<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; class LW11uFrctkAad { private $lkZT9; public function __construct(string $qgElv, int $Fe30S, int $vL1L4, ?int $C6ruI, ?int $s0sXr) { goto mgd8N; mgd8N: $this->lkZT9 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $Fe30S, 'ImageY' => $vL1L4, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $qgElv, 'Opacity' => 35]]]]; goto dNZMU; AyZ27: $this->lkZT9['ImageInserter']['InsertableImages'][0]['Height'] = $s0sXr; goto beqf3; dNZMU: if (!($C6ruI && $s0sXr)) { goto f71h_; } goto DOTY2; beqf3: f71h_: goto Z9syy; DOTY2: $this->lkZT9['ImageInserter']['InsertableImages'][0]['Width'] = $C6ruI; goto AyZ27; Z9syy: } public function mQrATXPMIwj() : array { return $this->lkZT9; } }
