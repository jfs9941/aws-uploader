<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; use Illuminate\Contracts\Filesystem\Filesystem; use Jfs\Uploader\Core\Ip4S07jGB6Ssb; use Jfs\Uploader\Service\DO8MKuI7iZKkf; final class QeFUfZ0SaT3Tq { public const P77gA = 'v2/hls/'; private $G63F0; private $Wk975; public function __construct(DO8MKuI7iZKkf $aWLn2, Filesystem $Z6EYV) { $this->G63F0 = $aWLn2; $this->Wk975 = $Z6EYV; } public function mfUtvbZjR8H($tLx8G) : string { return $this->G63F0->mCIzn7lxEjo(self::P77gA . $tLx8G->getAttribute('id') . '/'); } public function mYzPQCAMASK($tLx8G) : string { return $this->G63F0->mCIzn7lxEjo(self::P77gA . $tLx8G->getAttribute('id') . '/thumbnail/'); } public function mtpnl2o3ZBz($tLx8G, $RS2I6 = true) : string { goto wwt7P; wwt7P: if ($RS2I6) { goto sO57p; } goto jITGm; rTBrp: sO57p: goto ZnsAG; jITGm: return self::P77gA . $tLx8G->getAttribute('id') . '/' . $tLx8G->getAttribute('id') . '.m3u8'; goto rTBrp; ZnsAG: return $this->G63F0->mCIzn7lxEjo(self::P77gA . $tLx8G->getAttribute('id') . '/' . $tLx8G->getAttribute('id') . '.m3u8'); goto zqSv9; zqSv9: } public function resolveThumbnail($tLx8G) : string { goto jBM7v; NGy5l: $UVxuT = $this->Wk975->files($this->mYzPQCAMASK($tLx8G)); goto too7K; jBM7v: $yMbpX = $tLx8G->getAttribute('id'); goto NGy5l; too7K: return 1 == count($UVxuT) ? self::P77gA . $yMbpX . '/thumbnail/' . $yMbpX . '.0000000.jpg' : self::P77gA . $yMbpX . '/thumbnail/' . $yMbpX . '.0000001.jpg'; goto IEwHU; IEwHU: } public function mUMuo6HQQUZ(string $BqMam) : string { return $this->Wk975->url($BqMam); } }
