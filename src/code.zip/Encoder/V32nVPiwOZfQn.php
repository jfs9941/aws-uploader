<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; class V32nVPiwOZfQn { private $UFwRM; public function __construct(float $LWyZx, int $H30iE, string $oDw6l) { goto CZcNQ; Bi71A: $Wjko7 = max($Wjko7, 1); goto mdu_z; mdu_z: $this->UFwRM = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $Wjko7]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $oDw6l]]]; goto cCImI; CZcNQ: $Wjko7 = (int) $LWyZx / $H30iE; goto Bi71A; cCImI: } public function mEtZus7QFAx() : array { return $this->UFwRM; } }
