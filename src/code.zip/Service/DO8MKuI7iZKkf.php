<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Service; use Illuminate\Contracts\Filesystem\Filesystem; use Jfs\Uploader\Core\KcksySJhJWYDc; use Jfs\Uploader\Enum\FileDriver; final class DO8MKuI7iZKkf { private $O3YEZ; private $r7xRT; private $j3sqK; public function __construct(string $iGq6t, string $OlH3r, Filesystem $oPv40) { goto g4qLo; sgQ16: $this->r7xRT = $OlH3r; goto x_diW; x_diW: $this->j3sqK = $oPv40; goto SYYWN; g4qLo: $this->O3YEZ = $iGq6t; goto sgQ16; SYYWN: } public function mqg0DmCKPj4(KcksySJhJWYDc $hyZzp) : string { goto zEywf; zEywf: if (!(FileDriver::S3 == $hyZzp->getAttribute('driver'))) { goto lyTjK; } goto ajt2L; ViSVP: lyTjK: goto Mhyep; ajt2L: return 's3://' . $this->O3YEZ . '/' . $hyZzp->getAttribute('filename'); goto ViSVP; Mhyep: return $this->j3sqK->url($hyZzp->getAttribute('filename')); goto LiGHp; LiGHp: } public function mi24d3PG4HB(?string $XG4mY) : ?string { goto m7coD; FEj7v: $BqMam = parse_url($XG4mY, PHP_URL_PATH); goto cbgVQ; ey1ip: return null; goto ugq82; tvIto: if (!d7G0L($XG4mY, $this->O3YEZ)) { goto ydgpC; } goto FEj7v; exy3v: ydgpC: goto eWyOL; eWyOL: STCH8: goto ey1ip; cbgVQ: return 's3://' . $this->O3YEZ . '/' . ltrim($BqMam, '/'); goto exy3v; m7coD: if (!$XG4mY) { goto STCH8; } goto tvIto; ugq82: } public function mCIzn7lxEjo(string $BqMam) : string { return 's3://' . $this->O3YEZ . '/' . $BqMam; } }
