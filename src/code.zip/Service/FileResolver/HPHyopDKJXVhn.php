<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Service\FileResolver; use Jfs\Uploader\Core\Ip4S07jGB6Ssb; use Jfs\Uploader\Core\Filz4eY0wJAZu; final class HPHyopDKJXVhn implements GxaMXNGiGbnk7 { public function mSdIZLzo55a(Ip4S07jGB6Ssb $mS7iH) : string { return "v2/videos/{$mS7iH->getFileName()}.{$mS7iH->getExtension()}"; } public function mJPwOIdYsNQ(Ip4S07jGB6Ssb $mS7iH) { return $mS7iH instanceof Filz4eY0wJAZu; } }
