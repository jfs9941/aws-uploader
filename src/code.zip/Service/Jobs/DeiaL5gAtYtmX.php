<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Jfs\Uploader\Exposed\Jobs\PrepareMetadataJobInterface; use Jfs\Uploader\Core\Filz4eY0wJAZu; use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg; class DeiaL5gAtYtmX implements PrepareMetadataJobInterface { public function prepareMetadata(string $yMbpX) : void { goto tUR_9; yJKWv: if ($tLx8G->width() > 0 && $tLx8G->height() > 0) { goto O3PkO; } goto hotkI; hotkI: $this->mpqWHBObPFJ($tLx8G); goto GPvBY; tUR_9: $tLx8G = Filz4eY0wJAZu::findOrFail($yMbpX); goto yJKWv; GPvBY: O3PkO: goto DK6dB; DK6dB: } private function mpqWHBObPFJ(Filz4eY0wJAZu $Z2mW7) : void { goto cvnAs; cvnAs: $bywuI = $Z2mW7->getView(); goto x1Ymy; x9rn8: $ixTiX = $xd765->getVideoStream(); goto ONg1d; ER6Zh: $Z2mW7->update(['duration' => $xd765->getDurationInSeconds(), 'resolution' => $Ap98g->getWidth() . 'x' . $Ap98g->getHeight(), 'fps' => $ixTiX->get('r_frame_rate') ?? 30]); goto PMbgZ; ONg1d: $Ap98g = $ixTiX->getDimensions(); goto ER6Zh; x1Ymy: $xd765 = FFMpeg::fromDisk($bywuI['path'])->open($Z2mW7->getAttribute('filename')); goto x9rn8; PMbgZ: } }
