<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Illuminate\Support\Facades\Log; use Jfs\Uploader\Exposed\Jobs\GenerateThumbnailForVideoInterface; use Jfs\Uploader\Exposed\VideoPostHandleServiceInterface; class UFxXD8jcuTEDQ implements GenerateThumbnailForVideoInterface { private $vVeMM; public function __construct($kPKrK) { $this->vVeMM = $kPKrK; } public function generate(string $yMbpX) : void { Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $yMbpX); $this->vVeMM->createThumbnail($yMbpX); } }
