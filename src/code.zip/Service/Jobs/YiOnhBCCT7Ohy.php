<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Illuminate\Database\Eloquent\ModelNotFoundException; use Illuminate\Support\Facades\Log; use Jfs\Uploader\Exposed\Jobs\CompressJobInterface; use Jfs\Uploader\Core\LVQ91B8F8zY4F; class YiOnhBCCT7Ohy implements CompressJobInterface { const Ejd2T = 80; private $VWfMP; private $XmtJa; public function __construct($cfvlC, $tFGBJ) { $this->VWfMP = $cfvlC; $this->XmtJa = $tFGBJ; } public function compress(string $yMbpX) { Log::info("Compress image", ['imageId' => $yMbpX]); try { goto ao9WY; Cuf5s: $PP125 = $this->XmtJa->path($S8DUg->getLocation()); goto p9g7q; p9g7q: if (!($S8DUg->getExtension() === 'png')) { goto vEz8f; } goto x08P4; x08P4: $S8DUg->setAttribute('type', 'jpg'); goto esRQ3; esRQ3: $S8DUg->setAttribute('filename', str_replace('.png', '.jpg', $S8DUg->getLocation())); goto MCSzC; MCSzC: $S8DUg->save(); goto aL3vE; s_O2Y: $t7IX1->orientate(); goto io7sX; zO3qY: $t7IX1 = $this->VWfMP->call($this, $PP125); goto s_O2Y; io7sX: $t7IX1->save($pK3Hm, self::Ejd2T); goto id8f7; ao9WY: $S8DUg = LVQ91B8F8zY4F::findOrFail($yMbpX); goto Cuf5s; id8f7: $t7IX1->destroy(); goto yRLaU; aL3vE: vEz8f: goto gMee7; gMee7: $pK3Hm = $this->XmtJa->path($S8DUg->getLocation()); goto zO3qY; yRLaU: } catch (ModelNotFoundException) { Log::info("LVQ91B8F8zY4F has been deleted, discard it", ['imageId' => $yMbpX]); } } }
