<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Illuminate\Support\Facades\Log; use Illuminate\Support\Facades\Storage; use Jfs\Uploader\Exposed\Jobs\DownloadToLocalJobInterface; use Jfs\Uploader\Core\LVQ91B8F8zY4F; class Cildc8PGmPBSF implements DownloadToLocalJobInterface { private $Wk975; private $XmtJa; public function __construct($Z6EYV, $tFGBJ) { $this->Wk975 = $Z6EYV; $this->XmtJa = $tFGBJ; } public function download(string $yMbpX) : void { goto cWg_j; WycAm: return; goto DoEj_; cWg_j: $mS7iH = LVQ91B8F8zY4F::findOrFail($yMbpX); goto Ytpve; Ytpve: Log::info("Start download file to local", ['fileId' => $yMbpX, 'filename' => $mS7iH->getLocation()]); goto Ci_jf; DoEj_: HV1Lf: goto C4HMD; Ci_jf: if (!$this->XmtJa->exists($mS7iH->getLocation())) { goto HV1Lf; } goto WycAm; C4HMD: $this->XmtJa->put($mS7iH->getLocation(), $this->Wk975->get($mS7iH->getLocation())); goto GmHtJ; GmHtJ: } }
