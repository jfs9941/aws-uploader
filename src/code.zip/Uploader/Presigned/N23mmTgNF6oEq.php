<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\Rfow5q0HYgflu;
use Jfs\Uploader\Exception\JErR6MoLsdBKL;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Presigned\VqFBkbvSkc34V;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class N23mmTgNF6oEq implements VqFBkbvSkc34V
{
    private static $gzMi1 = 'chunks/';
    private $Fc9NF;
    private $j5MRz;
    private $Diye_;
    public function __construct(Rfow5q0HYgflu $LaHja, Filesystem $nkmCX, Filesystem $NYASv)
    {
        goto viGVe;
        S4BfU:
        $this->Diye_ = $NYASv;
        goto Mp7mH;
        e7RrI:
        $this->j5MRz = $nkmCX;
        goto S4BfU;
        viGVe:
        $this->Fc9NF = $LaHja;
        goto e7RrI;
        Mp7mH:
    }
    public function mB7vpRBakhx() : void
    {
        goto ZQEuc;
        uJ9sA:
        $s12IM = $Zqaxi->filename;
        goto d5mqF;
        d5mqF:
        $this->Fc9NF->mLISLvz7JU3()->mHiIxReHa8H($s12IM);
        goto Z9T8s;
        LC8nu:
        goto P1bUZ;
        goto SLSa4;
        YqE7e:
        P1bUZ:
        goto dpvmw;
        Ko2Wj:
        $hi827 = [];
        goto SGSbn;
        CulXz:
        $this->Diye_->put($this->Fc9NF->mAK7MUq8SYx(), json_encode($this->Fc9NF->mLISLvz7JU3()->toArray()));
        goto y4FLx;
        Iw16h:
        $vkvq3 = parse_url($MaCW5, PHP_URL_HOST);
        goto TYMuO;
        b3U2z:
        $lPyJj = parse_url($MaCW5, PHP_URL_PATH);
        goto Iw16h;
        eFTJ3:
        $hi827[] = ['index' => $igxB3, 'url' => $CWWxR];
        goto XrpxR;
        XrpxR:
        YltwT:
        goto h533X;
        dpvmw:
        if (!($igxB3 <= $D362G)) {
            goto rNead;
        }
        goto CLRsv;
        SLSa4:
        rNead:
        goto OKejW;
        J2k1D:
        $this->Fc9NF->mLISLvz7JU3()->mHiIxReHa8H($s12IM);
        goto wFn3R;
        CLRsv:
        $MaCW5 = route('upload.api.local_chunk.upload', ['uploadId' => $s12IM, 'index' => $igxB3]);
        goto b3U2z;
        h533X:
        ++$igxB3;
        goto LC8nu;
        OKejW:
        $this->Fc9NF->me2kPW7r3WV($hi827);
        goto J2k1D;
        Z9T8s:
        $igxB3 = 1;
        goto YqE7e;
        wFn3R:
        $this->j5MRz->put($this->Fc9NF->mAK7MUq8SYx(), json_encode($this->Fc9NF->mLISLvz7JU3()->toArray()));
        goto CulXz;
        TYMuO:
        $CWWxR = 'https://' . $vkvq3 . '/' . ltrim($lPyJj, '/');
        goto eFTJ3;
        ZQEuc:
        $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
        goto Ko2Wj;
        SGSbn:
        $D362G = ceil($Zqaxi->ZUDEN / $Zqaxi->RpZdB);
        goto uJ9sA;
        y4FLx:
    }
    public function mam3hAYlt0Q() : void
    {
        goto Pe8lY;
        LDNz1:
        $s12IM = $Zqaxi->Ca5Pw;
        goto cwACh;
        cwACh:
        $this->j5MRz->deleteDirectory(self::$gzMi1 . $s12IM);
        goto IqHDv;
        IqHDv:
        $this->Diye_->delete($this->Fc9NF->mAK7MUq8SYx());
        goto wxU2U;
        Pe8lY:
        $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
        goto LDNz1;
        wxU2U:
    }
    public function mpGt5pOOnnk() : void
    {
        goto OCgtC;
        ZBJ28:
        iWc97:
        goto ob9iv;
        DG9PR:
        oKHpJ:
        goto u5veO;
        xSCby:
        if (!(false === $YIyc0)) {
            goto m4uLu;
        }
        goto kS4nm;
        gwXZB:
        touch($JbZkE);
        goto ZsYMG;
        QVOwl:
        $zdavn = self::$gzMi1 . $Zqaxi->Ca5Pw;
        goto lHYTd;
        KNuzR:
        Assert::eq(count($zWS_M), $D362G, 'The number of parts and checksums must match.');
        goto phvow;
        ZsYMG:
        $YIyc0 = @fopen($JbZkE, 'wb');
        goto xSCby;
        ZPbIF:
        WQM9w:
        goto KY_k8;
        E1Zfc:
        $pIczb = dirname($k6VTn);
        goto IE_Cf;
        Kt6RT:
        if (chmod($W3vui, 0644)) {
            goto iWc97;
        }
        goto pBlEA;
        ByYf3:
        throw new \Exception('Failed to set file permissions for stored image: ' . $W3vui);
        goto ZBJ28;
        lHYTd:
        $k6VTn = $this->Fc9NF->getFile()->getLocation();
        goto oE9xm;
        kS4nm:
        throw new JErR6MoLsdBKL('Local chunk can not merge file (can create file): ' . $JbZkE);
        goto gdNR8;
        phvow:
        natsort($zWS_M);
        goto E1Zfc;
        OCgtC:
        $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
        goto WFZ2V;
        pBlEA:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $W3vui);
        goto ByYf3;
        IE_Cf:
        if ($this->j5MRz->exists($pIczb)) {
            goto WQM9w;
        }
        goto ti__Z;
        fqpsJ:
        $W3vui = $this->j5MRz->path($k6VTn);
        goto Kt6RT;
        k0F8Z:
        foreach ($zWS_M as $W5Sas) {
            goto F7yxB;
            F7yxB:
            $XTmyW = $this->j5MRz->path($W5Sas);
            goto cBiNo;
            ZK_xx:
            throw new JErR6MoLsdBKL('A chunk file not existed: ' . $XTmyW);
            goto Ia9kB;
            RPYGM:
            fclose($giuv5);
            goto cAUvj;
            dcRtV:
            throw new JErR6MoLsdBKL('A chunk file content can not copy: ' . $XTmyW);
            goto rEz3R;
            rEz3R:
            Bq9cT:
            goto iY9a7;
            yU8lE:
            if (!(false === $giuv5)) {
                goto hPVyW;
            }
            goto ZK_xx;
            iY9a7:
            zin03:
            goto KqkON;
            cBiNo:
            $giuv5 = @fopen($XTmyW, 'rb');
            goto yU8lE;
            Ia9kB:
            hPVyW:
            goto VIYsX;
            VIYsX:
            $katok = stream_copy_to_stream($giuv5, $YIyc0);
            goto RPYGM;
            cAUvj:
            if (!(false === $katok)) {
                goto Bq9cT;
            }
            goto dcRtV;
            KqkON:
        }
        goto DG9PR;
        u5veO:
        fclose($YIyc0);
        goto fqpsJ;
        ti__Z:
        $this->j5MRz->makeDirectory($pIczb);
        goto ZPbIF;
        WFZ2V:
        $D362G = $Zqaxi->QsKkV;
        goto QVOwl;
        oE9xm:
        $zWS_M = $this->j5MRz->files($zdavn);
        goto KNuzR;
        KY_k8:
        $JbZkE = $this->j5MRz->path($k6VTn);
        goto gwXZB;
        ob9iv:
        $this->j5MRz->deleteDirectory($zdavn);
        goto WbZ0d;
        gdNR8:
        m4uLu:
        goto k0F8Z;
        WbZ0d:
    }
}
