<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\I0VIwBtNAG2Lq;
use Jfs\Uploader\Exception\KiNemuUpdr4GY;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Presigned\MpQkc6sTxxyxM;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class SMLjySwy2Oxi2 implements MpQkc6sTxxyxM
{
    private static $bn_zm = 'chunks/';
    private $ImZI2;
    private $W2Sfl;
    private $dMiJj;
    public function __construct(I0VIwBtNAG2Lq $RHBLn, Filesystem $d_Wiu, Filesystem $F17Nf)
    {
        goto o664z;
        X8PKL:
        $this->dMiJj = $F17Nf;
        goto aeMyV;
        o664z:
        $this->ImZI2 = $RHBLn;
        goto S3PUr;
        S3PUr:
        $this->W2Sfl = $d_Wiu;
        goto X8PKL;
        aeMyV:
    }
    public function miOPwul7xEs() : void
    {
        goto UvGKQ;
        DGQbl:
        V0fNc:
        goto APnZa;
        nWOp6:
        $n1mJJ = ceil($fK0e7->jVikM / $fK0e7->vD_8M);
        goto KSqbd;
        APnZa:
        if (!($dLkks <= $n1mJJ)) {
            goto T0cbl;
        }
        goto TXTGY;
        jhG3q:
        $hs4qc = [];
        goto nWOp6;
        gU4AF:
        goto V0fNc;
        goto RMJsI;
        nyqb4:
        ++$dLkks;
        goto gU4AF;
        a3rNU:
        $this->dMiJj->put($this->ImZI2->mmOYDrQaoGz(), json_encode($this->ImZI2->mAOwHvxkwWq()->toArray()));
        goto AD75d;
        chGfc:
        $dLkks = 1;
        goto DGQbl;
        UvGKQ:
        $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
        goto jhG3q;
        HiZBr:
        $this->ImZI2->mvKUglYPOle($hs4qc);
        goto Z8sHK;
        QfYbG:
        iDcc2:
        goto nyqb4;
        PuHpO:
        $this->ImZI2->mAOwHvxkwWq()->m44sTqfMmVa($v5Sny);
        goto chGfc;
        KSqbd:
        $v5Sny = $fK0e7->filename;
        goto PuHpO;
        TXTGY:
        $hs4qc[] = ['index' => $dLkks, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $v5Sny, 'index' => $dLkks])];
        goto QfYbG;
        da9Fj:
        $this->W2Sfl->put($this->ImZI2->mmOYDrQaoGz(), json_encode($this->ImZI2->mAOwHvxkwWq()->toArray()));
        goto a3rNU;
        Z8sHK:
        $this->ImZI2->mAOwHvxkwWq()->m44sTqfMmVa($v5Sny);
        goto da9Fj;
        RMJsI:
        T0cbl:
        goto HiZBr;
        AD75d:
    }
    public function msracQGonfo() : void
    {
        goto vdNDv;
        kobI6:
        $this->dMiJj->delete($this->ImZI2->mmOYDrQaoGz());
        goto l63KL;
        t7Coa:
        $v5Sny = $fK0e7->Y7fjO;
        goto PvjLH;
        PvjLH:
        $this->W2Sfl->deleteDirectory(self::$bn_zm . $v5Sny);
        goto kobI6;
        vdNDv:
        $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
        goto t7Coa;
        l63KL:
    }
    public function mgn0m4kZaFh() : void
    {
        goto nLQoQ;
        QVLvh:
        throw new KiNemuUpdr4GY('Local chunk can not merge file (can create file): ' . $m3wB7);
        goto NvDWM;
        SxBXP:
        $LSo55 = $this->W2Sfl->files($u9t36);
        goto QtrYH;
        jwo2P:
        $uHw66 = $this->ImZI2->getFile()->getLocation();
        goto SxBXP;
        w0kbw:
        j6ood:
        goto ZK1km;
        BNTWZ:
        $P16Dd = $this->W2Sfl->path($uHw66);
        goto EYlP9;
        ZK1km:
        $this->W2Sfl->deleteDirectory($u9t36);
        goto uNTfn;
        ouuoI:
        $n1mJJ = $fK0e7->Qbq60;
        goto mCNEj;
        GvM6l:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $P16Dd);
        goto eK64Q;
        QtrYH:
        Assert::eq(count($LSo55), $n1mJJ, 'The number of parts and checksums must match.');
        goto cROxm;
        Hs2lt:
        fclose($TYNwn);
        goto BNTWZ;
        NvDWM:
        JM83v:
        goto rzt8j;
        ntFjp:
        touch($m3wB7);
        goto RCXmu;
        cROxm:
        natsort($LSo55);
        goto PMA8C;
        RCXmu:
        $TYNwn = @fopen($m3wB7, 'wb');
        goto HthSV;
        mCNEj:
        $u9t36 = self::$bn_zm . $fK0e7->Y7fjO;
        goto jwo2P;
        zLIaS:
        $m3wB7 = $this->W2Sfl->path($uHw66);
        goto ntFjp;
        CwM5_:
        f9BzZ:
        goto Hs2lt;
        W4v4Z:
        if ($this->W2Sfl->exists($uMGGh)) {
            goto rJzvD;
        }
        goto Df0qs;
        Df0qs:
        $this->W2Sfl->makeDirectory($uMGGh);
        goto kOrg4;
        nLQoQ:
        $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
        goto ouuoI;
        rzt8j:
        foreach ($LSo55 as $F5mIk) {
            goto TcZH3;
            ldKIA:
            TG7C1:
            goto eP6Mt;
            rVoac:
            arjl8:
            goto dB2rf;
            ZNP1N:
            throw new KiNemuUpdr4GY('A chunk file not existed: ' . $CQJZc);
            goto rVoac;
            dB2rf:
            $m4E_M = stream_copy_to_stream($BXuQM, $TYNwn);
            goto FwyY5;
            GfYjD:
            if (!(false === $m4E_M)) {
                goto psCpR;
            }
            goto rwEgI;
            m9lxF:
            psCpR:
            goto ldKIA;
            FwyY5:
            fclose($BXuQM);
            goto GfYjD;
            rwEgI:
            throw new KiNemuUpdr4GY('A chunk file content can not copy: ' . $CQJZc);
            goto m9lxF;
            Ek8IU:
            $BXuQM = @fopen($CQJZc, 'rb');
            goto Vw5Am;
            TcZH3:
            $CQJZc = $this->W2Sfl->path($F5mIk);
            goto Ek8IU;
            Vw5Am:
            if (!(false === $BXuQM)) {
                goto arjl8;
            }
            goto ZNP1N;
            eP6Mt:
        }
        goto CwM5_;
        PMA8C:
        $uMGGh = dirname($uHw66);
        goto W4v4Z;
        HthSV:
        if (!(false === $TYNwn)) {
            goto JM83v;
        }
        goto QVLvh;
        EYlP9:
        if (chmod($P16Dd, 0644)) {
            goto j6ood;
        }
        goto GvM6l;
        kOrg4:
        rJzvD:
        goto zLIaS;
        eK64Q:
        throw new \Exception('Failed to set file permissions for stored image: ' . $P16Dd);
        goto w0kbw;
        uNTfn:
    }
}
