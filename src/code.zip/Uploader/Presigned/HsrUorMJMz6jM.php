<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Presigned;

use backup\Uploader\Core\Pb0Dvv7XIOUP3;
use backup\Uploader\Exception\M7w1sfloneSV9;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Presigned\LWtJtdk30E0vd;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class HsrUorMJMz6jM implements LWtJtdk30E0vd
{
    private static $YMWAh = 'chunks/';
    private $eZBRn;
    private $FJZRi;
    private $JINyv;
    public function __construct(Pb0Dvv7XIOUP3 $D5W64, Filesystem $UEDUm, Filesystem $s49oM)
    {
        goto hep88;
        hep88:
        $this->eZBRn = $D5W64;
        goto WEgQP;
        WEgQP:
        $this->FJZRi = $UEDUm;
        goto qzgyS;
        qzgyS:
        $this->JINyv = $s49oM;
        goto gJtzS;
        gJtzS:
    }
    public function mUNxSWNsvIU() : void
    {
        goto KKXd8;
        rVMqW:
        $this->eZBRn->m77UJKssxZ5()->mrFQk9755s2($G56a2);
        goto N7_Xz;
        d_ESh:
        $this->JINyv->put($this->eZBRn->mE8PPexbKCM(), json_encode($this->eZBRn->m77UJKssxZ5()->toArray()));
        goto xhxCY;
        kadJX:
        if (!($YUcV3 <= $xfmMu)) {
            goto h6pxw;
        }
        goto sz4Ah;
        rUp5j:
        $YUcV3 = 1;
        goto iaX6t;
        XeBFA:
        iEFeN:
        goto uhCJs;
        iaX6t:
        pYotf:
        goto kadJX;
        KIR23:
        $sgukC = [];
        goto R50Xs;
        uhCJs:
        ++$YUcV3;
        goto eUJSN;
        KKXd8:
        $JbFc7 = $this->eZBRn->m77UJKssxZ5();
        goto KIR23;
        WpaiZ:
        h6pxw:
        goto QwO4H;
        sz4Ah:
        $sgukC[] = ['index' => $YUcV3, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $G56a2, 'index' => $YUcV3])];
        goto XeBFA;
        VEb2O:
        $this->eZBRn->m77UJKssxZ5()->mrFQk9755s2($G56a2);
        goto rUp5j;
        R50Xs:
        $xfmMu = ceil($JbFc7->AaaaP / $JbFc7->pc1aI);
        goto s2Q8c;
        s2Q8c:
        $G56a2 = Uuid::v4()->toHex();
        goto VEb2O;
        N7_Xz:
        $this->FJZRi->put($this->eZBRn->mE8PPexbKCM(), json_encode($this->eZBRn->m77UJKssxZ5()->toArray()));
        goto d_ESh;
        QwO4H:
        $this->eZBRn->mEXA8ft76kA($sgukC);
        goto rVMqW;
        eUJSN:
        goto pYotf;
        goto WpaiZ;
        xhxCY:
    }
    public function mKta32e3ZeL() : void
    {
        goto jDjMm;
        j4L9e:
        $G56a2 = $JbFc7->ZvM_a;
        goto d3XML;
        d3XML:
        $this->FJZRi->deleteDirectory(self::$YMWAh . $G56a2);
        goto RmsnS;
        jDjMm:
        $JbFc7 = $this->eZBRn->m77UJKssxZ5();
        goto j4L9e;
        RmsnS:
        $this->JINyv->delete($this->eZBRn->mE8PPexbKCM());
        goto s2X1D;
        s2X1D:
    }
    public function mluSWeny8it() : void
    {
        goto NganR;
        ajhl8:
        if ($this->FJZRi->exists($eHCHu)) {
            goto fmwca;
        }
        goto bjZEy;
        uVdRd:
        fmwca:
        goto kBIAy;
        F_j0m:
        $j0IEX = $this->eZBRn->getFile()->getLocation();
        goto xuR28;
        VHSpW:
        natsort($CB3SZ);
        goto n01CD;
        Devoj:
        $xfmMu = $JbFc7->tjMet;
        goto whYjC;
        whYjC:
        $Esnj0 = self::$YMWAh . $JbFc7->ZvM_a;
        goto F_j0m;
        RSnxR:
        vrKEF:
        goto LFVMa;
        kBIAy:
        $vMZ_N = $this->FJZRi->path($j0IEX);
        goto dmSxv;
        nhztI:
        $Gt0fZ = $this->FJZRi->path($j0IEX);
        goto ChNZw;
        Sdwq_:
        $this->FJZRi->deleteDirectory($Esnj0);
        goto KKwZM;
        bjZEy:
        $this->FJZRi->makeDirectory($eHCHu);
        goto uVdRd;
        XWHpP:
        $szJWB = @fopen($vMZ_N, 'wb');
        goto h9Isd;
        ChNZw:
        if (chmod($Gt0fZ, 0644)) {
            goto DnYMJ;
        }
        goto d_6jo;
        LFVMa:
        foreach ($CB3SZ as $H3xUC) {
            goto PR9zH;
            PR9zH:
            $OCWtZ = $this->FJZRi->path($H3xUC);
            goto r2rzy;
            e2213:
            if (!(false === $LUfo1)) {
                goto Yx6lR;
            }
            goto KfvNY;
            r2rzy:
            $LUfo1 = @fopen($OCWtZ, 'rb');
            goto e2213;
            G1JGd:
            Yx6lR:
            goto Xb6zl;
            AJ4ya:
            H8WxA:
            goto IkENk;
            wG7eo:
            fclose($LUfo1);
            goto RYdpt;
            qhADX:
            throw new M7w1sfloneSV9('A chunk file content can not copy: ' . $OCWtZ);
            goto tKuV2;
            tKuV2:
            D6Nnt:
            goto AJ4ya;
            RYdpt:
            if (!(false === $sXRv9)) {
                goto D6Nnt;
            }
            goto qhADX;
            KfvNY:
            throw new M7w1sfloneSV9('A chunk file not existed: ' . $OCWtZ);
            goto G1JGd;
            Xb6zl:
            $sXRv9 = stream_copy_to_stream($LUfo1, $szJWB);
            goto wG7eo;
            IkENk:
        }
        goto VLW20;
        h9Isd:
        if (!(false === $szJWB)) {
            goto vrKEF;
        }
        goto vOS6V;
        d_6jo:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $Gt0fZ);
        goto BlEzT;
        VLW20:
        Xciy_:
        goto vc2aj;
        tN1S6:
        Assert::eq(count($CB3SZ), $xfmMu, 'The number of parts and checksums must match.');
        goto VHSpW;
        BlEzT:
        throw new \Exception('Failed to set file permissions for stored image: ' . $Gt0fZ);
        goto meCrp;
        vc2aj:
        fclose($szJWB);
        goto nhztI;
        vOS6V:
        throw new M7w1sfloneSV9('Local chunk can not merge file (can create file): ' . $vMZ_N);
        goto RSnxR;
        n01CD:
        $eHCHu = dirname($j0IEX);
        goto ajhl8;
        dmSxv:
        touch($vMZ_N);
        goto XWHpP;
        NganR:
        $JbFc7 = $this->eZBRn->m77UJKssxZ5();
        goto Devoj;
        xuR28:
        $CB3SZ = $this->FJZRi->files($Esnj0);
        goto tN1S6;
        meCrp:
        DnYMJ:
        goto Sdwq_;
        KKwZM:
    }
}
