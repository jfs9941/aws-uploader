<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\PLi20pZSTTBHP;
use Jfs\Uploader\Exception\SBblY3x6tXLqg;
use Jfs\Uploader\Exception\TATK2XYTfrhu3;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Exception\BjZQ88WIjDC9s;
use Jfs\Uploader\Presigned\TR9OKRLZozZUP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class UN18LnxnRahWb implements TR9OKRLZozZUP
{
    private $Ym0Fe;
    private $pXh9P;
    private $Tfy0l;
    private $VzV90;
    public function __construct(PLi20pZSTTBHP $k0UDg, Filesystem $TWZho, Filesystem $bnvNm, string $v4kIW)
    {
        goto scIzb;
        EMann:
        $this->Tfy0l = $bnvNm;
        goto Ox_wp;
        J5nLw:
        $this->pXh9P = $TWZho;
        goto EMann;
        Ox_wp:
        $this->VzV90 = $v4kIW;
        goto UPR7x;
        scIzb:
        $this->Ym0Fe = $k0UDg;
        goto J5nLw;
        UPR7x:
    }
    public function mJyhvrcvYWY()
    {
        goto tiFrQ;
        uKlBe:
        $this->Tfy0l->put($this->Ym0Fe->m9Cbs65gEpK(), json_encode($this->Ym0Fe->mzbGvZW3SMF()->toArray()));
        goto sW6i1;
        wI4rr:
        ++$IXoHj;
        goto n0tMZ;
        W37rJ:
        RwE1m:
        goto kk1hQ;
        bWSEC:
        $nyh3w[] = ['index' => $IXoHj, 'url' => (string) $EA0zm->getUri()];
        goto L3fSJ;
        tmqUt:
        $IXoHj = 1;
        goto uSg1d;
        n0tMZ:
        goto ieM1B;
        goto W37rJ;
        tiFrQ:
        $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
        goto GSNXh;
        bcAKa:
        throw new BjZQ88WIjDC9s("Failed to create multipart upload for file {$this->Ym0Fe->getFile()->getFilename()}, S3 return empty response");
        goto lajG1;
        iiS56:
        $this->Ym0Fe->mzbGvZW3SMF()->mcz6MDxZF1x($aCVXA['UploadId']);
        goto IdCQt;
        kk1hQ:
        $this->Ym0Fe->m3uvAsmvocJ($nyh3w);
        goto iiS56;
        IdCQt:
        $this->pXh9P->put($this->Ym0Fe->m9Cbs65gEpK(), json_encode($this->Ym0Fe->mzbGvZW3SMF()->toArray()));
        goto uKlBe;
        LNFyl:
        $qNnht = $this->Tfy0l->getClient();
        goto Nhx_o;
        uSg1d:
        ieM1B:
        goto XzAiE;
        Hrnhd:
        $EA0zm = $qNnht->createPresignedRequest($bzYB8, '+1 day');
        goto bWSEC;
        L3fSJ:
        Ynn5e:
        goto wI4rr;
        JZddz:
        if (!(0 === $aCVXA->count())) {
            goto E9cwa;
        }
        goto bcAKa;
        DiHeb:
        $ruRfJ = ceil($bsvnL->P_XkO / $bsvnL->SWeqX);
        goto LNFyl;
        XzAiE:
        if (!($IXoHj <= $ruRfJ)) {
            goto RwE1m;
        }
        goto LFQdz;
        LFQdz:
        $bzYB8 = $qNnht->getCommand('UploadPart', ['Bucket' => $this->VzV90, 'Key' => $this->Ym0Fe->getFile()->getLocation(), 'UploadId' => $aCVXA['UploadId'], 'PartNumber' => $IXoHj]);
        goto Hrnhd;
        lajG1:
        E9cwa:
        goto tmqUt;
        Nhx_o:
        $aCVXA = $qNnht->createMultipartUpload(['Bucket' => $this->VzV90, 'Key' => $this->Ym0Fe->getFile()->getLocation(), 'ContentType' => $this->Ym0Fe->mzbGvZW3SMF()->rVXCI, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto JZddz;
        GSNXh:
        $nyh3w = [];
        goto DiHeb;
        sW6i1:
    }
    public function mxuapcvaHCE() : void
    {
        goto C1pG4;
        QxN__:
        $this->pXh9P->delete($this->Ym0Fe->m9Cbs65gEpK());
        goto moQ6K;
        moQ6K:
        $this->Tfy0l->delete($this->Ym0Fe->m9Cbs65gEpK());
        goto gaG7N;
        OjR7i:
        try {
            $qNnht->abortMultipartUpload(['Bucket' => $this->VzV90, 'Key' => $this->Ym0Fe->getFile()->getLocation(), 'UploadId' => $this->Ym0Fe->mzbGvZW3SMF()->cUKik]);
        } catch (\Throwable $jupeT) {
            throw new SBblY3x6tXLqg("Failed to abort multipart upload of file {$this->Ym0Fe->getFile()->getFilename()}", 0, $jupeT);
        }
        goto QxN__;
        C1pG4:
        $qNnht = $this->Tfy0l->getClient();
        goto OjR7i;
        gaG7N:
    }
    public function mGCUSudE8Jd() : void
    {
        goto VfLqi;
        VfLqi:
        $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
        goto Urmu3;
        rUCOC:
        dDz0a:
        goto sl4Au;
        mO7bS:
        Assert::eq(count($bQ_Iq), count($T52tC), 'The number of parts and checksums must match.');
        goto aSxyF;
        sl4Au:
        $qNnht = $this->Tfy0l->getClient();
        goto BqNiP;
        gJAN3:
        $T52tC = $bsvnL->E7GDc;
        goto mO7bS;
        Urmu3:
        $bQ_Iq = $bsvnL->CIuIt;
        goto gJAN3;
        aSxyF:
        $x8BdI = collect($bQ_Iq)->keyBy('partNumber');
        goto v29uc;
        BqNiP:
        try {
            $qNnht->completeMultipartUpload(['Bucket' => $this->VzV90, 'Key' => $this->Ym0Fe->getFile()->getLocation(), 'UploadId' => $this->Ym0Fe->mzbGvZW3SMF()->cUKik, 'MultipartUpload' => ['Parts' => collect($this->Ym0Fe->mzbGvZW3SMF()->CIuIt)->sortBy('partNumber')->map(fn($s2Skq) => ['ETag' => $s2Skq['eTag'], 'PartNumber' => $s2Skq['partNumber']])->toArray()]]);
        } catch (\Throwable $jupeT) {
            throw new TATK2XYTfrhu3("Failed to merge chunks of file {$this->Ym0Fe->getFile()->getFilename()}", 0, $jupeT);
        }
        goto PmDb6;
        v29uc:
        foreach ($T52tC as $Zcuhb) {
            goto mBjrX;
            YncA4:
            throw new TATK2XYTfrhu3("Checksum mismatch for part {$o9ydH} of file {$this->Ym0Fe->getFile()->getFilename()}");
            goto dxFbN;
            mBjrX:
            $o9ydH = $Zcuhb['partNumber'];
            goto TBCY9;
            vB1y3:
            if (!($s2Skq['eTag'] !== $Zcuhb['eTag'])) {
                goto S90bT;
            }
            goto YncA4;
            TBCY9:
            $s2Skq = $x8BdI[$o9ydH];
            goto vB1y3;
            dxFbN:
            S90bT:
            goto dNjBV;
            dNjBV:
            rH6Rh:
            goto VhVFA;
            VhVFA:
        }
        goto rUCOC;
        PmDb6:
    }
}
