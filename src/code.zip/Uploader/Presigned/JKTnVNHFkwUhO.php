<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\ZV4T54pWWCYdf;
use Jfs\Uploader\Exception\QzinLBl9CLzxV;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Presigned\D3WOtooSgtsIM;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class JKTnVNHFkwUhO implements D3WOtooSgtsIM
{
    private static $YChw3 = 'chunks/';
    private $fl_Nu;
    private $h0iwI;
    private $o9xvH;
    public function __construct(ZV4T54pWWCYdf $EZ04_, Filesystem $jxMWP, Filesystem $ft7kk)
    {
        goto pKlKl;
        yE3qW:
        $this->o9xvH = $ft7kk;
        goto TXGFp;
        pKlKl:
        $this->fl_Nu = $EZ04_;
        goto UoQfb;
        UoQfb:
        $this->h0iwI = $jxMWP;
        goto yE3qW;
        TXGFp:
    }
    public function mVNXsVqeTEd() : void
    {
        goto QQjZK;
        WT5j3:
        $Qa2v1 = [];
        goto CL6dO;
        rnp4q:
        RwPkD:
        goto BttI7;
        BttI7:
        if (!($HsMA6 <= $kv_XK)) {
            goto RVl5V;
        }
        goto zzWV8;
        nAlT6:
        ++$HsMA6;
        goto C6tCD;
        CL6dO:
        $kv_XK = ceil($V5lrw->qVkMu / $V5lrw->wuhof);
        goto TVjMi;
        C6tCD:
        goto RwPkD;
        goto DyxVv;
        vrmAt:
        $this->h0iwI->put($this->fl_Nu->mnTIDh8qJQQ(), json_encode($this->fl_Nu->mSViQFIwKkL()->toArray()));
        goto wlr6G;
        TVjMi:
        $IaSct = $V5lrw->filename;
        goto BAVHH;
        DyxVv:
        RVl5V:
        goto qB5Hu;
        wlr6G:
        $this->o9xvH->put($this->fl_Nu->mnTIDh8qJQQ(), json_encode($this->fl_Nu->mSViQFIwKkL()->toArray()));
        goto lcpH9;
        kiMl7:
        nx32o:
        goto nAlT6;
        sBQMN:
        $HsMA6 = 1;
        goto rnp4q;
        cUX7k:
        $this->fl_Nu->mSViQFIwKkL()->m3wuWcoEsff($IaSct);
        goto vrmAt;
        zzWV8:
        $Qa2v1[] = ['index' => $HsMA6, 'url' => str_replace('http', 'https', route('upload.api.local_chunk.upload', ['uploadId' => $IaSct, 'index' => $HsMA6]))];
        goto kiMl7;
        BAVHH:
        $this->fl_Nu->mSViQFIwKkL()->m3wuWcoEsff($IaSct);
        goto sBQMN;
        QQjZK:
        $V5lrw = $this->fl_Nu->mSViQFIwKkL();
        goto WT5j3;
        qB5Hu:
        $this->fl_Nu->m8J20ggo7Cc($Qa2v1);
        goto cUX7k;
        lcpH9:
    }
    public function ma5c6dbi8Bh() : void
    {
        goto LYoE8;
        Ymj4g:
        $this->h0iwI->deleteDirectory(self::$YChw3 . $IaSct);
        goto Pg69o;
        LYoE8:
        $V5lrw = $this->fl_Nu->mSViQFIwKkL();
        goto WKDOd;
        WKDOd:
        $IaSct = $V5lrw->ZiXeF;
        goto Ymj4g;
        Pg69o:
        $this->o9xvH->delete($this->fl_Nu->mnTIDh8qJQQ());
        goto krYhX;
        krYhX:
    }
    public function mUEzFn7SZiO() : void
    {
        goto pm2_d;
        arMn1:
        $K40WL = $this->fl_Nu->getFile()->getLocation();
        goto XE9rq;
        chlU7:
        throw new QzinLBl9CLzxV('Local chunk can not merge file (can create file): ' . $uez1y);
        goto of0tA;
        XE9rq:
        $kWtQi = $this->h0iwI->files($o3qpN);
        goto aAih3;
        gSwHX:
        fclose($UoDZg);
        goto hV1xm;
        exo0K:
        $UoDZg = @fopen($uez1y, 'wb');
        goto EG_NE;
        aAih3:
        Assert::eq(count($kWtQi), $kv_XK, 'The number of parts and checksums must match.');
        goto OmP5U;
        MS3fP:
        touch($uez1y);
        goto exo0K;
        q2d3B:
        if (chmod($HOs4s, 0644)) {
            goto du2Gj;
        }
        goto uQU2K;
        pm2_d:
        $V5lrw = $this->fl_Nu->mSViQFIwKkL();
        goto s9kht;
        EG_NE:
        if (!(false === $UoDZg)) {
            goto ySEuh;
        }
        goto chlU7;
        s9kht:
        $kv_XK = $V5lrw->Nb7VL;
        goto HcihM;
        hV1xm:
        $HOs4s = $this->h0iwI->path($K40WL);
        goto q2d3B;
        mN9Oq:
        $this->h0iwI->deleteDirectory($o3qpN);
        goto rWvAO;
        yQJCC:
        throw new \Exception('Failed to set file permissions for stored image: ' . $HOs4s);
        goto avlQi;
        pbobm:
        $this->h0iwI->makeDirectory($eEUKq);
        goto MB1V2;
        avlQi:
        du2Gj:
        goto mN9Oq;
        BJREU:
        $uez1y = $this->h0iwI->path($K40WL);
        goto MS3fP;
        NvQp_:
        $eEUKq = dirname($K40WL);
        goto xIh2m;
        uQU2K:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $HOs4s);
        goto yQJCC;
        MB1V2:
        wbawu:
        goto BJREU;
        xIh2m:
        if ($this->h0iwI->exists($eEUKq)) {
            goto wbawu;
        }
        goto pbobm;
        of0tA:
        ySEuh:
        goto cMLaI;
        cMLaI:
        foreach ($kWtQi as $ZkhOg) {
            goto MJ7rq;
            drDjN:
            qFjO_:
            goto pwKfy;
            vYhGQ:
            $cEUN8 = @fopen($G4VXS, 'rb');
            goto oYoFT;
            JQREF:
            fclose($cEUN8);
            goto kSA0H;
            MJ7rq:
            $G4VXS = $this->h0iwI->path($ZkhOg);
            goto vYhGQ;
            cVu0c:
            throw new QzinLBl9CLzxV('A chunk file content can not copy: ' . $G4VXS);
            goto TKNTR;
            oYoFT:
            if (!(false === $cEUN8)) {
                goto DL38F;
            }
            goto qGjxY;
            jFv8O:
            DL38F:
            goto HSSYT;
            kSA0H:
            if (!(false === $INUuJ)) {
                goto KE0cd;
            }
            goto cVu0c;
            HSSYT:
            $INUuJ = stream_copy_to_stream($cEUN8, $UoDZg);
            goto JQREF;
            qGjxY:
            throw new QzinLBl9CLzxV('A chunk file not existed: ' . $G4VXS);
            goto jFv8O;
            TKNTR:
            KE0cd:
            goto drDjN;
            pwKfy:
        }
        goto wPcos;
        wPcos:
        JWjpO:
        goto gSwHX;
        OmP5U:
        natsort($kWtQi);
        goto NvQp_;
        HcihM:
        $o3qpN = self::$YChw3 . $V5lrw->ZiXeF;
        goto arMn1;
        rWvAO:
    }
}
