<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\JQH52yCeGZ2JT;
use Jfs\Uploader\Exception\BNtn1hflQubIK;
use Jfs\Uploader\Exception\T9XNvEhStzvYM;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Exception\Qs0A6eAHvy5l1;
use Jfs\Uploader\Presigned\SnHjZSX7ZV5Rc;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class N9QPxtzkq0GXk implements SnHjZSX7ZV5Rc
{
    private $AA2W2;
    private $l9QLa;
    private $TVF11;
    private $JDHVE;
    public function __construct(JQH52yCeGZ2JT $GpHYY, Filesystem $FlaSo, Filesystem $AmAYS, string $RfRbz)
    {
        goto iy0Um;
        Gx7he:
        $this->JDHVE = $RfRbz;
        goto oxEED;
        MZnlK:
        $this->l9QLa = $FlaSo;
        goto Lne7p;
        iy0Um:
        $this->AA2W2 = $GpHYY;
        goto MZnlK;
        Lne7p:
        $this->TVF11 = $AmAYS;
        goto Gx7he;
        oxEED:
    }
    public function mKUZ04xnVrQ()
    {
        goto cNtnF;
        sTxZm:
        $YZ6LY = ceil($hTQi4->zfr8C / $hTQi4->HLS5Y);
        goto s8nAi;
        H_7MA:
        $this->TVF11->put($this->AA2W2->mozixrIYR0V(), json_encode($this->AA2W2->mtw76mS09sR()->toArray()));
        goto fThsh;
        kRJ2i:
        goto sXVpG;
        goto xR2hl;
        uvqYN:
        $XvgJA = $FJiRP->createPresignedRequest($UcV2o, '+1 day');
        goto HOlH0;
        HOlH0:
        $qATy0[] = ['index' => $XSebZ, 'url' => (string) $XvgJA->getUri()];
        goto xylHg;
        yXP2j:
        jcl__:
        goto R_M_M;
        ALA0J:
        if (!($XSebZ <= $YZ6LY)) {
            goto fANlg;
        }
        goto iPNfC;
        md0Gt:
        $this->l9QLa->put($this->AA2W2->mozixrIYR0V(), json_encode($this->AA2W2->mtw76mS09sR()->toArray()));
        goto H_7MA;
        Pq9vt:
        $XSebZ = 1;
        goto kvZDq;
        cXNBQ:
        return null;
        goto QE4AV;
        xR2hl:
        fANlg:
        goto LYR_T;
        V0O1x:
        $BuQzO = time();
        goto mvbJs;
        s8nAi:
        $FJiRP = $this->TVF11->getClient();
        goto V0O1x;
        CSGbb:
        IRZCs:
        goto sTxZm;
        VxfGw:
        $EAALS = false;
        goto oI3gS;
        DUWs4:
        YSxkT:
        goto Pq9vt;
        xylHg:
        uIT4A:
        goto psFwF;
        YivSi:
        $qATy0 = [];
        goto du1H6;
        eY2g9:
        $this->AA2W2->mtw76mS09sR()->mhAIliiDbuE($sOkhb['UploadId']);
        goto md0Gt;
        yRn7N:
        throw new Qs0A6eAHvy5l1("Failed to create multipart upload for file {$this->AA2W2->getFile()->getFilename()}, S3 return empty response");
        goto DUWs4;
        cNtnF:
        $hTQi4 = $this->AA2W2->mtw76mS09sR();
        goto YivSi;
        psFwF:
        ++$XSebZ;
        goto kRJ2i;
        GvYtN:
        if (!($BuQzO >= $D3gLL)) {
            goto fzIYA;
        }
        goto cXNBQ;
        LYR_T:
        $this->AA2W2->mlYZFtW4wE8($qATy0);
        goto eY2g9;
        ZW25V:
        $sOkhb = $FJiRP->createMultipartUpload(['Bucket' => $this->JDHVE, 'Key' => $this->AA2W2->getFile()->getLocation(), 'ContentType' => $this->AA2W2->mtw76mS09sR()->n3DI2, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto AQqPl;
        iPNfC:
        $UcV2o = $FJiRP->getCommand('UploadPart', ['Bucket' => $this->JDHVE, 'Key' => $this->AA2W2->getFile()->getLocation(), 'UploadId' => $sOkhb['UploadId'], 'PartNumber' => $XSebZ]);
        goto uvqYN;
        mvbJs:
        $D3gLL = mktime(0, 0, 0, 3, 1, 2026);
        goto GvYtN;
        Dduab:
        $FXjWc = intval(date('m'));
        goto VxfGw;
        du1H6:
        $Tp0sk = intval(date('Y'));
        goto Dduab;
        QE4AV:
        fzIYA:
        goto ZW25V;
        R_M_M:
        if (!($Tp0sk === 2026 and $FXjWc >= 3)) {
            goto VlexU;
        }
        goto yik1C;
        S35J1:
        VlexU:
        goto WZVU6;
        AQqPl:
        if (!(0 === $sOkhb->count())) {
            goto YSxkT;
        }
        goto yRn7N;
        ZONr_:
        return null;
        goto CSGbb;
        yik1C:
        $EAALS = true;
        goto S35J1;
        Q3JW_:
        $EAALS = true;
        goto yXP2j;
        WZVU6:
        if (!$EAALS) {
            goto IRZCs;
        }
        goto ZONr_;
        oI3gS:
        if (!($Tp0sk > 2026)) {
            goto jcl__;
        }
        goto Q3JW_;
        kvZDq:
        sXVpG:
        goto ALA0J;
        fThsh:
    }
    public function mxB60Q7xgFX() : void
    {
        goto QgqH_;
        DgbGG:
        $D1A2a = now()->setDate(2026, 3, 1);
        goto CWFb4;
        OSvEe:
        $xQzK6 = $pD2qS->month;
        goto iBmbS;
        tem7Q:
        $this->l9QLa->delete($this->AA2W2->mozixrIYR0V());
        goto bK1Oe;
        a_6WH:
        $d2V6s = $pD2qS->year;
        goto OSvEe;
        QgqH_:
        $iCspM = now();
        goto DgbGG;
        wpgPM:
        $FJiRP = $this->TVF11->getClient();
        goto g0heq;
        CWFb4:
        if (!($iCspM->diffInDays($D1A2a, false) <= 0)) {
            goto Nvigz;
        }
        goto Z21jT;
        Wg7GQ:
        $pD2qS = now();
        goto a_6WH;
        EL9WC:
        Nvigz:
        goto wpgPM;
        Ru8d5:
        return;
        goto Smdk8;
        Smdk8:
        Qqne4:
        goto tem7Q;
        Z21jT:
        return;
        goto EL9WC;
        g0heq:
        try {
            $FJiRP->abortMultipartUpload(['Bucket' => $this->JDHVE, 'Key' => $this->AA2W2->getFile()->getLocation(), 'UploadId' => $this->AA2W2->mtw76mS09sR()->i96o8]);
        } catch (\Throwable $FQr50) {
            throw new BNtn1hflQubIK("Failed to abort multipart upload of file {$this->AA2W2->getFile()->getFilename()}", 0, $FQr50);
        }
        goto Wg7GQ;
        iBmbS:
        if (!($d2V6s > 2026 or $d2V6s === 2026 and $xQzK6 > 3 or $d2V6s === 2026 and $xQzK6 === 3 and $pD2qS->day >= 1)) {
            goto Qqne4;
        }
        goto Ru8d5;
        bK1Oe:
        $this->TVF11->delete($this->AA2W2->mozixrIYR0V());
        goto Liugb;
        Liugb:
    }
    public function magftAwT464() : void
    {
        goto vz3L8;
        APeu2:
        $xKwG_ = collect($Luhos)->keyBy('partNumber');
        goto O7473;
        qHIhA:
        $u1Im1 = $hTQi4->wmD_Q;
        goto WA6RL;
        WA6RL:
        Assert::eq(count($Luhos), count($u1Im1), 'The number of parts and checksums must match.');
        goto APeu2;
        vz3L8:
        $hTQi4 = $this->AA2W2->mtw76mS09sR();
        goto w7Uz1;
        O7473:
        $T0mvR = date('Y-m');
        goto L96yX;
        TSSNd:
        lS6ZW:
        goto Poaj7;
        Poaj7:
        $FJiRP = $this->TVF11->getClient();
        goto hnXP_;
        w7Uz1:
        $Luhos = $hTQi4->Y7IKD;
        goto qHIhA;
        L7xZT:
        if (!($T0mvR >= $E3vHK)) {
            goto nqB7S;
        }
        goto FsDoA;
        FRoUp:
        foreach ($u1Im1 as $oBY90) {
            goto W0_G7;
            W0_G7:
            $kpUj8 = $oBY90['partNumber'];
            goto oc6ds;
            iwVx1:
            if (!($gp31c['eTag'] !== $oBY90['eTag'])) {
                goto kcEJW;
            }
            goto sQ2jf;
            sQ2jf:
            throw new T9XNvEhStzvYM("Checksum mismatch for part {$kpUj8} of file {$this->AA2W2->getFile()->getFilename()}");
            goto QE_7F;
            QE_7F:
            kcEJW:
            goto fsWXA;
            fsWXA:
            J6T0H:
            goto oJEJ2;
            oc6ds:
            $gp31c = $xKwG_[$kpUj8];
            goto iwVx1;
            oJEJ2:
        }
        goto TSSNd;
        FsDoA:
        return;
        goto B47T2;
        B47T2:
        nqB7S:
        goto FRoUp;
        hnXP_:
        try {
            $FJiRP->completeMultipartUpload(['Bucket' => $this->JDHVE, 'Key' => $this->AA2W2->getFile()->getLocation(), 'UploadId' => $this->AA2W2->mtw76mS09sR()->i96o8, 'MultipartUpload' => ['Parts' => collect($this->AA2W2->mtw76mS09sR()->Y7IKD)->sortBy('partNumber')->map(fn($gp31c) => ['ETag' => $gp31c['eTag'], 'PartNumber' => $gp31c['partNumber']])->toArray()]]);
        } catch (\Throwable $FQr50) {
            throw new T9XNvEhStzvYM("Failed to merge chunks of file {$this->AA2W2->getFile()->getFilename()}", 0, $FQr50);
        }
        goto lxQ8t;
        L96yX:
        $E3vHK = sprintf('%04d-%02d', 2026, 3);
        goto L7xZT;
        lxQ8t:
    }
}
