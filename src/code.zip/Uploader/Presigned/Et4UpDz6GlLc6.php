<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FUCc1kyYZtja3;
use Jfs\Uploader\Exception\W80S3BIfDCcVT;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Et4UpDz6GlLc6 implements GRbUnlgi8rQIE
{
    private static $XYzPY = 'chunks/';
    private $WdyLh;
    private $bX3fI;
    private $UAt4g;
    public function __construct(FUCc1kyYZtja3 $ld3oH, Filesystem $Q0hWX, Filesystem $RdfoB)
    {
        goto u4rMz;
        u4rMz:
        $this->WdyLh = $ld3oH;
        goto cyVc1;
        cyVc1:
        $this->bX3fI = $Q0hWX;
        goto T9qzO;
        T9qzO:
        $this->UAt4g = $RdfoB;
        goto fBtp_;
        fBtp_:
    }
    public function mFKsPsWJiLu() : void
    {
        goto W2SK_;
        mvV5G:
        $d_ind = [];
        goto ZTx6s;
        bx7zS:
        $this->WdyLh->mkBf6Gw5jFn()->mV8qOAW9LsS($Kps2Q);
        goto iIUwA;
        GuFbx:
        JeIOi:
        goto d4LOV;
        dI4Yx:
        $this->UAt4g->put($this->WdyLh->mHD2WAKGQbz(), json_encode($this->WdyLh->mkBf6Gw5jFn()->toArray()));
        goto L9zwi;
        Szo3o:
        RBS86:
        goto Scxtw;
        W2SK_:
        $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
        goto mvV5G;
        fuxnD:
        f23m6:
        goto JhO8Q;
        JhO8Q:
        $this->WdyLh->mlNtTK4pngF($d_ind);
        goto bx7zS;
        V9yoS:
        $Kps2Q = Uuid::v4()->toHex();
        goto VhuO9;
        iIUwA:
        $this->bX3fI->put($this->WdyLh->mHD2WAKGQbz(), json_encode($this->WdyLh->mkBf6Gw5jFn()->toArray()));
        goto dI4Yx;
        d4LOV:
        ++$KoFTL;
        goto oAYzX;
        VhuO9:
        $this->WdyLh->mkBf6Gw5jFn()->mV8qOAW9LsS($Kps2Q);
        goto nEuc4;
        nEuc4:
        $KoFTL = 1;
        goto Szo3o;
        oAYzX:
        goto RBS86;
        goto fuxnD;
        ZTx6s:
        $Pl90N = ceil($szNd7->Nx14_ / $szNd7->Z1nJX);
        goto V9yoS;
        Scxtw:
        if (!($KoFTL <= $Pl90N)) {
            goto f23m6;
        }
        goto jdJOW;
        jdJOW:
        $d_ind[] = ['index' => $KoFTL, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $Kps2Q, 'index' => $KoFTL])];
        goto GuFbx;
        L9zwi:
    }
    public function mvhetYh8Svj() : void
    {
        goto Kbd0b;
        uTech:
        $this->UAt4g->delete($this->WdyLh->mHD2WAKGQbz());
        goto VpDQP;
        cHCxo:
        $this->bX3fI->deleteDirectory(self::$XYzPY . $Kps2Q);
        goto uTech;
        ENDX0:
        $Kps2Q = $szNd7->PnBsq;
        goto cHCxo;
        Kbd0b:
        $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
        goto ENDX0;
        VpDQP:
    }
    public function mrCHpJ7Uki3() : void
    {
        goto iPC23;
        UuAQM:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $EAgPt);
        goto v9BhT;
        Ja1qk:
        Zcvb6:
        goto dQ3BA;
        xUpEs:
        $n5xKC = $this->WdyLh->getFile()->getLocation();
        goto oRU7a;
        oRU7a:
        $xn007 = $this->bX3fI->files($rm_sN);
        goto ku7Ep;
        PsYSI:
        if ($this->bX3fI->exists($BvMJg)) {
            goto quXD7;
        }
        goto B7Cqp;
        lOfWU:
        GqdI_:
        goto EqVyU;
        EEUwr:
        throw new W80S3BIfDCcVT('Local chunk can not merge file (can create file): ' . $mXf2r);
        goto Ja1qk;
        lNdhe:
        $EAgPt = $this->bX3fI->path($n5xKC);
        goto X15E3;
        KkNtk:
        $mXf2r = $this->bX3fI->path($n5xKC);
        goto nvH3c;
        PPhsG:
        fclose($nh4nD);
        goto lNdhe;
        EqVyU:
        $this->bX3fI->deleteDirectory($rm_sN);
        goto ZEdIF;
        Z3o39:
        $BvMJg = dirname($n5xKC);
        goto PsYSI;
        B7Cqp:
        $this->bX3fI->makeDirectory($BvMJg);
        goto MuTRL;
        RIT7K:
        $Pl90N = $szNd7->d1W2V;
        goto g1TgE;
        WXxzs:
        DMuK0:
        goto PPhsG;
        MuTRL:
        quXD7:
        goto KkNtk;
        ku7Ep:
        Assert::eq(count($xn007), $Pl90N, 'The number of parts and checksums must match.');
        goto R9H7I;
        iPC23:
        $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
        goto RIT7K;
        R9H7I:
        natsort($xn007);
        goto Z3o39;
        LkXZr:
        $nh4nD = @fopen($mXf2r, 'wb');
        goto ZptSz;
        v9BhT:
        throw new \Exception('Failed to set file permissions for stored image: ' . $EAgPt);
        goto lOfWU;
        g1TgE:
        $rm_sN = self::$XYzPY . $szNd7->PnBsq;
        goto xUpEs;
        dQ3BA:
        foreach ($xn007 as $It7jr) {
            goto JtzYE;
            H3h2u:
            FIgNC:
            goto hdIoH;
            h1XlV:
            bqq5n:
            goto Dv0dd;
            kCD2H:
            if (!(false === $B_EDj)) {
                goto FIgNC;
            }
            goto vL6Gz;
            lNepS:
            if (!(false === $BbquU)) {
                goto rnBat;
            }
            goto DAOoD;
            JtzYE:
            $nCEYJ = $this->bX3fI->path($It7jr);
            goto jkrNJ;
            jkrNJ:
            $B_EDj = @fopen($nCEYJ, 'rb');
            goto kCD2H;
            hdIoH:
            $BbquU = stream_copy_to_stream($B_EDj, $nh4nD);
            goto HA4FJ;
            HA4FJ:
            fclose($B_EDj);
            goto lNepS;
            aJTQ3:
            rnBat:
            goto h1XlV;
            DAOoD:
            throw new W80S3BIfDCcVT('A chunk file content can not copy: ' . $nCEYJ);
            goto aJTQ3;
            vL6Gz:
            throw new W80S3BIfDCcVT('A chunk file not existed: ' . $nCEYJ);
            goto H3h2u;
            Dv0dd:
        }
        goto WXxzs;
        nvH3c:
        touch($mXf2r);
        goto LkXZr;
        X15E3:
        if (chmod($EAgPt, 0644)) {
            goto GqdI_;
        }
        goto UuAQM;
        ZptSz:
        if (!(false === $nh4nD)) {
            goto Zcvb6;
        }
        goto EEUwr;
        ZEdIF:
    }
}
