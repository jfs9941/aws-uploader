<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UvoAmV0bL7M3i;
use Jfs\Uploader\Exception\Ycjaywk1DZxJx;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class XPrE42EoqXydt implements FEzFAspP5QxWi
{
    private static $FSYrc = 'chunks/';
    private $YYkmA;
    private $aB4Qh;
    private $qFnIc;
    public function __construct(UvoAmV0bL7M3i $au4Kn, Filesystem $Q0D24, Filesystem $A8Sfn)
    {
        goto TrtpG;
        RPnSD:
        $this->qFnIc = $A8Sfn;
        goto M93Um;
        i5OOB:
        $this->aB4Qh = $Q0D24;
        goto RPnSD;
        TrtpG:
        $this->YYkmA = $au4Kn;
        goto i5OOB;
        M93Um:
    }
    public function mX79Bq6DhRS() : void
    {
        goto QWCDF;
        MjAXO:
        $mZtuW = Uuid::v4()->toHex();
        goto jw4X0;
        VsR2D:
        jMei1:
        goto eL3vC;
        OXIxc:
        $APmCu = ceil($YKW91->Hj1Ds / $YKW91->pDj8N);
        goto MjAXO;
        g45rf:
        Ree8t:
        goto c2fEl;
        K1UEi:
        $this->YYkmA->mLK5jSa9bhL()->mljAt4c4xQC($mZtuW);
        goto mRm1k;
        jw4X0:
        $this->YYkmA->mLK5jSa9bhL()->mljAt4c4xQC($mZtuW);
        goto ur3AC;
        nUUfI:
        $Wdozm[] = ['index' => $rToUL, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $mZtuW, 'index' => $rToUL])];
        goto hpai7;
        QWCDF:
        $YKW91 = $this->YYkmA->mLK5jSa9bhL();
        goto UjKho;
        mRm1k:
        $this->aB4Qh->put($this->YYkmA->m6bsWqEDF0y(), json_encode($this->YYkmA->mLK5jSa9bhL()->toArray()));
        goto RDPKI;
        UjKho:
        $Wdozm = [];
        goto OXIxc;
        c2fEl:
        if (!($rToUL <= $APmCu)) {
            goto jMei1;
        }
        goto nUUfI;
        IscVs:
        ++$rToUL;
        goto fiTL4;
        fiTL4:
        goto Ree8t;
        goto VsR2D;
        hpai7:
        v7sCR:
        goto IscVs;
        ur3AC:
        $rToUL = 1;
        goto g45rf;
        eL3vC:
        $this->YYkmA->mkHeSFURrdO($Wdozm);
        goto K1UEi;
        RDPKI:
        $this->qFnIc->put($this->YYkmA->m6bsWqEDF0y(), json_encode($this->YYkmA->mLK5jSa9bhL()->toArray()));
        goto BCnn3;
        BCnn3:
    }
    public function me69BIFTRSd() : void
    {
        goto jbVts;
        jbVts:
        $YKW91 = $this->YYkmA->mLK5jSa9bhL();
        goto w8JN4;
        qm7lQ:
        $this->aB4Qh->deleteDirectory(self::$FSYrc . $mZtuW);
        goto wLtvz;
        w8JN4:
        $mZtuW = $YKW91->Llr3J;
        goto qm7lQ;
        wLtvz:
        $this->qFnIc->delete($this->YYkmA->m6bsWqEDF0y());
        goto v9Eig;
        v9Eig:
    }
    public function mab8LR1F1c8() : void
    {
        goto a92CY;
        h2TMa:
        foreach ($od91Z as $RdwfY) {
            goto nP6Gn;
            qpcd6:
            $RInqS = stream_copy_to_stream($ScsB6, $FcQrS);
            goto nnK7S;
            llqno:
            if (!(false === $ScsB6)) {
                goto RsjoF;
            }
            goto pUlrB;
            pUlrB:
            throw new Ycjaywk1DZxJx('A chunk file not existed: ' . $iLGe5);
            goto tZ91j;
            UYykV:
            $ScsB6 = @fopen($iLGe5, 'rb');
            goto llqno;
            tZ91j:
            RsjoF:
            goto qpcd6;
            nP6Gn:
            $iLGe5 = $this->aB4Qh->path($RdwfY);
            goto UYykV;
            rWSUw:
            SQffc:
            goto ZI97M;
            nnK7S:
            fclose($ScsB6);
            goto DBPdv;
            DBPdv:
            if (!(false === $RInqS)) {
                goto tvEyF;
            }
            goto DvfXv;
            DvfXv:
            throw new Ycjaywk1DZxJx('A chunk file content can not copy: ' . $iLGe5);
            goto jBpu5;
            jBpu5:
            tvEyF:
            goto rWSUw;
            ZI97M:
        }
        goto F92Ud;
        OHBrL:
        throw new \Exception('Failed to set file permissions for stored image: ' . $mGwgR);
        goto qu7oE;
        F92Ud:
        tgFF0:
        goto NPloq;
        yeLh3:
        $sL1L_ = $this->YYkmA->getFile()->getLocation();
        goto mR1Ue;
        xb5Bd:
        $mGwgR = $this->aB4Qh->path($sL1L_);
        goto D6dci;
        Rz43e:
        $zcdxf = $this->aB4Qh->path($sL1L_);
        goto Gz7g2;
        O_Npq:
        Hz7yH:
        goto Rz43e;
        F0WXM:
        if ($this->aB4Qh->exists($n9wnx)) {
            goto Hz7yH;
        }
        goto exZF0;
        WuLUR:
        natsort($od91Z);
        goto YWEvt;
        qu7oE:
        GONkO:
        goto Y0ht1;
        mR1Ue:
        $od91Z = $this->aB4Qh->files($xiPCw);
        goto iI0WL;
        iI0WL:
        Assert::eq(count($od91Z), $APmCu, 'The number of parts and checksums must match.');
        goto WuLUR;
        f6da9:
        VHiBz:
        goto h2TMa;
        etMrV:
        throw new Ycjaywk1DZxJx('Local chunk can not merge file (can create file): ' . $zcdxf);
        goto f6da9;
        D6dci:
        if (chmod($mGwgR, 0644)) {
            goto GONkO;
        }
        goto K4TTJ;
        Gz7g2:
        touch($zcdxf);
        goto zzaaa;
        Y0ht1:
        $this->aB4Qh->deleteDirectory($xiPCw);
        goto q2cGo;
        K4TTJ:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $mGwgR);
        goto OHBrL;
        qlpck:
        if (!(false === $FcQrS)) {
            goto VHiBz;
        }
        goto etMrV;
        exZF0:
        $this->aB4Qh->makeDirectory($n9wnx);
        goto O_Npq;
        O5rM5:
        $xiPCw = self::$FSYrc . $YKW91->Llr3J;
        goto yeLh3;
        a92CY:
        $YKW91 = $this->YYkmA->mLK5jSa9bhL();
        goto K0TnC;
        zzaaa:
        $FcQrS = @fopen($zcdxf, 'wb');
        goto qlpck;
        YWEvt:
        $n9wnx = dirname($sL1L_);
        goto F0WXM;
        K0TnC:
        $APmCu = $YKW91->IfFP1;
        goto O5rM5;
        NPloq:
        fclose($FcQrS);
        goto xb5Bd;
        q2cGo:
    }
}
