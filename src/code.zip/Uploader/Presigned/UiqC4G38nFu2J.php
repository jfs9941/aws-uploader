<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\ZFuimKZywyxo2;
use Jfs\Uploader\Exception\Z7YomP6U4O74j;
use Jfs\Uploader\Exception\TlWimU2mFcN6B;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Exception\OfpVnDWmMlNES;
use Jfs\Uploader\Presigned\HAbaKS6CSgn7Z;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class UiqC4G38nFu2J implements HAbaKS6CSgn7Z
{
    private $W_NkT;
    private $yt19t;
    private $wKOGL;
    private $XbarW;
    public function __construct(ZFuimKZywyxo2 $araMZ, Filesystem $RndMA, Filesystem $luwqK, string $YctT5)
    {
        goto y6CA8;
        TBwVx:
        $this->yt19t = $RndMA;
        goto fQl88;
        y6CA8:
        $this->W_NkT = $araMZ;
        goto TBwVx;
        nTnT3:
        $this->XbarW = $YctT5;
        goto MXRHc;
        fQl88:
        $this->wKOGL = $luwqK;
        goto nTnT3;
        MXRHc:
    }
    public function mFjyNjJ9bsc()
    {
        goto I_MnE;
        UIKVj:
        jBqYJ:
        goto ZVGJi;
        wn2K_:
        goto drN43;
        goto UIKVj;
        gc1Bh:
        $this->yt19t->put($this->W_NkT->muoWhAZBWrx(), json_encode($this->W_NkT->mf47A6FAs7u()->toArray()));
        goto NfpFr;
        tZPxn:
        throw new OfpVnDWmMlNES("Failed to create multipart upload for file {$this->W_NkT->getFile()->getFilename()}, S3 return empty response");
        goto yAtTD;
        FhpCU:
        $this->W_NkT->mf47A6FAs7u()->mYg3hbRtYS1($vnyRY['UploadId']);
        goto gc1Bh;
        jiAw5:
        $V6bfw = [];
        goto Uo8D9;
        lfcPf:
        $jM7_h = 1;
        goto keEKC;
        NfpFr:
        $this->wKOGL->put($this->W_NkT->muoWhAZBWrx(), json_encode($this->W_NkT->mf47A6FAs7u()->toArray()));
        goto vhe5D;
        ZVGJi:
        $this->W_NkT->mYisetnzoMl($V6bfw);
        goto FhpCU;
        keEKC:
        drN43:
        goto TFJKv;
        pDwqW:
        ++$jM7_h;
        goto wn2K_;
        TFJKv:
        if (!($jM7_h <= $GQ1lE)) {
            goto jBqYJ;
        }
        goto ajBk8;
        I_MnE:
        $zkqCI = $this->W_NkT->mf47A6FAs7u();
        goto jiAw5;
        e0sNY:
        $V6bfw[] = ['index' => $jM7_h, 'url' => (string) $uAxsj->getUri()];
        goto AUqW5;
        uoTXc:
        $vnyRY = $DPAi4->createMultipartUpload(['Bucket' => $this->XbarW, 'Key' => $this->W_NkT->getFile()->getLocation(), 'ContentType' => $this->W_NkT->mf47A6FAs7u()->yUFtr, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto TZFqn;
        Uo8D9:
        $GQ1lE = ceil($zkqCI->ylT5T / $zkqCI->Q3Heu);
        goto As6ZY;
        AUqW5:
        Ukcs8:
        goto pDwqW;
        MGacI:
        $uAxsj = $DPAi4->createPresignedRequest($SWDEo, '+1 day');
        goto e0sNY;
        ajBk8:
        $SWDEo = $DPAi4->getCommand('UploadPart', ['Bucket' => $this->XbarW, 'Key' => $this->W_NkT->getFile()->getLocation(), 'UploadId' => $vnyRY['UploadId'], 'PartNumber' => $jM7_h]);
        goto MGacI;
        As6ZY:
        $DPAi4 = $this->wKOGL->getClient();
        goto uoTXc;
        TZFqn:
        if (!(0 === $vnyRY->count())) {
            goto SeU9A;
        }
        goto tZPxn;
        yAtTD:
        SeU9A:
        goto lfcPf;
        vhe5D:
    }
    public function mFzOOpO3hET() : void
    {
        goto VMZIm;
        cVpov:
        try {
            $DPAi4->abortMultipartUpload(['Bucket' => $this->XbarW, 'Key' => $this->W_NkT->getFile()->getLocation(), 'UploadId' => $this->W_NkT->mf47A6FAs7u()->nk34n]);
        } catch (\Throwable $Jtg9A) {
            throw new Z7YomP6U4O74j("Failed to abort multipart upload of file {$this->W_NkT->getFile()->getFilename()}", 0, $Jtg9A);
        }
        goto es5hD;
        XxCis:
        $this->wKOGL->delete($this->W_NkT->muoWhAZBWrx());
        goto JS8QO;
        es5hD:
        $this->yt19t->delete($this->W_NkT->muoWhAZBWrx());
        goto XxCis;
        VMZIm:
        $DPAi4 = $this->wKOGL->getClient();
        goto cVpov;
        JS8QO:
    }
    public function mR3MGYXUkcQ() : void
    {
        goto s_SYE;
        zmaUS:
        $DPAi4 = $this->wKOGL->getClient();
        goto Ru4qG;
        xxqm4:
        Assert::eq(count($O39m9), count($fkXC5), 'The number of parts and checksums must match.');
        goto BNs1K;
        pDz7m:
        $fkXC5 = $zkqCI->bOsWj;
        goto xxqm4;
        M92A6:
        $O39m9 = $zkqCI->DRsEm;
        goto pDz7m;
        cKMDp:
        foreach ($fkXC5 as $Yw2ZO) {
            goto egyq6;
            KaBCq:
            if (!($HNva_['eTag'] !== $Yw2ZO['eTag'])) {
                goto Dl_e2;
            }
            goto OZvpz;
            iG3zb:
            JO1Vq:
            goto Yx3uW;
            OZvpz:
            throw new TlWimU2mFcN6B("Checksum mismatch for part {$BrfVD} of file {$this->W_NkT->getFile()->getFilename()}");
            goto otkwd;
            T4b2u:
            $HNva_ = $QUiI3[$BrfVD];
            goto KaBCq;
            egyq6:
            $BrfVD = $Yw2ZO['partNumber'];
            goto T4b2u;
            otkwd:
            Dl_e2:
            goto iG3zb;
            Yx3uW:
        }
        goto eBJ0m;
        BNs1K:
        $QUiI3 = collect($O39m9)->keyBy('partNumber');
        goto cKMDp;
        Ru4qG:
        try {
            $DPAi4->completeMultipartUpload(['Bucket' => $this->XbarW, 'Key' => $this->W_NkT->getFile()->getLocation(), 'UploadId' => $this->W_NkT->mf47A6FAs7u()->nk34n, 'MultipartUpload' => ['Parts' => collect($this->W_NkT->mf47A6FAs7u()->DRsEm)->sortBy('partNumber')->map(fn($HNva_) => ['ETag' => $HNva_['eTag'], 'PartNumber' => $HNva_['partNumber']])->toArray()]]);
        } catch (\Throwable $Jtg9A) {
            throw new TlWimU2mFcN6B("Failed to merge chunks of file {$this->W_NkT->getFile()->getFilename()}", 0, $Jtg9A);
        }
        goto pppdu;
        s_SYE:
        $zkqCI = $this->W_NkT->mf47A6FAs7u();
        goto M92A6;
        eBJ0m:
        gRdp2:
        goto zmaUS;
        pppdu:
    }
}
