<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\D4VgMZN43BF8o;
use Jfs\Uploader\Exception\OMb0yWYAcPeOw;
use Jfs\Uploader\Exception\PNXeQKcuBBTf6;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Exception\HFClZZzMY8BJU;
use Jfs\Uploader\Presigned\C8O6TZAvz7rlJ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class HmDvnx8A2PSxQ implements C8O6TZAvz7rlJ
{
    private $f0YGu;
    private $W9e5K;
    private $cEZhz;
    private $QNBCN;
    public function __construct(D4VgMZN43BF8o $oXu1C, Filesystem $XCkIj, Filesystem $UubHF, string $APN4u)
    {
        goto oqHNO;
        VXILh:
        $this->QNBCN = $APN4u;
        goto WHlC0;
        a5R8h:
        $this->W9e5K = $XCkIj;
        goto eFvF1;
        eFvF1:
        $this->cEZhz = $UubHF;
        goto VXILh;
        oqHNO:
        $this->f0YGu = $oXu1C;
        goto a5R8h;
        WHlC0:
    }
    public function mxPosq9wO3K()
    {
        goto ap0t4;
        tt08S:
        VgXVJ:
        goto MAoyh;
        sLaux:
        goto fHgda;
        goto fvYqK;
        z3evw:
        if (!(0 === $IcWNr->count())) {
            goto XxI0o;
        }
        goto JmZ58;
        ap0t4:
        $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
        goto DDGPm;
        JmZ58:
        throw new HFClZZzMY8BJU("Failed to create multipart upload for file {$this->f0YGu->getFile()->getFilename()}, S3 return empty response");
        goto b9yuL;
        znriu:
        $this->f0YGu->mJCTfUV9czb($jYIXy);
        goto FgFPd;
        DDGPm:
        $jYIXy = [];
        goto GqK3_;
        vzZB7:
        $VX4cz = $xfjC2->createPresignedRequest($kZFRf, '+1 day');
        goto BRKai;
        GqK3_:
        $unvls = ceil($u_EX6->mx_ve / $u_EX6->kar4X);
        goto fZJvk;
        zLS0_:
        if (!($g4K44 <= $unvls)) {
            goto J2O3G;
        }
        goto Ok7of;
        aVHpD:
        $g4K44 = 1;
        goto p2q0z;
        Ge03d:
        $IcWNr = $xfjC2->createMultipartUpload(['Bucket' => $this->QNBCN, 'Key' => $this->f0YGu->getFile()->getLocation(), 'ContentType' => $this->f0YGu->mlPpDqeRPNC()->KywSn, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto z3evw;
        Ok7of:
        $kZFRf = $xfjC2->getCommand('UploadPart', ['Bucket' => $this->QNBCN, 'Key' => $this->f0YGu->getFile()->getLocation(), 'UploadId' => $IcWNr['UploadId'], 'PartNumber' => $g4K44]);
        goto vzZB7;
        fvYqK:
        J2O3G:
        goto znriu;
        p2q0z:
        fHgda:
        goto zLS0_;
        b9yuL:
        XxI0o:
        goto aVHpD;
        BRKai:
        $jYIXy[] = ['index' => $g4K44, 'url' => (string) $VX4cz->getUri()];
        goto tt08S;
        FgFPd:
        $this->f0YGu->mlPpDqeRPNC()->mm4W6bXFGdY($IcWNr['UploadId']);
        goto JxJok;
        JvF06:
        $this->cEZhz->put($this->f0YGu->mEFYvbcZNB2(), json_encode($this->f0YGu->mlPpDqeRPNC()->toArray()));
        goto BxneW;
        MAoyh:
        ++$g4K44;
        goto sLaux;
        JxJok:
        $this->W9e5K->put($this->f0YGu->mEFYvbcZNB2(), json_encode($this->f0YGu->mlPpDqeRPNC()->toArray()));
        goto JvF06;
        fZJvk:
        $xfjC2 = $this->cEZhz->getClient();
        goto Ge03d;
        BxneW:
    }
    public function mSWgr2hpZl5() : void
    {
        goto e0o2i;
        WPiHU:
        $this->cEZhz->delete($this->f0YGu->mEFYvbcZNB2());
        goto K8zqj;
        e0o2i:
        $xfjC2 = $this->cEZhz->getClient();
        goto x64hp;
        ksErO:
        $this->W9e5K->delete($this->f0YGu->mEFYvbcZNB2());
        goto WPiHU;
        x64hp:
        try {
            $xfjC2->abortMultipartUpload(['Bucket' => $this->QNBCN, 'Key' => $this->f0YGu->getFile()->getLocation(), 'UploadId' => $this->f0YGu->mlPpDqeRPNC()->ROwMs]);
        } catch (\Throwable $oKDQw) {
            throw new OMb0yWYAcPeOw("Failed to abort multipart upload of file {$this->f0YGu->getFile()->getFilename()}", 0, $oKDQw);
        }
        goto ksErO;
        K8zqj:
    }
    public function maTvNKYiGsC() : void
    {
        goto doUwU;
        WTY2A:
        lWKoP:
        goto Z1dNK;
        VkvTk:
        Assert::eq(count($IovhQ), count($sF841), 'The number of parts and checksums must match.');
        goto Uv7Os;
        Z1dNK:
        $xfjC2 = $this->cEZhz->getClient();
        goto genee;
        xnolu:
        $sF841 = $u_EX6->ho3rM;
        goto VkvTk;
        genee:
        try {
            $xfjC2->completeMultipartUpload(['Bucket' => $this->QNBCN, 'Key' => $this->f0YGu->getFile()->getLocation(), 'UploadId' => $this->f0YGu->mlPpDqeRPNC()->ROwMs, 'MultipartUpload' => ['Parts' => collect($this->f0YGu->mlPpDqeRPNC()->AKW4f)->sortBy('partNumber')->map(fn($UxObC) => ['ETag' => $UxObC['eTag'], 'PartNumber' => $UxObC['partNumber']])->toArray()]]);
        } catch (\Throwable $oKDQw) {
            throw new PNXeQKcuBBTf6("Failed to merge chunks of file {$this->f0YGu->getFile()->getFilename()}", 0, $oKDQw);
        }
        goto RPwMJ;
        Azbt4:
        $IovhQ = $u_EX6->AKW4f;
        goto xnolu;
        Uv7Os:
        $Rb5Zd = collect($IovhQ)->keyBy('partNumber');
        goto kOXcT;
        kOXcT:
        foreach ($sF841 as $a7uio) {
            goto b8gag;
            wFvQl:
            throw new PNXeQKcuBBTf6("Checksum mismatch for part {$oOWRh} of file {$this->f0YGu->getFile()->getFilename()}");
            goto nObep;
            nObep:
            scrAi:
            goto fAx18;
            jXqF6:
            if (!($UxObC['eTag'] !== $a7uio['eTag'])) {
                goto scrAi;
            }
            goto wFvQl;
            fAx18:
            ijGJm:
            goto F6UHF;
            P3S5r:
            $UxObC = $Rb5Zd[$oOWRh];
            goto jXqF6;
            b8gag:
            $oOWRh = $a7uio['partNumber'];
            goto P3S5r;
            F6UHF:
        }
        goto WTY2A;
        doUwU:
        $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
        goto Azbt4;
        RPwMJ:
    }
}
