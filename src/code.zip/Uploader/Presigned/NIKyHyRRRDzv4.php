<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\EpvE4BO9GOGFh;
use Jfs\Uploader\Exception\AjL1OQuAtug3p;
use Jfs\Uploader\Exception\NmrNjbk6g29we;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Exception\DpHrJ5SdluXIW;
use Jfs\Uploader\Presigned\DTNoyruiw1HR5;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class NIKyHyRRRDzv4 implements DTNoyruiw1HR5
{
    private $EBcoC;
    private $TD3CW;
    private $Ht28P;
    private $nmHDC;
    public function __construct(EpvE4BO9GOGFh $N1xft, Filesystem $e3uVO, Filesystem $cUbzi, string $wIlgi)
    {
        goto WQFUx;
        vmih5:
        $this->TD3CW = $e3uVO;
        goto Z0ro8;
        QMs1L:
        $this->nmHDC = $wIlgi;
        goto tKuTD;
        Z0ro8:
        $this->Ht28P = $cUbzi;
        goto QMs1L;
        WQFUx:
        $this->EBcoC = $N1xft;
        goto vmih5;
        tKuTD:
    }
    public function mRdlHlaN15F()
    {
        goto QU28S;
        E1Kg6:
        $QU011 = $qUdal->createPresignedRequest($lgv8E, '+1 day');
        goto WggS3;
        Cy8iF:
        $this->TD3CW->put($this->EBcoC->mjA9e0O9M21(), json_encode($this->EBcoC->mw6tRR1NtWf()->toArray()));
        goto joaFn;
        NyBjz:
        TcQRy:
        goto Z_bf9;
        Lh0pX:
        z0T7V:
        goto ugHnS;
        NvENW:
        $DUsxo = $qUdal->createMultipartUpload(['Bucket' => $this->nmHDC, 'Key' => $this->EBcoC->getFile()->getLocation(), 'ContentType' => $this->EBcoC->mw6tRR1NtWf()->YLPQO, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto I_Qrx;
        rrRGD:
        ++$WMHuX;
        goto hew5f;
        ZwqOG:
        throw new DpHrJ5SdluXIW("Failed to create multipart upload for file {$this->EBcoC->getFile()->getFilename()}, S3 return empty response");
        goto NyBjz;
        GPHQ2:
        $lgv8E = $qUdal->getCommand('UploadPart', ['Bucket' => $this->nmHDC, 'Key' => $this->EBcoC->getFile()->getLocation(), 'UploadId' => $DUsxo['UploadId'], 'PartNumber' => $WMHuX]);
        goto E1Kg6;
        WggS3:
        $boggV[] = ['index' => $WMHuX, 'url' => (string) $QU011->getUri()];
        goto J1Z9B;
        fnIZ9:
        SWlg8:
        goto DiIi3;
        I_Qrx:
        if (!(0 === $DUsxo->count())) {
            goto TcQRy;
        }
        goto ZwqOG;
        Vtt0f:
        $this->EBcoC->mw6tRR1NtWf()->m4uiiVaRFKw($DUsxo['UploadId']);
        goto Cy8iF;
        joaFn:
        $this->Ht28P->put($this->EBcoC->mjA9e0O9M21(), json_encode($this->EBcoC->mw6tRR1NtWf()->toArray()));
        goto feqNJ;
        TPOD3:
        $boggV = [];
        goto ilO5s;
        ugHnS:
        $this->EBcoC->mTOWfJEsE4M($boggV);
        goto Vtt0f;
        hew5f:
        goto SWlg8;
        goto Lh0pX;
        Z_bf9:
        $WMHuX = 1;
        goto fnIZ9;
        oQaf1:
        $qUdal = $this->Ht28P->getClient();
        goto NvENW;
        DiIi3:
        if (!($WMHuX <= $J6kJg)) {
            goto z0T7V;
        }
        goto GPHQ2;
        QU28S:
        $abL5U = $this->EBcoC->mw6tRR1NtWf();
        goto TPOD3;
        J1Z9B:
        VBaW7:
        goto rrRGD;
        ilO5s:
        $J6kJg = ceil($abL5U->NG2sX / $abL5U->mGlEw);
        goto oQaf1;
        feqNJ:
    }
    public function mNbyeDUf9J3() : void
    {
        goto sp43D;
        sp43D:
        $qUdal = $this->Ht28P->getClient();
        goto HvsBf;
        HvsBf:
        try {
            $qUdal->abortMultipartUpload(['Bucket' => $this->nmHDC, 'Key' => $this->EBcoC->getFile()->getLocation(), 'UploadId' => $this->EBcoC->mw6tRR1NtWf()->RBHGE]);
        } catch (\Throwable $wEHhy) {
            throw new AjL1OQuAtug3p("Failed to abort multipart upload of file {$this->EBcoC->getFile()->getFilename()}", 0, $wEHhy);
        }
        goto jdTXh;
        X3S9S:
        $this->Ht28P->delete($this->EBcoC->mjA9e0O9M21());
        goto vevF4;
        jdTXh:
        $this->TD3CW->delete($this->EBcoC->mjA9e0O9M21());
        goto X3S9S;
        vevF4:
    }
    public function mSJsdVCHEX6() : void
    {
        goto H6dTD;
        CZVqv:
        $qgrjm = collect($nN4jY)->keyBy('partNumber');
        goto tHw5l;
        cpfBK:
        Assert::eq(count($nN4jY), count($WBy5d), 'The number of parts and checksums must match.');
        goto CZVqv;
        H6dTD:
        $abL5U = $this->EBcoC->mw6tRR1NtWf();
        goto QCstv;
        CAqOd:
        $WBy5d = $abL5U->EqDzm;
        goto cpfBK;
        BvylA:
        $qUdal = $this->Ht28P->getClient();
        goto vres2;
        vres2:
        try {
            $qUdal->completeMultipartUpload(['Bucket' => $this->nmHDC, 'Key' => $this->EBcoC->getFile()->getLocation(), 'UploadId' => $this->EBcoC->mw6tRR1NtWf()->RBHGE, 'MultipartUpload' => ['Parts' => collect($this->EBcoC->mw6tRR1NtWf()->FkUt2)->sortBy('partNumber')->map(fn($hGBMs) => ['ETag' => $hGBMs['eTag'], 'PartNumber' => $hGBMs['partNumber']])->toArray()]]);
        } catch (\Throwable $wEHhy) {
            throw new NmrNjbk6g29we("Failed to merge chunks of file {$this->EBcoC->getFile()->getFilename()}", 0, $wEHhy);
        }
        goto kB70l;
        fGCq0:
        RYXTj:
        goto BvylA;
        tHw5l:
        foreach ($WBy5d as $ZBdr1) {
            goto Be9tc;
            alqT5:
            Lo27u:
            goto wjwNx;
            vBaTK:
            throw new NmrNjbk6g29we("Checksum mismatch for part {$O0Dbv} of file {$this->EBcoC->getFile()->getFilename()}");
            goto wBtxJ;
            uFAY9:
            if (!($hGBMs['eTag'] !== $ZBdr1['eTag'])) {
                goto OVdK6;
            }
            goto vBaTK;
            rJy4d:
            $hGBMs = $qgrjm[$O0Dbv];
            goto uFAY9;
            wBtxJ:
            OVdK6:
            goto alqT5;
            Be9tc:
            $O0Dbv = $ZBdr1['partNumber'];
            goto rJy4d;
            wjwNx:
        }
        goto fGCq0;
        QCstv:
        $nN4jY = $abL5U->FkUt2;
        goto CAqOd;
        kB70l:
    }
}
