<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\UYVrA8my964mM;
use Jfs\Uploader\Exception\DADEKNm6UmpBg;
use Jfs\Uploader\Exception\O7TE1cDwqOaS4;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Exception\Ho9GPL9kaQA0u;
use Jfs\Uploader\Presigned\TiNDeDvTZ8mIR;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class OUJDLk41w7oqE implements TiNDeDvTZ8mIR
{
    private $BH22D;
    private $zoOKU;
    private $NICMg;
    private $pHuSQ;
    public function __construct(UYVrA8my964mM $e0yCg, Filesystem $e3FbC, Filesystem $iw6E8, string $h2Cp1)
    {
        goto tmDPw;
        tmDPw:
        $this->BH22D = $e0yCg;
        goto zhJUL;
        yJUOI:
        $this->pHuSQ = $h2Cp1;
        goto nwnFD;
        zhJUL:
        $this->zoOKU = $e3FbC;
        goto ZUrXC;
        ZUrXC:
        $this->NICMg = $iw6E8;
        goto yJUOI;
        nwnFD:
    }
    public function mrn0zxfXEyv()
    {
        goto DzVEZ;
        jBcmz:
        $ucyCa = ceil($AOnlH->J6RqZ / $AOnlH->UEMzw);
        goto TPnsd;
        UzvK9:
        ++$ejopc;
        goto l_y3Z;
        B3ggn:
        $ejopc = 1;
        goto By1Qr;
        pktNe:
        arAJG:
        goto B3ggn;
        oYmna:
        $COI2e = $ML8Ew->createMultipartUpload(['Bucket' => $this->pHuSQ, 'Key' => $this->BH22D->getFile()->getLocation(), 'ContentType' => $this->BH22D->m8KWEnHETkc()->Zmd06, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto kgQxd;
        jHXNS:
        if (!($ejopc <= $ucyCa)) {
            goto Dyn35;
        }
        goto qp2hl;
        bdd4p:
        $this->NICMg->put($this->BH22D->mlQjqylPuOa(), json_encode($this->BH22D->m8KWEnHETkc()->toArray()));
        goto Dndm_;
        l_y3Z:
        goto dE2zB;
        goto Cnadd;
        By1Qr:
        dE2zB:
        goto jHXNS;
        DzVEZ:
        $AOnlH = $this->BH22D->m8KWEnHETkc();
        goto XJh0M;
        MdR46:
        $this->BH22D->m8KWEnHETkc()->mI5wGiFDJrK($COI2e['UploadId']);
        goto lPhb4;
        kD6p3:
        $this->BH22D->mz9a6JmdKBB($AVdqv);
        goto MdR46;
        F2Oj1:
        FETyM:
        goto UzvK9;
        czpG3:
        throw new Ho9GPL9kaQA0u("Failed to create multipart upload for file {$this->BH22D->getFile()->getFilename()}, S3 return empty response");
        goto pktNe;
        zk6g_:
        $Hn6Lg = $ML8Ew->createPresignedRequest($yv2Ag, '+1 day');
        goto LWuCL;
        qp2hl:
        $yv2Ag = $ML8Ew->getCommand('UploadPart', ['Bucket' => $this->pHuSQ, 'Key' => $this->BH22D->getFile()->getLocation(), 'UploadId' => $COI2e['UploadId'], 'PartNumber' => $ejopc]);
        goto zk6g_;
        Cnadd:
        Dyn35:
        goto kD6p3;
        kgQxd:
        if (!(0 === $COI2e->count())) {
            goto arAJG;
        }
        goto czpG3;
        LWuCL:
        $AVdqv[] = ['index' => $ejopc, 'url' => (string) $Hn6Lg->getUri()];
        goto F2Oj1;
        TPnsd:
        $ML8Ew = $this->NICMg->getClient();
        goto oYmna;
        lPhb4:
        $this->zoOKU->put($this->BH22D->mlQjqylPuOa(), json_encode($this->BH22D->m8KWEnHETkc()->toArray()));
        goto bdd4p;
        XJh0M:
        $AVdqv = [];
        goto jBcmz;
        Dndm_:
    }
    public function mlSgbNh2AvY() : void
    {
        goto GcStO;
        amPse:
        try {
            $ML8Ew->abortMultipartUpload(['Bucket' => $this->pHuSQ, 'Key' => $this->BH22D->getFile()->getLocation(), 'UploadId' => $this->BH22D->m8KWEnHETkc()->s6sgC]);
        } catch (\Throwable $p0etA) {
            throw new DADEKNm6UmpBg("Failed to abort multipart upload of file {$this->BH22D->getFile()->getFilename()}", 0, $p0etA);
        }
        goto jlKfh;
        GcStO:
        $ML8Ew = $this->NICMg->getClient();
        goto amPse;
        jlKfh:
        $this->zoOKU->delete($this->BH22D->mlQjqylPuOa());
        goto i38NK;
        i38NK:
        $this->NICMg->delete($this->BH22D->mlQjqylPuOa());
        goto kroNL;
        kroNL:
    }
    public function mbG9fnI6E5D() : void
    {
        goto XVjsu;
        sYZ0l:
        $NCegP = $AOnlH->pNOXD;
        goto C5xaP;
        qic2X:
        $ML8Ew = $this->NICMg->getClient();
        goto X0N4F;
        C5xaP:
        $X3lTW = $AOnlH->GSkZ3;
        goto PSgEM;
        DWyUu:
        foreach ($X3lTW as $vdf2O) {
            goto KrWng;
            KbuPS:
            lfdTD:
            goto GeKOH;
            d0ZBF:
            $dJL0q = $Xqz2n[$uNVFZ];
            goto jnHbi;
            MCCdI:
            bxFpy:
            goto KbuPS;
            KrWng:
            $uNVFZ = $vdf2O['partNumber'];
            goto d0ZBF;
            T7hzj:
            throw new O7TE1cDwqOaS4("Checksum mismatch for part {$uNVFZ} of file {$this->BH22D->getFile()->getFilename()}");
            goto MCCdI;
            jnHbi:
            if (!($dJL0q['eTag'] !== $vdf2O['eTag'])) {
                goto bxFpy;
            }
            goto T7hzj;
            GeKOH:
        }
        goto NZr3t;
        ylQ1L:
        $Xqz2n = collect($NCegP)->keyBy('partNumber');
        goto DWyUu;
        NZr3t:
        QDYNk:
        goto qic2X;
        PSgEM:
        Assert::eq(count($NCegP), count($X3lTW), 'The number of parts and checksums must match.');
        goto ylQ1L;
        XVjsu:
        $AOnlH = $this->BH22D->m8KWEnHETkc();
        goto sYZ0l;
        X0N4F:
        try {
            $ML8Ew->completeMultipartUpload(['Bucket' => $this->pHuSQ, 'Key' => $this->BH22D->getFile()->getLocation(), 'UploadId' => $this->BH22D->m8KWEnHETkc()->s6sgC, 'MultipartUpload' => ['Parts' => collect($this->BH22D->m8KWEnHETkc()->pNOXD)->sortBy('partNumber')->map(fn($dJL0q) => ['ETag' => $dJL0q['eTag'], 'PartNumber' => $dJL0q['partNumber']])->toArray()]]);
        } catch (\Throwable $p0etA) {
            throw new O7TE1cDwqOaS4("Failed to merge chunks of file {$this->BH22D->getFile()->getFilename()}", 0, $p0etA);
        }
        goto IO80i;
        IO80i:
    }
}
