<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\DcQiQqj2PVL2z;
use Jfs\Uploader\Exception\AUYF7vc1ceGTR;
use Jfs\Uploader\Exception\SVA2aZGJgmDtq;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Exception\Ykleid03Drx9i;
use Jfs\Uploader\Presigned\Kdv2RDYQWDIhW;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class T0GFMTxoWASOt implements Kdv2RDYQWDIhW
{
    private $NHvEy;
    private $unMfk;
    private $x5SUA;
    private $petAu;
    public function __construct(DcQiQqj2PVL2z $m3Blp, Filesystem $L32kE, Filesystem $j3j3G, string $RiWpQ)
    {
        goto SrDBL;
        sMxa8:
        $this->petAu = $RiWpQ;
        goto BZHB_;
        SrDBL:
        $this->NHvEy = $m3Blp;
        goto jDfNT;
        u00U0:
        $this->x5SUA = $j3j3G;
        goto sMxa8;
        jDfNT:
        $this->unMfk = $L32kE;
        goto u00U0;
        BZHB_:
    }
    public function mzGVYtZieUh()
    {
        goto LucLd;
        WIac1:
        $GvmPZ = $he4Hj->getCommand('UploadPart', ['Bucket' => $this->petAu, 'Key' => $this->NHvEy->getFile()->getLocation(), 'UploadId' => $RXeDC['UploadId'], 'PartNumber' => $j4bsE]);
        goto SDtAu;
        FsrPS:
        goto PjxF3;
        goto PyJ1k;
        u8Cib:
        throw new Ykleid03Drx9i("Failed to create multipart upload for file {$this->NHvEy->getFile()->getFilename()}, S3 return empty response");
        goto O_twh;
        kx1TX:
        if (!($j4bsE <= $P13NU)) {
            goto lRw7j;
        }
        goto WIac1;
        SDtAu:
        $MT2WW = $he4Hj->createPresignedRequest($GvmPZ, '+1 day');
        goto M45iq;
        O2NK1:
        $this->x5SUA->put($this->NHvEy->mc7MIaojWTK(), json_encode($this->NHvEy->mYn06Pxlq0m()->toArray()));
        goto DEjWC;
        OPOr2:
        if (!(0 === $RXeDC->count())) {
            goto EDKxa;
        }
        goto u8Cib;
        RF6nT:
        HX2dh:
        goto jiT1v;
        M45iq:
        $yiCPI[] = ['index' => $j4bsE, 'url' => (string) $MT2WW->getUri()];
        goto RF6nT;
        PyJ1k:
        lRw7j:
        goto wFuNc;
        LucLd:
        $wEH2f = $this->NHvEy->mYn06Pxlq0m();
        goto Srnpe;
        jiT1v:
        ++$j4bsE;
        goto FsrPS;
        vocjE:
        $this->NHvEy->mYn06Pxlq0m()->mzmsXanFg3j($RXeDC['UploadId']);
        goto Sa7ms;
        Sa7ms:
        $this->unMfk->put($this->NHvEy->mc7MIaojWTK(), json_encode($this->NHvEy->mYn06Pxlq0m()->toArray()));
        goto O2NK1;
        pWFzO:
        $P13NU = ceil($wEH2f->rINwN / $wEH2f->tg2I4);
        goto BVg5b;
        Srnpe:
        $yiCPI = [];
        goto pWFzO;
        O_twh:
        EDKxa:
        goto LxrHt;
        BVg5b:
        $he4Hj = $this->x5SUA->getClient();
        goto ql1kr;
        ql1kr:
        $RXeDC = $he4Hj->createMultipartUpload(['Bucket' => $this->petAu, 'Key' => $this->NHvEy->getFile()->getLocation(), 'ContentType' => $this->NHvEy->mYn06Pxlq0m()->YK1UU, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto OPOr2;
        wFuNc:
        $this->NHvEy->mKgkEuClTdh($yiCPI);
        goto vocjE;
        bVZ4f:
        PjxF3:
        goto kx1TX;
        LxrHt:
        $j4bsE = 1;
        goto bVZ4f;
        DEjWC:
    }
    public function mo0bnXSNhQX() : void
    {
        goto ZkHvg;
        Q_Gck:
        $this->unMfk->delete($this->NHvEy->mc7MIaojWTK());
        goto t49QP;
        oMXaF:
        try {
            $he4Hj->abortMultipartUpload(['Bucket' => $this->petAu, 'Key' => $this->NHvEy->getFile()->getLocation(), 'UploadId' => $this->NHvEy->mYn06Pxlq0m()->OZbwJ]);
        } catch (\Throwable $dhJHu) {
            throw new AUYF7vc1ceGTR("Failed to abort multipart upload of file {$this->NHvEy->getFile()->getFilename()}", 0, $dhJHu);
        }
        goto Q_Gck;
        t49QP:
        $this->x5SUA->delete($this->NHvEy->mc7MIaojWTK());
        goto ra7Hv;
        ZkHvg:
        $he4Hj = $this->x5SUA->getClient();
        goto oMXaF;
        ra7Hv:
    }
    public function m5cVukL3XfZ() : void
    {
        goto qrq1f;
        Q49RB:
        $MPCIY = $wEH2f->Jol5M;
        goto aFOKs;
        Q4rlA:
        $Aw6Vd = $wEH2f->p3z8E;
        goto Q49RB;
        qrq1f:
        $wEH2f = $this->NHvEy->mYn06Pxlq0m();
        goto Q4rlA;
        S7iV0:
        $LDovo = collect($Aw6Vd)->keyBy('partNumber');
        goto GKicn;
        v08OO:
        $he4Hj = $this->x5SUA->getClient();
        goto QhQmR;
        aFOKs:
        Assert::eq(count($Aw6Vd), count($MPCIY), 'The number of parts and checksums must match.');
        goto S7iV0;
        QhQmR:
        try {
            $he4Hj->completeMultipartUpload(['Bucket' => $this->petAu, 'Key' => $this->NHvEy->getFile()->getLocation(), 'UploadId' => $this->NHvEy->mYn06Pxlq0m()->OZbwJ, 'MultipartUpload' => ['Parts' => collect($this->NHvEy->mYn06Pxlq0m()->p3z8E)->sortBy('partNumber')->map(fn($WJaue) => ['ETag' => $WJaue['eTag'], 'PartNumber' => $WJaue['partNumber']])->toArray()]]);
        } catch (\Throwable $dhJHu) {
            throw new SVA2aZGJgmDtq("Failed to merge chunks of file {$this->NHvEy->getFile()->getFilename()}", 0, $dhJHu);
        }
        goto KZ2Is;
        CQN7u:
        epIw8:
        goto v08OO;
        GKicn:
        foreach ($MPCIY as $cqwxK) {
            goto rBYWg;
            hd6Sb:
            throw new SVA2aZGJgmDtq("Checksum mismatch for part {$QgvN7} of file {$this->NHvEy->getFile()->getFilename()}");
            goto WveWR;
            keiCl:
            if (!($WJaue['eTag'] !== $cqwxK['eTag'])) {
                goto vUKAR;
            }
            goto hd6Sb;
            bD43z:
            t1c5B:
            goto MpKtb;
            rBYWg:
            $QgvN7 = $cqwxK['partNumber'];
            goto m6HkG;
            m6HkG:
            $WJaue = $LDovo[$QgvN7];
            goto keiCl;
            WveWR:
            vUKAR:
            goto bD43z;
            MpKtb:
        }
        goto CQN7u;
        KZ2Is:
    }
}
