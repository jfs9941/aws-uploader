<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Awxn6mQyQaPNK;
use Jfs\Uploader\Exception\LzC0xOlXt1he2;
use Jfs\Uploader\Exception\FZgyPg0yLfLgf;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Jfs\Uploader\Exception\Jv1k01IaWDwbX;
use Webmozart\Assert\Assert;
class E4Ha5YqXSNOy4 implements IXF2PdPyf9ZxL
{
    private $G_Jp3;
    private $OKvrN;
    private $y_rdZ;
    private $ZCKne;
    public function __construct(Awxn6mQyQaPNK $sqnmv, Filesystem $GiTtn, Filesystem $Cv4pg, string $mJZ7g)
    {
        goto MR4Z2;
        MR4Z2:
        $this->G_Jp3 = $sqnmv;
        goto kIXbz;
        kIXbz:
        $this->OKvrN = $GiTtn;
        goto J_Y0E;
        J_Y0E:
        $this->y_rdZ = $Cv4pg;
        goto uf7Sr;
        uf7Sr:
        $this->ZCKne = $mJZ7g;
        goto jOhcJ;
        jOhcJ:
    }
    public function mJ3A5JdqJu0()
    {
        goto GLAEE;
        XoYfD:
        $NgwJ1 = 1;
        goto TEoKh;
        vH9_L:
        if (!($NgwJ1 <= $W8PWX)) {
            goto RUuOr;
        }
        goto vcBNv;
        ftF2R:
        iM3CC:
        goto XoYfD;
        nBCYP:
        $this->y_rdZ->put($this->G_Jp3->mig8npPkPHw(), json_encode($this->G_Jp3->mdWxraqGvMN()->toArray()));
        goto AJKyV;
        TEoKh:
        xvgdB:
        goto vH9_L;
        S8e8t:
        ++$NgwJ1;
        goto IkZuX;
        zqXO8:
        $Nl8Kw = [];
        goto imDiI;
        IkZuX:
        goto xvgdB;
        goto QaHBg;
        Ih9S5:
        $Nl8Kw[] = ['index' => $NgwJ1, 'url' => (string) $GRTIv->getUri()];
        goto Lyvsj;
        GLAEE:
        $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
        goto zqXO8;
        Lyvsj:
        nFeQC:
        goto S8e8t;
        imDiI:
        $W8PWX = ceil($jJ8fr->lIbbz / $jJ8fr->myLYQ);
        goto Bvr_t;
        D128S:
        if (!(0 === $BVjJ8->count())) {
            goto iM3CC;
        }
        goto H_Gph;
        EOmY6:
        $BVjJ8 = $kEBaZ->createMultipartUpload(['Bucket' => $this->ZCKne, 'Key' => $this->G_Jp3->getFile()->getLocation(), 'ContentType' => $this->G_Jp3->mdWxraqGvMN()->xghyZ, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto D128S;
        EFxCB:
        $this->G_Jp3->mLCO6PoKT3u($Nl8Kw);
        goto eYdIa;
        eYdIa:
        $this->G_Jp3->mdWxraqGvMN()->mJvdHrWcN2f($BVjJ8['UploadId']);
        goto RuOyL;
        Bvr_t:
        $kEBaZ = $this->y_rdZ->getClient();
        goto EOmY6;
        vcBNv:
        $EdYfR = $kEBaZ->getCommand('UploadPart', ['Bucket' => $this->ZCKne, 'Key' => $this->G_Jp3->getFile()->getLocation(), 'UploadId' => $BVjJ8['UploadId'], 'PartNumber' => $NgwJ1]);
        goto Q6OYk;
        Q6OYk:
        $GRTIv = $kEBaZ->createPresignedRequest($EdYfR, '+1 day');
        goto Ih9S5;
        RuOyL:
        $this->OKvrN->put($this->G_Jp3->mig8npPkPHw(), json_encode($this->G_Jp3->mdWxraqGvMN()->toArray()));
        goto nBCYP;
        H_Gph:
        throw new Jv1k01IaWDwbX("Failed to create multipart upload for file {$this->G_Jp3->getFile()->getFilename()}, S3 return empty response");
        goto ftF2R;
        QaHBg:
        RUuOr:
        goto EFxCB;
        AJKyV:
    }
    public function mNBuHwfKe0i() : void
    {
        goto ALF5_;
        tiv5k:
        $this->y_rdZ->delete($this->G_Jp3->mig8npPkPHw());
        goto o0_3Y;
        CPOFA:
        try {
            $kEBaZ->abortMultipartUpload(['Bucket' => $this->ZCKne, 'Key' => $this->G_Jp3->getFile()->getLocation(), 'UploadId' => $this->G_Jp3->mdWxraqGvMN()->zLXWJ]);
        } catch (\Throwable $QEfxK) {
            throw new LzC0xOlXt1he2("Failed to abort multipart upload of file {$this->G_Jp3->getFile()->getFilename()}", 0, $QEfxK);
        }
        goto ks4ut;
        ALF5_:
        $kEBaZ = $this->y_rdZ->getClient();
        goto CPOFA;
        ks4ut:
        $this->OKvrN->delete($this->G_Jp3->mig8npPkPHw());
        goto tiv5k;
        o0_3Y:
    }
    public function mdiu2rEqHVo() : void
    {
        goto OUFNu;
        DVDEd:
        $WuWD8 = $jJ8fr->lC91s;
        goto bybO1;
        bSJX0:
        Assert::eq(count($WuWD8), count($I1ivv), 'The number of parts and checksums must match.');
        goto vm7Ky;
        HTZ9S:
        eXZTM:
        goto EbStk;
        rSiKZ:
        foreach ($I1ivv as $JjXmG) {
            goto V_FOG;
            V_FOG:
            $lTPaG = $JjXmG['partNumber'];
            goto IItC4;
            IItC4:
            $iUTsR = $d3prB[$lTPaG];
            goto sWt3N;
            Hu5Rh:
            throw new FZgyPg0yLfLgf("Checksum mismatch for part {$lTPaG} of file {$this->G_Jp3->getFile()->getFilename()}");
            goto MCpgH;
            sWt3N:
            if (!($iUTsR['eTag'] !== $JjXmG['eTag'])) {
                goto Pg10t;
            }
            goto Hu5Rh;
            MCpgH:
            Pg10t:
            goto fbQUu;
            fbQUu:
            OCgLE:
            goto l7YAR;
            l7YAR:
        }
        goto HTZ9S;
        bybO1:
        $I1ivv = $jJ8fr->XBduP;
        goto bSJX0;
        EbStk:
        $kEBaZ = $this->y_rdZ->getClient();
        goto Q1w4S;
        vm7Ky:
        $d3prB = collect($WuWD8)->keyBy('partNumber');
        goto rSiKZ;
        OUFNu:
        $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
        goto DVDEd;
        Q1w4S:
        try {
            $kEBaZ->completeMultipartUpload(['Bucket' => $this->ZCKne, 'Key' => $this->G_Jp3->getFile()->getLocation(), 'UploadId' => $this->G_Jp3->mdWxraqGvMN()->zLXWJ, 'MultipartUpload' => ['Parts' => collect($this->G_Jp3->mdWxraqGvMN()->lC91s)->sortBy('partNumber')->map(fn($iUTsR) => ['ETag' => $iUTsR['eTag'], 'PartNumber' => $iUTsR['partNumber']])->toArray()]]);
        } catch (\Throwable $QEfxK) {
            throw new FZgyPg0yLfLgf("Failed to merge chunks of file {$this->G_Jp3->getFile()->getFilename()}", 0, $QEfxK);
        }
        goto SZOyw;
        SZOyw:
    }
}
