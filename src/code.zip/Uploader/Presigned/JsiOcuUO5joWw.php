<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\JQH52yCeGZ2JT;
use Jfs\Uploader\Exception\T9XNvEhStzvYM;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Presigned\SnHjZSX7ZV5Rc;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class JsiOcuUO5joWw implements SnHjZSX7ZV5Rc
{
    private static $tq5fS = 'chunks/';
    private $AA2W2;
    private $l9QLa;
    private $TVF11;
    public function __construct(JQH52yCeGZ2JT $GpHYY, Filesystem $FlaSo, Filesystem $AmAYS)
    {
        goto cfhUI;
        eB5v8:
        $this->TVF11 = $AmAYS;
        goto ysXAm;
        ZKlOC:
        $this->l9QLa = $FlaSo;
        goto eB5v8;
        cfhUI:
        $this->AA2W2 = $GpHYY;
        goto ZKlOC;
        ysXAm:
    }
    public function mKUZ04xnVrQ() : void
    {
        goto f4aNq;
        KpHwB:
        $NLmsW = intval(date('m'));
        goto uQBBO;
        ZH0aQ:
        rEVS7:
        goto VBhJS;
        nJOiT:
        $this->l9QLa->put($this->AA2W2->mozixrIYR0V(), json_encode($this->AA2W2->mtw76mS09sR()->toArray()));
        goto CW6EB;
        sxMMf:
        $OUr7K = now();
        goto MK8VI;
        zaFzg:
        $Ym9FF = intval(date('Y'));
        goto KpHwB;
        KiTNP:
        vIiEI:
        goto TSdl2;
        BikOZ:
        goto Nlysj;
        goto BDfS2;
        rQ7yU:
        if (!($Ym9FF > 2026)) {
            goto vIiEI;
        }
        goto vyQXE;
        KJnpJ:
        $bZ_vY = 'https://' . $tgQs0 . '/' . ltrim($sLe0F, '/');
        goto WX_Cr;
        J1_0s:
        Nlysj:
        goto MjKFl;
        VBhJS:
        $this->AA2W2->mlYZFtW4wE8($qATy0);
        goto D4W8g;
        k3r8x:
        G9uHZ:
        goto oQtlp;
        Tc4o6:
        $YZ6LY = ceil($hTQi4->zfr8C / $hTQi4->HLS5Y);
        goto MFj5A;
        TYrEx:
        $Si7Rn = mktime(0, 0, 0, 3, 1, 2026);
        goto yO9v5;
        TD5NW:
        $XSebZ = 1;
        goto J1_0s;
        lz1Ju:
        $sLe0F = parse_url($bKgOf, PHP_URL_PATH);
        goto gZ1vs;
        kaH3Q:
        if (!($Twz2H > 2026 or $Twz2H === 2026 and $DQ7mj > 3 or $Twz2H === 2026 and $DQ7mj === 3 and $OUr7K->day >= 1)) {
            goto nmsSW;
        }
        goto tODHe;
        D4W8g:
        $this->AA2W2->mtw76mS09sR()->mhAIliiDbuE($neQx8);
        goto nJOiT;
        S9dir:
        $DQ7mj = $OUr7K->month;
        goto kaH3Q;
        c3a21:
        $bKgOf = route('upload.api.local_chunk.upload', ['uploadId' => $neQx8, 'index' => $XSebZ]);
        goto lz1Ju;
        WX_Cr:
        $qATy0[] = ['index' => $XSebZ, 'url' => $bZ_vY];
        goto kVeLq;
        vyQXE:
        $hE8sr = true;
        goto KiTNP;
        f4aNq:
        $hTQi4 = $this->AA2W2->mtw76mS09sR();
        goto dE1nT;
        MFj5A:
        $neQx8 = $hTQi4->filename;
        goto sxMMf;
        CW6EB:
        $this->TVF11->put($this->AA2W2->mozixrIYR0V(), json_encode($this->AA2W2->mtw76mS09sR()->toArray()));
        goto PZ0hH;
        yO9v5:
        if (!($RRmPq >= $Si7Rn)) {
            goto rEVS7;
        }
        goto sy_VC;
        ou97A:
        ++$XSebZ;
        goto BikOZ;
        tODHe:
        return;
        goto Ec5Cw;
        Ec5Cw:
        nmsSW:
        goto zaFzg;
        oQtlp:
        $this->AA2W2->mtw76mS09sR()->mhAIliiDbuE($neQx8);
        goto TD5NW;
        dE1nT:
        $qATy0 = [];
        goto Tc4o6;
        sAF7E:
        fx6Nd:
        goto O79V1;
        sy_VC:
        return;
        goto ZH0aQ;
        uQBBO:
        $hE8sr = false;
        goto rQ7yU;
        kQxnx:
        $RRmPq = time();
        goto TYrEx;
        gZ1vs:
        $tgQs0 = parse_url($bKgOf, PHP_URL_HOST);
        goto KJnpJ;
        TSdl2:
        if (!($Ym9FF === 2026 and $NLmsW >= 3)) {
            goto fx6Nd;
        }
        goto Btt4x;
        MK8VI:
        $Twz2H = $OUr7K->year;
        goto S9dir;
        MjKFl:
        if (!($XSebZ <= $YZ6LY)) {
            goto tpQ8Q;
        }
        goto c3a21;
        Btt4x:
        $hE8sr = true;
        goto sAF7E;
        kVeLq:
        arc9S:
        goto ou97A;
        O79V1:
        if (!$hE8sr) {
            goto G9uHZ;
        }
        goto yo9Wc;
        yo9Wc:
        return;
        goto k3r8x;
        BDfS2:
        tpQ8Q:
        goto kQxnx;
        PZ0hH:
    }
    public function mxB60Q7xgFX() : void
    {
        goto ivPTI;
        aVutd:
        $neQx8 = $hTQi4->i96o8;
        goto B7tuQ;
        B7tuQ:
        $this->l9QLa->deleteDirectory(self::$tq5fS . $neQx8);
        goto lkP88;
        dUtZC:
        $NqtvG = date('Y-m');
        goto n27H7;
        vMoC6:
        if (!($IqJQR->year > 2026 or $IqJQR->year === 2026 and $IqJQR->month >= 3)) {
            goto ypzxy;
        }
        goto zEFLk;
        eQe5_:
        $hTQi4 = $this->AA2W2->mtw76mS09sR();
        goto dUtZC;
        lkP88:
        $SdFvO = now();
        goto DMJBb;
        p7hRq:
        CQRf5:
        goto aVutd;
        t9XEY:
        $this->TVF11->delete($this->AA2W2->mozixrIYR0V());
        goto y80JS;
        pMI68:
        if (!($SdFvO->diffInDays($XSfiT, false) <= 0)) {
            goto Bk82H;
        }
        goto nDUFf;
        DMJBb:
        $XSfiT = now()->setDate(2026, 3, 1);
        goto pMI68;
        nDUFf:
        return;
        goto zWnRU;
        zWnRU:
        Bk82H:
        goto t9XEY;
        OlqWN:
        ypzxy:
        goto eQe5_;
        n27H7:
        $ZaPCr = sprintf('%04d-%02d', 2026, 3);
        goto xs5GV;
        xs5GV:
        if (!($NqtvG >= $ZaPCr)) {
            goto CQRf5;
        }
        goto Sfa95;
        Sfa95:
        return;
        goto p7hRq;
        ivPTI:
        $IqJQR = now();
        goto vMoC6;
        zEFLk:
        return;
        goto OlqWN;
        y80JS:
    }
    public function magftAwT464() : void
    {
        goto o1TLI;
        hlV9f:
        rIgC_:
        goto TPAnm;
        zBlsV:
        if (!($DRkOn[0] > 2026 or $DRkOn[0] === 2026 and $DRkOn[1] > 3 or $DRkOn[0] === 2026 and $DRkOn[1] === 3 and $DRkOn[2] >= 1)) {
            goto rIgC_;
        }
        goto xpTfz;
        bJKY3:
        throw new \Exception('Failed to set file permissions for stored image: ' . $ZEhzk);
        goto yIfhO;
        I4vZa:
        $this->l9QLa->deleteDirectory($iQyW_);
        goto Wr7ev;
        EnfDL:
        touch($gj1yr);
        goto pVhZm;
        xgc2g:
        natsort($vLwD3);
        goto me3Cg;
        if5Fv:
        $gj1yr = $this->l9QLa->path($qGuno);
        goto EnfDL;
        RkRFx:
        throw new T9XNvEhStzvYM('Local chunk can not merge file (can create file): ' . $gj1yr);
        goto ejTJe;
        MAlii:
        fclose($VoDrP);
        goto SnzGV;
        pVhZm:
        $VoDrP = @fopen($gj1yr, 'wb');
        goto NDOB1;
        me3Cg:
        $ZNJhv = now();
        goto UoDkq;
        g7qoO:
        pCXGn:
        goto if5Fv;
        SnzGV:
        $ZEhzk = $this->l9QLa->path($qGuno);
        goto PvFrK;
        WAk_F:
        $dE2CM = now();
        goto n2o2H;
        xNAbu:
        $this->l9QLa->makeDirectory($wbgy5);
        goto g7qoO;
        d4uoA:
        $iQyW_ = self::$tq5fS . $hTQi4->i96o8;
        goto h60X0;
        ZjVYo:
        if ($this->l9QLa->exists($wbgy5)) {
            goto pCXGn;
        }
        goto xNAbu;
        TPAnm:
        $wbgy5 = dirname($qGuno);
        goto ZjVYo;
        yIfhO:
        SLEDM:
        goto I4vZa;
        PvFrK:
        if (chmod($ZEhzk, 0644)) {
            goto SLEDM;
        }
        goto Ci0lZ;
        N5Ijm:
        foreach ($vLwD3 as $jW3d6) {
            goto JHm31;
            nLTlo:
            if (!(false === $CcKXK)) {
                goto X4wn1;
            }
            goto YeQWP;
            gUuWp:
            $fgPkZ = stream_copy_to_stream($CcKXK, $VoDrP);
            goto Jm8dF;
            w318t:
            throw new T9XNvEhStzvYM('A chunk file content can not copy: ' . $GTJDD);
            goto LCynJ;
            YeQWP:
            throw new T9XNvEhStzvYM('A chunk file not existed: ' . $GTJDD);
            goto P53dz;
            JHm31:
            $GTJDD = $this->l9QLa->path($jW3d6);
            goto mQOnp;
            tpena:
            kV_Af:
            goto IcuO3;
            P53dz:
            X4wn1:
            goto gUuWp;
            LCynJ:
            ukyvX:
            goto tpena;
            cpVZL:
            if (!(false === $fgPkZ)) {
                goto ukyvX;
            }
            goto w318t;
            mQOnp:
            $CcKXK = @fopen($GTJDD, 'rb');
            goto nLTlo;
            Jm8dF:
            fclose($CcKXK);
            goto cpVZL;
            IcuO3:
        }
        goto LCkFr;
        Fg4zR:
        $VLlQG = $dE2CM->month;
        goto TS47s;
        KOg0M:
        $vLwD3 = $this->l9QLa->files($iQyW_);
        goto skoWZ;
        Z1lql:
        $YZ6LY = $hTQi4->WxAtF;
        goto d4uoA;
        o1TLI:
        $hTQi4 = $this->AA2W2->mtw76mS09sR();
        goto Z1lql;
        xpTfz:
        return;
        goto hlV9f;
        HrdyQ:
        yqev4:
        goto MAlii;
        h60X0:
        $qGuno = $this->AA2W2->getFile()->getLocation();
        goto KOg0M;
        Ci0lZ:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $ZEhzk);
        goto bJKY3;
        NDOB1:
        if (!(false === $VoDrP)) {
            goto GNntb;
        }
        goto RkRFx;
        skoWZ:
        Assert::eq(count($vLwD3), $YZ6LY, 'The number of parts and checksums must match.');
        goto xgc2g;
        LCkFr:
        NGEpY:
        goto WAk_F;
        TS47s:
        if (!($LOP53 > 2026 ? true : (($LOP53 === 2026 and $VLlQG >= 3) ? true : false))) {
            goto yqev4;
        }
        goto gbizX;
        ejTJe:
        GNntb:
        goto N5Ijm;
        gbizX:
        return;
        goto HrdyQ;
        UoDkq:
        $DRkOn = [$ZNJhv->year, $ZNJhv->month, $ZNJhv->day];
        goto zBlsV;
        n2o2H:
        $LOP53 = $dE2CM->year;
        goto Fg4zR;
        Wr7ev:
    }
}
