<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

interface U1ZvgsGt0teMT
{
    public function mm4dJgrnW0N();
    public function mCHqfrmH8l8();
    public function mLNNdTnrcAS();
}
