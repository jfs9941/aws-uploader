<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\Hm5kuVZJdTKtj;
use Jfs\Uploader\Exception\LfYF54jMBIWX0;
use Jfs\Uploader\Exception\IbbbNgUH6aD1J;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Exception\K1XpNeEjZVUQH;
use Jfs\Uploader\Presigned\Dm52pX9iexrSs;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class UnoQO6Ikjrc34 implements Dm52pX9iexrSs
{
    private $D3E4X;
    private $uTYgy;
    private $gG9Jm;
    private $F_eut;
    public function __construct(Hm5kuVZJdTKtj $DiwBV, Filesystem $kVG4M, Filesystem $crBgX, string $Jkr71)
    {
        goto kasiW;
        Yll42:
        $this->uTYgy = $kVG4M;
        goto W_iZy;
        W_iZy:
        $this->gG9Jm = $crBgX;
        goto wiIhQ;
        kasiW:
        $this->D3E4X = $DiwBV;
        goto Yll42;
        wiIhQ:
        $this->F_eut = $Jkr71;
        goto BmBm2;
        BmBm2:
    }
    public function mFxnem6k407()
    {
        goto Fej5j;
        VH_SF:
        $this->gG9Jm->put($this->D3E4X->mwdQ1fTd3zq(), json_encode($this->D3E4X->mFV2s6jujmR()->toArray()));
        goto UgT0x;
        h2vHy:
        ++$i1iRy;
        goto J_3Zl;
        F2Ten:
        $this->D3E4X->mFV2s6jujmR()->mTOIVqQ3KEK($lgyD_['UploadId']);
        goto V7f6W;
        Fej5j:
        $H8A56 = $this->D3E4X->mFV2s6jujmR();
        goto Wa2TH;
        htd9O:
        throw new K1XpNeEjZVUQH("Failed to create multipart upload for file {$this->D3E4X->getFile()->getFilename()}, S3 return empty response");
        goto az4yG;
        eR3gv:
        $xqx5P[] = ['index' => $i1iRy, 'url' => (string) $UeLlB->getUri()];
        goto bQjbQ;
        FEPJR:
        $lgyD_ = $Ubm8B->createMultipartUpload(['Bucket' => $this->F_eut, 'Key' => $this->D3E4X->getFile()->getLocation(), 'ContentType' => $this->D3E4X->mFV2s6jujmR()->FvRNE, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto MJVMi;
        ka6tf:
        t4N3S:
        goto XN2TQ;
        t8vat:
        $YR3Z6 = $Ubm8B->getCommand('UploadPart', ['Bucket' => $this->F_eut, 'Key' => $this->D3E4X->getFile()->getLocation(), 'UploadId' => $lgyD_['UploadId'], 'PartNumber' => $i1iRy]);
        goto HyDtD;
        MJVMi:
        if (!(0 === $lgyD_->count())) {
            goto zk7rf;
        }
        goto htd9O;
        HDMyL:
        Nff7k:
        goto egQOl;
        az4yG:
        zk7rf:
        goto riytv;
        Wa2TH:
        $xqx5P = [];
        goto lDs6l;
        V7f6W:
        $this->uTYgy->put($this->D3E4X->mwdQ1fTd3zq(), json_encode($this->D3E4X->mFV2s6jujmR()->toArray()));
        goto VH_SF;
        bQjbQ:
        b0Ecx:
        goto h2vHy;
        riytv:
        $i1iRy = 1;
        goto ka6tf;
        HyDtD:
        $UeLlB = $Ubm8B->createPresignedRequest($YR3Z6, '+1 day');
        goto eR3gv;
        J_3Zl:
        goto t4N3S;
        goto HDMyL;
        XN2TQ:
        if (!($i1iRy <= $ZsNWr)) {
            goto Nff7k;
        }
        goto t8vat;
        uWrTG:
        $Ubm8B = $this->gG9Jm->getClient();
        goto FEPJR;
        lDs6l:
        $ZsNWr = ceil($H8A56->d7Yxv / $H8A56->MZnay);
        goto uWrTG;
        egQOl:
        $this->D3E4X->mbYvNurXiYp($xqx5P);
        goto F2Ten;
        UgT0x:
    }
    public function mmoUBfLYEHW() : void
    {
        goto SRO3b;
        SRO3b:
        $Ubm8B = $this->gG9Jm->getClient();
        goto bfamG;
        bC00_:
        $this->uTYgy->delete($this->D3E4X->mwdQ1fTd3zq());
        goto bEony;
        bfamG:
        try {
            $Ubm8B->abortMultipartUpload(['Bucket' => $this->F_eut, 'Key' => $this->D3E4X->getFile()->getLocation(), 'UploadId' => $this->D3E4X->mFV2s6jujmR()->F_Dsk]);
        } catch (\Throwable $xMxrQ) {
            throw new LfYF54jMBIWX0("Failed to abort multipart upload of file {$this->D3E4X->getFile()->getFilename()}", 0, $xMxrQ);
        }
        goto bC00_;
        bEony:
        $this->gG9Jm->delete($this->D3E4X->mwdQ1fTd3zq());
        goto oIyjU;
        oIyjU:
    }
    public function mH7ADod756J() : void
    {
        goto ojUcg;
        PhrDr:
        QbkA4:
        goto bt7SB;
        l_B1O:
        $mCZQS = $H8A56->uR8r7;
        goto TKVSh;
        ignl3:
        $M5tou = $H8A56->SBfza;
        goto l_B1O;
        bt7SB:
        $Ubm8B = $this->gG9Jm->getClient();
        goto Z9TKp;
        wdQVX:
        $JbyJM = collect($M5tou)->keyBy('partNumber');
        goto SISvk;
        TKVSh:
        Assert::eq(count($M5tou), count($mCZQS), 'The number of parts and checksums must match.');
        goto wdQVX;
        SISvk:
        foreach ($mCZQS as $W52wb) {
            goto Nz6I3;
            ndfQC:
            if (!($YuqDq['eTag'] !== $W52wb['eTag'])) {
                goto zKsnD;
            }
            goto b2Sed;
            fBpfE:
            zKsnD:
            goto DyaNe;
            DyaNe:
            nyHIB:
            goto jFkb0;
            kcnEu:
            $YuqDq = $JbyJM[$CFrqT];
            goto ndfQC;
            b2Sed:
            throw new IbbbNgUH6aD1J("Checksum mismatch for part {$CFrqT} of file {$this->D3E4X->getFile()->getFilename()}");
            goto fBpfE;
            Nz6I3:
            $CFrqT = $W52wb['partNumber'];
            goto kcnEu;
            jFkb0:
        }
        goto PhrDr;
        Z9TKp:
        try {
            $Ubm8B->completeMultipartUpload(['Bucket' => $this->F_eut, 'Key' => $this->D3E4X->getFile()->getLocation(), 'UploadId' => $this->D3E4X->mFV2s6jujmR()->F_Dsk, 'MultipartUpload' => ['Parts' => collect($this->D3E4X->mFV2s6jujmR()->SBfza)->sortBy('partNumber')->map(fn($YuqDq) => ['ETag' => $YuqDq['eTag'], 'PartNumber' => $YuqDq['partNumber']])->toArray()]]);
        } catch (\Throwable $xMxrQ) {
            throw new IbbbNgUH6aD1J("Failed to merge chunks of file {$this->D3E4X->getFile()->getFilename()}", 0, $xMxrQ);
        }
        goto sE_Uy;
        ojUcg:
        $H8A56 = $this->D3E4X->mFV2s6jujmR();
        goto ignl3;
        sE_Uy:
    }
}
