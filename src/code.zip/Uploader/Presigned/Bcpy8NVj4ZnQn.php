<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\IQDEtKorMDqYa;
use Jfs\Uploader\Exception\VLsw4zWL0oGJH;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Presigned\GIpmRlprHQXSB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Bcpy8NVj4ZnQn implements GIpmRlprHQXSB
{
    private static $svNEn = 'chunks/';
    private $oVe7o;
    private $iAAqk;
    private $PrHIa;
    public function __construct(IQDEtKorMDqYa $r4uPF, Filesystem $YNIuu, Filesystem $NP1kd)
    {
        goto UeBtL;
        UeBtL:
        $this->oVe7o = $r4uPF;
        goto Yk2Ru;
        Yk2Ru:
        $this->iAAqk = $YNIuu;
        goto Uj0PA;
        Uj0PA:
        $this->PrHIa = $NP1kd;
        goto KaBFx;
        KaBFx:
    }
    public function mMbBP7u4MD7() : void
    {
        goto oxbx1;
        dgRMI:
        $this->iAAqk->put($this->oVe7o->mwL2ScZNW65(), json_encode($this->oVe7o->mIrarJhaP0j()->toArray()));
        goto n9IHA;
        oxbx1:
        $TxsWN = $this->oVe7o->mIrarJhaP0j();
        goto OCZMO;
        G1jug:
        $iZJLy = 1;
        goto Q16fm;
        GHtFn:
        $this->oVe7o->mIrarJhaP0j()->mRBZ72cnJM7($I0nMz);
        goto dgRMI;
        UOo83:
        if (!($iZJLy <= $YnTza)) {
            goto u96FL;
        }
        goto npgYC;
        Q16fm:
        CzK85:
        goto UOo83;
        HEvdg:
        $YnTza = ceil($TxsWN->taYQP / $TxsWN->w2zTJ);
        goto xvr2U;
        GMH65:
        $this->oVe7o->mzAHhqFLnsA($IIxqH);
        goto GHtFn;
        npgYC:
        $yGB2u = route('upload.api.local_chunk.upload', ['uploadId' => $I0nMz, 'index' => $iZJLy]);
        goto ATZXl;
        w7b5c:
        u96FL:
        goto GMH65;
        h4mx7:
        pYfDq:
        goto hMpbS;
        ODml9:
        goto CzK85;
        goto w7b5c;
        R5A33:
        $IIxqH[] = ['index' => $iZJLy, 'url' => $nGV_C];
        goto h4mx7;
        n9IHA:
        $this->PrHIa->put($this->oVe7o->mwL2ScZNW65(), json_encode($this->oVe7o->mIrarJhaP0j()->toArray()));
        goto eniK0;
        RC51g:
        $iOwmw = parse_url($yGB2u, PHP_URL_HOST);
        goto E0iXj;
        hMpbS:
        ++$iZJLy;
        goto ODml9;
        OCZMO:
        $IIxqH = [];
        goto HEvdg;
        q5KXu:
        $this->oVe7o->mIrarJhaP0j()->mRBZ72cnJM7($I0nMz);
        goto G1jug;
        E0iXj:
        $nGV_C = 'https://' . $iOwmw . '/' . ltrim($cJV8L, '/');
        goto R5A33;
        ATZXl:
        $cJV8L = parse_url($yGB2u, PHP_URL_PATH);
        goto RC51g;
        xvr2U:
        $I0nMz = $TxsWN->filename;
        goto q5KXu;
        eniK0:
    }
    public function mdqqx89d2D7() : void
    {
        goto mBrMC;
        mBrMC:
        $TxsWN = $this->oVe7o->mIrarJhaP0j();
        goto QXMQl;
        bCAJ3:
        $this->iAAqk->deleteDirectory(self::$svNEn . $I0nMz);
        goto GfnPB;
        QXMQl:
        $I0nMz = $TxsWN->LwfXc;
        goto bCAJ3;
        GfnPB:
        $this->PrHIa->delete($this->oVe7o->mwL2ScZNW65());
        goto ej3fJ;
        ej3fJ:
    }
    public function mO5xHEz50iL() : void
    {
        goto M6LYP;
        M6LYP:
        $TxsWN = $this->oVe7o->mIrarJhaP0j();
        goto DAr7M;
        lA1re:
        throw new \Exception('Failed to set file permissions for stored image: ' . $Srdn7);
        goto l3qe8;
        T32NY:
        natsort($SMTet);
        goto Jb_pW;
        u2Mp7:
        Assert::eq(count($SMTet), $YnTza, 'The number of parts and checksums must match.');
        goto T32NY;
        wISJo:
        oDQNA:
        goto eTmM3;
        DG1Kp:
        $emLyC = self::$svNEn . $TxsWN->LwfXc;
        goto LLQuo;
        KF0YK:
        lryXP:
        goto R3WM1;
        y_wBD:
        if ($this->iAAqk->exists($iTwY1)) {
            goto lryXP;
        }
        goto ijXWY;
        eTmM3:
        foreach ($SMTet as $CWdub) {
            goto pRinz;
            pRinz:
            $TZDZz = $this->iAAqk->path($CWdub);
            goto WJXud;
            Gc5w_:
            fclose($enqV3);
            goto a75Sv;
            a75Sv:
            if (!(false === $JPonQ)) {
                goto f6jRy;
            }
            goto dDtRc;
            FCTRv:
            throw new VLsw4zWL0oGJH('A chunk file not existed: ' . $TZDZz);
            goto TuI9R;
            PQwbQ:
            $JPonQ = stream_copy_to_stream($enqV3, $auv6t);
            goto Gc5w_;
            EnnKA:
            f6jRy:
            goto bsMCU;
            ZfQUd:
            if (!(false === $enqV3)) {
                goto IXxId;
            }
            goto FCTRv;
            TuI9R:
            IXxId:
            goto PQwbQ;
            dDtRc:
            throw new VLsw4zWL0oGJH('A chunk file content can not copy: ' . $TZDZz);
            goto EnnKA;
            WJXud:
            $enqV3 = @fopen($TZDZz, 'rb');
            goto ZfQUd;
            bsMCU:
            S_mMR:
            goto ZG3aV;
            ZG3aV:
        }
        goto DrP3a;
        l3qe8:
        JIBpM:
        goto PIvGc;
        DrP3a:
        zrtia:
        goto BQOW2;
        EJ6F8:
        if (!(false === $auv6t)) {
            goto oDQNA;
        }
        goto lO1Hy;
        CVnZV:
        $SMTet = $this->iAAqk->files($emLyC);
        goto u2Mp7;
        DAr7M:
        $YnTza = $TxsWN->QULrr;
        goto DG1Kp;
        FmT3X:
        if (chmod($Srdn7, 0644)) {
            goto JIBpM;
        }
        goto VBw_h;
        Jb_pW:
        $iTwY1 = dirname($lFxmq);
        goto y_wBD;
        R3WM1:
        $vScAS = $this->iAAqk->path($lFxmq);
        goto zuFhj;
        AH2GC:
        $auv6t = @fopen($vScAS, 'wb');
        goto EJ6F8;
        lcbBm:
        $Srdn7 = $this->iAAqk->path($lFxmq);
        goto FmT3X;
        zuFhj:
        touch($vScAS);
        goto AH2GC;
        lO1Hy:
        throw new VLsw4zWL0oGJH('Local chunk can not merge file (can create file): ' . $vScAS);
        goto wISJo;
        LLQuo:
        $lFxmq = $this->oVe7o->getFile()->getLocation();
        goto CVnZV;
        VBw_h:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $Srdn7);
        goto lA1re;
        BQOW2:
        fclose($auv6t);
        goto lcbBm;
        ijXWY:
        $this->iAAqk->makeDirectory($iTwY1);
        goto KF0YK;
        PIvGc:
        $this->iAAqk->deleteDirectory($emLyC);
        goto f05Yi;
        f05Yi:
    }
}
