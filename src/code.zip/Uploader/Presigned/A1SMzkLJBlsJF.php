<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

interface A1SMzkLJBlsJF
{
    public function mR8YH6Ul9tS();
    public function mmZY5pVfPQx();
    public function mPGOyQEz4ld();
}
