<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use src\Uploader\Core\HU7bCai77CgrB;
use src\Uploader\Exception\AZPh1jcEIDfCC;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Exception\QUKmC67ivZ04D;
use src\Uploader\Exception\XCOswXJIkJ0Ex;
use src\Uploader\Presigned\IYgqj7b3EHs5P;
use Webmozart\Assert\Assert;
class FKw6Tf1KE1WQd implements IYgqj7b3EHs5P
{
    private $RkCAT;
    private $SiK3b;
    private $TDmz_;
    private $tVqMs;
    public function __construct(HU7bCai77CgrB $kmQTT, Filesystem $eX8wo, Filesystem $RustJ, string $FQWsT)
    {
        goto z3D2O;
        I1Tne:
        $this->SiK3b = $eX8wo;
        goto TJahB;
        z3D2O:
        $this->RkCAT = $kmQTT;
        goto I1Tne;
        GB3eP:
        $this->tVqMs = $FQWsT;
        goto kV074;
        TJahB:
        $this->TDmz_ = $RustJ;
        goto GB3eP;
        kV074:
    }
    public function mGzsNnTbqgx()
    {
        goto GVEHR;
        iHp3i:
        $this->RkCAT->mN5M3gzjZ92($vI41B);
        goto Rgswu;
        vE6Xr:
        ++$nX65E;
        goto wzxus;
        nxFH4:
        $this->TDmz_->put($this->RkCAT->mk8mOnWi1YG(), json_encode($this->RkCAT->mH4ZGE0jflN()->toArray()));
        goto vYTsA;
        Oehxz:
        $rjHqp = $Yr67i->getCommand('UploadPart', ['Bucket' => $this->tVqMs, 'Key' => $this->RkCAT->getFile()->getLocation(), 'UploadId' => $aJeqW['UploadId'], 'PartNumber' => $nX65E]);
        goto liFoU;
        wb6fm:
        $izYGq = ceil($rEWu2->dXNxw / $rEWu2->I5jem);
        goto VCeCf;
        SceVu:
        $nX65E = 1;
        goto Qmht4;
        n0a1x:
        $vI41B[] = ['index' => $nX65E, 'url' => (string) $hfZR1->getUri()];
        goto gdGRx;
        Ux3d3:
        F5uiT:
        goto SceVu;
        KSddL:
        $this->SiK3b->put($this->RkCAT->mk8mOnWi1YG(), json_encode($this->RkCAT->mH4ZGE0jflN()->toArray()));
        goto nxFH4;
        wzxus:
        goto FTh0M;
        goto yPfoW;
        yPfoW:
        DSapD:
        goto iHp3i;
        PCG14:
        throw new QUKmC67ivZ04D("Failed to create multipart upload for file {$this->RkCAT->getFile()->getFilename()}, S3 return empty response");
        goto Ux3d3;
        LJmNh:
        $aJeqW = $Yr67i->createMultipartUpload(['Bucket' => $this->tVqMs, 'Key' => $this->RkCAT->getFile()->getLocation(), 'ContentType' => $this->RkCAT->mH4ZGE0jflN()->G1PGO, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto doRvw;
        doRvw:
        if (!(0 === $aJeqW->count())) {
            goto F5uiT;
        }
        goto PCG14;
        SPqT3:
        $vI41B = [];
        goto wb6fm;
        liFoU:
        $hfZR1 = $Yr67i->createPresignedRequest($rjHqp, '+1 day');
        goto n0a1x;
        GVEHR:
        $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
        goto SPqT3;
        gdGRx:
        LygLl:
        goto vE6Xr;
        Qmht4:
        FTh0M:
        goto ZE4CL;
        VCeCf:
        $Yr67i = $this->TDmz_->getClient();
        goto LJmNh;
        Rgswu:
        $this->RkCAT->mH4ZGE0jflN()->mrkxryvGEcX($aJeqW['UploadId']);
        goto KSddL;
        ZE4CL:
        if (!($nX65E <= $izYGq)) {
            goto DSapD;
        }
        goto Oehxz;
        vYTsA:
    }
    public function mI5hbVUBG4S() : void
    {
        goto gzfGY;
        gzfGY:
        $Yr67i = $this->TDmz_->getClient();
        goto xGRkW;
        xGRkW:
        try {
            $Yr67i->abortMultipartUpload(['Bucket' => $this->tVqMs, 'Key' => $this->RkCAT->getFile()->getLocation(), 'UploadId' => $this->RkCAT->mH4ZGE0jflN()->hNgeS]);
        } catch (\Throwable $lrm5K) {
            throw new AZPh1jcEIDfCC("Failed to abort multipart upload of file {$this->RkCAT->getFile()->getFilename()}", 0, $lrm5K);
        }
        goto XRSHX;
        bBg0G:
        $this->TDmz_->delete($this->RkCAT->mk8mOnWi1YG());
        goto fW2_8;
        XRSHX:
        $this->SiK3b->delete($this->RkCAT->mk8mOnWi1YG());
        goto bBg0G;
        fW2_8:
    }
    public function ml4R7rGsjxd() : void
    {
        goto HeK4N;
        ydUHj:
        $CNTHN = $rEWu2->blHu4;
        goto fMba2;
        SVYYD:
        foreach ($CNTHN as $AxmJQ) {
            goto KWRvE;
            KWRvE:
            $ZD3HH = $AxmJQ['partNumber'];
            goto L6Hdl;
            nMaQk:
            throw new XCOswXJIkJ0Ex("Checksum mismatch for part {$ZD3HH} of file {$this->RkCAT->getFile()->getFilename()}");
            goto pRCbG;
            ZnnCh:
            if (!($TNZJa['eTag'] !== $AxmJQ['eTag'])) {
                goto HXNpu;
            }
            goto nMaQk;
            pRCbG:
            HXNpu:
            goto gsDh0;
            gsDh0:
            W1_Z9:
            goto u13Fa;
            L6Hdl:
            $TNZJa = $M3yD9[$ZD3HH];
            goto ZnnCh;
            u13Fa:
        }
        goto TRsgT;
        TRsgT:
        b6r_Y:
        goto bvj72;
        EgsO0:
        try {
            $Yr67i->completeMultipartUpload(['Bucket' => $this->tVqMs, 'Key' => $this->RkCAT->getFile()->getLocation(), 'UploadId' => $this->RkCAT->mH4ZGE0jflN()->hNgeS, 'MultipartUpload' => ['Parts' => collect($this->RkCAT->mH4ZGE0jflN()->Kp54_)->sortBy('partNumber')->map(fn($TNZJa) => ['ETag' => $TNZJa['eTag'], 'PartNumber' => $TNZJa['partNumber']])->toArray()]]);
        } catch (\Throwable $lrm5K) {
            throw new XCOswXJIkJ0Ex("Failed to merge chunks of file {$this->RkCAT->getFile()->getFilename()}", 0, $lrm5K);
        }
        goto Pxjd3;
        HeK4N:
        $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
        goto xICCN;
        veU1d:
        $M3yD9 = collect($qj0o5)->keyBy('partNumber');
        goto SVYYD;
        xICCN:
        $qj0o5 = $rEWu2->Kp54_;
        goto ydUHj;
        fMba2:
        Assert::eq(count($qj0o5), count($CNTHN), 'The number of parts and checksums must match.');
        goto veU1d;
        bvj72:
        $Yr67i = $this->TDmz_->getClient();
        goto EgsO0;
        Pxjd3:
    }
}
