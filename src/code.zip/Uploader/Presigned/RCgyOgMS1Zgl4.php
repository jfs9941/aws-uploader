<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Y96dk3g6dPmcf;
use Jfs\Uploader\Exception\N7nRJ0hgKtASw;
use Jfs\Uploader\Exception\Iz97XtnhFWG8z;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Jfs\Uploader\Exception\WssSud2Fd6gDV;
use Webmozart\Assert\Assert;
class RCgyOgMS1Zgl4 implements QsAeGSwzIgbhx
{
    private $yVhDF;
    private $VFHFZ;
    private $NP9R0;
    private $DK2hf;
    public function __construct(Y96dk3g6dPmcf $lIPqb, Filesystem $dOL2I, Filesystem $TLVVj, string $TyFPC)
    {
        goto kKzE1;
        kKzE1:
        $this->yVhDF = $lIPqb;
        goto w6SZp;
        tK01y:
        $this->DK2hf = $TyFPC;
        goto YMA5B;
        zC649:
        $this->NP9R0 = $TLVVj;
        goto tK01y;
        w6SZp:
        $this->VFHFZ = $dOL2I;
        goto zC649;
        YMA5B:
    }
    public function mPEms69EA0A()
    {
        goto ej5HO;
        INTSd:
        $KmwCR = $ZH2Pc->getCommand('UploadPart', ['Bucket' => $this->DK2hf, 'Key' => $this->yVhDF->getFile()->getLocation(), 'UploadId' => $paaTe['UploadId'], 'PartNumber' => $sBfQi]);
        goto GDFsB;
        A8SRA:
        $this->yVhDF->mmWA2B9zVkK()->moWcWcx9wMl($paaTe['UploadId']);
        goto RuXc_;
        smN6v:
        $NiTPl[] = ['index' => $sBfQi, 'url' => (string) $zW12m->getUri()];
        goto zMHOE;
        yrlDw:
        $NiTPl = [];
        goto cyDUK;
        o7Bk3:
        if (!(0 === $paaTe->count())) {
            goto npr8R;
        }
        goto Y8edo;
        llvkX:
        $ZH2Pc = $this->NP9R0->getClient();
        goto Ieykb;
        zMHOE:
        pZ63y:
        goto wvDBT;
        x1x31:
        if (!($sBfQi <= $HqM7F)) {
            goto cj2ap;
        }
        goto INTSd;
        D9QfA:
        $this->NP9R0->put($this->yVhDF->mEfGPqiyn18(), json_encode($this->yVhDF->mmWA2B9zVkK()->toArray()));
        goto W4tLw;
        Ieykb:
        $paaTe = $ZH2Pc->createMultipartUpload(['Bucket' => $this->DK2hf, 'Key' => $this->yVhDF->getFile()->getLocation(), 'ContentType' => $this->yVhDF->mmWA2B9zVkK()->XovbP, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto o7Bk3;
        l6Tdw:
        goto A3aJ_;
        goto JzVJM;
        cyDUK:
        $HqM7F = ceil($ag5JI->u1hlj / $ag5JI->EAzFa);
        goto llvkX;
        Ojdbb:
        A3aJ_:
        goto x1x31;
        Od8Zd:
        $sBfQi = 1;
        goto Ojdbb;
        Y8edo:
        throw new WssSud2Fd6gDV("Failed to create multipart upload for file {$this->yVhDF->getFile()->getFilename()}, S3 return empty response");
        goto Z6cC6;
        qHpBj:
        $this->yVhDF->mfc4hqnAzmE($NiTPl);
        goto A8SRA;
        ej5HO:
        $ag5JI = $this->yVhDF->mmWA2B9zVkK();
        goto yrlDw;
        RuXc_:
        $this->VFHFZ->put($this->yVhDF->mEfGPqiyn18(), json_encode($this->yVhDF->mmWA2B9zVkK()->toArray()));
        goto D9QfA;
        wvDBT:
        ++$sBfQi;
        goto l6Tdw;
        JzVJM:
        cj2ap:
        goto qHpBj;
        Z6cC6:
        npr8R:
        goto Od8Zd;
        GDFsB:
        $zW12m = $ZH2Pc->createPresignedRequest($KmwCR, '+1 day');
        goto smN6v;
        W4tLw:
    }
    public function mnpYdu0IZ9W() : void
    {
        goto ZJkCN;
        VKu_I:
        $this->NP9R0->delete($this->yVhDF->mEfGPqiyn18());
        goto Bpx1_;
        ZJkCN:
        $ZH2Pc = $this->NP9R0->getClient();
        goto nIqEo;
        BG7aR:
        $this->VFHFZ->delete($this->yVhDF->mEfGPqiyn18());
        goto VKu_I;
        nIqEo:
        try {
            $ZH2Pc->abortMultipartUpload(['Bucket' => $this->DK2hf, 'Key' => $this->yVhDF->getFile()->getLocation(), 'UploadId' => $this->yVhDF->mmWA2B9zVkK()->NDdad]);
        } catch (\Throwable $mz5ks) {
            throw new N7nRJ0hgKtASw("Failed to abort multipart upload of file {$this->yVhDF->getFile()->getFilename()}", 0, $mz5ks);
        }
        goto BG7aR;
        Bpx1_:
    }
    public function mqyBtnjUsU9() : void
    {
        goto XdcBn;
        J1HJA:
        Assert::eq(count($Zkrnk), count($bcSv0), 'The number of parts and checksums must match.');
        goto oUJyN;
        sF6JC:
        foreach ($bcSv0 as $F5keK) {
            goto Lj1iS;
            Lj1iS:
            $ChWfM = $F5keK['partNumber'];
            goto tv_da;
            J5aDk:
            oC1yA:
            goto irlxr;
            tv_da:
            $SozDT = $hjddI[$ChWfM];
            goto Il7VT;
            Il7VT:
            if (!($SozDT['eTag'] !== $F5keK['eTag'])) {
                goto oC1yA;
            }
            goto XPlO3;
            irlxr:
            Yk27c:
            goto XgifT;
            XPlO3:
            throw new Iz97XtnhFWG8z("Checksum mismatch for part {$ChWfM} of file {$this->yVhDF->getFile()->getFilename()}");
            goto J5aDk;
            XgifT:
        }
        goto Jv3V_;
        IPddD:
        $ZH2Pc = $this->NP9R0->getClient();
        goto rjU_J;
        xdlq1:
        $Zkrnk = $ag5JI->XwLtl;
        goto UAyey;
        XdcBn:
        $ag5JI = $this->yVhDF->mmWA2B9zVkK();
        goto xdlq1;
        rjU_J:
        try {
            $ZH2Pc->completeMultipartUpload(['Bucket' => $this->DK2hf, 'Key' => $this->yVhDF->getFile()->getLocation(), 'UploadId' => $this->yVhDF->mmWA2B9zVkK()->NDdad, 'MultipartUpload' => ['Parts' => collect($this->yVhDF->mmWA2B9zVkK()->XwLtl)->sortBy('partNumber')->map(fn($SozDT) => ['ETag' => $SozDT['eTag'], 'PartNumber' => $SozDT['partNumber']])->toArray()]]);
        } catch (\Throwable $mz5ks) {
            throw new Iz97XtnhFWG8z("Failed to merge chunks of file {$this->yVhDF->getFile()->getFilename()}", 0, $mz5ks);
        }
        goto ELZYW;
        Jv3V_:
        AXaKw:
        goto IPddD;
        UAyey:
        $bcSv0 = $ag5JI->H1t_A;
        goto J1HJA;
        oUJyN:
        $hjddI = collect($Zkrnk)->keyBy('partNumber');
        goto sF6JC;
        ELZYW:
    }
}
