<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\VX3gdl3bFyp5B;
use Jfs\Uploader\Exception\DggqAWJRlDYzw;
use Jfs\Uploader\Exception\HJ2NaMMJCY27q;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Jfs\Uploader\Exception\VdkKz4FgBf8FW;
use Webmozart\Assert\Assert;
class Grj67gsLukV22 implements RPMVlbeBF6oBq
{
    private $speJc;
    private $N3F9R;
    private $LmK5y;
    private $Jbhpc;
    public function __construct(VX3gdl3bFyp5B $KnLpk, Filesystem $mFX9i, Filesystem $ExTI3, string $A745z)
    {
        goto sZ_zy;
        sZ_zy:
        $this->speJc = $KnLpk;
        goto gpc56;
        UGrMS:
        $this->LmK5y = $ExTI3;
        goto MhoXi;
        gpc56:
        $this->N3F9R = $mFX9i;
        goto UGrMS;
        MhoXi:
        $this->Jbhpc = $A745z;
        goto UjvHR;
        UjvHR:
    }
    public function m9UURmwWnW3()
    {
        goto OQpPU;
        a3wyO:
        ++$EP1lQ;
        goto qAUHe;
        IdNoq:
        $z5dDB = $nC_XV->getCommand('UploadPart', ['Bucket' => $this->Jbhpc, 'Key' => $this->speJc->getFile()->getLocation(), 'UploadId' => $gy2ea['UploadId'], 'PartNumber' => $EP1lQ]);
        goto cb86c;
        SgdLq:
        hYOJX:
        goto a3wyO;
        cb86c:
        $KHpOt = $nC_XV->createPresignedRequest($z5dDB, '+1 day');
        goto HfwYL;
        q3nWH:
        $jaUM6 = [];
        goto Sg1bj;
        OQpPU:
        $Ds24j = $this->speJc->mDwF61YxuNq();
        goto q3nWH;
        Sg1bj:
        $eB3WA = ceil($Ds24j->bGpro / $Ds24j->DR4yj);
        goto MuXFo;
        BsKo0:
        AfbLd:
        goto YDjN5;
        GIUk4:
        $this->speJc->mDwF61YxuNq()->mv3G4OVCmSr($gy2ea['UploadId']);
        goto ohQip;
        xkcwz:
        d9XLy:
        goto L5E2V;
        RmVey:
        L0WfQ:
        goto BV0xJ;
        YDjN5:
        $EP1lQ = 1;
        goto xkcwz;
        MuXFo:
        $nC_XV = $this->LmK5y->getClient();
        goto tOeeF;
        qAUHe:
        goto d9XLy;
        goto RmVey;
        tOeeF:
        $gy2ea = $nC_XV->createMultipartUpload(['Bucket' => $this->Jbhpc, 'Key' => $this->speJc->getFile()->getLocation(), 'ContentType' => $this->speJc->mDwF61YxuNq()->odzgM, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto FTYhm;
        BV0xJ:
        $this->speJc->mUEr22m4NIs($jaUM6);
        goto GIUk4;
        HfwYL:
        $jaUM6[] = ['index' => $EP1lQ, 'url' => (string) $KHpOt->getUri()];
        goto SgdLq;
        ohQip:
        $this->N3F9R->put($this->speJc->mn0D2cAVuAW(), json_encode($this->speJc->mDwF61YxuNq()->toArray()));
        goto jCRS8;
        rptRX:
        throw new VdkKz4FgBf8FW("Failed to create multipart upload for file {$this->speJc->getFile()->getFilename()}, S3 return empty response");
        goto BsKo0;
        jCRS8:
        $this->LmK5y->put($this->speJc->mn0D2cAVuAW(), json_encode($this->speJc->mDwF61YxuNq()->toArray()));
        goto Yhk7n;
        L5E2V:
        if (!($EP1lQ <= $eB3WA)) {
            goto L0WfQ;
        }
        goto IdNoq;
        FTYhm:
        if (!(0 === $gy2ea->count())) {
            goto AfbLd;
        }
        goto rptRX;
        Yhk7n:
    }
    public function muDP4BURVYw() : void
    {
        goto Sl805;
        h2N3W:
        try {
            $nC_XV->abortMultipartUpload(['Bucket' => $this->Jbhpc, 'Key' => $this->speJc->getFile()->getLocation(), 'UploadId' => $this->speJc->mDwF61YxuNq()->l9IH2]);
        } catch (\Throwable $ZkRqE) {
            throw new DggqAWJRlDYzw("Failed to abort multipart upload of file {$this->speJc->getFile()->getFilename()}", 0, $ZkRqE);
        }
        goto PV_52;
        Sl805:
        $nC_XV = $this->LmK5y->getClient();
        goto h2N3W;
        PV_52:
        $this->N3F9R->delete($this->speJc->mn0D2cAVuAW());
        goto YSXf0;
        YSXf0:
        $this->LmK5y->delete($this->speJc->mn0D2cAVuAW());
        goto uv3Wb;
        uv3Wb:
    }
    public function mYrguHH3ARB() : void
    {
        goto s8rXe;
        dAL8T:
        $tFMn9 = $Ds24j->XvCZF;
        goto ejuWo;
        ejuWo:
        $GuzHV = $Ds24j->Gr1_Z;
        goto eykwq;
        PyFWy:
        foreach ($GuzHV as $MjOdz) {
            goto RVSel;
            WopkX:
            throw new HJ2NaMMJCY27q("Checksum mismatch for part {$WHw0q} of file {$this->speJc->getFile()->getFilename()}");
            goto UaRgp;
            WlMVt:
            Wsl7_:
            goto Dn_fa;
            RVSel:
            $WHw0q = $MjOdz['partNumber'];
            goto pobDS;
            Fogft:
            if (!($GW31j['eTag'] !== $MjOdz['eTag'])) {
                goto DT8KP;
            }
            goto WopkX;
            pobDS:
            $GW31j = $djQ0i[$WHw0q];
            goto Fogft;
            UaRgp:
            DT8KP:
            goto WlMVt;
            Dn_fa:
        }
        goto lSmt5;
        sUVjE:
        $djQ0i = collect($tFMn9)->keyBy('partNumber');
        goto PyFWy;
        eykwq:
        Assert::eq(count($tFMn9), count($GuzHV), 'The number of parts and checksums must match.');
        goto sUVjE;
        s8rXe:
        $Ds24j = $this->speJc->mDwF61YxuNq();
        goto dAL8T;
        fyhtk:
        try {
            $nC_XV->completeMultipartUpload(['Bucket' => $this->Jbhpc, 'Key' => $this->speJc->getFile()->getLocation(), 'UploadId' => $this->speJc->mDwF61YxuNq()->l9IH2, 'MultipartUpload' => ['Parts' => collect($this->speJc->mDwF61YxuNq()->XvCZF)->sortBy('partNumber')->map(fn($GW31j) => ['ETag' => $GW31j['eTag'], 'PartNumber' => $GW31j['partNumber']])->toArray()]]);
        } catch (\Throwable $ZkRqE) {
            throw new HJ2NaMMJCY27q("Failed to merge chunks of file {$this->speJc->getFile()->getFilename()}", 0, $ZkRqE);
        }
        goto Mh0R5;
        gfKAe:
        $nC_XV = $this->LmK5y->getClient();
        goto fyhtk;
        lSmt5:
        bCYW6:
        goto gfKAe;
        Mh0R5:
    }
}
