<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\T1237kNnrvH7d;
use Jfs\Uploader\Exception\K1KuLvybHBBym;
use Jfs\Uploader\Exception\ZUCYJN8335T88;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Exception\EBolz1WkSGiMJ;
use Jfs\Uploader\Presigned\OELbHQiIMrHSQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class Vu57mjM1g6xEv implements OELbHQiIMrHSQ
{
    private $lituY;
    private $IaFSl;
    private $QO2Ul;
    private $SmbHD;
    public function __construct(T1237kNnrvH7d $IXO6X, Filesystem $B27Pk, Filesystem $YzAw4, string $l286D)
    {
        goto vIeil;
        ADjlU:
        $this->IaFSl = $B27Pk;
        goto NdGau;
        CaCO_:
        $this->SmbHD = $l286D;
        goto PIM2F;
        NdGau:
        $this->QO2Ul = $YzAw4;
        goto CaCO_;
        vIeil:
        $this->lituY = $IXO6X;
        goto ADjlU;
        PIM2F:
    }
    public function mq1QIPo5NbE()
    {
        goto dqHaS;
        lS4aj:
        if (!($jiZ6m <= $wfYO4)) {
            goto RyqOn;
        }
        goto RK2x0;
        rGlHS:
        RyqOn:
        goto KBc_J;
        Pg58i:
        Lc6TU:
        goto I7V6B;
        W6aKr:
        if (!(0 === $y0m_Q->count())) {
            goto Lc6TU;
        }
        goto hrKoL;
        Aacs8:
        ++$jiZ6m;
        goto BE2tu;
        BE2tu:
        goto Ey53p;
        goto rGlHS;
        RK2x0:
        $s2YBe = $NXlvU->getCommand('UploadPart', ['Bucket' => $this->SmbHD, 'Key' => $this->lituY->getFile()->getLocation(), 'UploadId' => $y0m_Q['UploadId'], 'PartNumber' => $jiZ6m]);
        goto PLJBK;
        ne1or:
        $this->QO2Ul->put($this->lituY->mwi5nmRyoKE(), json_encode($this->lituY->m20XUNl7Aaq()->toArray()));
        goto O2muw;
        CJ0O6:
        $this->lituY->m20XUNl7Aaq()->mGzbykTgjHh($y0m_Q['UploadId']);
        goto lx6BZ;
        v5GYX:
        Ey53p:
        goto lS4aj;
        jsK28:
        $wfYO4 = ceil($vOZNn->QhLmd / $vOZNn->HAyU7);
        goto lmb3_;
        Gsxkq:
        SY767:
        goto Aacs8;
        lx6BZ:
        $this->IaFSl->put($this->lituY->mwi5nmRyoKE(), json_encode($this->lituY->m20XUNl7Aaq()->toArray()));
        goto ne1or;
        KBc_J:
        $this->lituY->mt7T9zPbtAi($kRlEI);
        goto CJ0O6;
        I7V6B:
        $jiZ6m = 1;
        goto v5GYX;
        iFQqJ:
        $kRlEI[] = ['index' => $jiZ6m, 'url' => (string) $B61lN->getUri()];
        goto Gsxkq;
        hrKoL:
        throw new EBolz1WkSGiMJ("Failed to create multipart upload for file {$this->lituY->getFile()->getFilename()}, S3 return empty response");
        goto Pg58i;
        uh56I:
        $kRlEI = [];
        goto jsK28;
        lYq1f:
        $y0m_Q = $NXlvU->createMultipartUpload(['Bucket' => $this->SmbHD, 'Key' => $this->lituY->getFile()->getLocation(), 'ContentType' => $this->lituY->m20XUNl7Aaq()->cjAQL, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto W6aKr;
        lmb3_:
        $NXlvU = $this->QO2Ul->getClient();
        goto lYq1f;
        dqHaS:
        $vOZNn = $this->lituY->m20XUNl7Aaq();
        goto uh56I;
        PLJBK:
        $B61lN = $NXlvU->createPresignedRequest($s2YBe, '+1 day');
        goto iFQqJ;
        O2muw:
    }
    public function miOIHr1YHeY() : void
    {
        goto NhC0W;
        tV4dK:
        try {
            $NXlvU->abortMultipartUpload(['Bucket' => $this->SmbHD, 'Key' => $this->lituY->getFile()->getLocation(), 'UploadId' => $this->lituY->m20XUNl7Aaq()->JI6i6]);
        } catch (\Throwable $vR5RQ) {
            throw new K1KuLvybHBBym("Failed to abort multipart upload of file {$this->lituY->getFile()->getFilename()}", 0, $vR5RQ);
        }
        goto XD_rJ;
        XD_rJ:
        $this->IaFSl->delete($this->lituY->mwi5nmRyoKE());
        goto V62xu;
        NhC0W:
        $NXlvU = $this->QO2Ul->getClient();
        goto tV4dK;
        V62xu:
        $this->QO2Ul->delete($this->lituY->mwi5nmRyoKE());
        goto TpIZE;
        TpIZE:
    }
    public function m1kTEjhiqBw() : void
    {
        goto uwCb3;
        iSDcO:
        S46t9:
        goto QH6i_;
        BmeTz:
        $YXgxQ = $vOZNn->O3Nrl;
        goto DrWfG;
        QC45V:
        foreach ($hWt8D as $Car5C) {
            goto rbF1W;
            f8MbX:
            sShKC:
            goto xGGxV;
            wxGNI:
            $MKe7f = $xpbF3[$be056];
            goto Rry4Y;
            Rry4Y:
            if (!($MKe7f['eTag'] !== $Car5C['eTag'])) {
                goto sShKC;
            }
            goto D18kO;
            rbF1W:
            $be056 = $Car5C['partNumber'];
            goto wxGNI;
            D18kO:
            throw new ZUCYJN8335T88("Checksum mismatch for part {$be056} of file {$this->lituY->getFile()->getFilename()}");
            goto f8MbX;
            xGGxV:
            PbomG:
            goto U4hYS;
            U4hYS:
        }
        goto iSDcO;
        DrWfG:
        $hWt8D = $vOZNn->ndGcb;
        goto K0QMK;
        K0QMK:
        Assert::eq(count($YXgxQ), count($hWt8D), 'The number of parts and checksums must match.');
        goto pzv_f;
        pzv_f:
        $xpbF3 = collect($YXgxQ)->keyBy('partNumber');
        goto QC45V;
        uwCb3:
        $vOZNn = $this->lituY->m20XUNl7Aaq();
        goto BmeTz;
        QH6i_:
        $NXlvU = $this->QO2Ul->getClient();
        goto yPMBz;
        yPMBz:
        try {
            $NXlvU->completeMultipartUpload(['Bucket' => $this->SmbHD, 'Key' => $this->lituY->getFile()->getLocation(), 'UploadId' => $this->lituY->m20XUNl7Aaq()->JI6i6, 'MultipartUpload' => ['Parts' => collect($this->lituY->m20XUNl7Aaq()->O3Nrl)->sortBy('partNumber')->map(fn($MKe7f) => ['ETag' => $MKe7f['eTag'], 'PartNumber' => $MKe7f['partNumber']])->toArray()]]);
        } catch (\Throwable $vR5RQ) {
            throw new ZUCYJN8335T88("Failed to merge chunks of file {$this->lituY->getFile()->getFilename()}", 0, $vR5RQ);
        }
        goto s2IuS;
        s2IuS:
    }
}
