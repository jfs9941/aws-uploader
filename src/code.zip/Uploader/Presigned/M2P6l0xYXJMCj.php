<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\ZV4T54pWWCYdf;
use Jfs\Uploader\Exception\PuDFLOEVAkvUs;
use Jfs\Uploader\Exception\QzinLBl9CLzxV;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Exception\SbSI1zF3HE3hq;
use Jfs\Uploader\Presigned\D3WOtooSgtsIM;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class M2P6l0xYXJMCj implements D3WOtooSgtsIM
{
    private $fl_Nu;
    private $h0iwI;
    private $o9xvH;
    private $VwfNm;
    public function __construct(ZV4T54pWWCYdf $EZ04_, Filesystem $jxMWP, Filesystem $ft7kk, string $XbR1L)
    {
        goto tZWLd;
        jzQlK:
        $this->h0iwI = $jxMWP;
        goto xd1Nj;
        iabuf:
        $this->VwfNm = $XbR1L;
        goto R7jK_;
        xd1Nj:
        $this->o9xvH = $ft7kk;
        goto iabuf;
        tZWLd:
        $this->fl_Nu = $EZ04_;
        goto jzQlK;
        R7jK_:
    }
    public function mVNXsVqeTEd()
    {
        goto Y4iVu;
        J7u4k:
        $kv_XK = ceil($V5lrw->qVkMu / $V5lrw->wuhof);
        goto dy40c;
        Um7e4:
        $this->fl_Nu->mSViQFIwKkL()->m3wuWcoEsff($hd6J3['UploadId']);
        goto Gt9dY;
        Ze5G4:
        $c3PUV = $dbHTm->getCommand('UploadPart', ['Bucket' => $this->VwfNm, 'Key' => $this->fl_Nu->getFile()->getLocation(), 'UploadId' => $hd6J3['UploadId'], 'PartNumber' => $HsMA6]);
        goto Oux7h;
        veeRU:
        $this->o9xvH->put($this->fl_Nu->mnTIDh8qJQQ(), json_encode($this->fl_Nu->mSViQFIwKkL()->toArray()));
        goto rhsr6;
        JApbx:
        $Qa2v1[] = ['index' => $HsMA6, 'url' => (string) $MsSdU->getUri()];
        goto b193y;
        qcCy9:
        if (!($HsMA6 <= $kv_XK)) {
            goto GZTnm;
        }
        goto Ze5G4;
        Vv34u:
        if (!(0 === $hd6J3->count())) {
            goto qIg7s;
        }
        goto bFpIo;
        xofgz:
        MjIba:
        goto qcCy9;
        b193y:
        gryZ0:
        goto aTaOI;
        K9PVY:
        $HsMA6 = 1;
        goto xofgz;
        gg4yj:
        qIg7s:
        goto K9PVY;
        ssajD:
        $hd6J3 = $dbHTm->createMultipartUpload(['Bucket' => $this->VwfNm, 'Key' => $this->fl_Nu->getFile()->getLocation(), 'ContentType' => $this->fl_Nu->mSViQFIwKkL()->nL0uY, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto Vv34u;
        bFpIo:
        throw new SbSI1zF3HE3hq("Failed to create multipart upload for file {$this->fl_Nu->getFile()->getFilename()}, S3 return empty response");
        goto gg4yj;
        y3SPn:
        $this->fl_Nu->m8J20ggo7Cc($Qa2v1);
        goto Um7e4;
        U10Hn:
        $Qa2v1 = [];
        goto J7u4k;
        Gt9dY:
        $this->h0iwI->put($this->fl_Nu->mnTIDh8qJQQ(), json_encode($this->fl_Nu->mSViQFIwKkL()->toArray()));
        goto veeRU;
        aTaOI:
        ++$HsMA6;
        goto MAFYm;
        MAFYm:
        goto MjIba;
        goto s5cwL;
        dy40c:
        $dbHTm = $this->o9xvH->getClient();
        goto ssajD;
        s5cwL:
        GZTnm:
        goto y3SPn;
        Y4iVu:
        $V5lrw = $this->fl_Nu->mSViQFIwKkL();
        goto U10Hn;
        Oux7h:
        $MsSdU = $dbHTm->createPresignedRequest($c3PUV, '+1 day');
        goto JApbx;
        rhsr6:
    }
    public function ma5c6dbi8Bh() : void
    {
        goto Xi8RL;
        h8dSL:
        $this->o9xvH->delete($this->fl_Nu->mnTIDh8qJQQ());
        goto SCuLo;
        Xi8RL:
        $dbHTm = $this->o9xvH->getClient();
        goto waKVb;
        rr1vW:
        $this->h0iwI->delete($this->fl_Nu->mnTIDh8qJQQ());
        goto h8dSL;
        waKVb:
        try {
            $dbHTm->abortMultipartUpload(['Bucket' => $this->VwfNm, 'Key' => $this->fl_Nu->getFile()->getLocation(), 'UploadId' => $this->fl_Nu->mSViQFIwKkL()->ZiXeF]);
        } catch (\Throwable $OaHp2) {
            throw new PuDFLOEVAkvUs("Failed to abort multipart upload of file {$this->fl_Nu->getFile()->getFilename()}", 0, $OaHp2);
        }
        goto rr1vW;
        SCuLo:
    }
    public function mUEzFn7SZiO() : void
    {
        goto MfqFW;
        MfqFW:
        $V5lrw = $this->fl_Nu->mSViQFIwKkL();
        goto ex1q3;
        ex1q3:
        $H1_VI = $V5lrw->ie343;
        goto TyEiQ;
        M1Pw4:
        $q6TEo = collect($H1_VI)->keyBy('partNumber');
        goto nLvaq;
        TyEiQ:
        $LVKMJ = $V5lrw->Xb0r9;
        goto drYce;
        un4s_:
        try {
            $dbHTm->completeMultipartUpload(['Bucket' => $this->VwfNm, 'Key' => $this->fl_Nu->getFile()->getLocation(), 'UploadId' => $this->fl_Nu->mSViQFIwKkL()->ZiXeF, 'MultipartUpload' => ['Parts' => collect($this->fl_Nu->mSViQFIwKkL()->ie343)->sortBy('partNumber')->map(fn($mlB7C) => ['ETag' => $mlB7C['eTag'], 'PartNumber' => $mlB7C['partNumber']])->toArray()]]);
        } catch (\Throwable $OaHp2) {
            throw new QzinLBl9CLzxV("Failed to merge chunks of file {$this->fl_Nu->getFile()->getFilename()}", 0, $OaHp2);
        }
        goto KAWmh;
        nLvaq:
        foreach ($LVKMJ as $aq5hN) {
            goto PabvU;
            fS40H:
            c4HTz:
            goto z9TN2;
            P0WmX:
            throw new QzinLBl9CLzxV("Checksum mismatch for part {$jpeco} of file {$this->fl_Nu->getFile()->getFilename()}");
            goto fS40H;
            bHyTw:
            $mlB7C = $q6TEo[$jpeco];
            goto MeFec;
            MeFec:
            if (!($mlB7C['eTag'] !== $aq5hN['eTag'])) {
                goto c4HTz;
            }
            goto P0WmX;
            z9TN2:
            o8D2b:
            goto n_xfW;
            PabvU:
            $jpeco = $aq5hN['partNumber'];
            goto bHyTw;
            n_xfW:
        }
        goto FRKYZ;
        drYce:
        Assert::eq(count($H1_VI), count($LVKMJ), 'The number of parts and checksums must match.');
        goto M1Pw4;
        tla3B:
        $dbHTm = $this->o9xvH->getClient();
        goto un4s_;
        FRKYZ:
        t_hFK:
        goto tla3B;
        KAWmh:
    }
}
