<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\T1237kNnrvH7d;
use Jfs\Uploader\Exception\ZUCYJN8335T88;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Presigned\OELbHQiIMrHSQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class JjXia9P5SW7Ks implements OELbHQiIMrHSQ
{
    private static $XVCX2 = 'chunks/';
    private $lituY;
    private $IaFSl;
    private $QO2Ul;
    public function __construct(T1237kNnrvH7d $IXO6X, Filesystem $B27Pk, Filesystem $YzAw4)
    {
        goto fNTIR;
        z4EXj:
        $this->IaFSl = $B27Pk;
        goto DcYP3;
        fNTIR:
        $this->lituY = $IXO6X;
        goto z4EXj;
        DcYP3:
        $this->QO2Ul = $YzAw4;
        goto dgrBT;
        dgrBT:
    }
    public function mq1QIPo5NbE() : void
    {
        goto FtoSl;
        FtoSl:
        $vOZNn = $this->lituY->m20XUNl7Aaq();
        goto GFFFp;
        e815_:
        dr4Md:
        goto EETTi;
        xhwfP:
        $wfYO4 = ceil($vOZNn->QhLmd / $vOZNn->HAyU7);
        goto F4RHY;
        F4RHY:
        $rrVeh = Uuid::v4()->toHex();
        goto Hwg8u;
        MnY3C:
        $this->lituY->m20XUNl7Aaq()->mGzbykTgjHh($rrVeh);
        goto jLpsd;
        GFFFp:
        $kRlEI = [];
        goto xhwfP;
        kplBg:
        goto pMEyk;
        goto e815_;
        EETTi:
        $this->lituY->mt7T9zPbtAi($kRlEI);
        goto MnY3C;
        v1TQ9:
        if (!($jiZ6m <= $wfYO4)) {
            goto dr4Md;
        }
        goto D5PKV;
        D5PKV:
        $kRlEI[] = ['index' => $jiZ6m, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $rrVeh, 'index' => $jiZ6m])];
        goto Ejjl1;
        u5Dxz:
        $jiZ6m = 1;
        goto r6ID4;
        MCL7j:
        ++$jiZ6m;
        goto kplBg;
        Ejjl1:
        yj_Ut:
        goto MCL7j;
        jLpsd:
        $this->IaFSl->put($this->lituY->mwi5nmRyoKE(), json_encode($this->lituY->m20XUNl7Aaq()->toArray()));
        goto HbeHd;
        HbeHd:
        $this->QO2Ul->put($this->lituY->mwi5nmRyoKE(), json_encode($this->lituY->m20XUNl7Aaq()->toArray()));
        goto G8l15;
        Hwg8u:
        $this->lituY->m20XUNl7Aaq()->mGzbykTgjHh($rrVeh);
        goto u5Dxz;
        r6ID4:
        pMEyk:
        goto v1TQ9;
        G8l15:
    }
    public function miOIHr1YHeY() : void
    {
        goto jpes0;
        jpes0:
        $vOZNn = $this->lituY->m20XUNl7Aaq();
        goto guFNg;
        xenwq:
        $this->QO2Ul->delete($this->lituY->mwi5nmRyoKE());
        goto rzkgA;
        guFNg:
        $rrVeh = $vOZNn->JI6i6;
        goto Z47uT;
        Z47uT:
        $this->IaFSl->deleteDirectory(self::$XVCX2 . $rrVeh);
        goto xenwq;
        rzkgA:
    }
    public function m1kTEjhiqBw() : void
    {
        goto zgu9L;
        TNNpx:
        $biNuX = self::$XVCX2 . $vOZNn->JI6i6;
        goto A5g_3;
        DmD9u:
        $eZ_aq = $this->IaFSl->path($JNSZD);
        goto PUYvC;
        Vvy4M:
        Assert::eq(count($gYL6Z), $wfYO4, 'The number of parts and checksums must match.');
        goto h1M5T;
        Sp7SC:
        if ($this->IaFSl->exists($LLyTB)) {
            goto C2Kmb;
        }
        goto M0jG0;
        nQlbF:
        lr2cs:
        goto oFqcC;
        eBrpU:
        zGvKc:
        goto p3mIk;
        ljp7Y:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $f0mV5);
        goto sjn2M;
        bDfMj:
        fclose($oqNwf);
        goto UE1bg;
        QzhyR:
        $wfYO4 = $vOZNn->KmLDC;
        goto TNNpx;
        UE1bg:
        $f0mV5 = $this->IaFSl->path($JNSZD);
        goto dr3YX;
        p3mIk:
        foreach ($gYL6Z as $WbCEn) {
            goto wTwRw;
            xxt4J:
            $HO4L_ = stream_copy_to_stream($igQ4x, $oqNwf);
            goto tpilF;
            DWkAU:
            throw new ZUCYJN8335T88('A chunk file not existed: ' . $zRU2c);
            goto Jnp1m;
            ANQa1:
            if (!(false === $HO4L_)) {
                goto o0nu2;
            }
            goto PFxxj;
            tpilF:
            fclose($igQ4x);
            goto ANQa1;
            eqYTG:
            $igQ4x = @fopen($zRU2c, 'rb');
            goto WtRr_;
            wTwRw:
            $zRU2c = $this->IaFSl->path($WbCEn);
            goto eqYTG;
            Jnp1m:
            T8WJ9:
            goto xxt4J;
            upOKo:
            QKe09:
            goto iI06e;
            WtRr_:
            if (!(false === $igQ4x)) {
                goto T8WJ9;
            }
            goto DWkAU;
            YVFmy:
            o0nu2:
            goto upOKo;
            PFxxj:
            throw new ZUCYJN8335T88('A chunk file content can not copy: ' . $zRU2c);
            goto YVFmy;
            iI06e:
        }
        goto DXZwG;
        dr3YX:
        if (chmod($f0mV5, 0644)) {
            goto lr2cs;
        }
        goto ljp7Y;
        sjn2M:
        throw new \Exception('Failed to set file permissions for stored image: ' . $f0mV5);
        goto nQlbF;
        A5g_3:
        $JNSZD = $this->lituY->getFile()->getLocation();
        goto PWvTD;
        h1M5T:
        natsort($gYL6Z);
        goto Obnup;
        PWvTD:
        $gYL6Z = $this->IaFSl->files($biNuX);
        goto Vvy4M;
        hqFEb:
        $oqNwf = @fopen($eZ_aq, 'wb');
        goto KnGBO;
        DXZwG:
        iRx_g:
        goto bDfMj;
        PUYvC:
        touch($eZ_aq);
        goto hqFEb;
        zgu9L:
        $vOZNn = $this->lituY->m20XUNl7Aaq();
        goto QzhyR;
        rmNEv:
        C2Kmb:
        goto DmD9u;
        oFqcC:
        $this->IaFSl->deleteDirectory($biNuX);
        goto A5HFB;
        M0jG0:
        $this->IaFSl->makeDirectory($LLyTB);
        goto rmNEv;
        cCj8S:
        throw new ZUCYJN8335T88('Local chunk can not merge file (can create file): ' . $eZ_aq);
        goto eBrpU;
        KnGBO:
        if (!(false === $oqNwf)) {
            goto zGvKc;
        }
        goto cCj8S;
        Obnup:
        $LLyTB = dirname($JNSZD);
        goto Sp7SC;
        A5HFB:
    }
}
