<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\TVInkZGE2Z8Ja;
use Jfs\Uploader\Exception\XeSDn5fv42UKx;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class EG6PFllhbS4O3 implements MdoDaYR0UPmor
{
    private static $rRSAd = 'chunks/';
    private $hpsHP;
    private $fodJQ;
    private $i9Sna;
    public function __construct(TVInkZGE2Z8Ja $y4PP7, Filesystem $nsgrL, Filesystem $moAxa)
    {
        goto V8l1I;
        YChlr:
        $this->i9Sna = $moAxa;
        goto BqlHk;
        V8l1I:
        $this->hpsHP = $y4PP7;
        goto WOAVh;
        WOAVh:
        $this->fodJQ = $nsgrL;
        goto YChlr;
        BqlHk:
    }
    public function mKjsNob7bmV() : void
    {
        goto mMDpt;
        mMDpt:
        $xf_XV = $this->hpsHP->mlnKeX4eawe();
        goto ZkXb2;
        CDU3C:
        ++$Jvwha;
        goto J0STn;
        CqL5f:
        $this->i9Sna->put($this->hpsHP->mQA9EIajGk2(), json_encode($this->hpsHP->mlnKeX4eawe()->toArray()));
        goto tsoBv;
        frSP7:
        $dZOow[] = ['index' => $Jvwha, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $MSFCE, 'index' => $Jvwha])];
        goto e9qQU;
        HKd0Q:
        J23Pa:
        goto L3J1g;
        lyvRr:
        $this->hpsHP->mqoCm0UM5Os($dZOow);
        goto dZiDk;
        L3J1g:
        if (!($Jvwha <= $cejfY)) {
            goto ire5F;
        }
        goto frSP7;
        kt4Jw:
        $this->fodJQ->put($this->hpsHP->mQA9EIajGk2(), json_encode($this->hpsHP->mlnKeX4eawe()->toArray()));
        goto CqL5f;
        zSnrr:
        $Jvwha = 1;
        goto HKd0Q;
        przbE:
        $cejfY = ceil($xf_XV->msg3v / $xf_XV->hHmny);
        goto HBh9_;
        HBh9_:
        $MSFCE = Uuid::v4()->toHex();
        goto RjWp8;
        RjWp8:
        $this->hpsHP->mlnKeX4eawe()->m1Z5hvqmFrV($MSFCE);
        goto zSnrr;
        e9qQU:
        iuxco:
        goto CDU3C;
        ZkXb2:
        $dZOow = [];
        goto przbE;
        FQWaR:
        ire5F:
        goto lyvRr;
        J0STn:
        goto J23Pa;
        goto FQWaR;
        dZiDk:
        $this->hpsHP->mlnKeX4eawe()->m1Z5hvqmFrV($MSFCE);
        goto kt4Jw;
        tsoBv:
    }
    public function msMWIkXUKbG() : void
    {
        goto K5c56;
        K8nW3:
        $MSFCE = $xf_XV->HkGuv;
        goto weF9m;
        K5c56:
        $xf_XV = $this->hpsHP->mlnKeX4eawe();
        goto K8nW3;
        rMbSM:
        $this->i9Sna->delete($this->hpsHP->mQA9EIajGk2());
        goto eHcHH;
        weF9m:
        $this->fodJQ->deleteDirectory(self::$rRSAd . $MSFCE);
        goto rMbSM;
        eHcHH:
    }
    public function mpcjuwrcLbZ() : void
    {
        goto bUkCX;
        MxPBc:
        M2B0S:
        goto bXXYL;
        C7B9r:
        if (chmod($h1aZp, 0644)) {
            goto MpHoy;
        }
        goto TbrLn;
        L8lG5:
        $fTUbc = dirname($lJaNX);
        goto ASbw0;
        j8R14:
        $this->fodJQ->deleteDirectory($GjP8k);
        goto b0Tup;
        bXXYL:
        fclose($M36BI);
        goto zXG3L;
        ASbw0:
        if ($this->fodJQ->exists($fTUbc)) {
            goto Y3Xr2;
        }
        goto GKORE;
        cmEGW:
        throw new XeSDn5fv42UKx('Local chunk can not merge file (can create file): ' . $zt2iE);
        goto U0Nj1;
        XDjBi:
        $cejfY = $xf_XV->wgp7g;
        goto tKjTk;
        TbrLn:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $h1aZp);
        goto T3zq5;
        RzGFC:
        Assert::eq(count($fkSAd), $cejfY, 'The number of parts and checksums must match.');
        goto kOmVD;
        U0Nj1:
        HXY62:
        goto n9BIS;
        BiltT:
        $fkSAd = $this->fodJQ->files($GjP8k);
        goto RzGFC;
        ZMLKT:
        $lJaNX = $this->hpsHP->getFile()->getLocation();
        goto BiltT;
        I6J2g:
        touch($zt2iE);
        goto kuAeV;
        gt5r3:
        $zt2iE = $this->fodJQ->path($lJaNX);
        goto I6J2g;
        n9BIS:
        foreach ($fkSAd as $bZmt2) {
            goto kDRJ8;
            u5WQh:
            if (!(false === $O31vS)) {
                goto pF6hC;
            }
            goto MnS0n;
            Kctmz:
            throw new XeSDn5fv42UKx('A chunk file content can not copy: ' . $PjSej);
            goto j2Q7w;
            R0bA6:
            pF6hC:
            goto WpjcJ;
            Mswiq:
            $O31vS = @fopen($PjSej, 'rb');
            goto u5WQh;
            j2Q7w:
            C0f6Q:
            goto GKy0k;
            hU01g:
            if (!(false === $cfgGs)) {
                goto C0f6Q;
            }
            goto Kctmz;
            ZesOf:
            fclose($O31vS);
            goto hU01g;
            MnS0n:
            throw new XeSDn5fv42UKx('A chunk file not existed: ' . $PjSej);
            goto R0bA6;
            GKy0k:
            ERKgQ:
            goto c0rWp;
            kDRJ8:
            $PjSej = $this->fodJQ->path($bZmt2);
            goto Mswiq;
            WpjcJ:
            $cfgGs = stream_copy_to_stream($O31vS, $M36BI);
            goto ZesOf;
            c0rWp:
        }
        goto MxPBc;
        tKjTk:
        $GjP8k = self::$rRSAd . $xf_XV->HkGuv;
        goto ZMLKT;
        eygTI:
        if (!(false === $M36BI)) {
            goto HXY62;
        }
        goto cmEGW;
        kOmVD:
        natsort($fkSAd);
        goto L8lG5;
        zXG3L:
        $h1aZp = $this->fodJQ->path($lJaNX);
        goto C7B9r;
        GKORE:
        $this->fodJQ->makeDirectory($fTUbc);
        goto g3YTH;
        g3YTH:
        Y3Xr2:
        goto gt5r3;
        kuAeV:
        $M36BI = @fopen($zt2iE, 'wb');
        goto eygTI;
        Yn8fh:
        MpHoy:
        goto j8R14;
        T3zq5:
        throw new \Exception('Failed to set file permissions for stored image: ' . $h1aZp);
        goto Yn8fh;
        bUkCX:
        $xf_XV = $this->hpsHP->mlnKeX4eawe();
        goto XDjBi;
        b0Tup:
    }
}
