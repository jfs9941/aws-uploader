<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\Wa740mKVvCN9d;
use Jfs\Uploader\Exception\UG3Plh0htUmWz;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Presigned\A1SMzkLJBlsJF;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class MBDc0ezSNOIGe implements A1SMzkLJBlsJF
{
    private static $P3An1 = 'chunks/';
    private $F1L0c;
    private $niO3l;
    private $aplH5;
    public function __construct(Wa740mKVvCN9d $QJo2h, Filesystem $xuow1, Filesystem $C82jg)
    {
        goto vOlQC;
        vOlQC:
        $this->F1L0c = $QJo2h;
        goto SHY8a;
        c67WA:
        $this->aplH5 = $C82jg;
        goto QgM6i;
        SHY8a:
        $this->niO3l = $xuow1;
        goto c67WA;
        QgM6i:
    }
    public function mR8YH6Ul9tS() : void
    {
        goto BWWyE;
        KJfAT:
        $this->F1L0c->mBE2ZEQSaNO()->m74QFmAnqWV($ARG0J);
        goto FJru8;
        e_3y3:
        qbTXw:
        goto N3IP7;
        BWWyE:
        $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
        goto giTsO;
        Du5E5:
        $this->F1L0c->mBE2ZEQSaNO()->m74QFmAnqWV($ARG0J);
        goto ZtAt3;
        yYpos:
        $ARG0J = Uuid::v4()->toHex();
        goto KJfAT;
        FJru8:
        $xDfl8 = 1;
        goto rYdaY;
        giTsO:
        $LZ2fC = [];
        goto ypTy9;
        rTl4P:
        $LZ2fC[] = ['index' => $xDfl8, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $ARG0J, 'index' => $xDfl8])];
        goto ZqocH;
        ZtAt3:
        $this->niO3l->put($this->F1L0c->mYTaPK60wfh(), json_encode($this->F1L0c->mBE2ZEQSaNO()->toArray()));
        goto ikIhy;
        ikIhy:
        $this->aplH5->put($this->F1L0c->mYTaPK60wfh(), json_encode($this->F1L0c->mBE2ZEQSaNO()->toArray()));
        goto G96vS;
        lI4vk:
        ++$xDfl8;
        goto UCmso;
        ZqocH:
        A0GTz:
        goto lI4vk;
        rYdaY:
        ihIzk:
        goto mVC_z;
        UCmso:
        goto ihIzk;
        goto e_3y3;
        mVC_z:
        if (!($xDfl8 <= $dkYsv)) {
            goto qbTXw;
        }
        goto rTl4P;
        ypTy9:
        $dkYsv = ceil($ZTJaQ->n0Dq1 / $ZTJaQ->x1m41);
        goto yYpos;
        N3IP7:
        $this->F1L0c->miZvF1lrUqz($LZ2fC);
        goto Du5E5;
        G96vS:
    }
    public function mmZY5pVfPQx() : void
    {
        goto N_Ze6;
        N_Ze6:
        $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
        goto fr4sq;
        fQmsd:
        $this->niO3l->deleteDirectory(self::$P3An1 . $ARG0J);
        goto qwnKb;
        fr4sq:
        $ARG0J = $ZTJaQ->fTWbE;
        goto fQmsd;
        qwnKb:
        $this->aplH5->delete($this->F1L0c->mYTaPK60wfh());
        goto Y4OdN;
        Y4OdN:
    }
    public function mPGOyQEz4ld() : void
    {
        goto Hr9U3;
        hTsM_:
        if (chmod($oo9Nb, 0644)) {
            goto OD06c;
        }
        goto LoKBX;
        o6g5y:
        $s2fNG = $this->niO3l->files($lVqFt);
        goto LUyUt;
        hJ5KX:
        natsort($s2fNG);
        goto p07fB;
        an0mo:
        $this->niO3l->makeDirectory($iuAwU);
        goto XdzdI;
        LoKBX:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $oo9Nb);
        goto lWpbh;
        ijnJC:
        $oo9Nb = $this->niO3l->path($uEGP9);
        goto hTsM_;
        cNG8L:
        $VpIJD = @fopen($L7QFy, 'wb');
        goto Kwrpi;
        fqRtR:
        throw new UG3Plh0htUmWz('Local chunk can not merge file (can create file): ' . $L7QFy);
        goto t0GmB;
        xXqKK:
        if ($this->niO3l->exists($iuAwU)) {
            goto UWUNL;
        }
        goto an0mo;
        Kwrpi:
        if (!(false === $VpIJD)) {
            goto tAmV3;
        }
        goto fqRtR;
        qcR4x:
        touch($L7QFy);
        goto cNG8L;
        p0DjZ:
        foreach ($s2fNG as $DubqN) {
            goto H1_TH;
            c0y9O:
            throw new UG3Plh0htUmWz('A chunk file content can not copy: ' . $MQUNe);
            goto ySpW9;
            f7YW_:
            throw new UG3Plh0htUmWz('A chunk file not existed: ' . $MQUNe);
            goto C85gz;
            SEQud:
            if (!(false === $tZEOn)) {
                goto PFkjo;
            }
            goto f7YW_;
            kVMLX:
            $EyoKJ = stream_copy_to_stream($tZEOn, $VpIJD);
            goto RyrDI;
            RyrDI:
            fclose($tZEOn);
            goto Kiayr;
            jOUBA:
            LsjRr:
            goto bPkq7;
            KEeKH:
            $tZEOn = @fopen($MQUNe, 'rb');
            goto SEQud;
            ySpW9:
            KZMM6:
            goto jOUBA;
            Kiayr:
            if (!(false === $EyoKJ)) {
                goto KZMM6;
            }
            goto c0y9O;
            H1_TH:
            $MQUNe = $this->niO3l->path($DubqN);
            goto KEeKH;
            C85gz:
            PFkjo:
            goto kVMLX;
            bPkq7:
        }
        goto glvxl;
        p07fB:
        $iuAwU = dirname($uEGP9);
        goto xXqKK;
        wFdQS:
        $L7QFy = $this->niO3l->path($uEGP9);
        goto qcR4x;
        D0IZE:
        $lVqFt = self::$P3An1 . $ZTJaQ->fTWbE;
        goto iqf3k;
        lWpbh:
        throw new \Exception('Failed to set file permissions for stored image: ' . $oo9Nb);
        goto PUKeV;
        teqXk:
        $dkYsv = $ZTJaQ->ShsPv;
        goto D0IZE;
        f39g9:
        fclose($VpIJD);
        goto ijnJC;
        iqf3k:
        $uEGP9 = $this->F1L0c->getFile()->getLocation();
        goto o6g5y;
        glvxl:
        aznv6:
        goto f39g9;
        XdzdI:
        UWUNL:
        goto wFdQS;
        Tlb1v:
        $this->niO3l->deleteDirectory($lVqFt);
        goto GSmxO;
        t0GmB:
        tAmV3:
        goto p0DjZ;
        LUyUt:
        Assert::eq(count($s2fNG), $dkYsv, 'The number of parts and checksums must match.');
        goto hJ5KX;
        Hr9U3:
        $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
        goto teqXk;
        PUKeV:
        OD06c:
        goto Tlb1v;
        GSmxO:
    }
}
