<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\NfmgXUF97Fg3H;
use Jfs\Uploader\Exception\FkF89X2F8xBt8;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Presigned\PnE0ypHyhXJqc;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class F00t7QHnGzEry implements PnE0ypHyhXJqc
{
    private static $t9cho = 'chunks/';
    private $M2ERX;
    private $GUhIK;
    private $bBnq9;
    public function __construct(NfmgXUF97Fg3H $TtzPI, Filesystem $kGo1c, Filesystem $k6y5k)
    {
        goto ZK0Xm;
        Cr7rt:
        $this->bBnq9 = $k6y5k;
        goto d2beZ;
        TZQGE:
        $this->GUhIK = $kGo1c;
        goto Cr7rt;
        ZK0Xm:
        $this->M2ERX = $TtzPI;
        goto TZQGE;
        d2beZ:
    }
    public function mIiANiKKpuc() : void
    {
        goto lZjwS;
        hT9Qp:
        $this->M2ERX->mu6Z5XKe7fC()->mZ6eTnfJjku($zSVro);
        goto VqGIs;
        aE2yQ:
        $Qaa89[] = ['index' => $TrpLY, 'url' => $mnQQb];
        goto nKV0j;
        OQkjj:
        ++$TrpLY;
        goto QLhCY;
        AsL8v:
        $mnQQb = 'https://' . $jqO73 . '/' . ltrim($dSgog, '/');
        goto aE2yQ;
        nKV0j:
        rSXS7:
        goto OQkjj;
        kggf3:
        $this->M2ERX->mu6Z5XKe7fC()->mZ6eTnfJjku($zSVro);
        goto cD7mg;
        EPjuZ:
        $zSVro = $i4bQp->filename;
        goto kggf3;
        lZjwS:
        $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
        goto gSyIG;
        Nq1Vu:
        $KLu9w = route('upload.api.local_chunk.upload', ['uploadId' => $zSVro, 'index' => $TrpLY]);
        goto ZVMS9;
        cD7mg:
        $TrpLY = 1;
        goto RRdCv;
        fMBiG:
        $jqO73 = parse_url($KLu9w, PHP_URL_HOST);
        goto AsL8v;
        yYPrr:
        $this->M2ERX->maHJweHZt83($Qaa89);
        goto hT9Qp;
        pcUUZ:
        sunjR:
        goto yYPrr;
        ZVMS9:
        $dSgog = parse_url($KLu9w, PHP_URL_PATH);
        goto fMBiG;
        gSyIG:
        $Qaa89 = [];
        goto k2yce;
        k2yce:
        $YW9DR = ceil($i4bQp->QZ4DW / $i4bQp->DKPYI);
        goto EPjuZ;
        QLhCY:
        goto OinKy;
        goto pcUUZ;
        VqGIs:
        $this->GUhIK->put($this->M2ERX->mbZTP3Wyy1I(), json_encode($this->M2ERX->mu6Z5XKe7fC()->toArray()));
        goto egz2a;
        un_fx:
        if (!($TrpLY <= $YW9DR)) {
            goto sunjR;
        }
        goto Nq1Vu;
        RRdCv:
        OinKy:
        goto un_fx;
        egz2a:
        $this->bBnq9->put($this->M2ERX->mbZTP3Wyy1I(), json_encode($this->M2ERX->mu6Z5XKe7fC()->toArray()));
        goto MIqzK;
        MIqzK:
    }
    public function mc7M89BR07U() : void
    {
        goto ziCkn;
        DwZmc:
        $zSVro = $i4bQp->xc0J5;
        goto AAMH9;
        ziCkn:
        $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
        goto DwZmc;
        AAMH9:
        $this->GUhIK->deleteDirectory(self::$t9cho . $zSVro);
        goto JkeA1;
        JkeA1:
        $this->bBnq9->delete($this->M2ERX->mbZTP3Wyy1I());
        goto VK8VL;
        VK8VL:
    }
    public function mbcBVUFS35t() : void
    {
        goto d38dp;
        WskVo:
        z5GZW:
        goto rGaAV;
        d38dp:
        $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
        goto UsyE6;
        YDUg6:
        $pJ2Kc = $this->M2ERX->getFile()->getLocation();
        goto yGu67;
        hSVxc:
        $this->GUhIK->makeDirectory($SzxhY);
        goto qWE4k;
        lbzVn:
        $NhM5a = $this->GUhIK->path($pJ2Kc);
        goto Fbaqh;
        mIfjt:
        Assert::eq(count($WI0bI), $YW9DR, 'The number of parts and checksums must match.');
        goto H4A79;
        yGfEI:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $FqMQT);
        goto sXFXf;
        AP41L:
        foreach ($WI0bI as $uPNA4) {
            goto Bn8zu;
            o8Mhf:
            if (!(false === $t6MEQ)) {
                goto yLrb8;
            }
            goto qmW2v;
            ETGka:
            throw new FkF89X2F8xBt8('A chunk file not existed: ' . $BZQQ1);
            goto ktPQ1;
            lzWxn:
            yLrb8:
            goto uV5kC;
            hIkUE:
            $LyYyg = @fopen($BZQQ1, 'rb');
            goto bBzWA;
            qmW2v:
            throw new FkF89X2F8xBt8('A chunk file content can not copy: ' . $BZQQ1);
            goto lzWxn;
            bBzWA:
            if (!(false === $LyYyg)) {
                goto Rxcbt;
            }
            goto ETGka;
            uV5kC:
            E_SvQ:
            goto p5t1n;
            ktPQ1:
            Rxcbt:
            goto zHmee;
            zHmee:
            $t6MEQ = stream_copy_to_stream($LyYyg, $sTxYt);
            goto lNuec;
            lNuec:
            fclose($LyYyg);
            goto o8Mhf;
            Bn8zu:
            $BZQQ1 = $this->GUhIK->path($uPNA4);
            goto hIkUE;
            p5t1n:
        }
        goto SjP0Y;
        xJc5D:
        fclose($sTxYt);
        goto zi3vs;
        LamU1:
        if (!(false === $sTxYt)) {
            goto ruk95;
        }
        goto AVWd8;
        EN1V6:
        $sTxYt = @fopen($NhM5a, 'wb');
        goto LamU1;
        qWE4k:
        awXKP:
        goto lbzVn;
        BpiOf:
        if (chmod($FqMQT, 0644)) {
            goto z5GZW;
        }
        goto yGfEI;
        SjP0Y:
        iTJru:
        goto xJc5D;
        fx8JQ:
        $SzxhY = dirname($pJ2Kc);
        goto x55KX;
        M9sPY:
        ruk95:
        goto AP41L;
        zi3vs:
        $FqMQT = $this->GUhIK->path($pJ2Kc);
        goto BpiOf;
        yGu67:
        $WI0bI = $this->GUhIK->files($lUVR3);
        goto mIfjt;
        sXFXf:
        throw new \Exception('Failed to set file permissions for stored image: ' . $FqMQT);
        goto WskVo;
        AVWd8:
        throw new FkF89X2F8xBt8('Local chunk can not merge file (can create file): ' . $NhM5a);
        goto M9sPY;
        Fbaqh:
        touch($NhM5a);
        goto EN1V6;
        x55KX:
        if ($this->GUhIK->exists($SzxhY)) {
            goto awXKP;
        }
        goto hSVxc;
        KXlEF:
        $lUVR3 = self::$t9cho . $i4bQp->xc0J5;
        goto YDUg6;
        rGaAV:
        $this->GUhIK->deleteDirectory($lUVR3);
        goto hvv1n;
        UsyE6:
        $YW9DR = $i4bQp->h134J;
        goto KXlEF;
        H4A79:
        natsort($WI0bI);
        goto fx8JQ;
        hvv1n:
    }
}
