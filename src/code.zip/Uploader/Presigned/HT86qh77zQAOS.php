<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\El1EbMj6pC2Ez;
use Jfs\Uploader\Exception\P1cBJVt5vzahC;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Presigned\J2QclvQdBQfV8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class HT86qh77zQAOS implements J2QclvQdBQfV8
{
    private static $BUwen = 'chunks/';
    private $liA4i;
    private $FHcNr;
    private $p5xeF;
    public function __construct(El1EbMj6pC2Ez $tzb77, Filesystem $z279S, Filesystem $AA8Bi)
    {
        goto DijUk;
        DijUk:
        $this->liA4i = $tzb77;
        goto dFtc0;
        Ah1_h:
        $this->p5xeF = $AA8Bi;
        goto ugQkr;
        dFtc0:
        $this->FHcNr = $z279S;
        goto Ah1_h;
        ugQkr:
    }
    public function mYhjxA8RCUq() : void
    {
        goto tQ4Ie;
        Eu5Io:
        YZ0pe:
        goto FRpSr;
        WlkAE:
        $Jkf3h = 'https://' . $os_K1 . '/' . ltrim($L5bJW, '/');
        goto IQUHR;
        dzsOD:
        $this->liA4i->mFBfBagZ9x6()->mLQU01cj3Al($aPEyz);
        goto LCY73;
        UAp4x:
        $os_K1 = parse_url($uG0yw, PHP_URL_HOST);
        goto WlkAE;
        LCY73:
        $ZXvon = 1;
        goto RLdWG;
        hPNQo:
        $this->liA4i->mFBfBagZ9x6()->mLQU01cj3Al($aPEyz);
        goto IBgoT;
        mMNxY:
        ofvUR:
        goto v4NHr;
        RLdWG:
        NVayI:
        goto DEvZu;
        tQ4Ie:
        $eSKpN = $this->liA4i->mFBfBagZ9x6();
        goto GUx7O;
        v4NHr:
        ++$ZXvon;
        goto c9sSY;
        IBgoT:
        $this->FHcNr->put($this->liA4i->mrwx9qum9K0(), json_encode($this->liA4i->mFBfBagZ9x6()->toArray()));
        goto CKolv;
        FRpSr:
        $this->liA4i->mSKQ6IJo5al($HXn5w);
        goto hPNQo;
        oyIIw:
        $aPEyz = $eSKpN->filename;
        goto dzsOD;
        GUx7O:
        $HXn5w = [];
        goto RHXHO;
        c9sSY:
        goto NVayI;
        goto Eu5Io;
        IQUHR:
        $HXn5w[] = ['index' => $ZXvon, 'url' => $Jkf3h];
        goto mMNxY;
        CKolv:
        $this->p5xeF->put($this->liA4i->mrwx9qum9K0(), json_encode($this->liA4i->mFBfBagZ9x6()->toArray()));
        goto W7MNp;
        DEvZu:
        if (!($ZXvon <= $D5Cak)) {
            goto YZ0pe;
        }
        goto c1qwb;
        e114P:
        $L5bJW = parse_url($uG0yw, PHP_URL_PATH);
        goto UAp4x;
        c1qwb:
        $uG0yw = route('upload.api.local_chunk.upload', ['uploadId' => $aPEyz, 'index' => $ZXvon]);
        goto e114P;
        RHXHO:
        $D5Cak = ceil($eSKpN->TgkQ_ / $eSKpN->R2hLK);
        goto oyIIw;
        W7MNp:
    }
    public function mE0rB6JIYIW() : void
    {
        goto czAkw;
        czAkw:
        $eSKpN = $this->liA4i->mFBfBagZ9x6();
        goto vqJrV;
        XJUtr:
        $this->p5xeF->delete($this->liA4i->mrwx9qum9K0());
        goto krDQG;
        cqAbt:
        $this->FHcNr->deleteDirectory(self::$BUwen . $aPEyz);
        goto XJUtr;
        vqJrV:
        $aPEyz = $eSKpN->zFYsq;
        goto cqAbt;
        krDQG:
    }
    public function muBMwFMNOXz() : void
    {
        goto zHy2v;
        BqkXk:
        $zEDQ0 = dirname($M5qZY);
        goto msYZu;
        mye12:
        foreach ($aS6XG as $cqvTd) {
            goto Z88V9;
            Mimqy:
            throw new P1cBJVt5vzahC('A chunk file not existed: ' . $He2tD);
            goto MMshh;
            L3EFi:
            xZI5h:
            goto AJ0_Q;
            vwdkh:
            $mfB3G = @fopen($He2tD, 'rb');
            goto quu4i;
            z_xj2:
            RmInm:
            goto L3EFi;
            shqci:
            throw new P1cBJVt5vzahC('A chunk file content can not copy: ' . $He2tD);
            goto z_xj2;
            Z88V9:
            $He2tD = $this->FHcNr->path($cqvTd);
            goto vwdkh;
            MMshh:
            lQh8l:
            goto Nx0h1;
            PWLX_:
            if (!(false === $wrK5m)) {
                goto RmInm;
            }
            goto shqci;
            W9dXM:
            fclose($mfB3G);
            goto PWLX_;
            Nx0h1:
            $wrK5m = stream_copy_to_stream($mfB3G, $ixnN5);
            goto W9dXM;
            quu4i:
            if (!(false === $mfB3G)) {
                goto lQh8l;
            }
            goto Mimqy;
            AJ0_Q:
        }
        goto uDrMi;
        Z1ad1:
        $this->FHcNr->makeDirectory($zEDQ0);
        goto W2Uh5;
        uDrMi:
        cM6HE:
        goto lXup7;
        vxLSi:
        jLUuS:
        goto mye12;
        biI1v:
        throw new P1cBJVt5vzahC('Local chunk can not merge file (can create file): ' . $ZNuz0);
        goto vxLSi;
        NTDgR:
        throw new \Exception('Failed to set file permissions for stored image: ' . $CM1YL);
        goto xIngs;
        ELKmL:
        if (!(false === $ixnN5)) {
            goto jLUuS;
        }
        goto biI1v;
        khvqC:
        $this->FHcNr->deleteDirectory($dkzGm);
        goto le8EH;
        Ad00w:
        $aS6XG = $this->FHcNr->files($dkzGm);
        goto mLBWk;
        voXqM:
        if (chmod($CM1YL, 0644)) {
            goto WY8Yr;
        }
        goto zHQWY;
        Hag7p:
        $ixnN5 = @fopen($ZNuz0, 'wb');
        goto ELKmL;
        zHQWY:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $CM1YL);
        goto NTDgR;
        zHy2v:
        $eSKpN = $this->liA4i->mFBfBagZ9x6();
        goto ZiLbH;
        r2Tu_:
        touch($ZNuz0);
        goto Hag7p;
        F1wjg:
        $M5qZY = $this->liA4i->getFile()->getLocation();
        goto Ad00w;
        ixBHN:
        $dkzGm = self::$BUwen . $eSKpN->zFYsq;
        goto F1wjg;
        jm01X:
        $CM1YL = $this->FHcNr->path($M5qZY);
        goto voXqM;
        xIngs:
        WY8Yr:
        goto khvqC;
        msYZu:
        if ($this->FHcNr->exists($zEDQ0)) {
            goto LvErt;
        }
        goto Z1ad1;
        pN5v4:
        $ZNuz0 = $this->FHcNr->path($M5qZY);
        goto r2Tu_;
        wa0QN:
        natsort($aS6XG);
        goto BqkXk;
        W2Uh5:
        LvErt:
        goto pN5v4;
        ZiLbH:
        $D5Cak = $eSKpN->DWXiY;
        goto ixBHN;
        mLBWk:
        Assert::eq(count($aS6XG), $D5Cak, 'The number of parts and checksums must match.');
        goto wa0QN;
        lXup7:
        fclose($ixnN5);
        goto jm01X;
        le8EH:
    }
}
