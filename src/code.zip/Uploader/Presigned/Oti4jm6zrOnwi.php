<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\DcQiQqj2PVL2z;
use Jfs\Uploader\Exception\SVA2aZGJgmDtq;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Presigned\Kdv2RDYQWDIhW;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Oti4jm6zrOnwi implements Kdv2RDYQWDIhW
{
    private static $dPkmB = 'chunks/';
    private $NHvEy;
    private $unMfk;
    private $x5SUA;
    public function __construct(DcQiQqj2PVL2z $m3Blp, Filesystem $L32kE, Filesystem $j3j3G)
    {
        goto MyuAr;
        MyuAr:
        $this->NHvEy = $m3Blp;
        goto BAAZi;
        BAAZi:
        $this->unMfk = $L32kE;
        goto SMX3W;
        SMX3W:
        $this->x5SUA = $j3j3G;
        goto Sg4kA;
        Sg4kA:
    }
    public function mzGVYtZieUh() : void
    {
        goto rzl2p;
        avlL3:
        $this->NHvEy->mKgkEuClTdh($yiCPI);
        goto Vf0am;
        UJ203:
        if (!($j4bsE <= $P13NU)) {
            goto SWcaz;
        }
        goto J2I9S;
        xi4Fh:
        $yiCPI = [];
        goto E3On9;
        Vf0am:
        $this->NHvEy->mYn06Pxlq0m()->mzmsXanFg3j($pYyLE);
        goto d55he;
        E3On9:
        $P13NU = ceil($wEH2f->rINwN / $wEH2f->tg2I4);
        goto ygIwN;
        rzl2p:
        $wEH2f = $this->NHvEy->mYn06Pxlq0m();
        goto xi4Fh;
        EN8MX:
        goto CF0oP;
        goto pLb5x;
        K0KGN:
        $j4bsE = 1;
        goto O2Bl1;
        O2Bl1:
        CF0oP:
        goto UJ203;
        hdYhV:
        $this->x5SUA->put($this->NHvEy->mc7MIaojWTK(), json_encode($this->NHvEy->mYn06Pxlq0m()->toArray()));
        goto FPHrR;
        gBbTD:
        $this->NHvEy->mYn06Pxlq0m()->mzmsXanFg3j($pYyLE);
        goto K0KGN;
        ygIwN:
        $pYyLE = Uuid::v4()->toHex();
        goto gBbTD;
        Oy5HL:
        ++$j4bsE;
        goto EN8MX;
        ikQEz:
        HWnOX:
        goto Oy5HL;
        d55he:
        $this->unMfk->put($this->NHvEy->mc7MIaojWTK(), json_encode($this->NHvEy->mYn06Pxlq0m()->toArray()));
        goto hdYhV;
        J2I9S:
        $yiCPI[] = ['index' => $j4bsE, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $pYyLE, 'index' => $j4bsE])];
        goto ikQEz;
        pLb5x:
        SWcaz:
        goto avlL3;
        FPHrR:
    }
    public function mo0bnXSNhQX() : void
    {
        goto dflVl;
        dflVl:
        $wEH2f = $this->NHvEy->mYn06Pxlq0m();
        goto dMueW;
        cc_zk:
        $this->x5SUA->delete($this->NHvEy->mc7MIaojWTK());
        goto MCFcH;
        Iqxbe:
        $this->unMfk->deleteDirectory(self::$dPkmB . $pYyLE);
        goto cc_zk;
        dMueW:
        $pYyLE = $wEH2f->OZbwJ;
        goto Iqxbe;
        MCFcH:
    }
    public function m5cVukL3XfZ() : void
    {
        goto EpahV;
        L5jiH:
        $fP6Bj = $this->NHvEy->getFile()->getLocation();
        goto GLE4k;
        ikO4f:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $J9rwS);
        goto MMLKh;
        hOUPB:
        PaaCW:
        goto sKHKe;
        pNUsK:
        $J9rwS = $this->unMfk->path($fP6Bj);
        goto V14H1;
        EpahV:
        $wEH2f = $this->NHvEy->mYn06Pxlq0m();
        goto yqq6O;
        tXk0h:
        Assert::eq(count($qkgKv), $P13NU, 'The number of parts and checksums must match.');
        goto Yplzb;
        lCvxT:
        $this->unMfk->makeDirectory($PdXfz);
        goto NlRvC;
        mi7We:
        throw new SVA2aZGJgmDtq('Local chunk can not merge file (can create file): ' . $LOPfb);
        goto p91bT;
        Yc3iR:
        if ($this->unMfk->exists($PdXfz)) {
            goto hmVQp;
        }
        goto lCvxT;
        sKHKe:
        $this->unMfk->deleteDirectory($Adn2i);
        goto WMHsk;
        Vgb7d:
        $Adn2i = self::$dPkmB . $wEH2f->OZbwJ;
        goto L5jiH;
        URucJ:
        AizOc:
        goto N0FLd;
        kHalw:
        touch($LOPfb);
        goto HYd0r;
        vZggG:
        $LOPfb = $this->unMfk->path($fP6Bj);
        goto kHalw;
        N0FLd:
        fclose($z4vIo);
        goto pNUsK;
        yqq6O:
        $P13NU = $wEH2f->JbpvE;
        goto Vgb7d;
        N6RB2:
        $PdXfz = dirname($fP6Bj);
        goto Yc3iR;
        p91bT:
        gLQQe:
        goto Nn1Tu;
        Yplzb:
        natsort($qkgKv);
        goto N6RB2;
        NlRvC:
        hmVQp:
        goto vZggG;
        GLE4k:
        $qkgKv = $this->unMfk->files($Adn2i);
        goto tXk0h;
        V14H1:
        if (chmod($J9rwS, 0644)) {
            goto PaaCW;
        }
        goto ikO4f;
        Nn1Tu:
        foreach ($qkgKv as $uPGyO) {
            goto KX6lz;
            sTpxX:
            kHej0:
            goto a77vS;
            elAVe:
            Sq9fO:
            goto sTpxX;
            a7ndi:
            throw new SVA2aZGJgmDtq('A chunk file content can not copy: ' . $iKfx8);
            goto elAVe;
            NNSh9:
            $QLEDR = @fopen($iKfx8, 'rb');
            goto S0ksC;
            I1t0L:
            fclose($QLEDR);
            goto W6gKp;
            ht00r:
            B47bx:
            goto flsNg;
            W6gKp:
            if (!(false === $Poupi)) {
                goto Sq9fO;
            }
            goto a7ndi;
            S0ksC:
            if (!(false === $QLEDR)) {
                goto B47bx;
            }
            goto aL612;
            flsNg:
            $Poupi = stream_copy_to_stream($QLEDR, $z4vIo);
            goto I1t0L;
            aL612:
            throw new SVA2aZGJgmDtq('A chunk file not existed: ' . $iKfx8);
            goto ht00r;
            KX6lz:
            $iKfx8 = $this->unMfk->path($uPGyO);
            goto NNSh9;
            a77vS:
        }
        goto URucJ;
        MMLKh:
        throw new \Exception('Failed to set file permissions for stored image: ' . $J9rwS);
        goto hOUPB;
        HFoKQ:
        if (!(false === $z4vIo)) {
            goto gLQQe;
        }
        goto mi7We;
        HYd0r:
        $z4vIo = @fopen($LOPfb, 'wb');
        goto HFoKQ;
        WMHsk:
    }
}
