<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Y96dk3g6dPmcf;
use Jfs\Uploader\Exception\Iz97XtnhFWG8z;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class BYwgIVxcWoIPX implements QsAeGSwzIgbhx
{
    private static $X2yKS = 'chunks/';
    private $yVhDF;
    private $VFHFZ;
    private $NP9R0;
    public function __construct(Y96dk3g6dPmcf $lIPqb, Filesystem $dOL2I, Filesystem $TLVVj)
    {
        goto szJM8;
        fnuIn:
        $this->VFHFZ = $dOL2I;
        goto SkjRR;
        szJM8:
        $this->yVhDF = $lIPqb;
        goto fnuIn;
        SkjRR:
        $this->NP9R0 = $TLVVj;
        goto BGNpu;
        BGNpu:
    }
    public function mPEms69EA0A() : void
    {
        goto MHUC5;
        pnN2n:
        $Tu5AU = Uuid::v4()->toHex();
        goto lbM2o;
        Ff639:
        BIpMd:
        goto QzDMr;
        UesVw:
        goto qey60;
        goto VaMAH;
        lbM2o:
        $this->yVhDF->mmWA2B9zVkK()->moWcWcx9wMl($Tu5AU);
        goto GEzEs;
        ryCSP:
        $HqM7F = ceil($ag5JI->u1hlj / $ag5JI->EAzFa);
        goto pnN2n;
        QzDMr:
        ++$sBfQi;
        goto UesVw;
        SSBoU:
        qey60:
        goto BcOQW;
        GEzEs:
        $sBfQi = 1;
        goto SSBoU;
        vW7NY:
        $NiTPl[] = ['index' => $sBfQi, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $Tu5AU, 'index' => $sBfQi])];
        goto Ff639;
        BcOQW:
        if (!($sBfQi <= $HqM7F)) {
            goto lpDrD;
        }
        goto vW7NY;
        CrvYM:
        $NiTPl = [];
        goto ryCSP;
        KAqBi:
        $this->yVhDF->mmWA2B9zVkK()->moWcWcx9wMl($Tu5AU);
        goto nLAgb;
        VaMAH:
        lpDrD:
        goto xEq9q;
        nLAgb:
        $this->VFHFZ->put($this->yVhDF->mEfGPqiyn18(), json_encode($this->yVhDF->mmWA2B9zVkK()->toArray()));
        goto Ird83;
        Ird83:
        $this->NP9R0->put($this->yVhDF->mEfGPqiyn18(), json_encode($this->yVhDF->mmWA2B9zVkK()->toArray()));
        goto NWv5X;
        MHUC5:
        $ag5JI = $this->yVhDF->mmWA2B9zVkK();
        goto CrvYM;
        xEq9q:
        $this->yVhDF->mfc4hqnAzmE($NiTPl);
        goto KAqBi;
        NWv5X:
    }
    public function mnpYdu0IZ9W() : void
    {
        goto toG5t;
        N_Z_r:
        $this->NP9R0->delete($this->yVhDF->mEfGPqiyn18());
        goto gNuSe;
        toG5t:
        $ag5JI = $this->yVhDF->mmWA2B9zVkK();
        goto uZCDC;
        uZCDC:
        $Tu5AU = $ag5JI->NDdad;
        goto H56_2;
        H56_2:
        $this->VFHFZ->deleteDirectory(self::$X2yKS . $Tu5AU);
        goto N_Z_r;
        gNuSe:
    }
    public function mqyBtnjUsU9() : void
    {
        goto txT8z;
        zZ67S:
        if (chmod($uejxd, 0644)) {
            goto Lgywc;
        }
        goto Zyng1;
        Zyng1:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $uejxd);
        goto SGVbZ;
        k5B5W:
        $uejxd = $this->VFHFZ->path($sfedA);
        goto zZ67S;
        D6owp:
        $this->VFHFZ->makeDirectory($qcvuT);
        goto wxu6U;
        rQL6p:
        foreach ($FmBQl as $o1bgP) {
            goto hbqqr;
            hbqqr:
            $VdDTV = $this->VFHFZ->path($o1bgP);
            goto OnlGC;
            ofOwt:
            To3QO:
            goto CWcCq;
            eIbHE:
            throw new Iz97XtnhFWG8z('A chunk file content can not copy: ' . $VdDTV);
            goto rjkk5;
            oZWjj:
            if (!(false === $gsHPy)) {
                goto PGLSq;
            }
            goto qw5sM;
            rjkk5:
            vMBBW:
            goto ofOwt;
            qw5sM:
            throw new Iz97XtnhFWG8z('A chunk file not existed: ' . $VdDTV);
            goto hFDfz;
            KmQ_D:
            if (!(false === $LoKI9)) {
                goto vMBBW;
            }
            goto eIbHE;
            hFDfz:
            PGLSq:
            goto yaSso;
            OnlGC:
            $gsHPy = @fopen($VdDTV, 'rb');
            goto oZWjj;
            xS1zn:
            fclose($gsHPy);
            goto KmQ_D;
            yaSso:
            $LoKI9 = stream_copy_to_stream($gsHPy, $fIcp1);
            goto xS1zn;
            CWcCq:
        }
        goto nwbnG;
        p552B:
        $qcvuT = dirname($sfedA);
        goto wk80P;
        vX8TV:
        if (!(false === $fIcp1)) {
            goto FL75k;
        }
        goto DLvRX;
        mz7L3:
        natsort($FmBQl);
        goto p552B;
        klm_f:
        Lgywc:
        goto cvioy;
        YHIz8:
        $FmBQl = $this->VFHFZ->files($X2MW1);
        goto oVRzC;
        vFISG:
        FL75k:
        goto rQL6p;
        wxu6U:
        QuNiC:
        goto M_v9V;
        M_v9V:
        $tWlEO = $this->VFHFZ->path($sfedA);
        goto vEPRX;
        txT8z:
        $ag5JI = $this->yVhDF->mmWA2B9zVkK();
        goto i7zlQ;
        i7zlQ:
        $HqM7F = $ag5JI->bQ8dx;
        goto Kv7JM;
        DLvRX:
        throw new Iz97XtnhFWG8z('Local chunk can not merge file (can create file): ' . $tWlEO);
        goto vFISG;
        xPOhk:
        fclose($fIcp1);
        goto k5B5W;
        vEPRX:
        touch($tWlEO);
        goto VA13R;
        Kv7JM:
        $X2MW1 = self::$X2yKS . $ag5JI->NDdad;
        goto Sk4Mw;
        VA13R:
        $fIcp1 = @fopen($tWlEO, 'wb');
        goto vX8TV;
        SGVbZ:
        throw new \Exception('Failed to set file permissions for stored image: ' . $uejxd);
        goto klm_f;
        oVRzC:
        Assert::eq(count($FmBQl), $HqM7F, 'The number of parts and checksums must match.');
        goto mz7L3;
        nwbnG:
        AlJBd:
        goto xPOhk;
        cvioy:
        $this->VFHFZ->deleteDirectory($X2MW1);
        goto yNopy;
        Sk4Mw:
        $sfedA = $this->yVhDF->getFile()->getLocation();
        goto YHIz8;
        wk80P:
        if ($this->VFHFZ->exists($qcvuT)) {
            goto QuNiC;
        }
        goto D6owp;
        yNopy:
    }
}
