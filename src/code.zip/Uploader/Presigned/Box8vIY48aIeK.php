<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:22              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\ED7I8bwNqdusd;
use Jfs\Uploader\Exception\BZYcohGyJis2t;
use Jfs\Uploader\Exception\RaGvp4a3nFEqU;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Exception\O68QFpMODjRW0;
use Jfs\Uploader\Presigned\HtVuQ4B4NMn1d;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class Box8vIY48aIeK implements HtVuQ4B4NMn1d
{
    private $YssWB;
    private $qqmnq;
    private $iIDXy;
    private $mltiL;
    public function __construct(ED7I8bwNqdusd $lJ5H4, Filesystem $vS8UC, Filesystem $vKILS, string $nIkcP)
    {
        goto DGcMH;
        pZOms:
        $this->iIDXy = $vKILS;
        goto M_zi7;
        M_zi7:
        $this->mltiL = $nIkcP;
        goto YF1Iu;
        DGcMH:
        $this->YssWB = $lJ5H4;
        goto tTcrK;
        tTcrK:
        $this->qqmnq = $vS8UC;
        goto pZOms;
        YF1Iu:
    }
    public function mY1nsrq2j7D()
    {
        goto UP227;
        hNJvX:
        if (!($yO0N5 <= $JIqfO)) {
            goto ZDeki;
        }
        goto K2gNc;
        KLgpU:
        $this->YssWB->m2ccRPZ5J1k($FG6si);
        goto fkoBW;
        UP227:
        $wt893 = $this->YssWB->mvHStueAWqd();
        goto NYtRv;
        wK2F2:
        if (!(0 === $XDvUb->count())) {
            goto kjoIb;
        }
        goto NhfV0;
        dHlf8:
        goto Zgbzz;
        goto tyNhQ;
        m2zND:
        Zgbzz:
        goto hNJvX;
        K2gNc:
        $Uec0L = $Ylw8l->getCommand('UploadPart', ['Bucket' => $this->mltiL, 'Key' => $this->YssWB->getFile()->getLocation(), 'UploadId' => $XDvUb['UploadId'], 'PartNumber' => $yO0N5]);
        goto qrPAz;
        NYtRv:
        $FG6si = [];
        goto YzJDr;
        fkoBW:
        $this->YssWB->mvHStueAWqd()->m0xOxJ2PiV4($XDvUb['UploadId']);
        goto ih99p;
        z3IE1:
        kjoIb:
        goto EGW23;
        NhfV0:
        throw new O68QFpMODjRW0("Failed to create multipart upload for file {$this->YssWB->getFile()->getFilename()}, S3 return empty response");
        goto z3IE1;
        V4Cem:
        $this->iIDXy->put($this->YssWB->mZx3Wns8jZm(), json_encode($this->YssWB->mvHStueAWqd()->toArray()));
        goto fGQ7N;
        HhYQz:
        IRmGf:
        goto cer0b;
        tyNhQ:
        ZDeki:
        goto KLgpU;
        nLT1Z:
        $Ylw8l = $this->iIDXy->getClient();
        goto k0ZtR;
        AsZT6:
        $FG6si[] = ['index' => $yO0N5, 'url' => (string) $q7b6O->getUri()];
        goto HhYQz;
        k0ZtR:
        $XDvUb = $Ylw8l->createMultipartUpload(['Bucket' => $this->mltiL, 'Key' => $this->YssWB->getFile()->getLocation(), 'ContentType' => $this->YssWB->mvHStueAWqd()->P4Jmr, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto wK2F2;
        YzJDr:
        $JIqfO = ceil($wt893->zJLxD / $wt893->Lmq3n);
        goto nLT1Z;
        EGW23:
        $yO0N5 = 1;
        goto m2zND;
        cer0b:
        ++$yO0N5;
        goto dHlf8;
        ih99p:
        $this->qqmnq->put($this->YssWB->mZx3Wns8jZm(), json_encode($this->YssWB->mvHStueAWqd()->toArray()));
        goto V4Cem;
        qrPAz:
        $q7b6O = $Ylw8l->createPresignedRequest($Uec0L, '+1 day');
        goto AsZT6;
        fGQ7N:
    }
    public function mhhM9EUIOAf() : void
    {
        goto R8nv0;
        BOVs4:
        try {
            $Ylw8l->abortMultipartUpload(['Bucket' => $this->mltiL, 'Key' => $this->YssWB->getFile()->getLocation(), 'UploadId' => $this->YssWB->mvHStueAWqd()->ARR5y]);
        } catch (\Throwable $b6Bui) {
            throw new BZYcohGyJis2t("Failed to abort multipart upload of file {$this->YssWB->getFile()->getFilename()}", 0, $b6Bui);
        }
        goto RKU3I;
        RKU3I:
        $this->qqmnq->delete($this->YssWB->mZx3Wns8jZm());
        goto NPo1f;
        NPo1f:
        $this->iIDXy->delete($this->YssWB->mZx3Wns8jZm());
        goto GE1cE;
        R8nv0:
        $Ylw8l = $this->iIDXy->getClient();
        goto BOVs4;
        GE1cE:
    }
    public function mnPGFoo0xg7() : void
    {
        goto KcDUv;
        MeFTi:
        $jwVeU = $wt893->kw5aF;
        goto mWPGv;
        mWPGv:
        Assert::eq(count($zO8GR), count($jwVeU), 'The number of parts and checksums must match.');
        goto ZUz0r;
        t3a2S:
        kPoeq:
        goto of7kM;
        FAFHk:
        foreach ($jwVeU as $JHDpG) {
            goto su6J1;
            wh05U:
            throw new RaGvp4a3nFEqU("Checksum mismatch for part {$KjS77} of file {$this->YssWB->getFile()->getFilename()}");
            goto iP09p;
            su6J1:
            $KjS77 = $JHDpG['partNumber'];
            goto c4GxB;
            Um11A:
            Dvwm9:
            goto RhTLh;
            iP09p:
            YTzjP:
            goto Um11A;
            FprxQ:
            if (!($RO623['eTag'] !== $JHDpG['eTag'])) {
                goto YTzjP;
            }
            goto wh05U;
            c4GxB:
            $RO623 = $pWsMw[$KjS77];
            goto FprxQ;
            RhTLh:
        }
        goto t3a2S;
        w2CM4:
        $zO8GR = $wt893->H17hx;
        goto MeFTi;
        ZUz0r:
        $pWsMw = collect($zO8GR)->keyBy('partNumber');
        goto FAFHk;
        zu5Ks:
        try {
            $Ylw8l->completeMultipartUpload(['Bucket' => $this->mltiL, 'Key' => $this->YssWB->getFile()->getLocation(), 'UploadId' => $this->YssWB->mvHStueAWqd()->ARR5y, 'MultipartUpload' => ['Parts' => collect($this->YssWB->mvHStueAWqd()->H17hx)->sortBy('partNumber')->map(fn($RO623) => ['ETag' => $RO623['eTag'], 'PartNumber' => $RO623['partNumber']])->toArray()]]);
        } catch (\Throwable $b6Bui) {
            throw new RaGvp4a3nFEqU("Failed to merge chunks of file {$this->YssWB->getFile()->getFilename()}", 0, $b6Bui);
        }
        goto E7AHq;
        of7kM:
        $Ylw8l = $this->iIDXy->getClient();
        goto zu5Ks;
        KcDUv:
        $wt893 = $this->YssWB->mvHStueAWqd();
        goto w2CM4;
        E7AHq:
    }
}
