<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\I0VIwBtNAG2Lq;
use Jfs\Uploader\Exception\BJPS0zpokxmYo;
use Jfs\Uploader\Exception\KiNemuUpdr4GY;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Exception\PX4GouGrOz7dU;
use Jfs\Uploader\Presigned\MpQkc6sTxxyxM;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class TzZR4LqjnuAXX implements MpQkc6sTxxyxM
{
    private $ImZI2;
    private $W2Sfl;
    private $dMiJj;
    private $omjLi;
    public function __construct(I0VIwBtNAG2Lq $RHBLn, Filesystem $d_Wiu, Filesystem $F17Nf, string $O893k)
    {
        goto QRQHL;
        QRQHL:
        $this->ImZI2 = $RHBLn;
        goto MwUzy;
        x_ovh:
        $this->dMiJj = $F17Nf;
        goto cr3iu;
        cr3iu:
        $this->omjLi = $O893k;
        goto OjzBP;
        MwUzy:
        $this->W2Sfl = $d_Wiu;
        goto x_ovh;
        OjzBP:
    }
    public function miOPwul7xEs()
    {
        goto f82im;
        zCjKa:
        $n1mJJ = ceil($fK0e7->jVikM / $fK0e7->vD_8M);
        goto joD6M;
        SqRxw:
        throw new PX4GouGrOz7dU("Failed to create multipart upload for file {$this->ImZI2->getFile()->getFilename()}, S3 return empty response");
        goto gvFVs;
        CnFEo:
        $E7P1t = $N3akJ->getCommand('UploadPart', ['Bucket' => $this->omjLi, 'Key' => $this->ImZI2->getFile()->getLocation(), 'UploadId' => $h1oLe['UploadId'], 'PartNumber' => $dLkks]);
        goto jPBUk;
        M6kXM:
        $hs4qc = [];
        goto zCjKa;
        q1t9v:
        if (!($dLkks <= $n1mJJ)) {
            goto egK9U;
        }
        goto CnFEo;
        Sa0YE:
        $dLkks = 1;
        goto z2BuM;
        urw1i:
        $this->W2Sfl->put($this->ImZI2->mmOYDrQaoGz(), json_encode($this->ImZI2->mAOwHvxkwWq()->toArray()));
        goto eK_Dw;
        mPh3G:
        if (!(0 === $h1oLe->count())) {
            goto cfD5A;
        }
        goto SqRxw;
        HtWJF:
        MuJuT:
        goto Aa0HK;
        CfIFh:
        $this->ImZI2->mAOwHvxkwWq()->m44sTqfMmVa($h1oLe['UploadId']);
        goto urw1i;
        eK_Dw:
        $this->dMiJj->put($this->ImZI2->mmOYDrQaoGz(), json_encode($this->ImZI2->mAOwHvxkwWq()->toArray()));
        goto gIA4w;
        jPBUk:
        $FXuMy = $N3akJ->createPresignedRequest($E7P1t, '+1 day');
        goto Y6RlO;
        D_WMO:
        egK9U:
        goto oh2ji;
        S5iSC:
        $h1oLe = $N3akJ->createMultipartUpload(['Bucket' => $this->omjLi, 'Key' => $this->ImZI2->getFile()->getLocation(), 'ContentType' => $this->ImZI2->mAOwHvxkwWq()->x06d2, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto mPh3G;
        oh2ji:
        $this->ImZI2->mvKUglYPOle($hs4qc);
        goto CfIFh;
        Y6RlO:
        $hs4qc[] = ['index' => $dLkks, 'url' => (string) $FXuMy->getUri()];
        goto HtWJF;
        tLxXn:
        goto X5OoD;
        goto D_WMO;
        Aa0HK:
        ++$dLkks;
        goto tLxXn;
        f82im:
        $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
        goto M6kXM;
        z2BuM:
        X5OoD:
        goto q1t9v;
        gvFVs:
        cfD5A:
        goto Sa0YE;
        joD6M:
        $N3akJ = $this->dMiJj->getClient();
        goto S5iSC;
        gIA4w:
    }
    public function msracQGonfo() : void
    {
        goto td75S;
        k7XNJ:
        $this->dMiJj->delete($this->ImZI2->mmOYDrQaoGz());
        goto CgdKd;
        scicD:
        try {
            $N3akJ->abortMultipartUpload(['Bucket' => $this->omjLi, 'Key' => $this->ImZI2->getFile()->getLocation(), 'UploadId' => $this->ImZI2->mAOwHvxkwWq()->Y7fjO]);
        } catch (\Throwable $bIOBo) {
            throw new BJPS0zpokxmYo("Failed to abort multipart upload of file {$this->ImZI2->getFile()->getFilename()}", 0, $bIOBo);
        }
        goto hRknj;
        hRknj:
        $this->W2Sfl->delete($this->ImZI2->mmOYDrQaoGz());
        goto k7XNJ;
        td75S:
        $N3akJ = $this->dMiJj->getClient();
        goto scicD;
        CgdKd:
    }
    public function mgn0m4kZaFh() : void
    {
        goto G51zi;
        xtg_k:
        $MZWng = $fK0e7->MA937;
        goto Uv35F;
        G51zi:
        $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
        goto xtg_k;
        Wawqr:
        Assert::eq(count($MZWng), count($S0AL0), 'The number of parts and checksums must match.');
        goto ESnpd;
        nay72:
        XUzI0:
        goto DHZon;
        Uv35F:
        $S0AL0 = $fK0e7->rqL2L;
        goto Wawqr;
        DHZon:
        $N3akJ = $this->dMiJj->getClient();
        goto y0UdC;
        ot2d5:
        foreach ($S0AL0 as $zis9O) {
            goto eHqN2;
            hTcZC:
            VLSkF:
            goto hKIRO;
            JkwlB:
            $qiUQe = $JtkHA[$yMRB6];
            goto yj6MO;
            yj6MO:
            if (!($qiUQe['eTag'] !== $zis9O['eTag'])) {
                goto PNagD;
            }
            goto zwTOQ;
            zwTOQ:
            throw new KiNemuUpdr4GY("Checksum mismatch for part {$yMRB6} of file {$this->ImZI2->getFile()->getFilename()}");
            goto yOiM2;
            eHqN2:
            $yMRB6 = $zis9O['partNumber'];
            goto JkwlB;
            yOiM2:
            PNagD:
            goto hTcZC;
            hKIRO:
        }
        goto nay72;
        ESnpd:
        $JtkHA = collect($MZWng)->keyBy('partNumber');
        goto ot2d5;
        y0UdC:
        try {
            $N3akJ->completeMultipartUpload(['Bucket' => $this->omjLi, 'Key' => $this->ImZI2->getFile()->getLocation(), 'UploadId' => $this->ImZI2->mAOwHvxkwWq()->Y7fjO, 'MultipartUpload' => ['Parts' => collect($this->ImZI2->mAOwHvxkwWq()->MA937)->sortBy('partNumber')->map(fn($qiUQe) => ['ETag' => $qiUQe['eTag'], 'PartNumber' => $qiUQe['partNumber']])->toArray()]]);
        } catch (\Throwable $bIOBo) {
            throw new KiNemuUpdr4GY("Failed to merge chunks of file {$this->ImZI2->getFile()->getFilename()}", 0, $bIOBo);
        }
        goto ixqnJ;
        ixqnJ:
    }
}
