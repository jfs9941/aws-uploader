<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\I9eXouytPf2zH;
use Jfs\Uploader\Exception\AiOjz36jlc8a3;
use Jfs\Uploader\Exception\DvjM23NaGNvwG;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Jfs\Uploader\Exception\PgAGQxNuMG4nF;
use Webmozart\Assert\Assert;
class N5hiEwPfaJUjD implements CyAoKfbD7nMu5
{
    private $Y8BXM;
    private $UBJ9G;
    private $Mq65A;
    private $iqyyD;
    public function __construct(I9eXouytPf2zH $N50om, Filesystem $e1L33, Filesystem $o9ClE, string $TnK9g)
    {
        goto cV4hA;
        q0WVj:
        $this->UBJ9G = $e1L33;
        goto CszMK;
        CszMK:
        $this->Mq65A = $o9ClE;
        goto qXv0L;
        qXv0L:
        $this->iqyyD = $TnK9g;
        goto TO68L;
        cV4hA:
        $this->Y8BXM = $N50om;
        goto q0WVj;
        TO68L:
    }
    public function muC09Jkb6rX()
    {
        goto imHy2;
        tDV_G:
        $Ahfya = $this->Mq65A->getClient();
        goto VpP8U;
        n0F_k:
        $this->Y8BXM->mKnU1KBXWBI($wN8_0);
        goto UXPKl;
        LDExw:
        $this->Mq65A->put($this->Y8BXM->mjQ6d2ONI6n(), json_encode($this->Y8BXM->mbu93E3v49T()->toArray()));
        goto ah506;
        cQDsy:
        $CSwjw = $Ahfya->createPresignedRequest($CB9Z9, '+1 day');
        goto c1bFM;
        VQ35I:
        if (!(0 === $G4taM->count())) {
            goto pBCAq;
        }
        goto tpEHX;
        mJ5ua:
        $x3S11 = 1;
        goto Ll7CU;
        tpEHX:
        throw new PgAGQxNuMG4nF("Failed to create multipart upload for file {$this->Y8BXM->getFile()->getFilename()}, S3 return empty response");
        goto WEijU;
        imHy2:
        $yqV2Y = $this->Y8BXM->mbu93E3v49T();
        goto Xu8nY;
        HTHHl:
        if (!($x3S11 <= $sNRyE)) {
            goto I20br;
        }
        goto ChPjR;
        zehDE:
        I20br:
        goto n0F_k;
        iXj1r:
        My_70:
        goto Ljghx;
        Xu8nY:
        $wN8_0 = [];
        goto O58CO;
        Ljghx:
        ++$x3S11;
        goto u7Vw5;
        WEijU:
        pBCAq:
        goto mJ5ua;
        ChPjR:
        $CB9Z9 = $Ahfya->getCommand('UploadPart', ['Bucket' => $this->iqyyD, 'Key' => $this->Y8BXM->getFile()->getLocation(), 'UploadId' => $G4taM['UploadId'], 'PartNumber' => $x3S11]);
        goto cQDsy;
        VpP8U:
        $G4taM = $Ahfya->createMultipartUpload(['Bucket' => $this->iqyyD, 'Key' => $this->Y8BXM->getFile()->getLocation(), 'ContentType' => $this->Y8BXM->mbu93E3v49T()->B4WH4, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto VQ35I;
        Ll7CU:
        D8H2Y:
        goto HTHHl;
        O58CO:
        $sNRyE = ceil($yqV2Y->i917H / $yqV2Y->LHc1a);
        goto tDV_G;
        UXPKl:
        $this->Y8BXM->mbu93E3v49T()->mqcvRZvfhlP($G4taM['UploadId']);
        goto aXCQ7;
        u7Vw5:
        goto D8H2Y;
        goto zehDE;
        aXCQ7:
        $this->UBJ9G->put($this->Y8BXM->mjQ6d2ONI6n(), json_encode($this->Y8BXM->mbu93E3v49T()->toArray()));
        goto LDExw;
        c1bFM:
        $wN8_0[] = ['index' => $x3S11, 'url' => (string) $CSwjw->getUri()];
        goto iXj1r;
        ah506:
    }
    public function mac8rClbTBj() : void
    {
        goto Kf06Z;
        Kf06Z:
        $Ahfya = $this->Mq65A->getClient();
        goto Y8Ntv;
        Y8Ntv:
        try {
            $Ahfya->abortMultipartUpload(['Bucket' => $this->iqyyD, 'Key' => $this->Y8BXM->getFile()->getLocation(), 'UploadId' => $this->Y8BXM->mbu93E3v49T()->mIA_S]);
        } catch (\Throwable $I8puu) {
            throw new AiOjz36jlc8a3("Failed to abort multipart upload of file {$this->Y8BXM->getFile()->getFilename()}", 0, $I8puu);
        }
        goto WAfNT;
        Fwj7Z:
        $this->Mq65A->delete($this->Y8BXM->mjQ6d2ONI6n());
        goto XiyDC;
        WAfNT:
        $this->UBJ9G->delete($this->Y8BXM->mjQ6d2ONI6n());
        goto Fwj7Z;
        XiyDC:
    }
    public function mdZHRNgOwob() : void
    {
        goto Otcgz;
        rD811:
        foreach ($ec0ac as $fGxTz) {
            goto HWyAw;
            n4XXK:
            JfPKC:
            goto wY9FT;
            Kp3e3:
            $BY1H3 = $d3lds[$XtMUZ];
            goto l6R54;
            HWyAw:
            $XtMUZ = $fGxTz['partNumber'];
            goto Kp3e3;
            l6R54:
            if (!($BY1H3['eTag'] !== $fGxTz['eTag'])) {
                goto JfPKC;
            }
            goto orrQl;
            orrQl:
            throw new DvjM23NaGNvwG("Checksum mismatch for part {$XtMUZ} of file {$this->Y8BXM->getFile()->getFilename()}");
            goto n4XXK;
            wY9FT:
            bhtym:
            goto DnOOY;
            DnOOY:
        }
        goto bq0AL;
        kc9XO:
        $Ahfya = $this->Mq65A->getClient();
        goto dRShs;
        bq0AL:
        Ate1f:
        goto kc9XO;
        mtlTk:
        Assert::eq(count($IDZ5l), count($ec0ac), 'The number of parts and checksums must match.');
        goto tNLwN;
        tNLwN:
        $d3lds = collect($IDZ5l)->keyBy('partNumber');
        goto rD811;
        Otcgz:
        $yqV2Y = $this->Y8BXM->mbu93E3v49T();
        goto rr5JB;
        dRShs:
        try {
            $Ahfya->completeMultipartUpload(['Bucket' => $this->iqyyD, 'Key' => $this->Y8BXM->getFile()->getLocation(), 'UploadId' => $this->Y8BXM->mbu93E3v49T()->mIA_S, 'MultipartUpload' => ['Parts' => collect($this->Y8BXM->mbu93E3v49T()->r9Pau)->sortBy('partNumber')->map(fn($BY1H3) => ['ETag' => $BY1H3['eTag'], 'PartNumber' => $BY1H3['partNumber']])->toArray()]]);
        } catch (\Throwable $I8puu) {
            throw new DvjM23NaGNvwG("Failed to merge chunks of file {$this->Y8BXM->getFile()->getFilename()}", 0, $I8puu);
        }
        goto ANsCn;
        rr5JB:
        $IDZ5l = $yqV2Y->r9Pau;
        goto Hx50O;
        Hx50O:
        $ec0ac = $yqV2Y->AY7wK;
        goto mtlTk;
        ANsCn:
    }
}
