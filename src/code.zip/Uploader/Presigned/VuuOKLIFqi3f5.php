<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\FALKOA7AcL69a;
use Jfs\Uploader\Exception\QdPczZB5KzxIi;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Presigned\ZZnTlbvYCGhQk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class VuuOKLIFqi3f5 implements ZZnTlbvYCGhQk
{
    private static $Xex9r = 'chunks/';
    private $JWVa8;
    private $SIeOC;
    private $s7iRq;
    public function __construct(FALKOA7AcL69a $wfCxx, Filesystem $Ay4fJ, Filesystem $UC1Qe)
    {
        goto TU5NX;
        TU5NX:
        $this->JWVa8 = $wfCxx;
        goto EWSb4;
        l6hYI:
        $this->s7iRq = $UC1Qe;
        goto cc_Yy;
        EWSb4:
        $this->SIeOC = $Ay4fJ;
        goto l6hYI;
        cc_Yy:
    }
    public function m009zDRe4t4() : void
    {
        goto JYLoz;
        C4ujk:
        $voLkM = 1;
        goto fnUHY;
        eGlpn:
        $hKqqZ = parse_url($NTSvS, PHP_URL_PATH);
        goto suLAp;
        cYloC:
        $n_04A = ceil($CLKCW->u5y3E / $CLKCW->sfiTQ);
        goto nN9g6;
        XDVfQ:
        o1Wg6:
        goto nFnps;
        TkvXS:
        $jkS7D[] = ['index' => $voLkM, 'url' => $cJBZI];
        goto xA_70;
        suLAp:
        $UK_fb = parse_url($NTSvS, PHP_URL_HOST);
        goto dpCVI;
        sCb7o:
        ++$voLkM;
        goto eWZAL;
        nFnps:
        $this->JWVa8->mLsCeGjrqf2($jkS7D);
        goto TXrI5;
        PS_P8:
        $this->SIeOC->put($this->JWVa8->mvoG00rB8tY(), json_encode($this->JWVa8->mvAZkBgf9bv()->toArray()));
        goto NBbBk;
        fnUHY:
        jEVWj:
        goto bgMeN;
        nN9g6:
        $b2o4e = $CLKCW->filename;
        goto c0CS0;
        dpCVI:
        $cJBZI = 'https://' . $UK_fb . '/' . ltrim($hKqqZ, '/');
        goto TkvXS;
        xA_70:
        IHTnP:
        goto sCb7o;
        bgMeN:
        if (!($voLkM <= $n_04A)) {
            goto o1Wg6;
        }
        goto d24Ey;
        d9IEW:
        $jkS7D = [];
        goto cYloC;
        eWZAL:
        goto jEVWj;
        goto XDVfQ;
        d24Ey:
        $NTSvS = route('upload.api.local_chunk.upload', ['uploadId' => $b2o4e, 'index' => $voLkM]);
        goto eGlpn;
        NBbBk:
        $this->s7iRq->put($this->JWVa8->mvoG00rB8tY(), json_encode($this->JWVa8->mvAZkBgf9bv()->toArray()));
        goto pxMcX;
        c0CS0:
        $this->JWVa8->mvAZkBgf9bv()->moZF5p29pbi($b2o4e);
        goto C4ujk;
        TXrI5:
        $this->JWVa8->mvAZkBgf9bv()->moZF5p29pbi($b2o4e);
        goto PS_P8;
        JYLoz:
        $CLKCW = $this->JWVa8->mvAZkBgf9bv();
        goto d9IEW;
        pxMcX:
    }
    public function mAOPUkkIZjS() : void
    {
        goto qTaCp;
        n_942:
        $this->SIeOC->deleteDirectory(self::$Xex9r . $b2o4e);
        goto YgeQO;
        qTaCp:
        $CLKCW = $this->JWVa8->mvAZkBgf9bv();
        goto HUmRT;
        YgeQO:
        $this->s7iRq->delete($this->JWVa8->mvoG00rB8tY());
        goto rSiKL;
        HUmRT:
        $b2o4e = $CLKCW->ohWsi;
        goto n_942;
        rSiKL:
    }
    public function mNOO3VgsKs7() : void
    {
        goto Ftccj;
        vJDIP:
        $n_04A = $CLKCW->jxdb6;
        goto IbHP1;
        SkDRJ:
        if (chmod($h7HO0, 0644)) {
            goto mj4yq;
        }
        goto Z2FDO;
        CfxWL:
        $whDL4 = $this->JWVa8->getFile()->getLocation();
        goto QncAL;
        vEM7f:
        $NCAMh = $this->SIeOC->path($whDL4);
        goto GIBoP;
        PIB13:
        $this->SIeOC->deleteDirectory($yhAQR);
        goto BnGlp;
        XxMlZ:
        mj4yq:
        goto PIB13;
        Crzwn:
        throw new QdPczZB5KzxIi('Local chunk can not merge file (can create file): ' . $NCAMh);
        goto ypZ5u;
        rHpd3:
        if (!(false === $Q7c6R)) {
            goto igpi4;
        }
        goto Crzwn;
        uF96O:
        $Gvxy5 = dirname($whDL4);
        goto A3_Vb;
        Ftccj:
        $CLKCW = $this->JWVa8->mvAZkBgf9bv();
        goto vJDIP;
        Z2FDO:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $h7HO0);
        goto wNT9a;
        JP2m6:
        Assert::eq(count($a_9Wq), $n_04A, 'The number of parts and checksums must match.');
        goto aWBAe;
        yrMTo:
        foreach ($a_9Wq as $o0Hb_) {
            goto IdHoo;
            AKd_5:
            if (!(false === $mnUdb)) {
                goto RYRms;
            }
            goto w53wX;
            QcG8D:
            fclose($mnUdb);
            goto pXA7c;
            ndm_p:
            $mnUdb = @fopen($SKAlf, 'rb');
            goto AKd_5;
            cEzk0:
            throw new QdPczZB5KzxIi('A chunk file content can not copy: ' . $SKAlf);
            goto Zckfg;
            XsaCC:
            RYRms:
            goto Yco0h;
            w53wX:
            throw new QdPczZB5KzxIi('A chunk file not existed: ' . $SKAlf);
            goto XsaCC;
            Yco0h:
            $AYibl = stream_copy_to_stream($mnUdb, $Q7c6R);
            goto QcG8D;
            NFPr3:
            d_8Ht:
            goto q3Qcn;
            pXA7c:
            if (!(false === $AYibl)) {
                goto Ydasd;
            }
            goto cEzk0;
            IdHoo:
            $SKAlf = $this->SIeOC->path($o0Hb_);
            goto ndm_p;
            Zckfg:
            Ydasd:
            goto NFPr3;
            q3Qcn:
        }
        goto y3068;
        A3_Vb:
        if ($this->SIeOC->exists($Gvxy5)) {
            goto Ir2Uy;
        }
        goto DNsU8;
        IbHP1:
        $yhAQR = self::$Xex9r . $CLKCW->ohWsi;
        goto CfxWL;
        Ppd0p:
        $h7HO0 = $this->SIeOC->path($whDL4);
        goto SkDRJ;
        GIBoP:
        touch($NCAMh);
        goto bpwLF;
        wNT9a:
        throw new \Exception('Failed to set file permissions for stored image: ' . $h7HO0);
        goto XxMlZ;
        ypZ5u:
        igpi4:
        goto yrMTo;
        bpwLF:
        $Q7c6R = @fopen($NCAMh, 'wb');
        goto rHpd3;
        DNsU8:
        $this->SIeOC->makeDirectory($Gvxy5);
        goto OGpC1;
        y3068:
        xNzm2:
        goto yDq81;
        aWBAe:
        natsort($a_9Wq);
        goto uF96O;
        OGpC1:
        Ir2Uy:
        goto vEM7f;
        QncAL:
        $a_9Wq = $this->SIeOC->files($yhAQR);
        goto JP2m6;
        yDq81:
        fclose($Q7c6R);
        goto Ppd0p;
        BnGlp:
    }
}
