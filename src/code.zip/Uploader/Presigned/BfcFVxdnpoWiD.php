<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use src\Uploader\Core\HU7bCai77CgrB;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Exception\XCOswXJIkJ0Ex;
use src\Uploader\Presigned\IYgqj7b3EHs5P;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class BfcFVxdnpoWiD implements IYgqj7b3EHs5P
{
    private static $iaia2 = 'chunks/';
    private $RkCAT;
    private $SiK3b;
    private $TDmz_;
    public function __construct(HU7bCai77CgrB $kmQTT, Filesystem $eX8wo, Filesystem $RustJ)
    {
        goto IGZEx;
        nPMfT:
        $this->SiK3b = $eX8wo;
        goto MvdHt;
        MvdHt:
        $this->TDmz_ = $RustJ;
        goto NOoIh;
        IGZEx:
        $this->RkCAT = $kmQTT;
        goto nPMfT;
        NOoIh:
    }
    public function mGzsNnTbqgx() : void
    {
        goto CZtKH;
        jHF3o:
        $this->RkCAT->mN5M3gzjZ92($vI41B);
        goto URYLQ;
        KOZF8:
        $izYGq = ceil($rEWu2->dXNxw / $rEWu2->I5jem);
        goto uugu0;
        raHxy:
        ++$nX65E;
        goto c9nOs;
        eu3gc:
        $nX65E = 1;
        goto CDCRU;
        uugu0:
        $bkvvg = Uuid::v4()->toHex();
        goto O_UlY;
        knd9b:
        $vI41B = [];
        goto KOZF8;
        BFZDd:
        $this->TDmz_->put($this->RkCAT->mk8mOnWi1YG(), json_encode($this->RkCAT->mH4ZGE0jflN()->toArray()));
        goto QFOBk;
        c9nOs:
        goto ehkxp;
        goto rWdbo;
        iNr1Q:
        if (!($nX65E <= $izYGq)) {
            goto qfO1S;
        }
        goto jWDr_;
        jBVrW:
        $this->SiK3b->put($this->RkCAT->mk8mOnWi1YG(), json_encode($this->RkCAT->mH4ZGE0jflN()->toArray()));
        goto BFZDd;
        O_UlY:
        $this->RkCAT->mH4ZGE0jflN()->mrkxryvGEcX($bkvvg);
        goto eu3gc;
        URYLQ:
        $this->RkCAT->mH4ZGE0jflN()->mrkxryvGEcX($bkvvg);
        goto jBVrW;
        jWDr_:
        $vI41B[] = ['index' => $nX65E, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $bkvvg, 'index' => $nX65E])];
        goto ulX42;
        CDCRU:
        ehkxp:
        goto iNr1Q;
        CZtKH:
        $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
        goto knd9b;
        ulX42:
        Z7572:
        goto raHxy;
        rWdbo:
        qfO1S:
        goto jHF3o;
        QFOBk:
    }
    public function mI5hbVUBG4S() : void
    {
        goto Edko9;
        JrZfE:
        $this->SiK3b->deleteDirectory(self::$iaia2 . $bkvvg);
        goto NHBgh;
        NHBgh:
        $this->TDmz_->delete($this->RkCAT->mk8mOnWi1YG());
        goto guHLm;
        Q80Vo:
        $bkvvg = $rEWu2->hNgeS;
        goto JrZfE;
        Edko9:
        $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
        goto Q80Vo;
        guHLm:
    }
    public function ml4R7rGsjxd() : void
    {
        goto o6uWj;
        Fwte7:
        sdRdx:
        goto mKh3Q;
        EIJO5:
        if (chmod($xzWfp, 0644)) {
            goto sdRdx;
        }
        goto PdpnA;
        jSSiA:
        $gJSDS = $this->SiK3b->path($JzQUy);
        goto Ewjpa;
        PtsAS:
        GOeqv:
        goto kyBEG;
        Nke1t:
        fclose($ASlmC);
        goto j07sy;
        PdpnA:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $xzWfp);
        goto zn0Qq;
        kyBEG:
        foreach ($tDSGB as $s8Xcn) {
            goto F6Kvq;
            F6Kvq:
            $ysfeA = $this->SiK3b->path($s8Xcn);
            goto mLyKX;
            zGhOv:
            $SbqPn = stream_copy_to_stream($ZDVMO, $ASlmC);
            goto vFv5a;
            vFv5a:
            fclose($ZDVMO);
            goto Fo08E;
            XINsb:
            EmzMg:
            goto GkiWE;
            Js69T:
            tbFwX:
            goto XINsb;
            Fo08E:
            if (!(false === $SbqPn)) {
                goto tbFwX;
            }
            goto cVYF3;
            Yi3NU:
            if (!(false === $ZDVMO)) {
                goto CHH9b;
            }
            goto brmIW;
            cXyMJ:
            CHH9b:
            goto zGhOv;
            mLyKX:
            $ZDVMO = @fopen($ysfeA, 'rb');
            goto Yi3NU;
            cVYF3:
            throw new XCOswXJIkJ0Ex('A chunk file content can not copy: ' . $ysfeA);
            goto Js69T;
            brmIW:
            throw new XCOswXJIkJ0Ex('A chunk file not existed: ' . $ysfeA);
            goto cXyMJ;
            GkiWE:
        }
        goto kETE1;
        dfoPd:
        $UtV2S = dirname($JzQUy);
        goto pb13L;
        v9Sxj:
        $JzQUy = $this->RkCAT->getFile()->getLocation();
        goto WrR5l;
        mXnz3:
        Assert::eq(count($tDSGB), $izYGq, 'The number of parts and checksums must match.');
        goto wtmWz;
        Ewjpa:
        touch($gJSDS);
        goto ziHtc;
        ziHtc:
        $ASlmC = @fopen($gJSDS, 'wb');
        goto OdgLx;
        pb13L:
        if ($this->SiK3b->exists($UtV2S)) {
            goto SQBbY;
        }
        goto tGD9P;
        zn0Qq:
        throw new \Exception('Failed to set file permissions for stored image: ' . $xzWfp);
        goto Fwte7;
        j07sy:
        $xzWfp = $this->SiK3b->path($JzQUy);
        goto EIJO5;
        OdgLx:
        if (!(false === $ASlmC)) {
            goto GOeqv;
        }
        goto fWdBN;
        tGD9P:
        $this->SiK3b->makeDirectory($UtV2S);
        goto Ky_Wj;
        XL8Wr:
        $v3Gk3 = self::$iaia2 . $rEWu2->hNgeS;
        goto v9Sxj;
        Ky_Wj:
        SQBbY:
        goto jSSiA;
        mKh3Q:
        $this->SiK3b->deleteDirectory($v3Gk3);
        goto XPkJK;
        o6uWj:
        $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
        goto LCLDG;
        wtmWz:
        natsort($tDSGB);
        goto dfoPd;
        fWdBN:
        throw new XCOswXJIkJ0Ex('Local chunk can not merge file (can create file): ' . $gJSDS);
        goto PtsAS;
        WrR5l:
        $tDSGB = $this->SiK3b->files($v3Gk3);
        goto mXnz3;
        LCLDG:
        $izYGq = $rEWu2->f6ZsI;
        goto XL8Wr;
        kETE1:
        egRk9:
        goto Nke1t;
        XPkJK:
    }
}
