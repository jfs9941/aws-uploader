<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\S3bwZBI8SlQQZ;
use Jfs\Uploader\Exception\M3YuEfc3kK1YW;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Presigned\JlkAnpr9pgOn4;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Z5jtHfGiVfu9s implements JlkAnpr9pgOn4
{
    private static $su41i = 'chunks/';
    private $xcd12;
    private $hhcR1;
    private $GkraP;
    public function __construct(S3bwZBI8SlQQZ $GNrIm, Filesystem $nQYui, Filesystem $jkGKh)
    {
        goto bCuIk;
        KE3O7:
        $this->hhcR1 = $nQYui;
        goto JdQCi;
        JdQCi:
        $this->GkraP = $jkGKh;
        goto Syo8f;
        bCuIk:
        $this->xcd12 = $GNrIm;
        goto KE3O7;
        Syo8f:
    }
    public function mcbEWNLqf0J() : void
    {
        goto EzlnK;
        EzlnK:
        $apROX = $this->xcd12->mAorhKFxc5x();
        goto p_LGz;
        h6Tj2:
        $this->xcd12->mAorhKFxc5x()->mRlC7I4fyfy($n7tqz);
        goto vyZfL;
        YI_14:
        $UrE8Q = parse_url($AJp4R, PHP_URL_HOST);
        goto dsnj8;
        p_LGz:
        $Fa_MX = [];
        goto lxQG0;
        lxQG0:
        $i5tAd = ceil($apROX->BeHax / $apROX->qTTdh);
        goto a9vpY;
        tL0Tw:
        $this->xcd12->mzghmmo0YQO($Fa_MX);
        goto h6Tj2;
        TLjIR:
        goto W0iHs;
        goto Zhr6j;
        a9vpY:
        $n7tqz = $apROX->filename;
        goto L1U5h;
        WGHSM:
        $ibpeb = 1;
        goto Xq5cc;
        Xq5cc:
        W0iHs:
        goto ioLMj;
        J_hiw:
        $this->GkraP->put($this->xcd12->mwo8AmZgP7W(), json_encode($this->xcd12->mAorhKFxc5x()->toArray()));
        goto crbid;
        Ltaye:
        ++$ibpeb;
        goto TLjIR;
        L1U5h:
        $this->xcd12->mAorhKFxc5x()->mRlC7I4fyfy($n7tqz);
        goto WGHSM;
        vyZfL:
        $this->hhcR1->put($this->xcd12->mwo8AmZgP7W(), json_encode($this->xcd12->mAorhKFxc5x()->toArray()));
        goto J_hiw;
        dsnj8:
        $JpoGg = 'https://' . $UrE8Q . '/' . ltrim($uMpUA, '/');
        goto JxVmJ;
        kCECr:
        $uMpUA = parse_url($AJp4R, PHP_URL_PATH);
        goto YI_14;
        ioLMj:
        if (!($ibpeb <= $i5tAd)) {
            goto fM39k;
        }
        goto fUCFc;
        mnaaD:
        MI8UT:
        goto Ltaye;
        fUCFc:
        $AJp4R = route('upload.api.local_chunk.upload', ['uploadId' => $n7tqz, 'index' => $ibpeb]);
        goto kCECr;
        Zhr6j:
        fM39k:
        goto tL0Tw;
        JxVmJ:
        $Fa_MX[] = ['index' => $ibpeb, 'url' => $JpoGg];
        goto mnaaD;
        crbid:
    }
    public function mGQrr1bb2uz() : void
    {
        goto ooKn7;
        uhUQd:
        $n7tqz = $apROX->qzKnH;
        goto ALdGc;
        NGCZj:
        $this->GkraP->delete($this->xcd12->mwo8AmZgP7W());
        goto yD8BX;
        ALdGc:
        $this->hhcR1->deleteDirectory(self::$su41i . $n7tqz);
        goto NGCZj;
        ooKn7:
        $apROX = $this->xcd12->mAorhKFxc5x();
        goto uhUQd;
        yD8BX:
    }
    public function mExpa4HytOM() : void
    {
        goto Cyxti;
        vQGmv:
        fclose($mnpPv);
        goto rLPfx;
        sT8Qg:
        $O78pg = dirname($amWyZ);
        goto wAFr7;
        KUuuR:
        $h6xwd = self::$su41i . $apROX->qzKnH;
        goto Tg2tR;
        kYUs4:
        $i5tAd = $apROX->ibBJk;
        goto KUuuR;
        HRnvi:
        $x9URJ = $this->hhcR1->files($h6xwd);
        goto Ek2BB;
        Ek2BB:
        Assert::eq(count($x9URJ), $i5tAd, 'The number of parts and checksums must match.');
        goto votub;
        k1bd1:
        m_Fi2:
        goto xeulG;
        wpoRX:
        throw new \Exception('Failed to set file permissions for stored image: ' . $PwdAa);
        goto O03i_;
        Cyxti:
        $apROX = $this->xcd12->mAorhKFxc5x();
        goto kYUs4;
        PzoAS:
        if (chmod($PwdAa, 0644)) {
            goto cKn6m;
        }
        goto mldeR;
        Uez1Q:
        $mnpPv = @fopen($w7XCQ, 'wb');
        goto IzU7x;
        wAFr7:
        if ($this->hhcR1->exists($O78pg)) {
            goto eVUzT;
        }
        goto LNWJE;
        GqMco:
        $this->hhcR1->deleteDirectory($h6xwd);
        goto DKV8Y;
        LNWJE:
        $this->hhcR1->makeDirectory($O78pg);
        goto AOB6a;
        AOB6a:
        eVUzT:
        goto YtFEC;
        xeulG:
        foreach ($x9URJ as $fwi19) {
            goto U5bWg;
            lApy9:
            throw new M3YuEfc3kK1YW('A chunk file content can not copy: ' . $geFPw);
            goto WzDhd;
            vW1z0:
            fclose($fNUF3);
            goto gMJKC;
            g2X8q:
            RDh92:
            goto kHpbe;
            gMJKC:
            if (!(false === $M13VF)) {
                goto LINQu;
            }
            goto lApy9;
            WzDhd:
            LINQu:
            goto DoUud;
            KsmKX:
            if (!(false === $fNUF3)) {
                goto RDh92;
            }
            goto PLblE;
            PLblE:
            throw new M3YuEfc3kK1YW('A chunk file not existed: ' . $geFPw);
            goto g2X8q;
            BWxMt:
            $fNUF3 = @fopen($geFPw, 'rb');
            goto KsmKX;
            kHpbe:
            $M13VF = stream_copy_to_stream($fNUF3, $mnpPv);
            goto vW1z0;
            U5bWg:
            $geFPw = $this->hhcR1->path($fwi19);
            goto BWxMt;
            DoUud:
            kF0yr:
            goto tujgC;
            tujgC:
        }
        goto SVud8;
        f2WSD:
        touch($w7XCQ);
        goto Uez1Q;
        Tg2tR:
        $amWyZ = $this->xcd12->getFile()->getLocation();
        goto HRnvi;
        SVud8:
        Df1bJ:
        goto vQGmv;
        YJIL1:
        throw new M3YuEfc3kK1YW('Local chunk can not merge file (can create file): ' . $w7XCQ);
        goto k1bd1;
        YtFEC:
        $w7XCQ = $this->hhcR1->path($amWyZ);
        goto f2WSD;
        rLPfx:
        $PwdAa = $this->hhcR1->path($amWyZ);
        goto PzoAS;
        votub:
        natsort($x9URJ);
        goto sT8Qg;
        O03i_:
        cKn6m:
        goto GqMco;
        mldeR:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $PwdAa);
        goto wpoRX;
        IzU7x:
        if (!(false === $mnpPv)) {
            goto m_Fi2;
        }
        goto YJIL1;
        DKV8Y:
    }
}
