<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\JxGHPMjqmk9TF;
use Jfs\Uploader\Exception\J6ezhygd351oD;
use Jfs\Uploader\Exception\MOUR9efsbk01P;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Exception\KfurTM3ey9V72;
use Jfs\Uploader\Presigned\LARdlacdm9Riz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class LjAgPhObx7wlI implements LARdlacdm9Riz
{
    private $sxfrv;
    private $BX0zD;
    private $lIJMo;
    private $p_blM;
    public function __construct(JxGHPMjqmk9TF $Gauo2, Filesystem $MKJ1D, Filesystem $niM9V, string $b7Jn7)
    {
        goto AUUIk;
        vzWJi:
        $this->BX0zD = $MKJ1D;
        goto qlAcO;
        qlAcO:
        $this->lIJMo = $niM9V;
        goto Lo0Ij;
        AUUIk:
        $this->sxfrv = $Gauo2;
        goto vzWJi;
        Lo0Ij:
        $this->p_blM = $b7Jn7;
        goto VqriR;
        VqriR:
    }
    public function m3iQcvvYamH()
    {
        goto tmA0b;
        oS_X9:
        $vFfCI = $this->lIJMo->getClient();
        goto UnpBW;
        K5Bp6:
        $UbzPE = $vFfCI->createPresignedRequest($hCUQo, '+1 day');
        goto m5SHX;
        sApfd:
        $this->sxfrv->mU5hpD7riBK()->mbFbYYzJZqu($EF1_E['UploadId']);
        goto VL3v4;
        hqfTK:
        rTcv4:
        goto Ojmex;
        UnpBW:
        $EF1_E = $vFfCI->createMultipartUpload(['Bucket' => $this->p_blM, 'Key' => $this->sxfrv->getFile()->getLocation(), 'ContentType' => $this->sxfrv->mU5hpD7riBK()->e0lpa, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto JKBIL;
        Ojmex:
        ++$OGWXQ;
        goto HDLru;
        HDLru:
        goto vPIs4;
        goto sKxhb;
        tmA0b:
        $bxW1r = $this->sxfrv->mU5hpD7riBK();
        goto FDazw;
        CM8CP:
        vPIs4:
        goto geVJr;
        JKBIL:
        if (!(0 === $EF1_E->count())) {
            goto HEpgd;
        }
        goto RjTv6;
        zudaX:
        $VlNtM = ceil($bxW1r->dOKnU / $bxW1r->EZNZh);
        goto oS_X9;
        SWH22:
        $hCUQo = $vFfCI->getCommand('UploadPart', ['Bucket' => $this->p_blM, 'Key' => $this->sxfrv->getFile()->getLocation(), 'UploadId' => $EF1_E['UploadId'], 'PartNumber' => $OGWXQ]);
        goto K5Bp6;
        b3_7a:
        $OGWXQ = 1;
        goto CM8CP;
        sKxhb:
        LWUKQ:
        goto DUGlf;
        m5SHX:
        $wS8JH[] = ['index' => $OGWXQ, 'url' => (string) $UbzPE->getUri()];
        goto hqfTK;
        RjTv6:
        throw new KfurTM3ey9V72("Failed to create multipart upload for file {$this->sxfrv->getFile()->getFilename()}, S3 return empty response");
        goto VvbRX;
        FDazw:
        $wS8JH = [];
        goto zudaX;
        VL3v4:
        $this->BX0zD->put($this->sxfrv->mOcpDPbRfUf(), json_encode($this->sxfrv->mU5hpD7riBK()->toArray()));
        goto kzjx4;
        VvbRX:
        HEpgd:
        goto b3_7a;
        kzjx4:
        $this->lIJMo->put($this->sxfrv->mOcpDPbRfUf(), json_encode($this->sxfrv->mU5hpD7riBK()->toArray()));
        goto SlbDm;
        DUGlf:
        $this->sxfrv->mnUNm6Udcoe($wS8JH);
        goto sApfd;
        geVJr:
        if (!($OGWXQ <= $VlNtM)) {
            goto LWUKQ;
        }
        goto SWH22;
        SlbDm:
    }
    public function ml8hDFcte5I() : void
    {
        goto NAoOd;
        NAoOd:
        $vFfCI = $this->lIJMo->getClient();
        goto klJJ_;
        inU6q:
        $this->BX0zD->delete($this->sxfrv->mOcpDPbRfUf());
        goto rqWXS;
        klJJ_:
        try {
            $vFfCI->abortMultipartUpload(['Bucket' => $this->p_blM, 'Key' => $this->sxfrv->getFile()->getLocation(), 'UploadId' => $this->sxfrv->mU5hpD7riBK()->Za_0M]);
        } catch (\Throwable $Fa7Tp) {
            throw new J6ezhygd351oD("Failed to abort multipart upload of file {$this->sxfrv->getFile()->getFilename()}", 0, $Fa7Tp);
        }
        goto inU6q;
        rqWXS:
        $this->lIJMo->delete($this->sxfrv->mOcpDPbRfUf());
        goto ozJsa;
        ozJsa:
    }
    public function myrPRPm7Nb8() : void
    {
        goto nx0wP;
        Lw28E:
        Assert::eq(count($vZh2W), count($kXmjN), 'The number of parts and checksums must match.');
        goto qMToC;
        BLlaQ:
        $vFfCI = $this->lIJMo->getClient();
        goto jGrvj;
        jGrvj:
        try {
            $vFfCI->completeMultipartUpload(['Bucket' => $this->p_blM, 'Key' => $this->sxfrv->getFile()->getLocation(), 'UploadId' => $this->sxfrv->mU5hpD7riBK()->Za_0M, 'MultipartUpload' => ['Parts' => collect($this->sxfrv->mU5hpD7riBK()->oZY1d)->sortBy('partNumber')->map(fn($eZzM0) => ['ETag' => $eZzM0['eTag'], 'PartNumber' => $eZzM0['partNumber']])->toArray()]]);
        } catch (\Throwable $Fa7Tp) {
            throw new MOUR9efsbk01P("Failed to merge chunks of file {$this->sxfrv->getFile()->getFilename()}", 0, $Fa7Tp);
        }
        goto ohpXW;
        V2p6E:
        swJ0c:
        goto BLlaQ;
        nx0wP:
        $bxW1r = $this->sxfrv->mU5hpD7riBK();
        goto Zr_Tv;
        hkVn3:
        $kXmjN = $bxW1r->lezR9;
        goto Lw28E;
        Zr_Tv:
        $vZh2W = $bxW1r->oZY1d;
        goto hkVn3;
        qMToC:
        $F2o9d = collect($vZh2W)->keyBy('partNumber');
        goto LJu6l;
        LJu6l:
        foreach ($kXmjN as $QkdJZ) {
            goto zorMg;
            Gmc1q:
            if (!($eZzM0['eTag'] !== $QkdJZ['eTag'])) {
                goto Vqqa_;
            }
            goto KuRAt;
            mb_DH:
            FJ88v:
            goto XUiF8;
            KuRAt:
            throw new MOUR9efsbk01P("Checksum mismatch for part {$ivGCh} of file {$this->sxfrv->getFile()->getFilename()}");
            goto hjlOT;
            pg5A8:
            $eZzM0 = $F2o9d[$ivGCh];
            goto Gmc1q;
            hjlOT:
            Vqqa_:
            goto mb_DH;
            zorMg:
            $ivGCh = $QkdJZ['partNumber'];
            goto pg5A8;
            XUiF8:
        }
        goto V2p6E;
        ohpXW:
    }
}
