<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\McnafHoTolEIL;
use Jfs\Uploader\Exception\NXYrsLyaCsn8r;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Presigned\DRBONvY8dDfAQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class KL695pUGU8EfA implements DRBONvY8dDfAQ
{
    private static $P5vHJ = 'chunks/';
    private $BOb2P;
    private $Ybatl;
    private $sKQBJ;
    public function __construct(McnafHoTolEIL $LlwTr, Filesystem $FHlTP, Filesystem $F1Ry9)
    {
        goto lXTLk;
        lXTLk:
        $this->BOb2P = $LlwTr;
        goto XVKvV;
        XVKvV:
        $this->Ybatl = $FHlTP;
        goto eeQr9;
        eeQr9:
        $this->sKQBJ = $F1Ry9;
        goto fBrzd;
        fBrzd:
    }
    public function m9GbYa671CI() : void
    {
        goto w5KPC;
        N0OE1:
        $cCJRo[] = ['index' => $Vf4A7, 'url' => $tAFKu];
        goto ayKwh;
        Uom8j:
        $cCJRo = [];
        goto o8j78;
        fOVht:
        $this->BOb2P->mZ6EamKZD6W($cCJRo);
        goto QkE3u;
        CVl7H:
        if (!($Vf4A7 <= $B9Jbt)) {
            goto sg86G;
        }
        goto yUK7O;
        glC37:
        Nqjgr:
        goto CVl7H;
        ayKwh:
        Ud7ze:
        goto uExkO;
        uExkO:
        ++$Vf4A7;
        goto qkoX3;
        zTMmH:
        $this->sKQBJ->put($this->BOb2P->mGhxMypxkPu(), json_encode($this->BOb2P->muHFWbWFrae()->toArray()));
        goto CSqEI;
        QkE3u:
        $this->BOb2P->muHFWbWFrae()->mZjQHk2Fi8R($PcG1p);
        goto tRCmQ;
        Zsg1f:
        $Vf4A7 = 1;
        goto glC37;
        tRCmQ:
        $this->Ybatl->put($this->BOb2P->mGhxMypxkPu(), json_encode($this->BOb2P->muHFWbWFrae()->toArray()));
        goto zTMmH;
        o8j78:
        $B9Jbt = ceil($MCnj4->aU_jI / $MCnj4->na8lq);
        goto IgCP8;
        rBnW7:
        $tAFKu = 'https://' . $rm73B . '/' . ltrim($K_YMm, '/');
        goto N0OE1;
        JMqvG:
        $this->BOb2P->muHFWbWFrae()->mZjQHk2Fi8R($PcG1p);
        goto Zsg1f;
        YM3Sh:
        $rm73B = parse_url($HPvn1, PHP_URL_HOST);
        goto rBnW7;
        Dl2P2:
        $K_YMm = parse_url($HPvn1, PHP_URL_PATH);
        goto YM3Sh;
        IgCP8:
        $PcG1p = $MCnj4->filename;
        goto JMqvG;
        yUK7O:
        $HPvn1 = route('upload.api.local_chunk.upload', ['uploadId' => $PcG1p, 'index' => $Vf4A7]);
        goto Dl2P2;
        qkoX3:
        goto Nqjgr;
        goto JqD0C;
        w5KPC:
        $MCnj4 = $this->BOb2P->muHFWbWFrae();
        goto Uom8j;
        JqD0C:
        sg86G:
        goto fOVht;
        CSqEI:
    }
    public function mBKuVbQuVRa() : void
    {
        goto M5vtu;
        MwW4u:
        $this->Ybatl->deleteDirectory(self::$P5vHJ . $PcG1p);
        goto SVEFc;
        SVEFc:
        $this->sKQBJ->delete($this->BOb2P->mGhxMypxkPu());
        goto sm2lv;
        f7L58:
        $PcG1p = $MCnj4->rAZCi;
        goto MwW4u;
        M5vtu:
        $MCnj4 = $this->BOb2P->muHFWbWFrae();
        goto f7L58;
        sm2lv:
    }
    public function mJlaumzyHgb() : void
    {
        goto nGVTb;
        WURvL:
        $o8ynY = self::$P5vHJ . $MCnj4->rAZCi;
        goto a47ji;
        v5Bk2:
        $B9Jbt = $MCnj4->NLwkr;
        goto WURvL;
        yn9TL:
        qcA8f:
        goto f3HDk;
        nGVTb:
        $MCnj4 = $this->BOb2P->muHFWbWFrae();
        goto v5Bk2;
        lGLci:
        $eeYq_ = $this->Ybatl->path($d12GO);
        goto zSjXf;
        nkgJG:
        foreach ($qgdlr as $RQ4fA) {
            goto bpq8T;
            c1XMD:
            if (!(false === $Nz0JV)) {
                goto uXPJj;
            }
            goto BbDnD;
            nSV9l:
            LSycq:
            goto rh6Bl;
            Xfs8M:
            $Nz0JV = @fopen($Hok2o, 'rb');
            goto c1XMD;
            ChXi2:
            if (!(false === $K0ZtC)) {
                goto J0zCy;
            }
            goto DdBdo;
            W4NrQ:
            uXPJj:
            goto tvfLG;
            teZex:
            J0zCy:
            goto nSV9l;
            BbDnD:
            throw new NXYrsLyaCsn8r('A chunk file not existed: ' . $Hok2o);
            goto W4NrQ;
            hMxaO:
            fclose($Nz0JV);
            goto ChXi2;
            tvfLG:
            $K0ZtC = stream_copy_to_stream($Nz0JV, $W8Ccd);
            goto hMxaO;
            DdBdo:
            throw new NXYrsLyaCsn8r('A chunk file content can not copy: ' . $Hok2o);
            goto teZex;
            bpq8T:
            $Hok2o = $this->Ybatl->path($RQ4fA);
            goto Xfs8M;
            rh6Bl:
        }
        goto smBl3;
        j6L7h:
        throw new NXYrsLyaCsn8r('Local chunk can not merge file (can create file): ' . $eeYq_);
        goto tPV2Q;
        OgMAR:
        Assert::eq(count($qgdlr), $B9Jbt, 'The number of parts and checksums must match.');
        goto YT_hc;
        Nxobq:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $v0KVo);
        goto Yfb3z;
        Htz6o:
        $v0KVo = $this->Ybatl->path($d12GO);
        goto XVZt7;
        j_ZO1:
        $W8Ccd = @fopen($eeYq_, 'wb');
        goto tvO8k;
        Yfb3z:
        throw new \Exception('Failed to set file permissions for stored image: ' . $v0KVo);
        goto yn9TL;
        kXSkJ:
        fclose($W8Ccd);
        goto Htz6o;
        f3HDk:
        $this->Ybatl->deleteDirectory($o8ynY);
        goto DpaGo;
        smBl3:
        omY0B:
        goto kXSkJ;
        eKoiA:
        $qgdlr = $this->Ybatl->files($o8ynY);
        goto OgMAR;
        XVZt7:
        if (chmod($v0KVo, 0644)) {
            goto qcA8f;
        }
        goto Nxobq;
        hvFfG:
        $this->Ybatl->makeDirectory($spKMt);
        goto Qmrm6;
        Qmrm6:
        NyYwf:
        goto lGLci;
        tPV2Q:
        D4720:
        goto nkgJG;
        tvO8k:
        if (!(false === $W8Ccd)) {
            goto D4720;
        }
        goto j6L7h;
        a47ji:
        $d12GO = $this->BOb2P->getFile()->getLocation();
        goto eKoiA;
        ZX6JZ:
        if ($this->Ybatl->exists($spKMt)) {
            goto NyYwf;
        }
        goto hvFfG;
        iZLA0:
        $spKMt = dirname($d12GO);
        goto ZX6JZ;
        zSjXf:
        touch($eeYq_);
        goto j_ZO1;
        YT_hc:
        natsort($qgdlr);
        goto iZLA0;
        DpaGo:
    }
}
