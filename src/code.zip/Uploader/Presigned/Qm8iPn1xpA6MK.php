<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\I9eXouytPf2zH;
use Jfs\Uploader\Exception\DvjM23NaGNvwG;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Qm8iPn1xpA6MK implements CyAoKfbD7nMu5
{
    private static $tCBm0 = 'chunks/';
    private $Y8BXM;
    private $UBJ9G;
    private $Mq65A;
    public function __construct(I9eXouytPf2zH $N50om, Filesystem $e1L33, Filesystem $o9ClE)
    {
        goto mZmDP;
        mZmDP:
        $this->Y8BXM = $N50om;
        goto RIBuI;
        RIBuI:
        $this->UBJ9G = $e1L33;
        goto xUoZI;
        xUoZI:
        $this->Mq65A = $o9ClE;
        goto lP9UF;
        lP9UF:
    }
    public function muC09Jkb6rX() : void
    {
        goto Qta0x;
        dYS0M:
        $this->Y8BXM->mbu93E3v49T()->mqcvRZvfhlP($y1uXc);
        goto fPzqV;
        fPzqV:
        $x3S11 = 1;
        goto NWSL_;
        q3VcO:
        $this->Mq65A->put($this->Y8BXM->mjQ6d2ONI6n(), json_encode($this->Y8BXM->mbu93E3v49T()->toArray()));
        goto drOk4;
        h0LxN:
        $y1uXc = Uuid::v4()->toHex();
        goto dYS0M;
        tFTiF:
        $this->Y8BXM->mbu93E3v49T()->mqcvRZvfhlP($y1uXc);
        goto hXUyt;
        dZUXh:
        $this->Y8BXM->mKnU1KBXWBI($wN8_0);
        goto tFTiF;
        FPRuo:
        zukiT:
        goto dZUXh;
        Qta0x:
        $yqV2Y = $this->Y8BXM->mbu93E3v49T();
        goto sNPy_;
        sNPy_:
        $wN8_0 = [];
        goto jW68H;
        hXUyt:
        $this->UBJ9G->put($this->Y8BXM->mjQ6d2ONI6n(), json_encode($this->Y8BXM->mbu93E3v49T()->toArray()));
        goto q3VcO;
        IzZqt:
        if (!($x3S11 <= $sNRyE)) {
            goto zukiT;
        }
        goto ot83f;
        jW68H:
        $sNRyE = ceil($yqV2Y->i917H / $yqV2Y->LHc1a);
        goto h0LxN;
        NWSL_:
        HXfsR:
        goto IzZqt;
        QSLvv:
        ++$x3S11;
        goto m9y6l;
        m9y6l:
        goto HXfsR;
        goto FPRuo;
        wWOtb:
        WLou2:
        goto QSLvv;
        ot83f:
        $wN8_0[] = ['index' => $x3S11, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $y1uXc, 'index' => $x3S11])];
        goto wWOtb;
        drOk4:
    }
    public function mac8rClbTBj() : void
    {
        goto gmec0;
        gmec0:
        $yqV2Y = $this->Y8BXM->mbu93E3v49T();
        goto MsdP0;
        MsdP0:
        $y1uXc = $yqV2Y->mIA_S;
        goto DPnkJ;
        LxMFr:
        $this->Mq65A->delete($this->Y8BXM->mjQ6d2ONI6n());
        goto oHsLj;
        DPnkJ:
        $this->UBJ9G->deleteDirectory(self::$tCBm0 . $y1uXc);
        goto LxMFr;
        oHsLj:
    }
    public function mdZHRNgOwob() : void
    {
        goto ztus5;
        WAI3e:
        $Ik15m = @fopen($XIV3f, 'wb');
        goto qzLDK;
        nlaSs:
        throw new DvjM23NaGNvwG('Local chunk can not merge file (can create file): ' . $XIV3f);
        goto JQxUl;
        CVOhT:
        yln8I:
        goto ol2mE;
        JUdr1:
        throw new \Exception('Failed to set file permissions for stored image: ' . $BP5jC);
        goto CVOhT;
        dMK7V:
        $hfXj2 = dirname($zyUtP);
        goto YZ6zJ;
        NBz32:
        $XIV3f = $this->UBJ9G->path($zyUtP);
        goto xQD77;
        M61Be:
        $zatTl = $this->UBJ9G->files($hSGmT);
        goto SEphs;
        UIpi9:
        natsort($zatTl);
        goto dMK7V;
        koiec:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $BP5jC);
        goto JUdr1;
        low0L:
        $this->UBJ9G->makeDirectory($hfXj2);
        goto ieCjh;
        ZAI5D:
        $zyUtP = $this->Y8BXM->getFile()->getLocation();
        goto M61Be;
        ol2mE:
        $this->UBJ9G->deleteDirectory($hSGmT);
        goto s5yLb;
        JQxUl:
        e0Mya:
        goto Bxo2O;
        KGXDX:
        P0C17:
        goto A3Kcq;
        Bxo2O:
        foreach ($zatTl as $lslH6) {
            goto wXwSE;
            TlRs6:
            throw new DvjM23NaGNvwG('A chunk file content can not copy: ' . $kPic2);
            goto bucXm;
            wXwSE:
            $kPic2 = $this->UBJ9G->path($lslH6);
            goto EI2Tm;
            j132h:
            if (!(false === $PGtUq)) {
                goto Cn2h8;
            }
            goto TlRs6;
            Aj0F5:
            if (!(false === $qj633)) {
                goto KWLpU;
            }
            goto UC_yG;
            GhsVh:
            KWLpU:
            goto G2hC7;
            RzwTr:
            gfpRg:
            goto ekegF;
            UC_yG:
            throw new DvjM23NaGNvwG('A chunk file not existed: ' . $kPic2);
            goto GhsVh;
            EI2Tm:
            $qj633 = @fopen($kPic2, 'rb');
            goto Aj0F5;
            G2hC7:
            $PGtUq = stream_copy_to_stream($qj633, $Ik15m);
            goto uRf3Y;
            bucXm:
            Cn2h8:
            goto RzwTr;
            uRf3Y:
            fclose($qj633);
            goto j132h;
            ekegF:
        }
        goto KGXDX;
        xQD77:
        touch($XIV3f);
        goto WAI3e;
        QdhW6:
        $BP5jC = $this->UBJ9G->path($zyUtP);
        goto B9koo;
        YZ6zJ:
        if ($this->UBJ9G->exists($hfXj2)) {
            goto JqLq5;
        }
        goto low0L;
        ieCjh:
        JqLq5:
        goto NBz32;
        ztus5:
        $yqV2Y = $this->Y8BXM->mbu93E3v49T();
        goto aTOFe;
        A3Kcq:
        fclose($Ik15m);
        goto QdhW6;
        qzLDK:
        if (!(false === $Ik15m)) {
            goto e0Mya;
        }
        goto nlaSs;
        aTOFe:
        $sNRyE = $yqV2Y->Qbrmb;
        goto LTYcQ;
        SEphs:
        Assert::eq(count($zatTl), $sNRyE, 'The number of parts and checksums must match.');
        goto UIpi9;
        LTYcQ:
        $hSGmT = self::$tCBm0 . $yqV2Y->mIA_S;
        goto ZAI5D;
        B9koo:
        if (chmod($BP5jC, 0644)) {
            goto yln8I;
        }
        goto koiec;
        s5yLb:
    }
}
