<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:22              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\ED7I8bwNqdusd;
use Jfs\Uploader\Exception\RaGvp4a3nFEqU;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Presigned\HtVuQ4B4NMn1d;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Y6cbPTDjBmUdV implements HtVuQ4B4NMn1d
{
    private static $PsCm1 = 'chunks/';
    private $YssWB;
    private $qqmnq;
    private $iIDXy;
    public function __construct(ED7I8bwNqdusd $lJ5H4, Filesystem $vS8UC, Filesystem $vKILS)
    {
        goto pT1Ay;
        sNN37:
        $this->iIDXy = $vKILS;
        goto KgVMw;
        pT1Ay:
        $this->YssWB = $lJ5H4;
        goto MjQLF;
        MjQLF:
        $this->qqmnq = $vS8UC;
        goto sNN37;
        KgVMw:
    }
    public function mY1nsrq2j7D() : void
    {
        goto OOLnX;
        dbBwl:
        $FG6si[] = ['index' => $yO0N5, 'url' => $frfAz];
        goto YFDUn;
        iXK_4:
        $iTIh6 = parse_url($KOZO4, PHP_URL_PATH);
        goto YXBea;
        blT0G:
        $FG6si = [];
        goto M1sgK;
        e21oG:
        $this->qqmnq->put($this->YssWB->mZx3Wns8jZm(), json_encode($this->YssWB->mvHStueAWqd()->toArray()));
        goto Z10_O;
        Imo3E:
        $this->YssWB->mvHStueAWqd()->m0xOxJ2PiV4($cH0Pn);
        goto yc9MR;
        lg1Af:
        $cH0Pn = $wt893->filename;
        goto Imo3E;
        YXBea:
        $frfAz = 'https://' . ltrim($iTIh6, '/');
        goto dbBwl;
        YFDUn:
        qtj0m:
        goto g4m0l;
        yc9MR:
        $yO0N5 = 1;
        goto yVNiv;
        DB8cc:
        $this->YssWB->m2ccRPZ5J1k($FG6si);
        goto MRw5G;
        M1sgK:
        $JIqfO = ceil($wt893->zJLxD / $wt893->Lmq3n);
        goto lg1Af;
        g4m0l:
        ++$yO0N5;
        goto AeDLh;
        Z10_O:
        $this->iIDXy->put($this->YssWB->mZx3Wns8jZm(), json_encode($this->YssWB->mvHStueAWqd()->toArray()));
        goto DNkJw;
        OOLnX:
        $wt893 = $this->YssWB->mvHStueAWqd();
        goto blT0G;
        yVNiv:
        j8m8a:
        goto kA7Zy;
        kA7Zy:
        if (!($yO0N5 <= $JIqfO)) {
            goto e3aV3;
        }
        goto btufC;
        btufC:
        $KOZO4 = route('upload.api.local_chunk.upload', ['uploadId' => $cH0Pn, 'index' => $yO0N5]);
        goto iXK_4;
        qrC_Y:
        e3aV3:
        goto DB8cc;
        MRw5G:
        $this->YssWB->mvHStueAWqd()->m0xOxJ2PiV4($cH0Pn);
        goto e21oG;
        AeDLh:
        goto j8m8a;
        goto qrC_Y;
        DNkJw:
    }
    public function mhhM9EUIOAf() : void
    {
        goto ECshH;
        PPmTD:
        $this->qqmnq->deleteDirectory(self::$PsCm1 . $cH0Pn);
        goto ZeU53;
        IDEgI:
        $cH0Pn = $wt893->ARR5y;
        goto PPmTD;
        ECshH:
        $wt893 = $this->YssWB->mvHStueAWqd();
        goto IDEgI;
        ZeU53:
        $this->iIDXy->delete($this->YssWB->mZx3Wns8jZm());
        goto UOrWB;
        UOrWB:
    }
    public function mnPGFoo0xg7() : void
    {
        goto YhgLl;
        YhgLl:
        $wt893 = $this->YssWB->mvHStueAWqd();
        goto I1H8T;
        Rxzp3:
        f3vRs:
        goto fkF2O;
        SL_Bh:
        if (chmod($kb702, 0644)) {
            goto f1tK6;
        }
        goto c0STU;
        kIXq3:
        $this->qqmnq->makeDirectory($U3OyI);
        goto m0A93;
        nYHTA:
        natsort($UE89n);
        goto A0rKq;
        c0STU:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $kb702);
        goto Vh1wz;
        TJRCI:
        if (!(false === $TMdHB)) {
            goto f3vRs;
        }
        goto vdF2O;
        XHcPE:
        $RvVgF = $this->qqmnq->path($x699o);
        goto x6WXX;
        NL5z0:
        Assert::eq(count($UE89n), $JIqfO, 'The number of parts and checksums must match.');
        goto nYHTA;
        x6WXX:
        touch($RvVgF);
        goto Bn91a;
        SwM4h:
        $UE89n = $this->qqmnq->files($IJpua);
        goto NL5z0;
        I1H8T:
        $JIqfO = $wt893->SYIMu;
        goto vi0on;
        Bn91a:
        $TMdHB = @fopen($RvVgF, 'wb');
        goto TJRCI;
        vdF2O:
        throw new RaGvp4a3nFEqU('Local chunk can not merge file (can create file): ' . $RvVgF);
        goto Rxzp3;
        NKLSl:
        ehLir:
        goto VPLru;
        X2Z3C:
        $this->qqmnq->deleteDirectory($IJpua);
        goto q3kaP;
        yZEmD:
        if ($this->qqmnq->exists($U3OyI)) {
            goto gMaoG;
        }
        goto kIXq3;
        YEs25:
        $kb702 = $this->qqmnq->path($x699o);
        goto SL_Bh;
        fkF2O:
        foreach ($UE89n as $dtute) {
            goto yrd7w;
            F0uqk:
            $Qqdyb = stream_copy_to_stream($n_Zcu, $TMdHB);
            goto ZJGZG;
            tXq2y:
            cXdmc:
            goto odSUQ;
            MkWSo:
            throw new RaGvp4a3nFEqU('A chunk file not existed: ' . $QVIec);
            goto Nahmv;
            hMSkB:
            throw new RaGvp4a3nFEqU('A chunk file content can not copy: ' . $QVIec);
            goto tXq2y;
            Nahmv:
            QRNL1:
            goto F0uqk;
            s1NNH:
            $n_Zcu = @fopen($QVIec, 'rb');
            goto EGvnu;
            EGvnu:
            if (!(false === $n_Zcu)) {
                goto QRNL1;
            }
            goto MkWSo;
            odSUQ:
            xmnB3:
            goto zq2O0;
            ZJGZG:
            fclose($n_Zcu);
            goto VuN5W;
            yrd7w:
            $QVIec = $this->qqmnq->path($dtute);
            goto s1NNH;
            VuN5W:
            if (!(false === $Qqdyb)) {
                goto cXdmc;
            }
            goto hMSkB;
            zq2O0:
        }
        goto NKLSl;
        Vh1wz:
        throw new \Exception('Failed to set file permissions for stored image: ' . $kb702);
        goto TkGpk;
        m0A93:
        gMaoG:
        goto XHcPE;
        A0rKq:
        $U3OyI = dirname($x699o);
        goto yZEmD;
        vi0on:
        $IJpua = self::$PsCm1 . $wt893->ARR5y;
        goto YGAoE;
        VPLru:
        fclose($TMdHB);
        goto YEs25;
        TkGpk:
        f1tK6:
        goto X2Z3C;
        YGAoE:
        $x699o = $this->YssWB->getFile()->getLocation();
        goto SwM4h;
        q3kaP:
    }
}
