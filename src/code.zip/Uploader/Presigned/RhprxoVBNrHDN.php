<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\FALKOA7AcL69a;
use Jfs\Uploader\Exception\PPL3aFv7g3oFc;
use Jfs\Uploader\Exception\QdPczZB5KzxIi;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Exception\RzK6k3gPv110U;
use Jfs\Uploader\Presigned\ZZnTlbvYCGhQk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class RhprxoVBNrHDN implements ZZnTlbvYCGhQk
{
    private $JWVa8;
    private $SIeOC;
    private $s7iRq;
    private $PoRf3;
    public function __construct(FALKOA7AcL69a $wfCxx, Filesystem $Ay4fJ, Filesystem $UC1Qe, string $L2yxk)
    {
        goto b97f4;
        DdoVV:
        $this->PoRf3 = $L2yxk;
        goto GXzHy;
        z1RdZ:
        $this->s7iRq = $UC1Qe;
        goto DdoVV;
        b97f4:
        $this->JWVa8 = $wfCxx;
        goto mlwu3;
        mlwu3:
        $this->SIeOC = $Ay4fJ;
        goto z1RdZ;
        GXzHy:
    }
    public function m009zDRe4t4()
    {
        goto JZY2X;
        PassL:
        $this->SIeOC->put($this->JWVa8->mvoG00rB8tY(), json_encode($this->JWVa8->mvAZkBgf9bv()->toArray()));
        goto QaY3J;
        U2juO:
        $this->JWVa8->mvAZkBgf9bv()->moZF5p29pbi($HgLpI['UploadId']);
        goto PassL;
        BZNVo:
        if (!($voLkM <= $n_04A)) {
            goto Flh2v;
        }
        goto mP_Ad;
        pU1Ln:
        $voLkM = 1;
        goto hcn35;
        ULWRZ:
        if (!(0 === $HgLpI->count())) {
            goto H1kI4;
        }
        goto BWouG;
        QaY3J:
        $this->s7iRq->put($this->JWVa8->mvoG00rB8tY(), json_encode($this->JWVa8->mvAZkBgf9bv()->toArray()));
        goto IFpr3;
        Xk40a:
        $jkS7D = [];
        goto nDjxF;
        QXoHg:
        ++$voLkM;
        goto W2dns;
        f1RkZ:
        H1kI4:
        goto pU1Ln;
        BWouG:
        throw new RzK6k3gPv110U("Failed to create multipart upload for file {$this->JWVa8->getFile()->getFilename()}, S3 return empty response");
        goto f1RkZ;
        qOiUh:
        $this->JWVa8->mLsCeGjrqf2($jkS7D);
        goto U2juO;
        nDjxF:
        $n_04A = ceil($CLKCW->u5y3E / $CLKCW->sfiTQ);
        goto umOMw;
        Tjes2:
        P8q1p:
        goto QXoHg;
        zbU2Q:
        $lgORh = $PcTXE->createPresignedRequest($vO41M, '+1 day');
        goto JN0Du;
        ig7R1:
        Flh2v:
        goto qOiUh;
        hcn35:
        Cieg_:
        goto BZNVo;
        umOMw:
        $PcTXE = $this->s7iRq->getClient();
        goto PCQto;
        mP_Ad:
        $vO41M = $PcTXE->getCommand('UploadPart', ['Bucket' => $this->PoRf3, 'Key' => $this->JWVa8->getFile()->getLocation(), 'UploadId' => $HgLpI['UploadId'], 'PartNumber' => $voLkM]);
        goto zbU2Q;
        JZY2X:
        $CLKCW = $this->JWVa8->mvAZkBgf9bv();
        goto Xk40a;
        PCQto:
        $HgLpI = $PcTXE->createMultipartUpload(['Bucket' => $this->PoRf3, 'Key' => $this->JWVa8->getFile()->getLocation(), 'ContentType' => $this->JWVa8->mvAZkBgf9bv()->A1fRk, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto ULWRZ;
        W2dns:
        goto Cieg_;
        goto ig7R1;
        JN0Du:
        $jkS7D[] = ['index' => $voLkM, 'url' => (string) $lgORh->getUri()];
        goto Tjes2;
        IFpr3:
    }
    public function mAOPUkkIZjS() : void
    {
        goto PuHmV;
        s2kG3:
        $this->s7iRq->delete($this->JWVa8->mvoG00rB8tY());
        goto I3no4;
        jTAr9:
        $this->SIeOC->delete($this->JWVa8->mvoG00rB8tY());
        goto s2kG3;
        yjpri:
        try {
            $PcTXE->abortMultipartUpload(['Bucket' => $this->PoRf3, 'Key' => $this->JWVa8->getFile()->getLocation(), 'UploadId' => $this->JWVa8->mvAZkBgf9bv()->ohWsi]);
        } catch (\Throwable $bAo2Y) {
            throw new PPL3aFv7g3oFc("Failed to abort multipart upload of file {$this->JWVa8->getFile()->getFilename()}", 0, $bAo2Y);
        }
        goto jTAr9;
        PuHmV:
        $PcTXE = $this->s7iRq->getClient();
        goto yjpri;
        I3no4:
    }
    public function mNOO3VgsKs7() : void
    {
        goto JNtiH;
        HPBOV:
        try {
            $PcTXE->completeMultipartUpload(['Bucket' => $this->PoRf3, 'Key' => $this->JWVa8->getFile()->getLocation(), 'UploadId' => $this->JWVa8->mvAZkBgf9bv()->ohWsi, 'MultipartUpload' => ['Parts' => collect($this->JWVa8->mvAZkBgf9bv()->pZeeV)->sortBy('partNumber')->map(fn($busBA) => ['ETag' => $busBA['eTag'], 'PartNumber' => $busBA['partNumber']])->toArray()]]);
        } catch (\Throwable $bAo2Y) {
            throw new QdPczZB5KzxIi("Failed to merge chunks of file {$this->JWVa8->getFile()->getFilename()}", 0, $bAo2Y);
        }
        goto Q41A2;
        PY1uP:
        $FeFdM = $CLKCW->pZeeV;
        goto m6ceC;
        HHjKD:
        Assert::eq(count($FeFdM), count($mIRUV), 'The number of parts and checksums must match.');
        goto BUUPu;
        VRsOd:
        nZA1i:
        goto L1lkj;
        JNtiH:
        $CLKCW = $this->JWVa8->mvAZkBgf9bv();
        goto PY1uP;
        dNMdK:
        foreach ($mIRUV as $HMTde) {
            goto pewJg;
            FnwSb:
            $busBA = $DqzcF[$QHZUN];
            goto DMu7k;
            pewJg:
            $QHZUN = $HMTde['partNumber'];
            goto FnwSb;
            KPH8J:
            throw new QdPczZB5KzxIi("Checksum mismatch for part {$QHZUN} of file {$this->JWVa8->getFile()->getFilename()}");
            goto Oa4Tx;
            DMu7k:
            if (!($busBA['eTag'] !== $HMTde['eTag'])) {
                goto fYAuX;
            }
            goto KPH8J;
            gtaIO:
            DeWHG:
            goto viqk4;
            Oa4Tx:
            fYAuX:
            goto gtaIO;
            viqk4:
        }
        goto VRsOd;
        m6ceC:
        $mIRUV = $CLKCW->d29za;
        goto HHjKD;
        BUUPu:
        $DqzcF = collect($FeFdM)->keyBy('partNumber');
        goto dNMdK;
        L1lkj:
        $PcTXE = $this->s7iRq->getClient();
        goto HPBOV;
        Q41A2:
    }
}
