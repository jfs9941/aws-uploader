<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Presigned;

use Aws\S3\S3Client;
use backup\Uploader\Core\Pb0Dvv7XIOUP3;
use backup\Uploader\Exception\SGhi47InXq6sx;
use backup\Uploader\Exception\M7w1sfloneSV9;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Exception\TQH4srKtU6Knf;
use backup\Uploader\Presigned\LWtJtdk30E0vd;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class Cz1TtKJmFbr22 implements LWtJtdk30E0vd
{
    private $eZBRn;
    private $FJZRi;
    private $JINyv;
    private $tv4bE;
    public function __construct(Pb0Dvv7XIOUP3 $D5W64, Filesystem $UEDUm, Filesystem $s49oM, string $ClLup)
    {
        goto KXl6E;
        KXl6E:
        $this->eZBRn = $D5W64;
        goto qWycq;
        lG60J:
        $this->JINyv = $s49oM;
        goto CyKtq;
        qWycq:
        $this->FJZRi = $UEDUm;
        goto lG60J;
        CyKtq:
        $this->tv4bE = $ClLup;
        goto RzFZ2;
        RzFZ2:
    }
    public function mUNxSWNsvIU()
    {
        goto SdMjw;
        fBHN4:
        OQuQt:
        goto Mm_rq;
        KBGd9:
        $iG9RC = $kgFd6->createPresignedRequest($P3RMA, '+1 day');
        goto jes4t;
        Mm_rq:
        $YUcV3 = 1;
        goto RKtbI;
        D5Vo8:
        if (!($YUcV3 <= $xfmMu)) {
            goto TyZUR;
        }
        goto QbZ3M;
        RKtbI:
        blekm:
        goto D5Vo8;
        Ue3Up:
        goto blekm;
        goto JHwyD;
        JaGcs:
        $this->eZBRn->m77UJKssxZ5()->mrFQk9755s2($Pay5j['UploadId']);
        goto SpeZU;
        SdMjw:
        $JbFc7 = $this->eZBRn->m77UJKssxZ5();
        goto dnFky;
        dnFky:
        $sgukC = [];
        goto Gx8Pp;
        jarFj:
        $this->JINyv->put($this->eZBRn->mE8PPexbKCM(), json_encode($this->eZBRn->m77UJKssxZ5()->toArray()));
        goto WhGnu;
        QbZ3M:
        $P3RMA = $kgFd6->getCommand('UploadPart', ['Bucket' => $this->tv4bE, 'Key' => $this->eZBRn->getFile()->getLocation(), 'UploadId' => $Pay5j['UploadId'], 'PartNumber' => $YUcV3]);
        goto KBGd9;
        SpeZU:
        $this->FJZRi->put($this->eZBRn->mE8PPexbKCM(), json_encode($this->eZBRn->m77UJKssxZ5()->toArray()));
        goto jarFj;
        L_uXl:
        $kgFd6 = $this->JINyv->getClient();
        goto x1Le0;
        r3Hhq:
        throw new TQH4srKtU6Knf("Failed to create multipart upload for file {$this->eZBRn->getFile()->getFilename()}, S3 return empty response");
        goto fBHN4;
        jes4t:
        $sgukC[] = ['index' => $YUcV3, 'url' => (string) $iG9RC->getUri()];
        goto oNc4y;
        oNc4y:
        Vo6Cm:
        goto lgBlj;
        Gx8Pp:
        $xfmMu = ceil($JbFc7->AaaaP / $JbFc7->pc1aI);
        goto L_uXl;
        GNHs4:
        if (!(0 === $Pay5j->count())) {
            goto OQuQt;
        }
        goto r3Hhq;
        x1Le0:
        $Pay5j = $kgFd6->createMultipartUpload(['Bucket' => $this->tv4bE, 'Key' => $this->eZBRn->getFile()->getLocation(), 'ContentType' => $this->eZBRn->m77UJKssxZ5()->K2tYP, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto GNHs4;
        lgBlj:
        ++$YUcV3;
        goto Ue3Up;
        cmIz9:
        $this->eZBRn->mEXA8ft76kA($sgukC);
        goto JaGcs;
        JHwyD:
        TyZUR:
        goto cmIz9;
        WhGnu:
    }
    public function mKta32e3ZeL() : void
    {
        goto lYdqx;
        qSwz2:
        $this->FJZRi->delete($this->eZBRn->mE8PPexbKCM());
        goto PgHb9;
        cWqUx:
        try {
            $kgFd6->abortMultipartUpload(['Bucket' => $this->tv4bE, 'Key' => $this->eZBRn->getFile()->getLocation(), 'UploadId' => $this->eZBRn->m77UJKssxZ5()->ZvM_a]);
        } catch (\Throwable $eQXjs) {
            throw new SGhi47InXq6sx("Failed to abort multipart upload of file {$this->eZBRn->getFile()->getFilename()}", 0, $eQXjs);
        }
        goto qSwz2;
        PgHb9:
        $this->JINyv->delete($this->eZBRn->mE8PPexbKCM());
        goto mGT78;
        lYdqx:
        $kgFd6 = $this->JINyv->getClient();
        goto cWqUx;
        mGT78:
    }
    public function mluSWeny8it() : void
    {
        goto JUBZJ;
        Z43Ul:
        $znDRw = $JbFc7->L_mVC;
        goto pkpC9;
        pkpC9:
        Assert::eq(count($QIhb6), count($znDRw), 'The number of parts and checksums must match.');
        goto JsnMO;
        H1cOR:
        tdPHJ:
        goto mqQZw;
        Qx9fR:
        foreach ($znDRw as $bKzy3) {
            goto zauNa;
            x9hcF:
            t6Xu_:
            goto Qut7k;
            zauNa:
            $URCuF = $bKzy3['partNumber'];
            goto HSfT1;
            HSfT1:
            $t4gMc = $JV_VG[$URCuF];
            goto iB2Bs;
            PuMw2:
            throw new M7w1sfloneSV9("Checksum mismatch for part {$URCuF} of file {$this->eZBRn->getFile()->getFilename()}");
            goto V7oIG;
            iB2Bs:
            if (!($t4gMc['eTag'] !== $bKzy3['eTag'])) {
                goto B2SPh;
            }
            goto PuMw2;
            V7oIG:
            B2SPh:
            goto x9hcF;
            Qut7k:
        }
        goto H1cOR;
        yoSvn:
        $QIhb6 = $JbFc7->T7MaX;
        goto Z43Ul;
        mqQZw:
        $kgFd6 = $this->JINyv->getClient();
        goto P0qNA;
        JUBZJ:
        $JbFc7 = $this->eZBRn->m77UJKssxZ5();
        goto yoSvn;
        JsnMO:
        $JV_VG = collect($QIhb6)->keyBy('partNumber');
        goto Qx9fR;
        P0qNA:
        try {
            $kgFd6->completeMultipartUpload(['Bucket' => $this->tv4bE, 'Key' => $this->eZBRn->getFile()->getLocation(), 'UploadId' => $this->eZBRn->m77UJKssxZ5()->ZvM_a, 'MultipartUpload' => ['Parts' => collect($this->eZBRn->m77UJKssxZ5()->T7MaX)->sortBy('partNumber')->map(fn($t4gMc) => ['ETag' => $t4gMc['eTag'], 'PartNumber' => $t4gMc['partNumber']])->toArray()]]);
        } catch (\Throwable $eQXjs) {
            throw new M7w1sfloneSV9("Failed to merge chunks of file {$this->eZBRn->getFile()->getFilename()}", 0, $eQXjs);
        }
        goto LR80Z;
        LR80Z:
    }
}
