<?php
declare(strict_types=1);

namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\PreSignedModel;
use Jfs\Uploader\Exception\ChunkAbortException;
use Jfs\Uploader\Exception\ChunkMergeException;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Jfs\Uploader\Exception\S3ConfigException;
use Webmozart\Assert\Assert;

class S3PresignedUpload implements PresignedUploadInterface
{
    /**
     * @var PreSignedModel
     */
    private $preSignedModel;
    /**
     * @var Filesystem
     */
    private $localStorage;
    /**
     * @var Filesystem
     */
    private $s3Storage;
    private $bucket;

    public function __construct(
        PreSignedModel $preSignedModel,
        Filesystem $localStorage,
        Filesystem $s3Storage,
        string $bucket,
    ) {
        $this->preSignedModel = $preSignedModel;
        $this->localStorage = $localStorage;
        $this->s3Storage = $s3Storage;
        $this->bucket = $bucket;
    }

    public function generateUrls()
    {
        $metadata = $this->preSignedModel->metadata();
        $urls = [];
        $totalChunks = ceil($metadata->fileSize / $metadata->chunkSize);

        /** @var S3Client $s3Client */
        $s3Client = $this->s3Storage->getClient();

        $result = $s3Client->createMultipartUpload([
            'Bucket' => $this->bucket,
            'Key' => $this->preSignedModel->getFile()->getLocation(),
            'ContentType' => $this->preSignedModel->metadata()->mimeType,
            'ContentDisposition' => 'inline',
            'ACL' => 'public-read',
        ]);
        if (0 === $result->count()) {
            throw new S3ConfigException("Failed to create multipart upload for file {$this->preSignedModel->getFile()->getFilename()}, S3 return empty response");
        }
        for ($chunkIndex = 1; $chunkIndex <= $totalChunks; ++$chunkIndex) {
            $command = $s3Client->getCommand('UploadPart', [
                'Bucket' => $this->bucket,
                'Key' => $this->preSignedModel->getFile()->getLocation(),
                'UploadId' => $result['UploadId'],
                'PartNumber' => $chunkIndex,
            ]);

            $preSigned = $s3Client->createPresignedRequest($command, '+1 day');

            $urls[] = [
                'index' => $chunkIndex,
                'url' => (string) $preSigned->getUri(),
            ];
        }

        $this->preSignedModel->withTempUrls($urls);
        $this->preSignedModel->metadata()->setUploadId($result['UploadId']);

        $this->localStorage->put(
            $this->preSignedModel->metaDataFile(),
            json_encode($this->preSignedModel->metadata()->toArray())
        );
        // backup in s3
        $this->s3Storage->put(
            $this->preSignedModel->metaDataFile(),
            json_encode($this->preSignedModel->metadata()->toArray())
        );
    }

    public function abort(): void
    {
        // Get the S3 client instance
        /** @var S3Client $s3Client */
        $s3Client = $this->s3Storage->getClient();

        // Abort the multipart upload
        try {
            $s3Client->abortMultipartUpload([
                'Bucket' => $this->bucket,
                'Key' => $this->preSignedModel->getFile()->getLocation(),
                'UploadId' => $this->preSignedModel->metadata()->uploadId,
            ]);
        } catch (\Throwable $exception) {
            throw new ChunkAbortException("Failed to abort multipart upload of file {$this->preSignedModel->getFile()->getFilename()}", 0, $exception);
        }

        $this->localStorage->delete($this->preSignedModel->metaDataFile());
        $this->s3Storage->delete($this->preSignedModel->metaDataFile());
    }

    /**
     * @throws ChunkMergeException
     * @throws InvalidTempFileException
     */
    public function finish(): void
    {
        $metadata = $this->preSignedModel->metadata();
        $parts = $metadata->parts;
        $checksums = $metadata->checksums;
        // pre-validation
        Assert::eq(count($parts), count($checksums), 'The number of parts and checksums must match.');

        $s3Parts = collect($parts)->keyBy('partNumber');
        // Check if all checksums are valid
        foreach ($checksums as $checksum) {
            $partIndex = $checksum['partNumber'];
            $part = $s3Parts[$partIndex];

            if ($part['eTag'] !== $checksum['eTag']) {
                throw new ChunkMergeException("Checksum mismatch for part {$partIndex} of file {$this->preSignedModel->getFile()->getFilename()}");
            }
        }

        /** @var S3Client $s3Client */
        $s3Client = $this->s3Storage->getClient();
        try {
            $s3Client->completeMultipartUpload([
                'Bucket' => $this->bucket,
                'Key' => $this->preSignedModel->getFile()->getLocation(),
                'UploadId' => $this->preSignedModel->metadata()->uploadId,
                'MultipartUpload' => [
                    'Parts' => collect($this->preSignedModel->metadata()->parts)->sortBy('partNumber')->map(fn ($part) => [
                        'ETag' => $part['eTag'],
                        'PartNumber' => $part['partNumber'],
                    ])->toArray(),
                ],
            ]);
        } catch (\Throwable $exception) {
            throw new ChunkMergeException("Failed to merge chunks of file {$this->preSignedModel->getFile()->getFilename()}", 0, $exception);
        }
    }
}
