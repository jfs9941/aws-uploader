<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\TVInkZGE2Z8Ja;
use Jfs\Uploader\Exception\O56c61QWURh7L;
use Jfs\Uploader\Exception\XeSDn5fv42UKx;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Jfs\Uploader\Exception\RmBZO19TyciVL;
use Webmozart\Assert\Assert;
class DAvuKXtR9GtaY implements MdoDaYR0UPmor
{
    private $hpsHP;
    private $fodJQ;
    private $i9Sna;
    private $pBNm8;
    public function __construct(TVInkZGE2Z8Ja $y4PP7, Filesystem $nsgrL, Filesystem $moAxa, string $QEIhn)
    {
        goto bTR0V;
        TYD8J:
        $this->fodJQ = $nsgrL;
        goto Ar3yQ;
        bTR0V:
        $this->hpsHP = $y4PP7;
        goto TYD8J;
        lChcQ:
        $this->pBNm8 = $QEIhn;
        goto aW2Yp;
        Ar3yQ:
        $this->i9Sna = $moAxa;
        goto lChcQ;
        aW2Yp:
    }
    public function mKjsNob7bmV()
    {
        goto T4AM5;
        hKbfK:
        ftK1u:
        goto C1_6J;
        tipcr:
        $FL9qC = $TthJZ->createPresignedRequest($TtwRH, '+1 day');
        goto KFpLi;
        C1_6J:
        if (!($Jvwha <= $cejfY)) {
            goto PoVPI;
        }
        goto iU0Id;
        yxkeO:
        $TthJZ = $this->i9Sna->getClient();
        goto wfu4o;
        rnVFb:
        ++$Jvwha;
        goto Oc7Vb;
        KFpLi:
        $dZOow[] = ['index' => $Jvwha, 'url' => (string) $FL9qC->getUri()];
        goto Q5EzR;
        IdIzF:
        throw new RmBZO19TyciVL("Failed to create multipart upload for file {$this->hpsHP->getFile()->getFilename()}, S3 return empty response");
        goto bOV3E;
        wzyko:
        if (!(0 === $bZOiO->count())) {
            goto qlqIS;
        }
        goto IdIzF;
        Cx2IT:
        $this->fodJQ->put($this->hpsHP->mQA9EIajGk2(), json_encode($this->hpsHP->mlnKeX4eawe()->toArray()));
        goto c3s5B;
        fvVS0:
        $cejfY = ceil($xf_XV->msg3v / $xf_XV->hHmny);
        goto yxkeO;
        s1CSF:
        $this->hpsHP->mqoCm0UM5Os($dZOow);
        goto IV5XK;
        T0jbN:
        $dZOow = [];
        goto fvVS0;
        iU0Id:
        $TtwRH = $TthJZ->getCommand('UploadPart', ['Bucket' => $this->pBNm8, 'Key' => $this->hpsHP->getFile()->getLocation(), 'UploadId' => $bZOiO['UploadId'], 'PartNumber' => $Jvwha]);
        goto tipcr;
        Q5EzR:
        JxZTv:
        goto rnVFb;
        wfu4o:
        $bZOiO = $TthJZ->createMultipartUpload(['Bucket' => $this->pBNm8, 'Key' => $this->hpsHP->getFile()->getLocation(), 'ContentType' => $this->hpsHP->mlnKeX4eawe()->i3osF, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto wzyko;
        Oc7Vb:
        goto ftK1u;
        goto hOZoC;
        c3s5B:
        $this->i9Sna->put($this->hpsHP->mQA9EIajGk2(), json_encode($this->hpsHP->mlnKeX4eawe()->toArray()));
        goto kuU1x;
        bOV3E:
        qlqIS:
        goto hIKs3;
        hIKs3:
        $Jvwha = 1;
        goto hKbfK;
        IV5XK:
        $this->hpsHP->mlnKeX4eawe()->m1Z5hvqmFrV($bZOiO['UploadId']);
        goto Cx2IT;
        T4AM5:
        $xf_XV = $this->hpsHP->mlnKeX4eawe();
        goto T0jbN;
        hOZoC:
        PoVPI:
        goto s1CSF;
        kuU1x:
    }
    public function msMWIkXUKbG() : void
    {
        goto h2P1j;
        v5tA7:
        $this->i9Sna->delete($this->hpsHP->mQA9EIajGk2());
        goto bE9wO;
        TwP7E:
        try {
            $TthJZ->abortMultipartUpload(['Bucket' => $this->pBNm8, 'Key' => $this->hpsHP->getFile()->getLocation(), 'UploadId' => $this->hpsHP->mlnKeX4eawe()->HkGuv]);
        } catch (\Throwable $xlNa7) {
            throw new O56c61QWURh7L("Failed to abort multipart upload of file {$this->hpsHP->getFile()->getFilename()}", 0, $xlNa7);
        }
        goto X1NFT;
        X1NFT:
        $this->fodJQ->delete($this->hpsHP->mQA9EIajGk2());
        goto v5tA7;
        h2P1j:
        $TthJZ = $this->i9Sna->getClient();
        goto TwP7E;
        bE9wO:
    }
    public function mpcjuwrcLbZ() : void
    {
        goto Dkyn3;
        nwOag:
        $u2DUU = $xf_XV->S_YVI;
        goto kEVok;
        CFYTB:
        $RMUBb = collect($u2DUU)->keyBy('partNumber');
        goto RZsQ3;
        bpnpm:
        try {
            $TthJZ->completeMultipartUpload(['Bucket' => $this->pBNm8, 'Key' => $this->hpsHP->getFile()->getLocation(), 'UploadId' => $this->hpsHP->mlnKeX4eawe()->HkGuv, 'MultipartUpload' => ['Parts' => collect($this->hpsHP->mlnKeX4eawe()->S_YVI)->sortBy('partNumber')->map(fn($zlPn3) => ['ETag' => $zlPn3['eTag'], 'PartNumber' => $zlPn3['partNumber']])->toArray()]]);
        } catch (\Throwable $xlNa7) {
            throw new XeSDn5fv42UKx("Failed to merge chunks of file {$this->hpsHP->getFile()->getFilename()}", 0, $xlNa7);
        }
        goto AXsFf;
        uNIFN:
        VyCS_:
        goto BhXXx;
        kEVok:
        $QS28K = $xf_XV->GGRG2;
        goto r1D45;
        Dkyn3:
        $xf_XV = $this->hpsHP->mlnKeX4eawe();
        goto nwOag;
        r1D45:
        Assert::eq(count($u2DUU), count($QS28K), 'The number of parts and checksums must match.');
        goto CFYTB;
        BhXXx:
        $TthJZ = $this->i9Sna->getClient();
        goto bpnpm;
        RZsQ3:
        foreach ($QS28K as $NsVAd) {
            goto k3aqD;
            Eogsk:
            if (!($zlPn3['eTag'] !== $NsVAd['eTag'])) {
                goto eY0wj;
            }
            goto N_01d;
            N_01d:
            throw new XeSDn5fv42UKx("Checksum mismatch for part {$s9azB} of file {$this->hpsHP->getFile()->getFilename()}");
            goto WrVi2;
            k3aqD:
            $s9azB = $NsVAd['partNumber'];
            goto K_zPL;
            Nck7B:
            ue6XE:
            goto LdqpV;
            WrVi2:
            eY0wj:
            goto Nck7B;
            K_zPL:
            $zlPn3 = $RMUBb[$s9azB];
            goto Eogsk;
            LdqpV:
        }
        goto uNIFN;
        AXsFf:
    }
}
