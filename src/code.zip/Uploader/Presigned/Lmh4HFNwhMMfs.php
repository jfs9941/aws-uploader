<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\RQ9bDEqcUZdSJ;
use Jfs\Uploader\Exception\RDRYmywN95fGw;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Presigned\U1ZvgsGt0teMT;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Lmh4HFNwhMMfs implements U1ZvgsGt0teMT
{
    private static $HBycO = 'chunks/';
    private $Y6NCf;
    private $gcP3F;
    private $Ck8AK;
    public function __construct(RQ9bDEqcUZdSJ $HuGK_, Filesystem $qxxOf, Filesystem $P4KJD)
    {
        goto dyENJ;
        oTB1a:
        $this->gcP3F = $qxxOf;
        goto FJ3QY;
        dyENJ:
        $this->Y6NCf = $HuGK_;
        goto oTB1a;
        FJ3QY:
        $this->Ck8AK = $P4KJD;
        goto p5j_h;
        p5j_h:
    }
    public function mm4dJgrnW0N() : void
    {
        goto o04dn;
        OaBYu:
        $this->Y6NCf->mg099Xaz8Vo()->ma96A33591M($fa_xj);
        goto VetRW;
        ZAR9b:
        $vSpQ8 = 'https://' . $S_eCg . '/' . ltrim($lT4E3, '/');
        goto pgc0g;
        hI1u1:
        $R0pa8 = [];
        goto VQuV2;
        MUCuZ:
        goto pSXbI;
        goto g4nPr;
        aRVPm:
        $lT4E3 = parse_url($Y_JtS, PHP_URL_PATH);
        goto dVBsu;
        dVBsu:
        $S_eCg = parse_url($Y_JtS, PHP_URL_HOST);
        goto ZAR9b;
        g4nPr:
        uo293:
        goto bndhr;
        Iowza:
        if (!($gfw60 <= $MnHFq)) {
            goto uo293;
        }
        goto JsOOA;
        pgc0g:
        $R0pa8[] = ['index' => $gfw60, 'url' => $vSpQ8];
        goto aiysd;
        yedje:
        $this->Y6NCf->mg099Xaz8Vo()->ma96A33591M($fa_xj);
        goto lcomp;
        H6Wqh:
        pSXbI:
        goto Iowza;
        GSTIu:
        $this->Ck8AK->put($this->Y6NCf->mzDDruv07Tv(), json_encode($this->Y6NCf->mg099Xaz8Vo()->toArray()));
        goto QKnCQ;
        VQuV2:
        $MnHFq = ceil($LGjda->iGEiJ / $LGjda->c9RKE);
        goto WGKfy;
        lcomp:
        $this->gcP3F->put($this->Y6NCf->mzDDruv07Tv(), json_encode($this->Y6NCf->mg099Xaz8Vo()->toArray()));
        goto GSTIu;
        AH9zG:
        ++$gfw60;
        goto MUCuZ;
        o04dn:
        $LGjda = $this->Y6NCf->mg099Xaz8Vo();
        goto hI1u1;
        aiysd:
        Der5r:
        goto AH9zG;
        VetRW:
        $gfw60 = 1;
        goto H6Wqh;
        bndhr:
        $this->Y6NCf->mLUJMMpbAb4($R0pa8);
        goto yedje;
        WGKfy:
        $fa_xj = $LGjda->filename;
        goto OaBYu;
        JsOOA:
        $Y_JtS = route('upload.api.local_chunk.upload', ['uploadId' => $fa_xj, 'index' => $gfw60]);
        goto aRVPm;
        QKnCQ:
    }
    public function mCHqfrmH8l8() : void
    {
        goto nQ9oP;
        M_cp3:
        $this->gcP3F->deleteDirectory(self::$HBycO . $fa_xj);
        goto Q1hfH;
        nQ9oP:
        $LGjda = $this->Y6NCf->mg099Xaz8Vo();
        goto JMh56;
        Q1hfH:
        $this->Ck8AK->delete($this->Y6NCf->mzDDruv07Tv());
        goto cI3E_;
        JMh56:
        $fa_xj = $LGjda->Z1W73;
        goto M_cp3;
        cI3E_:
    }
    public function mLNNdTnrcAS() : void
    {
        goto PJK8z;
        yoURF:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $C8lPP);
        goto H13zu;
        hDyEI:
        $ztd5A = self::$HBycO . $LGjda->Z1W73;
        goto azbqH;
        SIp2K:
        throw new RDRYmywN95fGw('Local chunk can not merge file (can create file): ' . $A96_r);
        goto eue2r;
        uk2HG:
        natsort($SjC4a);
        goto ZUrbA;
        tb8m_:
        yE6dd:
        goto W5rkp;
        ZUrbA:
        $ns6ef = dirname($qnxhy);
        goto wgRg7;
        bZW08:
        $MnHFq = $LGjda->LjfYY;
        goto hDyEI;
        JDesD:
        $Ek3xY = @fopen($A96_r, 'wb');
        goto goBlf;
        wgRg7:
        if ($this->gcP3F->exists($ns6ef)) {
            goto Nv4ri;
        }
        goto m3Xuq;
        ElRGk:
        Nv4ri:
        goto wHqJI;
        l2kDP:
        N74Rb:
        goto VMACS;
        cizre:
        touch($A96_r);
        goto JDesD;
        W5rkp:
        $this->gcP3F->deleteDirectory($ztd5A);
        goto B0Cla;
        fBhxz:
        foreach ($SjC4a as $krykm) {
            goto n7gby;
            r83T2:
            $lYaxR = stream_copy_to_stream($vLxCG, $Ek3xY);
            goto S9Mtj;
            C3NEt:
            if (!(false === $lYaxR)) {
                goto FSSvJ;
            }
            goto coJ0Y;
            kGO9m:
            WyFT8:
            goto jSm9q;
            coJ0Y:
            throw new RDRYmywN95fGw('A chunk file content can not copy: ' . $jVYNR);
            goto Y5SR0;
            c82Nc:
            throw new RDRYmywN95fGw('A chunk file not existed: ' . $jVYNR);
            goto Bd8No;
            Bd8No:
            HQahS:
            goto r83T2;
            n7gby:
            $jVYNR = $this->gcP3F->path($krykm);
            goto bsE9e;
            Y5SR0:
            FSSvJ:
            goto kGO9m;
            DBeQi:
            if (!(false === $vLxCG)) {
                goto HQahS;
            }
            goto c82Nc;
            S9Mtj:
            fclose($vLxCG);
            goto C3NEt;
            bsE9e:
            $vLxCG = @fopen($jVYNR, 'rb');
            goto DBeQi;
            jSm9q:
        }
        goto l2kDP;
        wHqJI:
        $A96_r = $this->gcP3F->path($qnxhy);
        goto cizre;
        m3Xuq:
        $this->gcP3F->makeDirectory($ns6ef);
        goto ElRGk;
        rY4sY:
        $SjC4a = $this->gcP3F->files($ztd5A);
        goto qIoqF;
        azbqH:
        $qnxhy = $this->Y6NCf->getFile()->getLocation();
        goto rY4sY;
        RT4Up:
        $C8lPP = $this->gcP3F->path($qnxhy);
        goto NoSao;
        eue2r:
        DGyIG:
        goto fBhxz;
        VMACS:
        fclose($Ek3xY);
        goto RT4Up;
        qIoqF:
        Assert::eq(count($SjC4a), $MnHFq, 'The number of parts and checksums must match.');
        goto uk2HG;
        NoSao:
        if (chmod($C8lPP, 0644)) {
            goto yE6dd;
        }
        goto yoURF;
        H13zu:
        throw new \Exception('Failed to set file permissions for stored image: ' . $C8lPP);
        goto tb8m_;
        goBlf:
        if (!(false === $Ek3xY)) {
            goto DGyIG;
        }
        goto SIp2K;
        PJK8z:
        $LGjda = $this->Y6NCf->mg099Xaz8Vo();
        goto bZW08;
        B0Cla:
    }
}
