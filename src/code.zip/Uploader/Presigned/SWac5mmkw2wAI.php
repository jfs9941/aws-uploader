<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Eyra2OnsK5qBk;
use Jfs\Uploader\Exception\KTN2YBzTu35D5;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class SWac5mmkw2wAI implements OB3spYi3UHM7c
{
    private static $G7fO8 = 'chunks/';
    private $SjKWI;
    private $Lrwlv;
    private $OjeW5;
    public function __construct(Eyra2OnsK5qBk $Ry7nX, Filesystem $AhP23, Filesystem $A6wTz)
    {
        goto Q0Kc1;
        XTHeG:
        $this->Lrwlv = $AhP23;
        goto gtmLQ;
        gtmLQ:
        $this->OjeW5 = $A6wTz;
        goto esiJV;
        Q0Kc1:
        $this->SjKWI = $Ry7nX;
        goto XTHeG;
        esiJV:
    }
    public function mlbPU0TakFO() : void
    {
        goto aC5aA;
        cgy2N:
        $this->SjKWI->mROzB90pF6O()->mGmavrFr6gA($oKtdH);
        goto e2VMI;
        uwIWD:
        $y0umu = ceil($uJKYp->nPW_w / $uJKYp->drka7);
        goto aN3En;
        aN3En:
        $oKtdH = Uuid::v4()->toHex();
        goto cgy2N;
        j4ppg:
        $chyJc[] = ['index' => $v2kl4, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $oKtdH, 'index' => $v2kl4])];
        goto rXUh_;
        aQunn:
        $this->Lrwlv->put($this->SjKWI->mpi6jqATMm1(), json_encode($this->SjKWI->mROzB90pF6O()->toArray()));
        goto MWW4y;
        scCcM:
        ++$v2kl4;
        goto OmchI;
        e2VMI:
        $v2kl4 = 1;
        goto kNMmC;
        Vmpq1:
        Ee1h2:
        goto Cvuum;
        rXUh_:
        SGjOk:
        goto scCcM;
        BqUso:
        if (!($v2kl4 <= $y0umu)) {
            goto Ee1h2;
        }
        goto j4ppg;
        aC5aA:
        $uJKYp = $this->SjKWI->mROzB90pF6O();
        goto Y6oES;
        kNMmC:
        UzIbi:
        goto BqUso;
        OmchI:
        goto UzIbi;
        goto Vmpq1;
        MWW4y:
        $this->OjeW5->put($this->SjKWI->mpi6jqATMm1(), json_encode($this->SjKWI->mROzB90pF6O()->toArray()));
        goto XSCed;
        Y6oES:
        $chyJc = [];
        goto uwIWD;
        Cvuum:
        $this->SjKWI->mfrHpIeDbxs($chyJc);
        goto pJXNF;
        pJXNF:
        $this->SjKWI->mROzB90pF6O()->mGmavrFr6gA($oKtdH);
        goto aQunn;
        XSCed:
    }
    public function mqX3etBSfdy() : void
    {
        goto Wxj53;
        mOy8F:
        $this->OjeW5->delete($this->SjKWI->mpi6jqATMm1());
        goto XE7vf;
        YQt6G:
        $this->Lrwlv->deleteDirectory(self::$G7fO8 . $oKtdH);
        goto mOy8F;
        xVtHo:
        $oKtdH = $uJKYp->C33qk;
        goto YQt6G;
        Wxj53:
        $uJKYp = $this->SjKWI->mROzB90pF6O();
        goto xVtHo;
        XE7vf:
    }
    public function m8foZzm8MDN() : void
    {
        goto wxH57;
        PPBg2:
        $W1HjC = dirname($iZ4Fw);
        goto D0YQx;
        aiZTn:
        Assert::eq(count($SNPYi), $y0umu, 'The number of parts and checksums must match.');
        goto UyT6S;
        D0YQx:
        if ($this->Lrwlv->exists($W1HjC)) {
            goto ZVO5d;
        }
        goto Qr0Kl;
        DZBBb:
        touch($L1QCl);
        goto oMxcl;
        Z1GFT:
        throw new \Exception('Failed to set file permissions for stored image: ' . $IM5_2);
        goto IRmjR;
        ZtCvt:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $IM5_2);
        goto Z1GFT;
        Qr0Kl:
        $this->Lrwlv->makeDirectory($W1HjC);
        goto RkYhp;
        UyT6S:
        natsort($SNPYi);
        goto PPBg2;
        dW4Qt:
        fclose($vVUSv);
        goto lZd9x;
        oIqsq:
        $iZ4Fw = $this->SjKWI->getFile()->getLocation();
        goto YCztZ;
        psc0E:
        $this->Lrwlv->deleteDirectory($zQ5sx);
        goto UtAZs;
        P9Brw:
        if (chmod($IM5_2, 0644)) {
            goto wk5uP;
        }
        goto ZtCvt;
        WVhgD:
        foreach ($SNPYi as $CbWGV) {
            goto gQsFj;
            Q6oTv:
            CTUma:
            goto xJ82j;
            gQsFj:
            $YTzUU = $this->Lrwlv->path($CbWGV);
            goto rcSz9;
            Q6yaI:
            if (!(false === $jrzRl)) {
                goto xL88X;
            }
            goto Fq1Np;
            aV2GS:
            if (!(false === $pU9MQ)) {
                goto CTUma;
            }
            goto WCCii;
            xJ82j:
            $jrzRl = stream_copy_to_stream($pU9MQ, $vVUSv);
            goto FYDxw;
            rcSz9:
            $pU9MQ = @fopen($YTzUU, 'rb');
            goto aV2GS;
            Fq1Np:
            throw new KTN2YBzTu35D5('A chunk file content can not copy: ' . $YTzUU);
            goto Oi0tu;
            MYDrx:
            Zu11G:
            goto yALv6;
            Oi0tu:
            xL88X:
            goto MYDrx;
            WCCii:
            throw new KTN2YBzTu35D5('A chunk file not existed: ' . $YTzUU);
            goto Q6oTv;
            FYDxw:
            fclose($pU9MQ);
            goto Q6yaI;
            yALv6:
        }
        goto hj4wv;
        oMxcl:
        $vVUSv = @fopen($L1QCl, 'wb');
        goto M3SYz;
        hj4wv:
        z0E2P:
        goto dW4Qt;
        YCztZ:
        $SNPYi = $this->Lrwlv->files($zQ5sx);
        goto aiZTn;
        UvFDh:
        $L1QCl = $this->Lrwlv->path($iZ4Fw);
        goto DZBBb;
        er7Be:
        $y0umu = $uJKYp->EodgE;
        goto xnO2b;
        IRmjR:
        wk5uP:
        goto psc0E;
        c14_x:
        throw new KTN2YBzTu35D5('Local chunk can not merge file (can create file): ' . $L1QCl);
        goto FNFfZ;
        FNFfZ:
        Rzd8H:
        goto WVhgD;
        RkYhp:
        ZVO5d:
        goto UvFDh;
        lZd9x:
        $IM5_2 = $this->Lrwlv->path($iZ4Fw);
        goto P9Brw;
        xnO2b:
        $zQ5sx = self::$G7fO8 . $uJKYp->C33qk;
        goto oIqsq;
        wxH57:
        $uJKYp = $this->SjKWI->mROzB90pF6O();
        goto er7Be;
        M3SYz:
        if (!(false === $vVUSv)) {
            goto Rzd8H;
        }
        goto c14_x;
        UtAZs:
    }
}
