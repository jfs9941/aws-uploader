<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

interface K6ZN3VsCpjdRp
{
    public function m0nMpBVxEy8();
    public function mFoW1sWSEnz();
    public function m5hKOwPI9JJ();
}
