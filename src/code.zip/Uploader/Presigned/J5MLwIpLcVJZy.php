<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\T9ZXYI5O5GjGl;
use Jfs\Uploader\Exception\RT7PraDsizlHa;
use Jfs\Uploader\Exception\HWNR21Z34Dhkn;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Jfs\Uploader\Exception\AqgjETwv8R3dH;
use Webmozart\Assert\Assert;
class J5MLwIpLcVJZy implements K6ZN3VsCpjdRp
{
    private $xUsoB;
    private $kduDw;
    private $w2y98;
    private $Jc4z2;
    public function __construct(T9ZXYI5O5GjGl $B107M, Filesystem $h5ffz, Filesystem $uANLN, string $rhVEO)
    {
        goto P7yK7;
        P7yK7:
        $this->xUsoB = $B107M;
        goto OLYs9;
        o0J2d:
        $this->w2y98 = $uANLN;
        goto pUMkz;
        pUMkz:
        $this->Jc4z2 = $rhVEO;
        goto Mp4PE;
        OLYs9:
        $this->kduDw = $h5ffz;
        goto o0J2d;
        Mp4PE:
    }
    public function m0nMpBVxEy8()
    {
        goto ZJkpG;
        K4z4f:
        if (!($tGdfy <= $OlxWo)) {
            goto LCYnF;
        }
        goto y5iCo;
        ELrj2:
        if (!(0 === $QuGN9->count())) {
            goto tGsKn;
        }
        goto OfpWE;
        ZJkpG:
        $kvLls = $this->xUsoB->mew8rrjhK4U();
        goto owjYP;
        qyHj_:
        goto Esmah;
        goto kUjHo;
        J1HGE:
        $this->xUsoB->m47Oa9dYR1p($hj4FY);
        goto Net5l;
        Net5l:
        $this->xUsoB->mew8rrjhK4U()->m7PoIJeQDrB($QuGN9['UploadId']);
        goto OWTPq;
        OfpWE:
        throw new AqgjETwv8R3dH("Failed to create multipart upload for file {$this->xUsoB->getFile()->getFilename()}, S3 return empty response");
        goto a1lqn;
        d63UL:
        $kPAXd = $EXETx->createPresignedRequest($H3nx2, '+1 day');
        goto dlVYz;
        JzOQV:
        zixav:
        goto VkiJ8;
        R9g2A:
        Esmah:
        goto K4z4f;
        w2UIn:
        $OlxWo = ceil($kvLls->eD7KV / $kvLls->Xlwm2);
        goto lcx4G;
        a1lqn:
        tGsKn:
        goto Z5MLj;
        VkiJ8:
        ++$tGdfy;
        goto qyHj_;
        RHZWO:
        $QuGN9 = $EXETx->createMultipartUpload(['Bucket' => $this->Jc4z2, 'Key' => $this->xUsoB->getFile()->getLocation(), 'ContentType' => $this->xUsoB->mew8rrjhK4U()->UM7qO, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto ELrj2;
        lcx4G:
        $EXETx = $this->w2y98->getClient();
        goto RHZWO;
        Z5MLj:
        $tGdfy = 1;
        goto R9g2A;
        kUjHo:
        LCYnF:
        goto J1HGE;
        owjYP:
        $hj4FY = [];
        goto w2UIn;
        y5iCo:
        $H3nx2 = $EXETx->getCommand('UploadPart', ['Bucket' => $this->Jc4z2, 'Key' => $this->xUsoB->getFile()->getLocation(), 'UploadId' => $QuGN9['UploadId'], 'PartNumber' => $tGdfy]);
        goto d63UL;
        OWTPq:
        $this->kduDw->put($this->xUsoB->mGsd4uDsuKt(), json_encode($this->xUsoB->mew8rrjhK4U()->toArray()));
        goto oYXTT;
        oYXTT:
        $this->w2y98->put($this->xUsoB->mGsd4uDsuKt(), json_encode($this->xUsoB->mew8rrjhK4U()->toArray()));
        goto ZRj8p;
        dlVYz:
        $hj4FY[] = ['index' => $tGdfy, 'url' => (string) $kPAXd->getUri()];
        goto JzOQV;
        ZRj8p:
    }
    public function mFoW1sWSEnz() : void
    {
        goto G9ckd;
        J_XqD:
        $this->w2y98->delete($this->xUsoB->mGsd4uDsuKt());
        goto Ho2KS;
        Lf2hS:
        $this->kduDw->delete($this->xUsoB->mGsd4uDsuKt());
        goto J_XqD;
        G9ckd:
        $EXETx = $this->w2y98->getClient();
        goto Z3eim;
        Z3eim:
        try {
            $EXETx->abortMultipartUpload(['Bucket' => $this->Jc4z2, 'Key' => $this->xUsoB->getFile()->getLocation(), 'UploadId' => $this->xUsoB->mew8rrjhK4U()->Q2m8A]);
        } catch (\Throwable $Z8tVK) {
            throw new RT7PraDsizlHa("Failed to abort multipart upload of file {$this->xUsoB->getFile()->getFilename()}", 0, $Z8tVK);
        }
        goto Lf2hS;
        Ho2KS:
    }
    public function m5hKOwPI9JJ() : void
    {
        goto hL3Y9;
        m0URK:
        foreach ($GzTUV as $RG1uB) {
            goto rrHph;
            cDLdk:
            if (!($fLM2W['eTag'] !== $RG1uB['eTag'])) {
                goto oK2u7;
            }
            goto TSvRq;
            TSvRq:
            throw new HWNR21Z34Dhkn("Checksum mismatch for part {$MHXiD} of file {$this->xUsoB->getFile()->getFilename()}");
            goto dOJ9R;
            dOJ9R:
            oK2u7:
            goto dEmX3;
            T7wwf:
            $fLM2W = $AhVL1[$MHXiD];
            goto cDLdk;
            dEmX3:
            gfmlV:
            goto msaif;
            rrHph:
            $MHXiD = $RG1uB['partNumber'];
            goto T7wwf;
            msaif:
        }
        goto t4TEq;
        K0EjT:
        $cJl2t = $kvLls->JkyMk;
        goto d1UGV;
        t4TEq:
        Zc1Ob:
        goto oe6lH;
        hL3Y9:
        $kvLls = $this->xUsoB->mew8rrjhK4U();
        goto K0EjT;
        d1UGV:
        $GzTUV = $kvLls->cAjCT;
        goto RRqPK;
        RRqPK:
        Assert::eq(count($cJl2t), count($GzTUV), 'The number of parts and checksums must match.');
        goto nXg93;
        wzWI6:
        try {
            $EXETx->completeMultipartUpload(['Bucket' => $this->Jc4z2, 'Key' => $this->xUsoB->getFile()->getLocation(), 'UploadId' => $this->xUsoB->mew8rrjhK4U()->Q2m8A, 'MultipartUpload' => ['Parts' => collect($this->xUsoB->mew8rrjhK4U()->JkyMk)->sortBy('partNumber')->map(fn($fLM2W) => ['ETag' => $fLM2W['eTag'], 'PartNumber' => $fLM2W['partNumber']])->toArray()]]);
        } catch (\Throwable $Z8tVK) {
            throw new HWNR21Z34Dhkn("Failed to merge chunks of file {$this->xUsoB->getFile()->getFilename()}", 0, $Z8tVK);
        }
        goto z5yL0;
        oe6lH:
        $EXETx = $this->w2y98->getClient();
        goto wzWI6;
        nXg93:
        $AhVL1 = collect($cJl2t)->keyBy('partNumber');
        goto m0URK;
        z5yL0:
    }
}
