<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Eyra2OnsK5qBk;
use Jfs\Uploader\Exception\JTpnMPGceIdOz;
use Jfs\Uploader\Exception\KTN2YBzTu35D5;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Jfs\Uploader\Exception\ZqBgmBXZACgSf;
use Webmozart\Assert\Assert;
class EfcdLi3CoUQPy implements OB3spYi3UHM7c
{
    private $SjKWI;
    private $Lrwlv;
    private $OjeW5;
    private $EBMt5;
    public function __construct(Eyra2OnsK5qBk $Ry7nX, Filesystem $AhP23, Filesystem $A6wTz, string $E6K8y)
    {
        goto hNRue;
        hNRue:
        $this->SjKWI = $Ry7nX;
        goto HhvOK;
        HhvOK:
        $this->Lrwlv = $AhP23;
        goto d9GoC;
        ALhmN:
        $this->EBMt5 = $E6K8y;
        goto MVuFR;
        d9GoC:
        $this->OjeW5 = $A6wTz;
        goto ALhmN;
        MVuFR:
    }
    public function mlbPU0TakFO()
    {
        goto o3Oo9;
        AxNpN:
        throw new ZqBgmBXZACgSf("Failed to create multipart upload for file {$this->SjKWI->getFile()->getFilename()}, S3 return empty response");
        goto Cbbk3;
        l_frC:
        if (!($v2kl4 <= $y0umu)) {
            goto P6g_C;
        }
        goto KVmek;
        sPF97:
        $chyJc = [];
        goto hWxQO;
        kQzkw:
        $this->SjKWI->mfrHpIeDbxs($chyJc);
        goto uRs7E;
        l0HMK:
        vVN24:
        goto pub80;
        Uyo4K:
        $this->Lrwlv->put($this->SjKWI->mpi6jqATMm1(), json_encode($this->SjKWI->mROzB90pF6O()->toArray()));
        goto Hc2T6;
        ftb7E:
        Vfl2T:
        goto l_frC;
        hWxQO:
        $y0umu = ceil($uJKYp->nPW_w / $uJKYp->drka7);
        goto AA6_0;
        Hc2T6:
        $this->OjeW5->put($this->SjKWI->mpi6jqATMm1(), json_encode($this->SjKWI->mROzB90pF6O()->toArray()));
        goto hVU51;
        AA6_0:
        $T1p3q = $this->OjeW5->getClient();
        goto XYflq;
        CNZLM:
        $chyJc[] = ['index' => $v2kl4, 'url' => (string) $DIWAI->getUri()];
        goto l0HMK;
        Pnzx1:
        goto Vfl2T;
        goto zH0AR;
        o3Oo9:
        $uJKYp = $this->SjKWI->mROzB90pF6O();
        goto sPF97;
        pub80:
        ++$v2kl4;
        goto Pnzx1;
        XYflq:
        $fC1nN = $T1p3q->createMultipartUpload(['Bucket' => $this->EBMt5, 'Key' => $this->SjKWI->getFile()->getLocation(), 'ContentType' => $this->SjKWI->mROzB90pF6O()->jxkS6, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto iH3hZ;
        zEgiR:
        $v2kl4 = 1;
        goto ftb7E;
        uRs7E:
        $this->SjKWI->mROzB90pF6O()->mGmavrFr6gA($fC1nN['UploadId']);
        goto Uyo4K;
        iH3hZ:
        if (!(0 === $fC1nN->count())) {
            goto oplQ3;
        }
        goto AxNpN;
        wda7e:
        $DIWAI = $T1p3q->createPresignedRequest($CLKqo, '+1 day');
        goto CNZLM;
        KVmek:
        $CLKqo = $T1p3q->getCommand('UploadPart', ['Bucket' => $this->EBMt5, 'Key' => $this->SjKWI->getFile()->getLocation(), 'UploadId' => $fC1nN['UploadId'], 'PartNumber' => $v2kl4]);
        goto wda7e;
        zH0AR:
        P6g_C:
        goto kQzkw;
        Cbbk3:
        oplQ3:
        goto zEgiR;
        hVU51:
    }
    public function mqX3etBSfdy() : void
    {
        goto Y0Zou;
        Cb4L0:
        $this->Lrwlv->delete($this->SjKWI->mpi6jqATMm1());
        goto Rk9E8;
        Rk9E8:
        $this->OjeW5->delete($this->SjKWI->mpi6jqATMm1());
        goto j0ErE;
        MfIQB:
        try {
            $T1p3q->abortMultipartUpload(['Bucket' => $this->EBMt5, 'Key' => $this->SjKWI->getFile()->getLocation(), 'UploadId' => $this->SjKWI->mROzB90pF6O()->C33qk]);
        } catch (\Throwable $tPAjT) {
            throw new JTpnMPGceIdOz("Failed to abort multipart upload of file {$this->SjKWI->getFile()->getFilename()}", 0, $tPAjT);
        }
        goto Cb4L0;
        Y0Zou:
        $T1p3q = $this->OjeW5->getClient();
        goto MfIQB;
        j0ErE:
    }
    public function m8foZzm8MDN() : void
    {
        goto FbpEh;
        C32dm:
        foreach ($QMgWa as $daIbs) {
            goto jwbex;
            rtmZ4:
            r7ImO:
            goto XDMIe;
            IAxQT:
            if (!($pYQUm['eTag'] !== $daIbs['eTag'])) {
                goto hDSQg;
            }
            goto kW_zZ;
            cevxi:
            hDSQg:
            goto rtmZ4;
            jwbex:
            $clMvJ = $daIbs['partNumber'];
            goto oj7fo;
            oj7fo:
            $pYQUm = $WTgPj[$clMvJ];
            goto IAxQT;
            kW_zZ:
            throw new KTN2YBzTu35D5("Checksum mismatch for part {$clMvJ} of file {$this->SjKWI->getFile()->getFilename()}");
            goto cevxi;
            XDMIe:
        }
        goto DpxD2;
        dQ1_o:
        $QMgWa = $uJKYp->BNFbb;
        goto akxA5;
        t9A7h:
        $T1p3q = $this->OjeW5->getClient();
        goto V5cE1;
        QSAg2:
        $iHezl = $uJKYp->x3Dn9;
        goto dQ1_o;
        FbpEh:
        $uJKYp = $this->SjKWI->mROzB90pF6O();
        goto QSAg2;
        akxA5:
        Assert::eq(count($iHezl), count($QMgWa), 'The number of parts and checksums must match.');
        goto nlOnB;
        DpxD2:
        bbcGS:
        goto t9A7h;
        V5cE1:
        try {
            $T1p3q->completeMultipartUpload(['Bucket' => $this->EBMt5, 'Key' => $this->SjKWI->getFile()->getLocation(), 'UploadId' => $this->SjKWI->mROzB90pF6O()->C33qk, 'MultipartUpload' => ['Parts' => collect($this->SjKWI->mROzB90pF6O()->x3Dn9)->sortBy('partNumber')->map(fn($pYQUm) => ['ETag' => $pYQUm['eTag'], 'PartNumber' => $pYQUm['partNumber']])->toArray()]]);
        } catch (\Throwable $tPAjT) {
            throw new KTN2YBzTu35D5("Failed to merge chunks of file {$this->SjKWI->getFile()->getFilename()}", 0, $tPAjT);
        }
        goto dryHM;
        nlOnB:
        $WTgPj = collect($iHezl)->keyBy('partNumber');
        goto C32dm;
        dryHM:
    }
}
