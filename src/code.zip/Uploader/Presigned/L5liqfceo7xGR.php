<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\VX3gdl3bFyp5B;
use Jfs\Uploader\Exception\HJ2NaMMJCY27q;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class L5liqfceo7xGR implements RPMVlbeBF6oBq
{
    private static $bqhMu = 'chunks/';
    private $speJc;
    private $N3F9R;
    private $LmK5y;
    public function __construct(VX3gdl3bFyp5B $KnLpk, Filesystem $mFX9i, Filesystem $ExTI3)
    {
        goto bWQ2z;
        vs0OS:
        $this->N3F9R = $mFX9i;
        goto bvh0M;
        bWQ2z:
        $this->speJc = $KnLpk;
        goto vs0OS;
        bvh0M:
        $this->LmK5y = $ExTI3;
        goto tDQE1;
        tDQE1:
    }
    public function m9UURmwWnW3() : void
    {
        goto xd5mi;
        CYeZQ:
        $jaUM6[] = ['index' => $EP1lQ, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $dXkPO, 'index' => $EP1lQ])];
        goto PgYX1;
        e6okP:
        $eB3WA = ceil($Ds24j->bGpro / $Ds24j->DR4yj);
        goto KDBTt;
        sucsR:
        ++$EP1lQ;
        goto wIRt4;
        xd5mi:
        $Ds24j = $this->speJc->mDwF61YxuNq();
        goto cHZID;
        fWBV9:
        $this->speJc->mDwF61YxuNq()->mv3G4OVCmSr($dXkPO);
        goto U4aFZ;
        kXpcG:
        if (!($EP1lQ <= $eB3WA)) {
            goto oEuZU;
        }
        goto CYeZQ;
        yYHgT:
        $this->speJc->mUEr22m4NIs($jaUM6);
        goto wt4zM;
        zwg4R:
        reRML:
        goto kXpcG;
        U4aFZ:
        $EP1lQ = 1;
        goto zwg4R;
        CkFad:
        oEuZU:
        goto yYHgT;
        wIRt4:
        goto reRML;
        goto CkFad;
        cHZID:
        $jaUM6 = [];
        goto e6okP;
        KDBTt:
        $dXkPO = Uuid::v4()->toHex();
        goto fWBV9;
        PgYX1:
        ycEsi:
        goto sucsR;
        wt4zM:
        $this->speJc->mDwF61YxuNq()->mv3G4OVCmSr($dXkPO);
        goto gFjsX;
        gFjsX:
        $this->N3F9R->put($this->speJc->mn0D2cAVuAW(), json_encode($this->speJc->mDwF61YxuNq()->toArray()));
        goto MVSdu;
        MVSdu:
        $this->LmK5y->put($this->speJc->mn0D2cAVuAW(), json_encode($this->speJc->mDwF61YxuNq()->toArray()));
        goto mQ1A4;
        mQ1A4:
    }
    public function muDP4BURVYw() : void
    {
        goto J3tTh;
        USWQA:
        $dXkPO = $Ds24j->l9IH2;
        goto RFunj;
        Lo7xJ:
        $this->LmK5y->delete($this->speJc->mn0D2cAVuAW());
        goto Mt2G1;
        RFunj:
        $this->N3F9R->deleteDirectory(self::$bqhMu . $dXkPO);
        goto Lo7xJ;
        J3tTh:
        $Ds24j = $this->speJc->mDwF61YxuNq();
        goto USWQA;
        Mt2G1:
    }
    public function mYrguHH3ARB() : void
    {
        goto fAJB3;
        qTcX9:
        fclose($SZGFi);
        goto FbLBT;
        emFHS:
        jAUD0:
        goto I2uui;
        iEgbf:
        SdVUL:
        goto qTcX9;
        Bhx6E:
        $this->N3F9R->makeDirectory($DA2US);
        goto nXhUx;
        g7lcA:
        B3SKZ:
        goto Ntf8Y;
        nXhUx:
        BCmFX:
        goto c0imE;
        FbLBT:
        $t8VCW = $this->N3F9R->path($mfnU0);
        goto KAZdd;
        c0imE:
        $bbfej = $this->N3F9R->path($mfnU0);
        goto GWyjg;
        NiovM:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $t8VCW);
        goto q4NW9;
        htUK5:
        throw new HJ2NaMMJCY27q('Local chunk can not merge file (can create file): ' . $bbfej);
        goto g7lcA;
        Ntf8Y:
        foreach ($F2Q_y as $vNxRJ) {
            goto qAj1p;
            Cdm5k:
            throw new HJ2NaMMJCY27q('A chunk file content can not copy: ' . $i8zxB);
            goto O3Mfq;
            Cj8K9:
            if (!(false === $YF4r1)) {
                goto xFt7B;
            }
            goto Cdm5k;
            p96YA:
            fclose($CRlSl);
            goto Cj8K9;
            hxhwF:
            throw new HJ2NaMMJCY27q('A chunk file not existed: ' . $i8zxB);
            goto EReb8;
            CCrvc:
            $CRlSl = @fopen($i8zxB, 'rb');
            goto EtZ92;
            qAj1p:
            $i8zxB = $this->N3F9R->path($vNxRJ);
            goto CCrvc;
            O3Mfq:
            xFt7B:
            goto SKcfa;
            EtZ92:
            if (!(false === $CRlSl)) {
                goto xvvAs;
            }
            goto hxhwF;
            SKcfa:
            ZHjvM:
            goto JhRWV;
            EReb8:
            xvvAs:
            goto VpE3a;
            VpE3a:
            $YF4r1 = stream_copy_to_stream($CRlSl, $SZGFi);
            goto p96YA;
            JhRWV:
        }
        goto iEgbf;
        aTY1E:
        $DA2US = dirname($mfnU0);
        goto QvSAe;
        F3EAM:
        if (!(false === $SZGFi)) {
            goto B3SKZ;
        }
        goto htUK5;
        CkFMd:
        $SZGFi = @fopen($bbfej, 'wb');
        goto F3EAM;
        GWyjg:
        touch($bbfej);
        goto CkFMd;
        I2uui:
        $this->N3F9R->deleteDirectory($Tzxdb);
        goto TrKPn;
        o3RVz:
        $eB3WA = $Ds24j->XqQ_r;
        goto T_fnY;
        fAJB3:
        $Ds24j = $this->speJc->mDwF61YxuNq();
        goto o3RVz;
        ClwpS:
        natsort($F2Q_y);
        goto aTY1E;
        q4NW9:
        throw new \Exception('Failed to set file permissions for stored image: ' . $t8VCW);
        goto emFHS;
        QvSAe:
        if ($this->N3F9R->exists($DA2US)) {
            goto BCmFX;
        }
        goto Bhx6E;
        KAZdd:
        if (chmod($t8VCW, 0644)) {
            goto jAUD0;
        }
        goto NiovM;
        vfJG8:
        Assert::eq(count($F2Q_y), $eB3WA, 'The number of parts and checksums must match.');
        goto ClwpS;
        FL3Ep:
        $F2Q_y = $this->N3F9R->files($Tzxdb);
        goto vfJG8;
        T_fnY:
        $Tzxdb = self::$bqhMu . $Ds24j->l9IH2;
        goto ZFYth;
        ZFYth:
        $mfnU0 = $this->speJc->getFile()->getLocation();
        goto FL3Ep;
        TrKPn:
    }
}
