<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\TN0vqVlBODTOO;
use Jfs\Uploader\Exception\SilEUK7TJaRKp;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Presigned\RUZz7OOZpzxlh;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Olsqvb4sy7cqu implements RUZz7OOZpzxlh
{
    private static $VcqUX = 'chunks/';
    private $LILxj;
    private $q6zCU;
    private $NTZHy;
    public function __construct(TN0vqVlBODTOO $wJPdj, Filesystem $zDbHT, Filesystem $pbv6a)
    {
        goto ysrDc;
        ysrDc:
        $this->LILxj = $wJPdj;
        goto EItTR;
        EItTR:
        $this->q6zCU = $zDbHT;
        goto G0jkr;
        G0jkr:
        $this->NTZHy = $pbv6a;
        goto tWZVi;
        tWZVi:
    }
    public function mQwILMgE5G0() : void
    {
        goto H3JHG;
        UPD6g:
        $this->NTZHy->put($this->LILxj->m0wKioa2Rfn(), json_encode($this->LILxj->m67klYkiadk()->toArray()));
        goto IWH05;
        wg6vj:
        bE5kt:
        goto lsYk4;
        OC2Jw:
        $OuliP = 'https://' . $lnTfz . '/' . ltrim($lmTDq, '/');
        goto PQP1E;
        z8bnn:
        $this->q6zCU->put($this->LILxj->m0wKioa2Rfn(), json_encode($this->LILxj->m67klYkiadk()->toArray()));
        goto UPD6g;
        lsYk4:
        if (!($YxYO9 <= $GvwqQ)) {
            goto Fwl2X;
        }
        goto Mta48;
        jJv3X:
        $this->LILxj->m67klYkiadk()->m4LXw4yPAPd($PCQqS);
        goto N5tSm;
        h2nX2:
        $PCQqS = $OFuou->filename;
        goto jJv3X;
        vyadT:
        $GvwqQ = ceil($OFuou->G7PBg / $OFuou->B1Wnn);
        goto h2nX2;
        VH3eL:
        $lnTfz = parse_url($igIiY, PHP_URL_HOST);
        goto OC2Jw;
        E2bLR:
        Fwl2X:
        goto q0Z4M;
        PQP1E:
        $Hez8p[] = ['index' => $YxYO9, 'url' => $OuliP];
        goto bBlnq;
        jLWTY:
        $Hez8p = [];
        goto vyadT;
        bBlnq:
        TNKDc:
        goto O_dwN;
        H3JHG:
        $OFuou = $this->LILxj->m67klYkiadk();
        goto jLWTY;
        ntB7t:
        $this->LILxj->m67klYkiadk()->m4LXw4yPAPd($PCQqS);
        goto z8bnn;
        Mta48:
        $igIiY = route('upload.api.local_chunk.upload', ['uploadId' => $PCQqS, 'index' => $YxYO9]);
        goto VOP6W;
        VOP6W:
        $lmTDq = parse_url($igIiY, PHP_URL_PATH);
        goto VH3eL;
        O_dwN:
        ++$YxYO9;
        goto zKHYg;
        N5tSm:
        $YxYO9 = 1;
        goto wg6vj;
        q0Z4M:
        $this->LILxj->mG9NRD5Z2bQ($Hez8p);
        goto ntB7t;
        zKHYg:
        goto bE5kt;
        goto E2bLR;
        IWH05:
    }
    public function m7mAhDQTm1t() : void
    {
        goto Poc15;
        hRpsG:
        $this->q6zCU->deleteDirectory(self::$VcqUX . $PCQqS);
        goto pTubc;
        pTubc:
        $this->NTZHy->delete($this->LILxj->m0wKioa2Rfn());
        goto AONS5;
        jRRpv:
        $PCQqS = $OFuou->ns0Bu;
        goto hRpsG;
        Poc15:
        $OFuou = $this->LILxj->m67klYkiadk();
        goto jRRpv;
        AONS5:
    }
    public function mtyEvCKHi25() : void
    {
        goto y7el3;
        Kx5xC:
        $l3dZQ = $this->q6zCU->files($LRyMy);
        goto noCm_;
        BvOYg:
        foreach ($l3dZQ as $wzwm_) {
            goto KPATU;
            AM5D7:
            q35W1:
            goto GcmBw;
            fRxod:
            $oGcIv = @fopen($xUtAX, 'rb');
            goto VzB3g;
            GcmBw:
            $i7fpK = stream_copy_to_stream($oGcIv, $GcRVq);
            goto giMZV;
            wlhcd:
            throw new SilEUK7TJaRKp('A chunk file content can not copy: ' . $xUtAX);
            goto DJdEd;
            NjZz6:
            zgR1y:
            goto RWK0T;
            BgaPN:
            if (!(false === $i7fpK)) {
                goto Vs4XR;
            }
            goto wlhcd;
            giMZV:
            fclose($oGcIv);
            goto BgaPN;
            KPATU:
            $xUtAX = $this->q6zCU->path($wzwm_);
            goto fRxod;
            CBW9Q:
            throw new SilEUK7TJaRKp('A chunk file not existed: ' . $xUtAX);
            goto AM5D7;
            DJdEd:
            Vs4XR:
            goto NjZz6;
            VzB3g:
            if (!(false === $oGcIv)) {
                goto q35W1;
            }
            goto CBW9Q;
            RWK0T:
        }
        goto jJMTP;
        MyHja:
        natsort($l3dZQ);
        goto k32m3;
        Uzky1:
        if (chmod($cODcu, 0644)) {
            goto m0fKS;
        }
        goto WRGyc;
        Z5AkB:
        $this->q6zCU->deleteDirectory($LRyMy);
        goto PVDxF;
        XGvZA:
        $this->q6zCU->makeDirectory($k8Cs9);
        goto EXhtM;
        jJMTP:
        l0dz8:
        goto kUPGk;
        ywvTB:
        throw new \Exception('Failed to set file permissions for stored image: ' . $cODcu);
        goto Q2X1l;
        SBtpW:
        touch($fzkVR);
        goto G2WLm;
        D_jlm:
        throw new SilEUK7TJaRKp('Local chunk can not merge file (can create file): ' . $fzkVR);
        goto za2u5;
        za2u5:
        hM7WT:
        goto BvOYg;
        EXhtM:
        abrhe:
        goto qB1UQ;
        Q2X1l:
        m0fKS:
        goto Z5AkB;
        G2WLm:
        $GcRVq = @fopen($fzkVR, 'wb');
        goto TE8R_;
        kUPGk:
        fclose($GcRVq);
        goto gHB4N;
        k32m3:
        $k8Cs9 = dirname($Pw1Qj);
        goto px0Po;
        noCm_:
        Assert::eq(count($l3dZQ), $GvwqQ, 'The number of parts and checksums must match.');
        goto MyHja;
        TE8R_:
        if (!(false === $GcRVq)) {
            goto hM7WT;
        }
        goto D_jlm;
        gHB4N:
        $cODcu = $this->q6zCU->path($Pw1Qj);
        goto Uzky1;
        WRGyc:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $cODcu);
        goto ywvTB;
        y7el3:
        $OFuou = $this->LILxj->m67klYkiadk();
        goto fjrKJ;
        dTYdr:
        $Pw1Qj = $this->LILxj->getFile()->getLocation();
        goto Kx5xC;
        qB1UQ:
        $fzkVR = $this->q6zCU->path($Pw1Qj);
        goto SBtpW;
        px0Po:
        if ($this->q6zCU->exists($k8Cs9)) {
            goto abrhe;
        }
        goto XGvZA;
        I9Jtd:
        $LRyMy = self::$VcqUX . $OFuou->ns0Bu;
        goto dTYdr;
        fjrKJ:
        $GvwqQ = $OFuou->ufqYL;
        goto I9Jtd;
        PVDxF:
    }
}
