<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\Wa740mKVvCN9d;
use Jfs\Uploader\Exception\Zxrtxnq00Ah5O;
use Jfs\Uploader\Exception\UG3Plh0htUmWz;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Exception\R31gy0GGuTDlE;
use Jfs\Uploader\Presigned\A1SMzkLJBlsJF;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class S6fGdybdYsuki implements A1SMzkLJBlsJF
{
    private $F1L0c;
    private $niO3l;
    private $aplH5;
    private $S7Zrn;
    public function __construct(Wa740mKVvCN9d $QJo2h, Filesystem $xuow1, Filesystem $C82jg, string $xYZ3A)
    {
        goto sxgfw;
        sxgfw:
        $this->F1L0c = $QJo2h;
        goto c55zK;
        wLqPU:
        $this->S7Zrn = $xYZ3A;
        goto LKeUM;
        vkaJG:
        $this->aplH5 = $C82jg;
        goto wLqPU;
        c55zK:
        $this->niO3l = $xuow1;
        goto vkaJG;
        LKeUM:
    }
    public function mR8YH6Ul9tS()
    {
        goto IFUpe;
        wpjrH:
        $grOd3 = $nxKEI->getCommand('UploadPart', ['Bucket' => $this->S7Zrn, 'Key' => $this->F1L0c->getFile()->getLocation(), 'UploadId' => $sx0QZ['UploadId'], 'PartNumber' => $xDfl8]);
        goto Q4RRm;
        Ej2bo:
        $this->F1L0c->miZvF1lrUqz($LZ2fC);
        goto kchfF;
        Q4RRm:
        $ar7VQ = $nxKEI->createPresignedRequest($grOd3, '+1 day');
        goto HVlJe;
        TPjU5:
        $this->aplH5->put($this->F1L0c->mYTaPK60wfh(), json_encode($this->F1L0c->mBE2ZEQSaNO()->toArray()));
        goto vGYuE;
        J3zU4:
        ++$xDfl8;
        goto zzFro;
        OkWlO:
        $dkYsv = ceil($ZTJaQ->n0Dq1 / $ZTJaQ->x1m41);
        goto wY1_7;
        zemeN:
        kCj6P:
        goto Ej2bo;
        w3BKa:
        ajir6:
        goto q0HSd;
        UiDga:
        if (!(0 === $sx0QZ->count())) {
            goto mnv8t;
        }
        goto XbOo1;
        DI2Sw:
        $sx0QZ = $nxKEI->createMultipartUpload(['Bucket' => $this->S7Zrn, 'Key' => $this->F1L0c->getFile()->getLocation(), 'ContentType' => $this->F1L0c->mBE2ZEQSaNO()->l70XB, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto UiDga;
        kchfF:
        $this->F1L0c->mBE2ZEQSaNO()->m74QFmAnqWV($sx0QZ['UploadId']);
        goto BM94C;
        HVlJe:
        $LZ2fC[] = ['index' => $xDfl8, 'url' => (string) $ar7VQ->getUri()];
        goto vm7Ft;
        wY1_7:
        $nxKEI = $this->aplH5->getClient();
        goto DI2Sw;
        mweaD:
        $LZ2fC = [];
        goto OkWlO;
        q0HSd:
        if (!($xDfl8 <= $dkYsv)) {
            goto kCj6P;
        }
        goto wpjrH;
        XbOo1:
        throw new R31gy0GGuTDlE("Failed to create multipart upload for file {$this->F1L0c->getFile()->getFilename()}, S3 return empty response");
        goto w8Ndv;
        zzFro:
        goto ajir6;
        goto zemeN;
        vm7Ft:
        AxEeT:
        goto J3zU4;
        w8Ndv:
        mnv8t:
        goto KG6HR;
        BM94C:
        $this->niO3l->put($this->F1L0c->mYTaPK60wfh(), json_encode($this->F1L0c->mBE2ZEQSaNO()->toArray()));
        goto TPjU5;
        KG6HR:
        $xDfl8 = 1;
        goto w3BKa;
        IFUpe:
        $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
        goto mweaD;
        vGYuE:
    }
    public function mmZY5pVfPQx() : void
    {
        goto f850H;
        T_Lpl:
        $this->aplH5->delete($this->F1L0c->mYTaPK60wfh());
        goto jmwvI;
        R8EE5:
        try {
            $nxKEI->abortMultipartUpload(['Bucket' => $this->S7Zrn, 'Key' => $this->F1L0c->getFile()->getLocation(), 'UploadId' => $this->F1L0c->mBE2ZEQSaNO()->fTWbE]);
        } catch (\Throwable $YIsP2) {
            throw new Zxrtxnq00Ah5O("Failed to abort multipart upload of file {$this->F1L0c->getFile()->getFilename()}", 0, $YIsP2);
        }
        goto qAbIZ;
        f850H:
        $nxKEI = $this->aplH5->getClient();
        goto R8EE5;
        qAbIZ:
        $this->niO3l->delete($this->F1L0c->mYTaPK60wfh());
        goto T_Lpl;
        jmwvI:
    }
    public function mPGOyQEz4ld() : void
    {
        goto vPM_n;
        oL7q_:
        try {
            $nxKEI->completeMultipartUpload(['Bucket' => $this->S7Zrn, 'Key' => $this->F1L0c->getFile()->getLocation(), 'UploadId' => $this->F1L0c->mBE2ZEQSaNO()->fTWbE, 'MultipartUpload' => ['Parts' => collect($this->F1L0c->mBE2ZEQSaNO()->pTf3A)->sortBy('partNumber')->map(fn($vLfhq) => ['ETag' => $vLfhq['eTag'], 'PartNumber' => $vLfhq['partNumber']])->toArray()]]);
        } catch (\Throwable $YIsP2) {
            throw new UG3Plh0htUmWz("Failed to merge chunks of file {$this->F1L0c->getFile()->getFilename()}", 0, $YIsP2);
        }
        goto A027J;
        nP3Gy:
        $dXuiY = $ZTJaQ->pTf3A;
        goto Frobc;
        UXSC8:
        $nxKEI = $this->aplH5->getClient();
        goto oL7q_;
        eijFm:
        Assert::eq(count($dXuiY), count($uH3S9), 'The number of parts and checksums must match.');
        goto oXlLB;
        vPM_n:
        $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
        goto nP3Gy;
        PSVfi:
        wCPty:
        goto UXSC8;
        rK93M:
        foreach ($uH3S9 as $ylNqr) {
            goto dps96;
            EIHbf:
            if (!($vLfhq['eTag'] !== $ylNqr['eTag'])) {
                goto mpG36;
            }
            goto bDZV5;
            gyqz3:
            NKOTC:
            goto gxtdB;
            PmvZB:
            $vLfhq = $iCR1R[$v5uyM];
            goto EIHbf;
            bDZV5:
            throw new UG3Plh0htUmWz("Checksum mismatch for part {$v5uyM} of file {$this->F1L0c->getFile()->getFilename()}");
            goto Id8Wm;
            dps96:
            $v5uyM = $ylNqr['partNumber'];
            goto PmvZB;
            Id8Wm:
            mpG36:
            goto gyqz3;
            gxtdB:
        }
        goto PSVfi;
        Frobc:
        $uH3S9 = $ZTJaQ->QlmBb;
        goto eijFm;
        oXlLB:
        $iCR1R = collect($dXuiY)->keyBy('partNumber');
        goto rK93M;
        A027J:
    }
}
