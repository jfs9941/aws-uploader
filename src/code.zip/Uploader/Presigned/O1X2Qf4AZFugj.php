<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\XWJCs1ZDQGYBH;
use Jfs\Uploader\Exception\Y3xIXPNoq2lO8;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Presigned\ZJaIDXyDkKWnB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class O1X2Qf4AZFugj implements ZJaIDXyDkKWnB
{
    private static $E2fos = 'chunks/';
    private $R3E7z;
    private $ZPzJH;
    private $luUdx;
    public function __construct(XWJCs1ZDQGYBH $iZsfk, Filesystem $G3exm, Filesystem $u0SLj)
    {
        goto RSRWi;
        gPYHf:
        $this->luUdx = $u0SLj;
        goto OBXqr;
        RSRWi:
        $this->R3E7z = $iZsfk;
        goto z1nw9;
        z1nw9:
        $this->ZPzJH = $G3exm;
        goto gPYHf;
        OBXqr:
    }
    public function mmc9EKNltDU() : void
    {
        goto r3YBT;
        LGfLD:
        $NB12w = $PSxFL->filename;
        goto z00mi;
        i1cPp:
        $this->R3E7z->mT6C36oVf34($jwylE);
        goto qaXh6;
        k3U2B:
        ++$a_aYv;
        goto bSWo0;
        NtPTs:
        $hrEZz = ceil($PSxFL->tZcBC / $PSxFL->C25S5);
        goto LGfLD;
        pJGBt:
        jlEGM:
        goto D3t4h;
        r3YBT:
        $PSxFL = $this->R3E7z->mLzfhDWzVE5();
        goto HpBsX;
        bSWo0:
        goto jlEGM;
        goto HxIm0;
        BRMDD:
        $YrdXo = str_replace('http', 'https', route('upload.api.local_chunk.upload', ['uploadId' => $NB12w, 'index' => $a_aYv]));
        goto ALTiX;
        HpBsX:
        $jwylE = [];
        goto NtPTs;
        ALTiX:
        $jwylE[] = ['index' => $a_aYv, 'url' => str_replace('httpss', 'https', $YrdXo)];
        goto PwOJP;
        z00mi:
        $this->R3E7z->mLzfhDWzVE5()->msZ9gs4HQR8($NB12w);
        goto myngV;
        myngV:
        $a_aYv = 1;
        goto pJGBt;
        qaXh6:
        $this->R3E7z->mLzfhDWzVE5()->msZ9gs4HQR8($NB12w);
        goto Eun51;
        PwOJP:
        rqh0i:
        goto k3U2B;
        D3t4h:
        if (!($a_aYv <= $hrEZz)) {
            goto T9aNt;
        }
        goto BRMDD;
        HxIm0:
        T9aNt:
        goto i1cPp;
        K25AO:
        $this->luUdx->put($this->R3E7z->mSoaLVttBsh(), json_encode($this->R3E7z->mLzfhDWzVE5()->toArray()));
        goto dDqYU;
        Eun51:
        $this->ZPzJH->put($this->R3E7z->mSoaLVttBsh(), json_encode($this->R3E7z->mLzfhDWzVE5()->toArray()));
        goto K25AO;
        dDqYU:
    }
    public function mEdT9RIpbT0() : void
    {
        goto LensR;
        KaEDk:
        $NB12w = $PSxFL->Uyx84;
        goto syf8f;
        QFWDY:
        $this->luUdx->delete($this->R3E7z->mSoaLVttBsh());
        goto zYVQD;
        LensR:
        $PSxFL = $this->R3E7z->mLzfhDWzVE5();
        goto KaEDk;
        syf8f:
        $this->ZPzJH->deleteDirectory(self::$E2fos . $NB12w);
        goto QFWDY;
        zYVQD:
    }
    public function m8k1eh8wcQE() : void
    {
        goto yx4bj;
        oFvjC:
        throw new Y3xIXPNoq2lO8('Local chunk can not merge file (can create file): ' . $M5a3K);
        goto rDgmU;
        MxH90:
        foreach ($psAci as $e7Zkx) {
            goto YXZ1w;
            vYMV_:
            Z_g1X:
            goto fqV0o;
            YxCfi:
            if (!(false === $M0ivz)) {
                goto zL5_k;
            }
            goto ls21G;
            ukubo:
            $wLE6A = @fopen($iHk0g, 'rb');
            goto kMP6y;
            ldvWP:
            throw new Y3xIXPNoq2lO8('A chunk file not existed: ' . $iHk0g);
            goto vYMV_;
            t1Aim:
            fclose($wLE6A);
            goto YxCfi;
            arFGf:
            zL5_k:
            goto iB0Ae;
            YXZ1w:
            $iHk0g = $this->ZPzJH->path($e7Zkx);
            goto ukubo;
            kMP6y:
            if (!(false === $wLE6A)) {
                goto Z_g1X;
            }
            goto ldvWP;
            fqV0o:
            $M0ivz = stream_copy_to_stream($wLE6A, $DWrDp);
            goto t1Aim;
            ls21G:
            throw new Y3xIXPNoq2lO8('A chunk file content can not copy: ' . $iHk0g);
            goto arFGf;
            iB0Ae:
            SbDm3:
            goto Z4eKa;
            Z4eKa:
        }
        goto szMyU;
        EwTE8:
        $lJGyd = self::$E2fos . $PSxFL->Uyx84;
        goto TsF5h;
        yx4bj:
        $PSxFL = $this->R3E7z->mLzfhDWzVE5();
        goto h0kBe;
        Al2ST:
        $M5a3K = $this->ZPzJH->path($PONQ9);
        goto aLhTs;
        TsF5h:
        $PONQ9 = $this->R3E7z->getFile()->getLocation();
        goto WJV2Z;
        TCFT3:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $T0Q_9);
        goto ua588;
        ua588:
        throw new \Exception('Failed to set file permissions for stored image: ' . $T0Q_9);
        goto iwruL;
        szMyU:
        I5deN:
        goto NQXGE;
        NQXGE:
        fclose($DWrDp);
        goto w9U2y;
        YnPaZ:
        zgK6B:
        goto Al2ST;
        rDgmU:
        K3kE2:
        goto MxH90;
        iwruL:
        J2lLh:
        goto MUZdk;
        vFWLt:
        $this->ZPzJH->makeDirectory($S24Tz);
        goto YnPaZ;
        w9U2y:
        $T0Q_9 = $this->ZPzJH->path($PONQ9);
        goto pHqZF;
        MUZdk:
        $this->ZPzJH->deleteDirectory($lJGyd);
        goto sWCZp;
        jBXGA:
        natsort($psAci);
        goto G50O8;
        aLhTs:
        touch($M5a3K);
        goto G4crN;
        wlE0N:
        if (!(false === $DWrDp)) {
            goto K3kE2;
        }
        goto oFvjC;
        G4crN:
        $DWrDp = @fopen($M5a3K, 'wb');
        goto wlE0N;
        h0kBe:
        $hrEZz = $PSxFL->bPUco;
        goto EwTE8;
        YgNOQ:
        Assert::eq(count($psAci), $hrEZz, 'The number of parts and checksums must match.');
        goto jBXGA;
        WJV2Z:
        $psAci = $this->ZPzJH->files($lJGyd);
        goto YgNOQ;
        hPyg2:
        if ($this->ZPzJH->exists($S24Tz)) {
            goto zgK6B;
        }
        goto vFWLt;
        G50O8:
        $S24Tz = dirname($PONQ9);
        goto hPyg2;
        pHqZF:
        if (chmod($T0Q_9, 0644)) {
            goto J2lLh;
        }
        goto TCFT3;
        sWCZp:
    }
}
