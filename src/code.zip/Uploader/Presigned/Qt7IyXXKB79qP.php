<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\Rfow5q0HYgflu;
use Jfs\Uploader\Exception\QV9q47CYV0jba;
use Jfs\Uploader\Exception\JErR6MoLsdBKL;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Exception\NXDA0GpL4iI7P;
use Jfs\Uploader\Presigned\VqFBkbvSkc34V;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class Qt7IyXXKB79qP implements VqFBkbvSkc34V
{
    private $Fc9NF;
    private $j5MRz;
    private $Diye_;
    private $q34dl;
    public function __construct(Rfow5q0HYgflu $LaHja, Filesystem $nkmCX, Filesystem $NYASv, string $ivxnu)
    {
        goto AVb0a;
        AVb0a:
        $this->Fc9NF = $LaHja;
        goto T2sg4;
        V_EH4:
        $this->Diye_ = $NYASv;
        goto v4dVn;
        v4dVn:
        $this->q34dl = $ivxnu;
        goto ISGyj;
        T2sg4:
        $this->j5MRz = $nkmCX;
        goto V_EH4;
        ISGyj:
    }
    public function mB7vpRBakhx()
    {
        goto tFGqK;
        Ce1fs:
        PuM1X:
        goto IBvBa;
        eJ2wf:
        $MKh9Q = $xnQNU->getCommand('UploadPart', ['Bucket' => $this->q34dl, 'Key' => $this->Fc9NF->getFile()->getLocation(), 'UploadId' => $KJZOG['UploadId'], 'PartNumber' => $igxB3]);
        goto JZHRE;
        wVPcM:
        $D362G = ceil($Zqaxi->ZUDEN / $Zqaxi->RpZdB);
        goto iii_o;
        IBvBa:
        $this->Fc9NF->me2kPW7r3WV($hi827);
        goto PxXCm;
        rd73a:
        $KJZOG = $xnQNU->createMultipartUpload(['Bucket' => $this->q34dl, 'Key' => $this->Fc9NF->getFile()->getLocation(), 'ContentType' => $this->Fc9NF->mLISLvz7JU3()->Zpu5j, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto Q82GQ;
        l5dgc:
        CCkz6:
        goto LQ2FC;
        tFGqK:
        $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
        goto iYuen;
        iii_o:
        $xnQNU = $this->Diye_->getClient();
        goto rd73a;
        bLI5c:
        if (!($igxB3 <= $D362G)) {
            goto PuM1X;
        }
        goto eJ2wf;
        Ny3rH:
        $this->Diye_->put($this->Fc9NF->mAK7MUq8SYx(), json_encode($this->Fc9NF->mLISLvz7JU3()->toArray()));
        goto NuxRU;
        IfDd9:
        throw new NXDA0GpL4iI7P("Failed to create multipart upload for file {$this->Fc9NF->getFile()->getFilename()}, S3 return empty response");
        goto qadpP;
        Q82GQ:
        if (!(0 === $KJZOG->count())) {
            goto S7N4b;
        }
        goto IfDd9;
        qadpP:
        S7N4b:
        goto ud11t;
        JZHRE:
        $jHO4v = $xnQNU->createPresignedRequest($MKh9Q, '+1 day');
        goto yeZTy;
        yeZTy:
        $hi827[] = ['index' => $igxB3, 'url' => (string) $jHO4v->getUri()];
        goto l5dgc;
        nWiwg:
        goto WFlhf;
        goto Ce1fs;
        iYuen:
        $hi827 = [];
        goto wVPcM;
        FSTiZ:
        WFlhf:
        goto bLI5c;
        ud11t:
        $igxB3 = 1;
        goto FSTiZ;
        QQQFL:
        $this->j5MRz->put($this->Fc9NF->mAK7MUq8SYx(), json_encode($this->Fc9NF->mLISLvz7JU3()->toArray()));
        goto Ny3rH;
        PxXCm:
        $this->Fc9NF->mLISLvz7JU3()->mHiIxReHa8H($KJZOG['UploadId']);
        goto QQQFL;
        LQ2FC:
        ++$igxB3;
        goto nWiwg;
        NuxRU:
    }
    public function mam3hAYlt0Q() : void
    {
        goto a2WZZ;
        a2WZZ:
        $xnQNU = $this->Diye_->getClient();
        goto F212L;
        JQdp0:
        $this->Diye_->delete($this->Fc9NF->mAK7MUq8SYx());
        goto idv8l;
        F212L:
        try {
            $xnQNU->abortMultipartUpload(['Bucket' => $this->q34dl, 'Key' => $this->Fc9NF->getFile()->getLocation(), 'UploadId' => $this->Fc9NF->mLISLvz7JU3()->Ca5Pw]);
        } catch (\Throwable $kE48F) {
            throw new QV9q47CYV0jba("Failed to abort multipart upload of file {$this->Fc9NF->getFile()->getFilename()}", 0, $kE48F);
        }
        goto cluPA;
        cluPA:
        $this->j5MRz->delete($this->Fc9NF->mAK7MUq8SYx());
        goto JQdp0;
        idv8l:
    }
    public function mpGt5pOOnnk() : void
    {
        goto AkN6K;
        aQtmL:
        foreach ($w0yvU as $PpUwI) {
            goto GIhvu;
            GIhvu:
            $BAVIU = $PpUwI['partNumber'];
            goto OQJep;
            YEXY5:
            Droqq:
            goto Fa2ZQ;
            OQJep:
            $IQnlV = $t0E2Y[$BAVIU];
            goto wPdNj;
            c8Ceb:
            throw new JErR6MoLsdBKL("Checksum mismatch for part {$BAVIU} of file {$this->Fc9NF->getFile()->getFilename()}");
            goto pC2FT;
            pC2FT:
            wf2x4:
            goto YEXY5;
            wPdNj:
            if (!($IQnlV['eTag'] !== $PpUwI['eTag'])) {
                goto wf2x4;
            }
            goto c8Ceb;
            Fa2ZQ:
        }
        goto Wq2xV;
        XYIM0:
        $xnQNU = $this->Diye_->getClient();
        goto jqpzm;
        aUPGF:
        $GU93H = $Zqaxi->hVSR8;
        goto GerVn;
        t1q_Q:
        $t0E2Y = collect($GU93H)->keyBy('partNumber');
        goto aQtmL;
        AkN6K:
        $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
        goto aUPGF;
        GerVn:
        $w0yvU = $Zqaxi->ST3w_;
        goto IJpBX;
        IJpBX:
        Assert::eq(count($GU93H), count($w0yvU), 'The number of parts and checksums must match.');
        goto t1q_Q;
        Wq2xV:
        MmtD8:
        goto XYIM0;
        jqpzm:
        try {
            $xnQNU->completeMultipartUpload(['Bucket' => $this->q34dl, 'Key' => $this->Fc9NF->getFile()->getLocation(), 'UploadId' => $this->Fc9NF->mLISLvz7JU3()->Ca5Pw, 'MultipartUpload' => ['Parts' => collect($this->Fc9NF->mLISLvz7JU3()->hVSR8)->sortBy('partNumber')->map(fn($IQnlV) => ['ETag' => $IQnlV['eTag'], 'PartNumber' => $IQnlV['partNumber']])->toArray()]]);
        } catch (\Throwable $kE48F) {
            throw new JErR6MoLsdBKL("Failed to merge chunks of file {$this->Fc9NF->getFile()->getFilename()}", 0, $kE48F);
        }
        goto afR6i;
        afR6i:
    }
}
