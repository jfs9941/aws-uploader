<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Presigned;

interface LWtJtdk30E0vd
{
    public function mUNxSWNsvIU();
    public function mKta32e3ZeL();
    public function mluSWeny8it();
}
