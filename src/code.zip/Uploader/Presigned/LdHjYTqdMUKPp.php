<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\GHjLMBSnTOoC3;
use Jfs\Uploader\Exception\EDfhTQpnFZOvZ;
use Jfs\Uploader\Exception\G42wr3J5chpvR;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Jfs\Uploader\Exception\WT0UbntR5RHit;
use Webmozart\Assert\Assert;
class LdHjYTqdMUKPp implements AfpsFMwSvfg9S
{
    private $EnwSG;
    private $x0wV5;
    private $f3yJU;
    private $q3TFM;
    public function __construct(GHjLMBSnTOoC3 $UEurj, Filesystem $mHTSY, Filesystem $RUQUm, string $ahaqc)
    {
        goto GWqpG;
        hbAUd:
        $this->f3yJU = $RUQUm;
        goto w4SvJ;
        GWqpG:
        $this->EnwSG = $UEurj;
        goto lejd2;
        lejd2:
        $this->x0wV5 = $mHTSY;
        goto hbAUd;
        w4SvJ:
        $this->q3TFM = $ahaqc;
        goto tOza9;
        tOza9:
    }
    public function mEnKsi71Uji()
    {
        goto ka5WA;
        mzKN1:
        $gTuIL = [];
        goto xA6mv;
        WoRFw:
        kgJtj:
        goto Bqj_1;
        TsIoF:
        $this->x0wV5->put($this->EnwSG->mgKbmuuPnDq(), json_encode($this->EnwSG->mCZg2QiXqrg()->toArray()));
        goto aO9NO;
        ZE3GK:
        $war3R = $this->f3yJU->getClient();
        goto YAEyq;
        jdTkz:
        goto kgJtj;
        goto xdWwi;
        YAEyq:
        $rWjSy = $war3R->createMultipartUpload(['Bucket' => $this->q3TFM, 'Key' => $this->EnwSG->getFile()->getLocation(), 'ContentType' => $this->EnwSG->mCZg2QiXqrg()->iZuc7, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto W1MYN;
        xA6mv:
        $ukUvl = ceil($RHxcL->WnwLD / $RHxcL->jrVTh);
        goto ZE3GK;
        cZt1p:
        $gTuIL[] = ['index' => $BcceA, 'url' => (string) $JNpPo->getUri()];
        goto t7JX4;
        uEO31:
        $SjDGw = $war3R->getCommand('UploadPart', ['Bucket' => $this->q3TFM, 'Key' => $this->EnwSG->getFile()->getLocation(), 'UploadId' => $rWjSy['UploadId'], 'PartNumber' => $BcceA]);
        goto yzuRO;
        Bqj_1:
        if (!($BcceA <= $ukUvl)) {
            goto NGf80;
        }
        goto uEO31;
        nUK3l:
        $BcceA = 1;
        goto WoRFw;
        aO9NO:
        $this->f3yJU->put($this->EnwSG->mgKbmuuPnDq(), json_encode($this->EnwSG->mCZg2QiXqrg()->toArray()));
        goto UEbg_;
        d0AMV:
        p2MPk:
        goto nUK3l;
        W1MYN:
        if (!(0 === $rWjSy->count())) {
            goto p2MPk;
        }
        goto vo191;
        Vg6Yu:
        $this->EnwSG->m3rYcjoHjjg($gTuIL);
        goto nYfFr;
        wsKaH:
        ++$BcceA;
        goto jdTkz;
        yzuRO:
        $JNpPo = $war3R->createPresignedRequest($SjDGw, '+1 day');
        goto cZt1p;
        ka5WA:
        $RHxcL = $this->EnwSG->mCZg2QiXqrg();
        goto mzKN1;
        xdWwi:
        NGf80:
        goto Vg6Yu;
        t7JX4:
        tBKhQ:
        goto wsKaH;
        vo191:
        throw new WT0UbntR5RHit("Failed to create multipart upload for file {$this->EnwSG->getFile()->getFilename()}, S3 return empty response");
        goto d0AMV;
        nYfFr:
        $this->EnwSG->mCZg2QiXqrg()->mCpgWR31fRN($rWjSy['UploadId']);
        goto TsIoF;
        UEbg_:
    }
    public function mZjmY4OFlvN() : void
    {
        goto Q1cJS;
        GLJLY:
        $this->f3yJU->delete($this->EnwSG->mgKbmuuPnDq());
        goto FH7VN;
        xl6kl:
        try {
            $war3R->abortMultipartUpload(['Bucket' => $this->q3TFM, 'Key' => $this->EnwSG->getFile()->getLocation(), 'UploadId' => $this->EnwSG->mCZg2QiXqrg()->uKrjd]);
        } catch (\Throwable $L1ZUQ) {
            throw new EDfhTQpnFZOvZ("Failed to abort multipart upload of file {$this->EnwSG->getFile()->getFilename()}", 0, $L1ZUQ);
        }
        goto jcmg5;
        Q1cJS:
        $war3R = $this->f3yJU->getClient();
        goto xl6kl;
        jcmg5:
        $this->x0wV5->delete($this->EnwSG->mgKbmuuPnDq());
        goto GLJLY;
        FH7VN:
    }
    public function mbH20YCpKPX() : void
    {
        goto M7lkr;
        UPPyh:
        Assert::eq(count($AbKCX), count($ZxcNO), 'The number of parts and checksums must match.');
        goto QCDiS;
        Ygq3h:
        try {
            $war3R->completeMultipartUpload(['Bucket' => $this->q3TFM, 'Key' => $this->EnwSG->getFile()->getLocation(), 'UploadId' => $this->EnwSG->mCZg2QiXqrg()->uKrjd, 'MultipartUpload' => ['Parts' => collect($this->EnwSG->mCZg2QiXqrg()->wihQa)->sortBy('partNumber')->map(fn($XL6nh) => ['ETag' => $XL6nh['eTag'], 'PartNumber' => $XL6nh['partNumber']])->toArray()]]);
        } catch (\Throwable $L1ZUQ) {
            throw new G42wr3J5chpvR("Failed to merge chunks of file {$this->EnwSG->getFile()->getFilename()}", 0, $L1ZUQ);
        }
        goto Z5G5R;
        aSmec:
        $war3R = $this->f3yJU->getClient();
        goto Ygq3h;
        gG03D:
        foreach ($ZxcNO as $zDB6J) {
            goto Jtcx4;
            aBVOu:
            rXSyk:
            goto qpEf1;
            CQzYm:
            $XL6nh = $rk0E2[$zy0lS];
            goto R_ApQ;
            qpEf1:
            q2blH:
            goto d1WIu;
            Jtcx4:
            $zy0lS = $zDB6J['partNumber'];
            goto CQzYm;
            aFQAx:
            throw new G42wr3J5chpvR("Checksum mismatch for part {$zy0lS} of file {$this->EnwSG->getFile()->getFilename()}");
            goto aBVOu;
            R_ApQ:
            if (!($XL6nh['eTag'] !== $zDB6J['eTag'])) {
                goto rXSyk;
            }
            goto aFQAx;
            d1WIu:
        }
        goto fH9Ma;
        QngKr:
        $ZxcNO = $RHxcL->nx1O1;
        goto UPPyh;
        o3zqk:
        $AbKCX = $RHxcL->wihQa;
        goto QngKr;
        M7lkr:
        $RHxcL = $this->EnwSG->mCZg2QiXqrg();
        goto o3zqk;
        fH9Ma:
        GQ7Fz:
        goto aSmec;
        QCDiS:
        $rk0E2 = collect($AbKCX)->keyBy('partNumber');
        goto gG03D;
        Z5G5R:
    }
}
