<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\CzJP6Lt3zlYLL;
use Jfs\Uploader\Exception\DWHlBUm01Xs6e;
use Jfs\Uploader\Exception\Ed9MsMNQ43udu;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Jfs\Uploader\Exception\Gpl3pSH841uyx;
use Webmozart\Assert\Assert;
class DcxQi2vEwPmja implements NGlxV4NFxt2kv
{
    private $lWNFo;
    private $OQTXf;
    private $TMwRg;
    private $HY2hW;
    public function __construct(CzJP6Lt3zlYLL $WoRRL, Filesystem $eL8cO, Filesystem $phksh, string $bqJVe)
    {
        goto qt9Ab;
        X4Gh9:
        $this->HY2hW = $bqJVe;
        goto Nthw6;
        NRTg3:
        $this->OQTXf = $eL8cO;
        goto p2Uay;
        p2Uay:
        $this->TMwRg = $phksh;
        goto X4Gh9;
        qt9Ab:
        $this->lWNFo = $WoRRL;
        goto NRTg3;
        Nthw6:
    }
    public function moI8qdKlCV1()
    {
        goto kGmp3;
        sOsuS:
        if (!(0 === $k7Y7P->count())) {
            goto PD7vN;
        }
        goto v9bJy;
        v9bJy:
        throw new Gpl3pSH841uyx("Failed to create multipart upload for file {$this->lWNFo->getFile()->getFilename()}, S3 return empty response");
        goto xELT3;
        w13mb:
        $fjN6S[] = ['index' => $u9OEq, 'url' => (string) $Vpdpr->getUri()];
        goto osJdd;
        zOmtk:
        $Vpdpr = $PxIqk->createPresignedRequest($yGkCT, '+1 day');
        goto w13mb;
        v0wXd:
        $this->OQTXf->put($this->lWNFo->myYTk6zPMYt(), json_encode($this->lWNFo->m0Sl3pG3XHq()->toArray()));
        goto phEj5;
        Wcv9n:
        $ol83l = ceil($JFwxi->y2OMX / $JFwxi->I1b24);
        goto RYBMu;
        Qq_5i:
        $u9OEq = 1;
        goto wCdQu;
        VDxBX:
        $this->lWNFo->mE1wovYgwvR($fjN6S);
        goto WomEb;
        ZIp3G:
        $fjN6S = [];
        goto Wcv9n;
        WomEb:
        $this->lWNFo->m0Sl3pG3XHq()->mJ42tt7T2YT($k7Y7P['UploadId']);
        goto v0wXd;
        xELT3:
        PD7vN:
        goto Qq_5i;
        XGHDa:
        if (!($u9OEq <= $ol83l)) {
            goto Hy4JW;
        }
        goto kZEIG;
        Q1RlS:
        $k7Y7P = $PxIqk->createMultipartUpload(['Bucket' => $this->HY2hW, 'Key' => $this->lWNFo->getFile()->getLocation(), 'ContentType' => $this->lWNFo->m0Sl3pG3XHq()->A15kv, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto sOsuS;
        wCdQu:
        SeoU5:
        goto XGHDa;
        RYBMu:
        $PxIqk = $this->TMwRg->getClient();
        goto Q1RlS;
        kZEIG:
        $yGkCT = $PxIqk->getCommand('UploadPart', ['Bucket' => $this->HY2hW, 'Key' => $this->lWNFo->getFile()->getLocation(), 'UploadId' => $k7Y7P['UploadId'], 'PartNumber' => $u9OEq]);
        goto zOmtk;
        cnGo4:
        Hy4JW:
        goto VDxBX;
        O3C9K:
        goto SeoU5;
        goto cnGo4;
        phEj5:
        $this->TMwRg->put($this->lWNFo->myYTk6zPMYt(), json_encode($this->lWNFo->m0Sl3pG3XHq()->toArray()));
        goto nWPLU;
        kGmp3:
        $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
        goto ZIp3G;
        osJdd:
        U1re5:
        goto GSuQs;
        GSuQs:
        ++$u9OEq;
        goto O3C9K;
        nWPLU:
    }
    public function mUJBWtzZQyJ() : void
    {
        goto OWW4W;
        pRG1h:
        $this->TMwRg->delete($this->lWNFo->myYTk6zPMYt());
        goto tR3OD;
        xZA36:
        $this->OQTXf->delete($this->lWNFo->myYTk6zPMYt());
        goto pRG1h;
        OWW4W:
        $PxIqk = $this->TMwRg->getClient();
        goto zEgzx;
        zEgzx:
        try {
            $PxIqk->abortMultipartUpload(['Bucket' => $this->HY2hW, 'Key' => $this->lWNFo->getFile()->getLocation(), 'UploadId' => $this->lWNFo->m0Sl3pG3XHq()->gWCHb]);
        } catch (\Throwable $sdtX4) {
            throw new DWHlBUm01Xs6e("Failed to abort multipart upload of file {$this->lWNFo->getFile()->getFilename()}", 0, $sdtX4);
        }
        goto xZA36;
        tR3OD:
    }
    public function m1tKpFKNKSo() : void
    {
        goto DwmNI;
        DwmNI:
        $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
        goto Joo7k;
        rXeKq:
        $bYnxU = $JFwxi->lSIOv;
        goto Fnqm8;
        qQqdY:
        foreach ($bYnxU as $FConR) {
            goto c1dQH;
            lPlpz:
            throw new Ed9MsMNQ43udu("Checksum mismatch for part {$kVsE0} of file {$this->lWNFo->getFile()->getFilename()}");
            goto MsouH;
            ymyhW:
            tGikF:
            goto adfC9;
            c1dQH:
            $kVsE0 = $FConR['partNumber'];
            goto IUeZV;
            IUeZV:
            $myPyL = $mxr_c[$kVsE0];
            goto Ph1HO;
            Ph1HO:
            if (!($myPyL['eTag'] !== $FConR['eTag'])) {
                goto q_ynC;
            }
            goto lPlpz;
            MsouH:
            q_ynC:
            goto ymyhW;
            adfC9:
        }
        goto piZj5;
        L1Blk:
        $PxIqk = $this->TMwRg->getClient();
        goto ZVAoc;
        Joo7k:
        $kr4UA = $JFwxi->HAYf_;
        goto rXeKq;
        Fnqm8:
        Assert::eq(count($kr4UA), count($bYnxU), 'The number of parts and checksums must match.');
        goto Fx7Jz;
        Fx7Jz:
        $mxr_c = collect($kr4UA)->keyBy('partNumber');
        goto qQqdY;
        ZVAoc:
        try {
            $PxIqk->completeMultipartUpload(['Bucket' => $this->HY2hW, 'Key' => $this->lWNFo->getFile()->getLocation(), 'UploadId' => $this->lWNFo->m0Sl3pG3XHq()->gWCHb, 'MultipartUpload' => ['Parts' => collect($this->lWNFo->m0Sl3pG3XHq()->HAYf_)->sortBy('partNumber')->map(fn($myPyL) => ['ETag' => $myPyL['eTag'], 'PartNumber' => $myPyL['partNumber']])->toArray()]]);
        } catch (\Throwable $sdtX4) {
            throw new Ed9MsMNQ43udu("Failed to merge chunks of file {$this->lWNFo->getFile()->getFilename()}", 0, $sdtX4);
        }
        goto TYym4;
        piZj5:
        sgIrS:
        goto L1Blk;
        TYym4:
    }
}
