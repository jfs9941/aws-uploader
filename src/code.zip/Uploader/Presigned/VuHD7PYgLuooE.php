<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\TN0vqVlBODTOO;
use Jfs\Uploader\Exception\VEpAqdlelw36X;
use Jfs\Uploader\Exception\SilEUK7TJaRKp;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Exception\L7pnSr9IBh966;
use Jfs\Uploader\Presigned\RUZz7OOZpzxlh;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class VuHD7PYgLuooE implements RUZz7OOZpzxlh
{
    private $LILxj;
    private $q6zCU;
    private $NTZHy;
    private $xhfp2;
    public function __construct(TN0vqVlBODTOO $wJPdj, Filesystem $zDbHT, Filesystem $pbv6a, string $C1Y4p)
    {
        goto M71At;
        M71At:
        $this->LILxj = $wJPdj;
        goto g3ghg;
        S6Z4I:
        $this->NTZHy = $pbv6a;
        goto PGlF3;
        PGlF3:
        $this->xhfp2 = $C1Y4p;
        goto JPANI;
        g3ghg:
        $this->q6zCU = $zDbHT;
        goto S6Z4I;
        JPANI:
    }
    public function mQwILMgE5G0()
    {
        goto CIGHw;
        odGm4:
        $S3FJC = $HuCIz->createPresignedRequest($e9rMQ, '+1 day');
        goto sqVg3;
        QC4hX:
        $Hez8p = [];
        goto UupPH;
        Jmek8:
        lKeIq:
        goto yaYOf;
        CIGHw:
        $OFuou = $this->LILxj->m67klYkiadk();
        goto QC4hX;
        rjEbA:
        if (!(0 === $NQsDq->count())) {
            goto ANyOK;
        }
        goto wLn0d;
        wLn0d:
        throw new L7pnSr9IBh966("Failed to create multipart upload for file {$this->LILxj->getFile()->getFilename()}, S3 return empty response");
        goto viDLL;
        yaYOf:
        $this->LILxj->mG9NRD5Z2bQ($Hez8p);
        goto zhqzY;
        qafWX:
        $this->NTZHy->put($this->LILxj->m0wKioa2Rfn(), json_encode($this->LILxj->m67klYkiadk()->toArray()));
        goto OUKAP;
        AOTBQ:
        ++$YxYO9;
        goto wlYx_;
        viDLL:
        ANyOK:
        goto ZcEZb;
        UupPH:
        $GvwqQ = ceil($OFuou->G7PBg / $OFuou->B1Wnn);
        goto vJBH9;
        Q3b6r:
        rdH2z:
        goto AOTBQ;
        eV4cG:
        $this->q6zCU->put($this->LILxj->m0wKioa2Rfn(), json_encode($this->LILxj->m67klYkiadk()->toArray()));
        goto qafWX;
        zhqzY:
        $this->LILxj->m67klYkiadk()->m4LXw4yPAPd($NQsDq['UploadId']);
        goto eV4cG;
        nhy5M:
        HmIXa:
        goto JrReU;
        QWt4c:
        $NQsDq = $HuCIz->createMultipartUpload(['Bucket' => $this->xhfp2, 'Key' => $this->LILxj->getFile()->getLocation(), 'ContentType' => $this->LILxj->m67klYkiadk()->PfGD5, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto rjEbA;
        wlYx_:
        goto HmIXa;
        goto Jmek8;
        cNij1:
        $e9rMQ = $HuCIz->getCommand('UploadPart', ['Bucket' => $this->xhfp2, 'Key' => $this->LILxj->getFile()->getLocation(), 'UploadId' => $NQsDq['UploadId'], 'PartNumber' => $YxYO9]);
        goto odGm4;
        sqVg3:
        $Hez8p[] = ['index' => $YxYO9, 'url' => (string) $S3FJC->getUri()];
        goto Q3b6r;
        ZcEZb:
        $YxYO9 = 1;
        goto nhy5M;
        vJBH9:
        $HuCIz = $this->NTZHy->getClient();
        goto QWt4c;
        JrReU:
        if (!($YxYO9 <= $GvwqQ)) {
            goto lKeIq;
        }
        goto cNij1;
        OUKAP:
    }
    public function m7mAhDQTm1t() : void
    {
        goto Mtmi_;
        Mtmi_:
        $HuCIz = $this->NTZHy->getClient();
        goto xxutL;
        TyQIQ:
        $this->q6zCU->delete($this->LILxj->m0wKioa2Rfn());
        goto dtEgx;
        xxutL:
        try {
            $HuCIz->abortMultipartUpload(['Bucket' => $this->xhfp2, 'Key' => $this->LILxj->getFile()->getLocation(), 'UploadId' => $this->LILxj->m67klYkiadk()->ns0Bu]);
        } catch (\Throwable $VJRSZ) {
            throw new VEpAqdlelw36X("Failed to abort multipart upload of file {$this->LILxj->getFile()->getFilename()}", 0, $VJRSZ);
        }
        goto TyQIQ;
        dtEgx:
        $this->NTZHy->delete($this->LILxj->m0wKioa2Rfn());
        goto WgJuN;
        WgJuN:
    }
    public function mtyEvCKHi25() : void
    {
        goto VqInG;
        RQ4qd:
        try {
            $HuCIz->completeMultipartUpload(['Bucket' => $this->xhfp2, 'Key' => $this->LILxj->getFile()->getLocation(), 'UploadId' => $this->LILxj->m67klYkiadk()->ns0Bu, 'MultipartUpload' => ['Parts' => collect($this->LILxj->m67klYkiadk()->DZzrV)->sortBy('partNumber')->map(fn($WW0C5) => ['ETag' => $WW0C5['eTag'], 'PartNumber' => $WW0C5['partNumber']])->toArray()]]);
        } catch (\Throwable $VJRSZ) {
            throw new SilEUK7TJaRKp("Failed to merge chunks of file {$this->LILxj->getFile()->getFilename()}", 0, $VJRSZ);
        }
        goto iWekj;
        fNvdb:
        $AWSAi = $OFuou->RfxUN;
        goto UdvOS;
        cvmSt:
        foreach ($AWSAi as $LYEZ5) {
            goto gnHeC;
            IGu7P:
            UQFL5:
            goto t5Csf;
            S1tY7:
            throw new SilEUK7TJaRKp("Checksum mismatch for part {$ObgmA} of file {$this->LILxj->getFile()->getFilename()}");
            goto IGu7P;
            t5Csf:
            vvAfW:
            goto erk19;
            Sf98U:
            $WW0C5 = $PYSmG[$ObgmA];
            goto bP2MS;
            gnHeC:
            $ObgmA = $LYEZ5['partNumber'];
            goto Sf98U;
            bP2MS:
            if (!($WW0C5['eTag'] !== $LYEZ5['eTag'])) {
                goto UQFL5;
            }
            goto S1tY7;
            erk19:
        }
        goto aZ_mY;
        aZ_mY:
        f9tky:
        goto Cg8WA;
        VqInG:
        $OFuou = $this->LILxj->m67klYkiadk();
        goto ewGjN;
        Cg8WA:
        $HuCIz = $this->NTZHy->getClient();
        goto RQ4qd;
        ewGjN:
        $R3nTL = $OFuou->DZzrV;
        goto fNvdb;
        UdvOS:
        Assert::eq(count($R3nTL), count($AWSAi), 'The number of parts and checksums must match.');
        goto M8t1D;
        M8t1D:
        $PYSmG = collect($R3nTL)->keyBy('partNumber');
        goto cvmSt;
        iWekj:
    }
}
