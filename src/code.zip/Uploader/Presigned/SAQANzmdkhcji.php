<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\McnafHoTolEIL;
use Jfs\Uploader\Exception\Q1M7vXS3k9gQN;
use Jfs\Uploader\Exception\NXYrsLyaCsn8r;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Exception\HkdIxKpisAkQn;
use Jfs\Uploader\Presigned\DRBONvY8dDfAQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class SAQANzmdkhcji implements DRBONvY8dDfAQ
{
    private $BOb2P;
    private $Ybatl;
    private $sKQBJ;
    private $Fcin3;
    public function __construct(McnafHoTolEIL $LlwTr, Filesystem $FHlTP, Filesystem $F1Ry9, string $Bnpg8)
    {
        goto ASoTe;
        Wk2m4:
        $this->sKQBJ = $F1Ry9;
        goto JPza0;
        JPza0:
        $this->Fcin3 = $Bnpg8;
        goto IV23b;
        zPmVC:
        $this->Ybatl = $FHlTP;
        goto Wk2m4;
        ASoTe:
        $this->BOb2P = $LlwTr;
        goto zPmVC;
        IV23b:
    }
    public function m9GbYa671CI()
    {
        goto vOxDa;
        KvQi7:
        $this->BOb2P->muHFWbWFrae()->mZjQHk2Fi8R($KZQPV['UploadId']);
        goto yqCN0;
        vOxDa:
        $MCnj4 = $this->BOb2P->muHFWbWFrae();
        goto zfCIT;
        urYLu:
        $Vf4A7 = 1;
        goto MJ3p3;
        SH4Fz:
        $this->BOb2P->mZ6EamKZD6W($cCJRo);
        goto KvQi7;
        abt2b:
        $this->sKQBJ->put($this->BOb2P->mGhxMypxkPu(), json_encode($this->BOb2P->muHFWbWFrae()->toArray()));
        goto iw8rR;
        brYAN:
        $B9Jbt = ceil($MCnj4->aU_jI / $MCnj4->na8lq);
        goto GERIr;
        zfCIT:
        $cCJRo = [];
        goto brYAN;
        mkDS2:
        goto FI9QZ;
        goto FegWA;
        qsXVI:
        throw new HkdIxKpisAkQn("Failed to create multipart upload for file {$this->BOb2P->getFile()->getFilename()}, S3 return empty response");
        goto ovRoU;
        BjiTD:
        $VKojO = $AFq_H->createPresignedRequest($MTKC6, '+1 day');
        goto c0dJC;
        ovRoU:
        X8UJV:
        goto urYLu;
        P9Wn7:
        $MTKC6 = $AFq_H->getCommand('UploadPart', ['Bucket' => $this->Fcin3, 'Key' => $this->BOb2P->getFile()->getLocation(), 'UploadId' => $KZQPV['UploadId'], 'PartNumber' => $Vf4A7]);
        goto BjiTD;
        FegWA:
        US1_d:
        goto SH4Fz;
        usTdT:
        ++$Vf4A7;
        goto mkDS2;
        MJ3p3:
        FI9QZ:
        goto j3R5o;
        j8CFc:
        Y1iXZ:
        goto usTdT;
        c0dJC:
        $cCJRo[] = ['index' => $Vf4A7, 'url' => (string) $VKojO->getUri()];
        goto j8CFc;
        yqCN0:
        $this->Ybatl->put($this->BOb2P->mGhxMypxkPu(), json_encode($this->BOb2P->muHFWbWFrae()->toArray()));
        goto abt2b;
        GERIr:
        $AFq_H = $this->sKQBJ->getClient();
        goto HzR4N;
        NHuVL:
        if (!(0 === $KZQPV->count())) {
            goto X8UJV;
        }
        goto qsXVI;
        j3R5o:
        if (!($Vf4A7 <= $B9Jbt)) {
            goto US1_d;
        }
        goto P9Wn7;
        HzR4N:
        $KZQPV = $AFq_H->createMultipartUpload(['Bucket' => $this->Fcin3, 'Key' => $this->BOb2P->getFile()->getLocation(), 'ContentType' => $this->BOb2P->muHFWbWFrae()->W97mt, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto NHuVL;
        iw8rR:
    }
    public function mBKuVbQuVRa() : void
    {
        goto o6uNE;
        IGIiK:
        $this->Ybatl->delete($this->BOb2P->mGhxMypxkPu());
        goto O92v_;
        lQfUJ:
        try {
            $AFq_H->abortMultipartUpload(['Bucket' => $this->Fcin3, 'Key' => $this->BOb2P->getFile()->getLocation(), 'UploadId' => $this->BOb2P->muHFWbWFrae()->rAZCi]);
        } catch (\Throwable $j62Rn) {
            throw new Q1M7vXS3k9gQN("Failed to abort multipart upload of file {$this->BOb2P->getFile()->getFilename()}", 0, $j62Rn);
        }
        goto IGIiK;
        O92v_:
        $this->sKQBJ->delete($this->BOb2P->mGhxMypxkPu());
        goto HcjxW;
        o6uNE:
        $AFq_H = $this->sKQBJ->getClient();
        goto lQfUJ;
        HcjxW:
    }
    public function mJlaumzyHgb() : void
    {
        goto ZnXty;
        n0Svg:
        J_awd:
        goto dkH22;
        yesKp:
        $hiri4 = $MCnj4->HB9Am;
        goto PTsR2;
        xPKaM:
        $YmLKp = collect($sYIWJ)->keyBy('partNumber');
        goto YYhxs;
        dlPbn:
        try {
            $AFq_H->completeMultipartUpload(['Bucket' => $this->Fcin3, 'Key' => $this->BOb2P->getFile()->getLocation(), 'UploadId' => $this->BOb2P->muHFWbWFrae()->rAZCi, 'MultipartUpload' => ['Parts' => collect($this->BOb2P->muHFWbWFrae()->kSIc5)->sortBy('partNumber')->map(fn($n7Vmw) => ['ETag' => $n7Vmw['eTag'], 'PartNumber' => $n7Vmw['partNumber']])->toArray()]]);
        } catch (\Throwable $j62Rn) {
            throw new NXYrsLyaCsn8r("Failed to merge chunks of file {$this->BOb2P->getFile()->getFilename()}", 0, $j62Rn);
        }
        goto oR5y1;
        YYhxs:
        foreach ($hiri4 as $Z2zRO) {
            goto RO3rT;
            x8Y_c:
            $n7Vmw = $YmLKp[$Pk_9P];
            goto lnmAn;
            QILtA:
            Jdzeg:
            goto HRusC;
            lnmAn:
            if (!($n7Vmw['eTag'] !== $Z2zRO['eTag'])) {
                goto V2lSv;
            }
            goto MudLM;
            MudLM:
            throw new NXYrsLyaCsn8r("Checksum mismatch for part {$Pk_9P} of file {$this->BOb2P->getFile()->getFilename()}");
            goto t6Ykp;
            t6Ykp:
            V2lSv:
            goto QILtA;
            RO3rT:
            $Pk_9P = $Z2zRO['partNumber'];
            goto x8Y_c;
            HRusC:
        }
        goto n0Svg;
        ZnXty:
        $MCnj4 = $this->BOb2P->muHFWbWFrae();
        goto zjBzY;
        PTsR2:
        Assert::eq(count($sYIWJ), count($hiri4), 'The number of parts and checksums must match.');
        goto xPKaM;
        dkH22:
        $AFq_H = $this->sKQBJ->getClient();
        goto dlPbn;
        zjBzY:
        $sYIWJ = $MCnj4->kSIc5;
        goto yesKp;
        oR5y1:
    }
}
