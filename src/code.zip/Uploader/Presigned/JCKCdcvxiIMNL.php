<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\XWJCs1ZDQGYBH;
use Jfs\Uploader\Exception\PUAPmOEHSwqE5;
use Jfs\Uploader\Exception\Y3xIXPNoq2lO8;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Exception\Kzp2tTJh5zTQn;
use Jfs\Uploader\Presigned\ZJaIDXyDkKWnB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class JCKCdcvxiIMNL implements ZJaIDXyDkKWnB
{
    private $R3E7z;
    private $ZPzJH;
    private $luUdx;
    private $kJEi8;
    public function __construct(XWJCs1ZDQGYBH $iZsfk, Filesystem $G3exm, Filesystem $u0SLj, string $r087v)
    {
        goto ht4At;
        AfiP8:
        $this->ZPzJH = $G3exm;
        goto MJpcq;
        v4RHA:
        $this->kJEi8 = $r087v;
        goto eiXbz;
        MJpcq:
        $this->luUdx = $u0SLj;
        goto v4RHA;
        ht4At:
        $this->R3E7z = $iZsfk;
        goto AfiP8;
        eiXbz:
    }
    public function mmc9EKNltDU()
    {
        goto jEv6_;
        CaMp9:
        hv4KG:
        goto vgYSB;
        gVa3n:
        $this->R3E7z->mLzfhDWzVE5()->msZ9gs4HQR8($U_gac['UploadId']);
        goto SZvmd;
        kOYSi:
        p2ZZe:
        goto Gqnno;
        qT3m9:
        $this->R3E7z->mT6C36oVf34($jwylE);
        goto gVa3n;
        j1o6c:
        $w_9Ju = $this->luUdx->getClient();
        goto i3G1X;
        U3_NL:
        $hrEZz = ceil($PSxFL->tZcBC / $PSxFL->C25S5);
        goto j1o6c;
        xWj2Y:
        goto p2ZZe;
        goto sRYoy;
        i3G1X:
        $U_gac = $w_9Ju->createMultipartUpload(['Bucket' => $this->kJEi8, 'Key' => $this->R3E7z->getFile()->getLocation(), 'ContentType' => $this->R3E7z->mLzfhDWzVE5()->AY7Co, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto BQO5N;
        SZvmd:
        $this->ZPzJH->put($this->R3E7z->mSoaLVttBsh(), json_encode($this->R3E7z->mLzfhDWzVE5()->toArray()));
        goto I9bga;
        jEv6_:
        $PSxFL = $this->R3E7z->mLzfhDWzVE5();
        goto Bdhwi;
        I9bga:
        $this->luUdx->put($this->R3E7z->mSoaLVttBsh(), json_encode($this->R3E7z->mLzfhDWzVE5()->toArray()));
        goto ad9TL;
        sRYoy:
        i0p9T:
        goto qT3m9;
        uUG07:
        pryIp:
        goto OeO7h;
        fotdq:
        $t5vaU = $w_9Ju->createPresignedRequest($bpMEn, '+1 day');
        goto GLV7G;
        dvD1C:
        throw new Kzp2tTJh5zTQn("Failed to create multipart upload for file {$this->R3E7z->getFile()->getFilename()}, S3 return empty response");
        goto CaMp9;
        BQO5N:
        if (!(0 === $U_gac->count())) {
            goto hv4KG;
        }
        goto dvD1C;
        OeO7h:
        ++$a_aYv;
        goto xWj2Y;
        Gqnno:
        if (!($a_aYv <= $hrEZz)) {
            goto i0p9T;
        }
        goto TneaG;
        TneaG:
        $bpMEn = $w_9Ju->getCommand('UploadPart', ['Bucket' => $this->kJEi8, 'Key' => $this->R3E7z->getFile()->getLocation(), 'UploadId' => $U_gac['UploadId'], 'PartNumber' => $a_aYv]);
        goto fotdq;
        Bdhwi:
        $jwylE = [];
        goto U3_NL;
        vgYSB:
        $a_aYv = 1;
        goto kOYSi;
        GLV7G:
        $jwylE[] = ['index' => $a_aYv, 'url' => (string) $t5vaU->getUri()];
        goto uUG07;
        ad9TL:
    }
    public function mEdT9RIpbT0() : void
    {
        goto w9b_L;
        w9b_L:
        $w_9Ju = $this->luUdx->getClient();
        goto amS1a;
        f0vRi:
        $this->luUdx->delete($this->R3E7z->mSoaLVttBsh());
        goto vsmmP;
        amS1a:
        try {
            $w_9Ju->abortMultipartUpload(['Bucket' => $this->kJEi8, 'Key' => $this->R3E7z->getFile()->getLocation(), 'UploadId' => $this->R3E7z->mLzfhDWzVE5()->Uyx84]);
        } catch (\Throwable $x4bzR) {
            throw new PUAPmOEHSwqE5("Failed to abort multipart upload of file {$this->R3E7z->getFile()->getFilename()}", 0, $x4bzR);
        }
        goto P0dbx;
        P0dbx:
        $this->ZPzJH->delete($this->R3E7z->mSoaLVttBsh());
        goto f0vRi;
        vsmmP:
    }
    public function m8k1eh8wcQE() : void
    {
        goto kXbQu;
        CfeM1:
        $bPa7l = $PSxFL->WSVrm;
        goto e8WIg;
        Xr3qG:
        try {
            $w_9Ju->completeMultipartUpload(['Bucket' => $this->kJEi8, 'Key' => $this->R3E7z->getFile()->getLocation(), 'UploadId' => $this->R3E7z->mLzfhDWzVE5()->Uyx84, 'MultipartUpload' => ['Parts' => collect($this->R3E7z->mLzfhDWzVE5()->z9PGG)->sortBy('partNumber')->map(fn($B0iL8) => ['ETag' => $B0iL8['eTag'], 'PartNumber' => $B0iL8['partNumber']])->toArray()]]);
        } catch (\Throwable $x4bzR) {
            throw new Y3xIXPNoq2lO8("Failed to merge chunks of file {$this->R3E7z->getFile()->getFilename()}", 0, $x4bzR);
        }
        goto JZagl;
        kXbQu:
        $PSxFL = $this->R3E7z->mLzfhDWzVE5();
        goto wbqcI;
        OGmd2:
        foreach ($bPa7l as $VeKi_) {
            goto tqIxd;
            tqIxd:
            $s66D3 = $VeKi_['partNumber'];
            goto rD6K4;
            VjGvl:
            rJ3C9:
            goto J8MQ9;
            rD6K4:
            $B0iL8 = $oSXsI[$s66D3];
            goto M3ttI;
            M3ttI:
            if (!($B0iL8['eTag'] !== $VeKi_['eTag'])) {
                goto VGrrF;
            }
            goto TqXNO;
            TqXNO:
            throw new Y3xIXPNoq2lO8("Checksum mismatch for part {$s66D3} of file {$this->R3E7z->getFile()->getFilename()}");
            goto R8AKh;
            R8AKh:
            VGrrF:
            goto VjGvl;
            J8MQ9:
        }
        goto uFq7o;
        n43TY:
        $w_9Ju = $this->luUdx->getClient();
        goto Xr3qG;
        wbqcI:
        $PoqoM = $PSxFL->z9PGG;
        goto CfeM1;
        uFq7o:
        IQpB_:
        goto n43TY;
        e8WIg:
        Assert::eq(count($PoqoM), count($bPa7l), 'The number of parts and checksums must match.');
        goto FaH6Q;
        FaH6Q:
        $oSXsI = collect($PoqoM)->keyBy('partNumber');
        goto OGmd2;
        JZagl:
    }
}
