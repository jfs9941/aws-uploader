<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\Q4cNg0cF0Oivx;
use Jfs\Uploader\Exception\B9MoXxTsOo5T7;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Presigned\Wu7dedFEcx87P;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class R4WmQd9p4yYG2 implements Wu7dedFEcx87P
{
    private static $a5LnV = 'chunks/';
    private $z1SIX;
    private $P8Yzg;
    private $Lrbr9;
    public function __construct(Q4cNg0cF0Oivx $XqWFu, Filesystem $jT0xz, Filesystem $x4E8s)
    {
        goto Z3g8M;
        P4LEd:
        $this->Lrbr9 = $x4E8s;
        goto FeNUR;
        Z3g8M:
        $this->z1SIX = $XqWFu;
        goto W8SQG;
        W8SQG:
        $this->P8Yzg = $jT0xz;
        goto P4LEd;
        FeNUR:
    }
    public function mmnQHbuvJde() : void
    {
        goto qI5NN;
        wI6rK:
        if (!($nTsbn <= $NWsS6)) {
            goto pjyc7;
        }
        goto fE9QM;
        myt5M:
        $this->z1SIX->m7mjAjbAyV9($YoH80);
        goto U3Tp4;
        K5vRM:
        $GKF7W = parse_url($NLPuF, PHP_URL_HOST);
        goto aZmhQ;
        s3RX9:
        $this->z1SIX->mjt4KTTPlCK()->mdX5318DZYf($Adfm4);
        goto NbWgj;
        W4yas:
        $Adfm4 = $SaEd8->filename;
        goto s3RX9;
        KFu21:
        JMtOP:
        goto wI6rK;
        b5ft6:
        goto JMtOP;
        goto gHmhJ;
        qI5NN:
        $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
        goto C1aW0;
        U3Tp4:
        $this->z1SIX->mjt4KTTPlCK()->mdX5318DZYf($Adfm4);
        goto IX5Tk;
        obfAk:
        $YoH80[] = ['index' => $nTsbn, 'url' => $iv1yf];
        goto QGHNG;
        gHmhJ:
        pjyc7:
        goto myt5M;
        qr45L:
        ++$nTsbn;
        goto b5ft6;
        f4vPU:
        $NWsS6 = ceil($SaEd8->Etik3 / $SaEd8->QFN10);
        goto W4yas;
        QGHNG:
        NWvXO:
        goto qr45L;
        L704x:
        $this->Lrbr9->put($this->z1SIX->m0q4dteLZ4Y(), json_encode($this->z1SIX->mjt4KTTPlCK()->toArray()));
        goto aSOZi;
        C1aW0:
        $YoH80 = [];
        goto f4vPU;
        aZmhQ:
        $iv1yf = 'https://' . $GKF7W . '/' . ltrim($AvgzF, '/');
        goto obfAk;
        IX5Tk:
        $this->P8Yzg->put($this->z1SIX->m0q4dteLZ4Y(), json_encode($this->z1SIX->mjt4KTTPlCK()->toArray()));
        goto L704x;
        fE9QM:
        $NLPuF = route('upload.api.local_chunk.upload', ['uploadId' => $Adfm4, 'index' => $nTsbn]);
        goto xxssO;
        xxssO:
        $AvgzF = parse_url($NLPuF, PHP_URL_PATH);
        goto K5vRM;
        NbWgj:
        $nTsbn = 1;
        goto KFu21;
        aSOZi:
    }
    public function mAQla2YiH6K() : void
    {
        goto nCk73;
        nCk73:
        $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
        goto aBCr3;
        dBOiw:
        $this->Lrbr9->delete($this->z1SIX->m0q4dteLZ4Y());
        goto twjeJ;
        TePyC:
        $this->P8Yzg->deleteDirectory(self::$a5LnV . $Adfm4);
        goto dBOiw;
        aBCr3:
        $Adfm4 = $SaEd8->e7KJG;
        goto TePyC;
        twjeJ:
    }
    public function mrSzJ7YzPBP() : void
    {
        goto Yy8BW;
        Yy8BW:
        $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
        goto eSy6m;
        lK9vM:
        $IG9Z9 = self::$a5LnV . $SaEd8->e7KJG;
        goto x4DtO;
        wPJtB:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $psRz9);
        goto uAWJc;
        jmUqk:
        $this->P8Yzg->makeDirectory($mPxR6);
        goto P33mi;
        fs14e:
        $vloxF = $this->P8Yzg->files($IG9Z9);
        goto dqoAB;
        TYaBu:
        natsort($vloxF);
        goto cr3KT;
        WOx2c:
        $this->P8Yzg->deleteDirectory($IG9Z9);
        goto pvaJ_;
        dqoAB:
        Assert::eq(count($vloxF), $NWsS6, 'The number of parts and checksums must match.');
        goto TYaBu;
        Jec42:
        zhNJ5:
        goto WOx2c;
        T3Btc:
        $tPx9R = $this->P8Yzg->path($IemM0);
        goto sBeeW;
        bFzPd:
        fclose($pj2f3);
        goto Ue7e8;
        slFYN:
        foreach ($vloxF as $ub_KB) {
            goto iuSZk;
            xMXM5:
            $C3hUA = @fopen($pp2BK, 'rb');
            goto aok66;
            aU8DI:
            sHPNC:
            goto q5RcL;
            vxe9h:
            if (!(false === $P10sM)) {
                goto bUx1Y;
            }
            goto Bwi1m;
            gwIAU:
            GtJAd:
            goto pzc9b;
            Bwi1m:
            throw new B9MoXxTsOo5T7('A chunk file content can not copy: ' . $pp2BK);
            goto jGDrx;
            pzc9b:
            $P10sM = stream_copy_to_stream($C3hUA, $pj2f3);
            goto yX4_2;
            iuSZk:
            $pp2BK = $this->P8Yzg->path($ub_KB);
            goto xMXM5;
            yX4_2:
            fclose($C3hUA);
            goto vxe9h;
            fEYB3:
            throw new B9MoXxTsOo5T7('A chunk file not existed: ' . $pp2BK);
            goto gwIAU;
            jGDrx:
            bUx1Y:
            goto aU8DI;
            aok66:
            if (!(false === $C3hUA)) {
                goto GtJAd;
            }
            goto fEYB3;
            q5RcL:
        }
        goto rJ6yq;
        oEe3_:
        throw new B9MoXxTsOo5T7('Local chunk can not merge file (can create file): ' . $tPx9R);
        goto Qk0i1;
        x4DtO:
        $IemM0 = $this->z1SIX->getFile()->getLocation();
        goto fs14e;
        sBeeW:
        touch($tPx9R);
        goto N1Hn9;
        rJ6yq:
        Ml9FH:
        goto bFzPd;
        eSy6m:
        $NWsS6 = $SaEd8->Upfz2;
        goto lK9vM;
        uAWJc:
        throw new \Exception('Failed to set file permissions for stored image: ' . $psRz9);
        goto Jec42;
        bWysN:
        if (chmod($psRz9, 0644)) {
            goto zhNJ5;
        }
        goto wPJtB;
        N1Hn9:
        $pj2f3 = @fopen($tPx9R, 'wb');
        goto rUCO_;
        P33mi:
        aH2k0:
        goto T3Btc;
        pCv7m:
        if ($this->P8Yzg->exists($mPxR6)) {
            goto aH2k0;
        }
        goto jmUqk;
        rUCO_:
        if (!(false === $pj2f3)) {
            goto B2GtZ;
        }
        goto oEe3_;
        Ue7e8:
        $psRz9 = $this->P8Yzg->path($IemM0);
        goto bWysN;
        cr3KT:
        $mPxR6 = dirname($IemM0);
        goto pCv7m;
        Qk0i1:
        B2GtZ:
        goto slFYN;
        pvaJ_:
    }
}
