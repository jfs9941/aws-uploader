<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Awxn6mQyQaPNK;
use Jfs\Uploader\Exception\FZgyPg0yLfLgf;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class PErikZGyAv1dJ implements IXF2PdPyf9ZxL
{
    private static $jBTr1 = 'chunks/';
    private $G_Jp3;
    private $OKvrN;
    private $y_rdZ;
    public function __construct(Awxn6mQyQaPNK $sqnmv, Filesystem $GiTtn, Filesystem $Cv4pg)
    {
        goto xVWAa;
        BYJSA:
        $this->y_rdZ = $Cv4pg;
        goto wGKsV;
        xVWAa:
        $this->G_Jp3 = $sqnmv;
        goto EVdyD;
        EVdyD:
        $this->OKvrN = $GiTtn;
        goto BYJSA;
        wGKsV:
    }
    public function mJ3A5JdqJu0() : void
    {
        goto oBUUK;
        zRRV4:
        $this->G_Jp3->mLCO6PoKT3u($Nl8Kw);
        goto WBeq7;
        sGTI3:
        $NgwJ1 = 1;
        goto s0BFA;
        WBeq7:
        $this->G_Jp3->mdWxraqGvMN()->mJvdHrWcN2f($HXXez);
        goto wC_VP;
        TZBuk:
        G7dOK:
        goto zRRV4;
        mL9eH:
        $W8PWX = ceil($jJ8fr->lIbbz / $jJ8fr->myLYQ);
        goto yAewU;
        yAewU:
        $HXXez = Uuid::v4()->toHex();
        goto opX6y;
        r9Y5_:
        $this->y_rdZ->put($this->G_Jp3->mig8npPkPHw(), json_encode($this->G_Jp3->mdWxraqGvMN()->toArray()));
        goto B_Mm4;
        wC_VP:
        $this->OKvrN->put($this->G_Jp3->mig8npPkPHw(), json_encode($this->G_Jp3->mdWxraqGvMN()->toArray()));
        goto r9Y5_;
        oBUUK:
        $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
        goto v0b23;
        gpRSE:
        if (!($NgwJ1 <= $W8PWX)) {
            goto G7dOK;
        }
        goto x0jGs;
        BqhQR:
        Qwr1Y:
        goto j9uwa;
        OcyCQ:
        goto d9RJc;
        goto TZBuk;
        j9uwa:
        ++$NgwJ1;
        goto OcyCQ;
        s0BFA:
        d9RJc:
        goto gpRSE;
        x0jGs:
        $Nl8Kw[] = ['index' => $NgwJ1, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $HXXez, 'index' => $NgwJ1])];
        goto BqhQR;
        opX6y:
        $this->G_Jp3->mdWxraqGvMN()->mJvdHrWcN2f($HXXez);
        goto sGTI3;
        v0b23:
        $Nl8Kw = [];
        goto mL9eH;
        B_Mm4:
    }
    public function mNBuHwfKe0i() : void
    {
        goto wDCFZ;
        wjDdc:
        $this->OKvrN->deleteDirectory(self::$jBTr1 . $HXXez);
        goto TmoM3;
        TmoM3:
        $this->y_rdZ->delete($this->G_Jp3->mig8npPkPHw());
        goto VJqhX;
        CGcbO:
        $HXXez = $jJ8fr->zLXWJ;
        goto wjDdc;
        wDCFZ:
        $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
        goto CGcbO;
        VJqhX:
    }
    public function mdiu2rEqHVo() : void
    {
        goto IaNLm;
        cHzAv:
        gG252:
        goto R6iXZ;
        ZI9hM:
        $cdBKm = $this->OKvrN->path($Vedo0);
        goto dJIxU;
        K2_8n:
        if ($this->OKvrN->exists($m2gTM)) {
            goto dbeUf;
        }
        goto IHNPt;
        wkHZF:
        $Vedo0 = $this->G_Jp3->getFile()->getLocation();
        goto C7t8O;
        IHNPt:
        $this->OKvrN->makeDirectory($m2gTM);
        goto iDDHd;
        CVt1k:
        MI8bd:
        goto fKh3p;
        dJIxU:
        if (chmod($cdBKm, 0644)) {
            goto MI8bd;
        }
        goto KnwZE;
        R6iXZ:
        fclose($BUI3g);
        goto ZI9hM;
        vZzKr:
        $BUI3g = @fopen($RvYqt, 'wb');
        goto PHAi0;
        KnwZE:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $cdBKm);
        goto RCD4H;
        hblen:
        AxAuv:
        goto j6f87;
        v2Qbl:
        $m2gTM = dirname($Vedo0);
        goto K2_8n;
        C7t8O:
        $HbMsi = $this->OKvrN->files($M4QPg);
        goto Jlbr5;
        IaNLm:
        $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
        goto OKjl6;
        gnokJ:
        $M4QPg = self::$jBTr1 . $jJ8fr->zLXWJ;
        goto wkHZF;
        SCWcM:
        touch($RvYqt);
        goto vZzKr;
        j6f87:
        foreach ($HbMsi as $c3gQO) {
            goto i0VNa;
            qWVvO:
            if (!(false === $SgNEL)) {
                goto hg3oD;
            }
            goto rwua0;
            namYM:
            $SgNEL = stream_copy_to_stream($HFu9d, $BUI3g);
            goto Uyde7;
            rwua0:
            throw new FZgyPg0yLfLgf('A chunk file content can not copy: ' . $gGq5Y);
            goto bF3hL;
            q7HLF:
            throw new FZgyPg0yLfLgf('A chunk file not existed: ' . $gGq5Y);
            goto Efd9D;
            Uyde7:
            fclose($HFu9d);
            goto qWVvO;
            Efd9D:
            mLFTw:
            goto namYM;
            i0VNa:
            $gGq5Y = $this->OKvrN->path($c3gQO);
            goto ym8Zn;
            oCVfN:
            Y9GZZ:
            goto ggU7k;
            qb13K:
            if (!(false === $HFu9d)) {
                goto mLFTw;
            }
            goto q7HLF;
            bF3hL:
            hg3oD:
            goto oCVfN;
            ym8Zn:
            $HFu9d = @fopen($gGq5Y, 'rb');
            goto qb13K;
            ggU7k:
        }
        goto cHzAv;
        fKh3p:
        $this->OKvrN->deleteDirectory($M4QPg);
        goto UcOgf;
        iDDHd:
        dbeUf:
        goto J4kZf;
        PHAi0:
        if (!(false === $BUI3g)) {
            goto AxAuv;
        }
        goto D_XYI;
        ziV6X:
        natsort($HbMsi);
        goto v2Qbl;
        J4kZf:
        $RvYqt = $this->OKvrN->path($Vedo0);
        goto SCWcM;
        D_XYI:
        throw new FZgyPg0yLfLgf('Local chunk can not merge file (can create file): ' . $RvYqt);
        goto hblen;
        OKjl6:
        $W8PWX = $jJ8fr->GdvAI;
        goto gnokJ;
        Jlbr5:
        Assert::eq(count($HbMsi), $W8PWX, 'The number of parts and checksums must match.');
        goto ziV6X;
        RCD4H:
        throw new \Exception('Failed to set file permissions for stored image: ' . $cdBKm);
        goto CVt1k;
        UcOgf:
    }
}
