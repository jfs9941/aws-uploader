<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\JxGHPMjqmk9TF;
use Jfs\Uploader\Exception\MOUR9efsbk01P;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Presigned\LARdlacdm9Riz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class GK5kJAmqOQKA8 implements LARdlacdm9Riz
{
    private static $R1e1c = 'chunks/';
    private $sxfrv;
    private $BX0zD;
    private $lIJMo;
    public function __construct(JxGHPMjqmk9TF $Gauo2, Filesystem $MKJ1D, Filesystem $niM9V)
    {
        goto Ae0qz;
        FvS0W:
        $this->lIJMo = $niM9V;
        goto xHv7Y;
        Y5NYD:
        $this->BX0zD = $MKJ1D;
        goto FvS0W;
        Ae0qz:
        $this->sxfrv = $Gauo2;
        goto Y5NYD;
        xHv7Y:
    }
    public function m3iQcvvYamH() : void
    {
        goto e_WNS;
        GJz_9:
        $this->sxfrv->mU5hpD7riBK()->mbFbYYzJZqu($dhlfo);
        goto e2hpj;
        MdutN:
        $VlNtM = ceil($bxW1r->dOKnU / $bxW1r->EZNZh);
        goto jfLeC;
        RFXxK:
        $this->lIJMo->put($this->sxfrv->mOcpDPbRfUf(), json_encode($this->sxfrv->mU5hpD7riBK()->toArray()));
        goto H1a4R;
        c9aml:
        ++$OGWXQ;
        goto xq0Yj;
        jfLeC:
        $dhlfo = $bxW1r->filename;
        goto GJz_9;
        WhlgK:
        $this->sxfrv->mU5hpD7riBK()->mbFbYYzJZqu($dhlfo);
        goto FzmZa;
        ESXU7:
        $HVWk2 = parse_url($S2YNe, PHP_URL_HOST);
        goto whQHD;
        xq0Yj:
        goto rvbVV;
        goto WPj9L;
        cudJs:
        $wS8JH[] = ['index' => $OGWXQ, 'url' => $wqiW2];
        goto ctcg_;
        ctcg_:
        E4q8L:
        goto c9aml;
        whQHD:
        $wqiW2 = 'https://' . $HVWk2 . ltrim($F0ycc, '/');
        goto cudJs;
        WPj9L:
        mPiKi:
        goto Gvq_O;
        FzmZa:
        $this->BX0zD->put($this->sxfrv->mOcpDPbRfUf(), json_encode($this->sxfrv->mU5hpD7riBK()->toArray()));
        goto RFXxK;
        lVnIL:
        $wS8JH = [];
        goto MdutN;
        qzjK0:
        $S2YNe = route('upload.api.local_chunk.upload', ['uploadId' => $dhlfo, 'index' => $OGWXQ]);
        goto XRV5V;
        Gvq_O:
        $this->sxfrv->mnUNm6Udcoe($wS8JH);
        goto WhlgK;
        XRV5V:
        $F0ycc = parse_url($S2YNe, PHP_URL_PATH);
        goto ESXU7;
        e2hpj:
        $OGWXQ = 1;
        goto nnhho;
        nnhho:
        rvbVV:
        goto gCZqV;
        gCZqV:
        if (!($OGWXQ <= $VlNtM)) {
            goto mPiKi;
        }
        goto qzjK0;
        e_WNS:
        $bxW1r = $this->sxfrv->mU5hpD7riBK();
        goto lVnIL;
        H1a4R:
    }
    public function ml8hDFcte5I() : void
    {
        goto u4TBh;
        u4TBh:
        $bxW1r = $this->sxfrv->mU5hpD7riBK();
        goto cw6s4;
        cw6s4:
        $dhlfo = $bxW1r->Za_0M;
        goto lRNmy;
        M0ery:
        $this->lIJMo->delete($this->sxfrv->mOcpDPbRfUf());
        goto D2mrO;
        lRNmy:
        $this->BX0zD->deleteDirectory(self::$R1e1c . $dhlfo);
        goto M0ery;
        D2mrO:
    }
    public function myrPRPm7Nb8() : void
    {
        goto NuOmI;
        RIsyn:
        $xY55H = self::$R1e1c . $bxW1r->Za_0M;
        goto DiPjW;
        cMlZF:
        throw new \Exception('Failed to set file permissions for stored image: ' . $vs2x4);
        goto s9fU1;
        daA1e:
        $FcoFm = $this->BX0zD->files($xY55H);
        goto k1FRK;
        k1FRK:
        Assert::eq(count($FcoFm), $VlNtM, 'The number of parts and checksums must match.');
        goto qcRYa;
        qcRYa:
        natsort($FcoFm);
        goto dRY0V;
        NuOmI:
        $bxW1r = $this->sxfrv->mU5hpD7riBK();
        goto v7uee;
        Vm1Cl:
        fclose($GKRKf);
        goto MKKdo;
        dDEOs:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $vs2x4);
        goto cMlZF;
        Ycxrj:
        throw new MOUR9efsbk01P('Local chunk can not merge file (can create file): ' . $goTaj);
        goto GSeXH;
        iXLmw:
        if ($this->BX0zD->exists($semjm)) {
            goto wkSFq;
        }
        goto w4wrb;
        w4wrb:
        $this->BX0zD->makeDirectory($semjm);
        goto NC4D6;
        s9fU1:
        DQ5Ao:
        goto tCtDF;
        dRY0V:
        $semjm = dirname($KHLAY);
        goto iXLmw;
        NC4D6:
        wkSFq:
        goto jUpJf;
        gXSsz:
        if (chmod($vs2x4, 0644)) {
            goto DQ5Ao;
        }
        goto dDEOs;
        tCtDF:
        $this->BX0zD->deleteDirectory($xY55H);
        goto X9c8U;
        MKKdo:
        $vs2x4 = $this->BX0zD->path($KHLAY);
        goto gXSsz;
        jpsx3:
        touch($goTaj);
        goto GIBPO;
        GIBPO:
        $GKRKf = @fopen($goTaj, 'wb');
        goto E5gcZ;
        GSeXH:
        A1iYe:
        goto DPUOe;
        DiPjW:
        $KHLAY = $this->sxfrv->getFile()->getLocation();
        goto daA1e;
        y1eZ_:
        XaZgu:
        goto Vm1Cl;
        v7uee:
        $VlNtM = $bxW1r->VPkbM;
        goto RIsyn;
        DPUOe:
        foreach ($FcoFm as $NNPfK) {
            goto kRKNs;
            zOMCj:
            xMd1D:
            goto OAfs3;
            nM2TF:
            JUVbc:
            goto F6JwC;
            QB7iA:
            throw new MOUR9efsbk01P('A chunk file not existed: ' . $BVB4p);
            goto nM2TF;
            OAfs3:
            G3rne:
            goto tvChs;
            UKxci:
            $JubFF = @fopen($BVB4p, 'rb');
            goto blLuM;
            tKYdd:
            if (!(false === $WtyD8)) {
                goto xMd1D;
            }
            goto W1HTA;
            W1HTA:
            throw new MOUR9efsbk01P('A chunk file content can not copy: ' . $BVB4p);
            goto zOMCj;
            blLuM:
            if (!(false === $JubFF)) {
                goto JUVbc;
            }
            goto QB7iA;
            kRKNs:
            $BVB4p = $this->BX0zD->path($NNPfK);
            goto UKxci;
            F6JwC:
            $WtyD8 = stream_copy_to_stream($JubFF, $GKRKf);
            goto VWuX1;
            VWuX1:
            fclose($JubFF);
            goto tKYdd;
            tvChs:
        }
        goto y1eZ_;
        E5gcZ:
        if (!(false === $GKRKf)) {
            goto A1iYe;
        }
        goto Ycxrj;
        jUpJf:
        $goTaj = $this->BX0zD->path($KHLAY);
        goto jpsx3;
        X9c8U:
    }
}
