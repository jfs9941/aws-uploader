<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\NfmgXUF97Fg3H;
use Jfs\Uploader\Exception\RbaPuaVNygIOe;
use Jfs\Uploader\Exception\FkF89X2F8xBt8;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Exception\Jg4IinP7ewzVw;
use Jfs\Uploader\Presigned\PnE0ypHyhXJqc;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class AUiO06M3Su7m7 implements PnE0ypHyhXJqc
{
    private $M2ERX;
    private $GUhIK;
    private $bBnq9;
    private $tA7Ds;
    public function __construct(NfmgXUF97Fg3H $TtzPI, Filesystem $kGo1c, Filesystem $k6y5k, string $EcbH3)
    {
        goto cB1Av;
        oOVLV:
        $this->bBnq9 = $k6y5k;
        goto gUx8Q;
        rDZt3:
        $this->GUhIK = $kGo1c;
        goto oOVLV;
        cB1Av:
        $this->M2ERX = $TtzPI;
        goto rDZt3;
        gUx8Q:
        $this->tA7Ds = $EcbH3;
        goto BM2uB;
        BM2uB:
    }
    public function mIiANiKKpuc()
    {
        goto dh1CS;
        EfSiS:
        $Qaa89 = [];
        goto E1Syk;
        Ez6pV:
        EZZmC:
        goto BYq6Z;
        oHvdz:
        $this->GUhIK->put($this->M2ERX->mbZTP3Wyy1I(), json_encode($this->M2ERX->mu6Z5XKe7fC()->toArray()));
        goto yOma1;
        S5EzH:
        throw new Jg4IinP7ewzVw("Failed to create multipart upload for file {$this->M2ERX->getFile()->getFilename()}, S3 return empty response");
        goto Ez6pV;
        fqwVu:
        $this->M2ERX->mu6Z5XKe7fC()->mZ6eTnfJjku($CT4ZU['UploadId']);
        goto oHvdz;
        E1Syk:
        $YW9DR = ceil($i4bQp->QZ4DW / $i4bQp->DKPYI);
        goto I54R7;
        SpQOu:
        if (!($TrpLY <= $YW9DR)) {
            goto NhVMN;
        }
        goto Cja1_;
        xD0fw:
        $this->M2ERX->maHJweHZt83($Qaa89);
        goto fqwVu;
        lrmwY:
        BtVLM:
        goto EuCOK;
        Z_smX:
        $Qaa89[] = ['index' => $TrpLY, 'url' => (string) $LKYnf->getUri()];
        goto lrmwY;
        Cja1_:
        $q1WOr = $w2No1->getCommand('UploadPart', ['Bucket' => $this->tA7Ds, 'Key' => $this->M2ERX->getFile()->getLocation(), 'UploadId' => $CT4ZU['UploadId'], 'PartNumber' => $TrpLY]);
        goto Sme3R;
        sfHKj:
        goto MubV5;
        goto EEJWR;
        yOma1:
        $this->bBnq9->put($this->M2ERX->mbZTP3Wyy1I(), json_encode($this->M2ERX->mu6Z5XKe7fC()->toArray()));
        goto c1Fic;
        PACaJ:
        if (!(0 === $CT4ZU->count())) {
            goto EZZmC;
        }
        goto S5EzH;
        EEJWR:
        NhVMN:
        goto xD0fw;
        ShEEY:
        MubV5:
        goto SpQOu;
        BYq6Z:
        $TrpLY = 1;
        goto ShEEY;
        I54R7:
        $w2No1 = $this->bBnq9->getClient();
        goto y72OC;
        dh1CS:
        $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
        goto EfSiS;
        Sme3R:
        $LKYnf = $w2No1->createPresignedRequest($q1WOr, '+1 day');
        goto Z_smX;
        y72OC:
        $CT4ZU = $w2No1->createMultipartUpload(['Bucket' => $this->tA7Ds, 'Key' => $this->M2ERX->getFile()->getLocation(), 'ContentType' => $this->M2ERX->mu6Z5XKe7fC()->mOR3k, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto PACaJ;
        EuCOK:
        ++$TrpLY;
        goto sfHKj;
        c1Fic:
    }
    public function mc7M89BR07U() : void
    {
        goto C_5Oo;
        sgQQc:
        $this->bBnq9->delete($this->M2ERX->mbZTP3Wyy1I());
        goto exit_;
        lHS62:
        $this->GUhIK->delete($this->M2ERX->mbZTP3Wyy1I());
        goto sgQQc;
        VOTag:
        try {
            $w2No1->abortMultipartUpload(['Bucket' => $this->tA7Ds, 'Key' => $this->M2ERX->getFile()->getLocation(), 'UploadId' => $this->M2ERX->mu6Z5XKe7fC()->xc0J5]);
        } catch (\Throwable $IGLS9) {
            throw new RbaPuaVNygIOe("Failed to abort multipart upload of file {$this->M2ERX->getFile()->getFilename()}", 0, $IGLS9);
        }
        goto lHS62;
        C_5Oo:
        $w2No1 = $this->bBnq9->getClient();
        goto VOTag;
        exit_:
    }
    public function mbcBVUFS35t() : void
    {
        goto RUNgB;
        HmuBK:
        Assert::eq(count($l5I6a), count($z_jcN), 'The number of parts and checksums must match.');
        goto jK3zB;
        xK94D:
        $w2No1 = $this->bBnq9->getClient();
        goto A2iJT;
        E8bCx:
        LUQyy:
        goto xK94D;
        tBV55:
        $l5I6a = $i4bQp->mIQ8P;
        goto uFbx8;
        Xadvr:
        foreach ($z_jcN as $wg37t) {
            goto bRLaV;
            xOx2x:
            if (!($BV__V['eTag'] !== $wg37t['eTag'])) {
                goto NVwGo;
            }
            goto Vmsju;
            bRLaV:
            $ro4vW = $wg37t['partNumber'];
            goto OG5I4;
            Vmsju:
            throw new FkF89X2F8xBt8("Checksum mismatch for part {$ro4vW} of file {$this->M2ERX->getFile()->getFilename()}");
            goto vA7ip;
            OG5I4:
            $BV__V = $O583l[$ro4vW];
            goto xOx2x;
            vA7ip:
            NVwGo:
            goto a2tqR;
            a2tqR:
            Sr5ng:
            goto W10yI;
            W10yI:
        }
        goto E8bCx;
        A2iJT:
        try {
            $w2No1->completeMultipartUpload(['Bucket' => $this->tA7Ds, 'Key' => $this->M2ERX->getFile()->getLocation(), 'UploadId' => $this->M2ERX->mu6Z5XKe7fC()->xc0J5, 'MultipartUpload' => ['Parts' => collect($this->M2ERX->mu6Z5XKe7fC()->mIQ8P)->sortBy('partNumber')->map(fn($BV__V) => ['ETag' => $BV__V['eTag'], 'PartNumber' => $BV__V['partNumber']])->toArray()]]);
        } catch (\Throwable $IGLS9) {
            throw new FkF89X2F8xBt8("Failed to merge chunks of file {$this->M2ERX->getFile()->getFilename()}", 0, $IGLS9);
        }
        goto v4aAa;
        jK3zB:
        $O583l = collect($l5I6a)->keyBy('partNumber');
        goto Xadvr;
        uFbx8:
        $z_jcN = $i4bQp->wgHxn;
        goto HmuBK;
        RUNgB:
        $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
        goto tBV55;
        v4aAa:
    }
}
