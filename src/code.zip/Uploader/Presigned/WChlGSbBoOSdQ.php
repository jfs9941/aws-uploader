<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\DXmfT6CslVApB;
use Jfs\Uploader\Exception\H3bUArvsKixXt;
use Jfs\Uploader\Exception\DYqbeptdrawEe;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Jfs\Uploader\Exception\Z2Oz6iUYznNvO;
use Webmozart\Assert\Assert;
class WChlGSbBoOSdQ implements SmDKYjZTWcESe
{
    private $BntnT;
    private $s0VP1;
    private $JjUJH;
    private $kALX2;
    public function __construct(DXmfT6CslVApB $C2BaX, Filesystem $TuWZt, Filesystem $qg6AO, string $vT463)
    {
        goto HzdFS;
        HzdFS:
        $this->BntnT = $C2BaX;
        goto JdSKf;
        Fl7Lc:
        $this->kALX2 = $vT463;
        goto C4ZSK;
        JdSKf:
        $this->s0VP1 = $TuWZt;
        goto FfiLm;
        FfiLm:
        $this->JjUJH = $qg6AO;
        goto Fl7Lc;
        C4ZSK:
    }
    public function mSJwGb2dLan()
    {
        goto LoxT9;
        Y5DKv:
        $d9aKw = $IHNE3->getCommand('UploadPart', ['Bucket' => $this->kALX2, 'Key' => $this->BntnT->getFile()->getLocation(), 'UploadId' => $hp3yb['UploadId'], 'PartNumber' => $TUv0_]);
        goto ZW31s;
        HLbkz:
        $this->s0VP1->put($this->BntnT->m8dpLxHLm9b(), json_encode($this->BntnT->m6oz0N1G29M()->toArray()));
        goto HE0JM;
        ZQlJE:
        zXpqL:
        goto WA1lp;
        xPEmM:
        $IHNE3 = $this->JjUJH->getClient();
        goto EBM6I;
        HE0JM:
        $this->JjUJH->put($this->BntnT->m8dpLxHLm9b(), json_encode($this->BntnT->m6oz0N1G29M()->toArray()));
        goto IllWr;
        EBM6I:
        $hp3yb = $IHNE3->createMultipartUpload(['Bucket' => $this->kALX2, 'Key' => $this->BntnT->getFile()->getLocation(), 'ContentType' => $this->BntnT->m6oz0N1G29M()->X2VU8, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto tflju;
        Ooj3L:
        $this->BntnT->m6oz0N1G29M()->mOkzQvX31nz($hp3yb['UploadId']);
        goto HLbkz;
        aEhQy:
        $gR5hY = [];
        goto Jv88h;
        Pia3l:
        if (!($TUv0_ <= $Wnf_y)) {
            goto n1MX9;
        }
        goto Y5DKv;
        W16Kh:
        throw new Z2Oz6iUYznNvO("Failed to create multipart upload for file {$this->BntnT->getFile()->getFilename()}, S3 return empty response");
        goto ZQlJE;
        WA1lp:
        $TUv0_ = 1;
        goto rqilE;
        RCE60:
        n1MX9:
        goto kJlfP;
        Jv88h:
        $Wnf_y = ceil($b679I->TfMNA / $b679I->BWFP_);
        goto xPEmM;
        Fskw3:
        $gR5hY[] = ['index' => $TUv0_, 'url' => (string) $nS1ZZ->getUri()];
        goto Z5eTw;
        ZW31s:
        $nS1ZZ = $IHNE3->createPresignedRequest($d9aKw, '+1 day');
        goto Fskw3;
        Z4Q6Q:
        goto qninH;
        goto RCE60;
        LoxT9:
        $b679I = $this->BntnT->m6oz0N1G29M();
        goto aEhQy;
        Z5eTw:
        kRgj5:
        goto b8D5d;
        b8D5d:
        ++$TUv0_;
        goto Z4Q6Q;
        kJlfP:
        $this->BntnT->mtMSkoI5tr5($gR5hY);
        goto Ooj3L;
        rqilE:
        qninH:
        goto Pia3l;
        tflju:
        if (!(0 === $hp3yb->count())) {
            goto zXpqL;
        }
        goto W16Kh;
        IllWr:
    }
    public function mf6JtbCKo3e() : void
    {
        goto XivH8;
        XivH8:
        $IHNE3 = $this->JjUJH->getClient();
        goto MYQJb;
        E5Fyx:
        $this->s0VP1->delete($this->BntnT->m8dpLxHLm9b());
        goto pcGsC;
        MYQJb:
        try {
            $IHNE3->abortMultipartUpload(['Bucket' => $this->kALX2, 'Key' => $this->BntnT->getFile()->getLocation(), 'UploadId' => $this->BntnT->m6oz0N1G29M()->FEcJW]);
        } catch (\Throwable $NvDiU) {
            throw new H3bUArvsKixXt("Failed to abort multipart upload of file {$this->BntnT->getFile()->getFilename()}", 0, $NvDiU);
        }
        goto E5Fyx;
        pcGsC:
        $this->JjUJH->delete($this->BntnT->m8dpLxHLm9b());
        goto Z2OSe;
        Z2OSe:
    }
    public function mxQijA6o4Nt() : void
    {
        goto RUevl;
        RUevl:
        $b679I = $this->BntnT->m6oz0N1G29M();
        goto ZCQ1T;
        D9pMh:
        $nfF1l = $b679I->s0IrZ;
        goto PeJ1Q;
        JRj6Q:
        try {
            $IHNE3->completeMultipartUpload(['Bucket' => $this->kALX2, 'Key' => $this->BntnT->getFile()->getLocation(), 'UploadId' => $this->BntnT->m6oz0N1G29M()->FEcJW, 'MultipartUpload' => ['Parts' => collect($this->BntnT->m6oz0N1G29M()->sON6q)->sortBy('partNumber')->map(fn($f9kjC) => ['ETag' => $f9kjC['eTag'], 'PartNumber' => $f9kjC['partNumber']])->toArray()]]);
        } catch (\Throwable $NvDiU) {
            throw new DYqbeptdrawEe("Failed to merge chunks of file {$this->BntnT->getFile()->getFilename()}", 0, $NvDiU);
        }
        goto v7S7A;
        xYamx:
        foreach ($nfF1l as $xvqNH) {
            goto NvWyL;
            HNcBc:
            throw new DYqbeptdrawEe("Checksum mismatch for part {$zUgL2} of file {$this->BntnT->getFile()->getFilename()}");
            goto nBm4g;
            SNC1E:
            pKsB2:
            goto PqpjU;
            NvWyL:
            $zUgL2 = $xvqNH['partNumber'];
            goto UqpbT;
            UqpbT:
            $f9kjC = $VxHf4[$zUgL2];
            goto pqbII;
            nBm4g:
            CkXNS:
            goto SNC1E;
            pqbII:
            if (!($f9kjC['eTag'] !== $xvqNH['eTag'])) {
                goto CkXNS;
            }
            goto HNcBc;
            PqpjU:
        }
        goto THbdH;
        Wx8Y0:
        $VxHf4 = collect($Wft18)->keyBy('partNumber');
        goto xYamx;
        ZCQ1T:
        $Wft18 = $b679I->sON6q;
        goto D9pMh;
        THbdH:
        K4EfU:
        goto rkpai;
        rkpai:
        $IHNE3 = $this->JjUJH->getClient();
        goto JRj6Q;
        PeJ1Q:
        Assert::eq(count($Wft18), count($nfF1l), 'The number of parts and checksums must match.');
        goto Wx8Y0;
        v7S7A:
    }
}
