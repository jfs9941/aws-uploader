<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GHjLMBSnTOoC3;
use Jfs\Uploader\Exception\G42wr3J5chpvR;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class NA9yEEgVNld2F implements AfpsFMwSvfg9S
{
    private static $sF9Uh = 'chunks/';
    private $EnwSG;
    private $x0wV5;
    private $f3yJU;
    public function __construct(GHjLMBSnTOoC3 $UEurj, Filesystem $mHTSY, Filesystem $RUQUm)
    {
        goto kJHnJ;
        kJHnJ:
        $this->EnwSG = $UEurj;
        goto YPzod;
        utspF:
        $this->f3yJU = $RUQUm;
        goto iScLa;
        YPzod:
        $this->x0wV5 = $mHTSY;
        goto utspF;
        iScLa:
    }
    public function mEnKsi71Uji() : void
    {
        goto WTfq5;
        iJUkN:
        goto ydOIC;
        goto rRhfb;
        HIFjb:
        $this->f3yJU->put($this->EnwSG->mgKbmuuPnDq(), json_encode($this->EnwSG->mCZg2QiXqrg()->toArray()));
        goto Nekft;
        rRhfb:
        tMJIj:
        goto icDtL;
        MNDMC:
        dF84o:
        goto VAjRx;
        lH7SW:
        $ukUvl = ceil($RHxcL->WnwLD / $RHxcL->jrVTh);
        goto cMbZ2;
        cMbZ2:
        $Oq4nq = Uuid::v4()->toHex();
        goto pv2IH;
        xnJbg:
        $gTuIL[] = ['index' => $BcceA, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $Oq4nq, 'index' => $BcceA])];
        goto MNDMC;
        pv2IH:
        $this->EnwSG->mCZg2QiXqrg()->mCpgWR31fRN($Oq4nq);
        goto hghiQ;
        M27sQ:
        $this->x0wV5->put($this->EnwSG->mgKbmuuPnDq(), json_encode($this->EnwSG->mCZg2QiXqrg()->toArray()));
        goto HIFjb;
        WTfq5:
        $RHxcL = $this->EnwSG->mCZg2QiXqrg();
        goto ZQw5z;
        IO6l7:
        ydOIC:
        goto GLx2v;
        VAjRx:
        ++$BcceA;
        goto iJUkN;
        icDtL:
        $this->EnwSG->m3rYcjoHjjg($gTuIL);
        goto PUW7e;
        PUW7e:
        $this->EnwSG->mCZg2QiXqrg()->mCpgWR31fRN($Oq4nq);
        goto M27sQ;
        hghiQ:
        $BcceA = 1;
        goto IO6l7;
        GLx2v:
        if (!($BcceA <= $ukUvl)) {
            goto tMJIj;
        }
        goto xnJbg;
        ZQw5z:
        $gTuIL = [];
        goto lH7SW;
        Nekft:
    }
    public function mZjmY4OFlvN() : void
    {
        goto SmxUi;
        bcm25:
        $this->x0wV5->deleteDirectory(self::$sF9Uh . $Oq4nq);
        goto NCxCD;
        lJXwt:
        $Oq4nq = $RHxcL->uKrjd;
        goto bcm25;
        SmxUi:
        $RHxcL = $this->EnwSG->mCZg2QiXqrg();
        goto lJXwt;
        NCxCD:
        $this->f3yJU->delete($this->EnwSG->mgKbmuuPnDq());
        goto WMPed;
        WMPed:
    }
    public function mbH20YCpKPX() : void
    {
        goto BiXdD;
        V1GpZ:
        TETAL:
        goto Q6q6O;
        HNiEO:
        $DQbZI = $this->x0wV5->path($HQo2M);
        goto laaRY;
        WyL1u:
        YRS5F:
        goto sMpAx;
        P6ZkY:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $DQbZI);
        goto AMY3B;
        sMpAx:
        fclose($KDR8h);
        goto HNiEO;
        Y4UpD:
        $kGxAn = dirname($HQo2M);
        goto fmqm6;
        EgpXu:
        $KDR8h = @fopen($oOMxj, 'wb');
        goto OQM9j;
        eK6b4:
        $this->x0wV5->deleteDirectory($m12Hm);
        goto VXoHE;
        jwSnl:
        throw new G42wr3J5chpvR('Local chunk can not merge file (can create file): ' . $oOMxj);
        goto V1GpZ;
        ODrsc:
        Assert::eq(count($iFduV), $ukUvl, 'The number of parts and checksums must match.');
        goto Lac5u;
        mpvjV:
        touch($oOMxj);
        goto EgpXu;
        Q6q6O:
        foreach ($iFduV as $OdF0E) {
            goto XXIg9;
            XXIg9:
            $rfN01 = $this->x0wV5->path($OdF0E);
            goto f5rQq;
            ogHDI:
            if (!(false === $lE1R2)) {
                goto tVIxD;
            }
            goto jQReq;
            w3cj3:
            if (!(false === $EVY1M)) {
                goto NA5vX;
            }
            goto KZ2In;
            f5rQq:
            $lE1R2 = @fopen($rfN01, 'rb');
            goto ogHDI;
            jQReq:
            throw new G42wr3J5chpvR('A chunk file not existed: ' . $rfN01);
            goto gM3x8;
            KZ2In:
            throw new G42wr3J5chpvR('A chunk file content can not copy: ' . $rfN01);
            goto hRcNi;
            b5MZJ:
            fclose($lE1R2);
            goto w3cj3;
            tdDyy:
            UCRjt:
            goto uwF82;
            hRcNi:
            NA5vX:
            goto tdDyy;
            gM3x8:
            tVIxD:
            goto kZb_k;
            kZb_k:
            $EVY1M = stream_copy_to_stream($lE1R2, $KDR8h);
            goto b5MZJ;
            uwF82:
        }
        goto WyL1u;
        AMY3B:
        throw new \Exception('Failed to set file permissions for stored image: ' . $DQbZI);
        goto cGcQx;
        j5EM8:
        $iFduV = $this->x0wV5->files($m12Hm);
        goto ODrsc;
        DPX81:
        $ukUvl = $RHxcL->NSSAu;
        goto YQyHC;
        Ka4Je:
        $HQo2M = $this->EnwSG->getFile()->getLocation();
        goto j5EM8;
        aYEwP:
        CCP_v:
        goto uSKmo;
        cGcQx:
        roYlB:
        goto eK6b4;
        laaRY:
        if (chmod($DQbZI, 0644)) {
            goto roYlB;
        }
        goto P6ZkY;
        Lac5u:
        natsort($iFduV);
        goto Y4UpD;
        APU_L:
        $this->x0wV5->makeDirectory($kGxAn);
        goto aYEwP;
        YQyHC:
        $m12Hm = self::$sF9Uh . $RHxcL->uKrjd;
        goto Ka4Je;
        BiXdD:
        $RHxcL = $this->EnwSG->mCZg2QiXqrg();
        goto DPX81;
        OQM9j:
        if (!(false === $KDR8h)) {
            goto TETAL;
        }
        goto jwSnl;
        fmqm6:
        if ($this->x0wV5->exists($kGxAn)) {
            goto CCP_v;
        }
        goto APU_L;
        uSKmo:
        $oOMxj = $this->x0wV5->path($HQo2M);
        goto mpvjV;
        VXoHE:
    }
}
