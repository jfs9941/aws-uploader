<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\T9ZXYI5O5GjGl;
use Jfs\Uploader\Exception\HWNR21Z34Dhkn;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Bul6otRYhfNMk implements K6ZN3VsCpjdRp
{
    private static $sYzGi = 'chunks/';
    private $xUsoB;
    private $kduDw;
    private $w2y98;
    public function __construct(T9ZXYI5O5GjGl $B107M, Filesystem $h5ffz, Filesystem $uANLN)
    {
        goto mYFML;
        BM6QE:
        $this->kduDw = $h5ffz;
        goto NitBX;
        mYFML:
        $this->xUsoB = $B107M;
        goto BM6QE;
        NitBX:
        $this->w2y98 = $uANLN;
        goto cTzBn;
        cTzBn:
    }
    public function m0nMpBVxEy8() : void
    {
        goto DuY1g;
        bxzGU:
        $OlxWo = ceil($kvLls->eD7KV / $kvLls->Xlwm2);
        goto zgbjI;
        RXmDe:
        goto PWPAZ;
        goto W_LYO;
        mv0X7:
        $this->xUsoB->mew8rrjhK4U()->m7PoIJeQDrB($gA0os);
        goto DV3XM;
        TCufO:
        $this->xUsoB->mew8rrjhK4U()->m7PoIJeQDrB($gA0os);
        goto NsVxh;
        IIVi7:
        $hj4FY = [];
        goto bxzGU;
        VavUB:
        PWPAZ:
        goto s4SGj;
        KZ4oK:
        ++$tGdfy;
        goto RXmDe;
        W_LYO:
        stnFU:
        goto tCWsy;
        UHwLl:
        $this->w2y98->put($this->xUsoB->mGsd4uDsuKt(), json_encode($this->xUsoB->mew8rrjhK4U()->toArray()));
        goto b6YMQ;
        NsVxh:
        $this->kduDw->put($this->xUsoB->mGsd4uDsuKt(), json_encode($this->xUsoB->mew8rrjhK4U()->toArray()));
        goto UHwLl;
        tCWsy:
        $this->xUsoB->m47Oa9dYR1p($hj4FY);
        goto TCufO;
        GnfqH:
        aQbOu:
        goto KZ4oK;
        DV3XM:
        $tGdfy = 1;
        goto VavUB;
        zgbjI:
        $gA0os = Uuid::v4()->toHex();
        goto mv0X7;
        s4SGj:
        if (!($tGdfy <= $OlxWo)) {
            goto stnFU;
        }
        goto Ftnzr;
        Ftnzr:
        $hj4FY[] = ['index' => $tGdfy, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $gA0os, 'index' => $tGdfy])];
        goto GnfqH;
        DuY1g:
        $kvLls = $this->xUsoB->mew8rrjhK4U();
        goto IIVi7;
        b6YMQ:
    }
    public function mFoW1sWSEnz() : void
    {
        goto AxqDO;
        rvSlY:
        $this->kduDw->deleteDirectory(self::$sYzGi . $gA0os);
        goto ncc8a;
        AxqDO:
        $kvLls = $this->xUsoB->mew8rrjhK4U();
        goto tXQV7;
        tXQV7:
        $gA0os = $kvLls->Q2m8A;
        goto rvSlY;
        ncc8a:
        $this->w2y98->delete($this->xUsoB->mGsd4uDsuKt());
        goto iH5yT;
        iH5yT:
    }
    public function m5hKOwPI9JJ() : void
    {
        goto Tv6C5;
        EHMhB:
        foreach ($pNSYY as $KanK8) {
            goto P2FRz;
            erl4e:
            throw new HWNR21Z34Dhkn('A chunk file content can not copy: ' . $RCogn);
            goto Ra71l;
            lKGPh:
            FCdSX:
            goto Qc4ve;
            uexpw:
            if (!(false === $NzG0W)) {
                goto ZOOA_;
            }
            goto erl4e;
            I_2u8:
            throw new HWNR21Z34Dhkn('A chunk file not existed: ' . $RCogn);
            goto kgHTx;
            Ra71l:
            ZOOA_:
            goto lKGPh;
            UJVyk:
            if (!(false === $hrS6u)) {
                goto SoMy1;
            }
            goto I_2u8;
            kgHTx:
            SoMy1:
            goto FgbB7;
            WfLVy:
            fclose($hrS6u);
            goto uexpw;
            wqXwz:
            $hrS6u = @fopen($RCogn, 'rb');
            goto UJVyk;
            FgbB7:
            $NzG0W = stream_copy_to_stream($hrS6u, $TlUVo);
            goto WfLVy;
            P2FRz:
            $RCogn = $this->kduDw->path($KanK8);
            goto wqXwz;
            Qc4ve:
        }
        goto ggYSE;
        VpnEB:
        faki0:
        goto po1WA;
        rh8YP:
        fclose($TlUVo);
        goto sGqaq;
        GRJJk:
        if (chmod($WDB6O, 0644)) {
            goto faki0;
        }
        goto sdleM;
        WByyd:
        GSc4A:
        goto EHMhB;
        TIwFI:
        if (!(false === $TlUVo)) {
            goto GSc4A;
        }
        goto ZCkL7;
        ZCkL7:
        throw new HWNR21Z34Dhkn('Local chunk can not merge file (can create file): ' . $Bv1tS);
        goto WByyd;
        N2tH0:
        touch($Bv1tS);
        goto UnUcY;
        zOaL6:
        $Bv1tS = $this->kduDw->path($d52Qz);
        goto N2tH0;
        GAx98:
        $MhqsF = self::$sYzGi . $kvLls->Q2m8A;
        goto PbeSA;
        cTb5B:
        $pNSYY = $this->kduDw->files($MhqsF);
        goto bfQCg;
        RbbpJ:
        $OlxWo = $kvLls->izUZw;
        goto GAx98;
        bfQCg:
        Assert::eq(count($pNSYY), $OlxWo, 'The number of parts and checksums must match.');
        goto uWErY;
        sGqaq:
        $WDB6O = $this->kduDw->path($d52Qz);
        goto GRJJk;
        ggYSE:
        EpsRC:
        goto rh8YP;
        pmNGw:
        throw new \Exception('Failed to set file permissions for stored image: ' . $WDB6O);
        goto VpnEB;
        C1YqT:
        c0Wx7:
        goto zOaL6;
        uWErY:
        natsort($pNSYY);
        goto d7fPn;
        OyXpK:
        if ($this->kduDw->exists($BiaRG)) {
            goto c0Wx7;
        }
        goto VGDvF;
        UnUcY:
        $TlUVo = @fopen($Bv1tS, 'wb');
        goto TIwFI;
        Tv6C5:
        $kvLls = $this->xUsoB->mew8rrjhK4U();
        goto RbbpJ;
        VGDvF:
        $this->kduDw->makeDirectory($BiaRG);
        goto C1YqT;
        sdleM:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $WDB6O);
        goto pmNGw;
        po1WA:
        $this->kduDw->deleteDirectory($MhqsF);
        goto In1rF;
        d7fPn:
        $BiaRG = dirname($d52Qz);
        goto OyXpK;
        PbeSA:
        $d52Qz = $this->xUsoB->getFile()->getLocation();
        goto cTb5B;
        In1rF:
    }
}
