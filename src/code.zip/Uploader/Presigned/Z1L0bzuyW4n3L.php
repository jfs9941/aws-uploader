<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\UYVrA8my964mM;
use Jfs\Uploader\Exception\O7TE1cDwqOaS4;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Presigned\TiNDeDvTZ8mIR;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Z1L0bzuyW4n3L implements TiNDeDvTZ8mIR
{
    private static $HMYyA = 'chunks/';
    private $BH22D;
    private $zoOKU;
    private $NICMg;
    public function __construct(UYVrA8my964mM $e0yCg, Filesystem $e3FbC, Filesystem $iw6E8)
    {
        goto vgTj5;
        S5pN3:
        $this->zoOKU = $e3FbC;
        goto cijSU;
        vgTj5:
        $this->BH22D = $e0yCg;
        goto S5pN3;
        cijSU:
        $this->NICMg = $iw6E8;
        goto Y8z1p;
        Y8z1p:
    }
    public function mrn0zxfXEyv() : void
    {
        goto nteIK;
        N3vbT:
        goto r4jlx;
        goto vFPg_;
        vFPg_:
        iOqlD:
        goto UThej;
        gG_rl:
        $ucyCa = ceil($AOnlH->J6RqZ / $AOnlH->UEMzw);
        goto P5VUe;
        TQBVb:
        $AVdqv = [];
        goto gG_rl;
        ExIWR:
        $this->zoOKU->put($this->BH22D->mlQjqylPuOa(), json_encode($this->BH22D->m8KWEnHETkc()->toArray()));
        goto ylo_F;
        P5VUe:
        $fLy2e = Uuid::v4()->toHex();
        goto WjQH9;
        iI1wF:
        $AVdqv[] = ['index' => $ejopc, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $fLy2e, 'index' => $ejopc])];
        goto Kk7P3;
        GgFn_:
        ++$ejopc;
        goto N3vbT;
        B9U1v:
        r4jlx:
        goto OCJe5;
        OCJe5:
        if (!($ejopc <= $ucyCa)) {
            goto iOqlD;
        }
        goto iI1wF;
        UThej:
        $this->BH22D->mz9a6JmdKBB($AVdqv);
        goto Pd7dy;
        ylo_F:
        $this->NICMg->put($this->BH22D->mlQjqylPuOa(), json_encode($this->BH22D->m8KWEnHETkc()->toArray()));
        goto lw5kS;
        WjQH9:
        $this->BH22D->m8KWEnHETkc()->mI5wGiFDJrK($fLy2e);
        goto OBUpI;
        nteIK:
        $AOnlH = $this->BH22D->m8KWEnHETkc();
        goto TQBVb;
        OBUpI:
        $ejopc = 1;
        goto B9U1v;
        Pd7dy:
        $this->BH22D->m8KWEnHETkc()->mI5wGiFDJrK($fLy2e);
        goto ExIWR;
        Kk7P3:
        ntm6q:
        goto GgFn_;
        lw5kS:
    }
    public function mlSgbNh2AvY() : void
    {
        goto Anx0B;
        B7Poc:
        $this->zoOKU->deleteDirectory(self::$HMYyA . $fLy2e);
        goto cuBAE;
        Anx0B:
        $AOnlH = $this->BH22D->m8KWEnHETkc();
        goto dsO3a;
        dsO3a:
        $fLy2e = $AOnlH->s6sgC;
        goto B7Poc;
        cuBAE:
        $this->NICMg->delete($this->BH22D->mlQjqylPuOa());
        goto VZOrc;
        VZOrc:
    }
    public function mbG9fnI6E5D() : void
    {
        goto BaoRk;
        bkBSi:
        M0b5e:
        goto zd7TF;
        xbnCS:
        foreach ($pwuvy as $I3j91) {
            goto RIYeb;
            YOteU:
            $WebwL = stream_copy_to_stream($EIPJb, $hlaNT);
            goto WYsRm;
            iXMBs:
            if (!(false === $WebwL)) {
                goto OJJu0;
            }
            goto X1Equ;
            WYsRm:
            fclose($EIPJb);
            goto iXMBs;
            RIYeb:
            $W4_6k = $this->zoOKU->path($I3j91);
            goto qwran;
            qwran:
            $EIPJb = @fopen($W4_6k, 'rb');
            goto Fb6fT;
            fK9G5:
            O1S0Q:
            goto YOteU;
            X1Equ:
            throw new O7TE1cDwqOaS4('A chunk file content can not copy: ' . $W4_6k);
            goto KBD2o;
            h99U5:
            throw new O7TE1cDwqOaS4('A chunk file not existed: ' . $W4_6k);
            goto fK9G5;
            Fb6fT:
            if (!(false === $EIPJb)) {
                goto O1S0Q;
            }
            goto h99U5;
            PMTXn:
            Ju74c:
            goto RLyp3;
            KBD2o:
            OJJu0:
            goto PMTXn;
            RLyp3:
        }
        goto bkBSi;
        aGMAa:
        throw new O7TE1cDwqOaS4('Local chunk can not merge file (can create file): ' . $o0pAU);
        goto kUOpJ;
        XNVRx:
        $ucyCa = $AOnlH->c5fBh;
        goto kqLXh;
        BaoRk:
        $AOnlH = $this->BH22D->m8KWEnHETkc();
        goto XNVRx;
        CJSt3:
        if (!(false === $hlaNT)) {
            goto YGJiS;
        }
        goto aGMAa;
        loXJG:
        $tTKg_ = $this->zoOKU->path($w42y2);
        goto m8FYS;
        Tlywh:
        natsort($pwuvy);
        goto seFsl;
        U_xvB:
        Qfv0O:
        goto p4KGq;
        hJ_IG:
        $pwuvy = $this->zoOKU->files($A1c_m);
        goto wbxqe;
        p4KGq:
        $this->zoOKU->deleteDirectory($A1c_m);
        goto sqBHY;
        rC2Ky:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $tTKg_);
        goto AS2rc;
        kUOpJ:
        YGJiS:
        goto xbnCS;
        RUJ_B:
        $hlaNT = @fopen($o0pAU, 'wb');
        goto CJSt3;
        AS2rc:
        throw new \Exception('Failed to set file permissions for stored image: ' . $tTKg_);
        goto U_xvB;
        seFsl:
        $pCRuZ = dirname($w42y2);
        goto rznZG;
        HzD7d:
        ibmyH:
        goto gTc2V;
        uM0sv:
        $w42y2 = $this->BH22D->getFile()->getLocation();
        goto hJ_IG;
        kqLXh:
        $A1c_m = self::$HMYyA . $AOnlH->s6sgC;
        goto uM0sv;
        zd7TF:
        fclose($hlaNT);
        goto loXJG;
        gTc2V:
        $o0pAU = $this->zoOKU->path($w42y2);
        goto Kxk24;
        vRc3y:
        $this->zoOKU->makeDirectory($pCRuZ);
        goto HzD7d;
        wbxqe:
        Assert::eq(count($pwuvy), $ucyCa, 'The number of parts and checksums must match.');
        goto Tlywh;
        Kxk24:
        touch($o0pAU);
        goto RUJ_B;
        m8FYS:
        if (chmod($tTKg_, 0644)) {
            goto Qfv0O;
        }
        goto rC2Ky;
        rznZG:
        if ($this->zoOKU->exists($pCRuZ)) {
            goto ibmyH;
        }
        goto vRc3y;
        sqBHY:
    }
}
