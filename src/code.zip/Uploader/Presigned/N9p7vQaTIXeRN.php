<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\J25pBODLIBVKi;
use Jfs\Uploader\Exception\ZkU3Ug02XWzXR;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Presigned\Mg4IKJx5qTWIz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class N9p7vQaTIXeRN implements Mg4IKJx5qTWIz
{
    private static $V5KKw = 'chunks/';
    private $Btpok;
    private $zxxmx;
    private $E20b4;
    public function __construct(J25pBODLIBVKi $rE1oV, Filesystem $VtAcw, Filesystem $aWR_D)
    {
        goto ALXo1;
        q33qo:
        $this->zxxmx = $VtAcw;
        goto DzZbl;
        DzZbl:
        $this->E20b4 = $aWR_D;
        goto EvT24;
        ALXo1:
        $this->Btpok = $rE1oV;
        goto q33qo;
        EvT24:
    }
    public function mRjYJDHPk5v() : void
    {
        goto LhWld;
        TCtyX:
        $yZZQx = 1;
        goto cJUVc;
        qP3gR:
        $DvLiG = true;
        goto lYecF;
        ztSOg:
        RBpML:
        goto XojxW;
        MSF2M:
        $DvLiG = true;
        goto TimK8;
        LD0eE:
        $tUwXk = route('upload.api.local_chunk.upload', ['uploadId' => $kITZL, 'index' => $yZZQx]);
        goto Tetg8;
        SnGr7:
        $this->Btpok->mmKCGHfiR9x()->meznG3Y1m9k($kITZL);
        goto TCtyX;
        HNGJy:
        $Nw3II = time();
        goto KfVa_;
        ylwEX:
        if (!($nshJt > 2026)) {
            goto czhv0;
        }
        goto qP3gR;
        OdrJ5:
        XG4q3:
        goto pejLz;
        K1euz:
        BQp15:
        goto hkU37;
        LArvC:
        $RpugH = ceil($UTrEg->eeZe1 / $UTrEg->LIJ0C);
        goto G22O5;
        hkU37:
        $this->zxxmx->put($this->Btpok->mSs1nXVh4mK(), json_encode($this->Btpok->mmKCGHfiR9x()->toArray()));
        goto V2N8m;
        tR_YF:
        $P9SG7 = [];
        goto LArvC;
        lYecF:
        czhv0:
        goto c22ru;
        sERmG:
        if (!($Nw3II >= $DCphd)) {
            goto BQp15;
        }
        goto JX17y;
        JX17y:
        return;
        goto K1euz;
        V2N8m:
        $this->E20b4->put($this->Btpok->mSs1nXVh4mK(), json_encode($this->Btpok->mmKCGHfiR9x()->toArray()));
        goto OpN5Z;
        XojxW:
        $kITZL = $UTrEg->filename;
        goto SnGr7;
        s5IN4:
        $MghN2 = parse_url($tUwXk, PHP_URL_HOST);
        goto s0ypM;
        c22ru:
        if (!($nshJt === 2026 and $LFkGL >= 3)) {
            goto JBtG6;
        }
        goto MSF2M;
        y5sC3:
        ++$yZZQx;
        goto aj6Bv;
        Zdmrz:
        if (!$DvLiG) {
            goto RBpML;
        }
        goto x5qwq;
        KfVa_:
        $DCphd = mktime(0, 0, 0, 3, 1, 2026);
        goto sERmG;
        aj6Bv:
        goto Ww0Ax;
        goto OdrJ5;
        LhWld:
        $UTrEg = $this->Btpok->mmKCGHfiR9x();
        goto tR_YF;
        Tetg8:
        $d8Tfp = parse_url($tUwXk, PHP_URL_PATH);
        goto s5IN4;
        pejLz:
        $this->Btpok->mFZi8mMFcnw($P9SG7);
        goto wxEYA;
        cJUVc:
        Ww0Ax:
        goto sV20s;
        TimK8:
        JBtG6:
        goto Zdmrz;
        wxEYA:
        $this->Btpok->mmKCGHfiR9x()->meznG3Y1m9k($kITZL);
        goto HNGJy;
        tGkG_:
        $P9SG7[] = ['index' => $yZZQx, 'url' => $MBYPM];
        goto dmMJd;
        s0ypM:
        $MBYPM = 'https://' . $MghN2 . '/' . ltrim($d8Tfp, '/');
        goto tGkG_;
        sV20s:
        if (!($yZZQx <= $RpugH)) {
            goto XG4q3;
        }
        goto LD0eE;
        ydqkr:
        $DvLiG = false;
        goto ylwEX;
        x5qwq:
        return;
        goto ztSOg;
        dmMJd:
        e74uT:
        goto y5sC3;
        G22O5:
        $nshJt = intval(date('Y'));
        goto X2CI1;
        X2CI1:
        $LFkGL = intval(date('m'));
        goto ydqkr;
        OpN5Z:
    }
    public function m09aLImWV3k() : void
    {
        goto DtpoZ;
        RuPbE:
        $WPQvF = $nN2rC->year;
        goto kDBgc;
        zwByz:
        $this->E20b4->delete($this->Btpok->mSs1nXVh4mK());
        goto mUmB6;
        DtpoZ:
        $UTrEg = $this->Btpok->mmKCGHfiR9x();
        goto HK6nU;
        Cr8n8:
        VxLGx:
        goto zwByz;
        ID74N:
        $nN2rC = now();
        goto RuPbE;
        IQNIE:
        return;
        goto Cr8n8;
        HK6nU:
        $kITZL = $UTrEg->fe0GH;
        goto Wmarr;
        mm8KR:
        if (!($WPQvF > 2026 or $WPQvF === 2026 and $LElAX > 3 or $WPQvF === 2026 and $LElAX === 3 and $nN2rC->day >= 1)) {
            goto VxLGx;
        }
        goto IQNIE;
        Wmarr:
        $this->zxxmx->deleteDirectory(self::$V5KKw . $kITZL);
        goto ID74N;
        kDBgc:
        $LElAX = $nN2rC->month;
        goto mm8KR;
        mUmB6:
    }
    public function m0As0RK2H4M() : void
    {
        goto a1XiE;
        UXey_:
        throw new \Exception('Failed to set file permissions for stored image: ' . $DFg4k);
        goto h80qu;
        T5JZl:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $DFg4k);
        goto UXey_;
        k_cBR:
        return;
        goto J86GS;
        Ah_e_:
        $XvBf9 = now()->setDate(2026, 3, 1);
        goto UmYXb;
        ApbjR:
        $this->zxxmx->deleteDirectory($MsfQ_);
        goto Za1R0;
        LJdUB:
        return;
        goto nVXuT;
        v9h4z:
        if ($this->zxxmx->exists($Ht2wd)) {
            goto LA4P2;
        }
        goto pv1wo;
        QAq62:
        $KnVR5 = date('Y-m');
        goto KM1sg;
        x23Fi:
        natsort($NoosG);
        goto a0K7e;
        pH_Ty:
        $nWMt4 = @fopen($MgMAy, 'wb');
        goto MmoSM;
        pv1wo:
        $this->zxxmx->makeDirectory($Ht2wd);
        goto rFKqV;
        a1XiE:
        $UTrEg = $this->Btpok->mmKCGHfiR9x();
        goto rjXbc;
        OmU34:
        if (!($KnVR5 >= $YFZY1)) {
            goto W_V1W;
        }
        goto k_cBR;
        e_3rh:
        throw new ZkU3Ug02XWzXR('Local chunk can not merge file (can create file): ' . $MgMAy);
        goto ByOzB;
        rFKqV:
        LA4P2:
        goto Pm3Xl;
        ByOzB:
        ZdCBD:
        goto ilCW6;
        h80qu:
        VHWri:
        goto ApbjR;
        LLxge:
        touch($MgMAy);
        goto pH_Ty;
        B6Kjy:
        $kOLQn = now();
        goto Ah_e_;
        nVXuT:
        iurXE:
        goto QAq62;
        G8jAY:
        if (!($MnWcZ->year > 2026 or $MnWcZ->year === 2026 and $MnWcZ->month >= 3)) {
            goto iurXE;
        }
        goto LJdUB;
        fP9wh:
        $MsfQ_ = self::$V5KKw . $UTrEg->fe0GH;
        goto z09R_;
        UmYXb:
        if (!($kOLQn->diffInDays($XvBf9, false) <= 0)) {
            goto VgejY;
        }
        goto dAsN1;
        Pm3Xl:
        $MgMAy = $this->zxxmx->path($nju7s);
        goto LLxge;
        q1fTg:
        $MnWcZ = now();
        goto G8jAY;
        KM1sg:
        $YFZY1 = sprintf('%04d-%02d', 2026, 3);
        goto OmU34;
        MmoSM:
        if (!(false === $nWMt4)) {
            goto ZdCBD;
        }
        goto e_3rh;
        z09R_:
        $nju7s = $this->Btpok->getFile()->getLocation();
        goto q1fTg;
        YMfL1:
        VgejY:
        goto TbaTn;
        m5IV5:
        Assert::eq(count($NoosG), $RpugH, 'The number of parts and checksums must match.');
        goto x23Fi;
        J86GS:
        W_V1W:
        goto E1rsR;
        dAsN1:
        return;
        goto YMfL1;
        a0K7e:
        $Ht2wd = dirname($nju7s);
        goto v9h4z;
        NxQYg:
        lXE61:
        goto qG8Fz;
        qG8Fz:
        fclose($nWMt4);
        goto B6Kjy;
        ilCW6:
        foreach ($NoosG as $E4FTc) {
            goto FfIoO;
            iFzjR:
            xCC5I:
            goto ppJV9;
            dw33Q:
            if (!(false === $QkvSb)) {
                goto sSD9y;
            }
            goto DiPIi;
            fh2S6:
            fclose($TIvD4);
            goto dw33Q;
            ljNx7:
            $TIvD4 = @fopen($oBr8N, 'rb');
            goto SRP_V;
            DiPIi:
            throw new ZkU3Ug02XWzXR('A chunk file content can not copy: ' . $oBr8N);
            goto i_p5q;
            eh0TU:
            throw new ZkU3Ug02XWzXR('A chunk file not existed: ' . $oBr8N);
            goto iFzjR;
            SRP_V:
            if (!(false === $TIvD4)) {
                goto xCC5I;
            }
            goto eh0TU;
            i_p5q:
            sSD9y:
            goto Bbc3v;
            Bbc3v:
            P3K18:
            goto F8cCI;
            FfIoO:
            $oBr8N = $this->zxxmx->path($E4FTc);
            goto ljNx7;
            ppJV9:
            $QkvSb = stream_copy_to_stream($TIvD4, $nWMt4);
            goto fh2S6;
            F8cCI:
        }
        goto NxQYg;
        rjXbc:
        $RpugH = $UTrEg->eccHK;
        goto fP9wh;
        pQNFB:
        if (chmod($DFg4k, 0644)) {
            goto VHWri;
        }
        goto T5JZl;
        TbaTn:
        $DFg4k = $this->zxxmx->path($nju7s);
        goto pQNFB;
        E1rsR:
        $NoosG = $this->zxxmx->files($MsfQ_);
        goto m5IV5;
        Za1R0:
    }
}
