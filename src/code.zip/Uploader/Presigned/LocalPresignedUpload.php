<?php
declare(strict_types=1);

namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\PreSignedModel;
use Jfs\Uploader\Exception\ChunkMergeException;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;

class LocalPresignedUpload implements PresignedUploadInterface
{
    private static $chunkFolder = 'chunks/';
    /**
     * @var PreSignedModel
     */
    private $preSignedModel;
    /**
     * @var Filesystem
     */
    private $localStorage;
    /**
     * @var Filesystem
     */
    private $s3Storage;

    public function __construct(
        PreSignedModel $preSignedModel,
        Filesystem $localStorage,
        Filesystem $s3Storage,
    ) {
        $this->preSignedModel = $preSignedModel;
        $this->localStorage = $localStorage;
        $this->s3Storage = $s3Storage;
    }

    /**
     * @throws InvalidTempFileException
     */
    public function generateUrls(): void
    {
        $metadata = $this->preSignedModel->metadata();
        $urls = [];
        $totalChunks = ceil($metadata->fileSize / $metadata->chunkSize);

        $uploadId = Uuid::v4()->toHex();
        $this->preSignedModel->metadata()->setUploadId($uploadId);

        for ($chunkIndex = 1; $chunkIndex <= $totalChunks; ++$chunkIndex) {
            $urls[] = [
                'index' => $chunkIndex,
                'url' => route('upload.api.local_chunk.upload', ['uploadId' => $uploadId, 'index' => $chunkIndex]),
            ];
        }

        $this->preSignedModel->withTempUrls($urls);
        $this->preSignedModel->metadata()->setUploadId($uploadId);

        $this->localStorage->put(
            $this->preSignedModel->metaDataFile(),
            json_encode($this->preSignedModel->metadata()->toArray())
        );
        // backup in s3
        $this->s3Storage->put(
            $this->preSignedModel->metaDataFile(),
            json_encode($this->preSignedModel->metadata()->toArray())
        );
    }

    public function abort(): void
    {
        $metadata = $this->preSignedModel->metadata();
        $uploadId = $metadata->uploadId;
        // delete all chunks
        $this->localStorage->deleteDirectory(self::$chunkFolder.$uploadId);
        $this->s3Storage->delete($this->preSignedModel->metaDataFile());
    }

    /**
     * @throws InvalidTempFileException|ChunkMergeException
     */
    public function finish(): void
    {
        $metadata = $this->preSignedModel->metadata();
        $totalChunks = $metadata->totalChunk;

        $chunkPath = self::$chunkFolder.$metadata->uploadId;
        $finalPath = $this->preSignedModel->getFile()->getLocation();

        $chunks = $this->localStorage->files($chunkPath);
        Assert::eq(count($chunks), $totalChunks, 'The number of parts and checksums must match.');

        natsort($chunks);
        $finalFileDir = dirname($finalPath);
        if (!$this->localStorage->exists($finalFileDir)) {
            $this->localStorage->makeDirectory($finalFileDir);
        }
        $finalPathAbs = $this->localStorage->path($finalPath);
        touch($finalPathAbs);

        $outputHandle = @fopen($finalPathAbs, 'wb');
        if (false === $outputHandle) {
            throw new ChunkMergeException('Local chunk can not merge file (can create file): '.$finalPathAbs);
        }
        // Merge chunks into the final file
        foreach ($chunks as $chunkFile) {
            $chunkFileAbs = $this->localStorage->path($chunkFile);
            $sourceHandle = @fopen($chunkFileAbs, 'rb');
            if (false === $sourceHandle) {
                throw new ChunkMergeException('A chunk file not existed: '.$chunkFileAbs);
            }

            // Copy the entire stream content from source to output
            // This is memory efficient as it buffers internally
            $bytesCopied = stream_copy_to_stream($sourceHandle, $outputHandle);

            // Close the source file handle immediately after copying
            fclose($sourceHandle);

            if (false === $bytesCopied) {
                throw new ChunkMergeException('A chunk file content can not copy: '.$chunkFileAbs);
            }
        }
        fclose($outputHandle);

        $storedFilePath = $this->localStorage->path($finalPath);
        if (!chmod($storedFilePath, 0644)) {
            Log::warning('Failed to set file permissions for stored video (chunk merge local): '.$storedFilePath);
            throw new \Exception('Failed to set file permissions for stored image: '.$storedFilePath);
        }
        $this->localStorage->deleteDirectory($chunkPath);
    }
}
