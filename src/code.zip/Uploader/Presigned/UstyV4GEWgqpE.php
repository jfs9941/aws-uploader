<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\D4VgMZN43BF8o;
use Jfs\Uploader\Exception\PNXeQKcuBBTf6;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Presigned\C8O6TZAvz7rlJ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class UstyV4GEWgqpE implements C8O6TZAvz7rlJ
{
    private static $ptT2U = 'chunks/';
    private $f0YGu;
    private $W9e5K;
    private $cEZhz;
    public function __construct(D4VgMZN43BF8o $oXu1C, Filesystem $XCkIj, Filesystem $UubHF)
    {
        goto vGWJ1;
        vGWJ1:
        $this->f0YGu = $oXu1C;
        goto Ry9bU;
        rfLH2:
        $this->cEZhz = $UubHF;
        goto ysmPF;
        Ry9bU:
        $this->W9e5K = $XCkIj;
        goto rfLH2;
        ysmPF:
    }
    public function mxPosq9wO3K() : void
    {
        goto bIfaS;
        O8pra:
        $lt0mW = $u_EX6->filename;
        goto V21eT;
        cmeQr:
        $RfsQZ = route('upload.api.local_chunk.upload', ['uploadId' => $lt0mW, 'index' => $g4K44]);
        goto pwtdC;
        L3J9h:
        goto cDcGI;
        goto BHUZd;
        DybpO:
        $r3v05 = 'https://' . $iX_Yd . '/' . ltrim($vRakW, '/');
        goto Ynp11;
        daDKS:
        $jYIXy = [];
        goto nw5ZQ;
        Xidoe:
        $iX_Yd = parse_url($RfsQZ, PHP_URL_HOST);
        goto DybpO;
        pwtdC:
        $vRakW = parse_url($RfsQZ, PHP_URL_PATH);
        goto Xidoe;
        vNHfB:
        if (!($g4K44 <= $unvls)) {
            goto UoM6S;
        }
        goto cmeQr;
        BHUZd:
        UoM6S:
        goto iLuYp;
        nw5ZQ:
        $unvls = ceil($u_EX6->mx_ve / $u_EX6->kar4X);
        goto O8pra;
        IWLNt:
        $this->W9e5K->put($this->f0YGu->mEFYvbcZNB2(), json_encode($this->f0YGu->mlPpDqeRPNC()->toArray()));
        goto HhWu_;
        Oaugo:
        rQ1Z5:
        goto DOiFX;
        iLuYp:
        $this->f0YGu->mJCTfUV9czb($jYIXy);
        goto QJQqR;
        HhWu_:
        $this->cEZhz->put($this->f0YGu->mEFYvbcZNB2(), json_encode($this->f0YGu->mlPpDqeRPNC()->toArray()));
        goto tmuq0;
        QJQqR:
        $this->f0YGu->mlPpDqeRPNC()->mm4W6bXFGdY($lt0mW);
        goto IWLNt;
        V21eT:
        $this->f0YGu->mlPpDqeRPNC()->mm4W6bXFGdY($lt0mW);
        goto bgTpk;
        bgTpk:
        $g4K44 = 1;
        goto R6gOf;
        R6gOf:
        cDcGI:
        goto vNHfB;
        DOiFX:
        ++$g4K44;
        goto L3J9h;
        bIfaS:
        $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
        goto daDKS;
        Ynp11:
        $jYIXy[] = ['index' => $g4K44, 'url' => $r3v05];
        goto Oaugo;
        tmuq0:
    }
    public function mSWgr2hpZl5() : void
    {
        goto QIYuI;
        nLfEC:
        $this->W9e5K->deleteDirectory(self::$ptT2U . $lt0mW);
        goto Wah0Z;
        oOf2j:
        $lt0mW = $u_EX6->ROwMs;
        goto nLfEC;
        Wah0Z:
        $this->cEZhz->delete($this->f0YGu->mEFYvbcZNB2());
        goto P_O3U;
        QIYuI:
        $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
        goto oOf2j;
        P_O3U:
    }
    public function maTvNKYiGsC() : void
    {
        goto RqUBC;
        SQyX9:
        $tj2N4 = $this->W9e5K->path($kur8X);
        goto htXuq;
        mh_an:
        M542h:
        goto Gxn4t;
        FOCHk:
        $PnH2Z = $this->W9e5K->files($Lu3nf);
        goto Fr618;
        K5pF4:
        $kur8X = $this->f0YGu->getFile()->getLocation();
        goto FOCHk;
        qu6qL:
        if (!(false === $pf365)) {
            goto WNR6z;
        }
        goto PdFdR;
        QDdO5:
        $pf365 = @fopen($tj2N4, 'wb');
        goto qu6qL;
        mZ3oR:
        natsort($PnH2Z);
        goto btNNv;
        Sdt_H:
        throw new \Exception('Failed to set file permissions for stored image: ' . $smgSm);
        goto gZCyu;
        xubfp:
        foreach ($PnH2Z as $l1Akq) {
            goto X3N8M;
            BPec0:
            fclose($mYFSq);
            goto M306w;
            j2Rhs:
            gH1PV:
            goto oRDKd;
            KoNe6:
            shatT:
            goto j2Rhs;
            eKnAn:
            throw new PNXeQKcuBBTf6('A chunk file not existed: ' . $KehbI);
            goto IucZH;
            IucZH:
            xASXK:
            goto gVkdb;
            gVkdb:
            $GbCSW = stream_copy_to_stream($mYFSq, $pf365);
            goto BPec0;
            M306w:
            if (!(false === $GbCSW)) {
                goto shatT;
            }
            goto pt2kP;
            pt2kP:
            throw new PNXeQKcuBBTf6('A chunk file content can not copy: ' . $KehbI);
            goto KoNe6;
            X3N8M:
            $KehbI = $this->W9e5K->path($l1Akq);
            goto uQADu;
            uQADu:
            $mYFSq = @fopen($KehbI, 'rb');
            goto a1j4i;
            a1j4i:
            if (!(false === $mYFSq)) {
                goto xASXK;
            }
            goto eKnAn;
            oRDKd:
        }
        goto mh_an;
        Fr618:
        Assert::eq(count($PnH2Z), $unvls, 'The number of parts and checksums must match.');
        goto mZ3oR;
        kzAKF:
        if (chmod($smgSm, 0644)) {
            goto LQdI4;
        }
        goto TG1Ba;
        btNNv:
        $xNdzX = dirname($kur8X);
        goto dLQpT;
        RqUBC:
        $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
        goto kJE3B;
        PdFdR:
        throw new PNXeQKcuBBTf6('Local chunk can not merge file (can create file): ' . $tj2N4);
        goto vHG_j;
        TG1Ba:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $smgSm);
        goto Sdt_H;
        x2SsD:
        $smgSm = $this->W9e5K->path($kur8X);
        goto kzAKF;
        MjdpX:
        $Lu3nf = self::$ptT2U . $u_EX6->ROwMs;
        goto K5pF4;
        Gxn4t:
        fclose($pf365);
        goto x2SsD;
        dLQpT:
        if ($this->W9e5K->exists($xNdzX)) {
            goto kA1Nj;
        }
        goto G1540;
        kJE3B:
        $unvls = $u_EX6->OkOje;
        goto MjdpX;
        G1540:
        $this->W9e5K->makeDirectory($xNdzX);
        goto byvIc;
        byvIc:
        kA1Nj:
        goto SQyX9;
        htXuq:
        touch($tj2N4);
        goto QDdO5;
        vHG_j:
        WNR6z:
        goto xubfp;
        crwpM:
        $this->W9e5K->deleteDirectory($Lu3nf);
        goto pFr78;
        gZCyu:
        LQdI4:
        goto crwpM;
        pFr78:
    }
}
