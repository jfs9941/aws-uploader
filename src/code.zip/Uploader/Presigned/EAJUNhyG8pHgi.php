<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\VhdgLYFn8a0ds;
use Jfs\Uploader\Exception\Mekt7oJZzvgCe;
use Jfs\Uploader\Exception\GYCnGhJDSoV27;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Exception\Mm1DniqQSEZXb;
use Jfs\Uploader\Presigned\HdpJMuzf2MANg;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class EAJUNhyG8pHgi implements HdpJMuzf2MANg
{
    private $yK1hJ;
    private $IA8m0;
    private $mzEj7;
    private $to1A0;
    public function __construct(VhdgLYFn8a0ds $Fr4mD, Filesystem $Rgxn3, Filesystem $z6qdY, string $QlBWR)
    {
        goto sQOch;
        f0bvf:
        $this->IA8m0 = $Rgxn3;
        goto VRbF4;
        sQOch:
        $this->yK1hJ = $Fr4mD;
        goto f0bvf;
        oQF1X:
        $this->to1A0 = $QlBWR;
        goto uqf1O;
        VRbF4:
        $this->mzEj7 = $z6qdY;
        goto oQF1X;
        uqf1O:
    }
    public function mCyzSeB6wKx()
    {
        goto LgO8L;
        OnWi9:
        $ace3H[] = ['index' => $bc2Ij, 'url' => (string) $PRC2n->getUri()];
        goto nQ1h9;
        UrQtd:
        $this->mzEj7->put($this->yK1hJ->mBtVCiNqqCF(), json_encode($this->yK1hJ->mMYcEvkVSg5()->toArray()));
        goto TXQ6Q;
        SVtnT:
        $this->yK1hJ->mSYLEwNVAPm($ace3H);
        goto ltoIS;
        nQ1h9:
        MpFvu:
        goto Ld6nz;
        sMwL7:
        $J61wK = ceil($cor5J->l3D2R / $cor5J->VA2jP);
        goto cbv32;
        T2ir6:
        throw new Mm1DniqQSEZXb("Failed to create multipart upload for file {$this->yK1hJ->getFile()->getFilename()}, S3 return empty response");
        goto LUuWz;
        ltoIS:
        $this->yK1hJ->mMYcEvkVSg5()->m2yI097SE4n($pVb4c['UploadId']);
        goto sZQRw;
        cbv32:
        $UVwEi = $this->mzEj7->getClient();
        goto z0coE;
        O1pHm:
        goto LVx8B;
        goto R0dxH;
        z0coE:
        $pVb4c = $UVwEi->createMultipartUpload(['Bucket' => $this->to1A0, 'Key' => $this->yK1hJ->getFile()->getLocation(), 'ContentType' => $this->yK1hJ->mMYcEvkVSg5()->Zokpz, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto JGLMK;
        K42dq:
        $bc2Ij = 1;
        goto ACsLd;
        c5X9A:
        if (!($bc2Ij <= $J61wK)) {
            goto hnAlQ;
        }
        goto t4gjY;
        LgO8L:
        $cor5J = $this->yK1hJ->mMYcEvkVSg5();
        goto rh2jM;
        JGLMK:
        if (!(0 === $pVb4c->count())) {
            goto HWVN3;
        }
        goto T2ir6;
        ACsLd:
        LVx8B:
        goto c5X9A;
        sZQRw:
        $this->IA8m0->put($this->yK1hJ->mBtVCiNqqCF(), json_encode($this->yK1hJ->mMYcEvkVSg5()->toArray()));
        goto UrQtd;
        HzZeV:
        $PRC2n = $UVwEi->createPresignedRequest($yBESy, '+1 day');
        goto OnWi9;
        LUuWz:
        HWVN3:
        goto K42dq;
        R0dxH:
        hnAlQ:
        goto SVtnT;
        Ld6nz:
        ++$bc2Ij;
        goto O1pHm;
        t4gjY:
        $yBESy = $UVwEi->getCommand('UploadPart', ['Bucket' => $this->to1A0, 'Key' => $this->yK1hJ->getFile()->getLocation(), 'UploadId' => $pVb4c['UploadId'], 'PartNumber' => $bc2Ij]);
        goto HzZeV;
        rh2jM:
        $ace3H = [];
        goto sMwL7;
        TXQ6Q:
    }
    public function mx9xMkU9qJu() : void
    {
        goto JLR1u;
        Y0Y0u:
        try {
            $UVwEi->abortMultipartUpload(['Bucket' => $this->to1A0, 'Key' => $this->yK1hJ->getFile()->getLocation(), 'UploadId' => $this->yK1hJ->mMYcEvkVSg5()->ZsH2f]);
        } catch (\Throwable $lzebJ) {
            throw new Mekt7oJZzvgCe("Failed to abort multipart upload of file {$this->yK1hJ->getFile()->getFilename()}", 0, $lzebJ);
        }
        goto sI_gR;
        sI_gR:
        $this->IA8m0->delete($this->yK1hJ->mBtVCiNqqCF());
        goto zvB2_;
        zvB2_:
        $this->mzEj7->delete($this->yK1hJ->mBtVCiNqqCF());
        goto ojXkF;
        JLR1u:
        $UVwEi = $this->mzEj7->getClient();
        goto Y0Y0u;
        ojXkF:
    }
    public function m0VtXeYPu88() : void
    {
        goto K3np0;
        DCpJC:
        foreach ($xEjOf as $DOQBU) {
            goto autGB;
            y4z1I:
            pkisX:
            goto CLg2f;
            YVr57:
            throw new GYCnGhJDSoV27("Checksum mismatch for part {$i5eaO} of file {$this->yK1hJ->getFile()->getFilename()}");
            goto y4z1I;
            kjoCp:
            if (!($aH1Ln['eTag'] !== $DOQBU['eTag'])) {
                goto pkisX;
            }
            goto YVr57;
            tOzy0:
            $aH1Ln = $m6yVE[$i5eaO];
            goto kjoCp;
            autGB:
            $i5eaO = $DOQBU['partNumber'];
            goto tOzy0;
            CLg2f:
            C3fIf:
            goto CAJ0i;
            CAJ0i:
        }
        goto YqUDt;
        W1Y2L:
        $m6yVE = collect($qwLXm)->keyBy('partNumber');
        goto DCpJC;
        YqUDt:
        nuHJD:
        goto DcxxB;
        fNGY0:
        try {
            $UVwEi->completeMultipartUpload(['Bucket' => $this->to1A0, 'Key' => $this->yK1hJ->getFile()->getLocation(), 'UploadId' => $this->yK1hJ->mMYcEvkVSg5()->ZsH2f, 'MultipartUpload' => ['Parts' => collect($this->yK1hJ->mMYcEvkVSg5()->Ka7W8)->sortBy('partNumber')->map(fn($aH1Ln) => ['ETag' => $aH1Ln['eTag'], 'PartNumber' => $aH1Ln['partNumber']])->toArray()]]);
        } catch (\Throwable $lzebJ) {
            throw new GYCnGhJDSoV27("Failed to merge chunks of file {$this->yK1hJ->getFile()->getFilename()}", 0, $lzebJ);
        }
        goto oFuFP;
        DcxxB:
        $UVwEi = $this->mzEj7->getClient();
        goto fNGY0;
        nE7T5:
        Assert::eq(count($qwLXm), count($xEjOf), 'The number of parts and checksums must match.');
        goto W1Y2L;
        LJOaF:
        $xEjOf = $cor5J->Uw4WG;
        goto nE7T5;
        K3np0:
        $cor5J = $this->yK1hJ->mMYcEvkVSg5();
        goto ayVtk;
        ayVtk:
        $qwLXm = $cor5J->Ka7W8;
        goto LJOaF;
        oFuFP:
    }
}
