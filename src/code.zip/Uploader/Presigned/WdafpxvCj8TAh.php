<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\VxCHgU78wg1To;
use Jfs\Uploader\Exception\IcOUDAYIheEwx;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Presigned\HHDOLLFxFHuta;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class WdafpxvCj8TAh implements HHDOLLFxFHuta
{
    private static $PXJBJ = 'chunks/';
    private $vHhJT;
    private $c5PSU;
    private $RGW8z;
    public function __construct(VxCHgU78wg1To $TUNr2, Filesystem $Ape3_, Filesystem $Dm30C)
    {
        goto pP1dM;
        pP1dM:
        $this->vHhJT = $TUNr2;
        goto UukBz;
        fwdOP:
        $this->RGW8z = $Dm30C;
        goto C_oZe;
        UukBz:
        $this->c5PSU = $Ape3_;
        goto fwdOP;
        C_oZe:
    }
    public function me4pj6MGrcy() : void
    {
        goto mUeWH;
        bpKW8:
        $this->vHhJT->muUg8to4YNh()->mivWGZsVcDB($hqf7_);
        goto x0saP;
        VisXq:
        $Qe1YG = ceil($j1WQY->dZOy6 / $j1WQY->vG8bM);
        goto hHHng;
        rvRnW:
        $this->vHhJT->muUg8to4YNh()->mivWGZsVcDB($hqf7_);
        goto Yokk3;
        fH_hF:
        $this->vHhJT->mYxiThMveVg($Fwvpc);
        goto bpKW8;
        iBryB:
        $Fwvpc[] = ['index' => $Ky6oD, 'url' => $aMRGK];
        goto cCRTX;
        T2gbZ:
        $xKMQp = parse_url($zbNSu, PHP_URL_HOST);
        goto Ffj1f;
        nYCwU:
        Z7EGU:
        goto MJdLf;
        x0saP:
        $this->c5PSU->put($this->vHhJT->m0QUuINWJKg(), json_encode($this->vHhJT->muUg8to4YNh()->toArray()));
        goto eXL_m;
        Lx2n1:
        JFhOV:
        goto fH_hF;
        eXL_m:
        $this->RGW8z->put($this->vHhJT->m0QUuINWJKg(), json_encode($this->vHhJT->muUg8to4YNh()->toArray()));
        goto xpteM;
        hHHng:
        $hqf7_ = $j1WQY->filename;
        goto rvRnW;
        cCRTX:
        gv6E_:
        goto WvRIZ;
        MJdLf:
        if (!($Ky6oD <= $Qe1YG)) {
            goto JFhOV;
        }
        goto SGuaJ;
        sIiIu:
        goto Z7EGU;
        goto Lx2n1;
        Ffj1f:
        $aMRGK = 'https://' . $xKMQp . ltrim($HyAAV, '/');
        goto iBryB;
        bl9YG:
        $Fwvpc = [];
        goto VisXq;
        voPgf:
        $HyAAV = parse_url($zbNSu, PHP_URL_PATH);
        goto T2gbZ;
        WvRIZ:
        ++$Ky6oD;
        goto sIiIu;
        mUeWH:
        $j1WQY = $this->vHhJT->muUg8to4YNh();
        goto bl9YG;
        Yokk3:
        $Ky6oD = 1;
        goto nYCwU;
        SGuaJ:
        $zbNSu = route('upload.api.local_chunk.upload', ['uploadId' => $hqf7_, 'index' => $Ky6oD]);
        goto voPgf;
        xpteM:
    }
    public function mnz8JEKyXsH() : void
    {
        goto Pxop6;
        Pxop6:
        $j1WQY = $this->vHhJT->muUg8to4YNh();
        goto FaTkA;
        SDXfI:
        $this->c5PSU->deleteDirectory(self::$PXJBJ . $hqf7_);
        goto etNnp;
        etNnp:
        $this->RGW8z->delete($this->vHhJT->m0QUuINWJKg());
        goto kjx2U;
        FaTkA:
        $hqf7_ = $j1WQY->X_FKb;
        goto SDXfI;
        kjx2U:
    }
    public function m70IYXIfVKq() : void
    {
        goto ifsow;
        B05mJ:
        $LVB_s = @fopen($aN078, 'wb');
        goto WFCy8;
        ICBE2:
        $fqAwd = $this->c5PSU->path($CUEmY);
        goto oGsx2;
        JhP46:
        if ($this->c5PSU->exists($Eobed)) {
            goto R6fa3;
        }
        goto vP_dV;
        ad6MB:
        $sP_Fq = $this->c5PSU->files($UA24I);
        goto s2lSw;
        EvXDE:
        natsort($sP_Fq);
        goto G0qri;
        aw8qa:
        foreach ($sP_Fq as $Ul0cg) {
            goto PuSHp;
            SYzIw:
            Wd_A1:
            goto HZmkS;
            dnQIJ:
            throw new IcOUDAYIheEwx('A chunk file not existed: ' . $OryEf);
            goto JWEzm;
            Jawmx:
            if (!(false === $iaRTV)) {
                goto BJAB6;
            }
            goto dnQIJ;
            ZUtWZ:
            $iaRTV = @fopen($OryEf, 'rb');
            goto Jawmx;
            HZmkS:
            Mns2h:
            goto AhiYD;
            ny2gk:
            throw new IcOUDAYIheEwx('A chunk file content can not copy: ' . $OryEf);
            goto SYzIw;
            E1h7U:
            fclose($iaRTV);
            goto sYmf6;
            sYmf6:
            if (!(false === $Y0pkm)) {
                goto Wd_A1;
            }
            goto ny2gk;
            JWEzm:
            BJAB6:
            goto UxuHZ;
            UxuHZ:
            $Y0pkm = stream_copy_to_stream($iaRTV, $LVB_s);
            goto E1h7U;
            PuSHp:
            $OryEf = $this->c5PSU->path($Ul0cg);
            goto ZUtWZ;
            AhiYD:
        }
        goto lKVRI;
        vP_dV:
        $this->c5PSU->makeDirectory($Eobed);
        goto HTuFS;
        YyfpJ:
        fclose($LVB_s);
        goto ICBE2;
        UodW4:
        NMXxu:
        goto Y3ute;
        yrj60:
        aCRhg:
        goto aw8qa;
        gtKj9:
        throw new IcOUDAYIheEwx('Local chunk can not merge file (can create file): ' . $aN078);
        goto yrj60;
        oGsx2:
        if (chmod($fqAwd, 0644)) {
            goto NMXxu;
        }
        goto f9oN1;
        HTuFS:
        R6fa3:
        goto yBHxn;
        h62WP:
        throw new \Exception('Failed to set file permissions for stored image: ' . $fqAwd);
        goto UodW4;
        yBHxn:
        $aN078 = $this->c5PSU->path($CUEmY);
        goto ad6F1;
        JQemm:
        $Qe1YG = $j1WQY->fqUWd;
        goto d_zkH;
        G0qri:
        $Eobed = dirname($CUEmY);
        goto JhP46;
        ad6F1:
        touch($aN078);
        goto B05mJ;
        d_zkH:
        $UA24I = self::$PXJBJ . $j1WQY->X_FKb;
        goto jarCO;
        lKVRI:
        ya4kX:
        goto YyfpJ;
        s2lSw:
        Assert::eq(count($sP_Fq), $Qe1YG, 'The number of parts and checksums must match.');
        goto EvXDE;
        WFCy8:
        if (!(false === $LVB_s)) {
            goto aCRhg;
        }
        goto gtKj9;
        Y3ute:
        $this->c5PSU->deleteDirectory($UA24I);
        goto Rx5kj;
        jarCO:
        $CUEmY = $this->vHhJT->getFile()->getLocation();
        goto ad6MB;
        ifsow:
        $j1WQY = $this->vHhJT->muUg8to4YNh();
        goto JQemm;
        f9oN1:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $fqAwd);
        goto h62WP;
        Rx5kj:
    }
}
