<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\RQ9bDEqcUZdSJ;
use Jfs\Uploader\Exception\HHqCZ8LmOyQMw;
use Jfs\Uploader\Exception\RDRYmywN95fGw;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Exception\XxbEYY9iusJHN;
use Jfs\Uploader\Presigned\U1ZvgsGt0teMT;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class MksEWJ9CWnSXw implements U1ZvgsGt0teMT
{
    private $Y6NCf;
    private $gcP3F;
    private $Ck8AK;
    private $n_TUX;
    public function __construct(RQ9bDEqcUZdSJ $HuGK_, Filesystem $qxxOf, Filesystem $P4KJD, string $EwO1g)
    {
        goto elab5;
        Cr_NM:
        $this->n_TUX = $EwO1g;
        goto JJ2sM;
        elab5:
        $this->Y6NCf = $HuGK_;
        goto lr3H5;
        w2aUK:
        $this->Ck8AK = $P4KJD;
        goto Cr_NM;
        lr3H5:
        $this->gcP3F = $qxxOf;
        goto w2aUK;
        JJ2sM:
    }
    public function mm4dJgrnW0N()
    {
        goto S78dR;
        aPagY:
        JLbIc:
        goto TMr2U;
        Z8kig:
        $gfw60 = 1;
        goto aPagY;
        e08ld:
        $zTSUl = $EYytr->createPresignedRequest($epCy7, '+1 day');
        goto mRbhS;
        Z3YQ0:
        goto JLbIc;
        goto sRCcV;
        gs0qo:
        $R0pa8 = [];
        goto b0TjK;
        ydn2x:
        $this->gcP3F->put($this->Y6NCf->mzDDruv07Tv(), json_encode($this->Y6NCf->mg099Xaz8Vo()->toArray()));
        goto uq3jd;
        QBQlI:
        laSrs:
        goto DJArd;
        agTJU:
        $epCy7 = $EYytr->getCommand('UploadPart', ['Bucket' => $this->n_TUX, 'Key' => $this->Y6NCf->getFile()->getLocation(), 'UploadId' => $uyT2h['UploadId'], 'PartNumber' => $gfw60]);
        goto e08ld;
        b0TjK:
        $MnHFq = ceil($LGjda->iGEiJ / $LGjda->c9RKE);
        goto qXY0X;
        r5IDS:
        throw new XxbEYY9iusJHN("Failed to create multipart upload for file {$this->Y6NCf->getFile()->getFilename()}, S3 return empty response");
        goto grEFf;
        p1qSg:
        if (!(0 === $uyT2h->count())) {
            goto V84td;
        }
        goto r5IDS;
        embxs:
        $this->Y6NCf->mg099Xaz8Vo()->ma96A33591M($uyT2h['UploadId']);
        goto ydn2x;
        TMr2U:
        if (!($gfw60 <= $MnHFq)) {
            goto NnoYT;
        }
        goto agTJU;
        mRbhS:
        $R0pa8[] = ['index' => $gfw60, 'url' => (string) $zTSUl->getUri()];
        goto QBQlI;
        jKm55:
        $this->Y6NCf->mLUJMMpbAb4($R0pa8);
        goto embxs;
        S78dR:
        $LGjda = $this->Y6NCf->mg099Xaz8Vo();
        goto gs0qo;
        DJArd:
        ++$gfw60;
        goto Z3YQ0;
        grEFf:
        V84td:
        goto Z8kig;
        sRCcV:
        NnoYT:
        goto jKm55;
        qXY0X:
        $EYytr = $this->Ck8AK->getClient();
        goto jH_o2;
        jH_o2:
        $uyT2h = $EYytr->createMultipartUpload(['Bucket' => $this->n_TUX, 'Key' => $this->Y6NCf->getFile()->getLocation(), 'ContentType' => $this->Y6NCf->mg099Xaz8Vo()->RlQMg, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto p1qSg;
        uq3jd:
        $this->Ck8AK->put($this->Y6NCf->mzDDruv07Tv(), json_encode($this->Y6NCf->mg099Xaz8Vo()->toArray()));
        goto E0FAJ;
        E0FAJ:
    }
    public function mCHqfrmH8l8() : void
    {
        goto NV9nM;
        qzArd:
        $this->Ck8AK->delete($this->Y6NCf->mzDDruv07Tv());
        goto r6TPd;
        NV9nM:
        $EYytr = $this->Ck8AK->getClient();
        goto wBBzi;
        wBBzi:
        try {
            $EYytr->abortMultipartUpload(['Bucket' => $this->n_TUX, 'Key' => $this->Y6NCf->getFile()->getLocation(), 'UploadId' => $this->Y6NCf->mg099Xaz8Vo()->Z1W73]);
        } catch (\Throwable $R1uEk) {
            throw new HHqCZ8LmOyQMw("Failed to abort multipart upload of file {$this->Y6NCf->getFile()->getFilename()}", 0, $R1uEk);
        }
        goto rEkQk;
        rEkQk:
        $this->gcP3F->delete($this->Y6NCf->mzDDruv07Tv());
        goto qzArd;
        r6TPd:
    }
    public function mLNNdTnrcAS() : void
    {
        goto XOuK8;
        jb3vZ:
        $cTMz9 = collect($Y_W7Y)->keyBy('partNumber');
        goto mF82Q;
        gzKw8:
        try {
            $EYytr->completeMultipartUpload(['Bucket' => $this->n_TUX, 'Key' => $this->Y6NCf->getFile()->getLocation(), 'UploadId' => $this->Y6NCf->mg099Xaz8Vo()->Z1W73, 'MultipartUpload' => ['Parts' => collect($this->Y6NCf->mg099Xaz8Vo()->i1Hdt)->sortBy('partNumber')->map(fn($kP1C2) => ['ETag' => $kP1C2['eTag'], 'PartNumber' => $kP1C2['partNumber']])->toArray()]]);
        } catch (\Throwable $R1uEk) {
            throw new RDRYmywN95fGw("Failed to merge chunks of file {$this->Y6NCf->getFile()->getFilename()}", 0, $R1uEk);
        }
        goto nMUm2;
        aZyRD:
        $EYytr = $this->Ck8AK->getClient();
        goto gzKw8;
        XOuK8:
        $LGjda = $this->Y6NCf->mg099Xaz8Vo();
        goto z2d7k;
        mF82Q:
        foreach ($V_q0k as $Q8tZs) {
            goto fIXJw;
            fIXJw:
            $Rhpzn = $Q8tZs['partNumber'];
            goto PDHKm;
            PDHKm:
            $kP1C2 = $cTMz9[$Rhpzn];
            goto BgEP7;
            nuSSD:
            throw new RDRYmywN95fGw("Checksum mismatch for part {$Rhpzn} of file {$this->Y6NCf->getFile()->getFilename()}");
            goto Eh7xr;
            Eh7xr:
            CjlCZ:
            goto tGqaE;
            tGqaE:
            aCAPc:
            goto NIKck;
            BgEP7:
            if (!($kP1C2['eTag'] !== $Q8tZs['eTag'])) {
                goto CjlCZ;
            }
            goto nuSSD;
            NIKck:
        }
        goto PC3PP;
        Y_pjW:
        Assert::eq(count($Y_W7Y), count($V_q0k), 'The number of parts and checksums must match.');
        goto jb3vZ;
        neyqq:
        $V_q0k = $LGjda->sI2p5;
        goto Y_pjW;
        z2d7k:
        $Y_W7Y = $LGjda->i1Hdt;
        goto neyqq;
        PC3PP:
        vwRph:
        goto aZyRD;
        nMUm2:
    }
}
