<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\FUCc1kyYZtja3;
use Jfs\Uploader\Exception\WW5pDRGQrONbo;
use Jfs\Uploader\Exception\W80S3BIfDCcVT;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Jfs\Uploader\Exception\YpoiqWaDwsF02;
use Webmozart\Assert\Assert;
class WdzeVRaluz7By implements GRbUnlgi8rQIE
{
    private $WdyLh;
    private $bX3fI;
    private $UAt4g;
    private $rczpf;
    public function __construct(FUCc1kyYZtja3 $ld3oH, Filesystem $Q0hWX, Filesystem $RdfoB, string $qir1P)
    {
        goto h9tvi;
        hmVhg:
        $this->rczpf = $qir1P;
        goto C6Wmz;
        xyR4w:
        $this->UAt4g = $RdfoB;
        goto hmVhg;
        h9tvi:
        $this->WdyLh = $ld3oH;
        goto PTs6t;
        PTs6t:
        $this->bX3fI = $Q0hWX;
        goto xyR4w;
        C6Wmz:
    }
    public function mFKsPsWJiLu()
    {
        goto R3ZI2;
        TF4Dd:
        if (!(0 === $rvOSs->count())) {
            goto PN3T8;
        }
        goto zZZ4g;
        vYZ5J:
        $this->UAt4g->put($this->WdyLh->mHD2WAKGQbz(), json_encode($this->WdyLh->mkBf6Gw5jFn()->toArray()));
        goto BhLhH;
        xrIz6:
        $mmk9B = $fHhL2->createPresignedRequest($crffk, '+1 day');
        goto TW2Tq;
        ibxI2:
        ++$KoFTL;
        goto H7h7Z;
        TW2Tq:
        $d_ind[] = ['index' => $KoFTL, 'url' => (string) $mmk9B->getUri()];
        goto WlOJl;
        Znr6k:
        $this->WdyLh->mlNtTK4pngF($d_ind);
        goto B430c;
        JFKD4:
        $d_ind = [];
        goto wx4bS;
        Fu17z:
        $crffk = $fHhL2->getCommand('UploadPart', ['Bucket' => $this->rczpf, 'Key' => $this->WdyLh->getFile()->getLocation(), 'UploadId' => $rvOSs['UploadId'], 'PartNumber' => $KoFTL]);
        goto xrIz6;
        Q2EwT:
        if (!($KoFTL <= $Pl90N)) {
            goto XAB1g;
        }
        goto Fu17z;
        M6K7X:
        XAB1g:
        goto Znr6k;
        wx4bS:
        $Pl90N = ceil($szNd7->Nx14_ / $szNd7->Z1nJX);
        goto RiCKz;
        R3ZI2:
        $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
        goto JFKD4;
        eOprO:
        PN3T8:
        goto lNSpa;
        RiCKz:
        $fHhL2 = $this->UAt4g->getClient();
        goto hqNXb;
        H7h7Z:
        goto xe9qA;
        goto M6K7X;
        lNSpa:
        $KoFTL = 1;
        goto hE2er;
        zZZ4g:
        throw new YpoiqWaDwsF02("Failed to create multipart upload for file {$this->WdyLh->getFile()->getFilename()}, S3 return empty response");
        goto eOprO;
        ldP8q:
        $this->bX3fI->put($this->WdyLh->mHD2WAKGQbz(), json_encode($this->WdyLh->mkBf6Gw5jFn()->toArray()));
        goto vYZ5J;
        WlOJl:
        H9Cu1:
        goto ibxI2;
        B430c:
        $this->WdyLh->mkBf6Gw5jFn()->mV8qOAW9LsS($rvOSs['UploadId']);
        goto ldP8q;
        hqNXb:
        $rvOSs = $fHhL2->createMultipartUpload(['Bucket' => $this->rczpf, 'Key' => $this->WdyLh->getFile()->getLocation(), 'ContentType' => $this->WdyLh->mkBf6Gw5jFn()->v1MoV, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto TF4Dd;
        hE2er:
        xe9qA:
        goto Q2EwT;
        BhLhH:
    }
    public function mvhetYh8Svj() : void
    {
        goto XAEdV;
        sJKg7:
        try {
            $fHhL2->abortMultipartUpload(['Bucket' => $this->rczpf, 'Key' => $this->WdyLh->getFile()->getLocation(), 'UploadId' => $this->WdyLh->mkBf6Gw5jFn()->PnBsq]);
        } catch (\Throwable $djmN_) {
            throw new WW5pDRGQrONbo("Failed to abort multipart upload of file {$this->WdyLh->getFile()->getFilename()}", 0, $djmN_);
        }
        goto Yqxcv;
        Yqxcv:
        $this->bX3fI->delete($this->WdyLh->mHD2WAKGQbz());
        goto nL0pi;
        XAEdV:
        $fHhL2 = $this->UAt4g->getClient();
        goto sJKg7;
        nL0pi:
        $this->UAt4g->delete($this->WdyLh->mHD2WAKGQbz());
        goto a2uFG;
        a2uFG:
    }
    public function mrCHpJ7Uki3() : void
    {
        goto xvEGQ;
        X41Ik:
        try {
            $fHhL2->completeMultipartUpload(['Bucket' => $this->rczpf, 'Key' => $this->WdyLh->getFile()->getLocation(), 'UploadId' => $this->WdyLh->mkBf6Gw5jFn()->PnBsq, 'MultipartUpload' => ['Parts' => collect($this->WdyLh->mkBf6Gw5jFn()->ODhaJ)->sortBy('partNumber')->map(fn($fuv5a) => ['ETag' => $fuv5a['eTag'], 'PartNumber' => $fuv5a['partNumber']])->toArray()]]);
        } catch (\Throwable $djmN_) {
            throw new W80S3BIfDCcVT("Failed to merge chunks of file {$this->WdyLh->getFile()->getFilename()}", 0, $djmN_);
        }
        goto zfZZh;
        YZggD:
        $Rf9Ka = collect($MF1dT)->keyBy('partNumber');
        goto GbpQU;
        IJSpd:
        $fHhL2 = $this->UAt4g->getClient();
        goto X41Ik;
        Al_1W:
        $R5uXi = $szNd7->eTR5r;
        goto fy2Vm;
        n2SQG:
        $MF1dT = $szNd7->ODhaJ;
        goto Al_1W;
        fy2Vm:
        Assert::eq(count($MF1dT), count($R5uXi), 'The number of parts and checksums must match.');
        goto YZggD;
        GbpQU:
        foreach ($R5uXi as $LOiqe) {
            goto nF6m1;
            C9494:
            NNIlI:
            goto vGhQR;
            d9RyQ:
            JeQPu:
            goto C9494;
            a2dVu:
            if (!($fuv5a['eTag'] !== $LOiqe['eTag'])) {
                goto JeQPu;
            }
            goto Qkv0q;
            nF6m1:
            $U0Bsr = $LOiqe['partNumber'];
            goto h5VJ3;
            Qkv0q:
            throw new W80S3BIfDCcVT("Checksum mismatch for part {$U0Bsr} of file {$this->WdyLh->getFile()->getFilename()}");
            goto d9RyQ;
            h5VJ3:
            $fuv5a = $Rf9Ka[$U0Bsr];
            goto a2dVu;
            vGhQR:
        }
        goto DOITk;
        xvEGQ:
        $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
        goto n2SQG;
        DOITk:
        mQ7k1:
        goto IJSpd;
        zfZZh:
    }
}
