<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CzJP6Lt3zlYLL;
use Jfs\Uploader\Exception\Ed9MsMNQ43udu;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class ZnBgxCEucBw3W implements NGlxV4NFxt2kv
{
    private static $Sj1TE = 'chunks/';
    private $lWNFo;
    private $OQTXf;
    private $TMwRg;
    public function __construct(CzJP6Lt3zlYLL $WoRRL, Filesystem $eL8cO, Filesystem $phksh)
    {
        goto O508l;
        uyYhm:
        $this->OQTXf = $eL8cO;
        goto VCXy5;
        VCXy5:
        $this->TMwRg = $phksh;
        goto Ka9G8;
        O508l:
        $this->lWNFo = $WoRRL;
        goto uyYhm;
        Ka9G8:
    }
    public function moI8qdKlCV1() : void
    {
        goto HTJ__;
        NtgCx:
        goto j9oMj;
        goto jZTFf;
        o7Wba:
        $this->lWNFo->m0Sl3pG3XHq()->mJ42tt7T2YT($EXsQV);
        goto uI9f2;
        gVVyD:
        ++$u9OEq;
        goto NtgCx;
        wX2xg:
        $fjN6S[] = ['index' => $u9OEq, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $EXsQV, 'index' => $u9OEq])];
        goto iQwLx;
        rtZTj:
        $this->lWNFo->m0Sl3pG3XHq()->mJ42tt7T2YT($EXsQV);
        goto UWPPw;
        kwS0j:
        $ol83l = ceil($JFwxi->y2OMX / $JFwxi->I1b24);
        goto g1A0_;
        ZobpS:
        j9oMj:
        goto H0_Oe;
        iQwLx:
        AHs_N:
        goto gVVyD;
        UWPPw:
        $this->OQTXf->put($this->lWNFo->myYTk6zPMYt(), json_encode($this->lWNFo->m0Sl3pG3XHq()->toArray()));
        goto K5ePA;
        H0_Oe:
        if (!($u9OEq <= $ol83l)) {
            goto EDgla;
        }
        goto wX2xg;
        HTJ__:
        $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
        goto u1hOK;
        g1A0_:
        $EXsQV = Uuid::v4()->toHex();
        goto o7Wba;
        A7o7G:
        $this->lWNFo->mE1wovYgwvR($fjN6S);
        goto rtZTj;
        uI9f2:
        $u9OEq = 1;
        goto ZobpS;
        K5ePA:
        $this->TMwRg->put($this->lWNFo->myYTk6zPMYt(), json_encode($this->lWNFo->m0Sl3pG3XHq()->toArray()));
        goto BJ1zG;
        u1hOK:
        $fjN6S = [];
        goto kwS0j;
        jZTFf:
        EDgla:
        goto A7o7G;
        BJ1zG:
    }
    public function mUJBWtzZQyJ() : void
    {
        goto d2Aok;
        ukLgh:
        $EXsQV = $JFwxi->gWCHb;
        goto bFirv;
        YLmYm:
        $this->TMwRg->delete($this->lWNFo->myYTk6zPMYt());
        goto y6mlx;
        bFirv:
        $this->OQTXf->deleteDirectory(self::$Sj1TE . $EXsQV);
        goto YLmYm;
        d2Aok:
        $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
        goto ukLgh;
        y6mlx:
    }
    public function m1tKpFKNKSo() : void
    {
        goto ECQBF;
        zUuae:
        oEjPi:
        goto PhhJP;
        jE4te:
        $qKPwm = $this->lWNFo->getFile()->getLocation();
        goto oPuQ9;
        Q_Iuk:
        fclose($VcIcf);
        goto N8evF;
        N8evF:
        $BptXp = $this->OQTXf->path($qKPwm);
        goto YaGak;
        gnUvn:
        natsort($CsXti);
        goto YcdTY;
        J4PCA:
        $l2vQI = $this->OQTXf->path($qKPwm);
        goto tHQxm;
        Y0AUQ:
        $ol83l = $JFwxi->bVVFN;
        goto YV2Vs;
        ECQBF:
        $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
        goto Y0AUQ;
        EgVok:
        z2sNL:
        goto Q_Iuk;
        YcdTY:
        $lMgza = dirname($qKPwm);
        goto r09lj;
        OViYP:
        $this->OQTXf->makeDirectory($lMgza);
        goto l8zY3;
        Ymdee:
        $this->OQTXf->deleteDirectory($pjepC);
        goto PP3Qq;
        PhhJP:
        foreach ($CsXti as $PhMEA) {
            goto cHZv2;
            zmetV:
            throw new Ed9MsMNQ43udu('A chunk file content can not copy: ' . $HHwOY);
            goto iMF3J;
            iMF3J:
            yadiQ:
            goto frkO6;
            B8PI5:
            throw new Ed9MsMNQ43udu('A chunk file not existed: ' . $HHwOY);
            goto TzBuy;
            akm2m:
            if (!(false === $jTdQT)) {
                goto sole1;
            }
            goto B8PI5;
            UGz0i:
            fclose($jTdQT);
            goto Z1Uva;
            cHZv2:
            $HHwOY = $this->OQTXf->path($PhMEA);
            goto mTleo;
            TzBuy:
            sole1:
            goto bT4bS;
            Z1Uva:
            if (!(false === $viiIL)) {
                goto yadiQ;
            }
            goto zmetV;
            mTleo:
            $jTdQT = @fopen($HHwOY, 'rb');
            goto akm2m;
            bT4bS:
            $viiIL = stream_copy_to_stream($jTdQT, $VcIcf);
            goto UGz0i;
            frkO6:
            LjWpE:
            goto wmw59;
            wmw59:
        }
        goto EgVok;
        IWfqG:
        if (!(false === $VcIcf)) {
            goto oEjPi;
        }
        goto X6cZq;
        tHQxm:
        touch($l2vQI);
        goto yPLFn;
        adidF:
        GJwSs:
        goto Ymdee;
        r09lj:
        if ($this->OQTXf->exists($lMgza)) {
            goto dPhI2;
        }
        goto OViYP;
        i6xZ1:
        throw new \Exception('Failed to set file permissions for stored image: ' . $BptXp);
        goto adidF;
        oPuQ9:
        $CsXti = $this->OQTXf->files($pjepC);
        goto dsROv;
        l8zY3:
        dPhI2:
        goto J4PCA;
        dsROv:
        Assert::eq(count($CsXti), $ol83l, 'The number of parts and checksums must match.');
        goto gnUvn;
        YaGak:
        if (chmod($BptXp, 0644)) {
            goto GJwSs;
        }
        goto PmAgS;
        PmAgS:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $BptXp);
        goto i6xZ1;
        yPLFn:
        $VcIcf = @fopen($l2vQI, 'wb');
        goto IWfqG;
        X6cZq:
        throw new Ed9MsMNQ43udu('Local chunk can not merge file (can create file): ' . $l2vQI);
        goto zUuae;
        YV2Vs:
        $pjepC = self::$Sj1TE . $JFwxi->gWCHb;
        goto jE4te;
        PP3Qq:
    }
}
