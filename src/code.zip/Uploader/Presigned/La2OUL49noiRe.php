<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\VxCHgU78wg1To;
use Jfs\Uploader\Exception\KfUscC7j3Xlno;
use Jfs\Uploader\Exception\IcOUDAYIheEwx;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Exception\XU3p5RF3SHSJj;
use Jfs\Uploader\Presigned\HHDOLLFxFHuta;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class La2OUL49noiRe implements HHDOLLFxFHuta
{
    private $vHhJT;
    private $c5PSU;
    private $RGW8z;
    private $GCETN;
    public function __construct(VxCHgU78wg1To $TUNr2, Filesystem $Ape3_, Filesystem $Dm30C, string $wiZGO)
    {
        goto SMzPt;
        znTYF:
        $this->RGW8z = $Dm30C;
        goto SCaxk;
        SCaxk:
        $this->GCETN = $wiZGO;
        goto jqgL1;
        p6bvm:
        $this->c5PSU = $Ape3_;
        goto znTYF;
        SMzPt:
        $this->vHhJT = $TUNr2;
        goto p6bvm;
        jqgL1:
    }
    public function me4pj6MGrcy()
    {
        goto j3uAz;
        F16sI:
        kMYos:
        goto I7_8I;
        NqwyH:
        if (!(0 === $szBd8->count())) {
            goto Iu_OI;
        }
        goto VFqfy;
        sX3Z7:
        $this->c5PSU->put($this->vHhJT->m0QUuINWJKg(), json_encode($this->vHhJT->muUg8to4YNh()->toArray()));
        goto D1LZD;
        HvAQt:
        $this->vHhJT->muUg8to4YNh()->mivWGZsVcDB($szBd8['UploadId']);
        goto sX3Z7;
        WxaAl:
        $Ky6oD = 1;
        goto MN_Qv;
        MN_Qv:
        JhF4u:
        goto WkGNu;
        g4_Po:
        $PaQkf = $y2JFM->createPresignedRequest($SqfT2, '+1 day');
        goto c4Fkd;
        WkGNu:
        if (!($Ky6oD <= $Qe1YG)) {
            goto qup6r;
        }
        goto a9zMk;
        U0lII:
        $szBd8 = $y2JFM->createMultipartUpload(['Bucket' => $this->GCETN, 'Key' => $this->vHhJT->getFile()->getLocation(), 'ContentType' => $this->vHhJT->muUg8to4YNh()->aRMkp, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto NqwyH;
        VFqfy:
        throw new XU3p5RF3SHSJj("Failed to create multipart upload for file {$this->vHhJT->getFile()->getFilename()}, S3 return empty response");
        goto w1nvf;
        Vr1pb:
        $Qe1YG = ceil($j1WQY->dZOy6 / $j1WQY->vG8bM);
        goto nuNS9;
        a9zMk:
        $SqfT2 = $y2JFM->getCommand('UploadPart', ['Bucket' => $this->GCETN, 'Key' => $this->vHhJT->getFile()->getLocation(), 'UploadId' => $szBd8['UploadId'], 'PartNumber' => $Ky6oD]);
        goto g4_Po;
        w1nvf:
        Iu_OI:
        goto WxaAl;
        I7_8I:
        ++$Ky6oD;
        goto pSotY;
        txyri:
        $this->vHhJT->mYxiThMveVg($Fwvpc);
        goto HvAQt;
        j3uAz:
        $j1WQY = $this->vHhJT->muUg8to4YNh();
        goto wkBFG;
        xC8NL:
        qup6r:
        goto txyri;
        pSotY:
        goto JhF4u;
        goto xC8NL;
        wkBFG:
        $Fwvpc = [];
        goto Vr1pb;
        c4Fkd:
        $Fwvpc[] = ['index' => $Ky6oD, 'url' => (string) $PaQkf->getUri()];
        goto F16sI;
        nuNS9:
        $y2JFM = $this->RGW8z->getClient();
        goto U0lII;
        D1LZD:
        $this->RGW8z->put($this->vHhJT->m0QUuINWJKg(), json_encode($this->vHhJT->muUg8to4YNh()->toArray()));
        goto YmJwW;
        YmJwW:
    }
    public function mnz8JEKyXsH() : void
    {
        goto t3DfE;
        hGujl:
        $this->RGW8z->delete($this->vHhJT->m0QUuINWJKg());
        goto It6kZ;
        NVFU4:
        try {
            $y2JFM->abortMultipartUpload(['Bucket' => $this->GCETN, 'Key' => $this->vHhJT->getFile()->getLocation(), 'UploadId' => $this->vHhJT->muUg8to4YNh()->X_FKb]);
        } catch (\Throwable $z6tFS) {
            throw new KfUscC7j3Xlno("Failed to abort multipart upload of file {$this->vHhJT->getFile()->getFilename()}", 0, $z6tFS);
        }
        goto h72Vs;
        t3DfE:
        $y2JFM = $this->RGW8z->getClient();
        goto NVFU4;
        h72Vs:
        $this->c5PSU->delete($this->vHhJT->m0QUuINWJKg());
        goto hGujl;
        It6kZ:
    }
    public function m70IYXIfVKq() : void
    {
        goto oHXlx;
        DjmzQ:
        try {
            $y2JFM->completeMultipartUpload(['Bucket' => $this->GCETN, 'Key' => $this->vHhJT->getFile()->getLocation(), 'UploadId' => $this->vHhJT->muUg8to4YNh()->X_FKb, 'MultipartUpload' => ['Parts' => collect($this->vHhJT->muUg8to4YNh()->CCl96)->sortBy('partNumber')->map(fn($pcann) => ['ETag' => $pcann['eTag'], 'PartNumber' => $pcann['partNumber']])->toArray()]]);
        } catch (\Throwable $z6tFS) {
            throw new IcOUDAYIheEwx("Failed to merge chunks of file {$this->vHhJT->getFile()->getFilename()}", 0, $z6tFS);
        }
        goto Rqur1;
        Q90Z6:
        $hIXp4 = collect($RNKEH)->keyBy('partNumber');
        goto YWuuL;
        YWuuL:
        foreach ($FDd_p as $w_Ew8) {
            goto BfM2j;
            dAP0z:
            if (!($pcann['eTag'] !== $w_Ew8['eTag'])) {
                goto wM1Ao;
            }
            goto R_oWp;
            BfM2j:
            $eiRKT = $w_Ew8['partNumber'];
            goto XnOiC;
            R_oWp:
            throw new IcOUDAYIheEwx("Checksum mismatch for part {$eiRKT} of file {$this->vHhJT->getFile()->getFilename()}");
            goto ZbQRl;
            XnOiC:
            $pcann = $hIXp4[$eiRKT];
            goto dAP0z;
            ZbQRl:
            wM1Ao:
            goto lEvU6;
            lEvU6:
            jRhyp:
            goto AwGuT;
            AwGuT:
        }
        goto t03To;
        t03To:
        f3OMq:
        goto hYD7r;
        SWbZL:
        Assert::eq(count($RNKEH), count($FDd_p), 'The number of parts and checksums must match.');
        goto Q90Z6;
        oHXlx:
        $j1WQY = $this->vHhJT->muUg8to4YNh();
        goto H7NVU;
        BOoCw:
        $FDd_p = $j1WQY->euBB1;
        goto SWbZL;
        hYD7r:
        $y2JFM = $this->RGW8z->getClient();
        goto DjmzQ;
        H7NVU:
        $RNKEH = $j1WQY->CCl96;
        goto BOoCw;
        Rqur1:
    }
}
