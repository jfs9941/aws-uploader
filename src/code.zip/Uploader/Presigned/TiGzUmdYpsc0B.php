<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DXmfT6CslVApB;
use Jfs\Uploader\Exception\DYqbeptdrawEe;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class TiGzUmdYpsc0B implements SmDKYjZTWcESe
{
    private static $Qpc2u = 'chunks/';
    private $BntnT;
    private $s0VP1;
    private $JjUJH;
    public function __construct(DXmfT6CslVApB $C2BaX, Filesystem $TuWZt, Filesystem $qg6AO)
    {
        goto MjyEp;
        MjyEp:
        $this->BntnT = $C2BaX;
        goto G5_PE;
        G5_PE:
        $this->s0VP1 = $TuWZt;
        goto a2UPt;
        a2UPt:
        $this->JjUJH = $qg6AO;
        goto eBj2H;
        eBj2H:
    }
    public function mSJwGb2dLan() : void
    {
        goto LLuug;
        LLuug:
        $b679I = $this->BntnT->m6oz0N1G29M();
        goto kX3Pa;
        pjJW1:
        ++$TUv0_;
        goto Vujia;
        LP72p:
        $gR5hY[] = ['index' => $TUv0_, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $LX_Uw, 'index' => $TUv0_])];
        goto gfHXA;
        aX1y7:
        $TUv0_ = 1;
        goto XtqG3;
        dQ5tD:
        $this->BntnT->m6oz0N1G29M()->mOkzQvX31nz($LX_Uw);
        goto aX1y7;
        lplvG:
        $this->JjUJH->put($this->BntnT->m8dpLxHLm9b(), json_encode($this->BntnT->m6oz0N1G29M()->toArray()));
        goto upYzY;
        gfHXA:
        At8t6:
        goto pjJW1;
        eYMwy:
        if (!($TUv0_ <= $Wnf_y)) {
            goto XEmcT;
        }
        goto LP72p;
        kX3Pa:
        $gR5hY = [];
        goto P8nlB;
        f1wGQ:
        $this->s0VP1->put($this->BntnT->m8dpLxHLm9b(), json_encode($this->BntnT->m6oz0N1G29M()->toArray()));
        goto lplvG;
        tfxkF:
        $LX_Uw = Uuid::v4()->toHex();
        goto dQ5tD;
        Vujia:
        goto AXY8f;
        goto RPf0u;
        XtqG3:
        AXY8f:
        goto eYMwy;
        P8nlB:
        $Wnf_y = ceil($b679I->TfMNA / $b679I->BWFP_);
        goto tfxkF;
        RPf0u:
        XEmcT:
        goto EWIBv;
        H9zvO:
        $this->BntnT->m6oz0N1G29M()->mOkzQvX31nz($LX_Uw);
        goto f1wGQ;
        EWIBv:
        $this->BntnT->mtMSkoI5tr5($gR5hY);
        goto H9zvO;
        upYzY:
    }
    public function mf6JtbCKo3e() : void
    {
        goto QdzYJ;
        QdzYJ:
        $b679I = $this->BntnT->m6oz0N1G29M();
        goto qAXzG;
        qAXzG:
        $LX_Uw = $b679I->FEcJW;
        goto Obqgf;
        Obqgf:
        $this->s0VP1->deleteDirectory(self::$Qpc2u . $LX_Uw);
        goto GNb0h;
        GNb0h:
        $this->JjUJH->delete($this->BntnT->m8dpLxHLm9b());
        goto gykn6;
        gykn6:
    }
    public function mxQijA6o4Nt() : void
    {
        goto CgUR2;
        n3FEo:
        fclose($yPxXL);
        goto qMmI4;
        WYc_9:
        tkYi9:
        goto xsZoS;
        aYU27:
        $this->s0VP1->deleteDirectory($hoewC);
        goto LrqU6;
        JoSho:
        $this->s0VP1->makeDirectory($gsh_j);
        goto WYc_9;
        g_d2r:
        $ti3Ga = $this->s0VP1->files($hoewC);
        goto fyqWW;
        cMFM8:
        $Wnf_y = $b679I->fwo9M;
        goto XfPmw;
        CgUR2:
        $b679I = $this->BntnT->m6oz0N1G29M();
        goto cMFM8;
        vt4dS:
        if ($this->s0VP1->exists($gsh_j)) {
            goto tkYi9;
        }
        goto JoSho;
        JlTI2:
        throw new \Exception('Failed to set file permissions for stored image: ' . $rcNa_);
        goto AXdef;
        Vzpkj:
        touch($wnlc6);
        goto r_ulX;
        QAmJz:
        sHXhp:
        goto R4osU;
        bQ6Ov:
        $EYJEG = $this->BntnT->getFile()->getLocation();
        goto g_d2r;
        xsZoS:
        $wnlc6 = $this->s0VP1->path($EYJEG);
        goto Vzpkj;
        cja5y:
        ZrXdx:
        goto n3FEo;
        Fp08t:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $rcNa_);
        goto JlTI2;
        FYGzb:
        if (!(false === $yPxXL)) {
            goto sHXhp;
        }
        goto i7zbq;
        AXdef:
        xwldb:
        goto aYU27;
        r_ulX:
        $yPxXL = @fopen($wnlc6, 'wb');
        goto FYGzb;
        sqtBc:
        if (chmod($rcNa_, 0644)) {
            goto xwldb;
        }
        goto Fp08t;
        fyqWW:
        Assert::eq(count($ti3Ga), $Wnf_y, 'The number of parts and checksums must match.');
        goto hppAn;
        XfPmw:
        $hoewC = self::$Qpc2u . $b679I->FEcJW;
        goto bQ6Ov;
        uTAxw:
        $gsh_j = dirname($EYJEG);
        goto vt4dS;
        i7zbq:
        throw new DYqbeptdrawEe('Local chunk can not merge file (can create file): ' . $wnlc6);
        goto QAmJz;
        qMmI4:
        $rcNa_ = $this->s0VP1->path($EYJEG);
        goto sqtBc;
        R4osU:
        foreach ($ti3Ga as $X_j6W) {
            goto IHIvd;
            OyUze:
            if (!(false === $OXfl6)) {
                goto zDrCU;
            }
            goto EyUaH;
            vj3Fl:
            zDrCU:
            goto bdUrJ;
            L06kx:
            if (!(false === $KnV0G)) {
                goto Cdoxc;
            }
            goto ZuxU9;
            ZuxU9:
            throw new DYqbeptdrawEe('A chunk file content can not copy: ' . $d6PCK);
            goto QmL29;
            DSLzF:
            fclose($OXfl6);
            goto L06kx;
            QmL29:
            Cdoxc:
            goto kgpeK;
            IHIvd:
            $d6PCK = $this->s0VP1->path($X_j6W);
            goto x0c7B;
            x0c7B:
            $OXfl6 = @fopen($d6PCK, 'rb');
            goto OyUze;
            bdUrJ:
            $KnV0G = stream_copy_to_stream($OXfl6, $yPxXL);
            goto DSLzF;
            kgpeK:
            eBxUB:
            goto lZ817;
            EyUaH:
            throw new DYqbeptdrawEe('A chunk file not existed: ' . $d6PCK);
            goto vj3Fl;
            lZ817:
        }
        goto cja5y;
        hppAn:
        natsort($ti3Ga);
        goto uTAxw;
        LrqU6:
    }
}
