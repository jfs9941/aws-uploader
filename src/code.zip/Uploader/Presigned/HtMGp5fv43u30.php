<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\S3bwZBI8SlQQZ;
use Jfs\Uploader\Exception\JMVG92vUsx277;
use Jfs\Uploader\Exception\M3YuEfc3kK1YW;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Exception\QIvYC7CBuFymv;
use Jfs\Uploader\Presigned\JlkAnpr9pgOn4;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class HtMGp5fv43u30 implements JlkAnpr9pgOn4
{
    private $xcd12;
    private $hhcR1;
    private $GkraP;
    private $VtRCr;
    public function __construct(S3bwZBI8SlQQZ $GNrIm, Filesystem $nQYui, Filesystem $jkGKh, string $G2CsF)
    {
        goto RcDsn;
        jfASq:
        $this->hhcR1 = $nQYui;
        goto uvW2m;
        hTmWJ:
        $this->VtRCr = $G2CsF;
        goto LOo27;
        uvW2m:
        $this->GkraP = $jkGKh;
        goto hTmWJ;
        RcDsn:
        $this->xcd12 = $GNrIm;
        goto jfASq;
        LOo27:
    }
    public function mcbEWNLqf0J()
    {
        goto u_FRr;
        KD8QY:
        $this->xcd12->mAorhKFxc5x()->mRlC7I4fyfy($TXgv0['UploadId']);
        goto DYSn9;
        ocKUQ:
        $c9xTh = $haBzI->getCommand('UploadPart', ['Bucket' => $this->VtRCr, 'Key' => $this->xcd12->getFile()->getLocation(), 'UploadId' => $TXgv0['UploadId'], 'PartNumber' => $ibpeb]);
        goto z8C18;
        vpNdS:
        throw new QIvYC7CBuFymv("Failed to create multipart upload for file {$this->xcd12->getFile()->getFilename()}, S3 return empty response");
        goto AxZDi;
        DKjmJ:
        RIUHk:
        goto psM5V;
        v8VLg:
        Gg_C1:
        goto F5VgI;
        nsztC:
        $i5tAd = ceil($apROX->BeHax / $apROX->qTTdh);
        goto BZXgv;
        djWuj:
        $Fa_MX = [];
        goto nsztC;
        XjBsv:
        $this->GkraP->put($this->xcd12->mwo8AmZgP7W(), json_encode($this->xcd12->mAorhKFxc5x()->toArray()));
        goto VPIVu;
        BZXgv:
        $haBzI = $this->GkraP->getClient();
        goto OIgCj;
        WgSPU:
        goto Gg_C1;
        goto DKjmJ;
        u_FRr:
        $apROX = $this->xcd12->mAorhKFxc5x();
        goto djWuj;
        Sf0BR:
        $Fa_MX[] = ['index' => $ibpeb, 'url' => (string) $DmCz8->getUri()];
        goto cHmev;
        AxZDi:
        YAIlQ:
        goto A5kqr;
        OIgCj:
        $TXgv0 = $haBzI->createMultipartUpload(['Bucket' => $this->VtRCr, 'Key' => $this->xcd12->getFile()->getLocation(), 'ContentType' => $this->xcd12->mAorhKFxc5x()->UrdNi, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto r0gM0;
        F5VgI:
        if (!($ibpeb <= $i5tAd)) {
            goto RIUHk;
        }
        goto ocKUQ;
        A5kqr:
        $ibpeb = 1;
        goto v8VLg;
        z8C18:
        $DmCz8 = $haBzI->createPresignedRequest($c9xTh, '+1 day');
        goto Sf0BR;
        r0gM0:
        if (!(0 === $TXgv0->count())) {
            goto YAIlQ;
        }
        goto vpNdS;
        XyzpP:
        ++$ibpeb;
        goto WgSPU;
        DYSn9:
        $this->hhcR1->put($this->xcd12->mwo8AmZgP7W(), json_encode($this->xcd12->mAorhKFxc5x()->toArray()));
        goto XjBsv;
        psM5V:
        $this->xcd12->mzghmmo0YQO($Fa_MX);
        goto KD8QY;
        cHmev:
        aiqrH:
        goto XyzpP;
        VPIVu:
    }
    public function mGQrr1bb2uz() : void
    {
        goto CrGi0;
        kduyt:
        $this->GkraP->delete($this->xcd12->mwo8AmZgP7W());
        goto FzgVB;
        CrGi0:
        $haBzI = $this->GkraP->getClient();
        goto HjwFO;
        uwXWP:
        $this->hhcR1->delete($this->xcd12->mwo8AmZgP7W());
        goto kduyt;
        HjwFO:
        try {
            $haBzI->abortMultipartUpload(['Bucket' => $this->VtRCr, 'Key' => $this->xcd12->getFile()->getLocation(), 'UploadId' => $this->xcd12->mAorhKFxc5x()->qzKnH]);
        } catch (\Throwable $tfcsO) {
            throw new JMVG92vUsx277("Failed to abort multipart upload of file {$this->xcd12->getFile()->getFilename()}", 0, $tfcsO);
        }
        goto uwXWP;
        FzgVB:
    }
    public function mExpa4HytOM() : void
    {
        goto HgcwF;
        scFGi:
        foreach ($WHPAZ as $NHpPn) {
            goto odNoj;
            hpeP1:
            ylVRH:
            goto x8YKC;
            odNoj:
            $Qp91V = $NHpPn['partNumber'];
            goto EMydN;
            x8YKC:
            frhkv:
            goto kiQIc;
            WYEo0:
            if (!($m5b7q['eTag'] !== $NHpPn['eTag'])) {
                goto ylVRH;
            }
            goto hIFtz;
            EMydN:
            $m5b7q = $DpCwI[$Qp91V];
            goto WYEo0;
            hIFtz:
            throw new M3YuEfc3kK1YW("Checksum mismatch for part {$Qp91V} of file {$this->xcd12->getFile()->getFilename()}");
            goto hpeP1;
            kiQIc:
        }
        goto IBKg4;
        HgcwF:
        $apROX = $this->xcd12->mAorhKFxc5x();
        goto dtje3;
        IBKg4:
        VXEvd:
        goto DMKid;
        dtje3:
        $DvSBV = $apROX->Fv1Hq;
        goto ZW10J;
        ZW10J:
        $WHPAZ = $apROX->BAFaU;
        goto W2H1i;
        W2H1i:
        Assert::eq(count($DvSBV), count($WHPAZ), 'The number of parts and checksums must match.');
        goto qwyXu;
        DMKid:
        $haBzI = $this->GkraP->getClient();
        goto cNzBw;
        qwyXu:
        $DpCwI = collect($DvSBV)->keyBy('partNumber');
        goto scFGi;
        cNzBw:
        try {
            $haBzI->completeMultipartUpload(['Bucket' => $this->VtRCr, 'Key' => $this->xcd12->getFile()->getLocation(), 'UploadId' => $this->xcd12->mAorhKFxc5x()->qzKnH, 'MultipartUpload' => ['Parts' => collect($this->xcd12->mAorhKFxc5x()->Fv1Hq)->sortBy('partNumber')->map(fn($m5b7q) => ['ETag' => $m5b7q['eTag'], 'PartNumber' => $m5b7q['partNumber']])->toArray()]]);
        } catch (\Throwable $tfcsO) {
            throw new M3YuEfc3kK1YW("Failed to merge chunks of file {$this->xcd12->getFile()->getFilename()}", 0, $tfcsO);
        }
        goto sBush;
        sBush:
    }
}
