<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZOwA486ueqbmD;
use Jfs\Uploader\Exception\ZbljA5z87yooD;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Kyp1AV9oloHFc implements M9yUJFukHJtOF
{
    private static $OgjEs = 'chunks/';
    private $alOL8;
    private $Hf14x;
    private $tYBKb;
    public function __construct(ZOwA486ueqbmD $X40HK, Filesystem $p1fCH, Filesystem $zCXkD)
    {
        goto ygK5q;
        TNowr:
        $this->Hf14x = $p1fCH;
        goto U_9If;
        ygK5q:
        $this->alOL8 = $X40HK;
        goto TNowr;
        U_9If:
        $this->tYBKb = $zCXkD;
        goto aHq7y;
        aHq7y:
    }
    public function mXz4toFge7Q() : void
    {
        goto dgHVx;
        V9sYh:
        Za3Cz:
        goto C8oFp;
        C0DdT:
        $vypSG = 1;
        goto Yrkk0;
        YeZP0:
        Nr137:
        goto ROuPn;
        ROuPn:
        ++$vypSG;
        goto AQ9lU;
        yx0Fs:
        $y_u0V = Uuid::v4()->toHex();
        goto U1gJU;
        U1gJU:
        $this->alOL8->mFmRtrLmgsB()->m4dvFVAPIAN($y_u0V);
        goto C0DdT;
        Ssiot:
        $this->alOL8->mFmRtrLmgsB()->m4dvFVAPIAN($y_u0V);
        goto lEKh7;
        dgHVx:
        $Cva33 = $this->alOL8->mFmRtrLmgsB();
        goto lc4f3;
        AQ9lU:
        goto sSgof;
        goto V9sYh;
        oFjJT:
        $this->tYBKb->put($this->alOL8->mqnDxf54UN2(), json_encode($this->alOL8->mFmRtrLmgsB()->toArray()));
        goto le2In;
        lEKh7:
        $this->Hf14x->put($this->alOL8->mqnDxf54UN2(), json_encode($this->alOL8->mFmRtrLmgsB()->toArray()));
        goto oFjJT;
        WSvWu:
        $yW3Og = ceil($Cva33->hYBql / $Cva33->ditJT);
        goto yx0Fs;
        lc4f3:
        $RYFrs = [];
        goto WSvWu;
        C8oFp:
        $this->alOL8->msb2M0BFxEn($RYFrs);
        goto Ssiot;
        eEQmh:
        $RYFrs[] = ['index' => $vypSG, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $y_u0V, 'index' => $vypSG])];
        goto YeZP0;
        ijRhZ:
        if (!($vypSG <= $yW3Og)) {
            goto Za3Cz;
        }
        goto eEQmh;
        Yrkk0:
        sSgof:
        goto ijRhZ;
        le2In:
    }
    public function maQSjrd7n8J() : void
    {
        goto rmpJq;
        n9_ux:
        $y_u0V = $Cva33->cgWhy;
        goto tASWf;
        tASWf:
        $this->Hf14x->deleteDirectory(self::$OgjEs . $y_u0V);
        goto GiqOj;
        rmpJq:
        $Cva33 = $this->alOL8->mFmRtrLmgsB();
        goto n9_ux;
        GiqOj:
        $this->tYBKb->delete($this->alOL8->mqnDxf54UN2());
        goto DNPKk;
        DNPKk:
    }
    public function mpI4EE9RWUf() : void
    {
        goto fD7T5;
        Lj2ub:
        $yW3Og = $Cva33->e1fBk;
        goto YdEGb;
        n_nTN:
        if ($this->Hf14x->exists($n_1PZ)) {
            goto MSsWk;
        }
        goto LWdtW;
        seJ6E:
        $Yeq2J = $this->Hf14x->files($ny0Bx);
        goto uPEuQ;
        k5dgh:
        $this->Hf14x->deleteDirectory($ny0Bx);
        goto TQLA8;
        y_Daq:
        MSsWk:
        goto QVOED;
        punBE:
        natsort($Yeq2J);
        goto fx9JP;
        Ej8tP:
        fclose($RbMB6);
        goto ltw8U;
        mP6w3:
        yPLyI:
        goto Ej8tP;
        FRo2J:
        Rlp30:
        goto ye4Zg;
        JZ1dD:
        throw new ZbljA5z87yooD('Local chunk can not merge file (can create file): ' . $GVlp9);
        goto FRo2J;
        wXcYL:
        h8Vxl:
        goto k5dgh;
        BYaW1:
        $n_uy4 = $this->alOL8->getFile()->getLocation();
        goto seJ6E;
        hYIzG:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $BtC3D);
        goto ZGjkG;
        QVOED:
        $GVlp9 = $this->Hf14x->path($n_uy4);
        goto sVvN1;
        ZGjkG:
        throw new \Exception('Failed to set file permissions for stored image: ' . $BtC3D);
        goto wXcYL;
        gzyqD:
        if (chmod($BtC3D, 0644)) {
            goto h8Vxl;
        }
        goto hYIzG;
        ye4Zg:
        foreach ($Yeq2J as $XYs_n) {
            goto TCVuX;
            zn0k0:
            $D6LlX = stream_copy_to_stream($gi9h3, $RbMB6);
            goto xxKWu;
            K47Cu:
            throw new ZbljA5z87yooD('A chunk file not existed: ' . $u8f9U);
            goto W9tYa;
            W9tYa:
            zoSRZ:
            goto zn0k0;
            U1HHx:
            throw new ZbljA5z87yooD('A chunk file content can not copy: ' . $u8f9U);
            goto K7t0P;
            IrB5G:
            $gi9h3 = @fopen($u8f9U, 'rb');
            goto sGVE0;
            TCVuX:
            $u8f9U = $this->Hf14x->path($XYs_n);
            goto IrB5G;
            Hy4w7:
            fRmih:
            goto CXL2W;
            K7t0P:
            I5vMD:
            goto Hy4w7;
            xxKWu:
            fclose($gi9h3);
            goto vMUVD;
            vMUVD:
            if (!(false === $D6LlX)) {
                goto I5vMD;
            }
            goto U1HHx;
            sGVE0:
            if (!(false === $gi9h3)) {
                goto zoSRZ;
            }
            goto K47Cu;
            CXL2W:
        }
        goto mP6w3;
        qTCFX:
        $RbMB6 = @fopen($GVlp9, 'wb');
        goto UGrve;
        LWdtW:
        $this->Hf14x->makeDirectory($n_1PZ);
        goto y_Daq;
        ltw8U:
        $BtC3D = $this->Hf14x->path($n_uy4);
        goto gzyqD;
        fD7T5:
        $Cva33 = $this->alOL8->mFmRtrLmgsB();
        goto Lj2ub;
        sVvN1:
        touch($GVlp9);
        goto qTCFX;
        fx9JP:
        $n_1PZ = dirname($n_uy4);
        goto n_nTN;
        uPEuQ:
        Assert::eq(count($Yeq2J), $yW3Og, 'The number of parts and checksums must match.');
        goto punBE;
        YdEGb:
        $ny0Bx = self::$OgjEs . $Cva33->cgWhy;
        goto BYaW1;
        UGrve:
        if (!(false === $RbMB6)) {
            goto Rlp30;
        }
        goto JZ1dD;
        TQLA8:
    }
}
