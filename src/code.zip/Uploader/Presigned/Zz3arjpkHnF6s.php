<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\TmESz0lUHO033;
use Jfs\Uploader\Exception\Ia53NE5vmyg2u;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Presigned\YkB5tLk814qJP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class Zz3arjpkHnF6s implements YkB5tLk814qJP
{
    private static $EPPA8 = 'chunks/';
    private $VqTjZ;
    private $hYphi;
    private $DtvHw;
    public function __construct(TmESz0lUHO033 $X318G, Filesystem $zuNM5, Filesystem $S3rMg)
    {
        goto FE7YQ;
        Dzvwn:
        $this->hYphi = $zuNM5;
        goto AsaaU;
        FE7YQ:
        $this->VqTjZ = $X318G;
        goto Dzvwn;
        AsaaU:
        $this->DtvHw = $S3rMg;
        goto CyMCF;
        CyMCF:
    }
    public function m0jynmDLk8d() : void
    {
        goto YaA4Y;
        NcbHE:
        $F77Xa = [];
        goto aQvXG;
        q01SI:
        Y4ytQ:
        goto myp6O;
        xOVZV:
        $UoeVh = route('upload.api.local_chunk.upload', ['uploadId' => $RsQzi, 'index' => $dwIiF]);
        goto Ca5_7;
        myp6O:
        ++$dwIiF;
        goto Y6Gxa;
        F9t5a:
        $this->DtvHw->put($this->VqTjZ->mLypJLcFD97(), json_encode($this->VqTjZ->miyJ5feZwpY()->toArray()));
        goto hCr_4;
        ozK2T:
        $zVmty = 'https://' . $b0PlV . '/' . ltrim($D4enG, '/');
        goto S3c3x;
        YaA4Y:
        $p3JMC = $this->VqTjZ->miyJ5feZwpY();
        goto NcbHE;
        YrFhP:
        $dwIiF = 1;
        goto g_82s;
        ROmUN:
        $RsQzi = $p3JMC->filename;
        goto IkpEc;
        Y6Gxa:
        goto U3V74;
        goto bwIXB;
        aQvXG:
        $eZtxX = ceil($p3JMC->ovxJB / $p3JMC->O_GCc);
        goto ROmUN;
        Ca5_7:
        $D4enG = parse_url($UoeVh, PHP_URL_PATH);
        goto c0Ith;
        g_82s:
        U3V74:
        goto HOUXc;
        S3c3x:
        $F77Xa[] = ['index' => $dwIiF, 'url' => $zVmty];
        goto q01SI;
        IkpEc:
        $this->VqTjZ->miyJ5feZwpY()->muRlIJMM2ro($RsQzi);
        goto YrFhP;
        c7fwN:
        $this->hYphi->put($this->VqTjZ->mLypJLcFD97(), json_encode($this->VqTjZ->miyJ5feZwpY()->toArray()));
        goto F9t5a;
        UKO33:
        $this->VqTjZ->miyJ5feZwpY()->muRlIJMM2ro($RsQzi);
        goto c7fwN;
        c8ZOZ:
        $this->VqTjZ->mHScPCLoHCA($F77Xa);
        goto UKO33;
        c0Ith:
        $b0PlV = parse_url($UoeVh, PHP_URL_HOST);
        goto ozK2T;
        HOUXc:
        if (!($dwIiF <= $eZtxX)) {
            goto nnJYY;
        }
        goto xOVZV;
        bwIXB:
        nnJYY:
        goto c8ZOZ;
        hCr_4:
    }
    public function mcNt6cVVB0k() : void
    {
        goto Q_Woa;
        tMk2z:
        $this->DtvHw->delete($this->VqTjZ->mLypJLcFD97());
        goto o8NxH;
        V47Vf:
        $this->hYphi->deleteDirectory(self::$EPPA8 . $RsQzi);
        goto tMk2z;
        sn3im:
        $RsQzi = $p3JMC->UUwpG;
        goto V47Vf;
        Q_Woa:
        $p3JMC = $this->VqTjZ->miyJ5feZwpY();
        goto sn3im;
        o8NxH:
    }
    public function mPJeP3847zn() : void
    {
        goto TmFwY;
        Y02Lo:
        $this->hYphi->deleteDirectory($VYe_J);
        goto NDowW;
        cDhQY:
        fclose($WRo3f);
        goto vO6wN;
        zLcGP:
        M0CxG:
        goto NzlZw;
        wTJu3:
        $VYe_J = self::$EPPA8 . $p3JMC->UUwpG;
        goto scNCP;
        qNpc_:
        Z1sM4:
        goto Y02Lo;
        ttbjy:
        $WRo3f = @fopen($QY8bh, 'wb');
        goto WgDVm;
        kvdiV:
        eRKon:
        goto cDhQY;
        BYEAV:
        $yFlqi = $this->hYphi->files($VYe_J);
        goto fI0iP;
        O7sgv:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $VLxDj);
        goto xayJV;
        fYLGk:
        throw new Ia53NE5vmyg2u('Local chunk can not merge file (can create file): ' . $QY8bh);
        goto Z_wyD;
        vO6wN:
        $VLxDj = $this->hYphi->path($TQaoc);
        goto DAKrR;
        WgDVm:
        if (!(false === $WRo3f)) {
            goto bRK3q;
        }
        goto fYLGk;
        scNCP:
        $TQaoc = $this->VqTjZ->getFile()->getLocation();
        goto BYEAV;
        NzlZw:
        $QY8bh = $this->hYphi->path($TQaoc);
        goto gXh_U;
        G2Mkm:
        foreach ($yFlqi as $JEHRz) {
            goto NxZV7;
            CAU9w:
            $USRIE = @fopen($P_TuW, 'rb');
            goto bqRYE;
            NxZV7:
            $P_TuW = $this->hYphi->path($JEHRz);
            goto CAU9w;
            uSXZp:
            DJsPf:
            goto KHAEZ;
            wYDCI:
            throw new Ia53NE5vmyg2u('A chunk file not existed: ' . $P_TuW);
            goto epdO1;
            sbN3_:
            $xaWN8 = stream_copy_to_stream($USRIE, $WRo3f);
            goto AtIOh;
            yEEm2:
            throw new Ia53NE5vmyg2u('A chunk file content can not copy: ' . $P_TuW);
            goto uOrpl;
            G5F_1:
            if (!(false === $xaWN8)) {
                goto mfSp1;
            }
            goto yEEm2;
            bqRYE:
            if (!(false === $USRIE)) {
                goto najcC;
            }
            goto wYDCI;
            uOrpl:
            mfSp1:
            goto uSXZp;
            epdO1:
            najcC:
            goto sbN3_;
            AtIOh:
            fclose($USRIE);
            goto G5F_1;
            KHAEZ:
        }
        goto kvdiV;
        DAKrR:
        if (chmod($VLxDj, 0644)) {
            goto Z1sM4;
        }
        goto O7sgv;
        TmFwY:
        $p3JMC = $this->VqTjZ->miyJ5feZwpY();
        goto GKRTq;
        B26xc:
        natsort($yFlqi);
        goto le00H;
        gXh_U:
        touch($QY8bh);
        goto ttbjy;
        KTYnZ:
        if ($this->hYphi->exists($uKsaJ)) {
            goto M0CxG;
        }
        goto Clx_2;
        GKRTq:
        $eZtxX = $p3JMC->fGqNh;
        goto wTJu3;
        Clx_2:
        $this->hYphi->makeDirectory($uKsaJ);
        goto zLcGP;
        le00H:
        $uKsaJ = dirname($TQaoc);
        goto KTYnZ;
        xayJV:
        throw new \Exception('Failed to set file permissions for stored image: ' . $VLxDj);
        goto qNpc_;
        fI0iP:
        Assert::eq(count($yFlqi), $eZtxX, 'The number of parts and checksums must match.');
        goto B26xc;
        Z_wyD:
        bRK3q:
        goto G2Mkm;
        NDowW:
    }
}
