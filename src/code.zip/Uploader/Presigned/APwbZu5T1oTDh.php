<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\JNVd14WbS7J31;
use Jfs\Uploader\Exception\G23CmOAeiHqkm;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Presigned\QBfShGMnlw2Jt;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class APwbZu5T1oTDh implements QBfShGMnlw2Jt
{
    private static $Mwnqh = 'chunks/';
    private $Ph2Bh;
    private $IdG3S;
    private $m1Mjp;
    public function __construct(JNVd14WbS7J31 $G3hwE, Filesystem $ftmEm, Filesystem $ZIdyH)
    {
        goto EjmGL;
        EjmGL:
        $this->Ph2Bh = $G3hwE;
        goto irHsm;
        S5yYf:
        $this->m1Mjp = $ZIdyH;
        goto glfHr;
        irHsm:
        $this->IdG3S = $ftmEm;
        goto S5yYf;
        glfHr:
    }
    public function mX63RYpwJf8() : void
    {
        goto F5Ad2;
        QrsCM:
        $Sw6uL = [];
        goto va68O;
        Vj26v:
        goto uje3N;
        goto yky29;
        kgFDl:
        $this->IdG3S->put($this->Ph2Bh->mmNRlgopoZ5(), json_encode($this->Ph2Bh->m8Hi8VWicy3()->toArray()));
        goto oIfQJ;
        yU36_:
        $liQkG = parse_url($GKxAm, PHP_URL_PATH);
        goto iCaFT;
        oIfQJ:
        $this->m1Mjp->put($this->Ph2Bh->mmNRlgopoZ5(), json_encode($this->Ph2Bh->m8Hi8VWicy3()->toArray()));
        goto Y1Kvw;
        va68O:
        $IftTu = ceil($W8N2W->BjjEq / $W8N2W->Z119c);
        goto g5sIi;
        fEZbn:
        if (!($tOIWk <= $IftTu)) {
            goto VOIrb;
        }
        goto Eafp6;
        J441u:
        uje3N:
        goto fEZbn;
        g5sIi:
        $tNwGR = $W8N2W->filename;
        goto t0l9o;
        iCaFT:
        $F_4QC = parse_url($GKxAm, PHP_URL_HOST);
        goto ShhLr;
        ukjgQ:
        $Sw6uL[] = ['index' => $tOIWk, 'url' => $xJXJu];
        goto BcobJ;
        Eggd1:
        ++$tOIWk;
        goto Vj26v;
        ShhLr:
        $xJXJu = 'https://' . $F_4QC . '/' . ltrim($liQkG, '/');
        goto ukjgQ;
        lS5Lp:
        $tOIWk = 1;
        goto J441u;
        t0l9o:
        $this->Ph2Bh->m8Hi8VWicy3()->mWwcN6VbLRG($tNwGR);
        goto lS5Lp;
        iKyaw:
        $this->Ph2Bh->m8Hi8VWicy3()->mWwcN6VbLRG($tNwGR);
        goto kgFDl;
        F5Ad2:
        $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
        goto QrsCM;
        Eafp6:
        $GKxAm = route('upload.api.local_chunk.upload', ['uploadId' => $tNwGR, 'index' => $tOIWk]);
        goto yU36_;
        BcobJ:
        MJVst:
        goto Eggd1;
        yky29:
        VOIrb:
        goto usAdx;
        usAdx:
        $this->Ph2Bh->mdcD4JdtpGn($Sw6uL);
        goto iKyaw;
        Y1Kvw:
    }
    public function mDAg6JsqB6v() : void
    {
        goto WeMOp;
        WeMOp:
        $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
        goto ODVxB;
        GfJUz:
        $this->m1Mjp->delete($this->Ph2Bh->mmNRlgopoZ5());
        goto NiBcm;
        ODVxB:
        $tNwGR = $W8N2W->MSlst;
        goto YgVn9;
        YgVn9:
        $this->IdG3S->deleteDirectory(self::$Mwnqh . $tNwGR);
        goto GfJUz;
        NiBcm:
    }
    public function mNBOH0CMzl3() : void
    {
        goto SshFa;
        VaYUK:
        $SPhyb = $this->IdG3S->files($A_cUC);
        goto rzDH3;
        pcYRN:
        if (!(false === $iHXfr)) {
            goto FpmLv;
        }
        goto I16Ou;
        gvNb9:
        $this->IdG3S->deleteDirectory($A_cUC);
        goto ghH0h;
        I16Ou:
        throw new G23CmOAeiHqkm('Local chunk can not merge file (can create file): ' . $YAvBx);
        goto cniNg;
        gIIYY:
        $bvvVP = $this->Ph2Bh->getFile()->getLocation();
        goto VaYUK;
        IiREr:
        throw new \Exception('Failed to set file permissions for stored image: ' . $jkd6M);
        goto sUhBf;
        poUGb:
        fclose($iHXfr);
        goto QpXWm;
        ihKaV:
        $iHXfr = @fopen($YAvBx, 'wb');
        goto pcYRN;
        PsPy2:
        if ($this->IdG3S->exists($vr1rt)) {
            goto aIgC0;
        }
        goto HZB8e;
        HuqrI:
        if (chmod($jkd6M, 0644)) {
            goto D0uqK;
        }
        goto FuD4u;
        HZB8e:
        $this->IdG3S->makeDirectory($vr1rt);
        goto H3vs2;
        dx20H:
        $A_cUC = self::$Mwnqh . $W8N2W->MSlst;
        goto gIIYY;
        SshFa:
        $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
        goto qsgXr;
        aMAyQ:
        EAehc:
        goto poUGb;
        cniNg:
        FpmLv:
        goto tz2PX;
        oDCiL:
        $vr1rt = dirname($bvvVP);
        goto PsPy2;
        qsgXr:
        $IftTu = $W8N2W->oKsce;
        goto dx20H;
        mo3JS:
        touch($YAvBx);
        goto ihKaV;
        Qh5Fa:
        natsort($SPhyb);
        goto oDCiL;
        FuD4u:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $jkd6M);
        goto IiREr;
        tz2PX:
        foreach ($SPhyb as $RDhwy) {
            goto wBLzN;
            XxZMP:
            $DZsIa = @fopen($ttL3a, 'rb');
            goto rpcrA;
            S91ue:
            throw new G23CmOAeiHqkm('A chunk file content can not copy: ' . $ttL3a);
            goto HzY0t;
            YcPij:
            throw new G23CmOAeiHqkm('A chunk file not existed: ' . $ttL3a);
            goto Yt33_;
            HzY0t:
            h72ow:
            goto YhGDB;
            NejHk:
            fclose($DZsIa);
            goto tGxTY;
            XOW3l:
            $ER9hq = stream_copy_to_stream($DZsIa, $iHXfr);
            goto NejHk;
            tGxTY:
            if (!(false === $ER9hq)) {
                goto h72ow;
            }
            goto S91ue;
            wBLzN:
            $ttL3a = $this->IdG3S->path($RDhwy);
            goto XxZMP;
            YhGDB:
            adQzG:
            goto yerj7;
            rpcrA:
            if (!(false === $DZsIa)) {
                goto eewPq;
            }
            goto YcPij;
            Yt33_:
            eewPq:
            goto XOW3l;
            yerj7:
        }
        goto aMAyQ;
        rzDH3:
        Assert::eq(count($SPhyb), $IftTu, 'The number of parts and checksums must match.');
        goto Qh5Fa;
        H3vs2:
        aIgC0:
        goto auRf4;
        QpXWm:
        $jkd6M = $this->IdG3S->path($bvvVP);
        goto HuqrI;
        auRf4:
        $YAvBx = $this->IdG3S->path($bvvVP);
        goto mo3JS;
        sUhBf:
        D0uqK:
        goto gvNb9;
        ghH0h:
    }
}
