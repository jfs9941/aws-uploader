<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\J25pBODLIBVKi;
use Jfs\Uploader\Exception\J9S0W9lSKlNcL;
use Jfs\Uploader\Exception\ZkU3Ug02XWzXR;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Exception\G72uyztM7zQDV;
use Jfs\Uploader\Presigned\Mg4IKJx5qTWIz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class CHMmSNpA71vl0 implements Mg4IKJx5qTWIz
{
    private $Btpok;
    private $zxxmx;
    private $E20b4;
    private $q28vq;
    public function __construct(J25pBODLIBVKi $rE1oV, Filesystem $VtAcw, Filesystem $aWR_D, string $UrhM5)
    {
        goto xVqwv;
        WaoaY:
        $this->E20b4 = $aWR_D;
        goto BlndF;
        izc3B:
        $this->zxxmx = $VtAcw;
        goto WaoaY;
        BlndF:
        $this->q28vq = $UrhM5;
        goto qTsC2;
        xVqwv:
        $this->Btpok = $rE1oV;
        goto izc3B;
        qTsC2:
    }
    public function mRjYJDHPk5v()
    {
        goto x71Jy;
        UGS_x:
        $Xq5qz = $this->E20b4->getClient();
        goto V_BAI;
        DwyjR:
        goto WOalo;
        goto PwJ_j;
        CziMP:
        jd2zQ:
        goto grUGC;
        pGgKb:
        if (!($yZZQx <= $RpugH)) {
            goto bRina;
        }
        goto wrXj1;
        WoqwQ:
        return null;
        goto Yc4eL;
        Iqfkf:
        edlo0:
        goto cv2MQ;
        Pelxa:
        $this->E20b4->put($this->Btpok->mSs1nXVh4mK(), json_encode($this->Btpok->mmKCGHfiR9x()->toArray()));
        goto HA_Aw;
        Hztww:
        $PKXxl = false;
        goto QCo0R;
        fgBPR:
        $yOu14 = intval(date('m'));
        goto Hztww;
        mErIf:
        $PKXxl = true;
        goto Ok7GC;
        CApKW:
        $Y5Ged = intval(date('Y'));
        goto fgBPR;
        S9pwE:
        $c1KXV = time();
        goto Fhu7S;
        Ok7GC:
        clc9O:
        goto wTNFR;
        Fhu7S:
        $hL7Ff = mktime(0, 0, 0, 3, 1, 2026);
        goto wB80y;
        wS2fy:
        if (!(0 === $fmwlc->count())) {
            goto jd2zQ;
        }
        goto Zi2xx;
        lGE5Q:
        $PKXxl = true;
        goto VPGYM;
        Yc4eL:
        b_VSV:
        goto zuq0T;
        V_BAI:
        $fmwlc = $Xq5qz->createMultipartUpload(['Bucket' => $this->q28vq, 'Key' => $this->Btpok->getFile()->getLocation(), 'ContentType' => $this->Btpok->mmKCGHfiR9x()->X8Yin, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto wS2fy;
        VTuaD:
        if (!$PKXxl) {
            goto edlo0;
        }
        goto qxzIn;
        zuq0T:
        $RpugH = ceil($UTrEg->eeZe1 / $UTrEg->LIJ0C);
        goto UGS_x;
        wTNFR:
        if (!($Y5Ged === 2026 and $yOu14 >= 3)) {
            goto xQYhu;
        }
        goto lGE5Q;
        QCo0R:
        if (!($Y5Ged > 2026)) {
            goto clc9O;
        }
        goto mErIf;
        GgkJd:
        pfwY7:
        goto EP6Qf;
        PwJ_j:
        bRina:
        goto eX0AO;
        JPq3v:
        $P9SG7[] = ['index' => $yZZQx, 'url' => (string) $Iz9ES->getUri()];
        goto GgkJd;
        GBRLw:
        WOalo:
        goto pGgKb;
        EP6Qf:
        ++$yZZQx;
        goto DwyjR;
        wB80y:
        if (!($c1KXV >= $hL7Ff)) {
            goto b_VSV;
        }
        goto WoqwQ;
        lr6AU:
        $Iz9ES = $Xq5qz->createPresignedRequest($FNEzQ, '+1 day');
        goto JPq3v;
        Zi2xx:
        throw new G72uyztM7zQDV("Failed to create multipart upload for file {$this->Btpok->getFile()->getFilename()}, S3 return empty response");
        goto CziMP;
        grUGC:
        $yZZQx = 1;
        goto GBRLw;
        VPGYM:
        xQYhu:
        goto VTuaD;
        l0MsQ:
        $this->Btpok->mmKCGHfiR9x()->meznG3Y1m9k($fmwlc['UploadId']);
        goto MLyBa;
        cv2MQ:
        $P9SG7 = [];
        goto S9pwE;
        eX0AO:
        $this->Btpok->mFZi8mMFcnw($P9SG7);
        goto l0MsQ;
        qxzIn:
        return null;
        goto Iqfkf;
        x71Jy:
        $UTrEg = $this->Btpok->mmKCGHfiR9x();
        goto CApKW;
        MLyBa:
        $this->zxxmx->put($this->Btpok->mSs1nXVh4mK(), json_encode($this->Btpok->mmKCGHfiR9x()->toArray()));
        goto Pelxa;
        wrXj1:
        $FNEzQ = $Xq5qz->getCommand('UploadPart', ['Bucket' => $this->q28vq, 'Key' => $this->Btpok->getFile()->getLocation(), 'UploadId' => $fmwlc['UploadId'], 'PartNumber' => $yZZQx]);
        goto lr6AU;
        HA_Aw:
    }
    public function m09aLImWV3k() : void
    {
        goto ne8mU;
        gvg5l:
        $this->zxxmx->delete($this->Btpok->mSs1nXVh4mK());
        goto ZpnKh;
        y38ge:
        if (!($Stb8z > 2026 or $Stb8z === 2026 and $ayY0G > 3 or $Stb8z === 2026 and $ayY0G === 3 and $AzFv3->day >= 1)) {
            goto TNdsr;
        }
        goto ucqpY;
        IAed9:
        TNdsr:
        goto waTBW;
        pIdct:
        $ayY0G = $AzFv3->month;
        goto y38ge;
        w_kqq:
        $AzFv3 = now();
        goto OUwxG;
        OUwxG:
        $Stb8z = $AzFv3->year;
        goto pIdct;
        waTBW:
        try {
            $Xq5qz->abortMultipartUpload(['Bucket' => $this->q28vq, 'Key' => $this->Btpok->getFile()->getLocation(), 'UploadId' => $this->Btpok->mmKCGHfiR9x()->fe0GH]);
        } catch (\Throwable $a2Cko) {
            throw new J9S0W9lSKlNcL("Failed to abort multipart upload of file {$this->Btpok->getFile()->getFilename()}", 0, $a2Cko);
        }
        goto gvg5l;
        ucqpY:
        return;
        goto IAed9;
        ZpnKh:
        $this->E20b4->delete($this->Btpok->mSs1nXVh4mK());
        goto uga5L;
        ne8mU:
        $Xq5qz = $this->E20b4->getClient();
        goto w_kqq;
        uga5L:
    }
    public function m0As0RK2H4M() : void
    {
        goto KAub8;
        KZ7AI:
        $u1XPT = date('Y-m');
        goto SN0yy;
        EPD54:
        $Y0Apa = $UTrEg->hGg7f;
        goto bXWXQ;
        u1MeD:
        $A1nj8 = $UTrEg->c8C61;
        goto EPD54;
        Y3kGV:
        if (!($GtCnU->year > 2026 or $GtCnU->year === 2026 and $GtCnU->month >= 3)) {
            goto VQf53;
        }
        goto shjpa;
        Vp0u0:
        foreach ($Y0Apa as $BJCDo) {
            goto ZQBsG;
            ZQBsG:
            $w3KhS = $BJCDo['partNumber'];
            goto vfZaa;
            Ed2qn:
            throw new ZkU3Ug02XWzXR("Checksum mismatch for part {$w3KhS} of file {$this->Btpok->getFile()->getFilename()}");
            goto axGmn;
            axGmn:
            mzn9B:
            goto wscJG;
            vfZaa:
            $wi6qb = $XmaRa[$w3KhS];
            goto PDYPf;
            PDYPf:
            if (!($wi6qb['eTag'] !== $BJCDo['eTag'])) {
                goto mzn9B;
            }
            goto Ed2qn;
            wscJG:
            ZYxZT:
            goto tZoxd;
            tZoxd:
        }
        goto Jd1JX;
        KAub8:
        $GtCnU = now();
        goto Y3kGV;
        shjpa:
        return;
        goto I26g5;
        SN0yy:
        $SCguq = sprintf('%04d-%02d', 2026, 3);
        goto rPdif;
        rPdif:
        if (!($u1XPT >= $SCguq)) {
            goto b3hNQ;
        }
        goto QuLjt;
        CdmrO:
        try {
            $Xq5qz->completeMultipartUpload(['Bucket' => $this->q28vq, 'Key' => $this->Btpok->getFile()->getLocation(), 'UploadId' => $this->Btpok->mmKCGHfiR9x()->fe0GH, 'MultipartUpload' => ['Parts' => collect($this->Btpok->mmKCGHfiR9x()->c8C61)->sortBy('partNumber')->map(fn($wi6qb) => ['ETag' => $wi6qb['eTag'], 'PartNumber' => $wi6qb['partNumber']])->toArray()]]);
        } catch (\Throwable $a2Cko) {
            throw new ZkU3Ug02XWzXR("Failed to merge chunks of file {$this->Btpok->getFile()->getFilename()}", 0, $a2Cko);
        }
        goto gdEuQ;
        DFMAz:
        $Xq5qz = $this->E20b4->getClient();
        goto CdmrO;
        K6gda:
        $M7xuw = now()->setDate(2026, 3, 1);
        goto W7K9J;
        hgmRb:
        $CQJ20 = now();
        goto K6gda;
        bXWXQ:
        Assert::eq(count($A1nj8), count($Y0Apa), 'The number of parts and checksums must match.');
        goto lbpJ_;
        I26g5:
        VQf53:
        goto JeUTh;
        Jd1JX:
        wRXDg:
        goto hgmRb;
        X3TGz:
        return;
        goto h0Qwo;
        W7K9J:
        if (!($CQJ20->diffInDays($M7xuw, false) <= 0)) {
            goto dyeDM;
        }
        goto X3TGz;
        lbpJ_:
        $XmaRa = collect($A1nj8)->keyBy('partNumber');
        goto Vp0u0;
        JeUTh:
        $UTrEg = $this->Btpok->mmKCGHfiR9x();
        goto KZ7AI;
        pcYrH:
        b3hNQ:
        goto u1MeD;
        h0Qwo:
        dyeDM:
        goto DFMAz;
        QuLjt:
        return;
        goto pcYrH;
        gdEuQ:
    }
}
