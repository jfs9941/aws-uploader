<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\IQDEtKorMDqYa;
use Jfs\Uploader\Exception\VWx34J99Rmuo6;
use Jfs\Uploader\Exception\VLsw4zWL0oGJH;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Exception\VqmUQEuxdIp5w;
use Jfs\Uploader\Presigned\GIpmRlprHQXSB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class Xf65LJkoYtNWa implements GIpmRlprHQXSB
{
    private $oVe7o;
    private $iAAqk;
    private $PrHIa;
    private $gHJ_C;
    public function __construct(IQDEtKorMDqYa $r4uPF, Filesystem $YNIuu, Filesystem $NP1kd, string $iwKga)
    {
        goto rWp5T;
        VdmsH:
        $this->PrHIa = $NP1kd;
        goto NgegS;
        rWp5T:
        $this->oVe7o = $r4uPF;
        goto xhSmv;
        NgegS:
        $this->gHJ_C = $iwKga;
        goto JtOuB;
        xhSmv:
        $this->iAAqk = $YNIuu;
        goto VdmsH;
        JtOuB:
    }
    public function mMbBP7u4MD7()
    {
        goto A1yQW;
        XMD5f:
        $q2eKB = $this->PrHIa->getClient();
        goto PDw4W;
        eqd5C:
        Rxo5U:
        goto dzxV6;
        xx6Rg:
        $x6EER = $q2eKB->createPresignedRequest($PQZM2, '+1 day');
        goto O3Cft;
        Lo35W:
        fWva2:
        goto IGTMR;
        IGTMR:
        $iZJLy = 1;
        goto kVFFM;
        X3qnv:
        $PQZM2 = $q2eKB->getCommand('UploadPart', ['Bucket' => $this->gHJ_C, 'Key' => $this->oVe7o->getFile()->getLocation(), 'UploadId' => $SKvTz['UploadId'], 'PartNumber' => $iZJLy]);
        goto xx6Rg;
        WTnP4:
        $this->oVe7o->mIrarJhaP0j()->mRBZ72cnJM7($SKvTz['UploadId']);
        goto qyhiQ;
        QHNmA:
        $IIxqH = [];
        goto Gif9n;
        dzxV6:
        $this->oVe7o->mzAHhqFLnsA($IIxqH);
        goto WTnP4;
        FJBeL:
        goto zjsgo;
        goto eqd5C;
        O3Cft:
        $IIxqH[] = ['index' => $iZJLy, 'url' => (string) $x6EER->getUri()];
        goto MpIyA;
        FlCEC:
        throw new VqmUQEuxdIp5w("Failed to create multipart upload for file {$this->oVe7o->getFile()->getFilename()}, S3 return empty response");
        goto Lo35W;
        A1yQW:
        $TxsWN = $this->oVe7o->mIrarJhaP0j();
        goto QHNmA;
        WNlM1:
        $this->PrHIa->put($this->oVe7o->mwL2ScZNW65(), json_encode($this->oVe7o->mIrarJhaP0j()->toArray()));
        goto RHkQw;
        VMEAT:
        if (!(0 === $SKvTz->count())) {
            goto fWva2;
        }
        goto FlCEC;
        MpIyA:
        SARFZ:
        goto IPngs;
        Gif9n:
        $YnTza = ceil($TxsWN->taYQP / $TxsWN->w2zTJ);
        goto XMD5f;
        kVFFM:
        zjsgo:
        goto e4OdS;
        IPngs:
        ++$iZJLy;
        goto FJBeL;
        qyhiQ:
        $this->iAAqk->put($this->oVe7o->mwL2ScZNW65(), json_encode($this->oVe7o->mIrarJhaP0j()->toArray()));
        goto WNlM1;
        e4OdS:
        if (!($iZJLy <= $YnTza)) {
            goto Rxo5U;
        }
        goto X3qnv;
        PDw4W:
        $SKvTz = $q2eKB->createMultipartUpload(['Bucket' => $this->gHJ_C, 'Key' => $this->oVe7o->getFile()->getLocation(), 'ContentType' => $this->oVe7o->mIrarJhaP0j()->jjihG, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto VMEAT;
        RHkQw:
    }
    public function mdqqx89d2D7() : void
    {
        goto lax_9;
        Lurkr:
        $this->PrHIa->delete($this->oVe7o->mwL2ScZNW65());
        goto Bwbm5;
        lax_9:
        $q2eKB = $this->PrHIa->getClient();
        goto tJiMD;
        AaARS:
        $this->iAAqk->delete($this->oVe7o->mwL2ScZNW65());
        goto Lurkr;
        tJiMD:
        try {
            $q2eKB->abortMultipartUpload(['Bucket' => $this->gHJ_C, 'Key' => $this->oVe7o->getFile()->getLocation(), 'UploadId' => $this->oVe7o->mIrarJhaP0j()->LwfXc]);
        } catch (\Throwable $p7PBd) {
            throw new VWx34J99Rmuo6("Failed to abort multipart upload of file {$this->oVe7o->getFile()->getFilename()}", 0, $p7PBd);
        }
        goto AaARS;
        Bwbm5:
    }
    public function mO5xHEz50iL() : void
    {
        goto JsmCb;
        PU83d:
        $q2eKB = $this->PrHIa->getClient();
        goto cLAL2;
        vcP62:
        $a2L2v = $TxsWN->bPDIv;
        goto IaqzH;
        cLAL2:
        try {
            $q2eKB->completeMultipartUpload(['Bucket' => $this->gHJ_C, 'Key' => $this->oVe7o->getFile()->getLocation(), 'UploadId' => $this->oVe7o->mIrarJhaP0j()->LwfXc, 'MultipartUpload' => ['Parts' => collect($this->oVe7o->mIrarJhaP0j()->nRuh8)->sortBy('partNumber')->map(fn($Lxw_G) => ['ETag' => $Lxw_G['eTag'], 'PartNumber' => $Lxw_G['partNumber']])->toArray()]]);
        } catch (\Throwable $p7PBd) {
            throw new VLsw4zWL0oGJH("Failed to merge chunks of file {$this->oVe7o->getFile()->getFilename()}", 0, $p7PBd);
        }
        goto OLvak;
        X3bCz:
        $nGsMa = collect($FvGiZ)->keyBy('partNumber');
        goto IWKfA;
        IWKfA:
        foreach ($a2L2v as $rS6EW) {
            goto fKhyq;
            upClq:
            GEUj5:
            goto BxVz0;
            dsEHR:
            throw new VLsw4zWL0oGJH("Checksum mismatch for part {$Klz25} of file {$this->oVe7o->getFile()->getFilename()}");
            goto AWFtm;
            zxtl5:
            if (!($Lxw_G['eTag'] !== $rS6EW['eTag'])) {
                goto WDbVZ;
            }
            goto dsEHR;
            Mzfn_:
            $Lxw_G = $nGsMa[$Klz25];
            goto zxtl5;
            AWFtm:
            WDbVZ:
            goto upClq;
            fKhyq:
            $Klz25 = $rS6EW['partNumber'];
            goto Mzfn_;
            BxVz0:
        }
        goto X1Vls;
        IaqzH:
        Assert::eq(count($FvGiZ), count($a2L2v), 'The number of parts and checksums must match.');
        goto X3bCz;
        X1Vls:
        JcWlQ:
        goto PU83d;
        JsmCb:
        $TxsWN = $this->oVe7o->mIrarJhaP0j();
        goto KRcHv;
        KRcHv:
        $FvGiZ = $TxsWN->nRuh8;
        goto vcP62;
        OLvak:
    }
}
