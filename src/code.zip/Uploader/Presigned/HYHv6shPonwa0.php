<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\UvoAmV0bL7M3i;
use Jfs\Uploader\Exception\Ua8kIa3dqKEE8;
use Jfs\Uploader\Exception\Ycjaywk1DZxJx;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Jfs\Uploader\Exception\ESflrfOXa8JlH;
use Webmozart\Assert\Assert;
class HYHv6shPonwa0 implements FEzFAspP5QxWi
{
    private $YYkmA;
    private $aB4Qh;
    private $qFnIc;
    private $ey_Bg;
    public function __construct(UvoAmV0bL7M3i $au4Kn, Filesystem $Q0D24, Filesystem $A8Sfn, string $F66z0)
    {
        goto BNxV0;
        efZIb:
        $this->aB4Qh = $Q0D24;
        goto NNt1D;
        aEgzp:
        $this->ey_Bg = $F66z0;
        goto ybuLm;
        NNt1D:
        $this->qFnIc = $A8Sfn;
        goto aEgzp;
        BNxV0:
        $this->YYkmA = $au4Kn;
        goto efZIb;
        ybuLm:
    }
    public function mX79Bq6DhRS()
    {
        goto mk5Tg;
        F37jp:
        $rToUL = 1;
        goto J7xdn;
        VAKUv:
        $ICdB3 = $HuLvb->createPresignedRequest($J9Sh1, '+1 day');
        goto kItIW;
        WK4we:
        ++$rToUL;
        goto JacBU;
        kItIW:
        $Wdozm[] = ['index' => $rToUL, 'url' => (string) $ICdB3->getUri()];
        goto H6Kin;
        J7xdn:
        abcjO:
        goto ZAE2T;
        JacBU:
        goto abcjO;
        goto q53PJ;
        yP2xD:
        $HuLvb = $this->qFnIc->getClient();
        goto L_4gF;
        yQ6mQ:
        $Wdozm = [];
        goto kCyT4;
        mk5Tg:
        $YKW91 = $this->YYkmA->mLK5jSa9bhL();
        goto yQ6mQ;
        bgSrl:
        $this->qFnIc->put($this->YYkmA->m6bsWqEDF0y(), json_encode($this->YYkmA->mLK5jSa9bhL()->toArray()));
        goto vZqm3;
        MJUX1:
        $this->YYkmA->mkHeSFURrdO($Wdozm);
        goto FxZmN;
        FxZmN:
        $this->YYkmA->mLK5jSa9bhL()->mljAt4c4xQC($hrLIq['UploadId']);
        goto MhlI6;
        q53PJ:
        J5zpv:
        goto MJUX1;
        kCyT4:
        $APmCu = ceil($YKW91->Hj1Ds / $YKW91->pDj8N);
        goto yP2xD;
        RnT09:
        throw new ESflrfOXa8JlH("Failed to create multipart upload for file {$this->YYkmA->getFile()->getFilename()}, S3 return empty response");
        goto UsDhq;
        L_4gF:
        $hrLIq = $HuLvb->createMultipartUpload(['Bucket' => $this->ey_Bg, 'Key' => $this->YYkmA->getFile()->getLocation(), 'ContentType' => $this->YYkmA->mLK5jSa9bhL()->elwIk, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto zhxy5;
        SQmbV:
        $J9Sh1 = $HuLvb->getCommand('UploadPart', ['Bucket' => $this->ey_Bg, 'Key' => $this->YYkmA->getFile()->getLocation(), 'UploadId' => $hrLIq['UploadId'], 'PartNumber' => $rToUL]);
        goto VAKUv;
        UsDhq:
        XlnCR:
        goto F37jp;
        H6Kin:
        mvaHc:
        goto WK4we;
        MhlI6:
        $this->aB4Qh->put($this->YYkmA->m6bsWqEDF0y(), json_encode($this->YYkmA->mLK5jSa9bhL()->toArray()));
        goto bgSrl;
        ZAE2T:
        if (!($rToUL <= $APmCu)) {
            goto J5zpv;
        }
        goto SQmbV;
        zhxy5:
        if (!(0 === $hrLIq->count())) {
            goto XlnCR;
        }
        goto RnT09;
        vZqm3:
    }
    public function me69BIFTRSd() : void
    {
        goto txO6J;
        tsjcR:
        $this->qFnIc->delete($this->YYkmA->m6bsWqEDF0y());
        goto gNHZo;
        Fr6qB:
        $this->aB4Qh->delete($this->YYkmA->m6bsWqEDF0y());
        goto tsjcR;
        k2BTO:
        try {
            $HuLvb->abortMultipartUpload(['Bucket' => $this->ey_Bg, 'Key' => $this->YYkmA->getFile()->getLocation(), 'UploadId' => $this->YYkmA->mLK5jSa9bhL()->Llr3J]);
        } catch (\Throwable $nhDP5) {
            throw new Ua8kIa3dqKEE8("Failed to abort multipart upload of file {$this->YYkmA->getFile()->getFilename()}", 0, $nhDP5);
        }
        goto Fr6qB;
        txO6J:
        $HuLvb = $this->qFnIc->getClient();
        goto k2BTO;
        gNHZo:
    }
    public function mab8LR1F1c8() : void
    {
        goto ZWtst;
        WMXsa:
        $JgCdd = collect($sGu64)->keyBy('partNumber');
        goto KHopa;
        ae0DX:
        $sGu64 = $YKW91->lrez6;
        goto o1JfD;
        nCzZ2:
        try {
            $HuLvb->completeMultipartUpload(['Bucket' => $this->ey_Bg, 'Key' => $this->YYkmA->getFile()->getLocation(), 'UploadId' => $this->YYkmA->mLK5jSa9bhL()->Llr3J, 'MultipartUpload' => ['Parts' => collect($this->YYkmA->mLK5jSa9bhL()->lrez6)->sortBy('partNumber')->map(fn($GOAPR) => ['ETag' => $GOAPR['eTag'], 'PartNumber' => $GOAPR['partNumber']])->toArray()]]);
        } catch (\Throwable $nhDP5) {
            throw new Ycjaywk1DZxJx("Failed to merge chunks of file {$this->YYkmA->getFile()->getFilename()}", 0, $nhDP5);
        }
        goto dRZ9V;
        ZWtst:
        $YKW91 = $this->YYkmA->mLK5jSa9bhL();
        goto ae0DX;
        KHopa:
        foreach ($aK2El as $TwQaY) {
            goto PYdaL;
            sWKRb:
            Xs1ZG:
            goto YR1Sl;
            vBBGI:
            T0iFp:
            goto sWKRb;
            J2nqT:
            $GOAPR = $JgCdd[$XhZmP];
            goto dbeuj;
            dbeuj:
            if (!($GOAPR['eTag'] !== $TwQaY['eTag'])) {
                goto T0iFp;
            }
            goto QkuVL;
            QkuVL:
            throw new Ycjaywk1DZxJx("Checksum mismatch for part {$XhZmP} of file {$this->YYkmA->getFile()->getFilename()}");
            goto vBBGI;
            PYdaL:
            $XhZmP = $TwQaY['partNumber'];
            goto J2nqT;
            YR1Sl:
        }
        goto kUAJb;
        kUAJb:
        nCXGO:
        goto i1wd9;
        o1JfD:
        $aK2El = $YKW91->EAreJ;
        goto qm4fH;
        qm4fH:
        Assert::eq(count($sGu64), count($aK2El), 'The number of parts and checksums must match.');
        goto WMXsa;
        i1wd9:
        $HuLvb = $this->qFnIc->getClient();
        goto nCzZ2;
        dRZ9V:
    }
}
