<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\Hm5kuVZJdTKtj;
use Jfs\Uploader\Exception\IbbbNgUH6aD1J;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Presigned\Dm52pX9iexrSs;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class VKLqBvZbeNIb4 implements Dm52pX9iexrSs
{
    private static $PILuM = 'chunks/';
    private $D3E4X;
    private $uTYgy;
    private $gG9Jm;
    public function __construct(Hm5kuVZJdTKtj $DiwBV, Filesystem $kVG4M, Filesystem $crBgX)
    {
        goto k86Ix;
        vX4ky:
        $this->gG9Jm = $crBgX;
        goto vgLga;
        k86Ix:
        $this->D3E4X = $DiwBV;
        goto Ae4j1;
        Ae4j1:
        $this->uTYgy = $kVG4M;
        goto vX4ky;
        vgLga:
    }
    public function mFxnem6k407() : void
    {
        goto X68qW;
        NqQOI:
        $xqx5P[] = ['index' => $i1iRy, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $j1Tgu, 'index' => $i1iRy])];
        goto ctUxC;
        bgHoD:
        $this->D3E4X->mFV2s6jujmR()->mTOIVqQ3KEK($j1Tgu);
        goto jRmcL;
        pkT5M:
        HG1Lx:
        goto llLMy;
        CMfD2:
        fMjXC:
        goto s3osH;
        h4KG5:
        $ZsNWr = ceil($H8A56->d7Yxv / $H8A56->MZnay);
        goto MlEMz;
        X68qW:
        $H8A56 = $this->D3E4X->mFV2s6jujmR();
        goto gjDRT;
        Sfarn:
        $this->D3E4X->mFV2s6jujmR()->mTOIVqQ3KEK($j1Tgu);
        goto cqYqt;
        MlEMz:
        $j1Tgu = Uuid::v4()->toHex();
        goto bgHoD;
        zw91b:
        goto HG1Lx;
        goto CMfD2;
        gjDRT:
        $xqx5P = [];
        goto h4KG5;
        WqG4t:
        $this->gG9Jm->put($this->D3E4X->mwdQ1fTd3zq(), json_encode($this->D3E4X->mFV2s6jujmR()->toArray()));
        goto SUb7h;
        Sllqa:
        ++$i1iRy;
        goto zw91b;
        cqYqt:
        $this->uTYgy->put($this->D3E4X->mwdQ1fTd3zq(), json_encode($this->D3E4X->mFV2s6jujmR()->toArray()));
        goto WqG4t;
        s3osH:
        $this->D3E4X->mbYvNurXiYp($xqx5P);
        goto Sfarn;
        llLMy:
        if (!($i1iRy <= $ZsNWr)) {
            goto fMjXC;
        }
        goto NqQOI;
        ctUxC:
        jvHWU:
        goto Sllqa;
        jRmcL:
        $i1iRy = 1;
        goto pkT5M;
        SUb7h:
    }
    public function mmoUBfLYEHW() : void
    {
        goto E30hy;
        FGR3f:
        $j1Tgu = $H8A56->F_Dsk;
        goto bUWr7;
        E30hy:
        $H8A56 = $this->D3E4X->mFV2s6jujmR();
        goto FGR3f;
        bUWr7:
        $this->uTYgy->deleteDirectory(self::$PILuM . $j1Tgu);
        goto CNAR6;
        CNAR6:
        $this->gG9Jm->delete($this->D3E4X->mwdQ1fTd3zq());
        goto ckjr2;
        ckjr2:
    }
    public function mH7ADod756J() : void
    {
        goto mnhK1;
        UES1_:
        $QWyIi = $this->uTYgy->path($Gnqib);
        goto sjR48;
        MwWBc:
        nBXji:
        goto qFAvP;
        tn8lA:
        H1_Jv:
        goto BkifX;
        fwkpS:
        natsort($GCKmP);
        goto eB1aO;
        qFAvP:
        fclose($yXc27);
        goto UES1_;
        sjR48:
        if (chmod($QWyIi, 0644)) {
            goto H1_Jv;
        }
        goto lrxws;
        jRm4W:
        $Gnqib = $this->D3E4X->getFile()->getLocation();
        goto z65Uf;
        lIIu6:
        M41Vq:
        goto fGJEr;
        q8D65:
        XX91b:
        goto Q_Tql;
        a96AL:
        throw new IbbbNgUH6aD1J('Local chunk can not merge file (can create file): ' . $d5Ban);
        goto q8D65;
        BkifX:
        $this->uTYgy->deleteDirectory($XucGF);
        goto WtqCp;
        b7l3r:
        $ZsNWr = $H8A56->hqF67;
        goto HIUor;
        HIUor:
        $XucGF = self::$PILuM . $H8A56->F_Dsk;
        goto jRm4W;
        z65Uf:
        $GCKmP = $this->uTYgy->files($XucGF);
        goto cUfI5;
        Q_Tql:
        foreach ($GCKmP as $xbrfa) {
            goto rU2kc;
            vyrHb:
            fclose($Kt2ug);
            goto Z2FVA;
            rU2kc:
            $wO1iQ = $this->uTYgy->path($xbrfa);
            goto E9OGK;
            KJ8M_:
            O2CQp:
            goto NVCf4;
            FXMU1:
            $xR1W8 = stream_copy_to_stream($Kt2ug, $yXc27);
            goto vyrHb;
            NVCf4:
            r43qI:
            goto yr1Re;
            zXtPQ:
            if (!(false === $Kt2ug)) {
                goto gQOf_;
            }
            goto iBRE2;
            E9OGK:
            $Kt2ug = @fopen($wO1iQ, 'rb');
            goto zXtPQ;
            J0BM5:
            gQOf_:
            goto FXMU1;
            yXlBD:
            throw new IbbbNgUH6aD1J('A chunk file content can not copy: ' . $wO1iQ);
            goto KJ8M_;
            Z2FVA:
            if (!(false === $xR1W8)) {
                goto O2CQp;
            }
            goto yXlBD;
            iBRE2:
            throw new IbbbNgUH6aD1J('A chunk file not existed: ' . $wO1iQ);
            goto J0BM5;
            yr1Re:
        }
        goto MwWBc;
        lrxws:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $QWyIi);
        goto qm3IH;
        mnhK1:
        $H8A56 = $this->D3E4X->mFV2s6jujmR();
        goto b7l3r;
        G2SF6:
        touch($d5Ban);
        goto SM4tJ;
        UclSO:
        $this->uTYgy->makeDirectory($MfPFf);
        goto lIIu6;
        cUfI5:
        Assert::eq(count($GCKmP), $ZsNWr, 'The number of parts and checksums must match.');
        goto fwkpS;
        SM4tJ:
        $yXc27 = @fopen($d5Ban, 'wb');
        goto PFJYN;
        fGJEr:
        $d5Ban = $this->uTYgy->path($Gnqib);
        goto G2SF6;
        QEz6B:
        if ($this->uTYgy->exists($MfPFf)) {
            goto M41Vq;
        }
        goto UclSO;
        PFJYN:
        if (!(false === $yXc27)) {
            goto XX91b;
        }
        goto a96AL;
        eB1aO:
        $MfPFf = dirname($Gnqib);
        goto QEz6B;
        qm3IH:
        throw new \Exception('Failed to set file permissions for stored image: ' . $QWyIi);
        goto tn8lA;
        WtqCp:
    }
}
