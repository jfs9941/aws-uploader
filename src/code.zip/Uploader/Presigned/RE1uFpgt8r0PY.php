<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\ZOwA486ueqbmD;
use Jfs\Uploader\Exception\IPu9dirA3oDHh;
use Jfs\Uploader\Exception\ZbljA5z87yooD;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Jfs\Uploader\Exception\BrZKqHT1Ver7X;
use Webmozart\Assert\Assert;
class RE1uFpgt8r0PY implements M9yUJFukHJtOF
{
    private $alOL8;
    private $Hf14x;
    private $tYBKb;
    private $zzcfY;
    public function __construct(ZOwA486ueqbmD $X40HK, Filesystem $p1fCH, Filesystem $zCXkD, string $UYSBS)
    {
        goto PV3ET;
        OgiUV:
        $this->Hf14x = $p1fCH;
        goto ig7P0;
        s9Yjp:
        $this->zzcfY = $UYSBS;
        goto uPD9C;
        ig7P0:
        $this->tYBKb = $zCXkD;
        goto s9Yjp;
        PV3ET:
        $this->alOL8 = $X40HK;
        goto OgiUV;
        uPD9C:
    }
    public function mXz4toFge7Q()
    {
        goto NkFyq;
        AOKin:
        if (!($vypSG <= $yW3Og)) {
            goto XohKq;
        }
        goto BEdfz;
        XJmVa:
        kJc8C:
        goto plwRA;
        BEdfz:
        $OeQOO = $tgr9H->getCommand('UploadPart', ['Bucket' => $this->zzcfY, 'Key' => $this->alOL8->getFile()->getLocation(), 'UploadId' => $Or112['UploadId'], 'PartNumber' => $vypSG]);
        goto YVFe3;
        NkFyq:
        $Cva33 = $this->alOL8->mFmRtrLmgsB();
        goto RPiKE;
        wuPf9:
        ++$vypSG;
        goto GAsaf;
        ONfa3:
        $RYFrs[] = ['index' => $vypSG, 'url' => (string) $p8nhd->getUri()];
        goto VMQu4;
        VMQu4:
        UKJUX:
        goto wuPf9;
        WDDjo:
        $yW3Og = ceil($Cva33->hYBql / $Cva33->ditJT);
        goto K698I;
        M_mta:
        throw new BrZKqHT1Ver7X("Failed to create multipart upload for file {$this->alOL8->getFile()->getFilename()}, S3 return empty response");
        goto XJmVa;
        Do_U3:
        if (!(0 === $Or112->count())) {
            goto kJc8C;
        }
        goto M_mta;
        v9c2X:
        $this->alOL8->mFmRtrLmgsB()->m4dvFVAPIAN($Or112['UploadId']);
        goto BcZee;
        RPiKE:
        $RYFrs = [];
        goto WDDjo;
        K698I:
        $tgr9H = $this->tYBKb->getClient();
        goto CclMD;
        BcZee:
        $this->Hf14x->put($this->alOL8->mqnDxf54UN2(), json_encode($this->alOL8->mFmRtrLmgsB()->toArray()));
        goto GYFCo;
        eyvKs:
        $this->alOL8->msb2M0BFxEn($RYFrs);
        goto v9c2X;
        blaDc:
        Znaoz:
        goto AOKin;
        j61bW:
        XohKq:
        goto eyvKs;
        GAsaf:
        goto Znaoz;
        goto j61bW;
        GYFCo:
        $this->tYBKb->put($this->alOL8->mqnDxf54UN2(), json_encode($this->alOL8->mFmRtrLmgsB()->toArray()));
        goto OeCWS;
        YVFe3:
        $p8nhd = $tgr9H->createPresignedRequest($OeQOO, '+1 day');
        goto ONfa3;
        plwRA:
        $vypSG = 1;
        goto blaDc;
        CclMD:
        $Or112 = $tgr9H->createMultipartUpload(['Bucket' => $this->zzcfY, 'Key' => $this->alOL8->getFile()->getLocation(), 'ContentType' => $this->alOL8->mFmRtrLmgsB()->MbqgQ, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto Do_U3;
        OeCWS:
    }
    public function maQSjrd7n8J() : void
    {
        goto XQGNz;
        Kore0:
        $this->Hf14x->delete($this->alOL8->mqnDxf54UN2());
        goto LNiRI;
        XQGNz:
        $tgr9H = $this->tYBKb->getClient();
        goto P9o52;
        P9o52:
        try {
            $tgr9H->abortMultipartUpload(['Bucket' => $this->zzcfY, 'Key' => $this->alOL8->getFile()->getLocation(), 'UploadId' => $this->alOL8->mFmRtrLmgsB()->cgWhy]);
        } catch (\Throwable $cy3Ei) {
            throw new IPu9dirA3oDHh("Failed to abort multipart upload of file {$this->alOL8->getFile()->getFilename()}", 0, $cy3Ei);
        }
        goto Kore0;
        LNiRI:
        $this->tYBKb->delete($this->alOL8->mqnDxf54UN2());
        goto YKOr4;
        YKOr4:
    }
    public function mpI4EE9RWUf() : void
    {
        goto Y1icW;
        BY8ho:
        $jVihR = collect($bLIUr)->keyBy('partNumber');
        goto hVwpa;
        Y1icW:
        $Cva33 = $this->alOL8->mFmRtrLmgsB();
        goto P6AuJ;
        u90eJ:
        try {
            $tgr9H->completeMultipartUpload(['Bucket' => $this->zzcfY, 'Key' => $this->alOL8->getFile()->getLocation(), 'UploadId' => $this->alOL8->mFmRtrLmgsB()->cgWhy, 'MultipartUpload' => ['Parts' => collect($this->alOL8->mFmRtrLmgsB()->u0a6G)->sortBy('partNumber')->map(fn($KikPD) => ['ETag' => $KikPD['eTag'], 'PartNumber' => $KikPD['partNumber']])->toArray()]]);
        } catch (\Throwable $cy3Ei) {
            throw new ZbljA5z87yooD("Failed to merge chunks of file {$this->alOL8->getFile()->getFilename()}", 0, $cy3Ei);
        }
        goto Ml1W5;
        P6AuJ:
        $bLIUr = $Cva33->u0a6G;
        goto hCNuY;
        YvUI4:
        Assert::eq(count($bLIUr), count($qG1CG), 'The number of parts and checksums must match.');
        goto BY8ho;
        hVwpa:
        foreach ($qG1CG as $clc83) {
            goto EaSbw;
            TE_Al:
            $KikPD = $jVihR[$tDQ8k];
            goto Ulzpv;
            RB0L7:
            mIapt:
            goto Fl1bc;
            EaSbw:
            $tDQ8k = $clc83['partNumber'];
            goto TE_Al;
            NUi30:
            throw new ZbljA5z87yooD("Checksum mismatch for part {$tDQ8k} of file {$this->alOL8->getFile()->getFilename()}");
            goto RB0L7;
            Ulzpv:
            if (!($KikPD['eTag'] !== $clc83['eTag'])) {
                goto mIapt;
            }
            goto NUi30;
            Fl1bc:
            nTHwR:
            goto uBYXR;
            uBYXR:
        }
        goto ruvmG;
        ruvmG:
        Sjhmk:
        goto mUf0z;
        mUf0z:
        $tgr9H = $this->tYBKb->getClient();
        goto u90eJ;
        hCNuY:
        $qG1CG = $Cva33->Phl0_;
        goto YvUI4;
        Ml1W5:
    }
}
