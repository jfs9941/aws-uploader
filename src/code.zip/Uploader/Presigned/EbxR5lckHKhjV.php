<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\ZFuimKZywyxo2;
use Jfs\Uploader\Exception\TlWimU2mFcN6B;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Presigned\HAbaKS6CSgn7Z;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class EbxR5lckHKhjV implements HAbaKS6CSgn7Z
{
    private static $kkFFx = 'chunks/';
    private $W_NkT;
    private $yt19t;
    private $wKOGL;
    public function __construct(ZFuimKZywyxo2 $araMZ, Filesystem $RndMA, Filesystem $luwqK)
    {
        goto WmGzt;
        WmGzt:
        $this->W_NkT = $araMZ;
        goto aop36;
        sFeqg:
        $this->wKOGL = $luwqK;
        goto ZmmAe;
        aop36:
        $this->yt19t = $RndMA;
        goto sFeqg;
        ZmmAe:
    }
    public function mFjyNjJ9bsc() : void
    {
        goto LSZA9;
        AJk5s:
        $r_huy = $zkqCI->filename;
        goto lSD9D;
        Ar0Kb:
        $this->W_NkT->mYisetnzoMl($V6bfw);
        goto HkDAJ;
        noHIF:
        pNv1i:
        goto WH2g5;
        EF7Ho:
        $this->yt19t->put($this->W_NkT->muoWhAZBWrx(), json_encode($this->W_NkT->mf47A6FAs7u()->toArray()));
        goto VFsr6;
        WH2g5:
        if (!($jM7_h <= $GQ1lE)) {
            goto R_qfP;
        }
        goto nei2j;
        LSZA9:
        $zkqCI = $this->W_NkT->mf47A6FAs7u();
        goto RmuFQ;
        HkDAJ:
        $this->W_NkT->mf47A6FAs7u()->mYg3hbRtYS1($r_huy);
        goto EF7Ho;
        z1E8x:
        R_qfP:
        goto Ar0Kb;
        ngkEs:
        l3PG5:
        goto ZZ15E;
        l3snW:
        goto pNv1i;
        goto z1E8x;
        yKoEX:
        $V6bfw[] = ['index' => $jM7_h, 'url' => $BHsWd];
        goto ngkEs;
        DovF2:
        $jM7_h = 1;
        goto noHIF;
        T20we:
        $GQ1lE = ceil($zkqCI->ylT5T / $zkqCI->Q3Heu);
        goto AJk5s;
        FTrSf:
        $fFHUt = parse_url($A8jlG, PHP_URL_HOST);
        goto d4b8Z;
        ZZ15E:
        ++$jM7_h;
        goto l3snW;
        VFsr6:
        $this->wKOGL->put($this->W_NkT->muoWhAZBWrx(), json_encode($this->W_NkT->mf47A6FAs7u()->toArray()));
        goto cFYjL;
        d4b8Z:
        $BHsWd = 'https://' . $fFHUt . '/' . ltrim($hU2b_, '/');
        goto yKoEX;
        nei2j:
        $A8jlG = route('upload.api.local_chunk.upload', ['uploadId' => $r_huy, 'index' => $jM7_h]);
        goto C65t7;
        RmuFQ:
        $V6bfw = [];
        goto T20we;
        C65t7:
        $hU2b_ = parse_url($A8jlG, PHP_URL_PATH);
        goto FTrSf;
        lSD9D:
        $this->W_NkT->mf47A6FAs7u()->mYg3hbRtYS1($r_huy);
        goto DovF2;
        cFYjL:
    }
    public function mFzOOpO3hET() : void
    {
        goto g6pld;
        nnps9:
        $this->wKOGL->delete($this->W_NkT->muoWhAZBWrx());
        goto xo18v;
        sB1ZI:
        $r_huy = $zkqCI->nk34n;
        goto t9UxG;
        t9UxG:
        $this->yt19t->deleteDirectory(self::$kkFFx . $r_huy);
        goto nnps9;
        g6pld:
        $zkqCI = $this->W_NkT->mf47A6FAs7u();
        goto sB1ZI;
        xo18v:
    }
    public function mR3MGYXUkcQ() : void
    {
        goto b78KL;
        b78KL:
        $zkqCI = $this->W_NkT->mf47A6FAs7u();
        goto KmkuV;
        NDfD0:
        $ZmQsi = self::$kkFFx . $zkqCI->nk34n;
        goto OChuz;
        mj7pZ:
        throw new \Exception('Failed to set file permissions for stored image: ' . $BlQKN);
        goto hG8Q9;
        Ys83N:
        $QtLYY = @fopen($MR1P5, 'wb');
        goto p3mB2;
        NDgrT:
        throw new TlWimU2mFcN6B('Local chunk can not merge file (can create file): ' . $MR1P5);
        goto akhNW;
        N0tmN:
        $this->yt19t->makeDirectory($BKtGd);
        goto MgsSq;
        p3mB2:
        if (!(false === $QtLYY)) {
            goto hq4WP;
        }
        goto NDgrT;
        ka_zQ:
        $BKtGd = dirname($AH6g6);
        goto Xbs6k;
        GJ1pc:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $BlQKN);
        goto mj7pZ;
        UwcEj:
        Assert::eq(count($GAtmc), $GQ1lE, 'The number of parts and checksums must match.');
        goto HaSjz;
        oNZ0B:
        if (chmod($BlQKN, 0644)) {
            goto T8gqD;
        }
        goto GJ1pc;
        Xbs6k:
        if ($this->yt19t->exists($BKtGd)) {
            goto ondTp;
        }
        goto N0tmN;
        EB1NJ:
        foreach ($GAtmc as $niPae) {
            goto LDitu;
            x867h:
            rvxBU:
            goto iqvpY;
            WD2vC:
            if (!(false === $HSqDo)) {
                goto dr9US;
            }
            goto n89Ua;
            Zg1p_:
            dr9US:
            goto YtpRU;
            vAAGX:
            wjNKb:
            goto x867h;
            YtpRU:
            $zgv04 = stream_copy_to_stream($HSqDo, $QtLYY);
            goto RsMT7;
            T1Gfu:
            throw new TlWimU2mFcN6B('A chunk file content can not copy: ' . $SFRfx);
            goto vAAGX;
            S6Eou:
            if (!(false === $zgv04)) {
                goto wjNKb;
            }
            goto T1Gfu;
            RsMT7:
            fclose($HSqDo);
            goto S6Eou;
            n89Ua:
            throw new TlWimU2mFcN6B('A chunk file not existed: ' . $SFRfx);
            goto Zg1p_;
            LDitu:
            $SFRfx = $this->yt19t->path($niPae);
            goto ittIL;
            ittIL:
            $HSqDo = @fopen($SFRfx, 'rb');
            goto WD2vC;
            iqvpY:
        }
        goto hBMaw;
        iB43n:
        $MR1P5 = $this->yt19t->path($AH6g6);
        goto L7IkT;
        Bwy9Z:
        $GAtmc = $this->yt19t->files($ZmQsi);
        goto UwcEj;
        L7IkT:
        touch($MR1P5);
        goto Ys83N;
        eedo4:
        fclose($QtLYY);
        goto fpuwa;
        fpuwa:
        $BlQKN = $this->yt19t->path($AH6g6);
        goto oNZ0B;
        HaSjz:
        natsort($GAtmc);
        goto ka_zQ;
        hG8Q9:
        T8gqD:
        goto KmB6y;
        hBMaw:
        Y3X4B:
        goto eedo4;
        KmB6y:
        $this->yt19t->deleteDirectory($ZmQsi);
        goto toieW;
        MgsSq:
        ondTp:
        goto iB43n;
        KmkuV:
        $GQ1lE = $zkqCI->y3Y6J;
        goto NDfD0;
        OChuz:
        $AH6g6 = $this->W_NkT->getFile()->getLocation();
        goto Bwy9Z;
        akhNW:
        hq4WP:
        goto EB1NJ;
        toieW:
    }
}
