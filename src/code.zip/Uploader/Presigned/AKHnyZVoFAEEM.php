<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\Q4cNg0cF0Oivx;
use Jfs\Uploader\Exception\NLvdCLQgmsVkR;
use Jfs\Uploader\Exception\B9MoXxTsOo5T7;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Exception\EUdSdOtPPTVNP;
use Jfs\Uploader\Presigned\Wu7dedFEcx87P;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class AKHnyZVoFAEEM implements Wu7dedFEcx87P
{
    private $z1SIX;
    private $P8Yzg;
    private $Lrbr9;
    private $t4Y2D;
    public function __construct(Q4cNg0cF0Oivx $XqWFu, Filesystem $jT0xz, Filesystem $x4E8s, string $wY6MR)
    {
        goto u3pcP;
        my9tx:
        $this->P8Yzg = $jT0xz;
        goto Urfh9;
        Z7BUM:
        $this->t4Y2D = $wY6MR;
        goto GXJ8A;
        u3pcP:
        $this->z1SIX = $XqWFu;
        goto my9tx;
        Urfh9:
        $this->Lrbr9 = $x4E8s;
        goto Z7BUM;
        GXJ8A:
    }
    public function mmnQHbuvJde()
    {
        goto YffhA;
        ikwU3:
        $YoH80 = [];
        goto r5_4L;
        YffhA:
        $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
        goto ikwU3;
        WpS6V:
        $LDmT4 = $ZbtsO->createMultipartUpload(['Bucket' => $this->t4Y2D, 'Key' => $this->z1SIX->getFile()->getLocation(), 'ContentType' => $this->z1SIX->mjt4KTTPlCK()->E428N, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto NwC0V;
        jZg_u:
        if (!($nTsbn <= $NWsS6)) {
            goto e9BxT;
        }
        goto dUmP6;
        Ebvgy:
        throw new EUdSdOtPPTVNP("Failed to create multipart upload for file {$this->z1SIX->getFile()->getFilename()}, S3 return empty response");
        goto mAjfi;
        zVKav:
        $YoH80[] = ['index' => $nTsbn, 'url' => (string) $xMG6f->getUri()];
        goto mv2wg;
        eZD3F:
        $this->z1SIX->m7mjAjbAyV9($YoH80);
        goto kALNe;
        k0b9V:
        $nTsbn = 1;
        goto ApNle;
        mv2wg:
        q4rW6:
        goto gogG_;
        mAjfi:
        c8At9:
        goto k0b9V;
        gogG_:
        ++$nTsbn;
        goto K8wSm;
        dUmP6:
        $c6HaU = $ZbtsO->getCommand('UploadPart', ['Bucket' => $this->t4Y2D, 'Key' => $this->z1SIX->getFile()->getLocation(), 'UploadId' => $LDmT4['UploadId'], 'PartNumber' => $nTsbn]);
        goto ZteIY;
        r5_4L:
        $NWsS6 = ceil($SaEd8->Etik3 / $SaEd8->QFN10);
        goto MlEDx;
        PHMlv:
        $this->Lrbr9->put($this->z1SIX->m0q4dteLZ4Y(), json_encode($this->z1SIX->mjt4KTTPlCK()->toArray()));
        goto x02ND;
        ApNle:
        tvZN5:
        goto jZg_u;
        kALNe:
        $this->z1SIX->mjt4KTTPlCK()->mdX5318DZYf($LDmT4['UploadId']);
        goto c1Nwn;
        DuFpN:
        e9BxT:
        goto eZD3F;
        NwC0V:
        if (!(0 === $LDmT4->count())) {
            goto c8At9;
        }
        goto Ebvgy;
        c1Nwn:
        $this->P8Yzg->put($this->z1SIX->m0q4dteLZ4Y(), json_encode($this->z1SIX->mjt4KTTPlCK()->toArray()));
        goto PHMlv;
        ZteIY:
        $xMG6f = $ZbtsO->createPresignedRequest($c6HaU, '+1 day');
        goto zVKav;
        MlEDx:
        $ZbtsO = $this->Lrbr9->getClient();
        goto WpS6V;
        K8wSm:
        goto tvZN5;
        goto DuFpN;
        x02ND:
    }
    public function mAQla2YiH6K() : void
    {
        goto yiSh9;
        yiSh9:
        $ZbtsO = $this->Lrbr9->getClient();
        goto R5m5L;
        YC7ur:
        $this->P8Yzg->delete($this->z1SIX->m0q4dteLZ4Y());
        goto IntO6;
        R5m5L:
        try {
            $ZbtsO->abortMultipartUpload(['Bucket' => $this->t4Y2D, 'Key' => $this->z1SIX->getFile()->getLocation(), 'UploadId' => $this->z1SIX->mjt4KTTPlCK()->e7KJG]);
        } catch (\Throwable $AUVE0) {
            throw new NLvdCLQgmsVkR("Failed to abort multipart upload of file {$this->z1SIX->getFile()->getFilename()}", 0, $AUVE0);
        }
        goto YC7ur;
        IntO6:
        $this->Lrbr9->delete($this->z1SIX->m0q4dteLZ4Y());
        goto LTi60;
        LTi60:
    }
    public function mrSzJ7YzPBP() : void
    {
        goto vF3GR;
        OVtH0:
        $wErBB = $SaEd8->sJEjQ;
        goto Yr5Rp;
        aptT7:
        foreach ($peJtM as $kLKtf) {
            goto vvhWq;
            vAMcK:
            HtNN6:
            goto fmykY;
            fmykY:
            ZOaX0:
            goto uS3oX;
            mrz5i:
            if (!($uMlRK['eTag'] !== $kLKtf['eTag'])) {
                goto HtNN6;
            }
            goto GV7xi;
            vvhWq:
            $kJXKP = $kLKtf['partNumber'];
            goto Esrv8;
            GV7xi:
            throw new B9MoXxTsOo5T7("Checksum mismatch for part {$kJXKP} of file {$this->z1SIX->getFile()->getFilename()}");
            goto vAMcK;
            Esrv8:
            $uMlRK = $TccPY[$kJXKP];
            goto mrz5i;
            uS3oX:
        }
        goto hJN5_;
        Yr5Rp:
        $peJtM = $SaEd8->bKDFt;
        goto KQEVl;
        vF3GR:
        $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
        goto OVtH0;
        KQEVl:
        Assert::eq(count($wErBB), count($peJtM), 'The number of parts and checksums must match.');
        goto qR5eY;
        hJN5_:
        qBoXp:
        goto bA9H9;
        R7GHF:
        try {
            $ZbtsO->completeMultipartUpload(['Bucket' => $this->t4Y2D, 'Key' => $this->z1SIX->getFile()->getLocation(), 'UploadId' => $this->z1SIX->mjt4KTTPlCK()->e7KJG, 'MultipartUpload' => ['Parts' => collect($this->z1SIX->mjt4KTTPlCK()->sJEjQ)->sortBy('partNumber')->map(fn($uMlRK) => ['ETag' => $uMlRK['eTag'], 'PartNumber' => $uMlRK['partNumber']])->toArray()]]);
        } catch (\Throwable $AUVE0) {
            throw new B9MoXxTsOo5T7("Failed to merge chunks of file {$this->z1SIX->getFile()->getFilename()}", 0, $AUVE0);
        }
        goto TlZo4;
        bA9H9:
        $ZbtsO = $this->Lrbr9->getClient();
        goto R7GHF;
        qR5eY:
        $TccPY = collect($wErBB)->keyBy('partNumber');
        goto aptT7;
        TlZo4:
    }
}
