<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\TmESz0lUHO033;
use Jfs\Uploader\Exception\KN3DbMe4GDZjf;
use Jfs\Uploader\Exception\Ia53NE5vmyg2u;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Exception\EIEB7mnsDMVk7;
use Jfs\Uploader\Presigned\YkB5tLk814qJP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class R0V3u2B7hkl0g implements YkB5tLk814qJP
{
    private $VqTjZ;
    private $hYphi;
    private $DtvHw;
    private $pKUHV;
    public function __construct(TmESz0lUHO033 $X318G, Filesystem $zuNM5, Filesystem $S3rMg, string $drKb4)
    {
        goto qLSYD;
        mGEZ5:
        $this->pKUHV = $drKb4;
        goto oi4cL;
        qLSYD:
        $this->VqTjZ = $X318G;
        goto VYRU4;
        VYRU4:
        $this->hYphi = $zuNM5;
        goto kERlw;
        kERlw:
        $this->DtvHw = $S3rMg;
        goto mGEZ5;
        oi4cL:
    }
    public function m0jynmDLk8d()
    {
        goto HllGQ;
        vgLgM:
        zuJZ7:
        goto mveEf;
        xaJQz:
        $darX4 = $NJDBD->createPresignedRequest($u8Ej5, '+1 day');
        goto RJbpA;
        U5cxa:
        $NJDBD = $this->DtvHw->getClient();
        goto nEDWy;
        X2vID:
        if (!($dwIiF <= $eZtxX)) {
            goto zuJZ7;
        }
        goto eawtO;
        exOno:
        $dwIiF = 1;
        goto VvN6Z;
        HllGQ:
        $p3JMC = $this->VqTjZ->miyJ5feZwpY();
        goto lvkkv;
        mveEf:
        $this->VqTjZ->mHScPCLoHCA($F77Xa);
        goto B7VtO;
        VvN6Z:
        DFzoc:
        goto X2vID;
        RJbpA:
        $F77Xa[] = ['index' => $dwIiF, 'url' => (string) $darX4->getUri()];
        goto wP_cH;
        B7VtO:
        $this->VqTjZ->miyJ5feZwpY()->muRlIJMM2ro($bzyUS['UploadId']);
        goto bUBeG;
        jPBho:
        if (!(0 === $bzyUS->count())) {
            goto zgWxe;
        }
        goto s9P9u;
        eawtO:
        $u8Ej5 = $NJDBD->getCommand('UploadPart', ['Bucket' => $this->pKUHV, 'Key' => $this->VqTjZ->getFile()->getLocation(), 'UploadId' => $bzyUS['UploadId'], 'PartNumber' => $dwIiF]);
        goto xaJQz;
        UYMwQ:
        zgWxe:
        goto exOno;
        gsUx4:
        $eZtxX = ceil($p3JMC->ovxJB / $p3JMC->O_GCc);
        goto U5cxa;
        M16oU:
        goto DFzoc;
        goto vgLgM;
        wP_cH:
        P2aJV:
        goto noF0V;
        e6JTq:
        $this->DtvHw->put($this->VqTjZ->mLypJLcFD97(), json_encode($this->VqTjZ->miyJ5feZwpY()->toArray()));
        goto s68QM;
        noF0V:
        ++$dwIiF;
        goto M16oU;
        lvkkv:
        $F77Xa = [];
        goto gsUx4;
        nEDWy:
        $bzyUS = $NJDBD->createMultipartUpload(['Bucket' => $this->pKUHV, 'Key' => $this->VqTjZ->getFile()->getLocation(), 'ContentType' => $this->VqTjZ->miyJ5feZwpY()->wl2h6, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto jPBho;
        bUBeG:
        $this->hYphi->put($this->VqTjZ->mLypJLcFD97(), json_encode($this->VqTjZ->miyJ5feZwpY()->toArray()));
        goto e6JTq;
        s9P9u:
        throw new EIEB7mnsDMVk7("Failed to create multipart upload for file {$this->VqTjZ->getFile()->getFilename()}, S3 return empty response");
        goto UYMwQ;
        s68QM:
    }
    public function mcNt6cVVB0k() : void
    {
        goto tD1vn;
        FKZIz:
        $this->DtvHw->delete($this->VqTjZ->mLypJLcFD97());
        goto oiz5l;
        EVKkJ:
        $this->hYphi->delete($this->VqTjZ->mLypJLcFD97());
        goto FKZIz;
        tD1vn:
        $NJDBD = $this->DtvHw->getClient();
        goto Ej3VH;
        Ej3VH:
        try {
            $NJDBD->abortMultipartUpload(['Bucket' => $this->pKUHV, 'Key' => $this->VqTjZ->getFile()->getLocation(), 'UploadId' => $this->VqTjZ->miyJ5feZwpY()->UUwpG]);
        } catch (\Throwable $qeKgz) {
            throw new KN3DbMe4GDZjf("Failed to abort multipart upload of file {$this->VqTjZ->getFile()->getFilename()}", 0, $qeKgz);
        }
        goto EVKkJ;
        oiz5l:
    }
    public function mPJeP3847zn() : void
    {
        goto kfLVa;
        BISQP:
        $NJDBD = $this->DtvHw->getClient();
        goto Puo7q;
        Jz_jP:
        oiMry:
        goto BISQP;
        kfLVa:
        $p3JMC = $this->VqTjZ->miyJ5feZwpY();
        goto MXZcA;
        MXZcA:
        $jOnpR = $p3JMC->rFNTA;
        goto TqpSS;
        QUPFB:
        foreach ($ZbwDh as $RQfPQ) {
            goto bhiwm;
            bhiwm:
            $sQR_R = $RQfPQ['partNumber'];
            goto VXZ7a;
            VXZ7a:
            $ZRw84 = $Rl32A[$sQR_R];
            goto noRy_;
            Dtl1U:
            ZQn81:
            goto E_tDh;
            JYjZ3:
            throw new Ia53NE5vmyg2u("Checksum mismatch for part {$sQR_R} of file {$this->VqTjZ->getFile()->getFilename()}");
            goto st5PX;
            st5PX:
            gOfi_:
            goto Dtl1U;
            noRy_:
            if (!($ZRw84['eTag'] !== $RQfPQ['eTag'])) {
                goto gOfi_;
            }
            goto JYjZ3;
            E_tDh:
        }
        goto Jz_jP;
        TqpSS:
        $ZbwDh = $p3JMC->NUHaj;
        goto kznZK;
        kznZK:
        Assert::eq(count($jOnpR), count($ZbwDh), 'The number of parts and checksums must match.');
        goto ysTvP;
        Puo7q:
        try {
            $NJDBD->completeMultipartUpload(['Bucket' => $this->pKUHV, 'Key' => $this->VqTjZ->getFile()->getLocation(), 'UploadId' => $this->VqTjZ->miyJ5feZwpY()->UUwpG, 'MultipartUpload' => ['Parts' => collect($this->VqTjZ->miyJ5feZwpY()->rFNTA)->sortBy('partNumber')->map(fn($ZRw84) => ['ETag' => $ZRw84['eTag'], 'PartNumber' => $ZRw84['partNumber']])->toArray()]]);
        } catch (\Throwable $qeKgz) {
            throw new Ia53NE5vmyg2u("Failed to merge chunks of file {$this->VqTjZ->getFile()->getFilename()}", 0, $qeKgz);
        }
        goto cuwxr;
        ysTvP:
        $Rl32A = collect($jOnpR)->keyBy('partNumber');
        goto QUPFB;
        cuwxr:
    }
}
