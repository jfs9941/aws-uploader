<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\EpvE4BO9GOGFh;
use Jfs\Uploader\Exception\NmrNjbk6g29we;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Presigned\DTNoyruiw1HR5;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class XdPJzQAWBAhHp implements DTNoyruiw1HR5
{
    private static $geBlv = 'chunks/';
    private $EBcoC;
    private $TD3CW;
    private $Ht28P;
    public function __construct(EpvE4BO9GOGFh $N1xft, Filesystem $e3uVO, Filesystem $cUbzi)
    {
        goto ffRgK;
        pbC6P:
        $this->TD3CW = $e3uVO;
        goto Xe66C;
        ffRgK:
        $this->EBcoC = $N1xft;
        goto pbC6P;
        Xe66C:
        $this->Ht28P = $cUbzi;
        goto wJSCh;
        wJSCh:
    }
    public function mRdlHlaN15F() : void
    {
        goto h9NDq;
        AED59:
        $this->EBcoC->mw6tRR1NtWf()->m4uiiVaRFKw($KCSMR);
        goto UkEQL;
        oaTO4:
        $rQZsd = 'https://' . $P7TlO . '/' . ltrim($HCRCz, '/');
        goto sI9hr;
        YI80t:
        goto G1SbZ;
        goto ebEjM;
        E_qPJ:
        $this->EBcoC->mw6tRR1NtWf()->m4uiiVaRFKw($KCSMR);
        goto ur3jx;
        h9NDq:
        $abL5U = $this->EBcoC->mw6tRR1NtWf();
        goto SuVwT;
        VuRin:
        $P7TlO = parse_url($YHzDC, PHP_URL_HOST);
        goto oaTO4;
        zHdeN:
        $KCSMR = $abL5U->filename;
        goto AED59;
        JTE2a:
        $YHzDC = route('upload.api.local_chunk.upload', ['uploadId' => $KCSMR, 'index' => $WMHuX]);
        goto DX8BO;
        SuVwT:
        $boggV = [];
        goto VAG5G;
        xpBI9:
        $this->EBcoC->mTOWfJEsE4M($boggV);
        goto E_qPJ;
        V4vfW:
        fAcjQ:
        goto VQzIc;
        VQzIc:
        ++$WMHuX;
        goto YI80t;
        VAG5G:
        $J6kJg = ceil($abL5U->NG2sX / $abL5U->mGlEw);
        goto zHdeN;
        dE1PI:
        if (!($WMHuX <= $J6kJg)) {
            goto W_pny;
        }
        goto JTE2a;
        UkEQL:
        $WMHuX = 1;
        goto lnJDQ;
        sI9hr:
        $boggV[] = ['index' => $WMHuX, 'url' => $rQZsd];
        goto V4vfW;
        ur3jx:
        $this->TD3CW->put($this->EBcoC->mjA9e0O9M21(), json_encode($this->EBcoC->mw6tRR1NtWf()->toArray()));
        goto WNp8s;
        lnJDQ:
        G1SbZ:
        goto dE1PI;
        WNp8s:
        $this->Ht28P->put($this->EBcoC->mjA9e0O9M21(), json_encode($this->EBcoC->mw6tRR1NtWf()->toArray()));
        goto Oq3o7;
        ebEjM:
        W_pny:
        goto xpBI9;
        DX8BO:
        $HCRCz = parse_url($YHzDC, PHP_URL_PATH);
        goto VuRin;
        Oq3o7:
    }
    public function mNbyeDUf9J3() : void
    {
        goto Q9gvt;
        l3lAq:
        $KCSMR = $abL5U->RBHGE;
        goto PGPXn;
        R82Hq:
        $this->Ht28P->delete($this->EBcoC->mjA9e0O9M21());
        goto U7ZSA;
        PGPXn:
        $this->TD3CW->deleteDirectory(self::$geBlv . $KCSMR);
        goto R82Hq;
        Q9gvt:
        $abL5U = $this->EBcoC->mw6tRR1NtWf();
        goto l3lAq;
        U7ZSA:
    }
    public function mSJsdVCHEX6() : void
    {
        goto Ehzb5;
        ybSOk:
        fclose($R6Nh_);
        goto bGoEd;
        dfUNy:
        $kjyNZ = self::$geBlv . $abL5U->RBHGE;
        goto D6grK;
        bGT2m:
        if ($this->TD3CW->exists($OkDuT)) {
            goto pH1hK;
        }
        goto DcfpN;
        nhbeF:
        ZtFRT:
        goto K3plo;
        pPoZq:
        Assert::eq(count($xpB06), $J6kJg, 'The number of parts and checksums must match.');
        goto Xt1XL;
        mmiEJ:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $f5SDf);
        goto LwcrF;
        P6440:
        $J6kJg = $abL5U->b_Oyb;
        goto dfUNy;
        oT9mP:
        if (chmod($f5SDf, 0644)) {
            goto w9tFV;
        }
        goto mmiEJ;
        kUZpa:
        $AxiA4 = $this->TD3CW->path($G__yK);
        goto HTKzC;
        K3plo:
        foreach ($xpB06 as $VlYxO) {
            goto ZDg4D;
            iyPL4:
            $kTM2a = @fopen($p4DSL, 'rb');
            goto VRFYy;
            kIIFf:
            if (!(false === $Cx_zP)) {
                goto gr8fm;
            }
            goto FYSlj;
            won3X:
            $Cx_zP = stream_copy_to_stream($kTM2a, $R6Nh_);
            goto zwJrY;
            ZDg4D:
            $p4DSL = $this->TD3CW->path($VlYxO);
            goto iyPL4;
            VRFYy:
            if (!(false === $kTM2a)) {
                goto Rw7O5;
            }
            goto B1l7h;
            Cx_Xd:
            gr8fm:
            goto r_H3N;
            FYSlj:
            throw new NmrNjbk6g29we('A chunk file content can not copy: ' . $p4DSL);
            goto Cx_Xd;
            B1l7h:
            throw new NmrNjbk6g29we('A chunk file not existed: ' . $p4DSL);
            goto HqusO;
            HqusO:
            Rw7O5:
            goto won3X;
            r_H3N:
            qKRXY:
            goto RtnS3;
            zwJrY:
            fclose($kTM2a);
            goto kIIFf;
            RtnS3:
        }
        goto xjIKT;
        kAOx2:
        $OkDuT = dirname($G__yK);
        goto bGT2m;
        bGoEd:
        $f5SDf = $this->TD3CW->path($G__yK);
        goto oT9mP;
        LwcrF:
        throw new \Exception('Failed to set file permissions for stored image: ' . $f5SDf);
        goto X7azw;
        Ehzb5:
        $abL5U = $this->EBcoC->mw6tRR1NtWf();
        goto P6440;
        D6grK:
        $G__yK = $this->EBcoC->getFile()->getLocation();
        goto x0n2y;
        EmwyJ:
        pH1hK:
        goto kUZpa;
        x0n2y:
        $xpB06 = $this->TD3CW->files($kjyNZ);
        goto pPoZq;
        HTKzC:
        touch($AxiA4);
        goto byh0S;
        X7azw:
        w9tFV:
        goto tyD9e;
        iiGd_:
        if (!(false === $R6Nh_)) {
            goto ZtFRT;
        }
        goto XOmXN;
        tyD9e:
        $this->TD3CW->deleteDirectory($kjyNZ);
        goto WqXLN;
        byh0S:
        $R6Nh_ = @fopen($AxiA4, 'wb');
        goto iiGd_;
        DcfpN:
        $this->TD3CW->makeDirectory($OkDuT);
        goto EmwyJ;
        xjIKT:
        uDub7:
        goto ybSOk;
        Xt1XL:
        natsort($xpB06);
        goto kAOx2;
        XOmXN:
        throw new NmrNjbk6g29we('Local chunk can not merge file (can create file): ' . $AxiA4);
        goto nhbeF;
        WqXLN:
    }
}
