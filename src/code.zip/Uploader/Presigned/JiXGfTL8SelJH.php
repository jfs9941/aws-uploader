<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\RShptJ3iNjD6n;
use Jfs\Uploader\Exception\LdcpmL2k672fR;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Presigned\NVSQxlnyPbOpL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class JiXGfTL8SelJH implements NVSQxlnyPbOpL
{
    private static $SwsER = 'chunks/';
    private $MRm9W;
    private $iK6YG;
    private $g3eUc;
    public function __construct(RShptJ3iNjD6n $oF7W0, Filesystem $whVTJ, Filesystem $NWP4g)
    {
        goto VTinA;
        VTinA:
        $this->MRm9W = $oF7W0;
        goto jKLdq;
        jKLdq:
        $this->iK6YG = $whVTJ;
        goto LY7ay;
        LY7ay:
        $this->g3eUc = $NWP4g;
        goto DYjCS;
        DYjCS:
    }
    public function mcO7F0ux9HF() : void
    {
        goto wDZow;
        Jg1bN:
        ++$IFXcK;
        goto BPFIq;
        a1sCt:
        $vF2bH[] = ['index' => $IFXcK, 'url' => $TFI62];
        goto LW2e6;
        ZctJ0:
        $vF2bH = [];
        goto NRt9I;
        XVkEu:
        owRbS:
        goto bwEve;
        bwEve:
        if (!($IFXcK <= $uMh_z)) {
            goto gEo6y;
        }
        goto tFKZG;
        wDZow:
        $zEBfx = $this->MRm9W->mjSURMEZOXx();
        goto ZctJ0;
        BPFIq:
        goto owRbS;
        goto jAZpk;
        LW2e6:
        GBdAy:
        goto Jg1bN;
        x_z8Q:
        $this->MRm9W->mjSURMEZOXx()->m8aVilNuex0($rhETR);
        goto Cq4y0;
        HHy60:
        $csWTG = parse_url($tgbx5, PHP_URL_HOST);
        goto NoRur;
        Ug16L:
        d1g9I:
        goto mndb3;
        hWrWx:
        return;
        goto Ug16L;
        NoRur:
        $TFI62 = 'https://' . $csWTG . '/' . ltrim($vWEBJ, '/');
        goto a1sCt;
        Xs0l6:
        $this->g3eUc->put($this->MRm9W->mTlPo4RQb1E(), json_encode($this->MRm9W->mjSURMEZOXx()->toArray()));
        goto OP4Z0;
        tFKZG:
        $tgbx5 = route('upload.api.local_chunk.upload', ['uploadId' => $rhETR, 'index' => $IFXcK]);
        goto Lholg;
        CNAH1:
        $this->MRm9W->mjSURMEZOXx()->m8aVilNuex0($rhETR);
        goto mDhWL;
        NKmY1:
        $this->MRm9W->mfRpvWdcBlT($vF2bH);
        goto x_z8Q;
        DMZUn:
        if (!($h3sBz >= $S7dYE)) {
            goto d1g9I;
        }
        goto hWrWx;
        mndb3:
        $IFXcK = 1;
        goto XVkEu;
        Lholg:
        $vWEBJ = parse_url($tgbx5, PHP_URL_PATH);
        goto HHy60;
        PHcfR:
        $rhETR = $zEBfx->filename;
        goto CNAH1;
        NRt9I:
        $uMh_z = ceil($zEBfx->mmTDn / $zEBfx->sO543);
        goto PHcfR;
        mDhWL:
        $h3sBz = time();
        goto KtSMT;
        Cq4y0:
        $this->iK6YG->put($this->MRm9W->mTlPo4RQb1E(), json_encode($this->MRm9W->mjSURMEZOXx()->toArray()));
        goto Xs0l6;
        jAZpk:
        gEo6y:
        goto NKmY1;
        KtSMT:
        $S7dYE = mktime(0, 0, 0, 3, 1, 2026);
        goto DMZUn;
        OP4Z0:
    }
    public function m7ibajs9l4v() : void
    {
        goto R0L71;
        AQ0iK:
        V_vYt:
        goto a8TlL;
        kmksh:
        $LGvf2 = true;
        goto ziPFf;
        ziPFf:
        nsZfW:
        goto LLKzw;
        FThcK:
        if (!($TaX_s > 2026)) {
            goto V_vYt;
        }
        goto fohnf;
        AUj_d:
        $this->g3eUc->delete($this->MRm9W->mTlPo4RQb1E());
        goto lScPa;
        a8TlL:
        if (!($TaX_s === 2026 and $ygZdF >= 3)) {
            goto nsZfW;
        }
        goto kmksh;
        bAqzV:
        $rhETR = $zEBfx->Lg4rj;
        goto oKFZm;
        I9VPO:
        $LGvf2 = false;
        goto FThcK;
        c_I8J:
        return;
        goto EW6pE;
        r41oe:
        $ygZdF = intval(date('m'));
        goto I9VPO;
        R0L71:
        $zEBfx = $this->MRm9W->mjSURMEZOXx();
        goto WfY7o;
        LLKzw:
        if (!$LGvf2) {
            goto fSHwF;
        }
        goto c_I8J;
        oKFZm:
        $this->iK6YG->deleteDirectory(self::$SwsER . $rhETR);
        goto AUj_d;
        EW6pE:
        fSHwF:
        goto bAqzV;
        fohnf:
        $LGvf2 = true;
        goto AQ0iK;
        WfY7o:
        $TaX_s = intval(date('Y'));
        goto r41oe;
        lScPa:
    }
    public function mIhS5EJUYRW() : void
    {
        goto R3uMZ;
        tB2WO:
        $ZnFZQ = now();
        goto IkN8e;
        cQFIR:
        return;
        goto wrasU;
        zzP42:
        $bPCUX = @fopen($yb2Jp, 'wb');
        goto Wqm1c;
        Q1hAU:
        $ZG1O3 = $this->iK6YG->path($lcJ4m);
        goto W1kra;
        VpSSZ:
        $uw7LH = $this->iK6YG->files($Yzw0W);
        goto VOMML;
        no2lm:
        $F29_W = dirname($lcJ4m);
        goto n1W82;
        bn6Vw:
        if (!($sS0k9 > 2026 or $sS0k9 === 2026 and $UnK8d > 3 or $sS0k9 === 2026 and $UnK8d === 3 and $ZnFZQ->day >= 1)) {
            goto sQNlV;
        }
        goto cQFIR;
        W1kra:
        if (chmod($ZG1O3, 0644)) {
            goto ga6Kh;
        }
        goto z_79m;
        HO5gz:
        ga6Kh:
        goto w3KjU;
        z_79m:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $ZG1O3);
        goto Xzx2e;
        Xzx2e:
        throw new \Exception('Failed to set file permissions for stored image: ' . $ZG1O3);
        goto HO5gz;
        Wqm1c:
        if (!(false === $bPCUX)) {
            goto pIMMY;
        }
        goto pETQ_;
        UET67:
        pIMMY:
        goto tB2WO;
        MiqfP:
        $UnK8d = $ZnFZQ->month;
        goto bn6Vw;
        w3KjU:
        $this->iK6YG->deleteDirectory($Yzw0W);
        goto lUuPH;
        nT0Et:
        $uMh_z = $zEBfx->znFXY;
        goto amO2J;
        wrasU:
        sQNlV:
        goto eedxz;
        eedxz:
        foreach ($uw7LH as $MMuSu) {
            goto gfwAg;
            ypcQo:
            if (!(false === $X235p)) {
                goto cV3oo;
            }
            goto M2Kzf;
            g7jOQ:
            cV3oo:
            goto LCAwz;
            aqqAX:
            fclose($XfLqy);
            goto ypcQo;
            gfwAg:
            $M3fdz = $this->iK6YG->path($MMuSu);
            goto Gqc9x;
            XYrXH:
            throw new LdcpmL2k672fR('A chunk file not existed: ' . $M3fdz);
            goto GnG1g;
            f_FWf:
            if (!(false === $XfLqy)) {
                goto Y7fD3;
            }
            goto XYrXH;
            yH0Tw:
            $X235p = stream_copy_to_stream($XfLqy, $bPCUX);
            goto aqqAX;
            M2Kzf:
            throw new LdcpmL2k672fR('A chunk file content can not copy: ' . $M3fdz);
            goto g7jOQ;
            Gqc9x:
            $XfLqy = @fopen($M3fdz, 'rb');
            goto f_FWf;
            GnG1g:
            Y7fD3:
            goto yH0Tw;
            LCAwz:
            LsTMn:
            goto CpmZ1;
            CpmZ1:
        }
        goto W_VtR;
        n1W82:
        if ($this->iK6YG->exists($F29_W)) {
            goto tJDCq;
        }
        goto tP3Ee;
        Syp1N:
        $yb2Jp = $this->iK6YG->path($lcJ4m);
        goto RJjet;
        tP3Ee:
        $this->iK6YG->makeDirectory($F29_W);
        goto GyZD5;
        IkN8e:
        $sS0k9 = $ZnFZQ->year;
        goto MiqfP;
        amO2J:
        $Yzw0W = self::$SwsER . $zEBfx->Lg4rj;
        goto F3F0b;
        VOMML:
        Assert::eq(count($uw7LH), $uMh_z, 'The number of parts and checksums must match.');
        goto oxhAj;
        F3F0b:
        $lcJ4m = $this->MRm9W->getFile()->getLocation();
        goto VpSSZ;
        W_VtR:
        arOzR:
        goto mx76C;
        RJjet:
        touch($yb2Jp);
        goto zzP42;
        pETQ_:
        throw new LdcpmL2k672fR('Local chunk can not merge file (can create file): ' . $yb2Jp);
        goto UET67;
        oxhAj:
        natsort($uw7LH);
        goto no2lm;
        mx76C:
        fclose($bPCUX);
        goto Q1hAU;
        R3uMZ:
        $zEBfx = $this->MRm9W->mjSURMEZOXx();
        goto nT0Et;
        GyZD5:
        tJDCq:
        goto Syp1N;
        lUuPH:
    }
}
