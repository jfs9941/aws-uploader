<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\VhdgLYFn8a0ds;
use Jfs\Uploader\Exception\GYCnGhJDSoV27;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Presigned\HdpJMuzf2MANg;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class SRGM5YfCckw3z implements HdpJMuzf2MANg
{
    private static $IcbQF = 'chunks/';
    private $yK1hJ;
    private $IA8m0;
    private $mzEj7;
    public function __construct(VhdgLYFn8a0ds $Fr4mD, Filesystem $Rgxn3, Filesystem $z6qdY)
    {
        goto lJy5c;
        XN89G:
        $this->mzEj7 = $z6qdY;
        goto zcqmc;
        lJy5c:
        $this->yK1hJ = $Fr4mD;
        goto vixjk;
        vixjk:
        $this->IA8m0 = $Rgxn3;
        goto XN89G;
        zcqmc:
    }
    public function mCyzSeB6wKx() : void
    {
        goto mk7h1;
        uka9A:
        $J61wK = ceil($cor5J->l3D2R / $cor5J->VA2jP);
        goto cou7U;
        usigk:
        $ace3H[] = ['index' => $bc2Ij, 'url' => $QV1u6];
        goto w03V2;
        tIZrM:
        DYBA1:
        goto v5TDK;
        VOBfN:
        $tgHTl = route('upload.api.local_chunk.upload', ['uploadId' => $ytDYW, 'index' => $bc2Ij]);
        goto sL0bS;
        w03V2:
        N1zD_:
        goto KKP8K;
        LNWEl:
        $this->mzEj7->put($this->yK1hJ->mBtVCiNqqCF(), json_encode($this->yK1hJ->mMYcEvkVSg5()->toArray()));
        goto YcNuW;
        DQ4hk:
        $usETr = parse_url($tgHTl, PHP_URL_HOST);
        goto TDe6Q;
        TDe6Q:
        $QV1u6 = 'https://' . $usETr . '/' . ltrim($FlxOy, '/');
        goto usigk;
        CjI8K:
        La4nV:
        goto Asb_F;
        cou7U:
        $ytDYW = $cor5J->filename;
        goto TU1Zv;
        xV1KE:
        $this->yK1hJ->mMYcEvkVSg5()->m2yI097SE4n($ytDYW);
        goto RxBTx;
        Asb_F:
        $this->yK1hJ->mSYLEwNVAPm($ace3H);
        goto xV1KE;
        rqfJE:
        $bc2Ij = 1;
        goto tIZrM;
        KKP8K:
        ++$bc2Ij;
        goto ZQ6EI;
        v5TDK:
        if (!($bc2Ij <= $J61wK)) {
            goto La4nV;
        }
        goto VOBfN;
        nRLwB:
        $ace3H = [];
        goto uka9A;
        TU1Zv:
        $this->yK1hJ->mMYcEvkVSg5()->m2yI097SE4n($ytDYW);
        goto rqfJE;
        mk7h1:
        $cor5J = $this->yK1hJ->mMYcEvkVSg5();
        goto nRLwB;
        ZQ6EI:
        goto DYBA1;
        goto CjI8K;
        sL0bS:
        $FlxOy = parse_url($tgHTl, PHP_URL_PATH);
        goto DQ4hk;
        RxBTx:
        $this->IA8m0->put($this->yK1hJ->mBtVCiNqqCF(), json_encode($this->yK1hJ->mMYcEvkVSg5()->toArray()));
        goto LNWEl;
        YcNuW:
    }
    public function mx9xMkU9qJu() : void
    {
        goto Agq2G;
        oSbCO:
        $ytDYW = $cor5J->ZsH2f;
        goto erl0S;
        Agq2G:
        $cor5J = $this->yK1hJ->mMYcEvkVSg5();
        goto oSbCO;
        erl0S:
        $this->IA8m0->deleteDirectory(self::$IcbQF . $ytDYW);
        goto EHNwa;
        EHNwa:
        $this->mzEj7->delete($this->yK1hJ->mBtVCiNqqCF());
        goto gRvCe;
        gRvCe:
    }
    public function m0VtXeYPu88() : void
    {
        goto bhlbP;
        YH1HL:
        VddHp:
        goto v4SPf;
        FZpVU:
        Assert::eq(count($eImVC), $J61wK, 'The number of parts and checksums must match.');
        goto MvO5T;
        bhlbP:
        $cor5J = $this->yK1hJ->mMYcEvkVSg5();
        goto nb1Mw;
        v4SPf:
        $this->IA8m0->deleteDirectory($JrZU3);
        goto ViYGw;
        zvW3L:
        jTR7k:
        goto rvdRl;
        sQ4QA:
        x1zcN:
        goto dcRYf;
        eCCuJ:
        $Mmnin = dirname($XKoLn);
        goto DrBUy;
        liIOt:
        throw new GYCnGhJDSoV27('Local chunk can not merge file (can create file): ' . $JHgkt);
        goto sQ4QA;
        DrBUy:
        if ($this->IA8m0->exists($Mmnin)) {
            goto GrFEI;
        }
        goto ytdZ8;
        zvk_r:
        throw new \Exception('Failed to set file permissions for stored image: ' . $hJlxB);
        goto YH1HL;
        dzZw3:
        if (!(false === $yn32V)) {
            goto x1zcN;
        }
        goto liIOt;
        HfMMa:
        GrFEI:
        goto lO7lL;
        ytdZ8:
        $this->IA8m0->makeDirectory($Mmnin);
        goto HfMMa;
        toRN6:
        touch($JHgkt);
        goto JkpVv;
        rvdRl:
        fclose($yn32V);
        goto W1AHy;
        nb1Mw:
        $J61wK = $cor5J->xMQDK;
        goto DXQuG;
        DXQuG:
        $JrZU3 = self::$IcbQF . $cor5J->ZsH2f;
        goto MYVB0;
        JkpVv:
        $yn32V = @fopen($JHgkt, 'wb');
        goto dzZw3;
        dcRYf:
        foreach ($eImVC as $ly2cm) {
            goto al5oF;
            x9lww:
            throw new GYCnGhJDSoV27('A chunk file content can not copy: ' . $y89Jp);
            goto g9r7a;
            snGvG:
            xCOMc:
            goto TZLLB;
            keKYw:
            fclose($o5i2t);
            goto nXBaf;
            g9r7a:
            krKd4:
            goto gDUJx;
            DjHjQ:
            $o5i2t = @fopen($y89Jp, 'rb');
            goto WPH9j;
            TZLLB:
            $iMMna = stream_copy_to_stream($o5i2t, $yn32V);
            goto keKYw;
            al5oF:
            $y89Jp = $this->IA8m0->path($ly2cm);
            goto DjHjQ;
            WPH9j:
            if (!(false === $o5i2t)) {
                goto xCOMc;
            }
            goto Ve93k;
            gDUJx:
            KcWy3:
            goto Hk8EC;
            nXBaf:
            if (!(false === $iMMna)) {
                goto krKd4;
            }
            goto x9lww;
            Ve93k:
            throw new GYCnGhJDSoV27('A chunk file not existed: ' . $y89Jp);
            goto snGvG;
            Hk8EC:
        }
        goto zvW3L;
        MYVB0:
        $XKoLn = $this->yK1hJ->getFile()->getLocation();
        goto cYFKL;
        cYFKL:
        $eImVC = $this->IA8m0->files($JrZU3);
        goto FZpVU;
        vdPiy:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $hJlxB);
        goto zvk_r;
        MvO5T:
        natsort($eImVC);
        goto eCCuJ;
        lO7lL:
        $JHgkt = $this->IA8m0->path($XKoLn);
        goto toRN6;
        W1AHy:
        $hJlxB = $this->IA8m0->path($XKoLn);
        goto KB1wW;
        KB1wW:
        if (chmod($hJlxB, 0644)) {
            goto VddHp;
        }
        goto vdPiy;
        ViYGw:
    }
}
