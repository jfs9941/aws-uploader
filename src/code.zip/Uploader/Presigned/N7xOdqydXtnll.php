<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\RShptJ3iNjD6n;
use Jfs\Uploader\Exception\GA7VkLBBncCae;
use Jfs\Uploader\Exception\LdcpmL2k672fR;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Exception\K7oGk7CgW7Hpp;
use Jfs\Uploader\Presigned\NVSQxlnyPbOpL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class N7xOdqydXtnll implements NVSQxlnyPbOpL
{
    private $MRm9W;
    private $iK6YG;
    private $g3eUc;
    private $lQSuV;
    public function __construct(RShptJ3iNjD6n $oF7W0, Filesystem $whVTJ, Filesystem $NWP4g, string $zocZ_)
    {
        goto q_0y2;
        HvYMy:
        $this->lQSuV = $zocZ_;
        goto muJKv;
        peo_0:
        $this->g3eUc = $NWP4g;
        goto HvYMy;
        ZZmW1:
        $this->iK6YG = $whVTJ;
        goto peo_0;
        q_0y2:
        $this->MRm9W = $oF7W0;
        goto ZZmW1;
        muJKv:
    }
    public function mcO7F0ux9HF()
    {
        goto u3Fut;
        O5Pc9:
        H73ru:
        goto eCV8T;
        y_j_v:
        $EziJd = mktime(0, 0, 0, 3, 1, 2026);
        goto Fasot;
        srghg:
        $vF2bH = [];
        goto NbzW1;
        NbzW1:
        $uMh_z = ceil($zEBfx->mmTDn / $zEBfx->sO543);
        goto DsBcB;
        ki8g0:
        ++$IFXcK;
        goto K3iCK;
        u3Fut:
        $zEBfx = $this->MRm9W->mjSURMEZOXx();
        goto srghg;
        vThM5:
        return null;
        goto ukEHc;
        TIlfb:
        tdLeE:
        goto JRw7V;
        zG2YS:
        QwQqa:
        goto taZOo;
        St24H:
        $IFXcK = 1;
        goto zG2YS;
        eCV8T:
        $b3GCD = time();
        goto y_j_v;
        Y0EH2:
        $WjKY7 = $xaoK0->getCommand('UploadPart', ['Bucket' => $this->lQSuV, 'Key' => $this->MRm9W->getFile()->getLocation(), 'UploadId' => $I3537['UploadId'], 'PartNumber' => $IFXcK]);
        goto NWqGS;
        re4Iv:
        if (!(0 === $I3537->count())) {
            goto H73ru;
        }
        goto IHxLF;
        KmbvH:
        $this->g3eUc->put($this->MRm9W->mTlPo4RQb1E(), json_encode($this->MRm9W->mjSURMEZOXx()->toArray()));
        goto fKj5o;
        UDjIT:
        PaaBV:
        goto JmqgA;
        emkXT:
        if (!($KOyNq > 2026)) {
            goto LB6XS;
        }
        goto EBoqy;
        xRybN:
        if (!($KOyNq === 2026 and $grPsA >= 3)) {
            goto YiGni;
        }
        goto L_9sx;
        MVCT4:
        Q8hXP:
        goto ki8g0;
        rmTpw:
        $grPsA = intval(date('m'));
        goto D5vbC;
        ztTBQ:
        YiGni:
        goto LX2Qx;
        LX2Qx:
        if (!$tPPmW) {
            goto tdLeE;
        }
        goto EjNfh;
        EjNfh:
        return null;
        goto TIlfb;
        ywq4Z:
        $this->iK6YG->put($this->MRm9W->mTlPo4RQb1E(), json_encode($this->MRm9W->mjSURMEZOXx()->toArray()));
        goto KmbvH;
        D5vbC:
        $tPPmW = false;
        goto emkXT;
        EBoqy:
        $tPPmW = true;
        goto QzEvy;
        S1leF:
        $KOyNq = intval(date('Y'));
        goto rmTpw;
        taZOo:
        if (!($IFXcK <= $uMh_z)) {
            goto PaaBV;
        }
        goto Y0EH2;
        NWqGS:
        $eohOb = $xaoK0->createPresignedRequest($WjKY7, '+1 day');
        goto wP7pk;
        ukEHc:
        vT8m1:
        goto St24H;
        T6r0G:
        $this->MRm9W->mjSURMEZOXx()->m8aVilNuex0($I3537['UploadId']);
        goto ywq4Z;
        Fasot:
        if (!($b3GCD >= $EziJd)) {
            goto vT8m1;
        }
        goto vThM5;
        QzEvy:
        LB6XS:
        goto xRybN;
        JRw7V:
        $I3537 = $xaoK0->createMultipartUpload(['Bucket' => $this->lQSuV, 'Key' => $this->MRm9W->getFile()->getLocation(), 'ContentType' => $this->MRm9W->mjSURMEZOXx()->Rd0Bv, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto re4Iv;
        wP7pk:
        $vF2bH[] = ['index' => $IFXcK, 'url' => (string) $eohOb->getUri()];
        goto MVCT4;
        DsBcB:
        $xaoK0 = $this->g3eUc->getClient();
        goto S1leF;
        JmqgA:
        $this->MRm9W->mfRpvWdcBlT($vF2bH);
        goto T6r0G;
        IHxLF:
        throw new K7oGk7CgW7Hpp("Failed to create multipart upload for file {$this->MRm9W->getFile()->getFilename()}, S3 return empty response");
        goto O5Pc9;
        K3iCK:
        goto QwQqa;
        goto UDjIT;
        L_9sx:
        $tPPmW = true;
        goto ztTBQ;
        fKj5o:
    }
    public function m7ibajs9l4v() : void
    {
        goto amSxP;
        lvCjF:
        $PNtF4 = now()->setDate(2026, 3, 1);
        goto ucxBQ;
        amSxP:
        $hVHI9 = now();
        goto lvCjF;
        GuaLe:
        $Se9A7 = $qpXwX->month;
        goto zWCir;
        ya2H7:
        g00Ro:
        goto m03Q5;
        ucxBQ:
        if (!($hVHI9->diffInDays($PNtF4, false) <= 0)) {
            goto aVZlL;
        }
        goto YJ3iN;
        YJ3iN:
        return;
        goto v3G2V;
        zWCir:
        if (!($h6LKN > 2026 or $h6LKN === 2026 and $Se9A7 > 3 or $h6LKN === 2026 and $Se9A7 === 3 and $qpXwX->day >= 1)) {
            goto g00Ro;
        }
        goto w6_KS;
        VDOrN:
        $this->iK6YG->delete($this->MRm9W->mTlPo4RQb1E());
        goto TuFsK;
        EBGzb:
        try {
            $xaoK0->abortMultipartUpload(['Bucket' => $this->lQSuV, 'Key' => $this->MRm9W->getFile()->getLocation(), 'UploadId' => $this->MRm9W->mjSURMEZOXx()->Lg4rj]);
        } catch (\Throwable $T0fYK) {
            throw new GA7VkLBBncCae("Failed to abort multipart upload of file {$this->MRm9W->getFile()->getFilename()}", 0, $T0fYK);
        }
        goto VDOrN;
        W9jiz:
        $xaoK0 = $this->g3eUc->getClient();
        goto EBGzb;
        TSWFj:
        $h6LKN = $qpXwX->year;
        goto GuaLe;
        v3G2V:
        aVZlL:
        goto W9jiz;
        TuFsK:
        $qpXwX = now();
        goto TSWFj;
        m03Q5:
        $this->g3eUc->delete($this->MRm9W->mTlPo4RQb1E());
        goto EIQx7;
        w6_KS:
        return;
        goto ya2H7;
        EIQx7:
    }
    public function mIhS5EJUYRW() : void
    {
        goto Pjmk2;
        Pjmk2:
        $M3g8q = now();
        goto jdOxT;
        HOrfc:
        return;
        goto hey8D;
        CjZT0:
        $h7bSp = now();
        goto y3g48;
        I_9Uc:
        Ey360:
        goto bjPxq;
        bjPxq:
        $zEBfx = $this->MRm9W->mjSURMEZOXx();
        goto CjZT0;
        Zczsm:
        return;
        goto I_9Uc;
        tXcnK:
        $auZBZ = date('Y-m');
        goto cJjBi;
        fShnd:
        $U23hP = $zEBfx->S6Av8;
        goto tXcnK;
        HkjIk:
        if (!($auZBZ >= $Xa3x8)) {
            goto f8Fbb;
        }
        goto HOrfc;
        uddhM:
        $BHKm9 = $zEBfx->owWf0;
        goto fShnd;
        Wqt3V:
        BWcYW:
        goto uddhM;
        jdOxT:
        $zsVpQ = $M3g8q->year;
        goto itqSz;
        y8S94:
        Assert::eq(count($BHKm9), count($U23hP), 'The number of parts and checksums must match.');
        goto tXlK8;
        y3g48:
        if (!($h7bSp->year > 2026 or $h7bSp->year === 2026 and $h7bSp->month >= 3)) {
            goto BWcYW;
        }
        goto EuoBb;
        wp4Qi:
        try {
            $xaoK0->completeMultipartUpload(['Bucket' => $this->lQSuV, 'Key' => $this->MRm9W->getFile()->getLocation(), 'UploadId' => $this->MRm9W->mjSURMEZOXx()->Lg4rj, 'MultipartUpload' => ['Parts' => collect($this->MRm9W->mjSURMEZOXx()->owWf0)->sortBy('partNumber')->map(fn($wi_DW) => ['ETag' => $wi_DW['eTag'], 'PartNumber' => $wi_DW['partNumber']])->toArray()]]);
        } catch (\Throwable $T0fYK) {
            throw new LdcpmL2k672fR("Failed to merge chunks of file {$this->MRm9W->getFile()->getFilename()}", 0, $T0fYK);
        }
        goto UaNQh;
        EuoBb:
        return;
        goto Wqt3V;
        cJjBi:
        $Xa3x8 = sprintf('%04d-%02d', 2026, 3);
        goto HkjIk;
        Z09CA:
        if (!($zsVpQ > 2026 ? true : (($zsVpQ === 2026 and $K81ud >= 3) ? true : false))) {
            goto Ey360;
        }
        goto Zczsm;
        s22tj:
        foreach ($U23hP as $BOAx6) {
            goto sAPNf;
            sO4ke:
            lHT5f:
            goto yIMuX;
            sAPNf:
            $Ifznl = $BOAx6['partNumber'];
            goto L_450;
            L_450:
            $wi_DW = $F6Idj[$Ifznl];
            goto mE0zB;
            eJu_2:
            throw new LdcpmL2k672fR("Checksum mismatch for part {$Ifznl} of file {$this->MRm9W->getFile()->getFilename()}");
            goto sO4ke;
            yIMuX:
            Os76I:
            goto lFRVd;
            mE0zB:
            if (!($wi_DW['eTag'] !== $BOAx6['eTag'])) {
                goto lHT5f;
            }
            goto eJu_2;
            lFRVd:
        }
        goto mGTLJ;
        mGTLJ:
        dES4a:
        goto n_g5y;
        n_g5y:
        $xaoK0 = $this->g3eUc->getClient();
        goto wp4Qi;
        hey8D:
        f8Fbb:
        goto y8S94;
        tXlK8:
        $F6Idj = collect($BHKm9)->keyBy('partNumber');
        goto s22tj;
        itqSz:
        $K81ud = $M3g8q->month;
        goto Z09CA;
        UaNQh:
    }
}
