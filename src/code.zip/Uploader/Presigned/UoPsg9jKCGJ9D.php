<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Jfs\Uploader\Core\PLi20pZSTTBHP;
use Jfs\Uploader\Exception\TATK2XYTfrhu3;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Presigned\TR9OKRLZozZUP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class UoPsg9jKCGJ9D implements TR9OKRLZozZUP
{
    private static $WJpwp = 'chunks/';
    private $Ym0Fe;
    private $pXh9P;
    private $Tfy0l;
    public function __construct(PLi20pZSTTBHP $k0UDg, Filesystem $TWZho, Filesystem $bnvNm)
    {
        goto iBnT2;
        HOVAl:
        $this->Tfy0l = $bnvNm;
        goto EanDR;
        iBnT2:
        $this->Ym0Fe = $k0UDg;
        goto ZEXG_;
        ZEXG_:
        $this->pXh9P = $TWZho;
        goto HOVAl;
        EanDR:
    }
    public function mJyhvrcvYWY() : void
    {
        goto MW8XQ;
        oI5NU:
        $this->Tfy0l->put($this->Ym0Fe->m9Cbs65gEpK(), json_encode($this->Ym0Fe->mzbGvZW3SMF()->toArray()));
        goto dc4s0;
        bhP9_:
        $IXoHj = 1;
        goto YwkXW;
        gBkiW:
        $nyh3w = [];
        goto aFqC1;
        Zpo_e:
        $this->Ym0Fe->m3uvAsmvocJ($nyh3w);
        goto wuctf;
        ijzgI:
        $nyh3w[] = ['index' => $IXoHj, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $bXjPU, 'index' => $IXoHj])];
        goto Uwl45;
        keKv_:
        ++$IXoHj;
        goto aZmZz;
        ROvJs:
        $this->Ym0Fe->mzbGvZW3SMF()->mcz6MDxZF1x($bXjPU);
        goto bhP9_;
        L2eVC:
        AWA6a:
        goto Zpo_e;
        FNIDu:
        $this->pXh9P->put($this->Ym0Fe->m9Cbs65gEpK(), json_encode($this->Ym0Fe->mzbGvZW3SMF()->toArray()));
        goto oI5NU;
        XeWde:
        if (!($IXoHj <= $ruRfJ)) {
            goto AWA6a;
        }
        goto ijzgI;
        aZmZz:
        goto EZYHm;
        goto L2eVC;
        h8Fo1:
        $bXjPU = $bsvnL->filename;
        goto ROvJs;
        MW8XQ:
        $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
        goto gBkiW;
        aFqC1:
        $ruRfJ = ceil($bsvnL->P_XkO / $bsvnL->SWeqX);
        goto h8Fo1;
        Uwl45:
        GYhll:
        goto keKv_;
        YwkXW:
        EZYHm:
        goto XeWde;
        wuctf:
        $this->Ym0Fe->mzbGvZW3SMF()->mcz6MDxZF1x($bXjPU);
        goto FNIDu;
        dc4s0:
    }
    public function mxuapcvaHCE() : void
    {
        goto Wk1Ua;
        Wk1Ua:
        $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
        goto wC_Sf;
        WtbjL:
        $this->Tfy0l->delete($this->Ym0Fe->m9Cbs65gEpK());
        goto nbEbg;
        SaN_q:
        $this->pXh9P->deleteDirectory(self::$WJpwp . $bXjPU);
        goto WtbjL;
        wC_Sf:
        $bXjPU = $bsvnL->cUKik;
        goto SaN_q;
        nbEbg:
    }
    public function mGCUSudE8Jd() : void
    {
        goto L8CwO;
        GxmaE:
        Nrjcr:
        goto uEyZX;
        SZWxU:
        E_Noe:
        goto XrpIN;
        amN2d:
        natsort($qih_X);
        goto X4NT4;
        fHald:
        if (!(false === $A67v4)) {
            goto E_Noe;
        }
        goto y5cMH;
        SmAKR:
        $ruRfJ = $bsvnL->zsyS6;
        goto GDQ21;
        uEyZX:
        $OLNvA = $this->pXh9P->path($vZKZX);
        goto gGwZ_;
        UDuOD:
        if ($this->pXh9P->exists($xvLDa)) {
            goto Nrjcr;
        }
        goto MOeqR;
        Dqkly:
        $vZKZX = $this->Ym0Fe->getFile()->getLocation();
        goto x6tPP;
        y5cMH:
        throw new TATK2XYTfrhu3('Local chunk can not merge file (can create file): ' . $OLNvA);
        goto SZWxU;
        X4NT4:
        $xvLDa = dirname($vZKZX);
        goto UDuOD;
        lKHcw:
        $A67v4 = @fopen($OLNvA, 'wb');
        goto fHald;
        zf5xz:
        A8O3p:
        goto pE6sa;
        pE6sa:
        $this->pXh9P->deleteDirectory($qypJF);
        goto RudPL;
        GDQ21:
        $qypJF = self::$WJpwp . $bsvnL->cUKik;
        goto Dqkly;
        XrpIN:
        foreach ($qih_X as $D3KOT) {
            goto LahYT;
            A1hez:
            jsKhA:
            goto qTyNG;
            qTyNG:
            $grCw0 = stream_copy_to_stream($pw6U3, $A67v4);
            goto vX6wE;
            MfNHX:
            throw new TATK2XYTfrhu3('A chunk file not existed: ' . $TfX_U);
            goto A1hez;
            vX6wE:
            fclose($pw6U3);
            goto oSkC7;
            uAyxe:
            throw new TATK2XYTfrhu3('A chunk file content can not copy: ' . $TfX_U);
            goto pCfYX;
            w53eT:
            mYQz5:
            goto En0sI;
            LahYT:
            $TfX_U = $this->pXh9P->path($D3KOT);
            goto HKwv2;
            oSkC7:
            if (!(false === $grCw0)) {
                goto aLB0T;
            }
            goto uAyxe;
            HKwv2:
            $pw6U3 = @fopen($TfX_U, 'rb');
            goto LCBZT;
            pCfYX:
            aLB0T:
            goto w53eT;
            LCBZT:
            if (!(false === $pw6U3)) {
                goto jsKhA;
            }
            goto MfNHX;
            En0sI:
        }
        goto F_ScQ;
        MOeqR:
        $this->pXh9P->makeDirectory($xvLDa);
        goto GxmaE;
        qL_fb:
        throw new \Exception('Failed to set file permissions for stored image: ' . $wEqZD);
        goto zf5xz;
        NOxgP:
        if (chmod($wEqZD, 0644)) {
            goto A8O3p;
        }
        goto s2c29;
        L8CwO:
        $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
        goto SmAKR;
        A1pMe:
        fclose($A67v4);
        goto gH_R1;
        x6tPP:
        $qih_X = $this->pXh9P->files($qypJF);
        goto BoElt;
        BoElt:
        Assert::eq(count($qih_X), $ruRfJ, 'The number of parts and checksums must match.');
        goto amN2d;
        s2c29:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $wEqZD);
        goto qL_fb;
        gH_R1:
        $wEqZD = $this->pXh9P->path($vZKZX);
        goto NOxgP;
        gGwZ_:
        touch($OLNvA);
        goto lKHcw;
        F_ScQ:
        AgYvB:
        goto A1pMe;
        RudPL:
    }
}
