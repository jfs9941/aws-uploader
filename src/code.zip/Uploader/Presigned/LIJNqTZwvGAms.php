<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\El1EbMj6pC2Ez;
use Jfs\Uploader\Exception\Sul3oaOuiRwuC;
use Jfs\Uploader\Exception\P1cBJVt5vzahC;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Exception\Da2ZeO2m1zxYD;
use Jfs\Uploader\Presigned\J2QclvQdBQfV8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class LIJNqTZwvGAms implements J2QclvQdBQfV8
{
    private $liA4i;
    private $FHcNr;
    private $p5xeF;
    private $n4bxV;
    public function __construct(El1EbMj6pC2Ez $tzb77, Filesystem $z279S, Filesystem $AA8Bi, string $dxOEL)
    {
        goto vFGLZ;
        mB1fC:
        $this->FHcNr = $z279S;
        goto SmqMQ;
        vFGLZ:
        $this->liA4i = $tzb77;
        goto mB1fC;
        SmqMQ:
        $this->p5xeF = $AA8Bi;
        goto iSwiS;
        iSwiS:
        $this->n4bxV = $dxOEL;
        goto R07XK;
        R07XK:
    }
    public function mYhjxA8RCUq()
    {
        goto Llmk9;
        vJmLB:
        s9tEY:
        goto wIRwz;
        SXrgN:
        OYnEA:
        goto hz90Q;
        I2wy4:
        $P7bmZ = $this->p5xeF->getClient();
        goto EXGtY;
        SjsWV:
        $D5Cak = ceil($eSKpN->TgkQ_ / $eSKpN->R2hLK);
        goto I2wy4;
        EXGtY:
        $FhmWg = $P7bmZ->createMultipartUpload(['Bucket' => $this->n4bxV, 'Key' => $this->liA4i->getFile()->getLocation(), 'ContentType' => $this->liA4i->mFBfBagZ9x6()->W0WCt, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto zgB0d;
        zntHb:
        $this->FHcNr->put($this->liA4i->mrwx9qum9K0(), json_encode($this->liA4i->mFBfBagZ9x6()->toArray()));
        goto HNN26;
        wIRwz:
        $this->liA4i->mSKQ6IJo5al($HXn5w);
        goto bFlTi;
        Wkq3N:
        $ZXvon = 1;
        goto SXrgN;
        JDe11:
        goto OYnEA;
        goto vJmLB;
        cE23U:
        $HXn5w = [];
        goto SjsWV;
        Llmk9:
        $eSKpN = $this->liA4i->mFBfBagZ9x6();
        goto cE23U;
        az0no:
        tF_BZ:
        goto Wkq3N;
        hz90Q:
        if (!($ZXvon <= $D5Cak)) {
            goto s9tEY;
        }
        goto UgPN9;
        zgB0d:
        if (!(0 === $FhmWg->count())) {
            goto tF_BZ;
        }
        goto cZq6W;
        HNN26:
        $this->p5xeF->put($this->liA4i->mrwx9qum9K0(), json_encode($this->liA4i->mFBfBagZ9x6()->toArray()));
        goto xerzW;
        UgPN9:
        $N0Aoh = $P7bmZ->getCommand('UploadPart', ['Bucket' => $this->n4bxV, 'Key' => $this->liA4i->getFile()->getLocation(), 'UploadId' => $FhmWg['UploadId'], 'PartNumber' => $ZXvon]);
        goto gy0pM;
        b_VQr:
        $HXn5w[] = ['index' => $ZXvon, 'url' => (string) $Y8ByN->getUri()];
        goto UmREt;
        cZq6W:
        throw new Da2ZeO2m1zxYD("Failed to create multipart upload for file {$this->liA4i->getFile()->getFilename()}, S3 return empty response");
        goto az0no;
        bFlTi:
        $this->liA4i->mFBfBagZ9x6()->mLQU01cj3Al($FhmWg['UploadId']);
        goto zntHb;
        gy0pM:
        $Y8ByN = $P7bmZ->createPresignedRequest($N0Aoh, '+1 day');
        goto b_VQr;
        UmREt:
        nDu7Z:
        goto r9N59;
        r9N59:
        ++$ZXvon;
        goto JDe11;
        xerzW:
    }
    public function mE0rB6JIYIW() : void
    {
        goto zLHsu;
        Wqs60:
        $this->p5xeF->delete($this->liA4i->mrwx9qum9K0());
        goto A0qME;
        MKRNx:
        $this->FHcNr->delete($this->liA4i->mrwx9qum9K0());
        goto Wqs60;
        zLHsu:
        $P7bmZ = $this->p5xeF->getClient();
        goto sbgZT;
        sbgZT:
        try {
            $P7bmZ->abortMultipartUpload(['Bucket' => $this->n4bxV, 'Key' => $this->liA4i->getFile()->getLocation(), 'UploadId' => $this->liA4i->mFBfBagZ9x6()->zFYsq]);
        } catch (\Throwable $X2LoG) {
            throw new Sul3oaOuiRwuC("Failed to abort multipart upload of file {$this->liA4i->getFile()->getFilename()}", 0, $X2LoG);
        }
        goto MKRNx;
        A0qME:
    }
    public function muBMwFMNOXz() : void
    {
        goto BKm9T;
        DFaPF:
        Assert::eq(count($oDHkw), count($Da8dG), 'The number of parts and checksums must match.');
        goto UeA6e;
        pJB2G:
        foreach ($Da8dG as $VuxRn) {
            goto XhDkI;
            slYri:
            throw new P1cBJVt5vzahC("Checksum mismatch for part {$N1PpZ} of file {$this->liA4i->getFile()->getFilename()}");
            goto PNha_;
            lGWPV:
            $XTIt9 = $LONSb[$N1PpZ];
            goto NDLZM;
            PNha_:
            EuT_5:
            goto d271D;
            NDLZM:
            if (!($XTIt9['eTag'] !== $VuxRn['eTag'])) {
                goto EuT_5;
            }
            goto slYri;
            XhDkI:
            $N1PpZ = $VuxRn['partNumber'];
            goto lGWPV;
            d271D:
            mmvIR:
            goto ZUg5Q;
            ZUg5Q:
        }
        goto oCZ3z;
        UeA6e:
        $LONSb = collect($oDHkw)->keyBy('partNumber');
        goto pJB2G;
        BKm9T:
        $eSKpN = $this->liA4i->mFBfBagZ9x6();
        goto zTkkG;
        Yq1o8:
        $P7bmZ = $this->p5xeF->getClient();
        goto TaSpD;
        TaSpD:
        try {
            $P7bmZ->completeMultipartUpload(['Bucket' => $this->n4bxV, 'Key' => $this->liA4i->getFile()->getLocation(), 'UploadId' => $this->liA4i->mFBfBagZ9x6()->zFYsq, 'MultipartUpload' => ['Parts' => collect($this->liA4i->mFBfBagZ9x6()->BGkIZ)->sortBy('partNumber')->map(fn($XTIt9) => ['ETag' => $XTIt9['eTag'], 'PartNumber' => $XTIt9['partNumber']])->toArray()]]);
        } catch (\Throwable $X2LoG) {
            throw new P1cBJVt5vzahC("Failed to merge chunks of file {$this->liA4i->getFile()->getFilename()}", 0, $X2LoG);
        }
        goto LzB2f;
        ox1Fm:
        $Da8dG = $eSKpN->PuNRE;
        goto DFaPF;
        zTkkG:
        $oDHkw = $eSKpN->BGkIZ;
        goto ox1Fm;
        oCZ3z:
        PTksP:
        goto Yq1o8;
        LzB2f:
    }
}
