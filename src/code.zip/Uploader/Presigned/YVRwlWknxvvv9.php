<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Jfs\Uploader\Core\JNVd14WbS7J31;
use Jfs\Uploader\Exception\GKgw1ouaNHk5q;
use Jfs\Uploader\Exception\G23CmOAeiHqkm;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Exception\RDqSw0CxqBp0v;
use Jfs\Uploader\Presigned\QBfShGMnlw2Jt;
use Illuminate\Contracts\Filesystem\Filesystem;
use Webmozart\Assert\Assert;
class YVRwlWknxvvv9 implements QBfShGMnlw2Jt
{
    private $Ph2Bh;
    private $IdG3S;
    private $m1Mjp;
    private $XWRu9;
    public function __construct(JNVd14WbS7J31 $G3hwE, Filesystem $ftmEm, Filesystem $ZIdyH, string $Ba5m3)
    {
        goto l_hHt;
        yD4f6:
        $this->m1Mjp = $ZIdyH;
        goto CYQiA;
        KDmaT:
        $this->IdG3S = $ftmEm;
        goto yD4f6;
        CYQiA:
        $this->XWRu9 = $Ba5m3;
        goto D7E8i;
        l_hHt:
        $this->Ph2Bh = $G3hwE;
        goto KDmaT;
        D7E8i:
    }
    public function mX63RYpwJf8()
    {
        goto DRlBc;
        B8JGm:
        ++$tOIWk;
        goto ATsgz;
        g0YUE:
        if (!(0 === $fNMAX->count())) {
            goto U3Vfv;
        }
        goto V3vKN;
        dAiL5:
        $this->Ph2Bh->m8Hi8VWicy3()->mWwcN6VbLRG($fNMAX['UploadId']);
        goto TfZ0O;
        Bx7q2:
        kZh2Q:
        goto cWZo5;
        ATsgz:
        goto kZh2Q;
        goto GvRnw;
        JfRW0:
        $this->m1Mjp->put($this->Ph2Bh->mmNRlgopoZ5(), json_encode($this->Ph2Bh->m8Hi8VWicy3()->toArray()));
        goto VAZKw;
        hvZcd:
        $Sw6uL = [];
        goto OK01l;
        vPw1R:
        $this->Ph2Bh->mdcD4JdtpGn($Sw6uL);
        goto dAiL5;
        nprsh:
        $k9JGl = $CBoNT->getCommand('UploadPart', ['Bucket' => $this->XWRu9, 'Key' => $this->Ph2Bh->getFile()->getLocation(), 'UploadId' => $fNMAX['UploadId'], 'PartNumber' => $tOIWk]);
        goto DEvKp;
        CqPyt:
        $CBoNT = $this->m1Mjp->getClient();
        goto NhRIo;
        TgnNa:
        U3Vfv:
        goto kx2HT;
        tJg3I:
        $Sw6uL[] = ['index' => $tOIWk, 'url' => (string) $HsqQX->getUri()];
        goto g1UR2;
        NhRIo:
        $fNMAX = $CBoNT->createMultipartUpload(['Bucket' => $this->XWRu9, 'Key' => $this->Ph2Bh->getFile()->getLocation(), 'ContentType' => $this->Ph2Bh->m8Hi8VWicy3()->NhJsW, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto g0YUE;
        kx2HT:
        $tOIWk = 1;
        goto Bx7q2;
        cWZo5:
        if (!($tOIWk <= $IftTu)) {
            goto Ay4Fc;
        }
        goto nprsh;
        DRlBc:
        $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
        goto hvZcd;
        TfZ0O:
        $this->IdG3S->put($this->Ph2Bh->mmNRlgopoZ5(), json_encode($this->Ph2Bh->m8Hi8VWicy3()->toArray()));
        goto JfRW0;
        OK01l:
        $IftTu = ceil($W8N2W->BjjEq / $W8N2W->Z119c);
        goto CqPyt;
        V3vKN:
        throw new RDqSw0CxqBp0v("Failed to create multipart upload for file {$this->Ph2Bh->getFile()->getFilename()}, S3 return empty response");
        goto TgnNa;
        GvRnw:
        Ay4Fc:
        goto vPw1R;
        DEvKp:
        $HsqQX = $CBoNT->createPresignedRequest($k9JGl, '+1 day');
        goto tJg3I;
        g1UR2:
        VZhPa:
        goto B8JGm;
        VAZKw:
    }
    public function mDAg6JsqB6v() : void
    {
        goto LBBr3;
        fJncw:
        $this->m1Mjp->delete($this->Ph2Bh->mmNRlgopoZ5());
        goto vj7p6;
        LBBr3:
        $CBoNT = $this->m1Mjp->getClient();
        goto WCjei;
        GvUr_:
        $this->IdG3S->delete($this->Ph2Bh->mmNRlgopoZ5());
        goto fJncw;
        WCjei:
        try {
            $CBoNT->abortMultipartUpload(['Bucket' => $this->XWRu9, 'Key' => $this->Ph2Bh->getFile()->getLocation(), 'UploadId' => $this->Ph2Bh->m8Hi8VWicy3()->MSlst]);
        } catch (\Throwable $L0fOk) {
            throw new GKgw1ouaNHk5q("Failed to abort multipart upload of file {$this->Ph2Bh->getFile()->getFilename()}", 0, $L0fOk);
        }
        goto GvUr_;
        vj7p6:
    }
    public function mNBOH0CMzl3() : void
    {
        goto hCVxd;
        DhOzI:
        $F8ggY = collect($p4mmG)->keyBy('partNumber');
        goto K4Qzp;
        bv83o:
        $p4mmG = $W8N2W->vb8UL;
        goto Wtkpy;
        Wtkpy:
        $gFfDX = $W8N2W->uWPVa;
        goto dNd9p;
        vZ0aA:
        PjX6L:
        goto H6eTY;
        H6eTY:
        $CBoNT = $this->m1Mjp->getClient();
        goto De7Ni;
        hCVxd:
        $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
        goto bv83o;
        K4Qzp:
        foreach ($gFfDX as $NkWo1) {
            goto Evya1;
            CwS1F:
            DZ1fk:
            goto PJ9TG;
            Evya1:
            $A6hee = $NkWo1['partNumber'];
            goto iKSVw;
            iKSVw:
            $AyIBs = $F8ggY[$A6hee];
            goto dYvCA;
            PJ9TG:
            wCuyw:
            goto jH0qh;
            dYvCA:
            if (!($AyIBs['eTag'] !== $NkWo1['eTag'])) {
                goto DZ1fk;
            }
            goto iFEAS;
            iFEAS:
            throw new G23CmOAeiHqkm("Checksum mismatch for part {$A6hee} of file {$this->Ph2Bh->getFile()->getFilename()}");
            goto CwS1F;
            jH0qh:
        }
        goto vZ0aA;
        De7Ni:
        try {
            $CBoNT->completeMultipartUpload(['Bucket' => $this->XWRu9, 'Key' => $this->Ph2Bh->getFile()->getLocation(), 'UploadId' => $this->Ph2Bh->m8Hi8VWicy3()->MSlst, 'MultipartUpload' => ['Parts' => collect($this->Ph2Bh->m8Hi8VWicy3()->vb8UL)->sortBy('partNumber')->map(fn($AyIBs) => ['ETag' => $AyIBs['eTag'], 'PartNumber' => $AyIBs['partNumber']])->toArray()]]);
        } catch (\Throwable $L0fOk) {
            throw new G23CmOAeiHqkm("Failed to merge chunks of file {$this->Ph2Bh->getFile()->getFilename()}", 0, $L0fOk);
        }
        goto h6rKY;
        dNd9p:
        Assert::eq(count($p4mmG), count($gFfDX), 'The number of parts and checksums must match.');
        goto DhOzI;
        h6rKY:
    }
}
