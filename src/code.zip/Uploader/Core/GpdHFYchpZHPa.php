<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Illuminate\Database\Eloquent\Model;
abstract  class GpdHFYchpZHPa extends Model implements OfMUIxZzii9Zu
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mO5zuxZvsQL() : bool
    {
        goto XALlt;
        sEg8W:
        BFtBa:
        goto z2KFn;
        O_C2j:
        return true;
        goto sEg8W;
        XALlt:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto BFtBa;
        }
        goto O_C2j;
        z2KFn:
        return !$this->m3nGXg4DL5c();
        goto ywQIN;
        ywQIN:
    }
    protected function m3nGXg4DL5c() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
