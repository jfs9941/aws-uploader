<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
final class XXOVbK7SeD5pn
{
    public $filename;
    public $qt3V6;
    public $AY7Co;
    public $tZcBC;
    public $C25S5;
    public $WSVrm;
    public $bPUco;
    public $status;
    public $Kv03s;
    public $Uyx84;
    public $h8PS2 = 's3';
    public $z9PGG = [];
    public function __construct($iS0Bq, $JZtiC, $fSCPa, $R5Mtg, $EiBY9, $bPa7l, $k1xoW, $ny2mX, $z4wME, $NB12w, $EWvJO = 's3', $PoqoM = [])
    {
        goto fInIC;
        Umsfh:
        $this->status = $ny2mX;
        goto j9xAV;
        E8F6S:
        $this->h8PS2 = $EWvJO;
        goto mWsnW;
        K37iG:
        $this->AY7Co = $fSCPa;
        goto NmWkO;
        sAgp4:
        $this->Uyx84 = $NB12w;
        goto E8F6S;
        mWsnW:
        $this->z9PGG = $PoqoM;
        goto X36F3;
        Ju97q:
        $this->qt3V6 = $JZtiC;
        goto K37iG;
        NmWkO:
        $this->tZcBC = $R5Mtg;
        goto tgHCe;
        SVImY:
        $this->bPUco = $k1xoW;
        goto Umsfh;
        fInIC:
        $this->filename = $iS0Bq;
        goto Ju97q;
        Abdjj:
        $this->WSVrm = $bPa7l;
        goto SVImY;
        tgHCe:
        $this->C25S5 = $EiBY9;
        goto Abdjj;
        j9xAV:
        $this->Kv03s = $z4wME;
        goto sAgp4;
        X36F3:
    }
    private static function mJhbNPNuwzN() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mIfQryc8UHW() : array
    {
        return array_flip(self::mJhbNPNuwzN());
    }
    public function toArray() : array
    {
        $JYx02 = self::mJhbNPNuwzN();
        return [$JYx02['filename'] => $this->filename, $JYx02['fileExtension'] => $this->qt3V6, $JYx02['mimeType'] => $this->AY7Co, $JYx02['fileSize'] => $this->tZcBC, $JYx02['chunkSize'] => $this->C25S5, $JYx02['checksums'] => $this->WSVrm, $JYx02['totalChunk'] => $this->bPUco, $JYx02['status'] => $this->status, $JYx02['userId'] => $this->Kv03s, $JYx02['uploadId'] => $this->Uyx84, $JYx02['driver'] => $this->h8PS2, $JYx02['parts'] => $this->z9PGG];
    }
    public static function mSQpjbj4OST(array $E1O3k) : self
    {
        $xWt4h = array_flip(self::mIfQryc8UHW());
        return new self($E1O3k[$xWt4h['filename']] ?? $E1O3k['filename'] ?? '', $E1O3k[$xWt4h['fileExtension']] ?? $E1O3k['fileExtension'] ?? '', $E1O3k[$xWt4h['mimeType']] ?? $E1O3k['mimeType'] ?? '', $E1O3k[$xWt4h['fileSize']] ?? $E1O3k['fileSize'] ?? 0, $E1O3k[$xWt4h['chunkSize']] ?? $E1O3k['chunkSize'] ?? 0, $E1O3k[$xWt4h['checksums']] ?? $E1O3k['checksums'] ?? [], $E1O3k[$xWt4h['totalChunk']] ?? $E1O3k['totalChunk'] ?? 0, $E1O3k[$xWt4h['status']] ?? $E1O3k['status'] ?? 0, $E1O3k[$xWt4h['userId']] ?? $E1O3k['userId'] ?? 0, $E1O3k[$xWt4h['uploadId']] ?? $E1O3k['uploadId'] ?? '', $E1O3k[$xWt4h['driver']] ?? $E1O3k['driver'] ?? 's3', $E1O3k[$xWt4h['parts']] ?? $E1O3k['parts'] ?? []);
    }
    public static function m5NrbL3FbvV($p6yvD) : self
    {
        goto tz4Hb;
        GWZqG:
        s5QDs:
        goto ZU3_l;
        ZU3_l:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto hMQPJ;
        jw1a_:
        return self::mSQpjbj4OST($p6yvD);
        goto GWZqG;
        tz4Hb:
        if (!(isset($p6yvD['fn']) || isset($p6yvD['fe']))) {
            goto s5QDs;
        }
        goto jw1a_;
        hMQPJ:
    }
    public function msZ9gs4HQR8(string $NB12w) : void
    {
        $this->Uyx84 = $NB12w;
    }
    public function mylZ97z2J2s(array $PoqoM) : void
    {
        $this->z9PGG = $PoqoM;
    }
    public static function mc9dxCBRxnZ($nbWJE, $jmob9, $ke97a, $z4wME, $EiBY9, $bPa7l, $EWvJO)
    {
        return new self($nbWJE->getFilename(), $nbWJE->getExtension(), $jmob9, $ke97a, $EiBY9, $bPa7l, count($bPa7l), H7dtWZ2h5WAty::UPLOADING, $z4wME, 0, $EWvJO, []);
    }
    public static function mujQ08d9CEo($DWjir)
    {
        return 'metadata/' . $DWjir . '.json';
    }
    public function mdf0USGjs5G()
    {
        return 's3' === $this->h8PS2 ? KkaUVP3OQvOtp::S3 : KkaUVP3OQvOtp::LOCAL;
    }
}
