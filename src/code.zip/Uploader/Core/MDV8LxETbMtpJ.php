<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Contracts\Bvfii9tMROJRp;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\Traits\SvjIu3InVS06e;
use Jfs\Uploader\Core\Traits\YXqL8Vu76ZyNK;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Service\PYjKYaymEKJyi;
class MDV8LxETbMtpJ extends IeEvjRaj1LMmG implements VuQzRNCSz5bHK
{
    use SvjIu3InVS06e;
    use YXqL8Vu76ZyNK;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $uXjFZ, string $n13FM) : self
    {
        goto s5sw5;
        ZB_Ij:
        return $yeTJJ;
        goto qSaen;
        s5sw5:
        $yeTJJ = new self(['id' => $uXjFZ, 'type' => $n13FM, 'status' => ZP6Ky842t6y9Y::UPLOADING]);
        goto qHtHf;
        qHtHf:
        $yeTJJ->m651SlcakeY(ZP6Ky842t6y9Y::UPLOADING);
        goto ZB_Ij;
        qSaen:
    }
    public function getView() : array
    {
        $V2cKr = app(Bvfii9tMROJRp::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $V2cKr->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $V2cKr->resolveThumbnail($this)];
    }
    public static function m1wo7FHZaCv(IeEvjRaj1LMmG $UmLJ2) : MDV8LxETbMtpJ
    {
        goto youVh;
        cWgR_:
        HgPjr:
        goto P_NmR;
        Yd3Ep:
        return $UmLJ2;
        goto cWgR_;
        P_NmR:
        return (new MDV8LxETbMtpJ())->fill($UmLJ2->getAttributes());
        goto L_225;
        youVh:
        if (!$UmLJ2 instanceof MDV8LxETbMtpJ) {
            goto HgPjr;
        }
        goto Yd3Ep;
        L_225:
    }
}
