<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
final class QUscYuYxMDsuz
{
    public $filename;
    public $iYo0H;
    public $i3osF;
    public $msg3v;
    public $hHmny;
    public $GGRG2;
    public $wgp7g;
    public $status;
    public $etR94;
    public $HkGuv;
    public $rbCCx = 's3';
    public $S_YVI = [];
    public function __construct($CdCMa, $YoNIV, $XSIXc, $Ku3nn, $DTo1w, $QS28K, $e1EOt, $nr4H3, $jVUTM, $MSFCE, $PAfML = 's3', $u2DUU = [])
    {
        goto PXAf3;
        sYcc0:
        $this->S_YVI = $u2DUU;
        goto c7xBa;
        Q86oF:
        $this->iYo0H = $YoNIV;
        goto EXZRQ;
        ods7l:
        $this->GGRG2 = $QS28K;
        goto sKWqO;
        H2bjX:
        $this->HkGuv = $MSFCE;
        goto xyOxf;
        EXZRQ:
        $this->i3osF = $XSIXc;
        goto nSzKX;
        jR2bv:
        $this->hHmny = $DTo1w;
        goto ods7l;
        uWyzi:
        $this->status = $nr4H3;
        goto GD006;
        nSzKX:
        $this->msg3v = $Ku3nn;
        goto jR2bv;
        PXAf3:
        $this->filename = $CdCMa;
        goto Q86oF;
        GD006:
        $this->etR94 = $jVUTM;
        goto H2bjX;
        sKWqO:
        $this->wgp7g = $e1EOt;
        goto uWyzi;
        xyOxf:
        $this->rbCCx = $PAfML;
        goto sYcc0;
        c7xBa:
    }
    private static function mybcJX1y8nT() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mAXb5QV8T5A() : array
    {
        return array_flip(self::mybcJX1y8nT());
    }
    public function toArray() : array
    {
        $YuRAG = self::mybcJX1y8nT();
        return [$YuRAG['filename'] => $this->filename, $YuRAG['fileExtension'] => $this->iYo0H, $YuRAG['mimeType'] => $this->i3osF, $YuRAG['fileSize'] => $this->msg3v, $YuRAG['chunkSize'] => $this->hHmny, $YuRAG['checksums'] => $this->GGRG2, $YuRAG['totalChunk'] => $this->wgp7g, $YuRAG['status'] => $this->status, $YuRAG['userId'] => $this->etR94, $YuRAG['uploadId'] => $this->HkGuv, $YuRAG['driver'] => $this->rbCCx, $YuRAG['parts'] => $this->S_YVI];
    }
    public static function mcOR9MnBlDQ(array $Dpd03) : self
    {
        $KguS2 = array_flip(self::mAXb5QV8T5A());
        return new self($Dpd03[$KguS2['filename']] ?? $Dpd03['filename'] ?? '', $Dpd03[$KguS2['fileExtension']] ?? $Dpd03['fileExtension'] ?? '', $Dpd03[$KguS2['mimeType']] ?? $Dpd03['mimeType'] ?? '', $Dpd03[$KguS2['fileSize']] ?? $Dpd03['fileSize'] ?? 0, $Dpd03[$KguS2['chunkSize']] ?? $Dpd03['chunkSize'] ?? 0, $Dpd03[$KguS2['checksums']] ?? $Dpd03['checksums'] ?? [], $Dpd03[$KguS2['totalChunk']] ?? $Dpd03['totalChunk'] ?? 0, $Dpd03[$KguS2['status']] ?? $Dpd03['status'] ?? 0, $Dpd03[$KguS2['userId']] ?? $Dpd03['userId'] ?? 0, $Dpd03[$KguS2['uploadId']] ?? $Dpd03['uploadId'] ?? '', $Dpd03[$KguS2['driver']] ?? $Dpd03['driver'] ?? 's3', $Dpd03[$KguS2['parts']] ?? $Dpd03['parts'] ?? []);
    }
    public static function mEDJWbnim9M($PPpaE) : self
    {
        goto DWEOz;
        iSYOv:
        return self::mcOR9MnBlDQ($PPpaE);
        goto oaI6Y;
        DWEOz:
        if (!(isset($PPpaE['fn']) || isset($PPpaE['fe']))) {
            goto B1Fv0;
        }
        goto iSYOv;
        KkrQu:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto PMahl;
        oaI6Y:
        B1Fv0:
        goto KkrQu;
        PMahl:
    }
    public function m1Z5hvqmFrV(string $MSFCE) : void
    {
        $this->HkGuv = $MSFCE;
    }
    public function mB7eRZmk2xa(array $u2DUU) : void
    {
        $this->S_YVI = $u2DUU;
    }
    public static function mc35KG5oSlP($TFA4Z, $rA1FC, $fQkDA, $jVUTM, $DTo1w, $QS28K, $PAfML)
    {
        return new self($TFA4Z->getFilename(), $TFA4Z->getExtension(), $rA1FC, $fQkDA, $DTo1w, $QS28K, count($QS28K), Q5pXt73hTeTVP::UPLOADING, $jVUTM, 0, $PAfML, []);
    }
    public static function mmwRyL53HQ1($ElvKF)
    {
        return 'metadata/' . $ElvKF . '.json';
    }
    public function mCI3IPXqltF()
    {
        return 's3' === $this->rbCCx ? I2Tze5VZcqaXS::S3 : I2Tze5VZcqaXS::LOCAL;
    }
}
