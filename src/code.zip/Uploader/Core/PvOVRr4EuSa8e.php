<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Contracts\SRErb8bXZXjuL;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\Traits\Av20P07H9bvdh;
use Jfs\Uploader\Core\Traits\VnPCfppm663dI;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Service\K2TtTNcFSFguA;
class PvOVRr4EuSa8e extends NCmZ7rMVMWyvC implements LKF23eYmlDs0w
{
    use Av20P07H9bvdh;
    use VnPCfppm663dI;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $gQlRM, string $UEzod) : self
    {
        goto l6Roo;
        whNMb:
        return $f3bsh;
        goto SuD0V;
        TJUFe:
        $f3bsh->mXDdmT111J7(GlPuUJKmzwUJ9::UPLOADING);
        goto whNMb;
        l6Roo:
        $f3bsh = new self(['id' => $gQlRM, 'type' => $UEzod, 'status' => GlPuUJKmzwUJ9::UPLOADING]);
        goto TJUFe;
        SuD0V:
    }
    public function getView() : array
    {
        $j1FXT = app(SRErb8bXZXjuL::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $j1FXT->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $j1FXT->resolveThumbnail($this)];
    }
    public static function mvzwsEX7FcR(NCmZ7rMVMWyvC $ldT2t) : PvOVRr4EuSa8e
    {
        goto hqLzd;
        t5EMo:
        nwhHP:
        goto S8SdI;
        hqLzd:
        if (!$ldT2t instanceof PvOVRr4EuSa8e) {
            goto nwhHP;
        }
        goto h00M1;
        S8SdI:
        return (new PvOVRr4EuSa8e())->fill($ldT2t->getAttributes());
        goto PPuIC;
        h00M1:
        return $ldT2t;
        goto t5EMo;
        PPuIC:
    }
}
