<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Contracts\GuNvSDjrDhnZX;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\Traits\Rr9MHzXLd8EvR;
use Jfs\Uploader\Core\Traits\XGoBOvpn4TlTz;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
class BG2FRpwGrKqJx extends KFe2ZCctciwsA implements GCZ2vyVNpj70n
{
    use Rr9MHzXLd8EvR;
    use XGoBOvpn4TlTz;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $VfJ3M, string $xY26M) : self
    {
        goto E3fT6;
        LO8Nb:
        return $Zpy0I;
        goto Lq10B;
        sycYL:
        $Zpy0I->mlS5irobHNA(EpMPhiTVzNYqA::UPLOADING);
        goto LO8Nb;
        E3fT6:
        $Zpy0I = new self(['id' => $VfJ3M, 'type' => $xY26M, 'status' => EpMPhiTVzNYqA::UPLOADING]);
        goto sycYL;
        Lq10B:
    }
    public function width() : ?int
    {
        goto Ej_52;
        w4TDn:
        return null;
        goto lKa0H;
        A101p:
        LNlE5:
        goto w4TDn;
        fdMPC:
        if (!$kc4oX) {
            goto LNlE5;
        }
        goto nL1hV;
        nL1hV:
        return $kc4oX;
        goto A101p;
        Ej_52:
        $kc4oX = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto fdMPC;
        lKa0H:
    }
    public function height() : ?int
    {
        goto UNn3D;
        RAtuR:
        return $lIw1W;
        goto YqOjh;
        YqOjh:
        K5A0u:
        goto o42V1;
        o42V1:
        return null;
        goto xQFCa;
        UNn3D:
        $lIw1W = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto jxyUl;
        jxyUl:
        if (!$lIw1W) {
            goto K5A0u;
        }
        goto RAtuR;
        xQFCa:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($Zpy0I) {
            goto CGl7s;
            Q0yzN:
            if (!($Yarth['thumbnail'] || $Yarth['hls_path'])) {
                goto vLDca;
            }
            goto bqUFl;
            bqUFl:
            BG2FRpwGrKqJx::where('parent_id', $Zpy0I->getAttribute('id'))->update(['thumbnail' => $Zpy0I->getAttributes()['thumbnail'], 'hls_path' => $Zpy0I->getAttributes()['hls_path']]);
            goto NtNxo;
            NtNxo:
            vLDca:
            goto bwYsC;
            h0lGR:
            return;
            goto FVZSy;
            ceP7Q:
            if (!(!array_key_exists('thumbnail', $Yarth) && !array_key_exists('hls_path', $Yarth))) {
                goto binxX;
            }
            goto h0lGR;
            CGl7s:
            $Yarth = $Zpy0I->getDirty();
            goto ceP7Q;
            FVZSy:
            binxX:
            goto Q0yzN;
            bwYsC:
        });
    }
    public function m5F2lwOBL1s()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m8ExJYweMXa()
    {
        return $this->getAttribute('id');
    }
    public function mHNglQRBQMN() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto uWtEb;
        Kjhdh:
        hk3bZ:
        goto twef0;
        twef0:
        $L5ARZ['player_url'] = $rEnse->resolvePathForHlsVideo($this, true);
        goto qsRgE;
        EX0GU:
        if ($this->getAttribute('hls_path')) {
            goto hk3bZ;
        }
        goto ebzbw;
        wbu2L:
        $L5ARZ['thumbnail'] = $rEnse->resolveThumbnail($this);
        goto GrUmX;
        GrUmX:
        return $L5ARZ;
        goto SRv8C;
        kf145:
        goto AQGSD;
        goto Kjhdh;
        KKNqn:
        $L5ARZ = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $rEnse->resolvePath($this, $this->getAttribute('driver'))];
        goto EX0GU;
        uWtEb:
        $rEnse = app(GuNvSDjrDhnZX::class);
        goto KKNqn;
        qsRgE:
        AQGSD:
        goto wbu2L;
        ebzbw:
        $L5ARZ['player_url'] = $rEnse->resolvePath($this, $this->getAttribute('driver'));
        goto kf145;
        SRv8C:
    }
    public function getThumbnails()
    {
        goto De75m;
        cPyVh:
        return array_map(function ($cOdCv) use($rEnse) {
            return $rEnse->resolvePath($cOdCv);
        }, $GLN14);
        goto SRXrr;
        FJswU:
        $rEnse = app(GuNvSDjrDhnZX::class);
        goto cPyVh;
        De75m:
        $GLN14 = $this->getAttribute('generated_previews') ?? [];
        goto FJswU;
        SRXrr:
    }
    public static function mTuCzzVbYKr(KFe2ZCctciwsA $Hz32I) : BG2FRpwGrKqJx
    {
        goto CSDT2;
        Xc9wD:
        return (new BG2FRpwGrKqJx())->fill($Hz32I->getAttributes());
        goto xw39j;
        CSDT2:
        if (!$Hz32I instanceof BG2FRpwGrKqJx) {
            goto kPenQ;
        }
        goto OV6od;
        OV6od:
        return $Hz32I;
        goto pqtU8;
        pqtU8:
        kPenQ:
        goto Xc9wD;
        xw39j:
    }
}
