<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\VCKF0xK25vLxq;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
final class IVTeeOwHA8NRW
{
    public $filename;
    public $CVNc9;
    public $xghyZ;
    public $lIbbz;
    public $myLYQ;
    public $XBduP;
    public $GdvAI;
    public $status;
    public $lnN7k;
    public $zLXWJ;
    public $BlJMK = 's3';
    public $lC91s = [];
    public function __construct($Ga2A8, $chXuT, $TGa6W, $h_1Yg, $rQwH5, $I1ivv, $pdD0o, $PZR7N, $PFtUr, $HXXez, $DzFpv = 's3', $WuWD8 = [])
    {
        goto CYnE8;
        zLa28:
        $this->myLYQ = $rQwH5;
        goto BnzgX;
        CDSj3:
        $this->status = $PZR7N;
        goto IRJLF;
        CYnE8:
        $this->filename = $Ga2A8;
        goto tHpiU;
        yl7Cn:
        $this->xghyZ = $TGa6W;
        goto fHI06;
        IRJLF:
        $this->lnN7k = $PFtUr;
        goto MQd4v;
        MQd4v:
        $this->zLXWJ = $HXXez;
        goto sYt_Y;
        BnzgX:
        $this->XBduP = $I1ivv;
        goto Y4ck0;
        sYt_Y:
        $this->BlJMK = $DzFpv;
        goto I645W;
        Y4ck0:
        $this->GdvAI = $pdD0o;
        goto CDSj3;
        I645W:
        $this->lC91s = $WuWD8;
        goto LcVeB;
        tHpiU:
        $this->CVNc9 = $chXuT;
        goto yl7Cn;
        fHI06:
        $this->lIbbz = $h_1Yg;
        goto zLa28;
        LcVeB:
    }
    private static function mruOY7NWiQ5() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function muJTazXOIZb() : array
    {
        return array_flip(self::mruOY7NWiQ5());
    }
    public function toArray() : array
    {
        $J98N7 = self::mruOY7NWiQ5();
        return [$J98N7['filename'] => $this->filename, $J98N7['fileExtension'] => $this->CVNc9, $J98N7['mimeType'] => $this->xghyZ, $J98N7['fileSize'] => $this->lIbbz, $J98N7['chunkSize'] => $this->myLYQ, $J98N7['checksums'] => $this->XBduP, $J98N7['totalChunk'] => $this->GdvAI, $J98N7['status'] => $this->status, $J98N7['userId'] => $this->lnN7k, $J98N7['uploadId'] => $this->zLXWJ, $J98N7['driver'] => $this->BlJMK, $J98N7['parts'] => $this->lC91s];
    }
    public static function m4kH9GDSRbg(array $rweMv) : self
    {
        $D5ar3 = array_flip(self::muJTazXOIZb());
        return new self($rweMv[$D5ar3['filename']] ?? $rweMv['filename'] ?? '', $rweMv[$D5ar3['fileExtension']] ?? $rweMv['fileExtension'] ?? '', $rweMv[$D5ar3['mimeType']] ?? $rweMv['mimeType'] ?? '', $rweMv[$D5ar3['fileSize']] ?? $rweMv['fileSize'] ?? 0, $rweMv[$D5ar3['chunkSize']] ?? $rweMv['chunkSize'] ?? 0, $rweMv[$D5ar3['checksums']] ?? $rweMv['checksums'] ?? [], $rweMv[$D5ar3['totalChunk']] ?? $rweMv['totalChunk'] ?? 0, $rweMv[$D5ar3['status']] ?? $rweMv['status'] ?? 0, $rweMv[$D5ar3['userId']] ?? $rweMv['userId'] ?? 0, $rweMv[$D5ar3['uploadId']] ?? $rweMv['uploadId'] ?? '', $rweMv[$D5ar3['driver']] ?? $rweMv['driver'] ?? 's3', $rweMv[$D5ar3['parts']] ?? $rweMv['parts'] ?? []);
    }
    public static function m9H3IbCYV7f($hG2LG) : self
    {
        goto I983u;
        x8Uc7:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto Cyi8D;
        I983u:
        if (!(isset($hG2LG['fn']) || isset($hG2LG['fe']))) {
            goto tvEJp;
        }
        goto ugRZm;
        ugRZm:
        return self::m4kH9GDSRbg($hG2LG);
        goto K62qa;
        K62qa:
        tvEJp:
        goto x8Uc7;
        Cyi8D:
    }
    public function mJvdHrWcN2f(string $HXXez) : void
    {
        $this->zLXWJ = $HXXez;
    }
    public function m26TEtnpzx5(array $WuWD8) : void
    {
        $this->lC91s = $WuWD8;
    }
    public static function mf8osksPllX($ezBDN, $b98KV, $tTjy3, $PFtUr, $rQwH5, $I1ivv, $DzFpv)
    {
        return new self($ezBDN->getFilename(), $ezBDN->getExtension(), $b98KV, $tTjy3, $rQwH5, $I1ivv, count($I1ivv), N4CY6qDTBAjPa::UPLOADING, $PFtUr, 0, $DzFpv, []);
    }
    public static function mtYQ0zAThf7($eXur0)
    {
        return 'metadata/' . $eXur0 . '.json';
    }
    public function m7gGHc9dD7O()
    {
        return 's3' === $this->BlJMK ? VCKF0xK25vLxq::S3 : VCKF0xK25vLxq::LOCAL;
    }
}
