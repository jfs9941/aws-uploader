<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Contracts\FK56xL1HuXbff;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\Traits\CAyWR6lPHLTW2;
use Jfs\Uploader\Core\Traits\NnqCGr9M8kJNm;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Service\DdwCOXXHdXXTK;
class KZbAaRxCqNUr3 extends HtHJXf7xellNX implements H1Ax5lj0mb7kw
{
    use CAyWR6lPHLTW2;
    use NnqCGr9M8kJNm;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $tbOMu, string $g88NJ) : self
    {
        goto yP9uu;
        yP9uu:
        $VSbOm = new self(['id' => $tbOMu, 'type' => $g88NJ, 'status' => IOOvAXAyKHLW2::UPLOADING]);
        goto H16rR;
        lEbDZ:
        return $VSbOm;
        goto ri70U;
        H16rR:
        $VSbOm->mMTZSzpDsC7(IOOvAXAyKHLW2::UPLOADING);
        goto lEbDZ;
        ri70U:
    }
    public function getView() : array
    {
        $QWY0L = app(FK56xL1HuXbff::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $QWY0L->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $QWY0L->resolveThumbnail($this)];
    }
    public static function muMVvYVlXv7(HtHJXf7xellNX $I6_Gg) : KZbAaRxCqNUr3
    {
        goto gNqMZ;
        yYElA:
        return (new KZbAaRxCqNUr3())->fill($I6_Gg->getAttributes());
        goto IXaKF;
        RELc1:
        pI5Nd:
        goto yYElA;
        V9Jr0:
        return $I6_Gg;
        goto RELc1;
        gNqMZ:
        if (!$I6_Gg instanceof KZbAaRxCqNUr3) {
            goto pI5Nd;
        }
        goto V9Jr0;
        IXaKF:
    }
}
