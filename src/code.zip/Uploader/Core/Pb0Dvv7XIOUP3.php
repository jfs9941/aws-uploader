<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\Observer\M0i8E0oGmuEYD;
use backup\Uploader\Core\AxmsWfJr0hDcu;
use backup\Uploader\Core\Traits\Bjzrau20Tp0as;
use backup\Uploader\Core\Traits\Fk7u5grtM5kGF;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Exception\Y86LODF9txYbT;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Exception\HXV6iIC92kwG6;
use backup\Uploader\Service\IJhG5F6LYY6Bm;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Pb0Dvv7XIOUP3 implements VnrpqIkXJe1mn
{
    use Bjzrau20Tp0as;
    use Fk7u5grtM5kGF;
    private $FKXaC;
    private function __construct($eVZrJ, $UEDUm)
    {
        $this->i31Dp = $eVZrJ;
        $this->RHF8i = $UEDUm;
    }
    private function mWM99dfhOt6(string $ClLup, $UEDUm, $s49oM, bool $dJrSm = false) : void
    {
        $this->mJOjnVefuIu(new M0i8E0oGmuEYD($this, $UEDUm, $s49oM, $ClLup, $dJrSm));
    }
    public function getFile()
    {
        return $this->i31Dp;
    }
    public function mEXA8ft76kA(array $UVpRu) : void
    {
        $this->FKXaC = $UVpRu;
    }
    public function mbBXZP0P4f9() : void
    {
        $this->mKOiTrzpM4V(Aetm2HiFuJE34::UPLOADING);
    }
    public function meHZvCsm6LD() : void
    {
        $this->mKOiTrzpM4V(Aetm2HiFuJE34::UPLOADED);
    }
    public function mj70zs86IlD() : void
    {
        $this->mKOiTrzpM4V(Aetm2HiFuJE34::PROCESSING);
    }
    public function mM9Bg0ljJBz() : void
    {
        $this->mKOiTrzpM4V(Aetm2HiFuJE34::FINISHED);
    }
    public function mlQSGoMVhvh() : void
    {
        $this->mKOiTrzpM4V(Aetm2HiFuJE34::ABORTED);
    }
    public function m9pzqYgcboi() : array
    {
        return $this->FKXaC;
    }
    public static function mDPNDjYdhNx(string $EQQae, $bG8XI, $FP6ih, $ClLup) : self
    {
        goto fXC5P;
        Ilym3:
        $iG9RC->mV7ZhSMguWB(Aetm2HiFuJE34::UPLOADING);
        goto z1K9t;
        IzsUu:
        $iG9RC = new self($eVZrJ, $bG8XI);
        goto hGe_v;
        z1K9t:
        return $iG9RC->mZuxAX7tvkm();
        goto UtwJI;
        fXC5P:
        $eVZrJ = App::make(IJhG5F6LYY6Bm::class)->m9LaZIEPg91(AxmsWfJr0hDcu::m2gHLHqC92C($EQQae));
        goto IzsUu;
        hGe_v:
        $iG9RC->mWM99dfhOt6($ClLup, $bG8XI, $FP6ih);
        goto Ilym3;
        UtwJI:
    }
    public static function mbt3puUz4JF($eVZrJ, $UEDUm, $s49oM, $ClLup, $dJrSm = false) : self
    {
        goto Oukbk;
        IFdOA:
        return $iG9RC;
        goto vlK8G;
        Oukbk:
        $iG9RC = new self($eVZrJ, $UEDUm);
        goto MhvEe;
        h6oHy:
        $iG9RC->mV7ZhSMguWB(Aetm2HiFuJE34::UPLOADING);
        goto IFdOA;
        MhvEe:
        $iG9RC->mWM99dfhOt6($ClLup, $UEDUm, $s49oM, $dJrSm);
        goto h6oHy;
        vlK8G:
    }
}
