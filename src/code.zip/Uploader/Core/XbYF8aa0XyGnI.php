<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Core\Traits\RYD8pJSplDz0G;
use Jfs\Uploader\Core\Traits\RmjpXY01QWbl2;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Service\Df64o7d8ZEcB5;
class XbYF8aa0XyGnI extends CZj9PTf9Cv9Eq implements VH6naaofz5IuZ
{
    use RYD8pJSplDz0G;
    use RmjpXY01QWbl2;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $Vuk0i, string $RKAxu) : self
    {
        goto LXeMn;
        LXeMn:
        $FGBix = new self(['id' => $Vuk0i, 'type' => $RKAxu, 'status' => EPmxqTVp5luXc::UPLOADING]);
        goto Pie3f;
        Pie3f:
        $FGBix->mkv7RuyOFPh(EPmxqTVp5luXc::UPLOADING);
        goto ulYOz;
        ulYOz:
        return $FGBix;
        goto jxjB9;
        jxjB9:
    }
    public function getView() : array
    {
        $hlmkv = app(BEzZsfn3kKkr3::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $hlmkv->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $hlmkv->resolveThumbnail($this)];
    }
    public static function mExCgmTcBRJ(CZj9PTf9Cv9Eq $dCHQU) : XbYF8aa0XyGnI
    {
        goto QM3B1;
        jMV3G:
        return (new XbYF8aa0XyGnI())->fill($dCHQU->getAttributes());
        goto zOgFB;
        QM3B1:
        if (!$dCHQU instanceof XbYF8aa0XyGnI) {
            goto VVkGl;
        }
        goto zqb0L;
        zqb0L:
        return $dCHQU;
        goto dfizD;
        dfizD:
        VVkGl:
        goto jMV3G;
        zOgFB:
    }
}
