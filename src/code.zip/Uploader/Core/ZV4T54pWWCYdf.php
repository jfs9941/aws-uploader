<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\Observer\D45tzYjcbr4gm;
use Jfs\Uploader\Core\UH9DV4SMWOQOz;
use Jfs\Uploader\Core\Traits\OVY1lz7Dzl4N6;
use Jfs\Uploader\Core\Traits\TZStemugh45tx;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Exception\GRAfJLmbKXpoS;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Exception\HaB2yhTzru90X;
use Jfs\Uploader\Service\W99ztYaFerRwn;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class ZV4T54pWWCYdf implements Zv4WZkC8rwgvt
{
    use OVY1lz7Dzl4N6;
    use TZStemugh45tx;
    private $CwWeU;
    private function __construct($bwI0g, $jxMWP)
    {
        $this->iN_s5 = $bwI0g;
        $this->z70LI = $jxMWP;
    }
    private function mdVsi7AgVUv(string $XbR1L, $jxMWP, $ft7kk, bool $lop45 = false) : void
    {
        $this->meWhUv2FYYU(new D45tzYjcbr4gm($this, $jxMWP, $ft7kk, $XbR1L, $lop45));
    }
    public function getFile()
    {
        return $this->iN_s5;
    }
    public function m8J20ggo7Cc(array $eW9nl) : void
    {
        $this->CwWeU = $eW9nl;
    }
    public function m9GWlIIZuqp() : void
    {
        $this->mRU2TqSePcC(WSEQ88VDOa3X0::UPLOADING);
    }
    public function m9vqCYmtYSU() : void
    {
        $this->mRU2TqSePcC(WSEQ88VDOa3X0::UPLOADED);
    }
    public function mxcejM77ulZ() : void
    {
        $this->mRU2TqSePcC(WSEQ88VDOa3X0::PROCESSING);
    }
    public function mFR82ZHgRp6() : void
    {
        $this->mRU2TqSePcC(WSEQ88VDOa3X0::FINISHED);
    }
    public function mCchs2jmG1F() : void
    {
        $this->mRU2TqSePcC(WSEQ88VDOa3X0::ABORTED);
    }
    public function m1mdlzVkhvL() : array
    {
        return $this->CwWeU;
    }
    public static function mDxA2W83Gl8(string $tu00C, $epqkv, $zeM4q, $XbR1L) : self
    {
        goto KBTEh;
        KBTEh:
        $bwI0g = App::make(W99ztYaFerRwn::class)->morhAThw6LY(UH9DV4SMWOQOz::mKCPcRTfEeG($tu00C));
        goto mAyWr;
        XpIme:
        $MsSdU->mA93Wx3HDpN(WSEQ88VDOa3X0::UPLOADING);
        goto m3O9N;
        m3O9N:
        return $MsSdU->mq2UUo8ghQN();
        goto xIvKZ;
        mAyWr:
        $MsSdU = new self($bwI0g, $epqkv);
        goto eURnE;
        eURnE:
        $MsSdU->mdVsi7AgVUv($XbR1L, $epqkv, $zeM4q);
        goto XpIme;
        xIvKZ:
    }
    public static function mTT9iwJ2I5B($bwI0g, $jxMWP, $ft7kk, $XbR1L, $lop45 = false) : self
    {
        goto Fdg9J;
        m679T:
        $MsSdU->mA93Wx3HDpN(WSEQ88VDOa3X0::UPLOADING);
        goto I3vkE;
        Fdg9J:
        $MsSdU = new self($bwI0g, $jxMWP);
        goto T3un6;
        T3un6:
        $MsSdU->mdVsi7AgVUv($XbR1L, $jxMWP, $ft7kk, $lop45);
        goto m679T;
        I3vkE:
        return $MsSdU;
        goto R7nGT;
        R7nGT:
    }
}
