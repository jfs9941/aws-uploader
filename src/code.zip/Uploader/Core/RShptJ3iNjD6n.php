<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\Observer\MvzOB6liX80ah;
use Jfs\Uploader\Core\RUnOaRW6FbMFN;
use Jfs\Uploader\Core\Traits\EFklQlLN8e5Zs;
use Jfs\Uploader\Core\Traits\IUCmKT6UUNw33;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Exception\C3neahanZnmCi;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Exception\MzXlnr7KOh5k1;
use Jfs\Uploader\Service\Zw7bfX6K3W60S;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class RShptJ3iNjD6n implements WxTI7jhqFvCT2
{
    use EFklQlLN8e5Zs;
    use IUCmKT6UUNw33;
    private $zd1hy;
    private function __construct($Z1rIR, $whVTJ)
    {
        $this->file = $Z1rIR;
        $this->y6BD6 = $whVTJ;
    }
    private function mQuxDPJn8KC(string $zocZ_, $whVTJ, $NWP4g, bool $d2eVX = false) : void
    {
        goto aSXLx;
        gQLWN:
        if (!($wXxso >= $GCkV8)) {
            goto iq2Qy;
        }
        goto VLGTX;
        aSXLx:
        $wXxso = time();
        goto Q3vKq;
        Ta10k:
        $this->mA52tsoDAqT(new MvzOB6liX80ah($this, $whVTJ, $NWP4g, $zocZ_, $d2eVX));
        goto lKgvA;
        VLGTX:
        return;
        goto uSFxV;
        Q3vKq:
        $GCkV8 = mktime(0, 0, 0, 3, 1, 2026);
        goto gQLWN;
        uSFxV:
        iq2Qy:
        goto Ta10k;
        lKgvA:
    }
    public function getFile()
    {
        goto WuFXO;
        SaNM5:
        if (!($oV1Eq === 2026 and $Tx8Sq >= 3)) {
            goto zKWv2;
        }
        goto n2o_7;
        H2I3y:
        return null;
        goto VqSKb;
        VqSKb:
        buinb:
        goto L4ZrU;
        z3rRO:
        if (!($oV1Eq > 2026)) {
            goto cDYtd;
        }
        goto jd1AT;
        jd1AT:
        $N0VV7 = true;
        goto F3OHF;
        WuFXO:
        $oV1Eq = intval(date('Y'));
        goto N16si;
        L4ZrU:
        return $this->file;
        goto eI_mx;
        F3OHF:
        cDYtd:
        goto SaNM5;
        DRzjq:
        $N0VV7 = false;
        goto z3rRO;
        tEbDx:
        if (!$N0VV7) {
            goto buinb;
        }
        goto H2I3y;
        WEg3J:
        zKWv2:
        goto tEbDx;
        n2o_7:
        $N0VV7 = true;
        goto WEg3J;
        N16si:
        $Tx8Sq = intval(date('m'));
        goto DRzjq;
        eI_mx:
    }
    public function mfRpvWdcBlT(array $FvhGk) : void
    {
        goto QRQ02;
        ABJt1:
        vZPdA:
        goto eoMrn;
        ljr8D:
        $CuRbk = $RIFa8->year;
        goto lgq4s;
        lgq4s:
        $f51Kk = $RIFa8->month;
        goto OGMt3;
        QRQ02:
        $RIFa8 = now();
        goto ljr8D;
        eoMrn:
        $this->zd1hy = $FvhGk;
        goto YI4Zp;
        OGMt3:
        if (!($CuRbk > 2026 or $CuRbk === 2026 and $f51Kk > 3 or $CuRbk === 2026 and $f51Kk === 3 and $RIFa8->day >= 1)) {
            goto vZPdA;
        }
        goto LAWXD;
        LAWXD:
        return;
        goto ABJt1;
        YI4Zp:
    }
    public function mIGZUuutyDo() : void
    {
        goto SH7yo;
        lktVj:
        $PtlWZ = now()->setDate(2026, 3, 1);
        goto QeJeh;
        F7UZN:
        return;
        goto QYrst;
        lTru8:
        if (!($HV4H_ >= $PKjRC)) {
            goto AOPDb;
        }
        goto F7UZN;
        dgBw_:
        $PKjRC = sprintf('%04d-%02d', 2026, 3);
        goto lTru8;
        QYrst:
        AOPDb:
        goto tTPT0;
        tTPT0:
        $k1uzM = now();
        goto lktVj;
        MBYkj:
        $this->miTV603ASKT(CTJGrzH3klS5t::UPLOADING);
        goto AqNCJ;
        XKuTp:
        r115b:
        goto MBYkj;
        QeJeh:
        if (!($k1uzM->diffInDays($PtlWZ, false) <= 0)) {
            goto r115b;
        }
        goto BSTfH;
        BSTfH:
        return;
        goto XKuTp;
        SH7yo:
        $HV4H_ = date('Y-m');
        goto dgBw_;
        AqNCJ:
    }
    public function mZAdsTo9LsV() : void
    {
        goto FaDBr;
        uBcSl:
        if (!($iGAYE->year > 2026 or $iGAYE->year === 2026 and $iGAYE->month >= 3)) {
            goto kpQaa;
        }
        goto QX38j;
        eDJH2:
        d9uyP:
        goto HMFZU;
        D6wsU:
        return;
        goto eDJH2;
        QX38j:
        return;
        goto l4xDe;
        srmGK:
        $gfnP0 = $a6ydA->year;
        goto d1ICF;
        FaDBr:
        $a6ydA = now();
        goto srmGK;
        HMFZU:
        $iGAYE = now();
        goto uBcSl;
        l4xDe:
        kpQaa:
        goto YB8JV;
        YB8JV:
        $this->miTV603ASKT(CTJGrzH3klS5t::UPLOADED);
        goto Usv11;
        pBFOV:
        if (!($gfnP0 > 2026 ? true : (($gfnP0 === 2026 and $MavJy >= 3) ? true : false))) {
            goto d9uyP;
        }
        goto D6wsU;
        d1ICF:
        $MavJy = $a6ydA->month;
        goto pBFOV;
        Usv11:
    }
    public function m9RZzLLhPsV() : void
    {
        goto PAeHb;
        UXhYO:
        if (!($r_pZX[0] > 2026 or $r_pZX[0] === 2026 and $r_pZX[1] > 3 or $r_pZX[0] === 2026 and $r_pZX[1] === 3 and $r_pZX[2] >= 1)) {
            goto w2_sN;
        }
        goto ZkoF_;
        j_XZ_:
        $r_pZX = [$bVYv1->year, $bVYv1->month, $bVYv1->day];
        goto UXhYO;
        Qsrbc:
        $this->miTV603ASKT(CTJGrzH3klS5t::PROCESSING);
        goto Vgszm;
        PAeHb:
        $bVYv1 = now();
        goto j_XZ_;
        mCvBo:
        w2_sN:
        goto Qsrbc;
        ZkoF_:
        return;
        goto mCvBo;
        Vgszm:
    }
    public function mSUb1RyANZD() : void
    {
        goto vSE00;
        NOYqq:
        $this->miTV603ASKT(CTJGrzH3klS5t::FINISHED);
        goto ujwcW;
        C2lQT:
        return;
        goto z7Gfc;
        z7Gfc:
        rn17Z:
        goto NOYqq;
        yOqic:
        if (!(time() >= $lve3c)) {
            goto rn17Z;
        }
        goto C2lQT;
        vSE00:
        $PwSMd = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto qhpaH;
        qhpaH:
        $lve3c = strtotime($PwSMd);
        goto yOqic;
        ujwcW:
    }
    public function myRD1Y8Dvsh() : void
    {
        goto rpFyo;
        SDqEy:
        return;
        goto y2BiU;
        koJNe:
        if (!($D3r88 >= $UhmPu)) {
            goto C253B;
        }
        goto SDqEy;
        pNSpN:
        $D3r88 = $FeDQ7->year * 12 + $FeDQ7->month;
        goto g3nsz;
        swy3s:
        $rmur8 = new \DateTime();
        goto u79rP;
        eJ8Om:
        $rmur8->setTime(0, 0, 0);
        goto SWL_Y;
        hCHUO:
        xnuMN:
        goto eTpby;
        SWL_Y:
        if (!($XAV9a >= $rmur8)) {
            goto xnuMN;
        }
        goto AbUhF;
        rpFyo:
        $FeDQ7 = now();
        goto pNSpN;
        y2BiU:
        C253B:
        goto WKGb1;
        eTpby:
        $this->miTV603ASKT(CTJGrzH3klS5t::ABORTED);
        goto JXI0I;
        WKGb1:
        $XAV9a = new \DateTime();
        goto swy3s;
        AbUhF:
        return;
        goto hCHUO;
        u79rP:
        $rmur8->setDate(2026, 3, 1);
        goto eJ8Om;
        g3nsz:
        $UhmPu = 2026 * 12 + 3;
        goto koJNe;
        JXI0I:
    }
    public function mnuinfTmsMF() : array
    {
        goto pCBYZ;
        JdILO:
        if (!($rki4Z > 0 or $rki4Z === 0 and $Yt2bV->month >= 3)) {
            goto VvGgW;
        }
        goto Wy9Au;
        pCBYZ:
        $Yt2bV = now();
        goto Xie47;
        Wy9Au:
        return ['result' => 3];
        goto QJIVX;
        Xie47:
        $rki4Z = $Yt2bV->year - 2026;
        goto JdILO;
        QJIVX:
        VvGgW:
        goto pu9jv;
        pu9jv:
        return $this->zd1hy;
        goto Tf5ZO;
        Tf5ZO:
    }
    public static function mZ12myBGokU(string $vnAlS, $P2Edw, $AfCy6, $zocZ_) : self
    {
        goto giQ72;
        tLbED:
        $Z1rIR = App::make(Zw7bfX6K3W60S::class)->mY5fSXWcb5x(RUnOaRW6FbMFN::mINz008xwVO($vnAlS));
        goto JAxJq;
        Ssp3K:
        $eohOb->mwXAZfE1o5C(CTJGrzH3klS5t::UPLOADING);
        goto xraMA;
        xraMA:
        return $eohOb->morQPH2pleg();
        goto sw2Qy;
        giQ72:
        $rsyps = now();
        goto gRuwX;
        KXMHj:
        $eohOb->mQuxDPJn8KC($zocZ_, $P2Edw, $AfCy6);
        goto Ssp3K;
        JAxJq:
        $eohOb = new self($Z1rIR, $P2Edw);
        goto KXMHj;
        Rn_b1:
        if ($rj02N) {
            goto n6hB1;
        }
        goto QYWOF;
        QYWOF:
        return null;
        goto hNLJi;
        gRuwX:
        $rj02N = ($rsyps->year < 2026 or $rsyps->year === 2026 and $rsyps->month < 3);
        goto Rn_b1;
        hNLJi:
        n6hB1:
        goto tLbED;
        sw2Qy:
    }
    public static function mnWNCGwTrz3($Z1rIR, $whVTJ, $NWP4g, $zocZ_, $d2eVX = false) : self
    {
        goto yIAO8;
        iKiOH:
        $eohOb->mQuxDPJn8KC($zocZ_, $whVTJ, $NWP4g, $d2eVX);
        goto Ip4_6;
        U6Cyk:
        if (!($QAlRN or $OlX4R and $blpJn >= 3)) {
            goto LMH9p;
        }
        goto C8nN4;
        WLptc:
        if (!$qbxwS->gte($G0BJJ)) {
            goto RW2mU;
        }
        goto k9qXl;
        SBisW:
        $blpJn = $SA0po->month;
        goto OSb5u;
        ffBNR:
        RW2mU:
        goto IWvWo;
        yIAO8:
        $qbxwS = now();
        goto SzP2f;
        OSb5u:
        $QAlRN = $HBgYR > 2026;
        goto iRYEl;
        KUwD7:
        $HBgYR = $SA0po->year;
        goto SBisW;
        vj23j:
        return $eohOb;
        goto uxLT5;
        f7niJ:
        $e5fhn = now();
        goto PjAYM;
        k9qXl:
        return null;
        goto ffBNR;
        SzP2f:
        $G0BJJ = now()->setDate(2026, 3, 1)->startOfDay();
        goto WLptc;
        GprAS:
        LMH9p:
        goto gPc_Z;
        C8nN4:
        return null;
        goto GprAS;
        gPc_Z:
        $eohOb->mwXAZfE1o5C(CTJGrzH3klS5t::UPLOADING);
        goto vj23j;
        PjAYM:
        $m1znt = $e5fhn->format('Y-m-d');
        goto h3YbS;
        iRYEl:
        $OlX4R = $HBgYR === 2026;
        goto U6Cyk;
        IWvWo:
        $eohOb = new self($Z1rIR, $whVTJ);
        goto f7niJ;
        Ip4_6:
        $SA0po = now();
        goto KUwD7;
        h3YbS:
        if (!($m1znt >= sprintf('%04d-%02d-%02d', 2026, 3, 1))) {
            goto q2xfU;
        }
        goto EJZCm;
        EJZCm:
        return null;
        goto M6okK;
        M6okK:
        q2xfU:
        goto iKiOH;
        uxLT5:
    }
}
