<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Contracts\ZBw3vE9HMeZfI;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\Traits\Ek8Ahis6odNzI;
use Jfs\Uploader\Core\Traits\NjN8yZvSzpWnf;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Service\Q9u6o449sXscP;
class JMa7GBaLcnq3D extends MIyg7KY6jn9L1 implements CyraHfwSfcIZC
{
    use Ek8Ahis6odNzI;
    use NjN8yZvSzpWnf;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $YJReg, string $bE8Rq) : self
    {
        goto dMSi1;
        TcQbL:
        return $RxSHk;
        goto wDGMg;
        dMSi1:
        $RxSHk = new self(['id' => $YJReg, 'type' => $bE8Rq, 'status' => A9q1Lm9l5QixG::UPLOADING]);
        goto UJbi6;
        UJbi6:
        $RxSHk->mXpDCMvZsDA(A9q1Lm9l5QixG::UPLOADING);
        goto TcQbL;
        wDGMg:
    }
    public function getView() : array
    {
        $lzVN0 = app(ZBw3vE9HMeZfI::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $lzVN0->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $lzVN0->resolveThumbnail($this)];
    }
    public static function mX44CNdBU9d(MIyg7KY6jn9L1 $IcEa3) : JMa7GBaLcnq3D
    {
        goto qP5cN;
        qP5cN:
        if (!$IcEa3 instanceof JMa7GBaLcnq3D) {
            goto bxlIC;
        }
        goto vpvGs;
        vpvGs:
        return $IcEa3;
        goto GSBC0;
        GSBC0:
        bxlIC:
        goto vVsBZ;
        vVsBZ:
        return (new JMa7GBaLcnq3D())->fill($IcEa3->getAttributes());
        goto LiDvb;
        LiDvb:
    }
}
