<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\Observer\PvXceVpP4rLX7;
use Jfs\Uploader\Core\ShrdF6p8QWYqf;
use Jfs\Uploader\Core\Traits\Gzlbg3E8eX4Qq;
use Jfs\Uploader\Core\Traits\YXqL8Vu76ZyNK;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Exception\VPhlMhTTl80vP;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Exception\NTczwCygSFCCc;
use Jfs\Uploader\Service\FJqWngr52kRMn;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class FALKOA7AcL69a implements VuQzRNCSz5bHK
{
    use Gzlbg3E8eX4Qq;
    use YXqL8Vu76ZyNK;
    private $ApBZS;
    private function __construct($YEF57, $Ay4fJ)
    {
        $this->QEMhI = $YEF57;
        $this->gL39j = $Ay4fJ;
    }
    private function m0OjdtonYOq(string $L2yxk, $Ay4fJ, $UC1Qe, bool $w6IFd = false) : void
    {
        $this->m2Ak24UoC8E(new PvXceVpP4rLX7($this, $Ay4fJ, $UC1Qe, $L2yxk, $w6IFd));
    }
    public function getFile()
    {
        return $this->QEMhI;
    }
    public function mLsCeGjrqf2(array $QQG3e) : void
    {
        $this->ApBZS = $QQG3e;
    }
    public function mBYfuD2w1Gj() : void
    {
        $this->mddb9WvMqo9(ZP6Ky842t6y9Y::UPLOADING);
    }
    public function mjOUs0grsg0() : void
    {
        $this->mddb9WvMqo9(ZP6Ky842t6y9Y::UPLOADED);
    }
    public function mZ2pi4co4VV() : void
    {
        $this->mddb9WvMqo9(ZP6Ky842t6y9Y::PROCESSING);
    }
    public function mN5oLK9CCTV() : void
    {
        $this->mddb9WvMqo9(ZP6Ky842t6y9Y::FINISHED);
    }
    public function m0ICSedKhNJ() : void
    {
        $this->mddb9WvMqo9(ZP6Ky842t6y9Y::ABORTED);
    }
    public function mGNUJ8NdeC3() : array
    {
        return $this->ApBZS;
    }
    public static function m9XExSC44dF(string $InHEz, $aGIVm, $UjVft, $L2yxk) : self
    {
        goto SI5Co;
        hZolN:
        $lgORh->m0OjdtonYOq($L2yxk, $aGIVm, $UjVft);
        goto OOcgz;
        SI5Co:
        $YEF57 = App::make(FJqWngr52kRMn::class)->m4MXHxxcRTe(ShrdF6p8QWYqf::mEfKM4QPesx($InHEz));
        goto lGoCN;
        OOcgz:
        $lgORh->m651SlcakeY(ZP6Ky842t6y9Y::UPLOADING);
        goto R8uto;
        R8uto:
        return $lgORh->m8eFggc96qO();
        goto DM9bf;
        lGoCN:
        $lgORh = new self($YEF57, $aGIVm);
        goto hZolN;
        DM9bf:
    }
    public static function mZMfhXq2Cjt($YEF57, $Ay4fJ, $UC1Qe, $L2yxk, $w6IFd = false) : self
    {
        goto q8lNg;
        uzc49:
        return $lgORh;
        goto tYvKe;
        ijYIS:
        $lgORh->m651SlcakeY(ZP6Ky842t6y9Y::UPLOADING);
        goto uzc49;
        ihJDs:
        $lgORh->m0OjdtonYOq($L2yxk, $Ay4fJ, $UC1Qe, $w6IFd);
        goto ijYIS;
        q8lNg:
        $lgORh = new self($YEF57, $Ay4fJ);
        goto ihJDs;
        tYvKe:
    }
}
