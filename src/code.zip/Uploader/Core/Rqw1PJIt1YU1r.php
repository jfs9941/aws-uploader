<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Illuminate\Database\Eloquent\Model;
abstract  class Rqw1PJIt1YU1r extends Model implements RV6vDyOPhxLM1
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mQao2a3rs3E() : bool
    {
        goto iZxdc;
        W0GgC:
        return !$this->mfUMXidrVrS();
        goto Fsr6K;
        iZxdc:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto dMan3;
        }
        goto FpKfc;
        yaYCK:
        dMan3:
        goto W0GgC;
        FpKfc:
        return true;
        goto yaYCK;
        Fsr6K:
    }
    protected function mfUMXidrVrS() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
