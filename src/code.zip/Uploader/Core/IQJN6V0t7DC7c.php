<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Contracts\PZ7iLyA8MUs3A;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\Traits\K8rP6m5O2PpBO;
use Jfs\Uploader\Core\Traits\TjGyNEupzj5XK;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Service\Gu99j9QqeoWGc;
class IQJN6V0t7DC7c extends F43pNWIrUhz3z implements F9PXWR72LBMoZ
{
    use K8rP6m5O2PpBO;
    use TjGyNEupzj5XK;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $lrkH0, string $aCi5W) : self
    {
        goto HIXTI;
        h5eb6:
        return $KlHaV;
        goto KNuPP;
        HIXTI:
        $KlHaV = new self(['id' => $lrkH0, 'type' => $aCi5W, 'status' => H7dtWZ2h5WAty::UPLOADING]);
        goto izPpa;
        izPpa:
        $KlHaV->muKqrdnPhRb(H7dtWZ2h5WAty::UPLOADING);
        goto h5eb6;
        KNuPP:
    }
    public function getView() : array
    {
        $i7mq9 = app(PZ7iLyA8MUs3A::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $i7mq9->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $i7mq9->resolveThumbnail($this)];
    }
    public static function mnXEB1vIaPR(F43pNWIrUhz3z $bPdTZ) : IQJN6V0t7DC7c
    {
        goto exKUK;
        fp9my:
        return $bPdTZ;
        goto jBlCM;
        jBlCM:
        grBP0:
        goto XyJim;
        XyJim:
        return (new IQJN6V0t7DC7c())->fill($bPdTZ->getAttributes());
        goto caOOo;
        exKUK:
        if (!$bPdTZ instanceof IQJN6V0t7DC7c) {
            goto grBP0;
        }
        goto fp9my;
        caOOo:
    }
}
