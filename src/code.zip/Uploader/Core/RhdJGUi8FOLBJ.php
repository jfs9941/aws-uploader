<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Contracts\VjEI9Nu3TyWfD;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Traits\CD8fs6jM2d7v1;
use Jfs\Uploader\Core\Traits\RWUAoQ6vUS0uH;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
class RhdJGUi8FOLBJ extends EpIpyfdFnoTz6 implements WZhCwGsxQbxug
{
    use CD8fs6jM2d7v1;
    use RWUAoQ6vUS0uH;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $chz0R, string $T_yZW) : self
    {
        goto DdPrk;
        ECUXd:
        $UUt0Z->myjAI8i1TR7(Fsm7WCrUwVWh9::UPLOADING);
        goto obHmU;
        DdPrk:
        $UUt0Z = new self(['id' => $chz0R, 'type' => $T_yZW, 'status' => Fsm7WCrUwVWh9::UPLOADING]);
        goto ECUXd;
        obHmU:
        return $UUt0Z;
        goto R2UQu;
        R2UQu:
    }
    public function width() : ?int
    {
        goto eA1PJ;
        KQdFU:
        if (!$BmTCT) {
            goto mE2Sc;
        }
        goto cWt34;
        jrEUf:
        return null;
        goto vG92i;
        cWt34:
        return $BmTCT;
        goto PbDPD;
        eA1PJ:
        $BmTCT = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto KQdFU;
        PbDPD:
        mE2Sc:
        goto jrEUf;
        vG92i:
    }
    public function height() : ?int
    {
        goto KeYI4;
        YNuMb:
        if (!$IkBoO) {
            goto vJQts;
        }
        goto pv8E1;
        pv8E1:
        return $IkBoO;
        goto c06Ic;
        KeYI4:
        $IkBoO = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto YNuMb;
        c06Ic:
        vJQts:
        goto TS1Ck;
        TS1Ck:
        return null;
        goto eziGG;
        eziGG:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($UUt0Z) {
            goto Xq4zU;
            f8w3g:
            if (!(!array_key_exists('thumbnail', $aOB48) && !array_key_exists('hls_path', $aOB48))) {
                goto r6TPk;
            }
            goto sg9VJ;
            Xq4zU:
            $aOB48 = $UUt0Z->getDirty();
            goto f8w3g;
            sg9VJ:
            return;
            goto z3359;
            z3359:
            r6TPk:
            goto qDA4f;
            JChNH:
            RhdJGUi8FOLBJ::where('parent_id', $UUt0Z->getAttribute('id'))->update(['thumbnail' => $UUt0Z->getAttributes()['thumbnail'], 'hls_path' => $UUt0Z->getAttributes()['hls_path']]);
            goto iDnsJ;
            iDnsJ:
            be1G_:
            goto Vc4tj;
            qDA4f:
            if (!($aOB48['thumbnail'] || $aOB48['hls_path'])) {
                goto be1G_;
            }
            goto JChNH;
            Vc4tj:
        });
    }
    public function m5JmFiWIfT4()
    {
        return $this->getAttribute('thumbnail');
    }
    public function md8PpdvvCop()
    {
        return $this->getAttribute('id');
    }
    public function myIwWlFb6Za() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Cnyg8;
        LYyYg:
        $cYXE_['thumbnail'] = $YTknp->resolveThumbnail($this);
        goto MkkPG;
        dKMIr:
        $cYXE_ = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $YTknp->resolvePath($this, $this->getAttribute('driver'))];
        goto xv2I4;
        BrZ9a:
        goto pED03;
        goto OSsNo;
        zDPxl:
        $cYXE_['player_url'] = $YTknp->resolvePath($this, $this->getAttribute('driver'));
        goto BrZ9a;
        MkkPG:
        return $cYXE_;
        goto eoNhK;
        xv2I4:
        if ($this->getAttribute('hls_path')) {
            goto SwILu;
        }
        goto zDPxl;
        OSsNo:
        SwILu:
        goto lHjbw;
        bfgMA:
        pED03:
        goto LYyYg;
        lHjbw:
        $cYXE_['player_url'] = $YTknp->resolvePathForHlsVideo($this, true);
        goto bfgMA;
        Cnyg8:
        $YTknp = app(VjEI9Nu3TyWfD::class);
        goto dKMIr;
        eoNhK:
    }
    public function getThumbnails()
    {
        goto vqIUr;
        vqIUr:
        $czRUK = $this->getAttribute('generated_previews') ?? [];
        goto sU0U6;
        ocDzM:
        return array_map(function ($gx7xw) use($YTknp) {
            return $YTknp->resolvePath($gx7xw);
        }, $czRUK);
        goto qSBAn;
        sU0U6:
        $YTknp = app(VjEI9Nu3TyWfD::class);
        goto ocDzM;
        qSBAn:
    }
    public static function mRdKdX78JVs(EpIpyfdFnoTz6 $HZKvy) : RhdJGUi8FOLBJ
    {
        goto BRrhL;
        BRrhL:
        if (!$HZKvy instanceof RhdJGUi8FOLBJ) {
            goto Wk4I1;
        }
        goto mrIXN;
        oaYF_:
        Wk4I1:
        goto aMXUW;
        aMXUW:
        return (new RhdJGUi8FOLBJ())->fill($HZKvy->getAttributes());
        goto lE_fQ;
        mrIXN:
        return $HZKvy;
        goto oaYF_;
        lE_fQ:
    }
}
