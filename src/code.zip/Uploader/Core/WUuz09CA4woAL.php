<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Contracts\Jhd15nso8PpYk;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\Traits\EhgHLZ3CNJJzA;
use Jfs\Uploader\Core\Traits\WUrQs9Ut05sJV;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Service\H0nWMZBOapaJq;
class WUuz09CA4woAL extends Rqw1PJIt1YU1r implements ZE3znzkASutzh
{
    use EhgHLZ3CNJJzA;
    use WUrQs9Ut05sJV;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $Xvgj6, string $xKIEz) : self
    {
        goto RvkBl;
        auesd:
        $T4AWF->mOJCH6BWZYm(TSfaBZEUMcbl0::UPLOADING);
        goto b1jRM;
        b1jRM:
        return $T4AWF;
        goto d04vD;
        RvkBl:
        $T4AWF = new self(['id' => $Xvgj6, 'type' => $xKIEz, 'status' => TSfaBZEUMcbl0::UPLOADING]);
        goto auesd;
        d04vD:
    }
    public function getView() : array
    {
        $qjixA = app(Jhd15nso8PpYk::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $qjixA->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $qjixA->resolveThumbnail($this)];
    }
    public static function mxZAEugLYBL(Rqw1PJIt1YU1r $ift9y) : WUuz09CA4woAL
    {
        goto z7BYA;
        gZ4Mb:
        return (new WUuz09CA4woAL())->fill($ift9y->getAttributes());
        goto dqCTR;
        z7BYA:
        if (!$ift9y instanceof WUuz09CA4woAL) {
            goto tEsqZ;
        }
        goto hfoI1;
        smlxN:
        tEsqZ:
        goto gZ4Mb;
        hfoI1:
        return $ift9y;
        goto smlxN;
        dqCTR:
    }
}
