<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Contracts\PathResolverInterface;
use Jfs\Uploader\Core\Traits\FileCreationTrait;
use Jfs\Uploader\Core\Traits\StateMachineTrait;
use Jfs\Uploader\Enum\FileStatus;

/**
 * @property string $resolution
 * @property float $fps
 * @property string $hls_path
 * @property string $aws_media_converter_job_id
 * @property string $thumbnail_id
 * @property int $driver
 */
class Video extends BaseFileModel implements FileStateInterface
{
    use FileCreationTrait;
    use StateMachineTrait;

    public function getType(): string
    {
        return 'video';
    }

    public static function createFromScratch(string $name, string $extension): self
    {
        $video = new self([
            'id' => $name,
            'type' => $extension,
            'status' => FileStatus::UPLOADING,
        ]);
        $video->initializeState(FileStatus::UPLOADING);

        return $video;
    }

    public function width(): ?int
    {
        $width = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        if ($width) {
            return $width;
        }

        return null;
    }

    public function height(): ?int
    {
        $height = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        if ($height) {
            return $height;
        }

        return null;
    }

    protected static function boot()
    {
        parent::boot();
        static::updated(function ($video) {
            $dirtyFields = $video->getDirty();
            if (!array_key_exists('thumbnail', $dirtyFields) && !array_key_exists('hls_path', $dirtyFields)) {
                return;
            }
            if ($dirtyFields['thumbnail'] || $dirtyFields['hls_path']) {
                Video::where('parent_id', $video->getAttribute('id'))->update([
                    'thumbnail' => $video->getAttributes()['thumbnail'],
                    'hls_path' => $video->getAttributes()['hls_path'],
                ]);
            }
        });
    }

    public function getThumbnail()
    {
        return $this->getAttribute('thumbnail');
    }

    public function getId()
    {
        return $this->getAttribute('id');
    }

    public function getPreviewThumbnail(): array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }

    public function getView(): array
    {
        $pathResolver = app(PathResolverInterface::class);
        $view = [
            'id' => $this->getAttribute('id'),
            'type' => $this->getAttribute('type'),
            'file_type' => 'video',
            'path' => $pathResolver->resolvePath($this, $this->getAttribute('driver')),
        ];

        //player key
        if ($this->getAttribute('hls_path')) {
            $view['player_url'] = $pathResolver->resolvePathForHlsVideo($this, true);
        } else {
            $view['player_url'] = $pathResolver->resolvePath($this, $this->getAttribute('driver'));
        }
        // poster key
        $view['thumbnail'] = $pathResolver->resolveThumbnail($this);
        return $view;
    }

    public function getThumbnails() {
        $previews = $this->getAttribute('generated_previews') ?? [];
        $pathResolver = app(PathResolverInterface::class);

        return array_map(function ($thumbnail) use ($pathResolver) {
            return $pathResolver->resolvePath($thumbnail);
        }, $previews);
    }

    public static function asVideo(BaseFileModel $fileModel): Video
    {
        if ($fileModel instanceof Video) {
            return $fileModel;
        }

        return (new Video())->fill($fileModel->getAttributes());
    }
}
