<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Illuminate\Database\Eloquent\Model;
abstract  class MEyH4ejCzSk64 extends Model implements Q0JnJtyNI6T0p
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mGqLq42ajnM() : bool
    {
        goto YNxtQ;
        whReY:
        kNJQ_:
        goto HTU89;
        HTU89:
        return !$this->mLXctVpwWDM();
        goto q2dCg;
        KtoLA:
        return true;
        goto whReY;
        YNxtQ:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto kNJQ_;
        }
        goto KtoLA;
        q2dCg:
    }
    protected function mLXctVpwWDM() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
