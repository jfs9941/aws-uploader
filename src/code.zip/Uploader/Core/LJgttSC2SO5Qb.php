<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
final class LJgttSC2SO5Qb
{
    public $filename;
    public $Qz2nr;
    public $jxkS6;
    public $nPW_w;
    public $drka7;
    public $BNFbb;
    public $EodgE;
    public $status;
    public $Rcfpd;
    public $C33qk;
    public $pM1q4 = 's3';
    public $x3Dn9 = [];
    public function __construct($qIeA3, $A7wHd, $g2xfP, $x5JLV, $SfZkF, $QMgWa, $KSV6A, $L87kl, $aG8Gq, $oKtdH, $NigPe = 's3', $iHezl = [])
    {
        goto zR5Ti;
        wJx_y:
        $this->C33qk = $oKtdH;
        goto QDIYw;
        QDIYw:
        $this->pM1q4 = $NigPe;
        goto YyVsx;
        YyVsx:
        $this->x3Dn9 = $iHezl;
        goto IspVB;
        E5JKF:
        $this->BNFbb = $QMgWa;
        goto ltW1m;
        H4103:
        $this->Qz2nr = $A7wHd;
        goto xBEr_;
        ltW1m:
        $this->EodgE = $KSV6A;
        goto o4vlS;
        o4vlS:
        $this->status = $L87kl;
        goto CSfo9;
        zR5Ti:
        $this->filename = $qIeA3;
        goto H4103;
        pd86h:
        $this->nPW_w = $x5JLV;
        goto svUVr;
        svUVr:
        $this->drka7 = $SfZkF;
        goto E5JKF;
        xBEr_:
        $this->jxkS6 = $g2xfP;
        goto pd86h;
        CSfo9:
        $this->Rcfpd = $aG8Gq;
        goto wJx_y;
        IspVB:
    }
    private static function mk8fjVKhPix() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mkfxoduYOmH() : array
    {
        return array_flip(self::mk8fjVKhPix());
    }
    public function toArray() : array
    {
        $yvBH2 = self::mk8fjVKhPix();
        return [$yvBH2['filename'] => $this->filename, $yvBH2['fileExtension'] => $this->Qz2nr, $yvBH2['mimeType'] => $this->jxkS6, $yvBH2['fileSize'] => $this->nPW_w, $yvBH2['chunkSize'] => $this->drka7, $yvBH2['checksums'] => $this->BNFbb, $yvBH2['totalChunk'] => $this->EodgE, $yvBH2['status'] => $this->status, $yvBH2['userId'] => $this->Rcfpd, $yvBH2['uploadId'] => $this->C33qk, $yvBH2['driver'] => $this->pM1q4, $yvBH2['parts'] => $this->x3Dn9];
    }
    public static function mg0pO2HMPyv(array $sPsco) : self
    {
        $B2vIw = array_flip(self::mkfxoduYOmH());
        return new self($sPsco[$B2vIw['filename']] ?? $sPsco['filename'] ?? '', $sPsco[$B2vIw['fileExtension']] ?? $sPsco['fileExtension'] ?? '', $sPsco[$B2vIw['mimeType']] ?? $sPsco['mimeType'] ?? '', $sPsco[$B2vIw['fileSize']] ?? $sPsco['fileSize'] ?? 0, $sPsco[$B2vIw['chunkSize']] ?? $sPsco['chunkSize'] ?? 0, $sPsco[$B2vIw['checksums']] ?? $sPsco['checksums'] ?? [], $sPsco[$B2vIw['totalChunk']] ?? $sPsco['totalChunk'] ?? 0, $sPsco[$B2vIw['status']] ?? $sPsco['status'] ?? 0, $sPsco[$B2vIw['userId']] ?? $sPsco['userId'] ?? 0, $sPsco[$B2vIw['uploadId']] ?? $sPsco['uploadId'] ?? '', $sPsco[$B2vIw['driver']] ?? $sPsco['driver'] ?? 's3', $sPsco[$B2vIw['parts']] ?? $sPsco['parts'] ?? []);
    }
    public static function mKduiIpARYo($M_TzS) : self
    {
        goto d_ruY;
        PPp5r:
        juf26:
        goto ZlWTo;
        vY0xp:
        return self::mg0pO2HMPyv($M_TzS);
        goto PPp5r;
        d_ruY:
        if (!(isset($M_TzS['fn']) || isset($M_TzS['fe']))) {
            goto juf26;
        }
        goto vY0xp;
        ZlWTo:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto Wyv4D;
        Wyv4D:
    }
    public function mGmavrFr6gA(string $oKtdH) : void
    {
        $this->C33qk = $oKtdH;
    }
    public function miFvLtB9QkN(array $iHezl) : void
    {
        $this->x3Dn9 = $iHezl;
    }
    public static function mv6UcYIveyF($rQ18B, $mbQ5e, $MkOZl, $aG8Gq, $SfZkF, $QMgWa, $NigPe)
    {
        return new self($rQ18B->getFilename(), $rQ18B->getExtension(), $mbQ5e, $MkOZl, $SfZkF, $QMgWa, count($QMgWa), SwAwanZG36Yx6::UPLOADING, $aG8Gq, 0, $NigPe, []);
    }
    public static function mMyUAUeGBJE($mfjeD)
    {
        return 'metadata/' . $mfjeD . '.json';
    }
    public function m7yPyvn12Q1()
    {
        return 's3' === $this->pM1q4 ? GTmWxMidiCuj0::S3 : GTmWxMidiCuj0::LOCAL;
    }
}
