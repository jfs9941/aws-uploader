<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\Observer\ZxZBwkj5ZHKJj;
use Jfs\Uploader\Core\XfZUz9XnPzPJ1;
use Jfs\Uploader\Core\Traits\Mkcxm8a3fkZS2;
use Jfs\Uploader\Core\Traits\WUrQs9Ut05sJV;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Exception\FLUrTiCUjjZmC;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Exception\W9MQd1eHMaESp;
use Jfs\Uploader\Service\VQRb8yFeCwEOC;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class PLi20pZSTTBHP implements ZE3znzkASutzh
{
    use Mkcxm8a3fkZS2;
    use WUrQs9Ut05sJV;
    private $KfiYW;
    private function __construct($ZPsYd, $TWZho)
    {
        $this->d3RM8 = $ZPsYd;
        $this->kgKzZ = $TWZho;
    }
    private function m0vmTIFt9jQ(string $v4kIW, $TWZho, $bnvNm, bool $v2W6E = false) : void
    {
        $this->m1QMTCQtDK5(new ZxZBwkj5ZHKJj($this, $TWZho, $bnvNm, $v4kIW, $v2W6E));
    }
    public function getFile()
    {
        return $this->d3RM8;
    }
    public function m3uvAsmvocJ(array $wcbZg) : void
    {
        $this->KfiYW = $wcbZg;
    }
    public function mhqFrMTjd6I() : void
    {
        $this->mvj3nnnI629(TSfaBZEUMcbl0::UPLOADING);
    }
    public function mOpCwXOW98b() : void
    {
        $this->mvj3nnnI629(TSfaBZEUMcbl0::UPLOADED);
    }
    public function mdd0tVETjoQ() : void
    {
        $this->mvj3nnnI629(TSfaBZEUMcbl0::PROCESSING);
    }
    public function moHiCVeO1lG() : void
    {
        $this->mvj3nnnI629(TSfaBZEUMcbl0::FINISHED);
    }
    public function mwraXPs7B5c() : void
    {
        $this->mvj3nnnI629(TSfaBZEUMcbl0::ABORTED);
    }
    public function mmY4tt6vTUT() : array
    {
        return $this->KfiYW;
    }
    public static function mLt8oIFAn3d(string $qMhfW, $Tyoly, $bjIIR, $v4kIW) : self
    {
        goto hFo9E;
        aiKvY:
        return $EA0zm->mGkpsdCtmoi();
        goto W2V8s;
        y1rcj:
        $EA0zm->m0vmTIFt9jQ($v4kIW, $Tyoly, $bjIIR);
        goto fYAa4;
        fYAa4:
        $EA0zm->mOJCH6BWZYm(TSfaBZEUMcbl0::UPLOADING);
        goto aiKvY;
        N9Woo:
        $EA0zm = new self($ZPsYd, $Tyoly);
        goto y1rcj;
        hFo9E:
        $ZPsYd = App::make(VQRb8yFeCwEOC::class)->mdDQ8kqbTiD(XfZUz9XnPzPJ1::mpccx90wi1r($qMhfW));
        goto N9Woo;
        W2V8s:
    }
    public static function mKV13015Spd($ZPsYd, $TWZho, $bnvNm, $v4kIW, $v2W6E = false) : self
    {
        goto P6Cv7;
        P6Cv7:
        $EA0zm = new self($ZPsYd, $TWZho);
        goto QlGDg;
        H0Rlx:
        $EA0zm->mOJCH6BWZYm(TSfaBZEUMcbl0::UPLOADING);
        goto vaqZe;
        vaqZe:
        return $EA0zm;
        goto L8Yhd;
        QlGDg:
        $EA0zm->m0vmTIFt9jQ($v4kIW, $TWZho, $bnvNm, $v2W6E);
        goto H0Rlx;
        L8Yhd:
    }
}
