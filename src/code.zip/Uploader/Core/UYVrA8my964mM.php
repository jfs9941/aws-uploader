<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Core\Observer\FzxG9Ly772UK9;
use Jfs\Uploader\Core\D30TCm1otQUnt;
use Jfs\Uploader\Core\Traits\TadWCyTQ43Otx;
use Jfs\Uploader\Core\Traits\REDykmcLTsPcw;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Exception\EJQS1ugI78hby;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Exception\Im4dmRuVGtM4W;
use Jfs\Uploader\Service\K3koL2kq4QSAu;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class UYVrA8my964mM implements OFkaCU82i4KNX
{
    use TadWCyTQ43Otx;
    use REDykmcLTsPcw;
    private $aJEQl;
    private function __construct($gNVOT, $e3FbC)
    {
        $this->uq849 = $gNVOT;
        $this->aEqGh = $e3FbC;
    }
    private function mIVoOMDRqwP(string $h2Cp1, $e3FbC, $iw6E8, bool $NVJrR = false) : void
    {
        $this->m4opzeov9Jg(new FzxG9Ly772UK9($this, $e3FbC, $iw6E8, $h2Cp1, $NVJrR));
    }
    public function getFile()
    {
        return $this->uq849;
    }
    public function mz9a6JmdKBB(array $ezR09) : void
    {
        $this->aJEQl = $ezR09;
    }
    public function mbd9isjgURj() : void
    {
        $this->ml2jBQKKXoS(EHhCBxlsVyz9C::UPLOADING);
    }
    public function mf3Ko95nDis() : void
    {
        $this->ml2jBQKKXoS(EHhCBxlsVyz9C::UPLOADED);
    }
    public function maOgBiOkDjI() : void
    {
        $this->ml2jBQKKXoS(EHhCBxlsVyz9C::PROCESSING);
    }
    public function mHeIKrJiKk6() : void
    {
        $this->ml2jBQKKXoS(EHhCBxlsVyz9C::FINISHED);
    }
    public function m6onpnUSJKd() : void
    {
        $this->ml2jBQKKXoS(EHhCBxlsVyz9C::ABORTED);
    }
    public function mVEsQY97kz8() : array
    {
        return $this->aJEQl;
    }
    public static function motvAxgHBzG(string $S580N, $Gilhq, $kxhX9, $h2Cp1) : self
    {
        goto NVr3Q;
        KKZwA:
        return $Hn6Lg->mvo29kYaGxY();
        goto yo2my;
        rn1PX:
        $Hn6Lg = new self($gNVOT, $Gilhq);
        goto P2jcp;
        pHyH7:
        $Hn6Lg->mJpZf64FjYj(EHhCBxlsVyz9C::UPLOADING);
        goto KKZwA;
        NVr3Q:
        $gNVOT = App::make(K3koL2kq4QSAu::class)->mrANFNqI7Cg(D30TCm1otQUnt::mttyt25rY1Q($S580N));
        goto rn1PX;
        P2jcp:
        $Hn6Lg->mIVoOMDRqwP($h2Cp1, $Gilhq, $kxhX9);
        goto pHyH7;
        yo2my:
    }
    public static function mG4IkP4BCe5($gNVOT, $e3FbC, $iw6E8, $h2Cp1, $NVJrR = false) : self
    {
        goto ucRgR;
        aH8Ou:
        $Hn6Lg->mJpZf64FjYj(EHhCBxlsVyz9C::UPLOADING);
        goto Qltjc;
        Qltjc:
        return $Hn6Lg;
        goto gLZMM;
        P2fTs:
        $Hn6Lg->mIVoOMDRqwP($h2Cp1, $e3FbC, $iw6E8, $NVJrR);
        goto aH8Ou;
        ucRgR:
        $Hn6Lg = new self($gNVOT, $e3FbC);
        goto P2fTs;
        gLZMM:
    }
}
