<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Contracts\VwiVLFCuZN4fA;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\Traits\NYTKsbVPARY8x;
use Jfs\Uploader\Core\Traits\V5MfgbTUETSZ1;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Service\M9fyBFwLMDM67;
class OjvWwjWRqBzIO extends D3Q3lppZQonk9 implements ZEs3XZLglwgUu
{
    use NYTKsbVPARY8x;
    use V5MfgbTUETSZ1;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $sAFP4, string $geXNd) : self
    {
        goto lnAQ6;
        QaFiv:
        $Kc1eZ->mWCCmTIigqB(ZVJoOgH14iXBq::UPLOADING);
        goto dtcPo;
        dtcPo:
        return $Kc1eZ;
        goto PZN7D;
        lnAQ6:
        $Kc1eZ = new self(['id' => $sAFP4, 'type' => $geXNd, 'status' => ZVJoOgH14iXBq::UPLOADING]);
        goto QaFiv;
        PZN7D:
    }
    public function getView() : array
    {
        $RXqJj = app(VwiVLFCuZN4fA::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $RXqJj->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $RXqJj->resolveThumbnail($this)];
    }
    public static function m7FwvxMaWNh(D3Q3lppZQonk9 $mA8Ck) : OjvWwjWRqBzIO
    {
        goto BMogj;
        BMogj:
        if (!$mA8Ck instanceof OjvWwjWRqBzIO) {
            goto h5xKj;
        }
        goto KkqLD;
        iZ5mr:
        return (new OjvWwjWRqBzIO())->fill($mA8Ck->getAttributes());
        goto vohzo;
        PW3L4:
        h5xKj:
        goto iZ5mr;
        KkqLD:
        return $mA8Ck;
        goto PW3L4;
        vohzo:
    }
}
