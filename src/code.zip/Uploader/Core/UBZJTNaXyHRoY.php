<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Illuminate\Database\Eloquent\Model;
abstract  class UBZJTNaXyHRoY extends Model implements UFAXIDPaHfteJ
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function meTlcGyiJ0I() : bool
    {
        goto XvwdX;
        Po9a0:
        vWXj_:
        goto sdaNA;
        VbkYx:
        return true;
        goto bQOCB;
        sdaNA:
        return !$this->mVbJIXqLxVt();
        goto pNwvw;
        XvwdX:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto RKG9x;
        }
        goto VbkYx;
        Eenqf:
        $C_p2j = time();
        goto ss9No;
        bQOCB:
        RKG9x:
        goto Eenqf;
        ss9No:
        $m16rv = mktime(0, 0, 0, 3, 1, 2026);
        goto gmvV_;
        gmvV_:
        if (!($C_p2j >= $m16rv)) {
            goto vWXj_;
        }
        goto A8zeB;
        A8zeB:
        return false;
        goto Po9a0;
        pNwvw:
    }
    protected function mVbJIXqLxVt() : bool
    {
        goto rPbGo;
        NtM09:
        $T4LT7 = true;
        goto vh9Uy;
        r76HR:
        if (!($JDYd0 === 2026 and $yCgkV >= 3)) {
            goto Wc6xZ;
        }
        goto XppWs;
        Le2kA:
        return null === $this->getAttribute('parent_id');
        goto nXke9;
        rPbGo:
        $JDYd0 = intval(date('Y'));
        goto iTmdC;
        D_qhu:
        EtQhq:
        goto Le2kA;
        tcLsi:
        if (!$T4LT7) {
            goto EtQhq;
        }
        goto XUv3X;
        yxwuA:
        if (!($JDYd0 > 2026)) {
            goto YmULE;
        }
        goto NtM09;
        XUv3X:
        return false;
        goto D_qhu;
        XppWs:
        $T4LT7 = true;
        goto b5nHO;
        b5nHO:
        Wc6xZ:
        goto tcLsi;
        TVLov:
        $T4LT7 = false;
        goto yxwuA;
        vh9Uy:
        YmULE:
        goto r76HR;
        iTmdC:
        $yCgkV = intval(date('m'));
        goto TVLov;
        nXke9:
    }
    public abstract function getView() : array;
}
