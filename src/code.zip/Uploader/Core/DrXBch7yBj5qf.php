<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Contracts\Ijay4AiPvrqAE;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\Traits\LIcGrY9QpTYiX;
use Jfs\Uploader\Core\Traits\Jvq5Oxs9eu5n3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Service\ElRFl5IfrCbnq;
class DrXBch7yBj5qf extends ZZfsW9KHWsMrx implements N6d9ndnX4hqae
{
    use LIcGrY9QpTYiX;
    use Jvq5Oxs9eu5n3;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $BeTZm, string $vQR_D) : self
    {
        goto e8auV;
        p_JAr:
        $U9fTX->m5qfukNPanz(QE1dzvgcPWV6R::UPLOADING);
        goto lmGOQ;
        e8auV:
        $U9fTX = new self(['id' => $BeTZm, 'type' => $vQR_D, 'status' => QE1dzvgcPWV6R::UPLOADING]);
        goto p_JAr;
        lmGOQ:
        return $U9fTX;
        goto PLxZ2;
        PLxZ2:
    }
    public function getView() : array
    {
        $vYRhC = app(Ijay4AiPvrqAE::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $vYRhC->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $vYRhC->resolveThumbnail($this)];
    }
    public static function mz6MeDmAsBZ(ZZfsW9KHWsMrx $mbUjE) : DrXBch7yBj5qf
    {
        goto d91vi;
        kZvc2:
        return (new DrXBch7yBj5qf())->fill($mbUjE->getAttributes());
        goto lHZCo;
        d91vi:
        if (!$mbUjE instanceof DrXBch7yBj5qf) {
            goto qJqUB;
        }
        goto wZlme;
        dHiqx:
        qJqUB:
        goto kZvc2;
        wZlme:
        return $mbUjE;
        goto dHiqx;
        lHZCo:
    }
}
