<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
final class OGqakwzIfzu7z
{
    public $filename;
    public $ZOUax;
    public $UrdNi;
    public $BeHax;
    public $qTTdh;
    public $BAFaU;
    public $ibBJk;
    public $status;
    public $ZNHY5;
    public $qzKnH;
    public $avC90 = 's3';
    public $Fv1Hq = [];
    public function __construct($vW3Vj, $cOgQS, $EYp1s, $nXbAC, $Y2e5D, $WHPAZ, $qQt8l, $gu0uu, $EiW4T, $n7tqz, $bWJ0p = 's3', $DvSBV = [])
    {
        goto dk7zS;
        dq1DW:
        $this->qTTdh = $Y2e5D;
        goto eOreD;
        cJ95d:
        $this->BeHax = $nXbAC;
        goto dq1DW;
        TrtaT:
        $this->status = $gu0uu;
        goto U4gHn;
        dk7zS:
        $this->filename = $vW3Vj;
        goto WG8jY;
        DmFuy:
        $this->qzKnH = $n7tqz;
        goto HdS5h;
        q76CZ:
        $this->ibBJk = $qQt8l;
        goto TrtaT;
        WG8jY:
        $this->ZOUax = $cOgQS;
        goto IbAQj;
        IbAQj:
        $this->UrdNi = $EYp1s;
        goto cJ95d;
        eOreD:
        $this->BAFaU = $WHPAZ;
        goto q76CZ;
        C5x6G:
        $this->Fv1Hq = $DvSBV;
        goto D8Vge;
        U4gHn:
        $this->ZNHY5 = $EiW4T;
        goto DmFuy;
        HdS5h:
        $this->avC90 = $bWJ0p;
        goto C5x6G;
        D8Vge:
    }
    private static function mMf6AeOmNYZ() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mOOW3gJsRh6() : array
    {
        return array_flip(self::mMf6AeOmNYZ());
    }
    public function toArray() : array
    {
        $w_1ON = self::mMf6AeOmNYZ();
        return [$w_1ON['filename'] => $this->filename, $w_1ON['fileExtension'] => $this->ZOUax, $w_1ON['mimeType'] => $this->UrdNi, $w_1ON['fileSize'] => $this->BeHax, $w_1ON['chunkSize'] => $this->qTTdh, $w_1ON['checksums'] => $this->BAFaU, $w_1ON['totalChunk'] => $this->ibBJk, $w_1ON['status'] => $this->status, $w_1ON['userId'] => $this->ZNHY5, $w_1ON['uploadId'] => $this->qzKnH, $w_1ON['driver'] => $this->avC90, $w_1ON['parts'] => $this->Fv1Hq];
    }
    public static function mPJ5IoDXkWy(array $lQPAG) : self
    {
        $kJYw7 = array_flip(self::mOOW3gJsRh6());
        return new self($lQPAG[$kJYw7['filename']] ?? $lQPAG['filename'] ?? '', $lQPAG[$kJYw7['fileExtension']] ?? $lQPAG['fileExtension'] ?? '', $lQPAG[$kJYw7['mimeType']] ?? $lQPAG['mimeType'] ?? '', $lQPAG[$kJYw7['fileSize']] ?? $lQPAG['fileSize'] ?? 0, $lQPAG[$kJYw7['chunkSize']] ?? $lQPAG['chunkSize'] ?? 0, $lQPAG[$kJYw7['checksums']] ?? $lQPAG['checksums'] ?? [], $lQPAG[$kJYw7['totalChunk']] ?? $lQPAG['totalChunk'] ?? 0, $lQPAG[$kJYw7['status']] ?? $lQPAG['status'] ?? 0, $lQPAG[$kJYw7['userId']] ?? $lQPAG['userId'] ?? 0, $lQPAG[$kJYw7['uploadId']] ?? $lQPAG['uploadId'] ?? '', $lQPAG[$kJYw7['driver']] ?? $lQPAG['driver'] ?? 's3', $lQPAG[$kJYw7['parts']] ?? $lQPAG['parts'] ?? []);
    }
    public static function m1nymnx8GaJ($fpuuH) : self
    {
        goto b3luk;
        foMRU:
        return self::mPJ5IoDXkWy($fpuuH);
        goto RYLBu;
        cu8er:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto YwMbd;
        RYLBu:
        zXBF4:
        goto cu8er;
        b3luk:
        if (!(isset($fpuuH['fn']) || isset($fpuuH['fe']))) {
            goto zXBF4;
        }
        goto foMRU;
        YwMbd:
    }
    public function mRlC7I4fyfy(string $n7tqz) : void
    {
        $this->qzKnH = $n7tqz;
    }
    public function m1j3l70ZkLu(array $DvSBV) : void
    {
        $this->Fv1Hq = $DvSBV;
    }
    public static function mtnaT8I8SCb($hFrf7, $TFxKe, $ubpQh, $EiW4T, $Y2e5D, $WHPAZ, $bWJ0p)
    {
        return new self($hFrf7->getFilename(), $hFrf7->getExtension(), $TFxKe, $ubpQh, $Y2e5D, $WHPAZ, count($WHPAZ), FdWrko7bmoI4Y::UPLOADING, $EiW4T, 0, $bWJ0p, []);
    }
    public static function mhXMJL71B9N($JTwN4)
    {
        return 'metadata/' . $JTwN4 . '.json';
    }
    public function md5H9xoYDzG()
    {
        return 's3' === $this->avC90 ? A3VATad7gvqZU::S3 : A3VATad7gvqZU::LOCAL;
    }
}
