<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Core\Traits\OoN59oKA3bVp5;
use Jfs\Uploader\Core\Traits\GzYkrJxGq9goW;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Service\XsyK4RfzqtWuF;
class E2ynNzu6kpbgj extends DYGJpbj9Ye8wY implements M9ges0moH9yTs
{
    use OoN59oKA3bVp5;
    use GzYkrJxGq9goW;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $IW90g, string $ffCXh) : self
    {
        goto kwV6r;
        kwV6r:
        $vPCcw = new self(['id' => $IW90g, 'type' => $ffCXh, 'status' => U8OFutptQGm3S::UPLOADING]);
        goto qJ7cL;
        ZqMPI:
        return $vPCcw;
        goto yvyCi;
        qJ7cL:
        $vPCcw->mM8xXTkFSyC(U8OFutptQGm3S::UPLOADING);
        goto ZqMPI;
        yvyCi:
    }
    public function getView() : array
    {
        $USeiP = app(ZOxMhYUF0fAsi::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $USeiP->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $USeiP->resolveThumbnail($this)];
    }
    public static function mgsEG9NjLde(DYGJpbj9Ye8wY $bcJEK) : E2ynNzu6kpbgj
    {
        goto MUqJl;
        PbTSP:
        return $bcJEK;
        goto OGrdf;
        MUqJl:
        if (!$bcJEK instanceof E2ynNzu6kpbgj) {
            goto MKOws;
        }
        goto PbTSP;
        l_frg:
        return (new E2ynNzu6kpbgj())->fill($bcJEK->getAttributes());
        goto GQ14N;
        OGrdf:
        MKOws:
        goto l_frg;
        GQ14N:
    }
}
