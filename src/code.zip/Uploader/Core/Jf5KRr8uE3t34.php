<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Contracts\IKjdKLYqqHsDJ;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Traits\LoACaEWnJQjFu;
use Jfs\Uploader\Core\Traits\SphMX2uWp2oS1;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
class Jf5KRr8uE3t34 extends ALaATNTmuoFHt implements MB8DYpNdVV1bz
{
    use LoACaEWnJQjFu;
    use SphMX2uWp2oS1;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $kftn8, string $ln7Ij) : self
    {
        goto ccigp;
        yqco2:
        return $Qw86m;
        goto zoT3K;
        ccigp:
        $Qw86m = new self(['id' => $kftn8, 'type' => $ln7Ij, 'status' => Tbw0jsMnRbOTP::UPLOADING]);
        goto mewyQ;
        mewyQ:
        $Qw86m->mWRFuBOBU6q(Tbw0jsMnRbOTP::UPLOADING);
        goto yqco2;
        zoT3K:
    }
    public function width() : ?int
    {
        goto avBSy;
        avBSy:
        $tYCg4 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto RsxUl;
        Nu32C:
        return null;
        goto SSGpY;
        gFKHC:
        t8uil:
        goto Nu32C;
        MVjeY:
        return $tYCg4;
        goto gFKHC;
        RsxUl:
        if (!$tYCg4) {
            goto t8uil;
        }
        goto MVjeY;
        SSGpY:
    }
    public function height() : ?int
    {
        goto kRPs8;
        NS6Q3:
        if (!$Xnjcp) {
            goto COs4r;
        }
        goto Qg2rn;
        kRPs8:
        $Xnjcp = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto NS6Q3;
        RY14t:
        return null;
        goto a9qnG;
        t3xpg:
        COs4r:
        goto RY14t;
        Qg2rn:
        return $Xnjcp;
        goto t3xpg;
        a9qnG:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($Qw86m) {
            goto FXjFY;
            oFqf3:
            mHsPO:
            goto RPCA_;
            U1WMI:
            fyrJy:
            goto yUcWV;
            RPCA_:
            if (!($S80eY['thumbnail'] || $S80eY['hls_path'])) {
                goto fyrJy;
            }
            goto bAwPs;
            bAwPs:
            Jf5KRr8uE3t34::where('parent_id', $Qw86m->getAttribute('id'))->update(['thumbnail' => $Qw86m->getAttributes()['thumbnail'], 'hls_path' => $Qw86m->getAttributes()['hls_path']]);
            goto U1WMI;
            cyhBj:
            return;
            goto oFqf3;
            FXjFY:
            $S80eY = $Qw86m->getDirty();
            goto aBAfb;
            aBAfb:
            if (!(!array_key_exists('thumbnail', $S80eY) && !array_key_exists('hls_path', $S80eY))) {
                goto mHsPO;
            }
            goto cyhBj;
            yUcWV:
        });
    }
    public function mokU7ydBs3A()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mLwR8riAU9Z()
    {
        return $this->getAttribute('id');
    }
    public function mcMblSBRNAQ() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto MsxP1;
        j1H5N:
        JiI13:
        goto KxDNg;
        KxDNg:
        $n65l6['thumbnail'] = $o4fuz->resolveThumbnail($this);
        goto Z5tw6;
        Z5tw6:
        return $n65l6;
        goto WNN5_;
        fTAks:
        Cx9fH:
        goto O6Gj9;
        wQLl3:
        if ($this->getAttribute('hls_path')) {
            goto Cx9fH;
        }
        goto G1fvN;
        E9viB:
        $n65l6 = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $o4fuz->resolvePath($this, $this->getAttribute('driver'))];
        goto wQLl3;
        O6Gj9:
        $n65l6['player_url'] = $o4fuz->resolvePathForHlsVideo($this, true);
        goto j1H5N;
        G1fvN:
        $n65l6['player_url'] = $o4fuz->resolvePath($this, $this->getAttribute('driver'));
        goto L7AaI;
        L7AaI:
        goto JiI13;
        goto fTAks;
        MsxP1:
        $o4fuz = app(IKjdKLYqqHsDJ::class);
        goto E9viB;
        WNN5_:
    }
    public function getThumbnails()
    {
        goto ZtFUF;
        YdRsn:
        return array_map(function ($saBWi) use($o4fuz) {
            return $o4fuz->resolvePath($saBWi);
        }, $LiCxT);
        goto D2c5O;
        ZtFUF:
        $LiCxT = $this->getAttribute('generated_previews') ?? [];
        goto IoUC_;
        IoUC_:
        $o4fuz = app(IKjdKLYqqHsDJ::class);
        goto YdRsn;
        D2c5O:
    }
    public static function mmsjrmald2i(ALaATNTmuoFHt $nu6qO) : Jf5KRr8uE3t34
    {
        goto c9GSg;
        xescN:
        return $nu6qO;
        goto wnjRc;
        wnjRc:
        otADN:
        goto woYkk;
        c9GSg:
        if (!$nu6qO instanceof Jf5KRr8uE3t34) {
            goto otADN;
        }
        goto xescN;
        woYkk:
        return (new Jf5KRr8uE3t34())->fill($nu6qO->getAttributes());
        goto uDlv9;
        uDlv9:
    }
}
