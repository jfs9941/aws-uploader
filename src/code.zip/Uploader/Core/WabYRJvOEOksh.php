<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Core\Traits\RYD8pJSplDz0G;
use Jfs\Uploader\Core\Traits\RmjpXY01QWbl2;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Service\Df64o7d8ZEcB5;
class WabYRJvOEOksh extends CZj9PTf9Cv9Eq implements VH6naaofz5IuZ
{
    use RYD8pJSplDz0G;
    use RmjpXY01QWbl2;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $Vuk0i, string $RKAxu) : self
    {
        goto zsyWJ;
        P0ei8:
        return $GS3Dz;
        goto AVTDT;
        vIbvS:
        $GS3Dz->mkv7RuyOFPh(EPmxqTVp5luXc::UPLOADING);
        goto P0ei8;
        zsyWJ:
        $GS3Dz = new self(['id' => $Vuk0i, 'type' => $RKAxu, 'status' => EPmxqTVp5luXc::UPLOADING]);
        goto vIbvS;
        AVTDT:
    }
    public function getView() : array
    {
        $hlmkv = app(BEzZsfn3kKkr3::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $hlmkv->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $hlmkv->resolveThumbnail($this)];
    }
    public static function mIKQ6h4By9B(CZj9PTf9Cv9Eq $dCHQU) : WabYRJvOEOksh
    {
        goto FLM5n;
        E2pWa:
        rcmHK:
        goto lBkDT;
        FLM5n:
        if (!$dCHQU instanceof WabYRJvOEOksh) {
            goto rcmHK;
        }
        goto jWOXE;
        lBkDT:
        return (new WabYRJvOEOksh())->fill($dCHQU->getAttributes());
        goto aLSs1;
        jWOXE:
        return $dCHQU;
        goto E2pWa;
        aLSs1:
    }
}
