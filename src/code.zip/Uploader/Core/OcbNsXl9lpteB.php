<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Core\Traits\NYNDlFOE1EB92;
use Jfs\Uploader\Core\Traits\ZKxVDSicUFaFP;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Service\U8DiLJGk0mfB7;
class OcbNsXl9lpteB extends QfVdOZWAlX8Sl implements QBvcnDryrzxsL
{
    use NYNDlFOE1EB92;
    use ZKxVDSicUFaFP;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $YoQzC, string $HuqsN) : self
    {
        goto HkEqB;
        C5ry3:
        $Xxl6q->mhnYveV1r0A(QUh2VVA2TE5xx::UPLOADING);
        goto guP65;
        guP65:
        return $Xxl6q;
        goto VbP7N;
        HkEqB:
        $Xxl6q = new self(['id' => $YoQzC, 'type' => $HuqsN, 'status' => QUh2VVA2TE5xx::UPLOADING]);
        goto C5ry3;
        VbP7N:
    }
    public function getView() : array
    {
        $dyGhn = app(E97atJzeJ1gs5::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $dyGhn->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $dyGhn->resolveThumbnail($this)];
    }
    public static function mpi4nItrxbO(QfVdOZWAlX8Sl $sYOYc) : OcbNsXl9lpteB
    {
        goto FDcPt;
        IAV_S:
        aFaIZ:
        goto zLs_s;
        f_AB3:
        return $sYOYc;
        goto IAV_S;
        zLs_s:
        return (new OcbNsXl9lpteB())->fill($sYOYc->getAttributes());
        goto CfqKt;
        FDcPt:
        if (!$sYOYc instanceof OcbNsXl9lpteB) {
            goto aFaIZ;
        }
        goto f_AB3;
        CfqKt:
    }
}
