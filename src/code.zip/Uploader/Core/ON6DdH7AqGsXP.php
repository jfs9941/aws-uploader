<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core;

use src\Uploader\Enum\FileDriver;
use src\Uploader\Enum\FileStatus;
final class ON6DdH7AqGsXP
{
    public $filename;
    public $VkTLD;
    public $G1PGO;
    public $dXNxw;
    public $I5jem;
    public $blHu4;
    public $f6ZsI;
    public $status;
    public $Md3QA;
    public $hNgeS;
    public $WJjcF = 's3';
    public $Kp54_ = [];
    public function __construct($AUYu_, $JhwC_, $wYibu, $sk6AO, $aa5xh, $CNTHN, $v7qX5, $SwBKz, $Vy40_, $bkvvg, $PwWrM = 's3', $qj0o5 = [])
    {
        goto Jbb3O;
        PSZFv:
        $this->Md3QA = $Vy40_;
        goto QVg4T;
        u3AHb:
        $this->status = $SwBKz;
        goto PSZFv;
        h1HNV:
        $this->WJjcF = $PwWrM;
        goto ukt7v;
        QG5OZ:
        $this->blHu4 = $CNTHN;
        goto eU2hP;
        KMwf5:
        $this->G1PGO = $wYibu;
        goto H0jc_;
        BhueZ:
        $this->VkTLD = $JhwC_;
        goto KMwf5;
        ukt7v:
        $this->Kp54_ = $qj0o5;
        goto sFsrL;
        fUFNM:
        $this->I5jem = $aa5xh;
        goto QG5OZ;
        eU2hP:
        $this->f6ZsI = $v7qX5;
        goto u3AHb;
        QVg4T:
        $this->hNgeS = $bkvvg;
        goto h1HNV;
        Jbb3O:
        $this->filename = $AUYu_;
        goto BhueZ;
        H0jc_:
        $this->dXNxw = $sk6AO;
        goto fUFNM;
        sFsrL:
    }
    private static function maVHW5kzPdM() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mGq6qxOHWt1() : array
    {
        return array_flip(self::maVHW5kzPdM());
    }
    public function toArray() : array
    {
        $iVdoF = self::maVHW5kzPdM();
        return [$iVdoF['filename'] => $this->filename, $iVdoF['fileExtension'] => $this->VkTLD, $iVdoF['mimeType'] => $this->G1PGO, $iVdoF['fileSize'] => $this->dXNxw, $iVdoF['chunkSize'] => $this->I5jem, $iVdoF['checksums'] => $this->blHu4, $iVdoF['totalChunk'] => $this->f6ZsI, $iVdoF['status'] => $this->status, $iVdoF['userId'] => $this->Md3QA, $iVdoF['uploadId'] => $this->hNgeS, $iVdoF['driver'] => $this->WJjcF, $iVdoF['parts'] => $this->Kp54_];
    }
    public static function m358AfuyGBp(array $CEixl) : self
    {
        $rUJGU = array_flip(self::mGq6qxOHWt1());
        return new self($CEixl[$rUJGU['filename']] ?? $CEixl['filename'] ?? '', $CEixl[$rUJGU['fileExtension']] ?? $CEixl['fileExtension'] ?? '', $CEixl[$rUJGU['mimeType']] ?? $CEixl['mimeType'] ?? '', $CEixl[$rUJGU['fileSize']] ?? $CEixl['fileSize'] ?? 0, $CEixl[$rUJGU['chunkSize']] ?? $CEixl['chunkSize'] ?? 0, $CEixl[$rUJGU['checksums']] ?? $CEixl['checksums'] ?? [], $CEixl[$rUJGU['totalChunk']] ?? $CEixl['totalChunk'] ?? 0, $CEixl[$rUJGU['status']] ?? $CEixl['status'] ?? 0, $CEixl[$rUJGU['userId']] ?? $CEixl['userId'] ?? 0, $CEixl[$rUJGU['uploadId']] ?? $CEixl['uploadId'] ?? '', $CEixl[$rUJGU['driver']] ?? $CEixl['driver'] ?? 's3', $CEixl[$rUJGU['parts']] ?? $CEixl['parts'] ?? []);
    }
    public static function myKxYsIh7WE($F1sgi) : self
    {
        goto WRQpH;
        yX2Kb:
        ETBkD:
        goto YoBDz;
        wVK3o:
        return self::m358AfuyGBp($F1sgi);
        goto yX2Kb;
        YoBDz:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto C2FX7;
        WRQpH:
        if (!(isset($F1sgi['fn']) || isset($F1sgi['fe']))) {
            goto ETBkD;
        }
        goto wVK3o;
        C2FX7:
    }
    public function mrkxryvGEcX(string $bkvvg) : void
    {
        $this->hNgeS = $bkvvg;
    }
    public function m8MkEEzPals(array $qj0o5) : void
    {
        $this->Kp54_ = $qj0o5;
    }
    public static function mhbmwFd9wYi($d1aiC, $AR0eO, $TDpky, $Vy40_, $aa5xh, $CNTHN, $PwWrM)
    {
        return new self($d1aiC->getFilename(), $d1aiC->getExtension(), $AR0eO, $TDpky, $aa5xh, $CNTHN, count($CNTHN), FileStatus::UPLOADING, $Vy40_, 0, $PwWrM, []);
    }
    public static function mDUKvw1QoZp($BFPg9)
    {
        return 'metadata/' . $BFPg9 . '.json';
    }
    public function mbO4gUDBrKb()
    {
        return 's3' === $this->WJjcF ? FileDriver::S3 : FileDriver::LOCAL;
    }
}
