<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\Observer\LI2VruHCBJDpe;
use Jfs\Uploader\Core\Ell8BGMQxuan6;
use Jfs\Uploader\Core\Traits\JFUnAKIvoYkez;
use Jfs\Uploader\Core\Traits\G7D3EePyrZS05;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Exception\Rd9NvFKXhRqmf;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Exception\Im1SMZKdIP8xi;
use Jfs\Uploader\Service\WhUSFqM1jr0Xc;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class J25pBODLIBVKi implements AMhr3oncxsM7G
{
    use JFUnAKIvoYkez;
    use G7D3EePyrZS05;
    private $vh_Rs;
    private function __construct($AgDkH, $VtAcw)
    {
        $this->file = $AgDkH;
        $this->AF5CG = $VtAcw;
    }
    private function m7SM7XCphr8(string $UrhM5, $VtAcw, $aWR_D, bool $Gut04 = false) : void
    {
        goto RPTIR;
        eWLA6:
        if (!($Ee1OA >= $TTA6C)) {
            goto LA6Nj;
        }
        goto N0QV9;
        RPTIR:
        $Ee1OA = time();
        goto Ra_Yu;
        GtwTA:
        LA6Nj:
        goto I3JAA;
        N0QV9:
        return;
        goto GtwTA;
        Ra_Yu:
        $TTA6C = mktime(0, 0, 0, 3, 1, 2026);
        goto eWLA6;
        I3JAA:
        $this->mNCLIs0B4x0(new LI2VruHCBJDpe($this, $VtAcw, $aWR_D, $UrhM5, $Gut04));
        goto TS5sP;
        TS5sP:
    }
    public function getFile()
    {
        goto n4PjX;
        n4PjX:
        $Y_BRG = intval(date('Y'));
        goto Kw_TA;
        s2J8X:
        $bVC0N = true;
        goto j992X;
        UFpGH:
        euQ65:
        goto Eu_RK;
        Kw_TA:
        $g0D_I = intval(date('m'));
        goto Devqg;
        NSbof:
        $bVC0N = true;
        goto WfYIm;
        Devqg:
        $bVC0N = false;
        goto grDbs;
        UIE4u:
        return null;
        goto UFpGH;
        j992X:
        W3kmp:
        goto RLL7N;
        WfYIm:
        CSv60:
        goto vkGU0;
        RLL7N:
        if (!($Y_BRG === 2026 and $g0D_I >= 3)) {
            goto CSv60;
        }
        goto NSbof;
        vkGU0:
        if (!$bVC0N) {
            goto euQ65;
        }
        goto UIE4u;
        Eu_RK:
        return $this->file;
        goto m3Kcc;
        grDbs:
        if (!($Y_BRG > 2026)) {
            goto W3kmp;
        }
        goto s2J8X;
        m3Kcc:
    }
    public function mFZi8mMFcnw(array $C41Oe) : void
    {
        goto oDZkQ;
        Uw8FY:
        $oLjPW = $RDKRK->year;
        goto msLZh;
        umJFh:
        return;
        goto BCgGD;
        BCgGD:
        ikR78:
        goto pKtdc;
        oDZkQ:
        $RDKRK = now();
        goto Uw8FY;
        pYCZL:
        if (!($oLjPW > 2026 or $oLjPW === 2026 and $MoVPh > 3 or $oLjPW === 2026 and $MoVPh === 3 and $RDKRK->day >= 1)) {
            goto ikR78;
        }
        goto umJFh;
        pKtdc:
        $this->vh_Rs = $C41Oe;
        goto xDSWs;
        msLZh:
        $MoVPh = $RDKRK->month;
        goto pYCZL;
        xDSWs:
    }
    public function mKkqauDXFSg() : void
    {
        goto tCHeV;
        XPZ9i:
        Zukwb:
        goto ivDNW;
        OakaP:
        $TQNIp = now();
        goto vVQEp;
        tCHeV:
        $azkwc = date('Y-m');
        goto qcJp3;
        I81r_:
        k31rJ:
        goto OakaP;
        dEIpp:
        if (!($TQNIp->diffInDays($y6lEW, false) <= 0)) {
            goto Zukwb;
        }
        goto jdx_Y;
        AbQ1W:
        if (!($azkwc >= $LO2Oy)) {
            goto k31rJ;
        }
        goto Bb2si;
        Bb2si:
        return;
        goto I81r_;
        jdx_Y:
        return;
        goto XPZ9i;
        qcJp3:
        $LO2Oy = sprintf('%04d-%02d', 2026, 3);
        goto AbQ1W;
        vVQEp:
        $y6lEW = now()->setDate(2026, 3, 1);
        goto dEIpp;
        ivDNW:
        $this->miBsAvAu0gK(X1RCpxma8t1mI::UPLOADING);
        goto gwWjz;
        gwWjz:
    }
    public function mDf2ssnrSJE() : void
    {
        goto bZRVa;
        zY7tJ:
        return;
        goto mQyDN;
        c8EO8:
        $this->miBsAvAu0gK(X1RCpxma8t1mI::UPLOADED);
        goto r6w2w;
        O4l8g:
        if (!($BDvbQ->year > 2026 or $BDvbQ->year === 2026 and $BDvbQ->month >= 3)) {
            goto P6MAJ;
        }
        goto zY7tJ;
        bZRVa:
        $BDvbQ = now();
        goto O4l8g;
        mQyDN:
        P6MAJ:
        goto c8EO8;
        r6w2w:
    }
    public function m0hxAKaxnWT() : void
    {
        goto bwGeD;
        GJUFJ:
        $wtbUy = $xoI2R->year;
        goto Dx8QA;
        YYxwg:
        return;
        goto seUy_;
        zD6RS:
        if (!($wtbUy > 2026 ? true : (($wtbUy === 2026 and $wUe8o >= 3) ? true : false))) {
            goto AxPcw;
        }
        goto YYxwg;
        seUy_:
        AxPcw:
        goto miINE;
        miINE:
        $this->miBsAvAu0gK(X1RCpxma8t1mI::PROCESSING);
        goto M2kBL;
        Dx8QA:
        $wUe8o = $xoI2R->month;
        goto zD6RS;
        bwGeD:
        $xoI2R = now();
        goto GJUFJ;
        M2kBL:
    }
    public function mPyt09GLtpB() : void
    {
        goto N62Zy;
        vNSnr:
        $this->miBsAvAu0gK(X1RCpxma8t1mI::FINISHED);
        goto hd94W;
        BnGC8:
        return;
        goto f6oEZ;
        mXzIG:
        if (!($cWQB2[0] > 2026 or $cWQB2[0] === 2026 and $cWQB2[1] > 3 or $cWQB2[0] === 2026 and $cWQB2[1] === 3 and $cWQB2[2] >= 1)) {
            goto QSLbK;
        }
        goto BnGC8;
        N62Zy:
        $XwY16 = now();
        goto JC5jh;
        f6oEZ:
        QSLbK:
        goto vNSnr;
        JC5jh:
        $cWQB2 = [$XwY16->year, $XwY16->month, $XwY16->day];
        goto mXzIG;
        hd94W:
    }
    public function mrAjREFESjK() : void
    {
        goto A8wGS;
        qXcPM:
        $OrKUj->setTime(0, 0, 0);
        goto mFlas;
        oU7jA:
        return;
        goto ga06g;
        hHGwC:
        $this->miBsAvAu0gK(X1RCpxma8t1mI::ABORTED);
        goto gVW3V;
        zy0fU:
        $OrKUj->setDate(2026, 3, 1);
        goto qXcPM;
        EMhZ_:
        $OrKUj = new \DateTime();
        goto zy0fU;
        vqlHt:
        R2IGi:
        goto hHGwC;
        mFlas:
        if (!($ZXWLI >= $OrKUj)) {
            goto r9kCU;
        }
        goto oU7jA;
        ga06g:
        r9kCU:
        goto yF2JN;
        yF2JN:
        $B71gl = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto mClfy;
        A8wGS:
        $ZXWLI = new \DateTime();
        goto EMhZ_;
        aFvFT:
        return;
        goto vqlHt;
        mClfy:
        $QL1dp = strtotime($B71gl);
        goto SSJHP;
        SSJHP:
        if (!(time() >= $QL1dp)) {
            goto R2IGi;
        }
        goto aFvFT;
        gVW3V:
    }
    public function mzySJUgFWv3() : array
    {
        goto r1Ovj;
        r1Ovj:
        $cztxT = now();
        goto Nq2xt;
        E1rqZ:
        return ['key' => 'null'];
        goto bylWd;
        bJma1:
        $Qmlbu = 2026 * 12 + 3;
        goto otH_y;
        otH_y:
        if (!($H8uwf >= $Qmlbu)) {
            goto tKO8N;
        }
        goto E1rqZ;
        KULDc:
        return $this->vh_Rs;
        goto mlHZz;
        bylWd:
        tKO8N:
        goto KULDc;
        Nq2xt:
        $H8uwf = $cztxT->year * 12 + $cztxT->month;
        goto bJma1;
        mlHZz:
    }
    public static function miSR5rsrxVR(string $HxXtJ, $wChQQ, $BNlIn, $UrhM5) : self
    {
        goto QZoQl;
        OPYoy:
        $Iz9ES->m7SM7XCphr8($UrhM5, $wChQQ, $BNlIn);
        goto waN00;
        QZoQl:
        $AgDkH = App::make(WhUSFqM1jr0Xc::class)->m5nB42s52FS(Ell8BGMQxuan6::m5ZXcqnfJ3O($HxXtJ));
        goto ROLU0;
        WUy1Y:
        if (!($hSqP2 > 0 or $hSqP2 === 0 and $zcNnt->month >= 3)) {
            goto bM3C0;
        }
        goto zUyFn;
        u4UJv:
        $hSqP2 = $zcNnt->year - 2026;
        goto WUy1Y;
        fAlMi:
        return $Iz9ES->mOwJAjZyPjV();
        goto a7PpW;
        waN00:
        $Iz9ES->maYYBXJYcZK(X1RCpxma8t1mI::UPLOADING);
        goto fAlMi;
        TMAZU:
        bM3C0:
        goto HmWxb;
        ROLU0:
        $zcNnt = now();
        goto u4UJv;
        zUyFn:
        return null;
        goto TMAZU;
        HmWxb:
        $Iz9ES = new self($AgDkH, $wChQQ);
        goto OPYoy;
        a7PpW:
    }
    public static function mNuGB9XWGNn($AgDkH, $VtAcw, $aWR_D, $UrhM5, $Gut04 = false) : self
    {
        goto gunAy;
        TstR_:
        return $Iz9ES;
        goto Er2MU;
        V33ov:
        $nvZeL = now();
        goto h0i2Q;
        XSpYt:
        $Iz9ES->maYYBXJYcZK(X1RCpxma8t1mI::UPLOADING);
        goto TstR_;
        klXrE:
        return null;
        goto vy6cl;
        UzNoo:
        $Iz9ES->m7SM7XCphr8($UrhM5, $VtAcw, $aWR_D, $Gut04);
        goto V33ov;
        YjNVs:
        $JRzrQ = $VP2ql->year;
        goto LbNS1;
        CJNlR:
        if ($N4_n9) {
            goto HmGcU;
        }
        goto klXrE;
        sjbb9:
        $gKnka = $JRzrQ === 2026;
        goto iBR0m;
        li7TE:
        $vDGHx = $JRzrQ > 2026;
        goto sjbb9;
        iBR0m:
        if (!($vDGHx or $gKnka and $bp8fu >= 3)) {
            goto KT90h;
        }
        goto qAwSr;
        h0i2Q:
        $N4_n9 = ($nvZeL->year < 2026 or $nvZeL->year === 2026 and $nvZeL->month < 3);
        goto CJNlR;
        y3IHg:
        $Iz9ES = new self($AgDkH, $VtAcw);
        goto UzNoo;
        LbNS1:
        $bp8fu = $VP2ql->month;
        goto li7TE;
        vy6cl:
        HmGcU:
        goto XSpYt;
        qAwSr:
        return null;
        goto DFMJP;
        DFMJP:
        KT90h:
        goto y3IHg;
        gunAy:
        $VP2ql = now();
        goto YjNVs;
        Er2MU:
    }
}
