<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Contracts\AbPtLXucv9ja8;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\Traits\IBoPBAZwQwRqv;
use Jfs\Uploader\Core\Traits\W8XZSueQaszDJ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
class N1wF7eNF4lYgo extends OWEQTdXGAAFta implements DHtESYY0VyGQJ
{
    use IBoPBAZwQwRqv;
    use W8XZSueQaszDJ;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $eVMet, string $cJEs5) : self
    {
        goto sYPWJ;
        XpOF6:
        return $JfLWA;
        goto SgUbm;
        sYPWJ:
        $JfLWA = new self(['id' => $eVMet, 'type' => $cJEs5, 'status' => A7CVlqbpzhfLD::UPLOADING]);
        goto tA_F2;
        tA_F2:
        $JfLWA->mdMI6wvUXmN(A7CVlqbpzhfLD::UPLOADING);
        goto XpOF6;
        SgUbm:
    }
    public function width() : ?int
    {
        goto RiIxn;
        izWEV:
        z13cW:
        goto n3RRe;
        n3RRe:
        return null;
        goto SWjjQ;
        RiIxn:
        $XLJzE = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto p7Pdw;
        vvObW:
        return $XLJzE;
        goto izWEV;
        p7Pdw:
        if (!$XLJzE) {
            goto z13cW;
        }
        goto vvObW;
        SWjjQ:
    }
    public function height() : ?int
    {
        goto v3hXS;
        TLXwQ:
        return $X8shh;
        goto i0CvW;
        v3hXS:
        $X8shh = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto ZC5FG;
        sraZa:
        return null;
        goto UDuN5;
        i0CvW:
        sI72X:
        goto sraZa;
        ZC5FG:
        if (!$X8shh) {
            goto sI72X;
        }
        goto TLXwQ;
        UDuN5:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($JfLWA) {
            goto B9Yam;
            qyh1I:
            return;
            goto QwC2G;
            g1Zv3:
            if (!($YcFWa['thumbnail'] || $YcFWa['hls_path'])) {
                goto tRtJM;
            }
            goto VBBGQ;
            mFTAw:
            if (!(!array_key_exists('thumbnail', $YcFWa) && !array_key_exists('hls_path', $YcFWa))) {
                goto Qe9xR;
            }
            goto qyh1I;
            ef7xg:
            tRtJM:
            goto TahLZ;
            QwC2G:
            Qe9xR:
            goto g1Zv3;
            VBBGQ:
            N1wF7eNF4lYgo::where('parent_id', $JfLWA->getAttribute('id'))->update(['thumbnail' => $JfLWA->getAttributes()['thumbnail'], 'hls_path' => $JfLWA->getAttributes()['hls_path']]);
            goto ef7xg;
            B9Yam:
            $YcFWa = $JfLWA->getDirty();
            goto mFTAw;
            TahLZ:
        });
    }
    public function mVacz9xkxTF()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mu4WcHljo9c()
    {
        return $this->getAttribute('id');
    }
    public function menJz07U6OQ() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto KeOG5;
        F0UpA:
        $vVh3J = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $wt4Tn->resolvePath($this, $this->getAttribute('driver'))];
        goto Z8qJP;
        dcIhg:
        $vVh3J['player_url'] = $wt4Tn->resolvePath($this, $this->getAttribute('driver'));
        goto rjAhl;
        F1M4f:
        return $vVh3J;
        goto nw9VC;
        Z8qJP:
        if ($this->getAttribute('hls_path')) {
            goto cJUKA;
        }
        goto dcIhg;
        rjAhl:
        goto D7I1A;
        goto LuUyo;
        abKcz:
        D7I1A:
        goto LuGCi;
        KeOG5:
        $wt4Tn = app(AbPtLXucv9ja8::class);
        goto F0UpA;
        LuGCi:
        $vVh3J['thumbnail'] = $wt4Tn->resolveThumbnail($this);
        goto F1M4f;
        LuUyo:
        cJUKA:
        goto OEJYN;
        OEJYN:
        $vVh3J['player_url'] = $wt4Tn->resolvePathForHlsVideo($this, true);
        goto abKcz;
        nw9VC:
    }
    public function getThumbnails()
    {
        goto mMaom;
        qoNy2:
        $wt4Tn = app(AbPtLXucv9ja8::class);
        goto O6jCY;
        O6jCY:
        return array_map(function ($gYP4D) use($wt4Tn) {
            return $wt4Tn->resolvePath($gYP4D);
        }, $mlKjz);
        goto ZHagH;
        mMaom:
        $mlKjz = $this->getAttribute('generated_previews') ?? [];
        goto qoNy2;
        ZHagH:
    }
    public static function md7edg6ZDxx(OWEQTdXGAAFta $QWQ9j) : N1wF7eNF4lYgo
    {
        goto KKN2k;
        KKN2k:
        if (!$QWQ9j instanceof N1wF7eNF4lYgo) {
            goto GEIz6;
        }
        goto GAIPE;
        GAIPE:
        return $QWQ9j;
        goto ksc3y;
        JJQ1G:
        return (new N1wF7eNF4lYgo())->fill($QWQ9j->getAttributes());
        goto wzmp1;
        ksc3y:
        GEIz6:
        goto JJQ1G;
        wzmp1:
    }
}
