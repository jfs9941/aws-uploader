<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; use Illuminate\Database\Eloquent\Model; use Jfs\Uploader\Enum\FileDriver; abstract  class J5wym0qxH1hlR extends Model implements DIYGIfCt7MLhm { public $incrementing = false; protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews']; protected $table = 'attachments'; protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int']; public function m1Z5bTDFXgO() : bool { goto RCm07; YNMZA: return !$this->m0bL4oEKvkr(); goto e5kKQ; RCm07: if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) { goto SloNk; } goto URGmm; URGmm: return true; goto aVpkN; aVpkN: SloNk: goto YNMZA; e5kKQ: } protected function m0bL4oEKvkr() : bool { return null === $this->getAttribute('parent_id'); } public abstract function getView() : array; }
