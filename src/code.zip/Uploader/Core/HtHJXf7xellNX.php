<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Illuminate\Database\Eloquent\Model;
abstract  class HtHJXf7xellNX extends Model implements N8O216tH1Gxax
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mKbwFy5aKy5() : bool
    {
        goto Ds1Gw;
        kbTV4:
        return true;
        goto oW8NL;
        oW8NL:
        GXwkF:
        goto akNwM;
        Ds1Gw:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto GXwkF;
        }
        goto kbTV4;
        akNwM:
        return !$this->mXj23ryz0Ps();
        goto wnJjq;
        wnJjq:
    }
    protected function mXj23ryz0Ps() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
