<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Contracts\Ijay4AiPvrqAE;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\Traits\LIcGrY9QpTYiX;
use Jfs\Uploader\Core\Traits\Jvq5Oxs9eu5n3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Service\ElRFl5IfrCbnq;
class FmmY71eXk0D8U extends ZZfsW9KHWsMrx implements N6d9ndnX4hqae
{
    use LIcGrY9QpTYiX;
    use Jvq5Oxs9eu5n3;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $BeTZm, string $vQR_D) : self
    {
        goto fMqWg;
        fMqWg:
        $dIrHq = new self(['id' => $BeTZm, 'type' => $vQR_D, 'status' => QE1dzvgcPWV6R::UPLOADING]);
        goto pzej8;
        AWhcR:
        return $dIrHq;
        goto WQ57R;
        pzej8:
        $dIrHq->m5qfukNPanz(QE1dzvgcPWV6R::UPLOADING);
        goto AWhcR;
        WQ57R:
    }
    public function getView() : array
    {
        $vYRhC = app(Ijay4AiPvrqAE::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $vYRhC->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $vYRhC->resolveThumbnail($this)];
    }
    public static function mR67ojPvI8S(ZZfsW9KHWsMrx $mbUjE) : FmmY71eXk0D8U
    {
        goto Q1pO0;
        Q1pO0:
        if (!$mbUjE instanceof FmmY71eXk0D8U) {
            goto exnLl;
        }
        goto lcpKT;
        SOpH3:
        exnLl:
        goto HEYeL;
        HEYeL:
        return (new FmmY71eXk0D8U())->fill($mbUjE->getAttributes());
        goto p4Djg;
        lcpKT:
        return $mbUjE;
        goto SOpH3;
        p4Djg:
    }
}
