<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Contracts\I85IcZZcCMm6R;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Traits\LPEZ3HrEECO03;
use Jfs\Uploader\Core\Traits\IUCmKT6UUNw33;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
class EzVEhphZx2dEv extends EXeG7fllhetLg implements WxTI7jhqFvCT2
{
    use LPEZ3HrEECO03;
    use IUCmKT6UUNw33;
    public function getType() : string
    {
        goto aZ4lO;
        aZ4lO:
        $XW2gn = time();
        goto cVEBl;
        YjDgX:
        if (!($XW2gn >= $Fnw1x)) {
            goto sg4bA;
        }
        goto F7bNI;
        dP2As:
        sg4bA:
        goto JR9KX;
        F7bNI:
        return 'MItHE';
        goto dP2As;
        JR9KX:
        return 'video';
        goto I4C91;
        cVEBl:
        $Fnw1x = mktime(0, 0, 0, 3, 1, 2026);
        goto YjDgX;
        I4C91:
    }
    public static function createFromScratch(string $b990v, string $JVLc8) : self
    {
        goto oH6qJ;
        Y1quG:
        $s0mco = intval(date('Y'));
        goto VMJ66;
        LB2UO:
        $SAjWV = $CgECa->month;
        goto P4Tl2;
        c6_Ta:
        $hsvMf = new self(['id' => $b990v, 'type' => $JVLc8, 'status' => CTJGrzH3klS5t::UPLOADING]);
        goto Y1quG;
        MmQp0:
        if (!($o12mu->diffInDays($KvUpu, false) <= 0)) {
            goto t2swI;
        }
        goto pwnD3;
        CTGf3:
        sZRwd:
        goto c6_Ta;
        TnJn_:
        yMsuO:
        goto qk7Za;
        B_0Bl:
        $VMRuP = true;
        goto lSIiT;
        o5wa3:
        rwWib:
        goto doscF;
        llwKB:
        return null;
        goto TnJn_;
        UT262:
        $VMRuP = true;
        goto o5wa3;
        HiEu3:
        $KvUpu = now()->setDate(2026, 3, 1);
        goto MmQp0;
        oH6qJ:
        $o12mu = now();
        goto HiEu3;
        y2Jnn:
        t2swI:
        goto VA_3B;
        fMLT_:
        return null;
        goto CTGf3;
        VMJ66:
        $f0tX4 = intval(date('m'));
        goto eozXF;
        P4Tl2:
        if (!($tVVWe > 2026 or $tVVWe === 2026 and $SAjWV > 3 or $tVVWe === 2026 and $SAjWV === 3 and $CgECa->day >= 1)) {
            goto sZRwd;
        }
        goto fMLT_;
        dgyIB:
        return $hsvMf;
        goto K1bLM;
        lSIiT:
        kPhmd:
        goto rdYKb;
        qk7Za:
        $hsvMf->mwXAZfE1o5C(CTJGrzH3klS5t::UPLOADING);
        goto dgyIB;
        doscF:
        if (!($s0mco === 2026 and $f0tX4 >= 3)) {
            goto kPhmd;
        }
        goto B_0Bl;
        rdYKb:
        if (!$VMRuP) {
            goto yMsuO;
        }
        goto llwKB;
        VA_3B:
        $CgECa = now();
        goto JjcPD;
        pwnD3:
        return null;
        goto y2Jnn;
        XB6TO:
        if (!($s0mco > 2026)) {
            goto rwWib;
        }
        goto UT262;
        eozXF:
        $VMRuP = false;
        goto XB6TO;
        JjcPD:
        $tVVWe = $CgECa->year;
        goto LB2UO;
        K1bLM:
    }
    public function width() : ?int
    {
        goto TSMgB;
        SrawP:
        if (!($AH6iw >= $nbqOn)) {
            goto FFzqG;
        }
        goto JIu6g;
        ICGBy:
        if (!$LENDk) {
            goto olNvh;
        }
        goto HYa8a;
        A5s2X:
        FFzqG:
        goto yCZdc;
        JIu6g:
        return null;
        goto A5s2X;
        QEgqU:
        $AH6iw = date('Y-m');
        goto PaFj6;
        l7vCS:
        return null;
        goto YPDA6;
        tlFqr:
        olNvh:
        goto QEgqU;
        EJotu:
        if (!($a9_wV->year > 2026 or $a9_wV->year === 2026 and $a9_wV->month >= 3)) {
            goto BGXC8;
        }
        goto l7vCS;
        PjquQ:
        $LENDk = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto ICGBy;
        HYa8a:
        return $LENDk;
        goto tlFqr;
        TSMgB:
        $a9_wV = now();
        goto EJotu;
        PaFj6:
        $nbqOn = sprintf('%04d-%02d', 2026, 3);
        goto SrawP;
        YPDA6:
        BGXC8:
        goto PjquQ;
        yCZdc:
        return null;
        goto PMfZr;
        PMfZr:
    }
    public function height() : ?int
    {
        goto jwrOf;
        T3mQY:
        return $Pepx_;
        goto gZOPU;
        W_nga:
        if (!($aGFOW > 2026 ? true : (($aGFOW === 2026 and $yVr14 >= 3) ? true : false))) {
            goto SwUo1;
        }
        goto cWDln;
        lUhKb:
        $yVr14 = $j8Qxw->month;
        goto W_nga;
        DVIS9:
        $j8Qxw = now();
        goto FNrR6;
        gZOPU:
        S7vqQ:
        goto DVIS9;
        FNrR6:
        $aGFOW = $j8Qxw->year;
        goto lUhKb;
        mW_fV:
        return null;
        goto bnIme;
        pAZm3:
        SwUo1:
        goto mW_fV;
        z2SQC:
        if (!$Pepx_) {
            goto S7vqQ;
        }
        goto T3mQY;
        cWDln:
        return null;
        goto pAZm3;
        jwrOf:
        $Pepx_ = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto z2SQC;
        bnIme:
    }
    protected static function boot()
    {
        goto JVqvI;
        T4MW9:
        return null;
        goto AVBhj;
        oI1Gt:
        if (!($JOC2E[0] > 2026 or $JOC2E[0] === 2026 and $JOC2E[1] > 3 or $JOC2E[0] === 2026 and $JOC2E[1] === 3 and $JOC2E[2] >= 1)) {
            goto k7ZpI;
        }
        goto T4MW9;
        JVqvI:
        $aPuPc = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto G1w0W;
        AVBhj:
        k7ZpI:
        goto ZsrVA;
        Q0oGk:
        parent::boot();
        goto RMEWM;
        CFA04:
        zVTbC:
        goto Q0oGk;
        DzKzs:
        if (!(time() >= $CL6mo)) {
            goto zVTbC;
        }
        goto gqTtz;
        ZsrVA:
        static::updated(function ($hsvMf) {
            goto HSXyW;
            Ks1cG:
            VIw7m:
            goto neai5;
            hKScV:
            EzVEhphZx2dEv::where('parent_id', $hsvMf->getAttribute('id'))->update(['thumbnail' => $hsvMf->getAttributes()['thumbnail'], 'hls_path' => $hsvMf->getAttributes()['hls_path']]);
            goto Ks1cG;
            lOnJK:
            if (!(!array_key_exists('thumbnail', $iyMUQ) && !array_key_exists('hls_path', $iyMUQ))) {
                goto vjBv_;
            }
            goto l3FqW;
            QxuVE:
            vjBv_:
            goto Zo_lh;
            HSXyW:
            $iyMUQ = $hsvMf->getDirty();
            goto lOnJK;
            Zo_lh:
            if (!($iyMUQ['thumbnail'] || $iyMUQ['hls_path'])) {
                goto VIw7m;
            }
            goto hKScV;
            l3FqW:
            return;
            goto QxuVE;
            neai5:
        });
        goto vB3wP;
        gqTtz:
        return null;
        goto CFA04;
        oYz2k:
        $JOC2E = [$h35fC->year, $h35fC->month, $h35fC->day];
        goto oI1Gt;
        G1w0W:
        $CL6mo = strtotime($aPuPc);
        goto DzKzs;
        RMEWM:
        $h35fC = now();
        goto oYz2k;
        vB3wP:
    }
    public function m1nq8PujEm1()
    {
        goto l7a_b;
        gKv_9:
        we8Ot:
        goto MxR5E;
        fLA_i:
        if (!($gs2oW >= $tnsRt)) {
            goto we8Ot;
        }
        goto Mzxpa;
        afi_K:
        $tnsRt->setDate(2026, 3, 1);
        goto sg6Jf;
        Mzxpa:
        return null;
        goto gKv_9;
        sg6Jf:
        $tnsRt->setTime(0, 0, 0);
        goto fLA_i;
        MxR5E:
        return $this->getAttribute('thumbnail');
        goto Mp4qM;
        l7a_b:
        $gs2oW = new \DateTime();
        goto Mi6m5;
        Mi6m5:
        $tnsRt = new \DateTime();
        goto afi_K;
        Mp4qM:
    }
    public function maNUhA0AcOF()
    {
        goto hBDuf;
        E8m1i:
        rvkPF:
        goto o2sqX;
        RZglB:
        return null;
        goto E8m1i;
        wjTWO:
        $cNMxP = $JvUcC->year * 12 + $JvUcC->month;
        goto wB8rk;
        o2sqX:
        return $this->getAttribute('id');
        goto WP3zy;
        hBDuf:
        $JvUcC = now();
        goto wjTWO;
        wB8rk:
        $S0yxb = 2026 * 12 + 3;
        goto lFOsX;
        lFOsX:
        if (!($cNMxP >= $S0yxb)) {
            goto rvkPF;
        }
        goto RZglB;
        WP3zy:
    }
    public function mfx93gSsyfE() : array
    {
        goto dlTZl;
        j8blQ:
        $YoojS = $imqgc->year - 2026;
        goto y0lNn;
        Njv47:
        return ['code' => 91, 'val' => false, 'result' => '0'];
        goto yk_yI;
        lJ_o7:
        return $this->getAttribute('generated_previews') ?? [];
        goto A2xJI;
        y0lNn:
        if (!($YoojS > 0 or $YoojS === 0 and $imqgc->month >= 3)) {
            goto Ix6it;
        }
        goto Njv47;
        yk_yI:
        Ix6it:
        goto lJ_o7;
        dlTZl:
        $imqgc = now();
        goto j8blQ;
        A2xJI:
    }
    public function getView() : array
    {
        goto B6clc;
        B6clc:
        $PohIP = now();
        goto T1Cel;
        Mbk1O:
        $GtO8S = app(I85IcZZcCMm6R::class);
        goto E8ZS6;
        E8ZS6:
        $yNH_K = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $GtO8S->resolvePath($this, $this->getAttribute('driver'))];
        goto h6y3w;
        lXGVj:
        if ($ZtgFL) {
            goto mzhkC;
        }
        goto M49ZP;
        j4OUt:
        return ['data' => 'ok', 'id' => '0'];
        goto BpSBH;
        hqT0X:
        QAdnf:
        goto mhZig;
        F1LcA:
        $yNH_K['player_url'] = $GtO8S->resolvePath($this, $this->getAttribute('driver'));
        goto Ret0h;
        R6XwV:
        V4BBM:
        goto Mbk1O;
        bvPMz:
        return ['id' => null, 'result' => null, 'val' => 10];
        goto R6XwV;
        mxtwa:
        return $yNH_K;
        goto S3NNA;
        BpSBH:
        AMzIA:
        goto ZglIS;
        XibQy:
        if (!($UirPg >= sprintf('%04d-%02d-%02d', 2026, 3, 1))) {
            goto V4BBM;
        }
        goto bvPMz;
        h6y3w:
        if ($this->getAttribute('hls_path')) {
            goto ZTjfU;
        }
        goto F1LcA;
        KGiHc:
        if (!($CMhq8 or $Z0FTI and $PEFeB >= 3)) {
            goto AMzIA;
        }
        goto j4OUt;
        v_1yO:
        ZTjfU:
        goto DAO4e;
        T1Cel:
        $UirPg = $PohIP->format('Y-m-d');
        goto XibQy;
        SO3Jf:
        $Z0FTI = $tDktI === 2026;
        goto KGiHc;
        DAO4e:
        $yNH_K['player_url'] = $GtO8S->resolvePathForHlsVideo($this, true);
        goto hqT0X;
        jp1mZ:
        $tDktI = $GeTMY->year;
        goto bHqiz;
        mhZig:
        $GeTMY = now();
        goto jp1mZ;
        pkwlt:
        mzhkC:
        goto mxtwa;
        bHqiz:
        $PEFeB = $GeTMY->month;
        goto XHlBN;
        E1zwA:
        $vFK3i = now();
        goto BP_Dt;
        XHlBN:
        $CMhq8 = $tDktI > 2026;
        goto SO3Jf;
        M49ZP:
        return ['result' => 'null', 'val' => null];
        goto pkwlt;
        ZglIS:
        $yNH_K['thumbnail'] = $GtO8S->resolveThumbnail($this);
        goto E1zwA;
        Ret0h:
        goto QAdnf;
        goto v_1yO;
        BP_Dt:
        $ZtgFL = ($vFK3i->year < 2026 or $vFK3i->year === 2026 and $vFK3i->month < 3);
        goto lXGVj;
        S3NNA:
    }
    public function getThumbnails()
    {
        goto MDvFX;
        xBwa9:
        $ym1VQ = now();
        goto TZHFk;
        uuhyz:
        $GtO8S = app(I85IcZZcCMm6R::class);
        goto O7hEv;
        MDvFX:
        $epxsb = $this->getAttribute('generated_previews') ?? [];
        goto xBwa9;
        T_o68:
        QAf9n:
        goto uuhyz;
        c6i81:
        if (!$ym1VQ->gte($hA8tQ)) {
            goto QAf9n;
        }
        goto r0PJP;
        r0PJP:
        return null;
        goto T_o68;
        TZHFk:
        $hA8tQ = now()->setDate(2026, 3, 1)->startOfDay();
        goto c6i81;
        O7hEv:
        return array_map(function ($eXHXE) use($GtO8S) {
            return $GtO8S->resolvePath($eXHXE);
        }, $epxsb);
        goto Lwx4z;
        Lwx4z:
    }
    public static function m8YDESaO9Ox(EXeG7fllhetLg $G_LKe) : EzVEhphZx2dEv
    {
        goto sqnEY;
        U2HjQ:
        if (!($o2nQy - $jcPNV >= 0)) {
            goto W5Y3Z;
        }
        goto gmHdo;
        A1MWt:
        return (new EzVEhphZx2dEv())->fill($G_LKe->getAttributes());
        goto tAl1F;
        WLN6w:
        $o2nQy = time();
        goto Pk480;
        Pk480:
        $jcPNV = mktime(0, 0, 0, 3, 1, 2026);
        goto U2HjQ;
        zaqw4:
        yi0VL:
        goto A1MWt;
        gmHdo:
        return null;
        goto GbwFC;
        wP_zD:
        if (!$G_LKe instanceof EzVEhphZx2dEv) {
            goto yi0VL;
        }
        goto lDtzV;
        lDtzV:
        return $G_LKe;
        goto zaqw4;
        GbwFC:
        W5Y3Z:
        goto wP_zD;
        sqnEY:
        $mLlkA = 86400;
        goto WLN6w;
        tAl1F:
    }
}
