<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\Observer\DRnwpVXsvb0a0;
use Jfs\Uploader\Core\FB4qGXxRRUqXX;
use Jfs\Uploader\Core\Traits\TnNY4fLhv6Gl5;
use Jfs\Uploader\Core\Traits\Jvq5Oxs9eu5n3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Exception\JcxKbdowoFJnP;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Exception\Hs8uHMlcZHaHS;
use Jfs\Uploader\Service\S0Eg4TIBvz6Wk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class JNVd14WbS7J31 implements N6d9ndnX4hqae
{
    use TnNY4fLhv6Gl5;
    use Jvq5Oxs9eu5n3;
    private $B9TSK;
    private function __construct($z620p, $ftmEm)
    {
        $this->SnpXu = $z620p;
        $this->sWH3A = $ftmEm;
    }
    private function meIx4QRy6Xp(string $Ba5m3, $ftmEm, $ZIdyH, bool $j35LT = false) : void
    {
        $this->mRlOizT0SxG(new DRnwpVXsvb0a0($this, $ftmEm, $ZIdyH, $Ba5m3, $j35LT));
    }
    public function getFile()
    {
        return $this->SnpXu;
    }
    public function mdcD4JdtpGn(array $W0rIe) : void
    {
        $this->B9TSK = $W0rIe;
    }
    public function mGSEj9gXQjR() : void
    {
        $this->mmjJCJ3ck7B(QE1dzvgcPWV6R::UPLOADING);
    }
    public function mRPr5DiMacW() : void
    {
        $this->mmjJCJ3ck7B(QE1dzvgcPWV6R::UPLOADED);
    }
    public function mKRSYThlX7Q() : void
    {
        $this->mmjJCJ3ck7B(QE1dzvgcPWV6R::PROCESSING);
    }
    public function mquRbyd079o() : void
    {
        $this->mmjJCJ3ck7B(QE1dzvgcPWV6R::FINISHED);
    }
    public function m7ENYq6iRcE() : void
    {
        $this->mmjJCJ3ck7B(QE1dzvgcPWV6R::ABORTED);
    }
    public function mu3g2CSVJ9h() : array
    {
        return $this->B9TSK;
    }
    public static function m8oJUULbBkM(string $SEOXv, $OIyd0, $KKbEP, $Ba5m3) : self
    {
        goto Ftyjz;
        Ftyjz:
        $z620p = App::make(S0Eg4TIBvz6Wk::class)->mU3n1Ivg8jW(FB4qGXxRRUqXX::m8Fi26WGLR3($SEOXv));
        goto Snkf0;
        uarPG:
        $HsqQX->m5qfukNPanz(QE1dzvgcPWV6R::UPLOADING);
        goto IMnJl;
        IMnJl:
        return $HsqQX->mi4kj4p8vux();
        goto rny0X;
        Snkf0:
        $HsqQX = new self($z620p, $OIyd0);
        goto znLUs;
        znLUs:
        $HsqQX->meIx4QRy6Xp($Ba5m3, $OIyd0, $KKbEP);
        goto uarPG;
        rny0X:
    }
    public static function m7yAyRmGtiO($z620p, $ftmEm, $ZIdyH, $Ba5m3, $j35LT = false) : self
    {
        goto ghzRb;
        fNMlH:
        $HsqQX->meIx4QRy6Xp($Ba5m3, $ftmEm, $ZIdyH, $j35LT);
        goto XxHRM;
        oEiuK:
        return $HsqQX;
        goto T1Qyj;
        XxHRM:
        $HsqQX->m5qfukNPanz(QE1dzvgcPWV6R::UPLOADING);
        goto oEiuK;
        ghzRb:
        $HsqQX = new self($z620p, $ftmEm);
        goto fNMlH;
        T1Qyj:
    }
}
