<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Contracts\NTBMTa29AeaJq;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\Traits\A6wERosUOJgWZ;
use backup\Uploader\Core\Traits\Fk7u5grtM5kGF;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Service\QHNWNb4yKCpvh;
class CrEYqpC23XUGo extends PJqa0Yy2jwBHe implements VnrpqIkXJe1mn
{
    use A6wERosUOJgWZ;
    use Fk7u5grtM5kGF;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $IMDKn, string $ISfDH) : self
    {
        goto rYA1t;
        imqkY:
        $ulojh->mV7ZhSMguWB(Aetm2HiFuJE34::UPLOADING);
        goto XzaIz;
        XzaIz:
        return $ulojh;
        goto uelCW;
        rYA1t:
        $ulojh = new self(['id' => $IMDKn, 'type' => $ISfDH, 'status' => Aetm2HiFuJE34::UPLOADING]);
        goto imqkY;
        uelCW:
    }
    public function getView() : array
    {
        $ddgk2 = app(NTBMTa29AeaJq::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $ddgk2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $ddgk2->resolveThumbnail($this)];
    }
    public static function mFbCs9BPJ4Y(PJqa0Yy2jwBHe $JFGfH) : CrEYqpC23XUGo
    {
        goto fTPdl;
        VmyRc:
        return $JFGfH;
        goto fryYk;
        WszRk:
        return (new CrEYqpC23XUGo())->fill($JFGfH->getAttributes());
        goto EsBnM;
        fTPdl:
        if (!$JFGfH instanceof CrEYqpC23XUGo) {
            goto Mezj3;
        }
        goto VmyRc;
        fryYk:
        Mezj3:
        goto WszRk;
        EsBnM:
    }
}
