<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
final class XlkXvlTYaUWJ1
{
    public $filename;
    public $L2IE8;
    public $jjihG;
    public $taYQP;
    public $w2zTJ;
    public $bPDIv;
    public $QULrr;
    public $status;
    public $wzfk6;
    public $LwfXc;
    public $driver = 's3';
    public $nRuh8 = [];
    public function __construct($OQDtH, $lCXAT, $AqJic, $cxbAu, $pYJII, $a2L2v, $UMM3E, $KARcZ, $NURhE, $I0nMz, $LvK26 = 's3', $FvGiZ = [])
    {
        goto L07Va;
        L07Va:
        $this->filename = $OQDtH;
        goto okn37;
        S7KPc:
        $this->bPDIv = $a2L2v;
        goto oK9oS;
        ODNQP:
        $this->nRuh8 = $FvGiZ;
        goto rWx2x;
        okn37:
        $this->L2IE8 = $lCXAT;
        goto ZFCDr;
        Jr0FK:
        $this->w2zTJ = $pYJII;
        goto S7KPc;
        ZFCDr:
        $this->jjihG = $AqJic;
        goto LW9id;
        jd2fx:
        $this->status = $KARcZ;
        goto wl91w;
        LW9id:
        $this->taYQP = $cxbAu;
        goto Jr0FK;
        wl91w:
        $this->wzfk6 = $NURhE;
        goto OHs5h;
        oK9oS:
        $this->QULrr = $UMM3E;
        goto jd2fx;
        OHs5h:
        $this->LwfXc = $I0nMz;
        goto CIU6V;
        CIU6V:
        $this->driver = $LvK26;
        goto ODNQP;
        rWx2x:
    }
    private static function mXmJvLq5iAW() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function m098TlktqxP() : array
    {
        return array_flip(self::mXmJvLq5iAW());
    }
    public function toArray() : array
    {
        $h926k = self::mXmJvLq5iAW();
        return [$h926k['filename'] => $this->filename, $h926k['fileExtension'] => $this->L2IE8, $h926k['mimeType'] => $this->jjihG, $h926k['fileSize'] => $this->taYQP, $h926k['chunkSize'] => $this->w2zTJ, $h926k['checksums'] => $this->bPDIv, $h926k['totalChunk'] => $this->QULrr, $h926k['status'] => $this->status, $h926k['userId'] => $this->wzfk6, $h926k['uploadId'] => $this->LwfXc, $h926k['driver'] => $this->driver, $h926k['parts'] => $this->nRuh8];
    }
    public static function moch7tA6Ebz(array $syWxp) : self
    {
        $Q8_gP = array_flip(self::m098TlktqxP());
        return new self($syWxp[$Q8_gP['filename']] ?? $syWxp['filename'] ?? '', $syWxp[$Q8_gP['fileExtension']] ?? $syWxp['fileExtension'] ?? '', $syWxp[$Q8_gP['mimeType']] ?? $syWxp['mimeType'] ?? '', $syWxp[$Q8_gP['fileSize']] ?? $syWxp['fileSize'] ?? 0, $syWxp[$Q8_gP['chunkSize']] ?? $syWxp['chunkSize'] ?? 0, $syWxp[$Q8_gP['checksums']] ?? $syWxp['checksums'] ?? [], $syWxp[$Q8_gP['totalChunk']] ?? $syWxp['totalChunk'] ?? 0, $syWxp[$Q8_gP['status']] ?? $syWxp['status'] ?? 0, $syWxp[$Q8_gP['userId']] ?? $syWxp['userId'] ?? 0, $syWxp[$Q8_gP['uploadId']] ?? $syWxp['uploadId'] ?? '', $syWxp[$Q8_gP['driver']] ?? $syWxp['driver'] ?? 's3', $syWxp[$Q8_gP['parts']] ?? $syWxp['parts'] ?? []);
    }
    public static function m8FyGRJIBo2($LYQFx) : self
    {
        goto wNYGU;
        gXohQ:
        lXz7W:
        goto SxQ82;
        QMmxW:
        return self::moch7tA6Ebz($LYQFx);
        goto gXohQ;
        SxQ82:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto rNyxG;
        wNYGU:
        if (!(isset($LYQFx['fn']) || isset($LYQFx['fe']))) {
            goto lXz7W;
        }
        goto QMmxW;
        rNyxG:
    }
    public function mRBZ72cnJM7(string $I0nMz) : void
    {
        $this->LwfXc = $I0nMz;
    }
    public function mxgcnkdEArR(array $FvGiZ) : void
    {
        $this->nRuh8 = $FvGiZ;
    }
    public static function mD3voKrVL5W($cNpq7, $OTiq3, $Y3vd4, $NURhE, $pYJII, $a2L2v, $LvK26)
    {
        return new self($cNpq7->getFilename(), $cNpq7->getExtension(), $OTiq3, $Y3vd4, $pYJII, $a2L2v, count($a2L2v), FmSSI1JLQCp0W::UPLOADING, $NURhE, 0, $LvK26, []);
    }
    public static function myM8iTLiY7F($EmnXX)
    {
        return 'metadata/' . $EmnXX . '.json';
    }
    public function mz7vW5seO1n()
    {
        return 's3' === $this->driver ? Tfi7lQDVWUJD9::S3 : Tfi7lQDVWUJD9::LOCAL;
    }
}
