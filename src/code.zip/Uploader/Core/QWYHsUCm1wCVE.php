<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Contracts\GN9q1LiHnFGKa;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Traits\L5mR6rHm99iIZ;
use Jfs\Uploader\Core\Traits\G5NBCB8i1Emes;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Service\P4kAqVwxHUI1r;
class QWYHsUCm1wCVE extends UXdXfw71iQGkx implements RsTEqK0aKnthE
{
    use L5mR6rHm99iIZ;
    use G5NBCB8i1Emes;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $r7rVx, string $NTkTt) : self
    {
        goto fyJDg;
        fyJDg:
        $cVkmY = new self(['id' => $r7rVx, 'type' => $NTkTt, 'status' => HGmeWpZQSxAlO::UPLOADING]);
        goto PU6Mp;
        PU6Mp:
        $cVkmY->mf3bcS2aSK5(HGmeWpZQSxAlO::UPLOADING);
        goto F8CX9;
        F8CX9:
        return $cVkmY;
        goto mOHyk;
        mOHyk:
    }
    public function getView() : array
    {
        $qqQzb = app(GN9q1LiHnFGKa::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $qqQzb->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $qqQzb->resolveThumbnail($this)];
    }
    public static function mi0oPfAJa4u(UXdXfw71iQGkx $xlFVb) : QWYHsUCm1wCVE
    {
        goto PYOMq;
        qnt4t:
        return $xlFVb;
        goto GlqyQ;
        GygH5:
        return (new QWYHsUCm1wCVE())->fill($xlFVb->getAttributes());
        goto bLzSe;
        PYOMq:
        if (!$xlFVb instanceof QWYHsUCm1wCVE) {
            goto te1R1;
        }
        goto qnt4t;
        GlqyQ:
        te1R1:
        goto GygH5;
        bLzSe:
    }
}
