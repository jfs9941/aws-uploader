<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Contracts\Jhd15nso8PpYk;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\Traits\EhgHLZ3CNJJzA;
use Jfs\Uploader\Core\Traits\WUrQs9Ut05sJV;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
class NYx4mhlHSMgHF extends Rqw1PJIt1YU1r implements ZE3znzkASutzh
{
    use EhgHLZ3CNJJzA;
    use WUrQs9Ut05sJV;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $Xvgj6, string $xKIEz) : self
    {
        goto Nwg50;
        fHsJJ:
        $JhYqb->mOJCH6BWZYm(TSfaBZEUMcbl0::UPLOADING);
        goto Zaq7d;
        Nwg50:
        $JhYqb = new self(['id' => $Xvgj6, 'type' => $xKIEz, 'status' => TSfaBZEUMcbl0::UPLOADING]);
        goto fHsJJ;
        Zaq7d:
        return $JhYqb;
        goto HrfGR;
        HrfGR:
    }
    public function width() : ?int
    {
        goto zQk_s;
        b53dj:
        Fp01f:
        goto WEvkE;
        CWy8b:
        if (!$ZJYlg) {
            goto Fp01f;
        }
        goto zYJKW;
        zYJKW:
        return $ZJYlg;
        goto b53dj;
        WEvkE:
        return null;
        goto luuEn;
        zQk_s:
        $ZJYlg = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto CWy8b;
        luuEn:
    }
    public function height() : ?int
    {
        goto TlSAI;
        G8kLS:
        if (!$RFX4H) {
            goto uxT0a;
        }
        goto rNdsd;
        rNdsd:
        return $RFX4H;
        goto zarcD;
        TlSAI:
        $RFX4H = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto G8kLS;
        zarcD:
        uxT0a:
        goto jzv8K;
        jzv8K:
        return null;
        goto WjRMO;
        WjRMO:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($JhYqb) {
            goto UK6ZN;
            u7kdL:
            if (!($EiSiP['thumbnail'] || $EiSiP['hls_path'])) {
                goto SdLqD;
            }
            goto a82pU;
            gTaUF:
            return;
            goto NmQvc;
            PKH9l:
            SdLqD:
            goto XAzKH;
            a82pU:
            NYx4mhlHSMgHF::where('parent_id', $JhYqb->getAttribute('id'))->update(['thumbnail' => $JhYqb->getAttributes()['thumbnail'], 'hls_path' => $JhYqb->getAttributes()['hls_path']]);
            goto PKH9l;
            UK6ZN:
            $EiSiP = $JhYqb->getDirty();
            goto P0FQe;
            NmQvc:
            S8T_K:
            goto u7kdL;
            P0FQe:
            if (!(!array_key_exists('thumbnail', $EiSiP) && !array_key_exists('hls_path', $EiSiP))) {
                goto S8T_K;
            }
            goto gTaUF;
            XAzKH:
        });
    }
    public function mmDmdMPkxOx()
    {
        return $this->getAttribute('thumbnail');
    }
    public function msk9QpStpg5()
    {
        return $this->getAttribute('id');
    }
    public function moeITb3KNRY() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto JjI3Y;
        Byj_z:
        $HjRng['player_url'] = $qjixA->resolvePath($this, $this->getAttribute('driver'));
        goto uEHK8;
        rD_pc:
        $HjRng['thumbnail'] = $qjixA->resolveThumbnail($this);
        goto NS2Mc;
        Ip8wn:
        $HjRng = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $qjixA->resolvePath($this, $this->getAttribute('driver'))];
        goto CiwiO;
        JjI3Y:
        $qjixA = app(Jhd15nso8PpYk::class);
        goto Ip8wn;
        sQnv1:
        $HjRng['player_url'] = $qjixA->resolvePathForHlsVideo($this, true);
        goto izXIy;
        qSv7j:
        LbM_4:
        goto sQnv1;
        uEHK8:
        goto aE9kG;
        goto qSv7j;
        NS2Mc:
        return $HjRng;
        goto D0bCv;
        CiwiO:
        if ($this->getAttribute('hls_path')) {
            goto LbM_4;
        }
        goto Byj_z;
        izXIy:
        aE9kG:
        goto rD_pc;
        D0bCv:
    }
    public function getThumbnails()
    {
        goto JRqr9;
        rFmQB:
        $qjixA = app(Jhd15nso8PpYk::class);
        goto zHYBh;
        JRqr9:
        $Ymu3O = $this->getAttribute('generated_previews') ?? [];
        goto rFmQB;
        zHYBh:
        return array_map(function ($f_EWh) use($qjixA) {
            return $qjixA->resolvePath($f_EWh);
        }, $Ymu3O);
        goto OfAil;
        OfAil:
    }
    public static function mMoUlTr9I2a(Rqw1PJIt1YU1r $ift9y) : NYx4mhlHSMgHF
    {
        goto XUy3e;
        XUy3e:
        if (!$ift9y instanceof NYx4mhlHSMgHF) {
            goto kM6ZF;
        }
        goto eb2IB;
        QzxhP:
        return (new NYx4mhlHSMgHF())->fill($ift9y->getAttributes());
        goto H4H3Q;
        MSCVz:
        kM6ZF:
        goto QzxhP;
        eb2IB:
        return $ift9y;
        goto MSCVz;
        H4H3Q:
    }
}
