<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
final class XxIkOu3r3u4yJ
{
    public $filename;
    public $dvco0;
    public $KywSn;
    public $mx_ve;
    public $kar4X;
    public $ho3rM;
    public $OkOje;
    public $status;
    public $GUGNm;
    public $ROwMs;
    public $Sc6J1 = 's3';
    public $AKW4f = [];
    public function __construct($f5TwW, $pF_y5, $e5iKR, $xwGwo, $Hg1G3, $sF841, $juviZ, $pU9SE, $E3Fxu, $lt0mW, $N4v2t = 's3', $IovhQ = [])
    {
        goto I1qKx;
        YnErI:
        $this->KywSn = $e5iKR;
        goto oyIfN;
        cg6SV:
        $this->ROwMs = $lt0mW;
        goto yPdf2;
        XcBrf:
        $this->ho3rM = $sF841;
        goto MX3By;
        I1qKx:
        $this->filename = $f5TwW;
        goto DrhuQ;
        Er86C:
        $this->kar4X = $Hg1G3;
        goto XcBrf;
        HLgL2:
        $this->status = $pU9SE;
        goto dYUSz;
        MX3By:
        $this->OkOje = $juviZ;
        goto HLgL2;
        dYUSz:
        $this->GUGNm = $E3Fxu;
        goto cg6SV;
        DrhuQ:
        $this->dvco0 = $pF_y5;
        goto YnErI;
        yPdf2:
        $this->Sc6J1 = $N4v2t;
        goto OL4JF;
        OL4JF:
        $this->AKW4f = $IovhQ;
        goto u2vd1;
        oyIfN:
        $this->mx_ve = $xwGwo;
        goto Er86C;
        u2vd1:
    }
    private static function m9GCsmNQqn4() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function my7tIPS0l0y() : array
    {
        return array_flip(self::m9GCsmNQqn4());
    }
    public function toArray() : array
    {
        $S0aBp = self::m9GCsmNQqn4();
        return [$S0aBp['filename'] => $this->filename, $S0aBp['fileExtension'] => $this->dvco0, $S0aBp['mimeType'] => $this->KywSn, $S0aBp['fileSize'] => $this->mx_ve, $S0aBp['chunkSize'] => $this->kar4X, $S0aBp['checksums'] => $this->ho3rM, $S0aBp['totalChunk'] => $this->OkOje, $S0aBp['status'] => $this->status, $S0aBp['userId'] => $this->GUGNm, $S0aBp['uploadId'] => $this->ROwMs, $S0aBp['driver'] => $this->Sc6J1, $S0aBp['parts'] => $this->AKW4f];
    }
    public static function mby1e5w9dvl(array $s0Y6I) : self
    {
        $j5TVZ = array_flip(self::my7tIPS0l0y());
        return new self($s0Y6I[$j5TVZ['filename']] ?? $s0Y6I['filename'] ?? '', $s0Y6I[$j5TVZ['fileExtension']] ?? $s0Y6I['fileExtension'] ?? '', $s0Y6I[$j5TVZ['mimeType']] ?? $s0Y6I['mimeType'] ?? '', $s0Y6I[$j5TVZ['fileSize']] ?? $s0Y6I['fileSize'] ?? 0, $s0Y6I[$j5TVZ['chunkSize']] ?? $s0Y6I['chunkSize'] ?? 0, $s0Y6I[$j5TVZ['checksums']] ?? $s0Y6I['checksums'] ?? [], $s0Y6I[$j5TVZ['totalChunk']] ?? $s0Y6I['totalChunk'] ?? 0, $s0Y6I[$j5TVZ['status']] ?? $s0Y6I['status'] ?? 0, $s0Y6I[$j5TVZ['userId']] ?? $s0Y6I['userId'] ?? 0, $s0Y6I[$j5TVZ['uploadId']] ?? $s0Y6I['uploadId'] ?? '', $s0Y6I[$j5TVZ['driver']] ?? $s0Y6I['driver'] ?? 's3', $s0Y6I[$j5TVZ['parts']] ?? $s0Y6I['parts'] ?? []);
    }
    public static function mtqR12H52AU($fd5NH) : self
    {
        goto hqwMt;
        hqwMt:
        if (!(isset($fd5NH['fn']) || isset($fd5NH['fe']))) {
            goto RCrNB;
        }
        goto O3ecw;
        O3ecw:
        return self::mby1e5w9dvl($fd5NH);
        goto RODjJ;
        RODjJ:
        RCrNB:
        goto mSfAS;
        mSfAS:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto QnMcY;
        QnMcY:
    }
    public function mm4W6bXFGdY(string $lt0mW) : void
    {
        $this->ROwMs = $lt0mW;
    }
    public function mJUDWybeVPc(array $IovhQ) : void
    {
        $this->AKW4f = $IovhQ;
    }
    public static function mS8DGJOmSpO($k2MU3, $OHboS, $srVys, $E3Fxu, $Hg1G3, $sF841, $N4v2t)
    {
        return new self($k2MU3->getFilename(), $k2MU3->getExtension(), $OHboS, $srVys, $Hg1G3, $sF841, count($sF841), A9q1Lm9l5QixG::UPLOADING, $E3Fxu, 0, $N4v2t, []);
    }
    public static function mCDEbHkhoSq($N2oAf)
    {
        return 'metadata/' . $N2oAf . '.json';
    }
    public function mR1UAaczC6v()
    {
        return 's3' === $this->Sc6J1 ? I5kpK7wkbRQvu::S3 : I5kpK7wkbRQvu::LOCAL;
    }
}
