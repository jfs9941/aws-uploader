<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\Observer\Ap6OmMu8ktKtp;
use Jfs\Uploader\Core\HH3lB6zqpldAM;
use Jfs\Uploader\Core\Traits\JfXCFnzVYQAiL;
use Jfs\Uploader\Core\Traits\LkAAxyhGgmAFk;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Exception\R2XNcytHoXlGH;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Exception\Mfea9FZrXQil7;
use Jfs\Uploader\Service\Sr0k4NPxeSoLY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class I0VIwBtNAG2Lq implements FTr6mgGRFf157
{
    use JfXCFnzVYQAiL;
    use LkAAxyhGgmAFk;
    private $xOEZE;
    private function __construct($YfsmL, $d_Wiu)
    {
        $this->EA4YD = $YfsmL;
        $this->z9V_f = $d_Wiu;
    }
    private function mSbFKPEhkkn(string $O893k, $d_Wiu, $F17Nf, bool $f0DVq = false) : void
    {
        $this->mfXOzZaHn0W(new Ap6OmMu8ktKtp($this, $d_Wiu, $F17Nf, $O893k, $f0DVq));
    }
    public function getFile()
    {
        return $this->EA4YD;
    }
    public function mvKUglYPOle(array $KroEt) : void
    {
        $this->xOEZE = $KroEt;
    }
    public function mNVtShfNZH5() : void
    {
        $this->mWYAL72rhSp(LV0wDYHZInswq::UPLOADING);
    }
    public function m39s5lPmBsY() : void
    {
        $this->mWYAL72rhSp(LV0wDYHZInswq::UPLOADED);
    }
    public function mAIknZtEWxh() : void
    {
        $this->mWYAL72rhSp(LV0wDYHZInswq::PROCESSING);
    }
    public function mUjWcAtiIZU() : void
    {
        $this->mWYAL72rhSp(LV0wDYHZInswq::FINISHED);
    }
    public function mhAfcCsxAoF() : void
    {
        $this->mWYAL72rhSp(LV0wDYHZInswq::ABORTED);
    }
    public function mL5bQmqdkQa() : array
    {
        return $this->xOEZE;
    }
    public static function mHhSqUKEaDa(string $B_L9m, $cJLy1, $ATeSz, $O893k) : self
    {
        goto rkndS;
        LQOK4:
        $FXuMy->mHWfC8guF82(LV0wDYHZInswq::UPLOADING);
        goto FZcFw;
        Wvcnc:
        $FXuMy->mSbFKPEhkkn($O893k, $cJLy1, $ATeSz);
        goto LQOK4;
        NowWl:
        $FXuMy = new self($YfsmL, $cJLy1);
        goto Wvcnc;
        rkndS:
        $YfsmL = App::make(Sr0k4NPxeSoLY::class)->mDMbcPNb8m7(HH3lB6zqpldAM::m8RSRuVXPMu($B_L9m));
        goto NowWl;
        FZcFw:
        return $FXuMy->mxj0A5vEyqK();
        goto oGzgn;
        oGzgn:
    }
    public static function mmdXYFst0Sk($YfsmL, $d_Wiu, $F17Nf, $O893k, $f0DVq = false) : self
    {
        goto EfUXj;
        EfUXj:
        $FXuMy = new self($YfsmL, $d_Wiu);
        goto iDa9D;
        iDa9D:
        $FXuMy->mSbFKPEhkkn($O893k, $d_Wiu, $F17Nf, $f0DVq);
        goto fcNBj;
        ZSnMJ:
        return $FXuMy;
        goto PcOuV;
        fcNBj:
        $FXuMy->mHWfC8guF82(LV0wDYHZInswq::UPLOADING);
        goto ZSnMJ;
        PcOuV:
    }
}
