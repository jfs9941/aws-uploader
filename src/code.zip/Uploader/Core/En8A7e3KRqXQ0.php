<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Contracts\TdTpyTw87RXgQ;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\Traits\G7E8tu8BtZX7c;
use Jfs\Uploader\Core\Traits\WbbiNrJy3XNAD;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Service\JujbASFciElku;
class En8A7e3KRqXQ0 extends OavRsjNQCayKr implements QguGxHrrpjTia
{
    use G7E8tu8BtZX7c;
    use WbbiNrJy3XNAD;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $bl6S5, string $TlRjW) : self
    {
        goto Z_ycq;
        ucQI_:
        return $LjX82;
        goto PCMOF;
        Z_ycq:
        $LjX82 = new self(['id' => $bl6S5, 'type' => $TlRjW, 'status' => IOEDyer18cpSA::UPLOADING]);
        goto Vh_2k;
        Vh_2k:
        $LjX82->mC8nuYteIk4(IOEDyer18cpSA::UPLOADING);
        goto ucQI_;
        PCMOF:
    }
    public function getView() : array
    {
        $XXXuf = app(TdTpyTw87RXgQ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $XXXuf->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $XXXuf->resolveThumbnail($this)];
    }
    public static function mianY5Xsm9l(OavRsjNQCayKr $jGsBp) : En8A7e3KRqXQ0
    {
        goto mEFjK;
        mEFjK:
        if (!$jGsBp instanceof En8A7e3KRqXQ0) {
            goto tiJX5;
        }
        goto roJje;
        hY9u1:
        tiJX5:
        goto oD7Ta;
        roJje:
        return $jGsBp;
        goto hY9u1;
        oD7Ta:
        return (new En8A7e3KRqXQ0())->fill($jGsBp->getAttributes());
        goto gcPHG;
        gcPHG:
    }
}
