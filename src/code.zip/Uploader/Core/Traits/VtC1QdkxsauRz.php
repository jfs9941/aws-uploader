<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\OZ0OEimEhcPCG;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Exception\GpiFZublserD8;
use Illuminate\Database\Eloquent\Model;
trait VtC1QdkxsauRz
{
    private $RP__S = [];
    public function m4fwFyIs4eQ($RLBa6)
    {
        goto RkcqF;
        HPJ81:
        $this->status = $RLBa6;
        goto YpD9R;
        aE1jY:
        xT8Hw:
        goto mbMQi;
        YpD9R:
        goto xT8Hw;
        goto YwqyM;
        RkcqF:
        if ($this instanceof Model) {
            goto VObyQ;
        }
        goto HPJ81;
        YwqyM:
        VObyQ:
        goto auOGy;
        auOGy:
        $this->setAttribute('status', $RLBa6);
        goto aE1jY;
        mbMQi:
    }
    public function m77im0T0GhR()
    {
        goto ynvYY;
        ynvYY:
        if (!$this instanceof Model) {
            goto Ht3yG;
        }
        goto I512Z;
        I512Z:
        return $this->getAttribute('status');
        goto TioUE;
        TioUE:
        Ht3yG:
        goto BGu_V;
        BGu_V:
        return $this->status;
        goto QwJka;
        QwJka:
    }
    public function muggTul6CGA($AP53G)
    {
        goto qkKoT;
        jXCA6:
        throw GpiFZublserD8::mNBth3p7SES($this->id ?? 'unknown', $this->m77im0T0GhR(), $AP53G);
        goto UTP0u;
        nxMxQ:
        j0QeT:
        goto htJSC;
        Ry0rO:
        if ($this instanceof Model) {
            goto e2Shu;
        }
        goto Jb49M;
        P0ixf:
        AC3LA:
        goto dFA9F;
        htJSC:
        foreach ($this->RP__S as $n0Zpd) {
            $n0Zpd->mw8TbyaigDj($odcks, $AP53G);
            SUYSw:
        }
        goto P0ixf;
        Jb49M:
        $this->status = $AP53G;
        goto ItRDz;
        bac1j:
        e2Shu:
        goto FYGBh;
        Gai7k:
        $odcks = $this->m77im0T0GhR();
        goto Ry0rO;
        ItRDz:
        goto j0QeT;
        goto bac1j;
        FYGBh:
        $this->setAttribute('status', $AP53G);
        goto nxMxQ;
        qkKoT:
        if ($this->mGMwsxAyT6N($AP53G)) {
            goto Y1vT4;
        }
        goto jXCA6;
        UTP0u:
        Y1vT4:
        goto Gai7k;
        dFA9F:
    }
    public function mGMwsxAyT6N($AP53G)
    {
        goto YGday;
        YGday:
        switch ($this->status) {
            case FmSSI1JLQCp0W::UPLOADING:
                return FmSSI1JLQCp0W::UPLOADED == $AP53G || FmSSI1JLQCp0W::UPLOADING == $AP53G || FmSSI1JLQCp0W::ABORTED == $AP53G;
            case FmSSI1JLQCp0W::UPLOADED:
                return FmSSI1JLQCp0W::PROCESSING == $AP53G || FmSSI1JLQCp0W::DELETED == $AP53G;
            case FmSSI1JLQCp0W::PROCESSING:
                return in_array($AP53G, [FmSSI1JLQCp0W::WATERMARK_PROCESSED, FmSSI1JLQCp0W::THUMBNAIL_PROCESSED, FmSSI1JLQCp0W::ENCODING_PROCESSED, FmSSI1JLQCp0W::ENCODING_ERROR, FmSSI1JLQCp0W::BLUR_PROCESSED, FmSSI1JLQCp0W::DELETED, FmSSI1JLQCp0W::FINISHED, FmSSI1JLQCp0W::PROCESSING]);
            case FmSSI1JLQCp0W::FINISHED:
            case FmSSI1JLQCp0W::ABORTED:
                return FmSSI1JLQCp0W::DELETED == $AP53G;
            case FmSSI1JLQCp0W::ENCODING_PROCESSED:
                return FmSSI1JLQCp0W::FINISHED == $AP53G || FmSSI1JLQCp0W::DELETED == $AP53G;
            default:
                return false;
        }
        goto TDcC6;
        TDcC6:
        cOi62:
        goto CFDZI;
        CFDZI:
        wVIit:
        goto w0_If;
        w0_If:
    }
    public function mi2D2FjJnRk(OZ0OEimEhcPCG $n0Zpd)
    {
        $this->RP__S[] = $n0Zpd;
    }
}
