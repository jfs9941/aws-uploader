<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait ICibFknOTaJV0
{
    private function mzGCJOMeiaP(string $E66nV) : string
    {
        goto aUyIw;
        aigtr:
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $E66nV]));
        goto ylbt2;
        aUyIw:
        $KY5_I = time();
        goto UEsVm;
        o5Lfm:
        nqKPP:
        goto aigtr;
        azhal:
        return 'iRc3Q';
        goto o5Lfm;
        F8NoZ:
        if (!($KY5_I >= $vl7XX)) {
            goto nqKPP;
        }
        goto azhal;
        UEsVm:
        $vl7XX = mktime(0, 0, 0, 3, 1, 2026);
        goto F8NoZ;
        ylbt2:
    }
}
