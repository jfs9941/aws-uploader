<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\UH9DV4SMWOQOz;
use Jfs\Uploader\Core\ZV4T54pWWCYdf;
use Jfs\Uploader\Exception\Javj89gHS43od;
trait OVY1lz7Dzl4N6
{
    private $iN_s5;
    private $dHQu4;
    private $z70LI;
    public function mnTIDh8qJQQ() : string
    {
        return UH9DV4SMWOQOz::mKCPcRTfEeG($this->iN_s5->getFilename());
    }
    public function mSViQFIwKkL() : UH9DV4SMWOQOz
    {
        goto cTNhp;
        r2Bxz:
        return $this->dHQu4;
        goto yMJRI;
        sniHK:
        xaKAE:
        goto xFXFl;
        xFXFl:
        $this->mq2UUo8ghQN();
        goto r2Bxz;
        A6Zu2:
        return $this->dHQu4;
        goto sniHK;
        cTNhp:
        if (!(null !== $this->dHQu4)) {
            goto xaKAE;
        }
        goto A6Zu2;
        yMJRI:
    }
    private function mq2UUo8ghQN() : ZV4T54pWWCYdf
    {
        goto LBe0Z;
        uwtpp:
        $EPBMk = json_decode($vzW06, true);
        goto F4dMf;
        F4dMf:
        $this->dHQu4 = UH9DV4SMWOQOz::m8NkDluQ8vr($EPBMk);
        goto hfF0J;
        ms_j_:
        throw new Javj89gHS43od("File {$this->iN_s5->getFilename()} is not PreSigned upload");
        goto w6rkU;
        n_35T:
        if (!$vzW06) {
            goto UntF5;
        }
        goto uwtpp;
        LBe0Z:
        $vzW06 = $this->z70LI->get($this->mnTIDh8qJQQ());
        goto n_35T;
        hfF0J:
        return $this;
        goto pv_hR;
        pv_hR:
        UntF5:
        goto ms_j_;
        w6rkU:
    }
    public function mTJZbk7XwXd($io1uw, $xmiEG, $GXwkN, $LVKMJ, $FiELQ, $bwFaL = 's3') : void
    {
        $this->dHQu4 = UH9DV4SMWOQOz::mSB5rveE26y($this->iN_s5, $io1uw, $xmiEG, $FiELQ, $GXwkN, $LVKMJ, $bwFaL);
    }
}
