<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\ZcCh1gvC4ktYJ;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Exception\VPhlMhTTl80vP;
use Illuminate\Database\Eloquent\Model;
trait YXqL8Vu76ZyNK
{
    private $MRcYm = [];
    public function m651SlcakeY($iXerz)
    {
        goto AHg90;
        uRb8x:
        $this->setAttribute('status', $iXerz);
        goto M1E4l;
        ZOu6y:
        O_fAg:
        goto uRb8x;
        qrAMR:
        $this->status = $iXerz;
        goto B_JgB;
        AHg90:
        if ($this instanceof Model) {
            goto O_fAg;
        }
        goto qrAMR;
        B_JgB:
        goto UxYKi;
        goto ZOu6y;
        M1E4l:
        UxYKi:
        goto ru1ah;
        ru1ah:
    }
    public function mAnbgmvjOCA()
    {
        goto COZXN;
        COZXN:
        if (!$this instanceof Model) {
            goto dRY9p;
        }
        goto thcjY;
        ooJNI:
        return $this->status;
        goto Qe72F;
        T5VU3:
        dRY9p:
        goto ooJNI;
        thcjY:
        return $this->getAttribute('status');
        goto T5VU3;
        Qe72F:
    }
    public function mddb9WvMqo9($phjis)
    {
        goto GFOuH;
        lh0SD:
        vj0h5:
        goto gmsdI;
        GFOuH:
        if ($this->mnlnhRwyESd($phjis)) {
            goto lhX1U;
        }
        goto DeKQR;
        gmsdI:
        foreach ($this->MRcYm as $H_8rF) {
            $H_8rF->mauAugSr89M($Zlwfi, $phjis);
            Dc1vV:
        }
        goto SizI1;
        SizI1:
        Spt1e:
        goto twR0O;
        E0gkD:
        lhX1U:
        goto UNhL2;
        VX9Nq:
        UBNY1:
        goto sdjWT;
        lcwt1:
        goto vj0h5;
        goto VX9Nq;
        UNhL2:
        $Zlwfi = $this->mAnbgmvjOCA();
        goto f3Bsb;
        sdjWT:
        $this->setAttribute('status', $phjis);
        goto lh0SD;
        f3Bsb:
        if ($this instanceof Model) {
            goto UBNY1;
        }
        goto WfcWI;
        DeKQR:
        throw VPhlMhTTl80vP::mTTrogQQCwC($this->id ?? 'unknown', $this->mAnbgmvjOCA(), $phjis);
        goto E0gkD;
        WfcWI:
        $this->status = $phjis;
        goto lcwt1;
        twR0O:
    }
    public function mnlnhRwyESd($phjis)
    {
        goto CIgC6;
        CIgC6:
        switch ($this->status) {
            case ZP6Ky842t6y9Y::UPLOADING:
                return ZP6Ky842t6y9Y::UPLOADED == $phjis || ZP6Ky842t6y9Y::UPLOADING == $phjis || ZP6Ky842t6y9Y::ABORTED == $phjis;
            case ZP6Ky842t6y9Y::UPLOADED:
                return ZP6Ky842t6y9Y::PROCESSING == $phjis || ZP6Ky842t6y9Y::DELETED == $phjis;
            case ZP6Ky842t6y9Y::PROCESSING:
                return in_array($phjis, [ZP6Ky842t6y9Y::WATERMARK_PROCESSED, ZP6Ky842t6y9Y::THUMBNAIL_PROCESSED, ZP6Ky842t6y9Y::ENCODING_PROCESSED, ZP6Ky842t6y9Y::ENCODING_ERROR, ZP6Ky842t6y9Y::BLUR_PROCESSED, ZP6Ky842t6y9Y::DELETED, ZP6Ky842t6y9Y::FINISHED, ZP6Ky842t6y9Y::PROCESSING]);
            case ZP6Ky842t6y9Y::FINISHED:
            case ZP6Ky842t6y9Y::ABORTED:
                return ZP6Ky842t6y9Y::DELETED == $phjis;
            case ZP6Ky842t6y9Y::ENCODING_PROCESSED:
                return ZP6Ky842t6y9Y::FINISHED == $phjis || ZP6Ky842t6y9Y::DELETED == $phjis;
            default:
                return false;
        }
        goto bhn3w;
        PveSE:
        t3o16:
        goto BeY2t;
        bhn3w:
        yvDOy:
        goto PveSE;
        BeY2t:
    }
    public function m2Ak24UoC8E(ZcCh1gvC4ktYJ $H_8rF)
    {
        $this->MRcYm[] = $H_8rF;
    }
}
