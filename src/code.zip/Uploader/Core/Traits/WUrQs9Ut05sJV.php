<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\IYQ9W9yMaFIDi;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Exception\FLUrTiCUjjZmC;
use Illuminate\Database\Eloquent\Model;
trait WUrQs9Ut05sJV
{
    private $N0QS_ = [];
    public function mOJCH6BWZYm($KR5Fj)
    {
        goto e8dXI;
        lvF8U:
        R4JL0:
        goto Js08E;
        kRZub:
        $this->status = $KR5Fj;
        goto k2gEp;
        k2gEp:
        goto R4JL0;
        goto XPYWs;
        jqNgs:
        $this->setAttribute('status', $KR5Fj);
        goto lvF8U;
        XPYWs:
        UJApT:
        goto jqNgs;
        e8dXI:
        if ($this instanceof Model) {
            goto UJApT;
        }
        goto kRZub;
        Js08E:
    }
    public function mG5vMQvDIJu()
    {
        goto v_qia;
        v_qia:
        if (!$this instanceof Model) {
            goto P1lFF;
        }
        goto DpVmO;
        DpVmO:
        return $this->getAttribute('status');
        goto heoGl;
        heoGl:
        P1lFF:
        goto Njies;
        Njies:
        return $this->status;
        goto KsT7t;
        KsT7t:
    }
    public function mvj3nnnI629($WWRmp)
    {
        goto dYSJg;
        koHct:
        adptz:
        goto e95c0;
        gdCaU:
        GR1MH:
        goto F_JHZ;
        oliS3:
        goto Lf21D;
        goto wOCId;
        SDD9_:
        throw FLUrTiCUjjZmC::mBjKyCB0xNm($this->id ?? 'unknown', $this->mG5vMQvDIJu(), $WWRmp);
        goto gdCaU;
        dYSJg:
        if ($this->msz7cd4Kawd($WWRmp)) {
            goto GR1MH;
        }
        goto SDD9_;
        LvLAr:
        Lf21D:
        goto hO3Pz;
        hO3Pz:
        foreach ($this->N0QS_ as $srSEY) {
            $srSEY->mX3kB2cejfz($xefuv, $WWRmp);
            iboMd:
        }
        goto koHct;
        Phn8N:
        if ($this instanceof Model) {
            goto zaQ0W;
        }
        goto nVfB5;
        nVfB5:
        $this->status = $WWRmp;
        goto oliS3;
        wOCId:
        zaQ0W:
        goto bYKwp;
        bYKwp:
        $this->setAttribute('status', $WWRmp);
        goto LvLAr;
        F_JHZ:
        $xefuv = $this->mG5vMQvDIJu();
        goto Phn8N;
        e95c0:
    }
    public function msz7cd4Kawd($WWRmp)
    {
        goto tS0EL;
        HK2KA:
        WXkkk:
        goto GaBPc;
        tS0EL:
        switch ($this->status) {
            case TSfaBZEUMcbl0::UPLOADING:
                return TSfaBZEUMcbl0::UPLOADED == $WWRmp || TSfaBZEUMcbl0::UPLOADING == $WWRmp || TSfaBZEUMcbl0::ABORTED == $WWRmp;
            case TSfaBZEUMcbl0::UPLOADED:
                return TSfaBZEUMcbl0::PROCESSING == $WWRmp || TSfaBZEUMcbl0::DELETED == $WWRmp;
            case TSfaBZEUMcbl0::PROCESSING:
                return in_array($WWRmp, [TSfaBZEUMcbl0::WATERMARK_PROCESSED, TSfaBZEUMcbl0::THUMBNAIL_PROCESSED, TSfaBZEUMcbl0::ENCODING_PROCESSED, TSfaBZEUMcbl0::ENCODING_ERROR, TSfaBZEUMcbl0::BLUR_PROCESSED, TSfaBZEUMcbl0::DELETED, TSfaBZEUMcbl0::FINISHED, TSfaBZEUMcbl0::PROCESSING]);
            case TSfaBZEUMcbl0::FINISHED:
            case TSfaBZEUMcbl0::ABORTED:
                return TSfaBZEUMcbl0::DELETED == $WWRmp;
            case TSfaBZEUMcbl0::ENCODING_PROCESSED:
                return TSfaBZEUMcbl0::FINISHED == $WWRmp || TSfaBZEUMcbl0::DELETED == $WWRmp;
            default:
                return false;
        }
        goto HK2KA;
        GaBPc:
        jvuUL:
        goto J0GbQ;
        J0GbQ:
    }
    public function m1QMTCQtDK5(IYQ9W9yMaFIDi $srSEY)
    {
        $this->N0QS_[] = $srSEY;
    }
}
