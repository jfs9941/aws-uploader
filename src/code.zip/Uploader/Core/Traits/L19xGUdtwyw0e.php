<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\HMzvJtEcyxrN7;
use Jfs\Uploader\Core\ZFuimKZywyxo2;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
trait L19xGUdtwyw0e
{
    private $pnMmg;
    private $H1GMX;
    private $IAuMz;
    public function muoWhAZBWrx() : string
    {
        return HMzvJtEcyxrN7::m4Lnp5opuAR($this->pnMmg->getFilename());
    }
    public function mf47A6FAs7u() : HMzvJtEcyxrN7
    {
        goto KjsjU;
        lNjsP:
        $this->mWZucd0nKyW();
        goto QPc1j;
        V4Po4:
        return $this->H1GMX;
        goto N3t5q;
        N3t5q:
        HS4js:
        goto lNjsP;
        KjsjU:
        if (!(null !== $this->H1GMX)) {
            goto HS4js;
        }
        goto V4Po4;
        QPc1j:
        return $this->H1GMX;
        goto pJG27;
        pJG27:
    }
    private function mWZucd0nKyW() : ZFuimKZywyxo2
    {
        goto pzUC6;
        yOUJD:
        if (!$yVlK6) {
            goto CBL6V;
        }
        goto GXtu_;
        GXtu_:
        $lVriI = json_decode($yVlK6, true);
        goto a0KBx;
        a0KBx:
        $this->H1GMX = HMzvJtEcyxrN7::mTTGVZFpaku($lVriI);
        goto Jlvuf;
        Jlvuf:
        return $this;
        goto i6Ron;
        pzUC6:
        $yVlK6 = $this->IAuMz->get($this->muoWhAZBWrx());
        goto yOUJD;
        USAWt:
        throw new Wu1EwEzrOvt3c("File {$this->pnMmg->getFilename()} is not PreSigned upload");
        goto CbTcq;
        i6Ron:
        CBL6V:
        goto USAWt;
        CbTcq:
    }
    public function miNwUSV7YyC($x3olq, $iUTFL, $S1bFz, $fkXC5, $Ps6ez, $XHDhR = 's3') : void
    {
        $this->H1GMX = HMzvJtEcyxrN7::mehuh6f6Udr($this->pnMmg, $x3olq, $iUTFL, $Ps6ez, $S1bFz, $fkXC5, $XHDhR);
    }
}
