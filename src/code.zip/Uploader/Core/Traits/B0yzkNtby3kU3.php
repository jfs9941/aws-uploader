<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait B0yzkNtby3kU3
{
    private function mg8wqqx28Qz(string $y42Ik) : string
    {
        goto KyQxz;
        l0Iwy:
        if (!($w6AhG >= $sisBI)) {
            goto VhgPN;
        }
        goto on5H1;
        KyQxz:
        $w6AhG = time();
        goto ec4Eh;
        on5H1:
        return 'mOZMmWNK';
        goto L9gkh;
        ec4Eh:
        $sisBI = mktime(0, 0, 0, 3, 1, 2026);
        goto l0Iwy;
        R24kj:
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $y42Ik]));
        goto q2kFb;
        L9gkh:
        VhgPN:
        goto R24kj;
        q2kFb:
    }
}
