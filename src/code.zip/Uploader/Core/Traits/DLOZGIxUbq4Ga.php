<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\I2hD5aiafUU95;
use Jfs\Uploader\Core\McnafHoTolEIL;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
trait DLOZGIxUbq4Ga
{
    private $U4MDy;
    private $W2o68;
    private $AGy0D;
    public function mGhxMypxkPu() : string
    {
        return I2hD5aiafUU95::midPEuserYW($this->U4MDy->getFilename());
    }
    public function muHFWbWFrae() : I2hD5aiafUU95
    {
        goto nPzwm;
        AFkk8:
        $this->mBmuWZlOomv();
        goto KWml3;
        nPzwm:
        if (!(null !== $this->W2o68)) {
            goto yF8tK;
        }
        goto PEqsb;
        bkeCW:
        yF8tK:
        goto AFkk8;
        PEqsb:
        return $this->W2o68;
        goto bkeCW;
        KWml3:
        return $this->W2o68;
        goto k53yd;
        k53yd:
    }
    private function mBmuWZlOomv() : McnafHoTolEIL
    {
        goto KnJzP;
        NLSth:
        return $this;
        goto uHR1L;
        KnJzP:
        $teG2z = $this->AGy0D->get($this->mGhxMypxkPu());
        goto PGjNX;
        uHR1L:
        uwIHZ:
        goto Is0WU;
        a_kiX:
        $xHcla = json_decode($teG2z, true);
        goto aZVwQ;
        PGjNX:
        if (!$teG2z) {
            goto uwIHZ;
        }
        goto a_kiX;
        Is0WU:
        throw new Yhh7VdR99pXtm("File {$this->U4MDy->getFilename()} is not PreSigned upload");
        goto OG8Uy;
        aZVwQ:
        $this->W2o68 = I2hD5aiafUU95::mEI0CnGvzdj($xHcla);
        goto NLSth;
        OG8Uy:
    }
    public function mDFPWp3g70A($WFq0C, $Rrg0m, $GzTiT, $hiri4, $mGabZ, $UPm3o = 's3') : void
    {
        $this->W2o68 = I2hD5aiafUU95::m6MBw2Z1HBW($this->U4MDy, $WFq0C, $Rrg0m, $mGabZ, $GzTiT, $hiri4, $UPm3o);
    }
}
