<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\VxPWGO5HkTQsP;
use Jfs\Uploader\Core\RQ9bDEqcUZdSJ;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
trait MvNzFOOLsDrZI
{
    private $XHy23;
    private $Uao25;
    private $C4IE4;
    public function mzDDruv07Tv() : string
    {
        return VxPWGO5HkTQsP::mcVXYpnXj59($this->XHy23->getFilename());
    }
    public function mg099Xaz8Vo() : VxPWGO5HkTQsP
    {
        goto F0EGx;
        OqYuB:
        $this->m6DsdjQRnTW();
        goto Fr92K;
        fpvVk:
        T1FiG:
        goto OqYuB;
        Mpsln:
        return $this->Uao25;
        goto fpvVk;
        F0EGx:
        if (!(null !== $this->Uao25)) {
            goto T1FiG;
        }
        goto Mpsln;
        Fr92K:
        return $this->Uao25;
        goto YoTlg;
        YoTlg:
    }
    private function m6DsdjQRnTW() : RQ9bDEqcUZdSJ
    {
        goto KVn2T;
        KVn2T:
        $R6n0H = $this->C4IE4->get($this->mzDDruv07Tv());
        goto R8vzB;
        LQhYC:
        $AgStn = json_decode($R6n0H, true);
        goto PjNWX;
        YZUyi:
        throw new DRgeXfZrFFnZd("File {$this->XHy23->getFilename()} is not PreSigned upload");
        goto g6_7C;
        cke00:
        return $this;
        goto fCVLW;
        PjNWX:
        $this->Uao25 = VxPWGO5HkTQsP::mMbxEMesYK0($AgStn);
        goto cke00;
        fCVLW:
        jIfgi:
        goto YZUyi;
        R8vzB:
        if (!$R6n0H) {
            goto jIfgi;
        }
        goto LQhYC;
        g6_7C:
    }
    public function mawAF9SpveM($cB3gt, $kKp4r, $cse1Q, $V_q0k, $hM9Ud, $Mf3Ow = 's3') : void
    {
        $this->Uao25 = VxPWGO5HkTQsP::mcoMW5vlk23($this->XHy23, $cB3gt, $kKp4r, $hM9Ud, $cse1Q, $V_q0k, $Mf3Ow);
    }
}
