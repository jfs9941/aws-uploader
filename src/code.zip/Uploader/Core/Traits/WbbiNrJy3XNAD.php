<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\M7qyTIw376zSo;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Exception\VwJ7WJWdWWDDp;
use Illuminate\Database\Eloquent\Model;
trait WbbiNrJy3XNAD
{
    private $IpiwP = [];
    public function mC8nuYteIk4($CyrJu)
    {
        goto Ym1ou;
        VJI6V:
        goto x09Pj;
        goto W1Ydp;
        W1Ydp:
        cFheH:
        goto QAvGf;
        Ym1ou:
        if ($this instanceof Model) {
            goto cFheH;
        }
        goto EzOz0;
        EzOz0:
        $this->status = $CyrJu;
        goto VJI6V;
        NPu1i:
        x09Pj:
        goto ze06b;
        QAvGf:
        $this->setAttribute('status', $CyrJu);
        goto NPu1i;
        ze06b:
    }
    public function mCBaFPB8Ct3()
    {
        goto T9fMs;
        j1otw:
        return $this->getAttribute('status');
        goto BImqC;
        T9fMs:
        if (!$this instanceof Model) {
            goto bCTqO;
        }
        goto j1otw;
        BImqC:
        bCTqO:
        goto lLov0;
        lLov0:
        return $this->status;
        goto HuLqE;
        HuLqE:
    }
    public function mImL6eGj9Ei($FFZ2V)
    {
        goto akVNM;
        du6mn:
        $this->setAttribute('status', $FFZ2V);
        goto weAui;
        DCisY:
        foreach ($this->IpiwP as $QIzeH) {
            $QIzeH->mCd5SPJOmmA($fbEkM, $FFZ2V);
            E3klF:
        }
        goto qxcUN;
        mLJIg:
        lzDN6:
        goto du6mn;
        weAui:
        gnrFp:
        goto DCisY;
        g_IHi:
        if ($this instanceof Model) {
            goto lzDN6;
        }
        goto Kw8KN;
        Kw8KN:
        $this->status = $FFZ2V;
        goto o_bku;
        o_bku:
        goto gnrFp;
        goto mLJIg;
        JDXOU:
        zC4yp:
        goto snFjx;
        snFjx:
        $fbEkM = $this->mCBaFPB8Ct3();
        goto g_IHi;
        ONitq:
        throw VwJ7WJWdWWDDp::m92pQpfckCQ($this->id ?? 'unknown', $this->mCBaFPB8Ct3(), $FFZ2V);
        goto JDXOU;
        qxcUN:
        yCVOV:
        goto ZXGsF;
        akVNM:
        if ($this->mTH4FAaagQg($FFZ2V)) {
            goto zC4yp;
        }
        goto ONitq;
        ZXGsF:
    }
    public function mTH4FAaagQg($FFZ2V)
    {
        goto VxI6E;
        VxI6E:
        switch ($this->status) {
            case IOEDyer18cpSA::UPLOADING:
                return IOEDyer18cpSA::UPLOADED == $FFZ2V || IOEDyer18cpSA::UPLOADING == $FFZ2V || IOEDyer18cpSA::ABORTED == $FFZ2V;
            case IOEDyer18cpSA::UPLOADED:
                return IOEDyer18cpSA::PROCESSING == $FFZ2V || IOEDyer18cpSA::DELETED == $FFZ2V;
            case IOEDyer18cpSA::PROCESSING:
                return in_array($FFZ2V, [IOEDyer18cpSA::WATERMARK_PROCESSED, IOEDyer18cpSA::THUMBNAIL_PROCESSED, IOEDyer18cpSA::ENCODING_PROCESSED, IOEDyer18cpSA::ENCODING_ERROR, IOEDyer18cpSA::BLUR_PROCESSED, IOEDyer18cpSA::DELETED, IOEDyer18cpSA::FINISHED, IOEDyer18cpSA::PROCESSING]);
            case IOEDyer18cpSA::FINISHED:
            case IOEDyer18cpSA::ABORTED:
                return IOEDyer18cpSA::DELETED == $FFZ2V;
            case IOEDyer18cpSA::ENCODING_PROCESSED:
                return IOEDyer18cpSA::FINISHED == $FFZ2V || IOEDyer18cpSA::DELETED == $FFZ2V;
            default:
                return false;
        }
        goto ps1t2;
        ps1t2:
        rM7uR:
        goto k2XHd;
        k2XHd:
        tHGyd:
        goto rlJfr;
        rlJfr:
    }
    public function m8X5yYN5PxJ(M7qyTIw376zSo $QIzeH)
    {
        $this->IpiwP[] = $QIzeH;
    }
}
