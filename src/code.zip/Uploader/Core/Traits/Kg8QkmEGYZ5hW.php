<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait Kg8QkmEGYZ5hW
{
    private function mFwCMiqQaKT(string $li4hO) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $li4hO]));
    }
}
