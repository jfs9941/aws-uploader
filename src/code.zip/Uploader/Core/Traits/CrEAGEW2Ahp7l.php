<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\TjZC83Yv3rOXg;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Exception\HF2PbTFQhW3Rr;
use Illuminate\Database\Eloquent\Model;
trait CrEAGEW2Ahp7l
{
    private $UZA2g = [];
    public function mocw0y5gdUS($dbIv9)
    {
        goto EJrGp;
        ptf89:
        $this->status = $dbIv9;
        goto FbDmC;
        e_BIX:
        $this->setAttribute('status', $dbIv9);
        goto b2PbU;
        Ayv2B:
        FTl7S:
        goto e_BIX;
        b2PbU:
        xSgIx:
        goto mow2b;
        FbDmC:
        goto xSgIx;
        goto Ayv2B;
        EJrGp:
        if ($this instanceof Model) {
            goto FTl7S;
        }
        goto ptf89;
        mow2b:
    }
    public function mjs4Xf4o0TA()
    {
        goto dP8Zi;
        qR2pc:
        return $this->status;
        goto W6x0j;
        yoKiy:
        return $this->getAttribute('status');
        goto bd5Z6;
        dP8Zi:
        if (!$this instanceof Model) {
            goto poWrI;
        }
        goto yoKiy;
        bd5Z6:
        poWrI:
        goto qR2pc;
        W6x0j:
    }
    public function mvlhr18w6fy($Hkjko)
    {
        goto EIh_2;
        fE3dF:
        $this->status = $Hkjko;
        goto x10e8;
        Fx8r_:
        QwbYO:
        goto qez8i;
        EIh_2:
        if ($this->mRMpcQ8AhNr($Hkjko)) {
            goto qiEOv;
        }
        goto WV62E;
        x10e8:
        goto QwbYO;
        goto npoKR;
        qez8i:
        foreach ($this->UZA2g as $F0DPR) {
            $F0DPR->mOZ7C9ggFcs($OxQ2x, $Hkjko);
            cOMx2:
        }
        goto FkpOI;
        h3X3O:
        qiEOv:
        goto lIVbs;
        lIVbs:
        $OxQ2x = $this->mjs4Xf4o0TA();
        goto ZwUle;
        WV62E:
        throw HF2PbTFQhW3Rr::msXMWqEcOmf($this->id ?? 'unknown', $this->mjs4Xf4o0TA(), $Hkjko);
        goto h3X3O;
        FkpOI:
        FFmo3:
        goto je8gc;
        ZwUle:
        if ($this instanceof Model) {
            goto EpVfe;
        }
        goto fE3dF;
        rNc5S:
        $this->setAttribute('status', $Hkjko);
        goto Fx8r_;
        npoKR:
        EpVfe:
        goto rNc5S;
        je8gc:
    }
    public function mRMpcQ8AhNr($Hkjko)
    {
        goto xGqtY;
        xGqtY:
        switch ($this->status) {
            case FdWrko7bmoI4Y::UPLOADING:
                return FdWrko7bmoI4Y::UPLOADED == $Hkjko || FdWrko7bmoI4Y::UPLOADING == $Hkjko || FdWrko7bmoI4Y::ABORTED == $Hkjko;
            case FdWrko7bmoI4Y::UPLOADED:
                return FdWrko7bmoI4Y::PROCESSING == $Hkjko || FdWrko7bmoI4Y::DELETED == $Hkjko;
            case FdWrko7bmoI4Y::PROCESSING:
                return in_array($Hkjko, [FdWrko7bmoI4Y::WATERMARK_PROCESSED, FdWrko7bmoI4Y::THUMBNAIL_PROCESSED, FdWrko7bmoI4Y::ENCODING_PROCESSED, FdWrko7bmoI4Y::ENCODING_ERROR, FdWrko7bmoI4Y::BLUR_PROCESSED, FdWrko7bmoI4Y::DELETED, FdWrko7bmoI4Y::FINISHED, FdWrko7bmoI4Y::PROCESSING]);
            case FdWrko7bmoI4Y::FINISHED:
            case FdWrko7bmoI4Y::ABORTED:
                return FdWrko7bmoI4Y::DELETED == $Hkjko;
            case FdWrko7bmoI4Y::ENCODING_PROCESSED:
                return FdWrko7bmoI4Y::FINISHED == $Hkjko || FdWrko7bmoI4Y::DELETED == $Hkjko;
            default:
                return false;
        }
        goto tUbIZ;
        fkA8J:
        Tuh5P:
        goto nYx2c;
        tUbIZ:
        Hk8wb:
        goto fkA8J;
        nYx2c:
    }
    public function m1RJrReO70j(TjZC83Yv3rOXg $F0DPR)
    {
        $this->UZA2g[] = $F0DPR;
    }
}
