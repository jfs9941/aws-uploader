<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\LwEuADzdXxX43;
use Jfs\Uploader\Core\ZOwA486ueqbmD;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
trait AfKE97XXxITZ0
{
    private $oWuCn;
    private $xjyKy;
    private $meUU4;
    public function mqnDxf54UN2() : string
    {
        return LwEuADzdXxX43::m16Obv6eGzx($this->oWuCn->getFilename());
    }
    public function mFmRtrLmgsB() : LwEuADzdXxX43
    {
        goto hL8vF;
        hL8vF:
        if (!(null !== $this->xjyKy)) {
            goto v7ySP;
        }
        goto iJJGf;
        AxmoB:
        v7ySP:
        goto cT064;
        Q1Ry4:
        return $this->xjyKy;
        goto GzfWK;
        iJJGf:
        return $this->xjyKy;
        goto AxmoB;
        cT064:
        $this->mqRlOWYrGFi();
        goto Q1Ry4;
        GzfWK:
    }
    private function mqRlOWYrGFi() : ZOwA486ueqbmD
    {
        goto eZSn4;
        oRws6:
        bdfLg:
        goto d7Fs5;
        d7Fs5:
        throw new GoWX7Rl7j3VtX("File {$this->oWuCn->getFilename()} is not PreSigned upload");
        goto R04Eg;
        eZSn4:
        $iyhhD = $this->meUU4->get($this->mqnDxf54UN2());
        goto flhyQ;
        ZJ64U:
        return $this;
        goto oRws6;
        flhyQ:
        if (!$iyhhD) {
            goto bdfLg;
        }
        goto xC4I4;
        mcs9p:
        $this->xjyKy = LwEuADzdXxX43::mt5WpLsIZZh($xHf7Z);
        goto ZJ64U;
        xC4I4:
        $xHf7Z = json_decode($iyhhD, true);
        goto mcs9p;
        R04Eg:
    }
    public function mq8iABfp1UB($EiWMT, $bBO7s, $P42U_, $qG1CG, $NnyAX, $hCnVR = 's3') : void
    {
        $this->xjyKy = LwEuADzdXxX43::mPfgtMh51KH($this->oWuCn, $EiWMT, $bBO7s, $NnyAX, $P42U_, $qG1CG, $hCnVR);
    }
}
