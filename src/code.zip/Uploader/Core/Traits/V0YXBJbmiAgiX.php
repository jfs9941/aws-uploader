<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\UAsHLG1mz8hdv;
use Jfs\Uploader\Core\Rfow5q0HYgflu;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
trait V0YXBJbmiAgiX
{
    private $N1jgO;
    private $EBC_O;
    private $WKvVV;
    public function mAK7MUq8SYx() : string
    {
        return UAsHLG1mz8hdv::mET7etRr7Va($this->N1jgO->getFilename());
    }
    public function mLISLvz7JU3() : UAsHLG1mz8hdv
    {
        goto zEbE2;
        s_YnP:
        OaZKr:
        goto wVtrQ;
        sTf1H:
        return $this->EBC_O;
        goto bOuR2;
        l1yr_:
        return $this->EBC_O;
        goto s_YnP;
        zEbE2:
        if (!(null !== $this->EBC_O)) {
            goto OaZKr;
        }
        goto l1yr_;
        wVtrQ:
        $this->mqtxOLuwlBz();
        goto sTf1H;
        bOuR2:
    }
    private function mqtxOLuwlBz() : Rfow5q0HYgflu
    {
        goto U32AB;
        LMb_y:
        throw new YK7fJDaVPWKzB("File {$this->N1jgO->getFilename()} is not PreSigned upload");
        goto LZiq7;
        U32AB:
        $uaciM = $this->WKvVV->get($this->mAK7MUq8SYx());
        goto dNZBC;
        P_I3K:
        return $this;
        goto zjID_;
        zjID_:
        rFSYA:
        goto LMb_y;
        Xk9tw:
        $KGxUE = json_decode($uaciM, true);
        goto zlmJQ;
        dNZBC:
        if (!$uaciM) {
            goto rFSYA;
        }
        goto Xk9tw;
        zlmJQ:
        $this->EBC_O = UAsHLG1mz8hdv::mFJii14EWHB($KGxUE);
        goto P_I3K;
        LZiq7:
    }
    public function mViFa4XEhmd($ZIlhp, $hbCdu, $PSFks, $w0yvU, $gjHtm, $WpjdV = 's3') : void
    {
        $this->EBC_O = UAsHLG1mz8hdv::mkCo10Re2W0($this->N1jgO, $ZIlhp, $hbCdu, $gjHtm, $PSFks, $w0yvU, $WpjdV);
    }
}
