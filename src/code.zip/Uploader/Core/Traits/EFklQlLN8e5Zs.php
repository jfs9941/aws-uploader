<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\RUnOaRW6FbMFN;
use Jfs\Uploader\Core\RShptJ3iNjD6n;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
trait EFklQlLN8e5Zs
{
    private $file;
    private $YQbIT;
    private $y6BD6;
    public function mTlPo4RQb1E() : string
    {
        goto K_0gp;
        UdzLu:
        $HEonk = mktime(0, 0, 0, 3, 1, 2026);
        goto tA5Tz;
        tA5Tz:
        if (!($i4uYy >= $HEonk)) {
            goto OUZKO;
        }
        goto gSXxv;
        gSXxv:
        return 'tKSAhMc';
        goto pp4pt;
        FUwnD:
        return RUnOaRW6FbMFN::mINz008xwVO($this->file->getFilename());
        goto JKi1w;
        pp4pt:
        OUZKO:
        goto FUwnD;
        K_0gp:
        $i4uYy = time();
        goto UdzLu;
        JKi1w:
    }
    public function mjSURMEZOXx() : RUnOaRW6FbMFN
    {
        goto pcJ3W;
        O980L:
        $NUKsh = now()->setDate(2026, 3, 1);
        goto AypZr;
        wStE3:
        m7Ef1:
        goto crvp1;
        N4Esr:
        $aPamp = $KhsEX->month;
        goto sDSlA;
        trMcR:
        if (!$gcFev) {
            goto Q_ha5;
        }
        goto OAvOZ;
        AypZr:
        if (!($rM7Bk->diffInDays($NUKsh, false) <= 0)) {
            goto P1PV1;
        }
        goto uwfZ5;
        kY6ly:
        m7Zp6:
        goto B2cjn;
        hl5He:
        $gcFev = false;
        goto pYNqt;
        pcJ3W:
        $rM7Bk = now();
        goto O980L;
        ZVGYH:
        $r8znN = $KhsEX->year;
        goto N4Esr;
        crvp1:
        if (!($l5cQE === 2026 and $NLr9M >= 3)) {
            goto jK_IA;
        }
        goto MIKNM;
        HYOrB:
        return null;
        goto u2RW4;
        HeOYe:
        jK_IA:
        goto trMcR;
        bVcHL:
        $l5cQE = intval(date('Y'));
        goto ul8od;
        Qktap:
        $gcFev = true;
        goto wStE3;
        OAvOZ:
        return null;
        goto iHpie;
        iHpie:
        Q_ha5:
        goto wHL3Y;
        ul8od:
        $NLr9M = intval(date('m'));
        goto hl5He;
        MIKNM:
        $gcFev = true;
        goto HeOYe;
        uwfZ5:
        return null;
        goto u3dhR;
        wHL3Y:
        $this->morQPH2pleg();
        goto aCHPY;
        u2RW4:
        bQg2Q:
        goto bVcHL;
        sDSlA:
        if (!($r8znN > 2026 or $r8znN === 2026 and $aPamp > 3 or $r8znN === 2026 and $aPamp === 3 and $KhsEX->day >= 1)) {
            goto bQg2Q;
        }
        goto HYOrB;
        u3dhR:
        P1PV1:
        goto QbaCP;
        QbaCP:
        if (!(null !== $this->YQbIT)) {
            goto m7Zp6;
        }
        goto bc3bh;
        aCHPY:
        return $this->YQbIT;
        goto MLpsO;
        bc3bh:
        return $this->YQbIT;
        goto kY6ly;
        pYNqt:
        if (!($l5cQE > 2026)) {
            goto m7Ef1;
        }
        goto Qktap;
        B2cjn:
        $KhsEX = now();
        goto ZVGYH;
        MLpsO:
    }
    private function morQPH2pleg() : RShptJ3iNjD6n
    {
        goto dqfbs;
        lHfrd:
        pxbcQ:
        goto wkgI_;
        zbf6M:
        return $this;
        goto lHfrd;
        jiDBs:
        $nHWPZ = $this->y6BD6->get($this->mTlPo4RQb1E());
        goto Up1K1;
        dqfbs:
        $dFAHP = date('Y-m');
        goto p3ROD;
        TFk07:
        if (!($dFAHP >= $qsTwe)) {
            goto kENsX;
        }
        goto HI6pk;
        p3ROD:
        $qsTwe = sprintf('%04d-%02d', 2026, 3);
        goto TFk07;
        B2BAc:
        kENsX:
        goto jiDBs;
        DcJcI:
        $this->YQbIT = RUnOaRW6FbMFN::mX12UxYuXH9($ePsKF);
        goto zbf6M;
        wkgI_:
        throw new TKLv3jf5qXCAJ("File {$this->file->getFilename()} is not PreSigned upload");
        goto GAysK;
        HI6pk:
        return null;
        goto B2BAc;
        u4NjV:
        $ePsKF = json_decode($nHWPZ, true);
        goto DcJcI;
        Up1K1:
        if (!$nHWPZ) {
            goto pxbcQ;
        }
        goto u4NjV;
        GAysK:
    }
    public function mIZWD5W66uM($SCIbS, $F8XZc, $hFM9I, $U23hP, $YWDpu, $BeDhM = 's3') : void
    {
        goto EZ0Qu;
        KNbvj:
        $this->YQbIT = RUnOaRW6FbMFN::mpwppkgSIMq($this->file, $SCIbS, $F8XZc, $YWDpu, $hFM9I, $U23hP, $BeDhM);
        goto xRZHH;
        lkXP7:
        return;
        goto RaBN2;
        jEidq:
        if (!($Hpnmw->year > 2026 or $Hpnmw->year === 2026 and $Hpnmw->month >= 3)) {
            goto tHnkP;
        }
        goto ZJ1iw;
        bprZB:
        if (!($fEqQc > 2026 ? true : (($fEqQc === 2026 and $rYwtp >= 3) ? true : false))) {
            goto g8s2G;
        }
        goto lkXP7;
        ONWRE:
        $rYwtp = $Kx8dn->month;
        goto bprZB;
        b3bC7:
        $Hpnmw = now();
        goto jEidq;
        sDYz0:
        $fEqQc = $Kx8dn->year;
        goto ONWRE;
        ZJ1iw:
        return;
        goto rgI43;
        EZ0Qu:
        $Kx8dn = now();
        goto sDYz0;
        RaBN2:
        g8s2G:
        goto b3bC7;
        rgI43:
        tHnkP:
        goto KNbvj;
        xRZHH:
    }
}
