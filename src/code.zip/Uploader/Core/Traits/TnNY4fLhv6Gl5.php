<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\FB4qGXxRRUqXX;
use Jfs\Uploader\Core\JNVd14WbS7J31;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
trait TnNY4fLhv6Gl5
{
    private $SnpXu;
    private $fFU3Y;
    private $sWH3A;
    public function mmNRlgopoZ5() : string
    {
        return FB4qGXxRRUqXX::m8Fi26WGLR3($this->SnpXu->getFilename());
    }
    public function m8Hi8VWicy3() : FB4qGXxRRUqXX
    {
        goto RcZZx;
        rRSS0:
        $this->mi4kj4p8vux();
        goto jnTzM;
        Altx7:
        Lc0Ww:
        goto rRSS0;
        RcZZx:
        if (!(null !== $this->fFU3Y)) {
            goto Lc0Ww;
        }
        goto ltZEs;
        ltZEs:
        return $this->fFU3Y;
        goto Altx7;
        jnTzM:
        return $this->fFU3Y;
        goto PmEdu;
        PmEdu:
    }
    private function mi4kj4p8vux() : JNVd14WbS7J31
    {
        goto zcwOg;
        kpu2U:
        $QT3bi = json_decode($nm9sv, true);
        goto mDKOS;
        DGY8j:
        throw new KWF9YuEFOPZRY("File {$this->SnpXu->getFilename()} is not PreSigned upload");
        goto d1KAh;
        mDKOS:
        $this->fFU3Y = FB4qGXxRRUqXX::m6bQG3bcuL0($QT3bi);
        goto DqT28;
        zcwOg:
        $nm9sv = $this->sWH3A->get($this->mmNRlgopoZ5());
        goto idIz7;
        DqT28:
        return $this;
        goto AjQ0W;
        idIz7:
        if (!$nm9sv) {
            goto elL2Z;
        }
        goto kpu2U;
        AjQ0W:
        elL2Z:
        goto DGY8j;
        d1KAh:
    }
    public function mCCDubV0cmy($uVy4X, $xOMrY, $PXFo7, $gFfDX, $VrvwN, $dHaKA = 's3') : void
    {
        $this->fFU3Y = FB4qGXxRRUqXX::mrKiRXtHFiM($this->SnpXu, $uVy4X, $xOMrY, $VrvwN, $PXFo7, $gFfDX, $dHaKA);
    }
}
