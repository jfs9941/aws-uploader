<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\A1DrGQVhPKB54;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Exception\LDB12Ub0rXHOx;
use Illuminate\Database\Eloquent\Model;
trait IkSz95bOOEAyh
{
    private $vAgws = [];
    public function moSEUBFRxDt($mJSqa)
    {
        goto ZMOvA;
        pCOv2:
        XKdmW:
        goto qhGSO;
        ZMOvA:
        if ($this instanceof Model) {
            goto XKdmW;
        }
        goto DSV4w;
        xcBjd:
        wG27J:
        goto lvo1Y;
        GSw1s:
        goto wG27J;
        goto pCOv2;
        DSV4w:
        $this->status = $mJSqa;
        goto GSw1s;
        qhGSO:
        $this->setAttribute('status', $mJSqa);
        goto xcBjd;
        lvo1Y:
    }
    public function m3tBiWBZHYC()
    {
        goto hV_LO;
        TA2kG:
        return $this->status;
        goto hoRrv;
        F9ZeE:
        ZISZy:
        goto TA2kG;
        fHHP1:
        return $this->getAttribute('status');
        goto F9ZeE;
        hV_LO:
        if (!$this instanceof Model) {
            goto ZISZy;
        }
        goto fHHP1;
        hoRrv:
    }
    public function mfzy7DteKHJ($POArZ)
    {
        goto k__fj;
        lgst6:
        $lC9T6 = $this->m3tBiWBZHYC();
        goto LRmhx;
        HGr71:
        $this->setAttribute('status', $POArZ);
        goto JOWHr;
        g2_sJ:
        cPz1h:
        goto HGr71;
        VdcnJ:
        throw LDB12Ub0rXHOx::mMv4ULqFVJn($this->id ?? 'unknown', $this->m3tBiWBZHYC(), $POArZ);
        goto BfEXP;
        JOWHr:
        eSMt8:
        goto jgJHw;
        k__fj:
        if ($this->mAtXjSpgm10($POArZ)) {
            goto P5xtQ;
        }
        goto VdcnJ;
        vel33:
        $this->status = $POArZ;
        goto f3pjn;
        jgJHw:
        foreach ($this->vAgws as $lf2oI) {
            $lf2oI->mhxhZPnjNPV($lC9T6, $POArZ);
            km5yd:
        }
        goto jbTJ5;
        BfEXP:
        P5xtQ:
        goto lgst6;
        f3pjn:
        goto eSMt8;
        goto g2_sJ;
        jbTJ5:
        WQeB7:
        goto cktY7;
        LRmhx:
        if ($this instanceof Model) {
            goto cPz1h;
        }
        goto vel33;
        cktY7:
    }
    public function mAtXjSpgm10($POArZ)
    {
        goto P9jp1;
        fvgLk:
        uP5nM:
        goto birGx;
        P9jp1:
        switch ($this->status) {
            case KidkTsWIjmNMb::UPLOADING:
                return KidkTsWIjmNMb::UPLOADED == $POArZ || KidkTsWIjmNMb::UPLOADING == $POArZ || KidkTsWIjmNMb::ABORTED == $POArZ;
            case KidkTsWIjmNMb::UPLOADED:
                return KidkTsWIjmNMb::PROCESSING == $POArZ || KidkTsWIjmNMb::DELETED == $POArZ;
            case KidkTsWIjmNMb::PROCESSING:
                return in_array($POArZ, [KidkTsWIjmNMb::WATERMARK_PROCESSED, KidkTsWIjmNMb::THUMBNAIL_PROCESSED, KidkTsWIjmNMb::ENCODING_PROCESSED, KidkTsWIjmNMb::ENCODING_ERROR, KidkTsWIjmNMb::BLUR_PROCESSED, KidkTsWIjmNMb::DELETED, KidkTsWIjmNMb::FINISHED, KidkTsWIjmNMb::PROCESSING]);
            case KidkTsWIjmNMb::FINISHED:
            case KidkTsWIjmNMb::ABORTED:
                return KidkTsWIjmNMb::DELETED == $POArZ;
            case KidkTsWIjmNMb::ENCODING_PROCESSED:
                return KidkTsWIjmNMb::FINISHED == $POArZ || KidkTsWIjmNMb::DELETED == $POArZ;
            default:
                return false;
        }
        goto A6NYY;
        A6NYY:
        bbkkY:
        goto fvgLk;
        birGx:
    }
    public function mme8vGqglZH(A1DrGQVhPKB54 $lf2oI)
    {
        $this->vAgws[] = $lf2oI;
    }
}
