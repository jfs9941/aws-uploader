<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\IlXdNMxZGcSoS;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Exception\CBStNIBT6cwK0;
use Illuminate\Database\Eloquent\Model;
trait KfSjQVQJRLwh3
{
    private $znQ0o = [];
    public function mJf7701KMEl($E9rq6)
    {
        goto LLkqN;
        oTUIK:
        x45lx:
        goto ZwOHS;
        RgatS:
        $this->status = $E9rq6;
        goto zPc1T;
        rPEmC:
        $this->setAttribute('status', $E9rq6);
        goto oTUIK;
        zPc1T:
        goto x45lx;
        goto F9djS;
        LLkqN:
        if ($this instanceof Model) {
            goto s0QHY;
        }
        goto RgatS;
        F9djS:
        s0QHY:
        goto rPEmC;
        ZwOHS:
    }
    public function mxqE5nOdX4O()
    {
        goto nCa6c;
        V7yZ5:
        myTTM:
        goto lPULi;
        lPULi:
        return $this->status;
        goto nzrqy;
        xFcae:
        return $this->getAttribute('status');
        goto V7yZ5;
        nCa6c:
        if (!$this instanceof Model) {
            goto myTTM;
        }
        goto xFcae;
        nzrqy:
    }
    public function mpDdU9lVtpc($c3txX)
    {
        goto zryUw;
        LS4Q2:
        goto AqMH_;
        goto nrOuH;
        cZjyI:
        AqMH_:
        goto J9EMn;
        MuVhT:
        throw CBStNIBT6cwK0::mjMcJx6Y5ML($this->id ?? 'unknown', $this->mxqE5nOdX4O(), $c3txX);
        goto ZKLtG;
        J9EMn:
        foreach ($this->znQ0o as $KGeEm) {
            $KGeEm->mZowOLQCS3i($Zw__L, $c3txX);
            rd9qE:
        }
        goto h3hOW;
        h3hOW:
        LmW4R:
        goto ePc7o;
        BLpwU:
        $this->status = $c3txX;
        goto LS4Q2;
        ufxtu:
        $this->setAttribute('status', $c3txX);
        goto cZjyI;
        ZKLtG:
        IQy3Y:
        goto hKrbv;
        nrOuH:
        EWmwY:
        goto ufxtu;
        hKrbv:
        $Zw__L = $this->mxqE5nOdX4O();
        goto aYkb4;
        aYkb4:
        if ($this instanceof Model) {
            goto EWmwY;
        }
        goto BLpwU;
        zryUw:
        if ($this->mTMqJijgtYL($c3txX)) {
            goto IQy3Y;
        }
        goto MuVhT;
        ePc7o:
    }
    public function mTMqJijgtYL($c3txX)
    {
        goto Nc666;
        Nc666:
        switch ($this->status) {
            case M7O7NSiJU2JG5::UPLOADING:
                return M7O7NSiJU2JG5::UPLOADED == $c3txX || M7O7NSiJU2JG5::UPLOADING == $c3txX || M7O7NSiJU2JG5::ABORTED == $c3txX;
            case M7O7NSiJU2JG5::UPLOADED:
                return M7O7NSiJU2JG5::PROCESSING == $c3txX || M7O7NSiJU2JG5::DELETED == $c3txX;
            case M7O7NSiJU2JG5::PROCESSING:
                return in_array($c3txX, [M7O7NSiJU2JG5::WATERMARK_PROCESSED, M7O7NSiJU2JG5::THUMBNAIL_PROCESSED, M7O7NSiJU2JG5::ENCODING_PROCESSED, M7O7NSiJU2JG5::ENCODING_ERROR, M7O7NSiJU2JG5::BLUR_PROCESSED, M7O7NSiJU2JG5::DELETED, M7O7NSiJU2JG5::FINISHED, M7O7NSiJU2JG5::PROCESSING]);
            case M7O7NSiJU2JG5::FINISHED:
            case M7O7NSiJU2JG5::ABORTED:
                return M7O7NSiJU2JG5::DELETED == $c3txX;
            case M7O7NSiJU2JG5::ENCODING_PROCESSED:
                return M7O7NSiJU2JG5::FINISHED == $c3txX || M7O7NSiJU2JG5::DELETED == $c3txX;
            default:
                return false;
        }
        goto PAW96;
        wFSBy:
        IIPe4:
        goto axRT4;
        PAW96:
        a8vnj:
        goto wFSBy;
        axRT4:
    }
    public function m3qxyKjPsWx(IlXdNMxZGcSoS $KGeEm)
    {
        $this->znQ0o[] = $KGeEm;
    }
}
