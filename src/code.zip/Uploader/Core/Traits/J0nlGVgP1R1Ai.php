<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\GMMSgBcs5XImF;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Exception\BtFXMjsbQEzWB;
trait J0nlGVgP1R1Ai
{
    private $X2XoV = [];
    public function m3B430t4QRf($wYQHI)
    {
        goto UCgqh;
        UCgqh:
        if ($this instanceof Model) {
            goto jr7nH;
        }
        goto NSCrs;
        NSCrs:
        $this->status = $wYQHI;
        goto vAuW2;
        dB5kV:
        jr7nH:
        goto tT8_j;
        tT8_j:
        $this->setAttribute('status', $wYQHI);
        goto NFcSr;
        vAuW2:
        goto GNpjc;
        goto dB5kV;
        NFcSr:
        GNpjc:
        goto Hhe1T;
        Hhe1T:
    }
    public function mMgSU2dRNmq()
    {
        goto wKPMt;
        uOWlx:
        return $this->getAttribute('status');
        goto efJtl;
        wKPMt:
        if (!$this instanceof Model) {
            goto c_1zp;
        }
        goto uOWlx;
        efJtl:
        c_1zp:
        goto TA3Bl;
        TA3Bl:
        return $this->status;
        goto C4A2T;
        C4A2T:
    }
    public function mhWKUa6jAoa($xPckJ)
    {
        goto xb0T2;
        n3UNY:
        goto MmTbP;
        goto QRbXE;
        qQQnm:
        KFmDD:
        goto eSsoR;
        QRbXE:
        vw9AJ:
        goto Ca7lh;
        Qcekd:
        dSpPW:
        goto sZyYg;
        sZyYg:
        $RAkh0 = $this->mMgSU2dRNmq();
        goto HsTeK;
        HsTeK:
        if ($this instanceof Model) {
            goto vw9AJ;
        }
        goto a4LYO;
        U9kef:
        MmTbP:
        goto UYZzF;
        Ca7lh:
        $this->setAttribute('status', $xPckJ);
        goto U9kef;
        xb0T2:
        if ($this->mUTz4zjaBVf($xPckJ)) {
            goto dSpPW;
        }
        goto pGHK4;
        a4LYO:
        $this->status = $xPckJ;
        goto n3UNY;
        pGHK4:
        throw BtFXMjsbQEzWB::mlyzSejpWh7($this->id ?? 'unknown', $this->mMgSU2dRNmq(), $xPckJ);
        goto Qcekd;
        UYZzF:
        foreach ($this->X2XoV as $bBDAd) {
            $bBDAd->mJdFuAPL4o5($RAkh0, $xPckJ);
            zRLrG:
        }
        goto qQQnm;
        eSsoR:
    }
    public function mUTz4zjaBVf($xPckJ)
    {
        goto Dk3Rz;
        cXWfq:
        K2SBG:
        goto K3rg4;
        gzeI2:
        hhNjb:
        goto cXWfq;
        Dk3Rz:
        switch ($this->status) {
            case EUkqoDwU9Zcvh::UPLOADING:
                return EUkqoDwU9Zcvh::UPLOADED == $xPckJ || EUkqoDwU9Zcvh::UPLOADING == $xPckJ || EUkqoDwU9Zcvh::ABORTED == $xPckJ;
            case EUkqoDwU9Zcvh::UPLOADED:
                return EUkqoDwU9Zcvh::PROCESSING == $xPckJ || EUkqoDwU9Zcvh::DELETED == $xPckJ;
            case EUkqoDwU9Zcvh::PROCESSING:
                return in_array($xPckJ, [EUkqoDwU9Zcvh::WATERMARK_PROCESSED, EUkqoDwU9Zcvh::THUMBNAIL_PROCESSED, EUkqoDwU9Zcvh::ENCODING_PROCESSED, EUkqoDwU9Zcvh::ENCODING_ERROR, EUkqoDwU9Zcvh::BLUR_PROCESSED, EUkqoDwU9Zcvh::DELETED, EUkqoDwU9Zcvh::FINISHED, EUkqoDwU9Zcvh::PROCESSING]);
            case EUkqoDwU9Zcvh::FINISHED:
            case EUkqoDwU9Zcvh::ABORTED:
                return EUkqoDwU9Zcvh::DELETED == $xPckJ;
            case EUkqoDwU9Zcvh::ENCODING_PROCESSED:
                return EUkqoDwU9Zcvh::FINISHED == $xPckJ || EUkqoDwU9Zcvh::DELETED == $xPckJ;
            default:
                return false;
        }
        goto gzeI2;
        K3rg4:
    }
    public function mCa4XumvZrx(GMMSgBcs5XImF $bBDAd)
    {
        $this->X2XoV[] = $bBDAd;
    }
}
