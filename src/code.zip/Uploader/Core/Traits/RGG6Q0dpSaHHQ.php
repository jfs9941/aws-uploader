<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait RGG6Q0dpSaHHQ
{
    private function mbPHJDm7oLp(string $g2Hrl) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $g2Hrl]));
    }
}
