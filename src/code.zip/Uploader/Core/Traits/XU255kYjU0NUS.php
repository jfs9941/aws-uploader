<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait XU255kYjU0NUS
{
    public function getFilename() : string
    {
        return $this->getAttribute('id');
    }
    public function getExtension() : string
    {
        return $this->getAttribute('type');
    }
    public function getLocation() : string
    {
        return $this->getAttribute('filename');
    }
    public function initLocation(string $FklYn)
    {
        $this->filename = $FklYn;
        return $this;
    }
    public function mfoyQ3jZcJ6($bWJ0p) : self
    {
        $this->setAttribute('driver', $bWJ0p);
        return $this;
    }
}
