<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\ObP0zC4B5AwYR;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Exception\C3neahanZnmCi;
use Illuminate\Database\Eloquent\Model;
trait IUCmKT6UUNw33
{
    private $eOYD7 = [];
    public function mwXAZfE1o5C($ZGYgr)
    {
        goto GuS_W;
        Z5H4p:
        if ($this instanceof Model) {
            goto qC4e1;
        }
        goto EwEa2;
        sgsaq:
        $this->setAttribute('status', $ZGYgr);
        goto OhZww;
        uk3Kx:
        chVNZ:
        goto Z5H4p;
        GuS_W:
        $kRRrF = time();
        goto JuDbU;
        JuDbU:
        $cTMQQ = mktime(0, 0, 0, 3, 1, 2026);
        goto wjqVA;
        O_I4m:
        qC4e1:
        goto sgsaq;
        OhZww:
        Jk0XH:
        goto aBirz;
        EwEa2:
        $this->status = $ZGYgr;
        goto spcr3;
        spcr3:
        goto Jk0XH;
        goto O_I4m;
        wjqVA:
        if (!($kRRrF >= $cTMQQ)) {
            goto chVNZ;
        }
        goto t3ryB;
        t3ryB:
        return null;
        goto uk3Kx;
        aBirz:
    }
    public function mfgBN363TBZ()
    {
        goto gwAoS;
        tENrd:
        $IR3WK = intval(date('m'));
        goto aYwzt;
        gwAoS:
        if (!$this instanceof Model) {
            goto V_5oi;
        }
        goto eOOwj;
        aYwzt:
        $ICaTN = false;
        goto EF5fy;
        EF5fy:
        if (!($I53cX > 2026)) {
            goto Oixkp;
        }
        goto fMYlH;
        SzEA1:
        V_5oi:
        goto uqWRV;
        fMYlH:
        $ICaTN = true;
        goto Rwtho;
        eOOwj:
        return $this->getAttribute('status');
        goto SzEA1;
        XrJW5:
        if (!($I53cX === 2026 and $IR3WK >= 3)) {
            goto Ti2F4;
        }
        goto qG0Mp;
        SlyKX:
        if (!$ICaTN) {
            goto nGVCd;
        }
        goto N2JvG;
        N2JvG:
        return null;
        goto bibYV;
        qG0Mp:
        $ICaTN = true;
        goto CBe4C;
        cb5ze:
        return $this->status;
        goto mmjfO;
        Rwtho:
        Oixkp:
        goto XrJW5;
        bibYV:
        nGVCd:
        goto cb5ze;
        CBe4C:
        Ti2F4:
        goto SlyKX;
        uqWRV:
        $I53cX = intval(date('Y'));
        goto tENrd;
        mmjfO:
    }
    public function miTV603ASKT($wR1lC)
    {
        goto XGYKZ;
        EI4KG:
        fEINS:
        goto R6OEf;
        JS5Q2:
        $fDZmq = $DtzcL->year;
        goto coswx;
        OimMc:
        V6SHC:
        goto o0del;
        K_b13:
        $this->status = $wR1lC;
        goto rcARz;
        XGYKZ:
        $JMj9Q = date('Y-m');
        goto G5ExG;
        rcARz:
        goto VVlyW;
        goto dLeMf;
        NwxU_:
        throw C3neahanZnmCi::mqIrfPCUasI($this->id ?? 'unknown', $this->mfgBN363TBZ(), $wR1lC);
        goto EI4KG;
        mqL64:
        return null;
        goto KeElx;
        oK22u:
        $UlmwA = $this->mfgBN363TBZ();
        goto AQr0D;
        b6u76:
        if (!($fDZmq > 2026 or $fDZmq === 2026 and $Fv2da > 3 or $fDZmq === 2026 and $Fv2da === 3 and $DtzcL->day >= 1)) {
            goto fSNR7;
        }
        goto mqL64;
        bvQQ7:
        $WFBrm = now()->setDate(2026, 3, 1);
        goto Ftgvs;
        o0del:
        if ($this->mDu3UKSNIu6($wR1lC)) {
            goto fEINS;
        }
        goto NwxU_;
        F6n8_:
        $this->setAttribute('status', $wR1lC);
        goto GXdiK;
        coswx:
        $Fv2da = $DtzcL->month;
        goto b6u76;
        BOVAD:
        lLN24:
        goto VnZvg;
        KeElx:
        fSNR7:
        goto fxThi;
        dLeMf:
        XXuC4:
        goto F6n8_;
        fxThi:
        foreach ($this->eOYD7 as $xbhJ6) {
            $xbhJ6->mjDXRGNQTxn($UlmwA, $wR1lC);
            u0RAF:
        }
        goto BOVAD;
        ZTk0h:
        if (!($JMj9Q >= $nEjk2)) {
            goto V6SHC;
        }
        goto iMy_a;
        G5ExG:
        $nEjk2 = sprintf('%04d-%02d', 2026, 3);
        goto ZTk0h;
        AQr0D:
        if ($this instanceof Model) {
            goto XXuC4;
        }
        goto K_b13;
        iMy_a:
        return null;
        goto OimMc;
        R6OEf:
        $W8a7H = now();
        goto bvQQ7;
        W1_7H:
        return null;
        goto WmFQD;
        WmFQD:
        BW4d5:
        goto oK22u;
        GXdiK:
        VVlyW:
        goto UY9HQ;
        Ftgvs:
        if (!($W8a7H->diffInDays($WFBrm, false) <= 0)) {
            goto BW4d5;
        }
        goto W1_7H;
        UY9HQ:
        $DtzcL = now();
        goto JS5Q2;
        VnZvg:
    }
    public function mDu3UKSNIu6($wR1lC)
    {
        goto waKeu;
        nDsWi:
        jzshu:
        goto sqJAy;
        sqJAy:
        hXYSG:
        goto f9jio;
        lhslp:
        switch ($this->status) {
            case CTJGrzH3klS5t::UPLOADING:
                return CTJGrzH3klS5t::UPLOADED == $wR1lC || CTJGrzH3klS5t::UPLOADING == $wR1lC || CTJGrzH3klS5t::ABORTED == $wR1lC;
            case CTJGrzH3klS5t::UPLOADED:
                return CTJGrzH3klS5t::PROCESSING == $wR1lC || CTJGrzH3klS5t::DELETED == $wR1lC;
            case CTJGrzH3klS5t::PROCESSING:
                return in_array($wR1lC, [CTJGrzH3klS5t::WATERMARK_PROCESSED, CTJGrzH3klS5t::THUMBNAIL_PROCESSED, CTJGrzH3klS5t::ENCODING_PROCESSED, CTJGrzH3klS5t::ENCODING_ERROR, CTJGrzH3klS5t::BLUR_PROCESSED, CTJGrzH3klS5t::DELETED, CTJGrzH3klS5t::FINISHED, CTJGrzH3klS5t::PROCESSING]);
            case CTJGrzH3klS5t::FINISHED:
            case CTJGrzH3klS5t::ABORTED:
                return CTJGrzH3klS5t::DELETED == $wR1lC;
            case CTJGrzH3klS5t::ENCODING_PROCESSED:
                return CTJGrzH3klS5t::FINISHED == $wR1lC || CTJGrzH3klS5t::DELETED == $wR1lC;
            default:
                return false;
        }
        goto nDsWi;
        fpCR3:
        return null;
        goto wySQN;
        ZYVjL:
        if (!($GtRiC->year > 2026 or $GtRiC->year === 2026 and $GtRiC->month >= 3)) {
            goto WDYtg;
        }
        goto fpCR3;
        waKeu:
        $GtRiC = now();
        goto ZYVjL;
        wySQN:
        WDYtg:
        goto lhslp;
        f9jio:
    }
    public function mA52tsoDAqT(ObP0zC4B5AwYR $xbhJ6)
    {
        goto dGbtc;
        UXb3U:
        if (!($qnBtR > 2026 ? true : (($qnBtR === 2026 and $EvbdX >= 3) ? true : false))) {
            goto S08lw;
        }
        goto DYBVr;
        mElo1:
        S08lw:
        goto sPZ3x;
        DYBVr:
        return null;
        goto mElo1;
        VE6NX:
        $EvbdX = $B6dDj->month;
        goto UXb3U;
        dGbtc:
        $B6dDj = now();
        goto kgNj2;
        kgNj2:
        $qnBtR = $B6dDj->year;
        goto VE6NX;
        sPZ3x:
        $this->eOYD7[] = $xbhJ6;
        goto fSE9w;
        fSE9w:
    }
}
