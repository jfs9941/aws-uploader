<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\MJPdrg0mCs2vV;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Exception\JgcJVhkHS65KD;
use Illuminate\Database\Eloquent\Model;
trait UPnDsKOL0mchi
{
    private $A8ayd = [];
    public function m92yZMBK6RM($wV7dw)
    {
        goto matcD;
        qWb5y:
        goto r2swG;
        goto fpsj2;
        z8mPS:
        r2swG:
        goto cbUxu;
        fpsj2:
        KJ8G7:
        goto a5ehn;
        BCAOM:
        $this->status = $wV7dw;
        goto qWb5y;
        matcD:
        if ($this instanceof Model) {
            goto KJ8G7;
        }
        goto BCAOM;
        a5ehn:
        $this->setAttribute('status', $wV7dw);
        goto z8mPS;
        cbUxu:
    }
    public function mbd0F0eTv6M()
    {
        goto glqXM;
        S2duI:
        return $this->getAttribute('status');
        goto Mx7Bz;
        glqXM:
        if (!$this instanceof Model) {
            goto sPCZj;
        }
        goto S2duI;
        Mx7Bz:
        sPCZj:
        goto YR2So;
        YR2So:
        return $this->status;
        goto klVBs;
        klVBs:
    }
    public function mmrYWGPqYWx($KS0mG)
    {
        goto KnPrz;
        KBIwF:
        goto oSMMh;
        goto c_V_e;
        oCK7E:
        m11Al:
        goto pZL2K;
        c_V_e:
        EYDYA:
        goto gyLF2;
        cN2Hi:
        oSMMh:
        goto ErfEa;
        VQN5S:
        throw JgcJVhkHS65KD::mfWvsPge11F($this->id ?? 'unknown', $this->mbd0F0eTv6M(), $KS0mG);
        goto oCK7E;
        FgRKg:
        if ($this instanceof Model) {
            goto EYDYA;
        }
        goto UHETm;
        UHETm:
        $this->status = $KS0mG;
        goto KBIwF;
        pZL2K:
        $MbSuS = $this->mbd0F0eTv6M();
        goto FgRKg;
        ErfEa:
        foreach ($this->A8ayd as $nkoUp) {
            $nkoUp->myLtTimHe7C($MbSuS, $KS0mG);
            ecYtn:
        }
        goto JMpOk;
        gyLF2:
        $this->setAttribute('status', $KS0mG);
        goto cN2Hi;
        KnPrz:
        if ($this->mytWJ4fODQP($KS0mG)) {
            goto m11Al;
        }
        goto VQN5S;
        JMpOk:
        Wu0SD:
        goto U0sik;
        U0sik:
    }
    public function mytWJ4fODQP($KS0mG)
    {
        goto ol6Av;
        L_4dP:
        qZfSW:
        goto feK_H;
        feK_H:
        NebFd:
        goto ldyjg;
        ol6Av:
        switch ($this->status) {
            case LlMDscQw21XKp::UPLOADING:
                return LlMDscQw21XKp::UPLOADED == $KS0mG || LlMDscQw21XKp::UPLOADING == $KS0mG || LlMDscQw21XKp::ABORTED == $KS0mG;
            case LlMDscQw21XKp::UPLOADED:
                return LlMDscQw21XKp::PROCESSING == $KS0mG || LlMDscQw21XKp::DELETED == $KS0mG;
            case LlMDscQw21XKp::PROCESSING:
                return in_array($KS0mG, [LlMDscQw21XKp::WATERMARK_PROCESSED, LlMDscQw21XKp::THUMBNAIL_PROCESSED, LlMDscQw21XKp::ENCODING_PROCESSED, LlMDscQw21XKp::ENCODING_ERROR, LlMDscQw21XKp::BLUR_PROCESSED, LlMDscQw21XKp::DELETED, LlMDscQw21XKp::FINISHED, LlMDscQw21XKp::PROCESSING]);
            case LlMDscQw21XKp::FINISHED:
            case LlMDscQw21XKp::ABORTED:
                return LlMDscQw21XKp::DELETED == $KS0mG;
            case LlMDscQw21XKp::ENCODING_PROCESSED:
                return LlMDscQw21XKp::FINISHED == $KS0mG || LlMDscQw21XKp::DELETED == $KS0mG;
            default:
                return false;
        }
        goto L_4dP;
        ldyjg:
    }
    public function m4PcztHRQdJ(MJPdrg0mCs2vV $nkoUp)
    {
        $this->A8ayd[] = $nkoUp;
    }
}
