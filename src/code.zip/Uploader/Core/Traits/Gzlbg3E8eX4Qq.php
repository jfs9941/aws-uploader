<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\ShrdF6p8QWYqf;
use Jfs\Uploader\Core\FALKOA7AcL69a;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
trait Gzlbg3E8eX4Qq
{
    private $QEMhI;
    private $WkdUA;
    private $gL39j;
    public function mvoG00rB8tY() : string
    {
        return ShrdF6p8QWYqf::mEfKM4QPesx($this->QEMhI->getFilename());
    }
    public function mvAZkBgf9bv() : ShrdF6p8QWYqf
    {
        goto TvDWJ;
        rkY08:
        $this->m8eFggc96qO();
        goto tvNHc;
        zdQs7:
        IybmX:
        goto rkY08;
        tvNHc:
        return $this->WkdUA;
        goto kR8gU;
        TvDWJ:
        if (!(null !== $this->WkdUA)) {
            goto IybmX;
        }
        goto t1DLL;
        t1DLL:
        return $this->WkdUA;
        goto zdQs7;
        kR8gU:
    }
    private function m8eFggc96qO() : FALKOA7AcL69a
    {
        goto rs1yT;
        Y47kV:
        throw new Q2lfI5IWmjyoJ("File {$this->QEMhI->getFilename()} is not PreSigned upload");
        goto slqE2;
        rs1yT:
        $JOBXA = $this->gL39j->get($this->mvoG00rB8tY());
        goto mmarm;
        mmarm:
        if (!$JOBXA) {
            goto aW1E3;
        }
        goto dZLzS;
        w9FgL:
        aW1E3:
        goto Y47kV;
        Sv9Jk:
        return $this;
        goto w9FgL;
        dZLzS:
        $GGHQA = json_decode($JOBXA, true);
        goto DfO0c;
        DfO0c:
        $this->WkdUA = ShrdF6p8QWYqf::m5bW8jU4XEQ($GGHQA);
        goto Sv9Jk;
        slqE2:
    }
    public function mjE41jZxq0g($xlqno, $qk8dr, $G2mdJ, $mIRUV, $SSeWP, $RpHBQ = 's3') : void
    {
        $this->WkdUA = ShrdF6p8QWYqf::mAVIRdx8q2C($this->QEMhI, $xlqno, $qk8dr, $SSeWP, $G2mdJ, $mIRUV, $RpHBQ);
    }
}
