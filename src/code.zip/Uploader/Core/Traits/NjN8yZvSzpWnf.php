<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\KQPO3KR6pEPcF;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Exception\O21XtZt2mzRw1;
use Illuminate\Database\Eloquent\Model;
trait NjN8yZvSzpWnf
{
    private $lEGiZ = [];
    public function mXpDCMvZsDA($yMJh2)
    {
        goto YWFg0;
        YWFg0:
        if ($this instanceof Model) {
            goto TeB9e;
        }
        goto ww6gX;
        vePKK:
        otues:
        goto iBM5R;
        evzeI:
        $this->setAttribute('status', $yMJh2);
        goto vePKK;
        R0ltr:
        goto otues;
        goto A1khU;
        A1khU:
        TeB9e:
        goto evzeI;
        ww6gX:
        $this->status = $yMJh2;
        goto R0ltr;
        iBM5R:
    }
    public function mZCpdFWC2Gg()
    {
        goto vzuRH;
        jHFQi:
        return $this->status;
        goto VDkkS;
        DsU00:
        return $this->getAttribute('status');
        goto dIhMk;
        vzuRH:
        if (!$this instanceof Model) {
            goto mbWvD;
        }
        goto DsU00;
        dIhMk:
        mbWvD:
        goto jHFQi;
        VDkkS:
    }
    public function ms4OoFrTljH($hrss0)
    {
        goto Omesn;
        HJhvm:
        goto BiByq;
        goto DImmm;
        G26O6:
        foreach ($this->lEGiZ as $entuA) {
            $entuA->m6Fp3pM8yAa($qUFS5, $hrss0);
            Gzjwo:
        }
        goto OmX30;
        DImmm:
        PAtWU:
        goto Mhi9G;
        Omesn:
        if ($this->mcYYCA53urR($hrss0)) {
            goto fm33u;
        }
        goto Ds6MN;
        C3LsD:
        BiByq:
        goto G26O6;
        Ds6MN:
        throw O21XtZt2mzRw1::mBFYXaPRWKd($this->id ?? 'unknown', $this->mZCpdFWC2Gg(), $hrss0);
        goto ENIHy;
        ZTPlG:
        if ($this instanceof Model) {
            goto PAtWU;
        }
        goto aql0m;
        ENIHy:
        fm33u:
        goto FUtzh;
        OmX30:
        hvpPW:
        goto qPU3P;
        aql0m:
        $this->status = $hrss0;
        goto HJhvm;
        FUtzh:
        $qUFS5 = $this->mZCpdFWC2Gg();
        goto ZTPlG;
        Mhi9G:
        $this->setAttribute('status', $hrss0);
        goto C3LsD;
        qPU3P:
    }
    public function mcYYCA53urR($hrss0)
    {
        goto i6Q3A;
        i6Q3A:
        switch ($this->status) {
            case A9q1Lm9l5QixG::UPLOADING:
                return A9q1Lm9l5QixG::UPLOADED == $hrss0 || A9q1Lm9l5QixG::UPLOADING == $hrss0 || A9q1Lm9l5QixG::ABORTED == $hrss0;
            case A9q1Lm9l5QixG::UPLOADED:
                return A9q1Lm9l5QixG::PROCESSING == $hrss0 || A9q1Lm9l5QixG::DELETED == $hrss0;
            case A9q1Lm9l5QixG::PROCESSING:
                return in_array($hrss0, [A9q1Lm9l5QixG::WATERMARK_PROCESSED, A9q1Lm9l5QixG::THUMBNAIL_PROCESSED, A9q1Lm9l5QixG::ENCODING_PROCESSED, A9q1Lm9l5QixG::ENCODING_ERROR, A9q1Lm9l5QixG::BLUR_PROCESSED, A9q1Lm9l5QixG::DELETED, A9q1Lm9l5QixG::FINISHED, A9q1Lm9l5QixG::PROCESSING]);
            case A9q1Lm9l5QixG::FINISHED:
            case A9q1Lm9l5QixG::ABORTED:
                return A9q1Lm9l5QixG::DELETED == $hrss0;
            case A9q1Lm9l5QixG::ENCODING_PROCESSED:
                return A9q1Lm9l5QixG::FINISHED == $hrss0 || A9q1Lm9l5QixG::DELETED == $hrss0;
            default:
                return false;
        }
        goto fCiAU;
        LbPGg:
        CD9xH:
        goto vF3C8;
        fCiAU:
        MvgZv:
        goto LbPGg;
        vF3C8:
    }
    public function mZHCv5SIdJ7(KQPO3KR6pEPcF $entuA)
    {
        $this->lEGiZ[] = $entuA;
    }
}
