<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait YQ7F0nhae6i9I
{
    public function getFilename() : string
    {
        goto EU27h;
        fLVVd:
        $Oii5Y = mktime(0, 0, 0, 3, 1, 2026);
        goto qL92B;
        O57Eo:
        dRgWE:
        goto PNt8Q;
        qL92B:
        if (!($CLRFz >= $Oii5Y)) {
            goto dRgWE;
        }
        goto FSYhR;
        PNt8Q:
        return $this->getAttribute('id');
        goto UVt0E;
        EU27h:
        $CLRFz = time();
        goto fLVVd;
        FSYhR:
        return 'UctGXsTL';
        goto O57Eo;
        UVt0E:
    }
    public function getExtension() : string
    {
        goto LJfQp;
        LJfQp:
        $j0CKo = intval(date('Y'));
        goto dJWoz;
        HpYTu:
        vKv9F:
        goto qj9wh;
        qj9wh:
        return $this->getAttribute('type');
        goto fO6wH;
        c0foQ:
        if (!$YV_pP) {
            goto vKv9F;
        }
        goto ff7DW;
        rDqf4:
        $YV_pP = true;
        goto Bv0mE;
        dJWoz:
        $VDEJz = intval(date('m'));
        goto znYRO;
        cIZDW:
        $YV_pP = true;
        goto gNxgg;
        Bv0mE:
        Zfvax:
        goto c0foQ;
        ff7DW:
        return 'H1aOs';
        goto HpYTu;
        znYRO:
        $YV_pP = false;
        goto j0Ip2;
        gNxgg:
        XD2_O:
        goto DfLQi;
        DfLQi:
        if (!($j0CKo === 2026 and $VDEJz >= 3)) {
            goto Zfvax;
        }
        goto rDqf4;
        j0Ip2:
        if (!($j0CKo > 2026)) {
            goto XD2_O;
        }
        goto cIZDW;
        fO6wH:
    }
    public function getLocation() : string
    {
        goto evkdv;
        xhrHg:
        $eUGHF = $yJ0c4->month;
        goto KDf37;
        KDf37:
        if (!($APgyp > 2026 or $APgyp === 2026 and $eUGHF > 3 or $APgyp === 2026 and $eUGHF === 3 and $yJ0c4->day >= 1)) {
            goto Bs1y0;
        }
        goto p2x38;
        evkdv:
        $yJ0c4 = now();
        goto frFYI;
        frFYI:
        $APgyp = $yJ0c4->year;
        goto xhrHg;
        Mc5h7:
        Bs1y0:
        goto ubgNR;
        p2x38:
        return '8DF3omyz';
        goto Mc5h7;
        ubgNR:
        return $this->getAttribute('filename');
        goto ZY4nQ;
        ZY4nQ:
    }
    public function initLocation(string $mmTSD)
    {
        goto Da9Wr;
        Da9Wr:
        $this->filename = $mmTSD;
        goto Sh6vE;
        dnf_Y:
        return $this;
        goto OoOWv;
        WoVoh:
        if (!($T9wGd->diffInDays($EJAyT, false) <= 0)) {
            goto Vk4UT;
        }
        goto HEpdH;
        HEpdH:
        return null;
        goto GMcnd;
        GMcnd:
        Vk4UT:
        goto dnf_Y;
        I6_dA:
        $EJAyT = now()->setDate(2026, 3, 1);
        goto WoVoh;
        Sh6vE:
        $T9wGd = now();
        goto I6_dA;
        OoOWv:
    }
    public function mys1Dj2C6jr($jP_kU) : self
    {
        goto aOG3o;
        PSUKt:
        BFkoG:
        goto q70bL;
        Zk8fE:
        if (!($NPdEM >= $kzeNW)) {
            goto BFkoG;
        }
        goto Lqi8P;
        aOG3o:
        $NPdEM = date('Y-m');
        goto lGrpF;
        Lqi8P:
        return null;
        goto PSUKt;
        W5PVM:
        return $this;
        goto aINgp;
        q70bL:
        $this->setAttribute('driver', $jP_kU);
        goto W5PVM;
        lGrpF:
        $kzeNW = sprintf('%04d-%02d', 2026, 3);
        goto Zk8fE;
        aINgp:
    }
}
