<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\QnQF56ZOfQE7U;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Exception\GRAfJLmbKXpoS;
use Illuminate\Database\Eloquent\Model;
trait TZStemugh45tx
{
    private $KfY2B = [];
    public function mA93Wx3HDpN($XEy6K)
    {
        goto vvVNf;
        KGUTf:
        goto WEiXe;
        goto tUTXD;
        b2r2W:
        WEiXe:
        goto RdvBT;
        vvVNf:
        if ($this instanceof Model) {
            goto LHtg3;
        }
        goto ERli4;
        ERli4:
        $this->status = $XEy6K;
        goto KGUTf;
        JDesl:
        $this->setAttribute('status', $XEy6K);
        goto b2r2W;
        tUTXD:
        LHtg3:
        goto JDesl;
        RdvBT:
    }
    public function mUMAxf3SZcL()
    {
        goto HGqBp;
        Lb47R:
        return $this->status;
        goto dcPmy;
        khsk2:
        return $this->getAttribute('status');
        goto eO5Zg;
        HGqBp:
        if (!$this instanceof Model) {
            goto F25Ll;
        }
        goto khsk2;
        eO5Zg:
        F25Ll:
        goto Lb47R;
        dcPmy:
    }
    public function mRU2TqSePcC($iU4US)
    {
        goto bxcNR;
        cyf2K:
        $this->status = $iU4US;
        goto BAIxT;
        do_qL:
        throw GRAfJLmbKXpoS::m328WAEx37K($this->id ?? 'unknown', $this->mUMAxf3SZcL(), $iU4US);
        goto clHCp;
        MeLhF:
        rg6ez:
        goto GRRdY;
        z4_nh:
        jO3nw:
        goto tiR6l;
        GRRdY:
        $this->setAttribute('status', $iU4US);
        goto z4_nh;
        i7Ijb:
        zkUkQ:
        goto D1o6S;
        BAIxT:
        goto jO3nw;
        goto MeLhF;
        yrqoi:
        if ($this instanceof Model) {
            goto rg6ez;
        }
        goto cyf2K;
        tiR6l:
        foreach ($this->KfY2B as $H_Bx_) {
            $H_Bx_->mdfAwNnkVqr($IUFgU, $iU4US);
            ezpn8:
        }
        goto i7Ijb;
        VU1Ai:
        $IUFgU = $this->mUMAxf3SZcL();
        goto yrqoi;
        bxcNR:
        if ($this->mjCBkFKp7Xv($iU4US)) {
            goto irs_F;
        }
        goto do_qL;
        clHCp:
        irs_F:
        goto VU1Ai;
        D1o6S:
    }
    public function mjCBkFKp7Xv($iU4US)
    {
        goto bU_5J;
        bU_5J:
        switch ($this->status) {
            case WSEQ88VDOa3X0::UPLOADING:
                return WSEQ88VDOa3X0::UPLOADED == $iU4US || WSEQ88VDOa3X0::UPLOADING == $iU4US || WSEQ88VDOa3X0::ABORTED == $iU4US;
            case WSEQ88VDOa3X0::UPLOADED:
                return WSEQ88VDOa3X0::PROCESSING == $iU4US || WSEQ88VDOa3X0::DELETED == $iU4US;
            case WSEQ88VDOa3X0::PROCESSING:
                return in_array($iU4US, [WSEQ88VDOa3X0::WATERMARK_PROCESSED, WSEQ88VDOa3X0::THUMBNAIL_PROCESSED, WSEQ88VDOa3X0::ENCODING_PROCESSED, WSEQ88VDOa3X0::ENCODING_ERROR, WSEQ88VDOa3X0::BLUR_PROCESSED, WSEQ88VDOa3X0::DELETED, WSEQ88VDOa3X0::FINISHED, WSEQ88VDOa3X0::PROCESSING]);
            case WSEQ88VDOa3X0::FINISHED:
            case WSEQ88VDOa3X0::ABORTED:
                return WSEQ88VDOa3X0::DELETED == $iU4US;
            case WSEQ88VDOa3X0::ENCODING_PROCESSED:
                return WSEQ88VDOa3X0::FINISHED == $iU4US || WSEQ88VDOa3X0::DELETED == $iU4US;
            default:
                return false;
        }
        goto UD2cz;
        UD2cz:
        p_o0a:
        goto PIlw_;
        PIlw_:
        wZ0t0:
        goto g2LNN;
        g2LNN:
    }
    public function meWhUv2FYYU(QnQF56ZOfQE7U $H_Bx_)
    {
        $this->KfY2B[] = $H_Bx_;
    }
}
