<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Icfhroj1Rrrzn;
use Jfs\Uploader\Core\Wa740mKVvCN9d;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
trait CFWlVgfsxtnSg
{
    private $Fhq5F;
    private $Gr7jJ;
    private $n1h4w;
    public function mYTaPK60wfh() : string
    {
        return Icfhroj1Rrrzn::mOQJSxSdp2A($this->Fhq5F->getFilename());
    }
    public function mBE2ZEQSaNO() : Icfhroj1Rrrzn
    {
        goto uhoXl;
        hnHEy:
        $this->mgm9G4tMUce();
        goto yM6rr;
        uhoXl:
        if (!(null !== $this->Gr7jJ)) {
            goto c6PKs;
        }
        goto nu3iF;
        nu3iF:
        return $this->Gr7jJ;
        goto VW9oX;
        yM6rr:
        return $this->Gr7jJ;
        goto dYXI7;
        VW9oX:
        c6PKs:
        goto hnHEy;
        dYXI7:
    }
    private function mgm9G4tMUce() : Wa740mKVvCN9d
    {
        goto Nri3p;
        lkEkd:
        $this->Gr7jJ = Icfhroj1Rrrzn::mO8cvLsrSHf($G6pie);
        goto U10Ce;
        Nri3p:
        $eshGp = $this->n1h4w->get($this->mYTaPK60wfh());
        goto m1FxA;
        d41yZ:
        throw new QBvwqKevOagSc("File {$this->Fhq5F->getFilename()} is not PreSigned upload");
        goto WUe1E;
        U10Ce:
        return $this;
        goto bWKo1;
        bWKo1:
        pm_4H:
        goto d41yZ;
        QBueZ:
        $G6pie = json_decode($eshGp, true);
        goto lkEkd;
        m1FxA:
        if (!$eshGp) {
            goto pm_4H;
        }
        goto QBueZ;
        WUe1E:
    }
    public function m6ciYNnybZO($WiAUe, $vA0dB, $RwQud, $uH3S9, $zJG5Z, $Cnmk0 = 's3') : void
    {
        $this->Gr7jJ = Icfhroj1Rrrzn::mwmWYyYAfnE($this->Fhq5F, $WiAUe, $vA0dB, $zJG5Z, $RwQud, $uH3S9, $Cnmk0);
    }
}
