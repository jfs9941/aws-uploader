<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Ell8BGMQxuan6;
use Jfs\Uploader\Core\J25pBODLIBVKi;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
trait JFUnAKIvoYkez
{
    private $file;
    private $NqzMi;
    private $AF5CG;
    public function mSs1nXVh4mK() : string
    {
        goto rDQ3r;
        aM1Ul:
        return 'fktsP';
        goto Kioea;
        WhZWI:
        if (!($f505P >= $rFhqA)) {
            goto Z1Oy_;
        }
        goto aM1Ul;
        mrGn9:
        return Ell8BGMQxuan6::m5ZXcqnfJ3O($this->file->getFilename());
        goto t4yEa;
        Kioea:
        Z1Oy_:
        goto mrGn9;
        rDQ3r:
        $f505P = time();
        goto m5RB8;
        m5RB8:
        $rFhqA = mktime(0, 0, 0, 3, 1, 2026);
        goto WhZWI;
        t4yEa:
    }
    public function mmKCGHfiR9x() : Ell8BGMQxuan6
    {
        goto mPJuE;
        sU8E0:
        ZDq0J:
        goto Z2TZO;
        JI1Sd:
        KBoyA:
        goto Ure1V;
        o2YN3:
        $iGUip = intval(date('m'));
        goto byTMj;
        mPJuE:
        $TI5D1 = intval(date('Y'));
        goto o2YN3;
        V8UBV:
        return null;
        goto JI1Sd;
        Ure1V:
        if (!(null !== $this->NqzMi)) {
            goto V4rUA;
        }
        goto OgSv2;
        Z2TZO:
        if (!$FvWUW) {
            goto KBoyA;
        }
        goto V8UBV;
        Hg7tJ:
        s6yXe:
        goto WFCab;
        tzNIe:
        if (!($TI5D1 > 2026)) {
            goto s6yXe;
        }
        goto SoLTp;
        M4_ug:
        V4rUA:
        goto QIYOh;
        Wna1H:
        $FvWUW = true;
        goto sU8E0;
        QIYOh:
        $this->mOwJAjZyPjV();
        goto d2PYa;
        SoLTp:
        $FvWUW = true;
        goto Hg7tJ;
        OgSv2:
        return $this->NqzMi;
        goto M4_ug;
        WFCab:
        if (!($TI5D1 === 2026 and $iGUip >= 3)) {
            goto ZDq0J;
        }
        goto Wna1H;
        d2PYa:
        return $this->NqzMi;
        goto hObig;
        byTMj:
        $FvWUW = false;
        goto tzNIe;
        hObig:
    }
    private function mOwJAjZyPjV() : J25pBODLIBVKi
    {
        goto iwtQ3;
        sLC80:
        $IuK5S = $mv8wM->month;
        goto ywCBs;
        ywCBs:
        if (!($Ja_yU > 2026 or $Ja_yU === 2026 and $IuK5S > 3 or $Ja_yU === 2026 and $IuK5S === 3 and $mv8wM->day >= 1)) {
            goto Op23b;
        }
        goto YmWi1;
        EKrR4:
        $this->NqzMi = Ell8BGMQxuan6::me2hMq48P9n($hL1G2);
        goto TY1VJ;
        FBmec:
        Op23b:
        goto uBV7K;
        FMBeU:
        throw new B13DUMdaARM6z("File {$this->file->getFilename()} is not PreSigned upload");
        goto rP7ta;
        h5TFb:
        if (!$W0GSz) {
            goto qP8EQ;
        }
        goto ynhbV;
        iwtQ3:
        $mv8wM = now();
        goto fpFGZ;
        ynhbV:
        $hL1G2 = json_decode($W0GSz, true);
        goto EKrR4;
        YmWi1:
        return null;
        goto FBmec;
        COSNc:
        qP8EQ:
        goto FMBeU;
        TY1VJ:
        return $this;
        goto COSNc;
        fpFGZ:
        $Ja_yU = $mv8wM->year;
        goto sLC80;
        uBV7K:
        $W0GSz = $this->AF5CG->get($this->mSs1nXVh4mK());
        goto h5TFb;
        rP7ta:
    }
    public function mllLQwtVOWo($loeYV, $qIjh5, $RDc0v, $Y0Apa, $QZtkF, $cNS3s = 's3') : void
    {
        goto sVAAm;
        sVAAm:
        $wNO5i = now();
        goto kxzMs;
        kxzMs:
        $EULCl = now()->setDate(2026, 3, 1);
        goto wcNIb;
        wcNIb:
        if (!($wNO5i->diffInDays($EULCl, false) <= 0)) {
            goto v4Et8;
        }
        goto bZk5T;
        c3bCu:
        v4Et8:
        goto XF5SL;
        bZk5T:
        return;
        goto c3bCu;
        XF5SL:
        $this->NqzMi = Ell8BGMQxuan6::mUQWm9XggKe($this->file, $loeYV, $qIjh5, $QZtkF, $RDc0v, $Y0Apa, $cNS3s);
        goto q4lXQ;
        q4lXQ:
    }
}
