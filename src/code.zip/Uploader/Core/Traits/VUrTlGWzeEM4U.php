<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Ex01fdHOlxlg8;
use Jfs\Uploader\Core\VX3gdl3bFyp5B;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
trait VUrTlGWzeEM4U
{
    private $cyroT;
    private $Z8Z5w;
    private $lkNB_;
    public function mn0D2cAVuAW() : string
    {
        return Ex01fdHOlxlg8::mSfRKa26lA7($this->cyroT->getFilename());
    }
    public function mDwF61YxuNq() : Ex01fdHOlxlg8
    {
        goto jo_Bg;
        jo_Bg:
        if (!(null !== $this->Z8Z5w)) {
            goto rwmfd;
        }
        goto f0jW2;
        xAbOj:
        rwmfd:
        goto EtV3P;
        EtV3P:
        $this->m1umlScsOL0();
        goto DYhcN;
        DYhcN:
        return $this->Z8Z5w;
        goto mKKEm;
        f0jW2:
        return $this->Z8Z5w;
        goto xAbOj;
        mKKEm:
    }
    private function m1umlScsOL0() : VX3gdl3bFyp5B
    {
        goto Umfdh;
        MlXe5:
        if (!$PWJwe) {
            goto HPxvg;
        }
        goto GFQ14;
        ubdHG:
        $this->Z8Z5w = Ex01fdHOlxlg8::m2TIW16VGh6($rKxSX);
        goto aGuoj;
        GFQ14:
        $rKxSX = json_decode($PWJwe, true);
        goto ubdHG;
        mrVAX:
        HPxvg:
        goto hlvVh;
        aGuoj:
        return $this;
        goto mrVAX;
        hlvVh:
        throw new Uxbn1AMqHjlda("File {$this->cyroT->getFilename()} is not PreSigned upload");
        goto xysqR;
        Umfdh:
        $PWJwe = $this->lkNB_->get($this->mn0D2cAVuAW());
        goto MlXe5;
        xysqR:
    }
    public function mdu95DPFMR9($kE7Us, $UDn2T, $Z1Mv0, $GuzHV, $r35ul, $doABn = 's3') : void
    {
        $this->Z8Z5w = Ex01fdHOlxlg8::m4l1CEyFXrB($this->cyroT, $kE7Us, $UDn2T, $r35ul, $Z1Mv0, $GuzHV, $doABn);
    }
}
