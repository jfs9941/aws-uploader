<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\UGfAXCSEERPE4;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Exception\R2XNcytHoXlGH;
use Illuminate\Database\Eloquent\Model;
trait LkAAxyhGgmAFk
{
    private $Jx9sK = [];
    public function mHWfC8guF82($afpbB)
    {
        goto AGcKJ;
        AGcKJ:
        if ($this instanceof Model) {
            goto O7lvS;
        }
        goto iDm63;
        iDm63:
        $this->status = $afpbB;
        goto tock_;
        frhJg:
        O7lvS:
        goto OwsJF;
        OwsJF:
        $this->setAttribute('status', $afpbB);
        goto X2StE;
        X2StE:
        FY0wG:
        goto mFwJ1;
        tock_:
        goto FY0wG;
        goto frhJg;
        mFwJ1:
    }
    public function mdaaKGzzmmM()
    {
        goto TOvMg;
        mJKIc:
        return $this->status;
        goto VHcuF;
        SQrNf:
        Nak0v:
        goto mJKIc;
        TOvMg:
        if (!$this instanceof Model) {
            goto Nak0v;
        }
        goto u72PB;
        u72PB:
        return $this->getAttribute('status');
        goto SQrNf;
        VHcuF:
    }
    public function mWYAL72rhSp($br6Fr)
    {
        goto TgDh0;
        f_4wa:
        goto hrRWu;
        goto w0yzn;
        w0yzn:
        g7swE:
        goto dPnUK;
        W7haC:
        throw R2XNcytHoXlGH::m79WXbCylqX($this->id ?? 'unknown', $this->mdaaKGzzmmM(), $br6Fr);
        goto TqKa6;
        TqKa6:
        DQETG:
        goto BXVu0;
        BXVu0:
        $gyGHc = $this->mdaaKGzzmmM();
        goto BvBa3;
        dPnUK:
        $this->setAttribute('status', $br6Fr);
        goto NJ9w3;
        TgDh0:
        if ($this->mZjlp2Vg5Xs($br6Fr)) {
            goto DQETG;
        }
        goto W7haC;
        R0UOz:
        $this->status = $br6Fr;
        goto f_4wa;
        UllNx:
        oFvSD:
        goto fq6Kq;
        BvBa3:
        if ($this instanceof Model) {
            goto g7swE;
        }
        goto R0UOz;
        J1ATd:
        foreach ($this->Jx9sK as $MpqAj) {
            $MpqAj->mj4xpscl4k5($gyGHc, $br6Fr);
            uqSvG:
        }
        goto UllNx;
        NJ9w3:
        hrRWu:
        goto J1ATd;
        fq6Kq:
    }
    public function mZjlp2Vg5Xs($br6Fr)
    {
        goto exufh;
        QR3oK:
        u_Ym0:
        goto PhzGK;
        PhzGK:
        Dgg3B:
        goto hdP7P;
        exufh:
        switch ($this->status) {
            case LV0wDYHZInswq::UPLOADING:
                return LV0wDYHZInswq::UPLOADED == $br6Fr || LV0wDYHZInswq::UPLOADING == $br6Fr || LV0wDYHZInswq::ABORTED == $br6Fr;
            case LV0wDYHZInswq::UPLOADED:
                return LV0wDYHZInswq::PROCESSING == $br6Fr || LV0wDYHZInswq::DELETED == $br6Fr;
            case LV0wDYHZInswq::PROCESSING:
                return in_array($br6Fr, [LV0wDYHZInswq::WATERMARK_PROCESSED, LV0wDYHZInswq::THUMBNAIL_PROCESSED, LV0wDYHZInswq::ENCODING_PROCESSED, LV0wDYHZInswq::ENCODING_ERROR, LV0wDYHZInswq::BLUR_PROCESSED, LV0wDYHZInswq::DELETED, LV0wDYHZInswq::FINISHED, LV0wDYHZInswq::PROCESSING]);
            case LV0wDYHZInswq::FINISHED:
            case LV0wDYHZInswq::ABORTED:
                return LV0wDYHZInswq::DELETED == $br6Fr;
            case LV0wDYHZInswq::ENCODING_PROCESSED:
                return LV0wDYHZInswq::FINISHED == $br6Fr || LV0wDYHZInswq::DELETED == $br6Fr;
            default:
                return false;
        }
        goto QR3oK;
        hdP7P:
    }
    public function mfXOzZaHn0W(UGfAXCSEERPE4 $MpqAj)
    {
        $this->Jx9sK[] = $MpqAj;
    }
}
