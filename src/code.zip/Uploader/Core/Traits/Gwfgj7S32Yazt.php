<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Xg08pDZLenaCo;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Exception\SlPIHqOmIQ9pI;
use Illuminate\Database\Eloquent\Model;
trait Gwfgj7S32Yazt
{
    private $E9DwZ = [];
    public function mtNisNH4NQd($qjpMl)
    {
        goto M0tpi;
        CVFrb:
        $this->status = $qjpMl;
        goto EB1Oz;
        EB1Oz:
        goto PWk2M;
        goto GlUJC;
        M0tpi:
        if ($this instanceof Model) {
            goto sneFQ;
        }
        goto CVFrb;
        GlUJC:
        sneFQ:
        goto hRp3n;
        UC6dO:
        PWk2M:
        goto sbIzn;
        hRp3n:
        $this->setAttribute('status', $qjpMl);
        goto UC6dO;
        sbIzn:
    }
    public function mkME0lMOO9k()
    {
        goto SfIVh;
        P7r0r:
        return $this->getAttribute('status');
        goto AaSWh;
        hXJ88:
        return $this->status;
        goto T0V5E;
        SfIVh:
        if (!$this instanceof Model) {
            goto bwr37;
        }
        goto P7r0r;
        AaSWh:
        bwr37:
        goto hXJ88;
        T0V5E:
    }
    public function mKP20BPk5QC($xPw_b)
    {
        goto avwR0;
        EqNT1:
        if ($this instanceof Model) {
            goto Pxc0I;
        }
        goto FLE0X;
        tuYXH:
        Pxc0I:
        goto VCe7o;
        uIh7V:
        jp_6W:
        goto ydipb;
        gxQkH:
        $dKZf2 = $this->mkME0lMOO9k();
        goto EqNT1;
        jABiM:
        goto jp_6W;
        goto tuYXH;
        ydipb:
        foreach ($this->E9DwZ as $AgLg8) {
            $AgLg8->mnTJmPCq3BW($dKZf2, $xPw_b);
            pvbMM:
        }
        goto se45v;
        DHszT:
        throw SlPIHqOmIQ9pI::maZJnuk1mxI($this->id ?? 'unknown', $this->mkME0lMOO9k(), $xPw_b);
        goto Rha3s;
        Rha3s:
        mOVtB:
        goto gxQkH;
        avwR0:
        if ($this->m5dfjsbYcbp($xPw_b)) {
            goto mOVtB;
        }
        goto DHszT;
        se45v:
        gQV03:
        goto LyCy2;
        FLE0X:
        $this->status = $xPw_b;
        goto jABiM;
        VCe7o:
        $this->setAttribute('status', $xPw_b);
        goto uIh7V;
        LyCy2:
    }
    public function m5dfjsbYcbp($xPw_b)
    {
        goto B1_4T;
        qO1vp:
        sdWys:
        goto zp91C;
        zp91C:
        YCXwH:
        goto NOU03;
        B1_4T:
        switch ($this->status) {
            case Zgh3BZ2JVlG1A::UPLOADING:
                return Zgh3BZ2JVlG1A::UPLOADED == $xPw_b || Zgh3BZ2JVlG1A::UPLOADING == $xPw_b || Zgh3BZ2JVlG1A::ABORTED == $xPw_b;
            case Zgh3BZ2JVlG1A::UPLOADED:
                return Zgh3BZ2JVlG1A::PROCESSING == $xPw_b || Zgh3BZ2JVlG1A::DELETED == $xPw_b;
            case Zgh3BZ2JVlG1A::PROCESSING:
                return in_array($xPw_b, [Zgh3BZ2JVlG1A::WATERMARK_PROCESSED, Zgh3BZ2JVlG1A::THUMBNAIL_PROCESSED, Zgh3BZ2JVlG1A::ENCODING_PROCESSED, Zgh3BZ2JVlG1A::ENCODING_ERROR, Zgh3BZ2JVlG1A::BLUR_PROCESSED, Zgh3BZ2JVlG1A::DELETED, Zgh3BZ2JVlG1A::FINISHED, Zgh3BZ2JVlG1A::PROCESSING]);
            case Zgh3BZ2JVlG1A::FINISHED:
            case Zgh3BZ2JVlG1A::ABORTED:
                return Zgh3BZ2JVlG1A::DELETED == $xPw_b;
            case Zgh3BZ2JVlG1A::ENCODING_PROCESSED:
                return Zgh3BZ2JVlG1A::FINISHED == $xPw_b || Zgh3BZ2JVlG1A::DELETED == $xPw_b;
            default:
                return false;
        }
        goto qO1vp;
        NOU03:
    }
    public function mQp3zHVoxcU(Xg08pDZLenaCo $AgLg8)
    {
        $this->E9DwZ[] = $AgLg8;
    }
}
