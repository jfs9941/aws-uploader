<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\WOlVkQsBFs8pP;
use Jfs\Uploader\Core\I9eXouytPf2zH;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
trait LFne7ijSG70wJ
{
    private $T6rAm;
    private $O2abO;
    private $TeKrB;
    public function mjQ6d2ONI6n() : string
    {
        return WOlVkQsBFs8pP::md7VzGoRhNQ($this->T6rAm->getFilename());
    }
    public function mbu93E3v49T() : WOlVkQsBFs8pP
    {
        goto ryC0G;
        XX3kZ:
        C3Gn4:
        goto xjKAE;
        xjKAE:
        $this->mcJKeP3Rzqg();
        goto UNTK_;
        UNTK_:
        return $this->O2abO;
        goto jXgRm;
        ryC0G:
        if (!(null !== $this->O2abO)) {
            goto C3Gn4;
        }
        goto bcJ0j;
        bcJ0j:
        return $this->O2abO;
        goto XX3kZ;
        jXgRm:
    }
    private function mcJKeP3Rzqg() : I9eXouytPf2zH
    {
        goto mCBJB;
        d8fc9:
        return $this;
        goto U35CE;
        fDzDo:
        if (!$bIApG) {
            goto gZJ9G;
        }
        goto TrXjw;
        mCBJB:
        $bIApG = $this->TeKrB->get($this->mjQ6d2ONI6n());
        goto fDzDo;
        rkxQ6:
        throw new Lki0sGWiU5Kzv("File {$this->T6rAm->getFilename()} is not PreSigned upload");
        goto DG1tZ;
        U35CE:
        gZJ9G:
        goto rkxQ6;
        TrXjw:
        $NSqE9 = json_decode($bIApG, true);
        goto rhPK9;
        rhPK9:
        $this->O2abO = WOlVkQsBFs8pP::mcSTjhdi3jH($NSqE9);
        goto d8fc9;
        DG1tZ:
    }
    public function myV5jotB85j($Quhfo, $w_BOX, $TZqXq, $ec0ac, $DLEqG, $GWbyt = 's3') : void
    {
        $this->O2abO = WOlVkQsBFs8pP::mQFar7u0XBm($this->T6rAm, $Quhfo, $w_BOX, $DLEqG, $TZqXq, $ec0ac, $GWbyt);
    }
}
