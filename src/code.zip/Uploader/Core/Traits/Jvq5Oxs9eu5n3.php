<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\JL46r4tF2ZJbX;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Exception\JcxKbdowoFJnP;
use Illuminate\Database\Eloquent\Model;
trait Jvq5Oxs9eu5n3
{
    private $PquT6 = [];
    public function m5qfukNPanz($NuXOM)
    {
        goto g3gXP;
        uD9wT:
        jQMzg:
        goto Nq96I;
        Nq96I:
        $this->setAttribute('status', $NuXOM);
        goto IlQip;
        rG5Rm:
        goto tofGI;
        goto uD9wT;
        IlQip:
        tofGI:
        goto qCcBy;
        rdfSB:
        $this->status = $NuXOM;
        goto rG5Rm;
        g3gXP:
        if ($this instanceof Model) {
            goto jQMzg;
        }
        goto rdfSB;
        qCcBy:
    }
    public function msOrEBleVFB()
    {
        goto v_9bZ;
        jicDa:
        return $this->status;
        goto S3VNY;
        S08Wz:
        return $this->getAttribute('status');
        goto pkEMt;
        pkEMt:
        AhAIT:
        goto jicDa;
        v_9bZ:
        if (!$this instanceof Model) {
            goto AhAIT;
        }
        goto S08Wz;
        S3VNY:
    }
    public function mmjJCJ3ck7B($gVAUx)
    {
        goto LIDe5;
        jjgiy:
        qHySk:
        goto WWndO;
        R8Exi:
        lLU6Z:
        goto nHP81;
        Wy4OL:
        goto UNTge;
        goto R8Exi;
        LIDe5:
        if ($this->mnPJAsNZX2b($gVAUx)) {
            goto SSxiK;
        }
        goto sqL0w;
        nHP81:
        $this->setAttribute('status', $gVAUx);
        goto ygfRy;
        sqL0w:
        throw JcxKbdowoFJnP::m9M1dA7CvUJ($this->id ?? 'unknown', $this->msOrEBleVFB(), $gVAUx);
        goto g_6f4;
        ygfRy:
        UNTge:
        goto llfgb;
        Z4BRw:
        $TKmjE = $this->msOrEBleVFB();
        goto PjRqk;
        PjRqk:
        if ($this instanceof Model) {
            goto lLU6Z;
        }
        goto ASYUb;
        llfgb:
        foreach ($this->PquT6 as $jFtH3) {
            $jFtH3->mueWblWOUUZ($TKmjE, $gVAUx);
            hjWLE:
        }
        goto jjgiy;
        ASYUb:
        $this->status = $gVAUx;
        goto Wy4OL;
        g_6f4:
        SSxiK:
        goto Z4BRw;
        WWndO:
    }
    public function mnPJAsNZX2b($gVAUx)
    {
        goto z4WVC;
        z4WVC:
        switch ($this->status) {
            case QE1dzvgcPWV6R::UPLOADING:
                return QE1dzvgcPWV6R::UPLOADED == $gVAUx || QE1dzvgcPWV6R::UPLOADING == $gVAUx || QE1dzvgcPWV6R::ABORTED == $gVAUx;
            case QE1dzvgcPWV6R::UPLOADED:
                return QE1dzvgcPWV6R::PROCESSING == $gVAUx || QE1dzvgcPWV6R::DELETED == $gVAUx;
            case QE1dzvgcPWV6R::PROCESSING:
                return in_array($gVAUx, [QE1dzvgcPWV6R::WATERMARK_PROCESSED, QE1dzvgcPWV6R::THUMBNAIL_PROCESSED, QE1dzvgcPWV6R::ENCODING_PROCESSED, QE1dzvgcPWV6R::ENCODING_ERROR, QE1dzvgcPWV6R::BLUR_PROCESSED, QE1dzvgcPWV6R::DELETED, QE1dzvgcPWV6R::FINISHED, QE1dzvgcPWV6R::PROCESSING]);
            case QE1dzvgcPWV6R::FINISHED:
            case QE1dzvgcPWV6R::ABORTED:
                return QE1dzvgcPWV6R::DELETED == $gVAUx;
            case QE1dzvgcPWV6R::ENCODING_PROCESSED:
                return QE1dzvgcPWV6R::FINISHED == $gVAUx || QE1dzvgcPWV6R::DELETED == $gVAUx;
            default:
                return false;
        }
        goto kAYg5;
        kAYg5:
        erLmy:
        goto k0ryK;
        k0ryK:
        ItGjm:
        goto KRhAf;
        KRhAf:
    }
    public function mRlOizT0SxG(JL46r4tF2ZJbX $jFtH3)
    {
        $this->PquT6[] = $jFtH3;
    }
}
