<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XlkXvlTYaUWJ1;
use Jfs\Uploader\Core\IQDEtKorMDqYa;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
trait S7x0KXILEa3L2
{
    private $WpbZG;
    private $cjp2p;
    private $gSpRj;
    private $DksH2;
    public function mwL2ScZNW65() : string
    {
        return XlkXvlTYaUWJ1::myM8iTLiY7F($this->WpbZG->getFilename());
    }
    public function mIrarJhaP0j() : XlkXvlTYaUWJ1
    {
        goto uSpX4;
        G2NDz:
        g3bP0:
        goto v2iXf;
        sJs_4:
        return $this->cjp2p;
        goto G2NDz;
        v2iXf:
        $this->muOym0kQoUZ();
        goto zamX3;
        uSpX4:
        if (!(null !== $this->cjp2p)) {
            goto g3bP0;
        }
        goto sJs_4;
        zamX3:
        return $this->cjp2p;
        goto fszO0;
        fszO0:
    }
    private function muOym0kQoUZ() : IQDEtKorMDqYa
    {
        goto N0Vkk;
        N0Vkk:
        $j7g_S = $this->gSpRj->get($this->mwL2ScZNW65());
        goto DoQ98;
        Wu1sL:
        return $this;
        goto fdEYs;
        fdEYs:
        EfcBS:
        goto zW6ob;
        SgyAd:
        mFuK_:
        goto Pb_rS;
        BcdVQ:
        $j7g_S = $this->DksH2->get($this->mwL2ScZNW65());
        goto SgyAd;
        DoQ98:
        if ($j7g_S) {
            goto mFuK_;
        }
        goto BcdVQ;
        Pb_rS:
        if (!$j7g_S) {
            goto EfcBS;
        }
        goto JjUQs;
        JjUQs:
        $cBuzS = json_decode($j7g_S, true);
        goto rpGHY;
        rpGHY:
        $this->cjp2p = XlkXvlTYaUWJ1::moch7tA6Ebz($cBuzS);
        goto Wu1sL;
        zW6ob:
        throw new CU2TWW78cXYKP("File {$this->WpbZG->getFilename()} is not PreSigned upload");
        goto rV5X2;
        rV5X2:
    }
    public function m56tQT9akP6($OTiq3, $Y3vd4, $pYJII, $a2L2v, $NURhE, $LvK26 = 's3') : void
    {
        $this->cjp2p = XlkXvlTYaUWJ1::mD3voKrVL5W($this->WpbZG, $OTiq3, $Y3vd4, $NURhE, $pYJII, $a2L2v, $LvK26);
    }
}
