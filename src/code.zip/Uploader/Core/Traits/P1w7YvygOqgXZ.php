<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XxIkOu3r3u4yJ;
use Jfs\Uploader\Core\D4VgMZN43BF8o;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
trait P1w7YvygOqgXZ
{
    private $VCrIB;
    private $AOnrp;
    private $NZ4o8;
    public function mEFYvbcZNB2() : string
    {
        return XxIkOu3r3u4yJ::mCDEbHkhoSq($this->VCrIB->getFilename());
    }
    public function mlPpDqeRPNC() : XxIkOu3r3u4yJ
    {
        goto C2N7F;
        NKRWu:
        $this->mPo0mAGzHS9();
        goto WYa62;
        C2N7F:
        if (!(null !== $this->AOnrp)) {
            goto ic7Hw;
        }
        goto B_x2v;
        XUQRI:
        ic7Hw:
        goto NKRWu;
        B_x2v:
        return $this->AOnrp;
        goto XUQRI;
        WYa62:
        return $this->AOnrp;
        goto aYf3i;
        aYf3i:
    }
    private function mPo0mAGzHS9() : D4VgMZN43BF8o
    {
        goto IAkQX;
        mw17k:
        jxZA7:
        goto dt1ye;
        IAkQX:
        $zlsyR = $this->NZ4o8->get($this->mEFYvbcZNB2());
        goto GskaN;
        qZDES:
        $kbnGg = json_decode($zlsyR, true);
        goto hf8g6;
        GskaN:
        if (!$zlsyR) {
            goto jxZA7;
        }
        goto qZDES;
        dt1ye:
        throw new PgT1yqHzwrHid("File {$this->VCrIB->getFilename()} is not PreSigned upload");
        goto Zdggm;
        hf8g6:
        $this->AOnrp = XxIkOu3r3u4yJ::mby1e5w9dvl($kbnGg);
        goto nyt7G;
        nyt7G:
        return $this;
        goto mw17k;
        Zdggm:
    }
    public function mvibDOOdADV($OHboS, $srVys, $Hg1G3, $sF841, $E3Fxu, $N4v2t = 's3') : void
    {
        $this->AOnrp = XxIkOu3r3u4yJ::mS8DGJOmSpO($this->VCrIB, $OHboS, $srVys, $E3Fxu, $Hg1G3, $sF841, $N4v2t);
    }
}
