<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\D30TCm1otQUnt;
use Jfs\Uploader\Core\UYVrA8my964mM;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
trait TadWCyTQ43Otx
{
    private $uq849;
    private $zoyaL;
    private $aEqGh;
    public function mlQjqylPuOa() : string
    {
        return D30TCm1otQUnt::mttyt25rY1Q($this->uq849->getFilename());
    }
    public function m8KWEnHETkc() : D30TCm1otQUnt
    {
        goto i0I4w;
        i0I4w:
        if (!(null !== $this->zoyaL)) {
            goto fTfep;
        }
        goto QwCdt;
        QwCdt:
        return $this->zoyaL;
        goto e0ttg;
        zgMns:
        return $this->zoyaL;
        goto kPAaj;
        e0ttg:
        fTfep:
        goto Qn_1V;
        Qn_1V:
        $this->mvo29kYaGxY();
        goto zgMns;
        kPAaj:
    }
    private function mvo29kYaGxY() : UYVrA8my964mM
    {
        goto LzDXA;
        naTg2:
        if (!$C4SJy) {
            goto vCKSM;
        }
        goto l7fJP;
        Hh3iv:
        vCKSM:
        goto s_BGR;
        J9AGb:
        return $this;
        goto Hh3iv;
        s_BGR:
        throw new UZ54KLSfEVX7F("File {$this->uq849->getFilename()} is not PreSigned upload");
        goto Z3NIw;
        rtc4L:
        $this->zoyaL = D30TCm1otQUnt::mXUAOPT49dG($wFinC);
        goto J9AGb;
        LzDXA:
        $C4SJy = $this->aEqGh->get($this->mlQjqylPuOa());
        goto naTg2;
        l7fJP:
        $wFinC = json_decode($C4SJy, true);
        goto rtc4L;
        Z3NIw:
    }
    public function m1rPM77PMvw($OU6uU, $M6km1, $FTk6S, $X3lTW, $mN8kw, $X0gtT = 's3') : void
    {
        $this->zoyaL = D30TCm1otQUnt::mSd5AOmkql6($this->uq849, $OU6uU, $M6km1, $mN8kw, $FTk6S, $X3lTW, $X0gtT);
    }
}
