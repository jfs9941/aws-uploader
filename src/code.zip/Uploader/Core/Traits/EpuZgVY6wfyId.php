<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait EpuZgVY6wfyId
{
    private function mV9c6queidQ(string $QBYnF) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $QBYnF]));
    }
}
