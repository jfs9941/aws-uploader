<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XfZUz9XnPzPJ1;
use Jfs\Uploader\Core\PLi20pZSTTBHP;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
trait Mkcxm8a3fkZS2
{
    private $d3RM8;
    private $tky6T;
    private $kgKzZ;
    public function m9Cbs65gEpK() : string
    {
        return XfZUz9XnPzPJ1::mpccx90wi1r($this->d3RM8->getFilename());
    }
    public function mzbGvZW3SMF() : XfZUz9XnPzPJ1
    {
        goto QK4S8;
        mLOrA:
        V_v8V:
        goto KYBh_;
        QK4S8:
        if (!(null !== $this->tky6T)) {
            goto V_v8V;
        }
        goto KjmF4;
        KjmF4:
        return $this->tky6T;
        goto mLOrA;
        KYBh_:
        $this->mGkpsdCtmoi();
        goto r_TtA;
        r_TtA:
        return $this->tky6T;
        goto F2mx0;
        F2mx0:
    }
    private function mGkpsdCtmoi() : PLi20pZSTTBHP
    {
        goto CdAzs;
        ZWw38:
        return $this;
        goto plIf5;
        o6bQj:
        throw new Jcm0L35ZiDWQ6("File {$this->d3RM8->getFilename()} is not PreSigned upload");
        goto QgFpJ;
        Vzktk:
        $this->tky6T = XfZUz9XnPzPJ1::mIKPNTVQ0Rv($I4VLo);
        goto ZWw38;
        yTXMr:
        $I4VLo = json_decode($G6yMr, true);
        goto Vzktk;
        CdAzs:
        $G6yMr = $this->kgKzZ->get($this->m9Cbs65gEpK());
        goto GDHO9;
        GDHO9:
        if (!$G6yMr) {
            goto tcWj9;
        }
        goto yTXMr;
        plIf5:
        tcWj9:
        goto o6bQj;
        QgFpJ:
    }
    public function mrsdCE1eS2e($DVljR, $MPOZB, $icV6U, $T52tC, $Vz1ad, $tbIVu = 's3') : void
    {
        $this->tky6T = XfZUz9XnPzPJ1::mdtBJkm8O9m($this->d3RM8, $DVljR, $MPOZB, $Vz1ad, $icV6U, $T52tC, $tbIVu);
    }
}
