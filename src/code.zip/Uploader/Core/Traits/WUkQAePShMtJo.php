<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Zw8MUfOdDRfcx;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Exception\RRyzFa9lvheK9;
use Illuminate\Database\Eloquent\Model;
trait WUkQAePShMtJo
{
    private $l8sdc = [];
    public function mNsps8Id3BK($iogAQ)
    {
        goto Qx41f;
        ZflcI:
        zU7MP:
        goto NzX3E;
        Z1EMy:
        goto gS4VS;
        goto ZflcI;
        z4VGs:
        gS4VS:
        goto W1QDN;
        Qx41f:
        if ($this instanceof Model) {
            goto zU7MP;
        }
        goto QXeOi;
        NzX3E:
        $this->setAttribute('status', $iogAQ);
        goto z4VGs;
        QXeOi:
        $this->status = $iogAQ;
        goto Z1EMy;
        W1QDN:
    }
    public function mzzMfB8y7MU()
    {
        goto TzMc_;
        QY7Gq:
        return $this->getAttribute('status');
        goto QUG1j;
        TzMc_:
        if (!$this instanceof Model) {
            goto ZCRoK;
        }
        goto QY7Gq;
        LClhI:
        return $this->status;
        goto yMttJ;
        QUG1j:
        ZCRoK:
        goto LClhI;
        yMttJ:
    }
    public function m6ASJ5S5Ktp($JlySh)
    {
        goto ZNL5J;
        R9V7w:
        $FbAIY = $this->mzzMfB8y7MU();
        goto xVhIj;
        poUab:
        $this->status = $JlySh;
        goto WWAmE;
        WWAmE:
        goto nuYuj;
        goto C9f1L;
        roLWk:
        $this->setAttribute('status', $JlySh);
        goto hGOLQ;
        ZNL5J:
        if ($this->mg6tOiAsrlZ($JlySh)) {
            goto n_d8Q;
        }
        goto Vcd8O;
        Vcd8O:
        throw RRyzFa9lvheK9::mT3R6dlRbiH($this->id ?? 'unknown', $this->mzzMfB8y7MU(), $JlySh);
        goto H4WPd;
        xVhIj:
        if ($this instanceof Model) {
            goto rD_j1;
        }
        goto poUab;
        E0jAK:
        dcoMw:
        goto eUonr;
        jWYzE:
        foreach ($this->l8sdc as $ncDKY) {
            $ncDKY->mHzEGxfe0qf($FbAIY, $JlySh);
            k29GD:
        }
        goto E0jAK;
        H4WPd:
        n_d8Q:
        goto R9V7w;
        C9f1L:
        rD_j1:
        goto roLWk;
        hGOLQ:
        nuYuj:
        goto jWYzE;
        eUonr:
    }
    public function mg6tOiAsrlZ($JlySh)
    {
        goto Vwp11;
        MbMRC:
        Do640:
        goto uaFo_;
        Vwp11:
        switch ($this->status) {
            case T93Mcsw1gA3an::UPLOADING:
                return T93Mcsw1gA3an::UPLOADED == $JlySh || T93Mcsw1gA3an::UPLOADING == $JlySh || T93Mcsw1gA3an::ABORTED == $JlySh;
            case T93Mcsw1gA3an::UPLOADED:
                return T93Mcsw1gA3an::PROCESSING == $JlySh || T93Mcsw1gA3an::DELETED == $JlySh;
            case T93Mcsw1gA3an::PROCESSING:
                return in_array($JlySh, [T93Mcsw1gA3an::WATERMARK_PROCESSED, T93Mcsw1gA3an::THUMBNAIL_PROCESSED, T93Mcsw1gA3an::ENCODING_PROCESSED, T93Mcsw1gA3an::ENCODING_ERROR, T93Mcsw1gA3an::BLUR_PROCESSED, T93Mcsw1gA3an::DELETED, T93Mcsw1gA3an::FINISHED, T93Mcsw1gA3an::PROCESSING]);
            case T93Mcsw1gA3an::FINISHED:
            case T93Mcsw1gA3an::ABORTED:
                return T93Mcsw1gA3an::DELETED == $JlySh;
            case T93Mcsw1gA3an::ENCODING_PROCESSED:
                return T93Mcsw1gA3an::FINISHED == $JlySh || T93Mcsw1gA3an::DELETED == $JlySh;
            default:
                return false;
        }
        goto Bh1BO;
        Bh1BO:
        gU_yu:
        goto MbMRC;
        uaFo_:
    }
    public function mhhx9gSDj1U(Zw8MUfOdDRfcx $ncDKY)
    {
        $this->l8sdc[] = $ncDKY;
    }
}
