<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\KHzXmciCVGzLc;
use Jfs\Uploader\Core\NfmgXUF97Fg3H;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
trait M1dxm8IlghHUG
{
    private $tp12K;
    private $Gn2_c;
    private $fz3B9;
    public function mbZTP3Wyy1I() : string
    {
        return KHzXmciCVGzLc::mfxFf7GQ3ZC($this->tp12K->getFilename());
    }
    public function mu6Z5XKe7fC() : KHzXmciCVGzLc
    {
        goto Ho0gZ;
        ixp7l:
        return $this->Gn2_c;
        goto d1UyD;
        Ho0gZ:
        if (!(null !== $this->Gn2_c)) {
            goto V9jra;
        }
        goto n51kb;
        UWHa4:
        $this->mDlbdm0o1yj();
        goto ixp7l;
        n51kb:
        return $this->Gn2_c;
        goto mxhP2;
        mxhP2:
        V9jra:
        goto UWHa4;
        d1UyD:
    }
    private function mDlbdm0o1yj() : NfmgXUF97Fg3H
    {
        goto ECgW3;
        IzcP4:
        if (!$P6aYD) {
            goto LYqFU;
        }
        goto B0x2V;
        dZ32A:
        $this->Gn2_c = KHzXmciCVGzLc::mATjowjbrtH($DiTJK);
        goto zbbcM;
        zbbcM:
        return $this;
        goto CGiZw;
        CGiZw:
        LYqFU:
        goto MPMpV;
        ECgW3:
        $P6aYD = $this->fz3B9->get($this->mbZTP3Wyy1I());
        goto IzcP4;
        MPMpV:
        throw new Pl4WlsTHZq9V7("File {$this->tp12K->getFilename()} is not PreSigned upload");
        goto VFeoT;
        B0x2V:
        $DiTJK = json_decode($P6aYD, true);
        goto dZ32A;
        VFeoT:
    }
    public function myYWHwbPX4L($uYSjI, $VpggW, $EBuuG, $z_jcN, $hxvZ_, $OFz0s = 's3') : void
    {
        $this->Gn2_c = KHzXmciCVGzLc::mzfh3SG39FC($this->tp12K, $uYSjI, $VpggW, $hxvZ_, $EBuuG, $z_jcN, $OFz0s);
    }
}
