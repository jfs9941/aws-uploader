<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\HH3lB6zqpldAM;
use Jfs\Uploader\Core\I0VIwBtNAG2Lq;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
trait JfXCFnzVYQAiL
{
    private $EA4YD;
    private $A82Oe;
    private $z9V_f;
    public function mmOYDrQaoGz() : string
    {
        return HH3lB6zqpldAM::m8RSRuVXPMu($this->EA4YD->getFilename());
    }
    public function mAOwHvxkwWq() : HH3lB6zqpldAM
    {
        goto bpNrD;
        XMwPc:
        $this->mxj0A5vEyqK();
        goto NroZg;
        bpNrD:
        if (!(null !== $this->A82Oe)) {
            goto C8Y22;
        }
        goto wxRER;
        NroZg:
        return $this->A82Oe;
        goto II50P;
        wxRER:
        return $this->A82Oe;
        goto MYVno;
        MYVno:
        C8Y22:
        goto XMwPc;
        II50P:
    }
    private function mxj0A5vEyqK() : I0VIwBtNAG2Lq
    {
        goto zfnSF;
        Sez8t:
        if (!$e0QYw) {
            goto v5sf4;
        }
        goto O3bZu;
        pzZBw:
        v5sf4:
        goto sRqVo;
        zfnSF:
        $e0QYw = $this->z9V_f->get($this->mmOYDrQaoGz());
        goto Sez8t;
        uriyf:
        $this->A82Oe = HH3lB6zqpldAM::mzh0Jv6nlRp($Vqzxf);
        goto tbFvn;
        sRqVo:
        throw new NCCpOFnEetEh7("File {$this->EA4YD->getFilename()} is not PreSigned upload");
        goto mL1BN;
        O3bZu:
        $Vqzxf = json_decode($e0QYw, true);
        goto uriyf;
        tbFvn:
        return $this;
        goto pzZBw;
        mL1BN:
    }
    public function mFwOe5ikmX6($rsp_O, $HwPCY, $eEti6, $S0AL0, $TbUNq, $Rmh9e = 's3') : void
    {
        $this->A82Oe = HH3lB6zqpldAM::mSvlo5fN5Xi($this->EA4YD, $rsp_O, $HwPCY, $TbUNq, $eEti6, $S0AL0, $Rmh9e);
    }
}
