<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait HZEaeFbD9s4vj
{
    private function mNdKlYe5e7D(string $w91p_) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $w91p_]));
    }
}
