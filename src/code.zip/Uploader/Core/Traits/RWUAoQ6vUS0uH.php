<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Pr07JVh1ChqJO;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Exception\Vfh0JNvlNsuXG;
use Illuminate\Database\Eloquent\Model;
trait RWUAoQ6vUS0uH
{
    private $YCW_3 = [];
    public function myjAI8i1TR7($CAMPq)
    {
        goto pqS3w;
        xXxkb:
        r8lFU:
        goto yZLSr;
        yAnry:
        QTnGE:
        goto XVAoI;
        yZLSr:
        $this->setAttribute('status', $CAMPq);
        goto yAnry;
        pqS3w:
        if ($this instanceof Model) {
            goto r8lFU;
        }
        goto ZyMDN;
        ZyMDN:
        $this->status = $CAMPq;
        goto sEFNj;
        sEFNj:
        goto QTnGE;
        goto xXxkb;
        XVAoI:
    }
    public function mOukRivI0jG()
    {
        goto IymqZ;
        TcvJM:
        GlZdi:
        goto azZQH;
        IymqZ:
        if (!$this instanceof Model) {
            goto GlZdi;
        }
        goto onMBk;
        onMBk:
        return $this->getAttribute('status');
        goto TcvJM;
        azZQH:
        return $this->status;
        goto we9y0;
        we9y0:
    }
    public function mtyCvJ3PeFW($WZaZ9)
    {
        goto JjzU3;
        ezbNO:
        OspEK:
        goto wc17k;
        O3a_v:
        foreach ($this->YCW_3 as $cF2wR) {
            $cF2wR->mI8wqsETHZd($O4f9E, $WZaZ9);
            tJS2l:
        }
        goto ezbNO;
        QQ81Y:
        $this->status = $WZaZ9;
        goto B2DBy;
        JjzU3:
        if ($this->mDyZeMdHaEJ($WZaZ9)) {
            goto XXcc0;
        }
        goto NnTNf;
        RoQKL:
        $O4f9E = $this->mOukRivI0jG();
        goto IlKGC;
        FO0DB:
        XXcc0:
        goto RoQKL;
        IlKGC:
        if ($this instanceof Model) {
            goto sCLd0;
        }
        goto QQ81Y;
        NnTNf:
        throw Vfh0JNvlNsuXG::mUetFwhXsNr($this->id ?? 'unknown', $this->mOukRivI0jG(), $WZaZ9);
        goto FO0DB;
        W2R_n:
        gAgxT:
        goto O3a_v;
        h6UTS:
        sCLd0:
        goto WpZvu;
        B2DBy:
        goto gAgxT;
        goto h6UTS;
        WpZvu:
        $this->setAttribute('status', $WZaZ9);
        goto W2R_n;
        wc17k:
    }
    public function mDyZeMdHaEJ($WZaZ9)
    {
        goto qJyip;
        PIBf_:
        HDJHo:
        goto Vvrg_;
        qJyip:
        switch ($this->status) {
            case Fsm7WCrUwVWh9::UPLOADING:
                return Fsm7WCrUwVWh9::UPLOADED == $WZaZ9 || Fsm7WCrUwVWh9::UPLOADING == $WZaZ9 || Fsm7WCrUwVWh9::ABORTED == $WZaZ9;
            case Fsm7WCrUwVWh9::UPLOADED:
                return Fsm7WCrUwVWh9::PROCESSING == $WZaZ9 || Fsm7WCrUwVWh9::DELETED == $WZaZ9;
            case Fsm7WCrUwVWh9::PROCESSING:
                return in_array($WZaZ9, [Fsm7WCrUwVWh9::WATERMARK_PROCESSED, Fsm7WCrUwVWh9::THUMBNAIL_PROCESSED, Fsm7WCrUwVWh9::ENCODING_PROCESSED, Fsm7WCrUwVWh9::ENCODING_ERROR, Fsm7WCrUwVWh9::BLUR_PROCESSED, Fsm7WCrUwVWh9::DELETED, Fsm7WCrUwVWh9::FINISHED, Fsm7WCrUwVWh9::PROCESSING]);
            case Fsm7WCrUwVWh9::FINISHED:
            case Fsm7WCrUwVWh9::ABORTED:
                return Fsm7WCrUwVWh9::DELETED == $WZaZ9;
            case Fsm7WCrUwVWh9::ENCODING_PROCESSED:
                return Fsm7WCrUwVWh9::FINISHED == $WZaZ9 || Fsm7WCrUwVWh9::DELETED == $WZaZ9;
            default:
                return false;
        }
        goto t9MfG;
        t9MfG:
        qdrlh:
        goto PIBf_;
        Vvrg_:
    }
    public function mmI31EdIVP7(Pr07JVh1ChqJO $cF2wR)
    {
        $this->YCW_3[] = $cF2wR;
    }
}
