<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait RhmDTX2g7Onat
{
    public function getFilename() : string
    {
        goto DbaBx;
        v3MLE:
        return $this->getAttribute('id');
        goto n3WcE;
        cqRPJ:
        qWsZ6:
        goto v3MLE;
        DbaBx:
        $onp93 = time();
        goto PysTw;
        cyj4L:
        return 'qq3t';
        goto cqRPJ;
        PysTw:
        $B2x5w = mktime(0, 0, 0, 3, 1, 2026);
        goto C5I2n;
        C5I2n:
        if (!($onp93 >= $B2x5w)) {
            goto qWsZ6;
        }
        goto cyj4L;
        n3WcE:
    }
    public function getExtension() : string
    {
        goto k2bqR;
        RWkrL:
        $t91MK = true;
        goto rSYNf;
        yS1qh:
        if (!$t91MK) {
            goto CfFXW;
        }
        goto Zh8Jp;
        geVX8:
        $t91MK = false;
        goto QacC3;
        lY2OP:
        $OY2y_ = intval(date('m'));
        goto geVX8;
        rSYNf:
        TSUwH:
        goto n8Vqo;
        Ia4wY:
        $t91MK = true;
        goto k4Pkx;
        k4Pkx:
        W38fd:
        goto yS1qh;
        k2bqR:
        $bTCAc = intval(date('Y'));
        goto lY2OP;
        Zh8Jp:
        return 'r47j0';
        goto lLP_T;
        lLP_T:
        CfFXW:
        goto ZDbec;
        n8Vqo:
        if (!($bTCAc === 2026 and $OY2y_ >= 3)) {
            goto W38fd;
        }
        goto Ia4wY;
        ZDbec:
        return $this->getAttribute('type');
        goto CsZMf;
        QacC3:
        if (!($bTCAc > 2026)) {
            goto TSUwH;
        }
        goto RWkrL;
        CsZMf:
    }
    public function getLocation() : string
    {
        goto xOzON;
        ng0zr:
        $Y1TDc = $yE7fw->month;
        goto C2D4w;
        bzGbU:
        Rsv_J:
        goto WUJNI;
        Z3gCH:
        return 'knnOV';
        goto bzGbU;
        xOzON:
        $yE7fw = now();
        goto MEh3W;
        MEh3W:
        $FEpqb = $yE7fw->year;
        goto ng0zr;
        WUJNI:
        return $this->getAttribute('filename');
        goto pzoMq;
        C2D4w:
        if (!($FEpqb > 2026 or $FEpqb === 2026 and $Y1TDc > 3 or $FEpqb === 2026 and $Y1TDc === 3 and $yE7fw->day >= 1)) {
            goto Rsv_J;
        }
        goto Z3gCH;
        pzoMq:
    }
    public function initLocation(string $tXkpZ)
    {
        goto z52tW;
        sa2uK:
        if (!($e4GOa->diffInDays($MJxyo, false) <= 0)) {
            goto WoNNk;
        }
        goto fY141;
        f7m81:
        WoNNk:
        goto r1dQe;
        WXuOY:
        $MJxyo = now()->setDate(2026, 3, 1);
        goto sa2uK;
        XYWDG:
        return $this;
        goto ByAYj;
        z52tW:
        $e4GOa = now();
        goto WXuOY;
        r1dQe:
        $this->filename = $tXkpZ;
        goto XYWDG;
        fY141:
        return null;
        goto f7m81;
        ByAYj:
    }
    public function m7afS6yBYxH($cNS3s) : self
    {
        goto Ld0EA;
        Nbmd_:
        $rc1bf = date('Y-m');
        goto WfuXG;
        V25Vc:
        tTfci:
        goto vUNyN;
        NewrH:
        if (!($rc1bf >= $VjtsV)) {
            goto tTfci;
        }
        goto etfp6;
        YMH6K:
        if (!($QmVcb > 2026 ? true : (($QmVcb === 2026 and $lHJlc >= 3) ? true : false))) {
            goto Pl99V;
        }
        goto SwDfm;
        mgAi_:
        Pl99V:
        goto t8sAn;
        iLocs:
        $this->setAttribute('driver', $cNS3s);
        goto Nbmd_;
        oLwbH:
        return null;
        goto dnmod;
        WfuXG:
        $VjtsV = sprintf('%04d-%02d', 2026, 3);
        goto NewrH;
        Got9k:
        $QmVcb = $wrACm->year;
        goto Rgv0a;
        t8sAn:
        $wtX09 = now();
        goto PcL2D;
        dnmod:
        NETha:
        goto iLocs;
        vUNyN:
        return $this;
        goto oakxB;
        etfp6:
        return null;
        goto V25Vc;
        PcL2D:
        if (!($wtX09->year > 2026 or $wtX09->year === 2026 and $wtX09->month >= 3)) {
            goto NETha;
        }
        goto oLwbH;
        Ld0EA:
        $wrACm = now();
        goto Got9k;
        SwDfm:
        return null;
        goto mgAi_;
        Rgv0a:
        $lHJlc = $wrACm->month;
        goto YMH6K;
        oakxB:
    }
}
