<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\Ey23NHBM8rqSI;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Exception\B2PcuiERDfNqQ;
trait DbEmnet2FoHTm
{
    private $eD3Hc = [];
    public function mt6YUzzNxIA($S1dGW)
    {
        goto ldEDf;
        ldEDf:
        if ($this instanceof Model) {
            goto uZGcQ;
        }
        goto aByL0;
        NglQu:
        goto LSPma;
        goto BEKAI;
        BEKAI:
        uZGcQ:
        goto c4Zdh;
        onTPK:
        LSPma:
        goto O_wKe;
        aByL0:
        $this->status = $S1dGW;
        goto NglQu;
        c4Zdh:
        $this->setAttribute('status', $S1dGW);
        goto onTPK;
        O_wKe:
    }
    public function mP8O9noVOj4()
    {
        goto VG0aQ;
        VG0aQ:
        if (!$this instanceof Model) {
            goto S56hA;
        }
        goto GWLk3;
        GWLk3:
        return $this->getAttribute('status');
        goto cXG3B;
        cXG3B:
        S56hA:
        goto Hw7z4;
        Hw7z4:
        return $this->status;
        goto YWdWZ;
        YWdWZ:
    }
    public function mSAdKjgXIhj($z14eN)
    {
        goto O88MO;
        at9sx:
        $eu9gA = $this->mP8O9noVOj4();
        goto Rmvnv;
        O88MO:
        if ($this->md87bJuqFS7($z14eN)) {
            goto vcNOb;
        }
        goto p36E9;
        pr8rx:
        goto xDV8c;
        goto T1lhW;
        ZA6Ml:
        $this->status = $z14eN;
        goto pr8rx;
        p36E9:
        throw B2PcuiERDfNqQ::mzYTkkfqyCU($this->id ?? 'unknown', $this->mP8O9noVOj4(), $z14eN);
        goto wSt1P;
        rSRrv:
        foreach ($this->eD3Hc as $xzT6U) {
            $xzT6U->myNnxL9T85B($eu9gA, $z14eN);
            dxA3I:
        }
        goto UO8q5;
        T1lhW:
        EeAqz:
        goto dBPYV;
        wSt1P:
        vcNOb:
        goto at9sx;
        UO8q5:
        O1OQo:
        goto JGFGT;
        Rmvnv:
        if ($this instanceof Model) {
            goto EeAqz;
        }
        goto ZA6Ml;
        J07Fj:
        xDV8c:
        goto rSRrv;
        dBPYV:
        $this->setAttribute('status', $z14eN);
        goto J07Fj;
        JGFGT:
    }
    public function md87bJuqFS7($z14eN)
    {
        goto nm8xs;
        zHbU9:
        vijPh:
        goto JfC5S;
        hJlCz:
        hhOls:
        goto zHbU9;
        nm8xs:
        switch ($this->status) {
            case O8RzIjGmSN6fG::UPLOADING:
                return O8RzIjGmSN6fG::UPLOADED == $z14eN || O8RzIjGmSN6fG::UPLOADING == $z14eN || O8RzIjGmSN6fG::ABORTED == $z14eN;
            case O8RzIjGmSN6fG::UPLOADED:
                return O8RzIjGmSN6fG::PROCESSING == $z14eN || O8RzIjGmSN6fG::DELETED == $z14eN;
            case O8RzIjGmSN6fG::PROCESSING:
                return in_array($z14eN, [O8RzIjGmSN6fG::WATERMARK_PROCESSED, O8RzIjGmSN6fG::THUMBNAIL_PROCESSED, O8RzIjGmSN6fG::ENCODING_PROCESSED, O8RzIjGmSN6fG::ENCODING_ERROR, O8RzIjGmSN6fG::BLUR_PROCESSED, O8RzIjGmSN6fG::DELETED, O8RzIjGmSN6fG::FINISHED, O8RzIjGmSN6fG::PROCESSING]);
            case O8RzIjGmSN6fG::FINISHED:
            case O8RzIjGmSN6fG::ABORTED:
                return O8RzIjGmSN6fG::DELETED == $z14eN;
            case O8RzIjGmSN6fG::ENCODING_PROCESSED:
                return O8RzIjGmSN6fG::FINISHED == $z14eN || O8RzIjGmSN6fG::DELETED == $z14eN;
            default:
                return false;
        }
        goto hJlCz;
        JfC5S:
    }
    public function mW7YosDFYf5(Ey23NHBM8rqSI $xzT6U)
    {
        $this->eD3Hc[] = $xzT6U;
    }
}
