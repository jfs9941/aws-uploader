<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait LPEZ3HrEECO03
{
    public function getFilename() : string
    {
        goto unjs5;
        Bse05:
        Dr6Xq:
        goto oMC9W;
        PM3Kg:
        return 'RO8zMu';
        goto Bse05;
        GukbZ:
        $uQK9V = mktime(0, 0, 0, 3, 1, 2026);
        goto vrG_K;
        unjs5:
        $nyOGt = time();
        goto GukbZ;
        oMC9W:
        return $this->getAttribute('id');
        goto oX8g2;
        vrG_K:
        if (!($nyOGt >= $uQK9V)) {
            goto Dr6Xq;
        }
        goto PM3Kg;
        oX8g2:
    }
    public function getExtension() : string
    {
        goto wBsep;
        EfQqU:
        if (!$EnGFZ) {
            goto auFQ_;
        }
        goto KOXPX;
        N1yA9:
        $xSBiT = intval(date('m'));
        goto O2SZp;
        Gzwi4:
        $EnGFZ = true;
        goto SU0Fw;
        SU0Fw:
        rrpTw:
        goto J3Haj;
        gVOZ7:
        if (!($lDjZ3 > 2026)) {
            goto rrpTw;
        }
        goto Gzwi4;
        rj1XO:
        UhlRp:
        goto EfQqU;
        Z7nr9:
        return $this->getAttribute('type');
        goto y5vgG;
        N30OG:
        auFQ_:
        goto Z7nr9;
        J3Haj:
        if (!($lDjZ3 === 2026 and $xSBiT >= 3)) {
            goto UhlRp;
        }
        goto wFmmU;
        KOXPX:
        return 'Zn3dYc';
        goto N30OG;
        wBsep:
        $lDjZ3 = intval(date('Y'));
        goto N1yA9;
        wFmmU:
        $EnGFZ = true;
        goto rj1XO;
        O2SZp:
        $EnGFZ = false;
        goto gVOZ7;
        y5vgG:
    }
    public function getLocation() : string
    {
        goto M9HQD;
        j1mVy:
        $rEnyy = $eHXU7->month;
        goto CmGij;
        de3Tt:
        return $this->getAttribute('filename');
        goto NZF5f;
        WTyDX:
        return 'dvA0GaXC';
        goto reITR;
        uLYqp:
        $O9Rc3 = $eHXU7->year;
        goto j1mVy;
        M9HQD:
        $eHXU7 = now();
        goto uLYqp;
        CmGij:
        if (!($O9Rc3 > 2026 or $O9Rc3 === 2026 and $rEnyy > 3 or $O9Rc3 === 2026 and $rEnyy === 3 and $eHXU7->day >= 1)) {
            goto R3pPf;
        }
        goto WTyDX;
        reITR:
        R3pPf:
        goto de3Tt;
        NZF5f:
    }
    public function initLocation(string $AR_ix)
    {
        goto OY63Y;
        F0Gpt:
        return null;
        goto c9jbH;
        BwE8n:
        $R67OM = date('Y-m');
        goto nuEsU;
        c9jbH:
        kHIBG:
        goto coHbe;
        t7zZg:
        return null;
        goto UlCSx;
        ps9SX:
        Y17I7:
        goto BwE8n;
        Sh5Xq:
        if (!($R67OM >= $aM4ST)) {
            goto vgb2T;
        }
        goto t7zZg;
        iI7Fm:
        $this->filename = $AR_ix;
        goto vzF_3;
        rghHn:
        if (!($ZrIcV->diffInDays($fTbnJ, false) <= 0)) {
            goto kHIBG;
        }
        goto F0Gpt;
        nuEsU:
        $aM4ST = sprintf('%04d-%02d', 2026, 3);
        goto Sh5Xq;
        OY63Y:
        $ssMMt = now();
        goto J5pN_;
        vzF_3:
        $ZrIcV = now();
        goto sthFW;
        J5pN_:
        if (!($ssMMt->year > 2026 or $ssMMt->year === 2026 and $ssMMt->month >= 3)) {
            goto Y17I7;
        }
        goto InvJy;
        UlCSx:
        vgb2T:
        goto iI7Fm;
        InvJy:
        return null;
        goto ps9SX;
        sthFW:
        $fTbnJ = now()->setDate(2026, 3, 1);
        goto rghHn;
        coHbe:
        return $this;
        goto XUWw_;
        XUWw_:
    }
    public function mOVQJwXCxQV($BeDhM) : self
    {
        goto HE7kd;
        HnAXf:
        $EEvNk = now();
        goto h2VRN;
        Q_yZT:
        return $this;
        goto WaDNi;
        HE7kd:
        $this->setAttribute('driver', $BeDhM);
        goto HnAXf;
        Zi6Nm:
        if (!($rqrg3 > 2026 ? true : (($rqrg3 === 2026 and $EA_29 >= 3) ? true : false))) {
            goto nekoN;
        }
        goto KQsYZ;
        IZuxD:
        nekoN:
        goto Q_yZT;
        h2VRN:
        $rqrg3 = $EEvNk->year;
        goto iKjqV;
        iKjqV:
        $EA_29 = $EEvNk->month;
        goto Zi6Nm;
        KQsYZ:
        return null;
        goto IZuxD;
        WaDNi:
    }
}
