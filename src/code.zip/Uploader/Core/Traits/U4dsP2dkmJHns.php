<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\PdBd5D8IKDopT;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Exception\BI7zT0hnXVI9h;
trait U4dsP2dkmJHns
{
    private $nvcam = [];
    public function m25UhhF4K3y($Poap0)
    {
        goto OSM1a;
        NDyBy:
        qYR4n:
        goto vjFAI;
        UOZQp:
        SGuur:
        goto VXFCU;
        sQKp5:
        $this->status = $Poap0;
        goto soK7O;
        soK7O:
        goto SGuur;
        goto NDyBy;
        OSM1a:
        if ($this instanceof Model) {
            goto qYR4n;
        }
        goto sQKp5;
        vjFAI:
        $this->setAttribute('status', $Poap0);
        goto UOZQp;
        VXFCU:
    }
    public function mF5qdlYQreN()
    {
        goto RYoF9;
        MD4nf:
        return $this->status;
        goto s0DCh;
        FBRUt:
        mjNA8:
        goto MD4nf;
        BUoX1:
        return $this->getAttribute('status');
        goto FBRUt;
        RYoF9:
        if (!$this instanceof Model) {
            goto mjNA8;
        }
        goto BUoX1;
        s0DCh:
    }
    public function mZecThKyfk1($GPUcb)
    {
        goto m1iRH;
        T56lw:
        ejzVq:
        goto Avz3x;
        y1bso:
        DGJ3P:
        goto hjHIW;
        Ive6t:
        throw BI7zT0hnXVI9h::msl2PQsd6Fw($this->id ?? 'unknown', $this->mF5qdlYQreN(), $GPUcb);
        goto T56lw;
        To6jf:
        if ($this instanceof Model) {
            goto GQeUt;
        }
        goto YteVe;
        YteVe:
        $this->status = $GPUcb;
        goto QMVfW;
        QMVfW:
        goto r4Q7A;
        goto wJbVC;
        Pkxme:
        r4Q7A:
        goto bxqkv;
        m1iRH:
        if ($this->mtVowMhmF1t($GPUcb)) {
            goto ejzVq;
        }
        goto Ive6t;
        bxqkv:
        foreach ($this->nvcam as $EqAuO) {
            $EqAuO->mht82bQ4KnY($fHwus, $GPUcb);
            ApET8:
        }
        goto y1bso;
        wJbVC:
        GQeUt:
        goto AeA6e;
        AeA6e:
        $this->setAttribute('status', $GPUcb);
        goto Pkxme;
        Avz3x:
        $fHwus = $this->mF5qdlYQreN();
        goto To6jf;
        hjHIW:
    }
    public function mtVowMhmF1t($GPUcb)
    {
        goto iwheu;
        Cjlgx:
        wSy4i:
        goto G97ry;
        iwheu:
        switch ($this->status) {
            case SwAwanZG36Yx6::UPLOADING:
                return SwAwanZG36Yx6::UPLOADED == $GPUcb || SwAwanZG36Yx6::UPLOADING == $GPUcb || SwAwanZG36Yx6::ABORTED == $GPUcb;
            case SwAwanZG36Yx6::UPLOADED:
                return SwAwanZG36Yx6::PROCESSING == $GPUcb || SwAwanZG36Yx6::DELETED == $GPUcb;
            case SwAwanZG36Yx6::PROCESSING:
                return in_array($GPUcb, [SwAwanZG36Yx6::WATERMARK_PROCESSED, SwAwanZG36Yx6::THUMBNAIL_PROCESSED, SwAwanZG36Yx6::ENCODING_PROCESSED, SwAwanZG36Yx6::ENCODING_ERROR, SwAwanZG36Yx6::BLUR_PROCESSED, SwAwanZG36Yx6::DELETED, SwAwanZG36Yx6::FINISHED, SwAwanZG36Yx6::PROCESSING]);
            case SwAwanZG36Yx6::FINISHED:
            case SwAwanZG36Yx6::ABORTED:
                return SwAwanZG36Yx6::DELETED == $GPUcb;
            case SwAwanZG36Yx6::ENCODING_PROCESSED:
                return SwAwanZG36Yx6::FINISHED == $GPUcb || SwAwanZG36Yx6::DELETED == $GPUcb;
            default:
                return false;
        }
        goto Cjlgx;
        G97ry:
        u7ibE:
        goto QLvnI;
        QLvnI:
    }
    public function mUpiDytTDuT(PdBd5D8IKDopT $EqAuO)
    {
        $this->nvcam[] = $EqAuO;
    }
}
