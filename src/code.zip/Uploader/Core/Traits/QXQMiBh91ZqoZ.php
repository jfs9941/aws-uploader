<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\E4a2957rpFTRJ;
use Jfs\Uploader\Core\T1237kNnrvH7d;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
trait QXQMiBh91ZqoZ
{
    private $i_qo1;
    private $l1187;
    private $jB78g;
    public function mwi5nmRyoKE() : string
    {
        return E4a2957rpFTRJ::mLe05NfPcmU($this->i_qo1->getFilename());
    }
    public function m20XUNl7Aaq() : E4a2957rpFTRJ
    {
        goto tIaL0;
        ImPiu:
        return $this->l1187;
        goto Un5AS;
        r9giI:
        Ni1Yw:
        goto wnLtb;
        Mv9uv:
        return $this->l1187;
        goto r9giI;
        tIaL0:
        if (!(null !== $this->l1187)) {
            goto Ni1Yw;
        }
        goto Mv9uv;
        wnLtb:
        $this->mFldCR5vjk9();
        goto ImPiu;
        Un5AS:
    }
    private function mFldCR5vjk9() : T1237kNnrvH7d
    {
        goto HHEMc;
        bl2zZ:
        $u691d = json_decode($vB3t1, true);
        goto AIvZm;
        AIvZm:
        $this->l1187 = E4a2957rpFTRJ::mz7ml4OjEUT($u691d);
        goto jCOhx;
        WZutB:
        throw new B9AWimnd5WRl4("File {$this->i_qo1->getFilename()} is not PreSigned upload");
        goto O_5kM;
        jCOhx:
        return $this;
        goto zFsqX;
        zFsqX:
        VrvuG:
        goto WZutB;
        HHEMc:
        $vB3t1 = $this->jB78g->get($this->mwi5nmRyoKE());
        goto UQKIe;
        UQKIe:
        if (!$vB3t1) {
            goto VrvuG;
        }
        goto bl2zZ;
        O_5kM:
    }
    public function mijOp1YUOWt($WZrdP, $lscSG, $rMOii, $hWt8D, $CYLV9, $uV7lV = 's3') : void
    {
        $this->l1187 = E4a2957rpFTRJ::m7WlBwjk1wo($this->i_qo1, $WZrdP, $lscSG, $CYLV9, $rMOii, $hWt8D, $uV7lV);
    }
}
