<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\Hx13AKbJdXa2m;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Exception\CWn6V46ojDVJy;
trait T98qFVxByjzPT
{
    private $l12a2 = [];
    public function mn9R5wxLm2K($KMCCs)
    {
        goto ci8sA;
        ci8sA:
        if ($this instanceof Model) {
            goto WWQwp;
        }
        goto jyfoX;
        JlbZH:
        goto gVf2_;
        goto HmMMH;
        Upig0:
        gVf2_:
        goto EI_X5;
        HmMMH:
        WWQwp:
        goto zAaHT;
        jyfoX:
        $this->status = $KMCCs;
        goto JlbZH;
        zAaHT:
        $this->setAttribute('status', $KMCCs);
        goto Upig0;
        EI_X5:
    }
    public function mEu3Vs3SlRo()
    {
        goto LFw9n;
        LFw9n:
        if (!$this instanceof Model) {
            goto Rw8br;
        }
        goto WrNfD;
        WrNfD:
        return $this->getAttribute('status');
        goto vpCrG;
        I_x1U:
        return $this->status;
        goto V4cEq;
        vpCrG:
        Rw8br:
        goto I_x1U;
        V4cEq:
    }
    public function mhK1eUHzFBK($VszfX)
    {
        goto sUuzY;
        txjt5:
        goto ohpYa;
        goto Dw83a;
        Nbyo9:
        nlsrz:
        goto i32Dd;
        Dw83a:
        ZgpKB:
        goto glYzW;
        ThCO1:
        foreach ($this->l12a2 as $As8uo) {
            $As8uo->mw0DVFYNlsC($B3dKG, $VszfX);
            QP2hD:
        }
        goto Nbyo9;
        YbazP:
        $this->status = $VszfX;
        goto txjt5;
        TRwpg:
        ohpYa:
        goto ThCO1;
        sUuzY:
        if ($this->m8kjqHcwUSC($VszfX)) {
            goto kzSC2;
        }
        goto EhG47;
        lMEdO:
        $B3dKG = $this->mEu3Vs3SlRo();
        goto K6FfY;
        R46u0:
        kzSC2:
        goto lMEdO;
        glYzW:
        $this->setAttribute('status', $VszfX);
        goto TRwpg;
        K6FfY:
        if ($this instanceof Model) {
            goto ZgpKB;
        }
        goto YbazP;
        EhG47:
        throw CWn6V46ojDVJy::mgVNMqBzmQt($this->id ?? 'unknown', $this->mEu3Vs3SlRo(), $VszfX);
        goto R46u0;
        i32Dd:
    }
    public function m8kjqHcwUSC($VszfX)
    {
        goto f5Y3Q;
        IMWhc:
        TRYDS:
        goto x5u7o;
        x5u7o:
        q7i0A:
        goto ABlS4;
        f5Y3Q:
        switch ($this->status) {
            case Q5pXt73hTeTVP::UPLOADING:
                return Q5pXt73hTeTVP::UPLOADED == $VszfX || Q5pXt73hTeTVP::UPLOADING == $VszfX || Q5pXt73hTeTVP::ABORTED == $VszfX;
            case Q5pXt73hTeTVP::UPLOADED:
                return Q5pXt73hTeTVP::PROCESSING == $VszfX || Q5pXt73hTeTVP::DELETED == $VszfX;
            case Q5pXt73hTeTVP::PROCESSING:
                return in_array($VszfX, [Q5pXt73hTeTVP::WATERMARK_PROCESSED, Q5pXt73hTeTVP::THUMBNAIL_PROCESSED, Q5pXt73hTeTVP::ENCODING_PROCESSED, Q5pXt73hTeTVP::ENCODING_ERROR, Q5pXt73hTeTVP::BLUR_PROCESSED, Q5pXt73hTeTVP::DELETED, Q5pXt73hTeTVP::FINISHED]);
            case Q5pXt73hTeTVP::FINISHED:
            case Q5pXt73hTeTVP::ABORTED:
                return Q5pXt73hTeTVP::DELETED == $VszfX;
            case Q5pXt73hTeTVP::ENCODING_PROCESSED:
                return Q5pXt73hTeTVP::FINISHED == $VszfX || Q5pXt73hTeTVP::DELETED == $VszfX;
            default:
                return false;
        }
        goto IMWhc;
        ABlS4:
    }
    public function mMajp12kCYR(Hx13AKbJdXa2m $As8uo)
    {
        $this->l12a2[] = $As8uo;
    }
}
