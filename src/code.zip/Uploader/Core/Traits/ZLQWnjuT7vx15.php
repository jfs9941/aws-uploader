<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\CPWst5X7YKGnu;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Exception\LiA5BOk62pit2;
trait ZLQWnjuT7vx15
{
    private $D1JGi = [];
    public function mfeKnFzyMNC($MUSXC)
    {
        goto xQ4Mb;
        xDsZA:
        CUzU1:
        goto sY8lS;
        jdxt3:
        QZ067:
        goto Im8vZ;
        sY8lS:
        $this->setAttribute('status', $MUSXC);
        goto jdxt3;
        SL4S1:
        $this->status = $MUSXC;
        goto WTa2P;
        WTa2P:
        goto QZ067;
        goto xDsZA;
        xQ4Mb:
        if ($this instanceof Model) {
            goto CUzU1;
        }
        goto SL4S1;
        Im8vZ:
    }
    public function mFO6EVg3QJi()
    {
        goto mAoXA;
        ZRDPt:
        Pa4Vj:
        goto HBT2P;
        HBT2P:
        return $this->status;
        goto O9J3C;
        EUiBy:
        return $this->getAttribute('status');
        goto ZRDPt;
        mAoXA:
        if (!$this instanceof Model) {
            goto Pa4Vj;
        }
        goto EUiBy;
        O9J3C:
    }
    public function m3irf1LtLKT($kncXe)
    {
        goto VPuZ3;
        ynl0G:
        c5DCQ:
        goto Q25m0;
        uQXfz:
        $this->status = $kncXe;
        goto HirEF;
        Szkt3:
        haf3u:
        goto KdHjb;
        VPuZ3:
        if ($this->mvgtahNetNS($kncXe)) {
            goto SYsNQ;
        }
        goto oscPy;
        Q25m0:
        $this->setAttribute('status', $kncXe);
        goto Szkt3;
        kNIL8:
        gcEYh:
        goto psOme;
        OO4J0:
        SYsNQ:
        goto wZ73Z;
        oscPy:
        throw LiA5BOk62pit2::mSG8vVYWOEV($this->id ?? 'unknown', $this->mFO6EVg3QJi(), $kncXe);
        goto OO4J0;
        AJYT1:
        if ($this instanceof Model) {
            goto c5DCQ;
        }
        goto uQXfz;
        HirEF:
        goto haf3u;
        goto ynl0G;
        wZ73Z:
        $B3oaq = $this->mFO6EVg3QJi();
        goto AJYT1;
        KdHjb:
        foreach ($this->D1JGi as $t9LAe) {
            $t9LAe->mLulwBaR29t($B3oaq, $kncXe);
            fkEWM:
        }
        goto kNIL8;
        psOme:
    }
    public function mvgtahNetNS($kncXe)
    {
        goto WXyDm;
        MBrLj:
        cKCUT:
        goto pCMLe;
        F7yBe:
        AI0Fw:
        goto MBrLj;
        WXyDm:
        switch ($this->status) {
            case OLX71luAn6XnP::UPLOADING:
                return OLX71luAn6XnP::UPLOADED == $kncXe || OLX71luAn6XnP::UPLOADING == $kncXe || OLX71luAn6XnP::ABORTED == $kncXe;
            case OLX71luAn6XnP::UPLOADED:
                return OLX71luAn6XnP::PROCESSING == $kncXe || OLX71luAn6XnP::DELETED == $kncXe;
            case OLX71luAn6XnP::PROCESSING:
                return in_array($kncXe, [OLX71luAn6XnP::WATERMARK_PROCESSED, OLX71luAn6XnP::THUMBNAIL_PROCESSED, OLX71luAn6XnP::ENCODING_PROCESSED, OLX71luAn6XnP::ENCODING_ERROR, OLX71luAn6XnP::BLUR_PROCESSED, OLX71luAn6XnP::DELETED, OLX71luAn6XnP::FINISHED]);
            case OLX71luAn6XnP::FINISHED:
            case OLX71luAn6XnP::ABORTED:
                return OLX71luAn6XnP::DELETED == $kncXe;
            case OLX71luAn6XnP::ENCODING_PROCESSED:
                return OLX71luAn6XnP::FINISHED == $kncXe || OLX71luAn6XnP::DELETED == $kncXe;
            default:
                return false;
        }
        goto F7yBe;
        pCMLe:
    }
    public function m0Ku2PvnNzM(CPWst5X7YKGnu $t9LAe)
    {
        $this->D1JGi[] = $t9LAe;
    }
}
