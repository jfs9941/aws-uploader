<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\YOSIkvkyMSIKR;
use Jfs\Uploader\Core\El1EbMj6pC2Ez;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
trait R4vSt4d64nOim
{
    private $wM7km;
    private $srKmY;
    private $j618T;
    public function mrwx9qum9K0() : string
    {
        return YOSIkvkyMSIKR::mFUIt4zd7G3($this->wM7km->getFilename());
    }
    public function mFBfBagZ9x6() : YOSIkvkyMSIKR
    {
        goto YQD8C;
        UmsoI:
        return $this->srKmY;
        goto h0bAH;
        bkyPH:
        PmUol:
        goto X5lMt;
        X5lMt:
        $this->macR3kJthJ6();
        goto UmsoI;
        YQD8C:
        if (!(null !== $this->srKmY)) {
            goto PmUol;
        }
        goto uAeeT;
        uAeeT:
        return $this->srKmY;
        goto bkyPH;
        h0bAH:
    }
    private function macR3kJthJ6() : El1EbMj6pC2Ez
    {
        goto ro5zL;
        Tj3Dh:
        if (!$ZMPNd) {
            goto oA76G;
        }
        goto r2f6C;
        dT8Zl:
        $this->srKmY = YOSIkvkyMSIKR::mxrh077UXy5($C7FpH);
        goto cMfaa;
        vDOmn:
        throw new LvyLnQ2Iyddt1("File {$this->wM7km->getFilename()} is not PreSigned upload");
        goto YB7C1;
        YmhvX:
        oA76G:
        goto vDOmn;
        r2f6C:
        $C7FpH = json_decode($ZMPNd, true);
        goto dT8Zl;
        ro5zL:
        $ZMPNd = $this->j618T->get($this->mrwx9qum9K0());
        goto Tj3Dh;
        cMfaa:
        return $this;
        goto YmhvX;
        YB7C1:
    }
    public function mYZDh1mMlqv($xMo__, $BJVUo, $pu7IV, $Da8dG, $V3Z4M, $n8L3v = 's3') : void
    {
        $this->srKmY = YOSIkvkyMSIKR::m3u5o2y4v0H($this->wM7km, $xMo__, $BJVUo, $V3Z4M, $pu7IV, $Da8dG, $n8L3v);
    }
}
