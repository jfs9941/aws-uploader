<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Traits;

use backup\Uploader\Core\AxmsWfJr0hDcu;
use backup\Uploader\Core\Pb0Dvv7XIOUP3;
use backup\Uploader\Exception\Asi2ubH37e0l9;
trait Bjzrau20Tp0as
{
    private $i31Dp;
    private $hn8lj;
    private $RHF8i;
    public function mE8PPexbKCM() : string
    {
        return AxmsWfJr0hDcu::m2gHLHqC92C($this->i31Dp->getFilename());
    }
    public function m77UJKssxZ5() : AxmsWfJr0hDcu
    {
        goto eTydx;
        f9knP:
        xJ0AK:
        goto KOwEz;
        SPOBc:
        return $this->hn8lj;
        goto FJ3v7;
        eTydx:
        if (!(null !== $this->hn8lj)) {
            goto xJ0AK;
        }
        goto ciQqD;
        ciQqD:
        return $this->hn8lj;
        goto f9knP;
        KOwEz:
        $this->mZuxAX7tvkm();
        goto SPOBc;
        FJ3v7:
    }
    private function mZuxAX7tvkm() : Pb0Dvv7XIOUP3
    {
        goto uGYOc;
        uGYOc:
        $KAN7P = $this->RHF8i->get($this->mE8PPexbKCM());
        goto Kh4xJ;
        NZeZZ:
        EmBa6:
        goto l5Lfn;
        l5Lfn:
        throw new Asi2ubH37e0l9("File {$this->i31Dp->getFilename()} is not PreSigned upload");
        goto xdPaW;
        hkaN6:
        $yBQK1 = json_decode($KAN7P, true);
        goto dlFrT;
        W6UyR:
        return $this;
        goto NZeZZ;
        dlFrT:
        $this->hn8lj = AxmsWfJr0hDcu::m7S9iMmuKkR($yBQK1);
        goto W6UyR;
        Kh4xJ:
        if (!$KAN7P) {
            goto EmBa6;
        }
        goto hkaN6;
        xdPaW:
    }
    public function m3gXtxRraDA($alBn4, $End7P, $ktvvF, $znDRw, $tVw6M, $agJ1D = 's3') : void
    {
        $this->hn8lj = AxmsWfJr0hDcu::mrfJKkeE3Fp($this->i31Dp, $alBn4, $End7P, $tVw6M, $ktvvF, $znDRw, $agJ1D);
    }
}
