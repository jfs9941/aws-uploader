<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait X3bf55NIDrAka
{
    private function mPm6LMmslbM(string $R5z2N) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $R5z2N]));
    }
}
