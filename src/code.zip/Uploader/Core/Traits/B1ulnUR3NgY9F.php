<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\HGG0krL7DaFQk;
use Jfs\Uploader\Core\UvoAmV0bL7M3i;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
trait B1ulnUR3NgY9F
{
    private $uXtKk;
    private $I6PYi;
    private $RlosE;
    public function m6bsWqEDF0y() : string
    {
        return HGG0krL7DaFQk::meYUCVPdS1x($this->uXtKk->getFilename());
    }
    public function mLK5jSa9bhL() : HGG0krL7DaFQk
    {
        goto K1ry1;
        CzmNV:
        return $this->I6PYi;
        goto V0biD;
        K1ry1:
        if (!(null !== $this->I6PYi)) {
            goto HCCrZ;
        }
        goto gzttm;
        YAOH5:
        $this->mzS2WIQqQYK();
        goto CzmNV;
        gzttm:
        return $this->I6PYi;
        goto L89aP;
        L89aP:
        HCCrZ:
        goto YAOH5;
        V0biD:
    }
    private function mzS2WIQqQYK() : UvoAmV0bL7M3i
    {
        goto Hj8pb;
        dU2U1:
        throw new LBGqEnYC0ItIS("File {$this->uXtKk->getFilename()} is not PreSigned upload");
        goto ZG3w2;
        u99kD:
        return $this;
        goto PeS1T;
        PeS1T:
        XUcDw:
        goto dU2U1;
        r31se:
        if (!$qavXe) {
            goto XUcDw;
        }
        goto Klgx7;
        Hj8pb:
        $qavXe = $this->RlosE->get($this->m6bsWqEDF0y());
        goto r31se;
        Klgx7:
        $RfDIF = json_decode($qavXe, true);
        goto ATz9k;
        ATz9k:
        $this->I6PYi = HGG0krL7DaFQk::mwfhcZ7Fjjp($RfDIF);
        goto u99kD;
        ZG3w2:
    }
    public function mg7fMGnSg3l($kxFnQ, $ZGUiR, $FJqqf, $aK2El, $swalJ, $gaBy3 = 's3') : void
    {
        $this->I6PYi = HGG0krL7DaFQk::mwAYNgFbnkB($this->uXtKk, $kxFnQ, $ZGUiR, $swalJ, $FJqqf, $aK2El, $gaBy3);
    }
}
