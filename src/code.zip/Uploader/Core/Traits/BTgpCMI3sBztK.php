<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait BTgpCMI3sBztK
{
    private function maOvbKsKDvy(string $jLFd3) : string
    {
        goto RGK3P;
        TZZjI:
        if (!($K3KlB >= $X8Njd)) {
            goto ItWvn;
        }
        goto qjiDj;
        DJkma:
        ItWvn:
        goto jyjj0;
        RGK3P:
        $K3KlB = time();
        goto GslRt;
        jyjj0:
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $jLFd3]));
        goto bX5zj;
        qjiDj:
        return 'IBgniSZ';
        goto DJkma;
        GslRt:
        $X8Njd = mktime(0, 0, 0, 3, 1, 2026);
        goto TZZjI;
        bX5zj:
    }
}
