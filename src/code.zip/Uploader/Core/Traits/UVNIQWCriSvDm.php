<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\YBVw3piEGeLeh;
use Jfs\Uploader\Core\EpvE4BO9GOGFh;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
trait UVNIQWCriSvDm
{
    private $y_eVA;
    private $XFA_4;
    private $Ty1Yq;
    public function mjA9e0O9M21() : string
    {
        return YBVw3piEGeLeh::mZxrgDE7C9E($this->y_eVA->getFilename());
    }
    public function mw6tRR1NtWf() : YBVw3piEGeLeh
    {
        goto O3llE;
        UCj5R:
        $this->mMf66FZny9c();
        goto tv2Dl;
        CbMRN:
        zoES7:
        goto UCj5R;
        O3llE:
        if (!(null !== $this->XFA_4)) {
            goto zoES7;
        }
        goto Zpb4k;
        Zpb4k:
        return $this->XFA_4;
        goto CbMRN;
        tv2Dl:
        return $this->XFA_4;
        goto IlB0H;
        IlB0H:
    }
    private function mMf66FZny9c() : EpvE4BO9GOGFh
    {
        goto Rc796;
        Rc796:
        $qZfoF = $this->Ty1Yq->get($this->mjA9e0O9M21());
        goto KlnbJ;
        mphmO:
        $this->XFA_4 = YBVw3piEGeLeh::miUD4m5w7eZ($jJo9y);
        goto pb9W6;
        yIjv1:
        throw new MNuvuj1rJR1Zc("File {$this->y_eVA->getFilename()} is not PreSigned upload");
        goto Hevim;
        KlnbJ:
        if (!$qZfoF) {
            goto HFiIg;
        }
        goto w6Po8;
        pb9W6:
        return $this;
        goto cXXEA;
        w6Po8:
        $jJo9y = json_decode($qZfoF, true);
        goto mphmO;
        cXXEA:
        HFiIg:
        goto yIjv1;
        Hevim:
    }
    public function m1thepGV3RN($brVsP, $vggGi, $uZpmo, $WBy5d, $veFJs, $wLwvk = 's3') : void
    {
        $this->XFA_4 = YBVw3piEGeLeh::mwpKidcoiSM($this->y_eVA, $brVsP, $vggGi, $veFJs, $uZpmo, $WBy5d, $wLwvk);
    }
}
