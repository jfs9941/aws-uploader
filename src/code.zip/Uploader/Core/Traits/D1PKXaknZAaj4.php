<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\BC3GCfM107Y7V;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Exception\Vkv9DR78jqmXg;
trait D1PKXaknZAaj4
{
    private $VtVX9 = [];
    public function msLvxB5AWdO($EyXDL)
    {
        goto uiieP;
        uiieP:
        if ($this instanceof Model) {
            goto iKkIs;
        }
        goto SB3lM;
        x5siI:
        HqK03:
        goto pklSY;
        dy7Lk:
        goto HqK03;
        goto KGepE;
        KGepE:
        iKkIs:
        goto VZrO0;
        SB3lM:
        $this->status = $EyXDL;
        goto dy7Lk;
        VZrO0:
        $this->setAttribute('status', $EyXDL);
        goto x5siI;
        pklSY:
    }
    public function mrZyem1XtDy()
    {
        goto HzAmw;
        ItACG:
        return $this->status;
        goto hnqSW;
        pJhiZ:
        return $this->getAttribute('status');
        goto vUY9C;
        vUY9C:
        gQVC1:
        goto ItACG;
        HzAmw:
        if (!$this instanceof Model) {
            goto gQVC1;
        }
        goto pJhiZ;
        hnqSW:
    }
    public function mvUghb89hzW($EmXmH)
    {
        goto MLOG9;
        WstXC:
        Wonks:
        goto RHo_k;
        ryF7D:
        if ($this instanceof Model) {
            goto gjk5g;
        }
        goto lL2OO;
        tbQkE:
        foreach ($this->VtVX9 as $dIkfC) {
            $dIkfC->mUbEgwqXkQg($GNQ5V, $EmXmH);
            ddKk1:
        }
        goto QZ9CI;
        iLGnt:
        goto qAXh7;
        goto Og410;
        QZ9CI:
        UvYWz:
        goto K1wf3;
        E6SD2:
        throw Vkv9DR78jqmXg::mUQNKsaPCEa($this->id ?? 'unknown', $this->mrZyem1XtDy(), $EmXmH);
        goto WstXC;
        MLOG9:
        if ($this->mlP84cezeNz($EmXmH)) {
            goto Wonks;
        }
        goto E6SD2;
        Og410:
        gjk5g:
        goto ragcN;
        lL2OO:
        $this->status = $EmXmH;
        goto iLGnt;
        pYju2:
        qAXh7:
        goto tbQkE;
        RHo_k:
        $GNQ5V = $this->mrZyem1XtDy();
        goto ryF7D;
        ragcN:
        $this->setAttribute('status', $EmXmH);
        goto pYju2;
        K1wf3:
    }
    public function mlP84cezeNz($EmXmH)
    {
        goto bFve5;
        RHuw4:
        EiXtK:
        goto fNuNN;
        fNuNN:
        hwDhn:
        goto N0NzJ;
        bFve5:
        switch ($this->status) {
            case SsxWbUYXracun::UPLOADING:
                return SsxWbUYXracun::UPLOADED == $EmXmH || SsxWbUYXracun::UPLOADING == $EmXmH || SsxWbUYXracun::ABORTED == $EmXmH;
            case SsxWbUYXracun::UPLOADED:
                return SsxWbUYXracun::PROCESSING == $EmXmH || SsxWbUYXracun::DELETED == $EmXmH;
            case SsxWbUYXracun::PROCESSING:
                return in_array($EmXmH, [SsxWbUYXracun::WATERMARK_PROCESSED, SsxWbUYXracun::THUMBNAIL_PROCESSED, SsxWbUYXracun::ENCODING_PROCESSED, SsxWbUYXracun::ENCODING_ERROR, SsxWbUYXracun::BLUR_PROCESSED, SsxWbUYXracun::DELETED, SsxWbUYXracun::FINISHED, SsxWbUYXracun::PROCESSING]);
            case SsxWbUYXracun::FINISHED:
            case SsxWbUYXracun::ABORTED:
                return SsxWbUYXracun::DELETED == $EmXmH;
            case SsxWbUYXracun::ENCODING_PROCESSED:
                return SsxWbUYXracun::FINISHED == $EmXmH || SsxWbUYXracun::DELETED == $EmXmH;
            default:
                return false;
        }
        goto RHuw4;
        N0NzJ:
    }
    public function mFPrsEX7dNQ(BC3GCfM107Y7V $dIkfC)
    {
        $this->VtVX9[] = $dIkfC;
    }
}
