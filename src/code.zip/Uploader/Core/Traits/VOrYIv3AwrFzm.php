<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Cwggsm2UPkGtM;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Exception\KlKPTBnDHVeRD;
use Illuminate\Database\Eloquent\Model;
trait VOrYIv3AwrFzm
{
    private $aBUOy = [];
    public function m36TLWxcxjb($V4EmV)
    {
        goto SUWKL;
        lzaGL:
        goto cmzGH;
        goto W8_RO;
        DXG7E:
        $this->status = $V4EmV;
        goto lzaGL;
        MRPSH:
        cmzGH:
        goto HIlUW;
        SUWKL:
        if ($this instanceof Model) {
            goto lqR2Q;
        }
        goto DXG7E;
        W8_RO:
        lqR2Q:
        goto cMtDs;
        cMtDs:
        $this->setAttribute('status', $V4EmV);
        goto MRPSH;
        HIlUW:
    }
    public function mbFvG5lOLib()
    {
        goto k1_3U;
        cBYh_:
        return $this->getAttribute('status');
        goto Vg9G7;
        Vg9G7:
        UvqP8:
        goto USqDd;
        k1_3U:
        if (!$this instanceof Model) {
            goto UvqP8;
        }
        goto cBYh_;
        USqDd:
        return $this->status;
        goto RJJae;
        RJJae:
    }
    public function mG7ZLOSfPOQ($swvrA)
    {
        goto pyVsW;
        B4xAv:
        throw KlKPTBnDHVeRD::mgTTgQaK74E($this->id ?? 'unknown', $this->mbFvG5lOLib(), $swvrA);
        goto gy9Bs;
        kyaiR:
        $GcNEe = $this->mbFvG5lOLib();
        goto yqyep;
        fbfsR:
        $this->setAttribute('status', $swvrA);
        goto Rnv65;
        pyVsW:
        if ($this->mXaLkebEMhO($swvrA)) {
            goto rfx9c;
        }
        goto B4xAv;
        s4E5d:
        goto ddLYH;
        goto NmMbk;
        hgzkp:
        LGZpc:
        goto S8h8K;
        D4McG:
        $this->status = $swvrA;
        goto s4E5d;
        NmMbk:
        oM09q:
        goto fbfsR;
        gy9Bs:
        rfx9c:
        goto kyaiR;
        ERMYK:
        foreach ($this->aBUOy as $A6wqi) {
            $A6wqi->mFunvful2ao($GcNEe, $swvrA);
            pH9Zp:
        }
        goto hgzkp;
        Rnv65:
        ddLYH:
        goto ERMYK;
        yqyep:
        if ($this instanceof Model) {
            goto oM09q;
        }
        goto D4McG;
        S8h8K:
    }
    public function mXaLkebEMhO($swvrA)
    {
        goto GsaNv;
        GsaNv:
        switch ($this->status) {
            case MUu80sOhINyO3::UPLOADING:
                return MUu80sOhINyO3::UPLOADED == $swvrA || MUu80sOhINyO3::UPLOADING == $swvrA || MUu80sOhINyO3::ABORTED == $swvrA;
            case MUu80sOhINyO3::UPLOADED:
                return MUu80sOhINyO3::PROCESSING == $swvrA || MUu80sOhINyO3::DELETED == $swvrA;
            case MUu80sOhINyO3::PROCESSING:
                return in_array($swvrA, [MUu80sOhINyO3::WATERMARK_PROCESSED, MUu80sOhINyO3::THUMBNAIL_PROCESSED, MUu80sOhINyO3::ENCODING_PROCESSED, MUu80sOhINyO3::ENCODING_ERROR, MUu80sOhINyO3::BLUR_PROCESSED, MUu80sOhINyO3::DELETED, MUu80sOhINyO3::FINISHED, MUu80sOhINyO3::PROCESSING]);
            case MUu80sOhINyO3::FINISHED:
            case MUu80sOhINyO3::ABORTED:
                return MUu80sOhINyO3::DELETED == $swvrA;
            case MUu80sOhINyO3::ENCODING_PROCESSED:
                return MUu80sOhINyO3::FINISHED == $swvrA || MUu80sOhINyO3::DELETED == $swvrA;
            default:
                return false;
        }
        goto aHzpB;
        d_cJW:
        AZSVH:
        goto JrHlc;
        aHzpB:
        eoKu2:
        goto d_cJW;
        JrHlc:
    }
    public function mHWivXnN62Y(Cwggsm2UPkGtM $A6wqi)
    {
        $this->aBUOy[] = $A6wqi;
    }
}
