<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Traits; use Jfs\Uploader\Core\PYHXHzt0R1RXl; use Jfs\Uploader\Core\OiJXH3yNNoWI2; use Jfs\Uploader\Exception\Iq9YAonfF6F9J; trait ZmovKEdfhIy2z { private $IptUJ; private $zBYSK; private $tt_9k; public function mvwu93Mv7vD() : string { return PYHXHzt0R1RXl::mcYbbqR0mls($this->IptUJ->getFilename()); } public function mWSD1JDBapI() : PYHXHzt0R1RXl { goto hgVHU; X3529: QbJDG: goto UAnOm; I5MRN: return $this->zBYSK; goto X3529; hgVHU: if (!(null !== $this->zBYSK)) { goto QbJDG; } goto I5MRN; yA6eY: return $this->zBYSK; goto FlfRF; UAnOm: $this->mit0bxlFgA2(); goto yA6eY; FlfRF: } private function mit0bxlFgA2() : OiJXH3yNNoWI2 { goto qrQ_3; owFwM: $dI5FD = json_decode($y1IRp, true); goto q26Zn; zNjMK: if (!$y1IRp) { goto i_6ei; } goto owFwM; lV_JD: throw new Iq9YAonfF6F9J("File {$this->IptUJ->getFilename()} is not PreSigned upload"); goto RhM40; qrQ_3: $y1IRp = $this->tt_9k->get($this->mvwu93Mv7vD()); goto zNjMK; zntKl: i_6ei: goto lV_JD; fikG9: return $this; goto zntKl; q26Zn: $this->zBYSK = PYHXHzt0R1RXl::m6oYGuvr7GC($dI5FD); goto fikG9; RhM40: } public function mKiQfKba1qn($N72mj, $RcZQ3, $Rv5a0, $x6mWe, $NRT80, $VbqH4 = 's3') : void { $this->zBYSK = PYHXHzt0R1RXl::m4DndKC4YqC($this->IptUJ, $N72mj, $RcZQ3, $NRT80, $Rv5a0, $x6mWe, $VbqH4); } }
