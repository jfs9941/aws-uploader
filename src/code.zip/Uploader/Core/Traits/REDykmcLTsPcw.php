<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\C3XDkOI7yIIoE;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Exception\EJQS1ugI78hby;
use Illuminate\Database\Eloquent\Model;
trait REDykmcLTsPcw
{
    private $zH4MY = [];
    public function mJpZf64FjYj($QTUt4)
    {
        goto iKW8b;
        fY29m:
        vx3sG:
        goto GsIWo;
        GsIWo:
        $this->setAttribute('status', $QTUt4);
        goto Rpf_U;
        Rpf_U:
        v3L7p:
        goto TJ086;
        x7eiP:
        $this->status = $QTUt4;
        goto BeyXK;
        BeyXK:
        goto v3L7p;
        goto fY29m;
        iKW8b:
        if ($this instanceof Model) {
            goto vx3sG;
        }
        goto x7eiP;
        TJ086:
    }
    public function maSrsWE3jGR()
    {
        goto EcXwf;
        EcXwf:
        if (!$this instanceof Model) {
            goto J4Ayb;
        }
        goto Sv0WZ;
        Sv0WZ:
        return $this->getAttribute('status');
        goto fhDb9;
        fhDb9:
        J4Ayb:
        goto uEEWR;
        uEEWR:
        return $this->status;
        goto Bjh8W;
        Bjh8W:
    }
    public function ml2jBQKKXoS($dAE3r)
    {
        goto Wjc2e;
        PxWN4:
        $this->setAttribute('status', $dAE3r);
        goto wqV0r;
        YovUg:
        snuCg:
        goto PxWN4;
        BgLwq:
        throw EJQS1ugI78hby::mmqRrMrCey5($this->id ?? 'unknown', $this->maSrsWE3jGR(), $dAE3r);
        goto HtHS0;
        fn77r:
        foreach ($this->zH4MY as $zTDJr) {
            $zTDJr->mEE11OcGDDM($L8DCs, $dAE3r);
            saShW:
        }
        goto QdzFb;
        Wjc2e:
        if ($this->mVGpa3lMgLf($dAE3r)) {
            goto gA2Ul;
        }
        goto BgLwq;
        wqV0r:
        FEMmh:
        goto fn77r;
        ZgBtj:
        if ($this instanceof Model) {
            goto snuCg;
        }
        goto oYUtl;
        Xfg19:
        $L8DCs = $this->maSrsWE3jGR();
        goto ZgBtj;
        A4qld:
        goto FEMmh;
        goto YovUg;
        oYUtl:
        $this->status = $dAE3r;
        goto A4qld;
        HtHS0:
        gA2Ul:
        goto Xfg19;
        QdzFb:
        YkayO:
        goto VqwS9;
        VqwS9:
    }
    public function mVGpa3lMgLf($dAE3r)
    {
        goto elVLs;
        CFV5r:
        h39Ia:
        goto cGsa6;
        WEw6i:
        a13G7:
        goto CFV5r;
        elVLs:
        switch ($this->status) {
            case EHhCBxlsVyz9C::UPLOADING:
                return EHhCBxlsVyz9C::UPLOADED == $dAE3r || EHhCBxlsVyz9C::UPLOADING == $dAE3r || EHhCBxlsVyz9C::ABORTED == $dAE3r;
            case EHhCBxlsVyz9C::UPLOADED:
                return EHhCBxlsVyz9C::PROCESSING == $dAE3r || EHhCBxlsVyz9C::DELETED == $dAE3r;
            case EHhCBxlsVyz9C::PROCESSING:
                return in_array($dAE3r, [EHhCBxlsVyz9C::WATERMARK_PROCESSED, EHhCBxlsVyz9C::THUMBNAIL_PROCESSED, EHhCBxlsVyz9C::ENCODING_PROCESSED, EHhCBxlsVyz9C::ENCODING_ERROR, EHhCBxlsVyz9C::BLUR_PROCESSED, EHhCBxlsVyz9C::DELETED, EHhCBxlsVyz9C::FINISHED, EHhCBxlsVyz9C::PROCESSING]);
            case EHhCBxlsVyz9C::FINISHED:
            case EHhCBxlsVyz9C::ABORTED:
                return EHhCBxlsVyz9C::DELETED == $dAE3r;
            case EHhCBxlsVyz9C::ENCODING_PROCESSED:
                return EHhCBxlsVyz9C::FINISHED == $dAE3r || EHhCBxlsVyz9C::DELETED == $dAE3r;
            default:
                return false;
        }
        goto WEw6i;
        cGsa6:
    }
    public function m4opzeov9Jg(C3XDkOI7yIIoE $zTDJr)
    {
        $this->zH4MY[] = $zTDJr;
    }
}
