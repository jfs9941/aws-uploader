<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\StateChangeObserverInterface;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Exception\InvalidStateTransitionException;

/**
 * @property int $status
 */
trait StateMachineTrait
{
    /**
     * @var StateChangeObserverInterface[]
     */
    private $observers = [];

    /**
     * @param int $initialState
     */
    public function initializeState($initialState)
    {
        if ($this instanceof Model) {
            $this->setAttribute('status', $initialState);
        } else {
            $this->status = $initialState;
        }
    }

    /**
     * @return int
     */
    public function getStatus()
    {
        if ($this instanceof Model) {
            return $this->getAttribute('status');
        }
        return $this->status;
    }

    /**
     * @param int $newState
     *
     * @throws InvalidStateTransitionException
     */
    public function transitionTo($newState)
    {
        if (!$this->canTransitionTo($newState)) {
            throw InvalidStateTransitionException::fromInvalidState($this->id ?? 'unknown', $this->getStatus(), $newState);
        }

        $oldState = $this->getStatus();
        if ($this instanceof Model) {
            $this->setAttribute('status', $newState);
        } else {
            $this->status = $newState;
        }

        // Notify observers of state change
        foreach ($this->observers as $observer) {
            $observer->onStateChange($oldState, $newState);
        }
    }

    /**
     * @param int $newState
     *
     * @return bool
     */
    public function canTransitionTo($newState)
    {
        switch ($this->status) {
            case FileStatus::UPLOADING:
                return FileStatus::UPLOADED == $newState || FileStatus::UPLOADING == $newState || FileStatus::ABORTED == $newState;
            case FileStatus::UPLOADED:
                return FileStatus::PROCESSING == $newState || FileStatus::DELETED == $newState;
            case FileStatus::PROCESSING:
                return in_array($newState, [
                    FileStatus::WATERMARK_PROCESSED,
                    FileStatus::THUMBNAIL_PROCESSED,
                    FileStatus::ENCODING_PROCESSED,
                    FileStatus::ENCODING_ERROR,
                    FileStatus::BLUR_PROCESSED,
                    FileStatus::DELETED,
                    FileStatus::FINISHED,
                ]);
            case FileStatus::FINISHED:
            case FileStatus::ABORTED:
                return FileStatus::DELETED == $newState;
            case FileStatus::ENCODING_PROCESSED:
                return FileStatus::FINISHED == $newState || FileStatus::DELETED == $newState;
            default:
                return false;
        }
    }

    public function addObserver(StateChangeObserverInterface $observer)
    {
        $this->observers[] = $observer;
    }
}
