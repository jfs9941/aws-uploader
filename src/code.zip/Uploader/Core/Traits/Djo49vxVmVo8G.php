<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\OGqakwzIfzu7z;
use Jfs\Uploader\Core\S3bwZBI8SlQQZ;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
trait Djo49vxVmVo8G
{
    private $HyWI1;
    private $Xeo8T;
    private $VMzF2;
    public function mwo8AmZgP7W() : string
    {
        return OGqakwzIfzu7z::mhXMJL71B9N($this->HyWI1->getFilename());
    }
    public function mAorhKFxc5x() : OGqakwzIfzu7z
    {
        goto SONvZ;
        SONvZ:
        if (!(null !== $this->Xeo8T)) {
            goto sXECE;
        }
        goto fXUi3;
        w4bEm:
        return $this->Xeo8T;
        goto aZVCD;
        IS7GT:
        $this->mT9XiaPrP4w();
        goto w4bEm;
        pLOGi:
        sXECE:
        goto IS7GT;
        fXUi3:
        return $this->Xeo8T;
        goto pLOGi;
        aZVCD:
    }
    private function mT9XiaPrP4w() : S3bwZBI8SlQQZ
    {
        goto Lylc1;
        A3EQh:
        throw new EpflNcDLOJeck("File {$this->HyWI1->getFilename()} is not PreSigned upload");
        goto xvoYf;
        P78Dk:
        return $this;
        goto eQoy5;
        rZwTE:
        $M8L5K = json_decode($p1Tkn, true);
        goto Zi1Z0;
        hPjHs:
        if (!$p1Tkn) {
            goto ySeR6;
        }
        goto rZwTE;
        Lylc1:
        $p1Tkn = $this->VMzF2->get($this->mwo8AmZgP7W());
        goto hPjHs;
        eQoy5:
        ySeR6:
        goto A3EQh;
        Zi1Z0:
        $this->Xeo8T = OGqakwzIfzu7z::mPJ5IoDXkWy($M8L5K);
        goto P78Dk;
        xvoYf:
    }
    public function mynhW1oCAAA($TFxKe, $ubpQh, $Y2e5D, $WHPAZ, $EiW4T, $bWJ0p = 's3') : void
    {
        $this->Xeo8T = OGqakwzIfzu7z::mtnaT8I8SCb($this->HyWI1, $TFxKe, $ubpQh, $EiW4T, $Y2e5D, $WHPAZ, $bWJ0p);
    }
}
