<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\QUscYuYxMDsuz;
use Jfs\Uploader\Core\TVInkZGE2Z8Ja;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
trait MEICJHiBOK6si
{
    private $PV7YF;
    private $mn6px;
    private $k51oV;
    public function mQA9EIajGk2() : string
    {
        return QUscYuYxMDsuz::mmwRyL53HQ1($this->PV7YF->getFilename());
    }
    public function mlnKeX4eawe() : QUscYuYxMDsuz
    {
        goto ZhIgt;
        Zj3jv:
        yOYTr:
        goto QEe09;
        E7ohw:
        return $this->mn6px;
        goto Zj3jv;
        gaLLg:
        return $this->mn6px;
        goto SYY0r;
        QEe09:
        $this->mR4vJ1pOyZp();
        goto gaLLg;
        ZhIgt:
        if (!(null !== $this->mn6px)) {
            goto yOYTr;
        }
        goto E7ohw;
        SYY0r:
    }
    private function mR4vJ1pOyZp() : TVInkZGE2Z8Ja
    {
        goto Tm19B;
        Jucbp:
        throw new JQsXv6HTe1n89("File {$this->PV7YF->getFilename()} is not PreSigned upload");
        goto hz309;
        qeEss:
        $I_ax1 = json_decode($iaAFv, true);
        goto lPwr6;
        lPwr6:
        $this->mn6px = QUscYuYxMDsuz::mcOR9MnBlDQ($I_ax1);
        goto Ey4L_;
        zLEsC:
        HghDR:
        goto Jucbp;
        Tm19B:
        $iaAFv = $this->k51oV->get($this->mQA9EIajGk2());
        goto qnTpQ;
        Ey4L_:
        return $this;
        goto zLEsC;
        qnTpQ:
        if (!$iaAFv) {
            goto HghDR;
        }
        goto qeEss;
        hz309:
    }
    public function mx86PeUtHxR($rA1FC, $fQkDA, $DTo1w, $QS28K, $jVUTM, $PAfML = 's3') : void
    {
        $this->mn6px = QUscYuYxMDsuz::mc35KG5oSlP($this->PV7YF, $rA1FC, $fQkDA, $jVUTM, $DTo1w, $QS28K, $PAfML);
    }
}
