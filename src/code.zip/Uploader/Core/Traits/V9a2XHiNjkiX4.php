<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait V9a2XHiNjkiX4
{
    private function mnteLsoQJIg(string $nm3TE) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $nm3TE]));
    }
}
