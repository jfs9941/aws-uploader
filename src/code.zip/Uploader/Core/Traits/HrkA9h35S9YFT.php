<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\X5zE8bFBbBVcm;
use Jfs\Uploader\Core\VhdgLYFn8a0ds;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
trait HrkA9h35S9YFT
{
    private $R_58H;
    private $GwO9B;
    private $AThgS;
    public function mBtVCiNqqCF() : string
    {
        return X5zE8bFBbBVcm::m46mJEWRin8($this->R_58H->getFilename());
    }
    public function mMYcEvkVSg5() : X5zE8bFBbBVcm
    {
        goto DmRwZ;
        DmRwZ:
        if (!(null !== $this->GwO9B)) {
            goto ITxsk;
        }
        goto fk289;
        fk289:
        return $this->GwO9B;
        goto xljWm;
        MK32j:
        return $this->GwO9B;
        goto XFfn1;
        F5Msk:
        $this->mNSnvCCFnSt();
        goto MK32j;
        xljWm:
        ITxsk:
        goto F5Msk;
        XFfn1:
    }
    private function mNSnvCCFnSt() : VhdgLYFn8a0ds
    {
        goto DCRC5;
        grVL0:
        G7XXS:
        goto k7MqD;
        JTIHI:
        $Y4Nam = json_decode($tu6JL, true);
        goto b7PNZ;
        DCRC5:
        $tu6JL = $this->AThgS->get($this->mBtVCiNqqCF());
        goto uo5nR;
        uo5nR:
        if (!$tu6JL) {
            goto G7XXS;
        }
        goto JTIHI;
        Pszlj:
        return $this;
        goto grVL0;
        k7MqD:
        throw new AsUdPM9ttxh6c("File {$this->R_58H->getFilename()} is not PreSigned upload");
        goto Cf0V0;
        b7PNZ:
        $this->GwO9B = X5zE8bFBbBVcm::m1nZyBGJ4sm($Y4Nam);
        goto Pszlj;
        Cf0V0:
    }
    public function maYcy0QKzJE($keMvO, $y5Uo1, $U3GL3, $xEjOf, $J7E9r, $NjcWd = 's3') : void
    {
        $this->GwO9B = X5zE8bFBbBVcm::mUmiVJ5XxHa($this->R_58H, $keMvO, $y5Uo1, $J7E9r, $U3GL3, $xEjOf, $NjcWd);
    }
}
