<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\ZQCRUoYnm7ASE;
use Jfs\Uploader\Core\FUCc1kyYZtja3;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
trait Tu7opFhr9ThYA
{
    private $nIFfY;
    private $cfV4P;
    private $uaFPR;
    public function mHD2WAKGQbz() : string
    {
        return ZQCRUoYnm7ASE::mbbcEvheO3r($this->nIFfY->getFilename());
    }
    public function mkBf6Gw5jFn() : ZQCRUoYnm7ASE
    {
        goto jHNrM;
        GZyVd:
        return $this->cfV4P;
        goto rr_Xw;
        LVuGR:
        return $this->cfV4P;
        goto CW5oU;
        O1C10:
        $this->mzzwcv0uqlO();
        goto GZyVd;
        jHNrM:
        if (!(null !== $this->cfV4P)) {
            goto MJJb7;
        }
        goto LVuGR;
        CW5oU:
        MJJb7:
        goto O1C10;
        rr_Xw:
    }
    private function mzzwcv0uqlO() : FUCc1kyYZtja3
    {
        goto isdsU;
        aY8Hm:
        $MX8VY = json_decode($vaT9c, true);
        goto vSZUY;
        HMuda:
        throw new DbtXptYiNGheI("File {$this->nIFfY->getFilename()} is not PreSigned upload");
        goto tw6W5;
        vSZUY:
        $this->cfV4P = ZQCRUoYnm7ASE::m53a1okOL98($MX8VY);
        goto EbmPl;
        EbmPl:
        return $this;
        goto A3kHK;
        mmXXD:
        if (!$vaT9c) {
            goto yCVw7;
        }
        goto aY8Hm;
        isdsU:
        $vaT9c = $this->uaFPR->get($this->mHD2WAKGQbz());
        goto mmXXD;
        A3kHK:
        yCVw7:
        goto HMuda;
        tw6W5:
    }
    public function mljBX6varR4($AimGO, $Mcv7F, $NM6rj, $R5uXi, $Iwgmc, $nHjZR = 's3') : void
    {
        $this->cfV4P = ZQCRUoYnm7ASE::mXCEl1YsBnP($this->nIFfY, $AimGO, $Mcv7F, $Iwgmc, $NM6rj, $R5uXi, $nHjZR);
    }
}
