<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\DiGhNuHXqO8Po;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Exception\HA83jJulZGJMz;
trait GzYkrJxGq9goW
{
    private $eFjaC = [];
    public function mM8xXTkFSyC($cHJNc)
    {
        goto SR1hJ;
        gB7Wz:
        W3bjC:
        goto a9iht;
        SR1hJ:
        if ($this instanceof Model) {
            goto wXXZV;
        }
        goto MIi2T;
        K22S7:
        $this->setAttribute('status', $cHJNc);
        goto gB7Wz;
        sjEz3:
        goto W3bjC;
        goto Xf79U;
        Xf79U:
        wXXZV:
        goto K22S7;
        MIi2T:
        $this->status = $cHJNc;
        goto sjEz3;
        a9iht:
    }
    public function mmihNChVYRn()
    {
        goto FoN2i;
        QQsPX:
        return $this->getAttribute('status');
        goto Ekq7n;
        CZulI:
        return $this->status;
        goto dskVW;
        Ekq7n:
        ChJYd:
        goto CZulI;
        FoN2i:
        if (!$this instanceof Model) {
            goto ChJYd;
        }
        goto QQsPX;
        dskVW:
    }
    public function mZunb8ueiKo($CqnA0)
    {
        goto vAiur;
        DUqYQ:
        throw HA83jJulZGJMz::mxjUjZRKOHB($this->id ?? 'unknown', $this->mmihNChVYRn(), $CqnA0);
        goto l78sv;
        I7bkS:
        KOo50:
        goto CD8i1;
        vAiur:
        if ($this->mnvJnuvaU99($CqnA0)) {
            goto J0xr1;
        }
        goto DUqYQ;
        zhcL1:
        GCHWP:
        goto ja4MJ;
        udwez:
        if ($this instanceof Model) {
            goto GCHWP;
        }
        goto XX9aG;
        XX9aG:
        $this->status = $CqnA0;
        goto YZ0zo;
        l78sv:
        J0xr1:
        goto ELEXT;
        ja4MJ:
        $this->setAttribute('status', $CqnA0);
        goto I7bkS;
        CD8i1:
        foreach ($this->eFjaC as $Q0byK) {
            $Q0byK->mA5gQsszPSr($w39FK, $CqnA0);
            EWHSl:
        }
        goto IGc2E;
        YZ0zo:
        goto KOo50;
        goto zhcL1;
        ELEXT:
        $w39FK = $this->mmihNChVYRn();
        goto udwez;
        IGc2E:
        pvCfK:
        goto cqd64;
        cqd64:
    }
    public function mnvJnuvaU99($CqnA0)
    {
        goto SieMN;
        rzJoe:
        VDcra:
        goto SiSQF;
        SiSQF:
        HNr05:
        goto RSaks;
        SieMN:
        switch ($this->status) {
            case U8OFutptQGm3S::UPLOADING:
                return U8OFutptQGm3S::UPLOADED == $CqnA0 || U8OFutptQGm3S::UPLOADING == $CqnA0 || U8OFutptQGm3S::ABORTED == $CqnA0;
            case U8OFutptQGm3S::UPLOADED:
                return U8OFutptQGm3S::PROCESSING == $CqnA0 || U8OFutptQGm3S::DELETED == $CqnA0;
            case U8OFutptQGm3S::PROCESSING:
                return in_array($CqnA0, [U8OFutptQGm3S::WATERMARK_PROCESSED, U8OFutptQGm3S::THUMBNAIL_PROCESSED, U8OFutptQGm3S::ENCODING_PROCESSED, U8OFutptQGm3S::ENCODING_ERROR, U8OFutptQGm3S::BLUR_PROCESSED, U8OFutptQGm3S::DELETED, U8OFutptQGm3S::FINISHED]);
            case U8OFutptQGm3S::FINISHED:
            case U8OFutptQGm3S::ABORTED:
                return U8OFutptQGm3S::DELETED == $CqnA0;
            case U8OFutptQGm3S::ENCODING_PROCESSED:
                return U8OFutptQGm3S::FINISHED == $CqnA0 || U8OFutptQGm3S::DELETED == $CqnA0;
            default:
                return false;
        }
        goto rzJoe;
        RSaks:
    }
    public function mPleB6N0Rmu(DiGhNuHXqO8Po $Q0byK)
    {
        $this->eFjaC[] = $Q0byK;
    }
}
