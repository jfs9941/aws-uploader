<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait U1oUBtFUca4cm
{
    public function getFilename() : string
    {
        return $this->getAttribute('id');
    }
    public function getExtension() : string
    {
        return $this->getAttribute('type');
    }
    public function getLocation() : string
    {
        return $this->getAttribute('filename');
    }
    public function initLocation(string $uFMJx)
    {
        $this->filename = $uFMJx;
        return $this;
    }
    public function mjOpMrHF08N($OFz0s) : self
    {
        $this->setAttribute('driver', $OFz0s);
        return $this;
    }
}
