<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\D1gefDsblgSHh;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Exception\D2GpNcz5KiI9K;
use Illuminate\Database\Eloquent\Model;
trait NnqCGr9M8kJNm
{
    private $WtFTu = [];
    public function mMTZSzpDsC7($SfXjy)
    {
        goto Jv6fg;
        vvVdw:
        goto fMmW8;
        goto l6BUs;
        Jv6fg:
        if ($this instanceof Model) {
            goto IqLSq;
        }
        goto WAR6v;
        l6BUs:
        IqLSq:
        goto Swf7X;
        Swf7X:
        $this->setAttribute('status', $SfXjy);
        goto MH4hJ;
        WAR6v:
        $this->status = $SfXjy;
        goto vvVdw;
        MH4hJ:
        fMmW8:
        goto RQSjd;
        RQSjd:
    }
    public function m1mmBreyOae()
    {
        goto pQ0QP;
        VAphF:
        return $this->getAttribute('status');
        goto mpwB_;
        qSaG7:
        return $this->status;
        goto GKjA_;
        pQ0QP:
        if (!$this instanceof Model) {
            goto h1OtM;
        }
        goto VAphF;
        mpwB_:
        h1OtM:
        goto qSaG7;
        GKjA_:
    }
    public function mVhOJ1PgG8J($vS1iO)
    {
        goto nSkZq;
        s2wQs:
        if ($this instanceof Model) {
            goto qd3Wv;
        }
        goto JLUOn;
        AiCAL:
        NGDXu:
        goto SRzdb;
        JLUOn:
        $this->status = $vS1iO;
        goto jJSaH;
        gwkQL:
        PkoEF:
        goto iR8lC;
        jJSaH:
        goto yB0MI;
        goto nbs0C;
        Dlkmc:
        foreach ($this->WtFTu as $vufeo) {
            $vufeo->mop1CVR7YoY($ZHiT_, $vS1iO);
            vJ3vb:
        }
        goto gwkQL;
        SRzdb:
        $ZHiT_ = $this->m1mmBreyOae();
        goto s2wQs;
        Cb0Lh:
        throw D2GpNcz5KiI9K::m5QMC5hX1oh($this->id ?? 'unknown', $this->m1mmBreyOae(), $vS1iO);
        goto AiCAL;
        T_PKW:
        $this->setAttribute('status', $vS1iO);
        goto h1oFs;
        nSkZq:
        if ($this->m7rh7ElFKF0($vS1iO)) {
            goto NGDXu;
        }
        goto Cb0Lh;
        nbs0C:
        qd3Wv:
        goto T_PKW;
        h1oFs:
        yB0MI:
        goto Dlkmc;
        iR8lC:
    }
    public function m7rh7ElFKF0($vS1iO)
    {
        goto O7iGV;
        Hur5G:
        jqP0Q:
        goto euSgx;
        O7iGV:
        switch ($this->status) {
            case IOOvAXAyKHLW2::UPLOADING:
                return IOOvAXAyKHLW2::UPLOADED == $vS1iO || IOOvAXAyKHLW2::UPLOADING == $vS1iO || IOOvAXAyKHLW2::ABORTED == $vS1iO;
            case IOOvAXAyKHLW2::UPLOADED:
                return IOOvAXAyKHLW2::PROCESSING == $vS1iO || IOOvAXAyKHLW2::DELETED == $vS1iO;
            case IOOvAXAyKHLW2::PROCESSING:
                return in_array($vS1iO, [IOOvAXAyKHLW2::WATERMARK_PROCESSED, IOOvAXAyKHLW2::THUMBNAIL_PROCESSED, IOOvAXAyKHLW2::ENCODING_PROCESSED, IOOvAXAyKHLW2::ENCODING_ERROR, IOOvAXAyKHLW2::BLUR_PROCESSED, IOOvAXAyKHLW2::DELETED, IOOvAXAyKHLW2::FINISHED, IOOvAXAyKHLW2::PROCESSING]);
            case IOOvAXAyKHLW2::FINISHED:
            case IOOvAXAyKHLW2::ABORTED:
                return IOOvAXAyKHLW2::DELETED == $vS1iO;
            case IOOvAXAyKHLW2::ENCODING_PROCESSED:
                return IOOvAXAyKHLW2::FINISHED == $vS1iO || IOOvAXAyKHLW2::DELETED == $vS1iO;
            default:
                return false;
        }
        goto Hur5G;
        euSgx:
        yWKwh:
        goto Y7XAJ;
        Y7XAJ:
    }
    public function mj3Wprz3dA2(D1gefDsblgSHh $vufeo)
    {
        $this->WtFTu[] = $vufeo;
    }
}
