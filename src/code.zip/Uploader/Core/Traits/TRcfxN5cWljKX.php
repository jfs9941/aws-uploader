<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XXOVbK7SeD5pn;
use Jfs\Uploader\Core\XWJCs1ZDQGYBH;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
trait TRcfxN5cWljKX
{
    private $tEOkh;
    private $HWzT0;
    private $DhHSC;
    public function mSoaLVttBsh() : string
    {
        return XXOVbK7SeD5pn::mujQ08d9CEo($this->tEOkh->getFilename());
    }
    public function mLzfhDWzVE5() : XXOVbK7SeD5pn
    {
        goto ChYVH;
        RyJWU:
        return $this->HWzT0;
        goto XfGSn;
        YVTft:
        return $this->HWzT0;
        goto rZ32Z;
        sG9v0:
        $this->mosz4VIUsb0();
        goto RyJWU;
        ChYVH:
        if (!(null !== $this->HWzT0)) {
            goto hvqKc;
        }
        goto YVTft;
        rZ32Z:
        hvqKc:
        goto sG9v0;
        XfGSn:
    }
    private function mosz4VIUsb0() : XWJCs1ZDQGYBH
    {
        goto HfyCP;
        dcO9l:
        if (!$XU6_i) {
            goto TyPkx;
        }
        goto ujBUs;
        ujBUs:
        $UssaC = json_decode($XU6_i, true);
        goto FwYYS;
        FwYYS:
        $this->HWzT0 = XXOVbK7SeD5pn::mSQpjbj4OST($UssaC);
        goto T7x3X;
        msbSE:
        TyPkx:
        goto q4vOv;
        T7x3X:
        return $this;
        goto msbSE;
        q4vOv:
        throw new CB5eg0zuzdVv8("File {$this->tEOkh->getFilename()} is not PreSigned upload");
        goto mySKJ;
        HfyCP:
        $XU6_i = $this->DhHSC->get($this->mSoaLVttBsh());
        goto dcO9l;
        mySKJ:
    }
    public function mEiiqnL3tge($jmob9, $ke97a, $EiBY9, $bPa7l, $z4wME, $EWvJO = 's3') : void
    {
        $this->HWzT0 = XXOVbK7SeD5pn::mc9dxCBRxnZ($this->tEOkh, $jmob9, $ke97a, $z4wME, $EiBY9, $bPa7l, $EWvJO);
    }
}
