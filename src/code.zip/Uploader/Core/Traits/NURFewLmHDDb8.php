<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use src\Uploader\Contracts\F5Xo0te9A5R68;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Exception\BUbHQrtyLH6v0;
trait NURFewLmHDDb8
{
    private $T8FJw = [];
    public function mRGXJFOfzBv($sEGBh)
    {
        goto JLPvU;
        SV5Gs:
        $this->status = $sEGBh;
        goto sVgDF;
        A5H5s:
        $this->setAttribute('status', $sEGBh);
        goto vBDUB;
        AI1Wo:
        ezLwr:
        goto A5H5s;
        vBDUB:
        Omxnr:
        goto S1NiR;
        JLPvU:
        if ($this instanceof Model) {
            goto ezLwr;
        }
        goto SV5Gs;
        sVgDF:
        goto Omxnr;
        goto AI1Wo;
        S1NiR:
    }
    public function m6MwmezzNZD()
    {
        goto o0R0c;
        o0R0c:
        if (!$this instanceof Model) {
            goto hII4U;
        }
        goto cPS8A;
        cPS8A:
        return $this->getAttribute('status');
        goto ZtCSy;
        gOcky:
        return $this->status;
        goto Wy0kp;
        ZtCSy:
        hII4U:
        goto gOcky;
        Wy0kp:
    }
    public function mIjUnedc3Mq($LPc0j)
    {
        goto ObMDC;
        nCZHB:
        zFhZn:
        goto eBGA1;
        vZJSs:
        if ($this instanceof Model) {
            goto zFhZn;
        }
        goto isw4F;
        Vs2Se:
        goto T0FLm;
        goto nCZHB;
        U903P:
        Elfrh:
        goto Xoaft;
        ObMDC:
        if ($this->mLGYFHehYqU($LPc0j)) {
            goto j0HiK;
        }
        goto lRILP;
        xvwu5:
        $bIUUY = $this->m6MwmezzNZD();
        goto vZJSs;
        lRILP:
        throw BUbHQrtyLH6v0::mmc6pJLyCdC($this->id ?? 'unknown', $this->m6MwmezzNZD(), $LPc0j);
        goto XFuYy;
        Ucrfk:
        T0FLm:
        goto WH1H0;
        WH1H0:
        foreach ($this->T8FJw as $USLIN) {
            $USLIN->myVaRYzH5cA($bIUUY, $LPc0j);
            WpR0x:
        }
        goto U903P;
        XFuYy:
        j0HiK:
        goto xvwu5;
        isw4F:
        $this->status = $LPc0j;
        goto Vs2Se;
        eBGA1:
        $this->setAttribute('status', $LPc0j);
        goto Ucrfk;
        Xoaft:
    }
    public function mLGYFHehYqU($LPc0j)
    {
        goto NC5cE;
        Hlls0:
        NdwQd:
        goto ke71a;
        NC5cE:
        switch ($this->status) {
            case FileStatus::UPLOADING:
                return FileStatus::UPLOADED == $LPc0j || FileStatus::UPLOADING == $LPc0j || FileStatus::ABORTED == $LPc0j;
            case FileStatus::UPLOADED:
                return FileStatus::PROCESSING == $LPc0j || FileStatus::DELETED == $LPc0j;
            case FileStatus::PROCESSING:
                return in_array($LPc0j, [FileStatus::WATERMARK_PROCESSED, FileStatus::THUMBNAIL_PROCESSED, FileStatus::ENCODING_PROCESSED, FileStatus::ENCODING_ERROR, FileStatus::BLUR_PROCESSED, FileStatus::DELETED, FileStatus::FINISHED]);
            case FileStatus::FINISHED:
            case FileStatus::ABORTED:
                return FileStatus::DELETED == $LPc0j;
            case FileStatus::ENCODING_PROCESSED:
                return FileStatus::FINISHED == $LPc0j || FileStatus::DELETED == $LPc0j;
            default:
                return false;
        }
        goto Hlls0;
        ke71a:
        qhNPG:
        goto KcS0m;
        KcS0m:
    }
    public function mLnW7ZmkfSj(F5Xo0te9A5R68 $USLIN)
    {
        $this->T8FJw[] = $USLIN;
    }
}
