<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\K6rnLmlRKxy9W;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Exception\Z1EmnB00QcmrE;
trait AyFiTfhD6jOXL
{
    private $wbRFX = [];
    public function mGG5zG7yPwR($SF4Fs)
    {
        goto Fpskt;
        CkSbq:
        $this->status = $SF4Fs;
        goto e9IQh;
        nfF3H:
        cH9vm:
        goto quaJD;
        Fpskt:
        if ($this instanceof Model) {
            goto klxDS;
        }
        goto CkSbq;
        e9IQh:
        goto cH9vm;
        goto I106j;
        YO4h1:
        $this->setAttribute('status', $SF4Fs);
        goto nfF3H;
        I106j:
        klxDS:
        goto YO4h1;
        quaJD:
    }
    public function mXVq5UqcpxT()
    {
        goto FmWNZ;
        Ldc3W:
        D4SVi:
        goto k8rrv;
        Bvl50:
        return $this->getAttribute('status');
        goto Ldc3W;
        k8rrv:
        return $this->status;
        goto czJGM;
        FmWNZ:
        if (!$this instanceof Model) {
            goto D4SVi;
        }
        goto Bvl50;
        czJGM:
    }
    public function mVwoe0E3Z3I($Tc1lW)
    {
        goto knD7u;
        OMELB:
        $this->setAttribute('status', $Tc1lW);
        goto h34cQ;
        zrLU1:
        $this->status = $Tc1lW;
        goto K6H7f;
        knD7u:
        if ($this->mDz3YYxJlFf($Tc1lW)) {
            goto Io6g0;
        }
        goto FBNCs;
        h34cQ:
        p3_8W:
        goto WNcrj;
        FBNCs:
        throw Z1EmnB00QcmrE::mYwZ1uXomWp($this->id ?? 'unknown', $this->mXVq5UqcpxT(), $Tc1lW);
        goto UzZ0n;
        K6H7f:
        goto p3_8W;
        goto fjejU;
        vC0al:
        jmw5J:
        goto DWeLs;
        arQRd:
        if ($this instanceof Model) {
            goto NONPR;
        }
        goto zrLU1;
        WNcrj:
        foreach ($this->wbRFX as $JsboH) {
            $JsboH->mYTLHr2vX9t($dBS0r, $Tc1lW);
            lc9Oo:
        }
        goto vC0al;
        QThtf:
        $dBS0r = $this->mXVq5UqcpxT();
        goto arQRd;
        UzZ0n:
        Io6g0:
        goto QThtf;
        fjejU:
        NONPR:
        goto OMELB;
        DWeLs:
    }
    public function mDz3YYxJlFf($Tc1lW)
    {
        goto g_q5S;
        ZuZs_:
        nW33z:
        goto VeU1l;
        VeU1l:
        f_Qse:
        goto anw9X;
        g_q5S:
        switch ($this->status) {
            case QoCMzcKvH8Cw2::UPLOADING:
                return QoCMzcKvH8Cw2::UPLOADED == $Tc1lW || QoCMzcKvH8Cw2::UPLOADING == $Tc1lW || QoCMzcKvH8Cw2::ABORTED == $Tc1lW;
            case QoCMzcKvH8Cw2::UPLOADED:
                return QoCMzcKvH8Cw2::PROCESSING == $Tc1lW || QoCMzcKvH8Cw2::DELETED == $Tc1lW;
            case QoCMzcKvH8Cw2::PROCESSING:
                return in_array($Tc1lW, [QoCMzcKvH8Cw2::WATERMARK_PROCESSED, QoCMzcKvH8Cw2::THUMBNAIL_PROCESSED, QoCMzcKvH8Cw2::ENCODING_PROCESSED, QoCMzcKvH8Cw2::ENCODING_ERROR, QoCMzcKvH8Cw2::BLUR_PROCESSED, QoCMzcKvH8Cw2::DELETED, QoCMzcKvH8Cw2::FINISHED, QoCMzcKvH8Cw2::PROCESSING]);
            case QoCMzcKvH8Cw2::FINISHED:
            case QoCMzcKvH8Cw2::ABORTED:
                return QoCMzcKvH8Cw2::DELETED == $Tc1lW;
            case QoCMzcKvH8Cw2::ENCODING_PROCESSED:
                return QoCMzcKvH8Cw2::FINISHED == $Tc1lW || QoCMzcKvH8Cw2::DELETED == $Tc1lW;
            default:
                return false;
        }
        goto ZuZs_;
        anw9X:
    }
    public function mubjGF8zmdt(K6rnLmlRKxy9W $JsboH)
    {
        $this->wbRFX[] = $JsboH;
    }
}
