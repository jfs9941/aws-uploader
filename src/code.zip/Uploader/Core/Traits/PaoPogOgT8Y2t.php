<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\TNpNhMZr7RgP2;
use Jfs\Uploader\Core\CzJP6Lt3zlYLL;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
trait PaoPogOgT8Y2t
{
    private $a2FAI;
    private $s72hh;
    private $mY3Ys;
    public function myYTk6zPMYt() : string
    {
        return TNpNhMZr7RgP2::mqIq70uMfk6($this->a2FAI->getFilename());
    }
    public function m0Sl3pG3XHq() : TNpNhMZr7RgP2
    {
        goto grClX;
        NtQiw:
        return $this->s72hh;
        goto Ht5g2;
        ZJ3wI:
        return $this->s72hh;
        goto ESZm3;
        ESZm3:
        CuGnb:
        goto YQRVS;
        YQRVS:
        $this->m41dI3cww1h();
        goto NtQiw;
        grClX:
        if (!(null !== $this->s72hh)) {
            goto CuGnb;
        }
        goto ZJ3wI;
        Ht5g2:
    }
    private function m41dI3cww1h() : CzJP6Lt3zlYLL
    {
        goto lp6t6;
        E8Zz3:
        xGjoE:
        goto ZyDLq;
        RVfvw:
        return $this;
        goto E8Zz3;
        xY6CB:
        if (!$de0n1) {
            goto xGjoE;
        }
        goto HR4He;
        ZyDLq:
        throw new YZ6TFg5btsXHA("File {$this->a2FAI->getFilename()} is not PreSigned upload");
        goto lJaVF;
        KCEJb:
        $this->s72hh = TNpNhMZr7RgP2::mZ45dVCgYrk($VnzW6);
        goto RVfvw;
        lp6t6:
        $de0n1 = $this->mY3Ys->get($this->myYTk6zPMYt());
        goto xY6CB;
        HR4He:
        $VnzW6 = json_decode($de0n1, true);
        goto KCEJb;
        lJaVF:
    }
    public function muVuvEIhLu9($z2n_l, $QjbQw, $QMvmw, $bYnxU, $qA0_A, $TYPZ5 = 's3') : void
    {
        $this->s72hh = TNpNhMZr7RgP2::mIpLPkZdAvP($this->a2FAI, $z2n_l, $QjbQw, $qA0_A, $QMvmw, $bYnxU, $TYPZ5);
    }
}
