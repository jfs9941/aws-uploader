<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\J6QUpUFjfs5mO;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Exception\GUt8ZmYbCCh9b;
use Illuminate\Database\Eloquent\Model;
trait XGoBOvpn4TlTz
{
    private $NYV4V = [];
    public function mlS5irobHNA($NkpSq)
    {
        goto ZA2vI;
        PchMt:
        HqfPS:
        goto jt_QM;
        kBubD:
        goto IkgBi;
        goto PchMt;
        x3he7:
        $this->status = $NkpSq;
        goto kBubD;
        ZA2vI:
        if ($this instanceof Model) {
            goto HqfPS;
        }
        goto x3he7;
        vOarm:
        IkgBi:
        goto NS_Es;
        jt_QM:
        $this->setAttribute('status', $NkpSq);
        goto vOarm;
        NS_Es:
    }
    public function mCiIs22Hk9A()
    {
        goto M1VzO;
        M1VzO:
        if (!$this instanceof Model) {
            goto nEzKa;
        }
        goto T5nER;
        LvN7I:
        nEzKa:
        goto WGRhd;
        T5nER:
        return $this->getAttribute('status');
        goto LvN7I;
        WGRhd:
        return $this->status;
        goto VqY5J;
        VqY5J:
    }
    public function mKd8O9TpYCH($sPgaJ)
    {
        goto qAK7U;
        AY1Nf:
        goto tuNgu;
        goto yAGsX;
        oLoJh:
        tuNgu:
        goto Q5Ihp;
        oFf2S:
        kD2XT:
        goto Isfm8;
        pHSmg:
        if ($this instanceof Model) {
            goto NM4ft;
        }
        goto hD0EW;
        Q5Ihp:
        foreach ($this->NYV4V as $wWux_) {
            $wWux_->mZjeUKxpiHv($wM01d, $sPgaJ);
            KuMd_:
        }
        goto mW2Tl;
        qAK7U:
        if ($this->mJp2AaygZfj($sPgaJ)) {
            goto kD2XT;
        }
        goto gIEgK;
        gIEgK:
        throw GUt8ZmYbCCh9b::m16bUb62auc($this->id ?? 'unknown', $this->mCiIs22Hk9A(), $sPgaJ);
        goto oFf2S;
        mW2Tl:
        sOisM:
        goto d35Nl;
        hD0EW:
        $this->status = $sPgaJ;
        goto AY1Nf;
        yAGsX:
        NM4ft:
        goto gigHP;
        Isfm8:
        $wM01d = $this->mCiIs22Hk9A();
        goto pHSmg;
        gigHP:
        $this->setAttribute('status', $sPgaJ);
        goto oLoJh;
        d35Nl:
    }
    public function mJp2AaygZfj($sPgaJ)
    {
        goto vafNT;
        ZAXAm:
        s501V:
        goto pouXM;
        pouXM:
        zrBRO:
        goto M_Aj0;
        vafNT:
        switch ($this->status) {
            case EpMPhiTVzNYqA::UPLOADING:
                return EpMPhiTVzNYqA::UPLOADED == $sPgaJ || EpMPhiTVzNYqA::UPLOADING == $sPgaJ || EpMPhiTVzNYqA::ABORTED == $sPgaJ;
            case EpMPhiTVzNYqA::UPLOADED:
                return EpMPhiTVzNYqA::PROCESSING == $sPgaJ || EpMPhiTVzNYqA::DELETED == $sPgaJ;
            case EpMPhiTVzNYqA::PROCESSING:
                return in_array($sPgaJ, [EpMPhiTVzNYqA::WATERMARK_PROCESSED, EpMPhiTVzNYqA::THUMBNAIL_PROCESSED, EpMPhiTVzNYqA::ENCODING_PROCESSED, EpMPhiTVzNYqA::ENCODING_ERROR, EpMPhiTVzNYqA::BLUR_PROCESSED, EpMPhiTVzNYqA::DELETED, EpMPhiTVzNYqA::FINISHED, EpMPhiTVzNYqA::PROCESSING]);
            case EpMPhiTVzNYqA::FINISHED:
            case EpMPhiTVzNYqA::ABORTED:
                return EpMPhiTVzNYqA::DELETED == $sPgaJ;
            case EpMPhiTVzNYqA::ENCODING_PROCESSED:
                return EpMPhiTVzNYqA::FINISHED == $sPgaJ || EpMPhiTVzNYqA::DELETED == $sPgaJ;
            default:
                return false;
        }
        goto ZAXAm;
        M_Aj0:
    }
    public function mJpwZRYg1fj(J6QUpUFjfs5mO $wWux_)
    {
        $this->NYV4V[] = $wWux_;
    }
}
