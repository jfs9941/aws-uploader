<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\YqfGySn8nxxqU;
use Jfs\Uploader\Core\Y96dk3g6dPmcf;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
trait E0p8mbkNoqHie
{
    private $MF3ET;
    private $gjmHB;
    private $wqdCV;
    public function mEfGPqiyn18() : string
    {
        return YqfGySn8nxxqU::m5taoOo2xJN($this->MF3ET->getFilename());
    }
    public function mmWA2B9zVkK() : YqfGySn8nxxqU
    {
        goto qcker;
        xmKAx:
        I336t:
        goto deIpZ;
        nhXa1:
        return $this->gjmHB;
        goto i_yH9;
        deIpZ:
        $this->mVv212nEf36();
        goto nhXa1;
        qcker:
        if (!(null !== $this->gjmHB)) {
            goto I336t;
        }
        goto mBCdr;
        mBCdr:
        return $this->gjmHB;
        goto xmKAx;
        i_yH9:
    }
    private function mVv212nEf36() : Y96dk3g6dPmcf
    {
        goto PTOhJ;
        QAeGf:
        if (!$Mv4oI) {
            goto AiE4W;
        }
        goto Go62P;
        jcpIk:
        $this->gjmHB = YqfGySn8nxxqU::mwqdCT15iL1($ITv_u);
        goto GhKk4;
        V9v5o:
        AiE4W:
        goto l5cb8;
        PTOhJ:
        $Mv4oI = $this->wqdCV->get($this->mEfGPqiyn18());
        goto QAeGf;
        Go62P:
        $ITv_u = json_decode($Mv4oI, true);
        goto jcpIk;
        GhKk4:
        return $this;
        goto V9v5o;
        l5cb8:
        throw new JGUomNqtfkab1("File {$this->MF3ET->getFilename()} is not PreSigned upload");
        goto e1Kt9;
        e1Kt9:
    }
    public function mdO9aScQwEz($MLY7y, $VSa1F, $aAHm1, $bcSv0, $W4GNe, $XokUJ = 's3') : void
    {
        $this->gjmHB = YqfGySn8nxxqU::mSKT3rOHzZ6($this->MF3ET, $MLY7y, $VSa1F, $W4GNe, $aAHm1, $bcSv0, $XokUJ);
    }
}
