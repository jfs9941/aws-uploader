<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Traits;

trait FileCreationTrait
{
    public function getFilename(): string
    {
        return $this->getAttribute('id');
    }

    public function getExtension(): string
    {
        return $this->getAttribute('type');
    }

    public function getLocation(): string
    {
        return $this->getAttribute('filename');
    }

    public function initLocation(string $location)
    {
        $this->filename = $location;

        return $this;
    }

    public function selectStorage($driver): self
    {
        $this->setAttribute('driver', $driver);

        return $this;
    }
}
