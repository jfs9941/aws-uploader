<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait H6KOzyVgvgvTK
{
    private function mtjM2u7QUfg(string $xt6u5) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $xt6u5]));
    }
}
