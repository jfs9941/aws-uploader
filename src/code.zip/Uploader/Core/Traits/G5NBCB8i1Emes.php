<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\PzqA3QfUmhhMJ;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Exception\LjuaNh4VOaOkF;
use Illuminate\Database\Eloquent\Model;
trait G5NBCB8i1Emes
{
    private $Fup7K = [];
    public function mf3bcS2aSK5($A4X8f)
    {
        goto lfy8s;
        OYJnS:
        sNxmT:
        goto MTXWf;
        sNgo0:
        $this->status = $A4X8f;
        goto Bg9Tt;
        MTXWf:
        $this->setAttribute('status', $A4X8f);
        goto JMMef;
        Bg9Tt:
        goto xpGlT;
        goto OYJnS;
        lfy8s:
        if ($this instanceof Model) {
            goto sNxmT;
        }
        goto sNgo0;
        JMMef:
        xpGlT:
        goto U4a4K;
        U4a4K:
    }
    public function mapuydun1zI()
    {
        goto uh_FS;
        BDP7G:
        return $this->getAttribute('status');
        goto JV533;
        uh_FS:
        if (!$this instanceof Model) {
            goto iQkb6;
        }
        goto BDP7G;
        JV533:
        iQkb6:
        goto qQiUO;
        qQiUO:
        return $this->status;
        goto CsLxF;
        CsLxF:
    }
    public function muO5nIQPKS7($K1saJ)
    {
        goto lralV;
        eqQ4w:
        Ftd0Q:
        goto eHPLl;
        lralV:
        if ($this->mQ6BIo8HH5r($K1saJ)) {
            goto Ksojq;
        }
        goto aPM7W;
        bAXLX:
        Ksojq:
        goto q6E3g;
        WsT_W:
        c0kYo:
        goto RIaaV;
        lFIZr:
        if ($this instanceof Model) {
            goto c0kYo;
        }
        goto SDjFm;
        RIaaV:
        $this->setAttribute('status', $K1saJ);
        goto Umrux;
        LUsv_:
        goto Us3kC;
        goto WsT_W;
        Umrux:
        Us3kC:
        goto bybsq;
        bybsq:
        foreach ($this->Fup7K as $ekLuN) {
            $ekLuN->mjTwbCJOfRB($VtxIo, $K1saJ);
            dfZIv:
        }
        goto eqQ4w;
        aPM7W:
        throw LjuaNh4VOaOkF::mD1XSPqgcUD($this->id ?? 'unknown', $this->mapuydun1zI(), $K1saJ);
        goto bAXLX;
        q6E3g:
        $VtxIo = $this->mapuydun1zI();
        goto lFIZr;
        SDjFm:
        $this->status = $K1saJ;
        goto LUsv_;
        eHPLl:
    }
    public function mQ6BIo8HH5r($K1saJ)
    {
        goto ONTTP;
        q8XQI:
        lYp4p:
        goto ogqhJ;
        CYV0h:
        gSk_d:
        goto q8XQI;
        ONTTP:
        switch ($this->status) {
            case HGmeWpZQSxAlO::UPLOADING:
                return HGmeWpZQSxAlO::UPLOADED == $K1saJ || HGmeWpZQSxAlO::UPLOADING == $K1saJ || HGmeWpZQSxAlO::ABORTED == $K1saJ;
            case HGmeWpZQSxAlO::UPLOADED:
                return HGmeWpZQSxAlO::PROCESSING == $K1saJ || HGmeWpZQSxAlO::DELETED == $K1saJ;
            case HGmeWpZQSxAlO::PROCESSING:
                return in_array($K1saJ, [HGmeWpZQSxAlO::WATERMARK_PROCESSED, HGmeWpZQSxAlO::THUMBNAIL_PROCESSED, HGmeWpZQSxAlO::ENCODING_PROCESSED, HGmeWpZQSxAlO::ENCODING_ERROR, HGmeWpZQSxAlO::BLUR_PROCESSED, HGmeWpZQSxAlO::DELETED, HGmeWpZQSxAlO::FINISHED, HGmeWpZQSxAlO::PROCESSING]);
            case HGmeWpZQSxAlO::FINISHED:
            case HGmeWpZQSxAlO::ABORTED:
                return HGmeWpZQSxAlO::DELETED == $K1saJ;
            case HGmeWpZQSxAlO::ENCODING_PROCESSED:
                return HGmeWpZQSxAlO::FINISHED == $K1saJ || HGmeWpZQSxAlO::DELETED == $K1saJ;
            default:
                return false;
        }
        goto CYV0h;
        ogqhJ:
    }
    public function mv8Sk2uSFhz(PzqA3QfUmhhMJ $ekLuN)
    {
        $this->Fup7K[] = $ekLuN;
    }
}
