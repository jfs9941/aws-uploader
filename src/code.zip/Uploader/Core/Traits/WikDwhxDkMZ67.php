<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Traits; trait WikDwhxDkMZ67 { public function getFilename() : string { return $this->getAttribute('id'); } public function getExtension() : string { return $this->getAttribute('type'); } public function getLocation() : string { return $this->getAttribute('filename'); } public function initLocation(string $BFxyy) { $this->filename = $BFxyy; return $this; } public function mD0gYQWbEMA($VbqH4) : self { $this->setAttribute('driver', $VbqH4); return $this; } }
