<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Hyi6BrRTUHRYH;
use Jfs\Uploader\Core\GHjLMBSnTOoC3;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
trait KUN5Q48ryL1qd
{
    private $woTf1;
    private $crELx;
    private $H58rn;
    public function mgKbmuuPnDq() : string
    {
        return Hyi6BrRTUHRYH::me28TlZc9hY($this->woTf1->getFilename());
    }
    public function mCZg2QiXqrg() : Hyi6BrRTUHRYH
    {
        goto SNOoB;
        yzuRr:
        return $this->crELx;
        goto uWhQt;
        SNOoB:
        if (!(null !== $this->crELx)) {
            goto LRMit;
        }
        goto yzuRr;
        uWhQt:
        LRMit:
        goto Ot3gV;
        nPBkO:
        return $this->crELx;
        goto YDnOf;
        Ot3gV:
        $this->m7cgC8D9UxI();
        goto nPBkO;
        YDnOf:
    }
    private function m7cgC8D9UxI() : GHjLMBSnTOoC3
    {
        goto aX0oI;
        sAft4:
        $this->crELx = Hyi6BrRTUHRYH::m0B1AYMIsca($QRxju);
        goto zPB7S;
        O0diD:
        if (!$cB2vA) {
            goto m1Kc7;
        }
        goto bUHCi;
        Kc2Ce:
        m1Kc7:
        goto eT7s0;
        eT7s0:
        throw new KzbSFcd7qiwCv("File {$this->woTf1->getFilename()} is not PreSigned upload");
        goto QBcSb;
        aX0oI:
        $cB2vA = $this->H58rn->get($this->mgKbmuuPnDq());
        goto O0diD;
        bUHCi:
        $QRxju = json_decode($cB2vA, true);
        goto sAft4;
        zPB7S:
        return $this;
        goto Kc2Ce;
        QBcSb:
    }
    public function mO1FRqgwloA($Pg2Ll, $oZuOJ, $XjqSL, $ZxcNO, $efA5J, $ewvCB = 's3') : void
    {
        $this->crELx = Hyi6BrRTUHRYH::mh7n9EI1nrg($this->woTf1, $Pg2Ll, $oZuOJ, $efA5J, $XjqSL, $ZxcNO, $ewvCB);
    }
}
