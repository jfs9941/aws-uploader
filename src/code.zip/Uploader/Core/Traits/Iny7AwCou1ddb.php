<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\YhOLLtTXuTxXo;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Exception\JTzKeriqU61FK;
use Illuminate\Database\Eloquent\Model;
trait Iny7AwCou1ddb
{
    private $M_FpN = [];
    public function mQ7dAxBkFij($AXUB2)
    {
        goto m2J4N;
        m2J4N:
        if ($this instanceof Model) {
            goto h1hfI;
        }
        goto q7Zav;
        ryc2D:
        $this->setAttribute('status', $AXUB2);
        goto KzPo8;
        wXtaK:
        h1hfI:
        goto ryc2D;
        KzPo8:
        aP0tk:
        goto SWKy8;
        q7Zav:
        $this->status = $AXUB2;
        goto m1MUN;
        m1MUN:
        goto aP0tk;
        goto wXtaK;
        SWKy8:
    }
    public function mq5z1mFF1Xu()
    {
        goto KsVrw;
        QvybH:
        Y4x1X:
        goto GPqv_;
        KsVrw:
        if (!$this instanceof Model) {
            goto Y4x1X;
        }
        goto grefM;
        grefM:
        return $this->getAttribute('status');
        goto QvybH;
        GPqv_:
        return $this->status;
        goto KsIP1;
        KsIP1:
    }
    public function m7ddHwazacD($y6lx_)
    {
        goto r3POV;
        Dmfsp:
        $this->status = $y6lx_;
        goto K4irW;
        K4irW:
        goto i9ns5;
        goto yfyU0;
        zmh3w:
        foreach ($this->M_FpN as $Ou8O8) {
            $Ou8O8->mW0P3SBpyXg($zdNIC, $y6lx_);
            wwEe4:
        }
        goto qsZwa;
        ketd5:
        i9ns5:
        goto zmh3w;
        yOdS0:
        throw JTzKeriqU61FK::m2MXj68TiOv($this->id ?? 'unknown', $this->mq5z1mFF1Xu(), $y6lx_);
        goto gWQhK;
        RkePf:
        if ($this instanceof Model) {
            goto Tq4WN;
        }
        goto Dmfsp;
        qsZwa:
        EFHNw:
        goto W3esN;
        yfyU0:
        Tq4WN:
        goto ZBVoV;
        gWQhK:
        B23GB:
        goto HF62L;
        HF62L:
        $zdNIC = $this->mq5z1mFF1Xu();
        goto RkePf;
        r3POV:
        if ($this->mlAr8GJp5gl($y6lx_)) {
            goto B23GB;
        }
        goto yOdS0;
        ZBVoV:
        $this->setAttribute('status', $y6lx_);
        goto ketd5;
        W3esN:
    }
    public function mlAr8GJp5gl($y6lx_)
    {
        goto jKU66;
        AH3ff:
        DaqCn:
        goto Fz2sa;
        jKU66:
        switch ($this->status) {
            case EXecNg2hg7kwl::UPLOADING:
                return EXecNg2hg7kwl::UPLOADED == $y6lx_ || EXecNg2hg7kwl::UPLOADING == $y6lx_ || EXecNg2hg7kwl::ABORTED == $y6lx_;
            case EXecNg2hg7kwl::UPLOADED:
                return EXecNg2hg7kwl::PROCESSING == $y6lx_ || EXecNg2hg7kwl::DELETED == $y6lx_;
            case EXecNg2hg7kwl::PROCESSING:
                return in_array($y6lx_, [EXecNg2hg7kwl::WATERMARK_PROCESSED, EXecNg2hg7kwl::THUMBNAIL_PROCESSED, EXecNg2hg7kwl::ENCODING_PROCESSED, EXecNg2hg7kwl::ENCODING_ERROR, EXecNg2hg7kwl::BLUR_PROCESSED, EXecNg2hg7kwl::DELETED, EXecNg2hg7kwl::FINISHED, EXecNg2hg7kwl::PROCESSING]);
            case EXecNg2hg7kwl::FINISHED:
            case EXecNg2hg7kwl::ABORTED:
                return EXecNg2hg7kwl::DELETED == $y6lx_;
            case EXecNg2hg7kwl::ENCODING_PROCESSED:
                return EXecNg2hg7kwl::FINISHED == $y6lx_ || EXecNg2hg7kwl::DELETED == $y6lx_;
            default:
                return false;
        }
        goto AH3ff;
        Fz2sa:
        T1lB1:
        goto tDHsr;
        tDHsr:
    }
    public function mf8n37ngIzn(YhOLLtTXuTxXo $Ou8O8)
    {
        $this->M_FpN[] = $Ou8O8;
    }
}
