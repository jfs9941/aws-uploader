<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\LJgttSC2SO5Qb;
use Jfs\Uploader\Core\Eyra2OnsK5qBk;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
trait Y5hONQswBVdkk
{
    private $IJ6tP;
    private $tKwA3;
    private $wOw95;
    public function mpi6jqATMm1() : string
    {
        return LJgttSC2SO5Qb::mMyUAUeGBJE($this->IJ6tP->getFilename());
    }
    public function mROzB90pF6O() : LJgttSC2SO5Qb
    {
        goto GcE79;
        kKEHN:
        return $this->tKwA3;
        goto tDfYE;
        tDfYE:
        dStqr:
        goto lW6CA;
        lW6CA:
        $this->m1us7rpWBJV();
        goto fsKvZ;
        GcE79:
        if (!(null !== $this->tKwA3)) {
            goto dStqr;
        }
        goto kKEHN;
        fsKvZ:
        return $this->tKwA3;
        goto KXBjm;
        KXBjm:
    }
    private function m1us7rpWBJV() : Eyra2OnsK5qBk
    {
        goto eLStQ;
        An3Vv:
        $this->tKwA3 = LJgttSC2SO5Qb::mg0pO2HMPyv($lPt_3);
        goto kZIA9;
        vqThK:
        if (!$cJ3Lp) {
            goto AF_nC;
        }
        goto MZEQY;
        kZIA9:
        return $this;
        goto zwn7l;
        ITsT6:
        throw new TvagaDpTwJZ4h("File {$this->IJ6tP->getFilename()} is not PreSigned upload");
        goto DTtin;
        MZEQY:
        $lPt_3 = json_decode($cJ3Lp, true);
        goto An3Vv;
        zwn7l:
        AF_nC:
        goto ITsT6;
        eLStQ:
        $cJ3Lp = $this->wOw95->get($this->mpi6jqATMm1());
        goto vqThK;
        DTtin:
    }
    public function mpyVFiyEScS($mbQ5e, $MkOZl, $SfZkF, $QMgWa, $aG8Gq, $NigPe = 's3') : void
    {
        $this->tKwA3 = LJgttSC2SO5Qb::mv6UcYIveyF($this->IJ6tP, $mbQ5e, $MkOZl, $aG8Gq, $SfZkF, $QMgWa, $NigPe);
    }
}
