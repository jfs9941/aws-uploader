<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait YfJc83Sgzhtbx
{
    private function m70pw4Z02m5(string $Z9AwD) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $Z9AwD]));
    }
}
