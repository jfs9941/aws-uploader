<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\AbQOw1WF9dU8u;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Exception\VSaAUeOOPZiL5;
use Illuminate\Database\Eloquent\Model;
trait SphMX2uWp2oS1
{
    private $G5lzt = [];
    public function mWRFuBOBU6q($oK1mp)
    {
        goto qFPon;
        Z3e24:
        aqCJ6:
        goto XChHe;
        O1OHT:
        goto aqCJ6;
        goto Ic3z_;
        qFPon:
        if ($this instanceof Model) {
            goto Vcvf8;
        }
        goto hZ1_1;
        CKnJB:
        $this->setAttribute('status', $oK1mp);
        goto Z3e24;
        hZ1_1:
        $this->status = $oK1mp;
        goto O1OHT;
        Ic3z_:
        Vcvf8:
        goto CKnJB;
        XChHe:
    }
    public function mhA6smQiPVz()
    {
        goto tb9Pz;
        RTRf0:
        return $this->status;
        goto RYCUC;
        IS7sE:
        return $this->getAttribute('status');
        goto fXKAA;
        fXKAA:
        SSnwq:
        goto RTRf0;
        tb9Pz:
        if (!$this instanceof Model) {
            goto SSnwq;
        }
        goto IS7sE;
        RYCUC:
    }
    public function mIiE80g96Fo($mm4RR)
    {
        goto hHRkt;
        BuY5Q:
        zsAQT:
        goto zX0H6;
        ZyGPg:
        foreach ($this->G5lzt as $nYpAb) {
            $nYpAb->mcSizi4ikHF($UociD, $mm4RR);
            inrpd:
        }
        goto BuY5Q;
        PkAPq:
        $this->setAttribute('status', $mm4RR);
        goto AxDuq;
        AxDuq:
        lQkrt:
        goto ZyGPg;
        UwmzK:
        $this->status = $mm4RR;
        goto nYZ4y;
        ZinMF:
        HRvBt:
        goto PkAPq;
        hHRkt:
        if ($this->mdI7468YBxf($mm4RR)) {
            goto r3WqJ;
        }
        goto bhYDr;
        Mw6Ha:
        r3WqJ:
        goto itOaI;
        nYZ4y:
        goto lQkrt;
        goto ZinMF;
        itOaI:
        $UociD = $this->mhA6smQiPVz();
        goto HtRYq;
        bhYDr:
        throw VSaAUeOOPZiL5::mvVCJPHdM77($this->id ?? 'unknown', $this->mhA6smQiPVz(), $mm4RR);
        goto Mw6Ha;
        HtRYq:
        if ($this instanceof Model) {
            goto HRvBt;
        }
        goto UwmzK;
        zX0H6:
    }
    public function mdI7468YBxf($mm4RR)
    {
        goto mBTXx;
        mBTXx:
        switch ($this->status) {
            case Tbw0jsMnRbOTP::UPLOADING:
                return Tbw0jsMnRbOTP::UPLOADED == $mm4RR || Tbw0jsMnRbOTP::UPLOADING == $mm4RR || Tbw0jsMnRbOTP::ABORTED == $mm4RR;
            case Tbw0jsMnRbOTP::UPLOADED:
                return Tbw0jsMnRbOTP::PROCESSING == $mm4RR || Tbw0jsMnRbOTP::DELETED == $mm4RR;
            case Tbw0jsMnRbOTP::PROCESSING:
                return in_array($mm4RR, [Tbw0jsMnRbOTP::WATERMARK_PROCESSED, Tbw0jsMnRbOTP::THUMBNAIL_PROCESSED, Tbw0jsMnRbOTP::ENCODING_PROCESSED, Tbw0jsMnRbOTP::ENCODING_ERROR, Tbw0jsMnRbOTP::BLUR_PROCESSED, Tbw0jsMnRbOTP::DELETED, Tbw0jsMnRbOTP::FINISHED, Tbw0jsMnRbOTP::PROCESSING]);
            case Tbw0jsMnRbOTP::FINISHED:
            case Tbw0jsMnRbOTP::ABORTED:
                return Tbw0jsMnRbOTP::DELETED == $mm4RR;
            case Tbw0jsMnRbOTP::ENCODING_PROCESSED:
                return Tbw0jsMnRbOTP::FINISHED == $mm4RR || Tbw0jsMnRbOTP::DELETED == $mm4RR;
            default:
                return false;
        }
        goto n0FJQ;
        EPYhT:
        kUjCp:
        goto ZLkvG;
        n0FJQ:
        RCnGr:
        goto EPYhT;
        ZLkvG:
    }
    public function mYvBQMWkcb5(AbQOw1WF9dU8u $nYpAb)
    {
        $this->G5lzt[] = $nYpAb;
    }
}
