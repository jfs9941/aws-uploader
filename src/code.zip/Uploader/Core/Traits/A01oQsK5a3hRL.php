<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Ds7G2MSK6KX1Y;
use Jfs\Uploader\Core\ED7I8bwNqdusd;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
trait A01oQsK5a3hRL
{
    private $MhOEp;
    private $n2k1E;
    private $yDluE;
    public function mZx3Wns8jZm() : string
    {
        return Ds7G2MSK6KX1Y::mO1jRHpZvPV($this->MhOEp->getFilename());
    }
    public function mvHStueAWqd() : Ds7G2MSK6KX1Y
    {
        goto Te8o9;
        Te8o9:
        if (!(null !== $this->n2k1E)) {
            goto Imqe1;
        }
        goto umdRf;
        nl7m0:
        $this->mvXhQvR5B2j();
        goto AZxF8;
        umdRf:
        return $this->n2k1E;
        goto xbqoy;
        AZxF8:
        return $this->n2k1E;
        goto wZ4rv;
        xbqoy:
        Imqe1:
        goto nl7m0;
        wZ4rv:
    }
    private function mvXhQvR5B2j() : ED7I8bwNqdusd
    {
        goto geWVC;
        Zptt_:
        throw new WpKhE6K2C9AsD("File {$this->MhOEp->getFilename()} is not PreSigned upload");
        goto UXpfS;
        geWVC:
        $nWF7q = $this->yDluE->get($this->mZx3Wns8jZm());
        goto O099I;
        AaCoj:
        $this->n2k1E = Ds7G2MSK6KX1Y::mHZ3f1oPTE4($Fb2Za);
        goto uh0uP;
        uh0uP:
        return $this;
        goto aAV0_;
        aAV0_:
        yUAjc:
        goto Zptt_;
        ttTEy:
        $Fb2Za = json_decode($nWF7q, true);
        goto AaCoj;
        O099I:
        if (!$nWF7q) {
            goto yUAjc;
        }
        goto ttTEy;
        UXpfS:
    }
    public function mXxX3rLJeae($QXSh4, $OegHY, $UmfS4, $jwVeU, $yJf24, $Z9PFQ = 's3') : void
    {
        $this->n2k1E = Ds7G2MSK6KX1Y::mFj6ejQPU3D($this->MhOEp, $QXSh4, $OegHY, $yJf24, $UmfS4, $jwVeU, $Z9PFQ);
    }
}
