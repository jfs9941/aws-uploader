<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\Fg5ZctnJZvYzy;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Exception\DTlKOLT8tkTnv;
trait ZKxVDSicUFaFP
{
    private $KxYJd = [];
    public function mhnYveV1r0A($DqhVQ)
    {
        goto jQmWb;
        Ql3sL:
        $this->status = $DqhVQ;
        goto U9JfK;
        NR4Gh:
        $this->setAttribute('status', $DqhVQ);
        goto t7fs4;
        U9JfK:
        goto jJe82;
        goto hVWYf;
        t7fs4:
        jJe82:
        goto VvfyB;
        jQmWb:
        if ($this instanceof Model) {
            goto GWbdr;
        }
        goto Ql3sL;
        hVWYf:
        GWbdr:
        goto NR4Gh;
        VvfyB:
    }
    public function m2jjzfjGLGF()
    {
        goto DpDoA;
        EvpHb:
        return $this->getAttribute('status');
        goto XD0aG;
        mROku:
        return $this->status;
        goto nMiWV;
        DpDoA:
        if (!$this instanceof Model) {
            goto V8fWb;
        }
        goto EvpHb;
        XD0aG:
        V8fWb:
        goto mROku;
        nMiWV:
    }
    public function meQCGHEeK80($ZJBuU)
    {
        goto UMojT;
        Qt3YC:
        goto KLv4L;
        goto ItL5z;
        Fxi1j:
        RvPHH:
        goto urQX1;
        ANNkQ:
        $this->status = $ZJBuU;
        goto Qt3YC;
        pXk4i:
        $GE5Om = $this->m2jjzfjGLGF();
        goto SKZrY;
        XGxBr:
        $this->setAttribute('status', $ZJBuU);
        goto bM321;
        UMojT:
        if ($this->mO6zkoxFvn7($ZJBuU)) {
            goto KzhKl;
        }
        goto L1hzJ;
        ouiS2:
        foreach ($this->KxYJd as $Iv7zH) {
            $Iv7zH->mWjTC6Gp86v($GE5Om, $ZJBuU);
            R_Goj:
        }
        goto Fxi1j;
        SKZrY:
        if ($this instanceof Model) {
            goto zLfXe;
        }
        goto ANNkQ;
        jJb5i:
        KzhKl:
        goto pXk4i;
        L1hzJ:
        throw DTlKOLT8tkTnv::mpWKgd2uQQY($this->id ?? 'unknown', $this->m2jjzfjGLGF(), $ZJBuU);
        goto jJb5i;
        bM321:
        KLv4L:
        goto ouiS2;
        ItL5z:
        zLfXe:
        goto XGxBr;
        urQX1:
    }
    public function mO6zkoxFvn7($ZJBuU)
    {
        goto BbeDl;
        BbeDl:
        switch ($this->status) {
            case QUh2VVA2TE5xx::UPLOADING:
                return QUh2VVA2TE5xx::UPLOADED == $ZJBuU || QUh2VVA2TE5xx::UPLOADING == $ZJBuU || QUh2VVA2TE5xx::ABORTED == $ZJBuU;
            case QUh2VVA2TE5xx::UPLOADED:
                return QUh2VVA2TE5xx::PROCESSING == $ZJBuU || QUh2VVA2TE5xx::DELETED == $ZJBuU;
            case QUh2VVA2TE5xx::PROCESSING:
                return in_array($ZJBuU, [QUh2VVA2TE5xx::WATERMARK_PROCESSED, QUh2VVA2TE5xx::THUMBNAIL_PROCESSED, QUh2VVA2TE5xx::ENCODING_PROCESSED, QUh2VVA2TE5xx::ENCODING_ERROR, QUh2VVA2TE5xx::BLUR_PROCESSED, QUh2VVA2TE5xx::DELETED, QUh2VVA2TE5xx::FINISHED, QUh2VVA2TE5xx::PROCESSING]);
            case QUh2VVA2TE5xx::FINISHED:
            case QUh2VVA2TE5xx::ABORTED:
                return QUh2VVA2TE5xx::DELETED == $ZJBuU;
            case QUh2VVA2TE5xx::ENCODING_PROCESSED:
                return QUh2VVA2TE5xx::FINISHED == $ZJBuU || QUh2VVA2TE5xx::DELETED == $ZJBuU;
            default:
                return false;
        }
        goto jpd55;
        jpd55:
        OKKpi:
        goto wR6Gc;
        wR6Gc:
        JUBsT:
        goto wKRuc;
        wKRuc:
    }
    public function m3FXSxRxwBi(Fg5ZctnJZvYzy $Iv7zH)
    {
        $this->KxYJd[] = $Iv7zH;
    }
}
