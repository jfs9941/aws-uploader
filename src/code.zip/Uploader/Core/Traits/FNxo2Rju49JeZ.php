<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\S6ysKpQv89ofz;
use Jfs\Uploader\Core\TmESz0lUHO033;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
trait FNxo2Rju49JeZ
{
    private $LXD2P;
    private $qZpgF;
    private $X7RRG;
    public function mLypJLcFD97() : string
    {
        return S6ysKpQv89ofz::mttkCSEeOLf($this->LXD2P->getFilename());
    }
    public function miyJ5feZwpY() : S6ysKpQv89ofz
    {
        goto TWxf_;
        FNinY:
        return $this->qZpgF;
        goto aEo01;
        rg0TY:
        $this->mhW2MyKimam();
        goto NMA2h;
        TWxf_:
        if (!(null !== $this->qZpgF)) {
            goto ajpBj;
        }
        goto FNinY;
        NMA2h:
        return $this->qZpgF;
        goto Wkvrx;
        aEo01:
        ajpBj:
        goto rg0TY;
        Wkvrx:
    }
    private function mhW2MyKimam() : TmESz0lUHO033
    {
        goto IrC2O;
        ffevD:
        $this->qZpgF = S6ysKpQv89ofz::mAWFJTfrz4l($TmbpH);
        goto JEmLW;
        w3Rqy:
        $TmbpH = json_decode($s7zCu, true);
        goto ffevD;
        JEmLW:
        return $this;
        goto oM7b8;
        yywTi:
        throw new DS3DIAJ2eyUA5("File {$this->LXD2P->getFilename()} is not PreSigned upload");
        goto dv0S9;
        IrC2O:
        $s7zCu = $this->X7RRG->get($this->mLypJLcFD97());
        goto M6lsX;
        M6lsX:
        if (!$s7zCu) {
            goto bO1jz;
        }
        goto w3Rqy;
        oM7b8:
        bO1jz:
        goto yywTi;
        dv0S9:
    }
    public function mjFzSbhVEvi($EeQqP, $cEc93, $Uz2J3, $ZbwDh, $WBtzJ, $WCiFa = 's3') : void
    {
        $this->qZpgF = S6ysKpQv89ofz::mZQ1mhapiPb($this->LXD2P, $EeQqP, $cEc93, $WBtzJ, $Uz2J3, $ZbwDh, $WCiFa);
    }
}
