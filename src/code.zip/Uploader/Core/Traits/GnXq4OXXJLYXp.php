<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\P7eZRarQfx9Id;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Exception\SwRmuIL9tuB7h;
trait GnXq4OXXJLYXp
{
    private $Yii2F = [];
    public function mnZV8lryeWr($vqPY2)
    {
        goto TZrfa;
        mPJK0:
        goto rhYbl;
        goto PUESV;
        PA2bp:
        $this->setAttribute('status', $vqPY2);
        goto AeYjw;
        PUESV:
        ncnQx:
        goto PA2bp;
        NYLSs:
        $this->status = $vqPY2;
        goto mPJK0;
        TZrfa:
        if ($this instanceof Model) {
            goto ncnQx;
        }
        goto NYLSs;
        AeYjw:
        rhYbl:
        goto hOhCl;
        hOhCl:
    }
    public function m7gMMC7rySi()
    {
        goto hkrMm;
        a9VuZ:
        zvuZO:
        goto SNozM;
        hkrMm:
        if (!$this instanceof Model) {
            goto zvuZO;
        }
        goto x8WMj;
        x8WMj:
        return $this->getAttribute('status');
        goto a9VuZ;
        SNozM:
        return $this->status;
        goto qpbJd;
        qpbJd:
    }
    public function mTKyaraJgz7($VBB0y)
    {
        goto qU0Wn;
        T9kcD:
        YIatp:
        goto kYwiB;
        S9KPK:
        cLrZl:
        goto n_HtS;
        qU0Wn:
        if ($this->mvZTZMNfb23($VBB0y)) {
            goto wPhl3;
        }
        goto avJo4;
        ZfDdg:
        $qnrt0 = $this->m7gMMC7rySi();
        goto z2Vry;
        mU5t2:
        foreach ($this->Yii2F as $nJpMn) {
            $nJpMn->m85MtNrnQlN($qnrt0, $VBB0y);
            R3m62:
        }
        goto S9KPK;
        kYwiB:
        $this->setAttribute('status', $VBB0y);
        goto apndA;
        jdgJT:
        wPhl3:
        goto ZfDdg;
        QFxTa:
        $this->status = $VBB0y;
        goto lm01Q;
        apndA:
        uYRCR:
        goto mU5t2;
        z2Vry:
        if ($this instanceof Model) {
            goto YIatp;
        }
        goto QFxTa;
        avJo4:
        throw SwRmuIL9tuB7h::mCPjQJhnuDI($this->id ?? 'unknown', $this->m7gMMC7rySi(), $VBB0y);
        goto jdgJT;
        lm01Q:
        goto uYRCR;
        goto T9kcD;
        n_HtS:
    }
    public function mvZTZMNfb23($VBB0y)
    {
        goto WL1GA;
        ln6R_:
        MEL2f:
        goto WVRL6;
        WL1GA:
        switch ($this->status) {
            case UimQKBIuLCEAO::UPLOADING:
                return UimQKBIuLCEAO::UPLOADED == $VBB0y || UimQKBIuLCEAO::UPLOADING == $VBB0y || UimQKBIuLCEAO::ABORTED == $VBB0y;
            case UimQKBIuLCEAO::UPLOADED:
                return UimQKBIuLCEAO::PROCESSING == $VBB0y || UimQKBIuLCEAO::DELETED == $VBB0y;
            case UimQKBIuLCEAO::PROCESSING:
                return in_array($VBB0y, [UimQKBIuLCEAO::WATERMARK_PROCESSED, UimQKBIuLCEAO::THUMBNAIL_PROCESSED, UimQKBIuLCEAO::ENCODING_PROCESSED, UimQKBIuLCEAO::ENCODING_ERROR, UimQKBIuLCEAO::BLUR_PROCESSED, UimQKBIuLCEAO::DELETED, UimQKBIuLCEAO::FINISHED, UimQKBIuLCEAO::PROCESSING]);
            case UimQKBIuLCEAO::FINISHED:
            case UimQKBIuLCEAO::ABORTED:
                return UimQKBIuLCEAO::DELETED == $VBB0y;
            case UimQKBIuLCEAO::ENCODING_PROCESSED:
                return UimQKBIuLCEAO::FINISHED == $VBB0y || UimQKBIuLCEAO::DELETED == $VBB0y;
            default:
                return false;
        }
        goto ln6R_;
        WVRL6:
        Y5jcj:
        goto aXLpw;
        aXLpw:
    }
    public function mxt7Kk7QeSS(P7eZRarQfx9Id $nJpMn)
    {
        $this->Yii2F[] = $nJpMn;
    }
}
