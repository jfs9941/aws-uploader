<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\A4nixFDruB7ul;
use Jfs\Uploader\Core\Hm5kuVZJdTKtj;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
trait RIWOC6w2gQhJW
{
    private $EidfR;
    private $Q9N_W;
    private $i9lKp;
    public function mwdQ1fTd3zq() : string
    {
        return A4nixFDruB7ul::msagmj6oOxB($this->EidfR->getFilename());
    }
    public function mFV2s6jujmR() : A4nixFDruB7ul
    {
        goto mJ053;
        mJ053:
        if (!(null !== $this->Q9N_W)) {
            goto IGzzh;
        }
        goto lO2wO;
        Y2v67:
        IGzzh:
        goto f2PQK;
        LuhTg:
        return $this->Q9N_W;
        goto DFCpL;
        f2PQK:
        $this->mB6MUhGhdzp();
        goto LuhTg;
        lO2wO:
        return $this->Q9N_W;
        goto Y2v67;
        DFCpL:
    }
    private function mB6MUhGhdzp() : Hm5kuVZJdTKtj
    {
        goto arReg;
        H52gU:
        y5yxc:
        goto USOWK;
        AODfj:
        return $this;
        goto H52gU;
        arReg:
        $l663A = $this->i9lKp->get($this->mwdQ1fTd3zq());
        goto Bma8A;
        iVamZ:
        $this->Q9N_W = A4nixFDruB7ul::mLrSDOhfwrg($QfMl1);
        goto AODfj;
        Bma8A:
        if (!$l663A) {
            goto y5yxc;
        }
        goto FtZdG;
        USOWK:
        throw new LFhGkQpjCxWvG("File {$this->EidfR->getFilename()} is not PreSigned upload");
        goto uFXNp;
        FtZdG:
        $QfMl1 = json_decode($l663A, true);
        goto iVamZ;
        uFXNp:
    }
    public function mxxDjrcKeAD($usaAM, $FgABw, $N70qa, $mCZQS, $IQBpu, $sjEM3 = 's3') : void
    {
        $this->Q9N_W = A4nixFDruB7ul::mXvT1oq5cbb($this->EidfR, $usaAM, $FgABw, $IQBpu, $N70qa, $mCZQS, $sjEM3);
    }
}
