<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait ST5539UqFnRNg
{
    private function muMCM9fiDza(string $QZS56) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $QZS56]));
    }
}
