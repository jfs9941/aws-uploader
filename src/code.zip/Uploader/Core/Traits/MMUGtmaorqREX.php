<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\RoTpJhiFhvlTg;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Exception\J0z9iIrDgeD3q;
trait MMUGtmaorqREX
{
    private $cfU8g = [];
    public function m3zp1EoQeXc($Z7ZNw)
    {
        goto eBeC1;
        ql3GJ:
        goto GAXkz;
        goto HHTrl;
        HHTrl:
        Mf152:
        goto w80yS;
        w80yS:
        $this->setAttribute('status', $Z7ZNw);
        goto TTB9O;
        YeKn6:
        $this->status = $Z7ZNw;
        goto ql3GJ;
        eBeC1:
        if ($this instanceof Model) {
            goto Mf152;
        }
        goto YeKn6;
        TTB9O:
        GAXkz:
        goto haN2L;
        haN2L:
    }
    public function m01hr3e5beG()
    {
        goto mgdc8;
        mgdc8:
        if (!$this instanceof Model) {
            goto PyD4J;
        }
        goto X7wt6;
        X7wt6:
        return $this->getAttribute('status');
        goto s_3mV;
        BUNdd:
        return $this->status;
        goto NGUvk;
        s_3mV:
        PyD4J:
        goto BUNdd;
        NGUvk:
    }
    public function mGQfJhYWpvR($fF5wM)
    {
        goto q8IXd;
        h8BiR:
        foreach ($this->cfU8g as $cWNSO) {
            $cWNSO->mM5x0654DhR($DIWvC, $fF5wM);
            VlhY2:
        }
        goto Kn251;
        q8IXd:
        if ($this->mE2Ndk2lqWA($fF5wM)) {
            goto uuV5q;
        }
        goto fgqLi;
        KbNnm:
        uuV5q:
        goto pQw_I;
        A3Xwx:
        if ($this instanceof Model) {
            goto TTANQ;
        }
        goto rafM9;
        pQw_I:
        $DIWvC = $this->m01hr3e5beG();
        goto A3Xwx;
        rafM9:
        $this->status = $fF5wM;
        goto hJue1;
        fgqLi:
        throw J0z9iIrDgeD3q::muLvIqLxlsH($this->id ?? 'unknown', $this->m01hr3e5beG(), $fF5wM);
        goto KbNnm;
        hJue1:
        goto XFuIH;
        goto AQq9t;
        pDxp4:
        $this->setAttribute('status', $fF5wM);
        goto cKPJZ;
        cKPJZ:
        XFuIH:
        goto h8BiR;
        AQq9t:
        TTANQ:
        goto pDxp4;
        Kn251:
        hAbq7:
        goto i42Z4;
        i42Z4:
    }
    public function mE2Ndk2lqWA($fF5wM)
    {
        goto oHmRi;
        pLwaQ:
        gLc2a:
        goto lP1fR;
        q3wcI:
        PayFT:
        goto pLwaQ;
        oHmRi:
        switch ($this->status) {
            case RwOJkCXwa9RQz::UPLOADING:
                return RwOJkCXwa9RQz::UPLOADED == $fF5wM || RwOJkCXwa9RQz::UPLOADING == $fF5wM || RwOJkCXwa9RQz::ABORTED == $fF5wM;
            case RwOJkCXwa9RQz::UPLOADED:
                return RwOJkCXwa9RQz::PROCESSING == $fF5wM || RwOJkCXwa9RQz::DELETED == $fF5wM;
            case RwOJkCXwa9RQz::PROCESSING:
                return in_array($fF5wM, [RwOJkCXwa9RQz::WATERMARK_PROCESSED, RwOJkCXwa9RQz::THUMBNAIL_PROCESSED, RwOJkCXwa9RQz::ENCODING_PROCESSED, RwOJkCXwa9RQz::ENCODING_ERROR, RwOJkCXwa9RQz::BLUR_PROCESSED, RwOJkCXwa9RQz::DELETED, RwOJkCXwa9RQz::FINISHED, RwOJkCXwa9RQz::PROCESSING]);
            case RwOJkCXwa9RQz::FINISHED:
            case RwOJkCXwa9RQz::ABORTED:
                return RwOJkCXwa9RQz::DELETED == $fF5wM;
            case RwOJkCXwa9RQz::ENCODING_PROCESSED:
                return RwOJkCXwa9RQz::FINISHED == $fF5wM || RwOJkCXwa9RQz::DELETED == $fF5wM;
            default:
                return false;
        }
        goto q3wcI;
        lP1fR:
    }
    public function mqyYIlRyjYD(RoTpJhiFhvlTg $cWNSO)
    {
        $this->cfU8g[] = $cWNSO;
    }
}
