<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\ASReQHmrabNfg;
use Jfs\Uploader\Core\T9ZXYI5O5GjGl;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
trait UPFKyMg91hBqR
{
    private $AO_te;
    private $iTEew;
    private $LuJWw;
    public function mGsd4uDsuKt() : string
    {
        return ASReQHmrabNfg::mDgt4KXkAWr($this->AO_te->getFilename());
    }
    public function mew8rrjhK4U() : ASReQHmrabNfg
    {
        goto hpPKD;
        hpPKD:
        if (!(null !== $this->iTEew)) {
            goto TwQKF;
        }
        goto smphw;
        Fy8U2:
        $this->mXcwNN708YR();
        goto H3IZF;
        H3IZF:
        return $this->iTEew;
        goto d1fSP;
        smphw:
        return $this->iTEew;
        goto QWLeP;
        QWLeP:
        TwQKF:
        goto Fy8U2;
        d1fSP:
    }
    private function mXcwNN708YR() : T9ZXYI5O5GjGl
    {
        goto Lgujk;
        FkWIp:
        if (!$SHuT1) {
            goto V94Ka;
        }
        goto YIx5V;
        MtK78:
        return $this;
        goto qmkSW;
        qmkSW:
        V94Ka:
        goto CNHJN;
        YFyVk:
        $this->iTEew = ASReQHmrabNfg::mpB82YDKVIN($wa_66);
        goto MtK78;
        CNHJN:
        throw new OK51HRfKr7bLh("File {$this->AO_te->getFilename()} is not PreSigned upload");
        goto k7LYo;
        YIx5V:
        $wa_66 = json_decode($SHuT1, true);
        goto YFyVk;
        Lgujk:
        $SHuT1 = $this->LuJWw->get($this->mGsd4uDsuKt());
        goto FkWIp;
        k7LYo:
    }
    public function mF6PC7tYEYz($Vrpla, $NQRMF, $HZVGD, $GzTUV, $UVY53, $yXj4Q = 's3') : void
    {
        $this->iTEew = ASReQHmrabNfg::mJStkQvbmu8($this->AO_te, $Vrpla, $NQRMF, $UVY53, $HZVGD, $GzTUV, $yXj4Q);
    }
}
