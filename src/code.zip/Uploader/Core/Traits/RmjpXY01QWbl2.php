<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\F66VaMRGSfxoM;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Exception\KVgPdowMikNnK;
trait RmjpXY01QWbl2
{
    private $PdEXo = [];
    public function mkv7RuyOFPh($Qm3Xo)
    {
        goto FuN4O;
        tkHJg:
        dWmQH:
        goto vU2EJ;
        gCkxq:
        $this->setAttribute('status', $Qm3Xo);
        goto tkHJg;
        tZ5Wu:
        $this->status = $Qm3Xo;
        goto qqmCG;
        FuN4O:
        if ($this instanceof Model) {
            goto V_FWp;
        }
        goto tZ5Wu;
        Y3Uss:
        V_FWp:
        goto gCkxq;
        qqmCG:
        goto dWmQH;
        goto Y3Uss;
        vU2EJ:
    }
    public function mnTygRN8xMs()
    {
        goto wHtAD;
        lzOW8:
        uKodx:
        goto znuL_;
        wHtAD:
        if (!$this instanceof Model) {
            goto uKodx;
        }
        goto bb0cd;
        znuL_:
        return $this->status;
        goto b7m2A;
        bb0cd:
        return $this->getAttribute('status');
        goto lzOW8;
        b7m2A:
    }
    public function mY8gUThQFjU($f40nf)
    {
        goto nGynn;
        xhkKs:
        throw KVgPdowMikNnK::mCLtInp7skF($this->id ?? 'unknown', $this->mnTygRN8xMs(), $f40nf);
        goto NlL3E;
        W9J7z:
        wqKgb:
        goto O8ouG;
        NlL3E:
        CRYKi:
        goto FV910;
        nGynn:
        if ($this->mVt3TUg4ptP($f40nf)) {
            goto CRYKi;
        }
        goto xhkKs;
        H_04g:
        goto pMzLn;
        goto W9J7z;
        bwgVn:
        pMzLn:
        goto b5SND;
        i5NCi:
        uM3va:
        goto cQm_T;
        b5SND:
        foreach ($this->PdEXo as $KW__u) {
            $KW__u->mSg4ZNxGqnf($YiZHw, $f40nf);
            j0gFL:
        }
        goto i5NCi;
        Iazps:
        if ($this instanceof Model) {
            goto wqKgb;
        }
        goto PIcPC;
        FV910:
        $YiZHw = $this->mnTygRN8xMs();
        goto Iazps;
        O8ouG:
        $this->setAttribute('status', $f40nf);
        goto bwgVn;
        PIcPC:
        $this->status = $f40nf;
        goto H_04g;
        cQm_T:
    }
    public function mVt3TUg4ptP($f40nf)
    {
        goto Vu0b9;
        HT_7B:
        zFbld:
        goto kuybD;
        KwUhh:
        jTvIM:
        goto HT_7B;
        Vu0b9:
        switch ($this->status) {
            case EPmxqTVp5luXc::UPLOADING:
                return EPmxqTVp5luXc::UPLOADED == $f40nf || EPmxqTVp5luXc::UPLOADING == $f40nf || EPmxqTVp5luXc::ABORTED == $f40nf;
            case EPmxqTVp5luXc::UPLOADED:
                return EPmxqTVp5luXc::PROCESSING == $f40nf || EPmxqTVp5luXc::DELETED == $f40nf;
            case EPmxqTVp5luXc::PROCESSING:
                return in_array($f40nf, [EPmxqTVp5luXc::WATERMARK_PROCESSED, EPmxqTVp5luXc::THUMBNAIL_PROCESSED, EPmxqTVp5luXc::ENCODING_PROCESSED, EPmxqTVp5luXc::ENCODING_ERROR, EPmxqTVp5luXc::BLUR_PROCESSED, EPmxqTVp5luXc::DELETED, EPmxqTVp5luXc::FINISHED, EPmxqTVp5luXc::PROCESSING]);
            case EPmxqTVp5luXc::FINISHED:
            case EPmxqTVp5luXc::ABORTED:
                return EPmxqTVp5luXc::DELETED == $f40nf;
            case EPmxqTVp5luXc::ENCODING_PROCESSED:
                return EPmxqTVp5luXc::FINISHED == $f40nf || EPmxqTVp5luXc::DELETED == $f40nf;
            default:
                return false;
        }
        goto KwUhh;
        kuybD:
    }
    public function mcp2uALDwNg(F66VaMRGSfxoM $KW__u)
    {
        $this->PdEXo[] = $KW__u;
    }
}
