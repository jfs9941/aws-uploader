<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Hj8CabiR8LqsR;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Exception\CIAjwsRYu6S6e;
use Illuminate\Database\Eloquent\Model;
trait W8XZSueQaszDJ
{
    private $P53lE = [];
    public function mdMI6wvUXmN($SJFJj)
    {
        goto ZC4w7;
        jDirC:
        goto RTxvV;
        goto ZDjEJ;
        ZDjEJ:
        tGSdb:
        goto ICB4o;
        ICB4o:
        $this->setAttribute('status', $SJFJj);
        goto Fjvwh;
        ZC4w7:
        if ($this instanceof Model) {
            goto tGSdb;
        }
        goto HCiKn;
        HCiKn:
        $this->status = $SJFJj;
        goto jDirC;
        Fjvwh:
        RTxvV:
        goto RwY62;
        RwY62:
    }
    public function me5F3GuvsnI()
    {
        goto S8DLu;
        U5S4g:
        oa63_:
        goto iU6AZ;
        iU6AZ:
        return $this->status;
        goto F7pcG;
        S8DLu:
        if (!$this instanceof Model) {
            goto oa63_;
        }
        goto w1fiZ;
        w1fiZ:
        return $this->getAttribute('status');
        goto U5S4g;
        F7pcG:
    }
    public function m1WocvV9yZy($acaP_)
    {
        goto ma6vN;
        N9I_W:
        XvMdc:
        goto zV_CX;
        KupX5:
        throw CIAjwsRYu6S6e::mNlhDLGQePH($this->id ?? 'unknown', $this->me5F3GuvsnI(), $acaP_);
        goto N9I_W;
        hHO61:
        foreach ($this->P53lE as $DlBRz) {
            $DlBRz->mGYJEzjTKty($CUTLh, $acaP_);
            ctCKv:
        }
        goto id8R7;
        id8R7:
        wTz0q:
        goto aNNeg;
        ls8wx:
        UXIkA:
        goto hHO61;
        OGsZs:
        $this->status = $acaP_;
        goto ghwEX;
        h4p4F:
        $this->setAttribute('status', $acaP_);
        goto ls8wx;
        gUEiy:
        if ($this instanceof Model) {
            goto o0Ru7;
        }
        goto OGsZs;
        PnxCd:
        o0Ru7:
        goto h4p4F;
        zV_CX:
        $CUTLh = $this->me5F3GuvsnI();
        goto gUEiy;
        ma6vN:
        if ($this->mJkT9dPY2jE($acaP_)) {
            goto XvMdc;
        }
        goto KupX5;
        ghwEX:
        goto UXIkA;
        goto PnxCd;
        aNNeg:
    }
    public function mJkT9dPY2jE($acaP_)
    {
        goto cbvpV;
        cbvpV:
        switch ($this->status) {
            case A7CVlqbpzhfLD::UPLOADING:
                return A7CVlqbpzhfLD::UPLOADED == $acaP_ || A7CVlqbpzhfLD::UPLOADING == $acaP_ || A7CVlqbpzhfLD::ABORTED == $acaP_;
            case A7CVlqbpzhfLD::UPLOADED:
                return A7CVlqbpzhfLD::PROCESSING == $acaP_ || A7CVlqbpzhfLD::DELETED == $acaP_;
            case A7CVlqbpzhfLD::PROCESSING:
                return in_array($acaP_, [A7CVlqbpzhfLD::WATERMARK_PROCESSED, A7CVlqbpzhfLD::THUMBNAIL_PROCESSED, A7CVlqbpzhfLD::ENCODING_PROCESSED, A7CVlqbpzhfLD::ENCODING_ERROR, A7CVlqbpzhfLD::BLUR_PROCESSED, A7CVlqbpzhfLD::DELETED, A7CVlqbpzhfLD::FINISHED, A7CVlqbpzhfLD::PROCESSING]);
            case A7CVlqbpzhfLD::FINISHED:
            case A7CVlqbpzhfLD::ABORTED:
                return A7CVlqbpzhfLD::DELETED == $acaP_;
            case A7CVlqbpzhfLD::ENCODING_PROCESSED:
                return A7CVlqbpzhfLD::FINISHED == $acaP_ || A7CVlqbpzhfLD::DELETED == $acaP_;
            default:
                return false;
        }
        goto N8MSf;
        N8MSf:
        RJHnc:
        goto tx0As;
        tx0As:
        U33XB:
        goto vzFQu;
        vzFQu:
    }
    public function mPs1JYkvGIi(Hj8CabiR8LqsR $DlBRz)
    {
        $this->P53lE[] = $DlBRz;
    }
}
