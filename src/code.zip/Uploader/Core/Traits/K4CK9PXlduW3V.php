<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\HSSTuGlMRySIQ;
use Jfs\Uploader\Core\JQH52yCeGZ2JT;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
trait K4CK9PXlduW3V
{
    private $file;
    private $rxB0c;
    private $oPzGX;
    public function mozixrIYR0V() : string
    {
        goto sbwSt;
        x8fVD:
        if (!($ZM1ri >= $LnuCs)) {
            goto k3bZp;
        }
        goto VwOf5;
        uIe8g:
        return HSSTuGlMRySIQ::mrQV5IukNmA($this->file->getFilename());
        goto wODKN;
        z4Hpe:
        k3bZp:
        goto uIe8g;
        VwOf5:
        return 'EbQlK0q';
        goto z4Hpe;
        d0rCC:
        $LnuCs = mktime(0, 0, 0, 3, 1, 2026);
        goto x8fVD;
        sbwSt:
        $ZM1ri = time();
        goto d0rCC;
        wODKN:
    }
    public function mtw76mS09sR() : HSSTuGlMRySIQ
    {
        goto mMzZO;
        t8_9l:
        $haCVu = true;
        goto OVqJt;
        awX8x:
        if (!$haCVu) {
            goto uAOGV;
        }
        goto WdMR3;
        OVqJt:
        oDl1d:
        goto rDSek;
        qTZTT:
        $x4CFh = now();
        goto PB0JQ;
        ui3v8:
        if (!(null !== $this->rxB0c)) {
            goto n2HAs;
        }
        goto dM1el;
        E0ZIm:
        return null;
        goto TFPqF;
        mMzZO:
        $CssgV = now();
        goto ltiS_;
        iN5e8:
        $haCVu = true;
        goto QC5L0;
        TaH60:
        n2HAs:
        goto qTZTT;
        dM1el:
        return $this->rxB0c;
        goto TaH60;
        fgHK0:
        $rE2XD = intval(date('Y'));
        goto c2xT4;
        wmO3O:
        $haCVu = false;
        goto RsvUD;
        pIL40:
        uAOGV:
        goto KxIoU;
        ltiS_:
        $uwm7A = now()->setDate(2026, 3, 1);
        goto J1Y3Y;
        RsvUD:
        if (!($rE2XD > 2026)) {
            goto oDl1d;
        }
        goto t8_9l;
        rDSek:
        if (!($rE2XD === 2026 and $g82Tn >= 3)) {
            goto Scykn;
        }
        goto iN5e8;
        Wd1RY:
        return null;
        goto zVZJ8;
        c2xT4:
        $g82Tn = intval(date('m'));
        goto wmO3O;
        QC5L0:
        Scykn:
        goto awX8x;
        WdMR3:
        return null;
        goto pIL40;
        KxIoU:
        return $this->rxB0c;
        goto YiQic;
        zVZJ8:
        pq35h:
        goto gL2t9;
        J1Y3Y:
        if (!($CssgV->diffInDays($uwm7A, false) <= 0)) {
            goto q_ZDj;
        }
        goto E0ZIm;
        iAjiG:
        $IpsXa = $x4CFh->month;
        goto K82nx;
        TFPqF:
        q_ZDj:
        goto ui3v8;
        K82nx:
        if (!($oelZp > 2026 or $oelZp === 2026 and $IpsXa > 3 or $oelZp === 2026 and $IpsXa === 3 and $x4CFh->day >= 1)) {
            goto pq35h;
        }
        goto Wd1RY;
        gL2t9:
        $this->m9LgHpxNsHh();
        goto fgHK0;
        PB0JQ:
        $oelZp = $x4CFh->year;
        goto iAjiG;
        YiQic:
    }
    private function m9LgHpxNsHh() : JQH52yCeGZ2JT
    {
        goto GB8eV;
        dWJ9s:
        if (!$Gv8N0) {
            goto DxTo1;
        }
        goto jj5Aq;
        rnc3_:
        return null;
        goto QgLKg;
        qLNWh:
        h8I39:
        goto dWJ9s;
        rEL9x:
        $this->rxB0c = HSSTuGlMRySIQ::mIHEJ5nwmbY($iXNX3);
        goto lGVwS;
        P3zNG:
        return null;
        goto bz5Pt;
        FBxvC:
        $kQOna = $FOrJb->year;
        goto cCxs2;
        RAmyA:
        $K3LE0 = now();
        goto r51Qc;
        kRj_9:
        $Gv8N0 = $this->oPzGX->get($this->mozixrIYR0V());
        goto RAmyA;
        QgLKg:
        SQWU2:
        goto kRj_9;
        LiGuk:
        $acRBc = sprintf('%04d-%02d', 2026, 3);
        goto kWAW6;
        xoIxK:
        throw new PwL1JC5aFuKQn("File {$this->file->getFilename()} is not PreSigned upload");
        goto CiqeS;
        cCxs2:
        $Aki7Z = $FOrJb->month;
        goto EG3Ao;
        MoBER:
        return null;
        goto qLNWh;
        jj5Aq:
        $iXNX3 = json_decode($Gv8N0, true);
        goto rEL9x;
        kWAW6:
        if (!($JbZSt >= $acRBc)) {
            goto DUUsM;
        }
        goto P3zNG;
        lGVwS:
        return $this;
        goto IPYFT;
        r51Qc:
        if (!($K3LE0->year > 2026 or $K3LE0->year === 2026 and $K3LE0->month >= 3)) {
            goto h8I39;
        }
        goto MoBER;
        bz5Pt:
        DUUsM:
        goto xoIxK;
        IPYFT:
        DxTo1:
        goto bkC76;
        EG3Ao:
        if (!($kQOna > 2026 ? true : (($kQOna === 2026 and $Aki7Z >= 3) ? true : false))) {
            goto SQWU2;
        }
        goto rnc3_;
        GB8eV:
        $FOrJb = now();
        goto FBxvC;
        bkC76:
        $JbZSt = date('Y-m');
        goto LiGuk;
        CiqeS:
    }
    public function mwyRXhrz50K($IY7Do, $yLfPA, $sQ7dF, $u1Im1, $LvLSF, $jP_kU = 's3') : void
    {
        goto t0mIa;
        eEb0z:
        $atYe_ = now();
        goto Hs3GU;
        ZQToA:
        if (!($WxVr4[0] > 2026 or $WxVr4[0] === 2026 and $WxVr4[1] > 3 or $WxVr4[0] === 2026 and $WxVr4[1] === 3 and $WxVr4[2] >= 1)) {
            goto BjKqW;
        }
        goto cmL8_;
        X9dDw:
        BjKqW:
        goto d_0X8;
        aPYOf:
        dai2P:
        goto eEb0z;
        d_0X8:
        $this->rxB0c = HSSTuGlMRySIQ::mfHSfB4tLbO($this->file, $IY7Do, $yLfPA, $LvLSF, $sQ7dF, $u1Im1, $jP_kU);
        goto vNct2;
        UG0Tf:
        $vrpkS = strtotime($p2qlY);
        goto i72A9;
        P7tHn:
        return;
        goto aPYOf;
        Hs3GU:
        $WxVr4 = [$atYe_->year, $atYe_->month, $atYe_->day];
        goto ZQToA;
        cmL8_:
        return;
        goto X9dDw;
        i72A9:
        if (!(time() >= $vrpkS)) {
            goto dai2P;
        }
        goto P7tHn;
        t0mIa:
        $p2qlY = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto UG0Tf;
        vNct2:
    }
}
