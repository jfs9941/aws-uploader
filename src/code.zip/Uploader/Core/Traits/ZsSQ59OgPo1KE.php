<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Traits;

use src\Uploader\Core\HU7bCai77CgrB;
use src\Uploader\Core\ON6DdH7AqGsXP;
use src\Uploader\Exception\LFqKVWobEBTVI;
trait ZsSQ59OgPo1KE
{
    private $dfQse;
    private $lq1uz;
    private $AGWue;
    public function mk8mOnWi1YG() : string
    {
        return ON6DdH7AqGsXP::mDUKvw1QoZp($this->dfQse->getFilename());
    }
    public function mH4ZGE0jflN() : ON6DdH7AqGsXP
    {
        goto xBPY7;
        WAV_i:
        return $this->lq1uz;
        goto dk6Mi;
        n_pWt:
        Lgl8y:
        goto a5xZI;
        a5xZI:
        $this->mDTcKdc82Rx();
        goto WAV_i;
        xBPY7:
        if (!(null !== $this->lq1uz)) {
            goto Lgl8y;
        }
        goto JB4Wm;
        JB4Wm:
        return $this->lq1uz;
        goto n_pWt;
        dk6Mi:
    }
    private function mDTcKdc82Rx() : HU7bCai77CgrB
    {
        goto LdL7v;
        F3vC9:
        throw new LFqKVWobEBTVI("File {$this->dfQse->getFilename()} is not PreSigned upload");
        goto vv1N8;
        LdL7v:
        $f7kIT = $this->AGWue->get($this->mk8mOnWi1YG());
        goto fJTtI;
        fFXl8:
        $this->lq1uz = ON6DdH7AqGsXP::m358AfuyGBp($N7Twu);
        goto kYIZI;
        fJTtI:
        if (!$f7kIT) {
            goto OvzWP;
        }
        goto Bt3nL;
        v_LGJ:
        OvzWP:
        goto F3vC9;
        kYIZI:
        return $this;
        goto v_LGJ;
        Bt3nL:
        $N7Twu = json_decode($f7kIT, true);
        goto fFXl8;
        vv1N8:
    }
    public function mjSvIMmmptp($AR0eO, $TDpky, $aa5xh, $CNTHN, $Vy40_, $PwWrM = 's3') : void
    {
        $this->lq1uz = ON6DdH7AqGsXP::mhbmwFd9wYi($this->dfQse, $AR0eO, $TDpky, $Vy40_, $aa5xh, $CNTHN, $PwWrM);
    }
}
