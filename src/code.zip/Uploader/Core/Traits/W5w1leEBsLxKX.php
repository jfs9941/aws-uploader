<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\BnU61laaiajX2;
use Jfs\Uploader\Core\DXmfT6CslVApB;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
trait W5w1leEBsLxKX
{
    private $PxcXo;
    private $DjlwB;
    private $Sdc_x;
    public function m8dpLxHLm9b() : string
    {
        return BnU61laaiajX2::mqdgOOZkBS0($this->PxcXo->getFilename());
    }
    public function m6oz0N1G29M() : BnU61laaiajX2
    {
        goto E3vKQ;
        GWB54:
        Y0q_P:
        goto h4Ygh;
        j65Y7:
        return $this->DjlwB;
        goto GWB54;
        h4Ygh:
        $this->mWWtXtQjBQC();
        goto THWWr;
        THWWr:
        return $this->DjlwB;
        goto ToLhH;
        E3vKQ:
        if (!(null !== $this->DjlwB)) {
            goto Y0q_P;
        }
        goto j65Y7;
        ToLhH:
    }
    private function mWWtXtQjBQC() : DXmfT6CslVApB
    {
        goto J24z6;
        J24z6:
        $CzjeJ = $this->Sdc_x->get($this->m8dpLxHLm9b());
        goto BcaB1;
        BszEg:
        kDd7e:
        goto Nfroi;
        V2lXm:
        return $this;
        goto BszEg;
        gt5GJ:
        $this->DjlwB = BnU61laaiajX2::md0HuJkhQJi($dtVbl);
        goto V2lXm;
        Pd1cC:
        $dtVbl = json_decode($CzjeJ, true);
        goto gt5GJ;
        BcaB1:
        if (!$CzjeJ) {
            goto kDd7e;
        }
        goto Pd1cC;
        Nfroi:
        throw new NaLxNTATn0Ubr("File {$this->PxcXo->getFilename()} is not PreSigned upload");
        goto JB_rh;
        JB_rh:
    }
    public function mh4ISMbiacT($naawS, $YftSz, $lYoIc, $nfF1l, $W7h0k, $Zqemz = 's3') : void
    {
        $this->DjlwB = BnU61laaiajX2::mTtDhdxq3zH($this->PxcXo, $naawS, $YftSz, $W7h0k, $lYoIc, $nfF1l, $Zqemz);
    }
}
