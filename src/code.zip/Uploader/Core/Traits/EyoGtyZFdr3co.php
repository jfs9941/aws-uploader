<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\Z4Tul5rPROvzh;
use Jfs\Uploader\Core\Q4cNg0cF0Oivx;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
trait EyoGtyZFdr3co
{
    private $Suzy5;
    private $Vr4oM;
    private $erfSo;
    public function m0q4dteLZ4Y() : string
    {
        return Z4Tul5rPROvzh::mAcNlszMlxW($this->Suzy5->getFilename());
    }
    public function mjt4KTTPlCK() : Z4Tul5rPROvzh
    {
        goto coVHJ;
        bk071:
        return $this->Vr4oM;
        goto uI010;
        coVHJ:
        if (!(null !== $this->Vr4oM)) {
            goto g0Uh4;
        }
        goto bk071;
        uI010:
        g0Uh4:
        goto fgdd3;
        JaqgP:
        return $this->Vr4oM;
        goto VgJ5g;
        fgdd3:
        $this->mTu77EpVWgl();
        goto JaqgP;
        VgJ5g:
    }
    private function mTu77EpVWgl() : Q4cNg0cF0Oivx
    {
        goto R3hVn;
        n9d6Z:
        return $this;
        goto RxVFt;
        rMBZ0:
        throw new OLKFtR17budEQ("File {$this->Suzy5->getFilename()} is not PreSigned upload");
        goto OeHe1;
        xrxxj:
        $this->Vr4oM = Z4Tul5rPROvzh::mOmCqxONM2r($CU2Co);
        goto n9d6Z;
        Keewd:
        $CU2Co = json_decode($C60Fy, true);
        goto xrxxj;
        R3hVn:
        $C60Fy = $this->erfSo->get($this->m0q4dteLZ4Y());
        goto yrueV;
        RxVFt:
        JVX3t:
        goto rMBZ0;
        yrueV:
        if (!$C60Fy) {
            goto JVX3t;
        }
        goto Keewd;
        OeHe1:
    }
    public function mn5rCiQWG82($EJO7R, $qM53d, $Dn1eW, $peJtM, $nBxcI, $ZVbDm = 's3') : void
    {
        $this->Vr4oM = Z4Tul5rPROvzh::m2H8Xx6sXXn($this->Suzy5, $EJO7R, $qM53d, $nBxcI, $Dn1eW, $peJtM, $ZVbDm);
    }
}
