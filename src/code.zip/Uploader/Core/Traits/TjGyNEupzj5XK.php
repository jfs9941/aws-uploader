<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\I2OiS2IsDF9Mg;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Exception\ZKaX19yQXS7pD;
use Illuminate\Database\Eloquent\Model;
trait TjGyNEupzj5XK
{
    private $nwxHu = [];
    public function muKqrdnPhRb($fDztD)
    {
        goto R6UTn;
        R6UTn:
        if ($this instanceof Model) {
            goto nccIP;
        }
        goto PkT7h;
        M3j8z:
        $this->setAttribute('status', $fDztD);
        goto Rckwa;
        p59kC:
        nccIP:
        goto M3j8z;
        MxMD4:
        goto gyebh;
        goto p59kC;
        Rckwa:
        gyebh:
        goto hFgZs;
        PkT7h:
        $this->status = $fDztD;
        goto MxMD4;
        hFgZs:
    }
    public function mApCoZ7yL4y()
    {
        goto fM1yQ;
        xaBxK:
        WX10E:
        goto eV3l5;
        fM1yQ:
        if (!$this instanceof Model) {
            goto WX10E;
        }
        goto xKR0Y;
        xKR0Y:
        return $this->getAttribute('status');
        goto xaBxK;
        eV3l5:
        return $this->status;
        goto mMWGZ;
        mMWGZ:
    }
    public function mI0VzEtubJR($NwBBE)
    {
        goto a1s5F;
        vVbE0:
        hPOv1:
        goto hMNM0;
        acf7P:
        $this->status = $NwBBE;
        goto AJ4mu;
        KpfiV:
        foreach ($this->nwxHu as $lSWLA) {
            $lSWLA->me0Vk27dOzU($lqmQD, $NwBBE);
            cEIXa:
        }
        goto FmdMt;
        pKNX8:
        SD9ZR:
        goto oEkRQ;
        a1s5F:
        if ($this->m1UGbqVuxLg($NwBBE)) {
            goto hPOv1;
        }
        goto aVnft;
        AJ4mu:
        goto oZXA1;
        goto pKNX8;
        oEkRQ:
        $this->setAttribute('status', $NwBBE);
        goto UnPZL;
        UnPZL:
        oZXA1:
        goto KpfiV;
        FmdMt:
        ZwtQZ:
        goto xxryC;
        hMNM0:
        $lqmQD = $this->mApCoZ7yL4y();
        goto t5IB2;
        t5IB2:
        if ($this instanceof Model) {
            goto SD9ZR;
        }
        goto acf7P;
        aVnft:
        throw ZKaX19yQXS7pD::mu9HcqorPuB($this->id ?? 'unknown', $this->mApCoZ7yL4y(), $NwBBE);
        goto vVbE0;
        xxryC:
    }
    public function m1UGbqVuxLg($NwBBE)
    {
        goto UOReL;
        aYJB4:
        CiWPV:
        goto aRwjB;
        gjjLU:
        VkzGt:
        goto aYJB4;
        UOReL:
        switch ($this->status) {
            case H7dtWZ2h5WAty::UPLOADING:
                return H7dtWZ2h5WAty::UPLOADED == $NwBBE || H7dtWZ2h5WAty::UPLOADING == $NwBBE || H7dtWZ2h5WAty::ABORTED == $NwBBE;
            case H7dtWZ2h5WAty::UPLOADED:
                return H7dtWZ2h5WAty::PROCESSING == $NwBBE || H7dtWZ2h5WAty::DELETED == $NwBBE;
            case H7dtWZ2h5WAty::PROCESSING:
                return in_array($NwBBE, [H7dtWZ2h5WAty::WATERMARK_PROCESSED, H7dtWZ2h5WAty::THUMBNAIL_PROCESSED, H7dtWZ2h5WAty::ENCODING_PROCESSED, H7dtWZ2h5WAty::ENCODING_ERROR, H7dtWZ2h5WAty::BLUR_PROCESSED, H7dtWZ2h5WAty::DELETED, H7dtWZ2h5WAty::FINISHED, H7dtWZ2h5WAty::PROCESSING]);
            case H7dtWZ2h5WAty::FINISHED:
            case H7dtWZ2h5WAty::ABORTED:
                return H7dtWZ2h5WAty::DELETED == $NwBBE;
            case H7dtWZ2h5WAty::ENCODING_PROCESSED:
                return H7dtWZ2h5WAty::FINISHED == $NwBBE || H7dtWZ2h5WAty::DELETED == $NwBBE;
            default:
                return false;
        }
        goto gjjLU;
        aRwjB:
    }
    public function mPghak6SKwq(I2OiS2IsDF9Mg $lSWLA)
    {
        $this->nwxHu[] = $lSWLA;
    }
}
