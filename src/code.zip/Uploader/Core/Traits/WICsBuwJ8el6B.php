<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Traits; trait WICsBuwJ8el6B { private function mDZmP7XJ3CZ(string $eIBZm) : string { return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $eIBZm])); } }
