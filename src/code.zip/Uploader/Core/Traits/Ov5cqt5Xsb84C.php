<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\ZCG0C7zP3e4el;
use Jfs\Uploader\Core\TN0vqVlBODTOO;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
trait Ov5cqt5Xsb84C
{
    private $YG65u;
    private $Oz3zT;
    private $Bg6wE;
    public function m0wKioa2Rfn() : string
    {
        return ZCG0C7zP3e4el::mG6OVqlq12t($this->YG65u->getFilename());
    }
    public function m67klYkiadk() : ZCG0C7zP3e4el
    {
        goto yQCrM;
        E51fn:
        $this->mox8patr0N6();
        goto XkIi1;
        XkIi1:
        return $this->Oz3zT;
        goto HMLh6;
        yQCrM:
        if (!(null !== $this->Oz3zT)) {
            goto pvUvG;
        }
        goto ey4Jh;
        ey4Jh:
        return $this->Oz3zT;
        goto S8lOG;
        S8lOG:
        pvUvG:
        goto E51fn;
        HMLh6:
    }
    private function mox8patr0N6() : TN0vqVlBODTOO
    {
        goto kD93X;
        CG2IH:
        throw new SLsozGEgkOpxH("File {$this->YG65u->getFilename()} is not PreSigned upload");
        goto c3wSn;
        yvDIj:
        return $this;
        goto lnNx4;
        hoByA:
        $wE2D2 = json_decode($VBVJF, true);
        goto otU1d;
        otU1d:
        $this->Oz3zT = ZCG0C7zP3e4el::mANfgbuiNdt($wE2D2);
        goto yvDIj;
        lnNx4:
        NY9VW:
        goto CG2IH;
        kD93X:
        $VBVJF = $this->Bg6wE->get($this->m0wKioa2Rfn());
        goto jvKOK;
        jvKOK:
        if (!$VBVJF) {
            goto NY9VW;
        }
        goto hoByA;
        c3wSn:
    }
    public function miKDxKJaSJG($i5dmr, $VGTq4, $FCa9B, $AWSAi, $aFk6e, $YKOlB = 's3') : void
    {
        $this->Oz3zT = ZCG0C7zP3e4el::monU1Zd4LXw($this->YG65u, $i5dmr, $VGTq4, $aFk6e, $FCa9B, $AWSAi, $YKOlB);
    }
}
