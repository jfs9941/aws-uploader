<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\QeUknjvnDpCFf;
use Jfs\Uploader\Core\VxCHgU78wg1To;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
trait LNmUl22uAPXpw
{
    private $VbAbt;
    private $BVDZZ;
    private $KoMr1;
    public function m0QUuINWJKg() : string
    {
        return QeUknjvnDpCFf::mSDllKAeQ1h($this->VbAbt->getFilename());
    }
    public function muUg8to4YNh() : QeUknjvnDpCFf
    {
        goto EYUOU;
        ZvtZ3:
        return $this->BVDZZ;
        goto IqX5c;
        WvBSy:
        Z3xkw:
        goto Fv1aA;
        CoMjg:
        return $this->BVDZZ;
        goto WvBSy;
        Fv1aA:
        $this->mFgDIJ3dLlF();
        goto ZvtZ3;
        EYUOU:
        if (!(null !== $this->BVDZZ)) {
            goto Z3xkw;
        }
        goto CoMjg;
        IqX5c:
    }
    private function mFgDIJ3dLlF() : VxCHgU78wg1To
    {
        goto kwAP9;
        kwAP9:
        $l4wli = $this->KoMr1->get($this->m0QUuINWJKg());
        goto sHWGJ;
        sHWGJ:
        if (!$l4wli) {
            goto eaa7e;
        }
        goto oSz8D;
        NeyyK:
        throw new XEcmSsCY89ji0("File {$this->VbAbt->getFilename()} is not PreSigned upload");
        goto InXgw;
        oSz8D:
        $yPsEw = json_decode($l4wli, true);
        goto QVKNi;
        QVKNi:
        $this->BVDZZ = QeUknjvnDpCFf::mUgHVyHELDa($yPsEw);
        goto Fw1MB;
        Fw1MB:
        return $this;
        goto mjzD3;
        mjzD3:
        eaa7e:
        goto NeyyK;
        InXgw:
    }
    public function mpVytGF7tI4($Aer7s, $svBb0, $vQ2ya, $FDd_p, $R57fB, $wU0QX = 's3') : void
    {
        $this->BVDZZ = QeUknjvnDpCFf::m9lPBKqTXrB($this->VbAbt, $Aer7s, $svBb0, $R57fB, $vQ2ya, $FDd_p, $wU0QX);
    }
}
