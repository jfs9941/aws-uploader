<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\IVTeeOwHA8NRW;
use Jfs\Uploader\Core\Awxn6mQyQaPNK;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
trait Ep55xNLBGc2Ux
{
    private $CqvUz;
    private $i_3kJ;
    private $fWhmx;
    public function mig8npPkPHw() : string
    {
        return IVTeeOwHA8NRW::mtYQ0zAThf7($this->CqvUz->getFilename());
    }
    public function mdWxraqGvMN() : IVTeeOwHA8NRW
    {
        goto VkyJi;
        etKKk:
        return $this->i_3kJ;
        goto fQB8X;
        fQB8X:
        gN9IB:
        goto upRLE;
        I58S5:
        return $this->i_3kJ;
        goto RWiOZ;
        upRLE:
        $this->mBx1DvXlwpF();
        goto I58S5;
        VkyJi:
        if (!(null !== $this->i_3kJ)) {
            goto gN9IB;
        }
        goto etKKk;
        RWiOZ:
    }
    private function mBx1DvXlwpF() : Awxn6mQyQaPNK
    {
        goto RzeAx;
        FCQpm:
        mv4fy:
        goto AaEvG;
        RzeAx:
        $kl2Ew = $this->fWhmx->get($this->mig8npPkPHw());
        goto MyzCw;
        MyzCw:
        if (!$kl2Ew) {
            goto mv4fy;
        }
        goto WNHza;
        AaEvG:
        throw new Wp4p9VCmIjK6G("File {$this->CqvUz->getFilename()} is not PreSigned upload");
        goto lQKD5;
        hMRQt:
        $this->i_3kJ = IVTeeOwHA8NRW::m4kH9GDSRbg($axqy4);
        goto kJaNv;
        kJaNv:
        return $this;
        goto FCQpm;
        WNHza:
        $axqy4 = json_decode($kl2Ew, true);
        goto hMRQt;
        lQKD5:
    }
    public function myBIkhgLRk4($b98KV, $tTjy3, $rQwH5, $I1ivv, $PFtUr, $DzFpv = 's3') : void
    {
        $this->i_3kJ = IVTeeOwHA8NRW::mf8osksPllX($this->CqvUz, $b98KV, $tTjy3, $PFtUr, $rQwH5, $I1ivv, $DzFpv);
    }
}
