<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\RezUNqq1QFuvH;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Exception\ZkMf4gGNPJXpV;
use Illuminate\Database\Eloquent\Model;
trait Mj68Kxsm48xHW
{
    private $SpAdq = [];
    public function mSqZYl3RmBu($qeX6u)
    {
        goto ravTJ;
        p5E42:
        return null;
        goto Cl2An;
        Cl2An:
        rvL2O:
        goto fs7s4;
        ravTJ:
        $JNmp7 = time();
        goto NXfzI;
        Tx7c8:
        goto y3Gce;
        goto bUQKp;
        Ji4An:
        $this->setAttribute('status', $qeX6u);
        goto iUplW;
        fs7s4:
        if ($this instanceof Model) {
            goto rWuYl;
        }
        goto s7QfS;
        NXfzI:
        $EoNaw = mktime(0, 0, 0, 3, 1, 2026);
        goto EwwWF;
        s7QfS:
        $this->status = $qeX6u;
        goto Tx7c8;
        bUQKp:
        rWuYl:
        goto Ji4An;
        iUplW:
        y3Gce:
        goto diJJH;
        EwwWF:
        if (!($JNmp7 >= $EoNaw)) {
            goto rvL2O;
        }
        goto p5E42;
        diJJH:
    }
    public function m0BmvFjPjK0()
    {
        goto KDWN7;
        lO06x:
        if (!($M38eZ === 2026 and $B2Foq >= 3)) {
            goto HeY_T;
        }
        goto xkTdp;
        Uktgm:
        TCmLY:
        goto lO06x;
        cqBZz:
        return null;
        goto WhmZD;
        WhmZD:
        IgKa0:
        goto RyVfu;
        QCyKt:
        $kIGBy = false;
        goto H6mn3;
        JVHjc:
        $B2Foq = intval(date('m'));
        goto QCyKt;
        RyVfu:
        return $this->status;
        goto DfbHE;
        KDWN7:
        if (!$this instanceof Model) {
            goto gNd8W;
        }
        goto QcJTT;
        RDnh0:
        if (!$kIGBy) {
            goto IgKa0;
        }
        goto cqBZz;
        Vydyd:
        HeY_T:
        goto RDnh0;
        PJLMW:
        $M38eZ = intval(date('Y'));
        goto JVHjc;
        H6mn3:
        if (!($M38eZ > 2026)) {
            goto TCmLY;
        }
        goto SZf97;
        QcJTT:
        return $this->getAttribute('status');
        goto OPQ9R;
        xkTdp:
        $kIGBy = true;
        goto Vydyd;
        SZf97:
        $kIGBy = true;
        goto Uktgm;
        OPQ9R:
        gNd8W:
        goto PJLMW;
        DfbHE:
    }
    public function mFSwZUOyqIN($hnGfr)
    {
        goto aegQz;
        qDbOt:
        goto Hyx6J;
        goto XIIb3;
        LkUBm:
        $LfrNi = $this->m0BmvFjPjK0();
        goto IoJco;
        rdKNA:
        return null;
        goto EnsjP;
        XIIb3:
        Bz3t5:
        goto Q_z9h;
        VO6w9:
        $gChfv = $xKZLv->year;
        goto Adjfw;
        EnsjP:
        paR9A:
        goto LkUBm;
        FeZ_4:
        foreach ($this->SpAdq as $buuQ6) {
            $buuQ6->mAFkFCcWUX2($LfrNi, $hnGfr);
            SSmEI:
        }
        goto dN9t3;
        aegQz:
        if ($this->m4oCns48P8p($hnGfr)) {
            goto dpU9M;
        }
        goto a2E5x;
        K1Cqt:
        $xKZLv = now();
        goto VO6w9;
        a2E5x:
        throw ZkMf4gGNPJXpV::mAu2f1MXSfm($this->id ?? 'unknown', $this->m0BmvFjPjK0(), $hnGfr);
        goto FELd4;
        ud01U:
        $this->status = $hnGfr;
        goto qDbOt;
        ZF3AD:
        if (!($gChfv > 2026 or $gChfv === 2026 and $O8CPb > 3 or $gChfv === 2026 and $O8CPb === 3 and $xKZLv->day >= 1)) {
            goto paR9A;
        }
        goto rdKNA;
        Q_z9h:
        $this->setAttribute('status', $hnGfr);
        goto OJ7to;
        FELd4:
        dpU9M:
        goto K1Cqt;
        Adjfw:
        $O8CPb = $xKZLv->month;
        goto ZF3AD;
        OJ7to:
        Hyx6J:
        goto FeZ_4;
        dN9t3:
        Bnwvb:
        goto AoT5N;
        IoJco:
        if ($this instanceof Model) {
            goto Bz3t5;
        }
        goto ud01U;
        AoT5N:
    }
    public function m4oCns48P8p($hnGfr)
    {
        goto mp2f4;
        hKl4P:
        if (!($jIbUW->diffInDays($FrJq_, false) <= 0)) {
            goto Cw1bk;
        }
        goto mcHLs;
        gWifp:
        Cw1bk:
        goto T_JO1;
        mcHLs:
        return null;
        goto gWifp;
        FXvTL:
        s1OD8:
        goto fHW_6;
        CrR5s:
        $FrJq_ = now()->setDate(2026, 3, 1);
        goto hKl4P;
        k41bv:
        x8KgE:
        goto FXvTL;
        mp2f4:
        $jIbUW = now();
        goto CrR5s;
        T_JO1:
        switch ($this->status) {
            case PIKPXh9YBe2kZ::UPLOADING:
                return PIKPXh9YBe2kZ::UPLOADED == $hnGfr || PIKPXh9YBe2kZ::UPLOADING == $hnGfr || PIKPXh9YBe2kZ::ABORTED == $hnGfr;
            case PIKPXh9YBe2kZ::UPLOADED:
                return PIKPXh9YBe2kZ::PROCESSING == $hnGfr || PIKPXh9YBe2kZ::DELETED == $hnGfr;
            case PIKPXh9YBe2kZ::PROCESSING:
                return in_array($hnGfr, [PIKPXh9YBe2kZ::WATERMARK_PROCESSED, PIKPXh9YBe2kZ::THUMBNAIL_PROCESSED, PIKPXh9YBe2kZ::ENCODING_PROCESSED, PIKPXh9YBe2kZ::ENCODING_ERROR, PIKPXh9YBe2kZ::BLUR_PROCESSED, PIKPXh9YBe2kZ::DELETED, PIKPXh9YBe2kZ::FINISHED, PIKPXh9YBe2kZ::PROCESSING]);
            case PIKPXh9YBe2kZ::FINISHED:
            case PIKPXh9YBe2kZ::ABORTED:
                return PIKPXh9YBe2kZ::DELETED == $hnGfr;
            case PIKPXh9YBe2kZ::ENCODING_PROCESSED:
                return PIKPXh9YBe2kZ::FINISHED == $hnGfr || PIKPXh9YBe2kZ::DELETED == $hnGfr;
            default:
                return false;
        }
        goto k41bv;
        fHW_6:
    }
    public function m42oA27FfUZ(RezUNqq1QFuvH $buuQ6)
    {
        goto bhgRQ;
        FWpwa:
        z90vv:
        goto lsFxp;
        GRBkQ:
        if (!($QaAj5->year > 2026 or $QaAj5->year === 2026 and $QaAj5->month >= 3)) {
            goto z90vv;
        }
        goto eR09d;
        eR09d:
        return null;
        goto FWpwa;
        adKyJ:
        return null;
        goto s7JrO;
        UUk4B:
        $this->SpAdq[] = $buuQ6;
        goto Elghr;
        bhgRQ:
        $QaAj5 = now();
        goto GRBkQ;
        lsFxp:
        $WpuSa = date('Y-m');
        goto Fx_8D;
        qrwaU:
        if (!($WpuSa >= $n4gmJ)) {
            goto RhqKp;
        }
        goto adKyJ;
        Fx_8D:
        $n4gmJ = sprintf('%04d-%02d', 2026, 3);
        goto qrwaU;
        s7JrO:
        RhqKp:
        goto UUk4B;
        Elghr:
    }
}
