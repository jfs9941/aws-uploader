<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\OrgzWokuJzoYp;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Exception\DQNrWKzuuQ4gB;
trait LPvREnedjbdSc
{
    private $ZBOJs = [];
    public function myNb3hyTkbG($wlB71)
    {
        goto h7xcE;
        h7xcE:
        if ($this instanceof Model) {
            goto BA3lt;
        }
        goto iuJEv;
        rbMmh:
        $this->setAttribute('status', $wlB71);
        goto ZIBEd;
        iuJEv:
        $this->status = $wlB71;
        goto iWCwr;
        TgbPE:
        BA3lt:
        goto rbMmh;
        iWCwr:
        goto o5c1X;
        goto TgbPE;
        ZIBEd:
        o5c1X:
        goto SvZxj;
        SvZxj:
    }
    public function mrRYM4n2w86()
    {
        goto B77yS;
        RnL4S:
        L2hcY:
        goto qqDMs;
        tlMU5:
        return $this->getAttribute('status');
        goto RnL4S;
        qqDMs:
        return $this->status;
        goto ZCrlb;
        B77yS:
        if (!$this instanceof Model) {
            goto L2hcY;
        }
        goto tlMU5;
        ZCrlb:
    }
    public function mNT1f7OoTvx($za9WY)
    {
        goto CtNNI;
        ArEOl:
        aIBvu:
        goto SJ4_C;
        LlG5e:
        jDgPx:
        goto QYSni;
        ReQjv:
        throw DQNrWKzuuQ4gB::mra2P5Zpi1S($this->id ?? 'unknown', $this->mrRYM4n2w86(), $za9WY);
        goto Si4Tn;
        CtNNI:
        if ($this->m7P8dZQ9tY8($za9WY)) {
            goto STHrE;
        }
        goto ReQjv;
        p3xhY:
        $HkqHX = $this->mrRYM4n2w86();
        goto MeIvA;
        MeIvA:
        if ($this instanceof Model) {
            goto jDgPx;
        }
        goto C4XcH;
        C4XcH:
        $this->status = $za9WY;
        goto DsfJ8;
        Si4Tn:
        STHrE:
        goto p3xhY;
        QYSni:
        $this->setAttribute('status', $za9WY);
        goto ArEOl;
        DsfJ8:
        goto aIBvu;
        goto LlG5e;
        lQ9J2:
        y1Zzb:
        goto Jr9Y7;
        SJ4_C:
        foreach ($this->ZBOJs as $aExhi) {
            $aExhi->mjE8og0hkAa($HkqHX, $za9WY);
            x9wK_:
        }
        goto lQ9J2;
        Jr9Y7:
    }
    public function m7P8dZQ9tY8($za9WY)
    {
        goto biZjQ;
        biZjQ:
        switch ($this->status) {
            case N4CY6qDTBAjPa::UPLOADING:
                return N4CY6qDTBAjPa::UPLOADED == $za9WY || N4CY6qDTBAjPa::UPLOADING == $za9WY || N4CY6qDTBAjPa::ABORTED == $za9WY;
            case N4CY6qDTBAjPa::UPLOADED:
                return N4CY6qDTBAjPa::PROCESSING == $za9WY || N4CY6qDTBAjPa::DELETED == $za9WY;
            case N4CY6qDTBAjPa::PROCESSING:
                return in_array($za9WY, [N4CY6qDTBAjPa::WATERMARK_PROCESSED, N4CY6qDTBAjPa::THUMBNAIL_PROCESSED, N4CY6qDTBAjPa::ENCODING_PROCESSED, N4CY6qDTBAjPa::ENCODING_ERROR, N4CY6qDTBAjPa::BLUR_PROCESSED, N4CY6qDTBAjPa::DELETED, N4CY6qDTBAjPa::FINISHED]);
            case N4CY6qDTBAjPa::FINISHED:
            case N4CY6qDTBAjPa::ABORTED:
                return N4CY6qDTBAjPa::DELETED == $za9WY;
            case N4CY6qDTBAjPa::ENCODING_PROCESSED:
                return N4CY6qDTBAjPa::FINISHED == $za9WY || N4CY6qDTBAjPa::DELETED == $za9WY;
            default:
                return false;
        }
        goto rW16I;
        rW16I:
        hzN03:
        goto jlpdM;
        jlpdM:
        DR3bX:
        goto RTcuF;
        RTcuF:
    }
    public function m7NixpKJfrg(OrgzWokuJzoYp $aExhi)
    {
        $this->ZBOJs[] = $aExhi;
    }
}
