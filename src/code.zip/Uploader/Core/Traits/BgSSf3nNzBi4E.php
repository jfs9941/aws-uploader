<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait BgSSf3nNzBi4E
{
    public function getFilename() : string
    {
        return $this->getAttribute('id');
    }
    public function getExtension() : string
    {
        return $this->getAttribute('type');
    }
    public function getLocation() : string
    {
        return $this->getAttribute('filename');
    }
    public function initLocation(string $enp15)
    {
        $this->filename = $enp15;
        return $this;
    }
    public function mFyJYzfzJa3($wLwvk) : self
    {
        $this->setAttribute('driver', $wLwvk);
        return $this;
    }
}
