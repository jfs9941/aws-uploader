<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XWPIITmssZr7Q;
use Jfs\Uploader\Core\DcQiQqj2PVL2z;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
trait OUGe2daOkuNHO
{
    private $bilhr;
    private $mr9i8;
    private $AouKZ;
    public function mc7MIaojWTK() : string
    {
        return XWPIITmssZr7Q::mrxyiFG5EN6($this->bilhr->getFilename());
    }
    public function mYn06Pxlq0m() : XWPIITmssZr7Q
    {
        goto NKYjf;
        vdfBJ:
        return $this->mr9i8;
        goto eE4g1;
        haMPC:
        return $this->mr9i8;
        goto Y9eO2;
        dQIVR:
        $this->moypkrW8FaU();
        goto vdfBJ;
        NKYjf:
        if (!(null !== $this->mr9i8)) {
            goto ht0uy;
        }
        goto haMPC;
        Y9eO2:
        ht0uy:
        goto dQIVR;
        eE4g1:
    }
    private function moypkrW8FaU() : DcQiQqj2PVL2z
    {
        goto bqjKj;
        oYwuf:
        throw new B5gPy0GuqF3TT("File {$this->bilhr->getFilename()} is not PreSigned upload");
        goto L81ic;
        B82zr:
        return $this;
        goto nGnfC;
        eFGaO:
        if (!$iOXA3) {
            goto GYbKS;
        }
        goto h8vnc;
        ZevDL:
        $this->mr9i8 = XWPIITmssZr7Q::mfUsMggNuaQ($FXm3Z);
        goto B82zr;
        bqjKj:
        $iOXA3 = $this->AouKZ->get($this->mc7MIaojWTK());
        goto eFGaO;
        nGnfC:
        GYbKS:
        goto oYwuf;
        h8vnc:
        $FXm3Z = json_decode($iOXA3, true);
        goto ZevDL;
        L81ic:
    }
    public function mv25hoqapeT($kJUYP, $tRxYh, $ZzjEq, $MPCIY, $cqKaJ, $E6W0h = 's3') : void
    {
        $this->mr9i8 = XWPIITmssZr7Q::m9JFBI1XYsa($this->bilhr, $kJUYP, $tRxYh, $cqKaJ, $ZzjEq, $MPCIY, $E6W0h);
    }
}
