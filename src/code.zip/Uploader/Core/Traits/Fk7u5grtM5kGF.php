<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Traits;

use backup\Uploader\Contracts\A2uS8gTe46deJ;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Exception\Y86LODF9txYbT;
use Illuminate\Database\Eloquent\Model;
trait Fk7u5grtM5kGF
{
    private $i5kmG = [];
    public function mV7ZhSMguWB($ni0Np)
    {
        goto m9Gti;
        rG7x8:
        $this->setAttribute('status', $ni0Np);
        goto yRl2O;
        yRl2O:
        A_I9q:
        goto HaeM9;
        m9Gti:
        if ($this instanceof Model) {
            goto naRX3;
        }
        goto IytkC;
        XDon2:
        naRX3:
        goto rG7x8;
        IytkC:
        $this->status = $ni0Np;
        goto sk11J;
        sk11J:
        goto A_I9q;
        goto XDon2;
        HaeM9:
    }
    public function my6DStzzyLq()
    {
        goto Lqowu;
        Lqowu:
        if (!$this instanceof Model) {
            goto cCyqW;
        }
        goto F7CfT;
        idF7R:
        cCyqW:
        goto mh56F;
        mh56F:
        return $this->status;
        goto Tw45o;
        F7CfT:
        return $this->getAttribute('status');
        goto idF7R;
        Tw45o:
    }
    public function mKOiTrzpM4V($p028t)
    {
        goto ns8md;
        At8qe:
        NdsDx:
        goto ifvMT;
        SqJU3:
        ZwIR6:
        goto C8Mwj;
        ns8md:
        if ($this->m9wYtYzHR4p($p028t)) {
            goto LCqVo;
        }
        goto ODvni;
        uBnCe:
        if ($this instanceof Model) {
            goto clj6S;
        }
        goto pQa0F;
        pQa0F:
        $this->status = $p028t;
        goto A8SdQ;
        A8SdQ:
        goto NdsDx;
        goto TvZOR;
        TvZOR:
        clj6S:
        goto Y2O2b;
        KvsQB:
        $aWDTu = $this->my6DStzzyLq();
        goto uBnCe;
        ODvni:
        throw Y86LODF9txYbT::mnZdhQhx1R3($this->id ?? 'unknown', $this->my6DStzzyLq(), $p028t);
        goto l2W6j;
        l2W6j:
        LCqVo:
        goto KvsQB;
        Y2O2b:
        $this->setAttribute('status', $p028t);
        goto At8qe;
        ifvMT:
        foreach ($this->i5kmG as $m1ir6) {
            $m1ir6->mI9DhQKSU08($aWDTu, $p028t);
            jZQEc:
        }
        goto SqJU3;
        C8Mwj:
    }
    public function m9wYtYzHR4p($p028t)
    {
        goto m1wNp;
        pMW7s:
        sn7Pw:
        goto ZlpFp;
        Or_Ra:
        jxe_b:
        goto pMW7s;
        m1wNp:
        switch ($this->status) {
            case Aetm2HiFuJE34::UPLOADING:
                return Aetm2HiFuJE34::UPLOADED == $p028t || Aetm2HiFuJE34::UPLOADING == $p028t || Aetm2HiFuJE34::ABORTED == $p028t;
            case Aetm2HiFuJE34::UPLOADED:
                return Aetm2HiFuJE34::PROCESSING == $p028t || Aetm2HiFuJE34::DELETED == $p028t;
            case Aetm2HiFuJE34::PROCESSING:
                return in_array($p028t, [Aetm2HiFuJE34::WATERMARK_PROCESSED, Aetm2HiFuJE34::THUMBNAIL_PROCESSED, Aetm2HiFuJE34::ENCODING_PROCESSED, Aetm2HiFuJE34::ENCODING_ERROR, Aetm2HiFuJE34::BLUR_PROCESSED, Aetm2HiFuJE34::DELETED, Aetm2HiFuJE34::FINISHED, Aetm2HiFuJE34::PROCESSING]);
            case Aetm2HiFuJE34::FINISHED:
            case Aetm2HiFuJE34::ABORTED:
                return Aetm2HiFuJE34::DELETED == $p028t;
            case Aetm2HiFuJE34::ENCODING_PROCESSED:
                return Aetm2HiFuJE34::FINISHED == $p028t || Aetm2HiFuJE34::DELETED == $p028t;
            default:
                return false;
        }
        goto Or_Ra;
        ZlpFp:
    }
    public function mJOjnVefuIu(A2uS8gTe46deJ $m1ir6)
    {
        $this->i5kmG[] = $m1ir6;
    }
}
