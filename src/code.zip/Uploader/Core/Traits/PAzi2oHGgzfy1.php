<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\YcADon3ndBWYh;
use Jfs\Uploader\Core\JxGHPMjqmk9TF;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
trait PAzi2oHGgzfy1
{
    private $bQMHT;
    private $L7b8Z;
    private $LI84V;
    public function mOcpDPbRfUf() : string
    {
        return YcADon3ndBWYh::mIt0SPRbc2O($this->bQMHT->getFilename());
    }
    public function mU5hpD7riBK() : YcADon3ndBWYh
    {
        goto o2uPr;
        CLjgC:
        KAB6m:
        goto MvJSc;
        o2uPr:
        if (!(null !== $this->L7b8Z)) {
            goto KAB6m;
        }
        goto xczcF;
        vJzZF:
        return $this->L7b8Z;
        goto sy7Vk;
        MvJSc:
        $this->mDgZl126LWl();
        goto vJzZF;
        xczcF:
        return $this->L7b8Z;
        goto CLjgC;
        sy7Vk:
    }
    private function mDgZl126LWl() : JxGHPMjqmk9TF
    {
        goto fkVYT;
        jCXTL:
        $LxQe4 = json_decode($kxTIX, true);
        goto geQ6r;
        fkVYT:
        $kxTIX = $this->LI84V->get($this->mOcpDPbRfUf());
        goto tjrnl;
        HaHz4:
        throw new RRuZixuGIQD7H("File {$this->bQMHT->getFilename()} is not PreSigned upload");
        goto JRcip;
        tjrnl:
        if (!$kxTIX) {
            goto geEOI;
        }
        goto jCXTL;
        geQ6r:
        $this->L7b8Z = YcADon3ndBWYh::mp30kFaHIJl($LxQe4);
        goto l30CB;
        l30CB:
        return $this;
        goto EUCDJ;
        EUCDJ:
        geEOI:
        goto HaHz4;
        JRcip:
    }
    public function mErn5ZjMDWP($ervb7, $bhFuN, $Kgya3, $kXmjN, $vfxUB, $C7qXl = 's3') : void
    {
        $this->L7b8Z = YcADon3ndBWYh::mT2l6CvqxA8($this->bQMHT, $ervb7, $bhFuN, $vfxUB, $Kgya3, $kXmjN, $C7qXl);
    }
}
