<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait Y2Fpv122icflP
{
    private function m8d0toBs9qI(string $FkoJ6) : string
    {
        return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $FkoJ6]));
    }
}
