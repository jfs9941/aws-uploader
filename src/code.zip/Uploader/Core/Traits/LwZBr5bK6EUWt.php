<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\PLHq1RdJfseHT;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Exception\HAdknCimVLDdp;
use Illuminate\Database\Eloquent\Model;
trait LwZBr5bK6EUWt
{
    private $uti4V = [];
    public function mdigVxgooZG($d8O7F)
    {
        goto XLgFy;
        jnPh2:
        $this->status = $d8O7F;
        goto CJ0pq;
        XLgFy:
        if ($this instanceof Model) {
            goto lNUrX;
        }
        goto jnPh2;
        CJ0pq:
        goto ikCIt;
        goto wKVNX;
        wKVNX:
        lNUrX:
        goto VqDt9;
        dwGWa:
        ikCIt:
        goto ssHsR;
        VqDt9:
        $this->setAttribute('status', $d8O7F);
        goto dwGWa;
        ssHsR:
    }
    public function mP9I7YdWSoJ()
    {
        goto yDcid;
        AlXsX:
        return $this->getAttribute('status');
        goto FpLTz;
        FpLTz:
        J8XJb:
        goto g8HHs;
        g8HHs:
        return $this->status;
        goto EJ2Yc;
        yDcid:
        if (!$this instanceof Model) {
            goto J8XJb;
        }
        goto AlXsX;
        EJ2Yc:
    }
    public function mo8ljKgMJTJ($kBGa4)
    {
        goto dd6_D;
        bi2Iw:
        $ByviU = $this->mP9I7YdWSoJ();
        goto Oir0G;
        niRf1:
        dx35F:
        goto MwB3f;
        Q9O5f:
        LmdbQ:
        goto gwHlR;
        yFTgN:
        $this->setAttribute('status', $kBGa4);
        goto Q9O5f;
        jMvhT:
        RWOUN:
        goto bi2Iw;
        Wjl2l:
        throw HAdknCimVLDdp::mxRgvnPjfdI($this->id ?? 'unknown', $this->mP9I7YdWSoJ(), $kBGa4);
        goto jMvhT;
        sS970:
        ugr2f:
        goto yFTgN;
        mbOUl:
        goto LmdbQ;
        goto sS970;
        gwHlR:
        foreach ($this->uti4V as $LOrox) {
            $LOrox->mQKpfhrTRkc($ByviU, $kBGa4);
            gfhdR:
        }
        goto niRf1;
        dd6_D:
        if ($this->mbkerlcx7kr($kBGa4)) {
            goto RWOUN;
        }
        goto Wjl2l;
        Oir0G:
        if ($this instanceof Model) {
            goto ugr2f;
        }
        goto KlCSu;
        KlCSu:
        $this->status = $kBGa4;
        goto mbOUl;
        MwB3f:
    }
    public function mbkerlcx7kr($kBGa4)
    {
        goto ZIIJM;
        ZIIJM:
        switch ($this->status) {
            case IfP50GBBbx63a::UPLOADING:
                return IfP50GBBbx63a::UPLOADED == $kBGa4 || IfP50GBBbx63a::UPLOADING == $kBGa4 || IfP50GBBbx63a::ABORTED == $kBGa4;
            case IfP50GBBbx63a::UPLOADED:
                return IfP50GBBbx63a::PROCESSING == $kBGa4 || IfP50GBBbx63a::DELETED == $kBGa4;
            case IfP50GBBbx63a::PROCESSING:
                return in_array($kBGa4, [IfP50GBBbx63a::WATERMARK_PROCESSED, IfP50GBBbx63a::THUMBNAIL_PROCESSED, IfP50GBBbx63a::ENCODING_PROCESSED, IfP50GBBbx63a::ENCODING_ERROR, IfP50GBBbx63a::BLUR_PROCESSED, IfP50GBBbx63a::DELETED, IfP50GBBbx63a::FINISHED, IfP50GBBbx63a::PROCESSING]);
            case IfP50GBBbx63a::FINISHED:
            case IfP50GBBbx63a::ABORTED:
                return IfP50GBBbx63a::DELETED == $kBGa4;
            case IfP50GBBbx63a::ENCODING_PROCESSED:
                return IfP50GBBbx63a::FINISHED == $kBGa4 || IfP50GBBbx63a::DELETED == $kBGa4;
            default:
                return false;
        }
        goto qAM68;
        qAM68:
        un25b:
        goto EhHqf;
        EhHqf:
        dU2L8:
        goto SSnHS;
        SSnHS:
    }
    public function mowZJc7KWzQ(PLHq1RdJfseHT $LOrox)
    {
        $this->uti4V[] = $LOrox;
    }
}
