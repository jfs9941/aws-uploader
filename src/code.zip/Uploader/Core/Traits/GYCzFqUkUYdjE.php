<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\WsCsRu4iqCZ5i;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Exception\BC4l4MMxB4wtt;
use Illuminate\Database\Eloquent\Model;
trait GYCzFqUkUYdjE
{
    private $aNlLt = [];
    public function mUg6EMktQTd($zDAn_)
    {
        goto lQtWA;
        lQtWA:
        if ($this instanceof Model) {
            goto v0Fgu;
        }
        goto xHGsV;
        DfyZG:
        $this->setAttribute('status', $zDAn_);
        goto nfJgB;
        OVsd0:
        v0Fgu:
        goto DfyZG;
        xTW4T:
        goto WzYLd;
        goto OVsd0;
        xHGsV:
        $this->status = $zDAn_;
        goto xTW4T;
        nfJgB:
        WzYLd:
        goto md7u7;
        md7u7:
    }
    public function mUNLIZc6kAe()
    {
        goto x0Ux_;
        m5Ci5:
        return $this->status;
        goto IcjNi;
        MjckL:
        Gkgm6:
        goto m5Ci5;
        FVmzw:
        return $this->getAttribute('status');
        goto MjckL;
        x0Ux_:
        if (!$this instanceof Model) {
            goto Gkgm6;
        }
        goto FVmzw;
        IcjNi:
    }
    public function mAPPeV3mHXi($V30xu)
    {
        goto GdioX;
        GdUHx:
        ufy3f:
        goto RQPwa;
        dT4hw:
        $this->status = $V30xu;
        goto umntr;
        umntr:
        goto p1CHg;
        goto KKDLQ;
        xLx7i:
        $this->setAttribute('status', $V30xu);
        goto m8ohg;
        GdioX:
        if ($this->m9fp6Fqioui($V30xu)) {
            goto ufy3f;
        }
        goto pP02y;
        pP02y:
        throw BC4l4MMxB4wtt::mssOEAN6dJH($this->id ?? 'unknown', $this->mUNLIZc6kAe(), $V30xu);
        goto GdUHx;
        RQPwa:
        $lG21k = $this->mUNLIZc6kAe();
        goto S6amE;
        m8ohg:
        p1CHg:
        goto U59P8;
        SOP3A:
        t0YDs:
        goto mgF0r;
        S6amE:
        if ($this instanceof Model) {
            goto M0QgC;
        }
        goto dT4hw;
        U59P8:
        foreach ($this->aNlLt as $Yo_5V) {
            $Yo_5V->mz4knromh2J($lG21k, $V30xu);
            fyJR2:
        }
        goto SOP3A;
        KKDLQ:
        M0QgC:
        goto xLx7i;
        mgF0r:
    }
    public function m9fp6Fqioui($V30xu)
    {
        goto mMSic;
        pxlfv:
        PAzjU:
        goto weQck;
        weQck:
        wau3p:
        goto Y0Smc;
        mMSic:
        switch ($this->status) {
            case Xy3InMky6jKYf::UPLOADING:
                return Xy3InMky6jKYf::UPLOADED == $V30xu || Xy3InMky6jKYf::UPLOADING == $V30xu || Xy3InMky6jKYf::ABORTED == $V30xu;
            case Xy3InMky6jKYf::UPLOADED:
                return Xy3InMky6jKYf::PROCESSING == $V30xu || Xy3InMky6jKYf::DELETED == $V30xu;
            case Xy3InMky6jKYf::PROCESSING:
                return in_array($V30xu, [Xy3InMky6jKYf::WATERMARK_PROCESSED, Xy3InMky6jKYf::THUMBNAIL_PROCESSED, Xy3InMky6jKYf::ENCODING_PROCESSED, Xy3InMky6jKYf::ENCODING_ERROR, Xy3InMky6jKYf::BLUR_PROCESSED, Xy3InMky6jKYf::DELETED, Xy3InMky6jKYf::FINISHED, Xy3InMky6jKYf::PROCESSING]);
            case Xy3InMky6jKYf::FINISHED:
            case Xy3InMky6jKYf::ABORTED:
                return Xy3InMky6jKYf::DELETED == $V30xu;
            case Xy3InMky6jKYf::ENCODING_PROCESSED:
                return Xy3InMky6jKYf::FINISHED == $V30xu || Xy3InMky6jKYf::DELETED == $V30xu;
            default:
                return false;
        }
        goto pxlfv;
        Y0Smc:
    }
    public function mdS7hIgNvPC(WsCsRu4iqCZ5i $Yo_5V)
    {
        $this->aNlLt[] = $Yo_5V;
    }
}
