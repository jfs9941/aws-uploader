<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\YZqPZlzFpJfK6;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Exception\F8y1xdPRStgQx;
use Illuminate\Database\Eloquent\Model;
trait V5MfgbTUETSZ1
{
    private $yr0zN = [];
    public function mWCCmTIigqB($xLGfv)
    {
        goto zdAT_;
        f7AH9:
        $this->setAttribute('status', $xLGfv);
        goto BCO_i;
        BCO_i:
        mSBPV:
        goto oTOl2;
        zdAT_:
        if ($this instanceof Model) {
            goto ECgfJ;
        }
        goto onfdW;
        rx1XO:
        goto mSBPV;
        goto p3Q8k;
        p3Q8k:
        ECgfJ:
        goto f7AH9;
        onfdW:
        $this->status = $xLGfv;
        goto rx1XO;
        oTOl2:
    }
    public function mY5IlWisF4J()
    {
        goto cfxZC;
        lomyw:
        return $this->status;
        goto p3ocF;
        IV35N:
        return $this->getAttribute('status');
        goto U9gEh;
        U9gEh:
        sn8M1:
        goto lomyw;
        cfxZC:
        if (!$this instanceof Model) {
            goto sn8M1;
        }
        goto IV35N;
        p3ocF:
    }
    public function mzoKjbCd8Ap($ju62Q)
    {
        goto bXsy3;
        MfCKS:
        foreach ($this->yr0zN as $H63vJ) {
            $H63vJ->mqIsZMsLGwg($for4K, $ju62Q);
            cdly9:
        }
        goto JcquU;
        VELFs:
        $for4K = $this->mY5IlWisF4J();
        goto Y613C;
        gzXJA:
        For1G:
        goto MfCKS;
        T8BB_:
        $this->setAttribute('status', $ju62Q);
        goto gzXJA;
        ik3Dg:
        goto For1G;
        goto KJ0rh;
        d8qMu:
        $this->status = $ju62Q;
        goto ik3Dg;
        JcquU:
        ndQUW:
        goto aMfwv;
        wtK1H:
        throw F8y1xdPRStgQx::m7IiMWWlUSF($this->id ?? 'unknown', $this->mY5IlWisF4J(), $ju62Q);
        goto Myf6H;
        KJ0rh:
        whQqB:
        goto T8BB_;
        bXsy3:
        if ($this->mxhgqgQ6ejj($ju62Q)) {
            goto ov4Hq;
        }
        goto wtK1H;
        Y613C:
        if ($this instanceof Model) {
            goto whQqB;
        }
        goto d8qMu;
        Myf6H:
        ov4Hq:
        goto VELFs;
        aMfwv:
    }
    public function mxhgqgQ6ejj($ju62Q)
    {
        goto eNs_b;
        KKlzz:
        iTWe2:
        goto hs8Sp;
        eNs_b:
        switch ($this->status) {
            case ZVJoOgH14iXBq::UPLOADING:
                return ZVJoOgH14iXBq::UPLOADED == $ju62Q || ZVJoOgH14iXBq::UPLOADING == $ju62Q || ZVJoOgH14iXBq::ABORTED == $ju62Q;
            case ZVJoOgH14iXBq::UPLOADED:
                return ZVJoOgH14iXBq::PROCESSING == $ju62Q || ZVJoOgH14iXBq::DELETED == $ju62Q;
            case ZVJoOgH14iXBq::PROCESSING:
                return in_array($ju62Q, [ZVJoOgH14iXBq::WATERMARK_PROCESSED, ZVJoOgH14iXBq::THUMBNAIL_PROCESSED, ZVJoOgH14iXBq::ENCODING_PROCESSED, ZVJoOgH14iXBq::ENCODING_ERROR, ZVJoOgH14iXBq::BLUR_PROCESSED, ZVJoOgH14iXBq::DELETED, ZVJoOgH14iXBq::FINISHED, ZVJoOgH14iXBq::PROCESSING]);
            case ZVJoOgH14iXBq::FINISHED:
            case ZVJoOgH14iXBq::ABORTED:
                return ZVJoOgH14iXBq::DELETED == $ju62Q;
            case ZVJoOgH14iXBq::ENCODING_PROCESSED:
                return ZVJoOgH14iXBq::FINISHED == $ju62Q || ZVJoOgH14iXBq::DELETED == $ju62Q;
            default:
                return false;
        }
        goto o99YB;
        o99YB:
        sn0uv:
        goto KKlzz;
        hs8Sp:
    }
    public function mfE5Wdi7XQV(YZqPZlzFpJfK6 $H63vJ)
    {
        $this->yr0zN[] = $H63vJ;
    }
}
