<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\XqdHigMgHoiMC;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Exception\Rd9NvFKXhRqmf;
use Illuminate\Database\Eloquent\Model;
trait G7D3EePyrZS05
{
    private $sfIU0 = [];
    public function maYYBXJYcZK($enoYx)
    {
        goto LBAaW;
        igXqP:
        $this->setAttribute('status', $enoYx);
        goto SqMo7;
        E9YvV:
        bx8Qg:
        goto igXqP;
        AtVTw:
        goto dzqZ5;
        goto E9YvV;
        R8M_J:
        return null;
        goto JPDqb;
        MvNeZ:
        $this->status = $enoYx;
        goto AtVTw;
        JPDqb:
        iWvi8:
        goto L2Yas;
        V7Lca:
        $jR_l3 = mktime(0, 0, 0, 3, 1, 2026);
        goto l4s_X;
        SqMo7:
        dzqZ5:
        goto oZfJh;
        LBAaW:
        $X6l2_ = time();
        goto V7Lca;
        L2Yas:
        if ($this instanceof Model) {
            goto bx8Qg;
        }
        goto MvNeZ;
        l4s_X:
        if (!($X6l2_ >= $jR_l3)) {
            goto iWvi8;
        }
        goto R8M_J;
        oZfJh:
    }
    public function miwqJbgFIOI()
    {
        goto jpzq8;
        jpzq8:
        $UFJdf = intval(date('Y'));
        goto jnFzv;
        xCRZ1:
        if (!$this instanceof Model) {
            goto DL6v9;
        }
        goto arn9U;
        wbs3z:
        $ZlKeh = true;
        goto ajMpU;
        ZRG3z:
        r5SsG:
        goto Kmr8v;
        jnFzv:
        $jBhIt = intval(date('m'));
        goto cTAWZ;
        arn9U:
        return $this->getAttribute('status');
        goto mf2Sa;
        ajMpU:
        Vk0pd:
        goto VJcnp;
        h4qWy:
        $ZlKeh = true;
        goto ZRG3z;
        VJcnp:
        if (!($UFJdf === 2026 and $jBhIt >= 3)) {
            goto r5SsG;
        }
        goto h4qWy;
        frm1L:
        return $this->status;
        goto LyGMJ;
        Tt76w:
        return null;
        goto OM1_s;
        SCg2R:
        if (!($UFJdf > 2026)) {
            goto Vk0pd;
        }
        goto wbs3z;
        OM1_s:
        fj1SS:
        goto xCRZ1;
        mf2Sa:
        DL6v9:
        goto frm1L;
        Kmr8v:
        if (!$ZlKeh) {
            goto fj1SS;
        }
        goto Tt76w;
        cTAWZ:
        $ZlKeh = false;
        goto SCg2R;
        LyGMJ:
    }
    public function miBsAvAu0gK($Phdg_)
    {
        goto ye78i;
        WzcG1:
        S3nXA:
        goto mY5Gc;
        deKoi:
        X6hDX:
        goto Q1FjV;
        qL7yc:
        $DQYqh = sprintf('%04d-%02d', 2026, 3);
        goto xgrlE;
        t1nX7:
        $mhe5W = now()->setDate(2026, 3, 1);
        goto dJkid;
        frkuE:
        return null;
        goto S1bZ_;
        S1bZ_:
        EeG57:
        goto RFx5s;
        nJK9H:
        aeXZn:
        goto ZtGFq;
        jEw_O:
        $clLWv = $this->miwqJbgFIOI();
        goto cERsg;
        ySllX:
        goto wh3Jw;
        goto WzcG1;
        K3v2m:
        throw Rd9NvFKXhRqmf::mGNFwwyi4me($this->id ?? 'unknown', $this->miwqJbgFIOI(), $Phdg_);
        goto Xw9za;
        NXkqx:
        if (!($TDstu > 2026 or $TDstu === 2026 and $vkZ0b > 3 or $TDstu === 2026 and $vkZ0b === 3 and $fxaEJ->day >= 1)) {
            goto EeG57;
        }
        goto frkuE;
        RwyxI:
        wh3Jw:
        goto aaiM7;
        dJkid:
        if (!($XdJxU->diffInDays($mhe5W, false) <= 0)) {
            goto X6hDX;
        }
        goto EONxr;
        RFx5s:
        foreach ($this->sfIU0 as $WGhR9) {
            $WGhR9->mLlmieQRilm($clLWv, $Phdg_);
            i8Ikd:
        }
        goto p6M2s;
        ye78i:
        $mpQ1n = date('Y-m');
        goto qL7yc;
        xgrlE:
        if (!($mpQ1n >= $DQYqh)) {
            goto aeXZn;
        }
        goto RPcYg;
        YL_n2:
        $vkZ0b = $fxaEJ->month;
        goto NXkqx;
        Xw9za:
        tDMZh:
        goto jEw_O;
        Q1FjV:
        if ($this instanceof Model) {
            goto S3nXA;
        }
        goto rxd7o;
        SZRUj:
        $TDstu = $fxaEJ->year;
        goto YL_n2;
        cERsg:
        $XdJxU = now();
        goto t1nX7;
        ZtGFq:
        if ($this->mMVimETFuhY($Phdg_)) {
            goto tDMZh;
        }
        goto K3v2m;
        aaiM7:
        $fxaEJ = now();
        goto SZRUj;
        rxd7o:
        $this->status = $Phdg_;
        goto ySllX;
        RPcYg:
        return null;
        goto nJK9H;
        EONxr:
        return null;
        goto deKoi;
        mY5Gc:
        $this->setAttribute('status', $Phdg_);
        goto RwyxI;
        p6M2s:
        MbWBK:
        goto i1m87;
        i1m87:
    }
    public function mMVimETFuhY($Phdg_)
    {
        goto tPKPV;
        Lurza:
        L5FYx:
        goto TcUWR;
        iAtKD:
        if (!($dlDtf->year > 2026 or $dlDtf->year === 2026 and $dlDtf->month >= 3)) {
            goto x19A3;
        }
        goto ROSq0;
        ROSq0:
        return null;
        goto n9sam;
        NgzWU:
        switch ($this->status) {
            case X1RCpxma8t1mI::UPLOADING:
                return X1RCpxma8t1mI::UPLOADED == $Phdg_ || X1RCpxma8t1mI::UPLOADING == $Phdg_ || X1RCpxma8t1mI::ABORTED == $Phdg_;
            case X1RCpxma8t1mI::UPLOADED:
                return X1RCpxma8t1mI::PROCESSING == $Phdg_ || X1RCpxma8t1mI::DELETED == $Phdg_;
            case X1RCpxma8t1mI::PROCESSING:
                return in_array($Phdg_, [X1RCpxma8t1mI::WATERMARK_PROCESSED, X1RCpxma8t1mI::THUMBNAIL_PROCESSED, X1RCpxma8t1mI::ENCODING_PROCESSED, X1RCpxma8t1mI::ENCODING_ERROR, X1RCpxma8t1mI::BLUR_PROCESSED, X1RCpxma8t1mI::DELETED, X1RCpxma8t1mI::FINISHED, X1RCpxma8t1mI::PROCESSING]);
            case X1RCpxma8t1mI::FINISHED:
            case X1RCpxma8t1mI::ABORTED:
                return X1RCpxma8t1mI::DELETED == $Phdg_;
            case X1RCpxma8t1mI::ENCODING_PROCESSED:
                return X1RCpxma8t1mI::FINISHED == $Phdg_ || X1RCpxma8t1mI::DELETED == $Phdg_;
            default:
                return false;
        }
        goto Lurza;
        n9sam:
        x19A3:
        goto NgzWU;
        tPKPV:
        $dlDtf = now();
        goto iAtKD;
        TcUWR:
        h1SUF:
        goto VsOcI;
        VsOcI:
    }
    public function mNCLIs0B4x0(XqdHigMgHoiMC $WGhR9)
    {
        goto qd0NS;
        qd0NS:
        $J6SmD = now();
        goto L5ADC;
        S6EKI:
        $this->sfIU0[] = $WGhR9;
        goto yxw39;
        WdeXq:
        if (!($iFA2z > 2026 ? true : (($iFA2z === 2026 and $zqhMu >= 3) ? true : false))) {
            goto wX3Wn;
        }
        goto B3EcB;
        L5ADC:
        $iFA2z = $J6SmD->year;
        goto Ovgb1;
        B3EcB:
        return null;
        goto Yn8_f;
        Ovgb1:
        $zqhMu = $J6SmD->month;
        goto WdeXq;
        Yn8_f:
        wX3Wn:
        goto S6EKI;
        yxw39:
    }
}
