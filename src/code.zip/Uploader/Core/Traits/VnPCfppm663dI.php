<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Contracts\Iy5htSHK04ggf;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Exception\FQ1SutuqCRD5X;
use Illuminate\Database\Eloquent\Model;
trait VnPCfppm663dI
{
    private $l3wIZ = [];
    public function mXDdmT111J7($x12KI)
    {
        goto zFlH6;
        Ea0ie:
        goto K1SO5;
        goto OWGHk;
        UmG0z:
        $this->status = $x12KI;
        goto Ea0ie;
        GZfbs:
        K1SO5:
        goto ddAZQ;
        zFlH6:
        if ($this instanceof Model) {
            goto wFgt4;
        }
        goto UmG0z;
        u1Tq3:
        $this->setAttribute('status', $x12KI);
        goto GZfbs;
        OWGHk:
        wFgt4:
        goto u1Tq3;
        ddAZQ:
    }
    public function mFQoSZI9l03()
    {
        goto JRSL7;
        JRSL7:
        if (!$this instanceof Model) {
            goto hSDjy;
        }
        goto Qt_rm;
        Qt_rm:
        return $this->getAttribute('status');
        goto dShOd;
        dShOd:
        hSDjy:
        goto Iw_gZ;
        Iw_gZ:
        return $this->status;
        goto FhqgN;
        FhqgN:
    }
    public function miF5zZlQWZD($ncU1p)
    {
        goto EW9ov;
        HoCam:
        Y9oAg:
        goto GdR7e;
        SE160:
        $this->status = $ncU1p;
        goto klTQg;
        rGyhs:
        $zYY2l = $this->mFQoSZI9l03();
        goto F13J2;
        Wl3oH:
        tzbtZ:
        goto uQkKc;
        EW9ov:
        if ($this->m8dWImzJ4Rt($ncU1p)) {
            goto FLL1d;
        }
        goto Cu3iZ;
        uQkKc:
        $this->setAttribute('status', $ncU1p);
        goto sHFyo;
        klTQg:
        goto A2_fv;
        goto Wl3oH;
        d7Kow:
        foreach ($this->l3wIZ as $mP9r0) {
            $mP9r0->mSJMv13z3kQ($zYY2l, $ncU1p);
            fZWV4:
        }
        goto HoCam;
        F13J2:
        if ($this instanceof Model) {
            goto tzbtZ;
        }
        goto SE160;
        sHFyo:
        A2_fv:
        goto d7Kow;
        UD77g:
        FLL1d:
        goto rGyhs;
        Cu3iZ:
        throw FQ1SutuqCRD5X::mqUOr2jRFkl($this->id ?? 'unknown', $this->mFQoSZI9l03(), $ncU1p);
        goto UD77g;
        GdR7e:
    }
    public function m8dWImzJ4Rt($ncU1p)
    {
        goto X1C8T;
        q_ELL:
        pcCKz:
        goto iJe2P;
        Vq6U2:
        zcvbR:
        goto q_ELL;
        X1C8T:
        switch ($this->status) {
            case GlPuUJKmzwUJ9::UPLOADING:
                return GlPuUJKmzwUJ9::UPLOADED == $ncU1p || GlPuUJKmzwUJ9::UPLOADING == $ncU1p || GlPuUJKmzwUJ9::ABORTED == $ncU1p;
            case GlPuUJKmzwUJ9::UPLOADED:
                return GlPuUJKmzwUJ9::PROCESSING == $ncU1p || GlPuUJKmzwUJ9::DELETED == $ncU1p;
            case GlPuUJKmzwUJ9::PROCESSING:
                return in_array($ncU1p, [GlPuUJKmzwUJ9::WATERMARK_PROCESSED, GlPuUJKmzwUJ9::THUMBNAIL_PROCESSED, GlPuUJKmzwUJ9::ENCODING_PROCESSED, GlPuUJKmzwUJ9::ENCODING_ERROR, GlPuUJKmzwUJ9::BLUR_PROCESSED, GlPuUJKmzwUJ9::DELETED, GlPuUJKmzwUJ9::FINISHED, GlPuUJKmzwUJ9::PROCESSING]);
            case GlPuUJKmzwUJ9::FINISHED:
            case GlPuUJKmzwUJ9::ABORTED:
                return GlPuUJKmzwUJ9::DELETED == $ncU1p;
            case GlPuUJKmzwUJ9::ENCODING_PROCESSED:
                return GlPuUJKmzwUJ9::FINISHED == $ncU1p || GlPuUJKmzwUJ9::DELETED == $ncU1p;
            default:
                return false;
        }
        goto Vq6U2;
        iJe2P:
    }
    public function m0Xpg1VLHmO(Iy5htSHK04ggf $mP9r0)
    {
        $this->l3wIZ[] = $mP9r0;
    }
}
