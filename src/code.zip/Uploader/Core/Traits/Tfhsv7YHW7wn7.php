<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait Tfhsv7YHW7wn7
{
    public function getFilename() : string
    {
        return $this->getAttribute('id');
    }
    public function getExtension() : string
    {
        return $this->getAttribute('type');
    }
    public function getLocation() : string
    {
        return $this->getAttribute('filename');
    }
    public function initLocation(string $Ex_tO)
    {
        $this->filename = $Ex_tO;
        return $this;
    }
    public function mJj4qrv3i53($ewvCB) : self
    {
        $this->setAttribute('driver', $ewvCB);
        return $this;
    }
}
