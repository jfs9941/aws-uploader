<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Uploader\Core\Traits\Tfhsv7YHW7wn7;
use Jfs\Uploader\Core\Traits\ZLQWnjuT7vx15;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
class SmhkgG6le5p0r extends LfWCTOqty2Slr implements EknRcwWhw5aDZ
{
    use Tfhsv7YHW7wn7;
    use ZLQWnjuT7vx15;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $VjmOq, string $H2Bah) : self
    {
        goto EGPmJ;
        W0aFq:
        $X0ufS->mfeKnFzyMNC(OLX71luAn6XnP::UPLOADING);
        goto oXtnf;
        EGPmJ:
        $X0ufS = new self(['id' => $VjmOq, 'type' => $H2Bah, 'status' => OLX71luAn6XnP::UPLOADING]);
        goto W0aFq;
        oXtnf:
        return $X0ufS;
        goto k3QTl;
        k3QTl:
    }
    public function width() : ?int
    {
        goto yIhb6;
        yIhb6:
        $qFAp6 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto S6i4a;
        Y3Zyr:
        return null;
        goto x698F;
        S6i4a:
        if (!$qFAp6) {
            goto s0UEo;
        }
        goto s8kdT;
        s8kdT:
        return $qFAp6;
        goto Bgqol;
        Bgqol:
        s0UEo:
        goto Y3Zyr;
        x698F:
    }
    public function height() : ?int
    {
        goto UYe6J;
        L1Gw2:
        return $bxUTl;
        goto m7zvv;
        ZotIi:
        return null;
        goto jOWM5;
        UYe6J:
        $bxUTl = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto EXYAc;
        EXYAc:
        if (!$bxUTl) {
            goto HHJVx;
        }
        goto L1Gw2;
        m7zvv:
        HHJVx:
        goto ZotIi;
        jOWM5:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($X0ufS) {
            goto fM2E3;
            d2fmx:
            qaba_:
            goto Ff9vM;
            mAhzE:
            return;
            goto d2fmx;
            PaT99:
            if (!(!array_key_exists('thumbnail', $h9IZ2) && !array_key_exists('hls_path', $h9IZ2))) {
                goto qaba_;
            }
            goto mAhzE;
            oRgLQ:
            uc5OZ:
            goto OjucE;
            Ff9vM:
            if (!($h9IZ2['thumbnail'] || $h9IZ2['hls_path'])) {
                goto uc5OZ;
            }
            goto WJzsv;
            WJzsv:
            SmhkgG6le5p0r::where('parent_id', $X0ufS->getAttribute('id'))->update(['thumbnail' => $X0ufS->getAttributes()['thumbnail'], 'hls_path' => $X0ufS->getAttributes()['hls_path']]);
            goto oRgLQ;
            fM2E3:
            $h9IZ2 = $X0ufS->getDirty();
            goto PaT99;
            OjucE:
        });
    }
    public function mIf99mgPo8M()
    {
        return $this->getAttribute('thumbnail');
    }
    public function meyQIpj4c2G()
    {
        return $this->getAttribute('id');
    }
    public function mMRXnJUidzH() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto l9NEK;
        pwJma:
        L5MRh:
        goto fDpu1;
        eCJhZ:
        $Th0F7['thumbnail'] = $vo0Bx->resolveThumbnail($this);
        goto yKS1R;
        yKS1R:
        return $Th0F7;
        goto j0GE8;
        l9NEK:
        $vo0Bx = app(TC3rpsU2GuKAE::class);
        goto ezXhI;
        fhnU8:
        $Th0F7['player_url'] = $vo0Bx->resolvePath($this, $this->getAttribute('driver'));
        goto wclh6;
        QjJlq:
        W1saQ:
        goto eCJhZ;
        ezXhI:
        $Th0F7 = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $vo0Bx->resolvePath($this, $this->getAttribute('driver'))];
        goto yXbXB;
        yXbXB:
        if ($this->getAttribute('hls_path')) {
            goto L5MRh;
        }
        goto fhnU8;
        wclh6:
        goto W1saQ;
        goto pwJma;
        fDpu1:
        $Th0F7['player_url'] = $vo0Bx->resolvePathForHlsVideo($this, true);
        goto QjJlq;
        j0GE8:
    }
    public function getThumbnails()
    {
        goto WoWTm;
        Pr_IS:
        return array_map(function ($O8BOu) use($vo0Bx) {
            return $vo0Bx->resolvePath($O8BOu);
        }, $sxVle);
        goto qSbi0;
        WoWTm:
        $sxVle = $this->getAttribute('generated_previews') ?? [];
        goto LMX9w;
        LMX9w:
        $vo0Bx = app(TC3rpsU2GuKAE::class);
        goto Pr_IS;
        qSbi0:
    }
    public static function mRyurtz0u9m(LfWCTOqty2Slr $FjxfJ) : SmhkgG6le5p0r
    {
        goto sSEPK;
        x175Y:
        return $FjxfJ;
        goto U3jQF;
        jCp4u:
        return (new SmhkgG6le5p0r())->fill($FjxfJ->getAttributes());
        goto zbXk5;
        U3jQF:
        SdbhT:
        goto jCp4u;
        sSEPK:
        if (!$FjxfJ instanceof SmhkgG6le5p0r) {
            goto SdbhT;
        }
        goto x175Y;
        zbXk5:
    }
}
