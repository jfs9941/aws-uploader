<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Uploader\Core\Traits\CHvTVfEcdTEOe;
use Jfs\Uploader\Core\Traits\T98qFVxByjzPT;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Service\XeGbK8RtVGtth;
class JUuiYtFOGewFF extends MXbLxov2QPqm4 implements HpFoUL2Zq7Sem
{
    use CHvTVfEcdTEOe;
    use T98qFVxByjzPT;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $DQgCT, string $rG_ni) : self
    {
        goto gop1d;
        yeh0W:
        $q7_ur->mn9R5wxLm2K(Q5pXt73hTeTVP::UPLOADING);
        goto IGzrV;
        IGzrV:
        return $q7_ur;
        goto JmoXw;
        gop1d:
        $q7_ur = new self(['id' => $DQgCT, 'type' => $rG_ni, 'status' => Q5pXt73hTeTVP::UPLOADING]);
        goto yeh0W;
        JmoXw:
    }
    public function getView() : array
    {
        $J1L9Z = app(LlbXoUBShkgwJ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $J1L9Z->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $J1L9Z->resolveThumbnail($this)];
    }
    public static function meW9yO1uQcc(MXbLxov2QPqm4 $rXM0w) : JUuiYtFOGewFF
    {
        goto mmMKv;
        x_1uf:
        return $rXM0w;
        goto hH0fi;
        ZeIns:
        return (new JUuiYtFOGewFF())->fill($rXM0w->getAttributes());
        goto R3BmA;
        hH0fi:
        GrbD_:
        goto ZeIns;
        mmMKv:
        if (!$rXM0w instanceof JUuiYtFOGewFF) {
            goto GrbD_;
        }
        goto x_1uf;
        R3BmA:
    }
}
