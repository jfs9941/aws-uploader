<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Core\Observer\F2UlGkbbhIbuT;
use Jfs\Uploader\Core\Traits\MEICJHiBOK6si;
use Jfs\Uploader\Core\Traits\T98qFVxByjzPT;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Exception\CWn6V46ojDVJy;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Jfs\Uploader\Exception\AJ3Q8FcxdzdHb;
use Jfs\Uploader\Service\Fqe4ryAftaAFD;
final class TVInkZGE2Z8Ja implements HpFoUL2Zq7Sem
{
    use MEICJHiBOK6si;
    use T98qFVxByjzPT;
    private $GIr4p;
    private function __construct($TFA4Z, $nsgrL)
    {
        $this->PV7YF = $TFA4Z;
        $this->k51oV = $nsgrL;
    }
    private function mMoo2zO4WTr(string $QEIhn, $nsgrL, $moAxa, bool $sGpmo = false) : void
    {
        $this->mMajp12kCYR(new F2UlGkbbhIbuT($this, $nsgrL, $moAxa, $QEIhn, $sGpmo));
    }
    public function getFile()
    {
        return $this->PV7YF;
    }
    public function mqoCm0UM5Os(array $cJl60) : void
    {
        $this->GIr4p = $cJl60;
    }
    public function mQ3Hz0K13wy() : void
    {
        $this->mhK1eUHzFBK(Q5pXt73hTeTVP::UPLOADING);
    }
    public function m2odgyXv0kz() : void
    {
        $this->mhK1eUHzFBK(Q5pXt73hTeTVP::UPLOADED);
    }
    public function mZjDGQM2XwH() : void
    {
        $this->mhK1eUHzFBK(Q5pXt73hTeTVP::PROCESSING);
    }
    public function mbd2W2I8k2m() : void
    {
        $this->mhK1eUHzFBK(Q5pXt73hTeTVP::FINISHED);
    }
    public function m9tUPySfwFH() : void
    {
        $this->mhK1eUHzFBK(Q5pXt73hTeTVP::ABORTED);
    }
    public function mQ5l5Rz3Gya() : array
    {
        return $this->GIr4p;
    }
    public static function mhsqHynhNgV(string $ElvKF, $fQ1wT, $eG_Pc, $QEIhn) : self
    {
        goto wPHh9;
        eXWhV:
        $FL9qC->mMoo2zO4WTr($QEIhn, $fQ1wT, $eG_Pc);
        goto MTDv8;
        cJGkJ:
        return $FL9qC->mR4vJ1pOyZp();
        goto Y8wzX;
        dqj8F:
        $FL9qC = new self($TFA4Z, $fQ1wT);
        goto eXWhV;
        wPHh9:
        $TFA4Z = App::make(Fqe4ryAftaAFD::class)->mN1PoxnHLL6(QUscYuYxMDsuz::mmwRyL53HQ1($ElvKF));
        goto dqj8F;
        MTDv8:
        $FL9qC->mn9R5wxLm2K(Q5pXt73hTeTVP::UPLOADING);
        goto cJGkJ;
        Y8wzX:
    }
    public static function mVq9qo82Pv9($TFA4Z, $nsgrL, $moAxa, $QEIhn, $sGpmo = false) : self
    {
        goto YS_J4;
        nx3aw:
        $FL9qC->mn9R5wxLm2K(Q5pXt73hTeTVP::UPLOADING);
        goto CJquW;
        YS_J4:
        $FL9qC = new self($TFA4Z, $nsgrL);
        goto vMjP_;
        vMjP_:
        $FL9qC->mMoo2zO4WTr($QEIhn, $nsgrL, $moAxa, $sGpmo);
        goto nx3aw;
        CJquW:
        return $FL9qC;
        goto jg5jG;
        jg5jG:
    }
}
