<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
final class ZCG0C7zP3e4el
{
    public $filename;
    public $h9ixw;
    public $PfGD5;
    public $G7PBg;
    public $B1Wnn;
    public $RfxUN;
    public $ufqYL;
    public $status;
    public $YGmQc;
    public $ns0Bu;
    public $driver = 's3';
    public $DZzrV = [];
    public function __construct($VSes0, $DNpTL, $BmwLx, $fO18m, $FCa9B, $AWSAi, $OP3kv, $PAl62, $aFk6e, $PCQqS, $YKOlB = 's3', $R3nTL = [])
    {
        goto OHSXQ;
        SvuNY:
        $this->ufqYL = $OP3kv;
        goto bpEwA;
        teKGF:
        $this->PfGD5 = $BmwLx;
        goto P77vO;
        P77vO:
        $this->G7PBg = $fO18m;
        goto g88I5;
        g88I5:
        $this->B1Wnn = $FCa9B;
        goto dTEkp;
        XHoaV:
        $this->h9ixw = $DNpTL;
        goto teKGF;
        OHSXQ:
        $this->filename = $VSes0;
        goto XHoaV;
        gidAf:
        $this->driver = $YKOlB;
        goto B24Kb;
        dTEkp:
        $this->RfxUN = $AWSAi;
        goto SvuNY;
        B24Kb:
        $this->DZzrV = $R3nTL;
        goto MENZK;
        lBIEG:
        $this->YGmQc = $aFk6e;
        goto P3MEa;
        bpEwA:
        $this->status = $PAl62;
        goto lBIEG;
        P3MEa:
        $this->ns0Bu = $PCQqS;
        goto gidAf;
        MENZK:
    }
    private static function mbbNNkrMwY1() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mPW6B7j7TRV() : array
    {
        return array_flip(self::mbbNNkrMwY1());
    }
    public function toArray() : array
    {
        $ZSFll = self::mbbNNkrMwY1();
        return [$ZSFll['filename'] => $this->filename, $ZSFll['fileExtension'] => $this->h9ixw, $ZSFll['mimeType'] => $this->PfGD5, $ZSFll['fileSize'] => $this->G7PBg, $ZSFll['chunkSize'] => $this->B1Wnn, $ZSFll['checksums'] => $this->RfxUN, $ZSFll['totalChunk'] => $this->ufqYL, $ZSFll['status'] => $this->status, $ZSFll['userId'] => $this->YGmQc, $ZSFll['uploadId'] => $this->ns0Bu, $ZSFll['driver'] => $this->driver, $ZSFll['parts'] => $this->DZzrV];
    }
    public static function mANfgbuiNdt(array $QmDvr) : self
    {
        $EmlT4 = array_flip(self::mPW6B7j7TRV());
        return new self($QmDvr[$EmlT4['filename']] ?? $QmDvr['filename'] ?? '', $QmDvr[$EmlT4['fileExtension']] ?? $QmDvr['fileExtension'] ?? '', $QmDvr[$EmlT4['mimeType']] ?? $QmDvr['mimeType'] ?? '', $QmDvr[$EmlT4['fileSize']] ?? $QmDvr['fileSize'] ?? 0, $QmDvr[$EmlT4['chunkSize']] ?? $QmDvr['chunkSize'] ?? 0, $QmDvr[$EmlT4['checksums']] ?? $QmDvr['checksums'] ?? [], $QmDvr[$EmlT4['totalChunk']] ?? $QmDvr['totalChunk'] ?? 0, $QmDvr[$EmlT4['status']] ?? $QmDvr['status'] ?? 0, $QmDvr[$EmlT4['userId']] ?? $QmDvr['userId'] ?? 0, $QmDvr[$EmlT4['uploadId']] ?? $QmDvr['uploadId'] ?? '', $QmDvr[$EmlT4['driver']] ?? $QmDvr['driver'] ?? 's3', $QmDvr[$EmlT4['parts']] ?? $QmDvr['parts'] ?? []);
    }
    public static function mPUATnUONu9($L2F5m) : self
    {
        goto fOuVd;
        jHSPZ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto aBZxh;
        MY5_C:
        tJqS6:
        goto jHSPZ;
        fOuVd:
        if (!(isset($L2F5m['fn']) || isset($L2F5m['fe']))) {
            goto tJqS6;
        }
        goto pw6d4;
        pw6d4:
        return self::mANfgbuiNdt($L2F5m);
        goto MY5_C;
        aBZxh:
    }
    public function m4LXw4yPAPd(string $PCQqS) : void
    {
        $this->ns0Bu = $PCQqS;
    }
    public function mp3ovv1LKfG(array $R3nTL) : void
    {
        $this->DZzrV = $R3nTL;
    }
    public static function monU1Zd4LXw($Z5ydB, $i5dmr, $VGTq4, $aFk6e, $FCa9B, $AWSAi, $YKOlB)
    {
        return new self($Z5ydB->getFilename(), $Z5ydB->getExtension(), $i5dmr, $VGTq4, $FCa9B, $AWSAi, count($AWSAi), M7O7NSiJU2JG5::UPLOADING, $aFk6e, 0, $YKOlB, []);
    }
    public static function mG6OVqlq12t($zV1kl)
    {
        return 'metadata/' . $zV1kl . '.json';
    }
    public function mphSn0us0TW()
    {
        return 's3' === $this->driver ? X4ZiOQdPeeHKI::S3 : X4ZiOQdPeeHKI::LOCAL;
    }
}
