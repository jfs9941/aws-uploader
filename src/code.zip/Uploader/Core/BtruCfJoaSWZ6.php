<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Contracts\IqdLBxImTkuBV;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\Traits\WajBwoXLSKmXZ;
use Jfs\Uploader\Core\Traits\REDykmcLTsPcw;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
class BtruCfJoaSWZ6 extends GpdHFYchpZHPa implements OFkaCU82i4KNX
{
    use WajBwoXLSKmXZ;
    use REDykmcLTsPcw;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $F4nAe, string $WawPM) : self
    {
        goto FQ8H4;
        FQ8H4:
        $Bh2o5 = new self(['id' => $F4nAe, 'type' => $WawPM, 'status' => EHhCBxlsVyz9C::UPLOADING]);
        goto mmRAG;
        kgeXo:
        return $Bh2o5;
        goto DTtZJ;
        mmRAG:
        $Bh2o5->mJpZf64FjYj(EHhCBxlsVyz9C::UPLOADING);
        goto kgeXo;
        DTtZJ:
    }
    public function width() : ?int
    {
        goto HwYu3;
        HwYu3:
        $Sv6q3 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto a1Dpy;
        a1Dpy:
        if (!$Sv6q3) {
            goto Aps3c;
        }
        goto OQ5Fh;
        nS_FC:
        Aps3c:
        goto mscHI;
        mscHI:
        return null;
        goto rU8Gx;
        OQ5Fh:
        return $Sv6q3;
        goto nS_FC;
        rU8Gx:
    }
    public function height() : ?int
    {
        goto vkf_n;
        Rw7DF:
        if (!$G9pt9) {
            goto e73zf;
        }
        goto sypfq;
        sypfq:
        return $G9pt9;
        goto zNalI;
        zNalI:
        e73zf:
        goto s5wLA;
        s5wLA:
        return null;
        goto SMrP3;
        vkf_n:
        $G9pt9 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto Rw7DF;
        SMrP3:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($Bh2o5) {
            goto OuBjA;
            OuBjA:
            $Jx6wP = $Bh2o5->getDirty();
            goto oH7so;
            oH7so:
            if (!(!array_key_exists('thumbnail', $Jx6wP) && !array_key_exists('hls_path', $Jx6wP))) {
                goto t9XZm;
            }
            goto bHEyv;
            A3M2R:
            if (!($Jx6wP['thumbnail'] || $Jx6wP['hls_path'])) {
                goto MZ2RY;
            }
            goto fRGmI;
            fRGmI:
            BtruCfJoaSWZ6::where('parent_id', $Bh2o5->getAttribute('id'))->update(['thumbnail' => $Bh2o5->getAttributes()['thumbnail'], 'hls_path' => $Bh2o5->getAttributes()['hls_path']]);
            goto YE_47;
            YE_47:
            MZ2RY:
            goto J5Vfc;
            bHEyv:
            return;
            goto fVmUV;
            fVmUV:
            t9XZm:
            goto A3M2R;
            J5Vfc:
        });
    }
    public function mg6WhuU1vZv()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mpW8XDlBFMx()
    {
        return $this->getAttribute('id');
    }
    public function mNw1wWRnNGn() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto szbXm;
        koHjW:
        goto eos5V;
        goto IApRT;
        aXeSH:
        $Ww7Yi['player_url'] = $BMXe2->resolvePathForHlsVideo($this, true);
        goto hrh4D;
        hrh4D:
        eos5V:
        goto gr2Tk;
        gr2Tk:
        $Ww7Yi['thumbnail'] = $BMXe2->resolveThumbnail($this);
        goto xTYEB;
        xTYEB:
        return $Ww7Yi;
        goto pGV4M;
        IApRT:
        UUKoG:
        goto aXeSH;
        YLbQ0:
        $Ww7Yi['player_url'] = $BMXe2->resolvePath($this, $this->getAttribute('driver'));
        goto koHjW;
        d2FuJ:
        $Ww7Yi = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $BMXe2->resolvePath($this, $this->getAttribute('driver'))];
        goto M2PTs;
        M2PTs:
        if ($this->getAttribute('hls_path')) {
            goto UUKoG;
        }
        goto YLbQ0;
        szbXm:
        $BMXe2 = app(IqdLBxImTkuBV::class);
        goto d2FuJ;
        pGV4M:
    }
    public function getThumbnails()
    {
        goto SIRbk;
        kUl1f:
        $BMXe2 = app(IqdLBxImTkuBV::class);
        goto nUN7B;
        SIRbk:
        $Sig31 = $this->getAttribute('generated_previews') ?? [];
        goto kUl1f;
        nUN7B:
        return array_map(function ($lSq7k) use($BMXe2) {
            return $BMXe2->resolvePath($lSq7k);
        }, $Sig31);
        goto xtZUr;
        xtZUr:
    }
    public static function m9PqKZwfJZn(GpdHFYchpZHPa $gR4Y3) : BtruCfJoaSWZ6
    {
        goto uOyjO;
        ViPsE:
        return $gR4Y3;
        goto UYqNr;
        UYqNr:
        GILMH:
        goto IiG0k;
        IiG0k:
        return (new BtruCfJoaSWZ6())->fill($gR4Y3->getAttributes());
        goto hHlZ0;
        uOyjO:
        if (!$gR4Y3 instanceof BtruCfJoaSWZ6) {
            goto GILMH;
        }
        goto ViPsE;
        hHlZ0:
    }
}
