<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
final class QeUknjvnDpCFf
{
    public $filename;
    public $RrB1K;
    public $aRMkp;
    public $dZOy6;
    public $vG8bM;
    public $euBB1;
    public $fqUWd;
    public $status;
    public $f3xsP;
    public $X_FKb;
    public $nP7o5 = 's3';
    public $CCl96 = [];
    public function __construct($TUw1J, $CKu1g, $o_gPM, $LRuDK, $vQ2ya, $FDd_p, $mBVCk, $fjvFT, $R57fB, $hqf7_, $wU0QX = 's3', $RNKEH = [])
    {
        goto R21xS;
        seajl:
        $this->aRMkp = $o_gPM;
        goto o5MrG;
        khrG0:
        $this->vG8bM = $vQ2ya;
        goto Rk4sQ;
        Rk4sQ:
        $this->euBB1 = $FDd_p;
        goto sI722;
        ozR8C:
        $this->CCl96 = $RNKEH;
        goto aAAfD;
        sI722:
        $this->fqUWd = $mBVCk;
        goto BF6hA;
        Q43N7:
        $this->X_FKb = $hqf7_;
        goto Tznaq;
        Tznaq:
        $this->nP7o5 = $wU0QX;
        goto ozR8C;
        R21xS:
        $this->filename = $TUw1J;
        goto GGwcK;
        sx1Pz:
        $this->f3xsP = $R57fB;
        goto Q43N7;
        BF6hA:
        $this->status = $fjvFT;
        goto sx1Pz;
        GGwcK:
        $this->RrB1K = $CKu1g;
        goto seajl;
        o5MrG:
        $this->dZOy6 = $LRuDK;
        goto khrG0;
        aAAfD:
    }
    private static function mjMp01PlaaH() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mgSKshFt0vY() : array
    {
        return array_flip(self::mjMp01PlaaH());
    }
    public function toArray() : array
    {
        $z7OFe = self::mjMp01PlaaH();
        return [$z7OFe['filename'] => $this->filename, $z7OFe['fileExtension'] => $this->RrB1K, $z7OFe['mimeType'] => $this->aRMkp, $z7OFe['fileSize'] => $this->dZOy6, $z7OFe['chunkSize'] => $this->vG8bM, $z7OFe['checksums'] => $this->euBB1, $z7OFe['totalChunk'] => $this->fqUWd, $z7OFe['status'] => $this->status, $z7OFe['userId'] => $this->f3xsP, $z7OFe['uploadId'] => $this->X_FKb, $z7OFe['driver'] => $this->nP7o5, $z7OFe['parts'] => $this->CCl96];
    }
    public static function mUgHVyHELDa(array $F0Lr5) : self
    {
        $HtL1T = array_flip(self::mgSKshFt0vY());
        return new self($F0Lr5[$HtL1T['filename']] ?? $F0Lr5['filename'] ?? '', $F0Lr5[$HtL1T['fileExtension']] ?? $F0Lr5['fileExtension'] ?? '', $F0Lr5[$HtL1T['mimeType']] ?? $F0Lr5['mimeType'] ?? '', $F0Lr5[$HtL1T['fileSize']] ?? $F0Lr5['fileSize'] ?? 0, $F0Lr5[$HtL1T['chunkSize']] ?? $F0Lr5['chunkSize'] ?? 0, $F0Lr5[$HtL1T['checksums']] ?? $F0Lr5['checksums'] ?? [], $F0Lr5[$HtL1T['totalChunk']] ?? $F0Lr5['totalChunk'] ?? 0, $F0Lr5[$HtL1T['status']] ?? $F0Lr5['status'] ?? 0, $F0Lr5[$HtL1T['userId']] ?? $F0Lr5['userId'] ?? 0, $F0Lr5[$HtL1T['uploadId']] ?? $F0Lr5['uploadId'] ?? '', $F0Lr5[$HtL1T['driver']] ?? $F0Lr5['driver'] ?? 's3', $F0Lr5[$HtL1T['parts']] ?? $F0Lr5['parts'] ?? []);
    }
    public static function mYS380Xuxy2($aNL7t) : self
    {
        goto d9hK0;
        kYnT_:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto axCSi;
        IVosM:
        return self::mUgHVyHELDa($aNL7t);
        goto XpuQc;
        d9hK0:
        if (!(isset($aNL7t['fn']) || isset($aNL7t['fe']))) {
            goto YKeNw;
        }
        goto IVosM;
        XpuQc:
        YKeNw:
        goto kYnT_;
        axCSi:
    }
    public function mivWGZsVcDB(string $hqf7_) : void
    {
        $this->X_FKb = $hqf7_;
    }
    public function mNQMB9ljE16(array $RNKEH) : void
    {
        $this->CCl96 = $RNKEH;
    }
    public static function m9lPBKqTXrB($s2INV, $Aer7s, $svBb0, $R57fB, $vQ2ya, $FDd_p, $wU0QX)
    {
        return new self($s2INV->getFilename(), $s2INV->getExtension(), $Aer7s, $svBb0, $vQ2ya, $FDd_p, count($FDd_p), IOEDyer18cpSA::UPLOADING, $R57fB, 0, $wU0QX, []);
    }
    public static function mSDllKAeQ1h($aK0gt)
    {
        return 'metadata/' . $aK0gt . '.json';
    }
    public function mXr1uBNwdLJ()
    {
        return 's3' === $this->nP7o5 ? ZuZC67ch9j73R::S3 : ZuZC67ch9j73R::LOCAL;
    }
}
