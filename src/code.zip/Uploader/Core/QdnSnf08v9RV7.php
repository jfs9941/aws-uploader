<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Core\Traits\OoN59oKA3bVp5;
use Jfs\Uploader\Core\Traits\GzYkrJxGq9goW;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
class QdnSnf08v9RV7 extends DYGJpbj9Ye8wY implements M9ges0moH9yTs
{
    use OoN59oKA3bVp5;
    use GzYkrJxGq9goW;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $IW90g, string $ffCXh) : self
    {
        goto jf5L2;
        jf5L2:
        $KuX31 = new self(['id' => $IW90g, 'type' => $ffCXh, 'status' => U8OFutptQGm3S::UPLOADING]);
        goto mGwl6;
        mGwl6:
        $KuX31->mM8xXTkFSyC(U8OFutptQGm3S::UPLOADING);
        goto Vb7x7;
        Vb7x7:
        return $KuX31;
        goto VRE3j;
        VRE3j:
    }
    public function width() : ?int
    {
        goto Vd8up;
        Vd8up:
        $n9snl = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto EEQAU;
        T2jWa:
        BdOOr:
        goto mk7O1;
        Ye6PK:
        return $n9snl;
        goto T2jWa;
        mk7O1:
        return null;
        goto ONaq2;
        EEQAU:
        if (!$n9snl) {
            goto BdOOr;
        }
        goto Ye6PK;
        ONaq2:
    }
    public function height() : ?int
    {
        goto llQL4;
        z2A7F:
        return null;
        goto Qm2hZ;
        IL5i4:
        if (!$M0J4r) {
            goto hN6a8;
        }
        goto h1ywS;
        llQL4:
        $M0J4r = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto IL5i4;
        h1ywS:
        return $M0J4r;
        goto qjIjJ;
        qjIjJ:
        hN6a8:
        goto z2A7F;
        Qm2hZ:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($KuX31) {
            goto uv3_Q;
            Gxbui:
            QdnSnf08v9RV7::where('parent_id', $KuX31->getAttribute('id'))->update(['thumbnail' => $KuX31->getAttributes()['thumbnail'], 'hls_path' => $KuX31->getAttributes()['hls_path']]);
            goto bx8AF;
            yo8EK:
            if (!($w5aeT['thumbnail'] || $w5aeT['hls_path'])) {
                goto BQaFR;
            }
            goto Gxbui;
            dmsap:
            if (!(!array_key_exists('thumbnail', $w5aeT) && !array_key_exists('hls_path', $w5aeT))) {
                goto FbgsL;
            }
            goto FQeGR;
            uv3_Q:
            $w5aeT = $KuX31->getDirty();
            goto dmsap;
            FQeGR:
            return;
            goto ciHSt;
            bx8AF:
            BQaFR:
            goto X593S;
            ciHSt:
            FbgsL:
            goto yo8EK;
            X593S:
        });
    }
    public function mxKXAzgKgQI()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m4SwR1sCcvu()
    {
        return $this->getAttribute('id');
    }
    public function m9BigqkeLJt() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto CqZUF;
        c10ty:
        if ($this->getAttribute('hls_path')) {
            goto d3mHl;
        }
        goto LOB9B;
        CqZUF:
        $USeiP = app(ZOxMhYUF0fAsi::class);
        goto x8YeS;
        LOB9B:
        $ORPyM['player_url'] = $USeiP->resolvePath($this, $this->getAttribute('driver'));
        goto uknXP;
        vYuR2:
        d3mHl:
        goto nxwr9;
        uknXP:
        goto sE6Kq;
        goto vYuR2;
        nxwr9:
        $ORPyM['player_url'] = $USeiP->resolvePathForHlsVideo($this, true);
        goto PfrXN;
        PfrXN:
        sE6Kq:
        goto Wx24G;
        Wx24G:
        $ORPyM['thumbnail'] = $USeiP->resolveThumbnail($this);
        goto z0sXL;
        x8YeS:
        $ORPyM = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $USeiP->resolvePath($this, $this->getAttribute('driver'))];
        goto c10ty;
        z0sXL:
        return $ORPyM;
        goto SOMLC;
        SOMLC:
    }
    public function getThumbnails()
    {
        goto Fr2Z5;
        roJ6b:
        return array_map(function ($FFU0R) use($USeiP) {
            return $USeiP->resolvePath($FFU0R);
        }, $v5_g9);
        goto qlOOB;
        Fr2Z5:
        $v5_g9 = $this->getAttribute('generated_previews') ?? [];
        goto GfRj0;
        GfRj0:
        $USeiP = app(ZOxMhYUF0fAsi::class);
        goto roJ6b;
        qlOOB:
    }
    public static function m18qmlHeEfl(DYGJpbj9Ye8wY $bcJEK) : QdnSnf08v9RV7
    {
        goto ZVlig;
        H7wg3:
        return $bcJEK;
        goto j8sxa;
        ZVlig:
        if (!$bcJEK instanceof QdnSnf08v9RV7) {
            goto JeRne;
        }
        goto H7wg3;
        j8sxa:
        JeRne:
        goto wxyoe;
        wxyoe:
        return (new QdnSnf08v9RV7())->fill($bcJEK->getAttributes());
        goto BFdj3;
        BFdj3:
    }
}
