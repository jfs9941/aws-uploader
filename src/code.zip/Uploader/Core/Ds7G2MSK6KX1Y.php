<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
final class Ds7G2MSK6KX1Y
{
    public $filename;
    public $vGRMi;
    public $P4Jmr;
    public $zJLxD;
    public $Lmq3n;
    public $kw5aF;
    public $SYIMu;
    public $status;
    public $NNRp9;
    public $ARR5y;
    public $NQ3st = 's3';
    public $H17hx = [];
    public function __construct($KEjeq, $ML_Yw, $Dkgj8, $rpEne, $UmfS4, $jwVeU, $oTViS, $ZEE7z, $yJf24, $cH0Pn, $Z9PFQ = 's3', $zO8GR = [])
    {
        goto q1Dj5;
        UgYwK:
        $this->zJLxD = $rpEne;
        goto UHKOr;
        UHKOr:
        $this->Lmq3n = $UmfS4;
        goto Mb8XA;
        Hby3y:
        $this->NNRp9 = $yJf24;
        goto yiO1t;
        IX21d:
        $this->NQ3st = $Z9PFQ;
        goto R9Mrf;
        yiO1t:
        $this->ARR5y = $cH0Pn;
        goto IX21d;
        GpdEB:
        $this->SYIMu = $oTViS;
        goto HBtVF;
        HBtVF:
        $this->status = $ZEE7z;
        goto Hby3y;
        q1Dj5:
        $this->filename = $KEjeq;
        goto tFVDV;
        uVb99:
        $this->P4Jmr = $Dkgj8;
        goto UgYwK;
        Mb8XA:
        $this->kw5aF = $jwVeU;
        goto GpdEB;
        tFVDV:
        $this->vGRMi = $ML_Yw;
        goto uVb99;
        R9Mrf:
        $this->H17hx = $zO8GR;
        goto RJUTA;
        RJUTA:
    }
    private static function meVATNSxp5e() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function m4Ql3tRISLQ() : array
    {
        return array_flip(self::meVATNSxp5e());
    }
    public function toArray() : array
    {
        $AvuXv = self::meVATNSxp5e();
        return [$AvuXv['filename'] => $this->filename, $AvuXv['fileExtension'] => $this->vGRMi, $AvuXv['mimeType'] => $this->P4Jmr, $AvuXv['fileSize'] => $this->zJLxD, $AvuXv['chunkSize'] => $this->Lmq3n, $AvuXv['checksums'] => $this->kw5aF, $AvuXv['totalChunk'] => $this->SYIMu, $AvuXv['status'] => $this->status, $AvuXv['userId'] => $this->NNRp9, $AvuXv['uploadId'] => $this->ARR5y, $AvuXv['driver'] => $this->NQ3st, $AvuXv['parts'] => $this->H17hx];
    }
    public static function mHZ3f1oPTE4(array $ErJrr) : self
    {
        $u8ShV = array_flip(self::m4Ql3tRISLQ());
        return new self($ErJrr[$u8ShV['filename']] ?? $ErJrr['filename'] ?? '', $ErJrr[$u8ShV['fileExtension']] ?? $ErJrr['fileExtension'] ?? '', $ErJrr[$u8ShV['mimeType']] ?? $ErJrr['mimeType'] ?? '', $ErJrr[$u8ShV['fileSize']] ?? $ErJrr['fileSize'] ?? 0, $ErJrr[$u8ShV['chunkSize']] ?? $ErJrr['chunkSize'] ?? 0, $ErJrr[$u8ShV['checksums']] ?? $ErJrr['checksums'] ?? [], $ErJrr[$u8ShV['totalChunk']] ?? $ErJrr['totalChunk'] ?? 0, $ErJrr[$u8ShV['status']] ?? $ErJrr['status'] ?? 0, $ErJrr[$u8ShV['userId']] ?? $ErJrr['userId'] ?? 0, $ErJrr[$u8ShV['uploadId']] ?? $ErJrr['uploadId'] ?? '', $ErJrr[$u8ShV['driver']] ?? $ErJrr['driver'] ?? 's3', $ErJrr[$u8ShV['parts']] ?? $ErJrr['parts'] ?? []);
    }
    public static function mpjDCoOJz5V($ezY_9) : self
    {
        goto i9yUk;
        UOIjZ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto SsFEV;
        crQ5v:
        return self::mHZ3f1oPTE4($ezY_9);
        goto c2tLg;
        i9yUk:
        if (!(isset($ezY_9['fn']) || isset($ezY_9['fe']))) {
            goto sXaof;
        }
        goto crQ5v;
        c2tLg:
        sXaof:
        goto UOIjZ;
        SsFEV:
    }
    public function m0xOxJ2PiV4(string $cH0Pn) : void
    {
        $this->ARR5y = $cH0Pn;
    }
    public function mxcZy8PDib7(array $zO8GR) : void
    {
        $this->H17hx = $zO8GR;
    }
    public static function mFj6ejQPU3D($RB3Ub, $QXSh4, $OegHY, $yJf24, $UmfS4, $jwVeU, $Z9PFQ)
    {
        return new self($RB3Ub->getFilename(), $RB3Ub->getExtension(), $QXSh4, $OegHY, $UmfS4, $jwVeU, count($jwVeU), Fsm7WCrUwVWh9::UPLOADING, $yJf24, 0, $Z9PFQ, []);
    }
    public static function mO1jRHpZvPV($GMwD5)
    {
        return 'metadata/' . $GMwD5 . '.json';
    }
    public function mbFbAgrHdil()
    {
        return 's3' === $this->NQ3st ? CUySMhqlL7P49::S3 : CUySMhqlL7P49::LOCAL;
    }
}
