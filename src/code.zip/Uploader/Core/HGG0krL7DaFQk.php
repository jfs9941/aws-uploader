<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\R278OrMF6HCNB;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
final class HGG0krL7DaFQk
{
    public $filename;
    public $domka;
    public $elwIk;
    public $Hj1Ds;
    public $pDj8N;
    public $EAreJ;
    public $IfFP1;
    public $status;
    public $oB1jk;
    public $Llr3J;
    public $P462y = 's3';
    public $lrez6 = [];
    public function __construct($duesu, $Moe0A, $Z2jso, $ZJBA9, $FJqqf, $aK2El, $OwPSr, $koWhG, $swalJ, $mZtuW, $gaBy3 = 's3', $sGu64 = [])
    {
        goto zzqJP;
        lcJSD:
        $this->P462y = $gaBy3;
        goto rZ8Sk;
        dWAYX:
        $this->Llr3J = $mZtuW;
        goto lcJSD;
        gVOWf:
        $this->oB1jk = $swalJ;
        goto dWAYX;
        pADHV:
        $this->status = $koWhG;
        goto gVOWf;
        DwR4n:
        $this->elwIk = $Z2jso;
        goto WsZiE;
        rZ8Sk:
        $this->lrez6 = $sGu64;
        goto pq85q;
        y0gq1:
        $this->EAreJ = $aK2El;
        goto lUHtw;
        lUHtw:
        $this->IfFP1 = $OwPSr;
        goto pADHV;
        wpPRT:
        $this->pDj8N = $FJqqf;
        goto y0gq1;
        WsZiE:
        $this->Hj1Ds = $ZJBA9;
        goto wpPRT;
        zzqJP:
        $this->filename = $duesu;
        goto yLDsg;
        yLDsg:
        $this->domka = $Moe0A;
        goto DwR4n;
        pq85q:
    }
    private static function mlk1AMqbjIW() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mpgB9tDQAvX() : array
    {
        return array_flip(self::mlk1AMqbjIW());
    }
    public function toArray() : array
    {
        $UyX8j = self::mlk1AMqbjIW();
        return [$UyX8j['filename'] => $this->filename, $UyX8j['fileExtension'] => $this->domka, $UyX8j['mimeType'] => $this->elwIk, $UyX8j['fileSize'] => $this->Hj1Ds, $UyX8j['chunkSize'] => $this->pDj8N, $UyX8j['checksums'] => $this->EAreJ, $UyX8j['totalChunk'] => $this->IfFP1, $UyX8j['status'] => $this->status, $UyX8j['userId'] => $this->oB1jk, $UyX8j['uploadId'] => $this->Llr3J, $UyX8j['driver'] => $this->P462y, $UyX8j['parts'] => $this->lrez6];
    }
    public static function mwfhcZ7Fjjp(array $i32_G) : self
    {
        $q48Ca = array_flip(self::mpgB9tDQAvX());
        return new self($i32_G[$q48Ca['filename']] ?? $i32_G['filename'] ?? '', $i32_G[$q48Ca['fileExtension']] ?? $i32_G['fileExtension'] ?? '', $i32_G[$q48Ca['mimeType']] ?? $i32_G['mimeType'] ?? '', $i32_G[$q48Ca['fileSize']] ?? $i32_G['fileSize'] ?? 0, $i32_G[$q48Ca['chunkSize']] ?? $i32_G['chunkSize'] ?? 0, $i32_G[$q48Ca['checksums']] ?? $i32_G['checksums'] ?? [], $i32_G[$q48Ca['totalChunk']] ?? $i32_G['totalChunk'] ?? 0, $i32_G[$q48Ca['status']] ?? $i32_G['status'] ?? 0, $i32_G[$q48Ca['userId']] ?? $i32_G['userId'] ?? 0, $i32_G[$q48Ca['uploadId']] ?? $i32_G['uploadId'] ?? '', $i32_G[$q48Ca['driver']] ?? $i32_G['driver'] ?? 's3', $i32_G[$q48Ca['parts']] ?? $i32_G['parts'] ?? []);
    }
    public static function mTqakSdzYAy($Xib_E) : self
    {
        goto tXVDd;
        hrugP:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto OHHNe;
        xsjCw:
        C59N5:
        goto hrugP;
        tXVDd:
        if (!(isset($Xib_E['fn']) || isset($Xib_E['fe']))) {
            goto C59N5;
        }
        goto BHH3V;
        BHH3V:
        return self::mwfhcZ7Fjjp($Xib_E);
        goto xsjCw;
        OHHNe:
    }
    public function mljAt4c4xQC(string $mZtuW) : void
    {
        $this->Llr3J = $mZtuW;
    }
    public function mVK4b8O7i66(array $sGu64) : void
    {
        $this->lrez6 = $sGu64;
    }
    public static function mwAYNgFbnkB($xdi9a, $kxFnQ, $ZGUiR, $swalJ, $FJqqf, $aK2El, $gaBy3)
    {
        return new self($xdi9a->getFilename(), $xdi9a->getExtension(), $kxFnQ, $ZGUiR, $FJqqf, $aK2El, count($aK2El), QUh2VVA2TE5xx::UPLOADING, $swalJ, 0, $gaBy3, []);
    }
    public static function meYUCVPdS1x($R7IrL)
    {
        return 'metadata/' . $R7IrL . '.json';
    }
    public function mSio1r6bavY()
    {
        return 's3' === $this->P462y ? R278OrMF6HCNB::S3 : R278OrMF6HCNB::LOCAL;
    }
}
