<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
final class UAsHLG1mz8hdv
{
    public $filename;
    public $tux0n;
    public $Zpu5j;
    public $ZUDEN;
    public $RpZdB;
    public $ST3w_;
    public $QsKkV;
    public $status;
    public $HOYb4;
    public $Ca5Pw;
    public $driver = 's3';
    public $hVSR8 = [];
    public function __construct($Th2bl, $IDPXc, $sSjas, $Tq6Ii, $PSFks, $w0yvU, $vooHT, $BTDFU, $gjHtm, $s12IM, $WpjdV = 's3', $GU93H = [])
    {
        goto L2E6n;
        TlP9S:
        $this->hVSR8 = $GU93H;
        goto P3t4K;
        L2E6n:
        $this->filename = $Th2bl;
        goto KL4nH;
        wAkpT:
        $this->ZUDEN = $Tq6Ii;
        goto Nhju4;
        KL4nH:
        $this->tux0n = $IDPXc;
        goto If0OG;
        z1uUx:
        $this->driver = $WpjdV;
        goto TlP9S;
        dItQ0:
        $this->QsKkV = $vooHT;
        goto LXW2L;
        Dv_Hf:
        $this->HOYb4 = $gjHtm;
        goto ffg35;
        Nhju4:
        $this->RpZdB = $PSFks;
        goto sHk59;
        If0OG:
        $this->Zpu5j = $sSjas;
        goto wAkpT;
        sHk59:
        $this->ST3w_ = $w0yvU;
        goto dItQ0;
        ffg35:
        $this->Ca5Pw = $s12IM;
        goto z1uUx;
        LXW2L:
        $this->status = $BTDFU;
        goto Dv_Hf;
        P3t4K:
    }
    private static function mKxbYBV6FIs() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mBQu10BEIHo() : array
    {
        return array_flip(self::mKxbYBV6FIs());
    }
    public function toArray() : array
    {
        $cacV1 = self::mKxbYBV6FIs();
        return [$cacV1['filename'] => $this->filename, $cacV1['fileExtension'] => $this->tux0n, $cacV1['mimeType'] => $this->Zpu5j, $cacV1['fileSize'] => $this->ZUDEN, $cacV1['chunkSize'] => $this->RpZdB, $cacV1['checksums'] => $this->ST3w_, $cacV1['totalChunk'] => $this->QsKkV, $cacV1['status'] => $this->status, $cacV1['userId'] => $this->HOYb4, $cacV1['uploadId'] => $this->Ca5Pw, $cacV1['driver'] => $this->driver, $cacV1['parts'] => $this->hVSR8];
    }
    public static function mFJii14EWHB(array $Sqh0g) : self
    {
        $GNV5u = array_flip(self::mBQu10BEIHo());
        return new self($Sqh0g[$GNV5u['filename']] ?? $Sqh0g['filename'] ?? '', $Sqh0g[$GNV5u['fileExtension']] ?? $Sqh0g['fileExtension'] ?? '', $Sqh0g[$GNV5u['mimeType']] ?? $Sqh0g['mimeType'] ?? '', $Sqh0g[$GNV5u['fileSize']] ?? $Sqh0g['fileSize'] ?? 0, $Sqh0g[$GNV5u['chunkSize']] ?? $Sqh0g['chunkSize'] ?? 0, $Sqh0g[$GNV5u['checksums']] ?? $Sqh0g['checksums'] ?? [], $Sqh0g[$GNV5u['totalChunk']] ?? $Sqh0g['totalChunk'] ?? 0, $Sqh0g[$GNV5u['status']] ?? $Sqh0g['status'] ?? 0, $Sqh0g[$GNV5u['userId']] ?? $Sqh0g['userId'] ?? 0, $Sqh0g[$GNV5u['uploadId']] ?? $Sqh0g['uploadId'] ?? '', $Sqh0g[$GNV5u['driver']] ?? $Sqh0g['driver'] ?? 's3', $Sqh0g[$GNV5u['parts']] ?? $Sqh0g['parts'] ?? []);
    }
    public static function mAUg5c8gbR3($VHoZl) : self
    {
        goto D9cmU;
        jn0kB:
        RrEkB:
        goto S6__G;
        D9cmU:
        if (!(isset($VHoZl['fn']) || isset($VHoZl['fe']))) {
            goto RrEkB;
        }
        goto FlJhQ;
        FlJhQ:
        return self::mFJii14EWHB($VHoZl);
        goto jn0kB;
        S6__G:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto a3VQi;
        a3VQi:
    }
    public function mHiIxReHa8H(string $s12IM) : void
    {
        $this->Ca5Pw = $s12IM;
    }
    public function mLvel7PmmCO(array $GU93H) : void
    {
        $this->hVSR8 = $GU93H;
    }
    public static function mkCo10Re2W0($Ga9Xm, $ZIlhp, $hbCdu, $gjHtm, $PSFks, $w0yvU, $WpjdV)
    {
        return new self($Ga9Xm->getFilename(), $Ga9Xm->getExtension(), $ZIlhp, $hbCdu, $PSFks, $w0yvU, count($w0yvU), HGmeWpZQSxAlO::UPLOADING, $gjHtm, 0, $WpjdV, []);
    }
    public static function mET7etRr7Va($ShXx2)
    {
        return 'metadata/' . $ShXx2 . '.json';
    }
    public function maDg8VZIO83()
    {
        return 's3' === $this->driver ? TpPQGsuK0gyw2::S3 : TpPQGsuK0gyw2::LOCAL;
    }
}
