<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Core\Observer\PreSignedStateObserver;
use Jfs\Uploader\Core\Traits\PreSignedMetadataTrait;
use Jfs\Uploader\Core\Traits\StateMachineTrait;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Exception\InvalidStateTransitionException;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Jfs\Uploader\Exception\NonAcceptedFileException;
use Jfs\Uploader\Service\FileFactory;

final class PreSignedModel implements FileStateInterface
{
    use PreSignedMetadataTrait;
    use StateMachineTrait;
    /**
     * @var array {index:int, url: string}
     */
    private $tempUrls;

    private function __construct(
        $file,
        $localStorage
    ) {
        $this->file = $file;
        $this->filesystem = $localStorage;
    }

    private function init(string $bucket, $localStorage, $s3Storage, bool $firstInit = false): void
    {
        $this->addObserver(new PreSignedStateObserver($this, $localStorage, $s3Storage, $bucket, $firstInit));
    }

    /**
     * @return FileStateInterface|FileInterface
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * @param array{index:int, url: string} $tempUrls
     */
    public function withTempUrls(array $tempUrls): void
    {
        $this->tempUrls = $tempUrls;
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function markAsUploading(): void
    {
        $this->transitionTo(FileStatus::UPLOADING);
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function markAsUploaded(): void
    {
        $this->transitionTo(FileStatus::UPLOADED);
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function markAsProcessing(): void
    {
        $this->transitionTo(FileStatus::PROCESSING);
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function markAsFinished(): void
    {
        $this->transitionTo(FileStatus::FINISHED);
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function markAsAborted(): void
    {
        $this->transitionTo(FileStatus::ABORTED);
    }

    public function getTempUrls(): array
    {
        return $this->tempUrls;
    }

    /**
     * @throws InvalidTempFileException
     * @throws NonAcceptedFileException
     */
    public static function fromId(string $id, $local, $s3, $bucket): self
    {
        /** @var FileStateInterface|BaseFileModel $file */
        $file = App::make(FileFactory::class)->initFromMetadata(PreSignedMetadata::metadataFileFromId($id));
        $preSigned = new self($file, $local);
        $preSigned->init($bucket, $local, $s3);
        $preSigned->initializeState(FileStatus::UPLOADING);

        return $preSigned->initMetadata();
    }

    /**
     * @param FileStateInterface|BaseFileModel $file
     * @param Filesystem                       $localStorage
     * @param Filesystem                       $s3Storage
     * @param string                           $bucket
     * @param bool                             $firstInit
     */
    public static function fromFile($file, $localStorage, $s3Storage, $bucket, $firstInit = false): self
    {
        $preSigned = new self($file, $localStorage);
        $preSigned->init($bucket, $localStorage, $s3Storage, $firstInit);
        $preSigned->initializeState(FileStatus::UPLOADING);

        return $preSigned;
    }
}
