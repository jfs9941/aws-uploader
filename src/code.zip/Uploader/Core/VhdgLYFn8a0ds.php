<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\Observer\I8s2MzKUq73Ug;
use Jfs\Uploader\Core\X5zE8bFBbBVcm;
use Jfs\Uploader\Core\Traits\HrkA9h35S9YFT;
use Jfs\Uploader\Core\Traits\VOrYIv3AwrFzm;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Exception\KlKPTBnDHVeRD;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Exception\VTCsTRR34DAEZ;
use Jfs\Uploader\Service\PwjTg62cqDtZB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class VhdgLYFn8a0ds implements BbauDy0pIbj64
{
    use HrkA9h35S9YFT;
    use VOrYIv3AwrFzm;
    private $IFbmo;
    private function __construct($eQ4Ln, $Rgxn3)
    {
        $this->R_58H = $eQ4Ln;
        $this->AThgS = $Rgxn3;
    }
    private function mxXzSPIxhAB(string $QlBWR, $Rgxn3, $z6qdY, bool $b36HC = false) : void
    {
        $this->mHWivXnN62Y(new I8s2MzKUq73Ug($this, $Rgxn3, $z6qdY, $QlBWR, $b36HC));
    }
    public function getFile()
    {
        return $this->R_58H;
    }
    public function mSYLEwNVAPm(array $PLcTe) : void
    {
        $this->IFbmo = $PLcTe;
    }
    public function m8aUqROEDGc() : void
    {
        $this->mG7ZLOSfPOQ(MUu80sOhINyO3::UPLOADING);
    }
    public function moAD0rX8JZT() : void
    {
        $this->mG7ZLOSfPOQ(MUu80sOhINyO3::UPLOADED);
    }
    public function mJg0jPE5Pwv() : void
    {
        $this->mG7ZLOSfPOQ(MUu80sOhINyO3::PROCESSING);
    }
    public function memZgKrrsgW() : void
    {
        $this->mG7ZLOSfPOQ(MUu80sOhINyO3::FINISHED);
    }
    public function mWZjTDDlJBZ() : void
    {
        $this->mG7ZLOSfPOQ(MUu80sOhINyO3::ABORTED);
    }
    public function mgj2km2k8NC() : array
    {
        return $this->IFbmo;
    }
    public static function mboVEfx7koj(string $g5e_r, $YUqIm, $C6boj, $QlBWR) : self
    {
        goto j9rO4;
        W04QU:
        $PRC2n->mxXzSPIxhAB($QlBWR, $YUqIm, $C6boj);
        goto TDeMs;
        TDeMs:
        $PRC2n->m36TLWxcxjb(MUu80sOhINyO3::UPLOADING);
        goto xC_7A;
        XQ5Zv:
        $PRC2n = new self($eQ4Ln, $YUqIm);
        goto W04QU;
        xC_7A:
        return $PRC2n->mNSnvCCFnSt();
        goto hYNeg;
        j9rO4:
        $eQ4Ln = App::make(PwjTg62cqDtZB::class)->mbFD6M3QdNh(X5zE8bFBbBVcm::m46mJEWRin8($g5e_r));
        goto XQ5Zv;
        hYNeg:
    }
    public static function mzj7ofubaMq($eQ4Ln, $Rgxn3, $z6qdY, $QlBWR, $b36HC = false) : self
    {
        goto T3AUb;
        T3AUb:
        $PRC2n = new self($eQ4Ln, $Rgxn3);
        goto jzh7E;
        jzh7E:
        $PRC2n->mxXzSPIxhAB($QlBWR, $Rgxn3, $z6qdY, $b36HC);
        goto Epd3h;
        Epd3h:
        $PRC2n->m36TLWxcxjb(MUu80sOhINyO3::UPLOADING);
        goto wfcbv;
        wfcbv:
        return $PRC2n;
        goto Hr0rp;
        Hr0rp:
    }
}
