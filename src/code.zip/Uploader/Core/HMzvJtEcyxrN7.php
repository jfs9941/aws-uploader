<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
final class HMzvJtEcyxrN7
{
    public $filename;
    public $RIBGm;
    public $yUFtr;
    public $ylT5T;
    public $Q3Heu;
    public $bOsWj;
    public $y3Y6J;
    public $status;
    public $fVECK;
    public $nk34n;
    public $driver = 's3';
    public $DRsEm = [];
    public function __construct($WHKOq, $QUdr3, $kmeWM, $fpSSm, $S1bFz, $fkXC5, $NsDCN, $AAU0q, $Ps6ez, $r_huy, $XHDhR = 's3', $O39m9 = [])
    {
        goto KWBeQ;
        gHhL6:
        $this->Q3Heu = $S1bFz;
        goto YF0CZ;
        YF0CZ:
        $this->bOsWj = $fkXC5;
        goto d5IAW;
        IHXab:
        $this->yUFtr = $kmeWM;
        goto fGQ43;
        KWBeQ:
        $this->filename = $WHKOq;
        goto PC7K3;
        fGQ43:
        $this->ylT5T = $fpSSm;
        goto gHhL6;
        CF04D:
        $this->DRsEm = $O39m9;
        goto Xm5vr;
        ARtgL:
        $this->driver = $XHDhR;
        goto CF04D;
        eVQbV:
        $this->fVECK = $Ps6ez;
        goto ncR0c;
        ncR0c:
        $this->nk34n = $r_huy;
        goto ARtgL;
        d5IAW:
        $this->y3Y6J = $NsDCN;
        goto ZFW55;
        PC7K3:
        $this->RIBGm = $QUdr3;
        goto IHXab;
        ZFW55:
        $this->status = $AAU0q;
        goto eVQbV;
        Xm5vr:
    }
    private static function mqAJAlLc93m() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mjOChJVZScf() : array
    {
        return array_flip(self::mqAJAlLc93m());
    }
    public function toArray() : array
    {
        $yg9h5 = self::mqAJAlLc93m();
        return [$yg9h5['filename'] => $this->filename, $yg9h5['fileExtension'] => $this->RIBGm, $yg9h5['mimeType'] => $this->yUFtr, $yg9h5['fileSize'] => $this->ylT5T, $yg9h5['chunkSize'] => $this->Q3Heu, $yg9h5['checksums'] => $this->bOsWj, $yg9h5['totalChunk'] => $this->y3Y6J, $yg9h5['status'] => $this->status, $yg9h5['userId'] => $this->fVECK, $yg9h5['uploadId'] => $this->nk34n, $yg9h5['driver'] => $this->driver, $yg9h5['parts'] => $this->DRsEm];
    }
    public static function mTTGVZFpaku(array $Aa5jc) : self
    {
        $IrhwB = array_flip(self::mjOChJVZScf());
        return new self($Aa5jc[$IrhwB['filename']] ?? $Aa5jc['filename'] ?? '', $Aa5jc[$IrhwB['fileExtension']] ?? $Aa5jc['fileExtension'] ?? '', $Aa5jc[$IrhwB['mimeType']] ?? $Aa5jc['mimeType'] ?? '', $Aa5jc[$IrhwB['fileSize']] ?? $Aa5jc['fileSize'] ?? 0, $Aa5jc[$IrhwB['chunkSize']] ?? $Aa5jc['chunkSize'] ?? 0, $Aa5jc[$IrhwB['checksums']] ?? $Aa5jc['checksums'] ?? [], $Aa5jc[$IrhwB['totalChunk']] ?? $Aa5jc['totalChunk'] ?? 0, $Aa5jc[$IrhwB['status']] ?? $Aa5jc['status'] ?? 0, $Aa5jc[$IrhwB['userId']] ?? $Aa5jc['userId'] ?? 0, $Aa5jc[$IrhwB['uploadId']] ?? $Aa5jc['uploadId'] ?? '', $Aa5jc[$IrhwB['driver']] ?? $Aa5jc['driver'] ?? 's3', $Aa5jc[$IrhwB['parts']] ?? $Aa5jc['parts'] ?? []);
    }
    public static function mqHLSM6Jtbu($KWjRQ) : self
    {
        goto kBfG_;
        XRKP0:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto sbpqp;
        hNySZ:
        return self::mTTGVZFpaku($KWjRQ);
        goto angEI;
        angEI:
        Sw9T1:
        goto XRKP0;
        kBfG_:
        if (!(isset($KWjRQ['fn']) || isset($KWjRQ['fe']))) {
            goto Sw9T1;
        }
        goto hNySZ;
        sbpqp:
    }
    public function mYg3hbRtYS1(string $r_huy) : void
    {
        $this->nk34n = $r_huy;
    }
    public function mp5vEwdLUkf(array $O39m9) : void
    {
        $this->DRsEm = $O39m9;
    }
    public static function mehuh6f6Udr($dV9QE, $x3olq, $iUTFL, $Ps6ez, $S1bFz, $fkXC5, $XHDhR)
    {
        return new self($dV9QE->getFilename(), $dV9QE->getExtension(), $x3olq, $iUTFL, $S1bFz, $fkXC5, count($fkXC5), EpMPhiTVzNYqA::UPLOADING, $Ps6ez, 0, $XHDhR, []);
    }
    public static function m4Lnp5opuAR($J_scC)
    {
        return 'metadata/' . $J_scC . '.json';
    }
    public function mUhQWRUP9sw()
    {
        return 's3' === $this->driver ? DccywYjigTakI::S3 : DccywYjigTakI::LOCAL;
    }
}
