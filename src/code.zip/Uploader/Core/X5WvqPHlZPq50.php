<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

interface X5WvqPHlZPq50
{
    public function getFilename() : string;
    public function getExtension() : string;
    public function getType() : string;
    public function getLocation() : string;
    public function initLocation(string $JDGKl);
    public static function createFromScratch(string $FIM0D, string $EE6bd);
    public function getView();
}
