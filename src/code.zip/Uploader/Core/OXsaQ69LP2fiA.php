<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Illuminate\Database\Eloquent\Model;
abstract  class OXsaQ69LP2fiA extends Model implements LxwvVLXJMU3yo
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function m5nOvxmictr() : bool
    {
        goto XE4tO;
        XE4tO:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto VK_1m;
        }
        goto yFNmS;
        fAJZ_:
        return !$this->mjxcGojK4W8();
        goto wlOq3;
        hXUf2:
        VK_1m:
        goto fAJZ_;
        yFNmS:
        return true;
        goto hXUf2;
        wlOq3:
    }
    protected function mjxcGojK4W8() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
