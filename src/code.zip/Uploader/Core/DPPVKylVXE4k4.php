<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Contracts\VrVag0CyeQKdN;
use Jfs\Uploader\Core\Traits\NS3Z1m1xuUfrl;
use Jfs\Uploader\Core\Traits\U4dsP2dkmJHns;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Service\GALKiO0auT3sq;
class DPPVKylVXE4k4 extends Yn8aWzKzROkno implements CxLspzxS91nUL
{
    use NS3Z1m1xuUfrl;
    use U4dsP2dkmJHns;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $EtuF1, string $dwytV) : self
    {
        goto CaVee;
        VwGO2:
        return $ORelO;
        goto f_axp;
        CaVee:
        $ORelO = new self(['id' => $EtuF1, 'type' => $dwytV, 'status' => SwAwanZG36Yx6::UPLOADING]);
        goto hb8eV;
        hb8eV:
        $ORelO->m25UhhF4K3y(SwAwanZG36Yx6::UPLOADING);
        goto VwGO2;
        f_axp:
    }
    public function getView() : array
    {
        $vZ4J2 = app(VrVag0CyeQKdN::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $vZ4J2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $vZ4J2->resolveThumbnail($this)];
    }
    public static function mQaSGimSztk(Yn8aWzKzROkno $LKVOP) : DPPVKylVXE4k4
    {
        goto xt2uX;
        EeKhe:
        UIrL9:
        goto kg035;
        Ic7E5:
        return $LKVOP;
        goto EeKhe;
        kg035:
        return (new DPPVKylVXE4k4())->fill($LKVOP->getAttributes());
        goto yz31N;
        xt2uX:
        if (!$LKVOP instanceof DPPVKylVXE4k4) {
            goto UIrL9;
        }
        goto Ic7E5;
        yz31N:
    }
}
