<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Core\Observer\PuvVk80m0ZCT8;
use Jfs\Uploader\Core\Traits\B1ulnUR3NgY9F;
use Jfs\Uploader\Core\Traits\ZKxVDSicUFaFP;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Exception\DTlKOLT8tkTnv;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Jfs\Uploader\Exception\Eh512bCz7e47V;
use Jfs\Uploader\Service\AicOtR7ItsXZc;
final class UvoAmV0bL7M3i implements QBvcnDryrzxsL
{
    use B1ulnUR3NgY9F;
    use ZKxVDSicUFaFP;
    private $d5VbT;
    private function __construct($xdi9a, $Q0D24)
    {
        $this->uXtKk = $xdi9a;
        $this->RlosE = $Q0D24;
    }
    private function mCZxgWjc1XN(string $F66z0, $Q0D24, $A8Sfn, bool $A3pPN = false) : void
    {
        $this->m3FXSxRxwBi(new PuvVk80m0ZCT8($this, $Q0D24, $A8Sfn, $F66z0, $A3pPN));
    }
    public function getFile()
    {
        return $this->uXtKk;
    }
    public function mkHeSFURrdO(array $FVQYF) : void
    {
        $this->d5VbT = $FVQYF;
    }
    public function m2F1EPzYY9n() : void
    {
        $this->meQCGHEeK80(QUh2VVA2TE5xx::UPLOADING);
    }
    public function mo8qIQpHjyT() : void
    {
        $this->meQCGHEeK80(QUh2VVA2TE5xx::UPLOADED);
    }
    public function mRtrYr13h28() : void
    {
        $this->meQCGHEeK80(QUh2VVA2TE5xx::PROCESSING);
    }
    public function mphReRfpATd() : void
    {
        $this->meQCGHEeK80(QUh2VVA2TE5xx::FINISHED);
    }
    public function mOkx2I7mq0D() : void
    {
        $this->meQCGHEeK80(QUh2VVA2TE5xx::ABORTED);
    }
    public function mH1aFytVAxg() : array
    {
        return $this->d5VbT;
    }
    public static function mNrAp4L40uP(string $R7IrL, $c44E_, $JGvdR, $F66z0) : self
    {
        goto xMroN;
        b6IR6:
        $ICdB3 = new self($xdi9a, $c44E_);
        goto lgI3I;
        VPlSG:
        return $ICdB3->mzS2WIQqQYK();
        goto KH3Zg;
        lgI3I:
        $ICdB3->mCZxgWjc1XN($F66z0, $c44E_, $JGvdR);
        goto axrlS;
        axrlS:
        $ICdB3->mhnYveV1r0A(QUh2VVA2TE5xx::UPLOADING);
        goto VPlSG;
        xMroN:
        $xdi9a = App::make(AicOtR7ItsXZc::class)->mxe6CYqgnS9(HGG0krL7DaFQk::meYUCVPdS1x($R7IrL));
        goto b6IR6;
        KH3Zg:
    }
    public static function mQBbDXqCtS1($xdi9a, $Q0D24, $A8Sfn, $F66z0, $A3pPN = false) : self
    {
        goto ijp8y;
        ijp8y:
        $ICdB3 = new self($xdi9a, $Q0D24);
        goto SE0h6;
        a7a9B:
        $ICdB3->mhnYveV1r0A(QUh2VVA2TE5xx::UPLOADING);
        goto TfRJc;
        SE0h6:
        $ICdB3->mCZxgWjc1XN($F66z0, $Q0D24, $A8Sfn, $A3pPN);
        goto a7a9B;
        TfRJc:
        return $ICdB3;
        goto TTdjL;
        TTdjL:
    }
}
