<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
final class TNpNhMZr7RgP2
{
    public $filename;
    public $EZhJ0;
    public $A15kv;
    public $y2OMX;
    public $I1b24;
    public $lSIOv;
    public $bVVFN;
    public $status;
    public $U2OZx;
    public $gWCHb;
    public $H9HlK = 's3';
    public $HAYf_ = [];
    public function __construct($AZvNE, $DHTsY, $BVED2, $zFsH6, $QMvmw, $bYnxU, $i5RAQ, $vs64v, $qA0_A, $EXsQV, $TYPZ5 = 's3', $kr4UA = [])
    {
        goto lDnfI;
        tWSOT:
        $this->status = $vs64v;
        goto c3fR8;
        KyK2j:
        $this->A15kv = $BVED2;
        goto CU8Vc;
        lDnfI:
        $this->filename = $AZvNE;
        goto SBlw8;
        yXSa6:
        $this->I1b24 = $QMvmw;
        goto HOojj;
        n17Ev:
        $this->HAYf_ = $kr4UA;
        goto O1zZA;
        HOojj:
        $this->lSIOv = $bYnxU;
        goto EGTZv;
        tjzlg:
        $this->H9HlK = $TYPZ5;
        goto n17Ev;
        SBlw8:
        $this->EZhJ0 = $DHTsY;
        goto KyK2j;
        YKV0t:
        $this->gWCHb = $EXsQV;
        goto tjzlg;
        c3fR8:
        $this->U2OZx = $qA0_A;
        goto YKV0t;
        CU8Vc:
        $this->y2OMX = $zFsH6;
        goto yXSa6;
        EGTZv:
        $this->bVVFN = $i5RAQ;
        goto tWSOT;
        O1zZA:
    }
    private static function mu9NCOHSXtv() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mD7ZSrzW9Jt() : array
    {
        return array_flip(self::mu9NCOHSXtv());
    }
    public function toArray() : array
    {
        $zkDFs = self::mu9NCOHSXtv();
        return [$zkDFs['filename'] => $this->filename, $zkDFs['fileExtension'] => $this->EZhJ0, $zkDFs['mimeType'] => $this->A15kv, $zkDFs['fileSize'] => $this->y2OMX, $zkDFs['chunkSize'] => $this->I1b24, $zkDFs['checksums'] => $this->lSIOv, $zkDFs['totalChunk'] => $this->bVVFN, $zkDFs['status'] => $this->status, $zkDFs['userId'] => $this->U2OZx, $zkDFs['uploadId'] => $this->gWCHb, $zkDFs['driver'] => $this->H9HlK, $zkDFs['parts'] => $this->HAYf_];
    }
    public static function mZ45dVCgYrk(array $awgMp) : self
    {
        $JX8mn = array_flip(self::mD7ZSrzW9Jt());
        return new self($awgMp[$JX8mn['filename']] ?? $awgMp['filename'] ?? '', $awgMp[$JX8mn['fileExtension']] ?? $awgMp['fileExtension'] ?? '', $awgMp[$JX8mn['mimeType']] ?? $awgMp['mimeType'] ?? '', $awgMp[$JX8mn['fileSize']] ?? $awgMp['fileSize'] ?? 0, $awgMp[$JX8mn['chunkSize']] ?? $awgMp['chunkSize'] ?? 0, $awgMp[$JX8mn['checksums']] ?? $awgMp['checksums'] ?? [], $awgMp[$JX8mn['totalChunk']] ?? $awgMp['totalChunk'] ?? 0, $awgMp[$JX8mn['status']] ?? $awgMp['status'] ?? 0, $awgMp[$JX8mn['userId']] ?? $awgMp['userId'] ?? 0, $awgMp[$JX8mn['uploadId']] ?? $awgMp['uploadId'] ?? '', $awgMp[$JX8mn['driver']] ?? $awgMp['driver'] ?? 's3', $awgMp[$JX8mn['parts']] ?? $awgMp['parts'] ?? []);
    }
    public static function mQOHluOGp5O($fqA0_) : self
    {
        goto Pjtat;
        J9M52:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto yvJJ_;
        Pjtat:
        if (!(isset($fqA0_['fn']) || isset($fqA0_['fe']))) {
            goto dzEvk;
        }
        goto DZoYR;
        DZoYR:
        return self::mZ45dVCgYrk($fqA0_);
        goto txYX_;
        txYX_:
        dzEvk:
        goto J9M52;
        yvJJ_:
    }
    public function mJ42tt7T2YT(string $EXsQV) : void
    {
        $this->gWCHb = $EXsQV;
    }
    public function mtth1J5nOXP(array $kr4UA) : void
    {
        $this->HAYf_ = $kr4UA;
    }
    public static function mIpLPkZdAvP($QxvEM, $z2n_l, $QjbQw, $qA0_A, $QMvmw, $bYnxU, $TYPZ5)
    {
        return new self($QxvEM->getFilename(), $QxvEM->getExtension(), $z2n_l, $QjbQw, $QMvmw, $bYnxU, count($bYnxU), U8OFutptQGm3S::UPLOADING, $qA0_A, 0, $TYPZ5, []);
    }
    public static function mqIq70uMfk6($UcmDx)
    {
        return 'metadata/' . $UcmDx . '.json';
    }
    public function mQPtzgYPpFf()
    {
        return 's3' === $this->H9HlK ? KPpxBU3Qc8yRk::S3 : KPpxBU3Qc8yRk::LOCAL;
    }
}
