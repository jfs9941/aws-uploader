<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Core\Traits\FdeEVbF7HDTyC;
use Jfs\Uploader\Core\Traits\LPvREnedjbdSc;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Service\Uzq9No60iqNHV;
class NvNhGXZYZ9DLW extends HJJu0xs0QACaQ implements IEfiXfym24wIp
{
    use FdeEVbF7HDTyC;
    use LPvREnedjbdSc;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $yU2y0, string $Vb_Cv) : self
    {
        goto g4Cqx;
        qyS8f:
        $zpdIY->myNb3hyTkbG(N4CY6qDTBAjPa::UPLOADING);
        goto XZsSb;
        g4Cqx:
        $zpdIY = new self(['id' => $yU2y0, 'type' => $Vb_Cv, 'status' => N4CY6qDTBAjPa::UPLOADING]);
        goto qyS8f;
        XZsSb:
        return $zpdIY;
        goto yj1LU;
        yj1LU:
    }
    public function getView() : array
    {
        $B5JAi = app(UKSr4EAd7qrlK::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $B5JAi->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $B5JAi->resolveThumbnail($this)];
    }
    public static function mnJ8VHbQddv(HJJu0xs0QACaQ $MgH4F) : NvNhGXZYZ9DLW
    {
        goto F_YO2;
        I3scI:
        return $MgH4F;
        goto FwZLp;
        F_YO2:
        if (!$MgH4F instanceof NvNhGXZYZ9DLW) {
            goto czVUm;
        }
        goto I3scI;
        FwZLp:
        czVUm:
        goto Tbp7_;
        Tbp7_:
        return (new NvNhGXZYZ9DLW())->fill($MgH4F->getAttributes());
        goto HDfYu;
        HDfYu:
    }
}
