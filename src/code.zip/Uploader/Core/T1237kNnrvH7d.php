<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\Observer\I3Q56besGDWjS;
use Jfs\Uploader\Core\E4a2957rpFTRJ;
use Jfs\Uploader\Core\Traits\QXQMiBh91ZqoZ;
use Jfs\Uploader\Core\Traits\Iny7AwCou1ddb;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Exception\JTzKeriqU61FK;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Exception\Pwrqemn2dhCsC;
use Jfs\Uploader\Service\GxQCvfot4aISP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class T1237kNnrvH7d implements IzCykbeCOYPNB
{
    use QXQMiBh91ZqoZ;
    use Iny7AwCou1ddb;
    private $xZ6ri;
    private function __construct($FJFJj, $B27Pk)
    {
        $this->i_qo1 = $FJFJj;
        $this->jB78g = $B27Pk;
    }
    private function mr0jFkXaGnm(string $l286D, $B27Pk, $YzAw4, bool $AU0z4 = false) : void
    {
        $this->mf8n37ngIzn(new I3Q56besGDWjS($this, $B27Pk, $YzAw4, $l286D, $AU0z4));
    }
    public function getFile()
    {
        return $this->i_qo1;
    }
    public function mt7T9zPbtAi(array $hPVq7) : void
    {
        $this->xZ6ri = $hPVq7;
    }
    public function mc2MBS4iICj() : void
    {
        $this->m7ddHwazacD(EXecNg2hg7kwl::UPLOADING);
    }
    public function mGAA4GybF91() : void
    {
        $this->m7ddHwazacD(EXecNg2hg7kwl::UPLOADED);
    }
    public function mMXPPeKoHyt() : void
    {
        $this->m7ddHwazacD(EXecNg2hg7kwl::PROCESSING);
    }
    public function mOYaQi1Iv9G() : void
    {
        $this->m7ddHwazacD(EXecNg2hg7kwl::FINISHED);
    }
    public function mPVzXBizobT() : void
    {
        $this->m7ddHwazacD(EXecNg2hg7kwl::ABORTED);
    }
    public function mNQAK4zjaHM() : array
    {
        return $this->xZ6ri;
    }
    public static function mfD5HTn0hZZ(string $arqvy, $FKawQ, $A3hvZ, $l286D) : self
    {
        goto fTkWM;
        Uagry:
        $B61lN->mr0jFkXaGnm($l286D, $FKawQ, $A3hvZ);
        goto N9DeA;
        N9DeA:
        $B61lN->mQ7dAxBkFij(EXecNg2hg7kwl::UPLOADING);
        goto XTGQG;
        XTGQG:
        return $B61lN->mFldCR5vjk9();
        goto cFFsr;
        u1Bkb:
        $B61lN = new self($FJFJj, $FKawQ);
        goto Uagry;
        fTkWM:
        $FJFJj = App::make(GxQCvfot4aISP::class)->miGkXiiUjT8(E4a2957rpFTRJ::mLe05NfPcmU($arqvy));
        goto u1Bkb;
        cFFsr:
    }
    public static function mYFzhFbMdlE($FJFJj, $B27Pk, $YzAw4, $l286D, $AU0z4 = false) : self
    {
        goto PYtU_;
        vgT_S:
        return $B61lN;
        goto Idsab;
        dacmG:
        $B61lN->mQ7dAxBkFij(EXecNg2hg7kwl::UPLOADING);
        goto vgT_S;
        PYtU_:
        $B61lN = new self($FJFJj, $B27Pk);
        goto P0hFB;
        P0hFB:
        $B61lN->mr0jFkXaGnm($l286D, $B27Pk, $YzAw4, $AU0z4);
        goto dacmG;
        Idsab:
    }
}
