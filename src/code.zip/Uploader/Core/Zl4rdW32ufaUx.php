<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Illuminate\Database\Eloquent\Model;
abstract  class Zl4rdW32ufaUx extends Model implements X5WvqPHlZPq50
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mkiN3f36dQi() : bool
    {
        goto ajMSo;
        ajMSo:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto dalWY;
        }
        goto cmTfs;
        BWyFY:
        return !$this->mwzMDfeRpAg();
        goto FpWTA;
        cmTfs:
        return true;
        goto kj7R2;
        kj7R2:
        dalWY:
        goto BWyFY;
        FpWTA:
    }
    protected function mwzMDfeRpAg() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
