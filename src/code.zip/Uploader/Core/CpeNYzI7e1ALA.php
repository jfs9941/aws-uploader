<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Contracts\WLzh1GrcHwitv;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\Traits\SyABBXn5GOmzX;
use Jfs\Uploader\Core\Traits\IkSz95bOOEAyh;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
class CpeNYzI7e1ALA extends UfttW7MErNAIK implements B7NusEU08Li4E
{
    use SyABBXn5GOmzX;
    use IkSz95bOOEAyh;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $g6MG9, string $Cm600) : self
    {
        goto cMBV3;
        SVfG4:
        $jYLmK->moSEUBFRxDt(KidkTsWIjmNMb::UPLOADING);
        goto DREfp;
        DREfp:
        return $jYLmK;
        goto L0Dsk;
        cMBV3:
        $jYLmK = new self(['id' => $g6MG9, 'type' => $Cm600, 'status' => KidkTsWIjmNMb::UPLOADING]);
        goto SVfG4;
        L0Dsk:
    }
    public function width() : ?int
    {
        goto yDo5E;
        JAgs_:
        if (!$V0H7W) {
            goto JtA0g;
        }
        goto wVYOK;
        BCJvL:
        JtA0g:
        goto pDhFo;
        pDhFo:
        return null;
        goto EKed8;
        yDo5E:
        $V0H7W = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto JAgs_;
        wVYOK:
        return $V0H7W;
        goto BCJvL;
        EKed8:
    }
    public function height() : ?int
    {
        goto uUVQy;
        uUVQy:
        $nO8OT = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto zX43G;
        B2exy:
        return $nO8OT;
        goto FaHDw;
        FaHDw:
        nfB2D:
        goto pTa0Q;
        pTa0Q:
        return null;
        goto orpXm;
        zX43G:
        if (!$nO8OT) {
            goto nfB2D;
        }
        goto B2exy;
        orpXm:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($jYLmK) {
            goto mv1vu;
            SvrWC:
            CpeNYzI7e1ALA::where('parent_id', $jYLmK->getAttribute('id'))->update(['thumbnail' => $jYLmK->getAttributes()['thumbnail'], 'hls_path' => $jYLmK->getAttributes()['hls_path']]);
            goto JuwlO;
            Uc8r6:
            if (!($vsuSy['thumbnail'] || $vsuSy['hls_path'])) {
                goto MfKBh;
            }
            goto SvrWC;
            FN4rW:
            return;
            goto BqTuf;
            JuwlO:
            MfKBh:
            goto lD7EQ;
            mv1vu:
            $vsuSy = $jYLmK->getDirty();
            goto oi_PD;
            BqTuf:
            UuMgV:
            goto Uc8r6;
            oi_PD:
            if (!(!array_key_exists('thumbnail', $vsuSy) && !array_key_exists('hls_path', $vsuSy))) {
                goto UuMgV;
            }
            goto FN4rW;
            lD7EQ:
        });
    }
    public function mBJoWxExRMi()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mF78KuY9zG8()
    {
        return $this->getAttribute('id');
    }
    public function mxcQxXSjpmn() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto NzpGL;
        te0Am:
        cq8AH:
        goto vec4x;
        FlzCw:
        $XVLvQ['thumbnail'] = $mjpq3->resolveThumbnail($this);
        goto VNElL;
        vec4x:
        $XVLvQ['player_url'] = $mjpq3->resolvePathForHlsVideo($this, true);
        goto OxFIb;
        VNElL:
        return $XVLvQ;
        goto yCBti;
        NzpGL:
        $mjpq3 = app(WLzh1GrcHwitv::class);
        goto wQMsr;
        ckW8K:
        $XVLvQ['player_url'] = $mjpq3->resolvePath($this, $this->getAttribute('driver'));
        goto JW0NY;
        OxFIb:
        r0eKY:
        goto FlzCw;
        wQMsr:
        $XVLvQ = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $mjpq3->resolvePath($this, $this->getAttribute('driver'))];
        goto W0vC_;
        W0vC_:
        if ($this->getAttribute('hls_path')) {
            goto cq8AH;
        }
        goto ckW8K;
        JW0NY:
        goto r0eKY;
        goto te0Am;
        yCBti:
    }
    public function getThumbnails()
    {
        goto DW0eU;
        DW0eU:
        $MB2jx = $this->getAttribute('generated_previews') ?? [];
        goto JyniU;
        jRMk8:
        return array_map(function ($dWEzY) use($mjpq3) {
            return $mjpq3->resolvePath($dWEzY);
        }, $MB2jx);
        goto uYpfi;
        JyniU:
        $mjpq3 = app(WLzh1GrcHwitv::class);
        goto jRMk8;
        uYpfi:
    }
    public static function mFWpAxV5AAs(UfttW7MErNAIK $gYpY3) : CpeNYzI7e1ALA
    {
        goto ycjGr;
        PDK8_:
        PWv3I:
        goto CY1NL;
        CY1NL:
        return (new CpeNYzI7e1ALA())->fill($gYpY3->getAttributes());
        goto NYb2Y;
        ycjGr:
        if (!$gYpY3 instanceof CpeNYzI7e1ALA) {
            goto PWv3I;
        }
        goto P95sf;
        P95sf:
        return $gYpY3;
        goto PDK8_;
        NYb2Y:
    }
}
