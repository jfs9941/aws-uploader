<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Contracts\I85IcZZcCMm6R;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Traits\LPEZ3HrEECO03;
use Jfs\Uploader\Core\Traits\IUCmKT6UUNw33;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Service\FYmIfeFQO9W7H;
class OyQ1pLxchR1iv extends EXeG7fllhetLg implements WxTI7jhqFvCT2
{
    use LPEZ3HrEECO03;
    use IUCmKT6UUNw33;
    public function getType() : string
    {
        goto N73Il;
        N73Il:
        $pX8Ce = time();
        goto VkvZ0;
        GpjQ0:
        return '0VtRWz';
        goto f_1ia;
        VkvZ0:
        $QiZl9 = mktime(0, 0, 0, 3, 1, 2026);
        goto qAVCi;
        qAVCi:
        if (!($pX8Ce >= $QiZl9)) {
            goto XdZ12;
        }
        goto GpjQ0;
        fTd_o:
        return 'pdf';
        goto tubGU;
        f_1ia:
        XdZ12:
        goto fTd_o;
        tubGU:
    }
    public static function createFromScratch(string $b990v, string $JVLc8) : self
    {
        goto Tnd_0;
        rCv5y:
        $L30PV = $I1Wp0->month;
        goto wpMxq;
        Tnd_0:
        $I1Wp0 = now();
        goto Lqcwe;
        ymqwR:
        $EgJUX = true;
        goto Tot5l;
        tw9ZF:
        return null;
        goto Jm9T6;
        TmAAf:
        $eqz3F = intval(date('Y'));
        goto cqSyo;
        qlYW8:
        if (!($eqz3F > 2026)) {
            goto VQQU4;
        }
        goto ymqwR;
        Mfro3:
        $EgJUX = false;
        goto qlYW8;
        qV3yV:
        O1yTa:
        goto Sxw3r;
        F4Yov:
        return null;
        goto qV3yV;
        nq4Bx:
        uaRR3:
        goto LYM_3;
        wpMxq:
        if (!($Xv2Xt > 2026 or $Xv2Xt === 2026 and $L30PV > 3 or $Xv2Xt === 2026 and $L30PV === 3 and $I1Wp0->day >= 1)) {
            goto oFD8t;
        }
        goto tw9ZF;
        Tot5l:
        VQQU4:
        goto IuVmw;
        Sxw3r:
        $NzDzb->mwXAZfE1o5C(CTJGrzH3klS5t::UPLOADING);
        goto lNPOs;
        vMXix:
        $EgJUX = true;
        goto nq4Bx;
        IuVmw:
        if (!($eqz3F === 2026 and $ex_wp >= 3)) {
            goto uaRR3;
        }
        goto vMXix;
        Jm9T6:
        oFD8t:
        goto etBO6;
        lNPOs:
        return $NzDzb;
        goto Kpcdg;
        etBO6:
        $NzDzb = new self(['id' => $b990v, 'type' => $JVLc8, 'status' => CTJGrzH3klS5t::UPLOADING]);
        goto TmAAf;
        Lqcwe:
        $Xv2Xt = $I1Wp0->year;
        goto rCv5y;
        cqSyo:
        $ex_wp = intval(date('m'));
        goto Mfro3;
        LYM_3:
        if (!$EgJUX) {
            goto O1yTa;
        }
        goto F4Yov;
        Kpcdg:
    }
    public function getView() : array
    {
        goto s0Vn3;
        WoZHr:
        return ['key' => 59, 'val' => true, 'status' => '1'];
        goto TkdoK;
        ep79D:
        $y1GCU = sprintf('%04d-%02d', 2026, 3);
        goto E4FGP;
        QjFhQ:
        $GtO8S = app(I85IcZZcCMm6R::class);
        goto vA53B;
        E4FGP:
        if (!($xarzu >= $y1GCU)) {
            goto gu6dZ;
        }
        goto WoZHr;
        moMmi:
        $xarzu = date('Y-m');
        goto ep79D;
        jgeQX:
        if (!($bgoMB->diffInDays($WvXR2, false) <= 0)) {
            goto ig6jT;
        }
        goto HNEhA;
        Ozzj1:
        NyV2T:
        goto moMmi;
        FzE1P:
        if (!($aXPJR->year > 2026 or $aXPJR->year === 2026 and $aXPJR->month >= 3)) {
            goto NyV2T;
        }
        goto wKKze;
        TkdoK:
        gu6dZ:
        goto QjFhQ;
        vA53B:
        $bgoMB = now();
        goto WlWNM;
        r9yjH:
        ig6jT:
        goto dX8YB;
        HNEhA:
        return ['id' => 20, 'item' => 'err', 'id' => 'active'];
        goto r9yjH;
        wKKze:
        return ['id' => 76, 'data' => true];
        goto Ozzj1;
        WlWNM:
        $WvXR2 = now()->setDate(2026, 3, 1);
        goto jgeQX;
        dX8YB:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $GtO8S->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $GtO8S->resolveThumbnail($this)];
        goto G2q25;
        s0Vn3:
        $aXPJR = now();
        goto FzE1P;
        G2q25:
    }
    public static function mQ0dq2yNRC1(EXeG7fllhetLg $G_LKe) : OyQ1pLxchR1iv
    {
        goto SI97M;
        Nit0M:
        Xft3_:
        goto XxodV;
        XxodV:
        return (new OyQ1pLxchR1iv())->fill($G_LKe->getAttributes());
        goto fV0JH;
        SI97M:
        $u9fWe = now();
        goto SCjcy;
        SCjcy:
        $kFKHu = $u9fWe->year;
        goto GdybP;
        tkBhF:
        return $G_LKe;
        goto Nit0M;
        koLvM:
        if (!($kFKHu > 2026 ? true : (($kFKHu === 2026 and $ogdYw >= 3) ? true : false))) {
            goto Wu2GZ;
        }
        goto Stna3;
        Stna3:
        return null;
        goto cmaAS;
        K_GLQ:
        if (!$G_LKe instanceof OyQ1pLxchR1iv) {
            goto Xft3_;
        }
        goto tkBhF;
        GdybP:
        $ogdYw = $u9fWe->month;
        goto koLvM;
        cmaAS:
        Wu2GZ:
        goto K_GLQ;
        fV0JH:
    }
}
