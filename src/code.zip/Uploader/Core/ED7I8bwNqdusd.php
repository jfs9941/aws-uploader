<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\Observer\GrAvXXZFM0g57;
use Jfs\Uploader\Core\Ds7G2MSK6KX1Y;
use Jfs\Uploader\Core\Traits\A01oQsK5a3hRL;
use Jfs\Uploader\Core\Traits\RWUAoQ6vUS0uH;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Exception\Vfh0JNvlNsuXG;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Exception\Ki9g9bsseJGaK;
use Jfs\Uploader\Service\G0pnBs62axPuz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class ED7I8bwNqdusd implements WZhCwGsxQbxug
{
    use A01oQsK5a3hRL;
    use RWUAoQ6vUS0uH;
    private $UqL2A;
    private function __construct($RB3Ub, $vS8UC)
    {
        $this->MhOEp = $RB3Ub;
        $this->yDluE = $vS8UC;
    }
    private function m3NkfmO1jvN(string $nIkcP, $vS8UC, $vKILS, bool $fJBaO = false) : void
    {
        $this->mmI31EdIVP7(new GrAvXXZFM0g57($this, $vS8UC, $vKILS, $nIkcP, $fJBaO));
    }
    public function getFile()
    {
        return $this->MhOEp;
    }
    public function m2ccRPZ5J1k(array $WGP6P) : void
    {
        $this->UqL2A = $WGP6P;
    }
    public function mHHfX0Ii621() : void
    {
        $this->mtyCvJ3PeFW(Fsm7WCrUwVWh9::UPLOADING);
    }
    public function m7ADqcvZTcv() : void
    {
        $this->mtyCvJ3PeFW(Fsm7WCrUwVWh9::UPLOADED);
    }
    public function mnY0ADZFWtN() : void
    {
        $this->mtyCvJ3PeFW(Fsm7WCrUwVWh9::PROCESSING);
    }
    public function mWH9dIalKQo() : void
    {
        $this->mtyCvJ3PeFW(Fsm7WCrUwVWh9::FINISHED);
    }
    public function mNHCFjdXofT() : void
    {
        $this->mtyCvJ3PeFW(Fsm7WCrUwVWh9::ABORTED);
    }
    public function meYr1FY5Tzr() : array
    {
        return $this->UqL2A;
    }
    public static function mWTo7Ll57d8(string $GMwD5, $UMhhX, $DPWG1, $nIkcP) : self
    {
        goto qeh9L;
        qeh9L:
        $RB3Ub = App::make(G0pnBs62axPuz::class)->mUduealZH9C(Ds7G2MSK6KX1Y::mO1jRHpZvPV($GMwD5));
        goto lcrA_;
        rR03h:
        $q7b6O->myjAI8i1TR7(Fsm7WCrUwVWh9::UPLOADING);
        goto Si4C9;
        H9P87:
        $q7b6O->m3NkfmO1jvN($nIkcP, $UMhhX, $DPWG1);
        goto rR03h;
        Si4C9:
        return $q7b6O->mvXhQvR5B2j();
        goto yOfqK;
        lcrA_:
        $q7b6O = new self($RB3Ub, $UMhhX);
        goto H9P87;
        yOfqK:
    }
    public static function mQ0StC5mkdO($RB3Ub, $vS8UC, $vKILS, $nIkcP, $fJBaO = false) : self
    {
        goto Hldxb;
        y5aCU:
        $q7b6O->myjAI8i1TR7(Fsm7WCrUwVWh9::UPLOADING);
        goto gpIVp;
        BALIJ:
        $q7b6O->m3NkfmO1jvN($nIkcP, $vS8UC, $vKILS, $fJBaO);
        goto y5aCU;
        gpIVp:
        return $q7b6O;
        goto e9yBp;
        Hldxb:
        $q7b6O = new self($RB3Ub, $vS8UC);
        goto BALIJ;
        e9yBp:
    }
}
