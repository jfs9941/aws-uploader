<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
final class A4nixFDruB7ul
{
    public $filename;
    public $m6941;
    public $FvRNE;
    public $d7Yxv;
    public $MZnay;
    public $uR8r7;
    public $hqF67;
    public $status;
    public $XtjDD;
    public $F_Dsk;
    public $tcavr = 's3';
    public $SBfza = [];
    public function __construct($CwLJA, $nvo1_, $OWULU, $k65FM, $N70qa, $mCZQS, $BUXox, $pwP2W, $IQBpu, $j1Tgu, $sjEM3 = 's3', $M5tou = [])
    {
        goto V2Skr;
        Zwns6:
        $this->MZnay = $N70qa;
        goto fI3Uf;
        M9Q8B:
        $this->SBfza = $M5tou;
        goto FNczD;
        sPbPc:
        $this->XtjDD = $IQBpu;
        goto ViBc2;
        GlOAX:
        $this->d7Yxv = $k65FM;
        goto Zwns6;
        brRni:
        $this->FvRNE = $OWULU;
        goto GlOAX;
        ViBc2:
        $this->F_Dsk = $j1Tgu;
        goto dArP4;
        YCX6P:
        $this->status = $pwP2W;
        goto sPbPc;
        Qps0M:
        $this->m6941 = $nvo1_;
        goto brRni;
        fI3Uf:
        $this->uR8r7 = $mCZQS;
        goto IcKU7;
        dArP4:
        $this->tcavr = $sjEM3;
        goto M9Q8B;
        IcKU7:
        $this->hqF67 = $BUXox;
        goto YCX6P;
        V2Skr:
        $this->filename = $CwLJA;
        goto Qps0M;
        FNczD:
    }
    private static function m0lttOmWhzU() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mI5VRacZLrA() : array
    {
        return array_flip(self::m0lttOmWhzU());
    }
    public function toArray() : array
    {
        $EeJpo = self::m0lttOmWhzU();
        return [$EeJpo['filename'] => $this->filename, $EeJpo['fileExtension'] => $this->m6941, $EeJpo['mimeType'] => $this->FvRNE, $EeJpo['fileSize'] => $this->d7Yxv, $EeJpo['chunkSize'] => $this->MZnay, $EeJpo['checksums'] => $this->uR8r7, $EeJpo['totalChunk'] => $this->hqF67, $EeJpo['status'] => $this->status, $EeJpo['userId'] => $this->XtjDD, $EeJpo['uploadId'] => $this->F_Dsk, $EeJpo['driver'] => $this->tcavr, $EeJpo['parts'] => $this->SBfza];
    }
    public static function mLrSDOhfwrg(array $jeiah) : self
    {
        $wqSM9 = array_flip(self::mI5VRacZLrA());
        return new self($jeiah[$wqSM9['filename']] ?? $jeiah['filename'] ?? '', $jeiah[$wqSM9['fileExtension']] ?? $jeiah['fileExtension'] ?? '', $jeiah[$wqSM9['mimeType']] ?? $jeiah['mimeType'] ?? '', $jeiah[$wqSM9['fileSize']] ?? $jeiah['fileSize'] ?? 0, $jeiah[$wqSM9['chunkSize']] ?? $jeiah['chunkSize'] ?? 0, $jeiah[$wqSM9['checksums']] ?? $jeiah['checksums'] ?? [], $jeiah[$wqSM9['totalChunk']] ?? $jeiah['totalChunk'] ?? 0, $jeiah[$wqSM9['status']] ?? $jeiah['status'] ?? 0, $jeiah[$wqSM9['userId']] ?? $jeiah['userId'] ?? 0, $jeiah[$wqSM9['uploadId']] ?? $jeiah['uploadId'] ?? '', $jeiah[$wqSM9['driver']] ?? $jeiah['driver'] ?? 's3', $jeiah[$wqSM9['parts']] ?? $jeiah['parts'] ?? []);
    }
    public static function m9frp5pXoGL($BQ_de) : self
    {
        goto IMdh3;
        ULE9S:
        return self::mLrSDOhfwrg($BQ_de);
        goto D9C2y;
        D9C2y:
        m3_xG:
        goto BoPcm;
        BoPcm:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto atdxv;
        IMdh3:
        if (!(isset($BQ_de['fn']) || isset($BQ_de['fe']))) {
            goto m3_xG;
        }
        goto ULE9S;
        atdxv:
    }
    public function mTOIVqQ3KEK(string $j1Tgu) : void
    {
        $this->F_Dsk = $j1Tgu;
    }
    public function mcm2drtC6xl(array $M5tou) : void
    {
        $this->SBfza = $M5tou;
    }
    public static function mXvT1oq5cbb($clm2Y, $usaAM, $FgABw, $IQBpu, $N70qa, $mCZQS, $sjEM3)
    {
        return new self($clm2Y->getFilename(), $clm2Y->getExtension(), $usaAM, $FgABw, $N70qa, $mCZQS, count($mCZQS), KidkTsWIjmNMb::UPLOADING, $IQBpu, 0, $sjEM3, []);
    }
    public static function msagmj6oOxB($B5uQ4)
    {
        return 'metadata/' . $B5uQ4 . '.json';
    }
    public function m6JaR9gO77g()
    {
        return 's3' === $this->tcavr ? LrHrisEWQ9E5o::S3 : LrHrisEWQ9E5o::LOCAL;
    }
}
