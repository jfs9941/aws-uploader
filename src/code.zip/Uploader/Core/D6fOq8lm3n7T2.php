<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Contracts\GN9q1LiHnFGKa;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Traits\L5mR6rHm99iIZ;
use Jfs\Uploader\Core\Traits\G5NBCB8i1Emes;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
class D6fOq8lm3n7T2 extends UXdXfw71iQGkx implements RsTEqK0aKnthE
{
    use L5mR6rHm99iIZ;
    use G5NBCB8i1Emes;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $r7rVx, string $NTkTt) : self
    {
        goto puPU2;
        JRUwW:
        $uA7Bz->mf3bcS2aSK5(HGmeWpZQSxAlO::UPLOADING);
        goto YVT2z;
        YVT2z:
        return $uA7Bz;
        goto rkAC7;
        puPU2:
        $uA7Bz = new self(['id' => $r7rVx, 'type' => $NTkTt, 'status' => HGmeWpZQSxAlO::UPLOADING]);
        goto JRUwW;
        rkAC7:
    }
    public function width() : ?int
    {
        goto ctfui;
        ctfui:
        $Evdiw = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto iWpFN;
        iWpFN:
        if (!$Evdiw) {
            goto qSjAO;
        }
        goto AhxT8;
        Xexq9:
        qSjAO:
        goto UV7bz;
        AhxT8:
        return $Evdiw;
        goto Xexq9;
        UV7bz:
        return null;
        goto qjEEI;
        qjEEI:
    }
    public function height() : ?int
    {
        goto ObDID;
        ObDID:
        $Brsit = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto IFU0F;
        IfXPs:
        sazuA:
        goto YM3AW;
        IFU0F:
        if (!$Brsit) {
            goto sazuA;
        }
        goto oE8_U;
        YM3AW:
        return null;
        goto UDZmv;
        oE8_U:
        return $Brsit;
        goto IfXPs;
        UDZmv:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($uA7Bz) {
            goto dqKMM;
            MEFrT:
            D6fOq8lm3n7T2::where('parent_id', $uA7Bz->getAttribute('id'))->update(['thumbnail' => $uA7Bz->getAttributes()['thumbnail'], 'hls_path' => $uA7Bz->getAttributes()['hls_path']]);
            goto ree1t;
            wrkk_:
            return;
            goto DbkX1;
            DbkX1:
            IK6vY:
            goto mOLZ8;
            BF6dx:
            if (!(!array_key_exists('thumbnail', $rqrid) && !array_key_exists('hls_path', $rqrid))) {
                goto IK6vY;
            }
            goto wrkk_;
            ree1t:
            cIq7_:
            goto iQP5L;
            dqKMM:
            $rqrid = $uA7Bz->getDirty();
            goto BF6dx;
            mOLZ8:
            if (!($rqrid['thumbnail'] || $rqrid['hls_path'])) {
                goto cIq7_;
            }
            goto MEFrT;
            iQP5L:
        });
    }
    public function mi1XNSFgzJs()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mcjiHYqyaWo()
    {
        return $this->getAttribute('id');
    }
    public function mo7s2mpNg8m() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto v5yI_;
        w6E3w:
        $VwddT['player_url'] = $qqQzb->resolvePath($this, $this->getAttribute('driver'));
        goto dQopB;
        LlTOB:
        $VwddT['thumbnail'] = $qqQzb->resolveThumbnail($this);
        goto jYVLo;
        jYVLo:
        return $VwddT;
        goto ec3rq;
        yn3MR:
        $VwddT = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $qqQzb->resolvePath($this, $this->getAttribute('driver'))];
        goto vnd_M;
        vnd_M:
        if ($this->getAttribute('hls_path')) {
            goto uVIY0;
        }
        goto w6E3w;
        v5yI_:
        $qqQzb = app(GN9q1LiHnFGKa::class);
        goto yn3MR;
        SqktZ:
        lQSe0:
        goto LlTOB;
        o6mYY:
        $VwddT['player_url'] = $qqQzb->resolvePathForHlsVideo($this, true);
        goto SqktZ;
        dQopB:
        goto lQSe0;
        goto MZmn7;
        MZmn7:
        uVIY0:
        goto o6mYY;
        ec3rq:
    }
    public function getThumbnails()
    {
        goto c4ypT;
        K3wYG:
        $qqQzb = app(GN9q1LiHnFGKa::class);
        goto BkYDU;
        BkYDU:
        return array_map(function ($weLf2) use($qqQzb) {
            return $qqQzb->resolvePath($weLf2);
        }, $XSmFq);
        goto swQF_;
        c4ypT:
        $XSmFq = $this->getAttribute('generated_previews') ?? [];
        goto K3wYG;
        swQF_:
    }
    public static function mn6id2HHGBf(UXdXfw71iQGkx $xlFVb) : D6fOq8lm3n7T2
    {
        goto sWVuu;
        diHGU:
        t5e3a:
        goto J7rCN;
        J7rCN:
        return (new D6fOq8lm3n7T2())->fill($xlFVb->getAttributes());
        goto OQImv;
        sWVuu:
        if (!$xlFVb instanceof D6fOq8lm3n7T2) {
            goto t5e3a;
        }
        goto IGlij;
        IGlij:
        return $xlFVb;
        goto diHGU;
        OQImv:
    }
}
