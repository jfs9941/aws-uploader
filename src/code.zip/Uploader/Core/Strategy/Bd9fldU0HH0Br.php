<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Webmozart\Assert\Assert;
class Bd9fldU0HH0Br implements FileProcessingStrategyInterface
{
    private $rrfwA;
    private $RA1U4;
    private $HnnbE;
    public function __construct($qKtXa, $GNSO9)
    {
        goto M1N3d;
        Ur0SJ:
        $O8uXs = config('upload.post_process_image');
        goto H3HkW;
        H3HkW:
        $this->HnnbE = new $O8uXs($qKtXa, $GNSO9);
        goto vwYX_;
        lu0RN:
        $this->RA1U4 = $GNSO9;
        goto Ur0SJ;
        fLbNo:
        $this->rrfwA = $qKtXa;
        goto lu0RN;
        M1N3d:
        Assert::isInstanceOf($qKtXa, MpPzMcfcRTISZ::class);
        goto fLbNo;
        vwYX_:
    }
    public function process($Q3oHh) : void
    {
        $this->HnnbE->process($Q3oHh);
    }
}
