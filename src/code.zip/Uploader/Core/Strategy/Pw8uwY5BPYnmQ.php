<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Webmozart\Assert\Assert;
class Pw8uwY5BPYnmQ implements FileProcessingStrategyInterface
{
    private $FO7P8;
    private $jYPwH;
    private $iQaN5;
    public function __construct($lu07a, $RxjAn)
    {
        goto Ojhmy;
        c0bGW:
        $this->jYPwH = $RxjAn;
        goto RSY_Z;
        m2LPt:
        $this->iQaN5 = new $yR2IU($lu07a, $RxjAn);
        goto fp16n;
        Ojhmy:
        Assert::isInstanceOf($lu07a, A9olNyGXhDJnA::class);
        goto eaFiM;
        eaFiM:
        $this->FO7P8 = $lu07a;
        goto c0bGW;
        RSY_Z:
        $yR2IU = config('upload.post_process_image');
        goto m2LPt;
        fp16n:
    }
    public function process($o91Cx) : void
    {
        $this->iQaN5->process($o91Cx);
    }
}
