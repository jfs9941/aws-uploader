<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Webmozart\Assert\Assert;
class EyqJ0idd6ccwL implements FileProcessingStrategyInterface
{
    private $vBPoy;
    private $NlhMr;
    private $UjMV4;
    public function __construct($RxSHk, $rS7iQ)
    {
        goto kkqwG;
        tft4g:
        $Jtbi7 = config('upload.post_process_image');
        goto hvjf_;
        Zc3sE:
        $this->NlhMr = $rS7iQ;
        goto tft4g;
        eqCXg:
        $this->vBPoy = $RxSHk;
        goto Zc3sE;
        hvjf_:
        $this->UjMV4 = new $Jtbi7($RxSHk, $rS7iQ);
        goto HQQJz;
        kkqwG:
        Assert::isInstanceOf($RxSHk, JMa7GBaLcnq3D::class);
        goto eqCXg;
        HQQJz:
    }
    public function process($QOcg0) : void
    {
        $this->UjMV4->process($QOcg0);
    }
}
