<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Encoder\NLoWoIWKwVnRR;
class JOFetdPCJuv2m implements FileProcessingStrategyInterface
{
    private $YL1g4;
    private $kSMWq;
    private $UjMV4;
    public function __construct(MxslGSmH9dMgZ $fTkob, NLoWoIWKwVnRR $qiLE2)
    {
        goto xtKRF;
        QL7w0:
        $Jtbi7 = config('upload.post_process_video');
        goto vm_PL;
        xtKRF:
        $this->YL1g4 = $fTkob;
        goto lw5Af;
        lw5Af:
        $this->kSMWq = $qiLE2;
        goto QL7w0;
        vm_PL:
        $this->UjMV4 = new $Jtbi7($fTkob, $qiLE2);
        goto u1NPk;
        u1NPk:
    }
    public function process($QOcg0)
    {
        $this->UjMV4->process($QOcg0);
    }
}
