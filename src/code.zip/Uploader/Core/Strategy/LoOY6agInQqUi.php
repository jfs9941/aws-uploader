<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Webmozart\Assert\Assert;
class LoOY6agInQqUi implements FileProcessingStrategyInterface
{
    private $ER2r9;
    private $tWs0h;
    private $D4NIt;
    public function __construct($Kc1eZ, $ZpGBL)
    {
        goto dn4Gp;
        KrB5i:
        $this->ER2r9 = $Kc1eZ;
        goto g0WSo;
        g0WSo:
        $this->tWs0h = $ZpGBL;
        goto Kl_Ir;
        cBtFV:
        $this->D4NIt = new $emeLM($Kc1eZ, $ZpGBL);
        goto XaAe4;
        Kl_Ir:
        $emeLM = config('upload.post_process_image');
        goto cBtFV;
        dn4Gp:
        Assert::isInstanceOf($Kc1eZ, OjvWwjWRqBzIO::class);
        goto KrB5i;
        XaAe4:
    }
    public function process($wnVK7) : void
    {
        $this->D4NIt->process($wnVK7);
    }
}
