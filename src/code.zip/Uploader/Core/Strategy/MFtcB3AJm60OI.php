<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Encoder\R1OfWFis73GHj;
class MFtcB3AJm60OI implements FileProcessingStrategyInterface
{
    private $tHSMe;
    private $sux6G;
    private $i3_hI;
    public function __construct(GYWdiuSbqNHgT $vd5JT, R1OfWFis73GHj $dJJYg)
    {
        goto xbxvD;
        fZh2y:
        $lsbnW = config('upload.post_process_video');
        goto r_ode;
        xbxvD:
        $this->tHSMe = $vd5JT;
        goto TGoP9;
        r_ode:
        $this->i3_hI = new $lsbnW($vd5JT, $dJJYg);
        goto l27R1;
        TGoP9:
        $this->sux6G = $dJJYg;
        goto fZh2y;
        l27R1:
    }
    public function process($QvKr1)
    {
        $this->i3_hI->process($QvKr1);
    }
}
