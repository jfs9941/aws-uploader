<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Webmozart\Assert\Assert;
class YyFP4ij2U7zE8 implements FileProcessingStrategyInterface
{
    private $gNjEc;
    private $OlWdX;
    private $FTWUu;
    public function __construct($Xxl6q, $GwkoE)
    {
        goto A44u6;
        qqjfI:
        $this->gNjEc = $Xxl6q;
        goto CzeZA;
        xK5Fx:
        $x5Qub = config('upload.post_process_image');
        goto HYETg;
        HYETg:
        $this->FTWUu = new $x5Qub($Xxl6q, $GwkoE);
        goto os2m2;
        A44u6:
        Assert::isInstanceOf($Xxl6q, OcbNsXl9lpteB::class);
        goto qqjfI;
        CzeZA:
        $this->OlWdX = $GwkoE;
        goto xK5Fx;
        os2m2:
    }
    public function process($NsOb8) : void
    {
        $this->FTWUu->process($NsOb8);
    }
}
