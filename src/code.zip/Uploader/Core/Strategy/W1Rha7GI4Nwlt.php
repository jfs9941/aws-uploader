<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Webmozart\Assert\Assert;
class W1Rha7GI4Nwlt implements FileProcessingStrategyInterface
{
    private $BXf9_;
    private $ounZ0;
    private $f70HQ;
    public function __construct($fK3zd, $FiE4q)
    {
        goto d9l_Q;
        F7lUd:
        $this->f70HQ = new $Np_OR($fK3zd, $FiE4q);
        goto QSyeR;
        PnZEu:
        $this->BXf9_ = $fK3zd;
        goto kUcR4;
        IB1KP:
        $Np_OR = config('upload.post_process_image');
        goto F7lUd;
        d9l_Q:
        Assert::isInstanceOf($fK3zd, DsyQbNiy8VgJG::class);
        goto PnZEu;
        kUcR4:
        $this->ounZ0 = $FiE4q;
        goto IB1KP;
        QSyeR:
    }
    public function process($P0HHu) : void
    {
        $this->f70HQ->process($P0HHu);
    }
}
