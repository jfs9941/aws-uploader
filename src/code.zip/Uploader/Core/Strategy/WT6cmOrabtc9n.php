<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Webmozart\Assert\Assert;
class WT6cmOrabtc9n implements FileProcessingStrategyInterface
{
    private $d_YWY;
    private $ScpDq;
    private $Pr65k;
    public function __construct($P2AJQ, $AMB6h)
    {
        goto nC21S;
        F0Dpd:
        $ELIyb = config('upload.post_process_image');
        goto BR1oa;
        yIlYB:
        $this->ScpDq = $AMB6h;
        goto F0Dpd;
        BR1oa:
        $this->Pr65k = new $ELIyb($P2AJQ, $AMB6h);
        goto MlWeU;
        M8Cdr:
        $this->d_YWY = $P2AJQ;
        goto yIlYB;
        nC21S:
        Assert::isInstanceOf($P2AJQ, LGMw063tEE9ZC::class);
        goto M8Cdr;
        MlWeU:
    }
    public function process($J0GfA) : void
    {
        $this->Pr65k->process($J0GfA);
    }
}
