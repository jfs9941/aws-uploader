<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Webmozart\Assert\Assert;
class SvKcXPVKtKJ6x implements FileProcessingStrategyInterface
{
    private $OuExQ;
    private $O9plT;
    private $NNOdt;
    public function __construct($KlHaV, $fjrI6)
    {
        goto enFYa;
        hiXQ1:
        $fO7ua = config('upload.post_process_image');
        goto R1Go3;
        enFYa:
        Assert::isInstanceOf($KlHaV, IQJN6V0t7DC7c::class);
        goto g3MXM;
        R1Go3:
        $this->NNOdt = new $fO7ua($KlHaV, $fjrI6);
        goto oVT80;
        g3MXM:
        $this->OuExQ = $KlHaV;
        goto HcUXT;
        HcUXT:
        $this->O9plT = $fjrI6;
        goto hiXQ1;
        oVT80:
    }
    public function process($mNKxt) : void
    {
        $this->NNOdt->process($mNKxt);
    }
}
