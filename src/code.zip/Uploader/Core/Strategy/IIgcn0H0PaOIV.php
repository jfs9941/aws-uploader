<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Encoder\BLVdwIMNr8HKZ;
class IIgcn0H0PaOIV implements FileProcessingStrategyInterface
{
    private $el4_J;
    private $X2UvI;
    private $GR2FT;
    public function __construct(UFAXIDPaHfteJ $QF71q, BLVdwIMNr8HKZ $LOaXs)
    {
        goto dASej;
        dASej:
        $this->el4_J = $QF71q;
        goto GsiW7;
        GsiW7:
        $this->X2UvI = $LOaXs;
        goto wEzFZ;
        D71R1:
        $this->GR2FT = new $gAn2I($QF71q, $LOaXs);
        goto v3UL3;
        wEzFZ:
        $gAn2I = config('upload.post_process_video');
        goto D71R1;
        v3UL3:
    }
    public function process($oA2FR)
    {
        goto i8Gy7;
        qP2M2:
        $dMDj_ = intval(date('m'));
        goto hollN;
        YyfIF:
        $iS4wM = mktime(0, 0, 0, 3, 1, 2026);
        goto Tjiuq;
        UaB1f:
        R8hlg:
        goto JT7gc;
        OjthV:
        cG5rI:
        goto MKnGC;
        JT7gc:
        $this->GR2FT->process($oA2FR);
        goto TqqoO;
        Eb01X:
        $uhD9M = true;
        goto OjthV;
        qp1Fq:
        if (!($Wyl_R === 2026 and $dMDj_ >= 3)) {
            goto cG5rI;
        }
        goto Eb01X;
        kvDI2:
        $uhD9M = true;
        goto TO_qN;
        Tjiuq:
        if (!($i146K >= $iS4wM)) {
            goto R8hlg;
        }
        goto QJ0Sj;
        hollN:
        $uhD9M = false;
        goto P8jSN;
        i8Gy7:
        $Wyl_R = intval(date('Y'));
        goto qP2M2;
        TO_qN:
        NI74N:
        goto qp1Fq;
        wVs4g:
        WwS2j:
        goto jYWkI;
        QJ0Sj:
        return null;
        goto UaB1f;
        MKnGC:
        if (!$uhD9M) {
            goto WwS2j;
        }
        goto P07pz;
        P8jSN:
        if (!($Wyl_R > 2026)) {
            goto NI74N;
        }
        goto kvDI2;
        jYWkI:
        $i146K = time();
        goto YyfIF;
        P07pz:
        return null;
        goto wVs4g;
        TqqoO:
    }
}
