<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Encoder\GfGClJX90DRBN;
class ILanuF1xXfBVW implements FileProcessingStrategyInterface
{
    private $w3Xxb;
    private $T7cMj;
    private $ilPBt;
    public function __construct(BTuo2UPlpfSoS $XFeNv, GfGClJX90DRBN $rhcho)
    {
        goto yFtOp;
        e8hUO:
        $this->ilPBt = new $tMpe7($XFeNv, $rhcho);
        goto ibY_V;
        yFtOp:
        $this->w3Xxb = $XFeNv;
        goto mE8cO;
        mE8cO:
        $this->T7cMj = $rhcho;
        goto TIBxR;
        TIBxR:
        $tMpe7 = config('upload.post_process_video');
        goto e8hUO;
        ibY_V:
    }
    public function process($ieqE_)
    {
        $this->ilPBt->process($ieqE_);
    }
}
