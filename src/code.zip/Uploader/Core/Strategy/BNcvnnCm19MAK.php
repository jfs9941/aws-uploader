<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Encoder\QTx5zGpV1D5nP;
class BNcvnnCm19MAK implements FileProcessingStrategyInterface
{
    private $FAU43;
    private $FsAB9;
    private $hjqPU;
    public function __construct(A9R6iJFlMGSBV $yZXjN, QTx5zGpV1D5nP $pXjq4)
    {
        goto aVQFT;
        aVQFT:
        $this->FAU43 = $yZXjN;
        goto n6ixc;
        n6ixc:
        $this->FsAB9 = $pXjq4;
        goto t6LrX;
        t6LrX:
        $x5wH9 = config('upload.post_process_video');
        goto Wl6JA;
        Wl6JA:
        $this->hjqPU = new $x5wH9($yZXjN, $pXjq4);
        goto ZkGD6;
        ZkGD6:
    }
    public function process($b8sYW)
    {
        $this->hjqPU->process($b8sYW);
    }
}
