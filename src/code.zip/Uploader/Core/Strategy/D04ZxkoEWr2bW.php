<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Webmozart\Assert\Assert;
class D04ZxkoEWr2bW implements FileProcessingStrategyInterface
{
    private $i797d;
    private $u0rqC;
    private $Y0p5m;
    public function __construct($CPHMS, $XGlwJ)
    {
        goto q1zmZ;
        Wx29C:
        $this->i797d = $CPHMS;
        goto t9K0G;
        t9K0G:
        $this->u0rqC = $XGlwJ;
        goto xTzfK;
        q1zmZ:
        Assert::isInstanceOf($CPHMS, NBWuSM65HseqY::class);
        goto Wx29C;
        xTzfK:
        $fFHxQ = config('upload.post_process_image');
        goto glDQ5;
        glDQ5:
        $this->Y0p5m = new $fFHxQ($CPHMS, $XGlwJ);
        goto oxxeG;
        oxxeG:
    }
    public function process($CSrFA) : void
    {
        $this->Y0p5m->process($CSrFA);
    }
}
