<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Webmozart\Assert\Assert;
class D8dXWNMG5l50j implements FileProcessingStrategyInterface
{
    private $swunD;
    private $FBCkB;
    private $K9wtV;
    public function __construct($VWXEV, $wNMDX)
    {
        goto cy2Dd;
        cy2Dd:
        Assert::isInstanceOf($VWXEV, XK5kReLMTU1ob::class);
        goto Jtuiq;
        Tcu35:
        $this->FBCkB = $wNMDX;
        goto RLCew;
        Jtuiq:
        $this->swunD = $VWXEV;
        goto Tcu35;
        RLCew:
        $GmLMT = config('upload.post_process_image');
        goto VyLDK;
        VyLDK:
        $this->K9wtV = new $GmLMT($VWXEV, $wNMDX);
        goto GBCcG;
        GBCcG:
    }
    public function process($MXqzr) : void
    {
        $this->K9wtV->process($MXqzr);
    }
}
