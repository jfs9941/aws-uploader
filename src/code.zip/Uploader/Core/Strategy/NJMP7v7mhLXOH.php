<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Encoder\PERAjoCXLxFkm;
class NJMP7v7mhLXOH implements FileProcessingStrategyInterface
{
    private $W2x3I;
    private $L9vAy;
    private $fiwnu;
    public function __construct(UkjvJ3zCZNh6F $eYbzj, PERAjoCXLxFkm $Sm2e5)
    {
        goto K_itU;
        WW8JX:
        $this->L9vAy = $Sm2e5;
        goto kulyz;
        tV1fX:
        $this->fiwnu = new $Un_c_($eYbzj, $Sm2e5);
        goto uQW5Z;
        kulyz:
        $Un_c_ = config('upload.post_process_video');
        goto tV1fX;
        K_itU:
        $this->W2x3I = $eYbzj;
        goto WW8JX;
        uQW5Z:
    }
    public function process($ksgR4)
    {
        $this->fiwnu->process($ksgR4);
    }
}
