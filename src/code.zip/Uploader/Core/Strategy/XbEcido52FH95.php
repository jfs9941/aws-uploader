<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Webmozart\Assert\Assert;
class XbEcido52FH95 implements FileProcessingStrategyInterface
{
    private $ANypw;
    private $yvtQF;
    private $vKiIA;
    public function __construct($oaIJp, $KF9cQ)
    {
        goto lYDbX;
        M07dH:
        $this->yvtQF = $KF9cQ;
        goto qELpd;
        qELpd:
        $ggplD = config('upload.post_process_image');
        goto mu_Py;
        ZIqMH:
        $this->ANypw = $oaIJp;
        goto M07dH;
        mu_Py:
        $this->vKiIA = new $ggplD($oaIJp, $KF9cQ);
        goto I69CH;
        lYDbX:
        Assert::isInstanceOf($oaIJp, IZ5shp3JHuftD::class);
        goto ZIqMH;
        I69CH:
    }
    public function process($qPpW3) : void
    {
        $this->vKiIA->process($qPpW3);
    }
}
