<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Webmozart\Assert\Assert;
class Lb9YM0rWVQC1D implements FileProcessingStrategyInterface
{
    private $PSJVl;
    private $qxf7d;
    private $ZOecL;
    public function __construct($fe3pc, $i6jr_)
    {
        goto sq1qn;
        sq1qn:
        Assert::isInstanceOf($fe3pc, YPgQPiPQjMu1g::class);
        goto EEHzL;
        dVpm7:
        $this->ZOecL = new $Clrx0($fe3pc, $i6jr_);
        goto pkMdu;
        EEHzL:
        $this->PSJVl = $fe3pc;
        goto TdbcO;
        TdbcO:
        $this->qxf7d = $i6jr_;
        goto CHbgw;
        CHbgw:
        $Clrx0 = config('upload.post_process_image');
        goto dVpm7;
        pkMdu:
    }
    public function process($tImt5) : void
    {
        $this->ZOecL->process($tImt5);
    }
}
