<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Webmozart\Assert\Assert;
class POiLiwL4ziX4Y implements FileProcessingStrategyInterface
{
    private $Z7Bev;
    private $t4ksb;
    private $msRiS;
    public function __construct($MpgR7, $Ocj5L)
    {
        goto gUOWs;
        Fo5Qz:
        $this->Z7Bev = $MpgR7;
        goto kr3AN;
        kr3AN:
        $this->t4ksb = $Ocj5L;
        goto lGPoi;
        gUOWs:
        Assert::isInstanceOf($MpgR7, Kx3NMUJqFpl5Q::class);
        goto Fo5Qz;
        lGPoi:
        $IJVAg = config('upload.post_process_image');
        goto W871o;
        W871o:
        $this->msRiS = new $IJVAg($MpgR7, $Ocj5L);
        goto SUxcB;
        SUxcB:
    }
    public function process($czrmK) : void
    {
        $this->msRiS->process($czrmK);
    }
}
