<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Webmozart\Assert\Assert;
class B4ZF0yQFWWc9S implements FileProcessingStrategyInterface
{
    private $DL9Cp;
    private $g83AR;
    private $HPfv_;
    public function __construct($cDDGh, $Fsmva)
    {
        goto ymah7;
        VkAMH:
        $this->DL9Cp = $cDDGh;
        goto WoB65;
        EL0v9:
        $GVwCX = config('upload.post_process_image');
        goto Rg2IH;
        Rg2IH:
        $this->HPfv_ = new $GVwCX($cDDGh, $Fsmva);
        goto Ne4an;
        ymah7:
        Assert::isInstanceOf($cDDGh, KyoDVfv3eGItF::class);
        goto VkAMH;
        WoB65:
        $this->g83AR = $Fsmva;
        goto EL0v9;
        Ne4an:
    }
    public function process($Ig7dJ) : void
    {
        $this->HPfv_->process($Ig7dJ);
    }
}
