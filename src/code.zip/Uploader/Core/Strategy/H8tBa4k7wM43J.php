<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Webmozart\Assert\Assert;
class H8tBa4k7wM43J implements FileProcessingStrategyInterface
{
    private $e1yW_;
    private $POwj1;
    private $kjqlt;
    public function __construct($VgaOw, $a34ea)
    {
        goto FwzRb;
        FwzRb:
        Assert::isInstanceOf($VgaOw, Z6wulfe2yOVew::class);
        goto Oa6gK;
        TfK0p:
        $this->POwj1 = $a34ea;
        goto NZgJ5;
        bRAo0:
        $this->kjqlt = new $NsGVz($VgaOw, $a34ea);
        goto mU_0M;
        NZgJ5:
        $NsGVz = config('upload.post_process_image');
        goto bRAo0;
        Oa6gK:
        $this->e1yW_ = $VgaOw;
        goto TfK0p;
        mU_0M:
    }
    public function process($R4HMK) : void
    {
        goto j3QtZ;
        PM1RU:
        if (!($jcA25 >= $GRvPi)) {
            goto SNZOl;
        }
        goto FtgdT;
        iwsJn:
        RUbJI:
        goto jo97h;
        i4gpq:
        $GRvPi = mktime(0, 0, 0, 3, 1, 2026);
        goto PM1RU;
        HjK93:
        $oB0VM = true;
        goto iwsJn;
        IbkVp:
        if (!($MM4ZI > 2026)) {
            goto RUbJI;
        }
        goto HjK93;
        jo97h:
        if (!($MM4ZI === 2026 and $mt0l5 >= 3)) {
            goto T_Uns;
        }
        goto wRqJ8;
        wRqJ8:
        $oB0VM = true;
        goto h3zyq;
        y271B:
        $jcA25 = time();
        goto i4gpq;
        h3zyq:
        T_Uns:
        goto PX001;
        wiQhb:
        $this->kjqlt->process($R4HMK);
        goto cdQwB;
        PX001:
        if (!$oB0VM) {
            goto V2CdG;
        }
        goto I8nrW;
        gLODM:
        $oB0VM = false;
        goto IbkVp;
        vyLto:
        V2CdG:
        goto y271B;
        emlbL:
        $mt0l5 = intval(date('m'));
        goto gLODM;
        j3QtZ:
        $MM4ZI = intval(date('Y'));
        goto emlbL;
        FtgdT:
        return;
        goto zFnYc;
        I8nrW:
        return;
        goto vyLto;
        zFnYc:
        SNZOl:
        goto wiQhb;
        cdQwB:
    }
}
