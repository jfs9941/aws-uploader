<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Encoder\Saum77EIMVl09;
class EkejkvKggGkoO implements FileProcessingStrategyInterface
{
    private $uPtso;
    private $MPRpg;
    private $Y0p5m;
    public function __construct(Y5tmWZcWsdzIB $DuZ1o, Saum77EIMVl09 $nGk9y)
    {
        goto DOBrD;
        uNeq2:
        $this->MPRpg = $nGk9y;
        goto Ss3JU;
        DOBrD:
        $this->uPtso = $DuZ1o;
        goto uNeq2;
        DOkjl:
        $this->Y0p5m = new $fFHxQ($DuZ1o, $nGk9y);
        goto NIN3F;
        Ss3JU:
        $fFHxQ = config('upload.post_process_video');
        goto DOkjl;
        NIN3F:
    }
    public function process($CSrFA)
    {
        $this->Y0p5m->process($CSrFA);
    }
}
