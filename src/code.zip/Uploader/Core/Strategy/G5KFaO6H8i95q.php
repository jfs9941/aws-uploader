<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Encoder\EVSDjuMy24t33;
class G5KFaO6H8i95q implements FileProcessingStrategyInterface
{
    private $JelaL;
    private $yFiOT;
    private $NNOdt;
    public function __construct(EeWreEFdq3Xdf $lamFK, EVSDjuMy24t33 $vulhD)
    {
        goto jCjlU;
        BeHiY:
        $fO7ua = config('upload.post_process_video');
        goto PrM_a;
        PrM_a:
        $this->NNOdt = new $fO7ua($lamFK, $vulhD);
        goto xJn9N;
        gEgAx:
        $this->yFiOT = $vulhD;
        goto BeHiY;
        jCjlU:
        $this->JelaL = $lamFK;
        goto gEgAx;
        xJn9N:
    }
    public function process($mNKxt)
    {
        $this->NNOdt->process($mNKxt);
    }
}
