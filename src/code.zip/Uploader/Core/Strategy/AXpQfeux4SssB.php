<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Webmozart\Assert\Assert;
class AXpQfeux4SssB implements FileProcessingStrategyInterface
{
    private $SVB2r;
    private $rvU5Z;
    private $HteQ2;
    public function __construct($AvW7Y, $taWvo)
    {
        goto IDR14;
        p0WS8:
        $this->HteQ2 = new $buNns($AvW7Y, $taWvo);
        goto MFOZB;
        kGqX8:
        $buNns = config('upload.post_process_image');
        goto p0WS8;
        vTYQY:
        $this->rvU5Z = $taWvo;
        goto kGqX8;
        IDR14:
        Assert::isInstanceOf($AvW7Y, Q48IcpSr3UpAT::class);
        goto OTSiQ;
        OTSiQ:
        $this->SVB2r = $AvW7Y;
        goto vTYQY;
        MFOZB:
    }
    public function process($fOBJe) : void
    {
        $this->HteQ2->process($fOBJe);
    }
}
