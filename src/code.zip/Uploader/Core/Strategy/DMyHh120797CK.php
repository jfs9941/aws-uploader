<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Webmozart\Assert\Assert;
class DMyHh120797CK implements FileProcessingStrategyInterface
{
    private $cg2Bl;
    private $WStj_;
    private $gUH8V;
    public function __construct($dmeuh, $ky5s4)
    {
        goto ENyWj;
        h1l6s:
        $this->WStj_ = $ky5s4;
        goto yICp4;
        yICp4:
        $IFUzP = config('upload.post_process_image');
        goto m5Xun;
        p7AaK:
        $this->cg2Bl = $dmeuh;
        goto h1l6s;
        ENyWj:
        Assert::isInstanceOf($dmeuh, C6ftQJKUZRJIp::class);
        goto p7AaK;
        m5Xun:
        $this->gUH8V = new $IFUzP($dmeuh, $ky5s4);
        goto QIeeW;
        QIeeW:
    }
    public function process($CHBXo) : void
    {
        $this->gUH8V->process($CHBXo);
    }
}
