<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Webmozart\Assert\Assert;
class Wod91e1taEuyw implements FileProcessingStrategyInterface
{
    private $xTgpE;
    private $EWW4J;
    private $fiwnu;
    public function __construct($anrPh, $rXnFu)
    {
        goto gbmS1;
        CJQ1y:
        $Un_c_ = config('upload.post_process_image');
        goto uwkU6;
        gbmS1:
        Assert::isInstanceOf($anrPh, WKX0l52zWptlF::class);
        goto DFjqx;
        adpxk:
        $this->EWW4J = $rXnFu;
        goto CJQ1y;
        uwkU6:
        $this->fiwnu = new $Un_c_($anrPh, $rXnFu);
        goto uLeLO;
        DFjqx:
        $this->xTgpE = $anrPh;
        goto adpxk;
        uLeLO:
    }
    public function process($ksgR4) : void
    {
        $this->fiwnu->process($ksgR4);
    }
}
