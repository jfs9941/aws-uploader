<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Webmozart\Assert\Assert;
class SzqF8Kv00GoJQ implements FileProcessingStrategyInterface
{
    private $G4IS_;
    private $INTZb;
    private $XJ0wK;
    public function __construct($xobEP, $K704z)
    {
        goto g4AEP;
        VxKZ8:
        $this->G4IS_ = $xobEP;
        goto LMqDQ;
        g4AEP:
        Assert::isInstanceOf($xobEP, Sf7MFJ2wUSx2k::class);
        goto VxKZ8;
        A2rx_:
        $this->XJ0wK = new $QFHsG($xobEP, $K704z);
        goto mjrl2;
        d5NCy:
        $QFHsG = config('upload.post_process_image');
        goto A2rx_;
        LMqDQ:
        $this->INTZb = $K704z;
        goto d5NCy;
        mjrl2:
    }
    public function process($tMFSs) : void
    {
        $this->XJ0wK->process($tMFSs);
    }
}
