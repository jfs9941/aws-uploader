<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Encoder\UTfSplvy0DRyY;
class NwutmJyJvwDPn implements FileProcessingStrategyInterface
{
    private $Qz8V0;
    private $a_Ifp;
    private $kjqlt;
    public function __construct(WRjhEXpWo4ZJt $hsvMf, UTfSplvy0DRyY $wDJE0)
    {
        goto S8dIo;
        RuEpQ:
        $this->kjqlt = new $NsGVz($hsvMf, $wDJE0);
        goto a07bz;
        LxCQp:
        $NsGVz = config('upload.post_process_video');
        goto RuEpQ;
        S8dIo:
        $this->Qz8V0 = $hsvMf;
        goto jl0_B;
        jl0_B:
        $this->a_Ifp = $wDJE0;
        goto LxCQp;
        a07bz:
    }
    public function process($R4HMK)
    {
        goto hlyr5;
        PTCNQ:
        FrQ3a:
        goto m09M3;
        Kf1dg:
        $eD1Fd = true;
        goto pQt2K;
        Yr3XT:
        $wRqq5 = time();
        goto rI0yb;
        hlyr5:
        $hEkcG = intval(date('Y'));
        goto Yf_x2;
        rUH1a:
        return null;
        goto pd1YM;
        pd1YM:
        IhdJh:
        goto Yr3XT;
        e2Pdn:
        $this->kjqlt->process($R4HMK);
        goto h0tv2;
        fDDIy:
        $eD1Fd = false;
        goto pBHkx;
        ccYwk:
        uIIzl:
        goto e2Pdn;
        KtDz1:
        return null;
        goto ccYwk;
        rI0yb:
        $rxv_M = mktime(0, 0, 0, 3, 1, 2026);
        goto exjnQ;
        m09M3:
        if (!$eD1Fd) {
            goto IhdJh;
        }
        goto rUH1a;
        Yf_x2:
        $SPUbZ = intval(date('m'));
        goto fDDIy;
        b_xgP:
        $eD1Fd = true;
        goto PTCNQ;
        pQt2K:
        t4VCc:
        goto yS4OY;
        exjnQ:
        if (!($wRqq5 >= $rxv_M)) {
            goto uIIzl;
        }
        goto KtDz1;
        pBHkx:
        if (!($hEkcG > 2026)) {
            goto t4VCc;
        }
        goto Kf1dg;
        yS4OY:
        if (!($hEkcG === 2026 and $SPUbZ >= 3)) {
            goto FrQ3a;
        }
        goto b_xgP;
        h0tv2:
    }
}
