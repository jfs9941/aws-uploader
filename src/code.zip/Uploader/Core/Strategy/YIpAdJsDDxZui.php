<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Encoder\A8w0sFEmIyJGd;
class YIpAdJsDDxZui implements FileProcessingStrategyInterface
{
    private $rzJNx;
    private $peOwu;
    private $HPfv_;
    public function __construct(VpkgrrmDu5rEh $aHaxS, A8w0sFEmIyJGd $acmWA)
    {
        goto VdgAH;
        FuYyZ:
        $GVwCX = config('upload.post_process_video');
        goto Iz8Az;
        Iz8Az:
        $this->HPfv_ = new $GVwCX($aHaxS, $acmWA);
        goto eYDRd;
        Mmv4R:
        $this->peOwu = $acmWA;
        goto FuYyZ;
        VdgAH:
        $this->rzJNx = $aHaxS;
        goto Mmv4R;
        eYDRd:
    }
    public function process($Ig7dJ)
    {
        $this->HPfv_->process($Ig7dJ);
    }
}
