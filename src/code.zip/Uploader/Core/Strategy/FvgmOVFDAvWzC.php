<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Encoder\PBaAMCftTA2PY;
class FvgmOVFDAvWzC implements FileProcessingStrategyInterface
{
    private $UlzBi;
    private $aH44f;
    private $RcPhL;
    public function __construct(FpdzXEk0mryCJ $JfLWA, PBaAMCftTA2PY $ikeQ2)
    {
        goto KX6lH;
        x9zc7:
        $this->RcPhL = new $pFVwC($JfLWA, $ikeQ2);
        goto SOyc4;
        hY4MS:
        $pFVwC = config('upload.post_process_video');
        goto x9zc7;
        KX6lH:
        $this->UlzBi = $JfLWA;
        goto NcAlH;
        NcAlH:
        $this->aH44f = $ikeQ2;
        goto hY4MS;
        SOyc4:
    }
    public function process($ATiun)
    {
        $this->RcPhL->process($ATiun);
    }
}
