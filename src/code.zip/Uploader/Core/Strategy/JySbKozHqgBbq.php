<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Encoder\U69m2hVAaudAN;
class JySbKozHqgBbq implements FileProcessingStrategyInterface
{
    private $CRCCL;
    private $yWdZf;
    private $HteQ2;
    public function __construct(M0ises9bx8zn4 $oS5x2, U69m2hVAaudAN $r5FB6)
    {
        goto h3bHG;
        h3bHG:
        $this->CRCCL = $oS5x2;
        goto Q2Iqp;
        Q2Iqp:
        $this->yWdZf = $r5FB6;
        goto oW6Xj;
        jBEg2:
        $this->HteQ2 = new $buNns($oS5x2, $r5FB6);
        goto Cj4ob;
        oW6Xj:
        $buNns = config('upload.post_process_video');
        goto jBEg2;
        Cj4ob:
    }
    public function process($fOBJe)
    {
        $this->HteQ2->process($fOBJe);
    }
}
