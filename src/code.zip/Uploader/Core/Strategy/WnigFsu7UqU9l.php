<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Encoder\XeMVcGXMtTgrJ;
class WnigFsu7UqU9l implements FileProcessingStrategyInterface
{
    private $tHqx1;
    private $QHqex;
    private $K9wtV;
    public function __construct(YeOKDEuyU49Av $Zpy0I, XeMVcGXMtTgrJ $zxYNZ)
    {
        goto dO25F;
        M00CY:
        $this->K9wtV = new $GmLMT($Zpy0I, $zxYNZ);
        goto ErXoC;
        dO25F:
        $this->tHqx1 = $Zpy0I;
        goto FeOcj;
        FeOcj:
        $this->QHqex = $zxYNZ;
        goto vxSAJ;
        vxSAJ:
        $GmLMT = config('upload.post_process_video');
        goto M00CY;
        ErXoC:
    }
    public function process($MXqzr)
    {
        $this->K9wtV->process($MXqzr);
    }
}
