<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Encoder\FKhlIfmeSlJUJ;
class OWUwvan4nBiqE implements FileProcessingStrategyInterface
{
    private $Y74ZT;
    private $yx7pM;
    private $PI_7f;
    public function __construct(QLOMBcv8tw1Qd $XrW52, FKhlIfmeSlJUJ $eny8I)
    {
        goto hMlYc;
        hMlYc:
        $this->Y74ZT = $XrW52;
        goto v5RpQ;
        sHRSp:
        $this->PI_7f = new $wkA_V($XrW52, $eny8I);
        goto J3OdY;
        v5RpQ:
        $this->yx7pM = $eny8I;
        goto CcRlI;
        CcRlI:
        $wkA_V = config('upload.post_process_video');
        goto sHRSp;
        J3OdY:
    }
    public function process($GJeeb)
    {
        $this->PI_7f->process($GJeeb);
    }
}
