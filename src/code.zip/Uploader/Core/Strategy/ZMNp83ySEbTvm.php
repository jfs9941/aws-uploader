<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Strategy; use Jfs\Exposed\FileProcessingStrategyInterface; use Jfs\Uploader\Core\DIYGIfCt7MLhm; use Jfs\Uploader\Encoder\IYOt5zjnxxuHq; class ZMNp83ySEbTvm implements FileProcessingStrategyInterface { private $gxTQn; private $xSTt3; private $LHBlp; public function __construct(DIYGIfCt7MLhm $mzQW8, IYOt5zjnxxuHq $tvL3P) { goto sfm1v; ntWGk: $this->LHBlp = new $YEZ0r($mzQW8, $tvL3P); goto SKG32; tq0Xl: $this->xSTt3 = $tvL3P; goto U5J2l; sfm1v: $this->gxTQn = $mzQW8; goto tq0Xl; U5J2l: $YEZ0r = config('upload.post_process_video'); goto ntWGk; SKG32: } public function process($PT8Zt) { $this->LHBlp->process($PT8Zt); } }
