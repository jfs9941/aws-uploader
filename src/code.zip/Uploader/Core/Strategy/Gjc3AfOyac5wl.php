<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Webmozart\Assert\Assert;
class Gjc3AfOyac5wl implements FileProcessingStrategyInterface
{
    private $Mafyn;
    private $qMX0W;
    private $qEQGy;
    public function __construct($h4i8i, $v5VWU)
    {
        goto Yfjrl;
        S2FHU:
        $A6TQ4 = config('upload.post_process_image');
        goto WLnv1;
        WLnv1:
        $this->qEQGy = new $A6TQ4($h4i8i, $v5VWU);
        goto hrdKD;
        hmz3o:
        $this->Mafyn = $h4i8i;
        goto MGp0p;
        Yfjrl:
        Assert::isInstanceOf($h4i8i, VPGaYsuFJzbQ0::class);
        goto hmz3o;
        MGp0p:
        $this->qMX0W = $v5VWU;
        goto S2FHU;
        hrdKD:
    }
    public function process($tYQyn) : void
    {
        $this->qEQGy->process($tYQyn);
    }
}
