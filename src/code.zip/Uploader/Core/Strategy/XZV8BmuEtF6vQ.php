<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Webmozart\Assert\Assert;
class XZV8BmuEtF6vQ implements FileProcessingStrategyInterface
{
    private $uJiIx;
    private $CV_ZV;
    private $PI_7f;
    public function __construct($tCWWG, $bJnIM)
    {
        goto Y0Xlg;
        VacOh:
        $this->PI_7f = new $wkA_V($tCWWG, $bJnIM);
        goto j39yL;
        I8ozr:
        $this->uJiIx = $tCWWG;
        goto YMBwq;
        YMBwq:
        $this->CV_ZV = $bJnIM;
        goto sSmFu;
        sSmFu:
        $wkA_V = config('upload.post_process_image');
        goto VacOh;
        Y0Xlg:
        Assert::isInstanceOf($tCWWG, QFoN7Ibbm93if::class);
        goto I8ozr;
        j39yL:
    }
    public function process($GJeeb) : void
    {
        $this->PI_7f->process($GJeeb);
    }
}
