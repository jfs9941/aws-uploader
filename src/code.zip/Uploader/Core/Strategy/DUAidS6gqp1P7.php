<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Encoder\O4lVkPvpn6cme;
class DUAidS6gqp1P7 implements FileProcessingStrategyInterface
{
    private $KRdTC;
    private $pcru5;
    private $dNIpE;
    public function __construct(X5WvqPHlZPq50 $QCHmE, O4lVkPvpn6cme $hNWjg)
    {
        goto qvuq1;
        pz0QF:
        $this->pcru5 = $hNWjg;
        goto zNtkj;
        qvuq1:
        $this->KRdTC = $QCHmE;
        goto pz0QF;
        zomTw:
        $this->dNIpE = new $BPzz_($QCHmE, $hNWjg);
        goto NHZFg;
        zNtkj:
        $BPzz_ = config('upload.post_process_video');
        goto zomTw;
        NHZFg:
    }
    public function process($vfRhE)
    {
        $this->dNIpE->process($vfRhE);
    }
}
