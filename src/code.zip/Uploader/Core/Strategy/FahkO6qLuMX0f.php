<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\UZjgdpyMf06F7;
use Webmozart\Assert\Assert;
class FahkO6qLuMX0f implements FileProcessingStrategyInterface
{
    private $Ji2PH;
    private $o5A8A;
    private $I9rLs;
    public function __construct($ab1g_, $VtGhn)
    {
        goto rPeSt;
        oGLID:
        $gDlwQ = config('upload.post_process_image');
        goto ExcHh;
        ExcHh:
        $this->I9rLs = new $gDlwQ($ab1g_, $VtGhn);
        goto gJxF5;
        cpd38:
        $this->Ji2PH = $ab1g_;
        goto GiszQ;
        GiszQ:
        $this->o5A8A = $VtGhn;
        goto oGLID;
        rPeSt:
        Assert::isInstanceOf($ab1g_, ID6EZw1DKfqu4::class);
        goto cpd38;
        gJxF5:
    }
    public function process($LM9ev) : void
    {
        $this->I9rLs->process($LM9ev);
    }
}
