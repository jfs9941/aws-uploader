<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Encoder\HYDAkFMesEGUF;
class KBMQV81FQOd78 implements FileProcessingStrategyInterface
{
    private $ekD5L;
    private $avxmF;
    private $vKiIA;
    public function __construct(LxwvVLXJMU3yo $bKijV, HYDAkFMesEGUF $EEJLx)
    {
        goto ubS2g;
        ZH0A7:
        $this->vKiIA = new $ggplD($bKijV, $EEJLx);
        goto xvBeV;
        EBEsc:
        $ggplD = config('upload.post_process_video');
        goto ZH0A7;
        ubS2g:
        $this->ekD5L = $bKijV;
        goto PTBKG;
        PTBKG:
        $this->avxmF = $EEJLx;
        goto EBEsc;
        xvBeV:
    }
    public function process($qPpW3)
    {
        $this->vKiIA->process($qPpW3);
    }
}
