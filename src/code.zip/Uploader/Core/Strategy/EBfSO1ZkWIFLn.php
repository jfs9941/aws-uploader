<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Webmozart\Assert\Assert;
class EBfSO1ZkWIFLn implements FileProcessingStrategyInterface
{
    private $sGPVx;
    private $czzDp;
    private $i3_hI;
    public function __construct($kHreC, $KKAWP)
    {
        goto SKuse;
        mEQ4N:
        $this->czzDp = $KKAWP;
        goto s1MKk;
        SKuse:
        Assert::isInstanceOf($kHreC, FNGNxcyxjaxBG::class);
        goto M2VGw;
        PQJl9:
        $this->i3_hI = new $lsbnW($kHreC, $KKAWP);
        goto mXwBj;
        M2VGw:
        $this->sGPVx = $kHreC;
        goto mEQ4N;
        s1MKk:
        $lsbnW = config('upload.post_process_image');
        goto PQJl9;
        mXwBj:
    }
    public function process($QvKr1) : void
    {
        $this->i3_hI->process($QvKr1);
    }
}
