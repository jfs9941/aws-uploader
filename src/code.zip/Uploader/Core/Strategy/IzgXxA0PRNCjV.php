<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Encoder\QuF8Qm4j71NF7;
class IzgXxA0PRNCjV implements FileProcessingStrategyInterface
{
    private $x_mW0;
    private $Pmf63;
    private $FTWUu;
    public function __construct(KO2pC9qLVd4GD $cZ20c, QuF8Qm4j71NF7 $f_gqD)
    {
        goto kqQ4t;
        kqQ4t:
        $this->x_mW0 = $cZ20c;
        goto aYRt4;
        aYRt4:
        $this->Pmf63 = $f_gqD;
        goto YE1ex;
        djUoF:
        $this->FTWUu = new $x5Qub($cZ20c, $f_gqD);
        goto jJnad;
        YE1ex:
        $x5Qub = config('upload.post_process_video');
        goto djUoF;
        jJnad:
    }
    public function process($NsOb8)
    {
        $this->FTWUu->process($NsOb8);
    }
}
