<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Encoder\V6kCroy78Tmzg;
class BZm8VQKCy3Ezl implements FileProcessingStrategyInterface
{
    private $rWNmT;
    private $Ye4pt;
    private $SxY74;
    public function __construct(Q0JnJtyNI6T0p $B4_PH, V6kCroy78Tmzg $xR2oQ)
    {
        goto g4TOr;
        Ci1Oy:
        $this->Ye4pt = $xR2oQ;
        goto dK2YZ;
        eUJx1:
        $this->SxY74 = new $ohyCs($B4_PH, $xR2oQ);
        goto rQdHl;
        dK2YZ:
        $ohyCs = config('upload.post_process_video');
        goto eUJx1;
        g4TOr:
        $this->rWNmT = $B4_PH;
        goto Ci1Oy;
        rQdHl:
    }
    public function process($PBgm2)
    {
        $this->SxY74->process($PBgm2);
    }
}
