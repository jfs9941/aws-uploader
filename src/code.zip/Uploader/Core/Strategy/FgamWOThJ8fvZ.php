<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Encoder\OIG3Aes8wHMT8;
class FgamWOThJ8fvZ implements FileProcessingStrategyInterface
{
    private $FKp2w;
    private $Q8cxL;
    private $TvTF0;
    public function __construct(PaQmIZL22EnpA $Qw86m, OIG3Aes8wHMT8 $qTc4J)
    {
        goto yGFUQ;
        yGFUQ:
        $this->FKp2w = $Qw86m;
        goto SscT7;
        SscT7:
        $this->Q8cxL = $qTc4J;
        goto V37_q;
        V37_q:
        $snXNa = config('upload.post_process_video');
        goto CX2Ud;
        CX2Ud:
        $this->TvTF0 = new $snXNa($Qw86m, $qTc4J);
        goto sLYib;
        sLYib:
    }
    public function process($pbBGy)
    {
        $this->TvTF0->process($pbBGy);
    }
}
