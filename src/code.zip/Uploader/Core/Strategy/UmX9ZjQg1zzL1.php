<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Encoder\GYeGOleAx46En;
class UmX9ZjQg1zzL1 implements FileProcessingStrategyInterface
{
    private $galgc;
    private $oYGLE;
    private $qEQGy;
    public function __construct(A7djqU0sacoRX $fxrDr, GYeGOleAx46En $ilcYW)
    {
        goto slHR_;
        slHR_:
        $this->galgc = $fxrDr;
        goto s_i3X;
        VVU66:
        $this->qEQGy = new $A6TQ4($fxrDr, $ilcYW);
        goto l1ywE;
        s_i3X:
        $this->oYGLE = $ilcYW;
        goto hLNaK;
        hLNaK:
        $A6TQ4 = config('upload.post_process_video');
        goto VVU66;
        l1ywE:
    }
    public function process($tYQyn)
    {
        $this->qEQGy->process($tYQyn);
    }
}
