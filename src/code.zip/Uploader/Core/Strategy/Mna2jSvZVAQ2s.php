<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Encoder\Suk3MOIJcOQzt;
class Mna2jSvZVAQ2s implements FileProcessingStrategyInterface
{
    private $k_NLk;
    private $TXCkW;
    private $D4NIt;
    public function __construct(HWHmqgxgfYrsZ $jZqB7, Suk3MOIJcOQzt $wbDY2)
    {
        goto DxSKK;
        sNP8i:
        $this->D4NIt = new $emeLM($jZqB7, $wbDY2);
        goto q_t0a;
        EwvT9:
        $emeLM = config('upload.post_process_video');
        goto sNP8i;
        DxSKK:
        $this->k_NLk = $jZqB7;
        goto nKpE4;
        nKpE4:
        $this->TXCkW = $wbDY2;
        goto EwvT9;
        q_t0a:
    }
    public function process($wnVK7)
    {
        $this->D4NIt->process($wnVK7);
    }
}
