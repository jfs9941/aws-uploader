<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Webmozart\Assert\Assert;
class G1tEiuD0CZvGR implements FileProcessingStrategyInterface
{
    private $pEUUc;
    private $JCpQ1;
    private $TvTF0;
    public function __construct($ZQQzW, $fXXZn)
    {
        goto DRqfS;
        DRqfS:
        Assert::isInstanceOf($ZQQzW, X9YHjKrAdcfhe::class);
        goto EG2YG;
        dN6pM:
        $snXNa = config('upload.post_process_image');
        goto rp89b;
        C2YRK:
        $this->JCpQ1 = $fXXZn;
        goto dN6pM;
        EG2YG:
        $this->pEUUc = $ZQQzW;
        goto C2YRK;
        rp89b:
        $this->TvTF0 = new $snXNa($ZQQzW, $fXXZn);
        goto tvCGO;
        tvCGO:
    }
    public function process($pbBGy) : void
    {
        $this->TvTF0->process($pbBGy);
    }
}
