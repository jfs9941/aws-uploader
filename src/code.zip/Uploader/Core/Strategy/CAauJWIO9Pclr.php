<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Webmozart\Assert\Assert;
class CAauJWIO9Pclr implements FileProcessingStrategyInterface
{
    private $BUIDz;
    private $RX1is;
    private $SxY74;
    public function __construct($a97TB, $sjhjO)
    {
        goto rUEdL;
        ySTjj:
        $this->SxY74 = new $ohyCs($a97TB, $sjhjO);
        goto vqfbA;
        LFleo:
        $this->RX1is = $sjhjO;
        goto hGklK;
        hGklK:
        $ohyCs = config('upload.post_process_image');
        goto ySTjj;
        rUEdL:
        Assert::isInstanceOf($a97TB, Z7LUL65CwqbbF::class);
        goto civ2r;
        civ2r:
        $this->BUIDz = $a97TB;
        goto LFleo;
        vqfbA:
    }
    public function process($PBgm2) : void
    {
        $this->SxY74->process($PBgm2);
    }
}
