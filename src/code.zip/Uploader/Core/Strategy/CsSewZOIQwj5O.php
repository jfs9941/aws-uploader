<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Encoder\Q0BHItA6POhGn;
class CsSewZOIQwj5O implements FileProcessingStrategyInterface
{
    private $M0XbK;
    private $iTLXM;
    private $iQaN5;
    public function __construct(WlFu7DaMUEnSS $hgsqV, Q0BHItA6POhGn $EMafP)
    {
        goto nlUha;
        iPi_c:
        $yR2IU = config('upload.post_process_video');
        goto mjGwN;
        mjGwN:
        $this->iQaN5 = new $yR2IU($hgsqV, $EMafP);
        goto i9Qtq;
        nlUha:
        $this->M0XbK = $hgsqV;
        goto KEg_Q;
        KEg_Q:
        $this->iTLXM = $EMafP;
        goto iPi_c;
        i9Qtq:
    }
    public function process($o91Cx)
    {
        $this->iQaN5->process($o91Cx);
    }
}
