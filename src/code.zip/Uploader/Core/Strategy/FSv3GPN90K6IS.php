<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Webmozart\Assert\Assert;
class FSv3GPN90K6IS implements FileProcessingStrategyInterface
{
    private $YHBBC;
    private $Pmi2M;
    private $JTaMn;
    public function __construct($gNhb4, $RH5Rq)
    {
        goto RyRYj;
        UJi1b:
        $this->JTaMn = new $Xs_xO($gNhb4, $RH5Rq);
        goto B4HW9;
        yc9gS:
        $this->YHBBC = $gNhb4;
        goto yvvx_;
        RyRYj:
        Assert::isInstanceOf($gNhb4, KfEJaEGpFJ0tm::class);
        goto yc9gS;
        IYr8o:
        $Xs_xO = config('upload.post_process_image');
        goto UJi1b;
        yvvx_:
        $this->Pmi2M = $RH5Rq;
        goto IYr8o;
        B4HW9:
    }
    public function process($g6hzj) : void
    {
        $this->JTaMn->process($g6hzj);
    }
}
