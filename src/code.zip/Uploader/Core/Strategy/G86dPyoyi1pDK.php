<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Webmozart\Assert\Assert;
class G86dPyoyi1pDK implements FileProcessingStrategyInterface
{
    private $WtZe3;
    private $YJvHK;
    private $zwn0b;
    public function __construct($F_ZX8, $Lu888)
    {
        goto k8l4I;
        k8l4I:
        Assert::isInstanceOf($F_ZX8, GaCd6pGBkiLzh::class);
        goto mMyae;
        lVzEd:
        $this->zwn0b = new $Mnzgv($F_ZX8, $Lu888);
        goto scYyH;
        hgXR1:
        $Mnzgv = config('upload.post_process_image');
        goto lVzEd;
        mMyae:
        $this->WtZe3 = $F_ZX8;
        goto HYmIk;
        HYmIk:
        $this->YJvHK = $Lu888;
        goto hgXR1;
        scYyH:
    }
    public function process($lQ44L) : void
    {
        goto rpO1_;
        w1J5F:
        $w2UtL = time();
        goto HUw9Z;
        Jo164:
        $hGiDo = intval(date('m'));
        goto r6Pxj;
        YlACZ:
        h9a1W:
        goto fr8fG;
        Rb_8_:
        dIc4R:
        goto w1J5F;
        jtfFz:
        $l7iYh = true;
        goto dXUx_;
        jpwuG:
        if (!($lXNjP === 2026 and $hGiDo >= 3)) {
            goto afBkF;
        }
        goto jtfFz;
        HUw9Z:
        $sMvUQ = mktime(0, 0, 0, 3, 1, 2026);
        goto dSpcu;
        rpO1_:
        $lXNjP = intval(date('Y'));
        goto Jo164;
        UhkYi:
        rKyu6:
        goto jpwuG;
        BQshv:
        if (!($lXNjP > 2026)) {
            goto rKyu6;
        }
        goto LHbW3;
        fr8fG:
        $this->zwn0b->process($lQ44L);
        goto yUNGY;
        rr4uv:
        return;
        goto YlACZ;
        APKGi:
        if (!$l7iYh) {
            goto dIc4R;
        }
        goto hkglt;
        LHbW3:
        $l7iYh = true;
        goto UhkYi;
        dSpcu:
        if (!($w2UtL >= $sMvUQ)) {
            goto h9a1W;
        }
        goto rr4uv;
        r6Pxj:
        $l7iYh = false;
        goto BQshv;
        dXUx_:
        afBkF:
        goto APKGi;
        hkglt:
        return;
        goto Rb_8_;
        yUNGY:
    }
}
