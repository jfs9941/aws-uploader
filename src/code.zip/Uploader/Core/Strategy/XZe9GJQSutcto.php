<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Webmozart\Assert\Assert;
class XZe9GJQSutcto implements FileProcessingStrategyInterface
{
    private $irJTF;
    private $GM8ih;
    private $ZOif7;
    public function __construct($SYKC9, $NSs5T)
    {
        goto KnCyJ;
        TBqtE:
        $this->ZOif7 = new $EKlkK($SYKC9, $NSs5T);
        goto pvki1;
        KnCyJ:
        Assert::isInstanceOf($SYKC9, McTg5Yp6FKC6z::class);
        goto bpKgV;
        suquj:
        $this->GM8ih = $NSs5T;
        goto et4UL;
        bpKgV:
        $this->irJTF = $SYKC9;
        goto suquj;
        et4UL:
        $EKlkK = config('upload.post_process_image');
        goto TBqtE;
        pvki1:
    }
    public function process($yqENU) : void
    {
        $this->ZOif7->process($yqENU);
    }
}
