<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Encoder\Qyf5nkvkW6Bhl;
class UdYgyX3r3509I implements FileProcessingStrategyInterface
{
    private $C_2Od;
    private $nuGwG;
    private $uOXuf;
    public function __construct(SYLdN2QnIYYwa $cFlec, Qyf5nkvkW6Bhl $VkQke)
    {
        goto MRv5V;
        WLQe1:
        $this->nuGwG = $VkQke;
        goto PVEDF;
        MRv5V:
        $this->C_2Od = $cFlec;
        goto WLQe1;
        Nyo40:
        $this->uOXuf = new $JzEFO($cFlec, $VkQke);
        goto xYh5m;
        PVEDF:
        $JzEFO = config('upload.post_process_video');
        goto Nyo40;
        xYh5m:
    }
    public function process($uuNrv)
    {
        $this->uOXuf->process($uuNrv);
    }
}
