<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Webmozart\Assert\Assert;
class Su1jU2ELQflwO implements FileProcessingStrategyInterface
{
    private $OmRww;
    private $roKTC;
    private $HLTzL;
    public function __construct($VGttq, $K4w3R)
    {
        goto zQ9L1;
        isfYF:
        $k2Hvs = config('upload.post_process_image');
        goto UQ1J2;
        xPJZt:
        $this->OmRww = $VGttq;
        goto JaaRW;
        zQ9L1:
        Assert::isInstanceOf($VGttq, UKkbXBDRxjSUY::class);
        goto xPJZt;
        UQ1J2:
        $this->HLTzL = new $k2Hvs($VGttq, $K4w3R);
        goto DN1_j;
        JaaRW:
        $this->roKTC = $K4w3R;
        goto isfYF;
        DN1_j:
    }
    public function process($g8A6r) : void
    {
        $this->HLTzL->process($g8A6r);
    }
}
