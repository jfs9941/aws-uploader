<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Encoder\CqIfz7C8PXyW1;
class E17tjeR7Ux3Qs implements FileProcessingStrategyInterface
{
    private $IgXIj;
    private $jfFiG;
    private $I9rLs;
    public function __construct(UZjgdpyMf06F7 $iit8z, CqIfz7C8PXyW1 $oKNB_)
    {
        goto kIHns;
        YzBqj:
        $this->I9rLs = new $gDlwQ($iit8z, $oKNB_);
        goto OWelb;
        kIHns:
        $this->IgXIj = $iit8z;
        goto uSpPA;
        Ft2tx:
        $gDlwQ = config('upload.post_process_video');
        goto YzBqj;
        uSpPA:
        $this->jfFiG = $oKNB_;
        goto Ft2tx;
        OWelb:
    }
    public function process($LM9ev)
    {
        $this->I9rLs->process($LM9ev);
    }
}
