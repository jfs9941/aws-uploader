<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Encoder\VNaEXNVKcqr6v;
class XprTOXzXRKkDr implements FileProcessingStrategyInterface
{
    private $evntx;
    private $QY2d8;
    private $bcuMO;
    public function __construct(IN9Uizy4TAywx $EVGvq, VNaEXNVKcqr6v $DURrE)
    {
        goto WhKJX;
        Qn4kf:
        $w7HAq = config('upload.post_process_video');
        goto RaRRg;
        WhKJX:
        $this->evntx = $EVGvq;
        goto VDa9n;
        RaRRg:
        $this->bcuMO = new $w7HAq($EVGvq, $DURrE);
        goto TnYRp;
        VDa9n:
        $this->QY2d8 = $DURrE;
        goto Qn4kf;
        TnYRp:
    }
    public function process($HOW2G)
    {
        $this->bcuMO->process($HOW2G);
    }
}
