<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Webmozart\Assert\Assert;
class VFeE64RRDXinB implements FileProcessingStrategyInterface
{
    private $lizqO;
    private $yYDr_;
    private $dO77T;
    public function __construct($dIrHq, $N33e6)
    {
        goto UJbjK;
        F9uUb:
        $this->dO77T = new $nkGkp($dIrHq, $N33e6);
        goto Vq_nu;
        UJbjK:
        Assert::isInstanceOf($dIrHq, FmmY71eXk0D8U::class);
        goto A3IKQ;
        A3IKQ:
        $this->lizqO = $dIrHq;
        goto cgFft;
        juh5u:
        $nkGkp = config('upload.post_process_image');
        goto F9uUb;
        cgFft:
        $this->yYDr_ = $N33e6;
        goto juh5u;
        Vq_nu:
    }
    public function process($oeUGC) : void
    {
        $this->dO77T->process($oeUGC);
    }
}
