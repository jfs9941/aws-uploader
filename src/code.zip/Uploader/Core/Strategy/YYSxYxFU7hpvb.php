<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Encoder\Uql37EhjWaxp7;
class YYSxYxFU7hpvb implements FileProcessingStrategyInterface
{
    private $K4RXE;
    private $Rs964;
    private $fJ7sB;
    public function __construct(KhQ4OQYybZ7Vk $Uas5p, Uql37EhjWaxp7 $Q_6na)
    {
        goto Dxsiv;
        oWh10:
        $this->fJ7sB = new $l6eDo($Uas5p, $Q_6na);
        goto c3tAs;
        lDQ5I:
        $this->Rs964 = $Q_6na;
        goto yX7Qc;
        yX7Qc:
        $l6eDo = config('upload.post_process_video');
        goto oWh10;
        Dxsiv:
        $this->K4RXE = $Uas5p;
        goto lDQ5I;
        c3tAs:
    }
    public function process($U8afQ)
    {
        $this->fJ7sB->process($U8afQ);
    }
}
