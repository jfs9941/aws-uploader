<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Encoder\LoHH67lOeFp9J;
class DrhNfMm6psarL implements FileProcessingStrategyInterface
{
    private $eBnUC;
    private $tkbcO;
    private $JTaMn;
    public function __construct(OfMUIxZzii9Zu $Bh2o5, LoHH67lOeFp9J $jm7lB)
    {
        goto ARRF5;
        AeDJm:
        $this->JTaMn = new $Xs_xO($Bh2o5, $jm7lB);
        goto O4JVt;
        ARRF5:
        $this->eBnUC = $Bh2o5;
        goto T4L9d;
        z2xTT:
        $Xs_xO = config('upload.post_process_video');
        goto AeDJm;
        T4L9d:
        $this->tkbcO = $jm7lB;
        goto z2xTT;
        O4JVt:
    }
    public function process($g6hzj)
    {
        $this->JTaMn->process($g6hzj);
    }
}
