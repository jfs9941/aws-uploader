<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Encoder\K98g74EXAn8Vy;
class A4HSggH2qUo1l implements FileProcessingStrategyInterface
{
    private $AGPs9;
    private $Kwm41;
    private $b8Nk4;
    public function __construct(TXpC7TSf51nOz $uA7Bz, K98g74EXAn8Vy $JZ81Z)
    {
        goto Z0_QF;
        Z0_QF:
        $this->AGPs9 = $uA7Bz;
        goto s8esn;
        CT9RK:
        $this->b8Nk4 = new $ZMqfw($uA7Bz, $JZ81Z);
        goto S0lAe;
        s8esn:
        $this->Kwm41 = $JZ81Z;
        goto apH3y;
        apH3y:
        $ZMqfw = config('upload.post_process_video');
        goto CT9RK;
        S0lAe:
    }
    public function process($FJwyp)
    {
        $this->b8Nk4->process($FJwyp);
    }
}
