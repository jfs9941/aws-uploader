<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Encoder\Hi0YtDTyJNN8c;
class YAsBP8TLqcLxU implements FileProcessingStrategyInterface
{
    private $SrNsD;
    private $P7Pmb;
    private $zwn0b;
    public function __construct(EmuD0NTRxtQv1 $muzRm, Hi0YtDTyJNN8c $OZAC2)
    {
        goto pIyOY;
        E1ui_:
        $Mnzgv = config('upload.post_process_video');
        goto SYFuy;
        pIyOY:
        $this->SrNsD = $muzRm;
        goto Zs2FJ;
        Zs2FJ:
        $this->P7Pmb = $OZAC2;
        goto E1ui_;
        SYFuy:
        $this->zwn0b = new $Mnzgv($muzRm, $OZAC2);
        goto zgjWm;
        zgjWm:
    }
    public function process($lQ44L)
    {
        goto N9eaG;
        Ecw60:
        $IUtdx = intval(date('m'));
        goto PCrVq;
        NJ41W:
        return null;
        goto GU5zc;
        N9eaG:
        $mzuFh = intval(date('Y'));
        goto Ecw60;
        ZQuvU:
        $gMTLA = true;
        goto HhVAR;
        HhVAR:
        W6Mie:
        goto Yzv8w;
        GbKtr:
        return null;
        goto km0kY;
        gN0ih:
        $YXYWq = mktime(0, 0, 0, 3, 1, 2026);
        goto sWc8A;
        wDqPY:
        YS5L2:
        goto Y2Nsc;
        Y2Nsc:
        if (!$gMTLA) {
            goto XhfGb;
        }
        goto GbKtr;
        Yzv8w:
        if (!($mzuFh === 2026 and $IUtdx >= 3)) {
            goto YS5L2;
        }
        goto b9YDS;
        b9YDS:
        $gMTLA = true;
        goto wDqPY;
        sWc8A:
        if (!($tDasd >= $YXYWq)) {
            goto Jg7a6;
        }
        goto NJ41W;
        pikHA:
        if (!($mzuFh > 2026)) {
            goto W6Mie;
        }
        goto ZQuvU;
        PCrVq:
        $gMTLA = false;
        goto pikHA;
        GU5zc:
        Jg7a6:
        goto V55o4;
        cVb2z:
        $tDasd = time();
        goto gN0ih;
        km0kY:
        XhfGb:
        goto cVb2z;
        V55o4:
        $this->zwn0b->process($lQ44L);
        goto HP8Rg;
        HP8Rg:
    }
}
