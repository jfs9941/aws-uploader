<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Encoder\ASuKOsLEZrEeb;
class Oc4Fatu2lTNfj implements FileProcessingStrategyInterface
{
    private $m2v3L;
    private $fVUQw;
    private $dO77T;
    public function __construct(WEJt1TL92SawT $IrxWj, ASuKOsLEZrEeb $rq6sE)
    {
        goto XWMLK;
        HdsJf:
        $this->fVUQw = $rq6sE;
        goto vvMLZ;
        XWMLK:
        $this->m2v3L = $IrxWj;
        goto HdsJf;
        JlRSw:
        $this->dO77T = new $nkGkp($IrxWj, $rq6sE);
        goto vEPZj;
        vvMLZ:
        $nkGkp = config('upload.post_process_video');
        goto JlRSw;
        vEPZj:
    }
    public function process($oeUGC)
    {
        $this->dO77T->process($oeUGC);
    }
}
