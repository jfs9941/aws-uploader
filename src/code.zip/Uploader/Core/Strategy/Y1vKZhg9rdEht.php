<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Webmozart\Assert\Assert;
class Y1vKZhg9rdEht implements FileProcessingStrategyInterface
{
    private $bzkg8;
    private $H5Cq0;
    private $v_FT5;
    public function __construct($VSbOm, $KzVpB)
    {
        goto HHz4Z;
        M7UsI:
        $this->bzkg8 = $VSbOm;
        goto KG_HA;
        KG_HA:
        $this->H5Cq0 = $KzVpB;
        goto evEbD;
        evEbD:
        $p47_6 = config('upload.post_process_image');
        goto VTrBi;
        VTrBi:
        $this->v_FT5 = new $p47_6($VSbOm, $KzVpB);
        goto pmq6o;
        HHz4Z:
        Assert::isInstanceOf($VSbOm, KZbAaRxCqNUr3::class);
        goto M7UsI;
        pmq6o:
    }
    public function process($pYxoc) : void
    {
        $this->v_FT5->process($pYxoc);
    }
}
