<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\FileInterface;
use Jfs\Uploader\Encoder\HlsPathResolver;

class PostProcessForVideo implements FileProcessingStrategyInterface
{
    private $video;
    private $hlsPathResolver;
    private $inner;

    public function __construct(
        FileInterface $video,
        HlsPathResolver $hlsPathResolver
    ) {
        $this->video = $video;
        $this->hlsPathResolver = $hlsPathResolver;
        $innerClass = config('upload.post_process_video');
        $this->inner = new $innerClass($video, $hlsPathResolver);
    }

    public function process($toStatus)
    {
        $this->inner->process($toStatus);
    }

}
