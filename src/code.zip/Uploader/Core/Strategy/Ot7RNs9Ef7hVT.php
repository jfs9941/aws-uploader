<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Webmozart\Assert\Assert;
class Ot7RNs9Ef7hVT implements FileProcessingStrategyInterface
{
    private $PxpbN;
    private $DWDC6;
    private $Aay9I;
    public function __construct($T4AWF, $eoTgM)
    {
        goto kg_dM;
        pVM8g:
        $v6KM_ = config('upload.post_process_image');
        goto r4nGn;
        aaday:
        $this->DWDC6 = $eoTgM;
        goto pVM8g;
        r4nGn:
        $this->Aay9I = new $v6KM_($T4AWF, $eoTgM);
        goto BEPrg;
        vfC0Z:
        $this->PxpbN = $T4AWF;
        goto aaday;
        kg_dM:
        Assert::isInstanceOf($T4AWF, WUuz09CA4woAL::class);
        goto vfC0Z;
        BEPrg:
    }
    public function process($rCZtY) : void
    {
        $this->Aay9I->process($rCZtY);
    }
}
