<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Encoder\VSKfJ2MZj0Tjg;
class NM3j8RKDr4jhP implements FileProcessingStrategyInterface
{
    private $aKDWA;
    private $iJ_mc;
    private $HnnbE;
    public function __construct(WGN88W9AFumiX $dajVn, VSKfJ2MZj0Tjg $HVXUU)
    {
        goto Tf5IZ;
        Rfhi7:
        $this->iJ_mc = $HVXUU;
        goto BvdrY;
        XUgRY:
        $this->HnnbE = new $O8uXs($dajVn, $HVXUU);
        goto qy1YI;
        Tf5IZ:
        $this->aKDWA = $dajVn;
        goto Rfhi7;
        BvdrY:
        $O8uXs = config('upload.post_process_video');
        goto XUgRY;
        qy1YI:
    }
    public function process($Q3oHh)
    {
        $this->HnnbE->process($Q3oHh);
    }
}
