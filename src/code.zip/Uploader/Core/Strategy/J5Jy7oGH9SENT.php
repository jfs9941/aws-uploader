<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Encoder\Gp4Z40z5XsT8O;
class J5Jy7oGH9SENT implements FileProcessingStrategyInterface
{
    private $wm5Rp;
    private $x_0uG;
    private $f70HQ;
    public function __construct(WmSe4qJ68rckH $wmU7r, Gp4Z40z5XsT8O $N6VEb)
    {
        goto AA2Eo;
        Hspfq:
        $this->x_0uG = $N6VEb;
        goto vOOiV;
        x6zo2:
        $this->f70HQ = new $Np_OR($wmU7r, $N6VEb);
        goto pUcus;
        vOOiV:
        $Np_OR = config('upload.post_process_video');
        goto x6zo2;
        AA2Eo:
        $this->wm5Rp = $wmU7r;
        goto Hspfq;
        pUcus:
    }
    public function process($P0HHu)
    {
        $this->f70HQ->process($P0HHu);
    }
}
