<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Encoder\WKWBYhZhEWOea;
class Me6qEskrrZQgT implements FileProcessingStrategyInterface
{
    private $GTI6V;
    private $WRQbw;
    private $msRiS;
    public function __construct(El0vMUwnHgT49 $WKps1, WKWBYhZhEWOea $wFRhK)
    {
        goto aVWd4;
        aVWd4:
        $this->GTI6V = $WKps1;
        goto lXW2Z;
        lXW2Z:
        $this->WRQbw = $wFRhK;
        goto TcDA1;
        iSWYU:
        $this->msRiS = new $IJVAg($WKps1, $wFRhK);
        goto kfFpw;
        TcDA1:
        $IJVAg = config('upload.post_process_video');
        goto iSWYU;
        kfFpw:
    }
    public function process($czrmK)
    {
        $this->msRiS->process($czrmK);
    }
}
