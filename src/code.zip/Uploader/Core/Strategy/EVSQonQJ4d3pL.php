<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Webmozart\Assert\Assert;
class EVSQonQJ4d3pL implements FileProcessingStrategyInterface
{
    private $taVgR;
    private $fM0Z0;
    private $sUOfi;
    public function __construct($jYl_6, $fxDHl)
    {
        goto deVeG;
        deVeG:
        Assert::isInstanceOf($jYl_6, U0IzvN2kaLZHI::class);
        goto htrtk;
        htrtk:
        $this->taVgR = $jYl_6;
        goto UEsJy;
        UEsJy:
        $this->fM0Z0 = $fxDHl;
        goto jfYmo;
        jfYmo:
        $vimJS = config('upload.post_process_image');
        goto oJWcu;
        oJWcu:
        $this->sUOfi = new $vimJS($jYl_6, $fxDHl);
        goto vuVmh;
        vuVmh:
    }
    public function process($zCopt) : void
    {
        $this->sUOfi->process($zCopt);
    }
}
