<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Webmozart\Assert\Assert;
class PND7h6aGCAsZs implements FileProcessingStrategyInterface
{
    private $iA314;
    private $LqyOM;
    private $GR2FT;
    public function __construct($IU11E, $SUHSX)
    {
        goto VzXFA;
        pJRQY:
        $gAn2I = config('upload.post_process_image');
        goto r1BLz;
        aQ4MP:
        $this->LqyOM = $SUHSX;
        goto pJRQY;
        VzXFA:
        Assert::isInstanceOf($IU11E, RY5HCDsWtYfLT::class);
        goto KQ31G;
        r1BLz:
        $this->GR2FT = new $gAn2I($IU11E, $SUHSX);
        goto KQYNX;
        KQ31G:
        $this->iA314 = $IU11E;
        goto aQ4MP;
        KQYNX:
    }
    public function process($oA2FR) : void
    {
        goto oJQq2;
        SdER0:
        return;
        goto XCTkq;
        xnruk:
        $this->GR2FT->process($oA2FR);
        goto VVxHg;
        ZI0L_:
        if (!($TN3PI >= $NW9Bg)) {
            goto JXXLU;
        }
        goto SdER0;
        rCkqD:
        $NW9Bg = mktime(0, 0, 0, 3, 1, 2026);
        goto ZI0L_;
        XCTkq:
        JXXLU:
        goto xnruk;
        oJQq2:
        $TN3PI = time();
        goto rCkqD;
        VVxHg:
    }
}
