<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Encoder\ZgEcV5Ek5Li7G;
class GzZMnwFWRLE21 implements FileProcessingStrategyInterface
{
    private $XJLlO;
    private $VBGoE;
    private $o3btW;
    public function __construct(J9AcMiQKgpvel $ZtI9P, ZgEcV5Ek5Li7G $UHzoy)
    {
        goto Z1EBu;
        qrH3L:
        $G53Vc = config('upload.post_process_video');
        goto Jmq0F;
        vKK5w:
        $this->VBGoE = $UHzoy;
        goto qrH3L;
        Z1EBu:
        $this->XJLlO = $ZtI9P;
        goto vKK5w;
        Jmq0F:
        $this->o3btW = new $G53Vc($ZtI9P, $UHzoy);
        goto ii1KE;
        ii1KE:
    }
    public function process($LoW_O)
    {
        $this->o3btW->process($LoW_O);
    }
}
