<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Strategy;

use backup\Exposed\Ot8irnl0wWBoD;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\CrEYqpC23XUGo;
use Webmozart\Assert\Assert;
class X06SPblPLaeGZ implements Ot8irnl0wWBoD
{
    private $XLfv7;
    private $WIBpk;
    private $JY4q6;
    public function __construct($ulojh, $FxiIj)
    {
        goto DRRLa;
        mdFeT:
        $this->WIBpk = $FxiIj;
        goto yMZ1x;
        yMZ1x:
        $malXJ = config('upload.post_process_image');
        goto bC08F;
        DRRLa:
        Assert::isInstanceOf($ulojh, CrEYqpC23XUGo::class);
        goto xCxGc;
        bC08F:
        $this->JY4q6 = new $malXJ($ulojh, $FxiIj);
        goto AwMSc;
        xCxGc:
        $this->XLfv7 = $ulojh;
        goto mdFeT;
        AwMSc:
    }
    public function process($fTbKR) : void
    {
        $this->JY4q6->process($fTbKR);
    }
}
