<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Encoder\FSb1vbQf2TVPX;
class DTRQSewO9aSqD implements FileProcessingStrategyInterface
{
    private $QSdwi;
    private $lNnJc;
    private $Aay9I;
    public function __construct(RV6vDyOPhxLM1 $JhYqb, FSb1vbQf2TVPX $kViBN)
    {
        goto SnqUe;
        eEs0q:
        $this->lNnJc = $kViBN;
        goto wioY7;
        wioY7:
        $v6KM_ = config('upload.post_process_video');
        goto MwHMN;
        MwHMN:
        $this->Aay9I = new $v6KM_($JhYqb, $kViBN);
        goto jkfI1;
        SnqUe:
        $this->QSdwi = $JhYqb;
        goto eEs0q;
        jkfI1:
    }
    public function process($rCZtY)
    {
        $this->Aay9I->process($rCZtY);
    }
}
