<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Encoder\LzL89H4g6zwMz;
class PZdwEyoqlLHE9 implements FileProcessingStrategyInterface
{
    private $FOng6;
    private $PwPPA;
    private $Pr65k;
    public function __construct(JQSlbB9QkzzhT $aiCaH, LzL89H4g6zwMz $fawdl)
    {
        goto DiOE9;
        N6bGp:
        $this->Pr65k = new $ELIyb($aiCaH, $fawdl);
        goto aPMzv;
        RF33q:
        $this->PwPPA = $fawdl;
        goto cmk0C;
        DiOE9:
        $this->FOng6 = $aiCaH;
        goto RF33q;
        cmk0C:
        $ELIyb = config('upload.post_process_video');
        goto N6bGp;
        aPMzv:
    }
    public function process($J0GfA)
    {
        $this->Pr65k->process($J0GfA);
    }
}
