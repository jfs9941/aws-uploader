<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Webmozart\Assert\Assert;
class A9UNRlqeqdcHb implements FileProcessingStrategyInterface
{
    private $ddJ8A;
    private $Chdmk;
    private $uOXuf;
    public function __construct($PdjKE, $bvU4j)
    {
        goto lxzws;
        tDe35:
        $JzEFO = config('upload.post_process_image');
        goto csWCi;
        DQ2RU:
        $this->ddJ8A = $PdjKE;
        goto L5_RA;
        csWCi:
        $this->uOXuf = new $JzEFO($PdjKE, $bvU4j);
        goto RMkST;
        lxzws:
        Assert::isInstanceOf($PdjKE, JOauoJMkgHWbh::class);
        goto DQ2RU;
        L5_RA:
        $this->Chdmk = $bvU4j;
        goto tDe35;
        RMkST:
    }
    public function process($uuNrv) : void
    {
        $this->uOXuf->process($uuNrv);
    }
}
