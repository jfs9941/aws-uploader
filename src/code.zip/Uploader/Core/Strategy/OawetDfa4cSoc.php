<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Strategy; use Jfs\Exposed\FileProcessingStrategyInterface; use Jfs\Uploader\Core\J5wym0qxH1hlR; use Jfs\Uploader\Core\DIYGIfCt7MLhm; use Jfs\Uploader\Core\NoqRziJe9G7Nn; use Webmozart\Assert\Assert; class OawetDfa4cSoc implements FileProcessingStrategyInterface { private $FQHua; private $Re812; private $LHBlp; public function __construct($ULD7R, $FV4bx) { goto houdm; BKqqp: $this->Re812 = $FV4bx; goto wrWF2; wrWF2: $YEZ0r = config('upload.post_process_image'); goto Xwr1i; Xwr1i: $this->LHBlp = new $YEZ0r($ULD7R, $FV4bx); goto yH6i6; vwHBo: $this->FQHua = $ULD7R; goto BKqqp; houdm: Assert::isInstanceOf($ULD7R, NoqRziJe9G7Nn::class); goto vwHBo; yH6i6: } public function process($PT8Zt) : void { $this->LHBlp->process($PT8Zt); } }
