<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Webmozart\Assert\Assert;
class NX9oXw65wUrm6 implements FileProcessingStrategyInterface
{
    private $ZtezL;
    private $utuCE;
    private $o3btW;
    public function __construct($h169k, $bbFOe)
    {
        goto naPC5;
        slCRx:
        $this->ZtezL = $h169k;
        goto nvTin;
        nvTin:
        $this->utuCE = $bbFOe;
        goto DgvYJ;
        DgvYJ:
        $G53Vc = config('upload.post_process_image');
        goto ndoXR;
        ndoXR:
        $this->o3btW = new $G53Vc($h169k, $bbFOe);
        goto cFB4_;
        naPC5:
        Assert::isInstanceOf($h169k, D6FgZi8OHmjic::class);
        goto slCRx;
        cFB4_:
    }
    public function process($LoW_O) : void
    {
        $this->o3btW->process($LoW_O);
    }
}
