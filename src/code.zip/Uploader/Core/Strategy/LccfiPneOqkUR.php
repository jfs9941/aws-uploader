<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Encoder\EBrgb5DByuboN;
class LccfiPneOqkUR implements FileProcessingStrategyInterface
{
    private $SVP_E;
    private $L0xBh;
    private $gUH8V;
    public function __construct(Mty95KsoNkhJl $UUt0Z, EBrgb5DByuboN $EQGHb)
    {
        goto uao8s;
        uao8s:
        $this->SVP_E = $UUt0Z;
        goto L1raE;
        bAiPl:
        $this->gUH8V = new $IFUzP($UUt0Z, $EQGHb);
        goto q7U3M;
        L1raE:
        $this->L0xBh = $EQGHb;
        goto zyh30;
        zyh30:
        $IFUzP = config('upload.post_process_video');
        goto bAiPl;
        q7U3M:
    }
    public function process($CHBXo)
    {
        $this->gUH8V->process($CHBXo);
    }
}
