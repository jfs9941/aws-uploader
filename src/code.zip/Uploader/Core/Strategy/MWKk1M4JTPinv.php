<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Webmozart\Assert\Assert;
class MWKk1M4JTPinv implements FileProcessingStrategyInterface
{
    private $qJW3p;
    private $nAcVF;
    private $SzZYU;
    public function __construct($IS6o1, $xBmsh)
    {
        goto XObdV;
        YtUHp:
        $this->qJW3p = $IS6o1;
        goto KZmPq;
        XObdV:
        Assert::isInstanceOf($IS6o1, HSe6BNUpJTSwE::class);
        goto YtUHp;
        n6zM5:
        $vfhyd = config('upload.post_process_image');
        goto j5rpG;
        j5rpG:
        $this->SzZYU = new $vfhyd($IS6o1, $xBmsh);
        goto eYY3z;
        KZmPq:
        $this->nAcVF = $xBmsh;
        goto n6zM5;
        eYY3z:
    }
    public function process($lU7gc) : void
    {
        $this->SzZYU->process($lU7gc);
    }
}
