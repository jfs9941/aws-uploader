<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Encoder\Z476P5MAXqSnV;
class RsEqyvqLyezoB implements FileProcessingStrategyInterface
{
    private $GkJdL;
    private $lwz1R;
    private $ZOecL;
    public function __construct(WEM4ywoGgpPLK $X0ufS, Z476P5MAXqSnV $mh495)
    {
        goto PHc9h;
        N_Eq7:
        $this->ZOecL = new $Clrx0($X0ufS, $mh495);
        goto tPOxu;
        iXUVt:
        $Clrx0 = config('upload.post_process_video');
        goto N_Eq7;
        p5t8U:
        $this->lwz1R = $mh495;
        goto iXUVt;
        PHc9h:
        $this->GkJdL = $X0ufS;
        goto p5t8U;
        tPOxu:
    }
    public function process($tImt5)
    {
        $this->ZOecL->process($tImt5);
    }
}
