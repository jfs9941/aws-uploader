<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Webmozart\Assert\Assert;
class VWx1aMGAHFRkn implements FileProcessingStrategyInterface
{
    private $N3I7b;
    private $Tihgx;
    private $o9Z2G;
    public function __construct($FGBix, $j7R1u)
    {
        goto YpcDz;
        YpcDz:
        Assert::isInstanceOf($FGBix, XbYF8aa0XyGnI::class);
        goto YXjyj;
        AyQjT:
        $this->o9Z2G = new $TWazt($FGBix, $j7R1u);
        goto BHsSd;
        YXjyj:
        $this->N3I7b = $FGBix;
        goto vs_FH;
        vs_FH:
        $this->Tihgx = $j7R1u;
        goto ph0ER;
        ph0ER:
        $TWazt = config('upload.post_process_image');
        goto AyQjT;
        BHsSd:
    }
    public function process($YdZ0W) : void
    {
        $this->o9Z2G->process($YdZ0W);
    }
}
