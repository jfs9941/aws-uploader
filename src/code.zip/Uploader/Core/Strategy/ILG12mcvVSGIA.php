<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Encoder\AhS2r9oThLsk4;
class ILG12mcvVSGIA implements FileProcessingStrategyInterface
{
    private $CKgWg;
    private $n2wpq;
    private $v_FT5;
    public function __construct(N8O216tH1Gxax $qNHE7, AhS2r9oThLsk4 $R1OF9)
    {
        goto ZOITl;
        HuaCA:
        $this->v_FT5 = new $p47_6($qNHE7, $R1OF9);
        goto wnx3u;
        ZOITl:
        $this->CKgWg = $qNHE7;
        goto ly9QJ;
        cbY90:
        $p47_6 = config('upload.post_process_video');
        goto HuaCA;
        ly9QJ:
        $this->n2wpq = $R1OF9;
        goto cbY90;
        wnx3u:
    }
    public function process($pYxoc)
    {
        $this->v_FT5->process($pYxoc);
    }
}
