<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Webmozart\Assert\Assert;
class Mo0a6PsC9oEmS implements FileProcessingStrategyInterface
{
    private $Rh8TS;
    private $tHKs2;
    private $hjqPU;
    public function __construct($iy9bs, $kEeaF)
    {
        goto W50Ee;
        KBd6K:
        $this->hjqPU = new $x5wH9($iy9bs, $kEeaF);
        goto WYMXT;
        gbBZb:
        $this->Rh8TS = $iy9bs;
        goto yAFFf;
        PE8Gm:
        $x5wH9 = config('upload.post_process_image');
        goto KBd6K;
        W50Ee:
        Assert::isInstanceOf($iy9bs, JyZaxpharsbun::class);
        goto gbBZb;
        yAFFf:
        $this->tHKs2 = $kEeaF;
        goto PE8Gm;
        WYMXT:
    }
    public function process($b8sYW) : void
    {
        $this->hjqPU->process($b8sYW);
    }
}
