<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\FileInterface;
use Jfs\Uploader\Core\Image;
use Webmozart\Assert\Assert;

class PostProcessForImage implements FileProcessingStrategyInterface
{
    private $image;
    private $options;

    private $inner;

    /**
     * @param FileInterface|BaseFileModel $image
     * @param array                       $options
     */
    public function __construct($image, $options)
    {
        Assert::isInstanceOf($image, Image::class);
        $this->image = $image;
        $this->options = $options;
        $innerClass = config('upload.post_process_image');
        $this->inner = new $innerClass($image, $options);
    }

    public function process($toStatus): void
    {
        $this->inner->process($toStatus);
    }
}
