<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Encoder\Rwcm9mhsmq7Wv;
class GuSN2fC476VWi implements FileProcessingStrategyInterface
{
    private $RiTOU;
    private $bHLAz;
    private $ZOif7;
    public function __construct(J5Mj1pjSQG0SH $vtvs_, Rwcm9mhsmq7Wv $TJaxK)
    {
        goto hWwRr;
        eQ1NA:
        $EKlkK = config('upload.post_process_video');
        goto yJg2H;
        yJg2H:
        $this->ZOif7 = new $EKlkK($vtvs_, $TJaxK);
        goto NB2sU;
        hWwRr:
        $this->RiTOU = $vtvs_;
        goto lIZch;
        lIZch:
        $this->bHLAz = $TJaxK;
        goto eQ1NA;
        NB2sU:
    }
    public function process($yqENU)
    {
        $this->ZOif7->process($yqENU);
    }
}
