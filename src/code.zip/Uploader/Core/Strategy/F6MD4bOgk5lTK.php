<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Encoder\VBDy3Gb7TKD1d;
class F6MD4bOgk5lTK implements FileProcessingStrategyInterface
{
    private $fIXyt;
    private $P_7a8;
    private $HLTzL;
    public function __construct(JVAg1Gkd0EvTM $qF0aQ, VBDy3Gb7TKD1d $OKVxj)
    {
        goto v6D8T;
        Wzf_e:
        $this->HLTzL = new $k2Hvs($qF0aQ, $OKVxj);
        goto M3M6M;
        g27VT:
        $this->P_7a8 = $OKVxj;
        goto gA62y;
        v6D8T:
        $this->fIXyt = $qF0aQ;
        goto g27VT;
        gA62y:
        $k2Hvs = config('upload.post_process_video');
        goto Wzf_e;
        M3M6M:
    }
    public function process($g8A6r)
    {
        $this->HLTzL->process($g8A6r);
    }
}
