<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Encoder\Koi3akneKfkiI;
class NA3I5Dp0Fy3l3 implements FileProcessingStrategyInterface
{
    private $QnmRj;
    private $GF9e_;
    private $o9Z2G;
    public function __construct(Zvx9VGBGZQ0lD $zef_R, Koi3akneKfkiI $oNkwX)
    {
        goto pdtRb;
        QFMeC:
        $this->GF9e_ = $oNkwX;
        goto oXnxG;
        oXnxG:
        $TWazt = config('upload.post_process_video');
        goto q07Rz;
        q07Rz:
        $this->o9Z2G = new $TWazt($zef_R, $oNkwX);
        goto UC1mY;
        pdtRb:
        $this->QnmRj = $zef_R;
        goto QFMeC;
        UC1mY:
    }
    public function process($YdZ0W)
    {
        $this->o9Z2G->process($YdZ0W);
    }
}
