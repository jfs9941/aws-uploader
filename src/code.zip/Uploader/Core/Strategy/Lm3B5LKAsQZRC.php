<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Webmozart\Assert\Assert;
class Lm3B5LKAsQZRC implements FileProcessingStrategyInterface
{
    private $zj0aM;
    private $yy6J0;
    private $b8Nk4;
    public function __construct($xixtT, $hNsac)
    {
        goto iCUwv;
        mhGZV:
        $this->b8Nk4 = new $ZMqfw($xixtT, $hNsac);
        goto jEM7A;
        iCUwv:
        Assert::isInstanceOf($xixtT, Vt3ybt0yfaPAa::class);
        goto iZKLE;
        ljYEC:
        $ZMqfw = config('upload.post_process_image');
        goto mhGZV;
        iZKLE:
        $this->zj0aM = $xixtT;
        goto zSlFV;
        zSlFV:
        $this->yy6J0 = $hNsac;
        goto ljYEC;
        jEM7A:
    }
    public function process($FJwyp) : void
    {
        $this->b8Nk4->process($FJwyp);
    }
}
