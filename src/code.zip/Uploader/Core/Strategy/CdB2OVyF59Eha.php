<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Webmozart\Assert\Assert;
class CdB2OVyF59Eha implements FileProcessingStrategyInterface
{
    private $Cg6hh;
    private $BTghq;
    private $bcuMO;
    public function __construct($RD3vr, $sUzkn)
    {
        goto BvwA0;
        oDNnP:
        $this->BTghq = $sUzkn;
        goto LJoYW;
        QmvCt:
        $this->Cg6hh = $RD3vr;
        goto oDNnP;
        y_20W:
        $this->bcuMO = new $w7HAq($RD3vr, $sUzkn);
        goto Jm0a0;
        LJoYW:
        $w7HAq = config('upload.post_process_image');
        goto y_20W;
        BvwA0:
        Assert::isInstanceOf($RD3vr, KCmQR4pvm0dT3::class);
        goto QmvCt;
        Jm0a0:
    }
    public function process($HOW2G) : void
    {
        $this->bcuMO->process($HOW2G);
    }
}
