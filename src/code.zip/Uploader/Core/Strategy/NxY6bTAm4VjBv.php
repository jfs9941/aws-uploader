<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Webmozart\Assert\Assert;
class NxY6bTAm4VjBv implements FileProcessingStrategyInterface
{
    private $naLl3;
    private $qmMpI;
    private $dNIpE;
    public function __construct($zCabx, $Bm5Jl)
    {
        goto jWpP2;
        y5Snh:
        $this->qmMpI = $Bm5Jl;
        goto hRmwi;
        hRmwi:
        $BPzz_ = config('upload.post_process_image');
        goto Ny4cB;
        Ny4cB:
        $this->dNIpE = new $BPzz_($zCabx, $Bm5Jl);
        goto o0vc_;
        jWpP2:
        Assert::isInstanceOf($zCabx, XMeo8SOmME8kj::class);
        goto JEhFQ;
        JEhFQ:
        $this->naLl3 = $zCabx;
        goto y5Snh;
        o0vc_:
    }
    public function process($vfRhE) : void
    {
        $this->dNIpE->process($vfRhE);
    }
}
