<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Encoder\TMo64GtkgTgVY;
class AOT9bVnwczyet implements FileProcessingStrategyInterface
{
    private $b2BaR;
    private $T4YPH;
    private $sUOfi;
    public function __construct(Guvqjk2EvHsmF $jYLmK, TMo64GtkgTgVY $LJ722)
    {
        goto wiQ6L;
        Abe0s:
        $this->sUOfi = new $vimJS($jYLmK, $LJ722);
        goto Mnjz8;
        mCpkz:
        $vimJS = config('upload.post_process_video');
        goto Abe0s;
        BppIy:
        $this->T4YPH = $LJ722;
        goto mCpkz;
        wiQ6L:
        $this->b2BaR = $jYLmK;
        goto BppIy;
        Mnjz8:
    }
    public function process($zCopt)
    {
        $this->sUOfi->process($zCopt);
    }
}
