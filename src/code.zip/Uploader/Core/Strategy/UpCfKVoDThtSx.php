<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Encoder\MquUYPN1EJDdI;
class UpCfKVoDThtSx implements FileProcessingStrategyInterface
{
    private $ceZhM;
    private $Dp3C8;
    private $SzZYU;
    public function __construct(DNmcAdktLJtqn $KuX31, MquUYPN1EJDdI $WHycl)
    {
        goto RdmRG;
        PiJwk:
        $this->Dp3C8 = $WHycl;
        goto ltDm5;
        ltDm5:
        $vfhyd = config('upload.post_process_video');
        goto qV4mf;
        qV4mf:
        $this->SzZYU = new $vfhyd($KuX31, $WHycl);
        goto CBuf0;
        RdmRG:
        $this->ceZhM = $KuX31;
        goto PiJwk;
        CBuf0:
    }
    public function process($lU7gc)
    {
        $this->SzZYU->process($lU7gc);
    }
}
