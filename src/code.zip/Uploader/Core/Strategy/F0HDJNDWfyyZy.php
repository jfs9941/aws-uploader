<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Strategy;

use backup\Exposed\Ot8irnl0wWBoD;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Encoder\LZk9dEYagFbfv;
class F0HDJNDWfyyZy implements Ot8irnl0wWBoD
{
    private $mdgNQ;
    private $Di1TS;
    private $JY4q6;
    public function __construct(YcdplGVWzA91v $L2Ff8, LZk9dEYagFbfv $CR9ys)
    {
        goto iaBUC;
        r_fS7:
        $this->Di1TS = $CR9ys;
        goto fskaf;
        EwGGD:
        $this->JY4q6 = new $malXJ($L2Ff8, $CR9ys);
        goto xklhI;
        fskaf:
        $malXJ = config('upload.post_process_video');
        goto EwGGD;
        iaBUC:
        $this->mdgNQ = $L2Ff8;
        goto r_fS7;
        xklhI:
    }
    public function process($fTbKR)
    {
        $this->JY4q6->process($fTbKR);
    }
}
