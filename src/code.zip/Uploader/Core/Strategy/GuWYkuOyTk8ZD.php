<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Encoder\OGmQ0hQJzIYby;
class GuWYkuOyTk8ZD implements FileProcessingStrategyInterface
{
    private $jZxsX;
    private $i2JqJ;
    private $XJ0wK;
    public function __construct(MQuH2y6UnzTZv $Ipllx, OGmQ0hQJzIYby $a0naV)
    {
        goto g62zw;
        QXXP0:
        $this->i2JqJ = $a0naV;
        goto iAVyx;
        NNO9f:
        $this->XJ0wK = new $QFHsG($Ipllx, $a0naV);
        goto jCT25;
        iAVyx:
        $QFHsG = config('upload.post_process_video');
        goto NNO9f;
        g62zw:
        $this->jZxsX = $Ipllx;
        goto QXXP0;
        jCT25:
    }
    public function process($tMFSs)
    {
        $this->XJ0wK->process($tMFSs);
    }
}
