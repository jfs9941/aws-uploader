<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Webmozart\Assert\Assert;
class G5LJq9vrKLHzp implements FileProcessingStrategyInterface
{
    private $iFa50;
    private $HsQc0;
    private $ilPBt;
    public function __construct($uuvVo, $RvoDa)
    {
        goto TTYEK;
        rgEzN:
        $tMpe7 = config('upload.post_process_image');
        goto TJ9n1;
        xjqK2:
        $this->iFa50 = $uuvVo;
        goto x1TJz;
        TJ9n1:
        $this->ilPBt = new $tMpe7($uuvVo, $RvoDa);
        goto Z23R2;
        TTYEK:
        Assert::isInstanceOf($uuvVo, S7LEoIprYtLQw::class);
        goto xjqK2;
        x1TJz:
        $this->HsQc0 = $RvoDa;
        goto rgEzN;
        Z23R2:
    }
    public function process($ieqE_) : void
    {
        $this->ilPBt->process($ieqE_);
    }
}
