<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Webmozart\Assert\Assert;
class Peo85prIGI36G implements FileProcessingStrategyInterface
{
    private $B55Ei;
    private $hYRvW;
    private $fJ7sB;
    public function __construct($MSkzT, $as2bQ)
    {
        goto FEGtw;
        pOrSR:
        $this->fJ7sB = new $l6eDo($MSkzT, $as2bQ);
        goto Bg0Ts;
        iq5J6:
        $this->B55Ei = $MSkzT;
        goto KRYKn;
        KRYKn:
        $this->hYRvW = $as2bQ;
        goto svNv1;
        svNv1:
        $l6eDo = config('upload.post_process_image');
        goto pOrSR;
        FEGtw:
        Assert::isInstanceOf($MSkzT, XqAJHKYeaW2YU::class);
        goto iq5J6;
        Bg0Ts:
    }
    public function process($U8afQ) : void
    {
        $this->fJ7sB->process($U8afQ);
    }
}
