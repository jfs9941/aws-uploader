<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\Observer\YwkS1y4Srg3M1;
use Jfs\Uploader\Core\HMzvJtEcyxrN7;
use Jfs\Uploader\Core\Traits\L19xGUdtwyw0e;
use Jfs\Uploader\Core\Traits\XGoBOvpn4TlTz;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Exception\GUt8ZmYbCCh9b;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Exception\YoMZumD8PRcVT;
use Jfs\Uploader\Service\RIRnT0b6ENemU;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class ZFuimKZywyxo2 implements GCZ2vyVNpj70n
{
    use L19xGUdtwyw0e;
    use XGoBOvpn4TlTz;
    private $Of1mS;
    private function __construct($dV9QE, $RndMA)
    {
        $this->pnMmg = $dV9QE;
        $this->IAuMz = $RndMA;
    }
    private function m7zKiiwEWsq(string $YctT5, $RndMA, $luwqK, bool $TxEfI = false) : void
    {
        $this->mJpwZRYg1fj(new YwkS1y4Srg3M1($this, $RndMA, $luwqK, $YctT5, $TxEfI));
    }
    public function getFile()
    {
        return $this->pnMmg;
    }
    public function mYisetnzoMl(array $y9rcG) : void
    {
        $this->Of1mS = $y9rcG;
    }
    public function mj1uGcThg9p() : void
    {
        $this->mKd8O9TpYCH(EpMPhiTVzNYqA::UPLOADING);
    }
    public function mdvy7fR7OrW() : void
    {
        $this->mKd8O9TpYCH(EpMPhiTVzNYqA::UPLOADED);
    }
    public function mHHMfsWbC3y() : void
    {
        $this->mKd8O9TpYCH(EpMPhiTVzNYqA::PROCESSING);
    }
    public function m1Elx5LUPo1() : void
    {
        $this->mKd8O9TpYCH(EpMPhiTVzNYqA::FINISHED);
    }
    public function mtVbnRXO7El() : void
    {
        $this->mKd8O9TpYCH(EpMPhiTVzNYqA::ABORTED);
    }
    public function mt4urd3oc3e() : array
    {
        return $this->Of1mS;
    }
    public static function mXj7mf0akQX(string $J_scC, $CXM_A, $DFpIk, $YctT5) : self
    {
        goto kTmwj;
        kTmwj:
        $dV9QE = App::make(RIRnT0b6ENemU::class)->mw8WSqR4dJv(HMzvJtEcyxrN7::m4Lnp5opuAR($J_scC));
        goto rSp_6;
        GNBl0:
        return $uAxsj->mWZucd0nKyW();
        goto Q20aA;
        rSp_6:
        $uAxsj = new self($dV9QE, $CXM_A);
        goto nkzR5;
        lcT3J:
        $uAxsj->mlS5irobHNA(EpMPhiTVzNYqA::UPLOADING);
        goto GNBl0;
        nkzR5:
        $uAxsj->m7zKiiwEWsq($YctT5, $CXM_A, $DFpIk);
        goto lcT3J;
        Q20aA:
    }
    public static function marMbitayPI($dV9QE, $RndMA, $luwqK, $YctT5, $TxEfI = false) : self
    {
        goto bI83F;
        bI83F:
        $uAxsj = new self($dV9QE, $RndMA);
        goto FbKKC;
        FbKKC:
        $uAxsj->m7zKiiwEWsq($YctT5, $RndMA, $luwqK, $TxEfI);
        goto k4XqT;
        k4XqT:
        $uAxsj->mlS5irobHNA(EpMPhiTVzNYqA::UPLOADING);
        goto e6sDP;
        e6sDP:
        return $uAxsj;
        goto N0w4J;
        N0w4J:
    }
}
