<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Core\Observer\Yr9hIYbWeBY4M;
use Jfs\Uploader\Core\Traits\Ep55xNLBGc2Ux;
use Jfs\Uploader\Core\Traits\LPvREnedjbdSc;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Exception\DQNrWKzuuQ4gB;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Jfs\Uploader\Exception\MbrGjey4Z1MjR;
use Jfs\Uploader\Service\Ti53myCAJIBMS;
final class Awxn6mQyQaPNK implements IEfiXfym24wIp
{
    use Ep55xNLBGc2Ux;
    use LPvREnedjbdSc;
    private $oFNmI;
    private function __construct($ezBDN, $GiTtn)
    {
        $this->CqvUz = $ezBDN;
        $this->fWhmx = $GiTtn;
    }
    private function mWn31JFb6YW(string $mJZ7g, $GiTtn, $Cv4pg, bool $L1ZW4 = false) : void
    {
        $this->m7NixpKJfrg(new Yr9hIYbWeBY4M($this, $GiTtn, $Cv4pg, $mJZ7g, $L1ZW4));
    }
    public function getFile()
    {
        return $this->CqvUz;
    }
    public function mLCO6PoKT3u(array $G2055) : void
    {
        $this->oFNmI = $G2055;
    }
    public function mG1W4IroAB2() : void
    {
        $this->mNT1f7OoTvx(N4CY6qDTBAjPa::UPLOADING);
    }
    public function mS05uU0WwUI() : void
    {
        $this->mNT1f7OoTvx(N4CY6qDTBAjPa::UPLOADED);
    }
    public function mtjblsgDS7P() : void
    {
        $this->mNT1f7OoTvx(N4CY6qDTBAjPa::PROCESSING);
    }
    public function mShQCOziZtK() : void
    {
        $this->mNT1f7OoTvx(N4CY6qDTBAjPa::FINISHED);
    }
    public function muYcE6LnfOG() : void
    {
        $this->mNT1f7OoTvx(N4CY6qDTBAjPa::ABORTED);
    }
    public function mQYPLqpKYRv() : array
    {
        return $this->oFNmI;
    }
    public static function mlonyXM23q3(string $eXur0, $QUJc4, $Q0shJ, $mJZ7g) : self
    {
        goto ZCgHY;
        plnuU:
        $GRTIv->myNb3hyTkbG(N4CY6qDTBAjPa::UPLOADING);
        goto ftTl_;
        ZCgHY:
        $ezBDN = App::make(Ti53myCAJIBMS::class)->mt7BmR82Kvz(IVTeeOwHA8NRW::mtYQ0zAThf7($eXur0));
        goto BPo5n;
        ftTl_:
        return $GRTIv->mBx1DvXlwpF();
        goto SfvuV;
        nMars:
        $GRTIv->mWn31JFb6YW($mJZ7g, $QUJc4, $Q0shJ);
        goto plnuU;
        BPo5n:
        $GRTIv = new self($ezBDN, $QUJc4);
        goto nMars;
        SfvuV:
    }
    public static function mvBhEH5MI4h($ezBDN, $GiTtn, $Cv4pg, $mJZ7g, $L1ZW4 = false) : self
    {
        goto do4eJ;
        dDd77:
        return $GRTIv;
        goto qRo4B;
        do4eJ:
        $GRTIv = new self($ezBDN, $GiTtn);
        goto khFjB;
        khFjB:
        $GRTIv->mWn31JFb6YW($mJZ7g, $GiTtn, $Cv4pg, $L1ZW4);
        goto WJxEv;
        WJxEv:
        $GRTIv->myNb3hyTkbG(N4CY6qDTBAjPa::UPLOADING);
        goto dDd77;
        qRo4B:
    }
}
