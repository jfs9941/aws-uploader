<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Contracts\TdTpyTw87RXgQ;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\Traits\G7E8tu8BtZX7c;
use Jfs\Uploader\Core\Traits\WbbiNrJy3XNAD;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
class IfBHv1AJhiIDu extends OavRsjNQCayKr implements QguGxHrrpjTia
{
    use G7E8tu8BtZX7c;
    use WbbiNrJy3XNAD;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $bl6S5, string $TlRjW) : self
    {
        goto VY3m7;
        iSySJ:
        return $dajVn;
        goto ht0Do;
        yAJj5:
        $dajVn->mC8nuYteIk4(IOEDyer18cpSA::UPLOADING);
        goto iSySJ;
        VY3m7:
        $dajVn = new self(['id' => $bl6S5, 'type' => $TlRjW, 'status' => IOEDyer18cpSA::UPLOADING]);
        goto yAJj5;
        ht0Do:
    }
    public function width() : ?int
    {
        goto qwaDn;
        lNFm8:
        return $tp6F0;
        goto nfoJ2;
        wX73W:
        if (!$tp6F0) {
            goto l9F93;
        }
        goto lNFm8;
        nfoJ2:
        l9F93:
        goto f2pW1;
        qwaDn:
        $tp6F0 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto wX73W;
        f2pW1:
        return null;
        goto slyma;
        slyma:
    }
    public function height() : ?int
    {
        goto z24_D;
        z24_D:
        $iNVXG = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto oWb5j;
        y_700:
        return $iNVXG;
        goto RTW4F;
        RTW4F:
        BFZQe:
        goto skMfH;
        oWb5j:
        if (!$iNVXG) {
            goto BFZQe;
        }
        goto y_700;
        skMfH:
        return null;
        goto kaxJB;
        kaxJB:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($dajVn) {
            goto HkhfF;
            d4Auh:
            cOWFG:
            goto aoDsG;
            io3jP:
            qgJmD:
            goto QQ2dK;
            yLbje:
            return;
            goto io3jP;
            HkhfF:
            $pUH28 = $dajVn->getDirty();
            goto ffjyB;
            QQ2dK:
            if (!($pUH28['thumbnail'] || $pUH28['hls_path'])) {
                goto cOWFG;
            }
            goto bA9rE;
            bA9rE:
            IfBHv1AJhiIDu::where('parent_id', $dajVn->getAttribute('id'))->update(['thumbnail' => $dajVn->getAttributes()['thumbnail'], 'hls_path' => $dajVn->getAttributes()['hls_path']]);
            goto d4Auh;
            ffjyB:
            if (!(!array_key_exists('thumbnail', $pUH28) && !array_key_exists('hls_path', $pUH28))) {
                goto qgJmD;
            }
            goto yLbje;
            aoDsG:
        });
    }
    public function msVKtm0fuSf()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mLtZ2NEbMb3()
    {
        return $this->getAttribute('id');
    }
    public function mfTv2JQLnYd() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto z5LmQ;
        pRiUV:
        aXIEs:
        goto RNmWh;
        kDzbE:
        $hdfBo['thumbnail'] = $XXXuf->resolveThumbnail($this);
        goto do3kl;
        RNmWh:
        $hdfBo['player_url'] = $XXXuf->resolvePathForHlsVideo($this, true);
        goto wEqMa;
        UcUrR:
        goto f7w1Y;
        goto pRiUV;
        MbbCp:
        $hdfBo['player_url'] = $XXXuf->resolvePath($this, $this->getAttribute('driver'));
        goto UcUrR;
        A4iOi:
        $hdfBo = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $XXXuf->resolvePath($this, $this->getAttribute('driver'))];
        goto k31rf;
        k31rf:
        if ($this->getAttribute('hls_path')) {
            goto aXIEs;
        }
        goto MbbCp;
        wEqMa:
        f7w1Y:
        goto kDzbE;
        do3kl:
        return $hdfBo;
        goto wtotl;
        z5LmQ:
        $XXXuf = app(TdTpyTw87RXgQ::class);
        goto A4iOi;
        wtotl:
    }
    public function getThumbnails()
    {
        goto JDUUi;
        TA5C7:
        return array_map(function ($oChgQ) use($XXXuf) {
            return $XXXuf->resolvePath($oChgQ);
        }, $kp2c0);
        goto UNUKe;
        JDUUi:
        $kp2c0 = $this->getAttribute('generated_previews') ?? [];
        goto tSvJF;
        tSvJF:
        $XXXuf = app(TdTpyTw87RXgQ::class);
        goto TA5C7;
        UNUKe:
    }
    public static function mGQz4LugI5K(OavRsjNQCayKr $jGsBp) : IfBHv1AJhiIDu
    {
        goto aIftX;
        rXHCy:
        return $jGsBp;
        goto jIOtb;
        aIftX:
        if (!$jGsBp instanceof IfBHv1AJhiIDu) {
            goto jwCXn;
        }
        goto rXHCy;
        jIOtb:
        jwCXn:
        goto S4oQb;
        S4oQb:
        return (new IfBHv1AJhiIDu())->fill($jGsBp->getAttributes());
        goto FNrNA;
        FNrNA:
    }
}
