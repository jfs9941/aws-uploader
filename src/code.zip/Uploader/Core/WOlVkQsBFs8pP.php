<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
final class WOlVkQsBFs8pP
{
    public $filename;
    public $YE0IW;
    public $B4WH4;
    public $i917H;
    public $LHc1a;
    public $AY7wK;
    public $Qbrmb;
    public $status;
    public $O5trU;
    public $mIA_S;
    public $jE_8B = 's3';
    public $r9Pau = [];
    public function __construct($SFGUb, $QwyTJ, $ImFse, $MO1g2, $TZqXq, $ec0ac, $oLdew, $YvDsx, $DLEqG, $y1uXc, $GWbyt = 's3', $IDZ5l = [])
    {
        goto JJ2m2;
        BYBkp:
        $this->jE_8B = $GWbyt;
        goto o4EV_;
        Li9OE:
        $this->LHc1a = $TZqXq;
        goto g8Oqk;
        j98c1:
        $this->i917H = $MO1g2;
        goto Li9OE;
        MZ35R:
        $this->status = $YvDsx;
        goto CPj3d;
        CPj3d:
        $this->O5trU = $DLEqG;
        goto HB0yy;
        Jixp6:
        $this->Qbrmb = $oLdew;
        goto MZ35R;
        SDuA1:
        $this->B4WH4 = $ImFse;
        goto j98c1;
        HB0yy:
        $this->mIA_S = $y1uXc;
        goto BYBkp;
        g8Oqk:
        $this->AY7wK = $ec0ac;
        goto Jixp6;
        o4EV_:
        $this->r9Pau = $IDZ5l;
        goto pxFYk;
        h6Vzx:
        $this->YE0IW = $QwyTJ;
        goto SDuA1;
        JJ2m2:
        $this->filename = $SFGUb;
        goto h6Vzx;
        pxFYk:
    }
    private static function mApu4n63Wpg() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mNfwcKWAyfu() : array
    {
        return array_flip(self::mApu4n63Wpg());
    }
    public function toArray() : array
    {
        $Jvv77 = self::mApu4n63Wpg();
        return [$Jvv77['filename'] => $this->filename, $Jvv77['fileExtension'] => $this->YE0IW, $Jvv77['mimeType'] => $this->B4WH4, $Jvv77['fileSize'] => $this->i917H, $Jvv77['chunkSize'] => $this->LHc1a, $Jvv77['checksums'] => $this->AY7wK, $Jvv77['totalChunk'] => $this->Qbrmb, $Jvv77['status'] => $this->status, $Jvv77['userId'] => $this->O5trU, $Jvv77['uploadId'] => $this->mIA_S, $Jvv77['driver'] => $this->jE_8B, $Jvv77['parts'] => $this->r9Pau];
    }
    public static function mcSTjhdi3jH(array $HhY2y) : self
    {
        $WU3Ok = array_flip(self::mNfwcKWAyfu());
        return new self($HhY2y[$WU3Ok['filename']] ?? $HhY2y['filename'] ?? '', $HhY2y[$WU3Ok['fileExtension']] ?? $HhY2y['fileExtension'] ?? '', $HhY2y[$WU3Ok['mimeType']] ?? $HhY2y['mimeType'] ?? '', $HhY2y[$WU3Ok['fileSize']] ?? $HhY2y['fileSize'] ?? 0, $HhY2y[$WU3Ok['chunkSize']] ?? $HhY2y['chunkSize'] ?? 0, $HhY2y[$WU3Ok['checksums']] ?? $HhY2y['checksums'] ?? [], $HhY2y[$WU3Ok['totalChunk']] ?? $HhY2y['totalChunk'] ?? 0, $HhY2y[$WU3Ok['status']] ?? $HhY2y['status'] ?? 0, $HhY2y[$WU3Ok['userId']] ?? $HhY2y['userId'] ?? 0, $HhY2y[$WU3Ok['uploadId']] ?? $HhY2y['uploadId'] ?? '', $HhY2y[$WU3Ok['driver']] ?? $HhY2y['driver'] ?? 's3', $HhY2y[$WU3Ok['parts']] ?? $HhY2y['parts'] ?? []);
    }
    public static function mrClfEjUpZO($DEfd1) : self
    {
        goto WcyOc;
        TnOWB:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto J_oX2;
        yJ_ga:
        nDICU:
        goto TnOWB;
        oWJ9P:
        return self::mcSTjhdi3jH($DEfd1);
        goto yJ_ga;
        WcyOc:
        if (!(isset($DEfd1['fn']) || isset($DEfd1['fe']))) {
            goto nDICU;
        }
        goto oWJ9P;
        J_oX2:
    }
    public function mqcvRZvfhlP(string $y1uXc) : void
    {
        $this->mIA_S = $y1uXc;
    }
    public function meN28KiYulF(array $IDZ5l) : void
    {
        $this->r9Pau = $IDZ5l;
    }
    public static function mQFar7u0XBm($PQjbH, $Quhfo, $w_BOX, $DLEqG, $TZqXq, $ec0ac, $GWbyt)
    {
        return new self($PQjbH->getFilename(), $PQjbH->getExtension(), $Quhfo, $w_BOX, $TZqXq, $ec0ac, count($ec0ac), UimQKBIuLCEAO::UPLOADING, $DLEqG, 0, $GWbyt, []);
    }
    public static function md7VzGoRhNQ($ld8Ad)
    {
        return 'metadata/' . $ld8Ad . '.json';
    }
    public function maCZ8QaOTiE()
    {
        return 's3' === $this->jE_8B ? ZBLpZ2qUZ4P6C::S3 : ZBLpZ2qUZ4P6C::LOCAL;
    }
}
