<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Contracts\QPcmBScQDUpcH;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Traits\XU255kYjU0NUS;
use Jfs\Uploader\Core\Traits\CrEAGEW2Ahp7l;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Service\W6MKQSWDEHAwJ;
class Z7LUL65CwqbbF extends MEyH4ejCzSk64 implements MEWwofwAYqgaI
{
    use XU255kYjU0NUS;
    use CrEAGEW2Ahp7l;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $pODrs, string $iJrca) : self
    {
        goto fJixL;
        fJixL:
        $a97TB = new self(['id' => $pODrs, 'type' => $iJrca, 'status' => FdWrko7bmoI4Y::UPLOADING]);
        goto R02OL;
        dYCu0:
        return $a97TB;
        goto tbo3z;
        R02OL:
        $a97TB->mocw0y5gdUS(FdWrko7bmoI4Y::UPLOADING);
        goto dYCu0;
        tbo3z:
    }
    public function getView() : array
    {
        $jku3P = app(QPcmBScQDUpcH::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $jku3P->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $jku3P->resolveThumbnail($this)];
    }
    public static function m1TDGa0a0oK(MEyH4ejCzSk64 $pkR_A) : Z7LUL65CwqbbF
    {
        goto b0_6c;
        b0_6c:
        if (!$pkR_A instanceof Z7LUL65CwqbbF) {
            goto qVu2F;
        }
        goto UbOk_;
        TtuLJ:
        return (new Z7LUL65CwqbbF())->fill($pkR_A->getAttributes());
        goto No_N8;
        puqVh:
        qVu2F:
        goto TtuLJ;
        UbOk_:
        return $pkR_A;
        goto puqVh;
        No_N8:
    }
}
