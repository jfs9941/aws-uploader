<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Contracts\Bvfii9tMROJRp;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\Traits\SvjIu3InVS06e;
use Jfs\Uploader\Core\Traits\YXqL8Vu76ZyNK;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Service\PYjKYaymEKJyi;
class UKkbXBDRxjSUY extends IeEvjRaj1LMmG implements VuQzRNCSz5bHK
{
    use SvjIu3InVS06e;
    use YXqL8Vu76ZyNK;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $uXjFZ, string $n13FM) : self
    {
        goto tpCjZ;
        emioN:
        $VGttq->m651SlcakeY(ZP6Ky842t6y9Y::UPLOADING);
        goto VZuNL;
        VZuNL:
        return $VGttq;
        goto lvNTB;
        tpCjZ:
        $VGttq = new self(['id' => $uXjFZ, 'type' => $n13FM, 'status' => ZP6Ky842t6y9Y::UPLOADING]);
        goto emioN;
        lvNTB:
    }
    public function getView() : array
    {
        $V2cKr = app(Bvfii9tMROJRp::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $V2cKr->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $V2cKr->resolveThumbnail($this)];
    }
    public static function miZKp3XAvG6(IeEvjRaj1LMmG $UmLJ2) : UKkbXBDRxjSUY
    {
        goto roCmK;
        yg_ZP:
        gp3og:
        goto Shn2t;
        Shn2t:
        return (new UKkbXBDRxjSUY())->fill($UmLJ2->getAttributes());
        goto AohHY;
        H4U9E:
        return $UmLJ2;
        goto yg_ZP;
        roCmK:
        if (!$UmLJ2 instanceof UKkbXBDRxjSUY) {
            goto gp3og;
        }
        goto H4U9E;
        AohHY:
    }
}
