<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; use Jfs\Uploader\Contracts\WrFez6oTdpaJs; use Jfs\Uploader\Contracts\PICYo9hgvioW3; use Jfs\Uploader\Core\Traits\WikDwhxDkMZ67; use Jfs\Uploader\Core\Traits\PVtMt2FkJYbaz; use Jfs\Uploader\Enum\FileStatus; use Jfs\Uploader\Service\CP7aCOgYEVsuX; class NoqRziJe9G7Nn extends J5wym0qxH1hlR implements WrFez6oTdpaJs { use WikDwhxDkMZ67; use PVtMt2FkJYbaz; public function getType() : string { return 'image'; } public static function createFromScratch(string $rOtzv, string $g7qa1) : self { goto epjTO; I7s18: return $ULD7R; goto zU4Qr; mYyBH: $ULD7R->mui5JkXMWEZ(FileStatus::UPLOADING); goto I7s18; epjTO: $ULD7R = new self(['id' => $rOtzv, 'type' => $g7qa1, 'status' => FileStatus::UPLOADING]); goto mYyBH; zU4Qr: } public function getView() : array { $fY1BR = app(PICYo9hgvioW3::class); return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $fY1BR->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $fY1BR->resolveThumbnail($this)]; } public static function mUeC8vrL96v(J5wym0qxH1hlR $fihHa) : NoqRziJe9G7Nn { goto aXvPw; ZcM32: return (new NoqRziJe9G7Nn())->fill($fihHa->getAttributes()); goto AxGTs; kvYLZ: return $fihHa; goto Z3DZf; Z3DZf: E1jqb: goto ZcM32; aXvPw: if (!$fihHa instanceof NoqRziJe9G7Nn) { goto E1jqb; } goto kvYLZ; AxGTs: } }
