<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Enum\FileDriver;
abstract  class TvpGfrAj9WMXE extends Model implements UZjgdpyMf06F7
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mSNOW0ZI8Zu() : bool
    {
        goto ur9Wv;
        sUYu3:
        return true;
        goto HHfYL;
        HHfYL:
        SVljH:
        goto FMtBA;
        FMtBA:
        return !$this->mhllREHl1YM();
        goto w4Kr5;
        ur9Wv:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto SVljH;
        }
        goto sUYu3;
        w4Kr5:
    }
    protected function mhllREHl1YM() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
