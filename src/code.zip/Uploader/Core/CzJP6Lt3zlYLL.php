<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Core\Observer\OdV1LxzeMMLBh;
use Jfs\Uploader\Core\Traits\PaoPogOgT8Y2t;
use Jfs\Uploader\Core\Traits\GzYkrJxGq9goW;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Exception\HA83jJulZGJMz;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Jfs\Uploader\Exception\GK2ekyHdTOcHc;
use Jfs\Uploader\Service\WkAFfUCbIBC7t;
final class CzJP6Lt3zlYLL implements M9ges0moH9yTs
{
    use PaoPogOgT8Y2t;
    use GzYkrJxGq9goW;
    private $J8mRp;
    private function __construct($QxvEM, $eL8cO)
    {
        $this->a2FAI = $QxvEM;
        $this->mY3Ys = $eL8cO;
    }
    private function mvLfoMj8uh2(string $bqJVe, $eL8cO, $phksh, bool $z1sU7 = false) : void
    {
        $this->mPleB6N0Rmu(new OdV1LxzeMMLBh($this, $eL8cO, $phksh, $bqJVe, $z1sU7));
    }
    public function getFile()
    {
        return $this->a2FAI;
    }
    public function mE1wovYgwvR(array $uQi4m) : void
    {
        $this->J8mRp = $uQi4m;
    }
    public function mg1NNZpymHK() : void
    {
        $this->mZunb8ueiKo(U8OFutptQGm3S::UPLOADING);
    }
    public function mQIKqLN2iux() : void
    {
        $this->mZunb8ueiKo(U8OFutptQGm3S::UPLOADED);
    }
    public function mOIa032st9z() : void
    {
        $this->mZunb8ueiKo(U8OFutptQGm3S::PROCESSING);
    }
    public function mZwjDyPYlWH() : void
    {
        $this->mZunb8ueiKo(U8OFutptQGm3S::FINISHED);
    }
    public function mPlcqHUs2ma() : void
    {
        $this->mZunb8ueiKo(U8OFutptQGm3S::ABORTED);
    }
    public function mlc1qkgLpks() : array
    {
        return $this->J8mRp;
    }
    public static function mVy96SS3Bzs(string $UcmDx, $tEUpR, $hTkyv, $bqJVe) : self
    {
        goto a3v5K;
        HJ4fu:
        $Vpdpr->mM8xXTkFSyC(U8OFutptQGm3S::UPLOADING);
        goto sFPNL;
        AKx0P:
        $Vpdpr = new self($QxvEM, $tEUpR);
        goto EOII_;
        a3v5K:
        $QxvEM = App::make(WkAFfUCbIBC7t::class)->mfrezBo3W7l(TNpNhMZr7RgP2::mqIq70uMfk6($UcmDx));
        goto AKx0P;
        sFPNL:
        return $Vpdpr->m41dI3cww1h();
        goto B1bqj;
        EOII_:
        $Vpdpr->mvLfoMj8uh2($bqJVe, $tEUpR, $hTkyv);
        goto HJ4fu;
        B1bqj:
    }
    public static function mv2dA6jVf9e($QxvEM, $eL8cO, $phksh, $bqJVe, $z1sU7 = false) : self
    {
        goto kjjB7;
        kjjB7:
        $Vpdpr = new self($QxvEM, $eL8cO);
        goto xVei3;
        LG0Uw:
        return $Vpdpr;
        goto UWt30;
        xVei3:
        $Vpdpr->mvLfoMj8uh2($bqJVe, $eL8cO, $phksh, $z1sU7);
        goto B4fJe;
        B4fJe:
        $Vpdpr->mM8xXTkFSyC(U8OFutptQGm3S::UPLOADING);
        goto LG0Uw;
        UWt30:
    }
}
