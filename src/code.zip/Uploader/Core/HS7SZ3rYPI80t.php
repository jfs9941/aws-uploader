<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Contracts\T1J9j7WqyAUZ6;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\Traits\Lch9OtTvfn4IQ;
use Jfs\Uploader\Core\Traits\WUkQAePShMtJo;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
class HS7SZ3rYPI80t extends GGOMDClEFMcsH implements WHyfIbzEzUFEe
{
    use Lch9OtTvfn4IQ;
    use WUkQAePShMtJo;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $eNeio, string $QGmwG) : self
    {
        goto BZYOz;
        Q3Pi3:
        return $ZtI9P;
        goto JLSfZ;
        mRpL1:
        $ZtI9P->mNsps8Id3BK(T93Mcsw1gA3an::UPLOADING);
        goto Q3Pi3;
        BZYOz:
        $ZtI9P = new self(['id' => $eNeio, 'type' => $QGmwG, 'status' => T93Mcsw1gA3an::UPLOADING]);
        goto mRpL1;
        JLSfZ:
    }
    public function width() : ?int
    {
        goto D9XVE;
        J4TJL:
        return null;
        goto JqFup;
        mh2A8:
        return $w0IG6;
        goto ez1m7;
        ez1m7:
        wkzfM:
        goto J4TJL;
        EspR4:
        if (!$w0IG6) {
            goto wkzfM;
        }
        goto mh2A8;
        D9XVE:
        $w0IG6 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto EspR4;
        JqFup:
    }
    public function height() : ?int
    {
        goto jhqxd;
        QgYPo:
        return $sIm70;
        goto ekRMb;
        jhqxd:
        $sIm70 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto c5bSr;
        c5bSr:
        if (!$sIm70) {
            goto RumZW;
        }
        goto QgYPo;
        ekRMb:
        RumZW:
        goto IzPel;
        IzPel:
        return null;
        goto gmfpX;
        gmfpX:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($ZtI9P) {
            goto bboji;
            Gg_IS:
            HS7SZ3rYPI80t::where('parent_id', $ZtI9P->getAttribute('id'))->update(['thumbnail' => $ZtI9P->getAttributes()['thumbnail'], 'hls_path' => $ZtI9P->getAttributes()['hls_path']]);
            goto W84rp;
            bboji:
            $NYoOB = $ZtI9P->getDirty();
            goto mBkYy;
            mFvuk:
            if (!($NYoOB['thumbnail'] || $NYoOB['hls_path'])) {
                goto BWsP4;
            }
            goto Gg_IS;
            mBkYy:
            if (!(!array_key_exists('thumbnail', $NYoOB) && !array_key_exists('hls_path', $NYoOB))) {
                goto LXCYX;
            }
            goto neUxm;
            W84rp:
            BWsP4:
            goto yXjYr;
            KkNu4:
            LXCYX:
            goto mFvuk;
            neUxm:
            return;
            goto KkNu4;
            yXjYr:
        });
    }
    public function madF6UYZmWF()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mme9OtZX2iP()
    {
        return $this->getAttribute('id');
    }
    public function m8MX0IHyJMe() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto MYjop;
        lN7Fj:
        if ($this->getAttribute('hls_path')) {
            goto heODS;
        }
        goto FMYeR;
        urgrX:
        goto k7YJ3;
        goto jbz2E;
        fF1y4:
        $zFO_M = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $M3DlU->resolvePath($this, $this->getAttribute('driver'))];
        goto lN7Fj;
        wXoI6:
        $zFO_M['player_url'] = $M3DlU->resolvePathForHlsVideo($this, true);
        goto zG2ac;
        FMYeR:
        $zFO_M['player_url'] = $M3DlU->resolvePath($this, $this->getAttribute('driver'));
        goto urgrX;
        dIEtA:
        $zFO_M['thumbnail'] = $M3DlU->resolveThumbnail($this);
        goto c2QyC;
        zG2ac:
        k7YJ3:
        goto dIEtA;
        MYjop:
        $M3DlU = app(T1J9j7WqyAUZ6::class);
        goto fF1y4;
        c2QyC:
        return $zFO_M;
        goto r7ZXA;
        jbz2E:
        heODS:
        goto wXoI6;
        r7ZXA:
    }
    public function getThumbnails()
    {
        goto zS14l;
        zS14l:
        $YZCuD = $this->getAttribute('generated_previews') ?? [];
        goto zikF0;
        NJGXk:
        return array_map(function ($N07Z2) use($M3DlU) {
            return $M3DlU->resolvePath($N07Z2);
        }, $YZCuD);
        goto r0NHJ;
        zikF0:
        $M3DlU = app(T1J9j7WqyAUZ6::class);
        goto NJGXk;
        r0NHJ:
    }
    public static function mW3R7ViluAh(GGOMDClEFMcsH $FX5Wq) : HS7SZ3rYPI80t
    {
        goto j41Zu;
        j41Zu:
        if (!$FX5Wq instanceof HS7SZ3rYPI80t) {
            goto amM_D;
        }
        goto GE8Cy;
        bvI3J:
        amM_D:
        goto rpiCV;
        GE8Cy:
        return $FX5Wq;
        goto bvI3J;
        rpiCV:
        return (new HS7SZ3rYPI80t())->fill($FX5Wq->getAttributes());
        goto Tflie;
        Tflie:
    }
}
