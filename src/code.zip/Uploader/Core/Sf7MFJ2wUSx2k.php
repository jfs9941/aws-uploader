<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Contracts\Hj0NrxjG6qaVy;
use Jfs\Uploader\Core\Traits\VxlX0xA9Oyzyn;
use Jfs\Uploader\Core\Traits\GnXq4OXXJLYXp;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Service\RkcpO1qn0gOFt;
class Sf7MFJ2wUSx2k extends O4HsadxAyKjYq implements XZsrc8KnXftCK
{
    use VxlX0xA9Oyzyn;
    use GnXq4OXXJLYXp;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $KKu2U, string $FonuJ) : self
    {
        goto YKK32;
        YKK32:
        $xobEP = new self(['id' => $KKu2U, 'type' => $FonuJ, 'status' => UimQKBIuLCEAO::UPLOADING]);
        goto dS5oF;
        Z9u8t:
        return $xobEP;
        goto IB9jD;
        dS5oF:
        $xobEP->mnZV8lryeWr(UimQKBIuLCEAO::UPLOADING);
        goto Z9u8t;
        IB9jD:
    }
    public function getView() : array
    {
        $z_puv = app(Hj0NrxjG6qaVy::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $z_puv->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $z_puv->resolveThumbnail($this)];
    }
    public static function mtnSOrZmhmT(O4HsadxAyKjYq $NyN9S) : Sf7MFJ2wUSx2k
    {
        goto hkxhG;
        PRVT3:
        return (new Sf7MFJ2wUSx2k())->fill($NyN9S->getAttributes());
        goto qi82d;
        AqKow:
        k_82w:
        goto PRVT3;
        DeqOB:
        return $NyN9S;
        goto AqKow;
        hkxhG:
        if (!$NyN9S instanceof Sf7MFJ2wUSx2k) {
            goto k_82w;
        }
        goto DeqOB;
        qi82d:
    }
}
