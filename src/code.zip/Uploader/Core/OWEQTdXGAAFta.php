<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Illuminate\Database\Eloquent\Model;
abstract  class OWEQTdXGAAFta extends Model implements FpdzXEk0mryCJ
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mDzSbKe5mdW() : bool
    {
        goto jwM6o;
        jwM6o:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto UN11P;
        }
        goto Sd1YO;
        ZsHSU:
        UN11P:
        goto triSb;
        Sd1YO:
        return true;
        goto ZsHSU;
        triSb:
        return !$this->mdle2fVNexM();
        goto JHpLq;
        JHpLq:
    }
    protected function mdle2fVNexM() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
