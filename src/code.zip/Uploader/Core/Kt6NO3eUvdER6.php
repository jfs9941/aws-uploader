<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Core\Traits\DE88el5C1yZlG;
use Jfs\Uploader\Core\Traits\J0nlGVgP1R1Ai;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
class Kt6NO3eUvdER6 extends DMUaxGX7XHAI0 implements BCa3K9pPFzXM0
{
    use DE88el5C1yZlG;
    use J0nlGVgP1R1Ai;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $XKudI, string $KvyPo) : self
    {
        goto GtI8_;
        vIka4:
        return $yZXjN;
        goto OLmt4;
        mldBX:
        $yZXjN->m3B430t4QRf(EUkqoDwU9Zcvh::UPLOADING);
        goto vIka4;
        GtI8_:
        $yZXjN = new self(['id' => $XKudI, 'type' => $KvyPo, 'status' => EUkqoDwU9Zcvh::UPLOADING]);
        goto mldBX;
        OLmt4:
    }
    public function width() : ?int
    {
        goto JeL7f;
        BdQOe:
        return null;
        goto VpOHk;
        JeL7f:
        $kl8qs = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto cOaZA;
        cOaZA:
        if (!$kl8qs) {
            goto c97Uy;
        }
        goto BcdWX;
        BcdWX:
        return $kl8qs;
        goto Ai3ai;
        Ai3ai:
        c97Uy:
        goto BdQOe;
        VpOHk:
    }
    public function height() : ?int
    {
        goto oeGfV;
        opCOl:
        return $nl3gy;
        goto yjX_z;
        yjX_z:
        trsw4:
        goto r9kjs;
        r9kjs:
        return null;
        goto z3qTm;
        oeGfV:
        $nl3gy = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto IZuvc;
        IZuvc:
        if (!$nl3gy) {
            goto trsw4;
        }
        goto opCOl;
        z3qTm:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($yZXjN) {
            goto WGvxJ;
            FGxQk:
            if (!(!array_key_exists('thumbnail', $Wl93o) && !array_key_exists('hls_path', $Wl93o))) {
                goto OhEaY;
            }
            goto pece6;
            ltkb4:
            if (!($Wl93o['thumbnail'] || $Wl93o['hls_path'])) {
                goto ikyAO;
            }
            goto HFyLQ;
            pece6:
            return;
            goto iNU4D;
            iNU4D:
            OhEaY:
            goto ltkb4;
            lG5o0:
            ikyAO:
            goto Vtj0P;
            WGvxJ:
            $Wl93o = $yZXjN->getDirty();
            goto FGxQk;
            HFyLQ:
            Kt6NO3eUvdER6::where('parent_id', $yZXjN->getAttribute('id'))->update(['thumbnail' => $yZXjN->getAttributes()['thumbnail'], 'hls_path' => $yZXjN->getAttributes()['hls_path']]);
            goto lG5o0;
            Vtj0P:
        });
    }
    public function mjAf2zqhMGr()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mzVsE4egU4U()
    {
        return $this->getAttribute('id');
    }
    public function m44JVj32w1m() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto BTxpf;
        iUWbf:
        $BxSpy['thumbnail'] = $d1dPQ->resolveThumbnail($this);
        goto TyXxL;
        AdqCK:
        Lflkd:
        goto iUWbf;
        uu3mg:
        $BxSpy['player_url'] = $d1dPQ->resolvePathForHlsVideo($this, true);
        goto AdqCK;
        wxbJ8:
        $BxSpy = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $d1dPQ->resolvePath($this, $this->getAttribute('driver'))];
        goto eNB2u;
        IFOTf:
        gpQXx:
        goto uu3mg;
        BTxpf:
        $d1dPQ = app(Yuf8dMzRcjZ21::class);
        goto wxbJ8;
        TyXxL:
        return $BxSpy;
        goto f_QGf;
        eNB2u:
        if ($this->getAttribute('hls_path')) {
            goto gpQXx;
        }
        goto RYZAz;
        oGN2s:
        goto Lflkd;
        goto IFOTf;
        RYZAz:
        $BxSpy['player_url'] = $d1dPQ->resolvePath($this, $this->getAttribute('driver'));
        goto oGN2s;
        f_QGf:
    }
    public function getThumbnails()
    {
        goto POazh;
        yRNzB:
        $d1dPQ = app(Yuf8dMzRcjZ21::class);
        goto P_akM;
        POazh:
        $OqZDb = $this->getAttribute('generated_previews') ?? [];
        goto yRNzB;
        P_akM:
        return array_map(function ($c2ORW) use($d1dPQ) {
            return $d1dPQ->resolvePath($c2ORW);
        }, $OqZDb);
        goto CNYQG;
        CNYQG:
    }
    public static function my6JDcooTU0(DMUaxGX7XHAI0 $hEivM) : Kt6NO3eUvdER6
    {
        goto cUnrQ;
        cUnrQ:
        if (!$hEivM instanceof Kt6NO3eUvdER6) {
            goto Um_uz;
        }
        goto Xbe0j;
        yaqE0:
        Um_uz:
        goto MXpA5;
        Xbe0j:
        return $hEivM;
        goto yaqE0;
        MXpA5:
        return (new Kt6NO3eUvdER6())->fill($hEivM->getAttributes());
        goto Vle9x;
        Vle9x:
    }
}
