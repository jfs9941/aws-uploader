<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Core\Traits\RN8oxnSswJ42z;
use Jfs\Uploader\Core\Traits\DbEmnet2FoHTm;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class CSQMvXC33KbbS extends Dup6KVtAFNCUq implements PxTzgsobiHpcX
{
    use RN8oxnSswJ42z;
    use DbEmnet2FoHTm;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $FeNc2, string $lfMjH) : self
    {
        goto p883u;
        p883u:
        $vtvs_ = new self(['id' => $FeNc2, 'type' => $lfMjH, 'status' => O8RzIjGmSN6fG::UPLOADING]);
        goto SEOm0;
        IH3f2:
        return $vtvs_;
        goto ezBkA;
        SEOm0:
        $vtvs_->mt6YUzzNxIA(O8RzIjGmSN6fG::UPLOADING);
        goto IH3f2;
        ezBkA:
    }
    public function width() : ?int
    {
        goto pg8ZP;
        Na4WK:
        if (!$NixDl) {
            goto s1wXi;
        }
        goto zJE0c;
        zJE0c:
        return $NixDl;
        goto JUynz;
        pg8ZP:
        $NixDl = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto Na4WK;
        JUynz:
        s1wXi:
        goto SVG2X;
        SVG2X:
        return null;
        goto QOvAR;
        QOvAR:
    }
    public function height() : ?int
    {
        goto BPpDu;
        wrrdi:
        return $l4GK0;
        goto ro5LN;
        BPpDu:
        $l4GK0 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto EbCPs;
        ro5LN:
        RrxRj:
        goto ut3GA;
        EbCPs:
        if (!$l4GK0) {
            goto RrxRj;
        }
        goto wrrdi;
        ut3GA:
        return null;
        goto FEAp2;
        FEAp2:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($vtvs_) {
            goto Ko28r;
            Bfqwa:
            if (!($D0p4P['thumbnail'] || $D0p4P['hls_path'])) {
                goto rG_hS;
            }
            goto lztDM;
            F05f1:
            rG_hS:
            goto WPF10;
            en09G:
            CovZm:
            goto Bfqwa;
            Ko28r:
            $D0p4P = $vtvs_->getDirty();
            goto Szpsy;
            lztDM:
            CSQMvXC33KbbS::where('parent_id', $vtvs_->getAttribute('id'))->update(['thumbnail' => $vtvs_->getAttributes()['thumbnail'], 'hls_path' => $vtvs_->getAttributes()['hls_path']]);
            goto F05f1;
            Szpsy:
            if (!(!array_key_exists('thumbnail', $D0p4P) && !array_key_exists('hls_path', $D0p4P))) {
                goto CovZm;
            }
            goto VY2Xd;
            VY2Xd:
            return;
            goto en09G;
            WPF10:
        });
    }
    public function mqFFnuR8hEN()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mQ7wOr9ldMo()
    {
        return $this->getAttribute('id');
    }
    public function m3eM3et8YPc() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto FDTcB;
        FDTcB:
        $rm8QX = app(MpZUpGr3YFIhj::class);
        goto NoEP0;
        lV5rC:
        if ($this->getAttribute('hls_path')) {
            goto pYlmD;
        }
        goto Uer5k;
        BZPkP:
        fcU9v:
        goto VHwbP;
        q0PJW:
        pYlmD:
        goto cf4NR;
        VHwbP:
        $jdl8g['thumbnail'] = $rm8QX->resolveThumbnail($this);
        goto JljcU;
        JljcU:
        return $jdl8g;
        goto i0eun;
        cf4NR:
        $jdl8g['player_url'] = $rm8QX->resolvePathForHlsVideo($this, true);
        goto BZPkP;
        tlH3F:
        goto fcU9v;
        goto q0PJW;
        Uer5k:
        $jdl8g['player_url'] = $rm8QX->resolvePath($this, $this->getAttribute('driver'));
        goto tlH3F;
        NoEP0:
        $jdl8g = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $rm8QX->resolvePath($this, $this->getAttribute('driver'))];
        goto lV5rC;
        i0eun:
    }
    public function getThumbnails()
    {
        goto ITODC;
        ITODC:
        $eB4dA = $this->getAttribute('generated_previews') ?? [];
        goto lHRPW;
        QMTh2:
        return array_map(function ($IlGiN) use($rm8QX) {
            return $rm8QX->resolvePath($IlGiN);
        }, $eB4dA);
        goto rY2u3;
        lHRPW:
        $rm8QX = app(MpZUpGr3YFIhj::class);
        goto QMTh2;
        rY2u3:
    }
    public static function miWN6rba4HM(Dup6KVtAFNCUq $FFbb9) : CSQMvXC33KbbS
    {
        goto pYqSU;
        MunSa:
        return $FFbb9;
        goto XKxUZ;
        pYqSU:
        if (!$FFbb9 instanceof CSQMvXC33KbbS) {
            goto dk0Fx;
        }
        goto MunSa;
        Kn0d_:
        return (new CSQMvXC33KbbS())->fill($FFbb9->getAttributes());
        goto uXnO8;
        XKxUZ:
        dk0Fx:
        goto Kn0d_;
        uXnO8:
    }
}
