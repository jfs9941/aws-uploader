<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
final class BnU61laaiajX2
{
    public $filename;
    public $PFcfx;
    public $X2VU8;
    public $TfMNA;
    public $BWFP_;
    public $s0IrZ;
    public $fwo9M;
    public $status;
    public $wigat;
    public $FEcJW;
    public $n5TQN = 's3';
    public $sON6q = [];
    public function __construct($z5qd9, $ObZOl, $qRKiQ, $eGZ6n, $lYoIc, $nfF1l, $qMgTA, $AmiqG, $W7h0k, $LX_Uw, $Zqemz = 's3', $Wft18 = [])
    {
        goto X0LEr;
        YLNvw:
        $this->n5TQN = $Zqemz;
        goto NhfGv;
        D3rH1:
        $this->X2VU8 = $qRKiQ;
        goto TszGZ;
        wJnzR:
        $this->BWFP_ = $lYoIc;
        goto c0S41;
        nlFi7:
        $this->FEcJW = $LX_Uw;
        goto YLNvw;
        c0S41:
        $this->s0IrZ = $nfF1l;
        goto FEYVx;
        TszGZ:
        $this->TfMNA = $eGZ6n;
        goto wJnzR;
        NhfGv:
        $this->sON6q = $Wft18;
        goto LmQeb;
        rnrL_:
        $this->status = $AmiqG;
        goto OKbep;
        xGks8:
        $this->PFcfx = $ObZOl;
        goto D3rH1;
        X0LEr:
        $this->filename = $z5qd9;
        goto xGks8;
        OKbep:
        $this->wigat = $W7h0k;
        goto nlFi7;
        FEYVx:
        $this->fwo9M = $qMgTA;
        goto rnrL_;
        LmQeb:
    }
    private static function mzrd3gmaj3i() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function manTpqnoEy4() : array
    {
        return array_flip(self::mzrd3gmaj3i());
    }
    public function toArray() : array
    {
        $ZdFh8 = self::mzrd3gmaj3i();
        return [$ZdFh8['filename'] => $this->filename, $ZdFh8['fileExtension'] => $this->PFcfx, $ZdFh8['mimeType'] => $this->X2VU8, $ZdFh8['fileSize'] => $this->TfMNA, $ZdFh8['chunkSize'] => $this->BWFP_, $ZdFh8['checksums'] => $this->s0IrZ, $ZdFh8['totalChunk'] => $this->fwo9M, $ZdFh8['status'] => $this->status, $ZdFh8['userId'] => $this->wigat, $ZdFh8['uploadId'] => $this->FEcJW, $ZdFh8['driver'] => $this->n5TQN, $ZdFh8['parts'] => $this->sON6q];
    }
    public static function md0HuJkhQJi(array $NyxzD) : self
    {
        $wYvJj = array_flip(self::manTpqnoEy4());
        return new self($NyxzD[$wYvJj['filename']] ?? $NyxzD['filename'] ?? '', $NyxzD[$wYvJj['fileExtension']] ?? $NyxzD['fileExtension'] ?? '', $NyxzD[$wYvJj['mimeType']] ?? $NyxzD['mimeType'] ?? '', $NyxzD[$wYvJj['fileSize']] ?? $NyxzD['fileSize'] ?? 0, $NyxzD[$wYvJj['chunkSize']] ?? $NyxzD['chunkSize'] ?? 0, $NyxzD[$wYvJj['checksums']] ?? $NyxzD['checksums'] ?? [], $NyxzD[$wYvJj['totalChunk']] ?? $NyxzD['totalChunk'] ?? 0, $NyxzD[$wYvJj['status']] ?? $NyxzD['status'] ?? 0, $NyxzD[$wYvJj['userId']] ?? $NyxzD['userId'] ?? 0, $NyxzD[$wYvJj['uploadId']] ?? $NyxzD['uploadId'] ?? '', $NyxzD[$wYvJj['driver']] ?? $NyxzD['driver'] ?? 's3', $NyxzD[$wYvJj['parts']] ?? $NyxzD['parts'] ?? []);
    }
    public static function mowxdHh44rb($HE0jk) : self
    {
        goto R0Lz1;
        R0Lz1:
        if (!(isset($HE0jk['fn']) || isset($HE0jk['fe']))) {
            goto yra0a;
        }
        goto Y8Qjj;
        jnFLu:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto gJRwC;
        Y8Qjj:
        return self::md0HuJkhQJi($HE0jk);
        goto AyLtg;
        AyLtg:
        yra0a:
        goto jnFLu;
        gJRwC:
    }
    public function mOkzQvX31nz(string $LX_Uw) : void
    {
        $this->FEcJW = $LX_Uw;
    }
    public function mzqBOhybw6d(array $Wft18) : void
    {
        $this->sON6q = $Wft18;
    }
    public static function mTtDhdxq3zH($VZzWw, $naawS, $YftSz, $W7h0k, $lYoIc, $nfF1l, $Zqemz)
    {
        return new self($VZzWw->getFilename(), $VZzWw->getExtension(), $naawS, $YftSz, $lYoIc, $nfF1l, count($nfF1l), EUkqoDwU9Zcvh::UPLOADING, $W7h0k, 0, $Zqemz, []);
    }
    public static function mqdgOOZkBS0($S6xyJ)
    {
        return 'metadata/' . $S6xyJ . '.json';
    }
    public function mn8AUEYdqqT()
    {
        return 's3' === $this->n5TQN ? Rc6MZhMMdyG6A::S3 : Rc6MZhMMdyG6A::LOCAL;
    }
}
