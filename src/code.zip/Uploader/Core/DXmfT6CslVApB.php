<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Core\Observer\XRRH05LBqJ7EZ;
use Jfs\Uploader\Core\Traits\W5w1leEBsLxKX;
use Jfs\Uploader\Core\Traits\J0nlGVgP1R1Ai;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Exception\BtFXMjsbQEzWB;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Jfs\Uploader\Exception\A0pWCtOCA3zPw;
use Jfs\Uploader\Service\ANTOKA6KWzE7t;
final class DXmfT6CslVApB implements BCa3K9pPFzXM0
{
    use W5w1leEBsLxKX;
    use J0nlGVgP1R1Ai;
    private $M89HW;
    private function __construct($VZzWw, $TuWZt)
    {
        $this->PxcXo = $VZzWw;
        $this->Sdc_x = $TuWZt;
    }
    private function mbdYqurHgjj(string $vT463, $TuWZt, $qg6AO, bool $dpHsf = false) : void
    {
        $this->mCa4XumvZrx(new XRRH05LBqJ7EZ($this, $TuWZt, $qg6AO, $vT463, $dpHsf));
    }
    public function getFile()
    {
        return $this->PxcXo;
    }
    public function mtMSkoI5tr5(array $GeEIH) : void
    {
        $this->M89HW = $GeEIH;
    }
    public function mvqJM3fUrjw() : void
    {
        $this->mhWKUa6jAoa(EUkqoDwU9Zcvh::UPLOADING);
    }
    public function mmU0aSbrCKc() : void
    {
        $this->mhWKUa6jAoa(EUkqoDwU9Zcvh::UPLOADED);
    }
    public function mxra39H1jik() : void
    {
        $this->mhWKUa6jAoa(EUkqoDwU9Zcvh::PROCESSING);
    }
    public function mxI99kBkJYY() : void
    {
        $this->mhWKUa6jAoa(EUkqoDwU9Zcvh::FINISHED);
    }
    public function mh0nhrQjPJe() : void
    {
        $this->mhWKUa6jAoa(EUkqoDwU9Zcvh::ABORTED);
    }
    public function mS0UOkfpCpF() : array
    {
        return $this->M89HW;
    }
    public static function mRdLbWPGoE4(string $S6xyJ, $KtpJh, $Vi8xq, $vT463) : self
    {
        goto cUGEA;
        geVIR:
        return $nS1ZZ->mWWtXtQjBQC();
        goto wsqTv;
        ZM2ek:
        $nS1ZZ->mbdYqurHgjj($vT463, $KtpJh, $Vi8xq);
        goto w9SbY;
        cUGEA:
        $VZzWw = App::make(ANTOKA6KWzE7t::class)->mfzCIE4XvGW(BnU61laaiajX2::mqdgOOZkBS0($S6xyJ));
        goto aB2Dz;
        w9SbY:
        $nS1ZZ->m3B430t4QRf(EUkqoDwU9Zcvh::UPLOADING);
        goto geVIR;
        aB2Dz:
        $nS1ZZ = new self($VZzWw, $KtpJh);
        goto ZM2ek;
        wsqTv:
    }
    public static function mj70qEmfHlK($VZzWw, $TuWZt, $qg6AO, $vT463, $dpHsf = false) : self
    {
        goto hIKQc;
        Fgpyj:
        $nS1ZZ->m3B430t4QRf(EUkqoDwU9Zcvh::UPLOADING);
        goto zZwVl;
        zZwVl:
        return $nS1ZZ;
        goto UK9zm;
        hIKQc:
        $nS1ZZ = new self($VZzWw, $TuWZt);
        goto oW0ll;
        oW0ll:
        $nS1ZZ->mbdYqurHgjj($vT463, $TuWZt, $qg6AO, $dpHsf);
        goto Fgpyj;
        UK9zm:
    }
}
