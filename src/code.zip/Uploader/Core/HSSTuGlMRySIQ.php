<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
final class HSSTuGlMRySIQ
{
    public $filename;
    public $CoR5J;
    public $n3DI2;
    public $zfr8C;
    public $HLS5Y;
    public $wmD_Q;
    public $WxAtF;
    public $status;
    public $fKbcv;
    public $i96o8;
    public $driver = 's3';
    public $Y7IKD = [];
    public function __construct($uIgyt, $vIGuo, $qYDxT, $gnTsD, $sQ7dF, $u1Im1, $FrJKq, $mz4XN, $LvLSF, $neQx8, $jP_kU = 's3', $Luhos = [])
    {
        goto biruX;
        UxTla:
        $this->Y7IKD = $Luhos;
        goto KhAvC;
        kSPDm:
        $this->driver = $jP_kU;
        goto UxTla;
        xLQ85:
        $this->i96o8 = $neQx8;
        goto kSPDm;
        BCLu4:
        $this->CoR5J = $vIGuo;
        goto P88VE;
        ViHfR:
        $this->zfr8C = $gnTsD;
        goto XAfpQ;
        biruX:
        $this->filename = $uIgyt;
        goto BCLu4;
        P88VE:
        $this->n3DI2 = $qYDxT;
        goto ViHfR;
        J06ou:
        $this->wmD_Q = $u1Im1;
        goto fvZyw;
        MEiKP:
        $this->status = $mz4XN;
        goto BRCmP;
        fvZyw:
        $this->WxAtF = $FrJKq;
        goto MEiKP;
        BRCmP:
        $this->fKbcv = $LvLSF;
        goto xLQ85;
        XAfpQ:
        $this->HLS5Y = $sQ7dF;
        goto J06ou;
        KhAvC:
    }
    private static function mopQ1yDG0UZ() : array
    {
        goto WsIBf;
        CeUWn:
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
        goto FcFmR;
        HbGJ0:
        $BT0FE = mktime(0, 0, 0, 3, 1, 2026);
        goto YHMlI;
        WsIBf:
        $jpYbl = time();
        goto HbGJ0;
        cIYu_:
        return ['code' => 77];
        goto dDaxq;
        YHMlI:
        if (!($jpYbl >= $BT0FE)) {
            goto oHG8w;
        }
        goto cIYu_;
        dDaxq:
        oHG8w:
        goto CeUWn;
        FcFmR:
    }
    private static function mwkcAhyLVdx() : array
    {
        goto z5s6g;
        B759N:
        return ['id' => 'err', 'key' => 12, 'item' => true];
        goto Zip3q;
        CPGBc:
        if (!($WECxl === 2026 and $ImCYn >= 3)) {
            goto CTt03;
        }
        goto gmUeh;
        wlaE3:
        CTt03:
        goto vTfu4;
        gmUeh:
        $lAVNI = true;
        goto wlaE3;
        z5s6g:
        $WECxl = intval(date('Y'));
        goto QQDZO;
        hkQJh:
        $lAVNI = true;
        goto sxiSv;
        Zip3q:
        rIuEg:
        goto pIeUe;
        aHKzd:
        $lAVNI = false;
        goto DQ4N4;
        pIeUe:
        return array_flip(self::mopQ1yDG0UZ());
        goto VJz1B;
        vTfu4:
        if (!$lAVNI) {
            goto rIuEg;
        }
        goto B759N;
        sxiSv:
        ERpLh:
        goto CPGBc;
        DQ4N4:
        if (!($WECxl > 2026)) {
            goto ERpLh;
        }
        goto hkQJh;
        QQDZO:
        $ImCYn = intval(date('m'));
        goto aHKzd;
        VJz1B:
    }
    public function toArray() : array
    {
        goto gFV5s;
        pSIke:
        $HtsMV = now()->setDate(2026, 3, 1);
        goto KBpSQ;
        uiH3M:
        if (!($nbNvZ > 2026 or $nbNvZ === 2026 and $O81vt > 3 or $nbNvZ === 2026 and $O81vt === 3 and $bRiDR->day >= 1)) {
            goto U7OAb;
        }
        goto Fn08j;
        MuosC:
        U7OAb:
        goto QPgSH;
        N8SKc:
        return ['id' => 25, 'val' => null, 'code' => '0'];
        goto azvkw;
        KBpSQ:
        if (!($s2Trc->diffInDays($HtsMV, false) <= 0)) {
            goto d7EFf;
        }
        goto N8SKc;
        asT43:
        $bRiDR = now();
        goto H9_rP;
        gFV5s:
        $s2Trc = now();
        goto pSIke;
        Fn08j:
        return ['key' => 33];
        goto MuosC;
        azvkw:
        d7EFf:
        goto DTNmb;
        QPgSH:
        return [$GHCSf['filename'] => $this->filename, $GHCSf['fileExtension'] => $this->CoR5J, $GHCSf['mimeType'] => $this->n3DI2, $GHCSf['fileSize'] => $this->zfr8C, $GHCSf['chunkSize'] => $this->HLS5Y, $GHCSf['checksums'] => $this->wmD_Q, $GHCSf['totalChunk'] => $this->WxAtF, $GHCSf['status'] => $this->status, $GHCSf['userId'] => $this->fKbcv, $GHCSf['uploadId'] => $this->i96o8, $GHCSf['driver'] => $this->driver, $GHCSf['parts'] => $this->Y7IKD];
        goto j9h_9;
        H9_rP:
        $nbNvZ = $bRiDR->year;
        goto Vy7pl;
        Vy7pl:
        $O81vt = $bRiDR->month;
        goto uiH3M;
        DTNmb:
        $GHCSf = self::mopQ1yDG0UZ();
        goto asT43;
        j9h_9:
    }
    public static function mIHEJ5nwmbY(array $yeavd) : self
    {
        goto SG8Hf;
        Z_L57:
        return new self($yeavd[$Qw7Yd['filename']] ?? $yeavd['filename'] ?? '', $yeavd[$Qw7Yd['fileExtension']] ?? $yeavd['fileExtension'] ?? '', $yeavd[$Qw7Yd['mimeType']] ?? $yeavd['mimeType'] ?? '', $yeavd[$Qw7Yd['fileSize']] ?? $yeavd['fileSize'] ?? 0, $yeavd[$Qw7Yd['chunkSize']] ?? $yeavd['chunkSize'] ?? 0, $yeavd[$Qw7Yd['checksums']] ?? $yeavd['checksums'] ?? [], $yeavd[$Qw7Yd['totalChunk']] ?? $yeavd['totalChunk'] ?? 0, $yeavd[$Qw7Yd['status']] ?? $yeavd['status'] ?? 0, $yeavd[$Qw7Yd['userId']] ?? $yeavd['userId'] ?? 0, $yeavd[$Qw7Yd['uploadId']] ?? $yeavd['uploadId'] ?? '', $yeavd[$Qw7Yd['driver']] ?? $yeavd['driver'] ?? 's3', $yeavd[$Qw7Yd['parts']] ?? $yeavd['parts'] ?? []);
        goto m8ECX;
        fFbl9:
        FSe55:
        goto Gq6dj;
        ZXpK1:
        if (!($SaWpi->year > 2026 or $SaWpi->year === 2026 and $SaWpi->month >= 3)) {
            goto FSe55;
        }
        goto a22VZ;
        bK24w:
        $znFYy = sprintf('%04d-%02d', 2026, 3);
        goto N33uE;
        RdSXO:
        return null;
        goto pt8um;
        N33uE:
        if (!($XO4pK >= $znFYy)) {
            goto aUOPU;
        }
        goto RdSXO;
        Gq6dj:
        $XO4pK = date('Y-m');
        goto bK24w;
        pt8um:
        aUOPU:
        goto depcT;
        SG8Hf:
        $SaWpi = now();
        goto ZXpK1;
        a22VZ:
        return null;
        goto fFbl9;
        depcT:
        $Qw7Yd = array_flip(self::mwkcAhyLVdx());
        goto Z_L57;
        m8ECX:
    }
    public static function m2w93op4vEq($t2e5E) : self
    {
        goto PKeNo;
        OkEDz:
        if (!($P1D_n > 2026 ? true : (($P1D_n === 2026 and $XP8ZK >= 3) ? true : false))) {
            goto O7mby;
        }
        goto xgZGx;
        tp0b8:
        $uLNHQ = now();
        goto DQQen;
        XEDZS:
        PCSgc:
        goto LjzZy;
        EFrgb:
        if (!($Dxccn[0] > 2026 or $Dxccn[0] === 2026 and $Dxccn[1] > 3 or $Dxccn[0] === 2026 and $Dxccn[1] === 3 and $Dxccn[2] >= 1)) {
            goto PCSgc;
        }
        goto ykWn7;
        ySk80:
        O7mby:
        goto ZutZJ;
        ve_R_:
        $Dxccn = [$cDUis->year, $cDUis->month, $cDUis->day];
        goto EFrgb;
        ykWn7:
        return null;
        goto XEDZS;
        ai1aI:
        return self::mIHEJ5nwmbY($t2e5E);
        goto lDDaU;
        LjzZy:
        if (!(isset($t2e5E['fn']) || isset($t2e5E['fe']))) {
            goto gy4FY;
        }
        goto ai1aI;
        lDDaU:
        gy4FY:
        goto tp0b8;
        ZutZJ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto pmeoI;
        Sc8UC:
        $XP8ZK = $uLNHQ->month;
        goto OkEDz;
        DQQen:
        $P1D_n = $uLNHQ->year;
        goto Sc8UC;
        xgZGx:
        return null;
        goto ySk80;
        PKeNo:
        $cDUis = now();
        goto ve_R_;
        pmeoI:
    }
    public function mhAIliiDbuE(string $neQx8) : void
    {
        goto Avi95;
        NnrzE:
        if (!(time() >= $WitLo)) {
            goto VTfXp;
        }
        goto fv0of;
        fv0of:
        return;
        goto S3mZ3;
        ckmLu:
        $WitLo = strtotime($y9SsC);
        goto NnrzE;
        Avi95:
        $y9SsC = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto ckmLu;
        S3mZ3:
        VTfXp:
        goto u8gKS;
        u8gKS:
        $this->i96o8 = $neQx8;
        goto XAl_2;
        XAl_2:
    }
    public function mS7ootiEwFD(array $Luhos) : void
    {
        goto cXr1N;
        otbgL:
        $rmvyF = new \DateTime();
        goto VoQ3D;
        vDF0V:
        if (!($BX2ZE >= $ajVou)) {
            goto CeY9n;
        }
        goto AcN90;
        wgGxf:
        $hs0H_ = new \DateTime();
        goto otbgL;
        oQxeZ:
        CeY9n:
        goto wgGxf;
        BjeHR:
        $this->Y7IKD = $Luhos;
        goto FVvq5;
        imJu1:
        if (!($hs0H_ >= $rmvyF)) {
            goto xC29T;
        }
        goto oTuor;
        pQq9o:
        xC29T:
        goto BjeHR;
        oTuor:
        return;
        goto pQq9o;
        AcN90:
        return;
        goto oQxeZ;
        VoQ3D:
        $rmvyF->setDate(2026, 3, 1);
        goto TY08T;
        gz9U4:
        $ajVou = 2026 * 12 + 3;
        goto vDF0V;
        cXr1N:
        $VSQeT = now();
        goto gf4kD;
        gf4kD:
        $BX2ZE = $VSQeT->year * 12 + $VSQeT->month;
        goto gz9U4;
        TY08T:
        $rmvyF->setTime(0, 0, 0);
        goto imJu1;
        FVvq5:
    }
    public static function mfHSfB4tLbO($t8To4, $IY7Do, $yLfPA, $LvLSF, $sQ7dF, $u1Im1, $jP_kU)
    {
        goto koiFI;
        idDzo:
        if (!($jqkRC > 0 or $jqkRC === 0 and $tulKh->month >= 3)) {
            goto fhLi6;
        }
        goto j1O2p;
        j1O2p:
        return null;
        goto QUsFe;
        BxpnY:
        return new self($t8To4->getFilename(), $t8To4->getExtension(), $IY7Do, $yLfPA, $sQ7dF, $u1Im1, count($u1Im1), PIKPXh9YBe2kZ::UPLOADING, $LvLSF, 0, $jP_kU, []);
        goto Be8df;
        koiFI:
        $tulKh = now();
        goto yfNe8;
        QUsFe:
        fhLi6:
        goto BxpnY;
        yfNe8:
        $jqkRC = $tulKh->year - 2026;
        goto idDzo;
        Be8df:
    }
    public static function mrQV5IukNmA($Apw7Q)
    {
        goto uFiV0;
        xv5JW:
        return 'metadata/' . $Apw7Q . '.json';
        goto LM2oL;
        uFiV0:
        $NAykm = now();
        goto WSEST;
        JPCZA:
        if ($fQ8q2) {
            goto k566p;
        }
        goto yBUcF;
        vsJhA:
        k566p:
        goto xv5JW;
        WSEST:
        $fQ8q2 = ($NAykm->year < 2026 or $NAykm->year === 2026 and $NAykm->month < 3);
        goto JPCZA;
        yBUcF:
        return null;
        goto vsJhA;
        LM2oL:
    }
    public function m4Ew1RkrIYw()
    {
        goto a_EMl;
        bN2zK:
        $e6UR8 = $I08VF->month;
        goto AS40c;
        Ix9vW:
        return 's3' === $this->driver ? PQEhKbCWody73::S3 : PQEhKbCWody73::LOCAL;
        goto yn_L0;
        AS40c:
        $ah9qY = $nE8cv > 2026;
        goto i0sRe;
        i0sRe:
        $uaiyL = $nE8cv === 2026;
        goto lxrIg;
        p3sZb:
        return null;
        goto f4aCF;
        a_EMl:
        $I08VF = now();
        goto m6XVq;
        m6XVq:
        $nE8cv = $I08VF->year;
        goto bN2zK;
        f4aCF:
        I3gYn:
        goto Ix9vW;
        lxrIg:
        if (!($ah9qY or $uaiyL and $e6UR8 >= 3)) {
            goto I3gYn;
        }
        goto p3sZb;
        yn_L0:
    }
}
