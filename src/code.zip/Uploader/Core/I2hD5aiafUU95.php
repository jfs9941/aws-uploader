<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
final class I2hD5aiafUU95
{
    public $filename;
    public $O8lFE;
    public $W97mt;
    public $aU_jI;
    public $na8lq;
    public $HB9Am;
    public $NLwkr;
    public $status;
    public $ztfuk;
    public $rAZCi;
    public $driver = 's3';
    public $kSIc5 = [];
    public function __construct($KDFW7, $sBtqB, $zbzX3, $hjXoB, $GzTiT, $hiri4, $yYiTU, $MJJMi, $mGabZ, $PcG1p, $UPm3o = 's3', $sYIWJ = [])
    {
        goto H9NfX;
        FMksU:
        $this->na8lq = $GzTiT;
        goto JazA6;
        H9NfX:
        $this->filename = $KDFW7;
        goto us8af;
        HRrA2:
        $this->rAZCi = $PcG1p;
        goto YtwRg;
        JazA6:
        $this->HB9Am = $hiri4;
        goto r1w3O;
        r1w3O:
        $this->NLwkr = $yYiTU;
        goto REVdR;
        hkKz_:
        $this->aU_jI = $hjXoB;
        goto FMksU;
        c_SQ1:
        $this->W97mt = $zbzX3;
        goto hkKz_;
        us8af:
        $this->O8lFE = $sBtqB;
        goto c_SQ1;
        REVdR:
        $this->status = $MJJMi;
        goto jVBq_;
        SyF8n:
        $this->kSIc5 = $sYIWJ;
        goto hLnN7;
        jVBq_:
        $this->ztfuk = $mGabZ;
        goto HRrA2;
        YtwRg:
        $this->driver = $UPm3o;
        goto SyF8n;
        hLnN7:
    }
    private static function mrVy1Iut9Jh() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mmuHdLmfq62() : array
    {
        return array_flip(self::mrVy1Iut9Jh());
    }
    public function toArray() : array
    {
        $IVb0E = self::mrVy1Iut9Jh();
        return [$IVb0E['filename'] => $this->filename, $IVb0E['fileExtension'] => $this->O8lFE, $IVb0E['mimeType'] => $this->W97mt, $IVb0E['fileSize'] => $this->aU_jI, $IVb0E['chunkSize'] => $this->na8lq, $IVb0E['checksums'] => $this->HB9Am, $IVb0E['totalChunk'] => $this->NLwkr, $IVb0E['status'] => $this->status, $IVb0E['userId'] => $this->ztfuk, $IVb0E['uploadId'] => $this->rAZCi, $IVb0E['driver'] => $this->driver, $IVb0E['parts'] => $this->kSIc5];
    }
    public static function mEI0CnGvzdj(array $XeMQ7) : self
    {
        $xLn30 = array_flip(self::mmuHdLmfq62());
        return new self($XeMQ7[$xLn30['filename']] ?? $XeMQ7['filename'] ?? '', $XeMQ7[$xLn30['fileExtension']] ?? $XeMQ7['fileExtension'] ?? '', $XeMQ7[$xLn30['mimeType']] ?? $XeMQ7['mimeType'] ?? '', $XeMQ7[$xLn30['fileSize']] ?? $XeMQ7['fileSize'] ?? 0, $XeMQ7[$xLn30['chunkSize']] ?? $XeMQ7['chunkSize'] ?? 0, $XeMQ7[$xLn30['checksums']] ?? $XeMQ7['checksums'] ?? [], $XeMQ7[$xLn30['totalChunk']] ?? $XeMQ7['totalChunk'] ?? 0, $XeMQ7[$xLn30['status']] ?? $XeMQ7['status'] ?? 0, $XeMQ7[$xLn30['userId']] ?? $XeMQ7['userId'] ?? 0, $XeMQ7[$xLn30['uploadId']] ?? $XeMQ7['uploadId'] ?? '', $XeMQ7[$xLn30['driver']] ?? $XeMQ7['driver'] ?? 's3', $XeMQ7[$xLn30['parts']] ?? $XeMQ7['parts'] ?? []);
    }
    public static function mr3CqhCgEdl($eYucb) : self
    {
        goto MugFi;
        GIx02:
        qCKDD:
        goto fxhee;
        MugFi:
        if (!(isset($eYucb['fn']) || isset($eYucb['fe']))) {
            goto qCKDD;
        }
        goto yE004;
        fxhee:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto TxhK6;
        yE004:
        return self::mEI0CnGvzdj($eYucb);
        goto GIx02;
        TxhK6:
    }
    public function mZjQHk2Fi8R(string $PcG1p) : void
    {
        $this->rAZCi = $PcG1p;
    }
    public function mwJqYjbl9h0(array $sYIWJ) : void
    {
        $this->kSIc5 = $sYIWJ;
    }
    public static function m6MBw2Z1HBW($mz56v, $WFq0C, $Rrg0m, $mGabZ, $GzTiT, $hiri4, $UPm3o)
    {
        return new self($mz56v->getFilename(), $mz56v->getExtension(), $WFq0C, $Rrg0m, $GzTiT, $hiri4, count($hiri4), IfP50GBBbx63a::UPLOADING, $mGabZ, 0, $UPm3o, []);
    }
    public static function midPEuserYW($q8q1b)
    {
        return 'metadata/' . $q8q1b . '.json';
    }
    public function mcd4WDHRYJL()
    {
        return 's3' === $this->driver ? Y9OZ7qWyGdhw2::S3 : Y9OZ7qWyGdhw2::LOCAL;
    }
}
