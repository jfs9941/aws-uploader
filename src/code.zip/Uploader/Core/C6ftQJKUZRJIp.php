<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Contracts\VjEI9Nu3TyWfD;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Traits\CD8fs6jM2d7v1;
use Jfs\Uploader\Core\Traits\RWUAoQ6vUS0uH;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Service\IeMg7A21r884m;
class C6ftQJKUZRJIp extends EpIpyfdFnoTz6 implements WZhCwGsxQbxug
{
    use CD8fs6jM2d7v1;
    use RWUAoQ6vUS0uH;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $chz0R, string $T_yZW) : self
    {
        goto m10tB;
        WUHev:
        $dmeuh->myjAI8i1TR7(Fsm7WCrUwVWh9::UPLOADING);
        goto YUnjf;
        m10tB:
        $dmeuh = new self(['id' => $chz0R, 'type' => $T_yZW, 'status' => Fsm7WCrUwVWh9::UPLOADING]);
        goto WUHev;
        YUnjf:
        return $dmeuh;
        goto EnKDf;
        EnKDf:
    }
    public function getView() : array
    {
        $YTknp = app(VjEI9Nu3TyWfD::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $YTknp->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $YTknp->resolveThumbnail($this)];
    }
    public static function mQO65yCGuDw(EpIpyfdFnoTz6 $HZKvy) : C6ftQJKUZRJIp
    {
        goto VnBnQ;
        qfIvK:
        return (new C6ftQJKUZRJIp())->fill($HZKvy->getAttributes());
        goto B2_dm;
        VnBnQ:
        if (!$HZKvy instanceof C6ftQJKUZRJIp) {
            goto grTKM;
        }
        goto Vc_r6;
        TtNCj:
        grTKM:
        goto qfIvK;
        Vc_r6:
        return $HZKvy;
        goto TtNCj;
        B2_dm:
    }
}
