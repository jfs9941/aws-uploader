<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Illuminate\Database\Eloquent\Model;
abstract  class UfttW7MErNAIK extends Model implements Guvqjk2EvHsmF
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mISFTPpP69d() : bool
    {
        goto aap4Q;
        rnREu:
        return !$this->mynpXu0Z63r();
        goto pSTWL;
        b2MJT:
        to26W:
        goto rnREu;
        aap4Q:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto to26W;
        }
        goto yYdKT;
        yYdKT:
        return true;
        goto b2MJT;
        pSTWL:
    }
    protected function mynpXu0Z63r() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
