<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

interface WRjhEXpWo4ZJt
{
    public function getFilename() : string;
    public function getExtension() : string;
    public function getType() : string;
    public function getLocation() : string;
    public function initLocation(string $AR_ix);
    public static function createFromScratch(string $b990v, string $JVLc8);
    public function getView();
}
