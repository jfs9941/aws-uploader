<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
abstract  class HJJu0xs0QACaQ extends Model implements Y5tmWZcWsdzIB
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mqioBzibeOU() : bool
    {
        goto h7zRK;
        klj_b:
        return true;
        goto GXGOh;
        GXGOh:
        hRWqt:
        goto vLe0y;
        vLe0y:
        return !$this->mtn2Z5Aus5A();
        goto fU6v9;
        h7zRK:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto hRWqt;
        }
        goto klj_b;
        fU6v9:
    }
    protected function mtn2Z5Aus5A() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
