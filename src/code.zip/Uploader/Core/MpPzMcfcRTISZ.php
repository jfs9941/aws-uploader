<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Contracts\TdTpyTw87RXgQ;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\Traits\G7E8tu8BtZX7c;
use Jfs\Uploader\Core\Traits\WbbiNrJy3XNAD;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Service\JujbASFciElku;
class MpPzMcfcRTISZ extends OavRsjNQCayKr implements QguGxHrrpjTia
{
    use G7E8tu8BtZX7c;
    use WbbiNrJy3XNAD;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $bl6S5, string $TlRjW) : self
    {
        goto M8STc;
        a7Ec0:
        return $qKtXa;
        goto EnJEG;
        M8STc:
        $qKtXa = new self(['id' => $bl6S5, 'type' => $TlRjW, 'status' => IOEDyer18cpSA::UPLOADING]);
        goto joJg4;
        joJg4:
        $qKtXa->mC8nuYteIk4(IOEDyer18cpSA::UPLOADING);
        goto a7Ec0;
        EnJEG:
    }
    public function getView() : array
    {
        $XXXuf = app(TdTpyTw87RXgQ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $XXXuf->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $XXXuf->resolveThumbnail($this)];
    }
    public static function msJ0kSV5JW8(OavRsjNQCayKr $jGsBp) : MpPzMcfcRTISZ
    {
        goto uQl2y;
        wgMYB:
        xe323:
        goto zRcWV;
        uQl2y:
        if (!$jGsBp instanceof MpPzMcfcRTISZ) {
            goto xe323;
        }
        goto mKcgF;
        zRcWV:
        return (new MpPzMcfcRTISZ())->fill($jGsBp->getAttributes());
        goto Lj00F;
        mKcgF:
        return $jGsBp;
        goto wgMYB;
        Lj00F:
    }
}
