<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

interface KO2pC9qLVd4GD
{
    public function getFilename() : string;
    public function getExtension() : string;
    public function getType() : string;
    public function getLocation() : string;
    public function initLocation(string $iqFVf);
    public static function createFromScratch(string $YoQzC, string $HuqsN);
    public function getView();
}
