<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Core\Traits\SMO7C4a5P3uK2;
use Jfs\Uploader\Core\Traits\D1PKXaknZAaj4;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Service\TEgBbF7EqiUEB;
class YuLJNLBqHeeZR extends ZujQPL2bQTbeI implements Y0vs5qDfvPebz
{
    use SMO7C4a5P3uK2;
    use D1PKXaknZAaj4;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $o6Bjc, string $sJ7MD) : self
    {
        goto JKvCl;
        JdBup:
        return $VjY6O;
        goto wl_Ae;
        JKvCl:
        $VjY6O = new self(['id' => $o6Bjc, 'type' => $sJ7MD, 'status' => SsxWbUYXracun::UPLOADING]);
        goto eawDk;
        eawDk:
        $VjY6O->msLvxB5AWdO(SsxWbUYXracun::UPLOADING);
        goto JdBup;
        wl_Ae:
    }
    public function getView() : array
    {
        $VXB2z = app(ECHrJsgxCR7OQ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $VXB2z->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $VXB2z->resolveThumbnail($this)];
    }
    public static function mLHyNmOdf7w(ZujQPL2bQTbeI $Rcq7S) : YuLJNLBqHeeZR
    {
        goto pCEus;
        pCEus:
        if (!$Rcq7S instanceof YuLJNLBqHeeZR) {
            goto VwVaC;
        }
        goto VFSe9;
        VFSe9:
        return $Rcq7S;
        goto PhalZ;
        PhalZ:
        VwVaC:
        goto SQPCR;
        SQPCR:
        return (new YuLJNLBqHeeZR())->fill($Rcq7S->getAttributes());
        goto sOEsE;
        sOEsE:
    }
}
