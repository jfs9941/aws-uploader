<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Core\Observer\Of8oIVHk5MhTm;
use Jfs\Uploader\Core\Traits\KUN5Q48ryL1qd;
use Jfs\Uploader\Core\Traits\ZLQWnjuT7vx15;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Exception\LiA5BOk62pit2;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Jfs\Uploader\Exception\RpmK0FOGWoQmq;
use Jfs\Uploader\Service\XqoSwDelQBsQt;
final class GHjLMBSnTOoC3 implements EknRcwWhw5aDZ
{
    use KUN5Q48ryL1qd;
    use ZLQWnjuT7vx15;
    private $LQHPr;
    private function __construct($oYtbp, $mHTSY)
    {
        $this->woTf1 = $oYtbp;
        $this->H58rn = $mHTSY;
    }
    private function ma3WcNTPZdH(string $ahaqc, $mHTSY, $RUQUm, bool $zSR_B = false) : void
    {
        $this->m0Ku2PvnNzM(new Of8oIVHk5MhTm($this, $mHTSY, $RUQUm, $ahaqc, $zSR_B));
    }
    public function getFile()
    {
        return $this->woTf1;
    }
    public function m3rYcjoHjjg(array $CGZiy) : void
    {
        $this->LQHPr = $CGZiy;
    }
    public function m2SZC1hpix5() : void
    {
        $this->m3irf1LtLKT(OLX71luAn6XnP::UPLOADING);
    }
    public function m2j98qj1KZT() : void
    {
        $this->m3irf1LtLKT(OLX71luAn6XnP::UPLOADED);
    }
    public function mpJKmbIe9Ju() : void
    {
        $this->m3irf1LtLKT(OLX71luAn6XnP::PROCESSING);
    }
    public function miNo8ZpQs0F() : void
    {
        $this->m3irf1LtLKT(OLX71luAn6XnP::FINISHED);
    }
    public function mZfuX6Fne2U() : void
    {
        $this->m3irf1LtLKT(OLX71luAn6XnP::ABORTED);
    }
    public function mbZSkEgKpwb() : array
    {
        return $this->LQHPr;
    }
    public static function mOivyCa3f9G(string $Qu08p, $dAqdR, $yEBaZ, $ahaqc) : self
    {
        goto hciez;
        hciez:
        $oYtbp = App::make(XqoSwDelQBsQt::class)->mcIC6oHbrkQ(Hyi6BrRTUHRYH::me28TlZc9hY($Qu08p));
        goto EilSb;
        P3LIO:
        $JNpPo->ma3WcNTPZdH($ahaqc, $dAqdR, $yEBaZ);
        goto LYf8D;
        EilSb:
        $JNpPo = new self($oYtbp, $dAqdR);
        goto P3LIO;
        LYf8D:
        $JNpPo->mfeKnFzyMNC(OLX71luAn6XnP::UPLOADING);
        goto FlhZs;
        FlhZs:
        return $JNpPo->m7cgC8D9UxI();
        goto AkznJ;
        AkznJ:
    }
    public static function m3JDOCfNVAu($oYtbp, $mHTSY, $RUQUm, $ahaqc, $zSR_B = false) : self
    {
        goto yLQUD;
        bvKaj:
        $JNpPo->ma3WcNTPZdH($ahaqc, $mHTSY, $RUQUm, $zSR_B);
        goto vf5h3;
        vf5h3:
        $JNpPo->mfeKnFzyMNC(OLX71luAn6XnP::UPLOADING);
        goto Ow2YD;
        yLQUD:
        $JNpPo = new self($oYtbp, $mHTSY);
        goto bvKaj;
        Ow2YD:
        return $JNpPo;
        goto UkmNu;
        UkmNu:
    }
}
