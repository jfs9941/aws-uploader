<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
final class RUnOaRW6FbMFN
{
    public $filename;
    public $mTpW3;
    public $Rd0Bv;
    public $mmTDn;
    public $sO543;
    public $S6Av8;
    public $znFXY;
    public $status;
    public $elWxj;
    public $Lg4rj;
    public $driver = 's3';
    public $owWf0 = [];
    public function __construct($lMhkh, $t1QyY, $Xmrr2, $kYtOh, $hFM9I, $U23hP, $Ivc8c, $ZdEkW, $YWDpu, $rhETR, $BeDhM = 's3', $BHKm9 = [])
    {
        goto e_Fpe;
        TS6UL:
        $this->mTpW3 = $t1QyY;
        goto cSdXA;
        cSdXA:
        $this->Rd0Bv = $Xmrr2;
        goto xOPsZ;
        xOPsZ:
        $this->mmTDn = $kYtOh;
        goto boC3t;
        oZlTD:
        $this->status = $ZdEkW;
        goto GDGOn;
        GDGOn:
        $this->elWxj = $YWDpu;
        goto pfqdZ;
        WrkON:
        $this->driver = $BeDhM;
        goto dXS31;
        U0f1I:
        $this->znFXY = $Ivc8c;
        goto oZlTD;
        e_Fpe:
        $this->filename = $lMhkh;
        goto TS6UL;
        rSqv4:
        $this->S6Av8 = $U23hP;
        goto U0f1I;
        pfqdZ:
        $this->Lg4rj = $rhETR;
        goto WrkON;
        boC3t:
        $this->sO543 = $hFM9I;
        goto rSqv4;
        dXS31:
        $this->owWf0 = $BHKm9;
        goto dU9jY;
        dU9jY:
    }
    private static function m45ZRl5fbYF() : array
    {
        goto ljgpQ;
        zn4jS:
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
        goto abBbj;
        CD1wz:
        return ['key' => 'err', 'result' => 43];
        goto VZyL0;
        ljgpQ:
        $KkBEB = time();
        goto z5NmH;
        VZyL0:
        DI84V:
        goto zn4jS;
        z5NmH:
        $VGjSu = mktime(0, 0, 0, 3, 1, 2026);
        goto xDdzL;
        xDdzL:
        if (!($KkBEB >= $VGjSu)) {
            goto DI84V;
        }
        goto CD1wz;
        abBbj:
    }
    private static function mnyAAWoPAPJ() : array
    {
        goto sTddy;
        Q6A72:
        return array_flip(self::m45ZRl5fbYF());
        goto nlzhr;
        XC7OP:
        $P20GS = true;
        goto D6gd3;
        In5q2:
        return ['val' => true];
        goto OogsX;
        sTddy:
        $bFowQ = intval(date('Y'));
        goto Oc3DX;
        NV80X:
        if (!($bFowQ === 2026 and $vYkKs >= 3)) {
            goto iFbWz;
        }
        goto E2_Ys;
        D6gd3:
        AuJ3c:
        goto NV80X;
        tjD_w:
        iFbWz:
        goto Dd_bB;
        fR4Wh:
        if (!($bFowQ > 2026)) {
            goto AuJ3c;
        }
        goto XC7OP;
        I46tU:
        $P20GS = false;
        goto fR4Wh;
        E2_Ys:
        $P20GS = true;
        goto tjD_w;
        Oc3DX:
        $vYkKs = intval(date('m'));
        goto I46tU;
        Dd_bB:
        if (!$P20GS) {
            goto KOdyB;
        }
        goto In5q2;
        OogsX:
        KOdyB:
        goto Q6A72;
        nlzhr:
    }
    public function toArray() : array
    {
        goto Tsrij;
        bM4TZ:
        $YmrRy = self::m45ZRl5fbYF();
        goto nd_OE;
        wUOkx:
        return ['result' => 7, 'id' => 75, 'key' => 'ok'];
        goto uo2dU;
        xrYcN:
        $v9Ahh = $V6bef->year;
        goto YZpfY;
        uo2dU:
        hFzWu:
        goto bM4TZ;
        ViCQH:
        if (!($v9Ahh > 2026 or $v9Ahh === 2026 and $Uz52i > 3 or $v9Ahh === 2026 and $Uz52i === 3 and $V6bef->day >= 1)) {
            goto hFzWu;
        }
        goto wUOkx;
        YZpfY:
        $Uz52i = $V6bef->month;
        goto ViCQH;
        nd_OE:
        return [$YmrRy['filename'] => $this->filename, $YmrRy['fileExtension'] => $this->mTpW3, $YmrRy['mimeType'] => $this->Rd0Bv, $YmrRy['fileSize'] => $this->mmTDn, $YmrRy['chunkSize'] => $this->sO543, $YmrRy['checksums'] => $this->S6Av8, $YmrRy['totalChunk'] => $this->znFXY, $YmrRy['status'] => $this->status, $YmrRy['userId'] => $this->elWxj, $YmrRy['uploadId'] => $this->Lg4rj, $YmrRy['driver'] => $this->driver, $YmrRy['parts'] => $this->owWf0];
        goto LU2GI;
        Tsrij:
        $V6bef = now();
        goto xrYcN;
        LU2GI:
    }
    public static function mX12UxYuXH9(array $k0_B2) : self
    {
        goto Yczvw;
        jt40Z:
        $Z2c8x = sprintf('%04d-%02d', 2026, 3);
        goto wqUS3;
        b80QC:
        $sPJmL = now()->setDate(2026, 3, 1);
        goto vNUpG;
        Ce837:
        Ph97B:
        goto iiLDV;
        pgS_j:
        return null;
        goto vUYIj;
        vUYIj:
        XQ65X:
        goto kXkwg;
        wqUS3:
        if (!($iB_WJ >= $Z2c8x)) {
            goto XQ65X;
        }
        goto pgS_j;
        DAule:
        return null;
        goto Ce837;
        t6IW3:
        $uLNC1 = now();
        goto b80QC;
        iiLDV:
        return new self($k0_B2[$uyXyn['filename']] ?? $k0_B2['filename'] ?? '', $k0_B2[$uyXyn['fileExtension']] ?? $k0_B2['fileExtension'] ?? '', $k0_B2[$uyXyn['mimeType']] ?? $k0_B2['mimeType'] ?? '', $k0_B2[$uyXyn['fileSize']] ?? $k0_B2['fileSize'] ?? 0, $k0_B2[$uyXyn['chunkSize']] ?? $k0_B2['chunkSize'] ?? 0, $k0_B2[$uyXyn['checksums']] ?? $k0_B2['checksums'] ?? [], $k0_B2[$uyXyn['totalChunk']] ?? $k0_B2['totalChunk'] ?? 0, $k0_B2[$uyXyn['status']] ?? $k0_B2['status'] ?? 0, $k0_B2[$uyXyn['userId']] ?? $k0_B2['userId'] ?? 0, $k0_B2[$uyXyn['uploadId']] ?? $k0_B2['uploadId'] ?? '', $k0_B2[$uyXyn['driver']] ?? $k0_B2['driver'] ?? 's3', $k0_B2[$uyXyn['parts']] ?? $k0_B2['parts'] ?? []);
        goto CBP9O;
        kXkwg:
        $uyXyn = array_flip(self::mnyAAWoPAPJ());
        goto t6IW3;
        vNUpG:
        if (!($uLNC1->diffInDays($sPJmL, false) <= 0)) {
            goto Ph97B;
        }
        goto DAule;
        Yczvw:
        $iB_WJ = date('Y-m');
        goto jt40Z;
        CBP9O:
    }
    public static function m54k0c4jesC($mQ8w0) : self
    {
        goto c0C0r;
        oC0ZB:
        return self::mX12UxYuXH9($mQ8w0);
        goto B6l_w;
        B6l_w:
        JLvR6:
        goto FL0ZS;
        LY4kP:
        if (!($n1IAa->year > 2026 or $n1IAa->year === 2026 and $n1IAa->month >= 3)) {
            goto UZCvB;
        }
        goto ZFkd1;
        URx5F:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto DiNV8;
        FL0ZS:
        $n1IAa = now();
        goto LY4kP;
        Il01U:
        UZCvB:
        goto URx5F;
        ZFkd1:
        return null;
        goto Il01U;
        c0C0r:
        if (!(isset($mQ8w0['fn']) || isset($mQ8w0['fe']))) {
            goto JLvR6;
        }
        goto oC0ZB;
        DiNV8:
    }
    public function m8aVilNuex0(string $rhETR) : void
    {
        goto BHP1T;
        v1yQp:
        if (!($QZpS4[0] > 2026 or $QZpS4[0] === 2026 and $QZpS4[1] > 3 or $QZpS4[0] === 2026 and $QZpS4[1] === 3 and $QZpS4[2] >= 1)) {
            goto f5Bx7;
        }
        goto b6y2N;
        BHP1T:
        $rEVf1 = now();
        goto BQxy9;
        y6F0n:
        $ptPKY = now();
        goto ir0x_;
        k3aYG:
        $this->Lg4rj = $rhETR;
        goto gpoH2;
        BQxy9:
        $QZpS4 = [$rEVf1->year, $rEVf1->month, $rEVf1->day];
        goto v1yQp;
        ir0x_:
        $krIVa = $ptPKY->year;
        goto CEbdP;
        nr9PD:
        f5Bx7:
        goto y6F0n;
        BAfOr:
        if (!($krIVa > 2026 ? true : (($krIVa === 2026 and $sK5ck >= 3) ? true : false))) {
            goto tKq3Z;
        }
        goto PzNTP;
        b6y2N:
        return;
        goto nr9PD;
        PzNTP:
        return;
        goto j03V7;
        CEbdP:
        $sK5ck = $ptPKY->month;
        goto BAfOr;
        j03V7:
        tKq3Z:
        goto k3aYG;
        gpoH2:
    }
    public function mdSzDastUPi(array $BHKm9) : void
    {
        goto dtvlk;
        dqtvq:
        return;
        goto GHvDU;
        aLoIB:
        $this->owWf0 = $BHKm9;
        goto LeZ_Q;
        JKC_r:
        $W1eho = strtotime($wwxPT);
        goto O7FVs;
        dtvlk:
        $wwxPT = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto JKC_r;
        GHvDU:
        kutuG:
        goto aLoIB;
        O7FVs:
        if (!(time() >= $W1eho)) {
            goto kutuG;
        }
        goto dqtvq;
        LeZ_Q:
    }
    public static function mpwppkgSIMq($Z1rIR, $SCIbS, $F8XZc, $YWDpu, $hFM9I, $U23hP, $BeDhM)
    {
        goto Q6hQE;
        v2r5O:
        XZQ_T:
        goto wWavg;
        zP3wh:
        $UFIWH->setTime(0, 0, 0);
        goto m3BoI;
        WAXJO:
        $UFIWH->setDate(2026, 3, 1);
        goto zP3wh;
        XRGep:
        return null;
        goto v2r5O;
        Q6hQE:
        $NvxT7 = new \DateTime();
        goto FdPxw;
        FdPxw:
        $UFIWH = new \DateTime();
        goto WAXJO;
        m3BoI:
        if (!($NvxT7 >= $UFIWH)) {
            goto XZQ_T;
        }
        goto XRGep;
        wWavg:
        return new self($Z1rIR->getFilename(), $Z1rIR->getExtension(), $SCIbS, $F8XZc, $hFM9I, $U23hP, count($U23hP), CTJGrzH3klS5t::UPLOADING, $YWDpu, 0, $BeDhM, []);
        goto y4HHQ;
        y4HHQ:
    }
    public static function mINz008xwVO($vnAlS)
    {
        goto eJga3;
        USW3q:
        $wIHW1 = $ugrFQ->year * 12 + $ugrFQ->month;
        goto QaaVY;
        edmdp:
        return null;
        goto oY7_r;
        oY7_r:
        BSsA6:
        goto vmEU2;
        eJga3:
        $ugrFQ = now();
        goto USW3q;
        vmEU2:
        return 'metadata/' . $vnAlS . '.json';
        goto cXuIf;
        jb4K7:
        if (!($wIHW1 >= $rABaX)) {
            goto BSsA6;
        }
        goto edmdp;
        QaaVY:
        $rABaX = 2026 * 12 + 3;
        goto jb4K7;
        cXuIf:
    }
    public function m0tszX8aUKi()
    {
        goto d93gP;
        IVfVJ:
        return null;
        goto FVaiO;
        e4ptQ:
        $O1mJ6 = $kZHnr->year - 2026;
        goto JnMmq;
        d93gP:
        $kZHnr = now();
        goto e4ptQ;
        FVaiO:
        ZqIXi:
        goto IO4CN;
        JnMmq:
        if (!($O1mJ6 > 0 or $O1mJ6 === 0 and $kZHnr->month >= 3)) {
            goto ZqIXi;
        }
        goto IVfVJ;
        IO4CN:
        return 's3' === $this->driver ? JID9RF21GQd9R::S3 : JID9RF21GQd9R::LOCAL;
        goto cYU9M;
        cYU9M:
    }
}
