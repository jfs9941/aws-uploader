<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Core\Observer\Oy9IrA1ruFcnF;
use Jfs\Uploader\Core\Traits\UPFKyMg91hBqR;
use Jfs\Uploader\Core\Traits\DbEmnet2FoHTm;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Exception\B2PcuiERDfNqQ;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Jfs\Uploader\Exception\QdafZI2suLm2R;
use Jfs\Uploader\Service\UKpsYHdguB77R;
final class T9ZXYI5O5GjGl implements PxTzgsobiHpcX
{
    use UPFKyMg91hBqR;
    use DbEmnet2FoHTm;
    private $ebzyo;
    private function __construct($nKKn0, $h5ffz)
    {
        $this->AO_te = $nKKn0;
        $this->LuJWw = $h5ffz;
    }
    private function mkkJBGwm4ZQ(string $rhVEO, $h5ffz, $uANLN, bool $fpbbH = false) : void
    {
        $this->mW7YosDFYf5(new Oy9IrA1ruFcnF($this, $h5ffz, $uANLN, $rhVEO, $fpbbH));
    }
    public function getFile()
    {
        return $this->AO_te;
    }
    public function m47Oa9dYR1p(array $S1ep9) : void
    {
        $this->ebzyo = $S1ep9;
    }
    public function m5XpvJSSw8B() : void
    {
        $this->mSAdKjgXIhj(O8RzIjGmSN6fG::UPLOADING);
    }
    public function mal1fCPSgtX() : void
    {
        $this->mSAdKjgXIhj(O8RzIjGmSN6fG::UPLOADED);
    }
    public function mxyeOEjPoFu() : void
    {
        $this->mSAdKjgXIhj(O8RzIjGmSN6fG::PROCESSING);
    }
    public function mcpT1XONZF5() : void
    {
        $this->mSAdKjgXIhj(O8RzIjGmSN6fG::FINISHED);
    }
    public function moRGnOr8s5k() : void
    {
        $this->mSAdKjgXIhj(O8RzIjGmSN6fG::ABORTED);
    }
    public function m1HynR3TcF6() : array
    {
        return $this->ebzyo;
    }
    public static function mqLELyC8VTa(string $PV4mw, $Kln4t, $PQlIa, $rhVEO) : self
    {
        goto Q29Go;
        Hgezv:
        $kPAXd->mkkJBGwm4ZQ($rhVEO, $Kln4t, $PQlIa);
        goto ffqaZ;
        IgFSm:
        return $kPAXd->mXcwNN708YR();
        goto ohZZP;
        Q29Go:
        $nKKn0 = App::make(UKpsYHdguB77R::class)->mDTj3kUFDAD(ASReQHmrabNfg::mDgt4KXkAWr($PV4mw));
        goto mMSgu;
        ffqaZ:
        $kPAXd->mt6YUzzNxIA(O8RzIjGmSN6fG::UPLOADING);
        goto IgFSm;
        mMSgu:
        $kPAXd = new self($nKKn0, $Kln4t);
        goto Hgezv;
        ohZZP:
    }
    public static function mtmgv9I6Ki6($nKKn0, $h5ffz, $uANLN, $rhVEO, $fpbbH = false) : self
    {
        goto bR267;
        j1vKB:
        $kPAXd->mt6YUzzNxIA(O8RzIjGmSN6fG::UPLOADING);
        goto WJS6l;
        WJS6l:
        return $kPAXd;
        goto qmIGH;
        acNPC:
        $kPAXd->mkkJBGwm4ZQ($rhVEO, $h5ffz, $uANLN, $fpbbH);
        goto j1vKB;
        bR267:
        $kPAXd = new self($nKKn0, $h5ffz);
        goto acNPC;
        qmIGH:
    }
}
