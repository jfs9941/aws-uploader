<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Contracts\T1J9j7WqyAUZ6;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\Traits\Lch9OtTvfn4IQ;
use Jfs\Uploader\Core\Traits\WUkQAePShMtJo;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Service\PUY1a6FGGWTSN;
class D6FgZi8OHmjic extends GGOMDClEFMcsH implements WHyfIbzEzUFEe
{
    use Lch9OtTvfn4IQ;
    use WUkQAePShMtJo;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $eNeio, string $QGmwG) : self
    {
        goto A0BQT;
        A0BQT:
        $h169k = new self(['id' => $eNeio, 'type' => $QGmwG, 'status' => T93Mcsw1gA3an::UPLOADING]);
        goto VFTWM;
        VFTWM:
        $h169k->mNsps8Id3BK(T93Mcsw1gA3an::UPLOADING);
        goto zjwVj;
        zjwVj:
        return $h169k;
        goto haIzk;
        haIzk:
    }
    public function getView() : array
    {
        $M3DlU = app(T1J9j7WqyAUZ6::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $M3DlU->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $M3DlU->resolveThumbnail($this)];
    }
    public static function mJOovyh4SEi(GGOMDClEFMcsH $FX5Wq) : D6FgZi8OHmjic
    {
        goto RH3fX;
        RZT7v:
        VpxOX:
        goto sKPMW;
        RH3fX:
        if (!$FX5Wq instanceof D6FgZi8OHmjic) {
            goto VpxOX;
        }
        goto pz3Yy;
        pz3Yy:
        return $FX5Wq;
        goto RZT7v;
        sKPMW:
        return (new D6FgZi8OHmjic())->fill($FX5Wq->getAttributes());
        goto kaFyF;
        kaFyF:
    }
}
