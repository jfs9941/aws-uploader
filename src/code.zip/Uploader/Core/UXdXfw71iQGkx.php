<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Illuminate\Database\Eloquent\Model;
abstract  class UXdXfw71iQGkx extends Model implements TXpC7TSf51nOz
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mArqmCtDsDI() : bool
    {
        goto Yli5h;
        N1iCx:
        wVh74:
        goto llpzK;
        Yli5h:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto wVh74;
        }
        goto m31ms;
        m31ms:
        return true;
        goto N1iCx;
        llpzK:
        return !$this->m776g9R83VN();
        goto Ee6yN;
        Ee6yN:
    }
    protected function m776g9R83VN() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
