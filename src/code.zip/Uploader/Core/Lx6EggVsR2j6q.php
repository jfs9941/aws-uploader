<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Illuminate\Database\Eloquent\Model;
abstract  class Lx6EggVsR2j6q extends Model implements SYLdN2QnIYYwa
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mE5CimfvM7E() : bool
    {
        goto vspvE;
        lNeyP:
        return true;
        goto Llnuk;
        vspvE:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto gCgyj;
        }
        goto lNeyP;
        VFl6X:
        return !$this->mcBQhZUYwcf();
        goto dE0UQ;
        Llnuk:
        gCgyj:
        goto VFl6X;
        dE0UQ:
    }
    protected function mcBQhZUYwcf() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
