<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\Observer\NwsVhkVZKGj95;
use Jfs\Uploader\Core\XlkXvlTYaUWJ1;
use Jfs\Uploader\Core\Traits\S7x0KXILEa3L2;
use Jfs\Uploader\Core\Traits\VtC1QdkxsauRz;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Exception\GpiFZublserD8;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Exception\WhP3OD3EOngaS;
use Jfs\Uploader\Service\I399kYrV05irP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class IQDEtKorMDqYa implements Dsl7Uurv4XRG0
{
    use S7x0KXILEa3L2;
    use VtC1QdkxsauRz;
    private $LnH6g;
    private function __construct($cNpq7, $YNIuu, $l4Drs)
    {
        goto wJrKW;
        wJrKW:
        $this->WpbZG = $cNpq7;
        goto OyPru;
        OyPru:
        $this->gSpRj = $YNIuu;
        goto CBuzE;
        CBuzE:
        $this->DksH2 = $l4Drs;
        goto BvJgd;
        BvJgd:
    }
    private function ml39UMBMXCX(string $iwKga, $YNIuu, $NP1kd, bool $vY_08 = false) : void
    {
        $this->mi2D2FjJnRk(new NwsVhkVZKGj95($this, $YNIuu, $NP1kd, $iwKga, $vY_08));
    }
    public function getFile()
    {
        return $this->WpbZG;
    }
    public function mzAHhqFLnsA(array $VlQdL) : void
    {
        $this->LnH6g = $VlQdL;
    }
    public function mVDPno93DCr() : void
    {
        $this->muggTul6CGA(FmSSI1JLQCp0W::UPLOADING);
    }
    public function mGgqz89H6Ay() : void
    {
        $this->muggTul6CGA(FmSSI1JLQCp0W::UPLOADED);
    }
    public function mSYXQYiCPVo() : void
    {
        $this->muggTul6CGA(FmSSI1JLQCp0W::PROCESSING);
    }
    public function mu1B247a8LX() : void
    {
        $this->muggTul6CGA(FmSSI1JLQCp0W::FINISHED);
    }
    public function mIacc5D3d9X() : void
    {
        $this->muggTul6CGA(FmSSI1JLQCp0W::ABORTED);
    }
    public function mdhEWtQ1WBe() : array
    {
        return $this->LnH6g;
    }
    public static function mEtjWMS7bRc(string $EmnXX, $HdeaK, $l4Drs, $iwKga) : self
    {
        goto obIb7;
        FP2NB:
        $x6EER->m4fwFyIs4eQ(FmSSI1JLQCp0W::UPLOADING);
        goto JeXcI;
        Sg_8B:
        $x6EER = new self($cNpq7, $HdeaK, $l4Drs);
        goto oTZnr;
        JeXcI:
        return $x6EER->muOym0kQoUZ();
        goto P5UJM;
        obIb7:
        $cNpq7 = App::make(I399kYrV05irP::class)->mRh0zUGhT1w(XlkXvlTYaUWJ1::myM8iTLiY7F($EmnXX));
        goto Sg_8B;
        oTZnr:
        $x6EER->ml39UMBMXCX($iwKga, $HdeaK, $l4Drs);
        goto FP2NB;
        P5UJM:
    }
    public static function mVVyjmMk9BR($cNpq7, $YNIuu, $NP1kd, $iwKga, $vY_08 = false) : self
    {
        goto Y65gA;
        vo8T0:
        return $x6EER;
        goto Cca_b;
        Y65gA:
        $x6EER = new self($cNpq7, $YNIuu, $NP1kd);
        goto qZRdc;
        OAi90:
        $x6EER->m4fwFyIs4eQ(FmSSI1JLQCp0W::UPLOADING);
        goto vo8T0;
        qZRdc:
        $x6EER->ml39UMBMXCX($iwKga, $YNIuu, $NP1kd, $vY_08);
        goto OAi90;
        Cca_b:
    }
}
