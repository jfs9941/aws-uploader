<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Contracts\QPcmBScQDUpcH;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Traits\XU255kYjU0NUS;
use Jfs\Uploader\Core\Traits\CrEAGEW2Ahp7l;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Service\W6MKQSWDEHAwJ;
class B1V448YMelQAT extends MEyH4ejCzSk64 implements MEWwofwAYqgaI
{
    use XU255kYjU0NUS;
    use CrEAGEW2Ahp7l;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $pODrs, string $iJrca) : self
    {
        goto fqHfE;
        fqHfE:
        $dz5Zf = new self(['id' => $pODrs, 'type' => $iJrca, 'status' => FdWrko7bmoI4Y::UPLOADING]);
        goto HZim8;
        yafBb:
        return $dz5Zf;
        goto Pj1to;
        HZim8:
        $dz5Zf->mocw0y5gdUS(FdWrko7bmoI4Y::UPLOADING);
        goto yafBb;
        Pj1to:
    }
    public function getView() : array
    {
        $jku3P = app(QPcmBScQDUpcH::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $jku3P->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $jku3P->resolveThumbnail($this)];
    }
    public static function mayfBcrM7kL(MEyH4ejCzSk64 $pkR_A) : B1V448YMelQAT
    {
        goto sp5Mj;
        kf7z1:
        return $pkR_A;
        goto VRXbs;
        sp5Mj:
        if (!$pkR_A instanceof B1V448YMelQAT) {
            goto I1ojj;
        }
        goto kf7z1;
        VRXbs:
        I1ojj:
        goto odUS5;
        odUS5:
        return (new B1V448YMelQAT())->fill($pkR_A->getAttributes());
        goto Ltidp;
        Ltidp:
    }
}
