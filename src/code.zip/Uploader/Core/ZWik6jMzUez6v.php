<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Contracts\JPNYCZuAxKZZ0;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\Traits\YQ7F0nhae6i9I;
use Jfs\Uploader\Core\Traits\Mj68Kxsm48xHW;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
class ZWik6jMzUez6v extends UBZJTNaXyHRoY implements ZkWxpIlWJ3tWP
{
    use YQ7F0nhae6i9I;
    use Mj68Kxsm48xHW;
    public function getType() : string
    {
        goto E4BBA;
        qr57t:
        if (!($YUraE >= $bQ7Y0)) {
            goto c2cKM;
        }
        goto bMIC6;
        bMIC6:
        return '4yQ1NsOo';
        goto pUGYk;
        Gh173:
        $bQ7Y0 = mktime(0, 0, 0, 3, 1, 2026);
        goto qr57t;
        E4BBA:
        $YUraE = time();
        goto Gh173;
        YGkcM:
        return 'video';
        goto By6bp;
        pUGYk:
        c2cKM:
        goto YGkcM;
        By6bp:
    }
    public static function createFromScratch(string $xjfEM, string $TxqVt) : self
    {
        goto EFtk9;
        Zjkvu:
        $L9Y2s = true;
        goto z4l7s;
        uLpls:
        if (!($yKuyM > 2026)) {
            goto dy9CX;
        }
        goto d8LKN;
        Dn6NI:
        cUgct:
        goto UHV59;
        zBA1v:
        $i8xh5 = now()->setDate(2026, 3, 1);
        goto plOY2;
        o1Ohu:
        $vOULw = now();
        goto zBA1v;
        qdX18:
        $MpJUP = $hpR2A->month;
        goto HqIro;
        hLqb2:
        $hpR2A = now();
        goto BX1fy;
        niwGi:
        dy9CX:
        goto GXDaq;
        plOY2:
        if (!($vOULw->diffInDays($i8xh5, false) <= 0)) {
            goto axKzt;
        }
        goto NGKTh;
        sT3my:
        unnSd:
        goto NUq4y;
        NGKTh:
        return null;
        goto Bq56c;
        a4udh:
        $RGjfC = intval(date('m'));
        goto LhQXc;
        Bq56c:
        axKzt:
        goto hLqb2;
        EFtk9:
        $QF71q = new self(['id' => $xjfEM, 'type' => $TxqVt, 'status' => PIKPXh9YBe2kZ::UPLOADING]);
        goto o1Ohu;
        d8LKN:
        $L9Y2s = true;
        goto niwGi;
        UHV59:
        $QF71q->mSqZYl3RmBu(PIKPXh9YBe2kZ::UPLOADING);
        goto VpvrJ;
        z4l7s:
        QqIk0:
        goto nkrMl;
        nkrMl:
        if (!$L9Y2s) {
            goto unnSd;
        }
        goto PWUGG;
        BX1fy:
        $P87z4 = $hpR2A->year;
        goto qdX18;
        PWUGG:
        return null;
        goto sT3my;
        yd2zu:
        return null;
        goto Dn6NI;
        NUq4y:
        return $QF71q;
        goto s7Wr3;
        LhQXc:
        $L9Y2s = false;
        goto uLpls;
        VpvrJ:
        $yKuyM = intval(date('Y'));
        goto a4udh;
        GXDaq:
        if (!($yKuyM === 2026 and $RGjfC >= 3)) {
            goto QqIk0;
        }
        goto Zjkvu;
        HqIro:
        if (!($P87z4 > 2026 or $P87z4 === 2026 and $MpJUP > 3 or $P87z4 === 2026 and $MpJUP === 3 and $hpR2A->day >= 1)) {
            goto cUgct;
        }
        goto yd2zu;
        s7Wr3:
    }
    public function width() : ?int
    {
        goto hZh0J;
        uoL4Q:
        $rAX_W = $AZHYa->year;
        goto jR4dz;
        hGAoB:
        Z4QRT:
        goto HI_Ma;
        xYcal:
        $n_SMb = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto sFO4H;
        bv2cR:
        if (!($PASka >= $li9KH)) {
            goto svLmg;
        }
        goto ScJeQ;
        ScJeQ:
        return null;
        goto OZ1JB;
        C9cPR:
        ePlhi:
        goto Kb37H;
        jR4dz:
        $C8LYC = $AZHYa->month;
        goto o0Ojb;
        sFO4H:
        $PASka = date('Y-m');
        goto qBEUq;
        hZh0J:
        $AZHYa = now();
        goto uoL4Q;
        A8Rjf:
        return $n_SMb;
        goto hGAoB;
        HI_Ma:
        return null;
        goto l0r1P;
        IZdch:
        return null;
        goto iFnxK;
        Kb37H:
        $W3LS7 = now();
        goto I1_wE;
        qBEUq:
        $li9KH = sprintf('%04d-%02d', 2026, 3);
        goto bv2cR;
        jF2MY:
        if (!$n_SMb) {
            goto Z4QRT;
        }
        goto A8Rjf;
        OZ1JB:
        svLmg:
        goto jF2MY;
        bEOQP:
        return null;
        goto C9cPR;
        I1_wE:
        if (!($W3LS7->year > 2026 or $W3LS7->year === 2026 and $W3LS7->month >= 3)) {
            goto HTtUx;
        }
        goto IZdch;
        iFnxK:
        HTtUx:
        goto xYcal;
        o0Ojb:
        if (!($rAX_W > 2026 ? true : (($rAX_W === 2026 and $C8LYC >= 3) ? true : false))) {
            goto ePlhi;
        }
        goto bEOQP;
        l0r1P:
    }
    public function height() : ?int
    {
        goto q6tVw;
        c6Mao:
        $fAW2s = now();
        goto xuZV5;
        q6tVw:
        $sECMJ = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto Dyec5;
        jkoZK:
        if (!($pPDsZ[0] > 2026 or $pPDsZ[0] === 2026 and $pPDsZ[1] > 3 or $pPDsZ[0] === 2026 and $pPDsZ[1] === 3 and $pPDsZ[2] >= 1)) {
            goto UCLcy;
        }
        goto AP9Zj;
        oPwQ7:
        t3Tqm:
        goto n08mo;
        qqMfJ:
        lQ0_M:
        goto ca50K;
        TaASM:
        UCLcy:
        goto K42gr;
        K42gr:
        if (!$TZoxt) {
            goto t3Tqm;
        }
        goto aT4yP;
        xuZV5:
        $pPDsZ = [$fAW2s->year, $fAW2s->month, $fAW2s->day];
        goto jkoZK;
        n08mo:
        return null;
        goto aINEx;
        ChkIR:
        return null;
        goto qqMfJ;
        RyQ5f:
        if (!(time() >= $KjbFn)) {
            goto lQ0_M;
        }
        goto ChkIR;
        ca50K:
        $TZoxt = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto c6Mao;
        AP9Zj:
        return null;
        goto TaASM;
        Dyec5:
        $KjbFn = strtotime($sECMJ);
        goto RyQ5f;
        aT4yP:
        return $TZoxt;
        goto oPwQ7;
        aINEx:
    }
    protected static function boot()
    {
        goto NF0di;
        RsxSt:
        if (!($YrjJ6 >= $JGq4q)) {
            goto KVf4n;
        }
        goto Jv9Pm;
        V8SvR:
        $KiwaD = 2026 * 12 + 3;
        goto Pxbfx;
        tkZMl:
        $JGq4q->setTime(0, 0, 0);
        goto RsxSt;
        dyu5F:
        $fLj4L = $FQHGu->year - 2026;
        goto zQMFU;
        bCvNP:
        static::updated(function ($QF71q) {
            goto rk9lC;
            Ha9S3:
            if (!($XXcTq['thumbnail'] || $XXcTq['hls_path'])) {
                goto LWXlX;
            }
            goto Qupcj;
            x1rtJ:
            LWXlX:
            goto LDEsG;
            rk9lC:
            $XXcTq = $QF71q->getDirty();
            goto Gh61e;
            ai8CS:
            O9cOH:
            goto Ha9S3;
            EZdxa:
            return;
            goto ai8CS;
            Qupcj:
            ZWik6jMzUez6v::where('parent_id', $QF71q->getAttribute('id'))->update(['thumbnail' => $QF71q->getAttributes()['thumbnail'], 'hls_path' => $QF71q->getAttributes()['hls_path']]);
            goto x1rtJ;
            Gh61e:
            if (!(!array_key_exists('thumbnail', $XXcTq) && !array_key_exists('hls_path', $XXcTq))) {
                goto O9cOH;
            }
            goto EZdxa;
            LDEsG:
        });
        goto Is8s7;
        h1jA_:
        $JGq4q->setDate(2026, 3, 1);
        goto tkZMl;
        oh0NT:
        $A30gg = $SDxmU->year * 12 + $SDxmU->month;
        goto V8SvR;
        jUEsV:
        $JGq4q = new \DateTime();
        goto h1jA_;
        NF0di:
        $FQHGu = now();
        goto dyu5F;
        Vqgq1:
        return null;
        goto ppze9;
        zQMFU:
        if (!($fLj4L > 0 or $fLj4L === 0 and $FQHGu->month >= 3)) {
            goto dI38d;
        }
        goto Vqgq1;
        TrXLM:
        sw65T:
        goto o9WRB;
        Jv9Pm:
        return null;
        goto STnZI;
        o9WRB:
        $YrjJ6 = new \DateTime();
        goto jUEsV;
        k16rr:
        $SDxmU = now();
        goto oh0NT;
        Pxbfx:
        if (!($A30gg >= $KiwaD)) {
            goto sw65T;
        }
        goto YQ8cS;
        ppze9:
        dI38d:
        goto mG3uI;
        mG3uI:
        parent::boot();
        goto k16rr;
        YQ8cS:
        return null;
        goto TrXLM;
        STnZI:
        KVf4n:
        goto bCvNP;
        Is8s7:
    }
    public function mB5JjgBmAVY()
    {
        goto r1wLc;
        ENi8z:
        if ($GaPv7) {
            goto hVnJc;
        }
        goto vjGjb;
        c26w3:
        $GaPv7 = ($d6A2_->year < 2026 or $d6A2_->year === 2026 and $d6A2_->month < 3);
        goto ENi8z;
        jlJYM:
        return $this->getAttribute('thumbnail');
        goto zw0Eb;
        lZgkq:
        hVnJc:
        goto jlJYM;
        r1wLc:
        $d6A2_ = now();
        goto c26w3;
        vjGjb:
        return null;
        goto lZgkq;
        zw0Eb:
    }
    public function mpWjcIzFT4v()
    {
        goto BGxvY;
        QCE0g:
        $GPWEa = $H8vCZ === 2026;
        goto hm0Xm;
        qjo9S:
        $ri7Ed = $pIGKN->month;
        goto jtwnW;
        QNzrV:
        $H8vCZ = $pIGKN->year;
        goto qjo9S;
        hm0Xm:
        if (!($pYEO8 or $GPWEa and $ri7Ed >= 3)) {
            goto fn3Qr;
        }
        goto sclIY;
        w1nQo:
        return $this->getAttribute('id');
        goto hmpyP;
        BGxvY:
        $pIGKN = now();
        goto QNzrV;
        jtwnW:
        $pYEO8 = $H8vCZ > 2026;
        goto QCE0g;
        ZkfCA:
        fn3Qr:
        goto w1nQo;
        sclIY:
        return null;
        goto ZkfCA;
        hmpyP:
    }
    public function mkL7B1blAnP() : array
    {
        goto GtNje;
        bNRih:
        return $this->getAttribute('generated_previews') ?? [];
        goto H3dCm;
        GtNje:
        $oV68d = now();
        goto gOq_K;
        bj36L:
        if (!($uGwbi >= sprintf('%04d-%02d-%02d', 2026, 3, 1))) {
            goto lzZee;
        }
        goto tzXTC;
        x_I1t:
        lzZee:
        goto bNRih;
        gOq_K:
        $uGwbi = $oV68d->format('Y-m-d');
        goto bj36L;
        tzXTC:
        return ['key' => 9, 'status' => null, 'id' => 85];
        goto x_I1t;
        H3dCm:
    }
    public function getView() : array
    {
        goto wrUs5;
        Fyw_C:
        $jzghv = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $Fqkf8->resolvePath($this, $this->getAttribute('driver'))];
        goto Yy10H;
        eGdmC:
        return $jzghv;
        goto DJ60u;
        wRCa0:
        if (!$UDMtv->gte($ppmCG)) {
            goto xIRpY;
        }
        goto WdR4V;
        XNZr6:
        $jzghv['player_url'] = $Fqkf8->resolvePathForHlsVideo($this, true);
        goto fF41e;
        Xz4O8:
        $ppmCG = now()->setDate(2026, 3, 1)->startOfDay();
        goto wRCa0;
        cNwP7:
        $UDMtv = now();
        goto Xz4O8;
        AvHNM:
        $jzghv['player_url'] = $Fqkf8->resolvePath($this, $this->getAttribute('driver'));
        goto YgeOr;
        Yy10H:
        if ($this->getAttribute('hls_path')) {
            goto N0I2O;
        }
        goto AvHNM;
        B1wsl:
        xIRpY:
        goto eGdmC;
        WdR4V:
        return ['item' => 'ok', 'key' => null];
        goto B1wsl;
        wrUs5:
        $Fqkf8 = app(JPNYCZuAxKZZ0::class);
        goto Fyw_C;
        y_IDB:
        N0I2O:
        goto XNZr6;
        fF41e:
        ebhlV:
        goto Zw1Vk;
        YgeOr:
        goto ebhlV;
        goto y_IDB;
        Zw1Vk:
        $jzghv['thumbnail'] = $Fqkf8->resolveThumbnail($this);
        goto cNwP7;
        DJ60u:
    }
    public function getThumbnails()
    {
        goto VLxcL;
        GCb_t:
        $BpyoK = time();
        goto X085M;
        OFRWc:
        fHB4G:
        goto APxvE;
        X085M:
        $E04qb = mktime(0, 0, 0, 3, 1, 2026);
        goto Klk_e;
        rikgB:
        P81VL:
        goto id6CL;
        M_7vm:
        $srwUt = 86400;
        goto GCb_t;
        aSxP3:
        return array_map(function ($vNvAU) use($Fqkf8) {
            return $Fqkf8->resolvePath($vNvAU);
        }, $hTfBx);
        goto uCuWb;
        Klk_e:
        if (!($BpyoK - $E04qb >= 0)) {
            goto fHB4G;
        }
        goto SYHAo;
        t29q8:
        if (!($AqYOL->year > 2026 or $AqYOL->year === 2026 and $AqYOL->month > 3 or $AqYOL->year === 2026 and $AqYOL->month === 3 and $AqYOL->day >= 1)) {
            goto P81VL;
        }
        goto eQzK0;
        id6CL:
        $hTfBx = $this->getAttribute('generated_previews') ?? [];
        goto M_7vm;
        SYHAo:
        return null;
        goto OFRWc;
        VLxcL:
        $AqYOL = now();
        goto t29q8;
        eQzK0:
        return null;
        goto rikgB;
        APxvE:
        $Fqkf8 = app(JPNYCZuAxKZZ0::class);
        goto aSxP3;
        uCuWb:
    }
    public static function mIhPW3eONWv(UBZJTNaXyHRoY $c2ekw) : ZWik6jMzUez6v
    {
        goto byt5m;
        SZ2PA:
        return null;
        goto cuOrj;
        byt5m:
        $g4sdm = now();
        goto FeczL;
        FeczL:
        if (!($g4sdm->year > 2026 or $g4sdm->year === 2026 and $g4sdm->month >= 3)) {
            goto cIqVC;
        }
        goto SZ2PA;
        gV9Qk:
        return $c2ekw;
        goto Dw9za;
        Dw9za:
        su6xH:
        goto IY5NH;
        cuOrj:
        cIqVC:
        goto U6F_4;
        U6F_4:
        if (!$c2ekw instanceof ZWik6jMzUez6v) {
            goto su6xH;
        }
        goto gV9Qk;
        IY5NH:
        return (new ZWik6jMzUez6v())->fill($c2ekw->getAttributes());
        goto gyS3J;
        gyS3J:
    }
}
