<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Contracts\LuYApSsjKQvJj;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\Traits\IdjMnkSrUQeOj;
use Jfs\Uploader\Core\Traits\LwZBr5bK6EUWt;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Service\NCOAFhLniyr9A;
class JmnRmflAnvBc1 extends Lx6EggVsR2j6q implements PLPNmbBnD48xL
{
    use IdjMnkSrUQeOj;
    use LwZBr5bK6EUWt;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $f_0vQ, string $Xu3VW) : self
    {
        goto Z40bo;
        PR9GL:
        return $C0SbZ;
        goto oBiVn;
        Z40bo:
        $C0SbZ = new self(['id' => $f_0vQ, 'type' => $Xu3VW, 'status' => IfP50GBBbx63a::UPLOADING]);
        goto X1zsq;
        X1zsq:
        $C0SbZ->mdigVxgooZG(IfP50GBBbx63a::UPLOADING);
        goto PR9GL;
        oBiVn:
    }
    public function getView() : array
    {
        $CcclM = app(LuYApSsjKQvJj::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $CcclM->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $CcclM->resolveThumbnail($this)];
    }
    public static function mdQyy3wSeZR(Lx6EggVsR2j6q $vIqmh) : JmnRmflAnvBc1
    {
        goto YpAxh;
        iJZPb:
        return $vIqmh;
        goto NzjTv;
        YpAxh:
        if (!$vIqmh instanceof JmnRmflAnvBc1) {
            goto eQ01r;
        }
        goto iJZPb;
        dBFv7:
        return (new JmnRmflAnvBc1())->fill($vIqmh->getAttributes());
        goto dXa63;
        NzjTv:
        eQ01r:
        goto dBFv7;
        dXa63:
    }
}
