<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Core\Traits\FdeEVbF7HDTyC;
use Jfs\Uploader\Core\Traits\LPvREnedjbdSc;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class S25BfMDKrX8cB extends HJJu0xs0QACaQ implements IEfiXfym24wIp
{
    use FdeEVbF7HDTyC;
    use LPvREnedjbdSc;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $yU2y0, string $Vb_Cv) : self
    {
        goto VQCwM;
        VQCwM:
        $DuZ1o = new self(['id' => $yU2y0, 'type' => $Vb_Cv, 'status' => N4CY6qDTBAjPa::UPLOADING]);
        goto W9YOb;
        W9YOb:
        $DuZ1o->myNb3hyTkbG(N4CY6qDTBAjPa::UPLOADING);
        goto P3sDt;
        P3sDt:
        return $DuZ1o;
        goto YHJ23;
        YHJ23:
    }
    public function width() : ?int
    {
        goto yY3SV;
        yY3SV:
        $vwL5B = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto VUOYB;
        m1F1x:
        return $vwL5B;
        goto wAGVu;
        QdYLq:
        return null;
        goto xPNte;
        wAGVu:
        xQdKk:
        goto QdYLq;
        VUOYB:
        if (!$vwL5B) {
            goto xQdKk;
        }
        goto m1F1x;
        xPNte:
    }
    public function height() : ?int
    {
        goto LmRCx;
        sgZTV:
        return null;
        goto msssy;
        mPzhd:
        if (!$ttadT) {
            goto hlLNm;
        }
        goto K1NcM;
        K1NcM:
        return $ttadT;
        goto oH1ss;
        oH1ss:
        hlLNm:
        goto sgZTV;
        LmRCx:
        $ttadT = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto mPzhd;
        msssy:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($DuZ1o) {
            goto nOuKt;
            CvyHB:
            S25BfMDKrX8cB::where('parent_id', $DuZ1o->getAttribute('id'))->update(['thumbnail' => $DuZ1o->getAttributes()['thumbnail'], 'hls_path' => $DuZ1o->getAttributes()['hls_path']]);
            goto UAlzE;
            UAlzE:
            Dupt4:
            goto ck8EC;
            nOuKt:
            $hpWct = $DuZ1o->getDirty();
            goto W5fdv;
            W5fdv:
            if (!(!array_key_exists('thumbnail', $hpWct) && !array_key_exists('hls_path', $hpWct))) {
                goto OG0OG;
            }
            goto NvHvP;
            dDUti:
            if (!($hpWct['thumbnail'] || $hpWct['hls_path'])) {
                goto Dupt4;
            }
            goto CvyHB;
            H_gyl:
            OG0OG:
            goto dDUti;
            NvHvP:
            return;
            goto H_gyl;
            ck8EC:
        });
    }
    public function mc7VJwzlcmw()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mpDN9TqF0BP()
    {
        return $this->getAttribute('id');
    }
    public function m23611Wf1SX() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto mJqdk;
        mJqdk:
        $B5JAi = app(UKSr4EAd7qrlK::class);
        goto G3RJq;
        ldDSx:
        if ($this->getAttribute('hls_path')) {
            goto wW_ec;
        }
        goto DKLcJ;
        cNUYj:
        $pQ0Yz['player_url'] = $B5JAi->resolvePathForHlsVideo($this, true);
        goto k6O0t;
        M1fQY:
        wW_ec:
        goto cNUYj;
        MS2Ly:
        goto n_0sf;
        goto M1fQY;
        DKLcJ:
        $pQ0Yz['player_url'] = $B5JAi->resolvePath($this, $this->getAttribute('driver'));
        goto MS2Ly;
        JGpqr:
        return $pQ0Yz;
        goto zT5RI;
        a5H7E:
        $pQ0Yz['thumbnail'] = $B5JAi->resolveThumbnail($this);
        goto JGpqr;
        G3RJq:
        $pQ0Yz = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $B5JAi->resolvePath($this, $this->getAttribute('driver'))];
        goto ldDSx;
        k6O0t:
        n_0sf:
        goto a5H7E;
        zT5RI:
    }
    public function getThumbnails()
    {
        goto eAUDN;
        eAUDN:
        $oMlUW = $this->getAttribute('generated_previews') ?? [];
        goto mCuGI;
        mCuGI:
        $B5JAi = app(UKSr4EAd7qrlK::class);
        goto Onr6M;
        Onr6M:
        return array_map(function ($jVS4s) use($B5JAi) {
            return $B5JAi->resolvePath($jVS4s);
        }, $oMlUW);
        goto XUJH2;
        XUJH2:
    }
    public static function mhgdbkItnfv(HJJu0xs0QACaQ $MgH4F) : S25BfMDKrX8cB
    {
        goto D3Fso;
        D3Fso:
        if (!$MgH4F instanceof S25BfMDKrX8cB) {
            goto iwd01;
        }
        goto WA3ae;
        vEhG8:
        iwd01:
        goto C3QOc;
        C3QOc:
        return (new S25BfMDKrX8cB())->fill($MgH4F->getAttributes());
        goto SQkpm;
        WA3ae:
        return $MgH4F;
        goto vEhG8;
        SQkpm:
    }
}
