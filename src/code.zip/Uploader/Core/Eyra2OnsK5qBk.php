<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Core\Observer\YLB6KnUD0kERR;
use Jfs\Uploader\Core\Traits\Y5hONQswBVdkk;
use Jfs\Uploader\Core\Traits\U4dsP2dkmJHns;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Exception\BI7zT0hnXVI9h;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Jfs\Uploader\Exception\HAf99Vtg3teX9;
use Jfs\Uploader\Service\IsJEOSgV8mPOx;
final class Eyra2OnsK5qBk implements CxLspzxS91nUL
{
    use Y5hONQswBVdkk;
    use U4dsP2dkmJHns;
    private $Nn0mi;
    private function __construct($rQ18B, $AhP23)
    {
        $this->IJ6tP = $rQ18B;
        $this->wOw95 = $AhP23;
    }
    private function mEeA1p3pfdF(string $E6K8y, $AhP23, $A6wTz, bool $G326f = false) : void
    {
        $this->mUpiDytTDuT(new YLB6KnUD0kERR($this, $AhP23, $A6wTz, $E6K8y, $G326f));
    }
    public function getFile()
    {
        return $this->IJ6tP;
    }
    public function mfrHpIeDbxs(array $QC0wJ) : void
    {
        $this->Nn0mi = $QC0wJ;
    }
    public function mGDIq8tG9F4() : void
    {
        $this->mZecThKyfk1(SwAwanZG36Yx6::UPLOADING);
    }
    public function miGXX9YY39t() : void
    {
        $this->mZecThKyfk1(SwAwanZG36Yx6::UPLOADED);
    }
    public function m9PSw2qxohj() : void
    {
        $this->mZecThKyfk1(SwAwanZG36Yx6::PROCESSING);
    }
    public function mcDH5mwYJpF() : void
    {
        $this->mZecThKyfk1(SwAwanZG36Yx6::FINISHED);
    }
    public function m4lSEjYc3Qj() : void
    {
        $this->mZecThKyfk1(SwAwanZG36Yx6::ABORTED);
    }
    public function mGK46yiocdc() : array
    {
        return $this->Nn0mi;
    }
    public static function meMp6HqhH3z(string $mfjeD, $cUUt8, $Klx1U, $E6K8y) : self
    {
        goto Pstrg;
        dLGTg:
        $DIWAI = new self($rQ18B, $cUUt8);
        goto QXHKJ;
        Pstrg:
        $rQ18B = App::make(IsJEOSgV8mPOx::class)->mpQZT6Vp0sV(LJgttSC2SO5Qb::mMyUAUeGBJE($mfjeD));
        goto dLGTg;
        nQhXU:
        return $DIWAI->m1us7rpWBJV();
        goto s5t3w;
        mpJgr:
        $DIWAI->m25UhhF4K3y(SwAwanZG36Yx6::UPLOADING);
        goto nQhXU;
        QXHKJ:
        $DIWAI->mEeA1p3pfdF($E6K8y, $cUUt8, $Klx1U);
        goto mpJgr;
        s5t3w:
    }
    public static function mdv2fYQaPU1($rQ18B, $AhP23, $A6wTz, $E6K8y, $G326f = false) : self
    {
        goto lKkqw;
        TD14x:
        $DIWAI->mEeA1p3pfdF($E6K8y, $AhP23, $A6wTz, $G326f);
        goto PBUVy;
        QJxhp:
        return $DIWAI;
        goto aOtro;
        lKkqw:
        $DIWAI = new self($rQ18B, $AhP23);
        goto TD14x;
        PBUVy:
        $DIWAI->m25UhhF4K3y(SwAwanZG36Yx6::UPLOADING);
        goto QJxhp;
        aOtro:
    }
}
