<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Illuminate\Database\Eloquent\Model;
abstract  class NRDoWGrbd9WhU extends Model implements BTuo2UPlpfSoS
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mNHdgR2nlsA() : bool
    {
        goto agcvm;
        M0ROY:
        return !$this->mMtS6ExJJCa();
        goto MmL7B;
        agcvm:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto ZmEA5;
        }
        goto M__pb;
        mJ8pV:
        ZmEA5:
        goto M0ROY;
        M__pb:
        return true;
        goto mJ8pV;
        MmL7B:
    }
    protected function mMtS6ExJJCa() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
