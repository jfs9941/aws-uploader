<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Core\Observer\QMLuzm1fPASgz;
use Jfs\Uploader\Core\Traits\LFne7ijSG70wJ;
use Jfs\Uploader\Core\Traits\GnXq4OXXJLYXp;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Exception\SwRmuIL9tuB7h;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Jfs\Uploader\Exception\SXcV92PG8WkeS;
use Jfs\Uploader\Service\B0zx05APUr70A;
final class I9eXouytPf2zH implements XZsrc8KnXftCK
{
    use LFne7ijSG70wJ;
    use GnXq4OXXJLYXp;
    private $TEK1D;
    private function __construct($PQjbH, $e1L33)
    {
        $this->T6rAm = $PQjbH;
        $this->TeKrB = $e1L33;
    }
    private function mBBI8UCguJE(string $TnK9g, $e1L33, $o9ClE, bool $b_9Ve = false) : void
    {
        $this->mxt7Kk7QeSS(new QMLuzm1fPASgz($this, $e1L33, $o9ClE, $TnK9g, $b_9Ve));
    }
    public function getFile()
    {
        return $this->T6rAm;
    }
    public function mKnU1KBXWBI(array $m_Mog) : void
    {
        $this->TEK1D = $m_Mog;
    }
    public function mHX5nftJZ3k() : void
    {
        $this->mTKyaraJgz7(UimQKBIuLCEAO::UPLOADING);
    }
    public function m0JbWcPZhsK() : void
    {
        $this->mTKyaraJgz7(UimQKBIuLCEAO::UPLOADED);
    }
    public function malfoqLbNuP() : void
    {
        $this->mTKyaraJgz7(UimQKBIuLCEAO::PROCESSING);
    }
    public function mwyn7VO1lcF() : void
    {
        $this->mTKyaraJgz7(UimQKBIuLCEAO::FINISHED);
    }
    public function ms51lN9QOM3() : void
    {
        $this->mTKyaraJgz7(UimQKBIuLCEAO::ABORTED);
    }
    public function m8jeis941P9() : array
    {
        return $this->TEK1D;
    }
    public static function ml9d4ws1Cxk(string $ld8Ad, $NxwXZ, $duBfR, $TnK9g) : self
    {
        goto pUAwM;
        UNs13:
        return $CSwjw->mcJKeP3Rzqg();
        goto ksm6M;
        cWUQ6:
        $CSwjw->mBBI8UCguJE($TnK9g, $NxwXZ, $duBfR);
        goto qCCh_;
        eOKlC:
        $CSwjw = new self($PQjbH, $NxwXZ);
        goto cWUQ6;
        qCCh_:
        $CSwjw->mnZV8lryeWr(UimQKBIuLCEAO::UPLOADING);
        goto UNs13;
        pUAwM:
        $PQjbH = App::make(B0zx05APUr70A::class)->mA3OUi5XBwu(WOlVkQsBFs8pP::md7VzGoRhNQ($ld8Ad));
        goto eOKlC;
        ksm6M:
    }
    public static function mP5oYjcuGW4($PQjbH, $e1L33, $o9ClE, $TnK9g, $b_9Ve = false) : self
    {
        goto yjrl0;
        VMqyD:
        $CSwjw->mnZV8lryeWr(UimQKBIuLCEAO::UPLOADING);
        goto MH8TM;
        MH8TM:
        return $CSwjw;
        goto eDpE2;
        hcBGf:
        $CSwjw->mBBI8UCguJE($TnK9g, $e1L33, $o9ClE, $b_9Ve);
        goto VMqyD;
        yjrl0:
        $CSwjw = new self($PQjbH, $e1L33);
        goto hcBGf;
        eDpE2:
    }
}
