<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Illuminate\Database\Eloquent\Model;
abstract  class OLbbi5g81G7dU extends Model implements EmuD0NTRxtQv1
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mDdXjjw4WKU() : bool
    {
        goto QwKik;
        gpXpJ:
        $CuMbl = mktime(0, 0, 0, 3, 1, 2026);
        goto dkzbx;
        dkzbx:
        if (!($QF9LH >= $CuMbl)) {
            goto GppXA;
        }
        goto CeOK9;
        QwKik:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto HY6oi;
        }
        goto DfFPl;
        CeOK9:
        return true;
        goto uwLQm;
        rTPI8:
        return !$this->mF4W5FOWGoa();
        goto AND1y;
        DfFPl:
        return true;
        goto iOFBC;
        baX_H:
        $QF9LH = time();
        goto gpXpJ;
        uwLQm:
        GppXA:
        goto rTPI8;
        iOFBC:
        HY6oi:
        goto baX_H;
        AND1y:
    }
    protected function mF4W5FOWGoa() : bool
    {
        goto ONkgf;
        GSLg7:
        return null === $this->getAttribute('parent_id');
        goto zGnVd;
        JhxFG:
        AFBXK:
        goto dOGjK;
        GZMwf:
        if (!($cSy25 > 2026)) {
            goto AFBXK;
        }
        goto EEfNf;
        Lui0Y:
        $DH9Jr = false;
        goto GZMwf;
        Z3T3r:
        EPUP4:
        goto mE7wh;
        FO0IL:
        $DH9Jr = true;
        goto Z3T3r;
        mE7wh:
        if (!$DH9Jr) {
            goto Z6NQ0;
        }
        goto IgmAt;
        EEfNf:
        $DH9Jr = true;
        goto JhxFG;
        dlxug:
        $Q51A0 = intval(date('m'));
        goto Lui0Y;
        ONkgf:
        $cSy25 = intval(date('Y'));
        goto dlxug;
        IgmAt:
        return false;
        goto sKP6g;
        sKP6g:
        Z6NQ0:
        goto GSLg7;
        dOGjK:
        if (!($cSy25 === 2026 and $Q51A0 >= 3)) {
            goto EPUP4;
        }
        goto FO0IL;
        zGnVd:
    }
    public abstract function getView() : array;
}
