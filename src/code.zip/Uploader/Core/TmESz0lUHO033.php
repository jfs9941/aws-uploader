<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\Observer\Eqe7NQ5FnLefn;
use Jfs\Uploader\Core\S6ysKpQv89ofz;
use Jfs\Uploader\Core\Traits\FNxo2Rju49JeZ;
use Jfs\Uploader\Core\Traits\WUkQAePShMtJo;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Exception\RRyzFa9lvheK9;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Exception\GNBoSRgkmhvfn;
use Jfs\Uploader\Service\SLO5cl2ibvGWu;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class TmESz0lUHO033 implements WHyfIbzEzUFEe
{
    use FNxo2Rju49JeZ;
    use WUkQAePShMtJo;
    private $N3Bg5;
    private function __construct($VslFR, $zuNM5)
    {
        $this->LXD2P = $VslFR;
        $this->X7RRG = $zuNM5;
    }
    private function mkDQkjHBJVk(string $drKb4, $zuNM5, $S3rMg, bool $FDEfO = false) : void
    {
        $this->mhhx9gSDj1U(new Eqe7NQ5FnLefn($this, $zuNM5, $S3rMg, $drKb4, $FDEfO));
    }
    public function getFile()
    {
        return $this->LXD2P;
    }
    public function mHScPCLoHCA(array $bP1zt) : void
    {
        $this->N3Bg5 = $bP1zt;
    }
    public function mmsgjSZc6hq() : void
    {
        $this->m6ASJ5S5Ktp(T93Mcsw1gA3an::UPLOADING);
    }
    public function mq97dowG195() : void
    {
        $this->m6ASJ5S5Ktp(T93Mcsw1gA3an::UPLOADED);
    }
    public function mgcQEZj794T() : void
    {
        $this->m6ASJ5S5Ktp(T93Mcsw1gA3an::PROCESSING);
    }
    public function mQiWiRCpHOL() : void
    {
        $this->m6ASJ5S5Ktp(T93Mcsw1gA3an::FINISHED);
    }
    public function mYIhZteZDyD() : void
    {
        $this->m6ASJ5S5Ktp(T93Mcsw1gA3an::ABORTED);
    }
    public function mrYymiL7sqz() : array
    {
        return $this->N3Bg5;
    }
    public static function mtugZzzj6Hx(string $hOWbX, $oMRSq, $dzspH, $drKb4) : self
    {
        goto oFwqF;
        TK3II:
        $darX4 = new self($VslFR, $oMRSq);
        goto GLu17;
        o214I:
        return $darX4->mhW2MyKimam();
        goto V6fko;
        oFwqF:
        $VslFR = App::make(SLO5cl2ibvGWu::class)->mARUIML1iFB(S6ysKpQv89ofz::mttkCSEeOLf($hOWbX));
        goto TK3II;
        GLu17:
        $darX4->mkDQkjHBJVk($drKb4, $oMRSq, $dzspH);
        goto WH84r;
        WH84r:
        $darX4->mNsps8Id3BK(T93Mcsw1gA3an::UPLOADING);
        goto o214I;
        V6fko:
    }
    public static function meJnQ0MYaF2($VslFR, $zuNM5, $S3rMg, $drKb4, $FDEfO = false) : self
    {
        goto uHIoO;
        LHa2w:
        $darX4->mNsps8Id3BK(T93Mcsw1gA3an::UPLOADING);
        goto Qsopv;
        uHIoO:
        $darX4 = new self($VslFR, $zuNM5);
        goto F_Kh2;
        F_Kh2:
        $darX4->mkDQkjHBJVk($drKb4, $zuNM5, $S3rMg, $FDEfO);
        goto LHa2w;
        Qsopv:
        return $darX4;
        goto gQxFt;
        gQxFt:
    }
}
