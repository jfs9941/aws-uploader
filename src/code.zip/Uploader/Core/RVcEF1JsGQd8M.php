<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Contracts\Hj0NrxjG6qaVy;
use Jfs\Uploader\Core\Traits\VxlX0xA9Oyzyn;
use Jfs\Uploader\Core\Traits\GnXq4OXXJLYXp;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class RVcEF1JsGQd8M extends O4HsadxAyKjYq implements XZsrc8KnXftCK
{
    use VxlX0xA9Oyzyn;
    use GnXq4OXXJLYXp;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $KKu2U, string $FonuJ) : self
    {
        goto t04ry;
        t04ry:
        $Ipllx = new self(['id' => $KKu2U, 'type' => $FonuJ, 'status' => UimQKBIuLCEAO::UPLOADING]);
        goto ftEOg;
        DkufO:
        return $Ipllx;
        goto OVbH2;
        ftEOg:
        $Ipllx->mnZV8lryeWr(UimQKBIuLCEAO::UPLOADING);
        goto DkufO;
        OVbH2:
    }
    public function width() : ?int
    {
        goto gJZvm;
        Ltc8V:
        return $Gsmm4;
        goto HBVAJ;
        gJZvm:
        $Gsmm4 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto QAj2M;
        HBVAJ:
        jXo1d:
        goto yZBlO;
        QAj2M:
        if (!$Gsmm4) {
            goto jXo1d;
        }
        goto Ltc8V;
        yZBlO:
        return null;
        goto Fa7M3;
        Fa7M3:
    }
    public function height() : ?int
    {
        goto RsOo7;
        RsOo7:
        $iM4bK = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto vYlqj;
        Y0uwt:
        return null;
        goto oApba;
        vYlqj:
        if (!$iM4bK) {
            goto OrSoW;
        }
        goto JR6bL;
        JR6bL:
        return $iM4bK;
        goto ziUov;
        ziUov:
        OrSoW:
        goto Y0uwt;
        oApba:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($Ipllx) {
            goto VvZQv;
            kv1fX:
            ETtOZ:
            goto frBp1;
            eug2U:
            ZfdM1:
            goto FY2ja;
            LSIzL:
            RVcEF1JsGQd8M::where('parent_id', $Ipllx->getAttribute('id'))->update(['thumbnail' => $Ipllx->getAttributes()['thumbnail'], 'hls_path' => $Ipllx->getAttributes()['hls_path']]);
            goto kv1fX;
            Zd3DH:
            return;
            goto eug2U;
            VvZQv:
            $hPJqt = $Ipllx->getDirty();
            goto iwSvo;
            iwSvo:
            if (!(!array_key_exists('thumbnail', $hPJqt) && !array_key_exists('hls_path', $hPJqt))) {
                goto ZfdM1;
            }
            goto Zd3DH;
            FY2ja:
            if (!($hPJqt['thumbnail'] || $hPJqt['hls_path'])) {
                goto ETtOZ;
            }
            goto LSIzL;
            frBp1:
        });
    }
    public function mTnHy6TOBdv()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mPUXNxRVrMG()
    {
        return $this->getAttribute('id');
    }
    public function mUG4jgFJWzb() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Ge1xZ;
        kiMIJ:
        $TdECi['player_url'] = $z_puv->resolvePathForHlsVideo($this, true);
        goto NtcF_;
        tVVne:
        $TdECi['thumbnail'] = $z_puv->resolveThumbnail($this);
        goto rzzDO;
        tZo6y:
        $TdECi = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $z_puv->resolvePath($this, $this->getAttribute('driver'))];
        goto Y4yKX;
        rzzDO:
        return $TdECi;
        goto NieMw;
        Y4yKX:
        if ($this->getAttribute('hls_path')) {
            goto KDqlU;
        }
        goto SP7xF;
        A0uYe:
        KDqlU:
        goto kiMIJ;
        Ge1xZ:
        $z_puv = app(Hj0NrxjG6qaVy::class);
        goto tZo6y;
        NtcF_:
        YKmSR:
        goto tVVne;
        SP7xF:
        $TdECi['player_url'] = $z_puv->resolvePath($this, $this->getAttribute('driver'));
        goto NwiIv;
        NwiIv:
        goto YKmSR;
        goto A0uYe;
        NieMw:
    }
    public function getThumbnails()
    {
        goto RrZJY;
        opofq:
        $z_puv = app(Hj0NrxjG6qaVy::class);
        goto GAYOO;
        GAYOO:
        return array_map(function ($pBU9S) use($z_puv) {
            return $z_puv->resolvePath($pBU9S);
        }, $ncu8K);
        goto LG_w9;
        RrZJY:
        $ncu8K = $this->getAttribute('generated_previews') ?? [];
        goto opofq;
        LG_w9:
    }
    public static function mkZPLnccwfi(O4HsadxAyKjYq $NyN9S) : RVcEF1JsGQd8M
    {
        goto gHMkg;
        gHMkg:
        if (!$NyN9S instanceof RVcEF1JsGQd8M) {
            goto l74yD;
        }
        goto qdQsK;
        cuR_W:
        return (new RVcEF1JsGQd8M())->fill($NyN9S->getAttributes());
        goto CG506;
        PqQSx:
        l74yD:
        goto cuR_W;
        qdQsK:
        return $NyN9S;
        goto PqQSx;
        CG506:
    }
}
