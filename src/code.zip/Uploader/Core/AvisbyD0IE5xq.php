<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Contracts\NTBMTa29AeaJq;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\Traits\A6wERosUOJgWZ;
use backup\Uploader\Core\Traits\Fk7u5grtM5kGF;
use backup\Uploader\Enum\Aetm2HiFuJE34;
class AvisbyD0IE5xq extends PJqa0Yy2jwBHe implements VnrpqIkXJe1mn
{
    use A6wERosUOJgWZ;
    use Fk7u5grtM5kGF;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $IMDKn, string $ISfDH) : self
    {
        goto u5urS;
        L0ZEm:
        return $L2Ff8;
        goto EkAcv;
        NQ3TL:
        $L2Ff8->mV7ZhSMguWB(Aetm2HiFuJE34::UPLOADING);
        goto L0ZEm;
        u5urS:
        $L2Ff8 = new self(['id' => $IMDKn, 'type' => $ISfDH, 'status' => Aetm2HiFuJE34::UPLOADING]);
        goto NQ3TL;
        EkAcv:
    }
    public function width() : ?int
    {
        goto waq5O;
        hnAl3:
        vljIv:
        goto uZ0KV;
        ll2pf:
        return $BxXBR;
        goto hnAl3;
        waq5O:
        $BxXBR = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto ilKLD;
        ilKLD:
        if (!$BxXBR) {
            goto vljIv;
        }
        goto ll2pf;
        uZ0KV:
        return null;
        goto FL4w4;
        FL4w4:
    }
    public function height() : ?int
    {
        goto XMCZj;
        XMCZj:
        $w10Ma = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto DYNoW;
        sPSyY:
        return null;
        goto Leaij;
        kLQSe:
        return $w10Ma;
        goto GUlut;
        GUlut:
        ZGTLn:
        goto sPSyY;
        DYNoW:
        if (!$w10Ma) {
            goto ZGTLn;
        }
        goto kLQSe;
        Leaij:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($L2Ff8) {
            goto l3WtR;
            zoYnr:
            if (!($oYsjE['thumbnail'] || $oYsjE['hls_path'])) {
                goto bUOkJ;
            }
            goto HIWdr;
            HIWdr:
            AvisbyD0IE5xq::where('parent_id', $L2Ff8->getAttribute('id'))->update(['thumbnail' => $L2Ff8->getAttributes()['thumbnail'], 'hls_path' => $L2Ff8->getAttributes()['hls_path']]);
            goto kktNd;
            l3WtR:
            $oYsjE = $L2Ff8->getDirty();
            goto Z_TZr;
            Z_TZr:
            if (!(!array_key_exists('thumbnail', $oYsjE) && !array_key_exists('hls_path', $oYsjE))) {
                goto tALuU;
            }
            goto jA56F;
            jA56F:
            return;
            goto eIaqS;
            kktNd:
            bUOkJ:
            goto g2Ajq;
            eIaqS:
            tALuU:
            goto zoYnr;
            g2Ajq:
        });
    }
    public function mtq7Y8emlXb()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mQhfFKpNRFv()
    {
        return $this->getAttribute('id');
    }
    public function mrAKUJLucZ8() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto S_89R;
        XURp3:
        if ($this->getAttribute('hls_path')) {
            goto UtGIy;
        }
        goto za_9W;
        TVs81:
        $wNj_Z['thumbnail'] = $ddgk2->resolveThumbnail($this);
        goto cvDnH;
        za_9W:
        $wNj_Z['player_url'] = $ddgk2->resolvePath($this, $this->getAttribute('driver'));
        goto rF873;
        ETEAh:
        QJI4r:
        goto TVs81;
        NdNfU:
        $wNj_Z = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $ddgk2->resolvePath($this, $this->getAttribute('driver'))];
        goto XURp3;
        Ubxd4:
        $wNj_Z['player_url'] = $ddgk2->resolvePathForHlsVideo($this, true);
        goto ETEAh;
        rF873:
        goto QJI4r;
        goto MXB5n;
        cvDnH:
        return $wNj_Z;
        goto Z9cbr;
        S_89R:
        $ddgk2 = app(NTBMTa29AeaJq::class);
        goto NdNfU;
        MXB5n:
        UtGIy:
        goto Ubxd4;
        Z9cbr:
    }
    public function getThumbnails()
    {
        goto ZvKX0;
        PSrYe:
        $ddgk2 = app(NTBMTa29AeaJq::class);
        goto r2gp9;
        ZvKX0:
        $O4A1X = $this->getAttribute('generated_previews') ?? [];
        goto PSrYe;
        r2gp9:
        return array_map(function ($bp6Lq) use($ddgk2) {
            return $ddgk2->resolvePath($bp6Lq);
        }, $O4A1X);
        goto tm5cV;
        tm5cV:
    }
    public static function mfV15QbPTt4(PJqa0Yy2jwBHe $JFGfH) : AvisbyD0IE5xq
    {
        goto PrYd8;
        Hvo7p:
        return $JFGfH;
        goto JxOnU;
        JxOnU:
        B12Pp:
        goto Xq1a2;
        Xq1a2:
        return (new AvisbyD0IE5xq())->fill($JFGfH->getAttributes());
        goto Th0nW;
        PrYd8:
        if (!$JFGfH instanceof AvisbyD0IE5xq) {
            goto B12Pp;
        }
        goto Hvo7p;
        Th0nW:
    }
}
