<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Core\Traits\RN8oxnSswJ42z;
use Jfs\Uploader\Core\Traits\DbEmnet2FoHTm;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Service\WILlDNuoyQRBR;
class XWqfTCKHy5X8X extends Dup6KVtAFNCUq implements PxTzgsobiHpcX
{
    use RN8oxnSswJ42z;
    use DbEmnet2FoHTm;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $FeNc2, string $lfMjH) : self
    {
        goto fH780;
        fH780:
        $wxqAD = new self(['id' => $FeNc2, 'type' => $lfMjH, 'status' => O8RzIjGmSN6fG::UPLOADING]);
        goto pJjse;
        rkcsN:
        return $wxqAD;
        goto O770Z;
        pJjse:
        $wxqAD->mt6YUzzNxIA(O8RzIjGmSN6fG::UPLOADING);
        goto rkcsN;
        O770Z:
    }
    public function getView() : array
    {
        $rm8QX = app(MpZUpGr3YFIhj::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $rm8QX->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $rm8QX->resolveThumbnail($this)];
    }
    public static function m6LSnq6paa7(Dup6KVtAFNCUq $FFbb9) : XWqfTCKHy5X8X
    {
        goto QKk4K;
        QiK_U:
        IJYUH:
        goto oDCye;
        ZSG31:
        return $FFbb9;
        goto QiK_U;
        QKk4K:
        if (!$FFbb9 instanceof XWqfTCKHy5X8X) {
            goto IJYUH;
        }
        goto ZSG31;
        oDCye:
        return (new XWqfTCKHy5X8X())->fill($FFbb9->getAttributes());
        goto suDt3;
        suDt3:
    }
}
