<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\GrPXtp41lLmde;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
final class ASReQHmrabNfg
{
    public $filename;
    public $D32Aw;
    public $UM7qO;
    public $eD7KV;
    public $Xlwm2;
    public $cAjCT;
    public $izUZw;
    public $status;
    public $b31DR;
    public $Q2m8A;
    public $rs3Zr = 's3';
    public $JkyMk = [];
    public function __construct($THoxE, $SrbsC, $NbLgB, $bgV58, $HZVGD, $GzTUV, $Oz2G3, $pqaBy, $UVY53, $gA0os, $yXj4Q = 's3', $cJl2t = [])
    {
        goto RGmpn;
        MzVyQ:
        $this->eD7KV = $bgV58;
        goto XESKG;
        RGmpn:
        $this->filename = $THoxE;
        goto t0VoQ;
        JRrFW:
        $this->rs3Zr = $yXj4Q;
        goto f3Ppb;
        GZVJ3:
        $this->izUZw = $Oz2G3;
        goto G_Ur1;
        DlCr9:
        $this->Q2m8A = $gA0os;
        goto JRrFW;
        G_Ur1:
        $this->status = $pqaBy;
        goto vOsYE;
        kBV07:
        $this->UM7qO = $NbLgB;
        goto MzVyQ;
        vOsYE:
        $this->b31DR = $UVY53;
        goto DlCr9;
        XESKG:
        $this->Xlwm2 = $HZVGD;
        goto ownNT;
        t0VoQ:
        $this->D32Aw = $SrbsC;
        goto kBV07;
        f3Ppb:
        $this->JkyMk = $cJl2t;
        goto UAqGz;
        ownNT:
        $this->cAjCT = $GzTUV;
        goto GZVJ3;
        UAqGz:
    }
    private static function mDP7Huk2oqD() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mPF8Fk5bXm4() : array
    {
        return array_flip(self::mDP7Huk2oqD());
    }
    public function toArray() : array
    {
        $bGu7Z = self::mDP7Huk2oqD();
        return [$bGu7Z['filename'] => $this->filename, $bGu7Z['fileExtension'] => $this->D32Aw, $bGu7Z['mimeType'] => $this->UM7qO, $bGu7Z['fileSize'] => $this->eD7KV, $bGu7Z['chunkSize'] => $this->Xlwm2, $bGu7Z['checksums'] => $this->cAjCT, $bGu7Z['totalChunk'] => $this->izUZw, $bGu7Z['status'] => $this->status, $bGu7Z['userId'] => $this->b31DR, $bGu7Z['uploadId'] => $this->Q2m8A, $bGu7Z['driver'] => $this->rs3Zr, $bGu7Z['parts'] => $this->JkyMk];
    }
    public static function mpB82YDKVIN(array $nC0lA) : self
    {
        $CVgg6 = array_flip(self::mPF8Fk5bXm4());
        return new self($nC0lA[$CVgg6['filename']] ?? $nC0lA['filename'] ?? '', $nC0lA[$CVgg6['fileExtension']] ?? $nC0lA['fileExtension'] ?? '', $nC0lA[$CVgg6['mimeType']] ?? $nC0lA['mimeType'] ?? '', $nC0lA[$CVgg6['fileSize']] ?? $nC0lA['fileSize'] ?? 0, $nC0lA[$CVgg6['chunkSize']] ?? $nC0lA['chunkSize'] ?? 0, $nC0lA[$CVgg6['checksums']] ?? $nC0lA['checksums'] ?? [], $nC0lA[$CVgg6['totalChunk']] ?? $nC0lA['totalChunk'] ?? 0, $nC0lA[$CVgg6['status']] ?? $nC0lA['status'] ?? 0, $nC0lA[$CVgg6['userId']] ?? $nC0lA['userId'] ?? 0, $nC0lA[$CVgg6['uploadId']] ?? $nC0lA['uploadId'] ?? '', $nC0lA[$CVgg6['driver']] ?? $nC0lA['driver'] ?? 's3', $nC0lA[$CVgg6['parts']] ?? $nC0lA['parts'] ?? []);
    }
    public static function mb0B4CHQcgE($E4bNU) : self
    {
        goto iM3PL;
        iM3PL:
        if (!(isset($E4bNU['fn']) || isset($E4bNU['fe']))) {
            goto EUgit;
        }
        goto AofRH;
        m11xq:
        EUgit:
        goto u_MWx;
        AofRH:
        return self::mpB82YDKVIN($E4bNU);
        goto m11xq;
        u_MWx:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto W6wWh;
        W6wWh:
    }
    public function m7PoIJeQDrB(string $gA0os) : void
    {
        $this->Q2m8A = $gA0os;
    }
    public function mUivlA2O4YU(array $cJl2t) : void
    {
        $this->JkyMk = $cJl2t;
    }
    public static function mJStkQvbmu8($nKKn0, $Vrpla, $NQRMF, $UVY53, $HZVGD, $GzTUV, $yXj4Q)
    {
        return new self($nKKn0->getFilename(), $nKKn0->getExtension(), $Vrpla, $NQRMF, $HZVGD, $GzTUV, count($GzTUV), O8RzIjGmSN6fG::UPLOADING, $UVY53, 0, $yXj4Q, []);
    }
    public static function mDgt4KXkAWr($PV4mw)
    {
        return 'metadata/' . $PV4mw . '.json';
    }
    public function mpmJbSjDsFB()
    {
        return 's3' === $this->rs3Zr ? GrPXtp41lLmde::S3 : GrPXtp41lLmde::LOCAL;
    }
}
