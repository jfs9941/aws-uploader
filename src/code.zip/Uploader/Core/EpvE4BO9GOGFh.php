<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\Observer\LCw0aGmgH8xAz;
use Jfs\Uploader\Core\YBVw3piEGeLeh;
use Jfs\Uploader\Core\Traits\UVNIQWCriSvDm;
use Jfs\Uploader\Core\Traits\Gwfgj7S32Yazt;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Exception\SlPIHqOmIQ9pI;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Exception\RlwRtWSVPtDAe;
use Jfs\Uploader\Service\QPQBXT5xv2KsY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class EpvE4BO9GOGFh implements N41GICKeJz2js
{
    use UVNIQWCriSvDm;
    use Gwfgj7S32Yazt;
    private $DNcMD;
    private function __construct($D55CH, $e3uVO)
    {
        $this->y_eVA = $D55CH;
        $this->Ty1Yq = $e3uVO;
    }
    private function mYjo5lCFZaT(string $wIlgi, $e3uVO, $cUbzi, bool $FFTQa = false) : void
    {
        $this->mQp3zHVoxcU(new LCw0aGmgH8xAz($this, $e3uVO, $cUbzi, $wIlgi, $FFTQa));
    }
    public function getFile()
    {
        return $this->y_eVA;
    }
    public function mTOWfJEsE4M(array $RaPrS) : void
    {
        $this->DNcMD = $RaPrS;
    }
    public function mqWgNNXI687() : void
    {
        $this->mKP20BPk5QC(Zgh3BZ2JVlG1A::UPLOADING);
    }
    public function mmizOPHltH3() : void
    {
        $this->mKP20BPk5QC(Zgh3BZ2JVlG1A::UPLOADED);
    }
    public function mGtG3lIWmKp() : void
    {
        $this->mKP20BPk5QC(Zgh3BZ2JVlG1A::PROCESSING);
    }
    public function mqqZNuBB0hr() : void
    {
        $this->mKP20BPk5QC(Zgh3BZ2JVlG1A::FINISHED);
    }
    public function m5HRMPd4c7L() : void
    {
        $this->mKP20BPk5QC(Zgh3BZ2JVlG1A::ABORTED);
    }
    public function m0SaDXylWqU() : array
    {
        return $this->DNcMD;
    }
    public static function m8pMRCYnNnN(string $iG1wy, $ksPxG, $KI4Gx, $wIlgi) : self
    {
        goto Zd4pB;
        wvRAJ:
        $QU011 = new self($D55CH, $ksPxG);
        goto oYW2A;
        oYW2A:
        $QU011->mYjo5lCFZaT($wIlgi, $ksPxG, $KI4Gx);
        goto YfZPq;
        KJluw:
        return $QU011->mMf66FZny9c();
        goto vI9zN;
        YfZPq:
        $QU011->mtNisNH4NQd(Zgh3BZ2JVlG1A::UPLOADING);
        goto KJluw;
        Zd4pB:
        $D55CH = App::make(QPQBXT5xv2KsY::class)->mpNfVM2pYHG(YBVw3piEGeLeh::mZxrgDE7C9E($iG1wy));
        goto wvRAJ;
        vI9zN:
    }
    public static function mrq8ZeUTURA($D55CH, $e3uVO, $cUbzi, $wIlgi, $FFTQa = false) : self
    {
        goto kxjIC;
        APwwP:
        return $QU011;
        goto iWyLx;
        t6qPh:
        $QU011->mtNisNH4NQd(Zgh3BZ2JVlG1A::UPLOADING);
        goto APwwP;
        RFtW8:
        $QU011->mYjo5lCFZaT($wIlgi, $e3uVO, $cUbzi, $FFTQa);
        goto t6qPh;
        kxjIC:
        $QU011 = new self($D55CH, $e3uVO);
        goto RFtW8;
        iWyLx:
    }
}
