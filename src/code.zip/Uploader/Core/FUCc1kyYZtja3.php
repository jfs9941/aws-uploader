<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Core\Observer\Bdt9eWxXcjNOA;
use Jfs\Uploader\Core\Traits\Tu7opFhr9ThYA;
use Jfs\Uploader\Core\Traits\AyFiTfhD6jOXL;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Exception\Z1EmnB00QcmrE;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Jfs\Uploader\Exception\KkJ7iB3slsUjq;
use Jfs\Uploader\Service\VRKkgi2bc4uRE;
final class FUCc1kyYZtja3 implements JGFha5eJXVoQK
{
    use Tu7opFhr9ThYA;
    use AyFiTfhD6jOXL;
    private $qo4dm;
    private function __construct($QuYzZ, $Q0hWX)
    {
        $this->nIFfY = $QuYzZ;
        $this->uaFPR = $Q0hWX;
    }
    private function mGUQV9JWosg(string $qir1P, $Q0hWX, $RdfoB, bool $CdLkE = false) : void
    {
        $this->mubjGF8zmdt(new Bdt9eWxXcjNOA($this, $Q0hWX, $RdfoB, $qir1P, $CdLkE));
    }
    public function getFile()
    {
        return $this->nIFfY;
    }
    public function mlNtTK4pngF(array $LT1aq) : void
    {
        $this->qo4dm = $LT1aq;
    }
    public function miBesHZJWLk() : void
    {
        $this->mVwoe0E3Z3I(QoCMzcKvH8Cw2::UPLOADING);
    }
    public function mmCSQPib4jl() : void
    {
        $this->mVwoe0E3Z3I(QoCMzcKvH8Cw2::UPLOADED);
    }
    public function mjSXa8Ftxu0() : void
    {
        $this->mVwoe0E3Z3I(QoCMzcKvH8Cw2::PROCESSING);
    }
    public function mBoWi6Q7mka() : void
    {
        $this->mVwoe0E3Z3I(QoCMzcKvH8Cw2::FINISHED);
    }
    public function mEkyhuJA3e0() : void
    {
        $this->mVwoe0E3Z3I(QoCMzcKvH8Cw2::ABORTED);
    }
    public function mz2SyXwjq0Q() : array
    {
        return $this->qo4dm;
    }
    public static function m4JkzRY3KVI(string $IaHim, $G29AT, $JhAxH, $qir1P) : self
    {
        goto V1FBh;
        zcTVZ:
        $mmk9B->mGUQV9JWosg($qir1P, $G29AT, $JhAxH);
        goto KEoHw;
        KEoHw:
        $mmk9B->mGG5zG7yPwR(QoCMzcKvH8Cw2::UPLOADING);
        goto qRMdG;
        V1FBh:
        $QuYzZ = App::make(VRKkgi2bc4uRE::class)->mZxcNvu3WfY(ZQCRUoYnm7ASE::mbbcEvheO3r($IaHim));
        goto PN9Df;
        qRMdG:
        return $mmk9B->mzzwcv0uqlO();
        goto Ov22l;
        PN9Df:
        $mmk9B = new self($QuYzZ, $G29AT);
        goto zcTVZ;
        Ov22l:
    }
    public static function mwh2q3yWrxX($QuYzZ, $Q0hWX, $RdfoB, $qir1P, $CdLkE = false) : self
    {
        goto JsqYX;
        HyDtt:
        $mmk9B->mGUQV9JWosg($qir1P, $Q0hWX, $RdfoB, $CdLkE);
        goto JLyFn;
        JLyFn:
        $mmk9B->mGG5zG7yPwR(QoCMzcKvH8Cw2::UPLOADING);
        goto L2l8p;
        L2l8p:
        return $mmk9B;
        goto dczbI;
        JsqYX:
        $mmk9B = new self($QuYzZ, $Q0hWX);
        goto HyDtt;
        dczbI:
    }
}
