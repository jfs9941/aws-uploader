<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Core\Traits\DE88el5C1yZlG;
use Jfs\Uploader\Core\Traits\J0nlGVgP1R1Ai;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Service\KWcrk2FVuq9pZ;
class SzJ0JuIDdEumD extends DMUaxGX7XHAI0 implements BCa3K9pPFzXM0
{
    use DE88el5C1yZlG;
    use J0nlGVgP1R1Ai;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $XKudI, string $KvyPo) : self
    {
        goto HK8ZP;
        HK8ZP:
        $A4sdE = new self(['id' => $XKudI, 'type' => $KvyPo, 'status' => EUkqoDwU9Zcvh::UPLOADING]);
        goto ZcxPK;
        rUvaX:
        return $A4sdE;
        goto UcB8e;
        ZcxPK:
        $A4sdE->m3B430t4QRf(EUkqoDwU9Zcvh::UPLOADING);
        goto rUvaX;
        UcB8e:
    }
    public function getView() : array
    {
        $d1dPQ = app(Yuf8dMzRcjZ21::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $d1dPQ->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $d1dPQ->resolveThumbnail($this)];
    }
    public static function mKOaENxjk3C(DMUaxGX7XHAI0 $hEivM) : SzJ0JuIDdEumD
    {
        goto h68np;
        bjPwi:
        return $hEivM;
        goto a36dc;
        a36dc:
        F1Vq0:
        goto pmnoM;
        pmnoM:
        return (new SzJ0JuIDdEumD())->fill($hEivM->getAttributes());
        goto py3TJ;
        h68np:
        if (!$hEivM instanceof SzJ0JuIDdEumD) {
            goto F1Vq0;
        }
        goto bjPwi;
        py3TJ:
    }
}
