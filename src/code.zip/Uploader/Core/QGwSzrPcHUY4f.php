<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; use Jfs\Uploader\Contracts\WrFez6oTdpaJs; use Jfs\Uploader\Contracts\PICYo9hgvioW3; use Jfs\Uploader\Core\Traits\WikDwhxDkMZ67; use Jfs\Uploader\Core\Traits\PVtMt2FkJYbaz; use Jfs\Uploader\Enum\FileStatus; use Jfs\Uploader\Service\CP7aCOgYEVsuX; class QGwSzrPcHUY4f extends J5wym0qxH1hlR implements WrFez6oTdpaJs { use WikDwhxDkMZ67; use PVtMt2FkJYbaz; public function getType() : string { return 'pdf'; } public static function createFromScratch(string $rOtzv, string $g7qa1) : self { goto sSNWf; GLYU0: $p9Rbq->mui5JkXMWEZ(FileStatus::UPLOADING); goto xdIrg; sSNWf: $p9Rbq = new self(['id' => $rOtzv, 'type' => $g7qa1, 'status' => FileStatus::UPLOADING]); goto GLYU0; xdIrg: return $p9Rbq; goto xgSS2; xgSS2: } public function getView() : array { $fY1BR = app(PICYo9hgvioW3::class); return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $fY1BR->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $fY1BR->resolveThumbnail($this)]; } public static function mbZbdvaFo8M(J5wym0qxH1hlR $fihHa) : QGwSzrPcHUY4f { goto EEWXs; EEWXs: if (!$fihHa instanceof QGwSzrPcHUY4f) { goto cisL1; } goto NAf_M; E1iYE: cisL1: goto JR9FS; JR9FS: return (new QGwSzrPcHUY4f())->fill($fihHa->getAttributes()); goto SdPM_; NAf_M: return $fihHa; goto E1iYE; SdPM_: } }
