<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\WG4kCv0INtCV4;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
final class Ex01fdHOlxlg8
{
    public $filename;
    public $b11vd;
    public $odzgM;
    public $bGpro;
    public $DR4yj;
    public $Gr1_Z;
    public $XqQ_r;
    public $status;
    public $Rkhdh;
    public $l9IH2;
    public $vZVzF = 's3';
    public $XvCZF = [];
    public function __construct($gX0Em, $flPmP, $iXTaP, $ljn0N, $Z1Mv0, $GuzHV, $EBA2F, $l_iIQ, $r35ul, $dXkPO, $doABn = 's3', $tFMn9 = [])
    {
        goto kC8vK;
        bE5PV:
        $this->XvCZF = $tFMn9;
        goto x5zYh;
        qbhj0:
        $this->vZVzF = $doABn;
        goto bE5PV;
        SbJLa:
        $this->bGpro = $ljn0N;
        goto dvM85;
        ZXZ8K:
        $this->Gr1_Z = $GuzHV;
        goto zjjyL;
        zjjyL:
        $this->XqQ_r = $EBA2F;
        goto HuqV8;
        D2PAp:
        $this->l9IH2 = $dXkPO;
        goto qbhj0;
        HuqV8:
        $this->status = $l_iIQ;
        goto FQOaz;
        T2s6p:
        $this->odzgM = $iXTaP;
        goto SbJLa;
        dvM85:
        $this->DR4yj = $Z1Mv0;
        goto ZXZ8K;
        FQOaz:
        $this->Rkhdh = $r35ul;
        goto D2PAp;
        kC8vK:
        $this->filename = $gX0Em;
        goto wi_8H;
        wi_8H:
        $this->b11vd = $flPmP;
        goto T2s6p;
        x5zYh:
    }
    private static function m9S3h2RKfgz() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mxokUxlH31I() : array
    {
        return array_flip(self::m9S3h2RKfgz());
    }
    public function toArray() : array
    {
        $Y0TrY = self::m9S3h2RKfgz();
        return [$Y0TrY['filename'] => $this->filename, $Y0TrY['fileExtension'] => $this->b11vd, $Y0TrY['mimeType'] => $this->odzgM, $Y0TrY['fileSize'] => $this->bGpro, $Y0TrY['chunkSize'] => $this->DR4yj, $Y0TrY['checksums'] => $this->Gr1_Z, $Y0TrY['totalChunk'] => $this->XqQ_r, $Y0TrY['status'] => $this->status, $Y0TrY['userId'] => $this->Rkhdh, $Y0TrY['uploadId'] => $this->l9IH2, $Y0TrY['driver'] => $this->vZVzF, $Y0TrY['parts'] => $this->XvCZF];
    }
    public static function m2TIW16VGh6(array $XAXGr) : self
    {
        $ZvhC2 = array_flip(self::mxokUxlH31I());
        return new self($XAXGr[$ZvhC2['filename']] ?? $XAXGr['filename'] ?? '', $XAXGr[$ZvhC2['fileExtension']] ?? $XAXGr['fileExtension'] ?? '', $XAXGr[$ZvhC2['mimeType']] ?? $XAXGr['mimeType'] ?? '', $XAXGr[$ZvhC2['fileSize']] ?? $XAXGr['fileSize'] ?? 0, $XAXGr[$ZvhC2['chunkSize']] ?? $XAXGr['chunkSize'] ?? 0, $XAXGr[$ZvhC2['checksums']] ?? $XAXGr['checksums'] ?? [], $XAXGr[$ZvhC2['totalChunk']] ?? $XAXGr['totalChunk'] ?? 0, $XAXGr[$ZvhC2['status']] ?? $XAXGr['status'] ?? 0, $XAXGr[$ZvhC2['userId']] ?? $XAXGr['userId'] ?? 0, $XAXGr[$ZvhC2['uploadId']] ?? $XAXGr['uploadId'] ?? '', $XAXGr[$ZvhC2['driver']] ?? $XAXGr['driver'] ?? 's3', $XAXGr[$ZvhC2['parts']] ?? $XAXGr['parts'] ?? []);
    }
    public static function mM0E1wVRoI2($Hkh0b) : self
    {
        goto nkUzn;
        pxwR_:
        u8Jyr:
        goto G_uYJ;
        nkUzn:
        if (!(isset($Hkh0b['fn']) || isset($Hkh0b['fe']))) {
            goto u8Jyr;
        }
        goto IbXrd;
        IbXrd:
        return self::m2TIW16VGh6($Hkh0b);
        goto pxwR_;
        G_uYJ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto bnnCg;
        bnnCg:
    }
    public function mv3G4OVCmSr(string $dXkPO) : void
    {
        $this->l9IH2 = $dXkPO;
    }
    public function mhQJzLNptS8(array $tFMn9) : void
    {
        $this->XvCZF = $tFMn9;
    }
    public static function m4l1CEyFXrB($a3XOL, $kE7Us, $UDn2T, $r35ul, $Z1Mv0, $GuzHV, $doABn)
    {
        return new self($a3XOL->getFilename(), $a3XOL->getExtension(), $kE7Us, $UDn2T, $Z1Mv0, $GuzHV, count($GuzHV), RwOJkCXwa9RQz::UPLOADING, $r35ul, 0, $doABn, []);
    }
    public static function mSfRKa26lA7($y06DH)
    {
        return 'metadata/' . $y06DH . '.json';
    }
    public function mwR4ZNqPtM8()
    {
        return 's3' === $this->vZVzF ? WG4kCv0INtCV4::S3 : WG4kCv0INtCV4::LOCAL;
    }
}
