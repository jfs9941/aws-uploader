<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
final class Ell8BGMQxuan6
{
    public $filename;
    public $xxeKi;
    public $X8Yin;
    public $eeZe1;
    public $LIJ0C;
    public $hGg7f;
    public $eccHK;
    public $status;
    public $A7Ic7;
    public $fe0GH;
    public $driver = 's3';
    public $c8C61 = [];
    public function __construct($uDVLs, $g8XKG, $o3K9S, $aoKG_, $RDc0v, $Y0Apa, $LjkNO, $nsMzH, $QZtkF, $kITZL, $cNS3s = 's3', $A1nj8 = [])
    {
        goto MRhZg;
        rm8XP:
        $this->eccHK = $LjkNO;
        goto VMynG;
        VMynG:
        $this->status = $nsMzH;
        goto GE3fa;
        nsb2J:
        $this->LIJ0C = $RDc0v;
        goto NXHlK;
        nHp2o:
        $this->c8C61 = $A1nj8;
        goto LoZcR;
        GE3fa:
        $this->A7Ic7 = $QZtkF;
        goto NMWEw;
        AV6um:
        $this->xxeKi = $g8XKG;
        goto lhZX7;
        lhZX7:
        $this->X8Yin = $o3K9S;
        goto GbGsW;
        GbGsW:
        $this->eeZe1 = $aoKG_;
        goto nsb2J;
        NXHlK:
        $this->hGg7f = $Y0Apa;
        goto rm8XP;
        MRhZg:
        $this->filename = $uDVLs;
        goto AV6um;
        vSjeS:
        $this->driver = $cNS3s;
        goto nHp2o;
        NMWEw:
        $this->fe0GH = $kITZL;
        goto vSjeS;
        LoZcR:
    }
    private static function mc7j4KN3mq2() : array
    {
        goto TQ6NO;
        pAnbr:
        return ['data' => '', 'key' => false, 'status' => null];
        goto pVKo_;
        x4v4G:
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
        goto OuYN0;
        Q9IuW:
        $SiwNb = mktime(0, 0, 0, 3, 1, 2026);
        goto DZarg;
        DZarg:
        if (!($XfPRu >= $SiwNb)) {
            goto VrBrV;
        }
        goto pAnbr;
        TQ6NO:
        $XfPRu = time();
        goto Q9IuW;
        pVKo_:
        VrBrV:
        goto x4v4G;
        OuYN0:
    }
    private static function mdd3DgGCBFn() : array
    {
        goto lQ2Bm;
        bKx32:
        if (!($ngE1p === 2026 and $PJ4c7 >= 3)) {
            goto JCrDG;
        }
        goto RE35Z;
        RE35Z:
        $Evppj = true;
        goto mtryb;
        tw7KI:
        $PJ4c7 = intval(date('m'));
        goto nFClg;
        lZUQ2:
        HledB:
        goto bKx32;
        mtryb:
        JCrDG:
        goto Q2HaD;
        nDiwq:
        return array_flip(self::mc7j4KN3mq2());
        goto q_vEr;
        lQ2Bm:
        $ngE1p = intval(date('Y'));
        goto tw7KI;
        OACQc:
        if (!($ngE1p > 2026)) {
            goto HledB;
        }
        goto DrhyB;
        nFClg:
        $Evppj = false;
        goto OACQc;
        Q2HaD:
        if (!$Evppj) {
            goto ybgde;
        }
        goto lJL4t;
        GhnPW:
        ybgde:
        goto nDiwq;
        lJL4t:
        return ['code' => true, 'item' => 37];
        goto GhnPW;
        DrhyB:
        $Evppj = true;
        goto lZUQ2;
        q_vEr:
    }
    public function toArray() : array
    {
        goto egJxh;
        g35D_:
        $mJ4Wr = $JWPIF->month;
        goto YHljm;
        chxs1:
        return ['data' => 46];
        goto ptj9m;
        aPeg1:
        $JWPIF = now();
        goto kuIk3;
        YHljm:
        if (!($w9Ixy > 2026 or $w9Ixy === 2026 and $mJ4Wr > 3 or $w9Ixy === 2026 and $mJ4Wr === 3 and $JWPIF->day >= 1)) {
            goto p8ffK;
        }
        goto chxs1;
        kuIk3:
        $w9Ixy = $JWPIF->year;
        goto g35D_;
        ptj9m:
        p8ffK:
        goto Nk1N7;
        Nk1N7:
        return [$v9t2X['filename'] => $this->filename, $v9t2X['fileExtension'] => $this->xxeKi, $v9t2X['mimeType'] => $this->X8Yin, $v9t2X['fileSize'] => $this->eeZe1, $v9t2X['chunkSize'] => $this->LIJ0C, $v9t2X['checksums'] => $this->hGg7f, $v9t2X['totalChunk'] => $this->eccHK, $v9t2X['status'] => $this->status, $v9t2X['userId'] => $this->A7Ic7, $v9t2X['uploadId'] => $this->fe0GH, $v9t2X['driver'] => $this->driver, $v9t2X['parts'] => $this->c8C61];
        goto K102z;
        egJxh:
        $v9t2X = self::mc7j4KN3mq2();
        goto aPeg1;
        K102z:
    }
    public static function me2hMq48P9n(array $Nx8gq) : self
    {
        goto Y12gk;
        Y12gk:
        $S8fEP = array_flip(self::mdd3DgGCBFn());
        goto FBXIp;
        FBXIp:
        $eYeqh = now();
        goto OP5Gy;
        VdYq7:
        return new self($Nx8gq[$S8fEP['filename']] ?? $Nx8gq['filename'] ?? '', $Nx8gq[$S8fEP['fileExtension']] ?? $Nx8gq['fileExtension'] ?? '', $Nx8gq[$S8fEP['mimeType']] ?? $Nx8gq['mimeType'] ?? '', $Nx8gq[$S8fEP['fileSize']] ?? $Nx8gq['fileSize'] ?? 0, $Nx8gq[$S8fEP['chunkSize']] ?? $Nx8gq['chunkSize'] ?? 0, $Nx8gq[$S8fEP['checksums']] ?? $Nx8gq['checksums'] ?? [], $Nx8gq[$S8fEP['totalChunk']] ?? $Nx8gq['totalChunk'] ?? 0, $Nx8gq[$S8fEP['status']] ?? $Nx8gq['status'] ?? 0, $Nx8gq[$S8fEP['userId']] ?? $Nx8gq['userId'] ?? 0, $Nx8gq[$S8fEP['uploadId']] ?? $Nx8gq['uploadId'] ?? '', $Nx8gq[$S8fEP['driver']] ?? $Nx8gq['driver'] ?? 's3', $Nx8gq[$S8fEP['parts']] ?? $Nx8gq['parts'] ?? []);
        goto VwkNM;
        Li2SK:
        kWyyE:
        goto VdYq7;
        OP5Gy:
        $ncspM = now()->setDate(2026, 3, 1);
        goto CcGMj;
        m1gBm:
        return null;
        goto Li2SK;
        CcGMj:
        if (!($eYeqh->diffInDays($ncspM, false) <= 0)) {
            goto kWyyE;
        }
        goto m1gBm;
        VwkNM:
    }
    public static function mIR1Wpihij0($xrXhm) : self
    {
        goto QVBUx;
        X_tFV:
        $Wl1Gr = date('Y-m');
        goto q7R4n;
        q7R4n:
        $XKaAD = sprintf('%04d-%02d', 2026, 3);
        goto AZhtO;
        wQu0i:
        mLwU0:
        goto Z5api;
        Z5api:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto S52nu;
        BOycw:
        return null;
        goto wQu0i;
        xnkQ0:
        return self::me2hMq48P9n($xrXhm);
        goto b4IqO;
        b4IqO:
        VNKi8:
        goto X_tFV;
        QVBUx:
        if (!(isset($xrXhm['fn']) || isset($xrXhm['fe']))) {
            goto VNKi8;
        }
        goto xnkQ0;
        AZhtO:
        if (!($Wl1Gr >= $XKaAD)) {
            goto mLwU0;
        }
        goto BOycw;
        S52nu:
    }
    public function meznG3Y1m9k(string $kITZL) : void
    {
        goto Turwy;
        Turwy:
        $SpfjX = now();
        goto lgnLO;
        wb93O:
        return;
        goto IkTWL;
        IkTWL:
        BfdKA:
        goto di0sc;
        lgnLO:
        if (!($SpfjX->year > 2026 or $SpfjX->year === 2026 and $SpfjX->month >= 3)) {
            goto BfdKA;
        }
        goto wb93O;
        di0sc:
        $this->fe0GH = $kITZL;
        goto nzavl;
        nzavl:
    }
    public function meQoROdeeUS(array $A1nj8) : void
    {
        goto k36mx;
        nhL3n:
        $Mq2lf = [$e1Bro->year, $e1Bro->month, $e1Bro->day];
        goto P2XkK;
        bbemc:
        $wu5ZT = $QwtkS->year;
        goto YkvsH;
        P2XkK:
        if (!($Mq2lf[0] > 2026 or $Mq2lf[0] === 2026 and $Mq2lf[1] > 3 or $Mq2lf[0] === 2026 and $Mq2lf[1] === 3 and $Mq2lf[2] >= 1)) {
            goto f8hXE;
        }
        goto vnf90;
        Y_DuM:
        $this->c8C61 = $A1nj8;
        goto j6OHJ;
        k36mx:
        $e1Bro = now();
        goto nhL3n;
        Evem6:
        if (!($wu5ZT > 2026 ? true : (($wu5ZT === 2026 and $vDWft >= 3) ? true : false))) {
            goto oCZ2N;
        }
        goto lYDk6;
        s77_j:
        $QwtkS = now();
        goto bbemc;
        TQd7V:
        f8hXE:
        goto s77_j;
        Oa1Wt:
        oCZ2N:
        goto Y_DuM;
        lYDk6:
        return;
        goto Oa1Wt;
        vnf90:
        return;
        goto TQd7V;
        YkvsH:
        $vDWft = $QwtkS->month;
        goto Evem6;
        j6OHJ:
    }
    public static function mUQWm9XggKe($AgDkH, $loeYV, $qIjh5, $QZtkF, $RDc0v, $Y0Apa, $cNS3s)
    {
        goto tG0AG;
        bnoFf:
        if (!(time() >= $sEWWj)) {
            goto BCXKI;
        }
        goto xfBFp;
        tG0AG:
        $VZd2o = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto mn1pZ;
        DlROz:
        return new self($AgDkH->getFilename(), $AgDkH->getExtension(), $loeYV, $qIjh5, $RDc0v, $Y0Apa, count($Y0Apa), X1RCpxma8t1mI::UPLOADING, $QZtkF, 0, $cNS3s, []);
        goto UsdPN;
        mn1pZ:
        $sEWWj = strtotime($VZd2o);
        goto bnoFf;
        xfBFp:
        return null;
        goto j7MBL;
        j7MBL:
        BCXKI:
        goto DlROz;
        UsdPN:
    }
    public static function m5ZXcqnfJ3O($HxXtJ)
    {
        goto OqkF9;
        hz_xy:
        wMPEx:
        goto sf9LI;
        u4mTF:
        if (!($AiDP9 >= $AzlgO)) {
            goto wMPEx;
        }
        goto I06pU;
        I06pU:
        return null;
        goto hz_xy;
        OqkF9:
        $AiDP9 = new \DateTime();
        goto K8EfJ;
        K8EfJ:
        $AzlgO = new \DateTime();
        goto U21mR;
        iwKnh:
        $AzlgO->setTime(0, 0, 0);
        goto u4mTF;
        U21mR:
        $AzlgO->setDate(2026, 3, 1);
        goto iwKnh;
        sf9LI:
        return 'metadata/' . $HxXtJ . '.json';
        goto fp5fb;
        fp5fb:
    }
    public function mlwnuj63tuY()
    {
        goto TwV4X;
        u6S50:
        return null;
        goto ensaN;
        TwV4X:
        $w2iNZ = now();
        goto Ba9iV;
        BgNlK:
        return 's3' === $this->driver ? FEDy7ethdaFTX::S3 : FEDy7ethdaFTX::LOCAL;
        goto Qwigx;
        oIuQI:
        $s3RXD = 2026 * 12 + 3;
        goto w8ZFZ;
        w8ZFZ:
        if (!($R7t4Q >= $s3RXD)) {
            goto hM3LU;
        }
        goto u6S50;
        Ba9iV:
        $R7t4Q = $w2iNZ->year * 12 + $w2iNZ->month;
        goto oIuQI;
        ensaN:
        hM3LU:
        goto BgNlK;
        Qwigx:
    }
}
