<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Contracts\VdjamMvtIkwfN;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\Traits\U1oUBtFUca4cm;
use Jfs\Uploader\Core\Traits\GYCzFqUkUYdjE;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Service\BA8ePy1ftd8cO;
class GPZ0EQoHpj04q extends VMj30iBgKeeJB implements SOB6nK7CGVegh
{
    use U1oUBtFUca4cm;
    use GYCzFqUkUYdjE;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $xRxub, string $Lmvwp) : self
    {
        goto jKlBs;
        fn89w:
        $wn49p->mUg6EMktQTd(Xy3InMky6jKYf::UPLOADING);
        goto Y8h_N;
        Y8h_N:
        return $wn49p;
        goto tsP08;
        jKlBs:
        $wn49p = new self(['id' => $xRxub, 'type' => $Lmvwp, 'status' => Xy3InMky6jKYf::UPLOADING]);
        goto fn89w;
        tsP08:
    }
    public function getView() : array
    {
        $FSDPH = app(VdjamMvtIkwfN::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $FSDPH->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $FSDPH->resolveThumbnail($this)];
    }
    public static function mU6lTk6bgNz(VMj30iBgKeeJB $XcVxI) : GPZ0EQoHpj04q
    {
        goto F8mbH;
        gJTu7:
        Wy6iA:
        goto YdYkW;
        YdYkW:
        return (new GPZ0EQoHpj04q())->fill($XcVxI->getAttributes());
        goto wEy47;
        F8mbH:
        if (!$XcVxI instanceof GPZ0EQoHpj04q) {
            goto Wy6iA;
        }
        goto ET0w9;
        ET0w9:
        return $XcVxI;
        goto gJTu7;
        wEy47:
    }
}
