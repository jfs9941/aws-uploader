<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Core\Traits\E2oUjXwrsjJZQ;
use Jfs\Uploader\Core\Traits\AyFiTfhD6jOXL;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Service\QBWgN1d5cwk0P;
class TXSCPefqEsBH1 extends GuA6QuvssLUzf implements JGFha5eJXVoQK
{
    use E2oUjXwrsjJZQ;
    use AyFiTfhD6jOXL;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $YIAds, string $poyPD) : self
    {
        goto P_7u0;
        I7ZmX:
        $A8uam->mGG5zG7yPwR(QoCMzcKvH8Cw2::UPLOADING);
        goto x3knJ;
        P_7u0:
        $A8uam = new self(['id' => $YIAds, 'type' => $poyPD, 'status' => QoCMzcKvH8Cw2::UPLOADING]);
        goto I7ZmX;
        x3knJ:
        return $A8uam;
        goto Af_K9;
        Af_K9:
    }
    public function getView() : array
    {
        $SMQC2 = app(HqWA5DdMiDW1U::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $SMQC2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $SMQC2->resolveThumbnail($this)];
    }
    public static function mIB5KzrWEj7(GuA6QuvssLUzf $nNNVD) : TXSCPefqEsBH1
    {
        goto nmZ9C;
        dxLU1:
        Gso4r:
        goto U5yJK;
        nmZ9C:
        if (!$nNNVD instanceof TXSCPefqEsBH1) {
            goto Gso4r;
        }
        goto tvl5d;
        U5yJK:
        return (new TXSCPefqEsBH1())->fill($nNNVD->getAttributes());
        goto OCbEa;
        tvl5d:
        return $nNNVD;
        goto dxLU1;
        OCbEa:
    }
}
