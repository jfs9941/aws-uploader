<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Contracts\NTBMTa29AeaJq;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\Traits\A6wERosUOJgWZ;
use backup\Uploader\Core\Traits\Fk7u5grtM5kGF;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Service\QHNWNb4yKCpvh;
class OzgWWRogA2eJF extends PJqa0Yy2jwBHe implements VnrpqIkXJe1mn
{
    use A6wERosUOJgWZ;
    use Fk7u5grtM5kGF;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $IMDKn, string $ISfDH) : self
    {
        goto YmMQZ;
        YmMQZ:
        $GRGwt = new self(['id' => $IMDKn, 'type' => $ISfDH, 'status' => Aetm2HiFuJE34::UPLOADING]);
        goto pwDHn;
        lowaF:
        return $GRGwt;
        goto cEK5q;
        pwDHn:
        $GRGwt->mV7ZhSMguWB(Aetm2HiFuJE34::UPLOADING);
        goto lowaF;
        cEK5q:
    }
    public function getView() : array
    {
        $ddgk2 = app(NTBMTa29AeaJq::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $ddgk2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $ddgk2->resolveThumbnail($this)];
    }
    public static function mqoxxfip02F(PJqa0Yy2jwBHe $JFGfH) : OzgWWRogA2eJF
    {
        goto FN2IR;
        ApXdL:
        return $JFGfH;
        goto FEyjW;
        FEyjW:
        TjzRU:
        goto Ed2DP;
        Ed2DP:
        return (new OzgWWRogA2eJF())->fill($JFGfH->getAttributes());
        goto EzhZ0;
        FN2IR:
        if (!$JFGfH instanceof OzgWWRogA2eJF) {
            goto TjzRU;
        }
        goto ApXdL;
        EzhZ0:
    }
}
