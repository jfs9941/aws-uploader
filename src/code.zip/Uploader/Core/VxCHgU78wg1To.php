<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\Observer\SEO3V0HfirU17;
use Jfs\Uploader\Core\QeUknjvnDpCFf;
use Jfs\Uploader\Core\Traits\LNmUl22uAPXpw;
use Jfs\Uploader\Core\Traits\WbbiNrJy3XNAD;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Exception\VwJ7WJWdWWDDp;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Exception\B3AeVUIqKwlr4;
use Jfs\Uploader\Service\UG0KhqkrdbP7y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class VxCHgU78wg1To implements QguGxHrrpjTia
{
    use LNmUl22uAPXpw;
    use WbbiNrJy3XNAD;
    private $QSAwm;
    private function __construct($s2INV, $Ape3_)
    {
        $this->VbAbt = $s2INV;
        $this->KoMr1 = $Ape3_;
    }
    private function m8jEXCH3iZp(string $wiZGO, $Ape3_, $Dm30C, bool $oG71L = false) : void
    {
        $this->m8X5yYN5PxJ(new SEO3V0HfirU17($this, $Ape3_, $Dm30C, $wiZGO, $oG71L));
    }
    public function getFile()
    {
        return $this->VbAbt;
    }
    public function mYxiThMveVg(array $WpDNo) : void
    {
        $this->QSAwm = $WpDNo;
    }
    public function mUDGSa6H1gD() : void
    {
        $this->mImL6eGj9Ei(IOEDyer18cpSA::UPLOADING);
    }
    public function mDoXvmsg17o() : void
    {
        $this->mImL6eGj9Ei(IOEDyer18cpSA::UPLOADED);
    }
    public function mhuIi5rAodZ() : void
    {
        $this->mImL6eGj9Ei(IOEDyer18cpSA::PROCESSING);
    }
    public function muVkUevgapd() : void
    {
        $this->mImL6eGj9Ei(IOEDyer18cpSA::FINISHED);
    }
    public function mNhdxZgLIOC() : void
    {
        $this->mImL6eGj9Ei(IOEDyer18cpSA::ABORTED);
    }
    public function mhgeh6QrYq1() : array
    {
        return $this->QSAwm;
    }
    public static function migKxo4kk5f(string $aK0gt, $MOo_o, $ejImE, $wiZGO) : self
    {
        goto CzL5S;
        q5qAy:
        $PaQkf->mC8nuYteIk4(IOEDyer18cpSA::UPLOADING);
        goto RmhMy;
        g5GuC:
        $PaQkf = new self($s2INV, $MOo_o);
        goto wafbi;
        RmhMy:
        return $PaQkf->mFgDIJ3dLlF();
        goto Ag0Yj;
        CzL5S:
        $s2INV = App::make(UG0KhqkrdbP7y::class)->mxX6QwgrEaW(QeUknjvnDpCFf::mSDllKAeQ1h($aK0gt));
        goto g5GuC;
        wafbi:
        $PaQkf->m8jEXCH3iZp($wiZGO, $MOo_o, $ejImE);
        goto q5qAy;
        Ag0Yj:
    }
    public static function maXmMkbjItR($s2INV, $Ape3_, $Dm30C, $wiZGO, $oG71L = false) : self
    {
        goto TamGp;
        s9An4:
        $PaQkf->mC8nuYteIk4(IOEDyer18cpSA::UPLOADING);
        goto dHYoa;
        TamGp:
        $PaQkf = new self($s2INV, $Ape3_);
        goto qVXj5;
        dHYoa:
        return $PaQkf;
        goto ye7Zh;
        qVXj5:
        $PaQkf->m8jEXCH3iZp($wiZGO, $Ape3_, $Dm30C, $oG71L);
        goto s9An4;
        ye7Zh:
    }
}
