<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
final class LwEuADzdXxX43
{
    public $filename;
    public $zFvPC;
    public $MbqgQ;
    public $hYBql;
    public $ditJT;
    public $Phl0_;
    public $e1fBk;
    public $status;
    public $A4G4G;
    public $cgWhy;
    public $tl1PH = 's3';
    public $u0a6G = [];
    public function __construct($rCYsa, $lxg_s, $SaFLV, $EcyuN, $P42U_, $qG1CG, $Hjp23, $vhTb2, $NnyAX, $y_u0V, $hCnVR = 's3', $bLIUr = [])
    {
        goto vVg5f;
        ma0Zh:
        $this->cgWhy = $y_u0V;
        goto pCEUS;
        yDrwy:
        $this->ditJT = $P42U_;
        goto wEq25;
        o2tAe:
        $this->A4G4G = $NnyAX;
        goto ma0Zh;
        JrDaC:
        $this->zFvPC = $lxg_s;
        goto jT6JE;
        wEq25:
        $this->Phl0_ = $qG1CG;
        goto GXzrU;
        vVg5f:
        $this->filename = $rCYsa;
        goto JrDaC;
        Jh33f:
        $this->u0a6G = $bLIUr;
        goto zTtvv;
        Fi1u6:
        $this->hYBql = $EcyuN;
        goto yDrwy;
        O4QYi:
        $this->status = $vhTb2;
        goto o2tAe;
        jT6JE:
        $this->MbqgQ = $SaFLV;
        goto Fi1u6;
        pCEUS:
        $this->tl1PH = $hCnVR;
        goto Jh33f;
        GXzrU:
        $this->e1fBk = $Hjp23;
        goto O4QYi;
        zTtvv:
    }
    private static function mJoOqYhDNAt() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function m0gtLPzCyyT() : array
    {
        return array_flip(self::mJoOqYhDNAt());
    }
    public function toArray() : array
    {
        $C0MmW = self::mJoOqYhDNAt();
        return [$C0MmW['filename'] => $this->filename, $C0MmW['fileExtension'] => $this->zFvPC, $C0MmW['mimeType'] => $this->MbqgQ, $C0MmW['fileSize'] => $this->hYBql, $C0MmW['chunkSize'] => $this->ditJT, $C0MmW['checksums'] => $this->Phl0_, $C0MmW['totalChunk'] => $this->e1fBk, $C0MmW['status'] => $this->status, $C0MmW['userId'] => $this->A4G4G, $C0MmW['uploadId'] => $this->cgWhy, $C0MmW['driver'] => $this->tl1PH, $C0MmW['parts'] => $this->u0a6G];
    }
    public static function mt5WpLsIZZh(array $jFT7D) : self
    {
        $KZMX2 = array_flip(self::m0gtLPzCyyT());
        return new self($jFT7D[$KZMX2['filename']] ?? $jFT7D['filename'] ?? '', $jFT7D[$KZMX2['fileExtension']] ?? $jFT7D['fileExtension'] ?? '', $jFT7D[$KZMX2['mimeType']] ?? $jFT7D['mimeType'] ?? '', $jFT7D[$KZMX2['fileSize']] ?? $jFT7D['fileSize'] ?? 0, $jFT7D[$KZMX2['chunkSize']] ?? $jFT7D['chunkSize'] ?? 0, $jFT7D[$KZMX2['checksums']] ?? $jFT7D['checksums'] ?? [], $jFT7D[$KZMX2['totalChunk']] ?? $jFT7D['totalChunk'] ?? 0, $jFT7D[$KZMX2['status']] ?? $jFT7D['status'] ?? 0, $jFT7D[$KZMX2['userId']] ?? $jFT7D['userId'] ?? 0, $jFT7D[$KZMX2['uploadId']] ?? $jFT7D['uploadId'] ?? '', $jFT7D[$KZMX2['driver']] ?? $jFT7D['driver'] ?? 's3', $jFT7D[$KZMX2['parts']] ?? $jFT7D['parts'] ?? []);
    }
    public static function mgaobc77vO7($q4dGR) : self
    {
        goto VwE2F;
        VwE2F:
        if (!(isset($q4dGR['fn']) || isset($q4dGR['fe']))) {
            goto l90T0;
        }
        goto q01_l;
        RRazG:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto L9EYC;
        q01_l:
        return self::mt5WpLsIZZh($q4dGR);
        goto CWgeQ;
        CWgeQ:
        l90T0:
        goto RRazG;
        L9EYC:
    }
    public function m4dvFVAPIAN(string $y_u0V) : void
    {
        $this->cgWhy = $y_u0V;
    }
    public function mwcq8pQL0f2(array $bLIUr) : void
    {
        $this->u0a6G = $bLIUr;
    }
    public static function mPfgtMh51KH($I2SbP, $EiWMT, $bBO7s, $NnyAX, $P42U_, $qG1CG, $hCnVR)
    {
        return new self($I2SbP->getFilename(), $I2SbP->getExtension(), $EiWMT, $bBO7s, $P42U_, $qG1CG, count($qG1CG), EPmxqTVp5luXc::UPLOADING, $NnyAX, 0, $hCnVR, []);
    }
    public static function m16Obv6eGzx($FILUb)
    {
        return 'metadata/' . $FILUb . '.json';
    }
    public function myxGNaRTrut()
    {
        return 's3' === $this->tl1PH ? N0ISad2bKF2Yp::S3 : N0ISad2bKF2Yp::LOCAL;
    }
}
