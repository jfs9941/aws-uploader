<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core;

use src\Uploader\Contracts\MGwfEiRGIYlUs;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\Traits\GGdwEU4dd3qMI;
use src\Uploader\Core\Traits\NURFewLmHDDb8;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Enum\FileStatus;
class YdClVYDRbSDMR extends TvpGfrAj9WMXE implements PxmUcH2EZiEWo
{
    use GGdwEU4dd3qMI;
    use NURFewLmHDDb8;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $rHgUV, string $cvjX2) : self
    {
        goto Wlra8;
        Wlra8:
        $iit8z = new self(['id' => $rHgUV, 'type' => $cvjX2, 'status' => FileStatus::UPLOADING]);
        goto XMCtg;
        XMCtg:
        $iit8z->mRGXJFOfzBv(FileStatus::UPLOADING);
        goto S50Jb;
        S50Jb:
        return $iit8z;
        goto y9gXL;
        y9gXL:
    }
    public function width() : ?int
    {
        goto AdjA3;
        AdjA3:
        $Lu5LP = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto arcj0;
        arcj0:
        if (!$Lu5LP) {
            goto V16Ny;
        }
        goto vvWFT;
        vvWFT:
        return $Lu5LP;
        goto tTLAb;
        tTLAb:
        V16Ny:
        goto UErOI;
        UErOI:
        return null;
        goto mR_To;
        mR_To:
    }
    public function height() : ?int
    {
        goto nQimq;
        VzDeL:
        return null;
        goto FtlXe;
        tDJd1:
        x_vcU:
        goto VzDeL;
        nHYhx:
        if (!$IPfYY) {
            goto x_vcU;
        }
        goto u8tBl;
        u8tBl:
        return $IPfYY;
        goto tDJd1;
        nQimq:
        $IPfYY = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto nHYhx;
        FtlXe:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($iit8z) {
            goto dTMLV;
            dTMLV:
            $TYpK7 = $iit8z->getDirty();
            goto bMvJs;
            GTTnk:
            fotz1:
            goto qMFbv;
            bMvJs:
            if (!(!array_key_exists('thumbnail', $TYpK7) && !array_key_exists('hls_path', $TYpK7))) {
                goto fotz1;
            }
            goto ALsfv;
            qMFbv:
            if (!($TYpK7['thumbnail'] || $TYpK7['hls_path'])) {
                goto KpPb2;
            }
            goto JNezH;
            ALsfv:
            return;
            goto GTTnk;
            HjQni:
            KpPb2:
            goto D9M_5;
            JNezH:
            YdClVYDRbSDMR::where('parent_id', $iit8z->getAttribute('id'))->update(['thumbnail' => $iit8z->getAttributes()['thumbnail'], 'hls_path' => $iit8z->getAttributes()['hls_path']]);
            goto HjQni;
            D9M_5:
        });
    }
    public function m0kz1rWtUSI()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mk7BRM31PDB()
    {
        return $this->getAttribute('id');
    }
    public function mb79LXbe2H3() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto grjtl;
        grjtl:
        $LMUnW = app(MGwfEiRGIYlUs::class);
        goto TDD5U;
        On72V:
        return $S62kT;
        goto m5uus;
        TDD5U:
        $S62kT = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $LMUnW->resolvePath($this, $this->getAttribute('driver'))];
        goto BwTmA;
        jmr85:
        $S62kT['thumbnail'] = $LMUnW->resolveThumbnail($this);
        goto On72V;
        fBzMJ:
        hf6o2:
        goto S7xYi;
        HSXGC:
        goto bwbJQ;
        goto fBzMJ;
        S7xYi:
        $S62kT['player_url'] = $LMUnW->resolvePathForHlsVideo($this, true);
        goto XWP_I;
        fwbjY:
        $S62kT['player_url'] = $LMUnW->resolvePath($this, $this->getAttribute('driver'));
        goto HSXGC;
        BwTmA:
        if ($this->getAttribute('hls_path')) {
            goto hf6o2;
        }
        goto fwbjY;
        XWP_I:
        bwbJQ:
        goto jmr85;
        m5uus:
    }
    public function getThumbnails()
    {
        goto jpTGX;
        jpTGX:
        $RbK4Z = $this->getAttribute('generated_previews') ?? [];
        goto LndMJ;
        AEPYq:
        return array_map(function ($pIzqs) use($LMUnW) {
            return $LMUnW->resolvePath($pIzqs);
        }, $RbK4Z);
        goto P_cyb;
        LndMJ:
        $LMUnW = app(MGwfEiRGIYlUs::class);
        goto AEPYq;
        P_cyb:
    }
    public static function m9suzflhhQ7(TvpGfrAj9WMXE $jVT23) : YdClVYDRbSDMR
    {
        goto CX6QS;
        CX6QS:
        if (!$jVT23 instanceof YdClVYDRbSDMR) {
            goto FXkWR;
        }
        goto i3p3q;
        cZRXO:
        return (new YdClVYDRbSDMR())->fill($jVT23->getAttributes());
        goto veJcm;
        THqZi:
        FXkWR:
        goto cZRXO;
        i3p3q:
        return $jVT23;
        goto THqZi;
        veJcm:
    }
}
