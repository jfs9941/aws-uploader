<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Contracts\Dm945121dFKVW;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\Traits\EpBhYo5NrILTt;
use Jfs\Uploader\Core\Traits\LkAAxyhGgmAFk;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
class U9HMl0N8dP0ZH extends Zl4rdW32ufaUx implements FTr6mgGRFf157
{
    use EpBhYo5NrILTt;
    use LkAAxyhGgmAFk;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $FIM0D, string $EE6bd) : self
    {
        goto Jndrl;
        qtIeX:
        return $QCHmE;
        goto u0VqS;
        RtQtc:
        $QCHmE->mHWfC8guF82(LV0wDYHZInswq::UPLOADING);
        goto qtIeX;
        Jndrl:
        $QCHmE = new self(['id' => $FIM0D, 'type' => $EE6bd, 'status' => LV0wDYHZInswq::UPLOADING]);
        goto RtQtc;
        u0VqS:
    }
    public function width() : ?int
    {
        goto feb3B;
        nF1wL:
        return null;
        goto DuzKa;
        nkUwE:
        if (!$BKFYC) {
            goto KtomX;
        }
        goto QZc2_;
        CcS9M:
        KtomX:
        goto nF1wL;
        feb3B:
        $BKFYC = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto nkUwE;
        QZc2_:
        return $BKFYC;
        goto CcS9M;
        DuzKa:
    }
    public function height() : ?int
    {
        goto xD8Zq;
        DksXC:
        sMbLC:
        goto eUxEA;
        eao4M:
        if (!$ZDe2g) {
            goto sMbLC;
        }
        goto pO5OD;
        eUxEA:
        return null;
        goto sAVIa;
        pO5OD:
        return $ZDe2g;
        goto DksXC;
        xD8Zq:
        $ZDe2g = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto eao4M;
        sAVIa:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($QCHmE) {
            goto qG7mW;
            V2mY6:
            if (!($Aivpp['thumbnail'] || $Aivpp['hls_path'])) {
                goto AK5D9;
            }
            goto J7ocq;
            J7ocq:
            U9HMl0N8dP0ZH::where('parent_id', $QCHmE->getAttribute('id'))->update(['thumbnail' => $QCHmE->getAttributes()['thumbnail'], 'hls_path' => $QCHmE->getAttributes()['hls_path']]);
            goto Go29E;
            qG7mW:
            $Aivpp = $QCHmE->getDirty();
            goto tLJ0_;
            Go29E:
            AK5D9:
            goto FbJJH;
            Ud7rz:
            FO_Ek:
            goto V2mY6;
            tLJ0_:
            if (!(!array_key_exists('thumbnail', $Aivpp) && !array_key_exists('hls_path', $Aivpp))) {
                goto FO_Ek;
            }
            goto JHVNJ;
            JHVNJ:
            return;
            goto Ud7rz;
            FbJJH:
        });
    }
    public function mP749yL4tV1()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mWRuO8vEofh()
    {
        return $this->getAttribute('id');
    }
    public function mrmperSQ6nG() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto phO6t;
        H5Ow6:
        SEUjh:
        goto ShLu6;
        jNcB2:
        $Wg92u['thumbnail'] = $Y_PMr->resolveThumbnail($this);
        goto DTgQM;
        iW0f1:
        IcUdL:
        goto jNcB2;
        phO6t:
        $Y_PMr = app(Dm945121dFKVW::class);
        goto zQ01g;
        DTgQM:
        return $Wg92u;
        goto aIAAf;
        PLK7E:
        goto IcUdL;
        goto H5Ow6;
        zQ01g:
        $Wg92u = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $Y_PMr->resolvePath($this, $this->getAttribute('driver'))];
        goto ziio0;
        ShLu6:
        $Wg92u['player_url'] = $Y_PMr->resolvePathForHlsVideo($this, true);
        goto iW0f1;
        ziio0:
        if ($this->getAttribute('hls_path')) {
            goto SEUjh;
        }
        goto S4Gph;
        S4Gph:
        $Wg92u['player_url'] = $Y_PMr->resolvePath($this, $this->getAttribute('driver'));
        goto PLK7E;
        aIAAf:
    }
    public function getThumbnails()
    {
        goto s7SKX;
        z6vEC:
        return array_map(function ($i7XwP) use($Y_PMr) {
            return $Y_PMr->resolvePath($i7XwP);
        }, $YgQcg);
        goto pNepg;
        kopzK:
        $Y_PMr = app(Dm945121dFKVW::class);
        goto z6vEC;
        s7SKX:
        $YgQcg = $this->getAttribute('generated_previews') ?? [];
        goto kopzK;
        pNepg:
    }
    public static function mxCkMxMEFEn(Zl4rdW32ufaUx $vPecg) : U9HMl0N8dP0ZH
    {
        goto KBp4I;
        KBp4I:
        if (!$vPecg instanceof U9HMl0N8dP0ZH) {
            goto jGbU_;
        }
        goto g_m5i;
        g_m5i:
        return $vPecg;
        goto qAkUS;
        qAkUS:
        jGbU_:
        goto qQ1W1;
        qQ1W1:
        return (new U9HMl0N8dP0ZH())->fill($vPecg->getAttributes());
        goto cX68A;
        cX68A:
    }
}
