<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
final class YcADon3ndBWYh
{
    public $filename;
    public $WYZ1W;
    public $e0lpa;
    public $dOKnU;
    public $EZNZh;
    public $lezR9;
    public $VPkbM;
    public $status;
    public $uaNQH;
    public $Za_0M;
    public $J42hQ = 's3';
    public $oZY1d = [];
    public function __construct($Uj3FV, $DqpTR, $HZ_7B, $KvxIY, $Kgya3, $kXmjN, $QuIyr, $NEXrH, $vfxUB, $dhlfo, $C7qXl = 's3', $vZh2W = [])
    {
        goto qN8id;
        JX3Im:
        $this->status = $NEXrH;
        goto kh3Eb;
        qN8id:
        $this->filename = $Uj3FV;
        goto NPpui;
        yqPBC:
        $this->Za_0M = $dhlfo;
        goto gEFq3;
        xShh1:
        $this->oZY1d = $vZh2W;
        goto RVjc9;
        NPpui:
        $this->WYZ1W = $DqpTR;
        goto QedpN;
        QedpN:
        $this->e0lpa = $HZ_7B;
        goto hGqUR;
        hGqUR:
        $this->dOKnU = $KvxIY;
        goto Sv4Ny;
        gEFq3:
        $this->J42hQ = $C7qXl;
        goto xShh1;
        kh3Eb:
        $this->uaNQH = $vfxUB;
        goto yqPBC;
        RRElY:
        $this->VPkbM = $QuIyr;
        goto JX3Im;
        Sv4Ny:
        $this->EZNZh = $Kgya3;
        goto a32V0;
        a32V0:
        $this->lezR9 = $kXmjN;
        goto RRElY;
        RVjc9:
    }
    private static function mBTk51Q1qJz() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mXxHjgOgmXo() : array
    {
        return array_flip(self::mBTk51Q1qJz());
    }
    public function toArray() : array
    {
        $DIkEP = self::mBTk51Q1qJz();
        return [$DIkEP['filename'] => $this->filename, $DIkEP['fileExtension'] => $this->WYZ1W, $DIkEP['mimeType'] => $this->e0lpa, $DIkEP['fileSize'] => $this->dOKnU, $DIkEP['chunkSize'] => $this->EZNZh, $DIkEP['checksums'] => $this->lezR9, $DIkEP['totalChunk'] => $this->VPkbM, $DIkEP['status'] => $this->status, $DIkEP['userId'] => $this->uaNQH, $DIkEP['uploadId'] => $this->Za_0M, $DIkEP['driver'] => $this->J42hQ, $DIkEP['parts'] => $this->oZY1d];
    }
    public static function mp30kFaHIJl(array $KuDTh) : self
    {
        $GNhlw = array_flip(self::mXxHjgOgmXo());
        return new self($KuDTh[$GNhlw['filename']] ?? $KuDTh['filename'] ?? '', $KuDTh[$GNhlw['fileExtension']] ?? $KuDTh['fileExtension'] ?? '', $KuDTh[$GNhlw['mimeType']] ?? $KuDTh['mimeType'] ?? '', $KuDTh[$GNhlw['fileSize']] ?? $KuDTh['fileSize'] ?? 0, $KuDTh[$GNhlw['chunkSize']] ?? $KuDTh['chunkSize'] ?? 0, $KuDTh[$GNhlw['checksums']] ?? $KuDTh['checksums'] ?? [], $KuDTh[$GNhlw['totalChunk']] ?? $KuDTh['totalChunk'] ?? 0, $KuDTh[$GNhlw['status']] ?? $KuDTh['status'] ?? 0, $KuDTh[$GNhlw['userId']] ?? $KuDTh['userId'] ?? 0, $KuDTh[$GNhlw['uploadId']] ?? $KuDTh['uploadId'] ?? '', $KuDTh[$GNhlw['driver']] ?? $KuDTh['driver'] ?? 's3', $KuDTh[$GNhlw['parts']] ?? $KuDTh['parts'] ?? []);
    }
    public static function mR3exW3vi8L($bxtJr) : self
    {
        goto WD4F8;
        C2cfr:
        return self::mp30kFaHIJl($bxtJr);
        goto gGTFL;
        WD4F8:
        if (!(isset($bxtJr['fn']) || isset($bxtJr['fe']))) {
            goto MmSjY;
        }
        goto C2cfr;
        gGTFL:
        MmSjY:
        goto lSyVZ;
        lSyVZ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto fcYWM;
        fcYWM:
    }
    public function mbFbYYzJZqu(string $dhlfo) : void
    {
        $this->Za_0M = $dhlfo;
    }
    public function mZmVKFliuYD(array $vZh2W) : void
    {
        $this->oZY1d = $vZh2W;
    }
    public static function mT2l6CvqxA8($ZQzpf, $ervb7, $bhFuN, $vfxUB, $Kgya3, $kXmjN, $C7qXl)
    {
        return new self($ZQzpf->getFilename(), $ZQzpf->getExtension(), $ervb7, $bhFuN, $Kgya3, $kXmjN, count($kXmjN), ZVJoOgH14iXBq::UPLOADING, $vfxUB, 0, $C7qXl, []);
    }
    public static function mIt0SPRbc2O($Brk87)
    {
        return 'metadata/' . $Brk87 . '.json';
    }
    public function mfM4ZHuZc6K()
    {
        return 's3' === $this->J42hQ ? NFXMub09wSQVu::S3 : NFXMub09wSQVu::LOCAL;
    }
}
