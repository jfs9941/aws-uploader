<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Contracts\K0dipGcxtVboz;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\Traits\QuukgXnznCEU4;
use Jfs\Uploader\Core\Traits\Iny7AwCou1ddb;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
class RhSx2q5xIlh0Y extends NRDoWGrbd9WhU implements IzCykbeCOYPNB
{
    use QuukgXnznCEU4;
    use Iny7AwCou1ddb;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $ExhEa, string $zuSYz) : self
    {
        goto Q6xkq;
        lNH69:
        $XFeNv->mQ7dAxBkFij(EXecNg2hg7kwl::UPLOADING);
        goto FEzlO;
        FEzlO:
        return $XFeNv;
        goto WoWll;
        Q6xkq:
        $XFeNv = new self(['id' => $ExhEa, 'type' => $zuSYz, 'status' => EXecNg2hg7kwl::UPLOADING]);
        goto lNH69;
        WoWll:
    }
    public function width() : ?int
    {
        goto JDa0E;
        fFQR8:
        if (!$oy0ze) {
            goto xwrmL;
        }
        goto kE6MF;
        j6CkP:
        return null;
        goto A4ZIS;
        kE6MF:
        return $oy0ze;
        goto lgCGB;
        lgCGB:
        xwrmL:
        goto j6CkP;
        JDa0E:
        $oy0ze = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto fFQR8;
        A4ZIS:
    }
    public function height() : ?int
    {
        goto QjRGv;
        QjRGv:
        $sccRX = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto f0Zw0;
        m9DeH:
        return null;
        goto cbDse;
        ndwSm:
        bSaiA:
        goto m9DeH;
        f0Zw0:
        if (!$sccRX) {
            goto bSaiA;
        }
        goto lT0EX;
        lT0EX:
        return $sccRX;
        goto ndwSm;
        cbDse:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($XFeNv) {
            goto rQzf7;
            JLKcj:
            if (!(!array_key_exists('thumbnail', $unAdt) && !array_key_exists('hls_path', $unAdt))) {
                goto W2Ayl;
            }
            goto etxdm;
            rQzf7:
            $unAdt = $XFeNv->getDirty();
            goto JLKcj;
            etxdm:
            return;
            goto tsZqI;
            OTJy_:
            iMRGG:
            goto pBU2F;
            QCTdG:
            RhSx2q5xIlh0Y::where('parent_id', $XFeNv->getAttribute('id'))->update(['thumbnail' => $XFeNv->getAttributes()['thumbnail'], 'hls_path' => $XFeNv->getAttributes()['hls_path']]);
            goto OTJy_;
            tsZqI:
            W2Ayl:
            goto DDp1e;
            DDp1e:
            if (!($unAdt['thumbnail'] || $unAdt['hls_path'])) {
                goto iMRGG;
            }
            goto QCTdG;
            pBU2F:
        });
    }
    public function mhOK291H5e5()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mzgGQSNdOG0()
    {
        return $this->getAttribute('id');
    }
    public function m9ScitPYDnM() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto K2BZK;
        yES46:
        goto ZQB1y;
        goto Az_k4;
        LbL79:
        if ($this->getAttribute('hls_path')) {
            goto yRCp_;
        }
        goto x0cnl;
        Az_k4:
        yRCp_:
        goto nYG_Z;
        ttiDX:
        $rjTdY['thumbnail'] = $tKXn_->resolveThumbnail($this);
        goto jy03S;
        K2BZK:
        $tKXn_ = app(K0dipGcxtVboz::class);
        goto SFWeb;
        jy03S:
        return $rjTdY;
        goto b_noA;
        SFWeb:
        $rjTdY = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $tKXn_->resolvePath($this, $this->getAttribute('driver'))];
        goto LbL79;
        nYG_Z:
        $rjTdY['player_url'] = $tKXn_->resolvePathForHlsVideo($this, true);
        goto rdKbW;
        rdKbW:
        ZQB1y:
        goto ttiDX;
        x0cnl:
        $rjTdY['player_url'] = $tKXn_->resolvePath($this, $this->getAttribute('driver'));
        goto yES46;
        b_noA:
    }
    public function getThumbnails()
    {
        goto GQQLa;
        GQQLa:
        $J3DlA = $this->getAttribute('generated_previews') ?? [];
        goto wBkOx;
        iFQwi:
        return array_map(function ($dZvCS) use($tKXn_) {
            return $tKXn_->resolvePath($dZvCS);
        }, $J3DlA);
        goto w3JYc;
        wBkOx:
        $tKXn_ = app(K0dipGcxtVboz::class);
        goto iFQwi;
        w3JYc:
    }
    public static function mua16OeAdrP(NRDoWGrbd9WhU $S8CpP) : RhSx2q5xIlh0Y
    {
        goto EQKVW;
        HCOaj:
        oeQ9n:
        goto f_klf;
        BZaP2:
        return $S8CpP;
        goto HCOaj;
        f_klf:
        return (new RhSx2q5xIlh0Y())->fill($S8CpP->getAttributes());
        goto lNsf6;
        EQKVW:
        if (!$S8CpP instanceof RhSx2q5xIlh0Y) {
            goto oeQ9n;
        }
        goto BZaP2;
        lNsf6:
    }
}
