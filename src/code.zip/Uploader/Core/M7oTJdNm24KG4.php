<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Contracts\QmpIhYv3zjvt7;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Traits\OyShdbtmiDhqy;
use Jfs\Uploader\Core\Traits\VtC1QdkxsauRz;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
class M7oTJdNm24KG4 extends THrRXrYMGJt0m implements Dsl7Uurv4XRG0
{
    use OyShdbtmiDhqy;
    use VtC1QdkxsauRz;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $seLPv, string $y_fdt) : self
    {
        goto CA6g2;
        CA6g2:
        $oS5x2 = new self(['id' => $seLPv, 'type' => $y_fdt, 'status' => FmSSI1JLQCp0W::UPLOADING]);
        goto WvrmZ;
        WvrmZ:
        $oS5x2->m4fwFyIs4eQ(FmSSI1JLQCp0W::UPLOADING);
        goto fgEkJ;
        fgEkJ:
        return $oS5x2;
        goto DSfGl;
        DSfGl:
    }
    public function width() : ?int
    {
        goto TlLJP;
        GB4VM:
        return $GPsTK;
        goto zk0zU;
        KJ0a5:
        if (!$GPsTK) {
            goto WHu_h;
        }
        goto GB4VM;
        pLfLA:
        return null;
        goto R7ywZ;
        TlLJP:
        $GPsTK = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto KJ0a5;
        zk0zU:
        WHu_h:
        goto pLfLA;
        R7ywZ:
    }
    public function height() : ?int
    {
        goto VVFKD;
        eyrZk:
        F8Kh9:
        goto OH_xf;
        UbKLZ:
        return $ldQdP;
        goto eyrZk;
        OH_xf:
        return null;
        goto mlv6I;
        g3fBG:
        if (!$ldQdP) {
            goto F8Kh9;
        }
        goto UbKLZ;
        VVFKD:
        $ldQdP = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto g3fBG;
        mlv6I:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($oS5x2) {
            goto gg140;
            ky8m8:
            if (!(!array_key_exists('thumbnail', $hDf19) && !array_key_exists('hls_path', $hDf19))) {
                goto OvXuS;
            }
            goto MLx7u;
            DtDKr:
            XRa4m:
            goto rkDHe;
            gg140:
            $hDf19 = $oS5x2->getDirty();
            goto ky8m8;
            MLx7u:
            return;
            goto eI1xe;
            cImfG:
            M7oTJdNm24KG4::where('parent_id', $oS5x2->getAttribute('id'))->update(['thumbnail' => $oS5x2->getAttributes()['thumbnail'], 'hls_path' => $oS5x2->getAttributes()['hls_path']]);
            goto DtDKr;
            MIy7b:
            if (!($hDf19['thumbnail'] || $hDf19['hls_path'])) {
                goto XRa4m;
            }
            goto cImfG;
            eI1xe:
            OvXuS:
            goto MIy7b;
            rkDHe:
        });
    }
    public function m7v4u0t4EZp()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mV7VrjzXzO4()
    {
        return $this->getAttribute('id');
    }
    public function mRgpEKGn1n7() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto egPhp;
        wdglU:
        YOfrZ:
        goto NIFzs;
        o8Nwc:
        $u0joM['player_url'] = $OnbMk->resolvePathForHlsVideo($this, true);
        goto wdglU;
        NIFzs:
        $u0joM['thumbnail'] = $OnbMk->resolveThumbnail($this);
        goto Z6QLc;
        Z6QLc:
        return $u0joM;
        goto THc_l;
        fYXQy:
        if ($this->getAttribute('hls_path')) {
            goto DL9qy;
        }
        goto QflOx;
        f8DAj:
        $u0joM = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $OnbMk->resolvePath($this, $this->getAttribute('driver'))];
        goto fYXQy;
        QflOx:
        $u0joM['player_url'] = $OnbMk->resolvePath($this, $this->getAttribute('driver'));
        goto nq0wI;
        nq0wI:
        goto YOfrZ;
        goto X639T;
        X639T:
        DL9qy:
        goto o8Nwc;
        egPhp:
        $OnbMk = app(QmpIhYv3zjvt7::class);
        goto f8DAj;
        THc_l:
    }
    public function getThumbnails()
    {
        goto lSFPe;
        lSFPe:
        $wFeCT = $this->getAttribute('generated_previews') ?? [];
        goto JV2VL;
        JV2VL:
        $OnbMk = app(QmpIhYv3zjvt7::class);
        goto tThIV;
        tThIV:
        return array_map(function ($BKlrl) use($OnbMk) {
            return $OnbMk->resolvePath($BKlrl);
        }, $wFeCT);
        goto BbFt0;
        BbFt0:
    }
    public static function mUrJus5XMWE(THrRXrYMGJt0m $IdScp) : M7oTJdNm24KG4
    {
        goto VC002;
        HraAk:
        return (new M7oTJdNm24KG4())->fill($IdScp->getAttributes());
        goto zWf_J;
        VC002:
        if (!$IdScp instanceof M7oTJdNm24KG4) {
            goto LhSBx;
        }
        goto mapdi;
        WrFCI:
        LhSBx:
        goto HraAk;
        mapdi:
        return $IdScp;
        goto WrFCI;
        zWf_J:
    }
}
