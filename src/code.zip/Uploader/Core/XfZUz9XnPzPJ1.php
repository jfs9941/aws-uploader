<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
final class XfZUz9XnPzPJ1
{
    public $filename;
    public $C3SKe;
    public $rVXCI;
    public $P_XkO;
    public $SWeqX;
    public $E7GDc;
    public $zsyS6;
    public $status;
    public $X_b7y;
    public $cUKik;
    public $pb8PJ = 's3';
    public $CIuIt = [];
    public function __construct($i7mhP, $CA538, $oQAFo, $a4ElZ, $icV6U, $T52tC, $S1FIt, $yEX0y, $Vz1ad, $bXjPU, $tbIVu = 's3', $bQ_Iq = [])
    {
        goto KOMKs;
        Hki6Z:
        $this->SWeqX = $icV6U;
        goto vUuhQ;
        wL9v1:
        $this->X_b7y = $Vz1ad;
        goto v1oEX;
        KOMKs:
        $this->filename = $i7mhP;
        goto BKK66;
        tZTbN:
        $this->status = $yEX0y;
        goto wL9v1;
        SLG6L:
        $this->P_XkO = $a4ElZ;
        goto Hki6Z;
        vUuhQ:
        $this->E7GDc = $T52tC;
        goto bQIOB;
        v1oEX:
        $this->cUKik = $bXjPU;
        goto UYzpb;
        PgT6t:
        $this->rVXCI = $oQAFo;
        goto SLG6L;
        UYzpb:
        $this->pb8PJ = $tbIVu;
        goto b1FXe;
        BKK66:
        $this->C3SKe = $CA538;
        goto PgT6t;
        bQIOB:
        $this->zsyS6 = $S1FIt;
        goto tZTbN;
        b1FXe:
        $this->CIuIt = $bQ_Iq;
        goto JroIk;
        JroIk:
    }
    private static function m13g10JG5ZN() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mEuOkH5YzV0() : array
    {
        return array_flip(self::m13g10JG5ZN());
    }
    public function toArray() : array
    {
        $fJv40 = self::m13g10JG5ZN();
        return [$fJv40['filename'] => $this->filename, $fJv40['fileExtension'] => $this->C3SKe, $fJv40['mimeType'] => $this->rVXCI, $fJv40['fileSize'] => $this->P_XkO, $fJv40['chunkSize'] => $this->SWeqX, $fJv40['checksums'] => $this->E7GDc, $fJv40['totalChunk'] => $this->zsyS6, $fJv40['status'] => $this->status, $fJv40['userId'] => $this->X_b7y, $fJv40['uploadId'] => $this->cUKik, $fJv40['driver'] => $this->pb8PJ, $fJv40['parts'] => $this->CIuIt];
    }
    public static function mIKPNTVQ0Rv(array $hQQJ1) : self
    {
        $Pu83g = array_flip(self::mEuOkH5YzV0());
        return new self($hQQJ1[$Pu83g['filename']] ?? $hQQJ1['filename'] ?? '', $hQQJ1[$Pu83g['fileExtension']] ?? $hQQJ1['fileExtension'] ?? '', $hQQJ1[$Pu83g['mimeType']] ?? $hQQJ1['mimeType'] ?? '', $hQQJ1[$Pu83g['fileSize']] ?? $hQQJ1['fileSize'] ?? 0, $hQQJ1[$Pu83g['chunkSize']] ?? $hQQJ1['chunkSize'] ?? 0, $hQQJ1[$Pu83g['checksums']] ?? $hQQJ1['checksums'] ?? [], $hQQJ1[$Pu83g['totalChunk']] ?? $hQQJ1['totalChunk'] ?? 0, $hQQJ1[$Pu83g['status']] ?? $hQQJ1['status'] ?? 0, $hQQJ1[$Pu83g['userId']] ?? $hQQJ1['userId'] ?? 0, $hQQJ1[$Pu83g['uploadId']] ?? $hQQJ1['uploadId'] ?? '', $hQQJ1[$Pu83g['driver']] ?? $hQQJ1['driver'] ?? 's3', $hQQJ1[$Pu83g['parts']] ?? $hQQJ1['parts'] ?? []);
    }
    public static function mki1v3aMtnh($IP97T) : self
    {
        goto Rhsq_;
        v_bt3:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto KembF;
        Rhsq_:
        if (!(isset($IP97T['fn']) || isset($IP97T['fe']))) {
            goto Qzwh7;
        }
        goto BGqtI;
        BGqtI:
        return self::mIKPNTVQ0Rv($IP97T);
        goto AoLV7;
        AoLV7:
        Qzwh7:
        goto v_bt3;
        KembF:
    }
    public function mcz6MDxZF1x(string $bXjPU) : void
    {
        $this->cUKik = $bXjPU;
    }
    public function mJjlZb6LEdy(array $bQ_Iq) : void
    {
        $this->CIuIt = $bQ_Iq;
    }
    public static function mdtBJkm8O9m($ZPsYd, $DVljR, $MPOZB, $Vz1ad, $icV6U, $T52tC, $tbIVu)
    {
        return new self($ZPsYd->getFilename(), $ZPsYd->getExtension(), $DVljR, $MPOZB, $icV6U, $T52tC, count($T52tC), TSfaBZEUMcbl0::UPLOADING, $Vz1ad, 0, $tbIVu, []);
    }
    public static function mpccx90wi1r($qMhfW)
    {
        return 'metadata/' . $qMhfW . '.json';
    }
    public function mO1plATSwB3()
    {
        return 's3' === $this->pb8PJ ? YOaiWCgFM7tRK::S3 : YOaiWCgFM7tRK::LOCAL;
    }
}
