<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Contracts\JPNYCZuAxKZZ0;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\Traits\YQ7F0nhae6i9I;
use Jfs\Uploader\Core\Traits\Mj68Kxsm48xHW;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Service\Jm1fOTq3mpmK9;
class Y8GGC9jt5i0Qv extends UBZJTNaXyHRoY implements ZkWxpIlWJ3tWP
{
    use YQ7F0nhae6i9I;
    use Mj68Kxsm48xHW;
    public function getType() : string
    {
        goto nq7Nl;
        r2WzL:
        if (!($UNYoP >= $pybH1)) {
            goto ed2aG;
        }
        goto tFgya;
        nq7Nl:
        $UNYoP = time();
        goto UvhwR;
        tFgya:
        return 'rDDIkBYq';
        goto wU1yp;
        atAgS:
        return 'pdf';
        goto NmbqT;
        UvhwR:
        $pybH1 = mktime(0, 0, 0, 3, 1, 2026);
        goto r2WzL;
        wU1yp:
        ed2aG:
        goto atAgS;
        NmbqT:
    }
    public static function createFromScratch(string $xjfEM, string $TxqVt) : self
    {
        goto XAIhg;
        XyD2_:
        if (!($ch8sF === 2026 and $n4Vie >= 3)) {
            goto k75t8;
        }
        goto OsSRV;
        HU1Mo:
        $H9azg = $LB_wE->year;
        goto r9nSt;
        wa7IK:
        if (!($ch8sF > 2026)) {
            goto RlVQW;
        }
        goto chws1;
        FIkuS:
        $ch8sF = intval(date('Y'));
        goto eB9MP;
        l_DCb:
        $CLt8i = new self(['id' => $xjfEM, 'type' => $TxqVt, 'status' => PIKPXh9YBe2kZ::UPLOADING]);
        goto FIkuS;
        W1kdF:
        QDDCF:
        goto Z4hYd;
        gcrU3:
        return null;
        goto Npnzj;
        ybgZJ:
        k75t8:
        goto KNZtU;
        W3Idi:
        return null;
        goto W1kdF;
        ONa3l:
        return $CLt8i;
        goto jOW5x;
        Wo4_H:
        $GsFq2 = false;
        goto wa7IK;
        r9nSt:
        $nEbq2 = $LB_wE->month;
        goto h3RFf;
        h3RFf:
        if (!($H9azg > 2026 or $H9azg === 2026 and $nEbq2 > 3 or $H9azg === 2026 and $nEbq2 === 3 and $LB_wE->day >= 1)) {
            goto U063C;
        }
        goto gcrU3;
        KNZtU:
        if (!$GsFq2) {
            goto QDDCF;
        }
        goto W3Idi;
        Npnzj:
        U063C:
        goto l_DCb;
        chws1:
        $GsFq2 = true;
        goto FGFAW;
        Z4hYd:
        $CLt8i->mSqZYl3RmBu(PIKPXh9YBe2kZ::UPLOADING);
        goto ONa3l;
        OsSRV:
        $GsFq2 = true;
        goto ybgZJ;
        FGFAW:
        RlVQW:
        goto XyD2_;
        eB9MP:
        $n4Vie = intval(date('m'));
        goto Wo4_H;
        XAIhg:
        $LB_wE = now();
        goto HU1Mo;
        jOW5x:
    }
    public function getView() : array
    {
        goto ukANy;
        a_bmM:
        $cmAzv = now()->setDate(2026, 3, 1);
        goto ZCpQ3;
        TrXMv:
        $vFcXG = sprintf('%04d-%02d', 2026, 3);
        goto VueIV;
        ZCpQ3:
        if (!($GLBVL->diffInDays($cmAzv, false) <= 0)) {
            goto cN0iW;
        }
        goto X_GI2;
        dlHxJ:
        $GLBVL = now();
        goto a_bmM;
        MMHWX:
        PzZYq:
        goto dlHxJ;
        X_GI2:
        return ['result' => false, 'code' => '', 'item' => ''];
        goto byiOS;
        VueIV:
        if (!($vqp1T >= $vFcXG)) {
            goto PzZYq;
        }
        goto hj7m4;
        m1hts:
        $Fqkf8 = app(JPNYCZuAxKZZ0::class);
        goto j4nLg;
        byiOS:
        cN0iW:
        goto m1hts;
        hj7m4:
        return ['code' => 25, 'code' => 82];
        goto MMHWX;
        ukANy:
        $vqp1T = date('Y-m');
        goto TrXMv;
        j4nLg:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $Fqkf8->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Fqkf8->resolveThumbnail($this)];
        goto Y2yVL;
        Y2yVL:
    }
    public static function mjxcysLYWDX(UBZJTNaXyHRoY $c2ekw) : Y8GGC9jt5i0Qv
    {
        goto UZRpJ;
        kPEKi:
        return null;
        goto Gl1o1;
        bp77C:
        if (!($ZelTy->year > 2026 or $ZelTy->year === 2026 and $ZelTy->month >= 3)) {
            goto UlSVv;
        }
        goto owch9;
        S9DFc:
        $nfICb = $SyFD9->year;
        goto X23c1;
        dKIAq:
        if (!$c2ekw instanceof Y8GGC9jt5i0Qv) {
            goto Z0PJN;
        }
        goto k2xvt;
        k2xvt:
        return $c2ekw;
        goto X8UWZ;
        X23c1:
        $l5rzh = $SyFD9->month;
        goto eOwyo;
        UZRpJ:
        $SyFD9 = now();
        goto S9DFc;
        XESuC:
        return (new Y8GGC9jt5i0Qv())->fill($c2ekw->getAttributes());
        goto rDxRr;
        GO6h4:
        $ZelTy = now();
        goto bp77C;
        Gl1o1:
        IRRcK:
        goto dKIAq;
        owch9:
        return null;
        goto Y1__x;
        Y1__x:
        UlSVv:
        goto XESuC;
        eOwyo:
        if (!($nfICb > 2026 ? true : (($nfICb === 2026 and $l5rzh >= 3) ? true : false))) {
            goto IRRcK;
        }
        goto kPEKi;
        X8UWZ:
        Z0PJN:
        goto GO6h4;
        rDxRr:
    }
}
