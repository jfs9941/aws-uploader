<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
final class ShrdF6p8QWYqf
{
    public $filename;
    public $ghW3E;
    public $A1fRk;
    public $u5y3E;
    public $sfiTQ;
    public $d29za;
    public $jxdb6;
    public $status;
    public $Ge0Mr;
    public $ohWsi;
    public $driver = 's3';
    public $pZeeV = [];
    public function __construct($yWEaX, $UCO1s, $FSnUv, $nbEyb, $G2mdJ, $mIRUV, $CrfJz, $ycn5E, $SSeWP, $b2o4e, $RpHBQ = 's3', $FeFdM = [])
    {
        goto OjASu;
        OjASu:
        $this->filename = $yWEaX;
        goto JNblr;
        XSCR1:
        $this->Ge0Mr = $SSeWP;
        goto RZfAx;
        RZfAx:
        $this->ohWsi = $b2o4e;
        goto PkeWP;
        Lu9Xx:
        $this->A1fRk = $FSnUv;
        goto sl0wc;
        aYWu4:
        $this->jxdb6 = $CrfJz;
        goto MCbJR;
        dRZ4Y:
        $this->pZeeV = $FeFdM;
        goto WIFTh;
        JNblr:
        $this->ghW3E = $UCO1s;
        goto Lu9Xx;
        Qz22u:
        $this->sfiTQ = $G2mdJ;
        goto rTcxH;
        sl0wc:
        $this->u5y3E = $nbEyb;
        goto Qz22u;
        MCbJR:
        $this->status = $ycn5E;
        goto XSCR1;
        rTcxH:
        $this->d29za = $mIRUV;
        goto aYWu4;
        PkeWP:
        $this->driver = $RpHBQ;
        goto dRZ4Y;
        WIFTh:
    }
    private static function msgzTbscFC2() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function miZ5eJfa1dX() : array
    {
        return array_flip(self::msgzTbscFC2());
    }
    public function toArray() : array
    {
        $ybcfM = self::msgzTbscFC2();
        return [$ybcfM['filename'] => $this->filename, $ybcfM['fileExtension'] => $this->ghW3E, $ybcfM['mimeType'] => $this->A1fRk, $ybcfM['fileSize'] => $this->u5y3E, $ybcfM['chunkSize'] => $this->sfiTQ, $ybcfM['checksums'] => $this->d29za, $ybcfM['totalChunk'] => $this->jxdb6, $ybcfM['status'] => $this->status, $ybcfM['userId'] => $this->Ge0Mr, $ybcfM['uploadId'] => $this->ohWsi, $ybcfM['driver'] => $this->driver, $ybcfM['parts'] => $this->pZeeV];
    }
    public static function m5bW8jU4XEQ(array $Jj1Nf) : self
    {
        $kflgV = array_flip(self::miZ5eJfa1dX());
        return new self($Jj1Nf[$kflgV['filename']] ?? $Jj1Nf['filename'] ?? '', $Jj1Nf[$kflgV['fileExtension']] ?? $Jj1Nf['fileExtension'] ?? '', $Jj1Nf[$kflgV['mimeType']] ?? $Jj1Nf['mimeType'] ?? '', $Jj1Nf[$kflgV['fileSize']] ?? $Jj1Nf['fileSize'] ?? 0, $Jj1Nf[$kflgV['chunkSize']] ?? $Jj1Nf['chunkSize'] ?? 0, $Jj1Nf[$kflgV['checksums']] ?? $Jj1Nf['checksums'] ?? [], $Jj1Nf[$kflgV['totalChunk']] ?? $Jj1Nf['totalChunk'] ?? 0, $Jj1Nf[$kflgV['status']] ?? $Jj1Nf['status'] ?? 0, $Jj1Nf[$kflgV['userId']] ?? $Jj1Nf['userId'] ?? 0, $Jj1Nf[$kflgV['uploadId']] ?? $Jj1Nf['uploadId'] ?? '', $Jj1Nf[$kflgV['driver']] ?? $Jj1Nf['driver'] ?? 's3', $Jj1Nf[$kflgV['parts']] ?? $Jj1Nf['parts'] ?? []);
    }
    public static function mqhTVnRl0yJ($U2oNX) : self
    {
        goto LmMLV;
        LmMLV:
        if (!(isset($U2oNX['fn']) || isset($U2oNX['fe']))) {
            goto ICIgV;
        }
        goto HBVtm;
        ZDdI9:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto sfa2A;
        iddCn:
        ICIgV:
        goto ZDdI9;
        HBVtm:
        return self::m5bW8jU4XEQ($U2oNX);
        goto iddCn;
        sfa2A:
    }
    public function moZF5p29pbi(string $b2o4e) : void
    {
        $this->ohWsi = $b2o4e;
    }
    public function mfL8ED8bRTw(array $FeFdM) : void
    {
        $this->pZeeV = $FeFdM;
    }
    public static function mAVIRdx8q2C($YEF57, $xlqno, $qk8dr, $SSeWP, $G2mdJ, $mIRUV, $RpHBQ)
    {
        return new self($YEF57->getFilename(), $YEF57->getExtension(), $xlqno, $qk8dr, $G2mdJ, $mIRUV, count($mIRUV), ZP6Ky842t6y9Y::UPLOADING, $SSeWP, 0, $RpHBQ, []);
    }
    public static function mEfKM4QPesx($InHEz)
    {
        return 'metadata/' . $InHEz . '.json';
    }
    public function mUz5QoCeD2Y()
    {
        return 's3' === $this->driver ? YJGCddWUf6Zu2::S3 : YJGCddWUf6Zu2::LOCAL;
    }
}
