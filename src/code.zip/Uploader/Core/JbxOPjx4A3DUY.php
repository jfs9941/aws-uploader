<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Contracts\XuIaPR4PMryqL;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\Traits\Kbu3Shr02PNph;
use Jfs\Uploader\Core\Traits\VOrYIv3AwrFzm;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
class JbxOPjx4A3DUY extends Fd8NTWwq2cQOc implements BbauDy0pIbj64
{
    use Kbu3Shr02PNph;
    use VOrYIv3AwrFzm;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $LtmUC, string $QVNFV) : self
    {
        goto A6e46;
        wmOlb:
        $Uas5p->m36TLWxcxjb(MUu80sOhINyO3::UPLOADING);
        goto QsLI9;
        A6e46:
        $Uas5p = new self(['id' => $LtmUC, 'type' => $QVNFV, 'status' => MUu80sOhINyO3::UPLOADING]);
        goto wmOlb;
        QsLI9:
        return $Uas5p;
        goto KjjM9;
        KjjM9:
    }
    public function width() : ?int
    {
        goto HmAPg;
        pKTaF:
        return null;
        goto gcRXw;
        pCKMi:
        qGa_h:
        goto pKTaF;
        GrRqW:
        return $SeDOJ;
        goto pCKMi;
        HmAPg:
        $SeDOJ = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto wX1Iv;
        wX1Iv:
        if (!$SeDOJ) {
            goto qGa_h;
        }
        goto GrRqW;
        gcRXw:
    }
    public function height() : ?int
    {
        goto SHqLf;
        sxa5a:
        return $vwirX;
        goto AfHmV;
        SHqLf:
        $vwirX = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto hreVg;
        AfHmV:
        chi8_:
        goto s4NmO;
        s4NmO:
        return null;
        goto PDd05;
        hreVg:
        if (!$vwirX) {
            goto chi8_;
        }
        goto sxa5a;
        PDd05:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($Uas5p) {
            goto CdYlx;
            oQN_o:
            Teh83:
            goto l347S;
            l347S:
            if (!($qFV0O['thumbnail'] || $qFV0O['hls_path'])) {
                goto mF4Hz;
            }
            goto VN7gH;
            OlVXF:
            return;
            goto oQN_o;
            XIjC0:
            mF4Hz:
            goto qP2K0;
            VN7gH:
            JbxOPjx4A3DUY::where('parent_id', $Uas5p->getAttribute('id'))->update(['thumbnail' => $Uas5p->getAttributes()['thumbnail'], 'hls_path' => $Uas5p->getAttributes()['hls_path']]);
            goto XIjC0;
            CdYlx:
            $qFV0O = $Uas5p->getDirty();
            goto WxIAm;
            WxIAm:
            if (!(!array_key_exists('thumbnail', $qFV0O) && !array_key_exists('hls_path', $qFV0O))) {
                goto Teh83;
            }
            goto OlVXF;
            qP2K0:
        });
    }
    public function m2bpAztczG8()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m5nhgz2QmVF()
    {
        return $this->getAttribute('id');
    }
    public function mclJFenLDZi() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto KCG72;
        jyBjl:
        $iLsZb = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $IXZSx->resolvePath($this, $this->getAttribute('driver'))];
        goto ARkiS;
        hCQDf:
        return $iLsZb;
        goto quk0w;
        Rngdb:
        vmOgq:
        goto jlzHf;
        wnqkd:
        $iLsZb['player_url'] = $IXZSx->resolvePathForHlsVideo($this, true);
        goto Rngdb;
        r9ELV:
        $iLsZb['player_url'] = $IXZSx->resolvePath($this, $this->getAttribute('driver'));
        goto h0Nak;
        xsyXf:
        ANI4_:
        goto wnqkd;
        ARkiS:
        if ($this->getAttribute('hls_path')) {
            goto ANI4_;
        }
        goto r9ELV;
        h0Nak:
        goto vmOgq;
        goto xsyXf;
        jlzHf:
        $iLsZb['thumbnail'] = $IXZSx->resolveThumbnail($this);
        goto hCQDf;
        KCG72:
        $IXZSx = app(XuIaPR4PMryqL::class);
        goto jyBjl;
        quk0w:
    }
    public function getThumbnails()
    {
        goto xfSDQ;
        MIFvi:
        $IXZSx = app(XuIaPR4PMryqL::class);
        goto HS4Ol;
        HS4Ol:
        return array_map(function ($T07ak) use($IXZSx) {
            return $IXZSx->resolvePath($T07ak);
        }, $q6f0P);
        goto fjvbJ;
        xfSDQ:
        $q6f0P = $this->getAttribute('generated_previews') ?? [];
        goto MIFvi;
        fjvbJ:
    }
    public static function mprcHbvAwf7(Fd8NTWwq2cQOc $ufjgt) : JbxOPjx4A3DUY
    {
        goto jN5Yv;
        QTbug:
        return (new JbxOPjx4A3DUY())->fill($ufjgt->getAttributes());
        goto Rutbc;
        v4vbu:
        HEXDE:
        goto QTbug;
        jN5Yv:
        if (!$ufjgt instanceof JbxOPjx4A3DUY) {
            goto HEXDE;
        }
        goto HFELh;
        HFELh:
        return $ufjgt;
        goto v4vbu;
        Rutbc:
    }
}
