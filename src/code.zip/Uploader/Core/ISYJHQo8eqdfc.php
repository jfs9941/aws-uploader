<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Contracts\FK56xL1HuXbff;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\Traits\CAyWR6lPHLTW2;
use Jfs\Uploader\Core\Traits\NnqCGr9M8kJNm;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
class ISYJHQo8eqdfc extends HtHJXf7xellNX implements H1Ax5lj0mb7kw
{
    use CAyWR6lPHLTW2;
    use NnqCGr9M8kJNm;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $tbOMu, string $g88NJ) : self
    {
        goto CQdHV;
        mjlO2:
        return $qNHE7;
        goto ADrWa;
        rzVOM:
        $qNHE7->mMTZSzpDsC7(IOOvAXAyKHLW2::UPLOADING);
        goto mjlO2;
        CQdHV:
        $qNHE7 = new self(['id' => $tbOMu, 'type' => $g88NJ, 'status' => IOOvAXAyKHLW2::UPLOADING]);
        goto rzVOM;
        ADrWa:
    }
    public function width() : ?int
    {
        goto c2e7I;
        D_KkY:
        TQYG9:
        goto eaWLB;
        c2e7I:
        $MpCza = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto VPm0X;
        VPm0X:
        if (!$MpCza) {
            goto TQYG9;
        }
        goto Q7Z2i;
        eaWLB:
        return null;
        goto ZylqP;
        Q7Z2i:
        return $MpCza;
        goto D_KkY;
        ZylqP:
    }
    public function height() : ?int
    {
        goto YhpMU;
        GOtkG:
        Fp34S:
        goto q5I9u;
        YhpMU:
        $rfhYJ = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto rndbc;
        q5I9u:
        return null;
        goto p92UY;
        Dsgrs:
        return $rfhYJ;
        goto GOtkG;
        rndbc:
        if (!$rfhYJ) {
            goto Fp34S;
        }
        goto Dsgrs;
        p92UY:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($qNHE7) {
            goto SZlaV;
            MdMBW:
            if (!($cvTOD['thumbnail'] || $cvTOD['hls_path'])) {
                goto WS0OH;
            }
            goto LM9zI;
            jIQWY:
            if (!(!array_key_exists('thumbnail', $cvTOD) && !array_key_exists('hls_path', $cvTOD))) {
                goto IJ5XL;
            }
            goto akws0;
            SZlaV:
            $cvTOD = $qNHE7->getDirty();
            goto jIQWY;
            LM9zI:
            ISYJHQo8eqdfc::where('parent_id', $qNHE7->getAttribute('id'))->update(['thumbnail' => $qNHE7->getAttributes()['thumbnail'], 'hls_path' => $qNHE7->getAttributes()['hls_path']]);
            goto BqJpt;
            BqJpt:
            WS0OH:
            goto uK3iP;
            akws0:
            return;
            goto VJwY1;
            VJwY1:
            IJ5XL:
            goto MdMBW;
            uK3iP:
        });
    }
    public function mXlWGmlfxqc()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mdK17axgfrA()
    {
        return $this->getAttribute('id');
    }
    public function mbYASwyVXoG() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto jGvFj;
        cE8x1:
        $IgxEE = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $QWY0L->resolvePath($this, $this->getAttribute('driver'))];
        goto NV9Cf;
        IQB5b:
        $IgxEE['player_url'] = $QWY0L->resolvePath($this, $this->getAttribute('driver'));
        goto Zlg3W;
        pjt21:
        $IgxEE['thumbnail'] = $QWY0L->resolveThumbnail($this);
        goto fGwyF;
        RILgG:
        $IgxEE['player_url'] = $QWY0L->resolvePathForHlsVideo($this, true);
        goto byLsu;
        NV9Cf:
        if ($this->getAttribute('hls_path')) {
            goto z0APx;
        }
        goto IQB5b;
        pgQpl:
        z0APx:
        goto RILgG;
        Zlg3W:
        goto iv3aZ;
        goto pgQpl;
        jGvFj:
        $QWY0L = app(FK56xL1HuXbff::class);
        goto cE8x1;
        byLsu:
        iv3aZ:
        goto pjt21;
        fGwyF:
        return $IgxEE;
        goto ixvNo;
        ixvNo:
    }
    public function getThumbnails()
    {
        goto rs8V_;
        Dwsxn:
        return array_map(function ($eeT1E) use($QWY0L) {
            return $QWY0L->resolvePath($eeT1E);
        }, $GqLyZ);
        goto n6CFv;
        rs8V_:
        $GqLyZ = $this->getAttribute('generated_previews') ?? [];
        goto JELYH;
        JELYH:
        $QWY0L = app(FK56xL1HuXbff::class);
        goto Dwsxn;
        n6CFv:
    }
    public static function mrZnKkTiou8(HtHJXf7xellNX $I6_Gg) : ISYJHQo8eqdfc
    {
        goto bndZA;
        bndZA:
        if (!$I6_Gg instanceof ISYJHQo8eqdfc) {
            goto d8SOv;
        }
        goto eIVdM;
        UWgOC:
        d8SOv:
        goto nEGia;
        eIVdM:
        return $I6_Gg;
        goto UWgOC;
        nEGia:
        return (new ISYJHQo8eqdfc())->fill($I6_Gg->getAttributes());
        goto FzHuX;
        FzHuX:
    }
}
