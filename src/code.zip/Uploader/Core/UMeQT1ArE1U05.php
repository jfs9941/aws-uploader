<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Uploader\Core\Traits\CHvTVfEcdTEOe;
use Jfs\Uploader\Core\Traits\T98qFVxByjzPT;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class UMeQT1ArE1U05 extends MXbLxov2QPqm4 implements HpFoUL2Zq7Sem
{
    use CHvTVfEcdTEOe;
    use T98qFVxByjzPT;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $DQgCT, string $rG_ni) : self
    {
        goto wmrZ5;
        sov5n:
        return $eYbzj;
        goto lh3vx;
        wmrZ5:
        $eYbzj = new self(['id' => $DQgCT, 'type' => $rG_ni, 'status' => Q5pXt73hTeTVP::UPLOADING]);
        goto XTW_m;
        XTW_m:
        $eYbzj->mn9R5wxLm2K(Q5pXt73hTeTVP::UPLOADING);
        goto sov5n;
        lh3vx:
    }
    public function width() : ?int
    {
        goto o0Ka_;
        RVRKj:
        if (!$g5xFk) {
            goto IkYJQ;
        }
        goto klUeQ;
        klUeQ:
        return $g5xFk;
        goto xbBj6;
        xbBj6:
        IkYJQ:
        goto b3ezB;
        b3ezB:
        return null;
        goto XV5Ey;
        o0Ka_:
        $g5xFk = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto RVRKj;
        XV5Ey:
    }
    public function height() : ?int
    {
        goto iCjHH;
        iCjHH:
        $zZl79 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto lJjxo;
        MIyXn:
        return $zZl79;
        goto uhDzg;
        uhDzg:
        dUo4o:
        goto I4v0X;
        lJjxo:
        if (!$zZl79) {
            goto dUo4o;
        }
        goto MIyXn;
        I4v0X:
        return null;
        goto snunf;
        snunf:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($eYbzj) {
            goto vLOp4;
            DGDVY:
            UMeQT1ArE1U05::where('parent_id', $eYbzj->getAttribute('id'))->update(['thumbnail' => $eYbzj->getAttributes()['thumbnail'], 'hls_path' => $eYbzj->getAttributes()['hls_path']]);
            goto ihRhO;
            p0h3t:
            xEVrP:
            goto tOJHa;
            vLOp4:
            $JG3dZ = $eYbzj->getDirty();
            goto SX5_l;
            VeXot:
            return;
            goto p0h3t;
            ihRhO:
            zFVxF:
            goto oMyLn;
            tOJHa:
            if (!($JG3dZ['thumbnail'] || $JG3dZ['hls_path'])) {
                goto zFVxF;
            }
            goto DGDVY;
            SX5_l:
            if (!(!array_key_exists('thumbnail', $JG3dZ) && !array_key_exists('hls_path', $JG3dZ))) {
                goto xEVrP;
            }
            goto VeXot;
            oMyLn:
        });
    }
    public function md6JvC1MTxd()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mGoQmLcAaiL()
    {
        return $this->getAttribute('id');
    }
    public function mM4X26Op2hl() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto qaeUR;
        Jjn_M:
        $NyT6D['player_url'] = $J1L9Z->resolvePath($this, $this->getAttribute('driver'));
        goto yTfwH;
        tFndS:
        return $NyT6D;
        goto cWORU;
        pf4Rx:
        iOnDz:
        goto J3mn8;
        oLYqN:
        if ($this->getAttribute('hls_path')) {
            goto TeMQ7;
        }
        goto Jjn_M;
        yTfwH:
        goto iOnDz;
        goto vXNVG;
        J3mn8:
        $NyT6D['thumbnail'] = $J1L9Z->resolveThumbnail($this);
        goto tFndS;
        H1FtT:
        $NyT6D = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $J1L9Z->resolvePath($this, $this->getAttribute('driver'))];
        goto oLYqN;
        Uwo8x:
        $NyT6D['player_url'] = $J1L9Z->resolvePathForHlsVideo($this, true);
        goto pf4Rx;
        qaeUR:
        $J1L9Z = app(LlbXoUBShkgwJ::class);
        goto H1FtT;
        vXNVG:
        TeMQ7:
        goto Uwo8x;
        cWORU:
    }
    public function getThumbnails()
    {
        goto fOVUI;
        fOVUI:
        $ky4Kr = $this->getAttribute('generated_previews') ?? [];
        goto h6kK1;
        h6kK1:
        $J1L9Z = app(LlbXoUBShkgwJ::class);
        goto vyks5;
        vyks5:
        return array_map(function ($I_Zk6) use($J1L9Z) {
            return $J1L9Z->resolvePath($I_Zk6);
        }, $ky4Kr);
        goto r4kwI;
        r4kwI:
    }
    public static function mUJPTOTgdD6(MXbLxov2QPqm4 $rXM0w) : UMeQT1ArE1U05
    {
        goto MzgHN;
        fFnND:
        return (new UMeQT1ArE1U05())->fill($rXM0w->getAttributes());
        goto QLKey;
        DEjya:
        return $rXM0w;
        goto R2kXB;
        MzgHN:
        if (!$rXM0w instanceof UMeQT1ArE1U05) {
            goto p9pXc;
        }
        goto DEjya;
        R2kXB:
        p9pXc:
        goto fFnND;
        QLKey:
    }
}
