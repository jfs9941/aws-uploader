<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Core\Observer\L9YzFkESbwIDl;
use Jfs\Uploader\Core\XWPIITmssZr7Q;
use Jfs\Uploader\Core\Traits\OUGe2daOkuNHO;
use Jfs\Uploader\Core\Traits\W8XZSueQaszDJ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Exception\CIAjwsRYu6S6e;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Exception\L8JNHBuVqji1P;
use Jfs\Uploader\Service\UkWgTCfbgTMD8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class DcQiQqj2PVL2z implements DHtESYY0VyGQJ
{
    use OUGe2daOkuNHO;
    use W8XZSueQaszDJ;
    private $gtifV;
    private function __construct($qFMlx, $L32kE)
    {
        $this->bilhr = $qFMlx;
        $this->AouKZ = $L32kE;
    }
    private function mV7Nkn03tLX(string $RiWpQ, $L32kE, $j3j3G, bool $J5V7H = false) : void
    {
        $this->mPs1JYkvGIi(new L9YzFkESbwIDl($this, $L32kE, $j3j3G, $RiWpQ, $J5V7H));
    }
    public function getFile()
    {
        return $this->bilhr;
    }
    public function mKgkEuClTdh(array $ic1Gt) : void
    {
        $this->gtifV = $ic1Gt;
    }
    public function mo8QDvgchjh() : void
    {
        $this->m1WocvV9yZy(A7CVlqbpzhfLD::UPLOADING);
    }
    public function mlgNMO0kMNH() : void
    {
        $this->m1WocvV9yZy(A7CVlqbpzhfLD::UPLOADED);
    }
    public function mhbSMT2U64r() : void
    {
        $this->m1WocvV9yZy(A7CVlqbpzhfLD::PROCESSING);
    }
    public function mqPI3SWHixP() : void
    {
        $this->m1WocvV9yZy(A7CVlqbpzhfLD::FINISHED);
    }
    public function mmrZucbHhSd() : void
    {
        $this->m1WocvV9yZy(A7CVlqbpzhfLD::ABORTED);
    }
    public function mrQkNHRXp1P() : array
    {
        return $this->gtifV;
    }
    public static function msanA4csySx(string $eeXS6, $PcU1j, $uIWH1, $RiWpQ) : self
    {
        goto EylHP;
        EylHP:
        $qFMlx = App::make(UkWgTCfbgTMD8::class)->mndT5zgzcel(XWPIITmssZr7Q::mrxyiFG5EN6($eeXS6));
        goto Vzb7e;
        bNNMo:
        $MT2WW->mdMI6wvUXmN(A7CVlqbpzhfLD::UPLOADING);
        goto Aycku;
        Vzb7e:
        $MT2WW = new self($qFMlx, $PcU1j);
        goto zzj8V;
        zzj8V:
        $MT2WW->mV7Nkn03tLX($RiWpQ, $PcU1j, $uIWH1);
        goto bNNMo;
        Aycku:
        return $MT2WW->moypkrW8FaU();
        goto bwjAz;
        bwjAz:
    }
    public static function m4O81XSiD24($qFMlx, $L32kE, $j3j3G, $RiWpQ, $J5V7H = false) : self
    {
        goto TxN3M;
        HSyGo:
        $MT2WW->mV7Nkn03tLX($RiWpQ, $L32kE, $j3j3G, $J5V7H);
        goto FjOdo;
        FjOdo:
        $MT2WW->mdMI6wvUXmN(A7CVlqbpzhfLD::UPLOADING);
        goto G5VG2;
        G5VG2:
        return $MT2WW;
        goto jc2V5;
        TxN3M:
        $MT2WW = new self($qFMlx, $L32kE);
        goto HSyGo;
        jc2V5:
    }
}
