<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\Observer\B3X39NyXf7328;
use Jfs\Uploader\Core\UAsHLG1mz8hdv;
use Jfs\Uploader\Core\Traits\V0YXBJbmiAgiX;
use Jfs\Uploader\Core\Traits\G5NBCB8i1Emes;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Exception\LjuaNh4VOaOkF;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Exception\N08aNyPgjV9qA;
use Jfs\Uploader\Service\DpvqXIwAB5UAa;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Rfow5q0HYgflu implements RsTEqK0aKnthE
{
    use V0YXBJbmiAgiX;
    use G5NBCB8i1Emes;
    private $I2jBi;
    private function __construct($Ga9Xm, $nkmCX)
    {
        $this->N1jgO = $Ga9Xm;
        $this->WKvVV = $nkmCX;
    }
    private function mcepN3rCOFn(string $ivxnu, $nkmCX, $NYASv, bool $FeGFw = false) : void
    {
        $this->mv8Sk2uSFhz(new B3X39NyXf7328($this, $nkmCX, $NYASv, $ivxnu, $FeGFw));
    }
    public function getFile()
    {
        return $this->N1jgO;
    }
    public function me2kPW7r3WV(array $qOvbD) : void
    {
        $this->I2jBi = $qOvbD;
    }
    public function mqwYUMOn9gH() : void
    {
        $this->muO5nIQPKS7(HGmeWpZQSxAlO::UPLOADING);
    }
    public function mGxDGBRUj3Q() : void
    {
        $this->muO5nIQPKS7(HGmeWpZQSxAlO::UPLOADED);
    }
    public function m4mw3ZqvLga() : void
    {
        $this->muO5nIQPKS7(HGmeWpZQSxAlO::PROCESSING);
    }
    public function mgJQBwKqV80() : void
    {
        $this->muO5nIQPKS7(HGmeWpZQSxAlO::FINISHED);
    }
    public function mZZl5H6bEXr() : void
    {
        $this->muO5nIQPKS7(HGmeWpZQSxAlO::ABORTED);
    }
    public function mVtrBORQO9n() : array
    {
        return $this->I2jBi;
    }
    public static function mORSzsBkcxt(string $ShXx2, $ZmJCn, $ehLvI, $ivxnu) : self
    {
        goto INTUT;
        BcF2J:
        return $jHO4v->mqtxOLuwlBz();
        goto r1nmk;
        UsKkB:
        $jHO4v->mf3bcS2aSK5(HGmeWpZQSxAlO::UPLOADING);
        goto BcF2J;
        mMdxR:
        $jHO4v = new self($Ga9Xm, $ZmJCn);
        goto r16Tr;
        r16Tr:
        $jHO4v->mcepN3rCOFn($ivxnu, $ZmJCn, $ehLvI);
        goto UsKkB;
        INTUT:
        $Ga9Xm = App::make(DpvqXIwAB5UAa::class)->mn14XV1nfnm(UAsHLG1mz8hdv::mET7etRr7Va($ShXx2));
        goto mMdxR;
        r1nmk:
    }
    public static function mS8Dcpb0iRh($Ga9Xm, $nkmCX, $NYASv, $ivxnu, $FeGFw = false) : self
    {
        goto EfZ_M;
        KkyZ7:
        $jHO4v->mcepN3rCOFn($ivxnu, $nkmCX, $NYASv, $FeGFw);
        goto nChWm;
        nChWm:
        $jHO4v->mf3bcS2aSK5(HGmeWpZQSxAlO::UPLOADING);
        goto m6vPZ;
        m6vPZ:
        return $jHO4v;
        goto cqexr;
        EfZ_M:
        $jHO4v = new self($Ga9Xm, $nkmCX);
        goto KkyZ7;
        cqexr:
    }
}
