<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\Observer\CIWm86tREgVxe;
use Jfs\Uploader\Core\OGqakwzIfzu7z;
use Jfs\Uploader\Core\Traits\Djo49vxVmVo8G;
use Jfs\Uploader\Core\Traits\CrEAGEW2Ahp7l;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Exception\HF2PbTFQhW3Rr;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Exception\ZEPVfMQDBdCIh;
use Jfs\Uploader\Service\JMS12XhOMqdv8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class S3bwZBI8SlQQZ implements MEWwofwAYqgaI
{
    use Djo49vxVmVo8G;
    use CrEAGEW2Ahp7l;
    private $pRcMh;
    private function __construct($hFrf7, $nQYui)
    {
        $this->HyWI1 = $hFrf7;
        $this->VMzF2 = $nQYui;
    }
    private function mCkBXEMCyrX(string $G2CsF, $nQYui, $jkGKh, bool $RRxCo = false) : void
    {
        $this->m1RJrReO70j(new CIWm86tREgVxe($this, $nQYui, $jkGKh, $G2CsF, $RRxCo));
    }
    public function getFile()
    {
        return $this->HyWI1;
    }
    public function mzghmmo0YQO(array $yJ3MQ) : void
    {
        $this->pRcMh = $yJ3MQ;
    }
    public function mkAB4wFX7me() : void
    {
        $this->mvlhr18w6fy(FdWrko7bmoI4Y::UPLOADING);
    }
    public function mKgTkN0NdQK() : void
    {
        $this->mvlhr18w6fy(FdWrko7bmoI4Y::UPLOADED);
    }
    public function mpGmUw1FiUx() : void
    {
        $this->mvlhr18w6fy(FdWrko7bmoI4Y::PROCESSING);
    }
    public function mIU23Rr1WEO() : void
    {
        $this->mvlhr18w6fy(FdWrko7bmoI4Y::FINISHED);
    }
    public function mVYs88Gfpix() : void
    {
        $this->mvlhr18w6fy(FdWrko7bmoI4Y::ABORTED);
    }
    public function mG4DLei2D97() : array
    {
        return $this->pRcMh;
    }
    public static function mZJaGcF41eX(string $JTwN4, $wWulN, $BQ2l1, $G2CsF) : self
    {
        goto PXFpj;
        oUyHB:
        $DmCz8 = new self($hFrf7, $wWulN);
        goto EXvQZ;
        R0YIJ:
        return $DmCz8->mT9XiaPrP4w();
        goto NZLKW;
        xc4cZ:
        $DmCz8->mocw0y5gdUS(FdWrko7bmoI4Y::UPLOADING);
        goto R0YIJ;
        EXvQZ:
        $DmCz8->mCkBXEMCyrX($G2CsF, $wWulN, $BQ2l1);
        goto xc4cZ;
        PXFpj:
        $hFrf7 = App::make(JMS12XhOMqdv8::class)->mYuIBEF54DA(OGqakwzIfzu7z::mhXMJL71B9N($JTwN4));
        goto oUyHB;
        NZLKW:
    }
    public static function m9WH9Zbzrb2($hFrf7, $nQYui, $jkGKh, $G2CsF, $RRxCo = false) : self
    {
        goto h01dw;
        n8Sv0:
        $DmCz8->mocw0y5gdUS(FdWrko7bmoI4Y::UPLOADING);
        goto HI5Me;
        h01dw:
        $DmCz8 = new self($hFrf7, $nQYui);
        goto CZxSq;
        HI5Me:
        return $DmCz8;
        goto UU75O;
        CZxSq:
        $DmCz8->mCkBXEMCyrX($G2CsF, $nQYui, $jkGKh, $RRxCo);
        goto n8Sv0;
        UU75O:
    }
}
