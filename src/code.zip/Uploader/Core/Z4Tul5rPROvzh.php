<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
final class Z4Tul5rPROvzh
{
    public $filename;
    public $YRAxZ;
    public $E428N;
    public $Etik3;
    public $QFN10;
    public $bKDFt;
    public $Upfz2;
    public $status;
    public $AjWvv;
    public $e7KJG;
    public $xiRsU = 's3';
    public $sJEjQ = [];
    public function __construct($Y84CC, $YN8Mo, $qIArj, $w1w85, $Dn1eW, $peJtM, $Aul2o, $piICF, $nBxcI, $Adfm4, $ZVbDm = 's3', $wErBB = [])
    {
        goto JUzt_;
        XH1_8:
        $this->bKDFt = $peJtM;
        goto gNlys;
        ZBh2p:
        $this->QFN10 = $Dn1eW;
        goto XH1_8;
        PGcBY:
        $this->AjWvv = $nBxcI;
        goto b0hNi;
        HtHgf:
        $this->Etik3 = $w1w85;
        goto ZBh2p;
        wBNs0:
        $this->status = $piICF;
        goto PGcBY;
        b0hNi:
        $this->e7KJG = $Adfm4;
        goto q13KA;
        tzbCr:
        $this->YRAxZ = $YN8Mo;
        goto IV3ne;
        gNlys:
        $this->Upfz2 = $Aul2o;
        goto wBNs0;
        q13KA:
        $this->xiRsU = $ZVbDm;
        goto KM7BW;
        KM7BW:
        $this->sJEjQ = $wErBB;
        goto pokey;
        IV3ne:
        $this->E428N = $qIArj;
        goto HtHgf;
        JUzt_:
        $this->filename = $Y84CC;
        goto tzbCr;
        pokey:
    }
    private static function m6y3ndpmFBp() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mi4iu6B81IO() : array
    {
        return array_flip(self::m6y3ndpmFBp());
    }
    public function toArray() : array
    {
        $YW_LY = self::m6y3ndpmFBp();
        return [$YW_LY['filename'] => $this->filename, $YW_LY['fileExtension'] => $this->YRAxZ, $YW_LY['mimeType'] => $this->E428N, $YW_LY['fileSize'] => $this->Etik3, $YW_LY['chunkSize'] => $this->QFN10, $YW_LY['checksums'] => $this->bKDFt, $YW_LY['totalChunk'] => $this->Upfz2, $YW_LY['status'] => $this->status, $YW_LY['userId'] => $this->AjWvv, $YW_LY['uploadId'] => $this->e7KJG, $YW_LY['driver'] => $this->xiRsU, $YW_LY['parts'] => $this->sJEjQ];
    }
    public static function mOmCqxONM2r(array $YEGQl) : self
    {
        $qumSq = array_flip(self::mi4iu6B81IO());
        return new self($YEGQl[$qumSq['filename']] ?? $YEGQl['filename'] ?? '', $YEGQl[$qumSq['fileExtension']] ?? $YEGQl['fileExtension'] ?? '', $YEGQl[$qumSq['mimeType']] ?? $YEGQl['mimeType'] ?? '', $YEGQl[$qumSq['fileSize']] ?? $YEGQl['fileSize'] ?? 0, $YEGQl[$qumSq['chunkSize']] ?? $YEGQl['chunkSize'] ?? 0, $YEGQl[$qumSq['checksums']] ?? $YEGQl['checksums'] ?? [], $YEGQl[$qumSq['totalChunk']] ?? $YEGQl['totalChunk'] ?? 0, $YEGQl[$qumSq['status']] ?? $YEGQl['status'] ?? 0, $YEGQl[$qumSq['userId']] ?? $YEGQl['userId'] ?? 0, $YEGQl[$qumSq['uploadId']] ?? $YEGQl['uploadId'] ?? '', $YEGQl[$qumSq['driver']] ?? $YEGQl['driver'] ?? 's3', $YEGQl[$qumSq['parts']] ?? $YEGQl['parts'] ?? []);
    }
    public static function mwsiK5ghIKF($k_I1r) : self
    {
        goto qOh5t;
        cP_r8:
        X7Drr:
        goto mOoFq;
        hTV0n:
        return self::mOmCqxONM2r($k_I1r);
        goto cP_r8;
        mOoFq:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto mVlcB;
        qOh5t:
        if (!(isset($k_I1r['fn']) || isset($k_I1r['fe']))) {
            goto X7Drr;
        }
        goto hTV0n;
        mVlcB:
    }
    public function mdX5318DZYf(string $Adfm4) : void
    {
        $this->e7KJG = $Adfm4;
    }
    public function mpxsTOv0vOY(array $wErBB) : void
    {
        $this->sJEjQ = $wErBB;
    }
    public static function m2H8Xx6sXXn($RCdwx, $EJO7R, $qM53d, $nBxcI, $Dn1eW, $peJtM, $ZVbDm)
    {
        return new self($RCdwx->getFilename(), $RCdwx->getExtension(), $EJO7R, $qM53d, $Dn1eW, $peJtM, count($peJtM), Tbw0jsMnRbOTP::UPLOADING, $nBxcI, 0, $ZVbDm, []);
    }
    public static function mAcNlszMlxW($LpGEK)
    {
        return 'metadata/' . $LpGEK . '.json';
    }
    public function mThngkFXA4R()
    {
        return 's3' === $this->xiRsU ? EzGWviwQDmAwI::S3 : EzGWviwQDmAwI::LOCAL;
    }
}
