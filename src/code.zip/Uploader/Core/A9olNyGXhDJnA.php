<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Contracts\SRErb8bXZXjuL;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\Traits\Av20P07H9bvdh;
use Jfs\Uploader\Core\Traits\VnPCfppm663dI;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Service\K2TtTNcFSFguA;
class A9olNyGXhDJnA extends NCmZ7rMVMWyvC implements LKF23eYmlDs0w
{
    use Av20P07H9bvdh;
    use VnPCfppm663dI;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $gQlRM, string $UEzod) : self
    {
        goto xeWn4;
        Fawu_:
        return $lu07a;
        goto FKQTE;
        i9alx:
        $lu07a->mXDdmT111J7(GlPuUJKmzwUJ9::UPLOADING);
        goto Fawu_;
        xeWn4:
        $lu07a = new self(['id' => $gQlRM, 'type' => $UEzod, 'status' => GlPuUJKmzwUJ9::UPLOADING]);
        goto i9alx;
        FKQTE:
    }
    public function getView() : array
    {
        $j1FXT = app(SRErb8bXZXjuL::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $j1FXT->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $j1FXT->resolveThumbnail($this)];
    }
    public static function mgsK0EwCCwS(NCmZ7rMVMWyvC $ldT2t) : A9olNyGXhDJnA
    {
        goto KzMKq;
        SuvBz:
        return (new A9olNyGXhDJnA())->fill($ldT2t->getAttributes());
        goto Kiwqg;
        KzMKq:
        if (!$ldT2t instanceof A9olNyGXhDJnA) {
            goto cV4Pu;
        }
        goto WwOvw;
        WcddU:
        cV4Pu:
        goto SuvBz;
        WwOvw:
        return $ldT2t;
        goto WcddU;
        Kiwqg:
    }
}
