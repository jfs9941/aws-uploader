<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Contracts\IqdLBxImTkuBV;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\Traits\WajBwoXLSKmXZ;
use Jfs\Uploader\Core\Traits\REDykmcLTsPcw;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Service\KS7YippgDSDNy;
class XHvEDPKBjvWLs extends GpdHFYchpZHPa implements OFkaCU82i4KNX
{
    use WajBwoXLSKmXZ;
    use REDykmcLTsPcw;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $F4nAe, string $WawPM) : self
    {
        goto ZuAuz;
        EMMwj:
        $QQOPv->mJpZf64FjYj(EHhCBxlsVyz9C::UPLOADING);
        goto KW1ke;
        KW1ke:
        return $QQOPv;
        goto apZO3;
        ZuAuz:
        $QQOPv = new self(['id' => $F4nAe, 'type' => $WawPM, 'status' => EHhCBxlsVyz9C::UPLOADING]);
        goto EMMwj;
        apZO3:
    }
    public function getView() : array
    {
        $BMXe2 = app(IqdLBxImTkuBV::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $BMXe2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $BMXe2->resolveThumbnail($this)];
    }
    public static function m6OhB7ZjjS8(GpdHFYchpZHPa $gR4Y3) : XHvEDPKBjvWLs
    {
        goto QSuMT;
        QSuMT:
        if (!$gR4Y3 instanceof XHvEDPKBjvWLs) {
            goto C12IX;
        }
        goto CMXnK;
        CMXnK:
        return $gR4Y3;
        goto AlnJ0;
        Dokx3:
        return (new XHvEDPKBjvWLs())->fill($gR4Y3->getAttributes());
        goto osCYh;
        AlnJ0:
        C12IX:
        goto Dokx3;
        osCYh:
    }
}
