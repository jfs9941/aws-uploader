<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Contracts\GuNvSDjrDhnZX;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\Traits\Rr9MHzXLd8EvR;
use Jfs\Uploader\Core\Traits\XGoBOvpn4TlTz;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Service\LNm3X2KAsSELE;
class XK5kReLMTU1ob extends KFe2ZCctciwsA implements GCZ2vyVNpj70n
{
    use Rr9MHzXLd8EvR;
    use XGoBOvpn4TlTz;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $VfJ3M, string $xY26M) : self
    {
        goto v7tfD;
        k5GXP:
        return $VWXEV;
        goto Q2LkU;
        v7tfD:
        $VWXEV = new self(['id' => $VfJ3M, 'type' => $xY26M, 'status' => EpMPhiTVzNYqA::UPLOADING]);
        goto vpo5V;
        vpo5V:
        $VWXEV->mlS5irobHNA(EpMPhiTVzNYqA::UPLOADING);
        goto k5GXP;
        Q2LkU:
    }
    public function getView() : array
    {
        $rEnse = app(GuNvSDjrDhnZX::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $rEnse->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $rEnse->resolveThumbnail($this)];
    }
    public static function m8dA7C2luFM(KFe2ZCctciwsA $Hz32I) : XK5kReLMTU1ob
    {
        goto Sxyw7;
        Sxyw7:
        if (!$Hz32I instanceof XK5kReLMTU1ob) {
            goto OPIIX;
        }
        goto XSOPZ;
        NSw48:
        return (new XK5kReLMTU1ob())->fill($Hz32I->getAttributes());
        goto vqWU2;
        XSOPZ:
        return $Hz32I;
        goto gzILx;
        gzILx:
        OPIIX:
        goto NSw48;
        vqWU2:
    }
}
