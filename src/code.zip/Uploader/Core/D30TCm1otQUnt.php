<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
final class D30TCm1otQUnt
{
    public $filename;
    public $O6Gdu;
    public $Zmd06;
    public $J6RqZ;
    public $UEMzw;
    public $GSkZ3;
    public $c5fBh;
    public $status;
    public $bgUT1;
    public $s6sgC;
    public $gUPdP = 's3';
    public $pNOXD = [];
    public function __construct($L6C5B, $qm8Ow, $LI_iG, $RYyDK, $FTk6S, $X3lTW, $Mpm0t, $DqCQq, $mN8kw, $fLy2e, $X0gtT = 's3', $NCegP = [])
    {
        goto HKWzT;
        HKWzT:
        $this->filename = $L6C5B;
        goto zN2gU;
        fA4yt:
        $this->c5fBh = $Mpm0t;
        goto S5RVj;
        S5RVj:
        $this->status = $DqCQq;
        goto QH0i6;
        Ng83d:
        $this->s6sgC = $fLy2e;
        goto fx48B;
        gww2M:
        $this->pNOXD = $NCegP;
        goto Tl7UZ;
        PFJwb:
        $this->J6RqZ = $RYyDK;
        goto mwV4Z;
        QH0i6:
        $this->bgUT1 = $mN8kw;
        goto Ng83d;
        fx48B:
        $this->gUPdP = $X0gtT;
        goto gww2M;
        fzpFl:
        $this->Zmd06 = $LI_iG;
        goto PFJwb;
        mwV4Z:
        $this->UEMzw = $FTk6S;
        goto ek2eB;
        ek2eB:
        $this->GSkZ3 = $X3lTW;
        goto fA4yt;
        zN2gU:
        $this->O6Gdu = $qm8Ow;
        goto fzpFl;
        Tl7UZ:
    }
    private static function mtz9wO1Zx0x() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mDN7Wi7FIBE() : array
    {
        return array_flip(self::mtz9wO1Zx0x());
    }
    public function toArray() : array
    {
        $Ygpwq = self::mtz9wO1Zx0x();
        return [$Ygpwq['filename'] => $this->filename, $Ygpwq['fileExtension'] => $this->O6Gdu, $Ygpwq['mimeType'] => $this->Zmd06, $Ygpwq['fileSize'] => $this->J6RqZ, $Ygpwq['chunkSize'] => $this->UEMzw, $Ygpwq['checksums'] => $this->GSkZ3, $Ygpwq['totalChunk'] => $this->c5fBh, $Ygpwq['status'] => $this->status, $Ygpwq['userId'] => $this->bgUT1, $Ygpwq['uploadId'] => $this->s6sgC, $Ygpwq['driver'] => $this->gUPdP, $Ygpwq['parts'] => $this->pNOXD];
    }
    public static function mXUAOPT49dG(array $renJK) : self
    {
        $hWW4T = array_flip(self::mDN7Wi7FIBE());
        return new self($renJK[$hWW4T['filename']] ?? $renJK['filename'] ?? '', $renJK[$hWW4T['fileExtension']] ?? $renJK['fileExtension'] ?? '', $renJK[$hWW4T['mimeType']] ?? $renJK['mimeType'] ?? '', $renJK[$hWW4T['fileSize']] ?? $renJK['fileSize'] ?? 0, $renJK[$hWW4T['chunkSize']] ?? $renJK['chunkSize'] ?? 0, $renJK[$hWW4T['checksums']] ?? $renJK['checksums'] ?? [], $renJK[$hWW4T['totalChunk']] ?? $renJK['totalChunk'] ?? 0, $renJK[$hWW4T['status']] ?? $renJK['status'] ?? 0, $renJK[$hWW4T['userId']] ?? $renJK['userId'] ?? 0, $renJK[$hWW4T['uploadId']] ?? $renJK['uploadId'] ?? '', $renJK[$hWW4T['driver']] ?? $renJK['driver'] ?? 's3', $renJK[$hWW4T['parts']] ?? $renJK['parts'] ?? []);
    }
    public static function mRt62ufLGnj($QUIbE) : self
    {
        goto iN_Ve;
        FlBen:
        return self::mXUAOPT49dG($QUIbE);
        goto dfudE;
        P3M0e:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto LDDh9;
        dfudE:
        uycT6:
        goto P3M0e;
        iN_Ve:
        if (!(isset($QUIbE['fn']) || isset($QUIbE['fe']))) {
            goto uycT6;
        }
        goto FlBen;
        LDDh9:
    }
    public function mI5wGiFDJrK(string $fLy2e) : void
    {
        $this->s6sgC = $fLy2e;
    }
    public function mkpVwrkBWKg(array $NCegP) : void
    {
        $this->pNOXD = $NCegP;
    }
    public static function mSd5AOmkql6($gNVOT, $OU6uU, $M6km1, $mN8kw, $FTk6S, $X3lTW, $X0gtT)
    {
        return new self($gNVOT->getFilename(), $gNVOT->getExtension(), $OU6uU, $M6km1, $FTk6S, $X3lTW, count($X3lTW), EHhCBxlsVyz9C::UPLOADING, $mN8kw, 0, $X0gtT, []);
    }
    public static function mttyt25rY1Q($S580N)
    {
        return 'metadata/' . $S580N . '.json';
    }
    public function mS69GwwTS4W()
    {
        return 's3' === $this->gUPdP ? McZXbZmlQ53or::S3 : McZXbZmlQ53or::LOCAL;
    }
}
