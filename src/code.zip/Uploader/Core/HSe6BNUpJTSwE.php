<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Core\Traits\OoN59oKA3bVp5;
use Jfs\Uploader\Core\Traits\GzYkrJxGq9goW;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Service\XsyK4RfzqtWuF;
class HSe6BNUpJTSwE extends DYGJpbj9Ye8wY implements M9ges0moH9yTs
{
    use OoN59oKA3bVp5;
    use GzYkrJxGq9goW;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $IW90g, string $ffCXh) : self
    {
        goto YBybM;
        YBybM:
        $IS6o1 = new self(['id' => $IW90g, 'type' => $ffCXh, 'status' => U8OFutptQGm3S::UPLOADING]);
        goto aFA1_;
        eB1Zj:
        return $IS6o1;
        goto r8qpu;
        aFA1_:
        $IS6o1->mM8xXTkFSyC(U8OFutptQGm3S::UPLOADING);
        goto eB1Zj;
        r8qpu:
    }
    public function getView() : array
    {
        $USeiP = app(ZOxMhYUF0fAsi::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $USeiP->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $USeiP->resolveThumbnail($this)];
    }
    public static function mFQn0UlhghW(DYGJpbj9Ye8wY $bcJEK) : HSe6BNUpJTSwE
    {
        goto iPd3n;
        TYdjk:
        Y_6Xz:
        goto dRRqw;
        dRRqw:
        return (new HSe6BNUpJTSwE())->fill($bcJEK->getAttributes());
        goto plzYh;
        iPd3n:
        if (!$bcJEK instanceof HSe6BNUpJTSwE) {
            goto Y_6Xz;
        }
        goto l3i3y;
        l3i3y:
        return $bcJEK;
        goto TYdjk;
        plzYh:
    }
}
