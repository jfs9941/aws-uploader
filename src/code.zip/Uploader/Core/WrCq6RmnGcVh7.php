<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Contracts\VdjamMvtIkwfN;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\Traits\U1oUBtFUca4cm;
use Jfs\Uploader\Core\Traits\GYCzFqUkUYdjE;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
class WrCq6RmnGcVh7 extends VMj30iBgKeeJB implements SOB6nK7CGVegh
{
    use U1oUBtFUca4cm;
    use GYCzFqUkUYdjE;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $xRxub, string $Lmvwp) : self
    {
        goto Oq7JW;
        Urdun:
        $XrW52->mUg6EMktQTd(Xy3InMky6jKYf::UPLOADING);
        goto uu09j;
        Oq7JW:
        $XrW52 = new self(['id' => $xRxub, 'type' => $Lmvwp, 'status' => Xy3InMky6jKYf::UPLOADING]);
        goto Urdun;
        uu09j:
        return $XrW52;
        goto peXn7;
        peXn7:
    }
    public function width() : ?int
    {
        goto zHEhy;
        zHEhy:
        $bvCsS = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto aNrjO;
        pdCRv:
        iY299:
        goto U6mlY;
        aNrjO:
        if (!$bvCsS) {
            goto iY299;
        }
        goto u9zlE;
        u9zlE:
        return $bvCsS;
        goto pdCRv;
        U6mlY:
        return null;
        goto dUnfn;
        dUnfn:
    }
    public function height() : ?int
    {
        goto ZYldG;
        cRXUK:
        YnAbV:
        goto t5eJY;
        t5eJY:
        return null;
        goto pQutg;
        QcC3d:
        return $WEPGl;
        goto cRXUK;
        ZYldG:
        $WEPGl = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto UIete;
        UIete:
        if (!$WEPGl) {
            goto YnAbV;
        }
        goto QcC3d;
        pQutg:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($XrW52) {
            goto MXx8n;
            FPmnH:
            bc4um:
            goto opmve;
            opmve:
            if (!($nHwsV['thumbnail'] || $nHwsV['hls_path'])) {
                goto NtHPi;
            }
            goto vnJP9;
            Tr_0L:
            NtHPi:
            goto lGOu3;
            MXx8n:
            $nHwsV = $XrW52->getDirty();
            goto bqJn1;
            vnJP9:
            WrCq6RmnGcVh7::where('parent_id', $XrW52->getAttribute('id'))->update(['thumbnail' => $XrW52->getAttributes()['thumbnail'], 'hls_path' => $XrW52->getAttributes()['hls_path']]);
            goto Tr_0L;
            JLPIi:
            return;
            goto FPmnH;
            bqJn1:
            if (!(!array_key_exists('thumbnail', $nHwsV) && !array_key_exists('hls_path', $nHwsV))) {
                goto bc4um;
            }
            goto JLPIi;
            lGOu3:
        });
    }
    public function mN4KrajeB1s()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mjpa9kEN1qt()
    {
        return $this->getAttribute('id');
    }
    public function mRQns5hMdU2() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto BpUaK;
        qnc2x:
        $dBRu8['thumbnail'] = $FSDPH->resolveThumbnail($this);
        goto MGSE9;
        Q7AJG:
        $dBRu8 = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $FSDPH->resolvePath($this, $this->getAttribute('driver'))];
        goto ttv24;
        Q4Szf:
        xmMSI:
        goto qnc2x;
        BpUaK:
        $FSDPH = app(VdjamMvtIkwfN::class);
        goto Q7AJG;
        INMLx:
        goto xmMSI;
        goto j0ass;
        j0ass:
        rVbMz:
        goto ITi8C;
        ITi8C:
        $dBRu8['player_url'] = $FSDPH->resolvePathForHlsVideo($this, true);
        goto Q4Szf;
        MGSE9:
        return $dBRu8;
        goto kuoLt;
        ttv24:
        if ($this->getAttribute('hls_path')) {
            goto rVbMz;
        }
        goto CrBft;
        CrBft:
        $dBRu8['player_url'] = $FSDPH->resolvePath($this, $this->getAttribute('driver'));
        goto INMLx;
        kuoLt:
    }
    public function getThumbnails()
    {
        goto rIlxi;
        vIloH:
        $FSDPH = app(VdjamMvtIkwfN::class);
        goto zvaOd;
        rIlxi:
        $Di9XS = $this->getAttribute('generated_previews') ?? [];
        goto vIloH;
        zvaOd:
        return array_map(function ($EpLlV) use($FSDPH) {
            return $FSDPH->resolvePath($EpLlV);
        }, $Di9XS);
        goto GQf83;
        GQf83:
    }
    public static function mG7JHVfK7iz(VMj30iBgKeeJB $XcVxI) : WrCq6RmnGcVh7
    {
        goto p9GEB;
        t1LMA:
        VTbjc:
        goto nl8LG;
        p9GEB:
        if (!$XcVxI instanceof WrCq6RmnGcVh7) {
            goto VTbjc;
        }
        goto EuF25;
        nl8LG:
        return (new WrCq6RmnGcVh7())->fill($XcVxI->getAttributes());
        goto QJKr8;
        EuF25:
        return $XcVxI;
        goto t1LMA;
        QJKr8:
    }
}
