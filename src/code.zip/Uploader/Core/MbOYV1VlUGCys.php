<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Contracts\QPcmBScQDUpcH;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Traits\XU255kYjU0NUS;
use Jfs\Uploader\Core\Traits\CrEAGEW2Ahp7l;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
class MbOYV1VlUGCys extends MEyH4ejCzSk64 implements MEWwofwAYqgaI
{
    use XU255kYjU0NUS;
    use CrEAGEW2Ahp7l;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $pODrs, string $iJrca) : self
    {
        goto SvZVg;
        vTeKN:
        $B4_PH->mocw0y5gdUS(FdWrko7bmoI4Y::UPLOADING);
        goto smFz6;
        smFz6:
        return $B4_PH;
        goto YdMCK;
        SvZVg:
        $B4_PH = new self(['id' => $pODrs, 'type' => $iJrca, 'status' => FdWrko7bmoI4Y::UPLOADING]);
        goto vTeKN;
        YdMCK:
    }
    public function width() : ?int
    {
        goto M3FqW;
        lwG2E:
        if (!$SAWrT) {
            goto cl5B0;
        }
        goto a8X6p;
        M3FqW:
        $SAWrT = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto lwG2E;
        a8X6p:
        return $SAWrT;
        goto hAgys;
        hAgys:
        cl5B0:
        goto XewjA;
        XewjA:
        return null;
        goto hSxT_;
        hSxT_:
    }
    public function height() : ?int
    {
        goto s5izn;
        s5izn:
        $rnPww = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto QkE3z;
        n6Csk:
        DARZx:
        goto bQG3F;
        QkE3z:
        if (!$rnPww) {
            goto DARZx;
        }
        goto pvqKA;
        bQG3F:
        return null;
        goto shdcs;
        pvqKA:
        return $rnPww;
        goto n6Csk;
        shdcs:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($B4_PH) {
            goto xAav3;
            P34YJ:
            if (!(!array_key_exists('thumbnail', $og4Q0) && !array_key_exists('hls_path', $og4Q0))) {
                goto O1Sb6;
            }
            goto u1r9N;
            xAav3:
            $og4Q0 = $B4_PH->getDirty();
            goto P34YJ;
            Arate:
            O1Sb6:
            goto HTVHG;
            u1r9N:
            return;
            goto Arate;
            QWQq1:
            MbOYV1VlUGCys::where('parent_id', $B4_PH->getAttribute('id'))->update(['thumbnail' => $B4_PH->getAttributes()['thumbnail'], 'hls_path' => $B4_PH->getAttributes()['hls_path']]);
            goto j0L2u;
            j0L2u:
            Sjs8e:
            goto QBgNX;
            HTVHG:
            if (!($og4Q0['thumbnail'] || $og4Q0['hls_path'])) {
                goto Sjs8e;
            }
            goto QWQq1;
            QBgNX:
        });
    }
    public function mFFCcYamld2()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mHcW5j5o7V5()
    {
        return $this->getAttribute('id');
    }
    public function meAUtXAL5iT() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto kUblA;
        rvqsF:
        W7wb3:
        goto sG1It;
        kUblA:
        $jku3P = app(QPcmBScQDUpcH::class);
        goto Q5ufv;
        YEj3I:
        $M7zOf['player_url'] = $jku3P->resolvePath($this, $this->getAttribute('driver'));
        goto J1rF0;
        TNH7V:
        return $M7zOf;
        goto L9DEk;
        B_bxn:
        $M7zOf['thumbnail'] = $jku3P->resolveThumbnail($this);
        goto TNH7V;
        rp9MF:
        nkP10:
        goto B_bxn;
        J1rF0:
        goto nkP10;
        goto rvqsF;
        Q5ufv:
        $M7zOf = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $jku3P->resolvePath($this, $this->getAttribute('driver'))];
        goto X4h3i;
        X4h3i:
        if ($this->getAttribute('hls_path')) {
            goto W7wb3;
        }
        goto YEj3I;
        sG1It:
        $M7zOf['player_url'] = $jku3P->resolvePathForHlsVideo($this, true);
        goto rp9MF;
        L9DEk:
    }
    public function getThumbnails()
    {
        goto uKECA;
        nEIBh:
        return array_map(function ($fMTw4) use($jku3P) {
            return $jku3P->resolvePath($fMTw4);
        }, $gi5Ph);
        goto CMOwv;
        e0dwF:
        $jku3P = app(QPcmBScQDUpcH::class);
        goto nEIBh;
        uKECA:
        $gi5Ph = $this->getAttribute('generated_previews') ?? [];
        goto e0dwF;
        CMOwv:
    }
    public static function mll4R4Tup3I(MEyH4ejCzSk64 $pkR_A) : MbOYV1VlUGCys
    {
        goto bqZ93;
        EzL_P:
        return $pkR_A;
        goto R6rXQ;
        bqZ93:
        if (!$pkR_A instanceof MbOYV1VlUGCys) {
            goto FfA0T;
        }
        goto EzL_P;
        CZq8f:
        return (new MbOYV1VlUGCys())->fill($pkR_A->getAttributes());
        goto JuMDz;
        R6rXQ:
        FfA0T:
        goto CZq8f;
        JuMDz:
    }
}
