<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
final class FB4qGXxRRUqXX
{
    public $filename;
    public $zx_Nm;
    public $NhJsW;
    public $BjjEq;
    public $Z119c;
    public $uWPVa;
    public $oKsce;
    public $status;
    public $PKfbA;
    public $MSlst;
    public $driver = 's3';
    public $vb8UL = [];
    public function __construct($KwVnZ, $t0nwn, $c2R7J, $Zx9Iw, $PXFo7, $gFfDX, $M3KWX, $CWcDk, $VrvwN, $tNwGR, $dHaKA = 's3', $p4mmG = [])
    {
        goto KOQo5;
        hkvDD:
        $this->NhJsW = $c2R7J;
        goto PKnQz;
        p2QxL:
        $this->driver = $dHaKA;
        goto oO1QE;
        oO1QE:
        $this->vb8UL = $p4mmG;
        goto Vqpv8;
        gxRJv:
        $this->Z119c = $PXFo7;
        goto axOFG;
        KOQo5:
        $this->filename = $KwVnZ;
        goto aqOZd;
        nkCPv:
        $this->status = $CWcDk;
        goto EYp4p;
        CRe1D:
        $this->oKsce = $M3KWX;
        goto nkCPv;
        EYp4p:
        $this->PKfbA = $VrvwN;
        goto Do9Kn;
        Do9Kn:
        $this->MSlst = $tNwGR;
        goto p2QxL;
        axOFG:
        $this->uWPVa = $gFfDX;
        goto CRe1D;
        aqOZd:
        $this->zx_Nm = $t0nwn;
        goto hkvDD;
        PKnQz:
        $this->BjjEq = $Zx9Iw;
        goto gxRJv;
        Vqpv8:
    }
    private static function mrNHJ1uLfdX() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mAPvCZdS3cX() : array
    {
        return array_flip(self::mrNHJ1uLfdX());
    }
    public function toArray() : array
    {
        $Cg_8l = self::mrNHJ1uLfdX();
        return [$Cg_8l['filename'] => $this->filename, $Cg_8l['fileExtension'] => $this->zx_Nm, $Cg_8l['mimeType'] => $this->NhJsW, $Cg_8l['fileSize'] => $this->BjjEq, $Cg_8l['chunkSize'] => $this->Z119c, $Cg_8l['checksums'] => $this->uWPVa, $Cg_8l['totalChunk'] => $this->oKsce, $Cg_8l['status'] => $this->status, $Cg_8l['userId'] => $this->PKfbA, $Cg_8l['uploadId'] => $this->MSlst, $Cg_8l['driver'] => $this->driver, $Cg_8l['parts'] => $this->vb8UL];
    }
    public static function m6bQG3bcuL0(array $WRcga) : self
    {
        $SPxSh = array_flip(self::mAPvCZdS3cX());
        return new self($WRcga[$SPxSh['filename']] ?? $WRcga['filename'] ?? '', $WRcga[$SPxSh['fileExtension']] ?? $WRcga['fileExtension'] ?? '', $WRcga[$SPxSh['mimeType']] ?? $WRcga['mimeType'] ?? '', $WRcga[$SPxSh['fileSize']] ?? $WRcga['fileSize'] ?? 0, $WRcga[$SPxSh['chunkSize']] ?? $WRcga['chunkSize'] ?? 0, $WRcga[$SPxSh['checksums']] ?? $WRcga['checksums'] ?? [], $WRcga[$SPxSh['totalChunk']] ?? $WRcga['totalChunk'] ?? 0, $WRcga[$SPxSh['status']] ?? $WRcga['status'] ?? 0, $WRcga[$SPxSh['userId']] ?? $WRcga['userId'] ?? 0, $WRcga[$SPxSh['uploadId']] ?? $WRcga['uploadId'] ?? '', $WRcga[$SPxSh['driver']] ?? $WRcga['driver'] ?? 's3', $WRcga[$SPxSh['parts']] ?? $WRcga['parts'] ?? []);
    }
    public static function mL8fXp7GapT($Vw4vH) : self
    {
        goto LM3mf;
        gPKv_:
        return self::m6bQG3bcuL0($Vw4vH);
        goto G7XJl;
        LM3mf:
        if (!(isset($Vw4vH['fn']) || isset($Vw4vH['fe']))) {
            goto lAxcL;
        }
        goto gPKv_;
        Jod4o:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto sbj27;
        G7XJl:
        lAxcL:
        goto Jod4o;
        sbj27:
    }
    public function mWwcN6VbLRG(string $tNwGR) : void
    {
        $this->MSlst = $tNwGR;
    }
    public function mPDjkmS6FtI(array $p4mmG) : void
    {
        $this->vb8UL = $p4mmG;
    }
    public static function mrKiRXtHFiM($z620p, $uVy4X, $xOMrY, $VrvwN, $PXFo7, $gFfDX, $dHaKA)
    {
        return new self($z620p->getFilename(), $z620p->getExtension(), $uVy4X, $xOMrY, $PXFo7, $gFfDX, count($gFfDX), QE1dzvgcPWV6R::UPLOADING, $VrvwN, 0, $dHaKA, []);
    }
    public static function m8Fi26WGLR3($SEOXv)
    {
        return 'metadata/' . $SEOXv . '.json';
    }
    public function mVYxyAg5des()
    {
        return 's3' === $this->driver ? Rf7fPQasmK9R3::S3 : Rf7fPQasmK9R3::LOCAL;
    }
}
