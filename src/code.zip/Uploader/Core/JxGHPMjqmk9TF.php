<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\Observer\DwX8kmn6uBEGI;
use Jfs\Uploader\Core\YcADon3ndBWYh;
use Jfs\Uploader\Core\Traits\PAzi2oHGgzfy1;
use Jfs\Uploader\Core\Traits\V5MfgbTUETSZ1;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Exception\F8y1xdPRStgQx;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Exception\DDrY5gI5aE4u5;
use Jfs\Uploader\Service\P8Uf7dWabbyOG;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class JxGHPMjqmk9TF implements ZEs3XZLglwgUu
{
    use PAzi2oHGgzfy1;
    use V5MfgbTUETSZ1;
    private $lQi2c;
    private function __construct($ZQzpf, $MKJ1D)
    {
        $this->bQMHT = $ZQzpf;
        $this->LI84V = $MKJ1D;
    }
    private function mzpEEjotmiI(string $b7Jn7, $MKJ1D, $niM9V, bool $tyCON = false) : void
    {
        $this->mfE5Wdi7XQV(new DwX8kmn6uBEGI($this, $MKJ1D, $niM9V, $b7Jn7, $tyCON));
    }
    public function getFile()
    {
        return $this->bQMHT;
    }
    public function mnUNm6Udcoe(array $vFSEz) : void
    {
        $this->lQi2c = $vFSEz;
    }
    public function mvO2oUl7xnV() : void
    {
        $this->mzoKjbCd8Ap(ZVJoOgH14iXBq::UPLOADING);
    }
    public function merteJGz1sz() : void
    {
        $this->mzoKjbCd8Ap(ZVJoOgH14iXBq::UPLOADED);
    }
    public function mjj6gPMGYbo() : void
    {
        $this->mzoKjbCd8Ap(ZVJoOgH14iXBq::PROCESSING);
    }
    public function ml1mJhuT6E0() : void
    {
        $this->mzoKjbCd8Ap(ZVJoOgH14iXBq::FINISHED);
    }
    public function mnYi7oWpgZr() : void
    {
        $this->mzoKjbCd8Ap(ZVJoOgH14iXBq::ABORTED);
    }
    public function mo3Tm9vFFgH() : array
    {
        return $this->lQi2c;
    }
    public static function m1ImageHwyB(string $Brk87, $vKS3S, $Npup8, $b7Jn7) : self
    {
        goto vZK3V;
        vZK3V:
        $ZQzpf = App::make(P8Uf7dWabbyOG::class)->mliyzdgKEaf(YcADon3ndBWYh::mIt0SPRbc2O($Brk87));
        goto BgZv2;
        DA_4r:
        $UbzPE->mzpEEjotmiI($b7Jn7, $vKS3S, $Npup8);
        goto To91g;
        To91g:
        $UbzPE->mWCCmTIigqB(ZVJoOgH14iXBq::UPLOADING);
        goto RXTq5;
        BgZv2:
        $UbzPE = new self($ZQzpf, $vKS3S);
        goto DA_4r;
        RXTq5:
        return $UbzPE->mDgZl126LWl();
        goto rneOQ;
        rneOQ:
    }
    public static function mLtryTMXpSi($ZQzpf, $MKJ1D, $niM9V, $b7Jn7, $tyCON = false) : self
    {
        goto wy9Ig;
        wy9Ig:
        $UbzPE = new self($ZQzpf, $MKJ1D);
        goto lf3oL;
        hJmaU:
        $UbzPE->mWCCmTIigqB(ZVJoOgH14iXBq::UPLOADING);
        goto Wl8NW;
        Wl8NW:
        return $UbzPE;
        goto q7Yef;
        lf3oL:
        $UbzPE->mzpEEjotmiI($b7Jn7, $MKJ1D, $niM9V, $tyCON);
        goto hJmaU;
        q7Yef:
    }
}
