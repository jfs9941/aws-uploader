<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\Observer\ZEWJYx5y5FQrR;
use Jfs\Uploader\Core\ZCG0C7zP3e4el;
use Jfs\Uploader\Core\Traits\Ov5cqt5Xsb84C;
use Jfs\Uploader\Core\Traits\KfSjQVQJRLwh3;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Exception\CBStNIBT6cwK0;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Exception\TLy3l2bn56lcq;
use Jfs\Uploader\Service\XaaDhpdqTL9N3;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class TN0vqVlBODTOO implements Fk274vNY0LJnp
{
    use Ov5cqt5Xsb84C;
    use KfSjQVQJRLwh3;
    private $M9fWk;
    private function __construct($Z5ydB, $zDbHT)
    {
        $this->YG65u = $Z5ydB;
        $this->Bg6wE = $zDbHT;
    }
    private function mFtadEYLhEn(string $C1Y4p, $zDbHT, $pbv6a, bool $nzIne = false) : void
    {
        $this->m3qxyKjPsWx(new ZEWJYx5y5FQrR($this, $zDbHT, $pbv6a, $C1Y4p, $nzIne));
    }
    public function getFile()
    {
        return $this->YG65u;
    }
    public function mG9NRD5Z2bQ(array $sFZUU) : void
    {
        $this->M9fWk = $sFZUU;
    }
    public function m2ofC0YgLEm() : void
    {
        $this->mpDdU9lVtpc(M7O7NSiJU2JG5::UPLOADING);
    }
    public function mDZARaYuIOd() : void
    {
        $this->mpDdU9lVtpc(M7O7NSiJU2JG5::UPLOADED);
    }
    public function mraPUzzIjKw() : void
    {
        $this->mpDdU9lVtpc(M7O7NSiJU2JG5::PROCESSING);
    }
    public function miKCeZObvHV() : void
    {
        $this->mpDdU9lVtpc(M7O7NSiJU2JG5::FINISHED);
    }
    public function mLDJoHspaWH() : void
    {
        $this->mpDdU9lVtpc(M7O7NSiJU2JG5::ABORTED);
    }
    public function mWg9QPOd0Lf() : array
    {
        return $this->M9fWk;
    }
    public static function mjR3Q7dHYyO(string $zV1kl, $NwFFB, $iay5S, $C1Y4p) : self
    {
        goto NEGJs;
        NEGJs:
        $Z5ydB = App::make(XaaDhpdqTL9N3::class)->mKop8RuHqqs(ZCG0C7zP3e4el::mG6OVqlq12t($zV1kl));
        goto b7p6N;
        XpKnX:
        return $S3FJC->mox8patr0N6();
        goto Ngg51;
        JJbG8:
        $S3FJC->mFtadEYLhEn($C1Y4p, $NwFFB, $iay5S);
        goto Z2o0I;
        b7p6N:
        $S3FJC = new self($Z5ydB, $NwFFB);
        goto JJbG8;
        Z2o0I:
        $S3FJC->mJf7701KMEl(M7O7NSiJU2JG5::UPLOADING);
        goto XpKnX;
        Ngg51:
    }
    public static function mQGhDqDDpV5($Z5ydB, $zDbHT, $pbv6a, $C1Y4p, $nzIne = false) : self
    {
        goto xIeBV;
        rR8kU:
        $S3FJC->mJf7701KMEl(M7O7NSiJU2JG5::UPLOADING);
        goto vHttJ;
        xIeBV:
        $S3FJC = new self($Z5ydB, $zDbHT);
        goto wbXOF;
        wbXOF:
        $S3FJC->mFtadEYLhEn($C1Y4p, $zDbHT, $pbv6a, $nzIne);
        goto rR8kU;
        vHttJ:
        return $S3FJC;
        goto z_6tN;
        z_6tN:
    }
}
