<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\Observer\UBpTHcMNCaMb2;
use Jfs\Uploader\Core\A4nixFDruB7ul;
use Jfs\Uploader\Core\Traits\RIWOC6w2gQhJW;
use Jfs\Uploader\Core\Traits\IkSz95bOOEAyh;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Exception\LDB12Ub0rXHOx;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Exception\Eau0ZADkUwi6b;
use Jfs\Uploader\Service\JVjr2CUQxg9ep;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Hm5kuVZJdTKtj implements B7NusEU08Li4E
{
    use RIWOC6w2gQhJW;
    use IkSz95bOOEAyh;
    private $Yb3AY;
    private function __construct($clm2Y, $kVG4M)
    {
        $this->EidfR = $clm2Y;
        $this->i9lKp = $kVG4M;
    }
    private function mB2JVsHdBr8(string $Jkr71, $kVG4M, $crBgX, bool $QLYMl = false) : void
    {
        $this->mme8vGqglZH(new UBpTHcMNCaMb2($this, $kVG4M, $crBgX, $Jkr71, $QLYMl));
    }
    public function getFile()
    {
        return $this->EidfR;
    }
    public function mbYvNurXiYp(array $ZSVuf) : void
    {
        $this->Yb3AY = $ZSVuf;
    }
    public function mquAMRxtIy1() : void
    {
        $this->mfzy7DteKHJ(KidkTsWIjmNMb::UPLOADING);
    }
    public function mvC383jw5Pn() : void
    {
        $this->mfzy7DteKHJ(KidkTsWIjmNMb::UPLOADED);
    }
    public function mNEe3D8nMJc() : void
    {
        $this->mfzy7DteKHJ(KidkTsWIjmNMb::PROCESSING);
    }
    public function moi51oZ3ZVJ() : void
    {
        $this->mfzy7DteKHJ(KidkTsWIjmNMb::FINISHED);
    }
    public function mOojEH10uoP() : void
    {
        $this->mfzy7DteKHJ(KidkTsWIjmNMb::ABORTED);
    }
    public function mhxGN0alAfz() : array
    {
        return $this->Yb3AY;
    }
    public static function m97qZMsyYLc(string $B5uQ4, $O0rb2, $v70jj, $Jkr71) : self
    {
        goto j874F;
        j874F:
        $clm2Y = App::make(JVjr2CUQxg9ep::class)->mv7PwR2Y278(A4nixFDruB7ul::msagmj6oOxB($B5uQ4));
        goto XCZZ3;
        XCZZ3:
        $UeLlB = new self($clm2Y, $O0rb2);
        goto T039t;
        bK3u_:
        return $UeLlB->mB6MUhGhdzp();
        goto i0pRG;
        T039t:
        $UeLlB->mB2JVsHdBr8($Jkr71, $O0rb2, $v70jj);
        goto CKJw_;
        CKJw_:
        $UeLlB->moSEUBFRxDt(KidkTsWIjmNMb::UPLOADING);
        goto bK3u_;
        i0pRG:
    }
    public static function mF4HpoMwsvA($clm2Y, $kVG4M, $crBgX, $Jkr71, $QLYMl = false) : self
    {
        goto sH2tL;
        ZLEcV:
        return $UeLlB;
        goto gf3s_;
        sH2tL:
        $UeLlB = new self($clm2Y, $kVG4M);
        goto kOPZs;
        kOPZs:
        $UeLlB->mB2JVsHdBr8($Jkr71, $kVG4M, $crBgX, $QLYMl);
        goto hm6MI;
        hm6MI:
        $UeLlB->moSEUBFRxDt(KidkTsWIjmNMb::UPLOADING);
        goto ZLEcV;
        gf3s_:
    }
}
