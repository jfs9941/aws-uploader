<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Uploader\Core\Traits\Tfhsv7YHW7wn7;
use Jfs\Uploader\Core\Traits\ZLQWnjuT7vx15;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Service\EBtMKqg57Ah66;
class YPgQPiPQjMu1g extends LfWCTOqty2Slr implements EknRcwWhw5aDZ
{
    use Tfhsv7YHW7wn7;
    use ZLQWnjuT7vx15;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $VjmOq, string $H2Bah) : self
    {
        goto TOznv;
        K6qyX:
        return $fe3pc;
        goto tHeuN;
        N2LF9:
        $fe3pc->mfeKnFzyMNC(OLX71luAn6XnP::UPLOADING);
        goto K6qyX;
        TOznv:
        $fe3pc = new self(['id' => $VjmOq, 'type' => $H2Bah, 'status' => OLX71luAn6XnP::UPLOADING]);
        goto N2LF9;
        tHeuN:
    }
    public function getView() : array
    {
        $vo0Bx = app(TC3rpsU2GuKAE::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $vo0Bx->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $vo0Bx->resolveThumbnail($this)];
    }
    public static function mVqWOcOPhht(LfWCTOqty2Slr $FjxfJ) : YPgQPiPQjMu1g
    {
        goto uZyOv;
        OaLfu:
        return (new YPgQPiPQjMu1g())->fill($FjxfJ->getAttributes());
        goto ioAwj;
        jrfwd:
        YibzH:
        goto OaLfu;
        uZyOv:
        if (!$FjxfJ instanceof YPgQPiPQjMu1g) {
            goto YibzH;
        }
        goto Ui090;
        Ui090:
        return $FjxfJ;
        goto jrfwd;
        ioAwj:
    }
}
