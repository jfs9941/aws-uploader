<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Uploader\Core\Traits\LQpqxojWwaLgF;
use Jfs\Uploader\Core\Traits\MMUGtmaorqREX;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class GXtnGiMmIPEIc extends UKWxL8i4Jx2NZ implements SK7fSNbDSRmCO
{
    use LQpqxojWwaLgF;
    use MMUGtmaorqREX;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $ksTON, string $GXi3I) : self
    {
        goto HvHuT;
        HvHuT:
        $aiCaH = new self(['id' => $ksTON, 'type' => $GXi3I, 'status' => RwOJkCXwa9RQz::UPLOADING]);
        goto gbTbd;
        WU7BD:
        return $aiCaH;
        goto Tb8OH;
        gbTbd:
        $aiCaH->m3zp1EoQeXc(RwOJkCXwa9RQz::UPLOADING);
        goto WU7BD;
        Tb8OH:
    }
    public function width() : ?int
    {
        goto nNWX8;
        ZSfsv:
        bukcU:
        goto GtYfo;
        nNWX8:
        $K2lK4 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto kEK1_;
        yViRT:
        return $K2lK4;
        goto ZSfsv;
        kEK1_:
        if (!$K2lK4) {
            goto bukcU;
        }
        goto yViRT;
        GtYfo:
        return null;
        goto iqPM4;
        iqPM4:
    }
    public function height() : ?int
    {
        goto WQ4pe;
        nQmOc:
        return $Mq4V6;
        goto htYdD;
        WQ4pe:
        $Mq4V6 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto t56_v;
        Hpp1h:
        return null;
        goto TuzbZ;
        t56_v:
        if (!$Mq4V6) {
            goto NcpsL;
        }
        goto nQmOc;
        htYdD:
        NcpsL:
        goto Hpp1h;
        TuzbZ:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($aiCaH) {
            goto wBi9i;
            jGiA3:
            lMGuC:
            goto yCouX;
            bhXJ8:
            GXtnGiMmIPEIc::where('parent_id', $aiCaH->getAttribute('id'))->update(['thumbnail' => $aiCaH->getAttributes()['thumbnail'], 'hls_path' => $aiCaH->getAttributes()['hls_path']]);
            goto jGiA3;
            h90WE:
            return;
            goto X4gwD;
            EYZay:
            if (!(!array_key_exists('thumbnail', $KXd3O) && !array_key_exists('hls_path', $KXd3O))) {
                goto JDZNa;
            }
            goto h90WE;
            X4gwD:
            JDZNa:
            goto DChKQ;
            wBi9i:
            $KXd3O = $aiCaH->getDirty();
            goto EYZay;
            DChKQ:
            if (!($KXd3O['thumbnail'] || $KXd3O['hls_path'])) {
                goto lMGuC;
            }
            goto bhXJ8;
            yCouX:
        });
    }
    public function mDj9AhmTQ5a()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mR1WoDGLpc0()
    {
        return $this->getAttribute('id');
    }
    public function mvgKPBGbzn9() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto yZvIH;
        NHnGE:
        if ($this->getAttribute('hls_path')) {
            goto jJ5ZN;
        }
        goto wLFtT;
        WwLh5:
        $UY4mB = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $FAUo0->resolvePath($this, $this->getAttribute('driver'))];
        goto NHnGE;
        chFSg:
        return $UY4mB;
        goto uJgX6;
        Poa59:
        $UY4mB['thumbnail'] = $FAUo0->resolveThumbnail($this);
        goto chFSg;
        wLFtT:
        $UY4mB['player_url'] = $FAUo0->resolvePath($this, $this->getAttribute('driver'));
        goto das34;
        Tsjlj:
        $UY4mB['player_url'] = $FAUo0->resolvePathForHlsVideo($this, true);
        goto iv_Wr;
        yZvIH:
        $FAUo0 = app(QhwgYzl056fwk::class);
        goto WwLh5;
        iv_Wr:
        NKnNb:
        goto Poa59;
        vlOwF:
        jJ5ZN:
        goto Tsjlj;
        das34:
        goto NKnNb;
        goto vlOwF;
        uJgX6:
    }
    public function getThumbnails()
    {
        goto lm7LN;
        M0zZn:
        return array_map(function ($qqIkT) use($FAUo0) {
            return $FAUo0->resolvePath($qqIkT);
        }, $WjUFj);
        goto S2yvn;
        D3sR5:
        $FAUo0 = app(QhwgYzl056fwk::class);
        goto M0zZn;
        lm7LN:
        $WjUFj = $this->getAttribute('generated_previews') ?? [];
        goto D3sR5;
        S2yvn:
    }
    public static function mQW5oMLynde(UKWxL8i4Jx2NZ $xKDWF) : GXtnGiMmIPEIc
    {
        goto ZzVQr;
        rW1UE:
        return (new GXtnGiMmIPEIc())->fill($xKDWF->getAttributes());
        goto Cjl6b;
        ZzVQr:
        if (!$xKDWF instanceof GXtnGiMmIPEIc) {
            goto CS4Vv;
        }
        goto OuEAe;
        O_cLu:
        CS4Vv:
        goto rW1UE;
        OuEAe:
        return $xKDWF;
        goto O_cLu;
        Cjl6b:
    }
}
