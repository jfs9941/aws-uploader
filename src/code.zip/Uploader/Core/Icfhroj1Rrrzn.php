<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
final class Icfhroj1Rrrzn
{
    public $filename;
    public $bga3I;
    public $l70XB;
    public $n0Dq1;
    public $x1m41;
    public $QlmBb;
    public $ShsPv;
    public $status;
    public $ZAI1Q;
    public $fTWbE;
    public $G8msK = 's3';
    public $pTf3A = [];
    public function __construct($mC98T, $Q7FgY, $uLgHj, $LHx7d, $RwQud, $uH3S9, $qfYie, $M0CES, $zJG5Z, $ARG0J, $Cnmk0 = 's3', $dXuiY = [])
    {
        goto u1hDk;
        u1hDk:
        $this->filename = $mC98T;
        goto Uy1BH;
        Uy1BH:
        $this->bga3I = $Q7FgY;
        goto aNWy2;
        GeRu7:
        $this->x1m41 = $RwQud;
        goto xQ2Qt;
        KwBgu:
        $this->fTWbE = $ARG0J;
        goto wDZAT;
        pnXMk:
        $this->pTf3A = $dXuiY;
        goto FUF4w;
        xQ2Qt:
        $this->QlmBb = $uH3S9;
        goto lLPkr;
        wDZAT:
        $this->G8msK = $Cnmk0;
        goto pnXMk;
        lLPkr:
        $this->ShsPv = $qfYie;
        goto wAMgQ;
        deFGL:
        $this->n0Dq1 = $LHx7d;
        goto GeRu7;
        wAMgQ:
        $this->status = $M0CES;
        goto gBooy;
        gBooy:
        $this->ZAI1Q = $zJG5Z;
        goto KwBgu;
        aNWy2:
        $this->l70XB = $uLgHj;
        goto deFGL;
        FUF4w:
    }
    private static function mdRolu9PIrY() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function m2N4Fylo1AP() : array
    {
        return array_flip(self::mdRolu9PIrY());
    }
    public function toArray() : array
    {
        $Y_ggq = self::mdRolu9PIrY();
        return [$Y_ggq['filename'] => $this->filename, $Y_ggq['fileExtension'] => $this->bga3I, $Y_ggq['mimeType'] => $this->l70XB, $Y_ggq['fileSize'] => $this->n0Dq1, $Y_ggq['chunkSize'] => $this->x1m41, $Y_ggq['checksums'] => $this->QlmBb, $Y_ggq['totalChunk'] => $this->ShsPv, $Y_ggq['status'] => $this->status, $Y_ggq['userId'] => $this->ZAI1Q, $Y_ggq['uploadId'] => $this->fTWbE, $Y_ggq['driver'] => $this->G8msK, $Y_ggq['parts'] => $this->pTf3A];
    }
    public static function mO8cvLsrSHf(array $z4jp0) : self
    {
        $R1zae = array_flip(self::m2N4Fylo1AP());
        return new self($z4jp0[$R1zae['filename']] ?? $z4jp0['filename'] ?? '', $z4jp0[$R1zae['fileExtension']] ?? $z4jp0['fileExtension'] ?? '', $z4jp0[$R1zae['mimeType']] ?? $z4jp0['mimeType'] ?? '', $z4jp0[$R1zae['fileSize']] ?? $z4jp0['fileSize'] ?? 0, $z4jp0[$R1zae['chunkSize']] ?? $z4jp0['chunkSize'] ?? 0, $z4jp0[$R1zae['checksums']] ?? $z4jp0['checksums'] ?? [], $z4jp0[$R1zae['totalChunk']] ?? $z4jp0['totalChunk'] ?? 0, $z4jp0[$R1zae['status']] ?? $z4jp0['status'] ?? 0, $z4jp0[$R1zae['userId']] ?? $z4jp0['userId'] ?? 0, $z4jp0[$R1zae['uploadId']] ?? $z4jp0['uploadId'] ?? '', $z4jp0[$R1zae['driver']] ?? $z4jp0['driver'] ?? 's3', $z4jp0[$R1zae['parts']] ?? $z4jp0['parts'] ?? []);
    }
    public static function msP2FJQJ6fD($ndA1H) : self
    {
        goto bvMby;
        Qe8T8:
        vUMkH:
        goto JZPiG;
        bvMby:
        if (!(isset($ndA1H['fn']) || isset($ndA1H['fe']))) {
            goto vUMkH;
        }
        goto L75UQ;
        JZPiG:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto zxkIn;
        L75UQ:
        return self::mO8cvLsrSHf($ndA1H);
        goto Qe8T8;
        zxkIn:
    }
    public function m74QFmAnqWV(string $ARG0J) : void
    {
        $this->fTWbE = $ARG0J;
    }
    public function mMt8Z43ZMyY(array $dXuiY) : void
    {
        $this->pTf3A = $dXuiY;
    }
    public static function mwmWYyYAfnE($spSJx, $WiAUe, $vA0dB, $zJG5Z, $RwQud, $uH3S9, $Cnmk0)
    {
        return new self($spSJx->getFilename(), $spSJx->getExtension(), $WiAUe, $vA0dB, $RwQud, $uH3S9, count($uH3S9), LlMDscQw21XKp::UPLOADING, $zJG5Z, 0, $Cnmk0, []);
    }
    public static function mOQJSxSdp2A($GhyxD)
    {
        return 'metadata/' . $GhyxD . '.json';
    }
    public function mpIm2o8nKEH()
    {
        return 's3' === $this->G8msK ? GoWVLKcTGnffy::S3 : GoWVLKcTGnffy::LOCAL;
    }
}
