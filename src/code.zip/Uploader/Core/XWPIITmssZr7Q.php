<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
final class XWPIITmssZr7Q
{
    public $filename;
    public $WB5M9;
    public $YK1UU;
    public $rINwN;
    public $tg2I4;
    public $Jol5M;
    public $JbpvE;
    public $status;
    public $bQJvo;
    public $OZbwJ;
    public $Fd5Pz = 's3';
    public $p3z8E = [];
    public function __construct($Y0BEI, $suRrh, $s1vwz, $qcr35, $ZzjEq, $MPCIY, $HeWyO, $fHd0d, $cqKaJ, $pYyLE, $E6W0h = 's3', $Aw6Vd = [])
    {
        goto vqC7i;
        NjvPo:
        $this->Fd5Pz = $E6W0h;
        goto vo5Q_;
        p5Cqc:
        $this->JbpvE = $HeWyO;
        goto xQcKD;
        xQcKD:
        $this->status = $fHd0d;
        goto UdkRY;
        Z_aed:
        $this->WB5M9 = $suRrh;
        goto qOxhg;
        qOxhg:
        $this->YK1UU = $s1vwz;
        goto Vta3q;
        vo5Q_:
        $this->p3z8E = $Aw6Vd;
        goto hidlq;
        UdkRY:
        $this->bQJvo = $cqKaJ;
        goto KsxII;
        Vta3q:
        $this->rINwN = $qcr35;
        goto uD2qn;
        vqC7i:
        $this->filename = $Y0BEI;
        goto Z_aed;
        PKmsx:
        $this->Jol5M = $MPCIY;
        goto p5Cqc;
        KsxII:
        $this->OZbwJ = $pYyLE;
        goto NjvPo;
        uD2qn:
        $this->tg2I4 = $ZzjEq;
        goto PKmsx;
        hidlq:
    }
    private static function mnQTGBkqUdp() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mAz3xTq2BII() : array
    {
        return array_flip(self::mnQTGBkqUdp());
    }
    public function toArray() : array
    {
        $SAjMM = self::mnQTGBkqUdp();
        return [$SAjMM['filename'] => $this->filename, $SAjMM['fileExtension'] => $this->WB5M9, $SAjMM['mimeType'] => $this->YK1UU, $SAjMM['fileSize'] => $this->rINwN, $SAjMM['chunkSize'] => $this->tg2I4, $SAjMM['checksums'] => $this->Jol5M, $SAjMM['totalChunk'] => $this->JbpvE, $SAjMM['status'] => $this->status, $SAjMM['userId'] => $this->bQJvo, $SAjMM['uploadId'] => $this->OZbwJ, $SAjMM['driver'] => $this->Fd5Pz, $SAjMM['parts'] => $this->p3z8E];
    }
    public static function mfUsMggNuaQ(array $RucJJ) : self
    {
        $rv0hI = array_flip(self::mAz3xTq2BII());
        return new self($RucJJ[$rv0hI['filename']] ?? $RucJJ['filename'] ?? '', $RucJJ[$rv0hI['fileExtension']] ?? $RucJJ['fileExtension'] ?? '', $RucJJ[$rv0hI['mimeType']] ?? $RucJJ['mimeType'] ?? '', $RucJJ[$rv0hI['fileSize']] ?? $RucJJ['fileSize'] ?? 0, $RucJJ[$rv0hI['chunkSize']] ?? $RucJJ['chunkSize'] ?? 0, $RucJJ[$rv0hI['checksums']] ?? $RucJJ['checksums'] ?? [], $RucJJ[$rv0hI['totalChunk']] ?? $RucJJ['totalChunk'] ?? 0, $RucJJ[$rv0hI['status']] ?? $RucJJ['status'] ?? 0, $RucJJ[$rv0hI['userId']] ?? $RucJJ['userId'] ?? 0, $RucJJ[$rv0hI['uploadId']] ?? $RucJJ['uploadId'] ?? '', $RucJJ[$rv0hI['driver']] ?? $RucJJ['driver'] ?? 's3', $RucJJ[$rv0hI['parts']] ?? $RucJJ['parts'] ?? []);
    }
    public static function mzuRsecsHYw($iHAwg) : self
    {
        goto ZH063;
        ukdzT:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto H1Qus;
        opF1T:
        return self::mfUsMggNuaQ($iHAwg);
        goto Y9B0k;
        ZH063:
        if (!(isset($iHAwg['fn']) || isset($iHAwg['fe']))) {
            goto jcGhu;
        }
        goto opF1T;
        Y9B0k:
        jcGhu:
        goto ukdzT;
        H1Qus:
    }
    public function mzmsXanFg3j(string $pYyLE) : void
    {
        $this->OZbwJ = $pYyLE;
    }
    public function mtdG7YaeXtg(array $Aw6Vd) : void
    {
        $this->p3z8E = $Aw6Vd;
    }
    public static function m9JFBI1XYsa($qFMlx, $kJUYP, $tRxYh, $cqKaJ, $ZzjEq, $MPCIY, $E6W0h)
    {
        return new self($qFMlx->getFilename(), $qFMlx->getExtension(), $kJUYP, $tRxYh, $ZzjEq, $MPCIY, count($MPCIY), A7CVlqbpzhfLD::UPLOADING, $cqKaJ, 0, $E6W0h, []);
    }
    public static function mrxyiFG5EN6($eeXS6)
    {
        return 'metadata/' . $eeXS6 . '.json';
    }
    public function mIn7Gc5C2IC()
    {
        return 's3' === $this->Fd5Pz ? PdN71mQX1JeZG::S3 : PdN71mQX1JeZG::LOCAL;
    }
}
