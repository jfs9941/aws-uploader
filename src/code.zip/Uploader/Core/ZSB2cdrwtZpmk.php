<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Contracts\VrVag0CyeQKdN;
use Jfs\Uploader\Core\Traits\NS3Z1m1xuUfrl;
use Jfs\Uploader\Core\Traits\U4dsP2dkmJHns;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class ZSB2cdrwtZpmk extends Yn8aWzKzROkno implements CxLspzxS91nUL
{
    use NS3Z1m1xuUfrl;
    use U4dsP2dkmJHns;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $EtuF1, string $dwytV) : self
    {
        goto ryhoE;
        ryhoE:
        $wmU7r = new self(['id' => $EtuF1, 'type' => $dwytV, 'status' => SwAwanZG36Yx6::UPLOADING]);
        goto bboox;
        bboox:
        $wmU7r->m25UhhF4K3y(SwAwanZG36Yx6::UPLOADING);
        goto mkuY6;
        mkuY6:
        return $wmU7r;
        goto JUYpa;
        JUYpa:
    }
    public function width() : ?int
    {
        goto yQYnU;
        yQYnU:
        $aio9s = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto oRUcf;
        oRUcf:
        if (!$aio9s) {
            goto IwJQi;
        }
        goto BBb3Z;
        BBb3Z:
        return $aio9s;
        goto celwi;
        zigcg:
        return null;
        goto fGolW;
        celwi:
        IwJQi:
        goto zigcg;
        fGolW:
    }
    public function height() : ?int
    {
        goto Wr3OW;
        DmhxW:
        if (!$E52ZJ) {
            goto m4CCv;
        }
        goto L6XyF;
        Wr3OW:
        $E52ZJ = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto DmhxW;
        rYRI9:
        return null;
        goto kOXFA;
        eHp1n:
        m4CCv:
        goto rYRI9;
        L6XyF:
        return $E52ZJ;
        goto eHp1n;
        kOXFA:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($wmU7r) {
            goto J_LcW;
            t1VL1:
            if (!(!array_key_exists('thumbnail', $axL5J) && !array_key_exists('hls_path', $axL5J))) {
                goto okgIW;
            }
            goto s7XoI;
            U4qmY:
            if (!($axL5J['thumbnail'] || $axL5J['hls_path'])) {
                goto T3lmw;
            }
            goto qRFSB;
            s7XoI:
            return;
            goto Qth4u;
            YNIxL:
            T3lmw:
            goto IMCf6;
            J_LcW:
            $axL5J = $wmU7r->getDirty();
            goto t1VL1;
            qRFSB:
            ZSB2cdrwtZpmk::where('parent_id', $wmU7r->getAttribute('id'))->update(['thumbnail' => $wmU7r->getAttributes()['thumbnail'], 'hls_path' => $wmU7r->getAttributes()['hls_path']]);
            goto YNIxL;
            Qth4u:
            okgIW:
            goto U4qmY;
            IMCf6:
        });
    }
    public function my7hpR240Lv()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mOVX1rCiFgI()
    {
        return $this->getAttribute('id');
    }
    public function mLQ4nsW4BAP() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto BSVrA;
        eS3_Z:
        if ($this->getAttribute('hls_path')) {
            goto nQiLN;
        }
        goto e0LtQ;
        d_jxN:
        $ZUnAd['thumbnail'] = $vZ4J2->resolveThumbnail($this);
        goto jkyKv;
        mK9Hm:
        $ZUnAd['player_url'] = $vZ4J2->resolvePathForHlsVideo($this, true);
        goto SawKS;
        qbVpR:
        $ZUnAd = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $vZ4J2->resolvePath($this, $this->getAttribute('driver'))];
        goto eS3_Z;
        SawKS:
        wwHEY:
        goto d_jxN;
        jkyKv:
        return $ZUnAd;
        goto L6rYD;
        e0LtQ:
        $ZUnAd['player_url'] = $vZ4J2->resolvePath($this, $this->getAttribute('driver'));
        goto IelAR;
        BSVrA:
        $vZ4J2 = app(VrVag0CyeQKdN::class);
        goto qbVpR;
        lQGf0:
        nQiLN:
        goto mK9Hm;
        IelAR:
        goto wwHEY;
        goto lQGf0;
        L6rYD:
    }
    public function getThumbnails()
    {
        goto Fnk5a;
        swabB:
        $vZ4J2 = app(VrVag0CyeQKdN::class);
        goto NIcq4;
        NIcq4:
        return array_map(function ($XGdv1) use($vZ4J2) {
            return $vZ4J2->resolvePath($XGdv1);
        }, $MiD3s);
        goto HzPpN;
        Fnk5a:
        $MiD3s = $this->getAttribute('generated_previews') ?? [];
        goto swabB;
        HzPpN:
    }
    public static function mjl467SqCuG(Yn8aWzKzROkno $LKVOP) : ZSB2cdrwtZpmk
    {
        goto XNrjp;
        yIz2R:
        return (new ZSB2cdrwtZpmk())->fill($LKVOP->getAttributes());
        goto y6aN_;
        y3wxB:
        IS3ep:
        goto yIz2R;
        WgRgG:
        return $LKVOP;
        goto y3wxB;
        XNrjp:
        if (!$LKVOP instanceof ZSB2cdrwtZpmk) {
            goto IS3ep;
        }
        goto WgRgG;
        y6aN_:
    }
}
