<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
final class E4a2957rpFTRJ
{
    public $filename;
    public $vYbvm;
    public $cjAQL;
    public $QhLmd;
    public $HAyU7;
    public $ndGcb;
    public $KmLDC;
    public $status;
    public $si8lR;
    public $JI6i6;
    public $P5ZjQ = 's3';
    public $O3Nrl = [];
    public function __construct($cjZ5W, $DMC5n, $gkXJK, $H0ksR, $rMOii, $hWt8D, $u26jl, $AL9iA, $CYLV9, $rrVeh, $uV7lV = 's3', $YXgxQ = [])
    {
        goto XiqU3;
        nroCO:
        $this->status = $AL9iA;
        goto uPcl5;
        rAiyn:
        $this->HAyU7 = $rMOii;
        goto m4mRu;
        F_Fn4:
        $this->JI6i6 = $rrVeh;
        goto ahGdH;
        YRe9S:
        $this->QhLmd = $H0ksR;
        goto rAiyn;
        m4mRu:
        $this->ndGcb = $hWt8D;
        goto mvwO0;
        uPcl5:
        $this->si8lR = $CYLV9;
        goto F_Fn4;
        mvwO0:
        $this->KmLDC = $u26jl;
        goto nroCO;
        uPIjN:
        $this->vYbvm = $DMC5n;
        goto Aw58N;
        XiqU3:
        $this->filename = $cjZ5W;
        goto uPIjN;
        oASFX:
        $this->O3Nrl = $YXgxQ;
        goto wgaxs;
        ahGdH:
        $this->P5ZjQ = $uV7lV;
        goto oASFX;
        Aw58N:
        $this->cjAQL = $gkXJK;
        goto YRe9S;
        wgaxs:
    }
    private static function moda0pD7CNm() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mRBt8MX78QV() : array
    {
        return array_flip(self::moda0pD7CNm());
    }
    public function toArray() : array
    {
        $K77Tq = self::moda0pD7CNm();
        return [$K77Tq['filename'] => $this->filename, $K77Tq['fileExtension'] => $this->vYbvm, $K77Tq['mimeType'] => $this->cjAQL, $K77Tq['fileSize'] => $this->QhLmd, $K77Tq['chunkSize'] => $this->HAyU7, $K77Tq['checksums'] => $this->ndGcb, $K77Tq['totalChunk'] => $this->KmLDC, $K77Tq['status'] => $this->status, $K77Tq['userId'] => $this->si8lR, $K77Tq['uploadId'] => $this->JI6i6, $K77Tq['driver'] => $this->P5ZjQ, $K77Tq['parts'] => $this->O3Nrl];
    }
    public static function mz7ml4OjEUT(array $QbjcT) : self
    {
        $NO6v0 = array_flip(self::mRBt8MX78QV());
        return new self($QbjcT[$NO6v0['filename']] ?? $QbjcT['filename'] ?? '', $QbjcT[$NO6v0['fileExtension']] ?? $QbjcT['fileExtension'] ?? '', $QbjcT[$NO6v0['mimeType']] ?? $QbjcT['mimeType'] ?? '', $QbjcT[$NO6v0['fileSize']] ?? $QbjcT['fileSize'] ?? 0, $QbjcT[$NO6v0['chunkSize']] ?? $QbjcT['chunkSize'] ?? 0, $QbjcT[$NO6v0['checksums']] ?? $QbjcT['checksums'] ?? [], $QbjcT[$NO6v0['totalChunk']] ?? $QbjcT['totalChunk'] ?? 0, $QbjcT[$NO6v0['status']] ?? $QbjcT['status'] ?? 0, $QbjcT[$NO6v0['userId']] ?? $QbjcT['userId'] ?? 0, $QbjcT[$NO6v0['uploadId']] ?? $QbjcT['uploadId'] ?? '', $QbjcT[$NO6v0['driver']] ?? $QbjcT['driver'] ?? 's3', $QbjcT[$NO6v0['parts']] ?? $QbjcT['parts'] ?? []);
    }
    public static function mmma09KXsnd($CGvBN) : self
    {
        goto Kjl9I;
        m2lZx:
        x6xAS:
        goto BHgO5;
        BHgO5:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto UU2oH;
        Kjl9I:
        if (!(isset($CGvBN['fn']) || isset($CGvBN['fe']))) {
            goto x6xAS;
        }
        goto unGYJ;
        unGYJ:
        return self::mz7ml4OjEUT($CGvBN);
        goto m2lZx;
        UU2oH:
    }
    public function mGzbykTgjHh(string $rrVeh) : void
    {
        $this->JI6i6 = $rrVeh;
    }
    public function m8MM5cUIu7J(array $YXgxQ) : void
    {
        $this->O3Nrl = $YXgxQ;
    }
    public static function m7WlBwjk1wo($FJFJj, $WZrdP, $lscSG, $CYLV9, $rMOii, $hWt8D, $uV7lV)
    {
        return new self($FJFJj->getFilename(), $FJFJj->getExtension(), $WZrdP, $lscSG, $rMOii, $hWt8D, count($hWt8D), EXecNg2hg7kwl::UPLOADING, $CYLV9, 0, $uV7lV, []);
    }
    public static function mLe05NfPcmU($arqvy)
    {
        return 'metadata/' . $arqvy . '.json';
    }
    public function m1D4daBT764()
    {
        return 's3' === $this->P5ZjQ ? Opdj0uZXaMJfa::S3 : Opdj0uZXaMJfa::LOCAL;
    }
}
