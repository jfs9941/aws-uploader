<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Contracts\AbPtLXucv9ja8;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\Traits\IBoPBAZwQwRqv;
use Jfs\Uploader\Core\Traits\W8XZSueQaszDJ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Service\AkmCl9xAlobwb;
class OrjVhA5InRPZV extends OWEQTdXGAAFta implements DHtESYY0VyGQJ
{
    use IBoPBAZwQwRqv;
    use W8XZSueQaszDJ;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $eVMet, string $cJEs5) : self
    {
        goto UrHoS;
        bFMJg:
        return $WpqQe;
        goto mlmUU;
        UrHoS:
        $WpqQe = new self(['id' => $eVMet, 'type' => $cJEs5, 'status' => A7CVlqbpzhfLD::UPLOADING]);
        goto TJUrK;
        TJUrK:
        $WpqQe->mdMI6wvUXmN(A7CVlqbpzhfLD::UPLOADING);
        goto bFMJg;
        mlmUU:
    }
    public function getView() : array
    {
        $wt4Tn = app(AbPtLXucv9ja8::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $wt4Tn->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $wt4Tn->resolveThumbnail($this)];
    }
    public static function m7IPkw58tbj(OWEQTdXGAAFta $QWQ9j) : OrjVhA5InRPZV
    {
        goto eP9hW;
        SBz4m:
        return $QWQ9j;
        goto RDel9;
        RDel9:
        v3cJL:
        goto p9rbP;
        eP9hW:
        if (!$QWQ9j instanceof OrjVhA5InRPZV) {
            goto v3cJL;
        }
        goto SBz4m;
        p9rbP:
        return (new OrjVhA5InRPZV())->fill($QWQ9j->getAttributes());
        goto hFfrg;
        hFfrg:
    }
}
