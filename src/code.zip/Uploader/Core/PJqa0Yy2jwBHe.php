<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use Illuminate\Database\Eloquent\Model;
abstract  class PJqa0Yy2jwBHe extends Model implements YcdplGVWzA91v
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mDm9EIxBnMR() : bool
    {
        goto t2Fno;
        g0nII:
        return true;
        goto H45kR;
        t2Fno:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto X7mFE;
        }
        goto g0nII;
        MW7Ap:
        return !$this->mULegJbjEHN();
        goto qF0at;
        H45kR:
        X7mFE:
        goto MW7Ap;
        qF0at:
    }
    protected function mULegJbjEHN() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
