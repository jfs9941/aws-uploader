<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Core\Traits\E2oUjXwrsjJZQ;
use Jfs\Uploader\Core\Traits\AyFiTfhD6jOXL;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Service\QBWgN1d5cwk0P;
class FNGNxcyxjaxBG extends GuA6QuvssLUzf implements JGFha5eJXVoQK
{
    use E2oUjXwrsjJZQ;
    use AyFiTfhD6jOXL;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $YIAds, string $poyPD) : self
    {
        goto bRHei;
        bRHei:
        $kHreC = new self(['id' => $YIAds, 'type' => $poyPD, 'status' => QoCMzcKvH8Cw2::UPLOADING]);
        goto Rw1Xs;
        bx9Be:
        return $kHreC;
        goto RjIkx;
        Rw1Xs:
        $kHreC->mGG5zG7yPwR(QoCMzcKvH8Cw2::UPLOADING);
        goto bx9Be;
        RjIkx:
    }
    public function getView() : array
    {
        $SMQC2 = app(HqWA5DdMiDW1U::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $SMQC2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $SMQC2->resolveThumbnail($this)];
    }
    public static function mAaHkpuO7oi(GuA6QuvssLUzf $nNNVD) : FNGNxcyxjaxBG
    {
        goto Fd8C8;
        BfXLY:
        return $nNNVD;
        goto f7tpw;
        f7tpw:
        ZK8vQ:
        goto sQK1t;
        Fd8C8:
        if (!$nNNVD instanceof FNGNxcyxjaxBG) {
            goto ZK8vQ;
        }
        goto BfXLY;
        sQK1t:
        return (new FNGNxcyxjaxBG())->fill($nNNVD->getAttributes());
        goto eYcGj;
        eYcGj:
    }
}
