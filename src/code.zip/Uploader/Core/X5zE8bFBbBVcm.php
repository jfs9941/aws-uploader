<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
final class X5zE8bFBbBVcm
{
    public $filename;
    public $lrNoe;
    public $Zokpz;
    public $l3D2R;
    public $VA2jP;
    public $Uw4WG;
    public $xMQDK;
    public $status;
    public $W8_Ik;
    public $ZsH2f;
    public $driver = 's3';
    public $Ka7W8 = [];
    public function __construct($RNODg, $b2ITX, $fT88U, $K27p7, $U3GL3, $xEjOf, $jlw95, $cNFkW, $J7E9r, $ytDYW, $NjcWd = 's3', $qwLXm = [])
    {
        goto t3lVy;
        t9Ph4:
        $this->Uw4WG = $xEjOf;
        goto hltrM;
        TN7wk:
        $this->Zokpz = $fT88U;
        goto FHNA_;
        t3lVy:
        $this->filename = $RNODg;
        goto CxGGf;
        Sb93q:
        $this->ZsH2f = $ytDYW;
        goto SUXvP;
        XQhfO:
        $this->VA2jP = $U3GL3;
        goto t9Ph4;
        CxGGf:
        $this->lrNoe = $b2ITX;
        goto TN7wk;
        FHNA_:
        $this->l3D2R = $K27p7;
        goto XQhfO;
        SUXvP:
        $this->driver = $NjcWd;
        goto mbzCE;
        Tj9IJ:
        $this->status = $cNFkW;
        goto RoJIP;
        hltrM:
        $this->xMQDK = $jlw95;
        goto Tj9IJ;
        mbzCE:
        $this->Ka7W8 = $qwLXm;
        goto DjdgO;
        RoJIP:
        $this->W8_Ik = $J7E9r;
        goto Sb93q;
        DjdgO:
    }
    private static function mLqIydrAJRJ() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mmFFZrnVv3j() : array
    {
        return array_flip(self::mLqIydrAJRJ());
    }
    public function toArray() : array
    {
        $mzClD = self::mLqIydrAJRJ();
        return [$mzClD['filename'] => $this->filename, $mzClD['fileExtension'] => $this->lrNoe, $mzClD['mimeType'] => $this->Zokpz, $mzClD['fileSize'] => $this->l3D2R, $mzClD['chunkSize'] => $this->VA2jP, $mzClD['checksums'] => $this->Uw4WG, $mzClD['totalChunk'] => $this->xMQDK, $mzClD['status'] => $this->status, $mzClD['userId'] => $this->W8_Ik, $mzClD['uploadId'] => $this->ZsH2f, $mzClD['driver'] => $this->driver, $mzClD['parts'] => $this->Ka7W8];
    }
    public static function m1nZyBGJ4sm(array $XX3Lf) : self
    {
        $PUt76 = array_flip(self::mmFFZrnVv3j());
        return new self($XX3Lf[$PUt76['filename']] ?? $XX3Lf['filename'] ?? '', $XX3Lf[$PUt76['fileExtension']] ?? $XX3Lf['fileExtension'] ?? '', $XX3Lf[$PUt76['mimeType']] ?? $XX3Lf['mimeType'] ?? '', $XX3Lf[$PUt76['fileSize']] ?? $XX3Lf['fileSize'] ?? 0, $XX3Lf[$PUt76['chunkSize']] ?? $XX3Lf['chunkSize'] ?? 0, $XX3Lf[$PUt76['checksums']] ?? $XX3Lf['checksums'] ?? [], $XX3Lf[$PUt76['totalChunk']] ?? $XX3Lf['totalChunk'] ?? 0, $XX3Lf[$PUt76['status']] ?? $XX3Lf['status'] ?? 0, $XX3Lf[$PUt76['userId']] ?? $XX3Lf['userId'] ?? 0, $XX3Lf[$PUt76['uploadId']] ?? $XX3Lf['uploadId'] ?? '', $XX3Lf[$PUt76['driver']] ?? $XX3Lf['driver'] ?? 's3', $XX3Lf[$PUt76['parts']] ?? $XX3Lf['parts'] ?? []);
    }
    public static function mlJAlG3FIjn($UpfBd) : self
    {
        goto fu3dz;
        TS9o7:
        return self::m1nZyBGJ4sm($UpfBd);
        goto Q6I3w;
        nl2hz:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto FeTkq;
        fu3dz:
        if (!(isset($UpfBd['fn']) || isset($UpfBd['fe']))) {
            goto Lo90Z;
        }
        goto TS9o7;
        Q6I3w:
        Lo90Z:
        goto nl2hz;
        FeTkq:
    }
    public function m2yI097SE4n(string $ytDYW) : void
    {
        $this->ZsH2f = $ytDYW;
    }
    public function mjoM4ZDVVFf(array $qwLXm) : void
    {
        $this->Ka7W8 = $qwLXm;
    }
    public static function mUmiVJ5XxHa($eQ4Ln, $keMvO, $y5Uo1, $J7E9r, $U3GL3, $xEjOf, $NjcWd)
    {
        return new self($eQ4Ln->getFilename(), $eQ4Ln->getExtension(), $keMvO, $y5Uo1, $U3GL3, $xEjOf, count($xEjOf), MUu80sOhINyO3::UPLOADING, $J7E9r, 0, $NjcWd, []);
    }
    public static function m46mJEWRin8($g5e_r)
    {
        return 'metadata/' . $g5e_r . '.json';
    }
    public function mp8oQSQ6jYh()
    {
        return 's3' === $this->driver ? Tq4KHV0o6oTIo::S3 : Tq4KHV0o6oTIo::LOCAL;
    }
}
