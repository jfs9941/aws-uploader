<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
final class YOSIkvkyMSIKR
{
    public $filename;
    public $e2m7j;
    public $W0WCt;
    public $TgkQ_;
    public $R2hLK;
    public $PuNRE;
    public $DWXiY;
    public $status;
    public $NFJuf;
    public $zFYsq;
    public $driver = 's3';
    public $BGkIZ = [];
    public function __construct($qoXzC, $W4kN6, $wJJHL, $u2XeJ, $pu7IV, $Da8dG, $dCJHE, $Nzk6o, $V3Z4M, $aPEyz, $n8L3v = 's3', $oDHkw = [])
    {
        goto F1vjf;
        aRD10:
        $this->R2hLK = $pu7IV;
        goto JHZiq;
        CCrMm:
        $this->e2m7j = $W4kN6;
        goto PmPHy;
        L_DYk:
        $this->NFJuf = $V3Z4M;
        goto UFetk;
        PmPHy:
        $this->W0WCt = $wJJHL;
        goto tfyuE;
        PSyXL:
        $this->DWXiY = $dCJHE;
        goto boijL;
        JHZiq:
        $this->PuNRE = $Da8dG;
        goto PSyXL;
        boijL:
        $this->status = $Nzk6o;
        goto L_DYk;
        tfyuE:
        $this->TgkQ_ = $u2XeJ;
        goto aRD10;
        nR7AU:
        $this->driver = $n8L3v;
        goto XsX9A;
        F1vjf:
        $this->filename = $qoXzC;
        goto CCrMm;
        XsX9A:
        $this->BGkIZ = $oDHkw;
        goto wuf3i;
        UFetk:
        $this->zFYsq = $aPEyz;
        goto nR7AU;
        wuf3i:
    }
    private static function myG5Sgq5Hct() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mZZK1WwTVtd() : array
    {
        return array_flip(self::myG5Sgq5Hct());
    }
    public function toArray() : array
    {
        $fQyRM = self::myG5Sgq5Hct();
        return [$fQyRM['filename'] => $this->filename, $fQyRM['fileExtension'] => $this->e2m7j, $fQyRM['mimeType'] => $this->W0WCt, $fQyRM['fileSize'] => $this->TgkQ_, $fQyRM['chunkSize'] => $this->R2hLK, $fQyRM['checksums'] => $this->PuNRE, $fQyRM['totalChunk'] => $this->DWXiY, $fQyRM['status'] => $this->status, $fQyRM['userId'] => $this->NFJuf, $fQyRM['uploadId'] => $this->zFYsq, $fQyRM['driver'] => $this->driver, $fQyRM['parts'] => $this->BGkIZ];
    }
    public static function mxrh077UXy5(array $L3732) : self
    {
        $ooBz6 = array_flip(self::mZZK1WwTVtd());
        return new self($L3732[$ooBz6['filename']] ?? $L3732['filename'] ?? '', $L3732[$ooBz6['fileExtension']] ?? $L3732['fileExtension'] ?? '', $L3732[$ooBz6['mimeType']] ?? $L3732['mimeType'] ?? '', $L3732[$ooBz6['fileSize']] ?? $L3732['fileSize'] ?? 0, $L3732[$ooBz6['chunkSize']] ?? $L3732['chunkSize'] ?? 0, $L3732[$ooBz6['checksums']] ?? $L3732['checksums'] ?? [], $L3732[$ooBz6['totalChunk']] ?? $L3732['totalChunk'] ?? 0, $L3732[$ooBz6['status']] ?? $L3732['status'] ?? 0, $L3732[$ooBz6['userId']] ?? $L3732['userId'] ?? 0, $L3732[$ooBz6['uploadId']] ?? $L3732['uploadId'] ?? '', $L3732[$ooBz6['driver']] ?? $L3732['driver'] ?? 's3', $L3732[$ooBz6['parts']] ?? $L3732['parts'] ?? []);
    }
    public static function mX9azFknIp3($ADgml) : self
    {
        goto gbSNI;
        Jbulv:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto VUplh;
        Skzaa:
        OY07y:
        goto Jbulv;
        gbSNI:
        if (!(isset($ADgml['fn']) || isset($ADgml['fe']))) {
            goto OY07y;
        }
        goto MOF4h;
        MOF4h:
        return self::mxrh077UXy5($ADgml);
        goto Skzaa;
        VUplh:
    }
    public function mLQU01cj3Al(string $aPEyz) : void
    {
        $this->zFYsq = $aPEyz;
    }
    public function mJxwEU3Y3Aa(array $oDHkw) : void
    {
        $this->BGkIZ = $oDHkw;
    }
    public static function m3u5o2y4v0H($K9DZL, $xMo__, $BJVUo, $V3Z4M, $pu7IV, $Da8dG, $n8L3v)
    {
        return new self($K9DZL->getFilename(), $K9DZL->getExtension(), $xMo__, $BJVUo, $pu7IV, $Da8dG, count($Da8dG), GlPuUJKmzwUJ9::UPLOADING, $V3Z4M, 0, $n8L3v, []);
    }
    public static function mFUIt4zd7G3($wAkkA)
    {
        return 'metadata/' . $wAkkA . '.json';
    }
    public function mFM26p1pjc0()
    {
        return 's3' === $this->driver ? Pj539Ru5gyMbt::S3 : Pj539Ru5gyMbt::LOCAL;
    }
}
