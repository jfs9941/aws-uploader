<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Contracts\LQJLoPxiuxgfZ;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\Traits\ICoBvKGsB4Udb;
use Jfs\Uploader\Core\Traits\KfSjQVQJRLwh3;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Service\WSEmT91tAxzKt;
class SK0zQTH7YFzcx extends AtQh9cRLX7xL8 implements Fk274vNY0LJnp
{
    use ICoBvKGsB4Udb;
    use KfSjQVQJRLwh3;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $e1Rlj, string $fsv41) : self
    {
        goto b2h58;
        UhNU8:
        return $Vpxjw;
        goto ndCpS;
        b2h58:
        $Vpxjw = new self(['id' => $e1Rlj, 'type' => $fsv41, 'status' => M7O7NSiJU2JG5::UPLOADING]);
        goto ZCO_e;
        ZCO_e:
        $Vpxjw->mJf7701KMEl(M7O7NSiJU2JG5::UPLOADING);
        goto UhNU8;
        ndCpS:
    }
    public function getView() : array
    {
        $VAwkb = app(LQJLoPxiuxgfZ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $VAwkb->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $VAwkb->resolveThumbnail($this)];
    }
    public static function mvWLcaos1oR(AtQh9cRLX7xL8 $hckxR) : SK0zQTH7YFzcx
    {
        goto X926O;
        sMWtT:
        return $hckxR;
        goto Bi4Gu;
        C_cW_:
        return (new SK0zQTH7YFzcx())->fill($hckxR->getAttributes());
        goto Nqtbi;
        X926O:
        if (!$hckxR instanceof SK0zQTH7YFzcx) {
            goto sU014;
        }
        goto sMWtT;
        Bi4Gu:
        sU014:
        goto C_cW_;
        Nqtbi:
    }
}
