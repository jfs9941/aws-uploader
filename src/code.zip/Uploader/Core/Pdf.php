<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Contracts\PathResolverInterface;
use Jfs\Uploader\Core\Traits\FileCreationTrait;
use Jfs\Uploader\Core\Traits\StateMachineTrait;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Service\PathResolver;

class Pdf extends BaseFileModel implements FileStateInterface
{
    use FileCreationTrait;
    use StateMachineTrait;

    public function getType(): string
    {
        return 'pdf';
    }

    public static function createFromScratch(string $name, string $extension): self
    {
        $pdf = new self([
            'id' => $name,
            'type' => $extension,
            'status' => FileStatus::UPLOADING,
        ]);

        $pdf->initializeState(FileStatus::UPLOADING);

        return $pdf;
    }

    public function getView(): array
    {
        $pathResolver = app(PathResolverInterface::class);
        return [
            'id' => $this->getAttribute('id'),
            'type' => $this->getAttribute('type'),
            'file_type' => 'file',
            'path' => $pathResolver->resolvePath($this, $this->getAttribute('driver')),
            'thumbnail' => $pathResolver->resolveThumbnail($this)
        ];
    }

    public static function asPdf(BaseFileModel $fileModel): Pdf
    {
        if ($fileModel instanceof Pdf) {
            return $fileModel;
        }

        return (new Pdf())->fill($fileModel->getAttributes());
    }
}
