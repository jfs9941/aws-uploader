<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\FW54oEnFetVYj;
use Jfs\Uploader\Enum\SsxWbUYXracun;
final class YqfGySn8nxxqU
{
    public $filename;
    public $AKs4N;
    public $XovbP;
    public $u1hlj;
    public $EAzFa;
    public $H1t_A;
    public $bQ8dx;
    public $status;
    public $JD7KB;
    public $NDdad;
    public $ymE9n = 's3';
    public $XwLtl = [];
    public function __construct($Uj30r, $lm2qe, $Sgwln, $ACybJ, $aAHm1, $bcSv0, $mdaFE, $JU_0g, $W4GNe, $Tu5AU, $XokUJ = 's3', $Zkrnk = [])
    {
        goto qrt7O;
        kGINn:
        $this->H1t_A = $bcSv0;
        goto LWzWo;
        TWTyd:
        $this->XwLtl = $Zkrnk;
        goto cTS0b;
        qvnRC:
        $this->XovbP = $Sgwln;
        goto yoxp3;
        qrt7O:
        $this->filename = $Uj30r;
        goto vCTT2;
        EUI8s:
        $this->status = $JU_0g;
        goto TcT47;
        TcT47:
        $this->JD7KB = $W4GNe;
        goto Sa2Tr;
        LWzWo:
        $this->bQ8dx = $mdaFE;
        goto EUI8s;
        Sa2Tr:
        $this->NDdad = $Tu5AU;
        goto g0HaW;
        yoxp3:
        $this->u1hlj = $ACybJ;
        goto WZPRp;
        WZPRp:
        $this->EAzFa = $aAHm1;
        goto kGINn;
        g0HaW:
        $this->ymE9n = $XokUJ;
        goto TWTyd;
        vCTT2:
        $this->AKs4N = $lm2qe;
        goto qvnRC;
        cTS0b:
    }
    private static function mXmrWWylLwb() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mfAW8SoUMOx() : array
    {
        return array_flip(self::mXmrWWylLwb());
    }
    public function toArray() : array
    {
        $JM0qL = self::mXmrWWylLwb();
        return [$JM0qL['filename'] => $this->filename, $JM0qL['fileExtension'] => $this->AKs4N, $JM0qL['mimeType'] => $this->XovbP, $JM0qL['fileSize'] => $this->u1hlj, $JM0qL['chunkSize'] => $this->EAzFa, $JM0qL['checksums'] => $this->H1t_A, $JM0qL['totalChunk'] => $this->bQ8dx, $JM0qL['status'] => $this->status, $JM0qL['userId'] => $this->JD7KB, $JM0qL['uploadId'] => $this->NDdad, $JM0qL['driver'] => $this->ymE9n, $JM0qL['parts'] => $this->XwLtl];
    }
    public static function mwqdCT15iL1(array $LED2o) : self
    {
        $VsTyk = array_flip(self::mfAW8SoUMOx());
        return new self($LED2o[$VsTyk['filename']] ?? $LED2o['filename'] ?? '', $LED2o[$VsTyk['fileExtension']] ?? $LED2o['fileExtension'] ?? '', $LED2o[$VsTyk['mimeType']] ?? $LED2o['mimeType'] ?? '', $LED2o[$VsTyk['fileSize']] ?? $LED2o['fileSize'] ?? 0, $LED2o[$VsTyk['chunkSize']] ?? $LED2o['chunkSize'] ?? 0, $LED2o[$VsTyk['checksums']] ?? $LED2o['checksums'] ?? [], $LED2o[$VsTyk['totalChunk']] ?? $LED2o['totalChunk'] ?? 0, $LED2o[$VsTyk['status']] ?? $LED2o['status'] ?? 0, $LED2o[$VsTyk['userId']] ?? $LED2o['userId'] ?? 0, $LED2o[$VsTyk['uploadId']] ?? $LED2o['uploadId'] ?? '', $LED2o[$VsTyk['driver']] ?? $LED2o['driver'] ?? 's3', $LED2o[$VsTyk['parts']] ?? $LED2o['parts'] ?? []);
    }
    public static function m0gFufJMyBg($eRuuK) : self
    {
        goto BS_oq;
        lEV1Q:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto vxig7;
        WkzKU:
        gwVKn:
        goto lEV1Q;
        AAvbi:
        return self::mwqdCT15iL1($eRuuK);
        goto WkzKU;
        BS_oq:
        if (!(isset($eRuuK['fn']) || isset($eRuuK['fe']))) {
            goto gwVKn;
        }
        goto AAvbi;
        vxig7:
    }
    public function moWcWcx9wMl(string $Tu5AU) : void
    {
        $this->NDdad = $Tu5AU;
    }
    public function mbWSXS8s0no(array $Zkrnk) : void
    {
        $this->XwLtl = $Zkrnk;
    }
    public static function mSKT3rOHzZ6($tscCi, $MLY7y, $VSa1F, $W4GNe, $aAHm1, $bcSv0, $XokUJ)
    {
        return new self($tscCi->getFilename(), $tscCi->getExtension(), $MLY7y, $VSa1F, $aAHm1, $bcSv0, count($bcSv0), SsxWbUYXracun::UPLOADING, $W4GNe, 0, $XokUJ, []);
    }
    public static function m5taoOo2xJN($cQqZd)
    {
        return 'metadata/' . $cQqZd . '.json';
    }
    public function mO43DEdkF8D()
    {
        return 's3' === $this->ymE9n ? FW54oEnFetVYj::S3 : FW54oEnFetVYj::LOCAL;
    }
}
