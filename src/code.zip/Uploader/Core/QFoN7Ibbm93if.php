<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Contracts\VdjamMvtIkwfN;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\Traits\U1oUBtFUca4cm;
use Jfs\Uploader\Core\Traits\GYCzFqUkUYdjE;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Service\BA8ePy1ftd8cO;
class QFoN7Ibbm93if extends VMj30iBgKeeJB implements SOB6nK7CGVegh
{
    use U1oUBtFUca4cm;
    use GYCzFqUkUYdjE;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $xRxub, string $Lmvwp) : self
    {
        goto oA9ev;
        oA9ev:
        $tCWWG = new self(['id' => $xRxub, 'type' => $Lmvwp, 'status' => Xy3InMky6jKYf::UPLOADING]);
        goto QQxbk;
        QQxbk:
        $tCWWG->mUg6EMktQTd(Xy3InMky6jKYf::UPLOADING);
        goto dPwhZ;
        dPwhZ:
        return $tCWWG;
        goto VzR5Y;
        VzR5Y:
    }
    public function getView() : array
    {
        $FSDPH = app(VdjamMvtIkwfN::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $FSDPH->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $FSDPH->resolveThumbnail($this)];
    }
    public static function mdge2uImzRv(VMj30iBgKeeJB $XcVxI) : QFoN7Ibbm93if
    {
        goto w2qZV;
        w2qZV:
        if (!$XcVxI instanceof QFoN7Ibbm93if) {
            goto IPIYA;
        }
        goto Yk3iT;
        Ys8bm:
        return (new QFoN7Ibbm93if())->fill($XcVxI->getAttributes());
        goto txvJs;
        v2Fc6:
        IPIYA:
        goto Ys8bm;
        Yk3iT:
        return $XcVxI;
        goto v2Fc6;
        txvJs:
    }
}
