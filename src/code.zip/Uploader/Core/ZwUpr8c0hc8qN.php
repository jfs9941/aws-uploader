<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Contracts\IKjdKLYqqHsDJ;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Traits\LoACaEWnJQjFu;
use Jfs\Uploader\Core\Traits\SphMX2uWp2oS1;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Service\H38a3dsu2FMgf;
class ZwUpr8c0hc8qN extends ALaATNTmuoFHt implements MB8DYpNdVV1bz
{
    use LoACaEWnJQjFu;
    use SphMX2uWp2oS1;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $kftn8, string $ln7Ij) : self
    {
        goto ca7Bo;
        ca7Bo:
        $uJ1gM = new self(['id' => $kftn8, 'type' => $ln7Ij, 'status' => Tbw0jsMnRbOTP::UPLOADING]);
        goto UgxBU;
        dW0JJ:
        return $uJ1gM;
        goto BHEs9;
        UgxBU:
        $uJ1gM->mWRFuBOBU6q(Tbw0jsMnRbOTP::UPLOADING);
        goto dW0JJ;
        BHEs9:
    }
    public function getView() : array
    {
        $o4fuz = app(IKjdKLYqqHsDJ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $o4fuz->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $o4fuz->resolveThumbnail($this)];
    }
    public static function mCJsnDwRyRT(ALaATNTmuoFHt $nu6qO) : ZwUpr8c0hc8qN
    {
        goto siJH7;
        Hd0mY:
        zv3l2:
        goto UtHz6;
        MfGDy:
        return $nu6qO;
        goto Hd0mY;
        UtHz6:
        return (new ZwUpr8c0hc8qN())->fill($nu6qO->getAttributes());
        goto gZx1O;
        siJH7:
        if (!$nu6qO instanceof ZwUpr8c0hc8qN) {
            goto zv3l2;
        }
        goto MfGDy;
        gZx1O:
    }
}
