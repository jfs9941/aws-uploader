<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Contracts\Bvfii9tMROJRp;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\Traits\SvjIu3InVS06e;
use Jfs\Uploader\Core\Traits\YXqL8Vu76ZyNK;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
class JPkW9ix1EKo3T extends IeEvjRaj1LMmG implements VuQzRNCSz5bHK
{
    use SvjIu3InVS06e;
    use YXqL8Vu76ZyNK;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $uXjFZ, string $n13FM) : self
    {
        goto V5bo8;
        XXSxy:
        $qF0aQ->m651SlcakeY(ZP6Ky842t6y9Y::UPLOADING);
        goto rlKS8;
        V5bo8:
        $qF0aQ = new self(['id' => $uXjFZ, 'type' => $n13FM, 'status' => ZP6Ky842t6y9Y::UPLOADING]);
        goto XXSxy;
        rlKS8:
        return $qF0aQ;
        goto FE_w0;
        FE_w0:
    }
    public function width() : ?int
    {
        goto OGMNW;
        CF0zU:
        ivgir:
        goto K_j3q;
        K_j3q:
        return null;
        goto VP1fN;
        ZKThr:
        if (!$k2slg) {
            goto ivgir;
        }
        goto I4ZAI;
        OGMNW:
        $k2slg = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto ZKThr;
        I4ZAI:
        return $k2slg;
        goto CF0zU;
        VP1fN:
    }
    public function height() : ?int
    {
        goto DTrD2;
        yFbcp:
        if (!$vci_g) {
            goto aYa6o;
        }
        goto novC5;
        VbgVh:
        return null;
        goto aXim_;
        novC5:
        return $vci_g;
        goto ckuvn;
        DTrD2:
        $vci_g = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto yFbcp;
        ckuvn:
        aYa6o:
        goto VbgVh;
        aXim_:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($qF0aQ) {
            goto u51tD;
            R5C8v:
            if (!($y3Itr['thumbnail'] || $y3Itr['hls_path'])) {
                goto UuxlD;
            }
            goto nfy89;
            h3uUM:
            return;
            goto D1ZEr;
            nfy89:
            JPkW9ix1EKo3T::where('parent_id', $qF0aQ->getAttribute('id'))->update(['thumbnail' => $qF0aQ->getAttributes()['thumbnail'], 'hls_path' => $qF0aQ->getAttributes()['hls_path']]);
            goto QqcUf;
            QqcUf:
            UuxlD:
            goto cgtIl;
            NzJLJ:
            if (!(!array_key_exists('thumbnail', $y3Itr) && !array_key_exists('hls_path', $y3Itr))) {
                goto Fgnna;
            }
            goto h3uUM;
            u51tD:
            $y3Itr = $qF0aQ->getDirty();
            goto NzJLJ;
            D1ZEr:
            Fgnna:
            goto R5C8v;
            cgtIl:
        });
    }
    public function mqoIvPsFZpI()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mIQRs3SOMiI()
    {
        return $this->getAttribute('id');
    }
    public function mKxwmdskQMr() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto j8ixT;
        tkHyc:
        return $rtMM2;
        goto bIilQ;
        DDmsh:
        $rtMM2 = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $V2cKr->resolvePath($this, $this->getAttribute('driver'))];
        goto gidb3;
        ARmrO:
        goto Qs812;
        goto g0Mvk;
        t2jHe:
        Qs812:
        goto IxwfL;
        g0Mvk:
        dLkeG:
        goto anvtv;
        vTPcc:
        $rtMM2['player_url'] = $V2cKr->resolvePath($this, $this->getAttribute('driver'));
        goto ARmrO;
        j8ixT:
        $V2cKr = app(Bvfii9tMROJRp::class);
        goto DDmsh;
        anvtv:
        $rtMM2['player_url'] = $V2cKr->resolvePathForHlsVideo($this, true);
        goto t2jHe;
        IxwfL:
        $rtMM2['thumbnail'] = $V2cKr->resolveThumbnail($this);
        goto tkHyc;
        gidb3:
        if ($this->getAttribute('hls_path')) {
            goto dLkeG;
        }
        goto vTPcc;
        bIilQ:
    }
    public function getThumbnails()
    {
        goto NibWo;
        NibWo:
        $PzULF = $this->getAttribute('generated_previews') ?? [];
        goto my0be;
        kyVtV:
        return array_map(function ($NnQOx) use($V2cKr) {
            return $V2cKr->resolvePath($NnQOx);
        }, $PzULF);
        goto IJRcv;
        my0be:
        $V2cKr = app(Bvfii9tMROJRp::class);
        goto kyVtV;
        IJRcv:
    }
    public static function mLD2cHFBZuB(IeEvjRaj1LMmG $UmLJ2) : JPkW9ix1EKo3T
    {
        goto zeR5Y;
        zeR5Y:
        if (!$UmLJ2 instanceof JPkW9ix1EKo3T) {
            goto HG66I;
        }
        goto euP7e;
        yLC0L:
        return (new JPkW9ix1EKo3T())->fill($UmLJ2->getAttributes());
        goto a9Yqx;
        JBA3W:
        HG66I:
        goto yLC0L;
        euP7e:
        return $UmLJ2;
        goto JBA3W;
        a9Yqx:
    }
}
