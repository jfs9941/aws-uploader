<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Contracts\O79PdR1cao6Xq;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\Traits\VexK8QON1Q211;
use Jfs\Uploader\Core\Traits\UPnDsKOL0mchi;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Service\PIItI2ah2Zu1r;
class UpreKuqs00udz extends OXsaQ69LP2fiA implements CxOTyXYpS0zWZ
{
    use VexK8QON1Q211;
    use UPnDsKOL0mchi;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $ixMzz, string $ydbmO) : self
    {
        goto AjRv2;
        P_2QY:
        return $deHcF;
        goto WIEDx;
        AjRv2:
        $deHcF = new self(['id' => $ixMzz, 'type' => $ydbmO, 'status' => LlMDscQw21XKp::UPLOADING]);
        goto p5xyu;
        p5xyu:
        $deHcF->m92yZMBK6RM(LlMDscQw21XKp::UPLOADING);
        goto P_2QY;
        WIEDx:
    }
    public function getView() : array
    {
        $q7czo = app(O79PdR1cao6Xq::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $q7czo->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $q7czo->resolveThumbnail($this)];
    }
    public static function m4F86YxIzdt(OXsaQ69LP2fiA $L7rEe) : UpreKuqs00udz
    {
        goto hpZ2M;
        bbYKw:
        return (new UpreKuqs00udz())->fill($L7rEe->getAttributes());
        goto LsM8q;
        QCFoq:
        return $L7rEe;
        goto WdfOi;
        hpZ2M:
        if (!$L7rEe instanceof UpreKuqs00udz) {
            goto p3MUF;
        }
        goto QCFoq;
        WdfOi:
        p3MUF:
        goto bbYKw;
        LsM8q:
    }
}
