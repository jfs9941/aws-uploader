<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Core\Traits\NYNDlFOE1EB92;
use Jfs\Uploader\Core\Traits\ZKxVDSicUFaFP;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Service\U8DiLJGk0mfB7;
class RkSRDDbIFKZE9 extends QfVdOZWAlX8Sl implements QBvcnDryrzxsL
{
    use NYNDlFOE1EB92;
    use ZKxVDSicUFaFP;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $YoQzC, string $HuqsN) : self
    {
        goto S8Et8;
        S8Et8:
        $hAB7F = new self(['id' => $YoQzC, 'type' => $HuqsN, 'status' => QUh2VVA2TE5xx::UPLOADING]);
        goto zkxDS;
        zkxDS:
        $hAB7F->mhnYveV1r0A(QUh2VVA2TE5xx::UPLOADING);
        goto Hmk6H;
        Hmk6H:
        return $hAB7F;
        goto Stas7;
        Stas7:
    }
    public function getView() : array
    {
        $dyGhn = app(E97atJzeJ1gs5::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $dyGhn->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $dyGhn->resolveThumbnail($this)];
    }
    public static function mqsl8SHPpfR(QfVdOZWAlX8Sl $sYOYc) : RkSRDDbIFKZE9
    {
        goto Ao70m;
        YuxgV:
        return $sYOYc;
        goto rnKAe;
        Ao70m:
        if (!$sYOYc instanceof RkSRDDbIFKZE9) {
            goto SDO6S;
        }
        goto YuxgV;
        rnKAe:
        SDO6S:
        goto Q43Or;
        Q43Or:
        return (new RkSRDDbIFKZE9())->fill($sYOYc->getAttributes());
        goto SLOvf;
        SLOvf:
    }
}
