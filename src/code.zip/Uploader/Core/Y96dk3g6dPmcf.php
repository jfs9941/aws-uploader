<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Core\Observer\Px6hrv2owih2J;
use Jfs\Uploader\Core\Traits\E0p8mbkNoqHie;
use Jfs\Uploader\Core\Traits\D1PKXaknZAaj4;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Exception\Vkv9DR78jqmXg;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Jfs\Uploader\Exception\GddjQ7rhrkuyP;
use Jfs\Uploader\Service\AYglkzXejDDAm;
final class Y96dk3g6dPmcf implements Y0vs5qDfvPebz
{
    use E0p8mbkNoqHie;
    use D1PKXaknZAaj4;
    private $uobaU;
    private function __construct($tscCi, $dOL2I)
    {
        $this->MF3ET = $tscCi;
        $this->wqdCV = $dOL2I;
    }
    private function mLA8IMqfHbh(string $TyFPC, $dOL2I, $TLVVj, bool $OWjWh = false) : void
    {
        $this->mFPrsEX7dNQ(new Px6hrv2owih2J($this, $dOL2I, $TLVVj, $TyFPC, $OWjWh));
    }
    public function getFile()
    {
        return $this->MF3ET;
    }
    public function mfc4hqnAzmE(array $fzsSk) : void
    {
        $this->uobaU = $fzsSk;
    }
    public function mKvxjDVLcKI() : void
    {
        $this->mvUghb89hzW(SsxWbUYXracun::UPLOADING);
    }
    public function m4uX1pQb4Ux() : void
    {
        $this->mvUghb89hzW(SsxWbUYXracun::UPLOADED);
    }
    public function mW5G3tLumNv() : void
    {
        $this->mvUghb89hzW(SsxWbUYXracun::PROCESSING);
    }
    public function mrPszRNnt2J() : void
    {
        $this->mvUghb89hzW(SsxWbUYXracun::FINISHED);
    }
    public function mjSxgz0pE87() : void
    {
        $this->mvUghb89hzW(SsxWbUYXracun::ABORTED);
    }
    public function msnuZYoW76Q() : array
    {
        return $this->uobaU;
    }
    public static function mF8XbeFNiMU(string $cQqZd, $cGf42, $v8n0s, $TyFPC) : self
    {
        goto FTrxq;
        r4gY_:
        $zW12m = new self($tscCi, $cGf42);
        goto QzMD4;
        izL0k:
        $zW12m->msLvxB5AWdO(SsxWbUYXracun::UPLOADING);
        goto z9EFc;
        QzMD4:
        $zW12m->mLA8IMqfHbh($TyFPC, $cGf42, $v8n0s);
        goto izL0k;
        FTrxq:
        $tscCi = App::make(AYglkzXejDDAm::class)->mOu1kjv0nYS(YqfGySn8nxxqU::m5taoOo2xJN($cQqZd));
        goto r4gY_;
        z9EFc:
        return $zW12m->mVv212nEf36();
        goto Opi2V;
        Opi2V:
    }
    public static function mZhCZmPzfTk($tscCi, $dOL2I, $TLVVj, $TyFPC, $OWjWh = false) : self
    {
        goto kk2yL;
        mUH6W:
        $zW12m->mLA8IMqfHbh($TyFPC, $dOL2I, $TLVVj, $OWjWh);
        goto vPfBB;
        vPfBB:
        $zW12m->msLvxB5AWdO(SsxWbUYXracun::UPLOADING);
        goto gHo3_;
        gHo3_:
        return $zW12m;
        goto mzCGO;
        kk2yL:
        $zW12m = new self($tscCi, $dOL2I);
        goto mUH6W;
        mzCGO:
    }
}
