<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Uploader\Core\Traits\LQpqxojWwaLgF;
use Jfs\Uploader\Core\Traits\MMUGtmaorqREX;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Service\JNMuh7Oo3jHTF;
class LGMw063tEE9ZC extends UKWxL8i4Jx2NZ implements SK7fSNbDSRmCO
{
    use LQpqxojWwaLgF;
    use MMUGtmaorqREX;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $ksTON, string $GXi3I) : self
    {
        goto lAzOB;
        lAzOB:
        $P2AJQ = new self(['id' => $ksTON, 'type' => $GXi3I, 'status' => RwOJkCXwa9RQz::UPLOADING]);
        goto ml9aA;
        voy2k:
        return $P2AJQ;
        goto H3oje;
        ml9aA:
        $P2AJQ->m3zp1EoQeXc(RwOJkCXwa9RQz::UPLOADING);
        goto voy2k;
        H3oje:
    }
    public function getView() : array
    {
        $FAUo0 = app(QhwgYzl056fwk::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $FAUo0->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $FAUo0->resolveThumbnail($this)];
    }
    public static function miCwnVnuzHF(UKWxL8i4Jx2NZ $xKDWF) : LGMw063tEE9ZC
    {
        goto Wjk_q;
        tY9kZ:
        return $xKDWF;
        goto DE2sg;
        pi3Mo:
        return (new LGMw063tEE9ZC())->fill($xKDWF->getAttributes());
        goto XHI25;
        Wjk_q:
        if (!$xKDWF instanceof LGMw063tEE9ZC) {
            goto IOKZb;
        }
        goto tY9kZ;
        DE2sg:
        IOKZb:
        goto pi3Mo;
        XHI25:
    }
}
