<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\Observer\Azekx5z9tMog9;
use Jfs\Uploader\Core\KHzXmciCVGzLc;
use Jfs\Uploader\Core\Traits\M1dxm8IlghHUG;
use Jfs\Uploader\Core\Traits\GYCzFqUkUYdjE;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Exception\BC4l4MMxB4wtt;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Exception\KQCoJb7DnfcxZ;
use Jfs\Uploader\Service\EJdnYZtMjtUUp;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class NfmgXUF97Fg3H implements SOB6nK7CGVegh
{
    use M1dxm8IlghHUG;
    use GYCzFqUkUYdjE;
    private $j8_AD;
    private function __construct($DejZC, $kGo1c)
    {
        $this->tp12K = $DejZC;
        $this->fz3B9 = $kGo1c;
    }
    private function mR2zc0ACWDM(string $EcbH3, $kGo1c, $k6y5k, bool $wAzY8 = false) : void
    {
        $this->mdS7hIgNvPC(new Azekx5z9tMog9($this, $kGo1c, $k6y5k, $EcbH3, $wAzY8));
    }
    public function getFile()
    {
        return $this->tp12K;
    }
    public function maHJweHZt83(array $X8on0) : void
    {
        $this->j8_AD = $X8on0;
    }
    public function mFzFxyOyRhP() : void
    {
        $this->mAPPeV3mHXi(Xy3InMky6jKYf::UPLOADING);
    }
    public function mSSLoFg4dyG() : void
    {
        $this->mAPPeV3mHXi(Xy3InMky6jKYf::UPLOADED);
    }
    public function m1XtLIZYW3f() : void
    {
        $this->mAPPeV3mHXi(Xy3InMky6jKYf::PROCESSING);
    }
    public function mj9BDEGvAB1() : void
    {
        $this->mAPPeV3mHXi(Xy3InMky6jKYf::FINISHED);
    }
    public function maBosN2qJq3() : void
    {
        $this->mAPPeV3mHXi(Xy3InMky6jKYf::ABORTED);
    }
    public function musHtpPk4T9() : array
    {
        return $this->j8_AD;
    }
    public static function m2baxpBz3iI(string $uuHkQ, $eoQVO, $C2YXG, $EcbH3) : self
    {
        goto tQqDM;
        fgLcd:
        $LKYnf->mR2zc0ACWDM($EcbH3, $eoQVO, $C2YXG);
        goto LCz0v;
        iNFDr:
        $LKYnf = new self($DejZC, $eoQVO);
        goto fgLcd;
        LCz0v:
        $LKYnf->mUg6EMktQTd(Xy3InMky6jKYf::UPLOADING);
        goto n4MK3;
        tQqDM:
        $DejZC = App::make(EJdnYZtMjtUUp::class)->mwXd6exkzqF(KHzXmciCVGzLc::mfxFf7GQ3ZC($uuHkQ));
        goto iNFDr;
        n4MK3:
        return $LKYnf->mDlbdm0o1yj();
        goto KJ8x0;
        KJ8x0:
    }
    public static function mkOth94gJm0($DejZC, $kGo1c, $k6y5k, $EcbH3, $wAzY8 = false) : self
    {
        goto GYtW7;
        b65S0:
        return $LKYnf;
        goto GrpC3;
        GYtW7:
        $LKYnf = new self($DejZC, $kGo1c);
        goto GCH5Z;
        GCH5Z:
        $LKYnf->mR2zc0ACWDM($EcbH3, $kGo1c, $k6y5k, $wAzY8);
        goto E0Oy3;
        E0Oy3:
        $LKYnf->mUg6EMktQTd(Xy3InMky6jKYf::UPLOADING);
        goto b65S0;
        GrpC3:
    }
}
