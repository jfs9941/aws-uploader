<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Contracts\O79PdR1cao6Xq;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\Traits\VexK8QON1Q211;
use Jfs\Uploader\Core\Traits\UPnDsKOL0mchi;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Service\PIItI2ah2Zu1r;
class IZ5shp3JHuftD extends OXsaQ69LP2fiA implements CxOTyXYpS0zWZ
{
    use VexK8QON1Q211;
    use UPnDsKOL0mchi;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $ixMzz, string $ydbmO) : self
    {
        goto fSevZ;
        fSevZ:
        $oaIJp = new self(['id' => $ixMzz, 'type' => $ydbmO, 'status' => LlMDscQw21XKp::UPLOADING]);
        goto r7edM;
        r7edM:
        $oaIJp->m92yZMBK6RM(LlMDscQw21XKp::UPLOADING);
        goto v86tZ;
        v86tZ:
        return $oaIJp;
        goto tMKWC;
        tMKWC:
    }
    public function getView() : array
    {
        $q7czo = app(O79PdR1cao6Xq::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $q7czo->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $q7czo->resolveThumbnail($this)];
    }
    public static function mcsCcsKbYAl(OXsaQ69LP2fiA $L7rEe) : IZ5shp3JHuftD
    {
        goto Fahj3;
        BefHA:
        m31l3:
        goto O8zGU;
        O8zGU:
        return (new IZ5shp3JHuftD())->fill($L7rEe->getAttributes());
        goto jirjo;
        Fahj3:
        if (!$L7rEe instanceof IZ5shp3JHuftD) {
            goto m31l3;
        }
        goto b7Xum;
        b7Xum:
        return $L7rEe;
        goto BefHA;
        jirjo:
    }
}
