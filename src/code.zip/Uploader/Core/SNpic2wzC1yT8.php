<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Contracts\SXC0PdU9S8rem;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\Traits\Vf8zHiJ8Htyjk;
use Jfs\Uploader\Core\Traits\TZStemugh45tx;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
class SNpic2wzC1yT8 extends Z3KXO9qO3sUsa implements Zv4WZkC8rwgvt
{
    use Vf8zHiJ8Htyjk;
    use TZStemugh45tx;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $CGBR8, string $QPWym) : self
    {
        goto Mb1W8;
        Drxt1:
        return $fxrDr;
        goto yf1eo;
        hJc2c:
        $fxrDr->mA93Wx3HDpN(WSEQ88VDOa3X0::UPLOADING);
        goto Drxt1;
        Mb1W8:
        $fxrDr = new self(['id' => $CGBR8, 'type' => $QPWym, 'status' => WSEQ88VDOa3X0::UPLOADING]);
        goto hJc2c;
        yf1eo:
    }
    public function width() : ?int
    {
        goto FwV31;
        EBRUu:
        dtw4T:
        goto YTKKh;
        YTKKh:
        return null;
        goto DYR2L;
        mG3MG:
        return $Nk4Te;
        goto EBRUu;
        FwV31:
        $Nk4Te = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto vR2uk;
        vR2uk:
        if (!$Nk4Te) {
            goto dtw4T;
        }
        goto mG3MG;
        DYR2L:
    }
    public function height() : ?int
    {
        goto aUzMW;
        cgX6U:
        if (!$jCfbb) {
            goto yOhaC;
        }
        goto mT0Op;
        aVNsw:
        return null;
        goto RCsMb;
        jHZth:
        yOhaC:
        goto aVNsw;
        aUzMW:
        $jCfbb = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto cgX6U;
        mT0Op:
        return $jCfbb;
        goto jHZth;
        RCsMb:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($fxrDr) {
            goto slw2F;
            isQUt:
            return;
            goto YzyUU;
            YzyUU:
            vRbjp:
            goto Tg02k;
            wHqUG:
            if (!(!array_key_exists('thumbnail', $Yjdsy) && !array_key_exists('hls_path', $Yjdsy))) {
                goto vRbjp;
            }
            goto isQUt;
            Tg02k:
            if (!($Yjdsy['thumbnail'] || $Yjdsy['hls_path'])) {
                goto fXnmS;
            }
            goto mzB0C;
            mzB0C:
            SNpic2wzC1yT8::where('parent_id', $fxrDr->getAttribute('id'))->update(['thumbnail' => $fxrDr->getAttributes()['thumbnail'], 'hls_path' => $fxrDr->getAttributes()['hls_path']]);
            goto REL0B;
            slw2F:
            $Yjdsy = $fxrDr->getDirty();
            goto wHqUG;
            REL0B:
            fXnmS:
            goto SZkM2;
            SZkM2:
        });
    }
    public function mgDWTJsepR0()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mICxBitpr2E()
    {
        return $this->getAttribute('id');
    }
    public function mCiKNgvmk5J() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Xy4Yi;
        RCse4:
        if ($this->getAttribute('hls_path')) {
            goto ugyDl;
        }
        goto off4B;
        CJYO3:
        $ld1HK['player_url'] = $ftO9B->resolvePathForHlsVideo($this, true);
        goto ffN0j;
        Xy4Yi:
        $ftO9B = app(SXC0PdU9S8rem::class);
        goto l5xf4;
        ffN0j:
        oBJfD:
        goto SX7FT;
        SX7FT:
        $ld1HK['thumbnail'] = $ftO9B->resolveThumbnail($this);
        goto cmMfq;
        fKwpz:
        ugyDl:
        goto CJYO3;
        off4B:
        $ld1HK['player_url'] = $ftO9B->resolvePath($this, $this->getAttribute('driver'));
        goto ynO3J;
        cmMfq:
        return $ld1HK;
        goto YZZlw;
        l5xf4:
        $ld1HK = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $ftO9B->resolvePath($this, $this->getAttribute('driver'))];
        goto RCse4;
        ynO3J:
        goto oBJfD;
        goto fKwpz;
        YZZlw:
    }
    public function getThumbnails()
    {
        goto CZUVs;
        Y0vwP:
        return array_map(function ($iSeOK) use($ftO9B) {
            return $ftO9B->resolvePath($iSeOK);
        }, $I4hoH);
        goto pHD3N;
        CZUVs:
        $I4hoH = $this->getAttribute('generated_previews') ?? [];
        goto N5gEP;
        N5gEP:
        $ftO9B = app(SXC0PdU9S8rem::class);
        goto Y0vwP;
        pHD3N:
    }
    public static function mqlrnEuOYnP(Z3KXO9qO3sUsa $ieBz5) : SNpic2wzC1yT8
    {
        goto NzGMR;
        uR4hW:
        sTH_v:
        goto HGTcm;
        NzGMR:
        if (!$ieBz5 instanceof SNpic2wzC1yT8) {
            goto sTH_v;
        }
        goto hc03o;
        hc03o:
        return $ieBz5;
        goto uR4hW;
        HGTcm:
        return (new SNpic2wzC1yT8())->fill($ieBz5->getAttributes());
        goto bQV4C;
        bQV4C:
    }
}
