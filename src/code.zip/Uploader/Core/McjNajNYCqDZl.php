<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Contracts\SXC0PdU9S8rem;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\Traits\Vf8zHiJ8Htyjk;
use Jfs\Uploader\Core\Traits\TZStemugh45tx;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Service\PyfePz8BX4gVQ;
class McjNajNYCqDZl extends Z3KXO9qO3sUsa implements Zv4WZkC8rwgvt
{
    use Vf8zHiJ8Htyjk;
    use TZStemugh45tx;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $CGBR8, string $QPWym) : self
    {
        goto jzqe0;
        ZUAc4:
        $qjq0G->mA93Wx3HDpN(WSEQ88VDOa3X0::UPLOADING);
        goto Wwm6T;
        jzqe0:
        $qjq0G = new self(['id' => $CGBR8, 'type' => $QPWym, 'status' => WSEQ88VDOa3X0::UPLOADING]);
        goto ZUAc4;
        Wwm6T:
        return $qjq0G;
        goto jMLuy;
        jMLuy:
    }
    public function getView() : array
    {
        $ftO9B = app(SXC0PdU9S8rem::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $ftO9B->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $ftO9B->resolveThumbnail($this)];
    }
    public static function m5KKffAjngV(Z3KXO9qO3sUsa $ieBz5) : McjNajNYCqDZl
    {
        goto Zqg33;
        QJxAN:
        return (new McjNajNYCqDZl())->fill($ieBz5->getAttributes());
        goto krBKv;
        Y2YmE:
        wRptv:
        goto QJxAN;
        AdM28:
        return $ieBz5;
        goto Y2YmE;
        Zqg33:
        if (!$ieBz5 instanceof McjNajNYCqDZl) {
            goto wRptv;
        }
        goto AdM28;
        krBKv:
    }
}
