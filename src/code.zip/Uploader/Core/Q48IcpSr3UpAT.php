<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Contracts\QmpIhYv3zjvt7;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Traits\OyShdbtmiDhqy;
use Jfs\Uploader\Core\Traits\VtC1QdkxsauRz;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Service\GRHQHm8JVCKmn;
class Q48IcpSr3UpAT extends THrRXrYMGJt0m implements Dsl7Uurv4XRG0
{
    use OyShdbtmiDhqy;
    use VtC1QdkxsauRz;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $seLPv, string $y_fdt) : self
    {
        goto XM9pB;
        F09cN:
        return $AvW7Y;
        goto EWAX0;
        XM9pB:
        $AvW7Y = new self(['id' => $seLPv, 'type' => $y_fdt, 'status' => FmSSI1JLQCp0W::UPLOADING]);
        goto aA0ho;
        aA0ho:
        $AvW7Y->m4fwFyIs4eQ(FmSSI1JLQCp0W::UPLOADING);
        goto F09cN;
        EWAX0:
    }
    public function getView() : array
    {
        $OnbMk = app(QmpIhYv3zjvt7::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $OnbMk->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $OnbMk->resolveThumbnail($this)];
    }
    public static function mfFzuceDwxY(THrRXrYMGJt0m $IdScp) : Q48IcpSr3UpAT
    {
        goto BGuWZ;
        kF_Yl:
        wIK0i:
        goto frFrJ;
        BGuWZ:
        if (!$IdScp instanceof Q48IcpSr3UpAT) {
            goto wIK0i;
        }
        goto AG9ZF;
        AG9ZF:
        return $IdScp;
        goto kF_Yl;
        frFrJ:
        return (new Q48IcpSr3UpAT())->fill($IdScp->getAttributes());
        goto hkYO3;
        hkYO3:
    }
}
