<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Core\Traits\SMO7C4a5P3uK2;
use Jfs\Uploader\Core\Traits\D1PKXaknZAaj4;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Service\TEgBbF7EqiUEB;
class Kx3NMUJqFpl5Q extends ZujQPL2bQTbeI implements Y0vs5qDfvPebz
{
    use SMO7C4a5P3uK2;
    use D1PKXaknZAaj4;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $o6Bjc, string $sJ7MD) : self
    {
        goto jOao_;
        hjxiH:
        $MpgR7->msLvxB5AWdO(SsxWbUYXracun::UPLOADING);
        goto JUXL5;
        jOao_:
        $MpgR7 = new self(['id' => $o6Bjc, 'type' => $sJ7MD, 'status' => SsxWbUYXracun::UPLOADING]);
        goto hjxiH;
        JUXL5:
        return $MpgR7;
        goto SrRy_;
        SrRy_:
    }
    public function getView() : array
    {
        $VXB2z = app(ECHrJsgxCR7OQ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $VXB2z->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $VXB2z->resolveThumbnail($this)];
    }
    public static function mYJzrtoXl6R(ZujQPL2bQTbeI $Rcq7S) : Kx3NMUJqFpl5Q
    {
        goto Gp5kK;
        Gp5kK:
        if (!$Rcq7S instanceof Kx3NMUJqFpl5Q) {
            goto Jh3VR;
        }
        goto MEHu5;
        nUwJp:
        return (new Kx3NMUJqFpl5Q())->fill($Rcq7S->getAttributes());
        goto CH2yZ;
        MEHu5:
        return $Rcq7S;
        goto cD1Qd;
        cD1Qd:
        Jh3VR:
        goto nUwJp;
        CH2yZ:
    }
}
