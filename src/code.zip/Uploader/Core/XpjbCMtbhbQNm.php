<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Contracts\ZBw3vE9HMeZfI;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\Traits\Ek8Ahis6odNzI;
use Jfs\Uploader\Core\Traits\NjN8yZvSzpWnf;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Service\Q9u6o449sXscP;
class XpjbCMtbhbQNm extends MIyg7KY6jn9L1 implements CyraHfwSfcIZC
{
    use Ek8Ahis6odNzI;
    use NjN8yZvSzpWnf;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $YJReg, string $bE8Rq) : self
    {
        goto rgcTz;
        iqLns:
        return $IF0O8;
        goto IzIKQ;
        zE1Na:
        $IF0O8->mXpDCMvZsDA(A9q1Lm9l5QixG::UPLOADING);
        goto iqLns;
        rgcTz:
        $IF0O8 = new self(['id' => $YJReg, 'type' => $bE8Rq, 'status' => A9q1Lm9l5QixG::UPLOADING]);
        goto zE1Na;
        IzIKQ:
    }
    public function getView() : array
    {
        $lzVN0 = app(ZBw3vE9HMeZfI::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $lzVN0->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $lzVN0->resolveThumbnail($this)];
    }
    public static function mNrRjIAanK0(MIyg7KY6jn9L1 $IcEa3) : XpjbCMtbhbQNm
    {
        goto Z6smY;
        zwXoj:
        LCKzO:
        goto Wo1gx;
        Wo1gx:
        return (new XpjbCMtbhbQNm())->fill($IcEa3->getAttributes());
        goto szSZj;
        Bbd1z:
        return $IcEa3;
        goto zwXoj;
        Z6smY:
        if (!$IcEa3 instanceof XpjbCMtbhbQNm) {
            goto LCKzO;
        }
        goto Bbd1z;
        szSZj:
    }
}
