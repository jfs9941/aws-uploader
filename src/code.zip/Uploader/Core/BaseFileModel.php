<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Enum\FileDriver;

/**
 * @property int     $status
 * @property string  $thumbnail
 * @property string  $filename
 * @property string  $preview
 * @property string  $id
 * @property ?string $parent_id
 * @property string  $original_path
 * @property string  $resolution
 * @property int     $driver
 */
abstract class BaseFileModel extends Model implements FileInterface
{
    public $incrementing = false;

    protected $fillable = [
        'user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id',
        // FOR UPLOAD V2
        'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved',
        'stock_message_id', 'generated_previews'
    ];

    protected $table = 'attachments';

    protected $casts = [
        'id' => 'string',
        'generated_previews' => 'array',
        'driver' => 'int',
        'status' => 'int',
    ];

    public function canDelete(): bool
    {
        if (null === $this->getAttribute('post_id')
            && null === $this->getAttribute('message_id')
            && null === $this->getAttribute('shop_item_id')) {
            return true;
        }

        return !$this->isOriginal();
    }

    protected function isOriginal(): bool
    {
        return null === $this->getAttribute('parent_id');
    }

    public abstract function getView(): array;
}
