<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Core\Traits\FdeEVbF7HDTyC;
use Jfs\Uploader\Core\Traits\LPvREnedjbdSc;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Service\Uzq9No60iqNHV;
class NBWuSM65HseqY extends HJJu0xs0QACaQ implements IEfiXfym24wIp
{
    use FdeEVbF7HDTyC;
    use LPvREnedjbdSc;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $yU2y0, string $Vb_Cv) : self
    {
        goto VSDtn;
        MNi5R:
        $CPHMS->myNb3hyTkbG(N4CY6qDTBAjPa::UPLOADING);
        goto GS4SO;
        VSDtn:
        $CPHMS = new self(['id' => $yU2y0, 'type' => $Vb_Cv, 'status' => N4CY6qDTBAjPa::UPLOADING]);
        goto MNi5R;
        GS4SO:
        return $CPHMS;
        goto rRFoD;
        rRFoD:
    }
    public function getView() : array
    {
        $B5JAi = app(UKSr4EAd7qrlK::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $B5JAi->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $B5JAi->resolveThumbnail($this)];
    }
    public static function mWHW8Fl7CnX(HJJu0xs0QACaQ $MgH4F) : NBWuSM65HseqY
    {
        goto pFwJw;
        zn2Ff:
        TIIp8:
        goto J9ZV6;
        pFwJw:
        if (!$MgH4F instanceof NBWuSM65HseqY) {
            goto TIIp8;
        }
        goto aNMWp;
        J9ZV6:
        return (new NBWuSM65HseqY())->fill($MgH4F->getAttributes());
        goto J_3nv;
        aNMWp:
        return $MgH4F;
        goto zn2Ff;
        J_3nv:
    }
}
