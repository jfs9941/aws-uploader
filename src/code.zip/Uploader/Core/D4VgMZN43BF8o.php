<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\Observer\YpwyNSmltx55J;
use Jfs\Uploader\Core\XxIkOu3r3u4yJ;
use Jfs\Uploader\Core\Traits\P1w7YvygOqgXZ;
use Jfs\Uploader\Core\Traits\NjN8yZvSzpWnf;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Exception\O21XtZt2mzRw1;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Exception\ST4IwPMeWC8T9;
use Jfs\Uploader\Service\L3m1gGxcrxodn;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class D4VgMZN43BF8o implements CyraHfwSfcIZC
{
    use P1w7YvygOqgXZ;
    use NjN8yZvSzpWnf;
    private $jBZ8q;
    private function __construct($k2MU3, $XCkIj)
    {
        $this->VCrIB = $k2MU3;
        $this->NZ4o8 = $XCkIj;
    }
    private function mjzgiG2oKHA(string $APN4u, $XCkIj, $UubHF, bool $pQOyB = false) : void
    {
        $this->mZHCv5SIdJ7(new YpwyNSmltx55J($this, $XCkIj, $UubHF, $APN4u, $pQOyB));
    }
    public function getFile()
    {
        return $this->VCrIB;
    }
    public function mJCTfUV9czb(array $xsJEe) : void
    {
        $this->jBZ8q = $xsJEe;
    }
    public function mlJIEdRvYbl() : void
    {
        $this->ms4OoFrTljH(A9q1Lm9l5QixG::UPLOADING);
    }
    public function mNfgZ31Jw4I() : void
    {
        $this->ms4OoFrTljH(A9q1Lm9l5QixG::UPLOADED);
    }
    public function mAGlms8OKHG() : void
    {
        $this->ms4OoFrTljH(A9q1Lm9l5QixG::PROCESSING);
    }
    public function m7yElLj3XNe() : void
    {
        $this->ms4OoFrTljH(A9q1Lm9l5QixG::FINISHED);
    }
    public function mes5Pm0Gmgd() : void
    {
        $this->ms4OoFrTljH(A9q1Lm9l5QixG::ABORTED);
    }
    public function mD2bzG2lTmU() : array
    {
        return $this->jBZ8q;
    }
    public static function mZrdRG94VR0(string $N2oAf, $xd0Sw, $Efy84, $APN4u) : self
    {
        goto DNjPw;
        hYBHC:
        return $VX4cz->mPo0mAGzHS9();
        goto Hm7zJ;
        DNjPw:
        $k2MU3 = App::make(L3m1gGxcrxodn::class)->mCcF1uxq2Dw(XxIkOu3r3u4yJ::mCDEbHkhoSq($N2oAf));
        goto jl3KV;
        ZIZy_:
        $VX4cz->mjzgiG2oKHA($APN4u, $xd0Sw, $Efy84);
        goto sCTyX;
        sCTyX:
        $VX4cz->mXpDCMvZsDA(A9q1Lm9l5QixG::UPLOADING);
        goto hYBHC;
        jl3KV:
        $VX4cz = new self($k2MU3, $xd0Sw);
        goto ZIZy_;
        Hm7zJ:
    }
    public static function miICgCVs1tP($k2MU3, $XCkIj, $UubHF, $APN4u, $pQOyB = false) : self
    {
        goto qmIFd;
        Z0hrb:
        $VX4cz->mXpDCMvZsDA(A9q1Lm9l5QixG::UPLOADING);
        goto W9LNH;
        W9LNH:
        return $VX4cz;
        goto I4oMf;
        x5_zs:
        $VX4cz->mjzgiG2oKHA($APN4u, $XCkIj, $UubHF, $pQOyB);
        goto Z0hrb;
        qmIFd:
        $VX4cz = new self($k2MU3, $XCkIj);
        goto x5_zs;
        I4oMf:
    }
}
