<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

interface N8O216tH1Gxax
{
    public function getFilename() : string;
    public function getExtension() : string;
    public function getType() : string;
    public function getLocation() : string;
    public function initLocation(string $ajlxd);
    public static function createFromScratch(string $tbOMu, string $g88NJ);
    public function getView();
}
