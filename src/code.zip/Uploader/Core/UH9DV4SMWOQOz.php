<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
final class UH9DV4SMWOQOz
{
    public $filename;
    public $B2Zq2;
    public $nL0uY;
    public $qVkMu;
    public $wuhof;
    public $Xb0r9;
    public $Nb7VL;
    public $status;
    public $TP6h2;
    public $ZiXeF;
    public $Gm9Y9 = 's3';
    public $ie343 = [];
    public function __construct($GPU3A, $is_cA, $pOR06, $AYqdX, $GXwkN, $LVKMJ, $kRtZt, $eBsRM, $FiELQ, $IaSct, $bwFaL = 's3', $H1_VI = [])
    {
        goto Erbqy;
        r4lfm:
        $this->B2Zq2 = $is_cA;
        goto ADS6B;
        Erbqy:
        $this->filename = $GPU3A;
        goto r4lfm;
        Bm4ZY:
        $this->Xb0r9 = $LVKMJ;
        goto mUR05;
        CIUMo:
        $this->ZiXeF = $IaSct;
        goto qJ2We;
        oEuJZ:
        $this->ie343 = $H1_VI;
        goto y6KMV;
        uGayy:
        $this->wuhof = $GXwkN;
        goto Bm4ZY;
        ADS6B:
        $this->nL0uY = $pOR06;
        goto q9W2b;
        mUR05:
        $this->Nb7VL = $kRtZt;
        goto aEfL4;
        q9W2b:
        $this->qVkMu = $AYqdX;
        goto uGayy;
        aEfL4:
        $this->status = $eBsRM;
        goto bRHEF;
        bRHEF:
        $this->TP6h2 = $FiELQ;
        goto CIUMo;
        qJ2We:
        $this->Gm9Y9 = $bwFaL;
        goto oEuJZ;
        y6KMV:
    }
    private static function mITr8VpOXdo() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function ml5huWGDhwq() : array
    {
        return array_flip(self::mITr8VpOXdo());
    }
    public function toArray() : array
    {
        $TOn0k = self::mITr8VpOXdo();
        return [$TOn0k['filename'] => $this->filename, $TOn0k['fileExtension'] => $this->B2Zq2, $TOn0k['mimeType'] => $this->nL0uY, $TOn0k['fileSize'] => $this->qVkMu, $TOn0k['chunkSize'] => $this->wuhof, $TOn0k['checksums'] => $this->Xb0r9, $TOn0k['totalChunk'] => $this->Nb7VL, $TOn0k['status'] => $this->status, $TOn0k['userId'] => $this->TP6h2, $TOn0k['uploadId'] => $this->ZiXeF, $TOn0k['driver'] => $this->Gm9Y9, $TOn0k['parts'] => $this->ie343];
    }
    public static function m8NkDluQ8vr(array $hg2KO) : self
    {
        $gP5UA = array_flip(self::ml5huWGDhwq());
        return new self($hg2KO[$gP5UA['filename']] ?? $hg2KO['filename'] ?? '', $hg2KO[$gP5UA['fileExtension']] ?? $hg2KO['fileExtension'] ?? '', $hg2KO[$gP5UA['mimeType']] ?? $hg2KO['mimeType'] ?? '', $hg2KO[$gP5UA['fileSize']] ?? $hg2KO['fileSize'] ?? 0, $hg2KO[$gP5UA['chunkSize']] ?? $hg2KO['chunkSize'] ?? 0, $hg2KO[$gP5UA['checksums']] ?? $hg2KO['checksums'] ?? [], $hg2KO[$gP5UA['totalChunk']] ?? $hg2KO['totalChunk'] ?? 0, $hg2KO[$gP5UA['status']] ?? $hg2KO['status'] ?? 0, $hg2KO[$gP5UA['userId']] ?? $hg2KO['userId'] ?? 0, $hg2KO[$gP5UA['uploadId']] ?? $hg2KO['uploadId'] ?? '', $hg2KO[$gP5UA['driver']] ?? $hg2KO['driver'] ?? 's3', $hg2KO[$gP5UA['parts']] ?? $hg2KO['parts'] ?? []);
    }
    public static function mOTyUjsFr9A($oDqPu) : self
    {
        goto yWkcr;
        yWkcr:
        if (!(isset($oDqPu['fn']) || isset($oDqPu['fe']))) {
            goto OB28u;
        }
        goto C0Q4c;
        C0Q4c:
        return self::m8NkDluQ8vr($oDqPu);
        goto EhlvC;
        EhlvC:
        OB28u:
        goto VpX4F;
        VpX4F:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto D6mzH;
        D6mzH:
    }
    public function m3wuWcoEsff(string $IaSct) : void
    {
        $this->ZiXeF = $IaSct;
    }
    public function muWf58XVBlf(array $H1_VI) : void
    {
        $this->ie343 = $H1_VI;
    }
    public static function mSB5rveE26y($bwI0g, $io1uw, $xmiEG, $FiELQ, $GXwkN, $LVKMJ, $bwFaL)
    {
        return new self($bwI0g->getFilename(), $bwI0g->getExtension(), $io1uw, $xmiEG, $GXwkN, $LVKMJ, count($LVKMJ), WSEQ88VDOa3X0::UPLOADING, $FiELQ, 0, $bwFaL, []);
    }
    public static function mKCPcRTfEeG($tu00C)
    {
        return 'metadata/' . $tu00C . '.json';
    }
    public function mgJNw7RoTDj()
    {
        return 's3' === $this->Gm9Y9 ? ISqBWmYzjt1eQ::S3 : ISqBWmYzjt1eQ::LOCAL;
    }
}
