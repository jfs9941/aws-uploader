<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\Observer\Zs8OhAW9qDkTw;
use Jfs\Uploader\Core\Icfhroj1Rrrzn;
use Jfs\Uploader\Core\Traits\CFWlVgfsxtnSg;
use Jfs\Uploader\Core\Traits\UPnDsKOL0mchi;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Exception\JgcJVhkHS65KD;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Exception\WWU79WdJSmf1K;
use Jfs\Uploader\Service\TFO1z3TFjdeZq;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Wa740mKVvCN9d implements CxOTyXYpS0zWZ
{
    use CFWlVgfsxtnSg;
    use UPnDsKOL0mchi;
    private $J1Ice;
    private function __construct($spSJx, $xuow1)
    {
        $this->Fhq5F = $spSJx;
        $this->n1h4w = $xuow1;
    }
    private function mjU7FULCVwh(string $xYZ3A, $xuow1, $C82jg, bool $Xnamn = false) : void
    {
        $this->m4PcztHRQdJ(new Zs8OhAW9qDkTw($this, $xuow1, $C82jg, $xYZ3A, $Xnamn));
    }
    public function getFile()
    {
        return $this->Fhq5F;
    }
    public function miZvF1lrUqz(array $csNZU) : void
    {
        $this->J1Ice = $csNZU;
    }
    public function mFYCb5T2MTm() : void
    {
        $this->mmrYWGPqYWx(LlMDscQw21XKp::UPLOADING);
    }
    public function mieXlIddk03() : void
    {
        $this->mmrYWGPqYWx(LlMDscQw21XKp::UPLOADED);
    }
    public function mCTgD0MzwOX() : void
    {
        $this->mmrYWGPqYWx(LlMDscQw21XKp::PROCESSING);
    }
    public function mALZJatptUu() : void
    {
        $this->mmrYWGPqYWx(LlMDscQw21XKp::FINISHED);
    }
    public function mo2jzTGzJop() : void
    {
        $this->mmrYWGPqYWx(LlMDscQw21XKp::ABORTED);
    }
    public function mYn0NQBvboY() : array
    {
        return $this->J1Ice;
    }
    public static function mubHrcw8ws9(string $GhyxD, $Wrf1u, $oOPBt, $xYZ3A) : self
    {
        goto iE204;
        iE204:
        $spSJx = App::make(TFO1z3TFjdeZq::class)->mW8OyAsEfnb(Icfhroj1Rrrzn::mOQJSxSdp2A($GhyxD));
        goto YPx0O;
        lTYeB:
        $ar7VQ->mjU7FULCVwh($xYZ3A, $Wrf1u, $oOPBt);
        goto oefxy;
        gzZSm:
        return $ar7VQ->mgm9G4tMUce();
        goto n3EL0;
        oefxy:
        $ar7VQ->m92yZMBK6RM(LlMDscQw21XKp::UPLOADING);
        goto gzZSm;
        YPx0O:
        $ar7VQ = new self($spSJx, $Wrf1u);
        goto lTYeB;
        n3EL0:
    }
    public static function mxISck3N94O($spSJx, $xuow1, $C82jg, $xYZ3A, $Xnamn = false) : self
    {
        goto wUNpJ;
        yMEIP:
        $ar7VQ->m92yZMBK6RM(LlMDscQw21XKp::UPLOADING);
        goto KBVR7;
        wUNpJ:
        $ar7VQ = new self($spSJx, $xuow1);
        goto le8v9;
        KBVR7:
        return $ar7VQ;
        goto EIv90;
        le8v9:
        $ar7VQ->mjU7FULCVwh($xYZ3A, $xuow1, $C82jg, $Xnamn);
        goto yMEIP;
        EIv90:
    }
}
