<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Contracts\ZBw3vE9HMeZfI;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\Traits\Ek8Ahis6odNzI;
use Jfs\Uploader\Core\Traits\NjN8yZvSzpWnf;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
class VPegVN4NByLqJ extends MIyg7KY6jn9L1 implements CyraHfwSfcIZC
{
    use Ek8Ahis6odNzI;
    use NjN8yZvSzpWnf;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $YJReg, string $bE8Rq) : self
    {
        goto nsrMB;
        Z0bFn:
        $fTkob->mXpDCMvZsDA(A9q1Lm9l5QixG::UPLOADING);
        goto r9bFb;
        nsrMB:
        $fTkob = new self(['id' => $YJReg, 'type' => $bE8Rq, 'status' => A9q1Lm9l5QixG::UPLOADING]);
        goto Z0bFn;
        r9bFb:
        return $fTkob;
        goto oZTij;
        oZTij:
    }
    public function width() : ?int
    {
        goto x84v_;
        jYhW8:
        if (!$lvh9C) {
            goto uOb7p;
        }
        goto Mn_oU;
        x84v_:
        $lvh9C = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto jYhW8;
        fHhe6:
        uOb7p:
        goto dfU9F;
        Mn_oU:
        return $lvh9C;
        goto fHhe6;
        dfU9F:
        return null;
        goto HCcHY;
        HCcHY:
    }
    public function height() : ?int
    {
        goto zZRCA;
        zZRCA:
        $S3Wk9 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto Lwwn7;
        QCCKN:
        return $S3Wk9;
        goto o3LJw;
        Lwwn7:
        if (!$S3Wk9) {
            goto XugiZ;
        }
        goto QCCKN;
        o3LJw:
        XugiZ:
        goto xoYUS;
        xoYUS:
        return null;
        goto U1Zz0;
        U1Zz0:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($fTkob) {
            goto MZXOK;
            BtzBy:
            return;
            goto zCvgj;
            zCvgj:
            S8T1C:
            goto ktnDB;
            ktnDB:
            if (!($AQGh6['thumbnail'] || $AQGh6['hls_path'])) {
                goto pQ5Ti;
            }
            goto yAU8k;
            ewsOy:
            pQ5Ti:
            goto zEUgm;
            MZXOK:
            $AQGh6 = $fTkob->getDirty();
            goto GZXAc;
            yAU8k:
            VPegVN4NByLqJ::where('parent_id', $fTkob->getAttribute('id'))->update(['thumbnail' => $fTkob->getAttributes()['thumbnail'], 'hls_path' => $fTkob->getAttributes()['hls_path']]);
            goto ewsOy;
            GZXAc:
            if (!(!array_key_exists('thumbnail', $AQGh6) && !array_key_exists('hls_path', $AQGh6))) {
                goto S8T1C;
            }
            goto BtzBy;
            zEUgm:
        });
    }
    public function m9e9XQuiLEH()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mIXa2znT3RZ()
    {
        return $this->getAttribute('id');
    }
    public function mcxyVxlfFDn() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto wsEWT;
        tzDAE:
        gAaQp:
        goto vc7WI;
        wsEWT:
        $lzVN0 = app(ZBw3vE9HMeZfI::class);
        goto gvPDz;
        VFBXP:
        goto xwKTL;
        goto tzDAE;
        uI3pE:
        if ($this->getAttribute('hls_path')) {
            goto gAaQp;
        }
        goto WoG3O;
        XQ_xw:
        xwKTL:
        goto jc4uu;
        jc4uu:
        $KqiYb['thumbnail'] = $lzVN0->resolveThumbnail($this);
        goto GhipU;
        WoG3O:
        $KqiYb['player_url'] = $lzVN0->resolvePath($this, $this->getAttribute('driver'));
        goto VFBXP;
        GhipU:
        return $KqiYb;
        goto O72LI;
        vc7WI:
        $KqiYb['player_url'] = $lzVN0->resolvePathForHlsVideo($this, true);
        goto XQ_xw;
        gvPDz:
        $KqiYb = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $lzVN0->resolvePath($this, $this->getAttribute('driver'))];
        goto uI3pE;
        O72LI:
    }
    public function getThumbnails()
    {
        goto Zp5L6;
        k5mZa:
        return array_map(function ($oEyCz) use($lzVN0) {
            return $lzVN0->resolvePath($oEyCz);
        }, $piein);
        goto c701i;
        Zp5L6:
        $piein = $this->getAttribute('generated_previews') ?? [];
        goto Ti5o5;
        Ti5o5:
        $lzVN0 = app(ZBw3vE9HMeZfI::class);
        goto k5mZa;
        c701i:
    }
    public static function mBXl913uoSe(MIyg7KY6jn9L1 $IcEa3) : VPegVN4NByLqJ
    {
        goto iYlKn;
        MmZva:
        JhKAZ:
        goto Y8Dau;
        iYlKn:
        if (!$IcEa3 instanceof VPegVN4NByLqJ) {
            goto JhKAZ;
        }
        goto P9AjA;
        P9AjA:
        return $IcEa3;
        goto MmZva;
        Y8Dau:
        return (new VPegVN4NByLqJ())->fill($IcEa3->getAttributes());
        goto SY8Xq;
        SY8Xq:
    }
}
