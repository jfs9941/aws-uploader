<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Contracts\WLzh1GrcHwitv;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\Traits\SyABBXn5GOmzX;
use Jfs\Uploader\Core\Traits\IkSz95bOOEAyh;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Service\VLNeV396JQx1d;
class U0IzvN2kaLZHI extends UfttW7MErNAIK implements B7NusEU08Li4E
{
    use SyABBXn5GOmzX;
    use IkSz95bOOEAyh;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $g6MG9, string $Cm600) : self
    {
        goto hzmZq;
        nGOyA:
        return $jYl_6;
        goto TQvVF;
        hzmZq:
        $jYl_6 = new self(['id' => $g6MG9, 'type' => $Cm600, 'status' => KidkTsWIjmNMb::UPLOADING]);
        goto eIhbP;
        eIhbP:
        $jYl_6->moSEUBFRxDt(KidkTsWIjmNMb::UPLOADING);
        goto nGOyA;
        TQvVF:
    }
    public function getView() : array
    {
        $mjpq3 = app(WLzh1GrcHwitv::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $mjpq3->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $mjpq3->resolveThumbnail($this)];
    }
    public static function m73RU6tUJOs(UfttW7MErNAIK $gYpY3) : U0IzvN2kaLZHI
    {
        goto MlP2K;
        MlP2K:
        if (!$gYpY3 instanceof U0IzvN2kaLZHI) {
            goto kFZMJ;
        }
        goto vOCuu;
        mB6WE:
        kFZMJ:
        goto wn1Ma;
        wn1Ma:
        return (new U0IzvN2kaLZHI())->fill($gYpY3->getAttributes());
        goto ZZ_2R;
        vOCuu:
        return $gYpY3;
        goto mB6WE;
        ZZ_2R:
    }
}
