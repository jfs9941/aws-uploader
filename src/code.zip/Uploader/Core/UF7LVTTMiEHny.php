<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Contracts\VjEI9Nu3TyWfD;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Traits\CD8fs6jM2d7v1;
use Jfs\Uploader\Core\Traits\RWUAoQ6vUS0uH;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Service\IeMg7A21r884m;
class UF7LVTTMiEHny extends EpIpyfdFnoTz6 implements WZhCwGsxQbxug
{
    use CD8fs6jM2d7v1;
    use RWUAoQ6vUS0uH;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $chz0R, string $T_yZW) : self
    {
        goto piWlv;
        y6ROo:
        $xipyx->myjAI8i1TR7(Fsm7WCrUwVWh9::UPLOADING);
        goto XeHAa;
        XeHAa:
        return $xipyx;
        goto rtOQf;
        piWlv:
        $xipyx = new self(['id' => $chz0R, 'type' => $T_yZW, 'status' => Fsm7WCrUwVWh9::UPLOADING]);
        goto y6ROo;
        rtOQf:
    }
    public function getView() : array
    {
        $YTknp = app(VjEI9Nu3TyWfD::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $YTknp->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $YTknp->resolveThumbnail($this)];
    }
    public static function mkfp0EymnNm(EpIpyfdFnoTz6 $HZKvy) : UF7LVTTMiEHny
    {
        goto N41Hv;
        afU0C:
        return $HZKvy;
        goto H5jhz;
        rhQc0:
        return (new UF7LVTTMiEHny())->fill($HZKvy->getAttributes());
        goto YH2cs;
        H5jhz:
        ZnDai:
        goto rhQc0;
        N41Hv:
        if (!$HZKvy instanceof UF7LVTTMiEHny) {
            goto ZnDai;
        }
        goto afU0C;
        YH2cs:
    }
}
