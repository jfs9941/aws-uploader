<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core;

use src\Uploader\Contracts\MGwfEiRGIYlUs;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\Traits\GGdwEU4dd3qMI;
use src\Uploader\Core\Traits\NURFewLmHDDb8;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Service\FtIk1ybHOJjaq;
class GoopVn9iYwlO0 extends TvpGfrAj9WMXE implements PxmUcH2EZiEWo
{
    use GGdwEU4dd3qMI;
    use NURFewLmHDDb8;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $rHgUV, string $cvjX2) : self
    {
        goto PONfr;
        cszT0:
        $NsAQp->mRGXJFOfzBv(FileStatus::UPLOADING);
        goto Eqld6;
        PONfr:
        $NsAQp = new self(['id' => $rHgUV, 'type' => $cvjX2, 'status' => FileStatus::UPLOADING]);
        goto cszT0;
        Eqld6:
        return $NsAQp;
        goto o8YPf;
        o8YPf:
    }
    public function getView() : array
    {
        $LMUnW = app(MGwfEiRGIYlUs::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $LMUnW->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $LMUnW->resolveThumbnail($this)];
    }
    public static function mkMxaw28x1V(TvpGfrAj9WMXE $jVT23) : GoopVn9iYwlO0
    {
        goto tjpwo;
        HKiBL:
        CJ_3m:
        goto bK8wF;
        iV8Nj:
        return $jVT23;
        goto HKiBL;
        tjpwo:
        if (!$jVT23 instanceof GoopVn9iYwlO0) {
            goto CJ_3m;
        }
        goto iV8Nj;
        bK8wF:
        return (new GoopVn9iYwlO0())->fill($jVT23->getAttributes());
        goto Wj6x2;
        Wj6x2:
    }
}
