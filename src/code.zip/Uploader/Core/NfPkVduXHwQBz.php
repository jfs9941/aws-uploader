<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Contracts\Dm945121dFKVW;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\Traits\EpBhYo5NrILTt;
use Jfs\Uploader\Core\Traits\LkAAxyhGgmAFk;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Service\QNlFAcHy60ycp;
class NfPkVduXHwQBz extends Zl4rdW32ufaUx implements FTr6mgGRFf157
{
    use EpBhYo5NrILTt;
    use LkAAxyhGgmAFk;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $FIM0D, string $EE6bd) : self
    {
        goto rrfgJ;
        kBvEK:
        return $JcMH5;
        goto TakGW;
        rrfgJ:
        $JcMH5 = new self(['id' => $FIM0D, 'type' => $EE6bd, 'status' => LV0wDYHZInswq::UPLOADING]);
        goto oOT1C;
        oOT1C:
        $JcMH5->mHWfC8guF82(LV0wDYHZInswq::UPLOADING);
        goto kBvEK;
        TakGW:
    }
    public function getView() : array
    {
        $Y_PMr = app(Dm945121dFKVW::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $Y_PMr->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Y_PMr->resolveThumbnail($this)];
    }
    public static function mg5qg8lzFlZ(Zl4rdW32ufaUx $vPecg) : NfPkVduXHwQBz
    {
        goto SasNE;
        Fri2w:
        return (new NfPkVduXHwQBz())->fill($vPecg->getAttributes());
        goto rRjuJ;
        SasNE:
        if (!$vPecg instanceof NfPkVduXHwQBz) {
            goto vK7o8;
        }
        goto tk6zZ;
        y2mpN:
        vK7o8:
        goto Fri2w;
        tk6zZ:
        return $vPecg;
        goto y2mpN;
        rRjuJ:
    }
}
