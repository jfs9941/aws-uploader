<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\NYPGraEb3Ennl;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
final class Hyi6BrRTUHRYH
{
    public $filename;
    public $eBQ45;
    public $iZuc7;
    public $WnwLD;
    public $jrVTh;
    public $nx1O1;
    public $NSSAu;
    public $status;
    public $D7poy;
    public $uKrjd;
    public $LjaQU = 's3';
    public $wihQa = [];
    public function __construct($RO6j_, $BI43q, $S8nr9, $j_8g3, $XjqSL, $ZxcNO, $MZ9AD, $DVkZ6, $efA5J, $Oq4nq, $ewvCB = 's3', $AbKCX = [])
    {
        goto xkrj0;
        fgQNS:
        $this->eBQ45 = $BI43q;
        goto b54LC;
        aaQ_J:
        $this->LjaQU = $ewvCB;
        goto mJIIw;
        rJDKp:
        $this->jrVTh = $XjqSL;
        goto Z5dJ_;
        uVxH2:
        $this->D7poy = $efA5J;
        goto ytR9v;
        Z5dJ_:
        $this->nx1O1 = $ZxcNO;
        goto NQKss;
        UQsCR:
        $this->WnwLD = $j_8g3;
        goto rJDKp;
        mJIIw:
        $this->wihQa = $AbKCX;
        goto LEPOk;
        ytR9v:
        $this->uKrjd = $Oq4nq;
        goto aaQ_J;
        nGBGR:
        $this->status = $DVkZ6;
        goto uVxH2;
        NQKss:
        $this->NSSAu = $MZ9AD;
        goto nGBGR;
        b54LC:
        $this->iZuc7 = $S8nr9;
        goto UQsCR;
        xkrj0:
        $this->filename = $RO6j_;
        goto fgQNS;
        LEPOk:
    }
    private static function mi3x2vebEQP() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mOSFsZE6MKR() : array
    {
        return array_flip(self::mi3x2vebEQP());
    }
    public function toArray() : array
    {
        $tadHl = self::mi3x2vebEQP();
        return [$tadHl['filename'] => $this->filename, $tadHl['fileExtension'] => $this->eBQ45, $tadHl['mimeType'] => $this->iZuc7, $tadHl['fileSize'] => $this->WnwLD, $tadHl['chunkSize'] => $this->jrVTh, $tadHl['checksums'] => $this->nx1O1, $tadHl['totalChunk'] => $this->NSSAu, $tadHl['status'] => $this->status, $tadHl['userId'] => $this->D7poy, $tadHl['uploadId'] => $this->uKrjd, $tadHl['driver'] => $this->LjaQU, $tadHl['parts'] => $this->wihQa];
    }
    public static function m0B1AYMIsca(array $cV0ae) : self
    {
        $Kqcmu = array_flip(self::mOSFsZE6MKR());
        return new self($cV0ae[$Kqcmu['filename']] ?? $cV0ae['filename'] ?? '', $cV0ae[$Kqcmu['fileExtension']] ?? $cV0ae['fileExtension'] ?? '', $cV0ae[$Kqcmu['mimeType']] ?? $cV0ae['mimeType'] ?? '', $cV0ae[$Kqcmu['fileSize']] ?? $cV0ae['fileSize'] ?? 0, $cV0ae[$Kqcmu['chunkSize']] ?? $cV0ae['chunkSize'] ?? 0, $cV0ae[$Kqcmu['checksums']] ?? $cV0ae['checksums'] ?? [], $cV0ae[$Kqcmu['totalChunk']] ?? $cV0ae['totalChunk'] ?? 0, $cV0ae[$Kqcmu['status']] ?? $cV0ae['status'] ?? 0, $cV0ae[$Kqcmu['userId']] ?? $cV0ae['userId'] ?? 0, $cV0ae[$Kqcmu['uploadId']] ?? $cV0ae['uploadId'] ?? '', $cV0ae[$Kqcmu['driver']] ?? $cV0ae['driver'] ?? 's3', $cV0ae[$Kqcmu['parts']] ?? $cV0ae['parts'] ?? []);
    }
    public static function mMt2F10WYwv($DrR_Q) : self
    {
        goto N1UFk;
        eH1pQ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto tuywq;
        N1UFk:
        if (!(isset($DrR_Q['fn']) || isset($DrR_Q['fe']))) {
            goto BIn5p;
        }
        goto c92_P;
        kD5mA:
        BIn5p:
        goto eH1pQ;
        c92_P:
        return self::m0B1AYMIsca($DrR_Q);
        goto kD5mA;
        tuywq:
    }
    public function mCpgWR31fRN(string $Oq4nq) : void
    {
        $this->uKrjd = $Oq4nq;
    }
    public function mIwkuoaBBlU(array $AbKCX) : void
    {
        $this->wihQa = $AbKCX;
    }
    public static function mh7n9EI1nrg($oYtbp, $Pg2Ll, $oZuOJ, $efA5J, $XjqSL, $ZxcNO, $ewvCB)
    {
        return new self($oYtbp->getFilename(), $oYtbp->getExtension(), $Pg2Ll, $oZuOJ, $XjqSL, $ZxcNO, count($ZxcNO), OLX71luAn6XnP::UPLOADING, $efA5J, 0, $ewvCB, []);
    }
    public static function me28TlZc9hY($Qu08p)
    {
        return 'metadata/' . $Qu08p . '.json';
    }
    public function m6VKberL6M5()
    {
        return 's3' === $this->LjaQU ? NYPGraEb3Ennl::S3 : NYPGraEb3Ennl::LOCAL;
    }
}
