<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Illuminate\Database\Eloquent\Model;
abstract  class IeEvjRaj1LMmG extends Model implements JVAg1Gkd0EvTM
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function m8iKNbDAQI2() : bool
    {
        goto cg2dB;
        cg2dB:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto cklCx;
        }
        goto RfrKY;
        RvXSl:
        cklCx:
        goto DirKj;
        DirKj:
        return !$this->mpVvwnyqQbZ();
        goto wsx42;
        RfrKY:
        return true;
        goto RvXSl;
        wsx42:
    }
    protected function mpVvwnyqQbZ() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
