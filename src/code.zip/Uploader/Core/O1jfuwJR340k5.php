<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Contracts\LuYApSsjKQvJj;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\Traits\IdjMnkSrUQeOj;
use Jfs\Uploader\Core\Traits\LwZBr5bK6EUWt;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
class O1jfuwJR340k5 extends Lx6EggVsR2j6q implements PLPNmbBnD48xL
{
    use IdjMnkSrUQeOj;
    use LwZBr5bK6EUWt;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $f_0vQ, string $Xu3VW) : self
    {
        goto MFhSA;
        sRhh3:
        $cFlec->mdigVxgooZG(IfP50GBBbx63a::UPLOADING);
        goto zEtCu;
        MFhSA:
        $cFlec = new self(['id' => $f_0vQ, 'type' => $Xu3VW, 'status' => IfP50GBBbx63a::UPLOADING]);
        goto sRhh3;
        zEtCu:
        return $cFlec;
        goto f71UK;
        f71UK:
    }
    public function width() : ?int
    {
        goto KgKeg;
        KgKeg:
        $wtcqu = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto JhE8i;
        nbpdi:
        return null;
        goto gquy5;
        J9sIt:
        return $wtcqu;
        goto tMKTA;
        tMKTA:
        PHorc:
        goto nbpdi;
        JhE8i:
        if (!$wtcqu) {
            goto PHorc;
        }
        goto J9sIt;
        gquy5:
    }
    public function height() : ?int
    {
        goto KmMnx;
        Ta2E2:
        return null;
        goto pA3Fx;
        q0cxc:
        pDmD3:
        goto Ta2E2;
        lTtJ4:
        return $snhLP;
        goto q0cxc;
        KmMnx:
        $snhLP = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto Eht4h;
        Eht4h:
        if (!$snhLP) {
            goto pDmD3;
        }
        goto lTtJ4;
        pA3Fx:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($cFlec) {
            goto E7FiH;
            zva27:
            if (!($ZNZRt['thumbnail'] || $ZNZRt['hls_path'])) {
                goto Enmb5;
            }
            goto N13ah;
            uNe7L:
            return;
            goto IrH6s;
            rHwNu:
            Enmb5:
            goto VW3g5;
            E7FiH:
            $ZNZRt = $cFlec->getDirty();
            goto uInML;
            uInML:
            if (!(!array_key_exists('thumbnail', $ZNZRt) && !array_key_exists('hls_path', $ZNZRt))) {
                goto FnIm2;
            }
            goto uNe7L;
            N13ah:
            O1jfuwJR340k5::where('parent_id', $cFlec->getAttribute('id'))->update(['thumbnail' => $cFlec->getAttributes()['thumbnail'], 'hls_path' => $cFlec->getAttributes()['hls_path']]);
            goto rHwNu;
            IrH6s:
            FnIm2:
            goto zva27;
            VW3g5:
        });
    }
    public function m7CWtkKXz7u()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m2DCVMgUNYW()
    {
        return $this->getAttribute('id');
    }
    public function mBE1dTRMsWC() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto ZaTQw;
        VZAug:
        $JsoDj['player_url'] = $CcclM->resolvePath($this, $this->getAttribute('driver'));
        goto vMgG3;
        DZLVp:
        U2JpG:
        goto KWnuY;
        Tqczf:
        $JsoDj['thumbnail'] = $CcclM->resolveThumbnail($this);
        goto hTyJY;
        HmeTd:
        zJy0Z:
        goto Tqczf;
        hTyJY:
        return $JsoDj;
        goto OXDu1;
        KWnuY:
        $JsoDj['player_url'] = $CcclM->resolvePathForHlsVideo($this, true);
        goto HmeTd;
        POG_3:
        if ($this->getAttribute('hls_path')) {
            goto U2JpG;
        }
        goto VZAug;
        vMgG3:
        goto zJy0Z;
        goto DZLVp;
        ZaTQw:
        $CcclM = app(LuYApSsjKQvJj::class);
        goto aWddH;
        aWddH:
        $JsoDj = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $CcclM->resolvePath($this, $this->getAttribute('driver'))];
        goto POG_3;
        OXDu1:
    }
    public function getThumbnails()
    {
        goto U3hln;
        NGAuv:
        return array_map(function ($XqjZc) use($CcclM) {
            return $CcclM->resolvePath($XqjZc);
        }, $Ux14A);
        goto UOXTG;
        PECMc:
        $CcclM = app(LuYApSsjKQvJj::class);
        goto NGAuv;
        U3hln:
        $Ux14A = $this->getAttribute('generated_previews') ?? [];
        goto PECMc;
        UOXTG:
    }
    public static function mrrWmneCyG1(Lx6EggVsR2j6q $vIqmh) : O1jfuwJR340k5
    {
        goto ezO7q;
        jFuJB:
        Uri0m:
        goto s1HvO;
        bTJls:
        return $vIqmh;
        goto jFuJB;
        s1HvO:
        return (new O1jfuwJR340k5())->fill($vIqmh->getAttributes());
        goto rkspw;
        ezO7q:
        if (!$vIqmh instanceof O1jfuwJR340k5) {
            goto Uri0m;
        }
        goto bTJls;
        rkspw:
    }
}
