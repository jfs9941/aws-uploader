<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core;

use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use backup\Uploader\Enum\Aetm2HiFuJE34;
final class AxmsWfJr0hDcu
{
    public $filename;
    public $k_wlU;
    public $K2tYP;
    public $AaaaP;
    public $pc1aI;
    public $L_mVC;
    public $tjMet;
    public $status;
    public $TV1w5;
    public $ZvM_a;
    public $IykL3 = 's3';
    public $T7MaX = [];
    public function __construct($OPQIP, $dFAQm, $fk8IK, $imjT0, $ktvvF, $znDRw, $qElZ6, $Y3A6R, $tVw6M, $G56a2, $agJ1D = 's3', $QIhb6 = [])
    {
        goto cO1kt;
        i9GdW:
        $this->k_wlU = $dFAQm;
        goto NJEG5;
        cO1kt:
        $this->filename = $OPQIP;
        goto i9GdW;
        FxsNX:
        $this->AaaaP = $imjT0;
        goto Uedsa;
        k3_wF:
        $this->T7MaX = $QIhb6;
        goto Pu61W;
        Bdrbt:
        $this->status = $Y3A6R;
        goto PY7GY;
        PY7GY:
        $this->TV1w5 = $tVw6M;
        goto E4Nko;
        KzBl6:
        $this->IykL3 = $agJ1D;
        goto k3_wF;
        E4Nko:
        $this->ZvM_a = $G56a2;
        goto KzBl6;
        Uedsa:
        $this->pc1aI = $ktvvF;
        goto xvPev;
        gVNTU:
        $this->tjMet = $qElZ6;
        goto Bdrbt;
        NJEG5:
        $this->K2tYP = $fk8IK;
        goto FxsNX;
        xvPev:
        $this->L_mVC = $znDRw;
        goto gVNTU;
        Pu61W:
    }
    private static function meR7SHnDN5a() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mICXEOPqobN() : array
    {
        return array_flip(self::meR7SHnDN5a());
    }
    public function toArray() : array
    {
        $wFt7E = self::meR7SHnDN5a();
        return [$wFt7E['filename'] => $this->filename, $wFt7E['fileExtension'] => $this->k_wlU, $wFt7E['mimeType'] => $this->K2tYP, $wFt7E['fileSize'] => $this->AaaaP, $wFt7E['chunkSize'] => $this->pc1aI, $wFt7E['checksums'] => $this->L_mVC, $wFt7E['totalChunk'] => $this->tjMet, $wFt7E['status'] => $this->status, $wFt7E['userId'] => $this->TV1w5, $wFt7E['uploadId'] => $this->ZvM_a, $wFt7E['driver'] => $this->IykL3, $wFt7E['parts'] => $this->T7MaX];
    }
    public static function m7S9iMmuKkR(array $lxfCY) : self
    {
        $CF2XX = array_flip(self::mICXEOPqobN());
        return new self($lxfCY[$CF2XX['filename']] ?? $lxfCY['filename'] ?? '', $lxfCY[$CF2XX['fileExtension']] ?? $lxfCY['fileExtension'] ?? '', $lxfCY[$CF2XX['mimeType']] ?? $lxfCY['mimeType'] ?? '', $lxfCY[$CF2XX['fileSize']] ?? $lxfCY['fileSize'] ?? 0, $lxfCY[$CF2XX['chunkSize']] ?? $lxfCY['chunkSize'] ?? 0, $lxfCY[$CF2XX['checksums']] ?? $lxfCY['checksums'] ?? [], $lxfCY[$CF2XX['totalChunk']] ?? $lxfCY['totalChunk'] ?? 0, $lxfCY[$CF2XX['status']] ?? $lxfCY['status'] ?? 0, $lxfCY[$CF2XX['userId']] ?? $lxfCY['userId'] ?? 0, $lxfCY[$CF2XX['uploadId']] ?? $lxfCY['uploadId'] ?? '', $lxfCY[$CF2XX['driver']] ?? $lxfCY['driver'] ?? 's3', $lxfCY[$CF2XX['parts']] ?? $lxfCY['parts'] ?? []);
    }
    public static function mS99Egimp5G($VI3jI) : self
    {
        goto iVguh;
        RsWhr:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto LMzq2;
        xSNeG:
        SiFv3:
        goto RsWhr;
        YVyBr:
        return self::m7S9iMmuKkR($VI3jI);
        goto xSNeG;
        iVguh:
        if (!(isset($VI3jI['fn']) || isset($VI3jI['fe']))) {
            goto SiFv3;
        }
        goto YVyBr;
        LMzq2:
    }
    public function mrFQk9755s2(string $G56a2) : void
    {
        $this->ZvM_a = $G56a2;
    }
    public function mWjGOocUYVy(array $QIhb6) : void
    {
        $this->T7MaX = $QIhb6;
    }
    public static function mrfJKkeE3Fp($eVZrJ, $alBn4, $End7P, $tVw6M, $ktvvF, $znDRw, $agJ1D)
    {
        return new self($eVZrJ->getFilename(), $eVZrJ->getExtension(), $alBn4, $End7P, $ktvvF, $znDRw, count($znDRw), Aetm2HiFuJE34::UPLOADING, $tVw6M, 0, $agJ1D, []);
    }
    public static function m2gHLHqC92C($EQQae)
    {
        return 'metadata/' . $EQQae . '.json';
    }
    public function mshRaudEy4y()
    {
        return 's3' === $this->IykL3 ? XmcIS8CQn72i3::S3 : XmcIS8CQn72i3::LOCAL;
    }
}
