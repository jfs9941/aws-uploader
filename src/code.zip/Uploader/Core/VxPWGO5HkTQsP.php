<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
final class VxPWGO5HkTQsP
{
    public $filename;
    public $hQA9w;
    public $RlQMg;
    public $iGEiJ;
    public $c9RKE;
    public $sI2p5;
    public $LjfYY;
    public $status;
    public $V2xxQ;
    public $Z1W73;
    public $driver = 's3';
    public $i1Hdt = [];
    public function __construct($FzYSf, $bpe62, $UhTpD, $eFQLC, $cse1Q, $V_q0k, $BFfOR, $Iu3Uz, $hM9Ud, $fa_xj, $Mf3Ow = 's3', $Y_W7Y = [])
    {
        goto Yhpbj;
        Yhpbj:
        $this->filename = $FzYSf;
        goto p_ecH;
        j39Hz:
        $this->driver = $Mf3Ow;
        goto BGM33;
        ufZcF:
        $this->status = $Iu3Uz;
        goto mzaie;
        BGM33:
        $this->i1Hdt = $Y_W7Y;
        goto XzOD1;
        mzaie:
        $this->V2xxQ = $hM9Ud;
        goto UlcZU;
        p_ecH:
        $this->hQA9w = $bpe62;
        goto G9WN_;
        iJPl4:
        $this->iGEiJ = $eFQLC;
        goto Pd5N2;
        UlcZU:
        $this->Z1W73 = $fa_xj;
        goto j39Hz;
        Pd5N2:
        $this->c9RKE = $cse1Q;
        goto B6iLJ;
        B6iLJ:
        $this->sI2p5 = $V_q0k;
        goto dM2P1;
        dM2P1:
        $this->LjfYY = $BFfOR;
        goto ufZcF;
        G9WN_:
        $this->RlQMg = $UhTpD;
        goto iJPl4;
        XzOD1:
    }
    private static function mpy6BtnhrNQ() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mnpUYiVvdzl() : array
    {
        return array_flip(self::mpy6BtnhrNQ());
    }
    public function toArray() : array
    {
        $BCjZW = self::mpy6BtnhrNQ();
        return [$BCjZW['filename'] => $this->filename, $BCjZW['fileExtension'] => $this->hQA9w, $BCjZW['mimeType'] => $this->RlQMg, $BCjZW['fileSize'] => $this->iGEiJ, $BCjZW['chunkSize'] => $this->c9RKE, $BCjZW['checksums'] => $this->sI2p5, $BCjZW['totalChunk'] => $this->LjfYY, $BCjZW['status'] => $this->status, $BCjZW['userId'] => $this->V2xxQ, $BCjZW['uploadId'] => $this->Z1W73, $BCjZW['driver'] => $this->driver, $BCjZW['parts'] => $this->i1Hdt];
    }
    public static function mMbxEMesYK0(array $auYk0) : self
    {
        $dtfWS = array_flip(self::mnpUYiVvdzl());
        return new self($auYk0[$dtfWS['filename']] ?? $auYk0['filename'] ?? '', $auYk0[$dtfWS['fileExtension']] ?? $auYk0['fileExtension'] ?? '', $auYk0[$dtfWS['mimeType']] ?? $auYk0['mimeType'] ?? '', $auYk0[$dtfWS['fileSize']] ?? $auYk0['fileSize'] ?? 0, $auYk0[$dtfWS['chunkSize']] ?? $auYk0['chunkSize'] ?? 0, $auYk0[$dtfWS['checksums']] ?? $auYk0['checksums'] ?? [], $auYk0[$dtfWS['totalChunk']] ?? $auYk0['totalChunk'] ?? 0, $auYk0[$dtfWS['status']] ?? $auYk0['status'] ?? 0, $auYk0[$dtfWS['userId']] ?? $auYk0['userId'] ?? 0, $auYk0[$dtfWS['uploadId']] ?? $auYk0['uploadId'] ?? '', $auYk0[$dtfWS['driver']] ?? $auYk0['driver'] ?? 's3', $auYk0[$dtfWS['parts']] ?? $auYk0['parts'] ?? []);
    }
    public static function mG35AK3eSZV($Jgy8b) : self
    {
        goto Bol5A;
        Bol5A:
        if (!(isset($Jgy8b['fn']) || isset($Jgy8b['fe']))) {
            goto zcqrR;
        }
        goto K3t7x;
        Lza2H:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto LjgV3;
        K3t7x:
        return self::mMbxEMesYK0($Jgy8b);
        goto XFAU6;
        XFAU6:
        zcqrR:
        goto Lza2H;
        LjgV3:
    }
    public function ma96A33591M(string $fa_xj) : void
    {
        $this->Z1W73 = $fa_xj;
    }
    public function mAJTVIUlwdH(array $Y_W7Y) : void
    {
        $this->i1Hdt = $Y_W7Y;
    }
    public static function mcoMW5vlk23($pemjO, $cB3gt, $kKp4r, $hM9Ud, $cse1Q, $V_q0k, $Mf3Ow)
    {
        return new self($pemjO->getFilename(), $pemjO->getExtension(), $cB3gt, $kKp4r, $cse1Q, $V_q0k, count($V_q0k), IOOvAXAyKHLW2::UPLOADING, $hM9Ud, 0, $Mf3Ow, []);
    }
    public static function mcVXYpnXj59($poSkG)
    {
        return 'metadata/' . $poSkG . '.json';
    }
    public function m1e3rAwPpDG()
    {
        return 's3' === $this->driver ? L2PWLPeQEFi6U::S3 : L2PWLPeQEFi6U::LOCAL;
    }
}
