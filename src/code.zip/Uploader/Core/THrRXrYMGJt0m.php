<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Illuminate\Database\Eloquent\Model;
abstract  class THrRXrYMGJt0m extends Model implements M0ises9bx8zn4
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mwR3OfZzJwr() : bool
    {
        goto fvYGK;
        YYPye:
        return true;
        goto dORVh;
        dORVh:
        IKvq3:
        goto DqXEL;
        fvYGK:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto IKvq3;
        }
        goto YYPye;
        DqXEL:
        return !$this->m42snOUABhd();
        goto IMHj_;
        IMHj_:
    }
    protected function m42snOUABhd() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
