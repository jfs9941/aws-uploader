<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Contracts\PZ7iLyA8MUs3A;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\Traits\K8rP6m5O2PpBO;
use Jfs\Uploader\Core\Traits\TjGyNEupzj5XK;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Service\Gu99j9QqeoWGc;
class IFOKBvW1HTPmz extends F43pNWIrUhz3z implements F9PXWR72LBMoZ
{
    use K8rP6m5O2PpBO;
    use TjGyNEupzj5XK;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $lrkH0, string $aCi5W) : self
    {
        goto Pnhex;
        Pnhex:
        $THlc0 = new self(['id' => $lrkH0, 'type' => $aCi5W, 'status' => H7dtWZ2h5WAty::UPLOADING]);
        goto NiQoT;
        NiQoT:
        $THlc0->muKqrdnPhRb(H7dtWZ2h5WAty::UPLOADING);
        goto MijCR;
        MijCR:
        return $THlc0;
        goto pKo4j;
        pKo4j:
    }
    public function getView() : array
    {
        $i7mq9 = app(PZ7iLyA8MUs3A::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $i7mq9->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $i7mq9->resolveThumbnail($this)];
    }
    public static function mgjpdNh3R0A(F43pNWIrUhz3z $bPdTZ) : IFOKBvW1HTPmz
    {
        goto S9Rod;
        dN4BU:
        return (new IFOKBvW1HTPmz())->fill($bPdTZ->getAttributes());
        goto GgSuY;
        S9Rod:
        if (!$bPdTZ instanceof IFOKBvW1HTPmz) {
            goto cPGZB;
        }
        goto FPWqm;
        CxMSD:
        cPGZB:
        goto dN4BU;
        FPWqm:
        return $bPdTZ;
        goto CxMSD;
        GgSuY:
    }
}
