<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Core\Traits\NYNDlFOE1EB92;
use Jfs\Uploader\Core\Traits\ZKxVDSicUFaFP;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
class B6s4AA1exjQ2T extends QfVdOZWAlX8Sl implements QBvcnDryrzxsL
{
    use NYNDlFOE1EB92;
    use ZKxVDSicUFaFP;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $YoQzC, string $HuqsN) : self
    {
        goto exGKo;
        vorAi:
        return $cZ20c;
        goto FxtaJ;
        c_d0D:
        $cZ20c->mhnYveV1r0A(QUh2VVA2TE5xx::UPLOADING);
        goto vorAi;
        exGKo:
        $cZ20c = new self(['id' => $YoQzC, 'type' => $HuqsN, 'status' => QUh2VVA2TE5xx::UPLOADING]);
        goto c_d0D;
        FxtaJ:
    }
    public function width() : ?int
    {
        goto j__rV;
        A5qJM:
        fKzxm:
        goto mJnjj;
        Di664:
        return $yyWeX;
        goto A5qJM;
        j__rV:
        $yyWeX = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto ZBOR6;
        mJnjj:
        return null;
        goto RZTmC;
        ZBOR6:
        if (!$yyWeX) {
            goto fKzxm;
        }
        goto Di664;
        RZTmC:
    }
    public function height() : ?int
    {
        goto Q0oOW;
        Q0oOW:
        $q2cOY = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto mc1ep;
        wHKRv:
        f1Zqt:
        goto R3H1g;
        R3H1g:
        return null;
        goto LGVWG;
        I1Ydi:
        return $q2cOY;
        goto wHKRv;
        mc1ep:
        if (!$q2cOY) {
            goto f1Zqt;
        }
        goto I1Ydi;
        LGVWG:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($cZ20c) {
            goto KU1IH;
            rbUGr:
            B6s4AA1exjQ2T::where('parent_id', $cZ20c->getAttribute('id'))->update(['thumbnail' => $cZ20c->getAttributes()['thumbnail'], 'hls_path' => $cZ20c->getAttributes()['hls_path']]);
            goto mT7nG;
            U0EQW:
            return;
            goto OYLTt;
            KU1IH:
            $BuqeN = $cZ20c->getDirty();
            goto SoXBa;
            SoXBa:
            if (!(!array_key_exists('thumbnail', $BuqeN) && !array_key_exists('hls_path', $BuqeN))) {
                goto dD9q4;
            }
            goto U0EQW;
            g9yy1:
            if (!($BuqeN['thumbnail'] || $BuqeN['hls_path'])) {
                goto C2APo;
            }
            goto rbUGr;
            OYLTt:
            dD9q4:
            goto g9yy1;
            mT7nG:
            C2APo:
            goto uZEpg;
            uZEpg:
        });
    }
    public function mOIw5UiGIZm()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mhFUJRVMS3Q()
    {
        return $this->getAttribute('id');
    }
    public function mW8hDDgSYOD() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto wsXDs;
        QnXRR:
        $faVyj['player_url'] = $dyGhn->resolvePath($this, $this->getAttribute('driver'));
        goto CxVqm;
        IOvEQ:
        if ($this->getAttribute('hls_path')) {
            goto guVkj;
        }
        goto QnXRR;
        S9O3N:
        $faVyj['player_url'] = $dyGhn->resolvePathForHlsVideo($this, true);
        goto wcTcm;
        xSV1j:
        $faVyj = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $dyGhn->resolvePath($this, $this->getAttribute('driver'))];
        goto IOvEQ;
        gEKyF:
        $faVyj['thumbnail'] = $dyGhn->resolveThumbnail($this);
        goto h62B0;
        wsXDs:
        $dyGhn = app(E97atJzeJ1gs5::class);
        goto xSV1j;
        wcTcm:
        zWneS:
        goto gEKyF;
        h62B0:
        return $faVyj;
        goto rtu8k;
        CxVqm:
        goto zWneS;
        goto msuNk;
        msuNk:
        guVkj:
        goto S9O3N;
        rtu8k:
    }
    public function getThumbnails()
    {
        goto jTBdE;
        C9YGg:
        $dyGhn = app(E97atJzeJ1gs5::class);
        goto j8v_0;
        j8v_0:
        return array_map(function ($i1LOg) use($dyGhn) {
            return $dyGhn->resolvePath($i1LOg);
        }, $wK2Ib);
        goto i2Nm2;
        jTBdE:
        $wK2Ib = $this->getAttribute('generated_previews') ?? [];
        goto C9YGg;
        i2Nm2:
    }
    public static function mGVlE6RHdPz(QfVdOZWAlX8Sl $sYOYc) : B6s4AA1exjQ2T
    {
        goto X1L2a;
        uNAag:
        return (new B6s4AA1exjQ2T())->fill($sYOYc->getAttributes());
        goto XczU_;
        pujTD:
        c5RNG:
        goto uNAag;
        X1L2a:
        if (!$sYOYc instanceof B6s4AA1exjQ2T) {
            goto c5RNG;
        }
        goto WSD1h;
        WSD1h:
        return $sYOYc;
        goto pujTD;
        XczU_:
    }
}
