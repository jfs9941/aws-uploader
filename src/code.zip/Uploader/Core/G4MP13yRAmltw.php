<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Core\Traits\SMO7C4a5P3uK2;
use Jfs\Uploader\Core\Traits\D1PKXaknZAaj4;
use Jfs\Uploader\Enum\SsxWbUYXracun;
class G4MP13yRAmltw extends ZujQPL2bQTbeI implements Y0vs5qDfvPebz
{
    use SMO7C4a5P3uK2;
    use D1PKXaknZAaj4;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $o6Bjc, string $sJ7MD) : self
    {
        goto MfnKQ;
        IFJ1j:
        return $WKps1;
        goto znmR_;
        MfnKQ:
        $WKps1 = new self(['id' => $o6Bjc, 'type' => $sJ7MD, 'status' => SsxWbUYXracun::UPLOADING]);
        goto KrWU7;
        KrWU7:
        $WKps1->msLvxB5AWdO(SsxWbUYXracun::UPLOADING);
        goto IFJ1j;
        znmR_:
    }
    public function width() : ?int
    {
        goto Hr1nL;
        azMyT:
        if (!$X22ix) {
            goto kvccd;
        }
        goto Iro18;
        Hr1nL:
        $X22ix = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto azMyT;
        caI_4:
        return null;
        goto UyFmA;
        uXSGW:
        kvccd:
        goto caI_4;
        Iro18:
        return $X22ix;
        goto uXSGW;
        UyFmA:
    }
    public function height() : ?int
    {
        goto vxbNp;
        p0Tfj:
        return $LrYxj;
        goto yAw8N;
        vxbNp:
        $LrYxj = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto ZuVLJ;
        yAw8N:
        D92lG:
        goto jumkw;
        jumkw:
        return null;
        goto i_WmV;
        ZuVLJ:
        if (!$LrYxj) {
            goto D92lG;
        }
        goto p0Tfj;
        i_WmV:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($WKps1) {
            goto UEk2F;
            G6BC5:
            if (!(!array_key_exists('thumbnail', $VdPJO) && !array_key_exists('hls_path', $VdPJO))) {
                goto RG2SQ;
            }
            goto MQKDX;
            jDIrn:
            if (!($VdPJO['thumbnail'] || $VdPJO['hls_path'])) {
                goto bbRfy;
            }
            goto Wy4rd;
            jPVd4:
            bbRfy:
            goto rDaRO;
            UEk2F:
            $VdPJO = $WKps1->getDirty();
            goto G6BC5;
            MQKDX:
            return;
            goto zwDwA;
            Wy4rd:
            G4MP13yRAmltw::where('parent_id', $WKps1->getAttribute('id'))->update(['thumbnail' => $WKps1->getAttributes()['thumbnail'], 'hls_path' => $WKps1->getAttributes()['hls_path']]);
            goto jPVd4;
            zwDwA:
            RG2SQ:
            goto jDIrn;
            rDaRO:
        });
    }
    public function mrIKlngMt8o()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mYBK1lbzmtj()
    {
        return $this->getAttribute('id');
    }
    public function mevdJWCNKlG() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Tnz13;
        z57GX:
        if ($this->getAttribute('hls_path')) {
            goto DIiJ9;
        }
        goto RRGiu;
        zLtCP:
        goto OQIal;
        goto GXyun;
        RRGiu:
        $Q2Ihy['player_url'] = $VXB2z->resolvePath($this, $this->getAttribute('driver'));
        goto zLtCP;
        fx8a1:
        $Q2Ihy['thumbnail'] = $VXB2z->resolveThumbnail($this);
        goto w52Pu;
        GXyun:
        DIiJ9:
        goto UrEzb;
        Shhk9:
        OQIal:
        goto fx8a1;
        w52Pu:
        return $Q2Ihy;
        goto F56Er;
        UrEzb:
        $Q2Ihy['player_url'] = $VXB2z->resolvePathForHlsVideo($this, true);
        goto Shhk9;
        Tnz13:
        $VXB2z = app(ECHrJsgxCR7OQ::class);
        goto ieer2;
        ieer2:
        $Q2Ihy = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $VXB2z->resolvePath($this, $this->getAttribute('driver'))];
        goto z57GX;
        F56Er:
    }
    public function getThumbnails()
    {
        goto a3gff;
        v5l1E:
        $VXB2z = app(ECHrJsgxCR7OQ::class);
        goto Ligud;
        Ligud:
        return array_map(function ($DU5Lh) use($VXB2z) {
            return $VXB2z->resolvePath($DU5Lh);
        }, $ae8Fd);
        goto KbLtd;
        a3gff:
        $ae8Fd = $this->getAttribute('generated_previews') ?? [];
        goto v5l1E;
        KbLtd:
    }
    public static function mLedFBDOv04(ZujQPL2bQTbeI $Rcq7S) : G4MP13yRAmltw
    {
        goto kZuOf;
        QmFCK:
        ueVbe:
        goto ViVCs;
        ViVCs:
        return (new G4MP13yRAmltw())->fill($Rcq7S->getAttributes());
        goto quvq5;
        DUI_H:
        return $Rcq7S;
        goto QmFCK;
        kZuOf:
        if (!$Rcq7S instanceof G4MP13yRAmltw) {
            goto ueVbe;
        }
        goto DUI_H;
        quvq5:
    }
}
