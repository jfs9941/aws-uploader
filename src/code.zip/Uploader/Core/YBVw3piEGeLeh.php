<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
final class YBVw3piEGeLeh
{
    public $filename;
    public $SeCMC;
    public $YLPQO;
    public $NG2sX;
    public $mGlEw;
    public $EqDzm;
    public $b_Oyb;
    public $status;
    public $QWYBu;
    public $RBHGE;
    public $driver = 's3';
    public $FkUt2 = [];
    public function __construct($BOzo2, $oUNBD, $sfrA1, $JEIcN, $uZpmo, $WBy5d, $aCnAd, $TbZW4, $veFJs, $KCSMR, $wLwvk = 's3', $nN4jY = [])
    {
        goto dB11P;
        dB11P:
        $this->filename = $BOzo2;
        goto H5NGq;
        RRPY_:
        $this->QWYBu = $veFJs;
        goto xgGJK;
        H5NGq:
        $this->SeCMC = $oUNBD;
        goto zWncQ;
        Tajzi:
        $this->NG2sX = $JEIcN;
        goto STBue;
        xgGJK:
        $this->RBHGE = $KCSMR;
        goto u6GEF;
        V2YO5:
        $this->status = $TbZW4;
        goto RRPY_;
        STBue:
        $this->mGlEw = $uZpmo;
        goto KZ0hJ;
        u6GEF:
        $this->driver = $wLwvk;
        goto DO6sO;
        zWncQ:
        $this->YLPQO = $sfrA1;
        goto Tajzi;
        KZ0hJ:
        $this->EqDzm = $WBy5d;
        goto s_dt3;
        s_dt3:
        $this->b_Oyb = $aCnAd;
        goto V2YO5;
        DO6sO:
        $this->FkUt2 = $nN4jY;
        goto u5W6_;
        u5W6_:
    }
    private static function mjrTAosjiZs() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mZqQy0oVjO1() : array
    {
        return array_flip(self::mjrTAosjiZs());
    }
    public function toArray() : array
    {
        $Igwwe = self::mjrTAosjiZs();
        return [$Igwwe['filename'] => $this->filename, $Igwwe['fileExtension'] => $this->SeCMC, $Igwwe['mimeType'] => $this->YLPQO, $Igwwe['fileSize'] => $this->NG2sX, $Igwwe['chunkSize'] => $this->mGlEw, $Igwwe['checksums'] => $this->EqDzm, $Igwwe['totalChunk'] => $this->b_Oyb, $Igwwe['status'] => $this->status, $Igwwe['userId'] => $this->QWYBu, $Igwwe['uploadId'] => $this->RBHGE, $Igwwe['driver'] => $this->driver, $Igwwe['parts'] => $this->FkUt2];
    }
    public static function miUD4m5w7eZ(array $SThbR) : self
    {
        $vZJIj = array_flip(self::mZqQy0oVjO1());
        return new self($SThbR[$vZJIj['filename']] ?? $SThbR['filename'] ?? '', $SThbR[$vZJIj['fileExtension']] ?? $SThbR['fileExtension'] ?? '', $SThbR[$vZJIj['mimeType']] ?? $SThbR['mimeType'] ?? '', $SThbR[$vZJIj['fileSize']] ?? $SThbR['fileSize'] ?? 0, $SThbR[$vZJIj['chunkSize']] ?? $SThbR['chunkSize'] ?? 0, $SThbR[$vZJIj['checksums']] ?? $SThbR['checksums'] ?? [], $SThbR[$vZJIj['totalChunk']] ?? $SThbR['totalChunk'] ?? 0, $SThbR[$vZJIj['status']] ?? $SThbR['status'] ?? 0, $SThbR[$vZJIj['userId']] ?? $SThbR['userId'] ?? 0, $SThbR[$vZJIj['uploadId']] ?? $SThbR['uploadId'] ?? '', $SThbR[$vZJIj['driver']] ?? $SThbR['driver'] ?? 's3', $SThbR[$vZJIj['parts']] ?? $SThbR['parts'] ?? []);
    }
    public static function mQaSFCvGTKs($iJA6e) : self
    {
        goto oCXkK;
        XlR2v:
        return self::miUD4m5w7eZ($iJA6e);
        goto svMEz;
        oCXkK:
        if (!(isset($iJA6e['fn']) || isset($iJA6e['fe']))) {
            goto Pw3nZ;
        }
        goto XlR2v;
        svMEz:
        Pw3nZ:
        goto Hs9CN;
        Hs9CN:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto UoG6c;
        UoG6c:
    }
    public function m4uiiVaRFKw(string $KCSMR) : void
    {
        $this->RBHGE = $KCSMR;
    }
    public function mo1S36hnlzS(array $nN4jY) : void
    {
        $this->FkUt2 = $nN4jY;
    }
    public static function mwpKidcoiSM($D55CH, $brVsP, $vggGi, $veFJs, $uZpmo, $WBy5d, $wLwvk)
    {
        return new self($D55CH->getFilename(), $D55CH->getExtension(), $brVsP, $vggGi, $uZpmo, $WBy5d, count($WBy5d), Zgh3BZ2JVlG1A::UPLOADING, $veFJs, 0, $wLwvk, []);
    }
    public static function mZxrgDE7C9E($iG1wy)
    {
        return 'metadata/' . $iG1wy . '.json';
    }
    public function mPpnX73VLhM()
    {
        return 's3' === $this->driver ? Ef6Dy6MoUDei9::S3 : Ef6Dy6MoUDei9::LOCAL;
    }
}
