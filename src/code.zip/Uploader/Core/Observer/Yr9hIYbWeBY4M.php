<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\OrgzWokuJzoYp;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Exception\DQNrWKzuuQ4gB;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Jfs\Uploader\Presigned\PErikZGyAv1dJ;
use Jfs\Uploader\Presigned\E4Ha5YqXSNOy4;
final class Yr9hIYbWeBY4M implements OrgzWokuJzoYp
{
    private $lPejE;
    private $G_Jp3;
    private $OKvrN;
    private $y_rdZ;
    private $ZCKne;
    public function __construct($sqnmv, $GiTtn, $Cv4pg, $mJZ7g, $KNN9s = false)
    {
        goto e1wBR;
        K6LD_:
        $this->ZCKne = $mJZ7g;
        goto BGWDV;
        BGWDV:
        if ($KNN9s) {
            goto c79sW;
        }
        goto DSBko;
        bzUEz:
        c79sW:
        goto zzOFF;
        V4T41:
        $this->y_rdZ = $Cv4pg;
        goto K6LD_;
        va81V:
        $this->OKvrN = $GiTtn;
        goto V4T41;
        DSBko:
        $this->mt0K6jvQR46();
        goto bzUEz;
        e1wBR:
        $this->G_Jp3 = $sqnmv;
        goto va81V;
        zzOFF:
    }
    private function mt0K6jvQR46() : void
    {
        goto beGQ_;
        GeCQV:
        return;
        goto xbl_i;
        oHu84:
        try {
            $jJ8fr = $this->G_Jp3->mdWxraqGvMN();
            $this->lPejE = 's3' === $jJ8fr->BlJMK ? new E4Ha5YqXSNOy4($this->G_Jp3, $this->OKvrN, $this->y_rdZ, $this->ZCKne) : new PErikZGyAv1dJ($this->G_Jp3, $this->OKvrN, $this->y_rdZ);
        } catch (Wp4p9VCmIjK6G $QEfxK) {
            Log::warning("Failed to set up presigned upload: {$QEfxK->getMessage()}");
        }
        goto XE3zg;
        beGQ_:
        if (!(null !== $this->lPejE)) {
            goto rZ6EM;
        }
        goto GeCQV;
        xbl_i:
        rZ6EM:
        goto oHu84;
        XE3zg:
    }
    public function mjE8og0hkAa($upN77, $LB0Yo)
    {
        goto IZczA;
        IZczA:
        $this->mt0K6jvQR46();
        goto T7Tf2;
        yZtwz:
        V2wzX:
        goto QRhSS;
        QRhSS:
        m4Q4c:
        goto QvROd;
        T7Tf2:
        switch ($LB0Yo) {
            case N4CY6qDTBAjPa::UPLOADING:
                $this->mkc0BuaBWBO();
                goto m4Q4c;
            case N4CY6qDTBAjPa::UPLOADED:
                $this->m2O3lufK76m();
                goto m4Q4c;
            case N4CY6qDTBAjPa::ABORTED:
                $this->mEJ43YsuftZ();
                goto m4Q4c;
            default:
                goto m4Q4c;
        }
        goto yZtwz;
        QvROd:
    }
    private function m2O3lufK76m() : void
    {
        goto Jo6_X;
        WhG_5:
        $ezBDN = $this->G_Jp3->getFile();
        goto ytTF4;
        ytTF4:
        $ezBDN->mNT1f7OoTvx(N4CY6qDTBAjPa::UPLOADED);
        goto Ak37f;
        Jo6_X:
        $this->lPejE->mdiu2rEqHVo();
        goto WhG_5;
        Ak37f:
        if (!$ezBDN instanceof S25BfMDKrX8cB) {
            goto FWldD;
        }
        goto eRAoj;
        eRAoj:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($ezBDN->id);
        goto iUPrZ;
        iUPrZ:
        FWldD:
        goto jvT_X;
        jvT_X:
    }
    private function mEJ43YsuftZ() : void
    {
        $this->lPejE->mNBuHwfKe0i();
    }
    private function mkc0BuaBWBO() : void
    {
        $this->lPejE->mJ3A5JdqJu0();
    }
}
