<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\MJPdrg0mCs2vV;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Exception\JgcJVhkHS65KD;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Presigned\MBDc0ezSNOIGe;
use Jfs\Uploader\Presigned\S6fGdybdYsuki;
use Illuminate\Support\Facades\Log;
final class Zs8OhAW9qDkTw implements MJPdrg0mCs2vV
{
    private $lVxt2;
    private $F1L0c;
    private $niO3l;
    private $aplH5;
    private $S7Zrn;
    public function __construct($QJo2h, $xuow1, $C82jg, $xYZ3A, $lqyWW = false)
    {
        goto OZnd0;
        d8FIz:
        if ($lqyWW) {
            goto ufi1b;
        }
        goto O5TGN;
        tLxIQ:
        $this->niO3l = $xuow1;
        goto abG2U;
        usM9_:
        $this->S7Zrn = $xYZ3A;
        goto d8FIz;
        OZnd0:
        $this->F1L0c = $QJo2h;
        goto tLxIQ;
        abG2U:
        $this->aplH5 = $C82jg;
        goto usM9_;
        O5TGN:
        $this->m2IPdxFwSjY();
        goto ERKxK;
        ERKxK:
        ufi1b:
        goto FM3yO;
        FM3yO:
    }
    private function m2IPdxFwSjY() : void
    {
        goto svtNU;
        n_0wO:
        return;
        goto vZPGH;
        svtNU:
        if (!(null !== $this->lVxt2)) {
            goto x4Mur;
        }
        goto n_0wO;
        mp3x9:
        try {
            $ZTJaQ = $this->F1L0c->mBE2ZEQSaNO();
            $this->lVxt2 = 's3' === $ZTJaQ->G8msK ? new S6fGdybdYsuki($this->F1L0c, $this->niO3l, $this->aplH5, $this->S7Zrn) : new MBDc0ezSNOIGe($this->F1L0c, $this->niO3l, $this->aplH5);
        } catch (QBvwqKevOagSc $YIsP2) {
            Log::warning("Failed to set up presigned upload: {$YIsP2->getMessage()}");
        }
        goto WtnUU;
        vZPGH:
        x4Mur:
        goto mp3x9;
        WtnUU:
    }
    public function myLtTimHe7C($Ll7x2, $SKIcn)
    {
        goto Mct3U;
        rn8f2:
        switch ($SKIcn) {
            case LlMDscQw21XKp::UPLOADING:
                $this->mK5AoM2Gb36();
                goto fVaT9;
            case LlMDscQw21XKp::UPLOADED:
                $this->mfyPAOwLMBJ();
                goto fVaT9;
            case LlMDscQw21XKp::ABORTED:
                $this->mJb3hsbTOji();
                goto fVaT9;
            default:
                goto fVaT9;
        }
        goto D9RZR;
        Mct3U:
        $this->m2IPdxFwSjY();
        goto rn8f2;
        W5wEb:
        fVaT9:
        goto z0Vhf;
        D9RZR:
        dwND9:
        goto W5wEb;
        z0Vhf:
    }
    private function mfyPAOwLMBJ() : void
    {
        goto mRhA3;
        mRhA3:
        $this->lVxt2->mPGOyQEz4ld();
        goto oLuik;
        gVRXp:
        qw8K6:
        goto Xm6DS;
        Zn39J:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($spSJx->id);
        goto gVRXp;
        zjMgb:
        if (!$spSJx instanceof VHp3UACVYl357) {
            goto qw8K6;
        }
        goto Zn39J;
        oLuik:
        $spSJx = $this->F1L0c->getFile();
        goto edz4R;
        edz4R:
        $spSJx->mmrYWGPqYWx(LlMDscQw21XKp::UPLOADED);
        goto zjMgb;
        Xm6DS:
    }
    private function mJb3hsbTOji() : void
    {
        $this->lVxt2->mmZY5pVfPQx();
    }
    private function mK5AoM2Gb36() : void
    {
        $this->lVxt2->mR8YH6Ul9tS();
    }
}
