<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Contracts\IYQ9W9yMaFIDi;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\Strategy\Ot7RNs9Ef7hVT;
use Jfs\Uploader\Core\Strategy\DTRQSewO9aSqD;
use Jfs\Uploader\Encoder\FSb1vbQf2TVPX;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Service\KiBRYQgrRVRtv;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class ZbCruJtdtlRqO implements IYQ9W9yMaFIDi
{
    private $VF1_1;
    private $d3RM8;
    private $QxLu3;
    private $DWDC6;
    public function __construct($ZPsYd, $bjIIR, $eoTgM)
    {
        goto utQyX;
        B5u3o:
        $this->VF1_1 = $this->m1HFYakUjuK();
        goto LEMMQ;
        utQyX:
        $this->d3RM8 = $ZPsYd;
        goto lv1z2;
        lv1z2:
        $this->QxLu3 = $bjIIR;
        goto AUtOW;
        AUtOW:
        $this->DWDC6 = $eoTgM;
        goto B5u3o;
        LEMMQ:
    }
    public function mX3kB2cejfz($CvLh2, $AOQvb) : void
    {
        goto b25mw;
        lJOBM:
        VH9fe:
        goto K2n9l;
        M5G3N:
        $this->d3RM8->save();
        goto nVnfl;
        eVULy:
        if (!(TSfaBZEUMcbl0::ENCODING_PROCESSED === $AOQvb)) {
            goto zBtxT;
        }
        goto x45s2;
        K2n9l:
        zBtxT:
        goto DQy28;
        A0pj8:
        $this->VF1_1->process($AOQvb);
        goto vSjC7;
        x45s2:
        $this->d3RM8->save();
        goto rwRdd;
        b25mw:
        if (!(TSfaBZEUMcbl0::PROCESSING === $AOQvb)) {
            goto Xewun;
        }
        goto M5G3N;
        bh0yn:
        $this->VF1_1->process($AOQvb);
        goto lJOBM;
        vSjC7:
        Lp9P1:
        goto sh7gl;
        sh7gl:
        Xewun:
        goto eVULy;
        nVnfl:
        if (!$this->VF1_1) {
            goto Lp9P1;
        }
        goto A0pj8;
        rwRdd:
        if (!$this->VF1_1) {
            goto VH9fe;
        }
        goto bh0yn;
        DQy28:
    }
    private function m1HFYakUjuK()
    {
        goto MQSsn;
        MQSsn:
        switch ($this->d3RM8->getType()) {
            case 'image':
                return new Ot7RNs9Ef7hVT($this->d3RM8, $this->DWDC6);
            case 'video':
                return new DTRQSewO9aSqD($this->d3RM8, App::make(FSb1vbQf2TVPX::class));
            default:
                return null;
        }
        goto D8XCL;
        ExduV:
        DreFs:
        goto gmJ3Q;
        D8XCL:
        EF49a:
        goto ExduV;
        gmJ3Q:
    }
}
