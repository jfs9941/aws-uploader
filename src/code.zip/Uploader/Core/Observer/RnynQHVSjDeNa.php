<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\AbQOw1WF9dU8u;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Exception\VSaAUeOOPZiL5;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Presigned\R4WmQd9p4yYG2;
use Jfs\Uploader\Presigned\AKHnyZVoFAEEM;
use Illuminate\Support\Facades\Log;
final class RnynQHVSjDeNa implements AbQOw1WF9dU8u
{
    private $Z73BI;
    private $z1SIX;
    private $P8Yzg;
    private $Lrbr9;
    private $t4Y2D;
    public function __construct($XqWFu, $jT0xz, $x4E8s, $wY6MR, $S4T8E = false)
    {
        goto oqHzy;
        TloBK:
        eoA1p:
        goto eq63D;
        U0_uy:
        $this->P8Yzg = $jT0xz;
        goto eMDFp;
        oqHzy:
        $this->z1SIX = $XqWFu;
        goto U0_uy;
        jJUIW:
        $this->mjGlZXQsmuP();
        goto TloBK;
        eMDFp:
        $this->Lrbr9 = $x4E8s;
        goto tyG_E;
        tyG_E:
        $this->t4Y2D = $wY6MR;
        goto o613R;
        o613R:
        if ($S4T8E) {
            goto eoA1p;
        }
        goto jJUIW;
        eq63D:
    }
    private function mjGlZXQsmuP() : void
    {
        goto fI8L2;
        fI8L2:
        if (!(null !== $this->Z73BI)) {
            goto Wy3BV;
        }
        goto vVS0E;
        Dv3Qb:
        try {
            $SaEd8 = $this->z1SIX->mjt4KTTPlCK();
            $this->Z73BI = 's3' === $SaEd8->xiRsU ? new AKHnyZVoFAEEM($this->z1SIX, $this->P8Yzg, $this->Lrbr9, $this->t4Y2D) : new R4WmQd9p4yYG2($this->z1SIX, $this->P8Yzg, $this->Lrbr9);
        } catch (OLKFtR17budEQ $AUVE0) {
            Log::warning("Failed to set up presigned upload: {$AUVE0->getMessage()}");
        }
        goto KCY3d;
        x1QHM:
        Wy3BV:
        goto Dv3Qb;
        vVS0E:
        return;
        goto x1QHM;
        KCY3d:
    }
    public function mcSizi4ikHF($S1194, $T_gUk)
    {
        goto X8v_5;
        YFpVo:
        s7ufc:
        goto C8tgh;
        C8tgh:
        Ty0ad:
        goto RoSAN;
        ib10x:
        switch ($T_gUk) {
            case Tbw0jsMnRbOTP::UPLOADING:
                $this->mIz9MtWxahU();
                goto Ty0ad;
            case Tbw0jsMnRbOTP::UPLOADED:
                $this->mBvRXkigS3T();
                goto Ty0ad;
            case Tbw0jsMnRbOTP::ABORTED:
                $this->mqg3AiWtJjU();
                goto Ty0ad;
            default:
                goto Ty0ad;
        }
        goto YFpVo;
        X8v_5:
        $this->mjGlZXQsmuP();
        goto ib10x;
        RoSAN:
    }
    private function mBvRXkigS3T() : void
    {
        goto LeTtG;
        ooIYh:
        $RCdwx = $this->z1SIX->getFile();
        goto BzNfH;
        BzNfH:
        $RCdwx->mIiE80g96Fo(Tbw0jsMnRbOTP::UPLOADED);
        goto TzWQL;
        gGvGZ:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($RCdwx->id);
        goto H_G8r;
        H_G8r:
        ArXz9:
        goto MZKKq;
        LeTtG:
        $this->Z73BI->mrSzJ7YzPBP();
        goto ooIYh;
        TzWQL:
        if (!$RCdwx instanceof Jf5KRr8uE3t34) {
            goto ArXz9;
        }
        goto gGvGZ;
        MZKKq:
    }
    private function mqg3AiWtJjU() : void
    {
        $this->Z73BI->mAQla2YiH6K();
    }
    private function mIz9MtWxahU() : void
    {
        $this->Z73BI->mmnQHbuvJde();
    }
}
