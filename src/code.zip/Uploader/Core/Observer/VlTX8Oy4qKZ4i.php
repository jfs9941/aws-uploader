<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Contracts\ZcCh1gvC4ktYJ;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
class VlTX8Oy4qKZ4i implements ZcCh1gvC4ktYJ
{
    private $QEMhI;
    public function __construct($YEF57)
    {
        $this->QEMhI = $YEF57;
    }
    public function mauAugSr89M($WZdil, $VdQLY)
    {
        goto ZGxai;
        tJZOt:
        LF9bd:
        goto Xk4_q;
        VWApP:
        $this->QEMhI->status = ZP6Ky842t6y9Y::UPLOADED;
        goto xmyoj;
        ZGxai:
        if (!(ZP6Ky842t6y9Y::UPLOADED === $VdQLY)) {
            goto qLBm6;
        }
        goto VWApP;
        xmyoj:
        if (!$this->QEMhI instanceof UKkbXBDRxjSUY) {
            goto Wt7Ys;
        }
        goto xclOB;
        FqDOn:
        if (!(ZP6Ky842t6y9Y::DELETED === $VdQLY && $this->QEMhI->m8iKNbDAQI2())) {
            goto LF9bd;
        }
        goto YrcNj;
        nvR7q:
        Wt7Ys:
        goto iM95O;
        iM95O:
        $this->QEMhI->save();
        goto qAxvq;
        qAxvq:
        qLBm6:
        goto FqDOn;
        xclOB:
        $this->QEMhI->mddb9WvMqo9(ZP6Ky842t6y9Y::PROCESSING);
        goto nvR7q;
        YrcNj:
        $this->QEMhI->delete();
        goto tJZOt;
        Xk4_q:
    }
}
