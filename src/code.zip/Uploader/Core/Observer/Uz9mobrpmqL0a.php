<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\PLHq1RdJfseHT;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Exception\HAdknCimVLDdp;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Presigned\KL695pUGU8EfA;
use Jfs\Uploader\Presigned\SAQANzmdkhcji;
use Illuminate\Support\Facades\Log;
final class Uz9mobrpmqL0a implements PLHq1RdJfseHT
{
    private $a6eHF;
    private $BOb2P;
    private $Ybatl;
    private $sKQBJ;
    private $Fcin3;
    public function __construct($LlwTr, $FHlTP, $F1Ry9, $Bnpg8, $OqABt = false)
    {
        goto VX1n5;
        qaxEx:
        n1mNQ:
        goto DXnj9;
        i8y11:
        if ($OqABt) {
            goto n1mNQ;
        }
        goto y43LT;
        y43LT:
        $this->m4NnLx3e0HZ();
        goto qaxEx;
        VX1n5:
        $this->BOb2P = $LlwTr;
        goto DX7qn;
        DX7qn:
        $this->Ybatl = $FHlTP;
        goto zH2qz;
        TwzoN:
        $this->Fcin3 = $Bnpg8;
        goto i8y11;
        zH2qz:
        $this->sKQBJ = $F1Ry9;
        goto TwzoN;
        DXnj9:
    }
    private function m4NnLx3e0HZ() : void
    {
        goto KWUGc;
        aALZ4:
        hjjPd:
        goto RUBSg;
        RUBSg:
        try {
            $MCnj4 = $this->BOb2P->muHFWbWFrae();
            $this->a6eHF = 's3' === $MCnj4->driver ? new SAQANzmdkhcji($this->BOb2P, $this->Ybatl, $this->sKQBJ, $this->Fcin3) : new KL695pUGU8EfA($this->BOb2P, $this->Ybatl, $this->sKQBJ);
        } catch (Yhh7VdR99pXtm $j62Rn) {
            Log::warning("Failed to set up presigned upload: {$j62Rn->getMessage()}");
        }
        goto VzYt8;
        jlOQW:
        return;
        goto aALZ4;
        KWUGc:
        if (!(null !== $this->a6eHF)) {
            goto hjjPd;
        }
        goto jlOQW;
        VzYt8:
    }
    public function mQKpfhrTRkc($hVcA0, $Ha4yb)
    {
        goto zKm5M;
        y9GkF:
        yeX2v:
        goto MvmsH;
        WmZBe:
        switch ($Ha4yb) {
            case IfP50GBBbx63a::UPLOADING:
                $this->mnq92Ew3ceX();
                goto yeX2v;
            case IfP50GBBbx63a::UPLOADED:
                $this->m1VB057a95R();
                goto yeX2v;
            case IfP50GBBbx63a::ABORTED:
                $this->mqGCZ7vI7WN();
                goto yeX2v;
            default:
                goto yeX2v;
        }
        goto FyWHG;
        zKm5M:
        $this->m4NnLx3e0HZ();
        goto WmZBe;
        FyWHG:
        B6pzH:
        goto y9GkF;
        MvmsH:
    }
    private function m1VB057a95R() : void
    {
        goto yHJbO;
        FdSq3:
        f5yVj:
        goto CNnCA;
        ul2GU:
        if (!$mz56v instanceof O1jfuwJR340k5) {
            goto f5yVj;
        }
        goto ye5UY;
        lhXUB:
        $mz56v->mo8ljKgMJTJ(IfP50GBBbx63a::PROCESSING);
        goto FdSq3;
        yHJbO:
        $this->a6eHF->mJlaumzyHgb();
        goto K0dWW;
        K0dWW:
        $mz56v = $this->BOb2P->getFile();
        goto JRGHh;
        ye5UY:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($mz56v->id);
        goto lhXUB;
        JRGHh:
        $mz56v->mo8ljKgMJTJ(IfP50GBBbx63a::UPLOADED);
        goto ul2GU;
        CNnCA:
    }
    private function mqGCZ7vI7WN() : void
    {
        $this->a6eHF->mBKuVbQuVRa();
    }
    private function mnq92Ew3ceX() : void
    {
        $this->a6eHF->m9GbYa671CI();
    }
}
