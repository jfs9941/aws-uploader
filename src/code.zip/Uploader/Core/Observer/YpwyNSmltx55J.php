<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\KQPO3KR6pEPcF;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Exception\O21XtZt2mzRw1;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Presigned\UstyV4GEWgqpE;
use Jfs\Uploader\Presigned\HmDvnx8A2PSxQ;
use Illuminate\Support\Facades\Log;
final class YpwyNSmltx55J implements KQPO3KR6pEPcF
{
    private $I9UCU;
    private $f0YGu;
    private $W9e5K;
    private $cEZhz;
    private $QNBCN;
    public function __construct($oXu1C, $XCkIj, $UubHF, $APN4u, $AR5_z = false)
    {
        goto e37h6;
        iYZIv:
        $this->W9e5K = $XCkIj;
        goto K7hNz;
        e37h6:
        $this->f0YGu = $oXu1C;
        goto iYZIv;
        q_KM1:
        $this->mbcrE9WcoV5();
        goto dibdm;
        dibdm:
        TQXUl:
        goto nwjiq;
        NKbqT:
        $this->QNBCN = $APN4u;
        goto iX60O;
        K7hNz:
        $this->cEZhz = $UubHF;
        goto NKbqT;
        iX60O:
        if ($AR5_z) {
            goto TQXUl;
        }
        goto q_KM1;
        nwjiq:
    }
    private function mbcrE9WcoV5() : void
    {
        goto sP1_k;
        Ha0fC:
        Ij0cA:
        goto AHxVE;
        sP1_k:
        if (!(null !== $this->I9UCU)) {
            goto Ij0cA;
        }
        goto wn0e4;
        wn0e4:
        return;
        goto Ha0fC;
        AHxVE:
        try {
            $u_EX6 = $this->f0YGu->mlPpDqeRPNC();
            $this->I9UCU = 's3' === $u_EX6->Sc6J1 ? new HmDvnx8A2PSxQ($this->f0YGu, $this->W9e5K, $this->cEZhz, $this->QNBCN) : new UstyV4GEWgqpE($this->f0YGu, $this->W9e5K, $this->cEZhz);
        } catch (PgT1yqHzwrHid $oKDQw) {
            Log::warning("Failed to set up presigned upload: {$oKDQw->getMessage()}");
        }
        goto jC1Cq;
        jC1Cq:
    }
    public function m6Fp3pM8yAa($Qc9id, $ZPmF2)
    {
        goto NPSBS;
        sm2IL:
        switch ($ZPmF2) {
            case A9q1Lm9l5QixG::UPLOADING:
                $this->mJ5yj8eRNB5();
                goto vcxHR;
            case A9q1Lm9l5QixG::UPLOADED:
                $this->mnG1G4cIZzp();
                goto vcxHR;
            case A9q1Lm9l5QixG::ABORTED:
                $this->miO4cu6z0v2();
                goto vcxHR;
            default:
                goto vcxHR;
        }
        goto WukTV;
        WukTV:
        Upe4K:
        goto nVGcp;
        NPSBS:
        $this->mbcrE9WcoV5();
        goto sm2IL;
        nVGcp:
        vcxHR:
        goto AktzV;
        AktzV:
    }
    private function mnG1G4cIZzp() : void
    {
        goto B5Kx3;
        DOmd1:
        if (!$k2MU3 instanceof VPegVN4NByLqJ) {
            goto DHzoe;
        }
        goto QuxF7;
        B5Kx3:
        $this->I9UCU->maTvNKYiGsC();
        goto j5RKH;
        RlkQ_:
        $k2MU3->ms4OoFrTljH(A9q1Lm9l5QixG::UPLOADED);
        goto DOmd1;
        j5RKH:
        $k2MU3 = $this->f0YGu->getFile();
        goto RlkQ_;
        YOlAf:
        DHzoe:
        goto RYfuM;
        QuxF7:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($k2MU3->id);
        goto YOlAf;
        RYfuM:
    }
    private function miO4cu6z0v2() : void
    {
        $this->I9UCU->mSWgr2hpZl5();
    }
    private function mJ5yj8eRNB5() : void
    {
        $this->I9UCU->mxPosq9wO3K();
    }
}
