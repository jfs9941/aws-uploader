<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\K6rnLmlRKxy9W;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Exception\Z1EmnB00QcmrE;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Jfs\Uploader\Presigned\Et4UpDz6GlLc6;
use Jfs\Uploader\Presigned\WdzeVRaluz7By;
final class Bdt9eWxXcjNOA implements K6rnLmlRKxy9W
{
    private $P6e_j;
    private $WdyLh;
    private $bX3fI;
    private $UAt4g;
    private $rczpf;
    public function __construct($ld3oH, $Q0hWX, $RdfoB, $qir1P, $d4GnK = false)
    {
        goto Z4wNH;
        FKVKC:
        $this->rczpf = $qir1P;
        goto vI2Pi;
        jA8Iv:
        $this->UAt4g = $RdfoB;
        goto FKVKC;
        Serwh:
        $this->bX3fI = $Q0hWX;
        goto jA8Iv;
        Z4wNH:
        $this->WdyLh = $ld3oH;
        goto Serwh;
        hokBy:
        TdZy4:
        goto i8lMu;
        Z6ZCC:
        $this->m9tRznhMGdd();
        goto hokBy;
        vI2Pi:
        if ($d4GnK) {
            goto TdZy4;
        }
        goto Z6ZCC;
        i8lMu:
    }
    private function m9tRznhMGdd() : void
    {
        goto Ri3P3;
        Ri3P3:
        if (!(null !== $this->P6e_j)) {
            goto Ehjwn;
        }
        goto p6sx1;
        Enq7k:
        try {
            $szNd7 = $this->WdyLh->mkBf6Gw5jFn();
            $this->P6e_j = 's3' === $szNd7->bdBtT ? new WdzeVRaluz7By($this->WdyLh, $this->bX3fI, $this->UAt4g, $this->rczpf) : new Et4UpDz6GlLc6($this->WdyLh, $this->bX3fI, $this->UAt4g);
        } catch (DbtXptYiNGheI $djmN_) {
            Log::warning("Failed to set up presigned upload: {$djmN_->getMessage()}");
        }
        goto rhgbp;
        RLbEx:
        Ehjwn:
        goto Enq7k;
        p6sx1:
        return;
        goto RLbEx;
        rhgbp:
    }
    public function mYTLHr2vX9t($WVkJm, $CQyva)
    {
        goto kI4Ol;
        D5JdA:
        wDRO8:
        goto y9XgV;
        kI4Ol:
        $this->m9tRznhMGdd();
        goto sVFGl;
        sVFGl:
        switch ($CQyva) {
            case QoCMzcKvH8Cw2::UPLOADING:
                $this->mI4FBAL1iM1();
                goto mDc0y;
            case QoCMzcKvH8Cw2::UPLOADED:
                $this->mEfp6gJYn5k();
                goto mDc0y;
            case QoCMzcKvH8Cw2::ABORTED:
                $this->mm75U6IR3rk();
                goto mDc0y;
            default:
                goto mDc0y;
        }
        goto D5JdA;
        y9XgV:
        mDc0y:
        goto yGR0M;
        yGR0M:
    }
    private function mEfp6gJYn5k() : void
    {
        goto T4uHN;
        d3Mvp:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($QuYzZ->id);
        goto Q2Qe9;
        fmvuk:
        $QuYzZ = $this->WdyLh->getFile();
        goto BCEaO;
        nrBYx:
        if (!$QuYzZ instanceof ACdpgX4YCYP6M) {
            goto pY7DK;
        }
        goto d3Mvp;
        BCEaO:
        $QuYzZ->mVwoe0E3Z3I(QoCMzcKvH8Cw2::UPLOADED);
        goto nrBYx;
        Q2Qe9:
        pY7DK:
        goto b89Um;
        T4uHN:
        $this->P6e_j->mrCHpJ7Uki3();
        goto fmvuk;
        b89Um:
    }
    private function mm75U6IR3rk() : void
    {
        $this->P6e_j->mvhetYh8Svj();
    }
    private function mI4FBAL1iM1() : void
    {
        $this->P6e_j->mFKsPsWJiLu();
    }
}
