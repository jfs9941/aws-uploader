<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Contracts\KQPO3KR6pEPcF;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
class SY8gU52rT5c5k implements KQPO3KR6pEPcF
{
    private $VCrIB;
    public function __construct($k2MU3)
    {
        $this->VCrIB = $k2MU3;
    }
    public function m6Fp3pM8yAa($Qc9id, $ZPmF2)
    {
        goto WPwSc;
        Sn2ai:
        $this->VCrIB->save();
        goto NGCVY;
        NGCVY:
        UmuQ_:
        goto fVHeo;
        jQwvZ:
        O3X29:
        goto ES9ef;
        T_Q5m:
        if (!$this->VCrIB instanceof JMa7GBaLcnq3D) {
            goto RPec7;
        }
        goto mq8A2;
        fVHeo:
        if (!(A9q1Lm9l5QixG::DELETED === $ZPmF2 && $this->VCrIB->mKdPXbmWyxW())) {
            goto O3X29;
        }
        goto v5FXl;
        mSana:
        $this->VCrIB->status = A9q1Lm9l5QixG::UPLOADED;
        goto T_Q5m;
        mq8A2:
        $this->VCrIB->ms4OoFrTljH(A9q1Lm9l5QixG::PROCESSING);
        goto nSQBj;
        WPwSc:
        if (!(A9q1Lm9l5QixG::UPLOADED === $ZPmF2)) {
            goto UmuQ_;
        }
        goto mSana;
        nSQBj:
        RPec7:
        goto Sn2ai;
        v5FXl:
        $this->VCrIB->delete();
        goto jQwvZ;
        ES9ef:
    }
}
