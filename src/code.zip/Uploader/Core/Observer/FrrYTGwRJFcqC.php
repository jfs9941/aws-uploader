<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Contracts\DiGhNuHXqO8Po;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
class FrrYTGwRJFcqC implements DiGhNuHXqO8Po
{
    private $a2FAI;
    public function __construct($QxvEM)
    {
        $this->a2FAI = $QxvEM;
    }
    public function mA5gQsszPSr($IdyK1, $GYSAw)
    {
        goto yENJf;
        Km8uk:
        $this->a2FAI->delete();
        goto FiFhJ;
        FiFhJ:
        Z95wq:
        goto BS8gU;
        T3UV9:
        OMZ08:
        goto woyAY;
        ccj2X:
        if (!(U8OFutptQGm3S::DELETED === $GYSAw && $this->a2FAI->mMwN9dtRMhA())) {
            goto Z95wq;
        }
        goto Km8uk;
        yENJf:
        if (!(U8OFutptQGm3S::UPLOADED === $GYSAw)) {
            goto Gmozh;
        }
        goto lET0R;
        MOpGS:
        Gmozh:
        goto ccj2X;
        lET0R:
        $this->a2FAI->status = U8OFutptQGm3S::UPLOADED;
        goto GhG3Q;
        MgTQk:
        $this->a2FAI->mZunb8ueiKo(U8OFutptQGm3S::PROCESSING);
        goto T3UV9;
        woyAY:
        $this->a2FAI->save();
        goto MOpGS;
        GhG3Q:
        if (!$this->a2FAI instanceof HSe6BNUpJTSwE) {
            goto OMZ08;
        }
        goto MgTQk;
        BS8gU:
    }
}
