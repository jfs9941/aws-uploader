<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Contracts\Fg5ZctnJZvYzy;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Core\Strategy\YyFP4ij2U7zE8;
use Jfs\Uploader\Core\Strategy\IzgXxA0PRNCjV;
use Jfs\Uploader\Encoder\QuF8Qm4j71NF7;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Service\JCjpIXXHThkPb;
final class RCEd2a5p9PuRm implements Fg5ZctnJZvYzy
{
    private $nb1We;
    private $uXtKk;
    private $IRlXr;
    private $OlWdX;
    public function __construct($xdi9a, $JGvdR, $GwkoE)
    {
        goto jTppd;
        c3fru:
        $this->nb1We = $this->mfKnY6BhXNa();
        goto nD0iU;
        jTppd:
        $this->uXtKk = $xdi9a;
        goto cYbSD;
        CUOSb:
        $this->OlWdX = $GwkoE;
        goto c3fru;
        cYbSD:
        $this->IRlXr = $JGvdR;
        goto CUOSb;
        nD0iU:
    }
    public function mWjTC6Gp86v($sADJF, $mhWhW) : void
    {
        goto HpWBh;
        HwhND:
        if (!$this->nb1We) {
            goto xE3nR;
        }
        goto lEka1;
        lEka1:
        $this->nb1We->process($mhWhW);
        goto Uy2Po;
        d_nBq:
        Q8FHe:
        goto FdmN0;
        IMFHR:
        $this->uXtKk->save();
        goto HwhND;
        ydRb0:
        if (!(QUh2VVA2TE5xx::ENCODING_PROCESSED === $mhWhW)) {
            goto JDZ8S;
        }
        goto nimy9;
        JE3cq:
        if (!$this->nb1We) {
            goto Q8FHe;
        }
        goto pYOQs;
        HpWBh:
        if (!(QUh2VVA2TE5xx::PROCESSING === $mhWhW)) {
            goto Vz45i;
        }
        goto IMFHR;
        nimy9:
        $this->uXtKk->save();
        goto JE3cq;
        vAmf6:
        Vz45i:
        goto ydRb0;
        Uy2Po:
        xE3nR:
        goto vAmf6;
        pYOQs:
        $this->nb1We->process($mhWhW);
        goto d_nBq;
        FdmN0:
        JDZ8S:
        goto JtcN0;
        JtcN0:
    }
    private function mfKnY6BhXNa()
    {
        goto iI6Oi;
        ZtsG5:
        m1k2O:
        goto ugCTq;
        iI6Oi:
        switch ($this->uXtKk->getType()) {
            case 'image':
                return new YyFP4ij2U7zE8($this->uXtKk, $this->OlWdX);
            case 'video':
                return new IzgXxA0PRNCjV($this->uXtKk, App::make(QuF8Qm4j71NF7::class));
            default:
                return null;
        }
        goto bepJi;
        bepJi:
        cobzZ:
        goto ZtsG5;
        ugCTq:
    }
}
