<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\Ey23NHBM8rqSI;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Exception\B2PcuiERDfNqQ;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Jfs\Uploader\Presigned\Bul6otRYhfNMk;
use Jfs\Uploader\Presigned\J5MLwIpLcVJZy;
final class Oy9IrA1ruFcnF implements Ey23NHBM8rqSI
{
    private $qFPVt;
    private $xUsoB;
    private $kduDw;
    private $w2y98;
    private $Jc4z2;
    public function __construct($B107M, $h5ffz, $uANLN, $rhVEO, $LWwYP = false)
    {
        goto OHoHX;
        IkT_v:
        $this->w2y98 = $uANLN;
        goto ZVI7M;
        WLs9i:
        if ($LWwYP) {
            goto FTvpI;
        }
        goto HKt1F;
        OHoHX:
        $this->xUsoB = $B107M;
        goto GEd41;
        GEd41:
        $this->kduDw = $h5ffz;
        goto IkT_v;
        ZVI7M:
        $this->Jc4z2 = $rhVEO;
        goto WLs9i;
        HKt1F:
        $this->mS6KN4iPTs8();
        goto XPBbK;
        XPBbK:
        FTvpI:
        goto PNtmy;
        PNtmy:
    }
    private function mS6KN4iPTs8() : void
    {
        goto LLGrG;
        kyKF9:
        try {
            $kvLls = $this->xUsoB->mew8rrjhK4U();
            $this->qFPVt = 's3' === $kvLls->rs3Zr ? new J5MLwIpLcVJZy($this->xUsoB, $this->kduDw, $this->w2y98, $this->Jc4z2) : new Bul6otRYhfNMk($this->xUsoB, $this->kduDw, $this->w2y98);
        } catch (OK51HRfKr7bLh $Z8tVK) {
            Log::warning("Failed to set up presigned upload: {$Z8tVK->getMessage()}");
        }
        goto CGxgY;
        LMXu9:
        kdfKF:
        goto kyKF9;
        LLGrG:
        if (!(null !== $this->qFPVt)) {
            goto kdfKF;
        }
        goto Qwe13;
        Qwe13:
        return;
        goto LMXu9;
        CGxgY:
    }
    public function myNnxL9T85B($TAUXh, $hgqT8)
    {
        goto zJ0Rw;
        a93Q1:
        R1ZHp:
        goto TsjI3;
        tPD4X:
        switch ($hgqT8) {
            case O8RzIjGmSN6fG::UPLOADING:
                $this->mk3mawUTsRL();
                goto R1ZHp;
            case O8RzIjGmSN6fG::UPLOADED:
                $this->mZoZ5jhSyMs();
                goto R1ZHp;
            case O8RzIjGmSN6fG::ABORTED:
                $this->mzloodMio98();
                goto R1ZHp;
            default:
                goto R1ZHp;
        }
        goto Gm1J0;
        Gm1J0:
        kO1u5:
        goto a93Q1;
        zJ0Rw:
        $this->mS6KN4iPTs8();
        goto tPD4X;
        TsjI3:
    }
    private function mZoZ5jhSyMs() : void
    {
        goto o2ECe;
        MOZtG:
        $nKKn0->mSAdKjgXIhj(O8RzIjGmSN6fG::UPLOADED);
        goto XoHY_;
        o2ECe:
        $this->qFPVt->m5hKOwPI9JJ();
        goto dZbCp;
        XoHY_:
        if (!$nKKn0 instanceof CSQMvXC33KbbS) {
            goto cQn1x;
        }
        goto xD52l;
        xD52l:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($nKKn0->id);
        goto Ap1Lo;
        Ap1Lo:
        cQn1x:
        goto vdBCH;
        dZbCp:
        $nKKn0 = $this->xUsoB->getFile();
        goto MOZtG;
        vdBCH:
    }
    private function mzloodMio98() : void
    {
        $this->qFPVt->mFoW1sWSEnz();
    }
    private function mk3mawUTsRL() : void
    {
        $this->qFPVt->m0nMpBVxEy8();
    }
}
