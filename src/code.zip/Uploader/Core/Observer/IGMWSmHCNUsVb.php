<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Contracts\ZcCh1gvC4ktYJ;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\Strategy\Su1jU2ELQflwO;
use Jfs\Uploader\Core\Strategy\F6MD4bOgk5lTK;
use Jfs\Uploader\Encoder\VBDy3Gb7TKD1d;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Service\BJWEJOjkkZaRL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class IGMWSmHCNUsVb implements ZcCh1gvC4ktYJ
{
    private $YQmYC;
    private $QEMhI;
    private $UoQI7;
    private $roKTC;
    public function __construct($YEF57, $UjVft, $K4w3R)
    {
        goto LvxUW;
        FDceQ:
        $this->YQmYC = $this->mquNYOKdbyY();
        goto v2ES1;
        UqSKR:
        $this->UoQI7 = $UjVft;
        goto S1897;
        S1897:
        $this->roKTC = $K4w3R;
        goto FDceQ;
        LvxUW:
        $this->QEMhI = $YEF57;
        goto UqSKR;
        v2ES1:
    }
    public function mauAugSr89M($WZdil, $VdQLY) : void
    {
        goto waMBO;
        DfwIw:
        vQo33:
        goto rSBFn;
        gDOAx:
        if (!(ZP6Ky842t6y9Y::ENCODING_PROCESSED === $VdQLY)) {
            goto cLsx4;
        }
        goto V4UTa;
        T8miU:
        if (!$this->YQmYC) {
            goto d833C;
        }
        goto FfgRT;
        KguVR:
        d833C:
        goto Dhv5U;
        rSBFn:
        cLsx4:
        goto O2CDK;
        QGe1K:
        if (!$this->YQmYC) {
            goto vQo33;
        }
        goto FL4E0;
        waMBO:
        if (!(ZP6Ky842t6y9Y::PROCESSING === $VdQLY)) {
            goto Ytjac;
        }
        goto ssnZS;
        FL4E0:
        $this->YQmYC->process($VdQLY);
        goto DfwIw;
        V4UTa:
        $this->QEMhI->save();
        goto QGe1K;
        ssnZS:
        $this->QEMhI->save();
        goto T8miU;
        Dhv5U:
        Ytjac:
        goto gDOAx;
        FfgRT:
        $this->YQmYC->process($VdQLY);
        goto KguVR;
        O2CDK:
    }
    private function mquNYOKdbyY()
    {
        goto TT0Cd;
        TT0Cd:
        switch ($this->QEMhI->getType()) {
            case 'image':
                return new Su1jU2ELQflwO($this->QEMhI, $this->roKTC);
            case 'video':
                return new F6MD4bOgk5lTK($this->QEMhI, App::make(VBDy3Gb7TKD1d::class));
            default:
                return null;
        }
        goto aYV1A;
        aYV1A:
        cSpQV:
        goto QmnjW;
        QmnjW:
        tobiA:
        goto B4BDn;
        B4BDn:
    }
}
