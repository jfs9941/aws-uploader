<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Observer;

use Illuminate\Support\Facades\Log;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use src\Uploader\Contracts\F5Xo0te9A5R68;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Exception\BUbHQrtyLH6v0;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Presigned\BfcFVxdnpoWiD;
use src\Uploader\Presigned\FKw6Tf1KE1WQd;
final class Gtj9UGCCs3DRi implements F5Xo0te9A5R68
{
    private $WLVYD;
    private $RkCAT;
    private $SiK3b;
    private $TDmz_;
    private $tVqMs;
    public function __construct($kmQTT, $eX8wo, $RustJ, $FQWsT, $hk59R = false)
    {
        goto HA8iu;
        zFkoF:
        $this->TDmz_ = $RustJ;
        goto Uojwg;
        ZbUrB:
        ykcO6:
        goto Dt25M;
        IQ6Dy:
        $this->SiK3b = $eX8wo;
        goto zFkoF;
        HA8iu:
        $this->RkCAT = $kmQTT;
        goto IQ6Dy;
        ruYH_:
        $this->m3L0bZG4RH3();
        goto ZbUrB;
        Uojwg:
        $this->tVqMs = $FQWsT;
        goto OUX8G;
        OUX8G:
        if ($hk59R) {
            goto ykcO6;
        }
        goto ruYH_;
        Dt25M:
    }
    private function m3L0bZG4RH3() : void
    {
        goto HeFeQ;
        VxK3B:
        return;
        goto By6SS;
        HeFeQ:
        if (!(null !== $this->WLVYD)) {
            goto fB_qL;
        }
        goto VxK3B;
        XH2t0:
        try {
            $rEWu2 = $this->RkCAT->mH4ZGE0jflN();
            $this->WLVYD = 's3' === $rEWu2->WJjcF ? new FKw6Tf1KE1WQd($this->RkCAT, $this->SiK3b, $this->TDmz_, $this->tVqMs) : new BfcFVxdnpoWiD($this->RkCAT, $this->SiK3b, $this->TDmz_);
        } catch (LFqKVWobEBTVI $lrm5K) {
            Log::warning("Failed to set up presigned upload: {$lrm5K->getMessage()}");
        }
        goto Bp9HZ;
        By6SS:
        fB_qL:
        goto XH2t0;
        Bp9HZ:
    }
    public function myVaRYzH5cA($oCcYR, $nz0Xr)
    {
        goto YvV2p;
        bKR00:
        ku3s6:
        goto M1Dzu;
        F0QZZ:
        switch ($nz0Xr) {
            case FileStatus::UPLOADING:
                $this->mGKct7LNpCy();
                goto YnGTW;
            case FileStatus::UPLOADED:
                $this->mmitWHTCLsY();
                goto YnGTW;
            case FileStatus::ABORTED:
                $this->mweJhiRFPwA();
                goto YnGTW;
            default:
                goto YnGTW;
        }
        goto bKR00;
        M1Dzu:
        YnGTW:
        goto SOpG_;
        YvV2p:
        $this->m3L0bZG4RH3();
        goto F0QZZ;
        SOpG_:
    }
    private function mmitWHTCLsY() : void
    {
        goto NfKhc;
        f_Va0:
        $d1aiC->mIjUnedc3Mq(FileStatus::UPLOADED);
        goto u7dw3;
        o2zoF:
        $d1aiC = $this->RkCAT->getFile();
        goto f_Va0;
        NfKhc:
        $this->WLVYD->ml4R7rGsjxd();
        goto o2zoF;
        a5jbM:
        zTo6S:
        goto SINUo;
        RN3T3:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($d1aiC->id);
        goto a5jbM;
        u7dw3:
        if (!$d1aiC instanceof YdClVYDRbSDMR) {
            goto zTo6S;
        }
        goto RN3T3;
        SINUo:
    }
    private function mweJhiRFPwA() : void
    {
        $this->WLVYD->mI5hbVUBG4S();
    }
    private function mGKct7LNpCy() : void
    {
        $this->WLVYD->mGzsNnTbqgx();
    }
}
