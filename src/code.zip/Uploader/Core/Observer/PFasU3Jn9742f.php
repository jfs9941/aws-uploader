<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Contracts\F66VaMRGSfxoM;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
class PFasU3Jn9742f implements F66VaMRGSfxoM
{
    private $oWuCn;
    public function __construct($I2SbP)
    {
        $this->oWuCn = $I2SbP;
    }
    public function mSg4ZNxGqnf($ESYUX, $X7DL1)
    {
        goto gUFeP;
        ypy0q:
        UkW5t:
        goto i5Gyg;
        Rg8p6:
        $this->oWuCn->status = EPmxqTVp5luXc::UPLOADED;
        goto ikIPU;
        Cx8A7:
        $this->oWuCn->delete();
        goto jHBgG;
        jHBgG:
        lS0Jj:
        goto jf8nB;
        zYJZN:
        $this->oWuCn->save();
        goto ypy0q;
        gUFeP:
        if (!(EPmxqTVp5luXc::UPLOADED === $X7DL1)) {
            goto UkW5t;
        }
        goto Rg8p6;
        ikIPU:
        if (!$this->oWuCn instanceof XbYF8aa0XyGnI) {
            goto B4Tya;
        }
        goto ZnrKa;
        ogBUx:
        B4Tya:
        goto zYJZN;
        ZnrKa:
        $this->oWuCn->mY8gUThQFjU(EPmxqTVp5luXc::PROCESSING);
        goto ogBUx;
        i5Gyg:
        if (!(EPmxqTVp5luXc::DELETED === $X7DL1 && $this->oWuCn->mTZGo8BvmYV())) {
            goto lS0Jj;
        }
        goto Cx8A7;
        jf8nB:
    }
}
