<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\PdBd5D8IKDopT;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Exception\BI7zT0hnXVI9h;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Jfs\Uploader\Presigned\SWac5mmkw2wAI;
use Jfs\Uploader\Presigned\EfcdLi3CoUQPy;
final class YLB6KnUD0kERR implements PdBd5D8IKDopT
{
    private $OBfD8;
    private $SjKWI;
    private $Lrwlv;
    private $OjeW5;
    private $EBMt5;
    public function __construct($Ry7nX, $AhP23, $A6wTz, $E6K8y, $B31p7 = false)
    {
        goto IPolv;
        x5n2Q:
        if ($B31p7) {
            goto MuMnY;
        }
        goto LhD6d;
        iPNj4:
        $this->OjeW5 = $A6wTz;
        goto wTzzB;
        wTzzB:
        $this->EBMt5 = $E6K8y;
        goto x5n2Q;
        IPolv:
        $this->SjKWI = $Ry7nX;
        goto AT0pR;
        LhD6d:
        $this->mUuSJv2GaDX();
        goto AT2ve;
        AT2ve:
        MuMnY:
        goto iS_D4;
        AT0pR:
        $this->Lrwlv = $AhP23;
        goto iPNj4;
        iS_D4:
    }
    private function mUuSJv2GaDX() : void
    {
        goto BqqHL;
        yF7C5:
        return;
        goto f1sPk;
        Doany:
        try {
            $uJKYp = $this->SjKWI->mROzB90pF6O();
            $this->OBfD8 = 's3' === $uJKYp->pM1q4 ? new EfcdLi3CoUQPy($this->SjKWI, $this->Lrwlv, $this->OjeW5, $this->EBMt5) : new SWac5mmkw2wAI($this->SjKWI, $this->Lrwlv, $this->OjeW5);
        } catch (TvagaDpTwJZ4h $tPAjT) {
            Log::warning("Failed to set up presigned upload: {$tPAjT->getMessage()}");
        }
        goto IeG3d;
        f1sPk:
        pzXRf:
        goto Doany;
        BqqHL:
        if (!(null !== $this->OBfD8)) {
            goto pzXRf;
        }
        goto yF7C5;
        IeG3d:
    }
    public function mht82bQ4KnY($iydej, $GbrlI)
    {
        goto AayuJ;
        xAvWc:
        switch ($GbrlI) {
            case SwAwanZG36Yx6::UPLOADING:
                $this->mN4UX95anm3();
                goto y8oh2;
            case SwAwanZG36Yx6::UPLOADED:
                $this->mx09xElDlnN();
                goto y8oh2;
            case SwAwanZG36Yx6::ABORTED:
                $this->mwXPX0QTUCb();
                goto y8oh2;
            default:
                goto y8oh2;
        }
        goto lfAvJ;
        AayuJ:
        $this->mUuSJv2GaDX();
        goto xAvWc;
        lfAvJ:
        I8Zc6:
        goto k39yp;
        k39yp:
        y8oh2:
        goto pjYqY;
        pjYqY:
    }
    private function mx09xElDlnN() : void
    {
        goto PMPu2;
        PMPu2:
        $this->OBfD8->m8foZzm8MDN();
        goto MS1Hc;
        MS1Hc:
        $rQ18B = $this->SjKWI->getFile();
        goto eTBsP;
        tLS1O:
        if (!$rQ18B instanceof ZSB2cdrwtZpmk) {
            goto ewiI0;
        }
        goto wMxgn;
        eTBsP:
        $rQ18B->mZecThKyfk1(SwAwanZG36Yx6::UPLOADED);
        goto tLS1O;
        mV8Kk:
        ewiI0:
        goto kp0OW;
        wMxgn:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($rQ18B->id);
        goto mV8Kk;
        kp0OW:
    }
    private function mwXPX0QTUCb() : void
    {
        $this->OBfD8->mqX3etBSfdy();
    }
    private function mN4UX95anm3() : void
    {
        $this->OBfD8->mlbPU0TakFO();
    }
}
