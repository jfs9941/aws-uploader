<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Contracts\A1DrGQVhPKB54;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\Strategy\EVSQonQJ4d3pL;
use Jfs\Uploader\Core\Strategy\AOT9bVnwczyet;
use Jfs\Uploader\Encoder\TMo64GtkgTgVY;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Service\HHzuA41ccyXtA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class XpPxaggO8iQsi implements A1DrGQVhPKB54
{
    private $kfObH;
    private $EidfR;
    private $tcoQz;
    private $fM0Z0;
    public function __construct($clm2Y, $v70jj, $fxDHl)
    {
        goto P3Qrv;
        wbQA1:
        $this->fM0Z0 = $fxDHl;
        goto RF0UO;
        P3Qrv:
        $this->EidfR = $clm2Y;
        goto Ux4z2;
        RF0UO:
        $this->kfObH = $this->mPYN6A4EpZ9();
        goto nwfUk;
        Ux4z2:
        $this->tcoQz = $v70jj;
        goto wbQA1;
        nwfUk:
    }
    public function mhxhZPnjNPV($zS2qB, $jAyD6) : void
    {
        goto vfQMm;
        o3S5e:
        if (!$this->kfObH) {
            goto WB_ea;
        }
        goto BNALX;
        jrNFu:
        WB_ea:
        goto IM3Gy;
        njs5l:
        if (!(KidkTsWIjmNMb::ENCODING_PROCESSED === $jAyD6)) {
            goto OIlvV;
        }
        goto e8nDN;
        IM3Gy:
        OIlvV:
        goto dHStJ;
        e8nDN:
        $this->EidfR->save();
        goto o3S5e;
        NofD1:
        TmDau:
        goto njs5l;
        BNALX:
        $this->kfObH->process($jAyD6);
        goto jrNFu;
        vfQMm:
        if (!(KidkTsWIjmNMb::PROCESSING === $jAyD6)) {
            goto TmDau;
        }
        goto UxyoG;
        UxyoG:
        $this->EidfR->save();
        goto ujwT7;
        ujwT7:
        if (!$this->kfObH) {
            goto kZ9b_;
        }
        goto JBiMj;
        JBiMj:
        $this->kfObH->process($jAyD6);
        goto wZe3H;
        wZe3H:
        kZ9b_:
        goto NofD1;
        dHStJ:
    }
    private function mPYN6A4EpZ9()
    {
        goto ZSYQx;
        vuUEn:
        S1Fsx:
        goto nq5iB;
        RKel4:
        VHfgu:
        goto vuUEn;
        ZSYQx:
        switch ($this->EidfR->getType()) {
            case 'image':
                return new EVSQonQJ4d3pL($this->EidfR, $this->fM0Z0);
            case 'video':
                return new AOT9bVnwczyet($this->EidfR, App::make(TMo64GtkgTgVY::class));
            default:
                return null;
        }
        goto RKel4;
        nq5iB:
    }
}
