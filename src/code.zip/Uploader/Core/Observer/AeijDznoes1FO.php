<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Contracts\JL46r4tF2ZJbX;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\Strategy\VFeE64RRDXinB;
use Jfs\Uploader\Core\Strategy\Oc4Fatu2lTNfj;
use Jfs\Uploader\Encoder\ASuKOsLEZrEeb;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Service\XmR9LXciUFjyf;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class AeijDznoes1FO implements JL46r4tF2ZJbX
{
    private $YbvQu;
    private $SnpXu;
    private $hFxUe;
    private $yYDr_;
    public function __construct($z620p, $KKbEP, $N33e6)
    {
        goto O0Mn4;
        BiHFo:
        $this->hFxUe = $KKbEP;
        goto UfY3O;
        M_Faq:
        $this->YbvQu = $this->mmTOxTIAqGq();
        goto qd139;
        O0Mn4:
        $this->SnpXu = $z620p;
        goto BiHFo;
        UfY3O:
        $this->yYDr_ = $N33e6;
        goto M_Faq;
        qd139:
    }
    public function mueWblWOUUZ($JPLgA, $wLbz9) : void
    {
        goto WXj2V;
        hfA12:
        vOe38:
        goto yijAu;
        yijAu:
        if (!(QE1dzvgcPWV6R::ENCODING_PROCESSED === $wLbz9)) {
            goto Ck6A9;
        }
        goto IAuwF;
        a32Q3:
        if (!$this->YbvQu) {
            goto x46Hs;
        }
        goto BMQOY;
        WXj2V:
        if (!(QE1dzvgcPWV6R::PROCESSING === $wLbz9)) {
            goto vOe38;
        }
        goto J7DUu;
        J7DUu:
        $this->SnpXu->save();
        goto a32Q3;
        zfWi3:
        Ck6A9:
        goto ypwB2;
        x_FxX:
        if (!$this->YbvQu) {
            goto ao4wA;
        }
        goto e8j_K;
        OuucZ:
        x46Hs:
        goto hfA12;
        e8j_K:
        $this->YbvQu->process($wLbz9);
        goto TQ58T;
        BMQOY:
        $this->YbvQu->process($wLbz9);
        goto OuucZ;
        TQ58T:
        ao4wA:
        goto zfWi3;
        IAuwF:
        $this->SnpXu->save();
        goto x_FxX;
        ypwB2:
    }
    private function mmTOxTIAqGq()
    {
        goto hk506;
        xuElx:
        hyx8Z:
        goto OJMz4;
        jULaO:
        AuWsF:
        goto xuElx;
        hk506:
        switch ($this->SnpXu->getType()) {
            case 'image':
                return new VFeE64RRDXinB($this->SnpXu, $this->yYDr_);
            case 'video':
                return new Oc4Fatu2lTNfj($this->SnpXu, App::make(ASuKOsLEZrEeb::class));
            default:
                return null;
        }
        goto jULaO;
        OJMz4:
    }
}
