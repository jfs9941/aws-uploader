<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\JL46r4tF2ZJbX;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Exception\JcxKbdowoFJnP;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Presigned\APwbZu5T1oTDh;
use Jfs\Uploader\Presigned\YVRwlWknxvvv9;
use Illuminate\Support\Facades\Log;
final class DRnwpVXsvb0a0 implements JL46r4tF2ZJbX
{
    private $ZIdi8;
    private $Ph2Bh;
    private $IdG3S;
    private $m1Mjp;
    private $XWRu9;
    public function __construct($G3hwE, $ftmEm, $ZIdyH, $Ba5m3, $rPLk4 = false)
    {
        goto vCL1C;
        n5ZeC:
        if ($rPLk4) {
            goto qVT1q;
        }
        goto zYB33;
        nzvL1:
        $this->IdG3S = $ftmEm;
        goto IcYRk;
        IcYRk:
        $this->m1Mjp = $ZIdyH;
        goto IsLQg;
        IsLQg:
        $this->XWRu9 = $Ba5m3;
        goto n5ZeC;
        WDpG9:
        qVT1q:
        goto dBeLe;
        vCL1C:
        $this->Ph2Bh = $G3hwE;
        goto nzvL1;
        zYB33:
        $this->mmM8vss70QC();
        goto WDpG9;
        dBeLe:
    }
    private function mmM8vss70QC() : void
    {
        goto Sfk9l;
        gQQNJ:
        return;
        goto XZqYX;
        nmrmC:
        try {
            $W8N2W = $this->Ph2Bh->m8Hi8VWicy3();
            $this->ZIdi8 = 's3' === $W8N2W->driver ? new YVRwlWknxvvv9($this->Ph2Bh, $this->IdG3S, $this->m1Mjp, $this->XWRu9) : new APwbZu5T1oTDh($this->Ph2Bh, $this->IdG3S, $this->m1Mjp);
        } catch (KWF9YuEFOPZRY $L0fOk) {
            Log::warning("Failed to set up presigned upload: {$L0fOk->getMessage()}");
        }
        goto d5hsm;
        Sfk9l:
        if (!(null !== $this->ZIdi8)) {
            goto tG3hp;
        }
        goto gQQNJ;
        XZqYX:
        tG3hp:
        goto nmrmC;
        d5hsm:
    }
    public function mueWblWOUUZ($JPLgA, $wLbz9)
    {
        goto KbCEP;
        PS_hP:
        BdXQ6:
        goto s6DVF;
        F3IHL:
        t6TmK:
        goto PS_hP;
        z3u5K:
        switch ($wLbz9) {
            case QE1dzvgcPWV6R::UPLOADING:
                $this->mRwFYoJ7Q2Z();
                goto BdXQ6;
            case QE1dzvgcPWV6R::UPLOADED:
                $this->mZHRoa0ciFp();
                goto BdXQ6;
            case QE1dzvgcPWV6R::ABORTED:
                $this->mpyQzqTN30P();
                goto BdXQ6;
            default:
                goto BdXQ6;
        }
        goto F3IHL;
        KbCEP:
        $this->mmM8vss70QC();
        goto z3u5K;
        s6DVF:
    }
    private function mZHRoa0ciFp() : void
    {
        goto eWZtE;
        XEwga:
        hvOxe:
        goto Sw0AG;
        vMH4t:
        $z620p = $this->Ph2Bh->getFile();
        goto VQKk_;
        arXLI:
        $z620p->mmjJCJ3ck7B(QE1dzvgcPWV6R::PROCESSING);
        goto XEwga;
        eWZtE:
        $this->ZIdi8->mNBOH0CMzl3();
        goto vMH4t;
        v_8Nx:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($z620p->id);
        goto arXLI;
        v4Seh:
        if (!$z620p instanceof IvT3V5jT5KEaA) {
            goto hvOxe;
        }
        goto v_8Nx;
        VQKk_:
        $z620p->mmjJCJ3ck7B(QE1dzvgcPWV6R::UPLOADED);
        goto v4Seh;
        Sw0AG:
    }
    private function mpyQzqTN30P() : void
    {
        $this->ZIdi8->mDAg6JsqB6v();
    }
    private function mRwFYoJ7Q2Z() : void
    {
        $this->ZIdi8->mX63RYpwJf8();
    }
}
