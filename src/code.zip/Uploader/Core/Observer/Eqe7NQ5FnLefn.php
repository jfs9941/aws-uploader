<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Zw8MUfOdDRfcx;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Exception\RRyzFa9lvheK9;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Presigned\Zz3arjpkHnF6s;
use Jfs\Uploader\Presigned\R0V3u2B7hkl0g;
use Illuminate\Support\Facades\Log;
final class Eqe7NQ5FnLefn implements Zw8MUfOdDRfcx
{
    private $fbCnU;
    private $VqTjZ;
    private $hYphi;
    private $DtvHw;
    private $pKUHV;
    public function __construct($X318G, $zuNM5, $S3rMg, $drKb4, $mM9ZL = false)
    {
        goto qhC2f;
        yPDCv:
        if ($mM9ZL) {
            goto MtmL4;
        }
        goto BX8Yz;
        BX8Yz:
        $this->mmsuZWWIGcB();
        goto PhIaA;
        qhC2f:
        $this->VqTjZ = $X318G;
        goto Xcp9u;
        Ey_xM:
        $this->DtvHw = $S3rMg;
        goto p2rzm;
        p2rzm:
        $this->pKUHV = $drKb4;
        goto yPDCv;
        Xcp9u:
        $this->hYphi = $zuNM5;
        goto Ey_xM;
        PhIaA:
        MtmL4:
        goto e7J3T;
        e7J3T:
    }
    private function mmsuZWWIGcB() : void
    {
        goto uJe_a;
        OqZ79:
        try {
            $p3JMC = $this->VqTjZ->miyJ5feZwpY();
            $this->fbCnU = 's3' === $p3JMC->driver ? new R0V3u2B7hkl0g($this->VqTjZ, $this->hYphi, $this->DtvHw, $this->pKUHV) : new Zz3arjpkHnF6s($this->VqTjZ, $this->hYphi, $this->DtvHw);
        } catch (DS3DIAJ2eyUA5 $qeKgz) {
            Log::warning("Failed to set up presigned upload: {$qeKgz->getMessage()}");
        }
        goto iFSuW;
        uJe_a:
        if (!(null !== $this->fbCnU)) {
            goto LiDHe;
        }
        goto Bf9QB;
        Bf9QB:
        return;
        goto b18kp;
        b18kp:
        LiDHe:
        goto OqZ79;
        iFSuW:
    }
    public function mHzEGxfe0qf($ADQei, $wbuog)
    {
        goto FydU2;
        FydU2:
        $this->mmsuZWWIGcB();
        goto oxaed;
        oxaed:
        switch ($wbuog) {
            case T93Mcsw1gA3an::UPLOADING:
                $this->mgVuryYhWXU();
                goto wncv9;
            case T93Mcsw1gA3an::UPLOADED:
                $this->mEWcg2BECub();
                goto wncv9;
            case T93Mcsw1gA3an::ABORTED:
                $this->mbDXvMinMiq();
                goto wncv9;
            default:
                goto wncv9;
        }
        goto CYPqQ;
        CYPqQ:
        da9UK:
        goto s1Q9I;
        s1Q9I:
        wncv9:
        goto ZQk7H;
        ZQk7H:
    }
    private function mEWcg2BECub() : void
    {
        goto qBhLE;
        Ncb5z:
        $VslFR = $this->VqTjZ->getFile();
        goto Nh5Y3;
        x273u:
        if (!$VslFR instanceof HS7SZ3rYPI80t) {
            goto nn678;
        }
        goto y2zmd;
        Nh5Y3:
        $VslFR->m6ASJ5S5Ktp(T93Mcsw1gA3an::UPLOADED);
        goto x273u;
        y2zmd:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($VslFR->id);
        goto tmIe4;
        qBhLE:
        $this->fbCnU->mPJeP3847zn();
        goto Ncb5z;
        tXurp:
        nn678:
        goto o6DsB;
        tmIe4:
        $VslFR->m6ASJ5S5Ktp(T93Mcsw1gA3an::PROCESSING);
        goto tXurp;
        o6DsB:
    }
    private function mbDXvMinMiq() : void
    {
        $this->fbCnU->mcNt6cVVB0k();
    }
    private function mgVuryYhWXU() : void
    {
        $this->fbCnU->m0jynmDLk8d();
    }
}
