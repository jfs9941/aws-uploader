<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Contracts\K6rnLmlRKxy9W;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class FhPHJXipLxQC9 implements K6rnLmlRKxy9W
{
    private $nIFfY;
    public function __construct($QuYzZ)
    {
        $this->nIFfY = $QuYzZ;
    }
    public function mYTLHr2vX9t($WVkJm, $CQyva)
    {
        goto jxLBG;
        jxLBG:
        if (!(QoCMzcKvH8Cw2::UPLOADED === $CQyva)) {
            goto hMQ4s;
        }
        goto GxTxB;
        GxTxB:
        $this->nIFfY->status = QoCMzcKvH8Cw2::UPLOADED;
        goto DDmgq;
        NFHPM:
        d4a3_:
        goto eoWep;
        MGmKJ:
        hMQ4s:
        goto ADvO_;
        eoWep:
        $this->nIFfY->save();
        goto MGmKJ;
        DDmgq:
        if (!$this->nIFfY instanceof FNGNxcyxjaxBG) {
            goto d4a3_;
        }
        goto CQcrX;
        r5QgW:
        $this->nIFfY->delete();
        goto yf40j;
        CQcrX:
        $this->nIFfY->mVwoe0E3Z3I(QoCMzcKvH8Cw2::PROCESSING);
        goto NFHPM;
        yf40j:
        wUO9I:
        goto P6sor;
        ADvO_:
        if (!(QoCMzcKvH8Cw2::DELETED === $CQyva && $this->nIFfY->mntZOTQMH84())) {
            goto wUO9I;
        }
        goto r5QgW;
        P6sor:
    }
}
