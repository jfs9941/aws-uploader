<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Contracts\Zw8MUfOdDRfcx;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\Strategy\NX9oXw65wUrm6;
use Jfs\Uploader\Core\Strategy\GzZMnwFWRLE21;
use Jfs\Uploader\Encoder\ZgEcV5Ek5Li7G;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Service\VjtcOzJCF9Hx7;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class D2rOZBl7n0bql implements Zw8MUfOdDRfcx
{
    private $fQewS;
    private $LXD2P;
    private $wEVdN;
    private $utuCE;
    public function __construct($VslFR, $dzspH, $bbFOe)
    {
        goto UyrU7;
        pgF6v:
        $this->wEVdN = $dzspH;
        goto uMaFH;
        UyrU7:
        $this->LXD2P = $VslFR;
        goto pgF6v;
        uMaFH:
        $this->utuCE = $bbFOe;
        goto aapm6;
        aapm6:
        $this->fQewS = $this->mhO12cVn6E3();
        goto Wxt1y;
        Wxt1y:
    }
    public function mHzEGxfe0qf($ADQei, $wbuog) : void
    {
        goto mKz9R;
        bhdx8:
        FPT6y:
        goto zLqIC;
        q3ofz:
        UXndK:
        goto dJqwl;
        Tamkn:
        quaQ8:
        goto bhdx8;
        u6h5c:
        if (!$this->fQewS) {
            goto quaQ8;
        }
        goto u5wvb;
        yXeDX:
        $this->fQewS->process($wbuog);
        goto pCPG7;
        fbLku:
        $this->LXD2P->save();
        goto u6h5c;
        uNxbs:
        $this->LXD2P->save();
        goto k3gS5;
        mKz9R:
        if (!(T93Mcsw1gA3an::PROCESSING === $wbuog)) {
            goto FPT6y;
        }
        goto fbLku;
        zLqIC:
        if (!(T93Mcsw1gA3an::ENCODING_PROCESSED === $wbuog)) {
            goto UXndK;
        }
        goto uNxbs;
        k3gS5:
        if (!$this->fQewS) {
            goto EuOGo;
        }
        goto yXeDX;
        pCPG7:
        EuOGo:
        goto q3ofz;
        u5wvb:
        $this->fQewS->process($wbuog);
        goto Tamkn;
        dJqwl:
    }
    private function mhO12cVn6E3()
    {
        goto MQO6I;
        WkY5_:
        CM4uZ:
        goto p1vYv;
        MQO6I:
        switch ($this->LXD2P->getType()) {
            case 'image':
                return new NX9oXw65wUrm6($this->LXD2P, $this->utuCE);
            case 'video':
                return new GzZMnwFWRLE21($this->LXD2P, App::make(ZgEcV5Ek5Li7G::class));
            default:
                return null;
        }
        goto wtEqv;
        wtEqv:
        iHwp6:
        goto WkY5_;
        p1vYv:
    }
}
