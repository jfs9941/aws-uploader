<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\GMMSgBcs5XImF;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Exception\BtFXMjsbQEzWB;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Jfs\Uploader\Presigned\TiGzUmdYpsc0B;
use Jfs\Uploader\Presigned\WChlGSbBoOSdQ;
final class XRRH05LBqJ7EZ implements GMMSgBcs5XImF
{
    private $Kuvqp;
    private $BntnT;
    private $s0VP1;
    private $JjUJH;
    private $kALX2;
    public function __construct($C2BaX, $TuWZt, $qg6AO, $vT463, $NtlAC = false)
    {
        goto Z8kZu;
        QWzt7:
        $this->s0VP1 = $TuWZt;
        goto TvCEY;
        PUVoB:
        $this->kALX2 = $vT463;
        goto rkx9a;
        jKCJ4:
        a0WGq:
        goto wG8Dg;
        AjhhC:
        $this->mplofefT7PI();
        goto jKCJ4;
        rkx9a:
        if ($NtlAC) {
            goto a0WGq;
        }
        goto AjhhC;
        TvCEY:
        $this->JjUJH = $qg6AO;
        goto PUVoB;
        Z8kZu:
        $this->BntnT = $C2BaX;
        goto QWzt7;
        wG8Dg:
    }
    private function mplofefT7PI() : void
    {
        goto hOiky;
        tRMlh:
        CDG_C:
        goto oYJ5k;
        hOiky:
        if (!(null !== $this->Kuvqp)) {
            goto CDG_C;
        }
        goto Mc93t;
        oYJ5k:
        try {
            $b679I = $this->BntnT->m6oz0N1G29M();
            $this->Kuvqp = 's3' === $b679I->n5TQN ? new WChlGSbBoOSdQ($this->BntnT, $this->s0VP1, $this->JjUJH, $this->kALX2) : new TiGzUmdYpsc0B($this->BntnT, $this->s0VP1, $this->JjUJH);
        } catch (NaLxNTATn0Ubr $NvDiU) {
            Log::warning("Failed to set up presigned upload: {$NvDiU->getMessage()}");
        }
        goto CocU0;
        Mc93t:
        return;
        goto tRMlh;
        CocU0:
    }
    public function mJdFuAPL4o5($a6p_S, $xM562)
    {
        goto fwXH6;
        cG9Nn:
        OgRqF:
        goto cC3xF;
        rReaN:
        switch ($xM562) {
            case EUkqoDwU9Zcvh::UPLOADING:
                $this->mXT9Tz5dtsh();
                goto OIdhI;
            case EUkqoDwU9Zcvh::UPLOADED:
                $this->mKQsUUV63Vd();
                goto OIdhI;
            case EUkqoDwU9Zcvh::ABORTED:
                $this->mkHTjFwldXM();
                goto OIdhI;
            default:
                goto OIdhI;
        }
        goto cG9Nn;
        cC3xF:
        OIdhI:
        goto rt2Ij;
        fwXH6:
        $this->mplofefT7PI();
        goto rReaN;
        rt2Ij:
    }
    private function mKQsUUV63Vd() : void
    {
        goto ZdGNz;
        Cv3UV:
        if (!$VZzWw instanceof Kt6NO3eUvdER6) {
            goto mYRdC;
        }
        goto xg5s0;
        ZdGNz:
        $this->Kuvqp->mxQijA6o4Nt();
        goto RrMgn;
        mlsDb:
        $VZzWw->mhWKUa6jAoa(EUkqoDwU9Zcvh::UPLOADED);
        goto Cv3UV;
        xg5s0:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($VZzWw->id);
        goto YwJX4;
        RrMgn:
        $VZzWw = $this->BntnT->getFile();
        goto mlsDb;
        YwJX4:
        mYRdC:
        goto dBTpO;
        dBTpO:
    }
    private function mkHTjFwldXM() : void
    {
        $this->Kuvqp->mf6JtbCKo3e();
    }
    private function mXT9Tz5dtsh() : void
    {
        $this->Kuvqp->mSJwGb2dLan();
    }
}
