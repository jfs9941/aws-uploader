<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Contracts\Hx13AKbJdXa2m;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Core\Strategy\Wod91e1taEuyw;
use Jfs\Uploader\Core\Strategy\NJMP7v7mhLXOH;
use Jfs\Uploader\Encoder\PERAjoCXLxFkm;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Service\HTG7kEjmlWunD;
final class AkWmj2jJHpl00 implements Hx13AKbJdXa2m
{
    private $AX2rc;
    private $PV7YF;
    private $qrvF0;
    private $EWW4J;
    public function __construct($TFA4Z, $eG_Pc, $rXnFu)
    {
        goto C7kUW;
        C7kUW:
        $this->PV7YF = $TFA4Z;
        goto pfOHM;
        qt7vr:
        $this->AX2rc = $this->mqGU5PZHZbV();
        goto lzzK7;
        xm7DS:
        $this->EWW4J = $rXnFu;
        goto qt7vr;
        pfOHM:
        $this->qrvF0 = $eG_Pc;
        goto xm7DS;
        lzzK7:
    }
    public function mw0DVFYNlsC($p8eXb, $lgpiE) : void
    {
        goto fd3rf;
        ZkyvN:
        $this->AX2rc->process($lgpiE);
        goto D01kQ;
        DSZfx:
        smpzG:
        goto SYhjl;
        cDGN4:
        if (!$this->AX2rc) {
            goto Na9UK;
        }
        goto ZkyvN;
        Nfq3A:
        $this->AX2rc->process($lgpiE);
        goto OMAah;
        OMAah:
        M7EVH:
        goto RPEjQ;
        RPEjQ:
        e2Oom:
        goto NmECp;
        fd3rf:
        if (!(Q5pXt73hTeTVP::PROCESSING === $lgpiE)) {
            goto smpzG;
        }
        goto e7H0s;
        D01kQ:
        Na9UK:
        goto DSZfx;
        SYhjl:
        if (!(Q5pXt73hTeTVP::ENCODING_PROCESSED === $lgpiE)) {
            goto e2Oom;
        }
        goto kSyF5;
        e7H0s:
        $this->PV7YF->save();
        goto cDGN4;
        kSyF5:
        $this->PV7YF->save();
        goto CpMAj;
        CpMAj:
        if (!$this->AX2rc) {
            goto M7EVH;
        }
        goto Nfq3A;
        NmECp:
    }
    private function mqGU5PZHZbV()
    {
        goto woVsp;
        woVsp:
        switch ($this->PV7YF->getType()) {
            case 'image':
                return new Wod91e1taEuyw($this->PV7YF, $this->EWW4J);
            case 'video':
                return new NJMP7v7mhLXOH($this->PV7YF, App::make(PERAjoCXLxFkm::class));
            default:
                return null;
        }
        goto aMVSn;
        aMVSn:
        T0HZ0:
        goto V8uk2;
        V8uk2:
        qakMH:
        goto WsnIi;
        WsnIi:
    }
}
