<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\BC3GCfM107Y7V;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Exception\Vkv9DR78jqmXg;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Jfs\Uploader\Presigned\BYwgIVxcWoIPX;
use Jfs\Uploader\Presigned\RCgyOgMS1Zgl4;
final class Px6hrv2owih2J implements BC3GCfM107Y7V
{
    private $KfH1R;
    private $yVhDF;
    private $VFHFZ;
    private $NP9R0;
    private $DK2hf;
    public function __construct($lIPqb, $dOL2I, $TLVVj, $TyFPC, $Cejwv = false)
    {
        goto UKK4l;
        HUTvS:
        $this->mt1JblXhle5();
        goto F2hms;
        UKK4l:
        $this->yVhDF = $lIPqb;
        goto vIBes;
        bdqku:
        if ($Cejwv) {
            goto ozKVS;
        }
        goto HUTvS;
        F2hms:
        ozKVS:
        goto tLS5F;
        vIBes:
        $this->VFHFZ = $dOL2I;
        goto daLPz;
        pfV0q:
        $this->DK2hf = $TyFPC;
        goto bdqku;
        daLPz:
        $this->NP9R0 = $TLVVj;
        goto pfV0q;
        tLS5F:
    }
    private function mt1JblXhle5() : void
    {
        goto GR0Xo;
        dpi2R:
        RogFT:
        goto DNwjy;
        DNwjy:
        try {
            $ag5JI = $this->yVhDF->mmWA2B9zVkK();
            $this->KfH1R = 's3' === $ag5JI->ymE9n ? new RCgyOgMS1Zgl4($this->yVhDF, $this->VFHFZ, $this->NP9R0, $this->DK2hf) : new BYwgIVxcWoIPX($this->yVhDF, $this->VFHFZ, $this->NP9R0);
        } catch (JGUomNqtfkab1 $mz5ks) {
            Log::warning("Failed to set up presigned upload: {$mz5ks->getMessage()}");
        }
        goto WvQAy;
        GR0Xo:
        if (!(null !== $this->KfH1R)) {
            goto RogFT;
        }
        goto WNlcN;
        WNlcN:
        return;
        goto dpi2R;
        WvQAy:
    }
    public function mUbEgwqXkQg($Y0L7L, $W4cEX)
    {
        goto aUnnL;
        LHnWj:
        switch ($W4cEX) {
            case SsxWbUYXracun::UPLOADING:
                $this->meaePVxWGtW();
                goto pi6Mp;
            case SsxWbUYXracun::UPLOADED:
                $this->mb3YxqIivjV();
                goto pi6Mp;
            case SsxWbUYXracun::ABORTED:
                $this->mcR5CxeSe80();
                goto pi6Mp;
            default:
                goto pi6Mp;
        }
        goto R_HRd;
        aUnnL:
        $this->mt1JblXhle5();
        goto LHnWj;
        R_HRd:
        afhW4:
        goto Fqd5Z;
        Fqd5Z:
        pi6Mp:
        goto uv9Xf;
        uv9Xf:
    }
    private function mb3YxqIivjV() : void
    {
        goto mia__;
        ex5xj:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($tscCi->id);
        goto l3XmO;
        am83Y:
        $tscCi = $this->yVhDF->getFile();
        goto ELy2h;
        ELy2h:
        $tscCi->mvUghb89hzW(SsxWbUYXracun::UPLOADED);
        goto QYgoP;
        mia__:
        $this->KfH1R->mqyBtnjUsU9();
        goto am83Y;
        l3XmO:
        O1de0:
        goto yhSs3;
        QYgoP:
        if (!$tscCi instanceof G4MP13yRAmltw) {
            goto O1de0;
        }
        goto ex5xj;
        yhSs3:
    }
    private function mcR5CxeSe80() : void
    {
        $this->KfH1R->mnpYdu0IZ9W();
    }
    private function meaePVxWGtW() : void
    {
        $this->KfH1R->mPEms69EA0A();
    }
}
