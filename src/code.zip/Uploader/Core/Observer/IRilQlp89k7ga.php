<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Contracts\F66VaMRGSfxoM;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Core\Strategy\VWx1aMGAHFRkn;
use Jfs\Uploader\Core\Strategy\NA3I5Dp0Fy3l3;
use Jfs\Uploader\Encoder\Koi3akneKfkiI;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Service\VmrgwQFNELOFc;
final class IRilQlp89k7ga implements F66VaMRGSfxoM
{
    private $iivWL;
    private $oWuCn;
    private $MV0lK;
    private $Tihgx;
    public function __construct($I2SbP, $tYsty, $j7R1u)
    {
        goto m0U00;
        m0U00:
        $this->oWuCn = $I2SbP;
        goto Ci7rC;
        s1PY_:
        $this->iivWL = $this->mOUyGAJugW8();
        goto zGf61;
        qW2qr:
        $this->Tihgx = $j7R1u;
        goto s1PY_;
        Ci7rC:
        $this->MV0lK = $tYsty;
        goto qW2qr;
        zGf61:
    }
    public function mSg4ZNxGqnf($ESYUX, $X7DL1) : void
    {
        goto LOgg6;
        pGTGH:
        if (!$this->iivWL) {
            goto mc2Ix;
        }
        goto eWS2y;
        LOgg6:
        if (!(EPmxqTVp5luXc::PROCESSING === $X7DL1)) {
            goto aNng3;
        }
        goto m1270;
        m1270:
        $this->oWuCn->save();
        goto d3scr;
        eWS2y:
        $this->iivWL->process($X7DL1);
        goto uggBa;
        IzLj6:
        JBapr:
        goto dQdHf;
        BqMee:
        if (!(EPmxqTVp5luXc::ENCODING_PROCESSED === $X7DL1)) {
            goto JBapr;
        }
        goto isnCc;
        ryeSZ:
        ZPper:
        goto nfA8Q;
        isnCc:
        $this->oWuCn->save();
        goto pGTGH;
        NJmoj:
        $this->iivWL->process($X7DL1);
        goto ryeSZ;
        nfA8Q:
        aNng3:
        goto BqMee;
        uggBa:
        mc2Ix:
        goto IzLj6;
        d3scr:
        if (!$this->iivWL) {
            goto ZPper;
        }
        goto NJmoj;
        dQdHf:
    }
    private function mOUyGAJugW8()
    {
        goto i06Ar;
        i06Ar:
        switch ($this->oWuCn->getType()) {
            case 'image':
                return new VWx1aMGAHFRkn($this->oWuCn, $this->Tihgx);
            case 'video':
                return new NA3I5Dp0Fy3l3($this->oWuCn, App::make(Koi3akneKfkiI::class));
            default:
                return null;
        }
        goto AhmhP;
        AhmhP:
        A893Q:
        goto VRz3X;
        VRz3X:
        JRU30:
        goto llOc6;
        llOc6:
    }
}
