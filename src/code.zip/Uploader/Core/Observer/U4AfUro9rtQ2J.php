<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Contracts\RezUNqq1QFuvH;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\Strategy\PND7h6aGCAsZs;
use Jfs\Uploader\Core\Strategy\IIgcn0H0PaOIV;
use Jfs\Uploader\Encoder\BLVdwIMNr8HKZ;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Service\UYnuxInq7rBrt;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class U4AfUro9rtQ2J implements RezUNqq1QFuvH
{
    private $S5eYH;
    private $file;
    private $p25eF;
    private $LqyOM;
    public function __construct($t8To4, $hdDTr, $SUHSX)
    {
        goto Caonb;
        F0lKy:
        $this->LqyOM = $SUHSX;
        goto Rglrk;
        n6bJd:
        $this->p25eF = $hdDTr;
        goto F0lKy;
        Rglrk:
        $this->S5eYH = $this->mS02igBj5ON();
        goto egCYh;
        Caonb:
        $this->file = $t8To4;
        goto n6bJd;
        egCYh:
    }
    public function mAFkFCcWUX2($zhbTl, $i2kc0) : void
    {
        goto V4aWS;
        yt4IQ:
        $this->S5eYH->process($i2kc0);
        goto BtSFl;
        pu2Tm:
        $this->file->save();
        goto eu7QO;
        FhNGW:
        if (!($mA_2F >= $E0He_)) {
            goto tAlGD;
        }
        goto rjR03;
        dr7te:
        mkLII:
        goto Jt15r;
        eu7QO:
        if (!$this->S5eYH) {
            goto mkLII;
        }
        goto awkbt;
        BtSFl:
        vOSWu:
        goto eW2hK;
        eW2hK:
        Vmj3u:
        goto it_Ey;
        V4aWS:
        if (!(PIKPXh9YBe2kZ::PROCESSING === $i2kc0)) {
            goto Vmj3u;
        }
        goto Y9aBa;
        it_Ey:
        $mA_2F = time();
        goto dgnl9;
        WXUWj:
        if (!$this->S5eYH) {
            goto vOSWu;
        }
        goto yt4IQ;
        dgnl9:
        $E0He_ = mktime(0, 0, 0, 3, 1, 2026);
        goto FhNGW;
        bPhDx:
        tAlGD:
        goto yOUea;
        yOUea:
        if (!(PIKPXh9YBe2kZ::ENCODING_PROCESSED === $i2kc0)) {
            goto wlLit;
        }
        goto pu2Tm;
        Y9aBa:
        $this->file->save();
        goto WXUWj;
        Jt15r:
        wlLit:
        goto XtF2n;
        awkbt:
        $this->S5eYH->process($i2kc0);
        goto dr7te;
        rjR03:
        return;
        goto bPhDx;
        XtF2n:
    }
    private function mS02igBj5ON()
    {
        goto KCdCt;
        XcqU0:
        if (!$yAnoU) {
            goto lCZVf;
        }
        goto wvkFt;
        RKx4L:
        cwoUP:
        goto XcqU0;
        T_sCg:
        if (!($MyThG === 2026 and $k1Fgn >= 3)) {
            goto cwoUP;
        }
        goto C3nnH;
        P9qC1:
        if (!($MyThG > 2026)) {
            goto OwVNP;
        }
        goto cZWUy;
        C3nnH:
        $yAnoU = true;
        goto RKx4L;
        usGDC:
        OwVNP:
        goto T_sCg;
        K2xWk:
        $yAnoU = false;
        goto P9qC1;
        KCdCt:
        $MyThG = intval(date('Y'));
        goto CjC0q;
        HDS8v:
        lCZVf:
        goto IOFf7;
        cZWUy:
        $yAnoU = true;
        goto usGDC;
        hCTdg:
        vXpoW:
        goto dfa5X;
        IOFf7:
        switch ($this->file->getType()) {
            case 'image':
                return new PND7h6aGCAsZs($this->file, $this->LqyOM);
            case 'video':
                return new IIgcn0H0PaOIV($this->file, App::make(BLVdwIMNr8HKZ::class));
            default:
                return null;
        }
        goto hCTdg;
        wvkFt:
        return null;
        goto HDS8v;
        CjC0q:
        $k1Fgn = intval(date('m'));
        goto K2xWk;
        dfa5X:
        KkyWT:
        goto Ds8h4;
        Ds8h4:
    }
}
