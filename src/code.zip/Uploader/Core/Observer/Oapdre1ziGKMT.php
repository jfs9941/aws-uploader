<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Contracts\JL46r4tF2ZJbX;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
class Oapdre1ziGKMT implements JL46r4tF2ZJbX
{
    private $SnpXu;
    public function __construct($z620p)
    {
        $this->SnpXu = $z620p;
    }
    public function mueWblWOUUZ($JPLgA, $wLbz9)
    {
        goto ppdca;
        OEibW:
        $this->SnpXu->status = QE1dzvgcPWV6R::UPLOADED;
        goto JNz34;
        Brjzs:
        $this->SnpXu->delete();
        goto v7bid;
        JNz34:
        if (!$this->SnpXu instanceof FmmY71eXk0D8U) {
            goto TT6Zy;
        }
        goto Pelsk;
        v7bid:
        nuiwx:
        goto t9W6q;
        VymzD:
        $this->SnpXu->save();
        goto e3aCj;
        ppdca:
        if (!(QE1dzvgcPWV6R::UPLOADED === $wLbz9)) {
            goto VCm1s;
        }
        goto OEibW;
        rcwDU:
        TT6Zy:
        goto VymzD;
        Pelsk:
        $this->SnpXu->mmjJCJ3ck7B(QE1dzvgcPWV6R::PROCESSING);
        goto rcwDU;
        coJ5O:
        if (!(QE1dzvgcPWV6R::DELETED === $wLbz9 && $this->SnpXu->mzKIDvWQfgP())) {
            goto nuiwx;
        }
        goto Brjzs;
        e3aCj:
        VCm1s:
        goto coJ5O;
        t9W6q:
    }
}
