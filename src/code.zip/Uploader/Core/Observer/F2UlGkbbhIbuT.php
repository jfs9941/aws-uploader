<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\Hx13AKbJdXa2m;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Exception\CWn6V46ojDVJy;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Jfs\Uploader\Presigned\EG6PFllhbS4O3;
use Jfs\Uploader\Presigned\DAvuKXtR9GtaY;
final class F2UlGkbbhIbuT implements Hx13AKbJdXa2m
{
    private $RZMgT;
    private $hpsHP;
    private $fodJQ;
    private $i9Sna;
    private $pBNm8;
    public function __construct($y4PP7, $nsgrL, $moAxa, $QEIhn, $nAzh3 = false)
    {
        goto pe4Wc;
        pe4Wc:
        $this->hpsHP = $y4PP7;
        goto eH95G;
        XsaTY:
        m02b7:
        goto RyKYB;
        Mkxvp:
        $this->pBNm8 = $QEIhn;
        goto LMELA;
        auhCn:
        $this->i9Sna = $moAxa;
        goto Mkxvp;
        eH95G:
        $this->fodJQ = $nsgrL;
        goto auhCn;
        qwe5D:
        $this->mmjHcwo9Agz();
        goto XsaTY;
        LMELA:
        if ($nAzh3) {
            goto m02b7;
        }
        goto qwe5D;
        RyKYB:
    }
    private function mmjHcwo9Agz() : void
    {
        goto hg1Eb;
        Fac0v:
        Djwed:
        goto Yoy6S;
        hg1Eb:
        if (!(null !== $this->RZMgT)) {
            goto Djwed;
        }
        goto pWpAy;
        Yoy6S:
        try {
            $xf_XV = $this->hpsHP->mlnKeX4eawe();
            $this->RZMgT = 's3' === $xf_XV->rbCCx ? new DAvuKXtR9GtaY($this->hpsHP, $this->fodJQ, $this->i9Sna, $this->pBNm8) : new EG6PFllhbS4O3($this->hpsHP, $this->fodJQ, $this->i9Sna);
        } catch (JQsXv6HTe1n89 $xlNa7) {
            Log::warning("Failed to set up presigned upload: {$xlNa7->getMessage()}");
        }
        goto nq6pg;
        pWpAy:
        return;
        goto Fac0v;
        nq6pg:
    }
    public function mw0DVFYNlsC($p8eXb, $lgpiE)
    {
        goto icsvA;
        icsvA:
        $this->mmjHcwo9Agz();
        goto DpYkP;
        DpYkP:
        switch ($lgpiE) {
            case Q5pXt73hTeTVP::UPLOADING:
                $this->mDOScKOtIho();
                goto jNUCa;
            case Q5pXt73hTeTVP::UPLOADED:
                $this->mfmwC1S0pBu();
                goto jNUCa;
            case Q5pXt73hTeTVP::ABORTED:
                $this->ma7Pv9YKD6r();
                goto jNUCa;
            default:
                goto jNUCa;
        }
        goto hs6pt;
        XWJRF:
        jNUCa:
        goto eTPur;
        hs6pt:
        vxUlg:
        goto XWJRF;
        eTPur:
    }
    private function mfmwC1S0pBu() : void
    {
        goto KKb3H;
        DOy_R:
        $TFA4Z = $this->hpsHP->getFile();
        goto mfrEa;
        dhoC8:
        Lq0E7:
        goto gBz_1;
        KKb3H:
        $this->RZMgT->mpcjuwrcLbZ();
        goto DOy_R;
        mfrEa:
        $TFA4Z->mhK1eUHzFBK(Q5pXt73hTeTVP::UPLOADED);
        goto gtmJK;
        gtmJK:
        if (!$TFA4Z instanceof UMeQT1ArE1U05) {
            goto Lq0E7;
        }
        goto WQxzq;
        WQxzq:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($TFA4Z->id);
        goto dhoC8;
        gBz_1:
    }
    private function ma7Pv9YKD6r() : void
    {
        $this->RZMgT->msMWIkXUKbG();
    }
    private function mDOScKOtIho() : void
    {
        $this->RZMgT->mKjsNob7bmV();
    }
}
