<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Contracts\GMMSgBcs5XImF;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
class K5kKBgfmxrNjt implements GMMSgBcs5XImF
{
    private $PxcXo;
    public function __construct($VZzWw)
    {
        $this->PxcXo = $VZzWw;
    }
    public function mJdFuAPL4o5($a6p_S, $xM562)
    {
        goto bMHBl;
        L2aH1:
        zSeV9:
        goto Yy52U;
        jbxII:
        if (!$this->PxcXo instanceof JyZaxpharsbun) {
            goto zSeV9;
        }
        goto cA8v3;
        l9XfT:
        Ez0Ip:
        goto u3YBT;
        u3YBT:
        if (!(EUkqoDwU9Zcvh::DELETED === $xM562 && $this->PxcXo->m7UA7FXPPxn())) {
            goto Vqt03;
        }
        goto incuZ;
        Yy52U:
        $this->PxcXo->save();
        goto l9XfT;
        LTvMD:
        Vqt03:
        goto xNxE4;
        RCfbi:
        $this->PxcXo->status = EUkqoDwU9Zcvh::UPLOADED;
        goto jbxII;
        incuZ:
        $this->PxcXo->delete();
        goto LTvMD;
        cA8v3:
        $this->PxcXo->mhWKUa6jAoa(EUkqoDwU9Zcvh::PROCESSING);
        goto L2aH1;
        bMHBl:
        if (!(EUkqoDwU9Zcvh::UPLOADED === $xM562)) {
            goto Ez0Ip;
        }
        goto RCfbi;
        xNxE4:
    }
}
