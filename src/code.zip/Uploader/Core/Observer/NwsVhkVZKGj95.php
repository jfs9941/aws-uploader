<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\OZ0OEimEhcPCG;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Exception\GpiFZublserD8;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Presigned\Bcpy8NVj4ZnQn;
use Jfs\Uploader\Presigned\Xf65LJkoYtNWa;
use Illuminate\Support\Facades\Log;
final class NwsVhkVZKGj95 implements OZ0OEimEhcPCG
{
    private $SuYji;
    private $oVe7o;
    private $iAAqk;
    private $PrHIa;
    private $gHJ_C;
    public function __construct($r4uPF, $YNIuu, $NP1kd, $iwKga, $gzpmS = false)
    {
        goto eLacb;
        e2DFZ:
        $this->gHJ_C = $iwKga;
        goto FzJIN;
        EleEF:
        $this->mfdCO7oLcpg();
        goto VCj8p;
        VCj8p:
        KU7FR:
        goto BhZFW;
        eLacb:
        $this->oVe7o = $r4uPF;
        goto rJLj3;
        rJLj3:
        $this->iAAqk = $YNIuu;
        goto wTLzQ;
        wTLzQ:
        $this->PrHIa = $NP1kd;
        goto e2DFZ;
        FzJIN:
        if ($gzpmS) {
            goto KU7FR;
        }
        goto EleEF;
        BhZFW:
    }
    private function mfdCO7oLcpg() : void
    {
        goto HLGGY;
        fsIlE:
        ZDgIB:
        goto HQ7n2;
        AH8Vf:
        return;
        goto fsIlE;
        HLGGY:
        if (!(null !== $this->SuYji)) {
            goto ZDgIB;
        }
        goto AH8Vf;
        HQ7n2:
        try {
            $TxsWN = $this->oVe7o->mIrarJhaP0j();
            $this->SuYji = 's3' === $TxsWN->driver ? new Xf65LJkoYtNWa($this->oVe7o, $this->iAAqk, $this->PrHIa, $this->gHJ_C) : new Bcpy8NVj4ZnQn($this->oVe7o, $this->iAAqk, $this->PrHIa);
        } catch (CU2TWW78cXYKP $p7PBd) {
            Log::warning("Failed to set up presigned upload: {$p7PBd->getMessage()}");
        }
        goto rRQVZ;
        rRQVZ:
    }
    public function mw8TbyaigDj($c9oe4, $Aof5j)
    {
        goto Qcn0L;
        QI11G:
        switch ($Aof5j) {
            case FmSSI1JLQCp0W::UPLOADING:
                $this->mLx0DKMk1v5();
                goto vXEir;
            case FmSSI1JLQCp0W::UPLOADED:
                $this->mftHFRuW24V();
                goto vXEir;
            case FmSSI1JLQCp0W::ABORTED:
                $this->meABPJdbd6K();
                goto vXEir;
            default:
                goto vXEir;
        }
        goto cOVCD;
        cOVCD:
        Mri7y:
        goto x0WPI;
        x0WPI:
        vXEir:
        goto KRfes;
        Qcn0L:
        $this->mfdCO7oLcpg();
        goto QI11G;
        KRfes:
    }
    private function mftHFRuW24V() : void
    {
        goto IIXB_;
        f5Fcp:
        $cNpq7->muggTul6CGA(FmSSI1JLQCp0W::PROCESSING);
        goto kXW4w;
        kXW4w:
        gnllF:
        goto hiSTy;
        u53po:
        $cNpq7->muggTul6CGA(FmSSI1JLQCp0W::UPLOADED);
        goto xBOBG;
        IIXB_:
        $this->SuYji->mO5xHEz50iL();
        goto CY76f;
        CY76f:
        $cNpq7 = $this->oVe7o->getFile();
        goto u53po;
        lGUOV:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($cNpq7->id);
        goto f5Fcp;
        xBOBG:
        if (!$cNpq7 instanceof M7oTJdNm24KG4) {
            goto gnllF;
        }
        goto lGUOV;
        hiSTy:
    }
    private function meABPJdbd6K() : void
    {
        $this->SuYji->mdqqx89d2D7();
    }
    private function mLx0DKMk1v5() : void
    {
        $this->SuYji->mMbBP7u4MD7();
    }
}
