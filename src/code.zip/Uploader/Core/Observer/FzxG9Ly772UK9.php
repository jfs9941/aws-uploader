<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\C3XDkOI7yIIoE;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Exception\EJQS1ugI78hby;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Presigned\Z1L0bzuyW4n3L;
use Jfs\Uploader\Presigned\OUJDLk41w7oqE;
use Illuminate\Support\Facades\Log;
final class FzxG9Ly772UK9 implements C3XDkOI7yIIoE
{
    private $IPcWW;
    private $BH22D;
    private $zoOKU;
    private $NICMg;
    private $pHuSQ;
    public function __construct($e0yCg, $e3FbC, $iw6E8, $h2Cp1, $Cjhis = false)
    {
        goto uONAq;
        CdAT5:
        tjQdQ:
        goto sdpV5;
        uONAq:
        $this->BH22D = $e0yCg;
        goto Aerqv;
        EsmsF:
        $this->NICMg = $iw6E8;
        goto n8xys;
        XIPs2:
        if ($Cjhis) {
            goto tjQdQ;
        }
        goto Mzs1o;
        Mzs1o:
        $this->mnnCOA9AO9w();
        goto CdAT5;
        Aerqv:
        $this->zoOKU = $e3FbC;
        goto EsmsF;
        n8xys:
        $this->pHuSQ = $h2Cp1;
        goto XIPs2;
        sdpV5:
    }
    private function mnnCOA9AO9w() : void
    {
        goto SALye;
        SALye:
        if (!(null !== $this->IPcWW)) {
            goto QTC9d;
        }
        goto U931q;
        LLFy0:
        try {
            $AOnlH = $this->BH22D->m8KWEnHETkc();
            $this->IPcWW = 's3' === $AOnlH->gUPdP ? new OUJDLk41w7oqE($this->BH22D, $this->zoOKU, $this->NICMg, $this->pHuSQ) : new Z1L0bzuyW4n3L($this->BH22D, $this->zoOKU, $this->NICMg);
        } catch (UZ54KLSfEVX7F $p0etA) {
            Log::warning("Failed to set up presigned upload: {$p0etA->getMessage()}");
        }
        goto Eqr8e;
        U931q:
        return;
        goto r50e1;
        r50e1:
        QTC9d:
        goto LLFy0;
        Eqr8e:
    }
    public function mEE11OcGDDM($i2vqC, $Z8Kuq)
    {
        goto rpS3B;
        p9lP6:
        switch ($Z8Kuq) {
            case EHhCBxlsVyz9C::UPLOADING:
                $this->mReReDfXTji();
                goto Zj8dH;
            case EHhCBxlsVyz9C::UPLOADED:
                $this->mYrUAh8iY2y();
                goto Zj8dH;
            case EHhCBxlsVyz9C::ABORTED:
                $this->mosj2ciNQg0();
                goto Zj8dH;
            default:
                goto Zj8dH;
        }
        goto lFVHf;
        r4QNS:
        Zj8dH:
        goto C_N9v;
        lFVHf:
        fvnHe:
        goto r4QNS;
        rpS3B:
        $this->mnnCOA9AO9w();
        goto p9lP6;
        C_N9v:
    }
    private function mYrUAh8iY2y() : void
    {
        goto HlX3x;
        NSZXA:
        Kc4Am:
        goto AxSfN;
        M1G4K:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($gNVOT->id);
        goto NSZXA;
        XzQ1e:
        $gNVOT->ml2jBQKKXoS(EHhCBxlsVyz9C::UPLOADED);
        goto VIKNs;
        x239F:
        $gNVOT = $this->BH22D->getFile();
        goto XzQ1e;
        HlX3x:
        $this->IPcWW->mbG9fnI6E5D();
        goto x239F;
        VIKNs:
        if (!$gNVOT instanceof BtruCfJoaSWZ6) {
            goto Kc4Am;
        }
        goto M1G4K;
        AxSfN:
    }
    private function mosj2ciNQg0() : void
    {
        $this->IPcWW->mlSgbNh2AvY();
    }
    private function mReReDfXTji() : void
    {
        $this->IPcWW->mrn0zxfXEyv();
    }
}
