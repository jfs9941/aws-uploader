<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Contracts\Cwggsm2UPkGtM;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
class KrCJD18qpEqnY implements Cwggsm2UPkGtM
{
    private $R_58H;
    public function __construct($eQ4Ln)
    {
        $this->R_58H = $eQ4Ln;
    }
    public function mFunvful2ao($QRp1M, $Y0Lou)
    {
        goto HG50b;
        D2mcU:
        uCvLz:
        goto lEbJ5;
        I2dmr:
        if (!(MUu80sOhINyO3::DELETED === $Y0Lou && $this->R_58H->m0IQvI6cLO5())) {
            goto uCvLz;
        }
        goto nTkrO;
        r5wQS:
        r_tj6:
        goto I2dmr;
        fkanf:
        if (!$this->R_58H instanceof XqAJHKYeaW2YU) {
            goto HpfaF;
        }
        goto cGBWU;
        cGBWU:
        $this->R_58H->mG7ZLOSfPOQ(MUu80sOhINyO3::PROCESSING);
        goto j271K;
        HG50b:
        if (!(MUu80sOhINyO3::UPLOADED === $Y0Lou)) {
            goto r_tj6;
        }
        goto Zom4O;
        Zom4O:
        $this->R_58H->status = MUu80sOhINyO3::UPLOADED;
        goto fkanf;
        nTkrO:
        $this->R_58H->delete();
        goto D2mcU;
        j271K:
        HpfaF:
        goto EXlD3;
        EXlD3:
        $this->R_58H->save();
        goto r5wQS;
        lEbJ5:
    }
}
