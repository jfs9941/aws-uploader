<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Observer;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Contracts\A2uS8gTe46deJ;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Enum\Aetm2HiFuJE34;
class Jzgh0IwrfyoJe implements A2uS8gTe46deJ
{
    private $i31Dp;
    public function __construct($eVZrJ)
    {
        $this->i31Dp = $eVZrJ;
    }
    public function mI9DhQKSU08($SGfNF, $SIscU)
    {
        goto y8C3q;
        ORZu6:
        $this->i31Dp->save();
        goto Ygs2S;
        H0o1d:
        if (!(Aetm2HiFuJE34::DELETED === $SIscU && $this->i31Dp->mDm9EIxBnMR())) {
            goto AVP_i;
        }
        goto F5V2l;
        Y0d5C:
        if (!$this->i31Dp instanceof CrEYqpC23XUGo) {
            goto u0ee5;
        }
        goto yhhVS;
        fyvxX:
        $this->i31Dp->status = Aetm2HiFuJE34::UPLOADED;
        goto Y0d5C;
        F5V2l:
        $this->i31Dp->delete();
        goto zQAvL;
        zQAvL:
        AVP_i:
        goto YWFNq;
        y8C3q:
        if (!(Aetm2HiFuJE34::UPLOADED === $SIscU)) {
            goto v1d18;
        }
        goto fyvxX;
        Kap7k:
        u0ee5:
        goto ORZu6;
        yhhVS:
        $this->i31Dp->mKOiTrzpM4V(Aetm2HiFuJE34::PROCESSING);
        goto Kap7k;
        Ygs2S:
        v1d18:
        goto H0o1d;
        YWFNq:
    }
}
