<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Contracts\UGfAXCSEERPE4;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\Strategy\NxY6bTAm4VjBv;
use Jfs\Uploader\Core\Strategy\DUAidS6gqp1P7;
use Jfs\Uploader\Encoder\O4lVkPvpn6cme;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Service\XxTGlKndb3r5q;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class HJceqWpwyTfR6 implements UGfAXCSEERPE4
{
    private $bENSc;
    private $EA4YD;
    private $uiTOc;
    private $qmMpI;
    public function __construct($YfsmL, $ATeSz, $Bm5Jl)
    {
        goto JQxQf;
        JQxQf:
        $this->EA4YD = $YfsmL;
        goto UMGib;
        YVa9U:
        $this->qmMpI = $Bm5Jl;
        goto yXrHF;
        UMGib:
        $this->uiTOc = $ATeSz;
        goto YVa9U;
        yXrHF:
        $this->bENSc = $this->mDwt2l2VDTX();
        goto phJCR;
        phJCR:
    }
    public function mj4xpscl4k5($DOhs8, $vQwbX) : void
    {
        goto n_jcN;
        ArhS9:
        $this->bENSc->process($vQwbX);
        goto dVRAr;
        dVRAr:
        ilJtk:
        goto DlHHe;
        NMllF:
        OFfFv:
        goto wl34t;
        jntz4:
        if (!(LV0wDYHZInswq::ENCODING_PROCESSED === $vQwbX)) {
            goto LqfWr;
        }
        goto toq6y;
        gIZVj:
        $this->bENSc->process($vQwbX);
        goto NMllF;
        toq6y:
        $this->EA4YD->save();
        goto Y3gmG;
        n_jcN:
        if (!(LV0wDYHZInswq::PROCESSING === $vQwbX)) {
            goto bmZaD;
        }
        goto FwQdN;
        PeRZr:
        if (!$this->bENSc) {
            goto ilJtk;
        }
        goto ArhS9;
        FwQdN:
        $this->EA4YD->save();
        goto PeRZr;
        wl34t:
        LqfWr:
        goto Rn3Vd;
        Y3gmG:
        if (!$this->bENSc) {
            goto OFfFv;
        }
        goto gIZVj;
        DlHHe:
        bmZaD:
        goto jntz4;
        Rn3Vd:
    }
    private function mDwt2l2VDTX()
    {
        goto hSq0P;
        i_uNa:
        Hkpil:
        goto oZqh4;
        hSq0P:
        switch ($this->EA4YD->getType()) {
            case 'image':
                return new NxY6bTAm4VjBv($this->EA4YD, $this->qmMpI);
            case 'video':
                return new DUAidS6gqp1P7($this->EA4YD, App::make(O4lVkPvpn6cme::class));
            default:
                return null;
        }
        goto lERYy;
        lERYy:
        trexr:
        goto i_uNa;
        oZqh4:
    }
}
