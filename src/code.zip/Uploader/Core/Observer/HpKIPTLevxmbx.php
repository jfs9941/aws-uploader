<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Contracts\Pr07JVh1ChqJO;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\Strategy\DMyHh120797CK;
use Jfs\Uploader\Core\Strategy\LccfiPneOqkUR;
use Jfs\Uploader\Encoder\EBrgb5DByuboN;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Service\RiRUUwVHtq3AY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class HpKIPTLevxmbx implements Pr07JVh1ChqJO
{
    private $NNqGN;
    private $MhOEp;
    private $SxfKN;
    private $WStj_;
    public function __construct($RB3Ub, $DPWG1, $ky5s4)
    {
        goto BpL2b;
        r46zb:
        $this->NNqGN = $this->miL19gPPJcW();
        goto aYO1i;
        RHF14:
        $this->SxfKN = $DPWG1;
        goto xaa0u;
        BpL2b:
        $this->MhOEp = $RB3Ub;
        goto RHF14;
        xaa0u:
        $this->WStj_ = $ky5s4;
        goto r46zb;
        aYO1i:
    }
    public function mI8wqsETHZd($zgXzD, $BmlMb) : void
    {
        goto QjNCN;
        JZzpw:
        $this->MhOEp->save();
        goto a4YT1;
        a4YT1:
        if (!$this->NNqGN) {
            goto GgWVC;
        }
        goto Rj1Hm;
        wf1mv:
        $this->NNqGN->process($BmlMb);
        goto SkVUt;
        Rj1Hm:
        $this->NNqGN->process($BmlMb);
        goto IlMnc;
        Aie7g:
        $this->MhOEp->save();
        goto RGfOh;
        RGfOh:
        if (!$this->NNqGN) {
            goto MKTQ5;
        }
        goto wf1mv;
        uS96R:
        bx2EK:
        goto ZTJTy;
        QjNCN:
        if (!(Fsm7WCrUwVWh9::PROCESSING === $BmlMb)) {
            goto v83Q5;
        }
        goto Aie7g;
        IlMnc:
        GgWVC:
        goto uS96R;
        qxERk:
        if (!(Fsm7WCrUwVWh9::ENCODING_PROCESSED === $BmlMb)) {
            goto bx2EK;
        }
        goto JZzpw;
        vuq1W:
        v83Q5:
        goto qxERk;
        SkVUt:
        MKTQ5:
        goto vuq1W;
        ZTJTy:
    }
    private function miL19gPPJcW()
    {
        goto XdHDj;
        jA6R4:
        Rx533:
        goto kdJW2;
        TL6VG:
        cLNPI:
        goto jA6R4;
        XdHDj:
        switch ($this->MhOEp->getType()) {
            case 'image':
                return new DMyHh120797CK($this->MhOEp, $this->WStj_);
            case 'video':
                return new LccfiPneOqkUR($this->MhOEp, App::make(EBrgb5DByuboN::class));
            default:
                return null;
        }
        goto TL6VG;
        kdJW2:
    }
}
