<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Contracts\PzqA3QfUmhhMJ;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
class Gj1znMULTyeud implements PzqA3QfUmhhMJ
{
    private $N1jgO;
    public function __construct($Ga9Xm)
    {
        $this->N1jgO = $Ga9Xm;
    }
    public function mjTwbCJOfRB($L51Zi, $IoGt4)
    {
        goto INx5B;
        ZrIDz:
        dBGCN:
        goto KHd0l;
        qC6li:
        bgYhF:
        goto rsoWv;
        B1iym:
        $this->N1jgO->delete();
        goto mqFA0;
        KHd0l:
        if (!(HGmeWpZQSxAlO::DELETED === $IoGt4 && $this->N1jgO->mArqmCtDsDI())) {
            goto kIecp;
        }
        goto B1iym;
        rsoWv:
        $this->N1jgO->save();
        goto ZrIDz;
        B2tfv:
        if (!$this->N1jgO instanceof Vt3ybt0yfaPAa) {
            goto bgYhF;
        }
        goto vpYl8;
        gEAyt:
        $this->N1jgO->status = HGmeWpZQSxAlO::UPLOADED;
        goto B2tfv;
        vpYl8:
        $this->N1jgO->muO5nIQPKS7(HGmeWpZQSxAlO::PROCESSING);
        goto qC6li;
        mqFA0:
        kIecp:
        goto mIva6;
        INx5B:
        if (!(HGmeWpZQSxAlO::UPLOADED === $IoGt4)) {
            goto dBGCN;
        }
        goto gEAyt;
        mIva6:
    }
}
