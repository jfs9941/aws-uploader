<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Contracts\MJPdrg0mCs2vV;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
class Q8yWq8yZ2btxz implements MJPdrg0mCs2vV
{
    private $Fhq5F;
    public function __construct($spSJx)
    {
        $this->Fhq5F = $spSJx;
    }
    public function myLtTimHe7C($Ll7x2, $SKIcn)
    {
        goto Jsz7m;
        GSfpm:
        if (!(LlMDscQw21XKp::DELETED === $SKIcn && $this->Fhq5F->m5nOvxmictr())) {
            goto C53uu;
        }
        goto xHiDE;
        Jsz7m:
        if (!(LlMDscQw21XKp::UPLOADED === $SKIcn)) {
            goto z2QJx;
        }
        goto vI12e;
        tfRiD:
        if (!$this->Fhq5F instanceof IZ5shp3JHuftD) {
            goto JCP3o;
        }
        goto wmdU0;
        xHiDE:
        $this->Fhq5F->delete();
        goto jwMoq;
        QOz1I:
        z2QJx:
        goto GSfpm;
        wmdU0:
        $this->Fhq5F->mmrYWGPqYWx(LlMDscQw21XKp::PROCESSING);
        goto yhZ9N;
        LrnUo:
        $this->Fhq5F->save();
        goto QOz1I;
        yhZ9N:
        JCP3o:
        goto LrnUo;
        jwMoq:
        C53uu:
        goto QyZsN;
        vI12e:
        $this->Fhq5F->status = LlMDscQw21XKp::UPLOADED;
        goto tfRiD;
        QyZsN:
    }
}
