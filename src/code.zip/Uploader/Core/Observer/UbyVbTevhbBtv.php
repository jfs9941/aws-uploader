<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Contracts\MJPdrg0mCs2vV;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\Strategy\XbEcido52FH95;
use Jfs\Uploader\Core\Strategy\KBMQV81FQOd78;
use Jfs\Uploader\Encoder\HYDAkFMesEGUF;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Service\EjF4mjWaYHYqw;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class UbyVbTevhbBtv implements MJPdrg0mCs2vV
{
    private $FGXTd;
    private $Fhq5F;
    private $VV2A8;
    private $yvtQF;
    public function __construct($spSJx, $oOPBt, $KF9cQ)
    {
        goto bm142;
        bm142:
        $this->Fhq5F = $spSJx;
        goto jItLm;
        MocPw:
        $this->yvtQF = $KF9cQ;
        goto uzZuI;
        uzZuI:
        $this->FGXTd = $this->mtrakscr4gO();
        goto kwIhw;
        jItLm:
        $this->VV2A8 = $oOPBt;
        goto MocPw;
        kwIhw:
    }
    public function myLtTimHe7C($Ll7x2, $SKIcn) : void
    {
        goto EioxP;
        YxLQb:
        xyHBF:
        goto m6RAq;
        Toi3A:
        $this->FGXTd->process($SKIcn);
        goto xmCzr;
        ZJNfz:
        if (!$this->FGXTd) {
            goto QRjgj;
        }
        goto Toi3A;
        g7Xod:
        J7Ff2:
        goto yYNZJ;
        nv2Cr:
        $this->Fhq5F->save();
        goto UQ_9R;
        xmCzr:
        QRjgj:
        goto YxLQb;
        ntpxT:
        $this->Fhq5F->save();
        goto ZJNfz;
        HrDFy:
        $this->FGXTd->process($SKIcn);
        goto giYDe;
        yYNZJ:
        if (!(LlMDscQw21XKp::ENCODING_PROCESSED === $SKIcn)) {
            goto xyHBF;
        }
        goto ntpxT;
        EioxP:
        if (!(LlMDscQw21XKp::PROCESSING === $SKIcn)) {
            goto J7Ff2;
        }
        goto nv2Cr;
        giYDe:
        L1Uha:
        goto g7Xod;
        UQ_9R:
        if (!$this->FGXTd) {
            goto L1Uha;
        }
        goto HrDFy;
        m6RAq:
    }
    private function mtrakscr4gO()
    {
        goto ew6Eq;
        T1P7i:
        wpb1D:
        goto Pw_Z8;
        ew6Eq:
        switch ($this->Fhq5F->getType()) {
            case 'image':
                return new XbEcido52FH95($this->Fhq5F, $this->yvtQF);
            case 'video':
                return new KBMQV81FQOd78($this->Fhq5F, App::make(HYDAkFMesEGUF::class));
            default:
                return null;
        }
        goto TxIfT;
        TxIfT:
        UHfqZ:
        goto T1P7i;
        Pw_Z8:
    }
}
