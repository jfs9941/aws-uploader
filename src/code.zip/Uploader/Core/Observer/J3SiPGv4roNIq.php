<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Contracts\Cwggsm2UPkGtM;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\Strategy\Peo85prIGI36G;
use Jfs\Uploader\Core\Strategy\YYSxYxFU7hpvb;
use Jfs\Uploader\Encoder\Uql37EhjWaxp7;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Service\DkSooBIdtZWQo;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class J3SiPGv4roNIq implements Cwggsm2UPkGtM
{
    private $W2ZAM;
    private $R_58H;
    private $f1xKj;
    private $hYRvW;
    public function __construct($eQ4Ln, $C6boj, $as2bQ)
    {
        goto E8KJs;
        E8KJs:
        $this->R_58H = $eQ4Ln;
        goto QGmBD;
        QGmBD:
        $this->f1xKj = $C6boj;
        goto w3sbp;
        hNrzg:
        $this->W2ZAM = $this->mGqbEImsck5();
        goto gioUc;
        w3sbp:
        $this->hYRvW = $as2bQ;
        goto hNrzg;
        gioUc:
    }
    public function mFunvful2ao($QRp1M, $Y0Lou) : void
    {
        goto VvNrZ;
        VzB_3:
        $this->W2ZAM->process($Y0Lou);
        goto nH554;
        gAtv4:
        if (!(MUu80sOhINyO3::ENCODING_PROCESSED === $Y0Lou)) {
            goto nD9yg;
        }
        goto cL0tF;
        RVRQm:
        nD9yg:
        goto A964h;
        bmb_r:
        SFzQz:
        goto AEcgj;
        hdJe3:
        if (!$this->W2ZAM) {
            goto cXPGY;
        }
        goto VzB_3;
        cL0tF:
        $this->R_58H->save();
        goto hdJe3;
        ThfG4:
        $this->W2ZAM->process($Y0Lou);
        goto bmb_r;
        pqdkF:
        $this->R_58H->save();
        goto GDjze;
        AEcgj:
        p52jv:
        goto gAtv4;
        GDjze:
        if (!$this->W2ZAM) {
            goto SFzQz;
        }
        goto ThfG4;
        nH554:
        cXPGY:
        goto RVRQm;
        VvNrZ:
        if (!(MUu80sOhINyO3::PROCESSING === $Y0Lou)) {
            goto p52jv;
        }
        goto pqdkF;
        A964h:
    }
    private function mGqbEImsck5()
    {
        goto nzkHV;
        Cuic3:
        jn0In:
        goto vQLyu;
        A78G3:
        oXarJ:
        goto Cuic3;
        nzkHV:
        switch ($this->R_58H->getType()) {
            case 'image':
                return new Peo85prIGI36G($this->R_58H, $this->hYRvW);
            case 'video':
                return new YYSxYxFU7hpvb($this->R_58H, App::make(Uql37EhjWaxp7::class));
            default:
                return null;
        }
        goto A78G3;
        vQLyu:
    }
}
