<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Contracts\C3XDkOI7yIIoE;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
class GQA6vtRwd42pY implements C3XDkOI7yIIoE
{
    private $uq849;
    public function __construct($gNVOT)
    {
        $this->uq849 = $gNVOT;
    }
    public function mEE11OcGDDM($i2vqC, $Z8Kuq)
    {
        goto GaJhw;
        sJ6Zr:
        $this->uq849->save();
        goto dD4nn;
        iN7Ta:
        Kfpn8:
        goto sJ6Zr;
        Xd2Vu:
        $this->uq849->delete();
        goto vfsPr;
        GaJhw:
        if (!(EHhCBxlsVyz9C::UPLOADED === $Z8Kuq)) {
            goto d2DaD;
        }
        goto Pa4G9;
        C3u6j:
        if (!(EHhCBxlsVyz9C::DELETED === $Z8Kuq && $this->uq849->mO5zuxZvsQL())) {
            goto m6E69;
        }
        goto Xd2Vu;
        Pa4G9:
        $this->uq849->status = EHhCBxlsVyz9C::UPLOADED;
        goto kWnAb;
        dD4nn:
        d2DaD:
        goto C3u6j;
        kWnAb:
        if (!$this->uq849 instanceof KfEJaEGpFJ0tm) {
            goto Kfpn8;
        }
        goto KC2e8;
        KC2e8:
        $this->uq849->ml2jBQKKXoS(EHhCBxlsVyz9C::PROCESSING);
        goto iN7Ta;
        vfsPr:
        m6E69:
        goto bh2jM;
        bh2jM:
    }
}
