<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Contracts\YhOLLtTXuTxXo;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\Strategy\G5LJq9vrKLHzp;
use Jfs\Uploader\Core\Strategy\ILanuF1xXfBVW;
use Jfs\Uploader\Encoder\GfGClJX90DRBN;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Service\O64LTP0s3gT1J;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class HxI1l4gkv9iZP implements YhOLLtTXuTxXo
{
    private $ENZYB;
    private $i_qo1;
    private $huyLW;
    private $HsQc0;
    public function __construct($FJFJj, $A3hvZ, $RvoDa)
    {
        goto CLtKd;
        CLtKd:
        $this->i_qo1 = $FJFJj;
        goto u4lXx;
        u4lXx:
        $this->huyLW = $A3hvZ;
        goto fyVpT;
        fyVpT:
        $this->HsQc0 = $RvoDa;
        goto xmJNS;
        xmJNS:
        $this->ENZYB = $this->mIJIkgykK1p();
        goto dxBs8;
        dxBs8:
    }
    public function mW0P3SBpyXg($pin6L, $SPhmg) : void
    {
        goto LhS2R;
        LhS2R:
        if (!(EXecNg2hg7kwl::PROCESSING === $SPhmg)) {
            goto xj1pl;
        }
        goto P3cym;
        KYXwd:
        $this->ENZYB->process($SPhmg);
        goto tBjic;
        pkzUt:
        ujZES:
        goto PcVgo;
        PcVgo:
        xj1pl:
        goto H1pqW;
        tBjic:
        Cmi2K:
        goto fkKY_;
        XdKoX:
        if (!$this->ENZYB) {
            goto ujZES;
        }
        goto AmFc3;
        AmFc3:
        $this->ENZYB->process($SPhmg);
        goto pkzUt;
        P3cym:
        $this->i_qo1->save();
        goto XdKoX;
        XgI56:
        $this->i_qo1->save();
        goto rqHZY;
        rqHZY:
        if (!$this->ENZYB) {
            goto Cmi2K;
        }
        goto KYXwd;
        fkKY_:
        tdloo:
        goto B2qC3;
        H1pqW:
        if (!(EXecNg2hg7kwl::ENCODING_PROCESSED === $SPhmg)) {
            goto tdloo;
        }
        goto XgI56;
        B2qC3:
    }
    private function mIJIkgykK1p()
    {
        goto l6p1m;
        Fyhnr:
        UtETe:
        goto KuZXr;
        l6p1m:
        switch ($this->i_qo1->getType()) {
            case 'image':
                return new G5LJq9vrKLHzp($this->i_qo1, $this->HsQc0);
            case 'video':
                return new ILanuF1xXfBVW($this->i_qo1, App::make(GfGClJX90DRBN::class));
            default:
                return null;
        }
        goto gkYC4;
        gkYC4:
        aTYzp:
        goto Fyhnr;
        KuZXr:
    }
}
