<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Contracts\CPWst5X7YKGnu;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
class ZiVoxGfurmBI7 implements CPWst5X7YKGnu
{
    private $woTf1;
    public function __construct($oYtbp)
    {
        $this->woTf1 = $oYtbp;
    }
    public function mLulwBaR29t($gJXBQ, $snzZr)
    {
        goto UR0KH;
        XPzsm:
        $this->woTf1->delete();
        goto PM_Hz;
        GV1x0:
        $this->woTf1->status = OLX71luAn6XnP::UPLOADED;
        goto YDU4t;
        PM_Hz:
        OURe1:
        goto tbbhf;
        rSPkT:
        eAoXC:
        goto GIGyJ;
        YDU4t:
        if (!$this->woTf1 instanceof YPgQPiPQjMu1g) {
            goto WBxws;
        }
        goto UhpZD;
        GIGyJ:
        if (!(OLX71luAn6XnP::DELETED === $snzZr && $this->woTf1->mCum6Ew9zM7())) {
            goto OURe1;
        }
        goto XPzsm;
        Z83jf:
        $this->woTf1->save();
        goto rSPkT;
        UhpZD:
        $this->woTf1->m3irf1LtLKT(OLX71luAn6XnP::PROCESSING);
        goto uVyiT;
        UR0KH:
        if (!(OLX71luAn6XnP::UPLOADED === $snzZr)) {
            goto eAoXC;
        }
        goto GV1x0;
        uVyiT:
        WBxws:
        goto Z83jf;
        tbbhf:
    }
}
