<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\J6QUpUFjfs5mO;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Exception\GUt8ZmYbCCh9b;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Presigned\EbxR5lckHKhjV;
use Jfs\Uploader\Presigned\UiqC4G38nFu2J;
use Illuminate\Support\Facades\Log;
final class YwkS1y4Srg3M1 implements J6QUpUFjfs5mO
{
    private $TFzzE;
    private $W_NkT;
    private $yt19t;
    private $wKOGL;
    private $XbarW;
    public function __construct($araMZ, $RndMA, $luwqK, $YctT5, $mW4CT = false)
    {
        goto NW9D_;
        SDJ6e:
        $this->mljtJ3E6yNO();
        goto M_xoa;
        M_xoa:
        i3Fo3:
        goto KTU0l;
        W4nks:
        if ($mW4CT) {
            goto i3Fo3;
        }
        goto SDJ6e;
        fZx33:
        $this->yt19t = $RndMA;
        goto pmLp7;
        pmLp7:
        $this->wKOGL = $luwqK;
        goto VbOEJ;
        VbOEJ:
        $this->XbarW = $YctT5;
        goto W4nks;
        NW9D_:
        $this->W_NkT = $araMZ;
        goto fZx33;
        KTU0l:
    }
    private function mljtJ3E6yNO() : void
    {
        goto dCo1D;
        Iz6XM:
        return;
        goto QKGxd;
        IUte2:
        try {
            $zkqCI = $this->W_NkT->mf47A6FAs7u();
            $this->TFzzE = 's3' === $zkqCI->driver ? new UiqC4G38nFu2J($this->W_NkT, $this->yt19t, $this->wKOGL, $this->XbarW) : new EbxR5lckHKhjV($this->W_NkT, $this->yt19t, $this->wKOGL);
        } catch (Wu1EwEzrOvt3c $Jtg9A) {
            Log::warning("Failed to set up presigned upload: {$Jtg9A->getMessage()}");
        }
        goto waJ02;
        dCo1D:
        if (!(null !== $this->TFzzE)) {
            goto FmrKv;
        }
        goto Iz6XM;
        QKGxd:
        FmrKv:
        goto IUte2;
        waJ02:
    }
    public function mZjeUKxpiHv($BWos3, $wqzpN)
    {
        goto df00I;
        df00I:
        $this->mljtJ3E6yNO();
        goto Z89_D;
        Z89_D:
        switch ($wqzpN) {
            case EpMPhiTVzNYqA::UPLOADING:
                $this->mLtv29p4pFi();
                goto wC3Qs;
            case EpMPhiTVzNYqA::UPLOADED:
                $this->mmamY1mbYrf();
                goto wC3Qs;
            case EpMPhiTVzNYqA::ABORTED:
                $this->mEmmbx7sxIt();
                goto wC3Qs;
            default:
                goto wC3Qs;
        }
        goto usWPP;
        usWPP:
        xLgRI:
        goto auyiL;
        auyiL:
        wC3Qs:
        goto KP9vl;
        KP9vl:
    }
    private function mmamY1mbYrf() : void
    {
        goto gDKv6;
        gDKv6:
        $this->TFzzE->mR3MGYXUkcQ();
        goto rWKAp;
        H4sVM:
        if (!$dV9QE instanceof BG2FRpwGrKqJx) {
            goto Qu49P;
        }
        goto AsNpg;
        AsNpg:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($dV9QE->id);
        goto I7peD;
        rWKAp:
        $dV9QE = $this->W_NkT->getFile();
        goto MQzjS;
        mS2so:
        Qu49P:
        goto Tfbm1;
        I7peD:
        $dV9QE->mKd8O9TpYCH(EpMPhiTVzNYqA::PROCESSING);
        goto mS2so;
        MQzjS:
        $dV9QE->mKd8O9TpYCH(EpMPhiTVzNYqA::UPLOADED);
        goto H4sVM;
        Tfbm1:
    }
    private function mEmmbx7sxIt() : void
    {
        $this->TFzzE->mFzOOpO3hET();
    }
    private function mLtv29p4pFi() : void
    {
        $this->TFzzE->mFjyNjJ9bsc();
    }
}
