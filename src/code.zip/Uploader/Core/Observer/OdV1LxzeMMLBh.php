<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\DiGhNuHXqO8Po;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Exception\HA83jJulZGJMz;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Jfs\Uploader\Presigned\ZnBgxCEucBw3W;
use Jfs\Uploader\Presigned\DcxQi2vEwPmja;
final class OdV1LxzeMMLBh implements DiGhNuHXqO8Po
{
    private $T6PJK;
    private $lWNFo;
    private $OQTXf;
    private $TMwRg;
    private $HY2hW;
    public function __construct($WoRRL, $eL8cO, $phksh, $bqJVe, $vckS0 = false)
    {
        goto lQPo3;
        zV12K:
        $this->TMwRg = $phksh;
        goto HlyE2;
        RJ92_:
        $this->OQTXf = $eL8cO;
        goto zV12K;
        QXiZz:
        if ($vckS0) {
            goto li8Y7;
        }
        goto ndoL0;
        ga6g6:
        li8Y7:
        goto b_6jf;
        HlyE2:
        $this->HY2hW = $bqJVe;
        goto QXiZz;
        lQPo3:
        $this->lWNFo = $WoRRL;
        goto RJ92_;
        ndoL0:
        $this->moIU3krrUnA();
        goto ga6g6;
        b_6jf:
    }
    private function moIU3krrUnA() : void
    {
        goto xNL2b;
        cBxgO:
        try {
            $JFwxi = $this->lWNFo->m0Sl3pG3XHq();
            $this->T6PJK = 's3' === $JFwxi->H9HlK ? new DcxQi2vEwPmja($this->lWNFo, $this->OQTXf, $this->TMwRg, $this->HY2hW) : new ZnBgxCEucBw3W($this->lWNFo, $this->OQTXf, $this->TMwRg);
        } catch (YZ6TFg5btsXHA $sdtX4) {
            Log::warning("Failed to set up presigned upload: {$sdtX4->getMessage()}");
        }
        goto sjJgW;
        JzRzT:
        KzlKX:
        goto cBxgO;
        xNL2b:
        if (!(null !== $this->T6PJK)) {
            goto KzlKX;
        }
        goto B6Ir1;
        B6Ir1:
        return;
        goto JzRzT;
        sjJgW:
    }
    public function mA5gQsszPSr($IdyK1, $GYSAw)
    {
        goto z4BCY;
        CQfBC:
        dlLF3:
        goto FbPjX;
        c7Xza:
        switch ($GYSAw) {
            case U8OFutptQGm3S::UPLOADING:
                $this->m0Q3CO043Fj();
                goto dlLF3;
            case U8OFutptQGm3S::UPLOADED:
                $this->m4FkL2fp6uG();
                goto dlLF3;
            case U8OFutptQGm3S::ABORTED:
                $this->m47w8L8G3Bp();
                goto dlLF3;
            default:
                goto dlLF3;
        }
        goto MTj2V;
        MTj2V:
        I2kF7:
        goto CQfBC;
        z4BCY:
        $this->moIU3krrUnA();
        goto c7Xza;
        FbPjX:
    }
    private function m4FkL2fp6uG() : void
    {
        goto OqDlM;
        cKNzE:
        if (!$QxvEM instanceof QdnSnf08v9RV7) {
            goto Knp_H;
        }
        goto QUIUF;
        YGMur:
        $QxvEM->mZunb8ueiKo(U8OFutptQGm3S::UPLOADED);
        goto cKNzE;
        nobpF:
        Knp_H:
        goto NTQtJ;
        Mj0Oo:
        $QxvEM = $this->lWNFo->getFile();
        goto YGMur;
        QUIUF:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($QxvEM->id);
        goto nobpF;
        OqDlM:
        $this->T6PJK->m1tKpFKNKSo();
        goto Mj0Oo;
        NTQtJ:
    }
    private function m47w8L8G3Bp() : void
    {
        $this->T6PJK->mUJBWtzZQyJ();
    }
    private function m0Q3CO043Fj() : void
    {
        $this->T6PJK->moI8qdKlCV1();
    }
}
