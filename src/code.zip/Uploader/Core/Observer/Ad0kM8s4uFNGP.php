<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Contracts\M7qyTIw376zSo;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
class Ad0kM8s4uFNGP implements M7qyTIw376zSo
{
    private $VbAbt;
    public function __construct($s2INV)
    {
        $this->VbAbt = $s2INV;
    }
    public function mCd5SPJOmmA($kLpNi, $x9eDd)
    {
        goto LcWP0;
        wiPPx:
        $this->VbAbt->status = IOEDyer18cpSA::UPLOADED;
        goto tryQz;
        R9JuO:
        $this->VbAbt->delete();
        goto TisRZ;
        alj8y:
        wI6hj:
        goto a0w4_;
        gDoTL:
        $this->VbAbt->save();
        goto alj8y;
        LZkiF:
        p1NSr:
        goto gDoTL;
        a0w4_:
        if (!(IOEDyer18cpSA::DELETED === $x9eDd && $this->VbAbt->mqfU9GeIbE0())) {
            goto pboU2;
        }
        goto R9JuO;
        WUih_:
        $this->VbAbt->mImL6eGj9Ei(IOEDyer18cpSA::PROCESSING);
        goto LZkiF;
        tryQz:
        if (!$this->VbAbt instanceof MpPzMcfcRTISZ) {
            goto p1NSr;
        }
        goto WUih_;
        TisRZ:
        pboU2:
        goto YoqjK;
        LcWP0:
        if (!(IOEDyer18cpSA::UPLOADED === $x9eDd)) {
            goto wI6hj;
        }
        goto wiPPx;
        YoqjK:
    }
}
