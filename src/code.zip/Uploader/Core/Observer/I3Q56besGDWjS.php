<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\YhOLLtTXuTxXo;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Exception\JTzKeriqU61FK;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Presigned\JjXia9P5SW7Ks;
use Jfs\Uploader\Presigned\Vu57mjM1g6xEv;
use Illuminate\Support\Facades\Log;
final class I3Q56besGDWjS implements YhOLLtTXuTxXo
{
    private $A066p;
    private $lituY;
    private $IaFSl;
    private $QO2Ul;
    private $SmbHD;
    public function __construct($IXO6X, $B27Pk, $YzAw4, $l286D, $CDU44 = false)
    {
        goto fQALM;
        i0lLp:
        Rwp6B:
        goto tnz1F;
        WBc12:
        $this->SmbHD = $l286D;
        goto aLR0U;
        u6Wf2:
        $this->QO2Ul = $YzAw4;
        goto WBc12;
        fQALM:
        $this->lituY = $IXO6X;
        goto iHvqe;
        iHvqe:
        $this->IaFSl = $B27Pk;
        goto u6Wf2;
        ZJXy7:
        $this->m7AjVqhVv5U();
        goto i0lLp;
        aLR0U:
        if ($CDU44) {
            goto Rwp6B;
        }
        goto ZJXy7;
        tnz1F:
    }
    private function m7AjVqhVv5U() : void
    {
        goto PdoCu;
        PdoCu:
        if (!(null !== $this->A066p)) {
            goto CMZwU;
        }
        goto MrpF2;
        Bhfyg:
        try {
            $vOZNn = $this->lituY->m20XUNl7Aaq();
            $this->A066p = 's3' === $vOZNn->P5ZjQ ? new Vu57mjM1g6xEv($this->lituY, $this->IaFSl, $this->QO2Ul, $this->SmbHD) : new JjXia9P5SW7Ks($this->lituY, $this->IaFSl, $this->QO2Ul);
        } catch (B9AWimnd5WRl4 $vR5RQ) {
            Log::warning("Failed to set up presigned upload: {$vR5RQ->getMessage()}");
        }
        goto grV9W;
        MrpF2:
        return;
        goto n4yao;
        n4yao:
        CMZwU:
        goto Bhfyg;
        grV9W:
    }
    public function mW0P3SBpyXg($pin6L, $SPhmg)
    {
        goto od3KQ;
        fEx2z:
        gZg0s:
        goto ejRWh;
        P6gpW:
        switch ($SPhmg) {
            case EXecNg2hg7kwl::UPLOADING:
                $this->mXUU4yhLo1B();
                goto gZg0s;
            case EXecNg2hg7kwl::UPLOADED:
                $this->mVuc6x7xsg9();
                goto gZg0s;
            case EXecNg2hg7kwl::ABORTED:
                $this->moHMmLGzrvd();
                goto gZg0s;
            default:
                goto gZg0s;
        }
        goto xjbFR;
        od3KQ:
        $this->m7AjVqhVv5U();
        goto P6gpW;
        xjbFR:
        NNfcy:
        goto fEx2z;
        ejRWh:
    }
    private function mVuc6x7xsg9() : void
    {
        goto DYDTH;
        t19xA:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($FJFJj->id);
        goto w2Iuf;
        DYDTH:
        $this->A066p->m1kTEjhiqBw();
        goto yfoTo;
        yfoTo:
        $FJFJj = $this->lituY->getFile();
        goto jaQvD;
        f1TBE:
        if (!$FJFJj instanceof RhSx2q5xIlh0Y) {
            goto GF9Bs;
        }
        goto t19xA;
        w2Iuf:
        GF9Bs:
        goto swrRj;
        jaQvD:
        $FJFJj->m7ddHwazacD(EXecNg2hg7kwl::UPLOADED);
        goto f1TBE;
        swrRj:
    }
    private function moHMmLGzrvd() : void
    {
        $this->A066p->miOIHr1YHeY();
    }
    private function mXUU4yhLo1B() : void
    {
        $this->A066p->mq1QIPo5NbE();
    }
}
