<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Contracts\OrgzWokuJzoYp;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Core\Strategy\D04ZxkoEWr2bW;
use Jfs\Uploader\Core\Strategy\EkejkvKggGkoO;
use Jfs\Uploader\Encoder\Saum77EIMVl09;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Service\NzkrkFhIBihmO;
final class MPRhglOgVUwL1 implements OrgzWokuJzoYp
{
    private $OVxY8;
    private $CqvUz;
    private $GQuun;
    private $u0rqC;
    public function __construct($ezBDN, $Q0shJ, $XGlwJ)
    {
        goto VjAIz;
        A0Kd7:
        $this->u0rqC = $XGlwJ;
        goto U7rYL;
        VjAIz:
        $this->CqvUz = $ezBDN;
        goto nk1_H;
        nk1_H:
        $this->GQuun = $Q0shJ;
        goto A0Kd7;
        U7rYL:
        $this->OVxY8 = $this->mCFljAOXr6M();
        goto tdbtR;
        tdbtR:
    }
    public function mjE8og0hkAa($upN77, $LB0Yo) : void
    {
        goto Vnp5C;
        yGQq4:
        if (!(N4CY6qDTBAjPa::ENCODING_PROCESSED === $LB0Yo)) {
            goto XpQcZ;
        }
        goto fIaDl;
        UO1w1:
        if (!$this->OVxY8) {
            goto JyPOx;
        }
        goto jLzeC;
        hjRaB:
        $this->OVxY8->process($LB0Yo);
        goto vBMQU;
        DGQO3:
        JyPOx:
        goto qFuv8;
        qFuv8:
        XpQcZ:
        goto jxxl0;
        PXdWJ:
        if (!$this->OVxY8) {
            goto ktSpc;
        }
        goto hjRaB;
        vBMQU:
        ktSpc:
        goto IjhJ3;
        fIaDl:
        $this->CqvUz->save();
        goto UO1w1;
        MDjnl:
        $this->CqvUz->save();
        goto PXdWJ;
        jLzeC:
        $this->OVxY8->process($LB0Yo);
        goto DGQO3;
        Vnp5C:
        if (!(N4CY6qDTBAjPa::PROCESSING === $LB0Yo)) {
            goto J6wHG;
        }
        goto MDjnl;
        IjhJ3:
        J6wHG:
        goto yGQq4;
        jxxl0:
    }
    private function mCFljAOXr6M()
    {
        goto bpBVQ;
        CvzuH:
        wohdm:
        goto KzEH6;
        bpBVQ:
        switch ($this->CqvUz->getType()) {
            case 'image':
                return new D04ZxkoEWr2bW($this->CqvUz, $this->u0rqC);
            case 'video':
                return new EkejkvKggGkoO($this->CqvUz, App::make(Saum77EIMVl09::class));
            default:
                return null;
        }
        goto iymfX;
        iymfX:
        wOTVD:
        goto CvzuH;
        KzEH6:
    }
}
