<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\IYQ9W9yMaFIDi;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Exception\FLUrTiCUjjZmC;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Presigned\UoPsg9jKCGJ9D;
use Jfs\Uploader\Presigned\UN18LnxnRahWb;
use Illuminate\Support\Facades\Log;
final class ZxZBwkj5ZHKJj implements IYQ9W9yMaFIDi
{
    private $GWrBm;
    private $Ym0Fe;
    private $pXh9P;
    private $Tfy0l;
    private $VzV90;
    public function __construct($k0UDg, $TWZho, $bnvNm, $v4kIW, $Kjd3W = false)
    {
        goto PbuyT;
        HM_bQ:
        $this->pXh9P = $TWZho;
        goto GfSYx;
        GfSYx:
        $this->Tfy0l = $bnvNm;
        goto uTqP5;
        OOSIR:
        EFgSX:
        goto SJjIT;
        R1sUN:
        $this->mV8yrq9l8cw();
        goto OOSIR;
        PbuyT:
        $this->Ym0Fe = $k0UDg;
        goto HM_bQ;
        LwZzk:
        if ($Kjd3W) {
            goto EFgSX;
        }
        goto R1sUN;
        uTqP5:
        $this->VzV90 = $v4kIW;
        goto LwZzk;
        SJjIT:
    }
    private function mV8yrq9l8cw() : void
    {
        goto KoWBS;
        KoWBS:
        if (!(null !== $this->GWrBm)) {
            goto qD1so;
        }
        goto dh7Lp;
        dh7Lp:
        return;
        goto EVAtS;
        QGAmh:
        try {
            $bsvnL = $this->Ym0Fe->mzbGvZW3SMF();
            $this->GWrBm = 's3' === $bsvnL->pb8PJ ? new UN18LnxnRahWb($this->Ym0Fe, $this->pXh9P, $this->Tfy0l, $this->VzV90) : new UoPsg9jKCGJ9D($this->Ym0Fe, $this->pXh9P, $this->Tfy0l);
        } catch (Jcm0L35ZiDWQ6 $jupeT) {
            Log::warning("Failed to set up presigned upload: {$jupeT->getMessage()}");
        }
        goto t8uKV;
        EVAtS:
        qD1so:
        goto QGAmh;
        t8uKV:
    }
    public function mX3kB2cejfz($CvLh2, $AOQvb)
    {
        goto QI7rS;
        QI7rS:
        $this->mV8yrq9l8cw();
        goto pzIq9;
        As3hn:
        QQKkL:
        goto cYycI;
        pzIq9:
        switch ($AOQvb) {
            case TSfaBZEUMcbl0::UPLOADING:
                $this->mzvhi5e7PdS();
                goto A_7fS;
            case TSfaBZEUMcbl0::UPLOADED:
                $this->mkVT8K5DirI();
                goto A_7fS;
            case TSfaBZEUMcbl0::ABORTED:
                $this->mAzGQjdftB4();
                goto A_7fS;
            default:
                goto A_7fS;
        }
        goto As3hn;
        cYycI:
        A_7fS:
        goto iNRM2;
        iNRM2:
    }
    private function mkVT8K5DirI() : void
    {
        goto jsj36;
        jsj36:
        $this->GWrBm->mGCUSudE8Jd();
        goto C0eiY;
        C0eiY:
        $ZPsYd = $this->Ym0Fe->getFile();
        goto iUJuy;
        UpZjg:
        FRQ01:
        goto RPEew;
        oiweR:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($ZPsYd->id);
        goto UpZjg;
        iUJuy:
        $ZPsYd->mvj3nnnI629(TSfaBZEUMcbl0::UPLOADED);
        goto pE5Ew;
        pE5Ew:
        if (!$ZPsYd instanceof NYx4mhlHSMgHF) {
            goto FRQ01;
        }
        goto oiweR;
        RPEew:
    }
    private function mAzGQjdftB4() : void
    {
        $this->GWrBm->mxuapcvaHCE();
    }
    private function mzvhi5e7PdS() : void
    {
        $this->GWrBm->mJyhvrcvYWY();
    }
}
