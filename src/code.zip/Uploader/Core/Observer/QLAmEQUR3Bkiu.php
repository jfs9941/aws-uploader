<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Contracts\Pr07JVh1ChqJO;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
class QLAmEQUR3Bkiu implements Pr07JVh1ChqJO
{
    private $MhOEp;
    public function __construct($RB3Ub)
    {
        $this->MhOEp = $RB3Ub;
    }
    public function mI8wqsETHZd($zgXzD, $BmlMb)
    {
        goto Gx1Sa;
        Gx1Sa:
        if (!(Fsm7WCrUwVWh9::UPLOADED === $BmlMb)) {
            goto aIZp8;
        }
        goto qXkNj;
        qXkNj:
        $this->MhOEp->status = Fsm7WCrUwVWh9::UPLOADED;
        goto YToPe;
        YToPe:
        if (!$this->MhOEp instanceof C6ftQJKUZRJIp) {
            goto xF71s;
        }
        goto N4OJH;
        BOwvJ:
        aIZp8:
        goto xOmtG;
        bzS1d:
        $this->MhOEp->delete();
        goto SsB3J;
        SsB3J:
        jrvdS:
        goto z_8WR;
        N4OJH:
        $this->MhOEp->mtyCvJ3PeFW(Fsm7WCrUwVWh9::PROCESSING);
        goto MCMCT;
        Krb8q:
        $this->MhOEp->save();
        goto BOwvJ;
        MCMCT:
        xF71s:
        goto Krb8q;
        xOmtG:
        if (!(Fsm7WCrUwVWh9::DELETED === $BmlMb && $this->MhOEp->m9tEY4AMtzK())) {
            goto jrvdS;
        }
        goto bzS1d;
        z_8WR:
    }
}
