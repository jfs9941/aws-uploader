<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Xg08pDZLenaCo;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Exception\SlPIHqOmIQ9pI;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Presigned\XdPJzQAWBAhHp;
use Jfs\Uploader\Presigned\NIKyHyRRRDzv4;
use Illuminate\Support\Facades\Log;
final class LCw0aGmgH8xAz implements Xg08pDZLenaCo
{
    private $GcLYW;
    private $EBcoC;
    private $TD3CW;
    private $Ht28P;
    private $nmHDC;
    public function __construct($N1xft, $e3uVO, $cUbzi, $wIlgi, $HzqcW = false)
    {
        goto mCvg8;
        h8Scg:
        $this->TD3CW = $e3uVO;
        goto A6y8F;
        H6hb2:
        if ($HzqcW) {
            goto qm4QY;
        }
        goto DaQxT;
        hOETb:
        qm4QY:
        goto HoqtD;
        DaQxT:
        $this->mF8tSlRRAnz();
        goto hOETb;
        A6y8F:
        $this->Ht28P = $cUbzi;
        goto gI_tP;
        mCvg8:
        $this->EBcoC = $N1xft;
        goto h8Scg;
        gI_tP:
        $this->nmHDC = $wIlgi;
        goto H6hb2;
        HoqtD:
    }
    private function mF8tSlRRAnz() : void
    {
        goto W4xeY;
        W4xeY:
        if (!(null !== $this->GcLYW)) {
            goto Q3CmE;
        }
        goto eRkSC;
        eRkSC:
        return;
        goto xThn1;
        xThn1:
        Q3CmE:
        goto sC14a;
        sC14a:
        try {
            $abL5U = $this->EBcoC->mw6tRR1NtWf();
            $this->GcLYW = 's3' === $abL5U->driver ? new NIKyHyRRRDzv4($this->EBcoC, $this->TD3CW, $this->Ht28P, $this->nmHDC) : new XdPJzQAWBAhHp($this->EBcoC, $this->TD3CW, $this->Ht28P);
        } catch (MNuvuj1rJR1Zc $wEHhy) {
            Log::warning("Failed to set up presigned upload: {$wEHhy->getMessage()}");
        }
        goto nHtp1;
        nHtp1:
    }
    public function mnTJmPCq3BW($gAEvi, $G7Qtb)
    {
        goto DAcux;
        DAcux:
        $this->mF8tSlRRAnz();
        goto L04QE;
        mBHe1:
        XuTbb:
        goto Fcs70;
        L04QE:
        switch ($G7Qtb) {
            case Zgh3BZ2JVlG1A::UPLOADING:
                $this->mF79c8A7eW4();
                goto OvJDI;
            case Zgh3BZ2JVlG1A::UPLOADED:
                $this->m0FLfKTk0Xr();
                goto OvJDI;
            case Zgh3BZ2JVlG1A::ABORTED:
                $this->mMLBk8yYSY7();
                goto OvJDI;
            default:
                goto OvJDI;
        }
        goto mBHe1;
        Fcs70:
        OvJDI:
        goto vT4EB;
        vT4EB:
    }
    private function m0FLfKTk0Xr() : void
    {
        goto FyFMD;
        ieAU_:
        if (!$D55CH instanceof AelPShnd8pMtD) {
            goto SBwIu;
        }
        goto UjjIW;
        pqOdM:
        SBwIu:
        goto s8hjH;
        lV_W0:
        $D55CH->mKP20BPk5QC(Zgh3BZ2JVlG1A::UPLOADED);
        goto ieAU_;
        jRqDn:
        $D55CH = $this->EBcoC->getFile();
        goto lV_W0;
        NjsaM:
        $D55CH->mKP20BPk5QC(Zgh3BZ2JVlG1A::PROCESSING);
        goto pqOdM;
        UjjIW:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($D55CH->id);
        goto NjsaM;
        FyFMD:
        $this->GcLYW->mSJsdVCHEX6();
        goto jRqDn;
        s8hjH:
    }
    private function mMLBk8yYSY7() : void
    {
        $this->GcLYW->mNbyeDUf9J3();
    }
    private function mF79c8A7eW4() : void
    {
        $this->GcLYW->mRdlHlaN15F();
    }
}
