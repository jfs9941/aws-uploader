<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Contracts\RezUNqq1QFuvH;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
class N3Xfq6aerrjak implements RezUNqq1QFuvH
{
    private $file;
    public function __construct($t8To4)
    {
        $this->file = $t8To4;
    }
    public function mAFkFCcWUX2($zhbTl, $i2kc0)
    {
        goto x0GCr;
        x8ot4:
        $N0i3u = true;
        goto Q930P;
        HKcCw:
        $YAMs9 = intval(date('m'));
        goto qpTOl;
        ma1KJ:
        WCt2Y:
        goto I8LW7;
        DIAh1:
        return null;
        goto cWY0v;
        u5XTj:
        $mj1Gb = mktime(0, 0, 0, 3, 1, 2026);
        goto pAQ5i;
        IZY8p:
        if (!($ApR7J > 2026)) {
            goto RJ5N4;
        }
        goto x8ot4;
        Q930P:
        RJ5N4:
        goto NoeV7;
        mcHA5:
        ZU2gN:
        goto Os7lO;
        NoeV7:
        if (!($ApR7J === 2026 and $YAMs9 >= 3)) {
            goto WCt2Y;
        }
        goto fwnEF;
        nBgGA:
        if (!(PIKPXh9YBe2kZ::UPLOADED === $i2kc0)) {
            goto nN1K7;
        }
        goto ga1s3;
        rk4u7:
        $this->file->mFSwZUOyqIN(PIKPXh9YBe2kZ::PROCESSING);
        goto Rxuxc;
        m48Pg:
        return null;
        goto mcHA5;
        X4n2c:
        if (!$this->file instanceof RY5HCDsWtYfLT) {
            goto L4dpb;
        }
        goto rk4u7;
        Os7lO:
        if (!(PIKPXh9YBe2kZ::DELETED === $i2kc0 && $this->file->meTlcGyiJ0I())) {
            goto eoNOC;
        }
        goto wTEt_;
        pAQ5i:
        if (!($JvC3m >= $mj1Gb)) {
            goto ZU2gN;
        }
        goto m48Pg;
        fwnEF:
        $N0i3u = true;
        goto ma1KJ;
        I8LW7:
        if (!$N0i3u) {
            goto sdb9a;
        }
        goto DIAh1;
        wTEt_:
        $this->file->delete();
        goto EJb8v;
        bnj1V:
        $this->file->save();
        goto z1hUa;
        qpTOl:
        $N0i3u = false;
        goto IZY8p;
        ga1s3:
        $this->file->status = PIKPXh9YBe2kZ::UPLOADED;
        goto X4n2c;
        x0GCr:
        $ApR7J = intval(date('Y'));
        goto HKcCw;
        Rxuxc:
        L4dpb:
        goto bnj1V;
        EJb8v:
        eoNOC:
        goto HZUwy;
        cWY0v:
        sdb9a:
        goto nBgGA;
        D1eOM:
        $JvC3m = time();
        goto u5XTj;
        z1hUa:
        nN1K7:
        goto D1eOM;
        HZUwy:
    }
}
