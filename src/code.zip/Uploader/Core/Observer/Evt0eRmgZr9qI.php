<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Contracts\D1gefDsblgSHh;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\Strategy\Y1vKZhg9rdEht;
use Jfs\Uploader\Core\Strategy\ILG12mcvVSGIA;
use Jfs\Uploader\Encoder\AhS2r9oThLsk4;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Service\CU3MKrDqwc6OY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Evt0eRmgZr9qI implements D1gefDsblgSHh
{
    private $Xh7VT;
    private $XHy23;
    private $D9Jo8;
    private $H5Cq0;
    public function __construct($pemjO, $v1Edp, $KzVpB)
    {
        goto fAoRI;
        Jszw0:
        $this->H5Cq0 = $KzVpB;
        goto gbgQT;
        gbgQT:
        $this->Xh7VT = $this->m9JS69UKw25();
        goto iC_9v;
        fAoRI:
        $this->XHy23 = $pemjO;
        goto lmK9e;
        lmK9e:
        $this->D9Jo8 = $v1Edp;
        goto Jszw0;
        iC_9v:
    }
    public function mop1CVR7YoY($olf3Q, $Iv88p) : void
    {
        goto eg4IX;
        Ggxed:
        if (!$this->Xh7VT) {
            goto LuxXT;
        }
        goto huYus;
        eNHoS:
        zTjVH:
        goto H0BvR;
        KBzu6:
        if (!(IOOvAXAyKHLW2::ENCODING_PROCESSED === $Iv88p)) {
            goto zTjVH;
        }
        goto h_Jv2;
        NHPrJ:
        $this->XHy23->save();
        goto Ggxed;
        BzEXT:
        KPeSR:
        goto eNHoS;
        h_Jv2:
        $this->XHy23->save();
        goto aUYVH;
        eg4IX:
        if (!(IOOvAXAyKHLW2::PROCESSING === $Iv88p)) {
            goto MytJk;
        }
        goto NHPrJ;
        slJpB:
        MytJk:
        goto KBzu6;
        LBvbB:
        $this->Xh7VT->process($Iv88p);
        goto BzEXT;
        PM5Zm:
        LuxXT:
        goto slJpB;
        huYus:
        $this->Xh7VT->process($Iv88p);
        goto PM5Zm;
        aUYVH:
        if (!$this->Xh7VT) {
            goto KPeSR;
        }
        goto LBvbB;
        H0BvR:
    }
    private function m9JS69UKw25()
    {
        goto msTz0;
        SPkm_:
        dm279:
        goto ParNY;
        msTz0:
        switch ($this->XHy23->getType()) {
            case 'image':
                return new Y1vKZhg9rdEht($this->XHy23, $this->H5Cq0);
            case 'video':
                return new ILG12mcvVSGIA($this->XHy23, App::make(AhS2r9oThLsk4::class));
            default:
                return null;
        }
        goto KqmvP;
        KqmvP:
        leqOt:
        goto SPkm_;
        ParNY:
    }
}
