<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Contracts\StateChangeObserverInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\FileInterface;
use Jfs\Uploader\Core\Strategy\PostProcessForImage;
use Jfs\Uploader\Core\Strategy\PostProcessForVideo;
use Jfs\Uploader\Encoder\HlsPathResolver;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Service\MediaPathResolver;

final class FileProcessingObserver implements StateChangeObserverInterface
{
    private $strategy;

    private $file;
    private $s3;
    private $options;

    /**
     * @param FileInterface|FileStateInterface|BaseFileModel $file
     * @param Filesystem                                     $s3
     * @param array                                          $options
     */
    public function __construct(
        $file,
        $s3,
        $options,
    ) {
        $this->file = $file;
        $this->s3 = $s3;
        $this->options = $options;
        $this->strategy = $this->createStrategy();
    }

    public function onStateChange($fromState, $toState): void
    {
        if (FileStatus::PROCESSING === $toState) {
            $this->file->save();
            if ($this->strategy) {
                $this->strategy->process($toState);
            }
        }
        if (FileStatus::ENCODING_PROCESSED === $toState) {
            $this->file->save();
            if ($this->strategy) {
                $this->strategy->process($toState);
            }
        }
    }

    private function createStrategy()
    {
        switch ($this->file->getType()) {
            case 'image':
                return new PostProcessForImage($this->file, $this->options);
            case 'video':
                return new PostProcessForVideo(
                    $this->file,
                    App::make(HlsPathResolver::class),
                );
            default:
                return null;
        }
    }
}
