<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Contracts\PzqA3QfUmhhMJ;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\Strategy\Lm3B5LKAsQZRC;
use Jfs\Uploader\Core\Strategy\A4HSggH2qUo1l;
use Jfs\Uploader\Encoder\K98g74EXAn8Vy;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Service\A7wFfsLiK9DEe;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class F4rYz9eUIaudx implements PzqA3QfUmhhMJ
{
    private $LwIT4;
    private $N1jgO;
    private $YHwpp;
    private $yy6J0;
    public function __construct($Ga9Xm, $ehLvI, $hNsac)
    {
        goto j8P44;
        j9XgP:
        $this->yy6J0 = $hNsac;
        goto EiF50;
        j8P44:
        $this->N1jgO = $Ga9Xm;
        goto NwPwf;
        EiF50:
        $this->LwIT4 = $this->mFbulWWGiQg();
        goto R163L;
        NwPwf:
        $this->YHwpp = $ehLvI;
        goto j9XgP;
        R163L:
    }
    public function mjTwbCJOfRB($L51Zi, $IoGt4) : void
    {
        goto HshYM;
        Ubjwm:
        if (!$this->LwIT4) {
            goto fM04Q;
        }
        goto hgcrZ;
        hgcrZ:
        $this->LwIT4->process($IoGt4);
        goto l40uy;
        eN7kQ:
        LXYUv:
        goto VJ2u1;
        MVG8E:
        if (!(HGmeWpZQSxAlO::ENCODING_PROCESSED === $IoGt4)) {
            goto LXYUv;
        }
        goto vhrwW;
        g8pay:
        if (!$this->LwIT4) {
            goto mRkg0;
        }
        goto RhXaK;
        rM8Am:
        mRkg0:
        goto WiMox;
        vhrwW:
        $this->N1jgO->save();
        goto Ubjwm;
        RhXaK:
        $this->LwIT4->process($IoGt4);
        goto rM8Am;
        WiMox:
        OZSCi:
        goto MVG8E;
        wEWjL:
        $this->N1jgO->save();
        goto g8pay;
        l40uy:
        fM04Q:
        goto eN7kQ;
        HshYM:
        if (!(HGmeWpZQSxAlO::PROCESSING === $IoGt4)) {
            goto OZSCi;
        }
        goto wEWjL;
        VJ2u1:
    }
    private function mFbulWWGiQg()
    {
        goto sL5mi;
        Qpvy_:
        LcW44:
        goto DWaNQ;
        DWaNQ:
        uKAz9:
        goto NwYiV;
        sL5mi:
        switch ($this->N1jgO->getType()) {
            case 'image':
                return new Lm3B5LKAsQZRC($this->N1jgO, $this->yy6J0);
            case 'video':
                return new A4HSggH2qUo1l($this->N1jgO, App::make(K98g74EXAn8Vy::class));
            default:
                return null;
        }
        goto Qpvy_;
        NwYiV:
    }
}
