<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Contracts\Hj8CabiR8LqsR;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Core\Strategy\MY6QY4nW4dXFz;
use Jfs\Uploader\Core\Strategy\FvgmOVFDAvWzC;
use Jfs\Uploader\Encoder\PBaAMCftTA2PY;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Service\ZKiz9aeWXGIZz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class T1IY0RFpO9tB3 implements Hj8CabiR8LqsR
{
    private $fHwiE;
    private $bilhr;
    private $rSfnv;
    private $GSMFK;
    public function __construct($qFMlx, $uIWH1, $H3592)
    {
        goto z1IOk;
        oZryB:
        $this->rSfnv = $uIWH1;
        goto TTHQ2;
        TTHQ2:
        $this->GSMFK = $H3592;
        goto ZDzDp;
        ZDzDp:
        $this->fHwiE = $this->my5KG8eV6ts();
        goto RqAz8;
        z1IOk:
        $this->bilhr = $qFMlx;
        goto oZryB;
        RqAz8:
    }
    public function mGYJEzjTKty($cadqL, $BEIOn) : void
    {
        goto eIAXW;
        nR3Yd:
        $this->fHwiE->process($BEIOn);
        goto QWeQ6;
        PENKr:
        Yap9Y:
        goto Mg1s0;
        jmtxl:
        HoVKw:
        goto OEKkw;
        dblsc:
        $this->bilhr->save();
        goto BWsAy;
        FWNzs:
        $this->fHwiE->process($BEIOn);
        goto HOseF;
        CLdTO:
        if (!$this->fHwiE) {
            goto rLfrz;
        }
        goto FWNzs;
        FJKB8:
        $this->bilhr->save();
        goto CLdTO;
        OEKkw:
        if (!(A7CVlqbpzhfLD::ENCODING_PROCESSED === $BEIOn)) {
            goto Yap9Y;
        }
        goto FJKB8;
        QWeQ6:
        adLD0:
        goto jmtxl;
        BWsAy:
        if (!$this->fHwiE) {
            goto adLD0;
        }
        goto nR3Yd;
        eIAXW:
        if (!(A7CVlqbpzhfLD::PROCESSING === $BEIOn)) {
            goto HoVKw;
        }
        goto dblsc;
        HOseF:
        rLfrz:
        goto PENKr;
        Mg1s0:
    }
    private function my5KG8eV6ts()
    {
        goto qt1t3;
        JfadX:
        kjSTR:
        goto WCy1z;
        qt1t3:
        switch ($this->bilhr->getType()) {
            case 'image':
                return new MY6QY4nW4dXFz($this->bilhr, $this->GSMFK);
            case 'video':
                return new FvgmOVFDAvWzC($this->bilhr, App::make(PBaAMCftTA2PY::class));
            default:
                return null;
        }
        goto UAfu9;
        UAfu9:
        WG98X:
        goto JfadX;
        WCy1z:
    }
}
