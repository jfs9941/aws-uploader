<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\UGfAXCSEERPE4;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Exception\R2XNcytHoXlGH;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Presigned\SMLjySwy2Oxi2;
use Jfs\Uploader\Presigned\TzZR4LqjnuAXX;
use Illuminate\Support\Facades\Log;
final class Ap6OmMu8ktKtp implements UGfAXCSEERPE4
{
    private $g0RW3;
    private $ImZI2;
    private $W2Sfl;
    private $dMiJj;
    private $omjLi;
    public function __construct($RHBLn, $d_Wiu, $F17Nf, $O893k, $JBjWk = false)
    {
        goto Q1LfO;
        NrtGU:
        $this->mUd1ALKDXOj();
        goto wxcpC;
        LD4qD:
        $this->W2Sfl = $d_Wiu;
        goto Oh_Ed;
        OdQfg:
        if ($JBjWk) {
            goto KNMpW;
        }
        goto NrtGU;
        Q1LfO:
        $this->ImZI2 = $RHBLn;
        goto LD4qD;
        YgOhW:
        $this->omjLi = $O893k;
        goto OdQfg;
        wxcpC:
        KNMpW:
        goto kosRw;
        Oh_Ed:
        $this->dMiJj = $F17Nf;
        goto YgOhW;
        kosRw:
    }
    private function mUd1ALKDXOj() : void
    {
        goto WOlIQ;
        uWTOm:
        uxfhy:
        goto E8E8m;
        E8E8m:
        try {
            $fK0e7 = $this->ImZI2->mAOwHvxkwWq();
            $this->g0RW3 = 's3' === $fK0e7->euRQL ? new TzZR4LqjnuAXX($this->ImZI2, $this->W2Sfl, $this->dMiJj, $this->omjLi) : new SMLjySwy2Oxi2($this->ImZI2, $this->W2Sfl, $this->dMiJj);
        } catch (NCCpOFnEetEh7 $bIOBo) {
            Log::warning("Failed to set up presigned upload: {$bIOBo->getMessage()}");
        }
        goto J5MdP;
        qZFZB:
        return;
        goto uWTOm;
        WOlIQ:
        if (!(null !== $this->g0RW3)) {
            goto uxfhy;
        }
        goto qZFZB;
        J5MdP:
    }
    public function mj4xpscl4k5($DOhs8, $vQwbX)
    {
        goto CtJwS;
        hdUKD:
        switch ($vQwbX) {
            case LV0wDYHZInswq::UPLOADING:
                $this->mQYjw0aOycx();
                goto cINAv;
            case LV0wDYHZInswq::UPLOADED:
                $this->mW1KHkDzir7();
                goto cINAv;
            case LV0wDYHZInswq::ABORTED:
                $this->m3piT8Qp2zu();
                goto cINAv;
            default:
                goto cINAv;
        }
        goto v0P8W;
        VqivZ:
        cINAv:
        goto z75yB;
        CtJwS:
        $this->mUd1ALKDXOj();
        goto hdUKD;
        v0P8W:
        Q7rNp:
        goto VqivZ;
        z75yB:
    }
    private function mW1KHkDzir7() : void
    {
        goto QwNwT;
        ystmh:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($YfsmL->id);
        goto Ta3tN;
        Eehgt:
        $YfsmL = $this->ImZI2->getFile();
        goto xnkVT;
        xnkVT:
        $YfsmL->mWYAL72rhSp(LV0wDYHZInswq::UPLOADED);
        goto L7UrT;
        Ta3tN:
        qxno4:
        goto XFdX8;
        QwNwT:
        $this->g0RW3->mgn0m4kZaFh();
        goto Eehgt;
        L7UrT:
        if (!$YfsmL instanceof U9HMl0N8dP0ZH) {
            goto qxno4;
        }
        goto ystmh;
        XFdX8:
    }
    private function m3piT8Qp2zu() : void
    {
        $this->g0RW3->msracQGonfo();
    }
    private function mQYjw0aOycx() : void
    {
        $this->g0RW3->miOPwul7xEs();
    }
}
