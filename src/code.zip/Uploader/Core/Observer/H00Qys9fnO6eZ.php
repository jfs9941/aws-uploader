<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Contracts\J6QUpUFjfs5mO;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
class H00Qys9fnO6eZ implements J6QUpUFjfs5mO
{
    private $pnMmg;
    public function __construct($dV9QE)
    {
        $this->pnMmg = $dV9QE;
    }
    public function mZjeUKxpiHv($BWos3, $wqzpN)
    {
        goto ptQEE;
        j57L_:
        $this->pnMmg->mKd8O9TpYCH(EpMPhiTVzNYqA::PROCESSING);
        goto nMi2W;
        KMu0Y:
        YcxpI:
        goto Md_lf;
        SBznJ:
        $this->pnMmg->status = EpMPhiTVzNYqA::UPLOADED;
        goto tMlAZ;
        tMlAZ:
        if (!$this->pnMmg instanceof XK5kReLMTU1ob) {
            goto TzPQN;
        }
        goto j57L_;
        Md_lf:
        if (!(EpMPhiTVzNYqA::DELETED === $wqzpN && $this->pnMmg->mrX3HV0mmnR())) {
            goto mRfh5;
        }
        goto I1frh;
        nMi2W:
        TzPQN:
        goto xNi24;
        BKMFa:
        mRfh5:
        goto DW1L9;
        xNi24:
        $this->pnMmg->save();
        goto KMu0Y;
        ptQEE:
        if (!(EpMPhiTVzNYqA::UPLOADED === $wqzpN)) {
            goto YcxpI;
        }
        goto SBznJ;
        I1frh:
        $this->pnMmg->delete();
        goto BKMFa;
        DW1L9:
    }
}
