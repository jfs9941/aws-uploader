<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\YZqPZlzFpJfK6;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Exception\F8y1xdPRStgQx;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Presigned\GK5kJAmqOQKA8;
use Jfs\Uploader\Presigned\LjAgPhObx7wlI;
use Illuminate\Support\Facades\Log;
final class DwX8kmn6uBEGI implements YZqPZlzFpJfK6
{
    private $v9SIT;
    private $sxfrv;
    private $BX0zD;
    private $lIJMo;
    private $p_blM;
    public function __construct($Gauo2, $MKJ1D, $niM9V, $b7Jn7, $i1h3l = false)
    {
        goto OqkYf;
        Z9AYT:
        if ($i1h3l) {
            goto vqdxB;
        }
        goto siWk_;
        siWk_:
        $this->mNd6RWM58fG();
        goto Bee1S;
        vTEr6:
        $this->p_blM = $b7Jn7;
        goto Z9AYT;
        Ep2tP:
        $this->lIJMo = $niM9V;
        goto vTEr6;
        OqkYf:
        $this->sxfrv = $Gauo2;
        goto kUDOm;
        kUDOm:
        $this->BX0zD = $MKJ1D;
        goto Ep2tP;
        Bee1S:
        vqdxB:
        goto G2Gai;
        G2Gai:
    }
    private function mNd6RWM58fG() : void
    {
        goto Q1HzL;
        EDHiM:
        try {
            $bxW1r = $this->sxfrv->mU5hpD7riBK();
            $this->v9SIT = 's3' === $bxW1r->J42hQ ? new LjAgPhObx7wlI($this->sxfrv, $this->BX0zD, $this->lIJMo, $this->p_blM) : new GK5kJAmqOQKA8($this->sxfrv, $this->BX0zD, $this->lIJMo);
        } catch (RRuZixuGIQD7H $Fa7Tp) {
            Log::warning("Failed to set up presigned upload: {$Fa7Tp->getMessage()}");
        }
        goto z6bwU;
        hI72R:
        return;
        goto HwfkX;
        Q1HzL:
        if (!(null !== $this->v9SIT)) {
            goto x8xXi;
        }
        goto hI72R;
        HwfkX:
        x8xXi:
        goto EDHiM;
        z6bwU:
    }
    public function mqIsZMsLGwg($Hr7H_, $ddv_R)
    {
        goto bt7Dq;
        bt7Dq:
        $this->mNd6RWM58fG();
        goto n1VoD;
        C6ZPF:
        u6sqZ:
        goto tFZjj;
        n1VoD:
        switch ($ddv_R) {
            case ZVJoOgH14iXBq::UPLOADING:
                $this->myxZ7w5aXfv();
                goto ZRXPM;
            case ZVJoOgH14iXBq::UPLOADED:
                $this->m24G4QWeBzh();
                goto ZRXPM;
            case ZVJoOgH14iXBq::ABORTED:
                $this->miRSeYzeYsS();
                goto ZRXPM;
            default:
                goto ZRXPM;
        }
        goto C6ZPF;
        tFZjj:
        ZRXPM:
        goto VY6zE;
        VY6zE:
    }
    private function m24G4QWeBzh() : void
    {
        goto Ibrzk;
        Ibrzk:
        $this->v9SIT->myrPRPm7Nb8();
        goto qhkAx;
        H5Gu_:
        if (!$ZQzpf instanceof HVuLZHLrSam0d) {
            goto r1LG6;
        }
        goto ZlYNF;
        y9VKx:
        $ZQzpf->mzoKjbCd8Ap(ZVJoOgH14iXBq::UPLOADED);
        goto H5Gu_;
        SqIfg:
        r1LG6:
        goto ZJ6HO;
        ZlYNF:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($ZQzpf->id);
        goto SqIfg;
        qhkAx:
        $ZQzpf = $this->sxfrv->getFile();
        goto y9VKx;
        ZJ6HO:
    }
    private function miRSeYzeYsS() : void
    {
        $this->v9SIT->ml8hDFcte5I();
    }
    private function myxZ7w5aXfv() : void
    {
        $this->v9SIT->m3iQcvvYamH();
    }
}
