<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\M7qyTIw376zSo;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Exception\VwJ7WJWdWWDDp;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Presigned\WdafpxvCj8TAh;
use Jfs\Uploader\Presigned\La2OUL49noiRe;
use Illuminate\Support\Facades\Log;
final class SEO3V0HfirU17 implements M7qyTIw376zSo
{
    private $BlEcs;
    private $vHhJT;
    private $c5PSU;
    private $RGW8z;
    private $GCETN;
    public function __construct($TUNr2, $Ape3_, $Dm30C, $wiZGO, $qEZOW = false)
    {
        goto cNNKu;
        Qwv_5:
        $this->GCETN = $wiZGO;
        goto UfXRr;
        cNNKu:
        $this->vHhJT = $TUNr2;
        goto ru8dF;
        Al5ko:
        $this->RGW8z = $Dm30C;
        goto Qwv_5;
        ru8dF:
        $this->c5PSU = $Ape3_;
        goto Al5ko;
        UfXRr:
        if ($qEZOW) {
            goto WjxME;
        }
        goto IOKmE;
        IOKmE:
        $this->mkxaPpcDu8c();
        goto iAJBf;
        iAJBf:
        WjxME:
        goto zAWg4;
        zAWg4:
    }
    private function mkxaPpcDu8c() : void
    {
        goto F07sg;
        ErjLk:
        return;
        goto wtpMH;
        IPFYc:
        try {
            $j1WQY = $this->vHhJT->muUg8to4YNh();
            $this->BlEcs = 's3' === $j1WQY->nP7o5 ? new La2OUL49noiRe($this->vHhJT, $this->c5PSU, $this->RGW8z, $this->GCETN) : new WdafpxvCj8TAh($this->vHhJT, $this->c5PSU, $this->RGW8z);
        } catch (XEcmSsCY89ji0 $z6tFS) {
            Log::warning("Failed to set up presigned upload: {$z6tFS->getMessage()}");
        }
        goto LI4dQ;
        wtpMH:
        LDWyt:
        goto IPFYc;
        F07sg:
        if (!(null !== $this->BlEcs)) {
            goto LDWyt;
        }
        goto ErjLk;
        LI4dQ:
    }
    public function mCd5SPJOmmA($kLpNi, $x9eDd)
    {
        goto pekzs;
        IFI8B:
        switch ($x9eDd) {
            case IOEDyer18cpSA::UPLOADING:
                $this->m5nulXdXgAV();
                goto t7S1h;
            case IOEDyer18cpSA::UPLOADED:
                $this->mB7oy2LuLAf();
                goto t7S1h;
            case IOEDyer18cpSA::ABORTED:
                $this->mE7XNozP5cz();
                goto t7S1h;
            default:
                goto t7S1h;
        }
        goto QOQLG;
        QOQLG:
        cdF1a:
        goto REos8;
        pekzs:
        $this->mkxaPpcDu8c();
        goto IFI8B;
        REos8:
        t7S1h:
        goto opU9Z;
        opU9Z:
    }
    private function mB7oy2LuLAf() : void
    {
        goto usGdb;
        KtOYT:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($s2INV->id);
        goto JY9U5;
        yVPZt:
        $s2INV->mImL6eGj9Ei(IOEDyer18cpSA::UPLOADED);
        goto vUzMS;
        NnZTR:
        $s2INV = $this->vHhJT->getFile();
        goto yVPZt;
        usGdb:
        $this->BlEcs->m70IYXIfVKq();
        goto NnZTR;
        vUzMS:
        if (!$s2INV instanceof IfBHv1AJhiIDu) {
            goto MC2fL;
        }
        goto KtOYT;
        JY9U5:
        MC2fL:
        goto w3Ltr;
        w3Ltr:
    }
    private function mE7XNozP5cz() : void
    {
        $this->BlEcs->mnz8JEKyXsH();
    }
    private function m5nulXdXgAV() : void
    {
        $this->BlEcs->me4pj6MGrcy();
    }
}
