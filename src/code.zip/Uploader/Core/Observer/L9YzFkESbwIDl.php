<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Hj8CabiR8LqsR;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Exception\CIAjwsRYu6S6e;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Presigned\Oti4jm6zrOnwi;
use Jfs\Uploader\Presigned\T0GFMTxoWASOt;
use Illuminate\Support\Facades\Log;
final class L9YzFkESbwIDl implements Hj8CabiR8LqsR
{
    private $j7GWb;
    private $NHvEy;
    private $unMfk;
    private $x5SUA;
    private $petAu;
    public function __construct($m3Blp, $L32kE, $j3j3G, $RiWpQ, $ie2cf = false)
    {
        goto dTbXI;
        HQ6Y0:
        Q3EKc:
        goto IDaaa;
        tbX1_:
        $this->unMfk = $L32kE;
        goto MdpFG;
        dTbXI:
        $this->NHvEy = $m3Blp;
        goto tbX1_;
        AtGKK:
        $this->mNVoYJQzl9J();
        goto HQ6Y0;
        MdpFG:
        $this->x5SUA = $j3j3G;
        goto PgjwH;
        Y9IBF:
        if ($ie2cf) {
            goto Q3EKc;
        }
        goto AtGKK;
        PgjwH:
        $this->petAu = $RiWpQ;
        goto Y9IBF;
        IDaaa:
    }
    private function mNVoYJQzl9J() : void
    {
        goto F2HXi;
        tVtA0:
        TpWyN:
        goto HfQQh;
        F2HXi:
        if (!(null !== $this->j7GWb)) {
            goto TpWyN;
        }
        goto Ci4on;
        HfQQh:
        try {
            $wEH2f = $this->NHvEy->mYn06Pxlq0m();
            $this->j7GWb = 's3' === $wEH2f->Fd5Pz ? new T0GFMTxoWASOt($this->NHvEy, $this->unMfk, $this->x5SUA, $this->petAu) : new Oti4jm6zrOnwi($this->NHvEy, $this->unMfk, $this->x5SUA);
        } catch (B5gPy0GuqF3TT $dhJHu) {
            Log::warning("Failed to set up presigned upload: {$dhJHu->getMessage()}");
        }
        goto c7vem;
        Ci4on:
        return;
        goto tVtA0;
        c7vem:
    }
    public function mGYJEzjTKty($cadqL, $BEIOn)
    {
        goto GDmMU;
        RhG5t:
        qTn64:
        goto XK0O7;
        XK0O7:
        ygyR2:
        goto zhOvU;
        GDmMU:
        $this->mNVoYJQzl9J();
        goto xYpg6;
        xYpg6:
        switch ($BEIOn) {
            case A7CVlqbpzhfLD::UPLOADING:
                $this->me5Ex35WDNF();
                goto ygyR2;
            case A7CVlqbpzhfLD::UPLOADED:
                $this->mVekSW9zGh2();
                goto ygyR2;
            case A7CVlqbpzhfLD::ABORTED:
                $this->mvr30rwLk1Z();
                goto ygyR2;
            default:
                goto ygyR2;
        }
        goto RhG5t;
        zhOvU:
    }
    private function mVekSW9zGh2() : void
    {
        goto gIn2N;
        BTRAz:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($qFMlx->id);
        goto EPl2r;
        DtXbL:
        if (!$qFMlx instanceof N1wF7eNF4lYgo) {
            goto UuuYj;
        }
        goto BTRAz;
        gIn2N:
        $this->j7GWb->m5cVukL3XfZ();
        goto QbK1n;
        QbK1n:
        $qFMlx = $this->NHvEy->getFile();
        goto EfkR3;
        EfkR3:
        $qFMlx->m1WocvV9yZy(A7CVlqbpzhfLD::UPLOADED);
        goto DtXbL;
        EPl2r:
        UuuYj:
        goto OBtem;
        OBtem:
    }
    private function mvr30rwLk1Z() : void
    {
        $this->j7GWb->mo0bnXSNhQX();
    }
    private function me5Ex35WDNF() : void
    {
        $this->j7GWb->mzGVYtZieUh();
    }
}
