<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Contracts\I2OiS2IsDF9Mg;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
class CoATXhCrVwYZs implements I2OiS2IsDF9Mg
{
    private $tEOkh;
    public function __construct($nbWJE)
    {
        $this->tEOkh = $nbWJE;
    }
    public function me0Vk27dOzU($OdVJN, $Ws7p7)
    {
        goto jFMaJ;
        OE0ET:
        $this->tEOkh->status = H7dtWZ2h5WAty::UPLOADED;
        goto rTw3E;
        rTw3E:
        if (!$this->tEOkh instanceof IQJN6V0t7DC7c) {
            goto OWQcN;
        }
        goto FbZcE;
        FbZcE:
        $this->tEOkh->mI0VzEtubJR(H7dtWZ2h5WAty::PROCESSING);
        goto MUUEu;
        MUUEu:
        OWQcN:
        goto iyqHs;
        WUU90:
        iGCX0:
        goto WDx16;
        QnQoD:
        if (!(H7dtWZ2h5WAty::DELETED === $Ws7p7 && $this->tEOkh->mjqr2YfBynI())) {
            goto iGCX0;
        }
        goto HTFCP;
        iyqHs:
        $this->tEOkh->save();
        goto TF7p6;
        HTFCP:
        $this->tEOkh->delete();
        goto WUU90;
        jFMaJ:
        if (!(H7dtWZ2h5WAty::UPLOADED === $Ws7p7)) {
            goto jdFeR;
        }
        goto OE0ET;
        TF7p6:
        jdFeR:
        goto QnQoD;
        WDx16:
    }
}
