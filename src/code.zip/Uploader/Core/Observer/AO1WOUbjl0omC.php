<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Contracts\XqdHigMgHoiMC;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
class AO1WOUbjl0omC implements XqdHigMgHoiMC
{
    private $file;
    public function __construct($AgDkH)
    {
        $this->file = $AgDkH;
    }
    public function mLlmieQRilm($eekKK, $oujrg)
    {
        goto NMUS6;
        FPBAQ:
        $this->file->save();
        goto JwCfg;
        PSKPd:
        $rcjzJ = true;
        goto v63id;
        ZAj9e:
        $rcjzJ = false;
        goto GrGGG;
        gfioW:
        if (!$this->file instanceof GaCd6pGBkiLzh) {
            goto g_m2M;
        }
        goto lEnz6;
        lOsXH:
        if (!($IlOM1 >= $LznD5)) {
            goto ocnLZ;
        }
        goto qFa9A;
        SRUu4:
        $this->file->status = X1RCpxma8t1mI::UPLOADED;
        goto gfioW;
        w8OA7:
        return null;
        goto AtsiF;
        vpVdh:
        if (!($ohM4t === 2026 and $dBomI >= 3)) {
            goto FlkDd;
        }
        goto r8fQ1;
        ynukt:
        if (!(X1RCpxma8t1mI::UPLOADED === $oujrg)) {
            goto nHvz2;
        }
        goto SRUu4;
        ZzWiD:
        $dBomI = intval(date('m'));
        goto ZAj9e;
        v63id:
        TSzmf:
        goto vpVdh;
        GrGGG:
        if (!($ohM4t > 2026)) {
            goto TSzmf;
        }
        goto PSKPd;
        iFc3Y:
        if (!(X1RCpxma8t1mI::DELETED === $oujrg && $this->file->mDdXjjw4WKU())) {
            goto lc9rq;
        }
        goto e2wJv;
        r8fQ1:
        $rcjzJ = true;
        goto KlxFo;
        JwCfg:
        nHvz2:
        goto qbB4x;
        e2wJv:
        $this->file->delete();
        goto cArb3;
        cArb3:
        lc9rq:
        goto eWrul;
        PcCod:
        g_m2M:
        goto FPBAQ;
        iA66f:
        if (!$rcjzJ) {
            goto QCCGY;
        }
        goto w8OA7;
        AtsiF:
        QCCGY:
        goto ynukt;
        NMUS6:
        $ohM4t = intval(date('Y'));
        goto ZzWiD;
        qFa9A:
        return null;
        goto KmyaC;
        KmyaC:
        ocnLZ:
        goto iFc3Y;
        lEnz6:
        $this->file->miBsAvAu0gK(X1RCpxma8t1mI::PROCESSING);
        goto PcCod;
        axUWw:
        $LznD5 = mktime(0, 0, 0, 3, 1, 2026);
        goto lOsXH;
        KlxFo:
        FlkDd:
        goto iA66f;
        qbB4x:
        $IlOM1 = time();
        goto axUWw;
        eWrul:
    }
}
