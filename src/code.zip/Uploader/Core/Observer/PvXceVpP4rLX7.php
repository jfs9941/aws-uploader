<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\ZcCh1gvC4ktYJ;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Exception\VPhlMhTTl80vP;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Presigned\VuuOKLIFqi3f5;
use Jfs\Uploader\Presigned\RhprxoVBNrHDN;
use Illuminate\Support\Facades\Log;
final class PvXceVpP4rLX7 implements ZcCh1gvC4ktYJ
{
    private $UcCCE;
    private $JWVa8;
    private $SIeOC;
    private $s7iRq;
    private $PoRf3;
    public function __construct($wfCxx, $Ay4fJ, $UC1Qe, $L2yxk, $RNUYl = false)
    {
        goto wx7Fm;
        r_Oz1:
        if ($RNUYl) {
            goto WCvQd;
        }
        goto xJxIz;
        xJxIz:
        $this->maUodpKNsNl();
        goto tZI_m;
        wx7Fm:
        $this->JWVa8 = $wfCxx;
        goto LKZzU;
        fhMFX:
        $this->s7iRq = $UC1Qe;
        goto W8xwh;
        W8xwh:
        $this->PoRf3 = $L2yxk;
        goto r_Oz1;
        tZI_m:
        WCvQd:
        goto SXAZM;
        LKZzU:
        $this->SIeOC = $Ay4fJ;
        goto fhMFX;
        SXAZM:
    }
    private function maUodpKNsNl() : void
    {
        goto GV0dh;
        XWJkb:
        dlQAt:
        goto psCzc;
        psCzc:
        try {
            $CLKCW = $this->JWVa8->mvAZkBgf9bv();
            $this->UcCCE = 's3' === $CLKCW->driver ? new RhprxoVBNrHDN($this->JWVa8, $this->SIeOC, $this->s7iRq, $this->PoRf3) : new VuuOKLIFqi3f5($this->JWVa8, $this->SIeOC, $this->s7iRq);
        } catch (Q2lfI5IWmjyoJ $bAo2Y) {
            Log::warning("Failed to set up presigned upload: {$bAo2Y->getMessage()}");
        }
        goto n65Vz;
        GV0dh:
        if (!(null !== $this->UcCCE)) {
            goto dlQAt;
        }
        goto PSzVv;
        PSzVv:
        return;
        goto XWJkb;
        n65Vz:
    }
    public function mauAugSr89M($WZdil, $VdQLY)
    {
        goto b4Ggx;
        fMzBz:
        gg_VL:
        goto X9txM;
        b4Ggx:
        $this->maUodpKNsNl();
        goto CeJCZ;
        v84kt:
        bHOSV:
        goto fMzBz;
        CeJCZ:
        switch ($VdQLY) {
            case ZP6Ky842t6y9Y::UPLOADING:
                $this->mIYpijAV8ty();
                goto gg_VL;
            case ZP6Ky842t6y9Y::UPLOADED:
                $this->m65RLAkdVvc();
                goto gg_VL;
            case ZP6Ky842t6y9Y::ABORTED:
                $this->mudAKXxyFh3();
                goto gg_VL;
            default:
                goto gg_VL;
        }
        goto v84kt;
        X9txM:
    }
    private function m65RLAkdVvc() : void
    {
        goto IAnsv;
        V4hGV:
        $YEF57->mddb9WvMqo9(ZP6Ky842t6y9Y::PROCESSING);
        goto I8jK5;
        AgSoY:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($YEF57->id);
        goto V4hGV;
        IAnsv:
        $this->UcCCE->mNOO3VgsKs7();
        goto EV6Bz;
        CaCoA:
        if (!$YEF57 instanceof JPkW9ix1EKo3T) {
            goto QtJG1;
        }
        goto AgSoY;
        EV6Bz:
        $YEF57 = $this->JWVa8->getFile();
        goto AkPBn;
        I8jK5:
        QtJG1:
        goto NND6R;
        AkPBn:
        $YEF57->mddb9WvMqo9(ZP6Ky842t6y9Y::UPLOADED);
        goto CaCoA;
        NND6R:
    }
    private function mudAKXxyFh3() : void
    {
        $this->UcCCE->mAOPUkkIZjS();
    }
    private function mIYpijAV8ty() : void
    {
        $this->UcCCE->m009zDRe4t4();
    }
}
