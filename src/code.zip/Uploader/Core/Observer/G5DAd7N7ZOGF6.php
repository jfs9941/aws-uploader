<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Contracts\ObP0zC4B5AwYR;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
class G5DAd7N7ZOGF6 implements ObP0zC4B5AwYR
{
    private $file;
    public function __construct($Z1rIR)
    {
        $this->file = $Z1rIR;
    }
    public function mjDXRGNQTxn($Dqtza, $oEcw2)
    {
        goto e7S1t;
        BhyNU:
        if (!($UFJAR >= $x8Byz)) {
            goto w3ouO;
        }
        goto kbDzx;
        jHdIo:
        $this->file->miTV603ASKT(CTJGrzH3klS5t::PROCESSING);
        goto NvYKd;
        XjxqO:
        $this->file->save();
        goto Ai5EU;
        pKGU_:
        if (!(CTJGrzH3klS5t::UPLOADED === $oEcw2)) {
            goto Ngwpw;
        }
        goto nv7lv;
        NvYKd:
        fcedU:
        goto XjxqO;
        bpwuo:
        if (!$this->file instanceof Z6wulfe2yOVew) {
            goto fcedU;
        }
        goto jHdIo;
        b8N3k:
        w3ouO:
        goto pKGU_;
        MFUqX:
        $this->file->delete();
        goto DL1xI;
        e7S1t:
        $UFJAR = time();
        goto WNQR7;
        WNQR7:
        $x8Byz = mktime(0, 0, 0, 3, 1, 2026);
        goto BhyNU;
        Ai5EU:
        Ngwpw:
        goto nyP33;
        kbDzx:
        return null;
        goto b8N3k;
        DL1xI:
        B_exK:
        goto FdHQF;
        nyP33:
        if (!(CTJGrzH3klS5t::DELETED === $oEcw2 && $this->file->mXvemDsvBvf())) {
            goto B_exK;
        }
        goto MFUqX;
        nv7lv:
        $this->file->status = CTJGrzH3klS5t::UPLOADED;
        goto bpwuo;
        FdHQF:
    }
}
