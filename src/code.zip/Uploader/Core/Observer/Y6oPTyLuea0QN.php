<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Contracts\Hj8CabiR8LqsR;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
class Y6oPTyLuea0QN implements Hj8CabiR8LqsR
{
    private $bilhr;
    public function __construct($qFMlx)
    {
        $this->bilhr = $qFMlx;
    }
    public function mGYJEzjTKty($cadqL, $BEIOn)
    {
        goto gMjta;
        Xn5eo:
        if (!$this->bilhr instanceof UG34Yjmf7IsbQ) {
            goto S1u22;
        }
        goto ZoZ3h;
        kurnG:
        if (!(A7CVlqbpzhfLD::DELETED === $BEIOn && $this->bilhr->mDzSbKe5mdW())) {
            goto N6QEn;
        }
        goto lrypo;
        eK4AA:
        $this->bilhr->save();
        goto mewbF;
        bh534:
        N6QEn:
        goto kahXc;
        VV4Dw:
        $this->bilhr->status = A7CVlqbpzhfLD::UPLOADED;
        goto Xn5eo;
        mewbF:
        D4f3B:
        goto kurnG;
        aFFI3:
        S1u22:
        goto eK4AA;
        lrypo:
        $this->bilhr->delete();
        goto bh534;
        ZoZ3h:
        $this->bilhr->m1WocvV9yZy(A7CVlqbpzhfLD::PROCESSING);
        goto aFFI3;
        gMjta:
        if (!(A7CVlqbpzhfLD::UPLOADED === $BEIOn)) {
            goto D4f3B;
        }
        goto VV4Dw;
        kahXc:
    }
}
