<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Contracts\GMMSgBcs5XImF;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Core\Strategy\Mo0a6PsC9oEmS;
use Jfs\Uploader\Core\Strategy\BNcvnnCm19MAK;
use Jfs\Uploader\Encoder\QTx5zGpV1D5nP;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Service\B9bpWG3g8Q6mz;
final class RnNnPMo6r46rb implements GMMSgBcs5XImF
{
    private $HhdVL;
    private $PxcXo;
    private $zTo0t;
    private $tHKs2;
    public function __construct($VZzWw, $Vi8xq, $kEeaF)
    {
        goto k0kzJ;
        kvjYN:
        $this->HhdVL = $this->mg8saVFYbFH();
        goto txyoh;
        lFcqE:
        $this->tHKs2 = $kEeaF;
        goto kvjYN;
        ZsOXu:
        $this->zTo0t = $Vi8xq;
        goto lFcqE;
        k0kzJ:
        $this->PxcXo = $VZzWw;
        goto ZsOXu;
        txyoh:
    }
    public function mJdFuAPL4o5($a6p_S, $xM562) : void
    {
        goto UAQeR;
        Q9lqP:
        qRMnW:
        goto leNnl;
        n_72q:
        $this->PxcXo->save();
        goto BxxL0;
        BxxL0:
        if (!$this->HhdVL) {
            goto pXX8C;
        }
        goto JRdBI;
        mDAYX:
        pGdUe:
        goto gTinn;
        leNnl:
        T95F8:
        goto X_ET1;
        JRdBI:
        $this->HhdVL->process($xM562);
        goto PFhCd;
        P4PxU:
        if (!$this->HhdVL) {
            goto qRMnW;
        }
        goto ROVu_;
        UAQeR:
        if (!(EUkqoDwU9Zcvh::PROCESSING === $xM562)) {
            goto T95F8;
        }
        goto yBu52;
        PFhCd:
        pXX8C:
        goto mDAYX;
        yBu52:
        $this->PxcXo->save();
        goto P4PxU;
        ROVu_:
        $this->HhdVL->process($xM562);
        goto Q9lqP;
        X_ET1:
        if (!(EUkqoDwU9Zcvh::ENCODING_PROCESSED === $xM562)) {
            goto pGdUe;
        }
        goto n_72q;
        gTinn:
    }
    private function mg8saVFYbFH()
    {
        goto p1qbS;
        p1qbS:
        switch ($this->PxcXo->getType()) {
            case 'image':
                return new Mo0a6PsC9oEmS($this->PxcXo, $this->tHKs2);
            case 'video':
                return new BNcvnnCm19MAK($this->PxcXo, App::make(QTx5zGpV1D5nP::class));
            default:
                return null;
        }
        goto TGvRE;
        TGvRE:
        iNPcH:
        goto B2EJL;
        B2EJL:
        pH4Xc:
        goto c8oxn;
        c8oxn:
    }
}
