<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Observer;

use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Contracts\A2uS8gTe46deJ;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\Strategy\X06SPblPLaeGZ;
use backup\Uploader\Core\Strategy\F0HDJNDWfyyZy;
use backup\Uploader\Encoder\LZk9dEYagFbfv;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Service\HgXaT629cXC5e;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class MxWo1C1itIr69 implements A2uS8gTe46deJ
{
    private $Dz9ld;
    private $i31Dp;
    private $kEfMA;
    private $WIBpk;
    public function __construct($eVZrJ, $FP6ih, $FxiIj)
    {
        goto rHYRG;
        wFR1Q:
        $this->Dz9ld = $this->m5oFobKDiD9();
        goto d4NjI;
        rHYRG:
        $this->i31Dp = $eVZrJ;
        goto EEWOy;
        EEWOy:
        $this->kEfMA = $FP6ih;
        goto WBJmB;
        WBJmB:
        $this->WIBpk = $FxiIj;
        goto wFR1Q;
        d4NjI:
    }
    public function mI9DhQKSU08($SGfNF, $SIscU) : void
    {
        goto h9_2Q;
        ALqFk:
        TVhHw:
        goto Xfe0B;
        ZK3kV:
        $this->i31Dp->save();
        goto Ou783;
        gqXbu:
        $this->Dz9ld->process($SIscU);
        goto NsP9F;
        rmRqr:
        if (!$this->Dz9ld) {
            goto YqfWe;
        }
        goto gqXbu;
        MGRHR:
        $this->i31Dp->save();
        goto rmRqr;
        Ou783:
        if (!$this->Dz9ld) {
            goto TVhHw;
        }
        goto eYomC;
        NsP9F:
        YqfWe:
        goto FWSc_;
        FWSc_:
        yiAvO:
        goto hFK3T;
        xhLK2:
        if (!(Aetm2HiFuJE34::ENCODING_PROCESSED === $SIscU)) {
            goto yiAvO;
        }
        goto MGRHR;
        eYomC:
        $this->Dz9ld->process($SIscU);
        goto ALqFk;
        Xfe0B:
        CsCTE:
        goto xhLK2;
        h9_2Q:
        if (!(Aetm2HiFuJE34::PROCESSING === $SIscU)) {
            goto CsCTE;
        }
        goto ZK3kV;
        hFK3T:
    }
    private function m5oFobKDiD9()
    {
        goto q87D1;
        vTJWc:
        BRBoP:
        goto hiyGR;
        q87D1:
        switch ($this->i31Dp->getType()) {
            case 'image':
                return new X06SPblPLaeGZ($this->i31Dp, $this->WIBpk);
            case 'video':
                return new F0HDJNDWfyyZy($this->i31Dp, App::make(LZk9dEYagFbfv::class));
            default:
                return null;
        }
        goto vTJWc;
        hiyGR:
        CaiYC:
        goto i6Q6P;
        i6Q6P:
    }
}
