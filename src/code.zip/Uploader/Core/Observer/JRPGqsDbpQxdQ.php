<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Contracts\A1DrGQVhPKB54;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
class JRPGqsDbpQxdQ implements A1DrGQVhPKB54
{
    private $EidfR;
    public function __construct($clm2Y)
    {
        $this->EidfR = $clm2Y;
    }
    public function mhxhZPnjNPV($zS2qB, $jAyD6)
    {
        goto Y2nGJ;
        rAWuZ:
        if (!$this->EidfR instanceof U0IzvN2kaLZHI) {
            goto BJoeJ;
        }
        goto UT4EU;
        XRNYD:
        BJoeJ:
        goto t6tDZ;
        UT4EU:
        $this->EidfR->mfzy7DteKHJ(KidkTsWIjmNMb::PROCESSING);
        goto XRNYD;
        t6tDZ:
        $this->EidfR->save();
        goto PFpi5;
        mLMEs:
        $this->EidfR->status = KidkTsWIjmNMb::UPLOADED;
        goto rAWuZ;
        Y2nGJ:
        if (!(KidkTsWIjmNMb::UPLOADED === $jAyD6)) {
            goto D1J8t;
        }
        goto mLMEs;
        MgmSI:
        $this->EidfR->delete();
        goto Iec94;
        PFpi5:
        D1J8t:
        goto ukB2Z;
        Iec94:
        QElAB:
        goto gWkLN;
        ukB2Z:
        if (!(KidkTsWIjmNMb::DELETED === $jAyD6 && $this->EidfR->mISFTPpP69d())) {
            goto QElAB;
        }
        goto MgmSI;
        gWkLN:
    }
}
