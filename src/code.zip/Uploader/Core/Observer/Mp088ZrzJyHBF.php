<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Contracts\DiGhNuHXqO8Po;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Core\Strategy\MWKk1M4JTPinv;
use Jfs\Uploader\Core\Strategy\UpCfKVoDThtSx;
use Jfs\Uploader\Encoder\MquUYPN1EJDdI;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Service\JrqDsqkHsYBsl;
final class Mp088ZrzJyHBF implements DiGhNuHXqO8Po
{
    private $DyCqj;
    private $a2FAI;
    private $RaPnW;
    private $nAcVF;
    public function __construct($QxvEM, $hTkyv, $xBmsh)
    {
        goto iXBMe;
        GSubv:
        $this->RaPnW = $hTkyv;
        goto B6U61;
        B6U61:
        $this->nAcVF = $xBmsh;
        goto paINv;
        paINv:
        $this->DyCqj = $this->mBlVjZ5wNaP();
        goto Dt_wg;
        iXBMe:
        $this->a2FAI = $QxvEM;
        goto GSubv;
        Dt_wg:
    }
    public function mA5gQsszPSr($IdyK1, $GYSAw) : void
    {
        goto YVmgZ;
        rptcA:
        NENKC:
        goto Iw6ws;
        rSUpI:
        if (!(U8OFutptQGm3S::ENCODING_PROCESSED === $GYSAw)) {
            goto LXAe3;
        }
        goto DzwuM;
        meo8X:
        $this->a2FAI->save();
        goto G27CI;
        EDR91:
        LXAe3:
        goto Hn8bp;
        YVmgZ:
        if (!(U8OFutptQGm3S::PROCESSING === $GYSAw)) {
            goto sG1Yr;
        }
        goto meo8X;
        Iw6ws:
        sG1Yr:
        goto rSUpI;
        gz1fU:
        $this->DyCqj->process($GYSAw);
        goto rptcA;
        sO9Qx:
        $this->DyCqj->process($GYSAw);
        goto gwZGU;
        G27CI:
        if (!$this->DyCqj) {
            goto NENKC;
        }
        goto gz1fU;
        SkBfG:
        if (!$this->DyCqj) {
            goto I2SU5;
        }
        goto sO9Qx;
        DzwuM:
        $this->a2FAI->save();
        goto SkBfG;
        gwZGU:
        I2SU5:
        goto EDR91;
        Hn8bp:
    }
    private function mBlVjZ5wNaP()
    {
        goto jJEAy;
        jJEAy:
        switch ($this->a2FAI->getType()) {
            case 'image':
                return new MWKk1M4JTPinv($this->a2FAI, $this->nAcVF);
            case 'video':
                return new UpCfKVoDThtSx($this->a2FAI, App::make(MquUYPN1EJDdI::class));
            default:
                return null;
        }
        goto yABFe;
        yABFe:
        H4IIu:
        goto qk8x1;
        qk8x1:
        Yd9Oa:
        goto DmkpF;
        DmkpF:
    }
}
