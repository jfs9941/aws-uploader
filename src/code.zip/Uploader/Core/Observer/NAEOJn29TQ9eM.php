<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Contracts\TjZC83Yv3rOXg;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\Strategy\CAauJWIO9Pclr;
use Jfs\Uploader\Core\Strategy\BZm8VQKCy3Ezl;
use Jfs\Uploader\Encoder\V6kCroy78Tmzg;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Service\PzfoMEiZi5U2a;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class NAEOJn29TQ9eM implements TjZC83Yv3rOXg
{
    private $XNeds;
    private $HyWI1;
    private $VoF9h;
    private $RX1is;
    public function __construct($hFrf7, $BQ2l1, $sjhjO)
    {
        goto WUMnO;
        o4vDI:
        $this->XNeds = $this->mQKjKyOpJrF();
        goto P82gp;
        K7VOT:
        $this->RX1is = $sjhjO;
        goto o4vDI;
        uGVWP:
        $this->VoF9h = $BQ2l1;
        goto K7VOT;
        WUMnO:
        $this->HyWI1 = $hFrf7;
        goto uGVWP;
        P82gp:
    }
    public function mOZ7C9ggFcs($YJZDm, $ge2j8) : void
    {
        goto ezSTE;
        IcJ7O:
        $this->HyWI1->save();
        goto NClil;
        Jmc1K:
        if (!(FdWrko7bmoI4Y::ENCODING_PROCESSED === $ge2j8)) {
            goto ENazv;
        }
        goto IcJ7O;
        do1h6:
        if (!$this->XNeds) {
            goto myZgW;
        }
        goto FGbfC;
        FGbfC:
        $this->XNeds->process($ge2j8);
        goto O92Jn;
        ORiYC:
        $this->XNeds->process($ge2j8);
        goto zizVW;
        NClil:
        if (!$this->XNeds) {
            goto Djklb;
        }
        goto ORiYC;
        ezSTE:
        if (!(FdWrko7bmoI4Y::PROCESSING === $ge2j8)) {
            goto HeCcI;
        }
        goto qik9D;
        O92Jn:
        myZgW:
        goto zuwYk;
        zuwYk:
        HeCcI:
        goto Jmc1K;
        zizVW:
        Djklb:
        goto oFT6t;
        oFT6t:
        ENazv:
        goto TuS47;
        qik9D:
        $this->HyWI1->save();
        goto do1h6;
        TuS47:
    }
    private function mQKjKyOpJrF()
    {
        goto ETFdm;
        ONoiN:
        ujdIg:
        goto IVAdR;
        ETFdm:
        switch ($this->HyWI1->getType()) {
            case 'image':
                return new CAauJWIO9Pclr($this->HyWI1, $this->RX1is);
            case 'video':
                return new BZm8VQKCy3Ezl($this->HyWI1, App::make(V6kCroy78Tmzg::class));
            default:
                return null;
        }
        goto hGmvX;
        hGmvX:
        MadaG:
        goto ONoiN;
        IVAdR:
    }
}
