<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\D1gefDsblgSHh;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Exception\D2GpNcz5KiI9K;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Presigned\Lmh4HFNwhMMfs;
use Jfs\Uploader\Presigned\MksEWJ9CWnSXw;
use Illuminate\Support\Facades\Log;
final class U3kjpY8VjSmvL implements D1gefDsblgSHh
{
    private $cPPPz;
    private $Y6NCf;
    private $gcP3F;
    private $Ck8AK;
    private $n_TUX;
    public function __construct($HuGK_, $qxxOf, $P4KJD, $EwO1g, $v1l2C = false)
    {
        goto Ma0xU;
        gWnZE:
        if ($v1l2C) {
            goto bta1m;
        }
        goto Be2Ry;
        UQrkT:
        $this->gcP3F = $qxxOf;
        goto nB81y;
        k_A7z:
        $this->n_TUX = $EwO1g;
        goto gWnZE;
        Ma0xU:
        $this->Y6NCf = $HuGK_;
        goto UQrkT;
        Be2Ry:
        $this->mPef1QXlbyA();
        goto xj63K;
        xj63K:
        bta1m:
        goto VcYSB;
        nB81y:
        $this->Ck8AK = $P4KJD;
        goto k_A7z;
        VcYSB:
    }
    private function mPef1QXlbyA() : void
    {
        goto I3jdw;
        SKWdC:
        return;
        goto x0W81;
        I3jdw:
        if (!(null !== $this->cPPPz)) {
            goto NP9q2;
        }
        goto SKWdC;
        K2YQk:
        try {
            $LGjda = $this->Y6NCf->mg099Xaz8Vo();
            $this->cPPPz = 's3' === $LGjda->driver ? new MksEWJ9CWnSXw($this->Y6NCf, $this->gcP3F, $this->Ck8AK, $this->n_TUX) : new Lmh4HFNwhMMfs($this->Y6NCf, $this->gcP3F, $this->Ck8AK);
        } catch (DRgeXfZrFFnZd $R1uEk) {
            Log::warning("Failed to set up presigned upload: {$R1uEk->getMessage()}");
        }
        goto Z8lDh;
        x0W81:
        NP9q2:
        goto K2YQk;
        Z8lDh:
    }
    public function mop1CVR7YoY($olf3Q, $Iv88p)
    {
        goto dwpUt;
        Oof5T:
        KYOqM:
        goto pB_Th;
        pB_Th:
        sGnN_:
        goto qAafU;
        dwpUt:
        $this->mPef1QXlbyA();
        goto ac6hP;
        ac6hP:
        switch ($Iv88p) {
            case IOOvAXAyKHLW2::UPLOADING:
                $this->mglYTXdth83();
                goto sGnN_;
            case IOOvAXAyKHLW2::UPLOADED:
                $this->mooHfLG3ZDN();
                goto sGnN_;
            case IOOvAXAyKHLW2::ABORTED:
                $this->m4af8ZJZlU8();
                goto sGnN_;
            default:
                goto sGnN_;
        }
        goto Oof5T;
        qAafU:
    }
    private function mooHfLG3ZDN() : void
    {
        goto tqPbh;
        i0EMT:
        oJf5K:
        goto ULS36;
        V0tH1:
        $pemjO->mVhOJ1PgG8J(IOOvAXAyKHLW2::PROCESSING);
        goto i0EMT;
        sPkRI:
        if (!$pemjO instanceof ISYJHQo8eqdfc) {
            goto oJf5K;
        }
        goto qIMzF;
        qIMzF:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($pemjO->id);
        goto V0tH1;
        tTE3u:
        $pemjO = $this->Y6NCf->getFile();
        goto ezmIn;
        ezmIn:
        $pemjO->mVhOJ1PgG8J(IOOvAXAyKHLW2::UPLOADED);
        goto sPkRI;
        tqPbh:
        $this->cPPPz->mLNNdTnrcAS();
        goto tTE3u;
        ULS36:
    }
    private function m4af8ZJZlU8() : void
    {
        $this->cPPPz->mCHqfrmH8l8();
    }
    private function mglYTXdth83() : void
    {
        $this->cPPPz->mm4dJgrnW0N();
    }
}
