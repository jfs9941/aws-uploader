<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Contracts\RoTpJhiFhvlTg;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Core\Strategy\WT6cmOrabtc9n;
use Jfs\Uploader\Core\Strategy\PZdwEyoqlLHE9;
use Jfs\Uploader\Encoder\LzL89H4g6zwMz;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Service\WK3vb1oP6Xm31;
final class TxC84kcTUFPDC implements RoTpJhiFhvlTg
{
    private $VfWRS;
    private $cyroT;
    private $W_Kti;
    private $ScpDq;
    public function __construct($a3XOL, $agzKA, $AMB6h)
    {
        goto X2jpF;
        wW42k:
        $this->VfWRS = $this->mCKCVhRx7SM();
        goto dlSgS;
        MgET1:
        $this->ScpDq = $AMB6h;
        goto wW42k;
        em5DU:
        $this->W_Kti = $agzKA;
        goto MgET1;
        X2jpF:
        $this->cyroT = $a3XOL;
        goto em5DU;
        dlSgS:
    }
    public function mM5x0654DhR($EIAGD, $UeOhO) : void
    {
        goto UBmqa;
        JmoZ2:
        $this->cyroT->save();
        goto CoA_F;
        Pfaza:
        if (!$this->VfWRS) {
            goto ysE2w;
        }
        goto bOFE9;
        ts8cF:
        $this->VfWRS->process($UeOhO);
        goto n93mu;
        WpWsi:
        if (!(RwOJkCXwa9RQz::ENCODING_PROCESSED === $UeOhO)) {
            goto zwuv5;
        }
        goto JmoZ2;
        CoA_F:
        if (!$this->VfWRS) {
            goto Iw37T;
        }
        goto ts8cF;
        bOFE9:
        $this->VfWRS->process($UeOhO);
        goto sWh8E;
        n93mu:
        Iw37T:
        goto e0dmH;
        k0tmr:
        RWq4y:
        goto WpWsi;
        sWh8E:
        ysE2w:
        goto k0tmr;
        e0dmH:
        zwuv5:
        goto cUwiX;
        Rhl8j:
        $this->cyroT->save();
        goto Pfaza;
        UBmqa:
        if (!(RwOJkCXwa9RQz::PROCESSING === $UeOhO)) {
            goto RWq4y;
        }
        goto Rhl8j;
        cUwiX:
    }
    private function mCKCVhRx7SM()
    {
        goto v63BW;
        WxUI9:
        GwepU:
        goto zy1QG;
        v63BW:
        switch ($this->cyroT->getType()) {
            case 'image':
                return new WT6cmOrabtc9n($this->cyroT, $this->ScpDq);
            case 'video':
                return new PZdwEyoqlLHE9($this->cyroT, App::make(LzL89H4g6zwMz::class));
            default:
                return null;
        }
        goto pvp1C;
        pvp1C:
        jNXhW:
        goto WxUI9;
        zy1QG:
    }
}
