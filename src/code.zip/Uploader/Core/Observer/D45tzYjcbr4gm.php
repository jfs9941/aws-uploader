<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\QnQF56ZOfQE7U;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Exception\GRAfJLmbKXpoS;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Presigned\JKTnVNHFkwUhO;
use Jfs\Uploader\Presigned\M2P6l0xYXJMCj;
use Illuminate\Support\Facades\Log;
final class D45tzYjcbr4gm implements QnQF56ZOfQE7U
{
    private $nBN1I;
    private $fl_Nu;
    private $h0iwI;
    private $o9xvH;
    private $VwfNm;
    public function __construct($EZ04_, $jxMWP, $ft7kk, $XbR1L, $E3b64 = false)
    {
        goto TxkU4;
        TxkU4:
        $this->fl_Nu = $EZ04_;
        goto Mbodr;
        HLOGD:
        $this->VwfNm = $XbR1L;
        goto u1sBH;
        c_ZNR:
        wn4_r:
        goto GqsbV;
        Mbodr:
        $this->h0iwI = $jxMWP;
        goto YCHy7;
        u1sBH:
        if ($E3b64) {
            goto wn4_r;
        }
        goto CqOKY;
        YCHy7:
        $this->o9xvH = $ft7kk;
        goto HLOGD;
        CqOKY:
        $this->m7ihlB90Nc6();
        goto c_ZNR;
        GqsbV:
    }
    private function m7ihlB90Nc6() : void
    {
        goto iiSji;
        FSB3G:
        return;
        goto c1395;
        P9qqp:
        try {
            $V5lrw = $this->fl_Nu->mSViQFIwKkL();
            $this->nBN1I = 's3' === $V5lrw->Gm9Y9 ? new M2P6l0xYXJMCj($this->fl_Nu, $this->h0iwI, $this->o9xvH, $this->VwfNm) : new JKTnVNHFkwUhO($this->fl_Nu, $this->h0iwI, $this->o9xvH);
        } catch (Javj89gHS43od $OaHp2) {
            Log::warning("Failed to set up presigned upload: {$OaHp2->getMessage()}");
        }
        goto v02IF;
        iiSji:
        if (!(null !== $this->nBN1I)) {
            goto CvBYT;
        }
        goto FSB3G;
        c1395:
        CvBYT:
        goto P9qqp;
        v02IF:
    }
    public function mdfAwNnkVqr($XbAUN, $ZIUao)
    {
        goto fBPba;
        S9wiD:
        switch ($ZIUao) {
            case WSEQ88VDOa3X0::UPLOADING:
                $this->m1nfZ6YGzL9();
                goto uUTwO;
            case WSEQ88VDOa3X0::UPLOADED:
                $this->muaDadZWJE8();
                goto uUTwO;
            case WSEQ88VDOa3X0::ABORTED:
                $this->mNETiORILWf();
                goto uUTwO;
            default:
                goto uUTwO;
        }
        goto Vx1Cy;
        Vx1Cy:
        xl0vn:
        goto J7YtZ;
        fBPba:
        $this->m7ihlB90Nc6();
        goto S9wiD;
        J7YtZ:
        uUTwO:
        goto VmCmB;
        VmCmB:
    }
    private function muaDadZWJE8() : void
    {
        goto amRYV;
        IrQpk:
        $bwI0g = $this->fl_Nu->getFile();
        goto BpeU0;
        BpeU0:
        $bwI0g->mRU2TqSePcC(WSEQ88VDOa3X0::UPLOADED);
        goto bv6l9;
        ibfcb:
        yqRxz:
        goto HPC1i;
        yE98j:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($bwI0g->id);
        goto ibfcb;
        amRYV:
        $this->nBN1I->mUEzFn7SZiO();
        goto IrQpk;
        bv6l9:
        if (!$bwI0g instanceof SNpic2wzC1yT8) {
            goto yqRxz;
        }
        goto yE98j;
        HPC1i:
    }
    private function mNETiORILWf() : void
    {
        $this->nBN1I->ma5c6dbi8Bh();
    }
    private function m1nfZ6YGzL9() : void
    {
        $this->nBN1I->mVNXsVqeTEd();
    }
}
