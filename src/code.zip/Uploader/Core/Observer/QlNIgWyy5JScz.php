<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\I2OiS2IsDF9Mg;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Exception\ZKaX19yQXS7pD;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Presigned\O1X2Qf4AZFugj;
use Jfs\Uploader\Presigned\JCKCdcvxiIMNL;
use Illuminate\Support\Facades\Log;
final class QlNIgWyy5JScz implements I2OiS2IsDF9Mg
{
    private $T9kb_;
    private $R3E7z;
    private $ZPzJH;
    private $luUdx;
    private $kJEi8;
    public function __construct($iZsfk, $G3exm, $u0SLj, $r087v, $F03NA = false)
    {
        goto vSLp5;
        RDpwU:
        $this->mVKTiFbE63U();
        goto GYpxd;
        Iu9mt:
        $this->luUdx = $u0SLj;
        goto Fu5HL;
        GYpxd:
        Rtuot:
        goto WRjBx;
        Fu5HL:
        $this->kJEi8 = $r087v;
        goto MRon5;
        MRon5:
        if ($F03NA) {
            goto Rtuot;
        }
        goto RDpwU;
        KbXh0:
        $this->ZPzJH = $G3exm;
        goto Iu9mt;
        vSLp5:
        $this->R3E7z = $iZsfk;
        goto KbXh0;
        WRjBx:
    }
    private function mVKTiFbE63U() : void
    {
        goto pcpBl;
        spPQn:
        return;
        goto lF1cr;
        dr5nK:
        try {
            $PSxFL = $this->R3E7z->mLzfhDWzVE5();
            $this->T9kb_ = 's3' === $PSxFL->h8PS2 ? new JCKCdcvxiIMNL($this->R3E7z, $this->ZPzJH, $this->luUdx, $this->kJEi8) : new O1X2Qf4AZFugj($this->R3E7z, $this->ZPzJH, $this->luUdx);
        } catch (CB5eg0zuzdVv8 $x4bzR) {
            Log::warning("Failed to set up presigned upload: {$x4bzR->getMessage()}");
        }
        goto IhzbJ;
        lF1cr:
        WhqaR:
        goto dr5nK;
        pcpBl:
        if (!(null !== $this->T9kb_)) {
            goto WhqaR;
        }
        goto spPQn;
        IhzbJ:
    }
    public function me0Vk27dOzU($OdVJN, $Ws7p7)
    {
        goto WvuLX;
        WvuLX:
        $this->mVKTiFbE63U();
        goto HBiBB;
        W9EsE:
        pdF7s:
        goto BSm2x;
        HBiBB:
        switch ($Ws7p7) {
            case H7dtWZ2h5WAty::UPLOADING:
                $this->mFKPlTmkuHN();
                goto pdF7s;
            case H7dtWZ2h5WAty::UPLOADED:
                $this->m16CTxNIvty();
                goto pdF7s;
            case H7dtWZ2h5WAty::ABORTED:
                $this->mXpxcPf5UOO();
                goto pdF7s;
            default:
                goto pdF7s;
        }
        goto hM3s9;
        hM3s9:
        cRSf2:
        goto W9EsE;
        BSm2x:
    }
    private function m16CTxNIvty() : void
    {
        goto Ycl54;
        nk8e2:
        $nbWJE = $this->R3E7z->getFile();
        goto mTf2x;
        Ycl54:
        $this->T9kb_->m8k1eh8wcQE();
        goto nk8e2;
        CynXc:
        OmvT5:
        goto bDybd;
        mTf2x:
        $nbWJE->mI0VzEtubJR(H7dtWZ2h5WAty::UPLOADED);
        goto fOdin;
        fOdin:
        if (!$nbWJE instanceof J7sRaWo8um3yO) {
            goto OmvT5;
        }
        goto oRJ5n;
        oRJ5n:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($nbWJE->id);
        goto CynXc;
        bDybd:
    }
    private function mXpxcPf5UOO() : void
    {
        $this->T9kb_->mEdT9RIpbT0();
    }
    private function mFKPlTmkuHN() : void
    {
        $this->T9kb_->mmc9EKNltDU();
    }
}
