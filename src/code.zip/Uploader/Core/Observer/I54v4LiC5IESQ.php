<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Contracts\UGfAXCSEERPE4;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
class I54v4LiC5IESQ implements UGfAXCSEERPE4
{
    private $EA4YD;
    public function __construct($YfsmL)
    {
        $this->EA4YD = $YfsmL;
    }
    public function mj4xpscl4k5($DOhs8, $vQwbX)
    {
        goto u00SN;
        gZ0BB:
        $this->EA4YD->status = LV0wDYHZInswq::UPLOADED;
        goto xl1cn;
        k1i5Q:
        if (!(LV0wDYHZInswq::DELETED === $vQwbX && $this->EA4YD->mkiN3f36dQi())) {
            goto PeBq_;
        }
        goto B1Rsl;
        B1Rsl:
        $this->EA4YD->delete();
        goto frpqj;
        vtXr3:
        P4MNn:
        goto k1i5Q;
        Uv1B7:
        $this->EA4YD->mWYAL72rhSp(LV0wDYHZInswq::PROCESSING);
        goto Lzglw;
        frpqj:
        PeBq_:
        goto IWxaR;
        u00SN:
        if (!(LV0wDYHZInswq::UPLOADED === $vQwbX)) {
            goto P4MNn;
        }
        goto gZ0BB;
        Lzglw:
        Uv2MY:
        goto WoqcS;
        xl1cn:
        if (!$this->EA4YD instanceof XMeo8SOmME8kj) {
            goto Uv2MY;
        }
        goto Uv1B7;
        WoqcS:
        $this->EA4YD->save();
        goto vtXr3;
        IWxaR:
    }
}
