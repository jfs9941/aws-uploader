<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Contracts\I2OiS2IsDF9Mg;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\Strategy\SvKcXPVKtKJ6x;
use Jfs\Uploader\Core\Strategy\G5KFaO6H8i95q;
use Jfs\Uploader\Encoder\EVSDjuMy24t33;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Service\Lqd1WdK14h5gQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class CSlB1hwdQhS6x implements I2OiS2IsDF9Mg
{
    private $ibPVc;
    private $tEOkh;
    private $bLZP5;
    private $O9plT;
    public function __construct($nbWJE, $C1By6, $fjrI6)
    {
        goto yGfNT;
        yGfNT:
        $this->tEOkh = $nbWJE;
        goto vFEqf;
        TwoOj:
        $this->O9plT = $fjrI6;
        goto ZGAd0;
        vFEqf:
        $this->bLZP5 = $C1By6;
        goto TwoOj;
        ZGAd0:
        $this->ibPVc = $this->m64L22t185t();
        goto qMt3B;
        qMt3B:
    }
    public function me0Vk27dOzU($OdVJN, $Ws7p7) : void
    {
        goto AQD_g;
        vFZ4e:
        if (!(H7dtWZ2h5WAty::ENCODING_PROCESSED === $Ws7p7)) {
            goto FZbJD;
        }
        goto UJfJP;
        D_ADa:
        if (!$this->ibPVc) {
            goto wJsML;
        }
        goto BOmD2;
        MWGMv:
        ZTHeI:
        goto nqrUG;
        tTmRn:
        FZbJD:
        goto wRuHg;
        nqrUG:
        PHE_A:
        goto vFZ4e;
        fVYND:
        if (!$this->ibPVc) {
            goto ZTHeI;
        }
        goto Q57_F;
        Ph7NT:
        wJsML:
        goto tTmRn;
        BOmD2:
        $this->ibPVc->process($Ws7p7);
        goto Ph7NT;
        cdpji:
        $this->tEOkh->save();
        goto fVYND;
        Q57_F:
        $this->ibPVc->process($Ws7p7);
        goto MWGMv;
        AQD_g:
        if (!(H7dtWZ2h5WAty::PROCESSING === $Ws7p7)) {
            goto PHE_A;
        }
        goto cdpji;
        UJfJP:
        $this->tEOkh->save();
        goto D_ADa;
        wRuHg:
    }
    private function m64L22t185t()
    {
        goto tnmEB;
        tnmEB:
        switch ($this->tEOkh->getType()) {
            case 'image':
                return new SvKcXPVKtKJ6x($this->tEOkh, $this->O9plT);
            case 'video':
                return new G5KFaO6H8i95q($this->tEOkh, App::make(EVSDjuMy24t33::class));
            default:
                return null;
        }
        goto B_LaY;
        B_LaY:
        aXEMd:
        goto yqxde;
        yqxde:
        Ikbpn:
        goto YxBsk;
        YxBsk:
    }
}
