<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\PzqA3QfUmhhMJ;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Exception\LjuaNh4VOaOkF;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Presigned\N23mmTgNF6oEq;
use Jfs\Uploader\Presigned\Qt7IyXXKB79qP;
use Illuminate\Support\Facades\Log;
final class B3X39NyXf7328 implements PzqA3QfUmhhMJ
{
    private $mBSKB;
    private $Fc9NF;
    private $j5MRz;
    private $Diye_;
    private $q34dl;
    public function __construct($LaHja, $nkmCX, $NYASv, $ivxnu, $qjIh3 = false)
    {
        goto faIVH;
        YM1gf:
        $this->j5MRz = $nkmCX;
        goto nCrRY;
        nCrRY:
        $this->Diye_ = $NYASv;
        goto f3b_g;
        qtCUM:
        xJf07:
        goto QEi13;
        f3b_g:
        $this->q34dl = $ivxnu;
        goto cvlWi;
        faIVH:
        $this->Fc9NF = $LaHja;
        goto YM1gf;
        qG8OR:
        $this->mwMek8n1OFv();
        goto qtCUM;
        cvlWi:
        if ($qjIh3) {
            goto xJf07;
        }
        goto qG8OR;
        QEi13:
    }
    private function mwMek8n1OFv() : void
    {
        goto FOHiw;
        z1rfH:
        return;
        goto pwyWR;
        KwjyU:
        try {
            $Zqaxi = $this->Fc9NF->mLISLvz7JU3();
            $this->mBSKB = 's3' === $Zqaxi->driver ? new Qt7IyXXKB79qP($this->Fc9NF, $this->j5MRz, $this->Diye_, $this->q34dl) : new N23mmTgNF6oEq($this->Fc9NF, $this->j5MRz, $this->Diye_);
        } catch (YK7fJDaVPWKzB $kE48F) {
            Log::warning("Failed to set up presigned upload: {$kE48F->getMessage()}");
        }
        goto K4P3q;
        FOHiw:
        if (!(null !== $this->mBSKB)) {
            goto RYs_K;
        }
        goto z1rfH;
        pwyWR:
        RYs_K:
        goto KwjyU;
        K4P3q:
    }
    public function mjTwbCJOfRB($L51Zi, $IoGt4)
    {
        goto kr_kg;
        kr_kg:
        $this->mwMek8n1OFv();
        goto Q0sa7;
        cBPSs:
        nMzOB:
        goto P8OzG;
        P8OzG:
        IL7Dr:
        goto KvGSS;
        Q0sa7:
        switch ($IoGt4) {
            case HGmeWpZQSxAlO::UPLOADING:
                $this->mH4ooDUsj0t();
                goto IL7Dr;
            case HGmeWpZQSxAlO::UPLOADED:
                $this->mm8sQaMl6yu();
                goto IL7Dr;
            case HGmeWpZQSxAlO::ABORTED:
                $this->mH3mxCd8vtK();
                goto IL7Dr;
            default:
                goto IL7Dr;
        }
        goto cBPSs;
        KvGSS:
    }
    private function mm8sQaMl6yu() : void
    {
        goto AHwAv;
        AHwAv:
        $this->mBSKB->mpGt5pOOnnk();
        goto DqgUj;
        orKwc:
        j0NqR:
        goto QvUmX;
        wlx6l:
        $Ga9Xm->muO5nIQPKS7(HGmeWpZQSxAlO::UPLOADED);
        goto UQKhF;
        UQKhF:
        if (!$Ga9Xm instanceof D6fOq8lm3n7T2) {
            goto j0NqR;
        }
        goto YktCT;
        YktCT:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($Ga9Xm->id);
        goto orKwc;
        DqgUj:
        $Ga9Xm = $this->Fc9NF->getFile();
        goto wlx6l;
        QvUmX:
    }
    private function mH3mxCd8vtK() : void
    {
        $this->mBSKB->mam3hAYlt0Q();
    }
    private function mH4ooDUsj0t() : void
    {
        $this->mBSKB->mB7vpRBakhx();
    }
}
