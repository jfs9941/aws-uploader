<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Contracts\WsCsRu4iqCZ5i;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
class IuCSRQJyNQ7L0 implements WsCsRu4iqCZ5i
{
    private $tp12K;
    public function __construct($DejZC)
    {
        $this->tp12K = $DejZC;
    }
    public function mz4knromh2J($s8PR0, $sNTGc)
    {
        goto tn1lt;
        tn1lt:
        if (!(Xy3InMky6jKYf::UPLOADED === $sNTGc)) {
            goto HWRDI;
        }
        goto GQZY4;
        GQZY4:
        $this->tp12K->status = Xy3InMky6jKYf::UPLOADED;
        goto kDNZB;
        RzI0C:
        $this->tp12K->mAPPeV3mHXi(Xy3InMky6jKYf::PROCESSING);
        goto n2L3t;
        kDNZB:
        if (!$this->tp12K instanceof QFoN7Ibbm93if) {
            goto WUZF5;
        }
        goto RzI0C;
        b29KN:
        if (!(Xy3InMky6jKYf::DELETED === $sNTGc && $this->tp12K->m3GTFmhc6Xp())) {
            goto dz2oz;
        }
        goto WNmQH;
        UeekI:
        dz2oz:
        goto n3DVi;
        YrQSQ:
        HWRDI:
        goto b29KN;
        n2L3t:
        WUZF5:
        goto Ub02z;
        WNmQH:
        $this->tp12K->delete();
        goto UeekI;
        Ub02z:
        $this->tp12K->save();
        goto YrQSQ;
        n3DVi:
    }
}
