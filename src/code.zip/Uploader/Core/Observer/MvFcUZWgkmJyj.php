<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Contracts\YZqPZlzFpJfK6;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\Strategy\LoOY6agInQqUi;
use Jfs\Uploader\Core\Strategy\Mna2jSvZVAQ2s;
use Jfs\Uploader\Encoder\Suk3MOIJcOQzt;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Service\CbfzS01NR7tQ9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class MvFcUZWgkmJyj implements YZqPZlzFpJfK6
{
    private $sqoo2;
    private $bQMHT;
    private $m2kWg;
    private $tWs0h;
    public function __construct($ZQzpf, $Npup8, $ZpGBL)
    {
        goto nXQvc;
        NRQ6F:
        $this->m2kWg = $Npup8;
        goto DrWUj;
        nXQvc:
        $this->bQMHT = $ZQzpf;
        goto NRQ6F;
        DrWUj:
        $this->tWs0h = $ZpGBL;
        goto mY0gB;
        mY0gB:
        $this->sqoo2 = $this->mMQMZHbRgfK();
        goto MnRR6;
        MnRR6:
    }
    public function mqIsZMsLGwg($Hr7H_, $ddv_R) : void
    {
        goto szi0v;
        bfm60:
        if (!$this->sqoo2) {
            goto li_Qn;
        }
        goto j8jnJ;
        UMTjG:
        $this->bQMHT->save();
        goto CuVOh;
        szi0v:
        if (!(ZVJoOgH14iXBq::PROCESSING === $ddv_R)) {
            goto aAuAk;
        }
        goto fpkZn;
        Lqq7C:
        li_Qn:
        goto jpduX;
        fpkZn:
        $this->bQMHT->save();
        goto bfm60;
        dd4JI:
        $this->sqoo2->process($ddv_R);
        goto QbhV7;
        jpduX:
        aAuAk:
        goto uQ2SG;
        uQ2SG:
        if (!(ZVJoOgH14iXBq::ENCODING_PROCESSED === $ddv_R)) {
            goto yA9C0;
        }
        goto UMTjG;
        CuVOh:
        if (!$this->sqoo2) {
            goto lqsDA;
        }
        goto dd4JI;
        j8jnJ:
        $this->sqoo2->process($ddv_R);
        goto Lqq7C;
        QbhV7:
        lqsDA:
        goto V3lFE;
        V3lFE:
        yA9C0:
        goto Fuv9j;
        Fuv9j:
    }
    private function mMQMZHbRgfK()
    {
        goto Z0OS5;
        X6FA3:
        i3mWV:
        goto UaSa3;
        Z0OS5:
        switch ($this->bQMHT->getType()) {
            case 'image':
                return new LoOY6agInQqUi($this->bQMHT, $this->tWs0h);
            case 'video':
                return new Mna2jSvZVAQ2s($this->bQMHT, App::make(Suk3MOIJcOQzt::class));
            default:
                return null;
        }
        goto ey68x;
        ey68x:
        BZcm0:
        goto X6FA3;
        UaSa3:
    }
}
