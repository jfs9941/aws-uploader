<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Contracts\J6QUpUFjfs5mO;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\Strategy\D8dXWNMG5l50j;
use Jfs\Uploader\Core\Strategy\WnigFsu7UqU9l;
use Jfs\Uploader\Encoder\XeMVcGXMtTgrJ;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Service\Vxy5RzsyYlKDb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class QDZMpb9AGAW1H implements J6QUpUFjfs5mO
{
    private $xZzgT;
    private $pnMmg;
    private $gErml;
    private $FBCkB;
    public function __construct($dV9QE, $DFpIk, $wNMDX)
    {
        goto DjJic;
        B9T0Q:
        $this->gErml = $DFpIk;
        goto pURRj;
        tVcuZ:
        $this->xZzgT = $this->mwnQcweB6mL();
        goto J7jZk;
        DjJic:
        $this->pnMmg = $dV9QE;
        goto B9T0Q;
        pURRj:
        $this->FBCkB = $wNMDX;
        goto tVcuZ;
        J7jZk:
    }
    public function mZjeUKxpiHv($BWos3, $wqzpN) : void
    {
        goto fS5uI;
        y5oAJ:
        if (!(EpMPhiTVzNYqA::ENCODING_PROCESSED === $wqzpN)) {
            goto vp0Rs;
        }
        goto QDgEb;
        uRfh1:
        if (!$this->xZzgT) {
            goto mXFVd;
        }
        goto W4gJ_;
        W4gJ_:
        $this->xZzgT->process($wqzpN);
        goto ybkX7;
        KXiSz:
        vp0Rs:
        goto FCsHl;
        ybkX7:
        mXFVd:
        goto fd9Ig;
        fS5uI:
        if (!(EpMPhiTVzNYqA::PROCESSING === $wqzpN)) {
            goto vJlbQ;
        }
        goto W1gW9;
        W1gW9:
        $this->pnMmg->save();
        goto uRfh1;
        lux3G:
        $this->xZzgT->process($wqzpN);
        goto VxhPk;
        QDgEb:
        $this->pnMmg->save();
        goto nRoKF;
        fd9Ig:
        vJlbQ:
        goto y5oAJ;
        nRoKF:
        if (!$this->xZzgT) {
            goto e9_cz;
        }
        goto lux3G;
        VxhPk:
        e9_cz:
        goto KXiSz;
        FCsHl:
    }
    private function mwnQcweB6mL()
    {
        goto oSVZO;
        M1YS5:
        dapjQ:
        goto issGZ;
        oSVZO:
        switch ($this->pnMmg->getType()) {
            case 'image':
                return new D8dXWNMG5l50j($this->pnMmg, $this->FBCkB);
            case 'video':
                return new WnigFsu7UqU9l($this->pnMmg, App::make(XeMVcGXMtTgrJ::class));
            default:
                return null;
        }
        goto M1YS5;
        issGZ:
        FI76u:
        goto xLupB;
        xLupB:
    }
}
