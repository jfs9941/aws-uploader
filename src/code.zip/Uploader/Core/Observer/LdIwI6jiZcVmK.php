<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Contracts\Xg08pDZLenaCo;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\Strategy\B4ZF0yQFWWc9S;
use Jfs\Uploader\Core\Strategy\YIpAdJsDDxZui;
use Jfs\Uploader\Encoder\A8w0sFEmIyJGd;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Service\WqQUjHBw41oKQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class LdIwI6jiZcVmK implements Xg08pDZLenaCo
{
    private $GiRQx;
    private $y_eVA;
    private $Mayr9;
    private $g83AR;
    public function __construct($D55CH, $KI4Gx, $Fsmva)
    {
        goto S6s4y;
        JV1JE:
        $this->g83AR = $Fsmva;
        goto Bng9h;
        Bng9h:
        $this->GiRQx = $this->mTZyPknMpCB();
        goto W9taq;
        MCrVS:
        $this->Mayr9 = $KI4Gx;
        goto JV1JE;
        S6s4y:
        $this->y_eVA = $D55CH;
        goto MCrVS;
        W9taq:
    }
    public function mnTJmPCq3BW($gAEvi, $G7Qtb) : void
    {
        goto sNs90;
        wqiKn:
        $this->y_eVA->save();
        goto oh_n0;
        eGsRe:
        if (!$this->GiRQx) {
            goto e9Nft;
        }
        goto fi0tU;
        sNs90:
        if (!(Zgh3BZ2JVlG1A::PROCESSING === $G7Qtb)) {
            goto fXfmr;
        }
        goto xnczL;
        oh_n0:
        if (!$this->GiRQx) {
            goto TbFMS;
        }
        goto lup1I;
        FGUF1:
        if (!(Zgh3BZ2JVlG1A::ENCODING_PROCESSED === $G7Qtb)) {
            goto ecdRa;
        }
        goto wqiKn;
        xnczL:
        $this->y_eVA->save();
        goto eGsRe;
        Rl4oI:
        fXfmr:
        goto FGUF1;
        fi0tU:
        $this->GiRQx->process($G7Qtb);
        goto KK1YT;
        XjXKi:
        ecdRa:
        goto Ext3t;
        KK1YT:
        e9Nft:
        goto Rl4oI;
        XAlcf:
        TbFMS:
        goto XjXKi;
        lup1I:
        $this->GiRQx->process($G7Qtb);
        goto XAlcf;
        Ext3t:
    }
    private function mTZyPknMpCB()
    {
        goto Uoh7J;
        ClRT_:
        JVeUS:
        goto TiMAO;
        TiMAO:
        i39BC:
        goto ZoUTy;
        Uoh7J:
        switch ($this->y_eVA->getType()) {
            case 'image':
                return new B4ZF0yQFWWc9S($this->y_eVA, $this->g83AR);
            case 'video':
                return new YIpAdJsDDxZui($this->y_eVA, App::make(A8w0sFEmIyJGd::class));
            default:
                return null;
        }
        goto ClRT_;
        ZoUTy:
    }
}
