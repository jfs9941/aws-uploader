<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\F66VaMRGSfxoM;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Exception\KVgPdowMikNnK;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Jfs\Uploader\Presigned\Kyp1AV9oloHFc;
use Jfs\Uploader\Presigned\RE1uFpgt8r0PY;
final class CCRkQg8HrppN4 implements F66VaMRGSfxoM
{
    private $k1J0P;
    private $alOL8;
    private $Hf14x;
    private $tYBKb;
    private $zzcfY;
    public function __construct($X40HK, $p1fCH, $zCXkD, $UYSBS, $o5esM = false)
    {
        goto nepiB;
        B8hew:
        if ($o5esM) {
            goto deRld;
        }
        goto VG627;
        nepiB:
        $this->alOL8 = $X40HK;
        goto Ah2Dj;
        EYofA:
        deRld:
        goto TmWgT;
        kXZIW:
        $this->zzcfY = $UYSBS;
        goto B8hew;
        VG627:
        $this->mUxIU0mmmmN();
        goto EYofA;
        Gebtw:
        $this->tYBKb = $zCXkD;
        goto kXZIW;
        Ah2Dj:
        $this->Hf14x = $p1fCH;
        goto Gebtw;
        TmWgT:
    }
    private function mUxIU0mmmmN() : void
    {
        goto rVxTh;
        bpNU1:
        agaTK:
        goto vs1c5;
        rVxTh:
        if (!(null !== $this->k1J0P)) {
            goto agaTK;
        }
        goto m4bJr;
        m4bJr:
        return;
        goto bpNU1;
        vs1c5:
        try {
            $Cva33 = $this->alOL8->mFmRtrLmgsB();
            $this->k1J0P = 's3' === $Cva33->tl1PH ? new RE1uFpgt8r0PY($this->alOL8, $this->Hf14x, $this->tYBKb, $this->zzcfY) : new Kyp1AV9oloHFc($this->alOL8, $this->Hf14x, $this->tYBKb);
        } catch (GoWX7Rl7j3VtX $cy3Ei) {
            Log::warning("Failed to set up presigned upload: {$cy3Ei->getMessage()}");
        }
        goto fm7eV;
        fm7eV:
    }
    public function mSg4ZNxGqnf($ESYUX, $X7DL1)
    {
        goto nBOGm;
        yXnPZ:
        RwcUS:
        goto xZ42n;
        lzXA2:
        Oys78:
        goto yXnPZ;
        nBOGm:
        $this->mUxIU0mmmmN();
        goto i0x92;
        i0x92:
        switch ($X7DL1) {
            case EPmxqTVp5luXc::UPLOADING:
                $this->mNsJ9GlOFKH();
                goto RwcUS;
            case EPmxqTVp5luXc::UPLOADED:
                $this->mDQWYHIMIIa();
                goto RwcUS;
            case EPmxqTVp5luXc::ABORTED:
                $this->mSoar037yXI();
                goto RwcUS;
            default:
                goto RwcUS;
        }
        goto lzXA2;
        xZ42n:
    }
    private function mDQWYHIMIIa() : void
    {
        goto ODqBi;
        u9QKh:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($I2SbP->id);
        goto fdipg;
        az7BG:
        $I2SbP = $this->alOL8->getFile();
        goto IEWec;
        fdipg:
        YcsH7:
        goto w49eR;
        zjCOJ:
        if (!$I2SbP instanceof CUaMUcjkFHEwK) {
            goto YcsH7;
        }
        goto u9QKh;
        IEWec:
        $I2SbP->mY8gUThQFjU(EPmxqTVp5luXc::UPLOADED);
        goto zjCOJ;
        ODqBi:
        $this->k1J0P->mpI4EE9RWUf();
        goto az7BG;
        w49eR:
    }
    private function mSoar037yXI() : void
    {
        $this->k1J0P->maQSjrd7n8J();
    }
    private function mNsJ9GlOFKH() : void
    {
        $this->k1J0P->mXz4toFge7Q();
    }
}
