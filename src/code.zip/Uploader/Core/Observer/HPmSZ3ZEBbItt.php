<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Contracts\YZqPZlzFpJfK6;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
class HPmSZ3ZEBbItt implements YZqPZlzFpJfK6
{
    private $bQMHT;
    public function __construct($ZQzpf)
    {
        $this->bQMHT = $ZQzpf;
    }
    public function mqIsZMsLGwg($Hr7H_, $ddv_R)
    {
        goto uph22;
        e11Sr:
        fFlnT:
        goto l2UZM;
        STMza:
        $this->bQMHT->status = ZVJoOgH14iXBq::UPLOADED;
        goto Ak6KQ;
        A4Tw0:
        $this->bQMHT->delete();
        goto v5tGg;
        q1hup:
        TbanO:
        goto cEBo9;
        cEBo9:
        $this->bQMHT->save();
        goto e11Sr;
        uph22:
        if (!(ZVJoOgH14iXBq::UPLOADED === $ddv_R)) {
            goto fFlnT;
        }
        goto STMza;
        Ak6KQ:
        if (!$this->bQMHT instanceof OjvWwjWRqBzIO) {
            goto TbanO;
        }
        goto wzCG7;
        l2UZM:
        if (!(ZVJoOgH14iXBq::DELETED === $ddv_R && $this->bQMHT->m0el2Ns6vCi())) {
            goto wIWlG;
        }
        goto A4Tw0;
        wzCG7:
        $this->bQMHT->mzoKjbCd8Ap(ZVJoOgH14iXBq::PROCESSING);
        goto q1hup;
        v5tGg:
        wIWlG:
        goto VDTek;
        VDTek:
    }
}
