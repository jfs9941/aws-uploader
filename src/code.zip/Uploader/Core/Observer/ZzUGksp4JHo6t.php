<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Contracts\PdBd5D8IKDopT;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Core\Strategy\W1Rha7GI4Nwlt;
use Jfs\Uploader\Core\Strategy\J5Jy7oGH9SENT;
use Jfs\Uploader\Encoder\Gp4Z40z5XsT8O;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Service\R9h2iDidHZRXb;
final class ZzUGksp4JHo6t implements PdBd5D8IKDopT
{
    private $SIFu0;
    private $IJ6tP;
    private $Vhcrn;
    private $ounZ0;
    public function __construct($rQ18B, $Klx1U, $FiE4q)
    {
        goto h7LcQ;
        eIXHx:
        $this->Vhcrn = $Klx1U;
        goto buZWz;
        buZWz:
        $this->ounZ0 = $FiE4q;
        goto VJUro;
        VJUro:
        $this->SIFu0 = $this->mrnoPCQPzu5();
        goto aNI94;
        h7LcQ:
        $this->IJ6tP = $rQ18B;
        goto eIXHx;
        aNI94:
    }
    public function mht82bQ4KnY($iydej, $GbrlI) : void
    {
        goto QZ5ah;
        QZ5ah:
        if (!(SwAwanZG36Yx6::PROCESSING === $GbrlI)) {
            goto DJuMF;
        }
        goto m998a;
        rD4Fw:
        if (!$this->SIFu0) {
            goto TnfcU;
        }
        goto o648S;
        d_JiM:
        i3J1p:
        goto okrgM;
        Su6Mb:
        if (!$this->SIFu0) {
            goto i3J1p;
        }
        goto SaxYN;
        m998a:
        $this->IJ6tP->save();
        goto rD4Fw;
        DNnaX:
        TnfcU:
        goto b1e6A;
        b1e6A:
        DJuMF:
        goto BpaPw;
        BpaPw:
        if (!(SwAwanZG36Yx6::ENCODING_PROCESSED === $GbrlI)) {
            goto uPrV_;
        }
        goto l5lDk;
        SaxYN:
        $this->SIFu0->process($GbrlI);
        goto d_JiM;
        l5lDk:
        $this->IJ6tP->save();
        goto Su6Mb;
        okrgM:
        uPrV_:
        goto uQkuG;
        o648S:
        $this->SIFu0->process($GbrlI);
        goto DNnaX;
        uQkuG:
    }
    private function mrnoPCQPzu5()
    {
        goto LcqEz;
        XEN9A:
        PAY9C:
        goto CjEYh;
        CjEYh:
        Ar3Ti:
        goto fEJSi;
        LcqEz:
        switch ($this->IJ6tP->getType()) {
            case 'image':
                return new W1Rha7GI4Nwlt($this->IJ6tP, $this->ounZ0);
            case 'video':
                return new J5Jy7oGH9SENT($this->IJ6tP, App::make(Gp4Z40z5XsT8O::class));
            default:
                return null;
        }
        goto XEN9A;
        fEJSi:
    }
}
