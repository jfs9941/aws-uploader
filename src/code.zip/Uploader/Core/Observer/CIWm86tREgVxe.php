<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\TjZC83Yv3rOXg;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Exception\HF2PbTFQhW3Rr;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Presigned\Z5jtHfGiVfu9s;
use Jfs\Uploader\Presigned\HtMGp5fv43u30;
use Illuminate\Support\Facades\Log;
final class CIWm86tREgVxe implements TjZC83Yv3rOXg
{
    private $eWA8h;
    private $xcd12;
    private $hhcR1;
    private $GkraP;
    private $VtRCr;
    public function __construct($GNrIm, $nQYui, $jkGKh, $G2CsF, $Qt_P5 = false)
    {
        goto nZOco;
        YBxit:
        $this->mG30P4YUkMM();
        goto LdPfK;
        Mk6xE:
        $this->hhcR1 = $nQYui;
        goto ce8cQ;
        LdPfK:
        uKGdG:
        goto RhqlG;
        nZOco:
        $this->xcd12 = $GNrIm;
        goto Mk6xE;
        X1S3_:
        $this->VtRCr = $G2CsF;
        goto OP40H;
        OP40H:
        if ($Qt_P5) {
            goto uKGdG;
        }
        goto YBxit;
        ce8cQ:
        $this->GkraP = $jkGKh;
        goto X1S3_;
        RhqlG:
    }
    private function mG30P4YUkMM() : void
    {
        goto JqpZB;
        LMQbm:
        DLftC:
        goto jErwu;
        Zsog7:
        return;
        goto LMQbm;
        JqpZB:
        if (!(null !== $this->eWA8h)) {
            goto DLftC;
        }
        goto Zsog7;
        jErwu:
        try {
            $apROX = $this->xcd12->mAorhKFxc5x();
            $this->eWA8h = 's3' === $apROX->avC90 ? new HtMGp5fv43u30($this->xcd12, $this->hhcR1, $this->GkraP, $this->VtRCr) : new Z5jtHfGiVfu9s($this->xcd12, $this->hhcR1, $this->GkraP);
        } catch (EpflNcDLOJeck $tfcsO) {
            Log::warning("Failed to set up presigned upload: {$tfcsO->getMessage()}");
        }
        goto tpbZg;
        tpbZg:
    }
    public function mOZ7C9ggFcs($YJZDm, $ge2j8)
    {
        goto mDH06;
        NoXmE:
        sIS9k:
        goto OTSNQ;
        GcIxe:
        switch ($ge2j8) {
            case FdWrko7bmoI4Y::UPLOADING:
                $this->m4wmtPZ0iZ9();
                goto YxmTB;
            case FdWrko7bmoI4Y::UPLOADED:
                $this->m1y1NkE4RbW();
                goto YxmTB;
            case FdWrko7bmoI4Y::ABORTED:
                $this->m991obJTywq();
                goto YxmTB;
            default:
                goto YxmTB;
        }
        goto NoXmE;
        mDH06:
        $this->mG30P4YUkMM();
        goto GcIxe;
        OTSNQ:
        YxmTB:
        goto W3nGB;
        W3nGB:
    }
    private function m1y1NkE4RbW() : void
    {
        goto mPUgk;
        eGzLy:
        $hFrf7 = $this->xcd12->getFile();
        goto Yc8b1;
        jN9O1:
        OEPsr:
        goto YT3AE;
        hhwxR:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($hFrf7->id);
        goto jN9O1;
        Yc8b1:
        $hFrf7->mvlhr18w6fy(FdWrko7bmoI4Y::UPLOADED);
        goto V2T0m;
        mPUgk:
        $this->eWA8h->mExpa4HytOM();
        goto eGzLy;
        V2T0m:
        if (!$hFrf7 instanceof MbOYV1VlUGCys) {
            goto OEPsr;
        }
        goto hhwxR;
        YT3AE:
    }
    private function m991obJTywq() : void
    {
        $this->eWA8h->mGQrr1bb2uz();
    }
    private function m4wmtPZ0iZ9() : void
    {
        $this->eWA8h->mcbEWNLqf0J();
    }
}
