<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Contracts\Ey23NHBM8rqSI;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Core\Strategy\XZe9GJQSutcto;
use Jfs\Uploader\Core\Strategy\GuSN2fC476VWi;
use Jfs\Uploader\Encoder\Rwcm9mhsmq7Wv;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Service\L3oEPipUZv9oB;
final class Cfjbs9GHhe8pj implements Ey23NHBM8rqSI
{
    private $KwV10;
    private $AO_te;
    private $ifs25;
    private $GM8ih;
    public function __construct($nKKn0, $PQlIa, $NSs5T)
    {
        goto cSwQr;
        cSwQr:
        $this->AO_te = $nKKn0;
        goto S2xmx;
        S2xmx:
        $this->ifs25 = $PQlIa;
        goto FkAmP;
        FkAmP:
        $this->GM8ih = $NSs5T;
        goto mrQXg;
        mrQXg:
        $this->KwV10 = $this->mjBUZhjULrj();
        goto v6UEf;
        v6UEf:
    }
    public function myNnxL9T85B($TAUXh, $hgqT8) : void
    {
        goto xGC0e;
        rtbDz:
        ZhM_r:
        goto bPXhD;
        BSfLH:
        $this->KwV10->process($hgqT8);
        goto A9lxY;
        WppM1:
        $this->AO_te->save();
        goto HR3XW;
        Pf66x:
        if (!$this->KwV10) {
            goto qhPyq;
        }
        goto wHnXU;
        A9lxY:
        AG5VT:
        goto j4Txe;
        xGC0e:
        if (!(O8RzIjGmSN6fG::PROCESSING === $hgqT8)) {
            goto EjbQn;
        }
        goto WppM1;
        wHnXU:
        $this->KwV10->process($hgqT8);
        goto Pnvba;
        j4Txe:
        EjbQn:
        goto LEW1y;
        Pnvba:
        qhPyq:
        goto rtbDz;
        LEW1y:
        if (!(O8RzIjGmSN6fG::ENCODING_PROCESSED === $hgqT8)) {
            goto ZhM_r;
        }
        goto jcj1T;
        HR3XW:
        if (!$this->KwV10) {
            goto AG5VT;
        }
        goto BSfLH;
        jcj1T:
        $this->AO_te->save();
        goto Pf66x;
        bPXhD:
    }
    private function mjBUZhjULrj()
    {
        goto diI01;
        Rai4i:
        nhQCi:
        goto unD9b;
        diI01:
        switch ($this->AO_te->getType()) {
            case 'image':
                return new XZe9GJQSutcto($this->AO_te, $this->GM8ih);
            case 'video':
                return new GuSN2fC476VWi($this->AO_te, App::make(Rwcm9mhsmq7Wv::class));
            default:
                return null;
        }
        goto pA_sn;
        pA_sn:
        W7dKD:
        goto Rai4i;
        unD9b:
    }
}
