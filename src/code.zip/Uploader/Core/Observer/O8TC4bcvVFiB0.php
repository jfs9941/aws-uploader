<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:11              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Contracts\YhOLLtTXuTxXo;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
class O8TC4bcvVFiB0 implements YhOLLtTXuTxXo
{
    private $i_qo1;
    public function __construct($FJFJj)
    {
        $this->i_qo1 = $FJFJj;
    }
    public function mW0P3SBpyXg($pin6L, $SPhmg)
    {
        goto LPqyq;
        Va9QE:
        $this->i_qo1->delete();
        goto ZBiNm;
        rroBy:
        if (!(EXecNg2hg7kwl::DELETED === $SPhmg && $this->i_qo1->mNHdgR2nlsA())) {
            goto M3JFD;
        }
        goto Va9QE;
        I1qV1:
        $this->i_qo1->save();
        goto c_oME;
        Ubs4o:
        NEpnn:
        goto I1qV1;
        Ne4FJ:
        if (!$this->i_qo1 instanceof S7LEoIprYtLQw) {
            goto NEpnn;
        }
        goto UurEW;
        UurEW:
        $this->i_qo1->m7ddHwazacD(EXecNg2hg7kwl::PROCESSING);
        goto Ubs4o;
        LPqyq:
        if (!(EXecNg2hg7kwl::UPLOADED === $SPhmg)) {
            goto Dp4JU;
        }
        goto pJB9u;
        c_oME:
        Dp4JU:
        goto rroBy;
        ZBiNm:
        M3JFD:
        goto CACVy;
        pJB9u:
        $this->i_qo1->status = EXecNg2hg7kwl::UPLOADED;
        goto Ne4FJ;
        CACVy:
    }
}
