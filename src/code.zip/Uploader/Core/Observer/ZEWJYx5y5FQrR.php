<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\IlXdNMxZGcSoS;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Exception\CBStNIBT6cwK0;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Presigned\Olsqvb4sy7cqu;
use Jfs\Uploader\Presigned\VuHD7PYgLuooE;
use Illuminate\Support\Facades\Log;
final class ZEWJYx5y5FQrR implements IlXdNMxZGcSoS
{
    private $Eeys2;
    private $LILxj;
    private $q6zCU;
    private $NTZHy;
    private $xhfp2;
    public function __construct($wJPdj, $zDbHT, $pbv6a, $C1Y4p, $cC2jv = false)
    {
        goto cCWX3;
        uMlfv:
        $this->NTZHy = $pbv6a;
        goto lCj2g;
        EgCDB:
        vlddn:
        goto LI2gZ;
        O62wG:
        $this->mVYe9knLU2x();
        goto EgCDB;
        GYjiE:
        $this->q6zCU = $zDbHT;
        goto uMlfv;
        lCj2g:
        $this->xhfp2 = $C1Y4p;
        goto QEjB3;
        cCWX3:
        $this->LILxj = $wJPdj;
        goto GYjiE;
        QEjB3:
        if ($cC2jv) {
            goto vlddn;
        }
        goto O62wG;
        LI2gZ:
    }
    private function mVYe9knLU2x() : void
    {
        goto rI1oT;
        z0BM7:
        pXhom:
        goto CHk2i;
        CHk2i:
        try {
            $OFuou = $this->LILxj->m67klYkiadk();
            $this->Eeys2 = 's3' === $OFuou->driver ? new VuHD7PYgLuooE($this->LILxj, $this->q6zCU, $this->NTZHy, $this->xhfp2) : new Olsqvb4sy7cqu($this->LILxj, $this->q6zCU, $this->NTZHy);
        } catch (SLsozGEgkOpxH $VJRSZ) {
            Log::warning("Failed to set up presigned upload: {$VJRSZ->getMessage()}");
        }
        goto OZgcD;
        dktqC:
        return;
        goto z0BM7;
        rI1oT:
        if (!(null !== $this->Eeys2)) {
            goto pXhom;
        }
        goto dktqC;
        OZgcD:
    }
    public function mZowOLQCS3i($PcLOc, $Kkroe)
    {
        goto gXCxc;
        vB2D_:
        switch ($Kkroe) {
            case M7O7NSiJU2JG5::UPLOADING:
                $this->m9QtTQkTCJD();
                goto zlhpT;
            case M7O7NSiJU2JG5::UPLOADED:
                $this->mWrayVrTmA9();
                goto zlhpT;
            case M7O7NSiJU2JG5::ABORTED:
                $this->mtCiyNx8PwO();
                goto zlhpT;
            default:
                goto zlhpT;
        }
        goto uv3f6;
        gXCxc:
        $this->mVYe9knLU2x();
        goto vB2D_;
        PrIOX:
        zlhpT:
        goto G_xlr;
        uv3f6:
        t5ry_:
        goto PrIOX;
        G_xlr:
    }
    private function mWrayVrTmA9() : void
    {
        goto lLux0;
        Vz09A:
        $Z5ydB->mpDdU9lVtpc(M7O7NSiJU2JG5::PROCESSING);
        goto NVxiG;
        NVxiG:
        pwUgB:
        goto quvfP;
        XkANm:
        $Z5ydB->mpDdU9lVtpc(M7O7NSiJU2JG5::UPLOADED);
        goto eiL0N;
        eiL0N:
        if (!$Z5ydB instanceof UYo98bF5lKEmO) {
            goto pwUgB;
        }
        goto rtU9T;
        rtU9T:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($Z5ydB->id);
        goto Vz09A;
        QAjWV:
        $Z5ydB = $this->LILxj->getFile();
        goto XkANm;
        lLux0:
        $this->Eeys2->mtyEvCKHi25();
        goto QAjWV;
        quvfP:
    }
    private function mtCiyNx8PwO() : void
    {
        $this->Eeys2->m7mAhDQTm1t();
    }
    private function m9QtTQkTCJD() : void
    {
        $this->Eeys2->mQwILMgE5G0();
    }
}
