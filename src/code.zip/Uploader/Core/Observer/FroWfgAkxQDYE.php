<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Contracts\RoTpJhiFhvlTg;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class FroWfgAkxQDYE implements RoTpJhiFhvlTg
{
    private $cyroT;
    public function __construct($a3XOL)
    {
        $this->cyroT = $a3XOL;
    }
    public function mM5x0654DhR($EIAGD, $UeOhO)
    {
        goto x7X3E;
        sy8dO:
        IZRWb:
        goto G4JOA;
        pp3M5:
        $this->cyroT->mGQfJhYWpvR(RwOJkCXwa9RQz::PROCESSING);
        goto sy8dO;
        BIfXd:
        $this->cyroT->delete();
        goto vUawt;
        rvAzs:
        $this->cyroT->status = RwOJkCXwa9RQz::UPLOADED;
        goto ryqvF;
        ryqvF:
        if (!$this->cyroT instanceof LGMw063tEE9ZC) {
            goto IZRWb;
        }
        goto pp3M5;
        mKkqg:
        if (!(RwOJkCXwa9RQz::DELETED === $UeOhO && $this->cyroT->maEByPHoAHv())) {
            goto BGEBa;
        }
        goto BIfXd;
        vUawt:
        BGEBa:
        goto GgV2q;
        G4JOA:
        $this->cyroT->save();
        goto Lia2p;
        Lia2p:
        EuQ0c:
        goto mKkqg;
        x7X3E:
        if (!(RwOJkCXwa9RQz::UPLOADED === $UeOhO)) {
            goto EuQ0c;
        }
        goto rvAzs;
        GgV2q:
    }
}
