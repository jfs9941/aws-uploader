<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Contracts\Zw8MUfOdDRfcx;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
class B24zI37icS20t implements Zw8MUfOdDRfcx
{
    private $LXD2P;
    public function __construct($VslFR)
    {
        $this->LXD2P = $VslFR;
    }
    public function mHzEGxfe0qf($ADQei, $wbuog)
    {
        goto KAqvj;
        Gawng:
        $this->LXD2P->m6ASJ5S5Ktp(T93Mcsw1gA3an::PROCESSING);
        goto D0kEA;
        D0kEA:
        DRVq0:
        goto yDybv;
        MTKi6:
        if (!(T93Mcsw1gA3an::DELETED === $wbuog && $this->LXD2P->mC8wY3yRBEY())) {
            goto PRunL;
        }
        goto jPtFw;
        yDybv:
        $this->LXD2P->save();
        goto HgcK6;
        qizYk:
        $this->LXD2P->status = T93Mcsw1gA3an::UPLOADED;
        goto NnOk4;
        KAqvj:
        if (!(T93Mcsw1gA3an::UPLOADED === $wbuog)) {
            goto WBlkV;
        }
        goto qizYk;
        SHoFz:
        PRunL:
        goto y6wMm;
        jPtFw:
        $this->LXD2P->delete();
        goto SHoFz;
        HgcK6:
        WBlkV:
        goto MTKi6;
        NnOk4:
        if (!$this->LXD2P instanceof D6FgZi8OHmjic) {
            goto DRVq0;
        }
        goto Gawng;
        y6wMm:
    }
}
