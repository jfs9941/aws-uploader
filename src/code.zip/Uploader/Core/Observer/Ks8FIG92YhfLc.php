<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Contracts\WsCsRu4iqCZ5i;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\Strategy\XZV8BmuEtF6vQ;
use Jfs\Uploader\Core\Strategy\OWUwvan4nBiqE;
use Jfs\Uploader\Encoder\FKhlIfmeSlJUJ;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Service\TUSrCGJanJHY8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Ks8FIG92YhfLc implements WsCsRu4iqCZ5i
{
    private $xpwog;
    private $tp12K;
    private $ZN9hu;
    private $CV_ZV;
    public function __construct($DejZC, $C2YXG, $bJnIM)
    {
        goto jW5BD;
        tqywd:
        $this->ZN9hu = $C2YXG;
        goto aA1aa;
        uMtXU:
        $this->xpwog = $this->mb9plMkf7nW();
        goto mp4da;
        aA1aa:
        $this->CV_ZV = $bJnIM;
        goto uMtXU;
        jW5BD:
        $this->tp12K = $DejZC;
        goto tqywd;
        mp4da:
    }
    public function mz4knromh2J($s8PR0, $sNTGc) : void
    {
        goto PPYRZ;
        qfRcU:
        $this->xpwog->process($sNTGc);
        goto QSvmz;
        Qd93A:
        $this->xpwog->process($sNTGc);
        goto lzACj;
        Il6Uc:
        if (!$this->xpwog) {
            goto zotEg;
        }
        goto qfRcU;
        TbgLy:
        $this->tp12K->save();
        goto mzTxJ;
        mq1uS:
        $this->tp12K->save();
        goto Il6Uc;
        lzACj:
        hcs0S:
        goto BunzB;
        BunzB:
        ilJO3:
        goto bspsH;
        mzTxJ:
        if (!$this->xpwog) {
            goto hcs0S;
        }
        goto Qd93A;
        QSvmz:
        zotEg:
        goto G7e1a;
        PPYRZ:
        if (!(Xy3InMky6jKYf::PROCESSING === $sNTGc)) {
            goto zeTsa;
        }
        goto mq1uS;
        GSuQg:
        if (!(Xy3InMky6jKYf::ENCODING_PROCESSED === $sNTGc)) {
            goto ilJO3;
        }
        goto TbgLy;
        G7e1a:
        zeTsa:
        goto GSuQg;
        bspsH:
    }
    private function mb9plMkf7nW()
    {
        goto uGQox;
        uGQox:
        switch ($this->tp12K->getType()) {
            case 'image':
                return new XZV8BmuEtF6vQ($this->tp12K, $this->CV_ZV);
            case 'video':
                return new OWUwvan4nBiqE($this->tp12K, App::make(FKhlIfmeSlJUJ::class));
            default:
                return null;
        }
        goto FllHY;
        FllHY:
        u7ZUP:
        goto JJ8Uj;
        JJ8Uj:
        p3ILx:
        goto VN7jw;
        VN7jw:
    }
}
