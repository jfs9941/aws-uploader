<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Contracts\K6rnLmlRKxy9W;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Core\Strategy\EBfSO1ZkWIFLn;
use Jfs\Uploader\Core\Strategy\MFtcB3AJm60OI;
use Jfs\Uploader\Encoder\R1OfWFis73GHj;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Service\BDt6SdH8IQ07z;
final class IASUYv8MKeNRq implements K6rnLmlRKxy9W
{
    private $ZnPcG;
    private $nIFfY;
    private $auR_S;
    private $czzDp;
    public function __construct($QuYzZ, $JhAxH, $KKAWP)
    {
        goto VuLl1;
        t0DTa:
        $this->auR_S = $JhAxH;
        goto U9XYs;
        U9XYs:
        $this->czzDp = $KKAWP;
        goto ag5d_;
        VuLl1:
        $this->nIFfY = $QuYzZ;
        goto t0DTa;
        ag5d_:
        $this->ZnPcG = $this->mDhz8bRU8mE();
        goto NWpaG;
        NWpaG:
    }
    public function mYTLHr2vX9t($WVkJm, $CQyva) : void
    {
        goto SoRu3;
        oHHtF:
        $this->nIFfY->save();
        goto Z6ZNS;
        Z6ZNS:
        if (!$this->ZnPcG) {
            goto Kk_SD;
        }
        goto kYqej;
        SoRu3:
        if (!(QoCMzcKvH8Cw2::PROCESSING === $CQyva)) {
            goto Mgx5O;
        }
        goto sO5cD;
        MmVKs:
        Mgx5O:
        goto H_uvw;
        xEKJW:
        Kk_SD:
        goto pKZ3w;
        sO5cD:
        $this->nIFfY->save();
        goto J2qKv;
        kYqej:
        $this->ZnPcG->process($CQyva);
        goto xEKJW;
        H_uvw:
        if (!(QoCMzcKvH8Cw2::ENCODING_PROCESSED === $CQyva)) {
            goto Uz0HL;
        }
        goto oHHtF;
        Iiqb_:
        $this->ZnPcG->process($CQyva);
        goto KXLGN;
        pKZ3w:
        Uz0HL:
        goto WX5WR;
        KXLGN:
        Q7fXg:
        goto MmVKs;
        J2qKv:
        if (!$this->ZnPcG) {
            goto Q7fXg;
        }
        goto Iiqb_;
        WX5WR:
    }
    private function mDhz8bRU8mE()
    {
        goto X3fvH;
        xmJI7:
        ZzwrR:
        goto VC1SX;
        X3fvH:
        switch ($this->nIFfY->getType()) {
            case 'image':
                return new EBfSO1ZkWIFLn($this->nIFfY, $this->czzDp);
            case 'video':
                return new MFtcB3AJm60OI($this->nIFfY, App::make(R1OfWFis73GHj::class));
            default:
                return null;
        }
        goto Yq1Po;
        Yq1Po:
        otz0H:
        goto xmJI7;
        VC1SX:
    }
}
