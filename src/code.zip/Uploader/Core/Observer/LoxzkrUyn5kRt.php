<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Contracts\PdBd5D8IKDopT;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class LoxzkrUyn5kRt implements PdBd5D8IKDopT
{
    private $IJ6tP;
    public function __construct($rQ18B)
    {
        $this->IJ6tP = $rQ18B;
    }
    public function mht82bQ4KnY($iydej, $GbrlI)
    {
        goto shaj7;
        VJfN_:
        $this->IJ6tP->status = SwAwanZG36Yx6::UPLOADED;
        goto U1749;
        TrsmN:
        $this->IJ6tP->delete();
        goto xBrAq;
        hZiSQ:
        $this->IJ6tP->save();
        goto S9Ku7;
        hp4t9:
        exE1K:
        goto hZiSQ;
        S9Ku7:
        UL3r4:
        goto WGiXO;
        shaj7:
        if (!(SwAwanZG36Yx6::UPLOADED === $GbrlI)) {
            goto UL3r4;
        }
        goto VJfN_;
        U1749:
        if (!$this->IJ6tP instanceof DsyQbNiy8VgJG) {
            goto exE1K;
        }
        goto SkHoa;
        SkHoa:
        $this->IJ6tP->mZecThKyfk1(SwAwanZG36Yx6::PROCESSING);
        goto hp4t9;
        xBrAq:
        YV5Pb:
        goto ekNXd;
        WGiXO:
        if (!(SwAwanZG36Yx6::DELETED === $GbrlI && $this->IJ6tP->mDYa9DI0nlR())) {
            goto YV5Pb;
        }
        goto TrsmN;
        ekNXd:
    }
}
