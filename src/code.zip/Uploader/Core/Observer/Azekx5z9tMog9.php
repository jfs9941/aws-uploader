<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\WsCsRu4iqCZ5i;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Exception\BC4l4MMxB4wtt;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Presigned\F00t7QHnGzEry;
use Jfs\Uploader\Presigned\AUiO06M3Su7m7;
use Illuminate\Support\Facades\Log;
final class Azekx5z9tMog9 implements WsCsRu4iqCZ5i
{
    private $TiLog;
    private $M2ERX;
    private $GUhIK;
    private $bBnq9;
    private $tA7Ds;
    public function __construct($TtzPI, $kGo1c, $k6y5k, $EcbH3, $Y8gc_ = false)
    {
        goto WFozl;
        qgCzn:
        $this->GUhIK = $kGo1c;
        goto xLlwl;
        xLlwl:
        $this->bBnq9 = $k6y5k;
        goto G0Wj1;
        G0Wj1:
        $this->tA7Ds = $EcbH3;
        goto hkqhp;
        TXoc4:
        B_fDt:
        goto ooLHw;
        pC9p4:
        $this->mCpMVvsCNE3();
        goto TXoc4;
        WFozl:
        $this->M2ERX = $TtzPI;
        goto qgCzn;
        hkqhp:
        if ($Y8gc_) {
            goto B_fDt;
        }
        goto pC9p4;
        ooLHw:
    }
    private function mCpMVvsCNE3() : void
    {
        goto MwGrE;
        TGjn7:
        zGwIV:
        goto xf3b9;
        o13_O:
        return;
        goto TGjn7;
        xf3b9:
        try {
            $i4bQp = $this->M2ERX->mu6Z5XKe7fC();
            $this->TiLog = 's3' === $i4bQp->mb9Ag ? new AUiO06M3Su7m7($this->M2ERX, $this->GUhIK, $this->bBnq9, $this->tA7Ds) : new F00t7QHnGzEry($this->M2ERX, $this->GUhIK, $this->bBnq9);
        } catch (Pl4WlsTHZq9V7 $IGLS9) {
            Log::warning("Failed to set up presigned upload: {$IGLS9->getMessage()}");
        }
        goto pTrxY;
        MwGrE:
        if (!(null !== $this->TiLog)) {
            goto zGwIV;
        }
        goto o13_O;
        pTrxY:
    }
    public function mz4knromh2J($s8PR0, $sNTGc)
    {
        goto vDsXG;
        ii7tC:
        zg0X5:
        goto KSJ27;
        KSJ27:
        tULqZ:
        goto cA21s;
        vABFK:
        switch ($sNTGc) {
            case Xy3InMky6jKYf::UPLOADING:
                $this->mDU9QckWele();
                goto tULqZ;
            case Xy3InMky6jKYf::UPLOADED:
                $this->mgFoHSomQbY();
                goto tULqZ;
            case Xy3InMky6jKYf::ABORTED:
                $this->mbxy2WuyAI5();
                goto tULqZ;
            default:
                goto tULqZ;
        }
        goto ii7tC;
        vDsXG:
        $this->mCpMVvsCNE3();
        goto vABFK;
        cA21s:
    }
    private function mgFoHSomQbY() : void
    {
        goto i3cm2;
        i3cm2:
        $this->TiLog->mbcBVUFS35t();
        goto Ib8Yl;
        QBAfx:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($DejZC->id);
        goto l4_60;
        l4_60:
        ijAQW:
        goto kyQgJ;
        tI8pP:
        if (!$DejZC instanceof WrCq6RmnGcVh7) {
            goto ijAQW;
        }
        goto QBAfx;
        Ib8Yl:
        $DejZC = $this->M2ERX->getFile();
        goto dNH3J;
        dNH3J:
        $DejZC->mAPPeV3mHXi(Xy3InMky6jKYf::UPLOADED);
        goto tI8pP;
        kyQgJ:
    }
    private function mbxy2WuyAI5() : void
    {
        $this->TiLog->mc7M89BR07U();
    }
    private function mDU9QckWele() : void
    {
        $this->TiLog->mIiANiKKpuc();
    }
}
