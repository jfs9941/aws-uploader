<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\CPWst5X7YKGnu;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Exception\LiA5BOk62pit2;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Jfs\Uploader\Presigned\NA9yEEgVNld2F;
use Jfs\Uploader\Presigned\LdHjYTqdMUKPp;
final class Of8oIVHk5MhTm implements CPWst5X7YKGnu
{
    private $ScVwp;
    private $EnwSG;
    private $x0wV5;
    private $f3yJU;
    private $q3TFM;
    public function __construct($UEurj, $mHTSY, $RUQUm, $ahaqc, $JILr4 = false)
    {
        goto QIQwf;
        oETeb:
        jDbzm:
        goto xZw2W;
        xwjXG:
        $this->x0wV5 = $mHTSY;
        goto QTp4q;
        qjHwD:
        if ($JILr4) {
            goto jDbzm;
        }
        goto b5FAe;
        b5FAe:
        $this->mQqZbpb7W1j();
        goto oETeb;
        QIQwf:
        $this->EnwSG = $UEurj;
        goto xwjXG;
        EzrUe:
        $this->q3TFM = $ahaqc;
        goto qjHwD;
        QTp4q:
        $this->f3yJU = $RUQUm;
        goto EzrUe;
        xZw2W:
    }
    private function mQqZbpb7W1j() : void
    {
        goto Qh_bD;
        kme9W:
        ZImhh:
        goto F2Gor;
        Qh_bD:
        if (!(null !== $this->ScVwp)) {
            goto ZImhh;
        }
        goto Q7gDo;
        Q7gDo:
        return;
        goto kme9W;
        F2Gor:
        try {
            $RHxcL = $this->EnwSG->mCZg2QiXqrg();
            $this->ScVwp = 's3' === $RHxcL->LjaQU ? new LdHjYTqdMUKPp($this->EnwSG, $this->x0wV5, $this->f3yJU, $this->q3TFM) : new NA9yEEgVNld2F($this->EnwSG, $this->x0wV5, $this->f3yJU);
        } catch (KzbSFcd7qiwCv $L1ZUQ) {
            Log::warning("Failed to set up presigned upload: {$L1ZUQ->getMessage()}");
        }
        goto PHG_P;
        PHG_P:
    }
    public function mLulwBaR29t($gJXBQ, $snzZr)
    {
        goto m4Rms;
        Ct7G6:
        switch ($snzZr) {
            case OLX71luAn6XnP::UPLOADING:
                $this->mJ2qIJwczqF();
                goto cEYP0;
            case OLX71luAn6XnP::UPLOADED:
                $this->mO0p4SQ2kxH();
                goto cEYP0;
            case OLX71luAn6XnP::ABORTED:
                $this->mEnfO4PXKVm();
                goto cEYP0;
            default:
                goto cEYP0;
        }
        goto Yyve4;
        jO42g:
        cEYP0:
        goto hUfWx;
        Yyve4:
        NRnsv:
        goto jO42g;
        m4Rms:
        $this->mQqZbpb7W1j();
        goto Ct7G6;
        hUfWx:
    }
    private function mO0p4SQ2kxH() : void
    {
        goto Jv2lB;
        I563Z:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($oYtbp->id);
        goto rxBdd;
        lPTU5:
        if (!$oYtbp instanceof SmhkgG6le5p0r) {
            goto mBjRO;
        }
        goto I563Z;
        Pegm_:
        $oYtbp = $this->EnwSG->getFile();
        goto TRRkJ;
        TRRkJ:
        $oYtbp->m3irf1LtLKT(OLX71luAn6XnP::UPLOADED);
        goto lPTU5;
        Jv2lB:
        $this->ScVwp->mbH20YCpKPX();
        goto Pegm_;
        rxBdd:
        mBjRO:
        goto sZT8T;
        sZT8T:
    }
    private function mEnfO4PXKVm() : void
    {
        $this->ScVwp->mZjmY4OFlvN();
    }
    private function mJ2qIJwczqF() : void
    {
        $this->ScVwp->mEnKsi71Uji();
    }
}
