<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Contracts\Iy5htSHK04ggf;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\Strategy\Pw8uwY5BPYnmQ;
use Jfs\Uploader\Core\Strategy\CsSewZOIQwj5O;
use Jfs\Uploader\Encoder\Q0BHItA6POhGn;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Service\KA9RxVwCbkfZQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class LWyHsnHVJ7f6T implements Iy5htSHK04ggf
{
    private $L4mN6;
    private $wM7km;
    private $VJN91;
    private $jYPwH;
    public function __construct($K9DZL, $J83Op, $RxjAn)
    {
        goto gz6lC;
        BcbYg:
        $this->VJN91 = $J83Op;
        goto cVWet;
        cVWet:
        $this->jYPwH = $RxjAn;
        goto PvQeR;
        gz6lC:
        $this->wM7km = $K9DZL;
        goto BcbYg;
        PvQeR:
        $this->L4mN6 = $this->mcdx8FMas2s();
        goto jG1Lw;
        jG1Lw:
    }
    public function mSJMv13z3kQ($bwPdj, $VpAJm) : void
    {
        goto qAoeN;
        JD2ix:
        g_17m:
        goto O2pQq;
        GSRYw:
        if (!(GlPuUJKmzwUJ9::ENCODING_PROCESSED === $VpAJm)) {
            goto OlQXw;
        }
        goto TYWFm;
        BUgBR:
        QNwR5:
        goto xWiw3;
        z7_oN:
        $this->L4mN6->process($VpAJm);
        goto JD2ix;
        O2pQq:
        QMBVT:
        goto GSRYw;
        TYWFm:
        $this->wM7km->save();
        goto dCLGP;
        SrcyJ:
        if (!$this->L4mN6) {
            goto g_17m;
        }
        goto z7_oN;
        dCLGP:
        if (!$this->L4mN6) {
            goto QNwR5;
        }
        goto Dj94x;
        Dj94x:
        $this->L4mN6->process($VpAJm);
        goto BUgBR;
        qAoeN:
        if (!(GlPuUJKmzwUJ9::PROCESSING === $VpAJm)) {
            goto QMBVT;
        }
        goto HpXAI;
        xWiw3:
        OlQXw:
        goto c2Lw1;
        HpXAI:
        $this->wM7km->save();
        goto SrcyJ;
        c2Lw1:
    }
    private function mcdx8FMas2s()
    {
        goto I8icp;
        acsCh:
        NKluV:
        goto RsZCP;
        I8icp:
        switch ($this->wM7km->getType()) {
            case 'image':
                return new Pw8uwY5BPYnmQ($this->wM7km, $this->jYPwH);
            case 'video':
                return new CsSewZOIQwj5O($this->wM7km, App::make(Q0BHItA6POhGn::class));
            default:
                return null;
        }
        goto Y2Fh1;
        Y2Fh1:
        y5D6J:
        goto acsCh;
        RsZCP:
    }
}
