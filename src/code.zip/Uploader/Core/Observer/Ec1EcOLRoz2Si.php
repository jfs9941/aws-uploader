<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Observer;

use Illuminate\Support\Facades\App;
use src\Uploader\Contracts\F5Xo0te9A5R68;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\Strategy\E17tjeR7Ux3Qs;
use src\Uploader\Core\Strategy\FahkO6qLuMX0f;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Encoder\CqIfz7C8PXyW1;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Service\BVykbOopwUKwx;
final class Ec1EcOLRoz2Si implements F5Xo0te9A5R68
{
    private $XQM4P;
    private $dfQse;
    private $Aj6QZ;
    private $o5A8A;
    public function __construct($d1aiC, $SaekO, $VtGhn)
    {
        goto d6B0y;
        g83oJ:
        $this->o5A8A = $VtGhn;
        goto IUgnk;
        d6B0y:
        $this->dfQse = $d1aiC;
        goto tOEHP;
        IUgnk:
        $this->XQM4P = $this->m1q8pBsM7et();
        goto aCKL2;
        tOEHP:
        $this->Aj6QZ = $SaekO;
        goto g83oJ;
        aCKL2:
    }
    public function myVaRYzH5cA($oCcYR, $nz0Xr) : void
    {
        goto w7hhc;
        K_Jrj:
        $this->dfQse->save();
        goto iz3ml;
        w7hhc:
        if (!(FileStatus::PROCESSING === $nz0Xr)) {
            goto ufsU8;
        }
        goto K_Jrj;
        xqBUZ:
        dpLcN:
        goto gZxeN;
        xBjTA:
        $this->XQM4P->process($nz0Xr);
        goto xqBUZ;
        fLLn4:
        if (!(FileStatus::ENCODING_PROCESSED === $nz0Xr)) {
            goto NIreo;
        }
        goto TiOb_;
        gZxeN:
        ufsU8:
        goto fLLn4;
        yZVsb:
        $this->XQM4P->process($nz0Xr);
        goto iYK7Q;
        TiOb_:
        $this->dfQse->save();
        goto qpEyg;
        qpEyg:
        if (!$this->XQM4P) {
            goto XMW1o;
        }
        goto yZVsb;
        iYK7Q:
        XMW1o:
        goto u2phm;
        u2phm:
        NIreo:
        goto latZu;
        iz3ml:
        if (!$this->XQM4P) {
            goto dpLcN;
        }
        goto xBjTA;
        latZu:
    }
    private function m1q8pBsM7et()
    {
        goto GWARV;
        mlD5H:
        yg3uQ:
        goto mdsMB;
        GWARV:
        switch ($this->dfQse->getType()) {
            case 'image':
                return new FahkO6qLuMX0f($this->dfQse, $this->o5A8A);
            case 'video':
                return new E17tjeR7Ux3Qs($this->dfQse, App::make(CqIfz7C8PXyW1::class));
            default:
                return null;
        }
        goto mlD5H;
        mdsMB:
        CNIo5:
        goto r55qp;
        r55qp:
    }
}
