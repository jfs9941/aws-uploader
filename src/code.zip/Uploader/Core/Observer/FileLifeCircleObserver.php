<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Contracts\StateChangeObserverInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Enum\FileStatus;

class FileLifeCircleObserver implements StateChangeObserverInterface
{
    /** @var BaseFileModel|FileStateInterface */
    private $file;

    public function __construct($file)
    {
        $this->file = $file;
    }

    public function onStateChange($fromState, $toState)
    {
        if (FileStatus::UPLOADED === $toState) {
            $this->file->status = FileStatus::UPLOADED;
            if ($this->file instanceof Image) {
                $this->file->transitionTo(FileStatus::PROCESSING);
            }
            $this->file->save();
        }

        if (FileStatus::DELETED === $toState && $this->file->canDelete()) {
            $this->file->delete();
        }
    }
}
