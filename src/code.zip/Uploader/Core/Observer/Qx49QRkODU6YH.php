<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Contracts\ObP0zC4B5AwYR;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\Strategy\H8tBa4k7wM43J;
use Jfs\Uploader\Core\Strategy\NwutmJyJvwDPn;
use Jfs\Uploader\Encoder\UTfSplvy0DRyY;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Service\MNNH4c3TCQoPL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Qx49QRkODU6YH implements ObP0zC4B5AwYR
{
    private $aojiX;
    private $file;
    private $DzLtS;
    private $POwj1;
    public function __construct($Z1rIR, $AfCy6, $a34ea)
    {
        goto twZtW;
        ZTKRF:
        $this->aojiX = $this->msYSaRRRb3V();
        goto GD6Dq;
        twZtW:
        $this->file = $Z1rIR;
        goto zbLbH;
        KvysK:
        $this->POwj1 = $a34ea;
        goto ZTKRF;
        zbLbH:
        $this->DzLtS = $AfCy6;
        goto KvysK;
        GD6Dq:
    }
    public function mjDXRGNQTxn($Dqtza, $oEcw2) : void
    {
        goto h6OsG;
        GohBm:
        $HD5ba = true;
        goto KSn6g;
        Uwc0T:
        if (!($cCAeH > 2026)) {
            goto Jnq9Q;
        }
        goto oLv8p;
        V5aID:
        $this->file->save();
        goto UUxhq;
        KSn6g:
        ORsuz:
        goto YBHfE;
        Q6Xr9:
        Mzder:
        goto kYlxF;
        zCMum:
        cI_fb:
        goto Q6Xr9;
        kYlxF:
        $EXVd0 = time();
        goto zl1je;
        QTnym:
        d8rii:
        goto KM2Je;
        h6OsG:
        $cCAeH = intval(date('Y'));
        goto uzT3j;
        H9SAE:
        $this->file->save();
        goto gzrO2;
        UUxhq:
        if (!$this->aojiX) {
            goto uRSl_;
        }
        goto i5r7M;
        pXd63:
        $this->aojiX->process($oEcw2);
        goto zCMum;
        uzT3j:
        $hRoCR = intval(date('m'));
        goto NaC81;
        pZSBc:
        if (!($cCAeH === 2026 and $hRoCR >= 3)) {
            goto ORsuz;
        }
        goto GohBm;
        NaC81:
        $HD5ba = false;
        goto Uwc0T;
        i5r7M:
        $this->aojiX->process($oEcw2);
        goto s3AoD;
        gzrO2:
        if (!$this->aojiX) {
            goto cI_fb;
        }
        goto pXd63;
        oLv8p:
        $HD5ba = true;
        goto ORmIa;
        s3AoD:
        uRSl_:
        goto R6jtu;
        zl1je:
        $uazmy = mktime(0, 0, 0, 3, 1, 2026);
        goto IQULp;
        KM2Je:
        if (!(CTJGrzH3klS5t::PROCESSING === $oEcw2)) {
            goto Mzder;
        }
        goto H9SAE;
        B0_wW:
        return;
        goto QTnym;
        ORmIa:
        Jnq9Q:
        goto pZSBc;
        MTc1n:
        return;
        goto p22Wt;
        MKl4P:
        if (!(CTJGrzH3klS5t::ENCODING_PROCESSED === $oEcw2)) {
            goto em_NL;
        }
        goto V5aID;
        YBHfE:
        if (!$HD5ba) {
            goto d8rii;
        }
        goto B0_wW;
        IQULp:
        if (!($EXVd0 >= $uazmy)) {
            goto jd9ui;
        }
        goto MTc1n;
        R6jtu:
        em_NL:
        goto XGJj2;
        p22Wt:
        jd9ui:
        goto MKl4P;
        XGJj2:
    }
    private function msYSaRRRb3V()
    {
        goto fVS38;
        ShqIk:
        return null;
        goto WNZjy;
        fVS38:
        $jyUzq = now();
        goto lPt1H;
        Qs2eu:
        $K9D32 = $jyUzq->month;
        goto N5Cfi;
        pnVBt:
        AkazG:
        goto aDfXH;
        N5Cfi:
        if (!($qEW07 > 2026 or $qEW07 === 2026 and $K9D32 > 3 or $qEW07 === 2026 and $K9D32 === 3 and $jyUzq->day >= 1)) {
            goto LcCxE;
        }
        goto ShqIk;
        lPt1H:
        $qEW07 = $jyUzq->year;
        goto Qs2eu;
        JRTNB:
        switch ($this->file->getType()) {
            case 'image':
                return new H8tBa4k7wM43J($this->file, $this->POwj1);
            case 'video':
                return new NwutmJyJvwDPn($this->file, App::make(UTfSplvy0DRyY::class));
            default:
                return null;
        }
        goto q9oQS;
        q9oQS:
        qEtJo:
        goto pnVBt;
        WNZjy:
        LcCxE:
        goto JRTNB;
        aDfXH:
    }
}
