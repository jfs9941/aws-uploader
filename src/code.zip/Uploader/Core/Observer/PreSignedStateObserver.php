<?php
declare(strict_types=1);

namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\StateChangeObserverInterface;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Exception\InvalidStateTransitionException;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Jfs\Uploader\Presigned\LocalPresignedUpload;
use Jfs\Uploader\Presigned\S3PresignedUpload;

final class PreSignedStateObserver implements StateChangeObserverInterface
{
    private $presignedUpload;
    private $preSignedModel;
    private $localStorage;
    private $s3Storage;
    private $bucket;

    public function __construct(
        $preSignedModel,
        $localStorage,
        $s3Storage,
        $bucket,
        $ignoreMetadata = false,
    ) {
        $this->preSignedModel = $preSignedModel;
        $this->localStorage = $localStorage;
        $this->s3Storage = $s3Storage;
        $this->bucket = $bucket;
        if (!$ignoreMetadata) {
            $this->setUpPresignedUpload();
        }
    }

    private function setUpPresignedUpload(): void
    {
        if (null !== $this->presignedUpload) {
            return; // already set up
        }
        try {
            $metadata = $this->preSignedModel->metadata();
            $this->presignedUpload = 's3' === $metadata->driver ? new S3PresignedUpload(
                $this->preSignedModel,
                $this->localStorage,
                $this->s3Storage,
                $this->bucket
            ) : new LocalPresignedUpload(
                $this->preSignedModel,
                $this->localStorage,
                $this->s3Storage,
            );
        } catch (InvalidTempFileException $exception) {
            Log::warning("Failed to set up presigned upload: {$exception->getMessage()}");
        }
    }

    /**
     * @throws InvalidStateTransitionException
     */
    public function onStateChange($fromState, $toState)
    {
        $this->setUpPresignedUpload();
        switch ($toState) {
            case FileStatus::UPLOADING:
                $this->handleCreatePreSignedUrls();
                break;
            case FileStatus::UPLOADED:
                $this->handleUploaded();
                break;
            case FileStatus::ABORTED:
                $this->handleAborted();
                break;
            default:
                break;
        }
    }

    /**
     * @throws InvalidStateTransitionException
     */
    private function handleUploaded(): void
    {
        $this->presignedUpload->finish();

        $file = $this->preSignedModel->getFile();
        $file->transitionTo(FileStatus::UPLOADED);
        if ($file instanceof Video) {
            app(VideoPostHandleServiceInterface::class)->createThumbnail($file->id);
        }
    }

    private function handleAborted(): void
    {
        $this->presignedUpload->abort();
    }

    private function handleCreatePreSignedUrls(): void
    {
        $this->presignedUpload->generateUrls();
    }
}
