<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Contracts\QnQF56ZOfQE7U;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
class OIvzAwPhFJac5 implements QnQF56ZOfQE7U
{
    private $iN_s5;
    public function __construct($bwI0g)
    {
        $this->iN_s5 = $bwI0g;
    }
    public function mdfAwNnkVqr($XbAUN, $ZIUao)
    {
        goto lt84p;
        GiSJw:
        $this->iN_s5->delete();
        goto lFaX2;
        eDfbq:
        $this->iN_s5->status = WSEQ88VDOa3X0::UPLOADED;
        goto F4RMt;
        NF7fx:
        i7X9W:
        goto ehBJB;
        lFaX2:
        ghfC6:
        goto T2VtV;
        ehBJB:
        if (!(WSEQ88VDOa3X0::DELETED === $ZIUao && $this->iN_s5->moOr97WSwAF())) {
            goto ghfC6;
        }
        goto GiSJw;
        RqwCZ:
        $this->iN_s5->mRU2TqSePcC(WSEQ88VDOa3X0::PROCESSING);
        goto NfWw1;
        NfWw1:
        FXBGl:
        goto CRnpO;
        lt84p:
        if (!(WSEQ88VDOa3X0::UPLOADED === $ZIUao)) {
            goto i7X9W;
        }
        goto eDfbq;
        CRnpO:
        $this->iN_s5->save();
        goto NF7fx;
        F4RMt:
        if (!$this->iN_s5 instanceof VPGaYsuFJzbQ0) {
            goto FXBGl;
        }
        goto RqwCZ;
        T2VtV:
    }
}
