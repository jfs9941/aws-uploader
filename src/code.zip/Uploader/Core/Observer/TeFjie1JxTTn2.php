<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Contracts\IlXdNMxZGcSoS;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\Strategy\CdB2OVyF59Eha;
use Jfs\Uploader\Core\Strategy\XprTOXzXRKkDr;
use Jfs\Uploader\Encoder\VNaEXNVKcqr6v;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Service\FpvVyCHYf1EbW;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class TeFjie1JxTTn2 implements IlXdNMxZGcSoS
{
    private $BFHBC;
    private $YG65u;
    private $aiw3M;
    private $BTghq;
    public function __construct($Z5ydB, $iay5S, $sUzkn)
    {
        goto MKkrF;
        ipLvK:
        $this->BTghq = $sUzkn;
        goto whh8b;
        MKkrF:
        $this->YG65u = $Z5ydB;
        goto EQQS9;
        EQQS9:
        $this->aiw3M = $iay5S;
        goto ipLvK;
        whh8b:
        $this->BFHBC = $this->maVKKUVyj8j();
        goto WjMo0;
        WjMo0:
    }
    public function mZowOLQCS3i($PcLOc, $Kkroe) : void
    {
        goto T211X;
        T211X:
        if (!(M7O7NSiJU2JG5::PROCESSING === $Kkroe)) {
            goto yIiUz;
        }
        goto Gip0D;
        ZvotM:
        if (!$this->BFHBC) {
            goto YCFyd;
        }
        goto sPI2T;
        gINwk:
        YCFyd:
        goto VjwNc;
        AW5y0:
        $this->BFHBC->process($Kkroe);
        goto d0Z_n;
        o_HDV:
        if (!(M7O7NSiJU2JG5::ENCODING_PROCESSED === $Kkroe)) {
            goto FfRO_;
        }
        goto dcD3T;
        FlUso:
        if (!$this->BFHBC) {
            goto Dhs1H;
        }
        goto AW5y0;
        VjwNc:
        FfRO_:
        goto wH4Oa;
        sa6fK:
        yIiUz:
        goto o_HDV;
        d0Z_n:
        Dhs1H:
        goto sa6fK;
        sPI2T:
        $this->BFHBC->process($Kkroe);
        goto gINwk;
        Gip0D:
        $this->YG65u->save();
        goto FlUso;
        dcD3T:
        $this->YG65u->save();
        goto ZvotM;
        wH4Oa:
    }
    private function maVKKUVyj8j()
    {
        goto NlS8o;
        m4CIL:
        itlHZ:
        goto YpUXT;
        YpUXT:
        G_vCc:
        goto SOHti;
        NlS8o:
        switch ($this->YG65u->getType()) {
            case 'image':
                return new CdB2OVyF59Eha($this->YG65u, $this->BTghq);
            case 'video':
                return new XprTOXzXRKkDr($this->YG65u, App::make(VNaEXNVKcqr6v::class));
            default:
                return null;
        }
        goto m4CIL;
        SOHti:
    }
}
