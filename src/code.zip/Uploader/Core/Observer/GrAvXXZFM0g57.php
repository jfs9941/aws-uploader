<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Pr07JVh1ChqJO;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Exception\Vfh0JNvlNsuXG;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Presigned\Y6cbPTDjBmUdV;
use Jfs\Uploader\Presigned\Box8vIY48aIeK;
use Illuminate\Support\Facades\Log;
final class GrAvXXZFM0g57 implements Pr07JVh1ChqJO
{
    private $s9GAD;
    private $YssWB;
    private $qqmnq;
    private $iIDXy;
    private $mltiL;
    public function __construct($lJ5H4, $vS8UC, $vKILS, $nIkcP, $czBLO = false)
    {
        goto JAyDQ;
        JAyDQ:
        $this->YssWB = $lJ5H4;
        goto HZElH;
        bzqqY:
        $this->mbHQU0RUxGd();
        goto T54QR;
        kHe1d:
        $this->iIDXy = $vKILS;
        goto uVF1V;
        uVF1V:
        $this->mltiL = $nIkcP;
        goto ngy0u;
        T54QR:
        gQ8wa:
        goto xXa1O;
        HZElH:
        $this->qqmnq = $vS8UC;
        goto kHe1d;
        ngy0u:
        if ($czBLO) {
            goto gQ8wa;
        }
        goto bzqqY;
        xXa1O:
    }
    private function mbHQU0RUxGd() : void
    {
        goto MAvqe;
        PrLVV:
        return;
        goto QbGhq;
        zhh3c:
        try {
            $wt893 = $this->YssWB->mvHStueAWqd();
            $this->s9GAD = 's3' === $wt893->NQ3st ? new Box8vIY48aIeK($this->YssWB, $this->qqmnq, $this->iIDXy, $this->mltiL) : new Y6cbPTDjBmUdV($this->YssWB, $this->qqmnq, $this->iIDXy);
        } catch (WpKhE6K2C9AsD $b6Bui) {
            Log::warning("Failed to set up presigned upload: {$b6Bui->getMessage()}");
        }
        goto eRMqk;
        QbGhq:
        XfNtD:
        goto zhh3c;
        MAvqe:
        if (!(null !== $this->s9GAD)) {
            goto XfNtD;
        }
        goto PrLVV;
        eRMqk:
    }
    public function mI8wqsETHZd($zgXzD, $BmlMb)
    {
        goto Rs4M4;
        DusQk:
        kqJT2:
        goto pEeA_;
        pEeA_:
        EllcX:
        goto vkkab;
        Rs4M4:
        $this->mbHQU0RUxGd();
        goto LDj_1;
        LDj_1:
        switch ($BmlMb) {
            case Fsm7WCrUwVWh9::UPLOADING:
                $this->mbmF3yoLhdM();
                goto EllcX;
            case Fsm7WCrUwVWh9::UPLOADED:
                $this->mMVrcAIFTXh();
                goto EllcX;
            case Fsm7WCrUwVWh9::ABORTED:
                $this->mAqhXqJuAeP();
                goto EllcX;
            default:
                goto EllcX;
        }
        goto DusQk;
        vkkab:
    }
    private function mMVrcAIFTXh() : void
    {
        goto Gz38w;
        BSgQW:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($RB3Ub->id);
        goto C7_D3;
        Gz38w:
        $this->s9GAD->mnPGFoo0xg7();
        goto ToLxl;
        ToLxl:
        $RB3Ub = $this->YssWB->getFile();
        goto V1oTX;
        V1oTX:
        $RB3Ub->mtyCvJ3PeFW(Fsm7WCrUwVWh9::UPLOADED);
        goto G2bdY;
        C7_D3:
        SS7CD:
        goto uHZKW;
        G2bdY:
        if (!$RB3Ub instanceof RhdJGUi8FOLBJ) {
            goto SS7CD;
        }
        goto BSgQW;
        uHZKW:
    }
    private function mAqhXqJuAeP() : void
    {
        $this->s9GAD->mhhM9EUIOAf();
    }
    private function mbmF3yoLhdM() : void
    {
        $this->s9GAD->mY1nsrq2j7D();
    }
}
