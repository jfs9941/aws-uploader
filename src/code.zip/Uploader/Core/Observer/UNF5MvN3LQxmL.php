<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\RoTpJhiFhvlTg;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Exception\J0z9iIrDgeD3q;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Jfs\Uploader\Presigned\L5liqfceo7xGR;
use Jfs\Uploader\Presigned\Grj67gsLukV22;
final class UNF5MvN3LQxmL implements RoTpJhiFhvlTg
{
    private $LYyrK;
    private $speJc;
    private $N3F9R;
    private $LmK5y;
    private $Jbhpc;
    public function __construct($KnLpk, $mFX9i, $ExTI3, $A745z, $Ip1jG = false)
    {
        goto XE7_j;
        GvSfw:
        $this->masFQrmg9Ec();
        goto vy9HC;
        XE7_j:
        $this->speJc = $KnLpk;
        goto RssXo;
        lh0kZ:
        $this->LmK5y = $ExTI3;
        goto cL03Y;
        cL03Y:
        $this->Jbhpc = $A745z;
        goto aEkC5;
        aEkC5:
        if ($Ip1jG) {
            goto kLebe;
        }
        goto GvSfw;
        vy9HC:
        kLebe:
        goto Du9se;
        RssXo:
        $this->N3F9R = $mFX9i;
        goto lh0kZ;
        Du9se:
    }
    private function masFQrmg9Ec() : void
    {
        goto kC8Ut;
        WcYZK:
        xFOR6:
        goto mkFEQ;
        xvOti:
        return;
        goto WcYZK;
        mkFEQ:
        try {
            $Ds24j = $this->speJc->mDwF61YxuNq();
            $this->LYyrK = 's3' === $Ds24j->vZVzF ? new Grj67gsLukV22($this->speJc, $this->N3F9R, $this->LmK5y, $this->Jbhpc) : new L5liqfceo7xGR($this->speJc, $this->N3F9R, $this->LmK5y);
        } catch (Uxbn1AMqHjlda $ZkRqE) {
            Log::warning("Failed to set up presigned upload: {$ZkRqE->getMessage()}");
        }
        goto p1JMR;
        kC8Ut:
        if (!(null !== $this->LYyrK)) {
            goto xFOR6;
        }
        goto xvOti;
        p1JMR:
    }
    public function mM5x0654DhR($EIAGD, $UeOhO)
    {
        goto Q_kWS;
        bRJQc:
        G4MCW:
        goto UfyDL;
        UfyDL:
        ee68S:
        goto mvBuG;
        Q_kWS:
        $this->masFQrmg9Ec();
        goto clV3H;
        clV3H:
        switch ($UeOhO) {
            case RwOJkCXwa9RQz::UPLOADING:
                $this->mr0gY0qg2Ck();
                goto ee68S;
            case RwOJkCXwa9RQz::UPLOADED:
                $this->m6VxZeS1Jo1();
                goto ee68S;
            case RwOJkCXwa9RQz::ABORTED:
                $this->mgFUvglJLQf();
                goto ee68S;
            default:
                goto ee68S;
        }
        goto bRJQc;
        mvBuG:
    }
    private function m6VxZeS1Jo1() : void
    {
        goto DYq5m;
        Pbt3Z:
        if (!$a3XOL instanceof GXtnGiMmIPEIc) {
            goto ybzSO;
        }
        goto xnhlX;
        DYq5m:
        $this->LYyrK->mYrguHH3ARB();
        goto ixHXJ;
        xnhlX:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($a3XOL->id);
        goto jwaES;
        ixHXJ:
        $a3XOL = $this->speJc->getFile();
        goto hmKP3;
        hmKP3:
        $a3XOL->mGQfJhYWpvR(RwOJkCXwa9RQz::UPLOADED);
        goto Pbt3Z;
        jwaES:
        ybzSO:
        goto MTrH_;
        MTrH_:
    }
    private function mgFUvglJLQf() : void
    {
        $this->LYyrK->muDP4BURVYw();
    }
    private function mr0gY0qg2Ck() : void
    {
        $this->LYyrK->m9UURmwWnW3();
    }
}
