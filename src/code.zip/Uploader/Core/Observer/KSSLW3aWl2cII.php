<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Contracts\Hx13AKbJdXa2m;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class KSSLW3aWl2cII implements Hx13AKbJdXa2m
{
    private $PV7YF;
    public function __construct($TFA4Z)
    {
        $this->PV7YF = $TFA4Z;
    }
    public function mw0DVFYNlsC($p8eXb, $lgpiE)
    {
        goto pVPMR;
        z2cnu:
        $this->PV7YF->status = Q5pXt73hTeTVP::UPLOADED;
        goto nmljh;
        YXM2i:
        HQugJ:
        goto l0JHP;
        L1tBk:
        tthiL:
        goto mihLW;
        pVPMR:
        if (!(Q5pXt73hTeTVP::UPLOADED === $lgpiE)) {
            goto HQugJ;
        }
        goto z2cnu;
        TZmjB:
        CPy2H:
        goto OkcGq;
        l0JHP:
        if (!(Q5pXt73hTeTVP::DELETED === $lgpiE && $this->PV7YF->mA2btvecJNA())) {
            goto tthiL;
        }
        goto KrhSP;
        nmljh:
        if (!$this->PV7YF instanceof WKX0l52zWptlF) {
            goto CPy2H;
        }
        goto ZKj7a;
        ZKj7a:
        $this->PV7YF->mhK1eUHzFBK(Q5pXt73hTeTVP::PROCESSING);
        goto TZmjB;
        KrhSP:
        $this->PV7YF->delete();
        goto L1tBk;
        OkcGq:
        $this->PV7YF->save();
        goto YXM2i;
        mihLW:
    }
}
