<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Contracts\P7eZRarQfx9Id;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Core\Strategy\SzqF8Kv00GoJQ;
use Jfs\Uploader\Core\Strategy\GuWYkuOyTk8ZD;
use Jfs\Uploader\Encoder\OGmQ0hQJzIYby;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Service\PP4BnfgX7sVAN;
final class VypGUfv7ecYko implements P7eZRarQfx9Id
{
    private $qCMla;
    private $T6rAm;
    private $gGE8I;
    private $INTZb;
    public function __construct($PQjbH, $duBfR, $K704z)
    {
        goto VmfzA;
        VmfzA:
        $this->T6rAm = $PQjbH;
        goto FfoFa;
        RtxDO:
        $this->qCMla = $this->mw90ER1mgUT();
        goto L3vY9;
        psOBw:
        $this->INTZb = $K704z;
        goto RtxDO;
        FfoFa:
        $this->gGE8I = $duBfR;
        goto psOBw;
        L3vY9:
    }
    public function m85MtNrnQlN($VOPJr, $O3gwv) : void
    {
        goto s_Sfz;
        U9Mfj:
        U8_BW:
        goto dONKG;
        OjuEW:
        if (!$this->qCMla) {
            goto mX1wG;
        }
        goto iBrka;
        UJKix:
        $this->T6rAm->save();
        goto OjuEW;
        iBrka:
        $this->qCMla->process($O3gwv);
        goto BQcyH;
        ZRnao:
        nqXoQ:
        goto U9Mfj;
        nZYRk:
        if (!$this->qCMla) {
            goto nqXoQ;
        }
        goto Yb5nZ;
        Yb5nZ:
        $this->qCMla->process($O3gwv);
        goto ZRnao;
        aACWs:
        if (!(UimQKBIuLCEAO::ENCODING_PROCESSED === $O3gwv)) {
            goto U8_BW;
        }
        goto vHdi1;
        vHdi1:
        $this->T6rAm->save();
        goto nZYRk;
        BQcyH:
        mX1wG:
        goto Bp_R4;
        Bp_R4:
        UlgNG:
        goto aACWs;
        s_Sfz:
        if (!(UimQKBIuLCEAO::PROCESSING === $O3gwv)) {
            goto UlgNG;
        }
        goto UJKix;
        dONKG:
    }
    private function mw90ER1mgUT()
    {
        goto tfNU4;
        f4BwK:
        VYRHn:
        goto PBB1w;
        tfNU4:
        switch ($this->T6rAm->getType()) {
            case 'image':
                return new SzqF8Kv00GoJQ($this->T6rAm, $this->INTZb);
            case 'video':
                return new GuWYkuOyTk8ZD($this->T6rAm, App::make(OGmQ0hQJzIYby::class));
            default:
                return null;
        }
        goto uDpn7;
        uDpn7:
        EVXu3:
        goto f4BwK;
        PBB1w:
    }
}
