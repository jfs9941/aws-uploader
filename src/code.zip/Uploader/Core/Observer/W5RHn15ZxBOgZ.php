<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Contracts\Iy5htSHK04ggf;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
class W5RHn15ZxBOgZ implements Iy5htSHK04ggf
{
    private $wM7km;
    public function __construct($K9DZL)
    {
        $this->wM7km = $K9DZL;
    }
    public function mSJMv13z3kQ($bwPdj, $VpAJm)
    {
        goto GW0HM;
        CR1g3:
        if (!$this->wM7km instanceof A9olNyGXhDJnA) {
            goto AfB1w;
        }
        goto b1cQy;
        SacEz:
        if (!(GlPuUJKmzwUJ9::DELETED === $VpAJm && $this->wM7km->mpP5bOKeXyo())) {
            goto KdPvM;
        }
        goto OKOB9;
        nvjKM:
        QaMLD:
        goto SacEz;
        b1cQy:
        $this->wM7km->miF5zZlQWZD(GlPuUJKmzwUJ9::PROCESSING);
        goto IXiL7;
        OKOB9:
        $this->wM7km->delete();
        goto Yb9dd;
        uVnVf:
        $this->wM7km->status = GlPuUJKmzwUJ9::UPLOADED;
        goto CR1g3;
        IXiL7:
        AfB1w:
        goto oFCG2;
        Yb9dd:
        KdPvM:
        goto vyXlB;
        GW0HM:
        if (!(GlPuUJKmzwUJ9::UPLOADED === $VpAJm)) {
            goto QaMLD;
        }
        goto uVnVf;
        oFCG2:
        $this->wM7km->save();
        goto nvjKM;
        vyXlB:
    }
}
