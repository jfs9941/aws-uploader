<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core\Observer;

use src\Uploader\Contracts\F5Xo0te9A5R68;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Enum\FileStatus;
class B4X2uxI8Q50V1 implements F5Xo0te9A5R68
{
    private $dfQse;
    public function __construct($d1aiC)
    {
        $this->dfQse = $d1aiC;
    }
    public function myVaRYzH5cA($oCcYR, $nz0Xr)
    {
        goto lOk9W;
        y1BtE:
        if (!$this->dfQse instanceof ID6EZw1DKfqu4) {
            goto y8A4X;
        }
        goto IZR3y;
        HA5ym:
        nxeK_:
        goto BMy3C;
        IZR3y:
        $this->dfQse->mIjUnedc3Mq(FileStatus::PROCESSING);
        goto bJBNw;
        DOJIr:
        if (!(FileStatus::DELETED === $nz0Xr && $this->dfQse->mSNOW0ZI8Zu())) {
            goto nxeK_;
        }
        goto BPDZ4;
        BbFLF:
        VUtOq:
        goto DOJIr;
        B9t9r:
        $this->dfQse->save();
        goto BbFLF;
        bJBNw:
        y8A4X:
        goto B9t9r;
        lOk9W:
        if (!(FileStatus::UPLOADED === $nz0Xr)) {
            goto VUtOq;
        }
        goto gDW3o;
        gDW3o:
        $this->dfQse->status = FileStatus::UPLOADED;
        goto y1BtE;
        BPDZ4:
        $this->dfQse->delete();
        goto HA5ym;
        BMy3C:
    }
}
