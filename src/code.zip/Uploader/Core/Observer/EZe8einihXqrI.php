<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Contracts\OZ0OEimEhcPCG;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\Strategy\AXpQfeux4SssB;
use Jfs\Uploader\Core\Strategy\JySbKozHqgBbq;
use Jfs\Uploader\Encoder\U69m2hVAaudAN;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Service\FTup2pWS3iynB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class EZe8einihXqrI implements OZ0OEimEhcPCG
{
    private $lkumF;
    private $WpbZG;
    private $DksH2;
    private $rvU5Z;
    public function __construct($cNpq7, $l4Drs, $taWvo)
    {
        goto M1RkR;
        siG7l:
        $this->DksH2 = $l4Drs;
        goto Z8wv5;
        M1RkR:
        $this->WpbZG = $cNpq7;
        goto siG7l;
        inrLj:
        $this->lkumF = $this->mMzhC3L0tY8();
        goto UPo0a;
        Z8wv5:
        $this->rvU5Z = $taWvo;
        goto inrLj;
        UPo0a:
    }
    public function mw8TbyaigDj($c9oe4, $Aof5j) : void
    {
        goto pMzan;
        BuXZ3:
        Pd921:
        goto G7eIx;
        xPjGu:
        if (!$this->lkumF) {
            goto U2RAm;
        }
        goto wV9J1;
        Hd0Ic:
        jmOmC:
        goto L6itV;
        wRylv:
        if (!$this->lkumF) {
            goto jmOmC;
        }
        goto G2G83;
        L6itV:
        JMeTx:
        goto rXjK7;
        G2G83:
        $this->lkumF->process($Aof5j);
        goto Hd0Ic;
        xkeWL:
        $this->WpbZG->save();
        goto xPjGu;
        pMzan:
        if (!(FmSSI1JLQCp0W::PROCESSING === $Aof5j)) {
            goto Pd921;
        }
        goto xkeWL;
        uRT20:
        $this->WpbZG->save();
        goto wRylv;
        k3YxN:
        U2RAm:
        goto BuXZ3;
        G7eIx:
        if (!(FmSSI1JLQCp0W::ENCODING_PROCESSED === $Aof5j)) {
            goto JMeTx;
        }
        goto uRT20;
        wV9J1:
        $this->lkumF->process($Aof5j);
        goto k3YxN;
        rXjK7:
    }
    private function mMzhC3L0tY8()
    {
        goto DC_zp;
        DC_zp:
        switch ($this->WpbZG->getType()) {
            case 'image':
                return new AXpQfeux4SssB($this->WpbZG, $this->rvU5Z);
            case 'video':
                return new JySbKozHqgBbq($this->WpbZG, App::make(U69m2hVAaudAN::class));
            default:
                return null;
        }
        goto xDrom;
        xDrom:
        l0OUU:
        goto MWbM2;
        MWbM2:
        gl_jg:
        goto tn48H;
        tn48H:
    }
}
