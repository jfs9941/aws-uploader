<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Observer; use Jfs\Uploader\Contracts\WrFez6oTdpaJs; use Jfs\Uploader\Contracts\B1wLFQApebIoO; use Jfs\Uploader\Core\J5wym0qxH1hlR; use Jfs\Uploader\Core\NoqRziJe9G7Nn; use Jfs\Uploader\Enum\FileStatus; class JfnuhKr0ypXSv implements B1wLFQApebIoO { private $IptUJ; public function __construct($goH3d) { $this->IptUJ = $goH3d; } public function maxj9EA5C3J($oaEUM, $e4BqQ) { goto Usr4b; mu2BC: if (!$this->IptUJ instanceof NoqRziJe9G7Nn) { goto wyX2i; } goto fmWJX; vwi96: B24jp: goto h94Fp; Usr4b: if (!(FileStatus::UPLOADED === $e4BqQ)) { goto wENJ6; } goto fzkmZ; eUEvd: $this->IptUJ->save(); goto caMMa; QkVQA: $this->IptUJ->delete(); goto vwi96; fmWJX: $this->IptUJ->mm4o1sFzBqc(FileStatus::PROCESSING); goto t8x7M; bB_nH: if (!(FileStatus::DELETED === $e4BqQ && $this->IptUJ->m1Z5bTDFXgO())) { goto B24jp; } goto QkVQA; caMMa: wENJ6: goto bB_nH; fzkmZ: $this->IptUJ->status = FileStatus::UPLOADED; goto mu2BC; t8x7M: wyX2i: goto eUEvd; h94Fp: } }
