<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\A1DrGQVhPKB54;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Exception\LDB12Ub0rXHOx;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Presigned\VKLqBvZbeNIb4;
use Jfs\Uploader\Presigned\UnoQO6Ikjrc34;
use Illuminate\Support\Facades\Log;
final class UBpTHcMNCaMb2 implements A1DrGQVhPKB54
{
    private $xIral;
    private $D3E4X;
    private $uTYgy;
    private $gG9Jm;
    private $F_eut;
    public function __construct($DiwBV, $kVG4M, $crBgX, $Jkr71, $BtdU9 = false)
    {
        goto JgOxs;
        rHrgP:
        $this->F_eut = $Jkr71;
        goto lSw3b;
        upfb0:
        $this->uTYgy = $kVG4M;
        goto eATaQ;
        v9jBM:
        lQhea:
        goto KjqrI;
        lSw3b:
        if ($BtdU9) {
            goto lQhea;
        }
        goto fGyUM;
        JgOxs:
        $this->D3E4X = $DiwBV;
        goto upfb0;
        eATaQ:
        $this->gG9Jm = $crBgX;
        goto rHrgP;
        fGyUM:
        $this->m8bPhaetDCj();
        goto v9jBM;
        KjqrI:
    }
    private function m8bPhaetDCj() : void
    {
        goto N4zqQ;
        N4zqQ:
        if (!(null !== $this->xIral)) {
            goto t2ZvX;
        }
        goto eEP2g;
        KwkFz:
        try {
            $H8A56 = $this->D3E4X->mFV2s6jujmR();
            $this->xIral = 's3' === $H8A56->tcavr ? new UnoQO6Ikjrc34($this->D3E4X, $this->uTYgy, $this->gG9Jm, $this->F_eut) : new VKLqBvZbeNIb4($this->D3E4X, $this->uTYgy, $this->gG9Jm);
        } catch (LFhGkQpjCxWvG $xMxrQ) {
            Log::warning("Failed to set up presigned upload: {$xMxrQ->getMessage()}");
        }
        goto EzVnW;
        eEP2g:
        return;
        goto tLDP2;
        tLDP2:
        t2ZvX:
        goto KwkFz;
        EzVnW:
    }
    public function mhxhZPnjNPV($zS2qB, $jAyD6)
    {
        goto j4K7p;
        fSPaS:
        switch ($jAyD6) {
            case KidkTsWIjmNMb::UPLOADING:
                $this->mEoIpW0DvPz();
                goto dYdJ7;
            case KidkTsWIjmNMb::UPLOADED:
                $this->m7BeHuq8mVL();
                goto dYdJ7;
            case KidkTsWIjmNMb::ABORTED:
                $this->mp4AAQtKO5o();
                goto dYdJ7;
            default:
                goto dYdJ7;
        }
        goto ZlHO_;
        ZlHO_:
        mu01L:
        goto c4dX8;
        c4dX8:
        dYdJ7:
        goto miWUl;
        j4K7p:
        $this->m8bPhaetDCj();
        goto fSPaS;
        miWUl:
    }
    private function m7BeHuq8mVL() : void
    {
        goto sFqSE;
        sFqSE:
        $this->xIral->mH7ADod756J();
        goto zAxLN;
        ZP1p4:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($clm2Y->id);
        goto glGuQ;
        Ns6I7:
        if (!$clm2Y instanceof CpeNYzI7e1ALA) {
            goto SG_hj;
        }
        goto ZP1p4;
        zAxLN:
        $clm2Y = $this->D3E4X->getFile();
        goto Jey_0;
        glGuQ:
        SG_hj:
        goto F_y5d;
        Jey_0:
        $clm2Y->mfzy7DteKHJ(KidkTsWIjmNMb::UPLOADED);
        goto Ns6I7;
        F_y5d:
    }
    private function mp4AAQtKO5o() : void
    {
        $this->xIral->mmoUBfLYEHW();
    }
    private function mEoIpW0DvPz() : void
    {
        $this->xIral->mFxnem6k407();
    }
}
