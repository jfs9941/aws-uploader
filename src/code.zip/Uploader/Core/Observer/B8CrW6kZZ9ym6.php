<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Contracts\TjZC83Yv3rOXg;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
class B8CrW6kZZ9ym6 implements TjZC83Yv3rOXg
{
    private $HyWI1;
    public function __construct($hFrf7)
    {
        $this->HyWI1 = $hFrf7;
    }
    public function mOZ7C9ggFcs($YJZDm, $ge2j8)
    {
        goto mDwQx;
        W7hq0:
        $this->HyWI1->mvlhr18w6fy(FdWrko7bmoI4Y::PROCESSING);
        goto TLSTK;
        UOTdd:
        $this->HyWI1->status = FdWrko7bmoI4Y::UPLOADED;
        goto q5MY5;
        Em2bp:
        $this->HyWI1->save();
        goto orJR6;
        rBnhk:
        Dla7W:
        goto eAbGr;
        gsSfp:
        $this->HyWI1->delete();
        goto rBnhk;
        mDwQx:
        if (!(FdWrko7bmoI4Y::UPLOADED === $ge2j8)) {
            goto GhdP7;
        }
        goto UOTdd;
        q5MY5:
        if (!$this->HyWI1 instanceof Z7LUL65CwqbbF) {
            goto ix8vj;
        }
        goto W7hq0;
        TLSTK:
        ix8vj:
        goto Em2bp;
        orJR6:
        GhdP7:
        goto SPIIJ;
        SPIIJ:
        if (!(FdWrko7bmoI4Y::DELETED === $ge2j8 && $this->HyWI1->mGqLq42ajnM())) {
            goto Dla7W;
        }
        goto gsSfp;
        eAbGr:
    }
}
