<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Contracts\PLHq1RdJfseHT;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\Strategy\A9UNRlqeqdcHb;
use Jfs\Uploader\Core\Strategy\UdYgyX3r3509I;
use Jfs\Uploader\Encoder\Qyf5nkvkW6Bhl;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Service\VEn7C5MII4ANw;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class VSXbfKeoGOaUS implements PLHq1RdJfseHT
{
    private $vxDd7;
    private $U4MDy;
    private $cC_4U;
    private $Chdmk;
    public function __construct($mz56v, $s1UdZ, $bvU4j)
    {
        goto bhXEh;
        oYHqo:
        $this->cC_4U = $s1UdZ;
        goto KzWWr;
        bhXEh:
        $this->U4MDy = $mz56v;
        goto oYHqo;
        KzWWr:
        $this->Chdmk = $bvU4j;
        goto n46ud;
        n46ud:
        $this->vxDd7 = $this->m32WASo6Pdh();
        goto Lb0z5;
        Lb0z5:
    }
    public function mQKpfhrTRkc($hVcA0, $Ha4yb) : void
    {
        goto dzlBF;
        WP0hZ:
        if (!(IfP50GBBbx63a::ENCODING_PROCESSED === $Ha4yb)) {
            goto jOagu;
        }
        goto SpW_l;
        B2Iwb:
        if (!$this->vxDd7) {
            goto eM4Q2;
        }
        goto QPieo;
        QMHyY:
        jOagu:
        goto ANA_z;
        QPieo:
        $this->vxDd7->process($Ha4yb);
        goto FmCD7;
        dzlBF:
        if (!(IfP50GBBbx63a::PROCESSING === $Ha4yb)) {
            goto ZgcPG;
        }
        goto fH_4v;
        fH_4v:
        $this->U4MDy->save();
        goto nwDEx;
        nwDEx:
        if (!$this->vxDd7) {
            goto yaGii;
        }
        goto X3Oy2;
        Ifw5c:
        ZgcPG:
        goto WP0hZ;
        SpW_l:
        $this->U4MDy->save();
        goto B2Iwb;
        hLs5v:
        yaGii:
        goto Ifw5c;
        X3Oy2:
        $this->vxDd7->process($Ha4yb);
        goto hLs5v;
        FmCD7:
        eM4Q2:
        goto QMHyY;
        ANA_z:
    }
    private function m32WASo6Pdh()
    {
        goto v9I0E;
        gH34C:
        ttHZb:
        goto JunzP;
        JunzP:
        lWl9O:
        goto vv48C;
        v9I0E:
        switch ($this->U4MDy->getType()) {
            case 'image':
                return new A9UNRlqeqdcHb($this->U4MDy, $this->Chdmk);
            case 'video':
                return new UdYgyX3r3509I($this->U4MDy, App::make(Qyf5nkvkW6Bhl::class));
            default:
                return null;
        }
        goto gH34C;
        vv48C:
    }
}
