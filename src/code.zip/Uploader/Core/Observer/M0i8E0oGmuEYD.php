<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Core\Observer;

use backup\Exposed\MWQEI3qnbYMuU;
use backup\Uploader\Contracts\A2uS8gTe46deJ;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Exception\Y86LODF9txYbT;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Presigned\HsrUorMJMz6jM;
use backup\Uploader\Presigned\Cz1TtKJmFbr22;
use Illuminate\Support\Facades\Log;
final class M0i8E0oGmuEYD implements A2uS8gTe46deJ
{
    private $Xplbf;
    private $eZBRn;
    private $FJZRi;
    private $JINyv;
    private $tv4bE;
    public function __construct($D5W64, $UEDUm, $s49oM, $ClLup, $qNPmZ = false)
    {
        goto N70H0;
        I33l0:
        TjF1g:
        goto SFWaR;
        x49ge:
        $this->tv4bE = $ClLup;
        goto MfBoK;
        kq3CI:
        $this->FJZRi = $UEDUm;
        goto iVqdZ;
        fraxM:
        $this->mP3riGF1eHg();
        goto I33l0;
        iVqdZ:
        $this->JINyv = $s49oM;
        goto x49ge;
        N70H0:
        $this->eZBRn = $D5W64;
        goto kq3CI;
        MfBoK:
        if ($qNPmZ) {
            goto TjF1g;
        }
        goto fraxM;
        SFWaR:
    }
    private function mP3riGF1eHg() : void
    {
        goto iAIaD;
        bMPYb:
        return;
        goto XICeQ;
        ZSDJC:
        try {
            $JbFc7 = $this->eZBRn->m77UJKssxZ5();
            $this->Xplbf = 's3' === $JbFc7->IykL3 ? new Cz1TtKJmFbr22($this->eZBRn, $this->FJZRi, $this->JINyv, $this->tv4bE) : new HsrUorMJMz6jM($this->eZBRn, $this->FJZRi, $this->JINyv);
        } catch (Asi2ubH37e0l9 $eQXjs) {
            Log::warning("Failed to set up presigned upload: {$eQXjs->getMessage()}");
        }
        goto L9Rj3;
        XICeQ:
        dTmfY:
        goto ZSDJC;
        iAIaD:
        if (!(null !== $this->Xplbf)) {
            goto dTmfY;
        }
        goto bMPYb;
        L9Rj3:
    }
    public function mI9DhQKSU08($SGfNF, $SIscU)
    {
        goto F0Hcd;
        F0Hcd:
        $this->mP3riGF1eHg();
        goto biuYr;
        QQ_IO:
        Q40eB:
        goto KpmJk;
        biuYr:
        switch ($SIscU) {
            case Aetm2HiFuJE34::UPLOADING:
                $this->m7ioBJfPfO8();
                goto Q40eB;
            case Aetm2HiFuJE34::UPLOADED:
                $this->mlU4g6ghlh1();
                goto Q40eB;
            case Aetm2HiFuJE34::ABORTED:
                $this->m4JSIKdDcYu();
                goto Q40eB;
            default:
                goto Q40eB;
        }
        goto bz0ne;
        bz0ne:
        yGhkz:
        goto QQ_IO;
        KpmJk:
    }
    private function mlU4g6ghlh1() : void
    {
        goto VJ7kt;
        SUj_a:
        app(MWQEI3qnbYMuU::class)->createThumbnail($eVZrJ->id);
        goto MGaWp;
        VJ7kt:
        $this->Xplbf->mluSWeny8it();
        goto hXY6K;
        O3KRK:
        if (!$eVZrJ instanceof AvisbyD0IE5xq) {
            goto Hfaj8;
        }
        goto SUj_a;
        hXY6K:
        $eVZrJ = $this->eZBRn->getFile();
        goto H6HK5;
        H6HK5:
        $eVZrJ->mKOiTrzpM4V(Aetm2HiFuJE34::UPLOADED);
        goto O3KRK;
        MGaWp:
        Hfaj8:
        goto v2Zgm;
        v2Zgm:
    }
    private function m4JSIKdDcYu() : void
    {
        $this->Xplbf->mKta32e3ZeL();
    }
    private function m7ioBJfPfO8() : void
    {
        $this->Xplbf->mUNxSWNsvIU();
    }
}
