<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Contracts\P7eZRarQfx9Id;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class OyE37jmOM3GFk implements P7eZRarQfx9Id
{
    private $T6rAm;
    public function __construct($PQjbH)
    {
        $this->T6rAm = $PQjbH;
    }
    public function m85MtNrnQlN($VOPJr, $O3gwv)
    {
        goto GCTaA;
        QGxws:
        $this->T6rAm->delete();
        goto GkC8w;
        GkC8w:
        IKJ9v:
        goto roupE;
        Cj1w1:
        $this->T6rAm->status = UimQKBIuLCEAO::UPLOADED;
        goto UiB67;
        iSwZe:
        VJM3j:
        goto d2vVT;
        d2vVT:
        $this->T6rAm->save();
        goto V23zo;
        knFmJ:
        $this->T6rAm->mTKyaraJgz7(UimQKBIuLCEAO::PROCESSING);
        goto iSwZe;
        GCTaA:
        if (!(UimQKBIuLCEAO::UPLOADED === $O3gwv)) {
            goto LHe1H;
        }
        goto Cj1w1;
        V23zo:
        LHe1H:
        goto yytE5;
        UiB67:
        if (!$this->T6rAm instanceof Sf7MFJ2wUSx2k) {
            goto VJM3j;
        }
        goto knFmJ;
        yytE5:
        if (!(UimQKBIuLCEAO::DELETED === $O3gwv && $this->T6rAm->m82svbFWTWy())) {
            goto IKJ9v;
        }
        goto QGxws;
        roupE:
    }
}
