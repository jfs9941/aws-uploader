<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:45              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Contracts\CPWst5X7YKGnu;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Core\Strategy\Lb9YM0rWVQC1D;
use Jfs\Uploader\Core\Strategy\RsEqyvqLyezoB;
use Jfs\Uploader\Encoder\Z476P5MAXqSnV;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Service\Cjv3UOrDUgWrC;
final class LK57MVeZYodze implements CPWst5X7YKGnu
{
    private $yb1SW;
    private $woTf1;
    private $K79lK;
    private $qxf7d;
    public function __construct($oYtbp, $yEBaZ, $i6jr_)
    {
        goto UM9DJ;
        oPvw1:
        $this->K79lK = $yEBaZ;
        goto HkmT4;
        UM9DJ:
        $this->woTf1 = $oYtbp;
        goto oPvw1;
        HkmT4:
        $this->qxf7d = $i6jr_;
        goto dltGU;
        dltGU:
        $this->yb1SW = $this->mGHxGApKFeS();
        goto T17rB;
        T17rB:
    }
    public function mLulwBaR29t($gJXBQ, $snzZr) : void
    {
        goto ILbEy;
        wRQeC:
        M539d:
        goto jpUjg;
        Y2XRM:
        $this->yb1SW->process($snzZr);
        goto FGxcC;
        G7yM7:
        g3_fp:
        goto wRQeC;
        FGxcC:
        NY61N:
        goto Skzbs;
        zBUcL:
        $this->yb1SW->process($snzZr);
        goto G7yM7;
        L7QbS:
        if (!$this->yb1SW) {
            goto NY61N;
        }
        goto Y2XRM;
        igHU7:
        $this->woTf1->save();
        goto L7QbS;
        ILbEy:
        if (!(OLX71luAn6XnP::PROCESSING === $snzZr)) {
            goto zeWui;
        }
        goto igHU7;
        TqUkW:
        $this->woTf1->save();
        goto a7UZ0;
        a7UZ0:
        if (!$this->yb1SW) {
            goto g3_fp;
        }
        goto zBUcL;
        Skzbs:
        zeWui:
        goto Qhon1;
        Qhon1:
        if (!(OLX71luAn6XnP::ENCODING_PROCESSED === $snzZr)) {
            goto M539d;
        }
        goto TqUkW;
        jpUjg:
    }
    private function mGHxGApKFeS()
    {
        goto W_Uvq;
        lmjk8:
        KDhAc:
        goto JhSDi;
        W_Uvq:
        switch ($this->woTf1->getType()) {
            case 'image':
                return new Lb9YM0rWVQC1D($this->woTf1, $this->qxf7d);
            case 'video':
                return new RsEqyvqLyezoB($this->woTf1, App::make(Z476P5MAXqSnV::class));
            default:
                return null;
        }
        goto v9LXF;
        v9LXF:
        PA0hZ:
        goto lmjk8;
        JhSDi:
    }
}
