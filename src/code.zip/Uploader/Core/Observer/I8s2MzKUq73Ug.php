<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Cwggsm2UPkGtM;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Exception\KlKPTBnDHVeRD;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Presigned\SRGM5YfCckw3z;
use Jfs\Uploader\Presigned\EAJUNhyG8pHgi;
use Illuminate\Support\Facades\Log;
final class I8s2MzKUq73Ug implements Cwggsm2UPkGtM
{
    private $Gg00W;
    private $yK1hJ;
    private $IA8m0;
    private $mzEj7;
    private $to1A0;
    public function __construct($Fr4mD, $Rgxn3, $z6qdY, $QlBWR, $CMqPQ = false)
    {
        goto z8udt;
        hzJJp:
        $this->myXdAYtz0zF();
        goto Wzbil;
        nFIM7:
        $this->IA8m0 = $Rgxn3;
        goto TEk2L;
        DQWMX:
        if ($CMqPQ) {
            goto hwBUB;
        }
        goto hzJJp;
        z8udt:
        $this->yK1hJ = $Fr4mD;
        goto nFIM7;
        Oj66U:
        $this->to1A0 = $QlBWR;
        goto DQWMX;
        Wzbil:
        hwBUB:
        goto JLq7D;
        TEk2L:
        $this->mzEj7 = $z6qdY;
        goto Oj66U;
        JLq7D:
    }
    private function myXdAYtz0zF() : void
    {
        goto pIvK3;
        IG5Re:
        DCBgu:
        goto mnVBJ;
        pIvK3:
        if (!(null !== $this->Gg00W)) {
            goto DCBgu;
        }
        goto D0Zfl;
        D0Zfl:
        return;
        goto IG5Re;
        mnVBJ:
        try {
            $cor5J = $this->yK1hJ->mMYcEvkVSg5();
            $this->Gg00W = 's3' === $cor5J->driver ? new EAJUNhyG8pHgi($this->yK1hJ, $this->IA8m0, $this->mzEj7, $this->to1A0) : new SRGM5YfCckw3z($this->yK1hJ, $this->IA8m0, $this->mzEj7);
        } catch (AsUdPM9ttxh6c $lzebJ) {
            Log::warning("Failed to set up presigned upload: {$lzebJ->getMessage()}");
        }
        goto pHnXd;
        pHnXd:
    }
    public function mFunvful2ao($QRp1M, $Y0Lou)
    {
        goto Iw08D;
        iTj7d:
        cGLvh:
        goto U9Bxc;
        UoZWV:
        switch ($Y0Lou) {
            case MUu80sOhINyO3::UPLOADING:
                $this->maP6ZmjxTTX();
                goto GWsVw;
            case MUu80sOhINyO3::UPLOADED:
                $this->mDEJ0tzUHJM();
                goto GWsVw;
            case MUu80sOhINyO3::ABORTED:
                $this->m0YEAL9RoJG();
                goto GWsVw;
            default:
                goto GWsVw;
        }
        goto iTj7d;
        U9Bxc:
        GWsVw:
        goto rH2v4;
        Iw08D:
        $this->myXdAYtz0zF();
        goto UoZWV;
        rH2v4:
    }
    private function mDEJ0tzUHJM() : void
    {
        goto xx1Vr;
        CEdPU:
        $eQ4Ln->mG7ZLOSfPOQ(MUu80sOhINyO3::UPLOADED);
        goto U9jo_;
        KbImX:
        nLIq_:
        goto fWi35;
        U9jo_:
        if (!$eQ4Ln instanceof JbxOPjx4A3DUY) {
            goto nLIq_;
        }
        goto M4GMB;
        cu_2k:
        $eQ4Ln = $this->yK1hJ->getFile();
        goto CEdPU;
        M4GMB:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($eQ4Ln->id);
        goto sCjR4;
        xx1Vr:
        $this->Gg00W->m0VtXeYPu88();
        goto cu_2k;
        sCjR4:
        $eQ4Ln->mG7ZLOSfPOQ(MUu80sOhINyO3::PROCESSING);
        goto KbImX;
        fWi35:
    }
    private function m0YEAL9RoJG() : void
    {
        $this->Gg00W->mx9xMkU9qJu();
    }
    private function maP6ZmjxTTX() : void
    {
        $this->Gg00W->mCyzSeB6wKx();
    }
}
