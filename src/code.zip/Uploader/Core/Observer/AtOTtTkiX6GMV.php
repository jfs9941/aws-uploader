<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Contracts\D1gefDsblgSHh;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
class AtOTtTkiX6GMV implements D1gefDsblgSHh
{
    private $XHy23;
    public function __construct($pemjO)
    {
        $this->XHy23 = $pemjO;
    }
    public function mop1CVR7YoY($olf3Q, $Iv88p)
    {
        goto FVGiT;
        NA9a1:
        $this->XHy23->mVhOJ1PgG8J(IOOvAXAyKHLW2::PROCESSING);
        goto peBcS;
        MVIOh:
        xdMMO:
        goto nk41c;
        peBcS:
        UxcSt:
        goto wD0CG;
        wD0CG:
        $this->XHy23->save();
        goto cI26g;
        thEkE:
        if (!$this->XHy23 instanceof KZbAaRxCqNUr3) {
            goto UxcSt;
        }
        goto NA9a1;
        Iol6r:
        $this->XHy23->status = IOOvAXAyKHLW2::UPLOADED;
        goto thEkE;
        RRC1X:
        if (!(IOOvAXAyKHLW2::DELETED === $Iv88p && $this->XHy23->mKbwFy5aKy5())) {
            goto xdMMO;
        }
        goto heicB;
        FVGiT:
        if (!(IOOvAXAyKHLW2::UPLOADED === $Iv88p)) {
            goto VBvMf;
        }
        goto Iol6r;
        heicB:
        $this->XHy23->delete();
        goto MVIOh;
        cI26g:
        VBvMf:
        goto RRC1X;
        nk41c:
    }
}
