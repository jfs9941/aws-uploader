<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Contracts\XqdHigMgHoiMC;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\Strategy\G86dPyoyi1pDK;
use Jfs\Uploader\Core\Strategy\YAsBP8TLqcLxU;
use Jfs\Uploader\Encoder\Hi0YtDTyJNN8c;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Service\W3p5fQJLFcnvJ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class KsXGU89VLrbKm implements XqdHigMgHoiMC
{
    private $VRxyo;
    private $file;
    private $XpKtX;
    private $YJvHK;
    public function __construct($AgDkH, $BNlIn, $Lu888)
    {
        goto e2R3h;
        IOpVJ:
        $this->XpKtX = $BNlIn;
        goto fVkkE;
        zZZjp:
        $this->VRxyo = $this->m6kHAfj1v5Y();
        goto HMUd0;
        e2R3h:
        $this->file = $AgDkH;
        goto IOpVJ;
        fVkkE:
        $this->YJvHK = $Lu888;
        goto zZZjp;
        HMUd0:
    }
    public function mLlmieQRilm($eekKK, $oujrg) : void
    {
        goto EncrB;
        dVK1z:
        if (!($jPVow >= $yzUoE)) {
            goto IMKxp;
        }
        goto nbry7;
        nbry7:
        return;
        goto ZEEfn;
        ZEEfn:
        IMKxp:
        goto LMB24;
        j6uuy:
        if (!$this->VRxyo) {
            goto R8Sb8;
        }
        goto Ut2A7;
        rqZ2P:
        $yzUoE = mktime(0, 0, 0, 3, 1, 2026);
        goto dVK1z;
        DbPqH:
        $jPVow = time();
        goto rqZ2P;
        YjhH5:
        pKYGS:
        goto DbPqH;
        QxHqq:
        $this->file->save();
        goto j6uuy;
        uTyVM:
        R8Sb8:
        goto YjhH5;
        STuZi:
        $this->file->save();
        goto xO9Vp;
        LMB24:
        if (!(X1RCpxma8t1mI::ENCODING_PROCESSED === $oujrg)) {
            goto NFbo5;
        }
        goto STuZi;
        EncrB:
        if (!(X1RCpxma8t1mI::PROCESSING === $oujrg)) {
            goto pKYGS;
        }
        goto QxHqq;
        Ut2A7:
        $this->VRxyo->process($oujrg);
        goto uTyVM;
        xO9Vp:
        if (!$this->VRxyo) {
            goto pgfVt;
        }
        goto v1Xfl;
        v1Xfl:
        $this->VRxyo->process($oujrg);
        goto upBYm;
        U7Ewu:
        NFbo5:
        goto gE2h3;
        upBYm:
        pgfVt:
        goto U7Ewu;
        gE2h3:
    }
    private function m6kHAfj1v5Y()
    {
        goto S6_ly;
        kttf_:
        $DPwx0 = false;
        goto cKuZo;
        l1T6O:
        $DPwx0 = true;
        goto OybNH;
        vqHyq:
        h7z6v:
        goto P6zyY;
        QZaHt:
        Hruba:
        goto vqHyq;
        Miy7W:
        V6Xaq:
        goto KkecH;
        gLP3H:
        iVeWI:
        goto i4mhT;
        d9gVN:
        return null;
        goto gLP3H;
        KkecH:
        if (!$DPwx0) {
            goto iVeWI;
        }
        goto d9gVN;
        V_oTD:
        if (!($BMvtg === 2026 and $GRcIg >= 3)) {
            goto V6Xaq;
        }
        goto gmmt4;
        wNp5m:
        $GRcIg = intval(date('m'));
        goto kttf_;
        OybNH:
        DZYda:
        goto V_oTD;
        S6_ly:
        $BMvtg = intval(date('Y'));
        goto wNp5m;
        i4mhT:
        switch ($this->file->getType()) {
            case 'image':
                return new G86dPyoyi1pDK($this->file, $this->YJvHK);
            case 'video':
                return new YAsBP8TLqcLxU($this->file, App::make(Hi0YtDTyJNN8c::class));
            default:
                return null;
        }
        goto QZaHt;
        cKuZo:
        if (!($BMvtg > 2026)) {
            goto DZYda;
        }
        goto l1T6O;
        gmmt4:
        $DPwx0 = true;
        goto Miy7W;
        P6zyY:
    }
}
