<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Contracts\C3XDkOI7yIIoE;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Core\Strategy\FSv3GPN90K6IS;
use Jfs\Uploader\Core\Strategy\DrhNfMm6psarL;
use Jfs\Uploader\Encoder\LoHH67lOeFp9J;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Service\KtvKQ6SgzhDbU;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class XE7R9TkGqTYDZ implements C3XDkOI7yIIoE
{
    private $V2UK5;
    private $uq849;
    private $PxC6l;
    private $Pmi2M;
    public function __construct($gNVOT, $kxhX9, $RH5Rq)
    {
        goto M_PFb;
        M_PFb:
        $this->uq849 = $gNVOT;
        goto OCkUr;
        nA3Ml:
        $this->Pmi2M = $RH5Rq;
        goto s7tP6;
        OCkUr:
        $this->PxC6l = $kxhX9;
        goto nA3Ml;
        s7tP6:
        $this->V2UK5 = $this->mi5hZL92dop();
        goto INulj;
        INulj:
    }
    public function mEE11OcGDDM($i2vqC, $Z8Kuq) : void
    {
        goto JcIG_;
        n4yEQ:
        if (!$this->V2UK5) {
            goto Gsfam;
        }
        goto K3Pyy;
        ZOlQc:
        AfYHT:
        goto EiVCX;
        xlBZY:
        sNIPk:
        goto DsC61;
        AMrFP:
        if (!$this->V2UK5) {
            goto AfYHT;
        }
        goto ahW8C;
        kd6OK:
        $this->uq849->save();
        goto AMrFP;
        DsC61:
        if (!(EHhCBxlsVyz9C::ENCODING_PROCESSED === $Z8Kuq)) {
            goto nYqsQ;
        }
        goto kd6OK;
        TyWGL:
        Gsfam:
        goto xlBZY;
        JcIG_:
        if (!(EHhCBxlsVyz9C::PROCESSING === $Z8Kuq)) {
            goto sNIPk;
        }
        goto g7r0f;
        g7r0f:
        $this->uq849->save();
        goto n4yEQ;
        K3Pyy:
        $this->V2UK5->process($Z8Kuq);
        goto TyWGL;
        ahW8C:
        $this->V2UK5->process($Z8Kuq);
        goto ZOlQc;
        EiVCX:
        nYqsQ:
        goto xPMbo;
        xPMbo:
    }
    private function mi5hZL92dop()
    {
        goto Qo53L;
        Qo53L:
        switch ($this->uq849->getType()) {
            case 'image':
                return new FSv3GPN90K6IS($this->uq849, $this->Pmi2M);
            case 'video':
                return new DrhNfMm6psarL($this->uq849, App::make(LoHH67lOeFp9J::class));
            default:
                return null;
        }
        goto Fuh2Z;
        IsZVo:
        TT8lB:
        goto zCAw4;
        Fuh2Z:
        t_uDl:
        goto IsZVo;
        zCAw4:
    }
}
