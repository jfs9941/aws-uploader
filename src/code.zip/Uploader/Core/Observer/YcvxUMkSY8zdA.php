<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Contracts\OrgzWokuJzoYp;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class YcvxUMkSY8zdA implements OrgzWokuJzoYp
{
    private $CqvUz;
    public function __construct($ezBDN)
    {
        $this->CqvUz = $ezBDN;
    }
    public function mjE8og0hkAa($upN77, $LB0Yo)
    {
        goto w53QG;
        nZoFp:
        cH11K:
        goto swB8c;
        w53QG:
        if (!(N4CY6qDTBAjPa::UPLOADED === $LB0Yo)) {
            goto cH11K;
        }
        goto jnQNa;
        cZILd:
        if (!$this->CqvUz instanceof NBWuSM65HseqY) {
            goto P1zR2;
        }
        goto l1dyh;
        t1dDC:
        P1zR2:
        goto AESix;
        jnQNa:
        $this->CqvUz->status = N4CY6qDTBAjPa::UPLOADED;
        goto cZILd;
        AESix:
        $this->CqvUz->save();
        goto nZoFp;
        OGSs6:
        t8iGI:
        goto VVUWn;
        l1dyh:
        $this->CqvUz->mNT1f7OoTvx(N4CY6qDTBAjPa::PROCESSING);
        goto t1dDC;
        E2khf:
        $this->CqvUz->delete();
        goto OGSs6;
        swB8c:
        if (!(N4CY6qDTBAjPa::DELETED === $LB0Yo && $this->CqvUz->mqioBzibeOU())) {
            goto t8iGI;
        }
        goto E2khf;
        VVUWn:
    }
}
