<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\Fg5ZctnJZvYzy;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Exception\DTlKOLT8tkTnv;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Jfs\Uploader\Presigned\XPrE42EoqXydt;
use Jfs\Uploader\Presigned\HYHv6shPonwa0;
final class PuvVk80m0ZCT8 implements Fg5ZctnJZvYzy
{
    private $Gy9Qo;
    private $YYkmA;
    private $aB4Qh;
    private $qFnIc;
    private $ey_Bg;
    public function __construct($au4Kn, $Q0D24, $A8Sfn, $F66z0, $L6GAX = false)
    {
        goto PUtFf;
        xcUoN:
        $this->ey_Bg = $F66z0;
        goto vQSCC;
        Dfj9d:
        w0YFF:
        goto apIvr;
        vQSCC:
        if ($L6GAX) {
            goto w0YFF;
        }
        goto BzHEk;
        ozT1b:
        $this->aB4Qh = $Q0D24;
        goto Sh7dG;
        BzHEk:
        $this->m16lxjhax8A();
        goto Dfj9d;
        Sh7dG:
        $this->qFnIc = $A8Sfn;
        goto xcUoN;
        PUtFf:
        $this->YYkmA = $au4Kn;
        goto ozT1b;
        apIvr:
    }
    private function m16lxjhax8A() : void
    {
        goto pZj7z;
        PS061:
        VpQJZ:
        goto k97yT;
        k97yT:
        try {
            $YKW91 = $this->YYkmA->mLK5jSa9bhL();
            $this->Gy9Qo = 's3' === $YKW91->P462y ? new HYHv6shPonwa0($this->YYkmA, $this->aB4Qh, $this->qFnIc, $this->ey_Bg) : new XPrE42EoqXydt($this->YYkmA, $this->aB4Qh, $this->qFnIc);
        } catch (LBGqEnYC0ItIS $nhDP5) {
            Log::warning("Failed to set up presigned upload: {$nhDP5->getMessage()}");
        }
        goto GcZXl;
        MwZv8:
        return;
        goto PS061;
        pZj7z:
        if (!(null !== $this->Gy9Qo)) {
            goto VpQJZ;
        }
        goto MwZv8;
        GcZXl:
    }
    public function mWjTC6Gp86v($sADJF, $mhWhW)
    {
        goto D2OCq;
        XXFMw:
        switch ($mhWhW) {
            case QUh2VVA2TE5xx::UPLOADING:
                $this->mOygBe6YGcd();
                goto GhXv8;
            case QUh2VVA2TE5xx::UPLOADED:
                $this->mxGPDyXaPG8();
                goto GhXv8;
            case QUh2VVA2TE5xx::ABORTED:
                $this->mYL9FHaH0SD();
                goto GhXv8;
            default:
                goto GhXv8;
        }
        goto NH_Gs;
        D2OCq:
        $this->m16lxjhax8A();
        goto XXFMw;
        bHSqg:
        GhXv8:
        goto jmmPO;
        NH_Gs:
        V2Ect:
        goto bHSqg;
        jmmPO:
    }
    private function mxGPDyXaPG8() : void
    {
        goto Xbuev;
        Xbuev:
        $this->Gy9Qo->mab8LR1F1c8();
        goto oAJkc;
        oAJkc:
        $xdi9a = $this->YYkmA->getFile();
        goto PyvB1;
        PyvB1:
        $xdi9a->meQCGHEeK80(QUh2VVA2TE5xx::UPLOADED);
        goto niw25;
        aYP2Y:
        jvxul:
        goto Y6Jv3;
        niw25:
        if (!$xdi9a instanceof B6s4AA1exjQ2T) {
            goto jvxul;
        }
        goto Xv3dY;
        Xv3dY:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($xdi9a->id);
        goto aYP2Y;
        Y6Jv3:
    }
    private function mYL9FHaH0SD() : void
    {
        $this->Gy9Qo->me69BIFTRSd();
    }
    private function mOygBe6YGcd() : void
    {
        $this->Gy9Qo->mX79Bq6DhRS();
    }
}
