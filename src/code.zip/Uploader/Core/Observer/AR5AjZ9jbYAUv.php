<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Contracts\BC3GCfM107Y7V;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Enum\SsxWbUYXracun;
class AR5AjZ9jbYAUv implements BC3GCfM107Y7V
{
    private $MF3ET;
    public function __construct($tscCi)
    {
        $this->MF3ET = $tscCi;
    }
    public function mUbEgwqXkQg($Y0L7L, $W4cEX)
    {
        goto AK1FV;
        SrpWV:
        $this->MF3ET->mvUghb89hzW(SsxWbUYXracun::PROCESSING);
        goto iAtuo;
        r9d4T:
        if (!(SsxWbUYXracun::DELETED === $W4cEX && $this->MF3ET->mR5L3wUZ8k3())) {
            goto x6F1m;
        }
        goto XO7x1;
        jx2KB:
        $this->MF3ET->save();
        goto S0J_O;
        XO7x1:
        $this->MF3ET->delete();
        goto rGFR7;
        oObaa:
        $this->MF3ET->status = SsxWbUYXracun::UPLOADED;
        goto Sz1gt;
        AK1FV:
        if (!(SsxWbUYXracun::UPLOADED === $W4cEX)) {
            goto JcNLD;
        }
        goto oObaa;
        iAtuo:
        t5Wbn:
        goto jx2KB;
        S0J_O:
        JcNLD:
        goto r9d4T;
        rGFR7:
        x6F1m:
        goto Wpq0Z;
        Sz1gt:
        if (!$this->MF3ET instanceof Kx3NMUJqFpl5Q) {
            goto t5Wbn;
        }
        goto SrpWV;
        Wpq0Z:
    }
}
