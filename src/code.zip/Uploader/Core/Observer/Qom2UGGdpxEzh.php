<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Contracts\BC3GCfM107Y7V;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Core\Strategy\POiLiwL4ziX4Y;
use Jfs\Uploader\Core\Strategy\Me6qEskrrZQgT;
use Jfs\Uploader\Encoder\WKWBYhZhEWOea;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Service\SqWT6oYd97hAj;
final class Qom2UGGdpxEzh implements BC3GCfM107Y7V
{
    private $RWqYT;
    private $MF3ET;
    private $dhrkT;
    private $t4ksb;
    public function __construct($tscCi, $v8n0s, $Ocj5L)
    {
        goto LPP18;
        gUqZy:
        $this->RWqYT = $this->m0yDcd2NmPy();
        goto RjfZK;
        Aky9j:
        $this->t4ksb = $Ocj5L;
        goto gUqZy;
        LPP18:
        $this->MF3ET = $tscCi;
        goto GUc0W;
        GUc0W:
        $this->dhrkT = $v8n0s;
        goto Aky9j;
        RjfZK:
    }
    public function mUbEgwqXkQg($Y0L7L, $W4cEX) : void
    {
        goto JdQ2I;
        WjqLk:
        if (!$this->RWqYT) {
            goto NUqrr;
        }
        goto ZvXkC;
        Q71LR:
        if (!(SsxWbUYXracun::ENCODING_PROCESSED === $W4cEX)) {
            goto MnHZq;
        }
        goto Unlg_;
        dIzLD:
        zXkTP:
        goto Q71LR;
        rz7az:
        Lz627:
        goto dIzLD;
        weyWl:
        $this->RWqYT->process($W4cEX);
        goto rz7az;
        ZvXkC:
        $this->RWqYT->process($W4cEX);
        goto Z2GBO;
        c2zkK:
        if (!$this->RWqYT) {
            goto Lz627;
        }
        goto weyWl;
        Unlg_:
        $this->MF3ET->save();
        goto WjqLk;
        smpUG:
        MnHZq:
        goto lYbKN;
        JdQ2I:
        if (!(SsxWbUYXracun::PROCESSING === $W4cEX)) {
            goto zXkTP;
        }
        goto ptz1i;
        ptz1i:
        $this->MF3ET->save();
        goto c2zkK;
        Z2GBO:
        NUqrr:
        goto smpUG;
        lYbKN:
    }
    private function m0yDcd2NmPy()
    {
        goto z3ImZ;
        vaw0y:
        HY6BK:
        goto jSRpb;
        z3ImZ:
        switch ($this->MF3ET->getType()) {
            case 'image':
                return new POiLiwL4ziX4Y($this->MF3ET, $this->t4ksb);
            case 'video':
                return new Me6qEskrrZQgT($this->MF3ET, App::make(WKWBYhZhEWOea::class));
            default:
                return null;
        }
        goto xsSg6;
        xsSg6:
        dPTLB:
        goto vaw0y;
        jSRpb:
    }
}
