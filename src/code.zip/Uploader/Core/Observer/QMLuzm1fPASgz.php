<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\P7eZRarQfx9Id;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Exception\SwRmuIL9tuB7h;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Jfs\Uploader\Presigned\Qm8iPn1xpA6MK;
use Jfs\Uploader\Presigned\N5hiEwPfaJUjD;
final class QMLuzm1fPASgz implements P7eZRarQfx9Id
{
    private $qPrCd;
    private $Y8BXM;
    private $UBJ9G;
    private $Mq65A;
    private $iqyyD;
    public function __construct($N50om, $e1L33, $o9ClE, $TnK9g, $u_MHC = false)
    {
        goto b4abA;
        JkwNO:
        $this->m7Ot00feggs();
        goto FD0i3;
        cIjT0:
        if ($u_MHC) {
            goto za7IA;
        }
        goto JkwNO;
        FD0i3:
        za7IA:
        goto Y8dPT;
        GdNAM:
        $this->Mq65A = $o9ClE;
        goto ShSjh;
        b4abA:
        $this->Y8BXM = $N50om;
        goto LGP8_;
        LGP8_:
        $this->UBJ9G = $e1L33;
        goto GdNAM;
        ShSjh:
        $this->iqyyD = $TnK9g;
        goto cIjT0;
        Y8dPT:
    }
    private function m7Ot00feggs() : void
    {
        goto sNfF5;
        W_55l:
        return;
        goto N4a4W;
        sNfF5:
        if (!(null !== $this->qPrCd)) {
            goto TBctv;
        }
        goto W_55l;
        HUlV4:
        try {
            $yqV2Y = $this->Y8BXM->mbu93E3v49T();
            $this->qPrCd = 's3' === $yqV2Y->jE_8B ? new N5hiEwPfaJUjD($this->Y8BXM, $this->UBJ9G, $this->Mq65A, $this->iqyyD) : new Qm8iPn1xpA6MK($this->Y8BXM, $this->UBJ9G, $this->Mq65A);
        } catch (Lki0sGWiU5Kzv $I8puu) {
            Log::warning("Failed to set up presigned upload: {$I8puu->getMessage()}");
        }
        goto Kyh6q;
        N4a4W:
        TBctv:
        goto HUlV4;
        Kyh6q:
    }
    public function m85MtNrnQlN($VOPJr, $O3gwv)
    {
        goto OGN_i;
        OGN_i:
        $this->m7Ot00feggs();
        goto T1Tvy;
        Km0M_:
        HcbX6:
        goto Ykmxw;
        Ykmxw:
        cE6Yz:
        goto hg0k_;
        T1Tvy:
        switch ($O3gwv) {
            case UimQKBIuLCEAO::UPLOADING:
                $this->mXhhemVHKV8();
                goto cE6Yz;
            case UimQKBIuLCEAO::UPLOADED:
                $this->mh5emupGqIT();
                goto cE6Yz;
            case UimQKBIuLCEAO::ABORTED:
                $this->mLXlMxbSxBZ();
                goto cE6Yz;
            default:
                goto cE6Yz;
        }
        goto Km0M_;
        hg0k_:
    }
    private function mh5emupGqIT() : void
    {
        goto c_vEY;
        NJXWh:
        $PQjbH = $this->Y8BXM->getFile();
        goto DFkkt;
        DFkkt:
        $PQjbH->mTKyaraJgz7(UimQKBIuLCEAO::UPLOADED);
        goto as4f2;
        as4f2:
        if (!$PQjbH instanceof RVcEF1JsGQd8M) {
            goto djak4;
        }
        goto COHX2;
        D57AD:
        djak4:
        goto UgNl3;
        COHX2:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($PQjbH->id);
        goto D57AD;
        c_vEY:
        $this->qPrCd->mdZHRNgOwob();
        goto NJXWh;
        UgNl3:
    }
    private function mLXlMxbSxBZ() : void
    {
        $this->qPrCd->mac8rClbTBj();
    }
    private function mXhhemVHKV8() : void
    {
        $this->qPrCd->muC09Jkb6rX();
    }
}
