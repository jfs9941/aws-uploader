<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Contracts\OZ0OEimEhcPCG;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
class WWNfwtucxYruU implements OZ0OEimEhcPCG
{
    private $WpbZG;
    public function __construct($cNpq7)
    {
        $this->WpbZG = $cNpq7;
    }
    public function mw8TbyaigDj($c9oe4, $Aof5j)
    {
        goto vS8Ft;
        jrRL5:
        fQamz:
        goto icreL;
        vS8Ft:
        if (!(FmSSI1JLQCp0W::UPLOADED === $Aof5j)) {
            goto VeI54;
        }
        goto h79vU;
        T2dkr:
        $this->WpbZG->muggTul6CGA(FmSSI1JLQCp0W::PROCESSING);
        goto HwK1g;
        AJ5kx:
        if (!(FmSSI1JLQCp0W::DELETED === $Aof5j && $this->WpbZG->mwR3OfZzJwr())) {
            goto fQamz;
        }
        goto pJUTc;
        h79vU:
        $this->WpbZG->status = FmSSI1JLQCp0W::UPLOADED;
        goto mEu6z;
        HwK1g:
        aN46r:
        goto Kg3RW;
        mEu6z:
        if (!$this->WpbZG instanceof Q48IcpSr3UpAT) {
            goto aN46r;
        }
        goto T2dkr;
        YCPOt:
        VeI54:
        goto AJ5kx;
        Kg3RW:
        $this->WpbZG->save();
        goto YCPOt;
        pJUTc:
        $this->WpbZG->delete();
        goto jrRL5;
        icreL:
    }
}
