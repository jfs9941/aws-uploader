<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Contracts\Xg08pDZLenaCo;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
class FJEG2eFHx6sNT implements Xg08pDZLenaCo
{
    private $y_eVA;
    public function __construct($D55CH)
    {
        $this->y_eVA = $D55CH;
    }
    public function mnTJmPCq3BW($gAEvi, $G7Qtb)
    {
        goto gY_WU;
        aPbxI:
        DIGYb:
        goto ulfIn;
        mYMXP:
        $this->y_eVA->save();
        goto m199l;
        l9COx:
        if (!$this->y_eVA instanceof KyoDVfv3eGItF) {
            goto nECAZ;
        }
        goto rV4ig;
        WGfFd:
        nECAZ:
        goto mYMXP;
        gDC9Y:
        $this->y_eVA->status = Zgh3BZ2JVlG1A::UPLOADED;
        goto l9COx;
        rV4ig:
        $this->y_eVA->mKP20BPk5QC(Zgh3BZ2JVlG1A::PROCESSING);
        goto WGfFd;
        X1BpT:
        if (!(Zgh3BZ2JVlG1A::DELETED === $G7Qtb && $this->y_eVA->m9KpLiYTd3q())) {
            goto DIGYb;
        }
        goto Ld9ri;
        Ld9ri:
        $this->y_eVA->delete();
        goto aPbxI;
        gY_WU:
        if (!(Zgh3BZ2JVlG1A::UPLOADED === $G7Qtb)) {
            goto WnEY3;
        }
        goto gDC9Y;
        m199l:
        WnEY3:
        goto X1BpT;
        ulfIn:
    }
}
