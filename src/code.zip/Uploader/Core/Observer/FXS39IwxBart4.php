<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Contracts\Fg5ZctnJZvYzy;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
class FXS39IwxBart4 implements Fg5ZctnJZvYzy
{
    private $uXtKk;
    public function __construct($xdi9a)
    {
        $this->uXtKk = $xdi9a;
    }
    public function mWjTC6Gp86v($sADJF, $mhWhW)
    {
        goto CHqJd;
        PNtDb:
        eC41S:
        goto mhfZH;
        u_mA9:
        if (!$this->uXtKk instanceof OcbNsXl9lpteB) {
            goto eC41S;
        }
        goto YJHIx;
        TME59:
        $this->uXtKk->delete();
        goto FDZbv;
        mhfZH:
        $this->uXtKk->save();
        goto cYROD;
        fFWBm:
        $this->uXtKk->status = QUh2VVA2TE5xx::UPLOADED;
        goto u_mA9;
        cYROD:
        OH0iK:
        goto HOkd9;
        YJHIx:
        $this->uXtKk->meQCGHEeK80(QUh2VVA2TE5xx::PROCESSING);
        goto PNtDb;
        FDZbv:
        klaem:
        goto jxIR3;
        CHqJd:
        if (!(QUh2VVA2TE5xx::UPLOADED === $mhWhW)) {
            goto OH0iK;
        }
        goto fFWBm;
        HOkd9:
        if (!(QUh2VVA2TE5xx::DELETED === $mhWhW && $this->uXtKk->mrPmY9hxkjC())) {
            goto klaem;
        }
        goto TME59;
        jxIR3:
    }
}
