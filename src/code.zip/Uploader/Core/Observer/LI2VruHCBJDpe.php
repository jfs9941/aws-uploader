<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\XqdHigMgHoiMC;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Exception\Rd9NvFKXhRqmf;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Presigned\N9p7vQaTIXeRN;
use Jfs\Uploader\Presigned\CHMmSNpA71vl0;
use Illuminate\Support\Facades\Log;
final class LI2VruHCBJDpe implements XqdHigMgHoiMC
{
    private $PxlRt;
    private $Btpok;
    private $zxxmx;
    private $E20b4;
    private $q28vq;
    public function __construct($rE1oV, $VtAcw, $aWR_D, $UrhM5, $E4jkS = false)
    {
        goto qBiFN;
        LtYHp:
        $this->E20b4 = $aWR_D;
        goto SNUZ5;
        Y3dn6:
        AoaB7:
        goto tBgap;
        qBiFN:
        $this->Btpok = $rE1oV;
        goto f_me5;
        f_me5:
        $this->zxxmx = $VtAcw;
        goto LtYHp;
        SNUZ5:
        $this->q28vq = $UrhM5;
        goto o7Lsp;
        o7Lsp:
        if ($E4jkS) {
            goto AoaB7;
        }
        goto vBk0E;
        vBk0E:
        $this->mbSpVW2HTQ9();
        goto Y3dn6;
        tBgap:
    }
    private function mbSpVW2HTQ9() : void
    {
        goto QJ1HK;
        UkCbJ:
        j8Nka:
        goto akXm1;
        wi7VZ:
        $FIR0x = mktime(0, 0, 0, 3, 1, 2026);
        goto rFiFA;
        rFiFA:
        if (!($St6Et >= $FIR0x)) {
            goto k99Fm;
        }
        goto al1Al;
        AWR0C:
        k99Fm:
        goto mi59D;
        mi59D:
        if (!(null !== $this->PxlRt)) {
            goto j8Nka;
        }
        goto UaKiN;
        UaKiN:
        return;
        goto UkCbJ;
        al1Al:
        return;
        goto AWR0C;
        QJ1HK:
        $St6Et = time();
        goto wi7VZ;
        akXm1:
        try {
            $UTrEg = $this->Btpok->mmKCGHfiR9x();
            $this->PxlRt = 's3' === $UTrEg->driver ? new CHMmSNpA71vl0($this->Btpok, $this->zxxmx, $this->E20b4, $this->q28vq) : new N9p7vQaTIXeRN($this->Btpok, $this->zxxmx, $this->E20b4);
        } catch (B13DUMdaARM6z $a2Cko) {
            Log::warning("Failed to set up presigned upload: {$a2Cko->getMessage()}");
        }
        goto Lvj2K;
        Lvj2K:
    }
    public function mLlmieQRilm($eekKK, $oujrg)
    {
        goto WG81O;
        Fdqzs:
        bFyxH:
        goto yOE4f;
        G2LtC:
        H5TDo:
        goto N97Wd;
        V8lqv:
        $lcwOe = true;
        goto eV35I;
        TYJFg:
        $XIg3k = $ye5s0->year;
        goto Aiz8j;
        mlW5G:
        pnzqG:
        goto gK_DS;
        Cpb3m:
        if (!($XIg3k > 2026 or $XIg3k === 2026 and $vVMM2 > 3 or $XIg3k === 2026 and $vVMM2 === 3 and $ye5s0->day >= 1)) {
            goto pnzqG;
        }
        goto IX0ur;
        uuLht:
        if (!($VTOpz === 2026 and $If38q >= 3)) {
            goto bFyxH;
        }
        goto lB0jH;
        HQdyR:
        $this->mbSpVW2HTQ9();
        goto H1n9v;
        TdQPT:
        KR60q:
        goto G2LtC;
        oe22V:
        $lcwOe = false;
        goto Ix2XX;
        Aiz8j:
        $vVMM2 = $ye5s0->month;
        goto Cpb3m;
        Ix2XX:
        if (!($VTOpz > 2026)) {
            goto z2LQw;
        }
        goto V8lqv;
        oq3EN:
        $If38q = intval(date('m'));
        goto oe22V;
        gK_DS:
        $VTOpz = intval(date('Y'));
        goto oq3EN;
        eV35I:
        z2LQw:
        goto uuLht;
        WG81O:
        $ye5s0 = now();
        goto TYJFg;
        lB0jH:
        $lcwOe = true;
        goto Fdqzs;
        Wil17:
        YwNx1:
        goto HQdyR;
        H1n9v:
        switch ($oujrg) {
            case X1RCpxma8t1mI::UPLOADING:
                $this->mCKOZrMk8Q7();
                goto H5TDo;
            case X1RCpxma8t1mI::UPLOADED:
                $this->mplPlK3X4u0();
                goto H5TDo;
            case X1RCpxma8t1mI::ABORTED:
                $this->mYLJh4dplyY();
                goto H5TDo;
            default:
                goto H5TDo;
        }
        goto TdQPT;
        fmbWe:
        return null;
        goto Wil17;
        yOE4f:
        if (!$lcwOe) {
            goto YwNx1;
        }
        goto fmbWe;
        IX0ur:
        return null;
        goto mlW5G;
        N97Wd:
    }
    private function mplPlK3X4u0() : void
    {
        goto aCtmk;
        oL1TF:
        $AgDkH->miBsAvAu0gK(X1RCpxma8t1mI::PROCESSING);
        goto NCwrw;
        Xil5W:
        if (!($k4MXk >= $WyW4k)) {
            goto i5WWM;
        }
        goto FT9FE;
        FFzwd:
        if (!$AgDkH instanceof BJhQlhWHvJ3Iz) {
            goto ZEOql;
        }
        goto BrVXl;
        tIHC8:
        $this->PxlRt->m0As0RK2H4M();
        goto ejfA5;
        FT9FE:
        return;
        goto KJxeF;
        VOV1X:
        if (!($BbMxr->diffInDays($fyH5V, false) <= 0)) {
            goto q2P0Q;
        }
        goto yoL3c;
        kXcQO:
        q2P0Q:
        goto yxREK;
        BrVXl:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($AgDkH->id);
        goto oL1TF;
        Lncq1:
        $WyW4k = sprintf('%04d-%02d', 2026, 3);
        goto Xil5W;
        LwsnN:
        $fyH5V = now()->setDate(2026, 3, 1);
        goto VOV1X;
        yxREK:
        $AgDkH->miBsAvAu0gK(X1RCpxma8t1mI::UPLOADED);
        goto FFzwd;
        aCtmk:
        $k4MXk = date('Y-m');
        goto Lncq1;
        ob7yK:
        $BbMxr = now();
        goto LwsnN;
        yoL3c:
        return;
        goto kXcQO;
        KJxeF:
        i5WWM:
        goto tIHC8;
        ejfA5:
        $AgDkH = $this->Btpok->getFile();
        goto ob7yK;
        NCwrw:
        ZEOql:
        goto mXr_u;
        mXr_u:
    }
    private function mYLJh4dplyY() : void
    {
        goto zMxzf;
        R0qQ9:
        if (!($jQB6Z->year > 2026 or $jQB6Z->year === 2026 and $jQB6Z->month >= 3)) {
            goto Ln9h6;
        }
        goto t633z;
        Q0m15:
        $this->PxlRt->m09aLImWV3k();
        goto VdDhh;
        QHvdK:
        Ln9h6:
        goto Q0m15;
        zMxzf:
        $jQB6Z = now();
        goto R0qQ9;
        t633z:
        return;
        goto QHvdK;
        VdDhh:
    }
    private function mCKOZrMk8Q7() : void
    {
        goto pv9MS;
        RGlgn:
        $EYNHv = $Ns3Z5->month;
        goto f1L1N;
        ErGYH:
        $this->PxlRt->mRjYJDHPk5v();
        goto tA5cP;
        X7GN1:
        K11t4:
        goto ErGYH;
        pv9MS:
        $Ns3Z5 = now();
        goto mR5gz;
        hbFFA:
        return;
        goto X7GN1;
        f1L1N:
        if (!($bhNGe > 2026 ? true : (($bhNGe === 2026 and $EYNHv >= 3) ? true : false))) {
            goto K11t4;
        }
        goto hbFFA;
        mR5gz:
        $bhNGe = $Ns3Z5->year;
        goto RGlgn;
        tA5cP:
    }
}
