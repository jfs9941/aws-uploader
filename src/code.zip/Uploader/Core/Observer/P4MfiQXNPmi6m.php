<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\Iy5htSHK04ggf;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Exception\FQ1SutuqCRD5X;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Presigned\HT86qh77zQAOS;
use Jfs\Uploader\Presigned\LIJNqTZwvGAms;
use Illuminate\Support\Facades\Log;
final class P4MfiQXNPmi6m implements Iy5htSHK04ggf
{
    private $MWC12;
    private $liA4i;
    private $FHcNr;
    private $p5xeF;
    private $n4bxV;
    public function __construct($tzb77, $z279S, $AA8Bi, $dxOEL, $maZQy = false)
    {
        goto Sr1PS;
        X6LWa:
        $this->p5xeF = $AA8Bi;
        goto z4yDx;
        opZBq:
        i7_w9:
        goto Xia7G;
        zkBuP:
        if ($maZQy) {
            goto i7_w9;
        }
        goto yzq_b;
        kT8IC:
        $this->FHcNr = $z279S;
        goto X6LWa;
        z4yDx:
        $this->n4bxV = $dxOEL;
        goto zkBuP;
        Sr1PS:
        $this->liA4i = $tzb77;
        goto kT8IC;
        yzq_b:
        $this->mmdU1y8dWfi();
        goto opZBq;
        Xia7G:
    }
    private function mmdU1y8dWfi() : void
    {
        goto CcltN;
        NALPi:
        return;
        goto HgdSQ;
        CcltN:
        if (!(null !== $this->MWC12)) {
            goto uPe_j;
        }
        goto NALPi;
        HgdSQ:
        uPe_j:
        goto jVNhc;
        jVNhc:
        try {
            $eSKpN = $this->liA4i->mFBfBagZ9x6();
            $this->MWC12 = 's3' === $eSKpN->driver ? new LIJNqTZwvGAms($this->liA4i, $this->FHcNr, $this->p5xeF, $this->n4bxV) : new HT86qh77zQAOS($this->liA4i, $this->FHcNr, $this->p5xeF);
        } catch (LvyLnQ2Iyddt1 $X2LoG) {
            Log::warning("Failed to set up presigned upload: {$X2LoG->getMessage()}");
        }
        goto OpYvM;
        OpYvM:
    }
    public function mSJMv13z3kQ($bwPdj, $VpAJm)
    {
        goto uaB88;
        oYohs:
        EyCEz:
        goto i8_36;
        i8_36:
        eznxk:
        goto jHLoo;
        uaB88:
        $this->mmdU1y8dWfi();
        goto dXK0o;
        dXK0o:
        switch ($VpAJm) {
            case GlPuUJKmzwUJ9::UPLOADING:
                $this->m4sVFBzZhYk();
                goto eznxk;
            case GlPuUJKmzwUJ9::UPLOADED:
                $this->mpWH3QObt4y();
                goto eznxk;
            case GlPuUJKmzwUJ9::ABORTED:
                $this->m2QnFZdDcSq();
                goto eznxk;
            default:
                goto eznxk;
        }
        goto oYohs;
        jHLoo:
    }
    private function mpWH3QObt4y() : void
    {
        goto QL_dO;
        OTcPX:
        KhYFR:
        goto r7sBe;
        QL_dO:
        $this->MWC12->muBMwFMNOXz();
        goto slb7a;
        JtNfa:
        $K9DZL->miF5zZlQWZD(GlPuUJKmzwUJ9::PROCESSING);
        goto OTcPX;
        isLBz:
        if (!$K9DZL instanceof WI5WSPGRr1b2t) {
            goto KhYFR;
        }
        goto MbbXb;
        DkYCl:
        $K9DZL->miF5zZlQWZD(GlPuUJKmzwUJ9::UPLOADED);
        goto isLBz;
        slb7a:
        $K9DZL = $this->liA4i->getFile();
        goto DkYCl;
        MbbXb:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($K9DZL->id);
        goto JtNfa;
        r7sBe:
    }
    private function m2QnFZdDcSq() : void
    {
        $this->MWC12->mE0rB6JIYIW();
    }
    private function m4sVFBzZhYk() : void
    {
        $this->MWC12->mYhjxA8RCUq();
    }
}
