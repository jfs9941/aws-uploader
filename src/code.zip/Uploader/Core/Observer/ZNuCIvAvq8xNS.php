<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Contracts\KQPO3KR6pEPcF;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\Strategy\EyqJ0idd6ccwL;
use Jfs\Uploader\Core\Strategy\JOFetdPCJuv2m;
use Jfs\Uploader\Encoder\NLoWoIWKwVnRR;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Service\ETNYJFyUYZrNI;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class ZNuCIvAvq8xNS implements KQPO3KR6pEPcF
{
    private $UnJAk;
    private $VCrIB;
    private $zbU8n;
    private $NlhMr;
    public function __construct($k2MU3, $Efy84, $rS7iQ)
    {
        goto KnuJv;
        GyZZj:
        $this->NlhMr = $rS7iQ;
        goto V46cs;
        ZTr4I:
        $this->zbU8n = $Efy84;
        goto GyZZj;
        KnuJv:
        $this->VCrIB = $k2MU3;
        goto ZTr4I;
        V46cs:
        $this->UnJAk = $this->mQNFaLl8127();
        goto TdL73;
        TdL73:
    }
    public function m6Fp3pM8yAa($Qc9id, $ZPmF2) : void
    {
        goto gBKu4;
        OYLPd:
        $this->VCrIB->save();
        goto Fmq3A;
        HRIq5:
        eR5Bv:
        goto u0M4Q;
        rgnfi:
        cRoEd:
        goto SeYHe;
        Fmq3A:
        if (!$this->UnJAk) {
            goto eR5Bv;
        }
        goto UqxWk;
        SeYHe:
        kq2ga:
        goto jeFBS;
        UqxWk:
        $this->UnJAk->process($ZPmF2);
        goto HRIq5;
        rVgpV:
        $this->VCrIB->save();
        goto MkjQE;
        u0M4Q:
        EVnBF:
        goto YrFu8;
        gBKu4:
        if (!(A9q1Lm9l5QixG::PROCESSING === $ZPmF2)) {
            goto EVnBF;
        }
        goto OYLPd;
        tHlQA:
        $this->UnJAk->process($ZPmF2);
        goto rgnfi;
        YrFu8:
        if (!(A9q1Lm9l5QixG::ENCODING_PROCESSED === $ZPmF2)) {
            goto kq2ga;
        }
        goto rVgpV;
        MkjQE:
        if (!$this->UnJAk) {
            goto cRoEd;
        }
        goto tHlQA;
        jeFBS:
    }
    private function mQNFaLl8127()
    {
        goto pohtj;
        owB0U:
        MPqfP:
        goto sgzTo;
        pohtj:
        switch ($this->VCrIB->getType()) {
            case 'image':
                return new EyqJ0idd6ccwL($this->VCrIB, $this->NlhMr);
            case 'video':
                return new JOFetdPCJuv2m($this->VCrIB, App::make(NLoWoIWKwVnRR::class));
            default:
                return null;
        }
        goto NYQRp;
        NYQRp:
        Y5FyL:
        goto owB0U;
        sgzTo:
    }
}
