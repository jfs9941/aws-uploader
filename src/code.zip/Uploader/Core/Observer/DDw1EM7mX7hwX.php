<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Contracts\IYQ9W9yMaFIDi;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
class DDw1EM7mX7hwX implements IYQ9W9yMaFIDi
{
    private $d3RM8;
    public function __construct($ZPsYd)
    {
        $this->d3RM8 = $ZPsYd;
    }
    public function mX3kB2cejfz($CvLh2, $AOQvb)
    {
        goto FsiEj;
        AEhvO:
        $this->d3RM8->delete();
        goto z2Wjn;
        z2Wjn:
        VvgAv:
        goto m2tOq;
        N1K7V:
        $this->d3RM8->save();
        goto ZTofE;
        TVKgH:
        $this->d3RM8->mvj3nnnI629(TSfaBZEUMcbl0::PROCESSING);
        goto dFbrC;
        ZTofE:
        JdkuQ:
        goto BgeyL;
        FsiEj:
        if (!(TSfaBZEUMcbl0::UPLOADED === $AOQvb)) {
            goto JdkuQ;
        }
        goto VnHI2;
        BgeyL:
        if (!(TSfaBZEUMcbl0::DELETED === $AOQvb && $this->d3RM8->mQao2a3rs3E())) {
            goto VvgAv;
        }
        goto AEhvO;
        VnHI2:
        $this->d3RM8->status = TSfaBZEUMcbl0::UPLOADED;
        goto bdO1r;
        dFbrC:
        A49zx:
        goto N1K7V;
        bdO1r:
        if (!$this->d3RM8 instanceof WUuz09CA4woAL) {
            goto A49zx;
        }
        goto TVKgH;
        m2tOq:
    }
}
