<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Contracts\AbQOw1WF9dU8u;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
class S3SDRlCvwlTH3 implements AbQOw1WF9dU8u
{
    private $Suzy5;
    public function __construct($RCdwx)
    {
        $this->Suzy5 = $RCdwx;
    }
    public function mcSizi4ikHF($S1194, $T_gUk)
    {
        goto Ntlg3;
        Ntlg3:
        if (!(Tbw0jsMnRbOTP::UPLOADED === $T_gUk)) {
            goto U3brQ;
        }
        goto l6Y1D;
        c_xqV:
        if (!(Tbw0jsMnRbOTP::DELETED === $T_gUk && $this->Suzy5->mIOiqFbXnGX())) {
            goto UqMYP;
        }
        goto k_5I6;
        cEMtp:
        $this->Suzy5->mIiE80g96Fo(Tbw0jsMnRbOTP::PROCESSING);
        goto OkO40;
        JzjC_:
        if (!$this->Suzy5 instanceof X9YHjKrAdcfhe) {
            goto W84Ge;
        }
        goto cEMtp;
        k_5I6:
        $this->Suzy5->delete();
        goto rUoGN;
        l6Y1D:
        $this->Suzy5->status = Tbw0jsMnRbOTP::UPLOADED;
        goto JzjC_;
        rUoGN:
        UqMYP:
        goto OSocL;
        jJNRK:
        $this->Suzy5->save();
        goto LhlKY;
        LhlKY:
        U3brQ:
        goto c_xqV;
        OkO40:
        W84Ge:
        goto jJNRK;
        OSocL:
    }
}
