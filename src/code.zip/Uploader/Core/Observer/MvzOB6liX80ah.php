<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\ObP0zC4B5AwYR;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Exception\C3neahanZnmCi;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Presigned\JiXGfTL8SelJH;
use Jfs\Uploader\Presigned\N7xOdqydXtnll;
use Illuminate\Support\Facades\Log;
final class MvzOB6liX80ah implements ObP0zC4B5AwYR
{
    private $ztnz7;
    private $MRm9W;
    private $iK6YG;
    private $g3eUc;
    private $lQSuV;
    public function __construct($oF7W0, $whVTJ, $NWP4g, $zocZ_, $KYPqg = false)
    {
        goto C2oqY;
        nPZ91:
        if ($KYPqg) {
            goto XjWQe;
        }
        goto Cfa27;
        Toz0K:
        $this->g3eUc = $NWP4g;
        goto kykFE;
        HBdDd:
        XjWQe:
        goto y9MPg;
        Cfa27:
        $this->mojk928Movi();
        goto HBdDd;
        kXDHV:
        $this->iK6YG = $whVTJ;
        goto Toz0K;
        C2oqY:
        $this->MRm9W = $oF7W0;
        goto kXDHV;
        kykFE:
        $this->lQSuV = $zocZ_;
        goto nPZ91;
        y9MPg:
    }
    private function mojk928Movi() : void
    {
        goto lXTl_;
        HRb3n:
        try {
            $zEBfx = $this->MRm9W->mjSURMEZOXx();
            $this->ztnz7 = 's3' === $zEBfx->driver ? new N7xOdqydXtnll($this->MRm9W, $this->iK6YG, $this->g3eUc, $this->lQSuV) : new JiXGfTL8SelJH($this->MRm9W, $this->iK6YG, $this->g3eUc);
        } catch (TKLv3jf5qXCAJ $T0fYK) {
            Log::warning("Failed to set up presigned upload: {$T0fYK->getMessage()}");
        }
        goto PEP_x;
        WpYme:
        if (!(null !== $this->ztnz7)) {
            goto bpaUq;
        }
        goto N1162;
        JopwO:
        $fmacW = intval(date('m'));
        goto aBeNd;
        M3oax:
        if (!($X0c9P > 2026)) {
            goto wC0zd;
        }
        goto dEdxD;
        O5mT4:
        bpaUq:
        goto J5IFs;
        Hr7wR:
        Gcasp:
        goto FE0_2;
        MmlzA:
        zmEqc:
        goto HRb3n;
        wOas7:
        $vTQwY = true;
        goto Hr7wR;
        PN2kV:
        wC0zd:
        goto D01ml;
        lXTl_:
        $X0c9P = intval(date('Y'));
        goto JopwO;
        D01ml:
        if (!($X0c9P === 2026 and $fmacW >= 3)) {
            goto Gcasp;
        }
        goto wOas7;
        dEdxD:
        $vTQwY = true;
        goto PN2kV;
        ejvHN:
        $jpMmo = mktime(0, 0, 0, 3, 1, 2026);
        goto tHPZZ;
        tHPZZ:
        if (!($DLGzr >= $jpMmo)) {
            goto zmEqc;
        }
        goto XpSiM;
        XpSiM:
        return;
        goto MmlzA;
        FE0_2:
        if (!$vTQwY) {
            goto xK3fN;
        }
        goto H9HXn;
        AH0Ys:
        xK3fN:
        goto WpYme;
        H9HXn:
        return;
        goto AH0Ys;
        N1162:
        return;
        goto O5mT4;
        aBeNd:
        $vTQwY = false;
        goto M3oax;
        J5IFs:
        $DLGzr = time();
        goto ejvHN;
        PEP_x:
    }
    public function mjDXRGNQTxn($Dqtza, $oEcw2)
    {
        goto mSepG;
        qDqlO:
        zjhW1:
        goto lqeu2;
        ILdP8:
        switch ($oEcw2) {
            case CTJGrzH3klS5t::UPLOADING:
                $this->m9HGCGP2EuJ();
                goto zjhW1;
            case CTJGrzH3klS5t::UPLOADED:
                $this->mPanmLICVQi();
                goto zjhW1;
            case CTJGrzH3klS5t::ABORTED:
                $this->mC6QdxWka2Y();
                goto zjhW1;
            default:
                goto zjhW1;
        }
        goto FD_5D;
        i312d:
        Ygn3o:
        goto cfZIV;
        Mhxus:
        $N0fla = now()->setDate(2026, 3, 1);
        goto CRXri;
        FD_5D:
        ZPFbk:
        goto qDqlO;
        v0Zbq:
        return null;
        goto u8iyL;
        zdf_u:
        $Wtj8D = $sC9a6->year;
        goto W2mww;
        u8iyL:
        gfakk:
        goto qYOQr;
        mSepG:
        $OBnNn = now();
        goto Mhxus;
        W2mww:
        $cn8_3 = $sC9a6->month;
        goto P4P5W;
        P4P5W:
        if (!($Wtj8D > 2026 or $Wtj8D === 2026 and $cn8_3 > 3 or $Wtj8D === 2026 and $cn8_3 === 3 and $sC9a6->day >= 1)) {
            goto gfakk;
        }
        goto v0Zbq;
        qYOQr:
        $this->mojk928Movi();
        goto ILdP8;
        w8NUV:
        return null;
        goto i312d;
        cfZIV:
        $sC9a6 = now();
        goto zdf_u;
        CRXri:
        if (!($OBnNn->diffInDays($N0fla, false) <= 0)) {
            goto Ygn3o;
        }
        goto w8NUV;
        lqeu2:
    }
    private function mPanmLICVQi() : void
    {
        goto jYdna;
        YCpda:
        return;
        goto VE_vJ;
        g3su1:
        if (!($ucMIC >= $kIi_N)) {
            goto Xx_ts;
        }
        goto o87G0;
        pGho1:
        $ucMIC = date('Y-m');
        goto N4Upp;
        hdm58:
        $Z1rIR->miTV603ASKT(CTJGrzH3klS5t::UPLOADED);
        goto Iq0Vz;
        VE_vJ:
        WW1LK:
        goto E2Yjr;
        MZjge:
        $Z1rIR = $this->MRm9W->getFile();
        goto hdm58;
        BeJFD:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($Z1rIR->id);
        goto NzUEH;
        cTwU3:
        Tr0bk:
        goto Ro5oX;
        o87G0:
        return;
        goto oWojz;
        NzUEH:
        $Z1rIR->miTV603ASKT(CTJGrzH3klS5t::PROCESSING);
        goto cTwU3;
        EWwNA:
        if (!($brcI3->year > 2026 or $brcI3->year === 2026 and $brcI3->month >= 3)) {
            goto WW1LK;
        }
        goto YCpda;
        jYdna:
        $brcI3 = now();
        goto EWwNA;
        Iq0Vz:
        if (!$Z1rIR instanceof EzVEhphZx2dEv) {
            goto Tr0bk;
        }
        goto BeJFD;
        oWojz:
        Xx_ts:
        goto MZjge;
        E2Yjr:
        $this->ztnz7->mIhS5EJUYRW();
        goto pGho1;
        N4Upp:
        $kIi_N = sprintf('%04d-%02d', 2026, 3);
        goto g3su1;
        Ro5oX:
    }
    private function mC6QdxWka2Y() : void
    {
        goto z0gwW;
        BFvDr:
        $this->ztnz7->m7ibajs9l4v();
        goto o_70a;
        pea1K:
        $MT224 = $YTcwu->month;
        goto g1O_m;
        dFfCK:
        return;
        goto TpoF3;
        CiReO:
        $ivJBJ = $YTcwu->year;
        goto pea1K;
        z0gwW:
        $YTcwu = now();
        goto CiReO;
        g1O_m:
        if (!($ivJBJ > 2026 ? true : (($ivJBJ === 2026 and $MT224 >= 3) ? true : false))) {
            goto ooY1o;
        }
        goto dFfCK;
        TpoF3:
        ooY1o:
        goto BFvDr;
        o_70a:
    }
    private function m9HGCGP2EuJ() : void
    {
        goto i43nU;
        zMhW8:
        if (!($TbxsI[0] > 2026 or $TbxsI[0] === 2026 and $TbxsI[1] > 3 or $TbxsI[0] === 2026 and $TbxsI[1] === 3 and $TbxsI[2] >= 1)) {
            goto kYNv7;
        }
        goto eyOgy;
        GecH8:
        return;
        goto GJrCn;
        tUTgT:
        if (!(time() >= $M4yUS)) {
            goto jF_DQ;
        }
        goto GecH8;
        qRhSx:
        $nzpiF = now();
        goto grC0c;
        GJrCn:
        jF_DQ:
        goto qRhSx;
        GWpi6:
        $M4yUS = strtotime($WgklL);
        goto tUTgT;
        i43nU:
        $WgklL = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto GWpi6;
        Vb0nj:
        $this->ztnz7->mcO7F0ux9HF();
        goto hDlHM;
        grC0c:
        $TbxsI = [$nzpiF->year, $nzpiF->month, $nzpiF->day];
        goto zMhW8;
        h9GsG:
        kYNv7:
        goto Vb0nj;
        eyOgy:
        return;
        goto h9GsG;
        hDlHM:
    }
}
