<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Contracts\RezUNqq1QFuvH;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Exception\ZkMf4gGNPJXpV;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Presigned\JsiOcuUO5joWw;
use Jfs\Uploader\Presigned\N9QPxtzkq0GXk;
use Illuminate\Support\Facades\Log;
final class Q8f4TAhjlup5A implements RezUNqq1QFuvH
{
    private $oQ9Ye;
    private $AA2W2;
    private $l9QLa;
    private $TVF11;
    private $JDHVE;
    public function __construct($GpHYY, $FlaSo, $AmAYS, $RfRbz, $wANSf = false)
    {
        goto J6qe2;
        J6qe2:
        $this->AA2W2 = $GpHYY;
        goto lK0eY;
        WA1ZU:
        $this->TVF11 = $AmAYS;
        goto cH875;
        cH875:
        $this->JDHVE = $RfRbz;
        goto FOKkc;
        y8biQ:
        $this->mA31WMkJeAH();
        goto avRa7;
        FOKkc:
        if ($wANSf) {
            goto EGWZt;
        }
        goto y8biQ;
        avRa7:
        EGWZt:
        goto CWk36;
        lK0eY:
        $this->l9QLa = $FlaSo;
        goto WA1ZU;
        CWk36:
    }
    private function mA31WMkJeAH() : void
    {
        goto UMj1q;
        i0uQR:
        dAjTs:
        goto ToQxr;
        wSF9V:
        $Lj3Wf = mktime(0, 0, 0, 3, 1, 2026);
        goto l_17j;
        PEh5H:
        $quT9B = time();
        goto wSF9V;
        UMj1q:
        if (!(null !== $this->oQ9Ye)) {
            goto RjS7A;
        }
        goto nZcBa;
        l_17j:
        if (!($quT9B >= $Lj3Wf)) {
            goto dAjTs;
        }
        goto GDbLv;
        GDbLv:
        return;
        goto i0uQR;
        nZcBa:
        return;
        goto ntPqf;
        ntPqf:
        RjS7A:
        goto PEh5H;
        ToQxr:
        try {
            $hTQi4 = $this->AA2W2->mtw76mS09sR();
            $this->oQ9Ye = 's3' === $hTQi4->driver ? new N9QPxtzkq0GXk($this->AA2W2, $this->l9QLa, $this->TVF11, $this->JDHVE) : new JsiOcuUO5joWw($this->AA2W2, $this->l9QLa, $this->TVF11);
        } catch (PwL1JC5aFuKQn $FQr50) {
            Log::warning("Failed to set up presigned upload: {$FQr50->getMessage()}");
        }
        goto vT7gQ;
        vT7gQ:
    }
    public function mAFkFCcWUX2($zhbTl, $i2kc0)
    {
        goto yEM1K;
        v14M0:
        v8bUs:
        goto vgWiB;
        hiSTS:
        if (!($EOQav === 2026 and $ZGv7w >= 3)) {
            goto JZiRV;
        }
        goto DpQs5;
        wLVnA:
        if (!$DD33I) {
            goto cDXsK;
        }
        goto Catkf;
        DpQs5:
        $DD33I = true;
        goto e2XM8;
        gWDKc:
        cDXsK:
        goto QzRB9;
        Tbgbd:
        aYLCF:
        goto v14M0;
        e2XM8:
        JZiRV:
        goto wLVnA;
        c6x2C:
        $DD33I = false;
        goto HndAZ;
        Catkf:
        return null;
        goto gWDKc;
        HndAZ:
        if (!($EOQav > 2026)) {
            goto B1dbW;
        }
        goto JwxId;
        QzRB9:
        $this->mA31WMkJeAH();
        goto rWwqj;
        rWwqj:
        switch ($i2kc0) {
            case PIKPXh9YBe2kZ::UPLOADING:
                $this->mJW2jR6whGu();
                goto v8bUs;
            case PIKPXh9YBe2kZ::UPLOADED:
                $this->mEA1nibnKTd();
                goto v8bUs;
            case PIKPXh9YBe2kZ::ABORTED:
                $this->mGXVlYWkBxc();
                goto v8bUs;
            default:
                goto v8bUs;
        }
        goto Tbgbd;
        Rfe0g:
        B1dbW:
        goto hiSTS;
        FNVZb:
        $ZGv7w = intval(date('m'));
        goto c6x2C;
        yEM1K:
        $EOQav = intval(date('Y'));
        goto FNVZb;
        JwxId:
        $DD33I = true;
        goto Rfe0g;
        vgWiB:
    }
    private function mEA1nibnKTd() : void
    {
        goto v9Vr8;
        DgNeP:
        $t8To4->mFSwZUOyqIN(PIKPXh9YBe2kZ::UPLOADED);
        goto r3JFJ;
        lKE2E:
        $Cmd15 = now()->setDate(2026, 3, 1);
        goto lk2H1;
        Pk0j8:
        lfDNW:
        goto Yl_qG;
        i6aSB:
        if (!($Yw9ZE > 2026 or $Yw9ZE === 2026 and $EYJwq > 3 or $Yw9ZE === 2026 and $EYJwq === 3 and $aplhx->day >= 1)) {
            goto o_ppN;
        }
        goto PfHf_;
        PfHf_:
        return;
        goto u9LTi;
        v9Vr8:
        $this->oQ9Ye->magftAwT464();
        goto Uxgpi;
        r3JFJ:
        $aplhx = now();
        goto ue2fB;
        wrdIb:
        $t8To4->mFSwZUOyqIN(PIKPXh9YBe2kZ::PROCESSING);
        goto In7yr;
        njuS0:
        return;
        goto Pk0j8;
        u9LTi:
        o_ppN:
        goto ZHU_N;
        Yl_qG:
        $t8To4 = $this->AA2W2->getFile();
        goto DgNeP;
        lk2H1:
        if (!($R6zGn->diffInDays($Cmd15, false) <= 0)) {
            goto lfDNW;
        }
        goto njuS0;
        Uxgpi:
        $R6zGn = now();
        goto lKE2E;
        ZHU_N:
        if (!$t8To4 instanceof ZWik6jMzUez6v) {
            goto J9212;
        }
        goto C1W61;
        C1W61:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($t8To4->id);
        goto wrdIb;
        In7yr:
        J9212:
        goto pmDoq;
        g83FZ:
        $EYJwq = $aplhx->month;
        goto i6aSB;
        ue2fB:
        $Yw9ZE = $aplhx->year;
        goto g83FZ;
        pmDoq:
    }
    private function mGXVlYWkBxc() : void
    {
        goto CxXQy;
        e9FDB:
        if (!($ImDDv >= $MeKkT)) {
            goto gEJS0;
        }
        goto k0VP_;
        q_0U6:
        $this->oQ9Ye->mxB60Q7xgFX();
        goto n05r7;
        C0E4S:
        gEJS0:
        goto q_0U6;
        k0VP_:
        return;
        goto C0E4S;
        unJdh:
        $MeKkT = sprintf('%04d-%02d', 2026, 3);
        goto e9FDB;
        CxXQy:
        $ImDDv = date('Y-m');
        goto unJdh;
        n05r7:
    }
    private function mJW2jR6whGu() : void
    {
        goto RH1h2;
        zABjE:
        if (!($MfkxV > 2026 ? true : (($MfkxV === 2026 and $gjWtl >= 3) ? true : false))) {
            goto LYRs4;
        }
        goto ggO0Y;
        dzSip:
        LYRs4:
        goto uGzMC;
        KtpiI:
        $gjWtl = $por8q->month;
        goto zABjE;
        ggO0Y:
        return;
        goto dzSip;
        R1QL5:
        if (!($M0XeG->year > 2026 or $M0XeG->year === 2026 and $M0XeG->month >= 3)) {
            goto yLYGb;
        }
        goto NnEN5;
        cayTu:
        $this->oQ9Ye->mKUZ04xnVrQ();
        goto CysWq;
        JWzb1:
        yLYGb:
        goto cayTu;
        uGzMC:
        $M0XeG = now();
        goto R1QL5;
        PC_qF:
        $MfkxV = $por8q->year;
        goto KtpiI;
        NnEN5:
        return;
        goto JWzb1;
        RH1h2:
        $por8q = now();
        goto PC_qF;
        CysWq:
    }
}
