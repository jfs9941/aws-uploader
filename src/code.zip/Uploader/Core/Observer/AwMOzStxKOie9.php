<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Contracts\IlXdNMxZGcSoS;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
class AwMOzStxKOie9 implements IlXdNMxZGcSoS
{
    private $YG65u;
    public function __construct($Z5ydB)
    {
        $this->YG65u = $Z5ydB;
    }
    public function mZowOLQCS3i($PcLOc, $Kkroe)
    {
        goto UCYMJ;
        fSWsZ:
        if (!(M7O7NSiJU2JG5::DELETED === $Kkroe && $this->YG65u->mlRW2CpfZjl())) {
            goto btWrR;
        }
        goto eB6wT;
        oJ7M1:
        $this->YG65u->save();
        goto gU__6;
        JaFXV:
        if (!$this->YG65u instanceof KCmQR4pvm0dT3) {
            goto dHziP;
        }
        goto dQuQq;
        gU__6:
        fS7ht:
        goto fSWsZ;
        Jc5mP:
        dHziP:
        goto oJ7M1;
        Ohu7b:
        btWrR:
        goto JDNPp;
        ywx8q:
        $this->YG65u->status = M7O7NSiJU2JG5::UPLOADED;
        goto JaFXV;
        eB6wT:
        $this->YG65u->delete();
        goto Ohu7b;
        dQuQq:
        $this->YG65u->mpDdU9lVtpc(M7O7NSiJU2JG5::PROCESSING);
        goto Jc5mP;
        UCYMJ:
        if (!(M7O7NSiJU2JG5::UPLOADED === $Kkroe)) {
            goto fS7ht;
        }
        goto ywx8q;
        JDNPp:
    }
}
