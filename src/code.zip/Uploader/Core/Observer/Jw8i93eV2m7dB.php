<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Contracts\QnQF56ZOfQE7U;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\Strategy\Gjc3AfOyac5wl;
use Jfs\Uploader\Core\Strategy\UmX9ZjQg1zzL1;
use Jfs\Uploader\Encoder\GYeGOleAx46En;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Service\HQQLwdzkwB4WZ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Jw8i93eV2m7dB implements QnQF56ZOfQE7U
{
    private $M1RKY;
    private $iN_s5;
    private $iHPgt;
    private $qMX0W;
    public function __construct($bwI0g, $zeM4q, $v5VWU)
    {
        goto hLCf9;
        hLCf9:
        $this->iN_s5 = $bwI0g;
        goto GShFK;
        bhVnU:
        $this->qMX0W = $v5VWU;
        goto kyroJ;
        kyroJ:
        $this->M1RKY = $this->mc18UqN2Mvl();
        goto gsL10;
        GShFK:
        $this->iHPgt = $zeM4q;
        goto bhVnU;
        gsL10:
    }
    public function mdfAwNnkVqr($XbAUN, $ZIUao) : void
    {
        goto guvqo;
        LnY5Q:
        PbwNV:
        goto lNC4E;
        Jr6T5:
        $this->M1RKY->process($ZIUao);
        goto rky5N;
        uSVOt:
        $this->iN_s5->save();
        goto K3wS5;
        RAygM:
        dcvQD:
        goto RZ_Ii;
        guvqo:
        if (!(WSEQ88VDOa3X0::PROCESSING === $ZIUao)) {
            goto dcvQD;
        }
        goto YNxH1;
        apBta:
        FQJOD:
        goto RAygM;
        YNxH1:
        $this->iN_s5->save();
        goto O1Jbf;
        O1Jbf:
        if (!$this->M1RKY) {
            goto FQJOD;
        }
        goto OAi3G;
        OAi3G:
        $this->M1RKY->process($ZIUao);
        goto apBta;
        rky5N:
        N1hIw:
        goto LnY5Q;
        RZ_Ii:
        if (!(WSEQ88VDOa3X0::ENCODING_PROCESSED === $ZIUao)) {
            goto PbwNV;
        }
        goto uSVOt;
        K3wS5:
        if (!$this->M1RKY) {
            goto N1hIw;
        }
        goto Jr6T5;
        lNC4E:
    }
    private function mc18UqN2Mvl()
    {
        goto epzNT;
        Hn9YC:
        A82bj:
        goto ph2u1;
        ph2u1:
        L5w8u:
        goto k63u_;
        epzNT:
        switch ($this->iN_s5->getType()) {
            case 'image':
                return new Gjc3AfOyac5wl($this->iN_s5, $this->qMX0W);
            case 'video':
                return new UmX9ZjQg1zzL1($this->iN_s5, App::make(GYeGOleAx46En::class));
            default:
                return null;
        }
        goto Hn9YC;
        k63u_:
    }
}
