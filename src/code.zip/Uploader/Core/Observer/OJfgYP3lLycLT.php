<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Contracts\Ey23NHBM8rqSI;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class OJfgYP3lLycLT implements Ey23NHBM8rqSI
{
    private $AO_te;
    public function __construct($nKKn0)
    {
        $this->AO_te = $nKKn0;
    }
    public function myNnxL9T85B($TAUXh, $hgqT8)
    {
        goto oIQFX;
        oIQFX:
        if (!(O8RzIjGmSN6fG::UPLOADED === $hgqT8)) {
            goto Ol3pP;
        }
        goto dtThd;
        dpWdo:
        $this->AO_te->delete();
        goto TV1Ve;
        dtThd:
        $this->AO_te->status = O8RzIjGmSN6fG::UPLOADED;
        goto vKXbL;
        BnuDA:
        Ol3pP:
        goto ImK6r;
        ImK6r:
        if (!(O8RzIjGmSN6fG::DELETED === $hgqT8 && $this->AO_te->mNGGz9EZhQY())) {
            goto xIclH;
        }
        goto dpWdo;
        TV1Ve:
        xIclH:
        goto tazLs;
        nTDk0:
        OpnR2:
        goto pS8wG;
        ny2e0:
        $this->AO_te->mSAdKjgXIhj(O8RzIjGmSN6fG::PROCESSING);
        goto nTDk0;
        vKXbL:
        if (!$this->AO_te instanceof McTg5Yp6FKC6z) {
            goto OpnR2;
        }
        goto ny2e0;
        pS8wG:
        $this->AO_te->save();
        goto BnuDA;
        tazLs:
    }
}
