<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Contracts\M7qyTIw376zSo;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\Strategy\Bd9fldU0HH0Br;
use Jfs\Uploader\Core\Strategy\NM3j8RKDr4jhP;
use Jfs\Uploader\Encoder\VSKfJ2MZj0Tjg;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Service\JkVi3Kv2ThmJv;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Rl3CLrtPgaz2O implements M7qyTIw376zSo
{
    private $l1_3Q;
    private $VbAbt;
    private $BfyCm;
    private $RA1U4;
    public function __construct($s2INV, $ejImE, $GNSO9)
    {
        goto LmXal;
        LmXal:
        $this->VbAbt = $s2INV;
        goto pEwsA;
        pEwsA:
        $this->BfyCm = $ejImE;
        goto R9kgo;
        Heq4q:
        $this->l1_3Q = $this->mEdAeMsH1la();
        goto xeDdv;
        R9kgo:
        $this->RA1U4 = $GNSO9;
        goto Heq4q;
        xeDdv:
    }
    public function mCd5SPJOmmA($kLpNi, $x9eDd) : void
    {
        goto rX8rE;
        X_cJs:
        SW1Ht:
        goto DxdVN;
        DxdVN:
        ALPH1:
        goto xmC6k;
        Xsk3D:
        if (!$this->l1_3Q) {
            goto CMUEY;
        }
        goto lS5vl;
        OFImk:
        kY606:
        goto jgHJ9;
        MPcOZ:
        CMUEY:
        goto OFImk;
        TRS9r:
        $this->VbAbt->save();
        goto Xsk3D;
        jgHJ9:
        if (!(IOEDyer18cpSA::ENCODING_PROCESSED === $x9eDd)) {
            goto ALPH1;
        }
        goto fS7__;
        RxM99:
        if (!$this->l1_3Q) {
            goto SW1Ht;
        }
        goto dSdbZ;
        rX8rE:
        if (!(IOEDyer18cpSA::PROCESSING === $x9eDd)) {
            goto kY606;
        }
        goto TRS9r;
        lS5vl:
        $this->l1_3Q->process($x9eDd);
        goto MPcOZ;
        dSdbZ:
        $this->l1_3Q->process($x9eDd);
        goto X_cJs;
        fS7__:
        $this->VbAbt->save();
        goto RxM99;
        xmC6k:
    }
    private function mEdAeMsH1la()
    {
        goto TaDJG;
        jzy4N:
        lAsiY:
        goto tvej0;
        y0yD0:
        N0_Vl:
        goto jzy4N;
        TaDJG:
        switch ($this->VbAbt->getType()) {
            case 'image':
                return new Bd9fldU0HH0Br($this->VbAbt, $this->RA1U4);
            case 'video':
                return new NM3j8RKDr4jhP($this->VbAbt, App::make(VSKfJ2MZj0Tjg::class));
            default:
                return null;
        }
        goto y0yD0;
        tvej0:
    }
}
