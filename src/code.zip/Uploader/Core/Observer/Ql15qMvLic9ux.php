<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Contracts\AbQOw1WF9dU8u;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\Strategy\G1tEiuD0CZvGR;
use Jfs\Uploader\Core\Strategy\FgamWOThJ8fvZ;
use Jfs\Uploader\Encoder\OIG3Aes8wHMT8;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Service\B0o6VsHdCPn65;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Ql15qMvLic9ux implements AbQOw1WF9dU8u
{
    private $UH12E;
    private $Suzy5;
    private $RE_2F;
    private $JCpQ1;
    public function __construct($RCdwx, $WmwnR, $fXXZn)
    {
        goto unomA;
        SzCwj:
        $this->UH12E = $this->mi5IAGotlhQ();
        goto qTyya;
        Y6XqN:
        $this->RE_2F = $WmwnR;
        goto COoNL;
        COoNL:
        $this->JCpQ1 = $fXXZn;
        goto SzCwj;
        unomA:
        $this->Suzy5 = $RCdwx;
        goto Y6XqN;
        qTyya:
    }
    public function mcSizi4ikHF($S1194, $T_gUk) : void
    {
        goto NJbJt;
        JEc2E:
        RVLwT:
        goto zhsTX;
        zhsTX:
        AIgbU:
        goto OlOlj;
        N70te:
        $this->UH12E->process($T_gUk);
        goto JEc2E;
        OlOlj:
        if (!(Tbw0jsMnRbOTP::ENCODING_PROCESSED === $T_gUk)) {
            goto XHAXi;
        }
        goto GE1xn;
        NJbJt:
        if (!(Tbw0jsMnRbOTP::PROCESSING === $T_gUk)) {
            goto AIgbU;
        }
        goto o11BB;
        o11BB:
        $this->Suzy5->save();
        goto Uy3Rr;
        KoPr7:
        XHAXi:
        goto iqKEW;
        GE1xn:
        $this->Suzy5->save();
        goto p6pxm;
        GAugr:
        $this->UH12E->process($T_gUk);
        goto FvYPL;
        p6pxm:
        if (!$this->UH12E) {
            goto JSk3i;
        }
        goto GAugr;
        Uy3Rr:
        if (!$this->UH12E) {
            goto RVLwT;
        }
        goto N70te;
        FvYPL:
        JSk3i:
        goto KoPr7;
        iqKEW:
    }
    private function mi5IAGotlhQ()
    {
        goto OztQJ;
        LgQFc:
        aot1O:
        goto BH6zS;
        OztQJ:
        switch ($this->Suzy5->getType()) {
            case 'image':
                return new G1tEiuD0CZvGR($this->Suzy5, $this->JCpQ1);
            case 'video':
                return new FgamWOThJ8fvZ($this->Suzy5, App::make(OIG3Aes8wHMT8::class));
            default:
                return null;
        }
        goto LgQFc;
        BH6zS:
        gZoUy:
        goto HEitm;
        HEitm:
    }
}
