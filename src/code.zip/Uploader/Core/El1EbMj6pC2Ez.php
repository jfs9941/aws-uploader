<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\Observer\P4MfiQXNPmi6m;
use Jfs\Uploader\Core\YOSIkvkyMSIKR;
use Jfs\Uploader\Core\Traits\R4vSt4d64nOim;
use Jfs\Uploader\Core\Traits\VnPCfppm663dI;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Exception\FQ1SutuqCRD5X;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Exception\NxfDNhkjIm1nw;
use Jfs\Uploader\Service\B1HCEXUDgNNxk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class El1EbMj6pC2Ez implements LKF23eYmlDs0w
{
    use R4vSt4d64nOim;
    use VnPCfppm663dI;
    private $o4adX;
    private function __construct($K9DZL, $z279S)
    {
        $this->wM7km = $K9DZL;
        $this->j618T = $z279S;
    }
    private function mnGJxO7pNoT(string $dxOEL, $z279S, $AA8Bi, bool $YUtDM = false) : void
    {
        $this->m0Xpg1VLHmO(new P4MfiQXNPmi6m($this, $z279S, $AA8Bi, $dxOEL, $YUtDM));
    }
    public function getFile()
    {
        return $this->wM7km;
    }
    public function mSKQ6IJo5al(array $nVijC) : void
    {
        $this->o4adX = $nVijC;
    }
    public function mo3qfcJAbt4() : void
    {
        $this->miF5zZlQWZD(GlPuUJKmzwUJ9::UPLOADING);
    }
    public function mTiwVD0wyAm() : void
    {
        $this->miF5zZlQWZD(GlPuUJKmzwUJ9::UPLOADED);
    }
    public function mNYdU3XLwW7() : void
    {
        $this->miF5zZlQWZD(GlPuUJKmzwUJ9::PROCESSING);
    }
    public function mEYcZubsvcH() : void
    {
        $this->miF5zZlQWZD(GlPuUJKmzwUJ9::FINISHED);
    }
    public function m7wvF9ApT8n() : void
    {
        $this->miF5zZlQWZD(GlPuUJKmzwUJ9::ABORTED);
    }
    public function mTlk22kDycI() : array
    {
        return $this->o4adX;
    }
    public static function mYtsf4mp97v(string $wAkkA, $aXfQX, $J83Op, $dxOEL) : self
    {
        goto I3kZY;
        yp1p9:
        $Y8ByN->mnGJxO7pNoT($dxOEL, $aXfQX, $J83Op);
        goto TMpI0;
        TMpI0:
        $Y8ByN->mXDdmT111J7(GlPuUJKmzwUJ9::UPLOADING);
        goto nbwwE;
        uJ5fl:
        $Y8ByN = new self($K9DZL, $aXfQX);
        goto yp1p9;
        nbwwE:
        return $Y8ByN->macR3kJthJ6();
        goto bhGM5;
        I3kZY:
        $K9DZL = App::make(B1HCEXUDgNNxk::class)->mkPNWfQwT5u(YOSIkvkyMSIKR::mFUIt4zd7G3($wAkkA));
        goto uJ5fl;
        bhGM5:
    }
    public static function mV7s1eh48Zx($K9DZL, $z279S, $AA8Bi, $dxOEL, $YUtDM = false) : self
    {
        goto UqZ25;
        UqZ25:
        $Y8ByN = new self($K9DZL, $z279S);
        goto vrJNC;
        IKnSB:
        return $Y8ByN;
        goto u0OEx;
        kx_Ce:
        $Y8ByN->mXDdmT111J7(GlPuUJKmzwUJ9::UPLOADING);
        goto IKnSB;
        vrJNC:
        $Y8ByN->mnGJxO7pNoT($dxOEL, $z279S, $AA8Bi, $YUtDM);
        goto kx_Ce;
        u0OEx:
    }
}
