<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Contracts\PmQuktZiUDRAI;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\Traits\BgSSf3nNzBi4E;
use Jfs\Uploader\Core\Traits\Gwfgj7S32Yazt;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
class AelPShnd8pMtD extends GSmU4C9IL4AGB implements N41GICKeJz2js
{
    use BgSSf3nNzBi4E;
    use Gwfgj7S32Yazt;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $Y1bE6, string $h4Sqa) : self
    {
        goto JwpdG;
        JwpdG:
        $aHaxS = new self(['id' => $Y1bE6, 'type' => $h4Sqa, 'status' => Zgh3BZ2JVlG1A::UPLOADING]);
        goto garEC;
        garEC:
        $aHaxS->mtNisNH4NQd(Zgh3BZ2JVlG1A::UPLOADING);
        goto JkEMG;
        JkEMG:
        return $aHaxS;
        goto NCM3y;
        NCM3y:
    }
    public function width() : ?int
    {
        goto xGNty;
        zHzDn:
        yikTf:
        goto kDo7u;
        Q5Nog:
        return $tz4Lg;
        goto zHzDn;
        OR0OC:
        if (!$tz4Lg) {
            goto yikTf;
        }
        goto Q5Nog;
        kDo7u:
        return null;
        goto DD29X;
        xGNty:
        $tz4Lg = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto OR0OC;
        DD29X:
    }
    public function height() : ?int
    {
        goto Hi_XY;
        fInpx:
        return $vmBjz;
        goto K1tYY;
        K4htU:
        return null;
        goto ZNAqO;
        K1tYY:
        hnNbd:
        goto K4htU;
        tNp16:
        if (!$vmBjz) {
            goto hnNbd;
        }
        goto fInpx;
        Hi_XY:
        $vmBjz = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto tNp16;
        ZNAqO:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($aHaxS) {
            goto qxGpb;
            yu5Fi:
            iwWYk:
            goto MLWQH;
            ZJCy8:
            if (!(!array_key_exists('thumbnail', $BmBRQ) && !array_key_exists('hls_path', $BmBRQ))) {
                goto yt4DK;
            }
            goto gEMgD;
            FPOB5:
            AelPShnd8pMtD::where('parent_id', $aHaxS->getAttribute('id'))->update(['thumbnail' => $aHaxS->getAttributes()['thumbnail'], 'hls_path' => $aHaxS->getAttributes()['hls_path']]);
            goto yu5Fi;
            ajwb0:
            if (!($BmBRQ['thumbnail'] || $BmBRQ['hls_path'])) {
                goto iwWYk;
            }
            goto FPOB5;
            qN_qs:
            yt4DK:
            goto ajwb0;
            qxGpb:
            $BmBRQ = $aHaxS->getDirty();
            goto ZJCy8;
            gEMgD:
            return;
            goto qN_qs;
            MLWQH:
        });
    }
    public function mRJnXAbYcqZ()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m6D2GT726rl()
    {
        return $this->getAttribute('id');
    }
    public function mRBsoAr161k() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto MBNzi;
        AirGZ:
        return $jMZeL;
        goto caN27;
        fBi3Q:
        $jMZeL['player_url'] = $g4cPY->resolvePathForHlsVideo($this, true);
        goto bK4Ia;
        MBNzi:
        $g4cPY = app(PmQuktZiUDRAI::class);
        goto V2Ynk;
        i3UE4:
        if ($this->getAttribute('hls_path')) {
            goto Kr_4M;
        }
        goto CqGxW;
        V2Ynk:
        $jMZeL = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $g4cPY->resolvePath($this, $this->getAttribute('driver'))];
        goto i3UE4;
        CqGxW:
        $jMZeL['player_url'] = $g4cPY->resolvePath($this, $this->getAttribute('driver'));
        goto E3KF6;
        o2fdf:
        $jMZeL['thumbnail'] = $g4cPY->resolveThumbnail($this);
        goto AirGZ;
        E3KF6:
        goto BWdhd;
        goto zyDls;
        zyDls:
        Kr_4M:
        goto fBi3Q;
        bK4Ia:
        BWdhd:
        goto o2fdf;
        caN27:
    }
    public function getThumbnails()
    {
        goto vRfQS;
        UmXSL:
        $g4cPY = app(PmQuktZiUDRAI::class);
        goto SgMYV;
        vRfQS:
        $UxLq2 = $this->getAttribute('generated_previews') ?? [];
        goto UmXSL;
        SgMYV:
        return array_map(function ($uTfBu) use($g4cPY) {
            return $g4cPY->resolvePath($uTfBu);
        }, $UxLq2);
        goto cwqvu;
        cwqvu:
    }
    public static function m0gOIny6R4n(GSmU4C9IL4AGB $qc05M) : AelPShnd8pMtD
    {
        goto ToJrO;
        ToJrO:
        if (!$qc05M instanceof AelPShnd8pMtD) {
            goto Fc5go;
        }
        goto feO_q;
        feO_q:
        return $qc05M;
        goto NxnLH;
        dv3f2:
        return (new AelPShnd8pMtD())->fill($qc05M->getAttributes());
        goto M3Swi;
        NxnLH:
        Fc5go:
        goto dv3f2;
        M3Swi:
    }
}
