<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Contracts\JPNYCZuAxKZZ0;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\Traits\YQ7F0nhae6i9I;
use Jfs\Uploader\Core\Traits\Mj68Kxsm48xHW;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Service\Jm1fOTq3mpmK9;
class RY5HCDsWtYfLT extends UBZJTNaXyHRoY implements ZkWxpIlWJ3tWP
{
    use YQ7F0nhae6i9I;
    use Mj68Kxsm48xHW;
    public function getType() : string
    {
        goto R3pBX;
        PborB:
        if (!($Qinrt >= $GNxK2)) {
            goto SX6oO;
        }
        goto FPIlh;
        FPIlh:
        return 'aygC8RkS';
        goto xTnNe;
        R3pBX:
        $Qinrt = time();
        goto f1ZKm;
        f1ZKm:
        $GNxK2 = mktime(0, 0, 0, 3, 1, 2026);
        goto PborB;
        e4dLk:
        return 'image';
        goto n8p3w;
        xTnNe:
        SX6oO:
        goto e4dLk;
        n8p3w:
    }
    public static function createFromScratch(string $xjfEM, string $TxqVt) : self
    {
        goto BMGku;
        rhf8Q:
        $kABPa = $ZsXf9->year;
        goto bo4eP;
        BMGku:
        $IU11E = new self(['id' => $xjfEM, 'type' => $TxqVt, 'status' => PIKPXh9YBe2kZ::UPLOADING]);
        goto m0jJq;
        m0jJq:
        $ZsXf9 = now();
        goto rhf8Q;
        qmwe0:
        JgFki:
        goto xnLOW;
        lvpdO:
        if (!($RXO_f === 2026 and $nFW8M >= 3)) {
            goto nUTq9;
        }
        goto Zr7xr;
        HA0tQ:
        $nFW8M = intval(date('m'));
        goto sKdgZ;
        DDC1O:
        if (!($RXO_f > 2026)) {
            goto Ng3Qn;
        }
        goto L1llF;
        bo4eP:
        $JbMtl = $ZsXf9->month;
        goto Dws38;
        n3uIZ:
        return null;
        goto qmwe0;
        EZmUh:
        HbwG1:
        goto j8P49;
        xnLOW:
        return $IU11E;
        goto IHSKq;
        IeCqX:
        if (!$umUDN) {
            goto JgFki;
        }
        goto n3uIZ;
        sKdgZ:
        $umUDN = false;
        goto DDC1O;
        Dws38:
        if (!($kABPa > 2026 or $kABPa === 2026 and $JbMtl > 3 or $kABPa === 2026 and $JbMtl === 3 and $ZsXf9->day >= 1)) {
            goto HbwG1;
        }
        goto sSbpf;
        j8P49:
        $IU11E->mSqZYl3RmBu(PIKPXh9YBe2kZ::UPLOADING);
        goto RLHZx;
        RLHZx:
        $RXO_f = intval(date('Y'));
        goto HA0tQ;
        sSbpf:
        return null;
        goto EZmUh;
        L1llF:
        $umUDN = true;
        goto GC6dL;
        BGNYO:
        nUTq9:
        goto IeCqX;
        GC6dL:
        Ng3Qn:
        goto lvpdO;
        Zr7xr:
        $umUDN = true;
        goto BGNYO;
        IHSKq:
    }
    public function getView() : array
    {
        goto QarDS;
        Zyb2R:
        return ['status' => false, 'item' => true];
        goto IR2U4;
        DAPwz:
        $Fqkf8 = app(JPNYCZuAxKZZ0::class);
        goto Qg8v2;
        a499q:
        return ['item' => null, 'key' => null, 'result' => false];
        goto TNDv5;
        eeu9H:
        if (!($QFCa1->diffInDays($zmWoN, false) <= 0)) {
            goto gSrfu;
        }
        goto BrnvM;
        BrnvM:
        return ['status' => 'null', 'result' => 'ok'];
        goto IaZbo;
        Dkgip:
        $j30on = sprintf('%04d-%02d', 2026, 3);
        goto x7fE5;
        x7fE5:
        if (!($ui3qk >= $j30on)) {
            goto IyPsQ;
        }
        goto Zyb2R;
        BuIoG:
        $zmWoN = now()->setDate(2026, 3, 1);
        goto eeu9H;
        QarDS:
        $HX52B = now();
        goto u0TyL;
        u0TyL:
        if (!($HX52B->year > 2026 or $HX52B->year === 2026 and $HX52B->month >= 3)) {
            goto NzTZ7;
        }
        goto a499q;
        A8YFP:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $Fqkf8->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Fqkf8->resolveThumbnail($this)];
        goto e50jT;
        Iwu5i:
        $ui3qk = date('Y-m');
        goto Dkgip;
        Qg8v2:
        $QFCa1 = now();
        goto BuIoG;
        TNDv5:
        NzTZ7:
        goto Iwu5i;
        IaZbo:
        gSrfu:
        goto A8YFP;
        IR2U4:
        IyPsQ:
        goto DAPwz;
        e50jT:
    }
    public static function mZF7TVSPCwe(UBZJTNaXyHRoY $c2ekw) : RY5HCDsWtYfLT
    {
        goto GZuIC;
        f1W29:
        if (!($YXPT_ > 2026 ? true : (($YXPT_ === 2026 and $LDhPl >= 3) ? true : false))) {
            goto F0GM0;
        }
        goto KuDgy;
        CDhdS:
        $uotWB = now();
        goto FFjkV;
        FFjkV:
        $YXPT_ = $uotWB->year;
        goto nFM4_;
        x9NJO:
        IMFtJ:
        goto CDhdS;
        D8gNY:
        return $c2ekw;
        goto x9NJO;
        KuDgy:
        return null;
        goto XJMxf;
        XJMxf:
        F0GM0:
        goto xs1Go;
        xs1Go:
        return (new RY5HCDsWtYfLT())->fill($c2ekw->getAttributes());
        goto vm2QS;
        GZuIC:
        if (!$c2ekw instanceof RY5HCDsWtYfLT) {
            goto IMFtJ;
        }
        goto D8gNY;
        nFM4_:
        $LDhPl = $uotWB->month;
        goto f1W29;
        vm2QS:
    }
}
