<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Core\Traits\DE88el5C1yZlG;
use Jfs\Uploader\Core\Traits\J0nlGVgP1R1Ai;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Service\KWcrk2FVuq9pZ;
class JyZaxpharsbun extends DMUaxGX7XHAI0 implements BCa3K9pPFzXM0
{
    use DE88el5C1yZlG;
    use J0nlGVgP1R1Ai;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $XKudI, string $KvyPo) : self
    {
        goto L49J7;
        iCRo0:
        $iy9bs->m3B430t4QRf(EUkqoDwU9Zcvh::UPLOADING);
        goto tQhxH;
        L49J7:
        $iy9bs = new self(['id' => $XKudI, 'type' => $KvyPo, 'status' => EUkqoDwU9Zcvh::UPLOADING]);
        goto iCRo0;
        tQhxH:
        return $iy9bs;
        goto iFHQm;
        iFHQm:
    }
    public function getView() : array
    {
        $d1dPQ = app(Yuf8dMzRcjZ21::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $d1dPQ->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $d1dPQ->resolveThumbnail($this)];
    }
    public static function mCzpCom7Ehj(DMUaxGX7XHAI0 $hEivM) : JyZaxpharsbun
    {
        goto b8zd6;
        OfRtz:
        return (new JyZaxpharsbun())->fill($hEivM->getAttributes());
        goto ocrIs;
        b8zd6:
        if (!$hEivM instanceof JyZaxpharsbun) {
            goto K70bK;
        }
        goto Nxnd7;
        Eonzm:
        K70bK:
        goto OfRtz;
        Nxnd7:
        return $hEivM;
        goto Eonzm;
        ocrIs:
    }
}
