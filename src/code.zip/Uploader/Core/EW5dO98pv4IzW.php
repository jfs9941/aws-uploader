<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Contracts\Hj0NrxjG6qaVy;
use Jfs\Uploader\Core\Traits\VxlX0xA9Oyzyn;
use Jfs\Uploader\Core\Traits\GnXq4OXXJLYXp;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Service\RkcpO1qn0gOFt;
class EW5dO98pv4IzW extends O4HsadxAyKjYq implements XZsrc8KnXftCK
{
    use VxlX0xA9Oyzyn;
    use GnXq4OXXJLYXp;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $KKu2U, string $FonuJ) : self
    {
        goto SBErd;
        e6Jnh:
        return $QT2c8;
        goto E1gBa;
        SBErd:
        $QT2c8 = new self(['id' => $KKu2U, 'type' => $FonuJ, 'status' => UimQKBIuLCEAO::UPLOADING]);
        goto LTGK3;
        LTGK3:
        $QT2c8->mnZV8lryeWr(UimQKBIuLCEAO::UPLOADING);
        goto e6Jnh;
        E1gBa:
    }
    public function getView() : array
    {
        $z_puv = app(Hj0NrxjG6qaVy::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $z_puv->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $z_puv->resolveThumbnail($this)];
    }
    public static function mmCgbYaS4M0(O4HsadxAyKjYq $NyN9S) : EW5dO98pv4IzW
    {
        goto Si8nj;
        uxFeY:
        return (new EW5dO98pv4IzW())->fill($NyN9S->getAttributes());
        goto XMhpL;
        P11rJ:
        return $NyN9S;
        goto sjsuD;
        sjsuD:
        u40E0:
        goto uxFeY;
        Si8nj:
        if (!$NyN9S instanceof EW5dO98pv4IzW) {
            goto u40E0;
        }
        goto P11rJ;
        XMhpL:
    }
}
