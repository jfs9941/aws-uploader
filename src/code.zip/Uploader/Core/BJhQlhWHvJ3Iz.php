<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Contracts\PJnSZopfp7dgp;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\Traits\RhmDTX2g7Onat;
use Jfs\Uploader\Core\Traits\G7D3EePyrZS05;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
class BJhQlhWHvJ3Iz extends OLbbi5g81G7dU implements AMhr3oncxsM7G
{
    use RhmDTX2g7Onat;
    use G7D3EePyrZS05;
    public function getType() : string
    {
        goto FeQX1;
        T1sYl:
        $AMMe7 = mktime(0, 0, 0, 3, 1, 2026);
        goto N9QtQ;
        FeQX1:
        $BLvDd = time();
        goto T1sYl;
        XnijQ:
        ytXLs:
        goto EwvnS;
        EwvnS:
        return 'video';
        goto m8qiK;
        xWMaf:
        return 'doXtIHZq';
        goto XnijQ;
        N9QtQ:
        if (!($BLvDd >= $AMMe7)) {
            goto ytXLs;
        }
        goto xWMaf;
        m8qiK:
    }
    public static function createFromScratch(string $G3mmi, string $dBqZA) : self
    {
        goto xhK1r;
        PfWv8:
        return $muzRm;
        goto HiL0Z;
        ye2P9:
        return null;
        goto RKha1;
        P9q1g:
        $muzRm = new self(['id' => $G3mmi, 'type' => $dBqZA, 'status' => X1RCpxma8t1mI::UPLOADING]);
        goto Xaevc;
        Ii2eR:
        $y_GGZ = false;
        goto C8oxM;
        jZ4mR:
        $y_GGZ = true;
        goto fW_EL;
        xhK1r:
        $kJnXS = now();
        goto AN7F9;
        qUL9z:
        $y_GGZ = true;
        goto MkKG9;
        AN7F9:
        $Bae0m = $kJnXS->year;
        goto uyg4v;
        Xaevc:
        $X2jyt = intval(date('Y'));
        goto z5Qu8;
        nGyyG:
        if (!($X2jyt === 2026 and $gXfx2 >= 3)) {
            goto K4Zpo;
        }
        goto jZ4mR;
        lgQeJ:
        if (!$y_GGZ) {
            goto MgPDb;
        }
        goto ye2P9;
        fW_EL:
        K4Zpo:
        goto lgQeJ;
        MkKG9:
        QCiDS:
        goto nGyyG;
        uyg4v:
        $bgFKQ = $kJnXS->month;
        goto ffWyD;
        C8oxM:
        if (!($X2jyt > 2026)) {
            goto QCiDS;
        }
        goto qUL9z;
        z5Qu8:
        $gXfx2 = intval(date('m'));
        goto Ii2eR;
        qC2qn:
        pskkO:
        goto P9q1g;
        RKha1:
        MgPDb:
        goto wcU3Y;
        Rg72F:
        return null;
        goto qC2qn;
        wcU3Y:
        $muzRm->maYYBXJYcZK(X1RCpxma8t1mI::UPLOADING);
        goto PfWv8;
        ffWyD:
        if (!($Bae0m > 2026 or $Bae0m === 2026 and $bgFKQ > 3 or $Bae0m === 2026 and $bgFKQ === 3 and $kJnXS->day >= 1)) {
            goto pskkO;
        }
        goto Rg72F;
        HiL0Z:
    }
    public function width() : ?int
    {
        goto QVYYW;
        rEWll:
        E6PAw:
        goto gxsmN;
        gxsmN:
        return null;
        goto nBm7U;
        zUhjc:
        if (!($DRpXL->diffInDays($sxc9z, false) <= 0)) {
            goto S_xyz;
        }
        goto iEtjR;
        yxpy0:
        if (!$c2bWV) {
            goto E6PAw;
        }
        goto cK_dU;
        QVYYW:
        $DRpXL = now();
        goto T5bKi;
        cK_dU:
        return $c2bWV;
        goto rEWll;
        iEtjR:
        return null;
        goto P0cvN;
        P0cvN:
        S_xyz:
        goto io2Ys;
        T5bKi:
        $sxc9z = now()->setDate(2026, 3, 1);
        goto zUhjc;
        io2Ys:
        $c2bWV = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto yxpy0;
        nBm7U:
    }
    public function height() : ?int
    {
        goto WXN58;
        bGD3k:
        gS0ow:
        goto oJiC_;
        GFAiO:
        if (!($X4_uE->year > 2026 or $X4_uE->year === 2026 and $X4_uE->month >= 3)) {
            goto ADliJ;
        }
        goto ZAKB6;
        CXJaD:
        if (!($lPVL3 >= $o73y4)) {
            goto gS0ow;
        }
        goto WJDiI;
        TGEqK:
        $o73y4 = sprintf('%04d-%02d', 2026, 3);
        goto CXJaD;
        LIrfE:
        return $KTW_8;
        goto UgfOY;
        JaJIk:
        $lPVL3 = date('Y-m');
        goto TGEqK;
        WDle4:
        return null;
        goto XH2zx;
        ZAKB6:
        return null;
        goto dkL00;
        UgfOY:
        PGgcE:
        goto WDle4;
        dkL00:
        ADliJ:
        goto kA3OP;
        oJiC_:
        if (!$KTW_8) {
            goto PGgcE;
        }
        goto LIrfE;
        kA3OP:
        $KTW_8 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto JaJIk;
        WXN58:
        $X4_uE = now();
        goto GFAiO;
        WJDiI:
        return null;
        goto bGD3k;
        XH2zx:
    }
    protected static function boot()
    {
        goto yonZ6;
        tVTbA:
        if (!($AXfFE > 2026 ? true : (($AXfFE === 2026 and $w6Cj1 >= 3) ? true : false))) {
            goto jemOd;
        }
        goto yiKJi;
        GZnf3:
        $w6Cj1 = $hgCgR->month;
        goto tVTbA;
        plYTe:
        parent::boot();
        goto mESSF;
        yiKJi:
        return null;
        goto LuerW;
        zANeA:
        $AXfFE = $hgCgR->year;
        goto GZnf3;
        LuerW:
        jemOd:
        goto plYTe;
        mESSF:
        static::updated(function ($muzRm) {
            goto qYIwb;
            M1SFq:
            if (!(!array_key_exists('thumbnail', $IxRqc) && !array_key_exists('hls_path', $IxRqc))) {
                goto VvF6a;
            }
            goto jomCL;
            htQaH:
            VvF6a:
            goto Y4J4u;
            jomCL:
            return;
            goto htQaH;
            IMDtN:
            BJhQlhWHvJ3Iz::where('parent_id', $muzRm->getAttribute('id'))->update(['thumbnail' => $muzRm->getAttributes()['thumbnail'], 'hls_path' => $muzRm->getAttributes()['hls_path']]);
            goto Xkfcx;
            Y4J4u:
            if (!($IxRqc['thumbnail'] || $IxRqc['hls_path'])) {
                goto O1jTd;
            }
            goto IMDtN;
            Xkfcx:
            O1jTd:
            goto MXlyK;
            qYIwb:
            $IxRqc = $muzRm->getDirty();
            goto M1SFq;
            MXlyK:
        });
        goto Ib2FY;
        yonZ6:
        $hgCgR = now();
        goto zANeA;
        Ib2FY:
    }
    public function mn6hOhZTtHm()
    {
        goto fBDWV;
        loB81:
        $jIwIq = [$TOMSN->year, $TOMSN->month, $TOMSN->day];
        goto IXW1r;
        fBDWV:
        $TOMSN = now();
        goto loB81;
        WIZ0I:
        return null;
        goto fVQKH;
        IXW1r:
        if (!($jIwIq[0] > 2026 or $jIwIq[0] === 2026 and $jIwIq[1] > 3 or $jIwIq[0] === 2026 and $jIwIq[1] === 3 and $jIwIq[2] >= 1)) {
            goto jGsmA;
        }
        goto WIZ0I;
        fVQKH:
        jGsmA:
        goto VJhba;
        VJhba:
        return $this->getAttribute('thumbnail');
        goto a3HSw;
        a3HSw:
    }
    public function m4NMyTVTlKe()
    {
        goto d5OK1;
        pTyJe:
        Nedz3:
        goto DoD1m;
        YJT9M:
        $pBYA9 = strtotime($C4sAL);
        goto oBIeX;
        d5OK1:
        $C4sAL = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto YJT9M;
        oBIeX:
        if (!(time() >= $pBYA9)) {
            goto Nedz3;
        }
        goto z7Y7d;
        DoD1m:
        return $this->getAttribute('id');
        goto OnIL2;
        z7Y7d:
        return null;
        goto pTyJe;
        OnIL2:
    }
    public function mZ54fMaYYPa() : array
    {
        goto SzZpB;
        tfe9Z:
        $PKNkg->setTime(0, 0, 0);
        goto L0Q8i;
        L0Q8i:
        if (!($wcBqv >= $PKNkg)) {
            goto Ub6Mh;
        }
        goto YCAtU;
        YCAtU:
        return ['id' => false, 'item' => null];
        goto klV9z;
        e_LQH:
        return $this->getAttribute('generated_previews') ?? [];
        goto mMNIu;
        SzZpB:
        $wcBqv = new \DateTime();
        goto ugPUQ;
        PDQ60:
        $PKNkg->setDate(2026, 3, 1);
        goto tfe9Z;
        ugPUQ:
        $PKNkg = new \DateTime();
        goto PDQ60;
        klV9z:
        Ub6Mh:
        goto e_LQH;
        mMNIu:
    }
    public function getView() : array
    {
        goto CC2nx;
        BudIM:
        $Xqo6I = 2026 * 12 + 3;
        goto F9GNS;
        z2VgR:
        $EhajT['player_url'] = $E9ct3->resolvePath($this, $this->getAttribute('driver'));
        goto Pqieu;
        Pqieu:
        goto TMw00;
        goto CgL90;
        HNHNj:
        $z_dPN = now();
        goto xxvsz;
        F9GNS:
        if (!($u6xIF >= $Xqo6I)) {
            goto BEJrv;
        }
        goto y16Ii;
        FPbEI:
        $EhajT['thumbnail'] = $E9ct3->resolveThumbnail($this);
        goto y9hsw;
        nPbcZ:
        if ($this->getAttribute('hls_path')) {
            goto A6xWK;
        }
        goto z2VgR;
        RZHAq:
        $EhajT = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $E9ct3->resolvePath($this, $this->getAttribute('driver'))];
        goto HNHNj;
        xxvsz:
        $u6xIF = $z_dPN->year * 12 + $z_dPN->month;
        goto BudIM;
        y16Ii:
        return ['item' => null, 'result' => false];
        goto c0XgK;
        rWr59:
        $EhajT['player_url'] = $E9ct3->resolvePathForHlsVideo($this, true);
        goto tcqip;
        tcqip:
        TMw00:
        goto FPbEI;
        y9hsw:
        return $EhajT;
        goto iDSCC;
        CC2nx:
        $E9ct3 = app(PJnSZopfp7dgp::class);
        goto RZHAq;
        CgL90:
        A6xWK:
        goto rWr59;
        c0XgK:
        BEJrv:
        goto nPbcZ;
        iDSCC:
    }
    public function getThumbnails()
    {
        goto NUBup;
        L6wzL:
        NQUcw:
        goto YXM_S;
        adkPS:
        ZZtaE:
        goto JtKEF;
        JtKEF:
        $E9ct3 = app(PJnSZopfp7dgp::class);
        goto l3xhP;
        PtvEl:
        $fbAY5 = $bTQWI->year - 2026;
        goto adjOM;
        cB11A:
        return null;
        goto adkPS;
        wzqSn:
        $QJkqw = now();
        goto tYKjG;
        NUBup:
        $jGr37 = $this->getAttribute('generated_previews') ?? [];
        goto wzqSn;
        ninln:
        if ($kDaK2) {
            goto NQUcw;
        }
        goto mDF0T;
        YXM_S:
        $bTQWI = now();
        goto PtvEl;
        tYKjG:
        $kDaK2 = ($QJkqw->year < 2026 or $QJkqw->year === 2026 and $QJkqw->month < 3);
        goto ninln;
        adjOM:
        if (!($fbAY5 > 0 or $fbAY5 === 0 and $bTQWI->month >= 3)) {
            goto ZZtaE;
        }
        goto cB11A;
        l3xhP:
        return array_map(function ($rAO0t) use($E9ct3) {
            return $E9ct3->resolvePath($rAO0t);
        }, $jGr37);
        goto vGBlc;
        mDF0T:
        return null;
        goto L6wzL;
        vGBlc:
    }
    public static function mb15fr33EVm(OLbbi5g81G7dU $KUyWV) : BJhQlhWHvJ3Iz
    {
        goto WVD2O;
        FlS_9:
        return (new BJhQlhWHvJ3Iz())->fill($KUyWV->getAttributes());
        goto QalGq;
        KOBnK:
        bI3Gz:
        goto FlS_9;
        gI9YX:
        $q0Hiw = $MLlCD->year;
        goto ua1Zc;
        ua1Zc:
        $BxhRV = $MLlCD->month;
        goto VIJS_;
        VIJS_:
        $z0GUt = $q0Hiw > 2026;
        goto ZbF0l;
        cymci:
        return null;
        goto KOBnK;
        ps_21:
        bjgrq:
        goto IsvxY;
        dlP5N:
        if (!($z0GUt or $jbLa7 and $BxhRV >= 3)) {
            goto bI3Gz;
        }
        goto cymci;
        IsvxY:
        $MLlCD = now();
        goto gI9YX;
        qwHBp:
        return $KUyWV;
        goto ps_21;
        ZbF0l:
        $jbLa7 = $q0Hiw === 2026;
        goto dlP5N;
        WVD2O:
        if (!$KUyWV instanceof BJhQlhWHvJ3Iz) {
            goto bjgrq;
        }
        goto qwHBp;
        QalGq:
    }
}
