<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\Observer\U3kjpY8VjSmvL;
use Jfs\Uploader\Core\VxPWGO5HkTQsP;
use Jfs\Uploader\Core\Traits\MvNzFOOLsDrZI;
use Jfs\Uploader\Core\Traits\NnqCGr9M8kJNm;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Exception\D2GpNcz5KiI9K;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Exception\C4FBIUHwDz2gM;
use Jfs\Uploader\Service\M5DWm1ijeK6rr;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class RQ9bDEqcUZdSJ implements H1Ax5lj0mb7kw
{
    use MvNzFOOLsDrZI;
    use NnqCGr9M8kJNm;
    private $Pzlba;
    private function __construct($pemjO, $qxxOf)
    {
        $this->XHy23 = $pemjO;
        $this->C4IE4 = $qxxOf;
    }
    private function mFXi2DJwso1(string $EwO1g, $qxxOf, $P4KJD, bool $aXeSG = false) : void
    {
        $this->mj3Wprz3dA2(new U3kjpY8VjSmvL($this, $qxxOf, $P4KJD, $EwO1g, $aXeSG));
    }
    public function getFile()
    {
        return $this->XHy23;
    }
    public function mLUJMMpbAb4(array $UeJge) : void
    {
        $this->Pzlba = $UeJge;
    }
    public function mQohhvSlrsq() : void
    {
        $this->mVhOJ1PgG8J(IOOvAXAyKHLW2::UPLOADING);
    }
    public function mHRc1ZRuqIi() : void
    {
        $this->mVhOJ1PgG8J(IOOvAXAyKHLW2::UPLOADED);
    }
    public function mswQ3I4yjQj() : void
    {
        $this->mVhOJ1PgG8J(IOOvAXAyKHLW2::PROCESSING);
    }
    public function mL49nMTa7sX() : void
    {
        $this->mVhOJ1PgG8J(IOOvAXAyKHLW2::FINISHED);
    }
    public function mG6Vb9gFdPg() : void
    {
        $this->mVhOJ1PgG8J(IOOvAXAyKHLW2::ABORTED);
    }
    public function mvk1TQJ0UZn() : array
    {
        return $this->Pzlba;
    }
    public static function mTOMSSad6UN(string $poSkG, $vQt8p, $v1Edp, $EwO1g) : self
    {
        goto LcNtD;
        PoR36:
        $zTSUl = new self($pemjO, $vQt8p);
        goto D3jrE;
        j90nV:
        $zTSUl->mMTZSzpDsC7(IOOvAXAyKHLW2::UPLOADING);
        goto x37hj;
        D3jrE:
        $zTSUl->mFXi2DJwso1($EwO1g, $vQt8p, $v1Edp);
        goto j90nV;
        x37hj:
        return $zTSUl->m6DsdjQRnTW();
        goto KgEaf;
        LcNtD:
        $pemjO = App::make(M5DWm1ijeK6rr::class)->mMpOj656eUB(VxPWGO5HkTQsP::mcVXYpnXj59($poSkG));
        goto PoR36;
        KgEaf:
    }
    public static function mFnXGqx5dSJ($pemjO, $qxxOf, $P4KJD, $EwO1g, $aXeSG = false) : self
    {
        goto YWMPj;
        kW4Bk:
        $zTSUl->mMTZSzpDsC7(IOOvAXAyKHLW2::UPLOADING);
        goto YA98F;
        YWMPj:
        $zTSUl = new self($pemjO, $qxxOf);
        goto rbSfc;
        rbSfc:
        $zTSUl->mFXi2DJwso1($EwO1g, $qxxOf, $P4KJD, $aXeSG);
        goto kW4Bk;
        YA98F:
        return $zTSUl;
        goto Y1l9Y;
        Y1l9Y:
    }
}
