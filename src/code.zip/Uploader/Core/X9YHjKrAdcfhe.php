<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Contracts\IKjdKLYqqHsDJ;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Traits\LoACaEWnJQjFu;
use Jfs\Uploader\Core\Traits\SphMX2uWp2oS1;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Service\H38a3dsu2FMgf;
class X9YHjKrAdcfhe extends ALaATNTmuoFHt implements MB8DYpNdVV1bz
{
    use LoACaEWnJQjFu;
    use SphMX2uWp2oS1;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $kftn8, string $ln7Ij) : self
    {
        goto IR0TQ;
        clfrF:
        $ZQQzW->mWRFuBOBU6q(Tbw0jsMnRbOTP::UPLOADING);
        goto BMSPJ;
        BMSPJ:
        return $ZQQzW;
        goto lnw0t;
        IR0TQ:
        $ZQQzW = new self(['id' => $kftn8, 'type' => $ln7Ij, 'status' => Tbw0jsMnRbOTP::UPLOADING]);
        goto clfrF;
        lnw0t:
    }
    public function getView() : array
    {
        $o4fuz = app(IKjdKLYqqHsDJ::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $o4fuz->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $o4fuz->resolveThumbnail($this)];
    }
    public static function mD9rfz3vdzZ(ALaATNTmuoFHt $nu6qO) : X9YHjKrAdcfhe
    {
        goto pntyU;
        NzsdE:
        return (new X9YHjKrAdcfhe())->fill($nu6qO->getAttributes());
        goto KU2SG;
        pntyU:
        if (!$nu6qO instanceof X9YHjKrAdcfhe) {
            goto jFF4V;
        }
        goto rBaA0;
        rBaA0:
        return $nu6qO;
        goto iTUt0;
        iTUt0:
        jFF4V:
        goto NzsdE;
        KU2SG:
    }
}
