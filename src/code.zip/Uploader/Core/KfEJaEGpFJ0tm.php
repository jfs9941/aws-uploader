<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Contracts\IqdLBxImTkuBV;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\Traits\WajBwoXLSKmXZ;
use Jfs\Uploader\Core\Traits\REDykmcLTsPcw;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Service\KS7YippgDSDNy;
class KfEJaEGpFJ0tm extends GpdHFYchpZHPa implements OFkaCU82i4KNX
{
    use WajBwoXLSKmXZ;
    use REDykmcLTsPcw;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $F4nAe, string $WawPM) : self
    {
        goto OPiwQ;
        L_OUz:
        $gNhb4->mJpZf64FjYj(EHhCBxlsVyz9C::UPLOADING);
        goto c7KFO;
        OPiwQ:
        $gNhb4 = new self(['id' => $F4nAe, 'type' => $WawPM, 'status' => EHhCBxlsVyz9C::UPLOADING]);
        goto L_OUz;
        c7KFO:
        return $gNhb4;
        goto P2tRC;
        P2tRC:
    }
    public function getView() : array
    {
        $BMXe2 = app(IqdLBxImTkuBV::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $BMXe2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $BMXe2->resolveThumbnail($this)];
    }
    public static function m5QQLRAV8sj(GpdHFYchpZHPa $gR4Y3) : KfEJaEGpFJ0tm
    {
        goto y2k6A;
        DKrtn:
        return (new KfEJaEGpFJ0tm())->fill($gR4Y3->getAttributes());
        goto M6K0z;
        u0sZt:
        XfNV_:
        goto DKrtn;
        S6D4s:
        return $gR4Y3;
        goto u0sZt;
        y2k6A:
        if (!$gR4Y3 instanceof KfEJaEGpFJ0tm) {
            goto XfNV_;
        }
        goto S6D4s;
        M6K0z:
    }
}
