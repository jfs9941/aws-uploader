<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Contracts\K0dipGcxtVboz;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\Traits\QuukgXnznCEU4;
use Jfs\Uploader\Core\Traits\Iny7AwCou1ddb;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Service\FiQYSbwR1Ly8I;
class QJ9aA37t27inE extends NRDoWGrbd9WhU implements IzCykbeCOYPNB
{
    use QuukgXnznCEU4;
    use Iny7AwCou1ddb;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $ExhEa, string $zuSYz) : self
    {
        goto qqcl4;
        nYzHY:
        $CgJZ5->mQ7dAxBkFij(EXecNg2hg7kwl::UPLOADING);
        goto grovl;
        grovl:
        return $CgJZ5;
        goto ILeIs;
        qqcl4:
        $CgJZ5 = new self(['id' => $ExhEa, 'type' => $zuSYz, 'status' => EXecNg2hg7kwl::UPLOADING]);
        goto nYzHY;
        ILeIs:
    }
    public function getView() : array
    {
        $tKXn_ = app(K0dipGcxtVboz::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $tKXn_->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $tKXn_->resolveThumbnail($this)];
    }
    public static function mnch22Y6EjB(NRDoWGrbd9WhU $S8CpP) : QJ9aA37t27inE
    {
        goto hMHw6;
        hMHw6:
        if (!$S8CpP instanceof QJ9aA37t27inE) {
            goto cJ34a;
        }
        goto bf1to;
        oMIHa:
        return (new QJ9aA37t27inE())->fill($S8CpP->getAttributes());
        goto Ts1UG;
        EF_Jl:
        cJ34a:
        goto oMIHa;
        bf1to:
        return $S8CpP;
        goto EF_Jl;
        Ts1UG:
    }
}
