<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Contracts\PZ7iLyA8MUs3A;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\Traits\K8rP6m5O2PpBO;
use Jfs\Uploader\Core\Traits\TjGyNEupzj5XK;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
class J7sRaWo8um3yO extends F43pNWIrUhz3z implements F9PXWR72LBMoZ
{
    use K8rP6m5O2PpBO;
    use TjGyNEupzj5XK;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $lrkH0, string $aCi5W) : self
    {
        goto h0oij;
        h0oij:
        $lamFK = new self(['id' => $lrkH0, 'type' => $aCi5W, 'status' => H7dtWZ2h5WAty::UPLOADING]);
        goto xstXl;
        xstXl:
        $lamFK->muKqrdnPhRb(H7dtWZ2h5WAty::UPLOADING);
        goto Xagyg;
        Xagyg:
        return $lamFK;
        goto I877g;
        I877g:
    }
    public function width() : ?int
    {
        goto BXLAY;
        TA6xj:
        return $ASgWt;
        goto Dog7C;
        Dog7C:
        I58F6:
        goto xCYB6;
        xCYB6:
        return null;
        goto LHA4w;
        hxJe3:
        if (!$ASgWt) {
            goto I58F6;
        }
        goto TA6xj;
        BXLAY:
        $ASgWt = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto hxJe3;
        LHA4w:
    }
    public function height() : ?int
    {
        goto v6RQ1;
        zv6Xa:
        if (!$ybj1g) {
            goto HAc7n;
        }
        goto HwIPz;
        v6RQ1:
        $ybj1g = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto zv6Xa;
        HwIPz:
        return $ybj1g;
        goto lDYUx;
        lDYUx:
        HAc7n:
        goto bHej3;
        bHej3:
        return null;
        goto OvXfy;
        OvXfy:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($lamFK) {
            goto PcLke;
            VJqNJ:
            Rg8rE:
            goto a9VvT;
            a9VvT:
            if (!($v0qAs['thumbnail'] || $v0qAs['hls_path'])) {
                goto u2wd2;
            }
            goto Fx3fs;
            sLqu5:
            if (!(!array_key_exists('thumbnail', $v0qAs) && !array_key_exists('hls_path', $v0qAs))) {
                goto Rg8rE;
            }
            goto zCwjQ;
            PcLke:
            $v0qAs = $lamFK->getDirty();
            goto sLqu5;
            zCwjQ:
            return;
            goto VJqNJ;
            Fx3fs:
            J7sRaWo8um3yO::where('parent_id', $lamFK->getAttribute('id'))->update(['thumbnail' => $lamFK->getAttributes()['thumbnail'], 'hls_path' => $lamFK->getAttributes()['hls_path']]);
            goto oYN5y;
            oYN5y:
            u2wd2:
            goto Gjbze;
            Gjbze:
        });
    }
    public function moHpVsEqZyT()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mvjKCI8kvFs()
    {
        return $this->getAttribute('id');
    }
    public function m6jJ8zpiUpK() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Xpixr;
        Xpixr:
        $i7mq9 = app(PZ7iLyA8MUs3A::class);
        goto M0S62;
        SArfO:
        goto ChcCi;
        goto Xwd9d;
        DnGN_:
        if ($this->getAttribute('hls_path')) {
            goto Exaqy;
        }
        goto HOofZ;
        HOofZ:
        $uApFn['player_url'] = $i7mq9->resolvePath($this, $this->getAttribute('driver'));
        goto SArfO;
        M0S62:
        $uApFn = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $i7mq9->resolvePath($this, $this->getAttribute('driver'))];
        goto DnGN_;
        NGBmH:
        return $uApFn;
        goto U5Jd9;
        RNo74:
        $uApFn['player_url'] = $i7mq9->resolvePathForHlsVideo($this, true);
        goto GMXGl;
        Xwd9d:
        Exaqy:
        goto RNo74;
        GMXGl:
        ChcCi:
        goto zTYIZ;
        zTYIZ:
        $uApFn['thumbnail'] = $i7mq9->resolveThumbnail($this);
        goto NGBmH;
        U5Jd9:
    }
    public function getThumbnails()
    {
        goto uKHMY;
        MpAhh:
        return array_map(function ($UT4QS) use($i7mq9) {
            return $i7mq9->resolvePath($UT4QS);
        }, $X_zxk);
        goto eY8XG;
        uKHMY:
        $X_zxk = $this->getAttribute('generated_previews') ?? [];
        goto FVMvg;
        FVMvg:
        $i7mq9 = app(PZ7iLyA8MUs3A::class);
        goto MpAhh;
        eY8XG:
    }
    public static function mVtkoYTT0QM(F43pNWIrUhz3z $bPdTZ) : J7sRaWo8um3yO
    {
        goto U9w_t;
        x2Ym1:
        return $bPdTZ;
        goto VYWiY;
        aUm71:
        return (new J7sRaWo8um3yO())->fill($bPdTZ->getAttributes());
        goto zzEbz;
        VYWiY:
        UlUbt:
        goto aUm71;
        U9w_t:
        if (!$bPdTZ instanceof J7sRaWo8um3yO) {
            goto UlUbt;
        }
        goto x2Ym1;
        zzEbz:
    }
}
