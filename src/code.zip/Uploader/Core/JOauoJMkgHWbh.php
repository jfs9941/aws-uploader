<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Contracts\LuYApSsjKQvJj;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\Traits\IdjMnkSrUQeOj;
use Jfs\Uploader\Core\Traits\LwZBr5bK6EUWt;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Service\NCOAFhLniyr9A;
class JOauoJMkgHWbh extends Lx6EggVsR2j6q implements PLPNmbBnD48xL
{
    use IdjMnkSrUQeOj;
    use LwZBr5bK6EUWt;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $f_0vQ, string $Xu3VW) : self
    {
        goto c4Ls2;
        McdrO:
        $PdjKE->mdigVxgooZG(IfP50GBBbx63a::UPLOADING);
        goto Y_M62;
        Y_M62:
        return $PdjKE;
        goto pzgwN;
        c4Ls2:
        $PdjKE = new self(['id' => $f_0vQ, 'type' => $Xu3VW, 'status' => IfP50GBBbx63a::UPLOADING]);
        goto McdrO;
        pzgwN:
    }
    public function getView() : array
    {
        $CcclM = app(LuYApSsjKQvJj::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $CcclM->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $CcclM->resolveThumbnail($this)];
    }
    public static function mfj1CtQBPLH(Lx6EggVsR2j6q $vIqmh) : JOauoJMkgHWbh
    {
        goto uFOxr;
        uFOxr:
        if (!$vIqmh instanceof JOauoJMkgHWbh) {
            goto sZAu3;
        }
        goto uleet;
        ZTFjp:
        return (new JOauoJMkgHWbh())->fill($vIqmh->getAttributes());
        goto Y2N1t;
        uleet:
        return $vIqmh;
        goto TeRhK;
        TeRhK:
        sZAu3:
        goto ZTFjp;
        Y2N1t:
    }
}
