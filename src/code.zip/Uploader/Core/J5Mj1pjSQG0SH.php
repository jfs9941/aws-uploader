<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

interface J5Mj1pjSQG0SH
{
    public function getFilename() : string;
    public function getExtension() : string;
    public function getType() : string;
    public function getLocation() : string;
    public function initLocation(string $fCww7);
    public static function createFromScratch(string $FeNc2, string $lfMjH);
    public function getView();
}
