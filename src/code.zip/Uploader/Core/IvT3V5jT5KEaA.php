<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Contracts\Ijay4AiPvrqAE;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\Traits\LIcGrY9QpTYiX;
use Jfs\Uploader\Core\Traits\Jvq5Oxs9eu5n3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
class IvT3V5jT5KEaA extends ZZfsW9KHWsMrx implements N6d9ndnX4hqae
{
    use LIcGrY9QpTYiX;
    use Jvq5Oxs9eu5n3;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $BeTZm, string $vQR_D) : self
    {
        goto iGcxe;
        xWvzn:
        $IrxWj->m5qfukNPanz(QE1dzvgcPWV6R::UPLOADING);
        goto VVVYs;
        iGcxe:
        $IrxWj = new self(['id' => $BeTZm, 'type' => $vQR_D, 'status' => QE1dzvgcPWV6R::UPLOADING]);
        goto xWvzn;
        VVVYs:
        return $IrxWj;
        goto y8_YG;
        y8_YG:
    }
    public function width() : ?int
    {
        goto OoXxY;
        OoXxY:
        $IxHFs = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto ebYOQ;
        u5PGo:
        return $IxHFs;
        goto RE3nE;
        ebYOQ:
        if (!$IxHFs) {
            goto NPTbH;
        }
        goto u5PGo;
        RE3nE:
        NPTbH:
        goto DCSpf;
        DCSpf:
        return null;
        goto fg61u;
        fg61u:
    }
    public function height() : ?int
    {
        goto XyddC;
        Al1Zm:
        return $Ijyqc;
        goto ALbRh;
        AeMqJ:
        if (!$Ijyqc) {
            goto DquZg;
        }
        goto Al1Zm;
        XyddC:
        $Ijyqc = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto AeMqJ;
        GPM8B:
        return null;
        goto HD7bT;
        ALbRh:
        DquZg:
        goto GPM8B;
        HD7bT:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($IrxWj) {
            goto lVsHe;
            tUsAp:
            return;
            goto EoieI;
            BKKDi:
            if (!(!array_key_exists('thumbnail', $R1DhE) && !array_key_exists('hls_path', $R1DhE))) {
                goto R2vgk;
            }
            goto tUsAp;
            lVsHe:
            $R1DhE = $IrxWj->getDirty();
            goto BKKDi;
            lt3EM:
            if (!($R1DhE['thumbnail'] || $R1DhE['hls_path'])) {
                goto pnmil;
            }
            goto bWYv6;
            bWYv6:
            IvT3V5jT5KEaA::where('parent_id', $IrxWj->getAttribute('id'))->update(['thumbnail' => $IrxWj->getAttributes()['thumbnail'], 'hls_path' => $IrxWj->getAttributes()['hls_path']]);
            goto XXfIH;
            XXfIH:
            pnmil:
            goto X3nGq;
            EoieI:
            R2vgk:
            goto lt3EM;
            X3nGq:
        });
    }
    public function m2lEzwsENk9()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mK96Bm4j5qw()
    {
        return $this->getAttribute('id');
    }
    public function mdFeGNmju5e() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto FIU7H;
        BZWI1:
        if ($this->getAttribute('hls_path')) {
            goto kyzCq;
        }
        goto TobYd;
        FIU7H:
        $vYRhC = app(Ijay4AiPvrqAE::class);
        goto lrLs6;
        lrLs6:
        $hhZ0v = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $vYRhC->resolvePath($this, $this->getAttribute('driver'))];
        goto BZWI1;
        u6bpi:
        return $hhZ0v;
        goto BFnMT;
        FnB7O:
        $hhZ0v['thumbnail'] = $vYRhC->resolveThumbnail($this);
        goto u6bpi;
        imVFk:
        $hhZ0v['player_url'] = $vYRhC->resolvePathForHlsVideo($this, true);
        goto ZKVoU;
        d13s5:
        kyzCq:
        goto imVFk;
        ZKVoU:
        M1Y2d:
        goto FnB7O;
        zjQzs:
        goto M1Y2d;
        goto d13s5;
        TobYd:
        $hhZ0v['player_url'] = $vYRhC->resolvePath($this, $this->getAttribute('driver'));
        goto zjQzs;
        BFnMT:
    }
    public function getThumbnails()
    {
        goto dGBYJ;
        dGBYJ:
        $Kd_aQ = $this->getAttribute('generated_previews') ?? [];
        goto NCLFt;
        IYijY:
        return array_map(function ($th60a) use($vYRhC) {
            return $vYRhC->resolvePath($th60a);
        }, $Kd_aQ);
        goto i0VUZ;
        NCLFt:
        $vYRhC = app(Ijay4AiPvrqAE::class);
        goto IYijY;
        i0VUZ:
    }
    public static function mONJQtUC1V5(ZZfsW9KHWsMrx $mbUjE) : IvT3V5jT5KEaA
    {
        goto MNHOd;
        MNHOd:
        if (!$mbUjE instanceof IvT3V5jT5KEaA) {
            goto fahQl;
        }
        goto t0sjT;
        rQmqQ:
        return (new IvT3V5jT5KEaA())->fill($mbUjE->getAttributes());
        goto Y1I6M;
        t0sjT:
        return $mbUjE;
        goto AWh8H;
        AWh8H:
        fahQl:
        goto rQmqQ;
        Y1I6M:
    }
}
