<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Core\Observer\CCRkQg8HrppN4;
use Jfs\Uploader\Core\Traits\AfKE97XXxITZ0;
use Jfs\Uploader\Core\Traits\RmjpXY01QWbl2;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Exception\KVgPdowMikNnK;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Jfs\Uploader\Exception\WgiszEiQkEJPG;
use Jfs\Uploader\Service\RLP5XS0nrqtBl;
final class ZOwA486ueqbmD implements VH6naaofz5IuZ
{
    use AfKE97XXxITZ0;
    use RmjpXY01QWbl2;
    private $I48AM;
    private function __construct($I2SbP, $p1fCH)
    {
        $this->oWuCn = $I2SbP;
        $this->meUU4 = $p1fCH;
    }
    private function mQWWbsZymNv(string $UYSBS, $p1fCH, $zCXkD, bool $oe4sb = false) : void
    {
        $this->mcp2uALDwNg(new CCRkQg8HrppN4($this, $p1fCH, $zCXkD, $UYSBS, $oe4sb));
    }
    public function getFile()
    {
        return $this->oWuCn;
    }
    public function msb2M0BFxEn(array $hvQC1) : void
    {
        $this->I48AM = $hvQC1;
    }
    public function maJTK30GZlo() : void
    {
        $this->mY8gUThQFjU(EPmxqTVp5luXc::UPLOADING);
    }
    public function mxnfqLi70gc() : void
    {
        $this->mY8gUThQFjU(EPmxqTVp5luXc::UPLOADED);
    }
    public function mrbL8K4c0Iy() : void
    {
        $this->mY8gUThQFjU(EPmxqTVp5luXc::PROCESSING);
    }
    public function m6RMo1yoqSN() : void
    {
        $this->mY8gUThQFjU(EPmxqTVp5luXc::FINISHED);
    }
    public function mk8zM424oMJ() : void
    {
        $this->mY8gUThQFjU(EPmxqTVp5luXc::ABORTED);
    }
    public function mJ33AkKTqbd() : array
    {
        return $this->I48AM;
    }
    public static function mAtEUX947sU(string $FILUb, $KoBWD, $tYsty, $UYSBS) : self
    {
        goto q5I_m;
        gbRqw:
        $p8nhd->mkv7RuyOFPh(EPmxqTVp5luXc::UPLOADING);
        goto wAW5K;
        q5I_m:
        $I2SbP = App::make(RLP5XS0nrqtBl::class)->mlImLDi7VHC(LwEuADzdXxX43::m16Obv6eGzx($FILUb));
        goto h8fo9;
        wAW5K:
        return $p8nhd->mqRlOWYrGFi();
        goto M_Q8t;
        h8fo9:
        $p8nhd = new self($I2SbP, $KoBWD);
        goto Vn7FR;
        Vn7FR:
        $p8nhd->mQWWbsZymNv($UYSBS, $KoBWD, $tYsty);
        goto gbRqw;
        M_Q8t:
    }
    public static function mxZLeTghw2H($I2SbP, $p1fCH, $zCXkD, $UYSBS, $oe4sb = false) : self
    {
        goto IfrWg;
        IfrWg:
        $p8nhd = new self($I2SbP, $p1fCH);
        goto F5JeE;
        F5JeE:
        $p8nhd->mQWWbsZymNv($UYSBS, $p1fCH, $zCXkD, $oe4sb);
        goto e0V1Y;
        J3qo9:
        return $p8nhd;
        goto bwb2T;
        e0V1Y:
        $p8nhd->mkv7RuyOFPh(EPmxqTVp5luXc::UPLOADING);
        goto J3qo9;
        bwb2T:
    }
}
