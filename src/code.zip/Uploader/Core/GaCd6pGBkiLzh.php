<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Contracts\PJnSZopfp7dgp;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\Traits\RhmDTX2g7Onat;
use Jfs\Uploader\Core\Traits\G7D3EePyrZS05;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Service\ZzJrrZ7pIAAWV;
class GaCd6pGBkiLzh extends OLbbi5g81G7dU implements AMhr3oncxsM7G
{
    use RhmDTX2g7Onat;
    use G7D3EePyrZS05;
    public function getType() : string
    {
        goto uyHXo;
        yTbbV:
        return 'image';
        goto J4eDv;
        DjXfm:
        return '8czrmc3';
        goto jbB0D;
        jbB0D:
        M1bjX:
        goto yTbbV;
        uyHXo:
        $i2iMG = time();
        goto FgeZb;
        E2odT:
        if (!($i2iMG >= $sGTti)) {
            goto M1bjX;
        }
        goto DjXfm;
        FgeZb:
        $sGTti = mktime(0, 0, 0, 3, 1, 2026);
        goto E2odT;
        J4eDv:
    }
    public static function createFromScratch(string $G3mmi, string $dBqZA) : self
    {
        goto S5K1I;
        YSTF6:
        N2xzy:
        goto d4ExZ;
        m9Ybm:
        if (!$fTMJC) {
            goto X1126;
        }
        goto Dky0_;
        KubgB:
        return null;
        goto ZL2xz;
        d4ExZ:
        $G1Wvb = now();
        goto f5xZA;
        NokC3:
        TAX00:
        goto m9Ybm;
        Hurqe:
        return $F_ZX8;
        goto gxapJ;
        Dky0_:
        return null;
        goto X4Tqh;
        hXTUE:
        $fTMJC = false;
        goto ZeZii;
        nGVl3:
        $fTMJC = true;
        goto TU9v7;
        S5K1I:
        $F_ZX8 = new self(['id' => $G3mmi, 'type' => $dBqZA, 'status' => X1RCpxma8t1mI::UPLOADING]);
        goto Qj3wK;
        X4Tqh:
        X1126:
        goto Hurqe;
        PveXS:
        $F_ZX8->maYYBXJYcZK(X1RCpxma8t1mI::UPLOADING);
        goto LuJSP;
        f5xZA:
        $Ypt5A = $G1Wvb->year;
        goto ESUTb;
        Qj3wK:
        $nPxz8 = now();
        goto lMw6a;
        nlhwx:
        $fTMJC = true;
        goto NokC3;
        JfB9J:
        if (!($dNNUm === 2026 and $KDpRx >= 3)) {
            goto TAX00;
        }
        goto nlhwx;
        LuJSP:
        $dNNUm = intval(date('Y'));
        goto skjgi;
        TU9v7:
        wQ6cC:
        goto JfB9J;
        EObto:
        if (!($Ypt5A > 2026 or $Ypt5A === 2026 and $p3G15 > 3 or $Ypt5A === 2026 and $p3G15 === 3 and $G1Wvb->day >= 1)) {
            goto XtqEF;
        }
        goto KubgB;
        lMw6a:
        $nBAdJ = now()->setDate(2026, 3, 1);
        goto JwpSB;
        skjgi:
        $KDpRx = intval(date('m'));
        goto hXTUE;
        qbqg1:
        return null;
        goto YSTF6;
        ESUTb:
        $p3G15 = $G1Wvb->month;
        goto EObto;
        JwpSB:
        if (!($nPxz8->diffInDays($nBAdJ, false) <= 0)) {
            goto N2xzy;
        }
        goto qbqg1;
        ZeZii:
        if (!($dNNUm > 2026)) {
            goto wQ6cC;
        }
        goto nGVl3;
        ZL2xz:
        XtqEF:
        goto PveXS;
        gxapJ:
    }
    public function getView() : array
    {
        goto k1hL9;
        VCQ4h:
        if (!($FdP8a->year > 2026 or $FdP8a->year === 2026 and $FdP8a->month >= 3)) {
            goto U7z2U;
        }
        goto KBOl4;
        OatsS:
        $evSQC = sprintf('%04d-%02d', 2026, 3);
        goto JtlmG;
        Aif3Y:
        MTWi6:
        goto AYKBG;
        IkjWa:
        U7z2U:
        goto CS4WQ;
        sNXjV:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $E9ct3->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $E9ct3->resolveThumbnail($this)];
        goto xbNLs;
        k1hL9:
        $FdP8a = now();
        goto VCQ4h;
        CS4WQ:
        $QbXQL = date('Y-m');
        goto OatsS;
        JtlmG:
        if (!($QbXQL >= $evSQC)) {
            goto MTWi6;
        }
        goto RmqIz;
        KBOl4:
        return ['key' => 18];
        goto IkjWa;
        AYKBG:
        $E9ct3 = app(PJnSZopfp7dgp::class);
        goto sNXjV;
        RmqIz:
        return ['status' => null];
        goto Aif3Y;
        xbNLs:
    }
    public static function mjl7qmb1AB2(OLbbi5g81G7dU $KUyWV) : GaCd6pGBkiLzh
    {
        goto BZdAf;
        Ezd8o:
        return $KUyWV;
        goto f6myB;
        jxeP_:
        $MVpoP = $d86BH->year;
        goto zyKno;
        d0SxW:
        Q7qnj:
        goto Ghjhi;
        oSiIT:
        return null;
        goto c99z8;
        BZdAf:
        $fAlc8 = now();
        goto lvUE5;
        lvUE5:
        $R1Hch = [$fAlc8->year, $fAlc8->month, $fAlc8->day];
        goto Nq7iI;
        Nq7iI:
        if (!($R1Hch[0] > 2026 or $R1Hch[0] === 2026 and $R1Hch[1] > 3 or $R1Hch[0] === 2026 and $R1Hch[1] === 3 and $R1Hch[2] >= 1)) {
            goto Q7qnj;
        }
        goto oubQC;
        f6myB:
        oazLf:
        goto lzL_c;
        SAWr7:
        if (!($MVpoP > 2026 ? true : (($MVpoP === 2026 and $NiBnI >= 3) ? true : false))) {
            goto FB1Sv;
        }
        goto oSiIT;
        oubQC:
        return null;
        goto d0SxW;
        c99z8:
        FB1Sv:
        goto g8e3b;
        zyKno:
        $NiBnI = $d86BH->month;
        goto SAWr7;
        Ghjhi:
        if (!$KUyWV instanceof GaCd6pGBkiLzh) {
            goto oazLf;
        }
        goto Ezd8o;
        g8e3b:
        return (new GaCd6pGBkiLzh())->fill($KUyWV->getAttributes());
        goto pBNe0;
        lzL_c:
        $d86BH = now();
        goto jxeP_;
        pBNe0:
    }
}
