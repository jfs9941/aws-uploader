<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Core;

use Illuminate\Support\Facades\App;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\Observer\Gtj9UGCCs3DRi;
use src\Uploader\Core\ON6DdH7AqGsXP;
use src\Uploader\Core\Traits\NURFewLmHDDb8;
use src\Uploader\Core\Traits\ZsSQ59OgPo1KE;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Exception\BUbHQrtyLH6v0;
use src\Uploader\Exception\Hm3sz2t6t56o2;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Service\TMv85L5ZRTfOP;
final class HU7bCai77CgrB implements PxmUcH2EZiEWo
{
    use ZsSQ59OgPo1KE;
    use NURFewLmHDDb8;
    private $ZpzAD;
    private function __construct($d1aiC, $eX8wo)
    {
        $this->dfQse = $d1aiC;
        $this->AGWue = $eX8wo;
    }
    private function mXYVvn1jKi9(string $FQWsT, $eX8wo, $RustJ, bool $PR2tR = false) : void
    {
        $this->mLnW7ZmkfSj(new Gtj9UGCCs3DRi($this, $eX8wo, $RustJ, $FQWsT, $PR2tR));
    }
    public function getFile()
    {
        return $this->dfQse;
    }
    public function mN5M3gzjZ92(array $mVVgY) : void
    {
        $this->ZpzAD = $mVVgY;
    }
    public function mzzcnzYtz82() : void
    {
        $this->mIjUnedc3Mq(FileStatus::UPLOADING);
    }
    public function meMUPYyDn2z() : void
    {
        $this->mIjUnedc3Mq(FileStatus::UPLOADED);
    }
    public function moiKSY5Wv01() : void
    {
        $this->mIjUnedc3Mq(FileStatus::PROCESSING);
    }
    public function mtFuuuTsRfl() : void
    {
        $this->mIjUnedc3Mq(FileStatus::FINISHED);
    }
    public function mfqxR02QQww() : void
    {
        $this->mIjUnedc3Mq(FileStatus::ABORTED);
    }
    public function mAjoRKsAUe1() : array
    {
        return $this->ZpzAD;
    }
    public static function mqJlQQxUtrR(string $BFPg9, $PYWYp, $SaekO, $FQWsT) : self
    {
        goto v8nns;
        CZjpt:
        $hfZR1->mRGXJFOfzBv(FileStatus::UPLOADING);
        goto XWcDV;
        mA_LE:
        $hfZR1->mXYVvn1jKi9($FQWsT, $PYWYp, $SaekO);
        goto CZjpt;
        nR0A8:
        $hfZR1 = new self($d1aiC, $PYWYp);
        goto mA_LE;
        v8nns:
        $d1aiC = App::make(TMv85L5ZRTfOP::class)->mn1IICjO3Jz(ON6DdH7AqGsXP::mDUKvw1QoZp($BFPg9));
        goto nR0A8;
        XWcDV:
        return $hfZR1->mDTcKdc82Rx();
        goto CgH7x;
        CgH7x:
    }
    public static function m6VkC76XUFm($d1aiC, $eX8wo, $RustJ, $FQWsT, $PR2tR = false) : self
    {
        goto s0LYR;
        Q4tEs:
        $hfZR1->mXYVvn1jKi9($FQWsT, $eX8wo, $RustJ, $PR2tR);
        goto XdxLJ;
        XdxLJ:
        $hfZR1->mRGXJFOfzBv(FileStatus::UPLOADING);
        goto sEd3I;
        sEd3I:
        return $hfZR1;
        goto hMNVB;
        s0LYR:
        $hfZR1 = new self($d1aiC, $eX8wo);
        goto Q4tEs;
        hMNVB:
    }
}
