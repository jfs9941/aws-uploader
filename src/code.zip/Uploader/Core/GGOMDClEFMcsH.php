<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Illuminate\Database\Eloquent\Model;
abstract  class GGOMDClEFMcsH extends Model implements J9AcMiQKgpvel
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mC8wY3yRBEY() : bool
    {
        goto rd4Hc;
        CiVVk:
        return true;
        goto Yh851;
        B2gSj:
        return !$this->mPeeEVOKZjr();
        goto M5vXq;
        rd4Hc:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto gHyWI;
        }
        goto CiVVk;
        Yh851:
        gHyWI:
        goto B2gSj;
        M5vXq:
    }
    protected function mPeeEVOKZjr() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
