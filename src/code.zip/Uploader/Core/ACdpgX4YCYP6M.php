<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Core\Traits\E2oUjXwrsjJZQ;
use Jfs\Uploader\Core\Traits\AyFiTfhD6jOXL;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class ACdpgX4YCYP6M extends GuA6QuvssLUzf implements JGFha5eJXVoQK
{
    use E2oUjXwrsjJZQ;
    use AyFiTfhD6jOXL;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $YIAds, string $poyPD) : self
    {
        goto NLb_t;
        NLb_t:
        $vd5JT = new self(['id' => $YIAds, 'type' => $poyPD, 'status' => QoCMzcKvH8Cw2::UPLOADING]);
        goto Antdz;
        LHUbw:
        return $vd5JT;
        goto Fv_2i;
        Antdz:
        $vd5JT->mGG5zG7yPwR(QoCMzcKvH8Cw2::UPLOADING);
        goto LHUbw;
        Fv_2i:
    }
    public function width() : ?int
    {
        goto ed2OC;
        gt_3d:
        return $ABqPe;
        goto EKHEr;
        tyqWT:
        return null;
        goto UiyqA;
        WvAPc:
        if (!$ABqPe) {
            goto w3C_e;
        }
        goto gt_3d;
        ed2OC:
        $ABqPe = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto WvAPc;
        EKHEr:
        w3C_e:
        goto tyqWT;
        UiyqA:
    }
    public function height() : ?int
    {
        goto UnCob;
        UGPp7:
        return $dE8ui;
        goto gJVWP;
        t50Ae:
        if (!$dE8ui) {
            goto S1psl;
        }
        goto UGPp7;
        gJVWP:
        S1psl:
        goto E7mj_;
        E7mj_:
        return null;
        goto IAopq;
        UnCob:
        $dE8ui = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto t50Ae;
        IAopq:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($vd5JT) {
            goto NLH6D;
            dZbMh:
            s0bRv:
            goto v4NgA;
            Eg91y:
            qgeDg:
            goto Ie2N7;
            Ie2N7:
            if (!($Xb7zC['thumbnail'] || $Xb7zC['hls_path'])) {
                goto s0bRv;
            }
            goto OhP9U;
            TbNCH:
            if (!(!array_key_exists('thumbnail', $Xb7zC) && !array_key_exists('hls_path', $Xb7zC))) {
                goto qgeDg;
            }
            goto g7sKK;
            g7sKK:
            return;
            goto Eg91y;
            NLH6D:
            $Xb7zC = $vd5JT->getDirty();
            goto TbNCH;
            OhP9U:
            ACdpgX4YCYP6M::where('parent_id', $vd5JT->getAttribute('id'))->update(['thumbnail' => $vd5JT->getAttributes()['thumbnail'], 'hls_path' => $vd5JT->getAttributes()['hls_path']]);
            goto dZbMh;
            v4NgA:
        });
    }
    public function mR9mqb3l39c()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mkf0KdiApiT()
    {
        return $this->getAttribute('id');
    }
    public function mtkJpGLr3yD() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto pI8FV;
        PmfyJ:
        $IjqxX['player_url'] = $SMQC2->resolvePathForHlsVideo($this, true);
        goto dUm9y;
        oNpez:
        tvWBA:
        goto PmfyJ;
        UtEZD:
        $IjqxX['thumbnail'] = $SMQC2->resolveThumbnail($this);
        goto wsZQJ;
        EbOGF:
        goto ydnX1;
        goto oNpez;
        wsZQJ:
        return $IjqxX;
        goto yA9_J;
        qoH6N:
        if ($this->getAttribute('hls_path')) {
            goto tvWBA;
        }
        goto dQsya;
        sj34V:
        $IjqxX = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $SMQC2->resolvePath($this, $this->getAttribute('driver'))];
        goto qoH6N;
        dQsya:
        $IjqxX['player_url'] = $SMQC2->resolvePath($this, $this->getAttribute('driver'));
        goto EbOGF;
        dUm9y:
        ydnX1:
        goto UtEZD;
        pI8FV:
        $SMQC2 = app(HqWA5DdMiDW1U::class);
        goto sj34V;
        yA9_J:
    }
    public function getThumbnails()
    {
        goto oIe0a;
        RXo31:
        return array_map(function ($NSw82) use($SMQC2) {
            return $SMQC2->resolvePath($NSw82);
        }, $UJs36);
        goto CfFCu;
        oIe0a:
        $UJs36 = $this->getAttribute('generated_previews') ?? [];
        goto TP0SS;
        TP0SS:
        $SMQC2 = app(HqWA5DdMiDW1U::class);
        goto RXo31;
        CfFCu:
    }
    public static function mYP43RJwVqM(GuA6QuvssLUzf $nNNVD) : ACdpgX4YCYP6M
    {
        goto Wl6h_;
        Wl6h_:
        if (!$nNNVD instanceof ACdpgX4YCYP6M) {
            goto gdWku;
        }
        goto L5w_T;
        kdlO7:
        return (new ACdpgX4YCYP6M())->fill($nNNVD->getAttributes());
        goto aGVoe;
        Y1M1V:
        gdWku:
        goto kdlO7;
        L5w_T:
        return $nNNVD;
        goto Y1M1V;
        aGVoe:
    }
}
