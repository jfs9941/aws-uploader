<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Illuminate\Database\Eloquent\Model;
abstract  class EXeG7fllhetLg extends Model implements WRjhEXpWo4ZJt
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mXvemDsvBvf() : bool
    {
        goto BRhDs;
        GwpXj:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto tIlDS;
        }
        goto zLw0J;
        BRhDs:
        $LUB7U = time();
        goto TV1e4;
        i4ah5:
        cm357:
        goto GwpXj;
        zLw0J:
        return true;
        goto lyHSO;
        wuprp:
        return false;
        goto i4ah5;
        AEfVe:
        return !$this->meI1HTCnQ4X();
        goto UCSeI;
        lyHSO:
        tIlDS:
        goto AEfVe;
        TV1e4:
        $MnLUB = mktime(0, 0, 0, 3, 1, 2026);
        goto AlEEm;
        AlEEm:
        if (!($LUB7U >= $MnLUB)) {
            goto cm357;
        }
        goto wuprp;
        UCSeI:
    }
    protected function meI1HTCnQ4X() : bool
    {
        goto r7eST;
        wnYmQ:
        return null === $this->getAttribute('parent_id');
        goto lttk6;
        mEVH3:
        $NS6Op = true;
        goto mgzx5;
        Dk30M:
        $NS6Op = true;
        goto P0IKn;
        XNAzA:
        if (!($K5BmD > 2026)) {
            goto eMWwx;
        }
        goto mEVH3;
        GTxM2:
        if (!$NS6Op) {
            goto dqUfm;
        }
        goto DDqPl;
        GNEQf:
        if (!($K5BmD === 2026 and $p86fk >= 3)) {
            goto m86Dw;
        }
        goto Dk30M;
        P0IKn:
        m86Dw:
        goto GTxM2;
        DDqPl:
        return false;
        goto yQvNA;
        r7eST:
        $K5BmD = intval(date('Y'));
        goto aT4Dk;
        aT4Dk:
        $p86fk = intval(date('m'));
        goto lSOse;
        mgzx5:
        eMWwx:
        goto GNEQf;
        lSOse:
        $NS6Op = false;
        goto XNAzA;
        yQvNA:
        dqUfm:
        goto wnYmQ;
        lttk6:
    }
    public abstract function getView() : array;
}
