<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Contracts\VwiVLFCuZN4fA;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\Traits\NYTKsbVPARY8x;
use Jfs\Uploader\Core\Traits\V5MfgbTUETSZ1;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
class HVuLZHLrSam0d extends D3Q3lppZQonk9 implements ZEs3XZLglwgUu
{
    use NYTKsbVPARY8x;
    use V5MfgbTUETSZ1;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $sAFP4, string $geXNd) : self
    {
        goto TFc7M;
        xUDtL:
        return $jZqB7;
        goto rY4SE;
        TFc7M:
        $jZqB7 = new self(['id' => $sAFP4, 'type' => $geXNd, 'status' => ZVJoOgH14iXBq::UPLOADING]);
        goto xMkA4;
        xMkA4:
        $jZqB7->mWCCmTIigqB(ZVJoOgH14iXBq::UPLOADING);
        goto xUDtL;
        rY4SE:
    }
    public function width() : ?int
    {
        goto Rb1pg;
        dTL4b:
        return $p9c0Q;
        goto rWwDj;
        dfK7k:
        return null;
        goto k0GEi;
        kz7wZ:
        if (!$p9c0Q) {
            goto TusXy;
        }
        goto dTL4b;
        Rb1pg:
        $p9c0Q = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto kz7wZ;
        rWwDj:
        TusXy:
        goto dfK7k;
        k0GEi:
    }
    public function height() : ?int
    {
        goto Ai9XS;
        tkScb:
        q3VDv:
        goto QtBDU;
        t_TTM:
        return $erqpi;
        goto tkScb;
        QtBDU:
        return null;
        goto fK1cY;
        pCAQu:
        if (!$erqpi) {
            goto q3VDv;
        }
        goto t_TTM;
        Ai9XS:
        $erqpi = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto pCAQu;
        fK1cY:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($jZqB7) {
            goto a_RGZ;
            Cjbe2:
            n10Fg:
            goto joWl5;
            xg3po:
            if (!(!array_key_exists('thumbnail', $ELCN0) && !array_key_exists('hls_path', $ELCN0))) {
                goto n10Fg;
            }
            goto wHc30;
            a_RGZ:
            $ELCN0 = $jZqB7->getDirty();
            goto xg3po;
            RQXJo:
            HVuLZHLrSam0d::where('parent_id', $jZqB7->getAttribute('id'))->update(['thumbnail' => $jZqB7->getAttributes()['thumbnail'], 'hls_path' => $jZqB7->getAttributes()['hls_path']]);
            goto Bj5S4;
            joWl5:
            if (!($ELCN0['thumbnail'] || $ELCN0['hls_path'])) {
                goto Qirj3;
            }
            goto RQXJo;
            wHc30:
            return;
            goto Cjbe2;
            Bj5S4:
            Qirj3:
            goto qdSH1;
            qdSH1:
        });
    }
    public function mTsIKwleqJO()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m2oItzkRLIM()
    {
        return $this->getAttribute('id');
    }
    public function mT5TzE9XKm8() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto UL26J;
        ZU5Gg:
        HMDoN:
        goto FSoaL;
        WrNSK:
        $jlkIR = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $RXqJj->resolvePath($this, $this->getAttribute('driver'))];
        goto LPG3G;
        UL26J:
        $RXqJj = app(VwiVLFCuZN4fA::class);
        goto WrNSK;
        WBjNF:
        $jlkIR['player_url'] = $RXqJj->resolvePath($this, $this->getAttribute('driver'));
        goto luG9A;
        Jodzd:
        A0sQ7:
        goto M6cwW;
        xLtK5:
        return $jlkIR;
        goto dDb8I;
        luG9A:
        goto HMDoN;
        goto Jodzd;
        FSoaL:
        $jlkIR['thumbnail'] = $RXqJj->resolveThumbnail($this);
        goto xLtK5;
        M6cwW:
        $jlkIR['player_url'] = $RXqJj->resolvePathForHlsVideo($this, true);
        goto ZU5Gg;
        LPG3G:
        if ($this->getAttribute('hls_path')) {
            goto A0sQ7;
        }
        goto WBjNF;
        dDb8I:
    }
    public function getThumbnails()
    {
        goto iwR1q;
        iwR1q:
        $drfh5 = $this->getAttribute('generated_previews') ?? [];
        goto nlRqn;
        Oqi2F:
        return array_map(function ($NQQfI) use($RXqJj) {
            return $RXqJj->resolvePath($NQQfI);
        }, $drfh5);
        goto epRud;
        nlRqn:
        $RXqJj = app(VwiVLFCuZN4fA::class);
        goto Oqi2F;
        epRud:
    }
    public static function mZ5lW3h9Joj(D3Q3lppZQonk9 $mA8Ck) : HVuLZHLrSam0d
    {
        goto mrvXf;
        TiWwK:
        return (new HVuLZHLrSam0d())->fill($mA8Ck->getAttributes());
        goto YLbHi;
        KAbl5:
        return $mA8Ck;
        goto ULOJa;
        ULOJa:
        PjfTi:
        goto TiWwK;
        mrvXf:
        if (!$mA8Ck instanceof HVuLZHLrSam0d) {
            goto PjfTi;
        }
        goto KAbl5;
        YLbHi:
    }
}
