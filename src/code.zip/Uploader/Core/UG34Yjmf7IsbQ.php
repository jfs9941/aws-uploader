<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Contracts\AbPtLXucv9ja8;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\Traits\IBoPBAZwQwRqv;
use Jfs\Uploader\Core\Traits\W8XZSueQaszDJ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Service\AkmCl9xAlobwb;
class UG34Yjmf7IsbQ extends OWEQTdXGAAFta implements DHtESYY0VyGQJ
{
    use IBoPBAZwQwRqv;
    use W8XZSueQaszDJ;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $eVMet, string $cJEs5) : self
    {
        goto M2ZiC;
        M2ZiC:
        $K0J89 = new self(['id' => $eVMet, 'type' => $cJEs5, 'status' => A7CVlqbpzhfLD::UPLOADING]);
        goto SOgvJ;
        CfXiJ:
        return $K0J89;
        goto LXQrC;
        SOgvJ:
        $K0J89->mdMI6wvUXmN(A7CVlqbpzhfLD::UPLOADING);
        goto CfXiJ;
        LXQrC:
    }
    public function getView() : array
    {
        $wt4Tn = app(AbPtLXucv9ja8::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $wt4Tn->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $wt4Tn->resolveThumbnail($this)];
    }
    public static function mm5YMwHGTZ1(OWEQTdXGAAFta $QWQ9j) : UG34Yjmf7IsbQ
    {
        goto aT354;
        eAW4b:
        return (new UG34Yjmf7IsbQ())->fill($QWQ9j->getAttributes());
        goto DarcS;
        aT354:
        if (!$QWQ9j instanceof UG34Yjmf7IsbQ) {
            goto xlbbb;
        }
        goto cn0WV;
        cn0WV:
        return $QWQ9j;
        goto qMacm;
        qMacm:
        xlbbb:
        goto eAW4b;
        DarcS:
    }
}
