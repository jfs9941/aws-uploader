<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Contracts\K0dipGcxtVboz;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\Traits\QuukgXnznCEU4;
use Jfs\Uploader\Core\Traits\Iny7AwCou1ddb;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Service\FiQYSbwR1Ly8I;
class S7LEoIprYtLQw extends NRDoWGrbd9WhU implements IzCykbeCOYPNB
{
    use QuukgXnznCEU4;
    use Iny7AwCou1ddb;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $ExhEa, string $zuSYz) : self
    {
        goto CPgbR;
        CPgbR:
        $uuvVo = new self(['id' => $ExhEa, 'type' => $zuSYz, 'status' => EXecNg2hg7kwl::UPLOADING]);
        goto EIMXR;
        EIMXR:
        $uuvVo->mQ7dAxBkFij(EXecNg2hg7kwl::UPLOADING);
        goto lfdyJ;
        lfdyJ:
        return $uuvVo;
        goto pMmQn;
        pMmQn:
    }
    public function getView() : array
    {
        $tKXn_ = app(K0dipGcxtVboz::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $tKXn_->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $tKXn_->resolveThumbnail($this)];
    }
    public static function mKzMM5HkJZD(NRDoWGrbd9WhU $S8CpP) : S7LEoIprYtLQw
    {
        goto jm2Zy;
        jm2Zy:
        if (!$S8CpP instanceof S7LEoIprYtLQw) {
            goto KGo4R;
        }
        goto lSvkM;
        RlFUr:
        return (new S7LEoIprYtLQw())->fill($S8CpP->getAttributes());
        goto fEqSa;
        lSvkM:
        return $S8CpP;
        goto v2hRT;
        v2hRT:
        KGo4R:
        goto RlFUr;
        fEqSa:
    }
}
