<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
final class ZQCRUoYnm7ASE
{
    public $filename;
    public $le4b_;
    public $v1MoV;
    public $Nx14_;
    public $Z1nJX;
    public $eTR5r;
    public $d1W2V;
    public $status;
    public $VBNJB;
    public $PnBsq;
    public $bdBtT = 's3';
    public $ODhaJ = [];
    public function __construct($bI33B, $uXg0E, $CwXhg, $JVYKn, $NM6rj, $R5uXi, $JRdZP, $lXEQ7, $Iwgmc, $Kps2Q, $nHjZR = 's3', $MF1dT = [])
    {
        goto swy6J;
        ij0RR:
        $this->Z1nJX = $NM6rj;
        goto F4rwb;
        vAzZ6:
        $this->PnBsq = $Kps2Q;
        goto YSjLl;
        F4rwb:
        $this->eTR5r = $R5uXi;
        goto BWPMl;
        OFlwW:
        $this->le4b_ = $uXg0E;
        goto xvLfj;
        YSjLl:
        $this->bdBtT = $nHjZR;
        goto pPkiD;
        mjXwX:
        $this->VBNJB = $Iwgmc;
        goto vAzZ6;
        so5Xk:
        $this->status = $lXEQ7;
        goto mjXwX;
        BWPMl:
        $this->d1W2V = $JRdZP;
        goto so5Xk;
        lfk0j:
        $this->Nx14_ = $JVYKn;
        goto ij0RR;
        xvLfj:
        $this->v1MoV = $CwXhg;
        goto lfk0j;
        pPkiD:
        $this->ODhaJ = $MF1dT;
        goto CODGm;
        swy6J:
        $this->filename = $bI33B;
        goto OFlwW;
        CODGm:
    }
    private static function mwX9sTQK1bA() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mNgfqVoWu3g() : array
    {
        return array_flip(self::mwX9sTQK1bA());
    }
    public function toArray() : array
    {
        $hqP_0 = self::mwX9sTQK1bA();
        return [$hqP_0['filename'] => $this->filename, $hqP_0['fileExtension'] => $this->le4b_, $hqP_0['mimeType'] => $this->v1MoV, $hqP_0['fileSize'] => $this->Nx14_, $hqP_0['chunkSize'] => $this->Z1nJX, $hqP_0['checksums'] => $this->eTR5r, $hqP_0['totalChunk'] => $this->d1W2V, $hqP_0['status'] => $this->status, $hqP_0['userId'] => $this->VBNJB, $hqP_0['uploadId'] => $this->PnBsq, $hqP_0['driver'] => $this->bdBtT, $hqP_0['parts'] => $this->ODhaJ];
    }
    public static function m53a1okOL98(array $DN9z0) : self
    {
        $VJBAo = array_flip(self::mNgfqVoWu3g());
        return new self($DN9z0[$VJBAo['filename']] ?? $DN9z0['filename'] ?? '', $DN9z0[$VJBAo['fileExtension']] ?? $DN9z0['fileExtension'] ?? '', $DN9z0[$VJBAo['mimeType']] ?? $DN9z0['mimeType'] ?? '', $DN9z0[$VJBAo['fileSize']] ?? $DN9z0['fileSize'] ?? 0, $DN9z0[$VJBAo['chunkSize']] ?? $DN9z0['chunkSize'] ?? 0, $DN9z0[$VJBAo['checksums']] ?? $DN9z0['checksums'] ?? [], $DN9z0[$VJBAo['totalChunk']] ?? $DN9z0['totalChunk'] ?? 0, $DN9z0[$VJBAo['status']] ?? $DN9z0['status'] ?? 0, $DN9z0[$VJBAo['userId']] ?? $DN9z0['userId'] ?? 0, $DN9z0[$VJBAo['uploadId']] ?? $DN9z0['uploadId'] ?? '', $DN9z0[$VJBAo['driver']] ?? $DN9z0['driver'] ?? 's3', $DN9z0[$VJBAo['parts']] ?? $DN9z0['parts'] ?? []);
    }
    public static function mFWPQDqpxn6($WwRgt) : self
    {
        goto dPP46;
        dPP46:
        if (!(isset($WwRgt['fn']) || isset($WwRgt['fe']))) {
            goto QK2OD;
        }
        goto z7EXv;
        WmS7Q:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto YrkDQ;
        z7EXv:
        return self::m53a1okOL98($WwRgt);
        goto e577V;
        e577V:
        QK2OD:
        goto WmS7Q;
        YrkDQ:
    }
    public function mV8qOAW9LsS(string $Kps2Q) : void
    {
        $this->PnBsq = $Kps2Q;
    }
    public function mItmJG4vJnm(array $MF1dT) : void
    {
        $this->ODhaJ = $MF1dT;
    }
    public static function mXCEl1YsBnP($QuYzZ, $AimGO, $Mcv7F, $Iwgmc, $NM6rj, $R5uXi, $nHjZR)
    {
        return new self($QuYzZ->getFilename(), $QuYzZ->getExtension(), $AimGO, $Mcv7F, $NM6rj, $R5uXi, count($R5uXi), QoCMzcKvH8Cw2::UPLOADING, $Iwgmc, 0, $nHjZR, []);
    }
    public static function mbbcEvheO3r($IaHim)
    {
        return 'metadata/' . $IaHim . '.json';
    }
    public function mU0MQafHL2j()
    {
        return 's3' === $this->bdBtT ? FUIPeZ7ssitYw::S3 : FUIPeZ7ssitYw::LOCAL;
    }
}
