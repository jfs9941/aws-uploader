<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Core\Traits\RN8oxnSswJ42z;
use Jfs\Uploader\Core\Traits\DbEmnet2FoHTm;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Service\WILlDNuoyQRBR;
class McTg5Yp6FKC6z extends Dup6KVtAFNCUq implements PxTzgsobiHpcX
{
    use RN8oxnSswJ42z;
    use DbEmnet2FoHTm;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $FeNc2, string $lfMjH) : self
    {
        goto lYwUi;
        lYwUi:
        $SYKC9 = new self(['id' => $FeNc2, 'type' => $lfMjH, 'status' => O8RzIjGmSN6fG::UPLOADING]);
        goto j0_z0;
        j0_z0:
        $SYKC9->mt6YUzzNxIA(O8RzIjGmSN6fG::UPLOADING);
        goto QWzwX;
        QWzwX:
        return $SYKC9;
        goto lpb_j;
        lpb_j:
    }
    public function getView() : array
    {
        $rm8QX = app(MpZUpGr3YFIhj::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $rm8QX->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $rm8QX->resolveThumbnail($this)];
    }
    public static function m4cyxOitf5I(Dup6KVtAFNCUq $FFbb9) : McTg5Yp6FKC6z
    {
        goto cR9WJ;
        n_s0_:
        return (new McTg5Yp6FKC6z())->fill($FFbb9->getAttributes());
        goto L77b3;
        cR9WJ:
        if (!$FFbb9 instanceof McTg5Yp6FKC6z) {
            goto iyHfG;
        }
        goto ZqT4l;
        ZqT4l:
        return $FFbb9;
        goto s25aT;
        s25aT:
        iyHfG:
        goto n_s0_;
        L77b3:
    }
}
