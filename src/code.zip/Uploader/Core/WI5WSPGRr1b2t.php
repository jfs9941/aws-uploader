<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Contracts\SRErb8bXZXjuL;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\Traits\Av20P07H9bvdh;
use Jfs\Uploader\Core\Traits\VnPCfppm663dI;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
class WI5WSPGRr1b2t extends NCmZ7rMVMWyvC implements LKF23eYmlDs0w
{
    use Av20P07H9bvdh;
    use VnPCfppm663dI;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $gQlRM, string $UEzod) : self
    {
        goto tyEFP;
        W7jja:
        $hgsqV->mXDdmT111J7(GlPuUJKmzwUJ9::UPLOADING);
        goto CsZ96;
        CsZ96:
        return $hgsqV;
        goto zxChI;
        tyEFP:
        $hgsqV = new self(['id' => $gQlRM, 'type' => $UEzod, 'status' => GlPuUJKmzwUJ9::UPLOADING]);
        goto W7jja;
        zxChI:
    }
    public function width() : ?int
    {
        goto Cm1TW;
        Cm1TW:
        $yRrbE = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto rizSx;
        rizSx:
        if (!$yRrbE) {
            goto BUB73;
        }
        goto UknrZ;
        UknrZ:
        return $yRrbE;
        goto U0b02;
        U0b02:
        BUB73:
        goto Eyf79;
        Eyf79:
        return null;
        goto OMWHi;
        OMWHi:
    }
    public function height() : ?int
    {
        goto cXypw;
        cXypw:
        $aQb9L = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto JSuWT;
        yAFfQ:
        return $aQb9L;
        goto HNPWe;
        FJY2I:
        return null;
        goto bRWp5;
        JSuWT:
        if (!$aQb9L) {
            goto dZF0H;
        }
        goto yAFfQ;
        HNPWe:
        dZF0H:
        goto FJY2I;
        bRWp5:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($hgsqV) {
            goto HH9u2;
            HVM3b:
            NSOdp:
            goto PdZm6;
            d14x7:
            s3Ya3:
            goto E1fhi;
            E1fhi:
            if (!($dzJV2['thumbnail'] || $dzJV2['hls_path'])) {
                goto NSOdp;
            }
            goto JEJLo;
            xsSvS:
            return;
            goto d14x7;
            CH2Ni:
            if (!(!array_key_exists('thumbnail', $dzJV2) && !array_key_exists('hls_path', $dzJV2))) {
                goto s3Ya3;
            }
            goto xsSvS;
            JEJLo:
            WI5WSPGRr1b2t::where('parent_id', $hgsqV->getAttribute('id'))->update(['thumbnail' => $hgsqV->getAttributes()['thumbnail'], 'hls_path' => $hgsqV->getAttributes()['hls_path']]);
            goto HVM3b;
            HH9u2:
            $dzJV2 = $hgsqV->getDirty();
            goto CH2Ni;
            PdZm6:
        });
    }
    public function mxim8FSg7TY()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mHFXPjQ1zIf()
    {
        return $this->getAttribute('id');
    }
    public function mrBzZlfZZRk() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto PR_dr;
        DVRKa:
        $RKt3t = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $j1FXT->resolvePath($this, $this->getAttribute('driver'))];
        goto U05Ug;
        PR_dr:
        $j1FXT = app(SRErb8bXZXjuL::class);
        goto DVRKa;
        vb4xP:
        QUzbe:
        goto APUm8;
        toSil:
        goto rxTZW;
        goto vb4xP;
        T1oGO:
        $RKt3t['player_url'] = $j1FXT->resolvePath($this, $this->getAttribute('driver'));
        goto toSil;
        VqcXZ:
        return $RKt3t;
        goto AHpYb;
        sD4xy:
        $RKt3t['thumbnail'] = $j1FXT->resolveThumbnail($this);
        goto VqcXZ;
        G67vG:
        rxTZW:
        goto sD4xy;
        APUm8:
        $RKt3t['player_url'] = $j1FXT->resolvePathForHlsVideo($this, true);
        goto G67vG;
        U05Ug:
        if ($this->getAttribute('hls_path')) {
            goto QUzbe;
        }
        goto T1oGO;
        AHpYb:
    }
    public function getThumbnails()
    {
        goto ve6Kc;
        ve6Kc:
        $ito40 = $this->getAttribute('generated_previews') ?? [];
        goto GY5Un;
        GY5Un:
        $j1FXT = app(SRErb8bXZXjuL::class);
        goto l1LkO;
        l1LkO:
        return array_map(function ($NHlhh) use($j1FXT) {
            return $j1FXT->resolvePath($NHlhh);
        }, $ito40);
        goto yPh7z;
        yPh7z:
    }
    public static function mQQw5D1SVlK(NCmZ7rMVMWyvC $ldT2t) : WI5WSPGRr1b2t
    {
        goto vCmXr;
        iEkFI:
        return (new WI5WSPGRr1b2t())->fill($ldT2t->getAttributes());
        goto fSo4G;
        TpVzg:
        AED8h:
        goto iEkFI;
        c4eZR:
        return $ldT2t;
        goto TpVzg;
        vCmXr:
        if (!$ldT2t instanceof WI5WSPGRr1b2t) {
            goto AED8h;
        }
        goto c4eZR;
        fSo4G:
    }
}
