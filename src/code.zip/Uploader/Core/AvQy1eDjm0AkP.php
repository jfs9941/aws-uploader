<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Contracts\XuIaPR4PMryqL;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\Traits\Kbu3Shr02PNph;
use Jfs\Uploader\Core\Traits\VOrYIv3AwrFzm;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Service\XHXjudWRHC4fj;
class AvQy1eDjm0AkP extends Fd8NTWwq2cQOc implements BbauDy0pIbj64
{
    use Kbu3Shr02PNph;
    use VOrYIv3AwrFzm;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $LtmUC, string $QVNFV) : self
    {
        goto jV3u2;
        jHxQ4:
        return $DcHwR;
        goto SfebA;
        jV3u2:
        $DcHwR = new self(['id' => $LtmUC, 'type' => $QVNFV, 'status' => MUu80sOhINyO3::UPLOADING]);
        goto QVFKZ;
        QVFKZ:
        $DcHwR->m36TLWxcxjb(MUu80sOhINyO3::UPLOADING);
        goto jHxQ4;
        SfebA:
    }
    public function getView() : array
    {
        $IXZSx = app(XuIaPR4PMryqL::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $IXZSx->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $IXZSx->resolveThumbnail($this)];
    }
    public static function mNjCFnOHEn6(Fd8NTWwq2cQOc $ufjgt) : AvQy1eDjm0AkP
    {
        goto cYMIm;
        sBIAM:
        return $ufjgt;
        goto NzRmx;
        cYMIm:
        if (!$ufjgt instanceof AvQy1eDjm0AkP) {
            goto jJ0o8;
        }
        goto sBIAM;
        NzRmx:
        jJ0o8:
        goto TdKX2;
        TdKX2:
        return (new AvQy1eDjm0AkP())->fill($ufjgt->getAttributes());
        goto tsIHS;
        tsIHS:
    }
}
