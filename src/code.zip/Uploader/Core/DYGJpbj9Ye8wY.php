<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
abstract  class DYGJpbj9Ye8wY extends Model implements DNmcAdktLJtqn
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mMwN9dtRMhA() : bool
    {
        goto RbSqd;
        dqEVB:
        FsNYK:
        goto PXGBJ;
        dS3G8:
        return true;
        goto dqEVB;
        PXGBJ:
        return !$this->m84Wx8GAAMe();
        goto M4kIC;
        RbSqd:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto FsNYK;
        }
        goto dS3G8;
        M4kIC:
    }
    protected function m84Wx8GAAMe() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
