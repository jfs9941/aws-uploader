<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Illuminate\Database\Eloquent\Model;
abstract  class Z3KXO9qO3sUsa extends Model implements A7djqU0sacoRX
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function moOr97WSwAF() : bool
    {
        goto kYoqQ;
        kYoqQ:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto oAF0d;
        }
        goto APS4M;
        PSiEF:
        return !$this->mCzXEXj8BT0();
        goto vXLZ7;
        fotCj:
        oAF0d:
        goto PSiEF;
        APS4M:
        return true;
        goto fotCj;
        vXLZ7:
    }
    protected function mCzXEXj8BT0() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
