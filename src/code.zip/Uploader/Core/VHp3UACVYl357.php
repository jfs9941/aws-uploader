<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Contracts\O79PdR1cao6Xq;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\Traits\VexK8QON1Q211;
use Jfs\Uploader\Core\Traits\UPnDsKOL0mchi;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
class VHp3UACVYl357 extends OXsaQ69LP2fiA implements CxOTyXYpS0zWZ
{
    use VexK8QON1Q211;
    use UPnDsKOL0mchi;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $ixMzz, string $ydbmO) : self
    {
        goto uZTlw;
        uZTlw:
        $bKijV = new self(['id' => $ixMzz, 'type' => $ydbmO, 'status' => LlMDscQw21XKp::UPLOADING]);
        goto GGQba;
        Sb29p:
        return $bKijV;
        goto rh3j3;
        GGQba:
        $bKijV->m92yZMBK6RM(LlMDscQw21XKp::UPLOADING);
        goto Sb29p;
        rh3j3:
    }
    public function width() : ?int
    {
        goto QMBHB;
        nET7y:
        if (!$Un71V) {
            goto sazQT;
        }
        goto WocDO;
        WocDO:
        return $Un71V;
        goto OYIGS;
        ew9Jz:
        return null;
        goto cu0Sm;
        OYIGS:
        sazQT:
        goto ew9Jz;
        QMBHB:
        $Un71V = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto nET7y;
        cu0Sm:
    }
    public function height() : ?int
    {
        goto ICkPc;
        bZ5pS:
        if (!$aHbCv) {
            goto aJXkI;
        }
        goto HroLP;
        HroLP:
        return $aHbCv;
        goto XTGq4;
        XTGq4:
        aJXkI:
        goto mICaP;
        mICaP:
        return null;
        goto buh2j;
        ICkPc:
        $aHbCv = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto bZ5pS;
        buh2j:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($bKijV) {
            goto iEZ9R;
            CaQwL:
            if (!($IMHV0['thumbnail'] || $IMHV0['hls_path'])) {
                goto HJqSi;
            }
            goto hfpcF;
            eGAWR:
            wqawZ:
            goto CaQwL;
            FaXCf:
            return;
            goto eGAWR;
            Njae5:
            HJqSi:
            goto LHKz2;
            YWoBn:
            if (!(!array_key_exists('thumbnail', $IMHV0) && !array_key_exists('hls_path', $IMHV0))) {
                goto wqawZ;
            }
            goto FaXCf;
            hfpcF:
            VHp3UACVYl357::where('parent_id', $bKijV->getAttribute('id'))->update(['thumbnail' => $bKijV->getAttributes()['thumbnail'], 'hls_path' => $bKijV->getAttributes()['hls_path']]);
            goto Njae5;
            iEZ9R:
            $IMHV0 = $bKijV->getDirty();
            goto YWoBn;
            LHKz2:
        });
    }
    public function mSApFb9qzUu()
    {
        return $this->getAttribute('thumbnail');
    }
    public function m9KtVxFGivA()
    {
        return $this->getAttribute('id');
    }
    public function m4QVUgAQsLB() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto Fyl6K;
        SK0zQ:
        $nv2Qs['player_url'] = $q7czo->resolvePath($this, $this->getAttribute('driver'));
        goto rr6CR;
        nUf1N:
        return $nv2Qs;
        goto ENccE;
        DrqaT:
        $nv2Qs = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $q7czo->resolvePath($this, $this->getAttribute('driver'))];
        goto xgoZ0;
        xgoZ0:
        if ($this->getAttribute('hls_path')) {
            goto kbEYv;
        }
        goto SK0zQ;
        awVeQ:
        kbEYv:
        goto P1uMs;
        Fyl6K:
        $q7czo = app(O79PdR1cao6Xq::class);
        goto DrqaT;
        P1uMs:
        $nv2Qs['player_url'] = $q7czo->resolvePathForHlsVideo($this, true);
        goto mHld4;
        mHld4:
        wCBZc:
        goto VgPW8;
        rr6CR:
        goto wCBZc;
        goto awVeQ;
        VgPW8:
        $nv2Qs['thumbnail'] = $q7czo->resolveThumbnail($this);
        goto nUf1N;
        ENccE:
    }
    public function getThumbnails()
    {
        goto cWnYe;
        CiDqb:
        $q7czo = app(O79PdR1cao6Xq::class);
        goto MljpD;
        MljpD:
        return array_map(function ($w6RVC) use($q7czo) {
            return $q7czo->resolvePath($w6RVC);
        }, $Y7Wv4);
        goto LhyT8;
        cWnYe:
        $Y7Wv4 = $this->getAttribute('generated_previews') ?? [];
        goto CiDqb;
        LhyT8:
    }
    public static function mYtxpnyXtwE(OXsaQ69LP2fiA $L7rEe) : VHp3UACVYl357
    {
        goto KerDt;
        NL1Zn:
        return (new VHp3UACVYl357())->fill($L7rEe->getAttributes());
        goto kJHKU;
        KerDt:
        if (!$L7rEe instanceof VHp3UACVYl357) {
            goto sdYoS;
        }
        goto KEdps;
        KEdps:
        return $L7rEe;
        goto AmgjN;
        AmgjN:
        sdYoS:
        goto NL1Zn;
        kJHKU:
    }
}
