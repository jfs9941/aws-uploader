<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Contracts\GN9q1LiHnFGKa;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Traits\L5mR6rHm99iIZ;
use Jfs\Uploader\Core\Traits\G5NBCB8i1Emes;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Service\P4kAqVwxHUI1r;
class Vt3ybt0yfaPAa extends UXdXfw71iQGkx implements RsTEqK0aKnthE
{
    use L5mR6rHm99iIZ;
    use G5NBCB8i1Emes;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $r7rVx, string $NTkTt) : self
    {
        goto LZ0_L;
        LZ0_L:
        $xixtT = new self(['id' => $r7rVx, 'type' => $NTkTt, 'status' => HGmeWpZQSxAlO::UPLOADING]);
        goto KoAri;
        FnwD9:
        return $xixtT;
        goto TTRMr;
        KoAri:
        $xixtT->mf3bcS2aSK5(HGmeWpZQSxAlO::UPLOADING);
        goto FnwD9;
        TTRMr:
    }
    public function getView() : array
    {
        $qqQzb = app(GN9q1LiHnFGKa::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $qqQzb->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $qqQzb->resolveThumbnail($this)];
    }
    public static function m9PoKybUPwn(UXdXfw71iQGkx $xlFVb) : Vt3ybt0yfaPAa
    {
        goto pcxI7;
        wcoUi:
        return (new Vt3ybt0yfaPAa())->fill($xlFVb->getAttributes());
        goto GrG8a;
        pcxI7:
        if (!$xlFVb instanceof Vt3ybt0yfaPAa) {
            goto kf_BA;
        }
        goto mZhMX;
        Ts0Jb:
        kf_BA:
        goto wcoUi;
        mZhMX:
        return $xlFVb;
        goto Ts0Jb;
        GrG8a:
    }
}
