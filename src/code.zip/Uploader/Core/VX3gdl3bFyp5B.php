<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Core\Observer\UNF5MvN3LQxmL;
use Jfs\Uploader\Core\Traits\VUrTlGWzeEM4U;
use Jfs\Uploader\Core\Traits\MMUGtmaorqREX;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Exception\J0z9iIrDgeD3q;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Jfs\Uploader\Exception\LlZ7jHsX0xmpK;
use Jfs\Uploader\Service\SPtrbk9kcnPEI;
final class VX3gdl3bFyp5B implements SK7fSNbDSRmCO
{
    use VUrTlGWzeEM4U;
    use MMUGtmaorqREX;
    private $VT9jU;
    private function __construct($a3XOL, $mFX9i)
    {
        $this->cyroT = $a3XOL;
        $this->lkNB_ = $mFX9i;
    }
    private function mgqZbEuV0eb(string $A745z, $mFX9i, $ExTI3, bool $prWS8 = false) : void
    {
        $this->mqyYIlRyjYD(new UNF5MvN3LQxmL($this, $mFX9i, $ExTI3, $A745z, $prWS8));
    }
    public function getFile()
    {
        return $this->cyroT;
    }
    public function mUEr22m4NIs(array $lWakL) : void
    {
        $this->VT9jU = $lWakL;
    }
    public function mOO2hGx6WBJ() : void
    {
        $this->mGQfJhYWpvR(RwOJkCXwa9RQz::UPLOADING);
    }
    public function mgJpdXKB3Xn() : void
    {
        $this->mGQfJhYWpvR(RwOJkCXwa9RQz::UPLOADED);
    }
    public function mGzGyHD99FA() : void
    {
        $this->mGQfJhYWpvR(RwOJkCXwa9RQz::PROCESSING);
    }
    public function mZMcj35DCr3() : void
    {
        $this->mGQfJhYWpvR(RwOJkCXwa9RQz::FINISHED);
    }
    public function mPg3VUD81kn() : void
    {
        $this->mGQfJhYWpvR(RwOJkCXwa9RQz::ABORTED);
    }
    public function mx7V80CwNdJ() : array
    {
        return $this->VT9jU;
    }
    public static function mLpgBe5q0Rd(string $y06DH, $rvBRi, $agzKA, $A745z) : self
    {
        goto jUCO0;
        k4evZ:
        return $KHpOt->m1umlScsOL0();
        goto KVXO3;
        k9Lx2:
        $KHpOt->m3zp1EoQeXc(RwOJkCXwa9RQz::UPLOADING);
        goto k4evZ;
        LjRZo:
        $KHpOt = new self($a3XOL, $rvBRi);
        goto bf209;
        bf209:
        $KHpOt->mgqZbEuV0eb($A745z, $rvBRi, $agzKA);
        goto k9Lx2;
        jUCO0:
        $a3XOL = App::make(SPtrbk9kcnPEI::class)->mdMn4oMULx2(Ex01fdHOlxlg8::mSfRKa26lA7($y06DH));
        goto LjRZo;
        KVXO3:
    }
    public static function mkQV9Hcse0B($a3XOL, $mFX9i, $ExTI3, $A745z, $prWS8 = false) : self
    {
        goto fUNZ4;
        fUNZ4:
        $KHpOt = new self($a3XOL, $mFX9i);
        goto XLYRq;
        cIpZ0:
        $KHpOt->m3zp1EoQeXc(RwOJkCXwa9RQz::UPLOADING);
        goto CrkXC;
        XLYRq:
        $KHpOt->mgqZbEuV0eb($A745z, $mFX9i, $ExTI3, $prWS8);
        goto cIpZ0;
        CrkXC:
        return $KHpOt;
        goto eYIhV;
        eYIhV:
    }
}
