<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Contracts\VwiVLFCuZN4fA;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\Traits\NYTKsbVPARY8x;
use Jfs\Uploader\Core\Traits\V5MfgbTUETSZ1;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Service\M9fyBFwLMDM67;
class EqLr3PLlMLHwV extends D3Q3lppZQonk9 implements ZEs3XZLglwgUu
{
    use NYTKsbVPARY8x;
    use V5MfgbTUETSZ1;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $sAFP4, string $geXNd) : self
    {
        goto w1g62;
        w1g62:
        $hKvCq = new self(['id' => $sAFP4, 'type' => $geXNd, 'status' => ZVJoOgH14iXBq::UPLOADING]);
        goto a01rh;
        MtMbl:
        return $hKvCq;
        goto b7xwT;
        a01rh:
        $hKvCq->mWCCmTIigqB(ZVJoOgH14iXBq::UPLOADING);
        goto MtMbl;
        b7xwT:
    }
    public function getView() : array
    {
        $RXqJj = app(VwiVLFCuZN4fA::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $RXqJj->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $RXqJj->resolveThumbnail($this)];
    }
    public static function myKiZABVUDf(D3Q3lppZQonk9 $mA8Ck) : EqLr3PLlMLHwV
    {
        goto vEo2t;
        vEo2t:
        if (!$mA8Ck instanceof EqLr3PLlMLHwV) {
            goto ooA87;
        }
        goto sxUUq;
        R163X:
        return (new EqLr3PLlMLHwV())->fill($mA8Ck->getAttributes());
        goto JlAM0;
        xe4bR:
        ooA87:
        goto R163X;
        sxUUq:
        return $mA8Ck;
        goto xe4bR;
        JlAM0:
    }
}
