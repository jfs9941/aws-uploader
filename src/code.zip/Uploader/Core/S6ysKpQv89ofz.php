<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
final class S6ysKpQv89ofz
{
    public $filename;
    public $LZRFL;
    public $wl2h6;
    public $ovxJB;
    public $O_GCc;
    public $NUHaj;
    public $fGqNh;
    public $status;
    public $umWbM;
    public $UUwpG;
    public $driver = 's3';
    public $rFNTA = [];
    public function __construct($XE7Cw, $yuhEU, $Hnn2Z, $QjEjF, $Uz2J3, $ZbwDh, $zb319, $fGGPI, $WBtzJ, $RsQzi, $WCiFa = 's3', $jOnpR = [])
    {
        goto bRAXC;
        UI0oh:
        $this->NUHaj = $ZbwDh;
        goto avibm;
        JxTDb:
        $this->UUwpG = $RsQzi;
        goto y40KV;
        Scg27:
        $this->umWbM = $WBtzJ;
        goto JxTDb;
        kXojX:
        $this->rFNTA = $jOnpR;
        goto FGfSX;
        zQ825:
        $this->ovxJB = $QjEjF;
        goto FEkk2;
        y9rOk:
        $this->status = $fGGPI;
        goto Scg27;
        FEkk2:
        $this->O_GCc = $Uz2J3;
        goto UI0oh;
        cc48V:
        $this->wl2h6 = $Hnn2Z;
        goto zQ825;
        bRAXC:
        $this->filename = $XE7Cw;
        goto btaax;
        avibm:
        $this->fGqNh = $zb319;
        goto y9rOk;
        btaax:
        $this->LZRFL = $yuhEU;
        goto cc48V;
        y40KV:
        $this->driver = $WCiFa;
        goto kXojX;
        FGfSX:
    }
    private static function mD10g15bTqE() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mxUadzdnAAQ() : array
    {
        return array_flip(self::mD10g15bTqE());
    }
    public function toArray() : array
    {
        $mmlG2 = self::mD10g15bTqE();
        return [$mmlG2['filename'] => $this->filename, $mmlG2['fileExtension'] => $this->LZRFL, $mmlG2['mimeType'] => $this->wl2h6, $mmlG2['fileSize'] => $this->ovxJB, $mmlG2['chunkSize'] => $this->O_GCc, $mmlG2['checksums'] => $this->NUHaj, $mmlG2['totalChunk'] => $this->fGqNh, $mmlG2['status'] => $this->status, $mmlG2['userId'] => $this->umWbM, $mmlG2['uploadId'] => $this->UUwpG, $mmlG2['driver'] => $this->driver, $mmlG2['parts'] => $this->rFNTA];
    }
    public static function mAWFJTfrz4l(array $F44Ct) : self
    {
        $Lw__t = array_flip(self::mxUadzdnAAQ());
        return new self($F44Ct[$Lw__t['filename']] ?? $F44Ct['filename'] ?? '', $F44Ct[$Lw__t['fileExtension']] ?? $F44Ct['fileExtension'] ?? '', $F44Ct[$Lw__t['mimeType']] ?? $F44Ct['mimeType'] ?? '', $F44Ct[$Lw__t['fileSize']] ?? $F44Ct['fileSize'] ?? 0, $F44Ct[$Lw__t['chunkSize']] ?? $F44Ct['chunkSize'] ?? 0, $F44Ct[$Lw__t['checksums']] ?? $F44Ct['checksums'] ?? [], $F44Ct[$Lw__t['totalChunk']] ?? $F44Ct['totalChunk'] ?? 0, $F44Ct[$Lw__t['status']] ?? $F44Ct['status'] ?? 0, $F44Ct[$Lw__t['userId']] ?? $F44Ct['userId'] ?? 0, $F44Ct[$Lw__t['uploadId']] ?? $F44Ct['uploadId'] ?? '', $F44Ct[$Lw__t['driver']] ?? $F44Ct['driver'] ?? 's3', $F44Ct[$Lw__t['parts']] ?? $F44Ct['parts'] ?? []);
    }
    public static function m5UeYs1KdsH($mB35u) : self
    {
        goto dC0Tu;
        wy_Av:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto NzA3n;
        VWvd_:
        return self::mAWFJTfrz4l($mB35u);
        goto yB1wz;
        yB1wz:
        iP8II:
        goto wy_Av;
        dC0Tu:
        if (!(isset($mB35u['fn']) || isset($mB35u['fe']))) {
            goto iP8II;
        }
        goto VWvd_;
        NzA3n:
    }
    public function muRlIJMM2ro(string $RsQzi) : void
    {
        $this->UUwpG = $RsQzi;
    }
    public function mzTDXTOmD3o(array $jOnpR) : void
    {
        $this->rFNTA = $jOnpR;
    }
    public static function mZQ1mhapiPb($VslFR, $EeQqP, $cEc93, $WBtzJ, $Uz2J3, $ZbwDh, $WCiFa)
    {
        return new self($VslFR->getFilename(), $VslFR->getExtension(), $EeQqP, $cEc93, $Uz2J3, $ZbwDh, count($ZbwDh), T93Mcsw1gA3an::UPLOADING, $WBtzJ, 0, $WCiFa, []);
    }
    public static function mttkCSEeOLf($hOWbX)
    {
        return 'metadata/' . $hOWbX . '.json';
    }
    public function m8OHhB52nVI()
    {
        return 's3' === $this->driver ? NZ0k4EM0XOGE7::S3 : NZ0k4EM0XOGE7::LOCAL;
    }
}
