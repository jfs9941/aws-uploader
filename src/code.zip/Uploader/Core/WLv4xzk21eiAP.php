<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Contracts\GuNvSDjrDhnZX;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\Traits\Rr9MHzXLd8EvR;
use Jfs\Uploader\Core\Traits\XGoBOvpn4TlTz;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Service\LNm3X2KAsSELE;
class WLv4xzk21eiAP extends KFe2ZCctciwsA implements GCZ2vyVNpj70n
{
    use Rr9MHzXLd8EvR;
    use XGoBOvpn4TlTz;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $VfJ3M, string $xY26M) : self
    {
        goto KV8GJ;
        tm7K9:
        return $K_Wq0;
        goto z6YET;
        tpq0j:
        $K_Wq0->mlS5irobHNA(EpMPhiTVzNYqA::UPLOADING);
        goto tm7K9;
        KV8GJ:
        $K_Wq0 = new self(['id' => $VfJ3M, 'type' => $xY26M, 'status' => EpMPhiTVzNYqA::UPLOADING]);
        goto tpq0j;
        z6YET:
    }
    public function getView() : array
    {
        $rEnse = app(GuNvSDjrDhnZX::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $rEnse->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $rEnse->resolveThumbnail($this)];
    }
    public static function mm7gGMh6HSD(KFe2ZCctciwsA $Hz32I) : WLv4xzk21eiAP
    {
        goto WcisF;
        fPEi0:
        FEWIQ:
        goto d6Lcc;
        WcisF:
        if (!$Hz32I instanceof WLv4xzk21eiAP) {
            goto FEWIQ;
        }
        goto QxDhX;
        d6Lcc:
        return (new WLv4xzk21eiAP())->fill($Hz32I->getAttributes());
        goto bBHFp;
        QxDhX:
        return $Hz32I;
        goto fPEi0;
        bBHFp:
    }
}
