<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Illuminate\Database\Eloquent\Model;
abstract  class ZZfsW9KHWsMrx extends Model implements WEJt1TL92SawT
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mzKIDvWQfgP() : bool
    {
        goto GKvoD;
        GKvoD:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto Xuup9;
        }
        goto mIWS6;
        n52on:
        Xuup9:
        goto N6qex;
        N6qex:
        return !$this->mu3S692JShI();
        goto vteZl;
        mIWS6:
        return true;
        goto n52on;
        vteZl:
    }
    protected function mu3S692JShI() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
