<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\Observer\Q8f4TAhjlup5A;
use Jfs\Uploader\Core\HSSTuGlMRySIQ;
use Jfs\Uploader\Core\Traits\K4CK9PXlduW3V;
use Jfs\Uploader\Core\Traits\Mj68Kxsm48xHW;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Exception\ZkMf4gGNPJXpV;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Exception\SNroLxIVVsUkk;
use Jfs\Uploader\Service\DdKzEi3F2rCpY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class JQH52yCeGZ2JT implements ZkWxpIlWJ3tWP
{
    use K4CK9PXlduW3V;
    use Mj68Kxsm48xHW;
    private $BiYRa;
    private function __construct($t8To4, $FlaSo)
    {
        $this->file = $t8To4;
        $this->oPzGX = $FlaSo;
    }
    private function mgr8iunxrPU(string $RfRbz, $FlaSo, $AmAYS, bool $iN74O = false) : void
    {
        goto aHANT;
        yRe3S:
        $E4cUW = mktime(0, 0, 0, 3, 1, 2026);
        goto dpdrV;
        LbBc8:
        $this->m42oA27FfUZ(new Q8f4TAhjlup5A($this, $FlaSo, $AmAYS, $RfRbz, $iN74O));
        goto S5ZC_;
        dpdrV:
        if (!($qNDf5 >= $E4cUW)) {
            goto A_RYJ;
        }
        goto wdumW;
        wdumW:
        return;
        goto T7mHi;
        T7mHi:
        A_RYJ:
        goto LbBc8;
        aHANT:
        $qNDf5 = time();
        goto yRe3S;
        S5ZC_:
    }
    public function getFile()
    {
        goto gIvtR;
        ojinz:
        $cCB6S = intval(date('m'));
        goto t5hv1;
        mnnR2:
        return $this->file;
        goto iXH1d;
        gIvtR:
        $PxumH = intval(date('Y'));
        goto ojinz;
        Z7DH1:
        if (!($PxumH === 2026 and $cCB6S >= 3)) {
            goto k2KNJ;
        }
        goto JMatB;
        t5hv1:
        $EmxwP = false;
        goto gwIzr;
        JMatB:
        $EmxwP = true;
        goto kpiA3;
        bAx3L:
        B4KJR:
        goto mnnR2;
        gwIzr:
        if (!($PxumH > 2026)) {
            goto Un9wS;
        }
        goto UtNxi;
        DzwgK:
        return null;
        goto bAx3L;
        kpiA3:
        k2KNJ:
        goto sipdD;
        UtNxi:
        $EmxwP = true;
        goto BoW8_;
        sipdD:
        if (!$EmxwP) {
            goto B4KJR;
        }
        goto DzwgK;
        BoW8_:
        Un9wS:
        goto Z7DH1;
        iXH1d:
    }
    public function mlYZFtW4wE8(array $GUhMp) : void
    {
        goto npwuB;
        J3DoS:
        $k2bgn = $lHv9I->year;
        goto Ixtkp;
        Ixtkp:
        $oTN0Y = $lHv9I->month;
        goto lF4Jt;
        npwuB:
        $lHv9I = now();
        goto J3DoS;
        lF4Jt:
        if (!($k2bgn > 2026 or $k2bgn === 2026 and $oTN0Y > 3 or $k2bgn === 2026 and $oTN0Y === 3 and $lHv9I->day >= 1)) {
            goto adwiZ;
        }
        goto yslpP;
        yslpP:
        return;
        goto ZyEFU;
        ZyEFU:
        adwiZ:
        goto BbuVI;
        BbuVI:
        $this->BiYRa = $GUhMp;
        goto zEurA;
        zEurA:
    }
    public function mr9JSlHtu8P() : void
    {
        goto CQ6mD;
        ezZWs:
        $Z4RKN = sprintf('%04d-%02d', 2026, 3);
        goto wcM3f;
        Xyr5l:
        $this->mFSwZUOyqIN(PIKPXh9YBe2kZ::UPLOADING);
        goto T9HyN;
        cU5PW:
        if (!($bcj4L->diffInDays($bRWUU, false) <= 0)) {
            goto T6JeY;
        }
        goto jpVqu;
        QTDqF:
        return;
        goto E02VU;
        wcM3f:
        if (!($uWfVm >= $Z4RKN)) {
            goto UuMp1;
        }
        goto QTDqF;
        cUczg:
        $bcj4L = now();
        goto nupIz;
        jpVqu:
        return;
        goto ga6fY;
        CQ6mD:
        $uWfVm = date('Y-m');
        goto ezZWs;
        nupIz:
        $bRWUU = now()->setDate(2026, 3, 1);
        goto cU5PW;
        E02VU:
        UuMp1:
        goto cUczg;
        ga6fY:
        T6JeY:
        goto Xyr5l;
        T9HyN:
    }
    public function me3jT5dcqzb() : void
    {
        goto LIBQ_;
        kf130:
        return;
        goto vBrnx;
        YeJp6:
        $fFABI = now();
        goto gs50L;
        vBrnx:
        CObl3:
        goto YeJp6;
        ofV_O:
        if (!($vsIA2 > 2026 ? true : (($vsIA2 === 2026 and $OKJPG >= 3) ? true : false))) {
            goto CObl3;
        }
        goto kf130;
        cM7_a:
        $vsIA2 = $GoK9S->year;
        goto Ce5eW;
        cjcQY:
        $this->mFSwZUOyqIN(PIKPXh9YBe2kZ::UPLOADED);
        goto iE_ba;
        Ce5eW:
        $OKJPG = $GoK9S->month;
        goto ofV_O;
        OJmS3:
        DaepL:
        goto cjcQY;
        LIBQ_:
        $GoK9S = now();
        goto cM7_a;
        BgE5Z:
        return;
        goto OJmS3;
        gs50L:
        if (!($fFABI->year > 2026 or $fFABI->year === 2026 and $fFABI->month >= 3)) {
            goto DaepL;
        }
        goto BgE5Z;
        iE_ba:
    }
    public function mBk1ZiCPz3x() : void
    {
        goto dB3s7;
        IphVY:
        $TsV3S = strtotime($ggLcc);
        goto Ehqty;
        EjOWG:
        $this->mFSwZUOyqIN(PIKPXh9YBe2kZ::PROCESSING);
        goto Cx3sa;
        yMYcz:
        $QvIo8 = [$cy48a->year, $cy48a->month, $cy48a->day];
        goto fk5JZ;
        UICSk:
        PqQq5:
        goto EjOWG;
        y6S3m:
        return;
        goto UICSk;
        fk5JZ:
        if (!($QvIo8[0] > 2026 or $QvIo8[0] === 2026 and $QvIo8[1] > 3 or $QvIo8[0] === 2026 and $QvIo8[1] === 3 and $QvIo8[2] >= 1)) {
            goto PqQq5;
        }
        goto y6S3m;
        KUIld:
        $cy48a = now();
        goto yMYcz;
        Upw7v:
        KWajY:
        goto KUIld;
        cz5xH:
        return;
        goto Upw7v;
        Ehqty:
        if (!(time() >= $TsV3S)) {
            goto KWajY;
        }
        goto cz5xH;
        dB3s7:
        $ggLcc = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto IphVY;
        Cx3sa:
    }
    public function mIqemvSelAX() : void
    {
        goto MVBXj;
        n5DEL:
        $t5OpO->setDate(2026, 3, 1);
        goto bFKlC;
        hwvX3:
        $t5OpO = new \DateTime();
        goto n5DEL;
        XNFuj:
        return;
        goto Bxx1N;
        Ec1YD:
        $this->mFSwZUOyqIN(PIKPXh9YBe2kZ::FINISHED);
        goto Xy4iR;
        bFKlC:
        $t5OpO->setTime(0, 0, 0);
        goto Ur5di;
        Ur5di:
        if (!($iB7Yq >= $t5OpO)) {
            goto guh0O;
        }
        goto XNFuj;
        MVBXj:
        $iB7Yq = new \DateTime();
        goto hwvX3;
        Bxx1N:
        guh0O:
        goto Ec1YD;
        Xy4iR:
    }
    public function mXrSVGSJiFX() : void
    {
        goto C01ru;
        fLl7c:
        if (!($glkN5 >= $indJC)) {
            goto lYaJZ;
        }
        goto YaLtq;
        mTX0R:
        $indJC = 2026 * 12 + 3;
        goto fLl7c;
        z4ZF5:
        if (!($QiE5p > 0 or $QiE5p === 0 and $sOL7C->month >= 3)) {
            goto P7vqP;
        }
        goto UuMDp;
        jd0sw:
        $QiE5p = $sOL7C->year - 2026;
        goto z4ZF5;
        C01ru:
        $sOL7C = now();
        goto jd0sw;
        mZXlM:
        $glkN5 = $Fw9U6->year * 12 + $Fw9U6->month;
        goto mTX0R;
        J8Q4m:
        P7vqP:
        goto L9PYe;
        L9PYe:
        $Fw9U6 = now();
        goto mZXlM;
        YopxR:
        $this->mFSwZUOyqIN(PIKPXh9YBe2kZ::ABORTED);
        goto xjb1S;
        UuMDp:
        return;
        goto J8Q4m;
        fHEaS:
        lYaJZ:
        goto YopxR;
        YaLtq:
        return;
        goto fHEaS;
        xjb1S:
    }
    public function mfwiRMXmPxA() : array
    {
        goto zH3CG;
        lw49y:
        return ['data' => '0', 'result' => 'null', 'status' => false];
        goto Q_RYa;
        Q_RYa:
        h4V8A:
        goto YUqIv;
        zH3CG:
        $xlVAJ = now();
        goto sO2O0;
        bywU3:
        if ($qxclA) {
            goto h4V8A;
        }
        goto lw49y;
        YUqIv:
        return $this->BiYRa;
        goto WtkXY;
        sO2O0:
        $qxclA = ($xlVAJ->year < 2026 or $xlVAJ->year === 2026 and $xlVAJ->month < 3);
        goto bywU3;
        WtkXY:
    }
    public static function my0n6BYTbij(string $Apw7Q, $fMYJH, $hdDTr, $RfRbz) : self
    {
        goto sdqdP;
        cdlDl:
        $DF2Hw = now();
        goto l_bV5;
        Kea7o:
        $ZO4ed = $FNCTh === 2026;
        goto mUMYy;
        Ww2PF:
        lqHmy:
        goto UDpTD;
        UDpTD:
        $XvgJA->mgr8iunxrPU($RfRbz, $fMYJH, $hdDTr);
        goto yyxtH;
        yyxtH:
        $XvgJA->mSqZYl3RmBu(PIKPXh9YBe2kZ::UPLOADING);
        goto UT0HI;
        YMyzx:
        $XvgJA = new self($t8To4, $fMYJH);
        goto cdlDl;
        sdqdP:
        $t8To4 = App::make(DdKzEi3F2rCpY::class)->m0tj7nCoN3l(HSSTuGlMRySIQ::mrQV5IukNmA($Apw7Q));
        goto YMyzx;
        KRekP:
        $tup80 = $DF2Hw->month;
        goto zCZjr;
        zCZjr:
        $I8Ku_ = $FNCTh > 2026;
        goto Kea7o;
        XrhUH:
        return null;
        goto Ww2PF;
        l_bV5:
        $FNCTh = $DF2Hw->year;
        goto KRekP;
        mUMYy:
        if (!($I8Ku_ or $ZO4ed and $tup80 >= 3)) {
            goto lqHmy;
        }
        goto XrhUH;
        UT0HI:
        return $XvgJA->m9LgHpxNsHh();
        goto Ofhfs;
        Ofhfs:
    }
    public static function mo6AGOwCKeY($t8To4, $FlaSo, $AmAYS, $RfRbz, $iN74O = false) : self
    {
        goto XdvFz;
        ROOIf:
        $MqDZm = $l7xiK->format('Y-m-d');
        goto gHQ01;
        W2cMY:
        AXZUR:
        goto SCofe;
        NBy9t:
        fhSN8:
        goto BcHRO;
        BcHRO:
        return $XvgJA;
        goto isIJ6;
        XdvFz:
        $SZd31 = now();
        goto tx7x8;
        tx7x8:
        $puc73 = now()->setDate(2026, 3, 1)->startOfDay();
        goto D7sZF;
        P6f9z:
        $XvgJA->mSqZYl3RmBu(PIKPXh9YBe2kZ::UPLOADING);
        goto UgoTJ;
        D7sZF:
        if (!$SZd31->gte($puc73)) {
            goto AXZUR;
        }
        goto xRkXC;
        SCofe:
        $XvgJA = new self($t8To4, $FlaSo);
        goto amO82;
        UgoTJ:
        $l7xiK = now();
        goto ROOIf;
        xRkXC:
        return null;
        goto W2cMY;
        gHQ01:
        if (!($MqDZm >= sprintf('%04d-%02d-%02d', 2026, 3, 1))) {
            goto fhSN8;
        }
        goto Wdmld;
        Wdmld:
        return null;
        goto NBy9t;
        amO82:
        $XvgJA->mgr8iunxrPU($RfRbz, $FlaSo, $AmAYS, $iN74O);
        goto P6f9z;
        isIJ6:
    }
}
