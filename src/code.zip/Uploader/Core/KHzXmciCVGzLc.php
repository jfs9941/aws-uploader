<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
final class KHzXmciCVGzLc
{
    public $filename;
    public $kkcKh;
    public $mOR3k;
    public $QZ4DW;
    public $DKPYI;
    public $wgHxn;
    public $h134J;
    public $status;
    public $BRBES;
    public $xc0J5;
    public $mb9Ag = 's3';
    public $mIQ8P = [];
    public function __construct($GE8ny, $BhZGI, $kJivh, $hU5Lc, $EBuuG, $z_jcN, $Op2jz, $kCN7n, $hxvZ_, $zSVro, $OFz0s = 's3', $l5I6a = [])
    {
        goto XNbjv;
        gbWJ0:
        $this->status = $kCN7n;
        goto vM3KZ;
        tq9nD:
        $this->xc0J5 = $zSVro;
        goto r62Wr;
        vCRtC:
        $this->DKPYI = $EBuuG;
        goto Mzd9W;
        cFYHu:
        $this->mOR3k = $kJivh;
        goto memAp;
        XNbjv:
        $this->filename = $GE8ny;
        goto X71WC;
        HvWDv:
        $this->mIQ8P = $l5I6a;
        goto Va4F5;
        r62Wr:
        $this->mb9Ag = $OFz0s;
        goto HvWDv;
        X71WC:
        $this->kkcKh = $BhZGI;
        goto cFYHu;
        vM3KZ:
        $this->BRBES = $hxvZ_;
        goto tq9nD;
        HJ9Ty:
        $this->h134J = $Op2jz;
        goto gbWJ0;
        memAp:
        $this->QZ4DW = $hU5Lc;
        goto vCRtC;
        Mzd9W:
        $this->wgHxn = $z_jcN;
        goto HJ9Ty;
        Va4F5:
    }
    private static function mHtEZmsgXy8() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function msEWVbtQhvS() : array
    {
        return array_flip(self::mHtEZmsgXy8());
    }
    public function toArray() : array
    {
        $fUbqt = self::mHtEZmsgXy8();
        return [$fUbqt['filename'] => $this->filename, $fUbqt['fileExtension'] => $this->kkcKh, $fUbqt['mimeType'] => $this->mOR3k, $fUbqt['fileSize'] => $this->QZ4DW, $fUbqt['chunkSize'] => $this->DKPYI, $fUbqt['checksums'] => $this->wgHxn, $fUbqt['totalChunk'] => $this->h134J, $fUbqt['status'] => $this->status, $fUbqt['userId'] => $this->BRBES, $fUbqt['uploadId'] => $this->xc0J5, $fUbqt['driver'] => $this->mb9Ag, $fUbqt['parts'] => $this->mIQ8P];
    }
    public static function mATjowjbrtH(array $JHnxA) : self
    {
        $rWfnW = array_flip(self::msEWVbtQhvS());
        return new self($JHnxA[$rWfnW['filename']] ?? $JHnxA['filename'] ?? '', $JHnxA[$rWfnW['fileExtension']] ?? $JHnxA['fileExtension'] ?? '', $JHnxA[$rWfnW['mimeType']] ?? $JHnxA['mimeType'] ?? '', $JHnxA[$rWfnW['fileSize']] ?? $JHnxA['fileSize'] ?? 0, $JHnxA[$rWfnW['chunkSize']] ?? $JHnxA['chunkSize'] ?? 0, $JHnxA[$rWfnW['checksums']] ?? $JHnxA['checksums'] ?? [], $JHnxA[$rWfnW['totalChunk']] ?? $JHnxA['totalChunk'] ?? 0, $JHnxA[$rWfnW['status']] ?? $JHnxA['status'] ?? 0, $JHnxA[$rWfnW['userId']] ?? $JHnxA['userId'] ?? 0, $JHnxA[$rWfnW['uploadId']] ?? $JHnxA['uploadId'] ?? '', $JHnxA[$rWfnW['driver']] ?? $JHnxA['driver'] ?? 's3', $JHnxA[$rWfnW['parts']] ?? $JHnxA['parts'] ?? []);
    }
    public static function mlMxIdLqjuU($uWBGK) : self
    {
        goto zUA2x;
        yqPKE:
        Sn7lL:
        goto ACfVZ;
        ACfVZ:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto apNvL;
        zUA2x:
        if (!(isset($uWBGK['fn']) || isset($uWBGK['fe']))) {
            goto Sn7lL;
        }
        goto QE2oJ;
        QE2oJ:
        return self::mATjowjbrtH($uWBGK);
        goto yqPKE;
        apNvL:
    }
    public function mZ6eTnfJjku(string $zSVro) : void
    {
        $this->xc0J5 = $zSVro;
    }
    public function mOtcCAQ9c6f(array $l5I6a) : void
    {
        $this->mIQ8P = $l5I6a;
    }
    public static function mzfh3SG39FC($DejZC, $uYSjI, $VpggW, $hxvZ_, $EBuuG, $z_jcN, $OFz0s)
    {
        return new self($DejZC->getFilename(), $DejZC->getExtension(), $uYSjI, $VpggW, $EBuuG, $z_jcN, count($z_jcN), Xy3InMky6jKYf::UPLOADING, $hxvZ_, 0, $OFz0s, []);
    }
    public static function mfxFf7GQ3ZC($uuHkQ)
    {
        return 'metadata/' . $uuHkQ . '.json';
    }
    public function m3S3ukXw02k()
    {
        return 's3' === $this->mb9Ag ? VNuaYSNcfVlT5::S3 : VNuaYSNcfVlT5::LOCAL;
    }
}
