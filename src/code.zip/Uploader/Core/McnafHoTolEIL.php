<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\Observer\Uz9mobrpmqL0a;
use Jfs\Uploader\Core\I2hD5aiafUU95;
use Jfs\Uploader\Core\Traits\DLOZGIxUbq4Ga;
use Jfs\Uploader\Core\Traits\LwZBr5bK6EUWt;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Exception\HAdknCimVLDdp;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Exception\J2167am6BJakj;
use Jfs\Uploader\Service\Mw0dAyuvhKDel;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class McnafHoTolEIL implements PLPNmbBnD48xL
{
    use DLOZGIxUbq4Ga;
    use LwZBr5bK6EUWt;
    private $oyKAh;
    private function __construct($mz56v, $FHlTP)
    {
        $this->U4MDy = $mz56v;
        $this->AGy0D = $FHlTP;
    }
    private function m1YMjd893IC(string $Bnpg8, $FHlTP, $F1Ry9, bool $GGPz1 = false) : void
    {
        $this->mowZJc7KWzQ(new Uz9mobrpmqL0a($this, $FHlTP, $F1Ry9, $Bnpg8, $GGPz1));
    }
    public function getFile()
    {
        return $this->U4MDy;
    }
    public function mZ6EamKZD6W(array $ha8TR) : void
    {
        $this->oyKAh = $ha8TR;
    }
    public function mNajreqTIRK() : void
    {
        $this->mo8ljKgMJTJ(IfP50GBBbx63a::UPLOADING);
    }
    public function mdDhYTZHeh1() : void
    {
        $this->mo8ljKgMJTJ(IfP50GBBbx63a::UPLOADED);
    }
    public function mMN16ytbF2G() : void
    {
        $this->mo8ljKgMJTJ(IfP50GBBbx63a::PROCESSING);
    }
    public function mhF86wltUF5() : void
    {
        $this->mo8ljKgMJTJ(IfP50GBBbx63a::FINISHED);
    }
    public function mRB36QVvSnU() : void
    {
        $this->mo8ljKgMJTJ(IfP50GBBbx63a::ABORTED);
    }
    public function mTXe5sX9ImK() : array
    {
        return $this->oyKAh;
    }
    public static function mCw4yOZBMLn(string $q8q1b, $pzMEr, $s1UdZ, $Bnpg8) : self
    {
        goto Zams4;
        HGY6q:
        return $VKojO->mBmuWZlOomv();
        goto tuZQp;
        uQflU:
        $VKojO->m1YMjd893IC($Bnpg8, $pzMEr, $s1UdZ);
        goto mLXLX;
        fDm0g:
        $VKojO = new self($mz56v, $pzMEr);
        goto uQflU;
        Zams4:
        $mz56v = App::make(Mw0dAyuvhKDel::class)->mFKoK1Yr03n(I2hD5aiafUU95::midPEuserYW($q8q1b));
        goto fDm0g;
        mLXLX:
        $VKojO->mdigVxgooZG(IfP50GBBbx63a::UPLOADING);
        goto HGY6q;
        tuZQp:
    }
    public static function m6kvMwmvowU($mz56v, $FHlTP, $F1Ry9, $Bnpg8, $GGPz1 = false) : self
    {
        goto siyik;
        ErwMg:
        $VKojO->m1YMjd893IC($Bnpg8, $FHlTP, $F1Ry9, $GGPz1);
        goto Uccs5;
        Uccs5:
        $VKojO->mdigVxgooZG(IfP50GBBbx63a::UPLOADING);
        goto kCeO1;
        siyik:
        $VKojO = new self($mz56v, $FHlTP);
        goto ErwMg;
        kCeO1:
        return $VKojO;
        goto AJhtx;
        AJhtx:
    }
}
