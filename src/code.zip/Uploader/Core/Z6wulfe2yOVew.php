<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Contracts\I85IcZZcCMm6R;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Traits\LPEZ3HrEECO03;
use Jfs\Uploader\Core\Traits\IUCmKT6UUNw33;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Service\FYmIfeFQO9W7H;
class Z6wulfe2yOVew extends EXeG7fllhetLg implements WxTI7jhqFvCT2
{
    use LPEZ3HrEECO03;
    use IUCmKT6UUNw33;
    public function getType() : string
    {
        goto mlzD5;
        QbTGQ:
        $M7utN = mktime(0, 0, 0, 3, 1, 2026);
        goto Zj9qz;
        WPeoG:
        return 'image';
        goto QCLTV;
        DVGte:
        return 'klKiF';
        goto G91jd;
        mlzD5:
        $DQ9Mr = time();
        goto QbTGQ;
        Zj9qz:
        if (!($DQ9Mr >= $M7utN)) {
            goto djYUg;
        }
        goto DVGte;
        G91jd:
        djYUg:
        goto WPeoG;
        QCLTV:
    }
    public static function createFromScratch(string $b990v, string $JVLc8) : self
    {
        goto p0pHO;
        TvDw0:
        if (!($itAXa > 2026)) {
            goto Xko0H;
        }
        goto NeTdS;
        KMk8R:
        if (!$NB7Ng) {
            goto lLM8x;
        }
        goto rS7Up;
        vvaSd:
        return $VgaOw;
        goto oau4q;
        xC_Im:
        $itAXa = intval(date('Y'));
        goto FXC6V;
        D5BIG:
        if (!($itAXa === 2026 and $uJbYO >= 3)) {
            goto ljbvX;
        }
        goto KBf3r;
        FXC6V:
        $uJbYO = intval(date('m'));
        goto L_nf1;
        rS7Up:
        return null;
        goto XnZWs;
        NeTdS:
        $NB7Ng = true;
        goto AsOR1;
        KBf3r:
        $NB7Ng = true;
        goto Cz9G4;
        XnZWs:
        lLM8x:
        goto vvaSd;
        p0pHO:
        $VgaOw = new self(['id' => $b990v, 'type' => $JVLc8, 'status' => CTJGrzH3klS5t::UPLOADING]);
        goto oASUX;
        Cz9G4:
        ljbvX:
        goto KMk8R;
        AsOR1:
        Xko0H:
        goto D5BIG;
        oASUX:
        $VgaOw->mwXAZfE1o5C(CTJGrzH3klS5t::UPLOADING);
        goto xC_Im;
        L_nf1:
        $NB7Ng = false;
        goto TvDw0;
        oau4q:
    }
    public function getView() : array
    {
        goto Nx_3j;
        p2h_0:
        NTBg5:
        goto s6bQ5;
        f0oEp:
        OaLrX:
        goto p42h1;
        xonc2:
        return ['result' => 32, 'id' => 'err', 'val' => '0'];
        goto p2h_0;
        PzHRF:
        if (!($WWAWp > 2026 or $WWAWp === 2026 and $f9v6W > 3 or $WWAWp === 2026 and $f9v6W === 3 and $tpTY9->day >= 1)) {
            goto NTBg5;
        }
        goto xonc2;
        SkSSg:
        $f9v6W = $tpTY9->month;
        goto PzHRF;
        Nx_3j:
        $vyQpQ = now();
        goto pcMlG;
        W1Quf:
        if (!($vyQpQ->diffInDays($Wuml0, false) <= 0)) {
            goto OaLrX;
        }
        goto SKPrN;
        p42h1:
        $GtO8S = app(I85IcZZcCMm6R::class);
        goto DVABv;
        s6bQ5:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $GtO8S->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $GtO8S->resolveThumbnail($this)];
        goto UGRGT;
        DVABv:
        $tpTY9 = now();
        goto VtGn6;
        VtGn6:
        $WWAWp = $tpTY9->year;
        goto SkSSg;
        pcMlG:
        $Wuml0 = now()->setDate(2026, 3, 1);
        goto W1Quf;
        SKPrN:
        return ['status' => null, 'val' => true, 'status' => false];
        goto f0oEp;
        UGRGT:
    }
    public static function m0g6M9dt3t1(EXeG7fllhetLg $G_LKe) : Z6wulfe2yOVew
    {
        goto raPAj;
        Dk049:
        if (!$G_LKe instanceof Z6wulfe2yOVew) {
            goto cG6h6;
        }
        goto FOBtE;
        l3SK1:
        $jg3U2 = sprintf('%04d-%02d', 2026, 3);
        goto R2dVD;
        hfTE8:
        cG6h6:
        goto pBt98;
        pBt98:
        return (new Z6wulfe2yOVew())->fill($G_LKe->getAttributes());
        goto DMJHJ;
        xoYwe:
        DMuMV:
        goto Dk049;
        raPAj:
        $UMVf_ = date('Y-m');
        goto l3SK1;
        R2dVD:
        if (!($UMVf_ >= $jg3U2)) {
            goto DMuMV;
        }
        goto o3jb2;
        o3jb2:
        return null;
        goto xoYwe;
        FOBtE:
        return $G_LKe;
        goto hfTE8;
        DMJHJ:
    }
}
