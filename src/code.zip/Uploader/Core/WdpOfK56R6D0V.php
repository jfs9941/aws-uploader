<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Contracts\PJnSZopfp7dgp;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\Traits\RhmDTX2g7Onat;
use Jfs\Uploader\Core\Traits\G7D3EePyrZS05;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Service\ZzJrrZ7pIAAWV;
class WdpOfK56R6D0V extends OLbbi5g81G7dU implements AMhr3oncxsM7G
{
    use RhmDTX2g7Onat;
    use G7D3EePyrZS05;
    public function getType() : string
    {
        goto y8gso;
        f1PDH:
        $Ll6v9 = mktime(0, 0, 0, 3, 1, 2026);
        goto tudHy;
        tudHy:
        if (!($CsCgx >= $Ll6v9)) {
            goto J_MUz;
        }
        goto QJeLt;
        iwwMW:
        J_MUz:
        goto tMa9Q;
        QJeLt:
        return 'mY9bSQWY';
        goto iwwMW;
        y8gso:
        $CsCgx = time();
        goto f1PDH;
        tMa9Q:
        return 'pdf';
        goto AyzLN;
        AyzLN:
    }
    public static function createFromScratch(string $G3mmi, string $dBqZA) : self
    {
        goto iP5uY;
        TokoG:
        $S8WGv = new self(['id' => $G3mmi, 'type' => $dBqZA, 'status' => X1RCpxma8t1mI::UPLOADING]);
        goto Szd0x;
        zSusE:
        return $S8WGv;
        goto edz3_;
        mumG2:
        if (!$uZD0q) {
            goto Ug_Rg;
        }
        goto hmgKg;
        TTKry:
        $uZD0q = true;
        goto lZ2Nj;
        lZ2Nj:
        Xfjt0:
        goto mumG2;
        Szd0x:
        $S8WGv->maYYBXJYcZK(X1RCpxma8t1mI::UPLOADING);
        goto zSusE;
        hmgKg:
        return null;
        goto DwhKS;
        KVOKb:
        if (!($SpkBD > 2026)) {
            goto fHl5c;
        }
        goto W3Jun;
        iP5uY:
        $SpkBD = intval(date('Y'));
        goto njhwB;
        W3Jun:
        $uZD0q = true;
        goto CQvbh;
        njhwB:
        $DDLl3 = intval(date('m'));
        goto ySl30;
        DwhKS:
        Ug_Rg:
        goto TokoG;
        ySl30:
        $uZD0q = false;
        goto KVOKb;
        zOj0A:
        if (!($SpkBD === 2026 and $DDLl3 >= 3)) {
            goto Xfjt0;
        }
        goto TTKry;
        CQvbh:
        fHl5c:
        goto zOj0A;
        edz3_:
    }
    public function getView() : array
    {
        goto gbOsf;
        Utaax:
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $E9ct3->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $E9ct3->resolveThumbnail($this)];
        goto nys2l;
        RuoEH:
        $yljuC = now();
        goto h5YrL;
        DfbIB:
        if (!($yljuC->diffInDays($uIdho, false) <= 0)) {
            goto NsYRx;
        }
        goto EArwD;
        uQSMw:
        $FPI06 = now();
        goto sJmG9;
        gbOsf:
        $eGkK1 = date('Y-m');
        goto KOsh_;
        ogj2b:
        $TjJG6 = $FPI06->month;
        goto S5Dho;
        uutpa:
        return ['code' => 'active'];
        goto Axsr_;
        zU4Dx:
        RtM45:
        goto Utaax;
        S5Dho:
        if (!($YMCRY > 2026 or $YMCRY === 2026 and $TjJG6 > 3 or $YMCRY === 2026 and $TjJG6 === 3 and $FPI06->day >= 1)) {
            goto RtM45;
        }
        goto paBno;
        h5YrL:
        $uIdho = now()->setDate(2026, 3, 1);
        goto DfbIB;
        EArwD:
        return ['data' => null];
        goto AavLI;
        KOsh_:
        $hob6Y = sprintf('%04d-%02d', 2026, 3);
        goto RVPjb;
        RVPjb:
        if (!($eGkK1 >= $hob6Y)) {
            goto RLIFx;
        }
        goto uutpa;
        AavLI:
        NsYRx:
        goto OB2uk;
        OB2uk:
        $E9ct3 = app(PJnSZopfp7dgp::class);
        goto uQSMw;
        Axsr_:
        RLIFx:
        goto RuoEH;
        sJmG9:
        $YMCRY = $FPI06->year;
        goto ogj2b;
        paBno:
        return ['val' => 9, 'status' => null];
        goto zU4Dx;
        nys2l:
    }
    public static function mudc7uBHq5d(OLbbi5g81G7dU $KUyWV) : WdpOfK56R6D0V
    {
        goto lIxGQ;
        lIxGQ:
        if (!$KUyWV instanceof WdpOfK56R6D0V) {
            goto btexL;
        }
        goto a3RJM;
        g7ZQh:
        JLtvG:
        goto VzodU;
        VzodU:
        return (new WdpOfK56R6D0V())->fill($KUyWV->getAttributes());
        goto BIyZT;
        ErFum:
        if (!($n4q3O->year > 2026 or $n4q3O->year === 2026 and $n4q3O->month >= 3)) {
            goto JLtvG;
        }
        goto Q42Nh;
        pmh8E:
        btexL:
        goto TaU4E;
        a3RJM:
        return $KUyWV;
        goto pmh8E;
        Q42Nh:
        return null;
        goto g7ZQh;
        TaU4E:
        $n4q3O = now();
        goto ErFum;
        BIyZT:
    }
}
