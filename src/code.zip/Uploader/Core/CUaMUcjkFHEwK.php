<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Core\Traits\RYD8pJSplDz0G;
use Jfs\Uploader\Core\Traits\RmjpXY01QWbl2;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
class CUaMUcjkFHEwK extends CZj9PTf9Cv9Eq implements VH6naaofz5IuZ
{
    use RYD8pJSplDz0G;
    use RmjpXY01QWbl2;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $Vuk0i, string $RKAxu) : self
    {
        goto rQ5Co;
        rQ5Co:
        $zef_R = new self(['id' => $Vuk0i, 'type' => $RKAxu, 'status' => EPmxqTVp5luXc::UPLOADING]);
        goto v270l;
        Sj7cn:
        return $zef_R;
        goto IkF6J;
        v270l:
        $zef_R->mkv7RuyOFPh(EPmxqTVp5luXc::UPLOADING);
        goto Sj7cn;
        IkF6J:
    }
    public function width() : ?int
    {
        goto fjP8D;
        ZmYwD:
        return $xjnOB;
        goto ouFHJ;
        Lq7mB:
        return null;
        goto qc7I9;
        ouFHJ:
        E6XWj:
        goto Lq7mB;
        uralY:
        if (!$xjnOB) {
            goto E6XWj;
        }
        goto ZmYwD;
        fjP8D:
        $xjnOB = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto uralY;
        qc7I9:
    }
    public function height() : ?int
    {
        goto EKSG0;
        fi7y3:
        RMrEc:
        goto JveN8;
        hB4SX:
        return $I9Wph;
        goto fi7y3;
        JveN8:
        return null;
        goto Wvn1e;
        xXTe1:
        if (!$I9Wph) {
            goto RMrEc;
        }
        goto hB4SX;
        EKSG0:
        $I9Wph = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto xXTe1;
        Wvn1e:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($zef_R) {
            goto DHfKU;
            XTGiu:
            if (!(!array_key_exists('thumbnail', $acJEr) && !array_key_exists('hls_path', $acJEr))) {
                goto vPJ0z;
            }
            goto cnRv3;
            cnRv3:
            return;
            goto dtFAV;
            NIbiZ:
            CUaMUcjkFHEwK::where('parent_id', $zef_R->getAttribute('id'))->update(['thumbnail' => $zef_R->getAttributes()['thumbnail'], 'hls_path' => $zef_R->getAttributes()['hls_path']]);
            goto XNOtx;
            wm94w:
            if (!($acJEr['thumbnail'] || $acJEr['hls_path'])) {
                goto ynTX2;
            }
            goto NIbiZ;
            dtFAV:
            vPJ0z:
            goto wm94w;
            XNOtx:
            ynTX2:
            goto Dw0Cy;
            DHfKU:
            $acJEr = $zef_R->getDirty();
            goto XTGiu;
            Dw0Cy:
        });
    }
    public function mhvVT05QwOr()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mXY3Y3MaptU()
    {
        return $this->getAttribute('id');
    }
    public function mq07jEGcxvW() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto V38TR;
        lFOVF:
        $RrBvn['player_url'] = $hlmkv->resolvePath($this, $this->getAttribute('driver'));
        goto X8NrJ;
        V38TR:
        $hlmkv = app(BEzZsfn3kKkr3::class);
        goto eU4PA;
        eU4PA:
        $RrBvn = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $hlmkv->resolvePath($this, $this->getAttribute('driver'))];
        goto V3R2I;
        S7xPk:
        return $RrBvn;
        goto woHns;
        V3R2I:
        if ($this->getAttribute('hls_path')) {
            goto XINDv;
        }
        goto lFOVF;
        X8NrJ:
        goto FeGzM;
        goto SEzD_;
        SEzD_:
        XINDv:
        goto pbP9D;
        J0Q_Q:
        FeGzM:
        goto MxXla;
        pbP9D:
        $RrBvn['player_url'] = $hlmkv->resolvePathForHlsVideo($this, true);
        goto J0Q_Q;
        MxXla:
        $RrBvn['thumbnail'] = $hlmkv->resolveThumbnail($this);
        goto S7xPk;
        woHns:
    }
    public function getThumbnails()
    {
        goto uTVDN;
        KqOl9:
        $hlmkv = app(BEzZsfn3kKkr3::class);
        goto vPqRX;
        vPqRX:
        return array_map(function ($E2RLT) use($hlmkv) {
            return $hlmkv->resolvePath($E2RLT);
        }, $xs6AF);
        goto uT8RP;
        uTVDN:
        $xs6AF = $this->getAttribute('generated_previews') ?? [];
        goto KqOl9;
        uT8RP:
    }
    public static function mpg6LaJ3BRK(CZj9PTf9Cv9Eq $dCHQU) : CUaMUcjkFHEwK
    {
        goto h1Ixo;
        lgMMZ:
        return $dCHQU;
        goto xE0OD;
        xE0OD:
        pZSDh:
        goto rVvma;
        h1Ixo:
        if (!$dCHQU instanceof CUaMUcjkFHEwK) {
            goto pZSDh;
        }
        goto lgMMZ;
        rVvma:
        return (new CUaMUcjkFHEwK())->fill($dCHQU->getAttributes());
        goto CttOI;
        CttOI:
    }
}
