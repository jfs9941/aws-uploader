<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Illuminate\Database\Eloquent\Model;
abstract  class NCmZ7rMVMWyvC extends Model implements WlFu7DaMUEnSS
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mpP5bOKeXyo() : bool
    {
        goto aIEz3;
        E6a0q:
        return true;
        goto M7wtx;
        aIEz3:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto vv2yS;
        }
        goto E6a0q;
        Cm8oa:
        return !$this->mGWZMYl7s11();
        goto fApyw;
        M7wtx:
        vv2yS:
        goto Cm8oa;
        fApyw:
    }
    protected function mGWZMYl7s11() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
