<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Contracts\Dm945121dFKVW;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\Traits\EpBhYo5NrILTt;
use Jfs\Uploader\Core\Traits\LkAAxyhGgmAFk;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Service\QNlFAcHy60ycp;
class XMeo8SOmME8kj extends Zl4rdW32ufaUx implements FTr6mgGRFf157
{
    use EpBhYo5NrILTt;
    use LkAAxyhGgmAFk;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $FIM0D, string $EE6bd) : self
    {
        goto glS63;
        BJzmZ:
        return $zCabx;
        goto HNN3k;
        MwFO0:
        $zCabx->mHWfC8guF82(LV0wDYHZInswq::UPLOADING);
        goto BJzmZ;
        glS63:
        $zCabx = new self(['id' => $FIM0D, 'type' => $EE6bd, 'status' => LV0wDYHZInswq::UPLOADING]);
        goto MwFO0;
        HNN3k:
    }
    public function getView() : array
    {
        $Y_PMr = app(Dm945121dFKVW::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $Y_PMr->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Y_PMr->resolveThumbnail($this)];
    }
    public static function m5NjCLAZvYq(Zl4rdW32ufaUx $vPecg) : XMeo8SOmME8kj
    {
        goto Xjj98;
        ucgyd:
        return $vPecg;
        goto v6OGl;
        YSi5m:
        return (new XMeo8SOmME8kj())->fill($vPecg->getAttributes());
        goto Wmv5i;
        Xjj98:
        if (!$vPecg instanceof XMeo8SOmME8kj) {
            goto TZ2MX;
        }
        goto ucgyd;
        v6OGl:
        TZ2MX:
        goto YSi5m;
        Wmv5i:
    }
}
