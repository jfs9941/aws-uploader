<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; interface DIYGIfCt7MLhm { public function getFilename() : string; public function getExtension() : string; public function getType() : string; public function getLocation() : string; public function initLocation(string $BFxyy); public static function createFromScratch(string $rOtzv, string $g7qa1); public function getView(); }
