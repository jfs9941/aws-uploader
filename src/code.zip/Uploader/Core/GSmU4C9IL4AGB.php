<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Illuminate\Database\Eloquent\Model;
abstract  class GSmU4C9IL4AGB extends Model implements VpkgrrmDu5rEh
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function m9KpLiYTd3q() : bool
    {
        goto OiSbS;
        OiSbS:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto JYKg0;
        }
        goto CUSLr;
        aFxsI:
        return !$this->mQoCmY7rlfr();
        goto fxtw4;
        BdR4Y:
        JYKg0:
        goto aFxsI;
        CUSLr:
        return true;
        goto BdR4Y;
        fxtw4:
    }
    protected function mQoCmY7rlfr() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
