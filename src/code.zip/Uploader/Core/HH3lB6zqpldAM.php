<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
final class HH3lB6zqpldAM
{
    public $filename;
    public $RRafQ;
    public $x06d2;
    public $jVikM;
    public $vD_8M;
    public $rqL2L;
    public $Qbq60;
    public $status;
    public $ymX0e;
    public $Y7fjO;
    public $euRQL = 's3';
    public $MA937 = [];
    public function __construct($lK1S0, $QCzoS, $obUpg, $FMSYP, $eEti6, $S0AL0, $AZzHq, $nqFge, $TbUNq, $v5Sny, $Rmh9e = 's3', $MZWng = [])
    {
        goto PAeqz;
        xhqp9:
        $this->Qbq60 = $AZzHq;
        goto rYEK_;
        n2a2B:
        $this->MA937 = $MZWng;
        goto pXTNU;
        m8VP2:
        $this->vD_8M = $eEti6;
        goto fJShP;
        xDS1x:
        $this->euRQL = $Rmh9e;
        goto n2a2B;
        PAeqz:
        $this->filename = $lK1S0;
        goto Th8uu;
        Th8uu:
        $this->RRafQ = $QCzoS;
        goto feWu1;
        P11l6:
        $this->ymX0e = $TbUNq;
        goto NCln_;
        NCln_:
        $this->Y7fjO = $v5Sny;
        goto xDS1x;
        AozRD:
        $this->jVikM = $FMSYP;
        goto m8VP2;
        feWu1:
        $this->x06d2 = $obUpg;
        goto AozRD;
        fJShP:
        $this->rqL2L = $S0AL0;
        goto xhqp9;
        rYEK_:
        $this->status = $nqFge;
        goto P11l6;
        pXTNU:
    }
    private static function mY1Qjjx8YVW() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mAgkucLgsle() : array
    {
        return array_flip(self::mY1Qjjx8YVW());
    }
    public function toArray() : array
    {
        $DCRI9 = self::mY1Qjjx8YVW();
        return [$DCRI9['filename'] => $this->filename, $DCRI9['fileExtension'] => $this->RRafQ, $DCRI9['mimeType'] => $this->x06d2, $DCRI9['fileSize'] => $this->jVikM, $DCRI9['chunkSize'] => $this->vD_8M, $DCRI9['checksums'] => $this->rqL2L, $DCRI9['totalChunk'] => $this->Qbq60, $DCRI9['status'] => $this->status, $DCRI9['userId'] => $this->ymX0e, $DCRI9['uploadId'] => $this->Y7fjO, $DCRI9['driver'] => $this->euRQL, $DCRI9['parts'] => $this->MA937];
    }
    public static function mzh0Jv6nlRp(array $jsCQB) : self
    {
        $YKdjL = array_flip(self::mAgkucLgsle());
        return new self($jsCQB[$YKdjL['filename']] ?? $jsCQB['filename'] ?? '', $jsCQB[$YKdjL['fileExtension']] ?? $jsCQB['fileExtension'] ?? '', $jsCQB[$YKdjL['mimeType']] ?? $jsCQB['mimeType'] ?? '', $jsCQB[$YKdjL['fileSize']] ?? $jsCQB['fileSize'] ?? 0, $jsCQB[$YKdjL['chunkSize']] ?? $jsCQB['chunkSize'] ?? 0, $jsCQB[$YKdjL['checksums']] ?? $jsCQB['checksums'] ?? [], $jsCQB[$YKdjL['totalChunk']] ?? $jsCQB['totalChunk'] ?? 0, $jsCQB[$YKdjL['status']] ?? $jsCQB['status'] ?? 0, $jsCQB[$YKdjL['userId']] ?? $jsCQB['userId'] ?? 0, $jsCQB[$YKdjL['uploadId']] ?? $jsCQB['uploadId'] ?? '', $jsCQB[$YKdjL['driver']] ?? $jsCQB['driver'] ?? 's3', $jsCQB[$YKdjL['parts']] ?? $jsCQB['parts'] ?? []);
    }
    public static function m7NfWkVypwj($t9bLp) : self
    {
        goto sa1Sb;
        CNFx8:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto oqqts;
        sa1Sb:
        if (!(isset($t9bLp['fn']) || isset($t9bLp['fe']))) {
            goto J1HGn;
        }
        goto QvSBQ;
        QvSBQ:
        return self::mzh0Jv6nlRp($t9bLp);
        goto ZCQDt;
        ZCQDt:
        J1HGn:
        goto CNFx8;
        oqqts:
    }
    public function m44sTqfMmVa(string $v5Sny) : void
    {
        $this->Y7fjO = $v5Sny;
    }
    public function mMyEb8uTkGj(array $MZWng) : void
    {
        $this->MA937 = $MZWng;
    }
    public static function mSvlo5fN5Xi($YfsmL, $rsp_O, $HwPCY, $TbUNq, $eEti6, $S0AL0, $Rmh9e)
    {
        return new self($YfsmL->getFilename(), $YfsmL->getExtension(), $rsp_O, $HwPCY, $eEti6, $S0AL0, count($S0AL0), LV0wDYHZInswq::UPLOADING, $TbUNq, 0, $Rmh9e, []);
    }
    public static function m8RSRuVXPMu($B_L9m)
    {
        return 'metadata/' . $B_L9m . '.json';
    }
    public function mRLbm2J63D1()
    {
        return 's3' === $this->euRQL ? J0IuL8wroLOWt::S3 : J0IuL8wroLOWt::LOCAL;
    }
}
