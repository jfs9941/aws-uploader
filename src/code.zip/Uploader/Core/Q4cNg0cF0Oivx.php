<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\Observer\RnynQHVSjDeNa;
use Jfs\Uploader\Core\Z4Tul5rPROvzh;
use Jfs\Uploader\Core\Traits\EyoGtyZFdr3co;
use Jfs\Uploader\Core\Traits\SphMX2uWp2oS1;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Exception\VSaAUeOOPZiL5;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Exception\IgLoDg5bjroxA;
use Jfs\Uploader\Service\CYgJOMj8wExPk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class Q4cNg0cF0Oivx implements MB8DYpNdVV1bz
{
    use EyoGtyZFdr3co;
    use SphMX2uWp2oS1;
    private $lOm5R;
    private function __construct($RCdwx, $jT0xz)
    {
        $this->Suzy5 = $RCdwx;
        $this->erfSo = $jT0xz;
    }
    private function mi3lkHbyMIe(string $wY6MR, $jT0xz, $x4E8s, bool $SuqjN = false) : void
    {
        $this->mYvBQMWkcb5(new RnynQHVSjDeNa($this, $jT0xz, $x4E8s, $wY6MR, $SuqjN));
    }
    public function getFile()
    {
        return $this->Suzy5;
    }
    public function m7mjAjbAyV9(array $rMflj) : void
    {
        $this->lOm5R = $rMflj;
    }
    public function mPIJfcVqq6f() : void
    {
        $this->mIiE80g96Fo(Tbw0jsMnRbOTP::UPLOADING);
    }
    public function mO37wAXSj7j() : void
    {
        $this->mIiE80g96Fo(Tbw0jsMnRbOTP::UPLOADED);
    }
    public function m3jdVw0RTz1() : void
    {
        $this->mIiE80g96Fo(Tbw0jsMnRbOTP::PROCESSING);
    }
    public function mm4RMr8V0Ds() : void
    {
        $this->mIiE80g96Fo(Tbw0jsMnRbOTP::FINISHED);
    }
    public function m725LM7dq7t() : void
    {
        $this->mIiE80g96Fo(Tbw0jsMnRbOTP::ABORTED);
    }
    public function mQC0gqARkin() : array
    {
        return $this->lOm5R;
    }
    public static function mJFDfbjInru(string $LpGEK, $i4KfK, $WmwnR, $wY6MR) : self
    {
        goto KJ9Vc;
        LKAKb:
        $xMG6f->mi3lkHbyMIe($wY6MR, $i4KfK, $WmwnR);
        goto nM9h_;
        nM9h_:
        $xMG6f->mWRFuBOBU6q(Tbw0jsMnRbOTP::UPLOADING);
        goto qIBdV;
        KJ9Vc:
        $RCdwx = App::make(CYgJOMj8wExPk::class)->mjowAcEjDR3(Z4Tul5rPROvzh::mAcNlszMlxW($LpGEK));
        goto VVJO2;
        VVJO2:
        $xMG6f = new self($RCdwx, $i4KfK);
        goto LKAKb;
        qIBdV:
        return $xMG6f->mTu77EpVWgl();
        goto qqy1M;
        qqy1M:
    }
    public static function mopG22rfXNL($RCdwx, $jT0xz, $x4E8s, $wY6MR, $SuqjN = false) : self
    {
        goto FL1gb;
        FL1gb:
        $xMG6f = new self($RCdwx, $jT0xz);
        goto oXrf3;
        oXrf3:
        $xMG6f->mi3lkHbyMIe($wY6MR, $jT0xz, $x4E8s, $SuqjN);
        goto dT3pc;
        vTS4a:
        return $xMG6f;
        goto ew5LW;
        dT3pc:
        $xMG6f->mWRFuBOBU6q(Tbw0jsMnRbOTP::UPLOADING);
        goto vTS4a;
        ew5LW:
    }
}
