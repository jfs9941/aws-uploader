<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Contracts\PmQuktZiUDRAI;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\Traits\BgSSf3nNzBi4E;
use Jfs\Uploader\Core\Traits\Gwfgj7S32Yazt;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Service\QVXDWzQlJsLPv;
class C1MO7dubi2ia5 extends GSmU4C9IL4AGB implements N41GICKeJz2js
{
    use BgSSf3nNzBi4E;
    use Gwfgj7S32Yazt;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $Y1bE6, string $h4Sqa) : self
    {
        goto IQF00;
        m0bSN:
        return $Ph173;
        goto qIBL2;
        IQF00:
        $Ph173 = new self(['id' => $Y1bE6, 'type' => $h4Sqa, 'status' => Zgh3BZ2JVlG1A::UPLOADING]);
        goto l11lo;
        l11lo:
        $Ph173->mtNisNH4NQd(Zgh3BZ2JVlG1A::UPLOADING);
        goto m0bSN;
        qIBL2:
    }
    public function getView() : array
    {
        $g4cPY = app(PmQuktZiUDRAI::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $g4cPY->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $g4cPY->resolveThumbnail($this)];
    }
    public static function mgdpp7AIRiA(GSmU4C9IL4AGB $qc05M) : C1MO7dubi2ia5
    {
        goto IulOQ;
        IulOQ:
        if (!$qc05M instanceof C1MO7dubi2ia5) {
            goto m0oiW;
        }
        goto GPcLW;
        nIdBy:
        return (new C1MO7dubi2ia5())->fill($qc05M->getAttributes());
        goto BscIq;
        vzMbF:
        m0oiW:
        goto nIdBy;
        GPcLW:
        return $qc05M;
        goto vzMbF;
        BscIq:
    }
}
