<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Illuminate\Database\Eloquent\Model;
abstract  class Fd8NTWwq2cQOc extends Model implements KhQ4OQYybZ7Vk
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function m0IQvI6cLO5() : bool
    {
        goto R26JD;
        R26JD:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto lwlCR;
        }
        goto zl2q1;
        E3kN8:
        return !$this->mLBOCPI1RWh();
        goto TpV2U;
        JpQOv:
        lwlCR:
        goto E3kN8;
        zl2q1:
        return true;
        goto JpQOv;
        TpV2U:
    }
    protected function mLBOCPI1RWh() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
