<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\Observer\QlNIgWyy5JScz;
use Jfs\Uploader\Core\XXOVbK7SeD5pn;
use Jfs\Uploader\Core\Traits\TRcfxN5cWljKX;
use Jfs\Uploader\Core\Traits\TjGyNEupzj5XK;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Exception\ZKaX19yQXS7pD;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Exception\YIRQaRmojMDyD;
use Jfs\Uploader\Service\ZZ32LbChqQKFG;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
final class XWJCs1ZDQGYBH implements F9PXWR72LBMoZ
{
    use TRcfxN5cWljKX;
    use TjGyNEupzj5XK;
    private $nenXC;
    private function __construct($nbWJE, $G3exm)
    {
        $this->tEOkh = $nbWJE;
        $this->DhHSC = $G3exm;
    }
    private function mG1HVEGsmki(string $r087v, $G3exm, $u0SLj, bool $XcPhJ = false) : void
    {
        $this->mPghak6SKwq(new QlNIgWyy5JScz($this, $G3exm, $u0SLj, $r087v, $XcPhJ));
    }
    public function getFile()
    {
        return $this->tEOkh;
    }
    public function mT6C36oVf34(array $Fc_GF) : void
    {
        $this->nenXC = $Fc_GF;
    }
    public function mkiR97Ha49x() : void
    {
        $this->mI0VzEtubJR(H7dtWZ2h5WAty::UPLOADING);
    }
    public function mPDWZFDXnAa() : void
    {
        $this->mI0VzEtubJR(H7dtWZ2h5WAty::UPLOADED);
    }
    public function m8ElVxQrBb4() : void
    {
        $this->mI0VzEtubJR(H7dtWZ2h5WAty::PROCESSING);
    }
    public function mT8xp5pS6is() : void
    {
        $this->mI0VzEtubJR(H7dtWZ2h5WAty::FINISHED);
    }
    public function mcr2nAulWjL() : void
    {
        $this->mI0VzEtubJR(H7dtWZ2h5WAty::ABORTED);
    }
    public function mawDjlibMZT() : array
    {
        return $this->nenXC;
    }
    public static function m7IezPqzN0k(string $DWjir, $oA0jJ, $C1By6, $r087v) : self
    {
        goto PJUbz;
        MqH9q:
        $t5vaU = new self($nbWJE, $oA0jJ);
        goto iOm7w;
        LO2kM:
        $t5vaU->muKqrdnPhRb(H7dtWZ2h5WAty::UPLOADING);
        goto puSpO;
        PJUbz:
        $nbWJE = App::make(ZZ32LbChqQKFG::class)->mR8BiHWgoQR(XXOVbK7SeD5pn::mujQ08d9CEo($DWjir));
        goto MqH9q;
        iOm7w:
        $t5vaU->mG1HVEGsmki($r087v, $oA0jJ, $C1By6);
        goto LO2kM;
        puSpO:
        return $t5vaU->mosz4VIUsb0();
        goto mzrpq;
        mzrpq:
    }
    public static function mJKhvElAoMA($nbWJE, $G3exm, $u0SLj, $r087v, $XcPhJ = false) : self
    {
        goto DZunT;
        PCHBX:
        $t5vaU->mG1HVEGsmki($r087v, $G3exm, $u0SLj, $XcPhJ);
        goto RZlrj;
        TZ2_b:
        return $t5vaU;
        goto DJ3aT;
        RZlrj:
        $t5vaU->muKqrdnPhRb(H7dtWZ2h5WAty::UPLOADING);
        goto TZ2_b;
        DZunT:
        $t5vaU = new self($nbWJE, $G3exm);
        goto PCHBX;
        DJ3aT:
    }
}
