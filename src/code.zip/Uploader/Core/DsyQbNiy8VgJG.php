<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Contracts\VrVag0CyeQKdN;
use Jfs\Uploader\Core\Traits\NS3Z1m1xuUfrl;
use Jfs\Uploader\Core\Traits\U4dsP2dkmJHns;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Service\GALKiO0auT3sq;
class DsyQbNiy8VgJG extends Yn8aWzKzROkno implements CxLspzxS91nUL
{
    use NS3Z1m1xuUfrl;
    use U4dsP2dkmJHns;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $EtuF1, string $dwytV) : self
    {
        goto kmj2e;
        JQ3lg:
        return $fK3zd;
        goto YrEbX;
        LYvHn:
        $fK3zd->m25UhhF4K3y(SwAwanZG36Yx6::UPLOADING);
        goto JQ3lg;
        kmj2e:
        $fK3zd = new self(['id' => $EtuF1, 'type' => $dwytV, 'status' => SwAwanZG36Yx6::UPLOADING]);
        goto LYvHn;
        YrEbX:
    }
    public function getView() : array
    {
        $vZ4J2 = app(VrVag0CyeQKdN::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $vZ4J2->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $vZ4J2->resolveThumbnail($this)];
    }
    public static function mItue757lf8(Yn8aWzKzROkno $LKVOP) : DsyQbNiy8VgJG
    {
        goto M4Th9;
        X2rbW:
        iFrVL:
        goto peJh1;
        peJh1:
        return (new DsyQbNiy8VgJG())->fill($LKVOP->getAttributes());
        goto Q3eaS;
        dmbg1:
        return $LKVOP;
        goto X2rbW;
        M4Th9:
        if (!$LKVOP instanceof DsyQbNiy8VgJG) {
            goto iFrVL;
        }
        goto dmbg1;
        Q3eaS:
    }
}
