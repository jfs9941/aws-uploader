<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:57              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Contracts\LQJLoPxiuxgfZ;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\Traits\ICoBvKGsB4Udb;
use Jfs\Uploader\Core\Traits\KfSjQVQJRLwh3;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
class UYo98bF5lKEmO extends AtQh9cRLX7xL8 implements Fk274vNY0LJnp
{
    use ICoBvKGsB4Udb;
    use KfSjQVQJRLwh3;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $e1Rlj, string $fsv41) : self
    {
        goto mwPeL;
        YiM3g:
        return $EVGvq;
        goto EgtpR;
        TxMCA:
        $EVGvq->mJf7701KMEl(M7O7NSiJU2JG5::UPLOADING);
        goto YiM3g;
        mwPeL:
        $EVGvq = new self(['id' => $e1Rlj, 'type' => $fsv41, 'status' => M7O7NSiJU2JG5::UPLOADING]);
        goto TxMCA;
        EgtpR:
    }
    public function width() : ?int
    {
        goto RaS3K;
        VwZsg:
        return $Eb8hw;
        goto HzV8B;
        blcxV:
        if (!$Eb8hw) {
            goto wx34_;
        }
        goto VwZsg;
        y09Ft:
        return null;
        goto K5a27;
        HzV8B:
        wx34_:
        goto y09Ft;
        RaS3K:
        $Eb8hw = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto blcxV;
        K5a27:
    }
    public function height() : ?int
    {
        goto vF_9z;
        g9jCx:
        if (!$eekOV) {
            goto jW5LW;
        }
        goto JBhgW;
        JBhgW:
        return $eekOV;
        goto b1p0R;
        b1p0R:
        jW5LW:
        goto AU2_I;
        AU2_I:
        return null;
        goto uVp14;
        vF_9z:
        $eekOV = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto g9jCx;
        uVp14:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($EVGvq) {
            goto LbpKK;
            LbpKK:
            $aT5iU = $EVGvq->getDirty();
            goto Ffmm_;
            Ffmm_:
            if (!(!array_key_exists('thumbnail', $aT5iU) && !array_key_exists('hls_path', $aT5iU))) {
                goto HpEf2;
            }
            goto PQYsE;
            oClzB:
            if (!($aT5iU['thumbnail'] || $aT5iU['hls_path'])) {
                goto PuCYF;
            }
            goto APqJN;
            APqJN:
            UYo98bF5lKEmO::where('parent_id', $EVGvq->getAttribute('id'))->update(['thumbnail' => $EVGvq->getAttributes()['thumbnail'], 'hls_path' => $EVGvq->getAttributes()['hls_path']]);
            goto sO1rH;
            PQYsE:
            return;
            goto O2fgC;
            sO1rH:
            PuCYF:
            goto cxM03;
            O2fgC:
            HpEf2:
            goto oClzB;
            cxM03:
        });
    }
    public function m35hxQJW42U()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mnbNER0Frfp()
    {
        return $this->getAttribute('id');
    }
    public function mFDStEnPbwd() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto ZpEhC;
        ZpEhC:
        $VAwkb = app(LQJLoPxiuxgfZ::class);
        goto IgBH1;
        cyGuU:
        UdDZE:
        goto IPUfC;
        Vc0Q2:
        if ($this->getAttribute('hls_path')) {
            goto UdDZE;
        }
        goto BVegj;
        ZzJjT:
        KhnaP:
        goto L9hVg;
        IPUfC:
        $OYL2A['player_url'] = $VAwkb->resolvePathForHlsVideo($this, true);
        goto ZzJjT;
        IgBH1:
        $OYL2A = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $VAwkb->resolvePath($this, $this->getAttribute('driver'))];
        goto Vc0Q2;
        L9hVg:
        $OYL2A['thumbnail'] = $VAwkb->resolveThumbnail($this);
        goto YWRA2;
        BVegj:
        $OYL2A['player_url'] = $VAwkb->resolvePath($this, $this->getAttribute('driver'));
        goto qzCpj;
        YWRA2:
        return $OYL2A;
        goto BOttQ;
        qzCpj:
        goto KhnaP;
        goto cyGuU;
        BOttQ:
    }
    public function getThumbnails()
    {
        goto V883D;
        XzCIj:
        return array_map(function ($X9APK) use($VAwkb) {
            return $VAwkb->resolvePath($X9APK);
        }, $xERPX);
        goto jT6pn;
        V883D:
        $xERPX = $this->getAttribute('generated_previews') ?? [];
        goto iOwFM;
        iOwFM:
        $VAwkb = app(LQJLoPxiuxgfZ::class);
        goto XzCIj;
        jT6pn:
    }
    public static function mHAl6xGHJWX(AtQh9cRLX7xL8 $hckxR) : UYo98bF5lKEmO
    {
        goto T6oJf;
        UOwTy:
        return (new UYo98bF5lKEmO())->fill($hckxR->getAttributes());
        goto QGCha;
        c90b2:
        return $hckxR;
        goto AD_uY;
        T6oJf:
        if (!$hckxR instanceof UYo98bF5lKEmO) {
            goto uWTmG;
        }
        goto c90b2;
        AD_uY:
        uWTmG:
        goto UOwTy;
        QGCha:
    }
}
