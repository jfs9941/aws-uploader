<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Enum;

class EPmxqTVp5luXc
{
    public const UPLOADED = 2;
    public const UPLOADING = 1;
    public const ABORTED = 0;
    public const PROCESSING = 3;
    public const WATERMARK_PROCESSED = 4;
    public const THUMBNAIL_PROCESSED = 5;
    public const ENCODING_PROCESSED = 6;
    public const BLUR_PROCESSED = 7;
    public const FINISHED = 8;
    public const DELETED = 9;
    public const ENCODING_ERROR = 10;
    public static function m2NWQKE32D6($FILUb) : string
    {
        goto pBEQb;
        MJFLP:
        ar0uH:
        goto POQ5e;
        pBEQb:
        switch ($FILUb) {
            case self::UPLOADED:
                return 'UPLOADED';
            case self::UPLOADING:
                return 'UPLOADING';
            case self::ABORTED:
                return 'ABORTED';
            case self::PROCESSING:
                return 'PROCESSING';
            case self::WATERMARK_PROCESSED:
                return 'WATERMARK_PROCESSED';
            case self::THUMBNAIL_PROCESSED:
                return 'THUMBNAIL_PROCESSED';
            case self::ENCODING_PROCESSED:
                return 'ENCODING_PROCESSED';
            case self::BLUR_PROCESSED:
                return 'BLUR_PROCESSED';
            case self::FINISHED:
                return 'FINISHED';
            case self::DELETED:
                return 'DELETED';
            case self::ENCODING_ERROR:
                return 'ENCODING_ERROR';
            default:
                return 'UNKNOWN_STATUS';
        }
        goto luKsY;
        luKsY:
        BZ5cM:
        goto MJFLP;
        POQ5e:
    }
}
