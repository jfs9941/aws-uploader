<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
interface BEzZsfn3kKkr3
{
    public function resolvePath($xUtpC, int $hCnVR = N0ISad2bKF2Yp::S3);
    public function resolveThumbnail(CZj9PTf9Cv9Eq $xUtpC);
    public function resolvePathForHlsVideo(CUaMUcjkFHEwK $zef_R, bool $wwEy0 = false);
    public function resolvePathForHlsVideos();
}
