<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\DccywYjigTakI;
interface GuNvSDjrDhnZX
{
    public function resolvePath($wiCE2, int $XHDhR = DccywYjigTakI::S3);
    public function resolveThumbnail(KFe2ZCctciwsA $wiCE2);
    public function resolvePathForHlsVideo(BG2FRpwGrKqJx $Zpy0I, bool $g95hj = false);
    public function resolvePathForHlsVideos();
}
