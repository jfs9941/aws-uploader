<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
interface QPcmBScQDUpcH
{
    public function resolvePath($p0I5F, int $bWJ0p = A3VATad7gvqZU::S3);
    public function resolveThumbnail(MEyH4ejCzSk64 $p0I5F);
    public function resolvePathForHlsVideo(MbOYV1VlUGCys $B4_PH, bool $fIYrO = false);
    public function resolvePathForHlsVideos();
}
