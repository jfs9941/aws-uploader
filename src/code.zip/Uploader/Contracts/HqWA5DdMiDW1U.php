<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
interface HqWA5DdMiDW1U
{
    public function resolvePath($UWZG3, int $nHjZR = FUIPeZ7ssitYw::S3);
    public function resolveThumbnail(GuA6QuvssLUzf $UWZG3);
    public function resolvePathForHlsVideo(ACdpgX4YCYP6M $vd5JT, bool $LC7vn = false);
    public function resolvePathForHlsVideos();
}
