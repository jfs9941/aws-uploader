<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\M7qyTIw376zSo;
use Jfs\Uploader\Exception\VwJ7WJWdWWDDp;
interface QguGxHrrpjTia
{
    public function mC8nuYteIk4($CyrJu);
    public function mCBaFPB8Ct3();
    public function mImL6eGj9Ei($FFZ2V);
    public function mTH4FAaagQg($FFZ2V);
    public function m8X5yYN5PxJ(M7qyTIw376zSo $toiza);
}
