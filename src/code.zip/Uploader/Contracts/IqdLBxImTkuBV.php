<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
interface IqdLBxImTkuBV
{
    public function resolvePath($zr5kh, int $X0gtT = McZXbZmlQ53or::S3);
    public function resolveThumbnail(GpdHFYchpZHPa $zr5kh);
    public function resolvePathForHlsVideo(BtruCfJoaSWZ6 $Bh2o5, bool $Y0x4V = false);
    public function resolvePathForHlsVideos();
}
