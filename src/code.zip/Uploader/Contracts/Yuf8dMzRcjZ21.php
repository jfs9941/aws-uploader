<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
interface Yuf8dMzRcjZ21
{
    public function resolvePath($DzZNO, int $Zqemz = Rc6MZhMMdyG6A::S3);
    public function resolveThumbnail(DMUaxGX7XHAI0 $DzZNO);
    public function resolvePathForHlsVideo(Kt6NO3eUvdER6 $yZXjN, bool $Nki3P = false);
    public function resolvePathForHlsVideos();
}
