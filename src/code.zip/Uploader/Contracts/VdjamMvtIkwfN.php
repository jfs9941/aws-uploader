<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
interface VdjamMvtIkwfN
{
    public function resolvePath($HO_3Y, int $OFz0s = VNuaYSNcfVlT5::S3);
    public function resolveThumbnail(VMj30iBgKeeJB $HO_3Y);
    public function resolvePathForHlsVideo(WrCq6RmnGcVh7 $XrW52, bool $z0gV9 = false);
    public function resolvePathForHlsVideos();
}
