<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Contracts;

use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\XmcIS8CQn72i3;
interface NTBMTa29AeaJq
{
    public function resolvePath($tFHv6, int $agJ1D = XmcIS8CQn72i3::S3);
    public function resolveThumbnail(PJqa0Yy2jwBHe $tFHv6);
    public function resolvePathForHlsVideo(AvisbyD0IE5xq $L2Ff8, bool $tQWZK = false);
    public function resolvePathForHlsVideos();
}
