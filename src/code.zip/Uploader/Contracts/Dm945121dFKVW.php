<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
interface Dm945121dFKVW
{
    public function resolvePath($uTqKK, int $Rmh9e = J0IuL8wroLOWt::S3);
    public function resolveThumbnail(Zl4rdW32ufaUx $uTqKK);
    public function resolvePathForHlsVideo(U9HMl0N8dP0ZH $QCHmE, bool $cuEie = false);
    public function resolvePathForHlsVideos();
}
