<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\J6QUpUFjfs5mO;
use Jfs\Uploader\Exception\GUt8ZmYbCCh9b;
interface GCZ2vyVNpj70n
{
    public function mlS5irobHNA($NkpSq);
    public function mCiIs22Hk9A();
    public function mKd8O9TpYCH($sPgaJ);
    public function mJp2AaygZfj($sPgaJ);
    public function mJpwZRYg1fj(J6QUpUFjfs5mO $LyAMd);
}
