<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\Hj8CabiR8LqsR;
use Jfs\Uploader\Exception\CIAjwsRYu6S6e;
interface DHtESYY0VyGQJ
{
    public function mdMI6wvUXmN($SJFJj);
    public function me5F3GuvsnI();
    public function m1WocvV9yZy($acaP_);
    public function mJkT9dPY2jE($acaP_);
    public function mPs1JYkvGIi(Hj8CabiR8LqsR $XrQRK);
}
