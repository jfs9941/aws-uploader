<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\UGfAXCSEERPE4;
use Jfs\Uploader\Exception\R2XNcytHoXlGH;
interface FTr6mgGRFf157
{
    public function mHWfC8guF82($afpbB);
    public function mdaaKGzzmmM();
    public function mWYAL72rhSp($br6Fr);
    public function mZjlp2Vg5Xs($br6Fr);
    public function mfXOzZaHn0W(UGfAXCSEERPE4 $whZ7q);
}
