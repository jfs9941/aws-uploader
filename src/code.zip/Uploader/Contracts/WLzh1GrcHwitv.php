<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
interface WLzh1GrcHwitv
{
    public function resolvePath($m5Vy1, int $sjEM3 = LrHrisEWQ9E5o::S3);
    public function resolveThumbnail(UfttW7MErNAIK $m5Vy1);
    public function resolvePathForHlsVideo(CpeNYzI7e1ALA $jYLmK, bool $jVzeG = false);
    public function resolvePathForHlsVideos();
}
