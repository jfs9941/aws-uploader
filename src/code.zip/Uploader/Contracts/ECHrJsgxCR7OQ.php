<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
interface ECHrJsgxCR7OQ
{
    public function resolvePath($ahBEB, int $XokUJ = FW54oEnFetVYj::S3);
    public function resolveThumbnail(ZujQPL2bQTbeI $ahBEB);
    public function resolvePathForHlsVideo(G4MP13yRAmltw $WKps1, bool $lFBPm = false);
    public function resolvePathForHlsVideos();
}
