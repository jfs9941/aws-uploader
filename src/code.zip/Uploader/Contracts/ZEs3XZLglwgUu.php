<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\YZqPZlzFpJfK6;
use Jfs\Uploader\Exception\F8y1xdPRStgQx;
interface ZEs3XZLglwgUu
{
    public function mWCCmTIigqB($xLGfv);
    public function mY5IlWisF4J();
    public function mzoKjbCd8Ap($ju62Q);
    public function mxhgqgQ6ejj($ju62Q);
    public function mfE5Wdi7XQV(YZqPZlzFpJfK6 $yF9e5);
}
