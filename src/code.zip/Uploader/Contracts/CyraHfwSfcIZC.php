<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\KQPO3KR6pEPcF;
use Jfs\Uploader\Exception\O21XtZt2mzRw1;
interface CyraHfwSfcIZC
{
    public function mXpDCMvZsDA($yMJh2);
    public function mZCpdFWC2Gg();
    public function ms4OoFrTljH($hrss0);
    public function mcYYCA53urR($hrss0);
    public function mZHCv5SIdJ7(KQPO3KR6pEPcF $mgPoy);
}
