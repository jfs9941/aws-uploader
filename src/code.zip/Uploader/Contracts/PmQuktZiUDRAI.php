<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
interface PmQuktZiUDRAI
{
    public function resolvePath($mCZRt, int $wLwvk = Ef6Dy6MoUDei9::S3);
    public function resolveThumbnail(GSmU4C9IL4AGB $mCZRt);
    public function resolvePathForHlsVideo(AelPShnd8pMtD $aHaxS, bool $gnS3j = false);
    public function resolvePathForHlsVideos();
}
