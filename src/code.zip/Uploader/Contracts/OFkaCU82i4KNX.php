<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\C3XDkOI7yIIoE;
use Jfs\Uploader\Exception\EJQS1ugI78hby;
interface OFkaCU82i4KNX
{
    public function mJpZf64FjYj($QTUt4);
    public function maSrsWE3jGR();
    public function ml2jBQKKXoS($dAE3r);
    public function mVGpa3lMgLf($dAE3r);
    public function m4opzeov9Jg(C3XDkOI7yIIoE $fRUWH);
}
