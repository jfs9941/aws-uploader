<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Contracts; use Jfs\Uploader\Exception\NNBHyxy5vtJ7v; interface WrFez6oTdpaJs { public function mui5JkXMWEZ($f5blI); public function mAD6yJhPvUy(); public function mm4o1sFzBqc($ZVAXY); public function mVbI1isl7hM($ZVAXY); public function mkeqYGP0mLa(B1wLFQApebIoO $W8RO1); }
