<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
interface XuIaPR4PMryqL
{
    public function resolvePath($LiWvx, int $NjcWd = Tq4KHV0o6oTIo::S3);
    public function resolveThumbnail(Fd8NTWwq2cQOc $LiWvx);
    public function resolvePathForHlsVideo(JbxOPjx4A3DUY $Uas5p, bool $S_18w = false);
    public function resolvePathForHlsVideos();
}
