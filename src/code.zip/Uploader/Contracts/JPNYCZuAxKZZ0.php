<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PQEhKbCWody73;
interface JPNYCZuAxKZZ0
{
    public function resolvePath($X1FNu, int $jP_kU = PQEhKbCWody73::S3);
    public function resolveThumbnail(UBZJTNaXyHRoY $X1FNu);
    public function resolvePathForHlsVideo(ZWik6jMzUez6v $QF71q, bool $vWZ4D = false);
    public function resolvePathForHlsVideos();
}
