<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
interface T1J9j7WqyAUZ6
{
    public function resolvePath($WtNuf, int $WCiFa = NZ0k4EM0XOGE7::S3);
    public function resolveThumbnail(GGOMDClEFMcsH $WtNuf);
    public function resolvePathForHlsVideo(HS7SZ3rYPI80t $ZtI9P, bool $AZVuE = false);
    public function resolvePathForHlsVideos();
}
