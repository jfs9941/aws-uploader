<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\YhOLLtTXuTxXo;
use Jfs\Uploader\Exception\JTzKeriqU61FK;
interface IzCykbeCOYPNB
{
    public function mQ7dAxBkFij($AXUB2);
    public function mq5z1mFF1Xu();
    public function m7ddHwazacD($y6lx_);
    public function mlAr8GJp5gl($y6lx_);
    public function mf8n37ngIzn(YhOLLtTXuTxXo $l0Llu);
}
