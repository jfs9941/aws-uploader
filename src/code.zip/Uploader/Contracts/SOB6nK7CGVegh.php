<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\WsCsRu4iqCZ5i;
use Jfs\Uploader\Exception\BC4l4MMxB4wtt;
interface SOB6nK7CGVegh
{
    public function mUg6EMktQTd($zDAn_);
    public function mUNLIZc6kAe();
    public function mAPPeV3mHXi($V30xu);
    public function m9fp6Fqioui($V30xu);
    public function mdS7hIgNvPC(WsCsRu4iqCZ5i $qAlaY);
}
