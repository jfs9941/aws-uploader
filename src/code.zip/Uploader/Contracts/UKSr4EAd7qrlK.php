<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
interface UKSr4EAd7qrlK
{
    public function resolvePath($wpJD9, int $DzFpv = VCKF0xK25vLxq::S3);
    public function resolveThumbnail(HJJu0xs0QACaQ $wpJD9);
    public function resolvePathForHlsVideo(S25BfMDKrX8cB $DuZ1o, bool $Xl3ZR = false);
    public function resolvePathForHlsVideos();
}
