<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\LiA5BOk62pit2;
interface EknRcwWhw5aDZ
{
    public function mfeKnFzyMNC($MUSXC);
    public function mFO6EVg3QJi();
    public function m3irf1LtLKT($kncXe);
    public function mvgtahNetNS($kncXe);
    public function m0Ku2PvnNzM(CPWst5X7YKGnu $Vpy3e);
}
