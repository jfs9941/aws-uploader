<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\IlXdNMxZGcSoS;
use Jfs\Uploader\Exception\CBStNIBT6cwK0;
interface Fk274vNY0LJnp
{
    public function mJf7701KMEl($E9rq6);
    public function mxqE5nOdX4O();
    public function mpDdU9lVtpc($c3txX);
    public function mTMqJijgtYL($c3txX);
    public function m3qxyKjPsWx(IlXdNMxZGcSoS $UPDiG);
}
