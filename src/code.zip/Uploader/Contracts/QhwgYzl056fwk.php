<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
interface QhwgYzl056fwk
{
    public function resolvePath($qRTR9, int $doABn = WG4kCv0INtCV4::S3);
    public function resolveThumbnail(UKWxL8i4Jx2NZ $qRTR9);
    public function resolvePathForHlsVideo(GXtnGiMmIPEIc $aiCaH, bool $pAoAm = false);
    public function resolvePathForHlsVideos();
}
