<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
interface Jhd15nso8PpYk
{
    public function resolvePath($lOhz0, int $tbIVu = YOaiWCgFM7tRK::S3);
    public function resolveThumbnail(Rqw1PJIt1YU1r $lOhz0);
    public function resolvePathForHlsVideo(NYx4mhlHSMgHF $JhYqb, bool $zVZeW = false);
    public function resolvePathForHlsVideos();
}
