<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\CWn6V46ojDVJy;
interface HpFoUL2Zq7Sem
{
    public function mn9R5wxLm2K($KMCCs);
    public function mEu3Vs3SlRo();
    public function mhK1eUHzFBK($VszfX);
    public function m8kjqHcwUSC($VszfX);
    public function mMajp12kCYR(Hx13AKbJdXa2m $r2Rvs);
}
