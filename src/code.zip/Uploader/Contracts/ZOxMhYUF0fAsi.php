<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
interface ZOxMhYUF0fAsi
{
    public function resolvePath($Mhc38, int $TYPZ5 = KPpxBU3Qc8yRk::S3);
    public function resolveThumbnail(DYGJpbj9Ye8wY $Mhc38);
    public function resolvePathForHlsVideo(QdnSnf08v9RV7 $KuX31, bool $yAUVl = false);
    public function resolvePathForHlsVideos();
}
