<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\B2PcuiERDfNqQ;
interface PxTzgsobiHpcX
{
    public function mt6YUzzNxIA($S1dGW);
    public function mP8O9noVOj4();
    public function mSAdKjgXIhj($z14eN);
    public function md87bJuqFS7($z14eN);
    public function mW7YosDFYf5(Ey23NHBM8rqSI $lbWZH);
}
