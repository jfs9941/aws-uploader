<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
interface LlbXoUBShkgwJ
{
    public function resolvePath($p2x5d, int $PAfML = I2Tze5VZcqaXS::S3);
    public function resolveThumbnail(MXbLxov2QPqm4 $p2x5d);
    public function resolvePathForHlsVideo(UMeQT1ArE1U05 $eYbzj, bool $Yid4s = false);
    public function resolvePathForHlsVideos();
}
