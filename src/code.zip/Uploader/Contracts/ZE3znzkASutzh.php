<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\IYQ9W9yMaFIDi;
use Jfs\Uploader\Exception\FLUrTiCUjjZmC;
interface ZE3znzkASutzh
{
    public function mOJCH6BWZYm($KR5Fj);
    public function mG5vMQvDIJu();
    public function mvj3nnnI629($WWRmp);
    public function msz7cd4Kawd($WWRmp);
    public function m1QMTCQtDK5(IYQ9W9yMaFIDi $IbbWh);
}
