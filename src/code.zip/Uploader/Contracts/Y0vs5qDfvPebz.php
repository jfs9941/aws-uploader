<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\Vkv9DR78jqmXg;
interface Y0vs5qDfvPebz
{
    public function msLvxB5AWdO($EyXDL);
    public function mrZyem1XtDy();
    public function mvUghb89hzW($EmXmH);
    public function mlP84cezeNz($EmXmH);
    public function mFPrsEX7dNQ(BC3GCfM107Y7V $JiKZ8);
}
