<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
interface QmpIhYv3zjvt7
{
    public function resolvePath($Zt12Z, int $LvK26 = Tfi7lQDVWUJD9::S3);
    public function resolveThumbnail(THrRXrYMGJt0m $Zt12Z);
    public function resolvePathForHlsVideo(M7oTJdNm24KG4 $oS5x2, bool $TsCWA = false);
    public function resolvePathForHlsVideos();
}
