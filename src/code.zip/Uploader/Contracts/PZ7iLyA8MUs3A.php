<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
interface PZ7iLyA8MUs3A
{
    public function resolvePath($jKCuO, int $EWvJO = KkaUVP3OQvOtp::S3);
    public function resolveThumbnail(F43pNWIrUhz3z $jKCuO);
    public function resolvePathForHlsVideo(J7sRaWo8um3yO $lamFK, bool $v_5PG = false);
    public function resolvePathForHlsVideos();
}
