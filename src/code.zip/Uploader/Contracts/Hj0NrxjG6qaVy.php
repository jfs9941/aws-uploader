<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
interface Hj0NrxjG6qaVy
{
    public function resolvePath($csSew, int $GWbyt = ZBLpZ2qUZ4P6C::S3);
    public function resolveThumbnail(O4HsadxAyKjYq $csSew);
    public function resolvePathForHlsVideo(RVcEF1JsGQd8M $Ipllx, bool $t6Po9 = false);
    public function resolvePathForHlsVideos();
}
