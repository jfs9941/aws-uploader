<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\QnQF56ZOfQE7U;
use Jfs\Uploader\Exception\GRAfJLmbKXpoS;
interface Zv4WZkC8rwgvt
{
    public function mA93Wx3HDpN($XEy6K);
    public function mUMAxf3SZcL();
    public function mRU2TqSePcC($iU4US);
    public function mjCBkFKp7Xv($iU4US);
    public function meWhUv2FYYU(QnQF56ZOfQE7U $cLHO5);
}
