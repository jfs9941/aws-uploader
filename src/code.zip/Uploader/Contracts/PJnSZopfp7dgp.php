<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
interface PJnSZopfp7dgp
{
    public function resolvePath($JAP4V, int $cNS3s = FEDy7ethdaFTX::S3);
    public function resolveThumbnail(OLbbi5g81G7dU $JAP4V);
    public function resolvePathForHlsVideo(BJhQlhWHvJ3Iz $muzRm, bool $hLhHB = false);
    public function resolvePathForHlsVideos();
}
