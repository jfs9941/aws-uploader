<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
interface O79PdR1cao6Xq
{
    public function resolvePath($pDny3, int $Cnmk0 = GoWVLKcTGnffy::S3);
    public function resolveThumbnail(OXsaQ69LP2fiA $pDny3);
    public function resolvePathForHlsVideo(VHp3UACVYl357 $bKijV, bool $Yj8qC = false);
    public function resolvePathForHlsVideos();
}
