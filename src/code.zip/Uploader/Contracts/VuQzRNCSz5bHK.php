<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\ZcCh1gvC4ktYJ;
use Jfs\Uploader\Exception\VPhlMhTTl80vP;
interface VuQzRNCSz5bHK
{
    public function m651SlcakeY($iXerz);
    public function mAnbgmvjOCA();
    public function mddb9WvMqo9($phjis);
    public function mnlnhRwyESd($phjis);
    public function m2Ak24UoC8E(ZcCh1gvC4ktYJ $ep7NG);
}
