<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
interface FK56xL1HuXbff
{
    public function resolvePath($F251H, int $Mf3Ow = L2PWLPeQEFi6U::S3);
    public function resolveThumbnail(HtHJXf7xellNX $F251H);
    public function resolvePathForHlsVideo(ISYJHQo8eqdfc $qNHE7, bool $QBBdE = false);
    public function resolvePathForHlsVideos();
}
