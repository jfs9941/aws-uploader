<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\D1gefDsblgSHh;
use Jfs\Uploader\Exception\D2GpNcz5KiI9K;
interface H1Ax5lj0mb7kw
{
    public function mMTZSzpDsC7($SfXjy);
    public function m1mmBreyOae();
    public function mVhOJ1PgG8J($vS1iO);
    public function m7rh7ElFKF0($vS1iO);
    public function mj3Wprz3dA2(D1gefDsblgSHh $t9UUt);
}
