<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
interface Ijay4AiPvrqAE
{
    public function resolvePath($tzY18, int $dHaKA = Rf7fPQasmK9R3::S3);
    public function resolveThumbnail(ZZfsW9KHWsMrx $tzY18);
    public function resolvePathForHlsVideo(IvT3V5jT5KEaA $IrxWj, bool $yPpDu = false);
    public function resolvePathForHlsVideos();
}
