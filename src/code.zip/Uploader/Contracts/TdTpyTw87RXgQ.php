<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
interface TdTpyTw87RXgQ
{
    public function resolvePath($SmLAm, int $wU0QX = ZuZC67ch9j73R::S3);
    public function resolveThumbnail(OavRsjNQCayKr $SmLAm);
    public function resolvePathForHlsVideo(IfBHv1AJhiIDu $dajVn, bool $B8mhH = false);
    public function resolvePathForHlsVideos();
}
