<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\MJPdrg0mCs2vV;
use Jfs\Uploader\Exception\JgcJVhkHS65KD;
interface CxOTyXYpS0zWZ
{
    public function m92yZMBK6RM($wV7dw);
    public function mbd0F0eTv6M();
    public function mmrYWGPqYWx($KS0mG);
    public function mytWJ4fODQP($KS0mG);
    public function m4PcztHRQdJ(MJPdrg0mCs2vV $prRSb);
}
