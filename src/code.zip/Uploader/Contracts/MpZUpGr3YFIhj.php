<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
interface MpZUpGr3YFIhj
{
    public function resolvePath($HpL55, int $yXj4Q = GrPXtp41lLmde::S3);
    public function resolveThumbnail(Dup6KVtAFNCUq $HpL55);
    public function resolvePathForHlsVideo(CSQMvXC33KbbS $vtvs_, bool $w_8cE = false);
    public function resolvePathForHlsVideos();
}
