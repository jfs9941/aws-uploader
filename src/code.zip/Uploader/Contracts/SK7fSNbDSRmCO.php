<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\J0z9iIrDgeD3q;
interface SK7fSNbDSRmCO
{
    public function m3zp1EoQeXc($Z7ZNw);
    public function m01hr3e5beG();
    public function mGQfJhYWpvR($fF5wM);
    public function mE2Ndk2lqWA($fF5wM);
    public function mqyYIlRyjYD(RoTpJhiFhvlTg $SYYsP);
}
