<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
interface ZBw3vE9HMeZfI
{
    public function resolvePath($aB0a5, int $N4v2t = I5kpK7wkbRQvu::S3);
    public function resolveThumbnail(MIyg7KY6jn9L1 $aB0a5);
    public function resolvePathForHlsVideo(VPegVN4NByLqJ $fTkob, bool $bRIpC = false);
    public function resolvePathForHlsVideos();
}
