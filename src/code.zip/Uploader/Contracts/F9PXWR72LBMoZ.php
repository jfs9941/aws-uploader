<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\I2OiS2IsDF9Mg;
use Jfs\Uploader\Exception\ZKaX19yQXS7pD;
interface F9PXWR72LBMoZ
{
    public function muKqrdnPhRb($fDztD);
    public function mApCoZ7yL4y();
    public function mI0VzEtubJR($NwBBE);
    public function m1UGbqVuxLg($NwBBE);
    public function mPghak6SKwq(I2OiS2IsDF9Mg $djnua);
}
