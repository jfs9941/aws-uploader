<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Contracts;

use backup\Uploader\Contracts\A2uS8gTe46deJ;
use backup\Uploader\Exception\Y86LODF9txYbT;
interface VnrpqIkXJe1mn
{
    public function mV7ZhSMguWB($ni0Np);
    public function my6DStzzyLq();
    public function mKOiTrzpM4V($p028t);
    public function m9wYtYzHR4p($p028t);
    public function mJOjnVefuIu(A2uS8gTe46deJ $tSe8y);
}
