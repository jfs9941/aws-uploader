<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\BtFXMjsbQEzWB;
interface BCa3K9pPFzXM0
{
    public function m3B430t4QRf($wYQHI);
    public function mMgSU2dRNmq();
    public function mhWKUa6jAoa($xPckJ);
    public function mUTz4zjaBVf($xPckJ);
    public function mCa4XumvZrx(GMMSgBcs5XImF $XSNUB);
}
