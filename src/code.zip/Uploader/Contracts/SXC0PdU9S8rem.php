<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
interface SXC0PdU9S8rem
{
    public function resolvePath($I80en, int $bwFaL = ISqBWmYzjt1eQ::S3);
    public function resolveThumbnail(Z3KXO9qO3sUsa $I80en);
    public function resolvePathForHlsVideo(SNpic2wzC1yT8 $fxrDr, bool $TzR45 = false);
    public function resolvePathForHlsVideos();
}
