<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
interface AbPtLXucv9ja8
{
    public function resolvePath($D_Z4Z, int $E6W0h = PdN71mQX1JeZG::S3);
    public function resolveThumbnail(OWEQTdXGAAFta $D_Z4Z);
    public function resolvePathForHlsVideo(N1wF7eNF4lYgo $JfLWA, bool $rkKq3 = false);
    public function resolvePathForHlsVideos();
}
