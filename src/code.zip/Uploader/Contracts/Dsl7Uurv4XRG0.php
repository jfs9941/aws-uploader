<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\OZ0OEimEhcPCG;
use Jfs\Uploader\Exception\GpiFZublserD8;
interface Dsl7Uurv4XRG0
{
    public function m4fwFyIs4eQ($RLBa6);
    public function m77im0T0GhR();
    public function muggTul6CGA($AP53G);
    public function mGMwsxAyT6N($AP53G);
    public function mi2D2FjJnRk(OZ0OEimEhcPCG $zR8s0);
}
