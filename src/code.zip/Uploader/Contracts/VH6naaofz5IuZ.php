<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\KVgPdowMikNnK;
interface VH6naaofz5IuZ
{
    public function mkv7RuyOFPh($Qm3Xo);
    public function mnTygRN8xMs();
    public function mY8gUThQFjU($f40nf);
    public function mVt3TUg4ptP($f40nf);
    public function mcp2uALDwNg(F66VaMRGSfxoM $iarXb);
}
