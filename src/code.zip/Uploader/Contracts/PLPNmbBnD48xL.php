<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\PLHq1RdJfseHT;
use Jfs\Uploader\Exception\HAdknCimVLDdp;
interface PLPNmbBnD48xL
{
    public function mdigVxgooZG($d8O7F);
    public function mP9I7YdWSoJ();
    public function mo8ljKgMJTJ($kBGa4);
    public function mbkerlcx7kr($kBGa4);
    public function mowZJc7KWzQ(PLHq1RdJfseHT $H_p02);
}
