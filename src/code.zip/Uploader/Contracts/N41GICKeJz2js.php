<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\Xg08pDZLenaCo;
use Jfs\Uploader\Exception\SlPIHqOmIQ9pI;
interface N41GICKeJz2js
{
    public function mtNisNH4NQd($qjpMl);
    public function mkME0lMOO9k();
    public function mKP20BPk5QC($xPw_b);
    public function m5dfjsbYcbp($xPw_b);
    public function mQp3zHVoxcU(Xg08pDZLenaCo $EhlXo);
}
