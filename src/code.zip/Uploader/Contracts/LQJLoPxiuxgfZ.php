<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
interface LQJLoPxiuxgfZ
{
    public function resolvePath($zacay, int $YKOlB = X4ZiOQdPeeHKI::S3);
    public function resolveThumbnail(AtQh9cRLX7xL8 $zacay);
    public function resolvePathForHlsVideo(UYo98bF5lKEmO $EVGvq, bool $r0jD0 = false);
    public function resolvePathForHlsVideos();
}
