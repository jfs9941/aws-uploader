<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\Pr07JVh1ChqJO;
use Jfs\Uploader\Exception\Vfh0JNvlNsuXG;
interface WZhCwGsxQbxug
{
    public function myjAI8i1TR7($CAMPq);
    public function mOukRivI0jG();
    public function mtyCvJ3PeFW($WZaZ9);
    public function mDyZeMdHaEJ($WZaZ9);
    public function mmI31EdIVP7(Pr07JVh1ChqJO $yaRZh);
}
