<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
interface VjEI9Nu3TyWfD
{
    public function resolvePath($jBims, int $Z9PFQ = CUySMhqlL7P49::S3);
    public function resolveThumbnail(EpIpyfdFnoTz6 $jBims);
    public function resolvePathForHlsVideo(RhdJGUi8FOLBJ $UUt0Z, bool $bebcO = false);
    public function resolvePathForHlsVideos();
}
