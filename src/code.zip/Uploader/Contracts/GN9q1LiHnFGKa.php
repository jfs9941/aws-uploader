<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
interface GN9q1LiHnFGKa
{
    public function resolvePath($PK0_J, int $WpjdV = TpPQGsuK0gyw2::S3);
    public function resolveThumbnail(UXdXfw71iQGkx $PK0_J);
    public function resolvePathForHlsVideo(D6fOq8lm3n7T2 $uA7Bz, bool $tDsiv = false);
    public function resolvePathForHlsVideos();
}
