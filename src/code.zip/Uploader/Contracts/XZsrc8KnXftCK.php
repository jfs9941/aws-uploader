<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\SwRmuIL9tuB7h;
interface XZsrc8KnXftCK
{
    public function mnZV8lryeWr($vqPY2);
    public function m7gMMC7rySi();
    public function mTKyaraJgz7($VBB0y);
    public function mvZTZMNfb23($VBB0y);
    public function mxt7Kk7QeSS(P7eZRarQfx9Id $NOB4Z);
}
