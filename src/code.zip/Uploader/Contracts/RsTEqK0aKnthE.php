<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\PzqA3QfUmhhMJ;
use Jfs\Uploader\Exception\LjuaNh4VOaOkF;
interface RsTEqK0aKnthE
{
    public function mf3bcS2aSK5($A4X8f);
    public function mapuydun1zI();
    public function muO5nIQPKS7($K1saJ);
    public function mQ6BIo8HH5r($K1saJ);
    public function mv8Sk2uSFhz(PzqA3QfUmhhMJ $OGjYt);
}
