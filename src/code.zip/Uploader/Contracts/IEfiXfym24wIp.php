<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\DQNrWKzuuQ4gB;
interface IEfiXfym24wIp
{
    public function myNb3hyTkbG($wlB71);
    public function mrRYM4n2w86();
    public function mNT1f7OoTvx($za9WY);
    public function m7P8dZQ9tY8($za9WY);
    public function m7NixpKJfrg(OrgzWokuJzoYp $eMwxR);
}
