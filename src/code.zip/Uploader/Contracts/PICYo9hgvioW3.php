<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Contracts; use Jfs\Uploader\Core\J5wym0qxH1hlR; use Jfs\Uploader\Core\OgXvS9KDq1Lql; use Jfs\Uploader\Enum\FileDriver; interface PICYo9hgvioW3 { public function resolvePath($zSEOq, int $VbqH4 = FileDriver::S3); public function resolveThumbnail(J5wym0qxH1hlR $zSEOq); public function resolvePathForHlsVideo(OgXvS9KDq1Lql $mzQW8, bool $aNxOc = false); public function resolvePathForHlsVideos(); }
