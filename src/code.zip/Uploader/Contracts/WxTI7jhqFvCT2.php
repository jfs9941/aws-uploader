<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\ObP0zC4B5AwYR;
use Jfs\Uploader\Exception\C3neahanZnmCi;
interface WxTI7jhqFvCT2
{
    public function mwXAZfE1o5C($ZGYgr);
    public function mfgBN363TBZ();
    public function miTV603ASKT($wR1lC);
    public function mDu3UKSNIu6($wR1lC);
    public function mA52tsoDAqT(ObP0zC4B5AwYR $AfqaA);
}
