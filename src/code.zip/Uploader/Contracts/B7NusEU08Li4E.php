<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\A1DrGQVhPKB54;
use Jfs\Uploader\Exception\LDB12Ub0rXHOx;
interface B7NusEU08Li4E
{
    public function moSEUBFRxDt($mJSqa);
    public function m3tBiWBZHYC();
    public function mfzy7DteKHJ($POArZ);
    public function mAtXjSpgm10($POArZ);
    public function mme8vGqglZH(A1DrGQVhPKB54 $qIsdv);
}
