<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\DTlKOLT8tkTnv;
interface QBvcnDryrzxsL
{
    public function mhnYveV1r0A($DqhVQ);
    public function m2jjzfjGLGF();
    public function meQCGHEeK80($ZJBuU);
    public function mO6zkoxFvn7($ZJBuU);
    public function m3FXSxRxwBi(Fg5ZctnJZvYzy $jKPS6);
}
