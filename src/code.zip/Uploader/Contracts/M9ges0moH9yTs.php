<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\HA83jJulZGJMz;
interface M9ges0moH9yTs
{
    public function mM8xXTkFSyC($cHJNc);
    public function mmihNChVYRn();
    public function mZunb8ueiKo($CqnA0);
    public function mnvJnuvaU99($CqnA0);
    public function mPleB6N0Rmu(DiGhNuHXqO8Po $HPyGG);
}
