<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\Iy5htSHK04ggf;
use Jfs\Uploader\Exception\FQ1SutuqCRD5X;
interface LKF23eYmlDs0w
{
    public function mXDdmT111J7($x12KI);
    public function mFQoSZI9l03();
    public function miF5zZlQWZD($ncU1p);
    public function m8dWImzJ4Rt($ncU1p);
    public function m0Xpg1VLHmO(Iy5htSHK04ggf $KwkOi);
}
