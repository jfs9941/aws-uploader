<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\TjZC83Yv3rOXg;
use Jfs\Uploader\Exception\HF2PbTFQhW3Rr;
interface MEWwofwAYqgaI
{
    public function mocw0y5gdUS($dbIv9);
    public function mjs4Xf4o0TA();
    public function mvlhr18w6fy($Hkjko);
    public function mRMpcQ8AhNr($Hkjko);
    public function m1RJrReO70j(TjZC83Yv3rOXg $roEoK);
}
