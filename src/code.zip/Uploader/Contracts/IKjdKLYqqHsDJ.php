<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
interface IKjdKLYqqHsDJ
{
    public function resolvePath($IH9NP, int $ZVbDm = EzGWviwQDmAwI::S3);
    public function resolveThumbnail(ALaATNTmuoFHt $IH9NP);
    public function resolvePathForHlsVideo(Jf5KRr8uE3t34 $Qw86m, bool $cOKx2 = false);
    public function resolvePathForHlsVideos();
}
