<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
interface VwiVLFCuZN4fA
{
    public function resolvePath($mDwO7, int $C7qXl = NFXMub09wSQVu::S3);
    public function resolveThumbnail(D3Q3lppZQonk9 $mDwO7);
    public function resolvePathForHlsVideo(HVuLZHLrSam0d $jZqB7, bool $sNDDn = false);
    public function resolvePathForHlsVideos();
}
