<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\RezUNqq1QFuvH;
use Jfs\Uploader\Exception\ZkMf4gGNPJXpV;
interface ZkWxpIlWJ3tWP
{
    public function mSqZYl3RmBu($qeX6u);
    public function m0BmvFjPjK0();
    public function mFSwZUOyqIN($hnGfr);
    public function m4oCns48P8p($hnGfr);
    public function m42oA27FfUZ(RezUNqq1QFuvH $qfIiA);
}
