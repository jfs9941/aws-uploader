<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Contracts;

use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileDriver;
interface MGwfEiRGIYlUs
{
    public function resolvePath($ymghJ, int $PwWrM = FileDriver::S3);
    public function resolveThumbnail(TvpGfrAj9WMXE $ymghJ);
    public function resolvePathForHlsVideo(YdClVYDRbSDMR $iit8z, bool $W67xp = false);
    public function resolvePathForHlsVideos();
}
