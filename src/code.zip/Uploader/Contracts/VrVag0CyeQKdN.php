<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
interface VrVag0CyeQKdN
{
    public function resolvePath($g1333, int $NigPe = GTmWxMidiCuj0::S3);
    public function resolveThumbnail(Yn8aWzKzROkno $g1333);
    public function resolvePathForHlsVideo(ZSB2cdrwtZpmk $wmU7r, bool $H7KQx = false);
    public function resolvePathForHlsVideos();
}
