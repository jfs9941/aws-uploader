<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\Cwggsm2UPkGtM;
use Jfs\Uploader\Exception\KlKPTBnDHVeRD;
interface BbauDy0pIbj64
{
    public function m36TLWxcxjb($V4EmV);
    public function mbFvG5lOLib();
    public function mG7ZLOSfPOQ($swvrA);
    public function mXaLkebEMhO($swvrA);
    public function mHWivXnN62Y(Cwggsm2UPkGtM $p8ZgW);
}
