<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\AbQOw1WF9dU8u;
use Jfs\Uploader\Exception\VSaAUeOOPZiL5;
interface MB8DYpNdVV1bz
{
    public function mWRFuBOBU6q($oK1mp);
    public function mhA6smQiPVz();
    public function mIiE80g96Fo($mm4RR);
    public function mdI7468YBxf($mm4RR);
    public function mYvBQMWkcb5(AbQOw1WF9dU8u $c2ElO);
}
