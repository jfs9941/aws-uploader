<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
interface LuYApSsjKQvJj
{
    public function resolvePath($XCcud, int $UPm3o = Y9OZ7qWyGdhw2::S3);
    public function resolveThumbnail(Lx6EggVsR2j6q $XCcud);
    public function resolvePathForHlsVideo(O1jfuwJR340k5 $cFlec, bool $z3VTt = false);
    public function resolvePathForHlsVideos();
}
