<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
interface K0dipGcxtVboz
{
    public function resolvePath($Nb_Od, int $uV7lV = Opdj0uZXaMJfa::S3);
    public function resolveThumbnail(NRDoWGrbd9WhU $Nb_Od);
    public function resolvePathForHlsVideo(RhSx2q5xIlh0Y $XFeNv, bool $e_9pG = false);
    public function resolvePathForHlsVideos();
}
