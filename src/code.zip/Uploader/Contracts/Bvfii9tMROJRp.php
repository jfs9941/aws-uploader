<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
interface Bvfii9tMROJRp
{
    public function resolvePath($P82oP, int $RpHBQ = YJGCddWUf6Zu2::S3);
    public function resolveThumbnail(IeEvjRaj1LMmG $P82oP);
    public function resolvePathForHlsVideo(JPkW9ix1EKo3T $qF0aQ, bool $Aq2wX = false);
    public function resolvePathForHlsVideos();
}
