<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
interface TC3rpsU2GuKAE
{
    public function resolvePath($Y6vHu, int $ewvCB = NYPGraEb3Ennl::S3);
    public function resolveThumbnail(LfWCTOqty2Slr $Y6vHu);
    public function resolvePathForHlsVideo(SmhkgG6le5p0r $X0ufS, bool $TiZWw = false);
    public function resolvePathForHlsVideos();
}
