<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
interface E97atJzeJ1gs5
{
    public function resolvePath($BOX5t, int $gaBy3 = R278OrMF6HCNB::S3);
    public function resolveThumbnail(QfVdOZWAlX8Sl $BOX5t);
    public function resolvePathForHlsVideo(B6s4AA1exjQ2T $cZ20c, bool $eH5et = false);
    public function resolvePathForHlsVideos();
}
