<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Contracts;

use src\Uploader\Contracts\F5Xo0te9A5R68;
use src\Uploader\Exception\BUbHQrtyLH6v0;
interface PxmUcH2EZiEWo
{
    public function mRGXJFOfzBv($sEGBh);
    public function m6MwmezzNZD();
    public function mIjUnedc3Mq($LPc0j);
    public function mLGYFHehYqU($LPc0j);
    public function mLnW7ZmkfSj(F5Xo0te9A5R68 $cVXcO);
}
