<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\Z1EmnB00QcmrE;
interface JGFha5eJXVoQK
{
    public function mGG5zG7yPwR($SF4Fs);
    public function mXVq5UqcpxT();
    public function mVwoe0E3Z3I($Tc1lW);
    public function mDz3YYxJlFf($Tc1lW);
    public function mubjGF8zmdt(K6rnLmlRKxy9W $COgXN);
}
