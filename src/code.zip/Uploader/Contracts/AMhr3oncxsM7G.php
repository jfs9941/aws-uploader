<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Contracts\XqdHigMgHoiMC;
use Jfs\Uploader\Exception\Rd9NvFKXhRqmf;
interface AMhr3oncxsM7G
{
    public function maYYBXJYcZK($enoYx);
    public function miwqJbgFIOI();
    public function miBsAvAu0gK($Phdg_);
    public function mMVimETFuhY($Phdg_);
    public function mNCLIs0B4x0(XqdHigMgHoiMC $S5j6A);
}
