<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Exception\Lwo8eDYvrwNYy;
class LDB12Ub0rXHOx extends \Exception implements Lwo8eDYvrwNYy
{
    public function __construct(string $nz45f = '', int $ilwIa = 0, ?\Throwable $ix4ka = null)
    {
        parent::__construct($nz45f, $ilwIa, $ix4ka);
    }
    public static function mMv4ULqFVJn($B5uQ4, $FY_8B, $ZEzpo)
    {
        $nz45f = sprintf('File: %s -> Cannot transition from %s to %s', $B5uQ4, KidkTsWIjmNMb::m5jzQTyv1Oe($FY_8B), KidkTsWIjmNMb::m5jzQTyv1Oe($ZEzpo));
        return new self($nz45f);
    }
}
