<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\MTIDo4nRUs25L;
class Mekt7oJZzvgCe extends \Exception implements MTIDo4nRUs25L
{
    public function __construct(string $lS3wF = '', int $LPAIW = 0, ?\Throwable $wJyN8 = null)
    {
        parent::__construct($lS3wF, $LPAIW, $wJyN8);
    }
}
