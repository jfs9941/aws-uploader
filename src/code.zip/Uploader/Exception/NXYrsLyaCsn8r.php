<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\JdgBxcQ8vJue3;
class NXYrsLyaCsn8r extends \Exception implements JdgBxcQ8vJue3
{
    public function __construct(string $Iaw2g = '', int $fJfek = 0, ?\Throwable $dzN7k = null)
    {
        parent::__construct($Iaw2g, $fJfek, $dzN7k);
    }
}
