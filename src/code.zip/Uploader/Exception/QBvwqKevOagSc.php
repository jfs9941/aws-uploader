<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\UoOxBMnG5qxpc;
class QBvwqKevOagSc extends \Exception implements UoOxBMnG5qxpc
{
}
