<?php
declare(strict_types=1);

namespace Jfs\Uploader\Exception;

class NonAcceptedFileException extends \Exception implements UploadExceptionInterface
{
}
