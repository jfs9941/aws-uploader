<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\QSLgIbnhaBG5b;
class JMVG92vUsx277 extends \Exception implements QSLgIbnhaBG5b
{
    public function __construct(string $k1CkZ = '', int $BTVJJ = 0, ?\Throwable $QLMCJ = null)
    {
        parent::__construct($k1CkZ, $BTVJJ, $QLMCJ);
    }
}
