<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class H3bUArvsKixXt extends \Exception implements VVkdCkcwmm5yK
{
    public function __construct(string $XeWZg = '', int $ba4CS = 0, ?\Throwable $XouZD = null)
    {
        parent::__construct($XeWZg, $ba4CS, $XouZD);
    }
}
