<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class J0z9iIrDgeD3q extends \Exception implements PHgfZpdv6E8PS
{
    public function __construct(string $v_jJB = '', int $x06NY = 0, ?\Throwable $fa61R = null)
    {
        parent::__construct($v_jJB, $x06NY, $fa61R);
    }
    public static function muLvIqLxlsH($y06DH, $INwpd, $nwFuB)
    {
        $v_jJB = sprintf('File: %s -> Cannot transition from %s to %s', $y06DH, RwOJkCXwa9RQz::m2cZQHcfof3($INwpd), RwOJkCXwa9RQz::m2cZQHcfof3($nwFuB));
        return new self($v_jJB);
    }
}
