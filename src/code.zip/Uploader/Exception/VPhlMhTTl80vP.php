<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Exception\LNEIcYe9GpJ6P;
class VPhlMhTTl80vP extends \Exception implements LNEIcYe9GpJ6P
{
    public function __construct(string $w9yxp = '', int $IMcJH = 0, ?\Throwable $jw7b5 = null)
    {
        parent::__construct($w9yxp, $IMcJH, $jw7b5);
    }
    public static function mTTrogQQCwC($InHEz, $Erorm, $nsn2i)
    {
        $w9yxp = sprintf('File: %s -> Cannot transition from %s to %s', $InHEz, ZP6Ky842t6y9Y::mOsm1MUgZP9($Erorm), ZP6Ky842t6y9Y::mOsm1MUgZP9($nsn2i));
        return new self($w9yxp);
    }
}
