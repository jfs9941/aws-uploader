<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\V3E36kR8tXAkr;
class G23CmOAeiHqkm extends \Exception implements V3E36kR8tXAkr
{
    public function __construct(string $BPLvz = '', int $W_FBV = 0, ?\Throwable $xTJQp = null)
    {
        parent::__construct($BPLvz, $W_FBV, $xTJQp);
    }
}
