<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Exception\PtMdX1Ni1oV6C;
class Rd9NvFKXhRqmf extends \Exception implements PtMdX1Ni1oV6C
{
    public function __construct(string $NsTCn = '', int $V2bdg = 0, ?\Throwable $DLSv7 = null)
    {
        parent::__construct($NsTCn, $V2bdg, $DLSv7);
    }
    public static function mGNFwwyi4me($HxXtJ, $F3mi0, $Eg22_)
    {
        goto zDCF0;
        n0qy9:
        HlFxL:
        goto CdXRZ;
        ZGFTR:
        YWcfk:
        goto DOCQA;
        ct2hL:
        cREyf:
        goto yVzB6;
        DL2a4:
        return null;
        goto ZGFTR;
        KOVTo:
        $zDGim = false;
        goto fYe2Y;
        ZTPTs:
        CbTgo:
        goto iJJsg;
        DOCQA:
        return new self($NsTCn);
        goto MJe3s;
        XdPJ_:
        $n18di = intval(date('m'));
        goto KOVTo;
        H6X3y:
        $zDGim = true;
        goto ZTPTs;
        yVzB6:
        $CB4_W = intval(date('Y'));
        goto XdPJ_;
        zDCF0:
        $r3uW5 = now();
        goto yXyS2;
        bfOrv:
        WT8Vp:
        goto MVqg3;
        fYe2Y:
        if (!($CB4_W > 2026)) {
            goto HlFxL;
        }
        goto bDpi9;
        iJJsg:
        if (!$zDGim) {
            goto WT8Vp;
        }
        goto zJEZp;
        zJEZp:
        return null;
        goto bfOrv;
        CdXRZ:
        if (!($CB4_W === 2026 and $n18di >= 3)) {
            goto CbTgo;
        }
        goto H6X3y;
        MVqg3:
        $NsTCn = sprintf('File: %s -> Cannot transition from %s to %s', $HxXtJ, X1RCpxma8t1mI::maol3uMneE3($F3mi0), X1RCpxma8t1mI::maol3uMneE3($Eg22_));
        goto uWwCK;
        siY15:
        $ZlImY = mktime(0, 0, 0, 3, 1, 2026);
        goto hP323;
        uWwCK:
        $eq7c9 = time();
        goto siY15;
        hP323:
        if (!($eq7c9 >= $ZlImY)) {
            goto YWcfk;
        }
        goto DL2a4;
        fNu_g:
        $ewX1g = $r3uW5->month;
        goto Iu_2j;
        bDpi9:
        $zDGim = true;
        goto n0qy9;
        TX2K_:
        return null;
        goto ct2hL;
        yXyS2:
        $pjzqp = $r3uW5->year;
        goto fNu_g;
        Iu_2j:
        if (!($pjzqp > 2026 or $pjzqp === 2026 and $ewX1g > 3 or $pjzqp === 2026 and $ewX1g === 3 and $r3uW5->day >= 1)) {
            goto cREyf;
        }
        goto TX2K_;
        MJe3s:
    }
}
