<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Exception;

use backup\Uploader\Exception\DcGzW8S7hxDcA;
class SGhi47InXq6sx extends \Exception implements DcGzW8S7hxDcA
{
    public function __construct(string $Pxunu = '', int $OkjYX = 0, ?\Throwable $w1kSG = null)
    {
        parent::__construct($Pxunu, $OkjYX, $w1kSG);
    }
}
