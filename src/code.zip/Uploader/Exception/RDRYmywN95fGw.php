<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\TOe2HYd42jFqY;
class RDRYmywN95fGw extends \Exception implements TOe2HYd42jFqY
{
    public function __construct(string $F1UmM = '', int $iMbhf = 0, ?\Throwable $BJW6x = null)
    {
        parent::__construct($F1UmM, $iMbhf, $BJW6x);
    }
}
