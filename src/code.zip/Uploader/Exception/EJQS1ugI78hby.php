<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Exception\Jcpj3W1A28H99;
class EJQS1ugI78hby extends \Exception implements Jcpj3W1A28H99
{
    public function __construct(string $bRSa3 = '', int $Ixh0W = 0, ?\Throwable $BUUPp = null)
    {
        parent::__construct($bRSa3, $Ixh0W, $BUUPp);
    }
    public static function mmqRrMrCey5($S580N, $GWCW8, $XiREy)
    {
        $bRSa3 = sprintf('File: %s -> Cannot transition from %s to %s', $S580N, EHhCBxlsVyz9C::mmT5A9iddtA($GWCW8), EHhCBxlsVyz9C::mmT5A9iddtA($XiREy));
        return new self($bRSa3);
    }
}
