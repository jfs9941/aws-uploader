<?php
declare(strict_types=1);

namespace Jfs\Uploader\Exception;

interface UploadExceptionInterface
{
}
