<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Exception\JdgBxcQ8vJue3;
class HAdknCimVLDdp extends \Exception implements JdgBxcQ8vJue3
{
    public function __construct(string $Iaw2g = '', int $fJfek = 0, ?\Throwable $dzN7k = null)
    {
        parent::__construct($Iaw2g, $fJfek, $dzN7k);
    }
    public static function mxRgvnPjfdI($q8q1b, $Pe_Uv, $Giye0)
    {
        $Iaw2g = sprintf('File: %s -> Cannot transition from %s to %s', $q8q1b, IfP50GBBbx63a::mByMmTDmQS5($Pe_Uv), IfP50GBBbx63a::mByMmTDmQS5($Giye0));
        return new self($Iaw2g);
    }
}
