<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class SwRmuIL9tuB7h extends \Exception implements DGXuz0NLw0qWk
{
    public function __construct(string $RzdJz = '', int $OAyLk = 0, ?\Throwable $XeeBf = null)
    {
        parent::__construct($RzdJz, $OAyLk, $XeeBf);
    }
    public static function mCPjQJhnuDI($ld8Ad, $mHVTr, $VklPN)
    {
        $RzdJz = sprintf('File: %s -> Cannot transition from %s to %s', $ld8Ad, UimQKBIuLCEAO::mYAH0ohn5u7($mHVTr), UimQKBIuLCEAO::mYAH0ohn5u7($VklPN));
        return new self($RzdJz);
    }
}
