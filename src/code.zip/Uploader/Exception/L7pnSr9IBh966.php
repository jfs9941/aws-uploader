<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\DT07HBj1LsSyW;
class L7pnSr9IBh966 extends \Exception implements DT07HBj1LsSyW
{
}
