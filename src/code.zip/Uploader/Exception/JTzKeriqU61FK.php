<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Exception\SO1HJt83yceyi;
class JTzKeriqU61FK extends \Exception implements SO1HJt83yceyi
{
    public function __construct(string $rNGwa = '', int $PdMNE = 0, ?\Throwable $as1Uv = null)
    {
        parent::__construct($rNGwa, $PdMNE, $as1Uv);
    }
    public static function m2MXj68TiOv($arqvy, $dxL4Y, $UAn24)
    {
        $rNGwa = sprintf('File: %s -> Cannot transition from %s to %s', $arqvy, EXecNg2hg7kwl::mx6avlXwStK($dxL4Y), EXecNg2hg7kwl::mx6avlXwStK($UAn24));
        return new self($rNGwa);
    }
}
