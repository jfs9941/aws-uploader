<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\CIJNBoCYHMvZE;
class GA7VkLBBncCae extends \Exception implements CIJNBoCYHMvZE
{
    public function __construct(string $MnFCE = '', int $OlJpv = 0, ?\Throwable $A_9yK = null)
    {
        parent::__construct($MnFCE, $OlJpv, $A_9yK);
    }
}
