<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Exception\ETVFXt5jMf9z2;
class VSaAUeOOPZiL5 extends \Exception implements ETVFXt5jMf9z2
{
    public function __construct(string $wDT7K = '', int $qYj2A = 0, ?\Throwable $CKZDj = null)
    {
        parent::__construct($wDT7K, $qYj2A, $CKZDj);
    }
    public static function mvVCJPHdM77($LpGEK, $W_mDx, $q_88W)
    {
        $wDT7K = sprintf('File: %s -> Cannot transition from %s to %s', $LpGEK, Tbw0jsMnRbOTP::mAXsMM9Dn6R($W_mDx), Tbw0jsMnRbOTP::mAXsMM9Dn6R($q_88W));
        return new self($wDT7K);
    }
}
