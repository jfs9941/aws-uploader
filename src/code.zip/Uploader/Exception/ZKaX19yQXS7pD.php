<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Exception\ABScNHC0OdD6O;
class ZKaX19yQXS7pD extends \Exception implements ABScNHC0OdD6O
{
    public function __construct(string $B3SZv = '', int $pVJcg = 0, ?\Throwable $qdMfS = null)
    {
        parent::__construct($B3SZv, $pVJcg, $qdMfS);
    }
    public static function mu9HcqorPuB($DWjir, $iYabd, $frONe)
    {
        $B3SZv = sprintf('File: %s -> Cannot transition from %s to %s', $DWjir, H7dtWZ2h5WAty::mV5lMae95RF($iYabd), H7dtWZ2h5WAty::mV5lMae95RF($frONe));
        return new self($B3SZv);
    }
}
