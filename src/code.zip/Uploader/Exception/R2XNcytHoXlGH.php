<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Exception\Djg080gjEC7qP;
class R2XNcytHoXlGH extends \Exception implements Djg080gjEC7qP
{
    public function __construct(string $f3oPJ = '', int $LzTId = 0, ?\Throwable $Q8Bgo = null)
    {
        parent::__construct($f3oPJ, $LzTId, $Q8Bgo);
    }
    public static function m79WXbCylqX($B_L9m, $o1IFK, $xCd4J)
    {
        $f3oPJ = sprintf('File: %s -> Cannot transition from %s to %s', $B_L9m, LV0wDYHZInswq::mhcA2hMSbSR($o1IFK), LV0wDYHZInswq::mhcA2hMSbSR($xCd4J));
        return new self($f3oPJ);
    }
}
