<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Exception\PGgwB2RBfa7A8;
class O21XtZt2mzRw1 extends \Exception implements PGgwB2RBfa7A8
{
    public function __construct(string $I6ABO = '', int $Xv7CL = 0, ?\Throwable $rMvRg = null)
    {
        parent::__construct($I6ABO, $Xv7CL, $rMvRg);
    }
    public static function mBFYXaPRWKd($N2oAf, $JPKZa, $J1xt_)
    {
        $I6ABO = sprintf('File: %s -> Cannot transition from %s to %s', $N2oAf, A9q1Lm9l5QixG::mb4CWapr3AG($JPKZa), A9q1Lm9l5QixG::mb4CWapr3AG($J1xt_));
        return new self($I6ABO);
    }
}
