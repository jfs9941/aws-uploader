<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class JTpnMPGceIdOz extends \Exception implements Y8NdlLgabqVta
{
    public function __construct(string $wD17k = '', int $AH9AS = 0, ?\Throwable $A1r36 = null)
    {
        parent::__construct($wD17k, $AH9AS, $A1r36);
    }
}
