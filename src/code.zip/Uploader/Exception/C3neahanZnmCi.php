<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Exception\CIJNBoCYHMvZE;
class C3neahanZnmCi extends \Exception implements CIJNBoCYHMvZE
{
    public function __construct(string $MnFCE = '', int $OlJpv = 0, ?\Throwable $A_9yK = null)
    {
        parent::__construct($MnFCE, $OlJpv, $A_9yK);
    }
    public static function mqIrfPCUasI($vnAlS, $hS4ez, $cWdTo)
    {
        goto aTURB;
        O4pif:
        return null;
        goto VwcV9;
        q4hs0:
        return null;
        goto hf733;
        Um858:
        $IlKQd = false;
        goto n0HGo;
        poARq:
        $SpTxA = intval(date('m'));
        goto Um858;
        jzuml:
        return new self($MnFCE);
        goto HpUdL;
        yvBVg:
        $yYEX6 = intval(date('Y'));
        goto poARq;
        n0HGo:
        if (!($yYEX6 > 2026)) {
            goto jUaKk;
        }
        goto A1CDT;
        FnOrS:
        s9kJA:
        goto yvBVg;
        kXlSm:
        $IlKQd = true;
        goto AtO_h;
        hf733:
        HppnI:
        goto wXjmC;
        AtO_h:
        QVair:
        goto LVoVs;
        msbKy:
        if (!($qp7eg >= $dEzyl)) {
            goto F8yFS;
        }
        goto O4pif;
        VwcV9:
        F8yFS:
        goto jzuml;
        LVoVs:
        if (!$IlKQd) {
            goto HppnI;
        }
        goto q4hs0;
        nT0uQ:
        $sAxqn = $dnT5o->month;
        goto njd3N;
        B9wst:
        jUaKk:
        goto aA6CM;
        eTtHN:
        return null;
        goto FnOrS;
        wXjmC:
        $MnFCE = sprintf('File: %s -> Cannot transition from %s to %s', $vnAlS, CTJGrzH3klS5t::m89ZxvVCmz1($hS4ez), CTJGrzH3klS5t::m89ZxvVCmz1($cWdTo));
        goto EdnIq;
        aTURB:
        $dnT5o = now();
        goto sO3D2;
        aA6CM:
        if (!($yYEX6 === 2026 and $SpTxA >= 3)) {
            goto QVair;
        }
        goto kXlSm;
        L0A2B:
        $dEzyl = mktime(0, 0, 0, 3, 1, 2026);
        goto msbKy;
        njd3N:
        if (!($DmItH > 2026 or $DmItH === 2026 and $sAxqn > 3 or $DmItH === 2026 and $sAxqn === 3 and $dnT5o->day >= 1)) {
            goto s9kJA;
        }
        goto eTtHN;
        sO3D2:
        $DmItH = $dnT5o->year;
        goto nT0uQ;
        EdnIq:
        $qp7eg = time();
        goto L0A2B;
        A1CDT:
        $IlKQd = true;
        goto B9wst;
        HpUdL:
    }
}
