<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\ROE64TwBCBUxG;
class AjL1OQuAtug3p extends \Exception implements ROE64TwBCBUxG
{
    public function __construct(string $kADx2 = '', int $pfdKX = 0, ?\Throwable $PtIal = null)
    {
        parent::__construct($kADx2, $pfdKX, $PtIal);
    }
}
