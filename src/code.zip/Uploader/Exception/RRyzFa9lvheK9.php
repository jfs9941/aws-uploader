<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Exception\W6j2nqUpzWfLh;
class RRyzFa9lvheK9 extends \Exception implements W6j2nqUpzWfLh
{
    public function __construct(string $Fehur = '', int $v1fD0 = 0, ?\Throwable $Xy8cn = null)
    {
        parent::__construct($Fehur, $v1fD0, $Xy8cn);
    }
    public static function mT3R6dlRbiH($hOWbX, $cdAM1, $u7iYc)
    {
        $Fehur = sprintf('File: %s -> Cannot transition from %s to %s', $hOWbX, T93Mcsw1gA3an::mhWKt0DOtK4($cdAM1), T93Mcsw1gA3an::mhWKt0DOtK4($u7iYc));
        return new self($Fehur);
    }
}
