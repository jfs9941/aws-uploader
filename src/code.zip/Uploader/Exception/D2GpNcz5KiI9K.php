<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Exception\TOe2HYd42jFqY;
class D2GpNcz5KiI9K extends \Exception implements TOe2HYd42jFqY
{
    public function __construct(string $F1UmM = '', int $iMbhf = 0, ?\Throwable $BJW6x = null)
    {
        parent::__construct($F1UmM, $iMbhf, $BJW6x);
    }
    public static function m5QMC5hX1oh($poSkG, $FO2CC, $c73SZ)
    {
        $F1UmM = sprintf('File: %s -> Cannot transition from %s to %s', $poSkG, IOOvAXAyKHLW2::m0X45TeGQes($FO2CC), IOOvAXAyKHLW2::m0X45TeGQes($c73SZ));
        return new self($F1UmM);
    }
}
