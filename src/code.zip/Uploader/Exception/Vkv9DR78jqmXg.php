<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\SsxWbUYXracun;
class Vkv9DR78jqmXg extends \Exception implements JZpB9znXz45XZ
{
    public function __construct(string $ciuKz = '', int $k87vy = 0, ?\Throwable $N2jG9 = null)
    {
        parent::__construct($ciuKz, $k87vy, $N2jG9);
    }
    public static function mUQNKsaPCEa($cQqZd, $n8pjE, $BXJJn)
    {
        $ciuKz = sprintf('File: %s -> Cannot transition from %s to %s', $cQqZd, SsxWbUYXracun::m5PT31GdoIa($n8pjE), SsxWbUYXracun::m5PT31GdoIa($BXJJn));
        return new self($ciuKz);
    }
}
