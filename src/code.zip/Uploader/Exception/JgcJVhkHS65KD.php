<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Exception\UoOxBMnG5qxpc;
class JgcJVhkHS65KD extends \Exception implements UoOxBMnG5qxpc
{
    public function __construct(string $Oe6vS = '', int $mDweu = 0, ?\Throwable $olHUV = null)
    {
        parent::__construct($Oe6vS, $mDweu, $olHUV);
    }
    public static function mfWvsPge11F($GhyxD, $zWppj, $JaxjV)
    {
        $Oe6vS = sprintf('File: %s -> Cannot transition from %s to %s', $GhyxD, LlMDscQw21XKp::m23QhOzjeTr($zWppj), LlMDscQw21XKp::m23QhOzjeTr($JaxjV));
        return new self($Oe6vS);
    }
}
