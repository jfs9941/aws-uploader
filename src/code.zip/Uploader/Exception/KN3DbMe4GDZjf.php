<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\W6j2nqUpzWfLh;
class KN3DbMe4GDZjf extends \Exception implements W6j2nqUpzWfLh
{
    public function __construct(string $Fehur = '', int $v1fD0 = 0, ?\Throwable $Xy8cn = null)
    {
        parent::__construct($Fehur, $v1fD0, $Xy8cn);
    }
}
