<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Exception\UsV6gXg4vvmRb;
class GUt8ZmYbCCh9b extends \Exception implements UsV6gXg4vvmRb
{
    public function __construct(string $JC8f7 = '', int $gWrEK = 0, ?\Throwable $C17Nq = null)
    {
        parent::__construct($JC8f7, $gWrEK, $C17Nq);
    }
    public static function m16bUb62auc($J_scC, $W1XEH, $DKKRG)
    {
        $JC8f7 = sprintf('File: %s -> Cannot transition from %s to %s', $J_scC, EpMPhiTVzNYqA::miCdJOmMoxV($W1XEH), EpMPhiTVzNYqA::miCdJOmMoxV($DKKRG));
        return new self($JC8f7);
    }
}
