<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Exception; class ZWq1WJWM9rMgy extends \Exception implements AFYMqZyCYIQfT { public function __construct(string $fi_6O = '', int $tvLTa = 0, ?\Throwable $i39AH = null) { parent::__construct($fi_6O, $tvLTa, $i39AH); } }
