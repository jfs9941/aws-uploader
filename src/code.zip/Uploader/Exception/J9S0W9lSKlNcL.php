<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\PtMdX1Ni1oV6C;
class J9S0W9lSKlNcL extends \Exception implements PtMdX1Ni1oV6C
{
    public function __construct(string $NsTCn = '', int $V2bdg = 0, ?\Throwable $DLSv7 = null)
    {
        parent::__construct($NsTCn, $V2bdg, $DLSv7);
    }
}
