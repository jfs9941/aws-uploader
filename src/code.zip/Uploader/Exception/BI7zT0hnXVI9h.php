<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class BI7zT0hnXVI9h extends \Exception implements Y8NdlLgabqVta
{
    public function __construct(string $wD17k = '', int $AH9AS = 0, ?\Throwable $A1r36 = null)
    {
        parent::__construct($wD17k, $AH9AS, $A1r36);
    }
    public static function msl2PQsd6Fw($mfjeD, $o90sS, $F8PQP)
    {
        $wD17k = sprintf('File: %s -> Cannot transition from %s to %s', $mfjeD, SwAwanZG36Yx6::mVHgpqFt3pc($o90sS), SwAwanZG36Yx6::mVHgpqFt3pc($F8PQP));
        return new self($wD17k);
    }
}
