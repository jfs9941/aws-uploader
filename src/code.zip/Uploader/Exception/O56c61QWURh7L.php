<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class O56c61QWURh7L extends \Exception implements TgEXpMfeg33wx
{
    public function __construct(string $c4jNm = '', int $ZaWfd = 0, ?\Throwable $VH0c0 = null)
    {
        parent::__construct($c4jNm, $ZaWfd, $VH0c0);
    }
}
