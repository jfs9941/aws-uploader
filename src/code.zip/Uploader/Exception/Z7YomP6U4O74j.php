<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\UsV6gXg4vvmRb;
class Z7YomP6U4O74j extends \Exception implements UsV6gXg4vvmRb
{
    public function __construct(string $JC8f7 = '', int $gWrEK = 0, ?\Throwable $C17Nq = null)
    {
        parent::__construct($JC8f7, $gWrEK, $C17Nq);
    }
}
