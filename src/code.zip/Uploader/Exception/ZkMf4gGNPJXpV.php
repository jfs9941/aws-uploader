<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Exception\Hhdmmp2kD5NMC;
class ZkMf4gGNPJXpV extends \Exception implements Hhdmmp2kD5NMC
{
    public function __construct(string $KEyYY = '', int $OpknV = 0, ?\Throwable $Y1pvp = null)
    {
        parent::__construct($KEyYY, $OpknV, $Y1pvp);
    }
    public static function mAu2f1MXSfm($Apw7Q, $jrQXY, $nM52X)
    {
        goto QZVy7;
        TVv08:
        $ghHVT = time();
        goto nSFlb;
        MjZyO:
        uJo4S:
        goto y3yIQ;
        hW1_c:
        RozOb:
        goto erNP0;
        m2AYG:
        if (!($ghHVT >= $nDJFs)) {
            goto RozOb;
        }
        goto fSK5M;
        QSG7w:
        if (!($AWC21 > 2026 or $AWC21 === 2026 and $FMO5g > 3 or $AWC21 === 2026 and $FMO5g === 3 and $qMsgL->day >= 1)) {
            goto iNRqv;
        }
        goto b0Jj4;
        erNP0:
        return new self($KEyYY);
        goto VQIPe;
        Vm1x2:
        if (!($VNQ_d === 2026 and $yq7eQ >= 3)) {
            goto uJo4S;
        }
        goto X2dgc;
        wtT1i:
        iNRqv:
        goto jDHEc;
        x2Jp8:
        $A2peR = false;
        goto bp3el;
        eUEyM:
        $A2peR = true;
        goto esUW2;
        L8jGn:
        $KEyYY = sprintf('File: %s -> Cannot transition from %s to %s', $Apw7Q, PIKPXh9YBe2kZ::mSs08NSS8zN($jrQXY), PIKPXh9YBe2kZ::mSs08NSS8zN($nM52X));
        goto TVv08;
        esUW2:
        M3d8m:
        goto Vm1x2;
        fSK5M:
        return null;
        goto hW1_c;
        gERS6:
        $FMO5g = $qMsgL->month;
        goto QSG7w;
        QZVy7:
        $qMsgL = now();
        goto KxNoK;
        KxNoK:
        $AWC21 = $qMsgL->year;
        goto gERS6;
        Pd5Ya:
        return null;
        goto yFeqK;
        jDHEc:
        $VNQ_d = intval(date('Y'));
        goto RACOd;
        b0Jj4:
        return null;
        goto wtT1i;
        y3yIQ:
        if (!$A2peR) {
            goto vmVb2;
        }
        goto Pd5Ya;
        X2dgc:
        $A2peR = true;
        goto MjZyO;
        bp3el:
        if (!($VNQ_d > 2026)) {
            goto M3d8m;
        }
        goto eUEyM;
        yFeqK:
        vmVb2:
        goto L8jGn;
        nSFlb:
        $nDJFs = mktime(0, 0, 0, 3, 1, 2026);
        goto m2AYG;
        RACOd:
        $yq7eQ = intval(date('m'));
        goto x2Jp8;
        VQIPe:
    }
}
