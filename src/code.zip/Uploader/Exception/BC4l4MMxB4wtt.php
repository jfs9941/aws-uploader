<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Exception\K6VI7nVKWxHDm;
class BC4l4MMxB4wtt extends \Exception implements K6VI7nVKWxHDm
{
    public function __construct(string $ijbhg = '', int $FdVyV = 0, ?\Throwable $gP9w6 = null)
    {
        parent::__construct($ijbhg, $FdVyV, $gP9w6);
    }
    public static function mssOEAN6dJH($uuHkQ, $WpCqr, $HBMDb)
    {
        $ijbhg = sprintf('File: %s -> Cannot transition from %s to %s', $uuHkQ, Xy3InMky6jKYf::mc5mqxprAHB($WpCqr), Xy3InMky6jKYf::mc5mqxprAHB($HBMDb));
        return new self($ijbhg);
    }
}
