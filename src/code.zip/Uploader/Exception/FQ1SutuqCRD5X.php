<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Exception\JH3uLOXwFZBJp;
class FQ1SutuqCRD5X extends \Exception implements JH3uLOXwFZBJp
{
    public function __construct(string $t4bJv = '', int $kaOdP = 0, ?\Throwable $Ksamh = null)
    {
        parent::__construct($t4bJv, $kaOdP, $Ksamh);
    }
    public static function mqUOr2jRFkl($wAkkA, $vIbAa, $GcysJ)
    {
        $t4bJv = sprintf('File: %s -> Cannot transition from %s to %s', $wAkkA, GlPuUJKmzwUJ9::mpXGgXWMkT8($vIbAa), GlPuUJKmzwUJ9::mpXGgXWMkT8($GcysJ));
        return new self($t4bJv);
    }
}
