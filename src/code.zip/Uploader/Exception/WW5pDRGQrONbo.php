<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class WW5pDRGQrONbo extends \Exception implements YXQjZ6dv00yzA
{
    public function __construct(string $d1HYk = '', int $KVSPf = 0, ?\Throwable $oAU30 = null)
    {
        parent::__construct($d1HYk, $KVSPf, $oAU30);
    }
}
