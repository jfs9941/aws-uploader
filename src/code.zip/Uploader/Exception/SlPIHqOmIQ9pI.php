<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Exception\ROE64TwBCBUxG;
class SlPIHqOmIQ9pI extends \Exception implements ROE64TwBCBUxG
{
    public function __construct(string $kADx2 = '', int $pfdKX = 0, ?\Throwable $PtIal = null)
    {
        parent::__construct($kADx2, $pfdKX, $PtIal);
    }
    public static function maZJnuk1mxI($iG1wy, $qzJ9C, $Ug4k1)
    {
        $kADx2 = sprintf('File: %s -> Cannot transition from %s to %s', $iG1wy, Zgh3BZ2JVlG1A::mvAX1q3GDKq($qzJ9C), Zgh3BZ2JVlG1A::mvAX1q3GDKq($Ug4k1));
        return new self($kADx2);
    }
}
