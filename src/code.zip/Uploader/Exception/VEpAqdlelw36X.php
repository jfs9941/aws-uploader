<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\DT07HBj1LsSyW;
class VEpAqdlelw36X extends \Exception implements DT07HBj1LsSyW
{
    public function __construct(string $wZ2gt = '', int $GaZi0 = 0, ?\Throwable $B20pX = null)
    {
        parent::__construct($wZ2gt, $GaZi0, $B20pX);
    }
}
