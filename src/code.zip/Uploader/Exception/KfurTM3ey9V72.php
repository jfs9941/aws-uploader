<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\AHFONmc886Mwh;
class KfurTM3ey9V72 extends \Exception implements AHFONmc886Mwh
{
}
