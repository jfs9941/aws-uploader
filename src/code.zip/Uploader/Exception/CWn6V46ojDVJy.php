<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class CWn6V46ojDVJy extends \Exception implements TgEXpMfeg33wx
{
    public function __construct(string $c4jNm = '', int $ZaWfd = 0, ?\Throwable $VH0c0 = null)
    {
        parent::__construct($c4jNm, $ZaWfd, $VH0c0);
    }
    public static function mgVNMqBzmQt($ElvKF, $fz_Ev, $vMDsG)
    {
        $c4jNm = sprintf('File: %s -> Cannot transition from %s to %s', $ElvKF, Q5pXt73hTeTVP::mneKfIOKDpt($fz_Ev), Q5pXt73hTeTVP::mneKfIOKDpt($vMDsG));
        return new self($c4jNm);
    }
}
