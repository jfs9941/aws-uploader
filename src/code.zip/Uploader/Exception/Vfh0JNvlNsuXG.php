<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Exception\IMJSvjjuLIoap;
class Vfh0JNvlNsuXG extends \Exception implements IMJSvjjuLIoap
{
    public function __construct(string $ue6m2 = '', int $Mrp4U = 0, ?\Throwable $L3wDM = null)
    {
        parent::__construct($ue6m2, $Mrp4U, $L3wDM);
    }
    public static function mUetFwhXsNr($GMwD5, $d_LUe, $RNsig)
    {
        $ue6m2 = sprintf('File: %s -> Cannot transition from %s to %s', $GMwD5, Fsm7WCrUwVWh9::mjHb9vwoZ79($d_LUe), Fsm7WCrUwVWh9::mjHb9vwoZ79($RNsig));
        return new self($ue6m2);
    }
}
