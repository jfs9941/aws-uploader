<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Exception\TQ9Yk1T9zx8yT;
class FLUrTiCUjjZmC extends \Exception implements TQ9Yk1T9zx8yT
{
    public function __construct(string $XkhuJ = '', int $T3NEz = 0, ?\Throwable $OoaIb = null)
    {
        parent::__construct($XkhuJ, $T3NEz, $OoaIb);
    }
    public static function mBjKyCB0xNm($qMhfW, $ZfpnJ, $ygS6H)
    {
        $XkhuJ = sprintf('File: %s -> Cannot transition from %s to %s', $qMhfW, TSfaBZEUMcbl0::mBCudTGUcAA($ZfpnJ), TSfaBZEUMcbl0::mBCudTGUcAA($ygS6H));
        return new self($XkhuJ);
    }
}
