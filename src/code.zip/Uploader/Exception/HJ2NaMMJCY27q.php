<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class HJ2NaMMJCY27q extends \Exception implements PHgfZpdv6E8PS
{
    public function __construct(string $v_jJB = '', int $x06NY = 0, ?\Throwable $fa61R = null)
    {
        parent::__construct($v_jJB, $x06NY, $fa61R);
    }
}
