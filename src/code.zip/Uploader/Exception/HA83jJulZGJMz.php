<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\U8OFutptQGm3S;
class HA83jJulZGJMz extends \Exception implements MmlglbwjEj5Rd
{
    public function __construct(string $rpTPm = '', int $NaQSf = 0, ?\Throwable $Fnspq = null)
    {
        parent::__construct($rpTPm, $NaQSf, $Fnspq);
    }
    public static function mxjUjZRKOHB($UcmDx, $VMtUd, $PE2Jh)
    {
        $rpTPm = sprintf('File: %s -> Cannot transition from %s to %s', $UcmDx, U8OFutptQGm3S::msXUEybRP6a($VMtUd), U8OFutptQGm3S::msXUEybRP6a($PE2Jh));
        return new self($rpTPm);
    }
}
