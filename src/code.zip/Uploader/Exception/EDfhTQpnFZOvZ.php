<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class EDfhTQpnFZOvZ extends \Exception implements Zb9Q3O97Pg0PO
{
    public function __construct(string $F6Qnr = '', int $xntmw = 0, ?\Throwable $zC15v = null)
    {
        parent::__construct($F6Qnr, $xntmw, $zC15v);
    }
}
