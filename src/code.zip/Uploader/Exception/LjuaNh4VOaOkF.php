<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Exception\CCligoGfhC5Jt;
class LjuaNh4VOaOkF extends \Exception implements CCligoGfhC5Jt
{
    public function __construct(string $sWqfy = '', int $vaapJ = 0, ?\Throwable $OugZX = null)
    {
        parent::__construct($sWqfy, $vaapJ, $OugZX);
    }
    public static function mD1XSPqgcUD($ShXx2, $sWqd5, $ODckt)
    {
        $sWqfy = sprintf('File: %s -> Cannot transition from %s to %s', $ShXx2, HGmeWpZQSxAlO::mkXK7ZBbBrh($sWqd5), HGmeWpZQSxAlO::mkXK7ZBbBrh($ODckt));
        return new self($sWqfy);
    }
}
