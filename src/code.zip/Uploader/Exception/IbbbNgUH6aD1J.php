<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\Lwo8eDYvrwNYy;
class IbbbNgUH6aD1J extends \Exception implements Lwo8eDYvrwNYy
{
    public function __construct(string $nz45f = '', int $ilwIa = 0, ?\Throwable $ix4ka = null)
    {
        parent::__construct($nz45f, $ilwIa, $ix4ka);
    }
}
