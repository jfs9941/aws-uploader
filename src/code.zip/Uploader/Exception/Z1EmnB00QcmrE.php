<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class Z1EmnB00QcmrE extends \Exception implements YXQjZ6dv00yzA
{
    public function __construct(string $d1HYk = '', int $KVSPf = 0, ?\Throwable $oAU30 = null)
    {
        parent::__construct($d1HYk, $KVSPf, $oAU30);
    }
    public static function mYwZ1uXomWp($IaHim, $qk30u, $PEvWd)
    {
        $d1HYk = sprintf('File: %s -> Cannot transition from %s to %s', $IaHim, QoCMzcKvH8Cw2::mOHxInsAZ17($qk30u), QoCMzcKvH8Cw2::mOHxInsAZ17($PEvWd));
        return new self($d1HYk);
    }
}
