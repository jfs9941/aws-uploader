<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Exception\DT07HBj1LsSyW;
class CBStNIBT6cwK0 extends \Exception implements DT07HBj1LsSyW
{
    public function __construct(string $wZ2gt = '', int $GaZi0 = 0, ?\Throwable $B20pX = null)
    {
        parent::__construct($wZ2gt, $GaZi0, $B20pX);
    }
    public static function mjMcJx6Y5ML($zV1kl, $xWMUH, $JpXTA)
    {
        $wZ2gt = sprintf('File: %s -> Cannot transition from %s to %s', $zV1kl, M7O7NSiJU2JG5::mt3yGqZfFSQ($xWMUH), M7O7NSiJU2JG5::mt3yGqZfFSQ($JpXTA));
        return new self($wZ2gt);
    }
}
