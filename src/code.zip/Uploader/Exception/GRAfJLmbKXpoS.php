<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Exception\VGzf6DP1Zndue;
class GRAfJLmbKXpoS extends \Exception implements VGzf6DP1Zndue
{
    public function __construct(string $xdTZV = '', int $gtq39 = 0, ?\Throwable $vz_xM = null)
    {
        parent::__construct($xdTZV, $gtq39, $vz_xM);
    }
    public static function m328WAEx37K($tu00C, $r7xWj, $EjxDg)
    {
        $xdTZV = sprintf('File: %s -> Cannot transition from %s to %s', $tu00C, WSEQ88VDOa3X0::mrgFfJVaGT3($r7xWj), WSEQ88VDOa3X0::mrgFfJVaGT3($EjxDg));
        return new self($xdTZV);
    }
}
