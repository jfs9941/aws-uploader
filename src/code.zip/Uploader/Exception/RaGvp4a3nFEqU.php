<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Exception\IMJSvjjuLIoap;
class RaGvp4a3nFEqU extends \Exception implements IMJSvjjuLIoap
{
    public function __construct(string $ue6m2 = '', int $Mrp4U = 0, ?\Throwable $L3wDM = null)
    {
        parent::__construct($ue6m2, $Mrp4U, $L3wDM);
    }
}
