<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class DQNrWKzuuQ4gB extends \Exception implements BBjvxpxKhw3RW
{
    public function __construct(string $S4WV0 = '', int $q7lQC = 0, ?\Throwable $DKOWz = null)
    {
        parent::__construct($S4WV0, $q7lQC, $DKOWz);
    }
    public static function mra2P5Zpi1S($eXur0, $T_sla, $mpYXJ)
    {
        $S4WV0 = sprintf('File: %s -> Cannot transition from %s to %s', $eXur0, N4CY6qDTBAjPa::mk7XTENH0zE($T_sla), N4CY6qDTBAjPa::mk7XTENH0zE($mpYXJ));
        return new self($S4WV0);
    }
}
