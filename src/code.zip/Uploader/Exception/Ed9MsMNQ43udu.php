<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class Ed9MsMNQ43udu extends \Exception implements MmlglbwjEj5Rd
{
    public function __construct(string $rpTPm = '', int $NaQSf = 0, ?\Throwable $Fnspq = null)
    {
        parent::__construct($rpTPm, $NaQSf, $Fnspq);
    }
}
