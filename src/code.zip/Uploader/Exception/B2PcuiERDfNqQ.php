<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class B2PcuiERDfNqQ extends \Exception implements W3SLrI2tcnxO5
{
    public function __construct(string $JYgx2 = '', int $KVwvJ = 0, ?\Throwable $ciCny = null)
    {
        parent::__construct($JYgx2, $KVwvJ, $ciCny);
    }
    public static function mzYTkkfqyCU($PV4mw, $h_ywo, $S4E_T)
    {
        $JYgx2 = sprintf('File: %s -> Cannot transition from %s to %s', $PV4mw, O8RzIjGmSN6fG::m9dTK4FAFQo($h_ywo), O8RzIjGmSN6fG::m9dTK4FAFQo($S4E_T));
        return new self($JYgx2);
    }
}
