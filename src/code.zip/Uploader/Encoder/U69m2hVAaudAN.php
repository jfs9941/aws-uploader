<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Service\FTup2pWS3iynB;
use Illuminate\Contracts\Filesystem\Filesystem;
final class U69m2hVAaudAN
{
    public const HdQAO = 'v2/hls/';
    private $m2Fzh;
    private $DksH2;
    public function __construct(FTup2pWS3iynB $WXNzZ, Filesystem $l4Drs)
    {
        $this->m2Fzh = $WXNzZ;
        $this->DksH2 = $l4Drs;
    }
    public function m0j4LnOSNte($oS5x2) : string
    {
        return $this->m2Fzh->mWPnOJO9f3o(self::HdQAO . $oS5x2->getAttribute('id') . '/');
    }
    public function mZkvd9XuLJf($oS5x2) : string
    {
        return $this->m2Fzh->mWPnOJO9f3o(self::HdQAO . $oS5x2->getAttribute('id') . '/thumbnail/');
    }
    public function mrSvcsv3tPY($oS5x2, $zif3R = true) : string
    {
        goto pt7TG;
        T_cqc:
        return $this->m2Fzh->mWPnOJO9f3o(self::HdQAO . $oS5x2->getAttribute('id') . '/' . $oS5x2->getAttribute('id') . '.m3u8');
        goto CwElA;
        pt7TG:
        if ($zif3R) {
            goto Dgn6Y;
        }
        goto gZJ0R;
        RXiUe:
        Dgn6Y:
        goto T_cqc;
        gZJ0R:
        return self::HdQAO . $oS5x2->getAttribute('id') . '/' . $oS5x2->getAttribute('id') . '.m3u8';
        goto RXiUe;
        CwElA:
    }
    public function resolveThumbnail($oS5x2) : string
    {
        goto zUTOf;
        y5m_i:
        return 1 == count($lS7oP) ? self::HdQAO . $EmnXX . '/thumbnail/' . $EmnXX . '.0000000.jpg' : self::HdQAO . $EmnXX . '/thumbnail/' . $EmnXX . '.0000001.jpg';
        goto aiJij;
        KS9D8:
        $lS7oP = $this->DksH2->files($this->mZkvd9XuLJf($oS5x2));
        goto y5m_i;
        zUTOf:
        $EmnXX = $oS5x2->getAttribute('id');
        goto KS9D8;
        aiJij:
    }
    public function maZUaPEk5bi(string $cJV8L) : string
    {
        return $this->DksH2->url($cJV8L);
    }
}
