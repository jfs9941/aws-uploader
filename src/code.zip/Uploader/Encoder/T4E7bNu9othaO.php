<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class T4E7bNu9othaO
{
    private $Et6ec;
    public function __construct(float $s2u07, int $P9dek, string $Uh02m)
    {
        goto Qo4X4;
        a5Xeb:
        $fIeKp = max($fIeKp, 1);
        goto Vb7ae;
        Qo4X4:
        $fIeKp = (int) $s2u07 / $P9dek;
        goto a5Xeb;
        Vb7ae:
        $this->Et6ec = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $fIeKp]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $Uh02m]]];
        goto U4lqI;
        U4lqI:
    }
    public function mc7VJwzlcmw() : array
    {
        return $this->Et6ec;
    }
}
