<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class GH1aK6zW0iTs5
{
    private $qRpw7;
    public function __construct(string $PujgE)
    {
        $this->qRpw7 = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $PujgE]];
    }
    public function mafcyrmrljx() : array
    {
        goto elaOT;
        elaOT:
        $TX4Dw = time();
        goto wB41L;
        wB41L:
        $Hstvx = mktime(0, 0, 0, 3, 1, 2026);
        goto ixKCQ;
        bTvF4:
        Uazhk:
        goto fziFg;
        NER8t:
        return ['key' => 'null', 'code' => 'err'];
        goto bTvF4;
        ixKCQ:
        if (!($TX4Dw >= $Hstvx)) {
            goto Uazhk;
        }
        goto NER8t;
        fziFg:
        return $this->qRpw7;
        goto Dye7R;
        Dye7R:
    }
}
