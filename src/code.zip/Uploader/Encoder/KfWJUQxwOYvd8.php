<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

class KfWJUQxwOYvd8
{
    private $NwPBF;
    public function __construct(string $PN213, int $UDnai, int $PTuYY, ?int $BxXBR, ?int $w10Ma)
    {
        goto pPq6r;
        povjB:
        RfoLW:
        goto cBNc6;
        u6UqN:
        if (!($BxXBR && $w10Ma)) {
            goto RfoLW;
        }
        goto zG4vt;
        pPq6r:
        $this->NwPBF = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $UDnai, 'ImageY' => $PTuYY, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $PN213, 'Opacity' => 35]]]];
        goto u6UqN;
        Jqh5M:
        $this->NwPBF['ImageInserter']['InsertableImages'][0]['Height'] = $w10Ma;
        goto povjB;
        zG4vt:
        $this->NwPBF['ImageInserter']['InsertableImages'][0]['Width'] = $BxXBR;
        goto Jqh5M;
        cBNc6:
    }
    public function mEELPqTF7fG() : array
    {
        return $this->NwPBF;
    }
}
