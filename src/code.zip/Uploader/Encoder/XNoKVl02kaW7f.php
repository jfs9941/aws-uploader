<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Wu1TTCZqWFpNm;
use Jfs\Uploader\Encoder\HYlcVVWzTHXE3;
use Jfs\Uploader\Encoder\AnydI1mi8QjAt;
use Illuminate\Support\Facades\Log;
final class XNoKVl02kaW7f
{
    private $aLBiu;
    private $BsBjV;
    private $LEbBT;
    private $Biest;
    private $w2y_H;
    private $eSHxg;
    private $cOLBZ;
    public function __construct(MediaConvertClient $eCTKl, $LlMC1, $XpYC6)
    {
        goto wV29S;
        UYiSq:
        $this->eSHxg = $XpYC6;
        goto iyniT;
        wV29S:
        $this->Biest = $eCTKl;
        goto oKDXT;
        oKDXT:
        $this->w2y_H = $LlMC1;
        goto UYiSq;
        iyniT:
    }
    public function mAXzg6XzPJ4() : MediaConvertClient
    {
        return $this->Biest;
    }
    public function mTQPJyjSSLG(AnydI1mi8QjAt $oCD7h) : self
    {
        $this->aLBiu = $oCD7h;
        return $this;
    }
    public function mqAfGivyjzw(string $CxJx2) : self
    {
        $this->LEbBT = $CxJx2;
        return $this;
    }
    public function mFyps98x3f5(HYlcVVWzTHXE3 $GhHKd) : self
    {
        $this->BsBjV[] = $GhHKd;
        return $this;
    }
    public function mVuZJqIFVcS(Wu1TTCZqWFpNm $gYP4D) : self
    {
        $this->cOLBZ = $gYP4D;
        return $this;
    }
    private function mnNyCeggJFa(bool $WH_l_) : array
    {
        goto LmWv_;
        kSZnW:
        throw new \LogicException('You must provide a input file to use');
        goto W2Je4;
        LmWv_:
        $pyMqY = (require 'template.php');
        goto c1U7t;
        V1WXA:
        $pyMqY['Settings']['Inputs'] = $this->aLBiu->mw3NWtjvu7d();
        goto anpM4;
        v7oxM:
        if (!$WH_l_) {
            goto mWzwK;
        }
        goto lvmRj;
        Cen9V:
        UzeyC:
        goto lcylg;
        lvmRj:
        $pyMqY['AccelerationSettings']['Mode'] = 'ENABLED';
        goto P1uoi;
        CoU39:
        $pyMqY['Queue'] = $this->eSHxg;
        goto qj8Ky;
        qj8Ky:
        if ($this->aLBiu) {
            goto CbH96;
        }
        goto kSZnW;
        SyKxQ:
        $TolL6['Outputs'] = [];
        goto go6on;
        go6on:
        foreach ($this->BsBjV as $GhHKd) {
            $TolL6['Outputs'][] = $GhHKd->mP8OeZyfu4Q();
            dCSxZ:
        }
        goto Cen9V;
        cXNS2:
        $pyMqY['Settings']['OutputGroups'][] = $this->cOLBZ->mVacz9xkxTF();
        goto QKyge;
        anpM4:
        $TolL6 = $pyMqY['Settings']['OutputGroups'][0];
        goto BNjTU;
        c1U7t:
        $pyMqY['Role'] = $this->w2y_H;
        goto CoU39;
        QKyge:
        D7ezK:
        goto v7oxM;
        YPuq6:
        if (!$this->cOLBZ) {
            goto D7ezK;
        }
        goto cXNS2;
        P6veT:
        $this->cOLBZ = null;
        goto kb6Cr;
        BNjTU:
        unset($pyMqY['Settings']['OutputGroups']);
        goto SyKxQ;
        kb6Cr:
        $this->aLBiu = null;
        goto v6V8G;
        WX8FA:
        $pyMqY['Settings']['OutputGroups'][] = $TolL6;
        goto YPuq6;
        lcylg:
        $TolL6['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->LEbBT;
        goto WX8FA;
        P1uoi:
        mWzwK:
        goto P6veT;
        Ji2hZ:
        return $pyMqY;
        goto EEx6s;
        W2Je4:
        CbH96:
        goto V1WXA;
        v6V8G:
        $this->BsBjV = [];
        goto Ji2hZ;
        EEx6s:
    }
    public function mjExSoX837A(bool $WH_l_ = false) : string
    {
        try {
            $RXeDC = $this->Biest->createJob($this->mnNyCeggJFa($WH_l_));
            return $RXeDC->get('Jobs')['Id'];
        } catch (AwsException $dhJHu) {
            Log::error('Error creating MediaConvert job: ' . $dhJHu->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $dhJHu);
        }
    }
}
