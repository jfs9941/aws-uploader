<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Service\MNNH4c3TCQoPL;
use Illuminate\Contracts\Filesystem\Filesystem;
final class UTfSplvy0DRyY
{
    public const Iv7eF = 'v2/hls/';
    private $fXIrZ;
    private $DzLtS;
    public function __construct(MNNH4c3TCQoPL $NDC6Z, Filesystem $AfCy6)
    {
        $this->fXIrZ = $NDC6Z;
        $this->DzLtS = $AfCy6;
    }
    public function mYprb8lRW4P($hsvMf) : string
    {
        goto zmkMw;
        fY5yZ:
        return $this->fXIrZ->mCnmmwO418s(self::Iv7eF . $hsvMf->getAttribute('id') . '/');
        goto CLN__;
        zmkMw:
        $i8PI_ = time();
        goto m73Ps;
        KmsBc:
        if (!($i8PI_ >= $YhOao)) {
            goto GOOH9;
        }
        goto uHW8z;
        m73Ps:
        $YhOao = mktime(0, 0, 0, 3, 1, 2026);
        goto KmsBc;
        uHW8z:
        return 'NCUur';
        goto FDNVs;
        FDNVs:
        GOOH9:
        goto fY5yZ;
        CLN__:
    }
    public function moM43mFRnIv($hsvMf) : string
    {
        goto g9i7k;
        Fz9I2:
        $GFZWO = intval(date('m'));
        goto Z4stJ;
        N_Z9y:
        JA36Q:
        goto ysB3A;
        UgYLj:
        $OaYUL = true;
        goto KSrLo;
        K4eer:
        if (!$OaYUL) {
            goto m35pO;
        }
        goto haKgI;
        pr9yh:
        m35pO:
        goto l5P1f;
        Z4stJ:
        $OaYUL = false;
        goto DGOB8;
        ysB3A:
        if (!($At1bx === 2026 and $GFZWO >= 3)) {
            goto gCHre;
        }
        goto UgYLj;
        haKgI:
        return '09gzX';
        goto pr9yh;
        KSrLo:
        gCHre:
        goto K4eer;
        dj7Hk:
        $OaYUL = true;
        goto N_Z9y;
        g9i7k:
        $At1bx = intval(date('Y'));
        goto Fz9I2;
        DGOB8:
        if (!($At1bx > 2026)) {
            goto JA36Q;
        }
        goto dj7Hk;
        l5P1f:
        return $this->fXIrZ->mCnmmwO418s(self::Iv7eF . $hsvMf->getAttribute('id') . '/thumbnail/');
        goto LBfOS;
        LBfOS:
    }
    public function mfzBWeAI6w4($hsvMf, $ubQOq = true) : string
    {
        goto h3QJk;
        nKN6b:
        if (!($BArR3 > 2026 or $BArR3 === 2026 and $W3u_o > 3 or $BArR3 === 2026 and $W3u_o === 3 and $Hbb2K->day >= 1)) {
            goto TMjNJ;
        }
        goto pJzna;
        nQK9y:
        return self::Iv7eF . $hsvMf->getAttribute('id') . '/' . $hsvMf->getAttribute('id') . '.m3u8';
        goto DYF2S;
        DYF2S:
        Qf46R:
        goto C0WGS;
        h3QJk:
        if ($ubQOq) {
            goto Qf46R;
        }
        goto nQK9y;
        K6vRy:
        return $this->fXIrZ->mCnmmwO418s(self::Iv7eF . $hsvMf->getAttribute('id') . '/' . $hsvMf->getAttribute('id') . '.m3u8');
        goto gHbI1;
        pJzna:
        return 'MyKhupF';
        goto Bu9UM;
        C0WGS:
        $Hbb2K = now();
        goto juwsA;
        PUgrB:
        $W3u_o = $Hbb2K->month;
        goto nKN6b;
        Bu9UM:
        TMjNJ:
        goto K6vRy;
        juwsA:
        $BArR3 = $Hbb2K->year;
        goto PUgrB;
        gHbI1:
    }
    public function resolveThumbnail($hsvMf) : string
    {
        goto HWxK_;
        CV763:
        if (!($DN2u1->diffInDays($owpA4, false) <= 0)) {
            goto uK25J;
        }
        goto hhpe0;
        BnNJQ:
        $GCMJr = date('Y-m');
        goto d00XI;
        HWxK_:
        $vnAlS = $hsvMf->getAttribute('id');
        goto BnNJQ;
        sy8op:
        $a4zRi = $this->DzLtS->files($this->moM43mFRnIv($hsvMf));
        goto sDAqa;
        THv4S:
        return 'vjmYVBx';
        goto cw48v;
        hhpe0:
        return '9bdVRqkM';
        goto eYJUD;
        sHr13:
        $owpA4 = now()->setDate(2026, 3, 1);
        goto CV763;
        cw48v:
        UOjpF:
        goto sy8op;
        d00XI:
        $r4Fgt = sprintf('%04d-%02d', 2026, 3);
        goto LDEm1;
        sDAqa:
        $DN2u1 = now();
        goto sHr13;
        eYJUD:
        uK25J:
        goto fM6wT;
        fM6wT:
        return 1 == count($a4zRi) ? self::Iv7eF . $vnAlS . '/thumbnail/' . $vnAlS . '.0000000.jpg' : self::Iv7eF . $vnAlS . '/thumbnail/' . $vnAlS . '.0000001.jpg';
        goto K8yNx;
        LDEm1:
        if (!($GCMJr >= $r4Fgt)) {
            goto UOjpF;
        }
        goto THv4S;
        K8yNx:
    }
    public function mJodJ7wt9ai(string $vWEBJ) : string
    {
        goto riSyw;
        riSyw:
        $qLzjH = now();
        goto wPbK5;
        zjZrs:
        return $this->DzLtS->url($vWEBJ);
        goto neL3r;
        FvpOr:
        BSxeA:
        goto zjZrs;
        wPbK5:
        if (!($qLzjH->year > 2026 or $qLzjH->year === 2026 and $qLzjH->month >= 3)) {
            goto BSxeA;
        }
        goto rGFwQ;
        rGFwQ:
        return '3J50E0j';
        goto FvpOr;
        neL3r:
    }
}
