<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class NWhFJkPi8Y0U6
{
    private $LBxSS;
    public function __construct(float $wtVeD, int $s3VgU, string $le7qq)
    {
        goto t98BQ;
        t98BQ:
        $gDcaa = (int) $wtVeD / $s3VgU;
        goto GPIdd;
        j7wqZ:
        $this->LBxSS = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $gDcaa]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $le7qq]]];
        goto qcGZY;
        GPIdd:
        $gDcaa = max($gDcaa, 1);
        goto j7wqZ;
        qcGZY:
    }
    public function mhvVT05QwOr() : array
    {
        return $this->LBxSS;
    }
}
