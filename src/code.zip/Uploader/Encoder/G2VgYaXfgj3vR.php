<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\F6FOYfmciBNIA;
final class G2VgYaXfgj3vR
{
    private $qULvp;
    public function __construct(string $Mfqj_, ?int $w0IG6, ?int $sIm70, float $XcY2o)
    {
        goto idG97;
        ZJ_av:
        if (!($w0IG6 && $sIm70)) {
            goto mwwoE;
        }
        goto v8e0m;
        rKvML:
        $QSd27 = $this->mEtDQg94RAX($w0IG6, $sIm70, $XcY2o);
        goto YEq6h;
        rtbfv:
        if (!($w0IG6 && $sIm70)) {
            goto P2xYp;
        }
        goto rKvML;
        v8e0m:
        $this->qULvp['VideoDescription']['Width'] = $w0IG6;
        goto W7W8T;
        W7W8T:
        $this->qULvp['VideoDescription']['Height'] = $sIm70;
        goto nuW7B;
        YEq6h:
        P2xYp:
        goto jJaMz;
        jJaMz:
        $this->qULvp = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $QSd27, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $Mfqj_];
        goto ZJ_av;
        nuW7B:
        mwwoE:
        goto fkKFD;
        idG97:
        $QSd27 = 15000000;
        goto rtbfv;
        fkKFD:
    }
    public function mx4kaOzrVgN(F6FOYfmciBNIA $aTlSl) : self
    {
        $this->qULvp['VideoDescription']['VideoPreprocessors'] = $aTlSl->mFLdtLE9Fb0();
        return $this;
    }
    public function mES18EGDU3q() : array
    {
        return $this->qULvp;
    }
    private function mEtDQg94RAX(int $w0IG6, int $sIm70, float $HvHKE, string $UPzKW = 'medium', string $dvaWT = 'h264', string $S48Vb = 'good') : ?int
    {
        goto AxImF;
        mfR4J:
        goto rIjDk;
        goto NxDTV;
        Td1kr:
        switch (strtolower($UPzKW)) {
            case 'low':
                $CR2HD *= 0.7;
                goto BXQkU;
            case 'high':
                $CR2HD *= 1.3;
                goto BXQkU;
            case 'veryhigh':
                $CR2HD *= 1.6;
                goto BXQkU;
        }
        goto tH1RZ;
        NUw2L:
        $FDP8S = 3;
        goto wVzjk;
        Hgadn:
        BXQkU:
        goto nUwME;
        tH1RZ:
        ITBy0:
        goto Hgadn;
        nUwME:
        if (!('h265' === strtolower($dvaWT) || 'hevc' === strtolower($dvaWT) || 'vp9' === strtolower($dvaWT))) {
            goto xSS8p;
        }
        goto Z_jJt;
        AxImF:
        $zZK34 = $w0IG6 * $sIm70;
        goto eTXlb;
        LwaXd:
        if ($zZK34 <= 3840 * 2160) {
            goto kzzFR;
        }
        goto ABiDL;
        mSffB:
        CHX4j:
        goto U0WBm;
        X2MqD:
        if ($zZK34 <= 2560 * 1440) {
            goto oJOC9;
        }
        goto LwaXd;
        tn4z2:
        if ($zZK34 <= 1920 * 1080) {
            goto CHX4j;
        }
        goto X2MqD;
        oriCQ:
        Bb_6c:
        goto RXFst;
        JGPD6:
        $CR2HD = $FDP8S * ($HvHKE / 30);
        goto Td1kr;
        uV8bV:
        PQiPp:
        goto zziKK;
        TZGF5:
        xSS8p:
        goto J2wzY;
        dEqKw:
        $FDP8S = 20;
        goto adgB3;
        adgB3:
        rIjDk:
        goto JGPD6;
        tdtZo:
        if ($zZK34 <= 1280 * 720) {
            goto RqXna;
        }
        goto tn4z2;
        nSxS7:
        $CR2HD = max(0.5, $CR2HD);
        goto gf0EI;
        POzIG:
        $FDP8S = 12;
        goto mfR4J;
        zziKK:
        SBzG9:
        goto nSxS7;
        J2wzY:
        switch (strtolower($S48Vb)) {
            case 'low':
                $CR2HD *= 0.8;
                goto SBzG9;
            case 'high':
                $CR2HD *= 1.2;
                goto SBzG9;
        }
        goto uV8bV;
        X89IF:
        goto rIjDk;
        goto oriCQ;
        NxDTV:
        kzzFR:
        goto dEqKw;
        eTXlb:
        if ($zZK34 <= 640 * 480) {
            goto Bb_6c;
        }
        goto tdtZo;
        Z_jJt:
        $CR2HD *= 0.65;
        goto TZGF5;
        ZeBNK:
        RqXna:
        goto NUw2L;
        wVzjk:
        goto rIjDk;
        goto mSffB;
        FeSiN:
        oJOC9:
        goto POzIG;
        tNRGD:
        goto rIjDk;
        goto FeSiN;
        RXFst:
        $FDP8S = 1.5;
        goto AMDSm;
        ABiDL:
        $FDP8S = 30;
        goto X89IF;
        U0WBm:
        $FDP8S = 7;
        goto tNRGD;
        AMDSm:
        goto rIjDk;
        goto ZeBNK;
        gf0EI:
        return (int) ($CR2HD * 1000 * 1000);
        goto HyPYa;
        HyPYa:
    }
}
