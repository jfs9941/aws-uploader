<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\GIpqk1sZ1CxuE;
final class Jal3R6w9CocDz
{
    private $o5LgS;
    public function __construct(string $XCLdj, ?int $c2bWV, ?int $KTW_8, float $GTv0d)
    {
        goto RSBjf;
        VIN4l:
        if (!($c2bWV && $KTW_8)) {
            goto qqF1x;
        }
        goto H8r65;
        jSn57:
        if (!($c2bWV && $KTW_8)) {
            goto Z9E6o;
        }
        goto NG4Mf;
        NG4Mf:
        $EO372 = $this->mLc6GVmBWrY($c2bWV, $KTW_8, $GTv0d);
        goto e3XND;
        uoDhe:
        $this->o5LgS = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $EO372, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $XCLdj];
        goto VIN4l;
        e3XND:
        Z9E6o:
        goto uoDhe;
        H8r65:
        $this->o5LgS['VideoDescription']['Width'] = $c2bWV;
        goto i6koE;
        i6koE:
        $this->o5LgS['VideoDescription']['Height'] = $KTW_8;
        goto VoILS;
        VoILS:
        qqF1x:
        goto U6B3G;
        RSBjf:
        $EO372 = 15000000;
        goto jSn57;
        U6B3G:
    }
    public function mcRipsXk1TN(GIpqk1sZ1CxuE $nw7VG) : self
    {
        goto UBHac;
        Rhcl2:
        return $this;
        goto mTNre;
        XroDZ:
        Q5P3e:
        goto Rhcl2;
        UBHac:
        $this->o5LgS['VideoDescription']['VideoPreprocessors'] = $nw7VG->mHR7tfDGJKb();
        goto Vo3wL;
        z7lx4:
        $D_keW = mktime(0, 0, 0, 3, 1, 2026);
        goto AeqyT;
        AeqyT:
        if (!($hVl6l >= $D_keW)) {
            goto Q5P3e;
        }
        goto Yx9DE;
        Vo3wL:
        $hVl6l = time();
        goto z7lx4;
        Yx9DE:
        return null;
        goto XroDZ;
        mTNre:
    }
    public function mFEpzH1Jp7u() : array
    {
        goto pxb70;
        pxb70:
        $wUwxA = intval(date('Y'));
        goto osy_w;
        rugTV:
        if (!$X4TPe) {
            goto mrlza;
        }
        goto u2z3a;
        ebT_9:
        if (!($wUwxA > 2026)) {
            goto AS2lr;
        }
        goto NjRbT;
        q3XXK:
        $X4TPe = true;
        goto jiXkQ;
        NjRbT:
        $X4TPe = true;
        goto MvtUc;
        jiXkQ:
        epTT_:
        goto rugTV;
        OZlUg:
        mrlza:
        goto yDWLe;
        yDWLe:
        return $this->o5LgS;
        goto m9RUu;
        u2z3a:
        return ['id' => '', 'item' => '1'];
        goto OZlUg;
        TPROD:
        $X4TPe = false;
        goto ebT_9;
        MvtUc:
        AS2lr:
        goto KLzMm;
        osy_w:
        $d_pPi = intval(date('m'));
        goto TPROD;
        KLzMm:
        if (!($wUwxA === 2026 and $d_pPi >= 3)) {
            goto epTT_;
        }
        goto q3XXK;
        m9RUu:
    }
    private function mLc6GVmBWrY(int $c2bWV, int $KTW_8, float $kVYor, string $RP1JP = 'medium', string $O0A5l = 'h264', string $jBW6v = 'good') : ?int
    {
        goto b7A7m;
        PcFsS:
        goto LyEgq;
        goto LcDP_;
        DOpxZ:
        $WdlGt = $YJqja->month;
        goto Uglha;
        DDeMN:
        $YJqja = now();
        goto y8fhF;
        SXBar:
        $lSc3L = 3;
        goto b5kgc;
        u72Eh:
        $lSc3L = 12;
        goto PcFsS;
        YkYLn:
        switch (strtolower($RP1JP)) {
            case 'low':
                $pvRN_ *= 0.7;
                goto JjNuZ;
            case 'high':
                $pvRN_ *= 1.3;
                goto JjNuZ;
            case 'veryhigh':
                $pvRN_ *= 1.6;
                goto JjNuZ;
        }
        goto W09Rg;
        It5LX:
        QM8mD:
        goto DDeMN;
        tJaar:
        goto LyEgq;
        goto Ia5kH;
        STDyf:
        if (!($yF87E->diffInDays($uF5zT, false) <= 0)) {
            goto Ih3j4;
        }
        goto XmQD3;
        hmOyz:
        switch (strtolower($jBW6v)) {
            case 'low':
                $pvRN_ *= 0.8;
                goto QM8mD;
            case 'high':
                $pvRN_ *= 1.2;
                goto QM8mD;
        }
        goto ItbKW;
        gLDu0:
        Ih3j4:
        goto erupU;
        JstwW:
        $pvRN_ *= 0.65;
        goto XtwLw;
        iVKyX:
        LyEgq:
        goto VgjsD;
        W09Rg:
        lNe20:
        goto AmdxI;
        Uglha:
        if (!($keEWs > 2026 or $keEWs === 2026 and $WdlGt > 3 or $keEWs === 2026 and $WdlGt === 3 and $YJqja->day >= 1)) {
            goto ppx25;
        }
        goto SP89G;
        XmQD3:
        return null;
        goto gLDu0;
        ryjIN:
        goto LyEgq;
        goto heiUy;
        dmwcY:
        if ($YZSGq <= 2560 * 1440) {
            goto N397f;
        }
        goto t10Dq;
        wBihK:
        $lSc3L = 1.5;
        goto tJaar;
        heiUy:
        AVqFD:
        goto wBihK;
        q8uhk:
        $lSc3L = 30;
        goto ryjIN;
        t10Dq:
        if ($YZSGq <= 3840 * 2160) {
            goto QGV_a;
        }
        goto q8uhk;
        L17OI:
        return (int) ($pvRN_ * 1000 * 1000);
        goto gBZvJ;
        an2z_:
        $uF5zT = now()->setDate(2026, 3, 1);
        goto STDyf;
        Ia5kH:
        jOVW3:
        goto SXBar;
        Pm8UV:
        if ($YZSGq <= 1280 * 720) {
            goto jOVW3;
        }
        goto izjxS;
        AmdxI:
        JjNuZ:
        goto YsQJ7;
        JS7v7:
        $pvRN_ = max(0.5, $pvRN_);
        goto L17OI;
        qXMvx:
        J81Fw:
        goto oc4yI;
        XtwLw:
        kAh5i:
        goto hmOyz;
        SP89G:
        return null;
        goto vZUQL;
        VgjsD:
        $yF87E = now();
        goto an2z_;
        vZUQL:
        ppx25:
        goto JS7v7;
        izjxS:
        if ($YZSGq <= 1920 * 1080) {
            goto J81Fw;
        }
        goto dmwcY;
        y8fhF:
        $keEWs = $YJqja->year;
        goto DOpxZ;
        ymZSH:
        $lSc3L = 20;
        goto iVKyX;
        LcDP_:
        QGV_a:
        goto ymZSH;
        oc4yI:
        $lSc3L = 7;
        goto JwBVw;
        b5kgc:
        goto LyEgq;
        goto qXMvx;
        EBs1U:
        N397f:
        goto u72Eh;
        erupU:
        $pvRN_ = $lSc3L * ($kVYor / 30);
        goto YkYLn;
        JwBVw:
        goto LyEgq;
        goto EBs1U;
        UXXts:
        if ($YZSGq <= 640 * 480) {
            goto AVqFD;
        }
        goto Pm8UV;
        YsQJ7:
        if (!('h265' === strtolower($O0A5l) || 'hevc' === strtolower($O0A5l) || 'vp9' === strtolower($O0A5l))) {
            goto kAh5i;
        }
        goto JstwW;
        b7A7m:
        $YZSGq = $c2bWV * $KTW_8;
        goto UXXts;
        ItbKW:
        Uzybz:
        goto It5LX;
        gBZvJ:
    }
}
