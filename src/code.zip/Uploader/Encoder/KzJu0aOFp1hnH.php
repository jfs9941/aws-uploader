<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class KzJu0aOFp1hnH
{
    private $gjPg0;
    public function __construct(string $f0XS1, int $n2p4c, int $pOrBT, ?int $tp6F0, ?int $iNVXG)
    {
        goto N39R7;
        Cbx2_:
        $this->gjPg0['ImageInserter']['InsertableImages'][0]['Height'] = $iNVXG;
        goto rh5rs;
        N39R7:
        $this->gjPg0 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $n2p4c, 'ImageY' => $pOrBT, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $f0XS1, 'Opacity' => 35]]]];
        goto dDeaR;
        rh5rs:
        GkRkf:
        goto yRaEN;
        dDeaR:
        if (!($tp6F0 && $iNVXG)) {
            goto GkRkf;
        }
        goto d8ohf;
        d8ohf:
        $this->gjPg0['ImageInserter']['InsertableImages'][0]['Width'] = $tp6F0;
        goto Cbx2_;
        yRaEN:
    }
    public function mQNlPxzu3Xl() : array
    {
        return $this->gjPg0;
    }
}
