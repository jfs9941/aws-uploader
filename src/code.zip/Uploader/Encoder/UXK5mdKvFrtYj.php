<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\IkuQrlPmUVsHD;
use Jfs\Uploader\Encoder\FJLxKHdfSuKx4;
use Jfs\Uploader\Encoder\Bq62l6IOj9M2O;
use Illuminate\Support\Facades\Log;
final class UXK5mdKvFrtYj
{
    private $m8i4e;
    private $ffkHP;
    private $Qbouy;
    private $FE1vN;
    private $gWbtF;
    private $J0HDj;
    private $bYlO6;
    public function __construct(MediaConvertClient $dcmt2, $NW5Nf, $iTC2p)
    {
        goto QPxcA;
        wsweN:
        $this->J0HDj = $iTC2p;
        goto Sm_Jx;
        mrJF9:
        $this->gWbtF = $NW5Nf;
        goto wsweN;
        QPxcA:
        $this->FE1vN = $dcmt2;
        goto mrJF9;
        Sm_Jx:
    }
    public function mcqgzht3Elh() : MediaConvertClient
    {
        return $this->FE1vN;
    }
    public function mBZGBlYwJs7(Bq62l6IOj9M2O $B3sJ7) : self
    {
        $this->m8i4e = $B3sJ7;
        return $this;
    }
    public function muYnfILbWaw(string $c797b) : self
    {
        $this->Qbouy = $c797b;
        return $this;
    }
    public function mfnnJg9SPBn(FJLxKHdfSuKx4 $WkrLr) : self
    {
        $this->ffkHP[] = $WkrLr;
        return $this;
    }
    public function mnGbY80Cuj6(IkuQrlPmUVsHD $BKlrl) : self
    {
        $this->bYlO6 = $BKlrl;
        return $this;
    }
    private function mnFx7wY4sC4(bool $riQ3b) : array
    {
        goto q59s7;
        wSEH2:
        foreach ($this->ffkHP as $WkrLr) {
            $X0use['Outputs'][] = $WkrLr->mg2MGyjQOx2();
            lqfJn:
        }
        goto NzqeZ;
        o5fpO:
        $this->ffkHP = [];
        goto FpuNr;
        Nzkw4:
        JyANY:
        goto HwVdX;
        YOIxN:
        Hkq5T:
        goto HY7Z3;
        BV7o_:
        if (!$this->bYlO6) {
            goto Hkq5T;
        }
        goto dWhJm;
        HY7Z3:
        if (!$riQ3b) {
            goto JyANY;
        }
        goto NigQz;
        QUQA5:
        throw new \LogicException('You must provide a input file to use');
        goto AcYSl;
        dWhJm:
        $x7baq['Settings']['OutputGroups'][] = $this->bYlO6->m7v4u0t4EZp();
        goto YOIxN;
        hCaAF:
        unset($x7baq['Settings']['OutputGroups']);
        goto abTfg;
        HwVdX:
        $this->bYlO6 = null;
        goto cCrge;
        XK8oT:
        $x7baq['Settings']['OutputGroups'][] = $X0use;
        goto BV7o_;
        KAxfj:
        $X0use = $x7baq['Settings']['OutputGroups'][0];
        goto hCaAF;
        FpuNr:
        return $x7baq;
        goto NHghY;
        q59s7:
        $x7baq = (require 'template.php');
        goto WbGMs;
        nNlhe:
        $x7baq['Settings']['Inputs'] = $this->m8i4e->mPQEFDkvYrk();
        goto KAxfj;
        cCrge:
        $this->m8i4e = null;
        goto o5fpO;
        kuF6n:
        if ($this->m8i4e) {
            goto hc48d;
        }
        goto QUQA5;
        NzqeZ:
        AIBus:
        goto n2a8V;
        AcYSl:
        hc48d:
        goto nNlhe;
        NigQz:
        $x7baq['AccelerationSettings']['Mode'] = 'ENABLED';
        goto Nzkw4;
        WbGMs:
        $x7baq['Role'] = $this->gWbtF;
        goto LLgvO;
        LLgvO:
        $x7baq['Queue'] = $this->J0HDj;
        goto kuF6n;
        n2a8V:
        $X0use['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->Qbouy;
        goto XK8oT;
        abTfg:
        $X0use['Outputs'] = [];
        goto wSEH2;
        NHghY:
    }
    public function mEOmIKFNPRa(bool $riQ3b = false) : string
    {
        try {
            $SKvTz = $this->FE1vN->createJob($this->mnFx7wY4sC4($riQ3b));
            return $SKvTz->get('Job')['Id'];
        } catch (AwsException $p7PBd) {
            Log::error('Error creating MediaConvert job: ' . $p7PBd->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $p7PBd);
        }
    }
}
