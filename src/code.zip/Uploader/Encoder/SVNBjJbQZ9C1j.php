<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class SVNBjJbQZ9C1j
{
    private $Rp1Uk;
    public function __construct(float $LrWOl, int $ZdAaE, string $bZ5A7)
    {
        goto nSOli;
        nSOli:
        $dF4R5 = (int) $LrWOl / $ZdAaE;
        goto Li50I;
        YqsgB:
        $this->Rp1Uk = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $dF4R5]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $bZ5A7]]];
        goto oYLx8;
        Li50I:
        $dF4R5 = max($dF4R5, 1);
        goto YqsgB;
        oYLx8:
    }
    public function m9e9XQuiLEH() : array
    {
        return $this->Rp1Uk;
    }
}
