<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class B0X93rEANSGOM
{
    private $rHzhB;
    public function __construct(float $rRWy1, int $dnijt, string $UiXON)
    {
        goto VcbdS;
        QAQUc:
        $cySj2 = max($cySj2, 1);
        goto ZWuel;
        ZWuel:
        $this->rHzhB = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $cySj2]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $UiXON]]];
        goto vy91G;
        VcbdS:
        $cySj2 = (int) $rRWy1 / $dnijt;
        goto QAQUc;
        vy91G:
    }
    public function mxim8FSg7TY() : array
    {
        return $this->rHzhB;
    }
}
