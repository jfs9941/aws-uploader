<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Service\XxTGlKndb3r5q;
use Illuminate\Contracts\Filesystem\Filesystem;
final class O4lVkPvpn6cme
{
    public const MHcpq = 'v2/hls/';
    private $i17af;
    private $uiTOc;
    public function __construct(XxTGlKndb3r5q $FpmNM, Filesystem $ATeSz)
    {
        $this->i17af = $FpmNM;
        $this->uiTOc = $ATeSz;
    }
    public function mJ2UMQMVQsK($QCHmE) : string
    {
        return $this->i17af->mOlYglCbH4y(self::MHcpq . $QCHmE->getAttribute('id') . '/');
    }
    public function mDxawBhtXH2($QCHmE) : string
    {
        return $this->i17af->mOlYglCbH4y(self::MHcpq . $QCHmE->getAttribute('id') . '/thumbnail/');
    }
    public function mY2XFRHW2f7($QCHmE, $AB15W = true) : string
    {
        goto OUkaq;
        QPunw:
        Vl7Mo:
        goto H9o0A;
        H9o0A:
        return $this->i17af->mOlYglCbH4y(self::MHcpq . $QCHmE->getAttribute('id') . '/' . $QCHmE->getAttribute('id') . '.m3u8');
        goto ZID3s;
        OUkaq:
        if ($AB15W) {
            goto Vl7Mo;
        }
        goto cvbfs;
        cvbfs:
        return self::MHcpq . $QCHmE->getAttribute('id') . '/' . $QCHmE->getAttribute('id') . '.m3u8';
        goto QPunw;
        ZID3s:
    }
    public function resolveThumbnail($QCHmE) : string
    {
        goto YIRmo;
        NBbYV:
        $siX1k = $this->uiTOc->files($this->mDxawBhtXH2($QCHmE));
        goto S01PC;
        YIRmo:
        $B_L9m = $QCHmE->getAttribute('id');
        goto NBbYV;
        S01PC:
        return 1 == count($siX1k) ? self::MHcpq . $B_L9m . '/thumbnail/' . $B_L9m . '.0000000.jpg' : self::MHcpq . $B_L9m . '/thumbnail/' . $B_L9m . '.0000001.jpg';
        goto WbgA2;
        WbgA2:
    }
    public function muq5Oe6H2SA(string $dTJxl) : string
    {
        return $this->uiTOc->url($dTJxl);
    }
}
