<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\NV3aOYfIycxy3;
final class Ntz5hwm7VzzwJ
{
    private $U2pK9;
    public function __construct(string $bJyTw, ?int $p9c0Q, ?int $erqpi, float $L3tYq)
    {
        goto Bi9Tq;
        V_Po_:
        G5esU:
        goto lF3r3;
        Bi9Tq:
        $PdLta = 15000000;
        goto i6EVI;
        I_423:
        XZTey:
        goto CmyGI;
        UiPiQ:
        if (!($p9c0Q && $erqpi)) {
            goto XZTey;
        }
        goto r79J2;
        i6EVI:
        if (!($p9c0Q && $erqpi)) {
            goto G5esU;
        }
        goto YzuDW;
        EgbTZ:
        $this->U2pK9['VideoDescription']['Height'] = $erqpi;
        goto I_423;
        YzuDW:
        $PdLta = $this->mNMOckW2IYn($p9c0Q, $erqpi, $L3tYq);
        goto V_Po_;
        r79J2:
        $this->U2pK9['VideoDescription']['Width'] = $p9c0Q;
        goto EgbTZ;
        lF3r3:
        $this->U2pK9 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $PdLta, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $bJyTw];
        goto UiPiQ;
        CmyGI:
    }
    public function mlthDNEIzNb(NV3aOYfIycxy3 $jA6ko) : self
    {
        $this->U2pK9['VideoDescription']['VideoPreprocessors'] = $jA6ko->mDESNrX4NyZ();
        return $this;
    }
    public function mBhfQxkFlHV() : array
    {
        return $this->U2pK9;
    }
    private function mNMOckW2IYn(int $p9c0Q, int $erqpi, float $ouu20, string $haFzF = 'medium', string $gWX_G = 'h264', string $lYcY1 = 'good') : ?int
    {
        goto Yg0mq;
        e8P4o:
        $VODbP *= 0.65;
        goto aT2A8;
        H9xO_:
        $VODbP = max(0.5, $VODbP);
        goto EerdE;
        zeiiS:
        if ($GJ5Gy <= 1920 * 1080) {
            goto v3bMY;
        }
        goto o5t4M;
        NAKmA:
        switch (strtolower($haFzF)) {
            case 'low':
                $VODbP *= 0.7;
                goto cqYL7;
            case 'high':
                $VODbP *= 1.3;
                goto cqYL7;
            case 'veryhigh':
                $VODbP *= 1.6;
                goto cqYL7;
        }
        goto V3F4M;
        bSZ3H:
        PXcqu:
        goto hk0xN;
        V3F4M:
        qM_W7:
        goto oIuqv;
        X5VAC:
        $HOXdg = 30;
        goto yV7Lu;
        QTmeX:
        kbdEs:
        goto Jnh3u;
        Jnh3u:
        $HOXdg = 20;
        goto HzCdl;
        RWlhV:
        if (!('h265' === strtolower($gWX_G) || 'hevc' === strtolower($gWX_G) || 'vp9' === strtolower($gWX_G))) {
            goto v1_fr;
        }
        goto e8P4o;
        j6zL2:
        afnhz:
        goto mj0lj;
        DA2Hk:
        switch (strtolower($lYcY1)) {
            case 'low':
                $VODbP *= 0.8;
                goto jzFRQ;
            case 'high':
                $VODbP *= 1.2;
                goto jzFRQ;
        }
        goto N_C4z;
        S8e2w:
        jzFRQ:
        goto H9xO_;
        mbB7t:
        goto MP3QC;
        goto QTmeX;
        yV7Lu:
        goto MP3QC;
        goto j6zL2;
        rDqcM:
        goto MP3QC;
        goto yCwo4;
        O3pz2:
        $VODbP = $HOXdg * ($ouu20 / 30);
        goto NAKmA;
        aFNoM:
        goto MP3QC;
        goto UfDBy;
        o5t4M:
        if ($GJ5Gy <= 2560 * 1440) {
            goto PXcqu;
        }
        goto XdCYv;
        aT2A8:
        v1_fr:
        goto DA2Hk;
        YZHed:
        $HOXdg = 3;
        goto rDqcM;
        N_C4z:
        yEkAn:
        goto S8e2w;
        kp8I2:
        if ($GJ5Gy <= 1280 * 720) {
            goto s5EY4;
        }
        goto zeiiS;
        Yg0mq:
        $GJ5Gy = $p9c0Q * $erqpi;
        goto g75Vm;
        UfDBy:
        s5EY4:
        goto YZHed;
        yCwo4:
        v3bMY:
        goto JMDZ3;
        HzCdl:
        MP3QC:
        goto O3pz2;
        g75Vm:
        if ($GJ5Gy <= 640 * 480) {
            goto afnhz;
        }
        goto kp8I2;
        XdCYv:
        if ($GJ5Gy <= 3840 * 2160) {
            goto kbdEs;
        }
        goto X5VAC;
        JMDZ3:
        $HOXdg = 7;
        goto bIuTo;
        EerdE:
        return (int) ($VODbP * 1000 * 1000);
        goto tjGLv;
        hk0xN:
        $HOXdg = 12;
        goto mbB7t;
        mj0lj:
        $HOXdg = 1.5;
        goto aFNoM;
        bIuTo:
        goto MP3QC;
        goto bSZ3H;
        oIuqv:
        cqYL7:
        goto RWlhV;
        tjGLv:
    }
}
