<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Service\KtvKQ6SgzhDbU;
use Illuminate\Contracts\Filesystem\Filesystem;
final class LoHH67lOeFp9J
{
    public const KVXAR = 'v2/hls/';
    private $INyLX;
    private $PxC6l;
    public function __construct(KtvKQ6SgzhDbU $j3pzE, Filesystem $kxhX9)
    {
        $this->INyLX = $j3pzE;
        $this->PxC6l = $kxhX9;
    }
    public function mbeczwwgUpg($Bh2o5) : string
    {
        return $this->INyLX->mBxHLXgL7Y0(self::KVXAR . $Bh2o5->getAttribute('id') . '/');
    }
    public function mItFQGnG9Ni($Bh2o5) : string
    {
        return $this->INyLX->mBxHLXgL7Y0(self::KVXAR . $Bh2o5->getAttribute('id') . '/thumbnail/');
    }
    public function m0ov7Upz77L($Bh2o5, $h_8Gc = true) : string
    {
        goto Z6O8o;
        qXbi2:
        return $this->INyLX->mBxHLXgL7Y0(self::KVXAR . $Bh2o5->getAttribute('id') . '/' . $Bh2o5->getAttribute('id') . '.m3u8');
        goto S1558;
        G0iS9:
        return self::KVXAR . $Bh2o5->getAttribute('id') . '/' . $Bh2o5->getAttribute('id') . '.m3u8';
        goto H1CEI;
        H1CEI:
        lE50w:
        goto qXbi2;
        Z6O8o:
        if ($h_8Gc) {
            goto lE50w;
        }
        goto G0iS9;
        S1558:
    }
    public function resolveThumbnail($Bh2o5) : string
    {
        goto bz1gU;
        BSzgn:
        $AvEgW = $this->PxC6l->files($this->mItFQGnG9Ni($Bh2o5));
        goto wuDB1;
        bz1gU:
        $S580N = $Bh2o5->getAttribute('id');
        goto BSzgn;
        wuDB1:
        return 1 == count($AvEgW) ? self::KVXAR . $S580N . '/thumbnail/' . $S580N . '.0000000.jpg' : self::KVXAR . $S580N . '/thumbnail/' . $S580N . '.0000001.jpg';
        goto nt76Q;
        nt76Q:
    }
    public function mfPfvd2x3v0(string $d1QWa) : string
    {
        return $this->PxC6l->url($d1QWa);
    }
}
