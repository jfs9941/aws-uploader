<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class LCD9zDkiJube7
{
    private $yapAq;
    public function __construct(string $Qca9q, int $tB7kb, int $hVYdy, ?int $kc4oX, ?int $lIw1W)
    {
        goto dpac_;
        jkPK4:
        $this->yapAq['ImageInserter']['InsertableImages'][0]['Height'] = $lIw1W;
        goto YKSI8;
        dpac_:
        $this->yapAq = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $tB7kb, 'ImageY' => $hVYdy, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $Qca9q, 'Opacity' => 35]]]];
        goto rf1ND;
        rf1ND:
        if (!($kc4oX && $lIw1W)) {
            goto yg8pG;
        }
        goto VSuAr;
        YKSI8:
        yg8pG:
        goto bqSZ2;
        VSuAr:
        $this->yapAq['ImageInserter']['InsertableImages'][0]['Width'] = $kc4oX;
        goto jkPK4;
        bqSZ2:
    }
    public function maalhD9s428() : array
    {
        return $this->yapAq;
    }
}
