<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class W2mjj6AmkKZSu
{
    private $SmaFr;
    public function __construct(string $e62Qh, int $tuEKb, int $u2xu8, ?int $bvCsS, ?int $WEPGl)
    {
        goto vIEtd;
        bG2HR:
        N6upS:
        goto J1GQI;
        FwQxE:
        $this->SmaFr['ImageInserter']['InsertableImages'][0]['Height'] = $WEPGl;
        goto bG2HR;
        vIEtd:
        $this->SmaFr = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $tuEKb, 'ImageY' => $u2xu8, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $e62Qh, 'Opacity' => 35]]]];
        goto LFghE;
        SRwB6:
        $this->SmaFr['ImageInserter']['InsertableImages'][0]['Width'] = $bvCsS;
        goto FwQxE;
        LFghE:
        if (!($bvCsS && $WEPGl)) {
            goto N6upS;
        }
        goto SRwB6;
        J1GQI:
    }
    public function m1Ml4m05MDO() : array
    {
        return $this->SmaFr;
    }
}
