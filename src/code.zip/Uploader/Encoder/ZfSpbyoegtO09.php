<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use backup\Uploader\Encoder\HtmI0wNZkfmpy;
use backup\Uploader\Encoder\OjOeu9zRWB4yz;
use backup\Uploader\Encoder\BJQ9kvYFDQhur;
use Illuminate\Support\Facades\Log;
final class ZfSpbyoegtO09
{
    private $AiqVL;
    private $GPWGI;
    private $X2feY;
    private $m7Dn5;
    private $nUlWk;
    private $Y3L57;
    private $PLX0U;
    public function __construct(MediaConvertClient $NqDL_, $DXp2R, $QdlP7)
    {
        goto YgOxp;
        YgOxp:
        $this->m7Dn5 = $NqDL_;
        goto uBjHy;
        RvN44:
        $this->Y3L57 = $QdlP7;
        goto CM6wP;
        uBjHy:
        $this->nUlWk = $DXp2R;
        goto RvN44;
        CM6wP:
    }
    public function mYvB6m1yedV() : MediaConvertClient
    {
        return $this->m7Dn5;
    }
    public function mV7JVVzNJHP(BJQ9kvYFDQhur $mroRP) : self
    {
        $this->AiqVL = $mroRP;
        return $this;
    }
    public function m9lZUWoxALq(string $yRYEz) : self
    {
        $this->X2feY = $yRYEz;
        return $this;
    }
    public function mnm3rGDP1tF(OjOeu9zRWB4yz $KK9hi) : self
    {
        $this->GPWGI[] = $KK9hi;
        return $this;
    }
    public function m8alkrtKZd4(HtmI0wNZkfmpy $bp6Lq) : self
    {
        $this->PLX0U = $bp6Lq;
        return $this;
    }
    private function mqO0MGsOAlV(bool $vfAUi) : array
    {
        goto LluVG;
        S3Bcy:
        if ($this->AiqVL) {
            goto m5uyK;
        }
        goto juPvK;
        w0xIU:
        $TtStz['Outputs'] = [];
        goto HI5ik;
        SAXYR:
        $this->GPWGI = [];
        goto cJP8d;
        kclFi:
        JDp5i:
        goto w_DYz;
        ITAQU:
        $this->PLX0U = null;
        goto WsXRB;
        w_DYz:
        $TtStz['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->X2feY;
        goto tfNVK;
        LluVG:
        $wGUIt = (require 'template.php');
        goto bT5Rc;
        unEWo:
        x9XVk:
        goto ITAQU;
        juPvK:
        throw new \LogicException('You must provide a input file to use');
        goto zon3g;
        HI5ik:
        foreach ($this->GPWGI as $KK9hi) {
            $TtStz['Outputs'][] = $KK9hi->mYjaq35KjU1();
            kg9ia:
        }
        goto kclFi;
        zon3g:
        m5uyK:
        goto qONmq;
        ro3tw:
        if (!$vfAUi) {
            goto x9XVk;
        }
        goto qe2kD;
        qONmq:
        $wGUIt['Settings']['Inputs'] = $this->AiqVL->m1CvMqyLPfo();
        goto DTxLx;
        NexkX:
        unset($wGUIt['Settings']['OutputGroups']);
        goto w0xIU;
        DFV56:
        yjusv:
        goto ro3tw;
        cJP8d:
        return $wGUIt;
        goto O1Bld;
        BAGw7:
        $wGUIt['Settings']['OutputGroups'][] = $this->PLX0U->mtq7Y8emlXb();
        goto DFV56;
        I2oLB:
        $wGUIt['Queue'] = $this->Y3L57;
        goto S3Bcy;
        tfNVK:
        $wGUIt['Settings']['OutputGroups'][] = $TtStz;
        goto tO19g;
        bT5Rc:
        $wGUIt['Role'] = $this->nUlWk;
        goto I2oLB;
        qe2kD:
        $wGUIt['AccelerationSettings']['Mode'] = 'ENABLED';
        goto unEWo;
        tO19g:
        if (!$this->PLX0U) {
            goto yjusv;
        }
        goto BAGw7;
        DTxLx:
        $TtStz = $wGUIt['Settings']['OutputGroups'][0];
        goto NexkX;
        WsXRB:
        $this->AiqVL = null;
        goto SAXYR;
        O1Bld:
    }
    public function mzHSsynqQRf(bool $vfAUi = false) : string
    {
        try {
            $Pay5j = $this->m7Dn5->createJob($this->mqO0MGsOAlV($vfAUi));
            return $Pay5j->get('Jobs')['Id'];
        } catch (AwsException $eQXjs) {
            Log::error('Error creating MediaConvert job: ' . $eQXjs->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $eQXjs);
        }
    }
}
