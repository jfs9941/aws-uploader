<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class PsVrIC99Lkpu6
{
    private $dQOF6;
    public function __construct(string $SLzTn, int $hCjkW, int $C5FhA, ?int $g5xFk, ?int $zZl79)
    {
        goto d60gF;
        d60gF:
        $this->dQOF6 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $hCjkW, 'ImageY' => $C5FhA, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $SLzTn, 'Opacity' => 35]]]];
        goto Fk4bC;
        jpvk2:
        $this->dQOF6['ImageInserter']['InsertableImages'][0]['Height'] = $zZl79;
        goto EIG_o;
        Fk4bC:
        if (!($g5xFk && $zZl79)) {
            goto Fna6w;
        }
        goto qY7ji;
        EIG_o:
        Fna6w:
        goto RtYgQ;
        qY7ji:
        $this->dQOF6['ImageInserter']['InsertableImages'][0]['Width'] = $g5xFk;
        goto jpvk2;
        RtYgQ:
    }
    public function mNqmV72Le7i() : array
    {
        return $this->dQOF6;
    }
}
