<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Service\Cjv3UOrDUgWrC;
final class Z476P5MAXqSnV
{
    public const GwFDi = 'v2/hls/';
    private $R93CE;
    private $K79lK;
    public function __construct(Cjv3UOrDUgWrC $qrahj, Filesystem $yEBaZ)
    {
        $this->R93CE = $qrahj;
        $this->K79lK = $yEBaZ;
    }
    public function mJjadSDLkeJ($X0ufS) : string
    {
        return $this->R93CE->mUfXNHGNmAK(self::GwFDi . $X0ufS->getAttribute('id') . '/');
    }
    public function mGgYqxoSc43($X0ufS) : string
    {
        return $this->R93CE->mUfXNHGNmAK(self::GwFDi . $X0ufS->getAttribute('id') . '/thumbnail/');
    }
    public function m0f3Ck5lHCa($X0ufS, $p2X9e = true) : string
    {
        goto h6oCI;
        h6oCI:
        if ($p2X9e) {
            goto b06ty;
        }
        goto GMv7a;
        GMv7a:
        return self::GwFDi . $X0ufS->getAttribute('id') . '/' . $X0ufS->getAttribute('id') . '.m3u8';
        goto d3meq;
        YDzmY:
        return $this->R93CE->mUfXNHGNmAK(self::GwFDi . $X0ufS->getAttribute('id') . '/' . $X0ufS->getAttribute('id') . '.m3u8');
        goto Ko1M2;
        d3meq:
        b06ty:
        goto YDzmY;
        Ko1M2:
    }
    public function resolveThumbnail($X0ufS) : string
    {
        goto MmeGL;
        zvHGe:
        return 1 == count($lFYWw) ? self::GwFDi . $Qu08p . '/thumbnail/' . $Qu08p . '.0000000.jpg' : self::GwFDi . $Qu08p . '/thumbnail/' . $Qu08p . '.0000001.jpg';
        goto xjrp3;
        fq2Mu:
        $lFYWw = $this->K79lK->files($this->mGgYqxoSc43($X0ufS));
        goto zvHGe;
        MmeGL:
        $Qu08p = $X0ufS->getAttribute('id');
        goto fq2Mu;
        xjrp3:
    }
    public function mYHThNa7OU2(string $TnwL2) : string
    {
        return $this->K79lK->url($TnwL2);
    }
}
