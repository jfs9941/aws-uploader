<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\VW5Bj7j5VYqGn;
final class InuwBbIMQbzyz
{
    private $GShL9;
    public function __construct(string $BntUR, ?int $SeDOJ, ?int $vwirX, float $vnK2h)
    {
        goto hreV1;
        AqqWG:
        if (!($SeDOJ && $vwirX)) {
            goto AkpWj;
        }
        goto mk0Bx;
        hreV1:
        $eBx6V = 15000000;
        goto CCYZT;
        D9IU8:
        $this->GShL9 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $eBx6V, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $BntUR];
        goto AqqWG;
        UZWdh:
        AkpWj:
        goto onnZ1;
        atPe5:
        $this->GShL9['VideoDescription']['Height'] = $vwirX;
        goto UZWdh;
        e9x5K:
        vM9R1:
        goto D9IU8;
        CCYZT:
        if (!($SeDOJ && $vwirX)) {
            goto vM9R1;
        }
        goto t6nLH;
        mk0Bx:
        $this->GShL9['VideoDescription']['Width'] = $SeDOJ;
        goto atPe5;
        t6nLH:
        $eBx6V = $this->msqswup567O($SeDOJ, $vwirX, $vnK2h);
        goto e9x5K;
        onnZ1:
    }
    public function mQ2LDkS55VA(VW5Bj7j5VYqGn $oi6Ld) : self
    {
        $this->GShL9['VideoDescription']['VideoPreprocessors'] = $oi6Ld->mNclBmPPbm4();
        return $this;
    }
    public function mvAImOIvgIn() : array
    {
        return $this->GShL9;
    }
    private function msqswup567O(int $SeDOJ, int $vwirX, float $qn_hP, string $h1lAF = 'medium', string $fv9fZ = 'h264', string $K72uV = 'good') : ?int
    {
        goto iBVa2;
        Etm0L:
        return (int) ($rlhl0 * 1000 * 1000);
        goto O_Vd0;
        ny1st:
        $rlhl0 = $BSGmU * ($qn_hP / 30);
        goto QHlMP;
        yPRiA:
        $rlhl0 *= 0.65;
        goto iNjFx;
        ZVfAW:
        goto cuAWB;
        goto XKyO0;
        kI1T9:
        goto cuAWB;
        goto kWJPp;
        XKyO0:
        D2IF9:
        goto jIhk0;
        rDreM:
        $BSGmU = 30;
        goto PPlE7;
        PPlE7:
        goto cuAWB;
        goto cYR7z;
        j_3T6:
        if ($wbuzt <= 1280 * 720) {
            goto XBhkc;
        }
        goto rxuUD;
        jIhk0:
        $BSGmU = 12;
        goto bvcDG;
        iBVa2:
        $wbuzt = $SeDOJ * $vwirX;
        goto IC2Gx;
        iNjFx:
        EWvs4:
        goto xZvVG;
        IC2Gx:
        if ($wbuzt <= 640 * 480) {
            goto O_Rwi;
        }
        goto j_3T6;
        c19U2:
        ex5aL:
        goto rYuXQ;
        p8Ec9:
        CNIUo:
        goto L0bqd;
        rxuUD:
        if ($wbuzt <= 1920 * 1080) {
            goto ex5aL;
        }
        goto Gf48t;
        bvcDG:
        goto cuAWB;
        goto N0AND;
        c0XER:
        goto cuAWB;
        goto c19U2;
        L0bqd:
        KUDf1:
        goto HCwdb;
        pt2Eq:
        $BSGmU = 3;
        goto c0XER;
        rYuXQ:
        $BSGmU = 7;
        goto ZVfAW;
        N0AND:
        NohXJ:
        goto cdoWb;
        ijevH:
        hxlDb:
        goto Xs2FO;
        xZvVG:
        switch (strtolower($K72uV)) {
            case 'low':
                $rlhl0 *= 0.8;
                goto hxlDb;
            case 'high':
                $rlhl0 *= 1.2;
                goto hxlDb;
        }
        goto XvvPP;
        XvvPP:
        MxZCL:
        goto ijevH;
        HCwdb:
        if (!('h265' === strtolower($fv9fZ) || 'hevc' === strtolower($fv9fZ) || 'vp9' === strtolower($fv9fZ))) {
            goto EWvs4;
        }
        goto yPRiA;
        Gf48t:
        if ($wbuzt <= 2560 * 1440) {
            goto D2IF9;
        }
        goto TYv3U;
        TYv3U:
        if ($wbuzt <= 3840 * 2160) {
            goto NohXJ;
        }
        goto rDreM;
        Xs2FO:
        $rlhl0 = max(0.5, $rlhl0);
        goto Etm0L;
        wds4y:
        $BSGmU = 1.5;
        goto kI1T9;
        cdoWb:
        $BSGmU = 20;
        goto mAzyL;
        cYR7z:
        O_Rwi:
        goto wds4y;
        kWJPp:
        XBhkc:
        goto pt2Eq;
        mAzyL:
        cuAWB:
        goto ny1st;
        QHlMP:
        switch (strtolower($h1lAF)) {
            case 'low':
                $rlhl0 *= 0.7;
                goto KUDf1;
            case 'high':
                $rlhl0 *= 1.3;
                goto KUDf1;
            case 'veryhigh':
                $rlhl0 *= 1.6;
                goto KUDf1;
        }
        goto p8Ec9;
        O_Vd0:
    }
}
