<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Alxlzu9Vtdk0x
{
    private $tt9EF;
    public function __construct(string $xuvYC, int $Ea81W, int $bpvnW, ?int $Gsmm4, ?int $iM4bK)
    {
        goto aX5MC;
        JSK9I:
        $this->tt9EF['ImageInserter']['InsertableImages'][0]['Width'] = $Gsmm4;
        goto PEqmE;
        PEqmE:
        $this->tt9EF['ImageInserter']['InsertableImages'][0]['Height'] = $iM4bK;
        goto o1uKj;
        o1uKj:
        Cso97:
        goto hRWAf;
        MQMzL:
        if (!($Gsmm4 && $iM4bK)) {
            goto Cso97;
        }
        goto JSK9I;
        aX5MC:
        $this->tt9EF = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $Ea81W, 'ImageY' => $bpvnW, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $xuvYC, 'Opacity' => 35]]]];
        goto MQMzL;
        hRWAf:
    }
    public function mqeIGlpkXYf() : array
    {
        return $this->tt9EF;
    }
}
