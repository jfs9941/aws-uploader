<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Service\ZKiz9aeWXGIZz;
use Illuminate\Contracts\Filesystem\Filesystem;
final class PBaAMCftTA2PY
{
    public const Xo4hM = 'v2/hls/';
    private $Bf3Nr;
    private $rSfnv;
    public function __construct(ZKiz9aeWXGIZz $XpJJ6, Filesystem $uIWH1)
    {
        $this->Bf3Nr = $XpJJ6;
        $this->rSfnv = $uIWH1;
    }
    public function m2xueZkh93c($JfLWA) : string
    {
        return $this->Bf3Nr->mxCxc9kMwDl(self::Xo4hM . $JfLWA->getAttribute('id') . '/');
    }
    public function mKEJxGQm5jf($JfLWA) : string
    {
        return $this->Bf3Nr->mxCxc9kMwDl(self::Xo4hM . $JfLWA->getAttribute('id') . '/thumbnail/');
    }
    public function m8ZjpDPpWxl($JfLWA, $oez00 = true) : string
    {
        goto P4c4U;
        cPYFO:
        return $this->Bf3Nr->mxCxc9kMwDl(self::Xo4hM . $JfLWA->getAttribute('id') . '/' . $JfLWA->getAttribute('id') . '.m3u8');
        goto IMVWU;
        Pp_JO:
        f98xY:
        goto cPYFO;
        I5be3:
        return self::Xo4hM . $JfLWA->getAttribute('id') . '/' . $JfLWA->getAttribute('id') . '.m3u8';
        goto Pp_JO;
        P4c4U:
        if ($oez00) {
            goto f98xY;
        }
        goto I5be3;
        IMVWU:
    }
    public function resolveThumbnail($JfLWA) : string
    {
        goto HW6O6;
        FrmEJ:
        return 1 == count($agem0) ? self::Xo4hM . $eeXS6 . '/thumbnail/' . $eeXS6 . '.0000000.jpg' : self::Xo4hM . $eeXS6 . '/thumbnail/' . $eeXS6 . '.0000001.jpg';
        goto Rm80s;
        YMAwm:
        $agem0 = $this->rSfnv->files($this->mKEJxGQm5jf($JfLWA));
        goto FrmEJ;
        HW6O6:
        $eeXS6 = $JfLWA->getAttribute('id');
        goto YMAwm;
        Rm80s:
    }
    public function m3Uf7V8YKx1(string $NSF8Y) : string
    {
        return $this->rSfnv->url($NSF8Y);
    }
}
