<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class IkuQrlPmUVsHD
{
    private $bYlO6;
    public function __construct(float $P58cP, int $L6EQe, string $c797b)
    {
        goto SZR3h;
        pPqbp:
        $xvF8A = max($xvF8A, 1);
        goto SDnez;
        SZR3h:
        $xvF8A = (int) $P58cP / $L6EQe;
        goto pPqbp;
        SDnez:
        $this->bYlO6 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $xvF8A]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $c797b]]];
        goto G3vHF;
        G3vHF:
    }
    public function m7v4u0t4EZp() : array
    {
        return $this->bYlO6;
    }
}
