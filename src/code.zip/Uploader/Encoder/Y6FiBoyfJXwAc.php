<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\ZhqheKMj6zBOk;
use Jfs\Uploader\Encoder\UcICRyWMxVcex;
use Jfs\Uploader\Encoder\H79n2eIrx9Dev;
use Illuminate\Support\Facades\Log;
final class Y6FiBoyfJXwAc
{
    private $plu_1;
    private $ChlA4;
    private $vYvYr;
    private $wYCCp;
    private $QQJz9;
    private $BTk2A;
    private $PVDri;
    public function __construct(MediaConvertClient $EWxxX, $h8Itz, $b5zIV)
    {
        goto GZXjA;
        GZXjA:
        $this->wYCCp = $EWxxX;
        goto cqbod;
        xayiX:
        $this->BTk2A = $b5zIV;
        goto qM_Py;
        cqbod:
        $this->QQJz9 = $h8Itz;
        goto xayiX;
        qM_Py:
    }
    public function mUhs0B7FDlq() : MediaConvertClient
    {
        return $this->wYCCp;
    }
    public function moj1tsuqnPJ(H79n2eIrx9Dev $I5UMd) : self
    {
        $this->plu_1 = $I5UMd;
        return $this;
    }
    public function m563SkKfO2j(string $YaY80) : self
    {
        $this->vYvYr = $YaY80;
        return $this;
    }
    public function mypBAWwioeu(UcICRyWMxVcex $Qw4L0) : self
    {
        $this->ChlA4[] = $Qw4L0;
        return $this;
    }
    public function muH7QQYELle(ZhqheKMj6zBOk $f_EWh) : self
    {
        $this->PVDri = $f_EWh;
        return $this;
    }
    private function mrGxrQRMArS(bool $GliMh) : array
    {
        goto XZV1l;
        n1qit:
        hOVgD:
        goto kC2Jc;
        VXdFv:
        return $MHedU;
        goto JRPdt;
        UgU2y:
        $JumG8['Outputs'] = [];
        goto by6hj;
        uIPXp:
        if (!$this->PVDri) {
            goto hOVgD;
        }
        goto NoerQ;
        tOl4Y:
        $JumG8['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->vYvYr;
        goto RkPsM;
        E7rJ4:
        $MHedU['Queue'] = $this->BTk2A;
        goto BKzkL;
        XZV1l:
        $MHedU = (require 'template.php');
        goto hYZVI;
        BKzkL:
        if ($this->plu_1) {
            goto fT3Bm;
        }
        goto XqjkM;
        dQ8GN:
        zWrsO:
        goto tOl4Y;
        I3j6O:
        unset($MHedU['Settings']['OutputGroups']);
        goto UgU2y;
        HmJiK:
        rescE:
        goto WG27l;
        gYvnA:
        fT3Bm:
        goto zuWoC;
        j3K6P:
        $this->ChlA4 = [];
        goto VXdFv;
        WG27l:
        $this->PVDri = null;
        goto Ob2Ja;
        by6hj:
        foreach ($this->ChlA4 as $Qw4L0) {
            $JumG8['Outputs'][] = $Qw4L0->mwp9FcxvC8A();
            RI8aE:
        }
        goto dQ8GN;
        hYZVI:
        $MHedU['Role'] = $this->QQJz9;
        goto E7rJ4;
        RkPsM:
        $MHedU['Settings']['OutputGroups'][] = $JumG8;
        goto uIPXp;
        kC2Jc:
        if (!$GliMh) {
            goto rescE;
        }
        goto Jc2nO;
        eZbt1:
        $JumG8 = $MHedU['Settings']['OutputGroups'][0];
        goto I3j6O;
        XqjkM:
        throw new \LogicException('You must provide a input file to use');
        goto gYvnA;
        Ob2Ja:
        $this->plu_1 = null;
        goto j3K6P;
        Jc2nO:
        $MHedU['AccelerationSettings']['Mode'] = 'ENABLED';
        goto HmJiK;
        zuWoC:
        $MHedU['Settings']['Inputs'] = $this->plu_1->mWib7I6Hz5k();
        goto eZbt1;
        NoerQ:
        $MHedU['Settings']['OutputGroups'][] = $this->PVDri->mmDmdMPkxOx();
        goto n1qit;
        JRPdt:
    }
    public function m3JunJVgwk3(bool $GliMh = false) : string
    {
        try {
            $aCVXA = $this->wYCCp->createJob($this->mrGxrQRMArS($GliMh));
            return $aCVXA->get('Jobs')['Id'];
        } catch (AwsException $jupeT) {
            Log::error('Error creating MediaConvert job: ' . $jupeT->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $jupeT);
        }
    }
}
