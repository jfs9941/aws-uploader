<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Service\XmR9LXciUFjyf;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ASuKOsLEZrEeb
{
    public const l3YrS = 'v2/hls/';
    private $KBTsU;
    private $hFxUe;
    public function __construct(XmR9LXciUFjyf $rKcW0, Filesystem $KKbEP)
    {
        $this->KBTsU = $rKcW0;
        $this->hFxUe = $KKbEP;
    }
    public function mOh7kVVbVZk($IrxWj) : string
    {
        return $this->KBTsU->mqr1lHgkTtT(self::l3YrS . $IrxWj->getAttribute('id') . '/');
    }
    public function mT6pU1IKqIF($IrxWj) : string
    {
        return $this->KBTsU->mqr1lHgkTtT(self::l3YrS . $IrxWj->getAttribute('id') . '/thumbnail/');
    }
    public function mlhIxqmvG6u($IrxWj, $UidrL = true) : string
    {
        goto o109z;
        o109z:
        if ($UidrL) {
            goto eqPcm;
        }
        goto nD3IY;
        V8EcT:
        eqPcm:
        goto IJsaH;
        nD3IY:
        return self::l3YrS . $IrxWj->getAttribute('id') . '/' . $IrxWj->getAttribute('id') . '.m3u8';
        goto V8EcT;
        IJsaH:
        return $this->KBTsU->mqr1lHgkTtT(self::l3YrS . $IrxWj->getAttribute('id') . '/' . $IrxWj->getAttribute('id') . '.m3u8');
        goto zLKAP;
        zLKAP:
    }
    public function resolveThumbnail($IrxWj) : string
    {
        goto XxhSW;
        TQ4no:
        return 1 == count($jhUCR) ? self::l3YrS . $SEOXv . '/thumbnail/' . $SEOXv . '.0000000.jpg' : self::l3YrS . $SEOXv . '/thumbnail/' . $SEOXv . '.0000001.jpg';
        goto K4oVn;
        XxhSW:
        $SEOXv = $IrxWj->getAttribute('id');
        goto HQqpq;
        HQqpq:
        $jhUCR = $this->hFxUe->files($this->mT6pU1IKqIF($IrxWj));
        goto TQ4no;
        K4oVn:
    }
    public function mLetKeviW3M(string $liQkG) : string
    {
        return $this->hFxUe->url($liQkG);
    }
}
