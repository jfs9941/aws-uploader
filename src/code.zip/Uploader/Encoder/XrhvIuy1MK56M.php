<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\OjCsASiweOGQ8;
final class XrhvIuy1MK56M
{
    private $NoWnQ;
    public function __construct(string $DHk3q, ?int $wtcqu, ?int $snhLP, float $l9zno)
    {
        goto mTxSH;
        P4Ovl:
        if (!($wtcqu && $snhLP)) {
            goto Ga8XP;
        }
        goto lpQK3;
        Agxep:
        if (!($wtcqu && $snhLP)) {
            goto eQE17;
        }
        goto Z5LEM;
        Vh4V6:
        $this->NoWnQ['VideoDescription']['Height'] = $snhLP;
        goto ZB_ic;
        UMIQM:
        Ga8XP:
        goto Ktw2j;
        ZB_ic:
        eQE17:
        goto kHSHR;
        Ktw2j:
        $this->NoWnQ = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $YhYhk, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $DHk3q];
        goto Agxep;
        mTxSH:
        $YhYhk = 15000000;
        goto P4Ovl;
        Z5LEM:
        $this->NoWnQ['VideoDescription']['Width'] = $wtcqu;
        goto Vh4V6;
        lpQK3:
        $YhYhk = $this->m1u3xkazl7y($wtcqu, $snhLP, $l9zno);
        goto UMIQM;
        kHSHR:
    }
    public function mLkiEYhjCcL(OjCsASiweOGQ8 $heBhO) : self
    {
        $this->NoWnQ['VideoDescription']['VideoPreprocessors'] = $heBhO->m605t8blifK();
        return $this;
    }
    public function m2UQ5g18FcF() : array
    {
        return $this->NoWnQ;
    }
    private function m1u3xkazl7y(int $wtcqu, int $snhLP, float $JPXkz, string $GC_7O = 'medium', string $GsCkj = 'h264', string $mPVis = 'good') : ?int
    {
        goto LLcmN;
        gzxtn:
        W0yAS:
        goto JDU9W;
        xPYdr:
        if ($pGinY <= 2560 * 1440) {
            goto n90NU;
        }
        goto bhlN1;
        y36hC:
        $ncVLn = 1.5;
        goto MxZIW;
        P3VSG:
        Jpiev:
        goto gdXo6;
        sn1MM:
        return (int) ($meamb * 1000 * 1000);
        goto Qz2IS;
        rxrmy:
        afbyr:
        goto b2Ftg;
        MxZIW:
        goto Jpiev;
        goto rxrmy;
        K0y1p:
        $ncVLn = 30;
        goto NBNdo;
        lMMFp:
        if ($pGinY <= 1920 * 1080) {
            goto W0yAS;
        }
        goto xPYdr;
        gpkOJ:
        VpwFb:
        goto o9OqU;
        A3yp4:
        oFi9z:
        goto CQhbi;
        ydW_0:
        goto Jpiev;
        goto gpkOJ;
        JDU9W:
        $ncVLn = 7;
        goto B2h97;
        xRe8A:
        edbPl:
        goto IV1ud;
        KmMkA:
        if ($pGinY <= 1280 * 720) {
            goto afbyr;
        }
        goto lMMFp;
        sOEaW:
        $ncVLn = 12;
        goto ydW_0;
        xu4Nn:
        $meamb *= 0.65;
        goto xRe8A;
        K3xcU:
        ElF70:
        goto pwpHH;
        LLcmN:
        $pGinY = $wtcqu * $snhLP;
        goto FZHkg;
        b2Ftg:
        $ncVLn = 3;
        goto mXakk;
        gdXo6:
        $meamb = $ncVLn * ($JPXkz / 30);
        goto jTDZ6;
        o9OqU:
        $ncVLn = 20;
        goto P3VSG;
        B2h97:
        goto Jpiev;
        goto N9Km5;
        mXakk:
        goto Jpiev;
        goto gzxtn;
        bhlN1:
        if ($pGinY <= 3840 * 2160) {
            goto VpwFb;
        }
        goto K0y1p;
        CQhbi:
        h5zK4:
        goto jyfCy;
        Mndps:
        FKIQw:
        goto y36hC;
        VA4Ms:
        $meamb = max(0.5, $meamb);
        goto sn1MM;
        IV1ud:
        switch (strtolower($mPVis)) {
            case 'low':
                $meamb *= 0.8;
                goto cMwRw;
            case 'high':
                $meamb *= 1.2;
                goto cMwRw;
        }
        goto K3xcU;
        pwpHH:
        cMwRw:
        goto VA4Ms;
        jyfCy:
        if (!('h265' === strtolower($GsCkj) || 'hevc' === strtolower($GsCkj) || 'vp9' === strtolower($GsCkj))) {
            goto edbPl;
        }
        goto xu4Nn;
        N9Km5:
        n90NU:
        goto sOEaW;
        NBNdo:
        goto Jpiev;
        goto Mndps;
        FZHkg:
        if ($pGinY <= 640 * 480) {
            goto FKIQw;
        }
        goto KmMkA;
        jTDZ6:
        switch (strtolower($GC_7O)) {
            case 'low':
                $meamb *= 0.7;
                goto h5zK4;
            case 'high':
                $meamb *= 1.3;
                goto h5zK4;
            case 'veryhigh':
                $meamb *= 1.6;
                goto h5zK4;
        }
        goto A3yp4;
        Qz2IS:
    }
}
