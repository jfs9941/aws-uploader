<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class OwFt4j2nadux5
{
    private $jBYWB;
    public function __construct(string $CSnia, int $TUffD, int $Tz1X7, ?int $MpCza, ?int $rfhYJ)
    {
        goto nPalo;
        ntS7G:
        if (!($MpCza && $rfhYJ)) {
            goto z182h;
        }
        goto mTaJg;
        CuF1o:
        z182h:
        goto wiZ1J;
        mTaJg:
        $this->jBYWB['ImageInserter']['InsertableImages'][0]['Width'] = $MpCza;
        goto Ywjqq;
        Ywjqq:
        $this->jBYWB['ImageInserter']['InsertableImages'][0]['Height'] = $rfhYJ;
        goto CuF1o;
        nPalo:
        $this->jBYWB = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $TUffD, 'ImageY' => $Tz1X7, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $CSnia, 'Opacity' => 35]]]];
        goto ntS7G;
        wiZ1J:
    }
    public function moAVkCXpdtQ() : array
    {
        return $this->jBYWB;
    }
}
