<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\KUtW8CyIwsZh0;
use Jfs\Uploader\Encoder\GEB19HZppIkTI;
use Jfs\Uploader\Encoder\Lx636Dczn2DZA;
use Illuminate\Support\Facades\Log;
final class FffZ2siMxgG2d
{
    private $ohTeB;
    private $K5gDx;
    private $Pt1gT;
    private $bA8Ks;
    private $Wuugy;
    private $hBZhk;
    private $tWztK;
    public function __construct(MediaConvertClient $H2pyk, $FfEEM, $iuFqB)
    {
        goto dklCi;
        dklCi:
        $this->bA8Ks = $H2pyk;
        goto lb_aT;
        lb_aT:
        $this->Wuugy = $FfEEM;
        goto z428d;
        z428d:
        $this->hBZhk = $iuFqB;
        goto iUAuW;
        iUAuW:
    }
    public function mp9Z3UGS7Ke() : MediaConvertClient
    {
        return $this->bA8Ks;
    }
    public function mNIEMAiViBT(Lx636Dczn2DZA $jaUT9) : self
    {
        $this->ohTeB = $jaUT9;
        return $this;
    }
    public function m147hZEQzrJ(string $wqITx) : self
    {
        $this->Pt1gT = $wqITx;
        return $this;
    }
    public function mQWhKak6LTl(GEB19HZppIkTI $rCMJg) : self
    {
        $this->K5gDx[] = $rCMJg;
        return $this;
    }
    public function mJpgGSnisw2(KUtW8CyIwsZh0 $w6RVC) : self
    {
        $this->tWztK = $w6RVC;
        return $this;
    }
    private function mgkTNzKY5C7(bool $lkKrH) : array
    {
        goto PAfwN;
        xKz2r:
        $hIULp = $oY5UC['Settings']['OutputGroups'][0];
        goto JCk6_;
        DDBm7:
        return $oY5UC;
        goto oqWXR;
        c2IxZ:
        if ($this->ohTeB) {
            goto AmzuR;
        }
        goto bWf3E;
        bWf3E:
        throw new \LogicException('You must provide a input file to use');
        goto SaoUQ;
        fh6mx:
        yHgTq:
        goto EZ1pX;
        SaoUQ:
        AmzuR:
        goto xBrc9;
        PAfwN:
        $oY5UC = (require 'template.php');
        goto wvFJo;
        xBm8M:
        Gudyk:
        goto lTe2d;
        N9ZzG:
        if (!$lkKrH) {
            goto Gudyk;
        }
        goto zcsAu;
        ieEYJ:
        $this->ohTeB = null;
        goto xkOCQ;
        ntFCp:
        if (!$this->tWztK) {
            goto YH1r0;
        }
        goto DPJ4o;
        b314G:
        $oY5UC['Settings']['OutputGroups'][] = $hIULp;
        goto ntFCp;
        SqcmI:
        foreach ($this->K5gDx as $rCMJg) {
            $hIULp['Outputs'][] = $rCMJg->mbneImfsfOH();
            w2nB9:
        }
        goto fh6mx;
        xkOCQ:
        $this->K5gDx = [];
        goto DDBm7;
        zcsAu:
        $oY5UC['AccelerationSettings']['Mode'] = 'ENABLED';
        goto xBm8M;
        lTe2d:
        $this->tWztK = null;
        goto ieEYJ;
        JCk6_:
        unset($oY5UC['Settings']['OutputGroups']);
        goto qdY1I;
        EZ1pX:
        $hIULp['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->Pt1gT;
        goto b314G;
        DPJ4o:
        $oY5UC['Settings']['OutputGroups'][] = $this->tWztK->mSApFb9qzUu();
        goto eB4z4;
        wvFJo:
        $oY5UC['Role'] = $this->Wuugy;
        goto vgZFQ;
        eB4z4:
        YH1r0:
        goto N9ZzG;
        vgZFQ:
        $oY5UC['Queue'] = $this->hBZhk;
        goto c2IxZ;
        xBrc9:
        $oY5UC['Settings']['Inputs'] = $this->ohTeB->mvlg7ORaMWx();
        goto xKz2r;
        qdY1I:
        $hIULp['Outputs'] = [];
        goto SqcmI;
        oqWXR:
    }
    public function mqb99rdLPGq(bool $lkKrH = false) : string
    {
        try {
            $sx0QZ = $this->bA8Ks->createJob($this->mgkTNzKY5C7($lkKrH));
            return $sx0QZ->get('Jobs')['Id'];
        } catch (AwsException $YIsP2) {
            Log::error('Error creating MediaConvert job: ' . $YIsP2->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $YIsP2);
        }
    }
}
