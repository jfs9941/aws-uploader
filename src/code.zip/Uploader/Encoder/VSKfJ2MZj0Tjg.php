<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Service\JkVi3Kv2ThmJv;
use Illuminate\Contracts\Filesystem\Filesystem;
final class VSKfJ2MZj0Tjg
{
    public const kFBVi = 'v2/hls/';
    private $TaZBi;
    private $BfyCm;
    public function __construct(JkVi3Kv2ThmJv $Upw6m, Filesystem $ejImE)
    {
        $this->TaZBi = $Upw6m;
        $this->BfyCm = $ejImE;
    }
    public function m7jExCbXa2j($dajVn) : string
    {
        return $this->TaZBi->mEwXI6TBtNV(self::kFBVi . $dajVn->getAttribute('id') . '/');
    }
    public function mlcQhfVFRik($dajVn) : string
    {
        return $this->TaZBi->mEwXI6TBtNV(self::kFBVi . $dajVn->getAttribute('id') . '/thumbnail/');
    }
    public function mOaIJ60GKHe($dajVn, $JagOR = true) : string
    {
        goto y1heW;
        y1heW:
        if ($JagOR) {
            goto J7cR4;
        }
        goto zjN80;
        zjN80:
        return self::kFBVi . $dajVn->getAttribute('id') . '/' . $dajVn->getAttribute('id') . '.m3u8';
        goto yE_53;
        ZaYbR:
        return $this->TaZBi->mEwXI6TBtNV(self::kFBVi . $dajVn->getAttribute('id') . '/' . $dajVn->getAttribute('id') . '.m3u8');
        goto bd8Xs;
        yE_53:
        J7cR4:
        goto ZaYbR;
        bd8Xs:
    }
    public function resolveThumbnail($dajVn) : string
    {
        goto jECLD;
        f2Cc5:
        $bFf3l = $this->BfyCm->files($this->mlcQhfVFRik($dajVn));
        goto JhYD1;
        JhYD1:
        return 1 == count($bFf3l) ? self::kFBVi . $aK0gt . '/thumbnail/' . $aK0gt . '.0000000.jpg' : self::kFBVi . $aK0gt . '/thumbnail/' . $aK0gt . '.0000001.jpg';
        goto bxH7_;
        jECLD:
        $aK0gt = $dajVn->getAttribute('id');
        goto f2Cc5;
        bxH7_:
    }
    public function mfM2V7WbtUe(string $HyAAV) : string
    {
        return $this->BfyCm->url($HyAAV);
    }
}
