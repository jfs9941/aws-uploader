<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Service\HHzuA41ccyXtA;
use Illuminate\Contracts\Filesystem\Filesystem;
final class TMo64GtkgTgVY
{
    public const rArUU = 'v2/hls/';
    private $mYmlh;
    private $tcoQz;
    public function __construct(HHzuA41ccyXtA $DOzS1, Filesystem $v70jj)
    {
        $this->mYmlh = $DOzS1;
        $this->tcoQz = $v70jj;
    }
    public function meR9CGDQ79M($jYLmK) : string
    {
        return $this->mYmlh->mfUYQYCCxiQ(self::rArUU . $jYLmK->getAttribute('id') . '/');
    }
    public function mcFwv3s6QV9($jYLmK) : string
    {
        return $this->mYmlh->mfUYQYCCxiQ(self::rArUU . $jYLmK->getAttribute('id') . '/thumbnail/');
    }
    public function mAZUrOlWOGk($jYLmK, $OQ9Dv = true) : string
    {
        goto w2USs;
        U2mhd:
        f4V8_:
        goto TAptM;
        TAptM:
        return $this->mYmlh->mfUYQYCCxiQ(self::rArUU . $jYLmK->getAttribute('id') . '/' . $jYLmK->getAttribute('id') . '.m3u8');
        goto bgiX_;
        xRvLR:
        return self::rArUU . $jYLmK->getAttribute('id') . '/' . $jYLmK->getAttribute('id') . '.m3u8';
        goto U2mhd;
        w2USs:
        if ($OQ9Dv) {
            goto f4V8_;
        }
        goto xRvLR;
        bgiX_:
    }
    public function resolveThumbnail($jYLmK) : string
    {
        goto gdx9e;
        dDPNM:
        return 1 == count($a0LP8) ? self::rArUU . $B5uQ4 . '/thumbnail/' . $B5uQ4 . '.0000000.jpg' : self::rArUU . $B5uQ4 . '/thumbnail/' . $B5uQ4 . '.0000001.jpg';
        goto n0csO;
        gdx9e:
        $B5uQ4 = $jYLmK->getAttribute('id');
        goto JJGir;
        JJGir:
        $a0LP8 = $this->tcoQz->files($this->mcFwv3s6QV9($jYLmK));
        goto dDPNM;
        n0csO:
    }
    public function mDr4w2yfvfL(string $uUtRl) : string
    {
        return $this->tcoQz->url($uUtRl);
    }
}
