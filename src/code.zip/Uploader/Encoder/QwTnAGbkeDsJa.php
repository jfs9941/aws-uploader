<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class QwTnAGbkeDsJa
{
    private $LmbNX;
    public function __construct(string $gmSGl, int $zSNHW, int $N8MnA, ?int $ZJYlg, ?int $RFX4H)
    {
        goto D8h5I;
        mXMbx:
        $this->LmbNX['ImageInserter']['InsertableImages'][0]['Width'] = $ZJYlg;
        goto Dq6M8;
        Dq6M8:
        $this->LmbNX['ImageInserter']['InsertableImages'][0]['Height'] = $RFX4H;
        goto eTA7d;
        eTA7d:
        qu1ts:
        goto EcKHt;
        D8h5I:
        $this->LmbNX = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $zSNHW, 'ImageY' => $N8MnA, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $gmSGl, 'Opacity' => 35]]]];
        goto EiZsJ;
        EiZsJ:
        if (!($ZJYlg && $RFX4H)) {
            goto qu1ts;
        }
        goto mXMbx;
        EcKHt:
    }
    public function mFDWZCfaAQU() : array
    {
        return $this->LmbNX;
    }
}
