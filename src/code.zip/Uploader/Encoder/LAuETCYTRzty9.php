<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class LAuETCYTRzty9
{
    private $j1NYY;
    public function __construct(string $F6e5U, ?int $Gsmm4, ?int $iM4bK, float $MXnrL)
    {
        goto af6jK;
        yJ0ea:
        $yqvQi = $this->mLKwCzsAffn($Gsmm4, $iM4bK, $MXnrL);
        goto EWvRx;
        EWvRx:
        Q02Tz:
        goto K7jCs;
        llw8R:
        if (!($Gsmm4 && $iM4bK)) {
            goto Q02Tz;
        }
        goto yJ0ea;
        af6jK:
        $yqvQi = 15000000;
        goto llw8R;
        JqXwu:
        WmB6q:
        goto huj9t;
        K7jCs:
        $this->j1NYY = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $yqvQi, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $F6e5U];
        goto t62Mt;
        ed3Mt:
        $this->j1NYY['VideoDescription']['Width'] = $Gsmm4;
        goto s3nWw;
        t62Mt:
        if (!($Gsmm4 && $iM4bK)) {
            goto WmB6q;
        }
        goto ed3Mt;
        s3nWw:
        $this->j1NYY['VideoDescription']['Height'] = $iM4bK;
        goto JqXwu;
        huj9t:
    }
    public function mocuGwBinBv(Alxlzu9Vtdk0x $Lx01S) : self
    {
        $this->j1NYY['VideoDescription']['VideoPreprocessors'] = $Lx01S->mqeIGlpkXYf();
        return $this;
    }
    public function mDBGlBrTc9k() : array
    {
        return $this->j1NYY;
    }
    private function mLKwCzsAffn(int $Gsmm4, int $iM4bK, float $TYkUU, string $u19tn = 'medium', string $xgeQG = 'h264', string $T_X7M = 'good') : ?int
    {
        goto J1Cqv;
        KGK9I:
        YV4Pz:
        goto p6PfU;
        Nhk_s:
        if ($iIoMB <= 3840 * 2160) {
            goto JVUbf;
        }
        goto QkT0X;
        FslQk:
        $KVROq = max(0.5, $KVROq);
        goto JJq6o;
        rANdq:
        z1ZJU:
        goto dljSt;
        iCd_Q:
        a3kCr:
        goto iIeLC;
        RKqx_:
        XWgIV:
        goto jkMQ2;
        JJq6o:
        return (int) ($KVROq * 1000 * 1000);
        goto HoQme;
        OWoNN:
        W_zsI:
        goto JohTF;
        nKqfe:
        if ($iIoMB <= 1920 * 1080) {
            goto a3kCr;
        }
        goto BxkxF;
        AHZI1:
        goto XWgIV;
        goto nmTMK;
        eeCfT:
        $qqBtc = 1.5;
        goto ZwWpA;
        ZwWpA:
        goto XWgIV;
        goto hin9L;
        l0cqd:
        $qqBtc = 20;
        goto RKqx_;
        dljSt:
        Knk51:
        goto FslQk;
        iIeLC:
        $qqBtc = 7;
        goto GI7r8;
        E13eQ:
        goto XWgIV;
        goto iCd_Q;
        QkT0X:
        $qqBtc = 30;
        goto snFuI;
        BxkxF:
        if ($iIoMB <= 2560 * 1440) {
            goto tRkhT;
        }
        goto Nhk_s;
        GI7r8:
        goto XWgIV;
        goto EVOsD;
        p6PfU:
        switch (strtolower($T_X7M)) {
            case 'low':
                $KVROq *= 0.8;
                goto Knk51;
            case 'high':
                $KVROq *= 1.2;
                goto Knk51;
        }
        goto rANdq;
        JohTF:
        Yh82n:
        goto y1tAG;
        hin9L:
        pvV19:
        goto Zl8_N;
        Zl8_N:
        $qqBtc = 3;
        goto E13eQ;
        jkMQ2:
        $KVROq = $qqBtc * ($TYkUU / 30);
        goto pF6Pi;
        EVOsD:
        tRkhT:
        goto QUDsQ;
        Nq68J:
        D0xhh:
        goto eeCfT;
        nmTMK:
        JVUbf:
        goto l0cqd;
        kOyjd:
        $KVROq *= 0.65;
        goto KGK9I;
        V606n:
        if ($iIoMB <= 640 * 480) {
            goto D0xhh;
        }
        goto PfSQ2;
        QUDsQ:
        $qqBtc = 12;
        goto AHZI1;
        y1tAG:
        if (!('h265' === strtolower($xgeQG) || 'hevc' === strtolower($xgeQG) || 'vp9' === strtolower($xgeQG))) {
            goto YV4Pz;
        }
        goto kOyjd;
        pF6Pi:
        switch (strtolower($u19tn)) {
            case 'low':
                $KVROq *= 0.7;
                goto Yh82n;
            case 'high':
                $KVROq *= 1.3;
                goto Yh82n;
            case 'veryhigh':
                $KVROq *= 1.6;
                goto Yh82n;
        }
        goto OWoNN;
        snFuI:
        goto XWgIV;
        goto Nq68J;
        J1Cqv:
        $iIoMB = $Gsmm4 * $iM4bK;
        goto V606n;
        PfSQ2:
        if ($iIoMB <= 1280 * 720) {
            goto pvV19;
        }
        goto nKqfe;
        HoQme:
    }
}
