<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class WTlTaBvgTA6Ch
{
    private $ywiLP;
    public function __construct(float $I7cMU, int $GNoKB, string $JT_oL)
    {
        goto sAM8J;
        mDwhO:
        $KfzKi = max($KfzKi, 1);
        goto VquK6;
        VquK6:
        $this->ywiLP = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $KfzKi]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $JT_oL]]];
        goto p0vE5;
        sAM8J:
        $KfzKi = (int) $I7cMU / $GNoKB;
        goto mDwhO;
        p0vE5:
    }
    public function mhOK291H5e5() : array
    {
        return $this->ywiLP;
    }
}
