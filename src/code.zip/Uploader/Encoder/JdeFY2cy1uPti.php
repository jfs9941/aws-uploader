<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Encoder;

class JdeFY2cy1uPti
{
    private $IGimW;
    public function __construct(string $Yrsu0, int $rZ91h, int $cV2tR, ?int $Lu5LP, ?int $IPfYY)
    {
        goto V3Ix_;
        FjDr7:
        WfMIY:
        goto Hns6Q;
        haaDW:
        $this->IGimW['ImageInserter']['InsertableImages'][0]['Width'] = $Lu5LP;
        goto Ygg26;
        V3Ix_:
        $this->IGimW = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $rZ91h, 'ImageY' => $cV2tR, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $Yrsu0, 'Opacity' => 35]]]];
        goto EaZDr;
        Ygg26:
        $this->IGimW['ImageInserter']['InsertableImages'][0]['Height'] = $IPfYY;
        goto FjDr7;
        EaZDr:
        if (!($Lu5LP && $IPfYY)) {
            goto WfMIY;
        }
        goto haaDW;
        Hns6Q:
    }
    public function mgnDB0PERWb() : array
    {
        return $this->IGimW;
    }
}
