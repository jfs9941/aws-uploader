<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\NsAe9ORmo3m5D;
final class LbzHNsWFIAPi8
{
    private $g1ymG;
    public function __construct(string $gIGTr, ?int $Sv6q3, ?int $G9pt9, float $qWtjX)
    {
        goto H3roD;
        BigOV:
        if (!($Sv6q3 && $G9pt9)) {
            goto fRTHo;
        }
        goto zxGIq;
        y4eTw:
        fRTHo:
        goto DB3qq;
        Gtm1T:
        $this->g1ymG = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $pYyhf, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $gIGTr];
        goto BigOV;
        YloeB:
        $this->g1ymG['VideoDescription']['Height'] = $G9pt9;
        goto y4eTw;
        yD1kt:
        if (!($Sv6q3 && $G9pt9)) {
            goto rjA3f;
        }
        goto wljuz;
        wljuz:
        $pYyhf = $this->mRPgSeS0Plj($Sv6q3, $G9pt9, $qWtjX);
        goto irZ7g;
        irZ7g:
        rjA3f:
        goto Gtm1T;
        zxGIq:
        $this->g1ymG['VideoDescription']['Width'] = $Sv6q3;
        goto YloeB;
        H3roD:
        $pYyhf = 15000000;
        goto yD1kt;
        DB3qq:
    }
    public function mbryH9c0fv1(NsAe9ORmo3m5D $a74x8) : self
    {
        $this->g1ymG['VideoDescription']['VideoPreprocessors'] = $a74x8->mJWcLknUvpk();
        return $this;
    }
    public function m2GHu5ADPjN() : array
    {
        return $this->g1ymG;
    }
    private function mRPgSeS0Plj(int $Sv6q3, int $G9pt9, float $ur0WD, string $UoYvw = 'medium', string $nDQ67 = 'h264', string $E04Yi = 'good') : ?int
    {
        goto oj8yf;
        HbR2N:
        CE4RK:
        goto nE7Ik;
        MZ05v:
        $l7Alb *= 0.65;
        goto HbR2N;
        V8zH0:
        return (int) ($l7Alb * 1000 * 1000);
        goto aeAMO;
        nU6ZX:
        $bfC1B = 12;
        goto oBc3b;
        KSzot:
        if ($oirja <= 3840 * 2160) {
            goto BA6Fl;
        }
        goto rqgcd;
        WOfUq:
        pD8e1:
        goto k1NlA;
        KocSJ:
        plbvx:
        goto XuXeC;
        sm5Ni:
        goto eDbk6;
        goto tdmyX;
        rqgcd:
        $bfC1B = 30;
        goto TAzIQ;
        XEjaZ:
        $bfC1B = 1.5;
        goto Mmmuu;
        P_xIc:
        if ($oirja <= 1920 * 1080) {
            goto pD8e1;
        }
        goto UPLC1;
        NpTp6:
        if ($oirja <= 1280 * 720) {
            goto PNiKD;
        }
        goto P_xIc;
        Yrmnj:
        $l7Alb = $bfC1B * ($ur0WD / 30);
        goto jsocI;
        EGtT0:
        $bfC1B = 20;
        goto r3Db3;
        vX0C7:
        PNiKD:
        goto SZATa;
        Mmmuu:
        goto eDbk6;
        goto vX0C7;
        XuXeC:
        aM3cy:
        goto Gc4SU;
        xp1NA:
        K3nrM:
        goto V5ZeC;
        khVKG:
        if ($oirja <= 640 * 480) {
            goto NhQ8o;
        }
        goto NpTp6;
        tdmyX:
        u5U41:
        goto nU6ZX;
        SZATa:
        $bfC1B = 3;
        goto P23pr;
        TYQxb:
        gSjG4:
        goto xp1NA;
        P23pr:
        goto eDbk6;
        goto WOfUq;
        t4PpY:
        BA6Fl:
        goto EGtT0;
        oBc3b:
        goto eDbk6;
        goto t4PpY;
        nE7Ik:
        switch (strtolower($E04Yi)) {
            case 'low':
                $l7Alb *= 0.8;
                goto aM3cy;
            case 'high':
                $l7Alb *= 1.2;
                goto aM3cy;
        }
        goto KocSJ;
        Gc4SU:
        $l7Alb = max(0.5, $l7Alb);
        goto V8zH0;
        nhyAk:
        NhQ8o:
        goto XEjaZ;
        r3Db3:
        eDbk6:
        goto Yrmnj;
        TAzIQ:
        goto eDbk6;
        goto nhyAk;
        k1NlA:
        $bfC1B = 7;
        goto sm5Ni;
        oj8yf:
        $oirja = $Sv6q3 * $G9pt9;
        goto khVKG;
        UPLC1:
        if ($oirja <= 2560 * 1440) {
            goto u5U41;
        }
        goto KSzot;
        V5ZeC:
        if (!('h265' === strtolower($nDQ67) || 'hevc' === strtolower($nDQ67) || 'vp9' === strtolower($nDQ67))) {
            goto CE4RK;
        }
        goto MZ05v;
        jsocI:
        switch (strtolower($UoYvw)) {
            case 'low':
                $l7Alb *= 0.7;
                goto K3nrM;
            case 'high':
                $l7Alb *= 1.3;
                goto K3nrM;
            case 'veryhigh':
                $l7Alb *= 1.6;
                goto K3nrM;
        }
        goto TYQxb;
        aeAMO:
    }
}
