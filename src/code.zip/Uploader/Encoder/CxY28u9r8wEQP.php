<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CxY28u9r8wEQP
{
    private $vznDi;
    public function __construct(string $WxPsk, int $CQ58k, int $eZoUz, ?int $NixDl, ?int $l4GK0)
    {
        goto imgOe;
        Es8dM:
        $this->vznDi['ImageInserter']['InsertableImages'][0]['Height'] = $l4GK0;
        goto wcB2v;
        imgOe:
        $this->vznDi = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $CQ58k, 'ImageY' => $eZoUz, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $WxPsk, 'Opacity' => 35]]]];
        goto VrqDa;
        VrqDa:
        if (!($NixDl && $l4GK0)) {
            goto CEeqX;
        }
        goto h9HZh;
        h9HZh:
        $this->vznDi['ImageInserter']['InsertableImages'][0]['Width'] = $NixDl;
        goto Es8dM;
        wcB2v:
        CEeqX:
        goto t_5tK;
        t_5tK:
    }
    public function m3KkEYLjtno() : array
    {
        return $this->vznDi;
    }
}
