<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\IaJdFtE5S3xOF;
final class XjTsbRWUA8NWj
{
    private $Y9zOD;
    public function __construct(string $WfqIk, ?int $SAWrT, ?int $rnPww, float $mcLHZ)
    {
        goto dvrzO;
        Z2TfM:
        if (!($SAWrT && $rnPww)) {
            goto sbFrr;
        }
        goto N5S2j;
        cxSx8:
        if (!($SAWrT && $rnPww)) {
            goto fdzeB;
        }
        goto PTapb;
        gmnYo:
        sbFrr:
        goto w7jKj;
        PTapb:
        $this->Y9zOD['VideoDescription']['Width'] = $SAWrT;
        goto DDvO2;
        dvrzO:
        $IBRpU = 15000000;
        goto Z2TfM;
        w7jKj:
        $this->Y9zOD = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $IBRpU, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $WfqIk];
        goto cxSx8;
        DDvO2:
        $this->Y9zOD['VideoDescription']['Height'] = $rnPww;
        goto ZXMOp;
        N5S2j:
        $IBRpU = $this->mhCg9FeD1r3($SAWrT, $rnPww, $mcLHZ);
        goto gmnYo;
        ZXMOp:
        fdzeB:
        goto RXoWC;
        RXoWC:
    }
    public function mkrKZ51cBEF(IaJdFtE5S3xOF $fjHjk) : self
    {
        $this->Y9zOD['VideoDescription']['VideoPreprocessors'] = $fjHjk->mFFPXaP5cRN();
        return $this;
    }
    public function mkLyhTFvyjN() : array
    {
        return $this->Y9zOD;
    }
    private function mhCg9FeD1r3(int $SAWrT, int $rnPww, float $cSWEq, string $C48L4 = 'medium', string $IAdb8 = 'h264', string $xtTTV = 'good') : ?int
    {
        goto FDKaa;
        pzxRC:
        KqijQ:
        goto RpWiV;
        Xjq2z:
        switch (strtolower($xtTTV)) {
            case 'low':
                $HCwIA *= 0.8;
                goto bZzsQ;
            case 'high':
                $HCwIA *= 1.2;
                goto bZzsQ;
        }
        goto pzxRC;
        zekQJ:
        $qE1cf = 7;
        goto rRF1P;
        ZxhdC:
        ynugY:
        goto jGR6J;
        RpWiV:
        bZzsQ:
        goto EaIxD;
        AAvMq:
        if ($o0Uk4 <= 3840 * 2160) {
            goto WLJO_;
        }
        goto EBQ3J;
        KILJv:
        ttWB3:
        goto rN2KZ;
        rRF1P:
        goto ynugY;
        goto l_TJa;
        Y5DWi:
        goto ynugY;
        goto t1_gq;
        nVmMI:
        switch (strtolower($C48L4)) {
            case 'low':
                $HCwIA *= 0.7;
                goto ttWB3;
            case 'high':
                $HCwIA *= 1.3;
                goto ttWB3;
            case 'veryhigh':
                $HCwIA *= 1.6;
                goto ttWB3;
        }
        goto hOQil;
        fS1Pb:
        $qE1cf = 1.5;
        goto KOt8z;
        cNJiQ:
        QHl9O:
        goto Xjq2z;
        K6a1A:
        if ($o0Uk4 <= 640 * 480) {
            goto Ly65n;
        }
        goto waxMk;
        S_QTX:
        qSvOA:
        goto FSJRg;
        MBs2J:
        if ($o0Uk4 <= 2560 * 1440) {
            goto a22xs;
        }
        goto AAvMq;
        UAM_q:
        Ly65n:
        goto fS1Pb;
        EBQ3J:
        $qE1cf = 30;
        goto PeDFw;
        xVaVu:
        $qE1cf = 20;
        goto ZxhdC;
        jGR6J:
        $HCwIA = $qE1cf * ($cSWEq / 30);
        goto nVmMI;
        Aqmqx:
        $qE1cf = 12;
        goto Y5DWi;
        zJ7ag:
        goto ynugY;
        goto MPU4m;
        JDard:
        if ($o0Uk4 <= 1920 * 1080) {
            goto tGAGL;
        }
        goto MBs2J;
        waxMk:
        if ($o0Uk4 <= 1280 * 720) {
            goto qSvOA;
        }
        goto JDard;
        FSJRg:
        $qE1cf = 3;
        goto zJ7ag;
        EaIxD:
        $HCwIA = max(0.5, $HCwIA);
        goto w4hc1;
        t1_gq:
        WLJO_:
        goto xVaVu;
        w4hc1:
        return (int) ($HCwIA * 1000 * 1000);
        goto CPCB1;
        rN2KZ:
        if (!('h265' === strtolower($IAdb8) || 'hevc' === strtolower($IAdb8) || 'vp9' === strtolower($IAdb8))) {
            goto QHl9O;
        }
        goto s1bNb;
        l_TJa:
        a22xs:
        goto Aqmqx;
        FDKaa:
        $o0Uk4 = $SAWrT * $rnPww;
        goto K6a1A;
        s1bNb:
        $HCwIA *= 0.65;
        goto cNJiQ;
        KOt8z:
        goto ynugY;
        goto S_QTX;
        hOQil:
        Zu730:
        goto KILJv;
        MPU4m:
        tGAGL:
        goto zekQJ;
        PeDFw:
        goto ynugY;
        goto UAM_q;
        CPCB1:
    }
}
