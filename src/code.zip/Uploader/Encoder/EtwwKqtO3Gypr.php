<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class EtwwKqtO3Gypr
{
    private $BIQot;
    public function __construct(string $iG4mK, int $gxiKM, int $Za1X5, ?int $IxHFs, ?int $Ijyqc)
    {
        goto uabbn;
        nDJxU:
        if (!($IxHFs && $Ijyqc)) {
            goto vf2rC;
        }
        goto Y_LuI;
        QXXzT:
        vf2rC:
        goto Vu122;
        Y_LuI:
        $this->BIQot['ImageInserter']['InsertableImages'][0]['Width'] = $IxHFs;
        goto tB3FT;
        tB3FT:
        $this->BIQot['ImageInserter']['InsertableImages'][0]['Height'] = $Ijyqc;
        goto QXXzT;
        uabbn:
        $this->BIQot = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $gxiKM, 'ImageY' => $Za1X5, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $iG4mK, 'Opacity' => 35]]]];
        goto nDJxU;
        Vu122:
    }
    public function mNXnBm1dmHe() : array
    {
        return $this->BIQot;
    }
}
