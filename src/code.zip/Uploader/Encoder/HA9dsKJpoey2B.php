<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class HA9dsKJpoey2B
{
    private $EFs40;
    public function __construct(string $LQLky, int $PPmkx, int $hgpjJ, ?int $V0H7W, ?int $nO8OT)
    {
        goto J37wI;
        rdcbw:
        $this->EFs40['ImageInserter']['InsertableImages'][0]['Width'] = $V0H7W;
        goto BGVme;
        t9kgX:
        h17a2:
        goto Zblul;
        X9etw:
        if (!($V0H7W && $nO8OT)) {
            goto h17a2;
        }
        goto rdcbw;
        J37wI:
        $this->EFs40 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $PPmkx, 'ImageY' => $hgpjJ, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $LQLky, 'Opacity' => 35]]]];
        goto X9etw;
        BGVme:
        $this->EFs40['ImageInserter']['InsertableImages'][0]['Height'] = $nO8OT;
        goto t9kgX;
        Zblul:
    }
    public function mqPQy3gJUtN() : array
    {
        return $this->EFs40;
    }
}
