<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\VKAnM1rNBvZzz;
final class FJLxKHdfSuKx4
{
    private $znmpn;
    public function __construct(string $x_P_T, ?int $GPsTK, ?int $ldQdP, float $WMAam)
    {
        goto GdhUs;
        jJfYf:
        b6MKZ:
        goto vZuEi;
        pswaP:
        if (!($GPsTK && $ldQdP)) {
            goto b6MKZ;
        }
        goto rbqCO;
        jORJw:
        $this->znmpn['VideoDescription']['Height'] = $ldQdP;
        goto jJfYf;
        FLkR8:
        $ovpAr = $this->mxEAb9a8wHL($GPsTK, $ldQdP, $WMAam);
        goto SH2CL;
        SH2CL:
        tJRin:
        goto G01ZE;
        G01ZE:
        $this->znmpn = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $ovpAr, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $x_P_T];
        goto pswaP;
        rbqCO:
        $this->znmpn['VideoDescription']['Width'] = $GPsTK;
        goto jORJw;
        s6QEn:
        if (!($GPsTK && $ldQdP)) {
            goto tJRin;
        }
        goto FLkR8;
        GdhUs:
        $ovpAr = 15000000;
        goto s6QEn;
        vZuEi:
    }
    public function mD9eX58vV7A(VKAnM1rNBvZzz $S3ETt) : self
    {
        $this->znmpn['VideoDescription']['VideoPreprocessors'] = $S3ETt->mJqY3YRl8fG();
        return $this;
    }
    public function mg2MGyjQOx2() : array
    {
        return $this->znmpn;
    }
    private function mxEAb9a8wHL(int $GPsTK, int $ldQdP, float $iB19G, string $j48I4 = 'medium', string $UDDfT = 'h264', string $zOD2j = 'good') : ?int
    {
        goto hxD0h;
        dpuw4:
        if ($AxJws <= 2560 * 1440) {
            goto dnHEc;
        }
        goto NoGh5;
        sKGvG:
        L4Qv6:
        goto H2vFH;
        Arhs6:
        if ($AxJws <= 1920 * 1080) {
            goto L0rdk;
        }
        goto dpuw4;
        NoGh5:
        if ($AxJws <= 3840 * 2160) {
            goto L4Qv6;
        }
        goto iEcKA;
        GE8U7:
        $m2HzD = $gOTY1 * ($iB19G / 30);
        goto h_i2I;
        H2vFH:
        $gOTY1 = 20;
        goto BUBco;
        HbzvG:
        goto vKWiX;
        goto dbGop;
        IARux:
        t0p2L:
        goto XuKiP;
        AiQ5w:
        goto vKWiX;
        goto sKGvG;
        u3wqo:
        goto vKWiX;
        goto x9fvm;
        x9fvm:
        L0rdk:
        goto x5ePb;
        cU2bO:
        goto vKWiX;
        goto QgRmA;
        oER0B:
        switch (strtolower($zOD2j)) {
            case 'low':
                $m2HzD *= 0.8;
                goto MLwFQ;
            case 'high':
                $m2HzD *= 1.2;
                goto MLwFQ;
        }
        goto CNf92;
        e0RnS:
        $gOTY1 = 12;
        goto AiQ5w;
        BUBco:
        vKWiX:
        goto GE8U7;
        x5ePb:
        $gOTY1 = 7;
        goto HbzvG;
        IMuH5:
        M2bdi:
        goto oER0B;
        CAck0:
        goto vKWiX;
        goto IARux;
        XipUX:
        if ($AxJws <= 640 * 480) {
            goto t0p2L;
        }
        goto vWE6S;
        Su6Ze:
        $m2HzD *= 0.65;
        goto IMuH5;
        hxD0h:
        $AxJws = $GPsTK * $ldQdP;
        goto XipUX;
        QgRmA:
        DQSqZ:
        goto AXK_V;
        CNf92:
        JJXuS:
        goto v1Xnq;
        vWE6S:
        if ($AxJws <= 1280 * 720) {
            goto DQSqZ;
        }
        goto Arhs6;
        fbTWG:
        if (!('h265' === strtolower($UDDfT) || 'hevc' === strtolower($UDDfT) || 'vp9' === strtolower($UDDfT))) {
            goto M2bdi;
        }
        goto Su6Ze;
        h_i2I:
        switch (strtolower($j48I4)) {
            case 'low':
                $m2HzD *= 0.7;
                goto lATdI;
            case 'high':
                $m2HzD *= 1.3;
                goto lATdI;
            case 'veryhigh':
                $m2HzD *= 1.6;
                goto lATdI;
        }
        goto dKmle;
        Kvpzi:
        $m2HzD = max(0.5, $m2HzD);
        goto wE5Ws;
        iEcKA:
        $gOTY1 = 30;
        goto CAck0;
        dbGop:
        dnHEc:
        goto e0RnS;
        fCHnq:
        lATdI:
        goto fbTWG;
        AXK_V:
        $gOTY1 = 3;
        goto u3wqo;
        dKmle:
        btySI:
        goto fCHnq;
        v1Xnq:
        MLwFQ:
        goto Kvpzi;
        wE5Ws:
        return (int) ($m2HzD * 1000 * 1000);
        goto cbRxl;
        XuKiP:
        $gOTY1 = 1.5;
        goto cU2bO;
        cbRxl:
    }
}
