<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Q74VPxpLowiUP
{
    private $Ij3xP;
    public function __construct(float $uylfg, int $BWvJh, string $bRtxN)
    {
        goto XE45b;
        XE45b:
        $cCRGC = (int) $uylfg / $BWvJh;
        goto c_2Za;
        c_2Za:
        $cCRGC = max($cCRGC, 1);
        goto OGhRC;
        OGhRC:
        $this->Ij3xP = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $cCRGC]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $bRtxN]]];
        goto gKwUj;
        gKwUj:
    }
    public function mXlWGmlfxqc() : array
    {
        return $this->Ij3xP;
    }
}
