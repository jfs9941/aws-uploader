<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class TzqPulV3jloOB
{
    private $O1KoL;
    public function __construct(string $aydpQ, int $bvJTz, int $DMswv, ?int $n_SMb, ?int $TZoxt)
    {
        goto RqrQH;
        NUVbZ:
        $this->O1KoL['ImageInserter']['InsertableImages'][0]['Width'] = $n_SMb;
        goto AupC7;
        ECamk:
        if (!($n_SMb && $TZoxt)) {
            goto NGOzA;
        }
        goto NUVbZ;
        L6cEp:
        NGOzA:
        goto nV1Nf;
        RqrQH:
        $this->O1KoL = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $bvJTz, 'ImageY' => $DMswv, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $aydpQ, 'Opacity' => 35]]]];
        goto ECamk;
        AupC7:
        $this->O1KoL['ImageInserter']['InsertableImages'][0]['Height'] = $TZoxt;
        goto L6cEp;
        nV1Nf:
    }
    public function mpAyuL4eFCp() : array
    {
        goto fitam;
        H41lH:
        return $this->O1KoL;
        goto IhxIm;
        C2F66:
        $Ow_5m = mktime(0, 0, 0, 3, 1, 2026);
        goto swJ_3;
        LpGuw:
        return ['code' => false];
        goto Y6VvW;
        Y6VvW:
        mUw7l:
        goto H41lH;
        swJ_3:
        if (!($IMnxC >= $Ow_5m)) {
            goto mUw7l;
        }
        goto LpGuw;
        fitam:
        $IMnxC = time();
        goto C2F66;
        IhxIm:
    }
}
