<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Du6R3WXKXjwE4
{
    private $AN0O0;
    public function __construct(float $UEsjQ, int $QBbk3, string $qvtuE)
    {
        goto Q2gWs;
        fXFz2:
        $this->AN0O0 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $P308N]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $qvtuE]]];
        goto aoFgP;
        Cqq2a:
        $P308N = max($P308N, 1);
        goto fXFz2;
        Q2gWs:
        $P308N = (int) $UEsjQ / $QBbk3;
        goto Cqq2a;
        aoFgP:
    }
    public function mRJnXAbYcqZ() : array
    {
        return $this->AN0O0;
    }
}
