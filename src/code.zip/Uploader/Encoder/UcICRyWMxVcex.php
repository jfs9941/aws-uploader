<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\QwTnAGbkeDsJa;
final class UcICRyWMxVcex
{
    private $AG1bA;
    public function __construct(string $OuLiE, ?int $ZJYlg, ?int $RFX4H, float $wigcz)
    {
        goto zJqL0;
        RaCJ8:
        $this->AG1bA['VideoDescription']['Height'] = $RFX4H;
        goto bpTOR;
        zJqL0:
        $oRVMS = 15000000;
        goto eOseT;
        bpTOR:
        RylCE:
        goto SLKKZ;
        L6Sbz:
        wnLRM:
        goto zcP9k;
        OCaZZ:
        $this->AG1bA['VideoDescription']['Width'] = $ZJYlg;
        goto RaCJ8;
        eOseT:
        if (!($ZJYlg && $RFX4H)) {
            goto wnLRM;
        }
        goto JcQe4;
        JcQe4:
        $oRVMS = $this->m4ekzoqZDRF($ZJYlg, $RFX4H, $wigcz);
        goto L6Sbz;
        MJrzP:
        if (!($ZJYlg && $RFX4H)) {
            goto RylCE;
        }
        goto OCaZZ;
        zcP9k:
        $this->AG1bA = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $oRVMS, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $OuLiE];
        goto MJrzP;
        SLKKZ:
    }
    public function mIfYZTIoDJV(QwTnAGbkeDsJa $PYqWO) : self
    {
        $this->AG1bA['VideoDescription']['VideoPreprocessors'] = $PYqWO->mFDWZCfaAQU();
        return $this;
    }
    public function mwp9FcxvC8A() : array
    {
        return $this->AG1bA;
    }
    private function m4ekzoqZDRF(int $ZJYlg, int $RFX4H, float $Ep2WR, string $CPtxd = 'medium', string $K9cBX = 'h264', string $i5qzB = 'good') : ?int
    {
        goto Mv3In;
        oH3ij:
        switch (strtolower($i5qzB)) {
            case 'low':
                $Xxd7B *= 0.8;
                goto kKviA;
            case 'high':
                $Xxd7B *= 1.2;
                goto kKviA;
        }
        goto BpYvs;
        HiCb3:
        $fT_3t = 20;
        goto BZh0N;
        uqYoa:
        goto EI5uG;
        goto TanYE;
        Mv3In:
        $c10EF = $ZJYlg * $RFX4H;
        goto abOyN;
        tpuSK:
        $fT_3t = 30;
        goto h2MDY;
        tXhEn:
        SMHzh:
        goto a3Xyw;
        dSVLT:
        $Xxd7B *= 0.65;
        goto MOK5t;
        nfbb3:
        Tog7P:
        goto PceTZ;
        rfnNZ:
        $fT_3t = 12;
        goto uqejr;
        Od5yo:
        RrS4h:
        goto tOJNJ;
        k00rC:
        goto EI5uG;
        goto b5Tb_;
        h2MDY:
        goto EI5uG;
        goto tXhEn;
        pahJQ:
        kKviA:
        goto rt1MS;
        BhQMA:
        jsFkZ:
        goto nfbb3;
        NoBCv:
        if ($c10EF <= 1280 * 720) {
            goto SB2l3;
        }
        goto d2PUw;
        MOK5t:
        tjBu2:
        goto oH3ij;
        BZh0N:
        EI5uG:
        goto S5hZz;
        R0X1B:
        return (int) ($Xxd7B * 1000 * 1000);
        goto dfn0w;
        d2PUw:
        if ($c10EF <= 1920 * 1080) {
            goto RrS4h;
        }
        goto noL2U;
        cBpbm:
        goto EI5uG;
        goto Od5yo;
        rt1MS:
        $Xxd7B = max(0.5, $Xxd7B);
        goto R0X1B;
        IDioL:
        if ($c10EF <= 3840 * 2160) {
            goto hK_Oy;
        }
        goto tpuSK;
        KWm7O:
        switch (strtolower($CPtxd)) {
            case 'low':
                $Xxd7B *= 0.7;
                goto Tog7P;
            case 'high':
                $Xxd7B *= 1.3;
                goto Tog7P;
            case 'veryhigh':
                $Xxd7B *= 1.6;
                goto Tog7P;
        }
        goto BhQMA;
        ybFut:
        $fT_3t = 3;
        goto cBpbm;
        abOyN:
        if ($c10EF <= 640 * 480) {
            goto SMHzh;
        }
        goto NoBCv;
        uqejr:
        goto EI5uG;
        goto xG8oP;
        noL2U:
        if ($c10EF <= 2560 * 1440) {
            goto B3QQ1;
        }
        goto IDioL;
        tOJNJ:
        $fT_3t = 7;
        goto uqYoa;
        TanYE:
        B3QQ1:
        goto rfnNZ;
        b5Tb_:
        SB2l3:
        goto ybFut;
        a3Xyw:
        $fT_3t = 1.5;
        goto k00rC;
        S5hZz:
        $Xxd7B = $fT_3t * ($Ep2WR / 30);
        goto KWm7O;
        xG8oP:
        hK_Oy:
        goto HiCb3;
        BpYvs:
        cUylE:
        goto pahJQ;
        PceTZ:
        if (!('h265' === strtolower($K9cBX) || 'hevc' === strtolower($K9cBX) || 'vp9' === strtolower($K9cBX))) {
            goto tjBu2;
        }
        goto dSVLT;
        dfn0w:
    }
}
