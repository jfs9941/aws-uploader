<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\IA5k3DCuxC3EX;
use Jfs\Uploader\Encoder\InuwBbIMQbzyz;
use Jfs\Uploader\Encoder\NXegFzNpQV853;
use Illuminate\Support\Facades\Log;
final class V9kB8ekPBG4Tf
{
    private $mdKLP;
    private $KaSaS;
    private $WoILt;
    private $ttqSA;
    private $CO3TB;
    private $pq1bT;
    private $wVPkg;
    public function __construct(MediaConvertClient $U94Aa, $QDc2h, $XIWwq)
    {
        goto iqrUH;
        Sv2F3:
        $this->pq1bT = $XIWwq;
        goto Y8Her;
        iqrUH:
        $this->ttqSA = $U94Aa;
        goto bO1_9;
        bO1_9:
        $this->CO3TB = $QDc2h;
        goto Sv2F3;
        Y8Her:
    }
    public function mj74F0lfXBp() : MediaConvertClient
    {
        return $this->ttqSA;
    }
    public function mMWtvVrUnnu(NXegFzNpQV853 $jOilL) : self
    {
        $this->mdKLP = $jOilL;
        return $this;
    }
    public function mvJno8COB69(string $h6mbG) : self
    {
        $this->WoILt = $h6mbG;
        return $this;
    }
    public function mHdZRWLqron(InuwBbIMQbzyz $nevNW) : self
    {
        $this->KaSaS[] = $nevNW;
        return $this;
    }
    public function mZunF2mARjZ(IA5k3DCuxC3EX $T07ak) : self
    {
        $this->wVPkg = $T07ak;
        return $this;
    }
    private function muogpLZDrfW(bool $c9iN1) : array
    {
        goto Ix0nq;
        NbA9i:
        $W4aaX['Role'] = $this->CO3TB;
        goto HuTz_;
        XTb0h:
        $W4aaX['AccelerationSettings']['Mode'] = 'ENABLED';
        goto O6nGD;
        L54ZX:
        if (!$c9iN1) {
            goto P0jKq;
        }
        goto XTb0h;
        NH0k7:
        $W4aaX['Settings']['OutputGroups'][] = $this->wVPkg->m2bpAztczG8();
        goto dsF91;
        tSn3s:
        if (!$this->wVPkg) {
            goto mMhEG;
        }
        goto NH0k7;
        Mb7wp:
        $W4aaX['Settings']['Inputs'] = $this->mdKLP->moy9vr6NxZE();
        goto HFOoq;
        bF7t3:
        $I2jnM['Outputs'] = [];
        goto DPWVx;
        dsF91:
        mMhEG:
        goto L54ZX;
        DPWVx:
        foreach ($this->KaSaS as $nevNW) {
            $I2jnM['Outputs'][] = $nevNW->mvAImOIvgIn();
            zpH81:
        }
        goto Qo3RD;
        MYtoI:
        ne5or:
        goto Mb7wp;
        YBHkK:
        $this->wVPkg = null;
        goto Eyh_f;
        G2bmc:
        unset($W4aaX['Settings']['OutputGroups']);
        goto bF7t3;
        Eyh_f:
        $this->mdKLP = null;
        goto v7a6l;
        WWF_z:
        if ($this->mdKLP) {
            goto ne5or;
        }
        goto b_qEl;
        AKxa3:
        return $W4aaX;
        goto d1Jku;
        u5zYw:
        $I2jnM['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->WoILt;
        goto d_fhn;
        v7a6l:
        $this->KaSaS = [];
        goto AKxa3;
        HFOoq:
        $I2jnM = $W4aaX['Settings']['OutputGroups'][0];
        goto G2bmc;
        O6nGD:
        P0jKq:
        goto YBHkK;
        Qo3RD:
        qgGKj:
        goto u5zYw;
        HuTz_:
        $W4aaX['Queue'] = $this->pq1bT;
        goto WWF_z;
        Ix0nq:
        $W4aaX = (require 'template.php');
        goto NbA9i;
        d_fhn:
        $W4aaX['Settings']['OutputGroups'][] = $I2jnM;
        goto tSn3s;
        b_qEl:
        throw new \LogicException('You must provide a input file to use');
        goto MYtoI;
        d1Jku:
    }
    public function m3xqNgOuyvH(bool $c9iN1 = false) : string
    {
        try {
            $pVb4c = $this->ttqSA->createJob($this->muogpLZDrfW($c9iN1));
            return $pVb4c->get('Job')['Id'];
        } catch (AwsException $lzebJ) {
            Log::error('Error creating MediaConvert job: ' . $lzebJ->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $lzebJ);
        }
    }
}
