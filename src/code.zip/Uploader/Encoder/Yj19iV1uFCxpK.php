<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Yj19iV1uFCxpK
{
    private $OFuJP;
    public function __construct(float $pvqTf, int $jIZFs, string $NeKM2)
    {
        goto sN2ZL;
        XaR89:
        $Vtd5s = max($Vtd5s, 1);
        goto cBa1q;
        cBa1q:
        $this->OFuJP = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $Vtd5s]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $NeKM2]]];
        goto aJrMc;
        sN2ZL:
        $Vtd5s = (int) $pvqTf / $jIZFs;
        goto XaR89;
        aJrMc:
    }
    public function mqoIvPsFZpI() : array
    {
        return $this->OFuJP;
    }
}
