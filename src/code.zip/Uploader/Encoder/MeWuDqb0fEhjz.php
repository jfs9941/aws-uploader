<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\MgrvlygkdVSsk;
use Jfs\Uploader\Encoder\SlIVoKaoiMz2R;
use Jfs\Uploader\Encoder\REmYsZqYs4zoN;
use Illuminate\Support\Facades\Log;
final class MeWuDqb0fEhjz
{
    private $x2m9K;
    private $HlQgS;
    private $abXNQ;
    private $uPlA1;
    private $FV7IU;
    private $gvTTn;
    private $ipAoK;
    public function __construct(MediaConvertClient $sWiqT, $cCx7Z, $R91ko)
    {
        goto Om7CM;
        uKJNU:
        $this->gvTTn = $R91ko;
        goto HY03y;
        V7WWG:
        $this->FV7IU = $cCx7Z;
        goto uKJNU;
        Om7CM:
        $this->uPlA1 = $sWiqT;
        goto V7WWG;
        HY03y:
    }
    public function m392kJCoyUZ() : MediaConvertClient
    {
        return $this->uPlA1;
    }
    public function mcjLPIWoXTz(REmYsZqYs4zoN $Rq2w8) : self
    {
        $this->x2m9K = $Rq2w8;
        return $this;
    }
    public function mc9UXrQrNX3(string $uJp0K) : self
    {
        $this->abXNQ = $uJp0K;
        return $this;
    }
    public function mXerkE5mk8C(SlIVoKaoiMz2R $emfTq) : self
    {
        $this->HlQgS[] = $emfTq;
        return $this;
    }
    public function mHlXwZI38Kk(MgrvlygkdVSsk $UT4QS) : self
    {
        $this->ipAoK = $UT4QS;
        return $this;
    }
    private function m0SM1PMwhWP(bool $DWtTf) : array
    {
        goto oAvE9;
        IIQ6r:
        throw new \LogicException('You must provide a input file to use');
        goto uHktC;
        KYLWQ:
        $UlcZh = $dE3RD['Settings']['OutputGroups'][0];
        goto FViR7;
        uHktC:
        w9TuH:
        goto g5hbU;
        j1KqO:
        tVGPj:
        goto gN65n;
        kUh6K:
        $this->x2m9K = null;
        goto tXsxu;
        riWj3:
        if (!$this->ipAoK) {
            goto u4v1i;
        }
        goto DBDe5;
        gN65n:
        $this->ipAoK = null;
        goto kUh6K;
        L5IGm:
        if (!$DWtTf) {
            goto tVGPj;
        }
        goto udZvB;
        Gb7nJ:
        $UlcZh['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->abXNQ;
        goto gPE8E;
        gPE8E:
        $dE3RD['Settings']['OutputGroups'][] = $UlcZh;
        goto riWj3;
        IfLwH:
        if ($this->x2m9K) {
            goto w9TuH;
        }
        goto IIQ6r;
        udZvB:
        $dE3RD['AccelerationSettings']['Mode'] = 'ENABLED';
        goto j1KqO;
        oAvE9:
        $dE3RD = (require 'template.php');
        goto JhPkN;
        vb4NN:
        foreach ($this->HlQgS as $emfTq) {
            $UlcZh['Outputs'][] = $emfTq->m0ECWmavCZK();
            cypGg:
        }
        goto Qgfxs;
        Y3Qad:
        $UlcZh['Outputs'] = [];
        goto vb4NN;
        p0Ej5:
        u4v1i:
        goto L5IGm;
        JhPkN:
        $dE3RD['Role'] = $this->FV7IU;
        goto vy7rD;
        FViR7:
        unset($dE3RD['Settings']['OutputGroups']);
        goto Y3Qad;
        Qgfxs:
        gNQXW:
        goto Gb7nJ;
        NOewz:
        return $dE3RD;
        goto X7uqN;
        g5hbU:
        $dE3RD['Settings']['Inputs'] = $this->x2m9K->m9nxYVo90H6();
        goto KYLWQ;
        tXsxu:
        $this->HlQgS = [];
        goto NOewz;
        vy7rD:
        $dE3RD['Queue'] = $this->gvTTn;
        goto IfLwH;
        DBDe5:
        $dE3RD['Settings']['OutputGroups'][] = $this->ipAoK->moHpVsEqZyT();
        goto p0Ej5;
        X7uqN:
    }
    public function mIwUmoVM1Md(bool $DWtTf = false) : string
    {
        try {
            $U_gac = $this->uPlA1->createJob($this->m0SM1PMwhWP($DWtTf));
            return $U_gac->get('Jobs')['Id'];
        } catch (AwsException $x4bzR) {
            Log::error('Error creating MediaConvert job: ' . $x4bzR->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $x4bzR);
        }
    }
}
