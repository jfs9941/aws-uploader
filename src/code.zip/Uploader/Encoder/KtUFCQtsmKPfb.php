<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\VNBPBDslqfoC3;
final class KtUFCQtsmKPfb
{
    private $swX4h;
    public function __construct(string $azVMA, ?int $lvh9C, ?int $S3Wk9, float $XxAl7)
    {
        goto NXlzO;
        f3BYy:
        $Crjwl = $this->meCzpo7upoO($lvh9C, $S3Wk9, $XxAl7);
        goto oUQak;
        MVgGQ:
        if (!($lvh9C && $S3Wk9)) {
            goto TvRNk;
        }
        goto sB4LG;
        jYOyp:
        $this->swX4h = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $Crjwl, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $azVMA];
        goto MVgGQ;
        rlber:
        TvRNk:
        goto scEKB;
        oiF0i:
        if (!($lvh9C && $S3Wk9)) {
            goto jlrKg;
        }
        goto f3BYy;
        sB4LG:
        $this->swX4h['VideoDescription']['Width'] = $lvh9C;
        goto TJl1s;
        NXlzO:
        $Crjwl = 15000000;
        goto oiF0i;
        oUQak:
        jlrKg:
        goto jYOyp;
        TJl1s:
        $this->swX4h['VideoDescription']['Height'] = $S3Wk9;
        goto rlber;
        scEKB:
    }
    public function maegZV38SvF(VNBPBDslqfoC3 $MsaVt) : self
    {
        $this->swX4h['VideoDescription']['VideoPreprocessors'] = $MsaVt->m5KMZKGGUsQ();
        return $this;
    }
    public function mWjRuKRYX4u() : array
    {
        return $this->swX4h;
    }
    private function meCzpo7upoO(int $lvh9C, int $S3Wk9, float $VLMzA, string $Z1CPT = 'medium', string $jeBai = 'h264', string $qL4PM = 'good') : ?int
    {
        goto w0MnU;
        CjSXU:
        BYGuh:
        goto fBiqY;
        cJCs9:
        goto rMzCH;
        goto EBIb5;
        s3vk_:
        x40d6:
        goto J8rwB;
        J8rwB:
        switch (strtolower($qL4PM)) {
            case 'low':
                $HRMzF *= 0.8;
                goto fftg8;
            case 'high':
                $HRMzF *= 1.2;
                goto fftg8;
        }
        goto k0G1W;
        G4Nai:
        zZV4I:
        goto an3F6;
        cSDLl:
        goto rMzCH;
        goto ghAcK;
        x98V2:
        $C7iZU = 3;
        goto PVdCa;
        OSIUU:
        Fc3HN:
        goto yAbOz;
        PVdCa:
        goto rMzCH;
        goto G4Nai;
        PRHTi:
        if ($a7CHo <= 640 * 480) {
            goto CBsFS;
        }
        goto R_3Y9;
        kRpkC:
        UCxRJ:
        goto OSIUU;
        aj1nt:
        $C7iZU = 12;
        goto nLouO;
        qJkH9:
        if ($a7CHo <= 1920 * 1080) {
            goto zZV4I;
        }
        goto XC7v4;
        eHi53:
        fftg8:
        goto N2DGC;
        Ooa0a:
        switch (strtolower($Z1CPT)) {
            case 'low':
                $HRMzF *= 0.7;
                goto Fc3HN;
            case 'high':
                $HRMzF *= 1.3;
                goto Fc3HN;
            case 'veryhigh':
                $HRMzF *= 1.6;
                goto Fc3HN;
        }
        goto kRpkC;
        VB2Ta:
        $C7iZU = 1.5;
        goto cJCs9;
        xLCiI:
        $HRMzF = $C7iZU * ($VLMzA / 30);
        goto Ooa0a;
        EBIb5:
        A2kV0:
        goto x98V2;
        R_3Y9:
        if ($a7CHo <= 1280 * 720) {
            goto A2kV0;
        }
        goto qJkH9;
        fBiqY:
        $C7iZU = 20;
        goto Sainy;
        yAbOz:
        if (!('h265' === strtolower($jeBai) || 'hevc' === strtolower($jeBai) || 'vp9' === strtolower($jeBai))) {
            goto x40d6;
        }
        goto IW7JO;
        qMGln:
        if ($a7CHo <= 3840 * 2160) {
            goto BYGuh;
        }
        goto TyEA2;
        pJKBt:
        return (int) ($HRMzF * 1000 * 1000);
        goto KYQwj;
        qo8Cn:
        CBsFS:
        goto VB2Ta;
        Sainy:
        rMzCH:
        goto xLCiI;
        an3F6:
        $C7iZU = 7;
        goto cSDLl;
        TyEA2:
        $C7iZU = 30;
        goto aibn5;
        IW7JO:
        $HRMzF *= 0.65;
        goto s3vk_;
        k0G1W:
        uaipV:
        goto eHi53;
        aibn5:
        goto rMzCH;
        goto qo8Cn;
        w0MnU:
        $a7CHo = $lvh9C * $S3Wk9;
        goto PRHTi;
        nLouO:
        goto rMzCH;
        goto CjSXU;
        ghAcK:
        cH3zH:
        goto aj1nt;
        N2DGC:
        $HRMzF = max(0.5, $HRMzF);
        goto pJKBt;
        XC7v4:
        if ($a7CHo <= 2560 * 1440) {
            goto cH3zH;
        }
        goto qMGln;
        KYQwj:
    }
}
