<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class HOZ8jeXzeceNN
{
    private $VJKQ0;
    private $I_pl9;
    private $cVLsV;
    private $KuKnv;
    private $RP0yH;
    private $XFL_s;
    private $DwgfU;
    public function __construct(MediaConvertClient $aMNvn, $hOGLY, $AyYqX)
    {
        goto WQPOi;
        WQPOi:
        $this->KuKnv = $aMNvn;
        goto D69K1;
        D69K1:
        $this->RP0yH = $hOGLY;
        goto eteh1;
        eteh1:
        $this->XFL_s = $AyYqX;
        goto Ok2v4;
        Ok2v4:
    }
    public function mV6jw4t1VFB() : MediaConvertClient
    {
        return $this->KuKnv;
    }
    public function mVvFjPHT0qr(PKlJdyi6xw084 $QHyDD) : self
    {
        $this->VJKQ0 = $QHyDD;
        return $this;
    }
    public function mPPcd3dshAp(string $OZyjE) : self
    {
        $this->cVLsV = $OZyjE;
        return $this;
    }
    public function mi8D4hxwFye(IY6DvZwAf7aLQ $C7b04) : self
    {
        $this->I_pl9[] = $C7b04;
        return $this;
    }
    public function mpKTEvsTBmY(SbtGdhmiZTwWn $FFU0R) : self
    {
        $this->DwgfU = $FFU0R;
        return $this;
    }
    private function mD9HbfZ7n7O(bool $MIg9Y) : array
    {
        goto PQZ3R;
        kWk0A:
        $JmlfD['Queue'] = $this->XFL_s;
        goto LLGgh;
        vxVZV:
        $R2dQn['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->cVLsV;
        goto uaFDM;
        uaFDM:
        $JmlfD['Settings']['OutputGroups'][] = $R2dQn;
        goto UgWMz;
        S_sbv:
        $this->VJKQ0 = null;
        goto m0OJG;
        TRE6F:
        $JmlfD['Role'] = $this->RP0yH;
        goto kWk0A;
        m0OJG:
        $this->I_pl9 = [];
        goto li390;
        mDMH7:
        foreach ($this->I_pl9 as $C7b04) {
            $R2dQn['Outputs'][] = $C7b04->m7Mzoy8LNGc();
            UrxY2:
        }
        goto mMLlA;
        UgWMz:
        if (!$this->DwgfU) {
            goto hQUHs;
        }
        goto ECt_g;
        aChVZ:
        rqLL2:
        goto XJe8I;
        QxYII:
        $R2dQn['Outputs'] = [];
        goto mDMH7;
        mMLlA:
        MuDhD:
        goto vxVZV;
        xNu2G:
        if (!$MIg9Y) {
            goto rqLL2;
        }
        goto H3HJk;
        H3HJk:
        $JmlfD['AccelerationSettings']['Mode'] = 'ENABLED';
        goto aChVZ;
        XJe8I:
        $this->DwgfU = null;
        goto S_sbv;
        NLEZ2:
        $R2dQn = $JmlfD['Settings']['OutputGroups'][0];
        goto nKl4w;
        PQZ3R:
        $JmlfD = (require 'template.php');
        goto TRE6F;
        nKl4w:
        unset($JmlfD['Settings']['OutputGroups']);
        goto QxYII;
        zELad:
        throw new \LogicException('You must provide a input file to use');
        goto LfROO;
        LfROO:
        GpX1A:
        goto ASBIq;
        eWCzI:
        hQUHs:
        goto xNu2G;
        ASBIq:
        $JmlfD['Settings']['Inputs'] = $this->VJKQ0->maDDRlSJhMG();
        goto NLEZ2;
        LLGgh:
        if ($this->VJKQ0) {
            goto GpX1A;
        }
        goto zELad;
        ECt_g:
        $JmlfD['Settings']['OutputGroups'][] = $this->DwgfU->mxKXAzgKgQI();
        goto eWCzI;
        li390:
        return $JmlfD;
        goto MIstK;
        MIstK:
    }
    public function mBaMGNuQcz1(bool $MIg9Y = false) : string
    {
        try {
            $k7Y7P = $this->KuKnv->createJob($this->mD9HbfZ7n7O($MIg9Y));
            return $k7Y7P->get('Jobs')['Id'];
        } catch (AwsException $sdtX4) {
            Log::error('Error creating MediaConvert job: ' . $sdtX4->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $sdtX4);
        }
    }
}
