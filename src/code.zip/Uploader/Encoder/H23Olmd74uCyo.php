<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class H23Olmd74uCyo
{
    private $K5O4x;
    private $HUs6j;
    private $pLjlv;
    private $AieHl;
    private $H4hWd;
    private $sLmvO;
    private $YLj7w;
    public function __construct(MediaConvertClient $etHQ7, $ad59c, $B0hVO)
    {
        goto fSUVn;
        WUT2W:
        $this->sLmvO = $B0hVO;
        goto Hsti4;
        fSUVn:
        $this->AieHl = $etHQ7;
        goto I4KNn;
        I4KNn:
        $this->H4hWd = $ad59c;
        goto WUT2W;
        Hsti4:
    }
    public function mtEhkd7pAKQ() : MediaConvertClient
    {
        return $this->AieHl;
    }
    public function mE1xDWPkYj2(Hbut6W3eL4gpe $LUkXU) : self
    {
        $this->K5O4x = $LUkXU;
        return $this;
    }
    public function mM2V9PXAqLb(string $flmVl) : self
    {
        $this->pLjlv = $flmVl;
        return $this;
    }
    public function mFshQbfbMkK(VLQyUVNUaHRA4 $g2tZm) : self
    {
        $this->HUs6j[] = $g2tZm;
        return $this;
    }
    public function mOb5PRM026E(DdzEZ8yPIp5zI $c2ORW) : self
    {
        $this->YLj7w = $c2ORW;
        return $this;
    }
    private function mWRaenRiFXZ(bool $qIJ13) : array
    {
        goto zFVqI;
        gijY6:
        xPf0T:
        goto hBN1P;
        W2aPE:
        $Ki0Rj['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->pLjlv;
        goto F7zTn;
        dFHz7:
        $G99Rl['Settings']['OutputGroups'][] = $this->YLj7w->mjAf2zqhMGr();
        goto HGMqy;
        lSc4s:
        unset($G99Rl['Settings']['OutputGroups']);
        goto zDUmO;
        KVc_W:
        $this->K5O4x = null;
        goto j028E;
        F7zTn:
        $G99Rl['Settings']['OutputGroups'][] = $Ki0Rj;
        goto niPdw;
        rhGi_:
        $this->YLj7w = null;
        goto KVc_W;
        XMlyG:
        foreach ($this->HUs6j as $g2tZm) {
            $Ki0Rj['Outputs'][] = $g2tZm->mCO3NBIInmc();
            SZ7IL:
        }
        goto jsSd0;
        t4afx:
        $G99Rl['Role'] = $this->H4hWd;
        goto PgmQo;
        zFVqI:
        $G99Rl = (require 'template.php');
        goto t4afx;
        j028E:
        $this->HUs6j = [];
        goto yeeTL;
        Kodfz:
        throw new \LogicException('You must provide a input file to use');
        goto gijY6;
        yeeTL:
        return $G99Rl;
        goto k55j4;
        coa0w:
        if (!$qIJ13) {
            goto NqJnT;
        }
        goto MVi2m;
        PgmQo:
        $G99Rl['Queue'] = $this->sLmvO;
        goto ixthq;
        niPdw:
        if (!$this->YLj7w) {
            goto ftZZl;
        }
        goto dFHz7;
        HGMqy:
        ftZZl:
        goto coa0w;
        ixthq:
        if ($this->K5O4x) {
            goto xPf0T;
        }
        goto Kodfz;
        hBN1P:
        $G99Rl['Settings']['Inputs'] = $this->K5O4x->m0Z1nQiACGR();
        goto rXFIi;
        jsSd0:
        ikITD:
        goto W2aPE;
        xjNjP:
        NqJnT:
        goto rhGi_;
        zDUmO:
        $Ki0Rj['Outputs'] = [];
        goto XMlyG;
        rXFIi:
        $Ki0Rj = $G99Rl['Settings']['OutputGroups'][0];
        goto lSc4s;
        MVi2m:
        $G99Rl['AccelerationSettings']['Mode'] = 'ENABLED';
        goto xjNjP;
        k55j4:
    }
    public function mQx4taafmXW(bool $qIJ13 = false) : string
    {
        try {
            $hp3yb = $this->AieHl->createJob($this->mWRaenRiFXZ($qIJ13));
            return $hp3yb->get('Jobs')['Id'];
        } catch (AwsException $NvDiU) {
            Log::error('Error creating MediaConvert job: ' . $NvDiU->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $NvDiU);
        }
    }
}
