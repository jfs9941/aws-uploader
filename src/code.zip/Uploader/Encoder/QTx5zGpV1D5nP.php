<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Service\B9bpWG3g8Q6mz;
final class QTx5zGpV1D5nP
{
    public const mtZH9 = 'v2/hls/';
    private $RHQIu;
    private $zTo0t;
    public function __construct(B9bpWG3g8Q6mz $Hes5T, Filesystem $Vi8xq)
    {
        $this->RHQIu = $Hes5T;
        $this->zTo0t = $Vi8xq;
    }
    public function mLBw2o8Cbbe($yZXjN) : string
    {
        return $this->RHQIu->mH6lVS0EYin(self::mtZH9 . $yZXjN->getAttribute('id') . '/');
    }
    public function mtzqPJqcjI5($yZXjN) : string
    {
        return $this->RHQIu->mH6lVS0EYin(self::mtZH9 . $yZXjN->getAttribute('id') . '/thumbnail/');
    }
    public function mtSWt0kAho6($yZXjN, $G4235 = true) : string
    {
        goto WcljF;
        cyc7k:
        return $this->RHQIu->mH6lVS0EYin(self::mtZH9 . $yZXjN->getAttribute('id') . '/' . $yZXjN->getAttribute('id') . '.m3u8');
        goto sqNPr;
        Clr8G:
        return self::mtZH9 . $yZXjN->getAttribute('id') . '/' . $yZXjN->getAttribute('id') . '.m3u8';
        goto w5xpS;
        w5xpS:
        Y8KMH:
        goto cyc7k;
        WcljF:
        if ($G4235) {
            goto Y8KMH;
        }
        goto Clr8G;
        sqNPr:
    }
    public function resolveThumbnail($yZXjN) : string
    {
        goto ii3rx;
        G_QfR:
        return 1 == count($W6w1N) ? self::mtZH9 . $S6xyJ . '/thumbnail/' . $S6xyJ . '.0000000.jpg' : self::mtZH9 . $S6xyJ . '/thumbnail/' . $S6xyJ . '.0000001.jpg';
        goto zDZV9;
        vhcLy:
        $W6w1N = $this->zTo0t->files($this->mtzqPJqcjI5($yZXjN));
        goto G_QfR;
        ii3rx:
        $S6xyJ = $yZXjN->getAttribute('id');
        goto vhcLy;
        zDZV9:
    }
    public function meWz9Wv80It(string $z69yI) : string
    {
        return $this->zTo0t->url($z69yI);
    }
}
