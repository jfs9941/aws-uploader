<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\BM6hyPenlDnb7;
use Jfs\Uploader\Encoder\HQYCEfe5qBMyw;
use Jfs\Uploader\Encoder\RPOmm90py987X;
use Illuminate\Support\Facades\Log;
final class XLZ6utKYThkTc
{
    private $fvpdM;
    private $WUDxi;
    private $nCStH;
    private $RG7bG;
    private $P2Pz7;
    private $QFoPw;
    private $aVfpf;
    public function __construct(MediaConvertClient $BCyb8, $WYC7F, $CemRH)
    {
        goto GhrGU;
        VNKET:
        $this->QFoPw = $CemRH;
        goto guYiC;
        GhrGU:
        $this->RG7bG = $BCyb8;
        goto MANr4;
        MANr4:
        $this->P2Pz7 = $WYC7F;
        goto VNKET;
        guYiC:
    }
    public function mEMWNVEICoZ() : MediaConvertClient
    {
        return $this->RG7bG;
    }
    public function mVqU6EsiQF6(RPOmm90py987X $rzFc3) : self
    {
        $this->fvpdM = $rzFc3;
        return $this;
    }
    public function mzUC8F4kL0s(string $tFqD7) : self
    {
        $this->nCStH = $tFqD7;
        return $this;
    }
    public function mcIDCScoGzO(HQYCEfe5qBMyw $Q3mz2) : self
    {
        $this->WUDxi[] = $Q3mz2;
        return $this;
    }
    public function mCoV79x0on2(BM6hyPenlDnb7 $dWEzY) : self
    {
        $this->aVfpf = $dWEzY;
        return $this;
    }
    private function mTydw3blwMm(bool $ml3Dw) : array
    {
        goto RjTd0;
        EAWo1:
        if ($this->fvpdM) {
            goto tFUF3;
        }
        goto HrNbq;
        eAi__:
        $k1FyM = $qHAZ1['Settings']['OutputGroups'][0];
        goto E6YFh;
        MkxLr:
        $this->WUDxi = [];
        goto hnpxY;
        HrNbq:
        throw new \LogicException('You must provide a input file to use');
        goto spZrQ;
        IyJcf:
        $this->fvpdM = null;
        goto MkxLr;
        NGiM0:
        $k1FyM['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->nCStH;
        goto MitdV;
        sUHtc:
        y_S4V:
        goto GGtMv;
        unlEC:
        $qHAZ1['Queue'] = $this->QFoPw;
        goto EAWo1;
        LeQ8s:
        $qHAZ1['Role'] = $this->P2Pz7;
        goto unlEC;
        poz4j:
        ObEst:
        goto GEfMz;
        hnpxY:
        return $qHAZ1;
        goto tFloC;
        Ucm2X:
        $qHAZ1['Settings']['Inputs'] = $this->fvpdM->mwMbinXHN5N();
        goto eAi__;
        GGtMv:
        $this->aVfpf = null;
        goto IyJcf;
        L1OAg:
        $k1FyM['Outputs'] = [];
        goto tC8Me;
        GEfMz:
        if (!$ml3Dw) {
            goto y_S4V;
        }
        goto O_OV2;
        spZrQ:
        tFUF3:
        goto Ucm2X;
        O_OV2:
        $qHAZ1['AccelerationSettings']['Mode'] = 'ENABLED';
        goto sUHtc;
        tC8Me:
        foreach ($this->WUDxi as $Q3mz2) {
            $k1FyM['Outputs'][] = $Q3mz2->m41rosK6q7Q();
            XgdcX:
        }
        goto lpuXt;
        KNdbr:
        $qHAZ1['Settings']['OutputGroups'][] = $this->aVfpf->mBJoWxExRMi();
        goto poz4j;
        E6YFh:
        unset($qHAZ1['Settings']['OutputGroups']);
        goto L1OAg;
        MitdV:
        $qHAZ1['Settings']['OutputGroups'][] = $k1FyM;
        goto HvYQq;
        RjTd0:
        $qHAZ1 = (require 'template.php');
        goto LeQ8s;
        lpuXt:
        z9IAt:
        goto NGiM0;
        HvYQq:
        if (!$this->aVfpf) {
            goto ObEst;
        }
        goto KNdbr;
        tFloC:
    }
    public function m6jy7J8ZrGK(bool $ml3Dw = false) : string
    {
        try {
            $lgyD_ = $this->RG7bG->createJob($this->mTydw3blwMm($ml3Dw));
            return $lgyD_->get('Jobs')['Id'];
        } catch (AwsException $xMxrQ) {
            Log::error('Error creating MediaConvert job: ' . $xMxrQ->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $xMxrQ);
        }
    }
}
