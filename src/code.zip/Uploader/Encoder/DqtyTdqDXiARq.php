<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class DqtyTdqDXiARq
{
    private $r1f8r;
    public function __construct(float $F000X, int $EScAp, string $pMiNc)
    {
        goto Sh2Rg;
        Sh2Rg:
        $hJfLd = (int) $F000X / $EScAp;
        goto gaUwu;
        gaUwu:
        $hJfLd = max($hJfLd, 1);
        goto nHbyK;
        nHbyK:
        $this->r1f8r = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $hJfLd]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $pMiNc]]];
        goto wW9VD;
        wW9VD:
    }
    public function m5F2lwOBL1s() : array
    {
        return $this->r1f8r;
    }
}
