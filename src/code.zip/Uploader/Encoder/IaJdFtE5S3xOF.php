<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class IaJdFtE5S3xOF
{
    private $GDOCJ;
    public function __construct(string $fTvcJ, int $L5SP9, int $xRGlC, ?int $SAWrT, ?int $rnPww)
    {
        goto lBR5z;
        FDMiw:
        EOg8e:
        goto vI8Zn;
        arcQO:
        $this->GDOCJ['ImageInserter']['InsertableImages'][0]['Width'] = $SAWrT;
        goto aqDlM;
        aqDlM:
        $this->GDOCJ['ImageInserter']['InsertableImages'][0]['Height'] = $rnPww;
        goto FDMiw;
        lBR5z:
        $this->GDOCJ = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $L5SP9, 'ImageY' => $xRGlC, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $fTvcJ, 'Opacity' => 35]]]];
        goto zHMfJ;
        zHMfJ:
        if (!($SAWrT && $rnPww)) {
            goto EOg8e;
        }
        goto arcQO;
        vI8Zn:
    }
    public function mFFPXaP5cRN() : array
    {
        return $this->GDOCJ;
    }
}
