<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class JOc7tbmnzw0x2
{
    private $OW9L0;
    public function __construct(string $P087T, int $TtVLt, int $FnDO8, ?int $BmTCT, ?int $IkBoO)
    {
        goto H1t1U;
        CIyIb:
        c704P:
        goto kvLLl;
        sOTC0:
        $this->OW9L0['ImageInserter']['InsertableImages'][0]['Height'] = $IkBoO;
        goto CIyIb;
        khdKz:
        $this->OW9L0['ImageInserter']['InsertableImages'][0]['Width'] = $BmTCT;
        goto sOTC0;
        H1t1U:
        $this->OW9L0 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $TtVLt, 'ImageY' => $FnDO8, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $P087T, 'Opacity' => 35]]]];
        goto eiML4;
        eiML4:
        if (!($BmTCT && $IkBoO)) {
            goto c704P;
        }
        goto khdKz;
        kvLLl:
    }
    public function mysXa5ST1p8() : array
    {
        return $this->OW9L0;
    }
}
