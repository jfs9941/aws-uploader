<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class Ij7aQIVlXZdDe
{
    private $QJQjl;
    public function __construct(string $A_HG7, ?int $g5xFk, ?int $zZl79, float $iuTM3)
    {
        goto YwjD8;
        WyWlX:
        $this->QJQjl['VideoDescription']['Height'] = $zZl79;
        goto Dz6Qp;
        YwjD8:
        $zttee = 15000000;
        goto hyH1W;
        FNwvV:
        $this->QJQjl = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $zttee, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $A_HG7];
        goto k75Ic;
        k75Ic:
        if (!($g5xFk && $zZl79)) {
            goto izrmb;
        }
        goto QrjKt;
        rc9ha:
        JflNd:
        goto FNwvV;
        hyH1W:
        if (!($g5xFk && $zZl79)) {
            goto JflNd;
        }
        goto mnTWG;
        Dz6Qp:
        izrmb:
        goto GR0zz;
        mnTWG:
        $zttee = $this->mN20OhZV0oY($g5xFk, $zZl79, $iuTM3);
        goto rc9ha;
        QrjKt:
        $this->QJQjl['VideoDescription']['Width'] = $g5xFk;
        goto WyWlX;
        GR0zz:
    }
    public function mxDwTPDk8te(PsVrIC99Lkpu6 $KdJhh) : self
    {
        $this->QJQjl['VideoDescription']['VideoPreprocessors'] = $KdJhh->mNqmV72Le7i();
        return $this;
    }
    public function mQXMSTmtXqw() : array
    {
        return $this->QJQjl;
    }
    private function mN20OhZV0oY(int $g5xFk, int $zZl79, float $NSXb5, string $ZGYdA = 'medium', string $ccFHB = 'h264', string $Alf_E = 'good') : ?int
    {
        goto pyc6f;
        ln04d:
        zlSuP:
        goto PDMoR;
        SyRFf:
        switch (strtolower($ZGYdA)) {
            case 'low':
                $fS5mK *= 0.7;
                goto jaSnK;
            case 'high':
                $fS5mK *= 1.3;
                goto jaSnK;
            case 'veryhigh':
                $fS5mK *= 1.6;
                goto jaSnK;
        }
        goto Of8yq;
        usmjA:
        goto U1BoB;
        goto ln04d;
        FV3r8:
        if ($QeBgn <= 3840 * 2160) {
            goto zlSuP;
        }
        goto rExQe;
        Rgqfu:
        goto U1BoB;
        goto DCv5x;
        idecL:
        if ($QeBgn <= 1920 * 1080) {
            goto lHOHl;
        }
        goto xUTjn;
        KyQvf:
        if ($QeBgn <= 1280 * 720) {
            goto z9fYi;
        }
        goto idecL;
        qzke5:
        U1BoB:
        goto ytMxF;
        xUTjn:
        if ($QeBgn <= 2560 * 1440) {
            goto nZp90;
        }
        goto FV3r8;
        ptQlN:
        switch (strtolower($Alf_E)) {
            case 'low':
                $fS5mK *= 0.8;
                goto G2cmu;
            case 'high':
                $fS5mK *= 1.2;
                goto G2cmu;
        }
        goto u55c_;
        gksZF:
        if ($QeBgn <= 640 * 480) {
            goto LoSsp;
        }
        goto KyQvf;
        Y6fA8:
        G2cmu:
        goto qT4Rg;
        WPV4w:
        goto U1BoB;
        goto YJnnB;
        zzGQ_:
        return (int) ($fS5mK * 1000 * 1000);
        goto RhcPU;
        s0hZr:
        jaSnK:
        goto oqfhT;
        qT4Rg:
        $fS5mK = max(0.5, $fS5mK);
        goto zzGQ_;
        u55c_:
        M_jV5:
        goto Y6fA8;
        YJnnB:
        LoSsp:
        goto pFn6T;
        DCv5x:
        lHOHl:
        goto ZWBBQ;
        ytMxF:
        $fS5mK = $mDTQP * ($NSXb5 / 30);
        goto SyRFf;
        sDSVg:
        goto U1BoB;
        goto yFoNX;
        rExQe:
        $mDTQP = 30;
        goto WPV4w;
        PDMoR:
        $mDTQP = 20;
        goto qzke5;
        pFn6T:
        $mDTQP = 1.5;
        goto byhiV;
        Rhkxf:
        $mDTQP = 3;
        goto Rgqfu;
        Of8yq:
        pYgRg:
        goto s0hZr;
        byhiV:
        goto U1BoB;
        goto dSSET;
        HR6uP:
        $fS5mK *= 0.65;
        goto zOc4R;
        ZWBBQ:
        $mDTQP = 7;
        goto sDSVg;
        zOc4R:
        BjOXK:
        goto ptQlN;
        yFoNX:
        nZp90:
        goto VUlK1;
        VUlK1:
        $mDTQP = 12;
        goto usmjA;
        oqfhT:
        if (!('h265' === strtolower($ccFHB) || 'hevc' === strtolower($ccFHB) || 'vp9' === strtolower($ccFHB))) {
            goto BjOXK;
        }
        goto HR6uP;
        dSSET:
        z9fYi:
        goto Rhkxf;
        pyc6f:
        $QeBgn = $g5xFk * $zZl79;
        goto gksZF;
        RhcPU:
    }
}
