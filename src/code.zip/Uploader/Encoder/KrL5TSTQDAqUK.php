<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\B0X93rEANSGOM;
use Jfs\Uploader\Encoder\PKHDooQHU3M1o;
use Jfs\Uploader\Encoder\Rfh6lYKf1Vsjf;
use Illuminate\Support\Facades\Log;
final class KrL5TSTQDAqUK
{
    private $BgplE;
    private $Qdf75;
    private $cRLDy;
    private $x6J3V;
    private $vYJvO;
    private $CYbam;
    private $rHzhB;
    public function __construct(MediaConvertClient $LcANo, $pRuF2, $U0a2G)
    {
        goto tslyx;
        N2gmY:
        $this->CYbam = $U0a2G;
        goto ZrVL7;
        ritTW:
        $this->vYJvO = $pRuF2;
        goto N2gmY;
        tslyx:
        $this->x6J3V = $LcANo;
        goto ritTW;
        ZrVL7:
    }
    public function mzgBtGzQqu9() : MediaConvertClient
    {
        return $this->x6J3V;
    }
    public function mR7DlxFfzVl(Rfh6lYKf1Vsjf $trRlR) : self
    {
        $this->BgplE = $trRlR;
        return $this;
    }
    public function mOsOwAHtATa(string $UiXON) : self
    {
        $this->cRLDy = $UiXON;
        return $this;
    }
    public function mhGucTT4xgI(PKHDooQHU3M1o $jIkNU) : self
    {
        $this->Qdf75[] = $jIkNU;
        return $this;
    }
    public function mxx8qJ8mmoD(B0X93rEANSGOM $NHlhh) : self
    {
        $this->rHzhB = $NHlhh;
        return $this;
    }
    private function msFgQrwKqvl(bool $RcdJn) : array
    {
        goto nwlym;
        Qaqfv:
        T_CaJ:
        goto Fv21v;
        ONBpL:
        if (!$RcdJn) {
            goto jt7oT;
        }
        goto GAPLx;
        SAp0x:
        GVrJP:
        goto ONBpL;
        t_Hx9:
        jt7oT:
        goto ixXws;
        QQYlQ:
        $zAX1A['Queue'] = $this->CYbam;
        goto xDbI4;
        anvDJ:
        return $zAX1A;
        goto Z3bbv;
        B0Ela:
        $zAX1A['Settings']['Inputs'] = $this->BgplE->mmJnPX2IBiJ();
        goto I1wFQ;
        GAPLx:
        $zAX1A['AccelerationSettings']['Mode'] = 'ENABLED';
        goto t_Hx9;
        jF7EB:
        $this->Qdf75 = [];
        goto anvDJ;
        xDbI4:
        if ($this->BgplE) {
            goto gx3RU;
        }
        goto IPfTb;
        I1wFQ:
        $Bh12l = $zAX1A['Settings']['OutputGroups'][0];
        goto FUVuS;
        uGvcM:
        $zAX1A['Settings']['OutputGroups'][] = $this->rHzhB->mxim8FSg7TY();
        goto SAp0x;
        avr2B:
        $Bh12l['Outputs'] = [];
        goto C1cSY;
        Fv21v:
        $Bh12l['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->cRLDy;
        goto r2crf;
        nwlym:
        $zAX1A = (require 'template.php');
        goto vBJtP;
        IPfTb:
        throw new \LogicException('You must provide a input file to use');
        goto iKarT;
        C1cSY:
        foreach ($this->Qdf75 as $jIkNU) {
            $Bh12l['Outputs'][] = $jIkNU->ms57sAxxCVy();
            rxg6b:
        }
        goto Qaqfv;
        Lxy1V:
        if (!$this->rHzhB) {
            goto GVrJP;
        }
        goto uGvcM;
        ixXws:
        $this->rHzhB = null;
        goto VBv2G;
        FUVuS:
        unset($zAX1A['Settings']['OutputGroups']);
        goto avr2B;
        vBJtP:
        $zAX1A['Role'] = $this->vYJvO;
        goto QQYlQ;
        iKarT:
        gx3RU:
        goto B0Ela;
        VBv2G:
        $this->BgplE = null;
        goto jF7EB;
        r2crf:
        $zAX1A['Settings']['OutputGroups'][] = $Bh12l;
        goto Lxy1V;
        Z3bbv:
    }
    public function mJz8iIrLVJ5(bool $RcdJn = false) : string
    {
        try {
            $FhmWg = $this->x6J3V->createJob($this->msFgQrwKqvl($RcdJn));
            return $FhmWg->get('Job')['Id'];
        } catch (AwsException $X2LoG) {
            Log::error('Error creating MediaConvert job: ' . $X2LoG->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $X2LoG);
        }
    }
}
