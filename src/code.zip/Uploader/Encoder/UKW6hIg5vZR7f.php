<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class UKW6hIg5vZR7f
{
    private $J1Oer;
    private $WdB2B;
    private $qf3Lo;
    private $Yobud;
    private $dpZJ9;
    private $j_fyM;
    private $QWfdD;
    public function __construct(MediaConvertClient $NlzZh, $N2q1H, $EeSxZ)
    {
        goto SJnT3;
        SJnT3:
        $this->Yobud = $NlzZh;
        goto LOleN;
        LOleN:
        $this->dpZJ9 = $N2q1H;
        goto gPrWF;
        gPrWF:
        $this->j_fyM = $EeSxZ;
        goto Zqp3k;
        Zqp3k:
    }
    public function mCHgW7zUd6n() : MediaConvertClient
    {
        return $this->Yobud;
    }
    public function mtsx23WNbib(YFHYa4NReTuPi $uGvoE) : self
    {
        $this->J1Oer = $uGvoE;
        return $this;
    }
    public function m6YRfvox6GB(string $wc_dU) : self
    {
        $this->qf3Lo = $wc_dU;
        return $this;
    }
    public function mkCeqbbi6sY(LAuETCYTRzty9 $Sc9WB) : self
    {
        $this->WdB2B[] = $Sc9WB;
        return $this;
    }
    public function mENMMTFgcoF(Hb3LYkcj2Y6p1 $pBU9S) : self
    {
        $this->QWfdD = $pBU9S;
        return $this;
    }
    private function m80AeggFutl(bool $Hj0F4) : array
    {
        goto bOQA3;
        sj6K9:
        J85NL:
        goto WaU7Z;
        wSNjJ:
        throw new \LogicException('You must provide a input file to use');
        goto s0eJT;
        dU5wH:
        if ($this->J1Oer) {
            goto Ek0vZ;
        }
        goto wSNjJ;
        P_T4X:
        $g_XQj['Settings']['OutputGroups'][] = $Djqrf;
        goto QECaA;
        i9SGW:
        if (!$Hj0F4) {
            goto J85NL;
        }
        goto kjFN4;
        iP_Lh:
        $this->WdB2B = [];
        goto YrBzA;
        vQQkF:
        unset($g_XQj['Settings']['OutputGroups']);
        goto LdbZV;
        kjFN4:
        $g_XQj['AccelerationSettings']['Mode'] = 'ENABLED';
        goto sj6K9;
        GFzA3:
        foreach ($this->WdB2B as $Sc9WB) {
            $Djqrf['Outputs'][] = $Sc9WB->mDBGlBrTc9k();
            nUS4l:
        }
        goto rQDbE;
        tEmWA:
        $Djqrf['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->qf3Lo;
        goto P_T4X;
        QECaA:
        if (!$this->QWfdD) {
            goto tMdLT;
        }
        goto C4i1O;
        WaU7Z:
        $this->QWfdD = null;
        goto b021V;
        rQDbE:
        CgGIe:
        goto tEmWA;
        n4fEj:
        $g_XQj['Role'] = $this->dpZJ9;
        goto OdfMZ;
        OdfMZ:
        $g_XQj['Queue'] = $this->j_fyM;
        goto dU5wH;
        C4i1O:
        $g_XQj['Settings']['OutputGroups'][] = $this->QWfdD->mTnHy6TOBdv();
        goto heAdC;
        LdbZV:
        $Djqrf['Outputs'] = [];
        goto GFzA3;
        b021V:
        $this->J1Oer = null;
        goto iP_Lh;
        B1SsI:
        $g_XQj['Settings']['Inputs'] = $this->J1Oer->mgR6E7Yhs3R();
        goto C920L;
        s0eJT:
        Ek0vZ:
        goto B1SsI;
        YrBzA:
        return $g_XQj;
        goto EkW_y;
        heAdC:
        tMdLT:
        goto i9SGW;
        C920L:
        $Djqrf = $g_XQj['Settings']['OutputGroups'][0];
        goto vQQkF;
        bOQA3:
        $g_XQj = (require 'template.php');
        goto n4fEj;
        EkW_y:
    }
    public function mAI4bqvpcL2(bool $Hj0F4 = false) : string
    {
        try {
            $G4taM = $this->Yobud->createJob($this->m80AeggFutl($Hj0F4));
            return $G4taM->get('Jobs')['Id'];
        } catch (AwsException $I8puu) {
            Log::error('Error creating MediaConvert job: ' . $I8puu->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $I8puu);
        }
    }
}
