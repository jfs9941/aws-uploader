<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\EtwwKqtO3Gypr;
final class Tp9NT29QRCL9S
{
    private $QnmTb;
    public function __construct(string $gmbqE, ?int $IxHFs, ?int $Ijyqc, float $xViyG)
    {
        goto Jinf6;
        oTo0p:
        $this->QnmTb['VideoDescription']['Height'] = $Ijyqc;
        goto PhbJJ;
        uITPW:
        $this->QnmTb = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $VKWyS, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $gmbqE];
        goto Xj34F;
        r7Kg2:
        $VKWyS = $this->mPoKuPKh7Mz($IxHFs, $Ijyqc, $xViyG);
        goto CS2iT;
        IxqYv:
        $this->QnmTb['VideoDescription']['Width'] = $IxHFs;
        goto oTo0p;
        Xj34F:
        if (!($IxHFs && $Ijyqc)) {
            goto QRxtb;
        }
        goto IxqYv;
        PhbJJ:
        QRxtb:
        goto Yis1d;
        CS2iT:
        Gkoex:
        goto uITPW;
        YnurN:
        if (!($IxHFs && $Ijyqc)) {
            goto Gkoex;
        }
        goto r7Kg2;
        Jinf6:
        $VKWyS = 15000000;
        goto YnurN;
        Yis1d:
    }
    public function mPdDoXjWLbE(EtwwKqtO3Gypr $XFfCd) : self
    {
        $this->QnmTb['VideoDescription']['VideoPreprocessors'] = $XFfCd->mNXnBm1dmHe();
        return $this;
    }
    public function mYld2l0DrNd() : array
    {
        return $this->QnmTb;
    }
    private function mPoKuPKh7Mz(int $IxHFs, int $Ijyqc, float $AWVyQ, string $NV1_Y = 'medium', string $q1S41 = 'h264', string $OpkAr = 'good') : ?int
    {
        goto p5LDy;
        R7l2_:
        $dpNaL = 12;
        goto BLHov;
        dTaer:
        if (!('h265' === strtolower($q1S41) || 'hevc' === strtolower($q1S41) || 'vp9' === strtolower($q1S41))) {
            goto fKozb;
        }
        goto CRc08;
        ewJdi:
        yc6MS:
        goto vd1Kf;
        uIz1A:
        goto vVqiy;
        goto Ee69W;
        SQ_Pt:
        return (int) ($DbTuK * 1000 * 1000);
        goto Bph8g;
        oS92P:
        goto vVqiy;
        goto kPGG7;
        kPGG7:
        TUhA0:
        goto KA7ZL;
        sz1pF:
        SraIq:
        goto DLG4D;
        DLG4D:
        $dpNaL = 1.5;
        goto uIz1A;
        ki5c1:
        goto vVqiy;
        goto d8tYo;
        A78Je:
        if ($tM3JN <= 1280 * 720) {
            goto B7D_M;
        }
        goto PCr76;
        BHO7T:
        if ($tM3JN <= 2560 * 1440) {
            goto iXlVN;
        }
        goto BWO0U;
        av42Y:
        switch (strtolower($NV1_Y)) {
            case 'low':
                $DbTuK *= 0.7;
                goto Zc1wR;
            case 'high':
                $DbTuK *= 1.3;
                goto Zc1wR;
            case 'veryhigh':
                $DbTuK *= 1.6;
                goto Zc1wR;
        }
        goto Ja2VU;
        Y7H9M:
        if ($tM3JN <= 640 * 480) {
            goto SraIq;
        }
        goto A78Je;
        v2OHP:
        $DbTuK = max(0.5, $DbTuK);
        goto SQ_Pt;
        CRc08:
        $DbTuK *= 0.65;
        goto MXSyC;
        PCr76:
        if ($tM3JN <= 1920 * 1080) {
            goto TUhA0;
        }
        goto BHO7T;
        KA7ZL:
        $dpNaL = 7;
        goto ki5c1;
        MXSyC:
        fKozb:
        goto e3ph0;
        yQg9r:
        $DbTuK = $dpNaL * ($AWVyQ / 30);
        goto av42Y;
        vIkEg:
        goto vVqiy;
        goto sz1pF;
        UH70K:
        GEQdI:
        goto YiwcH;
        BWO0U:
        if ($tM3JN <= 3840 * 2160) {
            goto yc6MS;
        }
        goto UWCLC;
        rdF9I:
        $dpNaL = 3;
        goto oS92P;
        vd1Kf:
        $dpNaL = 20;
        goto aHN_4;
        b55vB:
        Zc1wR:
        goto dTaer;
        UWCLC:
        $dpNaL = 30;
        goto vIkEg;
        e3ph0:
        switch (strtolower($OpkAr)) {
            case 'low':
                $DbTuK *= 0.8;
                goto QYGwH;
            case 'high':
                $DbTuK *= 1.2;
                goto QYGwH;
        }
        goto UH70K;
        YiwcH:
        QYGwH:
        goto v2OHP;
        d8tYo:
        iXlVN:
        goto R7l2_;
        Ja2VU:
        J8z8q:
        goto b55vB;
        aHN_4:
        vVqiy:
        goto yQg9r;
        BLHov:
        goto vVqiy;
        goto ewJdi;
        Ee69W:
        B7D_M:
        goto rdF9I;
        p5LDy:
        $tM3JN = $IxHFs * $Ijyqc;
        goto Y7H9M;
        Bph8g:
    }
}
