<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class Di7wGPfsbBXHu
{
    private $e21mN;
    public function __construct(string $m1ND5, ?int $qFAp6, ?int $bxUTl, float $DNngO)
    {
        goto EQZoy;
        v5ncK:
        $this->e21mN = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $vfsnR, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $m1ND5];
        goto jv5oj;
        JXt8S:
        tiOW_:
        goto v5ncK;
        VWDL7:
        $this->e21mN['VideoDescription']['Height'] = $bxUTl;
        goto bDj3G;
        WsYw5:
        if (!($qFAp6 && $bxUTl)) {
            goto tiOW_;
        }
        goto xE1EV;
        jv5oj:
        if (!($qFAp6 && $bxUTl)) {
            goto hiCXK;
        }
        goto DxJOB;
        DxJOB:
        $this->e21mN['VideoDescription']['Width'] = $qFAp6;
        goto VWDL7;
        xE1EV:
        $vfsnR = $this->myxUsWDTKBa($qFAp6, $bxUTl, $DNngO);
        goto JXt8S;
        EQZoy:
        $vfsnR = 15000000;
        goto WsYw5;
        bDj3G:
        hiCXK:
        goto EeC3t;
        EeC3t:
    }
    public function mcKAqu9DIaP(R8oCerQxKXZb6 $rapOh) : self
    {
        $this->e21mN['VideoDescription']['VideoPreprocessors'] = $rapOh->m2bsyqh60tG();
        return $this;
    }
    public function mV8UFrM2B2L() : array
    {
        return $this->e21mN;
    }
    private function myxUsWDTKBa(int $qFAp6, int $bxUTl, float $EkMKQ, string $mI7LY = 'medium', string $A4Y1d = 'h264', string $HaaPt = 'good') : ?int
    {
        goto U2mJi;
        fnCA0:
        if ($w5USj <= 640 * 480) {
            goto YdMFO;
        }
        goto i536Y;
        kSmlo:
        nQj01:
        goto x3PHC;
        l8XCs:
        goto gLgMP;
        goto FSoGo;
        PKt7b:
        $fUpwP *= 0.65;
        goto sg4h0;
        x3PHC:
        $fUpwP = max(0.5, $fUpwP);
        goto HhTTi;
        FSoGo:
        Ex2jb:
        goto gkJtm;
        SOdRC:
        eHbKP:
        goto rB4o8;
        pZITP:
        $PRJSh = 7;
        goto kf6DS;
        U2mJi:
        $w5USj = $qFAp6 * $bxUTl;
        goto fnCA0;
        coD03:
        $PRJSh = 30;
        goto QIdT0;
        i536Y:
        if ($w5USj <= 1280 * 720) {
            goto o0CPF;
        }
        goto Xme6p;
        zO7HX:
        A1W70:
        goto kSmlo;
        GoFYZ:
        N3uZd:
        goto DCFBQ;
        ENcbi:
        if ($w5USj <= 3840 * 2160) {
            goto Ex2jb;
        }
        goto coD03;
        kf6DS:
        goto gLgMP;
        goto GoFYZ;
        uw5zb:
        $PRJSh = 3;
        goto XNRKf;
        q_eW0:
        FDVCk:
        goto SOdRC;
        QIdT0:
        goto gLgMP;
        goto U3ELb;
        Xhkur:
        IUEBY:
        goto pZITP;
        rB4o8:
        if (!('h265' === strtolower($A4Y1d) || 'hevc' === strtolower($A4Y1d) || 'vp9' === strtolower($A4Y1d))) {
            goto dR6rD;
        }
        goto PKt7b;
        SUj4N:
        $fUpwP = $PRJSh * ($EkMKQ / 30);
        goto gxK9A;
        DCFBQ:
        $PRJSh = 12;
        goto l8XCs;
        FBDqP:
        $PRJSh = 1.5;
        goto optYI;
        optYI:
        goto gLgMP;
        goto LRvJk;
        XNRKf:
        goto gLgMP;
        goto Xhkur;
        U3ELb:
        YdMFO:
        goto FBDqP;
        Xme6p:
        if ($w5USj <= 1920 * 1080) {
            goto IUEBY;
        }
        goto jxO0P;
        jxO0P:
        if ($w5USj <= 2560 * 1440) {
            goto N3uZd;
        }
        goto ENcbi;
        HhTTi:
        return (int) ($fUpwP * 1000 * 1000);
        goto XboHO;
        gkJtm:
        $PRJSh = 20;
        goto RWM6g;
        LRvJk:
        o0CPF:
        goto uw5zb;
        sg4h0:
        dR6rD:
        goto Y_AfN;
        RWM6g:
        gLgMP:
        goto SUj4N;
        gxK9A:
        switch (strtolower($mI7LY)) {
            case 'low':
                $fUpwP *= 0.7;
                goto eHbKP;
            case 'high':
                $fUpwP *= 1.3;
                goto eHbKP;
            case 'veryhigh':
                $fUpwP *= 1.6;
                goto eHbKP;
        }
        goto q_eW0;
        Y_AfN:
        switch (strtolower($HaaPt)) {
            case 'low':
                $fUpwP *= 0.8;
                goto nQj01;
            case 'high':
                $fUpwP *= 1.2;
                goto nQj01;
        }
        goto zO7HX;
        XboHO:
    }
}
