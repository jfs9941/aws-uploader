<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class OjCsASiweOGQ8
{
    private $iVqFl;
    public function __construct(string $xKuhW, int $X220I, int $BH_2q, ?int $wtcqu, ?int $snhLP)
    {
        goto rM2Qs;
        J_1ZF:
        if (!($wtcqu && $snhLP)) {
            goto hRYhK;
        }
        goto SGG6Q;
        SGG6Q:
        $this->iVqFl['ImageInserter']['InsertableImages'][0]['Width'] = $wtcqu;
        goto mjCmS;
        rM2Qs:
        $this->iVqFl = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $X220I, 'ImageY' => $BH_2q, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $xKuhW, 'Opacity' => 35]]]];
        goto J_1ZF;
        mjCmS:
        $this->iVqFl['ImageInserter']['InsertableImages'][0]['Height'] = $snhLP;
        goto PKD93;
        PKD93:
        hRYhK:
        goto JNrTw;
        JNrTw:
    }
    public function m605t8blifK() : array
    {
        return $this->iVqFl;
    }
}
