<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Service\BDt6SdH8IQ07z;
final class R1OfWFis73GHj
{
    public const WkUVk = 'v2/hls/';
    private $uEVCb;
    private $auR_S;
    public function __construct(BDt6SdH8IQ07z $cEpkz, Filesystem $JhAxH)
    {
        $this->uEVCb = $cEpkz;
        $this->auR_S = $JhAxH;
    }
    public function m4EDDeLZFBA($vd5JT) : string
    {
        return $this->uEVCb->mNE0zVY6w96(self::WkUVk . $vd5JT->getAttribute('id') . '/');
    }
    public function mbcYqobUCzW($vd5JT) : string
    {
        return $this->uEVCb->mNE0zVY6w96(self::WkUVk . $vd5JT->getAttribute('id') . '/thumbnail/');
    }
    public function mlttawTYOCy($vd5JT, $GY_Cw = true) : string
    {
        goto WZfiU;
        mwGl6:
        return self::WkUVk . $vd5JT->getAttribute('id') . '/' . $vd5JT->getAttribute('id') . '.m3u8';
        goto NvUDZ;
        NvUDZ:
        mFDVi:
        goto CAsvH;
        WZfiU:
        if ($GY_Cw) {
            goto mFDVi;
        }
        goto mwGl6;
        CAsvH:
        return $this->uEVCb->mNE0zVY6w96(self::WkUVk . $vd5JT->getAttribute('id') . '/' . $vd5JT->getAttribute('id') . '.m3u8');
        goto C7Nrc;
        C7Nrc:
    }
    public function resolveThumbnail($vd5JT) : string
    {
        goto azKON;
        f5UMv:
        return 1 == count($tBSWh) ? self::WkUVk . $IaHim . '/thumbnail/' . $IaHim . '.0000000.jpg' : self::WkUVk . $IaHim . '/thumbnail/' . $IaHim . '.0000001.jpg';
        goto AruUL;
        h75FP:
        $tBSWh = $this->auR_S->files($this->mbcYqobUCzW($vd5JT));
        goto f5UMv;
        azKON:
        $IaHim = $vd5JT->getAttribute('id');
        goto h75FP;
        AruUL:
    }
    public function mOHoZnT71eD(string $JM0UK) : string
    {
        return $this->auR_S->url($JM0UK);
    }
}
