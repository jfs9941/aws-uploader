<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class ONqwzbh5EX8u2
{
    private $k7emd;
    public function __construct(float $G6K7F, int $bkKpX, string $QPN5j)
    {
        goto DYtyv;
        S_O_d:
        $EKeyF = max($EKeyF, 1);
        goto gZIX8;
        gZIX8:
        $this->k7emd = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $EKeyF]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $QPN5j]]];
        goto biRFi;
        DYtyv:
        $EKeyF = (int) $G6K7F / $bkKpX;
        goto S_O_d;
        biRFi:
    }
    public function mi1XNSFgzJs() : array
    {
        return $this->k7emd;
    }
}
