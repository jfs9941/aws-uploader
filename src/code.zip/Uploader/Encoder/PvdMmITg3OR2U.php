<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class PvdMmITg3OR2U
{
    private $CKPey;
    public function __construct(float $qGHjI, int $LhrXC, string $FdGQq)
    {
        goto zEFZR;
        OoHUh:
        $mFKz1 = max($mFKz1, 1);
        goto QA0Xm;
        QA0Xm:
        $this->CKPey = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $mFKz1]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $FdGQq]]];
        goto uLETy;
        zEFZR:
        $mFKz1 = (int) $qGHjI / $LhrXC;
        goto OoHUh;
        uLETy:
    }
    public function mDj9AhmTQ5a() : array
    {
        return $this->CKPey;
    }
}
