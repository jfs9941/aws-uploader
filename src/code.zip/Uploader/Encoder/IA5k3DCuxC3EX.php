<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class IA5k3DCuxC3EX
{
    private $wVPkg;
    public function __construct(float $EGiw4, int $duDb_, string $h6mbG)
    {
        goto nbHEv;
        nbHEv:
        $XbOfi = (int) $EGiw4 / $duDb_;
        goto m07G_;
        VoB8h:
        $this->wVPkg = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $XbOfi]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $h6mbG]]];
        goto tnKN8;
        m07G_:
        $XbOfi = max($XbOfi, 1);
        goto VoB8h;
        tnKN8:
    }
    public function m2bpAztczG8() : array
    {
        return $this->wVPkg;
    }
}
