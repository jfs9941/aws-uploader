<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class IpF68nxcXPUAb
{
    private $jR07i;
    public function __construct(string $eQegq, ?int $X22ix, ?int $LrYxj, float $mfZTO)
    {
        goto PyeLj;
        Uyu3v:
        $this->jR07i = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $yE906, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $eQegq];
        goto iXB_4;
        cXd1Y:
        $this->jR07i['VideoDescription']['Height'] = $LrYxj;
        goto SrK89;
        PyeLj:
        $yE906 = 15000000;
        goto a4NPr;
        iXB_4:
        if (!($X22ix && $LrYxj)) {
            goto zXNeB;
        }
        goto xwGbe;
        Pmn4K:
        K0250:
        goto Uyu3v;
        a4NPr:
        if (!($X22ix && $LrYxj)) {
            goto K0250;
        }
        goto RzKCA;
        xwGbe:
        $this->jR07i['VideoDescription']['Width'] = $X22ix;
        goto cXd1Y;
        RzKCA:
        $yE906 = $this->me2RzP7rPJ6($X22ix, $LrYxj, $mfZTO);
        goto Pmn4K;
        SrK89:
        zXNeB:
        goto LBbVA;
        LBbVA:
    }
    public function mndqAm9sbqh(HixSphBFBsnT0 $L_Ckv) : self
    {
        $this->jR07i['VideoDescription']['VideoPreprocessors'] = $L_Ckv->mj630tATlDx();
        return $this;
    }
    public function myHWTPdUVPb() : array
    {
        return $this->jR07i;
    }
    private function me2RzP7rPJ6(int $X22ix, int $LrYxj, float $TdMlx, string $gyW9R = 'medium', string $hpQDs = 'h264', string $NOi0m = 'good') : ?int
    {
        goto k0zl8;
        mKivf:
        yZu20:
        goto GcjCU;
        g2ZS0:
        JhB2W:
        goto cq5cd;
        BPVsU:
        $J9zCk = max(0.5, $J9zCk);
        goto oRW7i;
        AA0D3:
        goto vjrMK;
        goto T8dce;
        zrduc:
        $J9zCk *= 0.65;
        goto g2ZS0;
        B71QY:
        $iOSYD = 3;
        goto Kz8Or;
        Kz8Or:
        goto vjrMK;
        goto tSmNa;
        LMsKD:
        $iOSYD = 1.5;
        goto AA0D3;
        VHHur:
        FV2dc:
        goto muQNx;
        myWYB:
        switch (strtolower($gyW9R)) {
            case 'low':
                $J9zCk *= 0.7;
                goto KG6iF;
            case 'high':
                $J9zCk *= 1.3;
                goto KG6iF;
            case 'veryhigh':
                $J9zCk *= 1.6;
                goto KG6iF;
        }
        goto DVRgw;
        GcjCU:
        $iOSYD = 20;
        goto ZPA5B;
        k0zl8:
        $j3l0M = $X22ix * $LrYxj;
        goto SeyKp;
        cq5cd:
        switch (strtolower($NOi0m)) {
            case 'low':
                $J9zCk *= 0.8;
                goto M1Fyq;
            case 'high':
                $J9zCk *= 1.2;
                goto M1Fyq;
        }
        goto VHHur;
        BCBFx:
        if (!('h265' === strtolower($hpQDs) || 'hevc' === strtolower($hpQDs) || 'vp9' === strtolower($hpQDs))) {
            goto JhB2W;
        }
        goto zrduc;
        ZPA5B:
        vjrMK:
        goto VIMQu;
        B7RnT:
        if ($j3l0M <= 2560 * 1440) {
            goto nXlfs;
        }
        goto reFqw;
        tSmNa:
        Y34x7:
        goto pF8mY;
        pF8mY:
        $iOSYD = 7;
        goto jtqkl;
        GVaeu:
        goto vjrMK;
        goto mKivf;
        SeyKp:
        if ($j3l0M <= 640 * 480) {
            goto ghMrr;
        }
        goto qbuV0;
        Olkv9:
        nXlfs:
        goto YE_Aa;
        we4RM:
        $iOSYD = 30;
        goto W5R3S;
        W5R3S:
        goto vjrMK;
        goto d3DSo;
        muQNx:
        M1Fyq:
        goto BPVsU;
        LVQbv:
        if ($j3l0M <= 1920 * 1080) {
            goto Y34x7;
        }
        goto B7RnT;
        oRW7i:
        return (int) ($J9zCk * 1000 * 1000);
        goto RSNce;
        VIMQu:
        $J9zCk = $iOSYD * ($TdMlx / 30);
        goto myWYB;
        qbuV0:
        if ($j3l0M <= 1280 * 720) {
            goto moVbH;
        }
        goto LVQbv;
        jtqkl:
        goto vjrMK;
        goto Olkv9;
        DVRgw:
        dvR6W:
        goto YzONZ;
        YE_Aa:
        $iOSYD = 12;
        goto GVaeu;
        T8dce:
        moVbH:
        goto B71QY;
        d3DSo:
        ghMrr:
        goto LMsKD;
        reFqw:
        if ($j3l0M <= 3840 * 2160) {
            goto yZu20;
        }
        goto we4RM;
        YzONZ:
        KG6iF:
        goto BCBFx;
        RSNce:
    }
}
