<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

final class BJQ9kvYFDQhur
{
    private $AiqVL;
    public function __construct(string $nMhMQ)
    {
        $this->AiqVL = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $nMhMQ]];
    }
    public function m1CvMqyLPfo() : array
    {
        return $this->AiqVL;
    }
}
