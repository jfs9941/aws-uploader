<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\W2mjj6AmkKZSu;
final class Afpajs92v0EVW
{
    private $Rli0H;
    public function __construct(string $gEsy8, ?int $bvCsS, ?int $WEPGl, float $GGfpk)
    {
        goto beTYf;
        dnkLP:
        $K0wKH = $this->mY0yWywQiD8($bvCsS, $WEPGl, $GGfpk);
        goto jV5LL;
        mV6VS:
        if (!($bvCsS && $WEPGl)) {
            goto Mu07Y;
        }
        goto dnkLP;
        xQimz:
        if (!($bvCsS && $WEPGl)) {
            goto svSSv;
        }
        goto G_QUt;
        hCQlO:
        $this->Rli0H['VideoDescription']['Height'] = $WEPGl;
        goto XIfZQ;
        beTYf:
        $K0wKH = 15000000;
        goto mV6VS;
        jV5LL:
        Mu07Y:
        goto i3cyQ;
        XIfZQ:
        svSSv:
        goto KveEY;
        G_QUt:
        $this->Rli0H['VideoDescription']['Width'] = $bvCsS;
        goto hCQlO;
        i3cyQ:
        $this->Rli0H = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $K0wKH, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $gEsy8];
        goto xQimz;
        KveEY:
    }
    public function mdA0CFciA8Y(W2mjj6AmkKZSu $m_LFd) : self
    {
        $this->Rli0H['VideoDescription']['VideoPreprocessors'] = $m_LFd->m1Ml4m05MDO();
        return $this;
    }
    public function mNoK24UTk7v() : array
    {
        return $this->Rli0H;
    }
    private function mY0yWywQiD8(int $bvCsS, int $WEPGl, float $DwZlC, string $VmDxX = 'medium', string $V_3jC = 'h264', string $FZfDV = 'good') : ?int
    {
        goto fYQkg;
        lWhp2:
        Nccvu:
        goto xefK8;
        PMb1F:
        gizPt:
        goto xPFty;
        BD4f9:
        $vaYZz = 3;
        goto jUN_V;
        Fhbf9:
        if ($XrTmH <= 1280 * 720) {
            goto EuwGP;
        }
        goto pSd0W;
        qC7cx:
        if ($XrTmH <= 3840 * 2160) {
            goto lKKo1;
        }
        goto BRhFL;
        t3SN_:
        QkkFE:
        goto F75v2;
        ZZIy5:
        goto QkkFE;
        goto ZCMBy;
        t3cTZ:
        z58go:
        goto GoFow;
        ZCMBy:
        lKKo1:
        goto COIiO;
        GoFow:
        $vaYZz = 12;
        goto ZZIy5;
        jhNE6:
        w5Z1A:
        goto s5nGh;
        i7BQE:
        goto QkkFE;
        goto elAfn;
        hBRKe:
        return (int) ($W4FcT * 1000 * 1000);
        goto lNK0S;
        LKiZV:
        CFwDp:
        goto e4N94;
        xefK8:
        switch (strtolower($FZfDV)) {
            case 'low':
                $W4FcT *= 0.8;
                goto IcJn0;
            case 'high':
                $W4FcT *= 1.2;
                goto IcJn0;
        }
        goto LKiZV;
        FrQOO:
        goto QkkFE;
        goto jhNE6;
        tawBH:
        XhvmO:
        goto PMb1F;
        SuUA6:
        if ($XrTmH <= 2560 * 1440) {
            goto z58go;
        }
        goto qC7cx;
        y_czF:
        $vaYZz = 7;
        goto GKeRP;
        fYQkg:
        $XrTmH = $bvCsS * $WEPGl;
        goto tYycc;
        MAdwX:
        $W4FcT *= 0.65;
        goto lWhp2;
        m_xX_:
        switch (strtolower($VmDxX)) {
            case 'low':
                $W4FcT *= 0.7;
                goto gizPt;
            case 'high':
                $W4FcT *= 1.3;
                goto gizPt;
            case 'veryhigh':
                $W4FcT *= 1.6;
                goto gizPt;
        }
        goto tawBH;
        jUN_V:
        goto QkkFE;
        goto EDdVV;
        BRhFL:
        $vaYZz = 30;
        goto FrQOO;
        tYycc:
        if ($XrTmH <= 640 * 480) {
            goto w5Z1A;
        }
        goto Fhbf9;
        GKeRP:
        goto QkkFE;
        goto t3cTZ;
        NC5Xd:
        $W4FcT = max(0.5, $W4FcT);
        goto hBRKe;
        s5nGh:
        $vaYZz = 1.5;
        goto i7BQE;
        pSd0W:
        if ($XrTmH <= 1920 * 1080) {
            goto RWdoE;
        }
        goto SuUA6;
        EDdVV:
        RWdoE:
        goto y_czF;
        COIiO:
        $vaYZz = 20;
        goto t3SN_;
        xPFty:
        if (!('h265' === strtolower($V_3jC) || 'hevc' === strtolower($V_3jC) || 'vp9' === strtolower($V_3jC))) {
            goto Nccvu;
        }
        goto MAdwX;
        e4N94:
        IcJn0:
        goto NC5Xd;
        F75v2:
        $W4FcT = $vaYZz * ($DwZlC / 30);
        goto m_xX_;
        elAfn:
        EuwGP:
        goto BD4f9;
        lNK0S:
    }
}
