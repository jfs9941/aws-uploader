<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CQtYwlDJg3DU8
{
    private $r3OVR;
    public function __construct(float $pJ_ey, int $ArdRA, string $l9Oby)
    {
        goto Cs_eU;
        vYFbR:
        $OJWFc = max($OJWFc, 1);
        goto eyQ07;
        eyQ07:
        $this->r3OVR = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $OJWFc]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $l9Oby]]];
        goto bPXpR;
        Cs_eU:
        $OJWFc = (int) $pJ_ey / $ArdRA;
        goto vYFbR;
        bPXpR:
    }
    public function mokU7ydBs3A() : array
    {
        return $this->r3OVR;
    }
}
