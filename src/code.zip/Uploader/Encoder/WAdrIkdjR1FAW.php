<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\SVNBjJbQZ9C1j;
use Jfs\Uploader\Encoder\KtUFCQtsmKPfb;
use Jfs\Uploader\Encoder\AvkpdQ5uphWyl;
use Illuminate\Support\Facades\Log;
final class WAdrIkdjR1FAW
{
    private $uDrq4;
    private $qVfnn;
    private $asaFE;
    private $Xv0wu;
    private $vbTaJ;
    private $wh5wB;
    private $Rp1Uk;
    public function __construct(MediaConvertClient $faCzv, $GisUT, $yhMUa)
    {
        goto q6jmj;
        q6jmj:
        $this->Xv0wu = $faCzv;
        goto XnLWX;
        XnLWX:
        $this->vbTaJ = $GisUT;
        goto CqONO;
        CqONO:
        $this->wh5wB = $yhMUa;
        goto AMTte;
        AMTte:
    }
    public function msGMreawd7w() : MediaConvertClient
    {
        return $this->Xv0wu;
    }
    public function mw5YUt1R8sO(AvkpdQ5uphWyl $YLPga) : self
    {
        $this->uDrq4 = $YLPga;
        return $this;
    }
    public function m7VtwRWwmJO(string $bZ5A7) : self
    {
        $this->asaFE = $bZ5A7;
        return $this;
    }
    public function m4Xng9Ow39k(KtUFCQtsmKPfb $fZIS2) : self
    {
        $this->qVfnn[] = $fZIS2;
        return $this;
    }
    public function mLgTQyNnUyy(SVNBjJbQZ9C1j $oEyCz) : self
    {
        $this->Rp1Uk = $oEyCz;
        return $this;
    }
    private function mYdPOUdutW6(bool $x2W5b) : array
    {
        goto VKO3x;
        Fe4hE:
        throw new \LogicException('You must provide a input file to use');
        goto s99JB;
        iUz24:
        $jWFbp['Outputs'] = [];
        goto HO31P;
        MbpJj:
        if (!$this->Rp1Uk) {
            goto qhWyX;
        }
        goto OK3kQ;
        z6nTF:
        $THLA3['Settings']['Inputs'] = $this->uDrq4->mL9jqYjUfjz();
        goto RAPPo;
        cYFZ3:
        $THLA3['Settings']['OutputGroups'][] = $jWFbp;
        goto MbpJj;
        OK3kQ:
        $THLA3['Settings']['OutputGroups'][] = $this->Rp1Uk->m9e9XQuiLEH();
        goto wpMC5;
        hI8vB:
        $this->uDrq4 = null;
        goto LExwG;
        VKO3x:
        $THLA3 = (require 'template.php');
        goto pJFn5;
        wcKXD:
        eC7jv:
        goto ZfzBv;
        EwOx2:
        unset($THLA3['Settings']['OutputGroups']);
        goto iUz24;
        kwejp:
        return $THLA3;
        goto yFCrt;
        LExwG:
        $this->qVfnn = [];
        goto kwejp;
        xQdHE:
        if (!$x2W5b) {
            goto raCWH;
        }
        goto Hv6B4;
        s99JB:
        L3bwW:
        goto z6nTF;
        RAPPo:
        $jWFbp = $THLA3['Settings']['OutputGroups'][0];
        goto EwOx2;
        wpMC5:
        qhWyX:
        goto xQdHE;
        HO31P:
        foreach ($this->qVfnn as $fZIS2) {
            $jWFbp['Outputs'][] = $fZIS2->mWjRuKRYX4u();
            fhV2O:
        }
        goto wcKXD;
        gaN_x:
        if ($this->uDrq4) {
            goto L3bwW;
        }
        goto Fe4hE;
        Hv6B4:
        $THLA3['AccelerationSettings']['Mode'] = 'ENABLED';
        goto HAtCy;
        KhnPJ:
        $this->Rp1Uk = null;
        goto hI8vB;
        ZfzBv:
        $jWFbp['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->asaFE;
        goto cYFZ3;
        HAtCy:
        raCWH:
        goto KhnPJ;
        pJFn5:
        $THLA3['Role'] = $this->vbTaJ;
        goto yGAQA;
        yGAQA:
        $THLA3['Queue'] = $this->wh5wB;
        goto gaN_x;
        yFCrt:
    }
    public function mBPpf33FZWZ(bool $x2W5b = false) : string
    {
        try {
            $IcWNr = $this->Xv0wu->createJob($this->mYdPOUdutW6($x2W5b));
            return $IcWNr->get('Jobs')['Id'];
        } catch (AwsException $oKDQw) {
            Log::error('Error creating MediaConvert job: ' . $oKDQw->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $oKDQw);
        }
    }
}
