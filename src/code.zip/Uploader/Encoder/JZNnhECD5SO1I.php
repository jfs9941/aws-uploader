<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class JZNnhECD5SO1I
{
    private $Nlf1z;
    public function __construct(string $d3pn5, int $VrA9F, int $LyXL1, ?int $ASgWt, ?int $ybj1g)
    {
        goto PHnoJ;
        tvKK0:
        if (!($ASgWt && $ybj1g)) {
            goto qkm8E;
        }
        goto csgd8;
        csgd8:
        $this->Nlf1z['ImageInserter']['InsertableImages'][0]['Width'] = $ASgWt;
        goto WjfdW;
        Bu756:
        qkm8E:
        goto cH3o2;
        WjfdW:
        $this->Nlf1z['ImageInserter']['InsertableImages'][0]['Height'] = $ybj1g;
        goto Bu756;
        PHnoJ:
        $this->Nlf1z = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $VrA9F, 'ImageY' => $LyXL1, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $d3pn5, 'Opacity' => 35]]]];
        goto tvKK0;
        cH3o2:
    }
    public function mQnIFDfmU7W() : array
    {
        return $this->Nlf1z;
    }
}
