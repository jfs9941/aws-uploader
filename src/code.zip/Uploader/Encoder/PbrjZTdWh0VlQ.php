<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\CQZusEgvlBWXI;
final class PbrjZTdWh0VlQ
{
    private $sSEkQ;
    public function __construct(string $jIl7e, ?int $Eb8hw, ?int $eekOV, float $rtHoX)
    {
        goto X5_xn;
        BMXD5:
        if (!($Eb8hw && $eekOV)) {
            goto EXu25;
        }
        goto lGuy6;
        NKjrM:
        EXu25:
        goto fgSe9;
        O_kDd:
        $this->sSEkQ['VideoDescription']['Height'] = $eekOV;
        goto NKjrM;
        kFRbN:
        tU8Y5:
        goto E_yOY;
        X5_xn:
        $rAXBI = 15000000;
        goto pWB92;
        pWB92:
        if (!($Eb8hw && $eekOV)) {
            goto tU8Y5;
        }
        goto kOxWh;
        kOxWh:
        $rAXBI = $this->mq8amMI02Ll($Eb8hw, $eekOV, $rtHoX);
        goto kFRbN;
        lGuy6:
        $this->sSEkQ['VideoDescription']['Width'] = $Eb8hw;
        goto O_kDd;
        E_yOY:
        $this->sSEkQ = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $rAXBI, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $jIl7e];
        goto BMXD5;
        fgSe9:
    }
    public function mAm6iztaCSu(CQZusEgvlBWXI $pxLbo) : self
    {
        $this->sSEkQ['VideoDescription']['VideoPreprocessors'] = $pxLbo->mgZUrDHcO83();
        return $this;
    }
    public function mC0FBEyM5dy() : array
    {
        return $this->sSEkQ;
    }
    private function mq8amMI02Ll(int $Eb8hw, int $eekOV, float $f0t5j, string $dbCCQ = 'medium', string $JMZqx = 'h264', string $o1UBZ = 'good') : ?int
    {
        goto KDDvq;
        qx8kr:
        $halgi *= 0.65;
        goto i4jzV;
        CuF7F:
        goto EHvCa;
        goto eGIIL;
        CKwsF:
        EHvCa:
        goto wEfW3;
        ITrKX:
        n9n5t:
        goto zsMjK;
        W2xX6:
        if ($TqgPC <= 1920 * 1080) {
            goto JHiiS;
        }
        goto uCf89;
        rKZvZ:
        wcd_K:
        goto J3W9o;
        LDXR5:
        JHiiS:
        goto I72ac;
        WJ1cz:
        JEqO6:
        goto E0s5K;
        uCf89:
        if ($TqgPC <= 2560 * 1440) {
            goto wcd_K;
        }
        goto UDFhT;
        PYp7N:
        $halgi = max(0.5, $halgi);
        goto BvBLX;
        KDDvq:
        $TqgPC = $Eb8hw * $eekOV;
        goto XQVX1;
        IFUT1:
        $ISMxN = 1.5;
        goto Voqql;
        eGIIL:
        WO1Si:
        goto Yz_VW;
        XQVX1:
        if ($TqgPC <= 640 * 480) {
            goto SKKRG;
        }
        goto uL6QI;
        R2ASf:
        if (!('h265' === strtolower($JMZqx) || 'hevc' === strtolower($JMZqx) || 'vp9' === strtolower($JMZqx))) {
            goto SaVOh;
        }
        goto qx8kr;
        L56Ad:
        P_iEo:
        goto R2ASf;
        gr2n5:
        switch (strtolower($dbCCQ)) {
            case 'low':
                $halgi *= 0.7;
                goto P_iEo;
            case 'high':
                $halgi *= 1.3;
                goto P_iEo;
            case 'veryhigh':
                $halgi *= 1.6;
                goto P_iEo;
        }
        goto rg2wc;
        BvBLX:
        return (int) ($halgi * 1000 * 1000);
        goto f4990;
        rg2wc:
        noQau:
        goto L56Ad;
        b3DlB:
        goto EHvCa;
        goto zUY5Y;
        zJvjp:
        goto EHvCa;
        goto LDXR5;
        wEfW3:
        $halgi = $ISMxN * ($f0t5j / 30);
        goto gr2n5;
        zUY5Y:
        SKKRG:
        goto IFUT1;
        uL6QI:
        if ($TqgPC <= 1280 * 720) {
            goto n9n5t;
        }
        goto W2xX6;
        E0s5K:
        deH7d:
        goto PYp7N;
        Voqql:
        goto EHvCa;
        goto ITrKX;
        UDFhT:
        if ($TqgPC <= 3840 * 2160) {
            goto WO1Si;
        }
        goto z3h3d;
        i4jzV:
        SaVOh:
        goto qs1wa;
        J3W9o:
        $ISMxN = 12;
        goto CuF7F;
        cruSe:
        goto EHvCa;
        goto rKZvZ;
        Yz_VW:
        $ISMxN = 20;
        goto CKwsF;
        zsMjK:
        $ISMxN = 3;
        goto zJvjp;
        z3h3d:
        $ISMxN = 30;
        goto b3DlB;
        I72ac:
        $ISMxN = 7;
        goto cruSe;
        qs1wa:
        switch (strtolower($o1UBZ)) {
            case 'low':
                $halgi *= 0.8;
                goto deH7d;
            case 'high':
                $halgi *= 1.2;
                goto deH7d;
        }
        goto WJ1cz;
        f4990:
    }
}
