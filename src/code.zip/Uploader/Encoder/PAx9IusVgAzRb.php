<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class PAx9IusVgAzRb
{
    private $VPjF9;
    public function __construct(float $oR1K4, int $mJ9Dt, string $hbG6Q)
    {
        goto VrS8E;
        TkOUR:
        $this->VPjF9 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $hbP83]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $hbG6Q]]];
        goto GK1PH;
        VrS8E:
        $hbP83 = (int) $oR1K4 / $mJ9Dt;
        goto Wpblm;
        Wpblm:
        $hbP83 = max($hbP83, 1);
        goto TkOUR;
        GK1PH:
    }
    public function mR9mqb3l39c() : array
    {
        return $this->VPjF9;
    }
}
