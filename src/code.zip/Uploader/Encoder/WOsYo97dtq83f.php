<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class WOsYo97dtq83f
{
    private $LWDKv;
    public function __construct(float $XUslc, int $VFlcB, string $HTaeo)
    {
        goto bo5SI;
        bo5SI:
        $tdx2j = (int) $XUslc / $VFlcB;
        goto hGa0w;
        fzpa3:
        $this->LWDKv = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $tdx2j]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $HTaeo]]];
        goto jfYup;
        hGa0w:
        $tdx2j = max($tdx2j, 1);
        goto fzpa3;
        jfYup:
    }
    public function m5JmFiWIfT4() : array
    {
        return $this->LWDKv;
    }
}
