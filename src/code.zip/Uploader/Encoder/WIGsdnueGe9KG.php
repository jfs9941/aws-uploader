<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class WIGsdnueGe9KG
{
    private $WRq40;
    public function __construct(string $zZELI, int $KyW_f, int $YR5cJ, ?int $Nk4Te, ?int $jCfbb)
    {
        goto D1c02;
        ef5P6:
        T9BAR:
        goto OLKAQ;
        LOfaL:
        $this->WRq40['ImageInserter']['InsertableImages'][0]['Width'] = $Nk4Te;
        goto zjXGb;
        eAPB5:
        if (!($Nk4Te && $jCfbb)) {
            goto T9BAR;
        }
        goto LOfaL;
        zjXGb:
        $this->WRq40['ImageInserter']['InsertableImages'][0]['Height'] = $jCfbb;
        goto ef5P6;
        D1c02:
        $this->WRq40 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $KyW_f, 'ImageY' => $YR5cJ, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $zZELI, 'Opacity' => 35]]]];
        goto eAPB5;
        OLKAQ:
    }
    public function mLuYQwV68KK() : array
    {
        return $this->WRq40;
    }
}
