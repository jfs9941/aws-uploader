<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Wu1TTCZqWFpNm
{
    private $cOLBZ;
    public function __construct(float $atGxb, int $pNW1D, string $CxJx2)
    {
        goto tnQZV;
        ppXKA:
        $CpUJU = max($CpUJU, 1);
        goto LGRqH;
        tnQZV:
        $CpUJU = (int) $atGxb / $pNW1D;
        goto ppXKA;
        LGRqH:
        $this->cOLBZ = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $CpUJU]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $CxJx2]]];
        goto R6K5g;
        R6K5g:
    }
    public function mVacz9xkxTF() : array
    {
        return $this->cOLBZ;
    }
}
