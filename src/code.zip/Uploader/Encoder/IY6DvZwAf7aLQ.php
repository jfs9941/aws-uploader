<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class IY6DvZwAf7aLQ
{
    private $O7Azn;
    public function __construct(string $y8nq9, ?int $n9snl, ?int $M0J4r, float $RjfiO)
    {
        goto OgIhk;
        YFrh3:
        $this->O7Azn['VideoDescription']['Height'] = $M0J4r;
        goto XKp7t;
        OgIhk:
        $aKAJH = 15000000;
        goto DjrkR;
        cUedM:
        Nh5fa:
        goto CwNOt;
        ijXHL:
        $aKAJH = $this->mwVwwjSHsgF($n9snl, $M0J4r, $RjfiO);
        goto cUedM;
        wKFdB:
        if (!($n9snl && $M0J4r)) {
            goto ZvF97;
        }
        goto DPzBQ;
        DjrkR:
        if (!($n9snl && $M0J4r)) {
            goto Nh5fa;
        }
        goto ijXHL;
        DPzBQ:
        $this->O7Azn['VideoDescription']['Width'] = $n9snl;
        goto YFrh3;
        CwNOt:
        $this->O7Azn = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $aKAJH, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $y8nq9];
        goto wKFdB;
        XKp7t:
        ZvF97:
        goto PzcSG;
        PzcSG:
    }
    public function msfr5qJzRmo(UGwU8wiaV6qMB $N_UFb) : self
    {
        $this->O7Azn['VideoDescription']['VideoPreprocessors'] = $N_UFb->mQaNSpguVqI();
        return $this;
    }
    public function m7Mzoy8LNGc() : array
    {
        return $this->O7Azn;
    }
    private function mwVwwjSHsgF(int $n9snl, int $M0J4r, float $rZKTB, string $Ulb1S = 'medium', string $zzknL = 'h264', string $RtIdH = 'good') : ?int
    {
        goto eAlFg;
        tFOq3:
        $J3KQf = 3;
        goto Dm0Yz;
        eAlFg:
        $XqE8j = $n9snl * $M0J4r;
        goto nzwGF;
        Z35Et:
        S8qjy:
        goto Y5lv_;
        h1VvY:
        $J3KQf = 30;
        goto l0yPM;
        XoFZB:
        return (int) ($nF1lC * 1000 * 1000);
        goto GM8Iw;
        cWzgp:
        if ($XqE8j <= 1920 * 1080) {
            goto XGp2W;
        }
        goto YA4Ts;
        uSsWA:
        if ($XqE8j <= 3840 * 2160) {
            goto Pug2e;
        }
        goto h1VvY;
        YA4Ts:
        if ($XqE8j <= 2560 * 1440) {
            goto VxB5y;
        }
        goto uSsWA;
        vKbTI:
        goto pBd_D;
        goto WhVQu;
        FWUmD:
        switch (strtolower($RtIdH)) {
            case 'low':
                $nF1lC *= 0.8;
                goto kaygJ;
            case 'high':
                $nF1lC *= 1.2;
                goto kaygJ;
        }
        goto Z35Et;
        REhCR:
        XGp2W:
        goto yN9W9;
        gP9Y0:
        $J3KQf = 1.5;
        goto vKbTI;
        yN9W9:
        $J3KQf = 7;
        goto QGHxY;
        rfJDZ:
        switch (strtolower($Ulb1S)) {
            case 'low':
                $nF1lC *= 0.7;
                goto uiEbL;
            case 'high':
                $nF1lC *= 1.3;
                goto uiEbL;
            case 'veryhigh':
                $nF1lC *= 1.6;
                goto uiEbL;
        }
        goto LEkdu;
        l0yPM:
        goto pBd_D;
        goto x1brx;
        DEc_G:
        VxB5y:
        goto OynKw;
        o5OYz:
        if ($XqE8j <= 1280 * 720) {
            goto AV_q4;
        }
        goto cWzgp;
        Slmvd:
        $J3KQf = 20;
        goto bo1Jq;
        ogyEp:
        if (!('h265' === strtolower($zzknL) || 'hevc' === strtolower($zzknL) || 'vp9' === strtolower($zzknL))) {
            goto enQyf;
        }
        goto s7Oz7;
        s7Oz7:
        $nF1lC *= 0.65;
        goto MvvNw;
        OynKw:
        $J3KQf = 12;
        goto emudh;
        MvvNw:
        enQyf:
        goto FWUmD;
        kAMoO:
        $nF1lC = max(0.5, $nF1lC);
        goto XoFZB;
        Y5lv_:
        kaygJ:
        goto kAMoO;
        j6q3e:
        uiEbL:
        goto ogyEp;
        QGHxY:
        goto pBd_D;
        goto DEc_G;
        Dm0Yz:
        goto pBd_D;
        goto REhCR;
        AyJmL:
        Pug2e:
        goto Slmvd;
        m3c0m:
        $nF1lC = $J3KQf * ($rZKTB / 30);
        goto rfJDZ;
        LEkdu:
        Xhpr8:
        goto j6q3e;
        bo1Jq:
        pBd_D:
        goto m3c0m;
        x1brx:
        ZOr_B:
        goto gP9Y0;
        nzwGF:
        if ($XqE8j <= 640 * 480) {
            goto ZOr_B;
        }
        goto o5OYz;
        WhVQu:
        AV_q4:
        goto tFOq3;
        emudh:
        goto pBd_D;
        goto AyJmL;
        GM8Iw:
    }
}
