<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class TSR3742mYKFfW
{
    private $W6JUm;
    public function __construct(string $bYWPl, int $s0RcE, int $eAJg8, ?int $tYCg4, ?int $Xnjcp)
    {
        goto pDY_0;
        ivL8t:
        if (!($tYCg4 && $Xnjcp)) {
            goto rTa6A;
        }
        goto Ihjqb;
        u0vkZ:
        rTa6A:
        goto xVMOs;
        Ihjqb:
        $this->W6JUm['ImageInserter']['InsertableImages'][0]['Width'] = $tYCg4;
        goto yHrqW;
        pDY_0:
        $this->W6JUm = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $s0RcE, 'ImageY' => $eAJg8, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $bYWPl, 'Opacity' => 35]]]];
        goto ivL8t;
        yHrqW:
        $this->W6JUm['ImageInserter']['InsertableImages'][0]['Height'] = $Xnjcp;
        goto u0vkZ;
        xVMOs:
    }
    public function m2Z90b7p6qH() : array
    {
        return $this->W6JUm;
    }
}
