<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class H5lPadPHkaEN4
{
    private $SFmxo;
    public function __construct(string $lQxrW, ?int $yyWeX, ?int $q2cOY, float $pU3it)
    {
        goto BAcka;
        Hug74:
        if (!($yyWeX && $q2cOY)) {
            goto n2Jma;
        }
        goto MqbT1;
        BAcka:
        $l6S5b = 15000000;
        goto Fl_fz;
        NlXkp:
        $this->SFmxo = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $l6S5b, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $lQxrW];
        goto Hug74;
        Fl_fz:
        if (!($yyWeX && $q2cOY)) {
            goto YSGGy;
        }
        goto i1ja6;
        MqbT1:
        $this->SFmxo['VideoDescription']['Width'] = $yyWeX;
        goto bDqah;
        i1ja6:
        $l6S5b = $this->m27rWlzIGsF($yyWeX, $q2cOY, $pU3it);
        goto qQbVi;
        ICmWm:
        n2Jma:
        goto OFJSN;
        bDqah:
        $this->SFmxo['VideoDescription']['Height'] = $q2cOY;
        goto ICmWm;
        qQbVi:
        YSGGy:
        goto NlXkp;
        OFJSN:
    }
    public function m3JdvC1XUy1(Xx4ycHeslCT9O $QVzLS) : self
    {
        $this->SFmxo['VideoDescription']['VideoPreprocessors'] = $QVzLS->m8szk8kRcUJ();
        return $this;
    }
    public function mznTxyl86lu() : array
    {
        return $this->SFmxo;
    }
    private function m27rWlzIGsF(int $yyWeX, int $q2cOY, float $aTXnD, string $myDLY = 'medium', string $qQ3At = 'h264', string $fd6vN = 'good') : ?int
    {
        goto wqDfU;
        Mf_uJ:
        LL5Mu:
        goto TLYMH;
        mwlOZ:
        JCCzu:
        goto F80jO;
        zhvKU:
        goto a5E3P;
        goto zLGly;
        vl5qj:
        $HkCsG = 20;
        goto uwQ82;
        TLYMH:
        kA5jz:
        goto JZNWa;
        NusV2:
        $HkCsG = 12;
        goto cmAsE;
        F80jO:
        if (!('h265' === strtolower($qQ3At) || 'hevc' === strtolower($qQ3At) || 'vp9' === strtolower($qQ3At))) {
            goto HAhsd;
        }
        goto fCANn;
        qHdxJ:
        if ($tr0ex <= 1280 * 720) {
            goto YyYBO;
        }
        goto qFnoR;
        L2Acf:
        goto a5E3P;
        goto f8u5v;
        s2_f7:
        HlCcc:
        goto qQsPu;
        NKGtq:
        switch (strtolower($fd6vN)) {
            case 'low':
                $R2JkW *= 0.8;
                goto kA5jz;
            case 'high':
                $R2JkW *= 1.2;
                goto kA5jz;
        }
        goto Mf_uJ;
        nBm6V:
        e2sRY:
        goto NusV2;
        X7AWG:
        $HkCsG = 7;
        goto qYOb2;
        GgzSs:
        $R2JkW = $HkCsG * ($aTXnD / 30);
        goto fVLZw;
        Jz2e_:
        if ($tr0ex <= 640 * 480) {
            goto HlCcc;
        }
        goto qHdxJ;
        JZNWa:
        $R2JkW = max(0.5, $R2JkW);
        goto ZKUTG;
        gArpB:
        if ($tr0ex <= 2560 * 1440) {
            goto e2sRY;
        }
        goto wsI5Z;
        fCANn:
        $R2JkW *= 0.65;
        goto yuxnt;
        cmAsE:
        goto a5E3P;
        goto phgTS;
        rCDKl:
        $HkCsG = 30;
        goto LxSLs;
        phgTS:
        zOA7t:
        goto vl5qj;
        qFnoR:
        if ($tr0ex <= 1920 * 1080) {
            goto olkPB;
        }
        goto gArpB;
        qYOb2:
        goto a5E3P;
        goto nBm6V;
        fVLZw:
        switch (strtolower($myDLY)) {
            case 'low':
                $R2JkW *= 0.7;
                goto JCCzu;
            case 'high':
                $R2JkW *= 1.3;
                goto JCCzu;
            case 'veryhigh':
                $R2JkW *= 1.6;
                goto JCCzu;
        }
        goto t2PKk;
        wsI5Z:
        if ($tr0ex <= 3840 * 2160) {
            goto zOA7t;
        }
        goto rCDKl;
        qQsPu:
        $HkCsG = 1.5;
        goto zhvKU;
        uwQ82:
        a5E3P:
        goto GgzSs;
        oJvS4:
        $HkCsG = 3;
        goto L2Acf;
        zLGly:
        YyYBO:
        goto oJvS4;
        t2PKk:
        KkzUK:
        goto mwlOZ;
        f8u5v:
        olkPB:
        goto X7AWG;
        wqDfU:
        $tr0ex = $yyWeX * $q2cOY;
        goto Jz2e_;
        ZKUTG:
        return (int) ($R2JkW * 1000 * 1000);
        goto uPJhA;
        yuxnt:
        HAhsd:
        goto NKGtq;
        LxSLs:
        goto a5E3P;
        goto s2_f7;
        uPJhA:
    }
}
