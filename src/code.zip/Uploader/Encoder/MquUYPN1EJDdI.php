<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Service\JrqDsqkHsYBsl;
final class MquUYPN1EJDdI
{
    public const dZzT_ = 'v2/hls/';
    private $Uowa5;
    private $RaPnW;
    public function __construct(JrqDsqkHsYBsl $XNWw2, Filesystem $hTkyv)
    {
        $this->Uowa5 = $XNWw2;
        $this->RaPnW = $hTkyv;
    }
    public function m5KnHMFYC9O($KuX31) : string
    {
        return $this->Uowa5->mmWy415CetN(self::dZzT_ . $KuX31->getAttribute('id') . '/');
    }
    public function mqJJckNGKb7($KuX31) : string
    {
        return $this->Uowa5->mmWy415CetN(self::dZzT_ . $KuX31->getAttribute('id') . '/thumbnail/');
    }
    public function mCDHDPBrx7B($KuX31, $h2LJk = true) : string
    {
        goto OhtM7;
        OhtM7:
        if ($h2LJk) {
            goto p58Pk;
        }
        goto FvosC;
        EH0WR:
        p58Pk:
        goto mpSQk;
        mpSQk:
        return $this->Uowa5->mmWy415CetN(self::dZzT_ . $KuX31->getAttribute('id') . '/' . $KuX31->getAttribute('id') . '.m3u8');
        goto OMmR4;
        FvosC:
        return self::dZzT_ . $KuX31->getAttribute('id') . '/' . $KuX31->getAttribute('id') . '.m3u8';
        goto EH0WR;
        OMmR4:
    }
    public function resolveThumbnail($KuX31) : string
    {
        goto O0T6b;
        O0T6b:
        $UcmDx = $KuX31->getAttribute('id');
        goto rI43Y;
        rI43Y:
        $YNsmS = $this->RaPnW->files($this->mqJJckNGKb7($KuX31));
        goto Y0Y36;
        Y0Y36:
        return 1 == count($YNsmS) ? self::dZzT_ . $UcmDx . '/thumbnail/' . $UcmDx . '.0000000.jpg' : self::dZzT_ . $UcmDx . '/thumbnail/' . $UcmDx . '.0000001.jpg';
        goto G0HmF;
        G0HmF:
    }
    public function m5CjC7kY6ax(string $eviRR) : string
    {
        return $this->RaPnW->url($eviRR);
    }
}
