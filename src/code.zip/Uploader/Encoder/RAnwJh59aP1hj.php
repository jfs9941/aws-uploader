<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class RAnwJh59aP1hj
{
    private $y2DPj;
    public function __construct(string $uH36m, int $gkqwL, int $LSL6R, ?int $ABqPe, ?int $dE8ui)
    {
        goto AT15C;
        IXGov:
        $this->y2DPj['ImageInserter']['InsertableImages'][0]['Height'] = $dE8ui;
        goto qTRYX;
        fCB4E:
        $this->y2DPj['ImageInserter']['InsertableImages'][0]['Width'] = $ABqPe;
        goto IXGov;
        QS2gO:
        if (!($ABqPe && $dE8ui)) {
            goto t6cNb;
        }
        goto fCB4E;
        qTRYX:
        t6cNb:
        goto raPvJ;
        AT15C:
        $this->y2DPj = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $gkqwL, 'ImageY' => $LSL6R, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $uH36m, 'Opacity' => 35]]]];
        goto QS2gO;
        raPvJ:
    }
    public function mnObR0OH5FN() : array
    {
        return $this->y2DPj;
    }
}
