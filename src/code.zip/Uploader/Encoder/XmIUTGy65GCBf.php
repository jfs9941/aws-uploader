<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\LCD9zDkiJube7;
final class XmIUTGy65GCBf
{
    private $OkDff;
    public function __construct(string $no4cw, ?int $kc4oX, ?int $lIw1W, float $nJ6S_)
    {
        goto UfbTf;
        Ga9cn:
        IVaaW:
        goto z0kZ1;
        kTIYo:
        if (!($kc4oX && $lIw1W)) {
            goto gdWFW;
        }
        goto jn4zr;
        jn4zr:
        $this->OkDff['VideoDescription']['Width'] = $kc4oX;
        goto Vl727;
        UfbTf:
        $rMiOc = 15000000;
        goto sl5gq;
        qfNSD:
        $rMiOc = $this->mcvuY5GKnKt($kc4oX, $lIw1W, $nJ6S_);
        goto Ga9cn;
        HDLY6:
        gdWFW:
        goto zBMT1;
        Vl727:
        $this->OkDff['VideoDescription']['Height'] = $lIw1W;
        goto HDLY6;
        sl5gq:
        if (!($kc4oX && $lIw1W)) {
            goto IVaaW;
        }
        goto qfNSD;
        z0kZ1:
        $this->OkDff = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $rMiOc, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $no4cw];
        goto kTIYo;
        zBMT1:
    }
    public function mqvISxlQg3I(LCD9zDkiJube7 $i1XSF) : self
    {
        $this->OkDff['VideoDescription']['VideoPreprocessors'] = $i1XSF->maalhD9s428();
        return $this;
    }
    public function mfp7hvtKsYo() : array
    {
        return $this->OkDff;
    }
    private function mcvuY5GKnKt(int $kc4oX, int $lIw1W, float $XvCJC, string $SaEaM = 'medium', string $l8QF0 = 'h264', string $am2ex = 'good') : ?int
    {
        goto fFFOK;
        SesQz:
        aWjBa:
        goto ImWEZ;
        Q4e6U:
        if ($GctHg <= 640 * 480) {
            goto PkbIw;
        }
        goto H_E4e;
        Ps5t6:
        return (int) ($Krnmv * 1000 * 1000);
        goto Lh2_U;
        JHHUr:
        if (!('h265' === strtolower($l8QF0) || 'hevc' === strtolower($l8QF0) || 'vp9' === strtolower($l8QF0))) {
            goto GQmaV;
        }
        goto a7xW5;
        DsWpK:
        R6ugC:
        goto Idvx1;
        pyvj3:
        fdAgj:
        goto vq4sx;
        h2ZYh:
        if ($GctHg <= 1920 * 1080) {
            goto R6ugC;
        }
        goto Sknte;
        RxgOr:
        goto z8TRx;
        goto SesQz;
        UXur3:
        GQmaV:
        goto ULBG_;
        R_2DJ:
        PkbIw:
        goto YQk46;
        U9H0u:
        $NWgUv = 12;
        goto RxgOr;
        y9eAq:
        t6m_w:
        goto yrLRN;
        ULBG_:
        switch (strtolower($am2ex)) {
            case 'low':
                $Krnmv *= 0.8;
                goto fdAgj;
            case 'high':
                $Krnmv *= 1.2;
                goto fdAgj;
        }
        goto PgR_x;
        CRJol:
        goto z8TRx;
        goto h_x8a;
        aD30m:
        $NWgUv = 30;
        goto fi4Ci;
        L9eQp:
        switch (strtolower($SaEaM)) {
            case 'low':
                $Krnmv *= 0.7;
                goto Fl_lf;
            case 'high':
                $Krnmv *= 1.3;
                goto Fl_lf;
            case 'veryhigh':
                $Krnmv *= 1.6;
                goto Fl_lf;
        }
        goto PTKDo;
        PgR_x:
        AZLXw:
        goto pyvj3;
        CL64u:
        z8TRx:
        goto ZtaJE;
        diTfz:
        goto z8TRx;
        goto DsWpK;
        ImWEZ:
        $NWgUv = 20;
        goto CL64u;
        PTKDo:
        uNmiU:
        goto ygW2v;
        yrLRN:
        $NWgUv = 3;
        goto diTfz;
        ZtaJE:
        $Krnmv = $NWgUv * ($XvCJC / 30);
        goto L9eQp;
        fi4Ci:
        goto z8TRx;
        goto R_2DJ;
        H_E4e:
        if ($GctHg <= 1280 * 720) {
            goto t6m_w;
        }
        goto h2ZYh;
        PDcmm:
        if ($GctHg <= 3840 * 2160) {
            goto aWjBa;
        }
        goto aD30m;
        ygW2v:
        Fl_lf:
        goto JHHUr;
        fFFOK:
        $GctHg = $kc4oX * $lIw1W;
        goto Q4e6U;
        Sknte:
        if ($GctHg <= 2560 * 1440) {
            goto cDUaX;
        }
        goto PDcmm;
        a7xW5:
        $Krnmv *= 0.65;
        goto UXur3;
        Idvx1:
        $NWgUv = 7;
        goto CRJol;
        YQk46:
        $NWgUv = 1.5;
        goto VKeBk;
        vq4sx:
        $Krnmv = max(0.5, $Krnmv);
        goto Ps5t6;
        h_x8a:
        cDUaX:
        goto U9H0u;
        VKeBk:
        goto z8TRx;
        goto y9eAq;
        Lh2_U:
    }
}
