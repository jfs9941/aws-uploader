<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class HmpcWz3K8TIAu
{
    private $cE5ke;
    private $CILF1;
    private $n3IBm;
    private $o2aKN;
    private $Asfw2;
    private $PaSWw;
    private $LBxSS;
    public function __construct(MediaConvertClient $Apo2s, $LhBA9, $nU1QZ)
    {
        goto CI2lH;
        CI2lH:
        $this->o2aKN = $Apo2s;
        goto KiylN;
        KiylN:
        $this->Asfw2 = $LhBA9;
        goto J60gj;
        J60gj:
        $this->PaSWw = $nU1QZ;
        goto lpdkQ;
        lpdkQ:
    }
    public function msnTf36bhUn() : MediaConvertClient
    {
        return $this->o2aKN;
    }
    public function myP0aYppr7E(BKbHXXW0iqsEB $t6HQJ) : self
    {
        $this->cE5ke = $t6HQJ;
        return $this;
    }
    public function mvEDWFBHMn1(string $le7qq) : self
    {
        $this->n3IBm = $le7qq;
        return $this;
    }
    public function mhNAjPH5TVt(CJuIUkGtE4HG1 $tDQer) : self
    {
        $this->CILF1[] = $tDQer;
        return $this;
    }
    public function mq66qczz7SD(NWhFJkPi8Y0U6 $E2RLT) : self
    {
        $this->LBxSS = $E2RLT;
        return $this;
    }
    private function mDAZMLr7hQH(bool $yy2PA) : array
    {
        goto EdhIe;
        mLr8J:
        FhkL_:
        goto epra7;
        kkv6P:
        $RPEkS['Role'] = $this->Asfw2;
        goto rlNzT;
        vSh2R:
        if ($this->cE5ke) {
            goto FhkL_;
        }
        goto u3g08;
        epra7:
        $RPEkS['Settings']['Inputs'] = $this->cE5ke->mzV8zvu4QGR();
        goto ANPw1;
        eLORA:
        $RPEkS['Settings']['OutputGroups'][] = $HoAmO;
        goto ZQy00;
        nWwEg:
        unset($RPEkS['Settings']['OutputGroups']);
        goto eGsO2;
        EdhIe:
        $RPEkS = (require 'template.php');
        goto kkv6P;
        ZlQtg:
        return $RPEkS;
        goto rmp9H;
        eGsO2:
        $HoAmO['Outputs'] = [];
        goto K9uqx;
        u3g08:
        throw new \LogicException('You must provide a input file to use');
        goto mLr8J;
        PM83y:
        $HoAmO['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->n3IBm;
        goto eLORA;
        K9uqx:
        foreach ($this->CILF1 as $tDQer) {
            $HoAmO['Outputs'][] = $tDQer->mgfWyaiGTuN();
            h4ahX:
        }
        goto TUVY_;
        rlNzT:
        $RPEkS['Queue'] = $this->PaSWw;
        goto vSh2R;
        ZQy00:
        if (!$this->LBxSS) {
            goto SU0CP;
        }
        goto s3ZGD;
        L84cj:
        $this->LBxSS = null;
        goto zjKw1;
        p4_B2:
        SU0CP:
        goto ChntA;
        JfyzZ:
        $RPEkS['AccelerationSettings']['Mode'] = 'ENABLED';
        goto kOKKc;
        ANPw1:
        $HoAmO = $RPEkS['Settings']['OutputGroups'][0];
        goto nWwEg;
        TUVY_:
        uqLEO:
        goto PM83y;
        s3ZGD:
        $RPEkS['Settings']['OutputGroups'][] = $this->LBxSS->mhvVT05QwOr();
        goto p4_B2;
        Kn_vX:
        $this->CILF1 = [];
        goto ZlQtg;
        kOKKc:
        F6s92:
        goto L84cj;
        zjKw1:
        $this->cE5ke = null;
        goto Kn_vX;
        ChntA:
        if (!$yy2PA) {
            goto F6s92;
        }
        goto JfyzZ;
        rmp9H:
    }
    public function mBd9Mmen9ll(bool $yy2PA = false) : string
    {
        try {
            $Or112 = $this->o2aKN->createJob($this->mDAZMLr7hQH($yy2PA));
            return $Or112->get('Jobs')['Id'];
        } catch (AwsException $cy3Ei) {
            Log::error('Error creating MediaConvert job: ' . $cy3Ei->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $cy3Ei);
        }
    }
}
