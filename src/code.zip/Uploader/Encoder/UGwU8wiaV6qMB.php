<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class UGwU8wiaV6qMB
{
    private $hlJGH;
    public function __construct(string $SNyGD, int $ITTVM, int $KWsMm, ?int $n9snl, ?int $M0J4r)
    {
        goto HQGL5;
        LqYV9:
        $this->hlJGH['ImageInserter']['InsertableImages'][0]['Height'] = $M0J4r;
        goto pQGid;
        pQGid:
        wMcc4:
        goto Lgd0n;
        PA4uL:
        if (!($n9snl && $M0J4r)) {
            goto wMcc4;
        }
        goto OVXq_;
        HQGL5:
        $this->hlJGH = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $ITTVM, 'ImageY' => $KWsMm, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $SNyGD, 'Opacity' => 35]]]];
        goto PA4uL;
        OVXq_:
        $this->hlJGH['ImageInserter']['InsertableImages'][0]['Width'] = $n9snl;
        goto LqYV9;
        Lgd0n:
    }
    public function mQaNSpguVqI() : array
    {
        return $this->hlJGH;
    }
}
