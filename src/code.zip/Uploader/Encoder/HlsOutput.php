<?php
declare(strict_types=1);

namespace Jfs\Uploader\Encoder;

final class HlsOutput
{
    private $output;

    public function __construct(string $modifier, ?int $width, ?int $height, float $fps)
    {
        $bitrate = 15000000;
        if ($width && $height) {
            $bitrate = $this->estimateBitrate($width, $height, $fps);
        }
        $this->output = [
            'ContainerSettings' => [
                'Container' => 'M3U8',
                'M3u8Settings' => [
                ],
            ],
            'VideoDescription' => [
                'CodecSettings' => [
                    'Codec' => 'H_264',
                    'H264Settings' => [
                        'MaxBitrate' => $bitrate,
                        'RateControlMode' => 'QVBR',
                        'SceneChangeDetect' => 'TRANSITION_DETECTION',
                    ],
                ],
            ],
            'AudioDescriptions' => [
                [
                    'CodecSettings' => [
                        'Codec' => 'AAC',
                        'AacSettings' => [
                            'Bitrate' => 96000,
                            'CodingMode' => 'CODING_MODE_2_0',
                            'SampleRate' => 48000,
                        ],
                    ],
                ],
            ],
            'OutputSettings' => [
                'HlsSettings' => [
                ],
            ],
            'NameModifier' => $modifier,
        ];

        if ($width && $height) {
            $this->output['VideoDescription']['Width'] = $width;
            $this->output['VideoDescription']['Height'] = $height;
        }
    }

    public function setWatermark(Watermark $watermark): self
    {
        $this->output['VideoDescription']['VideoPreprocessors'] = $watermark->getWatermark();

        return $this;
    }

    public function getOutput(): array
    {
        return $this->output;
    }

    private function estimateBitrate(int $width, int $height, float $frameRate, string $contentComplexity = 'medium', string $codec = 'h264', string $qualityPreference = 'good'): ?int
    {
        $resolution = $width * $height;
        if ($resolution <= 640 * 480) { // SD
            $baseBitrateMbps = 1.5;
        } elseif ($resolution <= 1280 * 720) { // 720p
            $baseBitrateMbps = 3;
        } elseif ($resolution <= 1920 * 1080) { // 1080p
            $baseBitrateMbps = 7;
        } elseif ($resolution <= 2560 * 1440) { // 2K/QHD
            $baseBitrateMbps = 12;
        } elseif ($resolution <= 3840 * 2160) { // 4K/UHD
            $baseBitrateMbps = 20;
        } else {
            $baseBitrateMbps = 30;
        }

        $bitrateMbps = $baseBitrateMbps * ($frameRate / 30); // Normalize to 30fps

        switch (strtolower($contentComplexity)) {
            case 'low':
                $bitrateMbps *= 0.7;
                break;
            case 'high':
                $bitrateMbps *= 1.3;
                break;
            case 'veryhigh':
                $bitrateMbps *= 1.6;
                break;
        }

        if ('h265' === strtolower($codec) || 'hevc' === strtolower($codec) || 'vp9' === strtolower($codec)) {
            $bitrateMbps *= 0.65;
        }

        switch (strtolower($qualityPreference)) {
            case 'low':
                $bitrateMbps *= 0.8;
                break;
            case 'high':
                $bitrateMbps *= 1.2;
                break;
        }

        $bitrateMbps = max(0.5, $bitrateMbps);

        return (int) ($bitrateMbps * 1000 * 1000); // Convert to bps
    }
}
