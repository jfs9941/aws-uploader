<?php
declare(strict_types=1);

namespace Jfs\Uploader\Encoder;

class CaptureThumbnail
{
    private $thumbnail;

    public function __construct(float $duration, int $numberOfThumbnails, string $destination)
    {
        $timeForFrame = (int) $duration / $numberOfThumbnails;
        $timeForFrame = max($timeForFrame, 1);
        $this->thumbnail = [
            'CustomName' => 'thumbnail',
            'Name' => 'File Group',
            'Outputs' => [
                [
                    'ContainerSettings' => [
                        'Container' => 'RAW',
                    ],
                    'VideoDescription' => [
                        'CodecSettings' => [
                            'Codec' => 'FRAME_CAPTURE',
                            'FrameCaptureSettings' => [
                                'FramerateNumerator' => 1,
                                'FramerateDenominator' => $timeForFrame,
                            ],
                        ],
                    ],
                    'Extension' => '.jpg',
                ],
            ],
            'OutputGroupSettings' => [
                'Type' => 'FILE_GROUP_SETTINGS',
                'FileGroupSettings' => [
                    'Destination' => $destination,
                ],
            ],
        ];
    }

    public function getThumbnail(): array
    {
        return $this->thumbnail;
    }
}
