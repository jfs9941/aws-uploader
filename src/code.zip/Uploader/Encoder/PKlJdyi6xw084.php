<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class PKlJdyi6xw084
{
    private $VJKQ0;
    public function __construct(string $mAPmR)
    {
        $this->VJKQ0 = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $mAPmR]];
    }
    public function maDDRlSJhMG() : array
    {
        return $this->VJKQ0;
    }
}
