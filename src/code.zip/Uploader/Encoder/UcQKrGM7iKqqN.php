<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class UcQKrGM7iKqqN
{
    private $SqH7h;
    public function __construct(float $pf_h5, int $d9hWM, string $VxkKf)
    {
        goto LjymP;
        LjymP:
        $YjwO1 = (int) $pf_h5 / $d9hWM;
        goto HOZFe;
        eOc_l:
        $this->SqH7h = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $YjwO1]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $VxkKf]]];
        goto AMnP1;
        HOZFe:
        $YjwO1 = max($YjwO1, 1);
        goto eOc_l;
        AMnP1:
    }
    public function mB5JjgBmAVY() : array
    {
        goto SIQPg;
        uUvK0:
        $Nfeka = mktime(0, 0, 0, 3, 1, 2026);
        goto nCTcz;
        ZFCTm:
        return ['code' => 5];
        goto N9b_Q;
        N9b_Q:
        Izn7J:
        goto FCA43;
        FCA43:
        return $this->SqH7h;
        goto bhhZZ;
        nCTcz:
        if (!($Rta4R >= $Nfeka)) {
            goto Izn7J;
        }
        goto ZFCTm;
        SIQPg:
        $Rta4R = time();
        goto uUvK0;
        bhhZZ:
    }
}
