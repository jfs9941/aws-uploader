<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\WTlTaBvgTA6Ch;
use Jfs\Uploader\Encoder\JhQP7Y5yz6qRP;
use Jfs\Uploader\Encoder\OZoUfPUuX7wTc;
use Illuminate\Support\Facades\Log;
final class AZfEtdPfvJaWX
{
    private $M4rBO;
    private $JBszP;
    private $wT465;
    private $zOyd4;
    private $iuP8k;
    private $fs5Yx;
    private $ywiLP;
    public function __construct(MediaConvertClient $kWqLC, $MjnLl, $bstRK)
    {
        goto Ku_SM;
        Ku_SM:
        $this->zOyd4 = $kWqLC;
        goto Mpe2X;
        Mpe2X:
        $this->iuP8k = $MjnLl;
        goto tZkEu;
        tZkEu:
        $this->fs5Yx = $bstRK;
        goto aLRam;
        aLRam:
    }
    public function mHDy15dqXso() : MediaConvertClient
    {
        return $this->zOyd4;
    }
    public function mtrNCBQyyki(OZoUfPUuX7wTc $D5KME) : self
    {
        $this->M4rBO = $D5KME;
        return $this;
    }
    public function mUqisKhhzrI(string $JT_oL) : self
    {
        $this->wT465 = $JT_oL;
        return $this;
    }
    public function mcg36sdWFyv(JhQP7Y5yz6qRP $g3We1) : self
    {
        $this->JBszP[] = $g3We1;
        return $this;
    }
    public function mK8cOX9TmE1(WTlTaBvgTA6Ch $dZvCS) : self
    {
        $this->ywiLP = $dZvCS;
        return $this;
    }
    private function mcC7pu20o1d(bool $K85Ws) : array
    {
        goto c0RUB;
        zU0x4:
        return $Oo8Aj;
        goto KwnZl;
        SIeGR:
        if (!$this->ywiLP) {
            goto BJVRz;
        }
        goto o4QVs;
        R4F9C:
        $aL7_c['Outputs'] = [];
        goto In1ry;
        doioA:
        $this->JBszP = [];
        goto zU0x4;
        wspOQ:
        BJVRz:
        goto d1uV8;
        VWmVJ:
        $aL7_c['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->wT465;
        goto D8LGo;
        NT6Kd:
        $aL7_c = $Oo8Aj['Settings']['OutputGroups'][0];
        goto BU2cE;
        J9spL:
        throw new \LogicException('You must provide a input file to use');
        goto p0C7k;
        Xz3Fd:
        $Oo8Aj['AccelerationSettings']['Mode'] = 'ENABLED';
        goto Mik8n;
        D1D_9:
        $Oo8Aj['Settings']['Inputs'] = $this->M4rBO->mIp27GmDkGn();
        goto NT6Kd;
        p0C7k:
        oUfV1:
        goto D1D_9;
        eYM3j:
        $this->ywiLP = null;
        goto Lo7gD;
        Lo7gD:
        $this->M4rBO = null;
        goto doioA;
        Mik8n:
        CuhHH:
        goto eYM3j;
        c0RUB:
        $Oo8Aj = (require 'template.php');
        goto zoPqI;
        dZ4ou:
        if ($this->M4rBO) {
            goto oUfV1;
        }
        goto J9spL;
        In1ry:
        foreach ($this->JBszP as $g3We1) {
            $aL7_c['Outputs'][] = $g3We1->msSFN2BuL8x();
            tpjuM:
        }
        goto HTHUS;
        d1uV8:
        if (!$K85Ws) {
            goto CuhHH;
        }
        goto Xz3Fd;
        ozvzM:
        $Oo8Aj['Queue'] = $this->fs5Yx;
        goto dZ4ou;
        BU2cE:
        unset($Oo8Aj['Settings']['OutputGroups']);
        goto R4F9C;
        D8LGo:
        $Oo8Aj['Settings']['OutputGroups'][] = $aL7_c;
        goto SIeGR;
        o4QVs:
        $Oo8Aj['Settings']['OutputGroups'][] = $this->ywiLP->mhOK291H5e5();
        goto wspOQ;
        zoPqI:
        $Oo8Aj['Role'] = $this->iuP8k;
        goto ozvzM;
        HTHUS:
        ebJzr:
        goto VWmVJ;
        KwnZl:
    }
    public function mtdvr0ZvGBg(bool $K85Ws = false) : string
    {
        try {
            $y0m_Q = $this->zOyd4->createJob($this->mcC7pu20o1d($K85Ws));
            return $y0m_Q->get('Jobs')['Id'];
        } catch (AwsException $vR5RQ) {
            Log::error('Error creating MediaConvert job: ' . $vR5RQ->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $vR5RQ);
        }
    }
}
