<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Service\JCjpIXXHThkPb;
final class QuF8Qm4j71NF7
{
    public const jmGjI = 'v2/hls/';
    private $rvLVn;
    private $IRlXr;
    public function __construct(JCjpIXXHThkPb $Yfl_o, Filesystem $JGvdR)
    {
        $this->rvLVn = $Yfl_o;
        $this->IRlXr = $JGvdR;
    }
    public function myhsV216ZZ9($cZ20c) : string
    {
        return $this->rvLVn->myhpQsmTvHJ(self::jmGjI . $cZ20c->getAttribute('id') . '/');
    }
    public function m6v0qp8Znam($cZ20c) : string
    {
        return $this->rvLVn->myhpQsmTvHJ(self::jmGjI . $cZ20c->getAttribute('id') . '/thumbnail/');
    }
    public function mrJA8yiLHhh($cZ20c, $rNRtv = true) : string
    {
        goto XcAt4;
        XcAt4:
        if ($rNRtv) {
            goto LxbTJ;
        }
        goto WJBbQ;
        cl5Zx:
        return $this->rvLVn->myhpQsmTvHJ(self::jmGjI . $cZ20c->getAttribute('id') . '/' . $cZ20c->getAttribute('id') . '.m3u8');
        goto I1Zua;
        Se3aM:
        LxbTJ:
        goto cl5Zx;
        WJBbQ:
        return self::jmGjI . $cZ20c->getAttribute('id') . '/' . $cZ20c->getAttribute('id') . '.m3u8';
        goto Se3aM;
        I1Zua:
    }
    public function resolveThumbnail($cZ20c) : string
    {
        goto GSRR8;
        U6dGF:
        $qG1Gr = $this->IRlXr->files($this->m6v0qp8Znam($cZ20c));
        goto A3rNR;
        GSRR8:
        $R7IrL = $cZ20c->getAttribute('id');
        goto U6dGF;
        A3rNR:
        return 1 == count($qG1Gr) ? self::jmGjI . $R7IrL . '/thumbnail/' . $R7IrL . '.0000000.jpg' : self::jmGjI . $R7IrL . '/thumbnail/' . $R7IrL . '.0000001.jpg';
        goto ijo6Z;
        ijo6Z:
    }
    public function mAkaha9auyN(string $XkdbN) : string
    {
        return $this->IRlXr->url($XkdbN);
    }
}
