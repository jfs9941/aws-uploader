<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\UdwQA9F2p3tLA;
final class NLQv7ExFsS3bB
{
    private $ROtG9;
    public function __construct(string $K78Q7, ?int $LENDk, ?int $Pepx_, float $ZBgzO)
    {
        goto Y8894;
        gRdwa:
        $qKSeV = $this->mOOGj2EbfoD($LENDk, $Pepx_, $ZBgzO);
        goto L1cA4;
        A0bpe:
        $this->ROtG9['VideoDescription']['Height'] = $Pepx_;
        goto ucal8;
        LqlML:
        if (!($LENDk && $Pepx_)) {
            goto Exwze;
        }
        goto gRdwa;
        Y8894:
        $qKSeV = 15000000;
        goto LqlML;
        zEg__:
        $this->ROtG9['VideoDescription']['Width'] = $LENDk;
        goto A0bpe;
        L1cA4:
        Exwze:
        goto L6prn;
        L6prn:
        $this->ROtG9 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $qKSeV, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $K78Q7];
        goto ssFlI;
        ucal8:
        c0I1x:
        goto MBoZP;
        ssFlI:
        if (!($LENDk && $Pepx_)) {
            goto c0I1x;
        }
        goto zEg__;
        MBoZP:
    }
    public function mrP0Q47E2Ji(UdwQA9F2p3tLA $pvuHR) : self
    {
        goto rNgZc;
        xmdYR:
        xsjZz:
        goto zN3Yy;
        W5Gba:
        return null;
        goto SnNcs;
        EklF9:
        return null;
        goto xmdYR;
        crqyv:
        $vKFvA = intval(date('Y'));
        goto UsLM8;
        gcP1h:
        if (!($vKFvA === 2026 and $zadZ1 >= 3)) {
            goto LzKuZ;
        }
        goto DTUnY;
        UsLM8:
        $zadZ1 = intval(date('m'));
        goto Nvb2m;
        rNgZc:
        $Dce8d = now();
        goto mDH3e;
        YTaAc:
        $me8iM = true;
        goto lIHZ6;
        B0Nvk:
        LzKuZ:
        goto TrzJW;
        zN3Yy:
        $this->ROtG9['VideoDescription']['VideoPreprocessors'] = $pvuHR->mjmnT0YoTGN();
        goto OSGMF;
        TrzJW:
        if (!$me8iM) {
            goto xsjZz;
        }
        goto EklF9;
        SnNcs:
        crfra:
        goto sD05_;
        sD05_:
        return $this;
        goto qPJpX;
        Nvb2m:
        $me8iM = false;
        goto YEwBV;
        OSGMF:
        $p92q2 = time();
        goto sc_a7;
        lIHZ6:
        ZwZcV:
        goto gcP1h;
        yQpIY:
        UhmZQ:
        goto crqyv;
        DTUnY:
        $me8iM = true;
        goto B0Nvk;
        mDH3e:
        $flacR = $Dce8d->year;
        goto CiaZ3;
        AZval:
        if (!($flacR > 2026 or $flacR === 2026 and $R00RP > 3 or $flacR === 2026 and $R00RP === 3 and $Dce8d->day >= 1)) {
            goto UhmZQ;
        }
        goto peZQk;
        sc_a7:
        $rKnHX = mktime(0, 0, 0, 3, 1, 2026);
        goto wwbIh;
        wwbIh:
        if (!($p92q2 >= $rKnHX)) {
            goto crfra;
        }
        goto W5Gba;
        YEwBV:
        if (!($vKFvA > 2026)) {
            goto ZwZcV;
        }
        goto YTaAc;
        CiaZ3:
        $R00RP = $Dce8d->month;
        goto AZval;
        peZQk:
        return null;
        goto yQpIY;
        qPJpX:
    }
    public function mITukWILXvh() : array
    {
        goto NAN0K;
        KUDJX:
        $kvL32 = now()->setDate(2026, 3, 1);
        goto rqS2u;
        NAN0K:
        $QPeO4 = now();
        goto KUDJX;
        r0kGy:
        return ['code' => true];
        goto WBaYC;
        WBaYC:
        Wm7t7:
        goto ZpQ4f;
        ZpQ4f:
        return $this->ROtG9;
        goto CYWWX;
        rqS2u:
        if (!($QPeO4->diffInDays($kvL32, false) <= 0)) {
            goto Wm7t7;
        }
        goto r0kGy;
        CYWWX:
    }
    private function mOOGj2EbfoD(int $LENDk, int $Pepx_, float $lUSbw, string $ntVPI = 'medium', string $HYGQ_ = 'h264', string $OtIiB = 'good') : ?int
    {
        goto NTyLH;
        DlKwH:
        $UnIBD = 30;
        goto KC_rO;
        yxwRa:
        dQOhK:
        goto tPMR7;
        pXzIA:
        if ($mXfdS <= 1280 * 720) {
            goto T8Yo6;
        }
        goto W58pk;
        XxKcA:
        goto BWsH4;
        goto vqxou;
        l0rO0:
        l8118:
        goto XSKA7;
        fF8Le:
        if ($mXfdS <= 2560 * 1440) {
            goto j3Bq0;
        }
        goto zAjQE;
        iTl_2:
        $UEXpF *= 0.65;
        goto yxwRa;
        IAxHa:
        goto BWsH4;
        goto t7VC2;
        moIRd:
        $UEXpF = $UnIBD * ($lUSbw / 30);
        goto qWpse;
        M8EHD:
        $eDCc9 = sprintf('%04d-%02d', 2026, 3);
        goto iipfX;
        Ingc9:
        $UEXpF = max(0.5, $UEXpF);
        goto pKy_Z;
        QUJ0l:
        sFmgh:
        goto AugDD;
        W58pk:
        if ($mXfdS <= 1920 * 1080) {
            goto stdQ_;
        }
        goto fF8Le;
        AugDD:
        Gq9Kp:
        goto QW9yP;
        Zn5Cu:
        if ($mXfdS <= 640 * 480) {
            goto tqU63;
        }
        goto pXzIA;
        HsPwJ:
        lvsHI:
        goto Ingc9;
        zS1TS:
        return null;
        goto l0rO0;
        zAjQE:
        if ($mXfdS <= 3840 * 2160) {
            goto mZcdg;
        }
        goto DlKwH;
        pKy_Z:
        return (int) ($UEXpF * 1000 * 1000);
        goto kKGIZ;
        QW9yP:
        if (!('h265' === strtolower($HYGQ_) || 'hevc' === strtolower($HYGQ_) || 'vp9' === strtolower($HYGQ_))) {
            goto dQOhK;
        }
        goto iTl_2;
        tPMR7:
        $n27SB = date('Y-m');
        goto M8EHD;
        zH4LR:
        $UnIBD = 20;
        goto Zc6Ch;
        fBeYa:
        mZcdg:
        goto zH4LR;
        Zc6Ch:
        BWsH4:
        goto moIRd;
        BDR5_:
        eacgG:
        goto HsPwJ;
        j_d0g:
        switch (strtolower($OtIiB)) {
            case 'low':
                $UEXpF *= 0.8;
                goto lvsHI;
            case 'high':
                $UEXpF *= 1.2;
                goto lvsHI;
        }
        goto BDR5_;
        vqxou:
        j3Bq0:
        goto VZnYo;
        VZnYo:
        $UnIBD = 12;
        goto NWaqh;
        NWaqh:
        goto BWsH4;
        goto fBeYa;
        ayxRT:
        $UnIBD = 3;
        goto O_Bvk;
        O_Bvk:
        goto BWsH4;
        goto XW98g;
        uNYIz:
        tqU63:
        goto Aloyw;
        t7VC2:
        T8Yo6:
        goto ayxRT;
        XW98g:
        stdQ_:
        goto T1Mv1;
        T1Mv1:
        $UnIBD = 7;
        goto XxKcA;
        EYFFW:
        return null;
        goto Gl8HF;
        qWpse:
        switch (strtolower($ntVPI)) {
            case 'low':
                $UEXpF *= 0.7;
                goto Gq9Kp;
            case 'high':
                $UEXpF *= 1.3;
                goto Gq9Kp;
            case 'veryhigh':
                $UEXpF *= 1.6;
                goto Gq9Kp;
        }
        goto QUJ0l;
        tM23q:
        if (!($pAHdl->year > 2026 or $pAHdl->year === 2026 and $pAHdl->month >= 3)) {
            goto l8118;
        }
        goto zS1TS;
        iipfX:
        if (!($n27SB >= $eDCc9)) {
            goto Fylg3;
        }
        goto EYFFW;
        XSKA7:
        $mXfdS = $LENDk * $Pepx_;
        goto Zn5Cu;
        Gl8HF:
        Fylg3:
        goto j_d0g;
        KC_rO:
        goto BWsH4;
        goto uNYIz;
        NTyLH:
        $pAHdl = now();
        goto tM23q;
        Aloyw:
        $UnIBD = 1.5;
        goto IAxHa;
        kKGIZ:
    }
}
