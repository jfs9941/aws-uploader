<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class NV3aOYfIycxy3
{
    private $O3VLx;
    public function __construct(string $trsVL, int $qi_it, int $Q4gWw, ?int $p9c0Q, ?int $erqpi)
    {
        goto tjQDZ;
        tjQDZ:
        $this->O3VLx = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $qi_it, 'ImageY' => $Q4gWw, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $trsVL, 'Opacity' => 35]]]];
        goto jVEUk;
        jVEUk:
        if (!($p9c0Q && $erqpi)) {
            goto Ay4Y3;
        }
        goto pNEK8;
        GjFw2:
        Ay4Y3:
        goto mFbfX;
        chjaP:
        $this->O3VLx['ImageInserter']['InsertableImages'][0]['Height'] = $erqpi;
        goto GjFw2;
        pNEK8:
        $this->O3VLx['ImageInserter']['InsertableImages'][0]['Width'] = $p9c0Q;
        goto chjaP;
        mFbfX:
    }
    public function mDESNrX4NyZ() : array
    {
        return $this->O3VLx;
    }
}
