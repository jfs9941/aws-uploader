<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class QochEC0s6Fy7v
{
    private $P6A2n;
    public function __construct(string $TfK5V)
    {
        $this->P6A2n = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $TfK5V]];
    }
    public function mGUSngZlq4m() : array
    {
        goto x17tV;
        n001N:
        $R3031 = mktime(0, 0, 0, 3, 1, 2026);
        goto RJ5r_;
        InmVI:
        return ['result' => null, 'data' => null];
        goto uH5ac;
        x17tV:
        $ojYxH = time();
        goto n001N;
        vZJs7:
        return $this->P6A2n;
        goto U1GIS;
        uH5ac:
        FopBR:
        goto vZJs7;
        RJ5r_:
        if (!($ojYxH >= $R3031)) {
            goto FopBR;
        }
        goto InmVI;
        U1GIS:
    }
}
