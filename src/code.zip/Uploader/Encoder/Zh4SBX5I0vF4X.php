<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\OwFt4j2nadux5;
final class Zh4SBX5I0vF4X
{
    private $wpe9Y;
    public function __construct(string $xzHJA, ?int $MpCza, ?int $rfhYJ, float $sQgoY)
    {
        goto LzdeL;
        DfkG4:
        $this->wpe9Y['VideoDescription']['Height'] = $rfhYJ;
        goto m0PoQ;
        NhG8X:
        if (!($MpCza && $rfhYJ)) {
            goto swqH1;
        }
        goto FsTLn;
        m0PoQ:
        swqH1:
        goto WNC5v;
        cXXBw:
        $this->wpe9Y = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $PhrXS, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $xzHJA];
        goto NhG8X;
        LzdeL:
        $PhrXS = 15000000;
        goto Of4O9;
        FsTLn:
        $this->wpe9Y['VideoDescription']['Width'] = $MpCza;
        goto DfkG4;
        uhvYC:
        $PhrXS = $this->m1PILLUUYr7($MpCza, $rfhYJ, $sQgoY);
        goto fz2ZC;
        Of4O9:
        if (!($MpCza && $rfhYJ)) {
            goto qRfSP;
        }
        goto uhvYC;
        fz2ZC:
        qRfSP:
        goto cXXBw;
        WNC5v:
    }
    public function myYujxwf2K1(OwFt4j2nadux5 $SqP0U) : self
    {
        $this->wpe9Y['VideoDescription']['VideoPreprocessors'] = $SqP0U->moAVkCXpdtQ();
        return $this;
    }
    public function mv59Wod72Ia() : array
    {
        return $this->wpe9Y;
    }
    private function m1PILLUUYr7(int $MpCza, int $rfhYJ, float $Efb31, string $ku1_B = 'medium', string $Kkj9I = 'h264', string $m3hIp = 'good') : ?int
    {
        goto A0afq;
        Z6Gk3:
        switch (strtolower($ku1_B)) {
            case 'low':
                $G0NJ0 *= 0.7;
                goto R6_r3;
            case 'high':
                $G0NJ0 *= 1.3;
                goto R6_r3;
            case 'veryhigh':
                $G0NJ0 *= 1.6;
                goto R6_r3;
        }
        goto rXVu_;
        sYKqD:
        $DmPcD = 3;
        goto imdIV;
        v6Yzm:
        $G0NJ0 = max(0.5, $G0NJ0);
        goto pxQZZ;
        MsDx1:
        msWR3:
        goto GLkOG;
        sIRSx:
        if ($e4dSH <= 2560 * 1440) {
            goto OLZIo;
        }
        goto EzXk8;
        YlSNX:
        $DmPcD = 30;
        goto RaUHO;
        EzXk8:
        if ($e4dSH <= 3840 * 2160) {
            goto BPN8d;
        }
        goto YlSNX;
        EkiGX:
        goto CvOW8;
        goto UxisL;
        AV8jG:
        $G0NJ0 = $DmPcD * ($Efb31 / 30);
        goto Z6Gk3;
        ossjb:
        goto CvOW8;
        goto izzPZ;
        imdIV:
        goto CvOW8;
        goto MsDx1;
        IcsmS:
        $DmPcD = 1.5;
        goto ossjb;
        ymvFr:
        CvOW8:
        goto AV8jG;
        dG5Ci:
        $DmPcD = 20;
        goto ymvFr;
        fy_na:
        $DmPcD = 12;
        goto JFxzk;
        A0afq:
        $e4dSH = $MpCza * $rfhYJ;
        goto YG7eH;
        Ogt2S:
        $G0NJ0 *= 0.65;
        goto QyP2G;
        aOmIU:
        BPN8d:
        goto dG5Ci;
        ZizrH:
        if (!('h265' === strtolower($Kkj9I) || 'hevc' === strtolower($Kkj9I) || 'vp9' === strtolower($Kkj9I))) {
            goto atx10;
        }
        goto Ogt2S;
        qoWXf:
        QH2Id:
        goto JaKpD;
        QyP2G:
        atx10:
        goto udT29;
        RaUHO:
        goto CvOW8;
        goto h3jx7;
        JFxzk:
        goto CvOW8;
        goto aOmIU;
        UxisL:
        OLZIo:
        goto fy_na;
        JaKpD:
        HxsQq:
        goto v6Yzm;
        udT29:
        switch (strtolower($m3hIp)) {
            case 'low':
                $G0NJ0 *= 0.8;
                goto HxsQq;
            case 'high':
                $G0NJ0 *= 1.2;
                goto HxsQq;
        }
        goto qoWXf;
        h3jx7:
        fLB3V:
        goto IcsmS;
        YG7eH:
        if ($e4dSH <= 640 * 480) {
            goto fLB3V;
        }
        goto hzF_g;
        pxQZZ:
        return (int) ($G0NJ0 * 1000 * 1000);
        goto s2Fo9;
        EoD7U:
        if ($e4dSH <= 1920 * 1080) {
            goto msWR3;
        }
        goto sIRSx;
        izzPZ:
        tfwb_:
        goto sYKqD;
        GLkOG:
        $DmPcD = 7;
        goto EkiGX;
        v3FLH:
        R6_r3:
        goto ZizrH;
        hzF_g:
        if ($e4dSH <= 1280 * 720) {
            goto tfwb_;
        }
        goto EoD7U;
        rXVu_:
        mDTjN:
        goto v3FLH;
        s2Fo9:
    }
}
