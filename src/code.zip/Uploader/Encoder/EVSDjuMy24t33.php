<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Service\Lqd1WdK14h5gQ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class EVSDjuMy24t33
{
    public const m1pa4 = 'v2/hls/';
    private $QwXOx;
    private $bLZP5;
    public function __construct(Lqd1WdK14h5gQ $IEOZW, Filesystem $C1By6)
    {
        $this->QwXOx = $IEOZW;
        $this->bLZP5 = $C1By6;
    }
    public function mCgDTwgqDv8($lamFK) : string
    {
        return $this->QwXOx->mSCDeeKb5du(self::m1pa4 . $lamFK->getAttribute('id') . '/');
    }
    public function m84b2cDwFVh($lamFK) : string
    {
        return $this->QwXOx->mSCDeeKb5du(self::m1pa4 . $lamFK->getAttribute('id') . '/thumbnail/');
    }
    public function m3HFIefNBxW($lamFK, $ljrRW = true) : string
    {
        goto mP3qF;
        mP3qF:
        if ($ljrRW) {
            goto KooLM;
        }
        goto a900T;
        Cc4AU:
        return $this->QwXOx->mSCDeeKb5du(self::m1pa4 . $lamFK->getAttribute('id') . '/' . $lamFK->getAttribute('id') . '.m3u8');
        goto ub_2m;
        NyaK2:
        KooLM:
        goto Cc4AU;
        a900T:
        return self::m1pa4 . $lamFK->getAttribute('id') . '/' . $lamFK->getAttribute('id') . '.m3u8';
        goto NyaK2;
        ub_2m:
    }
    public function resolveThumbnail($lamFK) : string
    {
        goto uE8Fx;
        UuGi1:
        return 1 == count($cYYQf) ? self::m1pa4 . $DWjir . '/thumbnail/' . $DWjir . '.0000000.jpg' : self::m1pa4 . $DWjir . '/thumbnail/' . $DWjir . '.0000001.jpg';
        goto zw58O;
        uE8Fx:
        $DWjir = $lamFK->getAttribute('id');
        goto j9VeJ;
        j9VeJ:
        $cYYQf = $this->bLZP5->files($this->m84b2cDwFVh($lamFK));
        goto UuGi1;
        zw58O:
    }
    public function mOw8xNJhu4y(string $iVcpi) : string
    {
        return $this->bLZP5->url($iVcpi);
    }
}
