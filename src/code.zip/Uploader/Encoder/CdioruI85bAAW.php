<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class CdioruI85bAAW
{
    private $MxDXb;
    private $knZcZ;
    private $tq4G4;
    private $JjgL7;
    private $iQCsB;
    private $GqTZv;
    private $q4Ui5;
    public function __construct(MediaConvertClient $bh8fD, $VzKjZ, $LW4Ni)
    {
        goto FCBEy;
        FCBEy:
        $this->JjgL7 = $bh8fD;
        goto hXpts;
        hXpts:
        $this->iQCsB = $VzKjZ;
        goto a32cH;
        a32cH:
        $this->GqTZv = $LW4Ni;
        goto Yghz6;
        Yghz6:
    }
    public function mcgLhouSMT1() : MediaConvertClient
    {
        return $this->JjgL7;
    }
    public function m16g8cj8fQa(TOxo8bdUFruh2 $FglpP) : self
    {
        $this->MxDXb = $FglpP;
        return $this;
    }
    public function mKUmuNn3Qqr(string $fl6fW) : self
    {
        $this->tq4G4 = $fl6fW;
        return $this;
    }
    public function mi3AeKscgdF(H5lPadPHkaEN4 $Ybq13) : self
    {
        $this->knZcZ[] = $Ybq13;
        return $this;
    }
    public function mNWdGy0JfEa(GaML3gHcwK0zE $i1LOg) : self
    {
        $this->q4Ui5 = $i1LOg;
        return $this;
    }
    private function mSOLFKP9Rht(bool $zjIkt) : array
    {
        goto fu1I6;
        eXCWI:
        yVG1x:
        goto aqvOk;
        Axy7T:
        $this->q4Ui5 = null;
        goto NcGJA;
        Z31NO:
        $pcHgG['Outputs'] = [];
        goto S5N_P;
        VU8rr:
        unset($baseI['Settings']['OutputGroups']);
        goto Z31NO;
        aqvOk:
        $pcHgG['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->tq4G4;
        goto idSp9;
        HUIzJ:
        $baseI['Settings']['OutputGroups'][] = $this->q4Ui5->mOIw5UiGIZm();
        goto w7IQm;
        zZMu2:
        Nvjyw:
        goto C32FG;
        QNI1u:
        if (!$this->q4Ui5) {
            goto jjUI6;
        }
        goto HUIzJ;
        idSp9:
        $baseI['Settings']['OutputGroups'][] = $pcHgG;
        goto QNI1u;
        k5E8i:
        $pcHgG = $baseI['Settings']['OutputGroups'][0];
        goto VU8rr;
        S5N_P:
        foreach ($this->knZcZ as $Ybq13) {
            $pcHgG['Outputs'][] = $Ybq13->mznTxyl86lu();
            CPXjj:
        }
        goto eXCWI;
        w7IQm:
        jjUI6:
        goto i20_E;
        fu1I6:
        $baseI = (require 'template.php');
        goto vKYLG;
        EsUKC:
        return $baseI;
        goto b0tPZ;
        NcGJA:
        $this->MxDXb = null;
        goto hpSIb;
        vKYLG:
        $baseI['Role'] = $this->iQCsB;
        goto zfuj0;
        i20_E:
        if (!$zjIkt) {
            goto SogNu;
        }
        goto sIS2M;
        C32FG:
        $baseI['Settings']['Inputs'] = $this->MxDXb->mWb0lpvKTZc();
        goto k5E8i;
        zfuj0:
        $baseI['Queue'] = $this->GqTZv;
        goto IxjqJ;
        ux57P:
        throw new \LogicException('You must provide a input file to use');
        goto zZMu2;
        sIS2M:
        $baseI['AccelerationSettings']['Mode'] = 'ENABLED';
        goto BZ66T;
        hpSIb:
        $this->knZcZ = [];
        goto EsUKC;
        BZ66T:
        SogNu:
        goto Axy7T;
        IxjqJ:
        if ($this->MxDXb) {
            goto Nvjyw;
        }
        goto ux57P;
        b0tPZ:
    }
    public function myfNrgFiVrt(bool $zjIkt = false) : string
    {
        try {
            $hrLIq = $this->JjgL7->createJob($this->mSOLFKP9Rht($zjIkt));
            return $hrLIq->get('Jobs')['Id'];
        } catch (AwsException $nhDP5) {
            Log::error('Error creating MediaConvert job: ' . $nhDP5->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $nhDP5);
        }
    }
}
