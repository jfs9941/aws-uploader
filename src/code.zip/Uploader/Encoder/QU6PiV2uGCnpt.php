<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Encoder;

class QU6PiV2uGCnpt
{
    private $VjYPs;
    public function __construct(float $Itp2n, int $haP9_, string $eHFbT)
    {
        goto cSakH;
        cSakH:
        $ZzEHP = (int) $Itp2n / $haP9_;
        goto twoiG;
        twoiG:
        $ZzEHP = max($ZzEHP, 1);
        goto RF5_o;
        RF5_o:
        $this->VjYPs = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ZzEHP]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $eHFbT]]];
        goto TUGRH;
        TUGRH:
    }
    public function m0kz1rWtUSI() : array
    {
        return $this->VjYPs;
    }
}
