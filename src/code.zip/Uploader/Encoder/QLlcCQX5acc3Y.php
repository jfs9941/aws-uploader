<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class QLlcCQX5acc3Y
{
    private $Npbb_;
    private $GRYFi;
    private $iswQB;
    private $nx448;
    private $NwC2O;
    private $OukDE;
    private $xC5r_;
    public function __construct(MediaConvertClient $WWF21, $oWSjp, $Ry4HK)
    {
        goto g3GNz;
        pFIJZ:
        $this->NwC2O = $oWSjp;
        goto CNMtN;
        g3GNz:
        $this->nx448 = $WWF21;
        goto pFIJZ;
        CNMtN:
        $this->OukDE = $Ry4HK;
        goto jibPM;
        jibPM:
    }
    public function mdUH4r88O44() : MediaConvertClient
    {
        return $this->nx448;
    }
    public function mxfEK9czotL(L9C5rmIuqLjkd $jjhMj) : self
    {
        $this->Npbb_ = $jjhMj;
        return $this;
    }
    public function mydfbNTfHog(string $v0H_s) : self
    {
        $this->iswQB = $v0H_s;
        return $this;
    }
    public function m1bThoELSk0(Nue4ljWXYxKkO $ejRUL) : self
    {
        $this->GRYFi[] = $ejRUL;
        return $this;
    }
    public function mmqTH1N5SVb(MpCHeVeVe42Fl $XGdv1) : self
    {
        $this->xC5r_ = $XGdv1;
        return $this;
    }
    private function mhygEQLpJdF(bool $x6Yj3) : array
    {
        goto cWonG;
        XNq9c:
        $rpFWb['Outputs'] = [];
        goto LGPqc;
        EkwKe:
        NRrjJ:
        goto zZOp8;
        ZLGqm:
        if (!$x6Yj3) {
            goto i0Py9;
        }
        goto J9cpC;
        UZqP0:
        i0Py9:
        goto kBs39;
        I0riC:
        return $XZKUo;
        goto D_fOV;
        aP2Eo:
        kqcVu:
        goto ZLGqm;
        cGR9G:
        grL8x:
        goto JzwS1;
        LGPqc:
        foreach ($this->GRYFi as $ejRUL) {
            $rpFWb['Outputs'][] = $ejRUL->mSCczDWIxQW();
            Ezqv3:
        }
        goto EkwKe;
        zZOp8:
        $rpFWb['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->iswQB;
        goto JLrnT;
        qi65X:
        $rpFWb = $XZKUo['Settings']['OutputGroups'][0];
        goto RZNE7;
        cWonG:
        $XZKUo = (require 'template.php');
        goto VRA_C;
        a_1IC:
        $XZKUo['Settings']['OutputGroups'][] = $this->xC5r_->my7hpR240Lv();
        goto aP2Eo;
        hL5Td:
        throw new \LogicException('You must provide a input file to use');
        goto cGR9G;
        J9cpC:
        $XZKUo['AccelerationSettings']['Mode'] = 'ENABLED';
        goto UZqP0;
        JzwS1:
        $XZKUo['Settings']['Inputs'] = $this->Npbb_->mTdi4vq5XEC();
        goto qi65X;
        xXv3x:
        if (!$this->xC5r_) {
            goto kqcVu;
        }
        goto a_1IC;
        ehRkP:
        if ($this->Npbb_) {
            goto grL8x;
        }
        goto hL5Td;
        SZG90:
        $XZKUo['Queue'] = $this->OukDE;
        goto ehRkP;
        sNm8q:
        $this->Npbb_ = null;
        goto qoe0u;
        VRA_C:
        $XZKUo['Role'] = $this->NwC2O;
        goto SZG90;
        kBs39:
        $this->xC5r_ = null;
        goto sNm8q;
        RZNE7:
        unset($XZKUo['Settings']['OutputGroups']);
        goto XNq9c;
        JLrnT:
        $XZKUo['Settings']['OutputGroups'][] = $rpFWb;
        goto xXv3x;
        qoe0u:
        $this->GRYFi = [];
        goto I0riC;
        D_fOV:
    }
    public function mwnIFXzW7FE(bool $x6Yj3 = false) : string
    {
        try {
            $fC1nN = $this->nx448->createJob($this->mhygEQLpJdF($x6Yj3));
            return $fC1nN->get('Jobs')['Id'];
        } catch (AwsException $tPAjT) {
            Log::error('Error creating MediaConvert job: ' . $tPAjT->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $tPAjT);
        }
    }
}
