<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\ZgVfK3mFV3vr8;
use Jfs\Uploader\Encoder\Afpajs92v0EVW;
use Jfs\Uploader\Encoder\ViOgwaI8qnaEG;
use Illuminate\Support\Facades\Log;
final class Hm4pS3oE1MMiy
{
    private $j6boU;
    private $PyPKn;
    private $yXR7S;
    private $Bm0y3;
    private $iZFOi;
    private $O3EIX;
    private $oMOXS;
    public function __construct(MediaConvertClient $vM3M5, $IvRSj, $y6sAV)
    {
        goto dwxgA;
        uyOEC:
        $this->iZFOi = $IvRSj;
        goto U5DiT;
        dwxgA:
        $this->Bm0y3 = $vM3M5;
        goto uyOEC;
        U5DiT:
        $this->O3EIX = $y6sAV;
        goto nbRtU;
        nbRtU:
    }
    public function mamaLw0Iijt() : MediaConvertClient
    {
        return $this->Bm0y3;
    }
    public function mda1P5w8Yts(ViOgwaI8qnaEG $B5Cmy) : self
    {
        $this->j6boU = $B5Cmy;
        return $this;
    }
    public function mhIO9vy381Z(string $sWyxW) : self
    {
        $this->yXR7S = $sWyxW;
        return $this;
    }
    public function mDDHzdphWex(Afpajs92v0EVW $WAe4c) : self
    {
        $this->PyPKn[] = $WAe4c;
        return $this;
    }
    public function mwy5dUcYImb(ZgVfK3mFV3vr8 $EpLlV) : self
    {
        $this->oMOXS = $EpLlV;
        return $this;
    }
    private function myVf7PZhUwx(bool $livtu) : array
    {
        goto KXfab;
        AUIZM:
        throw new \LogicException('You must provide a input file to use');
        goto uuLBd;
        kHSW1:
        unset($urPJX['Settings']['OutputGroups']);
        goto PEEfR;
        RNT05:
        $o1KLI['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->yXR7S;
        goto qWoG0;
        NEaF4:
        $urPJX['Settings']['OutputGroups'][] = $this->oMOXS->mN4KrajeB1s();
        goto yd2Qu;
        s3w2d:
        $this->PyPKn = [];
        goto jtjPx;
        PEEfR:
        $o1KLI['Outputs'] = [];
        goto lUKuy;
        DalBs:
        NaUwg:
        goto RNT05;
        eBj5Z:
        $urPJX['Role'] = $this->iZFOi;
        goto Pw_h1;
        kMDMq:
        $this->j6boU = null;
        goto s3w2d;
        KXfab:
        $urPJX = (require 'template.php');
        goto eBj5Z;
        jtjPx:
        return $urPJX;
        goto qB49d;
        uuLBd:
        gUAzZ:
        goto p36Za;
        lUKuy:
        foreach ($this->PyPKn as $WAe4c) {
            $o1KLI['Outputs'][] = $WAe4c->mNoK24UTk7v();
            BmQUw:
        }
        goto DalBs;
        AVQgW:
        if (!$this->oMOXS) {
            goto S0ZmH;
        }
        goto NEaF4;
        qWoG0:
        $urPJX['Settings']['OutputGroups'][] = $o1KLI;
        goto AVQgW;
        fvL4C:
        $this->oMOXS = null;
        goto kMDMq;
        x3xdt:
        if (!$livtu) {
            goto YuH4D;
        }
        goto U2KPp;
        Pw_h1:
        $urPJX['Queue'] = $this->O3EIX;
        goto AfLkI;
        AfLkI:
        if ($this->j6boU) {
            goto gUAzZ;
        }
        goto AUIZM;
        p36Za:
        $urPJX['Settings']['Inputs'] = $this->j6boU->mm2MECJxnD8();
        goto EqnIs;
        B2TKk:
        YuH4D:
        goto fvL4C;
        U2KPp:
        $urPJX['AccelerationSettings']['Mode'] = 'ENABLED';
        goto B2TKk;
        yd2Qu:
        S0ZmH:
        goto x3xdt;
        EqnIs:
        $o1KLI = $urPJX['Settings']['OutputGroups'][0];
        goto kHSW1;
        qB49d:
    }
    public function mAkKGuYRFIH(bool $livtu = false) : string
    {
        try {
            $CT4ZU = $this->Bm0y3->createJob($this->myVf7PZhUwx($livtu));
            return $CT4ZU->get('Jobs')['Id'];
        } catch (AwsException $IGLS9) {
            Log::error('Error creating MediaConvert job: ' . $IGLS9->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $IGLS9);
        }
    }
}
