<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class GoSZbz69l96g0
{
    private $B6Fhn;
    public function __construct(float $L0LJi, int $vFG83, string $H_g0M)
    {
        goto XNl7n;
        XNl7n:
        $U0tYo = (int) $L0LJi / $vFG83;
        goto fAaus;
        QkNNh:
        $this->B6Fhn = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $U0tYo]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $H_g0M]]];
        goto js0hb;
        fAaus:
        $U0tYo = max($U0tYo, 1);
        goto QkNNh;
        js0hb:
    }
    public function mFFCcYamld2() : array
    {
        return $this->B6Fhn;
    }
}
