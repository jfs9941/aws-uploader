<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Service\BVykbOopwUKwx;
final class CqIfz7C8PXyW1
{
    public const wE0l_ = 'v2/hls/';
    private $RvSpm;
    private $Aj6QZ;
    public function __construct(BVykbOopwUKwx $YotoQ, Filesystem $SaekO)
    {
        $this->RvSpm = $YotoQ;
        $this->Aj6QZ = $SaekO;
    }
    public function mNVm7oEvEEI($iit8z) : string
    {
        return $this->RvSpm->mDJ5zUrqdk7(self::wE0l_ . $iit8z->getAttribute('id') . '/');
    }
    public function mHVNClNLBpr($iit8z) : string
    {
        return $this->RvSpm->mDJ5zUrqdk7(self::wE0l_ . $iit8z->getAttribute('id') . '/thumbnail/');
    }
    public function mvKOSDxEObU($iit8z, $K3up0 = true) : string
    {
        goto e6Ttj;
        j4VUU:
        return $this->RvSpm->mDJ5zUrqdk7(self::wE0l_ . $iit8z->getAttribute('id') . '/' . $iit8z->getAttribute('id') . '.m3u8');
        goto Z3Q1p;
        e6Ttj:
        if ($K3up0) {
            goto RWDVT;
        }
        goto TxSJk;
        T0jQm:
        RWDVT:
        goto j4VUU;
        TxSJk:
        return self::wE0l_ . $iit8z->getAttribute('id') . '/' . $iit8z->getAttribute('id') . '.m3u8';
        goto T0jQm;
        Z3Q1p:
    }
    public function resolveThumbnail($iit8z) : string
    {
        goto hVNlp;
        hVNlp:
        $BFPg9 = $iit8z->getAttribute('id');
        goto o3bOP;
        o3bOP:
        $CaSyV = $this->Aj6QZ->files($this->mHVNClNLBpr($iit8z));
        goto kClRx;
        kClRx:
        return 1 == count($CaSyV) ? self::wE0l_ . $BFPg9 . '/thumbnail/' . $BFPg9 . '.0000000.jpg' : self::wE0l_ . $BFPg9 . '/thumbnail/' . $BFPg9 . '.0000001.jpg';
        goto Th_DU;
        Th_DU:
    }
    public function mFCfdZHHx4W(string $fdqWg) : string
    {
        return $this->Aj6QZ->url($fdqWg);
    }
}
