<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class LTe1erTqXsoi2
{
    private $b53Em;
    private $Vevmt;
    private $Ljq22;
    private $fSP8S;
    private $T9XQc;
    private $Pbnck;
    private $pxIiA;
    public function __construct(MediaConvertClient $JYq4j, $gBJa3, $na786)
    {
        goto IVBKo;
        IVBKo:
        $this->fSP8S = $JYq4j;
        goto nPQSa;
        nPQSa:
        $this->T9XQc = $gBJa3;
        goto hhRkv;
        hhRkv:
        $this->Pbnck = $na786;
        goto B9iDg;
        B9iDg:
    }
    public function m8kV1WNnF9Y() : MediaConvertClient
    {
        return $this->fSP8S;
    }
    public function mi9Yzacz071(XTvyjq4TjM6Q2 $M8Szh) : self
    {
        $this->b53Em = $M8Szh;
        return $this;
    }
    public function mjeP04tsbZq(string $akNEN) : self
    {
        $this->Ljq22 = $akNEN;
        return $this;
    }
    public function m4GsFz2jrqE(Ij7aQIVlXZdDe $XdhZz) : self
    {
        $this->Vevmt[] = $XdhZz;
        return $this;
    }
    public function munJ0Lc3jZX(Z98THp6d6oPOr $I_Zk6) : self
    {
        $this->pxIiA = $I_Zk6;
        return $this;
    }
    private function mPFvisFNmap(bool $W5uM7) : array
    {
        goto rUaRc;
        E21Iu:
        $vZ6qp['Settings']['OutputGroups'][] = $this->pxIiA->md6JvC1MTxd();
        goto kznBY;
        Eh4fi:
        wHaC0:
        goto LKC0B;
        fUqPp:
        $m8zA6 = $vZ6qp['Settings']['OutputGroups'][0];
        goto zDIWe;
        m3dlb:
        nzIUS:
        goto GZPCR;
        lmood:
        zAkJo:
        goto vPj1B;
        CzQcH:
        throw new \LogicException('You must provide a input file to use');
        goto lmood;
        hbkfn:
        if (!$W5uM7) {
            goto nzIUS;
        }
        goto YGdo_;
        rUaRc:
        $vZ6qp = (require 'template.php');
        goto lSOJl;
        Qmdpn:
        $this->Vevmt = [];
        goto yGMH3;
        h5W07:
        if (!$this->pxIiA) {
            goto iewSI;
        }
        goto E21Iu;
        lSOJl:
        $vZ6qp['Role'] = $this->T9XQc;
        goto eWvwC;
        YGdo_:
        $vZ6qp['AccelerationSettings']['Mode'] = 'ENABLED';
        goto m3dlb;
        Epiim:
        $this->b53Em = null;
        goto Qmdpn;
        KJaBv:
        if ($this->b53Em) {
            goto zAkJo;
        }
        goto CzQcH;
        kznBY:
        iewSI:
        goto hbkfn;
        tZaiw:
        $vZ6qp['Settings']['OutputGroups'][] = $m8zA6;
        goto h5W07;
        eWvwC:
        $vZ6qp['Queue'] = $this->Pbnck;
        goto KJaBv;
        yGMH3:
        return $vZ6qp;
        goto OesAK;
        vPj1B:
        $vZ6qp['Settings']['Inputs'] = $this->b53Em->mwywCP6AbCN();
        goto fUqPp;
        zDIWe:
        unset($vZ6qp['Settings']['OutputGroups']);
        goto ArzJV;
        ArzJV:
        $m8zA6['Outputs'] = [];
        goto YLPiL;
        GZPCR:
        $this->pxIiA = null;
        goto Epiim;
        YLPiL:
        foreach ($this->Vevmt as $XdhZz) {
            $m8zA6['Outputs'][] = $XdhZz->mQXMSTmtXqw();
            sZv8g:
        }
        goto Eh4fi;
        LKC0B:
        $m8zA6['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->Ljq22;
        goto tZaiw;
        OesAK:
    }
    public function mkFdgQFoaZa(bool $W5uM7 = false) : string
    {
        try {
            $bZOiO = $this->fSP8S->createJob($this->mPFvisFNmap($W5uM7));
            return $bZOiO->get('Jobs')['Id'];
        } catch (AwsException $xlNa7) {
            Log::error('Error creating MediaConvert job: ' . $xlNa7->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $xlNa7);
        }
    }
}
