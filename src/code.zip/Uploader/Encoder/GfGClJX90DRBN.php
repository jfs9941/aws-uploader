<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Service\O64LTP0s3gT1J;
use Illuminate\Contracts\Filesystem\Filesystem;
final class GfGClJX90DRBN
{
    public const NYveK = 'v2/hls/';
    private $qJ6XE;
    private $huyLW;
    public function __construct(O64LTP0s3gT1J $IuV7H, Filesystem $A3hvZ)
    {
        $this->qJ6XE = $IuV7H;
        $this->huyLW = $A3hvZ;
    }
    public function mqE7Y3tGn1Q($XFeNv) : string
    {
        return $this->qJ6XE->mNNTgT6UPFH(self::NYveK . $XFeNv->getAttribute('id') . '/');
    }
    public function mfPcBw4lY1y($XFeNv) : string
    {
        return $this->qJ6XE->mNNTgT6UPFH(self::NYveK . $XFeNv->getAttribute('id') . '/thumbnail/');
    }
    public function mkH5hX8oqov($XFeNv, $y8eHd = true) : string
    {
        goto nQPAl;
        efupj:
        gm5v2:
        goto McsCw;
        nQPAl:
        if ($y8eHd) {
            goto gm5v2;
        }
        goto Pkbjv;
        McsCw:
        return $this->qJ6XE->mNNTgT6UPFH(self::NYveK . $XFeNv->getAttribute('id') . '/' . $XFeNv->getAttribute('id') . '.m3u8');
        goto ZZrHU;
        Pkbjv:
        return self::NYveK . $XFeNv->getAttribute('id') . '/' . $XFeNv->getAttribute('id') . '.m3u8';
        goto efupj;
        ZZrHU:
    }
    public function resolveThumbnail($XFeNv) : string
    {
        goto c00Ta;
        qRTu7:
        return 1 == count($ypBNL) ? self::NYveK . $arqvy . '/thumbnail/' . $arqvy . '.0000000.jpg' : self::NYveK . $arqvy . '/thumbnail/' . $arqvy . '.0000001.jpg';
        goto MlJRc;
        wutA1:
        $ypBNL = $this->huyLW->files($this->mfPcBw4lY1y($XFeNv));
        goto qRTu7;
        c00Ta:
        $arqvy = $XFeNv->getAttribute('id');
        goto wutA1;
        MlJRc:
    }
    public function mwGKoiVmCfu(string $lxbX3) : string
    {
        return $this->huyLW->url($lxbX3);
    }
}
