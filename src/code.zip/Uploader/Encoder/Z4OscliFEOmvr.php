<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class Z4OscliFEOmvr
{
    private $Nl2mw;
    private $a2OSm;
    private $dksSN;
    private $oqbnS;
    private $KPY9U;
    private $gZIbH;
    private $CKPey;
    public function __construct(MediaConvertClient $ysn3K, $ykLC9, $kSszM)
    {
        goto fsr59;
        fsr59:
        $this->oqbnS = $ysn3K;
        goto rsHGJ;
        rsHGJ:
        $this->KPY9U = $ykLC9;
        goto Te0JV;
        Te0JV:
        $this->gZIbH = $kSszM;
        goto Ebbgu;
        Ebbgu:
    }
    public function mWjgNr22e3o() : MediaConvertClient
    {
        return $this->oqbnS;
    }
    public function m0zGgXopQXk(PR0yJBVlrU7TV $UPU1B) : self
    {
        $this->Nl2mw = $UPU1B;
        return $this;
    }
    public function mUaO46dda49(string $FdGQq) : self
    {
        $this->dksSN = $FdGQq;
        return $this;
    }
    public function mpbrd1Q9bSN(VJyQpEMUBJg8a $Jk3ij) : self
    {
        $this->a2OSm[] = $Jk3ij;
        return $this;
    }
    public function mcN42vKef2E(PvdMmITg3OR2U $qqIkT) : self
    {
        $this->CKPey = $qqIkT;
        return $this;
    }
    private function mvXIfGXmG4X(bool $ewkSU) : array
    {
        goto cVl9d;
        vbL8O:
        $this->Nl2mw = null;
        goto BzvUR;
        gf5K5:
        return $uPCq4;
        goto pj2WH;
        dPbhq:
        tK9gy:
        goto O1gvN;
        BpP02:
        $UZ8bS['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->dksSN;
        goto TF9ap;
        dq3vY:
        $uPCq4['AccelerationSettings']['Mode'] = 'ENABLED';
        goto BHPiZ;
        O1gvN:
        if (!$ewkSU) {
            goto j6tCd;
        }
        goto dq3vY;
        gtha5:
        $this->CKPey = null;
        goto vbL8O;
        gNKTg:
        $uPCq4['Role'] = $this->KPY9U;
        goto hgChz;
        qDgtB:
        Shpjz:
        goto O_eww;
        tls20:
        ZU2Ef:
        goto BpP02;
        anm8F:
        $UZ8bS['Outputs'] = [];
        goto LLD3x;
        TF9ap:
        $uPCq4['Settings']['OutputGroups'][] = $UZ8bS;
        goto J1EdY;
        hgChz:
        $uPCq4['Queue'] = $this->gZIbH;
        goto mwuI9;
        BHPiZ:
        j6tCd:
        goto gtha5;
        k4Eb3:
        $UZ8bS = $uPCq4['Settings']['OutputGroups'][0];
        goto oGS_B;
        PJ1B3:
        $uPCq4['Settings']['OutputGroups'][] = $this->CKPey->mDj9AhmTQ5a();
        goto dPbhq;
        Hg3bn:
        throw new \LogicException('You must provide a input file to use');
        goto qDgtB;
        LLD3x:
        foreach ($this->a2OSm as $Jk3ij) {
            $UZ8bS['Outputs'][] = $Jk3ij->ms2snJfCX5N();
            vO64E:
        }
        goto tls20;
        oGS_B:
        unset($uPCq4['Settings']['OutputGroups']);
        goto anm8F;
        J1EdY:
        if (!$this->CKPey) {
            goto tK9gy;
        }
        goto PJ1B3;
        mwuI9:
        if ($this->Nl2mw) {
            goto Shpjz;
        }
        goto Hg3bn;
        O_eww:
        $uPCq4['Settings']['Inputs'] = $this->Nl2mw->m9vsQNAdmKz();
        goto k4Eb3;
        BzvUR:
        $this->a2OSm = [];
        goto gf5K5;
        cVl9d:
        $uPCq4 = (require 'template.php');
        goto gNKTg;
        pj2WH:
    }
    public function mWdVr0b3yO7(bool $ewkSU = false) : string
    {
        try {
            $gy2ea = $this->oqbnS->createJob($this->mvXIfGXmG4X($ewkSU));
            return $gy2ea->get('Jobs')['Id'];
        } catch (AwsException $ZkRqE) {
            Log::error('Error creating MediaConvert job: ' . $ZkRqE->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $ZkRqE);
        }
    }
}
