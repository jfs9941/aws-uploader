<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\WJAE7lcMNfE1y;
use Jfs\Uploader\Encoder\UB8Ev08ZytFP3;
use Jfs\Uploader\Encoder\ZAV6YqtgGxk5Y;
use Illuminate\Support\Facades\Log;
final class Y272Vu6XdYN6L
{
    private $aht5Z;
    private $b57EC;
    private $T0kuH;
    private $N5Lav;
    private $zwYoZ;
    private $FymXi;
    private $zeJHK;
    public function __construct(MediaConvertClient $gBys2, $d_zV0, $sxqfi)
    {
        goto kPc_p;
        C1a7I:
        $this->zwYoZ = $d_zV0;
        goto RxfZG;
        kPc_p:
        $this->N5Lav = $gBys2;
        goto C1a7I;
        RxfZG:
        $this->FymXi = $sxqfi;
        goto oWzpG;
        oWzpG:
    }
    public function miWCM192CHl() : MediaConvertClient
    {
        return $this->N5Lav;
    }
    public function mJgkRIqDk7b(ZAV6YqtgGxk5Y $Q_wGi) : self
    {
        $this->aht5Z = $Q_wGi;
        return $this;
    }
    public function m4MqqD6YjaJ(string $OtKpj) : self
    {
        $this->T0kuH = $OtKpj;
        return $this;
    }
    public function mJ1YHTdmdO0(UB8Ev08ZytFP3 $Vuv2G) : self
    {
        $this->b57EC[] = $Vuv2G;
        return $this;
    }
    public function mxOg1xgle9C(WJAE7lcMNfE1y $iSeOK) : self
    {
        $this->zeJHK = $iSeOK;
        return $this;
    }
    private function mJWiCW2eR6z(bool $ANtoX) : array
    {
        goto yTXa7;
        HQCNK:
        unset($fURAt['Settings']['OutputGroups']);
        goto mUznR;
        B4oBA:
        apG7C:
        goto rC04M;
        quiqL:
        throw new \LogicException('You must provide a input file to use');
        goto F2Aoe;
        rFu24:
        $oR5Hc['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->T0kuH;
        goto lxKff;
        O9gCK:
        $fURAt['AccelerationSettings']['Mode'] = 'ENABLED';
        goto xHXNr;
        mUznR:
        $oR5Hc['Outputs'] = [];
        goto ne3Rf;
        KJfIL:
        if ($this->aht5Z) {
            goto NX8v3;
        }
        goto quiqL;
        ne3Rf:
        foreach ($this->b57EC as $Vuv2G) {
            $oR5Hc['Outputs'][] = $Vuv2G->mSu7qfVuhUe();
            E8NVZ:
        }
        goto bfTUF;
        lxKff:
        $fURAt['Settings']['OutputGroups'][] = $oR5Hc;
        goto AVC_B;
        ZxHvu:
        $this->b57EC = [];
        goto LxWXY;
        SWEi5:
        $fURAt['Queue'] = $this->FymXi;
        goto KJfIL;
        G56O6:
        $oR5Hc = $fURAt['Settings']['OutputGroups'][0];
        goto HQCNK;
        VBx2n:
        $this->aht5Z = null;
        goto ZxHvu;
        yTXa7:
        $fURAt = (require 'template.php');
        goto y_UOi;
        F2Aoe:
        NX8v3:
        goto F2A4v;
        YwJ0S:
        $this->zeJHK = null;
        goto VBx2n;
        y_UOi:
        $fURAt['Role'] = $this->zwYoZ;
        goto SWEi5;
        kURCV:
        $fURAt['Settings']['OutputGroups'][] = $this->zeJHK->mgDWTJsepR0();
        goto B4oBA;
        xHXNr:
        kfqbO:
        goto YwJ0S;
        LxWXY:
        return $fURAt;
        goto glG0c;
        rC04M:
        if (!$ANtoX) {
            goto kfqbO;
        }
        goto O9gCK;
        AVC_B:
        if (!$this->zeJHK) {
            goto apG7C;
        }
        goto kURCV;
        bfTUF:
        SQr30:
        goto rFu24;
        F2A4v:
        $fURAt['Settings']['Inputs'] = $this->aht5Z->mvSWXiDnjA3();
        goto G56O6;
        glG0c:
    }
    public function mplZWbqExUn(bool $ANtoX = false) : string
    {
        try {
            $hd6J3 = $this->N5Lav->createJob($this->mJWiCW2eR6z($ANtoX));
            return $hd6J3->get('Jobs')['Id'];
        } catch (AwsException $OaHp2) {
            Log::error('Error creating MediaConvert job: ' . $OaHp2->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $OaHp2);
        }
    }
}
