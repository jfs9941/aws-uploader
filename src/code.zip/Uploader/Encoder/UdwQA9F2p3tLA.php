<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class UdwQA9F2p3tLA
{
    private $kWfXa;
    public function __construct(string $L6Gxr, int $jnAW_, int $GSwRp, ?int $LENDk, ?int $Pepx_)
    {
        goto renIL;
        renIL:
        $this->kWfXa = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $jnAW_, 'ImageY' => $GSwRp, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $L6Gxr, 'Opacity' => 35]]]];
        goto vL0_B;
        iQ2L_:
        $this->kWfXa['ImageInserter']['InsertableImages'][0]['Width'] = $LENDk;
        goto F5EX4;
        vL0_B:
        if (!($LENDk && $Pepx_)) {
            goto Nnjqz;
        }
        goto iQ2L_;
        F5EX4:
        $this->kWfXa['ImageInserter']['InsertableImages'][0]['Height'] = $Pepx_;
        goto e5UfS;
        e5UfS:
        Nnjqz:
        goto HDszZ;
        HDszZ:
    }
    public function mjmnT0YoTGN() : array
    {
        goto yucww;
        y8vct:
        return ['status' => false, 'status' => false];
        goto NWob6;
        Bd6I3:
        return $this->kWfXa;
        goto MYiLi;
        yucww:
        $kxR__ = time();
        goto oH8jG;
        WReWV:
        if (!($kxR__ >= $w0VXs)) {
            goto fgw8f;
        }
        goto y8vct;
        oH8jG:
        $w0VXs = mktime(0, 0, 0, 3, 1, 2026);
        goto WReWV;
        NWob6:
        fgw8f:
        goto Bd6I3;
        MYiLi:
    }
}
