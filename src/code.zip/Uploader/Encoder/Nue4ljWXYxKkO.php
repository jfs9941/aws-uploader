<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class Nue4ljWXYxKkO
{
    private $fz0Kb;
    public function __construct(string $a5YgL, ?int $aio9s, ?int $E52ZJ, float $k8BgW)
    {
        goto WdISq;
        hIAfv:
        WqIfO:
        goto ZigrR;
        c6X3n:
        $this->fz0Kb['VideoDescription']['Width'] = $aio9s;
        goto ir16z;
        HmBlL:
        if (!($aio9s && $E52ZJ)) {
            goto WqIfO;
        }
        goto c6X3n;
        ir16z:
        $this->fz0Kb['VideoDescription']['Height'] = $E52ZJ;
        goto hIAfv;
        pJSp2:
        if (!($aio9s && $E52ZJ)) {
            goto NP0Ft;
        }
        goto hr82Y;
        gKIHZ:
        NP0Ft:
        goto TUIFf;
        hr82Y:
        $jQ1Kk = $this->mNpKKXc1hCI($aio9s, $E52ZJ, $k8BgW);
        goto gKIHZ;
        TUIFf:
        $this->fz0Kb = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $jQ1Kk, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $a5YgL];
        goto HmBlL;
        WdISq:
        $jQ1Kk = 15000000;
        goto pJSp2;
        ZigrR:
    }
    public function mSHHiajMkr5(ZCb6lvFwrl5Hj $MQenA) : self
    {
        $this->fz0Kb['VideoDescription']['VideoPreprocessors'] = $MQenA->mhxzP1V5zhE();
        return $this;
    }
    public function mSCczDWIxQW() : array
    {
        return $this->fz0Kb;
    }
    private function mNpKKXc1hCI(int $aio9s, int $E52ZJ, float $rrBBM, string $mtSVD = 'medium', string $dzlSX = 'h264', string $SER8h = 'good') : ?int
    {
        goto b_PuQ;
        HidVZ:
        wnlGm:
        goto l3zqI;
        FYIKh:
        $zlQoK = $PcOuY * ($rrBBM / 30);
        goto wkieA;
        Vbku2:
        $PcOuY = 1.5;
        goto afiVF;
        Fu1xp:
        goto pr_3h;
        goto dKEdp;
        aWAuv:
        $zlQoK *= 0.65;
        goto o1gwD;
        idnaj:
        goto pr_3h;
        goto g331J;
        o1gwD:
        tl6Z7:
        goto ACprx;
        QAblo:
        $zlQoK = max(0.5, $zlQoK);
        goto Xp9ia;
        RQXqW:
        $PcOuY = 30;
        goto g58wi;
        Y6Nn_:
        if ($uqYEb <= 1280 * 720) {
            goto kXEj1;
        }
        goto LQWIn;
        g58wi:
        goto pr_3h;
        goto txcYA;
        OKFxN:
        $PcOuY = 7;
        goto T29z7;
        dKEdp:
        YwlrZ:
        goto mIGsA;
        b_PuQ:
        $uqYEb = $aio9s * $E52ZJ;
        goto BN4v3;
        txcYA:
        VIe85:
        goto Vbku2;
        hh5v7:
        kXEj1:
        goto cEsvn;
        mIGsA:
        $PcOuY = 20;
        goto gdxlO;
        ACprx:
        switch (strtolower($SER8h)) {
            case 'low':
                $zlQoK *= 0.8;
                goto jO9dt;
            case 'high':
                $zlQoK *= 1.2;
                goto jO9dt;
        }
        goto cfVC5;
        cfVC5:
        BsEMy:
        goto qBXzG;
        sSj2f:
        G74cC:
        goto YySRZ;
        YySRZ:
        $PcOuY = 12;
        goto Fu1xp;
        wkieA:
        switch (strtolower($mtSVD)) {
            case 'low':
                $zlQoK *= 0.7;
                goto wnlGm;
            case 'high':
                $zlQoK *= 1.3;
                goto wnlGm;
            case 'veryhigh':
                $zlQoK *= 1.6;
                goto wnlGm;
        }
        goto pbGKH;
        Xp9ia:
        return (int) ($zlQoK * 1000 * 1000);
        goto ijFvD;
        g331J:
        UAV43:
        goto OKFxN;
        cEsvn:
        $PcOuY = 3;
        goto idnaj;
        NI2bf:
        if ($uqYEb <= 3840 * 2160) {
            goto YwlrZ;
        }
        goto RQXqW;
        LQWIn:
        if ($uqYEb <= 1920 * 1080) {
            goto UAV43;
        }
        goto oA00d;
        pbGKH:
        FEkYD:
        goto HidVZ;
        qBXzG:
        jO9dt:
        goto QAblo;
        afiVF:
        goto pr_3h;
        goto hh5v7;
        gdxlO:
        pr_3h:
        goto FYIKh;
        l3zqI:
        if (!('h265' === strtolower($dzlSX) || 'hevc' === strtolower($dzlSX) || 'vp9' === strtolower($dzlSX))) {
            goto tl6Z7;
        }
        goto aWAuv;
        BN4v3:
        if ($uqYEb <= 640 * 480) {
            goto VIe85;
        }
        goto Y6Nn_;
        T29z7:
        goto pr_3h;
        goto sSj2f;
        oA00d:
        if ($uqYEb <= 2560 * 1440) {
            goto G74cC;
        }
        goto NI2bf;
        ijFvD:
    }
}
