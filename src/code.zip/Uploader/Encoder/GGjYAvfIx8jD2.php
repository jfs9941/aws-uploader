<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class GGjYAvfIx8jD2
{
    private $Tfq0C;
    private $woAfv;
    private $HcvaQ;
    private $PICWC;
    private $kcYd_;
    private $qj0ob;
    private $g97cm;
    public function __construct(MediaConvertClient $HKHTX, $KPZer, $Fsndx)
    {
        goto YLMHB;
        r01oZ:
        $this->kcYd_ = $KPZer;
        goto fn5tb;
        fn5tb:
        $this->qj0ob = $Fsndx;
        goto BanN2;
        YLMHB:
        $this->PICWC = $HKHTX;
        goto r01oZ;
        BanN2:
    }
    public function mR9PijebH8w() : MediaConvertClient
    {
        return $this->PICWC;
    }
    public function mH79deOSFTC(Zu01XTNfnZhjW $rMVBn) : self
    {
        $this->Tfq0C = $rMVBn;
        return $this;
    }
    public function mZdd6VkymGA(string $eQ1QS) : self
    {
        $this->HcvaQ = $eQ1QS;
        return $this;
    }
    public function muMfW5wYw2z(JCn5h7b7KyFNK $KcGkT) : self
    {
        $this->woAfv[] = $KcGkT;
        return $this;
    }
    public function mAxttTQyPrn(KxPUocSKhVWfb $IlGiN) : self
    {
        $this->g97cm = $IlGiN;
        return $this;
    }
    private function mNfqkN6QgDQ(bool $q8Hp1) : array
    {
        goto FxfYZ;
        Z7Gh6:
        foreach ($this->woAfv as $KcGkT) {
            $rUaVO['Outputs'][] = $KcGkT->mxLsNpCJJ2G();
            IQRKb:
        }
        goto m3ezZ;
        XIkMd:
        $rUaVO = $bUBjk['Settings']['OutputGroups'][0];
        goto LRqF5;
        gc6he:
        f060U:
        goto Hzzyf;
        dRWxx:
        PBY5w:
        goto xBa9L;
        XKIPn:
        $bUBjk['Queue'] = $this->qj0ob;
        goto TGt1g;
        Hzzyf:
        $this->g97cm = null;
        goto jL1pV;
        ZSWWv:
        $this->woAfv = [];
        goto JfPIs;
        m3ezZ:
        QttjC:
        goto euBr3;
        f66mv:
        $bUBjk['AccelerationSettings']['Mode'] = 'ENABLED';
        goto gc6he;
        TGt1g:
        if ($this->Tfq0C) {
            goto PBY5w;
        }
        goto Orthl;
        JfPIs:
        return $bUBjk;
        goto gER3u;
        ywLqv:
        $bUBjk['Settings']['OutputGroups'][] = $rUaVO;
        goto qcV7j;
        qcV7j:
        if (!$this->g97cm) {
            goto aJ5ps;
        }
        goto N4NjR;
        UXAYb:
        aJ5ps:
        goto FSqht;
        euBr3:
        $rUaVO['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->HcvaQ;
        goto ywLqv;
        Orthl:
        throw new \LogicException('You must provide a input file to use');
        goto dRWxx;
        N4NjR:
        $bUBjk['Settings']['OutputGroups'][] = $this->g97cm->mqFFnuR8hEN();
        goto UXAYb;
        xBa9L:
        $bUBjk['Settings']['Inputs'] = $this->Tfq0C->mOWY7tzjRJw();
        goto XIkMd;
        vX7b1:
        $rUaVO['Outputs'] = [];
        goto Z7Gh6;
        jL1pV:
        $this->Tfq0C = null;
        goto ZSWWv;
        FSqht:
        if (!$q8Hp1) {
            goto f060U;
        }
        goto f66mv;
        FxfYZ:
        $bUBjk = (require 'template.php');
        goto F8etQ;
        LRqF5:
        unset($bUBjk['Settings']['OutputGroups']);
        goto vX7b1;
        F8etQ:
        $bUBjk['Role'] = $this->kcYd_;
        goto XKIPn;
        gER3u:
    }
    public function mU7oQqORfRT(bool $q8Hp1 = false) : string
    {
        try {
            $QuGN9 = $this->PICWC->createJob($this->mNfqkN6QgDQ($q8Hp1));
            return $QuGN9->get('Jobs')['Id'];
        } catch (AwsException $Z8tVK) {
            Log::error('Error creating MediaConvert job: ' . $Z8tVK->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $Z8tVK);
        }
    }
}
