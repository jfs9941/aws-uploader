<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\Rcz6vFPVp31Qt;
final class HYlcVVWzTHXE3
{
    private $O9Z1Z;
    public function __construct(string $rMqds, ?int $XLJzE, ?int $X8shh, float $q3afb)
    {
        goto EYJhM;
        Jjnt_:
        $jeEuU = $this->msO9crGyoir($XLJzE, $X8shh, $q3afb);
        goto vSij3;
        EYJhM:
        $jeEuU = 15000000;
        goto zrtIT;
        vSij3:
        M8SY6:
        goto IW4Lf;
        IW4Lf:
        $this->O9Z1Z = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $jeEuU, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $rMqds];
        goto H3UHC;
        zEF21:
        $this->O9Z1Z['VideoDescription']['Height'] = $X8shh;
        goto gw2mA;
        gw2mA:
        hQk9n:
        goto VaCHL;
        dt7cb:
        $this->O9Z1Z['VideoDescription']['Width'] = $XLJzE;
        goto zEF21;
        zrtIT:
        if (!($XLJzE && $X8shh)) {
            goto M8SY6;
        }
        goto Jjnt_;
        H3UHC:
        if (!($XLJzE && $X8shh)) {
            goto hQk9n;
        }
        goto dt7cb;
        VaCHL:
    }
    public function mMiBm0pSYGw(Rcz6vFPVp31Qt $rUdwx) : self
    {
        $this->O9Z1Z['VideoDescription']['VideoPreprocessors'] = $rUdwx->mkZuE3ZwExP();
        return $this;
    }
    public function mP8OeZyfu4Q() : array
    {
        return $this->O9Z1Z;
    }
    private function msO9crGyoir(int $XLJzE, int $X8shh, float $et4o_, string $YASzy = 'medium', string $n10Z6 = 'h264', string $uMDdV = 'good') : ?int
    {
        goto YEN3q;
        x77tm:
        zYnB6:
        goto IUVlx;
        s50Nm:
        ConK0:
        goto x77tm;
        ZO3VS:
        if ($vMtOH <= 3840 * 2160) {
            goto wC1Hi;
        }
        goto CE428;
        WnhoM:
        if ($vMtOH <= 1920 * 1080) {
            goto WRzj2;
        }
        goto TO8RU;
        dfzpO:
        if ($vMtOH <= 640 * 480) {
            goto Lp3Pe;
        }
        goto POSXh;
        YkqhU:
        $HmBst = 1.5;
        goto avxMj;
        U4DIJ:
        $HmBst = 20;
        goto l9u7P;
        LV4Gp:
        vfZI1:
        goto I6InY;
        x7C3c:
        goto uOvYa;
        goto YASH2;
        JjpQ7:
        $V9zOp = $HmBst * ($et4o_ / 30);
        goto Lzwb_;
        YEN3q:
        $vMtOH = $XLJzE * $X8shh;
        goto dfzpO;
        ORmQ_:
        switch (strtolower($uMDdV)) {
            case 'low':
                $V9zOp *= 0.8;
                goto kx_cH;
            case 'high':
                $V9zOp *= 1.2;
                goto kx_cH;
        }
        goto UzHSl;
        GGCBJ:
        $V9zOp *= 0.65;
        goto G91lm;
        yXQ8U:
        n135z:
        goto Z9AA2;
        jk3kC:
        goto uOvYa;
        goto yXQ8U;
        Lzwb_:
        switch (strtolower($YASzy)) {
            case 'low':
                $V9zOp *= 0.7;
                goto zYnB6;
            case 'high':
                $V9zOp *= 1.3;
                goto zYnB6;
            case 'veryhigh':
                $V9zOp *= 1.6;
                goto zYnB6;
        }
        goto s50Nm;
        CE428:
        $HmBst = 30;
        goto shAXa;
        YASH2:
        WRzj2:
        goto JIRQY;
        avxMj:
        goto uOvYa;
        goto LV4Gp;
        TO8RU:
        if ($vMtOH <= 2560 * 1440) {
            goto n135z;
        }
        goto ZO3VS;
        UzHSl:
        NWJON:
        goto AnbP3;
        Z9AA2:
        $HmBst = 12;
        goto zLOoN;
        JIRQY:
        $HmBst = 7;
        goto jk3kC;
        shAXa:
        goto uOvYa;
        goto mFQ9F;
        G91lm:
        i98cO:
        goto ORmQ_;
        POSXh:
        if ($vMtOH <= 1280 * 720) {
            goto vfZI1;
        }
        goto WnhoM;
        bEOAS:
        wC1Hi:
        goto U4DIJ;
        F_byE:
        return (int) ($V9zOp * 1000 * 1000);
        goto e8Rs0;
        I6InY:
        $HmBst = 3;
        goto x7C3c;
        dXVRo:
        $V9zOp = max(0.5, $V9zOp);
        goto F_byE;
        zLOoN:
        goto uOvYa;
        goto bEOAS;
        IUVlx:
        if (!('h265' === strtolower($n10Z6) || 'hevc' === strtolower($n10Z6) || 'vp9' === strtolower($n10Z6))) {
            goto i98cO;
        }
        goto GGCBJ;
        l9u7P:
        uOvYa:
        goto JjpQ7;
        mFQ9F:
        Lp3Pe:
        goto YkqhU;
        AnbP3:
        kx_cH:
        goto dXVRo;
        e8Rs0:
    }
}
