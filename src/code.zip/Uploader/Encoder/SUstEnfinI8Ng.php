<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\QskQm1izUO3G7;
use Jfs\Uploader\Encoder\LbzHNsWFIAPi8;
use Jfs\Uploader\Encoder\NdDX16WGrVibA;
use Illuminate\Support\Facades\Log;
final class SUstEnfinI8Ng
{
    private $kRiuL;
    private $Yid_7;
    private $B0id3;
    private $P3dZD;
    private $FKbnr;
    private $Z7rc7;
    private $aweuO;
    public function __construct(MediaConvertClient $h1eNw, $xPW7D, $J9JKP)
    {
        goto H8rIa;
        H8rIa:
        $this->P3dZD = $h1eNw;
        goto cRdEW;
        cRdEW:
        $this->FKbnr = $xPW7D;
        goto Evoq3;
        Evoq3:
        $this->Z7rc7 = $J9JKP;
        goto tKJC3;
        tKJC3:
    }
    public function mRzFOPOfj66() : MediaConvertClient
    {
        return $this->P3dZD;
    }
    public function mMPtSIN56BN(NdDX16WGrVibA $nH3Bk) : self
    {
        $this->kRiuL = $nH3Bk;
        return $this;
    }
    public function mr6h3IadK1P(string $CznL5) : self
    {
        $this->B0id3 = $CznL5;
        return $this;
    }
    public function mCnU6U0mCug(LbzHNsWFIAPi8 $QJpOL) : self
    {
        $this->Yid_7[] = $QJpOL;
        return $this;
    }
    public function mZ9LJlxWXDo(QskQm1izUO3G7 $lSq7k) : self
    {
        $this->aweuO = $lSq7k;
        return $this;
    }
    private function mAfSCPFGuJR(bool $bKPSG) : array
    {
        goto bixZB;
        oR7Ey:
        $this->kRiuL = null;
        goto yLHuU;
        EDmnr:
        $t7jR4['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->B0id3;
        goto sYhfr;
        CJ1l3:
        if (!$this->aweuO) {
            goto t8NTx;
        }
        goto UypDU;
        ko1im:
        $t7jR4['Outputs'] = [];
        goto ikfbo;
        UypDU:
        $QYMt1['Settings']['OutputGroups'][] = $this->aweuO->mg6WhuU1vZv();
        goto ZAIf2;
        yLHuU:
        $this->Yid_7 = [];
        goto OYoI1;
        R_i9z:
        $QYMt1['AccelerationSettings']['Mode'] = 'ENABLED';
        goto ZVnI6;
        pNJCG:
        $QYMt1['Queue'] = $this->Z7rc7;
        goto Q20o5;
        ygDim:
        NGKWj:
        goto EDmnr;
        ikfbo:
        foreach ($this->Yid_7 as $QJpOL) {
            $t7jR4['Outputs'][] = $QJpOL->m2GHu5ADPjN();
            usVjY:
        }
        goto ygDim;
        M9O6Y:
        N5wZI:
        goto NnhIc;
        ZAIf2:
        t8NTx:
        goto dT3nH;
        BpdDl:
        throw new \LogicException('You must provide a input file to use');
        goto M9O6Y;
        OYoI1:
        return $QYMt1;
        goto if28S;
        XYPJv:
        unset($QYMt1['Settings']['OutputGroups']);
        goto ko1im;
        Oi1kv:
        $this->aweuO = null;
        goto oR7Ey;
        NnhIc:
        $QYMt1['Settings']['Inputs'] = $this->kRiuL->mggy5IXodjC();
        goto qfKZO;
        Q20o5:
        if ($this->kRiuL) {
            goto N5wZI;
        }
        goto BpdDl;
        qfKZO:
        $t7jR4 = $QYMt1['Settings']['OutputGroups'][0];
        goto XYPJv;
        dT3nH:
        if (!$bKPSG) {
            goto CdM76;
        }
        goto R_i9z;
        bixZB:
        $QYMt1 = (require 'template.php');
        goto fZcGi;
        sYhfr:
        $QYMt1['Settings']['OutputGroups'][] = $t7jR4;
        goto CJ1l3;
        fZcGi:
        $QYMt1['Role'] = $this->FKbnr;
        goto pNJCG;
        ZVnI6:
        CdM76:
        goto Oi1kv;
        if28S:
    }
    public function meN8mEENSn2(bool $bKPSG = false) : string
    {
        try {
            $COI2e = $this->P3dZD->createJob($this->mAfSCPFGuJR($bKPSG));
            return $COI2e->get('Jobs')['Id'];
        } catch (AwsException $p0etA) {
            Log::error('Error creating MediaConvert job: ' . $p0etA->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $p0etA);
        }
    }
}
