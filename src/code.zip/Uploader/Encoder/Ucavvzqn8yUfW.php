<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Ucavvzqn8yUfW
{
    private $tdC9T;
    public function __construct(string $ocbFN, int $TRuAN, int $PfwRv, ?int $k2slg, ?int $vci_g)
    {
        goto EIazf;
        CAEKJ:
        $this->tdC9T['ImageInserter']['InsertableImages'][0]['Width'] = $k2slg;
        goto bjA_k;
        vi0fQ:
        L_AFd:
        goto LcxAk;
        EIazf:
        $this->tdC9T = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $TRuAN, 'ImageY' => $PfwRv, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $ocbFN, 'Opacity' => 35]]]];
        goto ef55_;
        bjA_k:
        $this->tdC9T['ImageInserter']['InsertableImages'][0]['Height'] = $vci_g;
        goto vi0fQ;
        ef55_:
        if (!($k2slg && $vci_g)) {
            goto L_AFd;
        }
        goto CAEKJ;
        LcxAk:
    }
    public function mx3KTArDUbC() : array
    {
        return $this->tdC9T;
    }
}
