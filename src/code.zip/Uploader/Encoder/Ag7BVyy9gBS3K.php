<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Ag7BVyy9gBS3K
{
    private $Lkzkq;
    public function __construct(float $VNFJX, int $oh7uZ, string $Lzn6p)
    {
        goto nLteK;
        VIpxw:
        $JwKxd = max($JwKxd, 1);
        goto A_C2z;
        A_C2z:
        $this->Lkzkq = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $JwKxd]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $Lzn6p]]];
        goto YQdfD;
        nLteK:
        $JwKxd = (int) $VNFJX / $oh7uZ;
        goto VIpxw;
        YQdfD:
    }
    public function madF6UYZmWF() : array
    {
        return $this->Lkzkq;
    }
}
