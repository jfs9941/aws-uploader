<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class VNBPBDslqfoC3
{
    private $b7nH7;
    public function __construct(string $ZBQLb, int $V5pjp, int $lQa3E, ?int $lvh9C, ?int $S3Wk9)
    {
        goto DLfb6;
        DLfb6:
        $this->b7nH7 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $V5pjp, 'ImageY' => $lQa3E, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $ZBQLb, 'Opacity' => 35]]]];
        goto w7MIH;
        w7MIH:
        if (!($lvh9C && $S3Wk9)) {
            goto XAv9m;
        }
        goto flUt9;
        w3lBE:
        $this->b7nH7['ImageInserter']['InsertableImages'][0]['Height'] = $S3Wk9;
        goto Coycb;
        Coycb:
        XAv9m:
        goto bJ_LV;
        flUt9:
        $this->b7nH7['ImageInserter']['InsertableImages'][0]['Width'] = $lvh9C;
        goto w3lBE;
        bJ_LV:
    }
    public function m5KMZKGGUsQ() : array
    {
        return $this->b7nH7;
    }
}
