<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class WJAE7lcMNfE1y
{
    private $zeJHK;
    public function __construct(float $Vg4SG, int $uyc5z, string $OtKpj)
    {
        goto vtN0L;
        Nr9Jr:
        $this->zeJHK = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $lTk8V]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $OtKpj]]];
        goto ouyCU;
        piCbF:
        $lTk8V = max($lTk8V, 1);
        goto Nr9Jr;
        vtN0L:
        $lTk8V = (int) $Vg4SG / $uyc5z;
        goto piCbF;
        ouyCU:
    }
    public function mgDWTJsepR0() : array
    {
        return $this->zeJHK;
    }
}
