<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\JZNnhECD5SO1I;
final class SlIVoKaoiMz2R
{
    private $ZWyON;
    public function __construct(string $TDQmb, ?int $ASgWt, ?int $ybj1g, float $fY2D4)
    {
        goto exWYM;
        JmKSn:
        if (!($ASgWt && $ybj1g)) {
            goto eSaZW;
        }
        goto jFdkn;
        w3Mkr:
        $this->ZWyON['VideoDescription']['Height'] = $ybj1g;
        goto pmkY4;
        exWYM:
        $OKh_W = 15000000;
        goto h18NA;
        RgkNf:
        TIuPe:
        goto oRmsh;
        BAc5d:
        $OKh_W = $this->mhQemMprc9o($ASgWt, $ybj1g, $fY2D4);
        goto RgkNf;
        pmkY4:
        eSaZW:
        goto NX5as;
        h18NA:
        if (!($ASgWt && $ybj1g)) {
            goto TIuPe;
        }
        goto BAc5d;
        oRmsh:
        $this->ZWyON = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $OKh_W, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $TDQmb];
        goto JmKSn;
        jFdkn:
        $this->ZWyON['VideoDescription']['Width'] = $ASgWt;
        goto w3Mkr;
        NX5as:
    }
    public function my9nsBmlsOQ(JZNnhECD5SO1I $qY3RI) : self
    {
        $this->ZWyON['VideoDescription']['VideoPreprocessors'] = $qY3RI->mQnIFDfmU7W();
        return $this;
    }
    public function m0ECWmavCZK() : array
    {
        return $this->ZWyON;
    }
    private function mhQemMprc9o(int $ASgWt, int $ybj1g, float $Ubtbm, string $DDZHK = 'medium', string $MnFB_ = 'h264', string $uys3B = 'good') : ?int
    {
        goto Z6oyE;
        qvyha:
        ig3Bi:
        goto YskpU;
        XPnuI:
        $Ke3CT = 20;
        goto rDLj_;
        EEPyM:
        goto AMSDj;
        goto EUQvt;
        EUQvt:
        nWeOW:
        goto XPnuI;
        z_SHP:
        if ($RtoY4 <= 640 * 480) {
            goto iJaOx;
        }
        goto getKy;
        z1XkB:
        $Ke3CT = 3;
        goto FIFhY;
        DXx21:
        goto AMSDj;
        goto iEAaW;
        jCTiF:
        vR3ri:
        goto wG8dX;
        FIFhY:
        goto AMSDj;
        goto m7bm_;
        lMEWs:
        $Ke3CT = 7;
        goto AmBHi;
        Z6oyE:
        $RtoY4 = $ASgWt * $ybj1g;
        goto z_SHP;
        Oz_0D:
        $eP3Yf = $Ke3CT * ($Ubtbm / 30);
        goto eSLQ2;
        AmBHi:
        goto AMSDj;
        goto K5f3b;
        iEAaW:
        gtLhU:
        goto z1XkB;
        M2LyQ:
        xuAxV:
        goto qvyha;
        gxay9:
        goto AMSDj;
        goto YFMsQ;
        getKy:
        if ($RtoY4 <= 1280 * 720) {
            goto gtLhU;
        }
        goto ixSes;
        rDLj_:
        AMSDj:
        goto Oz_0D;
        L9G56:
        switch (strtolower($uys3B)) {
            case 'low':
                $eP3Yf *= 0.8;
                goto ig3Bi;
            case 'high':
                $eP3Yf *= 1.2;
                goto ig3Bi;
        }
        goto M2LyQ;
        YskpU:
        $eP3Yf = max(0.5, $eP3Yf);
        goto CHFMX;
        uts0N:
        jB6bI:
        goto jCTiF;
        PB9Be:
        if ($RtoY4 <= 3840 * 2160) {
            goto nWeOW;
        }
        goto WB21X;
        PPJZQ:
        if ($RtoY4 <= 2560 * 1440) {
            goto yHy1_;
        }
        goto PB9Be;
        CHFMX:
        return (int) ($eP3Yf * 1000 * 1000);
        goto azo9V;
        i2qOk:
        Dr2uZ:
        goto L9G56;
        WB21X:
        $Ke3CT = 30;
        goto gxay9;
        m7bm_:
        ltY8o:
        goto lMEWs;
        YFMsQ:
        iJaOx:
        goto IN_Nw;
        K5f3b:
        yHy1_:
        goto cmqFm;
        wG8dX:
        if (!('h265' === strtolower($MnFB_) || 'hevc' === strtolower($MnFB_) || 'vp9' === strtolower($MnFB_))) {
            goto Dr2uZ;
        }
        goto EwRvi;
        ixSes:
        if ($RtoY4 <= 1920 * 1080) {
            goto ltY8o;
        }
        goto PPJZQ;
        IN_Nw:
        $Ke3CT = 1.5;
        goto DXx21;
        eSLQ2:
        switch (strtolower($DDZHK)) {
            case 'low':
                $eP3Yf *= 0.7;
                goto vR3ri;
            case 'high':
                $eP3Yf *= 1.3;
                goto vR3ri;
            case 'veryhigh':
                $eP3Yf *= 1.6;
                goto vR3ri;
        }
        goto uts0N;
        EwRvi:
        $eP3Yf *= 0.65;
        goto i2qOk;
        cmqFm:
        $Ke3CT = 12;
        goto EEPyM;
        azo9V:
    }
}
