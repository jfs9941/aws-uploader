<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\BPO1kQM9JvpAH;
use Jfs\Uploader\Encoder\PbrjZTdWh0VlQ;
use Jfs\Uploader\Encoder\M00Y0GeagnFt6;
use Illuminate\Support\Facades\Log;
final class YtOeto201sjfh
{
    private $ahlgm;
    private $PC107;
    private $tM8QU;
    private $g27dF;
    private $oUzkI;
    private $MrC0p;
    private $u4XxL;
    public function __construct(MediaConvertClient $INEFf, $rxhhs, $HSSwM)
    {
        goto D7xqn;
        emxD8:
        $this->oUzkI = $rxhhs;
        goto CY685;
        CY685:
        $this->MrC0p = $HSSwM;
        goto d2UBp;
        D7xqn:
        $this->g27dF = $INEFf;
        goto emxD8;
        d2UBp:
    }
    public function m3qZ37v9mjq() : MediaConvertClient
    {
        return $this->g27dF;
    }
    public function mM7U9bka4qD(M00Y0GeagnFt6 $NGgpN) : self
    {
        $this->ahlgm = $NGgpN;
        return $this;
    }
    public function mekXAnWu5fR(string $suBw_) : self
    {
        $this->tM8QU = $suBw_;
        return $this;
    }
    public function mShL5oBOMms(PbrjZTdWh0VlQ $ZW3Gp) : self
    {
        $this->PC107[] = $ZW3Gp;
        return $this;
    }
    public function mdLrbFP7twl(BPO1kQM9JvpAH $X9APK) : self
    {
        $this->u4XxL = $X9APK;
        return $this;
    }
    private function mFj5OHcdgHZ(bool $W40an) : array
    {
        goto ZY1jG;
        fN75C:
        $drpNa['Settings']['OutputGroups'][] = $this->u4XxL->m35hxQJW42U();
        goto rYw6p;
        oFnWf:
        IVdaf:
        goto HDVbk;
        cJtVs:
        $drpNa['Settings']['Inputs'] = $this->ahlgm->mP9Lq5QuoyF();
        goto sUTOz;
        nCD5p:
        $drpNa['Settings']['OutputGroups'][] = $tvQwg;
        goto fTV7o;
        HDVbk:
        $this->u4XxL = null;
        goto mLQxy;
        v34ZJ:
        $tvQwg['Outputs'] = [];
        goto ui4w0;
        xfYDn:
        unset($drpNa['Settings']['OutputGroups']);
        goto v34ZJ;
        DB_zg:
        R9DHO:
        goto xXpKI;
        ZY1jG:
        $drpNa = (require 'template.php');
        goto SuhSg;
        zYQut:
        throw new \LogicException('You must provide a input file to use');
        goto Q7XJG;
        SuhSg:
        $drpNa['Role'] = $this->oUzkI;
        goto dWFbf;
        K5irW:
        if ($this->ahlgm) {
            goto yYUio;
        }
        goto zYQut;
        Q7XJG:
        yYUio:
        goto cJtVs;
        ui4w0:
        foreach ($this->PC107 as $ZW3Gp) {
            $tvQwg['Outputs'][] = $ZW3Gp->mC0FBEyM5dy();
            VKqmE:
        }
        goto DB_zg;
        sUTOz:
        $tvQwg = $drpNa['Settings']['OutputGroups'][0];
        goto xfYDn;
        YrVZQ:
        $this->PC107 = [];
        goto nlCrD;
        mLQxy:
        $this->ahlgm = null;
        goto YrVZQ;
        xXpKI:
        $tvQwg['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->tM8QU;
        goto nCD5p;
        Xmtlg:
        $drpNa['AccelerationSettings']['Mode'] = 'ENABLED';
        goto oFnWf;
        dWFbf:
        $drpNa['Queue'] = $this->MrC0p;
        goto K5irW;
        rYw6p:
        r8I5Y:
        goto iNrpB;
        fTV7o:
        if (!$this->u4XxL) {
            goto r8I5Y;
        }
        goto fN75C;
        iNrpB:
        if (!$W40an) {
            goto IVdaf;
        }
        goto Xmtlg;
        nlCrD:
        return $drpNa;
        goto W1Kwk;
        W1Kwk:
    }
    public function mlifLdaVPgE(bool $W40an = false) : string
    {
        try {
            $NQsDq = $this->g27dF->createJob($this->mFj5OHcdgHZ($W40an));
            return $NQsDq->get('Job')['Id'];
        } catch (AwsException $VJRSZ) {
            Log::error('Error creating MediaConvert job: ' . $VJRSZ->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $VJRSZ);
        }
    }
}
