<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class NsAe9ORmo3m5D
{
    private $hagmr;
    public function __construct(string $FR8gM, int $D20lY, int $kkrM5, ?int $Sv6q3, ?int $G9pt9)
    {
        goto sUqOI;
        Qrc5Y:
        L3GwR:
        goto VTzAB;
        cGllU:
        if (!($Sv6q3 && $G9pt9)) {
            goto L3GwR;
        }
        goto ufRkb;
        l1ubR:
        $this->hagmr['ImageInserter']['InsertableImages'][0]['Height'] = $G9pt9;
        goto Qrc5Y;
        ufRkb:
        $this->hagmr['ImageInserter']['InsertableImages'][0]['Width'] = $Sv6q3;
        goto l1ubR;
        sUqOI:
        $this->hagmr = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $D20lY, 'ImageY' => $kkrM5, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $FR8gM, 'Opacity' => 35]]]];
        goto cGllU;
        VTzAB:
    }
    public function mJWcLknUvpk() : array
    {
        return $this->hagmr;
    }
}
