<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class ZgVfK3mFV3vr8
{
    private $oMOXS;
    public function __construct(float $ShIKZ, int $NhkwY, string $sWyxW)
    {
        goto HV1dW;
        HV1dW:
        $hg07K = (int) $ShIKZ / $NhkwY;
        goto BJmn1;
        BJmn1:
        $hg07K = max($hg07K, 1);
        goto VYplo;
        VYplo:
        $this->oMOXS = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $hg07K]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $sWyxW]]];
        goto fTaMq;
        fTaMq:
    }
    public function mN4KrajeB1s() : array
    {
        return $this->oMOXS;
    }
}
