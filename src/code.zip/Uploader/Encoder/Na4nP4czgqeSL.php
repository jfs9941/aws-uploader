<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class Na4nP4czgqeSL
{
    private $gIqyK;
    private $UIhgq;
    private $eFUH8;
    private $EHFQ2;
    private $J6ouG;
    private $NFJUa;
    private $FH5aS;
    public function __construct(MediaConvertClient $aiNbP, $RHFNw, $PtClb)
    {
        goto oYOYN;
        ZQiQ_:
        $this->J6ouG = $RHFNw;
        goto pzxaB;
        pzxaB:
        $this->NFJUa = $PtClb;
        goto QL6Bw;
        oYOYN:
        $this->EHFQ2 = $aiNbP;
        goto ZQiQ_;
        QL6Bw:
    }
    public function mLcdGUdLjfu() : MediaConvertClient
    {
        return $this->EHFQ2;
    }
    public function mCEPq8cBaoV(FkO0riWkK3iiD $yeodh) : self
    {
        $this->gIqyK = $yeodh;
        return $this;
    }
    public function mdXrOSrC95W(string $fGlKL) : self
    {
        $this->eFUH8 = $fGlKL;
        return $this;
    }
    public function mz0T9B17Mut(IpF68nxcXPUAb $LA5j0) : self
    {
        $this->UIhgq[] = $LA5j0;
        return $this;
    }
    public function m2jNAxhQ2h6(SlQNgBAeh4N74 $DU5Lh) : self
    {
        $this->FH5aS = $DU5Lh;
        return $this;
    }
    private function m9wHmolZb7V(bool $aY3d1) : array
    {
        goto mUBKQ;
        FjScw:
        unset($zHUQM['Settings']['OutputGroups']);
        goto p_GE9;
        jNjxm:
        $this->FH5aS = null;
        goto ysdn3;
        yy_zg:
        $zHUQM['Settings']['Inputs'] = $this->gIqyK->miFrRhwnGg5();
        goto DHndj;
        VkmlB:
        if (!$this->FH5aS) {
            goto HP7W1;
        }
        goto Z50TF;
        KZ1La:
        $zHUQM['Queue'] = $this->NFJUa;
        goto vdYAc;
        ysdn3:
        $this->gIqyK = null;
        goto ZBYPk;
        BYzKG:
        $zHUQM['Role'] = $this->J6ouG;
        goto KZ1La;
        Z50TF:
        $zHUQM['Settings']['OutputGroups'][] = $this->FH5aS->mrIKlngMt8o();
        goto zVCxK;
        mUBKQ:
        $zHUQM = (require 'template.php');
        goto BYzKG;
        uCXV_:
        $zHUQM['AccelerationSettings']['Mode'] = 'ENABLED';
        goto QlXeN;
        ZBYPk:
        $this->UIhgq = [];
        goto PXL0z;
        HzmZK:
        foreach ($this->UIhgq as $LA5j0) {
            $sMHld['Outputs'][] = $LA5j0->myHWTPdUVPb();
            QBnbA:
        }
        goto xmyd5;
        vdYAc:
        if ($this->gIqyK) {
            goto aUXGK;
        }
        goto dKIuM;
        ObZLd:
        $zHUQM['Settings']['OutputGroups'][] = $sMHld;
        goto VkmlB;
        QlXeN:
        STz7U:
        goto jNjxm;
        p_GE9:
        $sMHld['Outputs'] = [];
        goto HzmZK;
        KLlMj:
        aUXGK:
        goto yy_zg;
        xmyd5:
        WLw1Z:
        goto DMUPb;
        PXL0z:
        return $zHUQM;
        goto IQ_rG;
        DMUPb:
        $sMHld['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->eFUH8;
        goto ObZLd;
        zVCxK:
        HP7W1:
        goto wDgq3;
        wDgq3:
        if (!$aY3d1) {
            goto STz7U;
        }
        goto uCXV_;
        dKIuM:
        throw new \LogicException('You must provide a input file to use');
        goto KLlMj;
        DHndj:
        $sMHld = $zHUQM['Settings']['OutputGroups'][0];
        goto FjScw;
        IQ_rG:
    }
    public function m75n56qlfHB(bool $aY3d1 = false) : string
    {
        try {
            $paaTe = $this->EHFQ2->createJob($this->m9wHmolZb7V($aY3d1));
            return $paaTe->get('Jobs')['Id'];
        } catch (AwsException $mz5ks) {
            Log::error('Error creating MediaConvert job: ' . $mz5ks->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $mz5ks);
        }
    }
}
