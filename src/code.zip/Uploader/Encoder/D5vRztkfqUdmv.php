<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; class D5vRztkfqUdmv { private $m05aI; public function __construct(string $AzYup, int $RLgzU, int $HesWG, ?int $erZ55, ?int $gFN2Z) { goto TbU67; dpjkR: fQj0v: goto IrY17; dreT8: $this->m05aI['ImageInserter']['InsertableImages'][0]['Height'] = $gFN2Z; goto dpjkR; TbU67: $this->m05aI = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $RLgzU, 'ImageY' => $HesWG, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $AzYup, 'Opacity' => 35]]]]; goto Zte2_; ZgvRt: $this->m05aI['ImageInserter']['InsertableImages'][0]['Width'] = $erZ55; goto dreT8; Zte2_: if (!($erZ55 && $gFN2Z)) { goto fQj0v; } goto ZgvRt; IrY17: } public function ma9gxhV8ckm() : array { return $this->m05aI; } }
