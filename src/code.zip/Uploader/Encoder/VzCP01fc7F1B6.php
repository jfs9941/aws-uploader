<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class VzCP01fc7F1B6
{
    private $M1zEY;
    public function __construct(string $i_idL, ?int $vwL5B, ?int $ttadT, float $frJIO)
    {
        goto jhnUe;
        L8g25:
        $this->M1zEY = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $MeFl9, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $i_idL];
        goto bzeiq;
        QmaX7:
        jbh4b:
        goto L8g25;
        TfsfI:
        E_fAq:
        goto QDm2F;
        VKxH8:
        $this->M1zEY['VideoDescription']['Width'] = $vwL5B;
        goto bea4h;
        bea4h:
        $this->M1zEY['VideoDescription']['Height'] = $ttadT;
        goto TfsfI;
        XMvEI:
        $MeFl9 = $this->mo14GCXKTyx($vwL5B, $ttadT, $frJIO);
        goto QmaX7;
        bzeiq:
        if (!($vwL5B && $ttadT)) {
            goto E_fAq;
        }
        goto VKxH8;
        Db9DI:
        if (!($vwL5B && $ttadT)) {
            goto jbh4b;
        }
        goto XMvEI;
        jhnUe:
        $MeFl9 = 15000000;
        goto Db9DI;
        QDm2F:
    }
    public function mHELPZjOMXP(Mk5y6pFXlppNf $Hq1oM) : self
    {
        $this->M1zEY['VideoDescription']['VideoPreprocessors'] = $Hq1oM->meQQw6nXlzV();
        return $this;
    }
    public function m8ipZbbhaRA() : array
    {
        return $this->M1zEY;
    }
    private function mo14GCXKTyx(int $vwL5B, int $ttadT, float $n233M, string $E32Bc = 'medium', string $Ljwq3 = 'h264', string $gVjkF = 'good') : ?int
    {
        goto QmzRm;
        fRE4N:
        lNIdv:
        goto hIPUf;
        Q9pyY:
        PlDEm:
        goto bxaHc;
        xDmmd:
        $rix0H = 20;
        goto L26uT;
        yQF7q:
        goto UEQtr;
        goto OAITp;
        bxaHc:
        $sAe14 = max(0.5, $sAe14);
        goto Q5qMB;
        CAHgu:
        $sAe14 *= 0.65;
        goto kQF1A;
        bPuV0:
        PudUF:
        goto xDmmd;
        JsyLg:
        if (!('h265' === strtolower($Ljwq3) || 'hevc' === strtolower($Ljwq3) || 'vp9' === strtolower($Ljwq3))) {
            goto X24BF;
        }
        goto CAHgu;
        QmzRm:
        $XelNI = $vwL5B * $ttadT;
        goto RPjm6;
        Bxl3D:
        vqIax:
        goto JsyLg;
        vW_WF:
        IfHc6:
        goto Usdk7;
        x3trA:
        goto UEQtr;
        goto vW_WF;
        vp6ua:
        BJSHf:
        goto Bxl3D;
        SJrrE:
        goto UEQtr;
        goto bPuV0;
        hIPUf:
        $rix0H = 12;
        goto SJrrE;
        X9zlX:
        switch (strtolower($gVjkF)) {
            case 'low':
                $sAe14 *= 0.8;
                goto PlDEm;
            case 'high':
                $sAe14 *= 1.2;
                goto PlDEm;
        }
        goto ktABT;
        VRkWZ:
        l9FHJ:
        goto UEzKQ;
        Q5qMB:
        return (int) ($sAe14 * 1000 * 1000);
        goto eIsVA;
        ktABT:
        Grko8:
        goto Q9pyY;
        Oy5nH:
        goto UEQtr;
        goto VRkWZ;
        qHr0J:
        switch (strtolower($E32Bc)) {
            case 'low':
                $sAe14 *= 0.7;
                goto vqIax;
            case 'high':
                $sAe14 *= 1.3;
                goto vqIax;
            case 'veryhigh':
                $sAe14 *= 1.6;
                goto vqIax;
        }
        goto vp6ua;
        Usdk7:
        $rix0H = 3;
        goto Oy5nH;
        L26uT:
        UEQtr:
        goto iMIIC;
        OAITp:
        maZvg:
        goto R3iYX;
        iMIIC:
        $sAe14 = $rix0H * ($n233M / 30);
        goto qHr0J;
        R3iYX:
        $rix0H = 1.5;
        goto x3trA;
        ZYwTO:
        if ($XelNI <= 2560 * 1440) {
            goto lNIdv;
        }
        goto UgZty;
        kQF1A:
        X24BF:
        goto X9zlX;
        LGjgg:
        $rix0H = 30;
        goto yQF7q;
        UEzKQ:
        $rix0H = 7;
        goto djheU;
        UgZty:
        if ($XelNI <= 3840 * 2160) {
            goto PudUF;
        }
        goto LGjgg;
        sgkAH:
        if ($XelNI <= 1920 * 1080) {
            goto l9FHJ;
        }
        goto ZYwTO;
        djheU:
        goto UEQtr;
        goto fRE4N;
        RPjm6:
        if ($XelNI <= 640 * 480) {
            goto maZvg;
        }
        goto A6AGS;
        A6AGS:
        if ($XelNI <= 1280 * 720) {
            goto IfHc6;
        }
        goto sgkAH;
        eIsVA:
    }
}
