<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class JCn5h7b7KyFNK
{
    private $CkXYM;
    public function __construct(string $SrpMp, ?int $NixDl, ?int $l4GK0, float $Ly5G5)
    {
        goto n_1vo;
        E4LPS:
        if (!($NixDl && $l4GK0)) {
            goto LKXSJ;
        }
        goto kZuOY;
        ABnvQ:
        dJ6LH:
        goto Y9LFi;
        kZuOY:
        $this->CkXYM['VideoDescription']['Width'] = $NixDl;
        goto R0pma;
        Y9LFi:
        $this->CkXYM = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $nEHfC, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $SrpMp];
        goto E4LPS;
        zhZ1n:
        if (!($NixDl && $l4GK0)) {
            goto dJ6LH;
        }
        goto qhPYL;
        UzJif:
        LKXSJ:
        goto LFFAs;
        R0pma:
        $this->CkXYM['VideoDescription']['Height'] = $l4GK0;
        goto UzJif;
        n_1vo:
        $nEHfC = 15000000;
        goto zhZ1n;
        qhPYL:
        $nEHfC = $this->mBdJF8KuQnf($NixDl, $l4GK0, $Ly5G5);
        goto ABnvQ;
        LFFAs:
    }
    public function mVNeRFmQ4o0(CxY28u9r8wEQP $HNsWT) : self
    {
        $this->CkXYM['VideoDescription']['VideoPreprocessors'] = $HNsWT->m3KkEYLjtno();
        return $this;
    }
    public function mxLsNpCJJ2G() : array
    {
        return $this->CkXYM;
    }
    private function mBdJF8KuQnf(int $NixDl, int $l4GK0, float $xRLJI, string $VDYPA = 'medium', string $ANWv0 = 'h264', string $NxeXg = 'good') : ?int
    {
        goto opfEA;
        pqsGH:
        $pWx4e = max(0.5, $pWx4e);
        goto qkQ2n;
        b8nTY:
        if ($NvXSr <= 1280 * 720) {
            goto PbRJA;
        }
        goto RkYRA;
        qRCi9:
        sW6KL:
        goto QcExs;
        xXeyQ:
        OiDqv:
        goto OzEjD;
        DO90h:
        goto XTfAV;
        goto VhfxU;
        qE3QB:
        $ooXMT = 3;
        goto v1GER;
        ZZKik:
        if ($NvXSr <= 2560 * 1440) {
            goto urPwl;
        }
        goto bVYAm;
        b0yng:
        goto XTfAV;
        goto qRCi9;
        opfEA:
        $NvXSr = $NixDl * $l4GK0;
        goto t0RAY;
        vd9XL:
        $ooXMT = 12;
        goto b0yng;
        T6Svu:
        $pWx4e = $ooXMT * ($xRLJI / 30);
        goto iBPhQ;
        t0RAY:
        if ($NvXSr <= 640 * 480) {
            goto PlwLG;
        }
        goto b8nTY;
        qkQ2n:
        return (int) ($pWx4e * 1000 * 1000);
        goto SFlnU;
        VhfxU:
        urPwl:
        goto vd9XL;
        TuMsD:
        E7LM9:
        goto MOk9K;
        HWABG:
        if (!('h265' === strtolower($ANWv0) || 'hevc' === strtolower($ANWv0) || 'vp9' === strtolower($ANWv0))) {
            goto OiDqv;
        }
        goto WS2oO;
        aLgZS:
        PlwLG:
        goto PvGNm;
        mrSSS:
        PbRJA:
        goto qE3QB;
        GifZK:
        goto XTfAV;
        goto aLgZS;
        RkYRA:
        if ($NvXSr <= 1920 * 1080) {
            goto m6PE1;
        }
        goto ZZKik;
        eyRhH:
        xZexh:
        goto pqsGH;
        yUZX8:
        $ooXMT = 7;
        goto DO90h;
        v1GER:
        goto XTfAV;
        goto wcGFZ;
        Z9H6h:
        XTfAV:
        goto T6Svu;
        WS2oO:
        $pWx4e *= 0.65;
        goto xXeyQ;
        bVYAm:
        if ($NvXSr <= 3840 * 2160) {
            goto sW6KL;
        }
        goto P1qMJ;
        P1qMJ:
        $ooXMT = 30;
        goto GifZK;
        dZm60:
        Y6W7a:
        goto eyRhH;
        wcGFZ:
        m6PE1:
        goto yUZX8;
        ujnG3:
        goto XTfAV;
        goto mrSSS;
        OzEjD:
        switch (strtolower($NxeXg)) {
            case 'low':
                $pWx4e *= 0.8;
                goto xZexh;
            case 'high':
                $pWx4e *= 1.2;
                goto xZexh;
        }
        goto dZm60;
        MOk9K:
        vnO2c:
        goto HWABG;
        PvGNm:
        $ooXMT = 1.5;
        goto ujnG3;
        QcExs:
        $ooXMT = 20;
        goto Z9H6h;
        iBPhQ:
        switch (strtolower($VDYPA)) {
            case 'low':
                $pWx4e *= 0.7;
                goto vnO2c;
            case 'high':
                $pWx4e *= 1.3;
                goto vnO2c;
            case 'veryhigh':
                $pWx4e *= 1.6;
                goto vnO2c;
        }
        goto TuMsD;
        SFlnU:
    }
}
