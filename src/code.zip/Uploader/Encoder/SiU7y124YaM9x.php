<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class SiU7y124YaM9x
{
    private $uZTRG;
    public function __construct(string $bSGKV, int $qQp_P, int $cQUW2, ?int $Un71V, ?int $aHbCv)
    {
        goto vsXik;
        ZOUIp:
        $this->uZTRG['ImageInserter']['InsertableImages'][0]['Height'] = $aHbCv;
        goto d0D5D;
        vsXik:
        $this->uZTRG = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $qQp_P, 'ImageY' => $cQUW2, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $bSGKV, 'Opacity' => 35]]]];
        goto UZY68;
        d0D5D:
        ZRhzM:
        goto TH43y;
        UZY68:
        if (!($Un71V && $aHbCv)) {
            goto ZRhzM;
        }
        goto OD7Il;
        OD7Il:
        $this->uZTRG['ImageInserter']['InsertableImages'][0]['Width'] = $Un71V;
        goto ZOUIp;
        TH43y:
    }
    public function mEKAMW2QZn7() : array
    {
        return $this->uZTRG;
    }
}
