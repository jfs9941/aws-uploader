<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class R8oCerQxKXZb6
{
    private $XgoXf;
    public function __construct(string $UzDam, int $MLewY, int $JZK5m, ?int $qFAp6, ?int $bxUTl)
    {
        goto QWXPq;
        QWXPq:
        $this->XgoXf = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $MLewY, 'ImageY' => $JZK5m, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $UzDam, 'Opacity' => 35]]]];
        goto tTti1;
        CNWYj:
        TnLPq:
        goto mE3f1;
        tTti1:
        if (!($qFAp6 && $bxUTl)) {
            goto TnLPq;
        }
        goto f1ZVq;
        Ue3Mo:
        $this->XgoXf['ImageInserter']['InsertableImages'][0]['Height'] = $bxUTl;
        goto CNWYj;
        f1ZVq:
        $this->XgoXf['ImageInserter']['InsertableImages'][0]['Width'] = $qFAp6;
        goto Ue3Mo;
        mE3f1:
    }
    public function m2bsyqh60tG() : array
    {
        return $this->XgoXf;
    }
}
