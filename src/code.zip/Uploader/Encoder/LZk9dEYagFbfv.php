<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Service\HgXaT629cXC5e;
use Illuminate\Contracts\Filesystem\Filesystem;
final class LZk9dEYagFbfv
{
    public const Y6lbP = 'v2/hls/';
    private $TjOHk;
    private $kEfMA;
    public function __construct(HgXaT629cXC5e $oelhj, Filesystem $FP6ih)
    {
        $this->TjOHk = $oelhj;
        $this->kEfMA = $FP6ih;
    }
    public function mUmeTTXTore($L2Ff8) : string
    {
        return $this->TjOHk->m9W44hJCIbw(self::Y6lbP . $L2Ff8->getAttribute('id') . '/');
    }
    public function mmYGSg1QZVV($L2Ff8) : string
    {
        return $this->TjOHk->m9W44hJCIbw(self::Y6lbP . $L2Ff8->getAttribute('id') . '/thumbnail/');
    }
    public function morZHWDrmhK($L2Ff8, $BT3pe = true) : string
    {
        goto tLHTf;
        tLHTf:
        if ($BT3pe) {
            goto grg6f;
        }
        goto bAzV2;
        CX29I:
        return $this->TjOHk->m9W44hJCIbw(self::Y6lbP . $L2Ff8->getAttribute('id') . '/' . $L2Ff8->getAttribute('id') . '.m3u8');
        goto tTWWW;
        bAzV2:
        return self::Y6lbP . $L2Ff8->getAttribute('id') . '/' . $L2Ff8->getAttribute('id') . '.m3u8';
        goto M0SU4;
        M0SU4:
        grg6f:
        goto CX29I;
        tTWWW:
    }
    public function resolveThumbnail($L2Ff8) : string
    {
        goto y4GIG;
        y4GIG:
        $EQQae = $L2Ff8->getAttribute('id');
        goto YvXrq;
        YvXrq:
        $w37Ul = $this->kEfMA->files($this->mmYGSg1QZVV($L2Ff8));
        goto H_RUS;
        H_RUS:
        return 1 == count($w37Ul) ? self::Y6lbP . $EQQae . '/thumbnail/' . $EQQae . '.0000000.jpg' : self::Y6lbP . $EQQae . '/thumbnail/' . $EQQae . '.0000001.jpg';
        goto rnGaJ;
        rnGaJ:
    }
    public function mj84CZLyu9H(string $KPnwr) : string
    {
        return $this->kEfMA->url($KPnwr);
    }
}
