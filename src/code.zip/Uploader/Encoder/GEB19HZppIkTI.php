<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\SiU7y124YaM9x;
final class GEB19HZppIkTI
{
    private $lcVBY;
    public function __construct(string $H4BMA, ?int $Un71V, ?int $aHbCv, float $wlttu)
    {
        goto GXytr;
        SIQ46:
        $vySHm = $this->m7nvp3zCfnJ($Un71V, $aHbCv, $wlttu);
        goto WMPCi;
        a7pBl:
        qX8PP:
        goto wpQ1U;
        ltq4z:
        if (!($Un71V && $aHbCv)) {
            goto qX8PP;
        }
        goto Duw86;
        gukk7:
        $this->lcVBY['VideoDescription']['Height'] = $aHbCv;
        goto a7pBl;
        GXytr:
        $vySHm = 15000000;
        goto GAV44;
        GAV44:
        if (!($Un71V && $aHbCv)) {
            goto HNnsv;
        }
        goto SIQ46;
        VbGf3:
        $this->lcVBY = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $vySHm, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $H4BMA];
        goto ltq4z;
        WMPCi:
        HNnsv:
        goto VbGf3;
        Duw86:
        $this->lcVBY['VideoDescription']['Width'] = $Un71V;
        goto gukk7;
        wpQ1U:
    }
    public function mo647wo27ir(SiU7y124YaM9x $cWYFB) : self
    {
        $this->lcVBY['VideoDescription']['VideoPreprocessors'] = $cWYFB->mEKAMW2QZn7();
        return $this;
    }
    public function mbneImfsfOH() : array
    {
        return $this->lcVBY;
    }
    private function m7nvp3zCfnJ(int $Un71V, int $aHbCv, float $tYLrC, string $qI_Fj = 'medium', string $IA9mI = 'h264', string $Hn_5p = 'good') : ?int
    {
        goto oW4cF;
        P6B4q:
        goto KK_FP;
        goto aPi57;
        swe2Y:
        goto KK_FP;
        goto aYuLK;
        HdJpI:
        $iOHX5 = $cuETq * ($tYLrC / 30);
        goto Ys3l2;
        Gi3dy:
        XfFaB:
        goto WCubi;
        PZiuH:
        if ($zi0te <= 640 * 480) {
            goto G0h72;
        }
        goto h38gx;
        aPi57:
        JPH6Q:
        goto kz0qV;
        J5k7g:
        $cuETq = 7;
        goto swe2Y;
        rVzPm:
        mMCU_:
        goto TEsdH;
        qtYbo:
        kC_vU:
        goto J5k7g;
        fBsmG:
        if ($zi0te <= 3840 * 2160) {
            goto JPH6Q;
        }
        goto TXfQu;
        iMObn:
        $cuETq = 3;
        goto rhxed;
        Ys3l2:
        switch (strtolower($qI_Fj)) {
            case 'low':
                $iOHX5 *= 0.7;
                goto G1QhF;
            case 'high':
                $iOHX5 *= 1.3;
                goto G1QhF;
            case 'veryhigh':
                $iOHX5 *= 1.6;
                goto G1QhF;
        }
        goto rVzPm;
        aUzVE:
        G0h72:
        goto mpCQw;
        oW4cF:
        $zi0te = $Un71V * $aHbCv;
        goto PZiuH;
        I0Jes:
        goto KK_FP;
        goto LS_2B;
        zWWn3:
        $cuETq = 12;
        goto P6B4q;
        TEsdH:
        G1QhF:
        goto BjlUZ;
        BjlUZ:
        if (!('h265' === strtolower($IA9mI) || 'hevc' === strtolower($IA9mI) || 'vp9' === strtolower($IA9mI))) {
            goto jrSdV;
        }
        goto ovB2v;
        mpCQw:
        $cuETq = 1.5;
        goto I0Jes;
        T854r:
        $iOHX5 = max(0.5, $iOHX5);
        goto ob8Vu;
        IB2Qh:
        KK_FP:
        goto HdJpI;
        WCubi:
        Dv8S9:
        goto T854r;
        ovB2v:
        $iOHX5 *= 0.65;
        goto i5cIw;
        dKPCu:
        goto KK_FP;
        goto aUzVE;
        i5cIw:
        jrSdV:
        goto YMUli;
        y3PZf:
        if ($zi0te <= 2560 * 1440) {
            goto LRvi7;
        }
        goto fBsmG;
        TXfQu:
        $cuETq = 30;
        goto dKPCu;
        YMUli:
        switch (strtolower($Hn_5p)) {
            case 'low':
                $iOHX5 *= 0.8;
                goto Dv8S9;
            case 'high':
                $iOHX5 *= 1.2;
                goto Dv8S9;
        }
        goto Gi3dy;
        rhxed:
        goto KK_FP;
        goto qtYbo;
        LS_2B:
        cKIBh:
        goto iMObn;
        kz0qV:
        $cuETq = 20;
        goto IB2Qh;
        aYuLK:
        LRvi7:
        goto zWWn3;
        GpuIG:
        if ($zi0te <= 1920 * 1080) {
            goto kC_vU;
        }
        goto y3PZf;
        ob8Vu:
        return (int) ($iOHX5 * 1000 * 1000);
        goto tqD2c;
        h38gx:
        if ($zi0te <= 1280 * 720) {
            goto cKIBh;
        }
        goto GpuIG;
        tqD2c:
    }
}
