<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Service\NzkrkFhIBihmO;
final class Saum77EIMVl09
{
    public const M3YHk = 'v2/hls/';
    private $IRR6l;
    private $GQuun;
    public function __construct(NzkrkFhIBihmO $ggIs8, Filesystem $Q0shJ)
    {
        $this->IRR6l = $ggIs8;
        $this->GQuun = $Q0shJ;
    }
    public function m3AjunF2pKL($DuZ1o) : string
    {
        return $this->IRR6l->mam0y8xjZWF(self::M3YHk . $DuZ1o->getAttribute('id') . '/');
    }
    public function m7iW1If9qU3($DuZ1o) : string
    {
        return $this->IRR6l->mam0y8xjZWF(self::M3YHk . $DuZ1o->getAttribute('id') . '/thumbnail/');
    }
    public function m8hjocS3Ndp($DuZ1o, $VqriH = true) : string
    {
        goto rtMMB;
        GaYHS:
        return $this->IRR6l->mam0y8xjZWF(self::M3YHk . $DuZ1o->getAttribute('id') . '/' . $DuZ1o->getAttribute('id') . '.m3u8');
        goto dyeoX;
        rtMMB:
        if ($VqriH) {
            goto UL2Tk;
        }
        goto F0Dzf;
        vFB8g:
        UL2Tk:
        goto GaYHS;
        F0Dzf:
        return self::M3YHk . $DuZ1o->getAttribute('id') . '/' . $DuZ1o->getAttribute('id') . '.m3u8';
        goto vFB8g;
        dyeoX:
    }
    public function resolveThumbnail($DuZ1o) : string
    {
        goto Vmpbu;
        ra8V6:
        return 1 == count($LJkda) ? self::M3YHk . $eXur0 . '/thumbnail/' . $eXur0 . '.0000000.jpg' : self::M3YHk . $eXur0 . '/thumbnail/' . $eXur0 . '.0000001.jpg';
        goto gMJeb;
        hbSPl:
        $LJkda = $this->GQuun->files($this->m7iW1If9qU3($DuZ1o));
        goto ra8V6;
        Vmpbu:
        $eXur0 = $DuZ1o->getAttribute('id');
        goto hbSPl;
        gMJeb:
    }
    public function mpUvJfqvMNx(string $Y7TgX) : string
    {
        return $this->GQuun->url($Y7TgX);
    }
}
