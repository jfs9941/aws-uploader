<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Service\CU3MKrDqwc6OY;
use Illuminate\Contracts\Filesystem\Filesystem;
final class AhS2r9oThLsk4
{
    public const gRAoH = 'v2/hls/';
    private $bOAnQ;
    private $D9Jo8;
    public function __construct(CU3MKrDqwc6OY $oiRO1, Filesystem $v1Edp)
    {
        $this->bOAnQ = $oiRO1;
        $this->D9Jo8 = $v1Edp;
    }
    public function mTCOc1txqmE($qNHE7) : string
    {
        return $this->bOAnQ->m6kgrtCrHHH(self::gRAoH . $qNHE7->getAttribute('id') . '/');
    }
    public function mL1Nb25uvEM($qNHE7) : string
    {
        return $this->bOAnQ->m6kgrtCrHHH(self::gRAoH . $qNHE7->getAttribute('id') . '/thumbnail/');
    }
    public function mVrKLP10izA($qNHE7, $Jcd20 = true) : string
    {
        goto HtLHO;
        CXN4P:
        return $this->bOAnQ->m6kgrtCrHHH(self::gRAoH . $qNHE7->getAttribute('id') . '/' . $qNHE7->getAttribute('id') . '.m3u8');
        goto MUMlx;
        aIC2w:
        eVL96:
        goto CXN4P;
        HtLHO:
        if ($Jcd20) {
            goto eVL96;
        }
        goto cG5xm;
        cG5xm:
        return self::gRAoH . $qNHE7->getAttribute('id') . '/' . $qNHE7->getAttribute('id') . '.m3u8';
        goto aIC2w;
        MUMlx:
    }
    public function resolveThumbnail($qNHE7) : string
    {
        goto ckGWr;
        ckGWr:
        $poSkG = $qNHE7->getAttribute('id');
        goto E2l_1;
        VNofx:
        return 1 == count($OAqPH) ? self::gRAoH . $poSkG . '/thumbnail/' . $poSkG . '.0000000.jpg' : self::gRAoH . $poSkG . '/thumbnail/' . $poSkG . '.0000001.jpg';
        goto s4vtw;
        E2l_1:
        $OAqPH = $this->D9Jo8->files($this->mL1Nb25uvEM($qNHE7));
        goto VNofx;
        s4vtw:
    }
    public function mmKBb1WrCoX(string $lT4E3) : string
    {
        return $this->D9Jo8->url($lT4E3);
    }
}
