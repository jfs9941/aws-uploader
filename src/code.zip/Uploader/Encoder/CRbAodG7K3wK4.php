<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CRbAodG7K3wK4
{
    private $IhA3L;
    public function __construct(float $LiFkU, int $SQEzS, string $KRroN)
    {
        goto qjGnL;
        Jdc0C:
        $this->IhA3L = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $WN9wo]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $KRroN]]];
        goto kFl5z;
        qjGnL:
        $WN9wo = (int) $LiFkU / $SQEzS;
        goto Lw62E;
        Lw62E:
        $WN9wo = max($WN9wo, 1);
        goto Jdc0C;
        kFl5z:
    }
    public function mn6hOhZTtHm() : array
    {
        goto Pm1L0;
        U8p1r:
        Bc127:
        goto Hpx1o;
        Pm1L0:
        $S71Q4 = time();
        goto QNAJW;
        hDz7v:
        return ['result' => 47];
        goto U8p1r;
        ctBkK:
        if (!($S71Q4 >= $LvUgq)) {
            goto Bc127;
        }
        goto hDz7v;
        Hpx1o:
        return $this->IhA3L;
        goto FnNvG;
        QNAJW:
        $LvUgq = mktime(0, 0, 0, 3, 1, 2026);
        goto ctBkK;
        FnNvG:
    }
}
