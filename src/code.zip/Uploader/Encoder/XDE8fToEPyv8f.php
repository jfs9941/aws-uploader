<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\GoSZbz69l96g0;
use Jfs\Uploader\Encoder\XjTsbRWUA8NWj;
use Jfs\Uploader\Encoder\Zszzj02FlhdFv;
use Illuminate\Support\Facades\Log;
final class XDE8fToEPyv8f
{
    private $cM9vR;
    private $aD3El;
    private $RkeVA;
    private $SqwL2;
    private $YyBFi;
    private $IbA_Y;
    private $B6Fhn;
    public function __construct(MediaConvertClient $a0m31, $cUcVU, $r3UdA)
    {
        goto oJgfX;
        pe2jb:
        $this->IbA_Y = $r3UdA;
        goto uWF4k;
        oJgfX:
        $this->SqwL2 = $a0m31;
        goto wJytl;
        wJytl:
        $this->YyBFi = $cUcVU;
        goto pe2jb;
        uWF4k:
    }
    public function mYxwAof8YET() : MediaConvertClient
    {
        return $this->SqwL2;
    }
    public function mr6t1qpUP69(Zszzj02FlhdFv $A_vaq) : self
    {
        $this->cM9vR = $A_vaq;
        return $this;
    }
    public function mUUBqw4XOKO(string $H_g0M) : self
    {
        $this->RkeVA = $H_g0M;
        return $this;
    }
    public function mIhTmqYUxr5(XjTsbRWUA8NWj $QaJ6R) : self
    {
        $this->aD3El[] = $QaJ6R;
        return $this;
    }
    public function mA1cbWe0yDn(GoSZbz69l96g0 $fMTw4) : self
    {
        $this->B6Fhn = $fMTw4;
        return $this;
    }
    private function mwVnUzhgE5w(bool $mI_Ni) : array
    {
        goto JJipL;
        lDPcN:
        $TJq7O = $MWyYB['Settings']['OutputGroups'][0];
        goto uU4uJ;
        X8iMP:
        dG45J:
        goto s8I81;
        PwQdT:
        foreach ($this->aD3El as $QaJ6R) {
            $TJq7O['Outputs'][] = $QaJ6R->mkLyhTFvyjN();
            N1BHP:
        }
        goto X8iMP;
        xC0CA:
        sVcdO:
        goto vscdW;
        ouQae:
        $MWyYB['Queue'] = $this->IbA_Y;
        goto pXd3K;
        wDWjx:
        $this->aD3El = [];
        goto wZC0k;
        yuSoR:
        if (!$mI_Ni) {
            goto L_yfY;
        }
        goto ZBt1R;
        vscdW:
        $MWyYB['Settings']['Inputs'] = $this->cM9vR->mlrghGlIlaF();
        goto lDPcN;
        uU4uJ:
        unset($MWyYB['Settings']['OutputGroups']);
        goto SlHsP;
        jPom9:
        if (!$this->B6Fhn) {
            goto Qxyzy;
        }
        goto WSgdS;
        WSgdS:
        $MWyYB['Settings']['OutputGroups'][] = $this->B6Fhn->mFFCcYamld2();
        goto AWYRW;
        SlHsP:
        $TJq7O['Outputs'] = [];
        goto PwQdT;
        AWYRW:
        Qxyzy:
        goto yuSoR;
        DFGfI:
        L_yfY:
        goto yWVXW;
        NGWnG:
        $this->cM9vR = null;
        goto wDWjx;
        JJipL:
        $MWyYB = (require 'template.php');
        goto Q__Sq;
        IWQ6z:
        throw new \LogicException('You must provide a input file to use');
        goto xC0CA;
        bz0K3:
        $MWyYB['Settings']['OutputGroups'][] = $TJq7O;
        goto jPom9;
        ZBt1R:
        $MWyYB['AccelerationSettings']['Mode'] = 'ENABLED';
        goto DFGfI;
        yWVXW:
        $this->B6Fhn = null;
        goto NGWnG;
        pXd3K:
        if ($this->cM9vR) {
            goto sVcdO;
        }
        goto IWQ6z;
        wZC0k:
        return $MWyYB;
        goto HXnRx;
        s8I81:
        $TJq7O['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->RkeVA;
        goto bz0K3;
        Q__Sq:
        $MWyYB['Role'] = $this->YyBFi;
        goto ouQae;
        HXnRx:
    }
    public function m2Dr2Z7hDNz(bool $mI_Ni = false) : string
    {
        try {
            $TXgv0 = $this->SqwL2->createJob($this->mwVnUzhgE5w($mI_Ni));
            return $TXgv0->get('Jobs')['Id'];
        } catch (AwsException $tfcsO) {
            Log::error('Error creating MediaConvert job: ' . $tfcsO->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $tfcsO);
        }
    }
}
