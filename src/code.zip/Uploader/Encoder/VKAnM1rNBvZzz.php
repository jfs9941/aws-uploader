<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class VKAnM1rNBvZzz
{
    private $gD3e6;
    public function __construct(string $jTMW2, int $EYYRc, int $Sbkjh, ?int $GPsTK, ?int $ldQdP)
    {
        goto D6x_z;
        S35AB:
        if (!($GPsTK && $ldQdP)) {
            goto Idb_t;
        }
        goto mXPHD;
        AP2Hk:
        Idb_t:
        goto h6fZ5;
        vIWOn:
        $this->gD3e6['ImageInserter']['InsertableImages'][0]['Height'] = $ldQdP;
        goto AP2Hk;
        mXPHD:
        $this->gD3e6['ImageInserter']['InsertableImages'][0]['Width'] = $GPsTK;
        goto vIWOn;
        D6x_z:
        $this->gD3e6 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $EYYRc, 'ImageY' => $Sbkjh, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $jTMW2, 'Opacity' => 35]]]];
        goto S35AB;
        h6fZ5:
    }
    public function mJqY3YRl8fG() : array
    {
        return $this->gD3e6;
    }
}
