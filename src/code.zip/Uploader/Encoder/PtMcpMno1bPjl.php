<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\ONqwzbh5EX8u2;
use Jfs\Uploader\Encoder\AjEME9FDV5xPI;
use Jfs\Uploader\Encoder\QUORU8TxE6XQu;
use Illuminate\Support\Facades\Log;
final class PtMcpMno1bPjl
{
    private $S66tZ;
    private $K2ua3;
    private $qkCqA;
    private $Nk83x;
    private $Rsw96;
    private $h4HbM;
    private $k7emd;
    public function __construct(MediaConvertClient $IylFH, $MN4IO, $nn7JC)
    {
        goto sSg09;
        cZg74:
        $this->h4HbM = $nn7JC;
        goto J37f5;
        sSg09:
        $this->Nk83x = $IylFH;
        goto p_R0N;
        p_R0N:
        $this->Rsw96 = $MN4IO;
        goto cZg74;
        J37f5:
    }
    public function mKkGdl98Spa() : MediaConvertClient
    {
        return $this->Nk83x;
    }
    public function mwJZxnrBZaN(QUORU8TxE6XQu $yUBbs) : self
    {
        $this->S66tZ = $yUBbs;
        return $this;
    }
    public function mN1B3PvsfLM(string $QPN5j) : self
    {
        $this->qkCqA = $QPN5j;
        return $this;
    }
    public function mMpjMmgh5Yd(AjEME9FDV5xPI $Lpspr) : self
    {
        $this->K2ua3[] = $Lpspr;
        return $this;
    }
    public function mrbOORmqO7u(ONqwzbh5EX8u2 $weLf2) : self
    {
        $this->k7emd = $weLf2;
        return $this;
    }
    private function mnk6U3t3DEV(bool $EYq9l) : array
    {
        goto lX4Hg;
        AGVNL:
        if (!$EYq9l) {
            goto Ej_w7;
        }
        goto Rt0rI;
        SrxVI:
        if (!$this->k7emd) {
            goto pGcOu;
        }
        goto EGZnF;
        YrjoH:
        DYAxR:
        goto Md1qz;
        n806E:
        pGcOu:
        goto AGVNL;
        HTaie:
        $this->K2ua3 = [];
        goto joB1T;
        F3unD:
        $this->S66tZ = null;
        goto HTaie;
        UGGYd:
        throw new \LogicException('You must provide a input file to use');
        goto YrjoH;
        M_NHv:
        $Hq9oe = $bi5mE['Settings']['OutputGroups'][0];
        goto mhSXG;
        rIZSh:
        $bi5mE['Queue'] = $this->h4HbM;
        goto Z3CKU;
        EGZnF:
        $bi5mE['Settings']['OutputGroups'][] = $this->k7emd->mi1XNSFgzJs();
        goto n806E;
        joB1T:
        return $bi5mE;
        goto fgHdD;
        oLKSZ:
        $bi5mE['Role'] = $this->Rsw96;
        goto rIZSh;
        sBWQu:
        foreach ($this->K2ua3 as $Lpspr) {
            $Hq9oe['Outputs'][] = $Lpspr->mbjNEvvpqDj();
            L9GCX:
        }
        goto P0BjO;
        mhSXG:
        unset($bi5mE['Settings']['OutputGroups']);
        goto uBbxg;
        Rt0rI:
        $bi5mE['AccelerationSettings']['Mode'] = 'ENABLED';
        goto QGhEI;
        P0BjO:
        dxEft:
        goto af7vL;
        imxIM:
        $this->k7emd = null;
        goto F3unD;
        Z3CKU:
        if ($this->S66tZ) {
            goto DYAxR;
        }
        goto UGGYd;
        Md1qz:
        $bi5mE['Settings']['Inputs'] = $this->S66tZ->mOph45Iy4gq();
        goto M_NHv;
        tjsXh:
        $bi5mE['Settings']['OutputGroups'][] = $Hq9oe;
        goto SrxVI;
        QGhEI:
        Ej_w7:
        goto imxIM;
        af7vL:
        $Hq9oe['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->qkCqA;
        goto tjsXh;
        uBbxg:
        $Hq9oe['Outputs'] = [];
        goto sBWQu;
        lX4Hg:
        $bi5mE = (require 'template.php');
        goto oLKSZ;
        fgHdD:
    }
    public function mWujk7mYe9B(bool $EYq9l = false) : string
    {
        try {
            $KJZOG = $this->Nk83x->createJob($this->mnk6U3t3DEV($EYq9l));
            return $KJZOG->get('Jobs')['Id'];
        } catch (AwsException $kE48F) {
            Log::error('Error creating MediaConvert job: ' . $kE48F->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $kE48F);
        }
    }
}
