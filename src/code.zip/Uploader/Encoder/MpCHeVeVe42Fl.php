<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class MpCHeVeVe42Fl
{
    private $xC5r_;
    public function __construct(float $Um4xl, int $IUsYe, string $v0H_s)
    {
        goto nf9q3;
        Dgfgl:
        $this->xC5r_ = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $R_CEJ]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $v0H_s]]];
        goto uC4lV;
        jMzPo:
        $R_CEJ = max($R_CEJ, 1);
        goto Dgfgl;
        nf9q3:
        $R_CEJ = (int) $Um4xl / $IUsYe;
        goto jMzPo;
        uC4lV:
    }
    public function my7hpR240Lv() : array
    {
        return $this->xC5r_;
    }
}
