<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CoZlTEDusQdM7
{
    private $bcO9d;
    public function __construct(float $CZyuP, int $OWbmr, string $LPZmP)
    {
        goto qC_mH;
        qC_mH:
        $Pe80K = (int) $CZyuP / $OWbmr;
        goto uVKiw;
        tNrNV:
        $this->bcO9d = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $Pe80K]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $LPZmP]]];
        goto L9Sq2;
        uVKiw:
        $Pe80K = max($Pe80K, 1);
        goto tNrNV;
        L9Sq2:
    }
    public function mTsIKwleqJO() : array
    {
        return $this->bcO9d;
    }
}
