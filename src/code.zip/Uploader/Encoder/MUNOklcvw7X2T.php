<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\CQtYwlDJg3DU8;
use Jfs\Uploader\Encoder\T1BQgatbMpEau;
use Jfs\Uploader\Encoder\S3pSMlpyA7cu9;
use Illuminate\Support\Facades\Log;
final class MUNOklcvw7X2T
{
    private $qIJNv;
    private $I8T9h;
    private $NFhLB;
    private $s2s_t;
    private $DyII5;
    private $UVTja;
    private $r3OVR;
    public function __construct(MediaConvertClient $pYrvM, $Ng1oE, $otQ1_)
    {
        goto f7vj5;
        f7vj5:
        $this->s2s_t = $pYrvM;
        goto FMQxL;
        N7iXL:
        $this->UVTja = $otQ1_;
        goto Fcldm;
        FMQxL:
        $this->DyII5 = $Ng1oE;
        goto N7iXL;
        Fcldm:
    }
    public function m3hBgOJMZRn() : MediaConvertClient
    {
        return $this->s2s_t;
    }
    public function mqOy77vTjcl(S3pSMlpyA7cu9 $zYgfw) : self
    {
        $this->qIJNv = $zYgfw;
        return $this;
    }
    public function mq6otmNgdyR(string $l9Oby) : self
    {
        $this->NFhLB = $l9Oby;
        return $this;
    }
    public function mSYOhWTD4Da(T1BQgatbMpEau $PmsUO) : self
    {
        $this->I8T9h[] = $PmsUO;
        return $this;
    }
    public function mOZPZtQYDfS(CQtYwlDJg3DU8 $saBWi) : self
    {
        $this->r3OVR = $saBWi;
        return $this;
    }
    private function mQbk9hcKCHB(bool $enFOP) : array
    {
        goto HAEK0;
        RG_Nj:
        r4Dnq:
        goto Mquwx;
        tCNfu:
        if (!$this->r3OVR) {
            goto r4Dnq;
        }
        goto e58vy;
        H6mgW:
        $RWaGO['Outputs'] = [];
        goto ErHXc;
        e58vy:
        $piUWf['Settings']['OutputGroups'][] = $this->r3OVR->mokU7ydBs3A();
        goto RG_Nj;
        OGxeZ:
        $piUWf['AccelerationSettings']['Mode'] = 'ENABLED';
        goto OxphR;
        V3ciI:
        $this->I8T9h = [];
        goto WQkv8;
        Px5QA:
        unset($piUWf['Settings']['OutputGroups']);
        goto H6mgW;
        Sctpf:
        $RWaGO['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->NFhLB;
        goto x8mVw;
        NGh_o:
        $this->r3OVR = null;
        goto HieNh;
        OxphR:
        fn1PX:
        goto NGh_o;
        CRupE:
        throw new \LogicException('You must provide a input file to use');
        goto u1o9v;
        Mquwx:
        if (!$enFOP) {
            goto fn1PX;
        }
        goto OGxeZ;
        HieNh:
        $this->qIJNv = null;
        goto V3ciI;
        hiRpr:
        uL4sf:
        goto Sctpf;
        HAEK0:
        $piUWf = (require 'template.php');
        goto KKajj;
        GnmRh:
        $piUWf['Settings']['Inputs'] = $this->qIJNv->m9XVC4BWPcy();
        goto Vssra;
        x8mVw:
        $piUWf['Settings']['OutputGroups'][] = $RWaGO;
        goto tCNfu;
        KKajj:
        $piUWf['Role'] = $this->DyII5;
        goto igRNK;
        uGyBO:
        if ($this->qIJNv) {
            goto KRT1P;
        }
        goto CRupE;
        WQkv8:
        return $piUWf;
        goto rFABY;
        igRNK:
        $piUWf['Queue'] = $this->UVTja;
        goto uGyBO;
        Vssra:
        $RWaGO = $piUWf['Settings']['OutputGroups'][0];
        goto Px5QA;
        ErHXc:
        foreach ($this->I8T9h as $PmsUO) {
            $RWaGO['Outputs'][] = $PmsUO->mTZivmfM82L();
            RfMys:
        }
        goto hiRpr;
        u1o9v:
        KRT1P:
        goto GnmRh;
        rFABY:
    }
    public function mChY6xrKY4C(bool $enFOP = false) : string
    {
        try {
            $LDmT4 = $this->s2s_t->createJob($this->mQbk9hcKCHB($enFOP));
            return $LDmT4->get('Jobs')['Id'];
        } catch (AwsException $AUVE0) {
            Log::error('Error creating MediaConvert job: ' . $AUVE0->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $AUVE0);
        }
    }
}
