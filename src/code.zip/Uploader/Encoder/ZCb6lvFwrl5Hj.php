<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class ZCb6lvFwrl5Hj
{
    private $Duz5V;
    public function __construct(string $AiR7L, int $uQ92F, int $hlWb6, ?int $aio9s, ?int $E52ZJ)
    {
        goto AGe2A;
        ITcgB:
        if (!($aio9s && $E52ZJ)) {
            goto cyBAh;
        }
        goto LFe54;
        LFe54:
        $this->Duz5V['ImageInserter']['InsertableImages'][0]['Width'] = $aio9s;
        goto FW70d;
        aQDYM:
        cyBAh:
        goto cBIFr;
        FW70d:
        $this->Duz5V['ImageInserter']['InsertableImages'][0]['Height'] = $E52ZJ;
        goto aQDYM;
        AGe2A:
        $this->Duz5V = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $uQ92F, 'ImageY' => $hlWb6, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $AiR7L, 'Opacity' => 35]]]];
        goto ITcgB;
        cBIFr:
    }
    public function mhxzP1V5zhE() : array
    {
        return $this->Duz5V;
    }
}
