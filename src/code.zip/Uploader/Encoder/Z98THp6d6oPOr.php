<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Z98THp6d6oPOr
{
    private $pxIiA;
    public function __construct(float $yPVhK, int $upJaA, string $akNEN)
    {
        goto qwlcX;
        qwlcX:
        $WEveA = (int) $yPVhK / $upJaA;
        goto xqTkA;
        qeW1g:
        $this->pxIiA = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $WEveA]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $akNEN]]];
        goto BN2rm;
        xqTkA:
        $WEveA = max($WEveA, 1);
        goto qeW1g;
        BN2rm:
    }
    public function md6JvC1MTxd() : array
    {
        return $this->pxIiA;
    }
}
