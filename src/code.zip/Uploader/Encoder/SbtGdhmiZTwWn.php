<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class SbtGdhmiZTwWn
{
    private $DwgfU;
    public function __construct(float $YgH2u, int $HtvD6, string $OZyjE)
    {
        goto lP8FH;
        lP8FH:
        $CtB5W = (int) $YgH2u / $HtvD6;
        goto bbHMB;
        tWslr:
        $this->DwgfU = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $CtB5W]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $OZyjE]]];
        goto b1bq3;
        bbHMB:
        $CtB5W = max($CtB5W, 1);
        goto tWslr;
        b1bq3:
    }
    public function mxKXAzgKgQI() : array
    {
        return $this->DwgfU;
    }
}
