<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
use src\Uploader\Encoder\AExjKfXX7gVdb;
use src\Uploader\Encoder\BQuzY5eIHOHbX;
use src\Uploader\Encoder\QU6PiV2uGCnpt;
final class SgVYdb34TZ3jy
{
    private $ItBBk;
    private $TmcdO;
    private $NKcIl;
    private $FYCni;
    private $F58ls;
    private $O5X0R;
    private $VjYPs;
    public function __construct(MediaConvertClient $Hb5qa, $k4LWT, $AuEzL)
    {
        goto pTWTO;
        CfL0s:
        $this->F58ls = $k4LWT;
        goto OQknu;
        OQknu:
        $this->O5X0R = $AuEzL;
        goto l_yix;
        pTWTO:
        $this->FYCni = $Hb5qa;
        goto CfL0s;
        l_yix:
    }
    public function m8303N8ubW7() : MediaConvertClient
    {
        return $this->FYCni;
    }
    public function me7cxy8aDVL(AExjKfXX7gVdb $kbl5T) : self
    {
        $this->ItBBk = $kbl5T;
        return $this;
    }
    public function m8vMoQIGcbD(string $eHFbT) : self
    {
        $this->NKcIl = $eHFbT;
        return $this;
    }
    public function mTmZr2lBMqg(BQuzY5eIHOHbX $Wy0Jl) : self
    {
        $this->TmcdO[] = $Wy0Jl;
        return $this;
    }
    public function mQbBDmkQoiu(QU6PiV2uGCnpt $pIzqs) : self
    {
        $this->VjYPs = $pIzqs;
        return $this;
    }
    private function mtQkgpeQino(bool $MopiS) : array
    {
        goto b0e_1;
        ORKRn:
        foreach ($this->TmcdO as $Wy0Jl) {
            $xUulD['Outputs'][] = $Wy0Jl->mqjQd3bKUpm();
            uBFjG:
        }
        goto Vj4R7;
        Vj4R7:
        dfIH4:
        goto rJDD1;
        VnjNv:
        shiXI:
        goto lbYJw;
        lbYJw:
        $this->VjYPs = null;
        goto u0OGe;
        d0Olo:
        $Yk713['Role'] = $this->F58ls;
        goto qpyD4;
        b0e_1:
        $Yk713 = (require 'template.php');
        goto d0Olo;
        BBvC5:
        throw new \LogicException('You must provide a input file to use');
        goto ZqxqY;
        p3j2z:
        if (!$MopiS) {
            goto shiXI;
        }
        goto OIePt;
        fRIIM:
        $xUulD['Outputs'] = [];
        goto ORKRn;
        ewB8A:
        if (!$this->VjYPs) {
            goto OWP3S;
        }
        goto iKlTk;
        KLA7Q:
        $this->TmcdO = [];
        goto j_3sQ;
        oFCsH:
        $Yk713['Settings']['OutputGroups'][] = $xUulD;
        goto ewB8A;
        PiOSB:
        unset($Yk713['Settings']['OutputGroups']);
        goto fRIIM;
        bijsz:
        $Yk713['Settings']['Inputs'] = $this->ItBBk->mHeXGzNVisH();
        goto fs1yC;
        F3w0P:
        OWP3S:
        goto p3j2z;
        qpyD4:
        $Yk713['Queue'] = $this->O5X0R;
        goto o1Zlz;
        j_3sQ:
        return $Yk713;
        goto ESpNj;
        fs1yC:
        $xUulD = $Yk713['Settings']['OutputGroups'][0];
        goto PiOSB;
        OIePt:
        $Yk713['AccelerationSettings']['Mode'] = 'ENABLED';
        goto VnjNv;
        iKlTk:
        $Yk713['Settings']['OutputGroups'][] = $this->VjYPs->m0kz1rWtUSI();
        goto F3w0P;
        u0OGe:
        $this->ItBBk = null;
        goto KLA7Q;
        ZqxqY:
        sEqo5:
        goto bijsz;
        o1Zlz:
        if ($this->ItBBk) {
            goto sEqo5;
        }
        goto BBvC5;
        rJDD1:
        $xUulD['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->NKcIl;
        goto oFCsH;
        ESpNj:
    }
    public function m4DyYMqBQ5p(bool $MopiS = false) : string
    {
        try {
            $aJeqW = $this->FYCni->createJob($this->mtQkgpeQino($MopiS));
            return $aJeqW->get('Jobs')['Id'];
        } catch (AwsException $lrm5K) {
            Log::error('Error creating MediaConvert job: ' . $lrm5K->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $lrm5K);
        }
    }
}
