<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class VW5Bj7j5VYqGn
{
    private $jL8A5;
    public function __construct(string $drbsd, int $ozu96, int $zIwol, ?int $SeDOJ, ?int $vwirX)
    {
        goto dyvtz;
        dyvtz:
        $this->jL8A5 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $ozu96, 'ImageY' => $zIwol, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $drbsd, 'Opacity' => 35]]]];
        goto IPAn9;
        PnDTU:
        $this->jL8A5['ImageInserter']['InsertableImages'][0]['Width'] = $SeDOJ;
        goto D3YCR;
        A52SN:
        xpJP2:
        goto k6BZQ;
        D3YCR:
        $this->jL8A5['ImageInserter']['InsertableImages'][0]['Height'] = $vwirX;
        goto A52SN;
        IPAn9:
        if (!($SeDOJ && $vwirX)) {
            goto xpJP2;
        }
        goto PnDTU;
        k6BZQ:
    }
    public function mNclBmPPbm4() : array
    {
        return $this->jL8A5;
    }
}
