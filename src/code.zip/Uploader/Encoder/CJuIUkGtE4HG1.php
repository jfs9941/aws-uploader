<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class CJuIUkGtE4HG1
{
    private $Ncmx0;
    public function __construct(string $h_KEw, ?int $xjnOB, ?int $I9Wph, float $JltSk)
    {
        goto BS6Et;
        W_phS:
        $C9Iwe = $this->mkZABJZ736y($xjnOB, $I9Wph, $JltSk);
        goto sRDCw;
        gg9mp:
        $this->Ncmx0['VideoDescription']['Width'] = $xjnOB;
        goto EhZlJ;
        EhZlJ:
        $this->Ncmx0['VideoDescription']['Height'] = $I9Wph;
        goto vOJPm;
        Rvp4f:
        if (!($xjnOB && $I9Wph)) {
            goto uGptc;
        }
        goto W_phS;
        vOJPm:
        CRNep:
        goto he2HY;
        sRDCw:
        uGptc:
        goto hJ7al;
        hJ7al:
        $this->Ncmx0 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $C9Iwe, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $h_KEw];
        goto XIsi0;
        BS6Et:
        $C9Iwe = 15000000;
        goto Rvp4f;
        XIsi0:
        if (!($xjnOB && $I9Wph)) {
            goto CRNep;
        }
        goto gg9mp;
        he2HY:
    }
    public function mQUHBkTzejk(OPZz6Z7tAZhju $Dr63y) : self
    {
        $this->Ncmx0['VideoDescription']['VideoPreprocessors'] = $Dr63y->ms2j342Ztgx();
        return $this;
    }
    public function mgfWyaiGTuN() : array
    {
        return $this->Ncmx0;
    }
    private function mkZABJZ736y(int $xjnOB, int $I9Wph, float $kNhzv, string $Q1dje = 'medium', string $O4LJM = 'h264', string $V_jsY = 'good') : ?int
    {
        goto aalKF;
        iI9JE:
        goto Uj56v;
        goto aLnkY;
        ERRfI:
        switch (strtolower($V_jsY)) {
            case 'low':
                $Cfofa *= 0.8;
                goto KYBul;
            case 'high':
                $Cfofa *= 1.2;
                goto KYBul;
        }
        goto JCkfN;
        R2ui3:
        if ($VpiCO <= 1280 * 720) {
            goto jdW2U;
        }
        goto WFCbs;
        emVM2:
        return (int) ($Cfofa * 1000 * 1000);
        goto wvDWT;
        xDyqF:
        $lyMA3 = 3;
        goto QOQ8k;
        oBKiQ:
        kKk_E:
        goto Sah4D;
        QOQ8k:
        goto Uj56v;
        goto KLo71;
        onZhw:
        YMw5t:
        goto o0m0c;
        XRxff:
        OSIme:
        goto PJcgI;
        HthdG:
        if (!('h265' === strtolower($O4LJM) || 'hevc' === strtolower($O4LJM) || 'vp9' === strtolower($O4LJM))) {
            goto J2wET;
        }
        goto kv9jc;
        bHxMj:
        $lyMA3 = 7;
        goto YYHxt;
        k39P7:
        $lyMA3 = 1.5;
        goto LZr4x;
        ayttX:
        goto Uj56v;
        goto oBKiQ;
        q8q8q:
        if ($VpiCO <= 3840 * 2160) {
            goto kKk_E;
        }
        goto eQrXu;
        KLo71:
        IJHaw:
        goto bHxMj;
        wpdEf:
        KYBul:
        goto u5Gp0;
        B1a20:
        switch (strtolower($Q1dje)) {
            case 'low':
                $Cfofa *= 0.7;
                goto bbfHg;
            case 'high':
                $Cfofa *= 1.3;
                goto bbfHg;
            case 'veryhigh':
                $Cfofa *= 1.6;
                goto bbfHg;
        }
        goto onZhw;
        aalKF:
        $VpiCO = $xjnOB * $I9Wph;
        goto gj2Iy;
        u5Gp0:
        $Cfofa = max(0.5, $Cfofa);
        goto emVM2;
        eQrXu:
        $lyMA3 = 30;
        goto iI9JE;
        m5ciI:
        $Cfofa = $lyMA3 * ($kNhzv / 30);
        goto B1a20;
        PJcgI:
        $lyMA3 = 12;
        goto ayttX;
        WFCbs:
        if ($VpiCO <= 1920 * 1080) {
            goto IJHaw;
        }
        goto K5VJa;
        Sah4D:
        $lyMA3 = 20;
        goto YnTZX;
        YnTZX:
        Uj56v:
        goto m5ciI;
        LZr4x:
        goto Uj56v;
        goto CFN_H;
        o0m0c:
        bbfHg:
        goto HthdG;
        kv9jc:
        $Cfofa *= 0.65;
        goto PwQ3n;
        JCkfN:
        C1397:
        goto wpdEf;
        K5VJa:
        if ($VpiCO <= 2560 * 1440) {
            goto OSIme;
        }
        goto q8q8q;
        YYHxt:
        goto Uj56v;
        goto XRxff;
        gj2Iy:
        if ($VpiCO <= 640 * 480) {
            goto QuHZH;
        }
        goto R2ui3;
        CFN_H:
        jdW2U:
        goto xDyqF;
        aLnkY:
        QuHZH:
        goto k39P7;
        PwQ3n:
        J2wET:
        goto ERRfI;
        wvDWT:
    }
}
