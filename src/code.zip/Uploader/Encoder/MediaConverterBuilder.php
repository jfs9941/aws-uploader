<?php
declare(strict_types=1);

namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;

final class MediaConverterBuilder
{
    /**
     * @var Input
     */
    private $input;
    /**
     * @var array<HlsOutput>
     */
    private $outputs;
    private $destination;

    private $convertClient;
    private $role;
    private $queue;

    /**
     * @var CaptureThumbnail|null
     */
    private $thumbnail;

    public function __construct(MediaConvertClient $convertClient,
        $role,
        $queue)
    {
        $this->convertClient = $convertClient;
        $this->role = $role;
        $this->queue = $queue;
    }

    public function getMediaConvertClient(): MediaConvertClient
    {
        return $this->convertClient;
    }

    public function input(Input $input): self
    {
        $this->input = $input;

        return $this;
    }

    public function setDestination(string $destination): self
    {
        $this->destination = $destination;

        return $this;
    }

    public function addOutput(HlsOutput $output): self
    {
        $this->outputs[] = $output;

        return $this;
    }

    public function thumbnail(CaptureThumbnail $thumbnail): self
    {
        $this->thumbnail = $thumbnail;

        return $this;
    }

    private function build(bool $accelerated): array
    {
        $template = require 'template.php';

        $template['Role'] = $this->role;
        $template['Queue'] = $this->queue;

        if (!$this->input) {
            throw new \LogicException('You must provide a input file to use');
        }

        $template['Settings']['Inputs'] = $this->input->getInput();
        $outputGroupTemplate = $template['Settings']['OutputGroups'][0];
        unset($template['Settings']['OutputGroups']);
        $outputGroupTemplate['Outputs'] = [];
        foreach ($this->outputs as $output) {
            $outputGroupTemplate['Outputs'][] = $output->getOutput();
        }
        $outputGroupTemplate['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->destination;
        $template['Settings']['OutputGroups'][] = $outputGroupTemplate;
        if ($this->thumbnail) {
            $template['Settings']['OutputGroups'][] = $this->thumbnail->getThumbnail();
        }

        if ($accelerated) {
            $template['AccelerationSettings']['Mode'] = 'ENABLED';
        }

        $this->thumbnail = null;
        $this->input = null;
        $this->outputs = [];

        return $template;
    }

    public function run(bool $accelerated = false): string
    {
        try {
            $result = $this->convertClient->createJob($this->build($accelerated));

            return $result->get('Jobs')['Id'];
        } catch (AwsException $exception) {
            Log::error('Error creating MediaConvert job: '.$exception->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $exception);
        }
    }
}
