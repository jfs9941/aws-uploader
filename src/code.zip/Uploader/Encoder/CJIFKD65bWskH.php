<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class CJIFKD65bWskH
{
    private $alYc1;
    private $u189w;
    private $ETw9e;
    private $VzEiC;
    private $HjCpl;
    private $ONFf7;
    private $Et6ec;
    public function __construct(MediaConvertClient $trQtj, $URTXW, $csTri)
    {
        goto I2PPh;
        I2PPh:
        $this->VzEiC = $trQtj;
        goto y9QAk;
        aK3ow:
        $this->ONFf7 = $csTri;
        goto Dr1_r;
        y9QAk:
        $this->HjCpl = $URTXW;
        goto aK3ow;
        Dr1_r:
    }
    public function mdzEqqcZFXx() : MediaConvertClient
    {
        return $this->VzEiC;
    }
    public function m6usEXjPvyX(IuBzMgccmnzY0 $YjJbT) : self
    {
        $this->alYc1 = $YjJbT;
        return $this;
    }
    public function mWhvNa0nJyI(string $Uh02m) : self
    {
        $this->ETw9e = $Uh02m;
        return $this;
    }
    public function mjQpyVD7qjf(VzCP01fc7F1B6 $b341d) : self
    {
        $this->u189w[] = $b341d;
        return $this;
    }
    public function mESxosCFZd0(T4E7bNu9othaO $jVS4s) : self
    {
        $this->Et6ec = $jVS4s;
        return $this;
    }
    private function mwIQQaPY1UE(bool $QOx7y) : array
    {
        goto R7IK4;
        mBP9T:
        iTJMl:
        goto aohOw;
        qwW8T:
        if (!$this->Et6ec) {
            goto V4Fnq;
        }
        goto iJJ5d;
        YVvG2:
        $this->alYc1 = null;
        goto dX_Kq;
        y7kTF:
        $this->Et6ec = null;
        goto YVvG2;
        W_Wck:
        $LHDG6['Settings']['OutputGroups'][] = $U8Krr;
        goto qwW8T;
        Ikb3K:
        UC2uj:
        goto y7kTF;
        iJJ5d:
        $LHDG6['Settings']['OutputGroups'][] = $this->Et6ec->mc7VJwzlcmw();
        goto hUlBr;
        u17FU:
        $LHDG6['Role'] = $this->HjCpl;
        goto Ey1xl;
        qt9N7:
        $U8Krr = $LHDG6['Settings']['OutputGroups'][0];
        goto XUzyB;
        px923:
        $LHDG6['AccelerationSettings']['Mode'] = 'ENABLED';
        goto Ikb3K;
        aohOw:
        $U8Krr['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->ETw9e;
        goto W_Wck;
        C6pdS:
        return $LHDG6;
        goto FwDWV;
        Ey1xl:
        $LHDG6['Queue'] = $this->ONFf7;
        goto f2Yls;
        uGIzU:
        throw new \LogicException('You must provide a input file to use');
        goto Quh9p;
        EOrcH:
        foreach ($this->u189w as $b341d) {
            $U8Krr['Outputs'][] = $b341d->m8ipZbbhaRA();
            AvUc_:
        }
        goto mBP9T;
        hUlBr:
        V4Fnq:
        goto DvBFf;
        Quh9p:
        OZoI0:
        goto oTkJS;
        f2Yls:
        if ($this->alYc1) {
            goto OZoI0;
        }
        goto uGIzU;
        dX_Kq:
        $this->u189w = [];
        goto C6pdS;
        oTkJS:
        $LHDG6['Settings']['Inputs'] = $this->alYc1->mtO2ZH1GnZg();
        goto qt9N7;
        R7IK4:
        $LHDG6 = (require 'template.php');
        goto u17FU;
        XUzyB:
        unset($LHDG6['Settings']['OutputGroups']);
        goto xwLee;
        xwLee:
        $U8Krr['Outputs'] = [];
        goto EOrcH;
        DvBFf:
        if (!$QOx7y) {
            goto UC2uj;
        }
        goto px923;
        FwDWV:
    }
    public function mEw24Bz5MMa(bool $QOx7y = false) : string
    {
        try {
            $BVjJ8 = $this->VzEiC->createJob($this->mwIQQaPY1UE($QOx7y));
            return $BVjJ8->get('Jobs')['Id'];
        } catch (AwsException $QEfxK) {
            Log::error('Error creating MediaConvert job: ' . $QEfxK->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $QEfxK);
        }
    }
}
