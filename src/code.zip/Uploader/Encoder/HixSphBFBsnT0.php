<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class HixSphBFBsnT0
{
    private $incY6;
    public function __construct(string $YQkwH, int $BIeVW, int $xLMkG, ?int $X22ix, ?int $LrYxj)
    {
        goto NKTYn;
        NXn5N:
        $this->incY6['ImageInserter']['InsertableImages'][0]['Height'] = $LrYxj;
        goto GYzRB;
        ggfY6:
        if (!($X22ix && $LrYxj)) {
            goto Qoc14;
        }
        goto vu3WT;
        GYzRB:
        Qoc14:
        goto Q1RVm;
        NKTYn:
        $this->incY6 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $BIeVW, 'ImageY' => $xLMkG, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $YQkwH, 'Opacity' => 35]]]];
        goto ggfY6;
        vu3WT:
        $this->incY6['ImageInserter']['InsertableImages'][0]['Width'] = $X22ix;
        goto NXn5N;
        Q1RVm:
    }
    public function mj630tATlDx() : array
    {
        return $this->incY6;
    }
}
