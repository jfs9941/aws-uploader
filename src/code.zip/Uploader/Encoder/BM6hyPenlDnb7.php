<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class BM6hyPenlDnb7
{
    private $aVfpf;
    public function __construct(float $UYz2A, int $fYbq6, string $tFqD7)
    {
        goto d4dpz;
        d4dpz:
        $bZ7rD = (int) $UYz2A / $fYbq6;
        goto McQXG;
        J6SVi:
        $this->aVfpf = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $bZ7rD]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $tFqD7]]];
        goto FRKCM;
        McQXG:
        $bZ7rD = max($bZ7rD, 1);
        goto J6SVi;
        FRKCM:
    }
    public function mBJoWxExRMi() : array
    {
        return $this->aVfpf;
    }
}
