<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\WOsYo97dtq83f;
use Jfs\Uploader\Encoder\BzfUWKOHVrbmX;
use Jfs\Uploader\Encoder\EVUJFq5ZpkhYa;
use Illuminate\Support\Facades\Log;
final class G5nvOO03RJEUp
{
    private $baZfo;
    private $rg1tV;
    private $SAwQ6;
    private $w0Tw0;
    private $sUJ0J;
    private $CUjEI;
    private $LWDKv;
    public function __construct(MediaConvertClient $TXWJc, $JtdVP, $HpggC)
    {
        goto wcmUG;
        wcmUG:
        $this->w0Tw0 = $TXWJc;
        goto fSsBu;
        fSsBu:
        $this->sUJ0J = $JtdVP;
        goto mknb1;
        mknb1:
        $this->CUjEI = $HpggC;
        goto SR5PN;
        SR5PN:
    }
    public function mQVtSJvVMYh() : MediaConvertClient
    {
        return $this->w0Tw0;
    }
    public function m8fLzkiZvIR(EVUJFq5ZpkhYa $XUe4r) : self
    {
        $this->baZfo = $XUe4r;
        return $this;
    }
    public function mXTIb6qDvsw(string $HTaeo) : self
    {
        $this->SAwQ6 = $HTaeo;
        return $this;
    }
    public function m29iTxK0Wba(BzfUWKOHVrbmX $YvrfS) : self
    {
        $this->rg1tV[] = $YvrfS;
        return $this;
    }
    public function mk8mJ38Cnf1(WOsYo97dtq83f $gx7xw) : self
    {
        $this->LWDKv = $gx7xw;
        return $this;
    }
    private function mVYNZJjzBuG(bool $pvpV3) : array
    {
        goto dyPO2;
        N3nUv:
        IMdJ6:
        goto Yil5Q;
        dyPO2:
        $K3BU0 = (require 'template.php');
        goto WNSaG;
        BXHB2:
        uHKPM:
        goto hqNn9;
        ndOvS:
        if (!$this->LWDKv) {
            goto IMdJ6;
        }
        goto GJ_zp;
        LQsnX:
        $f2zU8['Outputs'] = [];
        goto SI60X;
        fveQH:
        $K3BU0['Settings']['OutputGroups'][] = $f2zU8;
        goto ndOvS;
        hqNn9:
        $f2zU8['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->SAwQ6;
        goto fveQH;
        OJNvi:
        PLXZP:
        goto Z5_tK;
        P9YP1:
        $this->rg1tV = [];
        goto jExRU;
        qSyJc:
        $K3BU0['Queue'] = $this->CUjEI;
        goto jNPZH;
        jExRU:
        return $K3BU0;
        goto OZPC4;
        iIHny:
        $this->baZfo = null;
        goto P9YP1;
        Yil5Q:
        if (!$pvpV3) {
            goto uPxQS;
        }
        goto s_4vv;
        WNSaG:
        $K3BU0['Role'] = $this->sUJ0J;
        goto qSyJc;
        SI60X:
        foreach ($this->rg1tV as $YvrfS) {
            $f2zU8['Outputs'][] = $YvrfS->mI3DxT6uOof();
            G7hzg:
        }
        goto BXHB2;
        Qth_e:
        throw new \LogicException('You must provide a input file to use');
        goto OJNvi;
        jNPZH:
        if ($this->baZfo) {
            goto PLXZP;
        }
        goto Qth_e;
        N3XDI:
        unset($K3BU0['Settings']['OutputGroups']);
        goto LQsnX;
        s_4vv:
        $K3BU0['AccelerationSettings']['Mode'] = 'ENABLED';
        goto kAUqR;
        z0RDC:
        $f2zU8 = $K3BU0['Settings']['OutputGroups'][0];
        goto N3XDI;
        GJ_zp:
        $K3BU0['Settings']['OutputGroups'][] = $this->LWDKv->m5JmFiWIfT4();
        goto N3nUv;
        gqrJo:
        $this->LWDKv = null;
        goto iIHny;
        Z5_tK:
        $K3BU0['Settings']['Inputs'] = $this->baZfo->mJOfFFe3xWv();
        goto z0RDC;
        kAUqR:
        uPxQS:
        goto gqrJo;
        OZPC4:
    }
    public function mz8om46iu2k(bool $pvpV3 = false) : string
    {
        try {
            $XDvUb = $this->w0Tw0->createJob($this->mVYNZJjzBuG($pvpV3));
            return $XDvUb->get('Jobs')['Id'];
        } catch (AwsException $b6Bui) {
            Log::error('Error creating MediaConvert job: ' . $b6Bui->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $b6Bui);
        }
    }
}
