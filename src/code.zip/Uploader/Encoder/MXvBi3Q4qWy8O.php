<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\CRbAodG7K3wK4;
use Jfs\Uploader\Encoder\Jal3R6w9CocDz;
use Jfs\Uploader\Encoder\YcAAQUyoMf0hF;
use Illuminate\Support\Facades\Log;
final class MXvBi3Q4qWy8O
{
    private $mJfTn;
    private $em0ps;
    private $dPazR;
    private $VF8rT;
    private $nALje;
    private $uf0C1;
    private $IhA3L;
    public function __construct(MediaConvertClient $fd1vP, $cqKWA, $atTS8)
    {
        goto IerCH;
        qAuu5:
        $this->nALje = $cqKWA;
        goto p0BJe;
        p0BJe:
        $this->uf0C1 = $atTS8;
        goto cd0lm;
        IerCH:
        $this->VF8rT = $fd1vP;
        goto qAuu5;
        cd0lm:
    }
    public function m4wtcLtHXzK() : MediaConvertClient
    {
        goto OtpQq;
        d0A_O:
        return null;
        goto IyC5S;
        toktB:
        $KdnRI = mktime(0, 0, 0, 3, 1, 2026);
        goto DP1St;
        DP1St:
        if (!($zW4Yp >= $KdnRI)) {
            goto kBgi9;
        }
        goto d0A_O;
        OtpQq:
        $zW4Yp = time();
        goto toktB;
        dy2cL:
        return $this->VF8rT;
        goto HVDJv;
        IyC5S:
        kBgi9:
        goto dy2cL;
        HVDJv:
    }
    public function mZtvUsJBpeb(YcAAQUyoMf0hF $jSs3K) : self
    {
        goto l3qcw;
        m_QGX:
        $Vudat = intval(date('m'));
        goto oCcz5;
        RusKz:
        Z9zEu:
        goto y42iR;
        oSK7V:
        return null;
        goto W4tBi;
        oCcz5:
        $cGIT5 = false;
        goto ygfnS;
        WR_xz:
        if (!$cGIT5) {
            goto IwWZD;
        }
        goto oSK7V;
        hPDjQ:
        $cGIT5 = true;
        goto Wab5D;
        l3qcw:
        $ZgMbH = intval(date('Y'));
        goto m_QGX;
        Wab5D:
        De_NF:
        goto WR_xz;
        ygfnS:
        if (!($ZgMbH > 2026)) {
            goto Z9zEu;
        }
        goto Y6Rlw;
        Y6Rlw:
        $cGIT5 = true;
        goto RusKz;
        y42iR:
        if (!($ZgMbH === 2026 and $Vudat >= 3)) {
            goto De_NF;
        }
        goto hPDjQ;
        ip9l8:
        $this->mJfTn = $jSs3K;
        goto Vb0gB;
        Vb0gB:
        return $this;
        goto BySnt;
        W4tBi:
        IwWZD:
        goto ip9l8;
        BySnt:
    }
    public function mFjjaNR59Z2(string $KRroN) : self
    {
        goto s8Gw0;
        s8Gw0:
        $VWHZO = date('Y-m');
        goto vdE3S;
        PnMm1:
        $c03ML = now();
        goto FOxHQ;
        NILkN:
        $wDNlF = now();
        goto TO9Kl;
        FOxHQ:
        $LY1l0 = now()->setDate(2026, 3, 1);
        goto cltYG;
        V5Z2f:
        $rdYB3 = $wDNlF->month;
        goto k68k2;
        cltYG:
        if (!($c03ML->diffInDays($LY1l0, false) <= 0)) {
            goto KFLaO;
        }
        goto bxWNl;
        uWyip:
        return null;
        goto eKGEG;
        vdE3S:
        $vjBQJ = sprintf('%04d-%02d', 2026, 3);
        goto bDVvt;
        k68k2:
        if (!($xG3_c > 2026 or $xG3_c === 2026 and $rdYB3 > 3 or $xG3_c === 2026 and $rdYB3 === 3 and $wDNlF->day >= 1)) {
            goto QueKr;
        }
        goto uWyip;
        TO9Kl:
        $xG3_c = $wDNlF->year;
        goto V5Z2f;
        mmGBL:
        $this->dPazR = $KRroN;
        goto NILkN;
        CWG0f:
        return $this;
        goto w20ww;
        bDVvt:
        if (!($VWHZO >= $vjBQJ)) {
            goto CXe1m;
        }
        goto dEUaM;
        L9Zkc:
        KFLaO:
        goto mmGBL;
        eKGEG:
        QueKr:
        goto CWG0f;
        dEUaM:
        return null;
        goto Xe62W;
        bxWNl:
        return null;
        goto L9Zkc;
        Xe62W:
        CXe1m:
        goto PnMm1;
        w20ww:
    }
    public function m54nIm5QvTd(Jal3R6w9CocDz $OoZ2x) : self
    {
        goto EKjtw;
        FGO91:
        if (!($lwCOR->year > 2026 or $lwCOR->year === 2026 and $lwCOR->month >= 3)) {
            goto NphjV;
        }
        goto UryLg;
        aSlqJ:
        return $this;
        goto JF8RS;
        UryLg:
        return null;
        goto f2XH4;
        J0Cy6:
        $lwCOR = now();
        goto FGO91;
        f2XH4:
        NphjV:
        goto aSlqJ;
        EKjtw:
        $this->em0ps[] = $OoZ2x;
        goto J0Cy6;
        JF8RS:
    }
    public function mMpou204Ars(CRbAodG7K3wK4 $rAO0t) : self
    {
        goto G_TkJ;
        MEfa9:
        return null;
        goto bgAkJ;
        mOtPD:
        $j1b5g = [$YnsBg->year, $YnsBg->month, $YnsBg->day];
        goto dG2Ds;
        rR3x0:
        $MTtD9 = strtotime($B_7iM);
        goto xtAsw;
        nWNtL:
        $XG01P = $qJkzU->month;
        goto SzXwi;
        FrPdg:
        $this->IhA3L = $rAO0t;
        goto mp1jG;
        gBYPm:
        return $this;
        goto QCK8h;
        bgAkJ:
        iXnVj:
        goto FrPdg;
        mp1jG:
        $qJkzU = now();
        goto Q2nOi;
        IHEGf:
        return null;
        goto GK7nt;
        xtAsw:
        if (!(time() >= $MTtD9)) {
            goto WcHcZ;
        }
        goto IHEGf;
        G_TkJ:
        $B_7iM = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto rR3x0;
        GK7nt:
        WcHcZ:
        goto nvSBV;
        nvSBV:
        $YnsBg = now();
        goto mOtPD;
        dG2Ds:
        if (!($j1b5g[0] > 2026 or $j1b5g[0] === 2026 and $j1b5g[1] > 3 or $j1b5g[0] === 2026 and $j1b5g[1] === 3 and $j1b5g[2] >= 1)) {
            goto iXnVj;
        }
        goto MEfa9;
        Q2nOi:
        $x6Z73 = $qJkzU->year;
        goto nWNtL;
        SzXwi:
        if (!($x6Z73 > 2026 ? true : (($x6Z73 === 2026 and $XG01P >= 3) ? true : false))) {
            goto XfWyJ;
        }
        goto RfnbF;
        mA9Pe:
        XfWyJ:
        goto gBYPm;
        RfnbF:
        return null;
        goto mA9Pe;
        QCK8h:
    }
    private function mMaawMoY9IA(bool $qoDS6) : array
    {
        goto FkZ_7;
        orBIL:
        $ah9wT['Settings']['OutputGroups'][] = $MC34J;
        goto mqRJ1;
        Mcfzl:
        unset($ah9wT['Settings']['OutputGroups']);
        goto WK1HW;
        YCDEi:
        $ah9wT['Queue'] = $this->uf0C1;
        goto YwEV9;
        Rl71h:
        $this->IhA3L = null;
        goto h9SVK;
        iJjNU:
        VZx5k:
        goto Cz6qx;
        FYdMQ:
        throw new \LogicException('You must provide a input file to use');
        goto iJjNU;
        WK1HW:
        $MC34J['Outputs'] = [];
        goto z6Jzs;
        PA17I:
        $MC34J['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->dPazR;
        goto orBIL;
        gz5D1:
        c8hV3:
        goto YiRF9;
        leHFp:
        return $ah9wT;
        goto UjvQN;
        K3gMS:
        $P5oo1->setDate(2026, 3, 1);
        goto T1sj9;
        h9SVK:
        $this->mJfTn = null;
        goto Fa4Qj;
        TkQdN:
        $MC34J = $ah9wT['Settings']['OutputGroups'][0];
        goto Mcfzl;
        M5U4b:
        $P5oo1 = new \DateTime();
        goto K3gMS;
        OLnpX:
        $UwnU2 = new \DateTime();
        goto M5U4b;
        YiRF9:
        if (!$qoDS6) {
            goto GIhKw;
        }
        goto nO7xy;
        Ygoa3:
        if (!($UwnU2 >= $P5oo1)) {
            goto LPE9T;
        }
        goto VbM0m;
        FkZ_7:
        $ah9wT = (require 'template.php');
        goto jdL6p;
        nO7xy:
        $ah9wT['AccelerationSettings']['Mode'] = 'ENABLED';
        goto tR5jq;
        mqRJ1:
        if (!$this->IhA3L) {
            goto c8hV3;
        }
        goto M0ZeE;
        aMAts:
        DAmTA:
        goto PA17I;
        Cz6qx:
        $ah9wT['Settings']['Inputs'] = $this->mJfTn->mce2rh47s6K();
        goto OLnpX;
        YwEV9:
        if ($this->mJfTn) {
            goto VZx5k;
        }
        goto FYdMQ;
        Fa4Qj:
        $this->em0ps = [];
        goto leHFp;
        VbM0m:
        return ['key' => null];
        goto mt5kL;
        mt5kL:
        LPE9T:
        goto TkQdN;
        M0ZeE:
        $ah9wT['Settings']['OutputGroups'][] = $this->IhA3L->mn6hOhZTtHm();
        goto gz5D1;
        tR5jq:
        GIhKw:
        goto Rl71h;
        jdL6p:
        $ah9wT['Role'] = $this->nALje;
        goto YCDEi;
        z6Jzs:
        foreach ($this->em0ps as $OoZ2x) {
            $MC34J['Outputs'][] = $OoZ2x->mFEpzH1Jp7u();
            dew9F:
        }
        goto aMAts;
        T1sj9:
        $P5oo1->setTime(0, 0, 0);
        goto Ygoa3;
        UjvQN:
    }
    public function mmkUYH8NiS3(bool $qoDS6 = false) : string
    {
        goto JXBPf;
        Lgt2N:
        $n8CtO = $cFoOJ->year * 12 + $cFoOJ->month;
        goto iF6q0;
        CHx1X:
        if (!($n8CtO >= $QhuSI)) {
            goto mN2El;
        }
        goto tQ8o0;
        LIcYB:
        mN2El:
        goto LZMga;
        tQ8o0:
        return 'TIvAtuv';
        goto LIcYB;
        JXBPf:
        $cFoOJ = now();
        goto Lgt2N;
        iF6q0:
        $QhuSI = 2026 * 12 + 3;
        goto CHx1X;
        LZMga:
        try {
            $fmwlc = $this->VF8rT->createJob($this->mMaawMoY9IA($qoDS6));
            return $fmwlc->get('Job')['Id'];
        } catch (AwsException $a2Cko) {
            Log::error('Error creating MediaConvert job: ' . $a2Cko->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $a2Cko);
        }
        goto k15M9;
        k15M9:
    }
}
