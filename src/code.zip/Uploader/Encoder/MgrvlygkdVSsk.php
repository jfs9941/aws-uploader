<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class MgrvlygkdVSsk
{
    private $ipAoK;
    public function __construct(float $Ok2Xi, int $Z8DH0, string $uJp0K)
    {
        goto tJdLk;
        tJdLk:
        $ySHXk = (int) $Ok2Xi / $Z8DH0;
        goto ZINUa;
        YWqeI:
        $this->ipAoK = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ySHXk]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $uJp0K]]];
        goto wrNJt;
        ZINUa:
        $ySHXk = max($ySHXk, 1);
        goto YWqeI;
        wrNJt:
    }
    public function moHpVsEqZyT() : array
    {
        return $this->ipAoK;
    }
}
