<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\WyFzLebe89oBd;
final class JhQP7Y5yz6qRP
{
    private $jLHu7;
    public function __construct(string $LdFLs, ?int $oy0ze, ?int $sccRX, float $gkOrk)
    {
        goto nwf3i;
        kVSzI:
        if (!($oy0ze && $sccRX)) {
            goto TI0VM;
        }
        goto xsukO;
        R29Vk:
        $this->jLHu7 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $FLYxr, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $LdFLs];
        goto kVSzI;
        nwf3i:
        $FLYxr = 15000000;
        goto lGW9J;
        lzzTM:
        $this->jLHu7['VideoDescription']['Height'] = $sccRX;
        goto fcLbt;
        fcLbt:
        TI0VM:
        goto FUtZN;
        Zog6u:
        $FLYxr = $this->mmTKHZ4en0D($oy0ze, $sccRX, $gkOrk);
        goto o7OsJ;
        o7OsJ:
        TzAYl:
        goto R29Vk;
        lGW9J:
        if (!($oy0ze && $sccRX)) {
            goto TzAYl;
        }
        goto Zog6u;
        xsukO:
        $this->jLHu7['VideoDescription']['Width'] = $oy0ze;
        goto lzzTM;
        FUtZN:
    }
    public function mIzdYvq0h1J(WyFzLebe89oBd $pDpJ4) : self
    {
        $this->jLHu7['VideoDescription']['VideoPreprocessors'] = $pDpJ4->m0ByrI1QwU8();
        return $this;
    }
    public function msSFN2BuL8x() : array
    {
        return $this->jLHu7;
    }
    private function mmTKHZ4en0D(int $oy0ze, int $sccRX, float $Ssstb, string $HunpT = 'medium', string $DKJc9 = 'h264', string $Mwl6I = 'good') : ?int
    {
        goto AdEyL;
        crpX2:
        if ($RtClz <= 1920 * 1080) {
            goto OL87f;
        }
        goto nDjnv;
        M75cq:
        if ($RtClz <= 640 * 480) {
            goto tn5ja;
        }
        goto ykt1x;
        fz2BO:
        goto IzZwL;
        goto V43e8;
        sBDqv:
        return (int) ($RBLFd * 1000 * 1000);
        goto oUVZO;
        wKwbC:
        $RBLFd = $L7x2c * ($Ssstb / 30);
        goto iWfWA;
        AdEyL:
        $RtClz = $oy0ze * $sccRX;
        goto M75cq;
        AupWh:
        switch (strtolower($Mwl6I)) {
            case 'low':
                $RBLFd *= 0.8;
                goto Ol33a;
            case 'high':
                $RBLFd *= 1.2;
                goto Ol33a;
        }
        goto DTXTG;
        apeqv:
        BaAM1:
        goto fSvxS;
        kQVN9:
        Ol33a:
        goto vLnnH;
        rNilZ:
        goto IzZwL;
        goto LCNZ9;
        h6Fpg:
        $L7x2c = 30;
        goto fz2BO;
        dVMZm:
        ErvOu:
        goto fZjon;
        DTXTG:
        haN2t:
        goto kQVN9;
        vJ242:
        if (!('h265' === strtolower($DKJc9) || 'hevc' === strtolower($DKJc9) || 'vp9' === strtolower($DKJc9))) {
            goto fQOIw;
        }
        goto t0IIi;
        LCNZ9:
        EKpjd:
        goto HhZ4i;
        qLcnQ:
        OL87f:
        goto Nf13t;
        fSvxS:
        $L7x2c = 3;
        goto zSSjo;
        wS7kq:
        fQOIw:
        goto AupWh;
        vLnnH:
        $RBLFd = max(0.5, $RBLFd);
        goto sBDqv;
        q0fTl:
        if ($RtClz <= 3840 * 2160) {
            goto ErvOu;
        }
        goto h6Fpg;
        Ge8il:
        goto IzZwL;
        goto dVMZm;
        nDjnv:
        if ($RtClz <= 2560 * 1440) {
            goto EKpjd;
        }
        goto q0fTl;
        V43e8:
        tn5ja:
        goto p2c1u;
        wmSgf:
        h1Umm:
        goto o3vMc;
        Rdj4K:
        goto IzZwL;
        goto apeqv;
        t0IIi:
        $RBLFd *= 0.65;
        goto wS7kq;
        fZjon:
        $L7x2c = 20;
        goto fysGI;
        p2c1u:
        $L7x2c = 1.5;
        goto Rdj4K;
        o3vMc:
        KYC9U:
        goto vJ242;
        zSSjo:
        goto IzZwL;
        goto qLcnQ;
        iWfWA:
        switch (strtolower($HunpT)) {
            case 'low':
                $RBLFd *= 0.7;
                goto KYC9U;
            case 'high':
                $RBLFd *= 1.3;
                goto KYC9U;
            case 'veryhigh':
                $RBLFd *= 1.6;
                goto KYC9U;
        }
        goto wmSgf;
        HhZ4i:
        $L7x2c = 12;
        goto Ge8il;
        fysGI:
        IzZwL:
        goto wKwbC;
        Nf13t:
        $L7x2c = 7;
        goto rNilZ;
        ykt1x:
        if ($RtClz <= 1280 * 720) {
            goto BaAM1;
        }
        goto crpX2;
        oUVZO:
    }
}
