<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\FcRTXS1DgCu2b;
use Jfs\Uploader\Encoder\N5IONLvfizlXB;
use Jfs\Uploader\Encoder\AB1zr7gVTXVIM;
use Illuminate\Support\Facades\Log;
final class FhlmmSZhUQ7B8
{
    private $VLawB;
    private $kYiS5;
    private $AoYKI;
    private $tnubs;
    private $hAP2x;
    private $qb2Q1;
    private $hrRlC;
    public function __construct(MediaConvertClient $diixx, $rqY7f, $CrUfH)
    {
        goto thrxR;
        thrxR:
        $this->tnubs = $diixx;
        goto xlH9P;
        xlH9P:
        $this->hAP2x = $rqY7f;
        goto JwoUj;
        JwoUj:
        $this->qb2Q1 = $CrUfH;
        goto UCBCC;
        UCBCC:
    }
    public function m1EDGtTJEZP() : MediaConvertClient
    {
        return $this->tnubs;
    }
    public function mSmTcfzKCKL(AB1zr7gVTXVIM $WOW_4) : self
    {
        $this->VLawB = $WOW_4;
        return $this;
    }
    public function mfCtO1syYcq(string $MLP1z) : self
    {
        $this->AoYKI = $MLP1z;
        return $this;
    }
    public function mrrvD6Mk756(N5IONLvfizlXB $H6MIu) : self
    {
        $this->kYiS5[] = $H6MIu;
        return $this;
    }
    public function mTdFt36cBRn(FcRTXS1DgCu2b $i7XwP) : self
    {
        $this->hrRlC = $i7XwP;
        return $this;
    }
    private function mbJU6ypHANQ(bool $NFx06) : array
    {
        goto Up31m;
        DC98m:
        $FvKyQ = $SLUnB['Settings']['OutputGroups'][0];
        goto Yqcd_;
        zGaI0:
        CVCUT:
        goto cpB7p;
        Mmx0z:
        if ($this->VLawB) {
            goto CVCUT;
        }
        goto MG9pQ;
        cpB7p:
        $SLUnB['Settings']['Inputs'] = $this->VLawB->maMU1dVlokb();
        goto DC98m;
        bSpM9:
        rCU3x:
        goto XtKPE;
        Up31m:
        $SLUnB = (require 'template.php');
        goto CnMO0;
        Yqcd_:
        unset($SLUnB['Settings']['OutputGroups']);
        goto q4NPL;
        JjZYW:
        return $SLUnB;
        goto g7eUW;
        XtKPE:
        $FvKyQ['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->AoYKI;
        goto T9p7y;
        T9p7y:
        $SLUnB['Settings']['OutputGroups'][] = $FvKyQ;
        goto lyo88;
        nUzSt:
        foreach ($this->kYiS5 as $H6MIu) {
            $FvKyQ['Outputs'][] = $H6MIu->mVAGMRacmpJ();
            CLcAN:
        }
        goto bSpM9;
        b0Ek5:
        $this->hrRlC = null;
        goto LMyll;
        MG9pQ:
        throw new \LogicException('You must provide a input file to use');
        goto zGaI0;
        lyo88:
        if (!$this->hrRlC) {
            goto lvUhb;
        }
        goto qC1l1;
        CnMO0:
        $SLUnB['Role'] = $this->hAP2x;
        goto qS0t4;
        qS0t4:
        $SLUnB['Queue'] = $this->qb2Q1;
        goto Mmx0z;
        LMyll:
        $this->VLawB = null;
        goto DhKqo;
        rAtn5:
        XGEKF:
        goto b0Ek5;
        WiHJp:
        $SLUnB['AccelerationSettings']['Mode'] = 'ENABLED';
        goto rAtn5;
        DhKqo:
        $this->kYiS5 = [];
        goto JjZYW;
        qC1l1:
        $SLUnB['Settings']['OutputGroups'][] = $this->hrRlC->mP749yL4tV1();
        goto mKLtx;
        PyT3b:
        if (!$NFx06) {
            goto XGEKF;
        }
        goto WiHJp;
        mKLtx:
        lvUhb:
        goto PyT3b;
        q4NPL:
        $FvKyQ['Outputs'] = [];
        goto nUzSt;
        g7eUW:
    }
    public function mxTnwNqG8Jk(bool $NFx06 = false) : string
    {
        try {
            $h1oLe = $this->tnubs->createJob($this->mbJU6ypHANQ($NFx06));
            return $h1oLe->get('Jobs')['Id'];
        } catch (AwsException $bIOBo) {
            Log::error('Error creating MediaConvert job: ' . $bIOBo->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $bIOBo);
        }
    }
}
