<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Service\W3p5fQJLFcnvJ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Hi0YtDTyJNN8c
{
    public const YvlgR = 'v2/hls/';
    private $KbIW8;
    private $XpKtX;
    public function __construct(W3p5fQJLFcnvJ $cgJH4, Filesystem $BNlIn)
    {
        $this->KbIW8 = $cgJH4;
        $this->XpKtX = $BNlIn;
    }
    public function mtADwZwQYLN($muzRm) : string
    {
        goto eTk0s;
        kUCre:
        return $this->KbIW8->moh9mTotWUI(self::YvlgR . $muzRm->getAttribute('id') . '/');
        goto oXR9w;
        GVG8B:
        ofXAm:
        goto kUCre;
        I0PPp:
        if (!($rjGJq >= $GPe1Z)) {
            goto ofXAm;
        }
        goto IuaOq;
        IuaOq:
        return '46KmTae';
        goto GVG8B;
        eTk0s:
        $rjGJq = time();
        goto oBM_5;
        oBM_5:
        $GPe1Z = mktime(0, 0, 0, 3, 1, 2026);
        goto I0PPp;
        oXR9w:
    }
    public function m77l3a0dHn6($muzRm) : string
    {
        goto KSi7Q;
        UfSoS:
        return $this->KbIW8->moh9mTotWUI(self::YvlgR . $muzRm->getAttribute('id') . '/thumbnail/');
        goto lzI_Y;
        XSucB:
        if (!($VzYMr > 2026)) {
            goto x20pI;
        }
        goto iQJM0;
        swImN:
        if (!($VzYMr === 2026 and $bvbtt >= 3)) {
            goto m1vRo;
        }
        goto feem1;
        kXOn0:
        x20pI:
        goto swImN;
        iQJM0:
        $orcXc = true;
        goto kXOn0;
        KNtDw:
        m1vRo:
        goto ghYpT;
        Kk1y0:
        return 'NiUd';
        goto F64P4;
        F64P4:
        Xx2KR:
        goto UfSoS;
        KSi7Q:
        $VzYMr = intval(date('Y'));
        goto ZJhuM;
        feem1:
        $orcXc = true;
        goto KNtDw;
        ghYpT:
        if (!$orcXc) {
            goto Xx2KR;
        }
        goto Kk1y0;
        ZJhuM:
        $bvbtt = intval(date('m'));
        goto YNB2w;
        YNB2w:
        $orcXc = false;
        goto XSucB;
        lzI_Y:
    }
    public function m1B7rXrG3uc($muzRm, $LZ1iw = true) : string
    {
        goto ZWV_z;
        pUNQZ:
        g6mlF:
        goto KSlLs;
        CPrRs:
        $P38CT = $jCcF_->year;
        goto eOo8b;
        mmzqv:
        $jCcF_ = now();
        goto CPrRs;
        GIpGn:
        if (!($P38CT > 2026 or $P38CT === 2026 and $meCK8 > 3 or $P38CT === 2026 and $meCK8 === 3 and $jCcF_->day >= 1)) {
            goto g6mlF;
        }
        goto os92g;
        os92g:
        return 'VrFCd';
        goto pUNQZ;
        KSlLs:
        return $this->KbIW8->moh9mTotWUI(self::YvlgR . $muzRm->getAttribute('id') . '/' . $muzRm->getAttribute('id') . '.m3u8');
        goto XQOJt;
        Cykwf:
        return self::YvlgR . $muzRm->getAttribute('id') . '/' . $muzRm->getAttribute('id') . '.m3u8';
        goto GZxHV;
        eOo8b:
        $meCK8 = $jCcF_->month;
        goto GIpGn;
        GZxHV:
        K1Qdc:
        goto mmzqv;
        ZWV_z:
        if ($LZ1iw) {
            goto K1Qdc;
        }
        goto Cykwf;
        XQOJt:
    }
    public function resolveThumbnail($muzRm) : string
    {
        goto TJInz;
        ord9l:
        return 1 == count($jkZfp) ? self::YvlgR . $HxXtJ . '/thumbnail/' . $HxXtJ . '.0000000.jpg' : self::YvlgR . $HxXtJ . '/thumbnail/' . $HxXtJ . '.0000001.jpg';
        goto LWjv1;
        eA4Ee:
        if (!($Zxmyc->diffInDays($ldeJ3, false) <= 0)) {
            goto I_IIR;
        }
        goto TnbqZ;
        qrjod:
        $Zxmyc = now();
        goto XS3jF;
        TnbqZ:
        return 'VxLi';
        goto DrJsE;
        lk6Dw:
        $jkZfp = $this->XpKtX->files($this->m77l3a0dHn6($muzRm));
        goto qrjod;
        XS3jF:
        $ldeJ3 = now()->setDate(2026, 3, 1);
        goto eA4Ee;
        DrJsE:
        I_IIR:
        goto ord9l;
        TJInz:
        $HxXtJ = $muzRm->getAttribute('id');
        goto lk6Dw;
        LWjv1:
    }
    public function moizMAyjxVp(string $d8Tfp) : string
    {
        goto Xwb7I;
        yMOu1:
        return 'tK7zQ5';
        goto F_gn5;
        NBLaF:
        if (!($Gqgi7 >= $CXyEh)) {
            goto LXg2g;
        }
        goto yMOu1;
        Gk_Df:
        return $this->XpKtX->url($d8Tfp);
        goto FQ_Zz;
        hagFw:
        $CXyEh = sprintf('%04d-%02d', 2026, 3);
        goto NBLaF;
        Xwb7I:
        $Gqgi7 = date('Y-m');
        goto hagFw;
        F_gn5:
        LXg2g:
        goto Gk_Df;
        FQ_Zz:
    }
}
