<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Rcz6vFPVp31Qt
{
    private $L8lv4;
    public function __construct(string $ZPeCm, int $eHgD7, int $yBLUo, ?int $XLJzE, ?int $X8shh)
    {
        goto PZJma;
        N11FO:
        o2tgO:
        goto t9IzC;
        zbPKW:
        if (!($XLJzE && $X8shh)) {
            goto o2tgO;
        }
        goto qiGwq;
        PZJma:
        $this->L8lv4 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $eHgD7, 'ImageY' => $yBLUo, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $ZPeCm, 'Opacity' => 35]]]];
        goto zbPKW;
        qiGwq:
        $this->L8lv4['ImageInserter']['InsertableImages'][0]['Width'] = $XLJzE;
        goto G4zNe;
        G4zNe:
        $this->L8lv4['ImageInserter']['InsertableImages'][0]['Height'] = $X8shh;
        goto N11FO;
        t9IzC:
    }
    public function mkZuE3ZwExP() : array
    {
        return $this->L8lv4;
    }
}
