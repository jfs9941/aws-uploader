<?php
declare(strict_types=1);

namespace Jfs\Uploader\Encoder;

final class Input
{
    private $input;

    public function __construct(string $videoUrl)
    {
        $this->input = [
            [
                'AudioSelectors' => [
                    'Audio Selector 1' => [
                        'DefaultSelection' => 'DEFAULT',
                    ],
                ],
                'VideoSelector' => [
                    'Rotate' => 'AUTO',
                ],
                'TimecodeSource' => 'ZEROBASED',
                'FileInput' => $videoUrl,
            ],
        ];
    }

    public function getInput(): array
    {
        return $this->input;
    }
}
