<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Ye5PnDSJctWEA;
use Jfs\Uploader\Encoder\VeAMACddoaQSh;
use Jfs\Uploader\Encoder\SUpCoEEDksHjH;
use Illuminate\Support\Facades\Log;
final class VTzJhiAsIieKq
{
    private $JtmAs;
    private $TU0O5;
    private $i4LOO;
    private $FrxV1;
    private $GG1IW;
    private $Xx4wx;
    private $vo8A1;
    public function __construct(MediaConvertClient $kl43z, $q7e9R, $zQMFX)
    {
        goto guTMM;
        mdolx:
        $this->GG1IW = $q7e9R;
        goto QgH5s;
        QgH5s:
        $this->Xx4wx = $zQMFX;
        goto ukxXS;
        guTMM:
        $this->FrxV1 = $kl43z;
        goto mdolx;
        ukxXS:
    }
    public function mnTCco4Az8x() : MediaConvertClient
    {
        return $this->FrxV1;
    }
    public function m6VKVhCPRoa(SUpCoEEDksHjH $FTqyg) : self
    {
        $this->JtmAs = $FTqyg;
        return $this;
    }
    public function mf4iQ63JFbZ(string $F53lY) : self
    {
        $this->i4LOO = $F53lY;
        return $this;
    }
    public function mlnSne5hp5n(VeAMACddoaQSh $XE1cr) : self
    {
        $this->TU0O5[] = $XE1cr;
        return $this;
    }
    public function mjEe7Jzllpz(Ye5PnDSJctWEA $oChgQ) : self
    {
        $this->vo8A1 = $oChgQ;
        return $this;
    }
    private function mYfBXM2zRn4(bool $Lu4BB) : array
    {
        goto k0tfO;
        FCdB3:
        $nhTp2 = $XLa0j['Settings']['OutputGroups'][0];
        goto d2Jir;
        d2Jir:
        unset($XLa0j['Settings']['OutputGroups']);
        goto xuX0A;
        StLkD:
        $nhTp2['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->i4LOO;
        goto YEvDo;
        xWLTP:
        OO85g:
        goto j68ly;
        YEvDo:
        $XLa0j['Settings']['OutputGroups'][] = $nhTp2;
        goto D_19D;
        GPRFx:
        BN0KJ:
        goto Av9_m;
        j68ly:
        if (!$Lu4BB) {
            goto Pkm11;
        }
        goto BXOXj;
        Wc3CF:
        a8YTY:
        goto StLkD;
        D_19D:
        if (!$this->vo8A1) {
            goto OO85g;
        }
        goto gGNnu;
        YGt9s:
        return $XLa0j;
        goto XZGPc;
        Av9_m:
        $XLa0j['Settings']['Inputs'] = $this->JtmAs->mDiZqCf3XoA();
        goto FCdB3;
        gGNnu:
        $XLa0j['Settings']['OutputGroups'][] = $this->vo8A1->msVKtm0fuSf();
        goto xWLTP;
        Q5oKb:
        $XLa0j['Queue'] = $this->Xx4wx;
        goto SdKTd;
        JOQhG:
        $this->vo8A1 = null;
        goto x1_Ka;
        B2NTw:
        $this->TU0O5 = [];
        goto YGt9s;
        CHgaO:
        throw new \LogicException('You must provide a input file to use');
        goto GPRFx;
        BXOXj:
        $XLa0j['AccelerationSettings']['Mode'] = 'ENABLED';
        goto AZVJS;
        LEMh2:
        foreach ($this->TU0O5 as $XE1cr) {
            $nhTp2['Outputs'][] = $XE1cr->mqEWILuYzMq();
            UFSSv:
        }
        goto Wc3CF;
        SdKTd:
        if ($this->JtmAs) {
            goto BN0KJ;
        }
        goto CHgaO;
        k0tfO:
        $XLa0j = (require 'template.php');
        goto FjBty;
        x1_Ka:
        $this->JtmAs = null;
        goto B2NTw;
        xuX0A:
        $nhTp2['Outputs'] = [];
        goto LEMh2;
        AZVJS:
        Pkm11:
        goto JOQhG;
        FjBty:
        $XLa0j['Role'] = $this->GG1IW;
        goto Q5oKb;
        XZGPc:
    }
    public function mjqacbmHifP(bool $Lu4BB = false) : string
    {
        try {
            $szBd8 = $this->FrxV1->createJob($this->mYfBXM2zRn4($Lu4BB));
            return $szBd8->get('Jobs')['Id'];
        } catch (AwsException $z6tFS) {
            Log::error('Error creating MediaConvert job: ' . $z6tFS->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $z6tFS);
        }
    }
}
