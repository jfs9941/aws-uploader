<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class ZhqheKMj6zBOk
{
    private $PVDri;
    public function __construct(float $LcGK1, int $I7d0i, string $YaY80)
    {
        goto CpE5q;
        CpE5q:
        $ntBfK = (int) $LcGK1 / $I7d0i;
        goto RvHlG;
        EO7TS:
        $this->PVDri = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ntBfK]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $YaY80]]];
        goto yom9G;
        RvHlG:
        $ntBfK = max($ntBfK, 1);
        goto EO7TS;
        yom9G:
    }
    public function mmDmdMPkxOx() : array
    {
        return $this->PVDri;
    }
}
