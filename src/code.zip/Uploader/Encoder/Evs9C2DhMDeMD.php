<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\CoZlTEDusQdM7;
use Jfs\Uploader\Encoder\Ntz5hwm7VzzwJ;
use Jfs\Uploader\Encoder\PHA10ASHyxJnC;
use Illuminate\Support\Facades\Log;
final class Evs9C2DhMDeMD
{
    private $K2P78;
    private $Fbpwq;
    private $o9oC6;
    private $Fwo4b;
    private $gFx0U;
    private $xo1Kd;
    private $bcO9d;
    public function __construct(MediaConvertClient $GpdOa, $kaoEa, $ff33I)
    {
        goto v3PZ6;
        s5G_9:
        $this->gFx0U = $kaoEa;
        goto s0KX8;
        v3PZ6:
        $this->Fwo4b = $GpdOa;
        goto s5G_9;
        s0KX8:
        $this->xo1Kd = $ff33I;
        goto jjDGZ;
        jjDGZ:
    }
    public function mzmC2kEgh0j() : MediaConvertClient
    {
        return $this->Fwo4b;
    }
    public function mWylJfYFJ7F(PHA10ASHyxJnC $Yoefg) : self
    {
        $this->K2P78 = $Yoefg;
        return $this;
    }
    public function mWG0LZ1bFAO(string $LPZmP) : self
    {
        $this->o9oC6 = $LPZmP;
        return $this;
    }
    public function m4ZQCKu4FSy(Ntz5hwm7VzzwJ $YggeY) : self
    {
        $this->Fbpwq[] = $YggeY;
        return $this;
    }
    public function m5i1cg1abV9(CoZlTEDusQdM7 $NQQfI) : self
    {
        $this->bcO9d = $NQQfI;
        return $this;
    }
    private function mS29rDngKjF(bool $NRs4b) : array
    {
        goto FlfL3;
        J5B7p:
        if (!$this->bcO9d) {
            goto hFZoK;
        }
        goto swQjx;
        swQjx:
        $DIFwe['Settings']['OutputGroups'][] = $this->bcO9d->mTsIKwleqJO();
        goto kfBPB;
        VetiJ:
        unset($DIFwe['Settings']['OutputGroups']);
        goto J9iAn;
        yFSXI:
        throw new \LogicException('You must provide a input file to use');
        goto T0dc6;
        LHREu:
        $ig_oM['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->o9oC6;
        goto IrGpF;
        En3vc:
        if ($this->K2P78) {
            goto iilNi;
        }
        goto yFSXI;
        hfnba:
        tDr51:
        goto WX21K;
        x_HUY:
        if (!$NRs4b) {
            goto tDr51;
        }
        goto mULj0;
        t_Rls:
        $ig_oM = $DIFwe['Settings']['OutputGroups'][0];
        goto VetiJ;
        FlfL3:
        $DIFwe = (require 'template.php');
        goto OHjWp;
        Z4Quz:
        $DIFwe['Queue'] = $this->xo1Kd;
        goto En3vc;
        OHjWp:
        $DIFwe['Role'] = $this->gFx0U;
        goto Z4Quz;
        lP6dh:
        foreach ($this->Fbpwq as $YggeY) {
            $ig_oM['Outputs'][] = $YggeY->mBhfQxkFlHV();
            qgXOL:
        }
        goto CqdAu;
        J9iAn:
        $ig_oM['Outputs'] = [];
        goto lP6dh;
        T0dc6:
        iilNi:
        goto n12i4;
        mULj0:
        $DIFwe['AccelerationSettings']['Mode'] = 'ENABLED';
        goto hfnba;
        z7iXO:
        $this->K2P78 = null;
        goto rFiS2;
        kfBPB:
        hFZoK:
        goto x_HUY;
        n12i4:
        $DIFwe['Settings']['Inputs'] = $this->K2P78->mg42CHCPQIH();
        goto t_Rls;
        CqdAu:
        FkqdW:
        goto LHREu;
        opRji:
        return $DIFwe;
        goto t9m90;
        WX21K:
        $this->bcO9d = null;
        goto z7iXO;
        IrGpF:
        $DIFwe['Settings']['OutputGroups'][] = $ig_oM;
        goto J5B7p;
        rFiS2:
        $this->Fbpwq = [];
        goto opRji;
        t9m90:
    }
    public function mHtOBPKXSuq(bool $NRs4b = false) : string
    {
        try {
            $EF1_E = $this->Fwo4b->createJob($this->mS29rDngKjF($NRs4b));
            return $EF1_E->get('Jobs')['Id'];
        } catch (AwsException $Fa7Tp) {
            Log::error('Error creating MediaConvert job: ' . $Fa7Tp->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $Fa7Tp);
        }
    }
}
