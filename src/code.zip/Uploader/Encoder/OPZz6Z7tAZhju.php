<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class OPZz6Z7tAZhju
{
    private $pgMoK;
    public function __construct(string $CbT7Z, int $QjHgO, int $MtClO, ?int $xjnOB, ?int $I9Wph)
    {
        goto wDDAO;
        NvuMA:
        UulaK:
        goto Cmh6h;
        zUiPV:
        if (!($xjnOB && $I9Wph)) {
            goto UulaK;
        }
        goto AMlFr;
        NUfwE:
        $this->pgMoK['ImageInserter']['InsertableImages'][0]['Height'] = $I9Wph;
        goto NvuMA;
        AMlFr:
        $this->pgMoK['ImageInserter']['InsertableImages'][0]['Width'] = $xjnOB;
        goto NUfwE;
        wDDAO:
        $this->pgMoK = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $QjHgO, 'ImageY' => $MtClO, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $CbT7Z, 'Opacity' => 35]]]];
        goto zUiPV;
        Cmh6h:
    }
    public function ms2j342Ztgx() : array
    {
        return $this->pgMoK;
    }
}
