<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Service\FpvVyCHYf1EbW;
use Illuminate\Contracts\Filesystem\Filesystem;
final class VNaEXNVKcqr6v
{
    public const gdw3j = 'v2/hls/';
    private $Xo0dN;
    private $aiw3M;
    public function __construct(FpvVyCHYf1EbW $T7Fli, Filesystem $iay5S)
    {
        $this->Xo0dN = $T7Fli;
        $this->aiw3M = $iay5S;
    }
    public function mJ5jZAk1Nqd($EVGvq) : string
    {
        return $this->Xo0dN->m0rBCqDFu8S(self::gdw3j . $EVGvq->getAttribute('id') . '/');
    }
    public function mLj5q7uotj2($EVGvq) : string
    {
        return $this->Xo0dN->m0rBCqDFu8S(self::gdw3j . $EVGvq->getAttribute('id') . '/thumbnail/');
    }
    public function mwnkFYbEDvw($EVGvq, $wYLnY = true) : string
    {
        goto HDSyI;
        X5cDw:
        return self::gdw3j . $EVGvq->getAttribute('id') . '/' . $EVGvq->getAttribute('id') . '.m3u8';
        goto pCswH;
        yRsJQ:
        return $this->Xo0dN->m0rBCqDFu8S(self::gdw3j . $EVGvq->getAttribute('id') . '/' . $EVGvq->getAttribute('id') . '.m3u8');
        goto KnyWo;
        pCswH:
        rhS5a:
        goto yRsJQ;
        HDSyI:
        if ($wYLnY) {
            goto rhS5a;
        }
        goto X5cDw;
        KnyWo:
    }
    public function resolveThumbnail($EVGvq) : string
    {
        goto M1V_f;
        aE9H2:
        return 1 == count($SIBhP) ? self::gdw3j . $zV1kl . '/thumbnail/' . $zV1kl . '.0000000.jpg' : self::gdw3j . $zV1kl . '/thumbnail/' . $zV1kl . '.0000001.jpg';
        goto Qm8EY;
        uihzf:
        $SIBhP = $this->aiw3M->files($this->mLj5q7uotj2($EVGvq));
        goto aE9H2;
        M1V_f:
        $zV1kl = $EVGvq->getAttribute('id');
        goto uihzf;
        Qm8EY:
    }
    public function mPnCrI9M2FR(string $lmTDq) : string
    {
        return $this->aiw3M->url($lmTDq);
    }
}
