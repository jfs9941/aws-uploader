<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Service\PzfoMEiZi5U2a;
use Illuminate\Contracts\Filesystem\Filesystem;
final class V6kCroy78Tmzg
{
    public const oDVxY = 'v2/hls/';
    private $KuP3n;
    private $VoF9h;
    public function __construct(PzfoMEiZi5U2a $fkBVz, Filesystem $BQ2l1)
    {
        $this->KuP3n = $fkBVz;
        $this->VoF9h = $BQ2l1;
    }
    public function mZwvWoEs0EI($B4_PH) : string
    {
        return $this->KuP3n->mVCqMpMMdTo(self::oDVxY . $B4_PH->getAttribute('id') . '/');
    }
    public function mX37QX680ee($B4_PH) : string
    {
        return $this->KuP3n->mVCqMpMMdTo(self::oDVxY . $B4_PH->getAttribute('id') . '/thumbnail/');
    }
    public function mE1JGaDUDy4($B4_PH, $LhAwB = true) : string
    {
        goto b1q7z;
        b1q7z:
        if ($LhAwB) {
            goto d1JMh;
        }
        goto HSZje;
        pExHW:
        d1JMh:
        goto mEP1v;
        HSZje:
        return self::oDVxY . $B4_PH->getAttribute('id') . '/' . $B4_PH->getAttribute('id') . '.m3u8';
        goto pExHW;
        mEP1v:
        return $this->KuP3n->mVCqMpMMdTo(self::oDVxY . $B4_PH->getAttribute('id') . '/' . $B4_PH->getAttribute('id') . '.m3u8');
        goto zalKr;
        zalKr:
    }
    public function resolveThumbnail($B4_PH) : string
    {
        goto dzaPp;
        dzaPp:
        $JTwN4 = $B4_PH->getAttribute('id');
        goto lwKG_;
        AWyyQ:
        return 1 == count($AKGYB) ? self::oDVxY . $JTwN4 . '/thumbnail/' . $JTwN4 . '.0000000.jpg' : self::oDVxY . $JTwN4 . '/thumbnail/' . $JTwN4 . '.0000001.jpg';
        goto JqkHc;
        lwKG_:
        $AKGYB = $this->VoF9h->files($this->mX37QX680ee($B4_PH));
        goto AWyyQ;
        JqkHc:
    }
    public function mditD0fYGrn(string $uMpUA) : string
    {
        return $this->VoF9h->url($uMpUA);
    }
}
