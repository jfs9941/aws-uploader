<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Service\PP4BnfgX7sVAN;
final class OGmQ0hQJzIYby
{
    public const pY6BJ = 'v2/hls/';
    private $XnozO;
    private $gGE8I;
    public function __construct(PP4BnfgX7sVAN $LtUvT, Filesystem $duBfR)
    {
        $this->XnozO = $LtUvT;
        $this->gGE8I = $duBfR;
    }
    public function m8ERjHsMOsw($Ipllx) : string
    {
        return $this->XnozO->mMoRkdSHlVz(self::pY6BJ . $Ipllx->getAttribute('id') . '/');
    }
    public function mDGxAg2eqI5($Ipllx) : string
    {
        return $this->XnozO->mMoRkdSHlVz(self::pY6BJ . $Ipllx->getAttribute('id') . '/thumbnail/');
    }
    public function mYKQoYw70M6($Ipllx, $kY_V7 = true) : string
    {
        goto Ukd_M;
        Ukd_M:
        if ($kY_V7) {
            goto VdfC8;
        }
        goto ZTurw;
        qaCLK:
        return $this->XnozO->mMoRkdSHlVz(self::pY6BJ . $Ipllx->getAttribute('id') . '/' . $Ipllx->getAttribute('id') . '.m3u8');
        goto pfuxa;
        ZTurw:
        return self::pY6BJ . $Ipllx->getAttribute('id') . '/' . $Ipllx->getAttribute('id') . '.m3u8';
        goto I_ZXT;
        I_ZXT:
        VdfC8:
        goto qaCLK;
        pfuxa:
    }
    public function resolveThumbnail($Ipllx) : string
    {
        goto Qb_0i;
        tpL_X:
        return 1 == count($MmVmJ) ? self::pY6BJ . $ld8Ad . '/thumbnail/' . $ld8Ad . '.0000000.jpg' : self::pY6BJ . $ld8Ad . '/thumbnail/' . $ld8Ad . '.0000001.jpg';
        goto q2cRo;
        Qb_0i:
        $ld8Ad = $Ipllx->getAttribute('id');
        goto MsU4s;
        MsU4s:
        $MmVmJ = $this->gGE8I->files($this->mDGxAg2eqI5($Ipllx));
        goto tpL_X;
        q2cRo:
    }
    public function mD8czQZb8aT(string $jGQTt) : string
    {
        return $this->gGE8I->url($jGQTt);
    }
}
