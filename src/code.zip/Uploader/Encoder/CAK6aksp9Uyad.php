<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CAK6aksp9Uyad
{
    private $BvW5c;
    public function __construct(float $KDCmh, int $iBAp0, string $SPKog)
    {
        goto drOzn;
        q43ac:
        $this->BvW5c = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $MheB6]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $SPKog]]];
        goto DDtvv;
        Z2EOP:
        $MheB6 = max($MheB6, 1);
        goto q43ac;
        drOzn:
        $MheB6 = (int) $KDCmh / $iBAp0;
        goto Z2EOP;
        DDtvv:
    }
    public function m2lEzwsENk9() : array
    {
        return $this->BvW5c;
    }
}
