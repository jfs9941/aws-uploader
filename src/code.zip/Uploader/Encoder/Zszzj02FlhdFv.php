<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class Zszzj02FlhdFv
{
    private $cM9vR;
    public function __construct(string $CzRoa)
    {
        $this->cM9vR = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $CzRoa]];
    }
    public function mlrghGlIlaF() : array
    {
        return $this->cM9vR;
    }
}
