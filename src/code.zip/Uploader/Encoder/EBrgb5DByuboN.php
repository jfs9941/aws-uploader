<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Service\RiRUUwVHtq3AY;
use Illuminate\Contracts\Filesystem\Filesystem;
final class EBrgb5DByuboN
{
    public const YW2mW = 'v2/hls/';
    private $xBMY0;
    private $SxfKN;
    public function __construct(RiRUUwVHtq3AY $LmP6O, Filesystem $DPWG1)
    {
        $this->xBMY0 = $LmP6O;
        $this->SxfKN = $DPWG1;
    }
    public function m8zUVt0VPmE($UUt0Z) : string
    {
        return $this->xBMY0->mIPY8uGtSTG(self::YW2mW . $UUt0Z->getAttribute('id') . '/');
    }
    public function mA0L7sGffv3($UUt0Z) : string
    {
        return $this->xBMY0->mIPY8uGtSTG(self::YW2mW . $UUt0Z->getAttribute('id') . '/thumbnail/');
    }
    public function m4VPNsBV5Wk($UUt0Z, $X59pb = true) : string
    {
        goto fcd_u;
        Yrqwy:
        aEta1:
        goto XvBgh;
        XvBgh:
        return $this->xBMY0->mIPY8uGtSTG(self::YW2mW . $UUt0Z->getAttribute('id') . '/' . $UUt0Z->getAttribute('id') . '.m3u8');
        goto bFPCx;
        V8fEx:
        return self::YW2mW . $UUt0Z->getAttribute('id') . '/' . $UUt0Z->getAttribute('id') . '.m3u8';
        goto Yrqwy;
        fcd_u:
        if ($X59pb) {
            goto aEta1;
        }
        goto V8fEx;
        bFPCx:
    }
    public function resolveThumbnail($UUt0Z) : string
    {
        goto zVwYt;
        ASwfB:
        $Ybwit = $this->SxfKN->files($this->mA0L7sGffv3($UUt0Z));
        goto iOsmA;
        zVwYt:
        $GMwD5 = $UUt0Z->getAttribute('id');
        goto ASwfB;
        iOsmA:
        return 1 == count($Ybwit) ? self::YW2mW . $GMwD5 . '/thumbnail/' . $GMwD5 . '.0000000.jpg' : self::YW2mW . $GMwD5 . '/thumbnail/' . $GMwD5 . '.0000001.jpg';
        goto HS3bm;
        HS3bm:
    }
    public function myyDfaMyuGf(string $iTIh6) : string
    {
        return $this->SxfKN->url($iTIh6);
    }
}
