<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Service\HTG7kEjmlWunD;
final class PERAjoCXLxFkm
{
    public const ZUvsl = 'v2/hls/';
    private $Y6eRq;
    private $qrvF0;
    public function __construct(HTG7kEjmlWunD $bUBvu, Filesystem $eG_Pc)
    {
        $this->Y6eRq = $bUBvu;
        $this->qrvF0 = $eG_Pc;
    }
    public function mSVj4jx7Bwt($eYbzj) : string
    {
        return $this->Y6eRq->m73Uksv9AuA(self::ZUvsl . $eYbzj->getAttribute('id') . '/');
    }
    public function mu7BtR6dJe8($eYbzj) : string
    {
        return $this->Y6eRq->m73Uksv9AuA(self::ZUvsl . $eYbzj->getAttribute('id') . '/thumbnail/');
    }
    public function mhIk1ib73h3($eYbzj, $ueiP_ = true) : string
    {
        goto ZtpLK;
        kOpwk:
        return self::ZUvsl . $eYbzj->getAttribute('id') . '/' . $eYbzj->getAttribute('id') . '.m3u8';
        goto r2woN;
        Go22M:
        return $this->Y6eRq->m73Uksv9AuA(self::ZUvsl . $eYbzj->getAttribute('id') . '/' . $eYbzj->getAttribute('id') . '.m3u8');
        goto lyrtH;
        r2woN:
        juzaZ:
        goto Go22M;
        ZtpLK:
        if ($ueiP_) {
            goto juzaZ;
        }
        goto kOpwk;
        lyrtH:
    }
    public function resolveThumbnail($eYbzj) : string
    {
        goto iBrul;
        EVMLE:
        return 1 == count($YqCWq) ? self::ZUvsl . $ElvKF . '/thumbnail/' . $ElvKF . '.0000000.jpg' : self::ZUvsl . $ElvKF . '/thumbnail/' . $ElvKF . '.0000001.jpg';
        goto trdPH;
        iBrul:
        $ElvKF = $eYbzj->getAttribute('id');
        goto Dlz7Y;
        Dlz7Y:
        $YqCWq = $this->qrvF0->files($this->mu7BtR6dJe8($eYbzj));
        goto EVMLE;
        trdPH:
    }
    public function mrjnaXbXKd5(string $lmCO9) : string
    {
        return $this->qrvF0->url($lmCO9);
    }
}
