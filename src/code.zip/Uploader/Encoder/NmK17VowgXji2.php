<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class NmK17VowgXji2
{
    private $b5vzU;
    public function __construct(string $hqqZl, int $UWnwH, int $kr80a, ?int $tz4Lg, ?int $vmBjz)
    {
        goto Ij6f1;
        XfpcP:
        $this->b5vzU['ImageInserter']['InsertableImages'][0]['Height'] = $vmBjz;
        goto j7Tzv;
        RubPV:
        $this->b5vzU['ImageInserter']['InsertableImages'][0]['Width'] = $tz4Lg;
        goto XfpcP;
        j7Tzv:
        p_7Uz:
        goto N_h0A;
        Ij6f1:
        $this->b5vzU = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $UWnwH, 'ImageY' => $kr80a, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $hqqZl, 'Opacity' => 35]]]];
        goto ZSfi8;
        ZSfi8:
        if (!($tz4Lg && $vmBjz)) {
            goto p_7Uz;
        }
        goto RubPV;
        N_h0A:
    }
    public function mlrkLHVP2Ij() : array
    {
        return $this->b5vzU;
    }
}
