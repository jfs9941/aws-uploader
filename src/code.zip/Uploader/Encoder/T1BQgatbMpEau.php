<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\TSR3742mYKFfW;
final class T1BQgatbMpEau
{
    private $ZJFFj;
    public function __construct(string $RSRo0, ?int $tYCg4, ?int $Xnjcp, float $pnfiY)
    {
        goto lHVkj;
        EYpR2:
        lJLPi:
        goto r8n0k;
        aM0ve:
        MXD7_:
        goto B3QW0;
        M9LRn:
        if (!($tYCg4 && $Xnjcp)) {
            goto lJLPi;
        }
        goto X8X9b;
        u6Dxn:
        $this->ZJFFj['VideoDescription']['Height'] = $Xnjcp;
        goto EYpR2;
        X8X9b:
        $this->ZJFFj['VideoDescription']['Width'] = $tYCg4;
        goto u6Dxn;
        B3QW0:
        $this->ZJFFj = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $fuxwM, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $RSRo0];
        goto M9LRn;
        lHVkj:
        $fuxwM = 15000000;
        goto SQBl5;
        K2r6c:
        $fuxwM = $this->mMkNFE5zpgu($tYCg4, $Xnjcp, $pnfiY);
        goto aM0ve;
        SQBl5:
        if (!($tYCg4 && $Xnjcp)) {
            goto MXD7_;
        }
        goto K2r6c;
        r8n0k:
    }
    public function mXNYSK9aLXq(TSR3742mYKFfW $nI2zA) : self
    {
        $this->ZJFFj['VideoDescription']['VideoPreprocessors'] = $nI2zA->m2Z90b7p6qH();
        return $this;
    }
    public function mTZivmfM82L() : array
    {
        return $this->ZJFFj;
    }
    private function mMkNFE5zpgu(int $tYCg4, int $Xnjcp, float $AgJ3U, string $gzb3b = 'medium', string $WB6ih = 'h264', string $Rupcm = 'good') : ?int
    {
        goto tFmAh;
        gyad0:
        $qgtJU = 3;
        goto x0PJi;
        L_hSk:
        $qgtJU = 30;
        goto oLfBV;
        JpNuG:
        if ($EiDDw <= 1920 * 1080) {
            goto KGidd;
        }
        goto Ki_KI;
        yZQrP:
        switch (strtolower($Rupcm)) {
            case 'low':
                $CeX1Q *= 0.8;
                goto byQTk;
            case 'high':
                $CeX1Q *= 1.2;
                goto byQTk;
        }
        goto OYrWr;
        ZQ11Z:
        goto BRE6v;
        goto SG3EA;
        ufZhV:
        if ($EiDDw <= 640 * 480) {
            goto tUo75;
        }
        goto d4QaM;
        pHCsR:
        tUo75:
        goto xe5UF;
        wMVy7:
        cJffr:
        goto YdM4X;
        FZvUP:
        KGidd:
        goto mQZ1U;
        xe5UF:
        $qgtJU = 1.5;
        goto uyilA;
        O_QpB:
        $CeX1Q *= 0.65;
        goto tghFF;
        AmJHB:
        if (!('h265' === strtolower($WB6ih) || 'hevc' === strtolower($WB6ih) || 'vp9' === strtolower($WB6ih))) {
            goto JqaLE;
        }
        goto O_QpB;
        YdM4X:
        $qgtJU = 12;
        goto ZQ11Z;
        LcqhS:
        byQTk:
        goto b6DKE;
        Ki_KI:
        if ($EiDDw <= 2560 * 1440) {
            goto cJffr;
        }
        goto j5SXn;
        x0PJi:
        goto BRE6v;
        goto FZvUP;
        tghFF:
        JqaLE:
        goto yZQrP;
        en9tK:
        goto BRE6v;
        goto wMVy7;
        mQZ1U:
        $qgtJU = 7;
        goto en9tK;
        NszdV:
        switch (strtolower($gzb3b)) {
            case 'low':
                $CeX1Q *= 0.7;
                goto Ea15P;
            case 'high':
                $CeX1Q *= 1.3;
                goto Ea15P;
            case 'veryhigh':
                $CeX1Q *= 1.6;
                goto Ea15P;
        }
        goto jXqrH;
        OYrWr:
        VB51t:
        goto LcqhS;
        CpYG0:
        BRE6v:
        goto zSEY_;
        SG3EA:
        TXyF8:
        goto A92oF;
        tFmAh:
        $EiDDw = $tYCg4 * $Xnjcp;
        goto ufZhV;
        d4QaM:
        if ($EiDDw <= 1280 * 720) {
            goto eS5JS;
        }
        goto JpNuG;
        jXqrH:
        B4v3e:
        goto bQOFf;
        auZQr:
        eS5JS:
        goto gyad0;
        oLfBV:
        goto BRE6v;
        goto pHCsR;
        bQOFf:
        Ea15P:
        goto AmJHB;
        pVKX9:
        return (int) ($CeX1Q * 1000 * 1000);
        goto wcHFm;
        j5SXn:
        if ($EiDDw <= 3840 * 2160) {
            goto TXyF8;
        }
        goto L_hSk;
        zSEY_:
        $CeX1Q = $qgtJU * ($AgJ3U / 30);
        goto NszdV;
        A92oF:
        $qgtJU = 20;
        goto CpYG0;
        uyilA:
        goto BRE6v;
        goto auZQr;
        b6DKE:
        $CeX1Q = max(0.5, $CeX1Q);
        goto pVKX9;
        wcHFm:
    }
}
