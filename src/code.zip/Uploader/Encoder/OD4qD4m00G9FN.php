<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Q74VPxpLowiUP;
use Jfs\Uploader\Encoder\Zh4SBX5I0vF4X;
use Jfs\Uploader\Encoder\HaSCsbBEdqDr7;
use Illuminate\Support\Facades\Log;
final class OD4qD4m00G9FN
{
    private $l3HTe;
    private $ivApT;
    private $KHn6b;
    private $RUqS8;
    private $jLG1X;
    private $AxJkN;
    private $Ij3xP;
    public function __construct(MediaConvertClient $VjLVO, $kW_II, $xL0JM)
    {
        goto b6pvz;
        dw3pp:
        $this->AxJkN = $xL0JM;
        goto XJA5b;
        muBqr:
        $this->jLG1X = $kW_II;
        goto dw3pp;
        b6pvz:
        $this->RUqS8 = $VjLVO;
        goto muBqr;
        XJA5b:
    }
    public function m4lUsmE8wHo() : MediaConvertClient
    {
        return $this->RUqS8;
    }
    public function mIMmKaN0Oll(HaSCsbBEdqDr7 $RN5ea) : self
    {
        $this->l3HTe = $RN5ea;
        return $this;
    }
    public function mIeqICNq8Ll(string $bRtxN) : self
    {
        $this->KHn6b = $bRtxN;
        return $this;
    }
    public function mtjS3i8AWRq(Zh4SBX5I0vF4X $rgyps) : self
    {
        $this->ivApT[] = $rgyps;
        return $this;
    }
    public function mFt72TyHC7G(Q74VPxpLowiUP $eeT1E) : self
    {
        $this->Ij3xP = $eeT1E;
        return $this;
    }
    private function mtKKFmoEL9U(bool $tNiVZ) : array
    {
        goto L0NNy;
        ngfp5:
        if (!$tNiVZ) {
            goto jkJco;
        }
        goto nZZAN;
        LoaZL:
        $this->ivApT = [];
        goto iU9Z1;
        pL6tu:
        foreach ($this->ivApT as $rgyps) {
            $i34VG['Outputs'][] = $rgyps->mv59Wod72Ia();
            HcuRL:
        }
        goto f463Z;
        uacGT:
        $i34VG['Outputs'] = [];
        goto pL6tu;
        nMlmv:
        $this->l3HTe = null;
        goto LoaZL;
        f463Z:
        tCbAg:
        goto KoRkv;
        rlGmv:
        $f0C3Y['Settings']['Inputs'] = $this->l3HTe->mWEqeAxKzz9();
        goto c2Z6C;
        Ltvx5:
        $this->Ij3xP = null;
        goto nMlmv;
        wOYJ6:
        if (!$this->Ij3xP) {
            goto exYRk;
        }
        goto wnjFD;
        hF1jk:
        exYRk:
        goto ngfp5;
        wnjFD:
        $f0C3Y['Settings']['OutputGroups'][] = $this->Ij3xP->mXlWGmlfxqc();
        goto hF1jk;
        NEAqt:
        unset($f0C3Y['Settings']['OutputGroups']);
        goto uacGT;
        c2Z6C:
        $i34VG = $f0C3Y['Settings']['OutputGroups'][0];
        goto NEAqt;
        Uw1d_:
        MmhZT:
        goto rlGmv;
        B5f3G:
        $f0C3Y['Queue'] = $this->AxJkN;
        goto AN7lt;
        VQbHZ:
        jkJco:
        goto Ltvx5;
        KoRkv:
        $i34VG['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->KHn6b;
        goto js6I0;
        L0NNy:
        $f0C3Y = (require 'template.php');
        goto Sren7;
        nZZAN:
        $f0C3Y['AccelerationSettings']['Mode'] = 'ENABLED';
        goto VQbHZ;
        js6I0:
        $f0C3Y['Settings']['OutputGroups'][] = $i34VG;
        goto wOYJ6;
        Sren7:
        $f0C3Y['Role'] = $this->jLG1X;
        goto B5f3G;
        iU9Z1:
        return $f0C3Y;
        goto F2Mlk;
        PGGc_:
        throw new \LogicException('You must provide a input file to use');
        goto Uw1d_;
        AN7lt:
        if ($this->l3HTe) {
            goto MmhZT;
        }
        goto PGGc_;
        F2Mlk:
    }
    public function mn1CtQHvEKh(bool $tNiVZ = false) : string
    {
        try {
            $uyT2h = $this->RUqS8->createJob($this->mtKKFmoEL9U($tNiVZ));
            return $uyT2h->get('Job')['Id'];
        } catch (AwsException $R1uEk) {
            Log::error('Error creating MediaConvert job: ' . $R1uEk->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $R1uEk);
        }
    }
}
