<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Service\Vxy5RzsyYlKDb;
use Illuminate\Contracts\Filesystem\Filesystem;
final class XeMVcGXMtTgrJ
{
    public const ozFDt = 'v2/hls/';
    private $cLG_D;
    private $gErml;
    public function __construct(Vxy5RzsyYlKDb $vCrTa, Filesystem $DFpIk)
    {
        $this->cLG_D = $vCrTa;
        $this->gErml = $DFpIk;
    }
    public function mdkxdp2enva($Zpy0I) : string
    {
        return $this->cLG_D->mTU0gDxsVs7(self::ozFDt . $Zpy0I->getAttribute('id') . '/');
    }
    public function mUl9fifEdB6($Zpy0I) : string
    {
        return $this->cLG_D->mTU0gDxsVs7(self::ozFDt . $Zpy0I->getAttribute('id') . '/thumbnail/');
    }
    public function movLYqwhO6f($Zpy0I, $gX0Mq = true) : string
    {
        goto twWLP;
        twWLP:
        if ($gX0Mq) {
            goto KyLkR;
        }
        goto l22kh;
        C3mcd:
        KyLkR:
        goto Gtdmc;
        Gtdmc:
        return $this->cLG_D->mTU0gDxsVs7(self::ozFDt . $Zpy0I->getAttribute('id') . '/' . $Zpy0I->getAttribute('id') . '.m3u8');
        goto O6zAV;
        l22kh:
        return self::ozFDt . $Zpy0I->getAttribute('id') . '/' . $Zpy0I->getAttribute('id') . '.m3u8';
        goto C3mcd;
        O6zAV:
    }
    public function resolveThumbnail($Zpy0I) : string
    {
        goto u8zPY;
        YjD7B:
        return 1 == count($oik6g) ? self::ozFDt . $J_scC . '/thumbnail/' . $J_scC . '.0000000.jpg' : self::ozFDt . $J_scC . '/thumbnail/' . $J_scC . '.0000001.jpg';
        goto TSPxo;
        lqhXM:
        $oik6g = $this->gErml->files($this->mUl9fifEdB6($Zpy0I));
        goto YjD7B;
        u8zPY:
        $J_scC = $Zpy0I->getAttribute('id');
        goto lqhXM;
        TSPxo:
    }
    public function mRjcmjKGdcr(string $hU2b_) : string
    {
        return $this->gErml->url($hU2b_);
    }
}
