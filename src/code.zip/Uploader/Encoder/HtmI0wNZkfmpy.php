<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

class HtmI0wNZkfmpy
{
    private $PLX0U;
    public function __construct(float $TmAKp, int $M0WJt, string $yRYEz)
    {
        goto NDkg9;
        j68qP:
        $QJuxr = max($QJuxr, 1);
        goto S5CZl;
        NDkg9:
        $QJuxr = (int) $TmAKp / $M0WJt;
        goto j68qP;
        S5CZl:
        $this->PLX0U = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $QJuxr]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $yRYEz]]];
        goto TEIos;
        TEIos:
    }
    public function mtq7Y8emlXb() : array
    {
        return $this->PLX0U;
    }
}
