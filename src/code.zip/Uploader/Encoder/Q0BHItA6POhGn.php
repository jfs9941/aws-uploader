<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Service\KA9RxVwCbkfZQ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Q0BHItA6POhGn
{
    public const i1yO3 = 'v2/hls/';
    private $rlPHo;
    private $VJN91;
    public function __construct(KA9RxVwCbkfZQ $JfOlX, Filesystem $J83Op)
    {
        $this->rlPHo = $JfOlX;
        $this->VJN91 = $J83Op;
    }
    public function mj5X8Ukvo2M($hgsqV) : string
    {
        return $this->rlPHo->mLFqrKiNQ5K(self::i1yO3 . $hgsqV->getAttribute('id') . '/');
    }
    public function mv4HcxeNz7O($hgsqV) : string
    {
        return $this->rlPHo->mLFqrKiNQ5K(self::i1yO3 . $hgsqV->getAttribute('id') . '/thumbnail/');
    }
    public function maUW3CB8df3($hgsqV, $coOfM = true) : string
    {
        goto EwMX0;
        EwMX0:
        if ($coOfM) {
            goto E9vAO;
        }
        goto r9Lc_;
        elAxa:
        E9vAO:
        goto txEcZ;
        txEcZ:
        return $this->rlPHo->mLFqrKiNQ5K(self::i1yO3 . $hgsqV->getAttribute('id') . '/' . $hgsqV->getAttribute('id') . '.m3u8');
        goto tZT9P;
        r9Lc_:
        return self::i1yO3 . $hgsqV->getAttribute('id') . '/' . $hgsqV->getAttribute('id') . '.m3u8';
        goto elAxa;
        tZT9P:
    }
    public function resolveThumbnail($hgsqV) : string
    {
        goto pYKEA;
        BZlVt:
        return 1 == count($oxmmX) ? self::i1yO3 . $wAkkA . '/thumbnail/' . $wAkkA . '.0000000.jpg' : self::i1yO3 . $wAkkA . '/thumbnail/' . $wAkkA . '.0000001.jpg';
        goto YMWJP;
        pYKEA:
        $wAkkA = $hgsqV->getAttribute('id');
        goto aqh08;
        aqh08:
        $oxmmX = $this->VJN91->files($this->mv4HcxeNz7O($hgsqV));
        goto BZlVt;
        YMWJP:
    }
    public function mQZMYOhe80L(string $L5bJW) : string
    {
        return $this->VJN91->url($L5bJW);
    }
}
