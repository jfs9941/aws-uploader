<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Service\WK3vb1oP6Xm31;
final class LzL89H4g6zwMz
{
    public const Ii1Ld = 'v2/hls/';
    private $mmbW9;
    private $W_Kti;
    public function __construct(WK3vb1oP6Xm31 $Kacxo, Filesystem $agzKA)
    {
        $this->mmbW9 = $Kacxo;
        $this->W_Kti = $agzKA;
    }
    public function msFrbNLmSbV($aiCaH) : string
    {
        return $this->mmbW9->mfEtqflWIF3(self::Ii1Ld . $aiCaH->getAttribute('id') . '/');
    }
    public function m2SUp89509K($aiCaH) : string
    {
        return $this->mmbW9->mfEtqflWIF3(self::Ii1Ld . $aiCaH->getAttribute('id') . '/thumbnail/');
    }
    public function moFIXabgG3a($aiCaH, $ksNQ6 = true) : string
    {
        goto vlsRE;
        gbhyu:
        return $this->mmbW9->mfEtqflWIF3(self::Ii1Ld . $aiCaH->getAttribute('id') . '/' . $aiCaH->getAttribute('id') . '.m3u8');
        goto gqL2y;
        KRemx:
        return self::Ii1Ld . $aiCaH->getAttribute('id') . '/' . $aiCaH->getAttribute('id') . '.m3u8';
        goto cQneY;
        cQneY:
        F8Z26:
        goto gbhyu;
        vlsRE:
        if ($ksNQ6) {
            goto F8Z26;
        }
        goto KRemx;
        gqL2y:
    }
    public function resolveThumbnail($aiCaH) : string
    {
        goto R3fFh;
        aplUX:
        $NwKya = $this->W_Kti->files($this->m2SUp89509K($aiCaH));
        goto yW8QH;
        yW8QH:
        return 1 == count($NwKya) ? self::Ii1Ld . $y06DH . '/thumbnail/' . $y06DH . '.0000000.jpg' : self::Ii1Ld . $y06DH . '/thumbnail/' . $y06DH . '.0000001.jpg';
        goto CoP1n;
        R3fFh:
        $y06DH = $aiCaH->getAttribute('id');
        goto aplUX;
        CoP1n:
    }
    public function magG42MsIeB(string $IB9Pt) : string
    {
        return $this->W_Kti->url($IB9Pt);
    }
}
