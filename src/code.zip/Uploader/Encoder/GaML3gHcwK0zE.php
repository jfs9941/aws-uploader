<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class GaML3gHcwK0zE
{
    private $q4Ui5;
    public function __construct(float $J0pub, int $ZiO8x, string $fl6fW)
    {
        goto EZ9WZ;
        KvVCe:
        $this->q4Ui5 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $pKHcn]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $fl6fW]]];
        goto l1C_J;
        Io1eH:
        $pKHcn = max($pKHcn, 1);
        goto KvVCe;
        EZ9WZ:
        $pKHcn = (int) $J0pub / $ZiO8x;
        goto Io1eH;
        l1C_J:
    }
    public function mOIw5UiGIZm() : array
    {
        return $this->q4Ui5;
    }
}
