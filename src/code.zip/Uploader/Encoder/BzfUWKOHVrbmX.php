<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\JOc7tbmnzw0x2;
final class BzfUWKOHVrbmX
{
    private $Q51Ld;
    public function __construct(string $ODYlc, ?int $BmTCT, ?int $IkBoO, float $BoZLB)
    {
        goto ml718;
        QT5ri:
        tXNRO:
        goto We6lz;
        pbgbk:
        if (!($BmTCT && $IkBoO)) {
            goto XWXaO;
        }
        goto NzEcX;
        lCvwf:
        $this->Q51Ld = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $SlBtk, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $ODYlc];
        goto zp8K5;
        WaR0v:
        $this->Q51Ld['VideoDescription']['Height'] = $IkBoO;
        goto QT5ri;
        ml718:
        $SlBtk = 15000000;
        goto pbgbk;
        eQvIk:
        XWXaO:
        goto lCvwf;
        OYIzs:
        $this->Q51Ld['VideoDescription']['Width'] = $BmTCT;
        goto WaR0v;
        NzEcX:
        $SlBtk = $this->mRtqKVztC41($BmTCT, $IkBoO, $BoZLB);
        goto eQvIk;
        zp8K5:
        if (!($BmTCT && $IkBoO)) {
            goto tXNRO;
        }
        goto OYIzs;
        We6lz:
    }
    public function mQMmj8RRoI5(JOc7tbmnzw0x2 $Uj7rj) : self
    {
        $this->Q51Ld['VideoDescription']['VideoPreprocessors'] = $Uj7rj->mysXa5ST1p8();
        return $this;
    }
    public function mI3DxT6uOof() : array
    {
        return $this->Q51Ld;
    }
    private function mRtqKVztC41(int $BmTCT, int $IkBoO, float $R5L6K, string $rOHUu = 'medium', string $iLxy9 = 'h264', string $DNGpl = 'good') : ?int
    {
        goto ROk5I;
        VGCF0:
        if ($qyXVb <= 3840 * 2160) {
            goto XJENR;
        }
        goto XQ80v;
        QNAi2:
        goto z4M0M;
        goto mRI7c;
        utdab:
        if ($qyXVb <= 1280 * 720) {
            goto VE4NJ;
        }
        goto I2z2C;
        vPoky:
        oNlrH:
        goto RLvSf;
        KUW6L:
        $Rs9D6 = 20;
        goto VtYQP;
        sRqoX:
        $Rs9D6 = 7;
        goto ioemv;
        M0mYn:
        QUDJ3:
        goto A2DnZ;
        A0Vpg:
        if ($qyXVb <= 2560 * 1440) {
            goto i34xt;
        }
        goto VGCF0;
        LCoP0:
        if (!('h265' === strtolower($iLxy9) || 'hevc' === strtolower($iLxy9) || 'vp9' === strtolower($iLxy9))) {
            goto oNlrH;
        }
        goto vTRpx;
        mRI7c:
        TPJof:
        goto sRqoX;
        cp_Tg:
        $Rs9D6 = 12;
        goto lScT3;
        j1_At:
        mZb9I:
        goto M0mYn;
        d2CVL:
        goto z4M0M;
        goto bYJ2e;
        rLDdi:
        D5l9L:
        goto cPwQs;
        Y26fp:
        $Rs9D6 = 1.5;
        goto MiTwv;
        MiTwv:
        goto z4M0M;
        goto B2rWU;
        crJLx:
        $Rs9D6 = 3;
        goto QNAi2;
        TvJtp:
        switch (strtolower($rOHUu)) {
            case 'low':
                $YvNxY *= 0.7;
                goto IooWJ;
            case 'high':
                $YvNxY *= 1.3;
                goto IooWJ;
            case 'veryhigh':
                $YvNxY *= 1.6;
                goto IooWJ;
        }
        goto rLDdi;
        v5uqt:
        if ($qyXVb <= 640 * 480) {
            goto tZLYe;
        }
        goto utdab;
        VtYQP:
        z4M0M:
        goto J1UJ6;
        lScT3:
        goto z4M0M;
        goto Ca_VN;
        vTRpx:
        $YvNxY *= 0.65;
        goto vPoky;
        RLvSf:
        switch (strtolower($DNGpl)) {
            case 'low':
                $YvNxY *= 0.8;
                goto QUDJ3;
            case 'high':
                $YvNxY *= 1.2;
                goto QUDJ3;
        }
        goto j1_At;
        B2rWU:
        VE4NJ:
        goto crJLx;
        Ca_VN:
        XJENR:
        goto KUW6L;
        ioemv:
        goto z4M0M;
        goto Hm_ap;
        bYJ2e:
        tZLYe:
        goto Y26fp;
        XQ80v:
        $Rs9D6 = 30;
        goto d2CVL;
        bu4NP:
        return (int) ($YvNxY * 1000 * 1000);
        goto eRtBs;
        cPwQs:
        IooWJ:
        goto LCoP0;
        J1UJ6:
        $YvNxY = $Rs9D6 * ($R5L6K / 30);
        goto TvJtp;
        Hm_ap:
        i34xt:
        goto cp_Tg;
        ROk5I:
        $qyXVb = $BmTCT * $IkBoO;
        goto v5uqt;
        I2z2C:
        if ($qyXVb <= 1920 * 1080) {
            goto TPJof;
        }
        goto A0Vpg;
        A2DnZ:
        $YvNxY = max(0.5, $YvNxY);
        goto bu4NP;
        eRtBs:
    }
}
