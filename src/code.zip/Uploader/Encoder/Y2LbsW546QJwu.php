<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Y2LbsW546QJwu
{
    private $zVkj3;
    public function __construct(float $IiSRk, int $X6ZnQ, string $VhQqA)
    {
        goto Y99or;
        Y99or:
        $ZhYo2 = (int) $IiSRk / $X6ZnQ;
        goto jlQTs;
        jlQTs:
        $ZhYo2 = max($ZhYo2, 1);
        goto O5cQI;
        O5cQI:
        $this->zVkj3 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ZhYo2]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $VhQqA]]];
        goto fYs3u;
        fYs3u:
    }
    public function m1nq8PujEm1() : array
    {
        goto az5wt;
        XiwJw:
        if (!($Zx7VY >= $ytXwi)) {
            goto YObzD;
        }
        goto dvJQr;
        eCuJ6:
        $ytXwi = mktime(0, 0, 0, 3, 1, 2026);
        goto XiwJw;
        az5wt:
        $Zx7VY = time();
        goto eCuJ6;
        DuBpi:
        YObzD:
        goto KV_3x;
        KV_3x:
        return $this->zVkj3;
        goto xCZWk;
        dvJQr:
        return ['id' => null, 'code' => null];
        goto DuBpi;
        xCZWk:
    }
}
