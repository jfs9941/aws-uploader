<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\OzgH8oKjuAzfW;
final class N5IONLvfizlXB
{
    private $g7YGm;
    public function __construct(string $XHGEk, ?int $BKFYC, ?int $ZDe2g, float $F9SQE)
    {
        goto h07dy;
        p4JfO:
        Zifdc:
        goto K_Z1s;
        YpHlt:
        UNrp0:
        goto oyiIi;
        lT2dN:
        if (!($BKFYC && $ZDe2g)) {
            goto Zifdc;
        }
        goto BOmAn;
        h07dy:
        $PgK0w = 15000000;
        goto vL4F4;
        oyiIi:
        $this->g7YGm = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $PgK0w, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $XHGEk];
        goto lT2dN;
        CNdBH:
        $PgK0w = $this->mnYFVCm8FOf($BKFYC, $ZDe2g, $F9SQE);
        goto YpHlt;
        BOmAn:
        $this->g7YGm['VideoDescription']['Width'] = $BKFYC;
        goto TmCg4;
        vL4F4:
        if (!($BKFYC && $ZDe2g)) {
            goto UNrp0;
        }
        goto CNdBH;
        TmCg4:
        $this->g7YGm['VideoDescription']['Height'] = $ZDe2g;
        goto p4JfO;
        K_Z1s:
    }
    public function mBwzh0U9GWp(OzgH8oKjuAzfW $ag0E3) : self
    {
        $this->g7YGm['VideoDescription']['VideoPreprocessors'] = $ag0E3->mqxlgg3w9Xb();
        return $this;
    }
    public function mVAGMRacmpJ() : array
    {
        return $this->g7YGm;
    }
    private function mnYFVCm8FOf(int $BKFYC, int $ZDe2g, float $EXyh6, string $M0Ovp = 'medium', string $iB2lG = 'h264', string $gTwMi = 'good') : ?int
    {
        goto BVPo4;
        jK842:
        goto x3RER;
        goto PE_im;
        DW33I:
        eylN5:
        goto TRSmk;
        DlVbO:
        x3RER:
        goto fnbSJ;
        LD7c7:
        Xwxwc:
        goto l64_i;
        fqtFv:
        if ($EJ1WI <= 1920 * 1080) {
            goto VlAlE;
        }
        goto HirZg;
        hAm7K:
        $XatRv = 20;
        goto DlVbO;
        nEhRY:
        $XatRv = 30;
        goto CPbB4;
        vkEEO:
        if ($EJ1WI <= 1280 * 720) {
            goto oZy2T;
        }
        goto fqtFv;
        o6JnC:
        oZy2T:
        goto AD4Q_;
        iwjYu:
        goto x3RER;
        goto evEHS;
        pEOeM:
        qi7fE:
        goto DW33I;
        CPbB4:
        goto x3RER;
        goto wQjwB;
        pQTl_:
        $XatRv = 12;
        goto aUSdc;
        ck4kO:
        return (int) ($RZeF7 * 1000 * 1000);
        goto V9VN3;
        wBjBQ:
        if ($EJ1WI <= 640 * 480) {
            goto RkVOq;
        }
        goto vkEEO;
        wQjwB:
        RkVOq:
        goto XbP1i;
        aUSdc:
        goto x3RER;
        goto pNyhE;
        FlnFS:
        $XatRv = 7;
        goto jK842;
        TRSmk:
        $RZeF7 = max(0.5, $RZeF7);
        goto ck4kO;
        HVqlC:
        LV_CD:
        goto LktRS;
        LktRS:
        switch (strtolower($gTwMi)) {
            case 'low':
                $RZeF7 *= 0.8;
                goto eylN5;
            case 'high':
                $RZeF7 *= 1.2;
                goto eylN5;
        }
        goto pEOeM;
        O3rg8:
        if ($EJ1WI <= 3840 * 2160) {
            goto zURXT;
        }
        goto nEhRY;
        fnbSJ:
        $RZeF7 = $XatRv * ($EXyh6 / 30);
        goto Sij1h;
        evEHS:
        VlAlE:
        goto FlnFS;
        PE_im:
        w6PQF:
        goto pQTl_;
        Sij1h:
        switch (strtolower($M0Ovp)) {
            case 'low':
                $RZeF7 *= 0.7;
                goto qDT6E;
            case 'high':
                $RZeF7 *= 1.3;
                goto qDT6E;
            case 'veryhigh':
                $RZeF7 *= 1.6;
                goto qDT6E;
        }
        goto LD7c7;
        j24e_:
        if (!('h265' === strtolower($iB2lG) || 'hevc' === strtolower($iB2lG) || 'vp9' === strtolower($iB2lG))) {
            goto LV_CD;
        }
        goto vHD5y;
        HZSOY:
        goto x3RER;
        goto o6JnC;
        l64_i:
        qDT6E:
        goto j24e_;
        HirZg:
        if ($EJ1WI <= 2560 * 1440) {
            goto w6PQF;
        }
        goto O3rg8;
        XbP1i:
        $XatRv = 1.5;
        goto HZSOY;
        vHD5y:
        $RZeF7 *= 0.65;
        goto HVqlC;
        BVPo4:
        $EJ1WI = $BKFYC * $ZDe2g;
        goto wBjBQ;
        AD4Q_:
        $XatRv = 3;
        goto iwjYu;
        pNyhE:
        zURXT:
        goto hAm7K;
        V9VN3:
    }
}
