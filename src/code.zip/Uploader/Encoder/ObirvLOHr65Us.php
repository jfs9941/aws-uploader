<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\Ucavvzqn8yUfW;
final class ObirvLOHr65Us
{
    private $TEWn0;
    public function __construct(string $gc1pm, ?int $k2slg, ?int $vci_g, float $CJuZw)
    {
        goto ZUy9Z;
        NzQSh:
        if (!($k2slg && $vci_g)) {
            goto x6hvj;
        }
        goto thlW7;
        VMJ01:
        h9rvm:
        goto dZU9u;
        vMX_x:
        x6hvj:
        goto hwAuY;
        dZU9u:
        $this->TEWn0 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $zDCYy, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $gc1pm];
        goto NzQSh;
        x2NyI:
        $this->TEWn0['VideoDescription']['Height'] = $vci_g;
        goto vMX_x;
        SXHGp:
        $zDCYy = $this->muUORX5TPh0($k2slg, $vci_g, $CJuZw);
        goto VMJ01;
        thlW7:
        $this->TEWn0['VideoDescription']['Width'] = $k2slg;
        goto x2NyI;
        qv1J6:
        if (!($k2slg && $vci_g)) {
            goto h9rvm;
        }
        goto SXHGp;
        ZUy9Z:
        $zDCYy = 15000000;
        goto qv1J6;
        hwAuY:
    }
    public function mxcgeB787nR(Ucavvzqn8yUfW $VGZeQ) : self
    {
        $this->TEWn0['VideoDescription']['VideoPreprocessors'] = $VGZeQ->mx3KTArDUbC();
        return $this;
    }
    public function mLWKVbeM2x6() : array
    {
        return $this->TEWn0;
    }
    private function muUORX5TPh0(int $k2slg, int $vci_g, float $m7PMQ, string $neH9Q = 'medium', string $hleoT = 'h264', string $rFgpG = 'good') : ?int
    {
        goto tRGMI;
        AcAyx:
        goto HaWQQ;
        goto XzYqi;
        kVEPM:
        switch (strtolower($rFgpG)) {
            case 'low':
                $Kd6HC *= 0.8;
                goto mqdSu;
            case 'high':
                $Kd6HC *= 1.2;
                goto mqdSu;
        }
        goto IkjuX;
        nK0gG:
        goto HaWQQ;
        goto NpIgn;
        txQXk:
        $IFmpK = 12;
        goto auZ_2;
        cfnkk:
        Ek86m:
        goto BYtVf;
        pfLgF:
        if ($P3y40 <= 3840 * 2160) {
            goto Ek86m;
        }
        goto qa3Hf;
        tRGMI:
        $P3y40 = $k2slg * $vci_g;
        goto v8fbW;
        TMQNB:
        qFQ9O:
        goto kVEPM;
        g3fec:
        Dq72H:
        goto G4le8;
        aEuXD:
        $Kd6HC = $IFmpK * ($m7PMQ / 30);
        goto wu6Ty;
        v8fbW:
        if ($P3y40 <= 640 * 480) {
            goto KqrJn;
        }
        goto cjUPA;
        jZjyy:
        $IFmpK = 1.5;
        goto jrrWj;
        BYtVf:
        $IFmpK = 20;
        goto Jc1qx;
        ErS7s:
        if ($P3y40 <= 2560 * 1440) {
            goto itGuP;
        }
        goto pfLgF;
        MyqCD:
        $Kd6HC = max(0.5, $Kd6HC);
        goto OGTUV;
        G4le8:
        yClL7:
        goto T5qtq;
        IkjuX:
        RM5iA:
        goto pDtsn;
        XzYqi:
        KqrJn:
        goto jZjyy;
        s90Um:
        goto HaWQQ;
        goto QbhEx;
        uXrpn:
        $Kd6HC *= 0.65;
        goto TMQNB;
        cjUPA:
        if ($P3y40 <= 1280 * 720) {
            goto nssRX;
        }
        goto QEEbV;
        QbhEx:
        J815F:
        goto ZL1EE;
        qa3Hf:
        $IFmpK = 30;
        goto AcAyx;
        U9URR:
        nssRX:
        goto DwH1u;
        Jc1qx:
        HaWQQ:
        goto aEuXD;
        DwH1u:
        $IFmpK = 3;
        goto s90Um;
        wu6Ty:
        switch (strtolower($neH9Q)) {
            case 'low':
                $Kd6HC *= 0.7;
                goto yClL7;
            case 'high':
                $Kd6HC *= 1.3;
                goto yClL7;
            case 'veryhigh':
                $Kd6HC *= 1.6;
                goto yClL7;
        }
        goto g3fec;
        auZ_2:
        goto HaWQQ;
        goto cfnkk;
        pDtsn:
        mqdSu:
        goto MyqCD;
        T5qtq:
        if (!('h265' === strtolower($hleoT) || 'hevc' === strtolower($hleoT) || 'vp9' === strtolower($hleoT))) {
            goto qFQ9O;
        }
        goto uXrpn;
        jrrWj:
        goto HaWQQ;
        goto U9URR;
        OGTUV:
        return (int) ($Kd6HC * 1000 * 1000);
        goto ZdpaY;
        NpIgn:
        itGuP:
        goto txQXk;
        QEEbV:
        if ($P3y40 <= 1920 * 1080) {
            goto J815F;
        }
        goto ErS7s;
        ZL1EE:
        $IFmpK = 7;
        goto nK0gG;
        ZdpaY:
    }
}
