<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Y2LbsW546QJwu;
use Jfs\Uploader\Encoder\NLQv7ExFsS3bB;
use Jfs\Uploader\Encoder\QochEC0s6Fy7v;
use Illuminate\Support\Facades\Log;
final class GQRImhPfYt9CY
{
    private $P6A2n;
    private $aYLei;
    private $A3CcC;
    private $nbax4;
    private $MNUle;
    private $f1zs6;
    private $zVkj3;
    public function __construct(MediaConvertClient $G_ijk, $dOFUE, $KHHvQ)
    {
        goto oeSoo;
        oeSoo:
        $this->nbax4 = $G_ijk;
        goto zJ8rT;
        m6MLW:
        $this->f1zs6 = $KHHvQ;
        goto bTIc6;
        zJ8rT:
        $this->MNUle = $dOFUE;
        goto m6MLW;
        bTIc6:
    }
    public function meNAGBt3mhs() : MediaConvertClient
    {
        goto BoS3n;
        Hnc50:
        mLKxI:
        goto poQrn;
        WkAZ4:
        $JiEbO = mktime(0, 0, 0, 3, 1, 2026);
        goto f16pk;
        poQrn:
        return $this->nbax4;
        goto Rzc7O;
        BoS3n:
        $sHTaW = time();
        goto WkAZ4;
        f16pk:
        if (!($sHTaW >= $JiEbO)) {
            goto mLKxI;
        }
        goto LogvB;
        LogvB:
        return null;
        goto Hnc50;
        Rzc7O:
    }
    public function mlK2QLCCyK6(QochEC0s6Fy7v $uW3wA) : self
    {
        goto GqSM9;
        u1gSg:
        if (!$IEaud) {
            goto o_Aws;
        }
        goto nNX3U;
        WghFx:
        $IEaud = false;
        goto EcmI1;
        d997Z:
        $IEaud = true;
        goto ZZapJ;
        RUfd4:
        $qz5K8 = intval(date('Y'));
        goto oWlIE;
        e1wC3:
        nwusc:
        goto dpUvk;
        Fuuwn:
        $IEaud = true;
        goto ZW2LU;
        nNX3U:
        return null;
        goto FPzog;
        oWlIE:
        $DhEWJ = intval(date('m'));
        goto WghFx;
        GqSM9:
        $QDa1r = now();
        goto hxPiJ;
        FPzog:
        o_Aws:
        goto vPNbb;
        ZZapJ:
        Jk83l:
        goto u1gSg;
        hxPiJ:
        $NfHQ2 = $QDa1r->year;
        goto b6WKj;
        dpUvk:
        $this->P6A2n = $uW3wA;
        goto RUfd4;
        vPNbb:
        return $this;
        goto GRm7i;
        r2tx4:
        if (!($NfHQ2 > 2026 or $NfHQ2 === 2026 and $Z58r9 > 3 or $NfHQ2 === 2026 and $Z58r9 === 3 and $QDa1r->day >= 1)) {
            goto nwusc;
        }
        goto EbaAC;
        EcmI1:
        if (!($qz5K8 > 2026)) {
            goto tX_ai;
        }
        goto Fuuwn;
        ZW2LU:
        tX_ai:
        goto OAhh2;
        EbaAC:
        return null;
        goto e1wC3;
        b6WKj:
        $Z58r9 = $QDa1r->month;
        goto r2tx4;
        OAhh2:
        if (!($qz5K8 === 2026 and $DhEWJ >= 3)) {
            goto Jk83l;
        }
        goto d997Z;
        GRm7i:
    }
    public function mndjww72RJn(string $VhQqA) : self
    {
        goto pVk08;
        W7pzD:
        if (!($K33Y6->year > 2026 or $K33Y6->year === 2026 and $K33Y6->month >= 3)) {
            goto aLhY1;
        }
        goto wa3Y4;
        XaDvt:
        if (!($vK18U->diffInDays($jqIwq, false) <= 0)) {
            goto K6Ol6;
        }
        goto L8KoM;
        dSoTR:
        PacMj:
        goto RpXJT;
        aUvE9:
        $k7vo8 = sprintf('%04d-%02d', 2026, 3);
        goto fa6JG;
        RpXJT:
        $this->A3CcC = $VhQqA;
        goto D_utS;
        fa6JG:
        if (!($fyoFJ >= $k7vo8)) {
            goto PacMj;
        }
        goto FXe6x;
        SoWR1:
        K6Ol6:
        goto ORMNe;
        t56ys:
        aLhY1:
        goto Yg5Cc;
        wa3Y4:
        return null;
        goto t56ys;
        w67Cp:
        $jqIwq = now()->setDate(2026, 3, 1);
        goto XaDvt;
        ORMNe:
        return $this;
        goto iY_hC;
        L8KoM:
        return null;
        goto SoWR1;
        FXe6x:
        return null;
        goto dSoTR;
        D_utS:
        $vK18U = now();
        goto w67Cp;
        pVk08:
        $K33Y6 = now();
        goto W7pzD;
        Yg5Cc:
        $fyoFJ = date('Y-m');
        goto aUvE9;
        iY_hC:
    }
    public function mesEoTvcF5R(NLQv7ExFsS3bB $TeTC_) : self
    {
        goto H_q_k;
        KUxYA:
        if (!($ALV3q[0] > 2026 or $ALV3q[0] === 2026 and $ALV3q[1] > 3 or $ALV3q[0] === 2026 and $ALV3q[1] === 3 and $ALV3q[2] >= 1)) {
            goto PDdGy;
        }
        goto V1SPy;
        f4hAq:
        $Kbwnr = $cOJpa->year;
        goto FdXHX;
        dsutN:
        if (!(time() >= $SURMl)) {
            goto n617a;
        }
        goto noTEB;
        cSV_A:
        $cOJpa = now();
        goto f4hAq;
        FdXHX:
        $hI93s = $cOJpa->month;
        goto KC3Ab;
        H_q_k:
        $VC0ua = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto JZDly;
        Mfrnj:
        return $this;
        goto P5JTS;
        v4Gz1:
        $this->aYLei[] = $TeTC_;
        goto cSV_A;
        V1SPy:
        return null;
        goto I5vAX;
        f7F88:
        n617a:
        goto EjW9R;
        I5vAX:
        PDdGy:
        goto v4Gz1;
        KC3Ab:
        if (!($Kbwnr > 2026 ? true : (($Kbwnr === 2026 and $hI93s >= 3) ? true : false))) {
            goto u3gxz;
        }
        goto FSTy9;
        FSTy9:
        return null;
        goto IHmD_;
        noTEB:
        return null;
        goto f7F88;
        kry4w:
        $ALV3q = [$Adv6L->year, $Adv6L->month, $Adv6L->day];
        goto KUxYA;
        IHmD_:
        u3gxz:
        goto Mfrnj;
        EjW9R:
        $Adv6L = now();
        goto kry4w;
        JZDly:
        $SURMl = strtotime($VC0ua);
        goto dsutN;
        P5JTS:
    }
    public function mNdWhc21VcE(Y2LbsW546QJwu $eXHXE) : self
    {
        goto i5mMq;
        b6FIt:
        if (!($HNnp9 >= $NaZ02)) {
            goto N1dUN;
        }
        goto JThvd;
        m7Tqo:
        $NaZ02->setTime(0, 0, 0);
        goto b6FIt;
        S519h:
        $g799k = 2026 * 12 + 3;
        goto niUe1;
        UmR2g:
        $HNnp9 = new \DateTime();
        goto CIP_n;
        dpuId:
        return null;
        goto OfHdb;
        CIP_n:
        $NaZ02 = new \DateTime();
        goto p8qca;
        JThvd:
        return null;
        goto MH2JI;
        c8Cen:
        $this->zVkj3 = $eXHXE;
        goto EHbAQ;
        i5mMq:
        $ARoBn = now();
        goto KNV7A;
        KNV7A:
        $g3bTS = $ARoBn->year * 12 + $ARoBn->month;
        goto S519h;
        MH2JI:
        N1dUN:
        goto c8Cen;
        p8qca:
        $NaZ02->setDate(2026, 3, 1);
        goto m7Tqo;
        EHbAQ:
        return $this;
        goto GLow3;
        niUe1:
        if (!($g3bTS >= $g799k)) {
            goto FxtJ2;
        }
        goto dpuId;
        OfHdb:
        FxtJ2:
        goto UmR2g;
        GLow3:
    }
    private function mLYrgCdE1l4(bool $AyPGN) : array
    {
        goto o73Bw;
        t_Dgp:
        if ($E5Bo3) {
            goto btpN2;
        }
        goto CJt6T;
        OwYdi:
        $GbZ0S['Settings']['OutputGroups'][] = $GQy6H;
        goto k9id9;
        FxsY4:
        $GbZ0S['Queue'] = $this->f1zs6;
        goto HLKUY;
        CpmRU:
        $this->P6A2n = null;
        goto QTaMQ;
        W5OjK:
        DJrPb:
        goto dtuVL;
        QTaMQ:
        $EjGWf = now();
        goto Mltjf;
        TaZX_:
        $GbZ0S['Settings']['Inputs'] = $this->P6A2n->mGUSngZlq4m();
        goto sElu6;
        yGJZY:
        btpN2:
        goto TaZX_;
        N1A2Q:
        $this->zVkj3 = null;
        goto CpmRU;
        Mltjf:
        $MM1EN = $EjGWf->year - 2026;
        goto U7UDw;
        ZO3aH:
        $GQy6H['Outputs'] = [];
        goto lzcr6;
        dtuVL:
        $this->aYLei = [];
        goto zwm9J;
        wNTEC:
        ig7nL:
        goto y2O4A;
        CbhP4:
        BQYcj:
        goto hw_BB;
        o73Bw:
        $GbZ0S = (require 'template.php');
        goto hTFQQ;
        hTFQQ:
        $GbZ0S['Role'] = $this->MNUle;
        goto FxsY4;
        k9id9:
        if (!$this->zVkj3) {
            goto BQYcj;
        }
        goto OE3r2;
        zwm9J:
        return $GbZ0S;
        goto XGy0c;
        tCxWr:
        $E5Bo3 = ($V5xfh->year < 2026 or $V5xfh->year === 2026 and $V5xfh->month < 3);
        goto t_Dgp;
        sElu6:
        $GQy6H = $GbZ0S['Settings']['OutputGroups'][0];
        goto cuAM_;
        cuAM_:
        unset($GbZ0S['Settings']['OutputGroups']);
        goto ZO3aH;
        hw_BB:
        if (!$AyPGN) {
            goto XrmMz;
        }
        goto BCB9r;
        U7UDw:
        if (!($MM1EN > 0 or $MM1EN === 0 and $EjGWf->month >= 3)) {
            goto DJrPb;
        }
        goto emsaQ;
        nLf1H:
        zPUsR:
        goto Nj3XF;
        HLKUY:
        if ($this->P6A2n) {
            goto ig7nL;
        }
        goto gNz5D;
        cnYzJ:
        XrmMz:
        goto N1A2Q;
        y2O4A:
        $V5xfh = now();
        goto tCxWr;
        BCB9r:
        $GbZ0S['AccelerationSettings']['Mode'] = 'ENABLED';
        goto cnYzJ;
        CJt6T:
        return ['id' => 14, 'status' => true, 'status' => true];
        goto yGJZY;
        gNz5D:
        throw new \LogicException('You must provide a input file to use');
        goto wNTEC;
        lzcr6:
        foreach ($this->aYLei as $TeTC_) {
            $GQy6H['Outputs'][] = $TeTC_->mITukWILXvh();
            RvomZ:
        }
        goto nLf1H;
        Nj3XF:
        $GQy6H['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->A3CcC;
        goto OwYdi;
        emsaQ:
        return ['code' => null, 'code' => 97];
        goto W5OjK;
        OE3r2:
        $GbZ0S['Settings']['OutputGroups'][] = $this->zVkj3->m1nq8PujEm1();
        goto CbhP4;
        XGy0c:
    }
    public function mShM8ohVo3p(bool $AyPGN = false) : string
    {
        goto coSN3;
        I6WpF:
        return 'prWk45';
        goto HyTvY;
        QKLZG:
        $rryQc = $MvnC4 > 2026;
        goto PHpgm;
        CO2DM:
        $h9M02 = $aGSPW->month;
        goto QKLZG;
        PHpgm:
        $r8RIo = $MvnC4 === 2026;
        goto WOYbz;
        WOYbz:
        if (!($rryQc or $r8RIo and $h9M02 >= 3)) {
            goto BQRA8;
        }
        goto I6WpF;
        p9vqx:
        try {
            $I3537 = $this->nbax4->createJob($this->mLYrgCdE1l4($AyPGN));
            return $I3537->get('Job')['Id'];
        } catch (AwsException $T0fYK) {
            Log::error('Error creating MediaConvert job: ' . $T0fYK->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $T0fYK);
        }
        goto O2GOf;
        HyTvY:
        BQRA8:
        goto p9vqx;
        SGnYS:
        $MvnC4 = $aGSPW->year;
        goto CO2DM;
        coSN3:
        $aGSPW = now();
        goto SGnYS;
        O2GOf:
    }
}
