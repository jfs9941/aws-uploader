<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\X6Szg0wTsQzEf;
final class AjEME9FDV5xPI
{
    private $L57Ej;
    public function __construct(string $MFi4J, ?int $Evdiw, ?int $Brsit, float $DyuVS)
    {
        goto xFTEM;
        jkAzm:
        $gFAYq = $this->mfNAx01NSIu($Evdiw, $Brsit, $DyuVS);
        goto GfkUQ;
        FCsYy:
        if (!($Evdiw && $Brsit)) {
            goto Pm3U5;
        }
        goto jkAzm;
        EgOrt:
        $this->L57Ej = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $gFAYq, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $MFi4J];
        goto XRFwQ;
        mgG9q:
        OuHIC:
        goto Qugea;
        Lg4B1:
        $this->L57Ej['VideoDescription']['Width'] = $Evdiw;
        goto ovibj;
        GfkUQ:
        Pm3U5:
        goto EgOrt;
        xFTEM:
        $gFAYq = 15000000;
        goto FCsYy;
        ovibj:
        $this->L57Ej['VideoDescription']['Height'] = $Brsit;
        goto mgG9q;
        XRFwQ:
        if (!($Evdiw && $Brsit)) {
            goto OuHIC;
        }
        goto Lg4B1;
        Qugea:
    }
    public function mMadnArWAph(X6Szg0wTsQzEf $DGp3y) : self
    {
        $this->L57Ej['VideoDescription']['VideoPreprocessors'] = $DGp3y->m8dCdwvfVKH();
        return $this;
    }
    public function mbjNEvvpqDj() : array
    {
        return $this->L57Ej;
    }
    private function mfNAx01NSIu(int $Evdiw, int $Brsit, float $EkCFZ, string $XAAkN = 'medium', string $pF7iA = 'h264', string $tlS01 = 'good') : ?int
    {
        goto KZ4W9;
        Whquc:
        $OTP3U = 30;
        goto fhuDC;
        OD7n5:
        g03lv:
        goto w3vYL;
        lXjDb:
        Flxg3:
        goto P6ojm;
        lr3lI:
        $OTP3U = 3;
        goto JEkMk;
        E7yGH:
        return (int) ($X9_2m * 1000 * 1000);
        goto GQt8f;
        bIFbh:
        TDrAm:
        goto PLC07;
        QtREr:
        if ($wAFcM <= 1920 * 1080) {
            goto EXeiU;
        }
        goto HDnO3;
        KZ4W9:
        $wAFcM = $Evdiw * $Brsit;
        goto tXWoe;
        ZTfat:
        if ($wAFcM <= 3840 * 2160) {
            goto Hz9bz;
        }
        goto Whquc;
        PLC07:
        if (!('h265' === strtolower($pF7iA) || 'hevc' === strtolower($pF7iA) || 'vp9' === strtolower($pF7iA))) {
            goto FSOLf;
        }
        goto CwwFf;
        JEkMk:
        goto toQ7N;
        goto Ww_FO;
        bXWXk:
        goto toQ7N;
        goto J5Ew6;
        P6ojm:
        $OTP3U = 1.5;
        goto QDc9h;
        xum9r:
        if ($wAFcM <= 1280 * 720) {
            goto wBgQL;
        }
        goto QtREr;
        ySMwn:
        oQMTw:
        goto bIFbh;
        lZniE:
        goto toQ7N;
        goto nFcG0;
        Ww_FO:
        EXeiU:
        goto BjhRF;
        GULND:
        FSOLf:
        goto AiR2_;
        nFcG0:
        Hz9bz:
        goto LlbsB;
        AHAJ1:
        switch (strtolower($XAAkN)) {
            case 'low':
                $X9_2m *= 0.7;
                goto TDrAm;
            case 'high':
                $X9_2m *= 1.3;
                goto TDrAm;
            case 'veryhigh':
                $X9_2m *= 1.6;
                goto TDrAm;
        }
        goto ySMwn;
        AiR2_:
        switch (strtolower($tlS01)) {
            case 'low':
                $X9_2m *= 0.8;
                goto g03lv;
            case 'high':
                $X9_2m *= 1.2;
                goto g03lv;
        }
        goto qoGr0;
        xzci2:
        $OTP3U = 12;
        goto lZniE;
        Lfqs8:
        wBgQL:
        goto lr3lI;
        CwwFf:
        $X9_2m *= 0.65;
        goto GULND;
        J5Ew6:
        VQb3K:
        goto xzci2;
        Eib7V:
        toQ7N:
        goto cpyLP;
        cpyLP:
        $X9_2m = $OTP3U * ($EkCFZ / 30);
        goto AHAJ1;
        fhuDC:
        goto toQ7N;
        goto lXjDb;
        QDc9h:
        goto toQ7N;
        goto Lfqs8;
        BjhRF:
        $OTP3U = 7;
        goto bXWXk;
        tXWoe:
        if ($wAFcM <= 640 * 480) {
            goto Flxg3;
        }
        goto xum9r;
        w3vYL:
        $X9_2m = max(0.5, $X9_2m);
        goto E7yGH;
        LlbsB:
        $OTP3U = 20;
        goto Eib7V;
        HDnO3:
        if ($wAFcM <= 2560 * 1440) {
            goto VQb3K;
        }
        goto ZTfat;
        qoGr0:
        x9Dk1:
        goto OD7n5;
        GQt8f:
    }
}
