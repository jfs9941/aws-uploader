<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Ye5PnDSJctWEA
{
    private $vo8A1;
    public function __construct(float $M3O_T, int $aO3L1, string $F53lY)
    {
        goto n7QZp;
        n7QZp:
        $gkAnF = (int) $M3O_T / $aO3L1;
        goto dkqTE;
        oxkgA:
        $this->vo8A1 = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $gkAnF]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $F53lY]]];
        goto KUc5t;
        dkqTE:
        $gkAnF = max($gkAnF, 1);
        goto oxkgA;
        KUc5t:
    }
    public function msVKtm0fuSf() : array
    {
        return $this->vo8A1;
    }
}
