<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\NmK17VowgXji2;
final class WsTEbWEHtefqv
{
    private $tQDQO;
    public function __construct(string $MMHCz, ?int $tz4Lg, ?int $vmBjz, float $xjHVw)
    {
        goto qjNIN;
        KXJ_7:
        IQjiG:
        goto xE81p;
        swcKy:
        $this->tQDQO = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $TPvjF, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $MMHCz];
        goto Oh461;
        qjNIN:
        $TPvjF = 15000000;
        goto EjKhB;
        pxdLN:
        $this->tQDQO['VideoDescription']['Height'] = $vmBjz;
        goto KXJ_7;
        EjKhB:
        if (!($tz4Lg && $vmBjz)) {
            goto Ta0si;
        }
        goto aaBjw;
        OnXWz:
        Ta0si:
        goto swcKy;
        Oh461:
        if (!($tz4Lg && $vmBjz)) {
            goto IQjiG;
        }
        goto ywDZp;
        aaBjw:
        $TPvjF = $this->moYta4FAuj3($tz4Lg, $vmBjz, $xjHVw);
        goto OnXWz;
        ywDZp:
        $this->tQDQO['VideoDescription']['Width'] = $tz4Lg;
        goto pxdLN;
        xE81p:
    }
    public function m4kFWHhTxOv(NmK17VowgXji2 $l80kV) : self
    {
        $this->tQDQO['VideoDescription']['VideoPreprocessors'] = $l80kV->mlrkLHVP2Ij();
        return $this;
    }
    public function mq7FJEdH7av() : array
    {
        return $this->tQDQO;
    }
    private function moYta4FAuj3(int $tz4Lg, int $vmBjz, float $DaB4A, string $aqa81 = 'medium', string $Kf16b = 'h264', string $U8nnD = 'good') : ?int
    {
        goto pKXFV;
        Oxoyc:
        K1tE0:
        goto CBz39;
        zzo5x:
        $n6Sq1 = 3;
        goto W2uoj;
        aUlEw:
        goto LX3BL;
        goto EDbxt;
        W2uoj:
        goto LX3BL;
        goto kpp9E;
        ngEdC:
        switch (strtolower($aqa81)) {
            case 'low':
                $opP7o *= 0.7;
                goto qoljA;
            case 'high':
                $opP7o *= 1.3;
                goto qoljA;
            case 'veryhigh':
                $opP7o *= 1.6;
                goto qoljA;
        }
        goto yFlWX;
        B1v0H:
        goto LX3BL;
        goto cHzFv;
        cHzFv:
        f53w5:
        goto zzo5x;
        Hh1gI:
        if ($yfFqK <= 1920 * 1080) {
            goto pNGuU;
        }
        goto KarYn;
        CBz39:
        switch (strtolower($U8nnD)) {
            case 'low':
                $opP7o *= 0.8;
                goto rkirt;
            case 'high':
                $opP7o *= 1.2;
                goto rkirt;
        }
        goto BC23z;
        yFlWX:
        uX9uN:
        goto qCR1a;
        EDbxt:
        r1Iwi:
        goto jG233;
        lrMwl:
        if ($yfFqK <= 3840 * 2160) {
            goto Rx25n;
        }
        goto GjBar;
        MRaED:
        $opP7o *= 0.65;
        goto Oxoyc;
        GS5Eh:
        $n6Sq1 = 7;
        goto aUlEw;
        qCR1a:
        qoljA:
        goto jVJdP;
        BNNpN:
        LX3BL:
        goto qItI6;
        JutHA:
        Rx25n:
        goto Ah6p2;
        NarIg:
        return (int) ($opP7o * 1000 * 1000);
        goto fufoK;
        KarYn:
        if ($yfFqK <= 2560 * 1440) {
            goto r1Iwi;
        }
        goto lrMwl;
        BC23z:
        xEWg6:
        goto G3lRL;
        jVJdP:
        if (!('h265' === strtolower($Kf16b) || 'hevc' === strtolower($Kf16b) || 'vp9' === strtolower($Kf16b))) {
            goto K1tE0;
        }
        goto MRaED;
        lA3ta:
        goto LX3BL;
        goto JutHA;
        jG233:
        $n6Sq1 = 12;
        goto lA3ta;
        adtvt:
        $n6Sq1 = 1.5;
        goto B1v0H;
        QEYYg:
        $opP7o = max(0.5, $opP7o);
        goto NarIg;
        GjBar:
        $n6Sq1 = 30;
        goto gLMJO;
        k6GRo:
        AP2hI:
        goto adtvt;
        pKXFV:
        $yfFqK = $tz4Lg * $vmBjz;
        goto K8s5W;
        Ah6p2:
        $n6Sq1 = 20;
        goto BNNpN;
        kpp9E:
        pNGuU:
        goto GS5Eh;
        qItI6:
        $opP7o = $n6Sq1 * ($DaB4A / 30);
        goto ngEdC;
        K8s5W:
        if ($yfFqK <= 640 * 480) {
            goto AP2hI;
        }
        goto SqDxR;
        gLMJO:
        goto LX3BL;
        goto k6GRo;
        G3lRL:
        rkirt:
        goto QEYYg;
        SqDxR:
        if ($yfFqK <= 1280 * 720) {
            goto f53w5;
        }
        goto Hh1gI;
        fufoK:
    }
}
