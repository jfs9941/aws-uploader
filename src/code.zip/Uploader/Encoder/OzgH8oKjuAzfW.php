<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class OzgH8oKjuAzfW
{
    private $u2N3t;
    public function __construct(string $kNjqU, int $BF8aj, int $jRc5F, ?int $BKFYC, ?int $ZDe2g)
    {
        goto aqjAg;
        kXWjp:
        Ex9x4:
        goto eYyFk;
        WhA7m:
        $this->u2N3t['ImageInserter']['InsertableImages'][0]['Width'] = $BKFYC;
        goto Oxo_h;
        b86me:
        if (!($BKFYC && $ZDe2g)) {
            goto Ex9x4;
        }
        goto WhA7m;
        Oxo_h:
        $this->u2N3t['ImageInserter']['InsertableImages'][0]['Height'] = $ZDe2g;
        goto kXWjp;
        aqjAg:
        $this->u2N3t = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $BF8aj, 'ImageY' => $jRc5F, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $kNjqU, 'Opacity' => 35]]]];
        goto b86me;
        eYyFk:
    }
    public function mqxlgg3w9Xb() : array
    {
        return $this->u2N3t;
    }
}
