<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Service\VjtcOzJCF9Hx7;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ZgEcV5Ek5Li7G
{
    public const OhSoU = 'v2/hls/';
    private $InW5c;
    private $wEVdN;
    public function __construct(VjtcOzJCF9Hx7 $JpnD6, Filesystem $dzspH)
    {
        $this->InW5c = $JpnD6;
        $this->wEVdN = $dzspH;
    }
    public function mCoC5vTxQn5($ZtI9P) : string
    {
        return $this->InW5c->m98cY8xF205(self::OhSoU . $ZtI9P->getAttribute('id') . '/');
    }
    public function m0kOO0ha6Bj($ZtI9P) : string
    {
        return $this->InW5c->m98cY8xF205(self::OhSoU . $ZtI9P->getAttribute('id') . '/thumbnail/');
    }
    public function m6bfafCHknX($ZtI9P, $g5NWc = true) : string
    {
        goto b0R7d;
        llbIo:
        return self::OhSoU . $ZtI9P->getAttribute('id') . '/' . $ZtI9P->getAttribute('id') . '.m3u8';
        goto ewoRg;
        b0R7d:
        if ($g5NWc) {
            goto vzfbE;
        }
        goto llbIo;
        ewoRg:
        vzfbE:
        goto JdXCO;
        JdXCO:
        return $this->InW5c->m98cY8xF205(self::OhSoU . $ZtI9P->getAttribute('id') . '/' . $ZtI9P->getAttribute('id') . '.m3u8');
        goto U6USK;
        U6USK:
    }
    public function resolveThumbnail($ZtI9P) : string
    {
        goto ZNvm0;
        ZNvm0:
        $hOWbX = $ZtI9P->getAttribute('id');
        goto W5uTc;
        W5uTc:
        $IlvN_ = $this->wEVdN->files($this->m0kOO0ha6Bj($ZtI9P));
        goto pcSda;
        pcSda:
        return 1 == count($IlvN_) ? self::OhSoU . $hOWbX . '/thumbnail/' . $hOWbX . '.0000000.jpg' : self::OhSoU . $hOWbX . '/thumbnail/' . $hOWbX . '.0000001.jpg';
        goto SHoNO;
        SHoNO:
    }
    public function m6R9ADhmT2K(string $D4enG) : string
    {
        return $this->wEVdN->url($D4enG);
    }
}
