<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Service\SqWT6oYd97hAj;
final class WKWBYhZhEWOea
{
    public const r4Bo3 = 'v2/hls/';
    private $CiQ3J;
    private $dhrkT;
    public function __construct(SqWT6oYd97hAj $jgYSY, Filesystem $v8n0s)
    {
        $this->CiQ3J = $jgYSY;
        $this->dhrkT = $v8n0s;
    }
    public function mfwMNRrlKMs($WKps1) : string
    {
        return $this->CiQ3J->m6XZqiSGZzc(self::r4Bo3 . $WKps1->getAttribute('id') . '/');
    }
    public function mNysMat2axz($WKps1) : string
    {
        return $this->CiQ3J->m6XZqiSGZzc(self::r4Bo3 . $WKps1->getAttribute('id') . '/thumbnail/');
    }
    public function mIZHkld0SHw($WKps1, $gK0v4 = true) : string
    {
        goto Z3Zsg;
        vlh2Q:
        return $this->CiQ3J->m6XZqiSGZzc(self::r4Bo3 . $WKps1->getAttribute('id') . '/' . $WKps1->getAttribute('id') . '.m3u8');
        goto XDRfI;
        JrLtj:
        eZ3S6:
        goto vlh2Q;
        fxvHk:
        return self::r4Bo3 . $WKps1->getAttribute('id') . '/' . $WKps1->getAttribute('id') . '.m3u8';
        goto JrLtj;
        Z3Zsg:
        if ($gK0v4) {
            goto eZ3S6;
        }
        goto fxvHk;
        XDRfI:
    }
    public function resolveThumbnail($WKps1) : string
    {
        goto ZSFj6;
        RWXu7:
        $uclEW = $this->dhrkT->files($this->mNysMat2axz($WKps1));
        goto jvl2_;
        jvl2_:
        return 1 == count($uclEW) ? self::r4Bo3 . $cQqZd . '/thumbnail/' . $cQqZd . '.0000000.jpg' : self::r4Bo3 . $cQqZd . '/thumbnail/' . $cQqZd . '.0000001.jpg';
        goto sLqmy;
        ZSFj6:
        $cQqZd = $WKps1->getAttribute('id');
        goto RWXu7;
        sLqmy:
    }
    public function mmCrXMwm8In(string $IJqE5) : string
    {
        return $this->dhrkT->url($IJqE5);
    }
}
