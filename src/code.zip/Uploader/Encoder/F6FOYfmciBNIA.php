<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class F6FOYfmciBNIA
{
    private $E2Ayt;
    public function __construct(string $qDM8c, int $xVAYU, int $CVqNV, ?int $w0IG6, ?int $sIm70)
    {
        goto U2dlM;
        T3xiG:
        if (!($w0IG6 && $sIm70)) {
            goto Fnzyk;
        }
        goto wQldB;
        FMTmG:
        Fnzyk:
        goto bszcF;
        us_93:
        $this->E2Ayt['ImageInserter']['InsertableImages'][0]['Height'] = $sIm70;
        goto FMTmG;
        wQldB:
        $this->E2Ayt['ImageInserter']['InsertableImages'][0]['Width'] = $w0IG6;
        goto us_93;
        U2dlM:
        $this->E2Ayt = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $xVAYU, 'ImageY' => $CVqNV, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $qDM8c, 'Opacity' => 35]]]];
        goto T3xiG;
        bszcF:
    }
    public function mFLdtLE9Fb0() : array
    {
        return $this->E2Ayt;
    }
}
