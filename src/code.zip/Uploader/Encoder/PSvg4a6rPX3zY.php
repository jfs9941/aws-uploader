<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class PSvg4a6rPX3zY
{
    private $aUZVO;
    private $XP0P_;
    private $kOiqX;
    private $dGeI9;
    private $vXHAl;
    private $Y6LAH;
    private $VPjF9;
    public function __construct(MediaConvertClient $pop03, $JxUL3, $oo9eG)
    {
        goto SavpS;
        F05hv:
        $this->vXHAl = $JxUL3;
        goto VaIWV;
        SavpS:
        $this->dGeI9 = $pop03;
        goto F05hv;
        VaIWV:
        $this->Y6LAH = $oo9eG;
        goto S1pUa;
        S1pUa:
    }
    public function mBbHcnFzgQY() : MediaConvertClient
    {
        return $this->dGeI9;
    }
    public function mzedKEYcGcA(Vgz1Jn4ZgdZ37 $iIE8I) : self
    {
        $this->aUZVO = $iIE8I;
        return $this;
    }
    public function m3c7HKHoooK(string $hbG6Q) : self
    {
        $this->kOiqX = $hbG6Q;
        return $this;
    }
    public function m8SNYxL0llb(RO20FOPlN3fZQ $e7I5b) : self
    {
        $this->XP0P_[] = $e7I5b;
        return $this;
    }
    public function mBIEkztvl3g(PAx9IusVgAzRb $NSw82) : self
    {
        $this->VPjF9 = $NSw82;
        return $this;
    }
    private function myJXaWX2Ov1(bool $a0NOY) : array
    {
        goto gSGDr;
        PbWwX:
        $FYGuT['Role'] = $this->vXHAl;
        goto iq3HE;
        RkNJr:
        unHY4:
        goto fpA2x;
        Wv1Pf:
        $FYGuT['Settings']['OutputGroups'][] = $this->VPjF9->mR9mqb3l39c();
        goto y8DNd;
        fpA2x:
        $this->VPjF9 = null;
        goto ciipC;
        y8DNd:
        nllFv:
        goto Dln7N;
        EjXLQ:
        $FYGuT['Settings']['OutputGroups'][] = $qhaik;
        goto asrzA;
        lmYII:
        return $FYGuT;
        goto MCWUg;
        U6dja:
        $qhaik['Outputs'] = [];
        goto Ako1J;
        dTtVV:
        $FYGuT['AccelerationSettings']['Mode'] = 'ENABLED';
        goto RkNJr;
        asrzA:
        if (!$this->VPjF9) {
            goto nllFv;
        }
        goto Wv1Pf;
        vk18B:
        Wx_tB:
        goto eLazp;
        cfw1d:
        $qhaik['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->kOiqX;
        goto EjXLQ;
        Ako1J:
        foreach ($this->XP0P_ as $e7I5b) {
            $qhaik['Outputs'][] = $e7I5b->m80fZpJQGHe();
            hhsw7:
        }
        goto hISqe;
        ciipC:
        $this->aUZVO = null;
        goto KDiHm;
        KDiHm:
        $this->XP0P_ = [];
        goto lmYII;
        Dln7N:
        if (!$a0NOY) {
            goto unHY4;
        }
        goto dTtVV;
        pwcGd:
        throw new \LogicException('You must provide a input file to use');
        goto vk18B;
        mqrZj:
        $qhaik = $FYGuT['Settings']['OutputGroups'][0];
        goto oEUE3;
        hISqe:
        Ho2fT:
        goto cfw1d;
        gSGDr:
        $FYGuT = (require 'template.php');
        goto PbWwX;
        iq3HE:
        $FYGuT['Queue'] = $this->Y6LAH;
        goto yLXmr;
        oEUE3:
        unset($FYGuT['Settings']['OutputGroups']);
        goto U6dja;
        eLazp:
        $FYGuT['Settings']['Inputs'] = $this->aUZVO->mRiCdX6W6oj();
        goto mqrZj;
        yLXmr:
        if ($this->aUZVO) {
            goto Wx_tB;
        }
        goto pwcGd;
        MCWUg:
    }
    public function m7cvyyyEKtp(bool $a0NOY = false) : string
    {
        try {
            $rvOSs = $this->dGeI9->createJob($this->myJXaWX2Ov1($a0NOY));
            return $rvOSs->get('Jobs')['Id'];
        } catch (AwsException $djmN_) {
            Log::error('Error creating MediaConvert job: ' . $djmN_->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $djmN_);
        }
    }
}
