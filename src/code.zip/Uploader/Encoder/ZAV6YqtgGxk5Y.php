<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class ZAV6YqtgGxk5Y
{
    private $aht5Z;
    public function __construct(string $izJkp)
    {
        $this->aht5Z = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $izJkp]];
    }
    public function mvSWXiDnjA3() : array
    {
        return $this->aht5Z;
    }
}
