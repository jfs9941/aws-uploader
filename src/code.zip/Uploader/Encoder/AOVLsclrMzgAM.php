<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Du6R3WXKXjwE4;
use Jfs\Uploader\Encoder\WsTEbWEHtefqv;
use Jfs\Uploader\Encoder\T5yvSbVhcIDJU;
use Illuminate\Support\Facades\Log;
final class AOVLsclrMzgAM
{
    private $X2mD2;
    private $SkLSJ;
    private $V_SFm;
    private $doty3;
    private $BwNKu;
    private $CI2r8;
    private $AN0O0;
    public function __construct(MediaConvertClient $K06at, $ZMdaq, $Xv9R9)
    {
        goto HYmV0;
        fmXKU:
        $this->CI2r8 = $Xv9R9;
        goto af0qE;
        MKGbp:
        $this->BwNKu = $ZMdaq;
        goto fmXKU;
        HYmV0:
        $this->doty3 = $K06at;
        goto MKGbp;
        af0qE:
    }
    public function mH8zdEXCydi() : MediaConvertClient
    {
        return $this->doty3;
    }
    public function mMlllWaNf6p(T5yvSbVhcIDJU $sHsZJ) : self
    {
        $this->X2mD2 = $sHsZJ;
        return $this;
    }
    public function mfgWd86e8fk(string $qvtuE) : self
    {
        $this->V_SFm = $qvtuE;
        return $this;
    }
    public function mKmhR9ypYTz(WsTEbWEHtefqv $P8mMq) : self
    {
        $this->SkLSJ[] = $P8mMq;
        return $this;
    }
    public function maQVxVjaJzf(Du6R3WXKXjwE4 $uTfBu) : self
    {
        $this->AN0O0 = $uTfBu;
        return $this;
    }
    private function mM73KGFH9IR(bool $bOuwi) : array
    {
        goto tfgOV;
        S9rGd:
        $this->SkLSJ = [];
        goto OivPI;
        X22KY:
        $krcLS['Queue'] = $this->CI2r8;
        goto qx1tT;
        r9Xka:
        throw new \LogicException('You must provide a input file to use');
        goto j1igx;
        Lpoxq:
        $krcLS['Settings']['OutputGroups'][] = $this->AN0O0->mRJnXAbYcqZ();
        goto sBqVm;
        ac_Nu:
        $C1ra2['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->V_SFm;
        goto KVGul;
        tfgOV:
        $krcLS = (require 'template.php');
        goto nFWE3;
        gTkoU:
        $krcLS['Settings']['Inputs'] = $this->X2mD2->m4etLLz1qEk();
        goto LL99o;
        BpkhH:
        if (!$bOuwi) {
            goto a2lNu;
        }
        goto L4SO6;
        b4FPz:
        L1hIm:
        goto ac_Nu;
        L4SO6:
        $krcLS['AccelerationSettings']['Mode'] = 'ENABLED';
        goto HYvGa;
        eDEge:
        $this->AN0O0 = null;
        goto QCaiJ;
        QCaiJ:
        $this->X2mD2 = null;
        goto S9rGd;
        LL99o:
        $C1ra2 = $krcLS['Settings']['OutputGroups'][0];
        goto ZCYl6;
        OivPI:
        return $krcLS;
        goto OlwBF;
        nFWE3:
        $krcLS['Role'] = $this->BwNKu;
        goto X22KY;
        j1igx:
        KwKxm:
        goto gTkoU;
        sBqVm:
        jYYa4:
        goto BpkhH;
        KVGul:
        $krcLS['Settings']['OutputGroups'][] = $C1ra2;
        goto lLATM;
        ZCYl6:
        unset($krcLS['Settings']['OutputGroups']);
        goto CCALv;
        HYvGa:
        a2lNu:
        goto eDEge;
        GCEb8:
        foreach ($this->SkLSJ as $P8mMq) {
            $C1ra2['Outputs'][] = $P8mMq->mq7FJEdH7av();
            USdVK:
        }
        goto b4FPz;
        qx1tT:
        if ($this->X2mD2) {
            goto KwKxm;
        }
        goto r9Xka;
        lLATM:
        if (!$this->AN0O0) {
            goto jYYa4;
        }
        goto Lpoxq;
        CCALv:
        $C1ra2['Outputs'] = [];
        goto GCEb8;
        OlwBF:
    }
    public function moR1n97kuyV(bool $bOuwi = false) : string
    {
        try {
            $DUsxo = $this->doty3->createJob($this->mM73KGFH9IR($bOuwi));
            return $DUsxo->get('Job')['Id'];
        } catch (AwsException $wEHhy) {
            Log::error('Error creating MediaConvert job: ' . $wEHhy->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $wEHhy);
        }
    }
}
