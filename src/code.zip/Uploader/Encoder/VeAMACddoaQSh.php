<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\KzJu0aOFp1hnH;
final class VeAMACddoaQSh
{
    private $syAHv;
    public function __construct(string $WNNjX, ?int $tp6F0, ?int $iNVXG, float $YxNBL)
    {
        goto ZJS1w;
        aPnCT:
        if (!($tp6F0 && $iNVXG)) {
            goto oFXXW;
        }
        goto LNpMG;
        H0VEO:
        $this->syAHv['VideoDescription']['Width'] = $tp6F0;
        goto xN_qe;
        xN_qe:
        $this->syAHv['VideoDescription']['Height'] = $iNVXG;
        goto JpM6t;
        ZJS1w:
        $nClSQ = 15000000;
        goto aPnCT;
        JpM6t:
        oQsgc:
        goto QBNfd;
        LNpMG:
        $nClSQ = $this->mo4iYrvq1vA($tp6F0, $iNVXG, $YxNBL);
        goto I17hz;
        I17hz:
        oFXXW:
        goto Bimuo;
        nnkhm:
        if (!($tp6F0 && $iNVXG)) {
            goto oQsgc;
        }
        goto H0VEO;
        Bimuo:
        $this->syAHv = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $nClSQ, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $WNNjX];
        goto nnkhm;
        QBNfd:
    }
    public function mpqgOq1k8le(KzJu0aOFp1hnH $rJ0Rd) : self
    {
        $this->syAHv['VideoDescription']['VideoPreprocessors'] = $rJ0Rd->mQNlPxzu3Xl();
        return $this;
    }
    public function mqEWILuYzMq() : array
    {
        return $this->syAHv;
    }
    private function mo4iYrvq1vA(int $tp6F0, int $iNVXG, float $IW8f8, string $laUvb = 'medium', string $WOpBO = 'h264', string $qaQ8M = 'good') : ?int
    {
        goto qBoJn;
        cZ0OO:
        $Az_P2 = 3;
        goto uy3AZ;
        Yuubh:
        return (int) ($J1ZBu * 1000 * 1000);
        goto khKhe;
        CtMEQ:
        Q3Lb8:
        goto RdFLJ;
        mSY32:
        if ($qy14O <= 3840 * 2160) {
            goto dboQ3;
        }
        goto QeGzW;
        qBoJn:
        $qy14O = $tp6F0 * $iNVXG;
        goto So2Iq;
        Lbk9k:
        $Az_P2 = 20;
        goto pQvox;
        Fk_Ng:
        xe5n_:
        goto W3CaZ;
        CbZO0:
        dboQ3:
        goto Lbk9k;
        QeGzW:
        $Az_P2 = 30;
        goto n5UU5;
        HntgM:
        dAiKD:
        goto nAscg;
        u6hT8:
        pRTuO:
        goto Ry5LX;
        ZX1TA:
        nYfpC:
        goto u6hT8;
        Xtman:
        $Az_P2 = 12;
        goto GqJBf;
        PTVfb:
        $J1ZBu = $Az_P2 * ($IW8f8 / 30);
        goto Mh2Dv;
        WIPrv:
        goto CYuru;
        goto UbDmk;
        Ry5LX:
        $J1ZBu = max(0.5, $J1ZBu);
        goto Yuubh;
        OaT6g:
        TDRw3:
        goto CtMEQ;
        GqJBf:
        goto CYuru;
        goto CbZO0;
        pQvox:
        CYuru:
        goto PTVfb;
        j0ZXE:
        if ($qy14O <= 1280 * 720) {
            goto YpxSe;
        }
        goto aBGXB;
        YhBzc:
        pJJfi:
        goto Xtman;
        RdFLJ:
        if (!('h265' === strtolower($WOpBO) || 'hevc' === strtolower($WOpBO) || 'vp9' === strtolower($WOpBO))) {
            goto Ig1Jo;
        }
        goto eNq25;
        UbDmk:
        YpxSe:
        goto cZ0OO;
        n5UU5:
        goto CYuru;
        goto Fk_Ng;
        nAscg:
        $Az_P2 = 7;
        goto kO0De;
        J00hI:
        Ig1Jo:
        goto sndHa;
        uy3AZ:
        goto CYuru;
        goto HntgM;
        eNq25:
        $J1ZBu *= 0.65;
        goto J00hI;
        sndHa:
        switch (strtolower($qaQ8M)) {
            case 'low':
                $J1ZBu *= 0.8;
                goto pRTuO;
            case 'high':
                $J1ZBu *= 1.2;
                goto pRTuO;
        }
        goto ZX1TA;
        m1_Yj:
        if ($qy14O <= 2560 * 1440) {
            goto pJJfi;
        }
        goto mSY32;
        kO0De:
        goto CYuru;
        goto YhBzc;
        W3CaZ:
        $Az_P2 = 1.5;
        goto WIPrv;
        So2Iq:
        if ($qy14O <= 640 * 480) {
            goto xe5n_;
        }
        goto j0ZXE;
        Mh2Dv:
        switch (strtolower($laUvb)) {
            case 'low':
                $J1ZBu *= 0.7;
                goto Q3Lb8;
            case 'high':
                $J1ZBu *= 1.3;
                goto Q3Lb8;
            case 'veryhigh':
                $J1ZBu *= 1.6;
                goto Q3Lb8;
        }
        goto OaT6g;
        aBGXB:
        if ($qy14O <= 1920 * 1080) {
            goto dAiKD;
        }
        goto m1_Yj;
        khKhe:
    }
}
