<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Zp6bjD8AQnl45
{
    private $vygGL;
    public function __construct(string $FJv5i, int $vb2Qp, int $B1PYY, ?int $yRrbE, ?int $aQb9L)
    {
        goto j5rrf;
        VktTD:
        ssW4U:
        goto irvrU;
        CKq1d:
        $this->vygGL['ImageInserter']['InsertableImages'][0]['Width'] = $yRrbE;
        goto Y941J;
        j5rrf:
        $this->vygGL = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $vb2Qp, 'ImageY' => $B1PYY, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $FJv5i, 'Opacity' => 35]]]];
        goto xNLbi;
        Y941J:
        $this->vygGL['ImageInserter']['InsertableImages'][0]['Height'] = $aQb9L;
        goto VktTD;
        xNLbi:
        if (!($yRrbE && $aQb9L)) {
            goto ssW4U;
        }
        goto CKq1d;
        irvrU:
    }
    public function mtNCFM7h3pf() : array
    {
        return $this->vygGL;
    }
}
