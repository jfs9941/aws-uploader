<?php
declare(strict_types=1);

namespace Jfs\Uploader\Encoder;

class Watermark
{
    private $watermark;

    public function __construct(string $s3Uri, int $x, int $y, ?int $width, ?int $height)
    {
        $this->watermark = [
            'ImageInserter' => [
                'InsertableImages' => [
                    [
                        'ImageX' => $x,
                        'ImageY' => $y,
                        'StartTime' => '00:00:00:00',
                        'Layer' => 0,
                        'ImageInserterInput' => $s3Uri,
                        'Opacity' => 35,
                    ],
                ],
            ],
        ];
        if ($width && $height) {
            $this->watermark['ImageInserter']['InsertableImages'][0]['Width'] = $width;
            $this->watermark['ImageInserter']['InsertableImages'][0]['Height'] = $height;
        }
    }

    public function getWatermark(): array
    {
        return $this->watermark;
    }
}
