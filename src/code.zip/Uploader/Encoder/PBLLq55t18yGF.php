<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\DqtyTdqDXiARq;
use Jfs\Uploader\Encoder\XmIUTGy65GCBf;
use Jfs\Uploader\Encoder\J7daXwtzv3QYS;
use Illuminate\Support\Facades\Log;
final class PBLLq55t18yGF
{
    private $t0hrK;
    private $Zh9rJ;
    private $Ww4Zh;
    private $hbyDA;
    private $jAVID;
    private $PopD2;
    private $r1f8r;
    public function __construct(MediaConvertClient $rXMAL, $igkM1, $hvW2u)
    {
        goto NlCwM;
        NlCwM:
        $this->hbyDA = $rXMAL;
        goto eg2Gp;
        mbcgF:
        $this->PopD2 = $hvW2u;
        goto HIWm6;
        eg2Gp:
        $this->jAVID = $igkM1;
        goto mbcgF;
        HIWm6:
    }
    public function mUjfgBd9w3R() : MediaConvertClient
    {
        return $this->hbyDA;
    }
    public function mdHGFiK9opO(J7daXwtzv3QYS $oIcEz) : self
    {
        $this->t0hrK = $oIcEz;
        return $this;
    }
    public function mCDHuWcYHCY(string $pMiNc) : self
    {
        $this->Ww4Zh = $pMiNc;
        return $this;
    }
    public function mT8dO9E71jK(XmIUTGy65GCBf $T_ECO) : self
    {
        $this->Zh9rJ[] = $T_ECO;
        return $this;
    }
    public function mgJwyiXLves(DqtyTdqDXiARq $cOdCv) : self
    {
        $this->r1f8r = $cOdCv;
        return $this;
    }
    private function mdITsIwWCah(bool $knfij) : array
    {
        goto xdwLp;
        wKwyf:
        $this->Zh9rJ = [];
        goto kPtjS;
        lXhVl:
        $this->t0hrK = null;
        goto wKwyf;
        MLqaZ:
        $fv4mS['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->Ww4Zh;
        goto YEXti;
        LJ_Ai:
        $by1Sq['Settings']['OutputGroups'][] = $this->r1f8r->m5F2lwOBL1s();
        goto P2Kcz;
        yoc_9:
        if (!$this->r1f8r) {
            goto yk5er;
        }
        goto LJ_Ai;
        VDCPa:
        $by1Sq['Role'] = $this->jAVID;
        goto wyE1g;
        ybVJ_:
        JOtFS:
        goto MLqaZ;
        YtYAj:
        $fv4mS = $by1Sq['Settings']['OutputGroups'][0];
        goto VwpoN;
        q26Rc:
        $by1Sq['Settings']['Inputs'] = $this->t0hrK->mY6UMWIZpLA();
        goto YtYAj;
        TkDVP:
        $fv4mS['Outputs'] = [];
        goto Hct5x;
        wyE1g:
        $by1Sq['Queue'] = $this->PopD2;
        goto iRZoM;
        Hct5x:
        foreach ($this->Zh9rJ as $T_ECO) {
            $fv4mS['Outputs'][] = $T_ECO->mfp7hvtKsYo();
            NV7V1:
        }
        goto ybVJ_;
        YEXti:
        $by1Sq['Settings']['OutputGroups'][] = $fv4mS;
        goto yoc_9;
        CefSb:
        throw new \LogicException('You must provide a input file to use');
        goto XQKqY;
        P2Kcz:
        yk5er:
        goto ubdn9;
        xdwLp:
        $by1Sq = (require 'template.php');
        goto VDCPa;
        iRZoM:
        if ($this->t0hrK) {
            goto qXSCV;
        }
        goto CefSb;
        VwpoN:
        unset($by1Sq['Settings']['OutputGroups']);
        goto TkDVP;
        WSGRI:
        IO5L_:
        goto Qxkbx;
        Qxkbx:
        $this->r1f8r = null;
        goto lXhVl;
        ubdn9:
        if (!$knfij) {
            goto IO5L_;
        }
        goto ypnET;
        kPtjS:
        return $by1Sq;
        goto AfqpR;
        XQKqY:
        qXSCV:
        goto q26Rc;
        ypnET:
        $by1Sq['AccelerationSettings']['Mode'] = 'ENABLED';
        goto WSGRI;
        AfqpR:
    }
    public function moLasCdrpJY(bool $knfij = false) : string
    {
        try {
            $vnyRY = $this->hbyDA->createJob($this->mdITsIwWCah($knfij));
            return $vnyRY->get('Job')['Id'];
        } catch (AwsException $Jtg9A) {
            Log::error('Error creating MediaConvert job: ' . $Jtg9A->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $Jtg9A);
        }
    }
}
