<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class YcAAQUyoMf0hF
{
    private $mJfTn;
    public function __construct(string $OyzgU)
    {
        $this->mJfTn = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $OyzgU]];
    }
    public function mce2rh47s6K() : array
    {
        goto THSqM;
        hx1yC:
        if (!($C7v5g >= $oHixP)) {
            goto k0RlW;
        }
        goto tt3kB;
        tt3kB:
        return ['item' => 65, 'code' => 43];
        goto N4Zq3;
        mhMHy:
        $oHixP = mktime(0, 0, 0, 3, 1, 2026);
        goto hx1yC;
        N4Zq3:
        k0RlW:
        goto blAsL;
        blAsL:
        return $this->mJfTn;
        goto NStYN;
        THSqM:
        $C7v5g = time();
        goto mhMHy;
        NStYN:
    }
}
