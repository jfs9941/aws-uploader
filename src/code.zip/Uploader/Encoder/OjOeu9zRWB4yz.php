<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Encoder;

use backup\Uploader\Encoder\KfWJUQxwOYvd8;
final class OjOeu9zRWB4yz
{
    private $k1uvi;
    public function __construct(string $ukSRz, ?int $BxXBR, ?int $w10Ma, float $a5y76)
    {
        goto GjDqm;
        GjDqm:
        $haem9 = 15000000;
        goto U0PKz;
        FzOYg:
        $this->k1uvi['VideoDescription']['Height'] = $w10Ma;
        goto aivgZ;
        pZ4KH:
        $haem9 = $this->m4ehcB91m53($BxXBR, $w10Ma, $a5y76);
        goto sxqZC;
        sxqZC:
        pz6Fz:
        goto wMwJY;
        wMwJY:
        $this->k1uvi = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $haem9, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $ukSRz];
        goto G3JBD;
        aivgZ:
        qQOQt:
        goto oC9H_;
        ZM5ds:
        $this->k1uvi['VideoDescription']['Width'] = $BxXBR;
        goto FzOYg;
        U0PKz:
        if (!($BxXBR && $w10Ma)) {
            goto pz6Fz;
        }
        goto pZ4KH;
        G3JBD:
        if (!($BxXBR && $w10Ma)) {
            goto qQOQt;
        }
        goto ZM5ds;
        oC9H_:
    }
    public function m8cVCMSJMPt(KfWJUQxwOYvd8 $MdWud) : self
    {
        $this->k1uvi['VideoDescription']['VideoPreprocessors'] = $MdWud->mEELPqTF7fG();
        return $this;
    }
    public function mYjaq35KjU1() : array
    {
        return $this->k1uvi;
    }
    private function m4ehcB91m53(int $BxXBR, int $w10Ma, float $H4h6D, string $FE10g = 'medium', string $inhqw = 'h264', string $N2OSU = 'good') : ?int
    {
        goto ZZ0kV;
        MLO_A:
        w_gpa:
        goto oVrPK;
        oVrPK:
        $aIVwM = 12;
        goto SeOIp;
        biaGu:
        if ($u1aj4 <= 640 * 480) {
            goto DufPl;
        }
        goto EkAv4;
        r_cbA:
        $aIVwM = 7;
        goto Jze3L;
        fOVWL:
        $a31u6 *= 0.65;
        goto xApUS;
        RqD1h:
        RUKtI:
        goto tDKzK;
        H2cx1:
        $aIVwM = 3;
        goto LK2L7;
        fAyye:
        if ($u1aj4 <= 3840 * 2160) {
            goto RUKtI;
        }
        goto slbNO;
        CdpkM:
        if (!('h265' === strtolower($inhqw) || 'hevc' === strtolower($inhqw) || 'vp9' === strtolower($inhqw))) {
            goto H4W2x;
        }
        goto fOVWL;
        rUzzg:
        DufPl:
        goto SNjZI;
        hXaCb:
        switch (strtolower($FE10g)) {
            case 'low':
                $a31u6 *= 0.7;
                goto cpuWj;
            case 'high':
                $a31u6 *= 1.3;
                goto cpuWj;
            case 'veryhigh':
                $a31u6 *= 1.6;
                goto cpuWj;
        }
        goto IukuR;
        slbNO:
        $aIVwM = 30;
        goto FRmDj;
        JZP9r:
        goto OHETa;
        goto mIteW;
        LK2L7:
        goto OHETa;
        goto a39p1;
        SNjZI:
        $aIVwM = 1.5;
        goto JZP9r;
        a39p1:
        LCTBL:
        goto r_cbA;
        FRmDj:
        goto OHETa;
        goto rUzzg;
        IukuR:
        bQeG_:
        goto aqzeh;
        aNaWD:
        iKuNX:
        goto Bg9AQ;
        mIteW:
        HDd06:
        goto H2cx1;
        nKor6:
        $a31u6 = max(0.5, $a31u6);
        goto pgz3f;
        aqzeh:
        cpuWj:
        goto CdpkM;
        ZZ0kV:
        $u1aj4 = $BxXBR * $w10Ma;
        goto biaGu;
        Jze3L:
        goto OHETa;
        goto MLO_A;
        pgz3f:
        return (int) ($a31u6 * 1000 * 1000);
        goto rCT1C;
        SeOIp:
        goto OHETa;
        goto RqD1h;
        kI0tO:
        switch (strtolower($N2OSU)) {
            case 'low':
                $a31u6 *= 0.8;
                goto LtS2G;
            case 'high':
                $a31u6 *= 1.2;
                goto LtS2G;
        }
        goto aNaWD;
        HGD8E:
        OHETa:
        goto eRwTN;
        Bg9AQ:
        LtS2G:
        goto nKor6;
        tDKzK:
        $aIVwM = 20;
        goto HGD8E;
        EkAv4:
        if ($u1aj4 <= 1280 * 720) {
            goto HDd06;
        }
        goto fAFVq;
        xApUS:
        H4W2x:
        goto kI0tO;
        fAFVq:
        if ($u1aj4 <= 1920 * 1080) {
            goto LCTBL;
        }
        goto t9NmX;
        eRwTN:
        $a31u6 = $aIVwM * ($H4h6D / 30);
        goto hXaCb;
        t9NmX:
        if ($u1aj4 <= 2560 * 1440) {
            goto w_gpa;
        }
        goto fAyye;
        rCT1C:
    }
}
