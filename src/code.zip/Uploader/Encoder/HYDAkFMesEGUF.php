<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Service\EjF4mjWaYHYqw;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HYDAkFMesEGUF
{
    public const jR1Dg = 'v2/hls/';
    private $rwJ8s;
    private $VV2A8;
    public function __construct(EjF4mjWaYHYqw $moIQT, Filesystem $oOPBt)
    {
        $this->rwJ8s = $moIQT;
        $this->VV2A8 = $oOPBt;
    }
    public function ms5A2GnsX86($bKijV) : string
    {
        return $this->rwJ8s->mCs8X0WLjcY(self::jR1Dg . $bKijV->getAttribute('id') . '/');
    }
    public function mBcSpYDylRi($bKijV) : string
    {
        return $this->rwJ8s->mCs8X0WLjcY(self::jR1Dg . $bKijV->getAttribute('id') . '/thumbnail/');
    }
    public function mjdALMG3NcH($bKijV, $KxZ4V = true) : string
    {
        goto Bk2vu;
        J3uIZ:
        return self::jR1Dg . $bKijV->getAttribute('id') . '/' . $bKijV->getAttribute('id') . '.m3u8';
        goto JV5Ys;
        JV5Ys:
        BL4i9:
        goto eRzv5;
        Bk2vu:
        if ($KxZ4V) {
            goto BL4i9;
        }
        goto J3uIZ;
        eRzv5:
        return $this->rwJ8s->mCs8X0WLjcY(self::jR1Dg . $bKijV->getAttribute('id') . '/' . $bKijV->getAttribute('id') . '.m3u8');
        goto QLTPi;
        QLTPi:
    }
    public function resolveThumbnail($bKijV) : string
    {
        goto ylKgi;
        qnxTO:
        $GA5_K = $this->VV2A8->files($this->mBcSpYDylRi($bKijV));
        goto MXy0l;
        ylKgi:
        $GhyxD = $bKijV->getAttribute('id');
        goto qnxTO;
        MXy0l:
        return 1 == count($GA5_K) ? self::jR1Dg . $GhyxD . '/thumbnail/' . $GhyxD . '.0000000.jpg' : self::jR1Dg . $GhyxD . '/thumbnail/' . $GhyxD . '.0000001.jpg';
        goto HwOeR;
        HwOeR:
    }
    public function mKua6Zpfcfj(string $yRiLu) : string
    {
        return $this->VV2A8->url($yRiLu);
    }
}
