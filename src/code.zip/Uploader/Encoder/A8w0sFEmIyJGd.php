<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Service\WqQUjHBw41oKQ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class A8w0sFEmIyJGd
{
    public const qREjK = 'v2/hls/';
    private $DkFF_;
    private $Mayr9;
    public function __construct(WqQUjHBw41oKQ $paMBW, Filesystem $KI4Gx)
    {
        $this->DkFF_ = $paMBW;
        $this->Mayr9 = $KI4Gx;
    }
    public function mWDWYOqR3MC($aHaxS) : string
    {
        return $this->DkFF_->mLlkzeq9PSv(self::qREjK . $aHaxS->getAttribute('id') . '/');
    }
    public function mTmWGUwCChs($aHaxS) : string
    {
        return $this->DkFF_->mLlkzeq9PSv(self::qREjK . $aHaxS->getAttribute('id') . '/thumbnail/');
    }
    public function mVod7cfuD9c($aHaxS, $yLn7v = true) : string
    {
        goto I7SXV;
        SfFMf:
        return self::qREjK . $aHaxS->getAttribute('id') . '/' . $aHaxS->getAttribute('id') . '.m3u8';
        goto KZCBK;
        fOjMy:
        return $this->DkFF_->mLlkzeq9PSv(self::qREjK . $aHaxS->getAttribute('id') . '/' . $aHaxS->getAttribute('id') . '.m3u8');
        goto qxYdR;
        KZCBK:
        XOcnR:
        goto fOjMy;
        I7SXV:
        if ($yLn7v) {
            goto XOcnR;
        }
        goto SfFMf;
        qxYdR:
    }
    public function resolveThumbnail($aHaxS) : string
    {
        goto Z_6zu;
        Z_6zu:
        $iG1wy = $aHaxS->getAttribute('id');
        goto rpgcR;
        cRZ85:
        return 1 == count($ycEz7) ? self::qREjK . $iG1wy . '/thumbnail/' . $iG1wy . '.0000000.jpg' : self::qREjK . $iG1wy . '/thumbnail/' . $iG1wy . '.0000001.jpg';
        goto Oam5y;
        rpgcR:
        $ycEz7 = $this->Mayr9->files($this->mTmWGUwCChs($aHaxS));
        goto cRZ85;
        Oam5y:
    }
    public function mb0qVG2pWTu(string $HCRCz) : string
    {
        return $this->Mayr9->url($HCRCz);
    }
}
