<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\CAK6aksp9Uyad;
use Jfs\Uploader\Encoder\Tp9NT29QRCL9S;
use Jfs\Uploader\Encoder\SbhemT8X5X1z8;
use Illuminate\Support\Facades\Log;
final class HYHb7A2L6Ex2n
{
    private $An_lX;
    private $p02Jq;
    private $EeXIh;
    private $MCKWR;
    private $UHKqK;
    private $ARvnk;
    private $BvW5c;
    public function __construct(MediaConvertClient $lFfFM, $Or2PA, $rgE1q)
    {
        goto CfRPv;
        CfRPv:
        $this->MCKWR = $lFfFM;
        goto tHbe2;
        h4ScM:
        $this->ARvnk = $rgE1q;
        goto mPQsu;
        tHbe2:
        $this->UHKqK = $Or2PA;
        goto h4ScM;
        mPQsu:
    }
    public function mQ7Ni4rHrV5() : MediaConvertClient
    {
        return $this->MCKWR;
    }
    public function mKovrZboLLc(SbhemT8X5X1z8 $wxL9F) : self
    {
        $this->An_lX = $wxL9F;
        return $this;
    }
    public function mn1nwnAEThG(string $SPKog) : self
    {
        $this->EeXIh = $SPKog;
        return $this;
    }
    public function mn9pmiA6tdw(Tp9NT29QRCL9S $R7uzu) : self
    {
        $this->p02Jq[] = $R7uzu;
        return $this;
    }
    public function mwZPc5EwE5o(CAK6aksp9Uyad $th60a) : self
    {
        $this->BvW5c = $th60a;
        return $this;
    }
    private function m1TbvCCkcoc(bool $exakv) : array
    {
        goto HO6sP;
        Oxdo1:
        return $gR0SF;
        goto f6C8Z;
        CNm4z:
        unset($gR0SF['Settings']['OutputGroups']);
        goto SGzbZ;
        hB4e0:
        $Z0zss['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->EeXIh;
        goto sYdzf;
        Tbkg3:
        foreach ($this->p02Jq as $R7uzu) {
            $Z0zss['Outputs'][] = $R7uzu->mYld2l0DrNd();
            HUqGt:
        }
        goto cX4O5;
        Pqluj:
        if (!$this->BvW5c) {
            goto aUdf5;
        }
        goto NNe5C;
        fVDML:
        aUdf5:
        goto FeNbP;
        SxM77:
        $gR0SF['Queue'] = $this->ARvnk;
        goto pySYM;
        glpt1:
        $Z0zss = $gR0SF['Settings']['OutputGroups'][0];
        goto CNm4z;
        G8yhJ:
        $this->BvW5c = null;
        goto cHqT2;
        cHqT2:
        $this->An_lX = null;
        goto c7gGk;
        Og10h:
        $gR0SF['Settings']['Inputs'] = $this->An_lX->mIUdWGM9Oyc();
        goto glpt1;
        NNe5C:
        $gR0SF['Settings']['OutputGroups'][] = $this->BvW5c->m2lEzwsENk9();
        goto fVDML;
        FeNbP:
        if (!$exakv) {
            goto s6dnI;
        }
        goto Y6uXj;
        vdTS3:
        s6dnI:
        goto G8yhJ;
        c7gGk:
        $this->p02Jq = [];
        goto Oxdo1;
        sGw7R:
        iUVdn:
        goto Og10h;
        Y6uXj:
        $gR0SF['AccelerationSettings']['Mode'] = 'ENABLED';
        goto vdTS3;
        cPNCq:
        $gR0SF['Role'] = $this->UHKqK;
        goto SxM77;
        HO6sP:
        $gR0SF = (require 'template.php');
        goto cPNCq;
        cX4O5:
        yTjyW:
        goto hB4e0;
        SGzbZ:
        $Z0zss['Outputs'] = [];
        goto Tbkg3;
        sYdzf:
        $gR0SF['Settings']['OutputGroups'][] = $Z0zss;
        goto Pqluj;
        YqHSy:
        throw new \LogicException('You must provide a input file to use');
        goto sGw7R;
        pySYM:
        if ($this->An_lX) {
            goto iUVdn;
        }
        goto YqHSy;
        f6C8Z:
    }
    public function mekzVlHF4nE(bool $exakv = false) : string
    {
        try {
            $fNMAX = $this->MCKWR->createJob($this->m1TbvCCkcoc($exakv));
            return $fNMAX->get('Job')['Id'];
        } catch (AwsException $L0fOk) {
            Log::error('Error creating MediaConvert job: ' . $L0fOk->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $L0fOk);
        }
    }
}
