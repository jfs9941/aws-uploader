<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Service\HQQLwdzkwB4WZ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class GYeGOleAx46En
{
    public const Usf8j = 'v2/hls/';
    private $wlVwx;
    private $iHPgt;
    public function __construct(HQQLwdzkwB4WZ $Y3Zr2, Filesystem $zeM4q)
    {
        $this->wlVwx = $Y3Zr2;
        $this->iHPgt = $zeM4q;
    }
    public function mYJXdDWikdn($fxrDr) : string
    {
        return $this->wlVwx->mmrCLjm7lkY(self::Usf8j . $fxrDr->getAttribute('id') . '/');
    }
    public function mLf4sbUROSm($fxrDr) : string
    {
        return $this->wlVwx->mmrCLjm7lkY(self::Usf8j . $fxrDr->getAttribute('id') . '/thumbnail/');
    }
    public function m2WwOCe0rV7($fxrDr, $GJG2n = true) : string
    {
        goto G0wWC;
        G0wWC:
        if ($GJG2n) {
            goto oMtzE;
        }
        goto mkuRI;
        cC7qe:
        oMtzE:
        goto ULLGV;
        ULLGV:
        return $this->wlVwx->mmrCLjm7lkY(self::Usf8j . $fxrDr->getAttribute('id') . '/' . $fxrDr->getAttribute('id') . '.m3u8');
        goto IHdu4;
        mkuRI:
        return self::Usf8j . $fxrDr->getAttribute('id') . '/' . $fxrDr->getAttribute('id') . '.m3u8';
        goto cC7qe;
        IHdu4:
    }
    public function resolveThumbnail($fxrDr) : string
    {
        goto XFwUh;
        XFwUh:
        $tu00C = $fxrDr->getAttribute('id');
        goto HITw5;
        HITw5:
        $EKpu2 = $this->iHPgt->files($this->mLf4sbUROSm($fxrDr));
        goto PHVQe;
        PHVQe:
        return 1 == count($EKpu2) ? self::Usf8j . $tu00C . '/thumbnail/' . $tu00C . '.0000000.jpg' : self::Usf8j . $tu00C . '/thumbnail/' . $tu00C . '.0000001.jpg';
        goto o2L5W;
        o2L5W:
    }
    public function maMsOgTmJQt(string $fQjwQ) : string
    {
        return $this->iHPgt->url($fQjwQ);
    }
}
