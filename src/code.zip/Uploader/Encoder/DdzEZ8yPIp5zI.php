<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class DdzEZ8yPIp5zI
{
    private $YLj7w;
    public function __construct(float $cRxw9, int $Hw8f0, string $flmVl)
    {
        goto nJ4iQ;
        paD3S:
        $this->YLj7w = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $JDTo_]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $flmVl]]];
        goto tI_A_;
        nJ4iQ:
        $JDTo_ = (int) $cRxw9 / $Hw8f0;
        goto m0QTF;
        m0QTF:
        $JDTo_ = max($JDTo_, 1);
        goto paD3S;
        tI_A_:
    }
    public function mjAf2zqhMGr() : array
    {
        return $this->YLj7w;
    }
}
