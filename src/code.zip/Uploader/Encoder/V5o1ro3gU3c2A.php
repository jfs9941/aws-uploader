<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class V5o1ro3gU3c2A
{
    private $N9opy;
    public function __construct(string $dtuXR, int $j_Pwt, int $l_jEs, ?int $K2lK4, ?int $Mq4V6)
    {
        goto elbf2;
        JMGt9:
        if (!($K2lK4 && $Mq4V6)) {
            goto V0Jq8;
        }
        goto l5bJP;
        pq4Vt:
        V0Jq8:
        goto VcLHX;
        JLO6L:
        $this->N9opy['ImageInserter']['InsertableImages'][0]['Height'] = $Mq4V6;
        goto pq4Vt;
        elbf2:
        $this->N9opy = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $j_Pwt, 'ImageY' => $l_jEs, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $dtuXR, 'Opacity' => 35]]]];
        goto JMGt9;
        l5bJP:
        $this->N9opy['ImageInserter']['InsertableImages'][0]['Width'] = $K2lK4;
        goto JLO6L;
        VcLHX:
    }
    public function m0SXV8O5snt() : array
    {
        return $this->N9opy;
    }
}
