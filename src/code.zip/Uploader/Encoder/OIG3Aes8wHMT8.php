<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Service\B0o6VsHdCPn65;
use Illuminate\Contracts\Filesystem\Filesystem;
final class OIG3Aes8wHMT8
{
    public const fgg40 = 'v2/hls/';
    private $SUpsS;
    private $RE_2F;
    public function __construct(B0o6VsHdCPn65 $BkHR5, Filesystem $WmwnR)
    {
        $this->SUpsS = $BkHR5;
        $this->RE_2F = $WmwnR;
    }
    public function mywROX8HPuh($Qw86m) : string
    {
        return $this->SUpsS->mASHNMJyavd(self::fgg40 . $Qw86m->getAttribute('id') . '/');
    }
    public function mJ6ktCXV95B($Qw86m) : string
    {
        return $this->SUpsS->mASHNMJyavd(self::fgg40 . $Qw86m->getAttribute('id') . '/thumbnail/');
    }
    public function m8jFtdik4Jl($Qw86m, $I2522 = true) : string
    {
        goto uQ4kD;
        mrM4w:
        HMqjX:
        goto Er9OE;
        Er9OE:
        return $this->SUpsS->mASHNMJyavd(self::fgg40 . $Qw86m->getAttribute('id') . '/' . $Qw86m->getAttribute('id') . '.m3u8');
        goto nQkOW;
        uQ4kD:
        if ($I2522) {
            goto HMqjX;
        }
        goto ARYfV;
        ARYfV:
        return self::fgg40 . $Qw86m->getAttribute('id') . '/' . $Qw86m->getAttribute('id') . '.m3u8';
        goto mrM4w;
        nQkOW:
    }
    public function resolveThumbnail($Qw86m) : string
    {
        goto qXhzK;
        tYWxd:
        $i0dgv = $this->RE_2F->files($this->mJ6ktCXV95B($Qw86m));
        goto tJH3D;
        qXhzK:
        $LpGEK = $Qw86m->getAttribute('id');
        goto tYWxd;
        tJH3D:
        return 1 == count($i0dgv) ? self::fgg40 . $LpGEK . '/thumbnail/' . $LpGEK . '.0000000.jpg' : self::fgg40 . $LpGEK . '/thumbnail/' . $LpGEK . '.0000001.jpg';
        goto y6Mm3;
        y6Mm3:
    }
    public function myNnSpBlawh(string $AvgzF) : string
    {
        return $this->RE_2F->url($AvgzF);
    }
}
