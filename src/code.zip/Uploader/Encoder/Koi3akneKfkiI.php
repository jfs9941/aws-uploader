<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Service\VmrgwQFNELOFc;
final class Koi3akneKfkiI
{
    public const GwUay = 'v2/hls/';
    private $ZMuKH;
    private $MV0lK;
    public function __construct(VmrgwQFNELOFc $Geai1, Filesystem $tYsty)
    {
        $this->ZMuKH = $Geai1;
        $this->MV0lK = $tYsty;
    }
    public function moK51muoy5X($zef_R) : string
    {
        return $this->ZMuKH->m18Gs7IFa4t(self::GwUay . $zef_R->getAttribute('id') . '/');
    }
    public function mLV8PR6HxsX($zef_R) : string
    {
        return $this->ZMuKH->m18Gs7IFa4t(self::GwUay . $zef_R->getAttribute('id') . '/thumbnail/');
    }
    public function myfl3zsTjFY($zef_R, $vjTAl = true) : string
    {
        goto c31X6;
        c31X6:
        if ($vjTAl) {
            goto a3BNg;
        }
        goto Y_j8l;
        Y_j8l:
        return self::GwUay . $zef_R->getAttribute('id') . '/' . $zef_R->getAttribute('id') . '.m3u8';
        goto iLmsT;
        iLmsT:
        a3BNg:
        goto NWn3t;
        NWn3t:
        return $this->ZMuKH->m18Gs7IFa4t(self::GwUay . $zef_R->getAttribute('id') . '/' . $zef_R->getAttribute('id') . '.m3u8');
        goto JOr8u;
        JOr8u:
    }
    public function resolveThumbnail($zef_R) : string
    {
        goto PYOUT;
        PYOUT:
        $FILUb = $zef_R->getAttribute('id');
        goto eAnHi;
        eAnHi:
        $DOcNO = $this->MV0lK->files($this->mLV8PR6HxsX($zef_R));
        goto SiuVA;
        SiuVA:
        return 1 == count($DOcNO) ? self::GwUay . $FILUb . '/thumbnail/' . $FILUb . '.0000000.jpg' : self::GwUay . $FILUb . '/thumbnail/' . $FILUb . '.0000001.jpg';
        goto Lkxsl;
        Lkxsl:
    }
    public function m9pBQhDxiTR(string $Sblyk) : string
    {
        return $this->MV0lK->url($Sblyk);
    }
}
