<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class VJyQpEMUBJg8a
{
    private $cg48Z;
    public function __construct(string $Z1IOv, ?int $K2lK4, ?int $Mq4V6, float $XxHmQ)
    {
        goto dJF42;
        uJT8D:
        $this->cg48Z['VideoDescription']['Width'] = $K2lK4;
        goto UNsdM;
        leEBI:
        if (!($K2lK4 && $Mq4V6)) {
            goto n7_2p;
        }
        goto uJT8D;
        UUqwB:
        yUyRK:
        goto rE6mG;
        UNsdM:
        $this->cg48Z['VideoDescription']['Height'] = $Mq4V6;
        goto kjtWu;
        Vqwqo:
        if (!($K2lK4 && $Mq4V6)) {
            goto yUyRK;
        }
        goto wtEmU;
        wtEmU:
        $HMRz1 = $this->ms92dA9bBnv($K2lK4, $Mq4V6, $XxHmQ);
        goto UUqwB;
        dJF42:
        $HMRz1 = 15000000;
        goto Vqwqo;
        rE6mG:
        $this->cg48Z = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $HMRz1, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $Z1IOv];
        goto leEBI;
        kjtWu:
        n7_2p:
        goto XYdfT;
        XYdfT:
    }
    public function mEpCe2i4JcG(V5o1ro3gU3c2A $HPU1j) : self
    {
        $this->cg48Z['VideoDescription']['VideoPreprocessors'] = $HPU1j->m0SXV8O5snt();
        return $this;
    }
    public function ms2snJfCX5N() : array
    {
        return $this->cg48Z;
    }
    private function ms92dA9bBnv(int $K2lK4, int $Mq4V6, float $XgHHj, string $UqR0g = 'medium', string $uic1y = 'h264', string $DnrRP = 'good') : ?int
    {
        goto PKT0s;
        axMTr:
        wKOwG:
        goto E6rOz;
        GJ4aB:
        $AoRJg = 1.5;
        goto nkgXd;
        g4Ul6:
        if ($ov0tP <= 1280 * 720) {
            goto Q_U5i;
        }
        goto GtR9v;
        nkgXd:
        goto sh_be;
        goto h77Hz;
        FBhsI:
        LSidG:
        goto izDy4;
        GUwAu:
        $AoRJg = 30;
        goto nSKHg;
        veQx_:
        $B6Ivy = $AoRJg * ($XgHHj / 30);
        goto XxvY5;
        Aa8SF:
        uLSGT:
        goto GJ4aB;
        G2qCy:
        $AoRJg = 3;
        goto CMToQ;
        XxvY5:
        switch (strtolower($UqR0g)) {
            case 'low':
                $B6Ivy *= 0.7;
                goto h7AEB;
            case 'high':
                $B6Ivy *= 1.3;
                goto h7AEB;
            case 'veryhigh':
                $B6Ivy *= 1.6;
                goto h7AEB;
        }
        goto U3DyY;
        PKT0s:
        $ov0tP = $K2lK4 * $Mq4V6;
        goto FOvG8;
        izDy4:
        switch (strtolower($DnrRP)) {
            case 'low':
                $B6Ivy *= 0.8;
                goto i3A93;
            case 'high':
                $B6Ivy *= 1.2;
                goto i3A93;
        }
        goto zCR3x;
        zCR3x:
        mJ8PN:
        goto IjVoX;
        nSKHg:
        goto sh_be;
        goto Aa8SF;
        U3DyY:
        BJtgA:
        goto qjrcM;
        bm0GS:
        $B6Ivy = max(0.5, $B6Ivy);
        goto CYh4d;
        B03Jn:
        if (!('h265' === strtolower($uic1y) || 'hevc' === strtolower($uic1y) || 'vp9' === strtolower($uic1y))) {
            goto LSidG;
        }
        goto x1J5v;
        y40io:
        HzWu2:
        goto Mc3Wh;
        CMToQ:
        goto sh_be;
        goto y40io;
        Mc3Wh:
        $AoRJg = 7;
        goto dRZjU;
        x1J5v:
        $B6Ivy *= 0.65;
        goto FBhsI;
        hWiiP:
        $AoRJg = 12;
        goto tBZuH;
        GtR9v:
        if ($ov0tP <= 1920 * 1080) {
            goto HzWu2;
        }
        goto d7FEl;
        IjVoX:
        i3A93:
        goto bm0GS;
        d7FEl:
        if ($ov0tP <= 2560 * 1440) {
            goto NsdWb;
        }
        goto x1J5w;
        IPgQx:
        NsdWb:
        goto hWiiP;
        E6rOz:
        $AoRJg = 20;
        goto fueKO;
        fueKO:
        sh_be:
        goto veQx_;
        FOvG8:
        if ($ov0tP <= 640 * 480) {
            goto uLSGT;
        }
        goto g4Ul6;
        qjrcM:
        h7AEB:
        goto B03Jn;
        h77Hz:
        Q_U5i:
        goto G2qCy;
        x1J5w:
        if ($ov0tP <= 3840 * 2160) {
            goto wKOwG;
        }
        goto GUwAu;
        tBZuH:
        goto sh_be;
        goto axMTr;
        CYh4d:
        return (int) ($B6Ivy * 1000 * 1000);
        goto cFfO7;
        dRZjU:
        goto sh_be;
        goto IPgQx;
        cFfO7:
    }
}
