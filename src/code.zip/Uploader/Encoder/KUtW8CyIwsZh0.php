<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class KUtW8CyIwsZh0
{
    private $tWztK;
    public function __construct(float $A8OSa, int $vly9r, string $wqITx)
    {
        goto jvJGi;
        LFkR9:
        $this->tWztK = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $j_6aQ]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $wqITx]]];
        goto pe6v4;
        jvJGi:
        $j_6aQ = (int) $A8OSa / $vly9r;
        goto ReQZW;
        ReQZW:
        $j_6aQ = max($j_6aQ, 1);
        goto LFkR9;
        pe6v4:
    }
    public function mSApFb9qzUu() : array
    {
        return $this->tWztK;
    }
}
