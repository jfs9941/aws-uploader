<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class CQZusEgvlBWXI
{
    private $DcEuP;
    public function __construct(string $GWvdc, int $GRe5x, int $jq2ES, ?int $Eb8hw, ?int $eekOV)
    {
        goto o_pIk;
        Y6oMB:
        $this->DcEuP['ImageInserter']['InsertableImages'][0]['Width'] = $Eb8hw;
        goto zb_PX;
        Igphs:
        lLide:
        goto gClDR;
        zb_PX:
        $this->DcEuP['ImageInserter']['InsertableImages'][0]['Height'] = $eekOV;
        goto Igphs;
        o_pIk:
        $this->DcEuP = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $GRe5x, 'ImageY' => $jq2ES, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $GWvdc, 'Opacity' => 35]]]];
        goto znSew;
        znSew:
        if (!($Eb8hw && $eekOV)) {
            goto lLide;
        }
        goto Y6oMB;
        gClDR:
    }
    public function mgZUrDHcO83() : array
    {
        return $this->DcEuP;
    }
}
