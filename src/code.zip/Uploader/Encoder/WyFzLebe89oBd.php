<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class WyFzLebe89oBd
{
    private $PoZ_t;
    public function __construct(string $r3aSh, int $eWDbO, int $ih8pC, ?int $oy0ze, ?int $sccRX)
    {
        goto gL484;
        B8NmF:
        $this->PoZ_t['ImageInserter']['InsertableImages'][0]['Width'] = $oy0ze;
        goto Uv8_X;
        YhyiK:
        BNpyl:
        goto KRlmq;
        Uv8_X:
        $this->PoZ_t['ImageInserter']['InsertableImages'][0]['Height'] = $sccRX;
        goto YhyiK;
        gL484:
        $this->PoZ_t = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $eWDbO, 'ImageY' => $ih8pC, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $r3aSh, 'Opacity' => 35]]]];
        goto IpwP6;
        IpwP6:
        if (!($oy0ze && $sccRX)) {
            goto BNpyl;
        }
        goto B8NmF;
        KRlmq:
    }
    public function m0ByrI1QwU8() : array
    {
        return $this->PoZ_t;
    }
}
