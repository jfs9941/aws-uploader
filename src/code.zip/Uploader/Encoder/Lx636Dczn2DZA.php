<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class Lx636Dczn2DZA
{
    private $ohTeB;
    public function __construct(string $w0flE)
    {
        $this->ohTeB = [['AudioSelectors' => ['Audio Selector 1' => ['DefaultSelection' => 'DEFAULT']], 'VideoSelector' => ['Rotate' => 'AUTO'], 'TimecodeSource' => 'ZEROBASED', 'FileInput' => $w0flE]];
    }
    public function mvlg7ORaMWx() : array
    {
        return $this->ohTeB;
    }
}
