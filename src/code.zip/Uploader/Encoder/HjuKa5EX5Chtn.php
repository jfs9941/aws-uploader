<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; class HjuKa5EX5Chtn { private $dL7Aj; public function __construct(float $mSYTw, int $ADSFa, string $cgNlT) { goto z91ZY; z91ZY: $aWEsk = (int) $mSYTw / $ADSFa; goto tpmRd; tpmRd: $aWEsk = max($aWEsk, 1); goto FBhhJ; FBhhJ: $this->dL7Aj = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $aWEsk]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $cgNlT]]]; goto CuXnR; CuXnR: } public function m5dk3T2SKom() : array { return $this->dL7Aj; } }
