<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\Zp6bjD8AQnl45;
final class PKHDooQHU3M1o
{
    private $OCjxh;
    public function __construct(string $d93aE, ?int $yRrbE, ?int $aQb9L, float $uKiVZ)
    {
        goto kh90T;
        uy0U1:
        wJpX3:
        goto MQLw4;
        kh90T:
        $K81Os = 15000000;
        goto yw74S;
        KimW9:
        $this->OCjxh['VideoDescription']['Height'] = $aQb9L;
        goto uy0U1;
        TVcR5:
        jua6e:
        goto tyQKs;
        tyQKs:
        $this->OCjxh = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $K81Os, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $d93aE];
        goto tV2UY;
        hboVU:
        $K81Os = $this->mWkBNOtj8Pr($yRrbE, $aQb9L, $uKiVZ);
        goto TVcR5;
        yw74S:
        if (!($yRrbE && $aQb9L)) {
            goto jua6e;
        }
        goto hboVU;
        R_IQI:
        $this->OCjxh['VideoDescription']['Width'] = $yRrbE;
        goto KimW9;
        tV2UY:
        if (!($yRrbE && $aQb9L)) {
            goto wJpX3;
        }
        goto R_IQI;
        MQLw4:
    }
    public function m9aio19t0Wx(Zp6bjD8AQnl45 $WPGHr) : self
    {
        $this->OCjxh['VideoDescription']['VideoPreprocessors'] = $WPGHr->mtNCFM7h3pf();
        return $this;
    }
    public function ms57sAxxCVy() : array
    {
        return $this->OCjxh;
    }
    private function mWkBNOtj8Pr(int $yRrbE, int $aQb9L, float $IkVOa, string $Norrj = 'medium', string $TGrSn = 'h264', string $kADOj = 'good') : ?int
    {
        goto rtvEI;
        bZqVN:
        hfI3J:
        goto AGjEz;
        XDHe_:
        L2n2o:
        goto ZWpk6;
        AGjEz:
        $rRS9j = 7;
        goto HTG1W;
        HjRkF:
        yH94X:
        goto bvjfq;
        ZWpk6:
        wg5cN:
        goto I57MH;
        P3prR:
        CX38b:
        goto qUKm7;
        Ow94b:
        C1ylO:
        goto xDgYw;
        QAYR6:
        if ($AXh8X <= 1280 * 720) {
            goto C1ylO;
        }
        goto GRdXk;
        GRdXk:
        if ($AXh8X <= 1920 * 1080) {
            goto hfI3J;
        }
        goto o6x1Q;
        r_i2J:
        return (int) ($L8xi1 * 1000 * 1000);
        goto E_OvL;
        ilwC4:
        V2FaD:
        goto y6e2V;
        ajS8J:
        pSMSr:
        goto aWZxd;
        vuA7U:
        XRhJf:
        goto HjRkF;
        y6e2V:
        $L8xi1 = $rRS9j * ($IkVOa / 30);
        goto jBrHX;
        I57MH:
        if (!('h265' === strtolower($TGrSn) || 'hevc' === strtolower($TGrSn) || 'vp9' === strtolower($TGrSn))) {
            goto CX38b;
        }
        goto Ny7jt;
        HTG1W:
        goto V2FaD;
        goto yJU1r;
        Ny7jt:
        $L8xi1 *= 0.65;
        goto P3prR;
        yJU1r:
        aCi3s:
        goto fcYpS;
        DTEbr:
        goto V2FaD;
        goto bZqVN;
        qUKm7:
        switch (strtolower($kADOj)) {
            case 'low':
                $L8xi1 *= 0.8;
                goto yH94X;
            case 'high':
                $L8xi1 *= 1.2;
                goto yH94X;
        }
        goto vuA7U;
        ayB_J:
        goto V2FaD;
        goto ajS8J;
        j12jq:
        goto V2FaD;
        goto B3Qg2;
        DfJGm:
        if ($AXh8X <= 3840 * 2160) {
            goto S3pZC;
        }
        goto COlZM;
        bvjfq:
        $L8xi1 = max(0.5, $L8xi1);
        goto r_i2J;
        B3Qg2:
        S3pZC:
        goto M17_W;
        xDgYw:
        $rRS9j = 3;
        goto DTEbr;
        Y5BMc:
        goto V2FaD;
        goto Ow94b;
        o6x1Q:
        if ($AXh8X <= 2560 * 1440) {
            goto aCi3s;
        }
        goto DfJGm;
        tAI6s:
        if ($AXh8X <= 640 * 480) {
            goto pSMSr;
        }
        goto QAYR6;
        M17_W:
        $rRS9j = 20;
        goto ilwC4;
        jBrHX:
        switch (strtolower($Norrj)) {
            case 'low':
                $L8xi1 *= 0.7;
                goto wg5cN;
            case 'high':
                $L8xi1 *= 1.3;
                goto wg5cN;
            case 'veryhigh':
                $L8xi1 *= 1.6;
                goto wg5cN;
        }
        goto XDHe_;
        aWZxd:
        $rRS9j = 1.5;
        goto Y5BMc;
        COlZM:
        $rRS9j = 30;
        goto ayB_J;
        rtvEI:
        $AXh8X = $yRrbE * $aQb9L;
        goto tAI6s;
        fcYpS:
        $rRS9j = 12;
        goto j12jq;
        E_OvL:
    }
}
