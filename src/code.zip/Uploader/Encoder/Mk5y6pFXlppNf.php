<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Mk5y6pFXlppNf
{
    private $yfYgG;
    public function __construct(string $aybYK, int $jr3qd, int $LOjZO, ?int $vwL5B, ?int $ttadT)
    {
        goto SUuBF;
        SUuBF:
        $this->yfYgG = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $jr3qd, 'ImageY' => $LOjZO, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $aybYK, 'Opacity' => 35]]]];
        goto EJwwx;
        d1ESg:
        llGUs:
        goto NWCmr;
        Yj0rG:
        $this->yfYgG['ImageInserter']['InsertableImages'][0]['Height'] = $ttadT;
        goto d1ESg;
        EJwwx:
        if (!($vwL5B && $ttadT)) {
            goto llGUs;
        }
        goto wJuAW;
        wJuAW:
        $this->yfYgG['ImageInserter']['InsertableImages'][0]['Width'] = $vwL5B;
        goto Yj0rG;
        NWCmr:
    }
    public function meQQw6nXlzV() : array
    {
        return $this->yfYgG;
    }
}
