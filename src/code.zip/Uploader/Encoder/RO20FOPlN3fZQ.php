<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class RO20FOPlN3fZQ
{
    private $oeXIb;
    public function __construct(string $BrWcz, ?int $ABqPe, ?int $dE8ui, float $IWXM6)
    {
        goto NMvzo;
        KKc_8:
        $this->oeXIb = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $hk2tX, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $BrWcz];
        goto F7jLH;
        JNByc:
        $this->oeXIb['VideoDescription']['Width'] = $ABqPe;
        goto aXRpQ;
        wOGVS:
        $hk2tX = $this->mV67wO4fWv7($ABqPe, $dE8ui, $IWXM6);
        goto YafF7;
        NMvzo:
        $hk2tX = 15000000;
        goto q2eXe;
        F7jLH:
        if (!($ABqPe && $dE8ui)) {
            goto Rjd0q;
        }
        goto JNByc;
        q2eXe:
        if (!($ABqPe && $dE8ui)) {
            goto J2dO0;
        }
        goto wOGVS;
        aXRpQ:
        $this->oeXIb['VideoDescription']['Height'] = $dE8ui;
        goto QPyLt;
        YafF7:
        J2dO0:
        goto KKc_8;
        QPyLt:
        Rjd0q:
        goto LXw3s;
        LXw3s:
    }
    public function mwRngGW0Uxm(RAnwJh59aP1hj $ZR43H) : self
    {
        $this->oeXIb['VideoDescription']['VideoPreprocessors'] = $ZR43H->mnObR0OH5FN();
        return $this;
    }
    public function m80fZpJQGHe() : array
    {
        return $this->oeXIb;
    }
    private function mV67wO4fWv7(int $ABqPe, int $dE8ui, float $aMv83, string $FoA4H = 'medium', string $YhcCZ = 'h264', string $Lp6O9 = 'good') : ?int
    {
        goto P_CrP;
        myArc:
        if ($n9_yU <= 3840 * 2160) {
            goto Pq2QJ;
        }
        goto D5qYD;
        ph6fo:
        switch (strtolower($Lp6O9)) {
            case 'low':
                $u66kj *= 0.8;
                goto gT4ri;
            case 'high':
                $u66kj *= 1.2;
                goto gT4ri;
        }
        goto x7MXz;
        P_CrP:
        $n9_yU = $ABqPe * $dE8ui;
        goto dFMnQ;
        ATTZd:
        Pq2QJ:
        goto fDCvp;
        MnP5X:
        goto VMsG1;
        goto tGOVk;
        qjeJW:
        if ($n9_yU <= 1920 * 1080) {
            goto h7Uys;
        }
        goto oehGQ;
        Bm3Nl:
        b_Oql:
        goto dF6YU;
        x7MXz:
        h4oOd:
        goto EobMW;
        YT12s:
        goto VMsG1;
        goto gA3jh;
        cbIF6:
        yQ4uW:
        goto ph6fo;
        DzWN2:
        goto VMsG1;
        goto qqoS1;
        dF6YU:
        cW1zG:
        goto o3dox;
        o3dox:
        if (!('h265' === strtolower($YhcCZ) || 'hevc' === strtolower($YhcCZ) || 'vp9' === strtolower($YhcCZ))) {
            goto yQ4uW;
        }
        goto CkO5V;
        I5viT:
        $kKyoK = 1.5;
        goto MnP5X;
        CkO5V:
        $u66kj *= 0.65;
        goto cbIF6;
        wyPz2:
        if ($n9_yU <= 1280 * 720) {
            goto el0fq;
        }
        goto qjeJW;
        tGOVk:
        el0fq:
        goto CfeXB;
        dFMnQ:
        if ($n9_yU <= 640 * 480) {
            goto jNgmG;
        }
        goto wyPz2;
        EobMW:
        gT4ri:
        goto G0NVA;
        CfeXB:
        $kKyoK = 3;
        goto vCWbi;
        D5qYD:
        $kKyoK = 30;
        goto DzWN2;
        gA3jh:
        pb1U8:
        goto Ew3LB;
        oehGQ:
        if ($n9_yU <= 2560 * 1440) {
            goto pb1U8;
        }
        goto myArc;
        Ew3LB:
        $kKyoK = 12;
        goto GKbc0;
        qqoS1:
        jNgmG:
        goto I5viT;
        MtAUb:
        VMsG1:
        goto DLvd2;
        fDCvp:
        $kKyoK = 20;
        goto MtAUb;
        o7uWk:
        $kKyoK = 7;
        goto YT12s;
        EiuCi:
        h7Uys:
        goto o7uWk;
        i1kjg:
        return (int) ($u66kj * 1000 * 1000);
        goto CXwDp;
        TRWMT:
        switch (strtolower($FoA4H)) {
            case 'low':
                $u66kj *= 0.7;
                goto cW1zG;
            case 'high':
                $u66kj *= 1.3;
                goto cW1zG;
            case 'veryhigh':
                $u66kj *= 1.6;
                goto cW1zG;
        }
        goto Bm3Nl;
        G0NVA:
        $u66kj = max(0.5, $u66kj);
        goto i1kjg;
        vCWbi:
        goto VMsG1;
        goto EiuCi;
        DLvd2:
        $u66kj = $kKyoK * ($aMv83 / 30);
        goto TRWMT;
        GKbc0:
        goto VMsG1;
        goto ATTZd;
        CXwDp:
    }
}
