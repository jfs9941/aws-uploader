<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class QAZGS1jBxOIat
{
    private $vvhnK;
    private $JiM2u;
    private $FGt0n;
    private $do3lD;
    private $U2frQ;
    private $yoixB;
    private $pIIgF;
    public function __construct(MediaConvertClient $EXvzr, $sbrmg, $Az3dy)
    {
        goto yE22u;
        wVSu9:
        $this->yoixB = $Az3dy;
        goto TP9Ub;
        GT3Li:
        $this->U2frQ = $sbrmg;
        goto wVSu9;
        yE22u:
        $this->do3lD = $EXvzr;
        goto GT3Li;
        TP9Ub:
    }
    public function mVO52ybpM8x() : MediaConvertClient
    {
        return $this->do3lD;
    }
    public function mtwH6QVFxd0(VmOEcjiWKEEdZ $NuQfz) : self
    {
        $this->vvhnK = $NuQfz;
        return $this;
    }
    public function mFJwnDhqYOS(string $WF6cF) : self
    {
        $this->FGt0n = $WF6cF;
        return $this;
    }
    public function mzrA1hpk7ho(Di7wGPfsbBXHu $KODd8) : self
    {
        $this->JiM2u[] = $KODd8;
        return $this;
    }
    public function mpIdw95C9GV(MmrtqP9zAx1EE $O8BOu) : self
    {
        $this->pIIgF = $O8BOu;
        return $this;
    }
    private function mRfMWE1ey4O(bool $zZrmO) : array
    {
        goto awbRv;
        H5eZ6:
        $this->pIIgF = null;
        goto PcQ04;
        oqlPV:
        $JQjIc['Outputs'] = [];
        goto qXoSW;
        nr5pj:
        j0Mdg:
        goto HN1u3;
        HN1u3:
        $JQjIc['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->FGt0n;
        goto hHUKH;
        PcQ04:
        $this->vvhnK = null;
        goto TwSJ1;
        wdBKU:
        $JQjIc = $R8215['Settings']['OutputGroups'][0];
        goto ctFYl;
        PYffj:
        if ($this->vvhnK) {
            goto xjokv;
        }
        goto BkS_h;
        awbRv:
        $R8215 = (require 'template.php');
        goto YgfY0;
        hHUKH:
        $R8215['Settings']['OutputGroups'][] = $JQjIc;
        goto HTvkM;
        PjBgP:
        xjokv:
        goto QMTWu;
        ehIgK:
        OH8YT:
        goto mPMal;
        yyQ8R:
        return $R8215;
        goto YlkgF;
        qXoSW:
        foreach ($this->JiM2u as $KODd8) {
            $JQjIc['Outputs'][] = $KODd8->mV8UFrM2B2L();
            euKxo:
        }
        goto nr5pj;
        YgfY0:
        $R8215['Role'] = $this->U2frQ;
        goto Fj06Y;
        mPMal:
        if (!$zZrmO) {
            goto aMU9a;
        }
        goto NbwGs;
        QMTWu:
        $R8215['Settings']['Inputs'] = $this->vvhnK->mM1mmGwFs1L();
        goto wdBKU;
        TwSJ1:
        $this->JiM2u = [];
        goto yyQ8R;
        CImWX:
        aMU9a:
        goto H5eZ6;
        BkS_h:
        throw new \LogicException('You must provide a input file to use');
        goto PjBgP;
        HTvkM:
        if (!$this->pIIgF) {
            goto OH8YT;
        }
        goto KQH2s;
        NbwGs:
        $R8215['AccelerationSettings']['Mode'] = 'ENABLED';
        goto CImWX;
        ctFYl:
        unset($R8215['Settings']['OutputGroups']);
        goto oqlPV;
        Fj06Y:
        $R8215['Queue'] = $this->yoixB;
        goto PYffj;
        KQH2s:
        $R8215['Settings']['OutputGroups'][] = $this->pIIgF->mIf99mgPo8M();
        goto ehIgK;
        YlkgF:
    }
    public function mkASZN1bpeL(bool $zZrmO = false) : string
    {
        try {
            $rWjSy = $this->do3lD->createJob($this->mRfMWE1ey4O($zZrmO));
            return $rWjSy->get('Jobs')['Id'];
        } catch (AwsException $L1ZUQ) {
            Log::error('Error creating MediaConvert job: ' . $L1ZUQ->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $L1ZUQ);
        }
    }
}
