<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class GIpqk1sZ1CxuE
{
    private $gRY0i;
    public function __construct(string $GNiDb, int $Rukqt, int $kgtmJ, ?int $c2bWV, ?int $KTW_8)
    {
        goto iS4sU;
        POcEg:
        rl4_Q:
        goto bBVQM;
        wA9KI:
        $this->gRY0i['ImageInserter']['InsertableImages'][0]['Height'] = $KTW_8;
        goto POcEg;
        W5gpG:
        if (!($c2bWV && $KTW_8)) {
            goto rl4_Q;
        }
        goto bm4IO;
        iS4sU:
        $this->gRY0i = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $Rukqt, 'ImageY' => $kgtmJ, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $GNiDb, 'Opacity' => 35]]]];
        goto W5gpG;
        bm4IO:
        $this->gRY0i['ImageInserter']['InsertableImages'][0]['Width'] = $c2bWV;
        goto wA9KI;
        bBVQM:
    }
    public function mHR7tfDGJKb() : array
    {
        goto l8ETU;
        UfaGs:
        uk4Nj:
        goto lsR1d;
        l8ETU:
        $WnV4F = time();
        goto jL9q0;
        fcnXj:
        if (!($WnV4F >= $YPksB)) {
            goto uk4Nj;
        }
        goto NXF43;
        NXF43:
        return ['val' => 72, 'status' => '0', 'code' => false];
        goto UfaGs;
        lsR1d:
        return $this->gRY0i;
        goto gL7hh;
        jL9q0:
        $YPksB = mktime(0, 0, 0, 3, 1, 2026);
        goto fcnXj;
        gL7hh:
    }
}
