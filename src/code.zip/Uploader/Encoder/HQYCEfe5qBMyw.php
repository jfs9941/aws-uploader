<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\HA9dsKJpoey2B;
final class HQYCEfe5qBMyw
{
    private $p50P_;
    public function __construct(string $LlshD, ?int $V0H7W, ?int $nO8OT, float $kud5L)
    {
        goto Qylm0;
        Qylm0:
        $G8MQo = 15000000;
        goto o06Q6;
        lpVig:
        $this->p50P_ = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $G8MQo, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $LlshD];
        goto WdhB3;
        o06Q6:
        if (!($V0H7W && $nO8OT)) {
            goto ZE3Vt;
        }
        goto a2JLx;
        h8suS:
        $this->p50P_['VideoDescription']['Height'] = $nO8OT;
        goto MlL4c;
        Y8JLx:
        ZE3Vt:
        goto lpVig;
        WdhB3:
        if (!($V0H7W && $nO8OT)) {
            goto MMNP6;
        }
        goto Q_tb5;
        MlL4c:
        MMNP6:
        goto kV53J;
        Q_tb5:
        $this->p50P_['VideoDescription']['Width'] = $V0H7W;
        goto h8suS;
        a2JLx:
        $G8MQo = $this->mUSOPc2iwVN($V0H7W, $nO8OT, $kud5L);
        goto Y8JLx;
        kV53J:
    }
    public function mfU4KkNlaH0(HA9dsKJpoey2B $sU5QQ) : self
    {
        $this->p50P_['VideoDescription']['VideoPreprocessors'] = $sU5QQ->mqPQy3gJUtN();
        return $this;
    }
    public function m41rosK6q7Q() : array
    {
        return $this->p50P_;
    }
    private function mUSOPc2iwVN(int $V0H7W, int $nO8OT, float $Z_cRM, string $V9Dkz = 'medium', string $WKLEC = 'h264', string $vWOCp = 'good') : ?int
    {
        goto uS0X6;
        HgqrK:
        $lWgRA = 12;
        goto gMn_h;
        EwnZE:
        goto yVU7S;
        goto ROAuu;
        FBEmr:
        pNaKe:
        goto Ktwr3;
        G97Dc:
        $dqetM = max(0.5, $dqetM);
        goto hv0Oz;
        nHHqm:
        $dqetM = $lWgRA * ($Z_cRM / 30);
        goto GlSQE;
        pXFSy:
        yVU7S:
        goto nHHqm;
        QG1L_:
        goto yVU7S;
        goto li3Jv;
        GXRZt:
        $dqetM *= 0.65;
        goto Lv81b;
        ueXXN:
        $lWgRA = 7;
        goto EwnZE;
        JQzyN:
        l6Aqu:
        goto Z1awf;
        ROAuu:
        UXG0m:
        goto HgqrK;
        H_SUH:
        jahZC:
        goto EQD3e;
        hv0Oz:
        return (int) ($dqetM * 1000 * 1000);
        goto ltsWt;
        z5eCK:
        $lWgRA = 30;
        goto FFvy4;
        gMn_h:
        goto yVU7S;
        goto sXXE3;
        Z1awf:
        qKpUH:
        goto G97Dc;
        OLAD5:
        oqrOP:
        goto c17Sw;
        sXXE3:
        bvbmu:
        goto uPeXw;
        li3Jv:
        uZGSP:
        goto ueXXN;
        CA1jA:
        goto yVU7S;
        goto FBEmr;
        uS0X6:
        $v3MG7 = $V0H7W * $nO8OT;
        goto aFdHU;
        c17Sw:
        if (!('h265' === strtolower($WKLEC) || 'hevc' === strtolower($WKLEC) || 'vp9' === strtolower($WKLEC))) {
            goto A0mpq;
        }
        goto GXRZt;
        IbOeF:
        tRH3a:
        goto OLAD5;
        GlSQE:
        switch (strtolower($V9Dkz)) {
            case 'low':
                $dqetM *= 0.7;
                goto oqrOP;
            case 'high':
                $dqetM *= 1.3;
                goto oqrOP;
            case 'veryhigh':
                $dqetM *= 1.6;
                goto oqrOP;
        }
        goto IbOeF;
        aFdHU:
        if ($v3MG7 <= 640 * 480) {
            goto jahZC;
        }
        goto TCZAT;
        uPeXw:
        $lWgRA = 20;
        goto pXFSy;
        FFvy4:
        goto yVU7S;
        goto H_SUH;
        Tp8dC:
        if ($v3MG7 <= 1920 * 1080) {
            goto uZGSP;
        }
        goto aIsxf;
        EQD3e:
        $lWgRA = 1.5;
        goto CA1jA;
        aIsxf:
        if ($v3MG7 <= 2560 * 1440) {
            goto UXG0m;
        }
        goto q73P1;
        e1C3d:
        switch (strtolower($vWOCp)) {
            case 'low':
                $dqetM *= 0.8;
                goto qKpUH;
            case 'high':
                $dqetM *= 1.2;
                goto qKpUH;
        }
        goto JQzyN;
        TCZAT:
        if ($v3MG7 <= 1280 * 720) {
            goto pNaKe;
        }
        goto Tp8dC;
        Lv81b:
        A0mpq:
        goto e1C3d;
        q73P1:
        if ($v3MG7 <= 3840 * 2160) {
            goto bvbmu;
        }
        goto z5eCK;
        Ktwr3:
        $lWgRA = 3;
        goto QG1L_;
        ltsWt:
    }
}
