<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Service\VEn7C5MII4ANw;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Qyf5nkvkW6Bhl
{
    public const tk3TT = 'v2/hls/';
    private $fFo17;
    private $cC_4U;
    public function __construct(VEn7C5MII4ANw $O11GX, Filesystem $s1UdZ)
    {
        $this->fFo17 = $O11GX;
        $this->cC_4U = $s1UdZ;
    }
    public function mUiqBgKPPL5($cFlec) : string
    {
        return $this->fFo17->m5gStLGQgqF(self::tk3TT . $cFlec->getAttribute('id') . '/');
    }
    public function m5hssaprz0p($cFlec) : string
    {
        return $this->fFo17->m5gStLGQgqF(self::tk3TT . $cFlec->getAttribute('id') . '/thumbnail/');
    }
    public function molrMkgr5uW($cFlec, $gPAXn = true) : string
    {
        goto A7K8j;
        A7K8j:
        if ($gPAXn) {
            goto AD1bP;
        }
        goto cBjxT;
        hvAbd:
        return $this->fFo17->m5gStLGQgqF(self::tk3TT . $cFlec->getAttribute('id') . '/' . $cFlec->getAttribute('id') . '.m3u8');
        goto j9bOR;
        cBjxT:
        return self::tk3TT . $cFlec->getAttribute('id') . '/' . $cFlec->getAttribute('id') . '.m3u8';
        goto EnVL9;
        EnVL9:
        AD1bP:
        goto hvAbd;
        j9bOR:
    }
    public function resolveThumbnail($cFlec) : string
    {
        goto jVoqv;
        i94qO:
        return 1 == count($gLc71) ? self::tk3TT . $q8q1b . '/thumbnail/' . $q8q1b . '.0000000.jpg' : self::tk3TT . $q8q1b . '/thumbnail/' . $q8q1b . '.0000001.jpg';
        goto qYlHW;
        pnyWS:
        $gLc71 = $this->cC_4U->files($this->m5hssaprz0p($cFlec));
        goto i94qO;
        jVoqv:
        $q8q1b = $cFlec->getAttribute('id');
        goto pnyWS;
        qYlHW:
    }
    public function m4k5A1XUpuC(string $K_YMm) : string
    {
        return $this->cC_4U->url($K_YMm);
    }
}
