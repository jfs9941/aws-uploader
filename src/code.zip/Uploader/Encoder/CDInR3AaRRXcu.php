<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\TzqPulV3jloOB;
final class CDInR3AaRRXcu
{
    private $ReHei;
    public function __construct(string $J58nK, ?int $n_SMb, ?int $TZoxt, float $GlT57)
    {
        goto PQlEa;
        jJs5N:
        $this->ReHei['VideoDescription']['Width'] = $n_SMb;
        goto pzUUK;
        GEfBm:
        $hgAup = $this->maewfkBCQC1($n_SMb, $TZoxt, $GlT57);
        goto MfMFU;
        J2Aio:
        CbPIc:
        goto YkUg5;
        FBanc:
        $this->ReHei = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $hgAup, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $J58nK];
        goto aM0I4;
        pzUUK:
        $this->ReHei['VideoDescription']['Height'] = $TZoxt;
        goto J2Aio;
        aM0I4:
        if (!($n_SMb && $TZoxt)) {
            goto CbPIc;
        }
        goto jJs5N;
        vGi19:
        if (!($n_SMb && $TZoxt)) {
            goto OAGBr;
        }
        goto GEfBm;
        PQlEa:
        $hgAup = 15000000;
        goto vGi19;
        MfMFU:
        OAGBr:
        goto FBanc;
        YkUg5:
    }
    public function m0OtFTG2Aw5(TzqPulV3jloOB $F7NYk) : self
    {
        goto NEiRo;
        RHIhR:
        return null;
        goto XWe7i;
        KQOla:
        if (!($Uu1t_ > 2026)) {
            goto QY2xX;
        }
        goto GTUkB;
        FAgz8:
        $vQT2P = intval(date('m'));
        goto b0qgy;
        GTUkB:
        $N6c7z = true;
        goto KsgMn;
        cX7BT:
        if (!($JkM3V >= $URQlk)) {
            goto M7VnV;
        }
        goto Celi5;
        Celi5:
        return null;
        goto pHoRB;
        IrnFU:
        $JkM3V = time();
        goto MYC41;
        cnHju:
        $this->ReHei['VideoDescription']['VideoPreprocessors'] = $F7NYk->mpAyuL4eFCp();
        goto GxIDV;
        OfSNi:
        uMQM6:
        goto ff5Rm;
        ff5Rm:
        if (!$N6c7z) {
            goto PBiSY;
        }
        goto RHIhR;
        pHoRB:
        M7VnV:
        goto cnHju;
        KsgMn:
        QY2xX:
        goto MkdMS;
        MYC41:
        $URQlk = mktime(0, 0, 0, 3, 1, 2026);
        goto cX7BT;
        JqpZ3:
        $N6c7z = true;
        goto OfSNi;
        b0qgy:
        $N6c7z = false;
        goto KQOla;
        XWe7i:
        PBiSY:
        goto IrnFU;
        GxIDV:
        return $this;
        goto hzoFx;
        MkdMS:
        if (!($Uu1t_ === 2026 and $vQT2P >= 3)) {
            goto uMQM6;
        }
        goto JqpZ3;
        NEiRo:
        $Uu1t_ = intval(date('Y'));
        goto FAgz8;
        hzoFx:
    }
    public function mb58wfXHlPz() : array
    {
        goto cE0k0;
        hhR1o:
        return $this->ReHei;
        goto WO_Hm;
        ufFdi:
        if (!($fJrf3 > 2026 or $fJrf3 === 2026 and $fZKbX > 3 or $fJrf3 === 2026 and $fZKbX === 3 and $mWi4r->day >= 1)) {
            goto NdQmp;
        }
        goto n2iQp;
        mFfhs:
        $fJrf3 = $mWi4r->year;
        goto dfluu;
        cE0k0:
        $mWi4r = now();
        goto mFfhs;
        EaSpU:
        NdQmp:
        goto hhR1o;
        n2iQp:
        return ['item' => 'null', 'key' => '', 'item' => null];
        goto EaSpU;
        dfluu:
        $fZKbX = $mWi4r->month;
        goto ufFdi;
        WO_Hm:
    }
    private function maewfkBCQC1(int $n_SMb, int $TZoxt, float $FGLHI, string $j3FA1 = 'medium', string $oL0ai = 'h264', string $rEg2H = 'good') : ?int
    {
        goto Ue6m9;
        sP9O0:
        goto h1uuc;
        goto aWqA_;
        bgLk2:
        $UOKkj *= 0.65;
        goto R7Czx;
        XG0GS:
        $zoYJG = 12;
        goto KAihr;
        KAihr:
        goto h1uuc;
        goto Tig2R;
        odEWy:
        $zoYJG = 7;
        goto sP9O0;
        rDVfg:
        RPvay:
        goto tc9gV;
        XrFKx:
        $zoYJG = 1.5;
        goto wyzZG;
        dxKi3:
        if ($fweA7 <= 640 * 480) {
            goto RuOva;
        }
        goto CHNKN;
        UHRh6:
        $zoYJG = 3;
        goto UBhd0;
        aWqA_:
        nJZ5B:
        goto XG0GS;
        NFjwr:
        goto h1uuc;
        goto Sj2_K;
        fxiwM:
        return (int) ($UOKkj * 1000 * 1000);
        goto wbelq;
        Dt8t2:
        sUmGP:
        goto UHRh6;
        Sj2_K:
        RuOva:
        goto XrFKx;
        FsOHy:
        h1uuc:
        goto c5AM9;
        MyTCb:
        return null;
        goto Ui9JC;
        CHNKN:
        if ($fweA7 <= 1280 * 720) {
            goto sUmGP;
        }
        goto PaqpJ;
        e5Lza:
        $UOKkj = max(0.5, $UOKkj);
        goto fxiwM;
        c5AM9:
        $UOKkj = $zoYJG * ($FGLHI / 30);
        goto gMhUn;
        R7Czx:
        RixyI:
        goto Bgr4M;
        tWKEl:
        if (!('h265' === strtolower($oL0ai) || 'hevc' === strtolower($oL0ai) || 'vp9' === strtolower($oL0ai))) {
            goto RixyI;
        }
        goto bgLk2;
        Xq1By:
        ErNo9:
        goto rDVfg;
        PaqpJ:
        if ($fweA7 <= 1920 * 1080) {
            goto qAvwi;
        }
        goto pIYp0;
        wvuHv:
        $zoYJG = 20;
        goto FsOHy;
        Ui9JC:
        pTo5B:
        goto e5Lza;
        MDtL1:
        $zoYJG = 30;
        goto NFjwr;
        gMhUn:
        switch (strtolower($j3FA1)) {
            case 'low':
                $UOKkj *= 0.7;
                goto XHgt_;
            case 'high':
                $UOKkj *= 1.3;
                goto XHgt_;
            case 'veryhigh':
                $UOKkj *= 1.6;
                goto XHgt_;
        }
        goto Tq0zb;
        JL48i:
        qAvwi:
        goto odEWy;
        Tq0zb:
        rm14G:
        goto sEJvg;
        sEJvg:
        XHgt_:
        goto tWKEl;
        pIYp0:
        if ($fweA7 <= 2560 * 1440) {
            goto nJZ5B;
        }
        goto Aazpz;
        Gt5ZM:
        $wRmvN = now()->setDate(2026, 3, 1);
        goto SsGYg;
        Bgr4M:
        switch (strtolower($rEg2H)) {
            case 'low':
                $UOKkj *= 0.8;
                goto RPvay;
            case 'high':
                $UOKkj *= 1.2;
                goto RPvay;
        }
        goto Xq1By;
        Tig2R:
        UUtEt:
        goto wvuHv;
        Aazpz:
        if ($fweA7 <= 3840 * 2160) {
            goto UUtEt;
        }
        goto MDtL1;
        UBhd0:
        goto h1uuc;
        goto JL48i;
        wyzZG:
        goto h1uuc;
        goto Dt8t2;
        tc9gV:
        $qf4Mx = now();
        goto Gt5ZM;
        Ue6m9:
        $fweA7 = $n_SMb * $TZoxt;
        goto dxKi3;
        SsGYg:
        if (!($qf4Mx->diffInDays($wRmvN, false) <= 0)) {
            goto pTo5B;
        }
        goto MyTCb;
        wbelq:
    }
}
