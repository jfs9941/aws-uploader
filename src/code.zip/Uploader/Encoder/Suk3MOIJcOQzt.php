<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Service\CbfzS01NR7tQ9;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Suk3MOIJcOQzt
{
    public const Ra11p = 'v2/hls/';
    private $a_x95;
    private $m2kWg;
    public function __construct(CbfzS01NR7tQ9 $cDtoP, Filesystem $Npup8)
    {
        $this->a_x95 = $cDtoP;
        $this->m2kWg = $Npup8;
    }
    public function mgMoXe96s1W($jZqB7) : string
    {
        return $this->a_x95->mAH1KdigIIv(self::Ra11p . $jZqB7->getAttribute('id') . '/');
    }
    public function mEFZAYLFLa1($jZqB7) : string
    {
        return $this->a_x95->mAH1KdigIIv(self::Ra11p . $jZqB7->getAttribute('id') . '/thumbnail/');
    }
    public function mRCKRLjcqRx($jZqB7, $aoc2n = true) : string
    {
        goto fazE7;
        fazE7:
        if ($aoc2n) {
            goto RkEYW;
        }
        goto fMQfc;
        X_Qvl:
        return $this->a_x95->mAH1KdigIIv(self::Ra11p . $jZqB7->getAttribute('id') . '/' . $jZqB7->getAttribute('id') . '.m3u8');
        goto sOavV;
        Fv2o3:
        RkEYW:
        goto X_Qvl;
        fMQfc:
        return self::Ra11p . $jZqB7->getAttribute('id') . '/' . $jZqB7->getAttribute('id') . '.m3u8';
        goto Fv2o3;
        sOavV:
    }
    public function resolveThumbnail($jZqB7) : string
    {
        goto HaxqH;
        K7NPC:
        return 1 == count($njpzc) ? self::Ra11p . $Brk87 . '/thumbnail/' . $Brk87 . '.0000000.jpg' : self::Ra11p . $Brk87 . '/thumbnail/' . $Brk87 . '.0000001.jpg';
        goto ZLTz1;
        O4AHH:
        $njpzc = $this->m2kWg->files($this->mEFZAYLFLa1($jZqB7));
        goto K7NPC;
        HaxqH:
        $Brk87 = $jZqB7->getAttribute('id');
        goto O4AHH;
        ZLTz1:
    }
    public function m07WIbK8s3Z(string $F0ycc) : string
    {
        return $this->m2kWg->url($F0ycc);
    }
}
