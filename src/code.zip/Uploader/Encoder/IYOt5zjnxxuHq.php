<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Encoder; use Illuminate\Contracts\Filesystem\Filesystem; use Jfs\Uploader\Core\DIYGIfCt7MLhm; use Jfs\Uploader\Service\MHO6UkLMvWeCm; final class IYOt5zjnxxuHq { public const WFdYY = 'v2/hls/'; private $me5uL; private $yvqrD; public function __construct(MHO6UkLMvWeCm $D8e4X, Filesystem $bPZ2H) { $this->me5uL = $D8e4X; $this->yvqrD = $bPZ2H; } public function m2fLGWkqIGZ($mzQW8) : string { return $this->me5uL->mISCdNwM4Qe(self::WFdYY . $mzQW8->getAttribute('id') . '/'); } public function mxJ9RHyHjml($mzQW8) : string { return $this->me5uL->mISCdNwM4Qe(self::WFdYY . $mzQW8->getAttribute('id') . '/thumbnail/'); } public function m3Yzhwn2rgd($mzQW8, $Ughc7 = true) : string { goto ti92V; iOr4l: kVCTx: goto gYBq5; FKjZM: return self::WFdYY . $mzQW8->getAttribute('id') . '/' . $mzQW8->getAttribute('id') . '.m3u8'; goto iOr4l; ti92V: if ($Ughc7) { goto kVCTx; } goto FKjZM; gYBq5: return $this->me5uL->mISCdNwM4Qe(self::WFdYY . $mzQW8->getAttribute('id') . '/' . $mzQW8->getAttribute('id') . '.m3u8'); goto XKAFS; XKAFS: } public function resolveThumbnail($mzQW8) : string { goto I80Hz; aF0J3: return 1 == count($J6GMu) ? self::WFdYY . $hJXEE . '/thumbnail/' . $hJXEE . '.0000000.jpg' : self::WFdYY . $hJXEE . '/thumbnail/' . $hJXEE . '.0000001.jpg'; goto DoYlw; I80Hz: $hJXEE = $mzQW8->getAttribute('id'); goto YKZYX; YKZYX: $J6GMu = $this->yvqrD->files($this->mxJ9RHyHjml($mzQW8)); goto aF0J3; DoYlw: } public function mRby3OaD6qG(string $lb3BP) : string { return $this->yvqrD->url($lb3BP); } }
