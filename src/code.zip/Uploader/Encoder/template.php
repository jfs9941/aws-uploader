<?php

return [
    "Queue" => "",
    "UserMetadata" => [
    ],
    "Role" => "",
    "Settings" => [
        "TimecodeConfig" => [
            "Source" => "ZEROBASED"
        ],
        "OutputGroups" => [
            [
                "CustomName" => "HLS",
                "Name" => "Apple HLS",
                "Outputs" => [
                    [
                        "ContainerSettings" => [
                            "Container" => "M3U8",
                            "M3u8Settings" => [
                            ]
                        ],
                        "VideoDescription" => [
                            "CodecSettings" => [
                                "Codec" => "H_264",
                                "H264Settings" => [
                                    "MaxBitrate" => 15000000,
                                    "RateControlMode" => "QVBR",
                                    "SceneChangeDetect" => "TRANSITION_DETECTION"
                                ]
                            ]
                        ],
                        "AudioDescriptions" => [
                            [
                                "CodecSettings" => [
                                    "Codec" => "AAC",
                                    "AacSettings" => [
                                        "Bitrate" => 96000,
                                        "CodingMode" => "CODING_MODE_2_0",
                                        "SampleRate" => 48000
                                    ]
                                ]
                            ]
                        ],
                        "OutputSettings" => [
                            "HlsSettings" => [
                            ]
                        ],
                        "NameModifier" => "4k"
                    ],
                    [
                        "ContainerSettings" => [
                            "Container" => "M3U8",
                            "M3u8Settings" => [
                            ]
                        ],
                        "VideoDescription" => [
                            "Width" => 1920,
                            "Height" => 1080,
                            "VideoPreprocessors" => [
                                "ImageInserter" => [
                                    "InsertableImages" => [
                                        [
                                            "Width" => 300,
                                            "ImageX" => 50,
                                            "ImageY" => 50,
                                            "FadeIn" => 1,
                                            "Layer" => 1,
                                            "ImageInserterInput" => "",
                                            "Opacity" => 20
                                        ]
                                    ]
                                ]
                            ],
                            "CodecSettings" => [
                                "Codec" => "H_264",
                                "H264Settings" => [
                                    "MaxBitrate" => 5000000,
                                    "RateControlMode" => "QVBR",
                                    "SceneChangeDetect" => "TRANSITION_DETECTION"
                                ]
                            ]
                        ],
                        "AudioDescriptions" => [
                            [
                                "CodecSettings" => [
                                    "Codec" => "AAC",
                                    "AacSettings" => [
                                        "Bitrate" => 96000,
                                        "CodingMode" => "CODING_MODE_2_0",
                                        "SampleRate" => 48000
                                    ]
                                ]
                            ]
                        ],
                        "OutputSettings" => [
                            "HlsSettings" => [
                            ]
                        ],
                        "NameModifier" => "1080p"
                    ]
                ],
                "OutputGroupSettings" => [
                    "Type" => "HLS_GROUP_SETTINGS",
                    "HlsGroupSettings" => [
                        "SegmentLength" => 10,
                        "Destination" => "",
                        "MinSegmentLength" => 0
                    ]
                ]
            ],
            [
                "CustomName" => "thumbnail",
                "Name" => "File Group",
                "Outputs" => [
                    [
                        "ContainerSettings" => [
                            "Container" => "RAW"
                        ],
                        "VideoDescription" => [
                            "CodecSettings" => [
                                "Codec" => "FRAME_CAPTURE",
                                "FrameCaptureSettings" => [
                                    "FramerateNumerator" => 1,
                                    "FramerateDenominator" => 120
                                ]
                            ]
                        ],
                        "Extension" => ".jpg",
                        "NameModifier" => "thumbnail"
                    ]
                ],
                "OutputGroupSettings" => [
                    "Type" => "FILE_GROUP_SETTINGS",
                    "FileGroupSettings" => [
                        "Destination" => ""
                    ]
                ]
            ]
        ],
        "FollowSource" => 1,
        "Inputs" => [
            [
                "AudioSelectors" => [
                    "Audio Selector 1" => [
                        "DefaultSelection" => "DEFAULT"
                    ]
                ],
                "VideoSelector" => [
                ],
                "TimecodeSource" => "ZEROBASED",
                "FileInput" => ""
            ]
        ]
    ],
    "BillingTagsSource" => "JOB",
    "AccelerationSettings" => [
        "Mode" => "DISABLED",
    ],
    "StatusUpdateInterval" => "SECONDS_60",
    "Priority" => 0
];

