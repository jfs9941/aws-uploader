<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Service\DkSooBIdtZWQo;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Uql37EhjWaxp7
{
    public const mDYKf = 'v2/hls/';
    private $RNu7s;
    private $f1xKj;
    public function __construct(DkSooBIdtZWQo $S5eAy, Filesystem $C6boj)
    {
        $this->RNu7s = $S5eAy;
        $this->f1xKj = $C6boj;
    }
    public function mNQLRJaaozO($Uas5p) : string
    {
        return $this->RNu7s->mg25WKxCVWs(self::mDYKf . $Uas5p->getAttribute('id') . '/');
    }
    public function mUN0m6CqieY($Uas5p) : string
    {
        return $this->RNu7s->mg25WKxCVWs(self::mDYKf . $Uas5p->getAttribute('id') . '/thumbnail/');
    }
    public function mFYZEhdMp2r($Uas5p, $hhG4L = true) : string
    {
        goto nvoTp;
        M9q6b:
        return self::mDYKf . $Uas5p->getAttribute('id') . '/' . $Uas5p->getAttribute('id') . '.m3u8';
        goto YoL4E;
        YoL4E:
        TJK6Z:
        goto IgQFx;
        IgQFx:
        return $this->RNu7s->mg25WKxCVWs(self::mDYKf . $Uas5p->getAttribute('id') . '/' . $Uas5p->getAttribute('id') . '.m3u8');
        goto omxq_;
        nvoTp:
        if ($hhG4L) {
            goto TJK6Z;
        }
        goto M9q6b;
        omxq_:
    }
    public function resolveThumbnail($Uas5p) : string
    {
        goto d1nJr;
        uFiDG:
        return 1 == count($B1xo6) ? self::mDYKf . $g5e_r . '/thumbnail/' . $g5e_r . '.0000000.jpg' : self::mDYKf . $g5e_r . '/thumbnail/' . $g5e_r . '.0000001.jpg';
        goto RY4Cq;
        d1nJr:
        $g5e_r = $Uas5p->getAttribute('id');
        goto Yh_1M;
        Yh_1M:
        $B1xo6 = $this->f1xKj->files($this->mUN0m6CqieY($Uas5p));
        goto uFiDG;
        RY4Cq:
    }
    public function mBnCkluHEio(string $FlxOy) : string
    {
        return $this->f1xKj->url($FlxOy);
    }
}
