<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\TTEkHy4psgQsg;
use Jfs\Uploader\Encoder\XrhvIuy1MK56M;
use Jfs\Uploader\Encoder\BHaSp176lnu5Y;
use Illuminate\Support\Facades\Log;
final class Ef3aL8loW3QaG
{
    private $VA2Oa;
    private $biioY;
    private $dENCb;
    private $JA8KH;
    private $YF4b6;
    private $AzM3T;
    private $nuqvM;
    public function __construct(MediaConvertClient $joACK, $gYU49, $PpqtT)
    {
        goto m7Utm;
        OGMzk:
        $this->AzM3T = $PpqtT;
        goto EaA0O;
        wycGL:
        $this->YF4b6 = $gYU49;
        goto OGMzk;
        m7Utm:
        $this->JA8KH = $joACK;
        goto wycGL;
        EaA0O:
    }
    public function mFdc1NlPbX2() : MediaConvertClient
    {
        return $this->JA8KH;
    }
    public function miRslcMQBQz(BHaSp176lnu5Y $g2pEj) : self
    {
        $this->VA2Oa = $g2pEj;
        return $this;
    }
    public function mlobzpA37IO(string $h6t5D) : self
    {
        $this->dENCb = $h6t5D;
        return $this;
    }
    public function mH5GeY4NbmR(XrhvIuy1MK56M $aiaS5) : self
    {
        $this->biioY[] = $aiaS5;
        return $this;
    }
    public function mTHp9v2NOiU(TTEkHy4psgQsg $XqjZc) : self
    {
        $this->nuqvM = $XqjZc;
        return $this;
    }
    private function mUyI2EY8ZIm(bool $Q_Y3B) : array
    {
        goto zUDw_;
        vUE2K:
        foreach ($this->biioY as $aiaS5) {
            $g3O01['Outputs'][] = $aiaS5->m2UQ5g18FcF();
            WLFkW:
        }
        goto LFbEc;
        W6dwm:
        $this->biioY = [];
        goto iyN3o;
        lmzFM:
        $hVdr2['Role'] = $this->YF4b6;
        goto GgQKp;
        mL05d:
        qAyp8:
        goto mMJP6;
        oNMir:
        if (!$Q_Y3B) {
            goto js14Y;
        }
        goto sD0SY;
        xUEEd:
        $g3O01['Outputs'] = [];
        goto vUE2K;
        v16sg:
        js14Y:
        goto bZvtB;
        J8c4V:
        $g3O01 = $hVdr2['Settings']['OutputGroups'][0];
        goto vdlWW;
        bZvtB:
        $this->nuqvM = null;
        goto TQVNB;
        tcg72:
        $hVdr2['Settings']['OutputGroups'][] = $this->nuqvM->m7CWtkKXz7u();
        goto x6Fl2;
        iyN3o:
        return $hVdr2;
        goto wzTx0;
        zUDw_:
        $hVdr2 = (require 'template.php');
        goto lmzFM;
        EMT7J:
        $hVdr2['Settings']['OutputGroups'][] = $g3O01;
        goto tavwl;
        x6Fl2:
        H6jH4:
        goto oNMir;
        mMJP6:
        $hVdr2['Settings']['Inputs'] = $this->VA2Oa->mA5UWVi3SuQ();
        goto J8c4V;
        LFbEc:
        UR4Zv:
        goto M1Jds;
        tavwl:
        if (!$this->nuqvM) {
            goto H6jH4;
        }
        goto tcg72;
        bR4eT:
        if ($this->VA2Oa) {
            goto qAyp8;
        }
        goto ZCdDt;
        M1Jds:
        $g3O01['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->dENCb;
        goto EMT7J;
        TQVNB:
        $this->VA2Oa = null;
        goto W6dwm;
        GgQKp:
        $hVdr2['Queue'] = $this->AzM3T;
        goto bR4eT;
        vdlWW:
        unset($hVdr2['Settings']['OutputGroups']);
        goto xUEEd;
        ZCdDt:
        throw new \LogicException('You must provide a input file to use');
        goto mL05d;
        sD0SY:
        $hVdr2['AccelerationSettings']['Mode'] = 'ENABLED';
        goto v16sg;
        wzTx0:
    }
    public function mhc1VBSXL2D(bool $Q_Y3B = false) : string
    {
        try {
            $KZQPV = $this->JA8KH->createJob($this->mUyI2EY8ZIm($Q_Y3B));
            return $KZQPV->get('Job')['Id'];
        } catch (AwsException $j62Rn) {
            Log::error('Error creating MediaConvert job: ' . $j62Rn->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $j62Rn);
        }
    }
}
