<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Xx4ycHeslCT9O
{
    private $Jw4jk;
    public function __construct(string $EpQ58, int $EuKLQ, int $CzBW0, ?int $yyWeX, ?int $q2cOY)
    {
        goto wWwOo;
        GTmyY:
        $this->Jw4jk['ImageInserter']['InsertableImages'][0]['Height'] = $q2cOY;
        goto Xu1wR;
        wWwOo:
        $this->Jw4jk = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $EuKLQ, 'ImageY' => $CzBW0, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $EpQ58, 'Opacity' => 35]]]];
        goto FGPMz;
        Xu1wR:
        KMc_5:
        goto i96_h;
        FGPMz:
        if (!($yyWeX && $q2cOY)) {
            goto KMc_5;
        }
        goto e2LFQ;
        e2LFQ:
        $this->Jw4jk['ImageInserter']['InsertableImages'][0]['Width'] = $yyWeX;
        goto GTmyY;
        i96_h:
    }
    public function m8szk8kRcUJ() : array
    {
        return $this->Jw4jk;
    }
}
