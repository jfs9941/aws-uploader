<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Service\TUSrCGJanJHY8;
use Illuminate\Contracts\Filesystem\Filesystem;
final class FKhlIfmeSlJUJ
{
    public const qAq6k = 'v2/hls/';
    private $xu37t;
    private $ZN9hu;
    public function __construct(TUSrCGJanJHY8 $Y5OI2, Filesystem $C2YXG)
    {
        $this->xu37t = $Y5OI2;
        $this->ZN9hu = $C2YXG;
    }
    public function mY1QlrNe3OT($XrW52) : string
    {
        return $this->xu37t->meJLhlZY0za(self::qAq6k . $XrW52->getAttribute('id') . '/');
    }
    public function mRNA9tPncMR($XrW52) : string
    {
        return $this->xu37t->meJLhlZY0za(self::qAq6k . $XrW52->getAttribute('id') . '/thumbnail/');
    }
    public function mGPE01n9uNI($XrW52, $HpV6k = true) : string
    {
        goto IkWup;
        IkWup:
        if ($HpV6k) {
            goto Aowj1;
        }
        goto b__Xq;
        b__Xq:
        return self::qAq6k . $XrW52->getAttribute('id') . '/' . $XrW52->getAttribute('id') . '.m3u8';
        goto l2czP;
        y71LC:
        return $this->xu37t->meJLhlZY0za(self::qAq6k . $XrW52->getAttribute('id') . '/' . $XrW52->getAttribute('id') . '.m3u8');
        goto UbL7y;
        l2czP:
        Aowj1:
        goto y71LC;
        UbL7y:
    }
    public function resolveThumbnail($XrW52) : string
    {
        goto YHkwQ;
        YHkwQ:
        $uuHkQ = $XrW52->getAttribute('id');
        goto OWc2q;
        a7hEi:
        return 1 == count($UZokb) ? self::qAq6k . $uuHkQ . '/thumbnail/' . $uuHkQ . '.0000000.jpg' : self::qAq6k . $uuHkQ . '/thumbnail/' . $uuHkQ . '.0000001.jpg';
        goto NNudQ;
        OWc2q:
        $UZokb = $this->ZN9hu->files($this->mRNA9tPncMR($XrW52));
        goto a7hEi;
        NNudQ:
    }
    public function mzptx565HGm(string $dSgog) : string
    {
        return $this->ZN9hu->url($dSgog);
    }
}
