<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class BPO1kQM9JvpAH
{
    private $u4XxL;
    public function __construct(float $bI9gh, int $QMFgj, string $suBw_)
    {
        goto rCCPI;
        U4uYC:
        $ImRQe = max($ImRQe, 1);
        goto hn4Ir;
        rCCPI:
        $ImRQe = (int) $bI9gh / $QMFgj;
        goto U4uYC;
        hn4Ir:
        $this->u4XxL = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ImRQe]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $suBw_]]];
        goto B9yRd;
        B9yRd:
    }
    public function m35hxQJW42U() : array
    {
        return $this->u4XxL;
    }
}
