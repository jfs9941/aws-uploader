<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Service\ETNYJFyUYZrNI;
use Illuminate\Contracts\Filesystem\Filesystem;
final class NLoWoIWKwVnRR
{
    public const nJDk9 = 'v2/hls/';
    private $xdRfu;
    private $zbU8n;
    public function __construct(ETNYJFyUYZrNI $aPiO3, Filesystem $Efy84)
    {
        $this->xdRfu = $aPiO3;
        $this->zbU8n = $Efy84;
    }
    public function minDTpyVKdX($fTkob) : string
    {
        return $this->xdRfu->mQGt2T4MpQP(self::nJDk9 . $fTkob->getAttribute('id') . '/');
    }
    public function mpe80m0Mib0($fTkob) : string
    {
        return $this->xdRfu->mQGt2T4MpQP(self::nJDk9 . $fTkob->getAttribute('id') . '/thumbnail/');
    }
    public function mODLijVpC6r($fTkob, $TYmHu = true) : string
    {
        goto IxSjd;
        Hkw5L:
        return self::nJDk9 . $fTkob->getAttribute('id') . '/' . $fTkob->getAttribute('id') . '.m3u8';
        goto KN2ML;
        IxSjd:
        if ($TYmHu) {
            goto feovU;
        }
        goto Hkw5L;
        Y3vBT:
        return $this->xdRfu->mQGt2T4MpQP(self::nJDk9 . $fTkob->getAttribute('id') . '/' . $fTkob->getAttribute('id') . '.m3u8');
        goto PGvRr;
        KN2ML:
        feovU:
        goto Y3vBT;
        PGvRr:
    }
    public function resolveThumbnail($fTkob) : string
    {
        goto mqTzA;
        mqTzA:
        $N2oAf = $fTkob->getAttribute('id');
        goto f1ZK9;
        Tme81:
        return 1 == count($lak6A) ? self::nJDk9 . $N2oAf . '/thumbnail/' . $N2oAf . '.0000000.jpg' : self::nJDk9 . $N2oAf . '/thumbnail/' . $N2oAf . '.0000001.jpg';
        goto bUxYS;
        f1ZK9:
        $lak6A = $this->zbU8n->files($this->mpe80m0Mib0($fTkob));
        goto Tme81;
        bUxYS:
    }
    public function m33UnCr3UH0(string $vRakW) : string
    {
        return $this->zbU8n->url($vRakW);
    }
}
