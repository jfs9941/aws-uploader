<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Service\BJWEJOjkkZaRL;
use Illuminate\Contracts\Filesystem\Filesystem;
final class VBDy3Gb7TKD1d
{
    public const OPmLf = 'v2/hls/';
    private $NfIDR;
    private $UoQI7;
    public function __construct(BJWEJOjkkZaRL $ILKvW, Filesystem $UjVft)
    {
        $this->NfIDR = $ILKvW;
        $this->UoQI7 = $UjVft;
    }
    public function mhSeqlHcPhr($qF0aQ) : string
    {
        return $this->NfIDR->m544f5UHTMS(self::OPmLf . $qF0aQ->getAttribute('id') . '/');
    }
    public function mVMlY7UBB1W($qF0aQ) : string
    {
        return $this->NfIDR->m544f5UHTMS(self::OPmLf . $qF0aQ->getAttribute('id') . '/thumbnail/');
    }
    public function mP3mzlMmoKr($qF0aQ, $jRY06 = true) : string
    {
        goto a_OKy;
        LepXv:
        return $this->NfIDR->m544f5UHTMS(self::OPmLf . $qF0aQ->getAttribute('id') . '/' . $qF0aQ->getAttribute('id') . '.m3u8');
        goto Z1X4s;
        RA6m1:
        return self::OPmLf . $qF0aQ->getAttribute('id') . '/' . $qF0aQ->getAttribute('id') . '.m3u8';
        goto wpN2k;
        wpN2k:
        KxQnm:
        goto LepXv;
        a_OKy:
        if ($jRY06) {
            goto KxQnm;
        }
        goto RA6m1;
        Z1X4s:
    }
    public function resolveThumbnail($qF0aQ) : string
    {
        goto zqbcx;
        mvKbs:
        return 1 == count($esB70) ? self::OPmLf . $InHEz . '/thumbnail/' . $InHEz . '.0000000.jpg' : self::OPmLf . $InHEz . '/thumbnail/' . $InHEz . '.0000001.jpg';
        goto FxKLA;
        lW23o:
        $esB70 = $this->UoQI7->files($this->mVMlY7UBB1W($qF0aQ));
        goto mvKbs;
        zqbcx:
        $InHEz = $qF0aQ->getAttribute('id');
        goto lW23o;
        FxKLA:
    }
    public function mQBgOcq1nOj(string $hKqqZ) : string
    {
        return $this->UoQI7->url($hKqqZ);
    }
}
