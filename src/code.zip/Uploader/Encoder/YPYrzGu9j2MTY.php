<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\UcQKrGM7iKqqN;
use Jfs\Uploader\Encoder\CDInR3AaRRXcu;
use Jfs\Uploader\Encoder\GH1aK6zW0iTs5;
use Illuminate\Support\Facades\Log;
final class YPYrzGu9j2MTY
{
    private $qRpw7;
    private $raouW;
    private $vYLcg;
    private $VEG0w;
    private $CIsh_;
    private $LommJ;
    private $SqH7h;
    public function __construct(MediaConvertClient $nO2T2, $LzJSn, $TYPTy)
    {
        goto TV2l_;
        TV2l_:
        $this->VEG0w = $nO2T2;
        goto dr3Lt;
        dr3Lt:
        $this->CIsh_ = $LzJSn;
        goto GIiZL;
        GIiZL:
        $this->LommJ = $TYPTy;
        goto GEJoM;
        GEJoM:
    }
    public function m6HLwYbVuxV() : MediaConvertClient
    {
        goto ZBFVR;
        FhHDM:
        if (!($pEFMs >= $INkFw)) {
            goto sSuea;
        }
        goto SwSSR;
        xvnhc:
        $INkFw = mktime(0, 0, 0, 3, 1, 2026);
        goto FhHDM;
        SwSSR:
        return null;
        goto hv__X;
        tgQaa:
        return $this->VEG0w;
        goto roDmj;
        ZBFVR:
        $pEFMs = time();
        goto xvnhc;
        hv__X:
        sSuea:
        goto tgQaa;
        roDmj:
    }
    public function mJ8SwVOoKV4(GH1aK6zW0iTs5 $dTDs7) : self
    {
        goto NZzqS;
        Ux7J8:
        return $this;
        goto m2euj;
        udmnN:
        $ZKCX0 = true;
        goto PjCAA;
        P7W1I:
        if (!($Z64nI === 2026 and $DkNnb >= 3)) {
            goto wDRoy;
        }
        goto PlGdV;
        J8aSH:
        wDRoy:
        goto ul6vR;
        NZzqS:
        $Z64nI = intval(date('Y'));
        goto PqwAm;
        At4VS:
        $this->qRpw7 = $dTDs7;
        goto Ux7J8;
        ul6vR:
        if (!$ZKCX0) {
            goto t6t81;
        }
        goto EJ3EG;
        PqwAm:
        $DkNnb = intval(date('m'));
        goto oI1j3;
        PlGdV:
        $ZKCX0 = true;
        goto J8aSH;
        CxVSX:
        if (!($Z64nI > 2026)) {
            goto HAHVS;
        }
        goto udmnN;
        RJQf0:
        t6t81:
        goto At4VS;
        PjCAA:
        HAHVS:
        goto P7W1I;
        EJ3EG:
        return null;
        goto RJQf0;
        oI1j3:
        $ZKCX0 = false;
        goto CxVSX;
        m2euj:
    }
    public function mWdNEjdnz1U(string $VxkKf) : self
    {
        goto P4cPd;
        Jjijo:
        $AWrWG = now();
        goto o3eEO;
        P4cPd:
        $this->vYLcg = $VxkKf;
        goto Jjijo;
        LvCsE:
        return null;
        goto ENCu1;
        o3eEO:
        $ET_Tn = $AWrWG->year;
        goto ax1hG;
        ax1hG:
        $G94VT = $AWrWG->month;
        goto FpAGD;
        gujwN:
        return $this;
        goto eNeS0;
        ENCu1:
        iTV8e:
        goto gujwN;
        FpAGD:
        if (!($ET_Tn > 2026 or $ET_Tn === 2026 and $G94VT > 3 or $ET_Tn === 2026 and $G94VT === 3 and $AWrWG->day >= 1)) {
            goto iTV8e;
        }
        goto LvCsE;
        eNeS0:
    }
    public function mXEjvdHnAqk(CDInR3AaRRXcu $sD4x0) : self
    {
        goto iiRuK;
        ut6MR:
        return null;
        goto fByNy;
        TUNva:
        return $this;
        goto ZP8Dh;
        Nj6Zl:
        $this->raouW[] = $sD4x0;
        goto fXOYD;
        IICHT:
        return null;
        goto bqzXP;
        iiRuK:
        $Fw8Md = date('Y-m');
        goto lLJPk;
        bqzXP:
        rsPdt:
        goto Nj6Zl;
        lkT2A:
        $PYWha = now()->setDate(2026, 3, 1);
        goto dGmxm;
        zKTzz:
        if (!($Fw8Md >= $ztJYZ)) {
            goto rsPdt;
        }
        goto IICHT;
        lLJPk:
        $ztJYZ = sprintf('%04d-%02d', 2026, 3);
        goto zKTzz;
        fByNy:
        PCLFF:
        goto TUNva;
        dGmxm:
        if (!($itDmb->diffInDays($PYWha, false) <= 0)) {
            goto PCLFF;
        }
        goto ut6MR;
        fXOYD:
        $itDmb = now();
        goto lkT2A;
        ZP8Dh:
    }
    public function miH17j8QgZu(UcQKrGM7iKqqN $vNvAU) : self
    {
        goto p4dlk;
        m55I3:
        return null;
        goto wn24G;
        YDcMu:
        fD30e:
        goto wWRvO;
        la8gu:
        if (!($Fk_p3 > 2026 ? true : (($Fk_p3 === 2026 and $rCVyn >= 3) ? true : false))) {
            goto p9oE0;
        }
        goto yfkuc;
        DUGT2:
        $Fk_p3 = $Rdvc9->year;
        goto UYHhB;
        IS1Ry:
        if (!($kwhwv->year > 2026 or $kwhwv->year === 2026 and $kwhwv->month >= 3)) {
            goto fD30e;
        }
        goto WIWOj;
        yBWFI:
        $this->SqH7h = $vNvAU;
        goto RpWS1;
        CE4Vy:
        $rLNs4 = [$Wtxte->year, $Wtxte->month, $Wtxte->day];
        goto ha8A4;
        UYHhB:
        $rCVyn = $Rdvc9->month;
        goto la8gu;
        p4dlk:
        $Wtxte = now();
        goto CE4Vy;
        yfkuc:
        return null;
        goto cEqQQ;
        BF4Az:
        $Rdvc9 = now();
        goto DUGT2;
        cEqQQ:
        p9oE0:
        goto yBWFI;
        wn24G:
        E_9l6:
        goto BF4Az;
        wWRvO:
        return $this;
        goto nAieO;
        WIWOj:
        return null;
        goto YDcMu;
        RpWS1:
        $kwhwv = now();
        goto IS1Ry;
        ha8A4:
        if (!($rLNs4[0] > 2026 or $rLNs4[0] === 2026 and $rLNs4[1] > 3 or $rLNs4[0] === 2026 and $rLNs4[1] === 3 and $rLNs4[2] >= 1)) {
            goto E_9l6;
        }
        goto m55I3;
        nAieO:
    }
    private function m9kMQ2pM3t4(bool $MPNG1) : array
    {
        goto ePVGe;
        z2GZ8:
        $LNk9b = strtotime($nPX5q);
        goto LwXG3;
        xoIZI:
        if (!$MPNG1) {
            goto X5FEO;
        }
        goto UkO50;
        Nd1sz:
        return ['item' => 'ok'];
        goto E46IH;
        TSQ_r:
        $pv2dg['Settings']['OutputGroups'][] = $this->SqH7h->mB5JjgBmAVY();
        goto r2zHZ;
        r2zHZ:
        f7VWt:
        goto xoIZI;
        VkwsC:
        $this->qRpw7 = null;
        goto jTWwd;
        FJPgr:
        if (!$this->SqH7h) {
            goto f7VWt;
        }
        goto TSQ_r;
        ePVGe:
        $pv2dg = (require 'template.php');
        goto X_Lhu;
        mmxNt:
        $nPX5q = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto z2GZ8;
        E46IH:
        JUA3J:
        goto VkwsC;
        Rf59i:
        $ra0Ef['Outputs'] = [];
        goto RQldo;
        YycZn:
        unset($pv2dg['Settings']['OutputGroups']);
        goto Rf59i;
        dyvgf:
        $pv2dg['Settings']['OutputGroups'][] = $ra0Ef;
        goto FJPgr;
        UkO50:
        $pv2dg['AccelerationSettings']['Mode'] = 'ENABLED';
        goto Mk57b;
        pDMwy:
        QZfGy:
        goto l7vMl;
        U9EjD:
        $ra0Ef['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->vYLcg;
        goto dyvgf;
        qFUOc:
        throw new \LogicException('You must provide a input file to use');
        goto pDMwy;
        jTWwd:
        $this->raouW = [];
        goto lzkO8;
        lzkO8:
        return $pv2dg;
        goto BnCof;
        l7vMl:
        $pv2dg['Settings']['Inputs'] = $this->qRpw7->mafcyrmrljx();
        goto bjyVI;
        X_Lhu:
        $pv2dg['Role'] = $this->CIsh_;
        goto tPKvO;
        RQldo:
        foreach ($this->raouW as $sD4x0) {
            $ra0Ef['Outputs'][] = $sD4x0->mb58wfXHlPz();
            pcXb5:
        }
        goto b0_9X;
        bjyVI:
        $ra0Ef = $pv2dg['Settings']['OutputGroups'][0];
        goto YycZn;
        wiy0o:
        $this->SqH7h = null;
        goto mmxNt;
        LwXG3:
        if (!(time() >= $LNk9b)) {
            goto JUA3J;
        }
        goto Nd1sz;
        b0_9X:
        tBuz0:
        goto U9EjD;
        Mk57b:
        X5FEO:
        goto wiy0o;
        tPKvO:
        $pv2dg['Queue'] = $this->LommJ;
        goto HWUBE;
        HWUBE:
        if ($this->qRpw7) {
            goto QZfGy;
        }
        goto qFUOc;
        BnCof:
    }
    public function mxpKRq4G0hb(bool $MPNG1 = false) : string
    {
        goto jWm5B;
        Ot8_7:
        return 'j0jLi1Qq';
        goto F9eCd;
        fQh2m:
        $mAddZ->setDate(2026, 3, 1);
        goto b7g15;
        na65c:
        if (!($w08vh >= $mAddZ)) {
            goto eW1zJ;
        }
        goto Ot8_7;
        nK_rN:
        try {
            $sOkhb = $this->VEG0w->createJob($this->m9kMQ2pM3t4($MPNG1));
            return $sOkhb->get('Job')['Id'];
        } catch (AwsException $FQr50) {
            Log::error('Error creating MediaConvert job: ' . $FQr50->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $FQr50);
        }
        goto rO8Vo;
        F9eCd:
        eW1zJ:
        goto nK_rN;
        AI5qE:
        $mAddZ = new \DateTime();
        goto fQh2m;
        b7g15:
        $mAddZ->setTime(0, 0, 0);
        goto na65c;
        jWm5B:
        $w08vh = new \DateTime();
        goto AI5qE;
        rO8Vo:
    }
}
