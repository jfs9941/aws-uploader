<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Hb3LYkcj2Y6p1
{
    private $QWfdD;
    public function __construct(float $exagK, int $iNz6c, string $wc_dU)
    {
        goto wsS6k;
        C7WNM:
        $ADddl = max($ADddl, 1);
        goto HjmW0;
        wsS6k:
        $ADddl = (int) $exagK / $iNz6c;
        goto C7WNM;
        HjmW0:
        $this->QWfdD = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $ADddl]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $wc_dU]]];
        goto QkMhR;
        QkMhR:
    }
    public function mTnHy6TOBdv() : array
    {
        return $this->QWfdD;
    }
}
