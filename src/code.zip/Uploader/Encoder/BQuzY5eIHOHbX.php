<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Encoder;

use src\Uploader\Encoder\JdeFY2cy1uPti;

final class BQuzY5eIHOHbX
{
    private $EFb5h;
    public function __construct(string $Dvdtc, ?int $Lu5LP, ?int $IPfYY, float $kTTmZ)
    {
        goto jsfvU;
        lbN46:
        cCfFY:
        goto OuzBy;
        XxVPU:
        $this->EFb5h['VideoDescription']['Height'] = $IPfYY;
        goto lbN46;
        MtY1j:
        $this->EFb5h = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $tvNdt, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $Dvdtc];
        goto gZMce;
        jsfvU:
        $tvNdt = 15000000;
        goto Uw4hQ;
        HuZ_N:
        $tvNdt = $this->mFDagLHShDK($Lu5LP, $IPfYY, $kTTmZ);
        goto E7rmC;
        gZMce:
        if (!($Lu5LP && $IPfYY)) {
            goto cCfFY;
        }
        goto LvGc2;
        E7rmC:
        P8f5o:
        goto MtY1j;
        Uw4hQ:
        if (!($Lu5LP && $IPfYY)) {
            goto P8f5o;
        }
        goto HuZ_N;
        LvGc2:
        $this->EFb5h['VideoDescription']['Width'] = $Lu5LP;
        goto XxVPU;
        OuzBy:
    }
    public function mMuJO5lV3Wn(JdeFY2cy1uPti $lK1vK) : self
    {
        $this->EFb5h['VideoDescription']['VideoPreprocessors'] = $lK1vK->mgnDB0PERWb();
        return $this;
    }
    public function mqjQd3bKUpm() : array
    {
        return $this->EFb5h;
    }
    private function mFDagLHShDK(int $Lu5LP, int $IPfYY, float $eF3Gl, string $F9yrR = 'medium', string $ppLlV = 'h264', string $kjgNI = 'good') : ?int
    {
        goto zjODg;
        E8kVc:
        NA4QM:
        goto ggUWo;
        Y29dk:
        IALsT:
        goto hVU_e;
        wJbUq:
        $HUKBm = $HON19 * ($eF3Gl / 30);
        goto p_aTd;
        n52Jr:
        XKRWL:
        goto BDy9L;
        YbQzW:
        k8cAB:
        goto BbFLa;
        SRaPL:
        goto RnoNn;
        goto WQG11;
        cjcq7:
        if ($tZQS_ <= 1920 * 1080) {
            goto NA4QM;
        }
        goto i34y5;
        WQG11:
        MIhQp:
        goto vtwTJ;
        p_aTd:
        switch (strtolower($F9yrR)) {
            case 'low':
                $HUKBm *= 0.7;
                goto nLZ8z;
            case 'high':
                $HUKBm *= 1.3;
                goto nLZ8z;
            case 'veryhigh':
                $HUKBm *= 1.6;
                goto nLZ8z;
        }
        goto YbQzW;
        WSn6l:
        goto RnoNn;
        goto hlhOv;
        hWH8T:
        return (int) ($HUKBm * 1000 * 1000);
        goto ocwuC;
        vtwTJ:
        $HON19 = 20;
        goto SNFy0;
        hFf8p:
        $HON19 = 30;
        goto WSn6l;
        QOQNU:
        goto RnoNn;
        goto LwKwy;
        PTPYN:
        $HON19 = 12;
        goto SRaPL;
        msEC8:
        if ($tZQS_ <= 3840 * 2160) {
            goto MIhQp;
        }
        goto hFf8p;
        LwKwy:
        zAJV6:
        goto PTPYN;
        BDy9L:
        $HUKBm = max(0.5, $HUKBm);
        goto hWH8T;
        oRHJe:
        if (!('h265' === strtolower($ppLlV) || 'hevc' === strtolower($ppLlV) || 'vp9' === strtolower($ppLlV))) {
            goto IALsT;
        }
        goto HkHWS;
        zjODg:
        $tZQS_ = $Lu5LP * $IPfYY;
        goto JvYPL;
        idT5C:
        if ($tZQS_ <= 1280 * 720) {
            goto T3usj;
        }
        goto cjcq7;
        SNFy0:
        RnoNn:
        goto wJbUq;
        RBxQS:
        $HON19 = 1.5;
        goto vJoZW;
        PMhyy:
        goto RnoNn;
        goto E8kVc;
        hlhOv:
        woLLW:
        goto RBxQS;
        JvYPL:
        if ($tZQS_ <= 640 * 480) {
            goto woLLW;
        }
        goto idT5C;
        S1una:
        T3usj:
        goto ZE7HH;
        BbFLa:
        nLZ8z:
        goto oRHJe;
        mVoDd:
        I0yWY:
        goto n52Jr;
        ggUWo:
        $HON19 = 7;
        goto QOQNU;
        hVU_e:
        switch (strtolower($kjgNI)) {
            case 'low':
                $HUKBm *= 0.8;
                goto XKRWL;
            case 'high':
                $HUKBm *= 1.2;
                goto XKRWL;
        }
        goto mVoDd;
        vJoZW:
        goto RnoNn;
        goto S1una;
        HkHWS:
        $HUKBm *= 0.65;
        goto Y29dk;
        ZE7HH:
        $HON19 = 3;
        goto PMhyy;
        i34y5:
        if ($tZQS_ <= 2560 * 1440) {
            goto zAJV6;
        }
        goto msEC8;
        ocwuC:
    }
}
