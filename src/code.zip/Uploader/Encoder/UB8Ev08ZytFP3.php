<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Encoder\WIGsdnueGe9KG;
final class UB8Ev08ZytFP3
{
    private $hDG1X;
    public function __construct(string $YaxJ6, ?int $Nk4Te, ?int $jCfbb, float $FcthT)
    {
        goto TNxz1;
        TNxz1:
        $eXFAs = 15000000;
        goto RlRlY;
        mMee1:
        $this->hDG1X = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $eXFAs, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $YaxJ6];
        goto qyaOm;
        NG8Hn:
        $this->hDG1X['VideoDescription']['Height'] = $jCfbb;
        goto kuu_V;
        l5WjG:
        pkzNd:
        goto mMee1;
        CIYDn:
        $eXFAs = $this->migzQTQvgGZ($Nk4Te, $jCfbb, $FcthT);
        goto l5WjG;
        kuu_V:
        LG_aU:
        goto Vl828;
        qyaOm:
        if (!($Nk4Te && $jCfbb)) {
            goto LG_aU;
        }
        goto YF2My;
        YF2My:
        $this->hDG1X['VideoDescription']['Width'] = $Nk4Te;
        goto NG8Hn;
        RlRlY:
        if (!($Nk4Te && $jCfbb)) {
            goto pkzNd;
        }
        goto CIYDn;
        Vl828:
    }
    public function mKw0MA0RSTd(WIGsdnueGe9KG $RLzZk) : self
    {
        $this->hDG1X['VideoDescription']['VideoPreprocessors'] = $RLzZk->mLuYQwV68KK();
        return $this;
    }
    public function mSu7qfVuhUe() : array
    {
        return $this->hDG1X;
    }
    private function migzQTQvgGZ(int $Nk4Te, int $jCfbb, float $peedj, string $g0Btj = 'medium', string $tLG_I = 'h264', string $ew5v3 = 'good') : ?int
    {
        goto pVwf5;
        PewmN:
        switch (strtolower($g0Btj)) {
            case 'low':
                $AhGOM *= 0.7;
                goto mekBB;
            case 'high':
                $AhGOM *= 1.3;
                goto mekBB;
            case 'veryhigh':
                $AhGOM *= 1.6;
                goto mekBB;
        }
        goto rzMm6;
        TnnTv:
        $khClx = 30;
        goto JP_eZ;
        CNpWI:
        $AhGOM *= 0.65;
        goto fqiSm;
        n3oNc:
        Rw35u:
        goto VZ7vF;
        U_ppH:
        goto L_w4c;
        goto EykIc;
        ienql:
        $AhGOM = $khClx * ($peedj / 30);
        goto PewmN;
        YGxT2:
        M3ch5:
        goto vstOA;
        J73vs:
        knZ53:
        goto Jafk1;
        pHfCG:
        $khClx = 12;
        goto yIm01;
        VZ7vF:
        $khClx = 1.5;
        goto fibgv;
        kC_ak:
        if ($LTPjB <= 1280 * 720) {
            goto knZ53;
        }
        goto u8AGF;
        w3Wer:
        mekBB:
        goto sx0Xz;
        eQaJi:
        L_w4c:
        goto ienql;
        mM3wd:
        $AhGOM = max(0.5, $AhGOM);
        goto juDd8;
        JROV8:
        if ($LTPjB <= 3840 * 2160) {
            goto M3ch5;
        }
        goto TnnTv;
        tNlYd:
        switch (strtolower($ew5v3)) {
            case 'low':
                $AhGOM *= 0.8;
                goto WzcBH;
            case 'high':
                $AhGOM *= 1.2;
                goto WzcBH;
        }
        goto bGjAP;
        juDd8:
        return (int) ($AhGOM * 1000 * 1000);
        goto dXWtU;
        bGjAP:
        QPpYl:
        goto W0GIn;
        EykIc:
        lSkbr:
        goto pHfCG;
        fibgv:
        goto L_w4c;
        goto J73vs;
        rzMm6:
        vSwFl:
        goto w3Wer;
        fqiSm:
        TRKEn:
        goto tNlYd;
        pVwf5:
        $LTPjB = $Nk4Te * $jCfbb;
        goto qI9k_;
        yIm01:
        goto L_w4c;
        goto YGxT2;
        nI6WM:
        goto L_w4c;
        goto XGmZw;
        W0GIn:
        WzcBH:
        goto mM3wd;
        gOZ72:
        if ($LTPjB <= 2560 * 1440) {
            goto lSkbr;
        }
        goto JROV8;
        u8AGF:
        if ($LTPjB <= 1920 * 1080) {
            goto knmUu;
        }
        goto gOZ72;
        vstOA:
        $khClx = 20;
        goto eQaJi;
        sx0Xz:
        if (!('h265' === strtolower($tLG_I) || 'hevc' === strtolower($tLG_I) || 'vp9' === strtolower($tLG_I))) {
            goto TRKEn;
        }
        goto CNpWI;
        Jafk1:
        $khClx = 3;
        goto nI6WM;
        e7I8S:
        $khClx = 7;
        goto U_ppH;
        JP_eZ:
        goto L_w4c;
        goto n3oNc;
        XGmZw:
        knmUu:
        goto e7I8S;
        qI9k_:
        if ($LTPjB <= 640 * 480) {
            goto Rw35u;
        }
        goto kC_ak;
        dXWtU:
    }
}
