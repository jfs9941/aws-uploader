<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Yj19iV1uFCxpK;
use Jfs\Uploader\Encoder\ObirvLOHr65Us;
use Jfs\Uploader\Encoder\TpYPhel5ae8Mx;
use Illuminate\Support\Facades\Log;
final class Wlw2CGgLj1kt6
{
    private $tk94S;
    private $OgkOr;
    private $seOuj;
    private $LB2y8;
    private $rES3p;
    private $KQ7Ur;
    private $OFuJP;
    public function __construct(MediaConvertClient $IO3nR, $mF2xo, $lryv2)
    {
        goto HZ5oA;
        NSvN1:
        $this->KQ7Ur = $lryv2;
        goto seSH0;
        HZ5oA:
        $this->LB2y8 = $IO3nR;
        goto UBZwJ;
        UBZwJ:
        $this->rES3p = $mF2xo;
        goto NSvN1;
        seSH0:
    }
    public function mWegmXjX46O() : MediaConvertClient
    {
        return $this->LB2y8;
    }
    public function mbqxJAuhZaN(TpYPhel5ae8Mx $irkgv) : self
    {
        $this->tk94S = $irkgv;
        return $this;
    }
    public function mCWif6BXvyD(string $NeKM2) : self
    {
        $this->seOuj = $NeKM2;
        return $this;
    }
    public function mlIMlreHZ0X(ObirvLOHr65Us $DEI1F) : self
    {
        $this->OgkOr[] = $DEI1F;
        return $this;
    }
    public function mTemmvhAvNc(Yj19iV1uFCxpK $NnQOx) : self
    {
        $this->OFuJP = $NnQOx;
        return $this;
    }
    private function mqny01kmbo5(bool $xLD13) : array
    {
        goto sFmQu;
        v3QlP:
        ZvhBT:
        goto oGgBp;
        gvK03:
        H5TYY:
        goto O3QDQ;
        f14h5:
        if ($this->tk94S) {
            goto ZvhBT;
        }
        goto FxWhb;
        HIU3A:
        return $pnf3Z;
        goto XiRzh;
        ztJjw:
        $this->tk94S = null;
        goto KwiHM;
        KwiHM:
        $this->OgkOr = [];
        goto HIU3A;
        wQFZO:
        $WZLNV = $pnf3Z['Settings']['OutputGroups'][0];
        goto I0mWv;
        I0mWv:
        unset($pnf3Z['Settings']['OutputGroups']);
        goto U7gec;
        wLkXd:
        jVmyv:
        goto JUgAH;
        mPmx5:
        AQ_KI:
        goto GrUrY;
        GrUrY:
        $WZLNV['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->seOuj;
        goto BeHft;
        JUgAH:
        $this->OFuJP = null;
        goto ztJjw;
        Y5kXS:
        $pnf3Z['AccelerationSettings']['Mode'] = 'ENABLED';
        goto wLkXd;
        BeHft:
        $pnf3Z['Settings']['OutputGroups'][] = $WZLNV;
        goto k33GB;
        FxWhb:
        throw new \LogicException('You must provide a input file to use');
        goto v3QlP;
        DjYDl:
        $pnf3Z['Queue'] = $this->KQ7Ur;
        goto f14h5;
        zilrS:
        $pnf3Z['Role'] = $this->rES3p;
        goto DjYDl;
        vhnL5:
        foreach ($this->OgkOr as $DEI1F) {
            $WZLNV['Outputs'][] = $DEI1F->mLWKVbeM2x6();
            yPanO:
        }
        goto mPmx5;
        Ftc3r:
        $pnf3Z['Settings']['OutputGroups'][] = $this->OFuJP->mqoIvPsFZpI();
        goto gvK03;
        U7gec:
        $WZLNV['Outputs'] = [];
        goto vhnL5;
        oGgBp:
        $pnf3Z['Settings']['Inputs'] = $this->tk94S->mDkmXKGZK6A();
        goto wQFZO;
        O3QDQ:
        if (!$xLD13) {
            goto jVmyv;
        }
        goto Y5kXS;
        sFmQu:
        $pnf3Z = (require 'template.php');
        goto zilrS;
        k33GB:
        if (!$this->OFuJP) {
            goto H5TYY;
        }
        goto Ftc3r;
        XiRzh:
    }
    public function mvk1YpwJ4YW(bool $xLD13 = false) : string
    {
        try {
            $HgLpI = $this->LB2y8->createJob($this->mqny01kmbo5($xLD13));
            return $HgLpI->get('Job')['Id'];
        } catch (AwsException $bAo2Y) {
            Log::error('Error creating MediaConvert job: ' . $bAo2Y->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $bAo2Y);
        }
    }
}
