<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Jfs\Uploader\Encoder\Ag7BVyy9gBS3K;
use Jfs\Uploader\Encoder\G2VgYaXfgj3vR;
use Jfs\Uploader\Encoder\DMUpLei7KzwsT;
use Illuminate\Support\Facades\Log;
final class B5vx2QdfNEBBj
{
    private $SPXQX;
    private $shjMi;
    private $WL2xA;
    private $z32kc;
    private $qQvyN;
    private $EMD6s;
    private $Lkzkq;
    public function __construct(MediaConvertClient $q24y7, $cd9WC, $twrPB)
    {
        goto CFsI1;
        CFsI1:
        $this->z32kc = $q24y7;
        goto AAvL9;
        AAvL9:
        $this->qQvyN = $cd9WC;
        goto ZAXpF;
        ZAXpF:
        $this->EMD6s = $twrPB;
        goto JXiPH;
        JXiPH:
    }
    public function mHJ4uep5VNh() : MediaConvertClient
    {
        return $this->z32kc;
    }
    public function meenyFpkvLb(DMUpLei7KzwsT $VAcvS) : self
    {
        $this->SPXQX = $VAcvS;
        return $this;
    }
    public function m6V9zGKlPxn(string $Lzn6p) : self
    {
        $this->WL2xA = $Lzn6p;
        return $this;
    }
    public function mG8TwqJMYYe(G2VgYaXfgj3vR $B7brD) : self
    {
        $this->shjMi[] = $B7brD;
        return $this;
    }
    public function mGSvlz6oNpE(Ag7BVyy9gBS3K $N07Z2) : self
    {
        $this->Lkzkq = $N07Z2;
        return $this;
    }
    private function m9ExwDJkBij(bool $Qx1pT) : array
    {
        goto FklmH;
        nD7kY:
        $hs8qB['Queue'] = $this->EMD6s;
        goto t78ou;
        dUiBj:
        $hs8qB['Settings']['OutputGroups'][] = $this->Lkzkq->madF6UYZmWF();
        goto Tn1lK;
        TBb2A:
        $this->Lkzkq = null;
        goto YKmRM;
        D4FvG:
        H72Vd:
        goto M72Sq;
        aiSV2:
        unset($hs8qB['Settings']['OutputGroups']);
        goto n7r3R;
        ymIjZ:
        lgPt2:
        goto TBb2A;
        qBD34:
        $hs8qB['AccelerationSettings']['Mode'] = 'ENABLED';
        goto ymIjZ;
        UdUVu:
        $hs8qB['Role'] = $this->qQvyN;
        goto nD7kY;
        FklmH:
        $hs8qB = (require 'template.php');
        goto UdUVu;
        n7r3R:
        $Oty7C['Outputs'] = [];
        goto rVDAs;
        G5RYa:
        $Oty7C = $hs8qB['Settings']['OutputGroups'][0];
        goto aiSV2;
        rVDAs:
        foreach ($this->shjMi as $B7brD) {
            $Oty7C['Outputs'][] = $B7brD->mES18EGDU3q();
            lUdx8:
        }
        goto njpD1;
        YKmRM:
        $this->SPXQX = null;
        goto yfq_P;
        N6p3O:
        if (!$this->Lkzkq) {
            goto SsCj4;
        }
        goto dUiBj;
        M72Sq:
        $hs8qB['Settings']['Inputs'] = $this->SPXQX->m8m67iXZb9Q();
        goto G5RYa;
        hgh0M:
        return $hs8qB;
        goto m18bJ;
        njpD1:
        IBzim:
        goto zrdK3;
        J_y2w:
        $hs8qB['Settings']['OutputGroups'][] = $Oty7C;
        goto N6p3O;
        yfq_P:
        $this->shjMi = [];
        goto hgh0M;
        a12Di:
        if (!$Qx1pT) {
            goto lgPt2;
        }
        goto qBD34;
        zrdK3:
        $Oty7C['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->WL2xA;
        goto J_y2w;
        t78ou:
        if ($this->SPXQX) {
            goto H72Vd;
        }
        goto T5bsB;
        T5bsB:
        throw new \LogicException('You must provide a input file to use');
        goto D4FvG;
        Tn1lK:
        SsCj4:
        goto a12Di;
        m18bJ:
    }
    public function mXMigP37ith(bool $Qx1pT = false) : string
    {
        try {
            $bzyUS = $this->z32kc->createJob($this->m9ExwDJkBij($Qx1pT));
            return $bzyUS->get('Job')['Id'];
        } catch (AwsException $qeKgz) {
            Log::error('Error creating MediaConvert job: ' . $qeKgz->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $qeKgz);
        }
    }
}
