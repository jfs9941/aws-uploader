<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Service\A7wFfsLiK9DEe;
use Illuminate\Contracts\Filesystem\Filesystem;
final class K98g74EXAn8Vy
{
    public const vcy11 = 'v2/hls/';
    private $dRfny;
    private $YHwpp;
    public function __construct(A7wFfsLiK9DEe $mYBhd, Filesystem $ehLvI)
    {
        $this->dRfny = $mYBhd;
        $this->YHwpp = $ehLvI;
    }
    public function mFOkdY1WvwG($uA7Bz) : string
    {
        return $this->dRfny->mW4AkQf5njc(self::vcy11 . $uA7Bz->getAttribute('id') . '/');
    }
    public function mleGbwXoN7a($uA7Bz) : string
    {
        return $this->dRfny->mW4AkQf5njc(self::vcy11 . $uA7Bz->getAttribute('id') . '/thumbnail/');
    }
    public function m0fVFifEAAl($uA7Bz, $RAVTo = true) : string
    {
        goto zerU5;
        dxqPT:
        return $this->dRfny->mW4AkQf5njc(self::vcy11 . $uA7Bz->getAttribute('id') . '/' . $uA7Bz->getAttribute('id') . '.m3u8');
        goto akSEt;
        Yv3pk:
        return self::vcy11 . $uA7Bz->getAttribute('id') . '/' . $uA7Bz->getAttribute('id') . '.m3u8';
        goto Qdv3q;
        Qdv3q:
        ByWnO:
        goto dxqPT;
        zerU5:
        if ($RAVTo) {
            goto ByWnO;
        }
        goto Yv3pk;
        akSEt:
    }
    public function resolveThumbnail($uA7Bz) : string
    {
        goto MtRuP;
        MtRuP:
        $ShXx2 = $uA7Bz->getAttribute('id');
        goto o8qVr;
        o8qVr:
        $fXv_l = $this->YHwpp->files($this->mleGbwXoN7a($uA7Bz));
        goto dwCUD;
        dwCUD:
        return 1 == count($fXv_l) ? self::vcy11 . $ShXx2 . '/thumbnail/' . $ShXx2 . '.0000000.jpg' : self::vcy11 . $ShXx2 . '/thumbnail/' . $ShXx2 . '.0000001.jpg';
        goto xt9ih;
        xt9ih:
    }
    public function mImE1xfoJBw(string $lPyJj) : string
    {
        return $this->YHwpp->url($lPyJj);
    }
}
