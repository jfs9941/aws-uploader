<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class SlQNgBAeh4N74
{
    private $FH5aS;
    public function __construct(float $enHz_, int $TU63N, string $fGlKL)
    {
        goto cgMa2;
        cgMa2:
        $jeSXc = (int) $enHz_ / $TU63N;
        goto nTejq;
        x6cNH:
        $this->FH5aS = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $jeSXc]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $fGlKL]]];
        goto YgUT1;
        nTejq:
        $jeSXc = max($jeSXc, 1);
        goto x6cNH;
        YgUT1:
    }
    public function mrIKlngMt8o() : array
    {
        return $this->FH5aS;
    }
}
