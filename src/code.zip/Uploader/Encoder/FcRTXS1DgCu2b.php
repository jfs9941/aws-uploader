<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class FcRTXS1DgCu2b
{
    private $hrRlC;
    public function __construct(float $Vcmsu, int $I6tn3, string $MLP1z)
    {
        goto PbAGI;
        Nr2jg:
        $bC3BF = max($bC3BF, 1);
        goto EKZrB;
        EKZrB:
        $this->hrRlC = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $bC3BF]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $MLP1z]]];
        goto U5P7_;
        PbAGI:
        $bC3BF = (int) $Vcmsu / $I6tn3;
        goto Nr2jg;
        U5P7_:
    }
    public function mP749yL4tV1() : array
    {
        return $this->hrRlC;
    }
}
