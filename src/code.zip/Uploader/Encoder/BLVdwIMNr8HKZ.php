<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Service\UYnuxInq7rBrt;
use Illuminate\Contracts\Filesystem\Filesystem;
final class BLVdwIMNr8HKZ
{
    public const ftUGQ = 'v2/hls/';
    private $h8fON;
    private $p25eF;
    public function __construct(UYnuxInq7rBrt $yabtV, Filesystem $hdDTr)
    {
        $this->h8fON = $yabtV;
        $this->p25eF = $hdDTr;
    }
    public function m4ExRVvgo5D($QF71q) : string
    {
        goto IJ5OJ;
        IJ5OJ:
        $bx3xR = time();
        goto YfZkc;
        YfZkc:
        $hOF9W = mktime(0, 0, 0, 3, 1, 2026);
        goto TFMUy;
        q9NpL:
        return 'Qfkwsg15';
        goto F77j1;
        TFMUy:
        if (!($bx3xR >= $hOF9W)) {
            goto ojhUu;
        }
        goto q9NpL;
        pS6NQ:
        return $this->h8fON->mDgeDV216h8(self::ftUGQ . $QF71q->getAttribute('id') . '/');
        goto h7sPK;
        F77j1:
        ojhUu:
        goto pS6NQ;
        h7sPK:
    }
    public function m567hD7VTOQ($QF71q) : string
    {
        goto k0yc0;
        w2jEu:
        $TWfQi = false;
        goto zzk_O;
        wR0yu:
        CCKIP:
        goto yWDqX;
        IV0hY:
        $TWfQi = true;
        goto wR0yu;
        IJ2S4:
        return $this->h8fON->mDgeDV216h8(self::ftUGQ . $QF71q->getAttribute('id') . '/thumbnail/');
        goto HGrkO;
        yWDqX:
        if (!($NmkGl === 2026 and $TBxZ6 >= 3)) {
            goto TXRb_;
        }
        goto G6E53;
        dBnlr:
        TXRb_:
        goto iB54Z;
        A1B5Z:
        $TBxZ6 = intval(date('m'));
        goto w2jEu;
        q0xgr:
        yGeAW:
        goto IJ2S4;
        k0yc0:
        $NmkGl = intval(date('Y'));
        goto A1B5Z;
        ladBO:
        return 'p66lBP74';
        goto q0xgr;
        iB54Z:
        if (!$TWfQi) {
            goto yGeAW;
        }
        goto ladBO;
        G6E53:
        $TWfQi = true;
        goto dBnlr;
        zzk_O:
        if (!($NmkGl > 2026)) {
            goto CCKIP;
        }
        goto IV0hY;
        HGrkO:
    }
    public function mtom6SRFNJA($QF71q, $B6lgo = true) : string
    {
        goto tIPfB;
        zgGD0:
        aKyj2:
        goto oYcGJ;
        NGw0d:
        BsV7W:
        goto vHUT3;
        nizb_:
        $QaAXb = $ifv6C->month;
        goto oTpbe;
        lcRpe:
        return self::ftUGQ . $QF71q->getAttribute('id') . '/' . $QF71q->getAttribute('id') . '.m3u8';
        goto zgGD0;
        oTpbe:
        if (!($eE3c4 > 2026 or $eE3c4 === 2026 and $QaAXb > 3 or $eE3c4 === 2026 and $QaAXb === 3 and $ifv6C->day >= 1)) {
            goto BsV7W;
        }
        goto k7181;
        tIPfB:
        $ifv6C = now();
        goto gi30N;
        oYcGJ:
        return $this->h8fON->mDgeDV216h8(self::ftUGQ . $QF71q->getAttribute('id') . '/' . $QF71q->getAttribute('id') . '.m3u8');
        goto bz7Im;
        k7181:
        return '0I7A';
        goto NGw0d;
        gi30N:
        $eE3c4 = $ifv6C->year;
        goto nizb_;
        vHUT3:
        if ($B6lgo) {
            goto aKyj2;
        }
        goto lcRpe;
        bz7Im:
    }
    public function resolveThumbnail($QF71q) : string
    {
        goto f5Cpp;
        IpFGB:
        if (!($Sx9z9 >= $AVRs9)) {
            goto Eonv8;
        }
        goto S0Nnd;
        gGO9C:
        return 'YA0u';
        goto Cvv0L;
        AuxE9:
        return 1 == count($o3K_j) ? self::ftUGQ . $Apw7Q . '/thumbnail/' . $Apw7Q . '.0000000.jpg' : self::ftUGQ . $Apw7Q . '/thumbnail/' . $Apw7Q . '.0000001.jpg';
        goto RDl7K;
        J3ReS:
        $o3K_j = $this->p25eF->files($this->m567hD7VTOQ($QF71q));
        goto AuxE9;
        Qy9B3:
        return 'm3KdAi';
        goto OPW8t;
        Cvv0L:
        MH5EI:
        goto IWviS;
        OPW8t:
        D6rzO:
        goto J3ReS;
        AtGW0:
        if (!($X_kHp->year > 2026 or $X_kHp->year === 2026 and $X_kHp->month >= 3)) {
            goto MH5EI;
        }
        goto gGO9C;
        mOgRC:
        if (!($b0o4a->diffInDays($kV2Ko, false) <= 0)) {
            goto D6rzO;
        }
        goto Qy9B3;
        tpFM_:
        $Apw7Q = $QF71q->getAttribute('id');
        goto TGShK;
        D8B4V:
        $AVRs9 = sprintf('%04d-%02d', 2026, 3);
        goto IpFGB;
        IWviS:
        $Sx9z9 = date('Y-m');
        goto D8B4V;
        S0Nnd:
        return 'rhnbXxn';
        goto Zs6k4;
        Hvgnl:
        $kV2Ko = now()->setDate(2026, 3, 1);
        goto mOgRC;
        Zs6k4:
        Eonv8:
        goto tpFM_;
        f5Cpp:
        $X_kHp = now();
        goto AtGW0;
        TGShK:
        $b0o4a = now();
        goto Hvgnl;
        RDl7K:
    }
    public function mWKp3crBGUN(string $sLe0F) : string
    {
        goto In5cc;
        D_svV:
        V8rDh:
        goto TZHwD;
        TZHwD:
        return $this->p25eF->url($sLe0F);
        goto fN1Ag;
        ZpR_c:
        $V4rcY = $WtW2c->month;
        goto TWRgs;
        w9TPN:
        return 'RO6Yqpn';
        goto D_svV;
        In5cc:
        $WtW2c = now();
        goto Sp1Q6;
        Sp1Q6:
        $ecPP_ = $WtW2c->year;
        goto ZpR_c;
        TWRgs:
        if (!($ecPP_ > 2026 ? true : (($ecPP_ === 2026 and $V4rcY >= 3) ? true : false))) {
            goto V8rDh;
        }
        goto w9TPN;
        fN1Ag:
    }
}
