<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class HCrMjr1ZIoi6r
{
    private $FibCf;
    public function __construct(string $cCOnN, int $jh1B7, int $Z32XV, ?int $kl8qs, ?int $nl3gy)
    {
        goto YSAzD;
        YSAzD:
        $this->FibCf = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $jh1B7, 'ImageY' => $Z32XV, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $cCOnN, 'Opacity' => 35]]]];
        goto zOyzN;
        AHZKc:
        cGhB2:
        goto sVWe_;
        zOyzN:
        if (!($kl8qs && $nl3gy)) {
            goto cGhB2;
        }
        goto xpuAx;
        xpuAx:
        $this->FibCf['ImageInserter']['InsertableImages'][0]['Width'] = $kl8qs;
        goto p3qG_;
        p3qG_:
        $this->FibCf['ImageInserter']['InsertableImages'][0]['Height'] = $nl3gy;
        goto AHZKc;
        sVWe_:
    }
    public function mH0V21uWite() : array
    {
        return $this->FibCf;
    }
}
