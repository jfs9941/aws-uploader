<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Service\KiBRYQgrRVRtv;
use Illuminate\Contracts\Filesystem\Filesystem;
final class FSb1vbQf2TVPX
{
    public const EdS_E = 'v2/hls/';
    private $yCQN5;
    private $QxLu3;
    public function __construct(KiBRYQgrRVRtv $uLczT, Filesystem $bjIIR)
    {
        $this->yCQN5 = $uLczT;
        $this->QxLu3 = $bjIIR;
    }
    public function mu3Y9htrOBq($JhYqb) : string
    {
        return $this->yCQN5->m3Csu51ee5L(self::EdS_E . $JhYqb->getAttribute('id') . '/');
    }
    public function mIAn1jApgCC($JhYqb) : string
    {
        return $this->yCQN5->m3Csu51ee5L(self::EdS_E . $JhYqb->getAttribute('id') . '/thumbnail/');
    }
    public function mdLBsEaX2zO($JhYqb, $Zn3Fr = true) : string
    {
        goto YQKfa;
        rHnRC:
        return $this->yCQN5->m3Csu51ee5L(self::EdS_E . $JhYqb->getAttribute('id') . '/' . $JhYqb->getAttribute('id') . '.m3u8');
        goto W1hSE;
        YQKfa:
        if ($Zn3Fr) {
            goto eqVIb;
        }
        goto Hi3r0;
        am_L6:
        eqVIb:
        goto rHnRC;
        Hi3r0:
        return self::EdS_E . $JhYqb->getAttribute('id') . '/' . $JhYqb->getAttribute('id') . '.m3u8';
        goto am_L6;
        W1hSE:
    }
    public function resolveThumbnail($JhYqb) : string
    {
        goto GYTps;
        sT6ha:
        return 1 == count($J4EAq) ? self::EdS_E . $qMhfW . '/thumbnail/' . $qMhfW . '.0000000.jpg' : self::EdS_E . $qMhfW . '/thumbnail/' . $qMhfW . '.0000001.jpg';
        goto uSwW8;
        GYTps:
        $qMhfW = $JhYqb->getAttribute('id');
        goto U0W2N;
        U0W2N:
        $J4EAq = $this->QxLu3->files($this->mIAn1jApgCC($JhYqb));
        goto sT6ha;
        uSwW8:
    }
    public function mSp3UlH11rx(string $b0LKC) : string
    {
        return $this->QxLu3->url($b0LKC);
    }
}
