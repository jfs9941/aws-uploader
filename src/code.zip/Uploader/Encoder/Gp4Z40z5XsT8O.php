<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Service\R9h2iDidHZRXb;
final class Gp4Z40z5XsT8O
{
    public const zj1DL = 'v2/hls/';
    private $Nij9l;
    private $Vhcrn;
    public function __construct(R9h2iDidHZRXb $DngCm, Filesystem $Klx1U)
    {
        $this->Nij9l = $DngCm;
        $this->Vhcrn = $Klx1U;
    }
    public function mUFiV9Xi2ul($wmU7r) : string
    {
        return $this->Nij9l->m1SSZoFHCOG(self::zj1DL . $wmU7r->getAttribute('id') . '/');
    }
    public function muOJMFoqujS($wmU7r) : string
    {
        return $this->Nij9l->m1SSZoFHCOG(self::zj1DL . $wmU7r->getAttribute('id') . '/thumbnail/');
    }
    public function mFMgCe5NGMm($wmU7r, $UVP1R = true) : string
    {
        goto u_nhD;
        u_nhD:
        if ($UVP1R) {
            goto iEMV1;
        }
        goto E4NeI;
        dMYEJ:
        iEMV1:
        goto Fl7Wd;
        Fl7Wd:
        return $this->Nij9l->m1SSZoFHCOG(self::zj1DL . $wmU7r->getAttribute('id') . '/' . $wmU7r->getAttribute('id') . '.m3u8');
        goto d91aB;
        E4NeI:
        return self::zj1DL . $wmU7r->getAttribute('id') . '/' . $wmU7r->getAttribute('id') . '.m3u8';
        goto dMYEJ;
        d91aB:
    }
    public function resolveThumbnail($wmU7r) : string
    {
        goto wIQTQ;
        xSFd1:
        return 1 == count($TDvDf) ? self::zj1DL . $mfjeD . '/thumbnail/' . $mfjeD . '.0000000.jpg' : self::zj1DL . $mfjeD . '/thumbnail/' . $mfjeD . '.0000001.jpg';
        goto gGOrF;
        wIQTQ:
        $mfjeD = $wmU7r->getAttribute('id');
        goto xHxSE;
        xHxSE:
        $TDvDf = $this->Vhcrn->files($this->muOJMFoqujS($wmU7r));
        goto xSFd1;
        gGOrF:
    }
    public function mN6bEswXBoB(string $J9IgU) : string
    {
        return $this->Vhcrn->url($J9IgU);
    }
}
