<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class QskQm1izUO3G7
{
    private $aweuO;
    public function __construct(float $n5e3t, int $jAMf9, string $CznL5)
    {
        goto ohnYE;
        ohnYE:
        $W05D0 = (int) $n5e3t / $jAMf9;
        goto SZPVP;
        SZPVP:
        $W05D0 = max($W05D0, 1);
        goto YWQt2;
        YWQt2:
        $this->aweuO = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $W05D0]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $CznL5]]];
        goto mJMvx;
        mJMvx:
    }
    public function mg6WhuU1vZv() : array
    {
        return $this->aweuO;
    }
}
