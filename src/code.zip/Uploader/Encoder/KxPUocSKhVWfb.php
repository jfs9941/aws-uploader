<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class KxPUocSKhVWfb
{
    private $g97cm;
    public function __construct(float $E8hj0, int $du_jZ, string $eQ1QS)
    {
        goto j3vA8;
        ZciCn:
        $RhYNj = max($RhYNj, 1);
        goto g18m4;
        g18m4:
        $this->g97cm = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $RhYNj]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $eQ1QS]]];
        goto zUl1Q;
        j3vA8:
        $RhYNj = (int) $E8hj0 / $du_jZ;
        goto ZciCn;
        zUl1Q:
    }
    public function mqFFnuR8hEN() : array
    {
        return $this->g97cm;
    }
}
