<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Service\L3oEPipUZv9oB;
final class Rwcm9mhsmq7Wv
{
    public const Ygdn9 = 'v2/hls/';
    private $e8_T8;
    private $ifs25;
    public function __construct(L3oEPipUZv9oB $OZKMn, Filesystem $PQlIa)
    {
        $this->e8_T8 = $OZKMn;
        $this->ifs25 = $PQlIa;
    }
    public function m7gkGAfBmh9($vtvs_) : string
    {
        return $this->e8_T8->m6AMr5gMVyk(self::Ygdn9 . $vtvs_->getAttribute('id') . '/');
    }
    public function mr6RT9Mznvo($vtvs_) : string
    {
        return $this->e8_T8->m6AMr5gMVyk(self::Ygdn9 . $vtvs_->getAttribute('id') . '/thumbnail/');
    }
    public function mylsLdqjPZD($vtvs_, $X0Q0M = true) : string
    {
        goto WGDBo;
        WGDBo:
        if ($X0Q0M) {
            goto BRMlT;
        }
        goto zg4oS;
        tMnJ6:
        return $this->e8_T8->m6AMr5gMVyk(self::Ygdn9 . $vtvs_->getAttribute('id') . '/' . $vtvs_->getAttribute('id') . '.m3u8');
        goto r6Sy_;
        zg4oS:
        return self::Ygdn9 . $vtvs_->getAttribute('id') . '/' . $vtvs_->getAttribute('id') . '.m3u8';
        goto mEmKX;
        mEmKX:
        BRMlT:
        goto tMnJ6;
        r6Sy_:
    }
    public function resolveThumbnail($vtvs_) : string
    {
        goto PyjwP;
        PyjwP:
        $PV4mw = $vtvs_->getAttribute('id');
        goto XKawl;
        CfUnq:
        return 1 == count($TgJkF) ? self::Ygdn9 . $PV4mw . '/thumbnail/' . $PV4mw . '.0000000.jpg' : self::Ygdn9 . $PV4mw . '/thumbnail/' . $PV4mw . '.0000001.jpg';
        goto woKpy;
        XKawl:
        $TgJkF = $this->ifs25->files($this->mr6RT9Mznvo($vtvs_));
        goto CfUnq;
        woKpy:
    }
    public function mzSvIjUDClD(string $sEueW) : string
    {
        return $this->ifs25->url($sEueW);
    }
}
