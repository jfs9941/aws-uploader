<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class MmrtqP9zAx1EE
{
    private $pIIgF;
    public function __construct(float $F7YHz, int $VSkw1, string $WF6cF)
    {
        goto qYsz0;
        g40uE:
        $this->pIIgF = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $Tt0L0]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $WF6cF]]];
        goto ytPko;
        jtJKd:
        $Tt0L0 = max($Tt0L0, 1);
        goto g40uE;
        qYsz0:
        $Tt0L0 = (int) $F7YHz / $VSkw1;
        goto jtJKd;
        ytPko:
    }
    public function mIf99mgPo8M() : array
    {
        return $this->pIIgF;
    }
}
