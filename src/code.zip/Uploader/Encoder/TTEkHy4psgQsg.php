<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class TTEkHy4psgQsg
{
    private $nuqvM;
    public function __construct(float $TTDRv, int $KyvaQ, string $h6t5D)
    {
        goto HMU2w;
        jrrv6:
        $c418p = max($c418p, 1);
        goto AzfMr;
        AzfMr:
        $this->nuqvM = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $c418p]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $h6t5D]]];
        goto l6HtH;
        HMU2w:
        $c418p = (int) $TTDRv / $KyvaQ;
        goto jrrv6;
        l6HtH:
    }
    public function m7CWtkKXz7u() : array
    {
        return $this->nuqvM;
    }
}
