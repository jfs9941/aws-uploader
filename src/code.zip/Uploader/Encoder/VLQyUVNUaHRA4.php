<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class VLQyUVNUaHRA4
{
    private $eMRdR;
    public function __construct(string $Mwx1F, ?int $kl8qs, ?int $nl3gy, float $HMMkb)
    {
        goto O4W8P;
        Z1HHr:
        wCCd8:
        goto fUlpH;
        oq9Pp:
        $RLZ39 = $this->mmuHMJ9Q4gq($kl8qs, $nl3gy, $HMMkb);
        goto jAKxt;
        AFmcq:
        $this->eMRdR = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $RLZ39, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $Mwx1F];
        goto CU3m9;
        O4W8P:
        $RLZ39 = 15000000;
        goto VXoaV;
        Aml7r:
        $this->eMRdR['VideoDescription']['Height'] = $nl3gy;
        goto Z1HHr;
        yA7XU:
        $this->eMRdR['VideoDescription']['Width'] = $kl8qs;
        goto Aml7r;
        VXoaV:
        if (!($kl8qs && $nl3gy)) {
            goto kqaeb;
        }
        goto oq9Pp;
        jAKxt:
        kqaeb:
        goto AFmcq;
        CU3m9:
        if (!($kl8qs && $nl3gy)) {
            goto wCCd8;
        }
        goto yA7XU;
        fUlpH:
    }
    public function mZiMka8JQnR(HCrMjr1ZIoi6r $t51Nx) : self
    {
        $this->eMRdR['VideoDescription']['VideoPreprocessors'] = $t51Nx->mH0V21uWite();
        return $this;
    }
    public function mCO3NBIInmc() : array
    {
        return $this->eMRdR;
    }
    private function mmuHMJ9Q4gq(int $kl8qs, int $nl3gy, float $m_PM0, string $DipP7 = 'medium', string $PefRE = 'h264', string $N0pEn = 'good') : ?int
    {
        goto x9ACk;
        WOm59:
        if ($GPGKv <= 2560 * 1440) {
            goto xKuTO;
        }
        goto sdQRZ;
        FCrYh:
        S427y:
        goto ZZfud;
        sdQRZ:
        if ($GPGKv <= 3840 * 2160) {
            goto X25vR;
        }
        goto mBWh0;
        nFoOI:
        A8qCW:
        goto ZxCYA;
        CXeFQ:
        bZ_bP:
        goto g0XKl;
        mBWh0:
        $oL47l = 30;
        goto Ks69G;
        JuSnx:
        $osJKT = max(0.5, $osJKT);
        goto Q_ku7;
        aN9y8:
        goto zjXHK;
        goto FCrYh;
        zd_HA:
        $oL47l = 1.5;
        goto DHRfO;
        LfwND:
        goto zjXHK;
        goto qKPfy;
        DHRfO:
        goto zjXHK;
        goto CXeFQ;
        hIH6_:
        if ($GPGKv <= 1920 * 1080) {
            goto S427y;
        }
        goto WOm59;
        JmhiT:
        zpjJc:
        goto wVSAi;
        MhXnU:
        if ($GPGKv <= 640 * 480) {
            goto LDnv2;
        }
        goto pWkII;
        xb4Xj:
        switch (strtolower($DipP7)) {
            case 'low':
                $osJKT *= 0.7;
                goto zpjJc;
            case 'high':
                $osJKT *= 1.3;
                goto zpjJc;
            case 'veryhigh':
                $osJKT *= 1.6;
                goto zpjJc;
        }
        goto HJCLY;
        gr46_:
        $oL47l = 12;
        goto ssFtf;
        dgAAr:
        gswhe:
        goto OhSTc;
        ssFtf:
        goto zjXHK;
        goto Pybr5;
        wVSAi:
        if (!('h265' === strtolower($PefRE) || 'hevc' === strtolower($PefRE) || 'vp9' === strtolower($PefRE))) {
            goto A8qCW;
        }
        goto fAmes;
        g0XKl:
        $oL47l = 3;
        goto aN9y8;
        qKPfy:
        xKuTO:
        goto gr46_;
        JyytB:
        zjXHK:
        goto GGJHh;
        Ks69G:
        goto zjXHK;
        goto Nw0lS;
        GGJHh:
        $osJKT = $oL47l * ($m_PM0 / 30);
        goto xb4Xj;
        pWkII:
        if ($GPGKv <= 1280 * 720) {
            goto bZ_bP;
        }
        goto hIH6_;
        ZZfud:
        $oL47l = 7;
        goto LfwND;
        Pybr5:
        X25vR:
        goto ecaj5;
        x9ACk:
        $GPGKv = $kl8qs * $nl3gy;
        goto MhXnU;
        HJCLY:
        FrmE8:
        goto JmhiT;
        fAmes:
        $osJKT *= 0.65;
        goto nFoOI;
        Nw0lS:
        LDnv2:
        goto zd_HA;
        ZxCYA:
        switch (strtolower($N0pEn)) {
            case 'low':
                $osJKT *= 0.8;
                goto wg3iK;
            case 'high':
                $osJKT *= 1.2;
                goto wg3iK;
        }
        goto dgAAr;
        Q_ku7:
        return (int) ($osJKT * 1000 * 1000);
        goto qKvud;
        OhSTc:
        wg3iK:
        goto JuSnx;
        ecaj5:
        $oL47l = 20;
        goto JyytB;
        qKvud:
    }
}
