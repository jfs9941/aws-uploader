<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\ZV4T54pWWCYdf;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Jfs\Uploader\Exception\GRAfJLmbKXpoS;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Exception\HaB2yhTzru90X;
use Jfs\Uploader\Service\W99ztYaFerRwn;
use Illuminate\Contracts\Filesystem\Filesystem;
final class N2tPpcJn2iYGH implements UploadServiceInterface
{
    private $UgC0Q;
    private $h0iwI;
    private $o9xvH;
    private $WcGqk;
    public function __construct(W99ztYaFerRwn $vysjL, Filesystem $jxMWP, Filesystem $ft7kk, string $MsVSa)
    {
        goto zR2HQ;
        tBTK8:
        $this->WcGqk = $MsVSa;
        goto FEfcb;
        zR2HQ:
        $this->UgC0Q = $vysjL;
        goto OgvOS;
        OgvOS:
        $this->h0iwI = $jxMWP;
        goto CvlnI;
        CvlnI:
        $this->o9xvH = $ft7kk;
        goto tBTK8;
        FEfcb:
    }
    public function storeSingleFile(SingleUploadInterface $ExGW4) : array
    {
        goto ZrOWR;
        CV7ln:
        throw new \LogicException('File upload failed, check permissions');
        goto TMJoE;
        PRMw3:
        return $bwI0g->getView();
        goto rSpBR;
        NPbj3:
        nBcuH:
        goto PRMw3;
        ZrOWR:
        $bwI0g = $this->UgC0Q->mAhVG2DCuhs($ExGW4);
        goto m7cDB;
        qmO0h:
        if (false !== $fQjwQ && $bwI0g instanceof Zv4WZkC8rwgvt) {
            goto hJ73G;
        }
        goto CV7ln;
        a0NJ2:
        $bwI0g->mRU2TqSePcC(WSEQ88VDOa3X0::UPLOADED);
        goto NPbj3;
        TMJoE:
        goto nBcuH;
        goto Ux0vu;
        Ux0vu:
        hJ73G:
        goto a0NJ2;
        m7cDB:
        $fQjwQ = $this->o9xvH->putFileAs(dirname($bwI0g->getLocation()), $ExGW4->getFile(), $bwI0g->getFilename() . '.' . $bwI0g->getExtension(), ['visibility' => 'public']);
        goto qmO0h;
        rSpBR:
    }
    public function storePreSignedFile(array $K6POV)
    {
        goto W2Z6l;
        W2Z6l:
        $bwI0g = $this->UgC0Q->mAhVG2DCuhs($K6POV);
        goto NJryy;
        VytC_:
        $EZ04_->m9GWlIIZuqp();
        goto nSojN;
        WTcX8:
        $EZ04_->mTJZbk7XwXd($K6POV['mime'], $K6POV['file_size'], $K6POV['chunk_size'], $K6POV['checksums'], $K6POV['user_id'], $K6POV['driver']);
        goto VytC_;
        NJryy:
        $EZ04_ = ZV4T54pWWCYdf::mTT9iwJ2I5B($bwI0g, $this->h0iwI, $this->o9xvH, $this->WcGqk, true);
        goto WTcX8;
        nSojN:
        return ['filename' => $EZ04_->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $EZ04_->m1mdlzVkhvL()];
        goto GlsVp;
        GlsVp:
    }
    public function updatePreSignedFile(string $Q4iyS, int $gYfd5)
    {
        goto fWBNu;
        gxUYA:
        hooSh:
        goto zmtLq;
        fWBNu:
        $EZ04_ = ZV4T54pWWCYdf::mDxA2W83Gl8($Q4iyS, $this->h0iwI, $this->o9xvH, $this->WcGqk);
        goto RAvLp;
        RAvLp:
        switch ($gYfd5) {
            case WSEQ88VDOa3X0::UPLOADED:
                $EZ04_->m9vqCYmtYSU();
                goto jtz0d;
            case WSEQ88VDOa3X0::PROCESSING:
                $EZ04_->mxcejM77ulZ();
                goto jtz0d;
            case WSEQ88VDOa3X0::FINISHED:
                $EZ04_->mFR82ZHgRp6();
                goto jtz0d;
            case WSEQ88VDOa3X0::ABORTED:
                $EZ04_->mCchs2jmG1F();
                goto jtz0d;
        }
        goto gxUYA;
        zmtLq:
        jtz0d:
        goto H89SD;
        H89SD:
    }
    public function completePreSignedFile(string $Q4iyS, array $H1_VI)
    {
        goto KIWf6;
        OvIgZ:
        $EZ04_->mSViQFIwKkL()->muWf58XVBlf($H1_VI);
        goto ujqQS;
        KIWf6:
        $EZ04_ = ZV4T54pWWCYdf::mDxA2W83Gl8($Q4iyS, $this->h0iwI, $this->o9xvH, $this->WcGqk);
        goto OvIgZ;
        yao_V:
        return ['path' => $EZ04_->getFile()->getView()['path'], 'thumbnail' => $EZ04_->getFile()->zeJHK, 'id' => $Q4iyS];
        goto ZL91i;
        ujqQS:
        $EZ04_->m9vqCYmtYSU();
        goto yao_V;
        ZL91i:
    }
    public function updateFile(string $Q4iyS, int $gYfd5) : A7djqU0sacoRX
    {
        goto KNl5k;
        KNl5k:
        $bwI0g = $this->UgC0Q->mhd5AAeH9hj($Q4iyS);
        goto n5GYV;
        n5GYV:
        $bwI0g->mRU2TqSePcC($gYfd5);
        goto tVMT8;
        tVMT8:
        return $bwI0g;
        goto y2CIn;
        y2CIn:
    }
}
