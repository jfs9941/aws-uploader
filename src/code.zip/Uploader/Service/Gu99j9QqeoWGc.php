<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\PZ7iLyA8MUs3A;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Core\IFOKBvW1HTPmz;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
final class Gu99j9QqeoWGc implements PZ7iLyA8MUs3A
{
    private $Xh7Fy;
    private $V30Gl;
    public $TYjL9;
    private $eVPKR;
    private $Z1KXe;
    private $qeI_k;
    public function __construct($GLFr9, $Vdvce, $t5CX6, $AOHix, $wIJOS, $ShtWH)
    {
        goto WIn1y;
        CRdtj:
        $this->Z1KXe = $wIJOS;
        goto eG1mV;
        WIn1y:
        $this->qeI_k = $ShtWH;
        goto Cju8y;
        zJUNs:
        $this->TYjL9 = $t5CX6;
        goto zLlps;
        oAxgq:
        $this->V30Gl = $Vdvce;
        goto zJUNs;
        Cju8y:
        $this->Xh7Fy = $GLFr9;
        goto oAxgq;
        zLlps:
        $this->eVPKR = $AOHix;
        goto CRdtj;
        eG1mV:
    }
    public function resolvePath($jKCuO, $EWvJO = KkaUVP3OQvOtp::S3) : string
    {
        goto DvwX_;
        qNFFS:
        A_Yqk:
        goto jL3Vr;
        f69Cm:
        if (!$this->Xh7Fy) {
            goto X0gHC;
        }
        goto P270d;
        fkiz3:
        return config('upload.home') . '/' . $jKCuO;
        goto qNFFS;
        xgX9n:
        sHwHu:
        goto QKSPX;
        jL3Vr:
        if (!(!empty($this->eVPKR) && !empty($this->Z1KXe))) {
            goto ICnAd;
        }
        goto EAALm;
        q2LQh:
        ICnAd:
        goto f69Cm;
        UT_K5:
        X0gHC:
        goto KDxkA;
        P270d:
        return trim($this->TYjL9, '/') . '/' . $jKCuO;
        goto UT_K5;
        KDxkA:
        return trim($this->V30Gl, '/') . '/' . $jKCuO;
        goto EiTgr;
        KLOwQ:
        $jKCuO = $jKCuO->getAttribute('filename');
        goto xgX9n;
        QKSPX:
        if (!($EWvJO === KkaUVP3OQvOtp::LOCAL)) {
            goto A_Yqk;
        }
        goto fkiz3;
        DvwX_:
        if (!$jKCuO instanceof F43pNWIrUhz3z) {
            goto sHwHu;
        }
        goto KLOwQ;
        EAALm:
        return $this->mejuw7DFxiY($jKCuO);
        goto q2LQh;
        EiTgr:
    }
    public function resolveThumbnail(F43pNWIrUhz3z $jKCuO) : string
    {
        goto Zy3Gf;
        XS1Wv:
        if (!$UT4QS) {
            goto ko4az;
        }
        goto SzjUl;
        VNuc7:
        BsZ_E:
        goto gl3Zb;
        AFGmC:
        return asset('/img/pdf-preview.svg');
        goto EyWn5;
        NPItU:
        kw2dI:
        goto kGKY_;
        kGKY_:
        f34xb:
        goto qzCVA;
        gl3Zb:
        if (!$jKCuO instanceof IFOKBvW1HTPmz) {
            goto kWQ0x;
        }
        goto AFGmC;
        b_3av:
        ko4az:
        goto Z16cM;
        EyWn5:
        kWQ0x:
        goto eE5_e;
        nahOL:
        return $this->resolvePath($jKCuO, $jKCuO->getAttribute('driver'));
        goto VNuc7;
        Zy3Gf:
        $UT4QS = $jKCuO->getAttribute('thumbnail');
        goto XS1Wv;
        etdwc:
        return $this->resolvePath($Ocp5q, $Ocp5q->getAttribute('driver'));
        goto NPItU;
        eE5_e:
        return '';
        goto BScgT;
        XAjEp:
        $Ocp5q = IQJN6V0t7DC7c::find($jKCuO->getAttribute('thumbnail_id'));
        goto nyb4A;
        nyb4A:
        if (!$Ocp5q) {
            goto kw2dI;
        }
        goto etdwc;
        SzjUl:
        return $this->url($UT4QS, $jKCuO->getAttribute('driver'));
        goto b_3av;
        Z16cM:
        if (!$jKCuO->getAttribute('thumbnail_id')) {
            goto f34xb;
        }
        goto XAjEp;
        qzCVA:
        if (!$jKCuO instanceof IQJN6V0t7DC7c) {
            goto BsZ_E;
        }
        goto nahOL;
        BScgT:
    }
    private function url($iVcpi, $EWvJO)
    {
        goto pRnne;
        op_CX:
        return config('upload.home') . '/' . $iVcpi;
        goto Q87jq;
        AKQUu:
        return $this->resolvePath($iVcpi);
        goto afl5u;
        Q87jq:
        pCeVz:
        goto AKQUu;
        pRnne:
        if (!($EWvJO == KkaUVP3OQvOtp::LOCAL)) {
            goto pCeVz;
        }
        goto op_CX;
        afl5u:
    }
    private function mejuw7DFxiY($iVcpi)
    {
        goto TXbFB;
        vzY9J:
        jDPAt:
        goto Ey5tP;
        m0Fd0:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto vzY9J;
        Ey5tP:
        $itJ4p = now()->addMinutes(60)->timestamp;
        goto AS0Mn;
        AS0Mn:
        $gWMrZ = new UrlSigner($this->eVPKR, $this->qeI_k->path($this->Z1KXe));
        goto AaIaG;
        TXbFB:
        if (!(strpos($iVcpi, 'https://') === 0)) {
            goto apCBV;
        }
        goto Rr21Y;
        Rr21Y:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto tu2Aa;
        AaIaG:
        return $gWMrZ->getSignedUrl($this->TYjL9 . '/' . $iVcpi, $itJ4p);
        goto Kx3MX;
        tu2Aa:
        apCBV:
        goto exZmL;
        exZmL:
        if (!(strpos($iVcpi, 'm3u8') !== false)) {
            goto jDPAt;
        }
        goto m0Fd0;
        Kx3MX:
    }
    public function resolvePathForHlsVideo(J7sRaWo8um3yO $lamFK, $v_5PG = false) : string
    {
        goto tA15R;
        tA15R:
        if ($lamFK->getAttribute('hls_path')) {
            goto mwZ4_;
        }
        goto lmAM7;
        lmAM7:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto p2ImD;
        p2ImD:
        mwZ4_:
        goto OnTs6;
        OnTs6:
        return $this->TYjL9 . '/' . $lamFK->getAttribute('hls_path');
        goto t0flE;
        t0flE:
    }
    public function resolvePathForHlsVideos()
    {
        goto nvKAG;
        uBUDE:
        $G2CYV = json_encode(['Statement' => [['Resource' => sprintf('%s*', $CrItu), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $itJ4p]]]]]);
        goto mQsZg;
        kJIiG:
        return [$T6zNO, $itJ4p];
        goto il8YI;
        nvKAG:
        $itJ4p = now()->addDays(3)->timestamp;
        goto A1EOD;
        mQsZg:
        $KKpiF = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto D1XjO;
        A1EOD:
        $CrItu = $this->TYjL9 . '/v2/hls/';
        goto uBUDE;
        D1XjO:
        $T6zNO = $KKpiF->getSignedCookie(['key_pair_id' => $this->eVPKR, 'private_key' => $this->qeI_k->path($this->Z1KXe), 'policy' => $G2CYV]);
        goto kJIiG;
        il8YI:
    }
}
