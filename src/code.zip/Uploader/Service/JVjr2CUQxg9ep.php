<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Core\Observer\JRPGqsDbpQxdQ;
use Jfs\Uploader\Core\Observer\XpPxaggO8iQsi;
use Jfs\Uploader\Core\CuvWXGDQ9mxt7;
use Jfs\Uploader\Core\A4nixFDruB7ul;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Exception\Eau0ZADkUwi6b;
use Jfs\Uploader\Service\FileResolver\G52L06e5mJkBd;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class JVjr2CUQxg9ep
{
    private $jrCkw;
    private $uTYgy;
    private $tcoQz;
    public function __construct($ZYNAm, $kVG4M, $v70jj)
    {
        goto QHPA8;
        wNjJS:
        $this->tcoQz = $v70jj;
        goto j0xM8;
        QHPA8:
        $this->jrCkw = $ZYNAm;
        goto BREqe;
        BREqe:
        $this->uTYgy = $kVG4M;
        goto wNjJS;
        j0xM8:
    }
    public function mV2eo5mkU4s($IkykI)
    {
        goto UVp7d;
        OgrpQ:
        v5T2X:
        goto JrnAu;
        sKyXf:
        return $this->mbIuDkUbaPc($FKrfy->extension(), LrHrisEWQ9E5o::S3, null, $IkykI->options());
        goto OgrpQ;
        aS9Gn:
        $FKrfy = $IkykI->getFile();
        goto sKyXf;
        UVp7d:
        if (!$IkykI instanceof SingleUploadInterface) {
            goto v5T2X;
        }
        goto aS9Gn;
        JrnAu:
        return $this->mbIuDkUbaPc($IkykI['file_extension'], 's3' === $IkykI['driver'] ? LrHrisEWQ9E5o::S3 : LrHrisEWQ9E5o::LOCAL);
        goto pk0r8;
        pk0r8:
    }
    public function mJH7h8hd8oT(string $B5uQ4)
    {
        goto SX5D4;
        o13YS:
        return $clm2Y;
        goto Xt5KC;
        M3Pk9:
        $clm2Y->setRawAttributes($Eawqf->getAttributes());
        goto o13YS;
        SX5D4:
        $Eawqf = config('upload.attachment_model')::findOrFail($B5uQ4);
        goto PRNvy;
        aTTOc:
        $clm2Y->exists = true;
        goto M3Pk9;
        PRNvy:
        $clm2Y = $this->mbIuDkUbaPc($Eawqf->getAttribute('type'), $Eawqf->getAttribute('driver'), $Eawqf->getAttribute('id'));
        goto aTTOc;
        Xt5KC:
    }
    public function mv7PwR2Y278(string $vDPEq) : B7NusEU08Li4E
    {
        goto O1vLj;
        E5Q1D:
        if (!$H8A56) {
            goto Sb6OP;
        }
        goto JwOJ7;
        mLwtE:
        $H8A56 = json_decode($q22lO, true);
        goto E5Q1D;
        Ucgiv:
        $q22lO = $this->tcoQz->get($vDPEq);
        goto jBdkL;
        O1vLj:
        $q22lO = $this->uTYgy->get($vDPEq);
        goto dkkfy;
        nfrOe:
        throw new LFhGkQpjCxWvG('metadata file not found');
        goto ck0YQ;
        dkkfy:
        if ($q22lO) {
            goto ZYXny;
        }
        goto Ucgiv;
        jBdkL:
        ZYXny:
        goto mLwtE;
        Uc8hK:
        return $this->mbIuDkUbaPc($h3OeV->m6941, $h3OeV->m6JaR9gO77g(), $h3OeV->filename);
        goto T_NFa;
        T_NFa:
        Sb6OP:
        goto nfrOe;
        JwOJ7:
        $h3OeV = A4nixFDruB7ul::m9frp5pXoGL($H8A56);
        goto Uc8hK;
        ck0YQ:
    }
    private function mbIuDkUbaPc(string $nvo1_, $lQ5hF, ?string $B5uQ4 = null, array $fxDHl = [])
    {
        goto TpV7f;
        NtL1P:
        LzKJw:
        goto NW6DC;
        TpV7f:
        $B5uQ4 = $B5uQ4 ?? Uuid::uuid4()->getHex()->toString();
        goto GmwQS;
        mP0MF:
        $nciUN->mme8vGqglZH(new JRPGqsDbpQxdQ($nciUN));
        goto a2r3s;
        RgPhe:
        foreach ($this->jrCkw as $DOzS1) {
            goto c9Uzk;
            z7pQD:
            bMrJH:
            goto A4sXu;
            c9Uzk:
            if (!$DOzS1->mxxEwscu3Zo($nciUN)) {
                goto eHMog;
            }
            goto u6wQ1;
            u6wQ1:
            return $nciUN->initLocation($DOzS1->m7DsbapOQgU($nciUN));
            goto FX73i;
            FX73i:
            eHMog:
            goto z7pQD;
            A4sXu:
        }
        goto zo9P2;
        qq5sO:
        $nciUN = $nciUN->mSWw0aisRSd($lQ5hF);
        goto mP0MF;
        GmwQS:
        switch ($nvo1_) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $nciUN = U0IzvN2kaLZHI::createFromScratch($B5uQ4, $nvo1_);
                goto GaCSa;
            case 'mp4':
            case 'mov':
                $nciUN = CpeNYzI7e1ALA::createFromScratch($B5uQ4, $nvo1_);
                goto GaCSa;
            case 'pdf':
                $nciUN = CuvWXGDQ9mxt7::createFromScratch($B5uQ4, $nvo1_);
                goto GaCSa;
            default:
                throw new Eau0ZADkUwi6b("not support file type {$nvo1_}");
        }
        goto NtL1P;
        zo9P2:
        trBp4:
        goto I9FTe;
        I9FTe:
        throw new Eau0ZADkUwi6b("not support file type {$nvo1_}");
        goto V8Isk;
        NW6DC:
        GaCSa:
        goto qq5sO;
        a2r3s:
        $nciUN->mme8vGqglZH(new XpPxaggO8iQsi($nciUN, $this->tcoQz, $fxDHl));
        goto RgPhe;
        V8Isk:
    }
}
