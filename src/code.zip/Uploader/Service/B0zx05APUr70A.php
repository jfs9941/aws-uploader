<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Core\Observer\OyE37jmOM3GFk;
use Jfs\Uploader\Core\Observer\VypGUfv7ecYko;
use Jfs\Uploader\Core\EW5dO98pv4IzW;
use Jfs\Uploader\Core\WOlVkQsBFs8pP;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Jfs\Uploader\Exception\SXcV92PG8WkeS;
use Jfs\Uploader\Service\FileResolver\Kgc4WleZRX6U5;
use Ramsey\Uuid\Uuid;
final class B0zx05APUr70A
{
    private $o7eer;
    private $UBJ9G;
    private $gGE8I;
    public function __construct($qJ5na, $e1L33, $duBfR)
    {
        goto FXyw0;
        FXyw0:
        $this->o7eer = $qJ5na;
        goto y79Dc;
        y79Dc:
        $this->UBJ9G = $e1L33;
        goto K0HzA;
        K0HzA:
        $this->gGE8I = $duBfR;
        goto hNWb4;
        hNWb4:
    }
    public function mI1QeFDQhTT($s3v8_)
    {
        goto NoM6O;
        W6gTA:
        $au5Ec = $s3v8_->getFile();
        goto CQiUf;
        CQiUf:
        return $this->mU6aFBu3B9V($au5Ec->extension(), ZBLpZ2qUZ4P6C::S3, null, $s3v8_->options());
        goto WAoZ8;
        NoM6O:
        if (!$s3v8_ instanceof SingleUploadInterface) {
            goto ZhIxT;
        }
        goto W6gTA;
        WAoZ8:
        ZhIxT:
        goto hiQ2n;
        hiQ2n:
        return $this->mU6aFBu3B9V($s3v8_['file_extension'], 's3' === $s3v8_['driver'] ? ZBLpZ2qUZ4P6C::S3 : ZBLpZ2qUZ4P6C::LOCAL);
        goto XxGCt;
        XxGCt:
    }
    public function mUT7Vao1x5z(string $ld8Ad)
    {
        goto PreDz;
        W_v4G:
        return $PQjbH;
        goto rz9Pm;
        cnqj9:
        $PQjbH->exists = true;
        goto YdaDe;
        YdaDe:
        $PQjbH->setRawAttributes($ij6wF->getAttributes());
        goto W_v4G;
        wvAMH:
        $PQjbH = $this->mU6aFBu3B9V($ij6wF->getAttribute('type'), $ij6wF->getAttribute('driver'), $ij6wF->getAttribute('id'));
        goto cnqj9;
        PreDz:
        $ij6wF = config('upload.attachment_model')::findOrFail($ld8Ad);
        goto wvAMH;
        rz9Pm:
    }
    public function mA3OUi5XBwu(string $tfJVM) : XZsrc8KnXftCK
    {
        goto l2E6n;
        AxQGt:
        nutyN:
        goto GU_M1;
        UDiGD:
        if (!$yqV2Y) {
            goto nutyN;
        }
        goto ct5TC;
        GU_M1:
        throw new Lki0sGWiU5Kzv('metadata file not found');
        goto yCtbZ;
        Uxo9e:
        if ($umapn) {
            goto uvG9z;
        }
        goto pDihK;
        pDihK:
        $umapn = $this->gGE8I->get($tfJVM);
        goto ou4Sj;
        l2E6n:
        $umapn = $this->UBJ9G->get($tfJVM);
        goto Uxo9e;
        vaIh6:
        $yqV2Y = json_decode($umapn, true);
        goto UDiGD;
        ct5TC:
        $tB3m5 = WOlVkQsBFs8pP::mrClfEjUpZO($yqV2Y);
        goto AH_zs;
        AH_zs:
        return $this->mU6aFBu3B9V($tB3m5->YE0IW, $tB3m5->maCZ8QaOTiE(), $tB3m5->filename);
        goto AxQGt;
        ou4Sj:
        uvG9z:
        goto vaIh6;
        yCtbZ:
    }
    private function mU6aFBu3B9V(string $QwyTJ, $eVUDw, ?string $ld8Ad = null, array $K704z = [])
    {
        goto AE1pC;
        g3YXh:
        switch ($QwyTJ) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $zEBaq = Sf7MFJ2wUSx2k::createFromScratch($ld8Ad, $QwyTJ);
                goto y1nsw;
            case 'mp4':
            case 'mov':
                $zEBaq = RVcEF1JsGQd8M::createFromScratch($ld8Ad, $QwyTJ);
                goto y1nsw;
            case 'pdf':
                $zEBaq = EW5dO98pv4IzW::createFromScratch($ld8Ad, $QwyTJ);
                goto y1nsw;
            default:
                throw new SXcV92PG8WkeS("not support file type {$QwyTJ}");
        }
        goto rstyy;
        rstyy:
        yMekn:
        goto MWMSy;
        JQvEK:
        a1fKm:
        goto b8F9K;
        ISGjO:
        $zEBaq->mxt7Kk7QeSS(new VypGUfv7ecYko($zEBaq, $this->gGE8I, $K704z));
        goto rc6II;
        rc6II:
        foreach ($this->o7eer as $LtUvT) {
            goto MZnNz;
            MZnNz:
            if (!$LtUvT->mSdDQUHLSR9($zEBaq)) {
                goto veWVI;
            }
            goto zhcRC;
            zhcRC:
            return $zEBaq->initLocation($LtUvT->mIH1UIkA98G($zEBaq));
            goto LCf06;
            k0eR9:
            MyAuu:
            goto jnW8n;
            LCf06:
            veWVI:
            goto k0eR9;
            jnW8n:
        }
        goto JQvEK;
        OVBSM:
        $zEBaq = $zEBaq->mud7sI4nIqx($eVUDw);
        goto DFnGj;
        AE1pC:
        $ld8Ad = $ld8Ad ?? Uuid::uuid4()->getHex()->toString();
        goto g3YXh;
        b8F9K:
        throw new SXcV92PG8WkeS("not support file type {$QwyTJ}");
        goto uAogp;
        MWMSy:
        y1nsw:
        goto OVBSM;
        DFnGj:
        $zEBaq->mxt7Kk7QeSS(new OyE37jmOM3GFk($zEBaq));
        goto ISGjO;
        uAogp:
    }
}
