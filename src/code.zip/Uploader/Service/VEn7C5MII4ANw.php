<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Illuminate\Contracts\Filesystem\Filesystem;
final class VEn7C5MII4ANw
{
    private $Fcin3;
    private $Mhgax;
    private $Ybatl;
    public function __construct(string $Bnpg8, string $loxN0, Filesystem $FHlTP)
    {
        goto qn3lt;
        qn3lt:
        $this->Fcin3 = $Bnpg8;
        goto LWqlO;
        LWqlO:
        $this->Mhgax = $loxN0;
        goto ULfQG;
        ULfQG:
        $this->Ybatl = $FHlTP;
        goto DZ7EE;
        DZ7EE:
    }
    public function moe4R5sDFyZ(Lx6EggVsR2j6q $vIqmh) : string
    {
        goto pTsRk;
        cUpEV:
        return $this->Ybatl->url($vIqmh->getAttribute('filename'));
        goto NJnOP;
        pTsRk:
        if (!(Y9OZ7qWyGdhw2::S3 == $vIqmh->getAttribute('driver'))) {
            goto mWO8X;
        }
        goto DK2rB;
        DK2rB:
        return 's3://' . $this->Fcin3 . '/' . $vIqmh->getAttribute('filename');
        goto aq4wL;
        aq4wL:
        mWO8X:
        goto cUpEV;
        NJnOP:
    }
    public function mzwCiTjnYVU(?string $HPvn1) : ?string
    {
        goto lvf2N;
        M0G4I:
        if (!str_contains($HPvn1, $this->Fcin3)) {
            goto rsEPL;
        }
        goto wuXs4;
        X4139:
        return 's3://' . $this->Fcin3 . '/' . ltrim($K_YMm, '/');
        goto ukgea;
        YCuzR:
        return null;
        goto xp9fS;
        lvf2N:
        if (!$HPvn1) {
            goto wRfDm;
        }
        goto M0G4I;
        c2Jlj:
        wRfDm:
        goto YCuzR;
        wuXs4:
        $K_YMm = parse_url($HPvn1, PHP_URL_PATH);
        goto X4139;
        ukgea:
        rsEPL:
        goto c2Jlj;
        xp9fS:
    }
    public function m5gStLGQgqF(string $K_YMm) : string
    {
        return 's3://' . $this->Fcin3 . '/' . $K_YMm;
    }
}
