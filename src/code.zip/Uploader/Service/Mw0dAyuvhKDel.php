<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Core\Observer\HbKYFQD9ILWYK;
use Jfs\Uploader\Core\Observer\VSXbfKeoGOaUS;
use Jfs\Uploader\Core\JmnRmflAnvBc1;
use Jfs\Uploader\Core\I2hD5aiafUU95;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Exception\J2167am6BJakj;
use Jfs\Uploader\Service\FileResolver\Ebj614gXdZiar;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class Mw0dAyuvhKDel
{
    private $JCA30;
    private $Ybatl;
    private $cC_4U;
    public function __construct($VgzFX, $FHlTP, $s1UdZ)
    {
        goto hjdG4;
        nkZwv:
        $this->Ybatl = $FHlTP;
        goto VarDH;
        VarDH:
        $this->cC_4U = $s1UdZ;
        goto fDevv;
        hjdG4:
        $this->JCA30 = $VgzFX;
        goto nkZwv;
        fDevv:
    }
    public function mQjJoIWKZGy($glKEG)
    {
        goto TDff_;
        TDff_:
        if (!$glKEG instanceof SingleUploadInterface) {
            goto NeXGU;
        }
        goto NNFJr;
        NNFJr:
        $cZk0c = $glKEG->getFile();
        goto p3BvX;
        oLg8c:
        return $this->mybyTcZAbzK($glKEG['file_extension'], 's3' === $glKEG['driver'] ? Y9OZ7qWyGdhw2::S3 : Y9OZ7qWyGdhw2::LOCAL);
        goto yckmn;
        XPrl_:
        NeXGU:
        goto oLg8c;
        p3BvX:
        return $this->mybyTcZAbzK($cZk0c->extension(), Y9OZ7qWyGdhw2::S3, null, $glKEG->options());
        goto XPrl_;
        yckmn:
    }
    public function mUrMbdZyAMf(string $q8q1b)
    {
        goto T4Acm;
        hMuf9:
        $mz56v->setRawAttributes($wEV0l->getAttributes());
        goto DJa5W;
        T4Acm:
        $wEV0l = config('upload.attachment_model')::findOrFail($q8q1b);
        goto KwqHv;
        KwqHv:
        $mz56v = $this->mybyTcZAbzK($wEV0l->getAttribute('type'), $wEV0l->getAttribute('driver'), $wEV0l->getAttribute('id'));
        goto fUv7i;
        fUv7i:
        $mz56v->exists = true;
        goto hMuf9;
        DJa5W:
        return $mz56v;
        goto WssYV;
        WssYV:
    }
    public function mFKoK1Yr03n(string $C_ZEl) : PLPNmbBnD48xL
    {
        goto Q1Hss;
        EALVX:
        return $this->mybyTcZAbzK($Y9r7G->O8lFE, $Y9r7G->mcd4WDHRYJL(), $Y9r7G->filename);
        goto Y0tJX;
        Q1Hss:
        $JGZ5k = $this->Ybatl->get($C_ZEl);
        goto cAhma;
        Q0sls:
        $JGZ5k = $this->cC_4U->get($C_ZEl);
        goto cyPJh;
        cyPJh:
        oaIU_:
        goto vAqKM;
        Y0tJX:
        pSq0x:
        goto pT3IM;
        pT3IM:
        throw new Yhh7VdR99pXtm('metadata file not found');
        goto c4Ehc;
        FiV0C:
        $Y9r7G = I2hD5aiafUU95::mr3CqhCgEdl($MCnj4);
        goto EALVX;
        ZOMqF:
        if (!$MCnj4) {
            goto pSq0x;
        }
        goto FiV0C;
        vAqKM:
        $MCnj4 = json_decode($JGZ5k, true);
        goto ZOMqF;
        cAhma:
        if ($JGZ5k) {
            goto oaIU_;
        }
        goto Q0sls;
        c4Ehc:
    }
    private function mybyTcZAbzK(string $sBtqB, $cBCtb, ?string $q8q1b = null, array $bvU4j = [])
    {
        goto hZNUb;
        Y_yRL:
        switch ($sBtqB) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $V2jNQ = JOauoJMkgHWbh::createFromScratch($q8q1b, $sBtqB);
                goto vm2ot;
            case 'mp4':
            case 'mov':
                $V2jNQ = O1jfuwJR340k5::createFromScratch($q8q1b, $sBtqB);
                goto vm2ot;
            case 'pdf':
                $V2jNQ = JmnRmflAnvBc1::createFromScratch($q8q1b, $sBtqB);
                goto vm2ot;
            default:
                throw new J2167am6BJakj("not support file type {$sBtqB}");
        }
        goto YxrqY;
        kfivS:
        throw new J2167am6BJakj("not support file type {$sBtqB}");
        goto TWCMp;
        RNBHU:
        $V2jNQ->mowZJc7KWzQ(new VSXbfKeoGOaUS($V2jNQ, $this->cC_4U, $bvU4j));
        goto sj2eW;
        YxrqY:
        D5yE0:
        goto OGzh1;
        NTMjD:
        $V2jNQ = $V2jNQ->me9qyMUxXIj($cBCtb);
        goto m_4BD;
        sj2eW:
        foreach ($this->JCA30 as $O11GX) {
            goto rjNb9;
            C95Jy:
            R2dUL:
            goto BgdGb;
            Re046:
            return $V2jNQ->initLocation($O11GX->mYKZM8V80kU($V2jNQ));
            goto C95Jy;
            BgdGb:
            d4Wxt:
            goto V2uYr;
            rjNb9:
            if (!$O11GX->mZbDnySw1PK($V2jNQ)) {
                goto R2dUL;
            }
            goto Re046;
            V2uYr:
        }
        goto TyPjt;
        OGzh1:
        vm2ot:
        goto NTMjD;
        hZNUb:
        $q8q1b = $q8q1b ?? Uuid::uuid4()->getHex()->toString();
        goto Y_yRL;
        TyPjt:
        L2zW2:
        goto kfivS;
        m_4BD:
        $V2jNQ->mowZJc7KWzQ(new HbKYFQD9ILWYK($V2jNQ));
        goto RNBHU;
        TWCMp:
    }
}
