<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
final class MyogiksqjOJyS implements VideoPostHandleServiceInterface
{
    private $Zfmgt;
    private $Vhcrn;
    public function __construct(UploadServiceInterface $Lpv0i, Filesystem $Klx1U)
    {
        $this->Zfmgt = $Lpv0i;
        $this->Vhcrn = $Klx1U;
    }
    public function saveMetadata(string $mfjeD, array $uJKYp)
    {
        goto WOfmY;
        CZzQc:
        APrji:
        goto tiiOh;
        CSV_T:
        $FmcNx['resolution'] = $uJKYp['resolution'];
        goto jxlig;
        cTa05:
        YnOIE:
        goto NJyRr;
        RJrzr:
        if (!isset($uJKYp['thumbnail'])) {
            goto YnOIE;
        }
        goto kgjXJ;
        z74Bm:
        if (!$wmU7r->update($FmcNx)) {
            goto APrji;
        }
        goto ZtXIt;
        iUVWv:
        GCUWX:
        goto z74Bm;
        xi1l3:
        if (!isset($uJKYp['resolution'])) {
            goto q5L40;
        }
        goto CSV_T;
        I9C1k:
        Yz8oV:
        goto xMbSr;
        NJyRr:
        if (!isset($uJKYp['duration'])) {
            goto rI1IE;
        }
        goto VB7P3;
        xW1DZ:
        return $wmU7r->getView();
        goto CZzQc;
        ZtXIt:
        if (!(isset($uJKYp['change_status']) && $uJKYp['change_status'])) {
            goto LJCpr;
        }
        goto BEaya;
        ngddp:
        $FmcNx['fps'] = $uJKYp['fps'];
        goto I9C1k;
        f3quS:
        rI1IE:
        goto xi1l3;
        i8kMM:
        throw new \Exception("ZSB2cdrwtZpmk metadata store failed for unknown reason ... " . $mfjeD);
        goto x3DBP;
        BEaya:
        $this->Zfmgt->updateFile($wmU7r->getAttribute('id'), SwAwanZG36Yx6::PROCESSING);
        goto pdDRB;
        WOfmY:
        $wmU7r = ZSB2cdrwtZpmk::findOrFail($mfjeD);
        goto WdtLf;
        lb8sd:
        unset($FmcNx['thumbnail']);
        goto iUVWv;
        xMbSr:
        if (!$wmU7r->xC5r_) {
            goto GCUWX;
        }
        goto lb8sd;
        jxlig:
        q5L40:
        goto TytVu;
        WdtLf:
        $FmcNx = [];
        goto RJrzr;
        TytVu:
        if (!isset($uJKYp['fps'])) {
            goto Yz8oV;
        }
        goto ngddp;
        VB7P3:
        $FmcNx['duration'] = $uJKYp['duration'];
        goto f3quS;
        kgjXJ:
        try {
            goto lyY6d;
            GCEQ7:
            $FmcNx['thumbnail_id'] = $XGdv1['id'];
            goto IGmkB;
            IGmkB:
            $FmcNx['thumbnail'] = $XGdv1['filename'];
            goto NZf21;
            lyY6d:
            $XGdv1 = $this->Zfmgt->storeSingleFile(new class($uJKYp['thumbnail']) implements SingleUploadInterface
            {
                private $IJ6tP;
                public function __construct($rQ18B)
                {
                    $this->IJ6tP = $rQ18B;
                }
                public function getFile()
                {
                    return $this->IJ6tP;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto GCEQ7;
            NZf21:
        } catch (\Throwable $tPAjT) {
            Log::warning("ZSB2cdrwtZpmk thumbnail store failed: " . $tPAjT->getMessage());
        }
        goto cTa05;
        tiiOh:
        Log::warning("ZSB2cdrwtZpmk metadata store failed for unknown reason ... " . $mfjeD);
        goto i8kMM;
        pdDRB:
        LJCpr:
        goto xW1DZ;
        x3DBP:
    }
    public function createThumbnail(string $Ru7zy) : void
    {
        goto VKSRL;
        Uh7yy:
        $wmU7r = ZSB2cdrwtZpmk::findOrFail($Ru7zy);
        goto Bt7BO;
        Bt7BO:
        $D7Hgf = "v2/hls/thumbnails/{$Ru7zy}/";
        goto Fde3t;
        SZTw7:
        $yEMWv = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto E4lgJ;
        E4lgJ:
        try {
            goto d1igg;
            NGiuH:
            $k_tdh = $KFX3N->get('QueueUrl');
            goto LKCQ6;
            d1igg:
            $KFX3N = $yEMWv->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto NGiuH;
            LKCQ6:
            $yEMWv->sendMessage(['QueueUrl' => $k_tdh, 'MessageBody' => json_encode(['file_path' => $wmU7r->getLocation()])]);
            goto tanxn;
            tanxn:
        } catch (\Throwable $iE7wL) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$iE7wL->getMessage()}");
        }
        goto HrrGe;
        VKSRL:
        Log::info("Use Lambda to generate thumbnail for video: " . $Ru7zy);
        goto Uh7yy;
        HrrGe:
        QT7SG:
        goto tBos0;
        Fde3t:
        if (!(!$this->Vhcrn->directoryExists($D7Hgf) && empty($wmU7r->mLQ4nsW4BAP()))) {
            goto QT7SG;
        }
        goto SZTw7;
        tBos0:
    }
    public function mib2u4UqRZ7(string $Ru7zy) : void
    {
        goto KrVEm;
        ZDyKO:
        $D7Hgf = "v2/hls/thumbnails/{$Ru7zy}/";
        goto KUvu0;
        rsLb3:
        wYzVM:
        goto UZPOP;
        WNtNG:
        Log::error("Message back with success data but not found thumbnail files " . $Ru7zy);
        goto Hsbdg;
        UZPOP:
        $wmU7r->update(['generated_previews' => $D7Hgf]);
        goto avvF8;
        KrVEm:
        $wmU7r = ZSB2cdrwtZpmk::findOrFail($Ru7zy);
        goto ZDyKO;
        KcbFo:
        throw new \Exception("Message back with success data but not found thumbnail " . $Ru7zy);
        goto cu83q;
        g9Hy3:
        if (!(count($TDvDf) === 0)) {
            goto wYzVM;
        }
        goto WNtNG;
        mVn05:
        $TDvDf = $this->Vhcrn->files($D7Hgf);
        goto g9Hy3;
        cu83q:
        aNxBo:
        goto mVn05;
        Hsbdg:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Ru7zy);
        goto rsLb3;
        IRjQU:
        Log::error("Message back with success data but not found thumbnail " . $Ru7zy);
        goto KcbFo;
        KUvu0:
        if ($this->Vhcrn->directoryExists($D7Hgf)) {
            goto aNxBo;
        }
        goto IRjQU;
        avvF8:
    }
    public function getThumbnails(string $Ru7zy) : array
    {
        $wmU7r = ZSB2cdrwtZpmk::findOrFail($Ru7zy);
        return $wmU7r->getThumbnails();
    }
}
