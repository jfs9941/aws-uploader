<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\VjEI9Nu3TyWfD;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Core\UF7LVTTMiEHny;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
final class IeMg7A21r884m implements VjEI9Nu3TyWfD
{
    private $D7XpS;
    private $GPUTg;
    public $VaN5A;
    private $h12Fq;
    private $rik08;
    private $GmmTj;
    public function __construct($dE5UO, $G7ArA, $htVWs, $HAkzF, $sq5vA, $MYo5D)
    {
        goto sbhZe;
        QRiNz:
        $this->GPUTg = $G7ArA;
        goto U5C17;
        sbhZe:
        $this->GmmTj = $MYo5D;
        goto u52f0;
        rrNgW:
        $this->h12Fq = $HAkzF;
        goto pPTFk;
        pPTFk:
        $this->rik08 = $sq5vA;
        goto ryZn7;
        U5C17:
        $this->VaN5A = $htVWs;
        goto rrNgW;
        u52f0:
        $this->D7XpS = $dE5UO;
        goto QRiNz;
        ryZn7:
    }
    public function resolvePath($jBims, $Z9PFQ = CUySMhqlL7P49::S3) : string
    {
        goto jDcHc;
        jDcHc:
        if (!$jBims instanceof EpIpyfdFnoTz6) {
            goto dxhGx;
        }
        goto fk8jx;
        CSldW:
        return trim($this->VaN5A, '/') . '/' . $jBims;
        goto f4E8l;
        Ad3EV:
        return trim($this->GPUTg, '/') . '/' . $jBims;
        goto T4ck3;
        bV0LZ:
        return $this->m7o50z7j6pE($jBims);
        goto sCRYH;
        Jpeu7:
        if (!$this->D7XpS) {
            goto pqJH3;
        }
        goto CSldW;
        xZ3Sn:
        return config('upload.home') . '/' . $jBims;
        goto wbHY_;
        F9LSS:
        if (!($Z9PFQ === CUySMhqlL7P49::LOCAL)) {
            goto NYPe3;
        }
        goto xZ3Sn;
        f4E8l:
        pqJH3:
        goto Ad3EV;
        fk8jx:
        $jBims = $jBims->getAttribute('filename');
        goto HyjZL;
        wbHY_:
        NYPe3:
        goto V4HQM;
        sCRYH:
        LKPCi:
        goto Jpeu7;
        V4HQM:
        if (!(!empty($this->h12Fq) && !empty($this->rik08))) {
            goto LKPCi;
        }
        goto bV0LZ;
        HyjZL:
        dxhGx:
        goto F9LSS;
        T4ck3:
    }
    public function resolveThumbnail(EpIpyfdFnoTz6 $jBims) : string
    {
        goto gOKtu;
        v7vor:
        return $this->resolvePath($jBims, $jBims->getAttribute('driver'));
        goto MgKjf;
        mxtcw:
        return $this->url($gx7xw, $jBims->getAttribute('driver'));
        goto fMUDt;
        gOKtu:
        $gx7xw = $jBims->getAttribute('thumbnail');
        goto WXkVN;
        vdYTT:
        rucsV:
        goto wzTne;
        rPkXR:
        if (!$jBims instanceof C6ftQJKUZRJIp) {
            goto y0Pcj;
        }
        goto v7vor;
        wzTne:
        X788N:
        goto rPkXR;
        MgKjf:
        y0Pcj:
        goto OPjNW;
        OPjNW:
        if (!$jBims instanceof UF7LVTTMiEHny) {
            goto QX0rs;
        }
        goto aWMYQ;
        fMUDt:
        x62Bq:
        goto NOR1q;
        SaPEZ:
        if (!$r5P8m) {
            goto rucsV;
        }
        goto v3Zap;
        WXkVN:
        if (!$gx7xw) {
            goto x62Bq;
        }
        goto mxtcw;
        v3Zap:
        return $this->resolvePath($r5P8m, $r5P8m->getAttribute('driver'));
        goto vdYTT;
        KOy6i:
        QX0rs:
        goto kaLlV;
        aWMYQ:
        return asset('/img/pdf-preview.svg');
        goto KOy6i;
        mzb3Y:
        $r5P8m = C6ftQJKUZRJIp::find($jBims->getAttribute('thumbnail_id'));
        goto SaPEZ;
        NOR1q:
        if (!$jBims->getAttribute('thumbnail_id')) {
            goto X788N;
        }
        goto mzb3Y;
        kaLlV:
        return '';
        goto ofHv4;
        ofHv4:
    }
    private function url($iTIh6, $Z9PFQ)
    {
        goto vugla;
        h611C:
        return $this->resolvePath($iTIh6);
        goto wbYfB;
        Y9VOU:
        xdHxp:
        goto h611C;
        s_tnq:
        return config('upload.home') . '/' . $iTIh6;
        goto Y9VOU;
        vugla:
        if (!($Z9PFQ == CUySMhqlL7P49::LOCAL)) {
            goto xdHxp;
        }
        goto s_tnq;
        wbYfB:
    }
    private function m7o50z7j6pE($iTIh6)
    {
        goto yM1JE;
        AaIay:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto OZ_Xf;
        Uys29:
        return $X4rDQ->getSignedUrl($this->VaN5A . '/' . $iTIh6, $PHj0N);
        goto MD94q;
        eWRjJ:
        UJdf0:
        goto yQa_l;
        yM1JE:
        if (!(strpos($iTIh6, 'https://') === 0)) {
            goto IOrGu;
        }
        goto AaIay;
        yQa_l:
        $PHj0N = now()->addMinutes(60)->timestamp;
        goto wf3mz;
        p2LDN:
        if (!(strpos($iTIh6, 'm3u8') !== false)) {
            goto UJdf0;
        }
        goto w39PZ;
        OZ_Xf:
        IOrGu:
        goto p2LDN;
        w39PZ:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto eWRjJ;
        wf3mz:
        $X4rDQ = new UrlSigner($this->h12Fq, $this->GmmTj->path($this->rik08));
        goto Uys29;
        MD94q:
    }
    public function resolvePathForHlsVideo(RhdJGUi8FOLBJ $UUt0Z, $bebcO = false) : string
    {
        goto MLCyk;
        E0lc3:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Yjy_B;
        Yjy_B:
        wOdDf:
        goto UOx9f;
        MLCyk:
        if ($UUt0Z->getAttribute('hls_path')) {
            goto wOdDf;
        }
        goto E0lc3;
        UOx9f:
        return $this->VaN5A . '/' . $UUt0Z->getAttribute('hls_path');
        goto vpL22;
        vpL22:
    }
    public function resolvePathForHlsVideos()
    {
        goto S8c2Y;
        quypa:
        $atBPW = $this->VaN5A . '/v2/hls/';
        goto DjaOf;
        P_4Ie:
        $NsE9u = $zpneZ->getSignedCookie(['key_pair_id' => $this->h12Fq, 'private_key' => $this->GmmTj->path($this->rik08), 'policy' => $r07OL]);
        goto XZbPn;
        j4yP5:
        $zpneZ = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto P_4Ie;
        S8c2Y:
        $PHj0N = now()->addDays(3)->timestamp;
        goto quypa;
        XZbPn:
        return [$NsE9u, $PHj0N];
        goto wNnmr;
        DjaOf:
        $r07OL = json_encode(['Statement' => [['Resource' => sprintf('%s*', $atBPW), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $PHj0N]]]]]);
        goto j4yP5;
        wNnmr:
    }
}
