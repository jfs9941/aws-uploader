<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Illuminate\Contracts\Filesystem\Filesystem;
final class PzfoMEiZi5U2a
{
    private $VtRCr;
    private $f4RKZ;
    private $hhcR1;
    public function __construct(string $G2CsF, string $TysiM, Filesystem $nQYui)
    {
        goto q6rvL;
        q6rvL:
        $this->VtRCr = $G2CsF;
        goto M__lb;
        wzvWz:
        $this->hhcR1 = $nQYui;
        goto iv4wY;
        M__lb:
        $this->f4RKZ = $TysiM;
        goto wzvWz;
        iv4wY:
    }
    public function mYeVDpuA6lx(MEyH4ejCzSk64 $pkR_A) : string
    {
        goto E2qxI;
        YlqZx:
        FzIZ0:
        goto JaeZu;
        zmgn5:
        return 's3://' . $this->VtRCr . '/' . $pkR_A->getAttribute('filename');
        goto YlqZx;
        E2qxI:
        if (!(A3VATad7gvqZU::S3 == $pkR_A->getAttribute('driver'))) {
            goto FzIZ0;
        }
        goto zmgn5;
        JaeZu:
        return $this->hhcR1->url($pkR_A->getAttribute('filename'));
        goto U_gqb;
        U_gqb:
    }
    public function mBQrwMSIABF(?string $AJp4R) : ?string
    {
        goto CKxHw;
        ZXz0i:
        if (!K8Crh($AJp4R, $this->VtRCr)) {
            goto P1k7v;
        }
        goto d5oPf;
        QcWrO:
        P1k7v:
        goto W4IRU;
        aZ6nq:
        return 's3://' . $this->VtRCr . '/' . ltrim($uMpUA, '/');
        goto QcWrO;
        CKxHw:
        if (!$AJp4R) {
            goto PHFC4;
        }
        goto ZXz0i;
        pOeYZ:
        return null;
        goto K5Pds;
        d5oPf:
        $uMpUA = parse_url($AJp4R, PHP_URL_PATH);
        goto aZ6nq;
        W4IRU:
        PHFC4:
        goto pOeYZ;
        K5Pds:
    }
    public function mVCqMpMMdTo(string $uMpUA) : string
    {
        return 's3://' . $this->VtRCr . '/' . $uMpUA;
    }
}
