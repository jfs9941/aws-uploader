<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
final class K9BQS1i37fxvm implements VideoPostHandleServiceInterface
{
    private $yP5UR;
    private $IRlXr;
    public function __construct(UploadServiceInterface $H5nho, Filesystem $JGvdR)
    {
        $this->yP5UR = $H5nho;
        $this->IRlXr = $JGvdR;
    }
    public function saveMetadata(string $R7IrL, array $YKW91)
    {
        goto TgWj6;
        JXCNV:
        ktq2P:
        goto QR1k6;
        juhGd:
        if (!isset($YKW91['resolution'])) {
            goto irhtB;
        }
        goto twc8e;
        twc8e:
        $FcasN['resolution'] = $YKW91['resolution'];
        goto PQ38H;
        qVsMk:
        if (!isset($YKW91['fps'])) {
            goto yqoeg;
        }
        goto H6Gr1;
        oKrjX:
        cnmpL:
        goto Ay6HR;
        mzb3x:
        nd_uK:
        goto XtjYR;
        zA6O6:
        $FcasN = [];
        goto KfDbh;
        BfU90:
        try {
            goto WDCn7;
            WDCn7:
            $i1LOg = $this->yP5UR->storeSingleFile(new class($YKW91['thumbnail']) implements SingleUploadInterface
            {
                private $uXtKk;
                public function __construct($xdi9a)
                {
                    $this->uXtKk = $xdi9a;
                }
                public function getFile()
                {
                    return $this->uXtKk;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto wtfyh;
            wtfyh:
            $FcasN['thumbnail_id'] = $i1LOg['id'];
            goto XVmDW;
            XVmDW:
            $FcasN['thumbnail'] = $i1LOg['filename'];
            goto S4X7_;
            S4X7_:
        } catch (\Throwable $nhDP5) {
            Log::warning("B6s4AA1exjQ2T thumbnail store failed: " . $nhDP5->getMessage());
        }
        goto mzb3x;
        TgWj6:
        $cZ20c = B6s4AA1exjQ2T::findOrFail($R7IrL);
        goto zA6O6;
        zUUlX:
        throw new \Exception("B6s4AA1exjQ2T metadata store failed for unknown reason ... " . $R7IrL);
        goto mP4lP;
        Cb1CN:
        if (!$cZ20c->update($FcasN)) {
            goto cnmpL;
        }
        goto Z6QLH;
        QR1k6:
        return $cZ20c->getView();
        goto oKrjX;
        Z6QLH:
        if (!(isset($YKW91['change_status']) && $YKW91['change_status'])) {
            goto ktq2P;
        }
        goto hCwkf;
        Rjomu:
        $FcasN['duration'] = $YKW91['duration'];
        goto shaFl;
        z9XnT:
        unset($FcasN['thumbnail']);
        goto ekxsA;
        shaFl:
        vjgLg:
        goto juhGd;
        Ay6HR:
        Log::warning("B6s4AA1exjQ2T metadata store failed for unknown reason ... " . $R7IrL);
        goto zUUlX;
        hCwkf:
        $this->yP5UR->updateFile($cZ20c->getAttribute('id'), QUh2VVA2TE5xx::PROCESSING);
        goto JXCNV;
        KfDbh:
        if (!isset($YKW91['thumbnail'])) {
            goto nd_uK;
        }
        goto BfU90;
        PQ38H:
        irhtB:
        goto qVsMk;
        tVO_K:
        if (!$cZ20c->q4Ui5) {
            goto La3kb;
        }
        goto z9XnT;
        ekxsA:
        La3kb:
        goto Cb1CN;
        H6Gr1:
        $FcasN['fps'] = $YKW91['fps'];
        goto Nz8Q7;
        Nz8Q7:
        yqoeg:
        goto tVO_K;
        XtjYR:
        if (!isset($YKW91['duration'])) {
            goto vjgLg;
        }
        goto Rjomu;
        mP4lP:
    }
    public function createThumbnail(string $wsssR) : void
    {
        goto VjGYZ;
        bAR2u:
        if (!(!$this->IRlXr->directoryExists($f1mMW) && empty($cZ20c->mW8hDDgSYOD()))) {
            goto lNRR1;
        }
        goto okgnn;
        ubzZe:
        $cZ20c = B6s4AA1exjQ2T::findOrFail($wsssR);
        goto NT6Ax;
        NT6Ax:
        $f1mMW = "v2/hls/thumbnails/{$wsssR}/";
        goto bAR2u;
        okgnn:
        $lO1pb = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto CjVkQ;
        bZZWj:
        lNRR1:
        goto ugMoe;
        VjGYZ:
        Log::info("Use Lambda to generate thumbnail for video: " . $wsssR);
        goto ubzZe;
        CjVkQ:
        try {
            goto MIcp6;
            aGv1N:
            $AFCSO = $uB3wk->get('QueueUrl');
            goto EdCJG;
            MIcp6:
            $uB3wk = $lO1pb->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto aGv1N;
            EdCJG:
            $lO1pb->sendMessage(['QueueUrl' => $AFCSO, 'MessageBody' => json_encode(['file_path' => $cZ20c->getLocation()])]);
            goto m9vT5;
            m9vT5:
        } catch (\Throwable $jrXe_) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$jrXe_->getMessage()}");
        }
        goto bZZWj;
        ugMoe:
    }
    public function myn0AprrWHI(string $wsssR) : void
    {
        goto wOoa5;
        ANzlG:
        $f1mMW = "v2/hls/thumbnails/{$wsssR}/";
        goto qPKUn;
        wOoa5:
        $cZ20c = B6s4AA1exjQ2T::findOrFail($wsssR);
        goto ANzlG;
        iwYPx:
        qVtOv:
        goto QqwIM;
        ogV23:
        if (!(count($qG1Gr) === 0)) {
            goto Z8LKx;
        }
        goto uJPjE;
        cQqYF:
        throw new \Exception("Message back with success data but not found thumbnail files " . $wsssR);
        goto xvQ8x;
        xvQ8x:
        Z8LKx:
        goto qZene;
        qZene:
        $cZ20c->update(['generated_previews' => $f1mMW]);
        goto KTftp;
        Z4hIj:
        throw new \Exception("Message back with success data but not found thumbnail " . $wsssR);
        goto iwYPx;
        qPKUn:
        if ($this->IRlXr->directoryExists($f1mMW)) {
            goto qVtOv;
        }
        goto HOnZQ;
        HOnZQ:
        Log::error("Message back with success data but not found thumbnail " . $wsssR);
        goto Z4hIj;
        QqwIM:
        $qG1Gr = $this->IRlXr->files($f1mMW);
        goto ogV23;
        uJPjE:
        Log::error("Message back with success data but not found thumbnail files " . $wsssR);
        goto cQqYF;
        KTftp:
    }
    public function getThumbnails(string $wsssR) : array
    {
        $cZ20c = B6s4AA1exjQ2T::findOrFail($wsssR);
        return $cZ20c->getThumbnails();
    }
}
