<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Core\Observer\I54v4LiC5IESQ;
use Jfs\Uploader\Core\Observer\HJceqWpwyTfR6;
use Jfs\Uploader\Core\NfPkVduXHwQBz;
use Jfs\Uploader\Core\HH3lB6zqpldAM;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Exception\Mfea9FZrXQil7;
use Jfs\Uploader\Service\FileResolver\DUxtF4CYlybbO;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class Sr0k4NPxeSoLY
{
    private $h2tfT;
    private $W2Sfl;
    private $uiTOc;
    public function __construct($lFlkw, $d_Wiu, $ATeSz)
    {
        goto V0lHl;
        sK5dG:
        $this->W2Sfl = $d_Wiu;
        goto gXrha;
        V0lHl:
        $this->h2tfT = $lFlkw;
        goto sK5dG;
        gXrha:
        $this->uiTOc = $ATeSz;
        goto b17Me;
        b17Me:
    }
    public function mLeTwaifGjO($d1LbD)
    {
        goto Ojr1J;
        L183c:
        return $this->m9nB7h5CSjC($huASX->extension(), J0IuL8wroLOWt::S3, null, $d1LbD->options());
        goto tTx58;
        Ojr1J:
        if (!$d1LbD instanceof SingleUploadInterface) {
            goto f29ZR;
        }
        goto lRPEh;
        lRPEh:
        $huASX = $d1LbD->getFile();
        goto L183c;
        feGFI:
        return $this->m9nB7h5CSjC($d1LbD['file_extension'], 's3' === $d1LbD['driver'] ? J0IuL8wroLOWt::S3 : J0IuL8wroLOWt::LOCAL);
        goto oyqon;
        tTx58:
        f29ZR:
        goto feGFI;
        oyqon:
    }
    public function mNA739rY1kw(string $B_L9m)
    {
        goto feRgQ;
        PtYm_:
        $YfsmL->exists = true;
        goto CbjSx;
        yvySV:
        $YfsmL = $this->m9nB7h5CSjC($PC1_p->getAttribute('type'), $PC1_p->getAttribute('driver'), $PC1_p->getAttribute('id'));
        goto PtYm_;
        feRgQ:
        $PC1_p = config('upload.attachment_model')::findOrFail($B_L9m);
        goto yvySV;
        jMo5I:
        return $YfsmL;
        goto LX8zJ;
        CbjSx:
        $YfsmL->setRawAttributes($PC1_p->getAttributes());
        goto jMo5I;
        LX8zJ:
    }
    public function mDMbcPNb8m7(string $G62og) : FTr6mgGRFf157
    {
        goto ul5uJ;
        UhXaC:
        zKtUu:
        goto EPcdw;
        QqNjq:
        Fm7LD:
        goto w0xP3;
        RivzK:
        return $this->m9nB7h5CSjC($rgsAF->RRafQ, $rgsAF->mRLbm2J63D1(), $rgsAF->filename);
        goto UhXaC;
        VQb4X:
        $rgsAF = HH3lB6zqpldAM::m7NfWkVypwj($fK0e7);
        goto RivzK;
        ul5uJ:
        $p9LOJ = $this->W2Sfl->get($G62og);
        goto HqsDv;
        EPcdw:
        throw new NCCpOFnEetEh7('metadata file not found');
        goto lE5BT;
        K5Wgp:
        $p9LOJ = $this->uiTOc->get($G62og);
        goto QqNjq;
        HqsDv:
        if ($p9LOJ) {
            goto Fm7LD;
        }
        goto K5Wgp;
        DaMvx:
        if (!$fK0e7) {
            goto zKtUu;
        }
        goto VQb4X;
        w0xP3:
        $fK0e7 = json_decode($p9LOJ, true);
        goto DaMvx;
        lE5BT:
    }
    private function m9nB7h5CSjC(string $QCzoS, $ILGAH, ?string $B_L9m = null, array $Bm5Jl = [])
    {
        goto sPq0d;
        s152o:
        QYyRF:
        goto JfNSZ;
        qCmEk:
        $S09U5->mfXOzZaHn0W(new HJceqWpwyTfR6($S09U5, $this->uiTOc, $Bm5Jl));
        goto y1Eme;
        t7Q8t:
        throw new Mfea9FZrXQil7("not support file type {$QCzoS}");
        goto hTOqC;
        YDL2Q:
        switch ($QCzoS) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $S09U5 = XMeo8SOmME8kj::createFromScratch($B_L9m, $QCzoS);
                goto BjFpJ;
            case 'mp4':
            case 'mov':
                $S09U5 = U9HMl0N8dP0ZH::createFromScratch($B_L9m, $QCzoS);
                goto BjFpJ;
            case 'pdf':
                $S09U5 = NfPkVduXHwQBz::createFromScratch($B_L9m, $QCzoS);
                goto BjFpJ;
            default:
                throw new Mfea9FZrXQil7("not support file type {$QCzoS}");
        }
        goto s152o;
        y1Eme:
        foreach ($this->h2tfT as $FpmNM) {
            goto l85uV;
            NHiqf:
            return $S09U5->initLocation($FpmNM->mNnMQokzwcj($S09U5));
            goto Asqbk;
            Lilgj:
            dZZAv:
            goto dNGQQ;
            Asqbk:
            ZRIWf:
            goto Lilgj;
            l85uV:
            if (!$FpmNM->mVxygpHw1dN($S09U5)) {
                goto ZRIWf;
            }
            goto NHiqf;
            dNGQQ:
        }
        goto gwLqT;
        GL1J0:
        $S09U5->mfXOzZaHn0W(new I54v4LiC5IESQ($S09U5));
        goto qCmEk;
        JfNSZ:
        BjFpJ:
        goto UNi7W;
        UNi7W:
        $S09U5 = $S09U5->m1IhploFgOI($ILGAH);
        goto GL1J0;
        gwLqT:
        M7Hfa:
        goto t7Q8t;
        sPq0d:
        $B_L9m = $B_L9m ?? Uuid::uuid4()->getHex()->toString();
        goto YDL2Q;
        hTOqC:
    }
}
