<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Illuminate\Contracts\Filesystem\Filesystem;
final class DkSooBIdtZWQo
{
    private $to1A0;
    private $fleZz;
    private $IA8m0;
    public function __construct(string $QlBWR, string $cBkQJ, Filesystem $Rgxn3)
    {
        goto h6QEv;
        amVXs:
        $this->fleZz = $cBkQJ;
        goto Uu7uM;
        Uu7uM:
        $this->IA8m0 = $Rgxn3;
        goto Nl6nS;
        h6QEv:
        $this->to1A0 = $QlBWR;
        goto amVXs;
        Nl6nS:
    }
    public function mkF9iOg4mRe(Fd8NTWwq2cQOc $ufjgt) : string
    {
        goto Qtv6V;
        QLItR:
        return 's3://' . $this->to1A0 . '/' . $ufjgt->getAttribute('filename');
        goto uWXhx;
        uWXhx:
        RZnwv:
        goto ZaIkC;
        ZaIkC:
        return $this->IA8m0->url($ufjgt->getAttribute('filename'));
        goto imwiR;
        Qtv6V:
        if (!(Tq4KHV0o6oTIo::S3 == $ufjgt->getAttribute('driver'))) {
            goto RZnwv;
        }
        goto QLItR;
        imwiR:
    }
    public function meJWmgy6zxn(?string $tgHTl) : ?string
    {
        goto motll;
        DC69X:
        tHi00:
        goto av3Ua;
        av3Ua:
        wbBNu:
        goto NA7vG;
        tlUYe:
        if (!str_contains($tgHTl, $this->to1A0)) {
            goto tHi00;
        }
        goto PHCc1;
        PHCc1:
        $FlxOy = parse_url($tgHTl, PHP_URL_PATH);
        goto yfIH_;
        NA7vG:
        return null;
        goto P11JK;
        yfIH_:
        return 's3://' . $this->to1A0 . '/' . ltrim($FlxOy, '/');
        goto DC69X;
        motll:
        if (!$tgHTl) {
            goto wbBNu;
        }
        goto tlUYe;
        P11JK:
    }
    public function mg25WKxCVWs(string $FlxOy) : string
    {
        return 's3://' . $this->to1A0 . '/' . $FlxOy;
    }
}
