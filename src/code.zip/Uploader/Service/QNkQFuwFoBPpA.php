<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\FALKOA7AcL69a;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Jfs\Uploader\Exception\VPhlMhTTl80vP;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Exception\NTczwCygSFCCc;
use Jfs\Uploader\Service\FJqWngr52kRMn;
use Illuminate\Contracts\Filesystem\Filesystem;
final class QNkQFuwFoBPpA implements UploadServiceInterface
{
    private $t15dL;
    private $SIeOC;
    private $s7iRq;
    private $zPnDe;
    public function __construct(FJqWngr52kRMn $RgIAi, Filesystem $Ay4fJ, Filesystem $UC1Qe, string $EPiZm)
    {
        goto CFDC5;
        CFDC5:
        $this->t15dL = $RgIAi;
        goto ib662;
        ib662:
        $this->SIeOC = $Ay4fJ;
        goto qZINW;
        impo1:
        $this->zPnDe = $EPiZm;
        goto cVRrd;
        qZINW:
        $this->s7iRq = $UC1Qe;
        goto impo1;
        cVRrd:
    }
    public function storeSingleFile(SingleUploadInterface $trGle) : array
    {
        goto kqsv9;
        udNgJ:
        $YEF57->mddb9WvMqo9(ZP6Ky842t6y9Y::UPLOADED);
        goto hjWYS;
        Qqf_Y:
        if (false !== $hKqqZ && $YEF57 instanceof VuQzRNCSz5bHK) {
            goto xr_uk;
        }
        goto WM9df;
        hjWYS:
        Kd3B4:
        goto W_qsu;
        W_qsu:
        return $YEF57->getView();
        goto QyoqR;
        htGtE:
        xr_uk:
        goto udNgJ;
        YVqcf:
        goto Kd3B4;
        goto htGtE;
        kqsv9:
        $YEF57 = $this->t15dL->mhUxRFmyxFS($trGle);
        goto fqCX2;
        fqCX2:
        $hKqqZ = $this->s7iRq->putFileAs(dirname($YEF57->getLocation()), $trGle->getFile(), $YEF57->getFilename() . '.' . $YEF57->getExtension(), ['visibility' => 'public']);
        goto Qqf_Y;
        WM9df:
        throw new \LogicException('File upload failed, check permissions');
        goto YVqcf;
        QyoqR:
    }
    public function storePreSignedFile(array $W5LCn)
    {
        goto OEhiQ;
        uH71A:
        $wfCxx->mjE41jZxq0g($W5LCn['mime'], $W5LCn['file_size'], $W5LCn['chunk_size'], $W5LCn['checksums'], $W5LCn['user_id'], $W5LCn['driver']);
        goto cynGl;
        cynGl:
        $wfCxx->mBYfuD2w1Gj();
        goto EHGhE;
        NJeVO:
        $wfCxx = FALKOA7AcL69a::mZMfhXq2Cjt($YEF57, $this->SIeOC, $this->s7iRq, $this->zPnDe, true);
        goto uH71A;
        EHGhE:
        return ['filename' => $wfCxx->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $wfCxx->mGNUJ8NdeC3()];
        goto LKc2w;
        OEhiQ:
        $YEF57 = $this->t15dL->mhUxRFmyxFS($W5LCn);
        goto NJeVO;
        LKc2w:
    }
    public function updatePreSignedFile(string $TZ9kY, int $C_aMu)
    {
        goto hnZqF;
        c_VxL:
        noIwJ:
        goto EImeA;
        hnZqF:
        $wfCxx = FALKOA7AcL69a::m9XExSC44dF($TZ9kY, $this->SIeOC, $this->s7iRq, $this->zPnDe);
        goto Rc00y;
        EImeA:
        qPBO2:
        goto CJjJr;
        Rc00y:
        switch ($C_aMu) {
            case ZP6Ky842t6y9Y::UPLOADED:
                $wfCxx->mjOUs0grsg0();
                goto qPBO2;
            case ZP6Ky842t6y9Y::PROCESSING:
                $wfCxx->mZ2pi4co4VV();
                goto qPBO2;
            case ZP6Ky842t6y9Y::FINISHED:
                $wfCxx->mN5oLK9CCTV();
                goto qPBO2;
            case ZP6Ky842t6y9Y::ABORTED:
                $wfCxx->m0ICSedKhNJ();
                goto qPBO2;
        }
        goto c_VxL;
        CJjJr:
    }
    public function completePreSignedFile(string $TZ9kY, array $FeFdM)
    {
        goto X9Sg1;
        y1cC1:
        return ['path' => $wfCxx->getFile()->getView()['path'], 'thumbnail' => $wfCxx->getFile()->OFuJP, 'id' => $TZ9kY];
        goto Vq2Wq;
        Q2SKR:
        $wfCxx->mjOUs0grsg0();
        goto y1cC1;
        X9Sg1:
        $wfCxx = FALKOA7AcL69a::m9XExSC44dF($TZ9kY, $this->SIeOC, $this->s7iRq, $this->zPnDe);
        goto vpMXv;
        vpMXv:
        $wfCxx->mvAZkBgf9bv()->mfL8ED8bRTw($FeFdM);
        goto Q2SKR;
        Vq2Wq:
    }
    public function updateFile(string $TZ9kY, int $C_aMu) : JVAg1Gkd0EvTM
    {
        goto aUZoJ;
        aUZoJ:
        $YEF57 = $this->t15dL->m0mcH6s2Skm($TZ9kY);
        goto B3kBf;
        aHi11:
        return $YEF57;
        goto RQcqE;
        B3kBf:
        $YEF57->mddb9WvMqo9($C_aMu);
        goto aHi11;
        RQcqE:
    }
}
