<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Service\Jobs\LFbK8cyK0wiWn;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class OAbv666w6Kulu implements WatermarkTextJobInterface
{
    private $lT6tT;
    private $B3G_O;
    private $loW7J;
    private $bLZP5;
    private $ZPzJH;
    public function __construct($W4G5n, $PqmeA, $C1By6, $G3exm, $Q5h0J)
    {
        goto pDAGY;
        RbqGp:
        $this->ZPzJH = $G3exm;
        goto tXaG8;
        x1d56:
        $this->bLZP5 = $C1By6;
        goto RbqGp;
        tXaG8:
        $this->loW7J = $Q5h0J;
        goto VIa0Q;
        pDAGY:
        $this->lT6tT = $W4G5n;
        goto x1d56;
        VIa0Q:
        $this->B3G_O = $PqmeA;
        goto O52Lm;
        O52Lm:
    }
    public function putWatermark(string $DWjir, string $gDswH) : void
    {
        goto G7a1b;
        Y6PI9:
        $nmnvM = memory_get_peak_usage();
        goto X4kWX;
        G7a1b:
        $oDOT6 = microtime(true);
        goto CwHSA;
        X4kWX:
        Log::info("Adding watermark text to image", ['imageId' => $DWjir]);
        goto G86U5;
        G86U5:
        ini_set('memory_limit', '-1');
        goto pEQM4;
        pEQM4:
        try {
            goto Pta0_;
            m71WA:
            Log::error("IQJN6V0t7DC7c is not on local, might be deleted before put watermark", ['imageId' => $DWjir]);
            goto dYe2C;
            zbW_I:
            $this->bLZP5->put($iVcpi, $C_gXz->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto cy3QZ;
            xpXZZ:
            $C_gXz->orient();
            goto TSIOu;
            qsmog:
            throw new \Exception('Failed to set final permissions on image file: ' . $iVcpi);
            goto bSFHn;
            ImXUE:
            Y1SSs:
            goto PtFz9;
            rdEdk:
            $C_gXz = $this->lT6tT->call($this, $iVcpi);
            goto xpXZZ;
            bSFHn:
            bLc7W:
            goto JZMOt;
            cy3QZ:
            unset($C_gXz);
            goto F_llD;
            Pta0_:
            $KlHaV = IQJN6V0t7DC7c::findOrFail($DWjir);
            goto Kf6dC;
            PtFz9:
            $iVcpi = $this->ZPzJH->path($KlHaV->getLocation());
            goto rdEdk;
            QSP2t:
            \Log::warning('Failed to set final permissions on image file: ' . $iVcpi);
            goto qsmog;
            TSIOu:
            $this->mOUfu5bjhqh($C_gXz, $gDswH);
            goto zbW_I;
            Kf6dC:
            if ($this->ZPzJH->exists($KlHaV->getLocation())) {
                goto Y1SSs;
            }
            goto m71WA;
            dYe2C:
            return;
            goto ImXUE;
            F_llD:
            if (chmod($iVcpi, 0664)) {
                goto bLc7W;
            }
            goto QSP2t;
            JZMOt:
        } catch (\Throwable $XJsul) {
            goto N8PkT;
            vDqdM:
            return;
            goto sSJ0i;
            sSJ0i:
            xww3o:
            goto XNfG4;
            iBBa4:
            Log::info("IQJN6V0t7DC7c has been deleted, discard it", ['imageId' => $DWjir]);
            goto vDqdM;
            XNfG4:
            Log::error("IQJN6V0t7DC7c is not readable", ['imageId' => $DWjir, 'error' => $XJsul->getMessage()]);
            goto vNQrs;
            N8PkT:
            if (!$XJsul instanceof ModelNotFoundException) {
                goto xww3o;
            }
            goto iBBa4;
            vNQrs:
        } finally {
            $SoVKt = microtime(true);
            $aV3nd = memory_get_usage();
            $PoneH = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $DWjir, 'execution_time_sec' => $SoVKt - $oDOT6, 'memory_usage_mb' => ($aV3nd - $eRyKR) / 1024 / 1024, 'peak_memory_usage_mb' => ($PoneH - $nmnvM) / 1024 / 1024]);
        }
        goto JxMbe;
        CwHSA:
        $eRyKR = memory_get_usage();
        goto Y6PI9;
        JxMbe:
    }
    private function mOUfu5bjhqh($C_gXz, $gDswH) : void
    {
        goto GLU0O;
        WXmLv:
        $this->ZPzJH->put($Rv0JB, $this->bLZP5->get($Rv0JB));
        goto Aj1a2;
        zczhc:
        $BO1eQ = new LFbK8cyK0wiWn($this->B3G_O, $this->loW7J, $this->bLZP5, $this->ZPzJH);
        goto nlDQm;
        Aj1a2:
        $qY3RI = $this->lT6tT->call($this, $this->ZPzJH->path($Rv0JB));
        goto To9oN;
        To9oN:
        $C_gXz->place($qY3RI, 'top-left', 0, 0, 30);
        goto z3QrI;
        nlDQm:
        $Rv0JB = $BO1eQ->mjt3bIAGpxP($ASgWt, $ybj1g, $gDswH, true);
        goto WXmLv;
        soWna:
        $ybj1g = $C_gXz->height();
        goto zczhc;
        GLU0O:
        $ASgWt = $C_gXz->width();
        goto soWna;
        z3QrI:
    }
}
