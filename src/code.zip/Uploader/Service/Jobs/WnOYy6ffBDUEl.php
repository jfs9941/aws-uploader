<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class WnOYy6ffBDUEl implements CompressJobInterface
{
    const g0Utg = 60;
    private $wil31;
    private $MuT3J;
    private $UIHwe;
    public function __construct($jwYYV, $tBTgN, $W_qUx)
    {
        goto lPJHK;
        orXdM:
        $this->MuT3J = $tBTgN;
        goto EuN7T;
        lPJHK:
        $this->wil31 = $jwYYV;
        goto QDxpU;
        QDxpU:
        $this->UIHwe = $W_qUx;
        goto orXdM;
        EuN7T:
    }
    public function compress(string $uuHkQ)
    {
        goto jvI2b;
        jvI2b:
        $AzkxT = microtime(true);
        goto EaqV3;
        C2wJe:
        try {
            goto tCqZi;
            D2s3X:
            if (!(strtolower($tCWWG->getExtension()) === 'png' || strtolower($tCWWG->getExtension()) === 'heic')) {
                goto xlIUY;
            }
            goto nVy7H;
            cORFA:
            try {
                goto ts7rm;
                rYkj_:
                $this->mQAT5wQEIj9($tCWWG, 'webp');
                goto PRe2k;
                r7nSO:
                $this->mlxW4Sd0nnI($r8JSN, $j30HD);
                goto rYkj_;
                ts7rm:
                $j30HD = $this->MuT3J->path(str_replace('.jpg', '.webp', $tCWWG->getLocation()));
                goto r7nSO;
                PRe2k:
            } catch (\Exception $bhoVz) {
                goto YRK5g;
                YRK5g:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $uuHkQ, 'error' => $bhoVz->getMessage()]);
                goto h48vR;
                OVGRD:
                $this->mfKIXYoTXFu($r8JSN, $j30HD);
                goto mgFZ5;
                h48vR:
                $j30HD = $this->MuT3J->path($tCWWG->getLocation());
                goto OVGRD;
                mgFZ5:
            }
            goto oxyIu;
            tCqZi:
            $tCWWG = QFoN7Ibbm93if::findOrFail($uuHkQ);
            goto TAmk1;
            nVy7H:
            $tCWWG = $this->mQAT5wQEIj9($tCWWG, 'jpg');
            goto nXeC7;
            TAmk1:
            $r8JSN = $this->MuT3J->path($tCWWG->getLocation());
            goto D2s3X;
            nXeC7:
            xlIUY:
            goto cORFA;
            oxyIu:
        } catch (\Throwable $bhoVz) {
            goto Wyb3X;
            Wyb3X:
            if (!$bhoVz instanceof ModelNotFoundException) {
                goto RIgZ7;
            }
            goto spUCd;
            JwqBA:
            Log::error("Failed to compress image", ['imageId' => $uuHkQ, 'error' => $bhoVz->getMessage()]);
            goto vmkv_;
            OUvxF:
            RIgZ7:
            goto JwqBA;
            spUCd:
            Log::info("QFoN7Ibbm93if has been deleted, discard it", ['imageId' => $uuHkQ]);
            goto Ad5Nt;
            Ad5Nt:
            return;
            goto OUvxF;
            vmkv_:
        } finally {
            $aNu_H = microtime(true);
            $RzZdv = memory_get_usage();
            $cUIGa = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $uuHkQ, 'execution_time_sec' => $aNu_H - $AzkxT, 'memory_usage_mb' => ($RzZdv - $f24Pb) / 1024 / 1024, 'peak_memory_usage_mb' => ($cUIGa - $QzVyt) / 1024 / 1024]);
        }
        goto dXr72;
        UcX7V:
        Log::info("Compress image", ['imageId' => $uuHkQ]);
        goto C2wJe;
        EaqV3:
        $f24Pb = memory_get_usage();
        goto bgThH;
        bgThH:
        $QzVyt = memory_get_peak_usage();
        goto UcX7V;
        dXr72:
    }
    private function mfKIXYoTXFu($r8JSN, $j30HD)
    {
        goto IaJmC;
        IaJmC:
        $fFLHV = $this->wil31->call($this, $r8JSN);
        goto Y2MPE;
        mdVjD:
        unset($fFLHV);
        goto EnINi;
        Y2MPE:
        $fFLHV->orient()->toJpeg(self::g0Utg)->save($j30HD);
        goto v2Ktz;
        v2Ktz:
        $this->UIHwe->put($j30HD, $fFLHV->toJpeg(self::g0Utg), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto mdVjD;
        EnINi:
    }
    private function mlxW4Sd0nnI($r8JSN, $j30HD)
    {
        goto z12_Y;
        QpQHz:
        $fFLHV->orient()->toWebp(self::g0Utg);
        goto r7jAZ;
        r7jAZ:
        $this->UIHwe->put($j30HD, $fFLHV->toJpeg(self::g0Utg), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto dr4MR;
        dr4MR:
        unset($fFLHV);
        goto ZEnW8;
        z12_Y:
        $fFLHV = $this->wil31->call($this, $r8JSN);
        goto QpQHz;
        ZEnW8:
    }
    private function mQAT5wQEIj9($tCWWG, $kxk8f)
    {
        goto ld133;
        ao3rE:
        $tCWWG->save();
        goto LAHHa;
        LAHHa:
        return $tCWWG;
        goto Lf0IU;
        sLdlq:
        $tCWWG->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$kxk8f}", $tCWWG->getLocation()));
        goto ao3rE;
        ld133:
        $tCWWG->setAttribute('type', $kxk8f);
        goto sLdlq;
        Lf0IU:
    }
}
