<?php

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Encoder\CaptureThumbnail;
use Jfs\Uploader\Encoder\HlsOutput;
use Jfs\Uploader\Encoder\HlsPathResolver;
use Jfs\Uploader\Encoder\Input;
use Jfs\Uploader\Encoder\MediaConverterBuilder;
use Jfs\Uploader\Encoder\Watermark;
use Jfs\Uploader\Enum\FileDriver;
use Jfs\Uploader\Service\MediaPathResolver;
use Webmozart\Assert\Assert;

class VideoEncodeJob implements MediaEncodeJobInterface
{
    private $bucket;
    /**
     * @var Filesystem
     */
    private $localStorage;
    private $s3;
    private $canvas;
    private $watermarkFont;
    public function __construct(string $bucket, $localStorage, $s3, $canvas, $watermarkFont)
    {
        $this->bucket = $bucket;
        $this->localStorage = $localStorage;
        $this->s3 = $s3;
        $this->canvas = $canvas;
        $this->watermarkFont = $watermarkFont;
    }


    public function encode(string $id, string $username, $forceCheckAccelerate = true): void
    {
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $id]);
        ini_set('memory_limit', '-1');
        /** @var Video $video */
        try {
            $video = Video::findOrFail($id);
            Assert::isInstanceOf($video, Video::class);
            if ($video->driver !== FileDriver::S3) {
                throw new MediaConverterException("Video {$video->id} is not S3 driver");
            }
            $width = $video->width();
            $height = $video->height();

            $videoUri = $this->resolve($video);
            Log::info("Set input video for Job", [
                's3Uri' => $videoUri,
            ]);
            $builder = app(MediaConverterBuilder::class);
            $builder = $builder->input(new Input($videoUri));

            $originalOutput = new HlsOutput(
                'original', $width, $height, $video->fps ?? 30
            );
            $hlsPathResolver = app(HlsPathResolver::class);

            $builder->addOutput($originalOutput);
            $builder->setDestination($hlsPathResolver->resolveHlsPath($video));
            $resolver = app(MediaPathResolver::class);
            $watermarkFactory = new WatermarkFactory(
                $this->canvas,
                $this->watermarkFont,
                $this->s3,
                $this->localStorage
            );
            $watermarkObject = $this->getWatermarkObject($resolver, $watermarkFactory->factoryWatermark($video->width(), $video->height(), $username));
            if ($watermarkObject) {
                $originalOutput = $originalOutput->setWatermark($watermarkObject);
            }
            $builder->addOutput($originalOutput);
            $builder->setDestination($hlsPathResolver->resolveHlsPath($video));


            if ($width && $height) {
                if ($this->shouldGenerateLowerRes($width, $height)) {
                    $fHdResolution = $this->calculate1080pResolution($width, $height);
                    Log::info("Set 1080p resolution for Job", [
                        'width' => $fHdResolution['width'],
                        'height' => $fHdResolution['height'],
                        'originalWidth' => $width,
                        'originalHeight' => $height,
                    ]);
                    $fHdOutput = new HlsOutput(
                        '1080p', $fHdResolution['width'], $fHdResolution['height'], $video->fps ?? 30
                    );

                    $watermarkObject = $this->getWatermarkObject($resolver,
                        $watermarkFactory->factoryWatermark((int) $fHdResolution['width'], (int) $fHdResolution['height'], $username));
                    if ($watermarkObject) {
                        $fHdOutput = $fHdOutput->setWatermark($watermarkObject);
                    }
                    $builder = $builder->addOutput($fHdOutput);
                }
            }

            Log::info("Set thumbnail for Video Job",[
                'videoId' => $video->getAttribute('id'),
                'duration' => $video->getAttribute('duration')
            ]);

            $thumbnail = new CaptureThumbnail(
                $video->duration ?? 1,
                2,
                $hlsPathResolver->resolveThumbnailPath($video),
            );
            $builder = $builder->thumbnail($thumbnail);
            $id = $builder->run($this->shouldAccelerate($video, $forceCheckAccelerate));
            $video->update(['aws_media_converter_job_id' => $id]);
        } catch (\Exception $exception) {
            Log::info("Video has been deleted, discard it", ['fileId' => $id, 'err' => $exception->getMessage()]);
            return;
        }
    }

    /**
     * return true if video > 1080p and > 15 min or > 5 min and 4k
     * @param Video $video
     * @return bool
     */
    private function shouldAccelerate(Video $video, $forceCheckAccelerate): bool
    {
        if (!$forceCheckAccelerate) {
            return false;
        }
        $duration = (int) round($video->getAttribute('duration') ?? 0);
        switch (true) {
            case $video->width() * $video->height() >= (1920 * 1080) && $video->width() * $video->height() < (2560 * 1440):
                return $duration > 10 * 60;
            case $video->width() * $video->height() >= (2560 * 1440) && $video->width() * $video->height() < (3840 * 2160):
                return $duration > 5 * 60;
            case $video->width() * $video->height() >= (3840 * 2160):
                return $duration > 3 * 60;
            default:
                return false;
        }
    }

    private function getWatermarkObject(MediaPathResolver $resolver, string $url): ?Watermark
    {
        $watermarkS3Uri = $resolver->resolveForUrl($url);
        Log::info("Resolve watermark for job with url", ['url' => $url, 'uri'=> $watermarkS3Uri]);
        if ($watermarkS3Uri) {
            return new Watermark(
                $watermarkS3Uri,
                0,
                0,
                null,
                null,
            );
        }

        return null;
    }

    private function shouldGenerateLowerRes(int $width, int $height): bool
    {
        return $width * $height > 1.5 * (1920 * 1080);
    }

    private function calculate1080pResolution(int $width, int $height): array
    {
        $calculator = new ScaleDownCalculator($width, $height);

        return $calculator->scaleTo1080p();
    }

    private function resolve(BaseFileModel $fileModel): string {
        if ($fileModel->driver == FileDriver::S3) {
            return 's3://' . $this->bucket . '/' . $fileModel->filename;
        }

        return $this->localStorage->url($fileModel->filename);
    }
}
