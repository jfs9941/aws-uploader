<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Illuminate\Support\Facades\Log;
class YfUoFIujAyQF1 implements StoreVideoToS3JobInterface
{
    private $KIeS3;
    private $aiw3M;
    private $n8EBo;
    public function __construct($C1Y4p, $iay5S, $gdQ3g)
    {
        goto r60CT;
        RtZoP:
        $this->KIeS3 = $C1Y4p;
        goto taRoL;
        MSZzK:
        $this->n8EBo = $gdQ3g;
        goto RtZoP;
        r60CT:
        $this->aiw3M = $iay5S;
        goto MSZzK;
        taRoL:
    }
    public function store(string $zV1kl) : void
    {
        goto j1W7k;
        fRzB9:
        $g2Th1 = memory_get_peak_usage();
        goto sdH1d;
        sdH1d:
        try {
            goto du866;
            m6iHa:
            $R3nTL = [];
            goto Zd9g4;
            xHY40:
            yTKIO:
            goto f4st1;
            f4st1:
            fclose($HS88N);
            goto f9v16;
            du866:
            $NQsDq = $HuCIz->createMultipartUpload(['Bucket' => $this->KIeS3, 'Key' => $BGAtM->getLocation(), 'ContentType' => $BmwLx, 'ContentDisposition' => 'inline']);
            goto Ip2DP;
            uY1Ku:
            $t3XvK = $HuCIz->uploadPart(['Bucket' => $this->KIeS3, 'Key' => $BGAtM->getLocation(), 'UploadId' => $PCQqS, 'PartNumber' => $gdvpI, 'Body' => fread($HS88N, $FCa9B)]);
            goto f6S2t;
            g0MEt:
            if (feof($HS88N)) {
                goto yTKIO;
            }
            goto uY1Ku;
            Ip2DP:
            $PCQqS = $NQsDq['UploadId'];
            goto S5DsE;
            Qh8OM:
            $gdvpI++;
            goto IRxr1;
            S5DsE:
            $gdvpI = 1;
            goto m6iHa;
            Zd9g4:
            IOu90:
            goto g0MEt;
            sji0y:
            $BGAtM->update(['driver' => X4ZiOQdPeeHKI::S3]);
            goto nSQRu;
            nSQRu:
            $gdQ3g->delete($BGAtM->getLocation());
            goto pqmLs;
            IRxr1:
            goto IOu90;
            goto xHY40;
            f9v16:
            $HuCIz->completeMultipartUpload(['Bucket' => $this->KIeS3, 'Key' => $BGAtM->getLocation(), 'UploadId' => $PCQqS, 'MultipartUpload' => ['Parts' => $R3nTL]]);
            goto sji0y;
            f6S2t:
            $R3nTL[] = ['PartNumber' => $gdvpI, 'ETag' => $t3XvK['ETag']];
            goto Qh8OM;
            pqmLs:
        } catch (AwsException $nV19i) {
            goto mEGzy;
            pkQsz:
            Vu1Bq:
            goto vuyUT;
            C3ktR:
            try {
                $HuCIz->abortMultipartUpload(['Bucket' => $this->KIeS3, 'Key' => $BGAtM->getLocation(), 'UploadId' => $PCQqS]);
            } catch (AwsException $m6sz6) {
                Log::error('Error aborting multipart upload: ' . $m6sz6->getMessage());
            }
            goto pkQsz;
            vuyUT:
            Log::error('Failed to store video: ' . $BGAtM->getLocation() . ' - ' . $nV19i->getMessage());
            goto NVymF;
            mEGzy:
            if (!isset($PCQqS)) {
                goto Vu1Bq;
            }
            goto C3ktR;
            NVymF:
        } finally {
            $lmBz1 = microtime(true);
            $ZinuS = memory_get_usage();
            $NcQYU = memory_get_peak_usage();
            Log::info('Store UYo98bF5lKEmO to S3 function resource usage', ['imageId' => $zV1kl, 'execution_time_sec' => $lmBz1 - $u7QUO, 'memory_usage_mb' => ($ZinuS - $TkLmp) / 1024 / 1024, 'peak_memory_usage_mb' => ($NcQYU - $g2Th1) / 1024 / 1024]);
        }
        goto NdN2F;
        E3x73:
        $BmwLx = $gdQ3g->mimeType($BGAtM->getLocation());
        goto LzwIM;
        cLOFy:
        $FCa9B = 1024 * 1024 * 50;
        goto E3x73;
        meW9r:
        sBaY3:
        goto BY18r;
        LqPBw:
        ycTMm:
        goto YENO0;
        hSxv_:
        return;
        goto LqPBw;
        YENO0:
        $HS88N = $gdQ3g->readStream($BGAtM->getLocation());
        goto cLOFy;
        UTHOt:
        return;
        goto meW9r;
        Cr_rs:
        $HuCIz = $this->aiw3M->getClient();
        goto sYKHD;
        DOq8N:
        $TkLmp = memory_get_usage();
        goto fRzB9;
        Yj07j:
        if ($BGAtM) {
            goto sBaY3;
        }
        goto VoW13;
        LzwIM:
        $u7QUO = microtime(true);
        goto DOq8N;
        Qg5uH:
        $BGAtM = UYo98bF5lKEmO::find($zV1kl);
        goto Yj07j;
        sYKHD:
        $gdQ3g = $this->n8EBo;
        goto Qg5uH;
        BY18r:
        if ($gdQ3g->exists($BGAtM->getLocation())) {
            goto ycTMm;
        }
        goto dc5Ph;
        dc5Ph:
        Log::error("[YfUoFIujAyQF1] File not found, discard it ", ['video' => $BGAtM->getLocation()]);
        goto hSxv_;
        VoW13:
        Log::info("UYo98bF5lKEmO has been deleted in database or not inserted yet, discard it", ['fileId' => $zV1kl]);
        goto UTHOt;
        Hy0jf:
        ini_set('memory_limit', '-1');
        goto Cr_rs;
        j1W7k:
        Log::info('Storing video (local) to S3', ['fileId' => $zV1kl, 'bucketName' => $this->KIeS3]);
        goto Hy0jf;
        NdN2F:
    }
}
