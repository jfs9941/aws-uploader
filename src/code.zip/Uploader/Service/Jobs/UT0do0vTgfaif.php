<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
class UT0do0vTgfaif implements CompressJobInterface
{
    const KjBht = 80;
    private $RFvhw;
    private $HyJkj;
    public function __construct($LDEwd, $N7YvB)
    {
        $this->RFvhw = $LDEwd;
        $this->HyJkj = $N7YvB;
    }
    public function compress(string $Qu08p)
    {
        Log::info("Compress image", ['imageId' => $Qu08p]);
        try {
            goto QH2Yq;
            Ael1w:
            $fe3pc->setAttribute('type', 'jpg');
            goto rbrQG;
            XN2Ik:
            $fe3pc->save();
            goto OBZ28;
            V69A4:
            $es2NA->destroy();
            goto kYuSe;
            rbrQG:
            $fe3pc->setAttribute('filename', str_replace('.png', '.jpg', $fe3pc->getLocation()));
            goto XN2Ik;
            YtgOA:
            $es2NA = $this->RFvhw->call($this, $bD2AK);
            goto oAZ_1;
            Z5QDc:
            $es2NA->save($exisr, self::KjBht);
            goto V69A4;
            S_DyP:
            if (!($fe3pc->getExtension() === 'png')) {
                goto Ux8Qv;
            }
            goto Ael1w;
            oAZ_1:
            $es2NA->orientate();
            goto Z5QDc;
            CGGWX:
            $exisr = $this->HyJkj->path($fe3pc->getLocation());
            goto YtgOA;
            QH2Yq:
            $fe3pc = YPgQPiPQjMu1g::findOrFail($Qu08p);
            goto sw74m;
            sw74m:
            $bD2AK = $this->HyJkj->path($fe3pc->getLocation());
            goto S_DyP;
            OBZ28:
            Ux8Qv:
            goto CGGWX;
            kYuSe:
        } catch (ModelNotFoundException) {
            Log::info("YPgQPiPQjMu1g has been deleted, discard it", ['imageId' => $Qu08p]);
        }
    }
}
