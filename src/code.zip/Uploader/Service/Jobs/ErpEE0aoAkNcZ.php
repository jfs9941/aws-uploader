<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class ErpEE0aoAkNcZ implements StoreVideoToS3JobInterface
{
    private $xxKd3;
    private $W_Kti;
    private $kxBLk;
    public function __construct($A745z, $agzKA, $dgfeu)
    {
        goto Y0li0;
        Xlmu_:
        $this->kxBLk = $dgfeu;
        goto vKTIj;
        vKTIj:
        $this->xxKd3 = $A745z;
        goto uFcFt;
        Y0li0:
        $this->W_Kti = $agzKA;
        goto Xlmu_;
        uFcFt:
    }
    public function store(string $y06DH) : void
    {
        goto pkEIe;
        bF5on:
        try {
            goto fhWyd;
            nT0HW:
            $D5Xs0 = $nC_XV->uploadPart(['Bucket' => $this->xxKd3, 'Key' => $ipAzM->getLocation(), 'UploadId' => $dXkPO, 'PartNumber' => $ecpwQ, 'Body' => fread($EiGNG, $Z1Mv0)]);
            goto hHVa_;
            Xgese:
            orwbf:
            goto UKX2i;
            lSUHV:
            $ipAzM->update(['driver' => WG4kCv0INtCV4::S3, 'status' => RwOJkCXwa9RQz::FINISHED]);
            goto TiONW;
            VkPSJ:
            $ecpwQ++;
            goto kPB1G;
            R50re:
            $nC_XV->completeMultipartUpload(['Bucket' => $this->xxKd3, 'Key' => $ipAzM->getLocation(), 'UploadId' => $dXkPO, 'MultipartUpload' => ['Parts' => $tFMn9]]);
            goto lSUHV;
            fhWyd:
            $gy2ea = $nC_XV->createMultipartUpload(['Bucket' => $this->xxKd3, 'Key' => $ipAzM->getLocation(), 'ContentType' => $iXTaP, 'ContentDisposition' => 'inline']);
            goto fUG5b;
            MsPjP:
            $tFMn9 = [];
            goto Xgese;
            vwgyQ:
            fclose($EiGNG);
            goto R50re;
            kPB1G:
            goto orwbf;
            goto ObAF0;
            UKX2i:
            if (feof($EiGNG)) {
                goto U1DEd;
            }
            goto nT0HW;
            RidbG:
            $ecpwQ = 1;
            goto MsPjP;
            fUG5b:
            $dXkPO = $gy2ea['UploadId'];
            goto RidbG;
            ObAF0:
            U1DEd:
            goto vwgyQ;
            hHVa_:
            $tFMn9[] = ['PartNumber' => $ecpwQ, 'ETag' => $D5Xs0['ETag']];
            goto VkPSJ;
            TiONW:
            $dgfeu->delete($ipAzM->getLocation());
            goto Ium4j;
            Ium4j:
        } catch (AwsException $rq1wj) {
            goto lEwVo;
            pT4r2:
            try {
                $nC_XV->abortMultipartUpload(['Bucket' => $this->xxKd3, 'Key' => $ipAzM->getLocation(), 'UploadId' => $dXkPO]);
            } catch (AwsException $NQzwj) {
                Log::error('Error aborting multipart upload: ' . $NQzwj->getMessage());
            }
            goto tHY3w;
            lEwVo:
            if (!isset($dXkPO)) {
                goto TPJFd;
            }
            goto pT4r2;
            tHY3w:
            TPJFd:
            goto j_AyN;
            j_AyN:
            Log::error('Failed to store video: ' . $ipAzM->getLocation() . ' - ' . $rq1wj->getMessage());
            goto HIBY3;
            HIBY3:
        }
        goto QJG8q;
        uSVTr:
        QxN_h:
        goto BLyVp;
        GcIyS:
        $iXTaP = $dgfeu->mimeType($ipAzM->getLocation());
        goto bF5on;
        X2ab7:
        $Z1Mv0 = 1024 * 1024 * 50;
        goto GcIyS;
        R1xPi:
        $dgfeu = $this->kxBLk;
        goto zmOfE;
        Bzmdv:
        return;
        goto uSVTr;
        u93Ks:
        SZ4P3:
        goto Elj3N;
        Nxdly:
        ini_set('memory_limit', '-1');
        goto pkKWG;
        BLyVp:
        $EiGNG = $dgfeu->readStream($ipAzM->getLocation());
        goto X2ab7;
        zmOfE:
        $ipAzM = GXtnGiMmIPEIc::find($y06DH);
        goto WQIBk;
        Elj3N:
        if ($dgfeu->exists($ipAzM->getLocation())) {
            goto QxN_h;
        }
        goto m6_Ct;
        n8bSo:
        return;
        goto u93Ks;
        nEjjr:
        Log::info("GXtnGiMmIPEIc has been deleted, discard it", ['fileId' => $y06DH]);
        goto n8bSo;
        pkEIe:
        Log::info('Storing video (local) to S3', ['fileId' => $y06DH, 'bucketName' => $this->xxKd3]);
        goto Nxdly;
        m6_Ct:
        Log::error("[ErpEE0aoAkNcZ] File not found, discard it ", ['video' => $ipAzM->getLocation()]);
        goto Bzmdv;
        WQIBk:
        if ($ipAzM) {
            goto SZ4P3;
        }
        goto nEjjr;
        pkKWG:
        $nC_XV = $this->W_Kti->getClient();
        goto R1xPi;
        QJG8q:
    }
}
