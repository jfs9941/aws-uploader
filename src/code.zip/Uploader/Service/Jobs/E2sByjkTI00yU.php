<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
class E2sByjkTI00yU implements BlurVideoJobInterface
{
    const zhNzV = 15;
    const DJPIp = 500;
    const adkDy = 500;
    private $IfECA;
    private $zTo0t;
    private $uBhrQ;
    public function __construct($AaIEl, $Vi8xq, $Ms6sq)
    {
        goto eyXGh;
        OF2wf:
        $this->IfECA = $AaIEl;
        goto px5oJ;
        DAMhg:
        $this->zTo0t = $Vi8xq;
        goto OF2wf;
        eyXGh:
        $this->uBhrQ = $Ms6sq;
        goto DAMhg;
        px5oJ:
    }
    public function blur(string $S6xyJ) : void
    {
        goto yfvzF;
        VKwz0:
        CqM3I:
        goto jIGfl;
        OVTHe:
        $iy9bs->destroy();
        goto CINd9;
        iAyJC:
        $Xb5Jr = $iy9bs->width() / $iy9bs->height();
        goto wmoFR;
        jVx0U:
        $this->uBhrQ->put($kyFKc->getAttribute('thumbnail'), $this->zTo0t->get($kyFKc->getAttribute('thumbnail')));
        goto p1x9y;
        qkPE_:
        XjFpf:
        goto ELZfl;
        upikB:
        $iy9bs->save($y9ek3);
        goto yn5Kb;
        yfvzF:
        Log::info("Blurring for video", ['videoID' => $S6xyJ]);
        goto tlWlz;
        tlWlz:
        ini_set('memory_limit', '-1');
        goto md_7v;
        CW_tA:
        if (!$kyFKc->getAttribute('thumbnail')) {
            goto CqM3I;
        }
        goto jVx0U;
        p1x9y:
        $iy9bs = $this->IfECA->call($this, $this->uBhrQ->path($kyFKc->getAttribute('thumbnail')));
        goto iAyJC;
        ELZfl:
        $kyFKc->update(['preview' => $NzFkF]);
        goto VKwz0;
        qjLYh:
        throw new \Exception('Failed to set final permissions on image file: ' . $y9ek3);
        goto qkPE_;
        yn5Kb:
        $this->zTo0t->put($NzFkF, $this->uBhrQ->get($NzFkF));
        goto OVTHe;
        qtZCw:
        $iy9bs->blur(self::zhNzV);
        goto lCCwg;
        md_7v:
        $kyFKc = Kt6NO3eUvdER6::findOrFail($S6xyJ);
        goto CW_tA;
        CINd9:
        if (chmod($y9ek3, 0664)) {
            goto XjFpf;
        }
        goto HqX3K;
        lCCwg:
        $NzFkF = $this->mnofwe5vgIs($kyFKc);
        goto Ro518;
        Ro518:
        $y9ek3 = $this->uBhrQ->path($NzFkF);
        goto upikB;
        wmoFR:
        $iy9bs->resize(self::DJPIp, self::adkDy / $Xb5Jr);
        goto qtZCw;
        HqX3K:
        \Log::warning('Failed to set final permissions on image file: ' . $y9ek3);
        goto qjLYh;
        jIGfl:
    }
    private function mnofwe5vgIs(A9R6iJFlMGSBV $ECCgN) : string
    {
        goto Xs2eG;
        g4f3h:
        if ($this->uBhrQ->exists($sSGQz)) {
            goto K8nR3;
        }
        goto khul9;
        nrYh9:
        $sSGQz = dirname($z69yI) . '/preview/';
        goto g4f3h;
        Xs2eG:
        $z69yI = $ECCgN->getLocation();
        goto nrYh9;
        khul9:
        $this->uBhrQ->makeDirectory($sSGQz, 0755, true);
        goto Dix8e;
        BRvub:
        return $sSGQz . $ECCgN->getFilename() . '.jpg';
        goto igDIE;
        Dix8e:
        K8nR3:
        goto BRvub;
        igDIE:
    }
}
