<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class EeuBwwbhTRlwB implements GenerateThumbnailJobInterface
{
    const kqQEI = 150;
    const f9Oze = 150;
    private $vn9CJ;
    private $n8EBo;
    private $S2Lqz;
    public function __construct($HL7fw, $gdQ3g, $Uryi7)
    {
        goto fke1p;
        pLT0R:
        $this->n8EBo = $gdQ3g;
        goto QeLbE;
        fke1p:
        $this->vn9CJ = $HL7fw;
        goto pLT0R;
        QeLbE:
        $this->S2Lqz = $Uryi7;
        goto g4Z5H;
        g4Z5H:
    }
    public function generate(string $zV1kl)
    {
        goto lnW4Q;
        Yl4UT:
        ini_set('memory_limit', '-1');
        goto vR7kt;
        lnW4Q:
        Log::info("Generating thumbnail", ['imageId' => $zV1kl]);
        goto Yl4UT;
        vR7kt:
        try {
            goto m7BLQ;
            GRrSU:
            $RD3vr = KCmQR4pvm0dT3::findOrFail($zV1kl);
            goto dqMJE;
            Yia8d:
            unset($cKykl);
            goto i3_Vq;
            TovXT:
            M5qnS:
            goto QxPqi;
            dqMJE:
            $cKykl = $this->vn9CJ->call($this, $zDbHT->path($RD3vr->getLocation()));
            goto XjAtM;
            i3_Vq:
            if (!($sWnia !== false)) {
                goto M5qnS;
            }
            goto Py_av;
            m7BLQ:
            $zDbHT = $this->n8EBo;
            goto GRrSU;
            Z1HTR:
            $sWnia = $this->S2Lqz->put($lmTDq, $cKykl->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto Yia8d;
            HkwTp:
            $lmTDq = $this->mKx2eItiSBx($RD3vr);
            goto Z1HTR;
            Py_av:
            $RD3vr->update(['thumbnail' => $lmTDq, 'status' => M7O7NSiJU2JG5::THUMBNAIL_PROCESSED]);
            goto TovXT;
            XjAtM:
            $cKykl->orient()->resize(150, 150);
            goto HkwTp;
            QxPqi:
        } catch (ModelNotFoundException $nV19i) {
            Log::info("KCmQR4pvm0dT3 has been deleted, discard it", ['imageId' => $zV1kl]);
            return;
        } catch (\Exception $nV19i) {
            Log::error("Failed to generate thumbnail", ['imageId' => $zV1kl, 'error' => $nV19i->getMessage()]);
        }
        goto H0gBF;
        H0gBF:
    }
    private function mKx2eItiSBx(AtQh9cRLX7xL8 $RD3vr) : string
    {
        goto Fo2iY;
        fc87f:
        return $IzmSu . '/' . $RD3vr->getFilename() . '.jpg';
        goto D9TuA;
        shp4S:
        $IzmSu = $JRpFR . '/' . self::kqQEI . 'X' . self::f9Oze;
        goto fc87f;
        Fo2iY:
        $lmTDq = $RD3vr->getLocation();
        goto ThGAU;
        ThGAU:
        $JRpFR = dirname($lmTDq);
        goto shp4S;
        D9TuA:
    }
}
