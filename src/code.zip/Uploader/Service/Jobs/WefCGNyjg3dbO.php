<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Illuminate\Support\Facades\Log;
class WefCGNyjg3dbO implements StoreVideoToS3JobInterface
{
    private $Q0X7B;
    private $wEVdN;
    private $A8xPF;
    public function __construct($drKb4, $dzspH, $ZT237)
    {
        goto FmTGr;
        FmTGr:
        $this->wEVdN = $dzspH;
        goto z8jaa;
        clSn7:
        $this->Q0X7B = $drKb4;
        goto j6dkh;
        z8jaa:
        $this->A8xPF = $ZT237;
        goto clSn7;
        j6dkh:
    }
    public function store(string $hOWbX) : void
    {
        goto CXTpm;
        sQV2q:
        $wkaBP = memory_get_peak_usage();
        goto GrE2T;
        cDe1Y:
        ini_set('memory_limit', '-1');
        goto w9FHD;
        KN7VR:
        if ($Pr05u) {
            goto eN5Ln;
        }
        goto rOeS0;
        rOeS0:
        Log::info("HS7SZ3rYPI80t has been deleted in database or not inserted yet, discard it", ['fileId' => $hOWbX]);
        goto aO8iy;
        YXTRr:
        $ZT237 = $this->A8xPF;
        goto mz40p;
        EECdf:
        fAF7K:
        goto OVoqx;
        vr91q:
        $Uz2J3 = 1024 * 1024 * 50;
        goto QcgIt;
        Bes_O:
        return;
        goto EECdf;
        CXTpm:
        Log::info('Storing video (local) to S3', ['fileId' => $hOWbX, 'bucketName' => $this->Q0X7B]);
        goto cDe1Y;
        mz40p:
        $Pr05u = HS7SZ3rYPI80t::find($hOWbX);
        goto KN7VR;
        QcgIt:
        $Hnn2Z = $ZT237->mimeType($Pr05u->getLocation());
        goto clWB6;
        clWB6:
        $KyNi2 = microtime(true);
        goto G_W1a;
        aO8iy:
        return;
        goto okTSw;
        jNXOI:
        if ($ZT237->exists($Pr05u->getLocation())) {
            goto fAF7K;
        }
        goto DN21T;
        w9FHD:
        $NJDBD = $this->wEVdN->getClient();
        goto YXTRr;
        G_W1a:
        $W0709 = memory_get_usage();
        goto sQV2q;
        OVoqx:
        $cRnXQ = $ZT237->readStream($Pr05u->getLocation());
        goto vr91q;
        okTSw:
        eN5Ln:
        goto jNXOI;
        GrE2T:
        try {
            goto rsb1N;
            rXF63:
            fclose($cRnXQ);
            goto DFb3Z;
            xIG3o:
            $ZT237->delete($Pr05u->getLocation());
            goto Eiswo;
            aJ6Ev:
            $RsQzi = $bzyUS['UploadId'];
            goto mtaAD;
            mtaAD:
            $c63kn = 1;
            goto XBGMS;
            DFb3Z:
            $NJDBD->completeMultipartUpload(['Bucket' => $this->Q0X7B, 'Key' => $Pr05u->getLocation(), 'UploadId' => $RsQzi, 'MultipartUpload' => ['Parts' => $jOnpR]]);
            goto bGI2o;
            qPCYT:
            goto S8rVm;
            goto P_C18;
            GydBx:
            $c63kn++;
            goto qPCYT;
            rsb1N:
            $bzyUS = $NJDBD->createMultipartUpload(['Bucket' => $this->Q0X7B, 'Key' => $Pr05u->getLocation(), 'ContentType' => $Hnn2Z, 'ContentDisposition' => 'inline']);
            goto aJ6Ev;
            T43_i:
            if (feof($cRnXQ)) {
                goto CgdBv;
            }
            goto zV_Bm;
            XBGMS:
            $jOnpR = [];
            goto AvYwq;
            zV_Bm:
            $e0So9 = $NJDBD->uploadPart(['Bucket' => $this->Q0X7B, 'Key' => $Pr05u->getLocation(), 'UploadId' => $RsQzi, 'PartNumber' => $c63kn, 'Body' => fread($cRnXQ, $Uz2J3)]);
            goto o3T52;
            bGI2o:
            $Pr05u->update(['driver' => NZ0k4EM0XOGE7::S3]);
            goto xIG3o;
            o3T52:
            $jOnpR[] = ['PartNumber' => $c63kn, 'ETag' => $e0So9['ETag']];
            goto GydBx;
            AvYwq:
            S8rVm:
            goto T43_i;
            P_C18:
            CgdBv:
            goto rXF63;
            Eiswo:
        } catch (AwsException $aGVU4) {
            goto dwcQv;
            TNr0M:
            try {
                $NJDBD->abortMultipartUpload(['Bucket' => $this->Q0X7B, 'Key' => $Pr05u->getLocation(), 'UploadId' => $RsQzi]);
            } catch (AwsException $k7UBK) {
                Log::error('Error aborting multipart upload: ' . $k7UBK->getMessage());
            }
            goto RQ7jR;
            RQ7jR:
            m5KO4:
            goto VH0_2;
            VH0_2:
            Log::error('Failed to store video: ' . $Pr05u->getLocation() . ' - ' . $aGVU4->getMessage());
            goto GpXXc;
            dwcQv:
            if (!isset($RsQzi)) {
                goto m5KO4;
            }
            goto TNr0M;
            GpXXc:
        } finally {
            $qtKWj = microtime(true);
            $MDW5Q = memory_get_usage();
            $NFJ5h = memory_get_peak_usage();
            Log::info('Store HS7SZ3rYPI80t to S3 function resource usage', ['imageId' => $hOWbX, 'execution_time_sec' => $qtKWj - $KyNi2, 'memory_usage_mb' => ($MDW5Q - $W0709) / 1024 / 1024, 'peak_memory_usage_mb' => ($NFJ5h - $wkaBP) / 1024 / 1024]);
        }
        goto yEfuW;
        DN21T:
        Log::error("[WefCGNyjg3dbO] File not found, discard it ", ['video' => $Pr05u->getLocation()]);
        goto Bes_O;
        yEfuW:
    }
}
