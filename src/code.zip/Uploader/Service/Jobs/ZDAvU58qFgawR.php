<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
class ZDAvU58qFgawR implements CompressJobInterface
{
    const AsT71 = 80;
    private $KbvBQ;
    private $FFBPk;
    public function __construct($twxgF, $GHkBm)
    {
        $this->KbvBQ = $twxgF;
        $this->FFBPk = $GHkBm;
    }
    public function compress(string $UcmDx)
    {
        Log::info("Compress image", ['imageId' => $UcmDx]);
        try {
            goto MXKvc;
            gb5zx:
            if (!($IS6o1->getExtension() === 'png')) {
                goto xrwa2;
            }
            goto R5xWH;
            QAHxw:
            $yq22P = $this->KbvBQ->call($this, $bLWuX);
            goto xcyOb;
            hJFqB:
            $yq22P->save($XZH1z, self::AsT71);
            goto Ru6jE;
            nznap:
            $IS6o1->save();
            goto yZ3pb;
            R5xWH:
            $IS6o1->setAttribute('type', 'jpg');
            goto Ghqa9;
            yZ3pb:
            xrwa2:
            goto yFR9o;
            SZFKH:
            $bLWuX = $this->FFBPk->path($IS6o1->getLocation());
            goto gb5zx;
            yFR9o:
            $XZH1z = $this->FFBPk->path($IS6o1->getLocation());
            goto QAHxw;
            Ghqa9:
            $IS6o1->setAttribute('filename', str_replace('.png', '.jpg', $IS6o1->getLocation()));
            goto nznap;
            xcyOb:
            $yq22P->orientate();
            goto hJFqB;
            Ru6jE:
            $yq22P->destroy();
            goto u743Z;
            MXKvc:
            $IS6o1 = HSe6BNUpJTSwE::findOrFail($UcmDx);
            goto SZFKH;
            u743Z:
        } catch (ModelNotFoundException) {
            Log::info("HSe6BNUpJTSwE has been deleted, discard it", ['imageId' => $UcmDx]);
        }
    }
}
