<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Encoder\GoSZbz69l96g0;
use Jfs\Uploader\Encoder\XjTsbRWUA8NWj;
use Jfs\Uploader\Encoder\V6kCroy78Tmzg;
use Jfs\Uploader\Encoder\Zszzj02FlhdFv;
use Jfs\Uploader\Encoder\XDE8fToEPyv8f;
use Jfs\Uploader\Encoder\IaJdFtE5S3xOF;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Jfs\Uploader\Service\Jobs\LmEsLnOT0eZ0u;
use Jfs\Uploader\Service\Jobs\MFBwl1BTODZYU;
use Jfs\Uploader\Service\PzfoMEiZi5U2a;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class TTVnFdgrZz9G7 implements MediaEncodeJobInterface
{
    private $VtRCr;
    private $hhcR1;
    private $VoF9h;
    private $pUKMn;
    private $wyfwp;
    public function __construct(string $G2CsF, $nQYui, $BQ2l1, $BetpK, $KWnDr)
    {
        goto Vu9Jf;
        xyPNm:
        $this->VoF9h = $BQ2l1;
        goto rySHO;
        RYwPY:
        $this->wyfwp = $KWnDr;
        goto FDm2G;
        Acrvn:
        $this->hhcR1 = $nQYui;
        goto xyPNm;
        Vu9Jf:
        $this->VtRCr = $G2CsF;
        goto Acrvn;
        rySHO:
        $this->pUKMn = $BetpK;
        goto RYwPY;
        FDm2G:
    }
    public function encode(string $JTwN4, string $FkoJ6, $aB8uN = true) : void
    {
        goto L8jez;
        L8jez:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $JTwN4]);
        goto SihCb;
        SihCb:
        ini_set('memory_limit', '-1');
        goto BU9yZ;
        BU9yZ:
        try {
            goto SC3cg;
            VRzuc:
            $JTwN4 = $jeWVI->m2Dr2Z7hDNz($this->m09IkCVH8Vx($B4_PH, $aB8uN));
            goto ZImOM;
            ED7lK:
            throw new MediaConverterException("MbOYV1VlUGCys {$B4_PH->id} is not S3 driver");
            goto cgqTq;
            Vufz3:
            $Do91J = $this->mYeVDpuA6lx($B4_PH);
            goto aJrHd;
            wOdkn:
            Log::info("Set thumbnail for MbOYV1VlUGCys Job", ['videoId' => $B4_PH->getAttribute('id'), 'duration' => $B4_PH->getAttribute('duration')]);
            goto Ot6zC;
            SC3cg:
            $B4_PH = MbOYV1VlUGCys::findOrFail($JTwN4);
            goto mTyjV;
            RfG14:
            Log::info("Set 1080p resolution for Job", ['width' => $rc4Db['width'], 'height' => $rc4Db['height'], 'originalWidth' => $SAWrT, 'originalHeight' => $rnPww]);
            goto P40X2;
            yDwZW:
            LLL2n:
            goto XsqR3;
            B_3BC:
            $xR2oQ = app(V6kCroy78Tmzg::class);
            goto ytvp1;
            ZImOM:
            $B4_PH->update(['aws_media_converter_job_id' => $JTwN4]);
            goto gtT63;
            ntJ0u:
            $jeWVI = $jeWVI->mA1cbWe0yDn($fMTw4);
            goto VRzuc;
            p8Ics:
            if (!($SAWrT && $rnPww)) {
                goto hbJnu;
            }
            goto mPX4p;
            QUjE0:
            $rc4Db = $this->mh1mrEpgCjo($SAWrT, $rnPww);
            goto RfG14;
            Ot6zC:
            $fMTw4 = new GoSZbz69l96g0($B4_PH->A4T6t ?? 1, 2, $xR2oQ->mX37QX680ee($B4_PH));
            goto ntJ0u;
            mTyjV:
            Assert::isInstanceOf($B4_PH, MbOYV1VlUGCys::class);
            goto GYZU8;
            ytvp1:
            $jeWVI->mIhTmqYUxr5($pbRce);
            goto shvXF;
            eFoWz:
            if (!$Kiy2M) {
                goto LLL2n;
            }
            goto JxaDv;
            pqYJd:
            hbJnu:
            goto wOdkn;
            mPX4p:
            if (!$this->mQx7aEKf2fg($SAWrT, $rnPww)) {
                goto kdnl5;
            }
            goto QUjE0;
            itC5Q:
            $jeWVI = $jeWVI->mr6t1qpUP69(new Zszzj02FlhdFv($Do91J));
            goto mIrZH;
            aJrHd:
            Log::info("Set input video for Job", ['s3Uri' => $Do91J]);
            goto Q8ONe;
            tpgtK:
            $jeWVI = $jeWVI->mIhTmqYUxr5($s5c_9);
            goto QMJaS;
            GYZU8:
            if (!($B4_PH->avC90 !== A3VATad7gvqZU::S3)) {
                goto ZhXck;
            }
            goto ED7lK;
            obXqv:
            $rnPww = $B4_PH->height();
            goto Vufz3;
            P40X2:
            $s5c_9 = new XjTsbRWUA8NWj('1080p', $rc4Db['width'], $rc4Db['height'], $B4_PH->lLmvi ?? 30);
            goto nl8rX;
            shvXF:
            $jeWVI->mUUBqw4XOKO($xR2oQ->mZwvWoEs0EI($B4_PH));
            goto M3wbO;
            XsqR3:
            $jeWVI->mIhTmqYUxr5($pbRce);
            goto B3KIm;
            QMJaS:
            kdnl5:
            goto pqYJd;
            GXfZZ:
            $SAWrT = $B4_PH->width();
            goto obXqv;
            JxaDv:
            $pbRce = $pbRce->mkrKZ51cBEF($Kiy2M);
            goto yDwZW;
            M3wbO:
            $fkBVz = app(PzfoMEiZi5U2a::class);
            goto C60ze;
            h1Pd0:
            if (!$Kiy2M) {
                goto L8sIH;
            }
            goto qmlBJ;
            mIrZH:
            $pbRce = new XjTsbRWUA8NWj('original', $SAWrT, $rnPww, $B4_PH->lLmvi ?? 30);
            goto B_3BC;
            qmlBJ:
            $s5c_9 = $s5c_9->mkrKZ51cBEF($Kiy2M);
            goto n0qRI;
            cgqTq:
            ZhXck:
            goto GXfZZ;
            C60ze:
            $EeySv = new MFBwl1BTODZYU($this->pUKMn, $this->wyfwp, $this->VoF9h, $this->hhcR1);
            goto u29Ct;
            n0qRI:
            L8sIH:
            goto tpgtK;
            nl8rX:
            $Kiy2M = $this->mtKGdi9BZ8y($fkBVz, $EeySv->mvALyMgg8ca((int) $rc4Db['width'], (int) $rc4Db['height'], $FkoJ6));
            goto h1Pd0;
            Q8ONe:
            $jeWVI = app(XDE8fToEPyv8f::class);
            goto itC5Q;
            u29Ct:
            $Kiy2M = $this->mtKGdi9BZ8y($fkBVz, $EeySv->mvALyMgg8ca($B4_PH->width(), $B4_PH->height(), $FkoJ6));
            goto eFoWz;
            B3KIm:
            $jeWVI->mUUBqw4XOKO($xR2oQ->mZwvWoEs0EI($B4_PH));
            goto p8Ics;
            gtT63:
        } catch (\Exception $tfcsO) {
            Log::info("MbOYV1VlUGCys has been deleted, discard it", ['fileId' => $JTwN4, 'err' => $tfcsO->getMessage()]);
            return;
        }
        goto FAsL1;
        FAsL1:
    }
    private function m09IkCVH8Vx(MbOYV1VlUGCys $B4_PH, $aB8uN) : bool
    {
        goto hqVmt;
        th7KQ:
        k6LPe:
        goto mRH_c;
        d0vFH:
        nPFYJ:
        goto th7KQ;
        KVamo:
        x1VZI:
        goto at9d1;
        hqVmt:
        if ($aB8uN) {
            goto x1VZI;
        }
        goto OtNww;
        at9d1:
        $L0LJi = (int) round($B4_PH->getAttribute('duration') ?? 0);
        goto y1B8r;
        y1B8r:
        switch (true) {
            case $B4_PH->width() * $B4_PH->height() >= 1920 * 1080 && $B4_PH->width() * $B4_PH->height() < 2560 * 1440:
                return $L0LJi > 10 * 60;
            case $B4_PH->width() * $B4_PH->height() >= 2560 * 1440 && $B4_PH->width() * $B4_PH->height() < 3840 * 2160:
                return $L0LJi > 5 * 60;
            case $B4_PH->width() * $B4_PH->height() >= 3840 * 2160:
                return $L0LJi > 3 * 60;
            default:
                return false;
        }
        goto d0vFH;
        OtNww:
        return false;
        goto KVamo;
        mRH_c:
    }
    private function mtKGdi9BZ8y(PzfoMEiZi5U2a $fkBVz, string $AJp4R) : ?IaJdFtE5S3xOF
    {
        goto V2FEw;
        o62lZ:
        if (!$Rj_0x) {
            goto cw_1D;
        }
        goto sQHy3;
        NZzf9:
        return null;
        goto mUfvl;
        sQHy3:
        return new IaJdFtE5S3xOF($Rj_0x, 0, 0, null, null);
        goto IjmLi;
        IjmLi:
        cw_1D:
        goto NZzf9;
        oU0bq:
        Log::info("Resolve watermark for job with url", ['url' => $AJp4R, 'uri' => $Rj_0x]);
        goto o62lZ;
        V2FEw:
        $Rj_0x = $fkBVz->mBQrwMSIABF($AJp4R);
        goto oU0bq;
        mUfvl:
    }
    private function mQx7aEKf2fg(int $SAWrT, int $rnPww) : bool
    {
        return $SAWrT * $rnPww > 1.5 * (1920 * 1080);
    }
    private function mh1mrEpgCjo(int $SAWrT, int $rnPww) : array
    {
        $qlYFd = new LmEsLnOT0eZ0u($SAWrT, $rnPww);
        return $qlYFd->mPjnmT9a49a();
    }
    private function mYeVDpuA6lx(MEyH4ejCzSk64 $pkR_A) : string
    {
        goto X_u0_;
        v18JH:
        return $this->hhcR1->url($pkR_A->filename);
        goto oL8Lj;
        X_u0_:
        if (!($pkR_A->avC90 == A3VATad7gvqZU::S3)) {
            goto QFiko;
        }
        goto IwPh7;
        qIlPi:
        QFiko:
        goto v18JH;
        IwPh7:
        return 's3://' . $this->VtRCr . '/' . $pkR_A->filename;
        goto qIlPi;
        oL8Lj:
    }
}
