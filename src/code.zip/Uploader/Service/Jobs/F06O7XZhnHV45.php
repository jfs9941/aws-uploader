<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Illuminate\Support\Facades\Log;
class F06O7XZhnHV45 implements StoreVideoToS3JobInterface
{
    private $c0nhQ;
    private $cC_4U;
    private $jhnu6;
    public function __construct($Bnpg8, $s1UdZ, $vWOwZ)
    {
        goto Tn0L6;
        Tn0L6:
        $this->cC_4U = $s1UdZ;
        goto H0hx2;
        xf0Rv:
        $this->c0nhQ = $Bnpg8;
        goto iyoCc;
        H0hx2:
        $this->jhnu6 = $vWOwZ;
        goto xf0Rv;
        iyoCc:
    }
    public function store(string $q8q1b) : void
    {
        goto bRDAI;
        H9oxw:
        $uXTRB = O1jfuwJR340k5::find($q8q1b);
        goto n1xf3;
        b7AjW:
        $XnLxJ = memory_get_usage();
        goto NCIfb;
        n1xf3:
        if ($uXTRB) {
            goto mzi7B;
        }
        goto DjeMN;
        YXD8r:
        if ($vWOwZ->exists($uXTRB->getLocation())) {
            goto Da3nG;
        }
        goto Qi9l_;
        DjeMN:
        Log::info("O1jfuwJR340k5 has been deleted in database or not inserted yet, discard it", ['fileId' => $q8q1b]);
        goto iKjSr;
        pZdr4:
        $KLHLq = $vWOwZ->readStream($uXTRB->getLocation());
        goto A5Cyn;
        KIW46:
        mzi7B:
        goto YXD8r;
        LXdTZ:
        ini_set('memory_limit', '-1');
        goto CdJvc;
        Gk3xw:
        $tv3_r = microtime(true);
        goto b7AjW;
        uuIAi:
        $vWOwZ = $this->jhnu6;
        goto H9oxw;
        iKjSr:
        return;
        goto KIW46;
        w5VX8:
        try {
            goto b0LTP;
            vXi9w:
            $PcG1p = $KZQPV['UploadId'];
            goto JpdDB;
            zdEnc:
            $iU5rw = $AFq_H->uploadPart(['Bucket' => $this->c0nhQ, 'Key' => $uXTRB->getLocation(), 'UploadId' => $PcG1p, 'PartNumber' => $uZRL7, 'Body' => fread($KLHLq, $GzTiT)]);
            goto axQT5;
            ADbsh:
            $vWOwZ->delete($uXTRB->getLocation());
            goto v0Vu3;
            aijFJ:
            if (feof($KLHLq)) {
                goto ugrR4;
            }
            goto zdEnc;
            JpdDB:
            $uZRL7 = 1;
            goto bKIJo;
            Bpvs1:
            hgfCS:
            goto aijFJ;
            vm_6m:
            $uXTRB->update(['driver' => Y9OZ7qWyGdhw2::S3]);
            goto ADbsh;
            a7zVt:
            goto hgfCS;
            goto Y9wT_;
            e0Ifw:
            $uZRL7++;
            goto a7zVt;
            b0LTP:
            $KZQPV = $AFq_H->createMultipartUpload(['Bucket' => $this->c0nhQ, 'Key' => $uXTRB->getLocation(), 'ContentType' => $zbzX3, 'ContentDisposition' => 'inline']);
            goto vXi9w;
            axQT5:
            $sYIWJ[] = ['PartNumber' => $uZRL7, 'ETag' => $iU5rw['ETag']];
            goto e0Ifw;
            Y9wT_:
            ugrR4:
            goto vhbWd;
            bKIJo:
            $sYIWJ = [];
            goto Bpvs1;
            J9hE9:
            $AFq_H->completeMultipartUpload(['Bucket' => $this->c0nhQ, 'Key' => $uXTRB->getLocation(), 'UploadId' => $PcG1p, 'MultipartUpload' => ['Parts' => $sYIWJ]]);
            goto vm_6m;
            vhbWd:
            fclose($KLHLq);
            goto J9hE9;
            v0Vu3:
        } catch (AwsException $r5DbO) {
            goto gC5n8;
            gC5n8:
            if (!isset($PcG1p)) {
                goto nYeIG;
            }
            goto xtFgX;
            QIdqP:
            nYeIG:
            goto nCDs3;
            xtFgX:
            try {
                $AFq_H->abortMultipartUpload(['Bucket' => $this->c0nhQ, 'Key' => $uXTRB->getLocation(), 'UploadId' => $PcG1p]);
            } catch (AwsException $Q20ni) {
                Log::error('Error aborting multipart upload: ' . $Q20ni->getMessage());
            }
            goto QIdqP;
            nCDs3:
            Log::error('Failed to store video: ' . $uXTRB->getLocation() . ' - ' . $r5DbO->getMessage());
            goto XVrp4;
            XVrp4:
        } finally {
            $vnRbJ = microtime(true);
            $WSMrT = memory_get_usage();
            $oeVz2 = memory_get_peak_usage();
            Log::info('Store O1jfuwJR340k5 to S3 function resource usage', ['imageId' => $q8q1b, 'execution_time_sec' => $vnRbJ - $tv3_r, 'memory_usage_mb' => ($WSMrT - $XnLxJ) / 1024 / 1024, 'peak_memory_usage_mb' => ($oeVz2 - $iQTBg) / 1024 / 1024]);
        }
        goto PIhYh;
        bRDAI:
        Log::info('Storing video (local) to S3', ['fileId' => $q8q1b, 'bucketName' => $this->c0nhQ]);
        goto LXdTZ;
        ocUaC:
        Da3nG:
        goto pZdr4;
        f3J5c:
        $zbzX3 = $vWOwZ->mimeType($uXTRB->getLocation());
        goto Gk3xw;
        Qi9l_:
        Log::error("[F06O7XZhnHV45] File not found, discard it ", ['video' => $uXTRB->getLocation()]);
        goto FYZBn;
        CdJvc:
        $AFq_H = $this->cC_4U->getClient();
        goto uuIAi;
        A5Cyn:
        $GzTiT = 1024 * 1024 * 50;
        goto f3J5c;
        FYZBn:
        return;
        goto ocUaC;
        NCIfb:
        $iQTBg = memory_get_peak_usage();
        goto w5VX8;
        PIhYh:
    }
}
