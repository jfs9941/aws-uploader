<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Encoder\IkuQrlPmUVsHD;
use Jfs\Uploader\Encoder\FJLxKHdfSuKx4;
use Jfs\Uploader\Encoder\U69m2hVAaudAN;
use Jfs\Uploader\Encoder\Bq62l6IOj9M2O;
use Jfs\Uploader\Encoder\UXK5mdKvFrtYj;
use Jfs\Uploader\Encoder\VKAnM1rNBvZzz;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Jfs\Uploader\Service\Jobs\ZqvNN9lo9gaie;
use Jfs\Uploader\Service\Jobs\SBKmhirduBuxQ;
use Jfs\Uploader\Service\FTup2pWS3iynB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class VDvqdYRhzsIIF implements MediaEncodeJobInterface
{
    private $gHJ_C;
    private $iAAqk;
    private $DksH2;
    private $kYQtS;
    private $XdOe7;
    public function __construct(string $iwKga, $YNIuu, $l4Drs, $vWUsi, $ZKVnw)
    {
        goto A6E5v;
        sXKVH:
        $this->DksH2 = $l4Drs;
        goto pzFxy;
        pzFxy:
        $this->kYQtS = $vWUsi;
        goto FtdUT;
        k39Qh:
        $this->iAAqk = $YNIuu;
        goto sXKVH;
        A6E5v:
        $this->gHJ_C = $iwKga;
        goto k39Qh;
        FtdUT:
        $this->XdOe7 = $ZKVnw;
        goto u3IKi;
        u3IKi:
    }
    public function encode(string $EmnXX, string $nm3TE, $ax9Ce = true) : void
    {
        goto Rw0H6;
        Rw0H6:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $EmnXX]);
        goto ySRgh;
        ySRgh:
        ini_set('memory_limit', '-1');
        goto IFA_4;
        IFA_4:
        try {
            goto b_yoR;
            T3Jon:
            $YCwFp = $YCwFp->mD9eX58vV7A($GXi1_);
            goto mM3Xm;
            Go2cA:
            $E5K6n = new FJLxKHdfSuKx4('1080p', $X5EoD['width'], $X5EoD['height'], $oS5x2->bLGCe ?? 30);
            goto tvWTu;
            tvWTu:
            $GXi1_ = $this->mYgHNBJ4SRl($WXNzZ, $cklgV->m3ZG46sP9md((int) $X5EoD['width'], (int) $X5EoD['height'], $nm3TE));
            goto SzGLv;
            WvB0B:
            $cklgV = new SBKmhirduBuxQ($this->kYQtS, $this->XdOe7, $this->DksH2, $this->iAAqk);
            goto bJECr;
            nnTQm:
            $E5K6n = $E5K6n->mD9eX58vV7A($GXi1_);
            goto Q9shq;
            oICKp:
            $BoTPl->mfnnJg9SPBn($YCwFp);
            goto qbbG0;
            Q9shq:
            YQl0r:
            goto PZHy9;
            bJECr:
            $GXi1_ = $this->mYgHNBJ4SRl($WXNzZ, $cklgV->m3ZG46sP9md($oS5x2->width(), $oS5x2->height(), $nm3TE));
            goto P5k7W;
            RBnfk:
            FuIDk:
            goto t_OMr;
            D35gX:
            $ldQdP = $oS5x2->height();
            goto aoJO6;
            fdQLi:
            $r5FB6 = app(U69m2hVAaudAN::class);
            goto WZkzY;
            uWIXS:
            T1djd:
            goto vz13c;
            Qs1op:
            return;
            goto bVGx2;
            aoJO6:
            $wUy7l = $this->m21ZRedpx8D($oS5x2);
            goto FgXoQ;
            gmOoY:
            $X5EoD = $this->mQ2k640PTgS($GPsTK, $ldQdP);
            goto pCJtg;
            mOpc7:
            Log::info("M7oTJdNm24KG4 already has Media Converter Job ID, skip encoding", ['fileId' => $EmnXX, 'jobId' => $oS5x2->getAttribute('aws_media_converter_job_id')]);
            goto Qs1op;
            gYbWn:
            Assert::isInstanceOf($oS5x2, M7oTJdNm24KG4::class);
            goto L3C0n;
            MD2mg:
            throw new MediaConverterException("M7oTJdNm24KG4 {$oS5x2->id} is not S3 driver value = {$oS5x2->driver}");
            goto RBnfk;
            t_OMr:
            if (!$oS5x2->getAttribute('aws_media_converter_job_id')) {
                goto fYxB5;
            }
            goto mOpc7;
            Trfr7:
            $GPsTK = $oS5x2->width();
            goto D35gX;
            A2m9M:
            $BoTPl = $BoTPl->mnGbY80Cuj6($BKlrl);
            goto CwS2Q;
            vz13c:
            Log::info("Set thumbnail for M7oTJdNm24KG4 Job", ['videoId' => $oS5x2->getAttribute('id'), 'duration' => $oS5x2->getAttribute('duration')]);
            goto whvVH;
            tVBN1:
            $WXNzZ = app(FTup2pWS3iynB::class);
            goto WvB0B;
            pCJtg:
            Log::info("Set 1080p resolution for Job", ['width' => $X5EoD['width'], 'height' => $X5EoD['height'], 'originalWidth' => $GPsTK, 'originalHeight' => $ldQdP]);
            goto Go2cA;
            qbbG0:
            $BoTPl->muYnfILbWaw($r5FB6->m0j4LnOSNte($oS5x2));
            goto W7xoC;
            WZkzY:
            $BoTPl->muYnfILbWaw($r5FB6->m0j4LnOSNte($oS5x2));
            goto tVBN1;
            b_yoR:
            $oS5x2 = M7oTJdNm24KG4::findOrFail($EmnXX);
            goto gYbWn;
            gKD27:
            $BoTPl = $BoTPl->mBZGBlYwJs7(new Bq62l6IOj9M2O($wUy7l));
            goto J2U9l;
            LmCBl:
            $BoTPl = app(UXK5mdKvFrtYj::class);
            goto gKD27;
            J2U9l:
            $YCwFp = new FJLxKHdfSuKx4('original', $GPsTK, $ldQdP, $oS5x2->bLGCe ?? 30);
            goto fdQLi;
            bVGx2:
            fYxB5:
            goto Trfr7;
            SzGLv:
            if (!$GXi1_) {
                goto YQl0r;
            }
            goto nnTQm;
            PZHy9:
            $BoTPl = $BoTPl->mfnnJg9SPBn($E5K6n);
            goto QmLRP;
            cdZLS:
            $oS5x2->update(['aws_media_converter_job_id' => $EmnXX]);
            goto Cv3ZO;
            FgXoQ:
            Log::info("Set input video for Job", ['s3Uri' => $wUy7l]);
            goto LmCBl;
            P5k7W:
            if (!$GXi1_) {
                goto IBli2;
            }
            goto T3Jon;
            CwS2Q:
            $EmnXX = $BoTPl->mEOmIKFNPRa($this->mcMocgJtGKd($oS5x2, $ax9Ce));
            goto cdZLS;
            whvVH:
            $BKlrl = new IkuQrlPmUVsHD($oS5x2->getAttribute('duration') ?? 1, 2, $r5FB6->mZkvd9XuLJf($oS5x2));
            goto A2m9M;
            W7xoC:
            if (!($GPsTK && $ldQdP)) {
                goto T1djd;
            }
            goto yWIoq;
            mM3Xm:
            IBli2:
            goto oICKp;
            yWIoq:
            if (!$this->mV3rYIgmdYa($GPsTK, $ldQdP)) {
                goto wnzqg;
            }
            goto gmOoY;
            L3C0n:
            if (!($oS5x2->driver != Tfi7lQDVWUJD9::S3)) {
                goto FuIDk;
            }
            goto MD2mg;
            QmLRP:
            wnzqg:
            goto uWIXS;
            Cv3ZO:
        } catch (\Exception $p7PBd) {
            goto QtwuO;
            QtwuO:
            Log::warning("M7oTJdNm24KG4 has been deleted, discard it", ['fileId' => $EmnXX, 'err' => $p7PBd->getMessage()]);
            goto UB3v7;
            UB3v7:
            Sentry::captureException($p7PBd);
            goto OcQyt;
            OcQyt:
            return;
            goto EU2X0;
            EU2X0:
        }
        goto PgPul;
        PgPul:
    }
    private function mcMocgJtGKd(M7oTJdNm24KG4 $oS5x2, $ax9Ce) : bool
    {
        goto Z5Bp9;
        Z5Bp9:
        if ($ax9Ce) {
            goto IZIyL;
        }
        goto Z4F6b;
        Z4F6b:
        return false;
        goto erL2d;
        erL2d:
        IZIyL:
        goto tJ7__;
        utNB7:
        switch (true) {
            case $oS5x2->width() * $oS5x2->height() >= 1920 * 1080 && $oS5x2->width() * $oS5x2->height() < 2560 * 1440:
                return $P58cP > 30 * 60;
            case $oS5x2->width() * $oS5x2->height() >= 2560 * 1440 && $oS5x2->width() * $oS5x2->height() < 3840 * 2160:
                return $P58cP > 15 * 60;
            case $oS5x2->width() * $oS5x2->height() >= 3840 * 2160:
                return $P58cP > 10 * 60;
            default:
                return false;
        }
        goto Ne6oj;
        tJ7__:
        $P58cP = (int) round($oS5x2->getAttribute('duration') ?? 0);
        goto utNB7;
        Ne6oj:
        fmb23:
        goto Geh74;
        Geh74:
        ONnVU:
        goto Rf0JU;
        Rf0JU:
    }
    private function mYgHNBJ4SRl(FTup2pWS3iynB $WXNzZ, string $yGB2u) : ?VKAnM1rNBvZzz
    {
        goto gz608;
        BxySY:
        Log::info("Resolve watermark for job with url", ['url' => $yGB2u, 'uri' => $y3gqV]);
        goto ljUGs;
        gz608:
        $y3gqV = $WXNzZ->mQq6t1OfiF4($yGB2u);
        goto BxySY;
        HWZzj:
        return new VKAnM1rNBvZzz($y3gqV, 0, 0, null, null);
        goto W04Zm;
        oPG6n:
        return null;
        goto tW41M;
        ljUGs:
        if (!$y3gqV) {
            goto Yeiwn;
        }
        goto HWZzj;
        W04Zm:
        Yeiwn:
        goto oPG6n;
        tW41M:
    }
    private function mV3rYIgmdYa(int $GPsTK, int $ldQdP) : bool
    {
        return $GPsTK * $ldQdP > 1.5 * (1920 * 1080);
    }
    private function mQ2k640PTgS(int $GPsTK, int $ldQdP) : array
    {
        $jgT2M = new ZqvNN9lo9gaie($GPsTK, $ldQdP);
        return $jgT2M->mIxoimmOp83();
    }
    private function m21ZRedpx8D(THrRXrYMGJt0m $IdScp) : string
    {
        goto C5BcW;
        C5BcW:
        if (!($IdScp->driver == Tfi7lQDVWUJD9::S3)) {
            goto szj1Z;
        }
        goto K5SvR;
        K5SvR:
        return 's3://' . $this->gHJ_C . '/' . $IdScp->filename;
        goto ZpDBG;
        ZpDBG:
        szj1Z:
        goto l3jLT;
        l3jLT:
        return $this->iAAqk->url($IdScp->filename);
        goto gTZF1;
        gTZF1:
    }
}
