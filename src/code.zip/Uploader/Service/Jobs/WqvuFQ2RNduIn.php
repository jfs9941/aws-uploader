<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class WqvuFQ2RNduIn implements GenerateThumbnailForVideoInterface
{
    private $Xpl2B;
    public function __construct($tII1l)
    {
        $this->Xpl2B = $tII1l;
    }
    public function generate(string $q8q1b) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $q8q1b);
        $this->Xpl2B->createThumbnail($q8q1b);
    }
}
