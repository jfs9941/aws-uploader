<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Illuminate\Support\Facades\Log;
class IlP9qJIfRBYoX implements BlurVideoJobInterface
{
    const HFHlR = 15;
    const Afffq = 500;
    const lm_wJ = 500;
    private $lT6tT;
    private $bLZP5;
    private $qeI_k;
    public function __construct($W4G5n, $C1By6, $ShtWH)
    {
        goto QqbB2;
        V31LM:
        $this->lT6tT = $W4G5n;
        goto KTlWo;
        QqbB2:
        $this->qeI_k = $ShtWH;
        goto PQ7x7;
        PQ7x7:
        $this->bLZP5 = $C1By6;
        goto V31LM;
        KTlWo:
    }
    public function blur(string $DWjir) : void
    {
        goto W2Tkf;
        gD5gX:
        $KlHaV = $this->lT6tT->call($this, $this->qeI_k->path($UoG1T->getAttribute('thumbnail')));
        goto vw9W6;
        Fn32_:
        dg0WX:
        goto MwgKn;
        KCKp_:
        $KlHaV->blur(self::HFHlR);
        goto UFUk2;
        UFUk2:
        $Qh53y = $this->m7L24yaZgjE($UoG1T);
        goto x1e2V;
        Of36v:
        $UoG1T->update(['preview' => $Qh53y]);
        goto Fn32_;
        bmAbW:
        $this->bLZP5->put($Qh53y, $this->qeI_k->get($Qh53y));
        goto HMmiy;
        HMmiy:
        unset($KlHaV);
        goto ughXb;
        dHzBp:
        $KlHaV->save($f67Wo);
        goto bmAbW;
        FwyyS:
        $UoG1T = J7sRaWo8um3yO::findOrFail($DWjir);
        goto VFsF9;
        DDmfq:
        \Log::warning('Failed to set final permissions on image file: ' . $f67Wo);
        goto sq8t7;
        a50B4:
        IVOdI:
        goto Of36v;
        VFsF9:
        if (!$UoG1T->getAttribute('thumbnail')) {
            goto dg0WX;
        }
        goto HEoGb;
        W2Tkf:
        Log::info("Blurring for video", ['videoID' => $DWjir]);
        goto PEvOs;
        HEoGb:
        $this->qeI_k->put($UoG1T->getAttribute('thumbnail'), $this->bLZP5->get($UoG1T->getAttribute('thumbnail')));
        goto gD5gX;
        sq8t7:
        throw new \Exception('Failed to set final permissions on image file: ' . $f67Wo);
        goto a50B4;
        x1e2V:
        $f67Wo = $this->qeI_k->path($Qh53y);
        goto dHzBp;
        PEvOs:
        ini_set('memory_limit', '-1');
        goto FwyyS;
        ughXb:
        if (chmod($f67Wo, 0664)) {
            goto IVOdI;
        }
        goto DDmfq;
        IgPrH:
        $KlHaV->resize(self::Afffq, self::lm_wJ / $j_mpB);
        goto KCKp_;
        vw9W6:
        $j_mpB = $KlHaV->width() / $KlHaV->height();
        goto IgPrH;
        MwgKn:
    }
    private function m7L24yaZgjE(EeWreEFdq3Xdf $I9WVv) : string
    {
        goto YSeN1;
        x3V3k:
        if ($this->qeI_k->exists($F7Xbk)) {
            goto CwWWL;
        }
        goto EFg2H;
        dfim_:
        return $F7Xbk . $I9WVv->getFilename() . '.jpg';
        goto l_6mj;
        EFg2H:
        $this->qeI_k->makeDirectory($F7Xbk, 0755, true);
        goto snbaU;
        snbaU:
        CwWWL:
        goto dfim_;
        YSeN1:
        $iVcpi = $I9WVv->getLocation();
        goto m0r1V;
        m0r1V:
        $F7Xbk = dirname($iVcpi) . '/preview/';
        goto x3V3k;
        l_6mj:
    }
}
