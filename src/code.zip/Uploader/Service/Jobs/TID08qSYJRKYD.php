<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class TID08qSYJRKYD
{
    private $ooQeq;
    private $U9NM5;
    private $Vhcrn;
    private $Lrwlv;
    public function __construct($F_3Mm, $BuwNb, $Klx1U, $AhP23)
    {
        goto BIAUz;
        AHQGV:
        $this->Lrwlv = $AhP23;
        goto LFwAA;
        BIAUz:
        $this->U9NM5 = $BuwNb;
        goto DjEtq;
        DjEtq:
        $this->Vhcrn = $Klx1U;
        goto AHQGV;
        LFwAA:
        $this->ooQeq = $F_3Mm;
        goto sptzx;
        sptzx:
    }
    public function meptZfZfkod(?int $aio9s, ?int $E52ZJ, string $ATagl, bool $ffDQJ = false) : string
    {
        goto pauk7;
        rb_tu:
        fheAR:
        goto AIr3M;
        eOXeW:
        $BFz_x = $aio9s - $EC7hJ;
        goto Mp9_R;
        RnsCQ:
        list($WXfe0, $EC7hJ, $J2zI7) = $this->mvSSEzOmsN6($ATagl, $aio9s, $KUMNB, (float) $aio9s / $E52ZJ);
        goto GSUAK;
        GSUAK:
        $J9IgU = $this->mlycFxUznfc($J2zI7, $aio9s, $E52ZJ, $EC7hJ, $WXfe0);
        goto H6M4r;
        UJUJy:
        return $ffDQJ ? $J9IgU : $this->Vhcrn->url($J9IgU);
        goto UGKLg;
        H6M4r:
        if (!$this->Vhcrn->exists($J9IgU)) {
            goto fheAR;
        }
        goto IuFus;
        AIr3M:
        $fK3zd = $this->ooQeq->call($this, $aio9s, $E52ZJ);
        goto eOXeW;
        ZgGMj:
        if (!($aio9s > 1500)) {
            goto wqzBr;
        }
        goto JgUDp;
        JIWG3:
        throw new \RuntimeException("ZSB2cdrwtZpmk dimensions are not available.");
        goto ibFHI;
        ksTtQ:
        $KUMNB = 0.1;
        goto RnsCQ;
        wl7ZP:
        $BFz_x -= $BgMkO;
        goto ZgGMj;
        Mktto:
        $this->Lrwlv->put($J9IgU, $fK3zd->stream('png'));
        goto aBLlG;
        xuPvD:
        wqzBr:
        goto cv3gm;
        pauk7:
        if (!($aio9s === null || $E52ZJ === null)) {
            goto pX7zc;
        }
        goto JIWG3;
        Mp9_R:
        $BgMkO = (int) ($BFz_x / 80);
        goto wl7ZP;
        ibFHI:
        pX7zc:
        goto ksTtQ;
        JgUDp:
        $BFz_x -= $BgMkO * 0.4;
        goto xuPvD;
        qe3Dm:
        $fK3zd->text($J2zI7, $BFz_x, (int) $ufjDN, function ($QTGMa) use($WXfe0) {
            goto DsC4o;
            FJLQV:
            $QTGMa->align('middle');
            goto AerDF;
            jVo4K:
            $QTGMa->color([185, 185, 185, 1]);
            goto U511b;
            p1T7w:
            $QTGMa->size(max($T1bRA, 1));
            goto jVo4K;
            iD1YI:
            $T1bRA = (int) ($WXfe0 * 1.2);
            goto p1T7w;
            U511b:
            $QTGMa->valign('middle');
            goto FJLQV;
            DsC4o:
            $QTGMa->file(public_path($this->U9NM5));
            goto iD1YI;
            AerDF:
        });
        goto Mktto;
        cv3gm:
        $ufjDN = $E52ZJ - $WXfe0 - 10;
        goto qe3Dm;
        IuFus:
        return $ffDQJ ? $J9IgU : $this->Vhcrn->url($J9IgU);
        goto rb_tu;
        aBLlG:
        $this->Vhcrn->put($J9IgU, $fK3zd->stream('png'));
        goto UJUJy;
        UGKLg:
    }
    private function mlycFxUznfc(string $ATagl, int $aio9s, int $E52ZJ, int $DR3KD, int $hL3u9) : string
    {
        $bfaI3 = ltrim($ATagl, '@');
        return "v2/watermark/{$bfaI3}/{$aio9s}x{$E52ZJ}_{$DR3KD}x{$hL3u9}/text_watermark.png";
    }
    private function mvSSEzOmsN6($ATagl, int $aio9s, float $t_zX7, float $fu4AJ) : array
    {
        goto rXvii;
        fTH5D:
        return [(int) $MkCCj, $EC7hJ, $J2zI7];
        goto T_a2U;
        qRcGZ:
        PjazN:
        goto RzOMF;
        Vtw0L:
        if (!($fu4AJ > 1)) {
            goto PjazN;
        }
        goto XHKBY;
        RzOMF:
        $MkCCj = 1 / $fu4AJ * $EC7hJ / strlen($J2zI7);
        goto fTH5D;
        rXvii:
        $J2zI7 = '@' . $ATagl;
        goto Bz0Wa;
        Bz0Wa:
        $EC7hJ = (int) ($aio9s * $t_zX7);
        goto Vtw0L;
        GOYL2:
        return [(int) $MkCCj, $MkCCj * strlen($J2zI7) / 1.8, $J2zI7];
        goto qRcGZ;
        XHKBY:
        $MkCCj = $EC7hJ / (strlen($J2zI7) * 0.8);
        goto GOYL2;
        T_a2U:
    }
}
