<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class KivHERUZb00Ql implements CompressJobInterface
{
    const UxJ6G = 60;
    private $o4nAt;
    private $Jhhox;
    private $hZygw;
    public function __construct($wpWQD, $bXh5v, $CJv_E)
    {
        goto hN2Iu;
        REaJF:
        $this->hZygw = $CJv_E;
        goto MSFOy;
        MSFOy:
        $this->Jhhox = $bXh5v;
        goto OOs8w;
        hN2Iu:
        $this->o4nAt = $wpWQD;
        goto REaJF;
        OOs8w:
    }
    public function compress(string $Brk87)
    {
        goto IAmXY;
        hQmKd:
        $aPZAx = memory_get_usage();
        goto fBUzQ;
        IAmXY:
        $aRKLJ = microtime(true);
        goto hQmKd;
        O9t7c:
        Log::info("Compress image", ['imageId' => $Brk87]);
        goto ieuiS;
        ieuiS:
        try {
            goto UKWkK;
            LtC_K:
            empxq:
            goto IeY1i;
            myLs3:
            $Kc1eZ = $this->mNtQbqUDTk1($Kc1eZ, 'jpg');
            goto LtC_K;
            vh9EQ:
            if (!(strtolower($Kc1eZ->getExtension()) === 'png' || strtolower($Kc1eZ->getExtension()) === 'heic')) {
                goto empxq;
            }
            goto myLs3;
            A1szH:
            $a2ZIB = $this->Jhhox->path($Kc1eZ->getLocation());
            goto vh9EQ;
            IeY1i:
            try {
                goto gT7y0;
                gT7y0:
                $iorcL = $this->Jhhox->path(str_replace('.jpg', '.webp', $Kc1eZ->getLocation()));
                goto D9xpz;
                D9xpz:
                $this->mlARy0AziEf($a2ZIB, $iorcL);
                goto oUW2g;
                oUW2g:
                $this->mNtQbqUDTk1($Kc1eZ, 'webp');
                goto yQWwG;
                yQWwG:
            } catch (\Exception $fGlZL) {
                goto W33__;
                LmXxm:
                $this->m9Pp3zraogG($a2ZIB, $iorcL);
                goto hHZCc;
                gKRMi:
                $iorcL = $this->Jhhox->path($Kc1eZ->getLocation());
                goto LmXxm;
                W33__:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $Brk87, 'error' => $fGlZL->getMessage()]);
                goto gKRMi;
                hHZCc:
            }
            goto WphZD;
            UKWkK:
            $Kc1eZ = OjvWwjWRqBzIO::findOrFail($Brk87);
            goto A1szH;
            WphZD:
        } catch (\Throwable $fGlZL) {
            goto odsil;
            odsil:
            if (!$fGlZL instanceof ModelNotFoundException) {
                goto RImcr;
            }
            goto uSAMd;
            g1NQL:
            RImcr:
            goto ypJNa;
            uSAMd:
            Log::info("OjvWwjWRqBzIO has been deleted, discard it", ['imageId' => $Brk87]);
            goto DR0zk;
            DR0zk:
            return;
            goto g1NQL;
            ypJNa:
            Log::error("Failed to compress image", ['imageId' => $Brk87, 'error' => $fGlZL->getMessage()]);
            goto tdVYx;
            tdVYx:
        } finally {
            $Gy4_y = microtime(true);
            $aEdXV = memory_get_usage();
            $pE3ho = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $Brk87, 'execution_time_sec' => $Gy4_y - $aRKLJ, 'memory_usage_mb' => ($aEdXV - $aPZAx) / 1024 / 1024, 'peak_memory_usage_mb' => ($pE3ho - $NzcES) / 1024 / 1024]);
        }
        goto cAz83;
        fBUzQ:
        $NzcES = memory_get_peak_usage();
        goto O9t7c;
        cAz83:
    }
    private function m9Pp3zraogG($a2ZIB, $iorcL)
    {
        goto V9eNM;
        rZ6bG:
        $EusLJ->orient()->toJpeg(self::UxJ6G)->save($iorcL);
        goto XdSGw;
        XdSGw:
        $this->hZygw->put($iorcL, $EusLJ->toJpeg(self::UxJ6G), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto BTwsw;
        BTwsw:
        unset($EusLJ);
        goto gKtR7;
        V9eNM:
        $EusLJ = $this->o4nAt->call($this, $a2ZIB);
        goto rZ6bG;
        gKtR7:
    }
    private function mlARy0AziEf($a2ZIB, $iorcL)
    {
        goto V164o;
        LU0N3:
        $EusLJ->orient()->toWebp(self::UxJ6G);
        goto V8HI3;
        V8HI3:
        $this->hZygw->put($iorcL, $EusLJ->toJpeg(self::UxJ6G), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto ApbzQ;
        ApbzQ:
        unset($EusLJ);
        goto XzqwH;
        V164o:
        $EusLJ = $this->o4nAt->call($this, $a2ZIB);
        goto LU0N3;
        XzqwH:
    }
    private function mNtQbqUDTk1($Kc1eZ, $pwCiC)
    {
        goto p2_wZ;
        tsiYk:
        $Kc1eZ->save();
        goto SyQOW;
        SyQOW:
        return $Kc1eZ;
        goto btyOP;
        L0Tde:
        $Kc1eZ->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$pwCiC}", $Kc1eZ->getLocation()));
        goto tsiYk;
        p2_wZ:
        $Kc1eZ->setAttribute('type', $pwCiC);
        goto L0Tde;
        btyOP:
    }
}
