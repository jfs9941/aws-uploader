<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class GbOo94gTAZIhy implements GenerateThumbnailForVideoInterface
{
    private $jq2a_;
    public function __construct($FldSS)
    {
        $this->jq2a_ = $FldSS;
    }
    public function generate(string $B_L9m) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $B_L9m);
        $this->jq2a_->createThumbnail($B_L9m);
    }
}
