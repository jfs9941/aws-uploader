<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
class Xq0MswJXBRMe6 implements WatermarkTextJobInterface
{
    private $Ie_ZE;
    private $ZBBMD;
    private $TJ3cV;
    private $MV0lK;
    private $Hf14x;
    public function __construct($jSZw8, $v9tnd, $tYsty, $p1fCH, $PI6tU)
    {
        goto RMdyo;
        dXjQW:
        $this->Hf14x = $p1fCH;
        goto T7_oq;
        RMdyo:
        $this->Ie_ZE = $jSZw8;
        goto PWUHk;
        PWUHk:
        $this->MV0lK = $tYsty;
        goto dXjQW;
        T7_oq:
        $this->TJ3cV = $PI6tU;
        goto jy0Uu;
        jy0Uu:
        $this->ZBBMD = $v9tnd;
        goto jUd6Y;
        jUd6Y:
    }
    public function putWatermark(string $FILUb, string $u46de) : void
    {
        goto ac5V4;
        LHsYk:
        $sgrbS = memory_get_usage();
        goto lUb4M;
        Usxeb:
        try {
            goto omTd0;
            CPZ_3:
            return;
            goto AmcH3;
            RfvzF:
            $k898t = $this->Ie_ZE->call($this, $Sblyk);
            goto UihGV;
            b2_hz:
            yaOqR:
            goto V2Dol;
            Kn1ca:
            $k898t->destroy();
            goto k0lH1;
            SclMF:
            if ($this->Hf14x->exists($FGBix->getLocation())) {
                goto WIo2D;
            }
            goto VP9Vj;
            sXEGr:
            $this->mQWyBUhcdHg($k898t, $u46de);
            goto zD9Pp;
            k0lH1:
            if (chmod($Sblyk, 0664)) {
                goto yaOqR;
            }
            goto K5A5t;
            zD9Pp:
            $k898t->save($Sblyk);
            goto Kn1ca;
            UihGV:
            $k898t->orientate();
            goto sXEGr;
            AmcH3:
            WIo2D:
            goto QVAsA;
            omTd0:
            $FGBix = XbYF8aa0XyGnI::findOrFail($FILUb);
            goto SclMF;
            GqaNz:
            throw new \Exception('Failed to set final permissions on image file: ' . $Sblyk);
            goto b2_hz;
            K5A5t:
            \Log::warning('Failed to set final permissions on image file: ' . $Sblyk);
            goto GqaNz;
            QVAsA:
            $Sblyk = $this->Hf14x->path($FGBix->getLocation());
            goto RfvzF;
            VP9Vj:
            Log::error("XbYF8aa0XyGnI is not on local, might be deleted before put watermark", ['imageId' => $FILUb]);
            goto CPZ_3;
            V2Dol:
        } catch (\Throwable $Pb3Ix) {
            goto wba9G;
            bHN3f:
            Log::error("XbYF8aa0XyGnI is not readable", ['imageId' => $FILUb, 'error' => $Pb3Ix->getMessage()]);
            goto q2eO1;
            RElEu:
            return;
            goto juE8m;
            Fxw9z:
            Log::info("XbYF8aa0XyGnI has been deleted, discard it", ['imageId' => $FILUb]);
            goto RElEu;
            juE8m:
            wmqK0:
            goto bHN3f;
            wba9G:
            if (!$Pb3Ix instanceof ModelNotFoundException) {
                goto wmqK0;
            }
            goto Fxw9z;
            q2eO1:
        } finally {
            $zG72F = microtime(true);
            $ehM97 = memory_get_usage();
            $qkTl8 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $FILUb, 'execution_time_sec' => $zG72F - $riJ7Z, 'memory_usage_mb' => ($ehM97 - $sgrbS) / 1024 / 1024, 'peak_memory_usage_mb' => ($qkTl8 - $AgLQ7) / 1024 / 1024]);
        }
        goto bqUhU;
        bo2yT:
        Log::info("Adding watermark text to image", ['imageId' => $FILUb]);
        goto c_AW0;
        ac5V4:
        $riJ7Z = microtime(true);
        goto LHsYk;
        c_AW0:
        ini_set('memory_limit', '-1');
        goto Usxeb;
        lUb4M:
        $AgLQ7 = memory_get_peak_usage();
        goto bo2yT;
        bqUhU:
    }
    private function mQWyBUhcdHg($k898t, $u46de) : void
    {
        goto jpFOu;
        zuVqZ:
        $k898t->insert($Dr63y);
        goto APiBi;
        B8lV5:
        $Dr63y = $this->Ie_ZE->call($this, $this->Hf14x->path($xpXoC));
        goto b09v_;
        jpFOu:
        $xjnOB = $k898t->width();
        goto hZPhe;
        hZPhe:
        $I9Wph = $k898t->height();
        goto Kp5bA;
        pfZoB:
        $this->Hf14x->put($xpXoC, $this->MV0lK->get($xpXoC));
        goto B8lV5;
        Kp5bA:
        $re4IV = new O55RFBu3dDBa6($this->ZBBMD, $this->TJ3cV, $this->MV0lK, $this->Hf14x);
        goto UjTIK;
        UjTIK:
        $xpXoC = $re4IV->myRCF2se27f($xjnOB, $I9Wph, $u46de, true);
        goto pfZoB;
        b09v_:
        $Dr63y->opacity(35);
        goto zuVqZ;
        APiBi:
    }
}
