<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Service\Jobs\ShuOBoAxU0XST;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class IEmEByIZczjUB implements WatermarkTextJobInterface
{
    private $bIrxp;
    private $tiVps;
    private $aDr2m;
    private $rSfnv;
    private $unMfk;
    public function __construct($NJy8O, $BYcL7, $uIWH1, $L32kE, $t7N1B)
    {
        goto QL3Mo;
        NEuY_:
        $this->tiVps = $BYcL7;
        goto s7yTP;
        VY36g:
        $this->rSfnv = $uIWH1;
        goto EtT3_;
        QL3Mo:
        $this->bIrxp = $NJy8O;
        goto VY36g;
        VwJH7:
        $this->aDr2m = $t7N1B;
        goto NEuY_;
        EtT3_:
        $this->unMfk = $L32kE;
        goto VwJH7;
        s7yTP:
    }
    public function putWatermark(string $eeXS6, string $fmYhL) : void
    {
        goto LfBAO;
        PtDJO:
        try {
            goto b7Fb1;
            hrSug:
            throw new \Exception('Failed to set final permissions on image file: ' . $NSF8Y);
            goto zN4Kd;
            i9zRl:
            \Log::warning('Failed to set final permissions on image file: ' . $NSF8Y);
            goto hrSug;
            afcbq:
            $WyTVR = $this->bIrxp->call($this, $NSF8Y);
            goto ujdKM;
            qgI3C:
            $this->rSfnv->put($NSF8Y, $WyTVR->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto CK8C5;
            D5wDJ:
            $this->mwNtV0RJ5Uu($WyTVR, $fmYhL);
            goto qgI3C;
            eGW5O:
            $NSF8Y = $this->unMfk->path($K0J89->getLocation());
            goto afcbq;
            SlJot:
            if (chmod($NSF8Y, 0664)) {
                goto BTDFa;
            }
            goto i9zRl;
            CK8C5:
            unset($WyTVR);
            goto SlJot;
            ujdKM:
            $WyTVR->orient();
            goto D5wDJ;
            LFToA:
            return;
            goto I2ehT;
            IQ_6W:
            if ($this->unMfk->exists($K0J89->getLocation())) {
                goto Fy2eE;
            }
            goto RN6K6;
            zN4Kd:
            BTDFa:
            goto VqYPr;
            b7Fb1:
            $K0J89 = UG34Yjmf7IsbQ::findOrFail($eeXS6);
            goto IQ_6W;
            RN6K6:
            Log::error("UG34Yjmf7IsbQ is not on local, might be deleted before put watermark", ['imageId' => $eeXS6]);
            goto LFToA;
            I2ehT:
            Fy2eE:
            goto eGW5O;
            VqYPr:
        } catch (\Throwable $sKTz0) {
            goto pFi2v;
            pFi2v:
            if (!$sKTz0 instanceof ModelNotFoundException) {
                goto LoPxS;
            }
            goto tA7OV;
            tA7OV:
            Log::info("UG34Yjmf7IsbQ has been deleted, discard it", ['imageId' => $eeXS6]);
            goto eajH9;
            WqFwd:
            Log::error("UG34Yjmf7IsbQ is not readable", ['imageId' => $eeXS6, 'error' => $sKTz0->getMessage()]);
            goto LkWbS;
            eajH9:
            return;
            goto dA1PL;
            dA1PL:
            LoPxS:
            goto WqFwd;
            LkWbS:
        } finally {
            $kreUc = microtime(true);
            $VUnvt = memory_get_usage();
            $dR0uy = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $eeXS6, 'execution_time_sec' => $kreUc - $OYvfo, 'memory_usage_mb' => ($VUnvt - $dSWgf) / 1024 / 1024, 'peak_memory_usage_mb' => ($dR0uy - $WT5nk) / 1024 / 1024]);
        }
        goto Lyg52;
        AFbF7:
        $WT5nk = memory_get_peak_usage();
        goto PWRxa;
        lx3jM:
        $dSWgf = memory_get_usage();
        goto AFbF7;
        PWRxa:
        Log::info("Adding watermark text to image", ['imageId' => $eeXS6]);
        goto nGogX;
        nGogX:
        ini_set('memory_limit', '-1');
        goto PtDJO;
        LfBAO:
        $OYvfo = microtime(true);
        goto lx3jM;
        Lyg52:
    }
    private function mwNtV0RJ5Uu($WyTVR, $fmYhL) : void
    {
        goto zMDD8;
        sIutW:
        $X8shh = $WyTVR->height();
        goto Bcsf5;
        M0Vye:
        $WyTVR->place($rUdwx, 'top-left', 0, 0, 30);
        goto Lfdx4;
        Vwqdc:
        $rUdwx = $this->bIrxp->call($this, $this->unMfk->path($ojCCH));
        goto M0Vye;
        zMDD8:
        $XLJzE = $WyTVR->width();
        goto sIutW;
        Bcsf5:
        $Y6S2V = new ShuOBoAxU0XST($this->tiVps, $this->aDr2m, $this->rSfnv, $this->unMfk);
        goto mDWXw;
        b3Der:
        $this->unMfk->put($ojCCH, $this->rSfnv->get($ojCCH));
        goto Vwqdc;
        mDWXw:
        $ojCCH = $Y6S2V->mhwnG9Y7qwm($XLJzE, $X8shh, $fmYhL, true);
        goto b3Der;
        Lfdx4:
    }
}
