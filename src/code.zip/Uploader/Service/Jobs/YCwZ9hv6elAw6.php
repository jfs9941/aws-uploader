<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Illuminate\Support\Facades\Log;
class YCwZ9hv6elAw6 implements DownloadToLocalJobInterface
{
    private $bLZP5;
    private $qeI_k;
    public function __construct($C1By6, $ShtWH)
    {
        $this->bLZP5 = $C1By6;
        $this->qeI_k = $ShtWH;
    }
    public function download(string $DWjir) : void
    {
        goto sCzp5;
        vH4XS:
        Log::info("Start download file to local", ['fileId' => $DWjir, 'filename' => $nbWJE->getLocation()]);
        goto W1ARm;
        W1ARm:
        if (!$this->qeI_k->exists($nbWJE->getLocation())) {
            goto l4T0Z;
        }
        goto kDYlZ;
        kDYlZ:
        return;
        goto xsV1b;
        sCzp5:
        $nbWJE = IQJN6V0t7DC7c::findOrFail($DWjir);
        goto vH4XS;
        Ddl12:
        $this->qeI_k->put($nbWJE->getLocation(), $this->bLZP5->get($nbWJE->getLocation()));
        goto QSGr_;
        xsV1b:
        l4T0Z:
        goto Ddl12;
        QSGr_:
    }
}
