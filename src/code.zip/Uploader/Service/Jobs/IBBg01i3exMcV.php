<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WKX0l52zWptlF;
class IBBg01i3exMcV implements DownloadToLocalJobInterface
{
    private $qrvF0;
    private $ERIyl;
    public function __construct($eG_Pc, $nL6dR)
    {
        $this->qrvF0 = $eG_Pc;
        $this->ERIyl = $nL6dR;
    }
    public function download(string $ElvKF) : void
    {
        goto KvFaO;
        DS3NZ:
        $this->ERIyl->put($TFA4Z->getLocation(), $this->qrvF0->get($TFA4Z->getLocation()));
        goto inFIg;
        E20Tv:
        return;
        goto cUzbR;
        cUzbR:
        FClVZ:
        goto DS3NZ;
        Kgr05:
        if (!$this->ERIyl->exists($TFA4Z->getLocation())) {
            goto FClVZ;
        }
        goto E20Tv;
        i0Asg:
        Log::info("Start download file to local", ['fileId' => $ElvKF, 'filename' => $TFA4Z->getLocation()]);
        goto Kgr05;
        KvFaO:
        $TFA4Z = WKX0l52zWptlF::findOrFail($ElvKF);
        goto i0Asg;
        inFIg:
    }
}
