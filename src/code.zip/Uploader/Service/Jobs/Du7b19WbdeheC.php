<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Service\Jobs\T2CJnBIhoexXE;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Du7b19WbdeheC implements WatermarkTextJobInterface
{
    private $xy0Yf;
    private $jD7oG;
    private $jsGTU;
    private $gErml;
    private $yt19t;
    public function __construct($ppK7O, $ksSJg, $DFpIk, $RndMA, $u5Co4)
    {
        goto bfQfW;
        pBnNC:
        $this->jD7oG = $ksSJg;
        goto aP6mH;
        R4kay:
        $this->gErml = $DFpIk;
        goto PkTO7;
        PkTO7:
        $this->yt19t = $RndMA;
        goto aJ6B_;
        aJ6B_:
        $this->jsGTU = $u5Co4;
        goto pBnNC;
        bfQfW:
        $this->xy0Yf = $ppK7O;
        goto R4kay;
        aP6mH:
    }
    public function putWatermark(string $J_scC, string $SqwFQ) : void
    {
        goto cO0Oj;
        cO0Oj:
        $gAXA1 = microtime(true);
        goto gdd2_;
        gdd2_:
        $bp0pf = memory_get_usage();
        goto H7450;
        UqTH8:
        Log::info("Adding watermark text to image", ['imageId' => $J_scC]);
        goto CPgf4;
        i9s6L:
        try {
            goto EkBAT;
            HnFFw:
            $this->mf7Fb03ZTuN($MWP2E, $SqwFQ);
            goto eEnQ3;
            cUw5Q:
            $MWP2E->orient();
            goto HnFFw;
            xIqG4:
            uqvFT:
            goto Q3aJ_;
            aigHZ:
            if ($this->yt19t->exists($VWXEV->getLocation())) {
                goto uqvFT;
            }
            goto VrmvH;
            R2qXF:
            return;
            goto xIqG4;
            LhAM1:
            if (chmod($hU2b_, 0664)) {
                goto Dd6Pa;
            }
            goto Bf6P8;
            Q3aJ_:
            $hU2b_ = $this->yt19t->path($VWXEV->getLocation());
            goto g1CCR;
            EkBAT:
            $VWXEV = XK5kReLMTU1ob::findOrFail($J_scC);
            goto aigHZ;
            XP4I4:
            Dd6Pa:
            goto ADbWE;
            VrmvH:
            Log::error("XK5kReLMTU1ob is not on local, might be deleted before put watermark", ['imageId' => $J_scC]);
            goto R2qXF;
            g1CCR:
            $MWP2E = $this->xy0Yf->call($this, $hU2b_);
            goto cUw5Q;
            Bf6P8:
            \Log::warning('Failed to set final permissions on image file: ' . $hU2b_);
            goto zPu_j;
            zPu_j:
            throw new \Exception('Failed to set final permissions on image file: ' . $hU2b_);
            goto XP4I4;
            HhnS5:
            unset($MWP2E);
            goto LhAM1;
            eEnQ3:
            $this->gErml->put($hU2b_, $MWP2E->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto HhnS5;
            ADbWE:
        } catch (\Throwable $sEcqD) {
            goto qdNAv;
            Ayt8T:
            return;
            goto mApqV;
            Ql5ep:
            Log::error("XK5kReLMTU1ob is not readable", ['imageId' => $J_scC, 'error' => $sEcqD->getMessage()]);
            goto kMCG4;
            KbwVq:
            Log::info("XK5kReLMTU1ob has been deleted, discard it", ['imageId' => $J_scC]);
            goto Ayt8T;
            mApqV:
            zmOJ4:
            goto Ql5ep;
            qdNAv:
            if (!$sEcqD instanceof ModelNotFoundException) {
                goto zmOJ4;
            }
            goto KbwVq;
            kMCG4:
        } finally {
            $m9Rrr = microtime(true);
            $mHCRu = memory_get_usage();
            $kZ1f0 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $J_scC, 'execution_time_sec' => $m9Rrr - $gAXA1, 'memory_usage_mb' => ($mHCRu - $bp0pf) / 1024 / 1024, 'peak_memory_usage_mb' => ($kZ1f0 - $c_Bev) / 1024 / 1024]);
        }
        goto cXSw_;
        CPgf4:
        ini_set('memory_limit', '-1');
        goto i9s6L;
        H7450:
        $c_Bev = memory_get_peak_usage();
        goto UqTH8;
        cXSw_:
    }
    private function mf7Fb03ZTuN($MWP2E, $SqwFQ) : void
    {
        goto WUiqS;
        XvywS:
        $i1XSF = $this->xy0Yf->call($this, $this->yt19t->path($kNRUW));
        goto knW68;
        LOUg1:
        $this->yt19t->put($kNRUW, $this->gErml->get($kNRUW));
        goto XvywS;
        knW68:
        $MWP2E->place($i1XSF, 'top-left', 0, 0, 30);
        goto cDuG7;
        mARLK:
        $XLq95 = new T2CJnBIhoexXE($this->jD7oG, $this->jsGTU, $this->gErml, $this->yt19t);
        goto QedzE;
        WUiqS:
        $kc4oX = $MWP2E->width();
        goto LnjUW;
        QedzE:
        $kNRUW = $XLq95->mmlHyHPZIWI($kc4oX, $lIw1W, $SqwFQ, true);
        goto LOUg1;
        LnjUW:
        $lIw1W = $MWP2E->height();
        goto mARLK;
        cDuG7:
    }
}
