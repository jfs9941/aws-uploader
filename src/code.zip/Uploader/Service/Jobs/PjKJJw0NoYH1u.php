<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\NBWuSM65HseqY;
class PjKJJw0NoYH1u implements CompressJobInterface
{
    const dnM6l = 80;
    private $xI8aP;
    private $Farqu;
    public function __construct($uIkIq, $MQQLd)
    {
        $this->xI8aP = $uIkIq;
        $this->Farqu = $MQQLd;
    }
    public function compress(string $eXur0)
    {
        Log::info("Compress image", ['imageId' => $eXur0]);
        try {
            goto d5xYn;
            N68HQ:
            $BIC8T->destroy();
            goto XsWm7;
            dzGSR:
            $BIC8T = $this->xI8aP->call($this, $RMmbS);
            goto IfzHB;
            IfzHB:
            $BIC8T->orientate();
            goto JrAIs;
            JrAIs:
            $BIC8T->save($UhlEA, self::dnM6l);
            goto N68HQ;
            Iqnw_:
            $RMmbS = $this->Farqu->path($CPHMS->getLocation());
            goto UDIQD;
            RPOFa:
            $CPHMS->setAttribute('filename', str_replace('.png', '.jpg', $CPHMS->getLocation()));
            goto Ja5c5;
            F0EEd:
            $UhlEA = $this->Farqu->path($CPHMS->getLocation());
            goto dzGSR;
            UDIQD:
            if (!($CPHMS->getExtension() === 'png')) {
                goto WEH5A;
            }
            goto y2bzM;
            Ja5c5:
            $CPHMS->save();
            goto mM_0w;
            d5xYn:
            $CPHMS = NBWuSM65HseqY::findOrFail($eXur0);
            goto Iqnw_;
            mM_0w:
            WEH5A:
            goto F0EEd;
            y2bzM:
            $CPHMS->setAttribute('type', 'jpg');
            goto RPOFa;
            XsWm7:
        } catch (ModelNotFoundException) {
            Log::info("NBWuSM65HseqY has been deleted, discard it", ['imageId' => $eXur0]);
        }
    }
}
