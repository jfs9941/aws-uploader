<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class RlK5kQJKh8JXQ implements GenerateThumbnailJobInterface
{
    const VxG1F = 150;
    const RT7FO = 150;
    private $ABFqP;
    private $aW0a3;
    private $S2ABC;
    public function __construct($xLMar, $eEhuZ, $MO7Ok)
    {
        goto cyVw_;
        cyVw_:
        $this->ABFqP = $xLMar;
        goto oL2jH;
        oL2jH:
        $this->aW0a3 = $eEhuZ;
        goto QNhxM;
        QNhxM:
        $this->S2ABC = $MO7Ok;
        goto ebvx4;
        ebvx4:
    }
    public function generate(string $qMhfW)
    {
        goto tQFet;
        Nd4fy:
        try {
            goto bSRTv;
            AvoZ3:
            $T4AWF->update(['thumbnail' => $b0LKC, 'status' => TSfaBZEUMcbl0::THUMBNAIL_PROCESSED]);
            goto jZcqW;
            wMT2R:
            unset($MFYSD);
            goto rkiau;
            bSRTv:
            $TWZho = $this->aW0a3;
            goto FwD_M;
            nCH7v:
            $MFYSD = $this->ABFqP->call($this, $TWZho->path($T4AWF->getLocation()));
            goto YKxwm;
            GqL3R:
            $b0LKC = $this->muOZqmZNOzL($T4AWF);
            goto paCSz;
            rkiau:
            if (!($wcpGI !== false)) {
                goto jGWts;
            }
            goto AvoZ3;
            FwD_M:
            $T4AWF = WUuz09CA4woAL::findOrFail($qMhfW);
            goto nCH7v;
            paCSz:
            $wcpGI = $this->S2ABC->put($b0LKC, $MFYSD->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto wMT2R;
            YKxwm:
            $MFYSD->orient()->resize(150, 150);
            goto GqL3R;
            jZcqW:
            jGWts:
            goto E6Z_m;
            E6Z_m:
        } catch (ModelNotFoundException $X3u3n) {
            Log::info("WUuz09CA4woAL has been deleted, discard it", ['imageId' => $qMhfW]);
            return;
        } catch (\Exception $X3u3n) {
            Log::error("Failed to generate thumbnail", ['imageId' => $qMhfW, 'error' => $X3u3n->getMessage()]);
        }
        goto WMVsV;
        YDDgD:
        ini_set('memory_limit', '-1');
        goto Nd4fy;
        tQFet:
        Log::info("Generating thumbnail", ['imageId' => $qMhfW]);
        goto YDDgD;
        WMVsV:
    }
    private function muOZqmZNOzL(Rqw1PJIt1YU1r $T4AWF) : string
    {
        goto rFNTd;
        o1bI0:
        return $g1RX_ . '/' . $T4AWF->getFilename() . '.jpg';
        goto B9Ui0;
        rFNTd:
        $b0LKC = $T4AWF->getLocation();
        goto YcpE4;
        liE93:
        $g1RX_ = $kaImN . '/' . self::VxG1F . 'X' . self::RT7FO;
        goto o1bI0;
        YcpE4:
        $kaImN = dirname($b0LKC);
        goto liE93;
        B9Ui0:
    }
}
