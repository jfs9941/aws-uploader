<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class TXfMgH5VamIR3 implements GenerateThumbnailForVideoInterface
{
    private $tAZ2F;
    public function __construct($fQwx9)
    {
        $this->tAZ2F = $fQwx9;
    }
    public function generate(string $S580N) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $S580N);
        $this->tAZ2F->createThumbnail($S580N);
    }
}
