<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class N0u2MGGVwq0P4
{
    private $u0zPJ;
    private $pD352;
    public function __construct(int $izofa, int $XyRj8)
    {
        goto yAaz1;
        phr_b:
        $this->pD352 = $XyRj8;
        goto ha3os;
        X67RY:
        Wtguh:
        goto oHJ5D;
        KgZwV:
        bt1lo:
        goto uj_vy;
        yAaz1:
        if (!($izofa <= 0)) {
            goto bt1lo;
        }
        goto jVbIh;
        uj_vy:
        if (!($XyRj8 <= 0)) {
            goto Wtguh;
        }
        goto JPDNz;
        oHJ5D:
        $this->u0zPJ = $izofa;
        goto phr_b;
        JPDNz:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto X67RY;
        jVbIh:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto KgZwV;
        ha3os:
    }
    private static function mSnxIMUfnsD($knD3f, string $AqHRg = 'floor') : int
    {
        goto tP1IM;
        liACK:
        return $knD3f;
        goto uu5nI;
        oEOHt:
        ymCym:
        goto VjNAD;
        wnW_e:
        if (!(is_float($knD3f) && $knD3f == floor($knD3f) && (int) $knD3f % 2 === 0)) {
            goto ymCym;
        }
        goto kvfyh;
        Ml0oz:
        e1SUg:
        goto zk7EU;
        kvfyh:
        return (int) $knD3f;
        goto oEOHt;
        tP1IM:
        if (!(is_int($knD3f) && $knD3f % 2 === 0)) {
            goto TUKrx;
        }
        goto liACK;
        VjNAD:
        switch (strtolower($AqHRg)) {
            case 'ceil':
                return (int) (ceil($knD3f / 2) * 2);
            case 'round':
                return (int) (round($knD3f / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($knD3f / 2) * 2);
        }
        goto Ml0oz;
        zk7EU:
        KsXRJ:
        goto DTWxY;
        uu5nI:
        TUKrx:
        goto wnW_e;
        DTWxY:
    }
    public function mVaB48xRIWB(string $ncums = 'floor') : array
    {
        goto z3Etd;
        raGo4:
        RCkil:
        goto D3HOW;
        gHE3E:
        if (!($Ti7pe < 2)) {
            goto yNt5v;
        }
        goto eUvaE;
        m1N9s:
        $bHT4M = $this->u0zPJ * $ltU4h;
        goto QJVll;
        GDqg9:
        $Ti7pe = 0;
        goto Sge5M;
        zIRU5:
        oRfYI:
        goto gHE3E;
        IOFuw:
        yNt5v:
        goto nmhzy;
        qjQBr:
        OuAHu:
        goto VEFwR;
        rkQsi:
        $Ti7pe = $VKS4t;
        goto tS17R;
        z3Etd:
        $VKS4t = 1080;
        goto GDqg9;
        uAGuB:
        goto oRfYI;
        goto raGo4;
        VEFwR:
        return ['width' => $Ti7pe, 'height' => $WD1KI];
        goto wdnAf;
        eUvaE:
        $Ti7pe = 2;
        goto IOFuw;
        SGmzq:
        $ltU4h = $WD1KI / $this->pD352;
        goto m1N9s;
        uMQuL:
        $WD1KI = 2;
        goto qjQBr;
        eSzST:
        $WD1KI = self::mSnxIMUfnsD(round($mYYj8), $ncums);
        goto uAGuB;
        tS17R:
        $ltU4h = $Ti7pe / $this->u0zPJ;
        goto aIssf;
        D3HOW:
        $WD1KI = $VKS4t;
        goto SGmzq;
        nmhzy:
        if (!($WD1KI < 2)) {
            goto OuAHu;
        }
        goto uMQuL;
        M77oh:
        if ($this->u0zPJ >= $this->pD352) {
            goto RCkil;
        }
        goto rkQsi;
        Sge5M:
        $WD1KI = 0;
        goto M77oh;
        aIssf:
        $mYYj8 = $this->pD352 * $ltU4h;
        goto eSzST;
        QJVll:
        $Ti7pe = self::mSnxIMUfnsD(round($bHT4M), $ncums);
        goto zIRU5;
        wdnAf:
    }
}
