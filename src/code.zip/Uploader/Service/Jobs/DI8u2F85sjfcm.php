<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileDriver;
use src\Uploader\Enum\FileStatus;
class DI8u2F85sjfcm implements StoreVideoToS3JobInterface
{
    private $mr4Ue;
    private $Aj6QZ;
    private $tGIcp;
    public function __construct($FQWsT, $SaekO, $UR4Dl)
    {
        goto DZuWt;
        DZuWt:
        $this->Aj6QZ = $SaekO;
        goto xEt3t;
        xSN2p:
        $this->mr4Ue = $FQWsT;
        goto HdQag;
        xEt3t:
        $this->tGIcp = $UR4Dl;
        goto xSN2p;
        HdQag:
    }
    public function store(string $BFPg9) : void
    {
        goto Cjf80;
        ZfKZc:
        $Yr67i = $this->Aj6QZ->getClient();
        goto PatfW;
        P7HtN:
        ini_set('memory_limit', '-1');
        goto ZfKZc;
        o8I0R:
        return;
        goto FQ4tu;
        bUTXG:
        $aa5xh = 1024 * 1024 * 50;
        goto UQo7y;
        vcCyh:
        Log::error("[DI8u2F85sjfcm] File not found, discard it ", ['video' => $D4iMz->getLocation()]);
        goto sOkVX;
        llZCn:
        if ($UR4Dl->exists($D4iMz->getLocation())) {
            goto dS2X6;
        }
        goto vcCyh;
        Cjf80:
        Log::info('Storing video (local) to S3', ['fileId' => $BFPg9, 'bucketName' => $this->mr4Ue]);
        goto P7HtN;
        QncxS:
        if ($D4iMz) {
            goto LCjvM;
        }
        goto oKmvf;
        sOkVX:
        return;
        goto YROTE;
        XZ78a:
        try {
            goto TUOQp;
            ut1gh:
            $PVwoJ = $Yr67i->uploadPart(['Bucket' => $this->mr4Ue, 'Key' => $D4iMz->getLocation(), 'UploadId' => $bkvvg, 'PartNumber' => $kjOeQ, 'Body' => fread($ceeN6, $aa5xh)]);
            goto KOlIO;
            s3RUh:
            $Yr67i->completeMultipartUpload(['Bucket' => $this->mr4Ue, 'Key' => $D4iMz->getLocation(), 'UploadId' => $bkvvg, 'MultipartUpload' => ['Parts' => $qj0o5]]);
            goto RAKnL;
            ricdQ:
            $kjOeQ++;
            goto WOQWo;
            D0bR8:
            $qj0o5 = [];
            goto aIPq5;
            uHvnQ:
            $UR4Dl->delete($D4iMz->getLocation());
            goto S7HBC;
            aIPq5:
            yxuKI:
            goto RuN5r;
            WOQWo:
            goto yxuKI;
            goto JxDsd;
            KOlIO:
            $qj0o5[] = ['PartNumber' => $kjOeQ, 'ETag' => $PVwoJ['ETag']];
            goto ricdQ;
            RuN5r:
            if (feof($ceeN6)) {
                goto Jgpyo;
            }
            goto ut1gh;
            VY9RZ:
            $bkvvg = $aJeqW['UploadId'];
            goto Q73FP;
            Q73FP:
            $kjOeQ = 1;
            goto D0bR8;
            RAKnL:
            $D4iMz->update(['driver' => FileDriver::S3, 'status' => FileStatus::FINISHED]);
            goto uHvnQ;
            AV6vt:
            fclose($ceeN6);
            goto s3RUh;
            JxDsd:
            Jgpyo:
            goto AV6vt;
            TUOQp:
            $aJeqW = $Yr67i->createMultipartUpload(['Bucket' => $this->mr4Ue, 'Key' => $D4iMz->getLocation(), 'ContentType' => $wYibu, 'ContentDisposition' => 'inline']);
            goto VY9RZ;
            S7HBC:
        } catch (AwsException $X1eT0) {
            goto e9ufD;
            fU09Y:
            BNeZl:
            goto Xyfcg;
            e9ufD:
            if (!isset($bkvvg)) {
                goto BNeZl;
            }
            goto mPuZx;
            Xyfcg:
            Log::error('Failed to store video: ' . $D4iMz->getLocation() . ' - ' . $X1eT0->getMessage());
            goto NLhqb;
            mPuZx:
            try {
                $Yr67i->abortMultipartUpload(['Bucket' => $this->mr4Ue, 'Key' => $D4iMz->getLocation(), 'UploadId' => $bkvvg]);
            } catch (AwsException $VmpEt) {
                Log::error('Error aborting multipart upload: ' . $VmpEt->getMessage());
            }
            goto fU09Y;
            NLhqb:
        }
        goto pksTx;
        oKmvf:
        Log::info("YdClVYDRbSDMR has been deleted, discard it", ['fileId' => $BFPg9]);
        goto o8I0R;
        PatfW:
        $UR4Dl = $this->tGIcp;
        goto xsdWO;
        UQo7y:
        $wYibu = $UR4Dl->mimeType($D4iMz->getLocation());
        goto XZ78a;
        Depqu:
        $ceeN6 = $UR4Dl->readStream($D4iMz->getLocation());
        goto bUTXG;
        FQ4tu:
        LCjvM:
        goto llZCn;
        xsdWO:
        $D4iMz = YdClVYDRbSDMR::find($BFPg9);
        goto QncxS;
        YROTE:
        dS2X6:
        goto Depqu;
        pksTx:
    }
}
