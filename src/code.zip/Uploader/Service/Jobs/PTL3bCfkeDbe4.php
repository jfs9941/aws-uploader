<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class PTL3bCfkeDbe4 implements GenerateThumbnailForVideoInterface
{
    private $KwcB5;
    public function __construct($T9J0H)
    {
        $this->KwcB5 = $T9J0H;
    }
    public function generate(string $aK0gt) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $aK0gt);
        $this->KwcB5->createThumbnail($aK0gt);
    }
}
