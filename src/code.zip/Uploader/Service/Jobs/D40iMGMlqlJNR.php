<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class D40iMGMlqlJNR implements CompressJobInterface
{
    const LUmg7 = 60;
    private $j6_VZ;
    private $F8ilg;
    private $cbGQe;
    public function __construct($od_dm, $Pkopf, $yQFAj)
    {
        goto ETdjv;
        ETdjv:
        $this->j6_VZ = $od_dm;
        goto F2kB4;
        UQJB6:
        $this->F8ilg = $Pkopf;
        goto SMyet;
        F2kB4:
        $this->cbGQe = $yQFAj;
        goto UQJB6;
        SMyet:
    }
    public function compress(string $LpGEK)
    {
        goto Ox2vD;
        ys04z:
        try {
            goto UId86;
            m9yjC:
            try {
                goto wiFS9;
                wiFS9:
                $OqUP6 = $this->F8ilg->path(str_replace('.jpg', '.webp', $ZQQzW->getLocation()));
                goto BZYyw;
                BZYyw:
                $this->mD3V4kL4REt($KqaPF, $OqUP6);
                goto smz5G;
                smz5G:
                $this->m9aSjyIi5QC($ZQQzW, 'webp');
                goto RpxSJ;
                RpxSJ:
            } catch (\Exception $OtxN7) {
                goto l3_Qs;
                FvCno:
                $OqUP6 = $this->F8ilg->path($ZQQzW->getLocation());
                goto bjkVD;
                l3_Qs:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $LpGEK, 'error' => $OtxN7->getMessage()]);
                goto FvCno;
                bjkVD:
                $this->mTI8usl8j3y($KqaPF, $OqUP6);
                goto ouCcQ;
                ouCcQ:
            }
            goto qSSmN;
            txI7E:
            CEHTG:
            goto m9yjC;
            x2kAk:
            $ZQQzW = $this->m9aSjyIi5QC($ZQQzW, 'jpg');
            goto txI7E;
            UId86:
            $ZQQzW = X9YHjKrAdcfhe::findOrFail($LpGEK);
            goto tq1tH;
            tq1tH:
            $KqaPF = $this->F8ilg->path($ZQQzW->getLocation());
            goto EEfXn;
            EEfXn:
            if (!(strtolower($ZQQzW->getExtension()) === 'png' || strtolower($ZQQzW->getExtension()) === 'heic')) {
                goto CEHTG;
            }
            goto x2kAk;
            qSSmN:
        } catch (\Throwable $OtxN7) {
            goto KjqzN;
            qQxPW:
            Log::info("X9YHjKrAdcfhe has been deleted, discard it", ['imageId' => $LpGEK]);
            goto Qc5xu;
            Qc5xu:
            return;
            goto U0uBm;
            KjqzN:
            if (!$OtxN7 instanceof ModelNotFoundException) {
                goto Q_iW7;
            }
            goto qQxPW;
            U0uBm:
            Q_iW7:
            goto JKjZm;
            JKjZm:
            Log::error("Failed to compress image", ['imageId' => $LpGEK, 'error' => $OtxN7->getMessage()]);
            goto tN867;
            tN867:
        } finally {
            $U57EV = microtime(true);
            $N25yv = memory_get_usage();
            $E8PVY = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $LpGEK, 'execution_time_sec' => $U57EV - $bZyPc, 'memory_usage_mb' => ($N25yv - $xzy2m) / 1024 / 1024, 'peak_memory_usage_mb' => ($E8PVY - $oEqSJ) / 1024 / 1024]);
        }
        goto BqupA;
        bCumS:
        $xzy2m = memory_get_usage();
        goto ku8W2;
        qFrme:
        Log::info("Compress image", ['imageId' => $LpGEK]);
        goto ys04z;
        ku8W2:
        $oEqSJ = memory_get_peak_usage();
        goto qFrme;
        Ox2vD:
        $bZyPc = microtime(true);
        goto bCumS;
        BqupA:
    }
    private function mTI8usl8j3y($KqaPF, $OqUP6)
    {
        goto JIc5l;
        mAydB:
        $this->cbGQe->put($OqUP6, $au0AO->toJpeg(self::LUmg7), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto GpzTE;
        AWay1:
        $au0AO->orient()->toJpeg(self::LUmg7)->save($OqUP6);
        goto mAydB;
        JIc5l:
        $au0AO = $this->j6_VZ->call($this, $KqaPF);
        goto AWay1;
        GpzTE:
        unset($au0AO);
        goto Oy3gd;
        Oy3gd:
    }
    private function mD3V4kL4REt($KqaPF, $OqUP6)
    {
        goto xxO0D;
        E6A9y:
        $au0AO->orient()->toWebp(self::LUmg7);
        goto WiSKx;
        xxO0D:
        $au0AO = $this->j6_VZ->call($this, $KqaPF);
        goto E6A9y;
        WiSKx:
        $this->cbGQe->put($OqUP6, $au0AO->toJpeg(self::LUmg7), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto Hhlvq;
        Hhlvq:
        unset($au0AO);
        goto rAmfw;
        rAmfw:
    }
    private function m9aSjyIi5QC($ZQQzW, $n6wQU)
    {
        goto CpbUS;
        JyLmp:
        return $ZQQzW;
        goto TuEfc;
        CpbUS:
        $ZQQzW->setAttribute('type', $n6wQU);
        goto zjaEl;
        ghNCv:
        $ZQQzW->save();
        goto JyLmp;
        zjaEl:
        $ZQQzW->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$n6wQU}", $ZQQzW->getLocation()));
        goto ghNCv;
        TuEfc:
    }
}
