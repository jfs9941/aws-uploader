<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class T2CJnBIhoexXE
{
    private $jD7oG;
    private $jsGTU;
    private $gErml;
    private $yt19t;
    public function __construct($ksSJg, $lylEe, $DFpIk, $RndMA)
    {
        goto Vfrrg;
        Vfrrg:
        $this->jsGTU = $lylEe;
        goto tOwCu;
        QpA4Z:
        $this->jD7oG = $ksSJg;
        goto NwuQ0;
        AHh1i:
        $this->yt19t = $RndMA;
        goto QpA4Z;
        tOwCu:
        $this->gErml = $DFpIk;
        goto AHh1i;
        NwuQ0:
    }
    public function mmlHyHPZIWI(?int $kc4oX, ?int $lIw1W, string $SqwFQ, bool $NiewT = false) : string
    {
        goto qo3TB;
        FQGrW:
        $NGphH = 0.1;
        goto dD96e;
        qo3TB:
        if (!($kc4oX === null || $lIw1W === null)) {
            goto W0DNf;
        }
        goto BGr6I;
        NR_q8:
        $VWXEV->text($E2IZC, $OmVZJ, (int) $gnaTH, function ($x8pov) use($v6Q0U) {
            goto Qs4c3;
            MAAvR:
            $x8pov->align('middle');
            goto tIjOw;
            Xb0V9:
            $x8pov->color([185, 185, 185, 1]);
            goto sJoJC;
            owbpn:
            $x8pov->size(max($rNYkq, 1));
            goto Xb0V9;
            qNmJG:
            $rNYkq = (int) ($v6Q0U * 1.2);
            goto owbpn;
            sJoJC:
            $x8pov->valign('middle');
            goto MAAvR;
            Qs4c3:
            $x8pov->file(public_path($this->jsGTU));
            goto qNmJG;
            tIjOw:
        });
        goto jtJIV;
        WThII:
        if (!$this->gErml->exists($hU2b_)) {
            goto WYpwf;
        }
        goto nSoea;
        k032M:
        $OmVZJ -= $DSl1V;
        goto n12Xw;
        BGr6I:
        throw new \RuntimeException("BG2FRpwGrKqJx dimensions are not available.");
        goto Jtvds;
        N6Mh5:
        $DSl1V = (int) ($OmVZJ / 80);
        goto k032M;
        nSoea:
        return $NiewT ? $hU2b_ : $this->gErml->url($hU2b_);
        goto ybggp;
        ybggp:
        WYpwf:
        goto UYYIE;
        Jtvds:
        W0DNf:
        goto FQGrW;
        PSGu9:
        $OmVZJ -= $DSl1V * 0.4;
        goto nIZ1a;
        ZHfzn:
        $this->gErml->put($hU2b_, $VWXEV->stream('png'));
        goto jzfAa;
        UYYIE:
        $VWXEV = $this->jD7oG->call($this, $kc4oX, $lIw1W);
        goto SdWQc;
        n12Xw:
        if (!($kc4oX > 1500)) {
            goto WbCJD;
        }
        goto PSGu9;
        nIZ1a:
        WbCJD:
        goto xuO1q;
        jzfAa:
        return $NiewT ? $hU2b_ : $this->gErml->url($hU2b_);
        goto Ja7PY;
        SdWQc:
        $OmVZJ = $kc4oX - $h2XO3;
        goto N6Mh5;
        xuO1q:
        $gnaTH = $lIw1W - $v6Q0U - 10;
        goto NR_q8;
        kVUV3:
        $hU2b_ = $this->mUnHqZEWu7X($E2IZC, $kc4oX, $lIw1W, $h2XO3, $v6Q0U);
        goto WThII;
        dD96e:
        list($v6Q0U, $h2XO3, $E2IZC) = $this->mCRskFaifC7($SqwFQ, $kc4oX, $NGphH, (float) $kc4oX / $lIw1W);
        goto kVUV3;
        jtJIV:
        $this->yt19t->put($hU2b_, $VWXEV->stream('png'));
        goto ZHfzn;
        Ja7PY:
    }
    private function mUnHqZEWu7X(string $SqwFQ, int $kc4oX, int $lIw1W, int $Pkw4I, int $lBG6H) : string
    {
        $umK2d = ltrim($SqwFQ, '@');
        return "v2/watermark/{$umK2d}/{$kc4oX}x{$lIw1W}_{$Pkw4I}x{$lBG6H}/text_watermark.png";
    }
    private function mCRskFaifC7($SqwFQ, int $kc4oX, float $lvYGG, float $JKeeA) : array
    {
        goto PZGis;
        DUzTn:
        $h2XO3 = (int) ($kc4oX * $lvYGG);
        goto Yopjc;
        Yopjc:
        if (!($JKeeA > 1)) {
            goto VwNJr;
        }
        goto u4NhR;
        JFEbu:
        return [(int) $H97yV, $H97yV * strlen($E2IZC) / 1.8, $E2IZC];
        goto X3f_z;
        u4NhR:
        $H97yV = $h2XO3 / (strlen($E2IZC) * 0.8);
        goto JFEbu;
        X3f_z:
        VwNJr:
        goto rOw5C;
        PZGis:
        $E2IZC = '@' . $SqwFQ;
        goto DUzTn;
        KbU99:
        return [(int) $H97yV, $h2XO3, $E2IZC];
        goto zDdao;
        rOw5C:
        $H97yV = 1 / $JKeeA * $h2XO3 / strlen($E2IZC);
        goto KbU99;
        zDdao:
    }
}
