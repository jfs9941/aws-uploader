<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
class C1begswuMLD8K implements BlurJobInterface
{
    const VyMMp = 15;
    const WkNZV = 500;
    const HuM8M = 500;
    private $z59AQ;
    private $W_Kti;
    private $kxBLk;
    public function __construct($fbqBq, $agzKA, $dgfeu)
    {
        goto FnvQW;
        FnvQW:
        $this->kxBLk = $dgfeu;
        goto sbKGm;
        bf847:
        $this->z59AQ = $fbqBq;
        goto rlzI1;
        sbKGm:
        $this->W_Kti = $agzKA;
        goto bf847;
        rlzI1:
    }
    public function blur(string $y06DH) : void
    {
        goto kjFGD;
        xtlCN:
        $this->kxBLk->put($KI3Rc->filename, $qr3hB);
        goto MgTIU;
        OrDX_:
        $P2AJQ->save($yXh7z);
        goto kTNl7;
        KUhrT:
        throw new \Exception('Failed to set final permissions on image file: ' . $yXh7z);
        goto K3YtB;
        PzKRP:
        $oJEk8 = $this->mtdKgh29brn($KI3Rc);
        goto SiOpI;
        BXIQ1:
        $P2AJQ->blur(self::VyMMp);
        goto PzKRP;
        dDVbX:
        \Log::warning('Failed to set final permissions on image file: ' . $yXh7z);
        goto KUhrT;
        Bnyaw:
        $qr3hB = $this->W_Kti->get($KI3Rc->filename);
        goto xtlCN;
        uy4CX:
        $P2AJQ->resize(self::WkNZV, self::HuM8M / $pUtvf);
        goto BXIQ1;
        QmxVP:
        if (!($KI3Rc->vZVzF == WG4kCv0INtCV4::S3 && !$this->kxBLk->exists($KI3Rc->filename))) {
            goto WToAw;
        }
        goto Bnyaw;
        XFOiV:
        $KI3Rc->update(['preview' => $oJEk8]);
        goto qQjY7;
        BGLo2:
        $P2AJQ = $this->z59AQ->call($this, $this->kxBLk->path($KI3Rc->getLocation()));
        goto Vjnlv;
        kjFGD:
        $KI3Rc = LGMw063tEE9ZC::findOrFail($y06DH);
        goto p3fzf;
        K3YtB:
        poE1C:
        goto XFOiV;
        kTNl7:
        $P2AJQ->destroy();
        goto hjJo0;
        Vjnlv:
        $pUtvf = $P2AJQ->width() / $P2AJQ->height();
        goto uy4CX;
        p3fzf:
        ini_set('memory_limit', '-1');
        goto QmxVP;
        hjJo0:
        if (chmod($yXh7z, 0664)) {
            goto poE1C;
        }
        goto dDVbX;
        MgTIU:
        WToAw:
        goto BGLo2;
        SiOpI:
        $yXh7z = $this->kxBLk->path($oJEk8);
        goto OrDX_;
        qQjY7:
    }
    private function mtdKgh29brn($Ab2Uc) : string
    {
        goto gRpJk;
        jIANN:
        if ($this->kxBLk->exists($vQ3Gb)) {
            goto nv_Ar;
        }
        goto AW_h7;
        R6h61:
        return $vQ3Gb . $Ab2Uc->getFilename() . '.jpg';
        goto qQj6Y;
        AW_h7:
        $this->kxBLk->makeDirectory($vQ3Gb, 0755, true);
        goto iVHPH;
        gRpJk:
        $IB9Pt = $Ab2Uc->getLocation();
        goto vOvAw;
        vOvAw:
        $vQ3Gb = dirname($IB9Pt) . '/preview/';
        goto jIANN;
        iVHPH:
        nv_Ar:
        goto R6h61;
        qQj6Y:
    }
}
