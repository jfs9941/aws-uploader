<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class M3Xmvxbmi1S9y implements StoreToS3JobInterface
{
    private $vn9CJ;
    private $aiw3M;
    private $n8EBo;
    public function __construct($HL7fw, $iay5S, $gdQ3g)
    {
        goto tvhrR;
        tvhrR:
        $this->aiw3M = $iay5S;
        goto nD4G2;
        nD4G2:
        $this->n8EBo = $gdQ3g;
        goto Nz_Px;
        Nz_Px:
        $this->vn9CJ = $HL7fw;
        goto mSWzW;
        mSWzW:
    }
    public function store(string $zV1kl) : void
    {
        goto B5Oai;
        UzTxM:
        $X88bb = $r1gi8->getAttribute('thumbnail');
        goto H8dgN;
        fGa1N:
        return;
        goto ssy64;
        NYALk:
        Log::info("KCmQR4pvm0dT3 has been deleted, discard it", ['fileId' => $zV1kl]);
        goto fGa1N;
        i7wH5:
        NtVPX:
        goto Q59ws;
        Q59ws:
        if (!($r1gi8->getAttribute('preview') && $this->n8EBo->exists($r1gi8->getAttribute('preview')))) {
            goto AdifO;
        }
        goto xk15X;
        ME1Ar:
        $Z0aeL = $this->vn9CJ->call($this, $rxy1g);
        goto Z5R6f;
        Z5R6f:
        $this->aiw3M->put($r1gi8->getAttribute('preview'), $this->n8EBo->get($r1gi8->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $Z0aeL->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto OIZeP;
        DDOk1:
        if (!$r1gi8->update(['driver' => X4ZiOQdPeeHKI::S3, 'status' => M7O7NSiJU2JG5::FINISHED])) {
            goto XRy83;
        }
        goto kcscf;
        NwGpR:
        return;
        goto AmF1s;
        Zey4P:
        $this->aiw3M->put($r1gi8->getAttribute('thumbnail'), $this->n8EBo->get($X88bb), ['visibility' => 'public', 'ContentType' => $X9APK->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto i7wH5;
        VHuf2:
        $this->m0IJcTwItZP($lmTDq, $r1gi8->getLocation());
        goto UzTxM;
        AmF1s:
        XRy83:
        goto qMT1n;
        ssy64:
        Dm0yD:
        goto u8IrI;
        EVzUE:
        KCmQR4pvm0dT3::where('parent_id', $zV1kl)->update(['driver' => X4ZiOQdPeeHKI::S3, 'preview' => $r1gi8->getAttribute('preview'), 'thumbnail' => $r1gi8->getAttribute('thumbnail')]);
        goto NwGpR;
        qMT1n:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $zV1kl]);
        goto fCeTo;
        H3fdY:
        if ($r1gi8) {
            goto Dm0yD;
        }
        goto NYALk;
        kcscf:
        Log::info("KCmQR4pvm0dT3 stored to S3, update the children attachments", ['fileId' => $zV1kl]);
        goto EVzUE;
        u8IrI:
        $lmTDq = $this->n8EBo->path($r1gi8->getLocation());
        goto VHuf2;
        H8dgN:
        if (!($X88bb && $this->n8EBo->exists($X88bb))) {
            goto NtVPX;
        }
        goto AUkj7;
        AUkj7:
        $sQ5Vj = $this->n8EBo->path($X88bb);
        goto JxkKh;
        xk15X:
        $rxy1g = $this->n8EBo->path($r1gi8->getAttribute('preview'));
        goto ME1Ar;
        JxkKh:
        $X9APK = $this->vn9CJ->call($this, $sQ5Vj);
        goto Zey4P;
        B5Oai:
        $r1gi8 = KCmQR4pvm0dT3::findOrFail($zV1kl);
        goto H3fdY;
        OIZeP:
        AdifO:
        goto DDOk1;
        fCeTo:
    }
    private function m0IJcTwItZP($lmRKK, $td5Wt, $eX3H1 = '')
    {
        goto mTu_y;
        mTu_y:
        if (!$eX3H1) {
            goto O9gZF;
        }
        goto zJPNi;
        n5Uj3:
        $td5Wt = str_replace('.jpg', $eX3H1, $td5Wt);
        goto lFVVh;
        Fh8F7:
        try {
            $RD3vr = $this->vn9CJ->call($this, $lmRKK);
            $this->aiw3M->put($td5Wt, $this->n8EBo->get($td5Wt), ['visibility' => 'public', 'ContentType' => $RD3vr->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $VJRSZ) {
            Log::error("Failed to upload image to S3", ['s3Path' => $td5Wt, 'error' => $VJRSZ->getMessage()]);
        }
        goto HxoYD;
        lFVVh:
        O9gZF:
        goto Fh8F7;
        zJPNi:
        $lmRKK = str_replace('.jpg', $eX3H1, $lmRKK);
        goto n5Uj3;
        HxoYD:
    }
}
