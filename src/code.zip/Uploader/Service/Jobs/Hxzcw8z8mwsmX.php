<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Encoder\IA5k3DCuxC3EX;
use Jfs\Uploader\Encoder\InuwBbIMQbzyz;
use Jfs\Uploader\Encoder\Uql37EhjWaxp7;
use Jfs\Uploader\Encoder\NXegFzNpQV853;
use Jfs\Uploader\Encoder\V9kB8ekPBG4Tf;
use Jfs\Uploader\Encoder\VW5Bj7j5VYqGn;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Jfs\Uploader\Service\Jobs\W7OLxskJkGi31;
use Jfs\Uploader\Service\Jobs\Cxaa8rnKaz018;
use Jfs\Uploader\Service\DkSooBIdtZWQo;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class Hxzcw8z8mwsmX implements MediaEncodeJobInterface
{
    private $to1A0;
    private $IA8m0;
    private $f1xKj;
    private $HSLaS;
    private $O1fTR;
    public function __construct(string $QlBWR, $Rgxn3, $C6boj, $TNkgI, $ZSn51)
    {
        goto mU5wp;
        akLEb:
        $this->HSLaS = $TNkgI;
        goto Mvon2;
        Mvon2:
        $this->O1fTR = $ZSn51;
        goto wucYe;
        uRDby:
        $this->IA8m0 = $Rgxn3;
        goto K6yFG;
        mU5wp:
        $this->to1A0 = $QlBWR;
        goto uRDby;
        K6yFG:
        $this->f1xKj = $C6boj;
        goto akLEb;
        wucYe:
    }
    public function encode(string $g5e_r, string $QZS56, $GveX2 = true) : void
    {
        goto nFmNa;
        BqmWY:
        try {
            goto YL7oF;
            qBoLF:
            $GkjMb = $GkjMb->mMWtvVrUnnu(new NXegFzNpQV853($mj1iE));
            goto qsWky;
            A3owH:
            Uc7Py:
            goto Q8utp;
            PbmAa:
            $GkjMb = app(V9kB8ekPBG4Tf::class);
            goto qBoLF;
            NX9Hm:
            Log::info("Set input video for Job", ['s3Uri' => $mj1iE]);
            goto PbmAa;
            tqAnt:
            Log::info("JbxOPjx4A3DUY already has Media Converter Job ID, skip encoding", ['fileId' => $g5e_r, 'jobId' => $Uas5p->getAttribute('aws_media_converter_job_id')]);
            goto dQW6K;
            MSkc_:
            $GkjMb = $GkjMb->mZunF2mARjZ($T07ak);
            goto d2Svr;
            XirXC:
            if (!$ls19A) {
                goto Qe4aT;
            }
            goto Mcxow;
            YL7oF:
            $Uas5p = JbxOPjx4A3DUY::findOrFail($g5e_r);
            goto dVV9r;
            zXJqG:
            if (!($SeDOJ && $vwirX)) {
                goto SFGFg;
            }
            goto InQP9;
            xr2ro:
            LeVeX:
            goto LH6B7;
            nOvej:
            $AU7fI = $this->m0purUA7Qtu($SeDOJ, $vwirX);
            goto zJKZG;
            EqPmf:
            Y0jVT:
            goto L3JcY;
            k8g9y:
            $vwirX = $Uas5p->height();
            goto kec09;
            eD92j:
            if (!$Uas5p->getAttribute('aws_media_converter_job_id')) {
                goto Y0jVT;
            }
            goto tqAnt;
            f_OHk:
            $GkjMb->mvJno8COB69($Q_6na->mNQLRJaaozO($Uas5p));
            goto jeHoP;
            NSbYZ:
            $ls19A = $this->mtDfgqQYkLU($S5eAy, $hAiuI->m1xtUeFcf7X((int) $AU7fI['width'], (int) $AU7fI['height'], $QZS56));
            goto XirXC;
            Mcxow:
            $FDEME = $FDEME->mQ2LDkS55VA($ls19A);
            goto KJh1j;
            pOUfc:
            $FDEME = new InuwBbIMQbzyz('1080p', $AU7fI['width'], $AU7fI['height'], $Uas5p->CMpqu ?? 30);
            goto NSbYZ;
            qsWky:
            $fLUi8 = new InuwBbIMQbzyz('original', $SeDOJ, $vwirX, $Uas5p->CMpqu ?? 30);
            goto tM0LP;
            UYIZQ:
            if (!$ls19A) {
                goto Uc7Py;
            }
            goto oB84C;
            Rt0_w:
            $GkjMb = $GkjMb->mHdZRWLqron($FDEME);
            goto xr2ro;
            uP79R:
            Log::info("Set thumbnail for JbxOPjx4A3DUY Job", ['videoId' => $Uas5p->getAttribute('id'), 'duration' => $Uas5p->getAttribute('duration')]);
            goto dFdqU;
            EqGth:
            $Uas5p->update(['aws_media_converter_job_id' => $g5e_r]);
            goto yyd2a;
            dVV9r:
            Assert::isInstanceOf($Uas5p, JbxOPjx4A3DUY::class);
            goto scdMW;
            zJKZG:
            Log::info("Set 1080p resolution for Job", ['width' => $AU7fI['width'], 'height' => $AU7fI['height'], 'originalWidth' => $SeDOJ, 'originalHeight' => $vwirX]);
            goto pOUfc;
            i34qc:
            $ls19A = $this->mtDfgqQYkLU($S5eAy, $hAiuI->m1xtUeFcf7X($Uas5p->width(), $Uas5p->height(), $QZS56));
            goto UYIZQ;
            jeHoP:
            $S5eAy = app(DkSooBIdtZWQo::class);
            goto GbyM8;
            tM0LP:
            $Q_6na = app(Uql37EhjWaxp7::class);
            goto f_OHk;
            d2Svr:
            $g5e_r = $GkjMb->m3xqNgOuyvH($this->mFSJs74vqIi($Uas5p, $GveX2));
            goto EqGth;
            InQP9:
            if (!$this->mjODBAhnSE3($SeDOJ, $vwirX)) {
                goto LeVeX;
            }
            goto nOvej;
            ZdQ5C:
            throw new MediaConverterException("JbxOPjx4A3DUY {$Uas5p->id} is not S3 driver value = {$Uas5p->driver}");
            goto RxxoZ;
            kec09:
            $mj1iE = $this->mkF9iOg4mRe($Uas5p);
            goto NX9Hm;
            XemQe:
            $GkjMb->mvJno8COB69($Q_6na->mNQLRJaaozO($Uas5p));
            goto zXJqG;
            scdMW:
            if (!($Uas5p->driver != Tq4KHV0o6oTIo::S3)) {
                goto TnkXw;
            }
            goto ZdQ5C;
            LH6B7:
            SFGFg:
            goto uP79R;
            dQW6K:
            return;
            goto EqPmf;
            Q8utp:
            $GkjMb->mHdZRWLqron($fLUi8);
            goto XemQe;
            GbyM8:
            $hAiuI = new Cxaa8rnKaz018($this->HSLaS, $this->O1fTR, $this->f1xKj, $this->IA8m0);
            goto i34qc;
            RxxoZ:
            TnkXw:
            goto eD92j;
            dFdqU:
            $T07ak = new IA5k3DCuxC3EX($Uas5p->getAttribute('duration') ?? 1, 2, $Q_6na->mUN0m6CqieY($Uas5p));
            goto MSkc_;
            KJh1j:
            Qe4aT:
            goto Rt0_w;
            oB84C:
            $fLUi8 = $fLUi8->mQ2LDkS55VA($ls19A);
            goto A3owH;
            L3JcY:
            $SeDOJ = $Uas5p->width();
            goto k8g9y;
            yyd2a:
        } catch (\Exception $lzebJ) {
            goto jg1wl;
            jg1wl:
            Log::warning("JbxOPjx4A3DUY has been deleted, discard it", ['fileId' => $g5e_r, 'err' => $lzebJ->getMessage()]);
            goto NO2PL;
            NO2PL:
            Sentry::captureException($lzebJ);
            goto xrqXv;
            xrqXv:
            return;
            goto Kv9fX;
            Kv9fX:
        }
        goto jHTWe;
        nFmNa:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $g5e_r]);
        goto UQOCp;
        UQOCp:
        ini_set('memory_limit', '-1');
        goto BqmWY;
        jHTWe:
    }
    private function mFSJs74vqIi(JbxOPjx4A3DUY $Uas5p, $GveX2) : bool
    {
        goto NdAjK;
        RyMp7:
        $EGiw4 = (int) round($Uas5p->getAttribute('duration') ?? 0);
        goto EdN2a;
        NdAjK:
        if ($GveX2) {
            goto rsyS3;
        }
        goto BzI_1;
        aaUaH:
        VFi3v:
        goto SJl2L;
        O4ChJ:
        rsyS3:
        goto RyMp7;
        BzI_1:
        return false;
        goto O4ChJ;
        EdN2a:
        switch (true) {
            case $Uas5p->width() * $Uas5p->height() >= 1920 * 1080 && $Uas5p->width() * $Uas5p->height() < 2560 * 1440:
                return $EGiw4 > 30 * 60;
            case $Uas5p->width() * $Uas5p->height() >= 2560 * 1440 && $Uas5p->width() * $Uas5p->height() < 3840 * 2160:
                return $EGiw4 > 15 * 60;
            case $Uas5p->width() * $Uas5p->height() >= 3840 * 2160:
                return $EGiw4 > 10 * 60;
            default:
                return false;
        }
        goto F048y;
        F048y:
        qqJMq:
        goto aaUaH;
        SJl2L:
    }
    private function mtDfgqQYkLU(DkSooBIdtZWQo $S5eAy, string $tgHTl) : ?VW5Bj7j5VYqGn
    {
        goto ebTNw;
        h563E:
        Log::info("Resolve watermark for job with url", ['url' => $tgHTl, 'uri' => $TqHAi]);
        goto HgA07;
        HgA07:
        if (!$TqHAi) {
            goto q5ffV;
        }
        goto L6aZF;
        Byx1K:
        return null;
        goto XgXoj;
        yfM4D:
        q5ffV:
        goto Byx1K;
        L6aZF:
        return new VW5Bj7j5VYqGn($TqHAi, 0, 0, null, null);
        goto yfM4D;
        ebTNw:
        $TqHAi = $S5eAy->meJWmgy6zxn($tgHTl);
        goto h563E;
        XgXoj:
    }
    private function mjODBAhnSE3(int $SeDOJ, int $vwirX) : bool
    {
        return $SeDOJ * $vwirX > 1.5 * (1920 * 1080);
    }
    private function m0purUA7Qtu(int $SeDOJ, int $vwirX) : array
    {
        $iYHLa = new W7OLxskJkGi31($SeDOJ, $vwirX);
        return $iYHLa->m8guPE8fybh();
    }
    private function mkF9iOg4mRe(Fd8NTWwq2cQOc $ufjgt) : string
    {
        goto IZuw4;
        IZuw4:
        if (!($ufjgt->driver == Tq4KHV0o6oTIo::S3)) {
            goto d7JQQ;
        }
        goto LWm08;
        LWm08:
        return 's3://' . $this->to1A0 . '/' . $ufjgt->filename;
        goto SKaXH;
        KW1rA:
        return $this->IA8m0->url($ufjgt->filename);
        goto TBMWF;
        SKaXH:
        d7JQQ:
        goto KW1rA;
        TBMWF:
    }
}
