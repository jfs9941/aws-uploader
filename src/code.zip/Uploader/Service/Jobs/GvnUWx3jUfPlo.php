<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class GvnUWx3jUfPlo
{
    private $y_RMK;
    private $m0Pfo;
    public function __construct(int $AphP1, int $GOnuY)
    {
        goto P6pZC;
        j6fnz:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Dt9ZT;
        bpTCf:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto MT05J;
        ffU9G:
        $this->m0Pfo = $GOnuY;
        goto yJ2h9;
        Dt9ZT:
        g12iF:
        goto kHoc1;
        P6pZC:
        if (!($AphP1 <= 0)) {
            goto j7D8V;
        }
        goto bpTCf;
        iOaVN:
        if (!($GOnuY <= 0)) {
            goto g12iF;
        }
        goto j6fnz;
        MT05J:
        j7D8V:
        goto iOaVN;
        kHoc1:
        $this->y_RMK = $AphP1;
        goto ffU9G;
        yJ2h9:
    }
    private static function mkOsRW6lbRw($oKBeA, string $jWUg5 = 'floor') : int
    {
        goto dSgsM;
        dSgsM:
        if (!(is_int($oKBeA) && $oKBeA % 2 === 0)) {
            goto iHYpz;
        }
        goto omwKm;
        tWjWb:
        return (int) $oKBeA;
        goto EzcxA;
        EzcxA:
        ZQpws:
        goto ILHNT;
        lLANj:
        Q6Llj:
        goto Sh2AU;
        ILHNT:
        switch (strtolower($jWUg5)) {
            case 'ceil':
                return (int) (ceil($oKBeA / 2) * 2);
            case 'round':
                return (int) (round($oKBeA / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($oKBeA / 2) * 2);
        }
        goto rpiZA;
        xbRK0:
        iHYpz:
        goto Wk5zO;
        Wk5zO:
        if (!(is_float($oKBeA) && $oKBeA == floor($oKBeA) && (int) $oKBeA % 2 === 0)) {
            goto ZQpws;
        }
        goto tWjWb;
        rpiZA:
        a9lED:
        goto lLANj;
        omwKm:
        return $oKBeA;
        goto xbRK0;
        Sh2AU:
    }
    public function mfwNBR9UoDO(string $fmDKy = 'floor') : array
    {
        goto P0BWm;
        ayiGV:
        $anveF = 2;
        goto NcK7R;
        K1QD3:
        if (!($anveF < 2)) {
            goto uTzTh;
        }
        goto ayiGV;
        kEXWc:
        $YzPnO = $this->y_RMK * $kqgGs;
        goto VVZY3;
        aWWYQ:
        $DHBJG = 2;
        goto xNqxt;
        N5OA9:
        return ['width' => $DHBJG, 'height' => $anveF];
        goto No6t3;
        NkKLN:
        $anveF = self::mkOsRW6lbRw(round($xDztc), $fmDKy);
        goto Q0IPC;
        xNqxt:
        kidEj:
        goto K1QD3;
        b7ia4:
        $anveF = $l0laY;
        goto PFy7I;
        PFy7I:
        $kqgGs = $anveF / $this->m0Pfo;
        goto kEXWc;
        ouKUS:
        if ($this->y_RMK >= $this->m0Pfo) {
            goto fh4rO;
        }
        goto RCI8m;
        VVZY3:
        $DHBJG = self::mkOsRW6lbRw(round($YzPnO), $fmDKy);
        goto WvN4m;
        HLcet:
        $DHBJG = 0;
        goto QKlQK;
        FM5D3:
        $kqgGs = $DHBJG / $this->y_RMK;
        goto bs9Lb;
        QKlQK:
        $anveF = 0;
        goto ouKUS;
        P0BWm:
        $l0laY = 1080;
        goto HLcet;
        Q0IPC:
        goto R12XQ;
        goto LUusQ;
        PbOQK:
        if (!($DHBJG < 2)) {
            goto kidEj;
        }
        goto aWWYQ;
        bs9Lb:
        $xDztc = $this->m0Pfo * $kqgGs;
        goto NkKLN;
        NcK7R:
        uTzTh:
        goto N5OA9;
        WvN4m:
        R12XQ:
        goto PbOQK;
        RCI8m:
        $DHBJG = $l0laY;
        goto FM5D3;
        LUusQ:
        fh4rO:
        goto b7ia4;
        No6t3:
    }
}
