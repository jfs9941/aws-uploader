<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Illuminate\Support\Facades\Log;
class ZkFu9BPpbLXNU implements StoreVideoToS3JobInterface
{
    private $ZciNb;
    private $VoF9h;
    private $oBaPs;
    public function __construct($G2CsF, $BQ2l1, $paaZf)
    {
        goto tLnpY;
        y9p9y:
        $this->ZciNb = $G2CsF;
        goto HY6uS;
        tLnpY:
        $this->VoF9h = $BQ2l1;
        goto HZgEN;
        HZgEN:
        $this->oBaPs = $paaZf;
        goto y9p9y;
        HY6uS:
    }
    public function store(string $JTwN4) : void
    {
        goto bHxT3;
        YVTaf:
        try {
            goto JSsyd;
            QzyzP:
            goto Fzb_Q;
            goto ai_XC;
            ai_XC:
            frQbR:
            goto RfxCk;
            SXy2F:
            Fzb_Q:
            goto ssNBI;
            WvjOn:
            $CzdgF = $haBzI->uploadPart(['Bucket' => $this->ZciNb, 'Key' => $DQb0q->getLocation(), 'UploadId' => $n7tqz, 'PartNumber' => $LnfFI, 'Body' => fread($trZ6F, $Y2e5D)]);
            goto pJhFw;
            PMuVv:
            $paaZf->delete($DQb0q->getLocation());
            goto I0KLu;
            HnB9r:
            $DQb0q->update(['driver' => A3VATad7gvqZU::S3, 'status' => FdWrko7bmoI4Y::FINISHED]);
            goto PMuVv;
            zvhPn:
            $haBzI->completeMultipartUpload(['Bucket' => $this->ZciNb, 'Key' => $DQb0q->getLocation(), 'UploadId' => $n7tqz, 'MultipartUpload' => ['Parts' => $DvSBV]]);
            goto HnB9r;
            JmYlO:
            $LnfFI = 1;
            goto yOE7m;
            nyuv3:
            $n7tqz = $TXgv0['UploadId'];
            goto JmYlO;
            yOE7m:
            $DvSBV = [];
            goto SXy2F;
            pJhFw:
            $DvSBV[] = ['PartNumber' => $LnfFI, 'ETag' => $CzdgF['ETag']];
            goto scpgg;
            ssNBI:
            if (feof($trZ6F)) {
                goto frQbR;
            }
            goto WvjOn;
            RfxCk:
            fclose($trZ6F);
            goto zvhPn;
            scpgg:
            $LnfFI++;
            goto QzyzP;
            JSsyd:
            $TXgv0 = $haBzI->createMultipartUpload(['Bucket' => $this->ZciNb, 'Key' => $DQb0q->getLocation(), 'ContentType' => $EYp1s, 'ContentDisposition' => 'inline']);
            goto nyuv3;
            I0KLu:
        } catch (AwsException $QtemZ) {
            goto dqu3J;
            vChH_:
            GoteN:
            goto X2J27;
            U3S4u:
            try {
                $haBzI->abortMultipartUpload(['Bucket' => $this->ZciNb, 'Key' => $DQb0q->getLocation(), 'UploadId' => $n7tqz]);
            } catch (AwsException $JYQL2) {
                Log::error('Error aborting multipart upload: ' . $JYQL2->getMessage());
            }
            goto vChH_;
            dqu3J:
            if (!isset($n7tqz)) {
                goto GoteN;
            }
            goto U3S4u;
            X2J27:
            Log::error('Failed to store video: ' . $DQb0q->getLocation() . ' - ' . $QtemZ->getMessage());
            goto ngfUP;
            ngfUP:
        } finally {
            $ZCyht = microtime(true);
            $n3g31 = memory_get_usage();
            $b0QCz = memory_get_peak_usage();
            Log::info('Store MbOYV1VlUGCys to S3 function resource usage', ['imageId' => $JTwN4, 'execution_time_sec' => $ZCyht - $yvtjt, 'memory_usage_mb' => ($n3g31 - $cH3VP) / 1024 / 1024, 'peak_memory_usage_mb' => ($b0QCz - $iPamH) / 1024 / 1024]);
        }
        goto lV3hK;
        jZXbt:
        if ($DQb0q) {
            goto hEGr5;
        }
        goto ojncg;
        JypXM:
        $Y2e5D = 1024 * 1024 * 50;
        goto jU4sG;
        AgpLo:
        $iPamH = memory_get_peak_usage();
        goto YVTaf;
        mm62s:
        $DQb0q = MbOYV1VlUGCys::find($JTwN4);
        goto jZXbt;
        w7N2O:
        Log::error("[ZkFu9BPpbLXNU] File not found, discard it ", ['video' => $DQb0q->getLocation()]);
        goto gKGRF;
        gKGRF:
        return;
        goto psWoN;
        ojncg:
        Log::info("MbOYV1VlUGCys has been deleted, discard it", ['fileId' => $JTwN4]);
        goto qXrmM;
        aFhNH:
        ini_set('memory_limit', '-1');
        goto ZY57H;
        NLHKV:
        $paaZf = $this->oBaPs;
        goto mm62s;
        ZY57H:
        $haBzI = $this->VoF9h->getClient();
        goto NLHKV;
        qXrmM:
        return;
        goto cX22D;
        cv1Q6:
        $trZ6F = $paaZf->readStream($DQb0q->getLocation());
        goto JypXM;
        oT9qA:
        if ($paaZf->exists($DQb0q->getLocation())) {
            goto k18D7;
        }
        goto w7N2O;
        jU4sG:
        $EYp1s = $paaZf->mimeType($DQb0q->getLocation());
        goto oyb30;
        bHxT3:
        Log::info('Storing video (local) to S3', ['fileId' => $JTwN4, 'bucketName' => $this->ZciNb]);
        goto aFhNH;
        cX22D:
        hEGr5:
        goto oT9qA;
        kiAji:
        $cH3VP = memory_get_usage();
        goto AgpLo;
        psWoN:
        k18D7:
        goto cv1Q6;
        oyb30:
        $yvtjt = microtime(true);
        goto kiAji;
        lV3hK:
    }
}
