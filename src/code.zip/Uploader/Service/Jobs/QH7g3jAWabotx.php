<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
class QH7g3jAWabotx implements BlurVideoJobInterface
{
    const A0QeR = 15;
    const TNZPU = 500;
    const DXY2M = 500;
    private $bg_1H;
    private $auR_S;
    private $P6k4O;
    public function __construct($IDVBi, $JhAxH, $RNTis)
    {
        goto tWRlN;
        WQy7r:
        $this->bg_1H = $IDVBi;
        goto Es0V0;
        tWRlN:
        $this->P6k4O = $RNTis;
        goto omsGK;
        omsGK:
        $this->auR_S = $JhAxH;
        goto WQy7r;
        Es0V0:
    }
    public function blur(string $IaHim) : void
    {
        goto uqPec;
        Gyuhf:
        if (chmod($YwiJ7, 0664)) {
            goto BsZZE;
        }
        goto ZFbLb;
        w2OJX:
        $SY1xU = $kHreC->width() / $kHreC->height();
        goto Sbt7P;
        p4C_8:
        if (!$rVeWD->getAttribute('thumbnail')) {
            goto k4Yna;
        }
        goto N1aNd;
        uqPec:
        Log::info("Blurring for video", ['videoID' => $IaHim]);
        goto f_6zG;
        O4wJ4:
        $rVeWD->update(['preview' => $dkqps]);
        goto UCqLC;
        mdExL:
        $rVeWD = ACdpgX4YCYP6M::findOrFail($IaHim);
        goto p4C_8;
        NOdiZ:
        $YwiJ7 = $this->P6k4O->path($dkqps);
        goto nvoyP;
        nvoyP:
        $kHreC->save($YwiJ7);
        goto dmv3C;
        Sbt7P:
        $kHreC->resize(self::TNZPU, self::DXY2M / $SY1xU);
        goto DNC9W;
        ZFbLb:
        \Log::warning('Failed to set final permissions on image file: ' . $YwiJ7);
        goto fOWTt;
        ffhN7:
        $dkqps = $this->mvvrF4Zg2fO($rVeWD);
        goto NOdiZ;
        WjtER:
        BsZZE:
        goto O4wJ4;
        dmv3C:
        $this->auR_S->put($dkqps, $this->P6k4O->get($dkqps));
        goto F0GyO;
        fOWTt:
        throw new \Exception('Failed to set final permissions on image file: ' . $YwiJ7);
        goto WjtER;
        UCqLC:
        k4Yna:
        goto E45gu;
        u2rFC:
        $kHreC = $this->bg_1H->call($this, $this->P6k4O->path($rVeWD->getAttribute('thumbnail')));
        goto w2OJX;
        DNC9W:
        $kHreC->blur(self::A0QeR);
        goto ffhN7;
        N1aNd:
        $this->P6k4O->put($rVeWD->getAttribute('thumbnail'), $this->auR_S->get($rVeWD->getAttribute('thumbnail')));
        goto u2rFC;
        f_6zG:
        ini_set('memory_limit', '-1');
        goto mdExL;
        F0GyO:
        $kHreC->destroy();
        goto Gyuhf;
        E45gu:
    }
    private function mvvrF4Zg2fO(GYWdiuSbqNHgT $CArXB) : string
    {
        goto YYObQ;
        XGvpA:
        LUozN:
        goto W2ymH;
        W2ymH:
        return $ho7V0 . $CArXB->getFilename() . '.jpg';
        goto sbNUS;
        BNECa:
        if ($this->P6k4O->exists($ho7V0)) {
            goto LUozN;
        }
        goto QKUZQ;
        YYObQ:
        $JM0UK = $CArXB->getLocation();
        goto jn1n5;
        jn1n5:
        $ho7V0 = dirname($JM0UK) . '/preview/';
        goto BNECa;
        QKUZQ:
        $this->P6k4O->makeDirectory($ho7V0, 0755, true);
        goto XGvpA;
        sbNUS:
    }
}
