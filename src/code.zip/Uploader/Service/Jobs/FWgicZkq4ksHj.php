<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
class FWgicZkq4ksHj implements DownloadToLocalJobInterface
{
    private $RaPnW;
    private $FFBPk;
    public function __construct($hTkyv, $GHkBm)
    {
        $this->RaPnW = $hTkyv;
        $this->FFBPk = $GHkBm;
    }
    public function download(string $UcmDx) : void
    {
        goto G4ntH;
        ow5FJ:
        if (!$this->FFBPk->exists($QxvEM->getLocation())) {
            goto qasRE;
        }
        goto Yv36F;
        Yv36F:
        return;
        goto IT1uq;
        eLxTv:
        $this->FFBPk->put($QxvEM->getLocation(), $this->RaPnW->get($QxvEM->getLocation()));
        goto JlfFk;
        hH66y:
        Log::info("Start download file to local", ['fileId' => $UcmDx, 'filename' => $QxvEM->getLocation()]);
        goto ow5FJ;
        G4ntH:
        $QxvEM = HSe6BNUpJTSwE::findOrFail($UcmDx);
        goto hH66y;
        IT1uq:
        qasRE:
        goto eLxTv;
        JlfFk:
    }
}
