<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class LDCjQXRpUGi7G implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $arqvy) : void
    {
        goto dSDzr;
        dSDzr:
        $XFeNv = RhSx2q5xIlh0Y::findOrFail($arqvy);
        goto rpp2q;
        T4gYn:
        kVVkM:
        goto ArpJ1;
        rpp2q:
        if ($XFeNv->width() > 0 && $XFeNv->height() > 0) {
            goto kVVkM;
        }
        goto D8F1p;
        D8F1p:
        $this->mtlIQvkNSrf($XFeNv);
        goto T4gYn;
        ArpJ1:
    }
    private function mtlIQvkNSrf(RhSx2q5xIlh0Y $pCAnX) : void
    {
        goto cYRqi;
        cYRqi:
        $rjTdY = $pCAnX->getView();
        goto F0YXo;
        F0YXo:
        $Nb_Od = FFMpeg::fromDisk($rjTdY['path'])->open($pCAnX->getAttribute('filename'));
        goto s_WDX;
        KP59X:
        $pCAnX->update(['duration' => $Nb_Od->getDurationInSeconds(), 'resolution' => $nYn97->getWidth() . 'x' . $nYn97->getHeight(), 'fps' => $q7O3r->get('r_frame_rate') ?? 30]);
        goto GaZsu;
        s_WDX:
        $q7O3r = $Nb_Od->getVideoStream();
        goto YVzYh;
        YVzYh:
        $nYn97 = $q7O3r->getDimensions();
        goto KP59X;
        GaZsu:
    }
}
