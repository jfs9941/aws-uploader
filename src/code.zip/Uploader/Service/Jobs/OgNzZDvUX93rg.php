<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
class OgNzZDvUX93rg implements WatermarkTextJobInterface
{
    private $z59AQ;
    private $BmRID;
    private $TOG_e;
    private $W_Kti;
    private $N3F9R;
    public function __construct($fbqBq, $VtFJQ, $agzKA, $mFX9i, $YnMxx)
    {
        goto nDR3k;
        o620T:
        $this->N3F9R = $mFX9i;
        goto h_717;
        nDR3k:
        $this->z59AQ = $fbqBq;
        goto tk32B;
        GikVx:
        $this->BmRID = $VtFJQ;
        goto uo4VS;
        h_717:
        $this->TOG_e = $YnMxx;
        goto GikVx;
        tk32B:
        $this->W_Kti = $agzKA;
        goto o620T;
        uo4VS:
    }
    public function putWatermark(string $y06DH, string $Hx65l) : void
    {
        goto sB6Zz;
        sB6Zz:
        Log::info("Adding watermark text to image", ['imageId' => $y06DH]);
        goto b2GLN;
        b2GLN:
        ini_set('memory_limit', '-1');
        goto Y1Wht;
        Y1Wht:
        try {
            goto EkROj;
            R4_86:
            return;
            goto vBwYI;
            bstwy:
            $IB9Pt = $this->N3F9R->path($P2AJQ->getLocation());
            goto ZF_Cc;
            UK4Ku:
            \Log::warning('Failed to set final permissions on image file: ' . $IB9Pt);
            goto q3LRE;
            aPFIa:
            if (chmod($IB9Pt, 0664)) {
                goto K10MA;
            }
            goto UK4Ku;
            YVItL:
            $xO50j->save($IB9Pt);
            goto xe5fb;
            aJRJV:
            $this->mzfZmpJP7Yt($xO50j, $Hx65l);
            goto YVItL;
            ZF_Cc:
            $xO50j = $this->z59AQ->call($this, $IB9Pt);
            goto gmahA;
            xe5fb:
            $xO50j->destroy();
            goto aPFIa;
            vBwYI:
            UGEPr:
            goto bstwy;
            EkROj:
            $P2AJQ = LGMw063tEE9ZC::findOrFail($y06DH);
            goto fORpn;
            q3LRE:
            throw new \Exception('Failed to set final permissions on image file: ' . $IB9Pt);
            goto Cw6P8;
            fORpn:
            if ($this->N3F9R->exists($P2AJQ->getLocation())) {
                goto UGEPr;
            }
            goto Lq1Pt;
            Cw6P8:
            K10MA:
            goto D6V1N;
            gmahA:
            $xO50j->orientate();
            goto aJRJV;
            Lq1Pt:
            Log::error("LGMw063tEE9ZC is not on local, might be deleted before put watermark", ['imageId' => $y06DH]);
            goto R4_86;
            D6V1N:
        } catch (\Throwable $v3r4O) {
            goto vM3IR;
            okC0D:
            Log::info("LGMw063tEE9ZC has been deleted, discard it", ['imageId' => $y06DH]);
            goto IvNPw;
            vM3IR:
            if (!$v3r4O instanceof ModelNotFoundException) {
                goto VWYyi;
            }
            goto okC0D;
            f75GO:
            Log::error("LGMw063tEE9ZC is not readable", ['imageId' => $y06DH, 'error' => $v3r4O->getMessage()]);
            goto TQapo;
            IvNPw:
            return;
            goto Jwbbp;
            Jwbbp:
            VWYyi:
            goto f75GO;
            TQapo:
        }
        goto k1OFl;
        k1OFl:
    }
    private function mzfZmpJP7Yt($xO50j, $Hx65l) : void
    {
        goto CRgBs;
        Vh_5O:
        $this->N3F9R->put($KxtDu, $this->W_Kti->get($KxtDu));
        goto Ku0e8;
        gUcEh:
        $HPU1j->opacity(35);
        goto DNTr0;
        DNTr0:
        $xO50j->insert($HPU1j);
        goto Vjj7K;
        qix1T:
        $Q2TKK = new UiLxI3bJTv3i0($this->BmRID, $this->TOG_e, $this->W_Kti, $this->N3F9R);
        goto PZTZf;
        Ku0e8:
        $HPU1j = $this->z59AQ->call($this, $this->N3F9R->path($KxtDu));
        goto gUcEh;
        DwqgV:
        $Mq4V6 = $xO50j->height();
        goto qix1T;
        PZTZf:
        $KxtDu = $Q2TKK->mShOxL4HISe($K2lK4, $Mq4V6, $Hx65l, true);
        goto Vh_5O;
        CRgBs:
        $K2lK4 = $xO50j->width();
        goto DwqgV;
        Vjj7K:
    }
}
