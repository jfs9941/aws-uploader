<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class GBvckri6SF7xg implements StoreVideoToS3JobInterface
{
    private $rHBC5;
    private $gGE8I;
    private $xbA_A;
    public function __construct($TnK9g, $duBfR, $a_5ue)
    {
        goto n2n3c;
        X5xcI:
        $this->rHBC5 = $TnK9g;
        goto uKqFK;
        cXr1V:
        $this->xbA_A = $a_5ue;
        goto X5xcI;
        n2n3c:
        $this->gGE8I = $duBfR;
        goto cXr1V;
        uKqFK:
    }
    public function store(string $ld8Ad) : void
    {
        goto QJXxX;
        ZaHMH:
        $p0d_Z = microtime(true);
        goto LlIK4;
        BsxEf:
        return;
        goto Njenu;
        eC6qs:
        $a_5ue = $this->xbA_A;
        goto wwuW_;
        vODIU:
        if ($gupDM) {
            goto BolrQ;
        }
        goto Xwkot;
        LlIK4:
        $BpzCH = memory_get_usage();
        goto lcREc;
        oRJjy:
        $TZqXq = 1024 * 1024 * 50;
        goto tH9v_;
        V9nmx:
        $EN0Ik = $a_5ue->readStream($gupDM->getLocation());
        goto oRJjy;
        QJXxX:
        Log::info('Storing video (local) to S3', ['fileId' => $ld8Ad, 'bucketName' => $this->rHBC5]);
        goto VU3c9;
        aVZM8:
        $Ahfya = $this->gGE8I->getClient();
        goto eC6qs;
        UYEmv:
        Log::error("[GBvckri6SF7xg] File not found, discard it ", ['video' => $gupDM->getLocation()]);
        goto BsxEf;
        wwuW_:
        $gupDM = RVcEF1JsGQd8M::find($ld8Ad);
        goto vODIU;
        te754:
        return;
        goto lTU3w;
        VU3c9:
        ini_set('memory_limit', '-1');
        goto aVZM8;
        lcREc:
        $VBJ1E = memory_get_peak_usage();
        goto jAJ9t;
        jAJ9t:
        try {
            goto VL3KN;
            VL3KN:
            $G4taM = $Ahfya->createMultipartUpload(['Bucket' => $this->rHBC5, 'Key' => $gupDM->getLocation(), 'ContentType' => $ImFse, 'ContentDisposition' => 'inline']);
            goto M2Zaw;
            EWwoA:
            $a_5ue->delete($gupDM->getLocation());
            goto FTHCB;
            nZAE9:
            $IDZ5l = [];
            goto ll20n;
            sk9eu:
            $gupDM->update(['driver' => ZBLpZ2qUZ4P6C::S3, 'status' => UimQKBIuLCEAO::FINISHED]);
            goto EWwoA;
            RSwR8:
            $llg6u = 1;
            goto nZAE9;
            VIFXo:
            fclose($EN0Ik);
            goto IEtzw;
            oZz3c:
            goto kZaPD;
            goto vGRRs;
            mpsr8:
            $IDZ5l[] = ['PartNumber' => $llg6u, 'ETag' => $m2Ano['ETag']];
            goto Leng_;
            IEtzw:
            $Ahfya->completeMultipartUpload(['Bucket' => $this->rHBC5, 'Key' => $gupDM->getLocation(), 'UploadId' => $y1uXc, 'MultipartUpload' => ['Parts' => $IDZ5l]]);
            goto sk9eu;
            RYIAJ:
            $m2Ano = $Ahfya->uploadPart(['Bucket' => $this->rHBC5, 'Key' => $gupDM->getLocation(), 'UploadId' => $y1uXc, 'PartNumber' => $llg6u, 'Body' => fread($EN0Ik, $TZqXq)]);
            goto mpsr8;
            M2Zaw:
            $y1uXc = $G4taM['UploadId'];
            goto RSwR8;
            Leng_:
            $llg6u++;
            goto oZz3c;
            ll20n:
            kZaPD:
            goto zeuj7;
            zeuj7:
            if (feof($EN0Ik)) {
                goto wgX0c;
            }
            goto RYIAJ;
            vGRRs:
            wgX0c:
            goto VIFXo;
            FTHCB:
        } catch (AwsException $nXJFP) {
            goto LXpjZ;
            nXJmB:
            try {
                $Ahfya->abortMultipartUpload(['Bucket' => $this->rHBC5, 'Key' => $gupDM->getLocation(), 'UploadId' => $y1uXc]);
            } catch (AwsException $y0sfh) {
                Log::error('Error aborting multipart upload: ' . $y0sfh->getMessage());
            }
            goto J_Nso;
            J_Nso:
            bWf5U:
            goto ub7ja;
            LXpjZ:
            if (!isset($y1uXc)) {
                goto bWf5U;
            }
            goto nXJmB;
            ub7ja:
            Log::error('Failed to store video: ' . $gupDM->getLocation() . ' - ' . $nXJFP->getMessage());
            goto q797Z;
            q797Z:
        } finally {
            $RZBdd = microtime(true);
            $s2S1x = memory_get_usage();
            $J0pU0 = memory_get_peak_usage();
            Log::info('Store RVcEF1JsGQd8M to S3 function resource usage', ['imageId' => $ld8Ad, 'execution_time_sec' => $RZBdd - $p0d_Z, 'memory_usage_mb' => ($s2S1x - $BpzCH) / 1024 / 1024, 'peak_memory_usage_mb' => ($J0pU0 - $VBJ1E) / 1024 / 1024]);
        }
        goto uWF26;
        Xwkot:
        Log::info("RVcEF1JsGQd8M has been deleted, discard it", ['fileId' => $ld8Ad]);
        goto te754;
        Njenu:
        a1jVp:
        goto V9nmx;
        tH9v_:
        $ImFse = $a_5ue->mimeType($gupDM->getLocation());
        goto ZaHMH;
        lTU3w:
        BolrQ:
        goto piIra;
        piIra:
        if ($a_5ue->exists($gupDM->getLocation())) {
            goto a1jVp;
        }
        goto UYEmv;
        uWF26:
    }
}
