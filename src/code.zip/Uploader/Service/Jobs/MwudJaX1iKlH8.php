<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class MwudJaX1iKlH8
{
    private $z5gsb;
    private $o2VY1;
    private $m2kWg;
    private $BX0zD;
    public function __construct($ydoZC, $mjAYO, $Npup8, $MKJ1D)
    {
        goto vzXi4;
        YPe4P:
        $this->z5gsb = $ydoZC;
        goto ubFpn;
        OeHr3:
        $this->BX0zD = $MKJ1D;
        goto YPe4P;
        sCUZ4:
        $this->m2kWg = $Npup8;
        goto OeHr3;
        vzXi4:
        $this->o2VY1 = $mjAYO;
        goto sCUZ4;
        ubFpn:
    }
    public function mljISqrPrHy(?int $p9c0Q, ?int $erqpi, string $li4hO, bool $KCXdy = false) : string
    {
        goto iK8ny;
        U7lT4:
        $this->m2kWg->put($F0ycc, $Kc1eZ->stream('png'));
        goto nsdjt;
        Ijsvq:
        if (!$this->m2kWg->exists($F0ycc)) {
            goto RDL2v;
        }
        goto tov85;
        k36FR:
        A90Tm:
        goto ZiOXt;
        W4G3M:
        throw new \RuntimeException("HVuLZHLrSam0d dimensions are not available.");
        goto X4MUm;
        nsdjt:
        return $KCXdy ? $F0ycc : $this->m2kWg->url($F0ycc);
        goto CfpNR;
        kiUox:
        $Kc1eZ->text($tr04q, $Q0w5q, (int) $jtzAa, function ($ziI1C) use($jXzsV) {
            goto Anltk;
            q0L1b:
            $ziI1C->valign('middle');
            goto qtNoC;
            mzcPK:
            $PrtTK = (int) ($jXzsV * 1.2);
            goto LQFGx;
            Anltk:
            $ziI1C->file(public_path($this->o2VY1));
            goto mzcPK;
            qtNoC:
            $ziI1C->align('middle');
            goto tFiJU;
            LQFGx:
            $ziI1C->size(max($PrtTK, 1));
            goto LLGLL;
            LLGLL:
            $ziI1C->color([185, 185, 185, 1]);
            goto q0L1b;
            tFiJU:
        });
        goto slQuN;
        tov85:
        return $KCXdy ? $F0ycc : $this->m2kWg->url($F0ycc);
        goto kF0Iv;
        VCcwS:
        if (!($p9c0Q > 1500)) {
            goto A90Tm;
        }
        goto kWlqC;
        ezG7h:
        $mn3ir = 0.1;
        goto S829D;
        ZiOXt:
        $jtzAa = $erqpi - $jXzsV - 10;
        goto kiUox;
        kWlqC:
        $Q0w5q -= $OZKMk * 0.4;
        goto k36FR;
        eeTeb:
        $Kc1eZ = $this->z5gsb->call($this, $p9c0Q, $erqpi);
        goto HDu9E;
        S829D:
        list($jXzsV, $Wzt0K, $tr04q) = $this->mzz5t38AaQy($li4hO, $p9c0Q, $mn3ir, (float) $p9c0Q / $erqpi);
        goto kxPWN;
        D0inf:
        $OZKMk = (int) ($Q0w5q / 80);
        goto af4R4;
        iK8ny:
        if (!($p9c0Q === null || $erqpi === null)) {
            goto irmLX;
        }
        goto W4G3M;
        X4MUm:
        irmLX:
        goto ezG7h;
        kF0Iv:
        RDL2v:
        goto eeTeb;
        slQuN:
        $this->BX0zD->put($F0ycc, $Kc1eZ->stream('png'));
        goto U7lT4;
        kxPWN:
        $F0ycc = $this->mH2XWeD6H8g($tr04q, $p9c0Q, $erqpi, $Wzt0K, $jXzsV);
        goto Ijsvq;
        af4R4:
        $Q0w5q -= $OZKMk;
        goto VCcwS;
        HDu9E:
        $Q0w5q = $p9c0Q - $Wzt0K;
        goto D0inf;
        CfpNR:
    }
    private function mH2XWeD6H8g(string $li4hO, int $p9c0Q, int $erqpi, int $aN8w5, int $ovCw_) : string
    {
        $f2tS2 = ltrim($li4hO, '@');
        return "v2/watermark/{$f2tS2}/{$p9c0Q}x{$erqpi}_{$aN8w5}x{$ovCw_}/text_watermark.png";
    }
    private function mzz5t38AaQy($li4hO, int $p9c0Q, float $Okcqe, float $WT0iE) : array
    {
        goto lMwtB;
        lMwtB:
        $tr04q = '@' . $li4hO;
        goto t77E4;
        QEYvG:
        return [(int) $lVlFe, $Wzt0K, $tr04q];
        goto hN3lY;
        bA_63:
        return [(int) $lVlFe, $lVlFe * strlen($tr04q) / 1.8, $tr04q];
        goto LLDRr;
        TSaUd:
        if (!($WT0iE > 1)) {
            goto c0J2t;
        }
        goto DV_C6;
        DV_C6:
        $lVlFe = $Wzt0K / (strlen($tr04q) * 0.8);
        goto bA_63;
        a1d4R:
        $lVlFe = 1 / $WT0iE * $Wzt0K / strlen($tr04q);
        goto QEYvG;
        LLDRr:
        c0J2t:
        goto a1d4R;
        t77E4:
        $Wzt0K = (int) ($p9c0Q * $Okcqe);
        goto TSaUd;
        hN3lY:
    }
}
