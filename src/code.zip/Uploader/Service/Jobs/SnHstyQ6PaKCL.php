<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class SnHstyQ6PaKCL implements GenerateThumbnailJobInterface
{
    const JDAdP = 150;
    const VfFIV = 150;
    private $X2VAb;
    private $nEL6Z;
    private $uykKi;
    public function __construct($aC0aM, $vWt2S, $sAVES)
    {
        goto SD0PG;
        SD0PG:
        $this->X2VAb = $aC0aM;
        goto cTj5X;
        cTj5X:
        $this->nEL6Z = $vWt2S;
        goto VWMT7;
        VWMT7:
        $this->uykKi = $sAVES;
        goto kZPAW;
        kZPAW:
    }
    public function generate(string $iG1wy)
    {
        goto eh3A8;
        fnd0z:
        ini_set('memory_limit', '-1');
        goto O9Spo;
        eh3A8:
        Log::info("Generating thumbnail", ['imageId' => $iG1wy]);
        goto fnd0z;
        O9Spo:
        try {
            goto NrhEC;
            gd0Qc:
            $W3g7x = $this->X2VAb->call($this, $e3uVO->path($cDDGh->getLocation()));
            goto fxdDP;
            QfWoE:
            $cDDGh->update(['thumbnail' => $HCRCz, 'status' => Zgh3BZ2JVlG1A::THUMBNAIL_PROCESSED]);
            goto ZVlIM;
            ABF_J:
            $cDDGh = KyoDVfv3eGItF::findOrFail($iG1wy);
            goto gd0Qc;
            IL6fd:
            $MOpJ6 = $this->uykKi->put($HCRCz, $W3g7x->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto eaSmk;
            tpCAe:
            if (!($MOpJ6 !== false)) {
                goto YVUlU;
            }
            goto QfWoE;
            fxdDP:
            $W3g7x->orient()->resize(150, 150);
            goto YodkM;
            ZVlIM:
            YVUlU:
            goto VjJFF;
            YodkM:
            $HCRCz = $this->mWZUIOYeINf($cDDGh);
            goto IL6fd;
            eaSmk:
            unset($W3g7x);
            goto tpCAe;
            NrhEC:
            $e3uVO = $this->nEL6Z;
            goto ABF_J;
            VjJFF:
        } catch (ModelNotFoundException $WqnXx) {
            Log::info("KyoDVfv3eGItF has been deleted, discard it", ['imageId' => $iG1wy]);
            return;
        } catch (\Exception $WqnXx) {
            Log::error("Failed to generate thumbnail", ['imageId' => $iG1wy, 'error' => $WqnXx->getMessage()]);
        }
        goto NIZ5B;
        NIZ5B:
    }
    private function mWZUIOYeINf(GSmU4C9IL4AGB $cDDGh) : string
    {
        goto B0cTV;
        QdKgO:
        $qmsbj = dirname($HCRCz);
        goto YMUpR;
        nWDFN:
        return $y8ZBA . '/' . $cDDGh->getFilename() . '.jpg';
        goto pMuHL;
        YMUpR:
        $y8ZBA = $qmsbj . '/' . self::JDAdP . 'X' . self::VfFIV;
        goto nWDFN;
        B0cTV:
        $HCRCz = $cDDGh->getLocation();
        goto QdKgO;
        pMuHL:
    }
}
