<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Illuminate\Support\Facades\Log;
class GYvWgtOURv76a implements BlurVideoJobInterface
{
    const QST3M = 15;
    const vvzG4 = 500;
    const Ott5c = 500;
    private $GqFb6;
    private $BfyCm;
    private $S0euz;
    public function __construct($WV89v, $ejImE, $t9rFg)
    {
        goto K70aX;
        JYruR:
        $this->BfyCm = $ejImE;
        goto N9GaU;
        N9GaU:
        $this->GqFb6 = $WV89v;
        goto rcFrz;
        K70aX:
        $this->S0euz = $t9rFg;
        goto JYruR;
        rcFrz:
    }
    public function blur(string $aK0gt) : void
    {
        goto Ro4b6;
        hwA7J:
        $qKtXa->save($e78sf);
        goto LbdQn;
        mcUes:
        $this->S0euz->put($EaQ0R->getAttribute('thumbnail'), $this->BfyCm->get($EaQ0R->getAttribute('thumbnail')));
        goto SDu9V;
        r94bs:
        $EaQ0R->update(['preview' => $SjjXB]);
        goto jNi38;
        uQLf9:
        \Log::warning('Failed to set final permissions on image file: ' . $e78sf);
        goto M1Gjl;
        O5bH8:
        $EaQ0R = IfBHv1AJhiIDu::findOrFail($aK0gt);
        goto plylP;
        Ro4b6:
        Log::info("Blurring for video", ['videoID' => $aK0gt]);
        goto qqOGZ;
        XyDxU:
        $e78sf = $this->S0euz->path($SjjXB);
        goto hwA7J;
        SDu9V:
        $qKtXa = $this->GqFb6->call($this, $this->S0euz->path($EaQ0R->getAttribute('thumbnail')));
        goto Syvcl;
        M1Gjl:
        throw new \Exception('Failed to set final permissions on image file: ' . $e78sf);
        goto Jw1V6;
        ak3V9:
        if (chmod($e78sf, 0664)) {
            goto qR8St;
        }
        goto uQLf9;
        H01He:
        $qKtXa->resize(self::vvzG4, self::Ott5c / $e61mr);
        goto lFDsw;
        Jw1V6:
        qR8St:
        goto r94bs;
        lFDsw:
        $qKtXa->blur(self::QST3M);
        goto SPqMW;
        jNi38:
        j8k9A:
        goto nhcPK;
        qqOGZ:
        ini_set('memory_limit', '-1');
        goto O5bH8;
        plylP:
        if (!$EaQ0R->getAttribute('thumbnail')) {
            goto j8k9A;
        }
        goto mcUes;
        SPqMW:
        $SjjXB = $this->mG102AKvrVC($EaQ0R);
        goto XyDxU;
        LbdQn:
        $this->BfyCm->put($SjjXB, $this->S0euz->get($SjjXB));
        goto OqJl0;
        Syvcl:
        $e61mr = $qKtXa->width() / $qKtXa->height();
        goto H01He;
        OqJl0:
        unset($qKtXa);
        goto ak3V9;
        nhcPK:
    }
    private function mG102AKvrVC(WGN88W9AFumiX $bBmy0) : string
    {
        goto ilg3o;
        K1K33:
        etSxm:
        goto lpq5L;
        MwcfI:
        $ODUZC = dirname($HyAAV) . '/preview/';
        goto ErEs5;
        nts9N:
        $this->S0euz->makeDirectory($ODUZC, 0755, true);
        goto K1K33;
        ilg3o:
        $HyAAV = $bBmy0->getLocation();
        goto MwcfI;
        ErEs5:
        if ($this->S0euz->exists($ODUZC)) {
            goto etSxm;
        }
        goto nts9N;
        lpq5L:
        return $ODUZC . $bBmy0->getFilename() . '.jpg';
        goto BcI8A;
        BcI8A:
    }
}
