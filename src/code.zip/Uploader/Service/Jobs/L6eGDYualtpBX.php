<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class L6eGDYualtpBX implements StoreVideoToS3JobInterface
{
    private $JUv2O;
    private $Vhcrn;
    private $riMoE;
    public function __construct($E6K8y, $Klx1U, $BP_p5)
    {
        goto qkmwE;
        qkmwE:
        $this->Vhcrn = $Klx1U;
        goto zZURa;
        zZURa:
        $this->riMoE = $BP_p5;
        goto Raz9G;
        Raz9G:
        $this->JUv2O = $E6K8y;
        goto tQqeh;
        tQqeh:
    }
    public function store(string $mfjeD) : void
    {
        goto qGoiI;
        S1VDL:
        $SzJ39 = $BP_p5->readStream($EUi5K->getLocation());
        goto XR6ar;
        wSWA3:
        try {
            goto KpOqM;
            aIWRY:
            fclose($SzJ39);
            goto Drwhk;
            LPdMf:
            $iHezl = [];
            goto DLf20;
            K5cmA:
            $QYzFj++;
            goto RfuiA;
            jP1jT:
            if (feof($SzJ39)) {
                goto PQl2z;
            }
            goto DDK6t;
            KbBMl:
            $iHezl[] = ['PartNumber' => $QYzFj, 'ETag' => $FS514['ETag']];
            goto K5cmA;
            RfuiA:
            goto zVq3T;
            goto jSaZO;
            pph17:
            $QYzFj = 1;
            goto LPdMf;
            KpOqM:
            $fC1nN = $T1p3q->createMultipartUpload(['Bucket' => $this->JUv2O, 'Key' => $EUi5K->getLocation(), 'ContentType' => $g2xfP, 'ContentDisposition' => 'inline']);
            goto FyysM;
            FyysM:
            $oKtdH = $fC1nN['UploadId'];
            goto pph17;
            Drwhk:
            $T1p3q->completeMultipartUpload(['Bucket' => $this->JUv2O, 'Key' => $EUi5K->getLocation(), 'UploadId' => $oKtdH, 'MultipartUpload' => ['Parts' => $iHezl]]);
            goto n4k1S;
            jSaZO:
            PQl2z:
            goto aIWRY;
            buwZv:
            $BP_p5->delete($EUi5K->getLocation());
            goto RDkcG;
            DDK6t:
            $FS514 = $T1p3q->uploadPart(['Bucket' => $this->JUv2O, 'Key' => $EUi5K->getLocation(), 'UploadId' => $oKtdH, 'PartNumber' => $QYzFj, 'Body' => fread($SzJ39, $SfZkF)]);
            goto KbBMl;
            n4k1S:
            $EUi5K->update(['driver' => GTmWxMidiCuj0::S3, 'status' => SwAwanZG36Yx6::FINISHED]);
            goto buwZv;
            DLf20:
            zVq3T:
            goto jP1jT;
            RDkcG:
        } catch (AwsException $iE7wL) {
            goto AKQDq;
            eosim:
            qIyW3:
            goto io59G;
            u8Av5:
            try {
                $T1p3q->abortMultipartUpload(['Bucket' => $this->JUv2O, 'Key' => $EUi5K->getLocation(), 'UploadId' => $oKtdH]);
            } catch (AwsException $kBLHG) {
                Log::error('Error aborting multipart upload: ' . $kBLHG->getMessage());
            }
            goto eosim;
            io59G:
            Log::error('Failed to store video: ' . $EUi5K->getLocation() . ' - ' . $iE7wL->getMessage());
            goto BxgV3;
            AKQDq:
            if (!isset($oKtdH)) {
                goto qIyW3;
            }
            goto u8Av5;
            BxgV3:
        } finally {
            $j9xjg = microtime(true);
            $dJyQx = memory_get_usage();
            $RXP3o = memory_get_peak_usage();
            Log::info('Store ZSB2cdrwtZpmk to S3 function resource usage', ['imageId' => $mfjeD, 'execution_time_sec' => $j9xjg - $QEw_Q, 'memory_usage_mb' => ($dJyQx - $HmKOk) / 1024 / 1024, 'peak_memory_usage_mb' => ($RXP3o - $ghcvh) / 1024 / 1024]);
        }
        goto uFT8N;
        P831a:
        Log::info("ZSB2cdrwtZpmk has been deleted, discard it", ['fileId' => $mfjeD]);
        goto k8BNW;
        lSXv7:
        Log::error("[L6eGDYualtpBX] File not found, discard it ", ['video' => $EUi5K->getLocation()]);
        goto puh_d;
        XR6ar:
        $SfZkF = 1024 * 1024 * 50;
        goto hcUHj;
        jXNeG:
        vgRLQ:
        goto S1VDL;
        Q3KnL:
        $T1p3q = $this->Vhcrn->getClient();
        goto q6qWT;
        YU2Lp:
        $EUi5K = ZSB2cdrwtZpmk::find($mfjeD);
        goto I2m_q;
        puh_d:
        return;
        goto jXNeG;
        Phtud:
        ini_set('memory_limit', '-1');
        goto Q3KnL;
        KSDlh:
        RiJpT:
        goto tj3J0;
        hcUHj:
        $g2xfP = $BP_p5->mimeType($EUi5K->getLocation());
        goto wo6pf;
        I2m_q:
        if ($EUi5K) {
            goto RiJpT;
        }
        goto P831a;
        tj3J0:
        if ($BP_p5->exists($EUi5K->getLocation())) {
            goto vgRLQ;
        }
        goto lSXv7;
        qGoiI:
        Log::info('Storing video (local) to S3', ['fileId' => $mfjeD, 'bucketName' => $this->JUv2O]);
        goto Phtud;
        q6qWT:
        $BP_p5 = $this->riMoE;
        goto YU2Lp;
        f4ADf:
        $HmKOk = memory_get_usage();
        goto gsWzn;
        k8BNW:
        return;
        goto KSDlh;
        wo6pf:
        $QEw_Q = microtime(true);
        goto f4ADf;
        gsWzn:
        $ghcvh = memory_get_peak_usage();
        goto wSWA3;
        uFT8N:
    }
}
