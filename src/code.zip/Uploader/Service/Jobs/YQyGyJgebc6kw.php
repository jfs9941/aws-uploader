<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class YQyGyJgebc6kw
{
    private $uAKaW;
    private $qzWWz;
    private $YHwpp;
    private $j5MRz;
    public function __construct($X3Bm8, $E53dc, $ehLvI, $nkmCX)
    {
        goto mfUZu;
        qkve8:
        $this->uAKaW = $X3Bm8;
        goto zxRoS;
        Ii_G4:
        $this->YHwpp = $ehLvI;
        goto ggWhy;
        ggWhy:
        $this->j5MRz = $nkmCX;
        goto qkve8;
        mfUZu:
        $this->qzWWz = $E53dc;
        goto Ii_G4;
        zxRoS:
    }
    public function mzWhDzHAaay(?int $Evdiw, ?int $Brsit, string $gQ74Q, bool $P1OhX = false) : string
    {
        goto N0pIZ;
        l5Lii:
        throw new \RuntimeException("D6fOq8lm3n7T2 dimensions are not available.");
        goto kZS2L;
        WEg1X:
        $Iu6LU -= $QBzZ0;
        goto cfORO;
        Fnk25:
        return $P1OhX ? $lPyJj : $this->YHwpp->url($lPyJj);
        goto QQT48;
        dP4Bj:
        return $P1OhX ? $lPyJj : $this->YHwpp->url($lPyJj);
        goto cuZFa;
        pjREP:
        w_NbU:
        goto dGK5u;
        N0pIZ:
        if (!($Evdiw === null || $Brsit === null)) {
            goto i8XyZ;
        }
        goto l5Lii;
        kZS2L:
        i8XyZ:
        goto m6EEZ;
        aUGW8:
        $xixtT = $this->uAKaW->call($this, $Evdiw, $Brsit);
        goto lNqmv;
        vzjAY:
        $QBzZ0 = (int) ($Iu6LU / 80);
        goto WEg1X;
        cfORO:
        if (!($Evdiw > 1500)) {
            goto w_NbU;
        }
        goto Y17em;
        QQT48:
        V2wTl:
        goto aUGW8;
        lNqmv:
        $Iu6LU = $Evdiw - $mW7C1;
        goto vzjAY;
        Vdpbe:
        if (!$this->YHwpp->exists($lPyJj)) {
            goto V2wTl;
        }
        goto Fnk25;
        mkRYO:
        list($MP6mm, $mW7C1, $olJ3K) = $this->mZXKPv7YLn0($gQ74Q, $Evdiw, $M4dUB, (float) $Evdiw / $Brsit);
        goto CHzY8;
        SWBj6:
        $this->YHwpp->put($lPyJj, $xixtT->stream('png'));
        goto dP4Bj;
        m6EEZ:
        $M4dUB = 0.1;
        goto mkRYO;
        Y17em:
        $Iu6LU -= $QBzZ0 * 0.4;
        goto pjREP;
        dGK5u:
        $FU4zn = $Brsit - $MP6mm - 10;
        goto tkonC;
        u1nfl:
        $this->j5MRz->put($lPyJj, $xixtT->stream('png'));
        goto SWBj6;
        CHzY8:
        $lPyJj = $this->my8oRFbYZ1L($olJ3K, $Evdiw, $Brsit, $mW7C1, $MP6mm);
        goto Vdpbe;
        tkonC:
        $xixtT->text($olJ3K, $Iu6LU, (int) $FU4zn, function ($Nuq_5) use($MP6mm) {
            goto rFvTp;
            jGSM4:
            $Nuq_5->align('middle');
            goto fZ6w2;
            wQ_9S:
            $IpZPb = (int) ($MP6mm * 1.2);
            goto zKFvM;
            rFvTp:
            $Nuq_5->file(public_path($this->qzWWz));
            goto wQ_9S;
            zKFvM:
            $Nuq_5->size(max($IpZPb, 1));
            goto hiqwq;
            Ly0zr:
            $Nuq_5->valign('middle');
            goto jGSM4;
            hiqwq:
            $Nuq_5->color([185, 185, 185, 1]);
            goto Ly0zr;
            fZ6w2:
        });
        goto u1nfl;
        cuZFa:
    }
    private function my8oRFbYZ1L(string $gQ74Q, int $Evdiw, int $Brsit, int $cTV5i, int $t0bkF) : string
    {
        $ffk8X = ltrim($gQ74Q, '@');
        return "v2/watermark/{$ffk8X}/{$Evdiw}x{$Brsit}_{$cTV5i}x{$t0bkF}/text_watermark.png";
    }
    private function mZXKPv7YLn0($gQ74Q, int $Evdiw, float $ier2_, float $dAykE) : array
    {
        goto mJ2Fe;
        Tmy1Z:
        $mW7C1 = (int) ($Evdiw * $ier2_);
        goto yCgrn;
        HcBBd:
        return [(int) $eINF9, $mW7C1, $olJ3K];
        goto O5YDx;
        iy5su:
        return [(int) $eINF9, $eINF9 * strlen($olJ3K) / 1.8, $olJ3K];
        goto oB2Rn;
        oB2Rn:
        gQ74g:
        goto tiTGw;
        Urxez:
        $eINF9 = $mW7C1 / (strlen($olJ3K) * 0.8);
        goto iy5su;
        mJ2Fe:
        $olJ3K = '@' . $gQ74Q;
        goto Tmy1Z;
        tiTGw:
        $eINF9 = 1 / $dAykE * $mW7C1 / strlen($olJ3K);
        goto HcBBd;
        yCgrn:
        if (!($dAykE > 1)) {
            goto gQ74g;
        }
        goto Urxez;
        O5YDx:
    }
}
