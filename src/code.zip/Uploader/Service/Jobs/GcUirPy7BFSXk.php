<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class GcUirPy7BFSXk implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $Brk87) : void
    {
        goto dYfRK;
        UwylZ:
        if ($jZqB7->width() > 0 && $jZqB7->height() > 0) {
            goto t0_9w;
        }
        goto knSaR;
        dYfRK:
        $jZqB7 = HVuLZHLrSam0d::findOrFail($Brk87);
        goto UwylZ;
        N22pq:
        t0_9w:
        goto WeuMA;
        knSaR:
        $this->mvgLfFocCzH($jZqB7);
        goto N22pq;
        WeuMA:
    }
    private function mvgLfFocCzH(HVuLZHLrSam0d $VJuHB) : void
    {
        goto jLwXS;
        bVrgW:
        $VJuHB->update(['duration' => $mDwO7->getDurationInSeconds(), 'resolution' => $n8htQ->getWidth() . 'x' . $n8htQ->getHeight(), 'fps' => $IzXan->get('r_frame_rate') ?? 30]);
        goto pP8kJ;
        eTNev:
        $IzXan = $mDwO7->getVideoStream();
        goto sBYJM;
        sBYJM:
        $n8htQ = $IzXan->getDimensions();
        goto bVrgW;
        jLwXS:
        $jlkIR = $VJuHB->getView();
        goto Rtx1c;
        Rtx1c:
        $mDwO7 = FFMpeg::fromDisk($jlkIR['path'])->open($VJuHB->getAttribute('filename'));
        goto eTNev;
        pP8kJ:
    }
}
