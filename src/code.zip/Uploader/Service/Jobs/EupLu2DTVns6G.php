<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Service\Jobs\TOxy9ZW6dqxMa;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class EupLu2DTVns6G implements WatermarkTextJobInterface
{
    private $gVUAC;
    private $aAdxh;
    private $Ge2u8;
    private $cC_4U;
    private $Ybatl;
    public function __construct($pe6Kp, $V402Y, $s1UdZ, $FHlTP, $Z3C3b)
    {
        goto IlpWq;
        wZnon:
        $this->aAdxh = $V402Y;
        goto tQS1v;
        Ag5tD:
        $this->Ybatl = $FHlTP;
        goto s3eSl;
        s3eSl:
        $this->Ge2u8 = $Z3C3b;
        goto wZnon;
        yzB0i:
        $this->cC_4U = $s1UdZ;
        goto Ag5tD;
        IlpWq:
        $this->gVUAC = $pe6Kp;
        goto yzB0i;
        tQS1v:
    }
    public function putWatermark(string $q8q1b, string $lqmQe) : void
    {
        goto bGpwB;
        l8BGz:
        Log::info("Adding watermark text to image", ['imageId' => $q8q1b]);
        goto zuoeK;
        Jnhqa:
        $iQTBg = memory_get_peak_usage();
        goto l8BGz;
        zuoeK:
        ini_set('memory_limit', '-1');
        goto hDoIm;
        JAr0s:
        $XnLxJ = memory_get_usage();
        goto Jnhqa;
        hDoIm:
        try {
            goto Y1lGN;
            Ckp27:
            $K_YMm = $this->Ybatl->path($PdjKE->getLocation());
            goto fb0ZS;
            F3VqJ:
            return;
            goto h7Xoq;
            H26Rm:
            \Log::warning('Failed to set final permissions on image file: ' . $K_YMm);
            goto kfJS9;
            fb0ZS:
            $yU5fd = $this->gVUAC->call($this, $K_YMm);
            goto oinpk;
            oinpk:
            $yU5fd->orient();
            goto J9CKJ;
            J9CKJ:
            $this->m7gNWQKLuNC($yU5fd, $lqmQe);
            goto rqURz;
            kfJS9:
            throw new \Exception('Failed to set final permissions on image file: ' . $K_YMm);
            goto zZ8yl;
            zZ8yl:
            sI3MQ:
            goto thvWS;
            LEBBe:
            if ($this->Ybatl->exists($PdjKE->getLocation())) {
                goto drrqp;
            }
            goto suXtu;
            rqURz:
            $this->cC_4U->put($K_YMm, $yU5fd->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto lzj40;
            bLyj9:
            if (chmod($K_YMm, 0664)) {
                goto sI3MQ;
            }
            goto H26Rm;
            Y1lGN:
            $PdjKE = JOauoJMkgHWbh::findOrFail($q8q1b);
            goto LEBBe;
            h7Xoq:
            drrqp:
            goto Ckp27;
            suXtu:
            Log::error("JOauoJMkgHWbh is not on local, might be deleted before put watermark", ['imageId' => $q8q1b]);
            goto F3VqJ;
            lzj40:
            unset($yU5fd);
            goto bLyj9;
            thvWS:
        } catch (\Throwable $UdGv9) {
            goto n3Fnr;
            pMINz:
            GQ8qx:
            goto ELnWD;
            n3Fnr:
            if (!$UdGv9 instanceof ModelNotFoundException) {
                goto GQ8qx;
            }
            goto yrrhY;
            yrrhY:
            Log::info("JOauoJMkgHWbh has been deleted, discard it", ['imageId' => $q8q1b]);
            goto f5OxO;
            ELnWD:
            Log::error("JOauoJMkgHWbh is not readable", ['imageId' => $q8q1b, 'error' => $UdGv9->getMessage()]);
            goto K7uIf;
            f5OxO:
            return;
            goto pMINz;
            K7uIf:
        } finally {
            $vnRbJ = microtime(true);
            $WSMrT = memory_get_usage();
            $oeVz2 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $q8q1b, 'execution_time_sec' => $vnRbJ - $tv3_r, 'memory_usage_mb' => ($WSMrT - $XnLxJ) / 1024 / 1024, 'peak_memory_usage_mb' => ($oeVz2 - $iQTBg) / 1024 / 1024]);
        }
        goto LuiM0;
        bGpwB:
        $tv3_r = microtime(true);
        goto JAr0s;
        LuiM0:
    }
    private function m7gNWQKLuNC($yU5fd, $lqmQe) : void
    {
        goto CS5JB;
        OjidD:
        $yU5fd->place($heBhO, 'top-left', 0, 0, 30);
        goto H7CMi;
        gU352:
        $heBhO = $this->gVUAC->call($this, $this->Ybatl->path($h8nKU));
        goto OjidD;
        oMm9h:
        $h8nKU = $FRtii->mg1ITv6ydbE($wtcqu, $snhLP, $lqmQe, true);
        goto trzjL;
        trzjL:
        $this->Ybatl->put($h8nKU, $this->cC_4U->get($h8nKU));
        goto gU352;
        fIg2i:
        $snhLP = $yU5fd->height();
        goto AQLg4;
        AQLg4:
        $FRtii = new TOxy9ZW6dqxMa($this->aAdxh, $this->Ge2u8, $this->cC_4U, $this->Ybatl);
        goto oMm9h;
        CS5JB:
        $wtcqu = $yU5fd->width();
        goto fIg2i;
        H7CMi:
    }
}
