<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\ZqqMnnLm0bshs;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\AvisbyD0IE5xq;
use Illuminate\Support\Facades\Log;
class VdpemzuNhazRt implements ZqqMnnLm0bshs
{
    const u_3TH = 15;
    const V8_pe = 500;
    const WjYpe = 500;
    private $W3SEw;
    private $kEfMA;
    private $c35HU;
    public function __construct($DrcMD, $FP6ih, $VHhUy)
    {
        goto HaYAE;
        F7XbU:
        $this->W3SEw = $DrcMD;
        goto S4v3q;
        n6zM4:
        $this->kEfMA = $FP6ih;
        goto F7XbU;
        HaYAE:
        $this->c35HU = $VHhUy;
        goto n6zM4;
        S4v3q:
    }
    public function blur(string $EQQae) : void
    {
        goto BbMSi;
        zVOcZ:
        $TZu4k->update(['preview' => $vHYos]);
        goto sO_Dx;
        Ra_9m:
        $ulojh = $this->W3SEw->call($this, $this->c35HU->path($TZu4k->getAttribute('thumbnail')));
        goto A0SI3;
        zp6FK:
        $TZu4k = AvisbyD0IE5xq::findOrFail($EQQae);
        goto eQ_3A;
        Nm42C:
        $this->c35HU->put($TZu4k->getAttribute('thumbnail'), $this->kEfMA->get($TZu4k->getAttribute('thumbnail')));
        goto Ra_9m;
        A0SI3:
        $EUALP = $ulojh->width() / $ulojh->height();
        goto tUAKL;
        BB1_c:
        \Log::warning('Failed to set final permissions on image file: ' . $JoxEM);
        goto c0yCo;
        eQ_3A:
        if (!$TZu4k->getAttribute('thumbnail')) {
            goto Rx6Qu;
        }
        goto Nm42C;
        c0yCo:
        throw new \Exception('Failed to set final permissions on image file: ' . $JoxEM);
        goto SsCPu;
        dMLxh:
        if (chmod($JoxEM, 0664)) {
            goto P1PNH;
        }
        goto BB1_c;
        pPBV9:
        $ulojh->save($JoxEM);
        goto rxtBq;
        BbMSi:
        Log::info("Blurring for video", ['videoID' => $EQQae]);
        goto l2y2s;
        CzGQ8:
        $ulojh->blur(self::u_3TH);
        goto KnVa1;
        wV7Dq:
        unset($ulojh);
        goto dMLxh;
        l2y2s:
        ini_set('memory_limit', '-1');
        goto zp6FK;
        JSw_Q:
        $JoxEM = $this->c35HU->path($vHYos);
        goto pPBV9;
        SsCPu:
        P1PNH:
        goto zVOcZ;
        sO_Dx:
        Rx6Qu:
        goto GIcXu;
        KnVa1:
        $vHYos = $this->mKEcdzzpsX5($TZu4k);
        goto JSw_Q;
        rxtBq:
        $this->kEfMA->put($vHYos, $this->c35HU->get($vHYos));
        goto wV7Dq;
        tUAKL:
        $ulojh->resize(self::V8_pe, self::WjYpe / $EUALP);
        goto CzGQ8;
        GIcXu:
    }
    private function mKEcdzzpsX5(YcdplGVWzA91v $Y2tFe) : string
    {
        goto v_OI3;
        cVMCb:
        return $La3UL . $Y2tFe->getFilename() . '.jpg';
        goto hDWSQ;
        QlD5B:
        if ($this->c35HU->exists($La3UL)) {
            goto h3mJc;
        }
        goto aOf9Z;
        orgRE:
        $La3UL = dirname($KPnwr) . '/preview/';
        goto QlD5B;
        RFNC5:
        h3mJc:
        goto cVMCb;
        v_OI3:
        $KPnwr = $Y2tFe->getLocation();
        goto orgRE;
        aOf9Z:
        $this->c35HU->makeDirectory($La3UL, 0755, true);
        goto RFNC5;
        hDWSQ:
    }
}
