<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class GV4Hx68IFb0Ap implements StoreToS3JobInterface
{
    private $bIrxp;
    private $rSfnv;
    private $GRsEs;
    public function __construct($NJy8O, $uIWH1, $Zywh9)
    {
        goto H3H3m;
        H3H3m:
        $this->rSfnv = $uIWH1;
        goto e7iwR;
        e7iwR:
        $this->GRsEs = $Zywh9;
        goto itO1b;
        itO1b:
        $this->bIrxp = $NJy8O;
        goto LFCfk;
        LFCfk:
    }
    public function store(string $eeXS6) : void
    {
        goto p7gNf;
        PeJJ5:
        $lK2Vq = $this->GRsEs->path($ZgSsN);
        goto nEJYO;
        F9bnY:
        HQQzx:
        goto uUuBa;
        q53uS:
        UG34Yjmf7IsbQ::where('parent_id', $eeXS6)->update(['driver' => PdN71mQX1JeZG::S3, 'preview' => $zfULO->getAttribute('preview'), 'thumbnail' => $zfULO->getAttribute('thumbnail')]);
        goto IrKYj;
        zHVuZ:
        s2gd6:
        goto xEAIs;
        IrKYj:
        return;
        goto F9bnY;
        vtTZl:
        $this->rSfnv->put($zfULO->getAttribute('thumbnail'), $this->GRsEs->get($ZgSsN), ['visibility' => 'public', 'ContentType' => $gYP4D->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto zHVuZ;
        CY4r8:
        Log::info("UG34Yjmf7IsbQ stored to S3, update the children attachments", ['fileId' => $eeXS6]);
        goto q53uS;
        nEJYO:
        $gYP4D = $this->bIrxp->call($this, $lK2Vq);
        goto vtTZl;
        hKjIz:
        ZJ84P:
        goto jAlaZ;
        v2Swk:
        $this->mh5QUGeYmaJ($NSF8Y, $zfULO->getLocation());
        goto DoUMB;
        DoUMB:
        $ZgSsN = $zfULO->getAttribute('thumbnail');
        goto UrimL;
        xEAIs:
        if (!($zfULO->getAttribute('preview') && $this->GRsEs->exists($zfULO->getAttribute('preview')))) {
            goto Qf5G7;
        }
        goto TQxM3;
        qQZhj:
        if (!$zfULO->update(['driver' => PdN71mQX1JeZG::S3, 'status' => A7CVlqbpzhfLD::FINISHED])) {
            goto HQQzx;
        }
        goto CY4r8;
        jAlaZ:
        $NSF8Y = $this->GRsEs->path($zfULO->getLocation());
        goto v2Swk;
        KYQu7:
        if ($zfULO) {
            goto ZJ84P;
        }
        goto aq_bE;
        J6Jw7:
        $this->rSfnv->put($zfULO->getAttribute('preview'), $this->GRsEs->get($zfULO->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $BfkjO->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto xLJfL;
        DnrAa:
        $BfkjO = $this->bIrxp->call($this, $AYtsf);
        goto J6Jw7;
        TQxM3:
        $AYtsf = $this->GRsEs->path($zfULO->getAttribute('preview'));
        goto DnrAa;
        p7gNf:
        $zfULO = UG34Yjmf7IsbQ::findOrFail($eeXS6);
        goto KYQu7;
        aq_bE:
        Log::info("UG34Yjmf7IsbQ has been deleted, discard it", ['fileId' => $eeXS6]);
        goto DNLkm;
        DNLkm:
        return;
        goto hKjIz;
        xLJfL:
        Qf5G7:
        goto qQZhj;
        UrimL:
        if (!($ZgSsN && $this->GRsEs->exists($ZgSsN))) {
            goto s2gd6;
        }
        goto PeJJ5;
        uUuBa:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $eeXS6]);
        goto gB2Zy;
        gB2Zy:
    }
    private function mh5QUGeYmaJ($YC7oX, $aUE1w, $pp4CF = '')
    {
        goto SE1tg;
        nr6Wx:
        fGa9K:
        goto v217l;
        SE1tg:
        if (!$pp4CF) {
            goto fGa9K;
        }
        goto E8ltk;
        gTqqE:
        $aUE1w = str_replace('.jpg', $pp4CF, $aUE1w);
        goto nr6Wx;
        E8ltk:
        $YC7oX = str_replace('.jpg', $pp4CF, $YC7oX);
        goto gTqqE;
        v217l:
        try {
            $K0J89 = $this->bIrxp->call($this, $YC7oX);
            $this->rSfnv->put($aUE1w, $this->GRsEs->get($aUE1w), ['visibility' => 'public', 'ContentType' => $K0J89->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $dhJHu) {
            Log::error("Failed to upload image to S3", ['s3Path' => $aUE1w, 'error' => $dhJHu->getMessage()]);
        }
        goto z2u8m;
        z2u8m:
    }
}
