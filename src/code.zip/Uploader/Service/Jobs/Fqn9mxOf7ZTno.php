<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\D6FgZi8OHmjic\Interfaces\ImageInterface;
use Intervention\D6FgZi8OHmjic\Typography\FontFactory;
class Fqn9mxOf7ZTno
{
    private $VEFSL;
    private $GpRfX;
    private $wEVdN;
    private $hYphi;
    public function __construct($ukBzg, $lGHXf, $dzspH, $zuNM5)
    {
        goto AHAqp;
        ahI_I:
        $this->wEVdN = $dzspH;
        goto xIREU;
        xIREU:
        $this->hYphi = $zuNM5;
        goto bvHXp;
        AHAqp:
        $this->GpRfX = $lGHXf;
        goto ahI_I;
        bvHXp:
        $this->VEFSL = $ukBzg;
        goto zhUSs;
        zhUSs:
    }
    public function mrMxekbVqKL(?int $w0IG6, ?int $sIm70, string $R6W2J, bool $LEvx9 = false) : string
    {
        goto yq4_6;
        g2l39:
        return $LEvx9 ? $D4enG : $this->wEVdN->url($D4enG);
        goto JBRE1;
        UENqj:
        throw new \RuntimeException("HS7SZ3rYPI80t dimensions are not available.");
        goto KQa42;
        yq4_6:
        if (!($w0IG6 === null || $sIm70 === null)) {
            goto VJwua;
        }
        goto UENqj;
        KQa42:
        VJwua:
        goto j6QGW;
        qezMF:
        $this->hYphi->put($D4enG, $h169k->toPng());
        goto X5Q5Y;
        pyFCf:
        list($vt8mQ, $sKFKq, $eqXvD) = $this->muLS4mxrc02($R6W2J, $w0IG6, $RZ4ja, (float) $w0IG6 / $sIm70);
        goto Yntvd;
        BwhEr:
        if (!$this->wEVdN->exists($D4enG)) {
            goto Jq4g7;
        }
        goto g2l39;
        Kt6At:
        $h169k->text($eqXvD, $wU9JZ, (int) $TinEb, function ($B36Ac) use($vt8mQ) {
            goto HhgYX;
            SAkJe:
            $UJJxc = (int) ($vt8mQ * 1.2);
            goto tC0eM;
            tC0eM:
            $B36Ac->size(max($UJJxc, 1));
            goto l_jrf;
            oGL2T:
            $B36Ac->valign('middle');
            goto szeMO;
            szeMO:
            $B36Ac->align('middle');
            goto G9kHU;
            HhgYX:
            $B36Ac->file(public_path($this->GpRfX));
            goto SAkJe;
            l_jrf:
            $B36Ac->color('#B9B9B9');
            goto oGL2T;
            G9kHU:
        });
        goto qezMF;
        SrMZH:
        if (!($w0IG6 > 1500)) {
            goto q8xIG;
        }
        goto fwF7B;
        fwF7B:
        $wU9JZ -= $veRp6 * 0.4;
        goto U_euO;
        fKA_z:
        $wU9JZ -= $veRp6;
        goto SrMZH;
        VOZbP:
        $wU9JZ = $w0IG6 - $sKFKq;
        goto SzCDA;
        llsk2:
        return $LEvx9 ? $D4enG : $this->wEVdN->url($D4enG);
        goto rjwaV;
        JBRE1:
        Jq4g7:
        goto YA0Dp;
        YA0Dp:
        $h169k = $this->VEFSL->call($this, $w0IG6, $sIm70);
        goto VOZbP;
        Z0KQv:
        unset($h169k);
        goto llsk2;
        j6QGW:
        $RZ4ja = 0.1;
        goto pyFCf;
        U_euO:
        q8xIG:
        goto HrSYm;
        HrSYm:
        $TinEb = $sIm70 - $vt8mQ - 10;
        goto Kt6At;
        SzCDA:
        $veRp6 = (int) ($wU9JZ / 80);
        goto fKA_z;
        Yntvd:
        $D4enG = $this->m33Z2ToHLSb($eqXvD, $w0IG6, $sIm70, $sKFKq, $vt8mQ);
        goto BwhEr;
        X5Q5Y:
        $this->wEVdN->put($D4enG, $h169k->toPng());
        goto Z0KQv;
        rjwaV:
    }
    private function m33Z2ToHLSb(string $R6W2J, int $w0IG6, int $sIm70, int $vVm65, int $pVxqJ) : string
    {
        $nmAas = ltrim($R6W2J, '@');
        return "v2/watermark/{$nmAas}/{$w0IG6}x{$sIm70}_{$vVm65}x{$pVxqJ}/text_watermark.png";
    }
    private function muLS4mxrc02($R6W2J, int $w0IG6, float $vaQyM, float $JkoVl) : array
    {
        goto BxutX;
        BxutX:
        $eqXvD = '@' . $R6W2J;
        goto iiPL9;
        rAyIe:
        return [(int) $wLwal, $wLwal * strlen($eqXvD) / 1.8, $eqXvD];
        goto pfUxw;
        N8hjY:
        if (!($JkoVl > 1)) {
            goto BzER9;
        }
        goto nzeja;
        WTiB9:
        $wLwal = 1 / $JkoVl * $sKFKq / strlen($eqXvD);
        goto XgYDM;
        nzeja:
        $wLwal = $sKFKq / (strlen($eqXvD) * 0.8);
        goto rAyIe;
        iiPL9:
        $sKFKq = (int) ($w0IG6 * $vaQyM);
        goto N8hjY;
        XgYDM:
        return [(int) $wLwal, $sKFKq, $eqXvD];
        goto kLQu4;
        pfUxw:
        BzER9:
        goto WTiB9;
        kLQu4:
    }
}
