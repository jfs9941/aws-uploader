<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
class YT4TKJO08txNA implements GenerateThumbnailJobInterface
{
    const Qqf08 = 150;
    const jetsR = 150;
    private $Ie_ZE;
    private $P2FvH;
    public function __construct($jSZw8, $j8mv9)
    {
        $this->Ie_ZE = $jSZw8;
        $this->P2FvH = $j8mv9;
    }
    public function generate(string $FILUb)
    {
        goto Ei6FJ;
        CzZ9t:
        try {
            goto gr01z;
            gr01z:
            $p1fCH = $this->P2FvH;
            goto ckcSq;
            jv20r:
            $vX6jf = $p1fCH->put($Sblyk, $a9DPl->stream(), ['visibility' => 'public']);
            goto joDGS;
            ii06Z:
            $BtC3D = $p1fCH->path($Sblyk);
            goto jgwg2;
            SohBP:
            $a9DPl = $this->Ie_ZE->call($this, $p1fCH->path($FGBix->getLocation()));
            goto sD4fL;
            a4afn:
            Log::warning('Failed to set file permissions for stored image: ' . $BtC3D);
            goto L1z1s;
            L1z1s:
            throw new \Exception('Failed to set file permissions for stored image: ' . $BtC3D);
            goto Fui00;
            jgwg2:
            if (chmod($BtC3D, 0644)) {
                goto I2Hv8;
            }
            goto a4afn;
            sD4fL:
            $a9DPl->fit(150, 150, function ($SXrsL) {
                $SXrsL->aspectRatio();
            });
            goto ACfuW;
            joDGS:
            $a9DPl->destroy();
            goto ItRm7;
            ACfuW:
            $a9DPl->encode('jpg', 80);
            goto G0r3y;
            ckcSq:
            $FGBix = XbYF8aa0XyGnI::findOrFail($FILUb);
            goto SohBP;
            G0r3y:
            $Sblyk = $this->mwfF58VrEJD($FGBix);
            goto jv20r;
            FxLFz:
            SQ1sE:
            goto McreO;
            QxZ_x:
            $FGBix->update(['thumbnail' => $Sblyk, 'status' => EPmxqTVp5luXc::THUMBNAIL_PROCESSED]);
            goto ii06Z;
            Fui00:
            I2Hv8:
            goto FxLFz;
            ItRm7:
            if (!($vX6jf !== false)) {
                goto SQ1sE;
            }
            goto QxZ_x;
            McreO:
        } catch (ModelNotFoundException $AWFah) {
            Log::info("XbYF8aa0XyGnI has been deleted, discard it", ['imageId' => $FILUb]);
            return;
        }
        goto EdSSL;
        Ei6FJ:
        Log::info("Generating thumbnail", ['imageId' => $FILUb]);
        goto k0XZJ;
        k0XZJ:
        ini_set('memory_limit', '-1');
        goto CzZ9t;
        EdSSL:
    }
    private function mwfF58VrEJD(CZj9PTf9Cv9Eq $FGBix) : string
    {
        goto G0OxK;
        G0OxK:
        $Sblyk = $FGBix->getLocation();
        goto A9kOB;
        WeuOY:
        return $FwwwM . '/' . $FGBix->getFilename() . '.jpg';
        goto QsdHr;
        A9kOB:
        $OhpSE = dirname($Sblyk);
        goto YhqAz;
        YhqAz:
        $FwwwM = $OhpSE . '/' . self::Qqf08 . 'X' . self::jetsR;
        goto WeuOY;
        QsdHr:
    }
}
