<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class SmsNKqbzjpIKf implements StoreToS3JobInterface
{
    private $wil31;
    private $ZN9hu;
    private $MuT3J;
    public function __construct($jwYYV, $C2YXG, $tBTgN)
    {
        goto sAul1;
        sAul1:
        $this->ZN9hu = $C2YXG;
        goto FR2Q_;
        LbAV2:
        $this->wil31 = $jwYYV;
        goto dE9aJ;
        FR2Q_:
        $this->MuT3J = $tBTgN;
        goto LbAV2;
        dE9aJ:
    }
    public function store(string $uuHkQ) : void
    {
        goto uVFH4;
        ewnsi:
        $NmfQW = $this->wil31->call($this, $IYAfF);
        goto oJXfc;
        uVFH4:
        $npIYs = QFoN7Ibbm93if::findOrFail($uuHkQ);
        goto Gl63P;
        bJu5G:
        $fTV34 = $npIYs->getAttribute('thumbnail');
        goto HFJ7M;
        oLdMk:
        XKorS:
        goto ygibH;
        IOQ9C:
        QFoN7Ibbm93if::where('parent_id', $uuHkQ)->update(['driver' => VNuaYSNcfVlT5::S3, 'preview' => $npIYs->getAttribute('preview'), 'thumbnail' => $npIYs->getAttribute('thumbnail')]);
        goto X8tX_;
        X8tX_:
        return;
        goto H18rO;
        M2A09:
        $dSgog = $this->MuT3J->path($npIYs->getLocation());
        goto obrX0;
        AETdB:
        VIUVb:
        goto I0yhE;
        woZJJ:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $uuHkQ]);
        goto dtzne;
        I0yhE:
        if (!($npIYs->getAttribute('preview') && $this->MuT3J->exists($npIYs->getAttribute('preview')))) {
            goto XKorS;
        }
        goto Hvs7Q;
        oJXfc:
        $this->ZN9hu->put($npIYs->getAttribute('preview'), $this->MuT3J->get($npIYs->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $NmfQW->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto oLdMk;
        JnP8D:
        return;
        goto tLJ89;
        obrX0:
        $this->mtd0J4NCSVp($dSgog, $npIYs->getLocation());
        goto bJu5G;
        H18rO:
        vpQQY:
        goto woZJJ;
        HFJ7M:
        if (!($fTV34 && $this->MuT3J->exists($fTV34))) {
            goto VIUVb;
        }
        goto jpQmc;
        EAKe3:
        Log::info("QFoN7Ibbm93if stored to S3, update the children attachments", ['fileId' => $uuHkQ]);
        goto IOQ9C;
        tLJ89:
        ifHMG:
        goto M2A09;
        jpQmc:
        $f_RJe = $this->MuT3J->path($fTV34);
        goto ZuaXP;
        ZuaXP:
        $EpLlV = $this->wil31->call($this, $f_RJe);
        goto waStY;
        waStY:
        $this->ZN9hu->put($npIYs->getAttribute('thumbnail'), $this->MuT3J->get($fTV34), ['visibility' => 'public', 'ContentType' => $EpLlV->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto AETdB;
        Gl63P:
        if ($npIYs) {
            goto ifHMG;
        }
        goto Vl9gs;
        Hvs7Q:
        $IYAfF = $this->MuT3J->path($npIYs->getAttribute('preview'));
        goto ewnsi;
        ygibH:
        if (!$npIYs->update(['driver' => VNuaYSNcfVlT5::S3, 'status' => Xy3InMky6jKYf::FINISHED])) {
            goto vpQQY;
        }
        goto EAKe3;
        Vl9gs:
        Log::info("QFoN7Ibbm93if has been deleted, discard it", ['fileId' => $uuHkQ]);
        goto JnP8D;
        dtzne:
    }
    private function mtd0J4NCSVp($o1tf8, $HQyxJ, $kxk8f = '')
    {
        goto wZ_Xu;
        TZYGv:
        $HQyxJ = str_replace('.jpg', $kxk8f, $HQyxJ);
        goto XojOr;
        GHZKN:
        $o1tf8 = str_replace('.jpg', $kxk8f, $o1tf8);
        goto TZYGv;
        wZ_Xu:
        if (!$kxk8f) {
            goto JtCLs;
        }
        goto GHZKN;
        XojOr:
        JtCLs:
        goto M9861;
        M9861:
        try {
            $tCWWG = $this->wil31->call($this, $o1tf8);
            $this->ZN9hu->put($HQyxJ, $this->MuT3J->get($HQyxJ), ['visibility' => 'public', 'ContentType' => $tCWWG->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $IGLS9) {
            Log::error("Failed to upload image to S3", ['s3Path' => $HQyxJ, 'error' => $IGLS9->getMessage()]);
        }
        goto uU2v_;
        uU2v_:
    }
}
