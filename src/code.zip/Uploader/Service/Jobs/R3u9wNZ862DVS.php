<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Illuminate\Support\Facades\Log;
class R3u9wNZ862DVS implements StoreVideoToS3JobInterface
{
    private $Zxjhe;
    private $zbU8n;
    private $ofZvx;
    public function __construct($APN4u, $Efy84, $suNmN)
    {
        goto Uqc2z;
        Uqc2z:
        $this->zbU8n = $Efy84;
        goto xre8K;
        sLgGP:
        $this->Zxjhe = $APN4u;
        goto wkLTw;
        xre8K:
        $this->ofZvx = $suNmN;
        goto sLgGP;
        wkLTw:
    }
    public function store(string $N2oAf) : void
    {
        goto MSZuO;
        IOKhb:
        if ($suNmN->exists($kduhw->getLocation())) {
            goto LJ4Oh;
        }
        goto N62tx;
        JSZwu:
        if ($kduhw) {
            goto bAxrZ;
        }
        goto vk8xb;
        MSZuO:
        Log::info('Storing video (local) to S3', ['fileId' => $N2oAf, 'bucketName' => $this->Zxjhe]);
        goto IdD9o;
        IjTNp:
        $Oj18q = microtime(true);
        goto fQh0q;
        tiTEs:
        $Hg1G3 = 1024 * 1024 * 50;
        goto Q29B6;
        qd_8Z:
        $DS5WD = $suNmN->readStream($kduhw->getLocation());
        goto tiTEs;
        Jqe9b:
        LJ4Oh:
        goto qd_8Z;
        fQh0q:
        $zfPP0 = memory_get_usage();
        goto Dyqpq;
        eF_Mh:
        bAxrZ:
        goto IOKhb;
        c_KZC:
        $xfjC2 = $this->zbU8n->getClient();
        goto Ly_0i;
        CmbA0:
        $kduhw = VPegVN4NByLqJ::find($N2oAf);
        goto JSZwu;
        ELe9z:
        return;
        goto eF_Mh;
        sqDBH:
        return;
        goto Jqe9b;
        Q29B6:
        $e5iKR = $suNmN->mimeType($kduhw->getLocation());
        goto IjTNp;
        Dyqpq:
        $j44T2 = memory_get_peak_usage();
        goto JsHMF;
        N62tx:
        Log::error("[R3u9wNZ862DVS] File not found, discard it ", ['video' => $kduhw->getLocation()]);
        goto sqDBH;
        vk8xb:
        Log::info("VPegVN4NByLqJ has been deleted, discard it", ['fileId' => $N2oAf]);
        goto ELe9z;
        IdD9o:
        ini_set('memory_limit', '-1');
        goto c_KZC;
        Ly_0i:
        $suNmN = $this->ofZvx;
        goto CmbA0;
        JsHMF:
        try {
            goto FgQF9;
            zMqEk:
            $kduhw->update(['driver' => I5kpK7wkbRQvu::S3, 'status' => A9q1Lm9l5QixG::FINISHED]);
            goto eaaSs;
            Jl6R2:
            $gDc4u++;
            goto jbFNd;
            uG30J:
            $gDc4u = 1;
            goto ARNQf;
            guSwn:
            Uhjw3:
            goto pgFJn;
            Sq_xA:
            $IovhQ[] = ['PartNumber' => $gDc4u, 'ETag' => $NY1Vr['ETag']];
            goto Jl6R2;
            FgQF9:
            $IcWNr = $xfjC2->createMultipartUpload(['Bucket' => $this->Zxjhe, 'Key' => $kduhw->getLocation(), 'ContentType' => $e5iKR, 'ContentDisposition' => 'inline']);
            goto evFOo;
            Finrv:
            $NY1Vr = $xfjC2->uploadPart(['Bucket' => $this->Zxjhe, 'Key' => $kduhw->getLocation(), 'UploadId' => $lt0mW, 'PartNumber' => $gDc4u, 'Body' => fread($DS5WD, $Hg1G3)]);
            goto Sq_xA;
            eaaSs:
            $suNmN->delete($kduhw->getLocation());
            goto Rz1Ab;
            jbFNd:
            goto Vypwt;
            goto guSwn;
            KzTWm:
            Vypwt:
            goto uhG9L;
            evFOo:
            $lt0mW = $IcWNr['UploadId'];
            goto uG30J;
            pgFJn:
            fclose($DS5WD);
            goto FqkCo;
            FqkCo:
            $xfjC2->completeMultipartUpload(['Bucket' => $this->Zxjhe, 'Key' => $kduhw->getLocation(), 'UploadId' => $lt0mW, 'MultipartUpload' => ['Parts' => $IovhQ]]);
            goto zMqEk;
            ARNQf:
            $IovhQ = [];
            goto KzTWm;
            uhG9L:
            if (feof($DS5WD)) {
                goto Uhjw3;
            }
            goto Finrv;
            Rz1Ab:
        } catch (AwsException $a9JiP) {
            goto K16hU;
            ai9KL:
            try {
                $xfjC2->abortMultipartUpload(['Bucket' => $this->Zxjhe, 'Key' => $kduhw->getLocation(), 'UploadId' => $lt0mW]);
            } catch (AwsException $jnugT) {
                Log::error('Error aborting multipart upload: ' . $jnugT->getMessage());
            }
            goto mBpI_;
            HBJ5u:
            Log::error('Failed to store video: ' . $kduhw->getLocation() . ' - ' . $a9JiP->getMessage());
            goto dbCZX;
            mBpI_:
            KG9Dr:
            goto HBJ5u;
            K16hU:
            if (!isset($lt0mW)) {
                goto KG9Dr;
            }
            goto ai9KL;
            dbCZX:
        } finally {
            $FlQiD = microtime(true);
            $pejxD = memory_get_usage();
            $G9K1o = memory_get_peak_usage();
            Log::info('Store VPegVN4NByLqJ to S3 function resource usage', ['imageId' => $N2oAf, 'execution_time_sec' => $FlQiD - $Oj18q, 'memory_usage_mb' => ($pejxD - $zfPP0) / 1024 / 1024, 'peak_memory_usage_mb' => ($G9K1o - $j44T2) / 1024 / 1024]);
        }
        goto B1wkE;
        B1wkE:
    }
}
