<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Illuminate\Support\Facades\Log;
class PP0MV7J3Kq0AT implements BlurVideoJobInterface
{
    const jjY4c = 15;
    const iKWl8 = 500;
    const MpRAp = 500;
    private $G25L6;
    private $VV2A8;
    private $QbAvB;
    public function __construct($G6zg7, $oOPBt, $UNh9U)
    {
        goto jieBM;
        FXCcj:
        $this->G25L6 = $G6zg7;
        goto B2YLL;
        jieBM:
        $this->QbAvB = $UNh9U;
        goto S4_SC;
        S4_SC:
        $this->VV2A8 = $oOPBt;
        goto FXCcj;
        B2YLL:
    }
    public function blur(string $GhyxD) : void
    {
        goto VVq7b;
        iQfgV:
        xS3pi:
        goto hag8M;
        BlS_R:
        $QQZ5O = $this->QbAvB->path($J1ZcC);
        goto dWORW;
        tJuKh:
        $oaIJp = $this->G25L6->call($this, $this->QbAvB->path($LkH5Q->getAttribute('thumbnail')));
        goto Wf7N3;
        QcTL5:
        $J1ZcC = $this->m2MRGCZbu4Y($LkH5Q);
        goto BlS_R;
        VVq7b:
        Log::info("Blurring for video", ['videoID' => $GhyxD]);
        goto OzAzu;
        RmEcL:
        if (!$LkH5Q->getAttribute('thumbnail')) {
            goto xS3pi;
        }
        goto C5yqo;
        C5yqo:
        $this->QbAvB->put($LkH5Q->getAttribute('thumbnail'), $this->VV2A8->get($LkH5Q->getAttribute('thumbnail')));
        goto tJuKh;
        yvY0F:
        unset($oaIJp);
        goto PqeU6;
        dWORW:
        $oaIJp->save($QQZ5O);
        goto mIRFp;
        i32kI:
        throw new \Exception('Failed to set final permissions on image file: ' . $QQZ5O);
        goto w54FA;
        PqeU6:
        if (chmod($QQZ5O, 0664)) {
            goto QcQEn;
        }
        goto GlNxy;
        OzAzu:
        ini_set('memory_limit', '-1');
        goto QOJyQ;
        Wf7N3:
        $huvyP = $oaIJp->width() / $oaIJp->height();
        goto x_p_M;
        jt0KC:
        $oaIJp->blur(self::jjY4c);
        goto QcTL5;
        Oa5t1:
        $LkH5Q->update(['preview' => $J1ZcC]);
        goto iQfgV;
        GlNxy:
        \Log::warning('Failed to set final permissions on image file: ' . $QQZ5O);
        goto i32kI;
        mIRFp:
        $this->VV2A8->put($J1ZcC, $this->QbAvB->get($J1ZcC));
        goto yvY0F;
        x_p_M:
        $oaIJp->resize(self::iKWl8, self::MpRAp / $huvyP);
        goto jt0KC;
        QOJyQ:
        $LkH5Q = VHp3UACVYl357::findOrFail($GhyxD);
        goto RmEcL;
        w54FA:
        QcQEn:
        goto Oa5t1;
        hag8M:
    }
    private function m2MRGCZbu4Y(LxwvVLXJMU3yo $dkWnY) : string
    {
        goto Ipi5n;
        UCQt5:
        $this->QbAvB->makeDirectory($LZqCF, 0755, true);
        goto bXqCA;
        OvnYq:
        if ($this->QbAvB->exists($LZqCF)) {
            goto ZEstu;
        }
        goto UCQt5;
        G0Qar:
        return $LZqCF . $dkWnY->getFilename() . '.jpg';
        goto HCHsl;
        Ipi5n:
        $yRiLu = $dkWnY->getLocation();
        goto YKnk8;
        bXqCA:
        ZEstu:
        goto G0Qar;
        YKnk8:
        $LZqCF = dirname($yRiLu) . '/preview/';
        goto OvnYq;
        HCHsl:
    }
}
