<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class OqJPoAnPhPJem implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $qMhfW) : void
    {
        goto U0lik;
        lEfpn:
        $this->moe9xn53IYB($JhYqb);
        goto wNiFy;
        wNiFy:
        nIwoR:
        goto nEDvp;
        U0lik:
        $JhYqb = NYx4mhlHSMgHF::findOrFail($qMhfW);
        goto TAAWs;
        TAAWs:
        if ($JhYqb->width() > 0 && $JhYqb->height() > 0) {
            goto nIwoR;
        }
        goto lEfpn;
        nEDvp:
    }
    private function moe9xn53IYB(NYx4mhlHSMgHF $uC0lG) : void
    {
        goto g15fW;
        pZSAm:
        $uC0lG->update(['duration' => $lOhz0->getDurationInSeconds(), 'resolution' => $xFV83->getWidth() . 'x' . $xFV83->getHeight(), 'fps' => $ksEQK->get('r_frame_rate') ?? 30]);
        goto hIWkT;
        g15fW:
        $HjRng = $uC0lG->getView();
        goto C4Xie;
        C4Xie:
        $lOhz0 = FFMpeg::fromDisk($HjRng['path'])->open($uC0lG->getAttribute('filename'));
        goto uueXz;
        uueXz:
        $ksEQK = $lOhz0->getVideoStream();
        goto bEtvM;
        bEtvM:
        $xFV83 = $ksEQK->getDimensions();
        goto pZSAm;
        hIWkT:
    }
}
