<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class SW2RU4RxK8oM0 implements GenerateThumbnailForVideoInterface
{
    private $H0T2I;
    public function __construct($oR0yH)
    {
        $this->H0T2I = $oR0yH;
    }
    public function generate(string $ElvKF) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $ElvKF);
        $this->H0T2I->createThumbnail($ElvKF);
    }
}
