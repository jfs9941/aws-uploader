<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
class Gds2W9QX0HocO implements WatermarkTextJobInterface
{
    private $aQPLw;
    private $AQqBe;
    private $wmqIG;
    private $ifs25;
    private $kduDw;
    public function __construct($fhNRF, $RuaCx, $PQlIa, $h5ffz, $P7qCy)
    {
        goto UN6vC;
        arhgo:
        $this->AQqBe = $RuaCx;
        goto mC88X;
        pMsZB:
        $this->wmqIG = $P7qCy;
        goto arhgo;
        dWmOB:
        $this->ifs25 = $PQlIa;
        goto C3AEY;
        UN6vC:
        $this->aQPLw = $fhNRF;
        goto dWmOB;
        C3AEY:
        $this->kduDw = $h5ffz;
        goto pMsZB;
        mC88X:
    }
    public function putWatermark(string $PV4mw, string $FmRvX) : void
    {
        goto EK7p3;
        ytIE_:
        Log::info("Adding watermark text to image", ['imageId' => $PV4mw]);
        goto YZfTR;
        afkb0:
        try {
            goto jak0w;
            wCCTZ:
            $tNf9L = $this->aQPLw->call($this, $sEueW);
            goto EmRTL;
            ERIOh:
            JnjLY:
            goto IoPLd;
            Nis3A:
            rJILz:
            goto rVnxI;
            RV0wo:
            if ($this->kduDw->exists($SYKC9->getLocation())) {
                goto JnjLY;
            }
            goto JzCLn;
            IoPLd:
            $sEueW = $this->kduDw->path($SYKC9->getLocation());
            goto wCCTZ;
            jak0w:
            $SYKC9 = McTg5Yp6FKC6z::findOrFail($PV4mw);
            goto RV0wo;
            dKFDb:
            if (chmod($sEueW, 0664)) {
                goto rJILz;
            }
            goto WK8WF;
            DtWGr:
            $tNf9L->save($sEueW);
            goto q34K3;
            WK8WF:
            \Log::warning('Failed to set final permissions on image file: ' . $sEueW);
            goto oHixj;
            oHixj:
            throw new \Exception('Failed to set final permissions on image file: ' . $sEueW);
            goto Nis3A;
            EmRTL:
            $tNf9L->orientate();
            goto pZs6R;
            VKLOp:
            return;
            goto ERIOh;
            pZs6R:
            $this->m84pffpJLdr($tNf9L, $FmRvX);
            goto DtWGr;
            q34K3:
            $tNf9L->destroy();
            goto dKFDb;
            JzCLn:
            Log::error("McTg5Yp6FKC6z is not on local, might be deleted before put watermark", ['imageId' => $PV4mw]);
            goto VKLOp;
            rVnxI:
        } catch (\Throwable $Z3cRt) {
            goto yjp3X;
            yDtLl:
            return;
            goto WINuZ;
            wwuvF:
            Log::info("McTg5Yp6FKC6z has been deleted, discard it", ['imageId' => $PV4mw]);
            goto yDtLl;
            kicYp:
            Log::error("McTg5Yp6FKC6z is not readable", ['imageId' => $PV4mw, 'error' => $Z3cRt->getMessage()]);
            goto LkXle;
            WINuZ:
            aHCAH:
            goto kicYp;
            yjp3X:
            if (!$Z3cRt instanceof ModelNotFoundException) {
                goto aHCAH;
            }
            goto wwuvF;
            LkXle:
        } finally {
            $mf5n8 = microtime(true);
            $c5jd5 = memory_get_usage();
            $ghXwk = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $PV4mw, 'execution_time_sec' => $mf5n8 - $ZqNFk, 'memory_usage_mb' => ($c5jd5 - $vqC1w) / 1024 / 1024, 'peak_memory_usage_mb' => ($ghXwk - $NSzm3) / 1024 / 1024]);
        }
        goto O6iYC;
        MWKyB:
        $vqC1w = memory_get_usage();
        goto vpOS8;
        YZfTR:
        ini_set('memory_limit', '-1');
        goto afkb0;
        EK7p3:
        $ZqNFk = microtime(true);
        goto MWKyB;
        vpOS8:
        $NSzm3 = memory_get_peak_usage();
        goto ytIE_;
        O6iYC:
    }
    private function m84pffpJLdr($tNf9L, $FmRvX) : void
    {
        goto Y0HeA;
        wlnx5:
        $this->kduDw->put($IHrgr, $this->ifs25->get($IHrgr));
        goto OGXWC;
        pfEde:
        $HNsWT->opacity(35);
        goto mfmLU;
        KTurB:
        $JBG5O = new WJRFs5dkBBuwo($this->AQqBe, $this->wmqIG, $this->ifs25, $this->kduDw);
        goto CkvUi;
        OGXWC:
        $HNsWT = $this->aQPLw->call($this, $this->kduDw->path($IHrgr));
        goto pfEde;
        CkvUi:
        $IHrgr = $JBG5O->mRsy9eF6dlc($NixDl, $l4GK0, $FmRvX, true);
        goto wlnx5;
        Ta2E3:
        $l4GK0 = $tNf9L->height();
        goto KTurB;
        Y0HeA:
        $NixDl = $tNf9L->width();
        goto Ta2E3;
        mfmLU:
        $tNf9L->insert($HNsWT);
        goto Kbxrx;
        Kbxrx:
    }
}
