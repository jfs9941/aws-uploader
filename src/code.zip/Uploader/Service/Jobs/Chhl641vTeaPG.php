<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class Chhl641vTeaPG
{
    private $JVRnQ;
    private $hmZ9x;
    public function __construct(int $LLS7y, int $knROB)
    {
        goto cwRE2;
        cwRE2:
        if (!($LLS7y <= 0)) {
            goto kAXDL;
        }
        goto spGSC;
        spGSC:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto qDjaK;
        fQ9Pm:
        UOHA_:
        goto lnTl0;
        PwXMj:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto fQ9Pm;
        qDjaK:
        kAXDL:
        goto DuJP2;
        pxSMd:
        $this->hmZ9x = $knROB;
        goto Hvqn3;
        DuJP2:
        if (!($knROB <= 0)) {
            goto UOHA_;
        }
        goto PwXMj;
        lnTl0:
        $this->JVRnQ = $LLS7y;
        goto pxSMd;
        Hvqn3:
    }
    private static function mPbdI9gVLVj($jbXZi, string $BlLe2 = 'floor') : int
    {
        goto G9wSJ;
        dJ3pp:
        return (int) $jbXZi;
        goto VIDwP;
        pr0FI:
        switch (strtolower($BlLe2)) {
            case 'ceil':
                return (int) (ceil($jbXZi / 2) * 2);
            case 'round':
                return (int) (round($jbXZi / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($jbXZi / 2) * 2);
        }
        goto NDEtR;
        VIDwP:
        Rwe0C:
        goto pr0FI;
        TKDMo:
        gXqCM:
        goto JYghP;
        tnUMl:
        return $jbXZi;
        goto TKDMo;
        G9wSJ:
        if (!(is_int($jbXZi) && $jbXZi % 2 === 0)) {
            goto gXqCM;
        }
        goto tnUMl;
        JYghP:
        if (!(is_float($jbXZi) && $jbXZi == floor($jbXZi) && (int) $jbXZi % 2 === 0)) {
            goto Rwe0C;
        }
        goto dJ3pp;
        OOn5h:
        mYAv3:
        goto qdD0a;
        NDEtR:
        nzW3U:
        goto OOn5h;
        qdD0a:
    }
    public function mKPzSzy82MY(string $eVq4c = 'floor') : array
    {
        goto m8bwH;
        LwxTf:
        $BmfOS = self::mPbdI9gVLVj(round($KEHJ3), $eVq4c);
        goto EIWrx;
        jXiIa:
        $wp6Df = $cuqnz;
        goto gT1ox;
        el6jl:
        $BmfOS = 0;
        goto jWkcX;
        DSeQX:
        if (!($wp6Df < 2)) {
            goto eKRL2;
        }
        goto mKwgK;
        reWdp:
        h81KB:
        goto D71ZO;
        D71ZO:
        return ['width' => $wp6Df, 'height' => $BmfOS];
        goto rBQf4;
        JP4V1:
        $wp6Df = self::mPbdI9gVLVj(round($dhHEs), $eVq4c);
        goto xGWvw;
        CSCHV:
        $wp6Df = 0;
        goto el6jl;
        FbuIA:
        $KEHJ3 = $this->hmZ9x * $Js21k;
        goto LwxTf;
        jO2HA:
        $BmfOS = $cuqnz;
        goto nhAXo;
        m8bwH:
        $cuqnz = 1080;
        goto CSCHV;
        xGWvw:
        KMYvJ:
        goto DSeQX;
        jWkcX:
        if ($this->JVRnQ >= $this->hmZ9x) {
            goto uFOiK;
        }
        goto jXiIa;
        ZVr0u:
        eKRL2:
        goto Dx13l;
        EIWrx:
        goto KMYvJ;
        goto G6Ens;
        Q0_Nl:
        $dhHEs = $this->JVRnQ * $Js21k;
        goto JP4V1;
        mKwgK:
        $wp6Df = 2;
        goto ZVr0u;
        Dx13l:
        if (!($BmfOS < 2)) {
            goto h81KB;
        }
        goto vtgx6;
        vtgx6:
        $BmfOS = 2;
        goto reWdp;
        G6Ens:
        uFOiK:
        goto jO2HA;
        nhAXo:
        $Js21k = $BmfOS / $this->hmZ9x;
        goto Q0_Nl;
        gT1ox:
        $Js21k = $wp6Df / $this->JVRnQ;
        goto FbuIA;
        rBQf4:
    }
}
