<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class O55RFBu3dDBa6
{
    private $ZBBMD;
    private $TJ3cV;
    private $MV0lK;
    private $Hf14x;
    public function __construct($v9tnd, $EYZKC, $tYsty, $p1fCH)
    {
        goto XBYkZ;
        XBYkZ:
        $this->TJ3cV = $EYZKC;
        goto YEE6o;
        akgRe:
        $this->ZBBMD = $v9tnd;
        goto ASfqv;
        fpSAy:
        $this->Hf14x = $p1fCH;
        goto akgRe;
        YEE6o:
        $this->MV0lK = $tYsty;
        goto fpSAy;
        ASfqv:
    }
    public function myRCF2se27f(?int $xjnOB, ?int $I9Wph, string $u46de, bool $SO9aC = false) : string
    {
        goto W6VSY;
        etES7:
        return $SO9aC ? $Sblyk : $this->MV0lK->url($Sblyk);
        goto HEFRv;
        L4JBD:
        $jekn7 = 0.1;
        goto RWz4k;
        KnbNi:
        $WQVK3 = $xjnOB - $L1pK6;
        goto t6207;
        noiax:
        $Sblyk = $this->mCwnLvRgeaY($D1feY, $xjnOB, $I9Wph, $L1pK6, $hHFlY);
        goto CuFgU;
        t6207:
        $W7MFg = (int) ($WQVK3 / 80);
        goto anxkl;
        CuFgU:
        if (!$this->MV0lK->exists($Sblyk)) {
            goto tSPzP;
        }
        goto vHHA1;
        hkUsK:
        h9gLF:
        goto L4JBD;
        A5IOB:
        $WQVK3 -= $W7MFg * 0.4;
        goto xgJ6w;
        mW27P:
        $this->MV0lK->put($Sblyk, $FGBix->stream('png'));
        goto etES7;
        jKQFQ:
        $FGBix->text($D1feY, $WQVK3, (int) $yOAJu, function ($s9FEZ) use($hHFlY) {
            goto PLs8U;
            U3VJe:
            $s9FEZ->valign('middle');
            goto qc7rY;
            ADjEm:
            $s9FEZ->color([185, 185, 185, 1]);
            goto U3VJe;
            Zen1J:
            $s9FEZ->size(max($ugFUP, 1));
            goto ADjEm;
            qc7rY:
            $s9FEZ->align('middle');
            goto WmAse;
            PLs8U:
            $s9FEZ->file(public_path($this->TJ3cV));
            goto e2cQb;
            e2cQb:
            $ugFUP = (int) ($hHFlY * 1.2);
            goto Zen1J;
            WmAse:
        });
        goto AVuDO;
        W6VSY:
        if (!($xjnOB === null || $I9Wph === null)) {
            goto h9gLF;
        }
        goto OCc8M;
        anxkl:
        $WQVK3 -= $W7MFg;
        goto SRNSD;
        vHHA1:
        return $SO9aC ? $Sblyk : $this->MV0lK->url($Sblyk);
        goto fDFSb;
        SRNSD:
        if (!($xjnOB > 1500)) {
            goto ph7D7;
        }
        goto A5IOB;
        xgJ6w:
        ph7D7:
        goto XU_co;
        fDFSb:
        tSPzP:
        goto ZZe1t;
        OCc8M:
        throw new \RuntimeException("CUaMUcjkFHEwK dimensions are not available.");
        goto hkUsK;
        AVuDO:
        $this->Hf14x->put($Sblyk, $FGBix->stream('png'));
        goto mW27P;
        ZZe1t:
        $FGBix = $this->ZBBMD->call($this, $xjnOB, $I9Wph);
        goto KnbNi;
        RWz4k:
        list($hHFlY, $L1pK6, $D1feY) = $this->m2Q4gwkSamq($u46de, $xjnOB, $jekn7, (float) $xjnOB / $I9Wph);
        goto noiax;
        XU_co:
        $yOAJu = $I9Wph - $hHFlY - 10;
        goto jKQFQ;
        HEFRv:
    }
    private function mCwnLvRgeaY(string $u46de, int $xjnOB, int $I9Wph, int $eH3XC, int $agret) : string
    {
        $xtwO6 = ltrim($u46de, '@');
        return "v2/watermark/{$xtwO6}/{$xjnOB}x{$I9Wph}_{$eH3XC}x{$agret}/text_watermark.png";
    }
    private function m2Q4gwkSamq($u46de, int $xjnOB, float $y8qWI, float $jG3UU) : array
    {
        goto jfPnw;
        RXuC0:
        nboRD:
        goto EuxtP;
        ljwtT:
        return [(int) $v8OGU, $v8OGU * strlen($D1feY) / 1.8, $D1feY];
        goto RXuC0;
        Hw53o:
        return [(int) $v8OGU, $L1pK6, $D1feY];
        goto KQVPI;
        EuxtP:
        $v8OGU = 1 / $jG3UU * $L1pK6 / strlen($D1feY);
        goto Hw53o;
        CwfVi:
        $L1pK6 = (int) ($xjnOB * $y8qWI);
        goto MUu1e;
        IAIvx:
        $v8OGU = $L1pK6 / (strlen($D1feY) * 0.8);
        goto ljwtT;
        MUu1e:
        if (!($jG3UU > 1)) {
            goto nboRD;
        }
        goto IAIvx;
        jfPnw:
        $D1feY = '@' . $u46de;
        goto CwfVi;
        KQVPI:
    }
}
