<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\Video;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;

class PrepareMetadataJob implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $id): void
    {
        $video = Video::findOrFail($id);
        if (!($video->width() > 0 && $video->height() > 0)) {
            $this->fetchMetadataOfVideo($video);
        }
    }

    private function fetchMetadataOfVideo(Video $attachment): void
    {
        $view = $attachment->getView();

        $media = FFMpeg::fromDisk($view['path'])->open($attachment->getAttribute('filename'));
        $streamVideo = $media->getVideoStream();
        $dimension = $streamVideo->getDimensions();

        $attachment->update([
            'duration' => $media->getDurationInSeconds(),
            'resolution' => $dimension->getWidth() . 'x' . $dimension->getHeight(),
            'fps' => $streamVideo->get('r_frame_rate') ?? 30,
        ]);
    }
}
