<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Illuminate\Support\Facades\Log;
class EVBxly7PyHLk2 implements BlurVideoJobInterface
{
    const BSgK_ = 15;
    const xnKoO = 500;
    const kWMDX = 500;
    private $kAoN_;
    private $iHPgt;
    private $cGz6K;
    public function __construct($QJMxa, $zeM4q, $DAY12)
    {
        goto yb7X0;
        et_sg:
        $this->kAoN_ = $QJMxa;
        goto ZllZ9;
        yb7X0:
        $this->cGz6K = $DAY12;
        goto ejahi;
        ejahi:
        $this->iHPgt = $zeM4q;
        goto et_sg;
        ZllZ9:
    }
    public function blur(string $tu00C) : void
    {
        goto Wi8UM;
        VwKRz:
        LhySv:
        goto l4LRB;
        oM90c:
        $sBL_Q = $this->cGz6K->path($OXbOZ);
        goto ty1vE;
        Wi8UM:
        Log::info("Blurring for video", ['videoID' => $tu00C]);
        goto X7LIl;
        d9Tt5:
        if (chmod($sBL_Q, 0664)) {
            goto p1TZQ;
        }
        goto CauSm;
        Cv4yt:
        $YsmpC = $h4i8i->width() / $h4i8i->height();
        goto Y4CrW;
        iPZju:
        $OXbOZ = $this->mo6IqO8Nu4K($pDmAb);
        goto oM90c;
        ty1vE:
        $h4i8i->save($sBL_Q);
        goto b6Ihn;
        X7LIl:
        ini_set('memory_limit', '-1');
        goto Ut8nU;
        Y4CrW:
        $h4i8i->resize(self::xnKoO, self::kWMDX / $YsmpC);
        goto MoxJw;
        CauSm:
        \Log::warning('Failed to set final permissions on image file: ' . $sBL_Q);
        goto V1oIc;
        Ut8nU:
        $pDmAb = SNpic2wzC1yT8::findOrFail($tu00C);
        goto AwMds;
        mIZfe:
        $h4i8i = $this->kAoN_->call($this, $this->cGz6K->path($pDmAb->getAttribute('thumbnail')));
        goto Cv4yt;
        AwMds:
        if (!$pDmAb->getAttribute('thumbnail')) {
            goto LhySv;
        }
        goto y1bH3;
        MoxJw:
        $h4i8i->blur(self::BSgK_);
        goto iPZju;
        sbRwX:
        p1TZQ:
        goto OwrB8;
        b6Ihn:
        $this->iHPgt->put($OXbOZ, $this->cGz6K->get($OXbOZ));
        goto voj4n;
        V1oIc:
        throw new \Exception('Failed to set final permissions on image file: ' . $sBL_Q);
        goto sbRwX;
        voj4n:
        unset($h4i8i);
        goto d9Tt5;
        y1bH3:
        $this->cGz6K->put($pDmAb->getAttribute('thumbnail'), $this->iHPgt->get($pDmAb->getAttribute('thumbnail')));
        goto mIZfe;
        OwrB8:
        $pDmAb->update(['preview' => $OXbOZ]);
        goto VwKRz;
        l4LRB:
    }
    private function mo6IqO8Nu4K(A7djqU0sacoRX $lUg5v) : string
    {
        goto ffjnt;
        hGu0a:
        vRipm:
        goto oa7mK;
        ffjnt:
        $fQjwQ = $lUg5v->getLocation();
        goto wXB1F;
        wXB1F:
        $Ih_l8 = dirname($fQjwQ) . '/preview/';
        goto vCJqd;
        nJeIp:
        $this->cGz6K->makeDirectory($Ih_l8, 0755, true);
        goto hGu0a;
        oa7mK:
        return $Ih_l8 . $lUg5v->getFilename() . '.jpg';
        goto A5EbL;
        vCJqd:
        if ($this->cGz6K->exists($Ih_l8)) {
            goto vRipm;
        }
        goto nJeIp;
        A5EbL:
    }
}
