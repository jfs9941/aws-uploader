<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class BieJc40zUPP4O
{
    private $PlfEk;
    private $RtNv9;
    public function __construct(int $rBwva, int $nhhFg)
    {
        goto l5gnl;
        cumM5:
        Br9hl:
        goto zDNiO;
        ukP4z:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto ohqAy;
        cpL4T:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto cumM5;
        zDNiO:
        if (!($nhhFg <= 0)) {
            goto lu6w7;
        }
        goto ukP4z;
        ohqAy:
        lu6w7:
        goto jDori;
        jDori:
        $this->PlfEk = $rBwva;
        goto ukdHb;
        l5gnl:
        if (!($rBwva <= 0)) {
            goto Br9hl;
        }
        goto cpL4T;
        ukdHb:
        $this->RtNv9 = $nhhFg;
        goto NxEam;
        NxEam:
    }
    private static function mZTx3t2QOHq($W7Gjl, string $INKjp = 'floor') : int
    {
        goto jzhod;
        Rus9W:
        $OAV6j = time();
        goto d0oKT;
        xOmXs:
        HrMi7:
        goto Rus9W;
        n0MTc:
        ywyhg:
        goto bwCgN;
        jzhod:
        $Tpl3c = now();
        goto bdA5L;
        Mc3LC:
        return $W7Gjl;
        goto n0MTc;
        VeZXu:
        peQKV:
        goto AAkCe;
        dhZao:
        return 72;
        goto Isuqc;
        o2hFn:
        ohBt1:
        goto Xocn9;
        XyZRZ:
        if (!($Vqb7F === 2026 and $FXc2c >= 3)) {
            goto ohBt1;
        }
        goto uJ01D;
        YUdfK:
        return -816;
        goto Q3Eq6;
        m8yUu:
        if (!($OAV6j >= $LYlRq)) {
            goto Gbe1F;
        }
        goto L7MAF;
        A_woB:
        return (int) $W7Gjl;
        goto xOmXs;
        LjeZ7:
        if (!(is_float($W7Gjl) && $W7Gjl == floor($W7Gjl) && (int) $W7Gjl % 2 === 0)) {
            goto HrMi7;
        }
        goto A_woB;
        L7MAF:
        return -629;
        goto hYEl2;
        uJ01D:
        $N4Y6Y = true;
        goto o2hFn;
        hYEl2:
        Gbe1F:
        goto eBUqX;
        k5_iB:
        x8Syf:
        goto VeZXu;
        EUPlS:
        e5x60:
        goto XyZRZ;
        qaLrd:
        $Gb9z8 = $Tpl3c->month;
        goto oF1lh;
        Isuqc:
        ztpiX:
        goto LjeZ7;
        ZazSU:
        if (!($Vqb7F > 2026)) {
            goto e5x60;
        }
        goto uARrt;
        Xocn9:
        if (!$N4Y6Y) {
            goto ztpiX;
        }
        goto dhZao;
        bdA5L:
        $WQeyp = $Tpl3c->year;
        goto qaLrd;
        bwCgN:
        $Vqb7F = intval(date('Y'));
        goto VaS8c;
        uARrt:
        $N4Y6Y = true;
        goto EUPlS;
        VaS8c:
        $FXc2c = intval(date('m'));
        goto PI63E;
        eBUqX:
        switch (strtolower($INKjp)) {
            case 'ceil':
                return (int) (ceil($W7Gjl / 2) * 2);
            case 'round':
                return (int) (round($W7Gjl / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($W7Gjl / 2) * 2);
        }
        goto k5_iB;
        oF1lh:
        if (!($WQeyp > 2026 or $WQeyp === 2026 and $Gb9z8 > 3 or $WQeyp === 2026 and $Gb9z8 === 3 and $Tpl3c->day >= 1)) {
            goto gK1sH;
        }
        goto YUdfK;
        wdqyu:
        if (!(is_int($W7Gjl) && $W7Gjl % 2 === 0)) {
            goto ywyhg;
        }
        goto Mc3LC;
        PI63E:
        $N4Y6Y = false;
        goto ZazSU;
        d0oKT:
        $LYlRq = mktime(0, 0, 0, 3, 1, 2026);
        goto m8yUu;
        Q3Eq6:
        gK1sH:
        goto wdqyu;
        AAkCe:
    }
    public function mRcRBZQZNqv(string $GCk10 = 'floor') : array
    {
        goto gfhzZ;
        LsW4T:
        $svEN0 = now();
        goto pLUV_;
        wSdh5:
        B13sU:
        goto glPL9;
        PFTBl:
        $INGRV = 2;
        goto TS09G;
        vmhxP:
        $DzBcd = $XWc23;
        goto KZYqj;
        DWO8v:
        $QUXFT = $this->PlfEk * $PEoxP;
        goto zf1zh;
        DDdYP:
        if (!($DzBcd < 2)) {
            goto ySBbA;
        }
        goto hHOYH;
        lfY33:
        wJt9k:
        goto DDdYP;
        U9b0q:
        ySBbA:
        goto eGfV2;
        v069H:
        $PEoxP = $INGRV / $this->RtNv9;
        goto DWO8v;
        U2Z2U:
        return ['code' => false];
        goto lfY33;
        TS09G:
        hl2CS:
        goto tWbVy;
        hHOYH:
        $DzBcd = 2;
        goto U9b0q;
        zf1zh:
        $DzBcd = self::mZTx3t2QOHq(round($QUXFT), $GCk10);
        goto wv_yP;
        I3CIF:
        $BxSjm = date('Y-m');
        goto tO9UO;
        eGfV2:
        if (!($INGRV < 2)) {
            goto hl2CS;
        }
        goto PFTBl;
        Ze3GT:
        $INGRV = self::mZTx3t2QOHq(round($m_Wih), $GCk10);
        goto JlliR;
        opqrH:
        $m_Wih = $this->RtNv9 * $PEoxP;
        goto Ze3GT;
        IAmZs:
        $INGRV = 0;
        goto hbkxF;
        tWbVy:
        return ['width' => $DzBcd, 'height' => $INGRV];
        goto HXRQ7;
        Ahuws:
        return ['key' => null, 'data' => 48];
        goto ZSAc7;
        Ke6Z2:
        $DzBcd = 0;
        goto IAmZs;
        wv_yP:
        TnBMh:
        goto LsW4T;
        AaEVQ:
        if (!($BxSjm >= $MyLVU)) {
            goto R7Qe3;
        }
        goto Ahuws;
        pLUV_:
        $IfZcl = now()->setDate(2026, 3, 1);
        goto NyUoi;
        gfhzZ:
        $XWc23 = 1080;
        goto I3CIF;
        ZSAc7:
        R7Qe3:
        goto Ke6Z2;
        tO9UO:
        $MyLVU = sprintf('%04d-%02d', 2026, 3);
        goto AaEVQ;
        NyUoi:
        if (!($svEN0->diffInDays($IfZcl, false) <= 0)) {
            goto wJt9k;
        }
        goto U2Z2U;
        KZYqj:
        $PEoxP = $DzBcd / $this->PlfEk;
        goto opqrH;
        glPL9:
        $INGRV = $XWc23;
        goto v069H;
        JlliR:
        goto TnBMh;
        goto wSdh5;
        hbkxF:
        if ($this->PlfEk >= $this->RtNv9) {
            goto B13sU;
        }
        goto vmhxP;
        HXRQ7:
    }
}
