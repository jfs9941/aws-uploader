<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Illuminate\Support\Facades\Log;
class KOeKE7qZsdPoS implements StoreVideoToS3JobInterface
{
    private $BDS__;
    private $QxLu3;
    private $aW0a3;
    public function __construct($v4kIW, $bjIIR, $eEhuZ)
    {
        goto WOHYx;
        K91gC:
        $this->aW0a3 = $eEhuZ;
        goto CBAt7;
        CBAt7:
        $this->BDS__ = $v4kIW;
        goto x8Njx;
        WOHYx:
        $this->QxLu3 = $bjIIR;
        goto K91gC;
        x8Njx:
    }
    public function store(string $qMhfW) : void
    {
        goto dIWZy;
        Zl288:
        $S3kxc = NYx4mhlHSMgHF::find($qMhfW);
        goto m1EYD;
        dIWZy:
        Log::info('Storing video (local) to S3', ['fileId' => $qMhfW, 'bucketName' => $this->BDS__]);
        goto B720c;
        B720c:
        ini_set('memory_limit', '-1');
        goto L4msr;
        m1EYD:
        if ($S3kxc) {
            goto PH9gN;
        }
        goto QVTKl;
        QVTKl:
        Log::info("NYx4mhlHSMgHF has been deleted, discard it", ['fileId' => $qMhfW]);
        goto AOGnm;
        Li_0h:
        $nrXNy = memory_get_peak_usage();
        goto Fby0J;
        AOGnm:
        return;
        goto tqMl4;
        sTYVe:
        $gJ1qz = $eEhuZ->readStream($S3kxc->getLocation());
        goto BHESe;
        XMxXV:
        if ($eEhuZ->exists($S3kxc->getLocation())) {
            goto BS5tS;
        }
        goto eGryO;
        kaxf7:
        $u4XNo = microtime(true);
        goto D5P2e;
        HPVT4:
        return;
        goto hxTfB;
        BHESe:
        $icV6U = 1024 * 1024 * 50;
        goto L766a;
        L766a:
        $oQAFo = $eEhuZ->mimeType($S3kxc->getLocation());
        goto kaxf7;
        tqMl4:
        PH9gN:
        goto XMxXV;
        L4msr:
        $qNnht = $this->QxLu3->getClient();
        goto WkP4n;
        hxTfB:
        BS5tS:
        goto sTYVe;
        Fby0J:
        try {
            goto wsyTh;
            TCcdn:
            fclose($gJ1qz);
            goto YJh3_;
            zj4Xu:
            MyTQ3:
            goto PG0bJ;
            rAyQ9:
            $S3kxc->update(['driver' => YOaiWCgFM7tRK::S3, 'status' => TSfaBZEUMcbl0::FINISHED]);
            goto fmLL0;
            vO7oa:
            $bXjPU = $aCVXA['UploadId'];
            goto qc5jU;
            wsyTh:
            $aCVXA = $qNnht->createMultipartUpload(['Bucket' => $this->BDS__, 'Key' => $S3kxc->getLocation(), 'ContentType' => $oQAFo, 'ContentDisposition' => 'inline']);
            goto vO7oa;
            qc5jU:
            $PDKrb = 1;
            goto ulVAE;
            VKt1e:
            goto MyTQ3;
            goto RPrG5;
            fmLL0:
            $eEhuZ->delete($S3kxc->getLocation());
            goto Xp5d_;
            YJh3_:
            $qNnht->completeMultipartUpload(['Bucket' => $this->BDS__, 'Key' => $S3kxc->getLocation(), 'UploadId' => $bXjPU, 'MultipartUpload' => ['Parts' => $bQ_Iq]]);
            goto rAyQ9;
            z2TwE:
            $bQ_Iq[] = ['PartNumber' => $PDKrb, 'ETag' => $JKUBM['ETag']];
            goto ck_n8;
            ck_n8:
            $PDKrb++;
            goto VKt1e;
            PG0bJ:
            if (feof($gJ1qz)) {
                goto Ny60v;
            }
            goto xOyNM;
            xOyNM:
            $JKUBM = $qNnht->uploadPart(['Bucket' => $this->BDS__, 'Key' => $S3kxc->getLocation(), 'UploadId' => $bXjPU, 'PartNumber' => $PDKrb, 'Body' => fread($gJ1qz, $icV6U)]);
            goto z2TwE;
            RPrG5:
            Ny60v:
            goto TCcdn;
            ulVAE:
            $bQ_Iq = [];
            goto zj4Xu;
            Xp5d_:
        } catch (AwsException $X3u3n) {
            goto M7E62;
            bDFpd:
            Log::error('Failed to store video: ' . $S3kxc->getLocation() . ' - ' . $X3u3n->getMessage());
            goto SMxsF;
            ZqMha:
            WNbxO:
            goto bDFpd;
            Qokud:
            try {
                $qNnht->abortMultipartUpload(['Bucket' => $this->BDS__, 'Key' => $S3kxc->getLocation(), 'UploadId' => $bXjPU]);
            } catch (AwsException $JYS2d) {
                Log::error('Error aborting multipart upload: ' . $JYS2d->getMessage());
            }
            goto ZqMha;
            M7E62:
            if (!isset($bXjPU)) {
                goto WNbxO;
            }
            goto Qokud;
            SMxsF:
        } finally {
            $dFOsw = microtime(true);
            $IfrVA = memory_get_usage();
            $O6V3s = memory_get_peak_usage();
            Log::info('Store NYx4mhlHSMgHF to S3 function resource usage', ['imageId' => $qMhfW, 'execution_time_sec' => $dFOsw - $u4XNo, 'memory_usage_mb' => ($IfrVA - $E9dxY) / 1024 / 1024, 'peak_memory_usage_mb' => ($O6V3s - $nrXNy) / 1024 / 1024]);
        }
        goto XlcSl;
        D5P2e:
        $E9dxY = memory_get_usage();
        goto Li_0h;
        eGryO:
        Log::error("[KOeKE7qZsdPoS] File not found, discard it ", ['video' => $S3kxc->getLocation()]);
        goto HPVT4;
        WkP4n:
        $eEhuZ = $this->aW0a3;
        goto Zl288;
        XlcSl:
    }
}
