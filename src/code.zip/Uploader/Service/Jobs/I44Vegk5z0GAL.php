<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class I44Vegk5z0GAL implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $R7IrL) : void
    {
        goto OK5Kx;
        OK5Kx:
        $cZ20c = B6s4AA1exjQ2T::findOrFail($R7IrL);
        goto S3Kcf;
        qfpRQ:
        YTOAd:
        goto uIy32;
        mQpHA:
        $this->m4hrKVmkhpF($cZ20c);
        goto qfpRQ;
        S3Kcf:
        if ($cZ20c->width() > 0 && $cZ20c->height() > 0) {
            goto YTOAd;
        }
        goto mQpHA;
        uIy32:
    }
    private function m4hrKVmkhpF(B6s4AA1exjQ2T $js0c_) : void
    {
        goto XeixK;
        S_KQl:
        $js0c_->update(['duration' => $BOX5t->getDurationInSeconds(), 'resolution' => $YMwou->getWidth() . 'x' . $YMwou->getHeight(), 'fps' => $sj3Qa->get('r_frame_rate') ?? 30]);
        goto rnxDJ;
        AZNuV:
        $sj3Qa = $BOX5t->getVideoStream();
        goto Yjvd7;
        Jh8NJ:
        $BOX5t = FFMpeg::fromDisk($faVyj['path'])->open($js0c_->getAttribute('filename'));
        goto AZNuV;
        Yjvd7:
        $YMwou = $sj3Qa->getDimensions();
        goto S_KQl;
        XeixK:
        $faVyj = $js0c_->getView();
        goto Jh8NJ;
        rnxDJ:
    }
}
