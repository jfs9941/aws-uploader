<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Encoder\SbtGdhmiZTwWn;
use Jfs\Uploader\Encoder\IY6DvZwAf7aLQ;
use Jfs\Uploader\Encoder\MquUYPN1EJDdI;
use Jfs\Uploader\Encoder\PKlJdyi6xw084;
use Jfs\Uploader\Encoder\HOZ8jeXzeceNN;
use Jfs\Uploader\Encoder\UGwU8wiaV6qMB;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
use Jfs\Uploader\Service\JrqDsqkHsYBsl;
use Webmozart\Assert\Assert;
class RZtVIUu2mPjJE implements MediaEncodeJobInterface
{
    private $HY2hW;
    private $OQTXf;
    private $RaPnW;
    private $eVAG5;
    private $r2W0C;
    public function __construct(string $bqJVe, $eL8cO, $hTkyv, $Ar8h8, $ZoZ6N)
    {
        goto hJLKa;
        mxjBX:
        $this->eVAG5 = $Ar8h8;
        goto C4RzH;
        zMyzq:
        $this->OQTXf = $eL8cO;
        goto IPyjp;
        IPyjp:
        $this->RaPnW = $hTkyv;
        goto mxjBX;
        C4RzH:
        $this->r2W0C = $ZoZ6N;
        goto WLZ4y;
        hJLKa:
        $this->HY2hW = $bqJVe;
        goto zMyzq;
        WLZ4y:
    }
    public function encode(string $UcmDx, string $grG7O, $WMvYM = true) : void
    {
        goto BHfua;
        GfCCJ:
        ini_set('memory_limit', '-1');
        goto fa50M;
        BHfua:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $UcmDx]);
        goto GfCCJ;
        fa50M:
        try {
            goto xKQTZ;
            EvJ7p:
            if (!$this->meD0mcBYltg($n9snl, $M0J4r)) {
                goto QXkv2;
            }
            goto QtNbd;
            nqepd:
            $aeumJ = new SsZ0mh1c89bBF($this->eVAG5, $this->r2W0C, $this->RaPnW, $this->OQTXf);
            goto TxijC;
            xKQTZ:
            $KuX31 = QdnSnf08v9RV7::findOrFail($UcmDx);
            goto ylozU;
            hXusJ:
            Tp9Te:
            goto zhHcr;
            ay8_T:
            if (!$Iu3mb) {
                goto Tp9Te;
            }
            goto jUWXR;
            GP_jy:
            $sQ_dN = $sQ_dN->mpKTEvsTBmY($FFU0R);
            goto qd8na;
            VWkta:
            throw new MediaConverterException("QdnSnf08v9RV7 {$KuX31->id} is not S3 driver");
            goto g7t12;
            QJsoN:
            if (!$Iu3mb) {
                goto m3Wmd;
            }
            goto kuZHt;
            Imv_8:
            $sQ_dN->mPPcd3dshAp($WHycl->m5KnHMFYC9O($KuX31));
            goto U0ts0;
            suz4X:
            $CARl5 = $this->mCbPnZv8YZ1($KuX31);
            goto UMG2S;
            ZRewY:
            m3Wmd:
            goto fG6Ws;
            uLS2C:
            tQQR9:
            goto TuR48;
            efYu6:
            $FFU0R = new SbtGdhmiZTwWn($KuX31->vmwlv ?? 1, 2, $WHycl->mqJJckNGKb7($KuX31));
            goto GP_jy;
            zhHcr:
            $sQ_dN->mi8D4hxwFye($T10LI);
            goto Imv_8;
            fG6Ws:
            $sQ_dN = $sQ_dN->mi8D4hxwFye($lHqD7);
            goto wB3Qm;
            tKRF0:
            if (!($KuX31->H9HlK !== KPpxBU3Qc8yRk::S3)) {
                goto niIGk;
            }
            goto VWkta;
            HTiHG:
            $M0J4r = $KuX31->height();
            goto suz4X;
            pvMYA:
            $T10LI = new IY6DvZwAf7aLQ('original', $n9snl, $M0J4r, $KuX31->KpvTz ?? 30);
            goto izBDO;
            kuZHt:
            $lHqD7 = $lHqD7->msfr5qJzRmo($Iu3mb);
            goto ZRewY;
            fCgwc:
            $n9snl = $KuX31->width();
            goto HTiHG;
            QEp4B:
            $sQ_dN->mPPcd3dshAp($WHycl->m5KnHMFYC9O($KuX31));
            goto sf9kr;
            Y5mjg:
            $lHqD7 = new IY6DvZwAf7aLQ('1080p', $Y_QOC['width'], $Y_QOC['height'], $KuX31->KpvTz ?? 30);
            goto rCVhf;
            J28fO:
            Log::info("Set 1080p resolution for Job", ['width' => $Y_QOC['width'], 'height' => $Y_QOC['height'], 'originalWidth' => $n9snl, 'originalHeight' => $M0J4r]);
            goto Y5mjg;
            TxijC:
            $Iu3mb = $this->mTFG4lldhfK($XNWw2, $aeumJ->mN7QCjDOwk9($KuX31->width(), $KuX31->height(), $grG7O));
            goto ay8_T;
            SUcfZ:
            $KuX31->update(['aws_media_converter_job_id' => $UcmDx]);
            goto csizw;
            TuR48:
            Log::info("Set thumbnail for QdnSnf08v9RV7 Job", ['videoId' => $KuX31->getAttribute('id'), 'duration' => $KuX31->getAttribute('duration')]);
            goto efYu6;
            EJbNk:
            $sQ_dN->mi8D4hxwFye($T10LI);
            goto QEp4B;
            rCVhf:
            $Iu3mb = $this->mTFG4lldhfK($XNWw2, $aeumJ->mN7QCjDOwk9((int) $Y_QOC['width'], (int) $Y_QOC['height'], $grG7O));
            goto QJsoN;
            sf9kr:
            $XNWw2 = app(JrqDsqkHsYBsl::class);
            goto nqepd;
            qd8na:
            $UcmDx = $sQ_dN->mBaMGNuQcz1($this->mLFyUEJgyzz($KuX31, $WMvYM));
            goto SUcfZ;
            jUWXR:
            $T10LI = $T10LI->msfr5qJzRmo($Iu3mb);
            goto hXusJ;
            UMG2S:
            Log::info("Set input video for Job", ['s3Uri' => $CARl5]);
            goto JzHfA;
            ylozU:
            Assert::isInstanceOf($KuX31, QdnSnf08v9RV7::class);
            goto tKRF0;
            NPrrw:
            $sQ_dN = $sQ_dN->mVvFjPHT0qr(new PKlJdyi6xw084($CARl5));
            goto pvMYA;
            wB3Qm:
            QXkv2:
            goto uLS2C;
            izBDO:
            $WHycl = app(MquUYPN1EJDdI::class);
            goto EJbNk;
            QtNbd:
            $Y_QOC = $this->mLA1pvAVnin($n9snl, $M0J4r);
            goto J28fO;
            g7t12:
            niIGk:
            goto fCgwc;
            U0ts0:
            if (!($n9snl && $M0J4r)) {
                goto tQQR9;
            }
            goto EvJ7p;
            JzHfA:
            $sQ_dN = app(HOZ8jeXzeceNN::class);
            goto NPrrw;
            csizw:
        } catch (\Exception $sdtX4) {
            Log::info("QdnSnf08v9RV7 has been deleted, discard it", ['fileId' => $UcmDx, 'err' => $sdtX4->getMessage()]);
            return;
        }
        goto BDTN3;
        BDTN3:
    }
    private function mLFyUEJgyzz(QdnSnf08v9RV7 $KuX31, $WMvYM) : bool
    {
        goto Oa0oC;
        hQPSL:
        switch (true) {
            case $KuX31->width() * $KuX31->height() >= 1920 * 1080 && $KuX31->width() * $KuX31->height() < 2560 * 1440:
                return $YgH2u > 10 * 60;
            case $KuX31->width() * $KuX31->height() >= 2560 * 1440 && $KuX31->width() * $KuX31->height() < 3840 * 2160:
                return $YgH2u > 5 * 60;
            case $KuX31->width() * $KuX31->height() >= 3840 * 2160:
                return $YgH2u > 3 * 60;
            default:
                return false;
        }
        goto CrQHe;
        wPYxo:
        He2yq:
        goto z0dCJ;
        Oa0oC:
        if ($WMvYM) {
            goto XQ2pd;
        }
        goto lrORG;
        tftXB:
        $YgH2u = (int) round($KuX31->getAttribute('duration') ?? 0);
        goto hQPSL;
        lrORG:
        return false;
        goto IGUi9;
        IGUi9:
        XQ2pd:
        goto tftXB;
        CrQHe:
        hYqlE:
        goto wPYxo;
        z0dCJ:
    }
    private function mTFG4lldhfK(JrqDsqkHsYBsl $XNWw2, string $HH5aT) : ?UGwU8wiaV6qMB
    {
        goto YNWKr;
        eQVM8:
        return null;
        goto iX7F6;
        KxNXf:
        fmy_o:
        goto eQVM8;
        YNWKr:
        $gEf7X = $XNWw2->mGPyo7PQkAc($HH5aT);
        goto yFimJ;
        BC3Li:
        if (!$gEf7X) {
            goto fmy_o;
        }
        goto V7Wpp;
        yFimJ:
        Log::info("Resolve watermark for job with url", ['url' => $HH5aT, 'uri' => $gEf7X]);
        goto BC3Li;
        V7Wpp:
        return new UGwU8wiaV6qMB($gEf7X, 0, 0, null, null);
        goto KxNXf;
        iX7F6:
    }
    private function meD0mcBYltg(int $n9snl, int $M0J4r) : bool
    {
        return $n9snl * $M0J4r > 1.5 * (1920 * 1080);
    }
    private function mLA1pvAVnin(int $n9snl, int $M0J4r) : array
    {
        $V4PzM = new WdWZVKAS2G6OQ($n9snl, $M0J4r);
        return $V4PzM->m0GQWft94gB();
    }
    private function mCbPnZv8YZ1(DYGJpbj9Ye8wY $bcJEK) : string
    {
        goto Y9U_3;
        WLHV8:
        return 's3://' . $this->HY2hW . '/' . $bcJEK->filename;
        goto cgLKL;
        IPygX:
        return $this->OQTXf->url($bcJEK->filename);
        goto N1AO6;
        Y9U_3:
        if (!($bcJEK->H9HlK == KPpxBU3Qc8yRk::S3)) {
            goto QmCyo;
        }
        goto WLHV8;
        cgLKL:
        QmCyo:
        goto IPygX;
        N1AO6:
    }
}
