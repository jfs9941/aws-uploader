<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Illuminate\Support\Facades\Log;
class OETqqRpOBuv1I implements BlurVideoJobInterface
{
    const f95m3 = 15;
    const clrxQ = 500;
    const xFDkW = 500;
    private $T1B34;
    private $VJN91;
    private $EaJ_d;
    public function __construct($V0xce, $J83Op, $t9atP)
    {
        goto gVaUS;
        gVaUS:
        $this->EaJ_d = $t9atP;
        goto okpt1;
        okpt1:
        $this->VJN91 = $J83Op;
        goto BKEqc;
        BKEqc:
        $this->T1B34 = $V0xce;
        goto Gr5px;
        Gr5px:
    }
    public function blur(string $wAkkA) : void
    {
        goto sfDBS;
        CYVbO:
        $this->VJN91->put($PI9rG, $this->EaJ_d->get($PI9rG));
        goto ZQP4f;
        Aj04J:
        Bk1nV:
        goto zD3bd;
        RcHDl:
        $I3L3e = $this->EaJ_d->path($PI9rG);
        goto wve2p;
        hPKNe:
        $lu07a = $this->T1B34->call($this, $this->EaJ_d->path($dxzL5->getAttribute('thumbnail')));
        goto qw3a3;
        I9Q0F:
        \Log::warning('Failed to set final permissions on image file: ' . $I3L3e);
        goto PRg3h;
        Dy8PQ:
        if (!$dxzL5->getAttribute('thumbnail')) {
            goto Bk1nV;
        }
        goto WIRiA;
        jACc6:
        ini_set('memory_limit', '-1');
        goto T72G3;
        x8nwM:
        $lu07a->blur(self::f95m3);
        goto U3YSg;
        U3YSg:
        $PI9rG = $this->msiqSPM5Pal($dxzL5);
        goto RcHDl;
        mm2U1:
        if (chmod($I3L3e, 0664)) {
            goto PoTaB;
        }
        goto I9Q0F;
        shJnc:
        $dxzL5->update(['preview' => $PI9rG]);
        goto Aj04J;
        qw3a3:
        $X8aMX = $lu07a->width() / $lu07a->height();
        goto BBb3M;
        sfDBS:
        Log::info("Blurring for video", ['videoID' => $wAkkA]);
        goto jACc6;
        T72G3:
        $dxzL5 = WI5WSPGRr1b2t::findOrFail($wAkkA);
        goto Dy8PQ;
        ZQP4f:
        unset($lu07a);
        goto mm2U1;
        WIRiA:
        $this->EaJ_d->put($dxzL5->getAttribute('thumbnail'), $this->VJN91->get($dxzL5->getAttribute('thumbnail')));
        goto hPKNe;
        PRg3h:
        throw new \Exception('Failed to set final permissions on image file: ' . $I3L3e);
        goto mW2D4;
        wve2p:
        $lu07a->save($I3L3e);
        goto CYVbO;
        BBb3M:
        $lu07a->resize(self::clrxQ, self::xFDkW / $X8aMX);
        goto x8nwM;
        mW2D4:
        PoTaB:
        goto shJnc;
        zD3bd:
    }
    private function msiqSPM5Pal(WlFu7DaMUEnSS $lq1ns) : string
    {
        goto LINbT;
        wOUwR:
        $this->EaJ_d->makeDirectory($QbBrE, 0755, true);
        goto ZOaSh;
        OGfC7:
        return $QbBrE . $lq1ns->getFilename() . '.jpg';
        goto jWSfm;
        zY874:
        $QbBrE = dirname($L5bJW) . '/preview/';
        goto uzL2s;
        ZOaSh:
        IjZIt:
        goto OGfC7;
        LINbT:
        $L5bJW = $lq1ns->getLocation();
        goto zY874;
        uzL2s:
        if ($this->EaJ_d->exists($QbBrE)) {
            goto IjZIt;
        }
        goto wOUwR;
        jWSfm:
    }
}
