<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Illuminate\Support\Facades\Log;
class U8keiRd0JeOLQ implements DownloadToLocalJobInterface
{
    private $PxC6l;
    private $MpAl4;
    public function __construct($kxhX9, $U2KRS)
    {
        $this->PxC6l = $kxhX9;
        $this->MpAl4 = $U2KRS;
    }
    public function download(string $S580N) : void
    {
        goto Qm2aE;
        g0XES:
        if (!$this->MpAl4->exists($gNVOT->getLocation())) {
            goto CLWCL;
        }
        goto ZXTDM;
        ZXTDM:
        return;
        goto NeYBd;
        L2nWI:
        $this->MpAl4->put($gNVOT->getLocation(), $this->PxC6l->get($gNVOT->getLocation()));
        goto nWaKc;
        NeYBd:
        CLWCL:
        goto L2nWI;
        YwcN0:
        Log::info("Start download file to local", ['fileId' => $S580N, 'filename' => $gNVOT->getLocation()]);
        goto g0XES;
        Qm2aE:
        $gNVOT = KfEJaEGpFJ0tm::findOrFail($S580N);
        goto YwcN0;
        nWaKc:
    }
}
