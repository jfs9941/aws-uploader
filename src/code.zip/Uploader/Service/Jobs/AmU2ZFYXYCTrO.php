<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class AmU2ZFYXYCTrO implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $EmnXX) : void
    {
        goto n1vhs;
        n1vhs:
        $oS5x2 = M7oTJdNm24KG4::findOrFail($EmnXX);
        goto Cp187;
        Cp187:
        if ($oS5x2->width() > 0 && $oS5x2->height() > 0) {
            goto SVbs6;
        }
        goto v74Mk;
        v74Mk:
        $this->mmAk3MUQMfL($oS5x2);
        goto cCaxw;
        cCaxw:
        SVbs6:
        goto HTfYF;
        HTfYF:
    }
    private function mmAk3MUQMfL(M7oTJdNm24KG4 $vvube) : void
    {
        goto Fsm8R;
        dKbD3:
        $Zt12Z = FFMpeg::fromDisk($dHapF)->open($vvube->getAttribute('filename'));
        goto HQto2;
        bOlvF:
        $b2pSA = $IHI3g->getDimensions();
        goto EQWcE;
        EQWcE:
        $vvube->update(['duration' => $Zt12Z->getDurationInSeconds(), 'resolution' => $b2pSA->getWidth() . 'x' . $b2pSA->getHeight(), 'fps' => 30]);
        goto RaMR0;
        HQto2:
        $IHI3g = $Zt12Z->getVideoStream();
        goto bOlvF;
        Fsm8R:
        $dHapF = $vvube->getAttribute('driver') === 1 ? 's3' : 'public';
        goto dKbD3;
        RaMR0:
    }
}
