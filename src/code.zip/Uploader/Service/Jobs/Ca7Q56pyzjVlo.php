<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Illuminate\Support\Facades\Log;
class Ca7Q56pyzjVlo implements DownloadToLocalJobInterface
{
    private $huyLW;
    private $Ntit8;
    public function __construct($A3hvZ, $MYg0D)
    {
        $this->huyLW = $A3hvZ;
        $this->Ntit8 = $MYg0D;
    }
    public function download(string $arqvy) : void
    {
        goto eH5UK;
        xqscn:
        AHP0Z:
        goto I1Lwm;
        FIuSM:
        if (!$this->Ntit8->exists($FJFJj->getLocation())) {
            goto AHP0Z;
        }
        goto RJI00;
        RJI00:
        return;
        goto xqscn;
        ksAiM:
        Log::info("Start download file to local", ['fileId' => $arqvy, 'filename' => $FJFJj->getLocation()]);
        goto FIuSM;
        I1Lwm:
        $this->Ntit8->put($FJFJj->getLocation(), $this->huyLW->get($FJFJj->getLocation()));
        goto xsKE4;
        eH5UK:
        $FJFJj = S7LEoIprYtLQw::findOrFail($arqvy);
        goto ksAiM;
        xsKE4:
    }
}
