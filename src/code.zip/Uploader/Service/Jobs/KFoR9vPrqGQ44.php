<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class KFoR9vPrqGQ44 implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $ld8Ad) : void
    {
        goto aNBha;
        J0eTT:
        XcwVV:
        goto YnxbO;
        aNBha:
        $Ipllx = RVcEF1JsGQd8M::findOrFail($ld8Ad);
        goto IQgfS;
        IQgfS:
        if ($Ipllx->width() > 0 && $Ipllx->height() > 0) {
            goto XcwVV;
        }
        goto SiHF0;
        SiHF0:
        $this->mFr9yYvcqVG($Ipllx);
        goto J0eTT;
        YnxbO:
    }
    private function mFr9yYvcqVG(RVcEF1JsGQd8M $ij6wF) : void
    {
        goto oMjD4;
        smpvu:
        $ITGhv = $csSew->getVideoStream();
        goto ckstZ;
        RkA97:
        $csSew = FFMpeg::fromDisk($TdECi['path'])->open($ij6wF->getAttribute('filename'));
        goto smpvu;
        Zblwf:
        $ij6wF->update(['duration' => $csSew->getDurationInSeconds(), 'resolution' => $QyGpd->getWidth() . 'x' . $QyGpd->getHeight(), 'fps' => $ITGhv->get('r_frame_rate') ?? 30]);
        goto RK2xS;
        oMjD4:
        $TdECi = $ij6wF->getView();
        goto RkA97;
        ckstZ:
        $QyGpd = $ITGhv->getDimensions();
        goto Zblwf;
        RK2xS:
    }
}
