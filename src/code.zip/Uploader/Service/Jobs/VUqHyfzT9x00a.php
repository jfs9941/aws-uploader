<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class VUqHyfzT9x00a implements GenerateThumbnailJobInterface
{
    const HcR9a = 150;
    const cMOcE = 150;
    private $JG9IT;
    private $Ntit8;
    private $pdBhJ;
    public function __construct($mLPCZ, $MYg0D, $qMGry)
    {
        goto nIfuI;
        cy3Vu:
        $this->Ntit8 = $MYg0D;
        goto EGTz5;
        EGTz5:
        $this->pdBhJ = $qMGry;
        goto bX6Z7;
        nIfuI:
        $this->JG9IT = $mLPCZ;
        goto cy3Vu;
        bX6Z7:
    }
    public function generate(string $arqvy)
    {
        goto Uhzap;
        Uhzap:
        Log::info("Generating thumbnail", ['imageId' => $arqvy]);
        goto X4EOY;
        X4EOY:
        ini_set('memory_limit', '-1');
        goto CaD7E;
        CaD7E:
        try {
            goto Fzwka;
            DhAtE:
            $Yzn18 = $this->pdBhJ->put($lxbX3, $PqcRJ->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto M3Z_v;
            M3Z_v:
            unset($PqcRJ);
            goto J0rsL;
            Kbr9s:
            ks87W:
            goto Ud0Le;
            l0YQC:
            $uuvVo->update(['thumbnail' => $lxbX3, 'status' => EXecNg2hg7kwl::THUMBNAIL_PROCESSED]);
            goto Kbr9s;
            QpHUQ:
            $lxbX3 = $this->mnlfwhv6ERF($uuvVo);
            goto DhAtE;
            gtd8q:
            $PqcRJ = $this->JG9IT->call($this, $B27Pk->path($uuvVo->getLocation()));
            goto hQB40;
            J0rsL:
            if (!($Yzn18 !== false)) {
                goto ks87W;
            }
            goto l0YQC;
            hQB40:
            $PqcRJ->orient()->resize(150, 150);
            goto QpHUQ;
            Fzwka:
            $B27Pk = $this->Ntit8;
            goto Iz64g;
            Iz64g:
            $uuvVo = S7LEoIprYtLQw::findOrFail($arqvy);
            goto gtd8q;
            Ud0Le:
        } catch (ModelNotFoundException $FTnqg) {
            Log::info("S7LEoIprYtLQw has been deleted, discard it", ['imageId' => $arqvy]);
            return;
        } catch (\Exception $FTnqg) {
            Log::error("Failed to generate thumbnail", ['imageId' => $arqvy, 'error' => $FTnqg->getMessage()]);
        }
        goto vvlme;
        vvlme:
    }
    private function mnlfwhv6ERF(NRDoWGrbd9WhU $uuvVo) : string
    {
        goto m4AFT;
        lzviW:
        return $eh3bt . '/' . $uuvVo->getFilename() . '.jpg';
        goto akCQi;
        m4AFT:
        $lxbX3 = $uuvVo->getLocation();
        goto N5IvS;
        Xwxm5:
        $eh3bt = $gcOdN . '/' . self::HcR9a . 'X' . self::cMOcE;
        goto lzviW;
        N5IvS:
        $gcOdN = dirname($lxbX3);
        goto Xwxm5;
        akCQi:
    }
}
