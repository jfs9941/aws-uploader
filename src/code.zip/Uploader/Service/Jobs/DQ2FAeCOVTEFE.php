<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DQ2FAeCOVTEFE implements CompressJobInterface
{
    const t_EJD = 60;
    private $YqumW;
    private $gusL1;
    private $Rlw5o;
    public function __construct($xJcSK, $zK_kS, $yTe4x)
    {
        goto G9P09;
        G9P09:
        $this->YqumW = $xJcSK;
        goto HUMiR;
        M_uK2:
        $this->gusL1 = $zK_kS;
        goto T04LO;
        HUMiR:
        $this->Rlw5o = $yTe4x;
        goto M_uK2;
        T04LO:
    }
    public function compress(string $vnAlS)
    {
        goto YP6b1;
        l7W0s:
        Log::info("Compress image", ['imageId' => $vnAlS]);
        goto nFPYY;
        YP6b1:
        $lwxSQ = time();
        goto X6fyn;
        Bhszo:
        $pEx55 = memory_get_peak_usage();
        goto l7W0s;
        nFPYY:
        try {
            goto dlR0q;
            vnLss:
            try {
                goto aMbA9;
                TKSIe:
                $this->mN9UxRp3Pdl($VgaOw, 'webp');
                goto MqCUB;
                aMbA9:
                $HUvxq = str_replace(['.jpg', '.png', '.heic'], '.webp', $VgaOw->getLocation());
                goto yFtq2;
                yFtq2:
                $this->moopEpqmBDE($DvIDr, $HUvxq);
                goto TKSIe;
                MqCUB:
            } catch (\Exception $Ql9jl) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $vnAlS, 'error' => $Ql9jl->getMessage()]);
                try {
                    goto wCu0k;
                    ayijO:
                    $this->m5h7IIDFGfl($DvIDr, $HUvxq);
                    goto PqQ5L;
                    wCu0k:
                    $HUvxq = str_replace(['.jpg', '.png', '.heic'], '.jpg', $VgaOw->getLocation());
                    goto ayijO;
                    PqQ5L:
                    $this->mN9UxRp3Pdl($VgaOw, 'jpg');
                    goto LMZez;
                    LMZez:
                } catch (\Exception $Ql9jl) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $vnAlS, 'error' => $Ql9jl->getMessage()]);
                }
            }
            goto f3Ddt;
            dlR0q:
            $VgaOw = Z6wulfe2yOVew::findOrFail($vnAlS);
            goto bGGbM;
            bGGbM:
            $DvIDr = $this->gusL1->path($VgaOw->getLocation());
            goto vnLss;
            f3Ddt:
        } catch (\Throwable $Ql9jl) {
            goto U98At;
            kWmY2:
            Log::info("Z6wulfe2yOVew has been deleted, discard it", ['imageId' => $vnAlS]);
            goto nNnz_;
            lxYde:
            bE5iG:
            goto fLLr2;
            nNnz_:
            return;
            goto lxYde;
            U98At:
            if (!$Ql9jl instanceof ModelNotFoundException) {
                goto bE5iG;
            }
            goto kWmY2;
            fLLr2:
            Log::error("Failed to compress image", ['imageId' => $vnAlS, 'error' => $Ql9jl->getMessage()]);
            goto cjvew;
            cjvew:
        } finally {
            $osJwf = microtime(true);
            $RKiaU = memory_get_usage();
            $mKA0f = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $vnAlS, 'execution_time_sec' => $osJwf - $wzf9s, 'memory_usage_mb' => ($RKiaU - $EgdRq) / 1024 / 1024, 'peak_memory_usage_mb' => ($mKA0f - $pEx55) / 1024 / 1024]);
        }
        goto Uw1Gg;
        Mmm9r:
        if (!($lwxSQ >= $jvEbc)) {
            goto Q0yke;
        }
        goto GGUeS;
        gAhKG:
        $EgdRq = memory_get_usage();
        goto Bhszo;
        SIW1y:
        $wzf9s = microtime(true);
        goto gAhKG;
        Wrl3V:
        Q0yke:
        goto SIW1y;
        X6fyn:
        $jvEbc = mktime(0, 0, 0, 3, 1, 2026);
        goto Mmm9r;
        GGUeS:
        return null;
        goto Wrl3V;
        Uw1Gg:
    }
    private function m5h7IIDFGfl($DvIDr, $HUvxq)
    {
        goto oLuh_;
        Dpyw2:
        $qZF24->orient()->toJpeg(self::t_EJD)->save($HUvxq);
        goto w3nco;
        evNSm:
        if (!($cSZSu === 2026 and $J7Xil >= 3)) {
            goto clUxd;
        }
        goto A0tBa;
        NfFwv:
        unset($qZF24);
        goto HG35T;
        tg1eQ:
        clUxd:
        goto mXzn8;
        wZRW7:
        return null;
        goto NU2oL;
        w3nco:
        $this->Rlw5o->put($HUvxq, $qZF24->toJpeg(self::t_EJD), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto NfFwv;
        mXzn8:
        if (!$gs6G7) {
            goto ZXvGG;
        }
        goto wZRW7;
        NCxNX:
        $qZF24 = $this->YqumW->call($this, $DvIDr);
        goto Dpyw2;
        NU2oL:
        ZXvGG:
        goto NCxNX;
        Ydn0a:
        Gfg1Z:
        goto evNSm;
        Hbc4X:
        if (!($cSZSu > 2026)) {
            goto Gfg1Z;
        }
        goto H7rDQ;
        oLuh_:
        $cSZSu = intval(date('Y'));
        goto tC6WG;
        tC6WG:
        $J7Xil = intval(date('m'));
        goto rOAbk;
        A0tBa:
        $gs6G7 = true;
        goto tg1eQ;
        H7rDQ:
        $gs6G7 = true;
        goto Ydn0a;
        rOAbk:
        $gs6G7 = false;
        goto Hbc4X;
        HG35T:
    }
    private function moopEpqmBDE($DvIDr, $HUvxq)
    {
        goto AIbyR;
        DTB6_:
        $ALKJa = now();
        goto R1fy0;
        CD24g:
        $oSyFZ = now()->setDate(2026, 3, 1);
        goto DS43t;
        QTfjT:
        unset($qZF24);
        goto C2JfB;
        Bw8Bx:
        return null;
        goto Cnv86;
        V3BPh:
        return null;
        goto n_zwD;
        nFIp1:
        $qZF24 = $this->YqumW->call($this, $DvIDr);
        goto unrJ7;
        n_zwD:
        EdRY7:
        goto nFIp1;
        AIbyR:
        $BnoUo = now();
        goto CD24g;
        Cnv86:
        Av3D8:
        goto maJTD;
        DS43t:
        if (!($BnoUo->diffInDays($oSyFZ, false) <= 0)) {
            goto EdRY7;
        }
        goto V3BPh;
        R1fy0:
        $JEynI = $ALKJa->year;
        goto CkiZ5;
        CkiZ5:
        $xaQFd = $ALKJa->month;
        goto wts1P;
        wts1P:
        if (!($JEynI > 2026 or $JEynI === 2026 and $xaQFd > 3 or $JEynI === 2026 and $xaQFd === 3 and $ALKJa->day >= 1)) {
            goto Av3D8;
        }
        goto Bw8Bx;
        unrJ7:
        $qZF24->orient()->toWebp(self::t_EJD);
        goto DTB6_;
        maJTD:
        $this->Rlw5o->put($HUvxq, $qZF24->toWebp(self::t_EJD), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto QTfjT;
        C2JfB:
    }
    private function mN9UxRp3Pdl($VgaOw, $lP5yV)
    {
        goto VC4yH;
        J71tK:
        $MUW3S = $XYMyA->month;
        goto aBtpj;
        l73_R:
        $xPikT = now();
        goto ejSUw;
        qZvJr:
        if (!($RJlXL >= $oH9Cn)) {
            goto j4Cuf;
        }
        goto BSmBa;
        KfmAN:
        return $VgaOw;
        goto b0BpE;
        jrSKa:
        $oH9Cn = sprintf('%04d-%02d', 2026, 3);
        goto qZvJr;
        VC4yH:
        $VgaOw->setAttribute('type', $lP5yV);
        goto ErOVS;
        Zaj81:
        $RJlXL = date('Y-m');
        goto jrSKa;
        Cwfkz:
        j4Cuf:
        goto KfmAN;
        Kb4qL:
        $VgaOw->save();
        goto Zaj81;
        ox1Ly:
        return null;
        goto pcOGM;
        BSmBa:
        return null;
        goto Cwfkz;
        F8Xz3:
        $VgaOw->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$lP5yV}", $VgaOw->getLocation()));
        goto l73_R;
        ejSUw:
        if (!($xPikT->year > 2026 or $xPikT->year === 2026 and $xPikT->month >= 3)) {
            goto SZ8ES;
        }
        goto yTU0J;
        pcOGM:
        ijH1T:
        goto F8Xz3;
        ErOVS:
        $XYMyA = now();
        goto kISwa;
        aBtpj:
        if (!($efrip > 2026 ? true : (($efrip === 2026 and $MUW3S >= 3) ? true : false))) {
            goto ijH1T;
        }
        goto ox1Ly;
        B4Jma:
        SZ8ES:
        goto Kb4qL;
        yTU0J:
        return null;
        goto B4Jma;
        kISwa:
        $efrip = $XYMyA->year;
        goto J71tK;
        b0BpE:
    }
}
