<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class BZ4eujarFFlCo implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $tu00C) : void
    {
        goto p1fNo;
        hdajH:
        $this->mXzFJoYOxM1($fxrDr);
        goto PFf1i;
        PFf1i:
        R4Vu_:
        goto T6MCF;
        ysFt7:
        if ($fxrDr->width() > 0 && $fxrDr->height() > 0) {
            goto R4Vu_;
        }
        goto hdajH;
        p1fNo:
        $fxrDr = SNpic2wzC1yT8::findOrFail($tu00C);
        goto ysFt7;
        T6MCF:
    }
    private function mXzFJoYOxM1(SNpic2wzC1yT8 $kPdH9) : void
    {
        goto ohW4M;
        hD0WA:
        $dnedQ = $I80en->getVideoStream();
        goto iZp1e;
        LHkfx:
        $I80en = FFMpeg::fromDisk($ld1HK['path'])->open($kPdH9->getAttribute('filename'));
        goto hD0WA;
        ohW4M:
        $ld1HK = $kPdH9->getView();
        goto LHkfx;
        vzDNZ:
        $kPdH9->update(['duration' => $I80en->getDurationInSeconds(), 'resolution' => $i1PdJ->getWidth() . 'x' . $i1PdJ->getHeight(), 'fps' => $dnedQ->get('r_frame_rate') ?? 30]);
        goto QnUVA;
        iZp1e:
        $i1PdJ = $dnedQ->getDimensions();
        goto vzDNZ;
        QnUVA:
    }
}
