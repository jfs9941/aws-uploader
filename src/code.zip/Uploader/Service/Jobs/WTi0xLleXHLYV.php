<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class WTi0xLleXHLYV implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $wAkkA) : void
    {
        goto F8Zi7;
        F8Zi7:
        $hgsqV = WI5WSPGRr1b2t::findOrFail($wAkkA);
        goto vhJdA;
        vhJdA:
        if ($hgsqV->width() > 0 && $hgsqV->height() > 0) {
            goto hXo0f;
        }
        goto NW0hH;
        KCXqP:
        hXo0f:
        goto qUnA7;
        NW0hH:
        $this->mt3lpXGrJ5U($hgsqV);
        goto KCXqP;
        qUnA7:
    }
    private function mt3lpXGrJ5U(WI5WSPGRr1b2t $OwKVg) : void
    {
        goto zzB8X;
        dZeq1:
        $G2mX1 = FFMpeg::fromDisk($kE2kK)->open($OwKVg->getAttribute('filename'));
        goto Yt3Qm;
        Yt3Qm:
        $keiAz = $G2mX1->getVideoStream();
        goto pOGRm;
        pOGRm:
        $yeW9A = $keiAz->getDimensions();
        goto yVtZz;
        zzB8X:
        $kE2kK = $OwKVg->getAttribute('driver') === 1 ? 's3' : 'local';
        goto dZeq1;
        yVtZz:
        $OwKVg->update(['duration' => $G2mX1->getDurationInSeconds(), 'resolution' => $yeW9A->getWidth() . 'x' . $yeW9A->getHeight(), 'fps' => $keiAz->get('r_frame_rate') ?? 30]);
        goto xDPUz;
        xDPUz:
    }
}
