<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class J28K0oIWmGQJy
{
    private $zi8Gc;
    private $YOnDb;
    public function __construct(int $xf8Xq, int $iQ2st)
    {
        goto M55qK;
        Lcoe4:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto RmOyN;
        M55qK:
        if (!($xf8Xq <= 0)) {
            goto J3Mo3;
        }
        goto vq3CX;
        RmOyN:
        z7xDV:
        goto jA1gG;
        jA1gG:
        $this->zi8Gc = $xf8Xq;
        goto AQ3in;
        vq3CX:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto sEEZz;
        sEEZz:
        J3Mo3:
        goto jOwJY;
        jOwJY:
        if (!($iQ2st <= 0)) {
            goto z7xDV;
        }
        goto Lcoe4;
        AQ3in:
        $this->YOnDb = $iQ2st;
        goto U06Lv;
        U06Lv:
    }
    private static function mOeqn8eIjPz($Z2V2o, string $IBCoh = 'floor') : int
    {
        goto PVqZm;
        j7hCk:
        return $Z2V2o;
        goto SEFYt;
        b2rdr:
        dD4EY:
        goto EMc2q;
        YRp73:
        return (int) $Z2V2o;
        goto E_E9a;
        odSgy:
        if (!(is_float($Z2V2o) && $Z2V2o == floor($Z2V2o) && (int) $Z2V2o % 2 === 0)) {
            goto qWY64;
        }
        goto YRp73;
        ftHpI:
        HyUac:
        goto b2rdr;
        PVqZm:
        if (!(is_int($Z2V2o) && $Z2V2o % 2 === 0)) {
            goto kQSKO;
        }
        goto j7hCk;
        E_E9a:
        qWY64:
        goto NykFY;
        NykFY:
        switch (strtolower($IBCoh)) {
            case 'ceil':
                return (int) (ceil($Z2V2o / 2) * 2);
            case 'round':
                return (int) (round($Z2V2o / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($Z2V2o / 2) * 2);
        }
        goto ftHpI;
        SEFYt:
        kQSKO:
        goto odSgy;
        EMc2q:
    }
    public function mZNMVpvYoJy(string $o9lST = 'floor') : array
    {
        goto ABrfp;
        xpZa6:
        $a3g0G = 2;
        goto iy9Yi;
        QcIML:
        $rnUzB = $bBeWN;
        goto sF3kw;
        vAy1a:
        $a3g0G = $bBeWN;
        goto gsxwm;
        tgTT7:
        goto gklfF;
        goto gWEcJ;
        uBE6G:
        $Df9T6 = $this->zi8Gc * $x2Bsn;
        goto EwM8J;
        gqnrk:
        if (!($a3g0G < 2)) {
            goto S45dI;
        }
        goto xpZa6;
        gWEcJ:
        MT7ai:
        goto vAy1a;
        YqjoE:
        if ($this->zi8Gc >= $this->YOnDb) {
            goto MT7ai;
        }
        goto QcIML;
        ghAKW:
        fWSkz:
        goto gqnrk;
        Vf71I:
        if (!($rnUzB < 2)) {
            goto fWSkz;
        }
        goto rzsEH;
        EwM8J:
        $rnUzB = self::mOeqn8eIjPz(round($Df9T6), $o9lST);
        goto EW8yr;
        EW8yr:
        gklfF:
        goto Vf71I;
        rzsEH:
        $rnUzB = 2;
        goto ghAKW;
        h5GeE:
        $a3g0G = 0;
        goto YqjoE;
        gLksz:
        $Us8sZ = $this->YOnDb * $x2Bsn;
        goto afAfL;
        gsxwm:
        $x2Bsn = $a3g0G / $this->YOnDb;
        goto uBE6G;
        u6WBg:
        $rnUzB = 0;
        goto h5GeE;
        sF3kw:
        $x2Bsn = $rnUzB / $this->zi8Gc;
        goto gLksz;
        ABrfp:
        $bBeWN = 1080;
        goto u6WBg;
        nFmMc:
        return ['width' => $rnUzB, 'height' => $a3g0G];
        goto ZCu4y;
        afAfL:
        $a3g0G = self::mOeqn8eIjPz(round($Us8sZ), $o9lST);
        goto tgTT7;
        iy9Yi:
        S45dI:
        goto nFmMc;
        ZCu4y:
    }
}
