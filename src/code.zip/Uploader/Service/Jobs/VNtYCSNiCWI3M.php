<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class VNtYCSNiCWI3M
{
    private $oJNPX;
    private $cAi3S;
    private $QxLu3;
    private $pXh9P;
    public function __construct($K4GQ_, $A7A73, $bjIIR, $TWZho)
    {
        goto v8l0O;
        qMjwt:
        $this->pXh9P = $TWZho;
        goto e6LT9;
        e6LT9:
        $this->oJNPX = $K4GQ_;
        goto zlhM2;
        v8l0O:
        $this->cAi3S = $A7A73;
        goto NuxUe;
        NuxUe:
        $this->QxLu3 = $bjIIR;
        goto qMjwt;
        zlhM2:
    }
    public function mHXH8gbRF5x(?int $ZJYlg, ?int $RFX4H, string $S5d8n, bool $DNd6e = false) : string
    {
        goto rchP0;
        caqlN:
        G7LSN:
        goto ogJeg;
        ccEIK:
        $Ja45J = $ZJYlg - $TuH9j;
        goto pGuvt;
        Stcf3:
        list($Ywsfx, $TuH9j, $eaF7N) = $this->miktmcDY10c($S5d8n, $ZJYlg, $u9mYz, (float) $ZJYlg / $RFX4H);
        goto ydAi0;
        o0k2U:
        $this->QxLu3->put($b0LKC, $T4AWF->stream('png'));
        goto gintr;
        nHxQp:
        $Ja45J -= $zXLUY;
        goto QAxi6;
        TdN2I:
        throw new \RuntimeException("NYx4mhlHSMgHF dimensions are not available.");
        goto lFWi2;
        slmfA:
        $u9mYz = 0.1;
        goto Stcf3;
        gintr:
        return $DNd6e ? $b0LKC : $this->QxLu3->url($b0LKC);
        goto iH229;
        Ce0Bo:
        if (!$this->QxLu3->exists($b0LKC)) {
            goto AYiZs;
        }
        goto SGx_I;
        lFWi2:
        ORypK:
        goto slmfA;
        XfoUh:
        $this->pXh9P->put($b0LKC, $T4AWF->stream('png'));
        goto o0k2U;
        apRgB:
        $T4AWF->text($eaF7N, $Ja45J, (int) $xWjwI, function ($YhxJX) use($Ywsfx) {
            goto bF4lh;
            qtMH0:
            $YhxJX->color([185, 185, 185, 1]);
            goto kbUvu;
            EBuqd:
            $IZFCO = (int) ($Ywsfx * 1.2);
            goto WzPX0;
            kbUvu:
            $YhxJX->valign('middle');
            goto P9_jj;
            bF4lh:
            $YhxJX->file(public_path($this->cAi3S));
            goto EBuqd;
            P9_jj:
            $YhxJX->align('middle');
            goto pdbAk;
            WzPX0:
            $YhxJX->size(max($IZFCO, 1));
            goto qtMH0;
            pdbAk:
        });
        goto XfoUh;
        xKjRC:
        AYiZs:
        goto zOD5V;
        ydAi0:
        $b0LKC = $this->mP10c6Rko02($eaF7N, $ZJYlg, $RFX4H, $TuH9j, $Ywsfx);
        goto Ce0Bo;
        QAxi6:
        if (!($ZJYlg > 1500)) {
            goto G7LSN;
        }
        goto neA47;
        rchP0:
        if (!($ZJYlg === null || $RFX4H === null)) {
            goto ORypK;
        }
        goto TdN2I;
        ogJeg:
        $xWjwI = $RFX4H - $Ywsfx - 10;
        goto apRgB;
        pGuvt:
        $zXLUY = (int) ($Ja45J / 80);
        goto nHxQp;
        SGx_I:
        return $DNd6e ? $b0LKC : $this->QxLu3->url($b0LKC);
        goto xKjRC;
        zOD5V:
        $T4AWF = $this->oJNPX->call($this, $ZJYlg, $RFX4H);
        goto ccEIK;
        neA47:
        $Ja45J -= $zXLUY * 0.4;
        goto caqlN;
        iH229:
    }
    private function mP10c6Rko02(string $S5d8n, int $ZJYlg, int $RFX4H, int $Wahxp, int $zMD0v) : string
    {
        $wNPam = ltrim($S5d8n, '@');
        return "v2/watermark/{$wNPam}/{$ZJYlg}x{$RFX4H}_{$Wahxp}x{$zMD0v}/text_watermark.png";
    }
    private function miktmcDY10c($S5d8n, int $ZJYlg, float $BFVut, float $TlV7f) : array
    {
        goto I10j3;
        moqj2:
        return [(int) $Mcac3, $Mcac3 * strlen($eaF7N) / 1.8, $eaF7N];
        goto N0ZNW;
        N0ZNW:
        mhKYp:
        goto wcl8w;
        wcl8w:
        $Mcac3 = 1 / $TlV7f * $TuH9j / strlen($eaF7N);
        goto qCmbW;
        xvUro:
        $TuH9j = (int) ($ZJYlg * $BFVut);
        goto EleIu;
        qCmbW:
        return [(int) $Mcac3, $TuH9j, $eaF7N];
        goto msVVK;
        NEOwR:
        $Mcac3 = $TuH9j / (strlen($eaF7N) * 0.8);
        goto moqj2;
        EleIu:
        if (!($TlV7f > 1)) {
            goto mhKYp;
        }
        goto NEOwR;
        I10j3:
        $eaF7N = '@' . $S5d8n;
        goto xvUro;
        msVVK:
    }
}
