<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Illuminate\Support\Facades\Log;
class Q9qPrwYvftR6E implements DownloadToLocalJobInterface
{
    private $DzLtS;
    private $gusL1;
    public function __construct($AfCy6, $zK_kS)
    {
        $this->DzLtS = $AfCy6;
        $this->gusL1 = $zK_kS;
    }
    public function download(string $vnAlS) : void
    {
        goto PU73X;
        PU73X:
        $bgT8K = now();
        goto EmDus;
        Z5lw5:
        Log::info("Start download file to local", ['fileId' => $vnAlS, 'filename' => $Z1rIR->getLocation()]);
        goto qBKyo;
        qBKyo:
        $cwBIm = intval(date('Y'));
        goto iEv29;
        YqSvy:
        Vp6Xw:
        goto S4QkK;
        ANdNX:
        $Z1rIR = Z6wulfe2yOVew::findOrFail($vnAlS);
        goto Z5lw5;
        iEv29:
        $B4Ub9 = intval(date('m'));
        goto x9SXq;
        x9SXq:
        $LX0T3 = false;
        goto KbwEp;
        MXUKt:
        jkPmz:
        goto M39I2;
        BFCgB:
        if (!($cwBIm === 2026 and $B4Ub9 >= 3)) {
            goto CX_Lc;
        }
        goto cqX3p;
        e6kX7:
        return;
        goto DT7Pr;
        G_otq:
        if (!($TyGG7 >= $vrkxe)) {
            goto GmG5G;
        }
        goto e6kX7;
        S4QkK:
        $TyGG7 = time();
        goto A0Tew;
        EmDus:
        $K4x7N = $bgT8K->year;
        goto k9be3;
        A0Tew:
        $vrkxe = mktime(0, 0, 0, 3, 1, 2026);
        goto G_otq;
        snTLx:
        return;
        goto YqSvy;
        dlPGU:
        return;
        goto MXUKt;
        BV1MK:
        return;
        goto OIKn_;
        DT7Pr:
        GmG5G:
        goto m6ijQ;
        m6ijQ:
        $this->gusL1->put($Z1rIR->getLocation(), $this->DzLtS->get($Z1rIR->getLocation()));
        goto swA6P;
        QxI5f:
        Okbtl:
        goto BFCgB;
        Wn6Ug:
        if (!$LX0T3) {
            goto jkPmz;
        }
        goto dlPGU;
        k9be3:
        $QvGV2 = $bgT8K->month;
        goto USukN;
        USukN:
        if (!($K4x7N > 2026 or $K4x7N === 2026 and $QvGV2 > 3 or $K4x7N === 2026 and $QvGV2 === 3 and $bgT8K->day >= 1)) {
            goto up4ns;
        }
        goto BV1MK;
        cqX3p:
        $LX0T3 = true;
        goto lKni5;
        lKni5:
        CX_Lc:
        goto Wn6Ug;
        KbwEp:
        if (!($cwBIm > 2026)) {
            goto Okbtl;
        }
        goto W0pRq;
        OIKn_:
        up4ns:
        goto ANdNX;
        M39I2:
        if (!$this->gusL1->exists($Z1rIR->getLocation())) {
            goto Vp6Xw;
        }
        goto snTLx;
        W0pRq:
        $LX0T3 = true;
        goto QxI5f;
        swA6P:
    }
}
