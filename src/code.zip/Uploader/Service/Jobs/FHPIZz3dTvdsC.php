<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
class FHPIZz3dTvdsC implements StoreToS3JobInterface
{
    private $KbvBQ;
    private $RaPnW;
    private $FFBPk;
    public function __construct($twxgF, $hTkyv, $GHkBm)
    {
        goto mBG0z;
        IqLKB:
        $this->FFBPk = $GHkBm;
        goto Zs_pu;
        Zs_pu:
        $this->KbvBQ = $twxgF;
        goto Fdb4X;
        mBG0z:
        $this->RaPnW = $hTkyv;
        goto IqLKB;
        Fdb4X:
    }
    public function store(string $UcmDx) : void
    {
        goto vDMmg;
        Qjy9L:
        $dKvlC = $this->KbvBQ->call($this, $Ph2Eb);
        goto U2pbW;
        wZnEU:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $UcmDx]);
        goto iUlQ5;
        ar7hN:
        $FFU0R = $this->KbvBQ->call($this, $fYb1T);
        goto mUQrZ;
        rglpS:
        if ($LW_ZO) {
            goto anLsV;
        }
        goto V0rE7;
        mUQrZ:
        $this->RaPnW->put($LW_ZO->getAttribute('thumbnail'), $FFU0R->stream(), ['visibility' => 'public', 'ContentType' => $FFU0R->mime(), 'ContentDisposition' => 'inline']);
        goto srifi;
        V4Mon:
        Log::info("HSe6BNUpJTSwE stored to S3, update the children attachments", ['fileId' => $UcmDx]);
        goto XjhJ8;
        U2pbW:
        $this->RaPnW->put($LW_ZO->getAttribute('preview'), $dKvlC->stream(), ['visibility' => 'public', 'ContentType' => $dKvlC->mime(), 'ContentDisposition' => 'inline']);
        goto QDbP4;
        V0rE7:
        Log::info("HSe6BNUpJTSwE has been deleted, discard it", ['fileId' => $UcmDx]);
        goto N0CEf;
        skT27:
        $Ph2Eb = $this->FFBPk->path($LW_ZO->getAttribute('preview'));
        goto Qjy9L;
        erJC3:
        return;
        goto s3QvY;
        QDbP4:
        jmHSN:
        goto VxT0X;
        lcH2y:
        $IS6o1 = $this->KbvBQ->call($this, $eviRR);
        goto GuanX;
        XjhJ8:
        HSe6BNUpJTSwE::where('parent_id', $UcmDx)->update(['driver' => KPpxBU3Qc8yRk::S3, 'preview' => $LW_ZO->getAttribute('preview'), 'thumbnail' => $LW_ZO->getAttribute('thumbnail')]);
        goto erJC3;
        v1B8e:
        $brzPr = $LW_ZO->getAttribute('thumbnail');
        goto avTHI;
        h3uz5:
        anLsV:
        goto A2QM1;
        vDMmg:
        $LW_ZO = HSe6BNUpJTSwE::findOrFail($UcmDx);
        goto rglpS;
        s3QvY:
        SePJu:
        goto wZnEU;
        N0CEf:
        return;
        goto h3uz5;
        srifi:
        MPVhk:
        goto M_1QF;
        VxT0X:
        if (!$LW_ZO->update(['driver' => KPpxBU3Qc8yRk::S3, 'status' => U8OFutptQGm3S::FINISHED])) {
            goto SePJu;
        }
        goto V4Mon;
        avTHI:
        if (!($brzPr && $this->FFBPk->exists($brzPr))) {
            goto MPVhk;
        }
        goto ur5rR;
        ur5rR:
        $fYb1T = $this->FFBPk->path($brzPr);
        goto ar7hN;
        A2QM1:
        $eviRR = $this->FFBPk->path($LW_ZO->getLocation());
        goto lcH2y;
        M_1QF:
        if (!($LW_ZO->getAttribute('preview') && $this->FFBPk->exists($LW_ZO->getAttribute('preview')))) {
            goto jmHSN;
        }
        goto skT27;
        GuanX:
        $this->RaPnW->put($LW_ZO->getLocation(), $IS6o1->stream(), ['visibility' => 'public', 'ContentType' => $IS6o1->mime(), 'ContentDisposition' => 'inline']);
        goto v1B8e;
        iUlQ5:
    }
}
