<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class WPhjmMzudmjL8 implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $q8q1b) : void
    {
        goto kknzw;
        FuRo3:
        DyZbB:
        goto PkPOj;
        IOwKY:
        if ($cFlec->width() > 0 && $cFlec->height() > 0) {
            goto DyZbB;
        }
        goto PH7XB;
        PH7XB:
        $this->mwzJp0VJCBB($cFlec);
        goto FuRo3;
        kknzw:
        $cFlec = O1jfuwJR340k5::findOrFail($q8q1b);
        goto IOwKY;
        PkPOj:
    }
    private function mwzJp0VJCBB(O1jfuwJR340k5 $wEV0l) : void
    {
        goto uT4U7;
        hkGd7:
        $wEV0l->update(['duration' => $XCcud->getDurationInSeconds(), 'resolution' => $JvBLn->getWidth() . 'x' . $JvBLn->getHeight(), 'fps' => $FZMiP->get('r_frame_rate') ?? 30]);
        goto szmL6;
        uT4U7:
        $JsoDj = $wEV0l->getView();
        goto Un94n;
        Un94n:
        $XCcud = FFMpeg::fromDisk($JsoDj['path'])->open($wEV0l->getAttribute('filename'));
        goto TjrL_;
        TjrL_:
        $FZMiP = $XCcud->getVideoStream();
        goto XiQ4w;
        XiQ4w:
        $JvBLn = $FZMiP->getDimensions();
        goto hkGd7;
        szmL6:
    }
}
