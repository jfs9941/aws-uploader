<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class QOFRXBlpPvkox
{
    private $bJ64t;
    private $DV6_0;
    private $zbU8n;
    private $W9e5K;
    public function __construct($f_vTf, $dRs7q, $Efy84, $XCkIj)
    {
        goto FWd6r;
        eCO_q:
        $this->bJ64t = $f_vTf;
        goto xLkQL;
        FWd6r:
        $this->DV6_0 = $dRs7q;
        goto MXb9S;
        MXb9S:
        $this->zbU8n = $Efy84;
        goto Qo4ma;
        Qo4ma:
        $this->W9e5K = $XCkIj;
        goto eCO_q;
        xLkQL:
    }
    public function mp5Q2fe7Fqv(?int $lvh9C, ?int $S3Wk9, string $QBYnF, bool $FaICE = false) : string
    {
        goto YbnSf;
        YbnSf:
        if (!($lvh9C === null || $S3Wk9 === null)) {
            goto WIu8d;
        }
        goto A_WWJ;
        j30eL:
        $this->W9e5K->put($vRakW, $RxSHk->stream('png'));
        goto rFn2g;
        BIh3w:
        return $FaICE ? $vRakW : $this->zbU8n->url($vRakW);
        goto CHBbo;
        l6SDG:
        if (!$this->zbU8n->exists($vRakW)) {
            goto TGm6R;
        }
        goto b4TlL;
        SQMYK:
        $vRakW = $this->mtjDKV7h6mH($O0SN5, $lvh9C, $S3Wk9, $wL_N1, $vPS4f);
        goto l6SDG;
        Pmi0B:
        $thZJ7 = $S3Wk9 - $vPS4f - 10;
        goto OcywD;
        EvwRX:
        $RxSHk = $this->bJ64t->call($this, $lvh9C, $S3Wk9);
        goto wqs2Q;
        be15q:
        WIu8d:
        goto G5UDr;
        yB7Je:
        TGm6R:
        goto EvwRX;
        rFn2g:
        $this->zbU8n->put($vRakW, $RxSHk->stream('png'));
        goto BIh3w;
        wqs2Q:
        $l5XP5 = $lvh9C - $wL_N1;
        goto UIOVF;
        hfz1O:
        if (!($lvh9C > 1500)) {
            goto VwNx4;
        }
        goto ZisGC;
        EXmRK:
        $l5XP5 -= $JwPmv;
        goto hfz1O;
        G5UDr:
        $V2mz_ = 0.1;
        goto VH2nG;
        ILy8M:
        VwNx4:
        goto Pmi0B;
        b4TlL:
        return $FaICE ? $vRakW : $this->zbU8n->url($vRakW);
        goto yB7Je;
        VH2nG:
        list($vPS4f, $wL_N1, $O0SN5) = $this->m9Py2UeukVA($QBYnF, $lvh9C, $V2mz_, (float) $lvh9C / $S3Wk9);
        goto SQMYK;
        UIOVF:
        $JwPmv = (int) ($l5XP5 / 80);
        goto EXmRK;
        ZisGC:
        $l5XP5 -= $JwPmv * 0.4;
        goto ILy8M;
        OcywD:
        $RxSHk->text($O0SN5, $l5XP5, (int) $thZJ7, function ($sB4Fc) use($vPS4f) {
            goto Uu1Uh;
            kI7Jq:
            $Ia8FC = (int) ($vPS4f * 1.2);
            goto s3kcw;
            AFs4D:
            $sB4Fc->color([185, 185, 185, 1]);
            goto EIJuv;
            tnPn3:
            $sB4Fc->align('middle');
            goto ts8uO;
            EIJuv:
            $sB4Fc->valign('middle');
            goto tnPn3;
            s3kcw:
            $sB4Fc->size(max($Ia8FC, 1));
            goto AFs4D;
            Uu1Uh:
            $sB4Fc->file(public_path($this->DV6_0));
            goto kI7Jq;
            ts8uO:
        });
        goto j30eL;
        A_WWJ:
        throw new \RuntimeException("VPegVN4NByLqJ dimensions are not available.");
        goto be15q;
        CHBbo:
    }
    private function mtjDKV7h6mH(string $QBYnF, int $lvh9C, int $S3Wk9, int $N4nN3, int $TW8af) : string
    {
        $qIhB2 = ltrim($QBYnF, '@');
        return "v2/watermark/{$qIhB2}/{$lvh9C}x{$S3Wk9}_{$N4nN3}x{$TW8af}/text_watermark.png";
    }
    private function m9Py2UeukVA($QBYnF, int $lvh9C, float $FYED4, float $yzNoO) : array
    {
        goto tGzXF;
        BwDUP:
        j_0hA:
        goto hh36V;
        Lj3QZ:
        $wL_N1 = (int) ($lvh9C * $FYED4);
        goto fMd20;
        hh36V:
        $hiaGa = 1 / $yzNoO * $wL_N1 / strlen($O0SN5);
        goto VjUxK;
        tGzXF:
        $O0SN5 = '@' . $QBYnF;
        goto Lj3QZ;
        fMd20:
        if (!($yzNoO > 1)) {
            goto j_0hA;
        }
        goto LaQPB;
        VjUxK:
        return [(int) $hiaGa, $wL_N1, $O0SN5];
        goto T48Pv;
        HIta5:
        return [(int) $hiaGa, $hiaGa * strlen($O0SN5) / 1.8, $O0SN5];
        goto BwDUP;
        LaQPB:
        $hiaGa = $wL_N1 / (strlen($O0SN5) * 0.8);
        goto HIta5;
        T48Pv:
    }
}
