<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Aku4kwXVg7Zrz implements GenerateThumbnailForVideoInterface
{
    private $CmuCf;
    public function __construct($N2D5A)
    {
        $this->CmuCf = $N2D5A;
    }
    public function generate(string $g5e_r) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $g5e_r);
        $this->CmuCf->createThumbnail($g5e_r);
    }
}
