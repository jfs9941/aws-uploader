<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Illuminate\Support\Facades\Log;
class KkScwFnedVqJt implements BlurVideoJobInterface
{
    const gulgt = 15;
    const dqWi9 = 500;
    const I9e4n = 500;
    private $bIrxp;
    private $rSfnv;
    private $GRsEs;
    public function __construct($NJy8O, $uIWH1, $Zywh9)
    {
        goto v0XAW;
        hzQBP:
        $this->bIrxp = $NJy8O;
        goto dJaV6;
        v0XAW:
        $this->GRsEs = $Zywh9;
        goto NvxFF;
        NvxFF:
        $this->rSfnv = $uIWH1;
        goto hzQBP;
        dJaV6:
    }
    public function blur(string $eeXS6) : void
    {
        goto qExhw;
        O23zZ:
        $this->GRsEs->put($H1Zi_->getAttribute('thumbnail'), $this->rSfnv->get($H1Zi_->getAttribute('thumbnail')));
        goto fqvjM;
        Omm7v:
        $this->rSfnv->put($AYtsf, $this->GRsEs->get($AYtsf));
        goto wyRx6;
        qExhw:
        Log::info("Blurring for video", ['videoID' => $eeXS6]);
        goto ZCDIY;
        emYJV:
        ISZib:
        goto R0cWe;
        ZCDIY:
        ini_set('memory_limit', '-1');
        goto wOqrh;
        G07ho:
        if (chmod($sVWFg, 0664)) {
            goto ISZib;
        }
        goto MHuHN;
        wl0VU:
        $K0J89->save($sVWFg);
        goto Omm7v;
        Q4j2m:
        if (!$H1Zi_->getAttribute('thumbnail')) {
            goto F5qIy;
        }
        goto O23zZ;
        mVNKN:
        $K0J89->blur(self::gulgt);
        goto KkuYk;
        Z3xWd:
        $K0J89->resize(self::dqWi9, self::I9e4n / $QZr52);
        goto mVNKN;
        pWMdb:
        throw new \Exception('Failed to set final permissions on image file: ' . $sVWFg);
        goto emYJV;
        wyRx6:
        unset($K0J89);
        goto G07ho;
        rWox4:
        $QZr52 = $K0J89->width() / $K0J89->height();
        goto Z3xWd;
        dB5K6:
        F5qIy:
        goto pyADH;
        MHuHN:
        \Log::warning('Failed to set final permissions on image file: ' . $sVWFg);
        goto pWMdb;
        wOqrh:
        $H1Zi_ = N1wF7eNF4lYgo::findOrFail($eeXS6);
        goto Q4j2m;
        ZzzJ9:
        $sVWFg = $this->GRsEs->path($AYtsf);
        goto wl0VU;
        KkuYk:
        $AYtsf = $this->mopbvMljxg6($H1Zi_);
        goto ZzzJ9;
        fqvjM:
        $K0J89 = $this->bIrxp->call($this, $this->GRsEs->path($H1Zi_->getAttribute('thumbnail')));
        goto rWox4;
        R0cWe:
        $H1Zi_->update(['preview' => $AYtsf]);
        goto dB5K6;
        pyADH:
    }
    private function mopbvMljxg6(FpdzXEk0mryCJ $I_gke) : string
    {
        goto ahzAL;
        hE3kO:
        c90Ax:
        goto GeDwj;
        ehFPI:
        if ($this->GRsEs->exists($S4PZU)) {
            goto c90Ax;
        }
        goto QCGwa;
        ahzAL:
        $NSF8Y = $I_gke->getLocation();
        goto gySeT;
        GeDwj:
        return $S4PZU . $I_gke->getFilename() . '.jpg';
        goto JldJ9;
        gySeT:
        $S4PZU = dirname($NSF8Y) . '/preview/';
        goto ehFPI;
        QCGwa:
        $this->GRsEs->makeDirectory($S4PZU, 0755, true);
        goto hE3kO;
        JldJ9:
    }
}
