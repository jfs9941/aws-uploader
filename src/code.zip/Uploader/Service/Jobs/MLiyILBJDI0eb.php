<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
class MLiyILBJDI0eb implements BlurVideoJobInterface
{
    const l3YDx = 15;
    const YG24j = 500;
    const I1c9T = 500;
    private $SJRrZ;
    private $gGE8I;
    private $xbA_A;
    public function __construct($akc4V, $duBfR, $a_5ue)
    {
        goto lyyin;
        lyyin:
        $this->xbA_A = $a_5ue;
        goto XxedJ;
        XxedJ:
        $this->gGE8I = $duBfR;
        goto xxRTM;
        xxRTM:
        $this->SJRrZ = $akc4V;
        goto DVY7h;
        DVY7h:
    }
    public function blur(string $ld8Ad) : void
    {
        goto nmLOj;
        kwVT4:
        ini_set('memory_limit', '-1');
        goto hfAS2;
        HYx7u:
        $vQG8k = $xobEP->width() / $xobEP->height();
        goto ZZwpO;
        E_dPR:
        $jFpM9->update(['preview' => $DYrgW]);
        goto BuUko;
        dWgDM:
        unset($xobEP);
        goto qM43X;
        TiCYt:
        if (!$jFpM9->getAttribute('thumbnail')) {
            goto Ps81s;
        }
        goto sJrT2;
        qM43X:
        if (chmod($ShFvF, 0664)) {
            goto lUONt;
        }
        goto efeAv;
        qN3B1:
        $xobEP->blur(self::l3YDx);
        goto PcqIC;
        hfAS2:
        $jFpM9 = RVcEF1JsGQd8M::findOrFail($ld8Ad);
        goto TiCYt;
        nmLOj:
        Log::info("Blurring for video", ['videoID' => $ld8Ad]);
        goto kwVT4;
        ruYg9:
        $xobEP->save($ShFvF);
        goto VvS0O;
        efeAv:
        \Log::warning('Failed to set final permissions on image file: ' . $ShFvF);
        goto VrlG8;
        sJrT2:
        $this->xbA_A->put($jFpM9->getAttribute('thumbnail'), $this->gGE8I->get($jFpM9->getAttribute('thumbnail')));
        goto hMPwn;
        hMPwn:
        $xobEP = $this->SJRrZ->call($this, $this->xbA_A->path($jFpM9->getAttribute('thumbnail')));
        goto HYx7u;
        ZZwpO:
        $xobEP->resize(self::YG24j, self::I1c9T / $vQG8k);
        goto qN3B1;
        Y1tT8:
        $ShFvF = $this->xbA_A->path($DYrgW);
        goto ruYg9;
        BuUko:
        Ps81s:
        goto MurVT;
        VvS0O:
        $this->gGE8I->put($DYrgW, $this->xbA_A->get($DYrgW));
        goto dWgDM;
        VrlG8:
        throw new \Exception('Failed to set final permissions on image file: ' . $ShFvF);
        goto vuW4e;
        PcqIC:
        $DYrgW = $this->mnQ8tJizK2h($jFpM9);
        goto Y1tT8;
        vuW4e:
        lUONt:
        goto E_dPR;
        MurVT:
    }
    private function mnQ8tJizK2h(MQuH2y6UnzTZv $PW97U) : string
    {
        goto ciT15;
        ciT15:
        $jGQTt = $PW97U->getLocation();
        goto uLByb;
        DYi82:
        if ($this->xbA_A->exists($BaehP)) {
            goto qYr6D;
        }
        goto UV2Hx;
        nBVTa:
        return $BaehP . $PW97U->getFilename() . '.jpg';
        goto aOY9g;
        uLByb:
        $BaehP = dirname($jGQTt) . '/preview/';
        goto DYi82;
        UV2Hx:
        $this->xbA_A->makeDirectory($BaehP, 0755, true);
        goto BzN0_;
        BzN0_:
        qYr6D:
        goto nBVTa;
        aOY9g:
    }
}
