<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
class QxxyFIMkmTnPz implements StoreVideoToS3JobInterface
{
    private $t_ppt;
    private $MV0lK;
    private $P2FvH;
    public function __construct($UYSBS, $tYsty, $j8mv9)
    {
        goto ua2P9;
        ua2P9:
        $this->MV0lK = $tYsty;
        goto Mex5y;
        eRjgD:
        $this->t_ppt = $UYSBS;
        goto m_bu2;
        Mex5y:
        $this->P2FvH = $j8mv9;
        goto eRjgD;
        m_bu2:
    }
    public function store(string $FILUb) : void
    {
        goto moyRG;
        H7Cf2:
        $SaFLV = $j8mv9->mimeType($ez6kE->getLocation());
        goto RGT4u;
        K29Uq:
        try {
            goto sRjlz;
            Gqzq_:
            $tgr9H->completeMultipartUpload(['Bucket' => $this->t_ppt, 'Key' => $ez6kE->getLocation(), 'UploadId' => $y_u0V, 'MultipartUpload' => ['Parts' => $bLIUr]]);
            goto C1anG;
            YXexy:
            $j8mv9->delete($ez6kE->getLocation());
            goto mGXJE;
            fDfdT:
            LRdly:
            goto AgsW8;
            C1anG:
            $ez6kE->update(['driver' => N0ISad2bKF2Yp::S3, 'status' => EPmxqTVp5luXc::FINISHED]);
            goto YXexy;
            lo0tk:
            $nauDg = $tgr9H->uploadPart(['Bucket' => $this->t_ppt, 'Key' => $ez6kE->getLocation(), 'UploadId' => $y_u0V, 'PartNumber' => $Bval6, 'Body' => fread($MO43l, $P42U_)]);
            goto Ee9cJ;
            MOEqv:
            $Bval6++;
            goto jlDf6;
            iLy_8:
            $bLIUr = [];
            goto r3xIH;
            o5Aok:
            $y_u0V = $Or112['UploadId'];
            goto uVfn5;
            sRjlz:
            $Or112 = $tgr9H->createMultipartUpload(['Bucket' => $this->t_ppt, 'Key' => $ez6kE->getLocation(), 'ContentType' => $SaFLV, 'ContentDisposition' => 'inline']);
            goto o5Aok;
            r3xIH:
            Sh_Yl:
            goto hqEZy;
            hqEZy:
            if (feof($MO43l)) {
                goto LRdly;
            }
            goto lo0tk;
            AgsW8:
            fclose($MO43l);
            goto Gqzq_;
            uVfn5:
            $Bval6 = 1;
            goto iLy_8;
            Ee9cJ:
            $bLIUr[] = ['PartNumber' => $Bval6, 'ETag' => $nauDg['ETag']];
            goto MOEqv;
            jlDf6:
            goto Sh_Yl;
            goto fDfdT;
            mGXJE:
        } catch (AwsException $AWFah) {
            goto CKWJc;
            kf3Br:
            try {
                $tgr9H->abortMultipartUpload(['Bucket' => $this->t_ppt, 'Key' => $ez6kE->getLocation(), 'UploadId' => $y_u0V]);
            } catch (AwsException $q_Vub) {
                Log::error('Error aborting multipart upload: ' . $q_Vub->getMessage());
            }
            goto QkiV9;
            QkiV9:
            e1YUU:
            goto sRn4V;
            CKWJc:
            if (!isset($y_u0V)) {
                goto e1YUU;
            }
            goto kf3Br;
            sRn4V:
            Log::error('Failed to store video: ' . $ez6kE->getLocation() . ' - ' . $AWFah->getMessage());
            goto Hi7v7;
            Hi7v7:
        } finally {
            $zG72F = microtime(true);
            $ehM97 = memory_get_usage();
            $qkTl8 = memory_get_peak_usage();
            Log::info('Store CUaMUcjkFHEwK to S3 function resource usage', ['imageId' => $FILUb, 'execution_time_sec' => $zG72F - $riJ7Z, 'memory_usage_mb' => ($ehM97 - $sgrbS) / 1024 / 1024, 'peak_memory_usage_mb' => ($qkTl8 - $AgLQ7) / 1024 / 1024]);
        }
        goto VzXpj;
        MJYPB:
        EZpFf:
        goto BEYKb;
        cS_XG:
        Log::info("CUaMUcjkFHEwK has been deleted, discard it", ['fileId' => $FILUb]);
        goto eACWM;
        UqO9B:
        ini_set('memory_limit', '-1');
        goto yPlR4;
        h_Oya:
        $AgLQ7 = memory_get_peak_usage();
        goto K29Uq;
        gkcPa:
        $ez6kE = CUaMUcjkFHEwK::find($FILUb);
        goto BE2mU;
        lriU5:
        $sgrbS = memory_get_usage();
        goto h_Oya;
        yPlR4:
        $tgr9H = $this->MV0lK->getClient();
        goto o7BCC;
        RGT4u:
        $riJ7Z = microtime(true);
        goto lriU5;
        o7BCC:
        $j8mv9 = $this->P2FvH;
        goto gkcPa;
        rCc2X:
        if ($j8mv9->exists($ez6kE->getLocation())) {
            goto EZpFf;
        }
        goto mLkOR;
        gqhy4:
        ws0w2:
        goto rCc2X;
        BE2mU:
        if ($ez6kE) {
            goto ws0w2;
        }
        goto cS_XG;
        eACWM:
        return;
        goto gqhy4;
        moyRG:
        Log::info('Storing video (local) to S3', ['fileId' => $FILUb, 'bucketName' => $this->t_ppt]);
        goto UqO9B;
        mLkOR:
        Log::error("[QxxyFIMkmTnPz] File not found, discard it ", ['video' => $ez6kE->getLocation()]);
        goto uJAe7;
        uJAe7:
        return;
        goto MJYPB;
        LqDwX:
        $P42U_ = 1024 * 1024 * 50;
        goto H7Cf2;
        BEYKb:
        $MO43l = $j8mv9->readStream($ez6kE->getLocation());
        goto LqDwX;
        VzXpj:
    }
}
