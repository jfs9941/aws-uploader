<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class Mz7gU1sAJkoAF implements StoreToS3JobInterface
{
    private $lT6tT;
    private $bLZP5;
    private $qeI_k;
    public function __construct($W4G5n, $C1By6, $ShtWH)
    {
        goto Dccfe;
        dOuKc:
        $this->lT6tT = $W4G5n;
        goto IL674;
        Dccfe:
        $this->bLZP5 = $C1By6;
        goto tk9MG;
        tk9MG:
        $this->qeI_k = $ShtWH;
        goto dOuKc;
        IL674:
    }
    public function store(string $DWjir) : void
    {
        goto JAVcz;
        B0U52:
        return;
        goto be02B;
        HzsIt:
        MvPLv:
        goto bV940;
        elr0m:
        return;
        goto f1fQK;
        NAVNS:
        wSVh8:
        goto pVRJ1;
        IXSo_:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $DWjir]);
        goto uDQtd;
        yCtQP:
        if (!($sOmCy && $this->qeI_k->exists($sOmCy))) {
            goto MvPLv;
        }
        goto G3e1F;
        be02B:
        h0Fw1:
        goto hKylG;
        hKylG:
        $iVcpi = $this->qeI_k->path($AD715->getLocation());
        goto k_p1g;
        YUsJ0:
        Log::info("IQJN6V0t7DC7c stored to S3, update the children attachments", ['fileId' => $DWjir]);
        goto HfRou;
        CBQCK:
        $UT4QS = $this->lT6tT->call($this, $XZj6d);
        goto NFxPy;
        NFxPy:
        $this->bLZP5->put($AD715->getAttribute('thumbnail'), $this->qeI_k->get($sOmCy), ['visibility' => 'public', 'ContentType' => $UT4QS->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto HzsIt;
        W28FA:
        $sOmCy = $AD715->getAttribute('thumbnail');
        goto yCtQP;
        UOpXU:
        if ($AD715) {
            goto h0Fw1;
        }
        goto IaxaA;
        pVRJ1:
        if (!$AD715->update(['driver' => KkaUVP3OQvOtp::S3, 'status' => H7dtWZ2h5WAty::FINISHED])) {
            goto pyhhg;
        }
        goto YUsJ0;
        G3e1F:
        $XZj6d = $this->qeI_k->path($sOmCy);
        goto CBQCK;
        bV940:
        if (!($AD715->getAttribute('preview') && $this->qeI_k->exists($AD715->getAttribute('preview')))) {
            goto wSVh8;
        }
        goto Dugf8;
        HfRou:
        IQJN6V0t7DC7c::where('parent_id', $DWjir)->update(['driver' => KkaUVP3OQvOtp::S3, 'preview' => $AD715->getAttribute('preview'), 'thumbnail' => $AD715->getAttribute('thumbnail')]);
        goto elr0m;
        IaxaA:
        Log::info("IQJN6V0t7DC7c has been deleted, discard it", ['fileId' => $DWjir]);
        goto B0U52;
        ZmN9x:
        $hcwSN = $this->lT6tT->call($this, $Qh53y);
        goto bmb3W;
        k_p1g:
        $this->mT7HmPzOLMP($iVcpi, $AD715->getLocation());
        goto W28FA;
        f1fQK:
        pyhhg:
        goto IXSo_;
        Dugf8:
        $Qh53y = $this->qeI_k->path($AD715->getAttribute('preview'));
        goto ZmN9x;
        JAVcz:
        $AD715 = IQJN6V0t7DC7c::findOrFail($DWjir);
        goto UOpXU;
        bmb3W:
        $this->bLZP5->put($AD715->getAttribute('preview'), $this->qeI_k->get($AD715->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $hcwSN->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto NAVNS;
        uDQtd:
    }
    private function mT7HmPzOLMP($Qhin8, $CYKLz, $X7Oue = '')
    {
        goto PafkJ;
        uyv70:
        $Qhin8 = str_replace('.jpg', $X7Oue, $Qhin8);
        goto E1x4t;
        BGyZM:
        YHsPC:
        goto LTgkl;
        PafkJ:
        if (!$X7Oue) {
            goto YHsPC;
        }
        goto uyv70;
        LTgkl:
        try {
            $KlHaV = $this->lT6tT->call($this, $Qhin8);
            $this->bLZP5->put($CYKLz, $this->qeI_k->get($CYKLz), ['visibility' => 'public', 'ContentType' => $KlHaV->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $x4bzR) {
            Log::error("Failed to upload image to S3", ['s3Path' => $CYKLz, 'error' => $x4bzR->getMessage()]);
        }
        goto wZQzT;
        E1x4t:
        $CYKLz = str_replace('.jpg', $X7Oue, $CYKLz);
        goto BGyZM;
        wZQzT:
    }
}
