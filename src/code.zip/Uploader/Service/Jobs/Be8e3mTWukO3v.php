<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Be8e3mTWukO3v implements GenerateThumbnailJobInterface
{
    const w5aME = 150;
    const rVeig = 150;
    private $VnheV;
    private $GmmTj;
    private $l6NR4;
    public function __construct($wUcGa, $MYo5D, $Y7rOa)
    {
        goto HB6fE;
        ePS8j:
        $this->GmmTj = $MYo5D;
        goto xLjOd;
        xLjOd:
        $this->l6NR4 = $Y7rOa;
        goto RA32d;
        HB6fE:
        $this->VnheV = $wUcGa;
        goto ePS8j;
        RA32d:
    }
    public function generate(string $GMwD5)
    {
        goto MpWjs;
        N3DrS:
        ini_set('memory_limit', '-1');
        goto uuHmA;
        uuHmA:
        try {
            goto AlJpU;
            lKjLx:
            lKN_4:
            goto KXBEO;
            n6I9B:
            unset($IGbSY);
            goto OQfWM;
            L2rqU:
            $IGbSY->orient()->resize(150, 150);
            goto NmTlp;
            pSBi3:
            $nUWgk = $this->l6NR4->put($iTIh6, $IGbSY->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto n6I9B;
            Ep25l:
            $dmeuh = C6ftQJKUZRJIp::findOrFail($GMwD5);
            goto Q2dSB;
            Wgwci:
            $dmeuh->update(['thumbnail' => $iTIh6, 'status' => Fsm7WCrUwVWh9::THUMBNAIL_PROCESSED]);
            goto lKjLx;
            Q2dSB:
            $IGbSY = $this->VnheV->call($this, $vS8UC->path($dmeuh->getLocation()));
            goto L2rqU;
            AlJpU:
            $vS8UC = $this->GmmTj;
            goto Ep25l;
            NmTlp:
            $iTIh6 = $this->mTWuokivYSO($dmeuh);
            goto pSBi3;
            OQfWM:
            if (!($nUWgk !== false)) {
                goto lKN_4;
            }
            goto Wgwci;
            KXBEO:
        } catch (ModelNotFoundException $hPqRx) {
            Log::info("C6ftQJKUZRJIp has been deleted, discard it", ['imageId' => $GMwD5]);
            return;
        } catch (\Exception $hPqRx) {
            Log::error("Failed to generate thumbnail", ['imageId' => $GMwD5, 'error' => $hPqRx->getMessage()]);
        }
        goto UQMAo;
        MpWjs:
        Log::info("Generating thumbnail", ['imageId' => $GMwD5]);
        goto N3DrS;
        UQMAo:
    }
    private function mTWuokivYSO(EpIpyfdFnoTz6 $dmeuh) : string
    {
        goto E5JAm;
        E5JAm:
        $iTIh6 = $dmeuh->getLocation();
        goto UgTu9;
        UgTu9:
        $w6EkV = dirname($iTIh6);
        goto d4u9e;
        d4u9e:
        $nJWqj = $w6EkV . '/' . self::w5aME . 'X' . self::rVeig;
        goto gKoZM;
        gKoZM:
        return $nJWqj . '/' . $dmeuh->getFilename() . '.jpg';
        goto TSmuL;
        TSmuL:
    }
}
