<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class SxPld9RPz1NNE implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $DWjir) : void
    {
        goto XfMio;
        WIHFB:
        p_3Sr:
        goto M5EmV;
        XfMio:
        $lamFK = J7sRaWo8um3yO::findOrFail($DWjir);
        goto FM9ld;
        FM9ld:
        if ($lamFK->width() > 0 && $lamFK->height() > 0) {
            goto p_3Sr;
        }
        goto SfKBU;
        SfKBU:
        $this->m8xQlxoF1rZ($lamFK);
        goto WIHFB;
        M5EmV:
    }
    private function m8xQlxoF1rZ(J7sRaWo8um3yO $ks3oC) : void
    {
        goto ZkF8v;
        ZkF8v:
        $uApFn = $ks3oC->getView();
        goto CimPf;
        CimPf:
        $jKCuO = FFMpeg::fromDisk($uApFn['path'])->open($ks3oC->getAttribute('filename'));
        goto stXrE;
        QL4AP:
        $IztL4 = $SnfYu->getDimensions();
        goto GWibf;
        stXrE:
        $SnfYu = $jKCuO->getVideoStream();
        goto QL4AP;
        GWibf:
        $ks3oC->update(['duration' => $jKCuO->getDurationInSeconds(), 'resolution' => $IztL4->getWidth() . 'x' . $IztL4->getHeight(), 'fps' => $SnfYu->get('r_frame_rate') ?? 30]);
        goto i9hJ8;
        i9hJ8:
    }
}
