<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Illuminate\Support\Facades\Log;
class Rz5QzizFmN1lV implements DownloadToLocalJobInterface
{
    private $aiw3M;
    private $n8EBo;
    public function __construct($iay5S, $gdQ3g)
    {
        $this->aiw3M = $iay5S;
        $this->n8EBo = $gdQ3g;
    }
    public function download(string $zV1kl) : void
    {
        goto znajU;
        Ynvug:
        $this->n8EBo->put($Z5ydB->getLocation(), $this->aiw3M->get($Z5ydB->getLocation()));
        goto iyEjX;
        znajU:
        $Z5ydB = KCmQR4pvm0dT3::findOrFail($zV1kl);
        goto c7V04;
        c7V04:
        Log::info("Start download file to local", ['fileId' => $zV1kl, 'filename' => $Z5ydB->getLocation()]);
        goto l01KR;
        Eus32:
        return;
        goto EV7ng;
        EV7ng:
        lR6Rd:
        goto Ynvug;
        l01KR:
        if (!$this->n8EBo->exists($Z5ydB->getLocation())) {
            goto lR6Rd;
        }
        goto Eus32;
        iyEjX:
    }
}
