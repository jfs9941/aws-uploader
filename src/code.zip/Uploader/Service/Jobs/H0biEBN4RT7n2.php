<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Encoder\KxPUocSKhVWfb;
use Jfs\Uploader\Encoder\JCn5h7b7KyFNK;
use Jfs\Uploader\Encoder\Rwcm9mhsmq7Wv;
use Jfs\Uploader\Encoder\Zu01XTNfnZhjW;
use Jfs\Uploader\Encoder\GGjYAvfIx8jD2;
use Jfs\Uploader\Encoder\CxY28u9r8wEQP;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
use Jfs\Uploader\Service\L3oEPipUZv9oB;
use Webmozart\Assert\Assert;
class H0biEBN4RT7n2 implements MediaEncodeJobInterface
{
    private $Jc4z2;
    private $kduDw;
    private $ifs25;
    private $AQqBe;
    private $wmqIG;
    public function __construct(string $rhVEO, $h5ffz, $PQlIa, $RuaCx, $mECUN)
    {
        goto rg0Cg;
        JBza2:
        $this->AQqBe = $RuaCx;
        goto Ev113;
        rg0Cg:
        $this->Jc4z2 = $rhVEO;
        goto ZCtyY;
        ZCtyY:
        $this->kduDw = $h5ffz;
        goto w0Hxl;
        w0Hxl:
        $this->ifs25 = $PQlIa;
        goto JBza2;
        Ev113:
        $this->wmqIG = $mECUN;
        goto p288a;
        p288a:
    }
    public function encode(string $PV4mw, string $FmRvX, $mlVz1 = true) : void
    {
        goto JOlZQ;
        JOlZQ:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $PV4mw]);
        goto qRTHm;
        a5Eog:
        try {
            goto ntK6f;
            AiwQP:
            $YxARL = new JCn5h7b7KyFNK('1080p', $hUnXA['width'], $hUnXA['height'], $vtvs_->DjDhw ?? 30);
            goto wlVxh;
            nZTwn:
            $L5zcu = new JCn5h7b7KyFNK('original', $NixDl, $l4GK0, $vtvs_->DjDhw ?? 30);
            goto Pr1oa;
            ep8Rf:
            $OZKMn = app(L3oEPipUZv9oB::class);
            goto pMFaM;
            xc1ZO:
            $RSfya = app(GGjYAvfIx8jD2::class);
            goto SBszu;
            Ml5Cl:
            $NixDl = $vtvs_->width();
            goto ANXqx;
            ggCcI:
            GuJ7B:
            goto Ebvlv;
            ntK6f:
            $vtvs_ = CSQMvXC33KbbS::findOrFail($PV4mw);
            goto Vpltr;
            xNti7:
            $RSfya->mZdd6VkymGA($TJaxK->m7gkGAfBmh9($vtvs_));
            goto ep8Rf;
            Pr1oa:
            $TJaxK = app(Rwcm9mhsmq7Wv::class);
            goto McIPv;
            EEGNU:
            $hUnXA = $this->ms4ksUGpVNi($NixDl, $l4GK0);
            goto e_Hjo;
            jctVO:
            nyQHL:
            goto x9chI;
            fw8ZN:
            $gpnSS = $this->mY4nsY6JGPc($vtvs_);
            goto z3kxe;
            Ebvlv:
            $RSfya = $RSfya->muMfW5wYw2z($YxARL);
            goto tZ5JS;
            e_Hjo:
            Log::info("Set 1080p resolution for Job", ['width' => $hUnXA['width'], 'height' => $hUnXA['height'], 'originalWidth' => $NixDl, 'originalHeight' => $l4GK0]);
            goto AiwQP;
            itET9:
            if (!$rLbB_) {
                goto GuJ7B;
            }
            goto c_pqw;
            ANXqx:
            $l4GK0 = $vtvs_->height();
            goto fw8ZN;
            kVfXA:
            $RSfya->muMfW5wYw2z($L5zcu);
            goto YE6KX;
            ZGoNF:
            $PV4mw = $RSfya->mU7oQqORfRT($this->mJyY8EvMuxJ($vtvs_, $mlVz1));
            goto cqjO2;
            cijhJ:
            $L5zcu = $L5zcu->mVNeRFmQ4o0($rLbB_);
            goto y3J0x;
            NHfSg:
            throw new MediaConverterException("CSQMvXC33KbbS {$vtvs_->id} is not S3 driver");
            goto LExZD;
            y3J0x:
            hU9os:
            goto kVfXA;
            LExZD:
            jJciP:
            goto Ml5Cl;
            Ojaq5:
            if (!($vtvs_->rs3Zr !== GrPXtp41lLmde::S3)) {
                goto jJciP;
            }
            goto NHfSg;
            Vpltr:
            Assert::isInstanceOf($vtvs_, CSQMvXC33KbbS::class);
            goto Ojaq5;
            RCS9L:
            if (!($NixDl && $l4GK0)) {
                goto nyQHL;
            }
            goto lC0Cb;
            pMFaM:
            $JBG5O = new WJRFs5dkBBuwo($this->AQqBe, $this->wmqIG, $this->ifs25, $this->kduDw);
            goto hEXWO;
            YE6KX:
            $RSfya->mZdd6VkymGA($TJaxK->m7gkGAfBmh9($vtvs_));
            goto RCS9L;
            SBszu:
            $RSfya = $RSfya->mH79deOSFTC(new Zu01XTNfnZhjW($gpnSS));
            goto nZTwn;
            z3kxe:
            Log::info("Set input video for Job", ['s3Uri' => $gpnSS]);
            goto xc1ZO;
            lC0Cb:
            if (!$this->mETXjpTVw8N($NixDl, $l4GK0)) {
                goto BrCrv;
            }
            goto EEGNU;
            McIPv:
            $RSfya->muMfW5wYw2z($L5zcu);
            goto xNti7;
            c_pqw:
            $YxARL = $YxARL->mVNeRFmQ4o0($rLbB_);
            goto ggCcI;
            zb2LB:
            $RSfya = $RSfya->mAxttTQyPrn($IlGiN);
            goto ZGoNF;
            x9chI:
            Log::info("Set thumbnail for CSQMvXC33KbbS Job", ['videoId' => $vtvs_->getAttribute('id'), 'duration' => $vtvs_->getAttribute('duration')]);
            goto cXCWy;
            osTZe:
            if (!$rLbB_) {
                goto hU9os;
            }
            goto cijhJ;
            wlVxh:
            $rLbB_ = $this->mtjH8G0Yebk($OZKMn, $JBG5O->mRsy9eF6dlc((int) $hUnXA['width'], (int) $hUnXA['height'], $FmRvX));
            goto itET9;
            cXCWy:
            $IlGiN = new KxPUocSKhVWfb($vtvs_->dR3qj ?? 1, 2, $TJaxK->mr6RT9Mznvo($vtvs_));
            goto zb2LB;
            tZ5JS:
            BrCrv:
            goto jctVO;
            hEXWO:
            $rLbB_ = $this->mtjH8G0Yebk($OZKMn, $JBG5O->mRsy9eF6dlc($vtvs_->width(), $vtvs_->height(), $FmRvX));
            goto osTZe;
            cqjO2:
            $vtvs_->update(['aws_media_converter_job_id' => $PV4mw]);
            goto RwQni;
            RwQni:
        } catch (\Exception $Z8tVK) {
            Log::info("CSQMvXC33KbbS has been deleted, discard it", ['fileId' => $PV4mw, 'err' => $Z8tVK->getMessage()]);
            return;
        }
        goto SnRZl;
        qRTHm:
        ini_set('memory_limit', '-1');
        goto a5Eog;
        SnRZl:
    }
    private function mJyY8EvMuxJ(CSQMvXC33KbbS $vtvs_, $mlVz1) : bool
    {
        goto DbQTr;
        kpehT:
        fOF8z:
        goto OY58d;
        fNnva:
        $E8hj0 = (int) round($vtvs_->getAttribute('duration') ?? 0);
        goto PNcBE;
        DbQTr:
        if ($mlVz1) {
            goto jm3dS;
        }
        goto AIuUd;
        AIuUd:
        return false;
        goto LI5h3;
        PNcBE:
        switch (true) {
            case $vtvs_->width() * $vtvs_->height() >= 1920 * 1080 && $vtvs_->width() * $vtvs_->height() < 2560 * 1440:
                return $E8hj0 > 10 * 60;
            case $vtvs_->width() * $vtvs_->height() >= 2560 * 1440 && $vtvs_->width() * $vtvs_->height() < 3840 * 2160:
                return $E8hj0 > 5 * 60;
            case $vtvs_->width() * $vtvs_->height() >= 3840 * 2160:
                return $E8hj0 > 3 * 60;
            default:
                return false;
        }
        goto kpehT;
        OY58d:
        g38sl:
        goto C0ZHI;
        LI5h3:
        jm3dS:
        goto fNnva;
        C0ZHI:
    }
    private function mtjH8G0Yebk(L3oEPipUZv9oB $OZKMn, string $ltOFR) : ?CxY28u9r8wEQP
    {
        goto adnC2;
        B2aVv:
        return null;
        goto t2K9H;
        adnC2:
        $DfwAM = $OZKMn->mZoCLBw0Osx($ltOFR);
        goto L82Ek;
        eHjcJ:
        if (!$DfwAM) {
            goto J9Uyr;
        }
        goto zBfO0;
        XAafC:
        J9Uyr:
        goto B2aVv;
        zBfO0:
        return new CxY28u9r8wEQP($DfwAM, 0, 0, null, null);
        goto XAafC;
        L82Ek:
        Log::info("Resolve watermark for job with url", ['url' => $ltOFR, 'uri' => $DfwAM]);
        goto eHjcJ;
        t2K9H:
    }
    private function mETXjpTVw8N(int $NixDl, int $l4GK0) : bool
    {
        return $NixDl * $l4GK0 > 1.5 * (1920 * 1080);
    }
    private function ms4ksUGpVNi(int $NixDl, int $l4GK0) : array
    {
        $r3soj = new Lt4szzL0KrAkw($NixDl, $l4GK0);
        return $r3soj->mI6SGAwa9UG();
    }
    private function mY4nsY6JGPc(Dup6KVtAFNCUq $FFbb9) : string
    {
        goto hq05g;
        hq05g:
        if (!($FFbb9->rs3Zr == GrPXtp41lLmde::S3)) {
            goto hTQaL;
        }
        goto eqc1q;
        WVyri:
        return $this->kduDw->url($FFbb9->filename);
        goto Ym82z;
        eqc1q:
        return 's3://' . $this->Jc4z2 . '/' . $FFbb9->filename;
        goto txHH5;
        txHH5:
        hTQaL:
        goto WVyri;
        Ym82z:
    }
}
