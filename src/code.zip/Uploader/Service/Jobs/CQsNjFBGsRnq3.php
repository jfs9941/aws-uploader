<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class CQsNjFBGsRnq3 implements StoreToS3JobInterface
{
    private $awXpN;
    private $tcoQz;
    private $AwDbR;
    public function __construct($ek1iS, $v70jj, $uwOBm)
    {
        goto bMv2Q;
        IPQeP:
        $this->awXpN = $ek1iS;
        goto o5_ex;
        bMv2Q:
        $this->tcoQz = $v70jj;
        goto f52oB;
        f52oB:
        $this->AwDbR = $uwOBm;
        goto IPQeP;
        o5_ex:
    }
    public function store(string $B5uQ4) : void
    {
        goto VouCh;
        TQier:
        $w4gn5 = $XTF2w->getAttribute('thumbnail');
        goto ZlZXO;
        l5AlI:
        $this->tcoQz->put($XTF2w->getAttribute('thumbnail'), $this->AwDbR->get($w4gn5), ['visibility' => 'public', 'ContentType' => $dWEzY->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Q2Yax;
        RzKgo:
        M0Pb9:
        goto iiowy;
        spPl8:
        $I9Rl0 = $this->AwDbR->path($w4gn5);
        goto QNNYO;
        SiiKJ:
        return;
        goto bDvBy;
        zL1Dp:
        if (!$XTF2w->update(['driver' => LrHrisEWQ9E5o::S3, 'status' => KidkTsWIjmNMb::FINISHED])) {
            goto Rj_ZR;
        }
        goto dDtTR;
        fk5S3:
        if ($XTF2w) {
            goto M0Pb9;
        }
        goto WB_Q0;
        Hqpad:
        $I4v2U = $this->AwDbR->path($XTF2w->getAttribute('preview'));
        goto Tmz4q;
        qagzu:
        $this->mtV8outZ5WY($uUtRl, $XTF2w->getLocation());
        goto TQier;
        Q2Yax:
        XRUWj:
        goto gOluR;
        VouCh:
        $XTF2w = U0IzvN2kaLZHI::findOrFail($B5uQ4);
        goto fk5S3;
        tBIoF:
        $this->tcoQz->put($XTF2w->getAttribute('preview'), $this->AwDbR->get($XTF2w->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $xjP_H->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto NLQlg;
        QNNYO:
        $dWEzY = $this->awXpN->call($this, $I9Rl0);
        goto l5AlI;
        ZlZXO:
        if (!($w4gn5 && $this->AwDbR->exists($w4gn5))) {
            goto XRUWj;
        }
        goto spPl8;
        xCx02:
        U0IzvN2kaLZHI::where('parent_id', $B5uQ4)->update(['driver' => LrHrisEWQ9E5o::S3, 'preview' => $XTF2w->getAttribute('preview'), 'thumbnail' => $XTF2w->getAttribute('thumbnail')]);
        goto SiiKJ;
        NLQlg:
        utLPk:
        goto zL1Dp;
        lfQ9z:
        return;
        goto RzKgo;
        dDtTR:
        Log::info("U0IzvN2kaLZHI stored to S3, update the children attachments", ['fileId' => $B5uQ4]);
        goto xCx02;
        Tmz4q:
        $xjP_H = $this->awXpN->call($this, $I4v2U);
        goto tBIoF;
        WB_Q0:
        Log::info("U0IzvN2kaLZHI has been deleted, discard it", ['fileId' => $B5uQ4]);
        goto lfQ9z;
        yDA9P:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $B5uQ4]);
        goto F7WD4;
        gOluR:
        if (!($XTF2w->getAttribute('preview') && $this->AwDbR->exists($XTF2w->getAttribute('preview')))) {
            goto utLPk;
        }
        goto Hqpad;
        iiowy:
        $uUtRl = $this->AwDbR->path($XTF2w->getLocation());
        goto qagzu;
        bDvBy:
        Rj_ZR:
        goto yDA9P;
        F7WD4:
    }
    private function mtV8outZ5WY($M128j, $h_hr1, $M5w3u = '')
    {
        goto cr4j8;
        ZJOL8:
        $h_hr1 = str_replace('.jpg', $M5w3u, $h_hr1);
        goto ko2e2;
        ko2e2:
        r8fCj:
        goto dkP2a;
        dkP2a:
        try {
            $jYl_6 = $this->awXpN->call($this, $M128j);
            $this->tcoQz->put($h_hr1, $this->AwDbR->get($h_hr1), ['visibility' => 'public', 'ContentType' => $jYl_6->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $xMxrQ) {
            Log::error("Failed to upload image to S3", ['s3Path' => $h_hr1, 'error' => $xMxrQ->getMessage()]);
        }
        goto ehygm;
        cr4j8:
        if (!$M5w3u) {
            goto r8fCj;
        }
        goto yj8Jo;
        yj8Jo:
        $M128j = str_replace('.jpg', $M5w3u, $M128j);
        goto ZJOL8;
        ehygm:
    }
}
