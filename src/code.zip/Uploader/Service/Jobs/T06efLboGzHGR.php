<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Encoder\MgrvlygkdVSsk;
use Jfs\Uploader\Encoder\SlIVoKaoiMz2R;
use Jfs\Uploader\Encoder\EVSDjuMy24t33;
use Jfs\Uploader\Encoder\REmYsZqYs4zoN;
use Jfs\Uploader\Encoder\MeWuDqb0fEhjz;
use Jfs\Uploader\Encoder\JZNnhECD5SO1I;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Jfs\Uploader\Service\Jobs\SlR2p0ymVgfJp;
use Jfs\Uploader\Service\Jobs\LFbK8cyK0wiWn;
use Jfs\Uploader\Service\Lqd1WdK14h5gQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class T06efLboGzHGR implements MediaEncodeJobInterface
{
    private $kJEi8;
    private $ZPzJH;
    private $bLZP5;
    private $B3G_O;
    private $loW7J;
    public function __construct(string $r087v, $G3exm, $C1By6, $PqmeA, $gewHh)
    {
        goto R3so_;
        UKlcK:
        $this->loW7J = $gewHh;
        goto hO44d;
        NmSos:
        $this->bLZP5 = $C1By6;
        goto tf4gO;
        R3so_:
        $this->kJEi8 = $r087v;
        goto e1UHu;
        e1UHu:
        $this->ZPzJH = $G3exm;
        goto NmSos;
        tf4gO:
        $this->B3G_O = $PqmeA;
        goto UKlcK;
        hO44d:
    }
    public function encode(string $DWjir, string $gDswH, $bdi0k = true) : void
    {
        goto Isv37;
        aXB7M:
        try {
            goto cw8lX;
            m9Sff:
            KuU7Q:
            goto ChRY4;
            zYzyD:
            DNkRG:
            goto W7cKl;
            MME_1:
            cc3oc:
            goto m9Sff;
            cw8lX:
            $lamFK = J7sRaWo8um3yO::findOrFail($DWjir);
            goto GzOS_;
            ChRY4:
            Log::info("Set thumbnail for J7sRaWo8um3yO Job", ['videoId' => $lamFK->getAttribute('id'), 'duration' => $lamFK->getAttribute('duration')]);
            goto DQf8D;
            MRZ9l:
            throw new MediaConverterException("J7sRaWo8um3yO {$lamFK->id} is not S3 driver");
            goto zYzyD;
            xeXot:
            if (!$vhAbg) {
                goto j5nqu;
            }
            goto gajJU;
            S03ob:
            $vhAbg = $this->mfxfXc82xnM($IEOZW, $BO1eQ->mjt3bIAGpxP((int) $IqMXK['width'], (int) $IqMXK['height'], $gDswH));
            goto CcXZY;
            gajJU:
            $BFGUn = $BFGUn->my9nsBmlsOQ($vhAbg);
            goto dwwFC;
            gKRCJ:
            $jknT2 = $jknT2->mXerkE5mk8C($zHDrZ);
            goto MME_1;
            L5Hlb:
            $lamFK->update(['aws_media_converter_job_id' => $DWjir]);
            goto XhBu9;
            dwwFC:
            j5nqu:
            goto M3qUK;
            uCx4s:
            $zHDrZ = $zHDrZ->my9nsBmlsOQ($vhAbg);
            goto bUSeu;
            BA9z_:
            $IqMXK = $this->mfj3hNm2w0J($ASgWt, $ybj1g);
            goto CWqAA;
            i1m4b:
            $DWjir = $jknT2->mIwUmoVM1Md($this->mVZ7H6uKjGR($lamFK, $bdi0k));
            goto L5Hlb;
            DQf8D:
            $UT4QS = new MgrvlygkdVSsk($lamFK->Tgl_g ?? 1, 2, $vulhD->m84b2cDwFVh($lamFK));
            goto khOor;
            CXxDc:
            $jknT2 = app(MeWuDqb0fEhjz::class);
            goto JGRpb;
            M3qUK:
            $jknT2->mXerkE5mk8C($BFGUn);
            goto Yz8V7;
            I2bqb:
            $vhAbg = $this->mfxfXc82xnM($IEOZW, $BO1eQ->mjt3bIAGpxP($lamFK->width(), $lamFK->height(), $gDswH));
            goto xeXot;
            Bt5gO:
            if (!$this->mdiREPUSbjK($ASgWt, $ybj1g)) {
                goto cc3oc;
            }
            goto BA9z_;
            CWqAA:
            Log::info("Set 1080p resolution for Job", ['width' => $IqMXK['width'], 'height' => $IqMXK['height'], 'originalWidth' => $ASgWt, 'originalHeight' => $ybj1g]);
            goto Uo4jq;
            jzdXl:
            if (!($ASgWt && $ybj1g)) {
                goto KuU7Q;
            }
            goto Bt5gO;
            pxtA6:
            $vulhD = app(EVSDjuMy24t33::class);
            goto f4A4r;
            fdNOQ:
            $ybj1g = $lamFK->height();
            goto wOXJp;
            Yz8V7:
            $jknT2->mc9UXrQrNX3($vulhD->mCgDTwgqDv8($lamFK));
            goto jzdXl;
            EyJkk:
            Log::info("Set input video for Job", ['s3Uri' => $cSDXo]);
            goto CXxDc;
            BBmtv:
            if (!($lamFK->h8PS2 !== KkaUVP3OQvOtp::S3)) {
                goto DNkRG;
            }
            goto MRZ9l;
            GzOS_:
            Assert::isInstanceOf($lamFK, J7sRaWo8um3yO::class);
            goto BBmtv;
            f4A4r:
            $jknT2->mXerkE5mk8C($BFGUn);
            goto I00FJ;
            W7cKl:
            $ASgWt = $lamFK->width();
            goto fdNOQ;
            wOXJp:
            $cSDXo = $this->mvhTnR9BfpN($lamFK);
            goto EyJkk;
            JGRpb:
            $jknT2 = $jknT2->mcjLPIWoXTz(new REmYsZqYs4zoN($cSDXo));
            goto idSvj;
            Uo4jq:
            $zHDrZ = new SlIVoKaoiMz2R('1080p', $IqMXK['width'], $IqMXK['height'], $lamFK->Uu1La ?? 30);
            goto S03ob;
            I00FJ:
            $jknT2->mc9UXrQrNX3($vulhD->mCgDTwgqDv8($lamFK));
            goto QHo9u;
            khOor:
            $jknT2 = $jknT2->mHlXwZI38Kk($UT4QS);
            goto i1m4b;
            uxDpt:
            $BO1eQ = new LFbK8cyK0wiWn($this->B3G_O, $this->loW7J, $this->bLZP5, $this->ZPzJH);
            goto I2bqb;
            QHo9u:
            $IEOZW = app(Lqd1WdK14h5gQ::class);
            goto uxDpt;
            CcXZY:
            if (!$vhAbg) {
                goto xfLP3;
            }
            goto uCx4s;
            bUSeu:
            xfLP3:
            goto gKRCJ;
            idSvj:
            $BFGUn = new SlIVoKaoiMz2R('original', $ASgWt, $ybj1g, $lamFK->Uu1La ?? 30);
            goto pxtA6;
            XhBu9:
        } catch (\Exception $x4bzR) {
            Log::info("J7sRaWo8um3yO has been deleted, discard it", ['fileId' => $DWjir, 'err' => $x4bzR->getMessage()]);
            return;
        }
        goto W3KmS;
        Isv37:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $DWjir]);
        goto fxlqR;
        fxlqR:
        ini_set('memory_limit', '-1');
        goto aXB7M;
        W3KmS:
    }
    private function mVZ7H6uKjGR(J7sRaWo8um3yO $lamFK, $bdi0k) : bool
    {
        goto KsehW;
        DmtPu:
        mVqtw:
        goto dyAwQ;
        dyAwQ:
        FDEZ_:
        goto HQ0Ki;
        U50zt:
        return false;
        goto FvsCX;
        KsehW:
        if ($bdi0k) {
            goto oHQog;
        }
        goto U50zt;
        FvsCX:
        oHQog:
        goto P7cqN;
        RfIbp:
        switch (true) {
            case $lamFK->width() * $lamFK->height() >= 1920 * 1080 && $lamFK->width() * $lamFK->height() < 2560 * 1440:
                return $Ok2Xi > 10 * 60;
            case $lamFK->width() * $lamFK->height() >= 2560 * 1440 && $lamFK->width() * $lamFK->height() < 3840 * 2160:
                return $Ok2Xi > 5 * 60;
            case $lamFK->width() * $lamFK->height() >= 3840 * 2160:
                return $Ok2Xi > 3 * 60;
            default:
                return false;
        }
        goto DmtPu;
        P7cqN:
        $Ok2Xi = (int) round($lamFK->getAttribute('duration') ?? 0);
        goto RfIbp;
        HQ0Ki:
    }
    private function mfxfXc82xnM(Lqd1WdK14h5gQ $IEOZW, string $YrdXo) : ?JZNnhECD5SO1I
    {
        goto N2lB1;
        qfXuY:
        if (!$AZpD6) {
            goto PjaA0;
        }
        goto IQPRS;
        N2lB1:
        $AZpD6 = $IEOZW->mRya8qVbTAk($YrdXo);
        goto oqdDM;
        oqdDM:
        Log::info("Resolve watermark for job with url", ['url' => $YrdXo, 'uri' => $AZpD6]);
        goto qfXuY;
        v11Xh:
        return null;
        goto KPAQ3;
        N2nzM:
        PjaA0:
        goto v11Xh;
        IQPRS:
        return new JZNnhECD5SO1I($AZpD6, 0, 0, null, null);
        goto N2nzM;
        KPAQ3:
    }
    private function mdiREPUSbjK(int $ASgWt, int $ybj1g) : bool
    {
        return $ASgWt * $ybj1g > 1.5 * (1920 * 1080);
    }
    private function mfj3hNm2w0J(int $ASgWt, int $ybj1g) : array
    {
        $AJ8vl = new SlR2p0ymVgfJp($ASgWt, $ybj1g);
        return $AJ8vl->mIiWPR3OCUB();
    }
    private function mvhTnR9BfpN(F43pNWIrUhz3z $bPdTZ) : string
    {
        goto tubg4;
        bBND1:
        return $this->ZPzJH->url($bPdTZ->filename);
        goto bJSUG;
        tubg4:
        if (!($bPdTZ->h8PS2 == KkaUVP3OQvOtp::S3)) {
            goto X1jec;
        }
        goto UHdVt;
        UHdVt:
        return 's3://' . $this->kJEi8 . '/' . $bPdTZ->filename;
        goto t49PY;
        t49PY:
        X1jec:
        goto bBND1;
        bJSUG:
    }
}
