<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class AO2UYNmU0Lk7c implements GenerateThumbnailForVideoInterface
{
    private $SM9Fi;
    public function __construct($EJ0I6)
    {
        $this->SM9Fi = $EJ0I6;
    }
    public function generate(string $mfjeD) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $mfjeD);
        $this->SM9Fi->createThumbnail($mfjeD);
    }
}
