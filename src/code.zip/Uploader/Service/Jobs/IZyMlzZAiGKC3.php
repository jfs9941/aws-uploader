<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class IZyMlzZAiGKC3 implements GenerateThumbnailJobInterface
{
    const YOzWW = 150;
    const R0Xku = 150;
    private $KXch8;
    private $oBaPs;
    private $AlJXw;
    public function __construct($FeIAB, $paaZf, $PcD2s)
    {
        goto K8unN;
        cMblf:
        $this->AlJXw = $PcD2s;
        goto RqPH9;
        XewUN:
        $this->oBaPs = $paaZf;
        goto cMblf;
        K8unN:
        $this->KXch8 = $FeIAB;
        goto XewUN;
        RqPH9:
    }
    public function generate(string $JTwN4)
    {
        goto Tsdfl;
        Tsdfl:
        Log::info("Generating thumbnail", ['imageId' => $JTwN4]);
        goto glZHx;
        glZHx:
        ini_set('memory_limit', '-1');
        goto aluUH;
        aluUH:
        try {
            goto xNmhU;
            aY_eT:
            $kRpMX = $this->KXch8->call($this, $nQYui->path($a97TB->getLocation()));
            goto Kj1u6;
            fNl1x:
            $a97TB->update(['thumbnail' => $uMpUA, 'status' => FdWrko7bmoI4Y::THUMBNAIL_PROCESSED]);
            goto pqxyj;
            tyXrA:
            unset($kRpMX);
            goto piHle;
            Vxma1:
            $a97TB = Z7LUL65CwqbbF::findOrFail($JTwN4);
            goto aY_eT;
            Kj1u6:
            $kRpMX->orient()->resize(150, 150);
            goto yw6_3;
            yw6_3:
            $uMpUA = $this->m0Ihgaxh2Ma($a97TB);
            goto HlnZU;
            piHle:
            if (!($uTVQA !== false)) {
                goto Bwc6v;
            }
            goto fNl1x;
            HlnZU:
            $uTVQA = $this->AlJXw->put($uMpUA, $kRpMX->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto tyXrA;
            pqxyj:
            Bwc6v:
            goto Hbzw6;
            xNmhU:
            $nQYui = $this->oBaPs;
            goto Vxma1;
            Hbzw6:
        } catch (ModelNotFoundException $QtemZ) {
            Log::info("Z7LUL65CwqbbF has been deleted, discard it", ['imageId' => $JTwN4]);
            return;
        } catch (\Exception $QtemZ) {
            Log::error("Failed to generate thumbnail", ['imageId' => $JTwN4, 'error' => $QtemZ->getMessage()]);
        }
        goto jb8C0;
        jb8C0:
    }
    private function m0Ihgaxh2Ma(MEyH4ejCzSk64 $a97TB) : string
    {
        goto Hdo_v;
        bGP2T:
        $ksWJO = dirname($uMpUA);
        goto tDR8J;
        EgF3I:
        return $DEwIL . '/' . $a97TB->getFilename() . '.jpg';
        goto FfCRu;
        Hdo_v:
        $uMpUA = $a97TB->getLocation();
        goto bGP2T;
        tDR8J:
        $DEwIL = $ksWJO . '/' . self::YOzWW . 'X' . self::R0Xku;
        goto EgF3I;
        FfCRu:
    }
}
