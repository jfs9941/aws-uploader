<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Illuminate\Support\Facades\Log;
class PV5mhdJpGbLXd implements BlurVideoJobInterface
{
    const nYHSl = 15;
    const ycJ33 = 500;
    const L31tq = 500;
    private $buleS;
    private $UoQI7;
    private $pCaD7;
    public function __construct($nFvaK, $UjVft, $P3zvl)
    {
        goto JZKb7;
        nXkK4:
        $this->UoQI7 = $UjVft;
        goto vo1Pe;
        JZKb7:
        $this->pCaD7 = $P3zvl;
        goto nXkK4;
        vo1Pe:
        $this->buleS = $nFvaK;
        goto NrWXy;
        NrWXy:
    }
    public function blur(string $InHEz) : void
    {
        goto FcWDU;
        Hhlsv:
        $BbstY = $VGttq->width() / $VGttq->height();
        goto FyFqP;
        qVlSj:
        rVXDJ:
        goto G4O3i;
        FyFqP:
        $VGttq->resize(self::ycJ33, self::L31tq / $BbstY);
        goto bd_Vx;
        xUZVf:
        throw new \Exception('Failed to set final permissions on image file: ' . $vBiuG);
        goto oX_Wy;
        FcWDU:
        Log::info("Blurring for video", ['videoID' => $InHEz]);
        goto s8ZYj;
        ofIut:
        if (chmod($vBiuG, 0664)) {
            goto JPzv5;
        }
        goto PcA46;
        hBaAO:
        $VGttq = $this->buleS->call($this, $this->pCaD7->path($Arn1o->getAttribute('thumbnail')));
        goto Hhlsv;
        gBql0:
        $Arn1o->update(['preview' => $Aj9Of]);
        goto qVlSj;
        PcA46:
        \Log::warning('Failed to set final permissions on image file: ' . $vBiuG);
        goto xUZVf;
        DPON8:
        $Aj9Of = $this->mb3XeVOKROc($Arn1o);
        goto zu8oO;
        oX_Wy:
        JPzv5:
        goto gBql0;
        e84EN:
        unset($VGttq);
        goto ofIut;
        Dc8ZB:
        $this->UoQI7->put($Aj9Of, $this->pCaD7->get($Aj9Of));
        goto e84EN;
        bd_Vx:
        $VGttq->blur(self::nYHSl);
        goto DPON8;
        F9qFJ:
        if (!$Arn1o->getAttribute('thumbnail')) {
            goto rVXDJ;
        }
        goto lAUXy;
        s8ZYj:
        ini_set('memory_limit', '-1');
        goto VWrXe;
        VWrXe:
        $Arn1o = JPkW9ix1EKo3T::findOrFail($InHEz);
        goto F9qFJ;
        lAUXy:
        $this->pCaD7->put($Arn1o->getAttribute('thumbnail'), $this->UoQI7->get($Arn1o->getAttribute('thumbnail')));
        goto hBaAO;
        fcCN8:
        $VGttq->save($vBiuG);
        goto Dc8ZB;
        zu8oO:
        $vBiuG = $this->pCaD7->path($Aj9Of);
        goto fcCN8;
        G4O3i:
    }
    private function mb3XeVOKROc(JVAg1Gkd0EvTM $d8G8J) : string
    {
        goto I244f;
        SLRBY:
        if ($this->pCaD7->exists($jY69S)) {
            goto i70sN;
        }
        goto OcKJL;
        I244f:
        $hKqqZ = $d8G8J->getLocation();
        goto ZS302;
        MET1W:
        i70sN:
        goto TWU2y;
        OcKJL:
        $this->pCaD7->makeDirectory($jY69S, 0755, true);
        goto MET1W;
        ZS302:
        $jY69S = dirname($hKqqZ) . '/preview/';
        goto SLRBY;
        TWU2y:
        return $jY69S . $d8G8J->getFilename() . '.jpg';
        goto OW1t9;
        OW1t9:
    }
}
