<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Illuminate\Support\Facades\Log;
class WJlfwmcgPA8A1 implements BlurVideoJobInterface
{
    const pcl6K = 15;
    const rl6ku = 500;
    const gi9mL = 500;
    private $awXpN;
    private $tcoQz;
    private $AwDbR;
    public function __construct($ek1iS, $v70jj, $uwOBm)
    {
        goto gmir4;
        BHpu1:
        $this->tcoQz = $v70jj;
        goto eFRrM;
        gmir4:
        $this->AwDbR = $uwOBm;
        goto BHpu1;
        eFRrM:
        $this->awXpN = $ek1iS;
        goto qvLi2;
        qvLi2:
    }
    public function blur(string $B5uQ4) : void
    {
        goto mrY1l;
        T9og3:
        \Log::warning('Failed to set final permissions on image file: ' . $vf0_W);
        goto iMYuK;
        iGBcO:
        DI2oa:
        goto YDJkL;
        eMT3S:
        $this->tcoQz->put($I4v2U, $this->AwDbR->get($I4v2U));
        goto kEluL;
        GZSPD:
        $this->AwDbR->put($TJFpA->getAttribute('thumbnail'), $this->tcoQz->get($TJFpA->getAttribute('thumbnail')));
        goto zVVEj;
        W05qm:
        $jYl_6->blur(self::pcl6K);
        goto lUo0A;
        kEluL:
        unset($jYl_6);
        goto uoDBt;
        YDJkL:
        $TJFpA->update(['preview' => $I4v2U]);
        goto cCKfy;
        YEHg_:
        $TJFpA = CpeNYzI7e1ALA::findOrFail($B5uQ4);
        goto Xd1kA;
        cu1gY:
        $TZSdr = $jYl_6->width() / $jYl_6->height();
        goto d4a6r;
        iMYuK:
        throw new \Exception('Failed to set final permissions on image file: ' . $vf0_W);
        goto iGBcO;
        p_DwK:
        $jYl_6->save($vf0_W);
        goto eMT3S;
        cz1iQ:
        ini_set('memory_limit', '-1');
        goto YEHg_;
        mrY1l:
        Log::info("Blurring for video", ['videoID' => $B5uQ4]);
        goto cz1iQ;
        lUo0A:
        $I4v2U = $this->mv6VKtsmUGA($TJFpA);
        goto dlnGX;
        zVVEj:
        $jYl_6 = $this->awXpN->call($this, $this->AwDbR->path($TJFpA->getAttribute('thumbnail')));
        goto cu1gY;
        dlnGX:
        $vf0_W = $this->AwDbR->path($I4v2U);
        goto p_DwK;
        d4a6r:
        $jYl_6->resize(self::rl6ku, self::gi9mL / $TZSdr);
        goto W05qm;
        cCKfy:
        pJ1xN:
        goto GFVAq;
        uoDBt:
        if (chmod($vf0_W, 0664)) {
            goto DI2oa;
        }
        goto T9og3;
        Xd1kA:
        if (!$TJFpA->getAttribute('thumbnail')) {
            goto pJ1xN;
        }
        goto GZSPD;
        GFVAq:
    }
    private function mv6VKtsmUGA(Guvqjk2EvHsmF $nuWgw) : string
    {
        goto opdSF;
        bpYMy:
        $pVfz3 = dirname($uUtRl) . '/preview/';
        goto BsjGL;
        MH3Kv:
        wv21w:
        goto wE5Kj;
        opdSF:
        $uUtRl = $nuWgw->getLocation();
        goto bpYMy;
        wE5Kj:
        return $pVfz3 . $nuWgw->getFilename() . '.jpg';
        goto EaKkQ;
        BR7UY:
        $this->AwDbR->makeDirectory($pVfz3, 0755, true);
        goto MH3Kv;
        BsjGL:
        if ($this->AwDbR->exists($pVfz3)) {
            goto wv21w;
        }
        goto BR7UY;
        EaKkQ:
    }
}
