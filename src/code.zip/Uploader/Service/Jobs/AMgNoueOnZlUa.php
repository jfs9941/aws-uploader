<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Service\Jobs\H09smfnGPffl7;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class AMgNoueOnZlUa implements WatermarkTextJobInterface
{
    private $e2JZZ;
    private $ScRnx;
    private $Daa3m;
    private $uiTOc;
    private $W2Sfl;
    public function __construct($yGjLo, $tUc4C, $ATeSz, $d_Wiu, $EJP8o)
    {
        goto oa99V;
        BEjzv:
        $this->ScRnx = $tUc4C;
        goto NZWTb;
        rd41W:
        $this->W2Sfl = $d_Wiu;
        goto O1m7g;
        O1m7g:
        $this->Daa3m = $EJP8o;
        goto BEjzv;
        xMvTX:
        $this->uiTOc = $ATeSz;
        goto rd41W;
        oa99V:
        $this->e2JZZ = $yGjLo;
        goto xMvTX;
        NZWTb:
    }
    public function putWatermark(string $B_L9m, string $i4v7Y) : void
    {
        goto R8ck0;
        OTDcb:
        Log::info("Adding watermark text to image", ['imageId' => $B_L9m]);
        goto q3_re;
        R8ck0:
        $iw0Jp = microtime(true);
        goto lDgCC;
        q3_re:
        ini_set('memory_limit', '-1');
        goto H9Z3i;
        lDgCC:
        $hi2m0 = memory_get_usage();
        goto Lu55w;
        H9Z3i:
        try {
            goto N1Kr_;
            KiOd3:
            \Log::warning('Failed to set final permissions on image file: ' . $dTJxl);
            goto ALhYn;
            f1aPs:
            $dTJxl = $this->W2Sfl->path($zCabx->getLocation());
            goto lwCi6;
            vwJNe:
            hIwBX:
            goto f1aPs;
            OuQ3G:
            if ($this->W2Sfl->exists($zCabx->getLocation())) {
                goto hIwBX;
            }
            goto zL3S7;
            ALhYn:
            throw new \Exception('Failed to set final permissions on image file: ' . $dTJxl);
            goto ODTSR;
            lwCi6:
            $e5260 = $this->e2JZZ->call($this, $dTJxl);
            goto Ug3EK;
            byAAh:
            $this->uiTOc->put($dTJxl, $e5260->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto c4SF9;
            ODTSR:
            zHyBT:
            goto lsj2C;
            Ug3EK:
            $e5260->orient();
            goto hlQTG;
            hlQTG:
            $this->mSRueVluB92($e5260, $i4v7Y);
            goto byAAh;
            yE9vX:
            if (chmod($dTJxl, 0664)) {
                goto zHyBT;
            }
            goto KiOd3;
            N1Kr_:
            $zCabx = XMeo8SOmME8kj::findOrFail($B_L9m);
            goto OuQ3G;
            zL3S7:
            Log::error("XMeo8SOmME8kj is not on local, might be deleted before put watermark", ['imageId' => $B_L9m]);
            goto b1DsG;
            c4SF9:
            unset($e5260);
            goto yE9vX;
            b1DsG:
            return;
            goto vwJNe;
            lsj2C:
        } catch (\Throwable $STlXt) {
            goto eyECs;
            eyECs:
            if (!$STlXt instanceof ModelNotFoundException) {
                goto n6D3l;
            }
            goto dkbJK;
            uK1RF:
            return;
            goto PyHlE;
            PyHlE:
            n6D3l:
            goto i_mZW;
            i_mZW:
            Log::error("XMeo8SOmME8kj is not readable", ['imageId' => $B_L9m, 'error' => $STlXt->getMessage()]);
            goto CK8T3;
            dkbJK:
            Log::info("XMeo8SOmME8kj has been deleted, discard it", ['imageId' => $B_L9m]);
            goto uK1RF;
            CK8T3:
        } finally {
            $C_8tm = microtime(true);
            $U52Iz = memory_get_usage();
            $QtsLN = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $B_L9m, 'execution_time_sec' => $C_8tm - $iw0Jp, 'memory_usage_mb' => ($U52Iz - $hi2m0) / 1024 / 1024, 'peak_memory_usage_mb' => ($QtsLN - $n0RF8) / 1024 / 1024]);
        }
        goto EL5c1;
        Lu55w:
        $n0RF8 = memory_get_peak_usage();
        goto OTDcb;
        EL5c1:
    }
    private function mSRueVluB92($e5260, $i4v7Y) : void
    {
        goto tHLVc;
        CdclG:
        $RScQm = $Cn0jL->mR2ojYBGTKb($BKFYC, $ZDe2g, $i4v7Y, true);
        goto rhBJu;
        vN2da:
        $e5260->place($ag0E3, 'top-left', 0, 0, 30);
        goto mxU3v;
        tHLVc:
        $BKFYC = $e5260->width();
        goto q3t_b;
        q3t_b:
        $ZDe2g = $e5260->height();
        goto StDOc;
        LL2Kj:
        $ag0E3 = $this->e2JZZ->call($this, $this->W2Sfl->path($RScQm));
        goto vN2da;
        rhBJu:
        $this->W2Sfl->put($RScQm, $this->uiTOc->get($RScQm));
        goto LL2Kj;
        StDOc:
        $Cn0jL = new H09smfnGPffl7($this->ScRnx, $this->Daa3m, $this->uiTOc, $this->W2Sfl);
        goto CdclG;
        mxU3v:
    }
}
