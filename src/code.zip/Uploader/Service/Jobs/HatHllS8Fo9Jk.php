<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class HatHllS8Fo9Jk implements GenerateThumbnailJobInterface
{
    const TNZPU = 150;
    const DXY2M = 150;
    private $bg_1H;
    private $P6k4O;
    public function __construct($IDVBi, $RNTis)
    {
        $this->bg_1H = $IDVBi;
        $this->P6k4O = $RNTis;
    }
    public function generate(string $IaHim)
    {
        goto lHfTR;
        Pipq2:
        ini_set('memory_limit', '-1');
        goto Ejkdp;
        lHfTR:
        Log::info("Generating thumbnail", ['imageId' => $IaHim]);
        goto Pipq2;
        Ejkdp:
        try {
            goto Aij31;
            eI2nS:
            $J9w6o->encode('jpg', 80);
            goto MKc3l;
            Aij31:
            $Q0hWX = $this->P6k4O;
            goto aDtTf;
            aDtTf:
            $kHreC = FNGNxcyxjaxBG::findOrFail($IaHim);
            goto q96pE;
            qHPrk:
            vGjep:
            goto iXm0B;
            syXva:
            if (!($e9GS7 !== false)) {
                goto vGjep;
            }
            goto hCpEq;
            eumTg:
            Log::warning('Failed to set file permissions for stored image: ' . $EAgPt);
            goto rZYWk;
            G8AHC:
            $EAgPt = $Q0hWX->path($JM0UK);
            goto QE2Ns;
            lLN_P:
            $J9w6o->destroy();
            goto syXva;
            q96pE:
            $J9w6o = $this->bg_1H->call($this, $Q0hWX->path($kHreC->getLocation()));
            goto eMs71;
            vYUhR:
            $e9GS7 = $Q0hWX->put($JM0UK, $J9w6o->stream(), ['visibility' => 'public']);
            goto lLN_P;
            QE2Ns:
            if (chmod($EAgPt, 0644)) {
                goto I0ySz;
            }
            goto eumTg;
            hCpEq:
            $kHreC->update(['thumbnail' => $JM0UK, 'status' => QoCMzcKvH8Cw2::THUMBNAIL_PROCESSED]);
            goto G8AHC;
            eMs71:
            $J9w6o->fit(150, 150, function ($hmLlM) {
                $hmLlM->aspectRatio();
            });
            goto eI2nS;
            gHFEW:
            I0ySz:
            goto qHPrk;
            rZYWk:
            throw new \Exception('Failed to set file permissions for stored image: ' . $EAgPt);
            goto gHFEW;
            MKc3l:
            $JM0UK = $this->mvvrF4Zg2fO($kHreC);
            goto vYUhR;
            iXm0B:
        } catch (ModelNotFoundException $aa8DU) {
            Log::info("FNGNxcyxjaxBG has been deleted, discard it", ['imageId' => $IaHim]);
            return;
        }
        goto BzE7J;
        BzE7J:
    }
    private function mvvrF4Zg2fO(GuA6QuvssLUzf $kHreC) : string
    {
        goto KNN5K;
        mki_g:
        $AIxlT = $ho7V0 . '/' . self::TNZPU . 'X' . self::DXY2M;
        goto BGD2T;
        rv5_8:
        $ho7V0 = dirname($JM0UK);
        goto mki_g;
        BGD2T:
        return $AIxlT . '/' . $kHreC->getFilename() . '.jpg';
        goto N02nR;
        KNN5K:
        $JM0UK = $kHreC->getLocation();
        goto rv5_8;
        N02nR:
    }
}
