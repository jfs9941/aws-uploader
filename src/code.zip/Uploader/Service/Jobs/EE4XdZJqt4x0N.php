<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class EE4XdZJqt4x0N implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $ShXx2) : void
    {
        goto YNgMf;
        wSvnt:
        vE__C:
        goto jKIs1;
        YNgMf:
        $uA7Bz = D6fOq8lm3n7T2::findOrFail($ShXx2);
        goto s0jmV;
        zzwdX:
        $this->mdREheHb6z2($uA7Bz);
        goto wSvnt;
        s0jmV:
        if ($uA7Bz->width() > 0 && $uA7Bz->height() > 0) {
            goto vE__C;
        }
        goto zzwdX;
        jKIs1:
    }
    private function mdREheHb6z2(D6fOq8lm3n7T2 $pRvih) : void
    {
        goto r60G8;
        mJmV2:
        $YR5_Q = $OGMfp->getDimensions();
        goto hQceU;
        hQceU:
        $pRvih->update(['duration' => $PK0_J->getDurationInSeconds(), 'resolution' => $YR5_Q->getWidth() . 'x' . $YR5_Q->getHeight(), 'fps' => $OGMfp->get('r_frame_rate') ?? 30]);
        goto ZR74g;
        WiTJY:
        $PK0_J = FFMpeg::fromDisk($VwddT['path'])->open($pRvih->getAttribute('filename'));
        goto BseL9;
        BseL9:
        $OGMfp = $PK0_J->getVideoStream();
        goto mJmV2;
        r60G8:
        $VwddT = $pRvih->getView();
        goto WiTJY;
        ZR74g:
    }
}
