<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class Irgild271Mt83
{
    private $NgSyp;
    private $iNHSn;
    public function __construct(int $g3v5k, int $neb3c)
    {
        goto i8ZfM;
        oQBpA:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto Hf0_I;
        Ud_aG:
        dY3o2:
        goto LJdTu;
        LJdTu:
        $this->NgSyp = $g3v5k;
        goto n2GVc;
        i8ZfM:
        if (!($g3v5k <= 0)) {
            goto quAIm;
        }
        goto oQBpA;
        rCqVJ:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Ud_aG;
        K8ZZ8:
        if (!($neb3c <= 0)) {
            goto dY3o2;
        }
        goto rCqVJ;
        Hf0_I:
        quAIm:
        goto K8ZZ8;
        n2GVc:
        $this->iNHSn = $neb3c;
        goto u4D5w;
        u4D5w:
    }
    private static function mXm04oaUd2N($BUxbk, string $c9KqH = 'floor') : int
    {
        goto FsoB1;
        ZYNvW:
        return (int) $BUxbk;
        goto FhGeO;
        FhGeO:
        dwCqN:
        goto QsKgh;
        X8MLr:
        return $BUxbk;
        goto ofOcR;
        FsoB1:
        if (!(is_int($BUxbk) && $BUxbk % 2 === 0)) {
            goto Qmicg;
        }
        goto X8MLr;
        vQhdS:
        jqCZc:
        goto gqeRt;
        QsKgh:
        switch (strtolower($c9KqH)) {
            case 'ceil':
                return (int) (ceil($BUxbk / 2) * 2);
            case 'round':
                return (int) (round($BUxbk / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($BUxbk / 2) * 2);
        }
        goto vQhdS;
        EGO3O:
        if (!(is_float($BUxbk) && $BUxbk == floor($BUxbk) && (int) $BUxbk % 2 === 0)) {
            goto dwCqN;
        }
        goto ZYNvW;
        ofOcR:
        Qmicg:
        goto EGO3O;
        gqeRt:
        isMiG:
        goto ALU1Z;
        ALU1Z:
    }
    public function mcbO4JYb277(string $bPUeT = 'floor') : array
    {
        goto saqvl;
        jv7Qa:
        $BXJId = self::mXm04oaUd2N(round($JzCpu), $bPUeT);
        goto Jd72r;
        V8XAf:
        $OYJa8 = $Efimn / $this->NgSyp;
        goto bCY3A;
        f77pH:
        $Efimn = 2;
        goto STMsq;
        nRum2:
        $Efimn = $zLlEU;
        goto V8XAf;
        Fd3Oz:
        $Efimn = self::mXm04oaUd2N(round($aHnXN), $bPUeT);
        goto GDEjG;
        STMsq:
        G857b:
        goto NjNvR;
        NjNvR:
        if (!($BXJId < 2)) {
            goto Gi2wE;
        }
        goto inemT;
        Jd72r:
        goto vs1kM;
        goto HcHat;
        WIqJQ:
        if (!($Efimn < 2)) {
            goto G857b;
        }
        goto f77pH;
        dr_yR:
        $Efimn = 0;
        goto M580t;
        VqSOf:
        Gi2wE:
        goto qued0;
        HcHat:
        B2JIe:
        goto boZS7;
        d756i:
        $OYJa8 = $BXJId / $this->iNHSn;
        goto H8AKh;
        H8AKh:
        $aHnXN = $this->NgSyp * $OYJa8;
        goto Fd3Oz;
        GDEjG:
        vs1kM:
        goto WIqJQ;
        boZS7:
        $BXJId = $zLlEU;
        goto d756i;
        inemT:
        $BXJId = 2;
        goto VqSOf;
        saqvl:
        $zLlEU = 1080;
        goto dr_yR;
        qued0:
        return ['width' => $Efimn, 'height' => $BXJId];
        goto zFZV_;
        M580t:
        $BXJId = 0;
        goto xUkkZ;
        xUkkZ:
        if ($this->NgSyp >= $this->iNHSn) {
            goto B2JIe;
        }
        goto nRum2;
        bCY3A:
        $JzCpu = $this->iNHSn * $OYJa8;
        goto jv7Qa;
        zFZV_:
    }
}
