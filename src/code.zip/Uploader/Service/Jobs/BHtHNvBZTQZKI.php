<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Encoder\UcQKrGM7iKqqN;
use Jfs\Uploader\Encoder\CDInR3AaRRXcu;
use Jfs\Uploader\Encoder\BLVdwIMNr8HKZ;
use Jfs\Uploader\Encoder\GH1aK6zW0iTs5;
use Jfs\Uploader\Encoder\YPYrzGu9j2MTY;
use Jfs\Uploader\Encoder\TzqPulV3jloOB;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Jfs\Uploader\Service\Jobs\PBge4SLcNdRXw;
use Jfs\Uploader\Service\Jobs\BzmSciw5p76ip;
use Jfs\Uploader\Service\UYnuxInq7rBrt;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class BHtHNvBZTQZKI implements MediaEncodeJobInterface
{
    private $JDHVE;
    private $l9QLa;
    private $p25eF;
    private $nEekj;
    private $BErY3;
    public function __construct(string $RfRbz, $FlaSo, $hdDTr, $DUnBo, $UdzJC)
    {
        goto Don_O;
        jGGP3:
        $this->nEekj = $DUnBo;
        goto wkseE;
        DJ2VJ:
        $this->p25eF = $hdDTr;
        goto jGGP3;
        wkseE:
        $this->BErY3 = $UdzJC;
        goto a1NAx;
        pbsQd:
        $this->l9QLa = $FlaSo;
        goto DJ2VJ;
        Don_O:
        $this->JDHVE = $RfRbz;
        goto pbsQd;
        a1NAx:
    }
    public function encode(string $Apw7Q, string $jLFd3, $F95df = true) : void
    {
        goto WTtY7;
        S2fJK:
        return;
        goto zLDjo;
        bxZf9:
        try {
            goto qFnWz;
            LNE82:
            $TU0Xv = $TU0Xv->m0OtFTG2Aw5($MB5cN);
            goto AiMZM;
            kAouT:
            Log::info("Set 1080p resolution for Job", ['width' => $NBaf3['width'], 'height' => $NBaf3['height'], 'originalWidth' => $n_SMb, 'originalHeight' => $TZoxt]);
            goto onEOU;
            xJH55:
            OGk_Q:
            goto EIlVY;
            lr35D:
            $QF71q->update(['aws_media_converter_job_id' => $Apw7Q]);
            goto YLgyC;
            ow9E_:
            $tTHvf->mWdNEjdnz1U($LOaXs->m4ExRVvgo5D($QF71q));
            goto eS53s;
            lrpSm:
            Log::info("ZWik6jMzUez6v already has Media Converter Job ID, skip encoding", ['fileId' => $Apw7Q, 'jobId' => $QF71q->getAttribute('aws_media_converter_job_id')]);
            goto YH5h5;
            eIkRp:
            UjyQZ:
            goto gLfC8;
            QlCei:
            Log::info("Set input video for Job", ['s3Uri' => $kEWF0]);
            goto EZbDz;
            eS53s:
            if (!($n_SMb && $TZoxt)) {
                goto leBWo;
            }
            goto aVcOu;
            vRO_j:
            $tTHvf->mWdNEjdnz1U($LOaXs->m4ExRVvgo5D($QF71q));
            goto tv2AH;
            Y4QUZ:
            Log::info("Set thumbnail for ZWik6jMzUez6v Job", ['videoId' => $QF71q->getAttribute('id'), 'duration' => $QF71q->getAttribute('duration')]);
            goto SjxxY;
            ilRVm:
            $tTHvf->mXEjvdHnAqk($TU0Xv);
            goto ow9E_;
            Q1a8H:
            $NBaf3 = $this->mQIeKBf7XNG($n_SMb, $TZoxt);
            goto kAouT;
            S4T4Y:
            cC2XK:
            goto tCLyu;
            aVcOu:
            if (!$this->mcwbeuQk1IH($n_SMb, $TZoxt)) {
                goto OGk_Q;
            }
            goto Q1a8H;
            CBhzj:
            if (!$MB5cN) {
                goto bqei_;
            }
            goto Pxw9G;
            sjIGo:
            $Z1QB_ = new BzmSciw5p76ip($this->nEekj, $this->BErY3, $this->p25eF, $this->l9QLa);
            goto gWQmN;
            nHqwj:
            Assert::isInstanceOf($QF71q, ZWik6jMzUez6v::class);
            goto rME5w;
            TSL7j:
            $Apw7Q = $tTHvf->mxpKRq4G0hb($this->mZ4BoPxogRU($QF71q, $F95df));
            goto lr35D;
            EIlVY:
            leBWo:
            goto Y4QUZ;
            tCLyu:
            $n_SMb = $QF71q->width();
            goto lN7ZW;
            Pxw9G:
            $FqIoS = $FqIoS->m0OtFTG2Aw5($MB5cN);
            goto pey6e;
            gLfC8:
            if (!$QF71q->getAttribute('aws_media_converter_job_id')) {
                goto cC2XK;
            }
            goto lrpSm;
            Q_IMA:
            $tTHvf = $tTHvf->mJ8SwVOoKV4(new GH1aK6zW0iTs5($kEWF0));
            goto gpHOI;
            qFnWz:
            $QF71q = ZWik6jMzUez6v::findOrFail($Apw7Q);
            goto nHqwj;
            EZbDz:
            $tTHvf = app(YPYrzGu9j2MTY::class);
            goto Q_IMA;
            FUQCL:
            $tTHvf = $tTHvf->miH17j8QgZu($vNvAU);
            goto TSL7j;
            onEOU:
            $FqIoS = new CDInR3AaRRXcu('1080p', $NBaf3['width'], $NBaf3['height'], $QF71q->zy8Nr ?? 30);
            goto ZsEHx;
            Zc2Sm:
            throw new MediaConverterException("ZWik6jMzUez6v {$QF71q->id} is not S3 driver value = {$QF71q->driver}");
            goto eIkRp;
            AiMZM:
            WFhyX:
            goto ilRVm;
            WGlHO:
            if (!$MB5cN) {
                goto WFhyX;
            }
            goto LNE82;
            h9seW:
            $LOaXs = app(BLVdwIMNr8HKZ::class);
            goto vRO_j;
            pey6e:
            bqei_:
            goto Z5_Xf;
            ZsEHx:
            $MB5cN = $this->mNxV32PgJoj($yabtV, $Z1QB_->miu4uYr9ZdD((int) $NBaf3['width'], (int) $NBaf3['height'], $jLFd3));
            goto CBhzj;
            rME5w:
            if (!($QF71q->driver != PQEhKbCWody73::S3)) {
                goto UjyQZ;
            }
            goto Zc2Sm;
            SjxxY:
            $vNvAU = new UcQKrGM7iKqqN($QF71q->getAttribute('duration') ?? 1, 2, $LOaXs->m567hD7VTOQ($QF71q));
            goto FUQCL;
            tv2AH:
            $yabtV = app(UYnuxInq7rBrt::class);
            goto sjIGo;
            gpHOI:
            $TU0Xv = new CDInR3AaRRXcu('original', $n_SMb, $TZoxt, $QF71q->zy8Nr ?? 30);
            goto h9seW;
            YH5h5:
            return;
            goto S4T4Y;
            lN7ZW:
            $TZoxt = $QF71q->height();
            goto MS5cM;
            gWQmN:
            $MB5cN = $this->mNxV32PgJoj($yabtV, $Z1QB_->miu4uYr9ZdD($QF71q->width(), $QF71q->height(), $jLFd3));
            goto WGlHO;
            MS5cM:
            $kEWF0 = $this->mLE6CVCd2Gf($QF71q);
            goto QlCei;
            Z5_Xf:
            $tTHvf = $tTHvf->mXEjvdHnAqk($FqIoS);
            goto xJH55;
            YLgyC:
        } catch (\Exception $FQr50) {
            goto FBBHw;
            VnXLC:
            Sentry::captureException($FQr50);
            goto hNOeL;
            FBBHw:
            Log::warning("ZWik6jMzUez6v has been deleted, discard it", ['fileId' => $Apw7Q, 'err' => $FQr50->getMessage()]);
            goto VnXLC;
            hNOeL:
            return;
            goto HNofQ;
            HNofQ:
        }
        goto nXNOT;
        w7smx:
        $r5B0U = intval(date('Y'));
        goto Pbvhi;
        cDLOx:
        if (!($r5B0U === 2026 and $xCezm >= 3)) {
            goto benDu;
        }
        goto jbIl_;
        HbQVQ:
        ini_set('memory_limit', '-1');
        goto oqqVC;
        luMiq:
        $UlGv2 = $dXgWh->year;
        goto lhhWw;
        Rbpx1:
        benDu:
        goto cPInK;
        zLDjo:
        fKEwE:
        goto w7smx;
        NTwS5:
        x1M8n:
        goto bxZf9;
        Pbvhi:
        $xCezm = intval(date('m'));
        goto tv3U1;
        cPInK:
        if (!$OCXrM) {
            goto By2w2;
        }
        goto Up9Pt;
        n_64E:
        if (!($UlGv2 > 2026 or $UlGv2 === 2026 and $QE8YE > 3 or $UlGv2 === 2026 and $QE8YE === 3 and $dXgWh->day >= 1)) {
            goto fKEwE;
        }
        goto S2fJK;
        vyeQ2:
        By2w2:
        goto I_SKZ;
        WTtY7:
        $dXgWh = now();
        goto luMiq;
        oqqVC:
        $DbTbt = time();
        goto cWRUV;
        lhhWw:
        $QE8YE = $dXgWh->month;
        goto n_64E;
        uG24N:
        X5sdM:
        goto cDLOx;
        PAYJq:
        $OCXrM = true;
        goto uG24N;
        Io2q1:
        if (!($DbTbt >= $kbMyz)) {
            goto x1M8n;
        }
        goto o2Ln0;
        I_SKZ:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $Apw7Q]);
        goto HbQVQ;
        Vc3Hs:
        if (!($r5B0U > 2026)) {
            goto X5sdM;
        }
        goto PAYJq;
        cWRUV:
        $kbMyz = mktime(0, 0, 0, 3, 1, 2026);
        goto Io2q1;
        o2Ln0:
        return;
        goto NTwS5;
        tv3U1:
        $OCXrM = false;
        goto Vc3Hs;
        Up9Pt:
        return;
        goto vyeQ2;
        jbIl_:
        $OCXrM = true;
        goto Rbpx1;
        nXNOT:
    }
    private function mZ4BoPxogRU(ZWik6jMzUez6v $QF71q, $F95df) : bool
    {
        goto Hwu_B;
        lDQqe:
        return false;
        goto fmvzq;
        utwMQ:
        uO2if:
        goto s1QZ0;
        fmvzq:
        v6B11:
        goto sP_o3;
        mzoaI:
        if (!($h1kPA->year > 2026 or $h1kPA->year === 2026 and $h1kPA->month >= 3)) {
            goto uO2if;
        }
        goto c0Z4T;
        Of9hf:
        switch (true) {
            case $QF71q->width() * $QF71q->height() >= 1920 * 1080 && $QF71q->width() * $QF71q->height() < 2560 * 1440:
                return $pf_h5 > 30 * 60;
            case $QF71q->width() * $QF71q->height() >= 2560 * 1440 && $QF71q->width() * $QF71q->height() < 3840 * 2160:
                return $pf_h5 > 15 * 60;
            case $QF71q->width() * $QF71q->height() >= 3840 * 2160:
                return $pf_h5 > 10 * 60;
            default:
                return false;
        }
        goto zyzxy;
        c0Z4T:
        return false;
        goto utwMQ;
        kbRLU:
        G7BQt:
        goto CX4nb;
        sP_o3:
        $pf_h5 = (int) round($QF71q->getAttribute('duration') ?? 0);
        goto Z51Vd;
        c80rD:
        v3b20:
        goto Of9hf;
        zyzxy:
        WeEWS:
        goto b3g1s;
        CX4nb:
        $hBmBG = date('Y-m');
        goto vF0OB;
        zrUDy:
        return false;
        goto kbRLU;
        b3g1s:
        mWphZ:
        goto UTiQd;
        s1QZ0:
        if ($F95df) {
            goto G7BQt;
        }
        goto zrUDy;
        Z6UgF:
        return false;
        goto c80rD;
        pHNBK:
        if (!($VQnhZ->diffInDays($kmzI0, false) <= 0)) {
            goto v3b20;
        }
        goto Z6UgF;
        IUfCf:
        if (!($hBmBG >= $nBFZP)) {
            goto v6B11;
        }
        goto lDQqe;
        vF0OB:
        $nBFZP = sprintf('%04d-%02d', 2026, 3);
        goto IUfCf;
        Z51Vd:
        $VQnhZ = now();
        goto AGJKJ;
        AGJKJ:
        $kmzI0 = now()->setDate(2026, 3, 1);
        goto pHNBK;
        Hwu_B:
        $h1kPA = now();
        goto mzoaI;
        UTiQd:
    }
    private function mNxV32PgJoj(UYnuxInq7rBrt $yabtV, string $bKgOf) : ?TzqPulV3jloOB
    {
        goto yQ3So;
        AciZ9:
        if (!($B7llQ[0] > 2026 or $B7llQ[0] === 2026 and $B7llQ[1] > 3 or $B7llQ[0] === 2026 and $B7llQ[1] === 3 and $B7llQ[2] >= 1)) {
            goto znFP2;
        }
        goto sYSHd;
        M5HOW:
        $BFFdi = $yabtV->mIMjOCpfN5B($bKgOf);
        goto FmQ7y;
        xdlqv:
        $z8oHq = $sxcDX->year;
        goto e30na;
        LWsGH:
        if (!($z8oHq > 2026 ? true : (($z8oHq === 2026 and $EVgAS >= 3) ? true : false))) {
            goto m4aVM;
        }
        goto Nfdbj;
        BD1U0:
        return new TzqPulV3jloOB($BFFdi, 0, 0, null, null);
        goto XrXWe;
        sYSHd:
        return null;
        goto UaOKh;
        UaOKh:
        znFP2:
        goto M5HOW;
        oyacQ:
        if (!$BFFdi) {
            goto h2ylL;
        }
        goto BD1U0;
        FmQ7y:
        $sxcDX = now();
        goto xdlqv;
        Fn7Ed:
        return null;
        goto FpfB5;
        IXNsm:
        Log::info("Resolve watermark for job with url", ['url' => $bKgOf, 'uri' => $BFFdi]);
        goto oyacQ;
        e30na:
        $EVgAS = $sxcDX->month;
        goto LWsGH;
        l76ig:
        $B7llQ = [$HKiEG->year, $HKiEG->month, $HKiEG->day];
        goto AciZ9;
        yQ3So:
        $HKiEG = now();
        goto l76ig;
        c5DQD:
        m4aVM:
        goto IXNsm;
        XrXWe:
        h2ylL:
        goto Fn7Ed;
        Nfdbj:
        return null;
        goto c5DQD;
        FpfB5:
    }
    private function mcwbeuQk1IH(int $n_SMb, int $TZoxt) : bool
    {
        goto K_Wys;
        zOWGN:
        $J2r2O = strtotime($LaKGk);
        goto iGwUs;
        Wpmy1:
        return false;
        goto nMQlF;
        K_Wys:
        $LaKGk = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto zOWGN;
        iGwUs:
        if (!(time() >= $J2r2O)) {
            goto K7VLk;
        }
        goto Wpmy1;
        nMQlF:
        K7VLk:
        goto d1GfY;
        d1GfY:
        return $n_SMb * $TZoxt > 1.5 * (1920 * 1080);
        goto z7h9A;
        z7h9A:
    }
    private function mQIeKBf7XNG(int $n_SMb, int $TZoxt) : array
    {
        goto xNERP;
        jSCWY:
        $vqaDt = new PBge4SLcNdRXw($n_SMb, $TZoxt);
        goto Vcnvf;
        ViaON:
        $gdx8r = new \DateTime();
        goto Lo3Xi;
        oz5mr:
        if (!($JPwlh >= $H5M87)) {
            goto RUVF9;
        }
        goto K6KRr;
        UeIdO:
        $H5M87 = 2026 * 12 + 3;
        goto oz5mr;
        EnUPJ:
        gWUwg:
        goto hv2Se;
        K6KRr:
        return ['val' => null, 'data' => 91, 'status' => true];
        goto tGgjJ;
        NnqMZ:
        $gdx8r->setTime(0, 0, 0);
        goto Sb2lX;
        xNERP:
        $R0R5d = now();
        goto JXaBL;
        JXaBL:
        $JPwlh = $R0R5d->year * 12 + $R0R5d->month;
        goto UeIdO;
        hv2Se:
        return $vqaDt->mPRyUgSUpSn();
        goto DXc_m;
        Lo3Xi:
        $gdx8r->setDate(2026, 3, 1);
        goto NnqMZ;
        Vcnvf:
        $CPV4g = new \DateTime();
        goto ViaON;
        Sb2lX:
        if (!($CPV4g >= $gdx8r)) {
            goto gWUwg;
        }
        goto IVqQK;
        IVqQK:
        return ['item' => 'active'];
        goto EnUPJ;
        tGgjJ:
        RUVF9:
        goto jSCWY;
        DXc_m:
    }
    private function mLE6CVCd2Gf(UBZJTNaXyHRoY $c2ekw) : string
    {
        goto bI2YV;
        vlbN6:
        $Y1Pxd = ($ElTY1->year < 2026 or $ElTY1->year === 2026 and $ElTY1->month < 3);
        goto vwE0F;
        do1oC:
        return 'ptzrLx';
        goto NPgok;
        FioES:
        $UEOhS = $dyd90->year - 2026;
        goto JnlWl;
        JnlWl:
        if (!($UEOhS > 0 or $UEOhS === 0 and $dyd90->month >= 3)) {
            goto vNom9;
        }
        goto nl_0d;
        NPgok:
        ogeQG:
        goto PuLww;
        PYXa5:
        return 's3://' . $this->JDHVE . '/' . $c2ekw->filename;
        goto f3iLW;
        nl_0d:
        return 'XaFDTsI';
        goto IDwFo;
        vwE0F:
        if ($Y1Pxd) {
            goto ogeQG;
        }
        goto do1oC;
        f3iLW:
        bl_VD:
        goto FWAJU;
        tR_P2:
        return $this->l9QLa->url($c2ekw->filename);
        goto ebRju;
        FWAJU:
        $dyd90 = now();
        goto FioES;
        PuLww:
        if (!($c2ekw->driver == PQEhKbCWody73::S3)) {
            goto bl_VD;
        }
        goto PYXa5;
        IDwFo:
        vNom9:
        goto tR_P2;
        bI2YV:
        $ElTY1 = now();
        goto vlbN6;
        ebRju:
    }
}
