<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class V2CWIPB9W9uFI implements StoreToS3JobInterface
{
    private $j6_VZ;
    private $RE_2F;
    private $F8ilg;
    public function __construct($od_dm, $WmwnR, $Pkopf)
    {
        goto o4dgE;
        o4dgE:
        $this->RE_2F = $WmwnR;
        goto ZC0YX;
        ZC0YX:
        $this->F8ilg = $Pkopf;
        goto TKqIN;
        TKqIN:
        $this->j6_VZ = $od_dm;
        goto vCJ6O;
        vCJ6O:
    }
    public function store(string $LpGEK) : void
    {
        goto acRCj;
        EtDxQ:
        if (!$zmqC_->update(['driver' => EzGWviwQDmAwI::S3, 'status' => Tbw0jsMnRbOTP::FINISHED])) {
            goto rj28U;
        }
        goto dhd6E;
        Tg2PF:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $LpGEK]);
        goto pmyEG;
        gqPlN:
        $yGhrF = $this->F8ilg->path($EAABo);
        goto fBVuk;
        Eqn8X:
        vrAjW:
        goto bHtNR;
        VTSdQ:
        lPV2w:
        goto EtDxQ;
        TFyn3:
        $XC0PR = $this->F8ilg->path($zmqC_->getAttribute('preview'));
        goto Uzkby;
        FGjBy:
        $EAABo = $zmqC_->getAttribute('thumbnail');
        goto miBct;
        dhd6E:
        Log::info("X9YHjKrAdcfhe stored to S3, update the children attachments", ['fileId' => $LpGEK]);
        goto uwDv_;
        NWo5R:
        $AvgzF = $this->F8ilg->path($zmqC_->getLocation());
        goto aBSyB;
        O9_7b:
        Log::info("X9YHjKrAdcfhe has been deleted, discard it", ['fileId' => $LpGEK]);
        goto oHbO4;
        bHtNR:
        if (!($zmqC_->getAttribute('preview') && $this->F8ilg->exists($zmqC_->getAttribute('preview')))) {
            goto lPV2w;
        }
        goto TFyn3;
        uwDv_:
        X9YHjKrAdcfhe::where('parent_id', $LpGEK)->update(['driver' => EzGWviwQDmAwI::S3, 'preview' => $zmqC_->getAttribute('preview'), 'thumbnail' => $zmqC_->getAttribute('thumbnail')]);
        goto t_tY2;
        Uzkby:
        $kKuyN = $this->j6_VZ->call($this, $XC0PR);
        goto WgIPd;
        KaadI:
        rj28U:
        goto Tg2PF;
        vKdJN:
        LumBK:
        goto NWo5R;
        ss7Lr:
        $this->RE_2F->put($zmqC_->getAttribute('thumbnail'), $this->F8ilg->get($EAABo), ['visibility' => 'public', 'ContentType' => $saBWi->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Eqn8X;
        WgIPd:
        $this->RE_2F->put($zmqC_->getAttribute('preview'), $this->F8ilg->get($zmqC_->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $kKuyN->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto VTSdQ;
        fBVuk:
        $saBWi = $this->j6_VZ->call($this, $yGhrF);
        goto ss7Lr;
        acRCj:
        $zmqC_ = X9YHjKrAdcfhe::findOrFail($LpGEK);
        goto PCqb2;
        miBct:
        if (!($EAABo && $this->F8ilg->exists($EAABo))) {
            goto vrAjW;
        }
        goto gqPlN;
        PCqb2:
        if ($zmqC_) {
            goto LumBK;
        }
        goto O9_7b;
        oHbO4:
        return;
        goto vKdJN;
        aBSyB:
        $this->mQzD3w7a5SV($AvgzF, $zmqC_->getLocation());
        goto FGjBy;
        t_tY2:
        return;
        goto KaadI;
        pmyEG:
    }
    private function mQzD3w7a5SV($xLUrd, $db3L4, $n6wQU = '')
    {
        goto uBBnR;
        R_153:
        $db3L4 = str_replace('.jpg', $n6wQU, $db3L4);
        goto n_PEk;
        J4mex:
        try {
            $ZQQzW = $this->j6_VZ->call($this, $xLUrd);
            $this->RE_2F->put($db3L4, $this->F8ilg->get($db3L4), ['visibility' => 'public', 'ContentType' => $ZQQzW->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $AUVE0) {
            Log::error("Failed to upload image to S3", ['s3Path' => $db3L4, 'error' => $AUVE0->getMessage()]);
        }
        goto EuAEi;
        n_PEk:
        wtqBR:
        goto J4mex;
        dEiTw:
        $xLUrd = str_replace('.jpg', $n6wQU, $xLUrd);
        goto R_153;
        uBBnR:
        if (!$n6wQU) {
            goto wtqBR;
        }
        goto dEiTw;
        EuAEi:
    }
}
