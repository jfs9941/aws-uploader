<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class WF4mDTL139IMZ implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $IaHim) : void
    {
        goto s3Ies;
        CLtA9:
        $this->moiMYdY73av($vd5JT);
        goto CsRfn;
        s3Ies:
        $vd5JT = ACdpgX4YCYP6M::findOrFail($IaHim);
        goto iOswa;
        iOswa:
        if ($vd5JT->width() > 0 && $vd5JT->height() > 0) {
            goto GVjKd;
        }
        goto CLtA9;
        CsRfn:
        GVjKd:
        goto CZwHi;
        CZwHi:
    }
    private function moiMYdY73av(ACdpgX4YCYP6M $qW6LM) : void
    {
        goto Ui5rf;
        cj5GT:
        $at_5d = $UWZG3->getVideoStream();
        goto KPWn1;
        TPebZ:
        $qW6LM->update(['duration' => $UWZG3->getDurationInSeconds(), 'resolution' => $s0lIM->getWidth() . 'x' . $s0lIM->getHeight(), 'fps' => $at_5d->get('r_frame_rate') ?? 30]);
        goto C5IaI;
        mWrPn:
        $UWZG3 = FFMpeg::fromDisk($IjqxX['path'])->open($qW6LM->getAttribute('filename'));
        goto cj5GT;
        KPWn1:
        $s0lIM = $at_5d->getDimensions();
        goto TPebZ;
        Ui5rf:
        $IjqxX = $qW6LM->getView();
        goto mWrPn;
        C5IaI:
    }
}
