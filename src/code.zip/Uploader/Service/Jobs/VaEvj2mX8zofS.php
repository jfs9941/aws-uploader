<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class VaEvj2mX8zofS implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $aK0gt) : void
    {
        goto O8cET;
        MS4EI:
        zyiE7:
        goto ugy82;
        O8cET:
        $dajVn = IfBHv1AJhiIDu::findOrFail($aK0gt);
        goto RpvNd;
        tkT0C:
        $this->mx6eSnEpK4R($dajVn);
        goto MS4EI;
        RpvNd:
        if ($dajVn->width() > 0 && $dajVn->height() > 0) {
            goto zyiE7;
        }
        goto tkT0C;
        ugy82:
    }
    private function mx6eSnEpK4R(IfBHv1AJhiIDu $ZygbT) : void
    {
        goto SZQ0U;
        LkWw4:
        $SmLAm = FFMpeg::fromDisk($hdfBo['path'])->open($ZygbT->getAttribute('filename'));
        goto O7L2j;
        cODlS:
        $eRlfC = $eou8Z->getDimensions();
        goto nnoBr;
        nnoBr:
        $ZygbT->update(['duration' => $SmLAm->getDurationInSeconds(), 'resolution' => $eRlfC->getWidth() . 'x' . $eRlfC->getHeight(), 'fps' => $eou8Z->get('r_frame_rate') ?? 30]);
        goto VMrQE;
        SZQ0U:
        $hdfBo = $ZygbT->getView();
        goto LkWw4;
        O7L2j:
        $eou8Z = $SmLAm->getVideoStream();
        goto cODlS;
        VMrQE:
    }
}
