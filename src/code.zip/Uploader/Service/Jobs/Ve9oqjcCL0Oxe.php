<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Ve9oqjcCL0Oxe implements GenerateThumbnailForVideoInterface
{
    private $u3Z0R;
    public function __construct($vl9tn)
    {
        $this->u3Z0R = $vl9tn;
    }
    public function generate(string $LpGEK) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $LpGEK);
        $this->u3Z0R->createThumbnail($LpGEK);
    }
}
