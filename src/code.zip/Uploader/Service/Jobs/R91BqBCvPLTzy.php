<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
class R91BqBCvPLTzy implements BlurJobInterface
{
    const jjY4c = 15;
    const iKWl8 = 500;
    const MpRAp = 500;
    private $G25L6;
    private $VV2A8;
    private $QbAvB;
    public function __construct($G6zg7, $oOPBt, $UNh9U)
    {
        goto UXvMb;
        vDJvb:
        $this->VV2A8 = $oOPBt;
        goto bYulO;
        bYulO:
        $this->G25L6 = $G6zg7;
        goto EmHIz;
        UXvMb:
        $this->QbAvB = $UNh9U;
        goto vDJvb;
        EmHIz:
    }
    public function blur(string $GhyxD) : void
    {
        goto sVGoV;
        fiVsO:
        $oaIJp->blur(self::jjY4c);
        goto Ib3wC;
        RjkHa:
        throw new \Exception('Failed to set final permissions on image file: ' . $QQZ5O);
        goto bbolK;
        sVGoV:
        $PwAVf = IZ5shp3JHuftD::findOrFail($GhyxD);
        goto PW5H8;
        jzYLx:
        $CN01m = $this->VV2A8->get($PwAVf->filename);
        goto c1l3n;
        UDp25:
        $oaIJp = $this->G25L6->call($this, $this->QbAvB->path($PwAVf->getLocation()));
        goto BoE24;
        yZOvG:
        $PwAVf->update(['preview' => $J1ZcC]);
        goto biSVe;
        Ib3wC:
        $J1ZcC = $this->m2MRGCZbu4Y($PwAVf);
        goto JKeLk;
        zEmQD:
        unset($oaIJp);
        goto caqgr;
        iL8bc:
        KjV4q:
        goto UDp25;
        Xjw5o:
        $oaIJp->resize(self::iKWl8, self::MpRAp / $huvyP);
        goto fiVsO;
        BoE24:
        $huvyP = $oaIJp->width() / $oaIJp->height();
        goto Xjw5o;
        GJIci:
        \Log::warning('Failed to set final permissions on image file: ' . $QQZ5O);
        goto RjkHa;
        bbolK:
        ujL_V:
        goto yZOvG;
        c1l3n:
        $this->QbAvB->put($PwAVf->filename, $CN01m);
        goto iL8bc;
        lgA2J:
        if (!($PwAVf->G8msK == GoWVLKcTGnffy::S3 && !$this->QbAvB->exists($PwAVf->filename))) {
            goto KjV4q;
        }
        goto jzYLx;
        caqgr:
        if (chmod($QQZ5O, 0664)) {
            goto ujL_V;
        }
        goto GJIci;
        JKeLk:
        $QQZ5O = $this->VV2A8->put($J1ZcC, $oaIJp->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto zEmQD;
        PW5H8:
        ini_set('memory_limit', '-1');
        goto lgA2J;
        biSVe:
    }
    private function m2MRGCZbu4Y($dkWnY) : string
    {
        goto qB1yk;
        dzkKU:
        return $LZqCF . $dkWnY->getFilename() . '.jpg';
        goto bplKp;
        hO_k3:
        $this->QbAvB->makeDirectory($LZqCF, 0755, true);
        goto kDetv;
        qB1yk:
        $yRiLu = $dkWnY->getLocation();
        goto LzKpK;
        kDetv:
        ayHdp:
        goto dzkKU;
        LzKpK:
        $LZqCF = dirname($yRiLu) . '/preview/';
        goto HC18P;
        HC18P:
        if ($this->QbAvB->exists($LZqCF)) {
            goto ayHdp;
        }
        goto hO_k3;
        bplKp:
    }
}
