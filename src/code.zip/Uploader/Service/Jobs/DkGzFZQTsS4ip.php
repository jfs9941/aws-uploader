<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DkGzFZQTsS4ip implements GenerateThumbnailJobInterface
{
    const iKWl8 = 150;
    const MpRAp = 150;
    private $G25L6;
    private $QbAvB;
    private $hik1u;
    public function __construct($G6zg7, $UNh9U, $d7hWY)
    {
        goto r4vAQ;
        K7WWO:
        $this->hik1u = $d7hWY;
        goto ZTeLt;
        c2WzW:
        $this->QbAvB = $UNh9U;
        goto K7WWO;
        r4vAQ:
        $this->G25L6 = $G6zg7;
        goto c2WzW;
        ZTeLt:
    }
    public function generate(string $GhyxD)
    {
        goto yy7mm;
        n7iRR:
        try {
            goto mFptT;
            mFptT:
            $xuow1 = $this->QbAvB;
            goto pMSwm;
            T6MP6:
            $VQiq1 = $this->hik1u->put($yRiLu, $X7TWH->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto p8oJx;
            k7vKl:
            $X7TWH = $this->G25L6->call($this, $xuow1->path($oaIJp->getLocation()));
            goto e1Kxw;
            JM3Su:
            jQRDB:
            goto D10a0;
            e1Kxw:
            $X7TWH->orient()->resize(150, 150);
            goto qOMky;
            pMSwm:
            $oaIJp = IZ5shp3JHuftD::findOrFail($GhyxD);
            goto k7vKl;
            p8oJx:
            unset($X7TWH);
            goto rWoqh;
            qOMky:
            $yRiLu = $this->m2MRGCZbu4Y($oaIJp);
            goto T6MP6;
            hwnHa:
            $oaIJp->update(['thumbnail' => $yRiLu, 'status' => LlMDscQw21XKp::THUMBNAIL_PROCESSED]);
            goto JM3Su;
            rWoqh:
            if (!($VQiq1 !== false)) {
                goto jQRDB;
            }
            goto hwnHa;
            D10a0:
        } catch (ModelNotFoundException $w7Va8) {
            Log::info("IZ5shp3JHuftD has been deleted, discard it", ['imageId' => $GhyxD]);
            return;
        } catch (\Exception $w7Va8) {
            Log::error("Failed to generate thumbnail", ['imageId' => $GhyxD, 'error' => $w7Va8->getMessage()]);
        }
        goto BgT21;
        yy7mm:
        Log::info("Generating thumbnail", ['imageId' => $GhyxD]);
        goto OYnCE;
        OYnCE:
        ini_set('memory_limit', '-1');
        goto n7iRR;
        BgT21:
    }
    private function m2MRGCZbu4Y(OXsaQ69LP2fiA $oaIJp) : string
    {
        goto S9jbS;
        UNq5F:
        return $pZ3S1 . '/' . $oaIJp->getFilename() . '.jpg';
        goto TONZi;
        cz3as:
        $pZ3S1 = $LZqCF . '/' . self::iKWl8 . 'X' . self::MpRAp;
        goto UNq5F;
        S9jbS:
        $yRiLu = $oaIJp->getLocation();
        goto NTELy;
        NTELy:
        $LZqCF = dirname($yRiLu);
        goto cz3as;
        TONZi:
    }
}
