<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class NPsTgHFUCWkD2 implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $hOWbX) : void
    {
        goto HBAfE;
        HBAfE:
        $ZtI9P = HS7SZ3rYPI80t::findOrFail($hOWbX);
        goto UaJFQ;
        UaJFQ:
        if ($ZtI9P->width() > 0 && $ZtI9P->height() > 0) {
            goto CIpE8;
        }
        goto JnUBP;
        Js_gX:
        CIpE8:
        goto UL4sa;
        JnUBP:
        $this->mc4nt587B1O($ZtI9P);
        goto Js_gX;
        UL4sa:
    }
    private function mc4nt587B1O(HS7SZ3rYPI80t $s86ub) : void
    {
        goto VWtLS;
        ixF1d:
        $jM7kB = $vZTGR->getDimensions();
        goto FKAUR;
        VWtLS:
        $tu0Up = $s86ub->getAttribute('driver') === 1 ? 's3' : 'public';
        goto bqdw1;
        u7Kh1:
        $vZTGR = $WtNuf->getVideoStream();
        goto ixF1d;
        bqdw1:
        $WtNuf = FFMpeg::fromDisk($tu0Up)->open($s86ub->getAttribute('filename'));
        goto u7Kh1;
        FKAUR:
        $s86ub->update(['duration' => $WtNuf->getDurationInSeconds(), 'resolution' => $jM7kB->getWidth() . 'x' . $jM7kB->getHeight(), 'fps' => $vZTGR->get('r_frame_rate') ?? 30]);
        goto VXHvJ;
        VXHvJ:
    }
}
