<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class Y4j6zBUZX19T7 implements StoreToS3JobInterface
{
    private $K9RVo;
    private $qrvF0;
    private $ERIyl;
    public function __construct($Venjl, $eG_Pc, $nL6dR)
    {
        goto fvsxb;
        fvsxb:
        $this->qrvF0 = $eG_Pc;
        goto BOcer;
        BOcer:
        $this->ERIyl = $nL6dR;
        goto e65bO;
        e65bO:
        $this->K9RVo = $Venjl;
        goto e_Ao3;
        e_Ao3:
    }
    public function store(string $ElvKF) : void
    {
        goto CF2vP;
        lHSUe:
        d0Zq1:
        goto iEwhT;
        NhQ3T:
        return;
        goto su4Xo;
        yR87I:
        $LNc0i = $this->ERIyl->path($D7whq);
        goto ddw70;
        ddw70:
        $I_Zk6 = $this->K9RVo->call($this, $LNc0i);
        goto bhFU6;
        J_gG7:
        if (!($cdk3_->getAttribute('preview') && $this->ERIyl->exists($cdk3_->getAttribute('preview')))) {
            goto d0Zq1;
        }
        goto H6AuB;
        vp3nT:
        $this->qrvF0->put($cdk3_->getAttribute('preview'), $wR6RA->stream(), ['visibility' => 'public', 'ContentType' => $wR6RA->mime(), 'ContentDisposition' => 'inline']);
        goto lHSUe;
        FlMC6:
        $wR6RA = $this->K9RVo->call($this, $Q60Mb);
        goto vp3nT;
        bhFU6:
        $this->qrvF0->put($cdk3_->getAttribute('thumbnail'), $I_Zk6->stream(), ['visibility' => 'public', 'ContentType' => $I_Zk6->mime(), 'ContentDisposition' => 'inline']);
        goto JYde2;
        CF2vP:
        $cdk3_ = WKX0l52zWptlF::findOrFail($ElvKF);
        goto ZvS1u;
        tcH46:
        $this->qrvF0->put($cdk3_->getLocation(), $anrPh->stream(), ['visibility' => 'public', 'ContentType' => $anrPh->mime(), 'ContentDisposition' => 'inline']);
        goto EJF80;
        TGKkU:
        WKX0l52zWptlF::where('parent_id', $ElvKF)->update(['driver' => I2Tze5VZcqaXS::S3, 'preview' => $cdk3_->getAttribute('preview'), 'thumbnail' => $cdk3_->getAttribute('thumbnail')]);
        goto lLeZB;
        lLeZB:
        return;
        goto Yj51O;
        rjf71:
        $anrPh = $this->K9RVo->call($this, $lmCO9);
        goto tcH46;
        H6AuB:
        $Q60Mb = $this->ERIyl->path($cdk3_->getAttribute('preview'));
        goto FlMC6;
        EJF80:
        $D7whq = $cdk3_->getAttribute('thumbnail');
        goto ck6LR;
        thVhG:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $ElvKF]);
        goto Ns0L1;
        JYde2:
        l4ZTG:
        goto J_gG7;
        eR9Ej:
        Log::info("WKX0l52zWptlF stored to S3, update the children attachments", ['fileId' => $ElvKF]);
        goto TGKkU;
        r7cYH:
        Log::info("WKX0l52zWptlF has been deleted, discard it", ['fileId' => $ElvKF]);
        goto NhQ3T;
        su4Xo:
        Ub7hl:
        goto rhtDP;
        iEwhT:
        if (!$cdk3_->update(['driver' => I2Tze5VZcqaXS::S3, 'status' => Q5pXt73hTeTVP::FINISHED])) {
            goto l89sZ;
        }
        goto eR9Ej;
        ZvS1u:
        if ($cdk3_) {
            goto Ub7hl;
        }
        goto r7cYH;
        Yj51O:
        l89sZ:
        goto thVhG;
        ck6LR:
        if (!($D7whq && $this->ERIyl->exists($D7whq))) {
            goto l4ZTG;
        }
        goto yR87I;
        rhtDP:
        $lmCO9 = $this->ERIyl->path($cdk3_->getLocation());
        goto rjf71;
        Ns0L1:
    }
}
