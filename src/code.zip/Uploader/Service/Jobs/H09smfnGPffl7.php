<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class H09smfnGPffl7
{
    private $ScRnx;
    private $Daa3m;
    private $uiTOc;
    private $W2Sfl;
    public function __construct($tUc4C, $gQHhb, $ATeSz, $d_Wiu)
    {
        goto l3L0q;
        YoFNc:
        $this->ScRnx = $tUc4C;
        goto QjziK;
        KasQo:
        $this->uiTOc = $ATeSz;
        goto dtTJj;
        l3L0q:
        $this->Daa3m = $gQHhb;
        goto KasQo;
        dtTJj:
        $this->W2Sfl = $d_Wiu;
        goto YoFNc;
        QjziK:
    }
    public function mR2ojYBGTKb(?int $BKFYC, ?int $ZDe2g, string $i4v7Y, bool $qcD_m = false) : string
    {
        goto UuY66;
        NOFAe:
        r8wsE:
        goto GMI9j;
        GMI9j:
        $SiEYP = $ZDe2g - $k9Awk - 10;
        goto Pj74c;
        Pj74c:
        $zCabx->text($bik6P, $IcSNC, (int) $SiEYP, function ($LqODv) use($k9Awk) {
            goto IlQal;
            CHZH8:
            $LqODv->size(max($p4hia, 1));
            goto aUUFB;
            y8FjZ:
            $LqODv->valign('middle');
            goto N39Qm;
            pgno7:
            $p4hia = (int) ($k9Awk * 1.2);
            goto CHZH8;
            N39Qm:
            $LqODv->align('middle');
            goto GtPHC;
            IlQal:
            $LqODv->file(public_path($this->Daa3m));
            goto pgno7;
            aUUFB:
            $LqODv->color([185, 185, 185, 1]);
            goto y8FjZ;
            GtPHC:
        });
        goto IFdR5;
        HQmkq:
        $this->uiTOc->put($dTJxl, $zCabx->stream('png'));
        goto GgDFh;
        Zbxkg:
        return $qcD_m ? $dTJxl : $this->uiTOc->url($dTJxl);
        goto jIk58;
        k2VFG:
        if (!$this->uiTOc->exists($dTJxl)) {
            goto WJxF_;
        }
        goto Zbxkg;
        jIk58:
        WJxF_:
        goto OEtMV;
        iIjRV:
        $IcSNC -= $gFekB;
        goto d6iD1;
        GgDFh:
        return $qcD_m ? $dTJxl : $this->uiTOc->url($dTJxl);
        goto ihXoX;
        OEtMV:
        $zCabx = $this->ScRnx->call($this, $BKFYC, $ZDe2g);
        goto L2bUS;
        IFdR5:
        $this->W2Sfl->put($dTJxl, $zCabx->stream('png'));
        goto HQmkq;
        H_GMs:
        $OT0tJ = 0.1;
        goto YN1iB;
        PX43d:
        $gFekB = (int) ($IcSNC / 80);
        goto iIjRV;
        b2nIa:
        $dTJxl = $this->mydeIHLR6UC($bik6P, $BKFYC, $ZDe2g, $BWF0k, $k9Awk);
        goto k2VFG;
        d6iD1:
        if (!($BKFYC > 1500)) {
            goto r8wsE;
        }
        goto KtFMU;
        UuY66:
        if (!($BKFYC === null || $ZDe2g === null)) {
            goto mx2jm;
        }
        goto dMhzQ;
        KtFMU:
        $IcSNC -= $gFekB * 0.4;
        goto NOFAe;
        YN1iB:
        list($k9Awk, $BWF0k, $bik6P) = $this->mqvnWTgVXVo($i4v7Y, $BKFYC, $OT0tJ, (float) $BKFYC / $ZDe2g);
        goto b2nIa;
        jtuor:
        mx2jm:
        goto H_GMs;
        dMhzQ:
        throw new \RuntimeException("U9HMl0N8dP0ZH dimensions are not available.");
        goto jtuor;
        L2bUS:
        $IcSNC = $BKFYC - $BWF0k;
        goto PX43d;
        ihXoX:
    }
    private function mydeIHLR6UC(string $i4v7Y, int $BKFYC, int $ZDe2g, int $YrWEw, int $o66Ow) : string
    {
        $RIn0E = ltrim($i4v7Y, '@');
        return "v2/watermark/{$RIn0E}/{$BKFYC}x{$ZDe2g}_{$YrWEw}x{$o66Ow}/text_watermark.png";
    }
    private function mqvnWTgVXVo($i4v7Y, int $BKFYC, float $ZVTz3, float $j3ttF) : array
    {
        goto VkeCy;
        tn4k9:
        $nuMYg = 1 / $j3ttF * $BWF0k / strlen($bik6P);
        goto Rh9qX;
        VkeCy:
        $bik6P = '@' . $i4v7Y;
        goto lkZWj;
        paJfB:
        if (!($j3ttF > 1)) {
            goto dsjAc;
        }
        goto LeQiY;
        Rh9qX:
        return [(int) $nuMYg, $BWF0k, $bik6P];
        goto q3OrC;
        lkZWj:
        $BWF0k = (int) ($BKFYC * $ZVTz3);
        goto paJfB;
        Aga3h:
        return [(int) $nuMYg, $nuMYg * strlen($bik6P) / 1.8, $bik6P];
        goto p1nc4;
        p1nc4:
        dsjAc:
        goto tn4k9;
        LeQiY:
        $nuMYg = $BWF0k / (strlen($bik6P) * 0.8);
        goto Aga3h;
        q3OrC:
    }
}
