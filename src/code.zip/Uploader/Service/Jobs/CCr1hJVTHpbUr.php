<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class CCr1hJVTHpbUr implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $poSkG) : void
    {
        goto LK_2B;
        T61iH:
        $this->maWSprsZDR1($qNHE7);
        goto yFEZt;
        yFEZt:
        rqSEU:
        goto EeJzC;
        UZ3Je:
        if ($qNHE7->width() > 0 && $qNHE7->height() > 0) {
            goto rqSEU;
        }
        goto T61iH;
        LK_2B:
        $qNHE7 = ISYJHQo8eqdfc::findOrFail($poSkG);
        goto UZ3Je;
        EeJzC:
    }
    private function maWSprsZDR1(ISYJHQo8eqdfc $xLiVA) : void
    {
        goto tTZW0;
        ivMQc:
        $Ghk9Q = $F251H->getVideoStream();
        goto hLP9M;
        aIP3e:
        $F251H = FFMpeg::fromDisk($IgxEE['path'])->open($xLiVA->getAttribute('filename'));
        goto ivMQc;
        hLP9M:
        $dmmEW = $Ghk9Q->getDimensions();
        goto kn2Vn;
        kn2Vn:
        $xLiVA->update(['duration' => $F251H->getDurationInSeconds(), 'resolution' => $dmmEW->getWidth() . 'x' . $dmmEW->getHeight(), 'fps' => $Ghk9Q->get('r_frame_rate') ?? 30]);
        goto TBYkk;
        tTZW0:
        $IgxEE = $xLiVA->getView();
        goto aIP3e;
        TBYkk:
    }
}
