<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class PbRgcyVVWzH3Y implements StoreToS3JobInterface
{
    private $z59AQ;
    private $W_Kti;
    private $kxBLk;
    public function __construct($fbqBq, $agzKA, $dgfeu)
    {
        goto dbPNh;
        tvXvy:
        $this->z59AQ = $fbqBq;
        goto TXc1M;
        bFsF3:
        $this->kxBLk = $dgfeu;
        goto tvXvy;
        dbPNh:
        $this->W_Kti = $agzKA;
        goto bFsF3;
        TXc1M:
    }
    public function store(string $y06DH) : void
    {
        goto GtNiB;
        tYf23:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $y06DH]);
        goto Rf9CG;
        MYsZi:
        $P2AJQ = $this->z59AQ->call($this, $IB9Pt);
        goto l0MEe;
        GtNiB:
        $KI3Rc = LGMw063tEE9ZC::findOrFail($y06DH);
        goto MldjN;
        MldjN:
        if ($KI3Rc) {
            goto ML2ij;
        }
        goto hY7TJ;
        Kstj4:
        gJIIz:
        goto tYf23;
        fX6I0:
        Zv3Yz:
        goto K1PjS;
        QwOFm:
        $JjBVs = $KI3Rc->getAttribute('thumbnail');
        goto FYPM3;
        m8kHU:
        $WE_A0 = $this->kxBLk->path($JjBVs);
        goto kkNRv;
        kkNRv:
        $qqIkT = $this->z59AQ->call($this, $WE_A0);
        goto vV21B;
        l6EEo:
        ML2ij:
        goto D9u1r;
        i_3gc:
        $oJEk8 = $this->kxBLk->path($KI3Rc->getAttribute('preview'));
        goto YMm1_;
        l0MEe:
        $this->W_Kti->put($KI3Rc->getLocation(), $P2AJQ->stream(), ['visibility' => 'public', 'ContentType' => $P2AJQ->mime(), 'ContentDisposition' => 'inline']);
        goto QwOFm;
        vV21B:
        $this->W_Kti->put($KI3Rc->getAttribute('thumbnail'), $qqIkT->stream(), ['visibility' => 'public', 'ContentType' => $qqIkT->mime(), 'ContentDisposition' => 'inline']);
        goto g8KZQ;
        FYPM3:
        if (!($JjBVs && $this->kxBLk->exists($JjBVs))) {
            goto QgsiT;
        }
        goto m8kHU;
        K1PjS:
        if (!$KI3Rc->update(['driver' => WG4kCv0INtCV4::S3, 'status' => RwOJkCXwa9RQz::FINISHED])) {
            goto gJIIz;
        }
        goto sidGb;
        hY7TJ:
        Log::info("LGMw063tEE9ZC has been deleted, discard it", ['fileId' => $y06DH]);
        goto D_qPH;
        sidGb:
        Log::info("LGMw063tEE9ZC stored to S3, update the children attachments", ['fileId' => $y06DH]);
        goto bJtxO;
        ZtY8d:
        if (!($KI3Rc->getAttribute('preview') && $this->kxBLk->exists($KI3Rc->getAttribute('preview')))) {
            goto Zv3Yz;
        }
        goto i_3gc;
        g8KZQ:
        QgsiT:
        goto ZtY8d;
        D_qPH:
        return;
        goto l6EEo;
        eZczC:
        $this->W_Kti->put($KI3Rc->getAttribute('preview'), $J0R7e->stream(), ['visibility' => 'public', 'ContentType' => $J0R7e->mime(), 'ContentDisposition' => 'inline']);
        goto fX6I0;
        WbXOC:
        return;
        goto Kstj4;
        D9u1r:
        $IB9Pt = $this->kxBLk->path($KI3Rc->getLocation());
        goto MYsZi;
        YMm1_:
        $J0R7e = $this->z59AQ->call($this, $oJEk8);
        goto eZczC;
        bJtxO:
        LGMw063tEE9ZC::where('parent_id', $y06DH)->update(['driver' => WG4kCv0INtCV4::S3, 'preview' => $KI3Rc->getAttribute('preview'), 'thumbnail' => $KI3Rc->getAttribute('thumbnail')]);
        goto WbXOC;
        Rf9CG:
    }
}
