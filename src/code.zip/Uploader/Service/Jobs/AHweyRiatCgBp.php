<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class AHweyRiatCgBp implements CompressJobInterface
{
    const xbIce = 60;
    private $M9duE;
    private $SPj0U;
    private $F3J1W;
    public function __construct($U2Jsh, $KUQsT, $Tl5V5)
    {
        goto Rw_pN;
        Rw_pN:
        $this->M9duE = $U2Jsh;
        goto AGZ7x;
        AGZ7x:
        $this->F3J1W = $Tl5V5;
        goto l9lSQ;
        l9lSQ:
        $this->SPj0U = $KUQsT;
        goto w59PR;
        w59PR:
    }
    public function compress(string $g5e_r)
    {
        goto qEOrH;
        ekDV7:
        $i4hys = memory_get_peak_usage();
        goto cwloF;
        tArwv:
        try {
            goto Q3fx1;
            kc4T8:
            $purdg = $this->SPj0U->path($MSkzT->getLocation());
            goto aSWLa;
            aSWLa:
            try {
                goto Em2wh;
                Qc9YZ:
                $this->mZyAvZSp4ac($MSkzT, 'webp');
                goto m_ZDf;
                sOZY1:
                $this->mLwlhgAa6Zg($purdg, $pMNZx);
                goto Qc9YZ;
                Em2wh:
                $pMNZx = str_replace(['.jpg', '.png', '.heic'], '.webp', $MSkzT->getLocation());
                goto sOZY1;
                m_ZDf:
            } catch (\Exception $X_03M) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $g5e_r, 'error' => $X_03M->getMessage()]);
                try {
                    goto wCfWT;
                    wCfWT:
                    $pMNZx = str_replace(['.jpg', '.png', '.heic'], '.jpg', $MSkzT->getLocation());
                    goto VIKDX;
                    VIKDX:
                    $this->mICSiyAyZUP($purdg, $pMNZx);
                    goto T7SEZ;
                    T7SEZ:
                    $this->mZyAvZSp4ac($MSkzT, 'jpg');
                    goto hUnTJ;
                    hUnTJ:
                } catch (\Exception $X_03M) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $g5e_r, 'error' => $X_03M->getMessage()]);
                }
            }
            goto tZSQy;
            Q3fx1:
            $MSkzT = XqAJHKYeaW2YU::findOrFail($g5e_r);
            goto kc4T8;
            tZSQy:
        } catch (\Throwable $X_03M) {
            goto CCaWI;
            CCaWI:
            if (!$X_03M instanceof ModelNotFoundException) {
                goto WoFee;
            }
            goto B9c58;
            TgCIA:
            Log::error("Failed to compress image", ['imageId' => $g5e_r, 'error' => $X_03M->getMessage()]);
            goto qhEkL;
            B9c58:
            Log::info("XqAJHKYeaW2YU has been deleted, discard it", ['imageId' => $g5e_r]);
            goto nxWf2;
            iYusF:
            WoFee:
            goto TgCIA;
            nxWf2:
            return;
            goto iYusF;
            qhEkL:
        } finally {
            $nQGPQ = microtime(true);
            $E4uJa = memory_get_usage();
            $Q2gUW = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $g5e_r, 'execution_time_sec' => $nQGPQ - $DbNb5, 'memory_usage_mb' => ($E4uJa - $kVF0z) / 1024 / 1024, 'peak_memory_usage_mb' => ($Q2gUW - $i4hys) / 1024 / 1024]);
        }
        goto u7G01;
        cwloF:
        Log::info("Compress image", ['imageId' => $g5e_r]);
        goto tArwv;
        ZtIUS:
        $kVF0z = memory_get_usage();
        goto ekDV7;
        qEOrH:
        $DbNb5 = microtime(true);
        goto ZtIUS;
        u7G01:
    }
    private function mICSiyAyZUP($purdg, $pMNZx)
    {
        goto AUje2;
        MK4GS:
        unset($Ucqv9);
        goto GFI6f;
        AUje2:
        $Ucqv9 = $this->M9duE->call($this, $purdg);
        goto sjsJs;
        BZF8c:
        $this->F3J1W->put($pMNZx, $Ucqv9->toJpeg(self::xbIce), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto MK4GS;
        sjsJs:
        $Ucqv9->orient()->toJpeg(self::xbIce)->save($pMNZx);
        goto BZF8c;
        GFI6f:
    }
    private function mLwlhgAa6Zg($purdg, $pMNZx)
    {
        goto JeHxY;
        jC5Sx:
        $this->F3J1W->put($pMNZx, $Ucqv9->toWebp(self::xbIce), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto tm0yr;
        tm0yr:
        unset($Ucqv9);
        goto n3ylt;
        Oqsoj:
        $Ucqv9->orient()->toWebp(self::xbIce);
        goto jC5Sx;
        JeHxY:
        $Ucqv9 = $this->M9duE->call($this, $purdg);
        goto Oqsoj;
        n3ylt:
    }
    private function mZyAvZSp4ac($MSkzT, $Mwx3T)
    {
        goto nwmgp;
        hrsmA:
        return $MSkzT;
        goto aoURr;
        oOdo8:
        $MSkzT->save();
        goto hrsmA;
        N_QC_:
        $MSkzT->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$Mwx3T}", $MSkzT->getLocation()));
        goto oOdo8;
        nwmgp:
        $MSkzT->setAttribute('type', $Mwx3T);
        goto N_QC_;
        aoURr:
    }
}
