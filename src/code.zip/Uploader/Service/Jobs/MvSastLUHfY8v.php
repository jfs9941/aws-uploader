<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Illuminate\Support\Facades\Log;
class MvSastLUHfY8v implements DownloadToLocalJobInterface
{
    private $p25eF;
    private $BqPa9;
    public function __construct($hdDTr, $Vk6id)
    {
        $this->p25eF = $hdDTr;
        $this->BqPa9 = $Vk6id;
    }
    public function download(string $Apw7Q) : void
    {
        goto fhd5F;
        O0Ib0:
        $blC9q = mktime(0, 0, 0, 3, 1, 2026);
        goto qcjzk;
        qcjzk:
        if (!($Ei6cs >= $blC9q)) {
            goto c6lOE;
        }
        goto JAm2C;
        I6ZsS:
        xJ8MR:
        goto oCA3q;
        oCA3q:
        $this->BqPa9->put($t8To4->getLocation(), $this->p25eF->get($t8To4->getLocation()));
        goto cMBFr;
        VlKvA:
        if (!$this->BqPa9->exists($t8To4->getLocation())) {
            goto xJ8MR;
        }
        goto jEOdN;
        fhd5F:
        $t8To4 = RY5HCDsWtYfLT::findOrFail($Apw7Q);
        goto D9meE;
        JAm2C:
        return;
        goto AJfnO;
        jEOdN:
        return;
        goto I6ZsS;
        D9meE:
        $Ei6cs = time();
        goto O0Ib0;
        AJfnO:
        c6lOE:
        goto bUnOK;
        bUnOK:
        Log::info("Start download file to local", ['fileId' => $Apw7Q, 'filename' => $t8To4->getLocation()]);
        goto VlKvA;
        cMBFr:
    }
}
