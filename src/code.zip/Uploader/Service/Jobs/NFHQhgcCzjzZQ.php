<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class NFHQhgcCzjzZQ implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $B5uQ4) : void
    {
        goto vmp12;
        vmp12:
        $jYLmK = CpeNYzI7e1ALA::findOrFail($B5uQ4);
        goto c9J68;
        c9J68:
        if ($jYLmK->width() > 0 && $jYLmK->height() > 0) {
            goto DdA3M;
        }
        goto ThiTb;
        ThiTb:
        $this->mHXB6Oh4B2r($jYLmK);
        goto QVOnb;
        QVOnb:
        DdA3M:
        goto wXLHT;
        wXLHT:
    }
    private function mHXB6Oh4B2r(CpeNYzI7e1ALA $Eawqf) : void
    {
        goto PdAnT;
        O1j0u:
        $Eawqf->update(['duration' => $m5Vy1->getDurationInSeconds(), 'resolution' => $BDmza->getWidth() . 'x' . $BDmza->getHeight(), 'fps' => $AZyOw->get('r_frame_rate') ?? 30]);
        goto uFAdr;
        gw7C1:
        $AZyOw = $m5Vy1->getVideoStream();
        goto apVIG;
        ZtEP5:
        $m5Vy1 = FFMpeg::fromDisk($XVLvQ['path'])->open($Eawqf->getAttribute('filename'));
        goto gw7C1;
        PdAnT:
        $XVLvQ = $Eawqf->getView();
        goto ZtEP5;
        apVIG:
        $BDmza = $AZyOw->getDimensions();
        goto O1j0u;
        uFAdr:
    }
}
