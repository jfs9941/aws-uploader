<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class LXFKX4tQX3D0P
{
    private $EexiG;
    private $YJOqB;
    public function __construct(int $U0xll, int $FObuz)
    {
        goto hDdTc;
        RqK12:
        TVrj9:
        goto PD1gg;
        hDdTc:
        if (!($U0xll <= 0)) {
            goto VUvj7;
        }
        goto BpVPf;
        BrKvU:
        $this->YJOqB = $FObuz;
        goto GAvXo;
        PD1gg:
        $this->EexiG = $U0xll;
        goto BrKvU;
        eBfbA:
        VUvj7:
        goto n5S_f;
        BpVPf:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto eBfbA;
        n5S_f:
        if (!($FObuz <= 0)) {
            goto TVrj9;
        }
        goto IPe5i;
        IPe5i:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto RqK12;
        GAvXo:
    }
    private static function mMkk13NtiGc($ddFtP, string $Vocdk = 'floor') : int
    {
        goto nLCgI;
        tI0aW:
        switch (strtolower($Vocdk)) {
            case 'ceil':
                return (int) (ceil($ddFtP / 2) * 2);
            case 'round':
                return (int) (round($ddFtP / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($ddFtP / 2) * 2);
        }
        goto hQcVY;
        YGn3z:
        d0Vj_:
        goto yU8oM;
        yU8oM:
        if (!(is_float($ddFtP) && $ddFtP == floor($ddFtP) && (int) $ddFtP % 2 === 0)) {
            goto NYREm;
        }
        goto kSTLo;
        nLCgI:
        if (!(is_int($ddFtP) && $ddFtP % 2 === 0)) {
            goto d0Vj_;
        }
        goto dyvsL;
        kSTLo:
        return (int) $ddFtP;
        goto pQaH0;
        dyvsL:
        return $ddFtP;
        goto YGn3z;
        cbxPO:
        xNMpx:
        goto LgD2a;
        pQaH0:
        NYREm:
        goto tI0aW;
        hQcVY:
        QqFuj:
        goto cbxPO;
        LgD2a:
    }
    public function mHs8GaRQLfS(string $molon = 'floor') : array
    {
        goto JE_r_;
        pYW7F:
        if ($this->EexiG >= $this->YJOqB) {
            goto rLf2p;
        }
        goto lD32r;
        cvC7F:
        $RS2Ak = 2;
        goto klF2u;
        Q05BX:
        $RS2Ak = self::mMkk13NtiGc(round($Re5NV), $molon);
        goto dbcuz;
        F1l4X:
        $R1AaT = 0;
        goto KSK01;
        FbRs3:
        $RS2Ak = $ylTq0;
        goto qIx0W;
        qIx0W:
        $vCwod = $RS2Ak / $this->YJOqB;
        goto tJRZC;
        vpcvB:
        return ['width' => $R1AaT, 'height' => $RS2Ak];
        goto poijc;
        NAuFV:
        $R1AaT = 2;
        goto Lc22T;
        UHeNI:
        $R1AaT = self::mMkk13NtiGc(round($l3_cd), $molon);
        goto nWanb;
        nWanb:
        OLNZx:
        goto mLCUs;
        dbcuz:
        goto OLNZx;
        goto BFCD0;
        yIn64:
        $Re5NV = $this->YJOqB * $vCwod;
        goto Q05BX;
        mLCUs:
        if (!($R1AaT < 2)) {
            goto m7wf8;
        }
        goto NAuFV;
        JE_r_:
        $ylTq0 = 1080;
        goto F1l4X;
        KSK01:
        $RS2Ak = 0;
        goto pYW7F;
        Lc22T:
        m7wf8:
        goto mFn2M;
        BFCD0:
        rLf2p:
        goto FbRs3;
        klF2u:
        ePP11:
        goto vpcvB;
        FlkJQ:
        $vCwod = $R1AaT / $this->EexiG;
        goto yIn64;
        lD32r:
        $R1AaT = $ylTq0;
        goto FlkJQ;
        tJRZC:
        $l3_cd = $this->EexiG * $vCwod;
        goto UHeNI;
        mFn2M:
        if (!($RS2Ak < 2)) {
            goto ePP11;
        }
        goto cvC7F;
        poijc:
    }
}
