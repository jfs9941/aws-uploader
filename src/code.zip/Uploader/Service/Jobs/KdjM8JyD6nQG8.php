<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class KdjM8JyD6nQG8
{
    private $VJ5nN;
    private $ujF3W;
    private $iHPgt;
    private $h0iwI;
    public function __construct($TzB9b, $w6xg8, $zeM4q, $jxMWP)
    {
        goto ujgqV;
        OKNlZ:
        $this->VJ5nN = $TzB9b;
        goto RVjtE;
        ujgqV:
        $this->ujF3W = $w6xg8;
        goto TqF2W;
        aJ8pP:
        $this->h0iwI = $jxMWP;
        goto OKNlZ;
        TqF2W:
        $this->iHPgt = $zeM4q;
        goto aJ8pP;
        RVjtE:
    }
    public function mRm4cjztnmq(?int $Nk4Te, ?int $jCfbb, string $gKVpe, bool $VFZB3 = false) : string
    {
        goto G2rLr;
        SDqIQ:
        return $VFZB3 ? $fQjwQ : $this->iHPgt->url($fQjwQ);
        goto GYvw0;
        myv9s:
        $ACogh = $Nk4Te - $hA9ut;
        goto EziCE;
        inCRd:
        if (!$this->iHPgt->exists($fQjwQ)) {
            goto CgWVU;
        }
        goto SDqIQ;
        RHkTa:
        $g7NWE = 0.1;
        goto kPtO6;
        qOp9u:
        return $VFZB3 ? $fQjwQ : $this->iHPgt->url($fQjwQ);
        goto Yipbb;
        EziCE:
        $weET_ = (int) ($ACogh / 80);
        goto ocmsl;
        kPtO6:
        list($sn3Wi, $hA9ut, $vAihR) = $this->mqQtuSLboxk($gKVpe, $Nk4Te, $g7NWE, (float) $Nk4Te / $jCfbb);
        goto pxkIC;
        vuhV7:
        throw new \RuntimeException("SNpic2wzC1yT8 dimensions are not available.");
        goto BKNpH;
        L_pAW:
        $d0jEy = $jCfbb - $sn3Wi - 10;
        goto bzJDI;
        G2rLr:
        if (!($Nk4Te === null || $jCfbb === null)) {
            goto BlpCY;
        }
        goto vuhV7;
        GYvw0:
        CgWVU:
        goto jdsbG;
        C7ni7:
        $this->iHPgt->put($fQjwQ, $h4i8i->stream('png'));
        goto qOp9u;
        ocmsl:
        $ACogh -= $weET_;
        goto CnjkZ;
        BKNpH:
        BlpCY:
        goto RHkTa;
        pxkIC:
        $fQjwQ = $this->ms9pDT5hdT5($vAihR, $Nk4Te, $jCfbb, $hA9ut, $sn3Wi);
        goto inCRd;
        F4ZAV:
        ma1xN:
        goto L_pAW;
        CnjkZ:
        if (!($Nk4Te > 1500)) {
            goto ma1xN;
        }
        goto VhdBx;
        bzJDI:
        $h4i8i->text($vAihR, $ACogh, (int) $d0jEy, function ($tsYMn) use($sn3Wi) {
            goto EssUl;
            WXGdA:
            $tsYMn->align('middle');
            goto qHTIQ;
            GzIzz:
            $tsYMn->color([185, 185, 185, 1]);
            goto Qqy3V;
            ItjSO:
            $tEOfl = (int) ($sn3Wi * 1.2);
            goto t2kvp;
            EssUl:
            $tsYMn->file(public_path($this->ujF3W));
            goto ItjSO;
            Qqy3V:
            $tsYMn->valign('middle');
            goto WXGdA;
            t2kvp:
            $tsYMn->size(max($tEOfl, 1));
            goto GzIzz;
            qHTIQ:
        });
        goto vypj2;
        vypj2:
        $this->h0iwI->put($fQjwQ, $h4i8i->stream('png'));
        goto C7ni7;
        jdsbG:
        $h4i8i = $this->VJ5nN->call($this, $Nk4Te, $jCfbb);
        goto myv9s;
        VhdBx:
        $ACogh -= $weET_ * 0.4;
        goto F4ZAV;
        Yipbb:
    }
    private function ms9pDT5hdT5(string $gKVpe, int $Nk4Te, int $jCfbb, int $XQwqO, int $a89M2) : string
    {
        $KwKVJ = ltrim($gKVpe, '@');
        return "v2/watermark/{$KwKVJ}/{$Nk4Te}x{$jCfbb}_{$XQwqO}x{$a89M2}/text_watermark.png";
    }
    private function mqQtuSLboxk($gKVpe, int $Nk4Te, float $d4axR, float $YsmpC) : array
    {
        goto Rajd5;
        MZXok:
        $Wc2V1 = 1 / $YsmpC * $hA9ut / strlen($vAihR);
        goto HvMoZ;
        Lm04B:
        $Wc2V1 = $hA9ut / (strlen($vAihR) * 0.8);
        goto ASup9;
        xWNBO:
        $hA9ut = (int) ($Nk4Te * $d4axR);
        goto Dt1gx;
        HvMoZ:
        return [(int) $Wc2V1, $hA9ut, $vAihR];
        goto lDnLk;
        ASup9:
        return [(int) $Wc2V1, $Wc2V1 * strlen($vAihR) / 1.8, $vAihR];
        goto K05fF;
        Rajd5:
        $vAihR = '@' . $gKVpe;
        goto xWNBO;
        Dt1gx:
        if (!($YsmpC > 1)) {
            goto m727w;
        }
        goto Lm04B;
        K05fF:
        m727w:
        goto MZXok;
        lDnLk:
    }
}
