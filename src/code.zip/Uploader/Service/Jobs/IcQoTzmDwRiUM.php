<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class IcQoTzmDwRiUM implements GenerateThumbnailJobInterface
{
    const xzxfg = 150;
    const H9ZQ9 = 150;
    private $aQPLw;
    private $gq_yF;
    public function __construct($fhNRF, $gBW_k)
    {
        $this->aQPLw = $fhNRF;
        $this->gq_yF = $gBW_k;
    }
    public function generate(string $PV4mw)
    {
        goto wpz5X;
        pznIA:
        ini_set('memory_limit', '-1');
        goto tuMZx;
        wpz5X:
        Log::info("Generating thumbnail", ['imageId' => $PV4mw]);
        goto pznIA;
        tuMZx:
        try {
            goto iIh1X;
            kx9Xh:
            $WDB6O = $h5ffz->path($sEueW);
            goto e1Em1;
            OoyeI:
            mgmJW:
            goto bfPsf;
            m9xvm:
            $lmmyB = $this->aQPLw->call($this, $h5ffz->path($SYKC9->getLocation()));
            goto eMsY1;
            E0uAg:
            Log::warning('Failed to set file permissions for stored image: ' . $WDB6O);
            goto EIbsq;
            iGlF0:
            if (!($VDTJq !== false)) {
                goto mgmJW;
            }
            goto QHRFZ;
            ifxo1:
            vEZag:
            goto OoyeI;
            mAQP8:
            $lmmyB->destroy();
            goto iGlF0;
            eMsY1:
            $lmmyB->fit(150, 150, function ($u2fnU) {
                $u2fnU->aspectRatio();
            });
            goto Q51K2;
            ENXOp:
            $sEueW = $this->mEdD9zw0sfJ($SYKC9);
            goto BEOH7;
            BEOH7:
            $VDTJq = $h5ffz->put($sEueW, $lmmyB->stream(), ['visibility' => 'public']);
            goto mAQP8;
            EIbsq:
            throw new \Exception('Failed to set file permissions for stored image: ' . $WDB6O);
            goto ifxo1;
            Q51K2:
            $lmmyB->encode('jpg', 80);
            goto ENXOp;
            PuUtH:
            $SYKC9 = McTg5Yp6FKC6z::findOrFail($PV4mw);
            goto m9xvm;
            QHRFZ:
            $SYKC9->update(['thumbnail' => $sEueW, 'status' => O8RzIjGmSN6fG::THUMBNAIL_PROCESSED]);
            goto kx9Xh;
            iIh1X:
            $h5ffz = $this->gq_yF;
            goto PuUtH;
            e1Em1:
            if (chmod($WDB6O, 0644)) {
                goto vEZag;
            }
            goto E0uAg;
            bfPsf:
        } catch (ModelNotFoundException $Uh0GK) {
            Log::info("McTg5Yp6FKC6z has been deleted, discard it", ['imageId' => $PV4mw]);
            return;
        }
        goto Nkc8q;
        Nkc8q:
    }
    private function mEdD9zw0sfJ(Dup6KVtAFNCUq $SYKC9) : string
    {
        goto myCg_;
        myCg_:
        $sEueW = $SYKC9->getLocation();
        goto cXJ9H;
        OQ7vZ:
        $Aj0Hq = $H0xYM . '/' . self::xzxfg . 'X' . self::H9ZQ9;
        goto nO0DM;
        nO0DM:
        return $Aj0Hq . '/' . $SYKC9->getFilename() . '.jpg';
        goto CcEAo;
        cXJ9H:
        $H0xYM = dirname($sEueW);
        goto OQ7vZ;
        CcEAo:
    }
}
