<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class KG2iVDaA8Uu0H implements GenerateThumbnailForVideoInterface
{
    private $j3xD2;
    public function __construct($hfmvL)
    {
        $this->j3xD2 = $hfmvL;
    }
    public function generate(string $iG1wy) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $iG1wy);
        $this->j3xD2->createThumbnail($iG1wy);
    }
}
