<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class GcKCYcdpK9Qwk implements CompressJobInterface
{
    const bJ4HY = 60;
    private $bIrxp;
    private $GRsEs;
    private $hpoa6;
    public function __construct($NJy8O, $Zywh9, $tKzGl)
    {
        goto Y4dq4;
        CiepE:
        $this->GRsEs = $Zywh9;
        goto RYQWF;
        ljAn1:
        $this->hpoa6 = $tKzGl;
        goto CiepE;
        Y4dq4:
        $this->bIrxp = $NJy8O;
        goto ljAn1;
        RYQWF:
    }
    public function compress(string $eeXS6)
    {
        goto c9RI8;
        c9RI8:
        $OYvfo = microtime(true);
        goto xMTCy;
        ctefi:
        try {
            goto bPn89;
            mlDga:
            if (!(strtolower($K0J89->getExtension()) === 'png' || strtolower($K0J89->getExtension()) === 'heic')) {
                goto OJsDG;
            }
            goto pqM_l;
            pqM_l:
            $K0J89 = $this->mGEHCzGcDmS($K0J89, 'jpg');
            goto qdgOO;
            vDIG2:
            try {
                goto jP7Up;
                jP7Up:
                $en4WE = $this->GRsEs->path(str_replace('.jpg', '.webp', $K0J89->getLocation()));
                goto SxdGr;
                QAH2w:
                $this->mGEHCzGcDmS($K0J89, 'webp');
                goto E9dmg;
                SxdGr:
                $this->mmSGIr44a0A($VSyK7, $en4WE);
                goto QAH2w;
                E9dmg:
            } catch (\Exception $kJgSA) {
                goto JPe_5;
                PtNEe:
                $en4WE = $this->GRsEs->path($K0J89->getLocation());
                goto h7b2R;
                JPe_5:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $eeXS6, 'error' => $kJgSA->getMessage()]);
                goto PtNEe;
                h7b2R:
                $this->mDK8TJyqB2R($VSyK7, $en4WE);
                goto QAvHf;
                QAvHf:
            }
            goto S_10X;
            AmgaG:
            $VSyK7 = $this->GRsEs->path($K0J89->getLocation());
            goto mlDga;
            qdgOO:
            OJsDG:
            goto vDIG2;
            bPn89:
            $K0J89 = UG34Yjmf7IsbQ::findOrFail($eeXS6);
            goto AmgaG;
            S_10X:
        } catch (\Throwable $kJgSA) {
            goto T_7ir;
            jYAlz:
            K5K7V:
            goto nxQnp;
            I0g5N:
            return;
            goto jYAlz;
            nxQnp:
            Log::error("Failed to compress image", ['imageId' => $eeXS6, 'error' => $kJgSA->getMessage()]);
            goto YPxaO;
            gYOiF:
            Log::info("UG34Yjmf7IsbQ has been deleted, discard it", ['imageId' => $eeXS6]);
            goto I0g5N;
            T_7ir:
            if (!$kJgSA instanceof ModelNotFoundException) {
                goto K5K7V;
            }
            goto gYOiF;
            YPxaO:
        } finally {
            $kreUc = microtime(true);
            $VUnvt = memory_get_usage();
            $dR0uy = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $eeXS6, 'execution_time_sec' => $kreUc - $OYvfo, 'memory_usage_mb' => ($VUnvt - $dSWgf) / 1024 / 1024, 'peak_memory_usage_mb' => ($dR0uy - $WT5nk) / 1024 / 1024]);
        }
        goto rimgG;
        r3R7v:
        $WT5nk = memory_get_peak_usage();
        goto Wn6zm;
        Wn6zm:
        Log::info("Compress image", ['imageId' => $eeXS6]);
        goto ctefi;
        xMTCy:
        $dSWgf = memory_get_usage();
        goto r3R7v;
        rimgG:
    }
    private function mDK8TJyqB2R($VSyK7, $en4WE)
    {
        goto eX53x;
        eX53x:
        $WyTVR = $this->bIrxp->call($this, $VSyK7);
        goto H5iyd;
        S_ISV:
        unset($WyTVR);
        goto rjg3n;
        H5iyd:
        $WyTVR->orient()->toJpeg(self::bJ4HY)->save($en4WE);
        goto qoLu9;
        qoLu9:
        $this->hpoa6->put($en4WE, $WyTVR->toJpeg(self::bJ4HY), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto S_ISV;
        rjg3n:
    }
    private function mmSGIr44a0A($VSyK7, $en4WE)
    {
        goto S_oMh;
        nnKHG:
        unset($WyTVR);
        goto gfkkS;
        av2jA:
        $WyTVR->orient()->toWebp(self::bJ4HY);
        goto G070O;
        G070O:
        $this->hpoa6->put($en4WE, $WyTVR->toJpeg(self::bJ4HY), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto nnKHG;
        S_oMh:
        $WyTVR = $this->bIrxp->call($this, $VSyK7);
        goto av2jA;
        gfkkS:
    }
    private function mGEHCzGcDmS($K0J89, $pp4CF)
    {
        goto cG4LV;
        ROtDU:
        $K0J89->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$pp4CF}", $K0J89->getLocation()));
        goto zZaPC;
        gSIm2:
        return $K0J89;
        goto QgpwQ;
        zZaPC:
        $K0J89->save();
        goto gSIm2;
        cG4LV:
        $K0J89->setAttribute('type', $pp4CF);
        goto ROtDU;
        QgpwQ:
    }
}
