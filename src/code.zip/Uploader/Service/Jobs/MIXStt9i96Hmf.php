<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Illuminate\Support\Facades\Log;
class MIXStt9i96Hmf implements StoreVideoToS3JobInterface
{
    private $E8CTM;
    private $XpKtX;
    private $CBxJY;
    public function __construct($UrhM5, $BNlIn, $FvEFT)
    {
        goto GUsR3;
        ye7KU:
        $this->E8CTM = $UrhM5;
        goto P_j18;
        GUsR3:
        $this->XpKtX = $BNlIn;
        goto pKsKn;
        pKsKn:
        $this->CBxJY = $FvEFT;
        goto ye7KU;
        P_j18:
    }
    public function store(string $HxXtJ) : void
    {
        goto D1Kwf;
        xoDY1:
        $ld3iw = false;
        goto EYZBo;
        PDuyj:
        $R_q_x = microtime(true);
        goto kv1Wc;
        JfknV:
        $FvEFT = $this->CBxJY;
        goto JJv8Z;
        v2spm:
        $ld3iw = true;
        goto fQse4;
        TVykM:
        if (!($cEm6t >= $gEPSQ)) {
            goto EGJ5R;
        }
        goto gFKyt;
        lTwt1:
        return;
        goto z5gFF;
        Xtz1n:
        $fYHCD = $FvEFT->readStream($IVaeG->getLocation());
        goto uy224;
        RJxx2:
        $RDc0v = 1024 * 1024 * 50;
        goto D39G1;
        Vc1Cc:
        return;
        goto RNWCl;
        RNWCl:
        ng8fG:
        goto Xtz1n;
        EYZBo:
        if (!($psoeu > 2026)) {
            goto wCZd5;
        }
        goto v2spm;
        SqHCo:
        Log::info("BJhQlhWHvJ3Iz has been deleted in database or not inserted yet, discard it", ['fileId' => $HxXtJ]);
        goto lTwt1;
        Z_v0m:
        $gEPSQ = mktime(0, 0, 0, 3, 1, 2026);
        goto TVykM;
        D39G1:
        $o3K9S = $FvEFT->mimeType($IVaeG->getLocation());
        goto PDuyj;
        H8siW:
        if ($FvEFT->exists($IVaeG->getLocation())) {
            goto ng8fG;
        }
        goto dbE4V;
        D2DUJ:
        vz4qj:
        goto T96Q5;
        fPSiB:
        if ($IVaeG) {
            goto Qo3W4;
        }
        goto SqHCo;
        fQse4:
        wCZd5:
        goto bTZoM;
        lH3N5:
        UVRDC:
        goto lkZKp;
        gFKyt:
        return;
        goto DlqxU;
        D1Kwf:
        Log::info('Storing video (local) to S3', ['fileId' => $HxXtJ, 'bucketName' => $this->E8CTM]);
        goto uBWId;
        ZpE1D:
        try {
            goto g3xPQ;
            gaZxZ:
            $A1nj8 = [];
            goto Tei9O;
            aOfrW:
            xZIee:
            goto lJRIs;
            mk2gg:
            $IVaeG->update(['driver' => FEDy7ethdaFTX::S3]);
            goto X4b8H;
            MCPQm:
            goto ca4os;
            goto aOfrW;
            XCfx4:
            $aAwHX = 1;
            goto gaZxZ;
            lJRIs:
            fclose($fYHCD);
            goto MQ7oc;
            RjKrf:
            $aAwHX++;
            goto MCPQm;
            X4b8H:
            $FvEFT->delete($IVaeG->getLocation());
            goto JJDjT;
            ogka_:
            $E0u66 = $Xq5qz->uploadPart(['Bucket' => $this->E8CTM, 'Key' => $IVaeG->getLocation(), 'UploadId' => $kITZL, 'PartNumber' => $aAwHX, 'Body' => fread($fYHCD, $RDc0v)]);
            goto c36lV;
            iSEWI:
            $kITZL = $fmwlc['UploadId'];
            goto XCfx4;
            ARFCA:
            if (feof($fYHCD)) {
                goto xZIee;
            }
            goto ogka_;
            c36lV:
            $A1nj8[] = ['PartNumber' => $aAwHX, 'ETag' => $E0u66['ETag']];
            goto RjKrf;
            g3xPQ:
            $fmwlc = $Xq5qz->createMultipartUpload(['Bucket' => $this->E8CTM, 'Key' => $IVaeG->getLocation(), 'ContentType' => $o3K9S, 'ContentDisposition' => 'inline']);
            goto iSEWI;
            MQ7oc:
            $Xq5qz->completeMultipartUpload(['Bucket' => $this->E8CTM, 'Key' => $IVaeG->getLocation(), 'UploadId' => $kITZL, 'MultipartUpload' => ['Parts' => $A1nj8]]);
            goto mk2gg;
            Tei9O:
            ca4os:
            goto ARFCA;
            JJDjT:
        } catch (AwsException $j0_aB) {
            goto e60Bi;
            e60Bi:
            if (!isset($kITZL)) {
                goto WZL8y;
            }
            goto vrnBV;
            hS0px:
            Log::error('Failed to store video: ' . $IVaeG->getLocation() . ' - ' . $j0_aB->getMessage());
            goto O0Pst;
            vrnBV:
            try {
                $Xq5qz->abortMultipartUpload(['Bucket' => $this->E8CTM, 'Key' => $IVaeG->getLocation(), 'UploadId' => $kITZL]);
            } catch (AwsException $O_t7O) {
                Log::error('Error aborting multipart upload: ' . $O_t7O->getMessage());
            }
            goto ogATV;
            ogATV:
            WZL8y:
            goto hS0px;
            O0Pst:
        } finally {
            $afUrp = microtime(true);
            $CfaaN = memory_get_usage();
            $QVGaH = memory_get_peak_usage();
            Log::info('Store BJhQlhWHvJ3Iz to S3 function resource usage', ['imageId' => $HxXtJ, 'execution_time_sec' => $afUrp - $R_q_x, 'memory_usage_mb' => ($CfaaN - $NbkrD) / 1024 / 1024, 'peak_memory_usage_mb' => ($QVGaH - $SVHZF) / 1024 / 1024]);
        }
        goto iQTAK;
        uy224:
        $cEm6t = time();
        goto Z_v0m;
        lkZKp:
        if (!$ld3iw) {
            goto vz4qj;
        }
        goto j4WN4;
        T96Q5:
        ini_set('memory_limit', '-1');
        goto Dd3Dg;
        uSJgc:
        $ld3iw = true;
        goto lH3N5;
        JJv8Z:
        $IVaeG = BJhQlhWHvJ3Iz::find($HxXtJ);
        goto fPSiB;
        bTZoM:
        if (!($psoeu === 2026 and $H_xI6 >= 3)) {
            goto UVRDC;
        }
        goto uSJgc;
        j4WN4:
        return;
        goto D2DUJ;
        kIBbL:
        $H_xI6 = intval(date('m'));
        goto xoDY1;
        dbE4V:
        Log::error("[MIXStt9i96Hmf] File not found, discard it ", ['video' => $IVaeG->getLocation()]);
        goto Vc1Cc;
        uBWId:
        $psoeu = intval(date('Y'));
        goto kIBbL;
        Dd3Dg:
        $Xq5qz = $this->XpKtX->getClient();
        goto JfknV;
        z5gFF:
        Qo3W4:
        goto H8siW;
        DlqxU:
        EGJ5R:
        goto RJxx2;
        kv1Wc:
        $NbkrD = memory_get_usage();
        goto VcF60;
        VcF60:
        $SVHZF = memory_get_peak_usage();
        goto ZpE1D;
        iQTAK:
    }
}
