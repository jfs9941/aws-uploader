<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Illuminate\Support\Facades\Log;
class B20s7JuKm8vWq implements DownloadToLocalJobInterface
{
    private $cC_4U;
    private $jhnu6;
    public function __construct($s1UdZ, $vWOwZ)
    {
        $this->cC_4U = $s1UdZ;
        $this->jhnu6 = $vWOwZ;
    }
    public function download(string $q8q1b) : void
    {
        goto mz8X9;
        DExNR:
        Log::info("Start download file to local", ['fileId' => $q8q1b, 'filename' => $mz56v->getLocation()]);
        goto bCW4K;
        at0lV:
        $this->jhnu6->put($mz56v->getLocation(), $this->cC_4U->get($mz56v->getLocation()));
        goto OKiAa;
        mz8X9:
        $mz56v = JOauoJMkgHWbh::findOrFail($q8q1b);
        goto DExNR;
        kXfgr:
        return;
        goto DImCX;
        DImCX:
        TBEDW:
        goto at0lV;
        bCW4K:
        if (!$this->jhnu6->exists($mz56v->getLocation())) {
            goto TBEDW;
        }
        goto kXfgr;
        OKiAa:
    }
}
