<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class O05MgM29rHKIh implements GenerateThumbnailJobInterface
{
    const ICKs3 = 150;
    const vL0T_ = 150;
    private $bLQUI;
    private $svYhv;
    private $BZrcY;
    public function __construct($xA3df, $uLgU3, $bdI52)
    {
        goto emQhn;
        emQhn:
        $this->bLQUI = $xA3df;
        goto tikVw;
        jUchG:
        $this->BZrcY = $bdI52;
        goto AVpp0;
        tikVw:
        $this->svYhv = $uLgU3;
        goto jUchG;
        AVpp0:
    }
    public function generate(string $ShXx2)
    {
        goto PT5hK;
        umdl_:
        ini_set('memory_limit', '-1');
        goto pbzgT;
        PT5hK:
        Log::info("Generating thumbnail", ['imageId' => $ShXx2]);
        goto umdl_;
        pbzgT:
        try {
            goto dfLm3;
            Io9vv:
            $eDjqg = $this->BZrcY->put($lPyJj, $bo5_L->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto Vfqs0;
            dfHpu:
            $bo5_L = $this->bLQUI->call($this, $nkmCX->path($xixtT->getLocation()));
            goto R98mM;
            dfLm3:
            $nkmCX = $this->svYhv;
            goto tOzc_;
            w_1Ts:
            $lPyJj = $this->mWVJtSErsNd($xixtT);
            goto Io9vv;
            Vfqs0:
            unset($bo5_L);
            goto SEgR0;
            R98mM:
            $bo5_L->orient()->resize(150, 150);
            goto w_1Ts;
            SEgR0:
            if (!($eDjqg !== false)) {
                goto mcK4n;
            }
            goto xl99m;
            TqCqW:
            mcK4n:
            goto e8xkK;
            tOzc_:
            $xixtT = Vt3ybt0yfaPAa::findOrFail($ShXx2);
            goto dfHpu;
            xl99m:
            $xixtT->update(['thumbnail' => $lPyJj, 'status' => HGmeWpZQSxAlO::THUMBNAIL_PROCESSED]);
            goto TqCqW;
            e8xkK:
        } catch (ModelNotFoundException $KY3Rq) {
            Log::info("Vt3ybt0yfaPAa has been deleted, discard it", ['imageId' => $ShXx2]);
            return;
        } catch (\Exception $KY3Rq) {
            Log::error("Failed to generate thumbnail", ['imageId' => $ShXx2, 'error' => $KY3Rq->getMessage()]);
        }
        goto BpISD;
        BpISD:
    }
    private function mWVJtSErsNd(UXdXfw71iQGkx $xixtT) : string
    {
        goto w4yJm;
        w4yJm:
        $lPyJj = $xixtT->getLocation();
        goto xsPZP;
        zZzKc:
        $AcHrp = $Nuuvd . '/' . self::ICKs3 . 'X' . self::vL0T_;
        goto oRG9Q;
        xsPZP:
        $Nuuvd = dirname($lPyJj);
        goto zZzKc;
        oRG9Q:
        return $AcHrp . '/' . $xixtT->getFilename() . '.jpg';
        goto fZ5b8;
        fZ5b8:
    }
}
