<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\UHw5WGAecQbAG;
use backup\Exposed\MWQEI3qnbYMuU;
use Illuminate\Support\Facades\Log;
class LeHGRzVWQRkbw implements UHw5WGAecQbAG
{
    private $wOGK6;
    public function __construct($v309b)
    {
        $this->wOGK6 = $v309b;
    }
    public function generate(string $EQQae) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $EQQae);
        $this->wOGK6->createThumbnail($EQQae);
    }
}
