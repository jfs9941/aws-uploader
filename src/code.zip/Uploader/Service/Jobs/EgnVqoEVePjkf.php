<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class EgnVqoEVePjkf
{
    private $Q9b68;
    private $xyt2L;
    public function __construct(int $D9Gtw, int $IqQiK)
    {
        goto gceZ8;
        oTvef:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto wzBQX;
        LzdKH:
        nJyR_:
        goto VeErH;
        gceZ8:
        if (!($D9Gtw <= 0)) {
            goto nJyR_;
        }
        goto uSYeW;
        uSYeW:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto LzdKH;
        pxN1a:
        $this->xyt2L = $IqQiK;
        goto yRUCf;
        wzBQX:
        tRpNR:
        goto xjkOI;
        xjkOI:
        $this->Q9b68 = $D9Gtw;
        goto pxN1a;
        VeErH:
        if (!($IqQiK <= 0)) {
            goto tRpNR;
        }
        goto oTvef;
        yRUCf:
    }
    private static function mOz9BzrcHDQ($gtGq9, string $RxNqv = 'floor') : int
    {
        goto dW7pI;
        BtLG0:
        xcjDS:
        goto qfKXa;
        ONMpb:
        return (int) $gtGq9;
        goto pDHk9;
        dW7pI:
        if (!(is_int($gtGq9) && $gtGq9 % 2 === 0)) {
            goto V7tq1;
        }
        goto MG1uT;
        pEolL:
        switch (strtolower($RxNqv)) {
            case 'ceil':
                return (int) (ceil($gtGq9 / 2) * 2);
            case 'round':
                return (int) (round($gtGq9 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($gtGq9 / 2) * 2);
        }
        goto BtLG0;
        MG1uT:
        return $gtGq9;
        goto JJHLr;
        qfKXa:
        DEV7h:
        goto Dqha5;
        JJHLr:
        V7tq1:
        goto bnXJb;
        bnXJb:
        if (!(is_float($gtGq9) && $gtGq9 == floor($gtGq9) && (int) $gtGq9 % 2 === 0)) {
            goto VCh78;
        }
        goto ONMpb;
        pDHk9:
        VCh78:
        goto pEolL;
        Dqha5:
    }
    public function m2zXdGiw2g6(string $k2tkO = 'floor') : array
    {
        goto uz22s;
        cDeZj:
        $jFieO = $c2BfF;
        goto npmgJ;
        nq0PP:
        $jFieO = 2;
        goto DKY1n;
        Kr9e3:
        $jFieO = 0;
        goto hza38;
        uz22s:
        $c2BfF = 1080;
        goto Ab3uK;
        npmgJ:
        $Pr1UD = $jFieO / $this->xyt2L;
        goto aAQsE;
        Ab3uK:
        $YgaIG = 0;
        goto Kr9e3;
        nTKxE:
        if (!($jFieO < 2)) {
            goto b2nQy;
        }
        goto nq0PP;
        qh7A4:
        return ['width' => $YgaIG, 'height' => $jFieO];
        goto MDE_P;
        glJHZ:
        vHTvM:
        goto nTKxE;
        SMqCt:
        if (!($YgaIG < 2)) {
            goto vHTvM;
        }
        goto wu2NP;
        KvInh:
        $YgaIG = $c2BfF;
        goto k7aqR;
        TFNO8:
        $jFieO = self::mOz9BzrcHDQ(round($n0KyV), $k2tkO);
        goto yQbwf;
        wu2NP:
        $YgaIG = 2;
        goto glJHZ;
        DKY1n:
        b2nQy:
        goto qh7A4;
        RIsEZ:
        $n0KyV = $this->xyt2L * $Pr1UD;
        goto TFNO8;
        YrkYa:
        $YgaIG = self::mOz9BzrcHDQ(round($xiRXK), $k2tkO);
        goto deIUA;
        deIUA:
        t9BQF:
        goto SMqCt;
        k7aqR:
        $Pr1UD = $YgaIG / $this->Q9b68;
        goto RIsEZ;
        hza38:
        if ($this->Q9b68 >= $this->xyt2L) {
            goto J6Po1;
        }
        goto KvInh;
        iPgEF:
        J6Po1:
        goto cDeZj;
        aAQsE:
        $xiRXK = $this->Q9b68 * $Pr1UD;
        goto YrkYa;
        yQbwf:
        goto t9BQF;
        goto iPgEF;
        MDE_P:
    }
}
