<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Service\Jobs\Pj7hrgmc9SyTB;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class McS3futGkobMF implements WatermarkTextJobInterface
{
    private $vn9CJ;
    private $nVSvB;
    private $AK92U;
    private $aiw3M;
    private $q6zCU;
    public function __construct($HL7fw, $kRqOQ, $iay5S, $zDbHT, $EKzQ0)
    {
        goto Oji5l;
        NVfUZ:
        $this->aiw3M = $iay5S;
        goto yXqOJ;
        lZLDh:
        $this->nVSvB = $kRqOQ;
        goto kVesm;
        yXqOJ:
        $this->q6zCU = $zDbHT;
        goto biN0X;
        Oji5l:
        $this->vn9CJ = $HL7fw;
        goto NVfUZ;
        biN0X:
        $this->AK92U = $EKzQ0;
        goto lZLDh;
        kVesm:
    }
    public function putWatermark(string $zV1kl, string $VhKiX) : void
    {
        goto RN9bM;
        BJf4O:
        $TkLmp = memory_get_usage();
        goto vgjN5;
        ijHRy:
        ini_set('memory_limit', '-1');
        goto yPIu2;
        vnCBJ:
        Log::info("Adding watermark text to image", ['imageId' => $zV1kl]);
        goto ijHRy;
        vgjN5:
        $g2Th1 = memory_get_peak_usage();
        goto vnCBJ;
        yPIu2:
        try {
            goto vtqwG;
            ZL1no:
            Log::error("KCmQR4pvm0dT3 is not on local, might be deleted before put watermark", ['imageId' => $zV1kl]);
            goto AO4Ct;
            HP5Pa:
            $this->mUi5LLNFTjh($MUN90, $VhKiX);
            goto XFKUu;
            HT6mF:
            $lmTDq = $this->q6zCU->path($RD3vr->getLocation());
            goto YfcX1;
            nIhzs:
            if (chmod($lmTDq, 0664)) {
                goto EkKaQ;
            }
            goto GLZlG;
            LU0W1:
            $MUN90->orient();
            goto HP5Pa;
            mM1B6:
            EkKaQ:
            goto Dg3DT;
            XFKUu:
            $this->aiw3M->put($lmTDq, $MUN90->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto dd30x;
            YfcX1:
            $MUN90 = $this->vn9CJ->call($this, $lmTDq);
            goto LU0W1;
            uG1F0:
            aVuLa:
            goto HT6mF;
            AO4Ct:
            return;
            goto uG1F0;
            dd30x:
            unset($MUN90);
            goto nIhzs;
            HmM4Y:
            throw new \Exception('Failed to set final permissions on image file: ' . $lmTDq);
            goto mM1B6;
            vtqwG:
            $RD3vr = KCmQR4pvm0dT3::findOrFail($zV1kl);
            goto SgIur;
            GLZlG:
            \Log::warning('Failed to set final permissions on image file: ' . $lmTDq);
            goto HmM4Y;
            SgIur:
            if ($this->q6zCU->exists($RD3vr->getLocation())) {
                goto aVuLa;
            }
            goto ZL1no;
            Dg3DT:
        } catch (\Throwable $bi7t_) {
            goto TIkS6;
            TIkS6:
            if (!$bi7t_ instanceof ModelNotFoundException) {
                goto d8lLY;
            }
            goto vf3Fk;
            vf3Fk:
            Log::info("KCmQR4pvm0dT3 has been deleted, discard it", ['imageId' => $zV1kl]);
            goto S9RJI;
            xhWTm:
            d8lLY:
            goto Hl0Xa;
            Hl0Xa:
            Log::error("KCmQR4pvm0dT3 is not readable", ['imageId' => $zV1kl, 'error' => $bi7t_->getMessage()]);
            goto i2Xzt;
            S9RJI:
            return;
            goto xhWTm;
            i2Xzt:
        } finally {
            $lmBz1 = microtime(true);
            $ZinuS = memory_get_usage();
            $NcQYU = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $zV1kl, 'execution_time_sec' => $lmBz1 - $u7QUO, 'memory_usage_mb' => ($ZinuS - $TkLmp) / 1024 / 1024, 'peak_memory_usage_mb' => ($NcQYU - $g2Th1) / 1024 / 1024]);
        }
        goto tXpkQ;
        RN9bM:
        $u7QUO = microtime(true);
        goto BJf4O;
        tXpkQ:
    }
    private function mUi5LLNFTjh($MUN90, $VhKiX) : void
    {
        goto Dkn_g;
        lxvRe:
        $Hj32z = new Pj7hrgmc9SyTB($this->nVSvB, $this->AK92U, $this->aiw3M, $this->q6zCU);
        goto dyAFv;
        St3ZR:
        $this->q6zCU->put($YRAk6, $this->aiw3M->get($YRAk6));
        goto PjwKO;
        Dkn_g:
        $Eb8hw = $MUN90->width();
        goto c71XC;
        BGs2Y:
        $MUN90->place($pxLbo, 'top-left', 0, 0, 30);
        goto sNFri;
        dyAFv:
        $YRAk6 = $Hj32z->m7glC4JIXFX($Eb8hw, $eekOV, $VhKiX, true);
        goto St3ZR;
        c71XC:
        $eekOV = $MUN90->height();
        goto lxvRe;
        PjwKO:
        $pxLbo = $this->vn9CJ->call($this, $this->q6zCU->path($YRAk6));
        goto BGs2Y;
        sNFri:
    }
}
