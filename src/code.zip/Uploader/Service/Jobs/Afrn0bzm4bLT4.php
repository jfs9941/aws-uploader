<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
class Afrn0bzm4bLT4 implements CompressJobInterface
{
    const U9EI7 = 80;
    private $aQPLw;
    private $gq_yF;
    public function __construct($fhNRF, $gBW_k)
    {
        $this->aQPLw = $fhNRF;
        $this->gq_yF = $gBW_k;
    }
    public function compress(string $PV4mw)
    {
        goto LbEZ5;
        KTlbM:
        try {
            goto FWMc3;
            zReVQ:
            $tNf9L->orientate();
            goto LJUNU;
            cdJOV:
            $SYKC9->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $SYKC9->getLocation()));
            goto sgY5A;
            LJUNU:
            $tNf9L->encode('jpg', self::U9EI7);
            goto rizu6;
            l8nHh:
            $EjtV7 = $this->gq_yF->path($SYKC9->getLocation());
            goto A5ZUz;
            A5ZUz:
            $tNf9L = $this->aQPLw->call($this, $ITV_q);
            goto zReVQ;
            sgY5A:
            $SYKC9->save();
            goto i7iJn;
            rizu6:
            $tNf9L->save($EjtV7);
            goto M5W2o;
            bsrG3:
            if (!(strtolower($SYKC9->getExtension()) === 'png' || strtolower($SYKC9->getExtension()) === 'heic')) {
                goto ASUh_;
            }
            goto Q_gaJ;
            Q_gaJ:
            $SYKC9->setAttribute('type', 'jpg');
            goto cdJOV;
            FWMc3:
            $SYKC9 = McTg5Yp6FKC6z::findOrFail($PV4mw);
            goto J6DXt;
            J6DXt:
            $ITV_q = $this->gq_yF->path($SYKC9->getLocation());
            goto bsrG3;
            M5W2o:
            $tNf9L->destroy();
            goto L1AbI;
            i7iJn:
            ASUh_:
            goto l8nHh;
            L1AbI:
        } catch (ModelNotFoundException) {
            Log::info("McTg5Yp6FKC6z has been deleted, discard it", ['imageId' => $PV4mw]);
        } finally {
            $mf5n8 = microtime(true);
            $c5jd5 = memory_get_usage();
            $ghXwk = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $PV4mw, 'execution_time_sec' => $mf5n8 - $ZqNFk, 'memory_usage_mb' => ($c5jd5 - $vqC1w) / 1024 / 1024, 'peak_memory_usage_mb' => ($ghXwk - $NSzm3) / 1024 / 1024]);
        }
        goto GCuyo;
        t_HS6:
        Log::info("Compress image", ['imageId' => $PV4mw]);
        goto KTlbM;
        LbEZ5:
        $ZqNFk = microtime(true);
        goto OM2jc;
        OM2jc:
        $vqC1w = memory_get_usage();
        goto byiDn;
        byiDn:
        $NSzm3 = memory_get_peak_usage();
        goto t_HS6;
        GCuyo:
    }
}
