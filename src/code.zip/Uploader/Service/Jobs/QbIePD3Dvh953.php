<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
class QbIePD3Dvh953 implements WatermarkTextJobInterface
{
    private $wEW4b;
    private $q3KfI;
    private $i0IXb;
    private $dhrkT;
    private $VFHFZ;
    public function __construct($jlVrW, $xsFIZ, $v8n0s, $dOL2I, $HHE0X)
    {
        goto Qf7DF;
        kvzIP:
        $this->VFHFZ = $dOL2I;
        goto L_h8B;
        Qf7DF:
        $this->wEW4b = $jlVrW;
        goto rsHuU;
        L_h8B:
        $this->i0IXb = $HHE0X;
        goto Vw3b4;
        Vw3b4:
        $this->q3KfI = $xsFIZ;
        goto JTRi6;
        rsHuU:
        $this->dhrkT = $v8n0s;
        goto kvzIP;
        JTRi6:
    }
    public function putWatermark(string $cQqZd, string $mLgze) : void
    {
        goto fKx6H;
        h6YVU:
        try {
            goto iA5UW;
            Te0ZB:
            $J_xQQ = $this->wEW4b->call($this, $IJqE5);
            goto WEA3F;
            bncrv:
            $J_xQQ->save($IJqE5);
            goto Yg8ma;
            QkMVA:
            if (chmod($IJqE5, 0664)) {
                goto RYNHs;
            }
            goto k1fF7;
            Yg8ma:
            $J_xQQ->destroy();
            goto QkMVA;
            OUrOM:
            CuV9K:
            goto Vg0GX;
            Vg0GX:
            $IJqE5 = $this->VFHFZ->path($MpgR7->getLocation());
            goto Te0ZB;
            k8x8o:
            RYNHs:
            goto yJCU3;
            azjYh:
            throw new \Exception('Failed to set final permissions on image file: ' . $IJqE5);
            goto k8x8o;
            WEA3F:
            $J_xQQ->orientate();
            goto r5HRn;
            iA5UW:
            $MpgR7 = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
            goto BqWRc;
            k1fF7:
            \Log::warning('Failed to set final permissions on image file: ' . $IJqE5);
            goto azjYh;
            r5HRn:
            $this->mjphapfyBSm($J_xQQ, $mLgze);
            goto bncrv;
            ERb_M:
            return;
            goto OUrOM;
            BqWRc:
            if ($this->VFHFZ->exists($MpgR7->getLocation())) {
                goto CuV9K;
            }
            goto peJGL;
            peJGL:
            Log::error("Kx3NMUJqFpl5Q is not on local, might be deleted before put watermark", ['imageId' => $cQqZd]);
            goto ERb_M;
            yJCU3:
        } catch (\Throwable $G31WQ) {
            goto pWWZZ;
            K6aQ0:
            return;
            goto FRKS_;
            FRKS_:
            WwzRg:
            goto uCWnH;
            uCWnH:
            Log::error("Kx3NMUJqFpl5Q is not readable", ['imageId' => $cQqZd, 'error' => $G31WQ->getMessage()]);
            goto N6vpX;
            pWWZZ:
            if (!$G31WQ instanceof ModelNotFoundException) {
                goto WwzRg;
            }
            goto vlz6c;
            vlz6c:
            Log::info("Kx3NMUJqFpl5Q has been deleted, discard it", ['imageId' => $cQqZd]);
            goto K6aQ0;
            N6vpX:
        } finally {
            $yTnwM = microtime(true);
            $qw3CC = memory_get_usage();
            $uML0D = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $cQqZd, 'execution_time_sec' => $yTnwM - $OKKdr, 'memory_usage_mb' => ($qw3CC - $o3FRR) / 1024 / 1024, 'peak_memory_usage_mb' => ($uML0D - $wpG9k) / 1024 / 1024]);
        }
        goto Obp3B;
        ZELmA:
        Log::info("Adding watermark text to image", ['imageId' => $cQqZd]);
        goto JIHMU;
        JIHMU:
        ini_set('memory_limit', '-1');
        goto h6YVU;
        eIXrZ:
        $wpG9k = memory_get_peak_usage();
        goto ZELmA;
        fKx6H:
        $OKKdr = microtime(true);
        goto d5qDM;
        d5qDM:
        $o3FRR = memory_get_usage();
        goto eIXrZ;
        Obp3B:
    }
    private function mjphapfyBSm($J_xQQ, $mLgze) : void
    {
        goto sYhX2;
        bapl4:
        $KMdsh = $TPtwR->mZn9oNgFPjz($X22ix, $LrYxj, $mLgze, true);
        goto lIgf1;
        PyhNY:
        $J_xQQ->insert($L_Ckv);
        goto pyG6P;
        lIgf1:
        $this->VFHFZ->put($KMdsh, $this->dhrkT->get($KMdsh));
        goto pmrrR;
        qZiDq:
        $LrYxj = $J_xQQ->height();
        goto RfrnF;
        RfrnF:
        $TPtwR = new JLhS5pGupvbSs($this->q3KfI, $this->i0IXb, $this->dhrkT, $this->VFHFZ);
        goto bapl4;
        sYhX2:
        $X22ix = $J_xQQ->width();
        goto qZiDq;
        TqcjE:
        $L_Ckv->opacity(35);
        goto PyhNY;
        pmrrR:
        $L_Ckv = $this->wEW4b->call($this, $this->VFHFZ->path($KMdsh));
        goto TqcjE;
        pyG6P:
    }
}
