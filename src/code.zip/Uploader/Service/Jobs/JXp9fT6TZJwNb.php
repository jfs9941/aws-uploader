<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Encoder\Y2LbsW546QJwu;
use Jfs\Uploader\Encoder\NLQv7ExFsS3bB;
use Jfs\Uploader\Encoder\UTfSplvy0DRyY;
use Jfs\Uploader\Encoder\QochEC0s6Fy7v;
use Jfs\Uploader\Encoder\GQRImhPfYt9CY;
use Jfs\Uploader\Encoder\UdwQA9F2p3tLA;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Jfs\Uploader\Service\Jobs\RZKBH6yGTw8mC;
use Jfs\Uploader\Service\Jobs\OF4Ex7TEJabkL;
use Jfs\Uploader\Service\MNNH4c3TCQoPL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class JXp9fT6TZJwNb implements MediaEncodeJobInterface
{
    private $lQSuV;
    private $iK6YG;
    private $DzLtS;
    private $tffnP;
    private $KsiSY;
    public function __construct(string $zocZ_, $whVTJ, $AfCy6, $r9VTi, $yxve_)
    {
        goto EFGWC;
        tPnjJ:
        $this->DzLtS = $AfCy6;
        goto xNtYP;
        P2P17:
        $this->KsiSY = $yxve_;
        goto GRrlA;
        wGQIs:
        $this->iK6YG = $whVTJ;
        goto tPnjJ;
        EFGWC:
        $this->lQSuV = $zocZ_;
        goto wGQIs;
        xNtYP:
        $this->tffnP = $r9VTi;
        goto P2P17;
        GRrlA:
    }
    public function encode(string $vnAlS, string $E66nV, $MI6U3 = true) : void
    {
        goto rX1v1;
        cbV8D:
        $PPhfW = $HGgJM->month;
        goto O4apo;
        yHNtT:
        $LlObR = $HGgJM->year;
        goto cbV8D;
        PoD6a:
        return;
        goto B_T4M;
        AOjCB:
        $vRkS8 = intval(date('Y'));
        goto unuuF;
        O4apo:
        if (!($LlObR > 2026 or $LlObR === 2026 and $PPhfW > 3 or $LlObR === 2026 and $PPhfW === 3 and $HGgJM->day >= 1)) {
            goto wFiqX;
        }
        goto PoD6a;
        STj6W:
        NupJ5:
        goto WELET;
        kwRIS:
        uI1Lf:
        goto sRkNd;
        agZsy:
        if (!($gEsBt >= $zuAiT)) {
            goto wfL06;
        }
        goto gVIvJ;
        F0MOT:
        try {
            goto Lr3lz;
            KMMQF:
            $vnAlS = $No5E3->mShM8ohVo3p($this->m0chk0zMn59($hsvMf, $MI6U3));
            goto jjHvb;
            QmpjX:
            $eeiXG = $this->mbHGeDTC1Ed($hsvMf);
            goto NjRnu;
            cS5K3:
            $eXHXE = new Y2LbsW546QJwu($hsvMf->getAttribute('duration') ?? 1, 2, $wDJE0->moM43mFRnIv($hsvMf));
            goto LKYWh;
            WfpKB:
            Log::info("Set thumbnail for EzVEhphZx2dEv Job", ['videoId' => $hsvMf->getAttribute('id'), 'duration' => $hsvMf->getAttribute('duration')]);
            goto cS5K3;
            jjHvb:
            $hsvMf->update(['aws_media_converter_job_id' => $vnAlS]);
            goto Iz50M;
            ek9ty:
            $mzD3g = new NLQv7ExFsS3bB('1080p', $pvwWe['width'], $pvwWe['height'], $hsvMf->ez50l ?? 30);
            goto LEeEC;
            CqAyX:
            $pvwWe = $this->mLE0dmUgEKx($LENDk, $Pepx_);
            goto JMr_3;
            kX3n1:
            $waJoa = $this->mmMbG1sIKhZ($NDC6Z, $j99wl->myQ2OXd4GYt($hsvMf->width(), $hsvMf->height(), $E66nV));
            goto Dr2Ja;
            G9A9Z:
            $wDJE0 = app(UTfSplvy0DRyY::class);
            goto Siswe;
            gH8N_:
            F_lEw:
            goto IBb1F;
            NjRnu:
            Log::info("Set input video for Job", ['s3Uri' => $eeiXG]);
            goto X2g7W;
            wt0jO:
            $j99wl = new OF4Ex7TEJabkL($this->tffnP, $this->KsiSY, $this->DzLtS, $this->iK6YG);
            goto kX3n1;
            Dr2Ja:
            if (!$waJoa) {
                goto F_lEw;
            }
            goto CnVqM;
            Siswe:
            $No5E3->mndjww72RJn($wDJE0->mYprb8lRW4P($hsvMf));
            goto l6SFM;
            jurIu:
            $No5E3->mndjww72RJn($wDJE0->mYprb8lRW4P($hsvMf));
            goto gTWI7;
            CnVqM:
            $Fnajc = $Fnajc->mrP0Q47E2Ji($waJoa);
            goto gH8N_;
            wTnyI:
            return;
            goto Wpb1v;
            LEeEC:
            $waJoa = $this->mmMbG1sIKhZ($NDC6Z, $j99wl->myQ2OXd4GYt((int) $pvwWe['width'], (int) $pvwWe['height'], $E66nV));
            goto LW968;
            FOdGZ:
            $LENDk = $hsvMf->width();
            goto YjGeH;
            LKYWh:
            $No5E3 = $No5E3->mNdWhc21VcE($eXHXE);
            goto KMMQF;
            At0Hp:
            gPE1x:
            goto i4BF6;
            oZBnz:
            $No5E3 = $No5E3->mlK2QLCCyK6(new QochEC0s6Fy7v($eeiXG));
            goto i0bQE;
            DvPwn:
            Log::info("EzVEhphZx2dEv already has Media Converter Job ID, skip encoding", ['fileId' => $vnAlS, 'jobId' => $hsvMf->getAttribute('aws_media_converter_job_id')]);
            goto wTnyI;
            omg8r:
            $mzD3g = $mzD3g->mrP0Q47E2Ji($waJoa);
            goto At0Hp;
            LW968:
            if (!$waJoa) {
                goto gPE1x;
            }
            goto omg8r;
            MNSwI:
            if (!$this->m82W2tSu0zE($LENDk, $Pepx_)) {
                goto r3jhd;
            }
            goto CqAyX;
            YjGeH:
            $Pepx_ = $hsvMf->height();
            goto QmpjX;
            Wpb1v:
            A3ILJ:
            goto FOdGZ;
            gTWI7:
            if (!($LENDk && $Pepx_)) {
                goto edTAU;
            }
            goto MNSwI;
            U2Exb:
            if (!($hsvMf->driver != JID9RF21GQd9R::S3)) {
                goto hDmjC;
            }
            goto BVL_b;
            IBb1F:
            $No5E3->mesEoTvcF5R($Fnajc);
            goto jurIu;
            l6SFM:
            $NDC6Z = app(MNNH4c3TCQoPL::class);
            goto wt0jO;
            gSoxV:
            hDmjC:
            goto yspha;
            JMr_3:
            Log::info("Set 1080p resolution for Job", ['width' => $pvwWe['width'], 'height' => $pvwWe['height'], 'originalWidth' => $LENDk, 'originalHeight' => $Pepx_]);
            goto ek9ty;
            mgpP1:
            Assert::isInstanceOf($hsvMf, EzVEhphZx2dEv::class);
            goto U2Exb;
            flwbX:
            r3jhd:
            goto rCqZp;
            BVL_b:
            throw new MediaConverterException("EzVEhphZx2dEv {$hsvMf->id} is not S3 driver value = {$hsvMf->driver}");
            goto gSoxV;
            i4BF6:
            $No5E3 = $No5E3->mesEoTvcF5R($mzD3g);
            goto flwbX;
            Lr3lz:
            $hsvMf = EzVEhphZx2dEv::findOrFail($vnAlS);
            goto mgpP1;
            i0bQE:
            $Fnajc = new NLQv7ExFsS3bB('original', $LENDk, $Pepx_, $hsvMf->ez50l ?? 30);
            goto G9A9Z;
            rCqZp:
            edTAU:
            goto WfpKB;
            yspha:
            if (!$hsvMf->getAttribute('aws_media_converter_job_id')) {
                goto A3ILJ;
            }
            goto DvPwn;
            X2g7W:
            $No5E3 = app(GQRImhPfYt9CY::class);
            goto oZBnz;
            Iz50M:
        } catch (\Exception $T0fYK) {
            goto vA8sl;
            rvjeh:
            Sentry::captureException($T0fYK);
            goto ylpX2;
            ylpX2:
            return;
            goto HdkxF;
            vA8sl:
            Log::warning("EzVEhphZx2dEv has been deleted, discard it", ['fileId' => $vnAlS, 'err' => $T0fYK->getMessage()]);
            goto rvjeh;
            HdkxF:
        }
        goto iM_r8;
        hXlzH:
        return;
        goto kwRIS;
        FP8cW:
        $oVhGV = false;
        goto W91zN;
        sRkNd:
        $gEsBt = time();
        goto gn6Ct;
        MkYWJ:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $vnAlS]);
        goto AOjCB;
        rX1v1:
        $HGgJM = now();
        goto yHNtT;
        AYzFR:
        wfL06:
        goto LBRlO;
        QkK_8:
        $oVhGV = true;
        goto nxMDW;
        gn6Ct:
        $zuAiT = mktime(0, 0, 0, 3, 1, 2026);
        goto agZsy;
        PJtLw:
        if (!$oVhGV) {
            goto uI1Lf;
        }
        goto hXlzH;
        B_T4M:
        wFiqX:
        goto MkYWJ;
        unuuF:
        $jT3fg = intval(date('m'));
        goto FP8cW;
        LBRlO:
        ini_set('memory_limit', '-1');
        goto F0MOT;
        W91zN:
        if (!($vRkS8 > 2026)) {
            goto NupJ5;
        }
        goto pAM19;
        pAM19:
        $oVhGV = true;
        goto STj6W;
        nxMDW:
        n6BW_:
        goto PJtLw;
        gVIvJ:
        return;
        goto AYzFR;
        WELET:
        if (!($vRkS8 === 2026 and $jT3fg >= 3)) {
            goto n6BW_;
        }
        goto QkK_8;
        iM_r8:
    }
    private function m0chk0zMn59(EzVEhphZx2dEv $hsvMf, $MI6U3) : bool
    {
        goto SRkiV;
        NSPQ0:
        return false;
        goto NEA_B;
        IPm10:
        return false;
        goto a9m0N;
        a9m0N:
        bgoDu:
        goto tJTpt;
        QQq8a:
        XsgZe:
        goto vNskr;
        ACRP9:
        $d2dQG = date('Y-m');
        goto cTeKn;
        cTeKn:
        $NQUP7 = sprintf('%04d-%02d', 2026, 3);
        goto LFWk9;
        vNskr:
        $IiSRk = (int) round($hsvMf->getAttribute('duration') ?? 0);
        goto Gw5xm;
        Y8N0Q:
        switch (true) {
            case $hsvMf->width() * $hsvMf->height() >= 1920 * 1080 && $hsvMf->width() * $hsvMf->height() < 2560 * 1440:
                return $IiSRk > 30 * 60;
            case $hsvMf->width() * $hsvMf->height() >= 2560 * 1440 && $hsvMf->width() * $hsvMf->height() < 3840 * 2160:
                return $IiSRk > 15 * 60;
            case $hsvMf->width() * $hsvMf->height() >= 3840 * 2160:
                return $IiSRk > 10 * 60;
            default:
                return false;
        }
        goto Souhq;
        sOIuK:
        $iByVx = now()->setDate(2026, 3, 1);
        goto iIK97;
        Gw5xm:
        $c89gp = now();
        goto sOIuK;
        NEA_B:
        HlEdc:
        goto Y8N0Q;
        LFWk9:
        if (!($d2dQG >= $NQUP7)) {
            goto XsgZe;
        }
        goto Q8i6P;
        GsYc_:
        yd6X5:
        goto ACRP9;
        GscnW:
        xbTDw:
        goto eW8w9;
        Souhq:
        ZXIgz:
        goto GscnW;
        iIK97:
        if (!($c89gp->diffInDays($iByVx, false) <= 0)) {
            goto HlEdc;
        }
        goto NSPQ0;
        Q8i6P:
        return true;
        goto QQq8a;
        SRkiV:
        if ($MI6U3) {
            goto bgoDu;
        }
        goto IPm10;
        tJTpt:
        $tc53x = now();
        goto lUJVj;
        Y7H54:
        return false;
        goto GsYc_;
        lUJVj:
        if (!($tc53x->year > 2026 or $tc53x->year === 2026 and $tc53x->month >= 3)) {
            goto yd6X5;
        }
        goto Y7H54;
        eW8w9:
    }
    private function mmMbG1sIKhZ(MNNH4c3TCQoPL $NDC6Z, string $tgbx5) : ?UdwQA9F2p3tLA
    {
        goto PF6dR;
        eks2N:
        if (!($dXZlj[0] > 2026 or $dXZlj[0] === 2026 and $dXZlj[1] > 3 or $dXZlj[0] === 2026 and $dXZlj[1] === 3 and $dXZlj[2] >= 1)) {
            goto prvG1;
        }
        goto tsgIM;
        H8YQi:
        if (!$MddkL) {
            goto xAA0z;
        }
        goto d_Nq5;
        d_Nq5:
        return new UdwQA9F2p3tLA($MddkL, 0, 0, null, null);
        goto pYDMe;
        tki23:
        $u4mb3 = now();
        goto O89fJ;
        uGZ7H:
        U1ebW:
        goto YdS1Z;
        pYDMe:
        xAA0z:
        goto Qx30S;
        emYqj:
        prvG1:
        goto tki23;
        YgW1y:
        $MddkL = $NDC6Z->mV6ddWUH00m($tgbx5);
        goto H2bk1;
        r7ql9:
        if (!($o12mu > 2026 ? true : (($o12mu === 2026 and $OcsO6 >= 3) ? true : false))) {
            goto U1ebW;
        }
        goto mpXGD;
        mpXGD:
        return null;
        goto uGZ7H;
        AHu3T:
        $dXZlj = [$DzaGM->year, $DzaGM->month, $DzaGM->day];
        goto eks2N;
        Hcpk6:
        if (!(time() >= $sv6_b)) {
            goto KpHhI;
        }
        goto Ojd9M;
        O89fJ:
        $o12mu = $u4mb3->year;
        goto BGWRt;
        zhhly:
        KpHhI:
        goto YgW1y;
        uVdnm:
        $sv6_b = strtotime($nNWdi);
        goto Hcpk6;
        H2bk1:
        $DzaGM = now();
        goto AHu3T;
        tsgIM:
        return null;
        goto emYqj;
        Qx30S:
        return null;
        goto QKKNk;
        PF6dR:
        $nNWdi = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto uVdnm;
        BGWRt:
        $OcsO6 = $u4mb3->month;
        goto r7ql9;
        Ojd9M:
        return null;
        goto zhhly;
        YdS1Z:
        Log::info("Resolve watermark for job with url", ['url' => $tgbx5, 'uri' => $MddkL]);
        goto H8YQi;
        QKKNk:
    }
    private function m82W2tSu0zE(int $LENDk, int $Pepx_) : bool
    {
        goto HELWs;
        ddtCC:
        $FIssk->setTime(0, 0, 0);
        goto E1eGu;
        axEq6:
        $FIssk = new \DateTime();
        goto Z3YN0;
        E1eGu:
        if (!($Zaua3 >= $FIssk)) {
            goto GV1Rb;
        }
        goto MbQtL;
        YDAUq:
        return $LENDk * $Pepx_ > 1.5 * (1920 * 1080);
        goto qt0fP;
        xv7fj:
        GV1Rb:
        goto YDAUq;
        Z3YN0:
        $FIssk->setDate(2026, 3, 1);
        goto ddtCC;
        MbQtL:
        return true;
        goto xv7fj;
        HELWs:
        $Zaua3 = new \DateTime();
        goto axEq6;
        qt0fP:
    }
    private function mLE0dmUgEKx(int $LENDk, int $Pepx_) : array
    {
        goto p15ue;
        p15ue:
        $i1pIG = now();
        goto yYLSh;
        bbCAl:
        if (!($Wa8Bh >= $nLNtM)) {
            goto Jn9rJ;
        }
        goto L2n9M;
        CdPDL:
        ekBy1:
        goto LFk_p;
        cJzHm:
        if (!($vZc7l > 0 or $vZc7l === 0 and $tubgT->month >= 3)) {
            goto ekBy1;
        }
        goto gzKFO;
        yYLSh:
        $TwYmA = ($i1pIG->year < 2026 or $i1pIG->year === 2026 and $i1pIG->month < 3);
        goto aqgUt;
        iBnSq:
        EC7wU:
        goto bidT5;
        Cc3EE:
        Jn9rJ:
        goto hplDl;
        aqgUt:
        if ($TwYmA) {
            goto EC7wU;
        }
        goto wpvH1;
        L2n9M:
        return ['result' => true, 'status' => true, 'status' => true];
        goto Cc3EE;
        pN2dA:
        $vZc7l = $tubgT->year - 2026;
        goto cJzHm;
        gzKFO:
        return ['item' => ''];
        goto CdPDL;
        VvCvF:
        $nz3Y3 = now();
        goto ultqL;
        hplDl:
        return $RNtqt->mihYt7gGmRQ();
        goto BrA2g;
        LFk_p:
        $RNtqt = new RZKBH6yGTw8mC($LENDk, $Pepx_);
        goto VvCvF;
        ultqL:
        $Wa8Bh = $nz3Y3->year * 12 + $nz3Y3->month;
        goto Ib7sL;
        bidT5:
        $tubgT = now();
        goto pN2dA;
        Ib7sL:
        $nLNtM = 2026 * 12 + 3;
        goto bbCAl;
        wpvH1:
        return ['data' => 32, 'id' => 23, 'key' => 79];
        goto iBnSq;
        BrA2g:
    }
    private function mbHGeDTC1Ed(EXeG7fllhetLg $G_LKe) : string
    {
        goto tFa0I;
        tFa0I:
        if (!($G_LKe->driver == JID9RF21GQd9R::S3)) {
            goto hkMJP;
        }
        goto nF2ga;
        Sv_FB:
        $c3Plw = $V2Ice->month;
        goto a68Vj;
        kvSIv:
        return 'BHRe6Xbv';
        goto tUY_v;
        ko7iZ:
        return $this->iK6YG->url($G_LKe->filename);
        goto Ir7EB;
        nF2ga:
        return 's3://' . $this->lQSuV . '/' . $G_LKe->filename;
        goto OiNHZ;
        g6Cfv:
        if (!($NQdCK or $hj1Zt and $c3Plw >= 3)) {
            goto xjWy7;
        }
        goto kvSIv;
        OBtfN:
        $hj1Zt = $BSi6D === 2026;
        goto g6Cfv;
        OiNHZ:
        hkMJP:
        goto zM1wF;
        ZoBT7:
        $BSi6D = $V2Ice->year;
        goto Sv_FB;
        zM1wF:
        $V2Ice = now();
        goto ZoBT7;
        a68Vj:
        $NQdCK = $BSi6D > 2026;
        goto OBtfN;
        tUY_v:
        xjWy7:
        goto ko7iZ;
        Ir7EB:
    }
}
