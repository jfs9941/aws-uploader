<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class NxAwZoQC5RZsb implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $zV1kl) : void
    {
        goto FuWOP;
        S4sDW:
        dFdEF:
        goto KGwc2;
        FuWOP:
        $EVGvq = UYo98bF5lKEmO::findOrFail($zV1kl);
        goto yEWcs;
        yEWcs:
        if ($EVGvq->width() > 0 && $EVGvq->height() > 0) {
            goto dFdEF;
        }
        goto aQQm5;
        aQQm5:
        $this->mrbPPWsT6t4($EVGvq);
        goto S4sDW;
        KGwc2:
    }
    private function mrbPPWsT6t4(UYo98bF5lKEmO $sLwwk) : void
    {
        goto XRi_s;
        sE5L9:
        $zacay = FFMpeg::fromDisk($IXkvc)->open($sLwwk->getAttribute('filename'));
        goto eqWVT;
        ASy9U:
        $f8HfD = $cSVza->getDimensions();
        goto EPIf2;
        XRi_s:
        $IXkvc = $sLwwk->getAttribute('driver') === 1 ? 's3' : 'public';
        goto sE5L9;
        eqWVT:
        $cSVza = $zacay->getVideoStream();
        goto ASy9U;
        EPIf2:
        $sLwwk->update(['duration' => $zacay->getDurationInSeconds(), 'resolution' => $f8HfD->getWidth() . 'x' . $f8HfD->getHeight(), 'fps' => $cSVza->get('r_frame_rate') ?? 30]);
        goto v4tTl;
        v4tTl:
    }
}
