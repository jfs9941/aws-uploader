<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class XpSmd1XibkE3q implements GenerateThumbnailForVideoInterface
{
    private $nIyy4;
    public function __construct($Gc72q)
    {
        $this->nIyy4 = $Gc72q;
    }
    public function generate(string $R7IrL) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $R7IrL);
        $this->nIyy4->createThumbnail($R7IrL);
    }
}
