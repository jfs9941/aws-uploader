<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Illuminate\Support\Facades\Log;
class KaGHuNXFVgGmh implements DownloadToLocalJobInterface
{
    private $UoQI7;
    private $pCaD7;
    public function __construct($UjVft, $P3zvl)
    {
        $this->UoQI7 = $UjVft;
        $this->pCaD7 = $P3zvl;
    }
    public function download(string $InHEz) : void
    {
        goto WjEKu;
        FAo5G:
        $this->pCaD7->put($YEF57->getLocation(), $this->UoQI7->get($YEF57->getLocation()));
        goto N5YCZ;
        gVvSP:
        if (!$this->pCaD7->exists($YEF57->getLocation())) {
            goto l9pWl;
        }
        goto rLv1K;
        WjEKu:
        $YEF57 = UKkbXBDRxjSUY::findOrFail($InHEz);
        goto HRD49;
        HRD49:
        Log::info("Start download file to local", ['fileId' => $InHEz, 'filename' => $YEF57->getLocation()]);
        goto gVvSP;
        rLv1K:
        return;
        goto smP81;
        smP81:
        l9pWl:
        goto FAo5G;
        N5YCZ:
    }
}
