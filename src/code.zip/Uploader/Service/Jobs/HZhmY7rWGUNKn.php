<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class HZhmY7rWGUNKn implements StoreToS3JobInterface
{
    private $mwf2R;
    private $Vhcrn;
    private $riMoE;
    public function __construct($eF8NA, $Klx1U, $BP_p5)
    {
        goto YoYeh;
        YoYeh:
        $this->Vhcrn = $Klx1U;
        goto AgjY9;
        AgjY9:
        $this->riMoE = $BP_p5;
        goto m8neh;
        m8neh:
        $this->mwf2R = $eF8NA;
        goto XurED;
        XurED:
    }
    public function store(string $mfjeD) : void
    {
        goto tJ2J0;
        aHXnr:
        GjV9s:
        goto j0Vz1;
        TSzWX:
        TQAgP:
        goto mHPK5;
        WtsOd:
        $D7Hgf = $this->riMoE->path($RIEMb);
        goto QWycF;
        ju3Uq:
        $o70_W = $this->riMoE->path($UaX2R->getAttribute('preview'));
        goto p_AQb;
        GK5Z0:
        $this->Vhcrn->put($UaX2R->getAttribute('thumbnail'), $this->riMoE->get($RIEMb), ['visibility' => 'public', 'ContentType' => $XGdv1->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto aHXnr;
        cIHnY:
        if (!$UaX2R->update(['driver' => GTmWxMidiCuj0::S3, 'status' => SwAwanZG36Yx6::FINISHED])) {
            goto y4vOz;
        }
        goto bhae4;
        Pc2kj:
        $RIEMb = $UaX2R->getAttribute('thumbnail');
        goto sEHxg;
        p_AQb:
        $V9RH6 = $this->mwf2R->call($this, $o70_W);
        goto Bxbw4;
        O80_I:
        DsyQbNiy8VgJG::where('parent_id', $mfjeD)->update(['driver' => GTmWxMidiCuj0::S3, 'preview' => $UaX2R->getAttribute('preview'), 'thumbnail' => $UaX2R->getAttribute('thumbnail'), 'webp_path' => $UaX2R->getAttribute('webp_path')]);
        goto Gw3RN;
        Niov6:
        uV6cN:
        goto cIHnY;
        igAAH:
        $this->mWcGjwkxGBK($J9IgU, $UaX2R->getLocation(), '.webp');
        goto Pc2kj;
        rqNH6:
        if ($UaX2R) {
            goto TQAgP;
        }
        goto rwQ4a;
        Gw3RN:
        return;
        goto I4Om_;
        mHPK5:
        $J9IgU = $this->riMoE->path($UaX2R->getLocation());
        goto ZAYbO;
        Bxbw4:
        $this->Vhcrn->put($UaX2R->getAttribute('preview'), $this->riMoE->get($UaX2R->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $V9RH6->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Niov6;
        tJ2J0:
        $UaX2R = DsyQbNiy8VgJG::findOrFail($mfjeD);
        goto rqNH6;
        bhae4:
        Log::info("DsyQbNiy8VgJG stored to S3, update the children attachments", ['fileId' => $mfjeD]);
        goto O80_I;
        sEHxg:
        if (!($RIEMb && $this->riMoE->exists($RIEMb))) {
            goto GjV9s;
        }
        goto WtsOd;
        I4Om_:
        y4vOz:
        goto ssTN0;
        tnzN3:
        return;
        goto TSzWX;
        ZAYbO:
        $this->mWcGjwkxGBK($J9IgU, $UaX2R->getLocation());
        goto igAAH;
        QWycF:
        $XGdv1 = $this->mwf2R->call($this, $D7Hgf);
        goto GK5Z0;
        rwQ4a:
        Log::info("DsyQbNiy8VgJG has been deleted, discard it", ['fileId' => $mfjeD]);
        goto tnzN3;
        ssTN0:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $mfjeD]);
        goto v1WQG;
        j0Vz1:
        if (!($UaX2R->getAttribute('preview') && $this->riMoE->exists($UaX2R->getAttribute('preview')))) {
            goto uV6cN;
        }
        goto ju3Uq;
        v1WQG:
    }
    private function mWcGjwkxGBK($iR1jy, $p9T4R, $wbMgP = '')
    {
        goto s0jur;
        s0jur:
        if (!$wbMgP) {
            goto xXELX;
        }
        goto ewCLd;
        ewCLd:
        $iR1jy = str_replace('.jpg', $wbMgP, $iR1jy);
        goto Lky3i;
        FAiXW:
        try {
            $fK3zd = $this->mwf2R->call($this, $iR1jy);
            $this->Vhcrn->put($p9T4R, $this->riMoE->get($p9T4R), ['visibility' => 'public', 'ContentType' => $fK3zd->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $tPAjT) {
            Log::error("Failed to upload image to S3", ['s3Path' => $p9T4R, 'error' => $tPAjT->getMessage()]);
        }
        goto zTawX;
        Lky3i:
        $p9T4R = str_replace('.jpg', $wbMgP, $p9T4R);
        goto H2Gsu;
        H2Gsu:
        xXELX:
        goto FAiXW;
        zTawX:
    }
}
