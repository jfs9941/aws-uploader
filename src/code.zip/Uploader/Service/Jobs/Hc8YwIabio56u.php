<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Hc8YwIabio56u implements CompressJobInterface
{
    const O25RI = 60;
    private $buleS;
    private $pCaD7;
    private $Svend;
    public function __construct($nFvaK, $P3zvl, $jQtQe)
    {
        goto YI6H3;
        uOafh:
        $this->pCaD7 = $P3zvl;
        goto A4IKk;
        rKXAA:
        $this->Svend = $jQtQe;
        goto uOafh;
        YI6H3:
        $this->buleS = $nFvaK;
        goto rKXAA;
        A4IKk:
    }
    public function compress(string $InHEz)
    {
        goto J_Ag2;
        KZ3Xu:
        $LOR1V = memory_get_peak_usage();
        goto dzXTY;
        V5h7e:
        $TNT8K = memory_get_usage();
        goto KZ3Xu;
        PU2qV:
        try {
            goto Av7Wj;
            Av7Wj:
            $VGttq = UKkbXBDRxjSUY::findOrFail($InHEz);
            goto hV3jy;
            PrT_b:
            if (!(strtolower($VGttq->getExtension()) === 'png' || strtolower($VGttq->getExtension()) === 'heic')) {
                goto JOSnM;
            }
            goto tIURq;
            bLsB3:
            try {
                goto SM0te;
                FlPy7:
                $this->mPua2jf7N43($VGttq, 'webp');
                goto DHJ5c;
                S2DBL:
                $this->mnGYmxYVPUm($Qsav4, $DKxB0);
                goto FlPy7;
                SM0te:
                $DKxB0 = $this->pCaD7->path(str_replace('.jpg', '.webp', $VGttq->getLocation()));
                goto S2DBL;
                DHJ5c:
            } catch (\Exception $uF3lz) {
                goto KYNIt;
                XoILb:
                $DKxB0 = $this->pCaD7->path($VGttq->getLocation());
                goto qvoOZ;
                KYNIt:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $InHEz, 'error' => $uF3lz->getMessage()]);
                goto XoILb;
                qvoOZ:
                $this->mq7SU15Spl9($Qsav4, $DKxB0);
                goto B08o8;
                B08o8:
            }
            goto KCnS6;
            hV3jy:
            $Qsav4 = $this->pCaD7->path($VGttq->getLocation());
            goto PrT_b;
            tIURq:
            $VGttq = $this->mPua2jf7N43($VGttq, 'jpg');
            goto ZZiVi;
            ZZiVi:
            JOSnM:
            goto bLsB3;
            KCnS6:
        } catch (\Throwable $uF3lz) {
            goto Yt8Fn;
            nBLi7:
            xWIhB:
            goto ouik0;
            ZNVXw:
            Log::info("UKkbXBDRxjSUY has been deleted, discard it", ['imageId' => $InHEz]);
            goto mP4n3;
            Yt8Fn:
            if (!$uF3lz instanceof ModelNotFoundException) {
                goto xWIhB;
            }
            goto ZNVXw;
            ouik0:
            Log::error("Failed to compress image", ['imageId' => $InHEz, 'error' => $uF3lz->getMessage()]);
            goto tvEV7;
            mP4n3:
            return;
            goto nBLi7;
            tvEV7:
        } finally {
            $xYgEl = microtime(true);
            $FqOnS = memory_get_usage();
            $U8b7Q = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $InHEz, 'execution_time_sec' => $xYgEl - $Eceqa, 'memory_usage_mb' => ($FqOnS - $TNT8K) / 1024 / 1024, 'peak_memory_usage_mb' => ($U8b7Q - $LOR1V) / 1024 / 1024]);
        }
        goto n9O6w;
        dzXTY:
        Log::info("Compress image", ['imageId' => $InHEz]);
        goto PU2qV;
        J_Ag2:
        $Eceqa = microtime(true);
        goto V5h7e;
        n9O6w:
    }
    private function mq7SU15Spl9($Qsav4, $DKxB0)
    {
        goto u3L26;
        yEJTV:
        unset($PI2hl);
        goto L9ri6;
        hTHHY:
        $PI2hl->orient()->toJpeg(self::O25RI)->save($DKxB0);
        goto eo6AP;
        u3L26:
        $PI2hl = $this->buleS->call($this, $Qsav4);
        goto hTHHY;
        eo6AP:
        $this->Svend->put($DKxB0, $PI2hl->toJpeg(self::O25RI), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto yEJTV;
        L9ri6:
    }
    private function mnGYmxYVPUm($Qsav4, $DKxB0)
    {
        goto FUNWN;
        WR1Tu:
        unset($PI2hl);
        goto H2sNI;
        FUNWN:
        $PI2hl = $this->buleS->call($this, $Qsav4);
        goto uN2BN;
        K6Yqp:
        $this->Svend->put($DKxB0, $PI2hl->toJpeg(self::O25RI), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto WR1Tu;
        uN2BN:
        $PI2hl->orient()->toWebp(self::O25RI);
        goto K6Yqp;
        H2sNI:
    }
    private function mPua2jf7N43($VGttq, $LWqUl)
    {
        goto P2OM1;
        ZiaH3:
        $VGttq->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$LWqUl}", $VGttq->getLocation()));
        goto Pmqoq;
        CItGa:
        return $VGttq;
        goto z9pw7;
        P2OM1:
        $VGttq->setAttribute('type', $LWqUl);
        goto ZiaH3;
        Pmqoq:
        $VGttq->save();
        goto CItGa;
        z9pw7:
    }
}
