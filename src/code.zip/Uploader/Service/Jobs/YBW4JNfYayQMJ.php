<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
class YBW4JNfYayQMJ implements BlurJobInterface
{
    const NwGhq = 15;
    const JDAdP = 500;
    const VfFIV = 500;
    private $X2VAb;
    private $Mayr9;
    private $nEL6Z;
    public function __construct($aC0aM, $KI4Gx, $vWt2S)
    {
        goto KW3hU;
        KW3hU:
        $this->nEL6Z = $vWt2S;
        goto Yj8A9;
        Jn3eG:
        $this->X2VAb = $aC0aM;
        goto ccBty;
        Yj8A9:
        $this->Mayr9 = $KI4Gx;
        goto Jn3eG;
        ccBty:
    }
    public function blur(string $iG1wy) : void
    {
        goto kevCv;
        pGIPH:
        $NnB1V->update(['preview' => $JFak1]);
        goto NJE9t;
        qkNJH:
        throw new \Exception('Failed to set final permissions on image file: ' . $xOCo0);
        goto TVnu3;
        TVnu3:
        FOfMB:
        goto pGIPH;
        W14cU:
        unset($cDDGh);
        goto kORMx;
        Ra2MI:
        $this->nEL6Z->put($NnB1V->filename, $p9FCT);
        goto CXM5_;
        kevCv:
        $NnB1V = KyoDVfv3eGItF::findOrFail($iG1wy);
        goto OS2th;
        WR99U:
        $JFak1 = $this->mWZUIOYeINf($NnB1V);
        goto THOQZ;
        kORMx:
        if (chmod($xOCo0, 0664)) {
            goto FOfMB;
        }
        goto usCh7;
        OS2th:
        ini_set('memory_limit', '-1');
        goto l7ekM;
        VncXZ:
        $cDDGh->blur(self::NwGhq);
        goto WR99U;
        KhsEV:
        $cDDGh->resize(self::JDAdP, self::VfFIV / $J0wvK);
        goto VncXZ;
        THOQZ:
        $xOCo0 = $this->Mayr9->put($JFak1, $cDDGh->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto W14cU;
        B5qbr:
        $J0wvK = $cDDGh->width() / $cDDGh->height();
        goto KhsEV;
        usCh7:
        \Log::warning('Failed to set final permissions on image file: ' . $xOCo0);
        goto qkNJH;
        l7ekM:
        if (!($NnB1V->driver == Ef6Dy6MoUDei9::S3 && !$this->nEL6Z->exists($NnB1V->filename))) {
            goto G28Tq;
        }
        goto y12kI;
        y12kI:
        $p9FCT = $this->Mayr9->get($NnB1V->filename);
        goto Ra2MI;
        XW2zw:
        $cDDGh = $this->X2VAb->call($this, $this->nEL6Z->path($NnB1V->getLocation()));
        goto B5qbr;
        CXM5_:
        G28Tq:
        goto XW2zw;
        NJE9t:
    }
    private function mWZUIOYeINf($p1zVs) : string
    {
        goto yzFEi;
        yYVFD:
        VRS81:
        goto TCj6S;
        TCj6S:
        return $qmsbj . $p1zVs->getFilename() . '.jpg';
        goto sRFYF;
        fzaEg:
        $qmsbj = dirname($HCRCz) . '/preview/';
        goto VFsqN;
        yzFEi:
        $HCRCz = $p1zVs->getLocation();
        goto fzaEg;
        VFsqN:
        if ($this->nEL6Z->exists($qmsbj)) {
            goto VRS81;
        }
        goto sREC3;
        sREC3:
        $this->nEL6Z->makeDirectory($qmsbj, 0755, true);
        goto yYVFD;
        sRFYF:
    }
}
