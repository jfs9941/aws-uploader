<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\BAg6f47W8nEsi;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class N8QZCKh8bqKKO implements BAg6f47W8nEsi
{
    const V8_pe = 150;
    const WjYpe = 150;
    private $W3SEw;
    private $c35HU;
    private $Jn_QL;
    public function __construct($DrcMD, $VHhUy, $kywm2)
    {
        goto gPXre;
        gHUkL:
        $this->c35HU = $VHhUy;
        goto wAysq;
        gPXre:
        $this->W3SEw = $DrcMD;
        goto gHUkL;
        wAysq:
        $this->Jn_QL = $kywm2;
        goto h_nVE;
        h_nVE:
    }
    public function generate(string $EQQae)
    {
        goto i6d74;
        MIakM:
        ini_set('memory_limit', '-1');
        goto ZoXic;
        ZoXic:
        try {
            goto UwE3j;
            Drbt3:
            $QGELJ = $this->W3SEw->call($this, $UEDUm->path($ulojh->getLocation()));
            goto vVOFc;
            UwE3j:
            $UEDUm = $this->c35HU;
            goto MTcho;
            NYJrj:
            $ulojh->update(['thumbnail' => $KPnwr, 'status' => Aetm2HiFuJE34::THUMBNAIL_PROCESSED]);
            goto s3uhL;
            A2Ex9:
            if (!($TC80E !== false)) {
                goto hobmw;
            }
            goto NYJrj;
            s3uhL:
            hobmw:
            goto H6Xv4;
            wkTC6:
            $TC80E = $this->Jn_QL->put($KPnwr, $QGELJ->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto olgi_;
            sqcif:
            $KPnwr = $this->mKEcdzzpsX5($ulojh);
            goto wkTC6;
            olgi_:
            unset($QGELJ);
            goto A2Ex9;
            vVOFc:
            $QGELJ->orient()->resize(150, 150);
            goto sqcif;
            MTcho:
            $ulojh = CrEYqpC23XUGo::findOrFail($EQQae);
            goto Drbt3;
            H6Xv4:
        } catch (ModelNotFoundException $AfYww) {
            Log::info("CrEYqpC23XUGo has been deleted, discard it", ['imageId' => $EQQae]);
            return;
        } catch (\Exception $AfYww) {
            Log::error("Failed to generate thumbnail", ['imageId' => $EQQae, 'error' => $AfYww->getMessage()]);
        }
        goto ITeQY;
        i6d74:
        Log::info("Generating thumbnail", ['imageId' => $EQQae]);
        goto MIakM;
        ITeQY:
    }
    private function mKEcdzzpsX5(PJqa0Yy2jwBHe $ulojh) : string
    {
        goto axHE5;
        XCKVb:
        $wUPbs = $La3UL . '/' . self::V8_pe . 'X' . self::WjYpe;
        goto AuDqr;
        AuDqr:
        return $wUPbs . '/' . $ulojh->getFilename() . '.jpg';
        goto rG_Pm;
        oKg1O:
        $La3UL = dirname($KPnwr);
        goto XCKVb;
        axHE5:
        $KPnwr = $ulojh->getLocation();
        goto oKg1O;
        rG_Pm:
    }
}
