<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
class Pjc7ziAFrDbW8 implements BlurJobInterface
{
    const tzqDf = 15;
    const kqQEI = 500;
    const f9Oze = 500;
    private $vn9CJ;
    private $aiw3M;
    private $n8EBo;
    public function __construct($HL7fw, $iay5S, $gdQ3g)
    {
        goto cnI0W;
        sTLDW:
        $this->aiw3M = $iay5S;
        goto ESYHI;
        cnI0W:
        $this->n8EBo = $gdQ3g;
        goto sTLDW;
        ESYHI:
        $this->vn9CJ = $HL7fw;
        goto PfV0r;
        PfV0r:
    }
    public function blur(string $zV1kl) : void
    {
        goto YSdyA;
        Tdblf:
        $Ryfn0 = $RD3vr->width() / $RD3vr->height();
        goto ycTZC;
        TvMu1:
        $hBJM1 = $this->aiw3M->put($rxy1g, $RD3vr->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto JQAEw;
        ymndV:
        $this->n8EBo->put($r1gi8->filename, $fl7NN);
        goto gaR0L;
        XF471:
        if (chmod($hBJM1, 0664)) {
            goto rO1_D;
        }
        goto wXuEY;
        IE6Kn:
        ini_set('memory_limit', '-1');
        goto obx57;
        wXuEY:
        \Log::warning('Failed to set final permissions on image file: ' . $hBJM1);
        goto Jw2uC;
        ujHQ2:
        $rxy1g = $this->mKx2eItiSBx($r1gi8);
        goto TvMu1;
        JQAEw:
        unset($RD3vr);
        goto XF471;
        gaR0L:
        JsKOq:
        goto ToSar;
        SALQS:
        $r1gi8->update(['preview' => $rxy1g]);
        goto dT3Zl;
        Jw2uC:
        throw new \Exception('Failed to set final permissions on image file: ' . $hBJM1);
        goto dQgGb;
        dQgGb:
        rO1_D:
        goto SALQS;
        YSdyA:
        $r1gi8 = KCmQR4pvm0dT3::findOrFail($zV1kl);
        goto IE6Kn;
        ToSar:
        $RD3vr = $this->vn9CJ->call($this, $this->n8EBo->path($r1gi8->getLocation()));
        goto Tdblf;
        ycTZC:
        $RD3vr->resize(self::kqQEI, self::f9Oze / $Ryfn0);
        goto SsVdX;
        obx57:
        if (!($r1gi8->driver == X4ZiOQdPeeHKI::S3 && !$this->n8EBo->exists($r1gi8->filename))) {
            goto JsKOq;
        }
        goto gPUn2;
        gPUn2:
        $fl7NN = $this->aiw3M->get($r1gi8->filename);
        goto ymndV;
        SsVdX:
        $RD3vr->blur(self::tzqDf);
        goto ujHQ2;
        dT3Zl:
    }
    private function mKx2eItiSBx($xVVfG) : string
    {
        goto qFsx7;
        BQ_wU:
        if ($this->n8EBo->exists($JRpFR)) {
            goto QbfB0;
        }
        goto O4ZIL;
        EjmUU:
        $JRpFR = dirname($lmTDq) . '/preview/';
        goto BQ_wU;
        O4ZIL:
        $this->n8EBo->makeDirectory($JRpFR, 0755, true);
        goto UrnnN;
        qFsx7:
        $lmTDq = $xVVfG->getLocation();
        goto EjmUU;
        UrnnN:
        QbfB0:
        goto R8CJ3;
        R8CJ3:
        return $JRpFR . $xVVfG->getFilename() . '.jpg';
        goto Rm4ck;
        Rm4ck:
    }
}
