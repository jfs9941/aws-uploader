<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class U0lMXXZ5ASfal implements GenerateThumbnailJobInterface
{
    const Jpouv = 150;
    const GG3Av = 150;
    private $o4nAt;
    private $Jhhox;
    private $hZygw;
    public function __construct($wpWQD, $bXh5v, $CJv_E)
    {
        goto aeiJ5;
        aeiJ5:
        $this->o4nAt = $wpWQD;
        goto PbOq5;
        PbOq5:
        $this->Jhhox = $bXh5v;
        goto Ck31n;
        Ck31n:
        $this->hZygw = $CJv_E;
        goto cj7s4;
        cj7s4:
    }
    public function generate(string $Brk87)
    {
        goto NcXu8;
        NcXu8:
        Log::info("Generating thumbnail", ['imageId' => $Brk87]);
        goto qKIUn;
        qKIUn:
        ini_set('memory_limit', '-1');
        goto yhBpt;
        yhBpt:
        try {
            goto ULVw0;
            xkpGj:
            $dsPgC->orient()->resize(150, 150);
            goto vN696;
            Cg_QK:
            $Kc1eZ->update(['thumbnail' => $F0ycc, 'status' => ZVJoOgH14iXBq::THUMBNAIL_PROCESSED]);
            goto AGzBg;
            vN696:
            $F0ycc = $this->mDJQZopJGq2($Kc1eZ);
            goto kDDVZ;
            KjMwn:
            if (!($B559P !== false)) {
                goto MVRjD;
            }
            goto Cg_QK;
            DEym9:
            $dsPgC = $this->o4nAt->call($this, $MKJ1D->path($Kc1eZ->getLocation()));
            goto xkpGj;
            kDDVZ:
            $B559P = $this->hZygw->put($F0ycc, $dsPgC->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto b1crc;
            b1crc:
            unset($dsPgC);
            goto KjMwn;
            AGzBg:
            MVRjD:
            goto CXbDd;
            lsoF0:
            $Kc1eZ = OjvWwjWRqBzIO::findOrFail($Brk87);
            goto DEym9;
            ULVw0:
            $MKJ1D = $this->Jhhox;
            goto lsoF0;
            CXbDd:
        } catch (ModelNotFoundException $fGlZL) {
            Log::info("OjvWwjWRqBzIO has been deleted, discard it", ['imageId' => $Brk87]);
            return;
        } catch (\Exception $fGlZL) {
            Log::error("Failed to generate thumbnail", ['imageId' => $Brk87, 'error' => $fGlZL->getMessage()]);
        }
        goto qG0mK;
        qG0mK:
    }
    private function mDJQZopJGq2(D3Q3lppZQonk9 $Kc1eZ) : string
    {
        goto FZcJ7;
        SwY0s:
        $qZzVN = $e1knD . '/' . self::Jpouv . 'X' . self::GG3Av;
        goto uYk7o;
        FZcJ7:
        $F0ycc = $Kc1eZ->getLocation();
        goto mBqgD;
        uYk7o:
        return $qZzVN . '/' . $Kc1eZ->getFilename() . '.jpg';
        goto F4oLZ;
        mBqgD:
        $e1knD = dirname($F0ycc);
        goto SwY0s;
        F4oLZ:
    }
}
