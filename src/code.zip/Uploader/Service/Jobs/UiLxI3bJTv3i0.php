<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class UiLxI3bJTv3i0
{
    private $BmRID;
    private $TOG_e;
    private $W_Kti;
    private $N3F9R;
    public function __construct($VtFJQ, $QLRyU, $agzKA, $mFX9i)
    {
        goto p3UtO;
        ml2vx:
        $this->N3F9R = $mFX9i;
        goto m90AX;
        m90AX:
        $this->BmRID = $VtFJQ;
        goto tu2r9;
        WptU4:
        $this->W_Kti = $agzKA;
        goto ml2vx;
        p3UtO:
        $this->TOG_e = $QLRyU;
        goto WptU4;
        tu2r9:
    }
    public function mShOxL4HISe(?int $K2lK4, ?int $Mq4V6, string $Hx65l, bool $f4yvG = false) : string
    {
        goto C9DLc;
        exSI6:
        $So5Ck = (int) ($OpwQp / 80);
        goto iRXUd;
        iRXUd:
        $OpwQp -= $So5Ck;
        goto doMMi;
        MNiBQ:
        return $f4yvG ? $IB9Pt : $this->W_Kti->url($IB9Pt);
        goto hp7_5;
        Tt0MU:
        yMvBy:
        goto Pcji0;
        KcAWu:
        list($Qd2fi, $SmWFj, $JAbXx) = $this->mQ37AlkHz15($Hx65l, $K2lK4, $hsF6F, (float) $K2lK4 / $Mq4V6);
        goto S8g30;
        xqMH0:
        $OpwQp -= $So5Ck * 0.4;
        goto Tt0MU;
        C9DLc:
        if (!($K2lK4 === null || $Mq4V6 === null)) {
            goto kHzUJ;
        }
        goto NRWGT;
        KCFg1:
        $OpwQp = $K2lK4 - $SmWFj;
        goto exSI6;
        BWzH2:
        if (!$this->W_Kti->exists($IB9Pt)) {
            goto AD5D7;
        }
        goto wYJNi;
        Pcji0:
        $p5Krm = $Mq4V6 - $Qd2fi - 10;
        goto xPVCA;
        xPVCA:
        $P2AJQ->text($JAbXx, $OpwQp, (int) $p5Krm, function ($lXY0g) use($Qd2fi) {
            goto VXC3n;
            e2BGI:
            $lXY0g->valign('middle');
            goto AVVhn;
            CR9Fw:
            $lXY0g->color([185, 185, 185, 1]);
            goto e2BGI;
            VLPdU:
            $lXY0g->size(max($fj3Y4, 1));
            goto CR9Fw;
            VXC3n:
            $lXY0g->file(iv6QR($this->TOG_e));
            goto qV5Ci;
            qV5Ci:
            $fj3Y4 = (int) ($Qd2fi * 1.2);
            goto VLPdU;
            AVVhn:
            $lXY0g->align('middle');
            goto KPyIT;
            KPyIT:
        });
        goto GgZyH;
        D0sVC:
        $hsF6F = 0.1;
        goto KcAWu;
        S8g30:
        $IB9Pt = $this->mfk5CaObXfr($JAbXx, $K2lK4, $Mq4V6, $SmWFj, $Qd2fi);
        goto BWzH2;
        fRs_h:
        AD5D7:
        goto LGsMR;
        QlIaD:
        $this->W_Kti->put($IB9Pt, $P2AJQ->stream('png'));
        goto MNiBQ;
        GgZyH:
        $this->N3F9R->put($IB9Pt, $P2AJQ->stream('png'));
        goto QlIaD;
        wYJNi:
        return $f4yvG ? $IB9Pt : $this->W_Kti->url($IB9Pt);
        goto fRs_h;
        doMMi:
        if (!($K2lK4 > 1500)) {
            goto yMvBy;
        }
        goto xqMH0;
        LGsMR:
        $P2AJQ = $this->BmRID->call($this, $K2lK4, $Mq4V6);
        goto KCFg1;
        OINC7:
        kHzUJ:
        goto D0sVC;
        NRWGT:
        throw new \RuntimeException("GXtnGiMmIPEIc dimensions are not available.");
        goto OINC7;
        hp7_5:
    }
    private function mfk5CaObXfr(string $Hx65l, int $K2lK4, int $Mq4V6, int $t6_RC, int $zJ3Vd) : string
    {
        $fZd6r = ltrim($Hx65l, '@');
        return "v2/watermark/{$fZd6r}/{$K2lK4}x{$Mq4V6}_{$t6_RC}x{$zJ3Vd}/text_watermark.png";
    }
    private function mQ37AlkHz15($Hx65l, int $K2lK4, float $dvH3N, float $pUtvf) : array
    {
        goto l8pTS;
        ch2bp:
        return [(int) $tbGaa, $tbGaa * strlen($JAbXx) / 1.8, $JAbXx];
        goto kRZvD;
        l8pTS:
        $JAbXx = '@' . $Hx65l;
        goto S3k9i;
        gLq8P:
        $tbGaa = 1 / $pUtvf * $SmWFj / strlen($JAbXx);
        goto CBz8j;
        Tbec7:
        $tbGaa = $SmWFj / (strlen($JAbXx) * 0.8);
        goto ch2bp;
        kRZvD:
        B46Kx:
        goto gLq8P;
        S3k9i:
        $SmWFj = (int) ($K2lK4 * $dvH3N);
        goto yP6bB;
        CBz8j:
        return [(int) $tbGaa, $SmWFj, $JAbXx];
        goto qzMIC;
        yP6bB:
        if (!($pUtvf > 1)) {
            goto B46Kx;
        }
        goto Tbec7;
        qzMIC:
    }
}
