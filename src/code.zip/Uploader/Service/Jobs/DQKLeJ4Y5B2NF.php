<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
class DQKLeJ4Y5B2NF implements BlurJobInterface
{
    const Ekf6C = 15;
    const w5aME = 500;
    const rVeig = 500;
    private $VnheV;
    private $SxfKN;
    private $GmmTj;
    public function __construct($wUcGa, $DPWG1, $MYo5D)
    {
        goto QCxW2;
        QCxW2:
        $this->GmmTj = $MYo5D;
        goto N3wmE;
        dWF3H:
        $this->VnheV = $wUcGa;
        goto cK3nn;
        N3wmE:
        $this->SxfKN = $DPWG1;
        goto dWF3H;
        cK3nn:
    }
    public function blur(string $GMwD5) : void
    {
        goto EtCIN;
        Vcppd:
        throw new \Exception('Failed to set final permissions on image file: ' . $NtHgB);
        goto ybcV6;
        kStLG:
        $dmeuh->blur(self::Ekf6C);
        goto lUmfA;
        dz5co:
        $dmeuh->resize(self::w5aME, self::rVeig / $AXz2I);
        goto kStLG;
        IIurc:
        $sg_2q->update(['preview' => $itPqF]);
        goto g_raq;
        WUV91:
        $this->GmmTj->put($sg_2q->filename, $JBGZN);
        goto WUyS9;
        lUmfA:
        $itPqF = $this->mTWuokivYSO($sg_2q);
        goto ioLOQ;
        AmJy3:
        $JBGZN = $this->SxfKN->get($sg_2q->filename);
        goto WUV91;
        WUyS9:
        PZns7:
        goto JwwYu;
        EtCIN:
        $sg_2q = C6ftQJKUZRJIp::findOrFail($GMwD5);
        goto ZnU_R;
        JwwYu:
        $dmeuh = $this->VnheV->call($this, $this->GmmTj->path($sg_2q->getLocation()));
        goto Ky0g0;
        PNC3V:
        if (!($sg_2q->NQ3st == CUySMhqlL7P49::S3 && !$this->GmmTj->exists($sg_2q->filename))) {
            goto PZns7;
        }
        goto AmJy3;
        fqP4k:
        \Log::warning('Failed to set final permissions on image file: ' . $NtHgB);
        goto Vcppd;
        jl1eu:
        unset($dmeuh);
        goto woWII;
        woWII:
        if (chmod($NtHgB, 0664)) {
            goto OsLZN;
        }
        goto fqP4k;
        ZnU_R:
        ini_set('memory_limit', '-1');
        goto PNC3V;
        Ky0g0:
        $AXz2I = $dmeuh->width() / $dmeuh->height();
        goto dz5co;
        ybcV6:
        OsLZN:
        goto IIurc;
        ioLOQ:
        $NtHgB = $this->SxfKN->put($itPqF, $dmeuh->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto jl1eu;
        g_raq:
    }
    private function mTWuokivYSO($PUY_t) : string
    {
        goto ORwdc;
        rqpZJ:
        BfCEj:
        goto pX0bm;
        vW8mD:
        $w6EkV = dirname($iTIh6) . '/preview/';
        goto imQdB;
        imQdB:
        if ($this->GmmTj->exists($w6EkV)) {
            goto BfCEj;
        }
        goto DrNKQ;
        pX0bm:
        return $w6EkV . $PUY_t->getFilename() . '.jpg';
        goto nO_mj;
        DrNKQ:
        $this->GmmTj->makeDirectory($w6EkV, 0755, true);
        goto rqpZJ;
        ORwdc:
        $iTIh6 = $PUY_t->getLocation();
        goto vW8mD;
        nO_mj:
    }
}
