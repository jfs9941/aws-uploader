<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Encoder\Hb3LYkcj2Y6p1;
use Jfs\Uploader\Encoder\LAuETCYTRzty9;
use Jfs\Uploader\Encoder\OGmQ0hQJzIYby;
use Jfs\Uploader\Encoder\YFHYa4NReTuPi;
use Jfs\Uploader\Encoder\UKW6hIg5vZR7f;
use Jfs\Uploader\Encoder\Alxlzu9Vtdk0x;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Uploader\Service\PP4BnfgX7sVAN;
use Webmozart\Assert\Assert;
class EDvFQ2Y6VjbT0 implements MediaEncodeJobInterface
{
    private $iqyyD;
    private $UBJ9G;
    private $gGE8I;
    private $hOV1v;
    private $SRWQz;
    public function __construct(string $TnK9g, $e1L33, $duBfR, $s_InJ, $FRjEq)
    {
        goto XgYa1;
        brVGY:
        $this->gGE8I = $duBfR;
        goto VyEb5;
        NB7LY:
        $this->UBJ9G = $e1L33;
        goto brVGY;
        XgYa1:
        $this->iqyyD = $TnK9g;
        goto NB7LY;
        VyEb5:
        $this->hOV1v = $s_InJ;
        goto SP93V;
        SP93V:
        $this->SRWQz = $FRjEq;
        goto nD2a3;
        nD2a3:
    }
    public function encode(string $ld8Ad, string $fbB2w, $aeirh = true) : void
    {
        goto C4N0k;
        C4N0k:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $ld8Ad]);
        goto LIfEG;
        LIfEG:
        ini_set('memory_limit', '-1');
        goto XNKDB;
        XNKDB:
        try {
            goto OmkQW;
            I0DMb:
            $Eo278->m6YRfvox6GB($a0naV->m8ERjHsMOsw($Ipllx));
            goto B6UdP;
            YQoao:
            $Q6fz2 = $this->mDesqCmaKY8($LtUvT, $eATF4->mAceo7BJgV2((int) $mDtJs['width'], (int) $mDtJs['height'], $fbB2w));
            goto jUhTP;
            Gi2U9:
            $LtUvT = app(PP4BnfgX7sVAN::class);
            goto Yl2Ed;
            qzxgt:
            Ah5Iw:
            goto cGY4T;
            fbIoc:
            $RO83a = $this->msVX9GnHpGz($Ipllx);
            goto XijSM;
            B6UdP:
            if (!($Gsmm4 && $iM4bK)) {
                goto Ah5Iw;
            }
            goto sA2v1;
            iExPa:
            O2Cwv:
            goto xkwZC;
            aUAhl:
            $DwjAH = new LAuETCYTRzty9('1080p', $mDtJs['width'], $mDtJs['height'], $Ipllx->Qin1Q ?? 30);
            goto YQoao;
            GuHRE:
            $Eo278 = $Eo278->mENMMTFgcoF($pBU9S);
            goto H0jGV;
            DpBIx:
            $Eo278 = $Eo278->mtsx23WNbib(new YFHYa4NReTuPi($RO83a));
            goto s1Xpb;
            GaaSL:
            $Eo278->mkCeqbbi6sY($b8CME);
            goto gY0UZ;
            q2muL:
            $Eo278 = $Eo278->mkCeqbbi6sY($DwjAH);
            goto Cd115;
            i4qyE:
            $iM4bK = $Ipllx->height();
            goto fbIoc;
            cUk3p:
            A3coz:
            goto q2muL;
            xkwZC:
            $Eo278->mkCeqbbi6sY($b8CME);
            goto I0DMb;
            Cd115:
            npslZ:
            goto qzxgt;
            nE7Cz:
            $Ipllx->update(['aws_media_converter_job_id' => $ld8Ad]);
            goto suIVM;
            sA2v1:
            if (!$this->mwkaAH4JFdF($Gsmm4, $iM4bK)) {
                goto npslZ;
            }
            goto Xi4YV;
            jUhTP:
            if (!$Q6fz2) {
                goto A3coz;
            }
            goto HRWFh;
            rmLWV:
            $pBU9S = new Hb3LYkcj2Y6p1($Ipllx->LeLge ?? 1, 2, $a0naV->mDGxAg2eqI5($Ipllx));
            goto GuHRE;
            gY0UZ:
            $Eo278->m6YRfvox6GB($a0naV->m8ERjHsMOsw($Ipllx));
            goto Gi2U9;
            ACNgz:
            $Q6fz2 = $this->mDesqCmaKY8($LtUvT, $eATF4->mAceo7BJgV2($Ipllx->width(), $Ipllx->height(), $fbB2w));
            goto dvWkp;
            PjMWf:
            S0QTt:
            goto mV3DR;
            Xi4YV:
            $mDtJs = $this->m65FOYWCHR6($Gsmm4, $iM4bK);
            goto Mg5Fv;
            RDEW4:
            $b8CME = $b8CME->mocuGwBinBv($Q6fz2);
            goto iExPa;
            HRWFh:
            $DwjAH = $DwjAH->mocuGwBinBv($Q6fz2);
            goto cUk3p;
            s1Xpb:
            $b8CME = new LAuETCYTRzty9('original', $Gsmm4, $iM4bK, $Ipllx->Qin1Q ?? 30);
            goto H0t_j;
            MPWW3:
            $Eo278 = app(UKW6hIg5vZR7f::class);
            goto DpBIx;
            D7_qB:
            Assert::isInstanceOf($Ipllx, RVcEF1JsGQd8M::class);
            goto iI3uL;
            OmkQW:
            $Ipllx = RVcEF1JsGQd8M::findOrFail($ld8Ad);
            goto D7_qB;
            iI3uL:
            if (!($Ipllx->jE_8B !== ZBLpZ2qUZ4P6C::S3)) {
                goto S0QTt;
            }
            goto YOYTu;
            H0t_j:
            $a0naV = app(OGmQ0hQJzIYby::class);
            goto GaaSL;
            Yl2Ed:
            $eATF4 = new WQ9DxjOkuISPT($this->hOV1v, $this->SRWQz, $this->gGE8I, $this->UBJ9G);
            goto ACNgz;
            XijSM:
            Log::info("Set input video for Job", ['s3Uri' => $RO83a]);
            goto MPWW3;
            mV3DR:
            $Gsmm4 = $Ipllx->width();
            goto i4qyE;
            cGY4T:
            Log::info("Set thumbnail for RVcEF1JsGQd8M Job", ['videoId' => $Ipllx->getAttribute('id'), 'duration' => $Ipllx->getAttribute('duration')]);
            goto rmLWV;
            YOYTu:
            throw new MediaConverterException("RVcEF1JsGQd8M {$Ipllx->id} is not S3 driver");
            goto PjMWf;
            dvWkp:
            if (!$Q6fz2) {
                goto O2Cwv;
            }
            goto RDEW4;
            H0jGV:
            $ld8Ad = $Eo278->mAI4bqvpcL2($this->mIxfEa5aJMk($Ipllx, $aeirh));
            goto nE7Cz;
            Mg5Fv:
            Log::info("Set 1080p resolution for Job", ['width' => $mDtJs['width'], 'height' => $mDtJs['height'], 'originalWidth' => $Gsmm4, 'originalHeight' => $iM4bK]);
            goto aUAhl;
            suIVM:
        } catch (\Exception $I8puu) {
            Log::info("RVcEF1JsGQd8M has been deleted, discard it", ['fileId' => $ld8Ad, 'err' => $I8puu->getMessage()]);
            return;
        }
        goto flx6a;
        flx6a:
    }
    private function mIxfEa5aJMk(RVcEF1JsGQd8M $Ipllx, $aeirh) : bool
    {
        goto uDBGM;
        rVDzT:
        sTYxO:
        goto apI4q;
        apI4q:
        b5bdW:
        goto xxO0m;
        uDBGM:
        if ($aeirh) {
            goto Vgp2O;
        }
        goto RLn3L;
        cDog2:
        $exagK = (int) round($Ipllx->getAttribute('duration') ?? 0);
        goto GPfJa;
        RLn3L:
        return false;
        goto DH3UU;
        DH3UU:
        Vgp2O:
        goto cDog2;
        GPfJa:
        switch (true) {
            case $Ipllx->width() * $Ipllx->height() >= 1920 * 1080 && $Ipllx->width() * $Ipllx->height() < 2560 * 1440:
                return $exagK > 10 * 60;
            case $Ipllx->width() * $Ipllx->height() >= 2560 * 1440 && $Ipllx->width() * $Ipllx->height() < 3840 * 2160:
                return $exagK > 5 * 60;
            case $Ipllx->width() * $Ipllx->height() >= 3840 * 2160:
                return $exagK > 3 * 60;
            default:
                return false;
        }
        goto rVDzT;
        xxO0m:
    }
    private function mDesqCmaKY8(PP4BnfgX7sVAN $LtUvT, string $ui0MU) : ?Alxlzu9Vtdk0x
    {
        goto fYIin;
        fYIin:
        $gDLXt = $LtUvT->ma7jkuHlWQB($ui0MU);
        goto d775q;
        hbaaP:
        return null;
        goto Yj0Yx;
        KM1Gt:
        gPld5:
        goto hbaaP;
        nbqgr:
        return new Alxlzu9Vtdk0x($gDLXt, 0, 0, null, null);
        goto KM1Gt;
        ecROJ:
        if (!$gDLXt) {
            goto gPld5;
        }
        goto nbqgr;
        d775q:
        Log::info("Resolve watermark for job with url", ['url' => $ui0MU, 'uri' => $gDLXt]);
        goto ecROJ;
        Yj0Yx:
    }
    private function mwkaAH4JFdF(int $Gsmm4, int $iM4bK) : bool
    {
        return $Gsmm4 * $iM4bK > 1.5 * (1920 * 1080);
    }
    private function m65FOYWCHR6(int $Gsmm4, int $iM4bK) : array
    {
        $H6TMg = new WDBp9xCDNr1uI($Gsmm4, $iM4bK);
        return $H6TMg->mUvlefGiOaW();
    }
    private function msVX9GnHpGz(O4HsadxAyKjYq $NyN9S) : string
    {
        goto w0Wup;
        RGBqz:
        return 's3://' . $this->iqyyD . '/' . $NyN9S->filename;
        goto EP9fF;
        EP9fF:
        uZ4K1:
        goto V4A3D;
        w0Wup:
        if (!($NyN9S->jE_8B == ZBLpZ2qUZ4P6C::S3)) {
            goto uZ4K1;
        }
        goto RGBqz;
        V4A3D:
        return $this->UBJ9G->url($NyN9S->filename);
        goto lc5LX;
        lc5LX:
    }
}
