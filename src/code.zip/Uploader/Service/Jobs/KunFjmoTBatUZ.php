<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
class KunFjmoTBatUZ implements BlurJobInterface
{
    const al9g6 = 15;
    const xzxfg = 500;
    const H9ZQ9 = 500;
    private $aQPLw;
    private $ifs25;
    private $gq_yF;
    public function __construct($fhNRF, $PQlIa, $gBW_k)
    {
        goto E_aEe;
        TQRdb:
        $this->ifs25 = $PQlIa;
        goto GuqwC;
        GuqwC:
        $this->aQPLw = $fhNRF;
        goto P14gT;
        E_aEe:
        $this->gq_yF = $gBW_k;
        goto TQRdb;
        P14gT:
    }
    public function blur(string $PV4mw) : void
    {
        goto U1BNI;
        U1BNI:
        $a221h = McTg5Yp6FKC6z::findOrFail($PV4mw);
        goto PYN6j;
        nSfXI:
        throw new \Exception('Failed to set final permissions on image file: ' . $AZy50);
        goto lEzgU;
        kxqlC:
        $Ubt2R = $SYKC9->width() / $SYKC9->height();
        goto yy75M;
        aqwdT:
        $SYKC9 = $this->aQPLw->call($this, $this->gq_yF->path($a221h->getLocation()));
        goto kxqlC;
        yy75M:
        $SYKC9->resize(self::xzxfg, self::H9ZQ9 / $Ubt2R);
        goto W5k4L;
        vNTuI:
        if (chmod($AZy50, 0664)) {
            goto Lqo9L;
        }
        goto K99ZK;
        N5YBU:
        $wj6PE = $this->ifs25->get($a221h->filename);
        goto J2xY2;
        agJMq:
        $AZy50 = $this->gq_yF->path($rnJia);
        goto G1X7S;
        rriJW:
        if (!($a221h->rs3Zr == GrPXtp41lLmde::S3 && !$this->gq_yF->exists($a221h->filename))) {
            goto pDj2P;
        }
        goto N5YBU;
        lEzgU:
        Lqo9L:
        goto d6p5I;
        jBUQE:
        $rnJia = $this->mEdD9zw0sfJ($a221h);
        goto agJMq;
        G1X7S:
        $SYKC9->save($AZy50);
        goto km2e5;
        PYN6j:
        ini_set('memory_limit', '-1');
        goto rriJW;
        km2e5:
        $SYKC9->destroy();
        goto vNTuI;
        W5k4L:
        $SYKC9->blur(self::al9g6);
        goto jBUQE;
        J2xY2:
        $this->gq_yF->put($a221h->filename, $wj6PE);
        goto SR1Vd;
        K99ZK:
        \Log::warning('Failed to set final permissions on image file: ' . $AZy50);
        goto nSfXI;
        SR1Vd:
        pDj2P:
        goto aqwdT;
        d6p5I:
        $a221h->update(['preview' => $rnJia]);
        goto FvVP2;
        FvVP2:
    }
    private function mEdD9zw0sfJ($k5pKN) : string
    {
        goto iBCsj;
        DhuUK:
        return $H0xYM . $k5pKN->getFilename() . '.jpg';
        goto GmAq_;
        iBCsj:
        $sEueW = $k5pKN->getLocation();
        goto ziItO;
        ubfDm:
        if ($this->gq_yF->exists($H0xYM)) {
            goto WxEVD;
        }
        goto ldDar;
        ziItO:
        $H0xYM = dirname($sEueW) . '/preview/';
        goto ubfDm;
        SYMZG:
        WxEVD:
        goto DhuUK;
        ldDar:
        $this->gq_yF->makeDirectory($H0xYM, 0755, true);
        goto SYMZG;
        GmAq_:
    }
}
