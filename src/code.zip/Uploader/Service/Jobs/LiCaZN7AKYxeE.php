<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\A9olNyGXhDJnA\Interfaces\ImageInterface;
use Intervention\A9olNyGXhDJnA\Typography\FontFactory;
class LiCaZN7AKYxeE
{
    private $ie3Jn;
    private $Fz8fG;
    private $VJN91;
    private $FHcNr;
    public function __construct($VWeyA, $w9RjZ, $J83Op, $z279S)
    {
        goto yUcRu;
        tINnr:
        $this->ie3Jn = $VWeyA;
        goto beaS6;
        oVJN9:
        $this->FHcNr = $z279S;
        goto tINnr;
        yUcRu:
        $this->Fz8fG = $w9RjZ;
        goto Ukn07;
        Ukn07:
        $this->VJN91 = $J83Op;
        goto oVJN9;
        beaS6:
    }
    public function mwjfcTF32q8(?int $yRrbE, ?int $aQb9L, string $aBPF6, bool $hRjhX = false) : string
    {
        goto lWwH9;
        YlgCC:
        iu6ui:
        goto kfCv9;
        s051D:
        $this->VJN91->put($L5bJW, $lu07a->toPng());
        goto F0LWG;
        He0mV:
        $this->FHcNr->put($L5bJW, $lu07a->toPng());
        goto s051D;
        jYMSP:
        $b3w1J = $yRrbE - $f0Br0;
        goto tU983;
        nmu6j:
        $P_ehD = 0.1;
        goto KUX53;
        kfCv9:
        $ktEu0 = $aQb9L - $qPZl8 - 10;
        goto YP5HA;
        KUX53:
        list($qPZl8, $f0Br0, $JwT9c) = $this->mWFE5X8A2Vz($aBPF6, $yRrbE, $P_ehD, (float) $yRrbE / $aQb9L);
        goto f7I3S;
        FPna6:
        dBInL:
        goto KTon9;
        SemuE:
        return $hRjhX ? $L5bJW : $this->VJN91->url($L5bJW);
        goto FPna6;
        I7f6h:
        if (!($yRrbE > 1500)) {
            goto iu6ui;
        }
        goto hwj1_;
        ZBxD_:
        return $hRjhX ? $L5bJW : $this->VJN91->url($L5bJW);
        goto OPQx_;
        tU983:
        $YEXCU = (int) ($b3w1J / 80);
        goto abEQm;
        f7I3S:
        $L5bJW = $this->mXF4I82nqxK($JwT9c, $yRrbE, $aQb9L, $f0Br0, $qPZl8);
        goto kwV2c;
        Flx33:
        throw new \RuntimeException("WI5WSPGRr1b2t dimensions are not available.");
        goto GCC0G;
        kwV2c:
        if (!$this->VJN91->exists($L5bJW)) {
            goto dBInL;
        }
        goto SemuE;
        hwj1_:
        $b3w1J -= $YEXCU * 0.4;
        goto YlgCC;
        GCC0G:
        kcE3L:
        goto nmu6j;
        lWwH9:
        if (!($yRrbE === null || $aQb9L === null)) {
            goto kcE3L;
        }
        goto Flx33;
        KTon9:
        $lu07a = $this->ie3Jn->call($this, $yRrbE, $aQb9L);
        goto jYMSP;
        YP5HA:
        $lu07a->text($JwT9c, $b3w1J, (int) $ktEu0, function ($b2pus) use($qPZl8) {
            goto GRBCi;
            DR28R:
            $b2pus->valign('middle');
            goto diDT2;
            cUZpg:
            $b2pus->size(max($qDxHT, 1));
            goto MUocE;
            umTSU:
            $qDxHT = (int) ($qPZl8 * 1.2);
            goto cUZpg;
            diDT2:
            $b2pus->align('middle');
            goto sTNe6;
            GRBCi:
            $b2pus->file(public_path($this->Fz8fG));
            goto umTSU;
            MUocE:
            $b2pus->color('#B9B9B9');
            goto DR28R;
            sTNe6:
        });
        goto He0mV;
        F0LWG:
        unset($lu07a);
        goto ZBxD_;
        abEQm:
        $b3w1J -= $YEXCU;
        goto I7f6h;
        OPQx_:
    }
    private function mXF4I82nqxK(string $aBPF6, int $yRrbE, int $aQb9L, int $Foofy, int $FNPwn) : string
    {
        $WS2sw = ltrim($aBPF6, '@');
        return "v2/watermark/{$WS2sw}/{$yRrbE}x{$aQb9L}_{$Foofy}x{$FNPwn}/text_watermark.png";
    }
    private function mWFE5X8A2Vz($aBPF6, int $yRrbE, float $ipn_F, float $X8aMX) : array
    {
        goto QhpAV;
        ojdyI:
        $fcDmi = $f0Br0 / (strlen($JwT9c) * 0.8);
        goto fJIO6;
        fJIO6:
        return [(int) $fcDmi, $fcDmi * strlen($JwT9c) / 1.8, $JwT9c];
        goto lvkbz;
        lvkbz:
        YVWWM:
        goto reN91;
        QhpAV:
        $JwT9c = '@' . $aBPF6;
        goto m2LjO;
        m2LjO:
        $f0Br0 = (int) ($yRrbE * $ipn_F);
        goto lRtFz;
        reN91:
        $fcDmi = 1 / $X8aMX * $f0Br0 / strlen($JwT9c);
        goto rsbIq;
        lRtFz:
        if (!($X8aMX > 1)) {
            goto YVWWM;
        }
        goto ojdyI;
        rsbIq:
        return [(int) $fcDmi, $f0Br0, $JwT9c];
        goto EM4Q4;
        EM4Q4:
    }
}
