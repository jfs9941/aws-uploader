<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class P2jUKJAF2hP53
{
    private $jpcy7;
    private $ftXLB;
    public function __construct(int $yGps0, int $rH4fk)
    {
        goto Wl6K3;
        Zr5yt:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto I5jVt;
        qOU9b:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto AIlGn;
        Wl6K3:
        if (!($yGps0 <= 0)) {
            goto i4dgA;
        }
        goto Zr5yt;
        AIlGn:
        xoTX6:
        goto qqiQm;
        G6HVl:
        $this->ftXLB = $rH4fk;
        goto QblCa;
        AkOJ0:
        if (!($rH4fk <= 0)) {
            goto xoTX6;
        }
        goto qOU9b;
        qqiQm:
        $this->jpcy7 = $yGps0;
        goto G6HVl;
        I5jVt:
        i4dgA:
        goto AkOJ0;
        QblCa:
    }
    private static function mhBFnqb9jCI($NGVs3, string $CiuCf = 'floor') : int
    {
        goto N0fOS;
        Vu0PC:
        return $NGVs3;
        goto UYU7L;
        B8vS1:
        switch (strtolower($CiuCf)) {
            case 'ceil':
                return (int) (ceil($NGVs3 / 2) * 2);
            case 'round':
                return (int) (round($NGVs3 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($NGVs3 / 2) * 2);
        }
        goto NnLAm;
        aKOQN:
        return (int) $NGVs3;
        goto CdvJa;
        CdvJa:
        DxOXD:
        goto B8vS1;
        UYU7L:
        hf8QV:
        goto Ut4br;
        N0fOS:
        if (!(is_int($NGVs3) && $NGVs3 % 2 === 0)) {
            goto hf8QV;
        }
        goto Vu0PC;
        NnLAm:
        BFLyw:
        goto ftzlB;
        ftzlB:
        hnBTh:
        goto L8L9U;
        Ut4br:
        if (!(is_float($NGVs3) && $NGVs3 == floor($NGVs3) && (int) $NGVs3 % 2 === 0)) {
            goto DxOXD;
        }
        goto aKOQN;
        L8L9U:
    }
    public function mYqJat252DA(string $TbRAo = 'floor') : array
    {
        goto W7kyt;
        XRkv3:
        NeoK2:
        goto tVlhA;
        fNTVo:
        $zgwDy = $HDuOC;
        goto aVftr;
        NnlvG:
        $K_ypE = $this->ftXLB * $s7JNQ;
        goto LsvRu;
        v4xY0:
        $hj0WG = $this->jpcy7 * $s7JNQ;
        goto q3WAp;
        aVftr:
        $s7JNQ = $zgwDy / $this->jpcy7;
        goto NnlvG;
        dWWe2:
        $zgwDy = 0;
        goto dJCrZ;
        NbvG9:
        otL78:
        goto h_NLn;
        LsvRu:
        $j4ebW = self::mhBFnqb9jCI(round($K_ypE), $TbRAo);
        goto W55eL;
        Mw1aT:
        TDesA:
        goto gnrAD;
        mrLJ2:
        $zgwDy = 2;
        goto Mw1aT;
        xSPpI:
        $s7JNQ = $j4ebW / $this->ftXLB;
        goto v4xY0;
        tVlhA:
        return ['width' => $zgwDy, 'height' => $j4ebW];
        goto x7gbF;
        Ptfvb:
        $j4ebW = $HDuOC;
        goto xSPpI;
        b8y8X:
        pZFiA:
        goto Ptfvb;
        W7kyt:
        $HDuOC = 1080;
        goto dWWe2;
        Eufy1:
        $j4ebW = 2;
        goto XRkv3;
        dJCrZ:
        $j4ebW = 0;
        goto VLdJn;
        q3WAp:
        $zgwDy = self::mhBFnqb9jCI(round($hj0WG), $TbRAo);
        goto NbvG9;
        W55eL:
        goto otL78;
        goto b8y8X;
        gnrAD:
        if (!($j4ebW < 2)) {
            goto NeoK2;
        }
        goto Eufy1;
        h_NLn:
        if (!($zgwDy < 2)) {
            goto TDesA;
        }
        goto mrLJ2;
        VLdJn:
        if ($this->jpcy7 >= $this->ftXLB) {
            goto pZFiA;
        }
        goto fNTVo;
        x7gbF:
    }
}
