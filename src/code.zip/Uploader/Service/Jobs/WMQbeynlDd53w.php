<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
class WMQbeynlDd53w implements BlurJobInterface
{
    const S50FG = 15;
    const z_WAJ = 500;
    const i_ulN = 500;
    private $wEW4b;
    private $dhrkT;
    private $sf39X;
    public function __construct($jlVrW, $v8n0s, $ZqxJI)
    {
        goto OKx4E;
        m8NN2:
        $this->dhrkT = $v8n0s;
        goto JsV0f;
        OKx4E:
        $this->sf39X = $ZqxJI;
        goto m8NN2;
        JsV0f:
        $this->wEW4b = $jlVrW;
        goto TyvXO;
        TyvXO:
    }
    public function blur(string $cQqZd) : void
    {
        goto XAOsI;
        wIn1R:
        $this->sf39X->put($Vh3Ai->filename, $fwab4);
        goto YVudl;
        YD0ww:
        $MpgR7->save($nkKif);
        goto Juw9j;
        s4JvE:
        $MpgR7->blur(self::S50FG);
        goto lJr7n;
        i42a7:
        $Vh3Ai->update(['preview' => $RE6mo]);
        goto Cvhu7;
        wj7D5:
        if (chmod($nkKif, 0664)) {
            goto kKAWn;
        }
        goto JtX7b;
        jT_RT:
        if (!($Vh3Ai->ymE9n == FW54oEnFetVYj::S3 && !$this->sf39X->exists($Vh3Ai->filename))) {
            goto f0ihR;
        }
        goto uU27O;
        Juw9j:
        $MpgR7->destroy();
        goto wj7D5;
        uQUbR:
        throw new \Exception('Failed to set final permissions on image file: ' . $nkKif);
        goto iGh0_;
        rQaQT:
        ini_set('memory_limit', '-1');
        goto jT_RT;
        lJr7n:
        $RE6mo = $this->mZsjzUjcnba($Vh3Ai);
        goto RpYDz;
        iGh0_:
        kKAWn:
        goto i42a7;
        At8Sh:
        $NE9ag = $MpgR7->width() / $MpgR7->height();
        goto BnsuU;
        RpYDz:
        $nkKif = $this->sf39X->path($RE6mo);
        goto YD0ww;
        XAOsI:
        $Vh3Ai = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
        goto rQaQT;
        YVudl:
        f0ihR:
        goto yuUBu;
        uU27O:
        $fwab4 = $this->dhrkT->get($Vh3Ai->filename);
        goto wIn1R;
        JtX7b:
        \Log::warning('Failed to set final permissions on image file: ' . $nkKif);
        goto uQUbR;
        BnsuU:
        $MpgR7->resize(self::z_WAJ, self::i_ulN / $NE9ag);
        goto s4JvE;
        yuUBu:
        $MpgR7 = $this->wEW4b->call($this, $this->sf39X->path($Vh3Ai->getLocation()));
        goto At8Sh;
        Cvhu7:
    }
    private function mZsjzUjcnba($VAWGs) : string
    {
        goto U0FjS;
        SzkaP:
        $this->sf39X->makeDirectory($ZJ0e5, 0755, true);
        goto GYHF6;
        GYHF6:
        dMMHd:
        goto wc86Y;
        VSOl1:
        $ZJ0e5 = dirname($IJqE5) . '/preview/';
        goto qNHc2;
        qNHc2:
        if ($this->sf39X->exists($ZJ0e5)) {
            goto dMMHd;
        }
        goto SzkaP;
        U0FjS:
        $IJqE5 = $VAWGs->getLocation();
        goto VSOl1;
        wc86Y:
        return $ZJ0e5 . $VAWGs->getFilename() . '.jpg';
        goto XMioW;
        XMioW:
    }
}
