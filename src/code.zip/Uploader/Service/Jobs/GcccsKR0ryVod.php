<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class GcccsKR0ryVod implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $S580N) : void
    {
        goto ePgm1;
        ePgm1:
        $Bh2o5 = BtruCfJoaSWZ6::findOrFail($S580N);
        goto tbBvR;
        tbBvR:
        if ($Bh2o5->width() > 0 && $Bh2o5->height() > 0) {
            goto N2M85;
        }
        goto rOgKj;
        rOgKj:
        $this->mMEMlIBddSN($Bh2o5);
        goto xqvL0;
        xqvL0:
        N2M85:
        goto wbY0N;
        wbY0N:
    }
    private function mMEMlIBddSN(BtruCfJoaSWZ6 $FnmXY) : void
    {
        goto m6MhW;
        b9yAs:
        $SpnYq = $xJhpw->getDimensions();
        goto U84dK;
        Nyg2O:
        $zr5kh = FFMpeg::fromDisk($Ww7Yi['path'])->open($FnmXY->getAttribute('filename'));
        goto Gxmtt;
        U84dK:
        $FnmXY->update(['duration' => $zr5kh->getDurationInSeconds(), 'resolution' => $SpnYq->getWidth() . 'x' . $SpnYq->getHeight(), 'fps' => $xJhpw->get('r_frame_rate') ?? 30]);
        goto wLKns;
        Gxmtt:
        $xJhpw = $zr5kh->getVideoStream();
        goto b9yAs;
        m6MhW:
        $Ww7Yi = $FnmXY->getView();
        goto Nyg2O;
        wLKns:
    }
}
