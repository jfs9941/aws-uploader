<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class MuUS2rhnmm2zc implements GenerateThumbnailForVideoInterface
{
    private $xeiTo;
    public function __construct($VGGur)
    {
        $this->xeiTo = $VGGur;
    }
    public function generate(string $PV4mw) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $PV4mw);
        $this->xeiTo->createThumbnail($PV4mw);
    }
}
