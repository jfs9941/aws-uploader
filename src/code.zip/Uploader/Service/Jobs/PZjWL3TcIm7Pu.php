<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
class PZjWL3TcIm7Pu implements BlurJobInterface
{
    const ytBnH = 15;
    const b705n = 500;
    const yf4OB = 500;
    private $wil31;
    private $ZN9hu;
    private $MuT3J;
    public function __construct($jwYYV, $C2YXG, $tBTgN)
    {
        goto vK2a2;
        ggXh_:
        $this->ZN9hu = $C2YXG;
        goto LE15e;
        vK2a2:
        $this->MuT3J = $tBTgN;
        goto ggXh_;
        LE15e:
        $this->wil31 = $jwYYV;
        goto Tovsk;
        Tovsk:
    }
    public function blur(string $uuHkQ) : void
    {
        goto C3n2p;
        k8YjX:
        throw new \Exception('Failed to set final permissions on image file: ' . $oaqq9);
        goto JS0_q;
        hiLE6:
        if (chmod($oaqq9, 0664)) {
            goto PxhzI;
        }
        goto Gtq4j;
        Gtq4j:
        \Log::warning('Failed to set final permissions on image file: ' . $oaqq9);
        goto k8YjX;
        FdJIX:
        unset($tCWWG);
        goto hiLE6;
        G49sU:
        $tCWWG->blur(self::ytBnH);
        goto iq6VY;
        uNd8u:
        $GOvRp = $tCWWG->width() / $tCWWG->height();
        goto q2Tue;
        D_fsr:
        yHZb7:
        goto tfjQu;
        uX5mH:
        if (!($npIYs->mb9Ag == VNuaYSNcfVlT5::S3 && !$this->MuT3J->exists($npIYs->filename))) {
            goto yHZb7;
        }
        goto a232a;
        UfICg:
        $npIYs->update(['preview' => $IYAfF]);
        goto e8TJK;
        a232a:
        $VlsOL = $this->ZN9hu->get($npIYs->filename);
        goto J1TaR;
        q2Tue:
        $tCWWG->resize(self::b705n, self::yf4OB / $GOvRp);
        goto G49sU;
        KAJXF:
        $oaqq9 = $this->ZN9hu->put($IYAfF, $tCWWG->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto FdJIX;
        VNevE:
        ini_set('memory_limit', '-1');
        goto uX5mH;
        tfjQu:
        $tCWWG = $this->wil31->call($this, $this->MuT3J->path($npIYs->getLocation()));
        goto uNd8u;
        C3n2p:
        $npIYs = QFoN7Ibbm93if::findOrFail($uuHkQ);
        goto VNevE;
        iq6VY:
        $IYAfF = $this->mHQ0rVDrgXm($npIYs);
        goto KAJXF;
        J1TaR:
        $this->MuT3J->put($npIYs->filename, $VlsOL);
        goto D_fsr;
        JS0_q:
        PxhzI:
        goto UfICg;
        e8TJK:
    }
    private function mHQ0rVDrgXm($c4EHm) : string
    {
        goto BWOfZ;
        BWOfZ:
        $dSgog = $c4EHm->getLocation();
        goto j1Uq9;
        cY7MA:
        $this->MuT3J->makeDirectory($fgheN, 0755, true);
        goto uXe9b;
        j1Uq9:
        $fgheN = dirname($dSgog) . '/preview/';
        goto vanOe;
        uXe9b:
        h3ff1:
        goto fAArX;
        fAArX:
        return $fgheN . $c4EHm->getFilename() . '.jpg';
        goto eWd3C;
        vanOe:
        if ($this->MuT3J->exists($fgheN)) {
            goto h3ff1;
        }
        goto cY7MA;
        eWd3C:
    }
}
