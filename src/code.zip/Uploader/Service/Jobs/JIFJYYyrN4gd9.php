<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class JIFJYYyrN4gd9 implements GenerateThumbnailForVideoInterface
{
    private $B72sg;
    public function __construct($eNxQi)
    {
        $this->B72sg = $eNxQi;
    }
    public function generate(string $EmnXX) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $EmnXX);
        $this->B72sg->createThumbnail($EmnXX);
    }
}
