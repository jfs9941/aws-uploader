<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class MNCz9zM0Bwk1l implements StoreVideoToS3JobInterface
{
    private $ZyAJI;
    private $ifs25;
    private $gq_yF;
    public function __construct($rhVEO, $PQlIa, $gBW_k)
    {
        goto u0Tv3;
        aE_Pg:
        $this->ZyAJI = $rhVEO;
        goto JSdT1;
        efppV:
        $this->gq_yF = $gBW_k;
        goto aE_Pg;
        u0Tv3:
        $this->ifs25 = $PQlIa;
        goto efppV;
        JSdT1:
    }
    public function store(string $PV4mw) : void
    {
        goto fz3Ef;
        fz3Ef:
        Log::info('Storing video (local) to S3', ['fileId' => $PV4mw, 'bucketName' => $this->ZyAJI]);
        goto Ji8o6;
        hSk5P:
        $NSzm3 = memory_get_peak_usage();
        goto uIq3H;
        LWR_H:
        VE1LC:
        goto VGgD0;
        jKFpy:
        $gBW_k = $this->gq_yF;
        goto ZU9jv;
        TQr6P:
        Log::error("[MNCz9zM0Bwk1l] File not found, discard it ", ['video' => $kIZSf->getLocation()]);
        goto rQ2fv;
        vaPyh:
        $EXETx = $this->ifs25->getClient();
        goto jKFpy;
        rQ2fv:
        return;
        goto cEAm3;
        VGgD0:
        if ($gBW_k->exists($kIZSf->getLocation())) {
            goto FNw1r;
        }
        goto TQr6P;
        uIq3H:
        try {
            goto GC8bC;
            zXh3S:
            lPA6g:
            goto xvK92;
            GSIyZ:
            $EXETx->completeMultipartUpload(['Bucket' => $this->ZyAJI, 'Key' => $kIZSf->getLocation(), 'UploadId' => $gA0os, 'MultipartUpload' => ['Parts' => $cJl2t]]);
            goto U4vzG;
            Z5tUC:
            $gA0os = $QuGN9['UploadId'];
            goto MJQkl;
            U4vzG:
            $kIZSf->update(['driver' => GrPXtp41lLmde::S3, 'status' => O8RzIjGmSN6fG::FINISHED]);
            goto j2t6e;
            xvK92:
            fclose($Ihgi1);
            goto GSIyZ;
            MJQkl:
            $jyLkH = 1;
            goto AebB5;
            GC8bC:
            $QuGN9 = $EXETx->createMultipartUpload(['Bucket' => $this->ZyAJI, 'Key' => $kIZSf->getLocation(), 'ContentType' => $NbLgB, 'ContentDisposition' => 'inline']);
            goto Z5tUC;
            XqCfA:
            $jyLkH++;
            goto O_RP5;
            ZIxTy:
            $ge5Wy = $EXETx->uploadPart(['Bucket' => $this->ZyAJI, 'Key' => $kIZSf->getLocation(), 'UploadId' => $gA0os, 'PartNumber' => $jyLkH, 'Body' => fread($Ihgi1, $HZVGD)]);
            goto Itdhc;
            O_RP5:
            goto iLhDo;
            goto zXh3S;
            zhsDA:
            if (feof($Ihgi1)) {
                goto lPA6g;
            }
            goto ZIxTy;
            aM1iS:
            iLhDo:
            goto zhsDA;
            Itdhc:
            $cJl2t[] = ['PartNumber' => $jyLkH, 'ETag' => $ge5Wy['ETag']];
            goto XqCfA;
            AebB5:
            $cJl2t = [];
            goto aM1iS;
            j2t6e:
            $gBW_k->delete($kIZSf->getLocation());
            goto mQlhD;
            mQlhD:
        } catch (AwsException $Uh0GK) {
            goto Gwvyr;
            L8QoL:
            igeWS:
            goto nPocK;
            Gwvyr:
            if (!isset($gA0os)) {
                goto igeWS;
            }
            goto cFL94;
            nPocK:
            Log::error('Failed to store video: ' . $kIZSf->getLocation() . ' - ' . $Uh0GK->getMessage());
            goto gmILb;
            cFL94:
            try {
                $EXETx->abortMultipartUpload(['Bucket' => $this->ZyAJI, 'Key' => $kIZSf->getLocation(), 'UploadId' => $gA0os]);
            } catch (AwsException $KwIRr) {
                Log::error('Error aborting multipart upload: ' . $KwIRr->getMessage());
            }
            goto L8QoL;
            gmILb:
        } finally {
            $mf5n8 = microtime(true);
            $c5jd5 = memory_get_usage();
            $ghXwk = memory_get_peak_usage();
            Log::info('Store CSQMvXC33KbbS to S3 function resource usage', ['imageId' => $PV4mw, 'execution_time_sec' => $mf5n8 - $ZqNFk, 'memory_usage_mb' => ($c5jd5 - $vqC1w) / 1024 / 1024, 'peak_memory_usage_mb' => ($ghXwk - $NSzm3) / 1024 / 1024]);
        }
        goto Rym0m;
        h1myZ:
        $Ihgi1 = $gBW_k->readStream($kIZSf->getLocation());
        goto qH51i;
        qH51i:
        $HZVGD = 1024 * 1024 * 50;
        goto l4SoR;
        Ji8o6:
        ini_set('memory_limit', '-1');
        goto vaPyh;
        VjQYB:
        if ($kIZSf) {
            goto VE1LC;
        }
        goto N0oyk;
        N0oyk:
        Log::info("CSQMvXC33KbbS has been deleted, discard it", ['fileId' => $PV4mw]);
        goto QwWiI;
        ZU9jv:
        $kIZSf = CSQMvXC33KbbS::find($PV4mw);
        goto VjQYB;
        hyHHM:
        $ZqNFk = microtime(true);
        goto dZhJM;
        dZhJM:
        $vqC1w = memory_get_usage();
        goto hSk5P;
        QwWiI:
        return;
        goto LWR_H;
        cEAm3:
        FNw1r:
        goto h1myZ;
        l4SoR:
        $NbLgB = $gBW_k->mimeType($kIZSf->getLocation());
        goto hyHHM;
        Rym0m:
    }
}
