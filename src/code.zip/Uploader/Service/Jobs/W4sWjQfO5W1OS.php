<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Encoder\Ye5PnDSJctWEA;
use Jfs\Uploader\Encoder\VeAMACddoaQSh;
use Jfs\Uploader\Encoder\VSKfJ2MZj0Tjg;
use Jfs\Uploader\Encoder\SUpCoEEDksHjH;
use Jfs\Uploader\Encoder\VTzJhiAsIieKq;
use Jfs\Uploader\Encoder\KzJu0aOFp1hnH;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Jfs\Uploader\Service\Jobs\J28K0oIWmGQJy;
use Jfs\Uploader\Service\Jobs\BDQtoSYw7RsgD;
use Jfs\Uploader\Service\JkVi3Kv2ThmJv;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class W4sWjQfO5W1OS implements MediaEncodeJobInterface
{
    private $GCETN;
    private $c5PSU;
    private $BfyCm;
    private $cQzus;
    private $cZsgg;
    public function __construct(string $wiZGO, $Ape3_, $ejImE, $Iv4Wx, $gnZ_2)
    {
        goto bn80p;
        Ji6zp:
        $this->BfyCm = $ejImE;
        goto eog7e;
        IjxUU:
        $this->c5PSU = $Ape3_;
        goto Ji6zp;
        bn80p:
        $this->GCETN = $wiZGO;
        goto IjxUU;
        vJkGk:
        $this->cZsgg = $gnZ_2;
        goto nAjgk;
        eog7e:
        $this->cQzus = $Iv4Wx;
        goto vJkGk;
        nAjgk:
    }
    public function encode(string $aK0gt, string $w91p_, $Hrj3j = true) : void
    {
        goto CV66t;
        gqVE1:
        try {
            goto hONFR;
            HnPla:
            $HVXUU = app(VSKfJ2MZj0Tjg::class);
            goto P6aOF;
            b1Tjk:
            iwsqS:
            goto meTp0;
            I5gVJ:
            throw new MediaConverterException("IfBHv1AJhiIDu {$dajVn->id} is not S3 driver");
            goto MWtG2;
            QwUeq:
            $dajVn->update(['aws_media_converter_job_id' => $aK0gt]);
            goto hc3rB;
            fbCXD:
            $iNVXG = $dajVn->height();
            goto pmZ4i;
            p23W4:
            if (!($tp6F0 && $iNVXG)) {
                goto u8Eme;
            }
            goto d42jh;
            IvAuS:
            $X5frI = $this->mxkcVRLwJOu($tp6F0, $iNVXG);
            goto dv4JE;
            mafqX:
            $ONlVY->mlnSne5hp5n($rphXu);
            goto AhAcf;
            VLwCT:
            $AGbo2 = new VeAMACddoaQSh('1080p', $X5frI['width'], $X5frI['height'], $dajVn->SjJpV ?? 30);
            goto SUEfp;
            d42jh:
            if (!$this->mI3hsGb38vw($tp6F0, $iNVXG)) {
                goto iwsqS;
            }
            goto IvAuS;
            meTp0:
            u8Eme:
            goto I77Gi;
            MWtG2:
            ThCBp:
            goto ODxrV;
            HZNYK:
            $oChgQ = new Ye5PnDSJctWEA($dajVn->dA2Rf ?? 1, 2, $HVXUU->mlcQhfVFRik($dajVn));
            goto TGl8C;
            ODxrV:
            $tp6F0 = $dajVn->width();
            goto fbCXD;
            AhAcf:
            $ONlVY->mf4iQ63JFbZ($HVXUU->m7jExCbXa2j($dajVn));
            goto p23W4;
            P6aOF:
            $ONlVY->mlnSne5hp5n($rphXu);
            goto IkNxB;
            DRMMY:
            $Upw6m = app(JkVi3Kv2ThmJv::class);
            goto KBis7;
            QffAI:
            $rphXu = $rphXu->mpqgOq1k8le($qTGmn);
            goto u19aU;
            ge6ln:
            $ONlVY = $ONlVY->m6VKVhCPRoa(new SUpCoEEDksHjH($o4yLq));
            goto Uz1nK;
            IkNxB:
            $ONlVY->mf4iQ63JFbZ($HVXUU->m7jExCbXa2j($dajVn));
            goto DRMMY;
            vxJH2:
            Log::info("Set input video for Job", ['s3Uri' => $o4yLq]);
            goto DAw8z;
            GrMWz:
            OqFIq:
            goto xc_Zg;
            I77Gi:
            Log::info("Set thumbnail for IfBHv1AJhiIDu Job", ['videoId' => $dajVn->getAttribute('id'), 'duration' => $dajVn->getAttribute('duration')]);
            goto HZNYK;
            KBis7:
            $d2Z8D = new BDQtoSYw7RsgD($this->cQzus, $this->cZsgg, $this->BfyCm, $this->c5PSU);
            goto NZmlm;
            SUEfp:
            $qTGmn = $this->m2zaSkqWtOk($Upw6m, $d2Z8D->mepv8nGH5jL((int) $X5frI['width'], (int) $X5frI['height'], $w91p_));
            goto NuI2U;
            pmZ4i:
            $o4yLq = $this->m1EBsZazL7t($dajVn);
            goto vxJH2;
            NuI2U:
            if (!$qTGmn) {
                goto OqFIq;
            }
            goto Grymf;
            NZmlm:
            $qTGmn = $this->m2zaSkqWtOk($Upw6m, $d2Z8D->mepv8nGH5jL($dajVn->width(), $dajVn->height(), $w91p_));
            goto IPwFL;
            IPwFL:
            if (!$qTGmn) {
                goto E6CoC;
            }
            goto QffAI;
            Grymf:
            $AGbo2 = $AGbo2->mpqgOq1k8le($qTGmn);
            goto GrMWz;
            dv4JE:
            Log::info("Set 1080p resolution for Job", ['width' => $X5frI['width'], 'height' => $X5frI['height'], 'originalWidth' => $tp6F0, 'originalHeight' => $iNVXG]);
            goto VLwCT;
            tDL_H:
            if (!($dajVn->nP7o5 !== ZuZC67ch9j73R::S3)) {
                goto ThCBp;
            }
            goto I5gVJ;
            Xil6_:
            Assert::isInstanceOf($dajVn, IfBHv1AJhiIDu::class);
            goto tDL_H;
            bQAkI:
            $aK0gt = $ONlVY->mjqacbmHifP($this->mVLDTLlLSZ0($dajVn, $Hrj3j));
            goto QwUeq;
            hONFR:
            $dajVn = IfBHv1AJhiIDu::findOrFail($aK0gt);
            goto Xil6_;
            xc_Zg:
            $ONlVY = $ONlVY->mlnSne5hp5n($AGbo2);
            goto b1Tjk;
            u19aU:
            E6CoC:
            goto mafqX;
            TGl8C:
            $ONlVY = $ONlVY->mjEe7Jzllpz($oChgQ);
            goto bQAkI;
            Uz1nK:
            $rphXu = new VeAMACddoaQSh('original', $tp6F0, $iNVXG, $dajVn->SjJpV ?? 30);
            goto HnPla;
            DAw8z:
            $ONlVY = app(VTzJhiAsIieKq::class);
            goto ge6ln;
            hc3rB:
        } catch (\Exception $z6tFS) {
            Log::info("IfBHv1AJhiIDu has been deleted, discard it", ['fileId' => $aK0gt, 'err' => $z6tFS->getMessage()]);
            return;
        }
        goto vlaMn;
        CV66t:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $aK0gt]);
        goto cTCD0;
        cTCD0:
        ini_set('memory_limit', '-1');
        goto gqVE1;
        vlaMn:
    }
    private function mVLDTLlLSZ0(IfBHv1AJhiIDu $dajVn, $Hrj3j) : bool
    {
        goto J1bf6;
        gNo0e:
        return false;
        goto B4uHe;
        d0BPc:
        $M3O_T = (int) round($dajVn->getAttribute('duration') ?? 0);
        goto pVXQN;
        J1bf6:
        if ($Hrj3j) {
            goto Fh3yl;
        }
        goto gNo0e;
        B4uHe:
        Fh3yl:
        goto d0BPc;
        pVXQN:
        switch (true) {
            case $dajVn->width() * $dajVn->height() >= 1920 * 1080 && $dajVn->width() * $dajVn->height() < 2560 * 1440:
                return $M3O_T > 10 * 60;
            case $dajVn->width() * $dajVn->height() >= 2560 * 1440 && $dajVn->width() * $dajVn->height() < 3840 * 2160:
                return $M3O_T > 5 * 60;
            case $dajVn->width() * $dajVn->height() >= 3840 * 2160:
                return $M3O_T > 3 * 60;
            default:
                return false;
        }
        goto taOGe;
        taOGe:
        Oh11G:
        goto tWN3Z;
        tWN3Z:
        KIXmC:
        goto DZN3b;
        DZN3b:
    }
    private function m2zaSkqWtOk(JkVi3Kv2ThmJv $Upw6m, string $zbNSu) : ?KzJu0aOFp1hnH
    {
        goto r_Oz1;
        V1dZh:
        return new KzJu0aOFp1hnH($JzKHV, 0, 0, null, null);
        goto Kw8Lx;
        IsXch:
        return null;
        goto RDlQo;
        Kw8Lx:
        UR9dQ:
        goto IsXch;
        PdB72:
        if (!$JzKHV) {
            goto UR9dQ;
        }
        goto V1dZh;
        PaYbl:
        Log::info("Resolve watermark for job with url", ['url' => $zbNSu, 'uri' => $JzKHV]);
        goto PdB72;
        r_Oz1:
        $JzKHV = $Upw6m->mvbnzr7CgdU($zbNSu);
        goto PaYbl;
        RDlQo:
    }
    private function mI3hsGb38vw(int $tp6F0, int $iNVXG) : bool
    {
        return $tp6F0 * $iNVXG > 1.5 * (1920 * 1080);
    }
    private function mxkcVRLwJOu(int $tp6F0, int $iNVXG) : array
    {
        $dpcfV = new J28K0oIWmGQJy($tp6F0, $iNVXG);
        return $dpcfV->mZNMVpvYoJy();
    }
    private function m1EBsZazL7t(OavRsjNQCayKr $jGsBp) : string
    {
        goto i0oy8;
        MU9XZ:
        return 's3://' . $this->GCETN . '/' . $jGsBp->filename;
        goto kkJ82;
        i0oy8:
        if (!($jGsBp->nP7o5 == ZuZC67ch9j73R::S3)) {
            goto eFJNX;
        }
        goto MU9XZ;
        k0LU4:
        return $this->c5PSU->url($jGsBp->filename);
        goto EpLEU;
        kkJ82:
        eFJNX:
        goto k0LU4;
        EpLEU:
    }
}
