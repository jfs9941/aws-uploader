<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Enum\FileDriver;

class BlurJob implements BlurJobInterface
{
    const BLUR_THRESHOLD = 15;
    const FIX_WIDTH = 500;
    const FIX_HEIGHT = 500;

    /** @var \Closure */
    private $maker;
    private $s3;
    private $localDisk;
    public function __construct($maker, $s3, $localDisk)
    {
        $this->localDisk = $localDisk;
        $this->s3 = $s3;
        $this->maker = $maker;
    }

    public function blur(string $id): void
    {
        $imageModel = Image::findOrFail($id);
        ini_set('memory_limit', '-1');

        if ($imageModel->driver == FileDriver::S3 && !$this->localDisk->exists($imageModel->filename)) {
            $remoteFile = $this->s3->get($imageModel->filename);
            $this->localDisk->put($imageModel->filename, $remoteFile);
        }
        $image = $this->maker->call($this, $this->localDisk->path($imageModel->getLocation()));
        $ratio = $image->width() / $image->height();
        // fit with the ratio
        $image->resize(self::FIX_WIDTH, self::FIX_HEIGHT / $ratio);
        $image->blur(self::BLUR_THRESHOLD);
        $previewPath = $this->createPath($imageModel);
        $absPreviewPath = $this->localDisk->path($previewPath);
        $image->save($absPreviewPath);
        $image->destroy();

        if (!chmod($absPreviewPath, 0664)) {
            \Log::warning('Failed to set final permissions on image file: ' . $absPreviewPath);
            throw new \Exception('Failed to set final permissions on image file: ' . $absPreviewPath);
        }
        $imageModel->update([
            'preview' => $previewPath,
        ]);

    }


    private function createPath($imageObject): string
    {
        $path = $imageObject->getLocation();
        $folder = dirname($path) . '/preview/';

        if (!$this->localDisk->exists($folder)) {
            $this->localDisk->makeDirectory($folder, 0755, true);
        }

        return $folder .  $imageObject->getFilename() . '.jpg';
    }
}
