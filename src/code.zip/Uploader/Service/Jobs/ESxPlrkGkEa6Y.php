<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class ESxPlrkGkEa6Y
{
    private $Uv8NV;
    private $wap61;
    private $huyLW;
    private $IaFSl;
    public function __construct($lldd6, $D9mvh, $A3hvZ, $B27Pk)
    {
        goto SXPzv;
        S8yHW:
        $this->IaFSl = $B27Pk;
        goto A_Awx;
        SXPzv:
        $this->wap61 = $D9mvh;
        goto S362e;
        S362e:
        $this->huyLW = $A3hvZ;
        goto S8yHW;
        A_Awx:
        $this->Uv8NV = $lldd6;
        goto uomNa;
        uomNa:
    }
    public function mUcOzHh2TqY(?int $oy0ze, ?int $sccRX, string $zGGen, bool $b9ezw = false) : string
    {
        goto UIVrk;
        UIVrk:
        if (!($oy0ze === null || $sccRX === null)) {
            goto c9OCE;
        }
        goto fo2Qk;
        Bl2_c:
        $uuvVo->text($YdyRq, $ooPnr, (int) $irfej, function ($Y6uQY) use($N_1ku) {
            goto lOYta;
            Xrx0d:
            $Y6uQY->valign('middle');
            goto kc01c;
            ziPbN:
            $Bs6su = (int) ($N_1ku * 1.2);
            goto PrHyY;
            kc01c:
            $Y6uQY->align('middle');
            goto ZurX8;
            lOYta:
            $Y6uQY->file(public_path($this->wap61));
            goto ziPbN;
            PrHyY:
            $Y6uQY->size(max($Bs6su, 1));
            goto QQFGQ;
            QQFGQ:
            $Y6uQY->color([185, 185, 185, 1]);
            goto Xrx0d;
            ZurX8:
        });
        goto D0Lku;
        eY3Ew:
        $this->huyLW->put($lxbX3, $uuvVo->stream('png'));
        goto Bsl3S;
        Iw30z:
        list($N_1ku, $y0XTN, $YdyRq) = $this->mqS3xpdjeGG($zGGen, $oy0ze, $FNrT0, (float) $oy0ze / $sccRX);
        goto PJgVZ;
        zQhYR:
        $ooPnr -= $frmuI * 0.4;
        goto QYxd_;
        bUY0_:
        return $b9ezw ? $lxbX3 : $this->huyLW->url($lxbX3);
        goto x0Gp9;
        WWiN8:
        c9OCE:
        goto VzxEN;
        PJgVZ:
        $lxbX3 = $this->mXtwhVEMlp8($YdyRq, $oy0ze, $sccRX, $y0XTN, $N_1ku);
        goto VZmFB;
        QYxd_:
        Kqk2L:
        goto MwRYk;
        fo2Qk:
        throw new \RuntimeException("RhSx2q5xIlh0Y dimensions are not available.");
        goto WWiN8;
        MwRYk:
        $irfej = $sccRX - $N_1ku - 10;
        goto Bl2_c;
        D0Lku:
        $this->IaFSl->put($lxbX3, $uuvVo->stream('png'));
        goto eY3Ew;
        IVHRK:
        $uuvVo = $this->Uv8NV->call($this, $oy0ze, $sccRX);
        goto Bfz_n;
        rCmx1:
        $frmuI = (int) ($ooPnr / 80);
        goto HVXkD;
        ngddp:
        if (!($oy0ze > 1500)) {
            goto Kqk2L;
        }
        goto zQhYR;
        Bsl3S:
        return $b9ezw ? $lxbX3 : $this->huyLW->url($lxbX3);
        goto WhyEd;
        VzxEN:
        $FNrT0 = 0.1;
        goto Iw30z;
        HVXkD:
        $ooPnr -= $frmuI;
        goto ngddp;
        Bfz_n:
        $ooPnr = $oy0ze - $y0XTN;
        goto rCmx1;
        x0Gp9:
        id26R:
        goto IVHRK;
        VZmFB:
        if (!$this->huyLW->exists($lxbX3)) {
            goto id26R;
        }
        goto bUY0_;
        WhyEd:
    }
    private function mXtwhVEMlp8(string $zGGen, int $oy0ze, int $sccRX, int $RVOKZ, int $B3f0b) : string
    {
        $qIZVB = ltrim($zGGen, '@');
        return "v2/watermark/{$qIZVB}/{$oy0ze}x{$sccRX}_{$RVOKZ}x{$B3f0b}/text_watermark.png";
    }
    private function mqS3xpdjeGG($zGGen, int $oy0ze, float $meFdq, float $mpFph) : array
    {
        goto zMzIe;
        x9Lwg:
        $on15k = 1 / $mpFph * $y0XTN / strlen($YdyRq);
        goto vudTo;
        vudTo:
        return [(int) $on15k, $y0XTN, $YdyRq];
        goto cvJSY;
        l_bsW:
        $y0XTN = (int) ($oy0ze * $meFdq);
        goto T3BbC;
        rfbCX:
        $on15k = $y0XTN / (strlen($YdyRq) * 0.8);
        goto sG8Tm;
        T3BbC:
        if (!($mpFph > 1)) {
            goto p9mU0;
        }
        goto rfbCX;
        zSfl8:
        p9mU0:
        goto x9Lwg;
        sG8Tm:
        return [(int) $on15k, $on15k * strlen($YdyRq) / 1.8, $YdyRq];
        goto zSfl8;
        zMzIe:
        $YdyRq = '@' . $zGGen;
        goto l_bsW;
        cvJSY:
    }
}
