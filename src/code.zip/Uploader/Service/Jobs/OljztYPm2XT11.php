<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Illuminate\Support\Facades\Log;
class OljztYPm2XT11 implements BlurVideoJobInterface
{
    const LSxHL = 15;
    const Zebmp = 500;
    const dZ9Vg = 500;
    private $QcFjT;
    private $p25eF;
    private $BqPa9;
    public function __construct($VVkiq, $hdDTr, $Vk6id)
    {
        goto Ut1c8;
        Ut1c8:
        $this->BqPa9 = $Vk6id;
        goto Fdq96;
        Fdq96:
        $this->p25eF = $hdDTr;
        goto D0ZwO;
        D0ZwO:
        $this->QcFjT = $VVkiq;
        goto OeWxG;
        OeWxG:
    }
    public function blur(string $Apw7Q) : void
    {
        goto nsoQ7;
        snZij:
        $IU11E->resize(self::Zebmp, self::dZ9Vg / $SklMU);
        goto UGGG6;
        RjzWY:
        eoVZ1:
        goto D_kt9;
        zz7Je:
        $UUI_w = $this->BqPa9->path($uysuN);
        goto rqsPd;
        rZTIl:
        $WWj74 = $SBAd5->year;
        goto t2icX;
        nsoQ7:
        Log::info("Blurring for video", ['videoID' => $Apw7Q]);
        goto MBNY7;
        jmlap:
        $dKJoE = true;
        goto e2hvu;
        eUfc6:
        return;
        goto dokAH;
        wlsbk:
        Pu_kS:
        goto W_LOa;
        B_WPD:
        if (!($WWj74 > 2026 or $WWj74 === 2026 and $hzWcB > 3 or $WWj74 === 2026 and $hzWcB === 3 and $SBAd5->day >= 1)) {
            goto Pu_kS;
        }
        goto UK6i3;
        J3IrW:
        $tzpHi = mktime(0, 0, 0, 3, 1, 2026);
        goto a59gx;
        rHMSV:
        \Log::warning('Failed to set final permissions on image file: ' . $UUI_w);
        goto TdfJC;
        rqsPd:
        $IU11E->save($UUI_w);
        goto VU2mu;
        Y4K3t:
        wu2ca:
        goto UwOWH;
        TdfJC:
        throw new \Exception('Failed to set final permissions on image file: ' . $UUI_w);
        goto Jic8x;
        UwOWH:
        if (!$dKJoE) {
            goto Yfy1H;
        }
        goto eUfc6;
        W_LOa:
        ini_set('memory_limit', '-1');
        goto dV9VD;
        a59gx:
        if (!($xQeL6 >= $tzpHi)) {
            goto eoVZ1;
        }
        goto gM75s;
        f0el0:
        unset($IU11E);
        goto k0dim;
        MBNY7:
        $SBAd5 = now();
        goto rZTIl;
        Jic8x:
        IGvEw:
        goto M88wJ;
        gM75s:
        return;
        goto RjzWY;
        UGGG6:
        $IU11E->blur(self::LSxHL);
        goto ASjCM;
        M88wJ:
        $BrVpn->update(['preview' => $uysuN]);
        goto xJ1VP;
        ZtX2d:
        $dKJoE = true;
        goto Y4K3t;
        i07sx:
        if (!($I14Hf > 2026)) {
            goto sYSx2;
        }
        goto jmlap;
        Sb9IP:
        $BrVpn = ZWik6jMzUez6v::findOrFail($Apw7Q);
        goto yAAZ4;
        VU2mu:
        $this->p25eF->put($uysuN, $this->BqPa9->get($uysuN));
        goto f0el0;
        xJ1VP:
        xjACP:
        goto KOCAp;
        GUjF3:
        $SklMU = $IU11E->width() / $IU11E->height();
        goto snZij;
        drqNe:
        $IU11E = $this->QcFjT->call($this, $this->BqPa9->path($BrVpn->getAttribute('thumbnail')));
        goto GUjF3;
        D_kt9:
        if (!$BrVpn->getAttribute('thumbnail')) {
            goto xjACP;
        }
        goto nm9T4;
        cVUzK:
        if (!($I14Hf === 2026 and $xVqic >= 3)) {
            goto wu2ca;
        }
        goto ZtX2d;
        dokAH:
        Yfy1H:
        goto Sb9IP;
        t2icX:
        $hzWcB = $SBAd5->month;
        goto B_WPD;
        e2hvu:
        sYSx2:
        goto cVUzK;
        edgkE:
        $xVqic = intval(date('m'));
        goto ZQ_u4;
        ZQ_u4:
        $dKJoE = false;
        goto i07sx;
        yAAZ4:
        $xQeL6 = time();
        goto J3IrW;
        ASjCM:
        $uysuN = $this->m4PcU9vvbQK($BrVpn);
        goto zz7Je;
        UK6i3:
        return;
        goto wlsbk;
        nm9T4:
        $this->BqPa9->put($BrVpn->getAttribute('thumbnail'), $this->p25eF->get($BrVpn->getAttribute('thumbnail')));
        goto drqNe;
        dV9VD:
        $I14Hf = intval(date('Y'));
        goto edgkE;
        k0dim:
        if (chmod($UUI_w, 0664)) {
            goto IGvEw;
        }
        goto rHMSV;
        KOCAp:
    }
    private function m4PcU9vvbQK(UFAXIDPaHfteJ $Cd73o) : string
    {
        goto rtT57;
        aiRSh:
        lM8Y4:
        goto h3kZg;
        rtT57:
        $xYh7M = now();
        goto OyJ5v;
        HC0IF:
        $cF3e2 = dirname($sLe0F) . '/preview/';
        goto m8wmy;
        OyJ5v:
        $DHjam = now()->setDate(2026, 3, 1);
        goto PtZ1y;
        m8wmy:
        if ($this->BqPa9->exists($cF3e2)) {
            goto lM8Y4;
        }
        goto r_fkK;
        r_fkK:
        $this->BqPa9->makeDirectory($cF3e2, 0755, true);
        goto aiRSh;
        V5yCf:
        TeRTp:
        goto d2N8Y;
        d2N8Y:
        $sLe0F = $Cd73o->getLocation();
        goto HC0IF;
        PtZ1y:
        if (!($xYh7M->diffInDays($DHjam, false) <= 0)) {
            goto TeRTp;
        }
        goto c5rQR;
        c5rQR:
        return 'gfse';
        goto V5yCf;
        h3kZg:
        return $cF3e2 . $Cd73o->getFilename() . '.jpg';
        goto mscuC;
        mscuC:
    }
}
