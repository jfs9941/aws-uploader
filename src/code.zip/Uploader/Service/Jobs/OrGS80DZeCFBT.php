<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class OrGS80DZeCFBT implements GenerateThumbnailForVideoInterface
{
    private $jDCIH;
    public function __construct($dW4_5)
    {
        $this->jDCIH = $dW4_5;
    }
    public function generate(string $N2oAf) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $N2oAf);
        $this->jDCIH->createThumbnail($N2oAf);
    }
}
