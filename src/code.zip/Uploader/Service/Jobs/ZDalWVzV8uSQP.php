<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Illuminate\Support\Facades\Log;
class ZDalWVzV8uSQP implements DownloadToLocalJobInterface
{
    private $ZN9hu;
    private $MuT3J;
    public function __construct($C2YXG, $tBTgN)
    {
        $this->ZN9hu = $C2YXG;
        $this->MuT3J = $tBTgN;
    }
    public function download(string $uuHkQ) : void
    {
        goto N09Ed;
        SGgX0:
        Log::info("Start download file to local", ['fileId' => $uuHkQ, 'filename' => $DejZC->getLocation()]);
        goto E09P5;
        h1RLn:
        return;
        goto kja94;
        kja94:
        kAwVk:
        goto SyCHV;
        E09P5:
        if (!$this->MuT3J->exists($DejZC->getLocation())) {
            goto kAwVk;
        }
        goto h1RLn;
        N09Ed:
        $DejZC = QFoN7Ibbm93if::findOrFail($uuHkQ);
        goto SGgX0;
        SyCHV:
        $this->MuT3J->put($DejZC->getLocation(), $this->ZN9hu->get($DejZC->getLocation()));
        goto N0Kfr;
        N0Kfr:
    }
}
