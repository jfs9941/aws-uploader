<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class NrByMq7i9Knt5 implements CompressJobInterface
{
    const uVf17 = 60;
    private $vn9CJ;
    private $n8EBo;
    private $S2Lqz;
    public function __construct($HL7fw, $gdQ3g, $Uryi7)
    {
        goto XJHuT;
        rjQdo:
        $this->S2Lqz = $Uryi7;
        goto h5z_A;
        h5z_A:
        $this->n8EBo = $gdQ3g;
        goto CxWQW;
        XJHuT:
        $this->vn9CJ = $HL7fw;
        goto rjQdo;
        CxWQW:
    }
    public function compress(string $zV1kl)
    {
        goto t6K9A;
        t6K9A:
        $u7QUO = microtime(true);
        goto Dzifw;
        I3nIN:
        $g2Th1 = memory_get_peak_usage();
        goto tACKx;
        wDsIL:
        try {
            goto V0ecX;
            V0ecX:
            $RD3vr = KCmQR4pvm0dT3::findOrFail($zV1kl);
            goto sL_pZ;
            BR3SF:
            try {
                goto n7ei7;
                ZCwI2:
                $this->mnymhjTzv5h($RD3vr, 'webp');
                goto QgAmJ;
                n7ei7:
                $hGbsd = str_replace(['.jpg', '.png', '.heic'], '.webp', $RD3vr->getLocation());
                goto feBAc;
                feBAc:
                $this->mJFLn6AcRDk($pB0pg, $hGbsd);
                goto ZCwI2;
                QgAmJ:
            } catch (\Exception $nV19i) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $zV1kl, 'error' => $nV19i->getMessage()]);
                try {
                    goto k_zK1;
                    xPbBX:
                    $this->mnymhjTzv5h($RD3vr, 'jpg');
                    goto olbo4;
                    k_zK1:
                    $hGbsd = str_replace(['.jpg', '.png', '.heic'], '.jpg', $RD3vr->getLocation());
                    goto a_aeH;
                    a_aeH:
                    $this->mN0wkt67OIV($pB0pg, $hGbsd);
                    goto xPbBX;
                    olbo4:
                } catch (\Exception $nV19i) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $zV1kl, 'error' => $nV19i->getMessage()]);
                }
            }
            goto xH4J2;
            sL_pZ:
            $pB0pg = $this->n8EBo->path($RD3vr->getLocation());
            goto BR3SF;
            xH4J2:
        } catch (\Throwable $nV19i) {
            goto f6Viw;
            f6Viw:
            if (!$nV19i instanceof ModelNotFoundException) {
                goto s3_SV;
            }
            goto zNE3K;
            V7DxD:
            s3_SV:
            goto C1AZn;
            zNE3K:
            Log::info("KCmQR4pvm0dT3 has been deleted, discard it", ['imageId' => $zV1kl]);
            goto S9WBU;
            C1AZn:
            Log::error("Failed to compress image", ['imageId' => $zV1kl, 'error' => $nV19i->getMessage()]);
            goto XdDU0;
            S9WBU:
            return;
            goto V7DxD;
            XdDU0:
        } finally {
            $lmBz1 = microtime(true);
            $ZinuS = memory_get_usage();
            $NcQYU = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $zV1kl, 'execution_time_sec' => $lmBz1 - $u7QUO, 'memory_usage_mb' => ($ZinuS - $TkLmp) / 1024 / 1024, 'peak_memory_usage_mb' => ($NcQYU - $g2Th1) / 1024 / 1024]);
        }
        goto OWFKE;
        tACKx:
        Log::info("Compress image", ['imageId' => $zV1kl]);
        goto wDsIL;
        Dzifw:
        $TkLmp = memory_get_usage();
        goto I3nIN;
        OWFKE:
    }
    private function mN0wkt67OIV($pB0pg, $hGbsd)
    {
        goto FvaBO;
        TV6Um:
        $this->S2Lqz->put($hGbsd, $MUN90->toJpeg(self::uVf17), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto BW831;
        FvaBO:
        $MUN90 = $this->vn9CJ->call($this, $pB0pg);
        goto zVrRg;
        BW831:
        unset($MUN90);
        goto uoea0;
        zVrRg:
        $MUN90->orient()->toJpeg(self::uVf17)->save($hGbsd);
        goto TV6Um;
        uoea0:
    }
    private function mJFLn6AcRDk($pB0pg, $hGbsd)
    {
        goto shAce;
        shAce:
        $MUN90 = $this->vn9CJ->call($this, $pB0pg);
        goto csAVJ;
        Sna3K:
        $this->S2Lqz->put($hGbsd, $MUN90->toWebp(self::uVf17), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto ahCbo;
        csAVJ:
        $MUN90->orient()->toWebp(self::uVf17);
        goto Sna3K;
        ahCbo:
        unset($MUN90);
        goto GVlVI;
        GVlVI:
    }
    private function mnymhjTzv5h($RD3vr, $eX3H1)
    {
        goto r3Rz4;
        BXSYs:
        $RD3vr->save();
        goto PO_B6;
        PO_B6:
        return $RD3vr;
        goto RbfdE;
        D2XQW:
        $RD3vr->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$eX3H1}", $RD3vr->getLocation()));
        goto BXSYs;
        r3Rz4:
        $RD3vr->setAttribute('type', $eX3H1);
        goto D2XQW;
        RbfdE:
    }
}
