<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Illuminate\Support\Facades\Log;
class Og01R00FDMBgI implements StoreVideoToS3JobInterface
{
    private $Rjojo;
    private $f1xKj;
    private $SPj0U;
    public function __construct($QlBWR, $C6boj, $KUQsT)
    {
        goto L9cDk;
        NBl11:
        $this->Rjojo = $QlBWR;
        goto TUM8K;
        L9cDk:
        $this->f1xKj = $C6boj;
        goto bfKsC;
        bfKsC:
        $this->SPj0U = $KUQsT;
        goto NBl11;
        TUM8K:
    }
    public function store(string $g5e_r) : void
    {
        goto kiAMZ;
        NtJvP:
        $Yglc5 = $KUQsT->readStream($On18I->getLocation());
        goto maeqg;
        aV4wj:
        $KUQsT = $this->SPj0U;
        goto JSEhk;
        wUALr:
        $fT88U = $KUQsT->mimeType($On18I->getLocation());
        goto yGBSp;
        JSEhk:
        $On18I = JbxOPjx4A3DUY::find($g5e_r);
        goto lXAz2;
        eE0oD:
        ini_set('memory_limit', '-1');
        goto WDgZB;
        WDgZB:
        $UVwEi = $this->f1xKj->getClient();
        goto aV4wj;
        maeqg:
        $U3GL3 = 1024 * 1024 * 50;
        goto wUALr;
        MCGik:
        SaQk8:
        goto FdnrC;
        YAK7C:
        PBMlt:
        goto NtJvP;
        lXAz2:
        if ($On18I) {
            goto SaQk8;
        }
        goto NpsYH;
        kiAMZ:
        Log::info('Storing video (local) to S3', ['fileId' => $g5e_r, 'bucketName' => $this->Rjojo]);
        goto eE0oD;
        M7vKw:
        $kVF0z = memory_get_usage();
        goto bV9OI;
        BNtG0:
        try {
            goto CUvyg;
            EjTC9:
            $qwLXm[] = ['PartNumber' => $rYBqJ, 'ETag' => $npUNg['ETag']];
            goto Vuw0c;
            NsCT_:
            $rYBqJ = 1;
            goto mN74h;
            NOWOT:
            WzKPk:
            goto phe9o;
            gDrR3:
            $npUNg = $UVwEi->uploadPart(['Bucket' => $this->Rjojo, 'Key' => $On18I->getLocation(), 'UploadId' => $ytDYW, 'PartNumber' => $rYBqJ, 'Body' => fread($Yglc5, $U3GL3)]);
            goto EjTC9;
            phe9o:
            if (feof($Yglc5)) {
                goto xM9lK;
            }
            goto gDrR3;
            CUvyg:
            $pVb4c = $UVwEi->createMultipartUpload(['Bucket' => $this->Rjojo, 'Key' => $On18I->getLocation(), 'ContentType' => $fT88U, 'ContentDisposition' => 'inline']);
            goto ZUwjt;
            B8Wki:
            $On18I->update(['driver' => Tq4KHV0o6oTIo::S3]);
            goto ilwrU;
            ilwrU:
            $KUQsT->delete($On18I->getLocation());
            goto vM59H;
            HTmx2:
            fclose($Yglc5);
            goto co3qD;
            Vuw0c:
            $rYBqJ++;
            goto ljB25;
            co3qD:
            $UVwEi->completeMultipartUpload(['Bucket' => $this->Rjojo, 'Key' => $On18I->getLocation(), 'UploadId' => $ytDYW, 'MultipartUpload' => ['Parts' => $qwLXm]]);
            goto B8Wki;
            ZUwjt:
            $ytDYW = $pVb4c['UploadId'];
            goto NsCT_;
            mN74h:
            $qwLXm = [];
            goto NOWOT;
            aahlH:
            xM9lK:
            goto HTmx2;
            ljB25:
            goto WzKPk;
            goto aahlH;
            vM59H:
        } catch (AwsException $X_03M) {
            goto affoW;
            Grvwq:
            yQcXf:
            goto J5sjs;
            affoW:
            if (!isset($ytDYW)) {
                goto yQcXf;
            }
            goto URR5U;
            J5sjs:
            Log::error('Failed to store video: ' . $On18I->getLocation() . ' - ' . $X_03M->getMessage());
            goto QSohK;
            URR5U:
            try {
                $UVwEi->abortMultipartUpload(['Bucket' => $this->Rjojo, 'Key' => $On18I->getLocation(), 'UploadId' => $ytDYW]);
            } catch (AwsException $Cz64b) {
                Log::error('Error aborting multipart upload: ' . $Cz64b->getMessage());
            }
            goto Grvwq;
            QSohK:
        } finally {
            $nQGPQ = microtime(true);
            $E4uJa = memory_get_usage();
            $Q2gUW = memory_get_peak_usage();
            Log::info('Store JbxOPjx4A3DUY to S3 function resource usage', ['imageId' => $g5e_r, 'execution_time_sec' => $nQGPQ - $DbNb5, 'memory_usage_mb' => ($E4uJa - $kVF0z) / 1024 / 1024, 'peak_memory_usage_mb' => ($Q2gUW - $i4hys) / 1024 / 1024]);
        }
        goto HO6if;
        UCKpp:
        Log::error("[Og01R00FDMBgI] File not found, discard it ", ['video' => $On18I->getLocation()]);
        goto sJkN0;
        bV9OI:
        $i4hys = memory_get_peak_usage();
        goto BNtG0;
        NpsYH:
        Log::info("JbxOPjx4A3DUY has been deleted in database or not inserted yet, discard it", ['fileId' => $g5e_r]);
        goto oJDlc;
        oJDlc:
        return;
        goto MCGik;
        sJkN0:
        return;
        goto YAK7C;
        FdnrC:
        if ($KUQsT->exists($On18I->getLocation())) {
            goto PBMlt;
        }
        goto UCKpp;
        yGBSp:
        $DbNb5 = microtime(true);
        goto M7vKw;
        HO6if:
    }
}
