<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class HOtxsT8ZNbu6T
{
    private $vCnjM;
    private $chTTM;
    public function __construct(int $mteHt, int $a1g2N)
    {
        goto LFAwC;
        E_3_0:
        if (!($a1g2N <= 0)) {
            goto IyZov;
        }
        goto R1CFJ;
        fOO7Z:
        $this->chTTM = $a1g2N;
        goto JKITz;
        xU1qw:
        IyZov:
        goto kttBz;
        hBxQH:
        lEjoX:
        goto E_3_0;
        kttBz:
        $this->vCnjM = $mteHt;
        goto fOO7Z;
        R1CFJ:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto xU1qw;
        smHzk:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto hBxQH;
        LFAwC:
        if (!($mteHt <= 0)) {
            goto lEjoX;
        }
        goto smHzk;
        JKITz:
    }
    private static function m7SyVvYwd2m($B0zq7, string $uCoCU = 'floor') : int
    {
        goto EFQXI;
        DwgnC:
        if (!(is_float($B0zq7) && $B0zq7 == floor($B0zq7) && (int) $B0zq7 % 2 === 0)) {
            goto KbD8b;
        }
        goto xk_rx;
        Hgyix:
        FiKHX:
        goto moZvY;
        dHJTZ:
        KbD8b:
        goto lC44o;
        moZvY:
        sqSyX:
        goto uRpmu;
        tA52N:
        return $B0zq7;
        goto uMRyO;
        lC44o:
        switch (strtolower($uCoCU)) {
            case 'ceil':
                return (int) (ceil($B0zq7 / 2) * 2);
            case 'round':
                return (int) (round($B0zq7 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($B0zq7 / 2) * 2);
        }
        goto Hgyix;
        EFQXI:
        if (!(is_int($B0zq7) && $B0zq7 % 2 === 0)) {
            goto R4LMa;
        }
        goto tA52N;
        xk_rx:
        return (int) $B0zq7;
        goto dHJTZ;
        uMRyO:
        R4LMa:
        goto DwgnC;
        uRpmu:
    }
    public function m6L44Vkx35Q(string $D8urp = 'floor') : array
    {
        goto jbFsC;
        PxUX3:
        if (!($GO0EO < 2)) {
            goto iGpXa;
        }
        goto lzwlx;
        vLNTZ:
        $Uj0u9 = $this->vCnjM * $E_OPf;
        goto ii6Fu;
        VE_kn:
        if ($this->vCnjM >= $this->chTTM) {
            goto mChJf;
        }
        goto o7AOb;
        lzwlx:
        $GO0EO = 2;
        goto wWsNm;
        jbFsC:
        $elzGL = 1080;
        goto LbRD3;
        ybB3e:
        $GO0EO = $elzGL;
        goto M8MqG;
        cw2Px:
        $GO0EO = 0;
        goto VE_kn;
        LbRD3:
        $vGPFk = 0;
        goto cw2Px;
        wWsNm:
        iGpXa:
        goto XRnxE;
        ii6Fu:
        $vGPFk = self::m7SyVvYwd2m(round($Uj0u9), $D8urp);
        goto uD_1J;
        rc2VU:
        $ZJWqc = $this->chTTM * $E_OPf;
        goto V1P6I;
        LujzT:
        $E_OPf = $vGPFk / $this->vCnjM;
        goto rc2VU;
        n4Mnd:
        mChJf:
        goto ybB3e;
        XRnxE:
        return ['width' => $vGPFk, 'height' => $GO0EO];
        goto tO74o;
        b1E6u:
        goto oPh4u;
        goto n4Mnd;
        V1P6I:
        $GO0EO = self::m7SyVvYwd2m(round($ZJWqc), $D8urp);
        goto b1E6u;
        t3Zbu:
        if (!($vGPFk < 2)) {
            goto qCYga;
        }
        goto pTSDq;
        o7AOb:
        $vGPFk = $elzGL;
        goto LujzT;
        uD_1J:
        oPh4u:
        goto t3Zbu;
        xTch_:
        qCYga:
        goto PxUX3;
        pTSDq:
        $vGPFk = 2;
        goto xTch_;
        M8MqG:
        $E_OPf = $GO0EO / $this->chTTM;
        goto vLNTZ;
        tO74o:
    }
}
