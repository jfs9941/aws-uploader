<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Illuminate\Support\Facades\Log;
class Pp54Ji7b1cVMH implements StoreVideoToS3JobInterface
{
    private $yCBq_;
    private $Mayr9;
    private $nEL6Z;
    public function __construct($wIlgi, $KI4Gx, $vWt2S)
    {
        goto GsNMc;
        ICxe2:
        $this->yCBq_ = $wIlgi;
        goto p55BI;
        GsNMc:
        $this->Mayr9 = $KI4Gx;
        goto pY579;
        pY579:
        $this->nEL6Z = $vWt2S;
        goto ICxe2;
        p55BI:
    }
    public function store(string $iG1wy) : void
    {
        goto nMc9w;
        gYOiD:
        $qUdal = $this->Mayr9->getClient();
        goto cvSFl;
        cZM7j:
        $uZpmo = 1024 * 1024 * 50;
        goto tRq2m;
        W1eyI:
        $QFj0j = memory_get_usage();
        goto T831v;
        OsZAx:
        $mzMGr = microtime(true);
        goto W1eyI;
        CYgAD:
        Log::error("[Pp54Ji7b1cVMH] File not found, discard it ", ['video' => $hVTDq->getLocation()]);
        goto z9CGN;
        T831v:
        $qP_18 = memory_get_peak_usage();
        goto VnX2j;
        FQmPw:
        $hVTDq = AelPShnd8pMtD::find($iG1wy);
        goto A0lLA;
        z9CGN:
        return;
        goto jVein;
        jSYbB:
        $wNiL6 = $vWt2S->readStream($hVTDq->getLocation());
        goto cZM7j;
        tRq2m:
        $sfrA1 = $vWt2S->mimeType($hVTDq->getLocation());
        goto OsZAx;
        cvSFl:
        $vWt2S = $this->nEL6Z;
        goto FQmPw;
        nMc9w:
        Log::info('Storing video (local) to S3', ['fileId' => $iG1wy, 'bucketName' => $this->yCBq_]);
        goto GpSzO;
        A0lLA:
        if ($hVTDq) {
            goto WiXkz;
        }
        goto N44h4;
        Oh_Y3:
        if ($vWt2S->exists($hVTDq->getLocation())) {
            goto To2RH;
        }
        goto CYgAD;
        jVein:
        To2RH:
        goto jSYbB;
        kT3UI:
        return;
        goto ZhN2p;
        VnX2j:
        try {
            goto NHpPe;
            NHpPe:
            $DUsxo = $qUdal->createMultipartUpload(['Bucket' => $this->yCBq_, 'Key' => $hVTDq->getLocation(), 'ContentType' => $sfrA1, 'ContentDisposition' => 'inline']);
            goto Jq0S5;
            p8VXW:
            $qUdal->completeMultipartUpload(['Bucket' => $this->yCBq_, 'Key' => $hVTDq->getLocation(), 'UploadId' => $KCSMR, 'MultipartUpload' => ['Parts' => $nN4jY]]);
            goto XvpZV;
            YWdRZ:
            BpidV:
            goto e8MPg;
            tdpWM:
            $nN4jY = [];
            goto QIEUE;
            fN0fi:
            if (feof($wNiL6)) {
                goto BpidV;
            }
            goto p5znO;
            POjGM:
            $zXFeF++;
            goto HCrGM;
            XvpZV:
            $hVTDq->update(['driver' => Ef6Dy6MoUDei9::S3]);
            goto CRL5v;
            p5znO:
            $iqlj4 = $qUdal->uploadPart(['Bucket' => $this->yCBq_, 'Key' => $hVTDq->getLocation(), 'UploadId' => $KCSMR, 'PartNumber' => $zXFeF, 'Body' => fread($wNiL6, $uZpmo)]);
            goto gDu0X;
            gDu0X:
            $nN4jY[] = ['PartNumber' => $zXFeF, 'ETag' => $iqlj4['ETag']];
            goto POjGM;
            Jq0S5:
            $KCSMR = $DUsxo['UploadId'];
            goto aO7uq;
            CRL5v:
            $vWt2S->delete($hVTDq->getLocation());
            goto mQGpX;
            HCrGM:
            goto H77HO;
            goto YWdRZ;
            aO7uq:
            $zXFeF = 1;
            goto tdpWM;
            e8MPg:
            fclose($wNiL6);
            goto p8VXW;
            QIEUE:
            H77HO:
            goto fN0fi;
            mQGpX:
        } catch (AwsException $WqnXx) {
            goto qNo0e;
            qNo0e:
            if (!isset($KCSMR)) {
                goto gJUxe;
            }
            goto iz9T_;
            ps_RS:
            gJUxe:
            goto sODCa;
            iz9T_:
            try {
                $qUdal->abortMultipartUpload(['Bucket' => $this->yCBq_, 'Key' => $hVTDq->getLocation(), 'UploadId' => $KCSMR]);
            } catch (AwsException $g0mTv) {
                Log::error('Error aborting multipart upload: ' . $g0mTv->getMessage());
            }
            goto ps_RS;
            sODCa:
            Log::error('Failed to store video: ' . $hVTDq->getLocation() . ' - ' . $WqnXx->getMessage());
            goto JryU4;
            JryU4:
        } finally {
            $ljc5H = microtime(true);
            $s7nhL = memory_get_usage();
            $h40IA = memory_get_peak_usage();
            Log::info('Store AelPShnd8pMtD to S3 function resource usage', ['imageId' => $iG1wy, 'execution_time_sec' => $ljc5H - $mzMGr, 'memory_usage_mb' => ($s7nhL - $QFj0j) / 1024 / 1024, 'peak_memory_usage_mb' => ($h40IA - $qP_18) / 1024 / 1024]);
        }
        goto nRQOD;
        ZhN2p:
        WiXkz:
        goto Oh_Y3;
        GpSzO:
        ini_set('memory_limit', '-1');
        goto gYOiD;
        N44h4:
        Log::info("AelPShnd8pMtD has been deleted in database or not inserted yet, discard it", ['fileId' => $iG1wy]);
        goto kT3UI;
        nRQOD:
    }
}
