<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class PTFvvXXiafc6j implements CompressJobInterface
{
    const laU2f = 60;
    private $z0km_;
    private $ofZvx;
    private $vFVII;
    public function __construct($BSNlm, $suNmN, $pC4KD)
    {
        goto NQQaf;
        DwbfX:
        $this->vFVII = $pC4KD;
        goto lA37d;
        lA37d:
        $this->ofZvx = $suNmN;
        goto u18jm;
        NQQaf:
        $this->z0km_ = $BSNlm;
        goto DwbfX;
        u18jm:
    }
    public function compress(string $N2oAf)
    {
        goto aojI0;
        pzBNn:
        $zfPP0 = memory_get_usage();
        goto pzgVb;
        pzgVb:
        $j44T2 = memory_get_peak_usage();
        goto VB5mL;
        fDsUe:
        try {
            goto RtoR8;
            M2v0H:
            $RxSHk = $this->mE7ggSmCTTT($RxSHk, 'jpg');
            goto yADOC;
            eOdW4:
            if (!(strtolower($RxSHk->getExtension()) === 'png' || strtolower($RxSHk->getExtension()) === 'heic')) {
                goto OPmk2;
            }
            goto M2v0H;
            QNl4R:
            try {
                goto oF1rk;
                IZdN6:
                $this->mq8l5FQJoNZ($efYsk, $wN3XW);
                goto qvUAm;
                oF1rk:
                $wN3XW = $this->ofZvx->path(str_replace('.jpg', '.webp', $RxSHk->getLocation()));
                goto IZdN6;
                qvUAm:
                $this->mE7ggSmCTTT($RxSHk, 'webp');
                goto mJWAe;
                mJWAe:
            } catch (\Exception $a9JiP) {
                goto nBDWv;
                nBDWv:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $N2oAf, 'error' => $a9JiP->getMessage()]);
                goto JkfDC;
                JkfDC:
                $wN3XW = $this->ofZvx->path($RxSHk->getLocation());
                goto Hkhiz;
                Hkhiz:
                $this->mb2ql5VLq8M($efYsk, $wN3XW);
                goto PcxmH;
                PcxmH:
            }
            goto tMpew;
            yADOC:
            OPmk2:
            goto QNl4R;
            RtoR8:
            $RxSHk = JMa7GBaLcnq3D::findOrFail($N2oAf);
            goto Rq2q2;
            Rq2q2:
            $efYsk = $this->ofZvx->path($RxSHk->getLocation());
            goto eOdW4;
            tMpew:
        } catch (\Throwable $a9JiP) {
            goto SswkK;
            SswkK:
            if (!$a9JiP instanceof ModelNotFoundException) {
                goto ZF9zK;
            }
            goto kqlii;
            CK71d:
            ZF9zK:
            goto YUNxi;
            YUNxi:
            Log::error("Failed to compress image", ['imageId' => $N2oAf, 'error' => $a9JiP->getMessage()]);
            goto v4R0z;
            cFxDF:
            return;
            goto CK71d;
            kqlii:
            Log::info("JMa7GBaLcnq3D has been deleted, discard it", ['imageId' => $N2oAf]);
            goto cFxDF;
            v4R0z:
        } finally {
            $FlQiD = microtime(true);
            $pejxD = memory_get_usage();
            $G9K1o = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $N2oAf, 'execution_time_sec' => $FlQiD - $Oj18q, 'memory_usage_mb' => ($pejxD - $zfPP0) / 1024 / 1024, 'peak_memory_usage_mb' => ($G9K1o - $j44T2) / 1024 / 1024]);
        }
        goto yueHe;
        aojI0:
        $Oj18q = microtime(true);
        goto pzBNn;
        VB5mL:
        Log::info("Compress image", ['imageId' => $N2oAf]);
        goto fDsUe;
        yueHe:
    }
    private function mb2ql5VLq8M($efYsk, $wN3XW)
    {
        goto KtIJi;
        szwbV:
        $this->vFVII->put($wN3XW, $aymCM->toJpeg(self::laU2f), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto kScmF;
        KtIJi:
        $aymCM = $this->z0km_->call($this, $efYsk);
        goto IdfbL;
        kScmF:
        unset($aymCM);
        goto hikI9;
        IdfbL:
        $aymCM->orient()->toJpeg(self::laU2f)->save($wN3XW);
        goto szwbV;
        hikI9:
    }
    private function mq8l5FQJoNZ($efYsk, $wN3XW)
    {
        goto QPvsA;
        QPvsA:
        $aymCM = $this->z0km_->call($this, $efYsk);
        goto NAhoF;
        Fb9jn:
        unset($aymCM);
        goto Xr4i0;
        Wlt20:
        $this->vFVII->put($wN3XW, $aymCM->toJpeg(self::laU2f), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto Fb9jn;
        NAhoF:
        $aymCM->orient()->toWebp(self::laU2f);
        goto Wlt20;
        Xr4i0:
    }
    private function mE7ggSmCTTT($RxSHk, $qlMII)
    {
        goto kDcRJ;
        kDcRJ:
        $RxSHk->setAttribute('type', $qlMII);
        goto cCRS4;
        LWsBv:
        return $RxSHk;
        goto jMxAY;
        cCRS4:
        $RxSHk->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$qlMII}", $RxSHk->getLocation()));
        goto g3vgi;
        g3vgi:
        $RxSHk->save();
        goto LWsBv;
        jMxAY:
    }
}
