<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class UnyOeiIsEFHca implements CompressJobInterface
{
    const uCRhh = 60;
    private $z7YJI;
    private $MpAl4;
    private $wi_W5;
    public function __construct($fvRbj, $U2KRS, $WLmZw)
    {
        goto dYkWk;
        JFiVv:
        $this->MpAl4 = $U2KRS;
        goto aV251;
        dYkWk:
        $this->z7YJI = $fvRbj;
        goto y_J9g;
        y_J9g:
        $this->wi_W5 = $WLmZw;
        goto JFiVv;
        aV251:
    }
    public function compress(string $S580N)
    {
        goto jij7I;
        Egt92:
        $JYKfw = memory_get_peak_usage();
        goto ocawr;
        isEKp:
        try {
            goto mivaF;
            woKa9:
            AM3rT:
            goto JCy_P;
            VH02I:
            if (!(strtolower($gNhb4->getExtension()) === 'png' || strtolower($gNhb4->getExtension()) === 'heic')) {
                goto AM3rT;
            }
            goto fKxfk;
            fKxfk:
            $gNhb4 = $this->myxuEoMUZ8i($gNhb4, 'jpg');
            goto woKa9;
            m6Ggb:
            $p2oEb = $this->MpAl4->path($gNhb4->getLocation());
            goto VH02I;
            mivaF:
            $gNhb4 = KfEJaEGpFJ0tm::findOrFail($S580N);
            goto m6Ggb;
            JCy_P:
            try {
                goto zNYZD;
                uqTdx:
                $this->myxuEoMUZ8i($gNhb4, 'webp');
                goto GfyuE;
                JSvNA:
                $this->m2bvkNRMhPL($p2oEb, $pVEQi);
                goto uqTdx;
                zNYZD:
                $pVEQi = $this->MpAl4->path(str_replace('.jpg', '.webp', $gNhb4->getLocation()));
                goto JSvNA;
                GfyuE:
            } catch (\Exception $ah9h0) {
                goto xu9lL;
                HWWir:
                $pVEQi = $this->MpAl4->path($gNhb4->getLocation());
                goto DTK3a;
                xu9lL:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $S580N, 'error' => $ah9h0->getMessage()]);
                goto HWWir;
                DTK3a:
                $this->mwVZhCmdRPT($p2oEb, $pVEQi);
                goto H_Q_v;
                H_Q_v:
            }
            goto QnFQQ;
            QnFQQ:
        } catch (\Throwable $ah9h0) {
            goto TkbyF;
            PUqhn:
            return;
            goto hfD8p;
            ceIjY:
            Log::error("Failed to compress image", ['imageId' => $S580N, 'error' => $ah9h0->getMessage()]);
            goto EbY1M;
            eIzrz:
            Log::info("KfEJaEGpFJ0tm has been deleted, discard it", ['imageId' => $S580N]);
            goto PUqhn;
            hfD8p:
            tTqqV:
            goto ceIjY;
            TkbyF:
            if (!$ah9h0 instanceof ModelNotFoundException) {
                goto tTqqV;
            }
            goto eIzrz;
            EbY1M:
        } finally {
            $EX_rn = microtime(true);
            $r_Z2H = memory_get_usage();
            $I57ia = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $S580N, 'execution_time_sec' => $EX_rn - $nR1Wc, 'memory_usage_mb' => ($r_Z2H - $xM3o2) / 1024 / 1024, 'peak_memory_usage_mb' => ($I57ia - $JYKfw) / 1024 / 1024]);
        }
        goto yj3Zw;
        ocawr:
        Log::info("Compress image", ['imageId' => $S580N]);
        goto isEKp;
        VSJWT:
        $xM3o2 = memory_get_usage();
        goto Egt92;
        jij7I:
        $nR1Wc = microtime(true);
        goto VSJWT;
        yj3Zw:
    }
    private function mwVZhCmdRPT($p2oEb, $pVEQi)
    {
        goto ZruhE;
        ZNuSB:
        $cO2p_->orient()->toJpeg(self::uCRhh)->save($pVEQi);
        goto VfX17;
        acMv4:
        unset($cO2p_);
        goto QzrdT;
        ZruhE:
        $cO2p_ = $this->z7YJI->call($this, $p2oEb);
        goto ZNuSB;
        VfX17:
        $this->wi_W5->put($pVEQi, $cO2p_->toJpeg(self::uCRhh), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto acMv4;
        QzrdT:
    }
    private function m2bvkNRMhPL($p2oEb, $pVEQi)
    {
        goto eMuoE;
        vNSTq:
        unset($cO2p_);
        goto FN2_m;
        tKxUQ:
        $this->wi_W5->put($pVEQi, $cO2p_->toJpeg(self::uCRhh), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto vNSTq;
        eMuoE:
        $cO2p_ = $this->z7YJI->call($this, $p2oEb);
        goto FR6E7;
        FR6E7:
        $cO2p_->orient()->toWebp(self::uCRhh);
        goto tKxUQ;
        FN2_m:
    }
    private function myxuEoMUZ8i($gNhb4, $WXZ1K)
    {
        goto DQbiH;
        rENR3:
        return $gNhb4;
        goto EQOem;
        Dcmop:
        $gNhb4->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$WXZ1K}", $gNhb4->getLocation()));
        goto CL5Qm;
        DQbiH:
        $gNhb4->setAttribute('type', $WXZ1K);
        goto Dcmop;
        CL5Qm:
        $gNhb4->save();
        goto rENR3;
        EQOem:
    }
}
