<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
class WINFTU8An4GCx implements BlurJobInterface
{
    const fNdJA = 15;
    const Jpouv = 500;
    const GG3Av = 500;
    private $o4nAt;
    private $m2kWg;
    private $Jhhox;
    public function __construct($wpWQD, $Npup8, $bXh5v)
    {
        goto uTkOl;
        uTkOl:
        $this->Jhhox = $bXh5v;
        goto XPb5b;
        V9J6X:
        $this->o4nAt = $wpWQD;
        goto sGWvX;
        XPb5b:
        $this->m2kWg = $Npup8;
        goto V9J6X;
        sGWvX:
    }
    public function blur(string $Brk87) : void
    {
        goto vwOd7;
        Mcraa:
        if (!($APOmp->J42hQ == NFXMub09wSQVu::S3 && !$this->Jhhox->exists($APOmp->filename))) {
            goto BqT3Y;
        }
        goto X5Acw;
        UDlvm:
        \Log::warning('Failed to set final permissions on image file: ' . $gXVhV);
        goto krT1Q;
        X5Acw:
        $i6Z2h = $this->m2kWg->get($APOmp->filename);
        goto f1CuC;
        iJw_N:
        unset($Kc1eZ);
        goto BYJUD;
        apzz0:
        $WT0iE = $Kc1eZ->width() / $Kc1eZ->height();
        goto zrCCL;
        BYJUD:
        if (chmod($gXVhV, 0664)) {
            goto CcWrQ;
        }
        goto UDlvm;
        krT1Q:
        throw new \Exception('Failed to set final permissions on image file: ' . $gXVhV);
        goto G5FsX;
        we1E5:
        $Kc1eZ->blur(self::fNdJA);
        goto Hh1mt;
        a77YN:
        $gXVhV = $this->m2kWg->put($Tp_yG, $Kc1eZ->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto iJw_N;
        Hh1mt:
        $Tp_yG = $this->mDJQZopJGq2($APOmp);
        goto a77YN;
        qn6PR:
        BqT3Y:
        goto zhaa0;
        vwOd7:
        $APOmp = OjvWwjWRqBzIO::findOrFail($Brk87);
        goto L0jOi;
        G5FsX:
        CcWrQ:
        goto t0AiC;
        zrCCL:
        $Kc1eZ->resize(self::Jpouv, self::GG3Av / $WT0iE);
        goto we1E5;
        f1CuC:
        $this->Jhhox->put($APOmp->filename, $i6Z2h);
        goto qn6PR;
        zhaa0:
        $Kc1eZ = $this->o4nAt->call($this, $this->Jhhox->path($APOmp->getLocation()));
        goto apzz0;
        L0jOi:
        ini_set('memory_limit', '-1');
        goto Mcraa;
        t0AiC:
        $APOmp->update(['preview' => $Tp_yG]);
        goto pemtD;
        pemtD:
    }
    private function mDJQZopJGq2($u7KkV) : string
    {
        goto jcJYL;
        jcJYL:
        $F0ycc = $u7KkV->getLocation();
        goto xG_kO;
        x9FUa:
        r1VHU:
        goto OgJFz;
        xeedu:
        $this->Jhhox->makeDirectory($e1knD, 0755, true);
        goto x9FUa;
        a04CC:
        if ($this->Jhhox->exists($e1knD)) {
            goto r1VHU;
        }
        goto xeedu;
        OgJFz:
        return $e1knD . $u7KkV->getFilename() . '.jpg';
        goto BrwwI;
        xG_kO:
        $e1knD = dirname($F0ycc) . '/preview/';
        goto a04CC;
        BrwwI:
    }
}
