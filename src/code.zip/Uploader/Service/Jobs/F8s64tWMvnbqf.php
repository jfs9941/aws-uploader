<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class F8s64tWMvnbqf implements GenerateThumbnailJobInterface
{
    const a4eBw = 150;
    const HGSWR = 150;
    private $e2JZZ;
    private $dwubH;
    private $g23qO;
    public function __construct($yGjLo, $VzPPJ, $EWJhD)
    {
        goto IewZ2;
        bL_51:
        $this->dwubH = $VzPPJ;
        goto ZXaKl;
        IewZ2:
        $this->e2JZZ = $yGjLo;
        goto bL_51;
        ZXaKl:
        $this->g23qO = $EWJhD;
        goto EP4un;
        EP4un:
    }
    public function generate(string $B_L9m)
    {
        goto cwtAO;
        OIL9M:
        ini_set('memory_limit', '-1');
        goto O6Jph;
        cwtAO:
        Log::info("Generating thumbnail", ['imageId' => $B_L9m]);
        goto OIL9M;
        O6Jph:
        try {
            goto bDokC;
            OHYoh:
            HuAL_:
            goto w9zMn;
            mu7GP:
            $zCabx = XMeo8SOmME8kj::findOrFail($B_L9m);
            goto BmIvM;
            nhLqw:
            if (!($y9ggN !== false)) {
                goto HuAL_;
            }
            goto AeaOT;
            CZ3kS:
            $dTJxl = $this->myWULYwVwzq($zCabx);
            goto JdJIU;
            oXsxc:
            $Et3ln->orient()->resize(150, 150);
            goto CZ3kS;
            AeaOT:
            $zCabx->update(['thumbnail' => $dTJxl, 'status' => LV0wDYHZInswq::THUMBNAIL_PROCESSED]);
            goto OHYoh;
            BmIvM:
            $Et3ln = $this->e2JZZ->call($this, $d_Wiu->path($zCabx->getLocation()));
            goto oXsxc;
            o0QKr:
            unset($Et3ln);
            goto nhLqw;
            JdJIU:
            $y9ggN = $this->g23qO->put($dTJxl, $Et3ln->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto o0QKr;
            bDokC:
            $d_Wiu = $this->dwubH;
            goto mu7GP;
            w9zMn:
        } catch (ModelNotFoundException $kHEpW) {
            Log::info("XMeo8SOmME8kj has been deleted, discard it", ['imageId' => $B_L9m]);
            return;
        } catch (\Exception $kHEpW) {
            Log::error("Failed to generate thumbnail", ['imageId' => $B_L9m, 'error' => $kHEpW->getMessage()]);
        }
        goto zTRPN;
        zTRPN:
    }
    private function myWULYwVwzq(Zl4rdW32ufaUx $zCabx) : string
    {
        goto ArGYn;
        KcFfH:
        $dS4vR = $WeJv6 . '/' . self::a4eBw . 'X' . self::HGSWR;
        goto CZy2n;
        ArGYn:
        $dTJxl = $zCabx->getLocation();
        goto ijNtR;
        ijNtR:
        $WeJv6 = dirname($dTJxl);
        goto KcFfH;
        CZy2n:
        return $dS4vR . '/' . $zCabx->getFilename() . '.jpg';
        goto FM31E;
        FM31E:
    }
}
