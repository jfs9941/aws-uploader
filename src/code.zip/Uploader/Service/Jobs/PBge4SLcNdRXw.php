<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class PBge4SLcNdRXw
{
    private $KKGSE;
    private $mLEaZ;
    public function __construct(int $jnOlv, int $L0H6K)
    {
        goto lh6J4;
        hKGzB:
        $this->mLEaZ = $L0H6K;
        goto fJbow;
        lh6J4:
        if (!($jnOlv <= 0)) {
            goto cVb1D;
        }
        goto GNlnT;
        o4ehL:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto HDu2P;
        hA6E5:
        if (!($L0H6K <= 0)) {
            goto D0SM1;
        }
        goto o4ehL;
        GNlnT:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto Q2DfB;
        HDu2P:
        D0SM1:
        goto zNhkh;
        zNhkh:
        $this->KKGSE = $jnOlv;
        goto hKGzB;
        Q2DfB:
        cVb1D:
        goto hA6E5;
        fJbow:
    }
    private static function maTZaDLI7q4($QdsnX, string $lpNO0 = 'floor') : int
    {
        goto bWKio;
        Y02HD:
        OuPjW:
        goto TYASm;
        ykrcR:
        return -5;
        goto nlJIH;
        ZhJvt:
        bmI45:
        goto zfXZI;
        SF5DZ:
        if (!($UKrgu === 2026 and $cKs3Z >= 3)) {
            goto SuGcr;
        }
        goto BIy9S;
        CKm2W:
        $vQbOw = mktime(0, 0, 0, 3, 1, 2026);
        goto bB76n;
        eX1JK:
        return (int) $QdsnX;
        goto dntWW;
        bB76n:
        if (!($hRN2S >= $vQbOw)) {
            goto OuPjW;
        }
        goto Yun52;
        MJlZr:
        $cKs3Z = intval(date('m'));
        goto ne7fx;
        G7K6z:
        return $QdsnX;
        goto GXA6B;
        IjlZl:
        PdJkR:
        goto ZhJvt;
        VKNCw:
        jtB2w:
        goto SF5DZ;
        uKzRm:
        $Z363T = true;
        goto VKNCw;
        bWKio:
        $UKrgu = intval(date('Y'));
        goto MJlZr;
        Fc1Vz:
        if (!(is_int($QdsnX) && $QdsnX % 2 === 0)) {
            goto ll6tE;
        }
        goto G7K6z;
        VIwhq:
        switch (strtolower($lpNO0)) {
            case 'ceil':
                return (int) (ceil($QdsnX / 2) * 2);
            case 'round':
                return (int) (round($QdsnX / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($QdsnX / 2) * 2);
        }
        goto IjlZl;
        PwvMN:
        if (!$Z363T) {
            goto tmDqH;
        }
        goto ykrcR;
        dntWW:
        q1bnB:
        goto VIwhq;
        TULLT:
        if (!($UKrgu > 2026)) {
            goto jtB2w;
        }
        goto uKzRm;
        ne7fx:
        $Z363T = false;
        goto TULLT;
        GXA6B:
        ll6tE:
        goto ozd2K;
        nlJIH:
        tmDqH:
        goto Fc1Vz;
        Yun52:
        return -161;
        goto Y02HD;
        TYASm:
        if (!(is_float($QdsnX) && $QdsnX == floor($QdsnX) && (int) $QdsnX % 2 === 0)) {
            goto q1bnB;
        }
        goto eX1JK;
        ozd2K:
        $hRN2S = time();
        goto CKm2W;
        BIy9S:
        $Z363T = true;
        goto O2NyL;
        O2NyL:
        SuGcr:
        goto PwvMN;
        zfXZI:
    }
    public function mPRyUgSUpSn(string $mO81T = 'floor') : array
    {
        goto i0fZy;
        r1SRQ:
        qUi_8:
        goto DUDPe;
        Av7wZ:
        Q7ec0:
        goto bBru3;
        ah1QG:
        $XKbIO = $this->KKGSE * $I_ys7;
        goto Hy4sA;
        DUDPe:
        return ['width' => $QW0P2, 'height' => $ACQN5];
        goto qhXKc;
        qksKM:
        if (!($LqL2v > 2026 or $LqL2v === 2026 and $IlTEr > 3 or $LqL2v === 2026 and $IlTEr === 3 and $Jjjfk->day >= 1)) {
            goto cu_gD;
        }
        goto d0Gzh;
        eVWca:
        $ACQN5 = $MP2z1;
        goto KtinN;
        CGLJF:
        $QW0P2 = 2;
        goto Av7wZ;
        I7rHQ:
        $LqL2v = $Jjjfk->year;
        goto AyBSl;
        jS9Zg:
        $ACQN5 = 0;
        goto dubw2;
        dubw2:
        if ($this->KKGSE >= $this->mLEaZ) {
            goto Ht1gA;
        }
        goto kadEG;
        YtptJ:
        $ACQN5 = 2;
        goto r1SRQ;
        C4UmK:
        $Jjjfk = now();
        goto I7rHQ;
        a7rIb:
        $QW0P2 = 0;
        goto C4UmK;
        lUIUz:
        if (!($QW0P2 < 2)) {
            goto Q7ec0;
        }
        goto CGLJF;
        d0Gzh:
        return ['val' => 'null', 'item' => true];
        goto n7CCE;
        FQx8G:
        goto XIcuB;
        goto RRdGQ;
        Z3u_7:
        XIcuB:
        goto lUIUz;
        Hy4sA:
        $QW0P2 = self::maTZaDLI7q4(round($XKbIO), $mO81T);
        goto Z3u_7;
        bBru3:
        if (!($ACQN5 < 2)) {
            goto qUi_8;
        }
        goto YtptJ;
        BbbgD:
        $ACQN5 = self::maTZaDLI7q4(round($c30Ra), $mO81T);
        goto FQx8G;
        AyBSl:
        $IlTEr = $Jjjfk->month;
        goto qksKM;
        RRdGQ:
        Ht1gA:
        goto eVWca;
        K3yaz:
        $c30Ra = $this->mLEaZ * $I_ys7;
        goto BbbgD;
        i0fZy:
        $MP2z1 = 1080;
        goto a7rIb;
        n7CCE:
        cu_gD:
        goto jS9Zg;
        D6e8E:
        $I_ys7 = $QW0P2 / $this->KKGSE;
        goto K3yaz;
        KtinN:
        $I_ys7 = $ACQN5 / $this->mLEaZ;
        goto ah1QG;
        kadEG:
        $QW0P2 = $MP2z1;
        goto D6e8E;
        qhXKc:
    }
}
