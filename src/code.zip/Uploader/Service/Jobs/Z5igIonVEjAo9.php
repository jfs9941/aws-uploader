<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Z5igIonVEjAo9 implements CompressJobInterface
{
    const BfCcw = 60;
    private $bLQUI;
    private $svYhv;
    private $BZrcY;
    public function __construct($xA3df, $uLgU3, $bdI52)
    {
        goto UMfqd;
        UMfqd:
        $this->bLQUI = $xA3df;
        goto tiRp0;
        GInul:
        $this->svYhv = $uLgU3;
        goto p0C2F;
        tiRp0:
        $this->BZrcY = $bdI52;
        goto GInul;
        p0C2F:
    }
    public function compress(string $ShXx2)
    {
        goto LplcG;
        ZVBPN:
        Log::info("Compress image", ['imageId' => $ShXx2]);
        goto T1uUZ;
        LplcG:
        $NPFCL = microtime(true);
        goto fnqn6;
        fnqn6:
        $yfGDI = memory_get_usage();
        goto iNAq_;
        iNAq_:
        $xdRdR = memory_get_peak_usage();
        goto ZVBPN;
        T1uUZ:
        try {
            goto dMtJ_;
            GYGyw:
            $BRgkt = $this->svYhv->path($xixtT->getLocation());
            goto MUuUv;
            sBpuR:
            qSrhd:
            goto yegd9;
            dMtJ_:
            $xixtT = Vt3ybt0yfaPAa::findOrFail($ShXx2);
            goto GYGyw;
            RmlBP:
            $xixtT = $this->mkUlm5ctLKg($xixtT, 'jpg');
            goto sBpuR;
            MUuUv:
            if (!(strtolower($xixtT->getExtension()) === 'png' || strtolower($xixtT->getExtension()) === 'heic')) {
                goto qSrhd;
            }
            goto RmlBP;
            yegd9:
            try {
                goto dUbWw;
                bTRnE:
                $this->mkUlm5ctLKg($xixtT, 'webp');
                goto yiF4_;
                dUbWw:
                $fIePZ = $this->svYhv->path(str_replace('.jpg', '.webp', $xixtT->getLocation()));
                goto EGxg7;
                EGxg7:
                $this->mhLQ74wZFZ5($BRgkt, $fIePZ);
                goto bTRnE;
                yiF4_:
            } catch (\Exception $KY3Rq) {
                goto eNEFz;
                oGkz8:
                $this->mlxWAcxtVoY($BRgkt, $fIePZ);
                goto uxM4f;
                wajSA:
                $fIePZ = $this->svYhv->path($xixtT->getLocation());
                goto oGkz8;
                eNEFz:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $ShXx2, 'error' => $KY3Rq->getMessage()]);
                goto wajSA;
                uxM4f:
            }
            goto wNahl;
            wNahl:
        } catch (\Throwable $KY3Rq) {
            goto jpJP7;
            lISLb:
            Log::error("Failed to compress image", ['imageId' => $ShXx2, 'error' => $KY3Rq->getMessage()]);
            goto XytrM;
            hWlpv:
            Log::info("Vt3ybt0yfaPAa has been deleted, discard it", ['imageId' => $ShXx2]);
            goto wocpA;
            jpJP7:
            if (!$KY3Rq instanceof ModelNotFoundException) {
                goto yBJhj;
            }
            goto hWlpv;
            vo189:
            yBJhj:
            goto lISLb;
            wocpA:
            return;
            goto vo189;
            XytrM:
        } finally {
            $w1aby = microtime(true);
            $u5HI9 = memory_get_usage();
            $LDlnt = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $ShXx2, 'execution_time_sec' => $w1aby - $NPFCL, 'memory_usage_mb' => ($u5HI9 - $yfGDI) / 1024 / 1024, 'peak_memory_usage_mb' => ($LDlnt - $xdRdR) / 1024 / 1024]);
        }
        goto wuZJS;
        wuZJS:
    }
    private function mlxWAcxtVoY($BRgkt, $fIePZ)
    {
        goto QJ_gT;
        up7Cs:
        $this->BZrcY->put($fIePZ, $S1JNo->toJpeg(self::BfCcw), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto ltBeG;
        HMLrj:
        $S1JNo->orient()->toJpeg(self::BfCcw)->save($fIePZ);
        goto up7Cs;
        ltBeG:
        unset($S1JNo);
        goto xzzfB;
        QJ_gT:
        $S1JNo = $this->bLQUI->call($this, $BRgkt);
        goto HMLrj;
        xzzfB:
    }
    private function mhLQ74wZFZ5($BRgkt, $fIePZ)
    {
        goto iQMGW;
        W_jn2:
        $this->BZrcY->put($fIePZ, $S1JNo->toJpeg(self::BfCcw), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto XEYew;
        iQMGW:
        $S1JNo = $this->bLQUI->call($this, $BRgkt);
        goto ertQb;
        ertQb:
        $S1JNo->orient()->toWebp(self::BfCcw);
        goto W_jn2;
        XEYew:
        unset($S1JNo);
        goto iOucB;
        iOucB:
    }
    private function mkUlm5ctLKg($xixtT, $wpfYf)
    {
        goto I4aWr;
        jPtfW:
        $xixtT->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$wpfYf}", $xixtT->getLocation()));
        goto IfNPg;
        I4aWr:
        $xixtT->setAttribute('type', $wpfYf);
        goto jPtfW;
        fmFgW:
        return $xixtT;
        goto oT0We;
        IfNPg:
        $xixtT->save();
        goto fmFgW;
        oT0We:
    }
}
