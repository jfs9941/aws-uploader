<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class HDiithkLldbxY implements GenerateThumbnailForVideoInterface
{
    private $CudU0;
    public function __construct($m1i6x)
    {
        $this->CudU0 = $m1i6x;
    }
    public function generate(string $UcmDx) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $UcmDx);
        $this->CudU0->createThumbnail($UcmDx);
    }
}
