<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Enum\FileStatus;
class QQvjRM8pgb9fV implements GenerateThumbnailJobInterface
{
    const VOqXQ = 150;
    const kI5ZC = 150;
    private $Q1e5h;
    private $tGIcp;
    public function __construct($OdpJM, $UR4Dl)
    {
        $this->Q1e5h = $OdpJM;
        $this->tGIcp = $UR4Dl;
    }
    public function generate(string $BFPg9)
    {
        goto Dmqs_;
        Dmqs_:
        Log::info("Generating thumbnail", ['imageId' => $BFPg9]);
        goto RuYBN;
        RuYBN:
        ini_set('memory_limit', '-1');
        goto X1cLu;
        X1cLu:
        try {
            goto WKL6Y;
            xUWyl:
            $EPwtT->encode('jpg', 80);
            goto cAtYE;
            WKL6Y:
            $eX8wo = $this->tGIcp;
            goto pEWD4;
            INToE:
            if (!($JfxZT !== false)) {
                goto ExYWI;
            }
            goto b1whZ;
            rdOeN:
            if (chmod($xzWfp, 0644)) {
                goto iM8jb;
            }
            goto U6ks7;
            pEWD4:
            $ab1g_ = ID6EZw1DKfqu4::findOrFail($BFPg9);
            goto TpDRl;
            pFBHC:
            iM8jb:
            goto m0IFn;
            h3G9H:
            throw new \Exception('Failed to set file permissions for stored image: ' . $xzWfp);
            goto pFBHC;
            m0IFn:
            ExYWI:
            goto LcbOj;
            cAtYE:
            $fdqWg = $this->myy6cfLsqHs($ab1g_);
            goto siLmN;
            WpfUy:
            $EPwtT->destroy();
            goto INToE;
            VUDgj:
            $EPwtT->fit(150, 150, function ($gjzqq) {
                $gjzqq->aspectRatio();
            });
            goto xUWyl;
            kUQSM:
            $xzWfp = $eX8wo->path($fdqWg);
            goto rdOeN;
            TpDRl:
            $EPwtT = $this->Q1e5h->call($this, $eX8wo->path($ab1g_->getLocation()));
            goto VUDgj;
            U6ks7:
            Log::warning('Failed to set file permissions for stored image: ' . $xzWfp);
            goto h3G9H;
            siLmN:
            $JfxZT = $eX8wo->put($fdqWg, $EPwtT->stream(), ['visibility' => 'public']);
            goto WpfUy;
            b1whZ:
            $ab1g_->update(['thumbnail' => $fdqWg, 'status' => FileStatus::THUMBNAIL_PROCESSED]);
            goto kUQSM;
            LcbOj:
        } catch (ModelNotFoundException $X1eT0) {
            Log::info("ID6EZw1DKfqu4 has been deleted, discard it", ['imageId' => $BFPg9]);
            return;
        }
        goto uD7aH;
        uD7aH:
    }
    private function myy6cfLsqHs(TvpGfrAj9WMXE $ab1g_) : string
    {
        goto Ep4z9;
        ioB6B:
        $kZACY = dirname($fdqWg);
        goto D9iAp;
        P8pLq:
        return $H429e . '/' . $ab1g_->getFilename() . '.jpg';
        goto AeUUj;
        Ep4z9:
        $fdqWg = $ab1g_->getLocation();
        goto ioB6B;
        D9iAp:
        $H429e = $kZACY . '/' . self::VOqXQ . 'X' . self::kI5ZC;
        goto P8pLq;
        AeUUj:
    }
}
