<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\JyZaxpharsbun;
class F9RJ1S4hTeCdB implements WatermarkTextJobInterface
{
    private $IfECA;
    private $wzdVy;
    private $EHcHx;
    private $zTo0t;
    private $s0VP1;
    public function __construct($AaIEl, $HIvH7, $Vi8xq, $TuWZt, $HhqtH)
    {
        goto nnMHg;
        W68CN:
        $this->wzdVy = $HIvH7;
        goto V3Ws8;
        qIGM2:
        $this->EHcHx = $HhqtH;
        goto W68CN;
        nnMHg:
        $this->IfECA = $AaIEl;
        goto KQ7Of;
        A6oh5:
        $this->s0VP1 = $TuWZt;
        goto qIGM2;
        KQ7Of:
        $this->zTo0t = $Vi8xq;
        goto A6oh5;
        V3Ws8:
    }
    public function putWatermark(string $S6xyJ, string $QyRqP) : void
    {
        goto nkgzi;
        cuUAM:
        $V2At5 = memory_get_peak_usage();
        goto HgAN3;
        HgAN3:
        Log::info("Adding watermark text to image", ['imageId' => $S6xyJ]);
        goto unNoL;
        iu3PE:
        $JMKzk = memory_get_usage();
        goto cuUAM;
        ib7UT:
        try {
            goto ZGRjS;
            UlyFm:
            if (chmod($z69yI, 0664)) {
                goto XBoX9;
            }
            goto Kw5Ti;
            Y_Onl:
            $this->mVKd9wZkWJM($WhAgX, $QyRqP);
            goto Mm2w5;
            Mm2w5:
            $WhAgX->save($z69yI);
            goto MyweI;
            KBGuL:
            Log::error("JyZaxpharsbun is not on local, might be deleted before put watermark", ['imageId' => $S6xyJ]);
            goto U8ALS;
            ZGRjS:
            $iy9bs = JyZaxpharsbun::findOrFail($S6xyJ);
            goto OKqDr;
            pLPj0:
            throw new \Exception('Failed to set final permissions on image file: ' . $z69yI);
            goto f1zrJ;
            i0DZ2:
            $WhAgX = $this->IfECA->call($this, $z69yI);
            goto ff6ae;
            U8ALS:
            return;
            goto Z21ZI;
            uS_lw:
            $z69yI = $this->s0VP1->path($iy9bs->getLocation());
            goto i0DZ2;
            MyweI:
            $WhAgX->destroy();
            goto UlyFm;
            ff6ae:
            $WhAgX->orientate();
            goto Y_Onl;
            Kw5Ti:
            \Log::warning('Failed to set final permissions on image file: ' . $z69yI);
            goto pLPj0;
            Z21ZI:
            mMxcD:
            goto uS_lw;
            f1zrJ:
            XBoX9:
            goto IQMp3;
            OKqDr:
            if ($this->s0VP1->exists($iy9bs->getLocation())) {
                goto mMxcD;
            }
            goto KBGuL;
            IQMp3:
        } catch (\Throwable $mJFRx) {
            goto uja2l;
            iQ1it:
            return;
            goto Zvicf;
            oq7ht:
            Log::info("JyZaxpharsbun has been deleted, discard it", ['imageId' => $S6xyJ]);
            goto iQ1it;
            Zvicf:
            Y8eH5:
            goto LJh3x;
            uja2l:
            if (!$mJFRx instanceof ModelNotFoundException) {
                goto Y8eH5;
            }
            goto oq7ht;
            LJh3x:
            Log::error("JyZaxpharsbun is not readable", ['imageId' => $S6xyJ, 'error' => $mJFRx->getMessage()]);
            goto RWdXD;
            RWdXD:
        } finally {
            $Mzhg0 = microtime(true);
            $xdlh4 = memory_get_usage();
            $OC5ML = memory_get_peak_usage();
            Log::info('HCrMjr1ZIoi6r function resource usage', ['imageId' => $S6xyJ, 'execution_time_sec' => $Mzhg0 - $piVF4, 'memory_usage_bytes' => $xdlh4 - $JMKzk, 'peak_memory_usage_bytes' => $OC5ML - $V2At5]);
        }
        goto XxF1K;
        nkgzi:
        $piVF4 = microtime(true);
        goto iu3PE;
        unNoL:
        ini_set('memory_limit', '-1');
        goto ib7UT;
        XxF1K:
    }
    private function mVKd9wZkWJM($WhAgX, $QyRqP) : void
    {
        goto mWWOk;
        RWwqz:
        $this->s0VP1->put($eKVHm, $this->zTo0t->get($eKVHm));
        goto kwajF;
        SRwg2:
        $t51Nx->opacity(35);
        goto jiGS5;
        mWWOk:
        $kl8qs = $WhAgX->width();
        goto j8tJI;
        qp6ay:
        $eKVHm = $Mnzeo->mpYSbSHWX85($kl8qs, $nl3gy, $QyRqP, true);
        goto RWwqz;
        j8tJI:
        $nl3gy = $WhAgX->height();
        goto YAO6n;
        jiGS5:
        $WhAgX->insert($t51Nx);
        goto aAQyW;
        YAO6n:
        $Mnzeo = new KRAKiGGIqBhRX($this->wzdVy, $this->EHcHx, $this->zTo0t, $this->s0VP1);
        goto qp6ay;
        kwajF:
        $t51Nx = $this->IfECA->call($this, $this->s0VP1->path($eKVHm));
        goto SRwg2;
        aAQyW:
    }
}
