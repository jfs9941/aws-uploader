<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
class QxCmYYAinhuSZ implements WatermarkTextJobInterface
{
    private $TMqxn;
    private $dj1MR;
    private $AuZBF;
    private $IRlXr;
    private $aB4Qh;
    public function __construct($xskW6, $ckm9x, $JGvdR, $Q0D24, $AEiKj)
    {
        goto Q6d8h;
        Q6d8h:
        $this->TMqxn = $xskW6;
        goto b3XbQ;
        efM2G:
        $this->aB4Qh = $Q0D24;
        goto njq_y;
        b3qeS:
        $this->dj1MR = $ckm9x;
        goto oosRa;
        b3XbQ:
        $this->IRlXr = $JGvdR;
        goto efM2G;
        njq_y:
        $this->AuZBF = $AEiKj;
        goto b3qeS;
        oosRa:
    }
    public function putWatermark(string $R7IrL, string $t1mLK) : void
    {
        goto J0xxz;
        PF43J:
        try {
            goto hFn2b;
            Pa2Vz:
            if (chmod($XkdbN, 0664)) {
                goto MZJHZ;
            }
            goto NfXie;
            clZZx:
            $bQfZL = $this->TMqxn->call($this, $XkdbN);
            goto hzULh;
            EU1lJ:
            throw new \Exception('Failed to set final permissions on image file: ' . $XkdbN);
            goto T7QLG;
            AGrHs:
            ynzJw:
            goto s5ZqU;
            Hg17L:
            $this->mTDXJT9RCdA($bQfZL, $t1mLK);
            goto Tdf7T;
            CAilE:
            $bQfZL->destroy();
            goto Pa2Vz;
            hFn2b:
            $Xxl6q = OcbNsXl9lpteB::findOrFail($R7IrL);
            goto vwvW2;
            hzULh:
            $bQfZL->orientate();
            goto Hg17L;
            s5ZqU:
            $XkdbN = $this->aB4Qh->path($Xxl6q->getLocation());
            goto clZZx;
            rNbo5:
            return;
            goto AGrHs;
            NfXie:
            \Log::warning('Failed to set final permissions on image file: ' . $XkdbN);
            goto EU1lJ;
            vwvW2:
            if ($this->aB4Qh->exists($Xxl6q->getLocation())) {
                goto ynzJw;
            }
            goto n0haP;
            Tdf7T:
            $bQfZL->save($XkdbN);
            goto CAilE;
            T7QLG:
            MZJHZ:
            goto a6Bzh;
            n0haP:
            Log::error("OcbNsXl9lpteB is not on local, might be deleted before put watermark", ['imageId' => $R7IrL]);
            goto rNbo5;
            a6Bzh:
        } catch (\Throwable $T_fDV) {
            goto FAPli;
            L8c2D:
            Pc0iE:
            goto lacqj;
            mzmxp:
            return;
            goto L8c2D;
            rciwh:
            Log::info("OcbNsXl9lpteB has been deleted, discard it", ['imageId' => $R7IrL]);
            goto mzmxp;
            lacqj:
            Log::error("OcbNsXl9lpteB is not readable", ['imageId' => $R7IrL, 'error' => $T_fDV->getMessage()]);
            goto pF1eM;
            FAPli:
            if (!$T_fDV instanceof ModelNotFoundException) {
                goto Pc0iE;
            }
            goto rciwh;
            pF1eM:
        }
        goto W1pcb;
        fRuJ9:
        ini_set('memory_limit', '-1');
        goto PF43J;
        J0xxz:
        Log::info("Adding watermark text to image", ['imageId' => $R7IrL]);
        goto fRuJ9;
        W1pcb:
    }
    private function mTDXJT9RCdA($bQfZL, $t1mLK) : void
    {
        goto C9Oja;
        yNCWK:
        $v3e5U = $Et4Ld->mwyFxhSDrij($yyWeX, $q2cOY, $t1mLK, true);
        goto v61ph;
        v61ph:
        $this->aB4Qh->put($v3e5U, $this->IRlXr->get($v3e5U));
        goto X4z69;
        C9Oja:
        $yyWeX = $bQfZL->width();
        goto xcxz7;
        lGsyR:
        $bQfZL->insert($QVzLS);
        goto yYznk;
        La1vx:
        $Et4Ld = new YkQZ80FqJ5eHy($this->dj1MR, $this->AuZBF, $this->IRlXr, $this->aB4Qh);
        goto yNCWK;
        xcxz7:
        $q2cOY = $bQfZL->height();
        goto La1vx;
        X4z69:
        $QVzLS = $this->TMqxn->call($this, $this->aB4Qh->path($v3e5U));
        goto BdRw_;
        BdRw_:
        $QVzLS->opacity(35);
        goto lGsyR;
        yYznk:
    }
}
