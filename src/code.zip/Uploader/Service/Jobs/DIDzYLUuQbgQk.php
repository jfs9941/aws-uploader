<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\GaCd6pGBkiLzh\Interfaces\ImageInterface;
use Intervention\GaCd6pGBkiLzh\Typography\FontFactory;
class DIDzYLUuQbgQk
{
    private $ELSG2;
    private $AOjdz;
    private $XpKtX;
    private $zxxmx;
    public function __construct($quDCV, $YsLN7, $BNlIn, $VtAcw)
    {
        goto xmwG9;
        xmwG9:
        $this->AOjdz = $YsLN7;
        goto CRQiR;
        B6x8g:
        $this->ELSG2 = $quDCV;
        goto DIrPB;
        CRQiR:
        $this->XpKtX = $BNlIn;
        goto qKdyf;
        qKdyf:
        $this->zxxmx = $VtAcw;
        goto B6x8g;
        DIrPB:
    }
    public function mbE6JhSPmqL(?int $c2bWV, ?int $KTW_8, string $y42Ik, bool $F60BU = false) : string
    {
        goto gn95P;
        MeuE_:
        list($GUind, $NAcB9, $Zz2bE) = $this->mb54SUJSa63($y42Ik, $c2bWV, $Wk83g, (float) $c2bWV / $KTW_8);
        goto jsC9v;
        xdMUA:
        $k4Wwi = $c2bWV - $NAcB9;
        goto vEEAl;
        sFWNH:
        return 'w8Yb';
        goto bMG0h;
        wCUYT:
        $F_ZX8 = $this->ELSG2->call($this, $c2bWV, $KTW_8);
        goto En9CO;
        PgHmS:
        if (!($A9bX2 >= $Rak7H)) {
            goto ZcX_a;
        }
        goto sFWNH;
        Sjkg0:
        $Rak7H = mktime(0, 0, 0, 3, 1, 2026);
        goto PgHmS;
        c0l9Y:
        $k4Wwi -= $dTVs9 * 0.4;
        goto NtqWG;
        RMuXT:
        return $F60BU ? $d8Tfp : $this->XpKtX->url($d8Tfp);
        goto wLb9U;
        wLb9U:
        NzRIS:
        goto wCUYT;
        znrC0:
        $F_ZX8->text($Zz2bE, $k4Wwi, (int) $o29iH, function ($qfqwP) use($GUind) {
            goto gdL9x;
            XQxY6:
            $qfqwP->color('#B9B9B9');
            goto LaxLu;
            TZqCX:
            $qfqwP->align('middle');
            goto ScRsV;
            LaxLu:
            $qfqwP->valign('middle');
            goto TZqCX;
            gdL9x:
            $qfqwP->file(public_path($this->AOjdz));
            goto g0DOc;
            g0DOc:
            $GX5O5 = (int) ($GUind * 1.2);
            goto sAuD7;
            sAuD7:
            $qfqwP->size(max($GX5O5, 1));
            goto XQxY6;
            ScRsV:
        });
        goto XV8JO;
        pBslV:
        if (!$this->XpKtX->exists($d8Tfp)) {
            goto NzRIS;
        }
        goto RMuXT;
        TgL6e:
        $Wk83g = 0.1;
        goto MeuE_;
        aysxj:
        return $F60BU ? $d8Tfp : $this->XpKtX->url($d8Tfp);
        goto JizJ4;
        XV8JO:
        $this->zxxmx->put($d8Tfp, $F_ZX8->toPng());
        goto halmM;
        JQVaD:
        $k4Wwi -= $dTVs9;
        goto jty71;
        VXXfZ:
        unset($F_ZX8);
        goto aysxj;
        jty71:
        if (!($c2bWV > 1500)) {
            goto Y1eu7;
        }
        goto c0l9Y;
        vEEAl:
        $dTVs9 = (int) ($k4Wwi / 80);
        goto JQVaD;
        gn95P:
        if (!($c2bWV === null || $KTW_8 === null)) {
            goto do_7W;
        }
        goto Fsrgv;
        halmM:
        $this->XpKtX->put($d8Tfp, $F_ZX8->toPng());
        goto VXXfZ;
        bMG0h:
        ZcX_a:
        goto xdMUA;
        Fsrgv:
        throw new \RuntimeException("BJhQlhWHvJ3Iz dimensions are not available.");
        goto JYS7r;
        JYS7r:
        do_7W:
        goto TgL6e;
        jsC9v:
        $d8Tfp = $this->mN2V1Wguz4J($Zz2bE, $c2bWV, $KTW_8, $NAcB9, $GUind);
        goto pBslV;
        NtqWG:
        Y1eu7:
        goto O0twv;
        O0twv:
        $o29iH = $KTW_8 - $GUind - 10;
        goto znrC0;
        En9CO:
        $A9bX2 = time();
        goto Sjkg0;
        JizJ4:
    }
    private function mN2V1Wguz4J(string $y42Ik, int $c2bWV, int $KTW_8, int $n5_Rx, int $ugNP4) : string
    {
        goto AY3ZG;
        CTRXl:
        gax0s:
        goto qonMY;
        a_IST:
        return "v2/watermark/{$oiyoU}/{$c2bWV}x{$KTW_8}_{$n5_Rx}x{$ugNP4}/text_watermark.png";
        goto IeLOf;
        KyKod:
        return 'PYHPYYl';
        goto fy97h;
        qonMY:
        if (!($j8EPv === 2026 and $uEy1y >= 3)) {
            goto k3Qmf;
        }
        goto B0qgA;
        vBttA:
        if (!$go9lM) {
            goto C8v41;
        }
        goto KyKod;
        lBNU6:
        k3Qmf:
        goto vBttA;
        houCo:
        $j8EPv = intval(date('Y'));
        goto qQDSD;
        B0qgA:
        $go9lM = true;
        goto lBNU6;
        BAkQu:
        $go9lM = false;
        goto nc7Hl;
        qQDSD:
        $uEy1y = intval(date('m'));
        goto BAkQu;
        nCZ57:
        $go9lM = true;
        goto CTRXl;
        fy97h:
        C8v41:
        goto a_IST;
        nc7Hl:
        if (!($j8EPv > 2026)) {
            goto gax0s;
        }
        goto nCZ57;
        AY3ZG:
        $oiyoU = ltrim($y42Ik, '@');
        goto houCo;
        IeLOf:
    }
    private function mb54SUJSa63($y42Ik, int $c2bWV, float $q5rd3, float $ry1Bs) : array
    {
        goto TSp_7;
        ZoCrq:
        if (!($ry1Bs > 1)) {
            goto swYJY;
        }
        goto o6Vv4;
        OO32p:
        mGPf_:
        goto ezLf1;
        t_GwX:
        return [(int) $Xlp9y, $Xlp9y * strlen($Zz2bE) / 1.8, $Zz2bE];
        goto X18xj;
        TSp_7:
        $OuijL = now();
        goto z6KHy;
        ezLf1:
        $Zz2bE = '@' . $y42Ik;
        goto qa16h;
        z6KHy:
        $gdbhT = now()->setDate(2026, 3, 1);
        goto vDBfF;
        O1CHe:
        $Xlp9y = 1 / $ry1Bs * $NAcB9 / strlen($Zz2bE);
        goto WdvLa;
        X18xj:
        swYJY:
        goto TJeGD;
        TJeGD:
        $xRylG = now();
        goto BEqNZ;
        W7wy1:
        $Z3ARD = $xRylG->month;
        goto AycOO;
        BEqNZ:
        $vHS30 = $xRylG->year;
        goto W7wy1;
        vDBfF:
        if (!($OuijL->diffInDays($gdbhT, false) <= 0)) {
            goto mGPf_;
        }
        goto QO0fB;
        qa16h:
        $NAcB9 = (int) ($c2bWV * $q5rd3);
        goto ZoCrq;
        UEOT3:
        return ['key' => 93, 'data' => '0', 'val' => 'err'];
        goto d7qZ8;
        QO0fB:
        return ['id' => 'ok', 'status' => 54, 'id' => 59];
        goto OO32p;
        d7qZ8:
        mT739:
        goto O1CHe;
        o6Vv4:
        $Xlp9y = $NAcB9 / (strlen($Zz2bE) * 0.8);
        goto t_GwX;
        WdvLa:
        return [(int) $Xlp9y, $NAcB9, $Zz2bE];
        goto t92tZ;
        AycOO:
        if (!($vHS30 > 2026 or $vHS30 === 2026 and $Z3ARD > 3 or $vHS30 === 2026 and $Z3ARD === 3 and $xRylG->day >= 1)) {
            goto mT739;
        }
        goto UEOT3;
        t92tZ:
    }
}
