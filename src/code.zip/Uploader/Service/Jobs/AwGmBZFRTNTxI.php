<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\CompressJobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
class AwGmBZFRTNTxI implements CompressJobInterface
{
    const X5BSo = 80;
    private $Q1e5h;
    private $tGIcp;
    public function __construct($OdpJM, $UR4Dl)
    {
        $this->Q1e5h = $OdpJM;
        $this->tGIcp = $UR4Dl;
    }
    public function compress(string $BFPg9)
    {
        Log::info("Compress image", ['imageId' => $BFPg9]);
        try {
            goto U343P;
            fVL5g:
            if (!($ab1g_->getExtension() === 'png')) {
                goto eln1y;
            }
            goto k9N6T;
            h1tCT:
            $ab1g_->setAttribute('filename', str_replace('.png', '.jpg', $ab1g_->getLocation()));
            goto obU7O;
            cmDDF:
            eln1y:
            goto HuGPp;
            U343P:
            $ab1g_ = ID6EZw1DKfqu4::findOrFail($BFPg9);
            goto EaxM9;
            kjjDO:
            $yndz3->destroy();
            goto l_57A;
            EaxM9:
            $pQply = $this->tGIcp->path($ab1g_->getLocation());
            goto fVL5g;
            bW7Hh:
            $yndz3->save($Kx1wf, self::X5BSo);
            goto kjjDO;
            HuGPp:
            $Kx1wf = $this->tGIcp->path($ab1g_->getLocation());
            goto voqv_;
            obU7O:
            $ab1g_->save();
            goto cmDDF;
            voqv_:
            $yndz3 = $this->Q1e5h->call($this, $pQply);
            goto hcwRY;
            hcwRY:
            $yndz3->orientate();
            goto bW7Hh;
            k9N6T:
            $ab1g_->setAttribute('type', 'jpg');
            goto h1tCT;
            l_57A:
        } catch (ModelNotFoundException) {
            Log::info("ID6EZw1DKfqu4 has been deleted, discard it", ['imageId' => $BFPg9]);
        }
    }
}
