<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ErCveJ2oDsc0T
{
    private $DyLHt;
    private $XtCYQ;
    public function __construct(int $PSUt2, int $URYUx)
    {
        goto cr_3b;
        cr_3b:
        if (!($PSUt2 <= 0)) {
            goto mezvz;
        }
        goto DO9al;
        RoOwo:
        $this->DyLHt = $PSUt2;
        goto iWBZY;
        UTqbE:
        mezvz:
        goto nWzyc;
        nWzyc:
        if (!($URYUx <= 0)) {
            goto veiik;
        }
        goto I6Nis;
        iWBZY:
        $this->XtCYQ = $URYUx;
        goto uSfVf;
        K8VYr:
        veiik:
        goto RoOwo;
        DO9al:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto UTqbE;
        I6Nis:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto K8VYr;
        uSfVf:
    }
    private static function mRhBJacmcQa($Ks9CX, string $BU6mO = 'floor') : int
    {
        goto cD9_R;
        QmIKn:
        if (!(is_float($Ks9CX) && $Ks9CX == floor($Ks9CX) && (int) $Ks9CX % 2 === 0)) {
            goto v0bvT;
        }
        goto RWkzG;
        tfhAP:
        switch (strtolower($BU6mO)) {
            case 'ceil':
                return (int) (ceil($Ks9CX / 2) * 2);
            case 'round':
                return (int) (round($Ks9CX / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($Ks9CX / 2) * 2);
        }
        goto sAHl9;
        wLn_7:
        v0bvT:
        goto tfhAP;
        WPBob:
        return $Ks9CX;
        goto ufqp4;
        ufqp4:
        vaFe3:
        goto QmIKn;
        YO179:
        iIr_p:
        goto acsfd;
        cD9_R:
        if (!(is_int($Ks9CX) && $Ks9CX % 2 === 0)) {
            goto vaFe3;
        }
        goto WPBob;
        sAHl9:
        dD5NM:
        goto YO179;
        RWkzG:
        return (int) $Ks9CX;
        goto wLn_7;
        acsfd:
    }
    public function mydodEyR78l(string $Io2Bs = 'floor') : array
    {
        goto zvblN;
        Bx83a:
        af7RJ:
        goto Diwh3;
        sXROZ:
        $ky612 = self::mRhBJacmcQa(round($WkW8f), $Io2Bs);
        goto cfoP0;
        Ygyai:
        $ky612 = 0;
        goto LPWFL;
        vdhlg:
        $Oe0xY = $this->DyLHt * $Fi6uQ;
        goto b2szw;
        Diwh3:
        if (!($onRfq < 2)) {
            goto diFnS;
        }
        goto VmeG1;
        B1Y5x:
        $ky612 = 2;
        goto CEksK;
        b2szw:
        $onRfq = self::mRhBJacmcQa(round($Oe0xY), $Io2Bs);
        goto Bx83a;
        EKOqo:
        $WkW8f = $this->XtCYQ * $Fi6uQ;
        goto sXROZ;
        o0BgX:
        $ky612 = $wbq80;
        goto gr1_Z;
        wACHA:
        return ['width' => $onRfq, 'height' => $ky612];
        goto uU2rb;
        LPWFL:
        if ($this->DyLHt >= $this->XtCYQ) {
            goto VxKr3;
        }
        goto yLjYw;
        cfoP0:
        goto af7RJ;
        goto uxs3B;
        Sa_nB:
        if (!($ky612 < 2)) {
            goto qjpEh;
        }
        goto B1Y5x;
        bJ6aR:
        $Fi6uQ = $onRfq / $this->DyLHt;
        goto EKOqo;
        zvblN:
        $wbq80 = 1080;
        goto bQR84;
        gr1_Z:
        $Fi6uQ = $ky612 / $this->XtCYQ;
        goto vdhlg;
        uxs3B:
        VxKr3:
        goto o0BgX;
        yLjYw:
        $onRfq = $wbq80;
        goto bJ6aR;
        CEksK:
        qjpEh:
        goto wACHA;
        fnPef:
        diFnS:
        goto Sa_nB;
        VmeG1:
        $onRfq = 2;
        goto fnPef;
        bQR84:
        $onRfq = 0;
        goto Ygyai;
        uU2rb:
    }
}
