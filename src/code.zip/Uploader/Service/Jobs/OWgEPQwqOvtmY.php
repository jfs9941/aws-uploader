<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
use Jfs\Uploader\Enum\SsxWbUYXracun;
class OWgEPQwqOvtmY implements StoreVideoToS3JobInterface
{
    private $sLHA6;
    private $dhrkT;
    private $sf39X;
    public function __construct($TyFPC, $v8n0s, $ZqxJI)
    {
        goto TDZWf;
        CwFtF:
        $this->sLHA6 = $TyFPC;
        goto jSw0w;
        wYxdL:
        $this->sf39X = $ZqxJI;
        goto CwFtF;
        TDZWf:
        $this->dhrkT = $v8n0s;
        goto wYxdL;
        jSw0w:
    }
    public function store(string $cQqZd) : void
    {
        goto Cayt3;
        EK9vQ:
        $Sgwln = $ZqxJI->mimeType($XlBkr->getLocation());
        goto g8FXc;
        A65vQ:
        Log::info("G4MP13yRAmltw has been deleted, discard it", ['fileId' => $cQqZd]);
        goto DZSDc;
        fUQvy:
        $XlBkr = G4MP13yRAmltw::find($cQqZd);
        goto VOoib;
        wLVVH:
        if ($ZqxJI->exists($XlBkr->getLocation())) {
            goto FT28u;
        }
        goto InRRB;
        kzwsO:
        $ZqxJI = $this->sf39X;
        goto fUQvy;
        IMra7:
        $o3FRR = memory_get_usage();
        goto pXx3n;
        afdtJ:
        $ZH2Pc = $this->dhrkT->getClient();
        goto kzwsO;
        InRRB:
        Log::error("[OWgEPQwqOvtmY] File not found, discard it ", ['video' => $XlBkr->getLocation()]);
        goto v8ZU6;
        g8FXc:
        $OKKdr = microtime(true);
        goto IMra7;
        v8ZU6:
        return;
        goto i3dhR;
        i3dhR:
        FT28u:
        goto K54bs;
        DZSDc:
        return;
        goto r8LAw;
        Cayt3:
        Log::info('Storing video (local) to S3', ['fileId' => $cQqZd, 'bucketName' => $this->sLHA6]);
        goto eQd8G;
        Fg6hM:
        $aAHm1 = 1024 * 1024 * 50;
        goto EK9vQ;
        r8LAw:
        Rqk30:
        goto wLVVH;
        qcGG0:
        try {
            goto qZeH7;
            GKMkc:
            $ZqxJI->delete($XlBkr->getLocation());
            goto Udg1q;
            rdGy6:
            $Tu5AU = $paaTe['UploadId'];
            goto n3Yfc;
            eHUOg:
            goto QgLZV;
            goto V1rVS;
            vI_uu:
            fclose($LxQ1k);
            goto WwECT;
            W2FPe:
            if (feof($LxQ1k)) {
                goto aDczF;
            }
            goto aEnb9;
            WwECT:
            $ZH2Pc->completeMultipartUpload(['Bucket' => $this->sLHA6, 'Key' => $XlBkr->getLocation(), 'UploadId' => $Tu5AU, 'MultipartUpload' => ['Parts' => $Zkrnk]]);
            goto MrTBc;
            aEnb9:
            $JKPIN = $ZH2Pc->uploadPart(['Bucket' => $this->sLHA6, 'Key' => $XlBkr->getLocation(), 'UploadId' => $Tu5AU, 'PartNumber' => $eX2CE, 'Body' => fread($LxQ1k, $aAHm1)]);
            goto IDC3F;
            n3Yfc:
            $eX2CE = 1;
            goto PXyat;
            IDC3F:
            $Zkrnk[] = ['PartNumber' => $eX2CE, 'ETag' => $JKPIN['ETag']];
            goto EhEzY;
            V1rVS:
            aDczF:
            goto vI_uu;
            qZeH7:
            $paaTe = $ZH2Pc->createMultipartUpload(['Bucket' => $this->sLHA6, 'Key' => $XlBkr->getLocation(), 'ContentType' => $Sgwln, 'ContentDisposition' => 'inline']);
            goto rdGy6;
            MrTBc:
            $XlBkr->update(['driver' => FW54oEnFetVYj::S3, 'status' => SsxWbUYXracun::FINISHED]);
            goto GKMkc;
            EhEzY:
            $eX2CE++;
            goto eHUOg;
            PXyat:
            $Zkrnk = [];
            goto TjFBn;
            TjFBn:
            QgLZV:
            goto W2FPe;
            Udg1q:
        } catch (AwsException $xA1Kf) {
            goto sjBQj;
            lOhoF:
            Log::error('Failed to store video: ' . $XlBkr->getLocation() . ' - ' . $xA1Kf->getMessage());
            goto ExcEt;
            GnWRW:
            try {
                $ZH2Pc->abortMultipartUpload(['Bucket' => $this->sLHA6, 'Key' => $XlBkr->getLocation(), 'UploadId' => $Tu5AU]);
            } catch (AwsException $Di0of) {
                Log::error('Error aborting multipart upload: ' . $Di0of->getMessage());
            }
            goto JqRYX;
            sjBQj:
            if (!isset($Tu5AU)) {
                goto iyzhC;
            }
            goto GnWRW;
            JqRYX:
            iyzhC:
            goto lOhoF;
            ExcEt:
        } finally {
            $yTnwM = microtime(true);
            $qw3CC = memory_get_usage();
            $uML0D = memory_get_peak_usage();
            Log::info('Store G4MP13yRAmltw to S3 function resource usage', ['imageId' => $cQqZd, 'execution_time_sec' => $yTnwM - $OKKdr, 'memory_usage_mb' => ($qw3CC - $o3FRR) / 1024 / 1024, 'peak_memory_usage_mb' => ($uML0D - $wpG9k) / 1024 / 1024]);
        }
        goto rhBIK;
        pXx3n:
        $wpG9k = memory_get_peak_usage();
        goto qcGG0;
        VOoib:
        if ($XlBkr) {
            goto Rqk30;
        }
        goto A65vQ;
        eQd8G:
        ini_set('memory_limit', '-1');
        goto afdtJ;
        K54bs:
        $LxQ1k = $ZqxJI->readStream($XlBkr->getLocation());
        goto Fg6hM;
        rhBIK:
    }
}
