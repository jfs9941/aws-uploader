<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\PKlJoGnL129oy;
use backup\Uploader\Core\CrEYqpC23XUGo;
use Illuminate\Support\Facades\Log;
class B97GgB35i7hKl implements PKlJoGnL129oy
{
    private $kEfMA;
    private $c35HU;
    public function __construct($FP6ih, $VHhUy)
    {
        $this->kEfMA = $FP6ih;
        $this->c35HU = $VHhUy;
    }
    public function download(string $EQQae) : void
    {
        goto b1iry;
        rKPTc:
        if (!$this->c35HU->exists($eVZrJ->getLocation())) {
            goto TTQip;
        }
        goto iNJ3l;
        RZKZ5:
        Log::info("Start download file to local", ['fileId' => $EQQae, 'filename' => $eVZrJ->getLocation()]);
        goto rKPTc;
        ZGtvR:
        $this->c35HU->put($eVZrJ->getLocation(), $this->kEfMA->get($eVZrJ->getLocation()));
        goto U3DDN;
        b1iry:
        $eVZrJ = CrEYqpC23XUGo::findOrFail($EQQae);
        goto RZKZ5;
        iNJ3l:
        return;
        goto LU0Sh;
        LU0Sh:
        TTQip:
        goto ZGtvR;
        U3DDN:
    }
}
