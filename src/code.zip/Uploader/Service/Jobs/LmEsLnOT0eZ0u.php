<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class LmEsLnOT0eZ0u
{
    private $qI5Mc;
    private $jMh7r;
    public function __construct(int $pqyn_, int $R85nb)
    {
        goto rZU86;
        xSFXX:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto lqwrA;
        fAw26:
        $this->qI5Mc = $pqyn_;
        goto T5peJ;
        VqMul:
        auk4X:
        goto tLYbE;
        tLYbE:
        if (!($R85nb <= 0)) {
            goto i5FL0;
        }
        goto xSFXX;
        rZU86:
        if (!($pqyn_ <= 0)) {
            goto auk4X;
        }
        goto g60sr;
        lqwrA:
        i5FL0:
        goto fAw26;
        T5peJ:
        $this->jMh7r = $R85nb;
        goto o1KCX;
        g60sr:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto VqMul;
        o1KCX:
    }
    private static function mmuXp7EiG4z($b29CA, string $wYsG7 = 'floor') : int
    {
        goto b_y9g;
        KUwFT:
        return $b29CA;
        goto dUbfj;
        HM8w1:
        return (int) $b29CA;
        goto IgmCl;
        b_y9g:
        if (!(is_int($b29CA) && $b29CA % 2 === 0)) {
            goto WDd1J;
        }
        goto KUwFT;
        gjsCK:
        mO1_G:
        goto RUILN;
        IgmCl:
        aoZXk:
        goto bVfNv;
        dUbfj:
        WDd1J:
        goto EJ2FA;
        EJ2FA:
        if (!(is_float($b29CA) && $b29CA == floor($b29CA) && (int) $b29CA % 2 === 0)) {
            goto aoZXk;
        }
        goto HM8w1;
        bVfNv:
        switch (strtolower($wYsG7)) {
            case 'ceil':
                return (int) (ceil($b29CA / 2) * 2);
            case 'round':
                return (int) (round($b29CA / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($b29CA / 2) * 2);
        }
        goto esW3i;
        esW3i:
        noCjp:
        goto gjsCK;
        RUILN:
    }
    public function mPjnmT9a49a(string $Efl_0 = 'floor') : array
    {
        goto sm2AT;
        KgvlD:
        $SdXs6 = self::mmuXp7EiG4z(round($EIACK), $Efl_0);
        goto hro3s;
        IYzFI:
        if (!($Hq0K6 < 2)) {
            goto y7Bzu;
        }
        goto ZaNCi;
        vdZmz:
        P27UN:
        goto IYzFI;
        hmhBp:
        $e2iII = $this->jMh7r * $bj3a9;
        goto Lq6YA;
        Lq6YA:
        $Hq0K6 = self::mmuXp7EiG4z(round($e2iII), $Efl_0);
        goto KewKl;
        H2PIJ:
        $Hq0K6 = 0;
        goto B7IWa;
        hro3s:
        Jf4iu:
        goto cTUK6;
        Ftpa7:
        $SdXs6 = 0;
        goto H2PIJ;
        m56oA:
        return ['width' => $SdXs6, 'height' => $Hq0K6];
        goto krQmh;
        cTUK6:
        if (!($SdXs6 < 2)) {
            goto P27UN;
        }
        goto r7rQn;
        GElU0:
        $bj3a9 = $Hq0K6 / $this->jMh7r;
        goto zVTRq;
        zVTRq:
        $EIACK = $this->qI5Mc * $bj3a9;
        goto KgvlD;
        Uz4Su:
        C012q:
        goto ZZEw2;
        ZaNCi:
        $Hq0K6 = 2;
        goto Uzlpz;
        KewKl:
        goto Jf4iu;
        goto Uz4Su;
        EmnGK:
        $SdXs6 = $gRncd;
        goto XflqL;
        ZZEw2:
        $Hq0K6 = $gRncd;
        goto GElU0;
        sm2AT:
        $gRncd = 1080;
        goto Ftpa7;
        B7IWa:
        if ($this->qI5Mc >= $this->jMh7r) {
            goto C012q;
        }
        goto EmnGK;
        r7rQn:
        $SdXs6 = 2;
        goto vdZmz;
        Uzlpz:
        y7Bzu:
        goto m56oA;
        XflqL:
        $bj3a9 = $SdXs6 / $this->qI5Mc;
        goto hmhBp;
        krQmh:
    }
}
