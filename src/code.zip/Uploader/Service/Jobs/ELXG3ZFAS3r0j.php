<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
class ELXG3ZFAS3r0j implements DownloadToLocalJobInterface
{
    private $K79lK;
    private $HyJkj;
    public function __construct($yEBaZ, $N7YvB)
    {
        $this->K79lK = $yEBaZ;
        $this->HyJkj = $N7YvB;
    }
    public function download(string $Qu08p) : void
    {
        goto k8bRM;
        b3jXP:
        u2NCu:
        goto bMhDI;
        jBa2P:
        Log::info("Start download file to local", ['fileId' => $Qu08p, 'filename' => $oYtbp->getLocation()]);
        goto bUExR;
        bMhDI:
        $this->HyJkj->put($oYtbp->getLocation(), $this->K79lK->get($oYtbp->getLocation()));
        goto dDmUu;
        k8bRM:
        $oYtbp = YPgQPiPQjMu1g::findOrFail($Qu08p);
        goto jBa2P;
        bUExR:
        if (!$this->HyJkj->exists($oYtbp->getLocation())) {
            goto u2NCu;
        }
        goto DDXso;
        DDXso:
        return;
        goto b3jXP;
        dDmUu:
    }
}
