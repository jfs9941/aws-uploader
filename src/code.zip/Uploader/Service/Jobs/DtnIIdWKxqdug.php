<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Illuminate\Support\Facades\Log;
class DtnIIdWKxqdug implements StoreVideoToS3JobInterface
{
    private $eOIE2;
    private $iHPgt;
    private $cGz6K;
    public function __construct($XbR1L, $zeM4q, $DAY12)
    {
        goto mpIuk;
        uGOfp:
        $this->cGz6K = $DAY12;
        goto MTEX7;
        MTEX7:
        $this->eOIE2 = $XbR1L;
        goto KOo1c;
        mpIuk:
        $this->iHPgt = $zeM4q;
        goto uGOfp;
        KOo1c:
    }
    public function store(string $tu00C) : void
    {
        goto XVUWB;
        kNqGm:
        $SBeWo = memory_get_usage();
        goto B2TWn;
        GsGeb:
        $GXwkN = 1024 * 1024 * 50;
        goto afZRT;
        noZbp:
        ini_set('memory_limit', '-1');
        goto zzfMN;
        zzfMN:
        $dbHTm = $this->iHPgt->getClient();
        goto ik78q;
        lTgaP:
        try {
            goto HBszi;
            jOy4h:
            if (feof($B32kZ)) {
                goto ATO2A;
            }
            goto vf3gz;
            nPHxk:
            $mzQWp++;
            goto ZwL8Z;
            QqUhX:
            $mzQWp = 1;
            goto sNXgY;
            vf3gz:
            $hlU_D = $dbHTm->uploadPart(['Bucket' => $this->eOIE2, 'Key' => $bkimM->getLocation(), 'UploadId' => $IaSct, 'PartNumber' => $mzQWp, 'Body' => fread($B32kZ, $GXwkN)]);
            goto NZktk;
            bJOPv:
            $DAY12->delete($bkimM->getLocation());
            goto vaoZu;
            NZktk:
            $H1_VI[] = ['PartNumber' => $mzQWp, 'ETag' => $hlU_D['ETag']];
            goto nPHxk;
            AuDZs:
            fclose($B32kZ);
            goto cYVgR;
            Qlyzy:
            jZ35W:
            goto jOy4h;
            HBszi:
            $hd6J3 = $dbHTm->createMultipartUpload(['Bucket' => $this->eOIE2, 'Key' => $bkimM->getLocation(), 'ContentType' => $pOR06, 'ContentDisposition' => 'inline']);
            goto TOEJf;
            WIlPN:
            ATO2A:
            goto AuDZs;
            cYVgR:
            $dbHTm->completeMultipartUpload(['Bucket' => $this->eOIE2, 'Key' => $bkimM->getLocation(), 'UploadId' => $IaSct, 'MultipartUpload' => ['Parts' => $H1_VI]]);
            goto WNkdh;
            sNXgY:
            $H1_VI = [];
            goto Qlyzy;
            ZwL8Z:
            goto jZ35W;
            goto WIlPN;
            WNkdh:
            $bkimM->update(['driver' => ISqBWmYzjt1eQ::S3, 'status' => WSEQ88VDOa3X0::FINISHED]);
            goto bJOPv;
            TOEJf:
            $IaSct = $hd6J3['UploadId'];
            goto QqUhX;
            vaoZu:
        } catch (AwsException $hBzBz) {
            goto EaL51;
            A3BeA:
            try {
                $dbHTm->abortMultipartUpload(['Bucket' => $this->eOIE2, 'Key' => $bkimM->getLocation(), 'UploadId' => $IaSct]);
            } catch (AwsException $NGU2c) {
                Log::error('Error aborting multipart upload: ' . $NGU2c->getMessage());
            }
            goto CaCxg;
            EaL51:
            if (!isset($IaSct)) {
                goto G8H4q;
            }
            goto A3BeA;
            Q4u_f:
            Log::error('Failed to store video: ' . $bkimM->getLocation() . ' - ' . $hBzBz->getMessage());
            goto aXYnh;
            CaCxg:
            G8H4q:
            goto Q4u_f;
            aXYnh:
        } finally {
            $Taw_q = microtime(true);
            $rjavZ = memory_get_usage();
            $Szg_0 = memory_get_peak_usage();
            Log::info('Store SNpic2wzC1yT8 to S3 function resource usage', ['imageId' => $tu00C, 'execution_time_sec' => $Taw_q - $vLJkf, 'memory_usage_mb' => ($rjavZ - $SBeWo) / 1024 / 1024, 'peak_memory_usage_mb' => ($Szg_0 - $wsJtd) / 1024 / 1024]);
        }
        goto b6k6F;
        nt2Ae:
        uUMaa:
        goto lBE1p;
        ik78q:
        $DAY12 = $this->cGz6K;
        goto QGNM3;
        QGNM3:
        $bkimM = SNpic2wzC1yT8::find($tu00C);
        goto zgCXR;
        lBE1p:
        if ($DAY12->exists($bkimM->getLocation())) {
            goto GOhgB;
        }
        goto N29xs;
        qCHzQ:
        return;
        goto aLh6E;
        B2TWn:
        $wsJtd = memory_get_peak_usage();
        goto lTgaP;
        aLh6E:
        GOhgB:
        goto Qt_cO;
        nzBr5:
        $vLJkf = microtime(true);
        goto kNqGm;
        zgCXR:
        if ($bkimM) {
            goto uUMaa;
        }
        goto OFANX;
        Qt_cO:
        $B32kZ = $DAY12->readStream($bkimM->getLocation());
        goto GsGeb;
        WamuA:
        return;
        goto nt2Ae;
        N29xs:
        Log::error("[DtnIIdWKxqdug] File not found, discard it ", ['video' => $bkimM->getLocation()]);
        goto qCHzQ;
        XVUWB:
        Log::info('Storing video (local) to S3', ['fileId' => $tu00C, 'bucketName' => $this->eOIE2]);
        goto noZbp;
        OFANX:
        Log::info("SNpic2wzC1yT8 has been deleted, discard it", ['fileId' => $tu00C]);
        goto WamuA;
        afZRT:
        $pOR06 = $DAY12->mimeType($bkimM->getLocation());
        goto nzBr5;
        b6k6F:
    }
}
