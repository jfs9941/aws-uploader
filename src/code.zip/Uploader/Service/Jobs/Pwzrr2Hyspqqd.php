<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class Pwzrr2Hyspqqd
{
    private $zZRNN;
    private $b8AQe;
    private $RE_2F;
    private $P8Yzg;
    public function __construct($BLhUh, $WjOtg, $WmwnR, $jT0xz)
    {
        goto cxizr;
        eg8wV:
        $this->P8Yzg = $jT0xz;
        goto GjOEQ;
        d52NX:
        $this->RE_2F = $WmwnR;
        goto eg8wV;
        cxizr:
        $this->b8AQe = $WjOtg;
        goto d52NX;
        GjOEQ:
        $this->zZRNN = $BLhUh;
        goto NP9tZ;
        NP9tZ:
    }
    public function mtN0xu2kbrL(?int $tYCg4, ?int $Xnjcp, string $WkdyW, bool $qLpcy = false) : string
    {
        goto vDEMM;
        g9fPY:
        if (!($tYCg4 > 1500)) {
            goto uAy7X;
        }
        goto cnzBd;
        tmaX9:
        uAy7X:
        goto kJYnA;
        t69q3:
        $this->RE_2F->put($AvgzF, $ZQQzW->stream('png'));
        goto G5EQt;
        Qm5lV:
        throw new \RuntimeException("Jf5KRr8uE3t34 dimensions are not available.");
        goto zFsHn;
        venLG:
        $ZQQzW = $this->zZRNN->call($this, $tYCg4, $Xnjcp);
        goto AnydJ;
        e6elZ:
        if (!$this->RE_2F->exists($AvgzF)) {
            goto vStsI;
        }
        goto njo95;
        AnydJ:
        $JnXsH = $tYCg4 - $lnX1n;
        goto e9dhC;
        IfjK1:
        $AvgzF = $this->mMYb8c1fXBV($he3pR, $tYCg4, $Xnjcp, $lnX1n, $LezUX);
        goto e6elZ;
        cnzBd:
        $JnXsH -= $MIES9 * 0.4;
        goto tmaX9;
        UroZ8:
        $ZQQzW->text($he3pR, $JnXsH, (int) $jELy9, function ($zPRZ4) use($LezUX) {
            goto Zl6LO;
            HzFhE:
            $dG6du = (int) ($LezUX * 1.2);
            goto UtjLQ;
            Zl6LO:
            $zPRZ4->file(public_path($this->b8AQe));
            goto HzFhE;
            UtjLQ:
            $zPRZ4->size(max($dG6du, 1));
            goto WUFMQ;
            JLeV0:
            $zPRZ4->valign('middle');
            goto Teg2U;
            WUFMQ:
            $zPRZ4->color([185, 185, 185, 1]);
            goto JLeV0;
            Teg2U:
            $zPRZ4->align('middle');
            goto kw4u3;
            kw4u3:
        });
        goto X5Kr7;
        vDEMM:
        if (!($tYCg4 === null || $Xnjcp === null)) {
            goto MvTpx;
        }
        goto Qm5lV;
        VAEvE:
        $WvVQw = 0.1;
        goto eQXSC;
        e9dhC:
        $MIES9 = (int) ($JnXsH / 80);
        goto pqJ5x;
        ImXxf:
        vStsI:
        goto venLG;
        njo95:
        return $qLpcy ? $AvgzF : $this->RE_2F->url($AvgzF);
        goto ImXxf;
        eQXSC:
        list($LezUX, $lnX1n, $he3pR) = $this->mInUdtbkbNO($WkdyW, $tYCg4, $WvVQw, (float) $tYCg4 / $Xnjcp);
        goto IfjK1;
        G5EQt:
        return $qLpcy ? $AvgzF : $this->RE_2F->url($AvgzF);
        goto GoA7b;
        kJYnA:
        $jELy9 = $Xnjcp - $LezUX - 10;
        goto UroZ8;
        X5Kr7:
        $this->P8Yzg->put($AvgzF, $ZQQzW->stream('png'));
        goto t69q3;
        zFsHn:
        MvTpx:
        goto VAEvE;
        pqJ5x:
        $JnXsH -= $MIES9;
        goto g9fPY;
        GoA7b:
    }
    private function mMYb8c1fXBV(string $WkdyW, int $tYCg4, int $Xnjcp, int $BmHy1, int $jEVvB) : string
    {
        $eoqA4 = ltrim($WkdyW, '@');
        return "v2/watermark/{$eoqA4}/{$tYCg4}x{$Xnjcp}_{$BmHy1}x{$jEVvB}/text_watermark.png";
    }
    private function mInUdtbkbNO($WkdyW, int $tYCg4, float $Qdlat, float $lkDG2) : array
    {
        goto H5Qtc;
        MfyQv:
        return [(int) $HdKyh, $HdKyh * strlen($he3pR) / 1.8, $he3pR];
        goto H6_nA;
        EaAmk:
        if (!($lkDG2 > 1)) {
            goto RHQsd;
        }
        goto s8RaC;
        aAvpY:
        $HdKyh = 1 / $lkDG2 * $lnX1n / strlen($he3pR);
        goto I5PpX;
        I5PpX:
        return [(int) $HdKyh, $lnX1n, $he3pR];
        goto Uy6Pk;
        H5Qtc:
        $he3pR = '@' . $WkdyW;
        goto udtZg;
        udtZg:
        $lnX1n = (int) ($tYCg4 * $Qdlat);
        goto EaAmk;
        s8RaC:
        $HdKyh = $lnX1n / (strlen($he3pR) * 0.8);
        goto MfyQv;
        H6_nA:
        RHQsd:
        goto aAvpY;
        Uy6Pk:
    }
}
