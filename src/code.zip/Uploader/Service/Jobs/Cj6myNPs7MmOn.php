<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class Cj6myNPs7MmOn implements StoreToS3JobInterface
{
    private $bg_1H;
    private $auR_S;
    private $P6k4O;
    public function __construct($IDVBi, $JhAxH, $RNTis)
    {
        goto qiSSI;
        TgfTJ:
        $this->P6k4O = $RNTis;
        goto pSvZ5;
        qiSSI:
        $this->auR_S = $JhAxH;
        goto TgfTJ;
        pSvZ5:
        $this->bg_1H = $IDVBi;
        goto lC5K5;
        lC5K5:
    }
    public function store(string $IaHim) : void
    {
        goto UYxNy;
        tKUnS:
        return;
        goto k6F7e;
        kksay:
        $JM0UK = $this->P6k4O->path($n3Bd_->getLocation());
        goto YiGeC;
        iDfGY:
        DcjZ2:
        goto Zks4s;
        lnsdl:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $IaHim]);
        goto pfaBE;
        Zks4s:
        if (!($n3Bd_->getAttribute('preview') && $this->P6k4O->exists($n3Bd_->getAttribute('preview')))) {
            goto ptPwK;
        }
        goto a90Sq;
        LxigU:
        ptPwK:
        goto cf5E_;
        m2a61:
        $this->auR_S->put($n3Bd_->getAttribute('thumbnail'), $NSw82->stream(), ['visibility' => 'public', 'ContentType' => $NSw82->mime(), 'ContentDisposition' => 'inline']);
        goto iDfGY;
        iVsW0:
        $N6LTi = $n3Bd_->getAttribute('thumbnail');
        goto WSQPv;
        nauYE:
        Log::info("FNGNxcyxjaxBG stored to S3, update the children attachments", ['fileId' => $IaHim]);
        goto QZ8SW;
        yS7Ud:
        if ($n3Bd_) {
            goto DnGxn;
        }
        goto c1p3Q;
        dyxTV:
        $this->auR_S->put($n3Bd_->getLocation(), $kHreC->stream(), ['visibility' => 'public', 'ContentType' => $kHreC->mime(), 'ContentDisposition' => 'inline']);
        goto iVsW0;
        UYxNy:
        $n3Bd_ = FNGNxcyxjaxBG::findOrFail($IaHim);
        goto yS7Ud;
        YiGeC:
        $kHreC = $this->bg_1H->call($this, $JM0UK);
        goto dyxTV;
        KTjUa:
        return;
        goto ksClB;
        Y3m1S:
        $troOF = $this->bg_1H->call($this, $dkqps);
        goto l5g8y;
        QZ8SW:
        FNGNxcyxjaxBG::where('parent_id', $IaHim)->update(['driver' => FUIPeZ7ssitYw::S3, 'preview' => $n3Bd_->getAttribute('preview'), 'thumbnail' => $n3Bd_->getAttribute('thumbnail')]);
        goto KTjUa;
        k6F7e:
        DnGxn:
        goto kksay;
        nfZAf:
        $cwZhh = $this->P6k4O->path($N6LTi);
        goto MolrG;
        ksClB:
        a_fwC:
        goto lnsdl;
        cf5E_:
        if (!$n3Bd_->update(['driver' => FUIPeZ7ssitYw::S3, 'status' => QoCMzcKvH8Cw2::FINISHED])) {
            goto a_fwC;
        }
        goto nauYE;
        MolrG:
        $NSw82 = $this->bg_1H->call($this, $cwZhh);
        goto m2a61;
        WSQPv:
        if (!($N6LTi && $this->P6k4O->exists($N6LTi))) {
            goto DcjZ2;
        }
        goto nfZAf;
        a90Sq:
        $dkqps = $this->P6k4O->path($n3Bd_->getAttribute('preview'));
        goto Y3m1S;
        c1p3Q:
        Log::info("FNGNxcyxjaxBG has been deleted, discard it", ['fileId' => $IaHim]);
        goto tKUnS;
        l5g8y:
        $this->auR_S->put($n3Bd_->getAttribute('preview'), $troOF->stream(), ['visibility' => 'public', 'ContentType' => $troOF->mime(), 'ContentDisposition' => 'inline']);
        goto LxigU;
        pfaBE:
    }
}
