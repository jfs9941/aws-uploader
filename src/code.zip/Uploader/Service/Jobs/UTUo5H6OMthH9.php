<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class UTUo5H6OMthH9
{
    private $NKJRv;
    private $dpBF8;
    public function __construct(int $JghNh, int $TzpTS)
    {
        goto wo1KB;
        ORc5T:
        xNFNZ:
        goto sF0D7;
        sF0D7:
        $this->NKJRv = $JghNh;
        goto k9aqq;
        JFU2f:
        sPanE:
        goto VCSM4;
        k9aqq:
        $this->dpBF8 = $TzpTS;
        goto mfkZb;
        VCSM4:
        if (!($TzpTS <= 0)) {
            goto xNFNZ;
        }
        goto Y6aVu;
        Y6aVu:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto ORc5T;
        wo1KB:
        if (!($JghNh <= 0)) {
            goto sPanE;
        }
        goto EhsyY;
        EhsyY:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto JFU2f;
        mfkZb:
    }
    private static function mB2D6LciSBt($ti0V8, string $QUnh_ = 'floor') : int
    {
        goto aWcVH;
        Qfxmu:
        zRwTL:
        goto WpG9K;
        FTRPs:
        switch (strtolower($QUnh_)) {
            case 'ceil':
                return (int) (ceil($ti0V8 / 2) * 2);
            case 'round':
                return (int) (round($ti0V8 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($ti0V8 / 2) * 2);
        }
        goto Qfxmu;
        VuzrI:
        cZrgZ:
        goto XW0xA;
        ZBk0N:
        d40_U:
        goto FTRPs;
        WpG9K:
        vyq4P:
        goto ZuRMe;
        XW0xA:
        if (!(is_float($ti0V8) && $ti0V8 == floor($ti0V8) && (int) $ti0V8 % 2 === 0)) {
            goto d40_U;
        }
        goto phzVv;
        aWcVH:
        if (!(is_int($ti0V8) && $ti0V8 % 2 === 0)) {
            goto cZrgZ;
        }
        goto lxuHE;
        phzVv:
        return (int) $ti0V8;
        goto ZBk0N;
        lxuHE:
        return $ti0V8;
        goto VuzrI;
        ZuRMe:
    }
    public function mWLgWbYVD4e(string $cwF_A = 'floor') : array
    {
        goto BdhGK;
        jL3v9:
        NOqqy:
        goto SQhHK;
        RuvCP:
        $uqiW6 = $kuSTv;
        goto fHI9G;
        DW5N2:
        if (!($OUpB0 < 2)) {
            goto WWrzk;
        }
        goto zFf63;
        BdhGK:
        $kuSTv = 1080;
        goto h6GHr;
        ketvs:
        GPk3u:
        goto DW5N2;
        ASeKV:
        return ['width' => $uqiW6, 'height' => $OUpB0];
        goto x7nAk;
        c0OPy:
        $uqiW6 = 2;
        goto ketvs;
        UaWPu:
        if ($this->NKJRv >= $this->dpBF8) {
            goto NOqqy;
        }
        goto RuvCP;
        SQhHK:
        $OUpB0 = $kuSTv;
        goto UEl_m;
        zw9a_:
        WWrzk:
        goto ASeKV;
        zFf63:
        $OUpB0 = 2;
        goto zw9a_;
        UEl_m:
        $XvhoA = $OUpB0 / $this->dpBF8;
        goto GqfkA;
        EcXgW:
        $CwUHV = $this->dpBF8 * $XvhoA;
        goto SKJQA;
        vH_75:
        if (!($uqiW6 < 2)) {
            goto GPk3u;
        }
        goto c0OPy;
        NMhht:
        $OUpB0 = 0;
        goto UaWPu;
        SKJQA:
        $OUpB0 = self::mB2D6LciSBt(round($CwUHV), $cwF_A);
        goto muQ7E;
        GqfkA:
        $skCW5 = $this->NKJRv * $XvhoA;
        goto bmpQd;
        bmpQd:
        $uqiW6 = self::mB2D6LciSBt(round($skCW5), $cwF_A);
        goto WpoBd;
        h6GHr:
        $uqiW6 = 0;
        goto NMhht;
        fHI9G:
        $XvhoA = $uqiW6 / $this->NKJRv;
        goto EcXgW;
        WpoBd:
        WGWv0:
        goto vH_75;
        muQ7E:
        goto WGWv0;
        goto jL3v9;
        x7nAk:
    }
}
