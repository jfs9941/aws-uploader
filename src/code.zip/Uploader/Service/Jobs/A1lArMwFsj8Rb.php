<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Service\Jobs\ESxPlrkGkEa6Y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class A1lArMwFsj8Rb implements WatermarkTextJobInterface
{
    private $JG9IT;
    private $Uv8NV;
    private $wap61;
    private $huyLW;
    private $IaFSl;
    public function __construct($mLPCZ, $lldd6, $A3hvZ, $B27Pk, $TZR6i)
    {
        goto DhoCz;
        zfNRH:
        $this->huyLW = $A3hvZ;
        goto lYZuT;
        kSwPP:
        $this->Uv8NV = $lldd6;
        goto UiPcT;
        KSKNM:
        $this->wap61 = $TZR6i;
        goto kSwPP;
        DhoCz:
        $this->JG9IT = $mLPCZ;
        goto zfNRH;
        lYZuT:
        $this->IaFSl = $B27Pk;
        goto KSKNM;
        UiPcT:
    }
    public function putWatermark(string $arqvy, string $zGGen) : void
    {
        goto W7aSA;
        KbQLn:
        ini_set('memory_limit', '-1');
        goto McAyz;
        kaHz3:
        $NAxoU = memory_get_usage();
        goto nCZsj;
        W7aSA:
        $zi0zx = microtime(true);
        goto kaHz3;
        jnKrX:
        Log::info("Adding watermark text to image", ['imageId' => $arqvy]);
        goto KbQLn;
        nCZsj:
        $Eq74o = memory_get_peak_usage();
        goto jnKrX;
        McAyz:
        try {
            goto EUXky;
            KTu6o:
            Log::error("S7LEoIprYtLQw is not on local, might be deleted before put watermark", ['imageId' => $arqvy]);
            goto RL6Wa;
            uoRcT:
            unset($cl9Px);
            goto x2Dap;
            YVKVD:
            DmDQa:
            goto Qj4su;
            NEb64:
            i9pnF:
            goto cbLTk;
            K_K3P:
            $cl9Px = $this->JG9IT->call($this, $lxbX3);
            goto Ykftt;
            sT_L6:
            if ($this->IaFSl->exists($uuvVo->getLocation())) {
                goto DmDQa;
            }
            goto KTu6o;
            EUXky:
            $uuvVo = S7LEoIprYtLQw::findOrFail($arqvy);
            goto sT_L6;
            Qj4su:
            $lxbX3 = $this->IaFSl->path($uuvVo->getLocation());
            goto K_K3P;
            RL6Wa:
            return;
            goto YVKVD;
            mpdui:
            throw new \Exception('Failed to set final permissions on image file: ' . $lxbX3);
            goto NEb64;
            x2Dap:
            if (chmod($lxbX3, 0664)) {
                goto i9pnF;
            }
            goto o1UPn;
            am22O:
            $this->huyLW->put($lxbX3, $cl9Px->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto uoRcT;
            o1UPn:
            \Log::warning('Failed to set final permissions on image file: ' . $lxbX3);
            goto mpdui;
            Ykftt:
            $cl9Px->orient();
            goto A_dDe;
            A_dDe:
            $this->m1zlF97bvMI($cl9Px, $zGGen);
            goto am22O;
            cbLTk:
        } catch (\Throwable $f9ndW) {
            goto Gzy6H;
            eRkpn:
            Log::info("S7LEoIprYtLQw has been deleted, discard it", ['imageId' => $arqvy]);
            goto IjeQN;
            IjeQN:
            return;
            goto iZdc7;
            iZdc7:
            tCmfb:
            goto leljm;
            Gzy6H:
            if (!$f9ndW instanceof ModelNotFoundException) {
                goto tCmfb;
            }
            goto eRkpn;
            leljm:
            Log::error("S7LEoIprYtLQw is not readable", ['imageId' => $arqvy, 'error' => $f9ndW->getMessage()]);
            goto o8sRd;
            o8sRd:
        } finally {
            $qEn0v = microtime(true);
            $itTa2 = memory_get_usage();
            $qUJq5 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $arqvy, 'execution_time_sec' => $qEn0v - $zi0zx, 'memory_usage_mb' => ($itTa2 - $NAxoU) / 1024 / 1024, 'peak_memory_usage_mb' => ($qUJq5 - $Eq74o) / 1024 / 1024]);
        }
        goto mPfyf;
        mPfyf:
    }
    private function m1zlF97bvMI($cl9Px, $zGGen) : void
    {
        goto Cl_OL;
        W75EX:
        $pDpJ4 = $this->JG9IT->call($this, $this->IaFSl->path($qD_S5));
        goto oxuuY;
        NZne8:
        $SW277 = new ESxPlrkGkEa6Y($this->Uv8NV, $this->wap61, $this->huyLW, $this->IaFSl);
        goto LcrL6;
        G9ECJ:
        $sccRX = $cl9Px->height();
        goto NZne8;
        oxuuY:
        $cl9Px->place($pDpJ4, 'top-left', 0, 0, 30);
        goto x6230;
        R00Kq:
        $this->IaFSl->put($qD_S5, $this->huyLW->get($qD_S5));
        goto W75EX;
        LcrL6:
        $qD_S5 = $SW277->mUcOzHh2TqY($oy0ze, $sccRX, $zGGen, true);
        goto R00Kq;
        Cl_OL:
        $oy0ze = $cl9Px->width();
        goto G9ECJ;
        x6230:
    }
}
