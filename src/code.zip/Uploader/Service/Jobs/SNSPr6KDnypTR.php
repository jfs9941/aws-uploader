<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Illuminate\Support\Facades\Log;
class SNSPr6KDnypTR implements StoreVideoToS3JobInterface
{
    private $ohXaq;
    private $gErml;
    private $mzObC;
    public function __construct($YctT5, $DFpIk, $L1VX0)
    {
        goto Tlfr3;
        f9i3q:
        $this->mzObC = $L1VX0;
        goto B4z5a;
        Tlfr3:
        $this->gErml = $DFpIk;
        goto f9i3q;
        B4z5a:
        $this->ohXaq = $YctT5;
        goto y35zg;
        y35zg:
    }
    public function store(string $J_scC) : void
    {
        goto LlAxO;
        laOnD:
        $kmeWM = $L1VX0->mimeType($kjm4B->getLocation());
        goto yJ8NM;
        nFv2j:
        return;
        goto aUP3o;
        pjKsl:
        try {
            goto gRuW6;
            gRuW6:
            $vnyRY = $DPAi4->createMultipartUpload(['Bucket' => $this->ohXaq, 'Key' => $kjm4B->getLocation(), 'ContentType' => $kmeWM, 'ContentDisposition' => 'inline']);
            goto zxcUe;
            mxie2:
            HmuRR:
            goto MrT5L;
            FmNO4:
            $DPAi4->completeMultipartUpload(['Bucket' => $this->ohXaq, 'Key' => $kjm4B->getLocation(), 'UploadId' => $r_huy, 'MultipartUpload' => ['Parts' => $O39m9]]);
            goto ul2C1;
            KL1zH:
            goto HmuRR;
            goto QcImj;
            dYLkh:
            $O39m9 = [];
            goto mxie2;
            jMC3U:
            $Uxk1H++;
            goto KL1zH;
            w2Y6k:
            fclose($DC8CH);
            goto FmNO4;
            Xhj8d:
            $Uxk1H = 1;
            goto dYLkh;
            s2bux:
            $L1VX0->delete($kjm4B->getLocation());
            goto x9V1A;
            MrT5L:
            if (feof($DC8CH)) {
                goto yTbhl;
            }
            goto ngJJ_;
            zxcUe:
            $r_huy = $vnyRY['UploadId'];
            goto Xhj8d;
            QcImj:
            yTbhl:
            goto w2Y6k;
            ngJJ_:
            $e0Vi2 = $DPAi4->uploadPart(['Bucket' => $this->ohXaq, 'Key' => $kjm4B->getLocation(), 'UploadId' => $r_huy, 'PartNumber' => $Uxk1H, 'Body' => fread($DC8CH, $S1bFz)]);
            goto fMMuR;
            fMMuR:
            $O39m9[] = ['PartNumber' => $Uxk1H, 'ETag' => $e0Vi2['ETag']];
            goto jMC3U;
            ul2C1:
            $kjm4B->update(['driver' => DccywYjigTakI::S3, 'status' => EpMPhiTVzNYqA::FINISHED]);
            goto s2bux;
            x9V1A:
        } catch (AwsException $XViIf) {
            goto SsvBC;
            CkrMs:
            try {
                $DPAi4->abortMultipartUpload(['Bucket' => $this->ohXaq, 'Key' => $kjm4B->getLocation(), 'UploadId' => $r_huy]);
            } catch (AwsException $FBvAY) {
                Log::error('Error aborting multipart upload: ' . $FBvAY->getMessage());
            }
            goto K3Fir;
            vbiOt:
            Log::error('Failed to store video: ' . $kjm4B->getLocation() . ' - ' . $XViIf->getMessage());
            goto Gm12j;
            SsvBC:
            if (!isset($r_huy)) {
                goto Aarw5;
            }
            goto CkrMs;
            K3Fir:
            Aarw5:
            goto vbiOt;
            Gm12j:
        } finally {
            $m9Rrr = microtime(true);
            $mHCRu = memory_get_usage();
            $kZ1f0 = memory_get_peak_usage();
            Log::info('Store BG2FRpwGrKqJx to S3 function resource usage', ['imageId' => $J_scC, 'execution_time_sec' => $m9Rrr - $gAXA1, 'memory_usage_mb' => ($mHCRu - $bp0pf) / 1024 / 1024, 'peak_memory_usage_mb' => ($kZ1f0 - $c_Bev) / 1024 / 1024]);
        }
        goto fEJ6l;
        yJ8NM:
        $gAXA1 = microtime(true);
        goto xMNkw;
        F9PP3:
        $kjm4B = BG2FRpwGrKqJx::find($J_scC);
        goto BnKQk;
        aslKz:
        Log::error("[SNSPr6KDnypTR] File not found, discard it ", ['video' => $kjm4B->getLocation()]);
        goto nFv2j;
        eG_UO:
        $S1bFz = 1024 * 1024 * 50;
        goto laOnD;
        LlAxO:
        Log::info('Storing video (local) to S3', ['fileId' => $J_scC, 'bucketName' => $this->ohXaq]);
        goto RNjuK;
        X5xQf:
        bu3fp:
        goto yUEqz;
        E2AX0:
        return;
        goto X5xQf;
        xMNkw:
        $bp0pf = memory_get_usage();
        goto L7irZ;
        VlvKj:
        $L1VX0 = $this->mzObC;
        goto F9PP3;
        YlwWe:
        $DC8CH = $L1VX0->readStream($kjm4B->getLocation());
        goto eG_UO;
        LRgZT:
        Log::info("BG2FRpwGrKqJx has been deleted in database or not inserted yet, discard it", ['fileId' => $J_scC]);
        goto E2AX0;
        yUEqz:
        if ($L1VX0->exists($kjm4B->getLocation())) {
            goto lgjzU;
        }
        goto aslKz;
        BnKQk:
        if ($kjm4B) {
            goto bu3fp;
        }
        goto LRgZT;
        L7irZ:
        $c_Bev = memory_get_peak_usage();
        goto pjKsl;
        BZbSa:
        $DPAi4 = $this->gErml->getClient();
        goto VlvKj;
        RNjuK:
        ini_set('memory_limit', '-1');
        goto BZbSa;
        aUP3o:
        lgjzU:
        goto YlwWe;
        fEJ6l:
    }
}
