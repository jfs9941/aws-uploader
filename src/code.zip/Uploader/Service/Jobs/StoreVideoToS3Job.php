<?php

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileDriver;
use Jfs\Uploader\Enum\FileStatus;

class StoreVideoToS3Job implements StoreVideoToS3JobInterface
{

    private $bucketName;
    private $s3;
    private $localDisk;
    public function __construct($bucket, $s3, $localDisk)
    {
        $this->s3 = $s3;
        $this->localDisk = $localDisk;
        $this->bucketName = $bucket;
    }

    public function store(string $id): void
    {
        Log::info('Storing video (local) to S3', ['fileId' => $id, 'bucketName' => $this->bucketName]);
        ini_set('memory_limit', '-1');
        /** @var S3Client $s3Client */
        $s3Client = $this->s3->getClient();
        $localDisk = $this->localDisk;
        $videoModel = Video::find($id);
        if (!$videoModel) {
            Log::info("Video has been deleted, discard it", ['fileId' => $id]);
            return;
        }

        if (!$localDisk->exists($videoModel->getLocation())) {
            Log::error("[StoreVideoToS3Job] File not found, discard it " ,[
                'video' => $videoModel->getLocation()
            ]);
            return;
        }

        $fileStream = $localDisk->readStream($videoModel->getLocation());
        $chunkSize = 1024 * 1024 * 50; // 50MB chunk size
        $mimeType = $localDisk->mimeType($videoModel->getLocation());

        try {
            $result = $s3Client->createMultipartUpload([
                'Bucket' => $this->bucketName,
                'Key'    => $videoModel->getLocation(),
                'ContentType' => $mimeType,
                'ContentDisposition' => 'inline',
            ]);
            $uploadId = $result['UploadId'];

            $partNumber = 1;
            $parts = [];

            while (!feof($fileStream)) {
                $uploadPartResult = $s3Client->uploadPart([
                    'Bucket'     => $this->bucketName,
                    'Key'        => $videoModel->getLocation(),
                    'UploadId'   => $uploadId,
                    'PartNumber' => $partNumber,
                    'Body'       => fread($fileStream, $chunkSize), // Pass fread directly to Body
                ]);

                $parts[] = [
                    'PartNumber' => $partNumber,
                    'ETag'       => $uploadPartResult['ETag'],
                ];
                $partNumber++;
            }

            fclose($fileStream); // Close the stream after the loop

            $s3Client->completeMultipartUpload([
                'Bucket'          => $this->bucketName,
                'Key'             => $videoModel->getLocation(),
                'UploadId'        => $uploadId,
                'MultipartUpload' => [
                    'Parts' => $parts,
                ],
            ]);

            $videoModel->update(['driver' => FileDriver::S3, 'status' => FileStatus::FINISHED]);
            $localDisk->delete($videoModel->getLocation());
        } catch (AwsException $e) {
            // Abort the upload on error
            if (isset($uploadId)) {
                try {
                    $s3Client->abortMultipartUpload([
                        'Bucket'   => $this->bucketName,
                        'Key'      => $videoModel->getLocation(),
                        'UploadId' => $uploadId,
                    ]);
                } catch (AwsException $abortException) {
                    Log::error('Error aborting multipart upload: ' . $abortException->getMessage());
                }
            }
            Log::error('Failed to store video: ' . $videoModel->getLocation() . ' - ' . $e->getMessage());
        }
    }
}
