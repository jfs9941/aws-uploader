<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
class Ux87OpCnMRhyU implements BlurJobInterface
{
    const wSWQU = 15;
    const tKT9k = 500;
    const viX7F = 500;
    private $M9duE;
    private $f1xKj;
    private $SPj0U;
    public function __construct($U2Jsh, $C6boj, $KUQsT)
    {
        goto kqs96;
        M3WUN:
        $this->M9duE = $U2Jsh;
        goto FUOP0;
        gNf1x:
        $this->f1xKj = $C6boj;
        goto M3WUN;
        kqs96:
        $this->SPj0U = $KUQsT;
        goto gNf1x;
        FUOP0:
    }
    public function blur(string $g5e_r) : void
    {
        goto x2zXm;
        NtL1Z:
        $J6BhQ = $MSkzT->width() / $MSkzT->height();
        goto AOQ_o;
        LVT6q:
        $MSkzT = $this->M9duE->call($this, $this->SPj0U->path($VadxA->getLocation()));
        goto NtL1Z;
        Stngb:
        ini_set('memory_limit', '-1');
        goto JVeSC;
        upt42:
        $uM9Pr = $this->f1xKj->put($a1HS_, $MSkzT->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto TJawX;
        K4MOc:
        \Log::warning('Failed to set final permissions on image file: ' . $uM9Pr);
        goto aEvwy;
        y1KQJ:
        UTN64:
        goto LVT6q;
        AOQ_o:
        $MSkzT->resize(self::tKT9k, self::viX7F / $J6BhQ);
        goto F9i6k;
        OhvHc:
        $VadxA->update(['preview' => $a1HS_]);
        goto J2gms;
        CFn4x:
        $this->SPj0U->put($VadxA->filename, $HFHud);
        goto y1KQJ;
        x2zXm:
        $VadxA = XqAJHKYeaW2YU::findOrFail($g5e_r);
        goto Stngb;
        TJawX:
        unset($MSkzT);
        goto FqvsA;
        FqvsA:
        if (chmod($uM9Pr, 0664)) {
            goto bxMQx;
        }
        goto K4MOc;
        nZedS:
        bxMQx:
        goto OhvHc;
        JVeSC:
        if (!($VadxA->driver == Tq4KHV0o6oTIo::S3 && !$this->SPj0U->exists($VadxA->filename))) {
            goto UTN64;
        }
        goto bM3Wc;
        F9i6k:
        $MSkzT->blur(self::wSWQU);
        goto GabqF;
        GabqF:
        $a1HS_ = $this->meeZjeiY684($VadxA);
        goto upt42;
        aEvwy:
        throw new \Exception('Failed to set final permissions on image file: ' . $uM9Pr);
        goto nZedS;
        bM3Wc:
        $HFHud = $this->f1xKj->get($VadxA->filename);
        goto CFn4x;
        J2gms:
    }
    private function meeZjeiY684($wu1wA) : string
    {
        goto eLq8g;
        ph20l:
        $dHOYe = dirname($FlxOy) . '/preview/';
        goto dupHg;
        eLq8g:
        $FlxOy = $wu1wA->getLocation();
        goto ph20l;
        dWYTA:
        $this->SPj0U->makeDirectory($dHOYe, 0755, true);
        goto iJQzo;
        gUKLo:
        return $dHOYe . $wu1wA->getFilename() . '.jpg';
        goto FwMud;
        iJQzo:
        S_Zbr:
        goto gUKLo;
        dupHg:
        if ($this->SPj0U->exists($dHOYe)) {
            goto S_Zbr;
        }
        goto dWYTA;
        FwMud:
    }
}
