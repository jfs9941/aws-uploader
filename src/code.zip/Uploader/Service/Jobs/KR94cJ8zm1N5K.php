<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class KR94cJ8zm1N5K implements StoreToS3JobInterface
{
    private $VnheV;
    private $SxfKN;
    private $GmmTj;
    public function __construct($wUcGa, $DPWG1, $MYo5D)
    {
        goto BZZ2_;
        VpHNR:
        $this->GmmTj = $MYo5D;
        goto wY4Mc;
        BZZ2_:
        $this->SxfKN = $DPWG1;
        goto VpHNR;
        wY4Mc:
        $this->VnheV = $wUcGa;
        goto ktXTA;
        ktXTA:
    }
    public function store(string $GMwD5) : void
    {
        goto JnxAC;
        avinb:
        $gx7xw = $this->VnheV->call($this, $rA0h7);
        goto Nm2wN;
        Zobq4:
        ES9HG:
        goto T0hUt;
        y_VDy:
        rYOuA:
        goto H3qXO;
        T0hUt:
        $iTIh6 = $this->GmmTj->path($sg_2q->getLocation());
        goto fcqSi;
        DKdTJ:
        $r76n0 = $this->VnheV->call($this, $itPqF);
        goto EQCix;
        fcqSi:
        $this->mn7N8hrEEU4($iTIh6, $sg_2q->getLocation());
        goto oeqP7;
        aU3VG:
        if (!($ajABU && $this->GmmTj->exists($ajABU))) {
            goto VyNxV;
        }
        goto oJkZC;
        rBcBa:
        yC7PF:
        goto qFAMg;
        oJkZC:
        $rA0h7 = $this->GmmTj->path($ajABU);
        goto avinb;
        MaouY:
        C6ftQJKUZRJIp::where('parent_id', $GMwD5)->update(['driver' => CUySMhqlL7P49::S3, 'preview' => $sg_2q->getAttribute('preview'), 'thumbnail' => $sg_2q->getAttribute('thumbnail')]);
        goto dCX8l;
        oeqP7:
        $ajABU = $sg_2q->getAttribute('thumbnail');
        goto aU3VG;
        dCX8l:
        return;
        goto y_VDy;
        H3qXO:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $GMwD5]);
        goto Jr7r0;
        ylNoE:
        return;
        goto Zobq4;
        JnxAC:
        $sg_2q = C6ftQJKUZRJIp::findOrFail($GMwD5);
        goto hbXBB;
        csAqJ:
        if (!($sg_2q->getAttribute('preview') && $this->GmmTj->exists($sg_2q->getAttribute('preview')))) {
            goto yC7PF;
        }
        goto N6xIr;
        hbXBB:
        if ($sg_2q) {
            goto ES9HG;
        }
        goto W5qmd;
        qJ03Y:
        Log::info("C6ftQJKUZRJIp stored to S3, update the children attachments", ['fileId' => $GMwD5]);
        goto MaouY;
        Woy8J:
        VyNxV:
        goto csAqJ;
        N6xIr:
        $itPqF = $this->GmmTj->path($sg_2q->getAttribute('preview'));
        goto DKdTJ;
        EQCix:
        $this->SxfKN->put($sg_2q->getAttribute('preview'), $this->GmmTj->get($sg_2q->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $r76n0->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto rBcBa;
        W5qmd:
        Log::info("C6ftQJKUZRJIp has been deleted, discard it", ['fileId' => $GMwD5]);
        goto ylNoE;
        Nm2wN:
        $this->SxfKN->put($sg_2q->getAttribute('thumbnail'), $this->GmmTj->get($ajABU), ['visibility' => 'public', 'ContentType' => $gx7xw->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Woy8J;
        qFAMg:
        if (!$sg_2q->update(['driver' => CUySMhqlL7P49::S3, 'status' => Fsm7WCrUwVWh9::FINISHED])) {
            goto rYOuA;
        }
        goto qJ03Y;
        Jr7r0:
    }
    private function mn7N8hrEEU4($tKeHW, $rabIN, $MEDn0 = '')
    {
        goto ETkXD;
        ETkXD:
        if (!$MEDn0) {
            goto R9wWH;
        }
        goto oxzvo;
        uUMjv:
        $rabIN = str_replace('.jpg', $MEDn0, $rabIN);
        goto bMCAF;
        bFZ2u:
        try {
            $dmeuh = $this->VnheV->call($this, $tKeHW);
            $this->SxfKN->put($rabIN, $this->GmmTj->get($rabIN), ['visibility' => 'public', 'ContentType' => $dmeuh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $b6Bui) {
            Log::error("Failed to upload image to S3", ['s3Path' => $rabIN, 'error' => $b6Bui->getMessage()]);
        }
        goto sdn7U;
        oxzvo:
        $tKeHW = str_replace('.jpg', $MEDn0, $tKeHW);
        goto uUMjv;
        bMCAF:
        R9wWH:
        goto bFZ2u;
        sdn7U:
    }
}
