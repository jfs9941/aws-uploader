<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WKX0l52zWptlF;
class ONKKx7qfB4tWN implements WatermarkTextJobInterface
{
    private $K9RVo;
    private $m12Fs;
    private $s1Ojb;
    private $qrvF0;
    private $fodJQ;
    public function __construct($Venjl, $a3Ry3, $eG_Pc, $nsgrL, $qt9YU)
    {
        goto TdXzc;
        NEXNH:
        $this->s1Ojb = $qt9YU;
        goto Er0L4;
        TdXzc:
        $this->K9RVo = $Venjl;
        goto U3BVm;
        Er0L4:
        $this->m12Fs = $a3Ry3;
        goto Txueh;
        U3BVm:
        $this->qrvF0 = $eG_Pc;
        goto N32ty;
        N32ty:
        $this->fodJQ = $nsgrL;
        goto NEXNH;
        Txueh:
    }
    public function putWatermark(string $ElvKF, string $MjBIh) : void
    {
        goto jDtFK;
        jBbiN:
        try {
            goto M8zK6;
            oRrq8:
            $v6lLU->destroy();
            goto Hz__G;
            uC_pY:
            WfFI2:
            goto NH8dG;
            XgcGi:
            $v6lLU->save($lmCO9);
            goto oRrq8;
            c3Ky3:
            $this->mjvJHjqGCGM($v6lLU, $MjBIh);
            goto XgcGi;
            P2Op5:
            $v6lLU->orientate();
            goto c3Ky3;
            r1Zyb:
            Fj3V5:
            goto Qs5tu;
            AsyZd:
            throw new \Exception('Failed to set final permissions on image file: ' . $lmCO9);
            goto uC_pY;
            CabEL:
            $v6lLU = $this->K9RVo->call($this, $lmCO9);
            goto P2Op5;
            ZFeuz:
            return;
            goto r1Zyb;
            kxQUC:
            \Log::warning('Failed to set final permissions on image file: ' . $lmCO9);
            goto AsyZd;
            bpZ64:
            Log::error("WKX0l52zWptlF is not on local, might be deleted before put watermark", ['imageId' => $ElvKF]);
            goto ZFeuz;
            Hz__G:
            if (chmod($lmCO9, 0664)) {
                goto WfFI2;
            }
            goto kxQUC;
            UC3cY:
            if ($this->fodJQ->exists($anrPh->getLocation())) {
                goto Fj3V5;
            }
            goto bpZ64;
            Qs5tu:
            $lmCO9 = $this->fodJQ->path($anrPh->getLocation());
            goto CabEL;
            M8zK6:
            $anrPh = WKX0l52zWptlF::findOrFail($ElvKF);
            goto UC3cY;
            NH8dG:
        } catch (\Throwable $Tx0LJ) {
            goto Ug9fU;
            ZCND6:
            Log::error("WKX0l52zWptlF is not readable", ['imageId' => $ElvKF, 'error' => $Tx0LJ->getMessage()]);
            goto XA7ys;
            b7E1m:
            Log::info("WKX0l52zWptlF has been deleted, discard it", ['imageId' => $ElvKF]);
            goto eO3AB;
            Ug9fU:
            if (!$Tx0LJ instanceof ModelNotFoundException) {
                goto S58u0;
            }
            goto b7E1m;
            eO3AB:
            return;
            goto I2vno;
            I2vno:
            S58u0:
            goto ZCND6;
            XA7ys:
        }
        goto PY0Hv;
        jDtFK:
        Log::info("Adding watermark text to image", ['imageId' => $ElvKF]);
        goto O4NT1;
        O4NT1:
        ini_set('memory_limit', '-1');
        goto jBbiN;
        PY0Hv:
    }
    private function mjvJHjqGCGM($v6lLU, $MjBIh) : void
    {
        goto wg4Ju;
        XCBFr:
        $zZl79 = $v6lLU->height();
        goto iYpN7;
        EO8TY:
        $v6lLU->insert($KdJhh);
        goto aZkc9;
        NCN5g:
        $zgO1j = $hKkXZ->m3R2wWWZe8v($g5xFk, $zZl79, $MjBIh, true);
        goto O30UK;
        UMm2a:
        $KdJhh->opacity(35);
        goto EO8TY;
        O30UK:
        $this->fodJQ->put($zgO1j, $this->qrvF0->get($zgO1j));
        goto rywxh;
        wg4Ju:
        $g5xFk = $v6lLU->width();
        goto XCBFr;
        iYpN7:
        $hKkXZ = new VWi8iyX8y8IKN($this->m12Fs, $this->s1Ojb, $this->qrvF0, $this->fodJQ);
        goto NCN5g;
        rywxh:
        $KdJhh = $this->K9RVo->call($this, $this->fodJQ->path($zgO1j));
        goto UMm2a;
        aZkc9:
    }
}
