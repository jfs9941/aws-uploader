<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Illuminate\Support\Facades\Log;
class VpU71S2wn5iXi implements StoreVideoToS3JobInterface
{
    private $XB1Jn;
    private $hFxUe;
    private $Celh5;
    public function __construct($Ba5m3, $KKbEP, $clScT)
    {
        goto LaR3E;
        LaR3E:
        $this->hFxUe = $KKbEP;
        goto vSJ5X;
        DcGOH:
        $this->XB1Jn = $Ba5m3;
        goto CCpbS;
        vSJ5X:
        $this->Celh5 = $clScT;
        goto DcGOH;
        CCpbS:
    }
    public function store(string $SEOXv) : void
    {
        goto UOtoL;
        gsMwj:
        return;
        goto xKGW5;
        ki82C:
        Log::error("[VpU71S2wn5iXi] File not found, discard it ", ['video' => $hFIkt->getLocation()]);
        goto gsphj;
        gsphj:
        return;
        goto b39C6;
        mwxoN:
        try {
            goto KAELA;
            XK14i:
            $tNwGR = $fNMAX['UploadId'];
            goto pM24T;
            mi4Qy:
            $vLWpB = $CBoNT->uploadPart(['Bucket' => $this->XB1Jn, 'Key' => $hFIkt->getLocation(), 'UploadId' => $tNwGR, 'PartNumber' => $Kpbos, 'Body' => fread($T6aHm, $PXFo7)]);
            goto uGTmj;
            ZS0Ai:
            ivI1H:
            goto CjOwr;
            CjOwr:
            fclose($T6aHm);
            goto aLdux;
            fa49C:
            $clScT->delete($hFIkt->getLocation());
            goto NMmpQ;
            aLdux:
            $CBoNT->completeMultipartUpload(['Bucket' => $this->XB1Jn, 'Key' => $hFIkt->getLocation(), 'UploadId' => $tNwGR, 'MultipartUpload' => ['Parts' => $p4mmG]]);
            goto Wcvty;
            WUPeR:
            $Kpbos++;
            goto IdlUt;
            KAELA:
            $fNMAX = $CBoNT->createMultipartUpload(['Bucket' => $this->XB1Jn, 'Key' => $hFIkt->getLocation(), 'ContentType' => $c2R7J, 'ContentDisposition' => 'inline']);
            goto XK14i;
            KzEkd:
            if (feof($T6aHm)) {
                goto ivI1H;
            }
            goto mi4Qy;
            VJu0H:
            IksG8:
            goto KzEkd;
            eS1i7:
            $p4mmG = [];
            goto VJu0H;
            IdlUt:
            goto IksG8;
            goto ZS0Ai;
            Wcvty:
            $hFIkt->update(['driver' => Rf7fPQasmK9R3::S3, 'status' => QE1dzvgcPWV6R::FINISHED]);
            goto fa49C;
            pM24T:
            $Kpbos = 1;
            goto eS1i7;
            uGTmj:
            $p4mmG[] = ['PartNumber' => $Kpbos, 'ETag' => $vLWpB['ETag']];
            goto WUPeR;
            NMmpQ:
        } catch (AwsException $HhXZM) {
            goto hPjy5;
            FyyHP:
            try {
                $CBoNT->abortMultipartUpload(['Bucket' => $this->XB1Jn, 'Key' => $hFIkt->getLocation(), 'UploadId' => $tNwGR]);
            } catch (AwsException $dKXCP) {
                Log::error('Error aborting multipart upload: ' . $dKXCP->getMessage());
            }
            goto RJd65;
            RJd65:
            UnZ_R:
            goto CF7Q8;
            hPjy5:
            if (!isset($tNwGR)) {
                goto UnZ_R;
            }
            goto FyyHP;
            CF7Q8:
            Log::error('Failed to store video: ' . $hFIkt->getLocation() . ' - ' . $HhXZM->getMessage());
            goto AY5V0;
            AY5V0:
        } finally {
            $vmfo7 = microtime(true);
            $icHkX = memory_get_usage();
            $W9dV9 = memory_get_peak_usage();
            Log::info('Store IvT3V5jT5KEaA to S3 function resource usage', ['imageId' => $SEOXv, 'execution_time_sec' => $vmfo7 - $NR4hg, 'memory_usage_mb' => ($icHkX - $BuLko) / 1024 / 1024, 'peak_memory_usage_mb' => ($W9dV9 - $DAezb) / 1024 / 1024]);
        }
        goto LOQ_5;
        tGhVG:
        $DAezb = memory_get_peak_usage();
        goto mwxoN;
        Q_QrT:
        $c2R7J = $clScT->mimeType($hFIkt->getLocation());
        goto jACQF;
        UOtoL:
        Log::info('Storing video (local) to S3', ['fileId' => $SEOXv, 'bucketName' => $this->XB1Jn]);
        goto owY1o;
        k2O8Z:
        Log::info("IvT3V5jT5KEaA has been deleted in database or not inserted yet, discard it", ['fileId' => $SEOXv]);
        goto gsMwj;
        ML2hN:
        $hFIkt = IvT3V5jT5KEaA::find($SEOXv);
        goto imezM;
        imezM:
        if ($hFIkt) {
            goto J1de0;
        }
        goto k2O8Z;
        ZPd2b:
        $PXFo7 = 1024 * 1024 * 50;
        goto Q_QrT;
        jACQF:
        $NR4hg = microtime(true);
        goto Okh8f;
        gSH0R:
        $T6aHm = $clScT->readStream($hFIkt->getLocation());
        goto ZPd2b;
        Okh8f:
        $BuLko = memory_get_usage();
        goto tGhVG;
        b39C6:
        xJlz2:
        goto gSH0R;
        lTelq:
        $CBoNT = $this->hFxUe->getClient();
        goto Pt0p_;
        xKGW5:
        J1de0:
        goto K3NLj;
        Pt0p_:
        $clScT = $this->Celh5;
        goto ML2hN;
        K3NLj:
        if ($clScT->exists($hFIkt->getLocation())) {
            goto xJlz2;
        }
        goto ki82C;
        owY1o:
        ini_set('memory_limit', '-1');
        goto lTelq;
        LOQ_5:
    }
}
