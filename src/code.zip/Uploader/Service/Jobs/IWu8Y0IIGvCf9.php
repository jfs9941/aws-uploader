<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Encoder\SVNBjJbQZ9C1j;
use Jfs\Uploader\Encoder\KtUFCQtsmKPfb;
use Jfs\Uploader\Encoder\NLoWoIWKwVnRR;
use Jfs\Uploader\Encoder\AvkpdQ5uphWyl;
use Jfs\Uploader\Encoder\WAdrIkdjR1FAW;
use Jfs\Uploader\Encoder\VNBPBDslqfoC3;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Jfs\Uploader\Service\Jobs\VAS3IS3j3Ue1l;
use Jfs\Uploader\Service\Jobs\QOFRXBlpPvkox;
use Jfs\Uploader\Service\ETNYJFyUYZrNI;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class IWu8Y0IIGvCf9 implements MediaEncodeJobInterface
{
    private $QNBCN;
    private $W9e5K;
    private $zbU8n;
    private $bJ64t;
    private $DV6_0;
    public function __construct(string $APN4u, $XCkIj, $Efy84, $f_vTf, $dRs7q)
    {
        goto NT3d5;
        J_qR7:
        $this->W9e5K = $XCkIj;
        goto JzcWC;
        m7S14:
        $this->DV6_0 = $dRs7q;
        goto d6z6c;
        JzcWC:
        $this->zbU8n = $Efy84;
        goto Bze2s;
        NT3d5:
        $this->QNBCN = $APN4u;
        goto J_qR7;
        Bze2s:
        $this->bJ64t = $f_vTf;
        goto m7S14;
        d6z6c:
    }
    public function encode(string $N2oAf, string $QBYnF, $D8hZE = true) : void
    {
        goto leA1Y;
        Khx43:
        try {
            goto A3n2A;
            A3n2A:
            $fTkob = VPegVN4NByLqJ::findOrFail($N2oAf);
            goto ZWIix;
            AnF7y:
            $Kch1R = $this->mKYdGXvWtEV($fTkob);
            goto ZWJYq;
            q5j4w:
            Log::info("Set 1080p resolution for Job", ['width' => $eS6k5['width'], 'height' => $eS6k5['height'], 'originalWidth' => $lvh9C, 'originalHeight' => $S3Wk9]);
            goto eqt18;
            uvFen:
            if (!$BKWoY) {
                goto AdVn6;
            }
            goto wWgE3;
            uV2IH:
            AdVn6:
            goto Ks94_;
            ZWJYq:
            Log::info("Set input video for Job", ['s3Uri' => $Kch1R]);
            goto oqGhN;
            yb1C_:
            if (!($fTkob->Sc6J1 !== I5kpK7wkbRQvu::S3)) {
                goto KQH6m;
            }
            goto D95ih;
            F6yln:
            if (!$BKWoY) {
                goto wn_0Z;
            }
            goto REEvE;
            wWgE3:
            $KnT1s = $KnT1s->maegZV38SvF($BKWoY);
            goto uV2IH;
            zYdKM:
            $S3Wk9 = $fTkob->height();
            goto AnF7y;
            rxpzt:
            $eS6k5 = $this->mrBoP2yrBN1($lvh9C, $S3Wk9);
            goto q5j4w;
            EWmH0:
            $rRtwf = $rRtwf->mLgTQyNnUyy($oEyCz);
            goto S3IWf;
            yIBPF:
            if (!$this->mnrI2JDZcgT($lvh9C, $S3Wk9)) {
                goto vlF5w;
            }
            goto rxpzt;
            tH68O:
            $oEyCz = new SVNBjJbQZ9C1j($fTkob->SW27F ?? 1, 2, $qiLE2->mpe80m0Mib0($fTkob));
            goto EWmH0;
            S3IWf:
            $N2oAf = $rRtwf->mBPpf33FZWZ($this->mTG7UTFSPlk($fTkob, $D8hZE));
            goto YYrZk;
            YYrZk:
            $fTkob->update(['aws_media_converter_job_id' => $N2oAf]);
            goto WT7W0;
            mAz9M:
            $rRtwf->m7VtwRWwmJO($qiLE2->minDTpyVKdX($fTkob));
            goto D1AG1;
            ko6Ld:
            $rRtwf->m7VtwRWwmJO($qiLE2->minDTpyVKdX($fTkob));
            goto elLFP;
            oqGhN:
            $rRtwf = app(WAdrIkdjR1FAW::class);
            goto HcjPx;
            elLFP:
            if (!($lvh9C && $S3Wk9)) {
                goto ExMTr;
            }
            goto yIBPF;
            Srnsg:
            $rRtwf = $rRtwf->m4Xng9Ow39k($yJ6kZ);
            goto E0aS3;
            WuLuA:
            wn_0Z:
            goto Srnsg;
            REEvE:
            $yJ6kZ = $yJ6kZ->maegZV38SvF($BKWoY);
            goto WuLuA;
            copmN:
            $BKWoY = $this->mYpcn29TK4V($aPiO3, $bBvox->mp5Q2fe7Fqv($fTkob->width(), $fTkob->height(), $QBYnF));
            goto uvFen;
            vwrjn:
            $bBvox = new QOFRXBlpPvkox($this->bJ64t, $this->DV6_0, $this->zbU8n, $this->W9e5K);
            goto copmN;
            BS7Ie:
            ExMTr:
            goto agdB7;
            E0aS3:
            vlF5w:
            goto BS7Ie;
            sTCgG:
            $KnT1s = new KtUFCQtsmKPfb('original', $lvh9C, $S3Wk9, $fTkob->MLMuB ?? 30);
            goto UPwQa;
            eqt18:
            $yJ6kZ = new KtUFCQtsmKPfb('1080p', $eS6k5['width'], $eS6k5['height'], $fTkob->MLMuB ?? 30);
            goto eS1f4;
            mNfAh:
            $rRtwf->m4Xng9Ow39k($KnT1s);
            goto mAz9M;
            UPwQa:
            $qiLE2 = app(NLoWoIWKwVnRR::class);
            goto mNfAh;
            KLuu6:
            KQH6m:
            goto lx8Bq;
            D95ih:
            throw new MediaConverterException("VPegVN4NByLqJ {$fTkob->id} is not S3 driver");
            goto KLuu6;
            eS1f4:
            $BKWoY = $this->mYpcn29TK4V($aPiO3, $bBvox->mp5Q2fe7Fqv((int) $eS6k5['width'], (int) $eS6k5['height'], $QBYnF));
            goto F6yln;
            ZWIix:
            Assert::isInstanceOf($fTkob, VPegVN4NByLqJ::class);
            goto yb1C_;
            Ks94_:
            $rRtwf->m4Xng9Ow39k($KnT1s);
            goto ko6Ld;
            HcjPx:
            $rRtwf = $rRtwf->mw5YUt1R8sO(new AvkpdQ5uphWyl($Kch1R));
            goto sTCgG;
            D1AG1:
            $aPiO3 = app(ETNYJFyUYZrNI::class);
            goto vwrjn;
            agdB7:
            Log::info("Set thumbnail for VPegVN4NByLqJ Job", ['videoId' => $fTkob->getAttribute('id'), 'duration' => $fTkob->getAttribute('duration')]);
            goto tH68O;
            lx8Bq:
            $lvh9C = $fTkob->width();
            goto zYdKM;
            WT7W0:
        } catch (\Exception $oKDQw) {
            Log::info("VPegVN4NByLqJ has been deleted, discard it", ['fileId' => $N2oAf, 'err' => $oKDQw->getMessage()]);
            return;
        }
        goto XJcWP;
        leA1Y:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $N2oAf]);
        goto sYnby;
        sYnby:
        ini_set('memory_limit', '-1');
        goto Khx43;
        XJcWP:
    }
    private function mTG7UTFSPlk(VPegVN4NByLqJ $fTkob, $D8hZE) : bool
    {
        goto ZUOf2;
        qOwX0:
        S38IH:
        goto DVfrn;
        uz1Rl:
        NnEaB:
        goto SBDbs;
        q0_7X:
        CxU3D:
        goto uz1Rl;
        IrVFb:
        switch (true) {
            case $fTkob->width() * $fTkob->height() >= 1920 * 1080 && $fTkob->width() * $fTkob->height() < 2560 * 1440:
                return $LrWOl > 10 * 60;
            case $fTkob->width() * $fTkob->height() >= 2560 * 1440 && $fTkob->width() * $fTkob->height() < 3840 * 2160:
                return $LrWOl > 5 * 60;
            case $fTkob->width() * $fTkob->height() >= 3840 * 2160:
                return $LrWOl > 3 * 60;
            default:
                return false;
        }
        goto q0_7X;
        DVfrn:
        $LrWOl = (int) round($fTkob->getAttribute('duration') ?? 0);
        goto IrVFb;
        ZUOf2:
        if ($D8hZE) {
            goto S38IH;
        }
        goto OgYnH;
        OgYnH:
        return false;
        goto qOwX0;
        SBDbs:
    }
    private function mYpcn29TK4V(ETNYJFyUYZrNI $aPiO3, string $RfsQZ) : ?VNBPBDslqfoC3
    {
        goto pW4JG;
        jRbL8:
        Z0vGl:
        goto ezfB0;
        ezfB0:
        return null;
        goto bqYdI;
        EOIl0:
        if (!$S2LlB) {
            goto Z0vGl;
        }
        goto YBx_u;
        YBx_u:
        return new VNBPBDslqfoC3($S2LlB, 0, 0, null, null);
        goto jRbL8;
        CkvBR:
        Log::info("Resolve watermark for job with url", ['url' => $RfsQZ, 'uri' => $S2LlB]);
        goto EOIl0;
        pW4JG:
        $S2LlB = $aPiO3->mbQN4XBftAz($RfsQZ);
        goto CkvBR;
        bqYdI:
    }
    private function mnrI2JDZcgT(int $lvh9C, int $S3Wk9) : bool
    {
        return $lvh9C * $S3Wk9 > 1.5 * (1920 * 1080);
    }
    private function mrBoP2yrBN1(int $lvh9C, int $S3Wk9) : array
    {
        $vu5_r = new VAS3IS3j3Ue1l($lvh9C, $S3Wk9);
        return $vu5_r->mkTTqwPM1yd();
    }
    private function mKYdGXvWtEV(MIyg7KY6jn9L1 $IcEa3) : string
    {
        goto f_Cor;
        f_Cor:
        if (!($IcEa3->Sc6J1 == I5kpK7wkbRQvu::S3)) {
            goto eJzEa;
        }
        goto xsdXu;
        la_ev:
        return $this->W9e5K->url($IcEa3->filename);
        goto f1mz5;
        q3dPL:
        eJzEa:
        goto la_ev;
        xsdXu:
        return 's3://' . $this->QNBCN . '/' . $IcEa3->filename;
        goto q3dPL;
        f1mz5:
    }
}
