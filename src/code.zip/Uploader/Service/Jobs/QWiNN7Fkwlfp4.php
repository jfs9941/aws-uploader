<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class QWiNN7Fkwlfp4 implements CompressJobInterface
{
    const mplEX = 60;
    private $G25L6;
    private $QbAvB;
    private $hik1u;
    public function __construct($G6zg7, $UNh9U, $d7hWY)
    {
        goto tvf4h;
        hcP5v:
        $this->hik1u = $d7hWY;
        goto QtqLU;
        QtqLU:
        $this->QbAvB = $UNh9U;
        goto ZtDId;
        tvf4h:
        $this->G25L6 = $G6zg7;
        goto hcP5v;
        ZtDId:
    }
    public function compress(string $GhyxD)
    {
        goto fcp2D;
        ynsJd:
        Log::info("Compress image", ['imageId' => $GhyxD]);
        goto HXq0g;
        HXq0g:
        try {
            goto pIhiW;
            twp1U:
            if (!(strtolower($oaIJp->getExtension()) === 'png' || strtolower($oaIJp->getExtension()) === 'heic')) {
                goto im12O;
            }
            goto L5bFv;
            L5bFv:
            $oaIJp = $this->ma2tBVKDgFI($oaIJp, 'jpg');
            goto qgtsx;
            h4Q0P:
            try {
                goto TR444;
                IX6VQ:
                $this->muy8tVLqYkq($q_yXW, $fP8uj);
                goto ZUeM7;
                TR444:
                $fP8uj = $this->QbAvB->path(str_replace('.jpg', '.webp', $oaIJp->getLocation()));
                goto IX6VQ;
                ZUeM7:
                $this->ma2tBVKDgFI($oaIJp, 'webp');
                goto Mjp9_;
                Mjp9_:
            } catch (\Exception $w7Va8) {
                goto kX_G1;
                kX_G1:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $GhyxD, 'error' => $w7Va8->getMessage()]);
                goto InPZ0;
                xFPuq:
                $this->mMMeEoqS6FJ($q_yXW, $fP8uj);
                goto qn02y;
                InPZ0:
                $fP8uj = $this->QbAvB->path($oaIJp->getLocation());
                goto xFPuq;
                qn02y:
            }
            goto BQDfs;
            pIhiW:
            $oaIJp = IZ5shp3JHuftD::findOrFail($GhyxD);
            goto PW7hC;
            PW7hC:
            $q_yXW = $this->QbAvB->path($oaIJp->getLocation());
            goto twp1U;
            qgtsx:
            im12O:
            goto h4Q0P;
            BQDfs:
        } catch (\Throwable $w7Va8) {
            goto a9x0Q;
            a9x0Q:
            if (!$w7Va8 instanceof ModelNotFoundException) {
                goto VCMlm;
            }
            goto WypFR;
            Owjfc:
            Log::error("Failed to compress image", ['imageId' => $GhyxD, 'error' => $w7Va8->getMessage()]);
            goto p4JmX;
            WypFR:
            Log::info("IZ5shp3JHuftD has been deleted, discard it", ['imageId' => $GhyxD]);
            goto XPJZ7;
            OeQ0_:
            VCMlm:
            goto Owjfc;
            XPJZ7:
            return;
            goto OeQ0_;
            p4JmX:
        } finally {
            $SBKSV = microtime(true);
            $YOCUN = memory_get_usage();
            $Pkr75 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $GhyxD, 'execution_time_sec' => $SBKSV - $FmdyL, 'memory_usage_mb' => ($YOCUN - $Iifsd) / 1024 / 1024, 'peak_memory_usage_mb' => ($Pkr75 - $T8Pp2) / 1024 / 1024]);
        }
        goto IPT9c;
        zfv4I:
        $Iifsd = memory_get_usage();
        goto P_ek7;
        P_ek7:
        $T8Pp2 = memory_get_peak_usage();
        goto ynsJd;
        fcp2D:
        $FmdyL = microtime(true);
        goto zfv4I;
        IPT9c:
    }
    private function mMMeEoqS6FJ($q_yXW, $fP8uj)
    {
        goto Fq_4S;
        zb9P3:
        $this->hik1u->put($fP8uj, $GaG7q->toJpeg(self::mplEX), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto XlY13;
        Fq_4S:
        $GaG7q = $this->G25L6->call($this, $q_yXW);
        goto xj6Pl;
        XlY13:
        unset($GaG7q);
        goto UfLQY;
        xj6Pl:
        $GaG7q->orient()->toJpeg(self::mplEX)->save($fP8uj);
        goto zb9P3;
        UfLQY:
    }
    private function muy8tVLqYkq($q_yXW, $fP8uj)
    {
        goto TzMQg;
        IPowq:
        $GaG7q->orient()->toWebp(self::mplEX);
        goto nhczj;
        nhczj:
        $this->hik1u->put($fP8uj, $GaG7q->toJpeg(self::mplEX), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto me_Nx;
        me_Nx:
        unset($GaG7q);
        goto PZq_J;
        TzMQg:
        $GaG7q = $this->G25L6->call($this, $q_yXW);
        goto IPowq;
        PZq_J:
    }
    private function ma2tBVKDgFI($oaIJp, $N6gja)
    {
        goto kIcau;
        kIcau:
        $oaIJp->setAttribute('type', $N6gja);
        goto AprPo;
        dGCcx:
        $oaIJp->save();
        goto zHbcg;
        AprPo:
        $oaIJp->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$N6gja}", $oaIJp->getLocation()));
        goto dGCcx;
        zHbcg:
        return $oaIJp;
        goto bJwzi;
        bJwzi:
    }
}
