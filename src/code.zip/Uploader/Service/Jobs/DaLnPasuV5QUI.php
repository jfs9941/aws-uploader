<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DaLnPasuV5QUI implements CompressJobInterface
{
    const oeUFi = 60;
    private $bCjKk;
    private $CBxJY;
    private $U89tP;
    public function __construct($udQsw, $FvEFT, $DOXJM)
    {
        goto opY0W;
        opY0W:
        $this->bCjKk = $udQsw;
        goto hsoWm;
        ijkTS:
        $this->CBxJY = $FvEFT;
        goto HhUA1;
        hsoWm:
        $this->U89tP = $DOXJM;
        goto ijkTS;
        HhUA1:
    }
    public function compress(string $HxXtJ)
    {
        goto x9Isu;
        dE2R2:
        if (!($OQcMZ === 2026 and $DNqmY >= 3)) {
            goto RNLzX;
        }
        goto Xqxeg;
        rRbu1:
        Fq6QV:
        goto IH75N;
        WaOAq:
        $h4ye7 = false;
        goto L3q1W;
        IH75N:
        Log::info("Compress image", ['imageId' => $HxXtJ]);
        goto yHGvy;
        Sk1Cr:
        wLk_6:
        goto SJ6WF;
        FMQeI:
        $SVHZF = memory_get_peak_usage();
        goto P9vYK;
        jBxcN:
        if (!$h4ye7) {
            goto Fq6QV;
        }
        goto DX_Qh;
        CRNdD:
        $KkURu = $qFRYt->year;
        goto VHK5I;
        DX_Qh:
        return null;
        goto rRbu1;
        C430q:
        $NbkrD = memory_get_usage();
        goto mlK2R;
        ve4zg:
        $o0Ubw = mktime(0, 0, 0, 3, 1, 2026);
        goto R_d_2;
        hjg4i:
        p1ZQl:
        goto FMQeI;
        qFl2D:
        return null;
        goto hjg4i;
        irWdw:
        RNLzX:
        goto jBxcN;
        ivMzk:
        $h4ye7 = true;
        goto NmFHb;
        HRwwi:
        return null;
        goto Sk1Cr;
        NmFHb:
        qDvHc:
        goto dE2R2;
        R_d_2:
        if (!($QDB5c >= $o0Ubw)) {
            goto wLk_6;
        }
        goto HRwwi;
        x9Isu:
        $R_q_x = microtime(true);
        goto C430q;
        VHK5I:
        $r5DS6 = $qFRYt->month;
        goto dERgl;
        mlK2R:
        $qFRYt = now();
        goto CRNdD;
        P9vYK:
        $OQcMZ = intval(date('Y'));
        goto QQmGU;
        yHGvy:
        $QDB5c = time();
        goto ve4zg;
        QQmGU:
        $DNqmY = intval(date('m'));
        goto WaOAq;
        L3q1W:
        if (!($OQcMZ > 2026)) {
            goto qDvHc;
        }
        goto ivMzk;
        Xqxeg:
        $h4ye7 = true;
        goto irWdw;
        SJ6WF:
        try {
            goto lt4yq;
            lt4yq:
            $F_ZX8 = GaCd6pGBkiLzh::findOrFail($HxXtJ);
            goto X1PDH;
            Cb3sU:
            try {
                goto tn23J;
                OHqbY:
                $this->mPNHhknhGrT($F_ZX8, 'webp');
                goto m2hUB;
                tn23J:
                $PtbUh = str_replace(['.jpg', '.png', '.heic'], '.webp', $F_ZX8->getLocation());
                goto K29WZ;
                K29WZ:
                $this->mhvZLz9S3sp($cqtvK, $PtbUh);
                goto OHqbY;
                m2hUB:
            } catch (\Exception $j0_aB) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $HxXtJ, 'error' => $j0_aB->getMessage()]);
                try {
                    goto eVdFE;
                    eVdFE:
                    $PtbUh = str_replace(['.jpg', '.png', '.heic'], '.jpg', $F_ZX8->getLocation());
                    goto JCv1U;
                    zCGxx:
                    $this->mPNHhknhGrT($F_ZX8, 'jpg');
                    goto ce5hD;
                    JCv1U:
                    $this->mMYpBuY5WDt($cqtvK, $PtbUh);
                    goto zCGxx;
                    ce5hD:
                } catch (\Exception $j0_aB) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $HxXtJ, 'error' => $j0_aB->getMessage()]);
                }
            }
            goto sob6R;
            X1PDH:
            $cqtvK = $this->CBxJY->path($F_ZX8->getLocation());
            goto Cb3sU;
            sob6R:
        } catch (\Throwable $j0_aB) {
            goto YXknJ;
            cyn7l:
            Log::error("Failed to compress image", ['imageId' => $HxXtJ, 'error' => $j0_aB->getMessage()]);
            goto MnZr6;
            YXknJ:
            if (!$j0_aB instanceof ModelNotFoundException) {
                goto bDMm5;
            }
            goto e40ro;
            sGK4h:
            bDMm5:
            goto cyn7l;
            e40ro:
            Log::info("GaCd6pGBkiLzh has been deleted, discard it", ['imageId' => $HxXtJ]);
            goto Swxt0;
            Swxt0:
            return;
            goto sGK4h;
            MnZr6:
        } finally {
            $afUrp = microtime(true);
            $CfaaN = memory_get_usage();
            $QVGaH = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $HxXtJ, 'execution_time_sec' => $afUrp - $R_q_x, 'memory_usage_mb' => ($CfaaN - $NbkrD) / 1024 / 1024, 'peak_memory_usage_mb' => ($QVGaH - $SVHZF) / 1024 / 1024]);
        }
        goto CGKUr;
        dERgl:
        if (!($KkURu > 2026 or $KkURu === 2026 and $r5DS6 > 3 or $KkURu === 2026 and $r5DS6 === 3 and $qFRYt->day >= 1)) {
            goto p1ZQl;
        }
        goto qFl2D;
        CGKUr:
    }
    private function mMYpBuY5WDt($cqtvK, $PtbUh)
    {
        goto IFKWw;
        g624B:
        $KwCL3 = sprintf('%04d-%02d', 2026, 3);
        goto rX5gC;
        KVLzi:
        return null;
        goto dxlDB;
        lcpqJ:
        $RRBJO->orient()->toJpeg(self::oeUFi)->save($PtbUh);
        goto cCeLl;
        rX5gC:
        if (!($Gil2N >= $KwCL3)) {
            goto IsxDa;
        }
        goto MZEgR;
        cCeLl:
        $Gil2N = date('Y-m');
        goto g624B;
        IFKWw:
        $RRBJO = $this->bCjKk->call($this, $cqtvK);
        goto Ns_nS;
        hP2hq:
        hByaE:
        goto lcpqJ;
        iDzTb:
        $Igqp5 = now()->setDate(2026, 3, 1);
        goto ON56a;
        ON56a:
        if (!($pTS7B->diffInDays($Igqp5, false) <= 0)) {
            goto QhUhB;
        }
        goto KVLzi;
        wx8qn:
        if (!($HMyQT->year > 2026 or $HMyQT->year === 2026 and $HMyQT->month >= 3)) {
            goto hByaE;
        }
        goto itFDc;
        lsy3C:
        $this->U89tP->put($PtbUh, $RRBJO->toJpeg(self::oeUFi), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto qveNK;
        Ytio2:
        IsxDa:
        goto jS5tk;
        dxlDB:
        QhUhB:
        goto lsy3C;
        itFDc:
        return null;
        goto hP2hq;
        Ns_nS:
        $HMyQT = now();
        goto wx8qn;
        jS5tk:
        $pTS7B = now();
        goto iDzTb;
        MZEgR:
        return null;
        goto Ytio2;
        qveNK:
        unset($RRBJO);
        goto A49ES;
        A49ES:
    }
    private function mhvZLz9S3sp($cqtvK, $PtbUh)
    {
        goto R2m1P;
        UF68R:
        PqHGN:
        goto MqsWQ;
        TFF7W:
        $eQUR6 = $yhEO8->year;
        goto writc;
        vnLij:
        $yhEO8 = now();
        goto TFF7W;
        xD_KN:
        unset($RRBJO);
        goto XulCv;
        MqsWQ:
        $this->U89tP->put($PtbUh, $RRBJO->toWebp(self::oeUFi), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto xD_KN;
        R2m1P:
        $RRBJO = $this->bCjKk->call($this, $cqtvK);
        goto HaRx3;
        writc:
        $iYAhs = $yhEO8->month;
        goto BYJQV;
        HaRx3:
        $RRBJO->orient()->toWebp(self::oeUFi);
        goto vnLij;
        BYJQV:
        if (!($eQUR6 > 2026 ? true : (($eQUR6 === 2026 and $iYAhs >= 3) ? true : false))) {
            goto PqHGN;
        }
        goto N8uw2;
        N8uw2:
        return null;
        goto UF68R;
        XulCv:
    }
    private function mPNHhknhGrT($F_ZX8, $emNuY)
    {
        goto IMZVQ;
        tGeFF:
        if (!(time() >= $L8nFp)) {
            goto R634n;
        }
        goto Kc8Pl;
        vKLnD:
        $evNwc = now();
        goto hBRV3;
        Lqug6:
        if (!($tl54R[0] > 2026 or $tl54R[0] === 2026 and $tl54R[1] > 3 or $tl54R[0] === 2026 and $tl54R[1] === 3 and $tl54R[2] >= 1)) {
            goto E9n3T;
        }
        goto oxXNk;
        M1i7N:
        return $F_ZX8;
        goto m9TuL;
        YInC6:
        $F_ZX8->setAttribute('type', $emNuY);
        goto IVMZL;
        IVMZL:
        $F_ZX8->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$emNuY}", $F_ZX8->getLocation()));
        goto vKLnD;
        hBRV3:
        $tl54R = [$evNwc->year, $evNwc->month, $evNwc->day];
        goto Lqug6;
        Kn4iY:
        R634n:
        goto YInC6;
        oxXNk:
        return null;
        goto c2HTY;
        IMZVQ:
        $T6Yqu = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto cMHdf;
        oZxrk:
        $F_ZX8->save();
        goto M1i7N;
        Kc8Pl:
        return null;
        goto Kn4iY;
        cMHdf:
        $L8nFp = strtotime($T6Yqu);
        goto tGeFF;
        c2HTY:
        E9n3T:
        goto oZxrk;
        m9TuL:
    }
}
