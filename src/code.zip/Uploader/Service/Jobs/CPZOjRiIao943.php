<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class CPZOjRiIao943
{
    private $NzdTN;
    private $h6c5V;
    private $GQuun;
    private $OKvrN;
    public function __construct($DvaDk, $RogsX, $Q0shJ, $GiTtn)
    {
        goto p7Wfq;
        tfeyG:
        $this->OKvrN = $GiTtn;
        goto sgREv;
        sgREv:
        $this->NzdTN = $DvaDk;
        goto PNhos;
        iEccV:
        $this->GQuun = $Q0shJ;
        goto tfeyG;
        p7Wfq:
        $this->h6c5V = $RogsX;
        goto iEccV;
        PNhos:
    }
    public function mUbg5R9jG4v(?int $vwL5B, ?int $ttadT, string $hkNHZ, bool $j3Lgw = false) : string
    {
        goto US1a3;
        iuXDl:
        return $j3Lgw ? $Y7TgX : $this->GQuun->url($Y7TgX);
        goto c7ha3;
        TtMsn:
        $wttur = 0.1;
        goto uZLqB;
        U8cUc:
        $mfEjo -= $tJe3l;
        goto XrlcJ;
        XrlcJ:
        if (!($vwL5B > 1500)) {
            goto lYUbL;
        }
        goto C7C6E;
        d9kQ1:
        $CPHMS = $this->NzdTN->call($this, $vwL5B, $ttadT);
        goto QDiWy;
        j5gI4:
        throw new \RuntimeException("S25BfMDKrX8cB dimensions are not available.");
        goto caz7x;
        MZVAm:
        lYUbL:
        goto PvHR2;
        r23In:
        $CPHMS->text($YalG4, $mfEjo, (int) $drvYM, function ($WqHxk) use($D4Kvg) {
            goto fKjvV;
            X47s3:
            $WqHxk->valign('middle');
            goto oH_zL;
            HVXih:
            $WqHxk->color([185, 185, 185, 1]);
            goto X47s3;
            CV25C:
            $WqHxk->size(max($mb2E4, 1));
            goto HVXih;
            oH_zL:
            $WqHxk->align('middle');
            goto BKp6_;
            ZoyZ_:
            $mb2E4 = (int) ($D4Kvg * 1.2);
            goto CV25C;
            fKjvV:
            $WqHxk->file(Hs9sI($this->h6c5V));
            goto ZoyZ_;
            BKp6_:
        });
        goto LtEZK;
        US1a3:
        if (!($vwL5B === null || $ttadT === null)) {
            goto wQt3f;
        }
        goto j5gI4;
        caz7x:
        wQt3f:
        goto TtMsn;
        LtEZK:
        $this->OKvrN->put($Y7TgX, $CPHMS->stream('png'));
        goto jP4rY;
        OqRlK:
        $tJe3l = (int) ($mfEjo / 80);
        goto U8cUc;
        uZLqB:
        list($D4Kvg, $fpBiL, $YalG4) = $this->mD9iNKXDCNS($hkNHZ, $vwL5B, $wttur, (float) $vwL5B / $ttadT);
        goto ImxxZ;
        ImxxZ:
        $Y7TgX = $this->mQA0cxULZ7I($YalG4, $vwL5B, $ttadT, $fpBiL, $D4Kvg);
        goto kVNLk;
        jP4rY:
        $this->GQuun->put($Y7TgX, $CPHMS->stream('png'));
        goto iuXDl;
        QDiWy:
        $mfEjo = $vwL5B - $fpBiL;
        goto OqRlK;
        u2QVs:
        b80b0:
        goto d9kQ1;
        PvHR2:
        $drvYM = $ttadT - $D4Kvg - 10;
        goto r23In;
        C7C6E:
        $mfEjo -= $tJe3l * 0.4;
        goto MZVAm;
        AsLoT:
        return $j3Lgw ? $Y7TgX : $this->GQuun->url($Y7TgX);
        goto u2QVs;
        kVNLk:
        if (!$this->GQuun->exists($Y7TgX)) {
            goto b80b0;
        }
        goto AsLoT;
        c7ha3:
    }
    private function mQA0cxULZ7I(string $hkNHZ, int $vwL5B, int $ttadT, int $ubOGu, int $pHJlI) : string
    {
        $y2s5Q = ltrim($hkNHZ, '@');
        return "v2/watermark/{$y2s5Q}/{$vwL5B}x{$ttadT}_{$ubOGu}x{$pHJlI}/text_watermark.png";
    }
    private function mD9iNKXDCNS($hkNHZ, int $vwL5B, float $s9tJO, float $RgaZf) : array
    {
        goto IVqnp;
        k151g:
        $Yx7yj = $fpBiL / (strlen($YalG4) * 0.8);
        goto JUiGp;
        cUhVw:
        $fpBiL = (int) ($vwL5B * $s9tJO);
        goto gSER6;
        oCG5z:
        return [(int) $Yx7yj, $fpBiL, $YalG4];
        goto XpZgd;
        gSER6:
        if (!($RgaZf > 1)) {
            goto bHo3E;
        }
        goto k151g;
        DHZCE:
        $Yx7yj = 1 / $RgaZf * $fpBiL / strlen($YalG4);
        goto oCG5z;
        OeHV8:
        bHo3E:
        goto DHZCE;
        IVqnp:
        $YalG4 = '@' . $hkNHZ;
        goto cUhVw;
        JUiGp:
        return [(int) $Yx7yj, $Yx7yj * strlen($YalG4) / 1.8, $YalG4];
        goto OeHV8;
        XpZgd:
    }
}
