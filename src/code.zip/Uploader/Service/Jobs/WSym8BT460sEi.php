<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
class WSym8BT460sEi implements BlurJobInterface
{
    const Fzp39 = 15;
    const VxG1F = 500;
    const RT7FO = 500;
    private $ABFqP;
    private $QxLu3;
    private $aW0a3;
    public function __construct($xLMar, $bjIIR, $eEhuZ)
    {
        goto JYQVU;
        JYQVU:
        $this->aW0a3 = $eEhuZ;
        goto MPxks;
        bTE4B:
        $this->ABFqP = $xLMar;
        goto vMPeG;
        MPxks:
        $this->QxLu3 = $bjIIR;
        goto bTE4B;
        vMPeG:
    }
    public function blur(string $qMhfW) : void
    {
        goto qWQBI;
        EzlVk:
        throw new \Exception('Failed to set final permissions on image file: ' . $p76Rw);
        goto T5ARZ;
        lLxL6:
        $T4AWF->blur(self::Fzp39);
        goto NW_w4;
        hL2ZK:
        $p76Rw = $this->QxLu3->put($tbsXX, $T4AWF->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Pa95y;
        ZSo41:
        $T4AWF->resize(self::VxG1F, self::RT7FO / $TlV7f);
        goto lLxL6;
        T5ARZ:
        fDLw4:
        goto GPvaz;
        Pa95y:
        unset($T4AWF);
        goto pCGgq;
        JaIky:
        ini_set('memory_limit', '-1');
        goto L5psL;
        Lw1OI:
        $eOUes = $this->QxLu3->get($ij6Dh->filename);
        goto kwY27;
        TKsrs:
        BkV7q:
        goto T3Fhc;
        T3Fhc:
        $T4AWF = $this->ABFqP->call($this, $this->aW0a3->path($ij6Dh->getLocation()));
        goto oBD6h;
        GPvaz:
        $ij6Dh->update(['preview' => $tbsXX]);
        goto FZTyb;
        p3hiZ:
        \Log::warning('Failed to set final permissions on image file: ' . $p76Rw);
        goto EzlVk;
        oBD6h:
        $TlV7f = $T4AWF->width() / $T4AWF->height();
        goto ZSo41;
        kwY27:
        $this->aW0a3->put($ij6Dh->filename, $eOUes);
        goto TKsrs;
        pCGgq:
        if (chmod($p76Rw, 0664)) {
            goto fDLw4;
        }
        goto p3hiZ;
        NW_w4:
        $tbsXX = $this->muOZqmZNOzL($ij6Dh);
        goto hL2ZK;
        qWQBI:
        $ij6Dh = WUuz09CA4woAL::findOrFail($qMhfW);
        goto JaIky;
        L5psL:
        if (!($ij6Dh->pb8PJ == YOaiWCgFM7tRK::S3 && !$this->aW0a3->exists($ij6Dh->filename))) {
            goto BkV7q;
        }
        goto Lw1OI;
        FZTyb:
    }
    private function muOZqmZNOzL($VGjvC) : string
    {
        goto fRsS4;
        NyHEI:
        if ($this->aW0a3->exists($kaImN)) {
            goto H2CqP;
        }
        goto MaU8h;
        TMFAM:
        H2CqP:
        goto iN8Ra;
        sOe9t:
        $kaImN = dirname($b0LKC) . '/preview/';
        goto NyHEI;
        fRsS4:
        $b0LKC = $VGjvC->getLocation();
        goto sOe9t;
        MaU8h:
        $this->aW0a3->makeDirectory($kaImN, 0755, true);
        goto TMFAM;
        iN8Ra:
        return $kaImN . $VGjvC->getFilename() . '.jpg';
        goto isENq;
        isENq:
    }
}
