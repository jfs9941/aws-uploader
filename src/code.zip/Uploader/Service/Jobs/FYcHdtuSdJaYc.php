<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class FYcHdtuSdJaYc implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $N2oAf) : void
    {
        goto DGNA2;
        i2lOZ:
        Wh3d6:
        goto hR1HS;
        DGNA2:
        $fTkob = VPegVN4NByLqJ::findOrFail($N2oAf);
        goto juLqC;
        oCcR1:
        $this->m5zWqdF0A4K($fTkob);
        goto i2lOZ;
        juLqC:
        if ($fTkob->width() > 0 && $fTkob->height() > 0) {
            goto Wh3d6;
        }
        goto oCcR1;
        hR1HS:
    }
    private function m5zWqdF0A4K(VPegVN4NByLqJ $dYGNV) : void
    {
        goto mOeOa;
        kx7Ur:
        $FXWKt = $XZ7FM->getDimensions();
        goto S36T_;
        S36T_:
        $dYGNV->update(['duration' => $aB0a5->getDurationInSeconds(), 'resolution' => $FXWKt->getWidth() . 'x' . $FXWKt->getHeight(), 'fps' => $XZ7FM->get('r_frame_rate') ?? 30]);
        goto oLe9G;
        h47Ts:
        $XZ7FM = $aB0a5->getVideoStream();
        goto kx7Ur;
        woKaa:
        $aB0a5 = FFMpeg::fromDisk($KqiYb['path'])->open($dYGNV->getAttribute('filename'));
        goto h47Ts;
        mOeOa:
        $KqiYb = $dYGNV->getView();
        goto woKaa;
        oLe9G:
    }
}
