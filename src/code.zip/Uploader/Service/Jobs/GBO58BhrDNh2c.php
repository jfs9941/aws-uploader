<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class GBO58BhrDNh2c implements StoreToS3JobInterface
{
    private $buleS;
    private $UoQI7;
    private $pCaD7;
    public function __construct($nFvaK, $UjVft, $P3zvl)
    {
        goto sv0rw;
        ogPMZ:
        $this->pCaD7 = $P3zvl;
        goto ELrf8;
        ELrf8:
        $this->buleS = $nFvaK;
        goto ozcqH;
        sv0rw:
        $this->UoQI7 = $UjVft;
        goto ogPMZ;
        ozcqH:
    }
    public function store(string $InHEz) : void
    {
        goto tnrht;
        XKGcw:
        N0j2z:
        goto LG_PA;
        ERn8Z:
        $this->ms4LNhlaRcN($hKqqZ, $Oyqlq->getLocation());
        goto WcoPc;
        qYwsA:
        Log::info("UKkbXBDRxjSUY has been deleted, discard it", ['fileId' => $InHEz]);
        goto EkkR6;
        w77j9:
        $this->UoQI7->put($Oyqlq->getAttribute('thumbnail'), $this->pCaD7->get($s5Mcb), ['visibility' => 'public', 'ContentType' => $NnQOx->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto tWiV4;
        Vv5Wo:
        if ($Oyqlq) {
            goto TGbAX;
        }
        goto qYwsA;
        j_7rp:
        $NnQOx = $this->buleS->call($this, $Kx5MS);
        goto w77j9;
        EkkR6:
        return;
        goto ExVZH;
        FLXWv:
        $Aj9Of = $this->pCaD7->path($Oyqlq->getAttribute('preview'));
        goto PUKIf;
        wU2B3:
        Log::info("UKkbXBDRxjSUY stored to S3, update the children attachments", ['fileId' => $InHEz]);
        goto f0Cyx;
        Z4JsI:
        return;
        goto XKGcw;
        tnrht:
        $Oyqlq = UKkbXBDRxjSUY::findOrFail($InHEz);
        goto Vv5Wo;
        ETbLj:
        GXb8q:
        goto vDYWC;
        jHuOd:
        if (!($Oyqlq->getAttribute('preview') && $this->pCaD7->exists($Oyqlq->getAttribute('preview')))) {
            goto GXb8q;
        }
        goto FLXWv;
        PUKIf:
        $DZ_MJ = $this->buleS->call($this, $Aj9Of);
        goto qSxTB;
        ADaer:
        $Kx5MS = $this->pCaD7->path($s5Mcb);
        goto j_7rp;
        vDYWC:
        if (!$Oyqlq->update(['driver' => YJGCddWUf6Zu2::S3, 'status' => ZP6Ky842t6y9Y::FINISHED])) {
            goto N0j2z;
        }
        goto wU2B3;
        AX3K4:
        if (!($s5Mcb && $this->pCaD7->exists($s5Mcb))) {
            goto vLamd;
        }
        goto ADaer;
        ut74E:
        $hKqqZ = $this->pCaD7->path($Oyqlq->getLocation());
        goto ERn8Z;
        ExVZH:
        TGbAX:
        goto ut74E;
        qSxTB:
        $this->UoQI7->put($Oyqlq->getAttribute('preview'), $this->pCaD7->get($Oyqlq->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $DZ_MJ->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto ETbLj;
        WcoPc:
        $s5Mcb = $Oyqlq->getAttribute('thumbnail');
        goto AX3K4;
        f0Cyx:
        UKkbXBDRxjSUY::where('parent_id', $InHEz)->update(['driver' => YJGCddWUf6Zu2::S3, 'preview' => $Oyqlq->getAttribute('preview'), 'thumbnail' => $Oyqlq->getAttribute('thumbnail')]);
        goto Z4JsI;
        LG_PA:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $InHEz]);
        goto oedjZ;
        tWiV4:
        vLamd:
        goto jHuOd;
        oedjZ:
    }
    private function ms4LNhlaRcN($swacH, $zaAAK, $LWqUl = '')
    {
        goto lVX9U;
        vJbmL:
        try {
            $VGttq = $this->buleS->call($this, $swacH);
            $this->UoQI7->put($zaAAK, $this->pCaD7->get($zaAAK), ['visibility' => 'public', 'ContentType' => $VGttq->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $bAo2Y) {
            Log::error("Failed to upload image to S3", ['s3Path' => $zaAAK, 'error' => $bAo2Y->getMessage()]);
        }
        goto s974U;
        lVX9U:
        if (!$LWqUl) {
            goto Nz_Hz;
        }
        goto NdEHk;
        NdEHk:
        $swacH = str_replace('.jpg', $LWqUl, $swacH);
        goto ZUAim;
        LwYIA:
        Nz_Hz:
        goto vJbmL;
        ZUAim:
        $zaAAK = str_replace('.jpg', $LWqUl, $zaAAK);
        goto LwYIA;
        s974U:
    }
}
