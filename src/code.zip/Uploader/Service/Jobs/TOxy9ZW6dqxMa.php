<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class TOxy9ZW6dqxMa
{
    private $aAdxh;
    private $Ge2u8;
    private $cC_4U;
    private $Ybatl;
    public function __construct($V402Y, $oWXJW, $s1UdZ, $FHlTP)
    {
        goto Whemt;
        DmCJq:
        $this->aAdxh = $V402Y;
        goto YhJ9m;
        Dv5nr:
        $this->cC_4U = $s1UdZ;
        goto cBUbW;
        Whemt:
        $this->Ge2u8 = $oWXJW;
        goto Dv5nr;
        cBUbW:
        $this->Ybatl = $FHlTP;
        goto DmCJq;
        YhJ9m:
    }
    public function mg1ITv6ydbE(?int $wtcqu, ?int $snhLP, string $lqmQe, bool $s05OR = false) : string
    {
        goto YJuKE;
        jLkra:
        $PdjKE->text($nzAph, $nXELD, (int) $BdA2A, function ($GlKIM) use($AZbmH) {
            goto pdSYU;
            pL_ZI:
            $gusdK = (int) ($AZbmH * 1.2);
            goto NGkD0;
            sfPBi:
            $GlKIM->align('middle');
            goto WJZr2;
            H5Ba6:
            $GlKIM->color([185, 185, 185, 1]);
            goto NtOY9;
            pdSYU:
            $GlKIM->file(public_path($this->Ge2u8));
            goto pL_ZI;
            NGkD0:
            $GlKIM->size(max($gusdK, 1));
            goto H5Ba6;
            NtOY9:
            $GlKIM->valign('middle');
            goto sfPBi;
            WJZr2:
        });
        goto HKjhJ;
        CekEt:
        return $s05OR ? $K_YMm : $this->cC_4U->url($K_YMm);
        goto BIYSW;
        yyZG9:
        $this->cC_4U->put($K_YMm, $PdjKE->stream('png'));
        goto CekEt;
        CYm74:
        throw new \RuntimeException("O1jfuwJR340k5 dimensions are not available.");
        goto V0GLg;
        LtvfG:
        $nXELD -= $s9RQJ;
        goto PMGa7;
        V0GLg:
        AEOxk:
        goto eLuaY;
        ybG7S:
        $K_YMm = $this->mInNqtmHQ7x($nzAph, $wtcqu, $snhLP, $Spskn, $AZbmH);
        goto t_Ani;
        t_Ani:
        if (!$this->cC_4U->exists($K_YMm)) {
            goto ZROXk;
        }
        goto DRE_j;
        DRE_j:
        return $s05OR ? $K_YMm : $this->cC_4U->url($K_YMm);
        goto E6tR6;
        lWNmU:
        $s9RQJ = (int) ($nXELD / 80);
        goto LtvfG;
        PMGa7:
        if (!($wtcqu > 1500)) {
            goto dT18q;
        }
        goto BOZmF;
        YJuKE:
        if (!($wtcqu === null || $snhLP === null)) {
            goto AEOxk;
        }
        goto CYm74;
        wSGvi:
        dT18q:
        goto j2j6h;
        HKjhJ:
        $this->Ybatl->put($K_YMm, $PdjKE->stream('png'));
        goto yyZG9;
        jZ6Zl:
        list($AZbmH, $Spskn, $nzAph) = $this->mz5NovrRwfh($lqmQe, $wtcqu, $UHZzf, (float) $wtcqu / $snhLP);
        goto ybG7S;
        j2j6h:
        $BdA2A = $snhLP - $AZbmH - 10;
        goto jLkra;
        eLuaY:
        $UHZzf = 0.1;
        goto jZ6Zl;
        o17O2:
        $PdjKE = $this->aAdxh->call($this, $wtcqu, $snhLP);
        goto IUFAI;
        E6tR6:
        ZROXk:
        goto o17O2;
        IUFAI:
        $nXELD = $wtcqu - $Spskn;
        goto lWNmU;
        BOZmF:
        $nXELD -= $s9RQJ * 0.4;
        goto wSGvi;
        BIYSW:
    }
    private function mInNqtmHQ7x(string $lqmQe, int $wtcqu, int $snhLP, int $WulN5, int $te5aq) : string
    {
        $Z13Xm = ltrim($lqmQe, '@');
        return "v2/watermark/{$Z13Xm}/{$wtcqu}x{$snhLP}_{$WulN5}x{$te5aq}/text_watermark.png";
    }
    private function mz5NovrRwfh($lqmQe, int $wtcqu, float $Thj8S, float $NTbDZ) : array
    {
        goto hR0Ta;
        jkZFw:
        $Ybxp_ = $Spskn / (strlen($nzAph) * 0.8);
        goto FkcJj;
        VpxgZ:
        nKLL4:
        goto LN23j;
        tIU10:
        $Spskn = (int) ($wtcqu * $Thj8S);
        goto c2gjW;
        hpHsR:
        return [(int) $Ybxp_, $Spskn, $nzAph];
        goto U5_xk;
        FkcJj:
        return [(int) $Ybxp_, $Ybxp_ * strlen($nzAph) / 1.8, $nzAph];
        goto VpxgZ;
        LN23j:
        $Ybxp_ = 1 / $NTbDZ * $Spskn / strlen($nzAph);
        goto hpHsR;
        hR0Ta:
        $nzAph = '@' . $lqmQe;
        goto tIU10;
        c2gjW:
        if (!($NTbDZ > 1)) {
            goto nKLL4;
        }
        goto jkZFw;
        U5_xk:
    }
}
