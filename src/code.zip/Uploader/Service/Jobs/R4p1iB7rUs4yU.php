<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class R4p1iB7rUs4yU implements CompressJobInterface
{
    const MR_QX = 60;
    private $ABFqP;
    private $aW0a3;
    private $S2ABC;
    public function __construct($xLMar, $eEhuZ, $MO7Ok)
    {
        goto sJGW_;
        rdxw0:
        $this->aW0a3 = $eEhuZ;
        goto vkvJT;
        o5GcA:
        $this->S2ABC = $MO7Ok;
        goto rdxw0;
        sJGW_:
        $this->ABFqP = $xLMar;
        goto o5GcA;
        vkvJT:
    }
    public function compress(string $qMhfW)
    {
        goto tpeUP;
        tpeUP:
        $u4XNo = microtime(true);
        goto XkGhT;
        XkGhT:
        $E9dxY = memory_get_usage();
        goto OgCnF;
        YI9lp:
        Log::info("Compress image", ['imageId' => $qMhfW]);
        goto nipgx;
        OgCnF:
        $nrXNy = memory_get_peak_usage();
        goto YI9lp;
        nipgx:
        try {
            goto Prtiv;
            RNRQ6:
            $p9pjT = $this->aW0a3->path($T4AWF->getLocation());
            goto nP7WR;
            Prtiv:
            $T4AWF = WUuz09CA4woAL::findOrFail($qMhfW);
            goto RNRQ6;
            tC8U4:
            y670b:
            goto wbLsr;
            nP7WR:
            if (!(strtolower($T4AWF->getExtension()) === 'png' || strtolower($T4AWF->getExtension()) === 'heic')) {
                goto y670b;
            }
            goto etHNr;
            etHNr:
            $T4AWF = $this->mzRk6d4Q8EE($T4AWF, 'jpg');
            goto tC8U4;
            wbLsr:
            try {
                goto x43W6;
                o1VFG:
                $this->mVenocnoyve($p9pjT, $sUVO4);
                goto hRNJv;
                hRNJv:
                $this->mzRk6d4Q8EE($T4AWF, 'webp');
                goto SUmxf;
                x43W6:
                $sUVO4 = $this->aW0a3->path(str_replace('.jpg', '.webp', $T4AWF->getLocation()));
                goto o1VFG;
                SUmxf:
            } catch (\Exception $X3u3n) {
                goto rOwtm;
                kq47r:
                $this->mzUpNVmVOu3($p9pjT, $sUVO4);
                goto JBVMS;
                zsqDr:
                $sUVO4 = $this->aW0a3->path($T4AWF->getLocation());
                goto kq47r;
                rOwtm:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $qMhfW, 'error' => $X3u3n->getMessage()]);
                goto zsqDr;
                JBVMS:
            }
            goto N137I;
            N137I:
        } catch (\Throwable $X3u3n) {
            goto G5Jbb;
            LWmJ1:
            r9iDa:
            goto dlH7i;
            J3B52:
            Log::info("WUuz09CA4woAL has been deleted, discard it", ['imageId' => $qMhfW]);
            goto uuB73;
            dlH7i:
            Log::error("Failed to compress image", ['imageId' => $qMhfW, 'error' => $X3u3n->getMessage()]);
            goto bhkG1;
            uuB73:
            return;
            goto LWmJ1;
            G5Jbb:
            if (!$X3u3n instanceof ModelNotFoundException) {
                goto r9iDa;
            }
            goto J3B52;
            bhkG1:
        } finally {
            $dFOsw = microtime(true);
            $IfrVA = memory_get_usage();
            $O6V3s = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $qMhfW, 'execution_time_sec' => $dFOsw - $u4XNo, 'memory_usage_mb' => ($IfrVA - $E9dxY) / 1024 / 1024, 'peak_memory_usage_mb' => ($O6V3s - $nrXNy) / 1024 / 1024]);
        }
        goto WXptR;
        WXptR:
    }
    private function mzUpNVmVOu3($p9pjT, $sUVO4)
    {
        goto aBo_l;
        ILdx2:
        unset($v_wWH);
        goto WuLJk;
        y4XcT:
        $v_wWH->orient()->toJpeg(self::MR_QX)->save($sUVO4);
        goto xi8vI;
        xi8vI:
        $this->S2ABC->put($sUVO4, $v_wWH->toJpeg(self::MR_QX), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto ILdx2;
        aBo_l:
        $v_wWH = $this->ABFqP->call($this, $p9pjT);
        goto y4XcT;
        WuLJk:
    }
    private function mVenocnoyve($p9pjT, $sUVO4)
    {
        goto TQbII;
        fS7Nw:
        unset($v_wWH);
        goto q4xgP;
        TQbII:
        $v_wWH = $this->ABFqP->call($this, $p9pjT);
        goto U0hsC;
        U0hsC:
        $v_wWH->orient()->toWebp(self::MR_QX);
        goto gfWH1;
        gfWH1:
        $this->S2ABC->put($sUVO4, $v_wWH->toJpeg(self::MR_QX), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto fS7Nw;
        q4xgP:
    }
    private function mzRk6d4Q8EE($T4AWF, $G5Hlr)
    {
        goto iEobq;
        YjPNm:
        $T4AWF->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$G5Hlr}", $T4AWF->getLocation()));
        goto RuLxU;
        RuLxU:
        $T4AWF->save();
        goto Gc5u6;
        Gc5u6:
        return $T4AWF;
        goto Moecr;
        iEobq:
        $T4AWF->setAttribute('type', $G5Hlr);
        goto YjPNm;
        Moecr:
    }
}
