<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Illuminate\Support\Facades\Log;
class EYY79LmU9qCZ5 implements DownloadToLocalJobInterface
{
    private $zbU8n;
    private $ofZvx;
    public function __construct($Efy84, $suNmN)
    {
        $this->zbU8n = $Efy84;
        $this->ofZvx = $suNmN;
    }
    public function download(string $N2oAf) : void
    {
        goto HCRBo;
        xrM2b:
        if (!$this->ofZvx->exists($k2MU3->getLocation())) {
            goto Nbf_L;
        }
        goto E5xRC;
        EjQ1X:
        Nbf_L:
        goto o4MJ3;
        o4MJ3:
        $this->ofZvx->put($k2MU3->getLocation(), $this->zbU8n->get($k2MU3->getLocation()));
        goto b8EUp;
        HCRBo:
        $k2MU3 = JMa7GBaLcnq3D::findOrFail($N2oAf);
        goto i0oRn;
        i0oRn:
        Log::info("Start download file to local", ['fileId' => $N2oAf, 'filename' => $k2MU3->getLocation()]);
        goto xrM2b;
        E5xRC:
        return;
        goto EjQ1X;
        b8EUp:
    }
}
