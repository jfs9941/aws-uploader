<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use backup\Exposed\Jobs\O8CX6EuYCei1T;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use Illuminate\Support\Facades\Log;
class Am402HUeF85Yj implements O8CX6EuYCei1T
{
    private $FhVsE;
    private $kEfMA;
    private $c35HU;
    public function __construct($ClLup, $FP6ih, $VHhUy)
    {
        goto txQG7;
        zWSDn:
        $this->c35HU = $VHhUy;
        goto Jubsa;
        Jubsa:
        $this->FhVsE = $ClLup;
        goto j1bph;
        txQG7:
        $this->kEfMA = $FP6ih;
        goto zWSDn;
        j1bph:
    }
    public function store(string $EQQae) : void
    {
        goto la62m;
        OWwZ9:
        return;
        goto sxBk7;
        DIrww:
        Log::error("[Am402HUeF85Yj] File not found, discard it ", ['video' => $zyQ7O->getLocation()]);
        goto fEJun;
        whmQd:
        $kgFd6 = $this->kEfMA->getClient();
        goto pHM38;
        Rk6fs:
        try {
            goto MMdH6;
            Jp68l:
            $odlcs = $kgFd6->uploadPart(['Bucket' => $this->FhVsE, 'Key' => $zyQ7O->getLocation(), 'UploadId' => $G56a2, 'PartNumber' => $UKFCt, 'Body' => fread($TaLoI, $ktvvF)]);
            goto gEvgJ;
            d60W7:
            S17Xm:
            goto s0Ey2;
            gEvgJ:
            $QIhb6[] = ['PartNumber' => $UKFCt, 'ETag' => $odlcs['ETag']];
            goto BWz97;
            MhAki:
            WCVhz:
            goto MYzKN;
            vTgGV:
            goto WCVhz;
            goto d60W7;
            BWz97:
            $UKFCt++;
            goto vTgGV;
            MYzKN:
            if (feof($TaLoI)) {
                goto S17Xm;
            }
            goto Jp68l;
            VLG5I:
            $kgFd6->completeMultipartUpload(['Bucket' => $this->FhVsE, 'Key' => $zyQ7O->getLocation(), 'UploadId' => $G56a2, 'MultipartUpload' => ['Parts' => $QIhb6]]);
            goto tINy5;
            tINy5:
            $zyQ7O->update(['driver' => XmcIS8CQn72i3::S3, 'status' => Aetm2HiFuJE34::FINISHED]);
            goto xEPmo;
            xEPmo:
            $VHhUy->delete($zyQ7O->getLocation());
            goto zUhOf;
            vdGHN:
            $G56a2 = $Pay5j['UploadId'];
            goto JyUfl;
            nrjuK:
            $QIhb6 = [];
            goto MhAki;
            MMdH6:
            $Pay5j = $kgFd6->createMultipartUpload(['Bucket' => $this->FhVsE, 'Key' => $zyQ7O->getLocation(), 'ContentType' => $fk8IK, 'ContentDisposition' => 'inline']);
            goto vdGHN;
            JyUfl:
            $UKFCt = 1;
            goto nrjuK;
            s0Ey2:
            fclose($TaLoI);
            goto VLG5I;
            zUhOf:
        } catch (AwsException $AfYww) {
            goto q3O8H;
            Bd9O0:
            Log::error('Failed to store video: ' . $zyQ7O->getLocation() . ' - ' . $AfYww->getMessage());
            goto a0XHF;
            RGX7h:
            try {
                $kgFd6->abortMultipartUpload(['Bucket' => $this->FhVsE, 'Key' => $zyQ7O->getLocation(), 'UploadId' => $G56a2]);
            } catch (AwsException $WWMGH) {
                Log::error('Error aborting multipart upload: ' . $WWMGH->getMessage());
            }
            goto tLWlm;
            q3O8H:
            if (!isset($G56a2)) {
                goto BQwHC;
            }
            goto RGX7h;
            tLWlm:
            BQwHC:
            goto Bd9O0;
            a0XHF:
        } finally {
            $nQaGH = microtime(true);
            $QXkFj = memory_get_usage();
            $VfjfL = memory_get_peak_usage();
            Log::info('Store AvisbyD0IE5xq to S3 function resource usage', ['imageId' => $EQQae, 'execution_time_sec' => $nQaGH - $XzwBF, 'memory_usage_mb' => ($QXkFj - $CaFiz) / 1024 / 1024, 'peak_memory_usage_mb' => ($VfjfL - $m3FUa) / 1024 / 1024]);
        }
        goto tyFxU;
        vskDd:
        $m3FUa = memory_get_peak_usage();
        goto Rk6fs;
        sxBk7:
        WRGgR:
        goto RZdTz;
        gtVoN:
        rtWyI:
        goto ZlRx9;
        DQd3e:
        $XzwBF = microtime(true);
        goto Gpqzb;
        QQpf9:
        $ktvvF = 1024 * 1024 * 50;
        goto AhRot;
        q2IO3:
        $zyQ7O = AvisbyD0IE5xq::find($EQQae);
        goto ZWs4C;
        pHM38:
        $VHhUy = $this->c35HU;
        goto q2IO3;
        la62m:
        Log::info('Storing video (local) to S3', ['fileId' => $EQQae, 'bucketName' => $this->FhVsE]);
        goto fuzbk;
        fEJun:
        return;
        goto gtVoN;
        Gpqzb:
        $CaFiz = memory_get_usage();
        goto vskDd;
        fuzbk:
        ini_set('memory_limit', '-1');
        goto whmQd;
        AhRot:
        $fk8IK = $VHhUy->mimeType($zyQ7O->getLocation());
        goto DQd3e;
        ZWs4C:
        if ($zyQ7O) {
            goto WRGgR;
        }
        goto tAmNU;
        ZlRx9:
        $TaLoI = $VHhUy->readStream($zyQ7O->getLocation());
        goto QQpf9;
        RZdTz:
        if ($VHhUy->exists($zyQ7O->getLocation())) {
            goto rtWyI;
        }
        goto DIrww;
        tAmNU:
        Log::info("AvisbyD0IE5xq has been deleted, discard it", ['fileId' => $EQQae]);
        goto OWwZ9;
        tyFxU:
    }
}
