<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class HbqRXIyrD7cya implements GenerateThumbnailForVideoInterface
{
    private $AVLyK;
    public function __construct($UMEnj)
    {
        $this->AVLyK = $UMEnj;
    }
    public function generate(string $tu00C) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $tu00C);
        $this->AVLyK->createThumbnail($tu00C);
    }
}
