<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class K94er8DTblE32 implements GenerateThumbnailJobInterface
{
    const YWeMK = 150;
    const dgUo2 = 150;
    private $z0km_;
    private $ofZvx;
    private $vFVII;
    public function __construct($BSNlm, $suNmN, $pC4KD)
    {
        goto wr9zC;
        DdE60:
        $this->ofZvx = $suNmN;
        goto infyw;
        wr9zC:
        $this->z0km_ = $BSNlm;
        goto DdE60;
        infyw:
        $this->vFVII = $pC4KD;
        goto R3xf6;
        R3xf6:
    }
    public function generate(string $N2oAf)
    {
        goto jKt0p;
        jKt0p:
        Log::info("Generating thumbnail", ['imageId' => $N2oAf]);
        goto pou8V;
        POe_3:
        try {
            goto dzESh;
            Rur9p:
            $QJPJC = $this->vFVII->put($vRakW, $PpbTu->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto MBr7V;
            La2ro:
            $RxSHk = JMa7GBaLcnq3D::findOrFail($N2oAf);
            goto Ct5dt;
            Ct5dt:
            $PpbTu = $this->z0km_->call($this, $XCkIj->path($RxSHk->getLocation()));
            goto Pxelf;
            ogHac:
            if (!($QJPJC !== false)) {
                goto xA9bT;
            }
            goto a4Sjk;
            dzESh:
            $XCkIj = $this->ofZvx;
            goto La2ro;
            Pxelf:
            $PpbTu->orient()->resize(150, 150);
            goto Wj5Y3;
            a4Sjk:
            $RxSHk->update(['thumbnail' => $vRakW, 'status' => A9q1Lm9l5QixG::THUMBNAIL_PROCESSED]);
            goto yXbIs;
            Wj5Y3:
            $vRakW = $this->ml6PXtGY4oU($RxSHk);
            goto Rur9p;
            yXbIs:
            xA9bT:
            goto Tgti0;
            MBr7V:
            unset($PpbTu);
            goto ogHac;
            Tgti0:
        } catch (ModelNotFoundException $a9JiP) {
            Log::info("JMa7GBaLcnq3D has been deleted, discard it", ['imageId' => $N2oAf]);
            return;
        } catch (\Exception $a9JiP) {
            Log::error("Failed to generate thumbnail", ['imageId' => $N2oAf, 'error' => $a9JiP->getMessage()]);
        }
        goto WFvoz;
        pou8V:
        ini_set('memory_limit', '-1');
        goto POe_3;
        WFvoz:
    }
    private function ml6PXtGY4oU(MIyg7KY6jn9L1 $RxSHk) : string
    {
        goto P0Svr;
        EnQgW:
        $EnFXa = $TQLOY . '/' . self::YWeMK . 'X' . self::dgUo2;
        goto mTWuK;
        DW6ew:
        $TQLOY = dirname($vRakW);
        goto EnQgW;
        mTWuK:
        return $EnFXa . '/' . $RxSHk->getFilename() . '.jpg';
        goto mc9ay;
        P0Svr:
        $vRakW = $RxSHk->getLocation();
        goto DW6ew;
        mc9ay:
    }
}
