<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
class ONE13VivQKJcY implements WatermarkTextJobInterface
{
    private $RFvhw;
    private $QFCsF;
    private $G2Xe3;
    private $K79lK;
    private $x0wV5;
    public function __construct($LDEwd, $OPDJh, $yEBaZ, $mHTSY, $pKJN1)
    {
        goto CqALg;
        pxZRA:
        $this->QFCsF = $OPDJh;
        goto stgLx;
        CqALg:
        $this->RFvhw = $LDEwd;
        goto VBMQi;
        VBMQi:
        $this->K79lK = $yEBaZ;
        goto N7IeU;
        N7IeU:
        $this->x0wV5 = $mHTSY;
        goto CY9MR;
        CY9MR:
        $this->G2Xe3 = $pKJN1;
        goto pxZRA;
        stgLx:
    }
    public function putWatermark(string $Qu08p, string $S9w3S) : void
    {
        goto Ag0va;
        Ag0va:
        Log::info("Adding watermark text to image", ['imageId' => $Qu08p]);
        goto A_VA0;
        l8tn1:
        try {
            goto c51sT;
            hrpIg:
            if (chmod($TnwL2, 0664)) {
                goto aGVXl;
            }
            goto q8zp1;
            v4r51:
            YF3Sw:
            goto SvVvr;
            tvYm1:
            return;
            goto v4r51;
            psJon:
            $es2NA->save($TnwL2);
            goto q2EXn;
            xg1HV:
            throw new \Exception('Failed to set final permissions on image file: ' . $TnwL2);
            goto CDtg6;
            q8zp1:
            \Log::warning('Failed to set final permissions on image file: ' . $TnwL2);
            goto xg1HV;
            G39nW:
            $this->mKMs6DK79i2($es2NA, $S9w3S);
            goto psJon;
            c51sT:
            $fe3pc = YPgQPiPQjMu1g::findOrFail($Qu08p);
            goto mhY9v;
            mhY9v:
            if ($this->x0wV5->exists($fe3pc->getLocation())) {
                goto YF3Sw;
            }
            goto WWC82;
            mqgpi:
            $es2NA = $this->RFvhw->call($this, $TnwL2);
            goto TQwEX;
            q2EXn:
            $es2NA->destroy();
            goto hrpIg;
            SvVvr:
            $TnwL2 = $this->x0wV5->path($fe3pc->getLocation());
            goto mqgpi;
            CDtg6:
            aGVXl:
            goto rKjg_;
            TQwEX:
            $es2NA->orientate();
            goto G39nW;
            WWC82:
            Log::error("YPgQPiPQjMu1g is not on local, might be deleted before put watermark", ['imageId' => $Qu08p]);
            goto tvYm1;
            rKjg_:
        } catch (\Throwable $jRnx9) {
            goto OqbaX;
            qEkVR:
            fGMY0:
            goto C_0JW;
            OqbaX:
            if (!$jRnx9 instanceof ModelNotFoundException) {
                goto fGMY0;
            }
            goto O5o5I;
            O5o5I:
            Log::info("YPgQPiPQjMu1g has been deleted, discard it", ['imageId' => $Qu08p]);
            goto KSX7l;
            KSX7l:
            return;
            goto qEkVR;
            C_0JW:
            Log::error("YPgQPiPQjMu1g is not readable", ['imageId' => $Qu08p, 'error' => $jRnx9->getMessage()]);
            goto aBhAE;
            aBhAE:
        }
        goto DsSzv;
        A_VA0:
        ini_set('memory_limit', '-1');
        goto l8tn1;
        DsSzv:
    }
    private function mKMs6DK79i2($es2NA, $S9w3S) : void
    {
        goto Qz6gY;
        sk9hw:
        $rapOh = $this->RFvhw->call($this, $this->x0wV5->path($OcPLS));
        goto VDXcF;
        rfhpK:
        $JJXLO = new R40XH3H6TVben($this->QFCsF, $this->G2Xe3, $this->K79lK, $this->x0wV5);
        goto bgzNm;
        Qz6gY:
        $qFAp6 = $es2NA->width();
        goto yMrD4;
        yf1iA:
        $es2NA->insert($rapOh);
        goto Ot_6q;
        yMrD4:
        $bxUTl = $es2NA->height();
        goto rfhpK;
        bgzNm:
        $OcPLS = $JJXLO->m2IlDRXB6cD($qFAp6, $bxUTl, $S9w3S, true);
        goto tzis7;
        VDXcF:
        $rapOh->opacity(35);
        goto yf1iA;
        tzis7:
        $this->x0wV5->put($OcPLS, $this->K79lK->get($OcPLS));
        goto sk9hw;
        Ot_6q:
    }
}
