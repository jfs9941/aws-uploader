<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class NfIVkJvjy5S9N implements StoreToS3JobInterface
{
    private $JG9IT;
    private $huyLW;
    private $Ntit8;
    public function __construct($mLPCZ, $A3hvZ, $MYg0D)
    {
        goto P54r0;
        WiNDB:
        $this->JG9IT = $mLPCZ;
        goto cJUK1;
        P54r0:
        $this->huyLW = $A3hvZ;
        goto ydQj1;
        ydQj1:
        $this->Ntit8 = $MYg0D;
        goto WiNDB;
        cJUK1:
    }
    public function store(string $arqvy) : void
    {
        goto ag8yq;
        RPExU:
        $FpaeH = $this->Ntit8->path($abpQU->getAttribute('preview'));
        goto MJY8k;
        x7Ir3:
        Log::info("S7LEoIprYtLQw stored to S3, update the children attachments", ['fileId' => $arqvy]);
        goto ZV9uh;
        XLDle:
        $iZ2jw = $this->Ntit8->path($VdMBY);
        goto c5elY;
        F2P1k:
        if (!($abpQU->getAttribute('preview') && $this->Ntit8->exists($abpQU->getAttribute('preview')))) {
            goto I1R4C;
        }
        goto RPExU;
        Z_kPC:
        Log::info("S7LEoIprYtLQw has been deleted, discard it", ['fileId' => $arqvy]);
        goto n9gKa;
        Fdqoe:
        Uuudh:
        goto F2P1k;
        DGhlz:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $arqvy]);
        goto cL7D6;
        c5elY:
        $dZvCS = $this->JG9IT->call($this, $iZ2jw);
        goto fip1R;
        r8P_x:
        $lxbX3 = $this->Ntit8->path($abpQU->getLocation());
        goto GEIXv;
        ZV9uh:
        S7LEoIprYtLQw::where('parent_id', $arqvy)->update(['driver' => Opdj0uZXaMJfa::S3, 'preview' => $abpQU->getAttribute('preview'), 'thumbnail' => $abpQU->getAttribute('thumbnail')]);
        goto zJJnF;
        Vl_c7:
        VRWrY:
        goto r8P_x;
        n9gKa:
        return;
        goto Vl_c7;
        pTs1i:
        $this->huyLW->put($abpQU->getAttribute('preview'), $this->Ntit8->get($abpQU->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $yNmc8->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto zJ3rI;
        zJ3rI:
        I1R4C:
        goto azGmI;
        T_94v:
        RSC_a:
        goto DGhlz;
        ag8yq:
        $abpQU = S7LEoIprYtLQw::findOrFail($arqvy);
        goto SrYH0;
        fip1R:
        $this->huyLW->put($abpQU->getAttribute('thumbnail'), $this->Ntit8->get($VdMBY), ['visibility' => 'public', 'ContentType' => $dZvCS->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Fdqoe;
        iQL6D:
        $VdMBY = $abpQU->getAttribute('thumbnail');
        goto dTxPn;
        GEIXv:
        $this->mbcxBUxn2w3($lxbX3, $abpQU->getLocation());
        goto iQL6D;
        MJY8k:
        $yNmc8 = $this->JG9IT->call($this, $FpaeH);
        goto pTs1i;
        azGmI:
        if (!$abpQU->update(['driver' => Opdj0uZXaMJfa::S3, 'status' => EXecNg2hg7kwl::FINISHED])) {
            goto RSC_a;
        }
        goto x7Ir3;
        SrYH0:
        if ($abpQU) {
            goto VRWrY;
        }
        goto Z_kPC;
        zJJnF:
        return;
        goto T_94v;
        dTxPn:
        if (!($VdMBY && $this->Ntit8->exists($VdMBY))) {
            goto Uuudh;
        }
        goto XLDle;
        cL7D6:
    }
    private function mbcxBUxn2w3($CuxBW, $fmwTj, $w7vYI = '')
    {
        goto jVQZS;
        UiOvw:
        $CuxBW = str_replace('.jpg', $w7vYI, $CuxBW);
        goto XXyUc;
        hE3Gb:
        try {
            $uuvVo = $this->JG9IT->call($this, $CuxBW);
            $this->huyLW->put($fmwTj, $this->Ntit8->get($fmwTj), ['visibility' => 'public', 'ContentType' => $uuvVo->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $vR5RQ) {
            Log::error("Failed to upload image to S3", ['s3Path' => $fmwTj, 'error' => $vR5RQ->getMessage()]);
        }
        goto pRZpD;
        SGTdh:
        oCgDt:
        goto hE3Gb;
        XXyUc:
        $fmwTj = str_replace('.jpg', $w7vYI, $fmwTj);
        goto SGTdh;
        jVQZS:
        if (!$w7vYI) {
            goto oCgDt;
        }
        goto UiOvw;
        pRZpD:
    }
}
