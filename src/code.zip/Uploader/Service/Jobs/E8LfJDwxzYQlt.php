<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class E8LfJDwxzYQlt implements GenerateThumbnailJobInterface
{
    const trREs = 150;
    const DSHY1 = 150;
    private $xI8aP;
    private $Farqu;
    public function __construct($uIkIq, $MQQLd)
    {
        $this->xI8aP = $uIkIq;
        $this->Farqu = $MQQLd;
    }
    public function generate(string $eXur0)
    {
        goto wJj08;
        bkPet:
        ini_set('memory_limit', '-1');
        goto IkZ_A;
        wJj08:
        Log::info("Generating thumbnail", ['imageId' => $eXur0]);
        goto bkPet;
        IkZ_A:
        try {
            goto yIZ2D;
            fXGSc:
            $vYprr->destroy();
            goto hcF_r;
            M8D1z:
            $vYprr = $this->xI8aP->call($this, $GiTtn->path($CPHMS->getLocation()));
            goto N3kB9;
            AJb50:
            OxVC0:
            goto eVrQK;
            lOpyO:
            $vYprr->encode('jpg', 80);
            goto gLcR0;
            N3kB9:
            $vYprr->fit(150, 150, function ($vpeOW) {
                $vpeOW->aspectRatio();
            });
            goto lOpyO;
            jsFWC:
            throw new \Exception('Failed to set file permissions for stored image: ' . $cdBKm);
            goto AJb50;
            hcF_r:
            if (!($jOSHk !== false)) {
                goto mTWua;
            }
            goto zGLH8;
            yIZ2D:
            $GiTtn = $this->Farqu;
            goto Rd40t;
            OId9I:
            if (chmod($cdBKm, 0644)) {
                goto OxVC0;
            }
            goto pi6Ba;
            zGLH8:
            $CPHMS->update(['thumbnail' => $Y7TgX, 'status' => N4CY6qDTBAjPa::THUMBNAIL_PROCESSED]);
            goto JClz5;
            nDPlu:
            $jOSHk = $GiTtn->put($Y7TgX, $vYprr->stream(), ['visibility' => 'public']);
            goto fXGSc;
            gLcR0:
            $Y7TgX = $this->mJKF51YZReG($CPHMS);
            goto nDPlu;
            JClz5:
            $cdBKm = $GiTtn->path($Y7TgX);
            goto OId9I;
            pi6Ba:
            Log::warning('Failed to set file permissions for stored image: ' . $cdBKm);
            goto jsFWC;
            eVrQK:
            mTWua:
            goto G1SYK;
            Rd40t:
            $CPHMS = NBWuSM65HseqY::findOrFail($eXur0);
            goto M8D1z;
            G1SYK:
        } catch (ModelNotFoundException $HqoZE) {
            Log::info("NBWuSM65HseqY has been deleted, discard it", ['imageId' => $eXur0]);
            return;
        }
        goto kaq0S;
        kaq0S:
    }
    private function mJKF51YZReG(HJJu0xs0QACaQ $CPHMS) : string
    {
        goto uNpOY;
        Ag21k:
        $jNq3M = dirname($Y7TgX);
        goto hxqpT;
        ovBGv:
        return $dDYt_ . '/' . $CPHMS->getFilename() . '.jpg';
        goto RWKGU;
        uNpOY:
        $Y7TgX = $CPHMS->getLocation();
        goto Ag21k;
        hxqpT:
        $dDYt_ = $jNq3M . '/' . self::trREs . 'X' . self::DSHY1;
        goto ovBGv;
        RWKGU:
    }
}
