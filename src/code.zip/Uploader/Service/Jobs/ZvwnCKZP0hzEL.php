<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ZvwnCKZP0hzEL
{
    private $KbwvC;
    private $Peb9R;
    public function __construct(int $K6Pdv, int $SZ0Kg)
    {
        goto izIqF;
        dLBrB:
        $this->Peb9R = $SZ0Kg;
        goto Yg95V;
        T9Nbj:
        WLKDH:
        goto hFEI3;
        hFEI3:
        if (!($SZ0Kg <= 0)) {
            goto ZTlZV;
        }
        goto nveYy;
        jAFdV:
        $this->KbwvC = $K6Pdv;
        goto dLBrB;
        nveYy:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto CUU57;
        izIqF:
        if (!($K6Pdv <= 0)) {
            goto WLKDH;
        }
        goto NWOHs;
        NWOHs:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto T9Nbj;
        CUU57:
        ZTlZV:
        goto jAFdV;
        Yg95V:
    }
    private static function m5Q2wfjP7IZ($UP5W3, string $GqvbE = 'floor') : int
    {
        goto HlDxY;
        XxlCl:
        aWIvt:
        goto Rd9wq;
        l3JJK:
        return (int) $UP5W3;
        goto JpzDl;
        LUfg_:
        NBGm1:
        goto MIUON;
        JpzDl:
        e5yNt:
        goto ZeqaV;
        Rd9wq:
        PTMmK:
        goto AJTjJ;
        ivnRy:
        return $UP5W3;
        goto LUfg_;
        MIUON:
        if (!(is_float($UP5W3) && $UP5W3 == floor($UP5W3) && (int) $UP5W3 % 2 === 0)) {
            goto e5yNt;
        }
        goto l3JJK;
        HlDxY:
        if (!(is_int($UP5W3) && $UP5W3 % 2 === 0)) {
            goto NBGm1;
        }
        goto ivnRy;
        ZeqaV:
        switch (strtolower($GqvbE)) {
            case 'ceil':
                return (int) (ceil($UP5W3 / 2) * 2);
            case 'round':
                return (int) (round($UP5W3 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($UP5W3 / 2) * 2);
        }
        goto XxlCl;
        AJTjJ:
    }
    public function mA6zWsQJ3q2(string $oaRBH = 'floor') : array
    {
        goto YeaC8;
        D_Uuz:
        $WWWBW = $yXXKe;
        goto cKIeP;
        dXUy5:
        eGb2T:
        goto dCbTr;
        YeaC8:
        $yXXKe = 1080;
        goto NzaNo;
        vQHKT:
        if (!($WWWBW < 2)) {
            goto eGb2T;
        }
        goto D9RgY;
        kJ6dN:
        $tMchB = 2;
        goto HfSaK;
        YZZTq:
        z2Dwo:
        goto D_Uuz;
        tOEr3:
        $tMchB = self::m5Q2wfjP7IZ(round($FeAVD), $oaRBH);
        goto YSzEJ;
        dCbTr:
        return ['width' => $tMchB, 'height' => $WWWBW];
        goto FvPUp;
        rrzTe:
        $FeAVD = $this->KbwvC * $VjZvg;
        goto tOEr3;
        cKIeP:
        $VjZvg = $WWWBW / $this->Peb9R;
        goto rrzTe;
        MAiZ9:
        $tMchB = $yXXKe;
        goto uiS36;
        k00di:
        $WWWBW = self::m5Q2wfjP7IZ(round($xe8jW), $oaRBH);
        goto v3I9i;
        NzaNo:
        $tMchB = 0;
        goto JVy4S;
        YSzEJ:
        jQd3I:
        goto LsVe4;
        LsVe4:
        if (!($tMchB < 2)) {
            goto EqsfG;
        }
        goto kJ6dN;
        VGqkq:
        $xe8jW = $this->Peb9R * $VjZvg;
        goto k00di;
        HfSaK:
        EqsfG:
        goto vQHKT;
        uiS36:
        $VjZvg = $tMchB / $this->KbwvC;
        goto VGqkq;
        JVy4S:
        $WWWBW = 0;
        goto u3lmd;
        u3lmd:
        if ($this->KbwvC >= $this->Peb9R) {
            goto z2Dwo;
        }
        goto MAiZ9;
        v3I9i:
        goto jQd3I;
        goto YZZTq;
        D9RgY:
        $WWWBW = 2;
        goto dXUy5;
        FvPUp:
    }
}
