<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class Rr8Esp3bF4WdL implements StoreToS3JobInterface
{
    private $bLQUI;
    private $YHwpp;
    private $svYhv;
    public function __construct($xA3df, $ehLvI, $uLgU3)
    {
        goto qA5l0;
        XDUqg:
        $this->bLQUI = $xA3df;
        goto Ntacl;
        qA5l0:
        $this->YHwpp = $ehLvI;
        goto FuIx2;
        FuIx2:
        $this->svYhv = $uLgU3;
        goto XDUqg;
        Ntacl:
    }
    public function store(string $ShXx2) : void
    {
        goto gfE1d;
        itog0:
        $weLf2 = $this->bLQUI->call($this, $F78UR);
        goto LWgRM;
        euzjH:
        Log::info("Vt3ybt0yfaPAa stored to S3, update the children attachments", ['fileId' => $ShXx2]);
        goto T7hZd;
        i3qwi:
        $lPyJj = $this->svYhv->path($ShgKl->getLocation());
        goto IpXCu;
        NfBkN:
        w5qPg:
        goto i3qwi;
        qUFFy:
        wOl7r:
        goto eKE16;
        vOvQ1:
        BUN4J:
        goto XtX52;
        zY5MB:
        $this->YHwpp->put($ShgKl->getAttribute('preview'), $this->svYhv->get($ShgKl->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $MWYPz->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto fZtKZ;
        qU3Pq:
        $F78UR = $this->svYhv->path($XN5JG);
        goto itog0;
        Tgppv:
        return;
        goto qUFFy;
        RMxL4:
        if (!$ShgKl->update(['driver' => TpPQGsuK0gyw2::S3, 'status' => HGmeWpZQSxAlO::FINISHED])) {
            goto wOl7r;
        }
        goto euzjH;
        r7LNQ:
        return;
        goto NfBkN;
        guWQj:
        $XN5JG = $ShgKl->getAttribute('thumbnail');
        goto q2SI3;
        x5ntM:
        Log::info("Vt3ybt0yfaPAa has been deleted, discard it", ['fileId' => $ShXx2]);
        goto r7LNQ;
        T7hZd:
        Vt3ybt0yfaPAa::where('parent_id', $ShXx2)->update(['driver' => TpPQGsuK0gyw2::S3, 'preview' => $ShgKl->getAttribute('preview'), 'thumbnail' => $ShgKl->getAttribute('thumbnail')]);
        goto Tgppv;
        aHeyL:
        $QZDY1 = $this->svYhv->path($ShgKl->getAttribute('preview'));
        goto WVC4F;
        eKE16:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $ShXx2]);
        goto UQo1l;
        LWgRM:
        $this->YHwpp->put($ShgKl->getAttribute('thumbnail'), $this->svYhv->get($XN5JG), ['visibility' => 'public', 'ContentType' => $weLf2->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto vOvQ1;
        dKvu5:
        if ($ShgKl) {
            goto w5qPg;
        }
        goto x5ntM;
        fZtKZ:
        ECfBk:
        goto RMxL4;
        WVC4F:
        $MWYPz = $this->bLQUI->call($this, $QZDY1);
        goto zY5MB;
        XtX52:
        if (!($ShgKl->getAttribute('preview') && $this->svYhv->exists($ShgKl->getAttribute('preview')))) {
            goto ECfBk;
        }
        goto aHeyL;
        q2SI3:
        if (!($XN5JG && $this->svYhv->exists($XN5JG))) {
            goto BUN4J;
        }
        goto qU3Pq;
        IpXCu:
        $this->mFPSPOGQoTW($lPyJj, $ShgKl->getLocation());
        goto guWQj;
        gfE1d:
        $ShgKl = Vt3ybt0yfaPAa::findOrFail($ShXx2);
        goto dKvu5;
        UQo1l:
    }
    private function mFPSPOGQoTW($y5HQ5, $u2_KQ, $wpfYf = '')
    {
        goto GEe3e;
        GEe3e:
        if (!$wpfYf) {
            goto MBQcT;
        }
        goto orPEG;
        orPEG:
        $y5HQ5 = str_replace('.jpg', $wpfYf, $y5HQ5);
        goto jxU0S;
        k7xv2:
        try {
            $xixtT = $this->bLQUI->call($this, $y5HQ5);
            $this->YHwpp->put($u2_KQ, $this->svYhv->get($u2_KQ), ['visibility' => 'public', 'ContentType' => $xixtT->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $kE48F) {
            Log::error("Failed to upload image to S3", ['s3Path' => $u2_KQ, 'error' => $kE48F->getMessage()]);
        }
        goto rEiKC;
        jxU0S:
        $u2_KQ = str_replace('.jpg', $wpfYf, $u2_KQ);
        goto KCIiD;
        KCIiD:
        MBQcT:
        goto k7xv2;
        rEiKC:
    }
}
