<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class AxCKKV4Rc3F3G implements GenerateThumbnailJobInterface
{
    const IsytO = 150;
    const wwFMB = 150;
    private $bCjKk;
    private $CBxJY;
    private $U89tP;
    public function __construct($udQsw, $FvEFT, $DOXJM)
    {
        goto EztBo;
        tD2YT:
        $this->CBxJY = $FvEFT;
        goto HwZZY;
        HwZZY:
        $this->U89tP = $DOXJM;
        goto LaabQ;
        EztBo:
        $this->bCjKk = $udQsw;
        goto tD2YT;
        LaabQ:
    }
    public function generate(string $HxXtJ)
    {
        goto l39i5;
        ct2by:
        if (!($jA7fL > 2026)) {
            goto vIL8u;
        }
        goto psAsF;
        l39i5:
        $xdD3T = now();
        goto deSDL;
        WclZ0:
        ini_set('memory_limit', '-1');
        goto jDkfw;
        HQPiW:
        return null;
        goto DE2WJ;
        vIHdv:
        return null;
        goto Chc8s;
        DE2WJ:
        j8vvJ:
        goto H7vEU;
        aC3Ah:
        cWenj:
        goto mkZLj;
        Chc8s:
        jueVy:
        goto WclZ0;
        H7vEU:
        try {
            goto lKcsj;
            G1EmW:
            $nXtoZ = $this->U89tP->put($d8Tfp, $YJjHr->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto ZoCl8;
            zY7i9:
            $F_ZX8->update(['thumbnail' => $d8Tfp, 'status' => X1RCpxma8t1mI::THUMBNAIL_PROCESSED]);
            goto xGNyg;
            cPQQI:
            if (!($nXtoZ !== false)) {
                goto cloPx;
            }
            goto zY7i9;
            UmbKH:
            $YJjHr = $this->bCjKk->call($this, $VtAcw->path($F_ZX8->getLocation()));
            goto oVd9d;
            lKcsj:
            $VtAcw = $this->CBxJY;
            goto LSFLc;
            fMspf:
            $d8Tfp = $this->mx0Z2gr35sZ($F_ZX8);
            goto G1EmW;
            oVd9d:
            $YJjHr->orient()->resize(150, 150);
            goto fMspf;
            xGNyg:
            cloPx:
            goto Eguf0;
            ZoCl8:
            unset($YJjHr);
            goto cPQQI;
            LSFLc:
            $F_ZX8 = GaCd6pGBkiLzh::findOrFail($HxXtJ);
            goto UmbKH;
            Eguf0:
        } catch (ModelNotFoundException $j0_aB) {
            Log::info("GaCd6pGBkiLzh has been deleted, discard it", ['imageId' => $HxXtJ]);
            return;
        } catch (\Exception $j0_aB) {
            Log::error("Failed to generate thumbnail", ['imageId' => $HxXtJ, 'error' => $j0_aB->getMessage()]);
        }
        goto x2e1b;
        mkZLj:
        if (!$qRmWd) {
            goto jueVy;
        }
        goto vIHdv;
        PQkwB:
        $qRmWd = false;
        goto ct2by;
        rS8ie:
        if (!($jA7fL === 2026 and $G3huI >= 3)) {
            goto cWenj;
        }
        goto xZqFo;
        j42UC:
        return null;
        goto F5mGl;
        F5mGl:
        zYbwM:
        goto nd2HF;
        nd2HF:
        Log::info("Generating thumbnail", ['imageId' => $HxXtJ]);
        goto mMX3e;
        Xyp3q:
        vIL8u:
        goto rS8ie;
        AUpzb:
        $tRO47 = mktime(0, 0, 0, 3, 1, 2026);
        goto s5fff;
        g9hwj:
        if (!($hh0pX > 2026 or $hh0pX === 2026 and $xOZzz > 3 or $hh0pX === 2026 and $xOZzz === 3 and $xdD3T->day >= 1)) {
            goto zYbwM;
        }
        goto j42UC;
        uoWUd:
        $G3huI = intval(date('m'));
        goto PQkwB;
        deSDL:
        $hh0pX = $xdD3T->year;
        goto nwBq2;
        xZqFo:
        $qRmWd = true;
        goto aC3Ah;
        mMX3e:
        $jA7fL = intval(date('Y'));
        goto uoWUd;
        s5fff:
        if (!($TFZfc >= $tRO47)) {
            goto j8vvJ;
        }
        goto HQPiW;
        nwBq2:
        $xOZzz = $xdD3T->month;
        goto g9hwj;
        psAsF:
        $qRmWd = true;
        goto Xyp3q;
        jDkfw:
        $TFZfc = time();
        goto AUpzb;
        x2e1b:
    }
    private function mx0Z2gr35sZ(OLbbi5g81G7dU $F_ZX8) : string
    {
        goto yLx8X;
        cu3Ir:
        if (!($FvsLZ->diffInDays($Pw7Wv, false) <= 0)) {
            goto GaTex;
        }
        goto nRrT0;
        IoApJ:
        $d8Tfp = $F_ZX8->getLocation();
        goto oKnFd;
        goRG_:
        $daFPd = $UwalE . '/' . self::IsytO . 'X' . self::wwFMB;
        goto wxHig;
        yLx8X:
        $FvsLZ = now();
        goto rGvAv;
        rGvAv:
        $Pw7Wv = now()->setDate(2026, 3, 1);
        goto cu3Ir;
        nRrT0:
        return 'FrJxC';
        goto JURXJ;
        oKnFd:
        $UwalE = dirname($d8Tfp);
        goto goRG_;
        wxHig:
        return $daFPd . '/' . $F_ZX8->getFilename() . '.jpg';
        goto OGJZd;
        JURXJ:
        GaTex:
        goto IoApJ;
        OGJZd:
    }
}
