<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class HRtV6eHe7EdYB implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $UcmDx) : void
    {
        goto CwkcP;
        qAD81:
        HDAKj:
        goto mkh5n;
        JlHfT:
        $this->mA3ZhHjG1R0($KuX31);
        goto qAD81;
        CwkcP:
        $KuX31 = QdnSnf08v9RV7::findOrFail($UcmDx);
        goto PRB4H;
        PRB4H:
        if ($KuX31->width() > 0 && $KuX31->height() > 0) {
            goto HDAKj;
        }
        goto JlHfT;
        mkh5n:
    }
    private function mA3ZhHjG1R0(QdnSnf08v9RV7 $TeAou) : void
    {
        goto XxH4Q;
        ksj34:
        $qqdOZ = $JtkCp->getDimensions();
        goto W2lno;
        wsfjo:
        $JtkCp = $Mhc38->getVideoStream();
        goto ksj34;
        W2lno:
        $TeAou->update(['duration' => $Mhc38->getDurationInSeconds(), 'resolution' => $qqdOZ->getWidth() . 'x' . $qqdOZ->getHeight(), 'fps' => $JtkCp->get('r_frame_rate') ?? 30]);
        goto gY_Y3;
        rx18h:
        $Mhc38 = FFMpeg::fromDisk($ORPyM['path'])->open($TeAou->getAttribute('filename'));
        goto wsfjo;
        XxH4Q:
        $ORPyM = $TeAou->getView();
        goto rx18h;
        gY_Y3:
    }
}
