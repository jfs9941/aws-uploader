<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class H3u7NmHvIxK7d implements GenerateThumbnailJobInterface
{
    const rl6ku = 150;
    const gi9mL = 150;
    private $awXpN;
    private $AwDbR;
    private $AoOHl;
    public function __construct($ek1iS, $uwOBm, $cTRYW)
    {
        goto yhpfS;
        HhrsF:
        $this->AoOHl = $cTRYW;
        goto V9Fjs;
        yhpfS:
        $this->awXpN = $ek1iS;
        goto Z_CVS;
        Z_CVS:
        $this->AwDbR = $uwOBm;
        goto HhrsF;
        V9Fjs:
    }
    public function generate(string $B5uQ4)
    {
        goto mKb3_;
        dW3_q:
        ini_set('memory_limit', '-1');
        goto U2aTk;
        mKb3_:
        Log::info("Generating thumbnail", ['imageId' => $B5uQ4]);
        goto dW3_q;
        U2aTk:
        try {
            goto Ymh4k;
            qbWPT:
            QFiFa:
            goto dXxs_;
            FUMQa:
            $jYl_6 = U0IzvN2kaLZHI::findOrFail($B5uQ4);
            goto qQt1W;
            z6yKN:
            $vjOx0->orient()->resize(150, 150);
            goto JRWok;
            kQQvI:
            $BXTcc = $this->AoOHl->put($uUtRl, $vjOx0->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto vtrqS;
            qQt1W:
            $vjOx0 = $this->awXpN->call($this, $kVG4M->path($jYl_6->getLocation()));
            goto z6yKN;
            Ymh4k:
            $kVG4M = $this->AwDbR;
            goto FUMQa;
            vtrqS:
            unset($vjOx0);
            goto J_iyF;
            bFIXF:
            $jYl_6->update(['thumbnail' => $uUtRl, 'status' => KidkTsWIjmNMb::THUMBNAIL_PROCESSED]);
            goto qbWPT;
            J_iyF:
            if (!($BXTcc !== false)) {
                goto QFiFa;
            }
            goto bFIXF;
            JRWok:
            $uUtRl = $this->mv6VKtsmUGA($jYl_6);
            goto kQQvI;
            dXxs_:
        } catch (ModelNotFoundException $EgQtq) {
            Log::info("U0IzvN2kaLZHI has been deleted, discard it", ['imageId' => $B5uQ4]);
            return;
        } catch (\Exception $EgQtq) {
            Log::error("Failed to generate thumbnail", ['imageId' => $B5uQ4, 'error' => $EgQtq->getMessage()]);
        }
        goto GIvcH;
        GIvcH:
    }
    private function mv6VKtsmUGA(UfttW7MErNAIK $jYl_6) : string
    {
        goto QJyNe;
        UOYlq:
        $pVfz3 = dirname($uUtRl);
        goto q1jfE;
        QJyNe:
        $uUtRl = $jYl_6->getLocation();
        goto UOYlq;
        LFnO6:
        return $yk6Vq . '/' . $jYl_6->getFilename() . '.jpg';
        goto Eutjg;
        q1jfE:
        $yk6Vq = $pVfz3 . '/' . self::rl6ku . 'X' . self::gi9mL;
        goto LFnO6;
        Eutjg:
    }
}
