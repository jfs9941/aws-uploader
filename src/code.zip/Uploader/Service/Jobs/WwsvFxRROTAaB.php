<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class WwsvFxRROTAaB implements GenerateThumbnailJobInterface
{
    const q30Hb = 150;
    const D4nFA = 150;
    private $gVUAC;
    private $jhnu6;
    private $ssiPf;
    public function __construct($pe6Kp, $vWOwZ, $kMbER)
    {
        goto KYQeJ;
        Ecuts:
        $this->jhnu6 = $vWOwZ;
        goto UCcCp;
        UCcCp:
        $this->ssiPf = $kMbER;
        goto oZ1nP;
        KYQeJ:
        $this->gVUAC = $pe6Kp;
        goto Ecuts;
        oZ1nP:
    }
    public function generate(string $q8q1b)
    {
        goto r2sYt;
        EEn6Z:
        ini_set('memory_limit', '-1');
        goto h2urA;
        r2sYt:
        Log::info("Generating thumbnail", ['imageId' => $q8q1b]);
        goto EEn6Z;
        h2urA:
        try {
            goto DNBO3;
            wbOhg:
            $dPkX5 = $this->ssiPf->put($K_YMm, $LF1ar->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto Ku3IP;
            Ku3IP:
            unset($LF1ar);
            goto QHdT6;
            RehPH:
            $LF1ar->orient()->resize(150, 150);
            goto kdlSb;
            kdlSb:
            $K_YMm = $this->mbczg5sL9TG($PdjKE);
            goto wbOhg;
            cUQNC:
            $LF1ar = $this->gVUAC->call($this, $FHlTP->path($PdjKE->getLocation()));
            goto RehPH;
            eEbjL:
            $PdjKE = JOauoJMkgHWbh::findOrFail($q8q1b);
            goto cUQNC;
            ilIjE:
            dzUK0:
            goto Qm29T;
            QHdT6:
            if (!($dPkX5 !== false)) {
                goto dzUK0;
            }
            goto v2Imz;
            v2Imz:
            $PdjKE->update(['thumbnail' => $K_YMm, 'status' => IfP50GBBbx63a::THUMBNAIL_PROCESSED]);
            goto ilIjE;
            DNBO3:
            $FHlTP = $this->jhnu6;
            goto eEbjL;
            Qm29T:
        } catch (ModelNotFoundException $r5DbO) {
            Log::info("JOauoJMkgHWbh has been deleted, discard it", ['imageId' => $q8q1b]);
            return;
        } catch (\Exception $r5DbO) {
            Log::error("Failed to generate thumbnail", ['imageId' => $q8q1b, 'error' => $r5DbO->getMessage()]);
        }
        goto IJieE;
        IJieE:
    }
    private function mbczg5sL9TG(Lx6EggVsR2j6q $PdjKE) : string
    {
        goto i5_dn;
        tTjlh:
        $IZRUn = dirname($K_YMm);
        goto xxbtH;
        Ivggv:
        return $kzUfg . '/' . $PdjKE->getFilename() . '.jpg';
        goto YAOcS;
        i5_dn:
        $K_YMm = $PdjKE->getLocation();
        goto tTjlh;
        xxbtH:
        $kzUfg = $IZRUn . '/' . self::q30Hb . 'X' . self::D4nFA;
        goto Ivggv;
        YAOcS:
    }
}
