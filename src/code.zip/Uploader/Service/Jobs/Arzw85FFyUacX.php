<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Illuminate\Support\Facades\Log;
class Arzw85FFyUacX implements StoreVideoToS3JobInterface
{
    private $NC4Qr;
    private $VJN91;
    private $EaJ_d;
    public function __construct($dxOEL, $J83Op, $t9atP)
    {
        goto HIBSm;
        B3MfP:
        $this->NC4Qr = $dxOEL;
        goto IqZUs;
        HIBSm:
        $this->VJN91 = $J83Op;
        goto H_VhP;
        H_VhP:
        $this->EaJ_d = $t9atP;
        goto B3MfP;
        IqZUs:
    }
    public function store(string $wAkkA) : void
    {
        goto c_iBK;
        MRbhg:
        if ($t9atP->exists($LGN29->getLocation())) {
            goto jDpTH;
        }
        goto cSs3S;
        vi4j5:
        $pu7IV = 1024 * 1024 * 50;
        goto Ua7XF;
        zhpdn:
        jDpTH:
        goto P4nFp;
        Ua7XF:
        $wJJHL = $t9atP->mimeType($LGN29->getLocation());
        goto xYef7;
        iNsw1:
        $LGN29 = WI5WSPGRr1b2t::find($wAkkA);
        goto EyPyj;
        P4nFp:
        $fwVme = $t9atP->readStream($LGN29->getLocation());
        goto vi4j5;
        Br4xp:
        return;
        goto aHLeT;
        ln2Dg:
        return;
        goto zhpdn;
        c_iBK:
        Log::info('Storing video (local) to S3', ['fileId' => $wAkkA, 'bucketName' => $this->NC4Qr]);
        goto c_yUV;
        xYef7:
        $fShTg = microtime(true);
        goto CHF37;
        aHLeT:
        h3ewl:
        goto MRbhg;
        cSs3S:
        Log::error("[Arzw85FFyUacX] File not found, discard it ", ['video' => $LGN29->getLocation()]);
        goto ln2Dg;
        EyPyj:
        if ($LGN29) {
            goto h3ewl;
        }
        goto FYdE0;
        i5TM0:
        try {
            goto phlSO;
            MlCzG:
            oqnxN:
            goto PpOlU;
            DEZNR:
            $oDHkw[] = ['PartNumber' => $P33hR, 'ETag' => $aYupQ['ETag']];
            goto qlTlY;
            ZiMID:
            $LGN29->update(['driver' => Pj539Ru5gyMbt::S3]);
            goto PMJzU;
            lsCcz:
            $aYupQ = $P7bmZ->uploadPart(['Bucket' => $this->NC4Qr, 'Key' => $LGN29->getLocation(), 'UploadId' => $aPEyz, 'PartNumber' => $P33hR, 'Body' => fread($fwVme, $pu7IV)]);
            goto DEZNR;
            qlTlY:
            $P33hR++;
            goto N9umO;
            N85aJ:
            $oDHkw = [];
            goto h811W;
            OYcku:
            $P33hR = 1;
            goto N85aJ;
            phlSO:
            $FhmWg = $P7bmZ->createMultipartUpload(['Bucket' => $this->NC4Qr, 'Key' => $LGN29->getLocation(), 'ContentType' => $wJJHL, 'ContentDisposition' => 'inline']);
            goto yThbi;
            PMJzU:
            $t9atP->delete($LGN29->getLocation());
            goto HwNIl;
            tLHlH:
            $P7bmZ->completeMultipartUpload(['Bucket' => $this->NC4Qr, 'Key' => $LGN29->getLocation(), 'UploadId' => $aPEyz, 'MultipartUpload' => ['Parts' => $oDHkw]]);
            goto ZiMID;
            yThbi:
            $aPEyz = $FhmWg['UploadId'];
            goto OYcku;
            N9umO:
            goto wKeIm;
            goto MlCzG;
            PpOlU:
            fclose($fwVme);
            goto tLHlH;
            h811W:
            wKeIm:
            goto D9ZaW;
            D9ZaW:
            if (feof($fwVme)) {
                goto oqnxN;
            }
            goto lsCcz;
            HwNIl:
        } catch (AwsException $EGnga) {
            goto Zshme;
            OxLvQ:
            Log::error('Failed to store video: ' . $LGN29->getLocation() . ' - ' . $EGnga->getMessage());
            goto p3Amz;
            CM08A:
            aSSeO:
            goto OxLvQ;
            LaNV6:
            try {
                $P7bmZ->abortMultipartUpload(['Bucket' => $this->NC4Qr, 'Key' => $LGN29->getLocation(), 'UploadId' => $aPEyz]);
            } catch (AwsException $mHjiv) {
                Log::error('Error aborting multipart upload: ' . $mHjiv->getMessage());
            }
            goto CM08A;
            Zshme:
            if (!isset($aPEyz)) {
                goto aSSeO;
            }
            goto LaNV6;
            p3Amz:
        } finally {
            $TFGkL = microtime(true);
            $D2XLx = memory_get_usage();
            $dMjbk = memory_get_peak_usage();
            Log::info('Store WI5WSPGRr1b2t to S3 function resource usage', ['imageId' => $wAkkA, 'execution_time_sec' => $TFGkL - $fShTg, 'memory_usage_mb' => ($D2XLx - $XojxF) / 1024 / 1024, 'peak_memory_usage_mb' => ($dMjbk - $f0Zjf) / 1024 / 1024]);
        }
        goto EC0Vm;
        Xm1Wn:
        $P7bmZ = $this->VJN91->getClient();
        goto q0lMa;
        c_yUV:
        ini_set('memory_limit', '-1');
        goto Xm1Wn;
        hp3Ii:
        $f0Zjf = memory_get_peak_usage();
        goto i5TM0;
        FYdE0:
        Log::info("WI5WSPGRr1b2t has been deleted in database or not inserted yet, discard it", ['fileId' => $wAkkA]);
        goto Br4xp;
        q0lMa:
        $t9atP = $this->EaJ_d;
        goto iNsw1;
        CHF37:
        $XojxF = memory_get_usage();
        goto hp3Ii;
        EC0Vm:
    }
}
