<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Encoder\ZhqheKMj6zBOk;
use Jfs\Uploader\Encoder\UcICRyWMxVcex;
use Jfs\Uploader\Encoder\FSb1vbQf2TVPX;
use Jfs\Uploader\Encoder\H79n2eIrx9Dev;
use Jfs\Uploader\Encoder\Y6FiBoyfJXwAc;
use Jfs\Uploader\Encoder\QwTnAGbkeDsJa;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Jfs\Uploader\Service\Jobs\RJ8Y740RD1tez;
use Jfs\Uploader\Service\Jobs\VNtYCSNiCWI3M;
use Jfs\Uploader\Service\KiBRYQgrRVRtv;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class LKkvz1qFhNZOK implements MediaEncodeJobInterface
{
    private $VzV90;
    private $pXh9P;
    private $QxLu3;
    private $oJNPX;
    private $cAi3S;
    public function __construct(string $v4kIW, $TWZho, $bjIIR, $K4GQ_, $A7A73)
    {
        goto FDSE5;
        Nd4tg:
        $this->oJNPX = $K4GQ_;
        goto nTFup;
        SJRVF:
        $this->QxLu3 = $bjIIR;
        goto Nd4tg;
        JkkM5:
        $this->pXh9P = $TWZho;
        goto SJRVF;
        nTFup:
        $this->cAi3S = $A7A73;
        goto m59iA;
        FDSE5:
        $this->VzV90 = $v4kIW;
        goto JkkM5;
        m59iA:
    }
    public function encode(string $qMhfW, string $S5d8n, $yhhs7 = true) : void
    {
        goto PJc49;
        aIkNA:
        ini_set('memory_limit', '-1');
        goto JNPMZ;
        PJc49:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $qMhfW]);
        goto aIkNA;
        JNPMZ:
        try {
            goto N6W_3;
            LT48v:
            Log::info("Set 1080p resolution for Job", ['width' => $X5ud6['width'], 'height' => $X5ud6['height'], 'originalWidth' => $ZJYlg, 'originalHeight' => $RFX4H]);
            goto s9TBj;
            S0xtC:
            Assert::isInstanceOf($JhYqb, NYx4mhlHSMgHF::class);
            goto l181f;
            rXVp6:
            throw new MediaConverterException("NYx4mhlHSMgHF {$JhYqb->id} is not S3 driver");
            goto jJdSf;
            ZxihJ:
            $JhYqb->update(['aws_media_converter_job_id' => $qMhfW]);
            goto EjiPF;
            gZoeF:
            $Jnd8y = $this->mMnDwLHJyOP($uLczT, $zdqrL->mHXH8gbRF5x((int) $X5ud6['width'], (int) $X5ud6['height'], $S5d8n));
            goto oM8NU;
            wQi5o:
            $lqRvU->mypBAWwioeu($hfngR);
            goto bGK2y;
            E0jHE:
            $lqRvU = $lqRvU->muH7QQYELle($f_EWh);
            goto y6bhI;
            oUCqW:
            LpOhk:
            goto CXBvM;
            Ns3zD:
            $XLwb0 = $this->maaEYjSSTdf($JhYqb);
            goto IrRte;
            RD1vV:
            $lqRvU = $lqRvU->moj1tsuqnPJ(new H79n2eIrx9Dev($XLwb0));
            goto HsDRM;
            bnX15:
            $f_EWh = new ZhqheKMj6zBOk($JhYqb->Gwo13 ?? 1, 2, $kViBN->mIAn1jApgCC($JhYqb));
            goto E0jHE;
            s9TBj:
            $pT5Tk = new UcICRyWMxVcex('1080p', $X5ud6['width'], $X5ud6['height'], $JhYqb->pBlyB ?? 30);
            goto gZoeF;
            y6bhI:
            $qMhfW = $lqRvU->m3JunJVgwk3($this->mKSPBprFCUH($JhYqb, $yhhs7));
            goto ZxihJ;
            oM8NU:
            if (!$Jnd8y) {
                goto dRYwo;
            }
            goto ZCcMv;
            jJdSf:
            QvhFr:
            goto a46je;
            i50Ti:
            if (!$Jnd8y) {
                goto LpOhk;
            }
            goto iISzj;
            q8kee:
            jzlnJ:
            goto KB0mG;
            iISzj:
            $hfngR = $hfngR->mIfYZTIoDJV($Jnd8y);
            goto oUCqW;
            bGK2y:
            $lqRvU->m563SkKfO2j($kViBN->mu3Y9htrOBq($JhYqb));
            goto jrdLp;
            N6W_3:
            $JhYqb = NYx4mhlHSMgHF::findOrFail($qMhfW);
            goto S0xtC;
            l181f:
            if (!($JhYqb->pb8PJ !== YOaiWCgFM7tRK::S3)) {
                goto QvhFr;
            }
            goto rXVp6;
            JFDtE:
            $lqRvU->m563SkKfO2j($kViBN->mu3Y9htrOBq($JhYqb));
            goto uXglt;
            HsDRM:
            $hfngR = new UcICRyWMxVcex('original', $ZJYlg, $RFX4H, $JhYqb->pBlyB ?? 30);
            goto mn6oe;
            a46je:
            $ZJYlg = $JhYqb->width();
            goto KT78Z;
            jFS0A:
            $lqRvU = $lqRvU->mypBAWwioeu($pT5Tk);
            goto UK025;
            mn6oe:
            $kViBN = app(FSb1vbQf2TVPX::class);
            goto wQi5o;
            jrdLp:
            $uLczT = app(KiBRYQgrRVRtv::class);
            goto nVep5;
            GPm9C:
            dRYwo:
            goto jFS0A;
            KT78Z:
            $RFX4H = $JhYqb->height();
            goto Ns3zD;
            uXglt:
            if (!($ZJYlg && $RFX4H)) {
                goto jzlnJ;
            }
            goto nczQ5;
            nzziE:
            $Jnd8y = $this->mMnDwLHJyOP($uLczT, $zdqrL->mHXH8gbRF5x($JhYqb->width(), $JhYqb->height(), $S5d8n));
            goto i50Ti;
            nczQ5:
            if (!$this->myp72kTc4Iw($ZJYlg, $RFX4H)) {
                goto Xl6k9;
            }
            goto iXL8K;
            ZCcMv:
            $pT5Tk = $pT5Tk->mIfYZTIoDJV($Jnd8y);
            goto GPm9C;
            nVep5:
            $zdqrL = new VNtYCSNiCWI3M($this->oJNPX, $this->cAi3S, $this->QxLu3, $this->pXh9P);
            goto nzziE;
            CXBvM:
            $lqRvU->mypBAWwioeu($hfngR);
            goto JFDtE;
            iXL8K:
            $X5ud6 = $this->mbJThus1oug($ZJYlg, $RFX4H);
            goto LT48v;
            faeuH:
            $lqRvU = app(Y6FiBoyfJXwAc::class);
            goto RD1vV;
            KB0mG:
            Log::info("Set thumbnail for NYx4mhlHSMgHF Job", ['videoId' => $JhYqb->getAttribute('id'), 'duration' => $JhYqb->getAttribute('duration')]);
            goto bnX15;
            IrRte:
            Log::info("Set input video for Job", ['s3Uri' => $XLwb0]);
            goto faeuH;
            UK025:
            Xl6k9:
            goto q8kee;
            EjiPF:
        } catch (\Exception $jupeT) {
            Log::info("NYx4mhlHSMgHF has been deleted, discard it", ['fileId' => $qMhfW, 'err' => $jupeT->getMessage()]);
            return;
        }
        goto WhSAL;
        WhSAL:
    }
    private function mKSPBprFCUH(NYx4mhlHSMgHF $JhYqb, $yhhs7) : bool
    {
        goto YRw3w;
        Sj5wN:
        kzx57:
        goto bGE3F;
        Pbu31:
        GQD8d:
        goto Sj5wN;
        n7qSO:
        return false;
        goto I1YU5;
        hsNx7:
        switch (true) {
            case $JhYqb->width() * $JhYqb->height() >= 1920 * 1080 && $JhYqb->width() * $JhYqb->height() < 2560 * 1440:
                return $LcGK1 > 10 * 60;
            case $JhYqb->width() * $JhYqb->height() >= 2560 * 1440 && $JhYqb->width() * $JhYqb->height() < 3840 * 2160:
                return $LcGK1 > 5 * 60;
            case $JhYqb->width() * $JhYqb->height() >= 3840 * 2160:
                return $LcGK1 > 3 * 60;
            default:
                return false;
        }
        goto Pbu31;
        Brz_v:
        $LcGK1 = (int) round($JhYqb->getAttribute('duration') ?? 0);
        goto hsNx7;
        I1YU5:
        C9MNR:
        goto Brz_v;
        YRw3w:
        if ($yhhs7) {
            goto C9MNR;
        }
        goto n7qSO;
        bGE3F:
    }
    private function mMnDwLHJyOP(KiBRYQgrRVRtv $uLczT, string $wvH7y) : ?QwTnAGbkeDsJa
    {
        goto HD6n9;
        eQ_X3:
        ivZwg:
        goto bF57Y;
        URzWE:
        Log::info("Resolve watermark for job with url", ['url' => $wvH7y, 'uri' => $bFuGX]);
        goto AFyYZ;
        bF57Y:
        return null;
        goto qnR1O;
        HD6n9:
        $bFuGX = $uLczT->mWj7taGWPTi($wvH7y);
        goto URzWE;
        clWbc:
        return new QwTnAGbkeDsJa($bFuGX, 0, 0, null, null);
        goto eQ_X3;
        AFyYZ:
        if (!$bFuGX) {
            goto ivZwg;
        }
        goto clWbc;
        qnR1O:
    }
    private function myp72kTc4Iw(int $ZJYlg, int $RFX4H) : bool
    {
        return $ZJYlg * $RFX4H > 1.5 * (1920 * 1080);
    }
    private function mbJThus1oug(int $ZJYlg, int $RFX4H) : array
    {
        $nZGcN = new RJ8Y740RD1tez($ZJYlg, $RFX4H);
        return $nZGcN->mv96vCYyPUk();
    }
    private function maaEYjSSTdf(Rqw1PJIt1YU1r $ift9y) : string
    {
        goto KAlhF;
        XiU_N:
        return $this->pXh9P->url($ift9y->filename);
        goto HpAxd;
        KAlhF:
        if (!($ift9y->pb8PJ == YOaiWCgFM7tRK::S3)) {
            goto wIv5V;
        }
        goto lzpYP;
        lzpYP:
        return 's3://' . $this->VzV90 . '/' . $ift9y->filename;
        goto YoExg;
        YoExg:
        wIv5V:
        goto XiU_N;
        HpAxd:
    }
}
