<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class TYN4BeqY0zpXt implements GenerateThumbnailJobInterface
{
    const dqWi9 = 150;
    const I9e4n = 150;
    private $bIrxp;
    private $GRsEs;
    private $hpoa6;
    public function __construct($NJy8O, $Zywh9, $tKzGl)
    {
        goto b2K9L;
        b2K9L:
        $this->bIrxp = $NJy8O;
        goto RvRw_;
        Q3LdP:
        $this->hpoa6 = $tKzGl;
        goto x7We6;
        RvRw_:
        $this->GRsEs = $Zywh9;
        goto Q3LdP;
        x7We6:
    }
    public function generate(string $eeXS6)
    {
        goto Pt8B4;
        sm68c:
        ini_set('memory_limit', '-1');
        goto XV4av;
        Pt8B4:
        Log::info("Generating thumbnail", ['imageId' => $eeXS6]);
        goto sm68c;
        XV4av:
        try {
            goto gt29k;
            gt29k:
            $L32kE = $this->GRsEs;
            goto goDjq;
            nWRH2:
            $U5V1U = $this->bIrxp->call($this, $L32kE->path($K0J89->getLocation()));
            goto eFNhT;
            p1meT:
            if (!($NuAgs !== false)) {
                goto jVkwO;
            }
            goto gO9rR;
            BWYnB:
            unset($U5V1U);
            goto p1meT;
            goDjq:
            $K0J89 = UG34Yjmf7IsbQ::findOrFail($eeXS6);
            goto nWRH2;
            hgAwA:
            jVkwO:
            goto o5C1I;
            mwazW:
            $NSF8Y = $this->mopbvMljxg6($K0J89);
            goto jvMyg;
            gO9rR:
            $K0J89->update(['thumbnail' => $NSF8Y, 'status' => A7CVlqbpzhfLD::THUMBNAIL_PROCESSED]);
            goto hgAwA;
            eFNhT:
            $U5V1U->orient()->resize(150, 150);
            goto mwazW;
            jvMyg:
            $NuAgs = $this->hpoa6->put($NSF8Y, $U5V1U->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto BWYnB;
            o5C1I:
        } catch (ModelNotFoundException $kJgSA) {
            Log::info("UG34Yjmf7IsbQ has been deleted, discard it", ['imageId' => $eeXS6]);
            return;
        } catch (\Exception $kJgSA) {
            Log::error("Failed to generate thumbnail", ['imageId' => $eeXS6, 'error' => $kJgSA->getMessage()]);
        }
        goto otphW;
        otphW:
    }
    private function mopbvMljxg6(OWEQTdXGAAFta $K0J89) : string
    {
        goto gl44N;
        PnQut:
        $S4PZU = dirname($NSF8Y);
        goto lKNul;
        lKNul:
        $NOjjH = $S4PZU . '/' . self::dqWi9 . 'X' . self::I9e4n;
        goto T1FMT;
        T1FMT:
        return $NOjjH . '/' . $K0J89->getFilename() . '.jpg';
        goto JfJ0r;
        gl44N:
        $NSF8Y = $K0J89->getLocation();
        goto PnQut;
        JfJ0r:
    }
}
