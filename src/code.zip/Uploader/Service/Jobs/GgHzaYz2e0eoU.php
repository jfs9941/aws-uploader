<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class GgHzaYz2e0eoU implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $eeXS6) : void
    {
        goto DTo_M;
        jTsh2:
        $this->mRi2q8BFeLL($JfLWA);
        goto oglcX;
        u4hch:
        if ($JfLWA->width() > 0 && $JfLWA->height() > 0) {
            goto hK6Q6;
        }
        goto jTsh2;
        DTo_M:
        $JfLWA = N1wF7eNF4lYgo::findOrFail($eeXS6);
        goto u4hch;
        oglcX:
        hK6Q6:
        goto pqoBT;
        pqoBT:
    }
    private function mRi2q8BFeLL(N1wF7eNF4lYgo $DwGmR) : void
    {
        goto loED8;
        gJAsQ:
        $NDV21 = $D_Z4Z->getVideoStream();
        goto UeDeU;
        lpfx8:
        $D_Z4Z = FFMpeg::fromDisk($vVh3J['path'])->open($DwGmR->getAttribute('filename'));
        goto gJAsQ;
        UeDeU:
        $ct2Tt = $NDV21->getDimensions();
        goto Exkjp;
        loED8:
        $vVh3J = $DwGmR->getView();
        goto lpfx8;
        Exkjp:
        $DwGmR->update(['duration' => $D_Z4Z->getDurationInSeconds(), 'resolution' => $ct2Tt->getWidth() . 'x' . $ct2Tt->getHeight(), 'fps' => $NDV21->get('r_frame_rate') ?? 30]);
        goto mkNpu;
        mkNpu:
    }
}
