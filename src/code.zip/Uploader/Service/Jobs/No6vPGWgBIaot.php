<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class No6vPGWgBIaot implements StoreToS3JobInterface
{
    private $R2XXS;
    private $wEVdN;
    private $A8xPF;
    public function __construct($I4Jnv, $dzspH, $ZT237)
    {
        goto l9KMr;
        apk3e:
        $this->R2XXS = $I4Jnv;
        goto XaaQj;
        YcCp4:
        $this->A8xPF = $ZT237;
        goto apk3e;
        l9KMr:
        $this->wEVdN = $dzspH;
        goto YcCp4;
        XaaQj:
    }
    public function store(string $hOWbX) : void
    {
        goto dUuLE;
        cIW_P:
        $this->m486ONmvPwc($D4enG, $Hxtzm->getLocation());
        goto ghjLb;
        DMlCz:
        Log::info("D6FgZi8OHmjic has been deleted, discard it", ['fileId' => $hOWbX]);
        goto w_JTL;
        w_JTL:
        return;
        goto HV03h;
        dUuLE:
        $Hxtzm = D6FgZi8OHmjic::findOrFail($hOWbX);
        goto WAniq;
        Fe1Wb:
        $this->wEVdN->put($Hxtzm->getAttribute('thumbnail'), $this->A8xPF->get($YHRHD), ['visibility' => 'public', 'ContentType' => $N07Z2->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto gBxdh;
        p9q6g:
        Jj7jt:
        goto kPnx8;
        uJomm:
        $D4enG = $this->A8xPF->path($Hxtzm->getLocation());
        goto cIW_P;
        V6Bm7:
        $this->wEVdN->put($Hxtzm->getAttribute('preview'), $this->A8xPF->get($Hxtzm->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $Llvz5->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Ps8AA;
        Lu90H:
        $N07Z2 = $this->R2XXS->call($this, $IXbv1);
        goto Fe1Wb;
        IDoUx:
        if (!($Hxtzm->getAttribute('preview') && $this->A8xPF->exists($Hxtzm->getAttribute('preview')))) {
            goto kBbtM;
        }
        goto Maw0l;
        gBxdh:
        eiWCG:
        goto IDoUx;
        Ps8AA:
        kBbtM:
        goto I2iIc;
        jsjka:
        if (!($YHRHD && $this->A8xPF->exists($YHRHD))) {
            goto eiWCG;
        }
        goto ELrl6;
        FBDGl:
        $Llvz5 = $this->R2XXS->call($this, $R7aL8);
        goto V6Bm7;
        Maw0l:
        $R7aL8 = $this->A8xPF->path($Hxtzm->getAttribute('preview'));
        goto FBDGl;
        WAniq:
        if ($Hxtzm) {
            goto afRsA;
        }
        goto DMlCz;
        IHbQf:
        return;
        goto p9q6g;
        I2iIc:
        if (!$Hxtzm->update(['driver' => NZ0k4EM0XOGE7::S3, 'status' => T93Mcsw1gA3an::FINISHED])) {
            goto Jj7jt;
        }
        goto XhSFI;
        ghjLb:
        $YHRHD = $Hxtzm->getAttribute('thumbnail');
        goto jsjka;
        ELrl6:
        $IXbv1 = $this->A8xPF->path($YHRHD);
        goto Lu90H;
        el8IN:
        D6FgZi8OHmjic::where('parent_id', $hOWbX)->update(['driver' => NZ0k4EM0XOGE7::S3, 'preview' => $Hxtzm->getAttribute('preview'), 'thumbnail' => $Hxtzm->getAttribute('thumbnail')]);
        goto IHbQf;
        kPnx8:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $hOWbX]);
        goto mccwM;
        HV03h:
        afRsA:
        goto uJomm;
        XhSFI:
        Log::info("D6FgZi8OHmjic stored to S3, update the children attachments", ['fileId' => $hOWbX]);
        goto el8IN;
        mccwM:
    }
    private function m486ONmvPwc($CO8hq, $dQ5jE, $igJ3j = '')
    {
        goto RY1in;
        geylP:
        $dQ5jE = str_replace('.jpg', $igJ3j, $dQ5jE);
        goto VYk6e;
        VYk6e:
        XjP1D:
        goto vPyPM;
        RY1in:
        if (!$igJ3j) {
            goto XjP1D;
        }
        goto aLvl3;
        vPyPM:
        try {
            $h169k = $this->R2XXS->call($this, $CO8hq);
            $this->wEVdN->put($dQ5jE, $this->A8xPF->get($dQ5jE), ['visibility' => 'public', 'ContentType' => $h169k->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $qeKgz) {
            Log::error("Failed to upload image to S3", ['s3Path' => $dQ5jE, 'error' => $qeKgz->getMessage()]);
        }
        goto WRALh;
        aLvl3:
        $CO8hq = str_replace('.jpg', $igJ3j, $CO8hq);
        goto geylP;
        WRALh:
    }
}
