<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
class U0eMlWUJpsRhi implements BlurVideoJobInterface
{
    const nV2uI = 15;
    const Qqf08 = 500;
    const jetsR = 500;
    private $Ie_ZE;
    private $MV0lK;
    private $P2FvH;
    public function __construct($jSZw8, $tYsty, $j8mv9)
    {
        goto T3IDl;
        TsRn6:
        $this->MV0lK = $tYsty;
        goto Mmbv9;
        T3IDl:
        $this->P2FvH = $j8mv9;
        goto TsRn6;
        Mmbv9:
        $this->Ie_ZE = $jSZw8;
        goto upBlr;
        upBlr:
    }
    public function blur(string $FILUb) : void
    {
        goto jPWrc;
        grU_K:
        if (chmod($UrnhP, 0664)) {
            goto KMPGn;
        }
        goto EDvr7;
        dKei4:
        $pTbWI = $this->mwfF58VrEJD($koIlz);
        goto XBn0e;
        MJB3L:
        ini_set('memory_limit', '-1');
        goto OoBNM;
        XBn0e:
        $UrnhP = $this->P2FvH->path($pTbWI);
        goto YOsBN;
        CvlH3:
        KMPGn:
        goto FTk68;
        ax4d7:
        $jG3UU = $FGBix->width() / $FGBix->height();
        goto X1aTa;
        X1aTa:
        $FGBix->resize(self::Qqf08, self::jetsR / $jG3UU);
        goto a9NB3;
        y7nDb:
        throw new \Exception('Failed to set final permissions on image file: ' . $UrnhP);
        goto CvlH3;
        YOsBN:
        $FGBix->save($UrnhP);
        goto ylQ84;
        a9NB3:
        $FGBix->blur(self::nV2uI);
        goto dKei4;
        YEAZ0:
        $FGBix->destroy();
        goto grU_K;
        ylQ84:
        $this->MV0lK->put($pTbWI, $this->P2FvH->get($pTbWI));
        goto YEAZ0;
        Syhi5:
        hF2o4:
        goto uss7e;
        ljRpX:
        $FGBix = $this->Ie_ZE->call($this, $this->P2FvH->path($koIlz->getAttribute('thumbnail')));
        goto ax4d7;
        FTk68:
        $koIlz->update(['preview' => $pTbWI]);
        goto Syhi5;
        jPWrc:
        Log::info("Blurring for video", ['videoID' => $FILUb]);
        goto MJB3L;
        aQGwA:
        $this->P2FvH->put($koIlz->getAttribute('thumbnail'), $this->MV0lK->get($koIlz->getAttribute('thumbnail')));
        goto ljRpX;
        OoBNM:
        $koIlz = CUaMUcjkFHEwK::findOrFail($FILUb);
        goto UdGqM;
        UdGqM:
        if (!$koIlz->getAttribute('thumbnail')) {
            goto hF2o4;
        }
        goto aQGwA;
        EDvr7:
        \Log::warning('Failed to set final permissions on image file: ' . $UrnhP);
        goto y7nDb;
        uss7e:
    }
    private function mwfF58VrEJD(Zvx9VGBGZQ0lD $eh8u9) : string
    {
        goto v8D4U;
        v8D4U:
        $Sblyk = $eh8u9->getLocation();
        goto YkXWz;
        ARvyO:
        BIfli:
        goto SdV6E;
        YkXWz:
        $OhpSE = dirname($Sblyk) . '/preview/';
        goto IUsZP;
        IUsZP:
        if ($this->P2FvH->exists($OhpSE)) {
            goto BIfli;
        }
        goto p2mkv;
        p2mkv:
        $this->P2FvH->makeDirectory($OhpSE, 0755, true);
        goto ARvyO;
        SdV6E:
        return $OhpSE . $eh8u9->getFilename() . '.jpg';
        goto YdtdN;
        YdtdN:
    }
}
