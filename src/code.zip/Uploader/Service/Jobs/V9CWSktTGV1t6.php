<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Encoder\AExjKfXX7gVdb;
use src\Uploader\Encoder\BQuzY5eIHOHbX;
use src\Uploader\Encoder\CqIfz7C8PXyW1;
use src\Uploader\Encoder\JdeFY2cy1uPti;
use src\Uploader\Encoder\QU6PiV2uGCnpt;
use src\Uploader\Encoder\SgVYdb34TZ3jy;
use src\Uploader\Enum\FileDriver;
use src\Uploader\Service\BVykbOopwUKwx;
use src\Uploader\Service\Jobs\K9SMm43XlLmP8;
use src\Uploader\Service\Jobs\TgRlBFpF3yt9a;
use Webmozart\Assert\Assert;
class V9CWSktTGV1t6 implements MediaEncodeJobInterface
{
    private $tVqMs;
    private $SiK3b;
    private $Aj6QZ;
    private $kkvUd;
    private $s28PC;
    public function __construct(string $FQWsT, $eX8wo, $SaekO, $UOGFe, $vimS1)
    {
        goto TjZ4W;
        pkHAP:
        $this->Aj6QZ = $SaekO;
        goto xxjm_;
        TKaYv:
        $this->SiK3b = $eX8wo;
        goto pkHAP;
        TjZ4W:
        $this->tVqMs = $FQWsT;
        goto TKaYv;
        CdWvl:
        $this->s28PC = $vimS1;
        goto uiKIz;
        xxjm_:
        $this->kkvUd = $UOGFe;
        goto CdWvl;
        uiKIz:
    }
    public function encode(string $BFPg9, string $XT0rv, $f5YQ2 = true) : void
    {
        goto eaL87;
        C5V4A:
        try {
            goto C4FIq;
            CjOic:
            AL7R4:
            goto BSdTG;
            HHFoA:
            $w31bN = app(SgVYdb34TZ3jy::class);
            goto X6Cdh;
            MDPN5:
            Assert::isInstanceOf($iit8z, YdClVYDRbSDMR::class);
            goto PsHb9;
            LYN7P:
            A7Tev:
            goto Iwyb0;
            aR0Ej:
            WjLDH:
            goto pLQqG;
            PsHb9:
            if (!($iit8z->WJjcF !== FileDriver::S3)) {
                goto WjLDH;
            }
            goto udDw6;
            aUUuV:
            $w31bN = $w31bN->mTmZr2lBMqg($kEbXw);
            goto H8xh7;
            m6p2O:
            $iit8z->update(['aws_media_converter_job_id' => $BFPg9]);
            goto A1XKE;
            E60IW:
            $CZ9S0 = $this->mt54bizr7JN($Lu5LP, $IPfYY);
            goto yRUCB;
            C4FIq:
            $iit8z = YdClVYDRbSDMR::findOrFail($BFPg9);
            goto MDPN5;
            FLifB:
            $gX39q = $this->m7KrvrBBnt6($YotoQ, $ZVrUd->m8dbiOiHCTI((int) $CZ9S0['width'], (int) $CZ9S0['height'], $XT0rv));
            goto axTNU;
            nDIZo:
            $ZVrUd = new TgRlBFpF3yt9a($this->kkvUd, $this->s28PC, $this->Aj6QZ, $this->SiK3b);
            goto hwYG6;
            rSry0:
            $yGBHp = new BQuzY5eIHOHbX('original', $Lu5LP, $IPfYY, $iit8z->TKziK ?? 30);
            goto tV1UB;
            uEbpV:
            $w31bN->mTmZr2lBMqg($yGBHp);
            goto gBCl7;
            hwYG6:
            $gX39q = $this->m7KrvrBBnt6($YotoQ, $ZVrUd->m8dbiOiHCTI($iit8z->width(), $iit8z->height(), $XT0rv));
            goto I0Vtr;
            tMUBF:
            $BFPg9 = $w31bN->m4DyYMqBQ5p($this->msUyzulx2iZ($iit8z, $f5YQ2));
            goto m6p2O;
            LjcNT:
            Log::info("Set input video for Job", ['s3Uri' => $OX3hT]);
            goto HHFoA;
            rjCah:
            VOTqJ:
            goto aUUuV;
            PrnYP:
            if (!($Lu5LP && $IPfYY)) {
                goto AL7R4;
            }
            goto BRejJ;
            BRejJ:
            if (!$this->myKsRmcMnVp($Lu5LP, $IPfYY)) {
                goto Ms_OB;
            }
            goto E60IW;
            vTUXD:
            $pIzqs = new QU6PiV2uGCnpt($iit8z->cQ3nO ?? 1, 2, $oKNB_->mHVNClNLBpr($iit8z));
            goto qmzWC;
            Iwyb0:
            $w31bN->mTmZr2lBMqg($yGBHp);
            goto Ca5un;
            ZmVJM:
            $YotoQ = app(BVykbOopwUKwx::class);
            goto nDIZo;
            H8xh7:
            Ms_OB:
            goto CjOic;
            pLQqG:
            $Lu5LP = $iit8z->width();
            goto ThnhW;
            zDkwH:
            $OX3hT = $this->mPD7CEbQWGG($iit8z);
            goto LjcNT;
            AhbmN:
            $kEbXw = new BQuzY5eIHOHbX('1080p', $CZ9S0['width'], $CZ9S0['height'], $iit8z->TKziK ?? 30);
            goto FLifB;
            I0Vtr:
            if (!$gX39q) {
                goto A7Tev;
            }
            goto QXFYE;
            yRUCB:
            Log::info("Set 1080p resolution for Job", ['width' => $CZ9S0['width'], 'height' => $CZ9S0['height'], 'originalWidth' => $Lu5LP, 'originalHeight' => $IPfYY]);
            goto AhbmN;
            tV1UB:
            $oKNB_ = app(CqIfz7C8PXyW1::class);
            goto uEbpV;
            fIWY7:
            $kEbXw = $kEbXw->mMuJO5lV3Wn($gX39q);
            goto rjCah;
            ThnhW:
            $IPfYY = $iit8z->height();
            goto zDkwH;
            gBCl7:
            $w31bN->m8vMoQIGcbD($oKNB_->mNVm7oEvEEI($iit8z));
            goto ZmVJM;
            qmzWC:
            $w31bN = $w31bN->mQbBDmkQoiu($pIzqs);
            goto tMUBF;
            X6Cdh:
            $w31bN = $w31bN->me7cxy8aDVL(new AExjKfXX7gVdb($OX3hT));
            goto rSry0;
            BSdTG:
            Log::info("Set thumbnail for YdClVYDRbSDMR Job", ['videoId' => $iit8z->getAttribute('id'), 'duration' => $iit8z->getAttribute('duration')]);
            goto vTUXD;
            QXFYE:
            $yGBHp = $yGBHp->mMuJO5lV3Wn($gX39q);
            goto LYN7P;
            axTNU:
            if (!$gX39q) {
                goto VOTqJ;
            }
            goto fIWY7;
            Ca5un:
            $w31bN->m8vMoQIGcbD($oKNB_->mNVm7oEvEEI($iit8z));
            goto PrnYP;
            udDw6:
            throw new MediaConverterException("YdClVYDRbSDMR {$iit8z->id} is not S3 driver");
            goto aR0Ej;
            A1XKE:
        } catch (\Exception $lrm5K) {
            Log::info("YdClVYDRbSDMR has been deleted, discard it", ['fileId' => $BFPg9, 'err' => $lrm5K->getMessage()]);
            return;
        }
        goto R5Dtc;
        PqgHi:
        ini_set('memory_limit', '-1');
        goto C5V4A;
        eaL87:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $BFPg9]);
        goto PqgHi;
        R5Dtc:
    }
    private function msUyzulx2iZ(YdClVYDRbSDMR $iit8z, $f5YQ2) : bool
    {
        goto fmYbz;
        DAM0z:
        return false;
        goto E5X9q;
        fmYbz:
        if ($f5YQ2) {
            goto uSV_P;
        }
        goto DAM0z;
        nszjK:
        $Itp2n = (int) round($iit8z->getAttribute('duration') ?? 0);
        goto u1OhA;
        u1OhA:
        switch (true) {
            case $iit8z->width() * $iit8z->height() >= 1920 * 1080 && $iit8z->width() * $iit8z->height() < 2560 * 1440:
                return $Itp2n > 10 * 60;
            case $iit8z->width() * $iit8z->height() >= 2560 * 1440 && $iit8z->width() * $iit8z->height() < 3840 * 2160:
                return $Itp2n > 5 * 60;
            case $iit8z->width() * $iit8z->height() >= 3840 * 2160:
                return $Itp2n > 3 * 60;
            default:
                return false;
        }
        goto cqWg9;
        E5X9q:
        uSV_P:
        goto nszjK;
        J2jVr:
        EF0Ww:
        goto JNTnG;
        cqWg9:
        MelZr:
        goto J2jVr;
        JNTnG:
    }
    private function m7KrvrBBnt6(BVykbOopwUKwx $YotoQ, string $lKtRX) : ?JdeFY2cy1uPti
    {
        goto LxHXC;
        Ynj9o:
        return null;
        goto qGb24;
        FuPwv:
        Log::info("Resolve watermark for job with url", ['url' => $lKtRX, 'uri' => $PU7WO]);
        goto h2o9C;
        h2o9C:
        if (!$PU7WO) {
            goto FNMsp;
        }
        goto eZWaE;
        eZWaE:
        return new JdeFY2cy1uPti($PU7WO, 0, 0, null, null);
        goto I4qAK;
        LxHXC:
        $PU7WO = $YotoQ->mZtEu4MfD0R($lKtRX);
        goto FuPwv;
        I4qAK:
        FNMsp:
        goto Ynj9o;
        qGb24:
    }
    private function myKsRmcMnVp(int $Lu5LP, int $IPfYY) : bool
    {
        return $Lu5LP * $IPfYY > 1.5 * (1920 * 1080);
    }
    private function mt54bizr7JN(int $Lu5LP, int $IPfYY) : array
    {
        $ybxrZ = new K9SMm43XlLmP8($Lu5LP, $IPfYY);
        return $ybxrZ->mWhdXrMgyzn();
    }
    private function mPD7CEbQWGG(TvpGfrAj9WMXE $jVT23) : string
    {
        goto Ebd_V;
        mNQ8_:
        return $this->SiK3b->url($jVT23->filename);
        goto GkK_y;
        Ebd_V:
        if (!($jVT23->WJjcF == FileDriver::S3)) {
            goto i2L1C;
        }
        goto Noz9Y;
        l0tZe:
        i2L1C:
        goto mNQ8_;
        Noz9Y:
        return 's3://' . $this->tVqMs . '/' . $jVT23->filename;
        goto l0tZe;
        GkK_y:
    }
}
