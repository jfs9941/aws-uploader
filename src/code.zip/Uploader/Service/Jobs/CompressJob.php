<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Image;


class CompressJob implements CompressJobInterface
{
    const COMPRESS_RATIO = 80;

    /** @var \Closure */
    private $maker;
    private $localDisk;
    public function __construct($maker, $localDisk)
    {
        $this->maker = $maker;
        $this->localDisk = $localDisk;
    }

    public function compress(string $id)
    {
        Log::info("Compress image", ['imageId' => $id]);
        try {
            $image = Image::findOrFail($id);
            $oldPath = $this->localDisk->path($image->getLocation());
            if ($image->getExtension() === 'png') {
                // change png to jpg
                $image->setAttribute('type','jpg');
                $image->setAttribute('filename', str_replace('.png', '.jpg', $image->getLocation()));
                $image->save();
            }

            $newPath = $this->localDisk->path($image->getLocation());
            $jpgImage = $this->maker->call($this, $oldPath);
            $jpgImage->orientate();
            $jpgImage->save($newPath, self::COMPRESS_RATIO);
            $jpgImage->destroy();
        }catch (ModelNotFoundException) {
            Log::info("Image has been deleted, discard it", ['imageId' => $id]);
        }
    }
}
