<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Illuminate\Support\Facades\Log;
class EH8WJRdSgiB4s implements BlurVideoJobInterface
{
    const t_7Fw = 15;
    const YWeMK = 500;
    const dgUo2 = 500;
    private $z0km_;
    private $zbU8n;
    private $ofZvx;
    public function __construct($BSNlm, $Efy84, $suNmN)
    {
        goto yRJCc;
        yRJCc:
        $this->ofZvx = $suNmN;
        goto BHs1d;
        BHs1d:
        $this->zbU8n = $Efy84;
        goto LP3iB;
        LP3iB:
        $this->z0km_ = $BSNlm;
        goto zK3gA;
        zK3gA:
    }
    public function blur(string $N2oAf) : void
    {
        goto Btw5r;
        kLgki:
        $RxSHk->blur(self::t_7Fw);
        goto v72UN;
        XTTDy:
        ini_set('memory_limit', '-1');
        goto K5NO5;
        XL_oG:
        unset($RxSHk);
        goto HFjUY;
        Btw5r:
        Log::info("Blurring for video", ['videoID' => $N2oAf]);
        goto XTTDy;
        NXVYl:
        $qelwB = $this->ofZvx->path($M3UnW);
        goto ymJVS;
        puURz:
        throw new \Exception('Failed to set final permissions on image file: ' . $qelwB);
        goto qSCcq;
        ehP3D:
        if (!$OYyKR->getAttribute('thumbnail')) {
            goto SjBV6;
        }
        goto rs97V;
        yBaXH:
        $this->zbU8n->put($M3UnW, $this->ofZvx->get($M3UnW));
        goto XL_oG;
        Hi1cH:
        $RxSHk = $this->z0km_->call($this, $this->ofZvx->path($OYyKR->getAttribute('thumbnail')));
        goto QMiJ5;
        K5NO5:
        $OYyKR = VPegVN4NByLqJ::findOrFail($N2oAf);
        goto ehP3D;
        v72UN:
        $M3UnW = $this->ml6PXtGY4oU($OYyKR);
        goto NXVYl;
        KYXNq:
        SjBV6:
        goto Q3v_F;
        HFjUY:
        if (chmod($qelwB, 0664)) {
            goto uXE8t;
        }
        goto s8Sqc;
        OuZl1:
        $OYyKR->update(['preview' => $M3UnW]);
        goto KYXNq;
        QMiJ5:
        $yzNoO = $RxSHk->width() / $RxSHk->height();
        goto JPoBS;
        s8Sqc:
        \Log::warning('Failed to set final permissions on image file: ' . $qelwB);
        goto puURz;
        rs97V:
        $this->ofZvx->put($OYyKR->getAttribute('thumbnail'), $this->zbU8n->get($OYyKR->getAttribute('thumbnail')));
        goto Hi1cH;
        ymJVS:
        $RxSHk->save($qelwB);
        goto yBaXH;
        JPoBS:
        $RxSHk->resize(self::YWeMK, self::dgUo2 / $yzNoO);
        goto kLgki;
        qSCcq:
        uXE8t:
        goto OuZl1;
        Q3v_F:
    }
    private function ml6PXtGY4oU(MxslGSmH9dMgZ $OagJi) : string
    {
        goto H7lK5;
        LGSKq:
        return $TQLOY . $OagJi->getFilename() . '.jpg';
        goto K4j6U;
        sRC3v:
        HuBDX:
        goto LGSKq;
        mYT31:
        $this->ofZvx->makeDirectory($TQLOY, 0755, true);
        goto sRC3v;
        H7lK5:
        $vRakW = $OagJi->getLocation();
        goto Ep1j1;
        Ep1j1:
        $TQLOY = dirname($vRakW) . '/preview/';
        goto MS_3m;
        MS_3m:
        if ($this->ofZvx->exists($TQLOY)) {
            goto HuBDX;
        }
        goto mYT31;
        K4j6U:
    }
}
