<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
class RiKa0AFj1NpUc implements BlurJobInterface
{
    const zhNzV = 15;
    const DJPIp = 500;
    const adkDy = 500;
    private $IfECA;
    private $zTo0t;
    private $uBhrQ;
    public function __construct($AaIEl, $Vi8xq, $Ms6sq)
    {
        goto wmFtg;
        wmFtg:
        $this->uBhrQ = $Ms6sq;
        goto h10EK;
        d7_aO:
        $this->IfECA = $AaIEl;
        goto hnE0C;
        h10EK:
        $this->zTo0t = $Vi8xq;
        goto d7_aO;
        hnE0C:
    }
    public function blur(string $S6xyJ) : void
    {
        goto x7LwR;
        CUC5q:
        $iy9bs->destroy();
        goto uBnbn;
        BR6Dm:
        $iy9bs = $this->IfECA->call($this, $this->uBhrQ->path($cRLb2->getLocation()));
        goto EbDlD;
        WzU43:
        if (!($cRLb2->n5TQN == Rc6MZhMMdyG6A::S3 && !$this->uBhrQ->exists($cRLb2->filename))) {
            goto U6Ypv;
        }
        goto tH5iN;
        tH5iN:
        $GuO90 = $this->zTo0t->get($cRLb2->filename);
        goto ZTqqD;
        Oc662:
        $cRLb2->update(['preview' => $NzFkF]);
        goto WOffB;
        x7LwR:
        $cRLb2 = JyZaxpharsbun::findOrFail($S6xyJ);
        goto wqUnN;
        EbDlD:
        $Xb5Jr = $iy9bs->width() / $iy9bs->height();
        goto r7tzf;
        kstzW:
        $iy9bs->save($y9ek3);
        goto CUC5q;
        uBnbn:
        if (chmod($y9ek3, 0664)) {
            goto FVlxg;
        }
        goto t3eQS;
        t3eQS:
        \Log::warning('Failed to set final permissions on image file: ' . $y9ek3);
        goto Ffzcv;
        Ffzcv:
        throw new \Exception('Failed to set final permissions on image file: ' . $y9ek3);
        goto i31j0;
        r314P:
        $iy9bs->blur(self::zhNzV);
        goto eXRry;
        eXRry:
        $NzFkF = $this->mnofwe5vgIs($cRLb2);
        goto sy95k;
        sy95k:
        $y9ek3 = $this->uBhrQ->path($NzFkF);
        goto kstzW;
        wqUnN:
        ini_set('memory_limit', '-1');
        goto WzU43;
        i31j0:
        FVlxg:
        goto Oc662;
        ZTqqD:
        $this->uBhrQ->put($cRLb2->filename, $GuO90);
        goto szViI;
        r7tzf:
        $iy9bs->resize(self::DJPIp, self::adkDy / $Xb5Jr);
        goto r314P;
        szViI:
        U6Ypv:
        goto BR6Dm;
        WOffB:
    }
    private function mnofwe5vgIs($ECCgN) : string
    {
        goto dM8lF;
        dM8lF:
        $z69yI = $ECCgN->getLocation();
        goto W4pST;
        W4pST:
        $sSGQz = dirname($z69yI) . '/preview/';
        goto nKPQJ;
        ev4Jl:
        KNLVh:
        goto YjOGP;
        ZmypS:
        $this->uBhrQ->makeDirectory($sSGQz, 0755, true);
        goto ev4Jl;
        nKPQJ:
        if ($this->uBhrQ->exists($sSGQz)) {
            goto KNLVh;
        }
        goto ZmypS;
        YjOGP:
        return $sSGQz . $ECCgN->getFilename() . '.jpg';
        goto wqglf;
        wqglf:
    }
}
