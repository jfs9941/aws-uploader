<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Encoder\Q74VPxpLowiUP;
use Jfs\Uploader\Encoder\Zh4SBX5I0vF4X;
use Jfs\Uploader\Encoder\AhS2r9oThLsk4;
use Jfs\Uploader\Encoder\HaSCsbBEdqDr7;
use Jfs\Uploader\Encoder\OD4qD4m00G9FN;
use Jfs\Uploader\Encoder\OwFt4j2nadux5;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Jfs\Uploader\Service\Jobs\UvnGzrfudDGBa;
use Jfs\Uploader\Service\Jobs\DSUHtpZvOZQCp;
use Jfs\Uploader\Service\CU3MKrDqwc6OY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class B1PYBuYszNkz7 implements MediaEncodeJobInterface
{
    private $n_TUX;
    private $gcP3F;
    private $D9Jo8;
    private $QI7yZ;
    private $fyPpL;
    public function __construct(string $EwO1g, $qxxOf, $v1Edp, $EAMKc, $UJQDg)
    {
        goto TlZKs;
        TlZKs:
        $this->n_TUX = $EwO1g;
        goto D5QPg;
        DEL4F:
        $this->D9Jo8 = $v1Edp;
        goto altDo;
        D5QPg:
        $this->gcP3F = $qxxOf;
        goto DEL4F;
        altDo:
        $this->QI7yZ = $EAMKc;
        goto FfCN0;
        FfCN0:
        $this->fyPpL = $UJQDg;
        goto LPwdd;
        LPwdd:
    }
    public function encode(string $poSkG, string $R5z2N, $pwEfv = true) : void
    {
        goto FpVKV;
        z8MBc:
        ini_set('memory_limit', '-1');
        goto Z1Pwe;
        FpVKV:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $poSkG]);
        goto z8MBc;
        Z1Pwe:
        try {
            goto uf_Tj;
            QHTgY:
            $rfhYJ = $qNHE7->height();
            goto D6JbS;
            e0_tQ:
            bCe5b:
            goto gCdIN;
            D6JbS:
            $XEUXS = $this->mz5B94lMFzq($qNHE7);
            goto LY6S5;
            RBR8_:
            $gWJqy = app(OD4qD4m00G9FN::class);
            goto ixQob;
            lHTMG:
            um0W6:
            goto GvXv1;
            oMCDf:
            if (!($qNHE7->driver != L2PWLPeQEFi6U::S3)) {
                goto ikJw4;
            }
            goto fyqo0;
            VRhEg:
            $MpCza = $qNHE7->width();
            goto QHTgY;
            LOu9y:
            if (!$this->mwteJOCPk8N($MpCza, $rfhYJ)) {
                goto oU77s;
            }
            goto vkX5R;
            Nb3MM:
            $oiRO1 = app(CU3MKrDqwc6OY::class);
            goto EiiRL;
            SfevO:
            if (!$qNHE7->getAttribute('aws_media_converter_job_id')) {
                goto G79Vi;
            }
            goto QpnhM;
            gqVj6:
            $Cigj3 = new Zh4SBX5I0vF4X('1080p', $f_VCM['width'], $f_VCM['height'], $qNHE7->YCQka ?? 30);
            goto nU3RN;
            yxzzQ:
            Assert::isInstanceOf($qNHE7, ISYJHQo8eqdfc::class);
            goto oMCDf;
            uf_Tj:
            $qNHE7 = ISYJHQo8eqdfc::findOrFail($poSkG);
            goto yxzzQ;
            vkX5R:
            $f_VCM = $this->mBDf3LYd81T($MpCza, $rfhYJ);
            goto OmIlB;
            ixQob:
            $gWJqy = $gWJqy->mIMmKaN0Oll(new HaSCsbBEdqDr7($XEUXS));
            goto kavjQ;
            gCdIN:
            $gWJqy = $gWJqy->mtjS3i8AWRq($Cigj3);
            goto HZfoN;
            FTLYe:
            G79Vi:
            goto VRhEg;
            OmIlB:
            Log::info("Set 1080p resolution for Job", ['width' => $f_VCM['width'], 'height' => $f_VCM['height'], 'originalWidth' => $MpCza, 'originalHeight' => $rfhYJ]);
            goto gqVj6;
            h9aI2:
            if (!$W5ArP) {
                goto bCe5b;
            }
            goto kQXsQ;
            FUQ2Q:
            if (!($MpCza && $rfhYJ)) {
                goto Kb2C0;
            }
            goto LOu9y;
            aJgTg:
            $poSkG = $gWJqy->mn1CtQHvEKh($this->mRti5KsOUFk($qNHE7, $pwEfv));
            goto G8Rtq;
            UNzVS:
            $eeT1E = new Q74VPxpLowiUP($qNHE7->getAttribute('duration') ?? 1, 2, $R1OF9->mL1Nb25uvEM($qNHE7));
            goto h10n8;
            utd8o:
            $gWJqy->mIeqICNq8Ll($R1OF9->mTCOc1txqmE($qNHE7));
            goto FUQ2Q;
            qQZQt:
            $gWJqy->mIeqICNq8Ll($R1OF9->mTCOc1txqmE($qNHE7));
            goto Nb3MM;
            MBgtX:
            Kb2C0:
            goto qeiog;
            nU3RN:
            $W5ArP = $this->mvoMI7OVmkH($oiRO1, $SDn34->mrTKCqwq0WU((int) $f_VCM['width'], (int) $f_VCM['height'], $R5z2N));
            goto h9aI2;
            G8Rtq:
            $qNHE7->update(['aws_media_converter_job_id' => $poSkG]);
            goto MTikk;
            SwuSg:
            $W5ArP = $this->mvoMI7OVmkH($oiRO1, $SDn34->mrTKCqwq0WU($qNHE7->width(), $qNHE7->height(), $R5z2N));
            goto mfyJg;
            HZfoN:
            oU77s:
            goto MBgtX;
            kavjQ:
            $yQI0K = new Zh4SBX5I0vF4X('original', $MpCza, $rfhYJ, $qNHE7->YCQka ?? 30);
            goto lfbY_;
            GvXv1:
            $gWJqy->mtjS3i8AWRq($yQI0K);
            goto utd8o;
            v8J1k:
            ikJw4:
            goto SfevO;
            QpnhM:
            Log::info("ISYJHQo8eqdfc already has Media Converter Job ID, skip encoding", ['fileId' => $poSkG, 'jobId' => $qNHE7->getAttribute('aws_media_converter_job_id')]);
            goto MgwT9;
            EiiRL:
            $SDn34 = new DSUHtpZvOZQCp($this->QI7yZ, $this->fyPpL, $this->D9Jo8, $this->gcP3F);
            goto SwuSg;
            lfbY_:
            $R1OF9 = app(AhS2r9oThLsk4::class);
            goto qQZQt;
            qeiog:
            Log::info("Set thumbnail for ISYJHQo8eqdfc Job", ['videoId' => $qNHE7->getAttribute('id'), 'duration' => $qNHE7->getAttribute('duration')]);
            goto UNzVS;
            fyqo0:
            throw new MediaConverterException("ISYJHQo8eqdfc {$qNHE7->id} is not S3 driver value = {$qNHE7->driver}");
            goto v8J1k;
            h10n8:
            $gWJqy = $gWJqy->mFt72TyHC7G($eeT1E);
            goto aJgTg;
            LY6S5:
            Log::info("Set input video for Job", ['s3Uri' => $XEUXS]);
            goto RBR8_;
            kQXsQ:
            $Cigj3 = $Cigj3->myYujxwf2K1($W5ArP);
            goto e0_tQ;
            MgwT9:
            return;
            goto FTLYe;
            mfyJg:
            if (!$W5ArP) {
                goto um0W6;
            }
            goto cT1km;
            cT1km:
            $yQI0K = $yQI0K->myYujxwf2K1($W5ArP);
            goto lHTMG;
            MTikk:
        } catch (\Exception $R1uEk) {
            goto K6P7l;
            Nde89:
            return;
            goto o6ssN;
            pKLHw:
            Sentry::captureException($R1uEk);
            goto Nde89;
            K6P7l:
            Log::warning("ISYJHQo8eqdfc has been deleted, discard it", ['fileId' => $poSkG, 'err' => $R1uEk->getMessage()]);
            goto pKLHw;
            o6ssN:
        }
        goto ANF7n;
        ANF7n:
    }
    private function mRti5KsOUFk(ISYJHQo8eqdfc $qNHE7, $pwEfv) : bool
    {
        goto Qg3h4;
        j1Fxb:
        Po31R:
        goto BdDr5;
        XFHtu:
        return false;
        goto iaQaX;
        P3Dc0:
        $uylfg = (int) round($qNHE7->getAttribute('duration') ?? 0);
        goto n3mdY;
        iaQaX:
        XqfFy:
        goto P3Dc0;
        Qg3h4:
        if ($pwEfv) {
            goto XqfFy;
        }
        goto XFHtu;
        BdDr5:
        V1_pN:
        goto snCNt;
        n3mdY:
        switch (true) {
            case $qNHE7->width() * $qNHE7->height() >= 1920 * 1080 && $qNHE7->width() * $qNHE7->height() < 2560 * 1440:
                return $uylfg > 30 * 60;
            case $qNHE7->width() * $qNHE7->height() >= 2560 * 1440 && $qNHE7->width() * $qNHE7->height() < 3840 * 2160:
                return $uylfg > 15 * 60;
            case $qNHE7->width() * $qNHE7->height() >= 3840 * 2160:
                return $uylfg > 10 * 60;
            default:
                return false;
        }
        goto j1Fxb;
        snCNt:
    }
    private function mvoMI7OVmkH(CU3MKrDqwc6OY $oiRO1, string $Y_JtS) : ?OwFt4j2nadux5
    {
        goto XhWa4;
        c_AEr:
        return null;
        goto zTws4;
        BL5Nw:
        Log::info("Resolve watermark for job with url", ['url' => $Y_JtS, 'uri' => $eAVoa]);
        goto IHiye;
        rMqJi:
        return new OwFt4j2nadux5($eAVoa, 0, 0, null, null);
        goto u3zsg;
        u3zsg:
        xHOhH:
        goto c_AEr;
        IHiye:
        if (!$eAVoa) {
            goto xHOhH;
        }
        goto rMqJi;
        XhWa4:
        $eAVoa = $oiRO1->mTB7a9Zz2c9($Y_JtS);
        goto BL5Nw;
        zTws4:
    }
    private function mwteJOCPk8N(int $MpCza, int $rfhYJ) : bool
    {
        return $MpCza * $rfhYJ > 1.5 * (1920 * 1080);
    }
    private function mBDf3LYd81T(int $MpCza, int $rfhYJ) : array
    {
        $ilVSn = new UvnGzrfudDGBa($MpCza, $rfhYJ);
        return $ilVSn->m2kzsSbz7UN();
    }
    private function mz5B94lMFzq(HtHJXf7xellNX $I6_Gg) : string
    {
        goto jATF8;
        n3b5q:
        return 's3://' . $this->n_TUX . '/' . $I6_Gg->filename;
        goto LqDz0;
        jATF8:
        if (!($I6_Gg->driver == L2PWLPeQEFi6U::S3)) {
            goto kuXEU;
        }
        goto n3b5q;
        o2SfL:
        return $this->gcP3F->url($I6_Gg->filename);
        goto a2sH0;
        LqDz0:
        kuXEU:
        goto o2SfL;
        a2sH0:
    }
}
