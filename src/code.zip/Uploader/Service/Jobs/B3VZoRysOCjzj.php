<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
class B3VZoRysOCjzj implements DownloadToLocalJobInterface
{
    private $W_Kti;
    private $kxBLk;
    public function __construct($agzKA, $dgfeu)
    {
        $this->W_Kti = $agzKA;
        $this->kxBLk = $dgfeu;
    }
    public function download(string $y06DH) : void
    {
        goto Oogwb;
        hIow3:
        $this->kxBLk->put($a3XOL->getLocation(), $this->W_Kti->get($a3XOL->getLocation()));
        goto cP2mT;
        jC1f3:
        Log::info("Start download file to local", ['fileId' => $y06DH, 'filename' => $a3XOL->getLocation()]);
        goto VB6Qs;
        Usysz:
        gN4nu:
        goto hIow3;
        VB6Qs:
        if (!$this->kxBLk->exists($a3XOL->getLocation())) {
            goto gN4nu;
        }
        goto sB8wG;
        Oogwb:
        $a3XOL = LGMw063tEE9ZC::findOrFail($y06DH);
        goto jC1f3;
        sB8wG:
        return;
        goto Usysz;
        cP2mT:
    }
}
