<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Encoder\NWhFJkPi8Y0U6;
use Jfs\Uploader\Encoder\CJuIUkGtE4HG1;
use Jfs\Uploader\Encoder\Koi3akneKfkiI;
use Jfs\Uploader\Encoder\BKbHXXW0iqsEB;
use Jfs\Uploader\Encoder\HmpcWz3K8TIAu;
use Jfs\Uploader\Encoder\OPZz6Z7tAZhju;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
use Jfs\Uploader\Service\VmrgwQFNELOFc;
use Webmozart\Assert\Assert;
class KKtNW0DDPuezX implements MediaEncodeJobInterface
{
    private $zzcfY;
    private $Hf14x;
    private $MV0lK;
    private $ZBBMD;
    private $TJ3cV;
    public function __construct(string $UYSBS, $p1fCH, $tYsty, $v9tnd, $EYZKC)
    {
        goto dTwEd;
        dTwEd:
        $this->zzcfY = $UYSBS;
        goto yUbvv;
        yUbvv:
        $this->Hf14x = $p1fCH;
        goto fOSV0;
        gCZ3G:
        $this->TJ3cV = $EYZKC;
        goto vT11U;
        fOSV0:
        $this->MV0lK = $tYsty;
        goto viB3y;
        viB3y:
        $this->ZBBMD = $v9tnd;
        goto gCZ3G;
        vT11U:
    }
    public function encode(string $FILUb, string $u46de, $qB8vF = true) : void
    {
        goto FOXKf;
        FOXKf:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $FILUb]);
        goto k2ytB;
        k2ytB:
        ini_set('memory_limit', '-1');
        goto wBMlO;
        wBMlO:
        try {
            goto ZdgDz;
            jZ86E:
            $PaniD = app(HmpcWz3K8TIAu::class);
            goto ndp3V;
            L0VUT:
            $UXPaX = $this->maxlI0SDy4l($Geai1, $re4IV->myRCF2se27f((int) $lVN48['width'], (int) $lVN48['height'], $u46de));
            goto UwPlk;
            ZTe_G:
            $PaniD->mvEDWFBHMn1($oNkwX->moK51muoy5X($zef_R));
            goto ph8uu;
            NvO9B:
            $pcXxs = $pcXxs->mQUHBkTzejk($UXPaX);
            goto ci1Xz;
            a3D84:
            $oNkwX = app(Koi3akneKfkiI::class);
            goto tE7vJ;
            UwPlk:
            if (!$UXPaX) {
                goto iSmRw;
            }
            goto UZ0Yi;
            ndp3V:
            $PaniD = $PaniD->myP0aYppr7E(new BKbHXXW0iqsEB($JQ3YA));
            goto BIZ2f;
            ph8uu:
            $Geai1 = app(VmrgwQFNELOFc::class);
            goto xlBxb;
            k_aYJ:
            Log::info("Set 1080p resolution for Job", ['width' => $lVN48['width'], 'height' => $lVN48['height'], 'originalWidth' => $xjnOB, 'originalHeight' => $I9Wph]);
            goto GCRU6;
            wFxr2:
            $PaniD->mvEDWFBHMn1($oNkwX->moK51muoy5X($zef_R));
            goto rxjmT;
            GCRU6:
            $Fv0Jj = new CJuIUkGtE4HG1('1080p', $lVN48['width'], $lVN48['height'], $zef_R->T7YIh ?? 30);
            goto L0VUT;
            sVOq1:
            $xjnOB = $zef_R->width();
            goto VSXHN;
            aCsp9:
            if (!($zef_R->tl1PH !== N0ISad2bKF2Yp::S3)) {
                goto tyO1m;
            }
            goto ceaI1;
            e1sTc:
            if (!$UXPaX) {
                goto txgAU;
            }
            goto NvO9B;
            lb7WQ:
            Assert::isInstanceOf($zef_R, CUaMUcjkFHEwK::class);
            goto aCsp9;
            VSXHN:
            $I9Wph = $zef_R->height();
            goto Vd8_B;
            I_Kg0:
            $E2RLT = new NWhFJkPi8Y0U6($zef_R->jUceY ?? 1, 2, $oNkwX->mLV8PR6HxsX($zef_R));
            goto VLbZs;
            rxjmT:
            if (!($xjnOB && $I9Wph)) {
                goto EFLPh;
            }
            goto rXv4F;
            Vd8_B:
            $JQ3YA = $this->m5oGWtlQvEX($zef_R);
            goto hgt3J;
            WGLnO:
            $PaniD->mhNAjPH5TVt($pcXxs);
            goto wFxr2;
            ZdgDz:
            $zef_R = CUaMUcjkFHEwK::findOrFail($FILUb);
            goto lb7WQ;
            ueka3:
            zX7OZ:
            goto mkC0k;
            zpyLI:
            Log::info("Set thumbnail for CUaMUcjkFHEwK Job", ['videoId' => $zef_R->getAttribute('id'), 'duration' => $zef_R->getAttribute('duration')]);
            goto I_Kg0;
            hgt3J:
            Log::info("Set input video for Job", ['s3Uri' => $JQ3YA]);
            goto jZ86E;
            ceaI1:
            throw new MediaConverterException("CUaMUcjkFHEwK {$zef_R->id} is not S3 driver");
            goto YrQAn;
            b48yQ:
            $PaniD = $PaniD->mhNAjPH5TVt($Fv0Jj);
            goto ueka3;
            xlBxb:
            $re4IV = new O55RFBu3dDBa6($this->ZBBMD, $this->TJ3cV, $this->MV0lK, $this->Hf14x);
            goto oE733;
            ci1Xz:
            txgAU:
            goto WGLnO;
            mkC0k:
            EFLPh:
            goto zpyLI;
            uBxUe:
            $FILUb = $PaniD->mBd9Mmen9ll($this->m82xfmso4z8($zef_R, $qB8vF));
            goto H0Uu2;
            oE733:
            $UXPaX = $this->maxlI0SDy4l($Geai1, $re4IV->myRCF2se27f($zef_R->width(), $zef_R->height(), $u46de));
            goto e1sTc;
            VLbZs:
            $PaniD = $PaniD->mq66qczz7SD($E2RLT);
            goto uBxUe;
            rXv4F:
            if (!$this->mvbG4n9qb4g($xjnOB, $I9Wph)) {
                goto zX7OZ;
            }
            goto JRRlW;
            qL6hO:
            iSmRw:
            goto b48yQ;
            UZ0Yi:
            $Fv0Jj = $Fv0Jj->mQUHBkTzejk($UXPaX);
            goto qL6hO;
            BIZ2f:
            $pcXxs = new CJuIUkGtE4HG1('original', $xjnOB, $I9Wph, $zef_R->T7YIh ?? 30);
            goto a3D84;
            tE7vJ:
            $PaniD->mhNAjPH5TVt($pcXxs);
            goto ZTe_G;
            YrQAn:
            tyO1m:
            goto sVOq1;
            H0Uu2:
            $zef_R->update(['aws_media_converter_job_id' => $FILUb]);
            goto AnN37;
            JRRlW:
            $lVN48 = $this->mAqUZH3LSpF($xjnOB, $I9Wph);
            goto k_aYJ;
            AnN37:
        } catch (\Exception $cy3Ei) {
            Log::info("CUaMUcjkFHEwK has been deleted, discard it", ['fileId' => $FILUb, 'err' => $cy3Ei->getMessage()]);
            return;
        }
        goto pV2qf;
        pV2qf:
    }
    private function m82xfmso4z8(CUaMUcjkFHEwK $zef_R, $qB8vF) : bool
    {
        goto bltcv;
        m3oBZ:
        $wtVeD = (int) round($zef_R->getAttribute('duration') ?? 0);
        goto XqPIi;
        XqPIi:
        switch (true) {
            case $zef_R->width() * $zef_R->height() >= 1920 * 1080 && $zef_R->width() * $zef_R->height() < 2560 * 1440:
                return $wtVeD > 10 * 60;
            case $zef_R->width() * $zef_R->height() >= 2560 * 1440 && $zef_R->width() * $zef_R->height() < 3840 * 2160:
                return $wtVeD > 5 * 60;
            case $zef_R->width() * $zef_R->height() >= 3840 * 2160:
                return $wtVeD > 3 * 60;
            default:
                return false;
        }
        goto vJdpJ;
        bltcv:
        if ($qB8vF) {
            goto P_BVD;
        }
        goto zHIJw;
        ojNcQ:
        P_BVD:
        goto m3oBZ;
        vJdpJ:
        t2N8S:
        goto lUfuc;
        zHIJw:
        return false;
        goto ojNcQ;
        lUfuc:
        cs5V1:
        goto S9ZKc;
        S9ZKc:
    }
    private function maxlI0SDy4l(VmrgwQFNELOFc $Geai1, string $tdBtP) : ?OPZz6Z7tAZhju
    {
        goto KnesW;
        yAUmA:
        if (!$ReGm8) {
            goto UkuBV;
        }
        goto i3Dm3;
        KnesW:
        $ReGm8 = $Geai1->m3Axrl68gEU($tdBtP);
        goto vsYpa;
        PUepm:
        return null;
        goto rxUF0;
        WtbtU:
        UkuBV:
        goto PUepm;
        vsYpa:
        Log::info("Resolve watermark for job with url", ['url' => $tdBtP, 'uri' => $ReGm8]);
        goto yAUmA;
        i3Dm3:
        return new OPZz6Z7tAZhju($ReGm8, 0, 0, null, null);
        goto WtbtU;
        rxUF0:
    }
    private function mvbG4n9qb4g(int $xjnOB, int $I9Wph) : bool
    {
        return $xjnOB * $I9Wph > 1.5 * (1920 * 1080);
    }
    private function mAqUZH3LSpF(int $xjnOB, int $I9Wph) : array
    {
        $N5fqk = new UTUo5H6OMthH9($xjnOB, $I9Wph);
        return $N5fqk->mWLgWbYVD4e();
    }
    private function m5oGWtlQvEX(CZj9PTf9Cv9Eq $dCHQU) : string
    {
        goto QRcpQ;
        HX7ip:
        pIq1F:
        goto siVU2;
        QRcpQ:
        if (!($dCHQU->tl1PH == N0ISad2bKF2Yp::S3)) {
            goto pIq1F;
        }
        goto crqTp;
        crqTp:
        return 's3://' . $this->zzcfY . '/' . $dCHQU->filename;
        goto HX7ip;
        siVU2:
        return $this->Hf14x->url($dCHQU->filename);
        goto zrM2a;
        zrM2a:
    }
}
