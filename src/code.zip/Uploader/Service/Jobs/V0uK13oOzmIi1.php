<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
class V0uK13oOzmIi1 implements BlurJobInterface
{
    const LQaqd = 15;
    const HcR9a = 500;
    const cMOcE = 500;
    private $JG9IT;
    private $huyLW;
    private $Ntit8;
    public function __construct($mLPCZ, $A3hvZ, $MYg0D)
    {
        goto rrrxJ;
        Ds1_S:
        $this->huyLW = $A3hvZ;
        goto DVA6O;
        DVA6O:
        $this->JG9IT = $mLPCZ;
        goto sVVMh;
        rrrxJ:
        $this->Ntit8 = $MYg0D;
        goto Ds1_S;
        sVVMh:
    }
    public function blur(string $arqvy) : void
    {
        goto rRwis;
        k0UrB:
        $yNCAW = $this->huyLW->get($abpQU->filename);
        goto SeGy1;
        CpYr_:
        if (chmod($gxJtw, 0664)) {
            goto X8y6h;
        }
        goto XlFYb;
        jG4SM:
        $abpQU->update(['preview' => $FpaeH]);
        goto T2CWu;
        JYPMF:
        throw new \Exception('Failed to set final permissions on image file: ' . $gxJtw);
        goto enGcL;
        fihV4:
        $mpFph = $uuvVo->width() / $uuvVo->height();
        goto VtHcS;
        enGcL:
        X8y6h:
        goto jG4SM;
        Gm6Mp:
        $FpaeH = $this->mnlfwhv6ERF($abpQU);
        goto ZwcOw;
        MxzEt:
        ini_set('memory_limit', '-1');
        goto xgAYB;
        rRwis:
        $abpQU = S7LEoIprYtLQw::findOrFail($arqvy);
        goto MxzEt;
        VtHcS:
        $uuvVo->resize(self::HcR9a, self::cMOcE / $mpFph);
        goto Z8p5r;
        Rk2_f:
        unset($uuvVo);
        goto CpYr_;
        XlFYb:
        \Log::warning('Failed to set final permissions on image file: ' . $gxJtw);
        goto JYPMF;
        m8icY:
        $uuvVo = $this->JG9IT->call($this, $this->Ntit8->path($abpQU->getLocation()));
        goto fihV4;
        ZwcOw:
        $gxJtw = $this->huyLW->put($FpaeH, $uuvVo->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Rk2_f;
        Z8p5r:
        $uuvVo->blur(self::LQaqd);
        goto Gm6Mp;
        ZFGtK:
        rm0jL:
        goto m8icY;
        SeGy1:
        $this->Ntit8->put($abpQU->filename, $yNCAW);
        goto ZFGtK;
        xgAYB:
        if (!($abpQU->P5ZjQ == Opdj0uZXaMJfa::S3 && !$this->Ntit8->exists($abpQU->filename))) {
            goto rm0jL;
        }
        goto k0UrB;
        T2CWu:
    }
    private function mnlfwhv6ERF($fwqMa) : string
    {
        goto zSK9k;
        ojniz:
        return $gcOdN . $fwqMa->getFilename() . '.jpg';
        goto XLFEx;
        SAafl:
        $gcOdN = dirname($lxbX3) . '/preview/';
        goto e5693;
        zSK9k:
        $lxbX3 = $fwqMa->getLocation();
        goto SAafl;
        UvZst:
        $this->Ntit8->makeDirectory($gcOdN, 0755, true);
        goto htjuO;
        e5693:
        if ($this->Ntit8->exists($gcOdN)) {
            goto ZaWfF;
        }
        goto UvZst;
        htjuO:
        ZaWfF:
        goto ojniz;
        XLFEx:
    }
}
