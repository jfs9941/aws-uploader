<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
class HINeytZSirxpb implements GenerateThumbnailJobInterface
{
    const vdsNB = 150;
    const cNKXz = 150;
    private $KbvBQ;
    private $FFBPk;
    public function __construct($twxgF, $GHkBm)
    {
        $this->KbvBQ = $twxgF;
        $this->FFBPk = $GHkBm;
    }
    public function generate(string $UcmDx)
    {
        goto GHqKl;
        GHqKl:
        Log::info("Generating thumbnail", ['imageId' => $UcmDx]);
        goto RELiy;
        M_ANT:
        try {
            goto RH1St;
            Rup99:
            if (!($Wk8ih !== false)) {
                goto fdUHB;
            }
            goto NLIIt;
            mKcvR:
            throw new \Exception('Failed to set file permissions for stored image: ' . $BptXp);
            goto z21Wo;
            Qa0nR:
            Log::warning('Failed to set file permissions for stored image: ' . $BptXp);
            goto mKcvR;
            lyoAD:
            $eviRR = $this->m6HH5P3T3sI($IS6o1);
            goto Ae76J;
            RH1St:
            $eL8cO = $this->FFBPk;
            goto SBicy;
            cXZWi:
            $BNSmn->fit(150, 150, function ($ybORW) {
                $ybORW->aspectRatio();
            });
            goto YZ7OK;
            bynWE:
            $BNSmn->destroy();
            goto Rup99;
            PABCF:
            fdUHB:
            goto Fj1rR;
            DOa1f:
            $BptXp = $eL8cO->path($eviRR);
            goto N_GBg;
            bTRZD:
            $BNSmn = $this->KbvBQ->call($this, $eL8cO->path($IS6o1->getLocation()));
            goto cXZWi;
            YZ7OK:
            $BNSmn->encode('jpg', 80);
            goto lyoAD;
            Ae76J:
            $Wk8ih = $eL8cO->put($eviRR, $BNSmn->stream(), ['visibility' => 'public']);
            goto bynWE;
            z21Wo:
            UYwsb:
            goto PABCF;
            N_GBg:
            if (chmod($BptXp, 0644)) {
                goto UYwsb;
            }
            goto Qa0nR;
            NLIIt:
            $IS6o1->update(['thumbnail' => $eviRR, 'status' => U8OFutptQGm3S::THUMBNAIL_PROCESSED]);
            goto DOa1f;
            SBicy:
            $IS6o1 = HSe6BNUpJTSwE::findOrFail($UcmDx);
            goto bTRZD;
            Fj1rR:
        } catch (ModelNotFoundException $XCxKc) {
            Log::info("HSe6BNUpJTSwE has been deleted, discard it", ['imageId' => $UcmDx]);
            return;
        }
        goto IlffO;
        RELiy:
        ini_set('memory_limit', '-1');
        goto M_ANT;
        IlffO:
    }
    private function m6HH5P3T3sI(DYGJpbj9Ye8wY $IS6o1) : string
    {
        goto XXs1f;
        XXs1f:
        $eviRR = $IS6o1->getLocation();
        goto tJyui;
        tJyui:
        $cKRb7 = dirname($eviRR);
        goto uqhU2;
        agH5F:
        return $CxUfG . '/' . $IS6o1->getFilename() . '.jpg';
        goto VAPNO;
        uqhU2:
        $CxUfG = $cKRb7 . '/' . self::vdsNB . 'X' . self::cNKXz;
        goto agH5F;
        VAPNO:
    }
}
