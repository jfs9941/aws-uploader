<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\Kl3clWXNabHsa;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Enum\XmcIS8CQn72i3;
class RqOrW03KyLHEH implements Kl3clWXNabHsa
{
    const u_3TH = 15;
    const V8_pe = 500;
    const WjYpe = 500;
    private $W3SEw;
    private $kEfMA;
    private $c35HU;
    public function __construct($DrcMD, $FP6ih, $VHhUy)
    {
        goto WTUa5;
        pjfeH:
        $this->kEfMA = $FP6ih;
        goto SBOi7;
        SBOi7:
        $this->W3SEw = $DrcMD;
        goto kuxEi;
        WTUa5:
        $this->c35HU = $VHhUy;
        goto pjfeH;
        kuxEi:
    }
    public function blur(string $EQQae) : void
    {
        goto L3N_c;
        uAI5s:
        if (chmod($JoxEM, 0664)) {
            goto wRMJp;
        }
        goto dNMSe;
        R4ILI:
        $V3Bmr = $this->kEfMA->get($y42U4->filename);
        goto nIcRY;
        Dx9o7:
        $vHYos = $this->mKEcdzzpsX5($y42U4);
        goto eTHQO;
        b7rnN:
        NzfBP:
        goto Bl75_;
        brVTl:
        $ulojh->blur(self::u_3TH);
        goto Dx9o7;
        uMjyE:
        if (!($y42U4->IykL3 == XmcIS8CQn72i3::S3 && !$this->c35HU->exists($y42U4->filename))) {
            goto NzfBP;
        }
        goto R4ILI;
        eTHQO:
        $JoxEM = $this->kEfMA->put($vHYos, $ulojh->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto HjB2b;
        A5_lo:
        wRMJp:
        goto j_UJP;
        Bl75_:
        $ulojh = $this->W3SEw->call($this, $this->c35HU->path($y42U4->getLocation()));
        goto YjFTK;
        dNMSe:
        \Log::warning('Failed to set final permissions on image file: ' . $JoxEM);
        goto O4_f2;
        j_UJP:
        $y42U4->update(['preview' => $vHYos]);
        goto Aa83c;
        O4_f2:
        throw new \Exception('Failed to set final permissions on image file: ' . $JoxEM);
        goto A5_lo;
        HjB2b:
        unset($ulojh);
        goto uAI5s;
        L3N_c:
        $y42U4 = CrEYqpC23XUGo::findOrFail($EQQae);
        goto SVvO2;
        Ew43d:
        $ulojh->resize(self::V8_pe, self::WjYpe / $EUALP);
        goto brVTl;
        SVvO2:
        ini_set('memory_limit', '-1');
        goto uMjyE;
        YjFTK:
        $EUALP = $ulojh->width() / $ulojh->height();
        goto Ew43d;
        nIcRY:
        $this->c35HU->put($y42U4->filename, $V3Bmr);
        goto b7rnN;
        Aa83c:
    }
    private function mKEcdzzpsX5($Y2tFe) : string
    {
        goto Qkc7N;
        W5M0U:
        return $La3UL . $Y2tFe->getFilename() . '.jpg';
        goto EKQC7;
        Uea3N:
        oOTW9:
        goto W5M0U;
        xtfPE:
        if ($this->c35HU->exists($La3UL)) {
            goto oOTW9;
        }
        goto O0Sd4;
        zG8FA:
        $La3UL = dirname($KPnwr) . '/preview/';
        goto xtfPE;
        O0Sd4:
        $this->c35HU->makeDirectory($La3UL, 0755, true);
        goto Uea3N;
        Qkc7N:
        $KPnwr = $Y2tFe->getLocation();
        goto zG8FA;
        EKQC7:
    }
}
