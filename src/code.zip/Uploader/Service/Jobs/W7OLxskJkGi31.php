<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class W7OLxskJkGi31
{
    private $vSEbD;
    private $RjtXg;
    public function __construct(int $MPue4, int $AgBK9)
    {
        goto K4xPx;
        ZHJr0:
        $this->vSEbD = $MPue4;
        goto xnoD7;
        K4xPx:
        if (!($MPue4 <= 0)) {
            goto QvJG5;
        }
        goto c8aU_;
        ikx8X:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto c7Ix5;
        ea1w1:
        QvJG5:
        goto WVV3W;
        WVV3W:
        if (!($AgBK9 <= 0)) {
            goto veOn6;
        }
        goto ikx8X;
        xnoD7:
        $this->RjtXg = $AgBK9;
        goto JeidI;
        c7Ix5:
        veOn6:
        goto ZHJr0;
        c8aU_:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto ea1w1;
        JeidI:
    }
    private static function mxoSWaox9KJ($B0zGS, string $I1if9 = 'floor') : int
    {
        goto tZif7;
        KT3JF:
        return (int) $B0zGS;
        goto SKlQ3;
        uYKJF:
        tXVkM:
        goto t1gpB;
        tZif7:
        if (!(is_int($B0zGS) && $B0zGS % 2 === 0)) {
            goto J_cXZ;
        }
        goto zYn5J;
        SKlQ3:
        fY1N9:
        goto SGOCs;
        Gf3SB:
        if (!(is_float($B0zGS) && $B0zGS == floor($B0zGS) && (int) $B0zGS % 2 === 0)) {
            goto fY1N9;
        }
        goto KT3JF;
        As8uy:
        KY3IB:
        goto uYKJF;
        tj4xd:
        J_cXZ:
        goto Gf3SB;
        zYn5J:
        return $B0zGS;
        goto tj4xd;
        SGOCs:
        switch (strtolower($I1if9)) {
            case 'ceil':
                return (int) (ceil($B0zGS / 2) * 2);
            case 'round':
                return (int) (round($B0zGS / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($B0zGS / 2) * 2);
        }
        goto As8uy;
        t1gpB:
    }
    public function m8guPE8fybh(string $Y39c0 = 'floor') : array
    {
        goto lwcma;
        Htxzz:
        $w8g20 = 0;
        goto n5fIc;
        YZp_H:
        $w8g20 = $aOhuG;
        goto evYFW;
        lwcma:
        $aOhuG = 1080;
        goto RXZeV;
        zQD8g:
        $drGWi = $gSJj_ / $this->vSEbD;
        goto fOcE3;
        ZohWR:
        $w8g20 = 2;
        goto IMTFc;
        RXZeV:
        $gSJj_ = 0;
        goto Htxzz;
        lG5cs:
        if (!($gSJj_ < 2)) {
            goto zcBSw;
        }
        goto DKAB_;
        qqcen:
        goto VLO_9;
        goto NNvz3;
        z8VIp:
        VLO_9:
        goto lG5cs;
        evYFW:
        $drGWi = $w8g20 / $this->RjtXg;
        goto MnUWo;
        fOcE3:
        $CaRZG = $this->RjtXg * $drGWi;
        goto LBYKD;
        LBYKD:
        $w8g20 = self::mxoSWaox9KJ(round($CaRZG), $Y39c0);
        goto qqcen;
        MnUWo:
        $OvuQJ = $this->vSEbD * $drGWi;
        goto MKFBl;
        UKgf3:
        return ['width' => $gSJj_, 'height' => $w8g20];
        goto eNbOZ;
        cCfcA:
        zcBSw:
        goto R2G__;
        n5fIc:
        if ($this->vSEbD >= $this->RjtXg) {
            goto FOBrB;
        }
        goto eL5a1;
        DKAB_:
        $gSJj_ = 2;
        goto cCfcA;
        eL5a1:
        $gSJj_ = $aOhuG;
        goto zQD8g;
        NNvz3:
        FOBrB:
        goto YZp_H;
        R2G__:
        if (!($w8g20 < 2)) {
            goto Wyjhm;
        }
        goto ZohWR;
        MKFBl:
        $gSJj_ = self::mxoSWaox9KJ(round($OvuQJ), $Y39c0);
        goto z8VIp;
        IMTFc:
        Wyjhm:
        goto UKgf3;
        eNbOZ:
    }
}
