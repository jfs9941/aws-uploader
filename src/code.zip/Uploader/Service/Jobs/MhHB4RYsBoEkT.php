<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Illuminate\Support\Facades\Log;
class MhHB4RYsBoEkT implements BlurVideoJobInterface
{
    const LQaqd = 15;
    const HcR9a = 500;
    const cMOcE = 500;
    private $JG9IT;
    private $huyLW;
    private $Ntit8;
    public function __construct($mLPCZ, $A3hvZ, $MYg0D)
    {
        goto qxrLR;
        qxrLR:
        $this->Ntit8 = $MYg0D;
        goto J8aHk;
        x47N9:
        $this->JG9IT = $mLPCZ;
        goto z867w;
        J8aHk:
        $this->huyLW = $A3hvZ;
        goto x47N9;
        z867w:
    }
    public function blur(string $arqvy) : void
    {
        goto pA7rb;
        ZFeIh:
        $this->huyLW->put($FpaeH, $this->Ntit8->get($FpaeH));
        goto L885b;
        WS5wI:
        nbe2L:
        goto giWBs;
        DcS03:
        ini_set('memory_limit', '-1');
        goto lwvik;
        emqqW:
        \Log::warning('Failed to set final permissions on image file: ' . $gxJtw);
        goto d4Uoh;
        d4Uoh:
        throw new \Exception('Failed to set final permissions on image file: ' . $gxJtw);
        goto WS5wI;
        vRgqe:
        if (!$PAcIL->getAttribute('thumbnail')) {
            goto OhEcC;
        }
        goto PSdF6;
        BaoCA:
        $uuvVo->blur(self::LQaqd);
        goto Tt_EA;
        G4OmD:
        $uuvVo->resize(self::HcR9a, self::cMOcE / $mpFph);
        goto BaoCA;
        bxTNi:
        $uuvVo->save($gxJtw);
        goto ZFeIh;
        WNk4d:
        OhEcC:
        goto u04Gz;
        giWBs:
        $PAcIL->update(['preview' => $FpaeH]);
        goto WNk4d;
        Tt_EA:
        $FpaeH = $this->mnlfwhv6ERF($PAcIL);
        goto WhGq5;
        pA7rb:
        Log::info("Blurring for video", ['videoID' => $arqvy]);
        goto DcS03;
        OGyjI:
        $uuvVo = $this->JG9IT->call($this, $this->Ntit8->path($PAcIL->getAttribute('thumbnail')));
        goto ukqg8;
        q9vfh:
        if (chmod($gxJtw, 0664)) {
            goto nbe2L;
        }
        goto emqqW;
        ukqg8:
        $mpFph = $uuvVo->width() / $uuvVo->height();
        goto G4OmD;
        WhGq5:
        $gxJtw = $this->Ntit8->path($FpaeH);
        goto bxTNi;
        lwvik:
        $PAcIL = RhSx2q5xIlh0Y::findOrFail($arqvy);
        goto vRgqe;
        PSdF6:
        $this->Ntit8->put($PAcIL->getAttribute('thumbnail'), $this->huyLW->get($PAcIL->getAttribute('thumbnail')));
        goto OGyjI;
        L885b:
        unset($uuvVo);
        goto q9vfh;
        u04Gz:
    }
    private function mnlfwhv6ERF(BTuo2UPlpfSoS $fwqMa) : string
    {
        goto f7z0V;
        f7z0V:
        $lxbX3 = $fwqMa->getLocation();
        goto mDEfb;
        qdGS3:
        return $gcOdN . $fwqMa->getFilename() . '.jpg';
        goto Mr6b6;
        YiIsG:
        if ($this->Ntit8->exists($gcOdN)) {
            goto HiV3P;
        }
        goto zV3VG;
        mDEfb:
        $gcOdN = dirname($lxbX3) . '/preview/';
        goto YiIsG;
        UHGvq:
        HiV3P:
        goto qdGS3;
        zV3VG:
        $this->Ntit8->makeDirectory($gcOdN, 0755, true);
        goto UHGvq;
        Mr6b6:
    }
}
