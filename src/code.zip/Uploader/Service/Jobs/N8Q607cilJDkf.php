<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Service\Jobs\MFsckEdQzAs6x;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class N8Q607cilJDkf implements WatermarkTextJobInterface
{
    private $PAMAL;
    private $wVJ_V;
    private $rJ93d;
    private $hFxUe;
    private $IdG3S;
    public function __construct($VX8yi, $wc3FE, $KKbEP, $ftmEm, $p4tPq)
    {
        goto NpPVZ;
        t9NsJ:
        $this->IdG3S = $ftmEm;
        goto Hne4M;
        Hne4M:
        $this->rJ93d = $p4tPq;
        goto a7196;
        a7196:
        $this->wVJ_V = $wc3FE;
        goto nySUJ;
        NpPVZ:
        $this->PAMAL = $VX8yi;
        goto OU7qN;
        OU7qN:
        $this->hFxUe = $KKbEP;
        goto t9NsJ;
        nySUJ:
    }
    public function putWatermark(string $SEOXv, string $uZL5Y) : void
    {
        goto xW5FF;
        xW5FF:
        $NR4hg = microtime(true);
        goto kEjGC;
        nH9Xy:
        ini_set('memory_limit', '-1');
        goto MoogE;
        kEjGC:
        $BuLko = memory_get_usage();
        goto FbPWa;
        MoogE:
        try {
            goto SvomA;
            PDWuF:
            $this->m1Fm0BTEwX5($jHjzE, $uZL5Y);
            goto wfafo;
            JKaFf:
            hmkQf:
            goto GwEUK;
            FGTSM:
            \Log::warning('Failed to set final permissions on image file: ' . $liQkG);
            goto RhjXy;
            lboN3:
            if ($this->IdG3S->exists($dIrHq->getLocation())) {
                goto KlIy5;
            }
            goto ycVW0;
            M_13k:
            unset($jHjzE);
            goto qWkae;
            qWkae:
            if (chmod($liQkG, 0664)) {
                goto hmkQf;
            }
            goto FGTSM;
            RhjXy:
            throw new \Exception('Failed to set final permissions on image file: ' . $liQkG);
            goto JKaFf;
            ycVW0:
            Log::error("FmmY71eXk0D8U is not on local, might be deleted before put watermark", ['imageId' => $SEOXv]);
            goto JAkv6;
            wfafo:
            $this->hFxUe->put($liQkG, $jHjzE->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto M_13k;
            uIayO:
            KlIy5:
            goto nF0Ku;
            nF0Ku:
            $liQkG = $this->IdG3S->path($dIrHq->getLocation());
            goto CkMKC;
            SvomA:
            $dIrHq = FmmY71eXk0D8U::findOrFail($SEOXv);
            goto lboN3;
            JAkv6:
            return;
            goto uIayO;
            KfIAe:
            $jHjzE->orient();
            goto PDWuF;
            CkMKC:
            $jHjzE = $this->PAMAL->call($this, $liQkG);
            goto KfIAe;
            GwEUK:
        } catch (\Throwable $AskED) {
            goto n1Mqs;
            QeZm5:
            DrjKi:
            goto Q9xGN;
            Q9xGN:
            Log::error("FmmY71eXk0D8U is not readable", ['imageId' => $SEOXv, 'error' => $AskED->getMessage()]);
            goto sAWY0;
            SD9_K:
            Log::info("FmmY71eXk0D8U has been deleted, discard it", ['imageId' => $SEOXv]);
            goto cw_O4;
            n1Mqs:
            if (!$AskED instanceof ModelNotFoundException) {
                goto DrjKi;
            }
            goto SD9_K;
            cw_O4:
            return;
            goto QeZm5;
            sAWY0:
        } finally {
            $vmfo7 = microtime(true);
            $icHkX = memory_get_usage();
            $W9dV9 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $SEOXv, 'execution_time_sec' => $vmfo7 - $NR4hg, 'memory_usage_mb' => ($icHkX - $BuLko) / 1024 / 1024, 'peak_memory_usage_mb' => ($W9dV9 - $DAezb) / 1024 / 1024]);
        }
        goto QEosx;
        wN3Z3:
        Log::info("Adding watermark text to image", ['imageId' => $SEOXv]);
        goto nH9Xy;
        FbPWa:
        $DAezb = memory_get_peak_usage();
        goto wN3Z3;
        QEosx:
    }
    private function m1Fm0BTEwX5($jHjzE, $uZL5Y) : void
    {
        goto gufGS;
        gufGS:
        $IxHFs = $jHjzE->width();
        goto rna7i;
        RDLB6:
        $keXvC = $xJxNW->mJjYfi06Dd5($IxHFs, $Ijyqc, $uZL5Y, true);
        goto dXcOm;
        ZYQkV:
        $XFfCd = $this->PAMAL->call($this, $this->IdG3S->path($keXvC));
        goto EwuEF;
        rna7i:
        $Ijyqc = $jHjzE->height();
        goto cGsBR;
        cGsBR:
        $xJxNW = new MFsckEdQzAs6x($this->wVJ_V, $this->rJ93d, $this->hFxUe, $this->IdG3S);
        goto RDLB6;
        EwuEF:
        $jHjzE->place($XFfCd, 'top-left', 0, 0, 30);
        goto FhrWC;
        dXcOm:
        $this->IdG3S->put($keXvC, $this->hFxUe->get($keXvC));
        goto ZYQkV;
        FhrWC:
    }
}
