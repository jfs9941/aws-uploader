<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Qit2RZ1q0o2t5 implements CompressJobInterface
{
    const dHltM = 60;
    private $R2XXS;
    private $A8xPF;
    private $SLOAZ;
    public function __construct($I4Jnv, $ZT237, $JzkDu)
    {
        goto Osl7t;
        Q7012:
        $this->A8xPF = $ZT237;
        goto bzn8K;
        gPOvM:
        $this->SLOAZ = $JzkDu;
        goto Q7012;
        Osl7t:
        $this->R2XXS = $I4Jnv;
        goto gPOvM;
        bzn8K:
    }
    public function compress(string $hOWbX)
    {
        goto hCpM1;
        cDZ1V:
        $wkaBP = memory_get_peak_usage();
        goto vOvd7;
        vOvd7:
        Log::info("Compress image", ['imageId' => $hOWbX]);
        goto kuGeO;
        kuGeO:
        try {
            goto IHLM6;
            IHLM6:
            $h169k = D6FgZi8OHmjic::findOrFail($hOWbX);
            goto Cy40U;
            Cy40U:
            $O_GLh = $this->A8xPF->path($h169k->getLocation());
            goto WcB9E;
            NOBpm:
            bFtTZ:
            goto VUCMj;
            WcB9E:
            if (!(strtolower($h169k->getExtension()) === 'png' || strtolower($h169k->getExtension()) === 'heic')) {
                goto bFtTZ;
            }
            goto OwNzF;
            VUCMj:
            try {
                goto zlfRN;
                zlfRN:
                $CwPVn = $this->A8xPF->path(str_replace('.jpg', '.webp', $h169k->getLocation()));
                goto rcmXZ;
                ZFdG2:
                $this->mHNtqxgF5qV($h169k, 'webp');
                goto QPV16;
                rcmXZ:
                $this->m29BELdltVk($O_GLh, $CwPVn);
                goto ZFdG2;
                QPV16:
            } catch (\Exception $aGVU4) {
                goto kU5nK;
                iNq30:
                $this->mQ2KePRCSsR($O_GLh, $CwPVn);
                goto wYrEH;
                dQNlG:
                $CwPVn = $this->A8xPF->path($h169k->getLocation());
                goto iNq30;
                kU5nK:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $hOWbX, 'error' => $aGVU4->getMessage()]);
                goto dQNlG;
                wYrEH:
            }
            goto bnvDt;
            OwNzF:
            $h169k = $this->mHNtqxgF5qV($h169k, 'jpg');
            goto NOBpm;
            bnvDt:
        } catch (\Throwable $aGVU4) {
            goto FFR0A;
            jADYr:
            return;
            goto TcSpP;
            TcSpP:
            XXNb3:
            goto N69lS;
            HONCz:
            Log::info("D6FgZi8OHmjic has been deleted, discard it", ['imageId' => $hOWbX]);
            goto jADYr;
            FFR0A:
            if (!$aGVU4 instanceof ModelNotFoundException) {
                goto XXNb3;
            }
            goto HONCz;
            N69lS:
            Log::error("Failed to compress image", ['imageId' => $hOWbX, 'error' => $aGVU4->getMessage()]);
            goto oODJO;
            oODJO:
        } finally {
            $qtKWj = microtime(true);
            $MDW5Q = memory_get_usage();
            $NFJ5h = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $hOWbX, 'execution_time_sec' => $qtKWj - $KyNi2, 'memory_usage_mb' => ($MDW5Q - $W0709) / 1024 / 1024, 'peak_memory_usage_mb' => ($NFJ5h - $wkaBP) / 1024 / 1024]);
        }
        goto Kyof6;
        bs7NZ:
        $W0709 = memory_get_usage();
        goto cDZ1V;
        hCpM1:
        $KyNi2 = microtime(true);
        goto bs7NZ;
        Kyof6:
    }
    private function mQ2KePRCSsR($O_GLh, $CwPVn)
    {
        goto M2P3T;
        hjN3R:
        $JAxuw->orient()->toJpeg(self::dHltM)->save($CwPVn);
        goto ayexT;
        M2P3T:
        $JAxuw = $this->R2XXS->call($this, $O_GLh);
        goto hjN3R;
        c7tMU:
        unset($JAxuw);
        goto xTGgq;
        ayexT:
        $this->SLOAZ->put($CwPVn, $JAxuw->toJpeg(self::dHltM), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto c7tMU;
        xTGgq:
    }
    private function m29BELdltVk($O_GLh, $CwPVn)
    {
        goto ntkkr;
        X_ib2:
        $JAxuw->orient()->toWebp(self::dHltM);
        goto XKr28;
        tg7Y7:
        unset($JAxuw);
        goto Tfsdh;
        ntkkr:
        $JAxuw = $this->R2XXS->call($this, $O_GLh);
        goto X_ib2;
        XKr28:
        $this->SLOAZ->put($CwPVn, $JAxuw->toJpeg(self::dHltM), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto tg7Y7;
        Tfsdh:
    }
    private function mHNtqxgF5qV($h169k, $igJ3j)
    {
        goto MuT8N;
        suNHA:
        $h169k->save();
        goto mHbGq;
        JtH4H:
        $h169k->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$igJ3j}", $h169k->getLocation()));
        goto suNHA;
        mHbGq:
        return $h169k;
        goto JANIt;
        MuT8N:
        $h169k->setAttribute('type', $igJ3j);
        goto JtH4H;
        JANIt:
    }
}
