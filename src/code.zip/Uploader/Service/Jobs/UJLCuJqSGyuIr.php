<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class UJLCuJqSGyuIr
{
    private $XHe90;
    private $cPefI;
    public function __construct(int $Etxkh, int $gX0GJ)
    {
        goto FEbTT;
        iFuv5:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto vKvE3;
        SuORT:
        fC30Q:
        goto Vwqz9;
        vKvE3:
        X0Uyo:
        goto NNvbH;
        NNvbH:
        if (!($gX0GJ <= 0)) {
            goto fC30Q;
        }
        goto YBekz;
        M9x7L:
        $this->cPefI = $gX0GJ;
        goto HahAu;
        YBekz:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto SuORT;
        Vwqz9:
        $this->XHe90 = $Etxkh;
        goto M9x7L;
        FEbTT:
        if (!($Etxkh <= 0)) {
            goto X0Uyo;
        }
        goto iFuv5;
        HahAu:
    }
    private static function m3duQ3jNJwP($GO9TS, string $nJJom = 'floor') : int
    {
        goto C22oj;
        C22oj:
        if (!(is_int($GO9TS) && $GO9TS % 2 === 0)) {
            goto z1ymk;
        }
        goto T_FrB;
        CxqVV:
        z1ymk:
        goto UEyXN;
        JSILX:
        switch (strtolower($nJJom)) {
            case 'ceil':
                return (int) (ceil($GO9TS / 2) * 2);
            case 'round':
                return (int) (round($GO9TS / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($GO9TS / 2) * 2);
        }
        goto KGKQ6;
        T_FrB:
        return $GO9TS;
        goto CxqVV;
        zwHJ0:
        AvVnq:
        goto JSILX;
        BvVLu:
        stSBH:
        goto zRtj0;
        KGKQ6:
        T6TXx:
        goto BvVLu;
        UEyXN:
        if (!(is_float($GO9TS) && $GO9TS == floor($GO9TS) && (int) $GO9TS % 2 === 0)) {
            goto AvVnq;
        }
        goto WzYTJ;
        WzYTJ:
        return (int) $GO9TS;
        goto zwHJ0;
        zRtj0:
    }
    public function mmq9LFOiNJM(string $xPbCi = 'floor') : array
    {
        goto ZLBOM;
        n8KMl:
        if ($this->XHe90 >= $this->cPefI) {
            goto GBRxO;
        }
        goto aK2xs;
        mOu0F:
        $mBil0 = self::m3duQ3jNJwP(round($zJsBG), $xPbCi);
        goto eXRz2;
        eXRz2:
        dGXQv:
        goto ss2gi;
        thj5g:
        GBRxO:
        goto gAajn;
        Xcpy2:
        $OBYPI = 2;
        goto l4irW;
        C7TRg:
        if (!($OBYPI < 2)) {
            goto yaG2D;
        }
        goto Xcpy2;
        IEWjE:
        return ['width' => $mBil0, 'height' => $OBYPI];
        goto TL5AX;
        LK9DK:
        $OBYPI = self::m3duQ3jNJwP(round($vsMEA), $xPbCi);
        goto M331x;
        M331x:
        goto dGXQv;
        goto thj5g;
        Udl3D:
        $mBil0 = 0;
        goto Avhcv;
        DcYOZ:
        $G5ybk = $OBYPI / $this->cPefI;
        goto TIdEr;
        l4irW:
        yaG2D:
        goto IEWjE;
        gAajn:
        $OBYPI = $cj5n9;
        goto DcYOZ;
        Oi_K1:
        $G5ybk = $mBil0 / $this->XHe90;
        goto sQ95t;
        Avhcv:
        $OBYPI = 0;
        goto n8KMl;
        ZLBOM:
        $cj5n9 = 1080;
        goto Udl3D;
        aK2xs:
        $mBil0 = $cj5n9;
        goto Oi_K1;
        sQ95t:
        $vsMEA = $this->cPefI * $G5ybk;
        goto LK9DK;
        icLks:
        $mBil0 = 2;
        goto upX3P;
        ss2gi:
        if (!($mBil0 < 2)) {
            goto zKzR7;
        }
        goto icLks;
        upX3P:
        zKzR7:
        goto C7TRg;
        TIdEr:
        $zJsBG = $this->XHe90 * $G5ybk;
        goto mOu0F;
        TL5AX:
    }
}
