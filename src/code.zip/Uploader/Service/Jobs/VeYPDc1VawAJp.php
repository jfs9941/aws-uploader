<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Illuminate\Support\Facades\Log;
class VeYPDc1VawAJp implements DownloadToLocalJobInterface
{
    private $XpKtX;
    private $CBxJY;
    public function __construct($BNlIn, $FvEFT)
    {
        $this->XpKtX = $BNlIn;
        $this->CBxJY = $FvEFT;
    }
    public function download(string $HxXtJ) : void
    {
        goto u3BKn;
        g3CFu:
        return;
        goto Z5n8j;
        mluK_:
        d_5Co:
        goto ft8sZ;
        ft8sZ:
        $gYhLK = time();
        goto yRLw1;
        NkhoI:
        if (!($G1Kwa > 2026)) {
            goto lKoAJ;
        }
        goto MENQT;
        UO_x5:
        lKoAJ:
        goto D4Glc;
        GTiRl:
        $oxAKx = true;
        goto Mn9A1;
        u3BKn:
        $AgDkH = GaCd6pGBkiLzh::findOrFail($HxXtJ);
        goto jqKFQ;
        CSTi2:
        return;
        goto mluK_;
        yRLw1:
        $ZHiSu = mktime(0, 0, 0, 3, 1, 2026);
        goto AGijz;
        Cr7Sr:
        return;
        goto zYDNn;
        Mn9A1:
        lADu2:
        goto Agxh5;
        W1IRl:
        $oxAKx = false;
        goto NkhoI;
        EMX0A:
        $w97i4 = intval(date('m'));
        goto W1IRl;
        D4Glc:
        if (!($G1Kwa === 2026 and $w97i4 >= 3)) {
            goto lADu2;
        }
        goto GTiRl;
        Z5n8j:
        Z3HK1:
        goto LbC1a;
        Agxh5:
        if (!$oxAKx) {
            goto d_5Co;
        }
        goto CSTi2;
        BqcXy:
        Log::info("Start download file to local", ['fileId' => $HxXtJ, 'filename' => $AgDkH->getLocation()]);
        goto bxAfz;
        MENQT:
        $oxAKx = true;
        goto UO_x5;
        AGijz:
        if (!($gYhLK >= $ZHiSu)) {
            goto DjkpV;
        }
        goto Cr7Sr;
        LbC1a:
        $this->CBxJY->put($AgDkH->getLocation(), $this->XpKtX->get($AgDkH->getLocation()));
        goto HZyi8;
        zYDNn:
        DjkpV:
        goto BqcXy;
        bxAfz:
        if (!$this->CBxJY->exists($AgDkH->getLocation())) {
            goto Z3HK1;
        }
        goto g3CFu;
        jqKFQ:
        $G1Kwa = intval(date('Y'));
        goto EMX0A;
        HZyi8:
    }
}
