<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class BfkurxdTziJpV
{
    private $qhFb9;
    private $Di2j4;
    private $VV2A8;
    private $niO3l;
    public function __construct($lJlOD, $Ul7uk, $oOPBt, $xuow1)
    {
        goto q1opT;
        uDIkm:
        $this->niO3l = $xuow1;
        goto GZuWt;
        q1opT:
        $this->Di2j4 = $Ul7uk;
        goto zyAzy;
        zyAzy:
        $this->VV2A8 = $oOPBt;
        goto uDIkm;
        GZuWt:
        $this->qhFb9 = $lJlOD;
        goto PqjHy;
        PqjHy:
    }
    public function m9xBuLdlu22(?int $Un71V, ?int $aHbCv, string $Dk9f1, bool $Xxtl0 = false) : string
    {
        goto msq0w;
        obsBd:
        list($CEZbb, $vg9wq, $oDSwa) = $this->mTNR5jPG5Jj($Dk9f1, $Un71V, $fpLOQ, (float) $Un71V / $aHbCv);
        goto MFBeH;
        APDNi:
        return $Xxtl0 ? $yRiLu : $this->VV2A8->url($yRiLu);
        goto psjXp;
        r6ul2:
        rHH32:
        goto d8JX4;
        TeQOq:
        $JAa1S -= $xlZgf * 0.4;
        goto dfByX;
        Pyp52:
        $JAa1S -= $xlZgf;
        goto xh0gA;
        V5s6m:
        $oaIJp->text($oDSwa, $JAa1S, (int) $hSIOQ, function ($snt8z) use($CEZbb) {
            goto BmT8q;
            FT6Dx:
            $snt8z->valign('middle');
            goto DGEOm;
            BmT8q:
            $snt8z->file(public_path($this->Di2j4));
            goto Epgqe;
            LSb_4:
            $snt8z->color([185, 185, 185, 1]);
            goto FT6Dx;
            DGEOm:
            $snt8z->align('middle');
            goto N_UkU;
            Epgqe:
            $QxKjS = (int) ($CEZbb * 1.2);
            goto j89qm;
            j89qm:
            $snt8z->size(max($QxKjS, 1));
            goto LSb_4;
            N_UkU:
        });
        goto bzObL;
        oLK2L:
        $JAa1S = $Un71V - $vg9wq;
        goto f38DL;
        MceUt:
        $this->VV2A8->put($yRiLu, $oaIJp->stream('png'));
        goto APDNi;
        UQsAR:
        if (!$this->VV2A8->exists($yRiLu)) {
            goto OSLAv;
        }
        goto rZ169;
        bzObL:
        $this->niO3l->put($yRiLu, $oaIJp->stream('png'));
        goto MceUt;
        xh0gA:
        if (!($Un71V > 1500)) {
            goto KG_3N;
        }
        goto TeQOq;
        rZ169:
        return $Xxtl0 ? $yRiLu : $this->VV2A8->url($yRiLu);
        goto UWYd7;
        f38DL:
        $xlZgf = (int) ($JAa1S / 80);
        goto Pyp52;
        ygTvM:
        throw new \RuntimeException("VHp3UACVYl357 dimensions are not available.");
        goto r6ul2;
        msq0w:
        if (!($Un71V === null || $aHbCv === null)) {
            goto rHH32;
        }
        goto ygTvM;
        lxpRd:
        $oaIJp = $this->qhFb9->call($this, $Un71V, $aHbCv);
        goto oLK2L;
        d8JX4:
        $fpLOQ = 0.1;
        goto obsBd;
        MFBeH:
        $yRiLu = $this->mIHZOhSZ7xk($oDSwa, $Un71V, $aHbCv, $vg9wq, $CEZbb);
        goto UQsAR;
        JnNVH:
        $hSIOQ = $aHbCv - $CEZbb - 10;
        goto V5s6m;
        dfByX:
        KG_3N:
        goto JnNVH;
        UWYd7:
        OSLAv:
        goto lxpRd;
        psjXp:
    }
    private function mIHZOhSZ7xk(string $Dk9f1, int $Un71V, int $aHbCv, int $FPJfh, int $U8KCd) : string
    {
        $ZitVP = ltrim($Dk9f1, '@');
        return "v2/watermark/{$ZitVP}/{$Un71V}x{$aHbCv}_{$FPJfh}x{$U8KCd}/text_watermark.png";
    }
    private function mTNR5jPG5Jj($Dk9f1, int $Un71V, float $xe8UR, float $huvyP) : array
    {
        goto buWdU;
        zawru:
        return [(int) $ONM02, $vg9wq, $oDSwa];
        goto WQ7Z0;
        j2E20:
        $vg9wq = (int) ($Un71V * $xe8UR);
        goto bw6k0;
        p2bWn:
        $ONM02 = $vg9wq / (strlen($oDSwa) * 0.8);
        goto TCOFl;
        buWdU:
        $oDSwa = '@' . $Dk9f1;
        goto j2E20;
        bw6k0:
        if (!($huvyP > 1)) {
            goto mlt15;
        }
        goto p2bWn;
        cS8Qp:
        mlt15:
        goto lWgZH;
        lWgZH:
        $ONM02 = 1 / $huvyP * $vg9wq / strlen($oDSwa);
        goto zawru;
        TCOFl:
        return [(int) $ONM02, $ONM02 * strlen($oDSwa) / 1.8, $oDSwa];
        goto cS8Qp;
        WQ7Z0:
    }
}
