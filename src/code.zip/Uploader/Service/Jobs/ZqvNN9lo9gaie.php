<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ZqvNN9lo9gaie
{
    private $Y56oy;
    private $opajE;
    public function __construct(int $DTfjO, int $jlWVV)
    {
        goto kn9dt;
        Dihd2:
        RxWD6:
        goto T2aM7;
        T2aM7:
        $this->Y56oy = $DTfjO;
        goto qw65V;
        qw65V:
        $this->opajE = $jlWVV;
        goto wMOe7;
        kn9dt:
        if (!($DTfjO <= 0)) {
            goto fV8J_;
        }
        goto zit2t;
        zit2t:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto nafUf;
        w82iW:
        if (!($jlWVV <= 0)) {
            goto RxWD6;
        }
        goto p70aO;
        nafUf:
        fV8J_:
        goto w82iW;
        p70aO:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Dihd2;
        wMOe7:
    }
    private static function mXnDUsxq4vc($gDohD, string $LN_ZY = 'floor') : int
    {
        goto DHBXx;
        V1ReF:
        peGht:
        goto Me0IC;
        DvESS:
        if (!(is_float($gDohD) && $gDohD == floor($gDohD) && (int) $gDohD % 2 === 0)) {
            goto UepxJ;
        }
        goto SykTw;
        fdRCZ:
        UepxJ:
        goto dqgGs;
        dqgGs:
        switch (strtolower($LN_ZY)) {
            case 'ceil':
                return (int) (ceil($gDohD / 2) * 2);
            case 'round':
                return (int) (round($gDohD / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($gDohD / 2) * 2);
        }
        goto F05Uu;
        SykTw:
        return (int) $gDohD;
        goto fdRCZ;
        F05Uu:
        PzXdG:
        goto V1ReF;
        DHBXx:
        if (!(is_int($gDohD) && $gDohD % 2 === 0)) {
            goto Zrk8S;
        }
        goto l3V0N;
        WuqIe:
        Zrk8S:
        goto DvESS;
        l3V0N:
        return $gDohD;
        goto WuqIe;
        Me0IC:
    }
    public function mIxoimmOp83(string $HKy4O = 'floor') : array
    {
        goto yg4pS;
        yg4pS:
        $pPJgv = 1080;
        goto pg19M;
        o66LU:
        $PjBvR = 2;
        goto uqfHO;
        aV0oc:
        $PjBvR = self::mXnDUsxq4vc(round($niNAr), $HKy4O);
        goto KGaeB;
        Hzt_T:
        ZEEes:
        goto YYodO;
        KGaeB:
        WzOUP:
        goto zdM36;
        xWeZs:
        $yUULS = $pIFLx / $this->opajE;
        goto wzsys;
        HocGq:
        if ($this->Y56oy >= $this->opajE) {
            goto btaAk;
        }
        goto lsZDe;
        LLRxZ:
        $yUULS = $PjBvR / $this->Y56oy;
        goto XpgpW;
        tUgCy:
        btaAk:
        goto zRV4a;
        zdM36:
        if (!($PjBvR < 2)) {
            goto LRl7C;
        }
        goto o66LU;
        XpgpW:
        $H7ozi = $this->opajE * $yUULS;
        goto D8L5L;
        jJucs:
        if (!($pIFLx < 2)) {
            goto ZEEes;
        }
        goto tlMbo;
        uqfHO:
        LRl7C:
        goto jJucs;
        D8L5L:
        $pIFLx = self::mXnDUsxq4vc(round($H7ozi), $HKy4O);
        goto PWDPe;
        iMXWg:
        $pIFLx = 0;
        goto HocGq;
        tlMbo:
        $pIFLx = 2;
        goto Hzt_T;
        zRV4a:
        $pIFLx = $pPJgv;
        goto xWeZs;
        wzsys:
        $niNAr = $this->Y56oy * $yUULS;
        goto aV0oc;
        PWDPe:
        goto WzOUP;
        goto tUgCy;
        YYodO:
        return ['width' => $PjBvR, 'height' => $pIFLx];
        goto Sdc71;
        lsZDe:
        $PjBvR = $pPJgv;
        goto LLRxZ;
        pg19M:
        $PjBvR = 0;
        goto iMXWg;
        Sdc71:
    }
}
