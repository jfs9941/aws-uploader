<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
class NUuJh7gYX8WkE implements CompressJobInterface
{
    const snpJZ = 80;
    private $bg_1H;
    private $P6k4O;
    public function __construct($IDVBi, $RNTis)
    {
        $this->bg_1H = $IDVBi;
        $this->P6k4O = $RNTis;
    }
    public function compress(string $IaHim)
    {
        Log::info("Compress image", ['imageId' => $IaHim]);
        try {
            goto GvbGk;
            SpgMF:
            $kHreC->setAttribute('filename', str_replace('.png', '.jpg', $kHreC->getLocation()));
            goto V31EC;
            K0kF3:
            $HYrky->orientate();
            goto VrCVs;
            SBDiP:
            $HYrky = $this->bg_1H->call($this, $TTL0n);
            goto K0kF3;
            GvbGk:
            $kHreC = FNGNxcyxjaxBG::findOrFail($IaHim);
            goto phwA2;
            AwSJA:
            $HYrky->destroy();
            goto kpHzt;
            VrCVs:
            $HYrky->save($EzJvI, self::snpJZ);
            goto AwSJA;
            V31EC:
            $kHreC->save();
            goto nOPGn;
            GBE82:
            $kHreC->setAttribute('type', 'jpg');
            goto SpgMF;
            F4qnl:
            if (!($kHreC->getExtension() === 'png')) {
                goto dohwO;
            }
            goto GBE82;
            fsjEQ:
            $EzJvI = $this->P6k4O->path($kHreC->getLocation());
            goto SBDiP;
            phwA2:
            $TTL0n = $this->P6k4O->path($kHreC->getLocation());
            goto F4qnl;
            nOPGn:
            dohwO:
            goto fsjEQ;
            kpHzt:
        } catch (ModelNotFoundException) {
            Log::info("FNGNxcyxjaxBG has been deleted, discard it", ['imageId' => $IaHim]);
        }
    }
}
