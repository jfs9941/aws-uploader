<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\BUMikUMmdvq7W;
use backup\Uploader\Core\CrEYqpC23XUGo;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class BjuzinLCgVkZl implements BUMikUMmdvq7W
{
    const fPzdJ = 60;
    private $W3SEw;
    private $c35HU;
    private $Jn_QL;
    public function __construct($DrcMD, $VHhUy, $kywm2)
    {
        goto M0B2U;
        oRM39:
        $this->c35HU = $VHhUy;
        goto rAAo8;
        M0B2U:
        $this->W3SEw = $DrcMD;
        goto Qcq4Q;
        Qcq4Q:
        $this->Jn_QL = $kywm2;
        goto oRM39;
        rAAo8:
    }
    public function compress(string $EQQae)
    {
        goto RnMq8;
        lY85I:
        Log::info("Compress image", ['imageId' => $EQQae]);
        goto MbZ8l;
        RnMq8:
        $XzwBF = microtime(true);
        goto jrJqu;
        MbZ8l:
        try {
            goto AwOp6;
            m2l3N:
            if (!(strtolower($ulojh->getExtension()) === 'png' || strtolower($ulojh->getExtension()) === 'heic')) {
                goto u9Go6;
            }
            goto EW2Q4;
            EW2Q4:
            $ulojh = $this->mToxiXazfLV($ulojh, 'jpg');
            goto jPknE;
            DLfiY:
            try {
                goto nZ2pe;
                nZ2pe:
                $N1SwW = $this->c35HU->path(str_replace('.jpg', '.webp', $ulojh->getLocation()));
                goto sWf5U;
                rfEe8:
                $this->mToxiXazfLV($ulojh, 'webp');
                goto K65cL;
                sWf5U:
                $this->mU63vcBpicf($b6UHE, $N1SwW);
                goto rfEe8;
                K65cL:
            } catch (\Exception $AfYww) {
                goto hcxhO;
                YE3GF:
                $N1SwW = $this->c35HU->path($ulojh->getLocation());
                goto ZeoZt;
                hcxhO:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $EQQae, 'error' => $AfYww->getMessage()]);
                goto YE3GF;
                ZeoZt:
                $this->mPLeg91oBYN($b6UHE, $N1SwW);
                goto o_pFU;
                o_pFU:
            }
            goto i4_M_;
            q53GZ:
            $b6UHE = $this->c35HU->path($ulojh->getLocation());
            goto m2l3N;
            jPknE:
            u9Go6:
            goto DLfiY;
            AwOp6:
            $ulojh = CrEYqpC23XUGo::findOrFail($EQQae);
            goto q53GZ;
            i4_M_:
        } catch (\Throwable $AfYww) {
            goto knqyB;
            PlrQm:
            return;
            goto QNr2k;
            HhctQ:
            Log::error("Failed to compress image", ['imageId' => $EQQae, 'error' => $AfYww->getMessage()]);
            goto msFUu;
            knqyB:
            if (!$AfYww instanceof ModelNotFoundException) {
                goto JoIBb;
            }
            goto bY8oQ;
            bY8oQ:
            Log::info("CrEYqpC23XUGo has been deleted, discard it", ['imageId' => $EQQae]);
            goto PlrQm;
            QNr2k:
            JoIBb:
            goto HhctQ;
            msFUu:
        } finally {
            $nQaGH = microtime(true);
            $QXkFj = memory_get_usage();
            $VfjfL = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $EQQae, 'execution_time_sec' => $nQaGH - $XzwBF, 'memory_usage_mb' => ($QXkFj - $CaFiz) / 1024 / 1024, 'peak_memory_usage_mb' => ($VfjfL - $m3FUa) / 1024 / 1024]);
        }
        goto JvVhv;
        jrJqu:
        $CaFiz = memory_get_usage();
        goto iEPB5;
        iEPB5:
        $m3FUa = memory_get_peak_usage();
        goto lY85I;
        JvVhv:
    }
    private function mPLeg91oBYN($b6UHE, $N1SwW)
    {
        goto SX3yC;
        lR5GH:
        $this->Jn_QL->put($N1SwW, $Y2mNU->toJpeg(self::fPzdJ), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto mu0B1;
        SX3yC:
        $Y2mNU = $this->W3SEw->call($this, $b6UHE);
        goto Hlx3x;
        mu0B1:
        unset($Y2mNU);
        goto RCKNo;
        Hlx3x:
        $Y2mNU->orient()->toJpeg(self::fPzdJ)->save($N1SwW);
        goto lR5GH;
        RCKNo:
    }
    private function mU63vcBpicf($b6UHE, $N1SwW)
    {
        goto wayMN;
        u8TUT:
        $this->Jn_QL->put($N1SwW, $Y2mNU->toJpeg(self::fPzdJ), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto yChS4;
        wayMN:
        $Y2mNU = $this->W3SEw->call($this, $b6UHE);
        goto l0F6T;
        l0F6T:
        $Y2mNU->orient()->toWebp(self::fPzdJ);
        goto u8TUT;
        yChS4:
        unset($Y2mNU);
        goto pJobu;
        pJobu:
    }
    private function mToxiXazfLV($ulojh, $VgtDV)
    {
        goto jIPZB;
        jIPZB:
        $ulojh->setAttribute('type', $VgtDV);
        goto MR9jS;
        zzIQN:
        return $ulojh;
        goto AGz61;
        go2f4:
        $ulojh->save();
        goto zzIQN;
        MR9jS:
        $ulojh->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$VgtDV}", $ulojh->getLocation()));
        goto go2f4;
        AGz61:
    }
}
