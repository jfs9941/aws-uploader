<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class MFBwl1BTODZYU
{
    private $pUKMn;
    private $wyfwp;
    private $VoF9h;
    private $hhcR1;
    public function __construct($BetpK, $KWnDr, $BQ2l1, $nQYui)
    {
        goto kDT3w;
        PJjSp:
        $this->hhcR1 = $nQYui;
        goto GtHiV;
        kDT3w:
        $this->wyfwp = $KWnDr;
        goto Hb3Sj;
        GtHiV:
        $this->pUKMn = $BetpK;
        goto bOhwU;
        Hb3Sj:
        $this->VoF9h = $BQ2l1;
        goto PJjSp;
        bOhwU:
    }
    public function mvALyMgg8ca(?int $SAWrT, ?int $rnPww, string $FkoJ6, bool $XLm28 = false) : string
    {
        goto sQ_T6;
        xZe3f:
        if (!($SAWrT > 1500)) {
            goto aitde;
        }
        goto FT6if;
        YFWXP:
        $this->hhcR1->put($uMpUA, $a97TB->stream('png'));
        goto t9L2C;
        SXRIV:
        $dtF73 -= $O3qsb;
        goto xZe3f;
        L9U3p:
        $dtF73 = $SAWrT - $BrR3c;
        goto m17Ww;
        m4aUd:
        $a97TB = $this->pUKMn->call($this, $SAWrT, $rnPww);
        goto L9U3p;
        wul4h:
        return $XLm28 ? $uMpUA : $this->VoF9h->url($uMpUA);
        goto Wbo2F;
        w4xuZ:
        q4k6g:
        goto GP_Mq;
        tsZMR:
        $a97TB->text($B_fLp, $dtF73, (int) $neMEV, function ($EudYU) use($Jx7x3) {
            goto SD7OM;
            UBs1O:
            $EudYU->size(max($BVwGb, 1));
            goto hfK_M;
            SD7OM:
            $EudYU->file(public_path($this->wyfwp));
            goto Y2L8a;
            keyGg:
            $EudYU->valign('middle');
            goto VhdPe;
            Y2L8a:
            $BVwGb = (int) ($Jx7x3 * 1.2);
            goto UBs1O;
            VhdPe:
            $EudYU->align('middle');
            goto pV8EC;
            hfK_M:
            $EudYU->color([185, 185, 185, 1]);
            goto keyGg;
            pV8EC:
        });
        goto YFWXP;
        RjF1A:
        $uMpUA = $this->mKAkbcqTFO5($B_fLp, $SAWrT, $rnPww, $BrR3c, $Jx7x3);
        goto h_ujs;
        sQ_T6:
        if (!($SAWrT === null || $rnPww === null)) {
            goto q4k6g;
        }
        goto V1CDj;
        Upx5s:
        return $XLm28 ? $uMpUA : $this->VoF9h->url($uMpUA);
        goto mCVVq;
        qx9Hb:
        aitde:
        goto m4kQ4;
        m4kQ4:
        $neMEV = $rnPww - $Jx7x3 - 10;
        goto tsZMR;
        h_ujs:
        if (!$this->VoF9h->exists($uMpUA)) {
            goto zIIBW;
        }
        goto Upx5s;
        FT6if:
        $dtF73 -= $O3qsb * 0.4;
        goto qx9Hb;
        L5jvE:
        list($Jx7x3, $BrR3c, $B_fLp) = $this->mlrEEp3dzvC($FkoJ6, $SAWrT, $fW01F, (float) $SAWrT / $rnPww);
        goto RjF1A;
        mCVVq:
        zIIBW:
        goto m4aUd;
        V1CDj:
        throw new \RuntimeException("MbOYV1VlUGCys dimensions are not available.");
        goto w4xuZ;
        m17Ww:
        $O3qsb = (int) ($dtF73 / 80);
        goto SXRIV;
        GP_Mq:
        $fW01F = 0.1;
        goto L5jvE;
        t9L2C:
        $this->VoF9h->put($uMpUA, $a97TB->stream('png'));
        goto wul4h;
        Wbo2F:
    }
    private function mKAkbcqTFO5(string $FkoJ6, int $SAWrT, int $rnPww, int $Mkna7, int $A0yRj) : string
    {
        $O1nvA = ltrim($FkoJ6, '@');
        return "v2/watermark/{$O1nvA}/{$SAWrT}x{$rnPww}_{$Mkna7}x{$A0yRj}/text_watermark.png";
    }
    private function mlrEEp3dzvC($FkoJ6, int $SAWrT, float $ZXDzG, float $C2pdE) : array
    {
        goto knLRa;
        IzlN1:
        $yPtod = 1 / $C2pdE * $BrR3c / strlen($B_fLp);
        goto Wdjrp;
        kfqzQ:
        $BrR3c = (int) ($SAWrT * $ZXDzG);
        goto AwSD_;
        jMap5:
        return [(int) $yPtod, $yPtod * strlen($B_fLp) / 1.8, $B_fLp];
        goto AQarR;
        knLRa:
        $B_fLp = '@' . $FkoJ6;
        goto kfqzQ;
        EFflE:
        $yPtod = $BrR3c / (strlen($B_fLp) * 0.8);
        goto jMap5;
        Wdjrp:
        return [(int) $yPtod, $BrR3c, $B_fLp];
        goto HlboZ;
        AQarR:
        oM0x3:
        goto IzlN1;
        AwSD_:
        if (!($C2pdE > 1)) {
            goto oM0x3;
        }
        goto EFflE;
        HlboZ:
    }
}
