<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class Y0kDKtH8tjxQG implements StoreToS3JobInterface
{
    private $gVUAC;
    private $cC_4U;
    private $jhnu6;
    public function __construct($pe6Kp, $s1UdZ, $vWOwZ)
    {
        goto whMuL;
        TqBfS:
        $this->jhnu6 = $vWOwZ;
        goto cb1oR;
        whMuL:
        $this->cC_4U = $s1UdZ;
        goto TqBfS;
        cb1oR:
        $this->gVUAC = $pe6Kp;
        goto eJwQJ;
        eJwQJ:
    }
    public function store(string $q8q1b) : void
    {
        goto iQCq_;
        WH2xM:
        $WtKC3 = $this->jhnu6->path($dK1me);
        goto R4ewD;
        jGK0x:
        $this->mWy711AgqgW($K_YMm, $N8QeM->getLocation());
        goto Jltqm;
        QcBRL:
        if (!$N8QeM->update(['driver' => Y9OZ7qWyGdhw2::S3, 'status' => IfP50GBBbx63a::FINISHED])) {
            goto tZcc7;
        }
        goto EgFHe;
        zj0mT:
        $jxgar = $this->jhnu6->path($N8QeM->getAttribute('preview'));
        goto WlAg4;
        Z4F4x:
        J3YYw:
        goto QcBRL;
        iQCq_:
        $N8QeM = JOauoJMkgHWbh::findOrFail($q8q1b);
        goto AsTii;
        Taj0D:
        return;
        goto tQedI;
        BCCG5:
        Log::info("JOauoJMkgHWbh has been deleted, discard it", ['fileId' => $q8q1b]);
        goto PZv0v;
        tQedI:
        tZcc7:
        goto i5fIA;
        R4ewD:
        $XqjZc = $this->gVUAC->call($this, $WtKC3);
        goto skgjO;
        msI3K:
        $K_YMm = $this->jhnu6->path($N8QeM->getLocation());
        goto jGK0x;
        EgFHe:
        Log::info("JOauoJMkgHWbh stored to S3, update the children attachments", ['fileId' => $q8q1b]);
        goto Mp0uR;
        m2Pbw:
        $this->cC_4U->put($N8QeM->getAttribute('preview'), $this->jhnu6->get($N8QeM->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $yc76l->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Z4F4x;
        O8xdW:
        if (!($N8QeM->getAttribute('preview') && $this->jhnu6->exists($N8QeM->getAttribute('preview')))) {
            goto J3YYw;
        }
        goto zj0mT;
        Jltqm:
        $dK1me = $N8QeM->getAttribute('thumbnail');
        goto wmiav;
        eJdyN:
        ac0Mu:
        goto msI3K;
        i5fIA:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $q8q1b]);
        goto USd0g;
        Mp0uR:
        JOauoJMkgHWbh::where('parent_id', $q8q1b)->update(['driver' => Y9OZ7qWyGdhw2::S3, 'preview' => $N8QeM->getAttribute('preview'), 'thumbnail' => $N8QeM->getAttribute('thumbnail')]);
        goto Taj0D;
        wmiav:
        if (!($dK1me && $this->jhnu6->exists($dK1me))) {
            goto CVBtU;
        }
        goto WH2xM;
        skgjO:
        $this->cC_4U->put($N8QeM->getAttribute('thumbnail'), $this->jhnu6->get($dK1me), ['visibility' => 'public', 'ContentType' => $XqjZc->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto hB3yl;
        PZv0v:
        return;
        goto eJdyN;
        hB3yl:
        CVBtU:
        goto O8xdW;
        WlAg4:
        $yc76l = $this->gVUAC->call($this, $jxgar);
        goto m2Pbw;
        AsTii:
        if ($N8QeM) {
            goto ac0Mu;
        }
        goto BCCG5;
        USd0g:
    }
    private function mWy711AgqgW($kI6L6, $f3yvn, $NXwFP = '')
    {
        goto NFMwY;
        L9p6y:
        try {
            $PdjKE = $this->gVUAC->call($this, $kI6L6);
            $this->cC_4U->put($f3yvn, $this->jhnu6->get($f3yvn), ['visibility' => 'public', 'ContentType' => $PdjKE->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $j62Rn) {
            Log::error("Failed to upload image to S3", ['s3Path' => $f3yvn, 'error' => $j62Rn->getMessage()]);
        }
        goto kj0do;
        dzCt_:
        $f3yvn = str_replace('.jpg', $NXwFP, $f3yvn);
        goto J_XTJ;
        NFMwY:
        if (!$NXwFP) {
            goto QitGD;
        }
        goto s1nzb;
        s1nzb:
        $kI6L6 = str_replace('.jpg', $NXwFP, $kI6L6);
        goto dzCt_;
        J_XTJ:
        QitGD:
        goto L9p6y;
        kj0do:
    }
}
