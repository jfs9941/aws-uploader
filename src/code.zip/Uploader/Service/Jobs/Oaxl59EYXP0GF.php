<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Encoder\TTEkHy4psgQsg;
use Jfs\Uploader\Encoder\XrhvIuy1MK56M;
use Jfs\Uploader\Encoder\Qyf5nkvkW6Bhl;
use Jfs\Uploader\Encoder\BHaSp176lnu5Y;
use Jfs\Uploader\Encoder\Ef3aL8loW3QaG;
use Jfs\Uploader\Encoder\OjCsASiweOGQ8;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
use Jfs\Uploader\Service\Jobs\Irgild271Mt83;
use Jfs\Uploader\Service\Jobs\TOxy9ZW6dqxMa;
use Jfs\Uploader\Service\VEn7C5MII4ANw;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class Oaxl59EYXP0GF implements MediaEncodeJobInterface
{
    private $Fcin3;
    private $Ybatl;
    private $cC_4U;
    private $aAdxh;
    private $Ge2u8;
    public function __construct(string $Bnpg8, $FHlTP, $s1UdZ, $V402Y, $oWXJW)
    {
        goto E7Wpr;
        E7Wpr:
        $this->Fcin3 = $Bnpg8;
        goto d0ESM;
        d0ESM:
        $this->Ybatl = $FHlTP;
        goto ITFB6;
        dZi7j:
        $this->aAdxh = $V402Y;
        goto wWtXh;
        ITFB6:
        $this->cC_4U = $s1UdZ;
        goto dZi7j;
        wWtXh:
        $this->Ge2u8 = $oWXJW;
        goto wO5pA;
        wO5pA:
    }
    public function encode(string $q8q1b, string $lqmQe, $cOcUt = true) : void
    {
        goto GGe9P;
        IvRZY:
        try {
            goto HSDJc;
            yqR2l:
            if (!($wtcqu && $snhLP)) {
                goto rZjna;
            }
            goto LVdxt;
            j2i4x:
            $VDmC7 = $this->moe4R5sDFyZ($cFlec);
            goto tur2P;
            uAqtF:
            $Vcwqy->mH5GeY4NbmR($h_x1R);
            goto WdvYN;
            a7gUB:
            Log::info("Set thumbnail for O1jfuwJR340k5 Job", ['videoId' => $cFlec->getAttribute('id'), 'duration' => $cFlec->getAttribute('duration')]);
            goto FYNPX;
            fLL09:
            btFoN:
            goto Blq16;
            VsaA8:
            $HUay1 = $HUay1->mLkiEYhjCcL($cBcuF);
            goto fLL09;
            i0SE3:
            $Vcwqy = $Vcwqy->mTHp9v2NOiU($XqjZc);
            goto lACZT;
            etIih:
            $VkQke = app(Qyf5nkvkW6Bhl::class);
            goto NG_s_;
            ffmfQ:
            TRkOl:
            goto uAqtF;
            FYNPX:
            $XqjZc = new TTEkHy4psgQsg($cFlec->getAttribute('duration') ?? 1, 2, $VkQke->m5hssaprz0p($cFlec));
            goto i0SE3;
            HSDJc:
            $cFlec = O1jfuwJR340k5::findOrFail($q8q1b);
            goto WH8NY;
            NG_s_:
            $Vcwqy->mlobzpA37IO($VkQke->mUiqBgKPPL5($cFlec));
            goto lIdtE;
            u6fPe:
            $cBcuF = $this->mMwXpvw3Rij($O11GX, $FRtii->mg1ITv6ydbE((int) $xnt73['width'], (int) $xnt73['height'], $lqmQe));
            goto tZ0Mi;
            FQtSf:
            $xnt73 = $this->mceBFxqg7fH($wtcqu, $snhLP);
            goto C_YXB;
            tur2P:
            Log::info("Set input video for Job", ['s3Uri' => $VDmC7]);
            goto IjWkW;
            lACZT:
            $q8q1b = $Vcwqy->mhc1VBSXL2D($this->mO5nuwfV3lN($cFlec, $cOcUt));
            goto CExx5;
            y1_BG:
            AVE4D:
            goto VFEb2;
            vhOzW:
            rZjna:
            goto a7gUB;
            C_YXB:
            Log::info("Set 1080p resolution for Job", ['width' => $xnt73['width'], 'height' => $xnt73['height'], 'originalWidth' => $wtcqu, 'originalHeight' => $snhLP]);
            goto v_RaU;
            HI466:
            $Vcwqy = $Vcwqy->miRslcMQBQz(new BHaSp176lnu5Y($VDmC7));
            goto FxbSy;
            v_RaU:
            $HUay1 = new XrhvIuy1MK56M('1080p', $xnt73['width'], $xnt73['height'], $cFlec->ciX2S ?? 30);
            goto u6fPe;
            lIdtE:
            $O11GX = app(VEn7C5MII4ANw::class);
            goto xg7wG;
            jNYV6:
            if (!$cBcuF) {
                goto TRkOl;
            }
            goto n8DbH;
            WH8NY:
            Assert::isInstanceOf($cFlec, O1jfuwJR340k5::class);
            goto TEqkv;
            n8DbH:
            $h_x1R = $h_x1R->mLkiEYhjCcL($cBcuF);
            goto ffmfQ;
            CExx5:
            $cFlec->update(['aws_media_converter_job_id' => $q8q1b]);
            goto Ar3Gb;
            xg7wG:
            $FRtii = new TOxy9ZW6dqxMa($this->aAdxh, $this->Ge2u8, $this->cC_4U, $this->Ybatl);
            goto ng18v;
            AJ69M:
            throw new MediaConverterException("O1jfuwJR340k5 {$cFlec->id} is not S3 driver value = {$cFlec->driver}");
            goto MjOZA;
            IjWkW:
            $Vcwqy = app(Ef3aL8loW3QaG::class);
            goto HI466;
            tZ0Mi:
            if (!$cBcuF) {
                goto btFoN;
            }
            goto VsaA8;
            TEqkv:
            if (!($cFlec->driver != Y9OZ7qWyGdhw2::S3)) {
                goto BX8RQ;
            }
            goto AJ69M;
            crbWi:
            if (!$cFlec->getAttribute('aws_media_converter_job_id')) {
                goto AVE4D;
            }
            goto uV1Zu;
            ng18v:
            $cBcuF = $this->mMwXpvw3Rij($O11GX, $FRtii->mg1ITv6ydbE($cFlec->width(), $cFlec->height(), $lqmQe));
            goto jNYV6;
            VFEb2:
            $wtcqu = $cFlec->width();
            goto DXJ9e;
            LVdxt:
            if (!$this->mSWikgq3WGf($wtcqu, $snhLP)) {
                goto pkHpg;
            }
            goto FQtSf;
            JLt51:
            pkHpg:
            goto vhOzW;
            WdvYN:
            $Vcwqy->mlobzpA37IO($VkQke->mUiqBgKPPL5($cFlec));
            goto yqR2l;
            Blq16:
            $Vcwqy = $Vcwqy->mH5GeY4NbmR($HUay1);
            goto JLt51;
            DXJ9e:
            $snhLP = $cFlec->height();
            goto j2i4x;
            FxbSy:
            $h_x1R = new XrhvIuy1MK56M('original', $wtcqu, $snhLP, $cFlec->ciX2S ?? 30);
            goto etIih;
            uV1Zu:
            Log::info("O1jfuwJR340k5 already has Media Converter Job ID, skip encoding", ['fileId' => $q8q1b, 'jobId' => $cFlec->getAttribute('aws_media_converter_job_id')]);
            goto sxMaJ;
            sxMaJ:
            return;
            goto y1_BG;
            MjOZA:
            BX8RQ:
            goto crbWi;
            Ar3Gb:
        } catch (\Exception $j62Rn) {
            goto Y5SoN;
            cnR5s:
            return;
            goto HXJC9;
            Y5SoN:
            Log::warning("O1jfuwJR340k5 has been deleted, discard it", ['fileId' => $q8q1b, 'err' => $j62Rn->getMessage()]);
            goto SPoEg;
            SPoEg:
            Sentry::captureException($j62Rn);
            goto cnR5s;
            HXJC9:
        }
        goto KNtzX;
        GGe9P:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $q8q1b]);
        goto DAkRK;
        DAkRK:
        ini_set('memory_limit', '-1');
        goto IvRZY;
        KNtzX:
    }
    private function mO5nuwfV3lN(O1jfuwJR340k5 $cFlec, $cOcUt) : bool
    {
        goto A0Rie;
        Or1hJ:
        switch (true) {
            case $cFlec->width() * $cFlec->height() >= 1920 * 1080 && $cFlec->width() * $cFlec->height() < 2560 * 1440:
                return $TTDRv > 30 * 60;
            case $cFlec->width() * $cFlec->height() >= 2560 * 1440 && $cFlec->width() * $cFlec->height() < 3840 * 2160:
                return $TTDRv > 15 * 60;
            case $cFlec->width() * $cFlec->height() >= 3840 * 2160:
                return $TTDRv > 10 * 60;
            default:
                return false;
        }
        goto JqC0O;
        Ylbj_:
        bsT2V:
        goto ta0JZ;
        WnYHy:
        return false;
        goto YRweD;
        ep4UA:
        $TTDRv = (int) round($cFlec->getAttribute('duration') ?? 0);
        goto Or1hJ;
        YRweD:
        xEdDa:
        goto ep4UA;
        A0Rie:
        if ($cOcUt) {
            goto xEdDa;
        }
        goto WnYHy;
        JqC0O:
        XGeHl:
        goto Ylbj_;
        ta0JZ:
    }
    private function mMwXpvw3Rij(VEn7C5MII4ANw $O11GX, string $HPvn1) : ?OjCsASiweOGQ8
    {
        goto XZUOS;
        ugc67:
        return new OjCsASiweOGQ8($WoWBH, 0, 0, null, null);
        goto VGnLh;
        XZUOS:
        $WoWBH = $O11GX->mzwCiTjnYVU($HPvn1);
        goto TO1uO;
        VGnLh:
        BCw0E:
        goto vGcs3;
        uA8uP:
        if (!$WoWBH) {
            goto BCw0E;
        }
        goto ugc67;
        TO1uO:
        Log::info("Resolve watermark for job with url", ['url' => $HPvn1, 'uri' => $WoWBH]);
        goto uA8uP;
        vGcs3:
        return null;
        goto x6Vwu;
        x6Vwu:
    }
    private function mSWikgq3WGf(int $wtcqu, int $snhLP) : bool
    {
        return $wtcqu * $snhLP > 1.5 * (1920 * 1080);
    }
    private function mceBFxqg7fH(int $wtcqu, int $snhLP) : array
    {
        $w_scC = new Irgild271Mt83($wtcqu, $snhLP);
        return $w_scC->mcbO4JYb277();
    }
    private function moe4R5sDFyZ(Lx6EggVsR2j6q $vIqmh) : string
    {
        goto cEpRt;
        BrjxF:
        return $this->Ybatl->url($vIqmh->filename);
        goto Dkcc2;
        Ni6W_:
        return 's3://' . $this->Fcin3 . '/' . $vIqmh->filename;
        goto vaRp2;
        vaRp2:
        LSv5F:
        goto BrjxF;
        cEpRt:
        if (!($vIqmh->driver == Y9OZ7qWyGdhw2::S3)) {
            goto LSv5F;
        }
        goto Ni6W_;
        Dkcc2:
    }
}
