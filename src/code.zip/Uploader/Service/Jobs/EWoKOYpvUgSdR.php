<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Illuminate\Support\Facades\Log;
class EWoKOYpvUgSdR implements DownloadToLocalJobInterface
{
    private $Mayr9;
    private $nEL6Z;
    public function __construct($KI4Gx, $vWt2S)
    {
        $this->Mayr9 = $KI4Gx;
        $this->nEL6Z = $vWt2S;
    }
    public function download(string $iG1wy) : void
    {
        goto LzEJ6;
        LzEJ6:
        $D55CH = KyoDVfv3eGItF::findOrFail($iG1wy);
        goto OnjQg;
        OnjQg:
        Log::info("Start download file to local", ['fileId' => $iG1wy, 'filename' => $D55CH->getLocation()]);
        goto y0_AJ;
        w6IhR:
        blsUG:
        goto wABEw;
        wABEw:
        $this->nEL6Z->put($D55CH->getLocation(), $this->Mayr9->get($D55CH->getLocation()));
        goto dMDz1;
        HHi0f:
        return;
        goto w6IhR;
        y0_AJ:
        if (!$this->nEL6Z->exists($D55CH->getLocation())) {
            goto blsUG;
        }
        goto HHi0f;
        dMDz1:
    }
}
