<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
class G7AIMeSUQ84TK implements StoreVideoToS3JobInterface
{
    private $zyrxE;
    private $K79lK;
    private $HyJkj;
    public function __construct($ahaqc, $yEBaZ, $N7YvB)
    {
        goto CSyh_;
        Kj3po:
        $this->HyJkj = $N7YvB;
        goto tLwei;
        tLwei:
        $this->zyrxE = $ahaqc;
        goto TKXT1;
        CSyh_:
        $this->K79lK = $yEBaZ;
        goto Kj3po;
        TKXT1:
    }
    public function store(string $Qu08p) : void
    {
        goto b8VKk;
        xHk07:
        $zI6e7 = SmhkgG6le5p0r::find($Qu08p);
        goto N9_2r;
        N9_2r:
        if ($zI6e7) {
            goto a110i;
        }
        goto tp_FN;
        b8VKk:
        Log::info('Storing video (local) to S3', ['fileId' => $Qu08p, 'bucketName' => $this->zyrxE]);
        goto wCpCN;
        BDCgI:
        Log::error("[G7AIMeSUQ84TK] File not found, discard it ", ['video' => $zI6e7->getLocation()]);
        goto En8q2;
        a0Usv:
        xxwJ5:
        goto PSL4f;
        PSL4f:
        $mBayP = $N7YvB->readStream($zI6e7->getLocation());
        goto SMc2v;
        kgdIb:
        $N7YvB = $this->HyJkj;
        goto xHk07;
        nVjM3:
        return;
        goto eEEVN;
        tp_FN:
        Log::info("SmhkgG6le5p0r has been deleted, discard it", ['fileId' => $Qu08p]);
        goto nVjM3;
        wCpCN:
        ini_set('memory_limit', '-1');
        goto W_kXk;
        En8q2:
        return;
        goto a0Usv;
        JKqmk:
        $S8nr9 = $N7YvB->mimeType($zI6e7->getLocation());
        goto hf0cC;
        LxOJk:
        if ($N7YvB->exists($zI6e7->getLocation())) {
            goto xxwJ5;
        }
        goto BDCgI;
        W_kXk:
        $war3R = $this->K79lK->getClient();
        goto kgdIb;
        hf0cC:
        try {
            goto xuaIt;
            QEfKy:
            $Oq4nq = $rWjSy['UploadId'];
            goto uw_tD;
            DyVV9:
            $zI6e7->update(['driver' => NYPGraEb3Ennl::S3, 'status' => OLX71luAn6XnP::FINISHED]);
            goto Q8EF_;
            JF38v:
            $AbKCX[] = ['PartNumber' => $RRfjk, 'ETag' => $jGrbd['ETag']];
            goto hY74W;
            Q8EF_:
            $N7YvB->delete($zI6e7->getLocation());
            goto WGz2D;
            ZVAAf:
            G7Z3i:
            goto EczPu;
            uw_tD:
            $RRfjk = 1;
            goto utFdE;
            IcVce:
            g3Fa2:
            goto GyAxw;
            hY74W:
            $RRfjk++;
            goto p_lk3;
            GyAxw:
            if (feof($mBayP)) {
                goto G7Z3i;
            }
            goto oyevT;
            fMisK:
            $war3R->completeMultipartUpload(['Bucket' => $this->zyrxE, 'Key' => $zI6e7->getLocation(), 'UploadId' => $Oq4nq, 'MultipartUpload' => ['Parts' => $AbKCX]]);
            goto DyVV9;
            EczPu:
            fclose($mBayP);
            goto fMisK;
            xuaIt:
            $rWjSy = $war3R->createMultipartUpload(['Bucket' => $this->zyrxE, 'Key' => $zI6e7->getLocation(), 'ContentType' => $S8nr9, 'ContentDisposition' => 'inline']);
            goto QEfKy;
            oyevT:
            $jGrbd = $war3R->uploadPart(['Bucket' => $this->zyrxE, 'Key' => $zI6e7->getLocation(), 'UploadId' => $Oq4nq, 'PartNumber' => $RRfjk, 'Body' => fread($mBayP, $XjqSL)]);
            goto JF38v;
            p_lk3:
            goto g3Fa2;
            goto ZVAAf;
            utFdE:
            $AbKCX = [];
            goto IcVce;
            WGz2D:
        } catch (AwsException $WZ5dZ) {
            goto VRwrh;
            WPBWt:
            il3aO:
            goto XNZ2x;
            VRwrh:
            if (!isset($Oq4nq)) {
                goto il3aO;
            }
            goto yRG6j;
            yRG6j:
            try {
                $war3R->abortMultipartUpload(['Bucket' => $this->zyrxE, 'Key' => $zI6e7->getLocation(), 'UploadId' => $Oq4nq]);
            } catch (AwsException $Ymo3K) {
                Log::error('Error aborting multipart upload: ' . $Ymo3K->getMessage());
            }
            goto WPBWt;
            XNZ2x:
            Log::error('Failed to store video: ' . $zI6e7->getLocation() . ' - ' . $WZ5dZ->getMessage());
            goto f3uyF;
            f3uyF:
        }
        goto JDSKq;
        eEEVN:
        a110i:
        goto LxOJk;
        SMc2v:
        $XjqSL = 1024 * 1024 * 50;
        goto JKqmk;
        JDSKq:
    }
}
