<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class BYT5DBY3GZZvP implements StoreVideoToS3JobInterface
{
    private $GOxhN;
    private $qrvF0;
    private $ERIyl;
    public function __construct($QEIhn, $eG_Pc, $nL6dR)
    {
        goto y14y3;
        y14y3:
        $this->qrvF0 = $eG_Pc;
        goto HtsQF;
        BazLN:
        $this->GOxhN = $QEIhn;
        goto JQ1Fa;
        HtsQF:
        $this->ERIyl = $nL6dR;
        goto BazLN;
        JQ1Fa:
    }
    public function store(string $ElvKF) : void
    {
        goto TtEXv;
        oxvsZ:
        try {
            goto R7RL0;
            LNsis:
            fclose($Hc4XF);
            goto LyBVh;
            cGXtO:
            $nL6dR->delete($pWX2V->getLocation());
            goto EnbQZ;
            K1Uqf:
            $iKHe3 = $TthJZ->uploadPart(['Bucket' => $this->GOxhN, 'Key' => $pWX2V->getLocation(), 'UploadId' => $MSFCE, 'PartNumber' => $YjlcU, 'Body' => fread($Hc4XF, $DTo1w)]);
            goto ShTL9;
            LyBVh:
            $TthJZ->completeMultipartUpload(['Bucket' => $this->GOxhN, 'Key' => $pWX2V->getLocation(), 'UploadId' => $MSFCE, 'MultipartUpload' => ['Parts' => $u2DUU]]);
            goto rRgj2;
            mwAB4:
            F_6TQ:
            goto PwMXf;
            PwMXf:
            if (feof($Hc4XF)) {
                goto HsnI5;
            }
            goto K1Uqf;
            VGlaZ:
            $YjlcU = 1;
            goto RER3V;
            RER3V:
            $u2DUU = [];
            goto mwAB4;
            bcmbD:
            goto F_6TQ;
            goto WLlsU;
            zOS3P:
            $YjlcU++;
            goto bcmbD;
            WLlsU:
            HsnI5:
            goto LNsis;
            ShTL9:
            $u2DUU[] = ['PartNumber' => $YjlcU, 'ETag' => $iKHe3['ETag']];
            goto zOS3P;
            R7RL0:
            $bZOiO = $TthJZ->createMultipartUpload(['Bucket' => $this->GOxhN, 'Key' => $pWX2V->getLocation(), 'ContentType' => $XSIXc, 'ContentDisposition' => 'inline']);
            goto TM5Ai;
            rRgj2:
            $pWX2V->update(['driver' => I2Tze5VZcqaXS::S3, 'status' => Q5pXt73hTeTVP::FINISHED]);
            goto cGXtO;
            TM5Ai:
            $MSFCE = $bZOiO['UploadId'];
            goto VGlaZ;
            EnbQZ:
        } catch (AwsException $vGb1d) {
            goto IcGSX;
            IcGSX:
            if (!isset($MSFCE)) {
                goto doFx7;
            }
            goto vX_Zj;
            Zq9UC:
            doFx7:
            goto ny6TM;
            ny6TM:
            Log::error('Failed to store video: ' . $pWX2V->getLocation() . ' - ' . $vGb1d->getMessage());
            goto Ll8uW;
            vX_Zj:
            try {
                $TthJZ->abortMultipartUpload(['Bucket' => $this->GOxhN, 'Key' => $pWX2V->getLocation(), 'UploadId' => $MSFCE]);
            } catch (AwsException $SrF9k) {
                Log::error('Error aborting multipart upload: ' . $SrF9k->getMessage());
            }
            goto Zq9UC;
            Ll8uW:
        }
        goto uNtcd;
        MMUvh:
        if ($pWX2V) {
            goto TI04r;
        }
        goto SBFim;
        AR10A:
        $DTo1w = 1024 * 1024 * 50;
        goto Tptnc;
        TtEXv:
        Log::info('Storing video (local) to S3', ['fileId' => $ElvKF, 'bucketName' => $this->GOxhN]);
        goto ebKAa;
        vIzsC:
        g_TLo:
        goto qeNwU;
        Cgdvx:
        TI04r:
        goto G2QaL;
        ebKAa:
        ini_set('memory_limit', '-1');
        goto dhb_t;
        nYF_S:
        $nL6dR = $this->ERIyl;
        goto FCQBS;
        dhb_t:
        $TthJZ = $this->qrvF0->getClient();
        goto nYF_S;
        SBFim:
        Log::info("UMeQT1ArE1U05 has been deleted, discard it", ['fileId' => $ElvKF]);
        goto S5Le9;
        Tptnc:
        $XSIXc = $nL6dR->mimeType($pWX2V->getLocation());
        goto oxvsZ;
        WWEyb:
        return;
        goto vIzsC;
        qeNwU:
        $Hc4XF = $nL6dR->readStream($pWX2V->getLocation());
        goto AR10A;
        G2QaL:
        if ($nL6dR->exists($pWX2V->getLocation())) {
            goto g_TLo;
        }
        goto KXsLY;
        KXsLY:
        Log::error("[BYT5DBY3GZZvP] File not found, discard it ", ['video' => $pWX2V->getLocation()]);
        goto WWEyb;
        S5Le9:
        return;
        goto Cgdvx;
        FCQBS:
        $pWX2V = UMeQT1ArE1U05::find($ElvKF);
        goto MMUvh;
        uNtcd:
    }
}
