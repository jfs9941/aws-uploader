<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
class Kf7aQBaDvRG4E implements BlurJobInterface
{
    const diTWl = 15;
    const Owfd3 = 500;
    const P_xoQ = 500;
    private $RFvhw;
    private $K79lK;
    private $HyJkj;
    public function __construct($LDEwd, $yEBaZ, $N7YvB)
    {
        goto FaZFk;
        McbWt:
        $this->K79lK = $yEBaZ;
        goto Hu0qn;
        FaZFk:
        $this->HyJkj = $N7YvB;
        goto McbWt;
        Hu0qn:
        $this->RFvhw = $LDEwd;
        goto jbqlW;
        jbqlW:
    }
    public function blur(string $Qu08p) : void
    {
        goto e8k6b;
        ytc5j:
        $fe3pc->destroy();
        goto PN3Y4;
        Va4S8:
        $u3yva = $this->m6TxZOKmY2G($BfIMd);
        goto UxaDE;
        p7wM7:
        throw new \Exception('Failed to set final permissions on image file: ' . $HWIuu);
        goto f9G0T;
        OwTmR:
        $BfIMd->update(['preview' => $u3yva]);
        goto pOo7F;
        e8k6b:
        $BfIMd = YPgQPiPQjMu1g::findOrFail($Qu08p);
        goto jUQnV;
        PN3Y4:
        if (chmod($HWIuu, 0664)) {
            goto alaBu;
        }
        goto l88Ct;
        PZISm:
        $EsMv0 = $fe3pc->width() / $fe3pc->height();
        goto vareA;
        NUXa3:
        $Bm23p = $this->K79lK->get($BfIMd->filename);
        goto l2lEW;
        VnoO6:
        AvIk3:
        goto oFIOj;
        vvvAo:
        $fe3pc->blur(self::diTWl);
        goto Va4S8;
        vareA:
        $fe3pc->resize(self::Owfd3, self::P_xoQ / $EsMv0);
        goto vvvAo;
        hLKql:
        $fe3pc->save($HWIuu);
        goto ytc5j;
        Dt5WX:
        if (!($BfIMd->LjaQU == NYPGraEb3Ennl::S3 && !$this->HyJkj->exists($BfIMd->filename))) {
            goto AvIk3;
        }
        goto NUXa3;
        oFIOj:
        $fe3pc = $this->RFvhw->call($this, $this->HyJkj->path($BfIMd->getLocation()));
        goto PZISm;
        UxaDE:
        $HWIuu = $this->HyJkj->path($u3yva);
        goto hLKql;
        l2lEW:
        $this->HyJkj->put($BfIMd->filename, $Bm23p);
        goto VnoO6;
        jUQnV:
        ini_set('memory_limit', '-1');
        goto Dt5WX;
        f9G0T:
        alaBu:
        goto OwTmR;
        l88Ct:
        \Log::warning('Failed to set final permissions on image file: ' . $HWIuu);
        goto p7wM7;
        pOo7F:
    }
    private function m6TxZOKmY2G($vyzSI) : string
    {
        goto Uthi_;
        kTRuQ:
        if ($this->HyJkj->exists($zvQmT)) {
            goto AhDyN;
        }
        goto WopNM;
        gW1U4:
        $zvQmT = dirname($TnwL2) . '/preview/';
        goto kTRuQ;
        ALWPy:
        return $zvQmT . $vyzSI->getFilename() . '.jpg';
        goto Snd9d;
        WopNM:
        $this->HyJkj->makeDirectory($zvQmT, 0755, true);
        goto gUuTu;
        gUuTu:
        AhDyN:
        goto ALWPy;
        Uthi_:
        $TnwL2 = $vyzSI->getLocation();
        goto gW1U4;
        Snd9d:
    }
}
