<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Encoder\BM6hyPenlDnb7;
use Jfs\Uploader\Encoder\HQYCEfe5qBMyw;
use Jfs\Uploader\Encoder\TMo64GtkgTgVY;
use Jfs\Uploader\Encoder\RPOmm90py987X;
use Jfs\Uploader\Encoder\XLZ6utKYThkTc;
use Jfs\Uploader\Encoder\HA9dsKJpoey2B;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Jfs\Uploader\Service\Jobs\NHqUenz3Xezly;
use Jfs\Uploader\Service\Jobs\EO53Y7xMvE49W;
use Jfs\Uploader\Service\HHzuA41ccyXtA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class Jo1vXwLFOmnZA implements MediaEncodeJobInterface
{
    private $F_eut;
    private $uTYgy;
    private $tcoQz;
    private $eKoQ3;
    private $T2ciG;
    public function __construct(string $Jkr71, $kVG4M, $v70jj, $p1Hjh, $Vk5rF)
    {
        goto uMoaA;
        ytiLP:
        $this->tcoQz = $v70jj;
        goto KLu2Y;
        BiAl0:
        $this->T2ciG = $Vk5rF;
        goto D2Sug;
        KLu2Y:
        $this->eKoQ3 = $p1Hjh;
        goto BiAl0;
        uMoaA:
        $this->F_eut = $Jkr71;
        goto JS9LX;
        JS9LX:
        $this->uTYgy = $kVG4M;
        goto ytiLP;
        D2Sug:
    }
    public function encode(string $B5uQ4, string $pfZs5, $F9BPR = true) : void
    {
        goto l47sE;
        haEVb:
        try {
            goto OJFNO;
            ZEFdb:
            $usFjp = $usFjp->mcIDCScoGzO($WViDB);
            goto J50wN;
            VGcJj:
            $dWEzY = new BM6hyPenlDnb7($jYLmK->yTEsQ ?? 1, 2, $LJ722->mcFwv3s6QV9($jYLmK));
            goto Hk6nl;
            J2kN4:
            $WViDB = new HQYCEfe5qBMyw('1080p', $Go6Qv['width'], $Go6Qv['height'], $jYLmK->HNOGi ?? 30);
            goto GQN0K;
            zCedj:
            rh3_x:
            goto YrfKf;
            GQN0K:
            $yC135 = $this->mtkCHzvnRz1($DOzS1, $KrdFe->m2ADXial3qe((int) $Go6Qv['width'], (int) $Go6Qv['height'], $pfZs5));
            goto j4_q3;
            OJFNO:
            $jYLmK = CpeNYzI7e1ALA::findOrFail($B5uQ4);
            goto dLmAP;
            dxnFZ:
            $nO8OT = $jYLmK->height();
            goto ekohO;
            gtE_H:
            $usFjp->mzUC8F4kL0s($LJ722->meR9CGDQ79M($jYLmK));
            goto Qj39w;
            cTjrC:
            $iOzks = $iOzks->mfU4KkNlaH0($yC135);
            goto zCedj;
            Qj39w:
            if (!($V0H7W && $nO8OT)) {
                goto nLQRS;
            }
            goto jmKEX;
            fs3Qe:
            $usFjp = $usFjp->mVqU6EsiQF6(new RPOmm90py987X($lomp1));
            goto bwPP8;
            lfn_M:
            $V0H7W = $jYLmK->width();
            goto dxnFZ;
            r0pLg:
            Log::info("Set input video for Job", ['s3Uri' => $lomp1]);
            goto VVCKp;
            J50wN:
            WnXzL:
            goto bEbj3;
            YrfKf:
            $usFjp->mcIDCScoGzO($iOzks);
            goto gtE_H;
            VVCKp:
            $usFjp = app(XLZ6utKYThkTc::class);
            goto fs3Qe;
            fncVn:
            throw new MediaConverterException("CpeNYzI7e1ALA {$jYLmK->id} is not S3 driver");
            goto su2JH;
            lB6XH:
            $yC135 = $this->mtkCHzvnRz1($DOzS1, $KrdFe->m2ADXial3qe($jYLmK->width(), $jYLmK->height(), $pfZs5));
            goto DHGz0;
            Hk6nl:
            $usFjp = $usFjp->mCoV79x0on2($dWEzY);
            goto KwM9Q;
            KwM9Q:
            $B5uQ4 = $usFjp->m6jy7J8ZrGK($this->mOXPrQD14P9($jYLmK, $F9BPR));
            goto fM89u;
            dLmAP:
            Assert::isInstanceOf($jYLmK, CpeNYzI7e1ALA::class);
            goto zZhyV;
            j4_q3:
            if (!$yC135) {
                goto zQbgr;
            }
            goto UUaHQ;
            wTa6M:
            Log::info("Set thumbnail for CpeNYzI7e1ALA Job", ['videoId' => $jYLmK->getAttribute('id'), 'duration' => $jYLmK->getAttribute('duration')]);
            goto VGcJj;
            SgNoZ:
            $usFjp->mcIDCScoGzO($iOzks);
            goto Z6RRv;
            dYX6J:
            $KrdFe = new EO53Y7xMvE49W($this->eKoQ3, $this->T2ciG, $this->tcoQz, $this->uTYgy);
            goto lB6XH;
            bEbj3:
            nLQRS:
            goto wTa6M;
            fM89u:
            $jYLmK->update(['aws_media_converter_job_id' => $B5uQ4]);
            goto dTd_F;
            bSFaY:
            $DOzS1 = app(HHzuA41ccyXtA::class);
            goto dYX6J;
            HPaOB:
            $LJ722 = app(TMo64GtkgTgVY::class);
            goto SgNoZ;
            ekohO:
            $lomp1 = $this->mhI4VtxS5Px($jYLmK);
            goto r0pLg;
            su2JH:
            awZ8v:
            goto lfn_M;
            bwPP8:
            $iOzks = new HQYCEfe5qBMyw('original', $V0H7W, $nO8OT, $jYLmK->HNOGi ?? 30);
            goto HPaOB;
            Z6RRv:
            $usFjp->mzUC8F4kL0s($LJ722->meR9CGDQ79M($jYLmK));
            goto bSFaY;
            suLu5:
            zQbgr:
            goto ZEFdb;
            jmKEX:
            if (!$this->mqMMxQ1jlcL($V0H7W, $nO8OT)) {
                goto WnXzL;
            }
            goto j1Mhc;
            DHGz0:
            if (!$yC135) {
                goto rh3_x;
            }
            goto cTjrC;
            zZhyV:
            if (!($jYLmK->tcavr !== LrHrisEWQ9E5o::S3)) {
                goto awZ8v;
            }
            goto fncVn;
            j1Mhc:
            $Go6Qv = $this->m3pSGI6zkgV($V0H7W, $nO8OT);
            goto jie0m;
            jie0m:
            Log::info("Set 1080p resolution for Job", ['width' => $Go6Qv['width'], 'height' => $Go6Qv['height'], 'originalWidth' => $V0H7W, 'originalHeight' => $nO8OT]);
            goto J2kN4;
            UUaHQ:
            $WViDB = $WViDB->mfU4KkNlaH0($yC135);
            goto suLu5;
            dTd_F:
        } catch (\Exception $xMxrQ) {
            Log::info("CpeNYzI7e1ALA has been deleted, discard it", ['fileId' => $B5uQ4, 'err' => $xMxrQ->getMessage()]);
            return;
        }
        goto RmMUv;
        zHjAD:
        ini_set('memory_limit', '-1');
        goto haEVb;
        l47sE:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $B5uQ4]);
        goto zHjAD;
        RmMUv:
    }
    private function mOXPrQD14P9(CpeNYzI7e1ALA $jYLmK, $F9BPR) : bool
    {
        goto bVz4N;
        w1yDy:
        return false;
        goto ToNM5;
        f1M2f:
        switch (true) {
            case $jYLmK->width() * $jYLmK->height() >= 1920 * 1080 && $jYLmK->width() * $jYLmK->height() < 2560 * 1440:
                return $UYz2A > 10 * 60;
            case $jYLmK->width() * $jYLmK->height() >= 2560 * 1440 && $jYLmK->width() * $jYLmK->height() < 3840 * 2160:
                return $UYz2A > 5 * 60;
            case $jYLmK->width() * $jYLmK->height() >= 3840 * 2160:
                return $UYz2A > 3 * 60;
            default:
                return false;
        }
        goto IhnuT;
        ToNM5:
        MSRkY:
        goto dONew;
        FtMbo:
        SKYhR:
        goto SUAfK;
        dONew:
        $UYz2A = (int) round($jYLmK->getAttribute('duration') ?? 0);
        goto f1M2f;
        bVz4N:
        if ($F9BPR) {
            goto MSRkY;
        }
        goto w1yDy;
        IhnuT:
        d3J2u:
        goto FtMbo;
        SUAfK:
    }
    private function mtkCHzvnRz1(HHzuA41ccyXtA $DOzS1, string $Qtoey) : ?HA9dsKJpoey2B
    {
        goto rIx0O;
        Co2Y6:
        if (!$MccQ1) {
            goto xpNuJ;
        }
        goto kltao;
        Je9aU:
        xpNuJ:
        goto QTLu0;
        kltao:
        return new HA9dsKJpoey2B($MccQ1, 0, 0, null, null);
        goto Je9aU;
        rIx0O:
        $MccQ1 = $DOzS1->mqIYoB5vSE8($Qtoey);
        goto F9spf;
        F9spf:
        Log::info("Resolve watermark for job with url", ['url' => $Qtoey, 'uri' => $MccQ1]);
        goto Co2Y6;
        QTLu0:
        return null;
        goto Vvhlb;
        Vvhlb:
    }
    private function mqMMxQ1jlcL(int $V0H7W, int $nO8OT) : bool
    {
        return $V0H7W * $nO8OT > 1.5 * (1920 * 1080);
    }
    private function m3pSGI6zkgV(int $V0H7W, int $nO8OT) : array
    {
        $R3d6p = new NHqUenz3Xezly($V0H7W, $nO8OT);
        return $R3d6p->mTeFmek5ryr();
    }
    private function mhI4VtxS5Px(UfttW7MErNAIK $gYpY3) : string
    {
        goto Sj60I;
        Sj60I:
        if (!($gYpY3->tcavr == LrHrisEWQ9E5o::S3)) {
            goto hH4uQ;
        }
        goto H6VmV;
        qdmYZ:
        hH4uQ:
        goto dfIg0;
        H6VmV:
        return 's3://' . $this->F_eut . '/' . $gYpY3->filename;
        goto qdmYZ;
        dfIg0:
        return $this->uTYgy->url($gYpY3->filename);
        goto iuYSc;
        iuYSc:
    }
}
