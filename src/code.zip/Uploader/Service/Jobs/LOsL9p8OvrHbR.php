<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class LOsL9p8OvrHbR implements GenerateThumbnailForVideoInterface
{
    private $upEF3;
    public function __construct($feo3q)
    {
        $this->upEF3 = $feo3q;
    }
    public function generate(string $y06DH) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $y06DH);
        $this->upEF3->createThumbnail($y06DH);
    }
}
