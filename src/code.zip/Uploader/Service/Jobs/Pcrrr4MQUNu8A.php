<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Illuminate\Support\Facades\Log;
class Pcrrr4MQUNu8A implements BlurVideoJobInterface
{
    const fNdJA = 15;
    const Jpouv = 500;
    const GG3Av = 500;
    private $o4nAt;
    private $m2kWg;
    private $Jhhox;
    public function __construct($wpWQD, $Npup8, $bXh5v)
    {
        goto LLch4;
        C7Igl:
        $this->o4nAt = $wpWQD;
        goto OWjTF;
        Qy60h:
        $this->m2kWg = $Npup8;
        goto C7Igl;
        LLch4:
        $this->Jhhox = $bXh5v;
        goto Qy60h;
        OWjTF:
    }
    public function blur(string $Brk87) : void
    {
        goto KQOxg;
        Y2QMa:
        unset($Kc1eZ);
        goto i3Q9o;
        cofnE:
        if (!$GeUpC->getAttribute('thumbnail')) {
            goto HMFqA;
        }
        goto qibj7;
        KQOxg:
        Log::info("Blurring for video", ['videoID' => $Brk87]);
        goto Sv1_u;
        i3Q9o:
        if (chmod($gXVhV, 0664)) {
            goto VGV06;
        }
        goto n36Ew;
        ZBmNB:
        HMFqA:
        goto asX7y;
        fV23Y:
        $GeUpC->update(['preview' => $Tp_yG]);
        goto ZBmNB;
        k2YEZ:
        $WT0iE = $Kc1eZ->width() / $Kc1eZ->height();
        goto ZZkk2;
        s3hXh:
        $Kc1eZ->blur(self::fNdJA);
        goto TW2R9;
        wsZPC:
        throw new \Exception('Failed to set final permissions on image file: ' . $gXVhV);
        goto O0xgn;
        TW2R9:
        $Tp_yG = $this->mDJQZopJGq2($GeUpC);
        goto zW9nb;
        qibj7:
        $this->Jhhox->put($GeUpC->getAttribute('thumbnail'), $this->m2kWg->get($GeUpC->getAttribute('thumbnail')));
        goto ELqBs;
        Sv1_u:
        ini_set('memory_limit', '-1');
        goto gyZfv;
        DyvHS:
        $Kc1eZ->save($gXVhV);
        goto zYN5o;
        O0xgn:
        VGV06:
        goto fV23Y;
        zW9nb:
        $gXVhV = $this->Jhhox->path($Tp_yG);
        goto DyvHS;
        ELqBs:
        $Kc1eZ = $this->o4nAt->call($this, $this->Jhhox->path($GeUpC->getAttribute('thumbnail')));
        goto k2YEZ;
        zYN5o:
        $this->m2kWg->put($Tp_yG, $this->Jhhox->get($Tp_yG));
        goto Y2QMa;
        ZZkk2:
        $Kc1eZ->resize(self::Jpouv, self::GG3Av / $WT0iE);
        goto s3hXh;
        n36Ew:
        \Log::warning('Failed to set final permissions on image file: ' . $gXVhV);
        goto wsZPC;
        gyZfv:
        $GeUpC = HVuLZHLrSam0d::findOrFail($Brk87);
        goto cofnE;
        asX7y:
    }
    private function mDJQZopJGq2(HWHmqgxgfYrsZ $u7KkV) : string
    {
        goto k3Wuo;
        CKnAY:
        $this->Jhhox->makeDirectory($e1knD, 0755, true);
        goto Z5_Vg;
        QQz10:
        return $e1knD . $u7KkV->getFilename() . '.jpg';
        goto h9RYd;
        k3Wuo:
        $F0ycc = $u7KkV->getLocation();
        goto Ehaac;
        Z5_Vg:
        ITC5m:
        goto QQz10;
        b52XK:
        if ($this->Jhhox->exists($e1knD)) {
            goto ITC5m;
        }
        goto CKnAY;
        Ehaac:
        $e1knD = dirname($F0ycc) . '/preview/';
        goto b52XK;
        h9RYd:
    }
}
