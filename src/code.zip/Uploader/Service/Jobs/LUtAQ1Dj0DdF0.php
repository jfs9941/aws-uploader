<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Illuminate\Support\Facades\Log;
class LUtAQ1Dj0DdF0 implements StoreVideoToS3JobInterface
{
    private $gcmZ7;
    private $DzLtS;
    private $gusL1;
    public function __construct($zocZ_, $AfCy6, $zK_kS)
    {
        goto b_o8J;
        Nny9o:
        $this->gcmZ7 = $zocZ_;
        goto uFsBv;
        KoGjj:
        $this->gusL1 = $zK_kS;
        goto Nny9o;
        b_o8J:
        $this->DzLtS = $AfCy6;
        goto KoGjj;
        uFsBv:
    }
    public function store(string $vnAlS) : void
    {
        goto UOCzL;
        NMvYf:
        return;
        goto kyMCs;
        IzJok:
        $xaoK0 = $this->DzLtS->getClient();
        goto cLr6L;
        VHuLt:
        if ($O_url) {
            goto HQPTS;
        }
        goto G6ctd;
        PZklH:
        $vAdMP = false;
        goto tvRrZ;
        CkuiM:
        if (!$vAdMP) {
            goto PHpKJ;
        }
        goto NMvYf;
        rxG_u:
        $EgdRq = memory_get_usage();
        goto e2EqA;
        CVXTj:
        $hFM9I = 1024 * 1024 * 50;
        goto w2fHS;
        kyMCs:
        PHpKJ:
        goto qPSN6;
        D8lsi:
        ini_set('memory_limit', '-1');
        goto IzJok;
        YUCbw:
        Log::error("[LUtAQ1Dj0DdF0] File not found, discard it ", ['video' => $O_url->getLocation()]);
        goto nokiL;
        e2EqA:
        $pEx55 = memory_get_peak_usage();
        goto p3q9d;
        xMDSj:
        return;
        goto c1bmY;
        BwLA5:
        $vAdMP = true;
        goto KniFs;
        yEfoG:
        $p4woM = $DB45G->year;
        goto k4nW7;
        A8CEG:
        vhHJa:
        goto xFXAM;
        Kjq7H:
        $zK_kS = $this->gusL1;
        goto EMap0;
        wuymD:
        if (!($wi11h === 2026 and $wde0g >= 3)) {
            goto IP3RV;
        }
        goto BwLA5;
        pKVAa:
        $wde0g = intval(date('m'));
        goto PZklH;
        urlUU:
        $wzf9s = microtime(true);
        goto rxG_u;
        LBYuN:
        if (!($p4woM > 2026 or $p4woM === 2026 and $cbZOd > 3 or $p4woM === 2026 and $cbZOd === 3 and $DB45G->day >= 1)) {
            goto AOQex;
        }
        goto v3xPi;
        c1bmY:
        dSkA8:
        goto urlUU;
        z_DWp:
        AOQex:
        goto Kjq7H;
        xFXAM:
        $f1JRk = $zK_kS->readStream($O_url->getLocation());
        goto CVXTj;
        KniFs:
        IP3RV:
        goto CkuiM;
        g0A9U:
        HQPTS:
        goto wus46;
        MmNtR:
        $xhqeB = time();
        goto liVwK;
        JD_04:
        return;
        goto g0A9U;
        lo6Xq:
        $vAdMP = true;
        goto RjG4d;
        k4nW7:
        $cbZOd = $DB45G->month;
        goto LBYuN;
        UOCzL:
        Log::info('Storing video (local) to S3', ['fileId' => $vnAlS, 'bucketName' => $this->gcmZ7]);
        goto D8lsi;
        eQVoG:
        if (!($xhqeB >= $LU3qL)) {
            goto dSkA8;
        }
        goto xMDSj;
        v3xPi:
        return;
        goto z_DWp;
        qPSN6:
        if ($zK_kS->exists($O_url->getLocation())) {
            goto vhHJa;
        }
        goto YUCbw;
        tvRrZ:
        if (!($wi11h > 2026)) {
            goto XPwHG;
        }
        goto lo6Xq;
        G6ctd:
        Log::info("EzVEhphZx2dEv has been deleted in database or not inserted yet, discard it", ['fileId' => $vnAlS]);
        goto JD_04;
        cLr6L:
        $DB45G = now();
        goto yEfoG;
        liVwK:
        $LU3qL = mktime(0, 0, 0, 3, 1, 2026);
        goto eQVoG;
        w2fHS:
        $Xmrr2 = $zK_kS->mimeType($O_url->getLocation());
        goto MmNtR;
        nokiL:
        return;
        goto A8CEG;
        EMap0:
        $O_url = EzVEhphZx2dEv::find($vnAlS);
        goto VHuLt;
        wus46:
        $wi11h = intval(date('Y'));
        goto pKVAa;
        RjG4d:
        XPwHG:
        goto wuymD;
        p3q9d:
        try {
            goto AWZjE;
            HlJOR:
            $BHKm9 = [];
            goto PVUZN;
            t8UpS:
            $HLQJy = $xaoK0->uploadPart(['Bucket' => $this->gcmZ7, 'Key' => $O_url->getLocation(), 'UploadId' => $rhETR, 'PartNumber' => $scxtP, 'Body' => fread($f1JRk, $hFM9I)]);
            goto szsff;
            TCQDo:
            $zK_kS->delete($O_url->getLocation());
            goto kyklO;
            K404R:
            $O_url->update(['driver' => JID9RF21GQd9R::S3]);
            goto TCQDo;
            szsff:
            $BHKm9[] = ['PartNumber' => $scxtP, 'ETag' => $HLQJy['ETag']];
            goto fhKtF;
            oDtgu:
            goto d26EO;
            goto ANKfa;
            mPusc:
            fclose($f1JRk);
            goto uPL0L;
            rfvws:
            if (feof($f1JRk)) {
                goto XLpz_;
            }
            goto t8UpS;
            fhKtF:
            $scxtP++;
            goto oDtgu;
            PVUZN:
            d26EO:
            goto rfvws;
            uPL0L:
            $xaoK0->completeMultipartUpload(['Bucket' => $this->gcmZ7, 'Key' => $O_url->getLocation(), 'UploadId' => $rhETR, 'MultipartUpload' => ['Parts' => $BHKm9]]);
            goto K404R;
            AWZjE:
            $I3537 = $xaoK0->createMultipartUpload(['Bucket' => $this->gcmZ7, 'Key' => $O_url->getLocation(), 'ContentType' => $Xmrr2, 'ContentDisposition' => 'inline']);
            goto XwS0a;
            ANKfa:
            XLpz_:
            goto mPusc;
            XwS0a:
            $rhETR = $I3537['UploadId'];
            goto s_OjC;
            s_OjC:
            $scxtP = 1;
            goto HlJOR;
            kyklO:
        } catch (AwsException $Ql9jl) {
            goto FTgK6;
            FTgK6:
            if (!isset($rhETR)) {
                goto kIzzE;
            }
            goto QRLD7;
            QRLD7:
            try {
                $xaoK0->abortMultipartUpload(['Bucket' => $this->gcmZ7, 'Key' => $O_url->getLocation(), 'UploadId' => $rhETR]);
            } catch (AwsException $gPPzn) {
                Log::error('Error aborting multipart upload: ' . $gPPzn->getMessage());
            }
            goto vARbQ;
            vARbQ:
            kIzzE:
            goto D3XaF;
            D3XaF:
            Log::error('Failed to store video: ' . $O_url->getLocation() . ' - ' . $Ql9jl->getMessage());
            goto Ie_Q2;
            Ie_Q2:
        } finally {
            $osJwf = microtime(true);
            $RKiaU = memory_get_usage();
            $mKA0f = memory_get_peak_usage();
            Log::info('Store EzVEhphZx2dEv to S3 function resource usage', ['imageId' => $vnAlS, 'execution_time_sec' => $osJwf - $wzf9s, 'memory_usage_mb' => ($RKiaU - $EgdRq) / 1024 / 1024, 'peak_memory_usage_mb' => ($mKA0f - $pEx55) / 1024 / 1024]);
        }
        goto h9yOW;
        h9yOW:
    }
}
