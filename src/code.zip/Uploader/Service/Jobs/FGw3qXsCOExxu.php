<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
class FGw3qXsCOExxu implements CompressJobInterface
{
    const zxjuD = 80;
    private $z59AQ;
    private $kxBLk;
    public function __construct($fbqBq, $dgfeu)
    {
        $this->z59AQ = $fbqBq;
        $this->kxBLk = $dgfeu;
    }
    public function compress(string $y06DH)
    {
        Log::info("Compress image", ['imageId' => $y06DH]);
        try {
            goto x2gN1;
            cwmHA:
            $xO50j = $this->z59AQ->call($this, $j6CkI);
            goto ERTn2;
            pKVyQ:
            $xO50j->save($mxImh, self::zxjuD);
            goto XAE33;
            TWJlg:
            BUj1X:
            goto KWDyn;
            XAE33:
            $xO50j->destroy();
            goto TrO0Q;
            fEnN7:
            $P2AJQ->setAttribute('filename', str_replace('.png', '.jpg', $P2AJQ->getLocation()));
            goto g7UB1;
            h6pYi:
            if (!($P2AJQ->getExtension() === 'png')) {
                goto BUj1X;
            }
            goto N_nEN;
            ERTn2:
            $xO50j->orientate();
            goto pKVyQ;
            N_nEN:
            $P2AJQ->setAttribute('type', 'jpg');
            goto fEnN7;
            KWDyn:
            $mxImh = $this->kxBLk->path($P2AJQ->getLocation());
            goto cwmHA;
            x2gN1:
            $P2AJQ = LGMw063tEE9ZC::findOrFail($y06DH);
            goto CaiN4;
            g7UB1:
            $P2AJQ->save();
            goto TWJlg;
            CaiN4:
            $j6CkI = $this->kxBLk->path($P2AJQ->getLocation());
            goto h6pYi;
            TrO0Q:
        } catch (ModelNotFoundException) {
            Log::info("LGMw063tEE9ZC has been deleted, discard it", ['imageId' => $y06DH]);
        }
    }
}
