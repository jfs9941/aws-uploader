<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class WdWZVKAS2G6OQ
{
    private $ZeTFE;
    private $xq9jr;
    public function __construct(int $pknFe, int $RV7wL)
    {
        goto OEE6y;
        hMmaf:
        $this->ZeTFE = $pknFe;
        goto k3Rgy;
        SC5kb:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto P9RPb;
        P9RPb:
        WNAyG:
        goto YYcpR;
        OEE6y:
        if (!($pknFe <= 0)) {
            goto WNAyG;
        }
        goto SC5kb;
        YYcpR:
        if (!($RV7wL <= 0)) {
            goto TyWd4;
        }
        goto E5MOP;
        k3Rgy:
        $this->xq9jr = $RV7wL;
        goto lduID;
        Zute_:
        TyWd4:
        goto hMmaf;
        E5MOP:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Zute_;
        lduID:
    }
    private static function mHKzOSRJSbS($G11Wv, string $WkQK1 = 'floor') : int
    {
        goto ZkqK_;
        uKjSh:
        switch (strtolower($WkQK1)) {
            case 'ceil':
                return (int) (ceil($G11Wv / 2) * 2);
            case 'round':
                return (int) (round($G11Wv / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($G11Wv / 2) * 2);
        }
        goto BUG10;
        c3RRb:
        if (!(is_float($G11Wv) && $G11Wv == floor($G11Wv) && (int) $G11Wv % 2 === 0)) {
            goto gGk1h;
        }
        goto uiB8g;
        BUG10:
        M_7FQ:
        goto faSu1;
        uiB8g:
        return (int) $G11Wv;
        goto j0h53;
        j0h53:
        gGk1h:
        goto uKjSh;
        UP5NR:
        return $G11Wv;
        goto aQ5Nf;
        ZkqK_:
        if (!(is_int($G11Wv) && $G11Wv % 2 === 0)) {
            goto J0NhG;
        }
        goto UP5NR;
        faSu1:
        w4OpQ:
        goto D6UGa;
        aQ5Nf:
        J0NhG:
        goto c3RRb;
        D6UGa:
    }
    public function m0GQWft94gB(string $vA3ro = 'floor') : array
    {
        goto a0kzF;
        fiAIJ:
        if (!($z1faF < 2)) {
            goto t_ggU;
        }
        goto L4Sm6;
        dre8F:
        $BLSy9 = self::mHKzOSRJSbS(round($J1GSz), $vA3ro);
        goto KEsSl;
        UYNuS:
        qDA6q:
        goto fiAIJ;
        j7bYK:
        if ($this->ZeTFE >= $this->xq9jr) {
            goto hwdSj;
        }
        goto R18sb;
        Giz20:
        $BLSy9 = 2;
        goto UYNuS;
        B2g6I:
        return ['width' => $BLSy9, 'height' => $z1faF];
        goto ArQ0D;
        R18sb:
        $BLSy9 = $LQb4F;
        goto j1jW0;
        KEsSl:
        tBct0:
        goto E8Afy;
        xyJoB:
        hwdSj:
        goto f_s9r;
        E8Afy:
        if (!($BLSy9 < 2)) {
            goto qDA6q;
        }
        goto Giz20;
        j1jW0:
        $FHB_E = $BLSy9 / $this->ZeTFE;
        goto EiKKt;
        a0kzF:
        $LQb4F = 1080;
        goto MpPUU;
        IezFL:
        $J1GSz = $this->ZeTFE * $FHB_E;
        goto dre8F;
        L4Sm6:
        $z1faF = 2;
        goto zEpnG;
        f_s9r:
        $z1faF = $LQb4F;
        goto BN2Ly;
        BN2Ly:
        $FHB_E = $z1faF / $this->xq9jr;
        goto IezFL;
        wyAtO:
        $z1faF = self::mHKzOSRJSbS(round($SuX0Y), $vA3ro);
        goto oJWlg;
        oJWlg:
        goto tBct0;
        goto xyJoB;
        qZ5Bl:
        $z1faF = 0;
        goto j7bYK;
        MpPUU:
        $BLSy9 = 0;
        goto qZ5Bl;
        zEpnG:
        t_ggU:
        goto B2g6I;
        EiKKt:
        $SuX0Y = $this->xq9jr * $FHB_E;
        goto wyAtO;
        ArQ0D:
    }
}
