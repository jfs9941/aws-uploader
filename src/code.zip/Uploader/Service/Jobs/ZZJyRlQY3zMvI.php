<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class ZZJyRlQY3zMvI implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $J_scC) : void
    {
        goto FT03w;
        eClhY:
        gj8T6:
        goto ej2A8;
        d9dhL:
        $this->mmYQVdjiISS($Zpy0I);
        goto eClhY;
        FT03w:
        $Zpy0I = BG2FRpwGrKqJx::findOrFail($J_scC);
        goto u8Xwe;
        u8Xwe:
        if ($Zpy0I->width() > 0 && $Zpy0I->height() > 0) {
            goto gj8T6;
        }
        goto d9dhL;
        ej2A8:
    }
    private function mmYQVdjiISS(BG2FRpwGrKqJx $b55fD) : void
    {
        goto UDmsj;
        hwkPB:
        $E_p_r = $xOfLc->getDimensions();
        goto JXPik;
        UDmsj:
        $L5ARZ = $b55fD->getView();
        goto aKc3r;
        JXPik:
        $b55fD->update(['duration' => $wiCE2->getDurationInSeconds(), 'resolution' => $E_p_r->getWidth() . 'x' . $E_p_r->getHeight(), 'fps' => $xOfLc->get('r_frame_rate') ?? 30]);
        goto ObXcO;
        MxklR:
        $xOfLc = $wiCE2->getVideoStream();
        goto hwkPB;
        aKc3r:
        $wiCE2 = FFMpeg::fromDisk($L5ARZ['path'])->open($b55fD->getAttribute('filename'));
        goto MxklR;
        ObXcO:
    }
}
