<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class MARg2GurDnSiZ implements StoreToS3JobInterface
{
    private $SJRrZ;
    private $gGE8I;
    private $xbA_A;
    public function __construct($akc4V, $duBfR, $a_5ue)
    {
        goto YP_68;
        ZSDaT:
        $this->SJRrZ = $akc4V;
        goto RUHiC;
        BqLaJ:
        $this->xbA_A = $a_5ue;
        goto ZSDaT;
        YP_68:
        $this->gGE8I = $duBfR;
        goto BqLaJ;
        RUHiC:
    }
    public function store(string $ld8Ad) : void
    {
        goto cPFYB;
        KoFY8:
        $jGQTt = $this->xbA_A->path($UyUkP->getLocation());
        goto wvz0v;
        xEqg3:
        $g8Jx5 = $UyUkP->getAttribute('thumbnail');
        goto i8YG7;
        df9Ie:
        Log::info("Sf7MFJ2wUSx2k has been deleted, discard it", ['fileId' => $ld8Ad]);
        goto nJCMk;
        ge5EJ:
        H0mnP:
        goto p1tW1;
        A6kWb:
        Sf7MFJ2wUSx2k::where('parent_id', $ld8Ad)->update(['driver' => ZBLpZ2qUZ4P6C::S3, 'preview' => $UyUkP->getAttribute('preview'), 'thumbnail' => $UyUkP->getAttribute('thumbnail'), 'webp_path' => $UyUkP->getAttribute('webp_path')]);
        goto ZMPZO;
        cy3J3:
        $this->gGE8I->put($UyUkP->getAttribute('thumbnail'), $this->xbA_A->get($g8Jx5), ['visibility' => 'public', 'ContentType' => $pBU9S->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto dGGa3;
        JGF4W:
        $this->gGE8I->put($UyUkP->getAttribute('preview'), $this->xbA_A->get($UyUkP->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $V8DQZ->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto ge5EJ;
        zspSw:
        if ($UyUkP) {
            goto CpA1f;
        }
        goto df9Ie;
        p1tW1:
        if (!$UyUkP->update(['driver' => ZBLpZ2qUZ4P6C::S3, 'status' => UimQKBIuLCEAO::FINISHED])) {
            goto JSWDi;
        }
        goto Onv1g;
        bBBvk:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $ld8Ad]);
        goto JSKgx;
        Wpmyp:
        $this->mdMlQUXvgN6($jGQTt, $UyUkP->getLocation(), '.webp');
        goto xEqg3;
        ZMPZO:
        return;
        goto gOcQb;
        FVU5x:
        $ky3cI = $this->xbA_A->path($g8Jx5);
        goto YU2oT;
        YU2oT:
        $pBU9S = $this->SJRrZ->call($this, $ky3cI);
        goto cy3J3;
        cPFYB:
        $UyUkP = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
        goto zspSw;
        i8YG7:
        if (!($g8Jx5 && $this->xbA_A->exists($g8Jx5))) {
            goto Midke;
        }
        goto FVU5x;
        dGGa3:
        Midke:
        goto LLa4j;
        nJCMk:
        return;
        goto ldAD_;
        LLa4j:
        if (!($UyUkP->getAttribute('preview') && $this->xbA_A->exists($UyUkP->getAttribute('preview')))) {
            goto H0mnP;
        }
        goto NzhHf;
        NzhHf:
        $DYrgW = $this->xbA_A->path($UyUkP->getAttribute('preview'));
        goto ovBF9;
        wvz0v:
        $this->mdMlQUXvgN6($jGQTt, $UyUkP->getLocation());
        goto Wpmyp;
        ldAD_:
        CpA1f:
        goto KoFY8;
        Onv1g:
        Log::info("Sf7MFJ2wUSx2k stored to S3, update the children attachments", ['fileId' => $ld8Ad]);
        goto A6kWb;
        ovBF9:
        $V8DQZ = $this->SJRrZ->call($this, $DYrgW);
        goto JGF4W;
        gOcQb:
        JSWDi:
        goto bBBvk;
        JSKgx:
    }
    private function mdMlQUXvgN6($k0dKU, $BCYvI, $vdt1g = '')
    {
        goto aPd3y;
        iVX1J:
        $k0dKU = str_replace('.jpg', $vdt1g, $k0dKU);
        goto WEHS0;
        aPd3y:
        if (!$vdt1g) {
            goto kY1li;
        }
        goto iVX1J;
        WEHS0:
        $BCYvI = str_replace('.jpg', $vdt1g, $BCYvI);
        goto cahqh;
        HIFU2:
        try {
            $xobEP = $this->SJRrZ->call($this, $k0dKU);
            $this->gGE8I->put($BCYvI, $this->xbA_A->get($BCYvI), ['visibility' => 'public', 'ContentType' => $xobEP->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $I8puu) {
            Log::error("Failed to upload image to S3", ['s3Path' => $BCYvI, 'error' => $I8puu->getMessage()]);
        }
        goto zalJq;
        cahqh:
        kY1li:
        goto HIFU2;
        zalJq:
    }
}
