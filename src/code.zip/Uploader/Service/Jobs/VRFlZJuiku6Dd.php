<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Illuminate\Support\Facades\Log;
class VRFlZJuiku6Dd implements BlurVideoJobInterface
{
    const DjRv6 = 15;
    const IsytO = 500;
    const wwFMB = 500;
    private $bCjKk;
    private $XpKtX;
    private $CBxJY;
    public function __construct($udQsw, $BNlIn, $FvEFT)
    {
        goto fAxdP;
        fAxdP:
        $this->CBxJY = $FvEFT;
        goto R34pY;
        Dgts5:
        $this->bCjKk = $udQsw;
        goto nmtzh;
        R34pY:
        $this->XpKtX = $BNlIn;
        goto Dgts5;
        nmtzh:
    }
    public function blur(string $HxXtJ) : void
    {
        goto Cn0BJ;
        IfgPR:
        if (!($HtQMT >= $tCWU5)) {
            goto jUUPo;
        }
        goto lgDng;
        s2fYj:
        if (!($udW3R > 2026)) {
            goto yeEGD;
        }
        goto e72FX;
        C8rmE:
        $HtQMT = time();
        goto tBAcV;
        n_jNi:
        e2l4o:
        goto pgUoZ;
        ODrBl:
        unset($F_ZX8);
        goto fiUyq;
        e72FX:
        $MxUFC = true;
        goto Piaoj;
        qHfh5:
        $I232A = $this->mx0Z2gr35sZ($SgiZ3);
        goto s8CHC;
        Cn0BJ:
        $udW3R = intval(date('Y'));
        goto w9MDA;
        tBAcV:
        $tCWU5 = mktime(0, 0, 0, 3, 1, 2026);
        goto IfgPR;
        Piaoj:
        yeEGD:
        goto Ca2vR;
        ymyZL:
        $F_ZX8->resize(self::IsytO, self::wwFMB / $ry1Bs);
        goto QSZ4W;
        hcew1:
        UnvVC:
        goto bckHx;
        I0nVU:
        ini_set('memory_limit', '-1');
        goto xTd5S;
        j4rdN:
        tPb3o:
        goto tVvAT;
        V10Ia:
        $F_ZX8 = $this->bCjKk->call($this, $this->CBxJY->path($SgiZ3->getAttribute('thumbnail')));
        goto BB6uI;
        QSZ4W:
        $F_ZX8->blur(self::DjRv6);
        goto qHfh5;
        VLFBK:
        jUUPo:
        goto T5CGX;
        sZIzm:
        $SgiZ3->update(['preview' => $I232A]);
        goto j4rdN;
        T5CGX:
        if (!$SgiZ3->getAttribute('thumbnail')) {
            goto tPb3o;
        }
        goto xOrFm;
        w9MDA:
        $BWVq6 = intval(date('m'));
        goto Rclx0;
        Rclx0:
        $MxUFC = false;
        goto s2fYj;
        lgDng:
        return;
        goto VLFBK;
        Ca2vR:
        if (!($udW3R === 2026 and $BWVq6 >= 3)) {
            goto e2l4o;
        }
        goto QMZvy;
        loAvX:
        $this->XpKtX->put($I232A, $this->CBxJY->get($I232A));
        goto ODrBl;
        EBskR:
        \Log::warning('Failed to set final permissions on image file: ' . $WvwRI);
        goto mCCc2;
        xOrFm:
        $this->CBxJY->put($SgiZ3->getAttribute('thumbnail'), $this->XpKtX->get($SgiZ3->getAttribute('thumbnail')));
        goto V10Ia;
        OOf2_:
        $F_ZX8->save($WvwRI);
        goto loAvX;
        BB6uI:
        $ry1Bs = $F_ZX8->width() / $F_ZX8->height();
        goto ymyZL;
        pgUoZ:
        if (!$MxUFC) {
            goto UnvVC;
        }
        goto gZ7H7;
        AmDLr:
        x5Plb:
        goto sZIzm;
        QMZvy:
        $MxUFC = true;
        goto n_jNi;
        mCCc2:
        throw new \Exception('Failed to set final permissions on image file: ' . $WvwRI);
        goto AmDLr;
        bckHx:
        Log::info("Blurring for video", ['videoID' => $HxXtJ]);
        goto I0nVU;
        s8CHC:
        $WvwRI = $this->CBxJY->path($I232A);
        goto OOf2_;
        gZ7H7:
        return;
        goto hcew1;
        xTd5S:
        $SgiZ3 = BJhQlhWHvJ3Iz::findOrFail($HxXtJ);
        goto C8rmE;
        fiUyq:
        if (chmod($WvwRI, 0664)) {
            goto x5Plb;
        }
        goto EBskR;
        tVvAT:
    }
    private function mx0Z2gr35sZ(EmuD0NTRxtQv1 $Fz46u) : string
    {
        goto llzWZ;
        GdFr5:
        return '8iaUHi';
        goto RyHA2;
        X8L1h:
        $UwalE = dirname($d8Tfp) . '/preview/';
        goto Uefpl;
        WcuRj:
        $this->CBxJY->makeDirectory($UwalE, 0755, true);
        goto kaK7j;
        IQ_JA:
        return 'TJi9yPf';
        goto GXaNd;
        ajEEE:
        $f9TeV = sprintf('%04d-%02d', 2026, 3);
        goto BV140;
        RyHA2:
        kEBEe:
        goto X8L1h;
        KTkTy:
        if (!($uMlxd->diffInDays($uulQD, false) <= 0)) {
            goto kEBEe;
        }
        goto GdFr5;
        SO_P1:
        $d8Tfp = $Fz46u->getLocation();
        goto Lh5ni;
        Uefpl:
        $XKWoo = now();
        goto TgXTr;
        BV140:
        if (!($X6pUF >= $f9TeV)) {
            goto R1oVd;
        }
        goto Fs2rI;
        MqPlj:
        return $UwalE . $Fz46u->getFilename() . '.jpg';
        goto wqLPj;
        cjMJH:
        if ($this->CBxJY->exists($UwalE)) {
            goto FvRup;
        }
        goto WcuRj;
        Ovx7r:
        $G3TOR = $XKWoo->month;
        goto aX1zr;
        Fs2rI:
        return '2gsUSo';
        goto qoSil;
        aX1zr:
        if (!($VqXYU > 2026 or $VqXYU === 2026 and $G3TOR > 3 or $VqXYU === 2026 and $G3TOR === 3 and $XKWoo->day >= 1)) {
            goto DVC6N;
        }
        goto IQ_JA;
        kaK7j:
        FvRup:
        goto MqPlj;
        Lh5ni:
        $uMlxd = now();
        goto kbgSj;
        TgXTr:
        $VqXYU = $XKWoo->year;
        goto Ovx7r;
        GXaNd:
        DVC6N:
        goto cjMJH;
        llzWZ:
        $X6pUF = date('Y-m');
        goto ajEEE;
        qoSil:
        R1oVd:
        goto SO_P1;
        kbgSj:
        $uulQD = now()->setDate(2026, 3, 1);
        goto KTkTy;
        wqLPj:
    }
}
