<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Illuminate\Support\Facades\Log;
class SiDF171XuEmgz implements StoreVideoToS3JobInterface
{
    private $t2TIB;
    private $m2kWg;
    private $Jhhox;
    public function __construct($b7Jn7, $Npup8, $bXh5v)
    {
        goto MeG73;
        MeG73:
        $this->m2kWg = $Npup8;
        goto TBUIX;
        TBUIX:
        $this->Jhhox = $bXh5v;
        goto mfck_;
        mfck_:
        $this->t2TIB = $b7Jn7;
        goto GdePB;
        GdePB:
    }
    public function store(string $Brk87) : void
    {
        goto SS5FB;
        w18UI:
        if ($bXh5v->exists($OQ402->getLocation())) {
            goto mI4Al;
        }
        goto oV7yB;
        SK9cn:
        return;
        goto NtOaS;
        SS5FB:
        Log::info('Storing video (local) to S3', ['fileId' => $Brk87, 'bucketName' => $this->t2TIB]);
        goto Ei11s;
        YFNoe:
        if ($OQ402) {
            goto GSrFA;
        }
        goto W0u_u;
        cPJHt:
        $aRKLJ = microtime(true);
        goto S7Vb4;
        pzxze:
        $vFfCI = $this->m2kWg->getClient();
        goto RClUX;
        S7Vb4:
        $aPZAx = memory_get_usage();
        goto uGfSD;
        Le6cs:
        $OQ402 = HVuLZHLrSam0d::find($Brk87);
        goto YFNoe;
        oV7yB:
        Log::error("[SiDF171XuEmgz] File not found, discard it ", ['video' => $OQ402->getLocation()]);
        goto jYKlk;
        RClUX:
        $bXh5v = $this->Jhhox;
        goto Le6cs;
        qKTe8:
        try {
            goto DURht;
            KqYD8:
            $agIIp++;
            goto cghGa;
            RitQH:
            $vZh2W[] = ['PartNumber' => $agIIp, 'ETag' => $av3B3['ETag']];
            goto KqYD8;
            cghGa:
            goto EAxqt;
            goto kG4AU;
            OKlBK:
            $agIIp = 1;
            goto S8WsE;
            kG4AU:
            dZ9aD:
            goto dKbMg;
            lQJkk:
            $bXh5v->delete($OQ402->getLocation());
            goto DSSDs;
            Pr2g1:
            EAxqt:
            goto n_h4E;
            xdmI3:
            $av3B3 = $vFfCI->uploadPart(['Bucket' => $this->t2TIB, 'Key' => $OQ402->getLocation(), 'UploadId' => $dhlfo, 'PartNumber' => $agIIp, 'Body' => fread($Nz_ex, $Kgya3)]);
            goto RitQH;
            dKbMg:
            fclose($Nz_ex);
            goto YahAs;
            n_h4E:
            if (feof($Nz_ex)) {
                goto dZ9aD;
            }
            goto xdmI3;
            Twz9e:
            $OQ402->update(['driver' => NFXMub09wSQVu::S3, 'status' => ZVJoOgH14iXBq::FINISHED]);
            goto lQJkk;
            YahAs:
            $vFfCI->completeMultipartUpload(['Bucket' => $this->t2TIB, 'Key' => $OQ402->getLocation(), 'UploadId' => $dhlfo, 'MultipartUpload' => ['Parts' => $vZh2W]]);
            goto Twz9e;
            MhJCg:
            $dhlfo = $EF1_E['UploadId'];
            goto OKlBK;
            DURht:
            $EF1_E = $vFfCI->createMultipartUpload(['Bucket' => $this->t2TIB, 'Key' => $OQ402->getLocation(), 'ContentType' => $HZ_7B, 'ContentDisposition' => 'inline']);
            goto MhJCg;
            S8WsE:
            $vZh2W = [];
            goto Pr2g1;
            DSSDs:
        } catch (AwsException $fGlZL) {
            goto xw3Qp;
            xw3Qp:
            if (!isset($dhlfo)) {
                goto rdltI;
            }
            goto FonY2;
            mbjb7:
            Log::error('Failed to store video: ' . $OQ402->getLocation() . ' - ' . $fGlZL->getMessage());
            goto HCwlB;
            FonY2:
            try {
                $vFfCI->abortMultipartUpload(['Bucket' => $this->t2TIB, 'Key' => $OQ402->getLocation(), 'UploadId' => $dhlfo]);
            } catch (AwsException $B6C34) {
                Log::error('Error aborting multipart upload: ' . $B6C34->getMessage());
            }
            goto hsv1M;
            hsv1M:
            rdltI:
            goto mbjb7;
            HCwlB:
        } finally {
            $Gy4_y = microtime(true);
            $aEdXV = memory_get_usage();
            $pE3ho = memory_get_peak_usage();
            Log::info('Store HVuLZHLrSam0d to S3 function resource usage', ['imageId' => $Brk87, 'execution_time_sec' => $Gy4_y - $aRKLJ, 'memory_usage_mb' => ($aEdXV - $aPZAx) / 1024 / 1024, 'peak_memory_usage_mb' => ($pE3ho - $NzcES) / 1024 / 1024]);
        }
        goto ecs_1;
        NtOaS:
        GSrFA:
        goto w18UI;
        jYKlk:
        return;
        goto jvf0m;
        uGfSD:
        $NzcES = memory_get_peak_usage();
        goto qKTe8;
        Catjf:
        $HZ_7B = $bXh5v->mimeType($OQ402->getLocation());
        goto cPJHt;
        tSMmJ:
        $Kgya3 = 1024 * 1024 * 50;
        goto Catjf;
        Ei11s:
        ini_set('memory_limit', '-1');
        goto pzxze;
        W0u_u:
        Log::info("HVuLZHLrSam0d has been deleted, discard it", ['fileId' => $Brk87]);
        goto SK9cn;
        jvf0m:
        mI4Al:
        goto dZdx6;
        dZdx6:
        $Nz_ex = $bXh5v->readStream($OQ402->getLocation());
        goto tSMmJ;
        ecs_1:
    }
}
