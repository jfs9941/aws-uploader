<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Service\Jobs\JQoP3jKbYunC3;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class WVxsT78OVKxMa implements WatermarkTextJobInterface
{
    private $buleS;
    private $aAXO2;
    private $PVphm;
    private $UoQI7;
    private $SIeOC;
    public function __construct($nFvaK, $ZSFKK, $UjVft, $Ay4fJ, $cs2zq)
    {
        goto qpaV7;
        q4jdh:
        $this->aAXO2 = $ZSFKK;
        goto dig2C;
        qpaV7:
        $this->buleS = $nFvaK;
        goto oVm4P;
        SJ8T3:
        $this->PVphm = $cs2zq;
        goto q4jdh;
        B3PVe:
        $this->SIeOC = $Ay4fJ;
        goto SJ8T3;
        oVm4P:
        $this->UoQI7 = $UjVft;
        goto B3PVe;
        dig2C:
    }
    public function putWatermark(string $InHEz, string $ubwD6) : void
    {
        goto yGyIV;
        gXNDX:
        $TNT8K = memory_get_usage();
        goto QO5Js;
        QO5Js:
        $LOR1V = memory_get_peak_usage();
        goto F_htT;
        yGyIV:
        $Eceqa = microtime(true);
        goto gXNDX;
        HhJmH:
        ini_set('memory_limit', '-1');
        goto lbL4u;
        lbL4u:
        try {
            goto syuXJ;
            OHYlG:
            $PI2hl = $this->buleS->call($this, $hKqqZ);
            goto EdYkF;
            Is2tn:
            throw new \Exception('Failed to set final permissions on image file: ' . $hKqqZ);
            goto jpZBV;
            am5GD:
            $hKqqZ = $this->SIeOC->path($VGttq->getLocation());
            goto OHYlG;
            I1Mh1:
            $this->mZlLT2ebu6h($PI2hl, $ubwD6);
            goto nuW8f;
            Bdhjr:
            if (chmod($hKqqZ, 0664)) {
                goto ho7h1;
            }
            goto DswHP;
            oKBJa:
            return;
            goto igz9P;
            syuXJ:
            $VGttq = UKkbXBDRxjSUY::findOrFail($InHEz);
            goto ibDyU;
            DswHP:
            \Log::warning('Failed to set final permissions on image file: ' . $hKqqZ);
            goto Is2tn;
            EdYkF:
            $PI2hl->orient();
            goto I1Mh1;
            igz9P:
            O01dP:
            goto am5GD;
            nuW8f:
            $this->UoQI7->put($hKqqZ, $PI2hl->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto BbZYw;
            BbZYw:
            unset($PI2hl);
            goto Bdhjr;
            WxMjb:
            Log::error("UKkbXBDRxjSUY is not on local, might be deleted before put watermark", ['imageId' => $InHEz]);
            goto oKBJa;
            jpZBV:
            ho7h1:
            goto dXxVE;
            ibDyU:
            if ($this->SIeOC->exists($VGttq->getLocation())) {
                goto O01dP;
            }
            goto WxMjb;
            dXxVE:
        } catch (\Throwable $R_Eyh) {
            goto qnTQU;
            AcWNp:
            Log::error("UKkbXBDRxjSUY is not readable", ['imageId' => $InHEz, 'error' => $R_Eyh->getMessage()]);
            goto IBCf1;
            rLFvH:
            Log::info("UKkbXBDRxjSUY has been deleted, discard it", ['imageId' => $InHEz]);
            goto twRo5;
            qnTQU:
            if (!$R_Eyh instanceof ModelNotFoundException) {
                goto JLY1R;
            }
            goto rLFvH;
            d_2UF:
            JLY1R:
            goto AcWNp;
            twRo5:
            return;
            goto d_2UF;
            IBCf1:
        } finally {
            $xYgEl = microtime(true);
            $FqOnS = memory_get_usage();
            $U8b7Q = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $InHEz, 'execution_time_sec' => $xYgEl - $Eceqa, 'memory_usage_mb' => ($FqOnS - $TNT8K) / 1024 / 1024, 'peak_memory_usage_mb' => ($U8b7Q - $LOR1V) / 1024 / 1024]);
        }
        goto nBCYS;
        F_htT:
        Log::info("Adding watermark text to image", ['imageId' => $InHEz]);
        goto HhJmH;
        nBCYS:
    }
    private function mZlLT2ebu6h($PI2hl, $ubwD6) : void
    {
        goto WWelC;
        Tvt3x:
        $this->SIeOC->put($dbwrp, $this->UoQI7->get($dbwrp));
        goto SRa2T;
        MN0lF:
        $PI2hl->place($VGZeQ, 'top-left', 0, 0, 30);
        goto Vwjio;
        YgvKm:
        $Tdnut = new JQoP3jKbYunC3($this->aAXO2, $this->PVphm, $this->UoQI7, $this->SIeOC);
        goto fptcn;
        SRa2T:
        $VGZeQ = $this->buleS->call($this, $this->SIeOC->path($dbwrp));
        goto MN0lF;
        fptcn:
        $dbwrp = $Tdnut->mF7paffjixE($k2slg, $vci_g, $ubwD6, true);
        goto Tvt3x;
        iAlx5:
        $vci_g = $PI2hl->height();
        goto YgvKm;
        WWelC:
        $k2slg = $PI2hl->width();
        goto iAlx5;
        Vwjio:
    }
}
