<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Encoder\MmrtqP9zAx1EE;
use Jfs\Uploader\Encoder\Di7wGPfsbBXHu;
use Jfs\Uploader\Encoder\Z476P5MAXqSnV;
use Jfs\Uploader\Encoder\VmOEcjiWKEEdZ;
use Jfs\Uploader\Encoder\QAZGS1jBxOIat;
use Jfs\Uploader\Encoder\R8oCerQxKXZb6;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
use Jfs\Uploader\Service\Cjv3UOrDUgWrC;
use Webmozart\Assert\Assert;
class XL9VMQm4mpnzT implements MediaEncodeJobInterface
{
    private $q3TFM;
    private $x0wV5;
    private $K79lK;
    private $QFCsF;
    private $G2Xe3;
    public function __construct(string $ahaqc, $mHTSY, $yEBaZ, $OPDJh, $lCUIp)
    {
        goto FkibH;
        FkibH:
        $this->q3TFM = $ahaqc;
        goto l2hqc;
        zStCU:
        $this->QFCsF = $OPDJh;
        goto MBrDv;
        MBrDv:
        $this->G2Xe3 = $lCUIp;
        goto I1zmT;
        l2hqc:
        $this->x0wV5 = $mHTSY;
        goto UvLp4;
        UvLp4:
        $this->K79lK = $yEBaZ;
        goto zStCU;
        I1zmT:
    }
    public function encode(string $Qu08p, string $S9w3S, $XyS0P = true) : void
    {
        goto WrZMU;
        up13G:
        try {
            goto kYSvo;
            B0JGS:
            $DUZKC = $DUZKC->mpIdw95C9GV($O8BOu);
            goto npywK;
            m94j_:
            Assert::isInstanceOf($X0ufS, SmhkgG6le5p0r::class);
            goto EFBbh;
            Mzcaj:
            Fxwsp:
            goto PcJoh;
            PcJoh:
            $qFAp6 = $X0ufS->width();
            goto sv3eW;
            n6GrG:
            fT839:
            goto OPlJz;
            H8hv5:
            JmPhk:
            goto tiQVW;
            RqAyb:
            $DUZKC = app(QAZGS1jBxOIat::class);
            goto SYjgg;
            Lrvzd:
            $qrahj = app(Cjv3UOrDUgWrC::class);
            goto cTvcB;
            L_n_a:
            $DUZKC = $DUZKC->mzrA1hpk7ho($oWI4J);
            goto H8hv5;
            tBBTA:
            $NCoOp = $this->muej7NuKxdt($qFAp6, $bxUTl);
            goto sYjt4;
            t07Zq:
            $mh495 = app(Z476P5MAXqSnV::class);
            goto eiJC6;
            rT_Jm:
            $oWI4J = $oWI4J->mcKAqu9DIaP($jOOae);
            goto ig1cI;
            Yiz4E:
            $O8BOu = new MmrtqP9zAx1EE($X0ufS->hF8JB ?? 1, 2, $mh495->mGgYqxoSc43($X0ufS));
            goto B0JGS;
            MKgC6:
            throw new MediaConverterException("SmhkgG6le5p0r {$X0ufS->id} is not S3 driver");
            goto Mzcaj;
            ig1cI:
            jM_wW:
            goto L_n_a;
            cTvcB:
            $JJXLO = new R40XH3H6TVben($this->QFCsF, $this->G2Xe3, $this->K79lK, $this->x0wV5);
            goto RwHt3;
            sv3eW:
            $bxUTl = $X0ufS->height();
            goto w5Okd;
            LwJ4v:
            if (!$this->mRUzHpg8mQ8($qFAp6, $bxUTl)) {
                goto JmPhk;
            }
            goto tBBTA;
            SYjgg:
            $DUZKC = $DUZKC->mtwH6QVFxd0(new VmOEcjiWKEEdZ($Tx1j7));
            goto BDtoL;
            RwHt3:
            $jOOae = $this->mntVSRUH8Rj($qrahj, $JJXLO->m2IlDRXB6cD($X0ufS->width(), $X0ufS->height(), $S9w3S));
            goto o1lhb;
            YK2Pd:
            $X0ufS->update(['aws_media_converter_job_id' => $Qu08p]);
            goto q8poP;
            OHDuA:
            Log::info("Set input video for Job", ['s3Uri' => $Tx1j7]);
            goto RqAyb;
            e3lmJ:
            if (!$jOOae) {
                goto jM_wW;
            }
            goto rT_Jm;
            eiJC6:
            $DUZKC->mzrA1hpk7ho($CphiT);
            goto H34x8;
            sYjt4:
            Log::info("Set 1080p resolution for Job", ['width' => $NCoOp['width'], 'height' => $NCoOp['height'], 'originalWidth' => $qFAp6, 'originalHeight' => $bxUTl]);
            goto Ckq1s;
            lkigf:
            Log::info("Set thumbnail for SmhkgG6le5p0r Job", ['videoId' => $X0ufS->getAttribute('id'), 'duration' => $X0ufS->getAttribute('duration')]);
            goto Yiz4E;
            npywK:
            $Qu08p = $DUZKC->mkASZN1bpeL($this->mIRv5jIxrgU($X0ufS, $XyS0P));
            goto YK2Pd;
            O5O8c:
            $jOOae = $this->mntVSRUH8Rj($qrahj, $JJXLO->m2IlDRXB6cD((int) $NCoOp['width'], (int) $NCoOp['height'], $S9w3S));
            goto e3lmJ;
            iHf8i:
            $DUZKC->mFJwnDhqYOS($mh495->mJjadSDLkeJ($X0ufS));
            goto wNBZb;
            H34x8:
            $DUZKC->mFJwnDhqYOS($mh495->mJjadSDLkeJ($X0ufS));
            goto Lrvzd;
            wNBZb:
            if (!($qFAp6 && $bxUTl)) {
                goto Me8a5;
            }
            goto LwJ4v;
            BDtoL:
            $CphiT = new Di7wGPfsbBXHu('original', $qFAp6, $bxUTl, $X0ufS->feDR3 ?? 30);
            goto t07Zq;
            tiQVW:
            Me8a5:
            goto lkigf;
            MEZDE:
            $CphiT = $CphiT->mcKAqu9DIaP($jOOae);
            goto n6GrG;
            Ckq1s:
            $oWI4J = new Di7wGPfsbBXHu('1080p', $NCoOp['width'], $NCoOp['height'], $X0ufS->feDR3 ?? 30);
            goto O5O8c;
            EFBbh:
            if (!($X0ufS->LjaQU !== NYPGraEb3Ennl::S3)) {
                goto Fxwsp;
            }
            goto MKgC6;
            w5Okd:
            $Tx1j7 = $this->mU60j122Kur($X0ufS);
            goto OHDuA;
            OPlJz:
            $DUZKC->mzrA1hpk7ho($CphiT);
            goto iHf8i;
            kYSvo:
            $X0ufS = SmhkgG6le5p0r::findOrFail($Qu08p);
            goto m94j_;
            o1lhb:
            if (!$jOOae) {
                goto fT839;
            }
            goto MEZDE;
            q8poP:
        } catch (\Exception $L1ZUQ) {
            Log::info("SmhkgG6le5p0r has been deleted, discard it", ['fileId' => $Qu08p, 'err' => $L1ZUQ->getMessage()]);
            return;
        }
        goto tPLqK;
        X3ubQ:
        ini_set('memory_limit', '-1');
        goto up13G;
        WrZMU:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $Qu08p]);
        goto X3ubQ;
        tPLqK:
    }
    private function mIRv5jIxrgU(SmhkgG6le5p0r $X0ufS, $XyS0P) : bool
    {
        goto mpT5l;
        i5wmY:
        switch (true) {
            case $X0ufS->width() * $X0ufS->height() >= 1920 * 1080 && $X0ufS->width() * $X0ufS->height() < 2560 * 1440:
                return $F7YHz > 10 * 60;
            case $X0ufS->width() * $X0ufS->height() >= 2560 * 1440 && $X0ufS->width() * $X0ufS->height() < 3840 * 2160:
                return $F7YHz > 5 * 60;
            case $X0ufS->width() * $X0ufS->height() >= 3840 * 2160:
                return $F7YHz > 3 * 60;
            default:
                return false;
        }
        goto e6sQV;
        gtzRr:
        VgJyG:
        goto Rqo5V;
        mpT5l:
        if ($XyS0P) {
            goto zVxga;
        }
        goto A2mGt;
        A2mGt:
        return false;
        goto jL6DI;
        e6sQV:
        GYAI2:
        goto gtzRr;
        jL6DI:
        zVxga:
        goto zRr8m;
        zRr8m:
        $F7YHz = (int) round($X0ufS->getAttribute('duration') ?? 0);
        goto i5wmY;
        Rqo5V:
    }
    private function mntVSRUH8Rj(Cjv3UOrDUgWrC $qrahj, string $szoiw) : ?R8oCerQxKXZb6
    {
        goto kjrYy;
        CFKEC:
        nTeSb:
        goto RwgFA;
        CyLM9:
        Log::info("Resolve watermark for job with url", ['url' => $szoiw, 'uri' => $slm7h]);
        goto sW7Uv;
        A1Trw:
        return new R8oCerQxKXZb6($slm7h, 0, 0, null, null);
        goto CFKEC;
        RwgFA:
        return null;
        goto dnHpA;
        kjrYy:
        $slm7h = $qrahj->mSEGzvUlW0b($szoiw);
        goto CyLM9;
        sW7Uv:
        if (!$slm7h) {
            goto nTeSb;
        }
        goto A1Trw;
        dnHpA:
    }
    private function mRUzHpg8mQ8(int $qFAp6, int $bxUTl) : bool
    {
        return $qFAp6 * $bxUTl > 1.5 * (1920 * 1080);
    }
    private function muej7NuKxdt(int $qFAp6, int $bxUTl) : array
    {
        $SVrZv = new QXJUwRt07aAu0($qFAp6, $bxUTl);
        return $SVrZv->mFKsUsu1E6S();
    }
    private function mU60j122Kur(LfWCTOqty2Slr $FjxfJ) : string
    {
        goto GPtrf;
        BE6p9:
        qeulA:
        goto SNjfO;
        GPtrf:
        if (!($FjxfJ->LjaQU == NYPGraEb3Ennl::S3)) {
            goto qeulA;
        }
        goto lEtKd;
        lEtKd:
        return 's3://' . $this->q3TFM . '/' . $FjxfJ->filename;
        goto BE6p9;
        SNjfO:
        return $this->x0wV5->url($FjxfJ->filename);
        goto JcSKS;
        JcSKS:
    }
}
