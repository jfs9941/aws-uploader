<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ImR2RBQBrahNh
{
    private $x2YK4;
    private $H11EA;
    public function __construct(int $owZwn, int $rjtpE)
    {
        goto FRD1g;
        lJSle:
        $this->H11EA = $rjtpE;
        goto NxiOM;
        iBl1X:
        $this->x2YK4 = $owZwn;
        goto lJSle;
        BO7jS:
        nY0Q6:
        goto iBl1X;
        ZX1Ve:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto BO7jS;
        K5PE1:
        MTEml:
        goto uFZVR;
        uFZVR:
        if (!($rjtpE <= 0)) {
            goto nY0Q6;
        }
        goto ZX1Ve;
        RefbQ:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto K5PE1;
        FRD1g:
        if (!($owZwn <= 0)) {
            goto MTEml;
        }
        goto RefbQ;
        NxiOM:
    }
    private static function mN7GNVJUwXW($h8HpH, string $yOgvN = 'floor') : int
    {
        goto YO8TW;
        gT5ki:
        Lfihn:
        goto J3JKM;
        z5FyI:
        ZO6R0:
        goto o2HC9;
        J3JKM:
        MOYwa:
        goto Tu1xh;
        ngq6n:
        return $h8HpH;
        goto bjjA3;
        YO8TW:
        if (!(is_int($h8HpH) && $h8HpH % 2 === 0)) {
            goto fjCM1;
        }
        goto ngq6n;
        o2HC9:
        switch (strtolower($yOgvN)) {
            case 'ceil':
                return (int) (ceil($h8HpH / 2) * 2);
            case 'round':
                return (int) (round($h8HpH / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($h8HpH / 2) * 2);
        }
        goto gT5ki;
        bjjA3:
        fjCM1:
        goto xclh0;
        Ry5V2:
        return (int) $h8HpH;
        goto z5FyI;
        xclh0:
        if (!(is_float($h8HpH) && $h8HpH == floor($h8HpH) && (int) $h8HpH % 2 === 0)) {
            goto ZO6R0;
        }
        goto Ry5V2;
        Tu1xh:
    }
    public function mmJk1byti6a(string $cD0Ic = 'floor') : array
    {
        goto i19eE;
        jHJTT:
        $yg5CX = $this->H11EA * $U7LvQ;
        goto mrG5x;
        Bmb82:
        $JBfCB = $xzZaD;
        goto aGgS7;
        aGgS7:
        $U7LvQ = $JBfCB / $this->x2YK4;
        goto jHJTT;
        i19eE:
        $xzZaD = 1080;
        goto Muktk;
        yikpX:
        $JBfCB = self::mN7GNVJUwXW(round($zK4eZ), $cD0Ic);
        goto LkWIQ;
        jQejh:
        if (!($JBfCB < 2)) {
            goto x_20f;
        }
        goto P6o3h;
        mrG5x:
        $IKyKL = self::mN7GNVJUwXW(round($yg5CX), $cD0Ic);
        goto GXzRM;
        XHDnc:
        $IKyKL = 2;
        goto uLglQ;
        sDrqI:
        U9RXk:
        goto JwcjS;
        h85yb:
        $IKyKL = 0;
        goto CdX7x;
        JwcjS:
        $IKyKL = $xzZaD;
        goto O14w_;
        GXzRM:
        goto IbyeI;
        goto sDrqI;
        vLN0t:
        if (!($IKyKL < 2)) {
            goto pnpM4;
        }
        goto XHDnc;
        P6o3h:
        $JBfCB = 2;
        goto HNQbz;
        HNQbz:
        x_20f:
        goto vLN0t;
        O14w_:
        $U7LvQ = $IKyKL / $this->H11EA;
        goto fzPGf;
        IfXIy:
        return ['width' => $JBfCB, 'height' => $IKyKL];
        goto A1Gsj;
        LkWIQ:
        IbyeI:
        goto jQejh;
        fzPGf:
        $zK4eZ = $this->x2YK4 * $U7LvQ;
        goto yikpX;
        uLglQ:
        pnpM4:
        goto IfXIy;
        Muktk:
        $JBfCB = 0;
        goto h85yb;
        CdX7x:
        if ($this->x2YK4 >= $this->H11EA) {
            goto U9RXk;
        }
        goto Bmb82;
        A1Gsj:
    }
}
