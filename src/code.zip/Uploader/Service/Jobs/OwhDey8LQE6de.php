<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Illuminate\Support\Facades\Log;
class OwhDey8LQE6de implements DownloadToLocalJobInterface
{
    private $rSfnv;
    private $GRsEs;
    public function __construct($uIWH1, $Zywh9)
    {
        $this->rSfnv = $uIWH1;
        $this->GRsEs = $Zywh9;
    }
    public function download(string $eeXS6) : void
    {
        goto SMDDy;
        dmNkM:
        Log::info("Start download file to local", ['fileId' => $eeXS6, 'filename' => $qFMlx->getLocation()]);
        goto i3cPL;
        X7trT:
        $this->GRsEs->put($qFMlx->getLocation(), $this->rSfnv->get($qFMlx->getLocation()));
        goto uysRA;
        i3cPL:
        if (!$this->GRsEs->exists($qFMlx->getLocation())) {
            goto yaf6_;
        }
        goto tbnIu;
        nt77C:
        yaf6_:
        goto X7trT;
        SMDDy:
        $qFMlx = UG34Yjmf7IsbQ::findOrFail($eeXS6);
        goto dmNkM;
        tbnIu:
        return;
        goto nt77C;
        uysRA:
    }
}
