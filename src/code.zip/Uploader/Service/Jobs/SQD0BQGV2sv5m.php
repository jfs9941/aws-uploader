<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class SQD0BQGV2sv5m implements StoreToS3JobInterface
{
    private $X2VAb;
    private $Mayr9;
    private $nEL6Z;
    public function __construct($aC0aM, $KI4Gx, $vWt2S)
    {
        goto I__zX;
        I__zX:
        $this->Mayr9 = $KI4Gx;
        goto u09_G;
        u09_G:
        $this->nEL6Z = $vWt2S;
        goto wSDzQ;
        wSDzQ:
        $this->X2VAb = $aC0aM;
        goto RAVWk;
        RAVWk:
    }
    public function store(string $iG1wy) : void
    {
        goto cXq8y;
        m1WdO:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $iG1wy]);
        goto aVrQT;
        VMmD2:
        return;
        goto v0Hfm;
        hTcWq:
        $uTfBu = $this->X2VAb->call($this, $m7qW2);
        goto d6rZ1;
        e83sY:
        $this->mLbiBgxSeT8($HCRCz, $NnB1V->getLocation());
        goto LUuAS;
        d6rZ1:
        $this->Mayr9->put($NnB1V->getAttribute('thumbnail'), $this->nEL6Z->get($ayHzt), ['visibility' => 'public', 'ContentType' => $uTfBu->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto MFCLB;
        QJ77S:
        Log::info("KyoDVfv3eGItF stored to S3, update the children attachments", ['fileId' => $iG1wy]);
        goto FHRDG;
        ZZiBD:
        $HCRCz = $this->nEL6Z->path($NnB1V->getLocation());
        goto e83sY;
        WzvTC:
        ycsAs:
        goto kNXQa;
        LUuAS:
        $ayHzt = $NnB1V->getAttribute('thumbnail');
        goto GS0XJ;
        Wd4Q9:
        Log::info("KyoDVfv3eGItF has been deleted, discard it", ['fileId' => $iG1wy]);
        goto QocvE;
        kNXQa:
        if (!$NnB1V->update(['driver' => Ef6Dy6MoUDei9::S3, 'status' => Zgh3BZ2JVlG1A::FINISHED])) {
            goto I2kb3;
        }
        goto QJ77S;
        v0Hfm:
        I2kb3:
        goto m1WdO;
        FzZN1:
        $m7qW2 = $this->nEL6Z->path($ayHzt);
        goto hTcWq;
        GS0XJ:
        if (!($ayHzt && $this->nEL6Z->exists($ayHzt))) {
            goto Clrz5;
        }
        goto FzZN1;
        wnb_W:
        zpvHp:
        goto ZZiBD;
        FHRDG:
        KyoDVfv3eGItF::where('parent_id', $iG1wy)->update(['driver' => Ef6Dy6MoUDei9::S3, 'preview' => $NnB1V->getAttribute('preview'), 'thumbnail' => $NnB1V->getAttribute('thumbnail')]);
        goto VMmD2;
        mbmZz:
        $this->Mayr9->put($NnB1V->getAttribute('preview'), $this->nEL6Z->get($NnB1V->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $U2GjO->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto WzvTC;
        QocvE:
        return;
        goto wnb_W;
        sD6w1:
        if ($NnB1V) {
            goto zpvHp;
        }
        goto Wd4Q9;
        qIiWJ:
        $JFak1 = $this->nEL6Z->path($NnB1V->getAttribute('preview'));
        goto kuc2j;
        kuc2j:
        $U2GjO = $this->X2VAb->call($this, $JFak1);
        goto mbmZz;
        PZOGq:
        if (!($NnB1V->getAttribute('preview') && $this->nEL6Z->exists($NnB1V->getAttribute('preview')))) {
            goto ycsAs;
        }
        goto qIiWJ;
        MFCLB:
        Clrz5:
        goto PZOGq;
        cXq8y:
        $NnB1V = KyoDVfv3eGItF::findOrFail($iG1wy);
        goto sD6w1;
        aVrQT:
    }
    private function mLbiBgxSeT8($bXCN9, $cyUPY, $nbBOs = '')
    {
        goto Nja4u;
        w02UL:
        $bXCN9 = str_replace('.jpg', $nbBOs, $bXCN9);
        goto KF8CB;
        m0d93:
        try {
            $cDDGh = $this->X2VAb->call($this, $bXCN9);
            $this->Mayr9->put($cyUPY, $this->nEL6Z->get($cyUPY), ['visibility' => 'public', 'ContentType' => $cDDGh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $wEHhy) {
            Log::error("Failed to upload image to S3", ['s3Path' => $cyUPY, 'error' => $wEHhy->getMessage()]);
        }
        goto JFhUj;
        Nja4u:
        if (!$nbBOs) {
            goto ks7Ui;
        }
        goto w02UL;
        KF8CB:
        $cyUPY = str_replace('.jpg', $nbBOs, $cyUPY);
        goto Esf9E;
        Esf9E:
        ks7Ui:
        goto m0d93;
        JFhUj:
    }
}
