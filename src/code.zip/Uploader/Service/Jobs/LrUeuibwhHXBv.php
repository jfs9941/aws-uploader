<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Service\Jobs\Pwzrr2Hyspqqd;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class LrUeuibwhHXBv implements WatermarkTextJobInterface
{
    private $j6_VZ;
    private $zZRNN;
    private $b8AQe;
    private $RE_2F;
    private $P8Yzg;
    public function __construct($od_dm, $BLhUh, $WmwnR, $jT0xz, $HIxBy)
    {
        goto iKC32;
        WBSfQ:
        $this->RE_2F = $WmwnR;
        goto RC_4r;
        pIX9r:
        $this->b8AQe = $HIxBy;
        goto GlFSx;
        RC_4r:
        $this->P8Yzg = $jT0xz;
        goto pIX9r;
        iKC32:
        $this->j6_VZ = $od_dm;
        goto WBSfQ;
        GlFSx:
        $this->zZRNN = $BLhUh;
        goto dFaLT;
        dFaLT:
    }
    public function putWatermark(string $LpGEK, string $WkdyW) : void
    {
        goto f6LVg;
        XhTl1:
        ini_set('memory_limit', '-1');
        goto YfGH3;
        f6LVg:
        $bZyPc = microtime(true);
        goto PgVeD;
        Z0Zjw:
        $oEqSJ = memory_get_peak_usage();
        goto XwMIr;
        PgVeD:
        $xzy2m = memory_get_usage();
        goto Z0Zjw;
        XwMIr:
        Log::info("Adding watermark text to image", ['imageId' => $LpGEK]);
        goto XhTl1;
        YfGH3:
        try {
            goto QU3yw;
            SxTQi:
            return;
            goto o8Q8u;
            xq3o6:
            $au0AO = $this->j6_VZ->call($this, $AvgzF);
            goto cC3X9;
            dMnx_:
            Wv2Vw:
            goto IDbTu;
            cC3X9:
            $au0AO->orient();
            goto EM13z;
            Ol47F:
            throw new \Exception('Failed to set final permissions on image file: ' . $AvgzF);
            goto dMnx_;
            mTSoQ:
            Log::error("X9YHjKrAdcfhe is not on local, might be deleted before put watermark", ['imageId' => $LpGEK]);
            goto SxTQi;
            M7pu3:
            $AvgzF = $this->P8Yzg->path($ZQQzW->getLocation());
            goto xq3o6;
            pWjEN:
            $this->RE_2F->put($AvgzF, $au0AO->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto ec6Hk;
            o8Q8u:
            cK1ld:
            goto M7pu3;
            EM13z:
            $this->mYgY4mAcTM9($au0AO, $WkdyW);
            goto pWjEN;
            tMCBU:
            if (chmod($AvgzF, 0664)) {
                goto Wv2Vw;
            }
            goto dvUaP;
            QU3yw:
            $ZQQzW = X9YHjKrAdcfhe::findOrFail($LpGEK);
            goto JxJYO;
            dvUaP:
            \Log::warning('Failed to set final permissions on image file: ' . $AvgzF);
            goto Ol47F;
            ec6Hk:
            unset($au0AO);
            goto tMCBU;
            JxJYO:
            if ($this->P8Yzg->exists($ZQQzW->getLocation())) {
                goto cK1ld;
            }
            goto mTSoQ;
            IDbTu:
        } catch (\Throwable $xjcDD) {
            goto K4q8L;
            K4q8L:
            if (!$xjcDD instanceof ModelNotFoundException) {
                goto UcboP;
            }
            goto eK1z5;
            eK1z5:
            Log::info("X9YHjKrAdcfhe has been deleted, discard it", ['imageId' => $LpGEK]);
            goto tw8sg;
            S2M3f:
            UcboP:
            goto ZsWjP;
            tw8sg:
            return;
            goto S2M3f;
            ZsWjP:
            Log::error("X9YHjKrAdcfhe is not readable", ['imageId' => $LpGEK, 'error' => $xjcDD->getMessage()]);
            goto CUjTw;
            CUjTw:
        } finally {
            $U57EV = microtime(true);
            $N25yv = memory_get_usage();
            $E8PVY = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $LpGEK, 'execution_time_sec' => $U57EV - $bZyPc, 'memory_usage_mb' => ($N25yv - $xzy2m) / 1024 / 1024, 'peak_memory_usage_mb' => ($E8PVY - $oEqSJ) / 1024 / 1024]);
        }
        goto gVoEz;
        gVoEz:
    }
    private function mYgY4mAcTM9($au0AO, $WkdyW) : void
    {
        goto uG45c;
        a0w2A:
        $zIWYo = new Pwzrr2Hyspqqd($this->zZRNN, $this->b8AQe, $this->RE_2F, $this->P8Yzg);
        goto IIod2;
        rWyNA:
        $au0AO->place($nI2zA, 'top-left', 0, 0, 30);
        goto Uqy0k;
        LtlJV:
        $this->P8Yzg->put($rhdR9, $this->RE_2F->get($rhdR9));
        goto ltLsq;
        ltLsq:
        $nI2zA = $this->j6_VZ->call($this, $this->P8Yzg->path($rhdR9));
        goto rWyNA;
        IIod2:
        $rhdR9 = $zIWYo->mtN0xu2kbrL($tYCg4, $Xnjcp, $WkdyW, true);
        goto LtlJV;
        uG45c:
        $tYCg4 = $au0AO->width();
        goto iS1ga;
        iS1ga:
        $Xnjcp = $au0AO->height();
        goto a0w2A;
        Uqy0k:
    }
}
