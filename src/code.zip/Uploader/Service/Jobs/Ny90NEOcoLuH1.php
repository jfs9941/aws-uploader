<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Enum\SsxWbUYXracun;
class Ny90NEOcoLuH1 implements GenerateThumbnailJobInterface
{
    const z_WAJ = 150;
    const i_ulN = 150;
    private $wEW4b;
    private $sf39X;
    public function __construct($jlVrW, $ZqxJI)
    {
        $this->wEW4b = $jlVrW;
        $this->sf39X = $ZqxJI;
    }
    public function generate(string $cQqZd)
    {
        goto nMFk8;
        fHO1N:
        ini_set('memory_limit', '-1');
        goto nOfyq;
        nMFk8:
        Log::info("Generating thumbnail", ['imageId' => $cQqZd]);
        goto fHO1N;
        nOfyq:
        try {
            goto UMVY3;
            NWANf:
            t60MW:
            goto qe6xF;
            IewDH:
            $m5gMs->destroy();
            goto BCMmX;
            HEeRZ:
            $m5gMs = $this->wEW4b->call($this, $dOL2I->path($MpgR7->getLocation()));
            goto VGYGU;
            U7PsX:
            if (chmod($uejxd, 0644)) {
                goto t60MW;
            }
            goto TdQey;
            UMVY3:
            $dOL2I = $this->sf39X;
            goto cQzEZ;
            NuCHK:
            throw new \Exception('Failed to set file permissions for stored image: ' . $uejxd);
            goto NWANf;
            TdQey:
            Log::warning('Failed to set file permissions for stored image: ' . $uejxd);
            goto NuCHK;
            OoSyQ:
            $m5gMs->encode('jpg', 80);
            goto vk7fM;
            VGYGU:
            $m5gMs->fit(150, 150, function ($EWyPD) {
                $EWyPD->aspectRatio();
            });
            goto OoSyQ;
            fhhmk:
            $Pp8sx = $dOL2I->put($IJqE5, $m5gMs->stream(), ['visibility' => 'public']);
            goto IewDH;
            vk7fM:
            $IJqE5 = $this->mZsjzUjcnba($MpgR7);
            goto fhhmk;
            BCMmX:
            if (!($Pp8sx !== false)) {
                goto vhL2m;
            }
            goto loMo0;
            qe6xF:
            vhL2m:
            goto zYamP;
            cQzEZ:
            $MpgR7 = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
            goto HEeRZ;
            loMo0:
            $MpgR7->update(['thumbnail' => $IJqE5, 'status' => SsxWbUYXracun::THUMBNAIL_PROCESSED]);
            goto Iglus;
            Iglus:
            $uejxd = $dOL2I->path($IJqE5);
            goto U7PsX;
            zYamP:
        } catch (ModelNotFoundException $xA1Kf) {
            Log::info("Kx3NMUJqFpl5Q has been deleted, discard it", ['imageId' => $cQqZd]);
            return;
        }
        goto aryA1;
        aryA1:
    }
    private function mZsjzUjcnba(ZujQPL2bQTbeI $MpgR7) : string
    {
        goto emj36;
        RylUd:
        $LiunP = $ZJ0e5 . '/' . self::z_WAJ . 'X' . self::i_ulN;
        goto GKv42;
        emj36:
        $IJqE5 = $MpgR7->getLocation();
        goto MsiX3;
        MsiX3:
        $ZJ0e5 = dirname($IJqE5);
        goto RylUd;
        GKv42:
        return $LiunP . '/' . $MpgR7->getFilename() . '.jpg';
        goto okxsh;
        okxsh:
    }
}
