<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Service\Jobs\VNtYCSNiCWI3M;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class L4Q9FvQSntfVP implements WatermarkTextJobInterface
{
    private $ABFqP;
    private $oJNPX;
    private $cAi3S;
    private $QxLu3;
    private $pXh9P;
    public function __construct($xLMar, $K4GQ_, $bjIIR, $TWZho, $fB6P3)
    {
        goto i1JkR;
        i1JkR:
        $this->ABFqP = $xLMar;
        goto wsCvE;
        T9bGT:
        $this->cAi3S = $fB6P3;
        goto dt1Cv;
        dt1Cv:
        $this->oJNPX = $K4GQ_;
        goto h5jpz;
        wsCvE:
        $this->QxLu3 = $bjIIR;
        goto qTOQh;
        qTOQh:
        $this->pXh9P = $TWZho;
        goto T9bGT;
        h5jpz:
    }
    public function putWatermark(string $qMhfW, string $S5d8n) : void
    {
        goto Y7mzl;
        pAI3T:
        try {
            goto hLTze;
            lDEHp:
            xxkq3:
            goto gSaCS;
            qdysw:
            $v_wWH->orient();
            goto Dq1vH;
            Af9EW:
            xY9uu:
            goto v9ZUB;
            L753s:
            $v_wWH = $this->ABFqP->call($this, $b0LKC);
            goto qdysw;
            hLTze:
            $T4AWF = WUuz09CA4woAL::findOrFail($qMhfW);
            goto jQLlU;
            JKm2R:
            unset($v_wWH);
            goto KqZ8X;
            rwXvU:
            return;
            goto lDEHp;
            yfYr2:
            $this->QxLu3->put($b0LKC, $v_wWH->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto JKm2R;
            GqHTn:
            \Log::warning('Failed to set final permissions on image file: ' . $b0LKC);
            goto iT4dT;
            gSaCS:
            $b0LKC = $this->pXh9P->path($T4AWF->getLocation());
            goto L753s;
            jQLlU:
            if ($this->pXh9P->exists($T4AWF->getLocation())) {
                goto xxkq3;
            }
            goto rL1Kg;
            Dq1vH:
            $this->mCAtsMDWlwt($v_wWH, $S5d8n);
            goto yfYr2;
            rL1Kg:
            Log::error("WUuz09CA4woAL is not on local, might be deleted before put watermark", ['imageId' => $qMhfW]);
            goto rwXvU;
            iT4dT:
            throw new \Exception('Failed to set final permissions on image file: ' . $b0LKC);
            goto Af9EW;
            KqZ8X:
            if (chmod($b0LKC, 0664)) {
                goto xY9uu;
            }
            goto GqHTn;
            v9ZUB:
        } catch (\Throwable $AKF2s) {
            goto QiR7E;
            mw8ji:
            Log::info("WUuz09CA4woAL has been deleted, discard it", ['imageId' => $qMhfW]);
            goto wnEit;
            QiR7E:
            if (!$AKF2s instanceof ModelNotFoundException) {
                goto bGlR3;
            }
            goto mw8ji;
            wnEit:
            return;
            goto OmseD;
            s7sXP:
            Log::error("WUuz09CA4woAL is not readable", ['imageId' => $qMhfW, 'error' => $AKF2s->getMessage()]);
            goto DmQTW;
            OmseD:
            bGlR3:
            goto s7sXP;
            DmQTW:
        } finally {
            $dFOsw = microtime(true);
            $IfrVA = memory_get_usage();
            $O6V3s = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $qMhfW, 'execution_time_sec' => $dFOsw - $u4XNo, 'memory_usage_mb' => ($IfrVA - $E9dxY) / 1024 / 1024, 'peak_memory_usage_mb' => ($O6V3s - $nrXNy) / 1024 / 1024]);
        }
        goto OKgUQ;
        Y7mzl:
        $u4XNo = microtime(true);
        goto azPoA;
        xw_Nq:
        Log::info("Adding watermark text to image", ['imageId' => $qMhfW]);
        goto oRwZw;
        z4GDY:
        $nrXNy = memory_get_peak_usage();
        goto xw_Nq;
        azPoA:
        $E9dxY = memory_get_usage();
        goto z4GDY;
        oRwZw:
        ini_set('memory_limit', '-1');
        goto pAI3T;
        OKgUQ:
    }
    private function mCAtsMDWlwt($v_wWH, $S5d8n) : void
    {
        goto WoLgg;
        gyHcH:
        $RFX4H = $v_wWH->height();
        goto B4NKu;
        HfRCW:
        $PYqWO = $this->ABFqP->call($this, $this->pXh9P->path($B0GOO));
        goto e45yj;
        B4NKu:
        $zdqrL = new VNtYCSNiCWI3M($this->oJNPX, $this->cAi3S, $this->QxLu3, $this->pXh9P);
        goto HX2ec;
        Kr511:
        $this->pXh9P->put($B0GOO, $this->QxLu3->get($B0GOO));
        goto HfRCW;
        HX2ec:
        $B0GOO = $zdqrL->mHXH8gbRF5x($ZJYlg, $RFX4H, $S5d8n, true);
        goto Kr511;
        WoLgg:
        $ZJYlg = $v_wWH->width();
        goto gyHcH;
        e45yj:
        $v_wWH->place($PYqWO, 'top-left', 0, 0, 30);
        goto s0KhR;
        s0KhR:
    }
}
