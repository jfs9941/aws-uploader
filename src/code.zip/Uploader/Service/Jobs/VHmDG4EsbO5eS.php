<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Illuminate\Support\Facades\Log;
class VHmDG4EsbO5eS implements BlurVideoJobInterface
{
    const Eawhs = 15;
    const snXAI = 500;
    const mcq5p = 500;
    private $UVc7_;
    private $D9Jo8;
    private $s3l3u;
    public function __construct($h1yz3, $v1Edp, $lKCQu)
    {
        goto wSziJ;
        CLreP:
        $this->D9Jo8 = $v1Edp;
        goto Xe2Xl;
        wSziJ:
        $this->s3l3u = $lKCQu;
        goto CLreP;
        Xe2Xl:
        $this->UVc7_ = $h1yz3;
        goto V2ycC;
        V2ycC:
    }
    public function blur(string $poSkG) : void
    {
        goto lON3S;
        o9Fp9:
        $this->s3l3u->put($CcO2I->getAttribute('thumbnail'), $this->D9Jo8->get($CcO2I->getAttribute('thumbnail')));
        goto f_ruu;
        La2j1:
        $VSbOm->blur(self::Eawhs);
        goto zgVSz;
        dHTQB:
        $KUEeo = $this->s3l3u->path($W4B_D);
        goto Mf0AE;
        Mf0AE:
        $VSbOm->save($KUEeo);
        goto Zwhrh;
        wBlKj:
        hIt2u:
        goto P7YLx;
        Y2I4d:
        ini_set('memory_limit', '-1');
        goto Kus1z;
        P7YLx:
        $CcO2I->update(['preview' => $W4B_D]);
        goto kpfGr;
        Zwhrh:
        $this->D9Jo8->put($W4B_D, $this->s3l3u->get($W4B_D));
        goto j0xrC;
        kpfGr:
        F2i_1:
        goto cesUm;
        Kus1z:
        $CcO2I = ISYJHQo8eqdfc::findOrFail($poSkG);
        goto z0I12;
        zgVSz:
        $W4B_D = $this->m779BRmUrdc($CcO2I);
        goto dHTQB;
        bYOqe:
        \Log::warning('Failed to set final permissions on image file: ' . $KUEeo);
        goto ifMB1;
        G983K:
        $VSbOm->resize(self::snXAI, self::mcq5p / $vMMem);
        goto La2j1;
        odkkC:
        $vMMem = $VSbOm->width() / $VSbOm->height();
        goto G983K;
        f_ruu:
        $VSbOm = $this->UVc7_->call($this, $this->s3l3u->path($CcO2I->getAttribute('thumbnail')));
        goto odkkC;
        ifMB1:
        throw new \Exception('Failed to set final permissions on image file: ' . $KUEeo);
        goto wBlKj;
        lON3S:
        Log::info("Blurring for video", ['videoID' => $poSkG]);
        goto Y2I4d;
        bNmYV:
        if (chmod($KUEeo, 0664)) {
            goto hIt2u;
        }
        goto bYOqe;
        j0xrC:
        unset($VSbOm);
        goto bNmYV;
        z0I12:
        if (!$CcO2I->getAttribute('thumbnail')) {
            goto F2i_1;
        }
        goto o9Fp9;
        cesUm:
    }
    private function m779BRmUrdc(N8O216tH1Gxax $uDbCt) : string
    {
        goto QwE52;
        XXuEy:
        return $T2ESg . $uDbCt->getFilename() . '.jpg';
        goto QArlG;
        UMw33:
        $this->s3l3u->makeDirectory($T2ESg, 0755, true);
        goto GPHqA;
        oKrVK:
        $T2ESg = dirname($lT4E3) . '/preview/';
        goto duVxy;
        duVxy:
        if ($this->s3l3u->exists($T2ESg)) {
            goto ppex3;
        }
        goto UMw33;
        GPHqA:
        ppex3:
        goto XXuEy;
        QwE52:
        $lT4E3 = $uDbCt->getLocation();
        goto oKrVK;
        QArlG:
    }
}
