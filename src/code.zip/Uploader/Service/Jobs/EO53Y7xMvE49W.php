<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class EO53Y7xMvE49W
{
    private $eKoQ3;
    private $T2ciG;
    private $tcoQz;
    private $uTYgy;
    public function __construct($p1Hjh, $Vk5rF, $v70jj, $kVG4M)
    {
        goto kghUk;
        kghUk:
        $this->T2ciG = $Vk5rF;
        goto KFZX4;
        LHv4f:
        $this->eKoQ3 = $p1Hjh;
        goto wJWz3;
        KFZX4:
        $this->tcoQz = $v70jj;
        goto Doa0e;
        Doa0e:
        $this->uTYgy = $kVG4M;
        goto LHv4f;
        wJWz3:
    }
    public function m2ADXial3qe(?int $V0H7W, ?int $nO8OT, string $pfZs5, bool $sjQQc = false) : string
    {
        goto kKbm8;
        cCcUz:
        $vMNqJ = (int) ($QHtcG / 80);
        goto xLCIW;
        tsuXi:
        $jYl_6->text($Vv9Nt, $QHtcG, (int) $Ms4vD, function ($NyCTs) use($FZ_Wc) {
            goto n_Vb4;
            n_Vb4:
            $NyCTs->file(public_path($this->T2ciG));
            goto k4qje;
            RzNON:
            $NyCTs->align('middle');
            goto i66zs;
            k4qje:
            $SksIE = (int) ($FZ_Wc * 1.2);
            goto RjWQd;
            RjWQd:
            $NyCTs->size(max($SksIE, 1));
            goto nGpej;
            nGpej:
            $NyCTs->color([185, 185, 185, 1]);
            goto X973H;
            X973H:
            $NyCTs->valign('middle');
            goto RzNON;
            i66zs:
        });
        goto Q2uOl;
        kKbm8:
        if (!($V0H7W === null || $nO8OT === null)) {
            goto SsJ9M;
        }
        goto Pzgtj;
        pMnjU:
        return $sjQQc ? $uUtRl : $this->tcoQz->url($uUtRl);
        goto eBw2r;
        eoCE9:
        return $sjQQc ? $uUtRl : $this->tcoQz->url($uUtRl);
        goto TyzKw;
        ZivOQ:
        if (!($V0H7W > 1500)) {
            goto YOCZv;
        }
        goto xHGNQ;
        TyzKw:
        Ml3Zy:
        goto rYFos;
        eCA5T:
        if (!$this->tcoQz->exists($uUtRl)) {
            goto Ml3Zy;
        }
        goto eoCE9;
        xHGNQ:
        $QHtcG -= $vMNqJ * 0.4;
        goto DMl_y;
        sjV8D:
        list($FZ_Wc, $FVxc4, $Vv9Nt) = $this->mjbA1BTBykb($pfZs5, $V0H7W, $hebnC, (float) $V0H7W / $nO8OT);
        goto pxUbf;
        rYFos:
        $jYl_6 = $this->eKoQ3->call($this, $V0H7W, $nO8OT);
        goto iIeLR;
        DXONj:
        $Ms4vD = $nO8OT - $FZ_Wc - 10;
        goto tsuXi;
        pxUbf:
        $uUtRl = $this->mNv5c9dIXGM($Vv9Nt, $V0H7W, $nO8OT, $FVxc4, $FZ_Wc);
        goto eCA5T;
        xLCIW:
        $QHtcG -= $vMNqJ;
        goto ZivOQ;
        p0U1X:
        $this->tcoQz->put($uUtRl, $jYl_6->stream('png'));
        goto pMnjU;
        ZJ7_z:
        $hebnC = 0.1;
        goto sjV8D;
        Q2uOl:
        $this->uTYgy->put($uUtRl, $jYl_6->stream('png'));
        goto p0U1X;
        DMl_y:
        YOCZv:
        goto DXONj;
        hVXRz:
        SsJ9M:
        goto ZJ7_z;
        iIeLR:
        $QHtcG = $V0H7W - $FVxc4;
        goto cCcUz;
        Pzgtj:
        throw new \RuntimeException("CpeNYzI7e1ALA dimensions are not available.");
        goto hVXRz;
        eBw2r:
    }
    private function mNv5c9dIXGM(string $pfZs5, int $V0H7W, int $nO8OT, int $KZwBu, int $zd1Ll) : string
    {
        $fWQk9 = ltrim($pfZs5, '@');
        return "v2/watermark/{$fWQk9}/{$V0H7W}x{$nO8OT}_{$KZwBu}x{$zd1Ll}/text_watermark.png";
    }
    private function mjbA1BTBykb($pfZs5, int $V0H7W, float $lCFEZ, float $TZSdr) : array
    {
        goto Qrx3W;
        tMiLm:
        $FVxc4 = (int) ($V0H7W * $lCFEZ);
        goto vCu1l;
        EcXXY:
        $VKI4t = $FVxc4 / (strlen($Vv9Nt) * 0.8);
        goto FHYEB;
        vCu1l:
        if (!($TZSdr > 1)) {
            goto mXDve;
        }
        goto EcXXY;
        xyJbu:
        return [(int) $VKI4t, $FVxc4, $Vv9Nt];
        goto KVfF1;
        zkX6J:
        mXDve:
        goto MwNeW;
        FHYEB:
        return [(int) $VKI4t, $VKI4t * strlen($Vv9Nt) / 1.8, $Vv9Nt];
        goto zkX6J;
        MwNeW:
        $VKI4t = 1 / $TZSdr * $FVxc4 / strlen($Vv9Nt);
        goto xyJbu;
        Qrx3W:
        $Vv9Nt = '@' . $pfZs5;
        goto tMiLm;
        KVfF1:
    }
}
