<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class JaU0LQwVRva8r implements StoreToS3JobInterface
{
    private $xy0Yf;
    private $gErml;
    private $mzObC;
    public function __construct($ppK7O, $DFpIk, $L1VX0)
    {
        goto qhNCT;
        qhNCT:
        $this->gErml = $DFpIk;
        goto X4lAY;
        X4lAY:
        $this->mzObC = $L1VX0;
        goto w49AW;
        w49AW:
        $this->xy0Yf = $ppK7O;
        goto IR6TJ;
        IR6TJ:
    }
    public function store(string $J_scC) : void
    {
        goto H9HwW;
        G5Kg2:
        $this->mhMdu06cvAr($hU2b_, $VNJ0D->getLocation());
        goto LEocA;
        GvvJY:
        if ($VNJ0D) {
            goto J1v3x;
        }
        goto XHiqw;
        Hcr7T:
        $th8Vs = $this->xy0Yf->call($this, $qIpsP);
        goto DIv5N;
        T5eSH:
        $qIpsP = $this->mzObC->path($VNJ0D->getAttribute('preview'));
        goto Hcr7T;
        iE_u3:
        if (!$VNJ0D->update(['driver' => DccywYjigTakI::S3, 'status' => EpMPhiTVzNYqA::FINISHED])) {
            goto RTKiE;
        }
        goto kAibB;
        X8JsZ:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $J_scC]);
        goto n1CWg;
        FfuXT:
        RTKiE:
        goto X8JsZ;
        kAibB:
        Log::info("XK5kReLMTU1ob stored to S3, update the children attachments", ['fileId' => $J_scC]);
        goto bhT8_;
        fwtjl:
        QT2_J:
        goto iE_u3;
        bhT8_:
        XK5kReLMTU1ob::where('parent_id', $J_scC)->update(['driver' => DccywYjigTakI::S3, 'preview' => $VNJ0D->getAttribute('preview'), 'thumbnail' => $VNJ0D->getAttribute('thumbnail')]);
        goto yBK2w;
        QT9CF:
        $cOdCv = $this->xy0Yf->call($this, $ktqja);
        goto jSI_l;
        yBK2w:
        return;
        goto FfuXT;
        LEocA:
        $IitKq = $VNJ0D->getAttribute('thumbnail');
        goto auivY;
        XHiqw:
        Log::info("XK5kReLMTU1ob has been deleted, discard it", ['fileId' => $J_scC]);
        goto l4c3O;
        Bt6Ld:
        $ktqja = $this->mzObC->path($IitKq);
        goto QT9CF;
        D3Oq7:
        uItwa:
        goto c1L6f;
        AkE_k:
        J1v3x:
        goto HN0bL;
        jSI_l:
        $this->gErml->put($VNJ0D->getAttribute('thumbnail'), $this->mzObC->get($IitKq), ['visibility' => 'public', 'ContentType' => $cOdCv->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto D3Oq7;
        auivY:
        if (!($IitKq && $this->mzObC->exists($IitKq))) {
            goto uItwa;
        }
        goto Bt6Ld;
        DIv5N:
        $this->gErml->put($VNJ0D->getAttribute('preview'), $this->mzObC->get($VNJ0D->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $th8Vs->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto fwtjl;
        l4c3O:
        return;
        goto AkE_k;
        HN0bL:
        $hU2b_ = $this->mzObC->path($VNJ0D->getLocation());
        goto G5Kg2;
        H9HwW:
        $VNJ0D = XK5kReLMTU1ob::findOrFail($J_scC);
        goto GvvJY;
        c1L6f:
        if (!($VNJ0D->getAttribute('preview') && $this->mzObC->exists($VNJ0D->getAttribute('preview')))) {
            goto QT2_J;
        }
        goto T5eSH;
        n1CWg:
    }
    private function mhMdu06cvAr($i86bG, $xS23x, $fdWOz = '')
    {
        goto sryYP;
        sryYP:
        if (!$fdWOz) {
            goto ncs8B;
        }
        goto ueY2j;
        g3SAg:
        ncs8B:
        goto ZJqCg;
        ueY2j:
        $i86bG = str_replace('.jpg', $fdWOz, $i86bG);
        goto Fj5Nl;
        ZJqCg:
        try {
            $VWXEV = $this->xy0Yf->call($this, $i86bG);
            $this->gErml->put($xS23x, $this->mzObC->get($xS23x), ['visibility' => 'public', 'ContentType' => $VWXEV->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $Jtg9A) {
            Log::error("Failed to upload image to S3", ['s3Path' => $xS23x, 'error' => $Jtg9A->getMessage()]);
        }
        goto j4tCW;
        Fj5Nl:
        $xS23x = str_replace('.jpg', $fdWOz, $xS23x);
        goto g3SAg;
        j4tCW:
    }
}
