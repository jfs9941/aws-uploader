<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Service\Jobs\QOFRXBlpPvkox;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class LdRkQgcNcI7mH implements WatermarkTextJobInterface
{
    private $z0km_;
    private $bJ64t;
    private $DV6_0;
    private $zbU8n;
    private $W9e5K;
    public function __construct($BSNlm, $f_vTf, $Efy84, $XCkIj, $ZNWsr)
    {
        goto WO794;
        ogiCb:
        $this->W9e5K = $XCkIj;
        goto csPHP;
        WO794:
        $this->z0km_ = $BSNlm;
        goto SGDTC;
        SGDTC:
        $this->zbU8n = $Efy84;
        goto ogiCb;
        csPHP:
        $this->DV6_0 = $ZNWsr;
        goto FQF3U;
        FQF3U:
        $this->bJ64t = $f_vTf;
        goto qhuYr;
        qhuYr:
    }
    public function putWatermark(string $N2oAf, string $QBYnF) : void
    {
        goto ugT9H;
        xTgXd:
        $zfPP0 = memory_get_usage();
        goto HcnZ3;
        hQ7pw:
        try {
            goto m_qLz;
            vhxbX:
            $vRakW = $this->W9e5K->path($RxSHk->getLocation());
            goto M0501;
            jH9UX:
            if (chmod($vRakW, 0664)) {
                goto X4AqY;
            }
            goto Ac_2M;
            PgKY3:
            bbbuX:
            goto vhxbX;
            mhsLm:
            X4AqY:
            goto hDOL5;
            FFUF5:
            if ($this->W9e5K->exists($RxSHk->getLocation())) {
                goto bbbuX;
            }
            goto q8UXo;
            kEcpu:
            $aymCM->orient();
            goto R3_fL;
            R3_fL:
            $this->mbvJJHzDuds($aymCM, $QBYnF);
            goto BCssy;
            M0501:
            $aymCM = $this->z0km_->call($this, $vRakW);
            goto kEcpu;
            iyUgy:
            return;
            goto PgKY3;
            BCssy:
            $this->zbU8n->put($vRakW, $aymCM->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto gkYX5;
            q8UXo:
            Log::error("JMa7GBaLcnq3D is not on local, might be deleted before put watermark", ['imageId' => $N2oAf]);
            goto iyUgy;
            gkYX5:
            unset($aymCM);
            goto jH9UX;
            Ac_2M:
            \Log::warning('Failed to set final permissions on image file: ' . $vRakW);
            goto K96_r;
            m_qLz:
            $RxSHk = JMa7GBaLcnq3D::findOrFail($N2oAf);
            goto FFUF5;
            K96_r:
            throw new \Exception('Failed to set final permissions on image file: ' . $vRakW);
            goto mhsLm;
            hDOL5:
        } catch (\Throwable $PIEhr) {
            goto ZZEnX;
            iEwfD:
            Log::info("JMa7GBaLcnq3D has been deleted, discard it", ['imageId' => $N2oAf]);
            goto HbQ8D;
            pWu9K:
            sbmMP:
            goto S8N7X;
            HbQ8D:
            return;
            goto pWu9K;
            ZZEnX:
            if (!$PIEhr instanceof ModelNotFoundException) {
                goto sbmMP;
            }
            goto iEwfD;
            S8N7X:
            Log::error("JMa7GBaLcnq3D is not readable", ['imageId' => $N2oAf, 'error' => $PIEhr->getMessage()]);
            goto cIm3B;
            cIm3B:
        } finally {
            $FlQiD = microtime(true);
            $pejxD = memory_get_usage();
            $G9K1o = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $N2oAf, 'execution_time_sec' => $FlQiD - $Oj18q, 'memory_usage_mb' => ($pejxD - $zfPP0) / 1024 / 1024, 'peak_memory_usage_mb' => ($G9K1o - $j44T2) / 1024 / 1024]);
        }
        goto bIdiC;
        c_lU1:
        Log::info("Adding watermark text to image", ['imageId' => $N2oAf]);
        goto bczFY;
        ugT9H:
        $Oj18q = microtime(true);
        goto xTgXd;
        HcnZ3:
        $j44T2 = memory_get_peak_usage();
        goto c_lU1;
        bczFY:
        ini_set('memory_limit', '-1');
        goto hQ7pw;
        bIdiC:
    }
    private function mbvJJHzDuds($aymCM, $QBYnF) : void
    {
        goto c5ZbX;
        rNGPj:
        $bBvox = new QOFRXBlpPvkox($this->bJ64t, $this->DV6_0, $this->zbU8n, $this->W9e5K);
        goto Bj8XS;
        aDom7:
        $S3Wk9 = $aymCM->height();
        goto rNGPj;
        Bj8XS:
        $kCGtX = $bBvox->mp5Q2fe7Fqv($lvh9C, $S3Wk9, $QBYnF, true);
        goto NfdQs;
        b7Zuv:
        $aymCM->place($MsaVt, 'top-left', 0, 0, 30);
        goto Yb3mc;
        yzmj0:
        $MsaVt = $this->z0km_->call($this, $this->W9e5K->path($kCGtX));
        goto b7Zuv;
        NfdQs:
        $this->W9e5K->put($kCGtX, $this->zbU8n->get($kCGtX));
        goto yzmj0;
        c5ZbX:
        $lvh9C = $aymCM->width();
        goto aDom7;
        Yb3mc:
    }
}
