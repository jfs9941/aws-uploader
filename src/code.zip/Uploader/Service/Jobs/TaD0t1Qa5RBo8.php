<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Illuminate\Support\Facades\Log;
class TaD0t1Qa5RBo8 implements BlurVideoJobInterface
{
    const Fzp39 = 15;
    const VxG1F = 500;
    const RT7FO = 500;
    private $ABFqP;
    private $QxLu3;
    private $aW0a3;
    public function __construct($xLMar, $bjIIR, $eEhuZ)
    {
        goto xk9lV;
        jvaQp:
        $this->ABFqP = $xLMar;
        goto wzip1;
        xk9lV:
        $this->aW0a3 = $eEhuZ;
        goto f8_2l;
        f8_2l:
        $this->QxLu3 = $bjIIR;
        goto jvaQp;
        wzip1:
    }
    public function blur(string $qMhfW) : void
    {
        goto giUYk;
        oTyaD:
        oqxI1:
        goto DXCwC;
        wcmTo:
        XQOa2:
        goto nBlbq;
        QTAPD:
        if (!$D1igg->getAttribute('thumbnail')) {
            goto oqxI1;
        }
        goto twg3k;
        Ao_4W:
        $T4AWF->save($p76Rw);
        goto RptUZ;
        aiNiy:
        if (chmod($p76Rw, 0664)) {
            goto XQOa2;
        }
        goto XggoQ;
        giUYk:
        Log::info("Blurring for video", ['videoID' => $qMhfW]);
        goto S1mWO;
        GqR4P:
        $TlV7f = $T4AWF->width() / $T4AWF->height();
        goto oh94q;
        XggoQ:
        \Log::warning('Failed to set final permissions on image file: ' . $p76Rw);
        goto a0I4W;
        nBlbq:
        $D1igg->update(['preview' => $tbsXX]);
        goto oTyaD;
        xvDLD:
        $p76Rw = $this->aW0a3->path($tbsXX);
        goto Ao_4W;
        RptUZ:
        $this->QxLu3->put($tbsXX, $this->aW0a3->get($tbsXX));
        goto io54u;
        qS3O2:
        $T4AWF = $this->ABFqP->call($this, $this->aW0a3->path($D1igg->getAttribute('thumbnail')));
        goto GqR4P;
        qNsX4:
        $T4AWF->blur(self::Fzp39);
        goto YD4L5;
        twg3k:
        $this->aW0a3->put($D1igg->getAttribute('thumbnail'), $this->QxLu3->get($D1igg->getAttribute('thumbnail')));
        goto qS3O2;
        io54u:
        unset($T4AWF);
        goto aiNiy;
        a0I4W:
        throw new \Exception('Failed to set final permissions on image file: ' . $p76Rw);
        goto wcmTo;
        k4Q5q:
        $D1igg = NYx4mhlHSMgHF::findOrFail($qMhfW);
        goto QTAPD;
        oh94q:
        $T4AWF->resize(self::VxG1F, self::RT7FO / $TlV7f);
        goto qNsX4;
        S1mWO:
        ini_set('memory_limit', '-1');
        goto k4Q5q;
        YD4L5:
        $tbsXX = $this->muOZqmZNOzL($D1igg);
        goto xvDLD;
        DXCwC:
    }
    private function muOZqmZNOzL(RV6vDyOPhxLM1 $VGjvC) : string
    {
        goto Qgyal;
        DKEQM:
        WmpgZ:
        goto x2m7U;
        Qgyal:
        $b0LKC = $VGjvC->getLocation();
        goto IVxG1;
        jhra6:
        $this->aW0a3->makeDirectory($kaImN, 0755, true);
        goto DKEQM;
        x2m7U:
        return $kaImN . $VGjvC->getFilename() . '.jpg';
        goto JDtWw;
        IVxG1:
        $kaImN = dirname($b0LKC) . '/preview/';
        goto l5XbT;
        l5XbT:
        if ($this->aW0a3->exists($kaImN)) {
            goto WmpgZ;
        }
        goto jhra6;
        JDtWw:
    }
}
