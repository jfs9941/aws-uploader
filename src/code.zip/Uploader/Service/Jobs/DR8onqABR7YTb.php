<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class DR8onqABR7YTb implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $uuHkQ) : void
    {
        goto kyliS;
        Eyd42:
        $this->mFb22dXGUkB($XrW52);
        goto TwZZc;
        GMWx1:
        if ($XrW52->width() > 0 && $XrW52->height() > 0) {
            goto SE6jS;
        }
        goto Eyd42;
        kyliS:
        $XrW52 = WrCq6RmnGcVh7::findOrFail($uuHkQ);
        goto GMWx1;
        TwZZc:
        SE6jS:
        goto BKJvp;
        BKJvp:
    }
    private function mFb22dXGUkB(WrCq6RmnGcVh7 $uQMyN) : void
    {
        goto y2bCE;
        O6hc9:
        $NM1IQ = $HO_3Y->getVideoStream();
        goto NP64C;
        y2bCE:
        $dBRu8 = $uQMyN->getView();
        goto P2MKS;
        bgsQY:
        $uQMyN->update(['duration' => $HO_3Y->getDurationInSeconds(), 'resolution' => $LnB5y->getWidth() . 'x' . $LnB5y->getHeight(), 'fps' => $NM1IQ->get('r_frame_rate') ?? 30]);
        goto VCjn6;
        NP64C:
        $LnB5y = $NM1IQ->getDimensions();
        goto bgsQY;
        P2MKS:
        $HO_3Y = FFMpeg::fromDisk($dBRu8['path'])->open($uQMyN->getAttribute('filename'));
        goto O6hc9;
        VCjn6:
    }
}
