<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Illuminate\Support\Facades\Log;
class XdQh4dhyPWLr8 implements StoreVideoToS3JobInterface
{
    private $j7CBR;
    private $BfyCm;
    private $S0euz;
    public function __construct($wiZGO, $ejImE, $t9rFg)
    {
        goto R0R0j;
        HlvvN:
        $this->j7CBR = $wiZGO;
        goto tqVFB;
        R0R0j:
        $this->BfyCm = $ejImE;
        goto P7Ijr;
        P7Ijr:
        $this->S0euz = $t9rFg;
        goto HlvvN;
        tqVFB:
    }
    public function store(string $aK0gt) : void
    {
        goto rskoE;
        rskoE:
        Log::info('Storing video (local) to S3', ['fileId' => $aK0gt, 'bucketName' => $this->j7CBR]);
        goto bgXeY;
        FyB44:
        $SwK9A = memory_get_peak_usage();
        goto a26BX;
        UmmGG:
        $Wz1mR = microtime(true);
        goto VL76E;
        Nrm4N:
        return;
        goto iB2Vx;
        iB2Vx:
        u23Cg:
        goto YJTdQ;
        bgXeY:
        ini_set('memory_limit', '-1');
        goto aEsxk;
        uDHbE:
        Log::error("[XdQh4dhyPWLr8] File not found, discard it ", ['video' => $Am30b->getLocation()]);
        goto imZby;
        r63K4:
        $o_gPM = $t9rFg->mimeType($Am30b->getLocation());
        goto UmmGG;
        ggMP6:
        Log::info("IfBHv1AJhiIDu has been deleted, discard it", ['fileId' => $aK0gt]);
        goto Nrm4N;
        VL76E:
        $bzMw6 = memory_get_usage();
        goto FyB44;
        YJTdQ:
        if ($t9rFg->exists($Am30b->getLocation())) {
            goto u0Bqd;
        }
        goto uDHbE;
        aEsxk:
        $y2JFM = $this->BfyCm->getClient();
        goto zGTra;
        yhUh8:
        $rzR1A = $t9rFg->readStream($Am30b->getLocation());
        goto FhZX1;
        FhZX1:
        $vQ2ya = 1024 * 1024 * 50;
        goto r63K4;
        zwLeF:
        if ($Am30b) {
            goto u23Cg;
        }
        goto ggMP6;
        a26BX:
        try {
            goto L3wJ9;
            X4FW8:
            $hqf7_ = $szBd8['UploadId'];
            goto cSy1H;
            jw5Bn:
            goto JVEfl;
            goto PJUYG;
            YuWy7:
            JVEfl:
            goto cQggv;
            Ihaqr:
            $RNKEH[] = ['PartNumber' => $SuQFE, 'ETag' => $FHgFm['ETag']];
            goto WJkv5;
            Jl546:
            $FHgFm = $y2JFM->uploadPart(['Bucket' => $this->j7CBR, 'Key' => $Am30b->getLocation(), 'UploadId' => $hqf7_, 'PartNumber' => $SuQFE, 'Body' => fread($rzR1A, $vQ2ya)]);
            goto Ihaqr;
            PJUYG:
            pTV4D:
            goto klE0w;
            V0f_9:
            $t9rFg->delete($Am30b->getLocation());
            goto cNcbG;
            klE0w:
            fclose($rzR1A);
            goto Vq0kr;
            cQggv:
            if (feof($rzR1A)) {
                goto pTV4D;
            }
            goto Jl546;
            WJkv5:
            $SuQFE++;
            goto jw5Bn;
            L3wJ9:
            $szBd8 = $y2JFM->createMultipartUpload(['Bucket' => $this->j7CBR, 'Key' => $Am30b->getLocation(), 'ContentType' => $o_gPM, 'ContentDisposition' => 'inline']);
            goto X4FW8;
            Vq0kr:
            $y2JFM->completeMultipartUpload(['Bucket' => $this->j7CBR, 'Key' => $Am30b->getLocation(), 'UploadId' => $hqf7_, 'MultipartUpload' => ['Parts' => $RNKEH]]);
            goto FH7xj;
            FH7xj:
            $Am30b->update(['driver' => ZuZC67ch9j73R::S3, 'status' => IOEDyer18cpSA::FINISHED]);
            goto V0f_9;
            BWmII:
            $RNKEH = [];
            goto YuWy7;
            cSy1H:
            $SuQFE = 1;
            goto BWmII;
            cNcbG:
        } catch (AwsException $t0AeI) {
            goto TNEgh;
            v3Nb0:
            try {
                $y2JFM->abortMultipartUpload(['Bucket' => $this->j7CBR, 'Key' => $Am30b->getLocation(), 'UploadId' => $hqf7_]);
            } catch (AwsException $yG6uR) {
                Log::error('Error aborting multipart upload: ' . $yG6uR->getMessage());
            }
            goto MHaqE;
            Uz_74:
            Log::error('Failed to store video: ' . $Am30b->getLocation() . ' - ' . $t0AeI->getMessage());
            goto Cy0Mq;
            TNEgh:
            if (!isset($hqf7_)) {
                goto DYULx;
            }
            goto v3Nb0;
            MHaqE:
            DYULx:
            goto Uz_74;
            Cy0Mq:
        } finally {
            $Iy0Ri = microtime(true);
            $W1Mek = memory_get_usage();
            $s5Fdg = memory_get_peak_usage();
            Log::info('Store IfBHv1AJhiIDu to S3 function resource usage', ['imageId' => $aK0gt, 'execution_time_sec' => $Iy0Ri - $Wz1mR, 'memory_usage_mb' => ($W1Mek - $bzMw6) / 1024 / 1024, 'peak_memory_usage_mb' => ($s5Fdg - $SwK9A) / 1024 / 1024]);
        }
        goto Kw4Ib;
        imZby:
        return;
        goto UnokM;
        UnokM:
        u0Bqd:
        goto yhUh8;
        zGTra:
        $t9rFg = $this->S0euz;
        goto N6FuF;
        N6FuF:
        $Am30b = IfBHv1AJhiIDu::find($aK0gt);
        goto zwLeF;
        Kw4Ib:
    }
}
