<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Enum\FileDriver;
class DUgUsbfTgkyq2 implements BlurJobInterface
{
    const CUgxQ = 15;
    const VOqXQ = 500;
    const kI5ZC = 500;
    private $Q1e5h;
    private $Aj6QZ;
    private $tGIcp;
    public function __construct($OdpJM, $SaekO, $UR4Dl)
    {
        goto Peoax;
        ju34n:
        $this->Aj6QZ = $SaekO;
        goto iGqhZ;
        Peoax:
        $this->tGIcp = $UR4Dl;
        goto ju34n;
        iGqhZ:
        $this->Q1e5h = $OdpJM;
        goto my53r;
        my53r:
    }
    public function blur(string $BFPg9) : void
    {
        goto uKyny;
        YSuQY:
        $ab1g_->save($zRrOa);
        goto SBq9Q;
        Ev71q:
        if (chmod($zRrOa, 0664)) {
            goto U5h86;
        }
        goto A3uz4;
        R8App:
        oCEwo:
        goto rS1Gj;
        BQPQC:
        $JA9pQ = $ab1g_->width() / $ab1g_->height();
        goto qNcf3;
        S49eh:
        ini_set('memory_limit', '-1');
        goto dCtPT;
        dCtPT:
        if (!($JPzNm->WJjcF == FileDriver::S3 && !$this->tGIcp->exists($JPzNm->filename))) {
            goto oCEwo;
        }
        goto NvP3T;
        SBq9Q:
        $ab1g_->destroy();
        goto Ev71q;
        uKyny:
        $JPzNm = ID6EZw1DKfqu4::findOrFail($BFPg9);
        goto S49eh;
        rS1Gj:
        $ab1g_ = $this->Q1e5h->call($this, $this->tGIcp->path($JPzNm->getLocation()));
        goto BQPQC;
        pRCy6:
        $JPzNm->update(['preview' => $UStoI]);
        goto hUWMo;
        QcoB2:
        $UStoI = $this->myy6cfLsqHs($JPzNm);
        goto Sbwu9;
        qNcf3:
        $ab1g_->resize(self::VOqXQ, self::kI5ZC / $JA9pQ);
        goto xI786;
        Sbwu9:
        $zRrOa = $this->tGIcp->path($UStoI);
        goto YSuQY;
        xI786:
        $ab1g_->blur(self::CUgxQ);
        goto QcoB2;
        A3uz4:
        \Log::warning('Failed to set final permissions on image file: ' . $zRrOa);
        goto a9Nz3;
        NvP3T:
        $eM17L = $this->Aj6QZ->get($JPzNm->filename);
        goto LQxh0;
        c_WVa:
        U5h86:
        goto pRCy6;
        a9Nz3:
        throw new \Exception('Failed to set final permissions on image file: ' . $zRrOa);
        goto c_WVa;
        LQxh0:
        $this->tGIcp->put($JPzNm->filename, $eM17L);
        goto R8App;
        hUWMo:
    }
    private function myy6cfLsqHs($ZiVxT) : string
    {
        goto BlgnV;
        oJVAa:
        return $kZACY . $ZiVxT->getFilename() . '.jpg';
        goto SxZdu;
        L0_rf:
        xSzTe:
        goto oJVAa;
        ks9Li:
        if ($this->tGIcp->exists($kZACY)) {
            goto xSzTe;
        }
        goto x4HDL;
        x4HDL:
        $this->tGIcp->makeDirectory($kZACY, 0755, true);
        goto L0_rf;
        BlgnV:
        $fdqWg = $ZiVxT->getLocation();
        goto hyAIo;
        hyAIo:
        $kZACY = dirname($fdqWg) . '/preview/';
        goto ks9Li;
        SxZdu:
    }
}
