<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
class Vgs13ZVzwh4OK implements DownloadToLocalJobInterface
{
    private $auR_S;
    private $P6k4O;
    public function __construct($JhAxH, $RNTis)
    {
        $this->auR_S = $JhAxH;
        $this->P6k4O = $RNTis;
    }
    public function download(string $IaHim) : void
    {
        goto xeVC3;
        JQdQq:
        jlZN2:
        goto zszhB;
        xeVC3:
        $QuYzZ = FNGNxcyxjaxBG::findOrFail($IaHim);
        goto QmW9W;
        ocD3l:
        return;
        goto JQdQq;
        QmW9W:
        Log::info("Start download file to local", ['fileId' => $IaHim, 'filename' => $QuYzZ->getLocation()]);
        goto tZuJs;
        zszhB:
        $this->P6k4O->put($QuYzZ->getLocation(), $this->auR_S->get($QuYzZ->getLocation()));
        goto lJ8xi;
        tZuJs:
        if (!$this->P6k4O->exists($QuYzZ->getLocation())) {
            goto jlZN2;
        }
        goto ocD3l;
        lJ8xi:
    }
}
