<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
class NeB6vgUzAuVqg implements BlurJobInterface
{
    const HFHlR = 15;
    const Afffq = 500;
    const lm_wJ = 500;
    private $lT6tT;
    private $bLZP5;
    private $qeI_k;
    public function __construct($W4G5n, $C1By6, $ShtWH)
    {
        goto stisj;
        stisj:
        $this->qeI_k = $ShtWH;
        goto HxL2I;
        HxL2I:
        $this->bLZP5 = $C1By6;
        goto My0XQ;
        My0XQ:
        $this->lT6tT = $W4G5n;
        goto o4x0c;
        o4x0c:
    }
    public function blur(string $DWjir) : void
    {
        goto CEt7A;
        g4luD:
        $j_mpB = $KlHaV->width() / $KlHaV->height();
        goto Dv_8Q;
        hwVsf:
        unset($KlHaV);
        goto JlBN3;
        aSEu1:
        rRnN8:
        goto qPqvC;
        EmIuY:
        \Log::warning('Failed to set final permissions on image file: ' . $f67Wo);
        goto cordG;
        CEt7A:
        $AD715 = IQJN6V0t7DC7c::findOrFail($DWjir);
        goto uW1Ml;
        Sd3Mc:
        $f67Wo = $this->bLZP5->put($Qh53y, $KlHaV->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto hwVsf;
        EgvTd:
        $this->qeI_k->put($AD715->filename, $uxoVV);
        goto aSEu1;
        cordG:
        throw new \Exception('Failed to set final permissions on image file: ' . $f67Wo);
        goto Mrejq;
        WDYGr:
        $uxoVV = $this->bLZP5->get($AD715->filename);
        goto EgvTd;
        qPqvC:
        $KlHaV = $this->lT6tT->call($this, $this->qeI_k->path($AD715->getLocation()));
        goto g4luD;
        psgoe:
        $KlHaV->blur(self::HFHlR);
        goto IhB4W;
        j2L0v:
        if (!($AD715->h8PS2 == KkaUVP3OQvOtp::S3 && !$this->qeI_k->exists($AD715->filename))) {
            goto rRnN8;
        }
        goto WDYGr;
        VuNN7:
        $AD715->update(['preview' => $Qh53y]);
        goto uF7SX;
        Mrejq:
        wt4Jl:
        goto VuNN7;
        IhB4W:
        $Qh53y = $this->m7L24yaZgjE($AD715);
        goto Sd3Mc;
        JlBN3:
        if (chmod($f67Wo, 0664)) {
            goto wt4Jl;
        }
        goto EmIuY;
        uW1Ml:
        ini_set('memory_limit', '-1');
        goto j2L0v;
        Dv_8Q:
        $KlHaV->resize(self::Afffq, self::lm_wJ / $j_mpB);
        goto psgoe;
        uF7SX:
    }
    private function m7L24yaZgjE($I9WVv) : string
    {
        goto WQHds;
        QC00g:
        hE4RB:
        goto Jygoe;
        Jygoe:
        return $F7Xbk . $I9WVv->getFilename() . '.jpg';
        goto ZqI3W;
        XWqtu:
        $F7Xbk = dirname($iVcpi) . '/preview/';
        goto xe_4f;
        uWMiw:
        $this->qeI_k->makeDirectory($F7Xbk, 0755, true);
        goto QC00g;
        xe_4f:
        if ($this->qeI_k->exists($F7Xbk)) {
            goto hE4RB;
        }
        goto uWMiw;
        WQHds:
        $iVcpi = $I9WVv->getLocation();
        goto XWqtu;
        ZqI3W:
    }
}
