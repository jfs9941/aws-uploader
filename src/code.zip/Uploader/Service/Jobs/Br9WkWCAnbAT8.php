<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Br9WkWCAnbAT8 implements GenerateThumbnailJobInterface
{
    const ycJ33 = 150;
    const L31tq = 150;
    private $buleS;
    private $pCaD7;
    private $Svend;
    public function __construct($nFvaK, $P3zvl, $jQtQe)
    {
        goto m1Jtr;
        uELTI:
        $this->pCaD7 = $P3zvl;
        goto bDyOL;
        m1Jtr:
        $this->buleS = $nFvaK;
        goto uELTI;
        bDyOL:
        $this->Svend = $jQtQe;
        goto jGviC;
        jGviC:
    }
    public function generate(string $InHEz)
    {
        goto QMh5W;
        QMh5W:
        Log::info("Generating thumbnail", ['imageId' => $InHEz]);
        goto w64j1;
        anuVG:
        try {
            goto U7uxa;
            XQw4t:
            Eqxcb:
            goto kljW7;
            D34Yh:
            $VGttq->update(['thumbnail' => $hKqqZ, 'status' => ZP6Ky842t6y9Y::THUMBNAIL_PROCESSED]);
            goto XQw4t;
            h3mVL:
            $alKD9->orient()->resize(150, 150);
            goto sF0Sx;
            C1ooG:
            if (!($qhXQZ !== false)) {
                goto Eqxcb;
            }
            goto D34Yh;
            Wb4rd:
            $qhXQZ = $this->Svend->put($hKqqZ, $alKD9->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto mElCB;
            hOTZn:
            $VGttq = UKkbXBDRxjSUY::findOrFail($InHEz);
            goto GltoN;
            sF0Sx:
            $hKqqZ = $this->mb3XeVOKROc($VGttq);
            goto Wb4rd;
            U7uxa:
            $Ay4fJ = $this->pCaD7;
            goto hOTZn;
            GltoN:
            $alKD9 = $this->buleS->call($this, $Ay4fJ->path($VGttq->getLocation()));
            goto h3mVL;
            mElCB:
            unset($alKD9);
            goto C1ooG;
            kljW7:
        } catch (ModelNotFoundException $uF3lz) {
            Log::info("UKkbXBDRxjSUY has been deleted, discard it", ['imageId' => $InHEz]);
            return;
        } catch (\Exception $uF3lz) {
            Log::error("Failed to generate thumbnail", ['imageId' => $InHEz, 'error' => $uF3lz->getMessage()]);
        }
        goto GXVAr;
        w64j1:
        ini_set('memory_limit', '-1');
        goto anuVG;
        GXVAr:
    }
    private function mb3XeVOKROc(IeEvjRaj1LMmG $VGttq) : string
    {
        goto ySE4Q;
        ySE4Q:
        $hKqqZ = $VGttq->getLocation();
        goto n1mNN;
        oVmse:
        $cfbPS = $jY69S . '/' . self::ycJ33 . 'X' . self::L31tq;
        goto djI2D;
        n1mNN:
        $jY69S = dirname($hKqqZ);
        goto oVmse;
        djI2D:
        return $cfbPS . '/' . $VGttq->getFilename() . '.jpg';
        goto xaaAu;
        xaaAu:
    }
}
