<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
class RtK6at3CRkntq implements GenerateThumbnailJobInterface
{
    const GgqFG = 150;
    const f0GyN = 150;
    private $mwf2R;
    private $riMoE;
    public function __construct($eF8NA, $BP_p5)
    {
        $this->mwf2R = $eF8NA;
        $this->riMoE = $BP_p5;
    }
    public function generate(string $mfjeD)
    {
        goto bOscx;
        UDY4I:
        try {
            goto haJWj;
            vEUb0:
            $kF97t = $this->mwf2R->call($this, $AhP23->path($fK3zd->getLocation()));
            goto trLkg;
            yDJJ7:
            Log::warning('Failed to set file permissions for stored image: ' . $IM5_2);
            goto kiUab;
            kjt50:
            $fK3zd->update(['thumbnail' => $J9IgU, 'status' => SwAwanZG36Yx6::THUMBNAIL_PROCESSED]);
            goto W8G7W;
            uXQUd:
            if (chmod($IM5_2, 0644)) {
                goto jo2c1;
            }
            goto yDJJ7;
            FjP_Q:
            $rAC8B = $AhP23->put($J9IgU, $kF97t->toWebp(70), ['visibility' => 'public']);
            goto LCNnn;
            kwUb4:
            if (!($rAC8B !== false)) {
                goto bOoQp;
            }
            goto kjt50;
            LCNnn:
            unset($kF97t);
            goto kwUb4;
            haJWj:
            $AhP23 = $this->riMoE;
            goto oEUMH;
            kiUab:
            throw new \Exception('Failed to set file permissions for stored image: ' . $IM5_2);
            goto NJxrU;
            W8G7W:
            $IM5_2 = $AhP23->path($J9IgU);
            goto uXQUd;
            NJxrU:
            jo2c1:
            goto Cusz5;
            e_mJ6:
            $J9IgU = $this->msYkutivjiO($fK3zd);
            goto FjP_Q;
            oEUMH:
            $fK3zd = DsyQbNiy8VgJG::findOrFail($mfjeD);
            goto vEUb0;
            trLkg:
            $kF97t = $kF97t->orient()->resize(150, 150);
            goto e_mJ6;
            Cusz5:
            bOoQp:
            goto j2AcF;
            j2AcF:
        } catch (ModelNotFoundException $iE7wL) {
            Log::info("DsyQbNiy8VgJG has been deleted, discard it", ['imageId' => $mfjeD]);
            return;
        }
        goto C2hWb;
        LqJrg:
        ini_set('memory_limit', '-1');
        goto UDY4I;
        bOscx:
        Log::info("Generating thumbnail", ['imageId' => $mfjeD]);
        goto LqJrg;
        C2hWb:
    }
    private function msYkutivjiO(Yn8aWzKzROkno $fK3zd) : string
    {
        goto Uy3wx;
        tPsWb:
        $Wp3Im = dirname($J9IgU);
        goto XHJws;
        Uy3wx:
        $J9IgU = $fK3zd->getLocation();
        goto tPsWb;
        XHJws:
        $bRUGD = $Wp3Im . '/' . self::GgqFG . 'X' . self::f0GyN;
        goto YDYuf;
        YDYuf:
        return $bRUGD . '/' . $fK3zd->getFilename() . '.jpg';
        goto WsmvZ;
        WsmvZ:
    }
}
