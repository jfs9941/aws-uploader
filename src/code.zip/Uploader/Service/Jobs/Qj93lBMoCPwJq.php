<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Encoder\KUtW8CyIwsZh0;
use Jfs\Uploader\Encoder\GEB19HZppIkTI;
use Jfs\Uploader\Encoder\HYDAkFMesEGUF;
use Jfs\Uploader\Encoder\Lx636Dczn2DZA;
use Jfs\Uploader\Encoder\FffZ2siMxgG2d;
use Jfs\Uploader\Encoder\SiU7y124YaM9x;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Jfs\Uploader\Service\Jobs\T5ZZWWFggB97v;
use Jfs\Uploader\Service\Jobs\BfkurxdTziJpV;
use Jfs\Uploader\Service\EjF4mjWaYHYqw;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class Qj93lBMoCPwJq implements MediaEncodeJobInterface
{
    private $S7Zrn;
    private $niO3l;
    private $VV2A8;
    private $qhFb9;
    private $Di2j4;
    public function __construct(string $xYZ3A, $xuow1, $oOPBt, $lJlOD, $Ul7uk)
    {
        goto eZJwq;
        dRG77:
        $this->VV2A8 = $oOPBt;
        goto BySfS;
        cYMkW:
        $this->niO3l = $xuow1;
        goto dRG77;
        BySfS:
        $this->qhFb9 = $lJlOD;
        goto iWIuF;
        iWIuF:
        $this->Di2j4 = $Ul7uk;
        goto xuXuN;
        eZJwq:
        $this->S7Zrn = $xYZ3A;
        goto cYMkW;
        xuXuN:
    }
    public function encode(string $GhyxD, string $Dk9f1, $C9CAB = true) : void
    {
        goto y1W0e;
        mkgUI:
        try {
            goto dosAi;
            FmiNp:
            Vo733:
            goto cIBbS;
            kQ5NZ:
            $GhyxD = $LRBQB->mqb99rdLPGq($this->mZOMWFmRewg($bKijV, $C9CAB));
            goto UF26X;
            Hk7gX:
            $LRBQB->mQWhKak6LTl($M0Djz);
            goto Qe2DQ;
            v0olV:
            $moIQT = app(EjF4mjWaYHYqw::class);
            goto BHiuN;
            bjFBx:
            $M0Djz = new GEB19HZppIkTI('original', $Un71V, $aHbCv, $bKijV->wTiwY ?? 30);
            goto hyFhh;
            cIBbS:
            Log::info("Set thumbnail for VHp3UACVYl357 Job", ['videoId' => $bKijV->getAttribute('id'), 'duration' => $bKijV->getAttribute('duration')]);
            goto C4KFS;
            B0tAO:
            $tu4WU = $tu4WU->mo647wo27ir($zh_ru);
            goto C0WBu;
            UF26X:
            $bKijV->update(['aws_media_converter_job_id' => $GhyxD]);
            goto Y2ZHK;
            cCccX:
            Log::info("Set 1080p resolution for Job", ['width' => $GWZs7['width'], 'height' => $GWZs7['height'], 'originalWidth' => $Un71V, 'originalHeight' => $aHbCv]);
            goto IYkdI;
            QK__t:
            $M0Djz = $M0Djz->mo647wo27ir($zh_ru);
            goto DyUYF;
            aN3OT:
            $LRBQB = $LRBQB->mQWhKak6LTl($tu4WU);
            goto wsiHk;
            BHiuN:
            $t6WEw = new BfkurxdTziJpV($this->qhFb9, $this->Di2j4, $this->VV2A8, $this->niO3l);
            goto usEqD;
            cNrQt:
            $aHbCv = $bKijV->height();
            goto WtQAt;
            rjtwv:
            $LRBQB = $LRBQB->mJpgGSnisw2($w6RVC);
            goto kQ5NZ;
            wsiHk:
            zqr2S:
            goto FmiNp;
            IyRaP:
            Log::info("Set input video for Job", ['s3Uri' => $yzADg]);
            goto vy8QM;
            IYkdI:
            $tu4WU = new GEB19HZppIkTI('1080p', $GWZs7['width'], $GWZs7['height'], $bKijV->wTiwY ?? 30);
            goto X7lwm;
            KbF1z:
            if (!$zh_ru) {
                goto iC5wO;
            }
            goto B0tAO;
            C0WBu:
            iC5wO:
            goto aN3OT;
            usEqD:
            $zh_ru = $this->mIZVTpCS0X5($moIQT, $t6WEw->m9xBuLdlu22($bKijV->width(), $bKijV->height(), $Dk9f1));
            goto ljHRi;
            Q2xlx:
            $GWZs7 = $this->mTwQ0BdFncc($Un71V, $aHbCv);
            goto cCccX;
            WtQAt:
            $yzADg = $this->m1CbP8mAqVj($bKijV);
            goto IyRaP;
            C4KFS:
            $w6RVC = new KUtW8CyIwsZh0($bKijV->Xoe5B ?? 1, 2, $EEJLx->mBcSpYDylRi($bKijV));
            goto rjtwv;
            hyFhh:
            $EEJLx = app(HYDAkFMesEGUF::class);
            goto M9ozD;
            X7lwm:
            $zh_ru = $this->mIZVTpCS0X5($moIQT, $t6WEw->m9xBuLdlu22((int) $GWZs7['width'], (int) $GWZs7['height'], $Dk9f1));
            goto KbF1z;
            ljHRi:
            if (!$zh_ru) {
                goto oHYGq;
            }
            goto QK__t;
            Skoa2:
            s8heB:
            goto u04uv;
            Q0BJ2:
            $LRBQB = $LRBQB->mNIEMAiViBT(new Lx636Dczn2DZA($yzADg));
            goto bjFBx;
            ZNZKj:
            Assert::isInstanceOf($bKijV, VHp3UACVYl357::class);
            goto vXQ03;
            Qe2DQ:
            $LRBQB->m147hZEQzrJ($EEJLx->ms5A2GnsX86($bKijV));
            goto i8TjJ;
            DyUYF:
            oHYGq:
            goto Hk7gX;
            dosAi:
            $bKijV = VHp3UACVYl357::findOrFail($GhyxD);
            goto ZNZKj;
            i8TjJ:
            if (!($Un71V && $aHbCv)) {
                goto Vo733;
            }
            goto mXktj;
            LVyYX:
            throw new MediaConverterException("VHp3UACVYl357 {$bKijV->id} is not S3 driver");
            goto Skoa2;
            mXktj:
            if (!$this->m7i2iPu3xur($Un71V, $aHbCv)) {
                goto zqr2S;
            }
            goto Q2xlx;
            vy8QM:
            $LRBQB = app(FffZ2siMxgG2d::class);
            goto Q0BJ2;
            u04uv:
            $Un71V = $bKijV->width();
            goto cNrQt;
            vXQ03:
            if (!($bKijV->G8msK !== GoWVLKcTGnffy::S3)) {
                goto s8heB;
            }
            goto LVyYX;
            ce41O:
            $LRBQB->m147hZEQzrJ($EEJLx->ms5A2GnsX86($bKijV));
            goto v0olV;
            M9ozD:
            $LRBQB->mQWhKak6LTl($M0Djz);
            goto ce41O;
            Y2ZHK:
        } catch (\Exception $YIsP2) {
            Log::info("VHp3UACVYl357 has been deleted, discard it", ['fileId' => $GhyxD, 'err' => $YIsP2->getMessage()]);
            return;
        }
        goto vVFNP;
        y1W0e:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $GhyxD]);
        goto ZcIyE;
        ZcIyE:
        ini_set('memory_limit', '-1');
        goto mkgUI;
        vVFNP:
    }
    private function mZOMWFmRewg(VHp3UACVYl357 $bKijV, $C9CAB) : bool
    {
        goto gKsAb;
        SpH9v:
        gZQJr:
        goto LnsIJ;
        SqFa7:
        DYQWV:
        goto lMQIs;
        SIgVO:
        DBre3:
        goto SpH9v;
        gKsAb:
        if ($C9CAB) {
            goto DYQWV;
        }
        goto ynefK;
        K5zqG:
        switch (true) {
            case $bKijV->width() * $bKijV->height() >= 1920 * 1080 && $bKijV->width() * $bKijV->height() < 2560 * 1440:
                return $A8OSa > 10 * 60;
            case $bKijV->width() * $bKijV->height() >= 2560 * 1440 && $bKijV->width() * $bKijV->height() < 3840 * 2160:
                return $A8OSa > 5 * 60;
            case $bKijV->width() * $bKijV->height() >= 3840 * 2160:
                return $A8OSa > 3 * 60;
            default:
                return false;
        }
        goto SIgVO;
        lMQIs:
        $A8OSa = (int) round($bKijV->getAttribute('duration') ?? 0);
        goto K5zqG;
        ynefK:
        return false;
        goto SqFa7;
        LnsIJ:
    }
    private function mIZVTpCS0X5(EjF4mjWaYHYqw $moIQT, string $RRgGr) : ?SiU7y124YaM9x
    {
        goto hW_LT;
        cUTFz:
        Log::info("Resolve watermark for job with url", ['url' => $RRgGr, 'uri' => $HvAu9]);
        goto BnUyj;
        WW1ws:
        return new SiU7y124YaM9x($HvAu9, 0, 0, null, null);
        goto fwS0S;
        BnUyj:
        if (!$HvAu9) {
            goto rjxg4;
        }
        goto WW1ws;
        fwS0S:
        rjxg4:
        goto W3x78;
        hW_LT:
        $HvAu9 = $moIQT->mYtzp5wmt0Q($RRgGr);
        goto cUTFz;
        W3x78:
        return null;
        goto cIKoS;
        cIKoS:
    }
    private function m7i2iPu3xur(int $Un71V, int $aHbCv) : bool
    {
        return $Un71V * $aHbCv > 1.5 * (1920 * 1080);
    }
    private function mTwQ0BdFncc(int $Un71V, int $aHbCv) : array
    {
        $RTjn4 = new T5ZZWWFggB97v($Un71V, $aHbCv);
        return $RTjn4->miOYf0zDgHO();
    }
    private function m1CbP8mAqVj(OXsaQ69LP2fiA $L7rEe) : string
    {
        goto RQEEW;
        JwmiO:
        IB7ov:
        goto EvV80;
        EvV80:
        return $this->niO3l->url($L7rEe->filename);
        goto PUVvh;
        RQEEW:
        if (!($L7rEe->G8msK == GoWVLKcTGnffy::S3)) {
            goto IB7ov;
        }
        goto STSOn;
        STSOn:
        return 's3://' . $this->S7Zrn . '/' . $L7rEe->filename;
        goto JwmiO;
        PUVvh:
    }
}
