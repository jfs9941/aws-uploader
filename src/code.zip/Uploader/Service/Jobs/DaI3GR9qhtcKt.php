<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class DaI3GR9qhtcKt implements StoreVideoToS3JobInterface
{
    private $uYfQs;
    private $GQuun;
    private $Farqu;
    public function __construct($mJZ7g, $Q0shJ, $MQQLd)
    {
        goto PNbwk;
        tJggh:
        $this->uYfQs = $mJZ7g;
        goto mREKA;
        PNbwk:
        $this->GQuun = $Q0shJ;
        goto fb2jC;
        fb2jC:
        $this->Farqu = $MQQLd;
        goto tJggh;
        mREKA:
    }
    public function store(string $eXur0) : void
    {
        goto WPuxY;
        Un1og:
        $kEBaZ = $this->GQuun->getClient();
        goto r5PyQ;
        e95T2:
        if ($MQQLd->exists($ROMeE->getLocation())) {
            goto R_T4g;
        }
        goto sZ0x6;
        xvn4X:
        $ROMeE = S25BfMDKrX8cB::find($eXur0);
        goto f_8M8;
        rEER9:
        try {
            goto wtLSU;
            yRvgy:
            goto v7fib;
            goto VxtG8;
            rpfa0:
            $FvPBh++;
            goto yRvgy;
            Dj007:
            v7fib:
            goto iSt24;
            O_gkE:
            $WuWD8 = [];
            goto Dj007;
            v5v7s:
            $kEBaZ->completeMultipartUpload(['Bucket' => $this->uYfQs, 'Key' => $ROMeE->getLocation(), 'UploadId' => $HXXez, 'MultipartUpload' => ['Parts' => $WuWD8]]);
            goto Iu29O;
            Iu29O:
            $ROMeE->update(['driver' => VCKF0xK25vLxq::S3, 'status' => N4CY6qDTBAjPa::FINISHED]);
            goto ewiRz;
            xhu70:
            $FvPBh = 1;
            goto O_gkE;
            qVg5F:
            $WuWD8[] = ['PartNumber' => $FvPBh, 'ETag' => $dTTjG['ETag']];
            goto rpfa0;
            VxtG8:
            cAz2W:
            goto HvyGn;
            wtLSU:
            $BVjJ8 = $kEBaZ->createMultipartUpload(['Bucket' => $this->uYfQs, 'Key' => $ROMeE->getLocation(), 'ContentType' => $TGa6W, 'ContentDisposition' => 'inline']);
            goto hTUxM;
            hTUxM:
            $HXXez = $BVjJ8['UploadId'];
            goto xhu70;
            iSt24:
            if (feof($iaYkj)) {
                goto cAz2W;
            }
            goto pk3CZ;
            pk3CZ:
            $dTTjG = $kEBaZ->uploadPart(['Bucket' => $this->uYfQs, 'Key' => $ROMeE->getLocation(), 'UploadId' => $HXXez, 'PartNumber' => $FvPBh, 'Body' => fread($iaYkj, $rQwH5)]);
            goto qVg5F;
            ewiRz:
            $MQQLd->delete($ROMeE->getLocation());
            goto T4wWH;
            HvyGn:
            fclose($iaYkj);
            goto v5v7s;
            T4wWH:
        } catch (AwsException $HqoZE) {
            goto HMl7I;
            cHBlI:
            try {
                $kEBaZ->abortMultipartUpload(['Bucket' => $this->uYfQs, 'Key' => $ROMeE->getLocation(), 'UploadId' => $HXXez]);
            } catch (AwsException $clOVO) {
                Log::error('Error aborting multipart upload: ' . $clOVO->getMessage());
            }
            goto hP3JQ;
            L2HB9:
            Log::error('Failed to store video: ' . $ROMeE->getLocation() . ' - ' . $HqoZE->getMessage());
            goto Zjnsv;
            hP3JQ:
            hxV14:
            goto L2HB9;
            HMl7I:
            if (!isset($HXXez)) {
                goto hxV14;
            }
            goto cHBlI;
            Zjnsv:
        }
        goto jSahq;
        HTzTq:
        R_T4g:
        goto kbnWm;
        kbnWm:
        $iaYkj = $MQQLd->readStream($ROMeE->getLocation());
        goto wSXac;
        Q4gV1:
        Log::info("S25BfMDKrX8cB has been deleted, discard it", ['fileId' => $eXur0]);
        goto dWBX_;
        hfHIr:
        ini_set('memory_limit', '-1');
        goto Un1og;
        dWBX_:
        return;
        goto deMIc;
        f_8M8:
        if ($ROMeE) {
            goto XoGqs;
        }
        goto Q4gV1;
        sZ0x6:
        Log::error("[DaI3GR9qhtcKt] File not found, discard it ", ['video' => $ROMeE->getLocation()]);
        goto BsA8h;
        sgJDs:
        $TGa6W = $MQQLd->mimeType($ROMeE->getLocation());
        goto rEER9;
        wSXac:
        $rQwH5 = 1024 * 1024 * 50;
        goto sgJDs;
        r5PyQ:
        $MQQLd = $this->Farqu;
        goto xvn4X;
        BsA8h:
        return;
        goto HTzTq;
        WPuxY:
        Log::info('Storing video (local) to S3', ['fileId' => $eXur0, 'bucketName' => $this->uYfQs]);
        goto hfHIr;
        deMIc:
        XoGqs:
        goto e95T2;
        jSahq:
    }
}
