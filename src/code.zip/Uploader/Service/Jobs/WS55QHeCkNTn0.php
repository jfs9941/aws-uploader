<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
class WS55QHeCkNTn0 implements GenerateThumbnailJobInterface
{
    const WkNZV = 150;
    const HuM8M = 150;
    private $z59AQ;
    private $kxBLk;
    public function __construct($fbqBq, $dgfeu)
    {
        $this->z59AQ = $fbqBq;
        $this->kxBLk = $dgfeu;
    }
    public function generate(string $y06DH)
    {
        goto OaEwC;
        cSBNT:
        try {
            goto iHz32;
            ey_CE:
            $P2AJQ->update(['thumbnail' => $IB9Pt, 'status' => RwOJkCXwa9RQz::THUMBNAIL_PROCESSED]);
            goto nF65h;
            IzUNc:
            throw new \Exception('Failed to set file permissions for stored image: ' . $t8VCW);
            goto LcEpG;
            iHz32:
            $mFX9i = $this->kxBLk;
            goto hnY6v;
            LdJVj:
            $C0NJM->destroy();
            goto Rn5Sg;
            nF65h:
            $t8VCW = $mFX9i->path($IB9Pt);
            goto T53Uk;
            hnY6v:
            $P2AJQ = LGMw063tEE9ZC::findOrFail($y06DH);
            goto lmUfB;
            GQlra:
            $IB9Pt = $this->mtdKgh29brn($P2AJQ);
            goto lsXPS;
            T53Uk:
            if (chmod($t8VCW, 0644)) {
                goto ein0F;
            }
            goto drf1V;
            lsXPS:
            $NY2Vj = $mFX9i->put($IB9Pt, $C0NJM->stream(), ['visibility' => 'public']);
            goto LdJVj;
            AsS54:
            $C0NJM->fit(150, 150, function ($zMpkY) {
                $zMpkY->aspectRatio();
            });
            goto FGOmc;
            drf1V:
            Log::warning('Failed to set file permissions for stored image: ' . $t8VCW);
            goto IzUNc;
            LcEpG:
            ein0F:
            goto kNUPs;
            lmUfB:
            $C0NJM = $this->z59AQ->call($this, $mFX9i->path($P2AJQ->getLocation()));
            goto AsS54;
            kNUPs:
            c51Ux:
            goto QYcZI;
            FGOmc:
            $C0NJM->encode('jpg', 80);
            goto GQlra;
            Rn5Sg:
            if (!($NY2Vj !== false)) {
                goto c51Ux;
            }
            goto ey_CE;
            QYcZI:
        } catch (ModelNotFoundException $rq1wj) {
            Log::info("LGMw063tEE9ZC has been deleted, discard it", ['imageId' => $y06DH]);
            return;
        }
        goto tDvmW;
        OaEwC:
        Log::info("Generating thumbnail", ['imageId' => $y06DH]);
        goto GUepm;
        GUepm:
        ini_set('memory_limit', '-1');
        goto cSBNT;
        tDvmW:
    }
    private function mtdKgh29brn(UKWxL8i4Jx2NZ $P2AJQ) : string
    {
        goto LoH96;
        CHpiw:
        $DFtpv = $vQ3Gb . '/' . self::WkNZV . 'X' . self::HuM8M;
        goto SAtaf;
        LoH96:
        $IB9Pt = $P2AJQ->getLocation();
        goto B0Bqk;
        B0Bqk:
        $vQ3Gb = dirname($IB9Pt);
        goto CHpiw;
        SAtaf:
        return $DFtpv . '/' . $P2AJQ->getFilename() . '.jpg';
        goto y6niw;
        y6niw:
    }
}
