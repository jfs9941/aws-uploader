<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
class HOkKTcQ4ZI88G implements StoreToS3JobInterface
{
    private $aQPLw;
    private $ifs25;
    private $gq_yF;
    public function __construct($fhNRF, $PQlIa, $gBW_k)
    {
        goto MVrD7;
        STfX6:
        $this->aQPLw = $fhNRF;
        goto OY_VX;
        gYoT5:
        $this->gq_yF = $gBW_k;
        goto STfX6;
        MVrD7:
        $this->ifs25 = $PQlIa;
        goto gYoT5;
        OY_VX:
    }
    public function store(string $PV4mw) : void
    {
        goto UGrVo;
        UGrVo:
        $a221h = McTg5Yp6FKC6z::findOrFail($PV4mw);
        goto NVGHy;
        tko7J:
        return;
        goto u_m8g;
        ds8Li:
        $sEueW = $this->gq_yF->path($a221h->getLocation());
        goto iFMhJ;
        Ua75j:
        if (!($Hw7KW && $this->gq_yF->exists($Hw7KW))) {
            goto DLt4L;
        }
        goto EFPmi;
        F73p7:
        McTg5Yp6FKC6z::where('parent_id', $PV4mw)->update(['driver' => GrPXtp41lLmde::S3, 'preview' => $a221h->getAttribute('preview'), 'thumbnail' => $a221h->getAttribute('thumbnail')]);
        goto tko7J;
        rZ4WU:
        $Hw7KW = $a221h->getAttribute('thumbnail');
        goto Ua75j;
        Az_Xf:
        $this->ifs25->put($a221h->getLocation(), $SYKC9->stream(), ['visibility' => 'public', 'ContentType' => $SYKC9->mime(), 'ContentDisposition' => 'inline']);
        goto rZ4WU;
        bGFvX:
        Log::info("McTg5Yp6FKC6z has been deleted, discard it", ['fileId' => $PV4mw]);
        goto mE0nO;
        w8p31:
        kcl7B:
        goto B53CW;
        NVGHy:
        if ($a221h) {
            goto FnaNi;
        }
        goto bGFvX;
        OFBeH:
        FnaNi:
        goto ds8Li;
        z1LbY:
        if (!($a221h->getAttribute('preview') && $this->gq_yF->exists($a221h->getAttribute('preview')))) {
            goto kcl7B;
        }
        goto vESvT;
        EFPmi:
        $iSO5V = $this->gq_yF->path($Hw7KW);
        goto uwNFB;
        u_m8g:
        N3ulY:
        goto nIhzu;
        B53CW:
        if (!$a221h->update(['driver' => GrPXtp41lLmde::S3, 'status' => O8RzIjGmSN6fG::FINISHED])) {
            goto N3ulY;
        }
        goto Qq3Zz;
        fdMcF:
        $this->ifs25->put($a221h->getAttribute('preview'), $e3C87->stream(), ['visibility' => 'public', 'ContentType' => $e3C87->mime(), 'ContentDisposition' => 'inline']);
        goto w8p31;
        FfM1x:
        DLt4L:
        goto z1LbY;
        iFMhJ:
        $SYKC9 = $this->aQPLw->call($this, $sEueW);
        goto Az_Xf;
        Qq3Zz:
        Log::info("McTg5Yp6FKC6z stored to S3, update the children attachments", ['fileId' => $PV4mw]);
        goto F73p7;
        uwNFB:
        $IlGiN = $this->aQPLw->call($this, $iSO5V);
        goto fpr8g;
        F5l5R:
        $e3C87 = $this->aQPLw->call($this, $rnJia);
        goto fdMcF;
        nIhzu:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $PV4mw]);
        goto eHfhg;
        vESvT:
        $rnJia = $this->gq_yF->path($a221h->getAttribute('preview'));
        goto F5l5R;
        mE0nO:
        return;
        goto OFBeH;
        fpr8g:
        $this->ifs25->put($a221h->getAttribute('thumbnail'), $IlGiN->stream(), ['visibility' => 'public', 'ContentType' => $IlGiN->mime(), 'ContentDisposition' => 'inline']);
        goto FfM1x;
        eHfhg:
    }
}
