<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
class DMGQ9Xjdp3VxL implements StoreToS3JobInterface
{
    private $IfECA;
    private $zTo0t;
    private $uBhrQ;
    public function __construct($AaIEl, $Vi8xq, $Ms6sq)
    {
        goto VDUZV;
        VDUZV:
        $this->zTo0t = $Vi8xq;
        goto j0qSb;
        j0qSb:
        $this->uBhrQ = $Ms6sq;
        goto YjmoO;
        YjmoO:
        $this->IfECA = $AaIEl;
        goto ai2UN;
        ai2UN:
    }
    public function store(string $S6xyJ) : void
    {
        goto Z4xzt;
        ZgXUR:
        if (!($r3m4D && $this->uBhrQ->exists($r3m4D))) {
            goto aqsv3;
        }
        goto lzVJ1;
        rNLma:
        WYSuk:
        goto Q9Wu2;
        tc4Fy:
        $this->zTo0t->put($cRLb2->getAttribute('preview'), $pQGW1->stream(), ['visibility' => 'public', 'ContentType' => $pQGW1->mime(), 'ContentDisposition' => 'inline']);
        goto f8gy2;
        wlm6v:
        yihBv:
        goto LSqD_;
        A6C8L:
        $this->zTo0t->put($cRLb2->getLocation(), $iy9bs->stream(), ['visibility' => 'public', 'ContentType' => $iy9bs->mime(), 'ContentDisposition' => 'inline']);
        goto ulEjS;
        lzVJ1:
        $sZx9U = $this->uBhrQ->path($r3m4D);
        goto sLg4p;
        nBkIm:
        JyZaxpharsbun::where('parent_id', $S6xyJ)->update(['driver' => Rc6MZhMMdyG6A::S3, 'preview' => $cRLb2->getAttribute('preview'), 'thumbnail' => $cRLb2->getAttribute('thumbnail')]);
        goto I_6F2;
        ulEjS:
        $r3m4D = $cRLb2->getAttribute('thumbnail');
        goto ZgXUR;
        V55it:
        $NzFkF = $this->uBhrQ->path($cRLb2->getAttribute('preview'));
        goto nMP9s;
        f8gy2:
        kYwj0:
        goto MAM63;
        USidU:
        aqsv3:
        goto yzV9O;
        sLg4p:
        $c2ORW = $this->IfECA->call($this, $sZx9U);
        goto Rbyl6;
        LSqD_:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $S6xyJ]);
        goto duk_1;
        Rbyl6:
        $this->zTo0t->put($cRLb2->getAttribute('thumbnail'), $c2ORW->stream(), ['visibility' => 'public', 'ContentType' => $c2ORW->mime(), 'ContentDisposition' => 'inline']);
        goto USidU;
        Zp1wV:
        Log::info("JyZaxpharsbun stored to S3, update the children attachments", ['fileId' => $S6xyJ]);
        goto nBkIm;
        Z4xzt:
        $cRLb2 = JyZaxpharsbun::findOrFail($S6xyJ);
        goto Ha6A9;
        i_4A3:
        $iy9bs = $this->IfECA->call($this, $z69yI);
        goto A6C8L;
        XDE85:
        Log::info("JyZaxpharsbun has been deleted, discard it", ['fileId' => $S6xyJ]);
        goto u5dnu;
        u5dnu:
        return;
        goto rNLma;
        Ha6A9:
        if ($cRLb2) {
            goto WYSuk;
        }
        goto XDE85;
        nMP9s:
        $pQGW1 = $this->IfECA->call($this, $NzFkF);
        goto tc4Fy;
        I_6F2:
        return;
        goto wlm6v;
        MAM63:
        if (!$cRLb2->update(['driver' => Rc6MZhMMdyG6A::S3, 'status' => EUkqoDwU9Zcvh::FINISHED])) {
            goto yihBv;
        }
        goto Zp1wV;
        yzV9O:
        if (!($cRLb2->getAttribute('preview') && $this->uBhrQ->exists($cRLb2->getAttribute('preview')))) {
            goto kYwj0;
        }
        goto V55it;
        Q9Wu2:
        $z69yI = $this->uBhrQ->path($cRLb2->getLocation());
        goto i_4A3;
        duk_1:
    }
}
