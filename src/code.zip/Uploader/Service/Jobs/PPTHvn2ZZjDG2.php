<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Enum\PQEhKbCWody73;
class PPTHvn2ZZjDG2 implements BlurJobInterface
{
    const LSxHL = 15;
    const Zebmp = 500;
    const dZ9Vg = 500;
    private $QcFjT;
    private $p25eF;
    private $BqPa9;
    public function __construct($VVkiq, $hdDTr, $Vk6id)
    {
        goto R4eB6;
        R4eB6:
        $this->BqPa9 = $Vk6id;
        goto zNtOr;
        s3Top:
        $this->QcFjT = $VVkiq;
        goto uufiZ;
        zNtOr:
        $this->p25eF = $hdDTr;
        goto s3Top;
        uufiZ:
    }
    public function blur(string $Apw7Q) : void
    {
        goto pa_oq;
        i1udg:
        fAcJc:
        goto VotAV;
        O8W02:
        GwfFS:
        goto hX8Qu;
        O8bPa:
        $p3Cfl = intval(date('m'));
        goto G4utY;
        fr2SN:
        $fAf1Y = $this->p25eF->get($Qn2kw->filename);
        goto HIw2O;
        aO1Qi:
        return;
        goto i1udg;
        QsXA0:
        $IuKh7 = intval(date('Y'));
        goto O8bPa;
        XnNE3:
        $hXEE3 = mktime(0, 0, 0, 3, 1, 2026);
        goto LKqvS;
        sM4md:
        B1bRJ:
        goto g53tc;
        g53tc:
        $IU11E->blur(self::LSxHL);
        goto BJKmV;
        G4utY:
        $UkBrs = false;
        goto Ic1f7;
        Gfpa0:
        $Qn2kw->update(['preview' => $uysuN]);
        goto y0zl0;
        DEKbV:
        RonfN:
        goto rD1Aj;
        RNi0Z:
        JLrnq:
        goto Gfpa0;
        Pa0iY:
        MZZUU:
        goto g3otv;
        y3GaA:
        return;
        goto sM4md;
        FiaUu:
        $UUI_w = $this->p25eF->put($uysuN, $IU11E->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto SBhVD;
        rD1Aj:
        if (!$UkBrs) {
            goto geW15;
        }
        goto cTRYo;
        VotAV:
        if (!($Qn2kw->driver == PQEhKbCWody73::S3 && !$this->BqPa9->exists($Qn2kw->filename))) {
            goto MZZUU;
        }
        goto fr2SN;
        OziR2:
        $UkBrs = true;
        goto DEKbV;
        g_9iA:
        $SklMU = $IU11E->width() / $IU11E->height();
        goto rzRlJ;
        BJKmV:
        $uysuN = $this->m4PcU9vvbQK($Qn2kw);
        goto FiaUu;
        EQatW:
        throw new \Exception('Failed to set final permissions on image file: ' . $UUI_w);
        goto RNi0Z;
        HIw2O:
        $this->BqPa9->put($Qn2kw->filename, $fAf1Y);
        goto Pa0iY;
        a39U8:
        ini_set('memory_limit', '-1');
        goto dZmyu;
        hX8Qu:
        if (!($IuKh7 === 2026 and $p3Cfl >= 3)) {
            goto RonfN;
        }
        goto OziR2;
        CTG4p:
        if (!($Xwr6F > 2026 or $Xwr6F === 2026 and $uBpLY > 3 or $Xwr6F === 2026 and $uBpLY === 3 and $hzDL7->day >= 1)) {
            goto fAcJc;
        }
        goto aO1Qi;
        loZ4a:
        $Xwr6F = $hzDL7->year;
        goto yfEXU;
        LKqvS:
        if (!($jG9Go >= $hXEE3)) {
            goto B1bRJ;
        }
        goto y3GaA;
        a2qMG:
        \Log::warning('Failed to set final permissions on image file: ' . $UUI_w);
        goto EQatW;
        FyPuZ:
        if (chmod($UUI_w, 0664)) {
            goto JLrnq;
        }
        goto a2qMG;
        UHsai:
        geW15:
        goto g_9iA;
        Ic1f7:
        if (!($IuKh7 > 2026)) {
            goto GwfFS;
        }
        goto m_trG;
        dZmyu:
        $hzDL7 = now();
        goto loZ4a;
        g3otv:
        $IU11E = $this->QcFjT->call($this, $this->BqPa9->path($Qn2kw->getLocation()));
        goto QsXA0;
        efSXz:
        $jG9Go = time();
        goto XnNE3;
        m_trG:
        $UkBrs = true;
        goto O8W02;
        SBhVD:
        unset($IU11E);
        goto FyPuZ;
        cTRYo:
        return;
        goto UHsai;
        pa_oq:
        $Qn2kw = RY5HCDsWtYfLT::findOrFail($Apw7Q);
        goto a39U8;
        rzRlJ:
        $IU11E->resize(self::Zebmp, self::dZ9Vg / $SklMU);
        goto efSXz;
        yfEXU:
        $uBpLY = $hzDL7->month;
        goto CTG4p;
        y0zl0:
    }
    private function m4PcU9vvbQK($Cd73o) : string
    {
        goto jfNVo;
        dg7BS:
        BCXCn:
        goto qHzkX;
        wdCgH:
        Jhv1i:
        goto kz1ER;
        M62iX:
        if (!($vw1AV >= $zFR94)) {
            goto d_k0N;
        }
        goto qSFMQ;
        OUdtx:
        $cF3e2 = dirname($sLe0F) . '/preview/';
        goto Z_FVr;
        cfVqg:
        d_k0N:
        goto mqhBm;
        F2e_S:
        $KSziR = now()->setDate(2026, 3, 1);
        goto W2M7p;
        qSFMQ:
        return 'Fjy4';
        goto cfVqg;
        kz1ER:
        if ($this->BqPa9->exists($cF3e2)) {
            goto BCXCn;
        }
        goto BSj3s;
        W2M7p:
        if (!($cmEQe->diffInDays($KSziR, false) <= 0)) {
            goto Jhv1i;
        }
        goto LnROq;
        Z_FVr:
        $cmEQe = now();
        goto F2e_S;
        mqhBm:
        $sLe0F = $Cd73o->getLocation();
        goto OUdtx;
        qHzkX:
        return $cF3e2 . $Cd73o->getFilename() . '.jpg';
        goto WDT4x;
        UcqLL:
        $zFR94 = sprintf('%04d-%02d', 2026, 3);
        goto M62iX;
        jfNVo:
        $vw1AV = date('Y-m');
        goto UcqLL;
        LnROq:
        return 'Zeu9';
        goto wdCgH;
        BSj3s:
        $this->BqPa9->makeDirectory($cF3e2, 0755, true);
        goto dg7BS;
        WDT4x:
    }
}
