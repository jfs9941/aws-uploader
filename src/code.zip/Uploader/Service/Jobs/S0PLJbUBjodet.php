<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class S0PLJbUBjodet implements CompressJobInterface
{
    const ayJ06 = 60;
    private $xy0Yf;
    private $mzObC;
    private $eUSBH;
    public function __construct($ppK7O, $L1VX0, $rDA3i)
    {
        goto ezHum;
        cX1A1:
        $this->mzObC = $L1VX0;
        goto IkuQI;
        Xrr3p:
        $this->eUSBH = $rDA3i;
        goto cX1A1;
        ezHum:
        $this->xy0Yf = $ppK7O;
        goto Xrr3p;
        IkuQI:
    }
    public function compress(string $J_scC)
    {
        goto eZlMm;
        eZlMm:
        $gAXA1 = microtime(true);
        goto YK9w0;
        YK9w0:
        $bp0pf = memory_get_usage();
        goto PN4jV;
        PN4jV:
        $c_Bev = memory_get_peak_usage();
        goto zrJl7;
        uvHM5:
        try {
            goto CN8KS;
            g3KYQ:
            $VWXEV = $this->mkP8yNi0IoT($VWXEV, 'jpg');
            goto GUhjp;
            Uya1N:
            try {
                goto jJ1QQ;
                twikt:
                $this->mkP8yNi0IoT($VWXEV, 'webp');
                goto sBQt0;
                jJ1QQ:
                $oKQxu = $this->mzObC->path(str_replace('.jpg', '.webp', $VWXEV->getLocation()));
                goto CvMO6;
                CvMO6:
                $this->mA6xFAXVZj9($dQ_sG, $oKQxu);
                goto twikt;
                sBQt0:
            } catch (\Exception $XViIf) {
                goto l4qZw;
                l4qZw:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $J_scC, 'error' => $XViIf->getMessage()]);
                goto uoaY1;
                mQau3:
                $this->mJ5BM5hTt19($dQ_sG, $oKQxu);
                goto JM56x;
                uoaY1:
                $oKQxu = $this->mzObC->path($VWXEV->getLocation());
                goto mQau3;
                JM56x:
            }
            goto Z9AAr;
            GUhjp:
            hxyPi:
            goto Uya1N;
            CN8KS:
            $VWXEV = XK5kReLMTU1ob::findOrFail($J_scC);
            goto T6HE2;
            b6rHt:
            if (!(strtolower($VWXEV->getExtension()) === 'png' || strtolower($VWXEV->getExtension()) === 'heic')) {
                goto hxyPi;
            }
            goto g3KYQ;
            T6HE2:
            $dQ_sG = $this->mzObC->path($VWXEV->getLocation());
            goto b6rHt;
            Z9AAr:
        } catch (\Throwable $XViIf) {
            goto AQL6g;
            Ov42u:
            return;
            goto oMox6;
            oMox6:
            Kal2V:
            goto fv2nH;
            fv2nH:
            Log::error("Failed to compress image", ['imageId' => $J_scC, 'error' => $XViIf->getMessage()]);
            goto BAkjD;
            gzqP2:
            Log::info("XK5kReLMTU1ob has been deleted, discard it", ['imageId' => $J_scC]);
            goto Ov42u;
            AQL6g:
            if (!$XViIf instanceof ModelNotFoundException) {
                goto Kal2V;
            }
            goto gzqP2;
            BAkjD:
        } finally {
            $m9Rrr = microtime(true);
            $mHCRu = memory_get_usage();
            $kZ1f0 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $J_scC, 'execution_time_sec' => $m9Rrr - $gAXA1, 'memory_usage_mb' => ($mHCRu - $bp0pf) / 1024 / 1024, 'peak_memory_usage_mb' => ($kZ1f0 - $c_Bev) / 1024 / 1024]);
        }
        goto JwcG2;
        zrJl7:
        Log::info("Compress image", ['imageId' => $J_scC]);
        goto uvHM5;
        JwcG2:
    }
    private function mJ5BM5hTt19($dQ_sG, $oKQxu)
    {
        goto kBLG3;
        KSjF_:
        $this->eUSBH->put($oKQxu, $MWP2E->toJpeg(self::ayJ06), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto KymB0;
        kBLG3:
        $MWP2E = $this->xy0Yf->call($this, $dQ_sG);
        goto JyD0W;
        JyD0W:
        $MWP2E->orient()->toJpeg(self::ayJ06)->save($oKQxu);
        goto KSjF_;
        KymB0:
        unset($MWP2E);
        goto UUoVb;
        UUoVb:
    }
    private function mA6xFAXVZj9($dQ_sG, $oKQxu)
    {
        goto rHsa2;
        rHsa2:
        $MWP2E = $this->xy0Yf->call($this, $dQ_sG);
        goto rqP_r;
        rqP_r:
        $MWP2E->orient()->toWebp(self::ayJ06);
        goto m7H1P;
        m7H1P:
        $this->eUSBH->put($oKQxu, $MWP2E->toJpeg(self::ayJ06), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto AMD_O;
        AMD_O:
        unset($MWP2E);
        goto bbkF6;
        bbkF6:
    }
    private function mkP8yNi0IoT($VWXEV, $fdWOz)
    {
        goto HSmY3;
        HSmY3:
        $VWXEV->setAttribute('type', $fdWOz);
        goto CmS5u;
        CmS5u:
        $VWXEV->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$fdWOz}", $VWXEV->getLocation()));
        goto iTr63;
        zsy3s:
        return $VWXEV;
        goto Wy0lI;
        iTr63:
        $VWXEV->save();
        goto zsy3s;
        Wy0lI:
    }
}
