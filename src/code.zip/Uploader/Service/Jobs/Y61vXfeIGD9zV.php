<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Illuminate\Support\Facades\Log;
class Y61vXfeIGD9zV implements DownloadToLocalJobInterface
{
    private $gErml;
    private $mzObC;
    public function __construct($DFpIk, $L1VX0)
    {
        $this->gErml = $DFpIk;
        $this->mzObC = $L1VX0;
    }
    public function download(string $J_scC) : void
    {
        goto F5EEu;
        R8fSp:
        $this->mzObC->put($dV9QE->getLocation(), $this->gErml->get($dV9QE->getLocation()));
        goto s06TJ;
        AgGas:
        Log::info("Start download file to local", ['fileId' => $J_scC, 'filename' => $dV9QE->getLocation()]);
        goto sczUe;
        E83L3:
        return;
        goto WzSbM;
        WzSbM:
        BWEuz:
        goto R8fSp;
        sczUe:
        if (!$this->mzObC->exists($dV9QE->getLocation())) {
            goto BWEuz;
        }
        goto E83L3;
        F5EEu:
        $dV9QE = XK5kReLMTU1ob::findOrFail($J_scC);
        goto AgGas;
        s06TJ:
    }
}
