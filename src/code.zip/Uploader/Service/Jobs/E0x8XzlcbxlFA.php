<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Service\Jobs\Ka9F6ltS3EsKS;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class E0x8XzlcbxlFA implements WatermarkTextJobInterface
{
    private $VnheV;
    private $PvWfL;
    private $iKvr0;
    private $SxfKN;
    private $qqmnq;
    public function __construct($wUcGa, $Aeh19, $DPWG1, $vS8UC, $OEUO8)
    {
        goto UUtea;
        UUtea:
        $this->VnheV = $wUcGa;
        goto TMH_e;
        TF7KO:
        $this->qqmnq = $vS8UC;
        goto PevL6;
        PevL6:
        $this->iKvr0 = $OEUO8;
        goto HlHIq;
        TMH_e:
        $this->SxfKN = $DPWG1;
        goto TF7KO;
        HlHIq:
        $this->PvWfL = $Aeh19;
        goto FZk3M;
        FZk3M:
    }
    public function putWatermark(string $GMwD5, string $g2Hrl) : void
    {
        goto DyxW9;
        LRuR5:
        try {
            goto EvpPq;
            CF9Bl:
            $this->muuWnUiYz3q($VbqkY, $g2Hrl);
            goto bdJ81;
            Ol0uF:
            LScQv:
            goto TdFnQ;
            hzDyU:
            $VbqkY->orient();
            goto CF9Bl;
            Ad7q3:
            \Log::warning('Failed to set final permissions on image file: ' . $iTIh6);
            goto R5MHw;
            tEDQE:
            Log::error("C6ftQJKUZRJIp is not on local, might be deleted before put watermark", ['imageId' => $GMwD5]);
            goto ewDoD;
            I0tNH:
            unset($VbqkY);
            goto YQtUc;
            R5MHw:
            throw new \Exception('Failed to set final permissions on image file: ' . $iTIh6);
            goto SGkAF;
            bdJ81:
            $this->SxfKN->put($iTIh6, $VbqkY->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto I0tNH;
            TdFnQ:
            $iTIh6 = $this->qqmnq->path($dmeuh->getLocation());
            goto Wa082;
            ewDoD:
            return;
            goto Ol0uF;
            YQtUc:
            if (chmod($iTIh6, 0664)) {
                goto a8PUQ;
            }
            goto Ad7q3;
            J8Dsj:
            if ($this->qqmnq->exists($dmeuh->getLocation())) {
                goto LScQv;
            }
            goto tEDQE;
            EvpPq:
            $dmeuh = C6ftQJKUZRJIp::findOrFail($GMwD5);
            goto J8Dsj;
            Wa082:
            $VbqkY = $this->VnheV->call($this, $iTIh6);
            goto hzDyU;
            SGkAF:
            a8PUQ:
            goto BMuxU;
            BMuxU:
        } catch (\Throwable $zP3xK) {
            goto TRg64;
            TRg64:
            if (!$zP3xK instanceof ModelNotFoundException) {
                goto DIWhB;
            }
            goto yYr8B;
            VQogd:
            return;
            goto WSLbD;
            WSLbD:
            DIWhB:
            goto gHKYt;
            yYr8B:
            Log::info("C6ftQJKUZRJIp has been deleted, discard it", ['imageId' => $GMwD5]);
            goto VQogd;
            gHKYt:
            Log::error("C6ftQJKUZRJIp is not readable", ['imageId' => $GMwD5, 'error' => $zP3xK->getMessage()]);
            goto rIeDo;
            rIeDo:
        } finally {
            $UWIzp = microtime(true);
            $nzC5Y = memory_get_usage();
            $gEpcX = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $GMwD5, 'execution_time_sec' => $UWIzp - $EztI0, 'memory_usage_mb' => ($nzC5Y - $u_Mwa) / 1024 / 1024, 'peak_memory_usage_mb' => ($gEpcX - $ZV4fL) / 1024 / 1024]);
        }
        goto onK6o;
        DyxW9:
        $EztI0 = microtime(true);
        goto K2vsT;
        zD9c3:
        ini_set('memory_limit', '-1');
        goto LRuR5;
        K2vsT:
        $u_Mwa = memory_get_usage();
        goto cbfod;
        woPy0:
        Log::info("Adding watermark text to image", ['imageId' => $GMwD5]);
        goto zD9c3;
        cbfod:
        $ZV4fL = memory_get_peak_usage();
        goto woPy0;
        onK6o:
    }
    private function muuWnUiYz3q($VbqkY, $g2Hrl) : void
    {
        goto FW8ka;
        mxpaD:
        $VbqkY->place($Uj7rj, 'top-left', 0, 0, 30);
        goto s4HNd;
        UlmJO:
        $this->qqmnq->put($lk0YF, $this->SxfKN->get($lk0YF));
        goto Lyr18;
        d73Gd:
        $oEi9I = new Ka9F6ltS3EsKS($this->PvWfL, $this->iKvr0, $this->SxfKN, $this->qqmnq);
        goto m4LLc;
        FW8ka:
        $BmTCT = $VbqkY->width();
        goto Ys4LV;
        m4LLc:
        $lk0YF = $oEi9I->mZ54QsRZLR3($BmTCT, $IkBoO, $g2Hrl, true);
        goto UlmJO;
        Ys4LV:
        $IkBoO = $VbqkY->height();
        goto d73Gd;
        Lyr18:
        $Uj7rj = $this->VnheV->call($this, $this->qqmnq->path($lk0YF));
        goto mxpaD;
        s4HNd:
    }
}
