<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Um6s5iLRGphZr implements CompressJobInterface
{
    const ruIjy = 60;
    private $Q1wpU;
    private $JFHzD;
    private $B0BKT;
    public function __construct($kuI8f, $NVuHg, $X3WMV)
    {
        goto QeKbN;
        QeKbN:
        $this->Q1wpU = $kuI8f;
        goto s3_56;
        s3_56:
        $this->B0BKT = $X3WMV;
        goto MdJvQ;
        MdJvQ:
        $this->JFHzD = $NVuHg;
        goto e_Gxn;
        e_Gxn:
    }
    public function compress(string $EmnXX)
    {
        goto R2U_F;
        R2U_F:
        $CH3jk = microtime(true);
        goto riFlz;
        Rmi5F:
        $DGIY2 = memory_get_peak_usage();
        goto PIF58;
        riFlz:
        $sebDh = memory_get_usage();
        goto Rmi5F;
        zu_1e:
        try {
            goto Czw0e;
            Czw0e:
            $AvW7Y = Q48IcpSr3UpAT::findOrFail($EmnXX);
            goto uuPKz;
            w_r7t:
            try {
                goto wMJjN;
                jv38f:
                $this->m1isSeRin5v($wNRHz, $bERSk);
                goto Degsv;
                wMJjN:
                $bERSk = str_replace(['.jpg', '.png', '.heic'], '.webp', $AvW7Y->getLocation());
                goto jv38f;
                Degsv:
                $this->mpxbTvjONi0($AvW7Y, 'webp');
                goto V_ecg;
                V_ecg:
            } catch (\Exception $SoaRh) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $EmnXX, 'error' => $SoaRh->getMessage()]);
                try {
                    goto T13_6;
                    iZO5M:
                    $this->muE0S5LtD85($wNRHz, $bERSk);
                    goto xFwPX;
                    xFwPX:
                    $this->mpxbTvjONi0($AvW7Y, 'jpg');
                    goto qiSbj;
                    T13_6:
                    $bERSk = str_replace(['.jpg', '.png', '.heic'], '.jpg', $AvW7Y->getLocation());
                    goto iZO5M;
                    qiSbj:
                } catch (\Exception $SoaRh) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $EmnXX, 'error' => $SoaRh->getMessage()]);
                }
            }
            goto aI0ft;
            uuPKz:
            $wNRHz = $this->JFHzD->path($AvW7Y->getLocation());
            goto w_r7t;
            aI0ft:
        } catch (\Throwable $SoaRh) {
            goto WVhYs;
            CQwsl:
            Log::error("Failed to compress image", ['imageId' => $EmnXX, 'error' => $SoaRh->getMessage()]);
            goto dPeL3;
            Zpt1F:
            Log::info("Q48IcpSr3UpAT has been deleted, discard it", ['imageId' => $EmnXX]);
            goto VGYVi;
            VGYVi:
            return;
            goto Kj09C;
            WVhYs:
            if (!$SoaRh instanceof ModelNotFoundException) {
                goto FqUlB;
            }
            goto Zpt1F;
            Kj09C:
            FqUlB:
            goto CQwsl;
            dPeL3:
        } finally {
            $ukbV6 = microtime(true);
            $A4_rm = memory_get_usage();
            $PEAvN = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $EmnXX, 'execution_time_sec' => $ukbV6 - $CH3jk, 'memory_usage_mb' => ($A4_rm - $sebDh) / 1024 / 1024, 'peak_memory_usage_mb' => ($PEAvN - $DGIY2) / 1024 / 1024]);
        }
        goto fLfR7;
        PIF58:
        Log::info("Compress image", ['imageId' => $EmnXX]);
        goto zu_1e;
        fLfR7:
    }
    private function muE0S5LtD85($wNRHz, $bERSk)
    {
        goto TNaB3;
        dbM8A:
        $pec9t->orient()->toJpeg(self::ruIjy)->save($bERSk);
        goto eE4cD;
        eE4cD:
        $this->B0BKT->put($bERSk, $pec9t->toJpeg(self::ruIjy), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Dd9IG;
        TNaB3:
        $pec9t = $this->Q1wpU->call($this, $wNRHz);
        goto dbM8A;
        Dd9IG:
        unset($pec9t);
        goto JVPz7;
        JVPz7:
    }
    private function m1isSeRin5v($wNRHz, $bERSk)
    {
        goto vf8iZ;
        yQ8Z4:
        $this->B0BKT->put($bERSk, $pec9t->toWebp(self::ruIjy), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto MotYZ;
        vf8iZ:
        $pec9t = $this->Q1wpU->call($this, $wNRHz);
        goto Djv42;
        Djv42:
        $pec9t->orient()->toWebp(self::ruIjy);
        goto yQ8Z4;
        MotYZ:
        unset($pec9t);
        goto Wjcag;
        Wjcag:
    }
    private function mpxbTvjONi0($AvW7Y, $VYTXo)
    {
        goto R_F1M;
        Ktlip:
        $AvW7Y->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$VYTXo}", $AvW7Y->getLocation()));
        goto sGaNp;
        PRPEk:
        return $AvW7Y;
        goto VCDpV;
        R_F1M:
        $AvW7Y->setAttribute('type', $VYTXo);
        goto Ktlip;
        sGaNp:
        $AvW7Y->save();
        goto PRPEk;
        VCDpV:
    }
}
