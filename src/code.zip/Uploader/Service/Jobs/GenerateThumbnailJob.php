<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Enum\FileStatus;

class GenerateThumbnailJob implements GenerateThumbnailJobInterface
{
    const FIX_WIDTH = 150;
    const FIX_HEIGHT = 150;
    /** @var \Closure */
    private $maker;
    private $localDisk;
    public function __construct($maker, $localDisk)
    {
        $this->maker = $maker;
        $this->localDisk = $localDisk;
    }
    public function generate(string $id)
    {
        Log::info("Generating thumbnail", ['imageId' => $id]);
        ini_set('memory_limit', '-1');
        try {
            $localStorage = $this->localDisk;
            $image = Image::findOrFail($id);

            $img = $this->maker->call($this, $localStorage->path($image->getLocation()));
            $img->fit(150, 150, function ($constraint) {
                $constraint->aspectRatio();
            });
            $img->encode('jpg', 80);
            $path = $this->createPath($image);
            $stored = $localStorage->put(
                $path,
                $img->stream(),
                ['visibility' => 'public']
            );
            $img->destroy();
            if ($stored !== false) {
                $image->update(['thumbnail' => $path, 'status' => FileStatus::THUMBNAIL_PROCESSED]);

                $storedFilePath = $localStorage->path($path);
                if (!chmod($storedFilePath, 0644)) {
                    Log::warning('Failed to set file permissions for stored image: ' . $storedFilePath);
                    throw new \Exception('Failed to set file permissions for stored image: ' . $storedFilePath);
                }
            }
        } catch (ModelNotFoundException  $e) {
            Log::info("Image has been deleted, discard it", ['imageId' => $id]);
            return;
        }
    }



    private function createPath(BaseFileModel $image): string
    {
        $path = $image->getLocation();
        $folder = dirname($path);
        $thumbnailDir = $folder . '/' . self::FIX_WIDTH . 'X' . self::FIX_HEIGHT;

        return $thumbnailDir . '/' . $image->getFilename() . '.jpg';
    }
}
