<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
class FPeakagokBcbc implements BlurVideoJobInterface
{
    const EqRUT = 15;
    const g9ySt = 500;
    const o6MO3 = 500;
    private $K9RVo;
    private $qrvF0;
    private $ERIyl;
    public function __construct($Venjl, $eG_Pc, $nL6dR)
    {
        goto uc3f3;
        OUwuX:
        $this->K9RVo = $Venjl;
        goto n_9Rk;
        uc3f3:
        $this->ERIyl = $nL6dR;
        goto WmMCo;
        WmMCo:
        $this->qrvF0 = $eG_Pc;
        goto OUwuX;
        n_9Rk:
    }
    public function blur(string $ElvKF) : void
    {
        goto lMwAv;
        Wv3fz:
        throw new \Exception('Failed to set final permissions on image file: ' . $qUAdC);
        goto koBgQ;
        lMwAv:
        Log::info("Blurring for video", ['videoID' => $ElvKF]);
        goto WTUZa;
        bFnWT:
        if (!$yQtIj->getAttribute('thumbnail')) {
            goto oWndl;
        }
        goto yN9_x;
        WTUZa:
        ini_set('memory_limit', '-1');
        goto CBRjJ;
        l1vri:
        $Q60Mb = $this->mvnXtFBjtmf($yQtIj);
        goto EkKuH;
        CBRjJ:
        $yQtIj = UMeQT1ArE1U05::findOrFail($ElvKF);
        goto bFnWT;
        Z2hFD:
        oWndl:
        goto k00Kg;
        yN9_x:
        $this->ERIyl->put($yQtIj->getAttribute('thumbnail'), $this->qrvF0->get($yQtIj->getAttribute('thumbnail')));
        goto NLSHQ;
        QCSqV:
        $anrPh->destroy();
        goto iFzO_;
        JxjW4:
        $anrPh->save($qUAdC);
        goto YEUQh;
        koBgQ:
        MQjzO:
        goto mVgHd;
        P47Hp:
        \Log::warning('Failed to set final permissions on image file: ' . $qUAdC);
        goto Wv3fz;
        EkKuH:
        $qUAdC = $this->ERIyl->path($Q60Mb);
        goto JxjW4;
        AMW7R:
        $anrPh->blur(self::EqRUT);
        goto l1vri;
        Pt1kv:
        $WTiec = $anrPh->width() / $anrPh->height();
        goto ETzev;
        iFzO_:
        if (chmod($qUAdC, 0664)) {
            goto MQjzO;
        }
        goto P47Hp;
        ETzev:
        $anrPh->resize(self::g9ySt, self::o6MO3 / $WTiec);
        goto AMW7R;
        mVgHd:
        $yQtIj->update(['preview' => $Q60Mb]);
        goto Z2hFD;
        NLSHQ:
        $anrPh = $this->K9RVo->call($this, $this->ERIyl->path($yQtIj->getAttribute('thumbnail')));
        goto Pt1kv;
        YEUQh:
        $this->qrvF0->put($Q60Mb, $this->ERIyl->get($Q60Mb));
        goto QCSqV;
        k00Kg:
    }
    private function mvnXtFBjtmf(UkjvJ3zCZNh6F $jAFG4) : string
    {
        goto mLcT0;
        IKLeU:
        z3wwZ:
        goto w7S2Q;
        mLcT0:
        $lmCO9 = $jAFG4->getLocation();
        goto uG6Br;
        HCSkG:
        if ($this->ERIyl->exists($rccNk)) {
            goto z3wwZ;
        }
        goto EoTz3;
        w7S2Q:
        return $rccNk . $jAFG4->getFilename() . '.jpg';
        goto aBrVN;
        EoTz3:
        $this->ERIyl->makeDirectory($rccNk, 0755, true);
        goto IKLeU;
        uG6Br:
        $rccNk = dirname($lmCO9) . '/preview/';
        goto HCSkG;
        aBrVN:
    }
}
