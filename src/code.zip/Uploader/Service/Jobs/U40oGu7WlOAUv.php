<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class U40oGu7WlOAUv implements GenerateThumbnailForVideoInterface
{
    private $N5okI;
    public function __construct($npX1n)
    {
        $this->N5okI = $npX1n;
    }
    public function generate(string $DWjir) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $DWjir);
        $this->N5okI->createThumbnail($DWjir);
    }
}
