<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Illuminate\Support\Facades\Log;
class CibXqX7IkWYya implements StoreVideoToS3JobInterface
{
    private $TqkWa;
    private $D9Jo8;
    private $s3l3u;
    public function __construct($EwO1g, $v1Edp, $lKCQu)
    {
        goto wctw0;
        OSXTZ:
        $this->s3l3u = $lKCQu;
        goto Hw83o;
        wctw0:
        $this->D9Jo8 = $v1Edp;
        goto OSXTZ;
        Hw83o:
        $this->TqkWa = $EwO1g;
        goto c9Rff;
        c9Rff:
    }
    public function store(string $poSkG) : void
    {
        goto gvWPO;
        XIq4V:
        $PY97I = memory_get_usage();
        goto AScgB;
        gvWPO:
        Log::info('Storing video (local) to S3', ['fileId' => $poSkG, 'bucketName' => $this->TqkWa]);
        goto GfXZX;
        Qmmu5:
        return;
        goto X51rO;
        dvP3S:
        if ($lKCQu->exists($uWrfM->getLocation())) {
            goto GqO3l;
        }
        goto lFtmg;
        lFtmg:
        Log::error("[CibXqX7IkWYya] File not found, discard it ", ['video' => $uWrfM->getLocation()]);
        goto kHBTl;
        AScgB:
        $SH_2o = memory_get_peak_usage();
        goto uFwxU;
        Zt2cl:
        $cse1Q = 1024 * 1024 * 50;
        goto w3sXz;
        kHBTl:
        return;
        goto omJwW;
        CCO0X:
        $EnuQ0 = microtime(true);
        goto XIq4V;
        GfXZX:
        ini_set('memory_limit', '-1');
        goto VM80c;
        xPNuF:
        $wZqKE = $lKCQu->readStream($uWrfM->getLocation());
        goto Zt2cl;
        uoGFE:
        if ($uWrfM) {
            goto KbL0M;
        }
        goto ooB_p;
        VM80c:
        $EYytr = $this->D9Jo8->getClient();
        goto bQ4xc;
        X51rO:
        KbL0M:
        goto dvP3S;
        W8B9W:
        $uWrfM = ISYJHQo8eqdfc::find($poSkG);
        goto uoGFE;
        omJwW:
        GqO3l:
        goto xPNuF;
        ooB_p:
        Log::info("ISYJHQo8eqdfc has been deleted in database or not inserted yet, discard it", ['fileId' => $poSkG]);
        goto Qmmu5;
        bQ4xc:
        $lKCQu = $this->s3l3u;
        goto W8B9W;
        w3sXz:
        $UhTpD = $lKCQu->mimeType($uWrfM->getLocation());
        goto CCO0X;
        uFwxU:
        try {
            goto ir6nv;
            N6IMi:
            $b4Ykz = $EYytr->uploadPart(['Bucket' => $this->TqkWa, 'Key' => $uWrfM->getLocation(), 'UploadId' => $fa_xj, 'PartNumber' => $e8jaP, 'Body' => fread($wZqKE, $cse1Q)]);
            goto Q3KdU;
            Q3KdU:
            $Y_W7Y[] = ['PartNumber' => $e8jaP, 'ETag' => $b4Ykz['ETag']];
            goto CSFai;
            k88WF:
            $fa_xj = $uyT2h['UploadId'];
            goto otob0;
            BqZ5Y:
            $uWrfM->update(['driver' => L2PWLPeQEFi6U::S3, 'status' => IOOvAXAyKHLW2::FINISHED]);
            goto s_Noz;
            CSFai:
            $e8jaP++;
            goto GiOax;
            N3VH6:
            fclose($wZqKE);
            goto MAO2M;
            s_Noz:
            $lKCQu->delete($uWrfM->getLocation());
            goto b2LgP;
            otob0:
            $e8jaP = 1;
            goto Vz_42;
            k3ijD:
            if (feof($wZqKE)) {
                goto PhzJA;
            }
            goto N6IMi;
            ir6nv:
            $uyT2h = $EYytr->createMultipartUpload(['Bucket' => $this->TqkWa, 'Key' => $uWrfM->getLocation(), 'ContentType' => $UhTpD, 'ContentDisposition' => 'inline']);
            goto k88WF;
            MAO2M:
            $EYytr->completeMultipartUpload(['Bucket' => $this->TqkWa, 'Key' => $uWrfM->getLocation(), 'UploadId' => $fa_xj, 'MultipartUpload' => ['Parts' => $Y_W7Y]]);
            goto BqZ5Y;
            Nxb7P:
            QarDc:
            goto k3ijD;
            Vz_42:
            $Y_W7Y = [];
            goto Nxb7P;
            GiOax:
            goto QarDc;
            goto NFvVX;
            NFvVX:
            PhzJA:
            goto N3VH6;
            b2LgP:
        } catch (AwsException $RUf1Z) {
            goto WNIhh;
            WNIhh:
            if (!isset($fa_xj)) {
                goto xjdKI;
            }
            goto knTi3;
            knTi3:
            try {
                $EYytr->abortMultipartUpload(['Bucket' => $this->TqkWa, 'Key' => $uWrfM->getLocation(), 'UploadId' => $fa_xj]);
            } catch (AwsException $rAvKI) {
                Log::error('Error aborting multipart upload: ' . $rAvKI->getMessage());
            }
            goto vfLiV;
            vfLiV:
            xjdKI:
            goto Qe6Ij;
            Qe6Ij:
            Log::error('Failed to store video: ' . $uWrfM->getLocation() . ' - ' . $RUf1Z->getMessage());
            goto HWxbO;
            HWxbO:
        } finally {
            $BDOA4 = microtime(true);
            $GO2Jv = memory_get_usage();
            $Svmms = memory_get_peak_usage();
            Log::info('Store ISYJHQo8eqdfc to S3 function resource usage', ['imageId' => $poSkG, 'execution_time_sec' => $BDOA4 - $EnuQ0, 'memory_usage_mb' => ($GO2Jv - $PY97I) / 1024 / 1024, 'peak_memory_usage_mb' => ($Svmms - $SH_2o) / 1024 / 1024]);
        }
        goto s0fep;
        s0fep:
    }
}
