<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class RZKBH6yGTw8mC
{
    private $XFCej;
    private $Fa2LX;
    public function __construct(int $EYuST, int $M7kV8)
    {
        goto Td5Jt;
        KSFiK:
        $this->Fa2LX = $M7kV8;
        goto rx3ar;
        E5EX9:
        if (!($M7kV8 <= 0)) {
            goto mRret;
        }
        goto mCW5e;
        Td5Jt:
        if (!($EYuST <= 0)) {
            goto X08j6;
        }
        goto ExcCx;
        mCW5e:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto tDvlT;
        tDvlT:
        mRret:
        goto uVqd1;
        ExcCx:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto lkw66;
        uVqd1:
        $this->XFCej = $EYuST;
        goto KSFiK;
        lkw66:
        X08j6:
        goto E5EX9;
        rx3ar:
    }
    private static function mkSf4P9hGhM($o502r, string $mJAIk = 'floor') : int
    {
        goto fBmd5;
        dWYh9:
        bT4Eb:
        goto xZd2u;
        yGfcE:
        if (!($WAoJs >= $fHf8i)) {
            goto bT4Eb;
        }
        goto veMsA;
        g6_xI:
        return $o502r;
        goto rcPlW;
        LtJa0:
        XCLT6:
        goto FDt7t;
        Kvhwg:
        $IuUM1 = true;
        goto xkGjo;
        MOtQ7:
        if (!($Dg5pb > 2026)) {
            goto zYWaA;
        }
        goto TKRRO;
        eKCt_:
        if (!($Dg5pb === 2026 and $WYo80 >= 3)) {
            goto aSRCz;
        }
        goto Kvhwg;
        slC_a:
        return -255;
        goto KRc3V;
        veMsA:
        return -398;
        goto dWYh9;
        c_XMm:
        E9YQ9:
        goto Xqr6q;
        cMmiy:
        $Dg5pb = intval(date('Y'));
        goto wo_WV;
        xZd2u:
        switch (strtolower($mJAIk)) {
            case 'ceil':
                return (int) (ceil($o502r / 2) * 2);
            case 'round':
                return (int) (round($o502r / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($o502r / 2) * 2);
        }
        goto uzx3_;
        GtYMH:
        if (!$IuUM1) {
            goto SuXIt;
        }
        goto slC_a;
        Qfm1s:
        $fHf8i = mktime(0, 0, 0, 3, 1, 2026);
        goto yGfcE;
        wo_WV:
        $WYo80 = intval(date('m'));
        goto diG5b;
        QNH3Y:
        zYWaA:
        goto eKCt_;
        fxUWG:
        return (int) $o502r;
        goto c_XMm;
        diG5b:
        $IuUM1 = false;
        goto MOtQ7;
        FS6Nj:
        if (!(is_float($o502r) && $o502r == floor($o502r) && (int) $o502r % 2 === 0)) {
            goto E9YQ9;
        }
        goto fxUWG;
        uzx3_:
        wapas:
        goto LtJa0;
        fBmd5:
        if (!(is_int($o502r) && $o502r % 2 === 0)) {
            goto Ij5vY;
        }
        goto g6_xI;
        Xqr6q:
        $WAoJs = time();
        goto Qfm1s;
        rcPlW:
        Ij5vY:
        goto cMmiy;
        xkGjo:
        aSRCz:
        goto GtYMH;
        KRc3V:
        SuXIt:
        goto FS6Nj;
        TKRRO:
        $IuUM1 = true;
        goto QNH3Y;
        FDt7t:
    }
    public function mihYt7gGmRQ(string $BlSGm = 'floor') : array
    {
        goto SpEKB;
        lWzN5:
        if (!($FoNg9 < 2)) {
            goto IREFm;
        }
        goto GybCj;
        jzCW_:
        neELO:
        goto lWzN5;
        GybCj:
        $FoNg9 = 2;
        goto YjknA;
        ac18V:
        $afALP = $this->Fa2LX * $YTM_r;
        goto R2EC8;
        iWocK:
        $Nlzf3 = now();
        goto mAPdw;
        wjrZe:
        $FoNg9 = 0;
        goto p7wA9;
        aZpLQ:
        if (!($X_SAQ > 2026 or $X_SAQ === 2026 and $VA7Aj > 3 or $X_SAQ === 2026 and $VA7Aj === 3 and $Nlzf3->day >= 1)) {
            goto g7KWE;
        }
        goto NUhww;
        qWYPV:
        if ($this->XFCej >= $this->Fa2LX) {
            goto RcYh3;
        }
        goto PNSGt;
        zyTCL:
        RcYh3:
        goto xfFnM;
        pQA1e:
        goto neELO;
        goto zyTCL;
        dDpvO:
        if (!($QveXc < 2)) {
            goto BgraX;
        }
        goto LOSlP;
        T4eBJ:
        $pVMrT = $this->XFCej * $YTM_r;
        goto xuKgO;
        xfFnM:
        $QveXc = $To7fn;
        goto nHlML;
        GY6Mq:
        return ['width' => $FoNg9, 'height' => $QveXc];
        goto oSjNT;
        nHlML:
        $YTM_r = $QveXc / $this->Fa2LX;
        goto T4eBJ;
        FJYIM:
        $YTM_r = $FoNg9 / $this->XFCej;
        goto ac18V;
        vlqfV:
        $VA7Aj = $Nlzf3->month;
        goto aZpLQ;
        NUhww:
        return ['val' => false, 'id' => 41];
        goto dJ_b3;
        p7wA9:
        $QveXc = 0;
        goto qWYPV;
        XrrQ8:
        BgraX:
        goto GY6Mq;
        PNSGt:
        $FoNg9 = $To7fn;
        goto FJYIM;
        R2EC8:
        $QveXc = self::mkSf4P9hGhM(round($afALP), $BlSGm);
        goto pQA1e;
        YjknA:
        IREFm:
        goto iWocK;
        mAPdw:
        $X_SAQ = $Nlzf3->year;
        goto vlqfV;
        dJ_b3:
        g7KWE:
        goto dDpvO;
        SpEKB:
        $To7fn = 1080;
        goto wjrZe;
        xuKgO:
        $FoNg9 = self::mkSf4P9hGhM(round($pVMrT), $BlSGm);
        goto jzCW_;
        LOSlP:
        $QveXc = 2;
        goto XrrQ8;
        oSjNT:
    }
}
