<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Illuminate\Support\Facades\Log;
class Mo0etgsaKI3Tx implements DownloadToLocalJobInterface
{
    private $wEVdN;
    private $A8xPF;
    public function __construct($dzspH, $ZT237)
    {
        $this->wEVdN = $dzspH;
        $this->A8xPF = $ZT237;
    }
    public function download(string $hOWbX) : void
    {
        goto SaIPX;
        SaIPX:
        $VslFR = D6FgZi8OHmjic::findOrFail($hOWbX);
        goto tHSgZ;
        XHLE_:
        $this->A8xPF->put($VslFR->getLocation(), $this->wEVdN->get($VslFR->getLocation()));
        goto vpCbh;
        UTvno:
        return;
        goto BoOSZ;
        BoOSZ:
        Z2XQo:
        goto XHLE_;
        tHSgZ:
        Log::info("Start download file to local", ['fileId' => $hOWbX, 'filename' => $VslFR->getLocation()]);
        goto JUnVF;
        JUnVF:
        if (!$this->A8xPF->exists($VslFR->getLocation())) {
            goto Z2XQo;
        }
        goto UTvno;
        vpCbh:
    }
}
