<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class Ka9F6ltS3EsKS
{
    private $PvWfL;
    private $iKvr0;
    private $SxfKN;
    private $qqmnq;
    public function __construct($Aeh19, $TK_MT, $DPWG1, $vS8UC)
    {
        goto yC2VX;
        b_Anf:
        $this->qqmnq = $vS8UC;
        goto C155B;
        KK2uc:
        $this->SxfKN = $DPWG1;
        goto b_Anf;
        yC2VX:
        $this->iKvr0 = $TK_MT;
        goto KK2uc;
        C155B:
        $this->PvWfL = $Aeh19;
        goto tVovh;
        tVovh:
    }
    public function mZ54QsRZLR3(?int $BmTCT, ?int $IkBoO, string $g2Hrl, bool $cm5Fk = false) : string
    {
        goto k9IgP;
        R3LRV:
        $HlJ95 -= $LZqEl * 0.4;
        goto G4m4z;
        A4SpL:
        $this->SxfKN->put($iTIh6, $dmeuh->stream('png'));
        goto izYOS;
        eYnvn:
        throw new \RuntimeException("RhdJGUi8FOLBJ dimensions are not available.");
        goto QtzXH;
        qlGCB:
        return $cm5Fk ? $iTIh6 : $this->SxfKN->url($iTIh6);
        goto JXE2W;
        izYOS:
        return $cm5Fk ? $iTIh6 : $this->SxfKN->url($iTIh6);
        goto NmWhs;
        VkRwW:
        list($ImMeN, $XyrC9, $UraN7) = $this->mqybWvnOmXc($g2Hrl, $BmTCT, $nj_OD, (float) $BmTCT / $IkBoO);
        goto BHsY0;
        JXE2W:
        l4Xo0:
        goto aeThJ;
        hk9VK:
        $HlJ95 -= $LZqEl;
        goto A3Src;
        BHsY0:
        $iTIh6 = $this->mJOZSd8rxx8($UraN7, $BmTCT, $IkBoO, $XyrC9, $ImMeN);
        goto bo7a4;
        cRvks:
        $HlJ95 = $BmTCT - $XyrC9;
        goto id_sl;
        G4m4z:
        Uotj1:
        goto sZ69V;
        k9IgP:
        if (!($BmTCT === null || $IkBoO === null)) {
            goto weqWQ;
        }
        goto eYnvn;
        wo5mp:
        $nj_OD = 0.1;
        goto VkRwW;
        A3Src:
        if (!($BmTCT > 1500)) {
            goto Uotj1;
        }
        goto R3LRV;
        bo7a4:
        if (!$this->SxfKN->exists($iTIh6)) {
            goto l4Xo0;
        }
        goto qlGCB;
        id_sl:
        $LZqEl = (int) ($HlJ95 / 80);
        goto hk9VK;
        aeThJ:
        $dmeuh = $this->PvWfL->call($this, $BmTCT, $IkBoO);
        goto cRvks;
        DN1tr:
        $dmeuh->text($UraN7, $HlJ95, (int) $lhCSV, function ($Nga9N) use($ImMeN) {
            goto anjap;
            JBfe4:
            $Nga9N->color([185, 185, 185, 1]);
            goto PZKNA;
            pFPoH:
            $Nga9N->size(max($ai7W1, 1));
            goto JBfe4;
            DkRzg:
            $ai7W1 = (int) ($ImMeN * 1.2);
            goto pFPoH;
            PZKNA:
            $Nga9N->valign('middle');
            goto jWx20;
            anjap:
            $Nga9N->file(public_path($this->iKvr0));
            goto DkRzg;
            jWx20:
            $Nga9N->align('middle');
            goto TKKDz;
            TKKDz:
        });
        goto r0jgB;
        sZ69V:
        $lhCSV = $IkBoO - $ImMeN - 10;
        goto DN1tr;
        QtzXH:
        weqWQ:
        goto wo5mp;
        r0jgB:
        $this->qqmnq->put($iTIh6, $dmeuh->stream('png'));
        goto A4SpL;
        NmWhs:
    }
    private function mJOZSd8rxx8(string $g2Hrl, int $BmTCT, int $IkBoO, int $MTmuC, int $EQvgT) : string
    {
        $oAoGK = ltrim($g2Hrl, '@');
        return "v2/watermark/{$oAoGK}/{$BmTCT}x{$IkBoO}_{$MTmuC}x{$EQvgT}/text_watermark.png";
    }
    private function mqybWvnOmXc($g2Hrl, int $BmTCT, float $cjImV, float $AXz2I) : array
    {
        goto ny1rH;
        cn1VL:
        return [(int) $ulrp3, $ulrp3 * strlen($UraN7) / 1.8, $UraN7];
        goto ywwgi;
        vw2yq:
        $ulrp3 = 1 / $AXz2I * $XyrC9 / strlen($UraN7);
        goto QM9Ot;
        YOoTt:
        $XyrC9 = (int) ($BmTCT * $cjImV);
        goto M0shl;
        VFJ1p:
        $ulrp3 = $XyrC9 / (strlen($UraN7) * 0.8);
        goto cn1VL;
        QM9Ot:
        return [(int) $ulrp3, $XyrC9, $UraN7];
        goto kfGjN;
        M0shl:
        if (!($AXz2I > 1)) {
            goto D6AwX;
        }
        goto VFJ1p;
        ny1rH:
        $UraN7 = '@' . $g2Hrl;
        goto YOoTt;
        ywwgi:
        D6AwX:
        goto vw2yq;
        kfGjN:
    }
}
