<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class C3usLrLHxww3y implements GenerateThumbnailForVideoInterface
{
    private $NmXul;
    public function __construct($Ve4mN)
    {
        $this->NmXul = $Ve4mN;
    }
    public function generate(string $poSkG) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $poSkG);
        $this->NmXul->createThumbnail($poSkG);
    }
}
