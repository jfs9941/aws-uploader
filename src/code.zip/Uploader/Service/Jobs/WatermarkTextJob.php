<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Image;

class WatermarkTextJob implements WatermarkTextJobInterface
{

    /** @var \Closure */
    private $maker;
    /** @var \Closure */
    private $canvas;
    /**
     * @var string
     */
    private $watermarkFont;
    /**
     * @var Filesystem
     */
    private $s3;
    /**
     * @var Filesystem
     */
    private $localStorage;

    public function __construct($maker, $canvas, $s3, $localStorage, $textPath)
    {
        $this->maker = $maker;
        $this->s3 = $s3;
        $this->localStorage = $localStorage;
        $this->watermarkFont = $textPath;
        $this->canvas = $canvas;
    }
    public function putWatermark(string $id, string $username): void
    {
        Log::info("Adding watermark text to image", ['imageId' => $id]);
        ini_set('memory_limit', '-1');
        try {
            $image = Image::findOrFail($id);
            if (!$this->localStorage->exists($image->getLocation())) {
                Log::error("Image is not on local, might be deleted before put watermark", ['imageId' => $id]);
                return;
            }
            $path = $this->localStorage->path($image->getLocation());

            $jpgImage = $this->maker->call($this, $path);
            $jpgImage->orientate();
            $this->putTextWatermark($jpgImage, $username);
            $jpgImage->save($path);
            $jpgImage->destroy();
            if (!chmod($path, 0664)) {
                \Log::warning('Failed to set final permissions on image file: ' . $path);
                throw new \Exception('Failed to set final permissions on image file: ' . $path);
            }

        } catch (\Throwable $readableException) {
            if ($readableException instanceof ModelNotFoundException) {
                Log::info("Image has been deleted, discard it", ['imageId' => $id]);
                return;
            }
            Log::error("Image is not readable", [
                'imageId' => $id,
                'error' => $readableException->getMessage()
            ]);
        }
    }

    private function putTextWatermark($jpgImage, $username): void
    {
        $width = $jpgImage->width();
        $height = $jpgImage->height();
        $watermarkFactory = new WatermarkFactory(
            $this->canvas,
            $this->watermarkFont,
            $this->s3,
            $this->localStorage
        );
        $watermarkPath = $watermarkFactory->factoryWatermark($width, $height, $username, true);
        $this->localStorage->put($watermarkPath, $this->s3->get($watermarkPath));
        $watermark = $this->maker->call($this, $this->localStorage->path($watermarkPath));
        $watermark->opacity(35);
        $jpgImage->insert($watermark);
    }
}
