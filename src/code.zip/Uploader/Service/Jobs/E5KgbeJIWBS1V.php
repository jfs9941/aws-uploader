<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Illuminate\Support\Facades\Log;
class E5KgbeJIWBS1V implements BlurVideoJobInterface
{
    const oFxit = 15;
    const YOzWW = 500;
    const R0Xku = 500;
    private $KXch8;
    private $VoF9h;
    private $oBaPs;
    public function __construct($FeIAB, $BQ2l1, $paaZf)
    {
        goto W28iT;
        W28iT:
        $this->oBaPs = $paaZf;
        goto NtLWA;
        LQziM:
        $this->KXch8 = $FeIAB;
        goto PjmpM;
        NtLWA:
        $this->VoF9h = $BQ2l1;
        goto LQziM;
        PjmpM:
    }
    public function blur(string $JTwN4) : void
    {
        goto gYF1l;
        gJQ7o:
        $BC7bB = $this->oBaPs->path($vk8Z1);
        goto UKktj;
        gdIk_:
        throw new \Exception('Failed to set final permissions on image file: ' . $BC7bB);
        goto ZURBQ;
        Dze87:
        unset($a97TB);
        goto idjwJ;
        lC7bn:
        $TeOuL = MbOYV1VlUGCys::findOrFail($JTwN4);
        goto Sf2CZ;
        RDQbb:
        $vk8Z1 = $this->m0Ihgaxh2Ma($TeOuL);
        goto gJQ7o;
        ZURBQ:
        vDTu9:
        goto XhSKX;
        G4Rko:
        $a97TB = $this->KXch8->call($this, $this->oBaPs->path($TeOuL->getAttribute('thumbnail')));
        goto BidYq;
        d8OEY:
        $this->oBaPs->put($TeOuL->getAttribute('thumbnail'), $this->VoF9h->get($TeOuL->getAttribute('thumbnail')));
        goto G4Rko;
        SInxl:
        ini_set('memory_limit', '-1');
        goto lC7bn;
        AFVkp:
        $this->VoF9h->put($vk8Z1, $this->oBaPs->get($vk8Z1));
        goto Dze87;
        UKktj:
        $a97TB->save($BC7bB);
        goto AFVkp;
        Sf2CZ:
        if (!$TeOuL->getAttribute('thumbnail')) {
            goto gryb_;
        }
        goto d8OEY;
        BidYq:
        $C2pdE = $a97TB->width() / $a97TB->height();
        goto EN_p0;
        hp3xR:
        $a97TB->blur(self::oFxit);
        goto RDQbb;
        idjwJ:
        if (chmod($BC7bB, 0664)) {
            goto vDTu9;
        }
        goto H8wZ0;
        EN_p0:
        $a97TB->resize(self::YOzWW, self::R0Xku / $C2pdE);
        goto hp3xR;
        SULVz:
        gryb_:
        goto g92n3;
        XhSKX:
        $TeOuL->update(['preview' => $vk8Z1]);
        goto SULVz;
        gYF1l:
        Log::info("Blurring for video", ['videoID' => $JTwN4]);
        goto SInxl;
        H8wZ0:
        \Log::warning('Failed to set final permissions on image file: ' . $BC7bB);
        goto gdIk_;
        g92n3:
    }
    private function m0Ihgaxh2Ma(Q0JnJtyNI6T0p $QRnM3) : string
    {
        goto CjOqu;
        SyCJ2:
        $ksWJO = dirname($uMpUA) . '/preview/';
        goto ntfic;
        ntfic:
        if ($this->oBaPs->exists($ksWJO)) {
            goto RzA14;
        }
        goto FLjfr;
        fdfCj:
        RzA14:
        goto RWPeq;
        RWPeq:
        return $ksWJO . $QRnM3->getFilename() . '.jpg';
        goto SpTQg;
        FLjfr:
        $this->oBaPs->makeDirectory($ksWJO, 0755, true);
        goto fdfCj;
        CjOqu:
        $uMpUA = $QRnM3->getLocation();
        goto SyCJ2;
        SpTQg:
    }
}
