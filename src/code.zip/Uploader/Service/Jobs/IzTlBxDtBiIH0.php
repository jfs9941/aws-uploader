<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Illuminate\Support\Facades\Log;
class IzTlBxDtBiIH0 implements BlurVideoJobInterface
{
    const tzqDf = 15;
    const kqQEI = 500;
    const f9Oze = 500;
    private $vn9CJ;
    private $aiw3M;
    private $n8EBo;
    public function __construct($HL7fw, $iay5S, $gdQ3g)
    {
        goto SqDzc;
        jfygS:
        $this->vn9CJ = $HL7fw;
        goto xmHrr;
        yu1tJ:
        $this->aiw3M = $iay5S;
        goto jfygS;
        SqDzc:
        $this->n8EBo = $gdQ3g;
        goto yu1tJ;
        xmHrr:
    }
    public function blur(string $zV1kl) : void
    {
        goto o9Fw8;
        T2up_:
        unset($RD3vr);
        goto Q_IL0;
        U3mh4:
        $hBJM1 = $this->n8EBo->path($rxy1g);
        goto tkAca;
        tPHs5:
        a5NCq:
        goto jAoU9;
        yW2kc:
        $this->aiw3M->put($rxy1g, $this->n8EBo->get($rxy1g));
        goto T2up_;
        QNQ2M:
        NScBc:
        goto GdBqw;
        h5pGR:
        $this->n8EBo->put($kEJuN->getAttribute('thumbnail'), $this->aiw3M->get($kEJuN->getAttribute('thumbnail')));
        goto veDDY;
        Q_IL0:
        if (chmod($hBJM1, 0664)) {
            goto NScBc;
        }
        goto Vpcy2;
        ZLkMH:
        throw new \Exception('Failed to set final permissions on image file: ' . $hBJM1);
        goto QNQ2M;
        YvlhX:
        $Ryfn0 = $RD3vr->width() / $RD3vr->height();
        goto lgbeJ;
        Sibw_:
        ini_set('memory_limit', '-1');
        goto TJ2Zo;
        Vpcy2:
        \Log::warning('Failed to set final permissions on image file: ' . $hBJM1);
        goto ZLkMH;
        ZHHqP:
        if (!$kEJuN->getAttribute('thumbnail')) {
            goto a5NCq;
        }
        goto h5pGR;
        lgbeJ:
        $RD3vr->resize(self::kqQEI, self::f9Oze / $Ryfn0);
        goto AybFA;
        tkAca:
        $RD3vr->save($hBJM1);
        goto yW2kc;
        qBULS:
        $rxy1g = $this->mKx2eItiSBx($kEJuN);
        goto U3mh4;
        GdBqw:
        $kEJuN->update(['preview' => $rxy1g]);
        goto tPHs5;
        TJ2Zo:
        $kEJuN = UYo98bF5lKEmO::findOrFail($zV1kl);
        goto ZHHqP;
        o9Fw8:
        Log::info("Blurring for video", ['videoID' => $zV1kl]);
        goto Sibw_;
        AybFA:
        $RD3vr->blur(self::tzqDf);
        goto qBULS;
        veDDY:
        $RD3vr = $this->vn9CJ->call($this, $this->n8EBo->path($kEJuN->getAttribute('thumbnail')));
        goto YvlhX;
        jAoU9:
    }
    private function mKx2eItiSBx(IN9Uizy4TAywx $xVVfG) : string
    {
        goto PlSMc;
        PlSMc:
        $lmTDq = $xVVfG->getLocation();
        goto SkiJl;
        J11xx:
        $this->n8EBo->makeDirectory($JRpFR, 0755, true);
        goto s8lhQ;
        s8lhQ:
        jAa1X:
        goto pnF5P;
        pnF5P:
        return $JRpFR . $xVVfG->getFilename() . '.jpg';
        goto wsDpR;
        aIzB2:
        if ($this->n8EBo->exists($JRpFR)) {
            goto jAa1X;
        }
        goto J11xx;
        SkiJl:
        $JRpFR = dirname($lmTDq) . '/preview/';
        goto aIzB2;
        wsDpR:
    }
}
