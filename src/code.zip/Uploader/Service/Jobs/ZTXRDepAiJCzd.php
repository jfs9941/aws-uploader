<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Encoder\WTlTaBvgTA6Ch;
use Jfs\Uploader\Encoder\JhQP7Y5yz6qRP;
use Jfs\Uploader\Encoder\GfGClJX90DRBN;
use Jfs\Uploader\Encoder\OZoUfPUuX7wTc;
use Jfs\Uploader\Encoder\AZfEtdPfvJaWX;
use Jfs\Uploader\Encoder\WyFzLebe89oBd;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Jfs\Uploader\Service\Jobs\RREwrmnTZh1cK;
use Jfs\Uploader\Service\Jobs\ESxPlrkGkEa6Y;
use Jfs\Uploader\Service\O64LTP0s3gT1J;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class ZTXRDepAiJCzd implements MediaEncodeJobInterface
{
    private $SmbHD;
    private $IaFSl;
    private $huyLW;
    private $Uv8NV;
    private $wap61;
    public function __construct(string $l286D, $B27Pk, $A3hvZ, $lldd6, $D9mvh)
    {
        goto uHZTj;
        f1otp:
        $this->wap61 = $D9mvh;
        goto SObTc;
        jUHPg:
        $this->Uv8NV = $lldd6;
        goto f1otp;
        RTx_B:
        $this->IaFSl = $B27Pk;
        goto TZAVZ;
        TZAVZ:
        $this->huyLW = $A3hvZ;
        goto jUHPg;
        uHZTj:
        $this->SmbHD = $l286D;
        goto RTx_B;
        SObTc:
    }
    public function encode(string $arqvy, string $zGGen, $Nzm_3 = true) : void
    {
        goto Y1Isj;
        Y1Isj:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $arqvy]);
        goto rGKcf;
        R6KbD:
        try {
            goto B5Msh;
            iHOAL:
            if (!($XFeNv->P5ZjQ !== Opdj0uZXaMJfa::S3)) {
                goto Of1MK;
            }
            goto cHlxu;
            rSpa6:
            if (!$BJuCH) {
                goto nMqZl;
            }
            goto XGq69;
            dQn2C:
            $rpeu1 = new JhQP7Y5yz6qRP('1080p', $G7gEc['width'], $G7gEc['height'], $XFeNv->lO2hG ?? 30);
            goto yesoQ;
            B5Msh:
            $XFeNv = RhSx2q5xIlh0Y::findOrFail($arqvy);
            goto Zec72;
            AlwNs:
            OWV2F:
            goto VJ_AI;
            ATiAg:
            $zjUQs = $this->mgqwFmQ3edt($XFeNv);
            goto d0KcZ;
            kQgU9:
            $rpeu1 = $rpeu1->mIzdYvq0h1J($BJuCH);
            goto AlwNs;
            YJk84:
            Of1MK:
            goto pWoBh;
            MV300:
            PbZKQ:
            goto c8SaK;
            CEgep:
            $eyDUn->mUqisKhhzrI($rhcho->mqE7Y3tGn1Q($XFeNv));
            goto CU4WI;
            gMTcl:
            $sccRX = $XFeNv->height();
            goto ATiAg;
            fSyX6:
            $eyDUn = $eyDUn->mK8cOX9TmE1($dZvCS);
            goto ci4jz;
            jKJcz:
            $eyDUn->mcg36sdWFyv($xWK1z);
            goto CEgep;
            d96Ij:
            $xWK1z = new JhQP7Y5yz6qRP('original', $oy0ze, $sccRX, $XFeNv->lO2hG ?? 30);
            goto a9zMb;
            d0KcZ:
            Log::info("Set input video for Job", ['s3Uri' => $zjUQs]);
            goto dD40K;
            WjsAf:
            $IuV7H = app(O64LTP0s3gT1J::class);
            goto oJS3x;
            aGpZg:
            nMqZl:
            goto jKJcz;
            WcKsL:
            $XFeNv->update(['aws_media_converter_job_id' => $arqvy]);
            goto lpUK3;
            LZX2b:
            if (!$this->m4wMpg07esY($oy0ze, $sccRX)) {
                goto PbZKQ;
            }
            goto OxgBQ;
            UpvV5:
            $BJuCH = $this->mf5QVXNble4($IuV7H, $SW277->mUcOzHh2TqY($XFeNv->width(), $XFeNv->height(), $zGGen));
            goto rSpa6;
            lBnJb:
            Log::info("Set thumbnail for RhSx2q5xIlh0Y Job", ['videoId' => $XFeNv->getAttribute('id'), 'duration' => $XFeNv->getAttribute('duration')]);
            goto l33KT;
            OxgBQ:
            $G7gEc = $this->mxK9Qp1LXPp($oy0ze, $sccRX);
            goto qbFiT;
            l33KT:
            $dZvCS = new WTlTaBvgTA6Ch($XFeNv->QjP6I ?? 1, 2, $rhcho->mfPcBw4lY1y($XFeNv));
            goto fSyX6;
            w3N8k:
            if (!$BJuCH) {
                goto OWV2F;
            }
            goto kQgU9;
            N4z7E:
            $eyDUn->mcg36sdWFyv($xWK1z);
            goto m_Mh6;
            cHlxu:
            throw new MediaConverterException("RhSx2q5xIlh0Y {$XFeNv->id} is not S3 driver");
            goto YJk84;
            c8SaK:
            d8lWT:
            goto lBnJb;
            VJ_AI:
            $eyDUn = $eyDUn->mcg36sdWFyv($rpeu1);
            goto MV300;
            pWoBh:
            $oy0ze = $XFeNv->width();
            goto gMTcl;
            m_Mh6:
            $eyDUn->mUqisKhhzrI($rhcho->mqE7Y3tGn1Q($XFeNv));
            goto WjsAf;
            oJS3x:
            $SW277 = new ESxPlrkGkEa6Y($this->Uv8NV, $this->wap61, $this->huyLW, $this->IaFSl);
            goto UpvV5;
            XGq69:
            $xWK1z = $xWK1z->mIzdYvq0h1J($BJuCH);
            goto aGpZg;
            pVwDf:
            $eyDUn = $eyDUn->mtrNCBQyyki(new OZoUfPUuX7wTc($zjUQs));
            goto d96Ij;
            dD40K:
            $eyDUn = app(AZfEtdPfvJaWX::class);
            goto pVwDf;
            CU4WI:
            if (!($oy0ze && $sccRX)) {
                goto d8lWT;
            }
            goto LZX2b;
            a9zMb:
            $rhcho = app(GfGClJX90DRBN::class);
            goto N4z7E;
            qbFiT:
            Log::info("Set 1080p resolution for Job", ['width' => $G7gEc['width'], 'height' => $G7gEc['height'], 'originalWidth' => $oy0ze, 'originalHeight' => $sccRX]);
            goto dQn2C;
            ci4jz:
            $arqvy = $eyDUn->mtdvr0ZvGBg($this->m0cUvOBZQEI($XFeNv, $Nzm_3));
            goto WcKsL;
            Zec72:
            Assert::isInstanceOf($XFeNv, RhSx2q5xIlh0Y::class);
            goto iHOAL;
            yesoQ:
            $BJuCH = $this->mf5QVXNble4($IuV7H, $SW277->mUcOzHh2TqY((int) $G7gEc['width'], (int) $G7gEc['height'], $zGGen));
            goto w3N8k;
            lpUK3:
        } catch (\Exception $vR5RQ) {
            Log::info("RhSx2q5xIlh0Y has been deleted, discard it", ['fileId' => $arqvy, 'err' => $vR5RQ->getMessage()]);
            return;
        }
        goto xf114;
        rGKcf:
        ini_set('memory_limit', '-1');
        goto R6KbD;
        xf114:
    }
    private function m0cUvOBZQEI(RhSx2q5xIlh0Y $XFeNv, $Nzm_3) : bool
    {
        goto S8pxI;
        AMoR1:
        U1hd4:
        goto KmXLl;
        voUc3:
        return false;
        goto ikT1T;
        S8pxI:
        if ($Nzm_3) {
            goto S1RYn;
        }
        goto voUc3;
        OF2Zn:
        WH7y5:
        goto AMoR1;
        ikT1T:
        S1RYn:
        goto zLWus;
        zLWus:
        $I7cMU = (int) round($XFeNv->getAttribute('duration') ?? 0);
        goto m7ozu;
        m7ozu:
        switch (true) {
            case $XFeNv->width() * $XFeNv->height() >= 1920 * 1080 && $XFeNv->width() * $XFeNv->height() < 2560 * 1440:
                return $I7cMU > 10 * 60;
            case $XFeNv->width() * $XFeNv->height() >= 2560 * 1440 && $XFeNv->width() * $XFeNv->height() < 3840 * 2160:
                return $I7cMU > 5 * 60;
            case $XFeNv->width() * $XFeNv->height() >= 3840 * 2160:
                return $I7cMU > 3 * 60;
            default:
                return false;
        }
        goto OF2Zn;
        KmXLl:
    }
    private function mf5QVXNble4(O64LTP0s3gT1J $IuV7H, string $IOBET) : ?WyFzLebe89oBd
    {
        goto Ljjq5;
        j57OF:
        return null;
        goto twx51;
        O3Qcc:
        Log::info("Resolve watermark for job with url", ['url' => $IOBET, 'uri' => $x2MFi]);
        goto dZxMR;
        gsM78:
        return new WyFzLebe89oBd($x2MFi, 0, 0, null, null);
        goto mDXRW;
        Ljjq5:
        $x2MFi = $IuV7H->meCjKC5izfh($IOBET);
        goto O3Qcc;
        mDXRW:
        Ygk7Z:
        goto j57OF;
        dZxMR:
        if (!$x2MFi) {
            goto Ygk7Z;
        }
        goto gsM78;
        twx51:
    }
    private function m4wMpg07esY(int $oy0ze, int $sccRX) : bool
    {
        return $oy0ze * $sccRX > 1.5 * (1920 * 1080);
    }
    private function mxK9Qp1LXPp(int $oy0ze, int $sccRX) : array
    {
        $JvvBo = new RREwrmnTZh1cK($oy0ze, $sccRX);
        return $JvvBo->mb5nAkDPCjm();
    }
    private function mgqwFmQ3edt(NRDoWGrbd9WhU $S8CpP) : string
    {
        goto x49wd;
        x49wd:
        if (!($S8CpP->P5ZjQ == Opdj0uZXaMJfa::S3)) {
            goto TRKat;
        }
        goto EAONW;
        XUfw9:
        return $this->IaFSl->url($S8CpP->filename);
        goto vOMFR;
        HDeNB:
        TRKat:
        goto XUfw9;
        EAONW:
        return 's3://' . $this->SmbHD . '/' . $S8CpP->filename;
        goto HDeNB;
        vOMFR:
    }
}
