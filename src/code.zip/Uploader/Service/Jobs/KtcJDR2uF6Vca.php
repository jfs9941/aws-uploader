<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
class KtcJDR2uF6Vca implements BlurJobInterface
{
    const O45L2 = 15;
    const GgqFG = 500;
    const f0GyN = 500;
    private $mwf2R;
    private $Vhcrn;
    private $riMoE;
    public function __construct($eF8NA, $Klx1U, $BP_p5)
    {
        goto OyFjK;
        Vaq79:
        $this->mwf2R = $eF8NA;
        goto SfbQJ;
        OyFjK:
        $this->riMoE = $BP_p5;
        goto E0A12;
        E0A12:
        $this->Vhcrn = $Klx1U;
        goto Vaq79;
        SfbQJ:
    }
    public function blur(string $mfjeD) : void
    {
        goto Mqoq3;
        vjy7l:
        $fK3zd->resize(self::GgqFG, self::f0GyN / $fu4AJ);
        goto JYRVO;
        y3Ckn:
        if (!($UaX2R->pM1q4 == GTmWxMidiCuj0::S3 && !$this->riMoE->exists($UaX2R->filename))) {
            goto MQomr;
        }
        goto CZUZd;
        H0paB:
        $fK3zd = $this->mwf2R->call($this, $this->riMoE->path($UaX2R->getLocation()));
        goto X3bDA;
        QeHT2:
        $fK3zd->save($OMYvA);
        goto hdbn2;
        XTs5g:
        wF4ar:
        goto j47TC;
        kuVzM:
        MQomr:
        goto H0paB;
        fL83k:
        $o70_W = $this->msYkutivjiO($UaX2R);
        goto GRa14;
        hdbn2:
        unset($fK3zd);
        goto UIzzE;
        haaAi:
        throw new \Exception('Failed to set final permissions on image file: ' . $OMYvA);
        goto XTs5g;
        UIzzE:
        if (chmod($OMYvA, 0664)) {
            goto wF4ar;
        }
        goto ZgrW2;
        JYRVO:
        $fK3zd->blur(self::O45L2);
        goto fL83k;
        Mqoq3:
        $UaX2R = DsyQbNiy8VgJG::findOrFail($mfjeD);
        goto ZJlQV;
        X3bDA:
        $fu4AJ = $fK3zd->width() / $fK3zd->height();
        goto vjy7l;
        j47TC:
        $UaX2R->update(['preview' => $o70_W]);
        goto iQNRT;
        PKAqN:
        $this->riMoE->put($UaX2R->filename, $i1puF);
        goto kuVzM;
        CZUZd:
        $i1puF = $this->Vhcrn->get($UaX2R->filename);
        goto PKAqN;
        ZJlQV:
        ini_set('memory_limit', '-1');
        goto y3Ckn;
        GRa14:
        $OMYvA = $this->riMoE->path($o70_W);
        goto QeHT2;
        ZgrW2:
        \Log::warning('Failed to set final permissions on image file: ' . $OMYvA);
        goto haaAi;
        iQNRT:
    }
    private function msYkutivjiO($pCi_z) : string
    {
        goto qmFAx;
        qmFAx:
        $J9IgU = $pCi_z->getLocation();
        goto P50pI;
        P50pI:
        $Wp3Im = dirname($J9IgU) . '/preview/';
        goto GlMfZ;
        Uck6z:
        pOtH5:
        goto VXQXw;
        CuGRO:
        $this->riMoE->makeDirectory($Wp3Im, 0755, true);
        goto Uck6z;
        VXQXw:
        return $Wp3Im . $pCi_z->getFilename() . '.jpg';
        goto J2hnK;
        GlMfZ:
        if ($this->riMoE->exists($Wp3Im)) {
            goto pOtH5;
        }
        goto CuGRO;
        J2hnK:
    }
}
