<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
class DTho4X5GKmLwU implements StoreToS3JobInterface
{
    private $RFvhw;
    private $K79lK;
    private $HyJkj;
    public function __construct($LDEwd, $yEBaZ, $N7YvB)
    {
        goto p4bjK;
        HYfPF:
        $this->HyJkj = $N7YvB;
        goto R3Qtz;
        p4bjK:
        $this->K79lK = $yEBaZ;
        goto HYfPF;
        R3Qtz:
        $this->RFvhw = $LDEwd;
        goto fSuPE;
        fSuPE:
    }
    public function store(string $Qu08p) : void
    {
        goto pK9w9;
        tIqto:
        $u3yva = $this->HyJkj->path($BfIMd->getAttribute('preview'));
        goto MkZkX;
        MkZkX:
        $NF9Fd = $this->RFvhw->call($this, $u3yva);
        goto nhW5V;
        Hftk7:
        return;
        goto DDtxs;
        A2C5l:
        g2Hyn:
        goto hmn4b;
        PNV89:
        if (!($IsvL6 && $this->HyJkj->exists($IsvL6))) {
            goto aANpN;
        }
        goto O2yIb;
        zAa4z:
        Log::info("YPgQPiPQjMu1g stored to S3, update the children attachments", ['fileId' => $Qu08p]);
        goto P4Bhv;
        PjIhf:
        if (!$BfIMd->update(['driver' => NYPGraEb3Ennl::S3, 'status' => OLX71luAn6XnP::FINISHED])) {
            goto g2Hyn;
        }
        goto zAa4z;
        DDtxs:
        DMXSt:
        goto C8_zs;
        O2yIb:
        $tinpi = $this->HyJkj->path($IsvL6);
        goto sRUxc;
        pK9w9:
        $BfIMd = YPgQPiPQjMu1g::findOrFail($Qu08p);
        goto YRFJj;
        y9lmz:
        Log::info("YPgQPiPQjMu1g has been deleted, discard it", ['fileId' => $Qu08p]);
        goto Hftk7;
        MNxlM:
        $IsvL6 = $BfIMd->getAttribute('thumbnail');
        goto PNV89;
        sRUxc:
        $O8BOu = $this->RFvhw->call($this, $tinpi);
        goto hE1cM;
        nhW5V:
        $this->K79lK->put($BfIMd->getAttribute('preview'), $NF9Fd->stream(), ['visibility' => 'public', 'ContentType' => $NF9Fd->mime(), 'ContentDisposition' => 'inline']);
        goto zxQbs;
        P4Bhv:
        YPgQPiPQjMu1g::where('parent_id', $Qu08p)->update(['driver' => NYPGraEb3Ennl::S3, 'preview' => $BfIMd->getAttribute('preview'), 'thumbnail' => $BfIMd->getAttribute('thumbnail')]);
        goto PXw0b;
        hE1cM:
        $this->K79lK->put($BfIMd->getAttribute('thumbnail'), $O8BOu->stream(), ['visibility' => 'public', 'ContentType' => $O8BOu->mime(), 'ContentDisposition' => 'inline']);
        goto lNrWI;
        zxQbs:
        evvU2:
        goto PjIhf;
        hmn4b:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $Qu08p]);
        goto uuwux;
        PXw0b:
        return;
        goto A2C5l;
        C8_zs:
        $TnwL2 = $this->HyJkj->path($BfIMd->getLocation());
        goto nET7a;
        lNrWI:
        aANpN:
        goto DnMqe;
        DnMqe:
        if (!($BfIMd->getAttribute('preview') && $this->HyJkj->exists($BfIMd->getAttribute('preview')))) {
            goto evvU2;
        }
        goto tIqto;
        nET7a:
        $fe3pc = $this->RFvhw->call($this, $TnwL2);
        goto riSpP;
        YRFJj:
        if ($BfIMd) {
            goto DMXSt;
        }
        goto y9lmz;
        riSpP:
        $this->K79lK->put($BfIMd->getLocation(), $fe3pc->stream(), ['visibility' => 'public', 'ContentType' => $fe3pc->mime(), 'ContentDisposition' => 'inline']);
        goto MNxlM;
        uuwux:
    }
}
