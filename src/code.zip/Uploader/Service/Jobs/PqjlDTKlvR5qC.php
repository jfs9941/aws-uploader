<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class PqjlDTKlvR5qC implements CompressJobInterface
{
    const Nys2Y = 60;
    private $awXpN;
    private $AwDbR;
    private $AoOHl;
    public function __construct($ek1iS, $uwOBm, $cTRYW)
    {
        goto HeLfH;
        zikwL:
        $this->AwDbR = $uwOBm;
        goto B2Cmt;
        HeLfH:
        $this->awXpN = $ek1iS;
        goto uSNZY;
        uSNZY:
        $this->AoOHl = $cTRYW;
        goto zikwL;
        B2Cmt:
    }
    public function compress(string $B5uQ4)
    {
        goto qTJN7;
        aW6Rd:
        $Pykf_ = memory_get_usage();
        goto IN1lm;
        qPVTn:
        Log::info("Compress image", ['imageId' => $B5uQ4]);
        goto CXorB;
        IN1lm:
        $EPciM = memory_get_peak_usage();
        goto qPVTn;
        qTJN7:
        $Sb3tS = microtime(true);
        goto aW6Rd;
        CXorB:
        try {
            goto krY6y;
            PLJk7:
            try {
                goto FAHqZ;
                qIaiC:
                $this->mvAcHMBgnfw($jYl_6, 'webp');
                goto S31c_;
                aFpi1:
                $this->mbGv7eF9Q1H($LM50i, $guFym);
                goto qIaiC;
                FAHqZ:
                $guFym = $this->AwDbR->path(str_replace('.jpg', '.webp', $jYl_6->getLocation()));
                goto aFpi1;
                S31c_:
            } catch (\Exception $EgQtq) {
                goto It93B;
                zO1Rz:
                $this->mYO4YvODEM1($LM50i, $guFym);
                goto iCt9E;
                SBpqF:
                $guFym = $this->AwDbR->path($jYl_6->getLocation());
                goto zO1Rz;
                It93B:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $B5uQ4, 'error' => $EgQtq->getMessage()]);
                goto SBpqF;
                iCt9E:
            }
            goto AJF16;
            GQYmr:
            if (!(strtolower($jYl_6->getExtension()) === 'png' || strtolower($jYl_6->getExtension()) === 'heic')) {
                goto TMF_e;
            }
            goto oaRdy;
            ZOhhQ:
            $LM50i = $this->AwDbR->path($jYl_6->getLocation());
            goto GQYmr;
            oaRdy:
            $jYl_6 = $this->mvAcHMBgnfw($jYl_6, 'jpg');
            goto hsbPD;
            krY6y:
            $jYl_6 = U0IzvN2kaLZHI::findOrFail($B5uQ4);
            goto ZOhhQ;
            hsbPD:
            TMF_e:
            goto PLJk7;
            AJF16:
        } catch (\Throwable $EgQtq) {
            goto QZYJf;
            VNLJN:
            Log::info("U0IzvN2kaLZHI has been deleted, discard it", ['imageId' => $B5uQ4]);
            goto i_xLH;
            SzRSF:
            lKSCm:
            goto OOGfp;
            QZYJf:
            if (!$EgQtq instanceof ModelNotFoundException) {
                goto lKSCm;
            }
            goto VNLJN;
            i_xLH:
            return;
            goto SzRSF;
            OOGfp:
            Log::error("Failed to compress image", ['imageId' => $B5uQ4, 'error' => $EgQtq->getMessage()]);
            goto ymav7;
            ymav7:
        } finally {
            $YrIBh = microtime(true);
            $qjV8v = memory_get_usage();
            $iOIuO = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $B5uQ4, 'execution_time_sec' => $YrIBh - $Sb3tS, 'memory_usage_mb' => ($qjV8v - $Pykf_) / 1024 / 1024, 'peak_memory_usage_mb' => ($iOIuO - $EPciM) / 1024 / 1024]);
        }
        goto fVnRq;
        fVnRq:
    }
    private function mYO4YvODEM1($LM50i, $guFym)
    {
        goto tLsES;
        Cr96X:
        $this->AoOHl->put($guFym, $vVpA1->toJpeg(self::Nys2Y), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto dC3qd;
        tvgVf:
        $vVpA1->orient()->toJpeg(self::Nys2Y)->save($guFym);
        goto Cr96X;
        dC3qd:
        unset($vVpA1);
        goto n6z0h;
        tLsES:
        $vVpA1 = $this->awXpN->call($this, $LM50i);
        goto tvgVf;
        n6z0h:
    }
    private function mbGv7eF9Q1H($LM50i, $guFym)
    {
        goto bu6Wv;
        gTqon:
        unset($vVpA1);
        goto EGRmL;
        bu6Wv:
        $vVpA1 = $this->awXpN->call($this, $LM50i);
        goto N7TQx;
        L1kKM:
        $this->AoOHl->put($guFym, $vVpA1->toJpeg(self::Nys2Y), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto gTqon;
        N7TQx:
        $vVpA1->orient()->toWebp(self::Nys2Y);
        goto L1kKM;
        EGRmL:
    }
    private function mvAcHMBgnfw($jYl_6, $M5w3u)
    {
        goto q6wIA;
        pPw7c:
        return $jYl_6;
        goto L6l4a;
        Uyrxj:
        $jYl_6->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$M5w3u}", $jYl_6->getLocation()));
        goto TuCkd;
        TuCkd:
        $jYl_6->save();
        goto pPw7c;
        q6wIA:
        $jYl_6->setAttribute('type', $M5w3u);
        goto Uyrxj;
        L6l4a:
    }
}
