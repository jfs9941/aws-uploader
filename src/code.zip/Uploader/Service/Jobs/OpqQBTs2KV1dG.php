<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class OpqQBTs2KV1dG implements CompressJobInterface
{
    const Bper6 = 60;
    private $JG9IT;
    private $Ntit8;
    private $pdBhJ;
    public function __construct($mLPCZ, $MYg0D, $qMGry)
    {
        goto bsCb6;
        bsCb6:
        $this->JG9IT = $mLPCZ;
        goto CpYAU;
        CpYAU:
        $this->pdBhJ = $qMGry;
        goto r21PS;
        r21PS:
        $this->Ntit8 = $MYg0D;
        goto jnVtP;
        jnVtP:
    }
    public function compress(string $arqvy)
    {
        goto Er47s;
        Er47s:
        $zi0zx = microtime(true);
        goto fRoLk;
        EZKL6:
        Log::info("Compress image", ['imageId' => $arqvy]);
        goto iwyIw;
        Q45EV:
        $Eq74o = memory_get_peak_usage();
        goto EZKL6;
        iwyIw:
        try {
            goto HOxaJ;
            reV4K:
            knfp_:
            goto atIpZ;
            SBUjs:
            $M7phn = $this->Ntit8->path($uuvVo->getLocation());
            goto s2j3v;
            ec0z9:
            $uuvVo = $this->mRDcqwl7cMi($uuvVo, 'jpg');
            goto reV4K;
            HOxaJ:
            $uuvVo = S7LEoIprYtLQw::findOrFail($arqvy);
            goto SBUjs;
            s2j3v:
            if (!(strtolower($uuvVo->getExtension()) === 'png' || strtolower($uuvVo->getExtension()) === 'heic')) {
                goto knfp_;
            }
            goto ec0z9;
            atIpZ:
            try {
                goto jOhmP;
                ZFFED:
                $this->mRDcqwl7cMi($uuvVo, 'webp');
                goto LvfzH;
                J7d0_:
                $this->ma9CKoeeRzN($M7phn, $pJAIi);
                goto ZFFED;
                jOhmP:
                $pJAIi = $this->Ntit8->path(str_replace('.jpg', '.webp', $uuvVo->getLocation()));
                goto J7d0_;
                LvfzH:
            } catch (\Exception $FTnqg) {
                goto sx4R1;
                sx4R1:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $arqvy, 'error' => $FTnqg->getMessage()]);
                goto EO38o;
                IUUTz:
                $this->mCOCldO5iu5($M7phn, $pJAIi);
                goto wUzMj;
                EO38o:
                $pJAIi = $this->Ntit8->path($uuvVo->getLocation());
                goto IUUTz;
                wUzMj:
            }
            goto RRsgf;
            RRsgf:
        } catch (\Throwable $FTnqg) {
            goto C_WLv;
            p7TmU:
            Log::error("Failed to compress image", ['imageId' => $arqvy, 'error' => $FTnqg->getMessage()]);
            goto NS3Yx;
            qU5Si:
            BsbuE:
            goto p7TmU;
            mgnYg:
            return;
            goto qU5Si;
            C_WLv:
            if (!$FTnqg instanceof ModelNotFoundException) {
                goto BsbuE;
            }
            goto KBxeY;
            KBxeY:
            Log::info("S7LEoIprYtLQw has been deleted, discard it", ['imageId' => $arqvy]);
            goto mgnYg;
            NS3Yx:
        } finally {
            $qEn0v = microtime(true);
            $itTa2 = memory_get_usage();
            $qUJq5 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $arqvy, 'execution_time_sec' => $qEn0v - $zi0zx, 'memory_usage_mb' => ($itTa2 - $NAxoU) / 1024 / 1024, 'peak_memory_usage_mb' => ($qUJq5 - $Eq74o) / 1024 / 1024]);
        }
        goto PVzyo;
        fRoLk:
        $NAxoU = memory_get_usage();
        goto Q45EV;
        PVzyo:
    }
    private function mCOCldO5iu5($M7phn, $pJAIi)
    {
        goto T0AgL;
        YaRCD:
        $cl9Px->orient()->toJpeg(self::Bper6)->save($pJAIi);
        goto YZ56b;
        l8Yos:
        unset($cl9Px);
        goto FmqGV;
        T0AgL:
        $cl9Px = $this->JG9IT->call($this, $M7phn);
        goto YaRCD;
        YZ56b:
        $this->pdBhJ->put($pJAIi, $cl9Px->toJpeg(self::Bper6), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto l8Yos;
        FmqGV:
    }
    private function ma9CKoeeRzN($M7phn, $pJAIi)
    {
        goto SNuMZ;
        m8EAY:
        unset($cl9Px);
        goto Z24EG;
        wf2na:
        $cl9Px->orient()->toWebp(self::Bper6);
        goto vAA2z;
        vAA2z:
        $this->pdBhJ->put($pJAIi, $cl9Px->toJpeg(self::Bper6), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto m8EAY;
        SNuMZ:
        $cl9Px = $this->JG9IT->call($this, $M7phn);
        goto wf2na;
        Z24EG:
    }
    private function mRDcqwl7cMi($uuvVo, $w7vYI)
    {
        goto b0eHy;
        z7Jbm:
        $uuvVo->save();
        goto nmwBJ;
        b0eHy:
        $uuvVo->setAttribute('type', $w7vYI);
        goto OvX0_;
        nmwBJ:
        return $uuvVo;
        goto vFzXz;
        OvX0_:
        $uuvVo->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$w7vYI}", $uuvVo->getLocation()));
        goto z7Jbm;
        vFzXz:
    }
}
