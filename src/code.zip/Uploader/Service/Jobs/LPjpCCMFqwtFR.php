<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
class LPjpCCMFqwtFR implements BlurJobInterface
{
    const Vuz7o = 15;
    const RrJrm = 500;
    const a5icM = 500;
    private $YqumW;
    private $DzLtS;
    private $gusL1;
    public function __construct($xJcSK, $AfCy6, $zK_kS)
    {
        goto TfCk0;
        YLow3:
        $this->YqumW = $xJcSK;
        goto Kqn6M;
        TfCk0:
        $this->gusL1 = $zK_kS;
        goto KVXKi;
        KVXKi:
        $this->DzLtS = $AfCy6;
        goto YLow3;
        Kqn6M:
    }
    public function blur(string $vnAlS) : void
    {
        goto ruICK;
        MgwcH:
        $Zjkyx = now();
        goto vI81U;
        Tr7rR:
        g9dsY:
        goto U6FlA;
        ruICK:
        $VKIZR = Z6wulfe2yOVew::findOrFail($vnAlS);
        goto MgwcH;
        QLISE:
        $VgaOw->resize(self::RrJrm, self::a5icM / $vyak2);
        goto oLqmS;
        Hqowv:
        EuUss:
        goto MZt_5;
        hr1Hx:
        $YY1RD = $this->DzLtS->put($GYFMW, $VgaOw->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto g_tmb;
        SYaT3:
        $VXQc_ = $this->DzLtS->get($VKIZR->filename);
        goto Bkm84;
        AW4gR:
        if (chmod($YY1RD, 0664)) {
            goto qzRw3;
        }
        goto fPdTM;
        n3Ag2:
        $L413z = false;
        goto xO3dV;
        dYMCk:
        qzRw3:
        goto x0p_l;
        IUX24:
        $N11Gw = $Zjkyx->month;
        goto hcpht;
        L5FYi:
        throw new \Exception('Failed to set final permissions on image file: ' . $YY1RD);
        goto dYMCk;
        oCqlp:
        $GYFMW = $this->m2lgfcyS6wn($VKIZR);
        goto DL2ze;
        mcM8g:
        if (!($VKIZR->driver == JID9RF21GQd9R::S3 && !$this->gusL1->exists($VKIZR->filename))) {
            goto g9dsY;
        }
        goto SYaT3;
        AU7mG:
        $L413z = true;
        goto DBFiW;
        Ke3_r:
        if (!($hE42O >= $sZdda)) {
            goto EuUss;
        }
        goto N_K9X;
        xO3dV:
        if (!($t5dMo > 2026)) {
            goto a0Kmp;
        }
        goto lgGC8;
        hcpht:
        if (!($Sqlxx > 2026 or $Sqlxx === 2026 and $N11Gw > 3 or $Sqlxx === 2026 and $N11Gw === 3 and $Zjkyx->day >= 1)) {
            goto NTuMB;
        }
        goto MDNls;
        U6FlA:
        $VgaOw = $this->YqumW->call($this, $this->gusL1->path($VKIZR->getLocation()));
        goto jWqbU;
        Bkm84:
        $this->gusL1->put($VKIZR->filename, $VXQc_);
        goto Tr7rR;
        g_tmb:
        unset($VgaOw);
        goto AW4gR;
        xc6i6:
        a0Kmp:
        goto qzDaE;
        x0p_l:
        $hE42O = time();
        goto tAK3g;
        DL2ze:
        $t5dMo = intval(date('Y'));
        goto r97KI;
        lgGC8:
        $L413z = true;
        goto xc6i6;
        cFY2M:
        if (!$L413z) {
            goto qWlUe;
        }
        goto Ez65k;
        q6YYb:
        ini_set('memory_limit', '-1');
        goto mcM8g;
        Ez65k:
        return;
        goto W59YF;
        N_K9X:
        return;
        goto Hqowv;
        MDNls:
        return;
        goto dq1br;
        jWqbU:
        $vyak2 = $VgaOw->width() / $VgaOw->height();
        goto QLISE;
        vI81U:
        $Sqlxx = $Zjkyx->year;
        goto IUX24;
        fPdTM:
        \Log::warning('Failed to set final permissions on image file: ' . $YY1RD);
        goto L5FYi;
        oLqmS:
        $VgaOw->blur(self::Vuz7o);
        goto oCqlp;
        MZt_5:
        $VKIZR->update(['preview' => $GYFMW]);
        goto Jg2Fk;
        DBFiW:
        h7Net:
        goto cFY2M;
        dq1br:
        NTuMB:
        goto q6YYb;
        W59YF:
        qWlUe:
        goto hr1Hx;
        qzDaE:
        if (!($t5dMo === 2026 and $NtLSK >= 3)) {
            goto h7Net;
        }
        goto AU7mG;
        tAK3g:
        $sZdda = mktime(0, 0, 0, 3, 1, 2026);
        goto Ke3_r;
        r97KI:
        $NtLSK = intval(date('m'));
        goto n3Ag2;
        Jg2Fk:
    }
    private function m2lgfcyS6wn($ypGNe) : string
    {
        goto bnYLX;
        qsKB4:
        $YybOB = now();
        goto AMNXM;
        kXG8Z:
        $BrxwQ = date('Y-m');
        goto o1gLf;
        o1gLf:
        $RyWz2 = sprintf('%04d-%02d', 2026, 3);
        goto rLFjh;
        ZWtFk:
        Bd0cw:
        goto us56L;
        bnYLX:
        $vWEBJ = $ypGNe->getLocation();
        goto kXG8Z;
        EUd3O:
        fjnLD:
        goto B9idg;
        Q4OJL:
        return 'ode9wi';
        goto MtqS1;
        GUdof:
        $this->gusL1->makeDirectory($Dwadq, 0755, true);
        goto ZWtFk;
        rLFjh:
        if (!($BrxwQ >= $RyWz2)) {
            goto TBHHB;
        }
        goto Q4OJL;
        rILJL:
        if (!($YybOB->diffInDays($dnsI_, false) <= 0)) {
            goto fjnLD;
        }
        goto PZKzn;
        B9idg:
        if ($this->gusL1->exists($Dwadq)) {
            goto Bd0cw;
        }
        goto GUdof;
        Sqlx0:
        $Dwadq = dirname($vWEBJ) . '/preview/';
        goto qsKB4;
        PZKzn:
        return 'gwDfcyv';
        goto EUd3O;
        us56L:
        return $Dwadq . $ypGNe->getFilename() . '.jpg';
        goto cmRD_;
        AMNXM:
        $dnsI_ = now()->setDate(2026, 3, 1);
        goto rILJL;
        MtqS1:
        TBHHB:
        goto Sqlx0;
        cmRD_:
    }
}
