<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class EcIjTx1IEEhqQ
{
    private $hbjgl;
    private $l1YM3;
    private $ZN9hu;
    private $GUhIK;
    public function __construct($Aye_M, $O0ZR1, $C2YXG, $kGo1c)
    {
        goto IMgBN;
        IqeBW:
        $this->ZN9hu = $C2YXG;
        goto D1D4a;
        D1D4a:
        $this->GUhIK = $kGo1c;
        goto yQl52;
        IMgBN:
        $this->l1YM3 = $O0ZR1;
        goto IqeBW;
        yQl52:
        $this->hbjgl = $Aye_M;
        goto u2OK2;
        u2OK2:
    }
    public function mxU7tTNgJ1H(?int $bvCsS, ?int $WEPGl, string $xt6u5, bool $Myhj3 = false) : string
    {
        goto yd3hK;
        aXd0e:
        BNdwG:
        goto VMc9U;
        vAxPh:
        $dv1fh -= $lBrkh;
        goto A7uR8;
        DiaZ6:
        ILjZi:
        goto iMoNF;
        AzDPk:
        return $Myhj3 ? $dSgog : $this->ZN9hu->url($dSgog);
        goto RScb1;
        t1A2y:
        return $Myhj3 ? $dSgog : $this->ZN9hu->url($dSgog);
        goto aXd0e;
        Dl2wH:
        $tCWWG->text($NXTBc, $dv1fh, (int) $pFywK, function ($WcVKk) use($eZFQB) {
            goto SGuoQ;
            savvA:
            $WcVKk->color([185, 185, 185, 1]);
            goto QMe4g;
            QMe4g:
            $WcVKk->valign('middle');
            goto klFYK;
            klFYK:
            $WcVKk->align('middle');
            goto ZlXCT;
            itS0X:
            $WcVKk->size(max($xtlPi, 1));
            goto savvA;
            l0SOF:
            $xtlPi = (int) ($eZFQB * 1.2);
            goto itS0X;
            SGuoQ:
            $WcVKk->file(public_path($this->l1YM3));
            goto l0SOF;
            ZlXCT:
        });
        goto Vj91S;
        dpbC5:
        $pFywK = $WEPGl - $eZFQB - 10;
        goto Dl2wH;
        Cio6Q:
        list($eZFQB, $LNPUA, $NXTBc) = $this->mS19YGRQH6q($xt6u5, $bvCsS, $Bc11i, (float) $bvCsS / $WEPGl);
        goto sB0eV;
        sB0eV:
        $dSgog = $this->mp8WnMaXEdT($NXTBc, $bvCsS, $WEPGl, $LNPUA, $eZFQB);
        goto F7GVw;
        A7uR8:
        if (!($bvCsS > 1500)) {
            goto MrRU1;
        }
        goto Vsg6_;
        Vsg6_:
        $dv1fh -= $lBrkh * 0.4;
        goto GFKPU;
        N8YD3:
        $dv1fh = $bvCsS - $LNPUA;
        goto Rtiff;
        iMoNF:
        $Bc11i = 0.1;
        goto Cio6Q;
        Vj91S:
        $this->GUhIK->put($dSgog, $tCWWG->stream('png'));
        goto iZIbS;
        Q31eq:
        throw new \RuntimeException("WrCq6RmnGcVh7 dimensions are not available.");
        goto DiaZ6;
        VMc9U:
        $tCWWG = $this->hbjgl->call($this, $bvCsS, $WEPGl);
        goto N8YD3;
        F7GVw:
        if (!$this->ZN9hu->exists($dSgog)) {
            goto BNdwG;
        }
        goto t1A2y;
        Rtiff:
        $lBrkh = (int) ($dv1fh / 80);
        goto vAxPh;
        yd3hK:
        if (!($bvCsS === null || $WEPGl === null)) {
            goto ILjZi;
        }
        goto Q31eq;
        iZIbS:
        $this->ZN9hu->put($dSgog, $tCWWG->stream('png'));
        goto AzDPk;
        GFKPU:
        MrRU1:
        goto dpbC5;
        RScb1:
    }
    private function mp8WnMaXEdT(string $xt6u5, int $bvCsS, int $WEPGl, int $fncAS, int $U1Feq) : string
    {
        $ow08Z = ltrim($xt6u5, '@');
        return "v2/watermark/{$ow08Z}/{$bvCsS}x{$WEPGl}_{$fncAS}x{$U1Feq}/text_watermark.png";
    }
    private function mS19YGRQH6q($xt6u5, int $bvCsS, float $emN4T, float $GOvRp) : array
    {
        goto ha3a6;
        GvjFH:
        if (!($GOvRp > 1)) {
            goto fZb94;
        }
        goto dFo1Y;
        Oxvwz:
        fZb94:
        goto iGy9I;
        lqDeE:
        return [(int) $vJGc7, $vJGc7 * strlen($NXTBc) / 1.8, $NXTBc];
        goto Oxvwz;
        ha3a6:
        $NXTBc = '@' . $xt6u5;
        goto mhmXd;
        iGy9I:
        $vJGc7 = 1 / $GOvRp * $LNPUA / strlen($NXTBc);
        goto vkbbg;
        mhmXd:
        $LNPUA = (int) ($bvCsS * $emN4T);
        goto GvjFH;
        vkbbg:
        return [(int) $vJGc7, $LNPUA, $NXTBc];
        goto TjUD2;
        dFo1Y:
        $vJGc7 = $LNPUA / (strlen($NXTBc) * 0.8);
        goto lqDeE;
        TjUD2:
    }
}
