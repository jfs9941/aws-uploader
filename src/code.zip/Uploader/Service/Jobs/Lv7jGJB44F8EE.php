<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Encoder\Ag7BVyy9gBS3K;
use Jfs\Uploader\Encoder\G2VgYaXfgj3vR;
use Jfs\Uploader\Encoder\ZgEcV5Ek5Li7G;
use Jfs\Uploader\Encoder\DMUpLei7KzwsT;
use Jfs\Uploader\Encoder\B5vx2QdfNEBBj;
use Jfs\Uploader\Encoder\F6FOYfmciBNIA;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Jfs\Uploader\Service\Jobs\P2jUKJAF2hP53;
use Jfs\Uploader\Service\Jobs\Fqn9mxOf7ZTno;
use Jfs\Uploader\Service\VjtcOzJCF9Hx7;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class Lv7jGJB44F8EE implements MediaEncodeJobInterface
{
    private $pKUHV;
    private $hYphi;
    private $wEVdN;
    private $VEFSL;
    private $GpRfX;
    public function __construct(string $drKb4, $zuNM5, $dzspH, $ukBzg, $lGHXf)
    {
        goto t9dCj;
        Q0wWE:
        $this->GpRfX = $lGHXf;
        goto ATWZ2;
        U5Lcb:
        $this->VEFSL = $ukBzg;
        goto Q0wWE;
        oWYBx:
        $this->wEVdN = $dzspH;
        goto U5Lcb;
        t9dCj:
        $this->pKUHV = $drKb4;
        goto xJhyQ;
        xJhyQ:
        $this->hYphi = $zuNM5;
        goto oWYBx;
        ATWZ2:
    }
    public function encode(string $hOWbX, string $R6W2J, $ADC60 = true) : void
    {
        goto tE0O0;
        ejT_1:
        ini_set('memory_limit', '-1');
        goto m67zh;
        m67zh:
        try {
            goto kaIMn;
            zMJM7:
            if (!$Iweso) {
                goto VRAqx;
            }
            goto d0cce;
            arIPK:
            $hOWbX = $hY2O_->mXMigP37ith($this->mgI6fv4JSfv($ZtI9P, $ADC60));
            goto PlqXY;
            scIIH:
            $sIm70 = $ZtI9P->height();
            goto NpvR_;
            yHari:
            $hY2O_ = $hY2O_->mG8TwqJMYYe($Z46C9);
            goto n7mGj;
            nmej3:
            VRAqx:
            goto VzMX8;
            PhbH7:
            if (!$ZtI9P->getAttribute('aws_media_converter_job_id')) {
                goto kbjsD;
            }
            goto i8_qz;
            n7mGj:
            B5PCs:
            goto PPYSL;
            erSOA:
            gFpph:
            goto PhbH7;
            RAWwm:
            $Z46C9 = new G2VgYaXfgj3vR('1080p', $K1_4A['width'], $K1_4A['height'], $ZtI9P->gLN6a ?? 30);
            goto RI2jQ;
            G0ZF2:
            $hY2O_ = app(B5vx2QdfNEBBj::class);
            goto mxEpZ;
            PPYSL:
            bw3bE:
            goto kYplh;
            xlZ6A:
            if (!$this->m5edBojVtMV($w0IG6, $sIm70)) {
                goto B5PCs;
            }
            goto zQ4H3;
            u1CZN:
            $IyowZ = new G2VgYaXfgj3vR('original', $w0IG6, $sIm70, $ZtI9P->gLN6a ?? 30);
            goto KDY3i;
            PlqXY:
            $ZtI9P->update(['aws_media_converter_job_id' => $hOWbX]);
            goto o6LUm;
            Z0HJ3:
            Log::info("Set 1080p resolution for Job", ['width' => $K1_4A['width'], 'height' => $K1_4A['height'], 'originalWidth' => $w0IG6, 'originalHeight' => $sIm70]);
            goto RAWwm;
            f3uqL:
            $Z46C9 = $Z46C9->mx4kaOzrVgN($Iweso);
            goto iEdGC;
            iEdGC:
            lMEGh:
            goto yHari;
            d0cce:
            $IyowZ = $IyowZ->mx4kaOzrVgN($Iweso);
            goto nmej3;
            Lq9m9:
            return;
            goto R0ykW;
            RI2jQ:
            $Iweso = $this->miIUumlWmZx($JpnD6, $u6wnM->mrMxekbVqKL((int) $K1_4A['width'], (int) $K1_4A['height'], $R6W2J));
            goto TPSsb;
            zQ4H3:
            $K1_4A = $this->mI0F35CDuFX($w0IG6, $sIm70);
            goto Z0HJ3;
            NpvR_:
            $k3IRq = $this->mHTF8ZHpQ2c($ZtI9P);
            goto AkOcx;
            kYplh:
            Log::info("Set thumbnail for HS7SZ3rYPI80t Job", ['videoId' => $ZtI9P->getAttribute('id'), 'duration' => $ZtI9P->getAttribute('duration')]);
            goto bLniL;
            Z8ueZ:
            $w0IG6 = $ZtI9P->width();
            goto scIIH;
            KDY3i:
            $UHzoy = app(ZgEcV5Ek5Li7G::class);
            goto gCYah;
            TUkpe:
            $u6wnM = new Fqn9mxOf7ZTno($this->VEFSL, $this->GpRfX, $this->wEVdN, $this->hYphi);
            goto lKGdC;
            PlwAQ:
            $JpnD6 = app(VjtcOzJCF9Hx7::class);
            goto TUkpe;
            lKGdC:
            $Iweso = $this->miIUumlWmZx($JpnD6, $u6wnM->mrMxekbVqKL($ZtI9P->width(), $ZtI9P->height(), $R6W2J));
            goto zMJM7;
            LOCF3:
            if (!($ZtI9P->driver != NZ0k4EM0XOGE7::S3)) {
                goto gFpph;
            }
            goto Zd5JO;
            aDFZx:
            $hY2O_ = $hY2O_->mGSvlz6oNpE($N07Z2);
            goto arIPK;
            ubGuN:
            if (!($w0IG6 && $sIm70)) {
                goto bw3bE;
            }
            goto xlZ6A;
            bLniL:
            $N07Z2 = new Ag7BVyy9gBS3K($ZtI9P->getAttribute('duration') ?? 1, 2, $UHzoy->m0kOO0ha6Bj($ZtI9P));
            goto aDFZx;
            Wt8jL:
            $hY2O_->m6V9zGKlPxn($UHzoy->mCoC5vTxQn5($ZtI9P));
            goto ubGuN;
            gCYah:
            $hY2O_->m6V9zGKlPxn($UHzoy->mCoC5vTxQn5($ZtI9P));
            goto PlwAQ;
            Zd5JO:
            throw new MediaConverterException("HS7SZ3rYPI80t {$ZtI9P->id} is not S3 driver value = {$ZtI9P->driver}");
            goto erSOA;
            AkOcx:
            Log::info("Set input video for Job", ['s3Uri' => $k3IRq]);
            goto G0ZF2;
            i8_qz:
            Log::info("HS7SZ3rYPI80t already has Media Converter Job ID, skip encoding", ['fileId' => $hOWbX, 'jobId' => $ZtI9P->getAttribute('aws_media_converter_job_id')]);
            goto Lq9m9;
            mxEpZ:
            $hY2O_ = $hY2O_->meenyFpkvLb(new DMUpLei7KzwsT($k3IRq));
            goto u1CZN;
            Oj9Iw:
            Assert::isInstanceOf($ZtI9P, HS7SZ3rYPI80t::class);
            goto LOCF3;
            TPSsb:
            if (!$Iweso) {
                goto lMEGh;
            }
            goto f3uqL;
            kaIMn:
            $ZtI9P = HS7SZ3rYPI80t::findOrFail($hOWbX);
            goto Oj9Iw;
            R0ykW:
            kbjsD:
            goto Z8ueZ;
            VzMX8:
            $hY2O_->mG8TwqJMYYe($IyowZ);
            goto Wt8jL;
            o6LUm:
        } catch (\Exception $qeKgz) {
            goto LeeK3;
            io6an:
            return;
            goto daPM6;
            bf4kx:
            Sentry::captureException($qeKgz);
            goto io6an;
            LeeK3:
            Log::warning("HS7SZ3rYPI80t has been deleted, discard it", ['fileId' => $hOWbX, 'err' => $qeKgz->getMessage()]);
            goto bf4kx;
            daPM6:
        }
        goto rn9bU;
        tE0O0:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $hOWbX]);
        goto ejT_1;
        rn9bU:
    }
    private function mgI6fv4JSfv(HS7SZ3rYPI80t $ZtI9P, $ADC60) : bool
    {
        goto E4R3G;
        g94FC:
        switch (true) {
            case $ZtI9P->width() * $ZtI9P->height() >= 1920 * 1080 && $ZtI9P->width() * $ZtI9P->height() < 2560 * 1440:
                return $VNFJX > 30 * 60;
            case $ZtI9P->width() * $ZtI9P->height() >= 2560 * 1440 && $ZtI9P->width() * $ZtI9P->height() < 3840 * 2160:
                return $VNFJX > 15 * 60;
            case $ZtI9P->width() * $ZtI9P->height() >= 3840 * 2160:
                return $VNFJX > 10 * 60;
            default:
                return false;
        }
        goto M4Tx3;
        E4R3G:
        if ($ADC60) {
            goto iry4c;
        }
        goto pMMtr;
        rQevN:
        iry4c:
        goto wx7fy;
        L_6gL:
        nkWFz:
        goto sst54;
        pMMtr:
        return false;
        goto rQevN;
        wx7fy:
        $VNFJX = (int) round($ZtI9P->getAttribute('duration') ?? 0);
        goto g94FC;
        M4Tx3:
        o1QTO:
        goto L_6gL;
        sst54:
    }
    private function miIUumlWmZx(VjtcOzJCF9Hx7 $JpnD6, string $UoeVh) : ?F6FOYfmciBNIA
    {
        goto qpYwl;
        ve0TF:
        Log::info("Resolve watermark for job with url", ['url' => $UoeVh, 'uri' => $TP05Q]);
        goto zZodw;
        eg0aj:
        return null;
        goto PYl_F;
        qhNMm:
        return new F6FOYfmciBNIA($TP05Q, 0, 0, null, null);
        goto T2wRT;
        zZodw:
        if (!$TP05Q) {
            goto u2PCk;
        }
        goto qhNMm;
        T2wRT:
        u2PCk:
        goto eg0aj;
        qpYwl:
        $TP05Q = $JpnD6->mvgEw85RtYY($UoeVh);
        goto ve0TF;
        PYl_F:
    }
    private function m5edBojVtMV(int $w0IG6, int $sIm70) : bool
    {
        return $w0IG6 * $sIm70 > 1.5 * (1920 * 1080);
    }
    private function mI0F35CDuFX(int $w0IG6, int $sIm70) : array
    {
        $EkqER = new P2jUKJAF2hP53($w0IG6, $sIm70);
        return $EkqER->mYqJat252DA();
    }
    private function mHTF8ZHpQ2c(GGOMDClEFMcsH $FX5Wq) : string
    {
        goto kQsDM;
        ZZJTV:
        T2mlA:
        goto evbpG;
        evbpG:
        return $this->hYphi->url($FX5Wq->filename);
        goto RD8sG;
        kQsDM:
        if (!($FX5Wq->driver == NZ0k4EM0XOGE7::S3)) {
            goto T2mlA;
        }
        goto a37MU;
        a37MU:
        return 's3://' . $this->pKUHV . '/' . $FX5Wq->filename;
        goto ZZJTV;
        RD8sG:
    }
}
