<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
class VxYi7ztJzQrYh implements DownloadToLocalJobInterface
{
    private $Vhcrn;
    private $riMoE;
    public function __construct($Klx1U, $BP_p5)
    {
        $this->Vhcrn = $Klx1U;
        $this->riMoE = $BP_p5;
    }
    public function download(string $mfjeD) : void
    {
        goto AApJH;
        T0rJU:
        $this->riMoE->put($rQ18B->getLocation(), $this->Vhcrn->get($rQ18B->getLocation()));
        goto KfXTh;
        AApJH:
        $rQ18B = DsyQbNiy8VgJG::findOrFail($mfjeD);
        goto UIG4c;
        IXnuR:
        return;
        goto A3343;
        UIG4c:
        Log::info("Start download file to local", ['fileId' => $mfjeD, 'filename' => $rQ18B->getLocation()]);
        goto LaW_q;
        A3343:
        guxga:
        goto T0rJU;
        LaW_q:
        if (!$this->riMoE->exists($rQ18B->getLocation())) {
            goto guxga;
        }
        goto IXnuR;
        KfXTh:
    }
}
