<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use InvalidArgumentException;
class ZjpvMqzM69PB5
{
    private $EyruC;
    private $TqyXt;
    public function __construct(int $klWYS, int $xcfOa)
    {
        goto z1uUy;
        z1uUy:
        if (!($klWYS <= 0)) {
            goto o_1l0;
        }
        goto ePF1x;
        j2IWl:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Ah9Ka;
        ePF1x:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto gp6hR;
        gp6hR:
        o_1l0:
        goto CuZsE;
        CuZsE:
        if (!($xcfOa <= 0)) {
            goto o6QPN;
        }
        goto j2IWl;
        gh4TM:
        $this->EyruC = $klWYS;
        goto qAaqN;
        qAaqN:
        $this->TqyXt = $xcfOa;
        goto iPLUg;
        Ah9Ka:
        o6QPN:
        goto gh4TM;
        iPLUg:
    }
    private static function m9DL5qhSe3C($v76iO, string $Nj8Ol = 'floor') : int
    {
        goto UL2XL;
        FtjpV:
        V435I:
        goto TOvTL;
        UL2XL:
        if (!(is_int($v76iO) && $v76iO % 2 === 0)) {
            goto DvUVK;
        }
        goto oMVk3;
        TOvTL:
        SUp4v:
        goto i9cRl;
        oMVk3:
        return $v76iO;
        goto qmnqa;
        Ob7U8:
        XjPDH:
        goto njoP7;
        Ou2Fg:
        if (!(is_float($v76iO) && $v76iO == floor($v76iO) && (int) $v76iO % 2 === 0)) {
            goto XjPDH;
        }
        goto hUSMt;
        njoP7:
        switch (strtolower($Nj8Ol)) {
            case 'ceil':
                return (int) (ceil($v76iO / 2) * 2);
            case 'round':
                return (int) (round($v76iO / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($v76iO / 2) * 2);
        }
        goto FtjpV;
        hUSMt:
        return (int) $v76iO;
        goto Ob7U8;
        qmnqa:
        DvUVK:
        goto Ou2Fg;
        i9cRl:
    }
    public function m9Z9k3w3aSI(string $usKq4 = 'floor') : array
    {
        goto cUvnX;
        tohqc:
        $DX2Yn = $QqM6H;
        goto ycWfv;
        VOCpq:
        $SQ0zR = $this->EyruC * $eY1ZC;
        goto N5haM;
        pfMOc:
        HBXOc:
        goto m0gxS;
        Pby_Z:
        $foWYp = $QqM6H;
        goto JSw32;
        ILTvD:
        if ($this->EyruC >= $this->TqyXt) {
            goto hKvSF;
        }
        goto Pby_Z;
        Cghro:
        $DX2Yn = self::m9DL5qhSe3C(round($TIp2E), $usKq4);
        goto WP84x;
        rRndo:
        $TIp2E = $this->TqyXt * $eY1ZC;
        goto Cghro;
        iC86r:
        $DX2Yn = 2;
        goto pfMOc;
        ycWfv:
        $eY1ZC = $DX2Yn / $this->TqyXt;
        goto VOCpq;
        N5haM:
        $foWYp = self::m9DL5qhSe3C(round($SQ0zR), $usKq4);
        goto ts6Ik;
        j75Gn:
        if (!($DX2Yn < 2)) {
            goto HBXOc;
        }
        goto iC86r;
        DG5fW:
        $foWYp = 2;
        goto ztf2x;
        m0gxS:
        return ['width' => $foWYp, 'height' => $DX2Yn];
        goto Wc9m0;
        ztf2x:
        HYHT9:
        goto j75Gn;
        QOMZq:
        $foWYp = 0;
        goto cozMd;
        cozMd:
        $DX2Yn = 0;
        goto ILTvD;
        zfHgu:
        hKvSF:
        goto tohqc;
        JSw32:
        $eY1ZC = $foWYp / $this->EyruC;
        goto rRndo;
        WP84x:
        goto LLYC4;
        goto zfHgu;
        cUvnX:
        $QqM6H = 1080;
        goto QOMZq;
        fyytT:
        if (!($foWYp < 2)) {
            goto HYHT9;
        }
        goto DG5fW;
        ts6Ik:
        LLYC4:
        goto fyytT;
        Wc9m0:
    }
}
