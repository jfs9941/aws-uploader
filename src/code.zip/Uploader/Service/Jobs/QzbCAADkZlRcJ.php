<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Illuminate\Support\Facades\Log;
class QzbCAADkZlRcJ implements BlurVideoJobInterface
{
    const nYZzX = 15;
    const a4eBw = 500;
    const HGSWR = 500;
    private $e2JZZ;
    private $uiTOc;
    private $dwubH;
    public function __construct($yGjLo, $ATeSz, $VzPPJ)
    {
        goto MQOR1;
        MQOR1:
        $this->dwubH = $VzPPJ;
        goto wuhCU;
        sotNG:
        $this->e2JZZ = $yGjLo;
        goto nGqaX;
        wuhCU:
        $this->uiTOc = $ATeSz;
        goto sotNG;
        nGqaX:
    }
    public function blur(string $B_L9m) : void
    {
        goto n78KK;
        hXyBP:
        $this->dwubH->put($uzHJU->getAttribute('thumbnail'), $this->uiTOc->get($uzHJU->getAttribute('thumbnail')));
        goto X1jza;
        s2y0C:
        $j3ttF = $zCabx->width() / $zCabx->height();
        goto a9a8w;
        kzPX_:
        $qGbOo = $this->myWULYwVwzq($uzHJU);
        goto MpjWy;
        HfBi_:
        $zCabx->blur(self::nYZzX);
        goto kzPX_;
        Lh6zf:
        \Log::warning('Failed to set final permissions on image file: ' . $L_ixi);
        goto iyVuB;
        qjjbz:
        ini_set('memory_limit', '-1');
        goto ZKpMy;
        qAJ2X:
        $uzHJU->update(['preview' => $qGbOo]);
        goto l45ss;
        n78KK:
        Log::info("Blurring for video", ['videoID' => $B_L9m]);
        goto qjjbz;
        l45ss:
        DOxOK:
        goto FE54M;
        l_4m9:
        VpLoW:
        goto qAJ2X;
        f58R3:
        $this->uiTOc->put($qGbOo, $this->dwubH->get($qGbOo));
        goto RELRZ;
        RELRZ:
        unset($zCabx);
        goto ifAkH;
        iyVuB:
        throw new \Exception('Failed to set final permissions on image file: ' . $L_ixi);
        goto l_4m9;
        ifAkH:
        if (chmod($L_ixi, 0664)) {
            goto VpLoW;
        }
        goto Lh6zf;
        a9a8w:
        $zCabx->resize(self::a4eBw, self::HGSWR / $j3ttF);
        goto HfBi_;
        xz838:
        $zCabx->save($L_ixi);
        goto f58R3;
        X1jza:
        $zCabx = $this->e2JZZ->call($this, $this->dwubH->path($uzHJU->getAttribute('thumbnail')));
        goto s2y0C;
        MpjWy:
        $L_ixi = $this->dwubH->path($qGbOo);
        goto xz838;
        ZKpMy:
        $uzHJU = U9HMl0N8dP0ZH::findOrFail($B_L9m);
        goto UbyQV;
        UbyQV:
        if (!$uzHJU->getAttribute('thumbnail')) {
            goto DOxOK;
        }
        goto hXyBP;
        FE54M:
    }
    private function myWULYwVwzq(X5WvqPHlZPq50 $RvlqW) : string
    {
        goto OtEAd;
        qTSrT:
        return $WeJv6 . $RvlqW->getFilename() . '.jpg';
        goto Zbwja;
        vXKne:
        $WeJv6 = dirname($dTJxl) . '/preview/';
        goto OtGCm;
        OtGCm:
        if ($this->dwubH->exists($WeJv6)) {
            goto tlLVt;
        }
        goto QBUb4;
        QBUb4:
        $this->dwubH->makeDirectory($WeJv6, 0755, true);
        goto RbkJh;
        RbkJh:
        tlLVt:
        goto qTSrT;
        OtEAd:
        $dTJxl = $RvlqW->getLocation();
        goto vXKne;
        Zbwja:
    }
}
