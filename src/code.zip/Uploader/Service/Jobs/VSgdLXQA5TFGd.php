<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class VSgdLXQA5TFGd implements GenerateThumbnailForVideoInterface
{
    private $ktECr;
    public function __construct($YdBrf)
    {
        $this->ktECr = $YdBrf;
    }
    public function generate(string $JTwN4) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $JTwN4);
        $this->ktECr->createThumbnail($JTwN4);
    }
}
