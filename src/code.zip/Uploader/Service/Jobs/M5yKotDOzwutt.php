<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
class M5yKotDOzwutt implements BlurJobInterface
{
    const Eawhs = 15;
    const snXAI = 500;
    const mcq5p = 500;
    private $UVc7_;
    private $D9Jo8;
    private $s3l3u;
    public function __construct($h1yz3, $v1Edp, $lKCQu)
    {
        goto eo1hQ;
        kbQb2:
        $this->UVc7_ = $h1yz3;
        goto LmlcE;
        M4bfm:
        $this->D9Jo8 = $v1Edp;
        goto kbQb2;
        eo1hQ:
        $this->s3l3u = $lKCQu;
        goto M4bfm;
        LmlcE:
    }
    public function blur(string $poSkG) : void
    {
        goto IHExM;
        n96nB:
        KCbuA:
        goto roJ5J;
        e2MB8:
        $vMMem = $VSbOm->width() / $VSbOm->height();
        goto vV6a3;
        dlNMt:
        $F1_0l->update(['preview' => $W4B_D]);
        goto uVCSC;
        X0D1s:
        HvpLK:
        goto dlNMt;
        roJ5J:
        $VSbOm = $this->UVc7_->call($this, $this->s3l3u->path($F1_0l->getLocation()));
        goto e2MB8;
        dvgKZ:
        ini_set('memory_limit', '-1');
        goto eLKcM;
        XgrOG:
        throw new \Exception('Failed to set final permissions on image file: ' . $KUEeo);
        goto X0D1s;
        XvFUA:
        if (chmod($KUEeo, 0664)) {
            goto HvpLK;
        }
        goto ik2cq;
        uPCkE:
        $NRv54 = $this->D9Jo8->get($F1_0l->filename);
        goto FwwaW;
        eLKcM:
        if (!($F1_0l->driver == L2PWLPeQEFi6U::S3 && !$this->s3l3u->exists($F1_0l->filename))) {
            goto KCbuA;
        }
        goto uPCkE;
        ik2cq:
        \Log::warning('Failed to set final permissions on image file: ' . $KUEeo);
        goto XgrOG;
        FwwaW:
        $this->s3l3u->put($F1_0l->filename, $NRv54);
        goto n96nB;
        IHExM:
        $F1_0l = KZbAaRxCqNUr3::findOrFail($poSkG);
        goto dvgKZ;
        I5i7g:
        $VSbOm->blur(self::Eawhs);
        goto FwkZs;
        Rx5QS:
        unset($VSbOm);
        goto XvFUA;
        vV6a3:
        $VSbOm->resize(self::snXAI, self::mcq5p / $vMMem);
        goto I5i7g;
        FwkZs:
        $W4B_D = $this->m779BRmUrdc($F1_0l);
        goto K88gL;
        K88gL:
        $KUEeo = $this->D9Jo8->put($W4B_D, $VSbOm->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Rx5QS;
        uVCSC:
    }
    private function m779BRmUrdc($uDbCt) : string
    {
        goto AxPfq;
        uGBfn:
        MLZ4L:
        goto W68l0;
        nftIC:
        $T2ESg = dirname($lT4E3) . '/preview/';
        goto ffZsw;
        ffZsw:
        if ($this->s3l3u->exists($T2ESg)) {
            goto MLZ4L;
        }
        goto fQ3uI;
        W68l0:
        return $T2ESg . $uDbCt->getFilename() . '.jpg';
        goto mYvLL;
        AxPfq:
        $lT4E3 = $uDbCt->getLocation();
        goto nftIC;
        fQ3uI:
        $this->s3l3u->makeDirectory($T2ESg, 0755, true);
        goto uGBfn;
        mYvLL:
    }
}
