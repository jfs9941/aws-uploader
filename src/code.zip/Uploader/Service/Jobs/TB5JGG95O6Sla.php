<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

class TB5JGG95O6Sla
{
    private $s97Dj;
    private $CMe9Y;
    private $kEfMA;
    private $FJZRi;
    public function __construct($VV0qO, $Yq15P, $FP6ih, $UEDUm)
    {
        goto f4ulC;
        wfRd9:
        $this->s97Dj = $VV0qO;
        goto HFRXs;
        Q0biY:
        $this->FJZRi = $UEDUm;
        goto wfRd9;
        f4ulC:
        $this->CMe9Y = $Yq15P;
        goto DCpzY;
        DCpzY:
        $this->kEfMA = $FP6ih;
        goto Q0biY;
        HFRXs:
    }
    public function mYCip0tFyl3(?int $BxXBR, ?int $w10Ma, string $yy69B, bool $Biz10 = false) : string
    {
        goto itI28;
        itI28:
        if (!($BxXBR === null || $w10Ma === null)) {
            goto Nzwn6;
        }
        goto ZcfLu;
        v_a3p:
        $this->FJZRi->put($KPnwr, $ulojh->stream('png'));
        goto cJz1h;
        YWz46:
        list($PUnzj, $LPpQu, $Lp4oY) = $this->m0S9uc4z8bK($yy69B, $BxXBR, $K4sRO, (float) $BxXBR / $w10Ma);
        goto NtAiE;
        cJz1h:
        $this->kEfMA->put($KPnwr, $ulojh->stream('png'));
        goto zFyQL;
        ubPLa:
        $ulojh->text($Lp4oY, $ENCNa, (int) $snB3W, function ($hod2k) use($PUnzj) {
            goto weMn7;
            YjPu1:
            $Cayy_ = (int) ($PUnzj * 1.2);
            goto ABkz5;
            V2RS1:
            $hod2k->valign('middle');
            goto ifWZM;
            weMn7:
            $hod2k->file(public_path($this->CMe9Y));
            goto YjPu1;
            vY4N2:
            $hod2k->color([185, 185, 185, 1]);
            goto V2RS1;
            ABkz5:
            $hod2k->size(max($Cayy_, 1));
            goto vY4N2;
            ifWZM:
            $hod2k->align('middle');
            goto v_cFC;
            v_cFC:
        });
        goto v_a3p;
        ZcfLu:
        throw new \RuntimeException("AvisbyD0IE5xq dimensions are not available.");
        goto PLwHM;
        MmVIB:
        E2GFr:
        goto vcWPL;
        c7XiV:
        return $Biz10 ? $KPnwr : $this->kEfMA->url($KPnwr);
        goto MmVIB;
        NtAiE:
        $KPnwr = $this->mFTs246qnM4($Lp4oY, $BxXBR, $w10Ma, $LPpQu, $PUnzj);
        goto BSxFs;
        zFyQL:
        return $Biz10 ? $KPnwr : $this->kEfMA->url($KPnwr);
        goto pFv9K;
        lDXzA:
        BtiSU:
        goto x1AGd;
        BSxFs:
        if (!$this->kEfMA->exists($KPnwr)) {
            goto E2GFr;
        }
        goto c7XiV;
        sBDCR:
        $ENCNa -= $nIvl5 * 0.4;
        goto lDXzA;
        q4F3o:
        $nIvl5 = (int) ($ENCNa / 80);
        goto hc3NG;
        HtWFU:
        if (!($BxXBR > 1500)) {
            goto BtiSU;
        }
        goto sBDCR;
        u3UQd:
        $ENCNa = $BxXBR - $LPpQu;
        goto q4F3o;
        PLwHM:
        Nzwn6:
        goto hdsy2;
        vcWPL:
        $ulojh = $this->s97Dj->call($this, $BxXBR, $w10Ma);
        goto u3UQd;
        hdsy2:
        $K4sRO = 0.1;
        goto YWz46;
        x1AGd:
        $snB3W = $w10Ma - $PUnzj - 10;
        goto ubPLa;
        hc3NG:
        $ENCNa -= $nIvl5;
        goto HtWFU;
        pFv9K:
    }
    private function mFTs246qnM4(string $yy69B, int $BxXBR, int $w10Ma, int $PRnZH, int $VTWyR) : string
    {
        $FZoYE = ltrim($yy69B, '@');
        return "v2/watermark/{$FZoYE}/{$BxXBR}x{$w10Ma}_{$PRnZH}x{$VTWyR}/text_watermark.png";
    }
    private function m0S9uc4z8bK($yy69B, int $BxXBR, float $EmNSY, float $EUALP) : array
    {
        goto coJJb;
        fAaI0:
        $kX4yq = $LPpQu / (strlen($Lp4oY) * 0.8);
        goto tEACx;
        zhnFg:
        return [(int) $kX4yq, $LPpQu, $Lp4oY];
        goto DP6B3;
        kGocp:
        $LPpQu = (int) ($BxXBR * $EmNSY);
        goto DI5li;
        Dmzby:
        cSKTH:
        goto FP3pc;
        FP3pc:
        $kX4yq = 1 / $EUALP * $LPpQu / strlen($Lp4oY);
        goto zhnFg;
        coJJb:
        $Lp4oY = '@' . $yy69B;
        goto kGocp;
        DI5li:
        if (!($EUALP > 1)) {
            goto cSKTH;
        }
        goto fAaI0;
        tEACx:
        return [(int) $kX4yq, $kX4yq * strlen($Lp4oY) / 1.8, $Lp4oY];
        goto Dmzby;
        DP6B3:
    }
}
