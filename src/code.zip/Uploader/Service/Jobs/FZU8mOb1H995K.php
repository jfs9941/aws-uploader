<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
class FZU8mOb1H995K implements BlurVideoJobInterface
{
    const RwPcJ = 15;
    const vdsNB = 500;
    const cNKXz = 500;
    private $KbvBQ;
    private $RaPnW;
    private $FFBPk;
    public function __construct($twxgF, $hTkyv, $GHkBm)
    {
        goto Fa5U2;
        mup_H:
        $this->RaPnW = $hTkyv;
        goto Fz6vu;
        Fa5U2:
        $this->FFBPk = $GHkBm;
        goto mup_H;
        Fz6vu:
        $this->KbvBQ = $twxgF;
        goto i2KZY;
        i2KZY:
    }
    public function blur(string $UcmDx) : void
    {
        goto h2KIU;
        TvPfV:
        $WQYnm = $this->FFBPk->path($Ph2Eb);
        goto GURxb;
        z0sCp:
        \Log::warning('Failed to set final permissions on image file: ' . $WQYnm);
        goto jaCIf;
        SRUg5:
        if (chmod($WQYnm, 0664)) {
            goto bFSlj;
        }
        goto z0sCp;
        TGslF:
        $aVX8K = $IS6o1->width() / $IS6o1->height();
        goto LrAe6;
        GURxb:
        $IS6o1->save($WQYnm);
        goto cUWy0;
        Z3dzF:
        zldmJ:
        goto ozZcV;
        pTsOI:
        $IS6o1 = $this->KbvBQ->call($this, $this->FFBPk->path($j6caS->getAttribute('thumbnail')));
        goto TGslF;
        kP4ve:
        $j6caS = QdnSnf08v9RV7::findOrFail($UcmDx);
        goto zxUxa;
        W4fh_:
        $IS6o1->blur(self::RwPcJ);
        goto k139z;
        jaCIf:
        throw new \Exception('Failed to set final permissions on image file: ' . $WQYnm);
        goto L5uDm;
        L5uDm:
        bFSlj:
        goto lXF8e;
        PKqwR:
        ini_set('memory_limit', '-1');
        goto kP4ve;
        k139z:
        $Ph2Eb = $this->m6HH5P3T3sI($j6caS);
        goto TvPfV;
        h2KIU:
        Log::info("Blurring for video", ['videoID' => $UcmDx]);
        goto PKqwR;
        zxUxa:
        if (!$j6caS->getAttribute('thumbnail')) {
            goto zldmJ;
        }
        goto Vz4dE;
        Vz4dE:
        $this->FFBPk->put($j6caS->getAttribute('thumbnail'), $this->RaPnW->get($j6caS->getAttribute('thumbnail')));
        goto pTsOI;
        LrAe6:
        $IS6o1->resize(self::vdsNB, self::cNKXz / $aVX8K);
        goto W4fh_;
        cUWy0:
        $this->RaPnW->put($Ph2Eb, $this->FFBPk->get($Ph2Eb));
        goto mY1Dd;
        lXF8e:
        $j6caS->update(['preview' => $Ph2Eb]);
        goto Z3dzF;
        mY1Dd:
        $IS6o1->destroy();
        goto SRUg5;
        ozZcV:
    }
    private function m6HH5P3T3sI(DNmcAdktLJtqn $aoAFq) : string
    {
        goto fZdO6;
        LZ4Xi:
        CSLjq:
        goto sfqGU;
        sfqGU:
        return $cKRb7 . $aoAFq->getFilename() . '.jpg';
        goto lOSlA;
        LHNdm:
        $cKRb7 = dirname($eviRR) . '/preview/';
        goto K7Qem;
        fZdO6:
        $eviRR = $aoAFq->getLocation();
        goto LHNdm;
        K7Qem:
        if ($this->FFBPk->exists($cKRb7)) {
            goto CSLjq;
        }
        goto P2v12;
        P2v12:
        $this->FFBPk->makeDirectory($cKRb7, 0755, true);
        goto LZ4Xi;
        lOSlA:
    }
}
