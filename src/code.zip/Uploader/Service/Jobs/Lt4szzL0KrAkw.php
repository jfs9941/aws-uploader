<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class Lt4szzL0KrAkw
{
    private $GCW3Y;
    private $hDqRa;
    public function __construct(int $krMIv, int $EAG61)
    {
        goto t70z1;
        H5kU4:
        $this->hDqRa = $EAG61;
        goto TcmQI;
        t70z1:
        if (!($krMIv <= 0)) {
            goto oJ71g;
        }
        goto RrzXZ;
        GyT0I:
        $this->GCW3Y = $krMIv;
        goto H5kU4;
        QgGjN:
        oJ71g:
        goto kyXf0;
        LBw7E:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto Yd73T;
        kyXf0:
        if (!($EAG61 <= 0)) {
            goto TMyHr;
        }
        goto LBw7E;
        RrzXZ:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto QgGjN;
        Yd73T:
        TMyHr:
        goto GyT0I;
        TcmQI:
    }
    private static function mVovq6LnvKE($WMvet, string $dcqdt = 'floor') : int
    {
        goto ycZmI;
        lyEJM:
        WbFLk:
        goto Z1Rc7;
        VhH1g:
        switch (strtolower($dcqdt)) {
            case 'ceil':
                return (int) (ceil($WMvet / 2) * 2);
            case 'round':
                return (int) (round($WMvet / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($WMvet / 2) * 2);
        }
        goto naV3q;
        HbeNF:
        Sz7o0:
        goto VhH1g;
        UHXI4:
        ZK6Tp:
        goto DGNa7;
        cTf5i:
        return $WMvet;
        goto UHXI4;
        naV3q:
        TKMS3:
        goto lyEJM;
        UP5to:
        return (int) $WMvet;
        goto HbeNF;
        DGNa7:
        if (!(is_float($WMvet) && $WMvet == floor($WMvet) && (int) $WMvet % 2 === 0)) {
            goto Sz7o0;
        }
        goto UP5to;
        ycZmI:
        if (!(is_int($WMvet) && $WMvet % 2 === 0)) {
            goto ZK6Tp;
        }
        goto cTf5i;
        Z1Rc7:
    }
    public function mI6SGAwa9UG(string $xhcKF = 'floor') : array
    {
        goto AlpNg;
        pcmWk:
        Qpj0c:
        goto nZloc;
        NluKk:
        qEjSg:
        goto JXbuE;
        G8Zv2:
        $FwayP = $cs2pw / $this->hDqRa;
        goto w1LJv;
        noAIb:
        Z220t:
        goto LMAJ_;
        VBSSR:
        $cs2pw = 0;
        goto Q507k;
        okOPR:
        $nXYI7 = $this->hDqRa * $FwayP;
        goto e6Ovv;
        w1LJv:
        $OLUcn = $this->GCW3Y * $FwayP;
        goto NK4ob;
        EVCKq:
        $cs2pw = 2;
        goto pcmWk;
        SpJ4u:
        if (!($cs2pw < 2)) {
            goto Qpj0c;
        }
        goto EVCKq;
        e6Ovv:
        $cs2pw = self::mVovq6LnvKE(round($nXYI7), $xhcKF);
        goto vZxs8;
        vZxs8:
        goto Z220t;
        goto NluKk;
        AlpNg:
        $eqV8f = 1080;
        goto nvgey;
        w6Xwf:
        $FwayP = $uQjVc / $this->GCW3Y;
        goto okOPR;
        Q507k:
        if ($this->GCW3Y >= $this->hDqRa) {
            goto qEjSg;
        }
        goto tLyUn;
        tLyUn:
        $uQjVc = $eqV8f;
        goto w6Xwf;
        NK4ob:
        $uQjVc = self::mVovq6LnvKE(round($OLUcn), $xhcKF);
        goto noAIb;
        nZloc:
        return ['width' => $uQjVc, 'height' => $cs2pw];
        goto xOTRJ;
        LMAJ_:
        if (!($uQjVc < 2)) {
            goto U2RBb;
        }
        goto s1TvH;
        mL2jH:
        U2RBb:
        goto SpJ4u;
        JXbuE:
        $cs2pw = $eqV8f;
        goto G8Zv2;
        s1TvH:
        $uQjVc = 2;
        goto mL2jH;
        nvgey:
        $uQjVc = 0;
        goto VBSSR;
        xOTRJ:
    }
}
