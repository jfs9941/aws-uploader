<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class BDQtoSYw7RsgD
{
    private $cQzus;
    private $cZsgg;
    private $BfyCm;
    private $c5PSU;
    public function __construct($Iv4Wx, $gnZ_2, $ejImE, $Ape3_)
    {
        goto YYbAn;
        ek31J:
        $this->BfyCm = $ejImE;
        goto V5okJ;
        V5okJ:
        $this->c5PSU = $Ape3_;
        goto lK1Gq;
        lK1Gq:
        $this->cQzus = $Iv4Wx;
        goto ZMfW6;
        YYbAn:
        $this->cZsgg = $gnZ_2;
        goto ek31J;
        ZMfW6:
    }
    public function mepv8nGH5jL(?int $tp6F0, ?int $iNVXG, string $w91p_, bool $lffKU = false) : string
    {
        goto a6wNI;
        bHhUJ:
        if (!$this->BfyCm->exists($HyAAV)) {
            goto GJ1Xj;
        }
        goto OQFVF;
        jaS8u:
        $wNJLJ = (int) ($HSr36 / 80);
        goto tHjH1;
        geqBy:
        $rEal7 = $iNVXG - $pgEZL - 10;
        goto pV4Ek;
        l_oi3:
        list($pgEZL, $Zbjr5, $fZ3DO) = $this->ma2gDxj9h8W($w91p_, $tp6F0, $g3mg8, (float) $tp6F0 / $iNVXG);
        goto hnQy3;
        tHjH1:
        $HSr36 -= $wNJLJ;
        goto VoRII;
        F6iS3:
        $qKtXa = $this->cQzus->call($this, $tp6F0, $iNVXG);
        goto g958U;
        WOKZr:
        $g3mg8 = 0.1;
        goto l_oi3;
        g958U:
        $HSr36 = $tp6F0 - $Zbjr5;
        goto jaS8u;
        DCovy:
        lt81m:
        goto WOKZr;
        ywJeI:
        $HSr36 -= $wNJLJ * 0.4;
        goto feHh0;
        OQFVF:
        return $lffKU ? $HyAAV : $this->BfyCm->url($HyAAV);
        goto jlWW7;
        rPEQG:
        throw new \RuntimeException("IfBHv1AJhiIDu dimensions are not available.");
        goto DCovy;
        jlWW7:
        GJ1Xj:
        goto F6iS3;
        hnQy3:
        $HyAAV = $this->mw2ojuSKcNf($fZ3DO, $tp6F0, $iNVXG, $Zbjr5, $pgEZL);
        goto bHhUJ;
        R6xG3:
        return $lffKU ? $HyAAV : $this->BfyCm->url($HyAAV);
        goto zA1ex;
        nYOfw:
        $this->c5PSU->put($HyAAV, $qKtXa->stream('png'));
        goto j3Jwh;
        feHh0:
        IJj63:
        goto geqBy;
        VoRII:
        if (!($tp6F0 > 1500)) {
            goto IJj63;
        }
        goto ywJeI;
        a6wNI:
        if (!($tp6F0 === null || $iNVXG === null)) {
            goto lt81m;
        }
        goto rPEQG;
        j3Jwh:
        $this->BfyCm->put($HyAAV, $qKtXa->stream('png'));
        goto R6xG3;
        pV4Ek:
        $qKtXa->text($fZ3DO, $HSr36, (int) $rEal7, function ($ZwxkI) use($pgEZL) {
            goto zdPl5;
            zdPl5:
            $ZwxkI->file(public_path($this->cZsgg));
            goto P5ERV;
            Kh0MY:
            $ZwxkI->valign('middle');
            goto e6A3R;
            P5ERV:
            $eWLeS = (int) ($pgEZL * 1.2);
            goto gOs02;
            e6A3R:
            $ZwxkI->align('middle');
            goto ZhdDP;
            gOs02:
            $ZwxkI->size(max($eWLeS, 1));
            goto G24YX;
            G24YX:
            $ZwxkI->color([185, 185, 185, 1]);
            goto Kh0MY;
            ZhdDP:
        });
        goto nYOfw;
        zA1ex:
    }
    private function mw2ojuSKcNf(string $w91p_, int $tp6F0, int $iNVXG, int $oVUas, int $UR9K4) : string
    {
        $Ufny2 = ltrim($w91p_, '@');
        return "v2/watermark/{$Ufny2}/{$tp6F0}x{$iNVXG}_{$oVUas}x{$UR9K4}/text_watermark.png";
    }
    private function ma2gDxj9h8W($w91p_, int $tp6F0, float $IHrxk, float $e61mr) : array
    {
        goto FziT2;
        bz2rq:
        return [(int) $asnj6, $Zbjr5, $fZ3DO];
        goto K_XsK;
        GHFJw:
        return [(int) $asnj6, $asnj6 * strlen($fZ3DO) / 1.8, $fZ3DO];
        goto VWy_4;
        VWy_4:
        sHgiR:
        goto MBZHy;
        FziT2:
        $fZ3DO = '@' . $w91p_;
        goto XX8gt;
        wUSB4:
        if (!($e61mr > 1)) {
            goto sHgiR;
        }
        goto ESATi;
        MBZHy:
        $asnj6 = 1 / $e61mr * $Zbjr5 / strlen($fZ3DO);
        goto bz2rq;
        ESATi:
        $asnj6 = $Zbjr5 / (strlen($fZ3DO) * 0.8);
        goto GHFJw;
        XX8gt:
        $Zbjr5 = (int) ($tp6F0 * $IHrxk);
        goto wUSB4;
        K_XsK:
    }
}
