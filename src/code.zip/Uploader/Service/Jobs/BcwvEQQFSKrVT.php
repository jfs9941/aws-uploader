<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
class BcwvEQQFSKrVT implements BlurJobInterface
{
    const eSBnU = 15;
    const trREs = 500;
    const DSHY1 = 500;
    private $xI8aP;
    private $GQuun;
    private $Farqu;
    public function __construct($uIkIq, $Q0shJ, $MQQLd)
    {
        goto VU2AM;
        VU2AM:
        $this->Farqu = $MQQLd;
        goto iLtY4;
        pd1PR:
        $this->xI8aP = $uIkIq;
        goto n8IZx;
        iLtY4:
        $this->GQuun = $Q0shJ;
        goto pd1PR;
        n8IZx:
    }
    public function blur(string $eXur0) : void
    {
        goto OfCga;
        wfnvG:
        aBU6o:
        goto PW8qT;
        NIhaT:
        $Q0sMv = $this->mJKF51YZReG($Wd8o2);
        goto UDuxJ;
        UKq7G:
        throw new \Exception('Failed to set final permissions on image file: ' . $h31Qj);
        goto DlxuZ;
        DlxuZ:
        J2o8h:
        goto xqjPh;
        muz89:
        $CPHMS->blur(self::eSBnU);
        goto NIhaT;
        PW8qT:
        $CPHMS = $this->xI8aP->call($this, $this->Farqu->path($Wd8o2->getLocation()));
        goto ggwMg;
        cBjh0:
        $this->Farqu->put($Wd8o2->filename, $tvAcn);
        goto wfnvG;
        xqjPh:
        $Wd8o2->update(['preview' => $Q0sMv]);
        goto nNVFi;
        UDuxJ:
        $h31Qj = $this->Farqu->path($Q0sMv);
        goto vI7gv;
        oJncU:
        if (chmod($h31Qj, 0664)) {
            goto J2o8h;
        }
        goto ZxAdJ;
        F1nhH:
        $CPHMS->resize(self::trREs, self::DSHY1 / $RgaZf);
        goto muz89;
        x4W11:
        ini_set('memory_limit', '-1');
        goto No5F4;
        OfCga:
        $Wd8o2 = NBWuSM65HseqY::findOrFail($eXur0);
        goto x4W11;
        kEOMA:
        $tvAcn = $this->GQuun->get($Wd8o2->filename);
        goto cBjh0;
        vI7gv:
        $CPHMS->save($h31Qj);
        goto X5igJ;
        ZxAdJ:
        \Log::warning('Failed to set final permissions on image file: ' . $h31Qj);
        goto UKq7G;
        X5igJ:
        $CPHMS->destroy();
        goto oJncU;
        No5F4:
        if (!($Wd8o2->BlJMK == VCKF0xK25vLxq::S3 && !$this->Farqu->exists($Wd8o2->filename))) {
            goto aBU6o;
        }
        goto kEOMA;
        ggwMg:
        $RgaZf = $CPHMS->width() / $CPHMS->height();
        goto F1nhH;
        nNVFi:
    }
    private function mJKF51YZReG($cDHFV) : string
    {
        goto IUgPm;
        HVwjw:
        if ($this->Farqu->exists($jNq3M)) {
            goto VhpQx;
        }
        goto Gq96a;
        Gq96a:
        $this->Farqu->makeDirectory($jNq3M, 0755, true);
        goto rwOpL;
        i_pQl:
        $jNq3M = dirname($Y7TgX) . '/preview/';
        goto HVwjw;
        IUgPm:
        $Y7TgX = $cDHFV->getLocation();
        goto i_pQl;
        rwOpL:
        VhpQx:
        goto NTkGj;
        NTkGj:
        return $jNq3M . $cDHFV->getFilename() . '.jpg';
        goto Pkqmr;
        Pkqmr:
    }
}
