<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Service\Jobs\YQyGyJgebc6kw;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class CXK2bDGLYItsc implements WatermarkTextJobInterface
{
    private $bLQUI;
    private $uAKaW;
    private $qzWWz;
    private $YHwpp;
    private $j5MRz;
    public function __construct($xA3df, $X3Bm8, $ehLvI, $nkmCX, $UD0dL)
    {
        goto VdrWA;
        tpPpt:
        $this->j5MRz = $nkmCX;
        goto tZ8X1;
        tZ8X1:
        $this->qzWWz = $UD0dL;
        goto afo9x;
        gQUjm:
        $this->YHwpp = $ehLvI;
        goto tpPpt;
        afo9x:
        $this->uAKaW = $X3Bm8;
        goto FazNn;
        VdrWA:
        $this->bLQUI = $xA3df;
        goto gQUjm;
        FazNn:
    }
    public function putWatermark(string $ShXx2, string $gQ74Q) : void
    {
        goto Ax5Ub;
        vLpNp:
        ini_set('memory_limit', '-1');
        goto DiF_o;
        fQhIz:
        $yfGDI = memory_get_usage();
        goto os8kw;
        os8kw:
        $xdRdR = memory_get_peak_usage();
        goto RbCRw;
        RbCRw:
        Log::info("Adding watermark text to image", ['imageId' => $ShXx2]);
        goto vLpNp;
        DiF_o:
        try {
            goto cYHRY;
            TQAM5:
            unset($S1JNo);
            goto k1xhb;
            lDnEX:
            $lPyJj = $this->j5MRz->path($xixtT->getLocation());
            goto MfN3S;
            msKU_:
            vQXYa:
            goto kE7Rh;
            cYHRY:
            $xixtT = Vt3ybt0yfaPAa::findOrFail($ShXx2);
            goto MtvdT;
            wq8dc:
            Log::error("Vt3ybt0yfaPAa is not on local, might be deleted before put watermark", ['imageId' => $ShXx2]);
            goto wtO3_;
            OcX_d:
            ngnh8:
            goto lDnEX;
            wtO3_:
            return;
            goto OcX_d;
            jeJ97:
            $this->YHwpp->put($lPyJj, $S1JNo->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto TQAM5;
            k1xhb:
            if (chmod($lPyJj, 0664)) {
                goto vQXYa;
            }
            goto rmsqK;
            E0R5z:
            $this->mukYigekZQZ($S1JNo, $gQ74Q);
            goto jeJ97;
            MfN3S:
            $S1JNo = $this->bLQUI->call($this, $lPyJj);
            goto R6g3p;
            beg02:
            throw new \Exception('Failed to set final permissions on image file: ' . $lPyJj);
            goto msKU_;
            MtvdT:
            if ($this->j5MRz->exists($xixtT->getLocation())) {
                goto ngnh8;
            }
            goto wq8dc;
            R6g3p:
            $S1JNo->orient();
            goto E0R5z;
            rmsqK:
            \Log::warning('Failed to set final permissions on image file: ' . $lPyJj);
            goto beg02;
            kE7Rh:
        } catch (\Throwable $P5DL3) {
            goto DCIgj;
            Hhvmj:
            JiGHj:
            goto h2Ol0;
            BsrkL:
            Log::info("Vt3ybt0yfaPAa has been deleted, discard it", ['imageId' => $ShXx2]);
            goto zgxgr;
            zgxgr:
            return;
            goto Hhvmj;
            h2Ol0:
            Log::error("Vt3ybt0yfaPAa is not readable", ['imageId' => $ShXx2, 'error' => $P5DL3->getMessage()]);
            goto Ru7Mj;
            DCIgj:
            if (!$P5DL3 instanceof ModelNotFoundException) {
                goto JiGHj;
            }
            goto BsrkL;
            Ru7Mj:
        } finally {
            $w1aby = microtime(true);
            $u5HI9 = memory_get_usage();
            $LDlnt = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $ShXx2, 'execution_time_sec' => $w1aby - $NPFCL, 'memory_usage_mb' => ($u5HI9 - $yfGDI) / 1024 / 1024, 'peak_memory_usage_mb' => ($LDlnt - $xdRdR) / 1024 / 1024]);
        }
        goto HHE4g;
        Ax5Ub:
        $NPFCL = microtime(true);
        goto fQhIz;
        HHE4g:
    }
    private function mukYigekZQZ($S1JNo, $gQ74Q) : void
    {
        goto oLWuZ;
        oLWuZ:
        $Evdiw = $S1JNo->width();
        goto SA0cr;
        IT2AC:
        $MrpIx = new YQyGyJgebc6kw($this->uAKaW, $this->qzWWz, $this->YHwpp, $this->j5MRz);
        goto SttY_;
        VotN2:
        $DGp3y = $this->bLQUI->call($this, $this->j5MRz->path($IqIPw));
        goto in7so;
        SttY_:
        $IqIPw = $MrpIx->mzWhDzHAaay($Evdiw, $Brsit, $gQ74Q, true);
        goto aVjYk;
        in7so:
        $S1JNo->place($DGp3y, 'top-left', 0, 0, 30);
        goto LTOrn;
        aVjYk:
        $this->j5MRz->put($IqIPw, $this->YHwpp->get($IqIPw));
        goto VotN2;
        SA0cr:
        $Brsit = $S1JNo->height();
        goto IT2AC;
        LTOrn:
    }
}
