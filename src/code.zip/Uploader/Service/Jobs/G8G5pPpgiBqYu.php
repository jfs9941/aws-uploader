<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class G8G5pPpgiBqYu implements CompressJobInterface
{
    const oniMu = 60;
    private $KXch8;
    private $oBaPs;
    private $AlJXw;
    public function __construct($FeIAB, $paaZf, $PcD2s)
    {
        goto utZ6_;
        vG2Kl:
        $this->AlJXw = $PcD2s;
        goto KZ2WD;
        KZ2WD:
        $this->oBaPs = $paaZf;
        goto rYPKu;
        utZ6_:
        $this->KXch8 = $FeIAB;
        goto vG2Kl;
        rYPKu:
    }
    public function compress(string $JTwN4)
    {
        goto WjSTz;
        gFfgP:
        try {
            goto QDlgD;
            RGGFS:
            h_gNa:
            goto nr7gn;
            QDlgD:
            $a97TB = Z7LUL65CwqbbF::findOrFail($JTwN4);
            goto NUGPC;
            V49OO:
            if (!(strtolower($a97TB->getExtension()) === 'png' || strtolower($a97TB->getExtension()) === 'heic')) {
                goto h_gNa;
            }
            goto qTcXk;
            qTcXk:
            $a97TB = $this->meqxMhq6K00($a97TB, 'jpg');
            goto RGGFS;
            NUGPC:
            $Qq48z = $this->oBaPs->path($a97TB->getLocation());
            goto V49OO;
            nr7gn:
            try {
                goto IEIcn;
                aocBu:
                $this->mrMutHLP5Rc($Qq48z, $Z9jLr);
                goto W9UIl;
                IEIcn:
                $Z9jLr = $this->oBaPs->path(str_replace('.jpg', '.webp', $a97TB->getLocation()));
                goto aocBu;
                W9UIl:
                $this->meqxMhq6K00($a97TB, 'webp');
                goto myNhT;
                myNhT:
            } catch (\Exception $QtemZ) {
                goto Z62j7;
                Z62j7:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $JTwN4, 'error' => $QtemZ->getMessage()]);
                goto Qs1sz;
                rruok:
                $this->mCbLell6wC9($Qq48z, $Z9jLr);
                goto TsAOZ;
                Qs1sz:
                $Z9jLr = $this->oBaPs->path($a97TB->getLocation());
                goto rruok;
                TsAOZ:
            }
            goto qDQY9;
            qDQY9:
        } catch (\Throwable $QtemZ) {
            goto x7T1a;
            VhVlp:
            return;
            goto X5PyM;
            slkvG:
            Log::error("Failed to compress image", ['imageId' => $JTwN4, 'error' => $QtemZ->getMessage()]);
            goto feftW;
            X5PyM:
            ewRqe:
            goto slkvG;
            x7T1a:
            if (!$QtemZ instanceof ModelNotFoundException) {
                goto ewRqe;
            }
            goto Syfn5;
            Syfn5:
            Log::info("Z7LUL65CwqbbF has been deleted, discard it", ['imageId' => $JTwN4]);
            goto VhVlp;
            feftW:
        } finally {
            $ZCyht = microtime(true);
            $n3g31 = memory_get_usage();
            $b0QCz = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $JTwN4, 'execution_time_sec' => $ZCyht - $yvtjt, 'memory_usage_mb' => ($n3g31 - $cH3VP) / 1024 / 1024, 'peak_memory_usage_mb' => ($b0QCz - $iPamH) / 1024 / 1024]);
        }
        goto R7eYd;
        rybUU:
        $iPamH = memory_get_peak_usage();
        goto ziSQl;
        weoF1:
        $cH3VP = memory_get_usage();
        goto rybUU;
        WjSTz:
        $yvtjt = microtime(true);
        goto weoF1;
        ziSQl:
        Log::info("Compress image", ['imageId' => $JTwN4]);
        goto gFfgP;
        R7eYd:
    }
    private function mCbLell6wC9($Qq48z, $Z9jLr)
    {
        goto LOcrX;
        VrQdF:
        $uxqi9->orient()->toJpeg(self::oniMu)->save($Z9jLr);
        goto PAbwQ;
        LOcrX:
        $uxqi9 = $this->KXch8->call($this, $Qq48z);
        goto VrQdF;
        MY0PF:
        unset($uxqi9);
        goto X2QA5;
        PAbwQ:
        $this->AlJXw->put($Z9jLr, $uxqi9->toJpeg(self::oniMu), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto MY0PF;
        X2QA5:
    }
    private function mrMutHLP5Rc($Qq48z, $Z9jLr)
    {
        goto wsgEg;
        LiDA_:
        unset($uxqi9);
        goto Q0qXX;
        wQF4r:
        $uxqi9->orient()->toWebp(self::oniMu);
        goto KWxlB;
        wsgEg:
        $uxqi9 = $this->KXch8->call($this, $Qq48z);
        goto wQF4r;
        KWxlB:
        $this->AlJXw->put($Z9jLr, $uxqi9->toJpeg(self::oniMu), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto LiDA_;
        Q0qXX:
    }
    private function meqxMhq6K00($a97TB, $oBMq2)
    {
        goto vcHuu;
        vcHuu:
        $a97TB->setAttribute('type', $oBMq2);
        goto lU6Mg;
        lU6Mg:
        $a97TB->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$oBMq2}", $a97TB->getLocation()));
        goto G2_mg;
        m1pLv:
        return $a97TB;
        goto HIl7n;
        G2_mg:
        $a97TB->save();
        goto m1pLv;
        HIl7n:
    }
}
