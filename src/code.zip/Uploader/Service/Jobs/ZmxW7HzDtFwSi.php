<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Illuminate\Support\Facades\Log;
class ZmxW7HzDtFwSi implements BlurVideoJobInterface
{
    const Ekf6C = 15;
    const w5aME = 500;
    const rVeig = 500;
    private $VnheV;
    private $SxfKN;
    private $GmmTj;
    public function __construct($wUcGa, $DPWG1, $MYo5D)
    {
        goto CEEAj;
        XjGOz:
        $this->VnheV = $wUcGa;
        goto u2vfc;
        AFsFR:
        $this->SxfKN = $DPWG1;
        goto XjGOz;
        CEEAj:
        $this->GmmTj = $MYo5D;
        goto AFsFR;
        u2vfc:
    }
    public function blur(string $GMwD5) : void
    {
        goto RU0l_;
        eDThl:
        \Log::warning('Failed to set final permissions on image file: ' . $NtHgB);
        goto sd_4U;
        IqgR6:
        $Umpxv = RhdJGUi8FOLBJ::findOrFail($GMwD5);
        goto cllBj;
        YHTON:
        $dmeuh = $this->VnheV->call($this, $this->GmmTj->path($Umpxv->getAttribute('thumbnail')));
        goto eJQN5;
        ahDek:
        $Umpxv->update(['preview' => $itPqF]);
        goto I2xnq;
        FuSxG:
        $dmeuh->blur(self::Ekf6C);
        goto jIIlu;
        I2xnq:
        OqZdj:
        goto nmrwv;
        sd_4U:
        throw new \Exception('Failed to set final permissions on image file: ' . $NtHgB);
        goto ht_5W;
        jIIlu:
        $itPqF = $this->mTWuokivYSO($Umpxv);
        goto tCVw8;
        xiOg7:
        if (chmod($NtHgB, 0664)) {
            goto kj6ry;
        }
        goto eDThl;
        tCVw8:
        $NtHgB = $this->GmmTj->path($itPqF);
        goto utFte;
        sB3qp:
        ini_set('memory_limit', '-1');
        goto IqgR6;
        cI3rM:
        $this->GmmTj->put($Umpxv->getAttribute('thumbnail'), $this->SxfKN->get($Umpxv->getAttribute('thumbnail')));
        goto YHTON;
        ht_5W:
        kj6ry:
        goto ahDek;
        nDksO:
        $dmeuh->resize(self::w5aME, self::rVeig / $AXz2I);
        goto FuSxG;
        utFte:
        $dmeuh->save($NtHgB);
        goto Paybp;
        eJQN5:
        $AXz2I = $dmeuh->width() / $dmeuh->height();
        goto nDksO;
        RU0l_:
        Log::info("Blurring for video", ['videoID' => $GMwD5]);
        goto sB3qp;
        Paybp:
        $this->SxfKN->put($itPqF, $this->GmmTj->get($itPqF));
        goto WgnTJ;
        WgnTJ:
        unset($dmeuh);
        goto xiOg7;
        cllBj:
        if (!$Umpxv->getAttribute('thumbnail')) {
            goto OqZdj;
        }
        goto cI3rM;
        nmrwv:
    }
    private function mTWuokivYSO(Mty95KsoNkhJl $PUY_t) : string
    {
        goto pV3Vu;
        KSa8B:
        $this->GmmTj->makeDirectory($w6EkV, 0755, true);
        goto HNB1z;
        HNB1z:
        XeIGt:
        goto y0RWz;
        y0RWz:
        return $w6EkV . $PUY_t->getFilename() . '.jpg';
        goto xH0or;
        pV3Vu:
        $iTIh6 = $PUY_t->getLocation();
        goto ksPJ0;
        B6p8h:
        if ($this->GmmTj->exists($w6EkV)) {
            goto XeIGt;
        }
        goto KSa8B;
        ksPJ0:
        $w6EkV = dirname($iTIh6) . '/preview/';
        goto B6p8h;
        xH0or:
    }
}
