<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class TTxYktL1xl6sq implements GenerateThumbnailForVideoInterface
{
    private $HHBAY;
    public function __construct($TIah1)
    {
        $this->HHBAY = $TIah1;
    }
    public function generate(string $hOWbX) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $hOWbX);
        $this->HHBAY->createThumbnail($hOWbX);
    }
}
