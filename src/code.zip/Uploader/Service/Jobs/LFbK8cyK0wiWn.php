<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class LFbK8cyK0wiWn
{
    private $B3G_O;
    private $loW7J;
    private $bLZP5;
    private $ZPzJH;
    public function __construct($PqmeA, $gewHh, $C1By6, $G3exm)
    {
        goto bPTD8;
        gRMiz:
        $this->bLZP5 = $C1By6;
        goto lGVyt;
        lGVyt:
        $this->ZPzJH = $G3exm;
        goto SDXlH;
        bPTD8:
        $this->loW7J = $gewHh;
        goto gRMiz;
        SDXlH:
        $this->B3G_O = $PqmeA;
        goto LKHMj;
        LKHMj:
    }
    public function mjt3bIAGpxP(?int $ASgWt, ?int $ybj1g, string $gDswH, bool $afzvl = false) : string
    {
        goto mQyFp;
        hKTiX:
        $BI1UU = 0.1;
        goto tBL4u;
        sOWv0:
        b3oQw:
        goto C8ne9;
        q3YSn:
        $KlHaV->text($UmEGb, $BSO_t, (int) $gE8aH, function ($uF2NK) use($iy4dp) {
            goto cwpyL;
            LFqPY:
            $uF2NK->valign('middle');
            goto rViRq;
            rViRq:
            $uF2NK->align('middle');
            goto ZkHBX;
            gfbFq:
            $wTTXH = (int) ($iy4dp * 1.2);
            goto AQZo7;
            ZCPvF:
            $uF2NK->color([185, 185, 185, 1]);
            goto LFqPY;
            AQZo7:
            $uF2NK->size(max($wTTXH, 1));
            goto ZCPvF;
            cwpyL:
            $uF2NK->file(public_path($this->loW7J));
            goto gfbFq;
            ZkHBX:
        });
        goto MWUQ9;
        tBL4u:
        list($iy4dp, $fMO42, $UmEGb) = $this->mtKoiIKA9Jp($gDswH, $ASgWt, $BI1UU, (float) $ASgWt / $ybj1g);
        goto lh3Di;
        RhvDR:
        return $afzvl ? $iVcpi : $this->bLZP5->url($iVcpi);
        goto Tgf0A;
        bxxU_:
        if (!$this->bLZP5->exists($iVcpi)) {
            goto jUzIy;
        }
        goto KcnI6;
        KcnI6:
        return $afzvl ? $iVcpi : $this->bLZP5->url($iVcpi);
        goto mpGdu;
        XtOn4:
        throw new \RuntimeException("J7sRaWo8um3yO dimensions are not available.");
        goto KYy_N;
        h9MOd:
        $KlHaV = $this->B3G_O->call($this, $ASgWt, $ybj1g);
        goto a86jr;
        C8ne9:
        $gE8aH = $ybj1g - $iy4dp - 10;
        goto q3YSn;
        Xg1eA:
        $this->bLZP5->put($iVcpi, $KlHaV->stream('png'));
        goto RhvDR;
        mpGdu:
        jUzIy:
        goto h9MOd;
        MWUQ9:
        $this->ZPzJH->put($iVcpi, $KlHaV->stream('png'));
        goto Xg1eA;
        nWnz3:
        if (!($ASgWt > 1500)) {
            goto b3oQw;
        }
        goto DorXa;
        a86jr:
        $BSO_t = $ASgWt - $fMO42;
        goto UPkVl;
        KYy_N:
        bLoes:
        goto hKTiX;
        DorXa:
        $BSO_t -= $pNEzv * 0.4;
        goto sOWv0;
        UPkVl:
        $pNEzv = (int) ($BSO_t / 80);
        goto UKNpI;
        UKNpI:
        $BSO_t -= $pNEzv;
        goto nWnz3;
        mQyFp:
        if (!($ASgWt === null || $ybj1g === null)) {
            goto bLoes;
        }
        goto XtOn4;
        lh3Di:
        $iVcpi = $this->maBDeqUDnmV($UmEGb, $ASgWt, $ybj1g, $fMO42, $iy4dp);
        goto bxxU_;
        Tgf0A:
    }
    private function maBDeqUDnmV(string $gDswH, int $ASgWt, int $ybj1g, int $Fz6D_, int $uUTpd) : string
    {
        $sH9H6 = ltrim($gDswH, '@');
        return "v2/watermark/{$sH9H6}/{$ASgWt}x{$ybj1g}_{$Fz6D_}x{$uUTpd}/text_watermark.png";
    }
    private function mtKoiIKA9Jp($gDswH, int $ASgWt, float $Xg55k, float $j_mpB) : array
    {
        goto JG6PP;
        rjgSR:
        if (!($j_mpB > 1)) {
            goto zb1cU;
        }
        goto RNx9M;
        JG6PP:
        $UmEGb = '@' . $gDswH;
        goto AOuTT;
        KmpIx:
        return [(int) $MWszE, $fMO42, $UmEGb];
        goto XltfB;
        AOuTT:
        $fMO42 = (int) ($ASgWt * $Xg55k);
        goto rjgSR;
        RNx9M:
        $MWszE = $fMO42 / (strlen($UmEGb) * 0.8);
        goto NmgnB;
        geREF:
        $MWszE = 1 / $j_mpB * $fMO42 / strlen($UmEGb);
        goto KmpIx;
        gKVf2:
        zb1cU:
        goto geREF;
        NmgnB:
        return [(int) $MWszE, $MWszE * strlen($UmEGb) / 1.8, $UmEGb];
        goto gKVf2;
        XltfB:
    }
}
