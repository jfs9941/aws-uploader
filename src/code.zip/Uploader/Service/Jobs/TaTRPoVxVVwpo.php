<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
class TaTRPoVxVVwpo implements BlurVideoJobInterface
{
    const al9g6 = 15;
    const xzxfg = 500;
    const H9ZQ9 = 500;
    private $aQPLw;
    private $ifs25;
    private $gq_yF;
    public function __construct($fhNRF, $PQlIa, $gBW_k)
    {
        goto JBg_4;
        JBg_4:
        $this->gq_yF = $gBW_k;
        goto b06dY;
        CaGu2:
        $this->aQPLw = $fhNRF;
        goto oUpVd;
        b06dY:
        $this->ifs25 = $PQlIa;
        goto CaGu2;
        oUpVd:
    }
    public function blur(string $PV4mw) : void
    {
        goto XWOgZ;
        Q0jT9:
        $RRdJW = CSQMvXC33KbbS::findOrFail($PV4mw);
        goto BmN5R;
        Dfy4O:
        $RRdJW->update(['preview' => $rnJia]);
        goto DY9WY;
        ljvVm:
        $SYKC9->resize(self::xzxfg, self::H9ZQ9 / $Ubt2R);
        goto B1tCD;
        B1tCD:
        $SYKC9->blur(self::al9g6);
        goto f6sQI;
        mPXii:
        $SYKC9 = $this->aQPLw->call($this, $this->gq_yF->path($RRdJW->getAttribute('thumbnail')));
        goto ZkV0Z;
        zQnJv:
        $this->ifs25->put($rnJia, $this->gq_yF->get($rnJia));
        goto B4VEd;
        BmN5R:
        if (!$RRdJW->getAttribute('thumbnail')) {
            goto a6KUz;
        }
        goto L4c0H;
        hJXDj:
        \Log::warning('Failed to set final permissions on image file: ' . $AZy50);
        goto lFWoP;
        L4c0H:
        $this->gq_yF->put($RRdJW->getAttribute('thumbnail'), $this->ifs25->get($RRdJW->getAttribute('thumbnail')));
        goto mPXii;
        zz_29:
        laD1v:
        goto Dfy4O;
        XWOgZ:
        Log::info("Blurring for video", ['videoID' => $PV4mw]);
        goto rCu0G;
        lFWoP:
        throw new \Exception('Failed to set final permissions on image file: ' . $AZy50);
        goto zz_29;
        DY9WY:
        a6KUz:
        goto kwy2K;
        pCbW4:
        $AZy50 = $this->gq_yF->path($rnJia);
        goto j1IWI;
        ZkV0Z:
        $Ubt2R = $SYKC9->width() / $SYKC9->height();
        goto ljvVm;
        rCu0G:
        ini_set('memory_limit', '-1');
        goto Q0jT9;
        B4VEd:
        $SYKC9->destroy();
        goto sks56;
        sks56:
        if (chmod($AZy50, 0664)) {
            goto laD1v;
        }
        goto hJXDj;
        j1IWI:
        $SYKC9->save($AZy50);
        goto zQnJv;
        f6sQI:
        $rnJia = $this->mEdD9zw0sfJ($RRdJW);
        goto pCbW4;
        kwy2K:
    }
    private function mEdD9zw0sfJ(J5Mj1pjSQG0SH $k5pKN) : string
    {
        goto FmLN_;
        gXZci:
        $H0xYM = dirname($sEueW) . '/preview/';
        goto EGIbl;
        ncgLR:
        ISKJl:
        goto ftOCH;
        EGIbl:
        if ($this->gq_yF->exists($H0xYM)) {
            goto ISKJl;
        }
        goto Zc5rp;
        ftOCH:
        return $H0xYM . $k5pKN->getFilename() . '.jpg';
        goto OusT2;
        FmLN_:
        $sEueW = $k5pKN->getLocation();
        goto gXZci;
        Zc5rp:
        $this->gq_yF->makeDirectory($H0xYM, 0755, true);
        goto ncgLR;
        OusT2:
    }
}
