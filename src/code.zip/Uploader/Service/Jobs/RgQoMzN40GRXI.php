<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Jfs\Exposed\Jobs\CompressJobInterface; use Illuminate\Database\Eloquent\ModelNotFoundException; use Illuminate\Support\Facades\Log; use Jfs\Uploader\Core\NoqRziJe9G7Nn; class RgQoMzN40GRXI implements CompressJobInterface { const R_sj1 = 80; private $sCaL6; private $BQQPt; public function __construct($H2ScN, $EpDSi) { $this->sCaL6 = $H2ScN; $this->BQQPt = $EpDSi; } public function compress(string $hJXEE) { Log::info("Compress image", ['imageId' => $hJXEE]); try { goto u6mDt; u6mDt: $ULD7R = NoqRziJe9G7Nn::findOrFail($hJXEE); goto dvfd2; nXNpK: $ULD7R->save(); goto bCQR1; IiGMp: $ofkUr->destroy(); goto xlX93; d9WcL: $ULD7R->setAttribute('type', 'jpg'); goto repDt; rzfVK: $ofkUr->orientate(); goto FqgG6; repDt: $ULD7R->setAttribute('filename', str_replace('.png', '.jpg', $ULD7R->getLocation())); goto nXNpK; oZLgC: $ofkUr = $this->sCaL6->call($this, $XcbFL); goto rzfVK; FqgG6: $ofkUr->save($H3X23, self::R_sj1); goto IiGMp; ggAAm: if (!($ULD7R->getExtension() === 'png')) { goto byT66; } goto d9WcL; bCQR1: byT66: goto mebdm; dvfd2: $XcbFL = $this->BQQPt->path($ULD7R->getLocation()); goto ggAAm; mebdm: $H3X23 = $this->BQQPt->path($ULD7R->getLocation()); goto oZLgC; xlX93: } catch (ModelNotFoundException) { Log::info("NoqRziJe9G7Nn has been deleted, discard it", ['imageId' => $hJXEE]); } } }
