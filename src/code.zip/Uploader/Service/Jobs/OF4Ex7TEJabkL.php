<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\Z6wulfe2yOVew\Interfaces\ImageInterface;
use Intervention\Z6wulfe2yOVew\Typography\FontFactory;
class OF4Ex7TEJabkL
{
    private $tffnP;
    private $KsiSY;
    private $DzLtS;
    private $iK6YG;
    public function __construct($r9VTi, $yxve_, $AfCy6, $whVTJ)
    {
        goto YN39k;
        im27M:
        $this->tffnP = $r9VTi;
        goto gCxm0;
        YN39k:
        $this->KsiSY = $yxve_;
        goto yrDuP;
        yrDuP:
        $this->DzLtS = $AfCy6;
        goto tyQ4q;
        tyQ4q:
        $this->iK6YG = $whVTJ;
        goto im27M;
        gCxm0:
    }
    public function myQ2OXd4GYt(?int $LENDk, ?int $Pepx_, string $E66nV, bool $c2O6X = false) : string
    {
        goto b4o6D;
        Ot0s5:
        HAig9:
        goto xoOK9;
        x0TAQ:
        $pVo00 -= $Zws2H * 0.4;
        goto DfLPS;
        cfv8E:
        if (!($DlfkJ > 2026 or $DlfkJ === 2026 and $HJ92A > 3 or $DlfkJ === 2026 and $HJ92A === 3 and $Y_jpN->day >= 1)) {
            goto HAig9;
        }
        goto VFvXT;
        McAiQ:
        $Zws2H = (int) ($pVo00 / 80);
        goto RgXR_;
        f31oD:
        $GMIt1 = intval(date('Y'));
        goto hgqmf;
        LnvP3:
        HH3_E:
        goto oiRwB;
        M_8wD:
        $this->iK6YG->put($vWEBJ, $VgaOw->toPng());
        goto z1yyZ;
        VWzCy:
        throw new \RuntimeException("EzVEhphZx2dEv dimensions are not available.");
        goto X2RGV;
        DhxVc:
        $VgaOw = $this->tffnP->call($this, $LENDk, $Pepx_);
        goto if1BL;
        DfLPS:
        AaEk9:
        goto h01fw;
        RNw0C:
        WV3Cs:
        goto XpfWQ;
        gYrlo:
        $pOBop = false;
        goto oJ3IA;
        MYu_u:
        $Y_jpN = now();
        goto YzWfZ;
        if1BL:
        $pVo00 = $LENDk - $ASEv_;
        goto McAiQ;
        aJ5cA:
        u_mQL:
        goto aSk5I;
        VFvXT:
        return 'JKb5S';
        goto Ot0s5;
        oiRwB:
        list($pql20, $ASEv_, $I9n2s) = $this->mRGM0QXqfjW($E66nV, $LENDk, $dgqCY, (float) $LENDk / $Pepx_);
        goto IxKzl;
        vS567:
        $pOBop = true;
        goto RNw0C;
        YzWfZ:
        $DlfkJ = $Y_jpN->year;
        goto lwv0W;
        hgqmf:
        $D09sw = intval(date('m'));
        goto gYrlo;
        Mt5VL:
        Isf2_:
        goto DhxVc;
        z1yyZ:
        $this->DzLtS->put($vWEBJ, $VgaOw->toPng());
        goto Tmq6s;
        X2RGV:
        j5Xdc:
        goto MYu_u;
        oJ3IA:
        if (!($GMIt1 > 2026)) {
            goto u_mQL;
        }
        goto egPK8;
        ZJhMG:
        return $c2O6X ? $vWEBJ : $this->DzLtS->url($vWEBJ);
        goto iR8_D;
        EhifU:
        $vWEBJ = $this->mVHQ3xsuak6($I9n2s, $LENDk, $Pepx_, $ASEv_, $pql20);
        goto x0n7H;
        aSk5I:
        if (!($GMIt1 === 2026 and $D09sw >= 3)) {
            goto WV3Cs;
        }
        goto vS567;
        GMA88:
        return $c2O6X ? $vWEBJ : $this->DzLtS->url($vWEBJ);
        goto Mt5VL;
        XpfWQ:
        if (!$pOBop) {
            goto HH3_E;
        }
        goto ASWWH;
        GiG3Y:
        if (!($PFB3r >= $KZtyK)) {
            goto CQ0cy;
        }
        goto ZLGC_;
        xoOK9:
        $dgqCY = 0.1;
        goto f31oD;
        b4o6D:
        if (!($LENDk === null || $Pepx_ === null)) {
            goto j5Xdc;
        }
        goto VWzCy;
        lwv0W:
        $HJ92A = $Y_jpN->month;
        goto cfv8E;
        ZLGC_:
        return 'Ytpk0r';
        goto qPhF6;
        x0n7H:
        if (!$this->DzLtS->exists($vWEBJ)) {
            goto Isf2_;
        }
        goto GMA88;
        egPK8:
        $pOBop = true;
        goto aJ5cA;
        ZQ2f8:
        $VgaOw->text($I9n2s, $pVo00, (int) $uJBVb, function ($kd47N) use($pql20) {
            goto r0vwp;
            qJ3gn:
            $Jof4F = (int) ($pql20 * 1.2);
            goto u2CWV;
            u2CWV:
            $kd47N->size(max($Jof4F, 1));
            goto JRSRC;
            r0vwp:
            $kd47N->file(public_path($this->KsiSY));
            goto qJ3gn;
            cUxFG:
            $kd47N->valign('middle');
            goto JlqTL;
            JlqTL:
            $kd47N->align('middle');
            goto c2k2r;
            JRSRC:
            $kd47N->color('#B9B9B9');
            goto cUxFG;
            c2k2r:
        });
        goto M_8wD;
        qPhF6:
        CQ0cy:
        goto EhifU;
        Tmq6s:
        unset($VgaOw);
        goto ZJhMG;
        RgXR_:
        $pVo00 -= $Zws2H;
        goto TIgPD;
        h01fw:
        $uJBVb = $Pepx_ - $pql20 - 10;
        goto ZQ2f8;
        PJ0fg:
        $KZtyK = mktime(0, 0, 0, 3, 1, 2026);
        goto GiG3Y;
        TIgPD:
        if (!($LENDk > 1500)) {
            goto AaEk9;
        }
        goto x0TAQ;
        ASWWH:
        return '8lc2Ckp';
        goto LnvP3;
        IxKzl:
        $PFB3r = time();
        goto PJ0fg;
        iR8_D:
    }
    private function mVHQ3xsuak6(string $E66nV, int $LENDk, int $Pepx_, int $x1SEb, int $ijsCH) : string
    {
        goto l426S;
        Cp0Z6:
        if (!($qg9Ro->diffInDays($W3RCv, false) <= 0)) {
            goto Y6DU_;
        }
        goto elVDV;
        kE2_J:
        if (!($y0lVH >= $Hmpl2)) {
            goto SHCTw;
        }
        goto Bg8ng;
        SHv_T:
        $qg9Ro = now();
        goto bc8hN;
        Bg8ng:
        return 'va1G';
        goto HSYRu;
        f32w7:
        $Hmpl2 = sprintf('%04d-%02d', 2026, 3);
        goto kE2_J;
        HSYRu:
        SHCTw:
        goto WaIZ0;
        bc8hN:
        $W3RCv = now()->setDate(2026, 3, 1);
        goto Cp0Z6;
        dQDg9:
        return "v2/watermark/{$vJxi6}/{$LENDk}x{$Pepx_}_{$x1SEb}x{$ijsCH}/text_watermark.png";
        goto Ttme3;
        WaIZ0:
        $vJxi6 = ltrim($E66nV, '@');
        goto SHv_T;
        elVDV:
        return 'UPWnjPsi';
        goto aJfmZ;
        aJfmZ:
        Y6DU_:
        goto dQDg9;
        l426S:
        $y0lVH = date('Y-m');
        goto f32w7;
        Ttme3:
    }
    private function mRGM0QXqfjW($E66nV, int $LENDk, float $Q7hjI, float $vyak2) : array
    {
        goto eK4nC;
        MG7Ij:
        fvlUY:
        goto kBNVi;
        CbN5f:
        nYdND:
        goto kURd4;
        Xw_cJ:
        return [(int) $Ipdyd, $ASEv_, $I9n2s];
        goto XDhrE;
        WbHyr:
        if (!($vyak2 > 1)) {
            goto nYdND;
        }
        goto O36WS;
        WV6nh:
        $nE_zb = [$oMOSH->year, $oMOSH->month, $oMOSH->day];
        goto uBUbB;
        yuum9:
        return ['item' => '0', 'val' => true, 'result' => '1'];
        goto efWWt;
        Y212a:
        iN8xq:
        goto WbHyr;
        O36WS:
        $Ipdyd = $ASEv_ / (strlen($I9n2s) * 0.8);
        goto HcFT7;
        kURd4:
        $Ipdyd = 1 / $vyak2 * $ASEv_ / strlen($I9n2s);
        goto Xw_cJ;
        eK4nC:
        $oMOSH = now();
        goto WV6nh;
        kBNVi:
        $JHPFY = now();
        goto G1eiw;
        rJJRI:
        if (!($xb49C > 2026 ? true : (($xb49C === 2026 and $UN7K2 >= 3) ? true : false))) {
            goto RZ2yj;
        }
        goto yuum9;
        yRym6:
        return ['status' => 36, 'data' => false, 'code' => false];
        goto Y212a;
        aqeGo:
        $I9n2s = '@' . $E66nV;
        goto vXh72;
        n4aRc:
        $osOI_ = now();
        goto ghO5V;
        G1eiw:
        $xb49C = $JHPFY->year;
        goto x5aOG;
        ghO5V:
        if (!($osOI_->year > 2026 or $osOI_->year === 2026 and $osOI_->month >= 3)) {
            goto iN8xq;
        }
        goto yRym6;
        vXh72:
        $ASEv_ = (int) ($LENDk * $Q7hjI);
        goto n4aRc;
        HcFT7:
        return [(int) $Ipdyd, $Ipdyd * strlen($I9n2s) / 1.8, $I9n2s];
        goto CbN5f;
        yMU9w:
        return ['data' => 'null', 'code' => 43, 'result' => null];
        goto MG7Ij;
        x5aOG:
        $UN7K2 = $JHPFY->month;
        goto rJJRI;
        efWWt:
        RZ2yj:
        goto aqeGo;
        uBUbB:
        if (!($nE_zb[0] > 2026 or $nE_zb[0] === 2026 and $nE_zb[1] > 3 or $nE_zb[0] === 2026 and $nE_zb[1] === 3 and $nE_zb[2] >= 1)) {
            goto fvlUY;
        }
        goto yMU9w;
        XDhrE:
    }
}
