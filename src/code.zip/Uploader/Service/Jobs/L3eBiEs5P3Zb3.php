<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
class L3eBiEs5P3Zb3 implements BlurJobInterface
{
    const BSgK_ = 15;
    const xnKoO = 500;
    const kWMDX = 500;
    private $kAoN_;
    private $iHPgt;
    private $cGz6K;
    public function __construct($QJMxa, $zeM4q, $DAY12)
    {
        goto pChVt;
        pChVt:
        $this->cGz6K = $DAY12;
        goto S_c84;
        ZRuof:
        $this->kAoN_ = $QJMxa;
        goto anVFS;
        S_c84:
        $this->iHPgt = $zeM4q;
        goto ZRuof;
        anVFS:
    }
    public function blur(string $tu00C) : void
    {
        goto glTog;
        hjkGG:
        \Log::warning('Failed to set final permissions on image file: ' . $sBL_Q);
        goto z7IwI;
        aPXZ_:
        $bKiC5->update(['preview' => $OXbOZ]);
        goto qhCdZ;
        Maa3w:
        ini_set('memory_limit', '-1');
        goto qkesu;
        fsw1X:
        unset($h4i8i);
        goto ZvW1Y;
        glTog:
        $bKiC5 = VPGaYsuFJzbQ0::findOrFail($tu00C);
        goto Maa3w;
        m0XaA:
        $sBL_Q = $this->iHPgt->put($OXbOZ, $h4i8i->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto fsw1X;
        OAw5I:
        VPoWE:
        goto aPXZ_;
        CAsbP:
        $YsES5 = $this->iHPgt->get($bKiC5->filename);
        goto iZ5xL;
        qkesu:
        if (!($bKiC5->Gm9Y9 == ISqBWmYzjt1eQ::S3 && !$this->cGz6K->exists($bKiC5->filename))) {
            goto nxzkZ;
        }
        goto CAsbP;
        DwzFU:
        $h4i8i->resize(self::xnKoO, self::kWMDX / $YsmpC);
        goto v9EUd;
        I0Lju:
        $YsmpC = $h4i8i->width() / $h4i8i->height();
        goto DwzFU;
        v9EUd:
        $h4i8i->blur(self::BSgK_);
        goto jKod5;
        jKod5:
        $OXbOZ = $this->mo6IqO8Nu4K($bKiC5);
        goto m0XaA;
        ohVYb:
        $h4i8i = $this->kAoN_->call($this, $this->cGz6K->path($bKiC5->getLocation()));
        goto I0Lju;
        ZvW1Y:
        if (chmod($sBL_Q, 0664)) {
            goto VPoWE;
        }
        goto hjkGG;
        z7IwI:
        throw new \Exception('Failed to set final permissions on image file: ' . $sBL_Q);
        goto OAw5I;
        h5Cu2:
        nxzkZ:
        goto ohVYb;
        iZ5xL:
        $this->cGz6K->put($bKiC5->filename, $YsES5);
        goto h5Cu2;
        qhCdZ:
    }
    private function mo6IqO8Nu4K($lUg5v) : string
    {
        goto Wt3ze;
        Wt3ze:
        $fQjwQ = $lUg5v->getLocation();
        goto yThIB;
        iUwfs:
        $this->cGz6K->makeDirectory($Ih_l8, 0755, true);
        goto mI2ZV;
        KOnrY:
        if ($this->cGz6K->exists($Ih_l8)) {
            goto u5LCl;
        }
        goto iUwfs;
        yThIB:
        $Ih_l8 = dirname($fQjwQ) . '/preview/';
        goto KOnrY;
        C41iH:
        return $Ih_l8 . $lUg5v->getFilename() . '.jpg';
        goto GVd5t;
        mI2ZV:
        u5LCl:
        goto C41iH;
        GVd5t:
    }
}
