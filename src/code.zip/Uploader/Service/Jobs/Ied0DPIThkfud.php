<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Illuminate\Support\Facades\Log;
class Ied0DPIThkfud implements DownloadToLocalJobInterface
{
    private $VoF9h;
    private $oBaPs;
    public function __construct($BQ2l1, $paaZf)
    {
        $this->VoF9h = $BQ2l1;
        $this->oBaPs = $paaZf;
    }
    public function download(string $JTwN4) : void
    {
        goto hlXiD;
        uPBdu:
        $this->oBaPs->put($hFrf7->getLocation(), $this->VoF9h->get($hFrf7->getLocation()));
        goto OJXij;
        tmzcz:
        if (!$this->oBaPs->exists($hFrf7->getLocation())) {
            goto OUbsF;
        }
        goto Xizto;
        z4aj4:
        Log::info("Start download file to local", ['fileId' => $JTwN4, 'filename' => $hFrf7->getLocation()]);
        goto tmzcz;
        hlXiD:
        $hFrf7 = Z7LUL65CwqbbF::findOrFail($JTwN4);
        goto z4aj4;
        Xizto:
        return;
        goto Zk1w2;
        Zk1w2:
        OUbsF:
        goto uPBdu;
        OJXij:
    }
}
