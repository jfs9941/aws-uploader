<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class UvnGzrfudDGBa
{
    private $VeG5y;
    private $WmyDH;
    public function __construct(int $yCO0u, int $owacS)
    {
        goto juNmj;
        nFVOy:
        $this->VeG5y = $yCO0u;
        goto Uqi2H;
        H90Ql:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto FH4Po;
        Uqi2H:
        $this->WmyDH = $owacS;
        goto OaTtR;
        FjBce:
        if (!($owacS <= 0)) {
            goto cL9hl;
        }
        goto H90Ql;
        juNmj:
        if (!($yCO0u <= 0)) {
            goto uEprF;
        }
        goto K6THe;
        uc9b2:
        uEprF:
        goto FjBce;
        K6THe:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto uc9b2;
        FH4Po:
        cL9hl:
        goto nFVOy;
        OaTtR:
    }
    private static function mX5Af8QD0eR($gEfL2, string $iTBZc = 'floor') : int
    {
        goto k1x7l;
        xgW__:
        gEP5h:
        goto Bqcxe;
        sUdav:
        Eh0Ya:
        goto OPXJS;
        CdD1E:
        return (int) $gEfL2;
        goto sUdav;
        k1x7l:
        if (!(is_int($gEfL2) && $gEfL2 % 2 === 0)) {
            goto RghdQ;
        }
        goto vewGM;
        Bqcxe:
        LnV8p:
        goto Etdlh;
        ISBA6:
        RghdQ:
        goto Suuw5;
        Suuw5:
        if (!(is_float($gEfL2) && $gEfL2 == floor($gEfL2) && (int) $gEfL2 % 2 === 0)) {
            goto Eh0Ya;
        }
        goto CdD1E;
        OPXJS:
        switch (strtolower($iTBZc)) {
            case 'ceil':
                return (int) (ceil($gEfL2 / 2) * 2);
            case 'round':
                return (int) (round($gEfL2 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($gEfL2 / 2) * 2);
        }
        goto xgW__;
        vewGM:
        return $gEfL2;
        goto ISBA6;
        Etdlh:
    }
    public function m2kzsSbz7UN(string $znb8d = 'floor') : array
    {
        goto cmRcx;
        tVCp6:
        $wq0Ts = self::mX5Af8QD0eR(round($sBbVh), $znb8d);
        goto J4PWn;
        bsXg2:
        PqOhP:
        goto ibowp;
        GjuvJ:
        GU7Kk:
        goto kWMID;
        ibowp:
        $fLz1H = $d1LoZ;
        goto sspww;
        sspww:
        $FZxC2 = $fLz1H / $this->WmyDH;
        goto mr6Sf;
        ukHA8:
        $oN2gb = $this->WmyDH * $FZxC2;
        goto s0_Tt;
        uktoM:
        $fLz1H = 0;
        goto nl_Xd;
        tmd3f:
        VrzcF:
        goto LsT0i;
        nl_Xd:
        if ($this->VeG5y >= $this->WmyDH) {
            goto PqOhP;
        }
        goto JvCZk;
        URMRB:
        $wq0Ts = 2;
        goto tmd3f;
        mr6Sf:
        $sBbVh = $this->VeG5y * $FZxC2;
        goto tVCp6;
        J4PWn:
        dcr3r:
        goto Rk9LX;
        cmRcx:
        $d1LoZ = 1080;
        goto BixTG;
        r_76g:
        $fLz1H = 2;
        goto GjuvJ;
        s0_Tt:
        $fLz1H = self::mX5Af8QD0eR(round($oN2gb), $znb8d);
        goto A3Woh;
        JvCZk:
        $wq0Ts = $d1LoZ;
        goto TP7Wr;
        TP7Wr:
        $FZxC2 = $wq0Ts / $this->VeG5y;
        goto ukHA8;
        kWMID:
        return ['width' => $wq0Ts, 'height' => $fLz1H];
        goto MveqF;
        A3Woh:
        goto dcr3r;
        goto bsXg2;
        Rk9LX:
        if (!($wq0Ts < 2)) {
            goto VrzcF;
        }
        goto URMRB;
        BixTG:
        $wq0Ts = 0;
        goto uktoM;
        LsT0i:
        if (!($fLz1H < 2)) {
            goto GU7Kk;
        }
        goto r_76g;
        MveqF:
    }
}
