<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Encoder\CAK6aksp9Uyad;
use Jfs\Uploader\Encoder\Tp9NT29QRCL9S;
use Jfs\Uploader\Encoder\ASuKOsLEZrEeb;
use Jfs\Uploader\Encoder\SbhemT8X5X1z8;
use Jfs\Uploader\Encoder\HYHb7A2L6Ex2n;
use Jfs\Uploader\Encoder\EtwwKqtO3Gypr;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Jfs\Uploader\Service\Jobs\TzF4QjjMGsAzw;
use Jfs\Uploader\Service\Jobs\MFsckEdQzAs6x;
use Jfs\Uploader\Service\XmR9LXciUFjyf;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class TCGbWudEvpDHl implements MediaEncodeJobInterface
{
    private $XWRu9;
    private $IdG3S;
    private $hFxUe;
    private $wVJ_V;
    private $rJ93d;
    public function __construct(string $Ba5m3, $ftmEm, $KKbEP, $wc3FE, $OPaP_)
    {
        goto AdFQD;
        YdAj7:
        $this->wVJ_V = $wc3FE;
        goto KYY2j;
        gT7RL:
        $this->IdG3S = $ftmEm;
        goto Aqy1e;
        AdFQD:
        $this->XWRu9 = $Ba5m3;
        goto gT7RL;
        Aqy1e:
        $this->hFxUe = $KKbEP;
        goto YdAj7;
        KYY2j:
        $this->rJ93d = $OPaP_;
        goto lxjzT;
        lxjzT:
    }
    public function encode(string $SEOXv, string $uZL5Y, $EipFx = true) : void
    {
        goto RJDK2;
        uWEp5:
        try {
            goto wGYtg;
            cukrh:
            $NLBFz = $NLBFz->mwZPc5EwE5o($th60a);
            goto AmSSS;
            QrZrX:
            $b27Fu = $b27Fu->mPdDoXjWLbE($wO3vh);
            goto hThct;
            olvqT:
            $wO3vh = $this->mj8zlhvha6H($rKcW0, $xJxNW->mJjYfi06Dd5($IrxWj->width(), $IrxWj->height(), $uZL5Y));
            goto Gpg9Q;
            ItF9k:
            $rq6sE = app(ASuKOsLEZrEeb::class);
            goto qjxBL;
            JrMTM:
            $b27Fu = new Tp9NT29QRCL9S('original', $IxHFs, $Ijyqc, $IrxWj->UokrC ?? 30);
            goto ItF9k;
            cji21:
            $U34JM = new Tp9NT29QRCL9S('1080p', $wdwa4['width'], $wdwa4['height'], $IrxWj->UokrC ?? 30);
            goto krRyZ;
            yB3mQ:
            yeBwn:
            goto IjgGs;
            zTVEg:
            $IrxWj->update(['aws_media_converter_job_id' => $SEOXv]);
            goto vBrsP;
            iMVwW:
            $U34JM = $U34JM->mPdDoXjWLbE($wO3vh);
            goto yB3mQ;
            nRWe2:
            throw new MediaConverterException("IvT3V5jT5KEaA {$IrxWj->id} is not S3 driver value = {$IrxWj->driver}");
            goto dbFuG;
            wUGfS:
            GT3Lx:
            goto lJdKR;
            liluI:
            Log::info("IvT3V5jT5KEaA already has Media Converter Job ID, skip encoding", ['fileId' => $SEOXv, 'jobId' => $IrxWj->getAttribute('aws_media_converter_job_id')]);
            goto mkAmb;
            AmSSS:
            $SEOXv = $NLBFz->mekzVlHF4nE($this->mPkPynOak9G($IrxWj, $EipFx));
            goto zTVEg;
            IG39Y:
            if (!$IrxWj->getAttribute('aws_media_converter_job_id')) {
                goto GT3Lx;
            }
            goto liluI;
            A2Ga1:
            $Ijyqc = $IrxWj->height();
            goto opfWH;
            wGYtg:
            $IrxWj = IvT3V5jT5KEaA::findOrFail($SEOXv);
            goto BAdXH;
            d3GNG:
            if (!$wO3vh) {
                goto yeBwn;
            }
            goto iMVwW;
            qjxBL:
            $NLBFz->mn9pmiA6tdw($b27Fu);
            goto BViob;
            GcglW:
            $NLBFz->mn9pmiA6tdw($b27Fu);
            goto nEd3y;
            krRyZ:
            $wO3vh = $this->mj8zlhvha6H($rKcW0, $xJxNW->mJjYfi06Dd5((int) $wdwa4['width'], (int) $wdwa4['height'], $uZL5Y));
            goto d3GNG;
            BAdXH:
            Assert::isInstanceOf($IrxWj, IvT3V5jT5KEaA::class);
            goto eGVmh;
            NEMNB:
            $NLBFz = $NLBFz->mKovrZboLLc(new SbhemT8X5X1z8($Ej7D3));
            goto JrMTM;
            lJdKR:
            $IxHFs = $IrxWj->width();
            goto A2Ga1;
            Z7tqc:
            $th60a = new CAK6aksp9Uyad($IrxWj->getAttribute('duration') ?? 1, 2, $rq6sE->mT6pU1IKqIF($IrxWj));
            goto cukrh;
            hThct:
            w0ZPH:
            goto GcglW;
            nacNz:
            $wdwa4 = $this->mnshvuBppZY($IxHFs, $Ijyqc);
            goto UN1F0;
            mkAmb:
            return;
            goto wUGfS;
            aMQkL:
            pvc2f:
            goto Gg5O0;
            IjgGs:
            $NLBFz = $NLBFz->mn9pmiA6tdw($U34JM);
            goto aMQkL;
            Gg5O0:
            fQ81B:
            goto loq4K;
            YpZ0z:
            $xJxNW = new MFsckEdQzAs6x($this->wVJ_V, $this->rJ93d, $this->hFxUe, $this->IdG3S);
            goto olvqT;
            opfWH:
            $Ej7D3 = $this->mxWazagsF3t($IrxWj);
            goto bjIHj;
            dbFuG:
            z3MGz:
            goto IG39Y;
            ehyIu:
            if (!$this->muPCGv0NXsr($IxHFs, $Ijyqc)) {
                goto pvc2f;
            }
            goto nacNz;
            bjIHj:
            Log::info("Set input video for Job", ['s3Uri' => $Ej7D3]);
            goto vIPDE;
            XnoML:
            $rKcW0 = app(XmR9LXciUFjyf::class);
            goto YpZ0z;
            BViob:
            $NLBFz->mn1nwnAEThG($rq6sE->mOh7kVVbVZk($IrxWj));
            goto XnoML;
            loq4K:
            Log::info("Set thumbnail for IvT3V5jT5KEaA Job", ['videoId' => $IrxWj->getAttribute('id'), 'duration' => $IrxWj->getAttribute('duration')]);
            goto Z7tqc;
            nEd3y:
            $NLBFz->mn1nwnAEThG($rq6sE->mOh7kVVbVZk($IrxWj));
            goto cGpGy;
            Gpg9Q:
            if (!$wO3vh) {
                goto w0ZPH;
            }
            goto QrZrX;
            cGpGy:
            if (!($IxHFs && $Ijyqc)) {
                goto fQ81B;
            }
            goto ehyIu;
            eGVmh:
            if (!($IrxWj->driver != Rf7fPQasmK9R3::S3)) {
                goto z3MGz;
            }
            goto nRWe2;
            vIPDE:
            $NLBFz = app(HYHb7A2L6Ex2n::class);
            goto NEMNB;
            UN1F0:
            Log::info("Set 1080p resolution for Job", ['width' => $wdwa4['width'], 'height' => $wdwa4['height'], 'originalWidth' => $IxHFs, 'originalHeight' => $Ijyqc]);
            goto cji21;
            vBrsP:
        } catch (\Exception $L0fOk) {
            goto GxaSd;
            by6kF:
            Sentry::captureException($L0fOk);
            goto k6uiV;
            k6uiV:
            return;
            goto yUDmw;
            GxaSd:
            Log::warning("IvT3V5jT5KEaA has been deleted, discard it", ['fileId' => $SEOXv, 'err' => $L0fOk->getMessage()]);
            goto by6kF;
            yUDmw:
        }
        goto Gmrul;
        n6Ku8:
        ini_set('memory_limit', '-1');
        goto uWEp5;
        RJDK2:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $SEOXv]);
        goto n6Ku8;
        Gmrul:
    }
    private function mPkPynOak9G(IvT3V5jT5KEaA $IrxWj, $EipFx) : bool
    {
        goto ulGJh;
        ZRwP3:
        $KDCmh = (int) round($IrxWj->getAttribute('duration') ?? 0);
        goto DdtDP;
        DdtDP:
        switch (true) {
            case $IrxWj->width() * $IrxWj->height() >= 1920 * 1080 && $IrxWj->width() * $IrxWj->height() < 2560 * 1440:
                return $KDCmh > 30 * 60;
            case $IrxWj->width() * $IrxWj->height() >= 2560 * 1440 && $IrxWj->width() * $IrxWj->height() < 3840 * 2160:
                return $KDCmh > 15 * 60;
            case $IrxWj->width() * $IrxWj->height() >= 3840 * 2160:
                return $KDCmh > 10 * 60;
            default:
                return false;
        }
        goto pRlr_;
        lwsTi:
        QR0gr:
        goto ZRwP3;
        XuqMi:
        JGhEf:
        goto okPNR;
        ulGJh:
        if ($EipFx) {
            goto QR0gr;
        }
        goto SkloL;
        SkloL:
        return false;
        goto lwsTi;
        pRlr_:
        D_8EL:
        goto XuqMi;
        okPNR:
    }
    private function mj8zlhvha6H(XmR9LXciUFjyf $rKcW0, string $GKxAm) : ?EtwwKqtO3Gypr
    {
        goto ni0s1;
        BJSVT:
        if (!$ixlkI) {
            goto bX_ep;
        }
        goto cWu1l;
        MW1EP:
        return null;
        goto gZBzF;
        E9j5u:
        bX_ep:
        goto MW1EP;
        ni0s1:
        $ixlkI = $rKcW0->mwu24m1eaLt($GKxAm);
        goto XwTfx;
        cWu1l:
        return new EtwwKqtO3Gypr($ixlkI, 0, 0, null, null);
        goto E9j5u;
        XwTfx:
        Log::info("Resolve watermark for job with url", ['url' => $GKxAm, 'uri' => $ixlkI]);
        goto BJSVT;
        gZBzF:
    }
    private function muPCGv0NXsr(int $IxHFs, int $Ijyqc) : bool
    {
        return $IxHFs * $Ijyqc > 1.5 * (1920 * 1080);
    }
    private function mnshvuBppZY(int $IxHFs, int $Ijyqc) : array
    {
        $LO2OA = new TzF4QjjMGsAzw($IxHFs, $Ijyqc);
        return $LO2OA->mOZ5Qjnxwu5();
    }
    private function mxWazagsF3t(ZZfsW9KHWsMrx $mbUjE) : string
    {
        goto WZ5i1;
        wBiiq:
        return $this->IdG3S->url($mbUjE->filename);
        goto M6PN7;
        y3qMc:
        YadUO:
        goto wBiiq;
        WZ5i1:
        if (!($mbUjE->driver == Rf7fPQasmK9R3::S3)) {
            goto YadUO;
        }
        goto C3nqk;
        C3nqk:
        return 's3://' . $this->XWRu9 . '/' . $mbUjE->filename;
        goto y3qMc;
        M6PN7:
    }
}
