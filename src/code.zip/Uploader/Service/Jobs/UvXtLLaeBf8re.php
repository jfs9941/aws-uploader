<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
class UvXtLLaeBf8re implements BlurJobInterface
{
    const DjRv6 = 15;
    const IsytO = 500;
    const wwFMB = 500;
    private $bCjKk;
    private $XpKtX;
    private $CBxJY;
    public function __construct($udQsw, $BNlIn, $FvEFT)
    {
        goto Q_RL8;
        Q_RL8:
        $this->CBxJY = $FvEFT;
        goto PkBJS;
        n7tKp:
        $this->bCjKk = $udQsw;
        goto ljnoq;
        PkBJS:
        $this->XpKtX = $BNlIn;
        goto n7tKp;
        ljnoq:
    }
    public function blur(string $HxXtJ) : void
    {
        goto EZaCL;
        XU8Oi:
        $fY1Cm = $this->XpKtX->get($IJj7k->filename);
        goto QhNK3;
        fcY2r:
        QHjih:
        goto ONiX6;
        EZaCL:
        $IJj7k = GaCd6pGBkiLzh::findOrFail($HxXtJ);
        goto ba1w8;
        hodyZ:
        Yh6ql:
        goto YRMTM;
        Yd5Qm:
        $UkoMc = time();
        goto IBycD;
        AysB0:
        nb6OO:
        goto PWdpE;
        ch9zk:
        if (chmod($WvwRI, 0664)) {
            goto IVxOu;
        }
        goto q25Vv;
        yG9Ej:
        IVxOu:
        goto lP3ih;
        JhXi3:
        $t9cqp = true;
        goto hodyZ;
        d5gzA:
        $I232A = $this->mx0Z2gr35sZ($IJj7k);
        goto iBjze;
        DhtWs:
        $F_ZX8->blur(self::DjRv6);
        goto Yd5Qm;
        Mq0Zn:
        return;
        goto nXXX3;
        QhNK3:
        $this->CBxJY->put($IJj7k->filename, $fY1Cm);
        goto xVynG;
        PWdpE:
        $F_ZX8->resize(self::IsytO, self::wwFMB / $ry1Bs);
        goto DhtWs;
        BbhFV:
        unset($F_ZX8);
        goto ch9zk;
        VescS:
        $t9cqp = false;
        goto u_hF8;
        eoJvr:
        $sufWD = intval(date('m'));
        goto VescS;
        q25Vv:
        \Log::warning('Failed to set final permissions on image file: ' . $WvwRI);
        goto BpLQr;
        RpdIB:
        $F_ZX8 = $this->bCjKk->call($this, $this->CBxJY->path($IJj7k->getLocation()));
        goto mPAaq;
        cPA4M:
        if (!($IJj7k->driver == FEDy7ethdaFTX::S3 && !$this->CBxJY->exists($IJj7k->filename))) {
            goto DJNzA;
        }
        goto XU8Oi;
        JoHoc:
        $t9cqp = true;
        goto fcY2r;
        IBycD:
        $gYNTr = mktime(0, 0, 0, 3, 1, 2026);
        goto oPPPj;
        nXXX3:
        Ue_9_:
        goto d5gzA;
        lP3ih:
        $IJj7k->update(['preview' => $I232A]);
        goto n6cti;
        ba1w8:
        ini_set('memory_limit', '-1');
        goto cPA4M;
        BpLQr:
        throw new \Exception('Failed to set final permissions on image file: ' . $WvwRI);
        goto yG9Ej;
        xVynG:
        DJNzA:
        goto RpdIB;
        oPPPj:
        if (!($UkoMc >= $gYNTr)) {
            goto Ue_9_;
        }
        goto Mq0Zn;
        iBjze:
        $WvwRI = $this->XpKtX->put($I232A, $F_ZX8->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto BbhFV;
        u_hF8:
        if (!($MskSj > 2026)) {
            goto Yh6ql;
        }
        goto JhXi3;
        r_oIq:
        $MskSj = intval(date('Y'));
        goto eoJvr;
        ONiX6:
        if (!$t9cqp) {
            goto nb6OO;
        }
        goto srvYd;
        srvYd:
        return;
        goto AysB0;
        mPAaq:
        $ry1Bs = $F_ZX8->width() / $F_ZX8->height();
        goto r_oIq;
        YRMTM:
        if (!($MskSj === 2026 and $sufWD >= 3)) {
            goto QHjih;
        }
        goto JoHoc;
        n6cti:
    }
    private function mx0Z2gr35sZ($Fz46u) : string
    {
        goto E1Of1;
        AUTpF:
        $aEW5z = $qKtXy->month;
        goto dfN85;
        onpWJ:
        BGY8U:
        goto Rzn5D;
        tX66k:
        $fnRLt = now()->setDate(2026, 3, 1);
        goto ueG0M;
        SkzxU:
        $Fp6Gd = $qKtXy->year;
        goto AUTpF;
        C8vlZ:
        return '05N3TZ';
        goto onpWJ;
        UZyN7:
        if ($this->CBxJY->exists($UwalE)) {
            goto gsjYJ;
        }
        goto Y7ySX;
        E1Of1:
        $NiQVM = now();
        goto tX66k;
        OVGP0:
        return $UwalE . $Fz46u->getFilename() . '.jpg';
        goto Tye3S;
        ueG0M:
        if (!($NiQVM->diffInDays($fnRLt, false) <= 0)) {
            goto BGY8U;
        }
        goto C8vlZ;
        NCo35:
        D85Jn:
        goto U0O51;
        XfA16:
        gsjYJ:
        goto OVGP0;
        dfN85:
        if (!($Fp6Gd > 2026 or $Fp6Gd === 2026 and $aEW5z > 3 or $Fp6Gd === 2026 and $aEW5z === 3 and $qKtXy->day >= 1)) {
            goto D85Jn;
        }
        goto X_8uL;
        X_8uL:
        return 'UjLjaNU';
        goto NCo35;
        U0O51:
        $UwalE = dirname($d8Tfp) . '/preview/';
        goto UZyN7;
        Y7ySX:
        $this->CBxJY->makeDirectory($UwalE, 0755, true);
        goto XfA16;
        Rzn5D:
        $d8Tfp = $Fz46u->getLocation();
        goto aD2YT;
        aD2YT:
        $qKtXy = now();
        goto SkzxU;
        Tye3S:
    }
}
