<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class JLhS5pGupvbSs
{
    private $q3KfI;
    private $i0IXb;
    private $dhrkT;
    private $VFHFZ;
    public function __construct($xsFIZ, $tJOVN, $v8n0s, $dOL2I)
    {
        goto ow1_W;
        ow1_W:
        $this->i0IXb = $tJOVN;
        goto G0H2E;
        VSLRt:
        $this->VFHFZ = $dOL2I;
        goto BKWI_;
        BKWI_:
        $this->q3KfI = $xsFIZ;
        goto ZZQY1;
        G0H2E:
        $this->dhrkT = $v8n0s;
        goto VSLRt;
        ZZQY1:
    }
    public function mZn9oNgFPjz(?int $X22ix, ?int $LrYxj, string $mLgze, bool $vetEG = false) : string
    {
        goto MWnr8;
        MWnr8:
        if (!($X22ix === null || $LrYxj === null)) {
            goto cGxUu;
        }
        goto GDr4N;
        B69KZ:
        $hs5Cw = $X22ix - $G0PP8;
        goto YMgRN;
        okCqO:
        $this->VFHFZ->put($IJqE5, $MpgR7->stream('png'));
        goto Mr3mD;
        Pv6dm:
        $MpgR7 = $this->q3KfI->call($this, $X22ix, $LrYxj);
        goto B69KZ;
        uayjt:
        OVxoU:
        goto ekZt1;
        CMvjs:
        if (!($X22ix > 1500)) {
            goto OVxoU;
        }
        goto kscsf;
        kscsf:
        $hs5Cw -= $uywGL * 0.4;
        goto uayjt;
        zqqKg:
        yPEe3:
        goto Pv6dm;
        CzGZr:
        $hs5Cw -= $uywGL;
        goto CMvjs;
        Mr3mD:
        $this->dhrkT->put($IJqE5, $MpgR7->stream('png'));
        goto wcla8;
        ekZt1:
        $jix6p = $LrYxj - $V45Fg - 10;
        goto SgQ3V;
        df0iq:
        if (!$this->dhrkT->exists($IJqE5)) {
            goto yPEe3;
        }
        goto UvtJd;
        mAJ1G:
        cGxUu:
        goto fln9E;
        UvtJd:
        return $vetEG ? $IJqE5 : $this->dhrkT->url($IJqE5);
        goto zqqKg;
        fvG4k:
        $IJqE5 = $this->mhcB89aYfYS($EZhCf, $X22ix, $LrYxj, $G0PP8, $V45Fg);
        goto df0iq;
        fln9E:
        $iMZKi = 0.1;
        goto GrRh_;
        YMgRN:
        $uywGL = (int) ($hs5Cw / 80);
        goto CzGZr;
        GDr4N:
        throw new \RuntimeException("G4MP13yRAmltw dimensions are not available.");
        goto mAJ1G;
        wcla8:
        return $vetEG ? $IJqE5 : $this->dhrkT->url($IJqE5);
        goto pOMQR;
        SgQ3V:
        $MpgR7->text($EZhCf, $hs5Cw, (int) $jix6p, function ($nv2EQ) use($V45Fg) {
            goto go5KB;
            go5KB:
            $nv2EQ->file(public_path($this->i0IXb));
            goto yD7EA;
            qe1dD:
            $nv2EQ->valign('middle');
            goto elGzt;
            elGzt:
            $nv2EQ->align('middle');
            goto lbIhp;
            yD7EA:
            $D7swn = (int) ($V45Fg * 1.2);
            goto fkjKV;
            SlMNo:
            $nv2EQ->color([185, 185, 185, 1]);
            goto qe1dD;
            fkjKV:
            $nv2EQ->size(max($D7swn, 1));
            goto SlMNo;
            lbIhp:
        });
        goto okCqO;
        GrRh_:
        list($V45Fg, $G0PP8, $EZhCf) = $this->mHDJp3IZoWw($mLgze, $X22ix, $iMZKi, (float) $X22ix / $LrYxj);
        goto fvG4k;
        pOMQR:
    }
    private function mhcB89aYfYS(string $mLgze, int $X22ix, int $LrYxj, int $txj7j, int $Kdapx) : string
    {
        $sA1J_ = ltrim($mLgze, '@');
        return "v2/watermark/{$sA1J_}/{$X22ix}x{$LrYxj}_{$txj7j}x{$Kdapx}/text_watermark.png";
    }
    private function mHDJp3IZoWw($mLgze, int $X22ix, float $cM6_m, float $NE9ag) : array
    {
        goto HjPLO;
        v81XL:
        $gQXOC = $G0PP8 / (strlen($EZhCf) * 0.8);
        goto QGbuD;
        QGbuD:
        return [(int) $gQXOC, $gQXOC * strlen($EZhCf) / 1.8, $EZhCf];
        goto bQdlb;
        bDzNa:
        $gQXOC = 1 / $NE9ag * $G0PP8 / strlen($EZhCf);
        goto ORzNt;
        HjPLO:
        $EZhCf = '@' . $mLgze;
        goto cgAdv;
        ORzNt:
        return [(int) $gQXOC, $G0PP8, $EZhCf];
        goto d2IfE;
        geQwW:
        if (!($NE9ag > 1)) {
            goto pSi5K;
        }
        goto v81XL;
        cgAdv:
        $G0PP8 = (int) ($X22ix * $cM6_m);
        goto geQwW;
        bQdlb:
        pSi5K:
        goto bDzNa;
        d2IfE:
    }
}
