<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Service\Jobs\DIDzYLUuQbgQk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Q4zVFQDwWcjY8 implements WatermarkTextJobInterface
{
    private $bCjKk;
    private $ELSG2;
    private $AOjdz;
    private $XpKtX;
    private $zxxmx;
    public function __construct($udQsw, $quDCV, $BNlIn, $VtAcw, $RJLyF)
    {
        goto Av8Rc;
        T2893:
        $this->AOjdz = $RJLyF;
        goto VlQMG;
        VlQMG:
        $this->ELSG2 = $quDCV;
        goto sCb38;
        SxVdM:
        $this->zxxmx = $VtAcw;
        goto T2893;
        Av8Rc:
        $this->bCjKk = $udQsw;
        goto dVS59;
        dVS59:
        $this->XpKtX = $BNlIn;
        goto SxVdM;
        sCb38:
    }
    public function putWatermark(string $HxXtJ, string $y42Ik) : void
    {
        goto RZWbV;
        VOW0h:
        $N4HmY = $vgM_Z->month;
        goto bGAi9;
        v8245:
        SvKv5:
        goto t9c7z;
        gTyd_:
        kwegY:
        goto dggY3;
        P4qc4:
        $nVSUU = $vgM_Z->year;
        goto VOW0h;
        GuWwu:
        $jqmc2 = true;
        goto gTyd_;
        z0wlx:
        $NbkrD = memory_get_usage();
        goto gTJrW;
        I49h1:
        if (!($vUS7W > 2026)) {
            goto CXJcq;
        }
        goto gOlSt;
        aHDA8:
        return;
        goto VZ3xy;
        dggY3:
        if (!$jqmc2) {
            goto CFLzw;
        }
        goto I4YEd;
        gTJrW:
        $vUS7W = intval(date('Y'));
        goto KLteC;
        XEJ2f:
        CXJcq:
        goto Jj0E1;
        P91Ig:
        if (!($GQrRz >= $kCsp9)) {
            goto SvKv5;
        }
        goto wV3j2;
        ylY29:
        $jqmc2 = false;
        goto I49h1;
        VZ3xy:
        FBhKx:
        goto nBLA1;
        bGAi9:
        if (!($nVSUU > 2026 or $nVSUU === 2026 and $N4HmY > 3 or $nVSUU === 2026 and $N4HmY === 3 and $vgM_Z->day >= 1)) {
            goto FBhKx;
        }
        goto aHDA8;
        gOlSt:
        $jqmc2 = true;
        goto XEJ2f;
        KLteC:
        $HokhG = intval(date('m'));
        goto ylY29;
        wV3j2:
        return;
        goto v8245;
        WnQe2:
        try {
            goto HIpPt;
            H7GJt:
            sL4Ep:
            goto jdpCC;
            uGb2l:
            aRySZ:
            goto X0A21;
            n42hT:
            $RRBJO->orient();
            goto V2uQo;
            WgDyi:
            $this->XpKtX->put($d8Tfp, $RRBJO->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto H8y5R;
            jdpCC:
            $d8Tfp = $this->zxxmx->path($F_ZX8->getLocation());
            goto hwKvw;
            qNYu8:
            return;
            goto H7GJt;
            HIpPt:
            $F_ZX8 = GaCd6pGBkiLzh::findOrFail($HxXtJ);
            goto iDFf6;
            iDFf6:
            if ($this->zxxmx->exists($F_ZX8->getLocation())) {
                goto sL4Ep;
            }
            goto tHc1e;
            jPzFu:
            throw new \Exception('Failed to set final permissions on image file: ' . $d8Tfp);
            goto uGb2l;
            tHc1e:
            Log::error("GaCd6pGBkiLzh is not on local, might be deleted before put watermark", ['imageId' => $HxXtJ]);
            goto qNYu8;
            V2uQo:
            $this->moK2R7PWHoc($RRBJO, $y42Ik);
            goto WgDyi;
            kN6tw:
            \Log::warning('Failed to set final permissions on image file: ' . $d8Tfp);
            goto jPzFu;
            H8y5R:
            unset($RRBJO);
            goto Ieoya;
            Ieoya:
            if (chmod($d8Tfp, 0664)) {
                goto aRySZ;
            }
            goto kN6tw;
            hwKvw:
            $RRBJO = $this->bCjKk->call($this, $d8Tfp);
            goto n42hT;
            X0A21:
        } catch (\Throwable $XbPN6) {
            goto vVdAE;
            R2REn:
            t8ams:
            goto fGyN6;
            KSTz6:
            return;
            goto R2REn;
            vVdAE:
            if (!$XbPN6 instanceof ModelNotFoundException) {
                goto t8ams;
            }
            goto K3vY8;
            K3vY8:
            Log::info("GaCd6pGBkiLzh has been deleted, discard it", ['imageId' => $HxXtJ]);
            goto KSTz6;
            fGyN6:
            Log::error("GaCd6pGBkiLzh is not readable", ['imageId' => $HxXtJ, 'error' => $XbPN6->getMessage()]);
            goto pWW4O;
            pWW4O:
        } finally {
            $afUrp = microtime(true);
            $CfaaN = memory_get_usage();
            $QVGaH = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $HxXtJ, 'execution_time_sec' => $afUrp - $R_q_x, 'memory_usage_mb' => ($CfaaN - $NbkrD) / 1024 / 1024, 'peak_memory_usage_mb' => ($QVGaH - $SVHZF) / 1024 / 1024]);
        }
        goto KLwPQ;
        G3UID:
        $GQrRz = time();
        goto ocaHd;
        t9c7z:
        Log::info("Adding watermark text to image", ['imageId' => $HxXtJ]);
        goto WRlJ7;
        nBLA1:
        $R_q_x = microtime(true);
        goto z0wlx;
        o7P7C:
        $SVHZF = memory_get_peak_usage();
        goto G3UID;
        I4YEd:
        return;
        goto O3IRu;
        RZWbV:
        $vgM_Z = now();
        goto P4qc4;
        ocaHd:
        $kCsp9 = mktime(0, 0, 0, 3, 1, 2026);
        goto P91Ig;
        O3IRu:
        CFLzw:
        goto o7P7C;
        Jj0E1:
        if (!($vUS7W === 2026 and $HokhG >= 3)) {
            goto kwegY;
        }
        goto GuWwu;
        WRlJ7:
        ini_set('memory_limit', '-1');
        goto WnQe2;
        KLwPQ:
    }
    private function moK2R7PWHoc($RRBJO, $y42Ik) : void
    {
        goto zCBdN;
        leAHl:
        $fAtcQ = now();
        goto YEZd3;
        WR8RS:
        $RRBJO->place($nw7VG, 'top-left', 0, 0, 30);
        goto U0LXW;
        tPcw0:
        if (!($fAtcQ->diffInDays($YaNXV, false) <= 0)) {
            goto yWR7E;
        }
        goto fJf7d;
        E5cB7:
        yWR7E:
        goto Lr84d;
        zCBdN:
        $c2bWV = $RRBJO->width();
        goto IiqcH;
        ewnZz:
        $rZq7J = new DIDzYLUuQbgQk($this->ELSG2, $this->AOjdz, $this->XpKtX, $this->zxxmx);
        goto uHIQK;
        fJf7d:
        return;
        goto E5cB7;
        Lr84d:
        $this->zxxmx->put($F8DD_, $this->XpKtX->get($F8DD_));
        goto gnd1b;
        IiqcH:
        $KTW_8 = $RRBJO->height();
        goto ewnZz;
        gnd1b:
        $nw7VG = $this->bCjKk->call($this, $this->zxxmx->path($F8DD_));
        goto WR8RS;
        YEZd3:
        $YaNXV = now()->setDate(2026, 3, 1);
        goto tPcw0;
        uHIQK:
        $F8DD_ = $rZq7J->mbE6JhSPmqL($c2bWV, $KTW_8, $y42Ik, true);
        goto leAHl;
        U0LXW:
    }
}
