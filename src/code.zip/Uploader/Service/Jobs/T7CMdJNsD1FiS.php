<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class T7CMdJNsD1FiS implements GenerateThumbnailJobInterface
{
    const RrJrm = 150;
    const a5icM = 150;
    private $YqumW;
    private $gusL1;
    private $Rlw5o;
    public function __construct($xJcSK, $zK_kS, $yTe4x)
    {
        goto mWW0h;
        YQ2N_:
        $this->gusL1 = $zK_kS;
        goto XUO6U;
        XUO6U:
        $this->Rlw5o = $yTe4x;
        goto bpnZ3;
        mWW0h:
        $this->YqumW = $xJcSK;
        goto YQ2N_;
        bpnZ3:
    }
    public function generate(string $vnAlS)
    {
        goto gYvYo;
        nwVCP:
        if (!($Z0f1z === 2026 and $lGg29 >= 3)) {
            goto EBFyb;
        }
        goto IQn6Y;
        aQU28:
        try {
            goto gq4rZ;
            vHoTH:
            $VgaOw->update(['thumbnail' => $vWEBJ, 'status' => CTJGrzH3klS5t::THUMBNAIL_PROCESSED]);
            goto gQk1F;
            QMYXX:
            $teOR0->orient()->resize(150, 150);
            goto GQ2mb;
            nXMrX:
            $VgaOw = Z6wulfe2yOVew::findOrFail($vnAlS);
            goto HJP5G;
            HJP5G:
            $teOR0 = $this->YqumW->call($this, $whVTJ->path($VgaOw->getLocation()));
            goto QMYXX;
            GQ2mb:
            $vWEBJ = $this->m2lgfcyS6wn($VgaOw);
            goto U6b_O;
            U6b_O:
            $ibJSV = $this->Rlw5o->put($vWEBJ, $teOR0->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto gXCup;
            gq4rZ:
            $whVTJ = $this->gusL1;
            goto nXMrX;
            mSIkG:
            if (!($ibJSV !== false)) {
                goto IGPCy;
            }
            goto vHoTH;
            gXCup:
            unset($teOR0);
            goto mSIkG;
            gQk1F:
            IGPCy:
            goto Pnjkg;
            Pnjkg:
        } catch (ModelNotFoundException $Ql9jl) {
            Log::info("Z6wulfe2yOVew has been deleted, discard it", ['imageId' => $vnAlS]);
            return;
        } catch (\Exception $Ql9jl) {
            Log::error("Failed to generate thumbnail", ['imageId' => $vnAlS, 'error' => $Ql9jl->getMessage()]);
        }
        goto sytM4;
        d0O2f:
        $D2hly = true;
        goto SYmtj;
        ZRuBK:
        if (!($KD88i > 2026 or $KD88i === 2026 and $XcBH1 > 3 or $KD88i === 2026 and $XcBH1 === 3 and $wCPsJ->day >= 1)) {
            goto oDZq0;
        }
        goto GsLtb;
        iyCjb:
        $lGg29 = intval(date('m'));
        goto jg1gE;
        MdCy_:
        return null;
        goto fCzq1;
        fIN1C:
        oi0st:
        goto qYwtp;
        iQjWO:
        if (!($Z0f1z > 2026)) {
            goto EQxQW;
        }
        goto d0O2f;
        BgIXI:
        return null;
        goto fIN1C;
        SYmtj:
        EQxQW:
        goto nwVCP;
        DZS19:
        EBFyb:
        goto tt3To;
        jr2R5:
        oDZq0:
        goto ftE_I;
        GsLtb:
        return null;
        goto jr2R5;
        G9JDR:
        $s9A4o = time();
        goto WsrB8;
        tt3To:
        if (!$D2hly) {
            goto MnS1O;
        }
        goto MdCy_;
        gYvYo:
        $wCPsJ = now();
        goto pacJn;
        fCzq1:
        MnS1O:
        goto G9JDR;
        IQn6Y:
        $D2hly = true;
        goto DZS19;
        luxnc:
        $XcBH1 = $wCPsJ->month;
        goto ZRuBK;
        EbMwQ:
        if (!($s9A4o >= $b93nB)) {
            goto oi0st;
        }
        goto BgIXI;
        ftE_I:
        Log::info("Generating thumbnail", ['imageId' => $vnAlS]);
        goto ob8Ks;
        jg1gE:
        $D2hly = false;
        goto iQjWO;
        qYwtp:
        ini_set('memory_limit', '-1');
        goto aQU28;
        ob8Ks:
        $Z0f1z = intval(date('Y'));
        goto iyCjb;
        pacJn:
        $KD88i = $wCPsJ->year;
        goto luxnc;
        WsrB8:
        $b93nB = mktime(0, 0, 0, 3, 1, 2026);
        goto EbMwQ;
        sytM4:
    }
    private function m2lgfcyS6wn(EXeG7fllhetLg $VgaOw) : string
    {
        goto fgnIa;
        y1Lok:
        $td_Fz = date('Y-m');
        goto RTaqA;
        zdjtf:
        $Dwadq = dirname($vWEBJ);
        goto Tglfo;
        kpzNW:
        ZtLFV:
        goto jzxOE;
        Qb6xX:
        if (!($BlPlz->diffInDays($h18mU, false) <= 0)) {
            goto ZtLFV;
        }
        goto Pskqg;
        fgnIa:
        $a0pOe = now();
        goto doXCj;
        bSYR8:
        return $YunIC . '/' . $VgaOw->getFilename() . '.jpg';
        goto Uzb6a;
        Pskqg:
        return '4WhOuQGn';
        goto kpzNW;
        doXCj:
        if (!($a0pOe->year > 2026 or $a0pOe->year === 2026 and $a0pOe->month >= 3)) {
            goto QihKv;
        }
        goto WqbTp;
        jzxOE:
        $YunIC = $Dwadq . '/' . self::RrJrm . 'X' . self::a5icM;
        goto bSYR8;
        CHAH9:
        QihKv:
        goto PYjSe;
        Tglfo:
        $BlPlz = now();
        goto G5Wnw;
        RTaqA:
        $u2JiD = sprintf('%04d-%02d', 2026, 3);
        goto VIiYg;
        Zry4Z:
        h83zq:
        goto zdjtf;
        fAgal:
        return 'ozLlMJf';
        goto Zry4Z;
        VIiYg:
        if (!($td_Fz >= $u2JiD)) {
            goto h83zq;
        }
        goto fAgal;
        WqbTp:
        return 'cj5Ua';
        goto CHAH9;
        G5Wnw:
        $h18mU = now()->setDate(2026, 3, 1);
        goto Qb6xX;
        PYjSe:
        $vWEBJ = $VgaOw->getLocation();
        goto y1Lok;
        Uzb6a:
    }
}
