<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class ZklglaQMmoVEa implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $PV4mw) : void
    {
        goto esps0;
        J1wyv:
        f0rWP:
        goto PD5Qq;
        esps0:
        $vtvs_ = CSQMvXC33KbbS::findOrFail($PV4mw);
        goto fgmKi;
        fgmKi:
        if ($vtvs_->width() > 0 && $vtvs_->height() > 0) {
            goto f0rWP;
        }
        goto yARtV;
        yARtV:
        $this->mw2XftxGHi2($vtvs_);
        goto J1wyv;
        PD5Qq:
    }
    private function mw2XftxGHi2(CSQMvXC33KbbS $TUPIK) : void
    {
        goto D2zWl;
        D2zWl:
        $jdl8g = $TUPIK->getView();
        goto NP5TT;
        HOo1O:
        $jAl7Z = $HpL55->getVideoStream();
        goto NrlSK;
        VNTbR:
        $TUPIK->update(['duration' => $HpL55->getDurationInSeconds(), 'resolution' => $yuuXD->getWidth() . 'x' . $yuuXD->getHeight(), 'fps' => $jAl7Z->get('r_frame_rate') ?? 30]);
        goto e22Pj;
        NrlSK:
        $yuuXD = $jAl7Z->getDimensions();
        goto VNTbR;
        NP5TT:
        $HpL55 = FFMpeg::fromDisk($jdl8g['path'])->open($TUPIK->getAttribute('filename'));
        goto HOo1O;
        e22Pj:
    }
}
