<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class JY16BPSHUwdha implements CompressJobInterface
{
    const ashuc = 60;
    private $GqFb6;
    private $S0euz;
    private $qh_2h;
    public function __construct($WV89v, $t9rFg, $Jno5S)
    {
        goto j2faO;
        tmsi2:
        $this->S0euz = $t9rFg;
        goto HLIKB;
        lg2wd:
        $this->qh_2h = $Jno5S;
        goto tmsi2;
        j2faO:
        $this->GqFb6 = $WV89v;
        goto lg2wd;
        HLIKB:
    }
    public function compress(string $aK0gt)
    {
        goto zUDzT;
        Zx9YR:
        Log::info("Compress image", ['imageId' => $aK0gt]);
        goto bPWJ_;
        bPWJ_:
        try {
            goto hQo4I;
            jJs6m:
            try {
                goto T20V7;
                T20V7:
                $VBTcn = $this->S0euz->path(str_replace('.jpg', '.webp', $qKtXa->getLocation()));
                goto b6Ykw;
                w3LFE:
                $this->mr9X1qkVQ0T($qKtXa, 'webp');
                goto g8OqB;
                b6Ykw:
                $this->m1CHlFGipBh($etZMf, $VBTcn);
                goto w3LFE;
                g8OqB:
            } catch (\Exception $t0AeI) {
                goto z9I8O;
                iZZGx:
                $VBTcn = $this->S0euz->path($qKtXa->getLocation());
                goto KPmv6;
                KPmv6:
                $this->mVyQB7CY69S($etZMf, $VBTcn);
                goto DrYCq;
                z9I8O:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $aK0gt, 'error' => $t0AeI->getMessage()]);
                goto iZZGx;
                DrYCq:
            }
            goto IuajG;
            QM1GW:
            YM7zX:
            goto jJs6m;
            oqPjF:
            $etZMf = $this->S0euz->path($qKtXa->getLocation());
            goto yedIS;
            YrxYl:
            $qKtXa = $this->mr9X1qkVQ0T($qKtXa, 'jpg');
            goto QM1GW;
            yedIS:
            if (!(strtolower($qKtXa->getExtension()) === 'png' || strtolower($qKtXa->getExtension()) === 'heic')) {
                goto YM7zX;
            }
            goto YrxYl;
            hQo4I:
            $qKtXa = MpPzMcfcRTISZ::findOrFail($aK0gt);
            goto oqPjF;
            IuajG:
        } catch (\Throwable $t0AeI) {
            goto ar7Xz;
            rDDA7:
            return;
            goto l_iEo;
            IHx_D:
            Log::info("MpPzMcfcRTISZ has been deleted, discard it", ['imageId' => $aK0gt]);
            goto rDDA7;
            ar7Xz:
            if (!$t0AeI instanceof ModelNotFoundException) {
                goto UbAVS;
            }
            goto IHx_D;
            l_iEo:
            UbAVS:
            goto PDvXH;
            PDvXH:
            Log::error("Failed to compress image", ['imageId' => $aK0gt, 'error' => $t0AeI->getMessage()]);
            goto QfubS;
            QfubS:
        } finally {
            $Iy0Ri = microtime(true);
            $W1Mek = memory_get_usage();
            $s5Fdg = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $aK0gt, 'execution_time_sec' => $Iy0Ri - $Wz1mR, 'memory_usage_mb' => ($W1Mek - $bzMw6) / 1024 / 1024, 'peak_memory_usage_mb' => ($s5Fdg - $SwK9A) / 1024 / 1024]);
        }
        goto aif4v;
        zUDzT:
        $Wz1mR = microtime(true);
        goto jvvKg;
        YxAKx:
        $SwK9A = memory_get_peak_usage();
        goto Zx9YR;
        jvvKg:
        $bzMw6 = memory_get_usage();
        goto YxAKx;
        aif4v:
    }
    private function mVyQB7CY69S($etZMf, $VBTcn)
    {
        goto rrFdx;
        rrFdx:
        $BXhsT = $this->GqFb6->call($this, $etZMf);
        goto u3QgV;
        MzFQc:
        $this->qh_2h->put($VBTcn, $BXhsT->toJpeg(self::ashuc), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto yG8Dp;
        yG8Dp:
        unset($BXhsT);
        goto DTeGX;
        u3QgV:
        $BXhsT->orient()->toJpeg(self::ashuc)->save($VBTcn);
        goto MzFQc;
        DTeGX:
    }
    private function m1CHlFGipBh($etZMf, $VBTcn)
    {
        goto hT38G;
        mNqPR:
        unset($BXhsT);
        goto Uf1sU;
        S5_lD:
        $this->qh_2h->put($VBTcn, $BXhsT->toJpeg(self::ashuc), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto mNqPR;
        hT38G:
        $BXhsT = $this->GqFb6->call($this, $etZMf);
        goto WCTkC;
        WCTkC:
        $BXhsT->orient()->toWebp(self::ashuc);
        goto S5_lD;
        Uf1sU:
    }
    private function mr9X1qkVQ0T($qKtXa, $ZESiZ)
    {
        goto VaqHr;
        VaqHr:
        $qKtXa->setAttribute('type', $ZESiZ);
        goto GiUbt;
        GiUbt:
        $qKtXa->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$ZESiZ}", $qKtXa->getLocation()));
        goto yBFfp;
        yBFfp:
        $qKtXa->save();
        goto t2Pq5;
        t2Pq5:
        return $qKtXa;
        goto yJ8pB;
        yJ8pB:
    }
}
