<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Service\Jobs\TgRlBFpF3yt9a;
class WZrAOwClqUV8d implements WatermarkTextJobInterface
{
    private $Q1e5h;
    private $kkvUd;
    private $s28PC;
    private $Aj6QZ;
    private $SiK3b;
    public function __construct($OdpJM, $UOGFe, $SaekO, $eX8wo, $rkl9Z)
    {
        goto hNP4a;
        gwP3F:
        $this->Aj6QZ = $SaekO;
        goto JhKtY;
        JhKtY:
        $this->SiK3b = $eX8wo;
        goto yIX8A;
        hNP4a:
        $this->Q1e5h = $OdpJM;
        goto gwP3F;
        FuhEA:
        $this->kkvUd = $UOGFe;
        goto vQ7sD;
        yIX8A:
        $this->s28PC = $rkl9Z;
        goto FuhEA;
        vQ7sD:
    }
    public function putWatermark(string $BFPg9, string $XT0rv) : void
    {
        goto o6B0I;
        o6B0I:
        Log::info("Adding watermark text to image", ['imageId' => $BFPg9]);
        goto SAhB8;
        TKQuO:
        try {
            goto q8sOT;
            LkHBQ:
            $fdqWg = $this->SiK3b->path($ab1g_->getLocation());
            goto QdAUF;
            MKH3q:
            $this->mHbJ502CaRX($yndz3, $XT0rv);
            goto DLTem;
            QdAUF:
            $yndz3 = $this->Q1e5h->call($this, $fdqWg);
            goto YfLM8;
            YfLM8:
            $yndz3->orientate();
            goto MKH3q;
            AjhDL:
            SS6Ab:
            goto gthfw;
            EvkL_:
            Log::error("ID6EZw1DKfqu4 is not on local, might be deleted before put watermark", ['imageId' => $BFPg9]);
            goto GkqMr;
            XQ_lb:
            if (chmod($fdqWg, 0664)) {
                goto SS6Ab;
            }
            goto XORD2;
            q8sOT:
            $ab1g_ = ID6EZw1DKfqu4::findOrFail($BFPg9);
            goto h1Pkx;
            YeROL:
            $yndz3->destroy();
            goto XQ_lb;
            DLTem:
            $yndz3->save($fdqWg);
            goto YeROL;
            h1Pkx:
            if ($this->SiK3b->exists($ab1g_->getLocation())) {
                goto OMEAa;
            }
            goto EvkL_;
            gr47m:
            OMEAa:
            goto LkHBQ;
            GkqMr:
            return;
            goto gr47m;
            PiCm_:
            throw new \Exception('Failed to set final permissions on image file: ' . $fdqWg);
            goto AjhDL;
            XORD2:
            \Log::warning('Failed to set final permissions on image file: ' . $fdqWg);
            goto PiCm_;
            gthfw:
        } catch (\Throwable $hfBp7) {
            goto SJcPp;
            vARXW:
            return;
            goto yTOUZ;
            yTOUZ:
            X_sV3:
            goto cS1Qp;
            SJcPp:
            if (!$hfBp7 instanceof ModelNotFoundException) {
                goto X_sV3;
            }
            goto IVZ4R;
            cS1Qp:
            Log::error("ID6EZw1DKfqu4 is not readable", ['imageId' => $BFPg9, 'error' => $hfBp7->getMessage()]);
            goto DlfYr;
            IVZ4R:
            Log::info("ID6EZw1DKfqu4 has been deleted, discard it", ['imageId' => $BFPg9]);
            goto vARXW;
            DlfYr:
        }
        goto LqTUb;
        SAhB8:
        ini_set('memory_limit', '-1');
        goto TKQuO;
        LqTUb:
    }
    private function mHbJ502CaRX($yndz3, $XT0rv) : void
    {
        goto LeqAx;
        cVXJo:
        $OCPvl = $ZVrUd->m8dbiOiHCTI($Lu5LP, $IPfYY, $XT0rv, true);
        goto U9a4d;
        AMavm:
        $IPfYY = $yndz3->height();
        goto LeNFP;
        LeqAx:
        $Lu5LP = $yndz3->width();
        goto AMavm;
        udUHI:
        $yndz3->insert($lK1vK);
        goto uu3A4;
        U9a4d:
        $this->SiK3b->put($OCPvl, $this->Aj6QZ->get($OCPvl));
        goto AS1PB;
        LeNFP:
        $ZVrUd = new TgRlBFpF3yt9a($this->kkvUd, $this->s28PC, $this->Aj6QZ, $this->SiK3b);
        goto cVXJo;
        AS1PB:
        $lK1vK = $this->Q1e5h->call($this, $this->SiK3b->path($OCPvl));
        goto Y5rCd;
        Y5rCd:
        $lK1vK->opacity(35);
        goto udUHI;
        uu3A4:
    }
}
