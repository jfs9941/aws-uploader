<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\XqAJHKYeaW2YU\Interfaces\ImageInterface;
use Intervention\XqAJHKYeaW2YU\Typography\FontFactory;
class Cxaa8rnKaz018
{
    private $HSLaS;
    private $O1fTR;
    private $f1xKj;
    private $IA8m0;
    public function __construct($TNkgI, $ZSn51, $C6boj, $Rgxn3)
    {
        goto AoyXc;
        DozKt:
        $this->f1xKj = $C6boj;
        goto nkoOl;
        AoyXc:
        $this->O1fTR = $ZSn51;
        goto DozKt;
        nkoOl:
        $this->IA8m0 = $Rgxn3;
        goto G1NdT;
        G1NdT:
        $this->HSLaS = $TNkgI;
        goto uT23B;
        uT23B:
    }
    public function m1xtUeFcf7X(?int $SeDOJ, ?int $vwirX, string $QZS56, bool $Ok3sR = false) : string
    {
        goto mJ6bv;
        GZuBu:
        $P1Jr_ -= $cULBk * 0.4;
        goto s5Xa6;
        MDcnx:
        IvwpX:
        goto M70V8;
        s5Xa6:
        pIpJi:
        goto pYOUC;
        c97EA:
        $P1Jr_ -= $cULBk;
        goto ldiX_;
        M70V8:
        $MSkzT = $this->HSLaS->call($this, $SeDOJ, $vwirX);
        goto nqsP3;
        pYOUC:
        $t6PsR = $vwirX - $l7CT2 - 10;
        goto bav4C;
        OP5J5:
        if (!$this->f1xKj->exists($FlxOy)) {
            goto IvwpX;
        }
        goto Iektc;
        XonnP:
        return $Ok3sR ? $FlxOy : $this->f1xKj->url($FlxOy);
        goto nsKQ1;
        mJ6bv:
        if (!($SeDOJ === null || $vwirX === null)) {
            goto tDMAa;
        }
        goto xXH3p;
        HAFvP:
        $this->IA8m0->put($FlxOy, $MSkzT->toPng());
        goto P04Iq;
        OQbPh:
        $FlxOy = $this->msUYSoFstqA($TS25F, $SeDOJ, $vwirX, $DuUbm, $l7CT2);
        goto OP5J5;
        UpVIr:
        $cULBk = (int) ($P1Jr_ / 80);
        goto c97EA;
        ldiX_:
        if (!($SeDOJ > 1500)) {
            goto pIpJi;
        }
        goto GZuBu;
        bav4C:
        $MSkzT->text($TS25F, $P1Jr_, (int) $t6PsR, function ($fRyqz) use($l7CT2) {
            goto Hju0T;
            gSseM:
            $fRyqz->valign('middle');
            goto JE0y9;
            f173a:
            $fRyqz->size(max($T3PVV, 1));
            goto VRlyR;
            Hju0T:
            $fRyqz->file(public_path($this->O1fTR));
            goto nKyuV;
            JE0y9:
            $fRyqz->align('middle');
            goto tVaP9;
            nKyuV:
            $T3PVV = (int) ($l7CT2 * 1.2);
            goto f173a;
            VRlyR:
            $fRyqz->color('#B9B9B9');
            goto gSseM;
            tVaP9:
        });
        goto HAFvP;
        Iektc:
        return $Ok3sR ? $FlxOy : $this->f1xKj->url($FlxOy);
        goto MDcnx;
        nqsP3:
        $P1Jr_ = $SeDOJ - $DuUbm;
        goto UpVIr;
        Pw3sl:
        tDMAa:
        goto HTTh8;
        qQoc9:
        unset($MSkzT);
        goto XonnP;
        xXH3p:
        throw new \RuntimeException("JbxOPjx4A3DUY dimensions are not available.");
        goto Pw3sl;
        HTTh8:
        $sufIz = 0.1;
        goto X_TbC;
        P04Iq:
        $this->f1xKj->put($FlxOy, $MSkzT->toPng());
        goto qQoc9;
        X_TbC:
        list($l7CT2, $DuUbm, $TS25F) = $this->mGycUIzuoxD($QZS56, $SeDOJ, $sufIz, (float) $SeDOJ / $vwirX);
        goto OQbPh;
        nsKQ1:
    }
    private function msUYSoFstqA(string $QZS56, int $SeDOJ, int $vwirX, int $mrCls, int $kFv0f) : string
    {
        $A98l_ = ltrim($QZS56, '@');
        return "v2/watermark/{$A98l_}/{$SeDOJ}x{$vwirX}_{$mrCls}x{$kFv0f}/text_watermark.png";
    }
    private function mGycUIzuoxD($QZS56, int $SeDOJ, float $e4mKw, float $J6BhQ) : array
    {
        goto WxkmS;
        WxkmS:
        $TS25F = '@' . $QZS56;
        goto iROGD;
        bUi2P:
        return [(int) $o4jtg, $o4jtg * strlen($TS25F) / 1.8, $TS25F];
        goto RPZsg;
        qp7iZ:
        $o4jtg = $DuUbm / (strlen($TS25F) * 0.8);
        goto bUi2P;
        xUx_K:
        if (!($J6BhQ > 1)) {
            goto Tgply;
        }
        goto qp7iZ;
        RPZsg:
        Tgply:
        goto rX87o;
        rX87o:
        $o4jtg = 1 / $J6BhQ * $DuUbm / strlen($TS25F);
        goto tIutX;
        iROGD:
        $DuUbm = (int) ($SeDOJ * $e4mKw);
        goto xUx_K;
        tIutX:
        return [(int) $o4jtg, $DuUbm, $TS25F];
        goto xj0PJ;
        xj0PJ:
    }
}
