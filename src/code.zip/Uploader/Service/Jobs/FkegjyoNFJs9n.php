<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
class FkegjyoNFJs9n implements BlurJobInterface
{
    const f95m3 = 15;
    const clrxQ = 500;
    const xFDkW = 500;
    private $T1B34;
    private $VJN91;
    private $EaJ_d;
    public function __construct($V0xce, $J83Op, $t9atP)
    {
        goto JQ0v4;
        puLy3:
        $this->VJN91 = $J83Op;
        goto mmm1l;
        mmm1l:
        $this->T1B34 = $V0xce;
        goto d1PNb;
        JQ0v4:
        $this->EaJ_d = $t9atP;
        goto puLy3;
        d1PNb:
    }
    public function blur(string $wAkkA) : void
    {
        goto OnUx4;
        wrOqT:
        $this->EaJ_d->put($c3HLM->filename, $Kx1i9);
        goto bpufD;
        bpufD:
        ifeRw:
        goto NpLvL;
        QfR_0:
        throw new \Exception('Failed to set final permissions on image file: ' . $I3L3e);
        goto FIzjp;
        r3FcK:
        $I3L3e = $this->VJN91->put($PI9rG, $lu07a->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto UIJnO;
        UK7cR:
        $lu07a->blur(self::f95m3);
        goto H_Qxq;
        HpEBa:
        ini_set('memory_limit', '-1');
        goto dUdpU;
        EJLhm:
        $lu07a->resize(self::clrxQ, self::xFDkW / $X8aMX);
        goto UK7cR;
        fDCJL:
        if (chmod($I3L3e, 0664)) {
            goto Y6wgH;
        }
        goto IxuAu;
        OnUx4:
        $c3HLM = A9olNyGXhDJnA::findOrFail($wAkkA);
        goto HpEBa;
        IxuAu:
        \Log::warning('Failed to set final permissions on image file: ' . $I3L3e);
        goto QfR_0;
        NpLvL:
        $lu07a = $this->T1B34->call($this, $this->EaJ_d->path($c3HLM->getLocation()));
        goto cMqdG;
        NBtO7:
        $c3HLM->update(['preview' => $PI9rG]);
        goto mV0dw;
        UVHBF:
        $Kx1i9 = $this->VJN91->get($c3HLM->filename);
        goto wrOqT;
        UIJnO:
        unset($lu07a);
        goto fDCJL;
        dUdpU:
        if (!($c3HLM->driver == Pj539Ru5gyMbt::S3 && !$this->EaJ_d->exists($c3HLM->filename))) {
            goto ifeRw;
        }
        goto UVHBF;
        H_Qxq:
        $PI9rG = $this->msiqSPM5Pal($c3HLM);
        goto r3FcK;
        FIzjp:
        Y6wgH:
        goto NBtO7;
        cMqdG:
        $X8aMX = $lu07a->width() / $lu07a->height();
        goto EJLhm;
        mV0dw:
    }
    private function msiqSPM5Pal($lq1ns) : string
    {
        goto XFfXB;
        K_VIr:
        return $QbBrE . $lq1ns->getFilename() . '.jpg';
        goto uIF_2;
        HzUK1:
        D2Hja:
        goto K_VIr;
        L2JOm:
        $this->EaJ_d->makeDirectory($QbBrE, 0755, true);
        goto HzUK1;
        DnjmD:
        if ($this->EaJ_d->exists($QbBrE)) {
            goto D2Hja;
        }
        goto L2JOm;
        ncBh2:
        $QbBrE = dirname($L5bJW) . '/preview/';
        goto DnjmD;
        XFfXB:
        $L5bJW = $lq1ns->getLocation();
        goto ncBh2;
        uIF_2:
    }
}
