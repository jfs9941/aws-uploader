<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Illuminate\Support\Facades\Log;
class LY0JZ7eyOgkDa implements DownloadToLocalJobInterface
{
    private $hFxUe;
    private $Celh5;
    public function __construct($KKbEP, $clScT)
    {
        $this->hFxUe = $KKbEP;
        $this->Celh5 = $clScT;
    }
    public function download(string $SEOXv) : void
    {
        goto Q068V;
        WGiFG:
        if (!$this->Celh5->exists($z620p->getLocation())) {
            goto Y5tiP;
        }
        goto ZgCEB;
        Cw1Ux:
        Log::info("Start download file to local", ['fileId' => $SEOXv, 'filename' => $z620p->getLocation()]);
        goto WGiFG;
        deL0v:
        Y5tiP:
        goto v8qFN;
        ZgCEB:
        return;
        goto deL0v;
        Q068V:
        $z620p = FmmY71eXk0D8U::findOrFail($SEOXv);
        goto Cw1Ux;
        v8qFN:
        $this->Celh5->put($z620p->getLocation(), $this->hFxUe->get($z620p->getLocation()));
        goto B8QPp;
        B8QPp:
    }
}
