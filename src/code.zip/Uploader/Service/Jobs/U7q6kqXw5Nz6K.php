<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class U7q6kqXw5Nz6K implements GenerateThumbnailForVideoInterface
{
    private $y9a4k;
    public function __construct($hnYFq)
    {
        $this->y9a4k = $hnYFq;
    }
    public function generate(string $GMwD5) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $GMwD5);
        $this->y9a4k->createThumbnail($GMwD5);
    }
}
