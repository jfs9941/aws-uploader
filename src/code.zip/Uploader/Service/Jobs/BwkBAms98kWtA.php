<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class BwkBAms98kWtA implements StoreToS3JobInterface
{
    private $GqFb6;
    private $BfyCm;
    private $S0euz;
    public function __construct($WV89v, $ejImE, $t9rFg)
    {
        goto MQMob;
        MQMob:
        $this->BfyCm = $ejImE;
        goto zvRia;
        zvRia:
        $this->S0euz = $t9rFg;
        goto TzIyL;
        TzIyL:
        $this->GqFb6 = $WV89v;
        goto PAjPv;
        PAjPv:
    }
    public function store(string $aK0gt) : void
    {
        goto JZC2m;
        UtXuW:
        $oChgQ = $this->GqFb6->call($this, $ICE3b);
        goto i82rw;
        yw3Kz:
        $this->m6K0we9Slr2($HyAAV, $F1u8w->getLocation());
        goto volIo;
        n_WxO:
        return;
        goto LfG1p;
        G33RP:
        Log::info("MpPzMcfcRTISZ stored to S3, update the children attachments", ['fileId' => $aK0gt]);
        goto RoOqB;
        QZi7k:
        if (!($oSdqz && $this->S0euz->exists($oSdqz))) {
            goto vzFiQ;
        }
        goto cqEID;
        kDX9R:
        vzFiQ:
        goto gBcuK;
        A56xl:
        return;
        goto uHNmA;
        gBcuK:
        if (!($F1u8w->getAttribute('preview') && $this->S0euz->exists($F1u8w->getAttribute('preview')))) {
            goto Qb1Ua;
        }
        goto mGgLM;
        DdLv4:
        $this->BfyCm->put($F1u8w->getAttribute('preview'), $this->S0euz->get($F1u8w->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $fgJJ0->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto MYEKa;
        volIo:
        $oSdqz = $F1u8w->getAttribute('thumbnail');
        goto QZi7k;
        HOVwC:
        Log::info("MpPzMcfcRTISZ has been deleted, discard it", ['fileId' => $aK0gt]);
        goto n_WxO;
        LfG1p:
        CoI6k:
        goto Mp1VL;
        uHNmA:
        FFuoe:
        goto SfkWe;
        cqEID:
        $ICE3b = $this->S0euz->path($oSdqz);
        goto UtXuW;
        mGgLM:
        $SjjXB = $this->S0euz->path($F1u8w->getAttribute('preview'));
        goto jF2dO;
        p14nh:
        if (!$F1u8w->update(['driver' => ZuZC67ch9j73R::S3, 'status' => IOEDyer18cpSA::FINISHED])) {
            goto FFuoe;
        }
        goto G33RP;
        C7I7m:
        if ($F1u8w) {
            goto CoI6k;
        }
        goto HOVwC;
        RoOqB:
        MpPzMcfcRTISZ::where('parent_id', $aK0gt)->update(['driver' => ZuZC67ch9j73R::S3, 'preview' => $F1u8w->getAttribute('preview'), 'thumbnail' => $F1u8w->getAttribute('thumbnail')]);
        goto A56xl;
        Mp1VL:
        $HyAAV = $this->S0euz->path($F1u8w->getLocation());
        goto yw3Kz;
        i82rw:
        $this->BfyCm->put($F1u8w->getAttribute('thumbnail'), $this->S0euz->get($oSdqz), ['visibility' => 'public', 'ContentType' => $oChgQ->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto kDX9R;
        jF2dO:
        $fgJJ0 = $this->GqFb6->call($this, $SjjXB);
        goto DdLv4;
        MYEKa:
        Qb1Ua:
        goto p14nh;
        JZC2m:
        $F1u8w = MpPzMcfcRTISZ::findOrFail($aK0gt);
        goto C7I7m;
        SfkWe:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $aK0gt]);
        goto BqctS;
        BqctS:
    }
    private function m6K0we9Slr2($DxQhq, $jJGiN, $ZESiZ = '')
    {
        goto J0wPY;
        g7Ynf:
        try {
            $qKtXa = $this->GqFb6->call($this, $DxQhq);
            $this->BfyCm->put($jJGiN, $this->S0euz->get($jJGiN), ['visibility' => 'public', 'ContentType' => $qKtXa->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $z6tFS) {
            Log::error("Failed to upload image to S3", ['s3Path' => $jJGiN, 'error' => $z6tFS->getMessage()]);
        }
        goto emQai;
        K43nN:
        $DxQhq = str_replace('.jpg', $ZESiZ, $DxQhq);
        goto HHxwE;
        HHxwE:
        $jJGiN = str_replace('.jpg', $ZESiZ, $jJGiN);
        goto PEQxI;
        PEQxI:
        PcXD6:
        goto g7Ynf;
        J0wPY:
        if (!$ZESiZ) {
            goto PcXD6;
        }
        goto K43nN;
        emQai:
    }
}
