<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class NHqUenz3Xezly
{
    private $MwLYv;
    private $meL4o;
    public function __construct(int $dG1OW, int $EkDbm)
    {
        goto iI8Nb;
        E17SE:
        if (!($EkDbm <= 0)) {
            goto rr65t;
        }
        goto Y0w_x;
        AVWoT:
        dQqQF:
        goto E17SE;
        hFNwy:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto AVWoT;
        iI8Nb:
        if (!($dG1OW <= 0)) {
            goto dQqQF;
        }
        goto hFNwy;
        Vh1fb:
        $this->MwLYv = $dG1OW;
        goto RlfoB;
        Y0w_x:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto g2Twd;
        g2Twd:
        rr65t:
        goto Vh1fb;
        RlfoB:
        $this->meL4o = $EkDbm;
        goto mE_eB;
        mE_eB:
    }
    private static function m68O5CenQxi($MwzI6, string $YdTn1 = 'floor') : int
    {
        goto iFyc4;
        Qr0Wj:
        if (!(is_float($MwzI6) && $MwzI6 == floor($MwzI6) && (int) $MwzI6 % 2 === 0)) {
            goto Jz3D7;
        }
        goto tNoaG;
        j4H03:
        return $MwzI6;
        goto rAk5y;
        NIZsa:
        a8agp:
        goto t7mpA;
        rAk5y:
        iwrTW:
        goto Qr0Wj;
        d0Xc8:
        switch (strtolower($YdTn1)) {
            case 'ceil':
                return (int) (ceil($MwzI6 / 2) * 2);
            case 'round':
                return (int) (round($MwzI6 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($MwzI6 / 2) * 2);
        }
        goto NIZsa;
        iFyc4:
        if (!(is_int($MwzI6) && $MwzI6 % 2 === 0)) {
            goto iwrTW;
        }
        goto j4H03;
        tNoaG:
        return (int) $MwzI6;
        goto AozKy;
        AozKy:
        Jz3D7:
        goto d0Xc8;
        t7mpA:
        ZxwZZ:
        goto pddRF;
        pddRF:
    }
    public function mTeFmek5ryr(string $o7n68 = 'floor') : array
    {
        goto U3r1e;
        NLuJz:
        if ($this->MwLYv >= $this->meL4o) {
            goto z1JWM;
        }
        goto fEN8z;
        ibDvg:
        rIdPA:
        goto S8Idf;
        PW6tD:
        $WPTZc = $this->meL4o * $bZG2g;
        goto EV5fJ;
        fEN8z:
        $DygAy = $mEFw_;
        goto vI_Ud;
        U3r1e:
        $mEFw_ = 1080;
        goto QkcGN;
        QkcGN:
        $DygAy = 0;
        goto u2Ak5;
        ZhmYm:
        G1npK:
        goto Qq7A_;
        Rch4f:
        $BNccV = $mEFw_;
        goto N44WL;
        Qq7A_:
        if (!($DygAy < 2)) {
            goto f3T_U;
        }
        goto EgYZf;
        VGNv2:
        if (!($BNccV < 2)) {
            goto rIdPA;
        }
        goto DDLL8;
        EgYZf:
        $DygAy = 2;
        goto K_xpc;
        u2Ak5:
        $BNccV = 0;
        goto NLuJz;
        K_xpc:
        f3T_U:
        goto VGNv2;
        Em_XZ:
        $FyU5G = $this->MwLYv * $bZG2g;
        goto jhg8M;
        N44WL:
        $bZG2g = $BNccV / $this->meL4o;
        goto Em_XZ;
        vZ7LA:
        goto G1npK;
        goto BZxy8;
        jhg8M:
        $DygAy = self::m68O5CenQxi(round($FyU5G), $o7n68);
        goto ZhmYm;
        DDLL8:
        $BNccV = 2;
        goto ibDvg;
        BZxy8:
        z1JWM:
        goto Rch4f;
        EV5fJ:
        $BNccV = self::m68O5CenQxi(round($WPTZc), $o7n68);
        goto vZ7LA;
        S8Idf:
        return ['width' => $DygAy, 'height' => $BNccV];
        goto AN8cQ;
        vI_Ud:
        $bZG2g = $DygAy / $this->MwLYv;
        goto PW6tD;
        AN8cQ:
    }
}
