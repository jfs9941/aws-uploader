<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class FVJYMpcYNuoCy implements GenerateThumbnailJobInterface
{
    const xnKoO = 150;
    const kWMDX = 150;
    private $kAoN_;
    private $cGz6K;
    private $qqa8Q;
    public function __construct($QJMxa, $DAY12, $mv1tg)
    {
        goto DuLGk;
        S9lIp:
        $this->cGz6K = $DAY12;
        goto QRNIc;
        DuLGk:
        $this->kAoN_ = $QJMxa;
        goto S9lIp;
        QRNIc:
        $this->qqa8Q = $mv1tg;
        goto wgUeM;
        wgUeM:
    }
    public function generate(string $tu00C)
    {
        goto aE_iG;
        A0SFJ:
        ini_set('memory_limit', '-1');
        goto R62LQ;
        R62LQ:
        try {
            goto xgbr1;
            vPuNX:
            $h4i8i = VPGaYsuFJzbQ0::findOrFail($tu00C);
            goto d_SPK;
            VeibU:
            $h4i8i->update(['thumbnail' => $fQjwQ, 'status' => WSEQ88VDOa3X0::THUMBNAIL_PROCESSED]);
            goto Mh99c;
            IoukE:
            $DH4gk->orient()->resize(150, 150);
            goto B22_2;
            SUGYH:
            unset($DH4gk);
            goto FXf1W;
            d_SPK:
            $DH4gk = $this->kAoN_->call($this, $jxMWP->path($h4i8i->getLocation()));
            goto IoukE;
            xgbr1:
            $jxMWP = $this->cGz6K;
            goto vPuNX;
            B22_2:
            $fQjwQ = $this->mo6IqO8Nu4K($h4i8i);
            goto d_B1c;
            Mh99c:
            OgJyb:
            goto HZF6j;
            FXf1W:
            if (!($TLCBn !== false)) {
                goto OgJyb;
            }
            goto VeibU;
            d_B1c:
            $TLCBn = $this->qqa8Q->put($fQjwQ, $DH4gk->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto SUGYH;
            HZF6j:
        } catch (ModelNotFoundException $hBzBz) {
            Log::info("VPGaYsuFJzbQ0 has been deleted, discard it", ['imageId' => $tu00C]);
            return;
        } catch (\Exception $hBzBz) {
            Log::error("Failed to generate thumbnail", ['imageId' => $tu00C, 'error' => $hBzBz->getMessage()]);
        }
        goto jh3VN;
        aE_iG:
        Log::info("Generating thumbnail", ['imageId' => $tu00C]);
        goto A0SFJ;
        jh3VN:
    }
    private function mo6IqO8Nu4K(Z3KXO9qO3sUsa $h4i8i) : string
    {
        goto bVazD;
        VgWYH:
        $KjFft = $Ih_l8 . '/' . self::xnKoO . 'X' . self::kWMDX;
        goto caRMe;
        caRMe:
        return $KjFft . '/' . $h4i8i->getFilename() . '.jpg';
        goto Na8xq;
        bVazD:
        $fQjwQ = $h4i8i->getLocation();
        goto KYzkd;
        KYzkd:
        $Ih_l8 = dirname($fQjwQ);
        goto VgWYH;
        Na8xq:
    }
}
