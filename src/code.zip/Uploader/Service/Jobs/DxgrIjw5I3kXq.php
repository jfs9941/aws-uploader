<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DxgrIjw5I3kXq implements GenerateThumbnailJobInterface
{
    const snXAI = 150;
    const mcq5p = 150;
    private $UVc7_;
    private $s3l3u;
    private $z1k21;
    public function __construct($h1yz3, $lKCQu, $R6Lbx)
    {
        goto zVMTj;
        zVMTj:
        $this->UVc7_ = $h1yz3;
        goto J3ttC;
        qZSME:
        $this->z1k21 = $R6Lbx;
        goto WIYi1;
        J3ttC:
        $this->s3l3u = $lKCQu;
        goto qZSME;
        WIYi1:
    }
    public function generate(string $poSkG)
    {
        goto BFE6Y;
        J3MzQ:
        ini_set('memory_limit', '-1');
        goto T_gNf;
        BFE6Y:
        Log::info("Generating thumbnail", ['imageId' => $poSkG]);
        goto J3MzQ;
        T_gNf:
        try {
            goto PiEk0;
            CDCll:
            cAIVg:
            goto IRg1W;
            wFzZf:
            $VSbOm = KZbAaRxCqNUr3::findOrFail($poSkG);
            goto CK6lz;
            yuT2t:
            if (!($D6kcP !== false)) {
                goto cAIVg;
            }
            goto fz_Mm;
            Qccou:
            $D6kcP = $this->z1k21->put($lT4E3, $jtv1J->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto wtDR6;
            wtDR6:
            unset($jtv1J);
            goto yuT2t;
            fz_Mm:
            $VSbOm->update(['thumbnail' => $lT4E3, 'status' => IOOvAXAyKHLW2::THUMBNAIL_PROCESSED]);
            goto CDCll;
            jlVRM:
            $jtv1J->orient()->resize(150, 150);
            goto oxt4W;
            PiEk0:
            $qxxOf = $this->s3l3u;
            goto wFzZf;
            CK6lz:
            $jtv1J = $this->UVc7_->call($this, $qxxOf->path($VSbOm->getLocation()));
            goto jlVRM;
            oxt4W:
            $lT4E3 = $this->m779BRmUrdc($VSbOm);
            goto Qccou;
            IRg1W:
        } catch (ModelNotFoundException $RUf1Z) {
            Log::info("KZbAaRxCqNUr3 has been deleted, discard it", ['imageId' => $poSkG]);
            return;
        } catch (\Exception $RUf1Z) {
            Log::error("Failed to generate thumbnail", ['imageId' => $poSkG, 'error' => $RUf1Z->getMessage()]);
        }
        goto LjhJR;
        LjhJR:
    }
    private function m779BRmUrdc(HtHJXf7xellNX $VSbOm) : string
    {
        goto TC0_l;
        sKozU:
        $CAGGG = $T2ESg . '/' . self::snXAI . 'X' . self::mcq5p;
        goto cFGFu;
        njDIX:
        $T2ESg = dirname($lT4E3);
        goto sKozU;
        cFGFu:
        return $CAGGG . '/' . $VSbOm->getFilename() . '.jpg';
        goto I9b65;
        TC0_l:
        $lT4E3 = $VSbOm->getLocation();
        goto njDIX;
        I9b65:
    }
}
