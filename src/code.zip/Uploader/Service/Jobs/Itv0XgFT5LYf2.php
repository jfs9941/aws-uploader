<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
class Itv0XgFT5LYf2 implements BlurVideoJobInterface
{
    const O45L2 = 15;
    const GgqFG = 500;
    const f0GyN = 500;
    private $mwf2R;
    private $Vhcrn;
    private $riMoE;
    public function __construct($eF8NA, $Klx1U, $BP_p5)
    {
        goto O8pcT;
        O8pcT:
        $this->riMoE = $BP_p5;
        goto cf7u9;
        cf7u9:
        $this->Vhcrn = $Klx1U;
        goto SsG4r;
        SsG4r:
        $this->mwf2R = $eF8NA;
        goto Bl819;
        Bl819:
    }
    public function blur(string $mfjeD) : void
    {
        goto Mq0yw;
        e_lKQ:
        $fu4AJ = $fK3zd->width() / $fK3zd->height();
        goto fLDX2;
        dSzgg:
        $fK3zd = $this->mwf2R->call($this, $this->riMoE->path($WHxJl->getAttribute('thumbnail')));
        goto e_lKQ;
        fLDX2:
        $fK3zd->resize(self::GgqFG, self::f0GyN / $fu4AJ);
        goto bxFYy;
        iJX_s:
        GjSIr:
        goto zrb9V;
        W9CuF:
        $this->Vhcrn->put($o70_W, $this->riMoE->get($o70_W));
        goto c8Em0;
        xGLlJ:
        \Log::warning('Failed to set final permissions on image file: ' . $OMYvA);
        goto p5kep;
        Mq0yw:
        Log::info("Blurring for video", ['videoID' => $mfjeD]);
        goto QmjrA;
        QmjrA:
        ini_set('memory_limit', '-1');
        goto c234F;
        tnH2e:
        if (!$WHxJl->getAttribute('thumbnail')) {
            goto Eov1a;
        }
        goto vCOQf;
        RX5bB:
        Eov1a:
        goto L4eEF;
        p5kep:
        throw new \Exception('Failed to set final permissions on image file: ' . $OMYvA);
        goto iJX_s;
        bxFYy:
        $fK3zd->blur(self::O45L2);
        goto NCloq;
        c234F:
        $WHxJl = ZSB2cdrwtZpmk::findOrFail($mfjeD);
        goto tnH2e;
        NCloq:
        $o70_W = $this->msYkutivjiO($WHxJl);
        goto XWXd5;
        XWXd5:
        $OMYvA = $this->riMoE->path($o70_W);
        goto l3FbE;
        c8Em0:
        unset($fK3zd);
        goto afBkx;
        zrb9V:
        $WHxJl->update(['preview' => $o70_W]);
        goto RX5bB;
        afBkx:
        if (chmod($OMYvA, 0664)) {
            goto GjSIr;
        }
        goto xGLlJ;
        l3FbE:
        $fK3zd->save($OMYvA);
        goto W9CuF;
        vCOQf:
        $this->riMoE->put($WHxJl->getAttribute('thumbnail'), $this->Vhcrn->get($WHxJl->getAttribute('thumbnail')));
        goto dSzgg;
        L4eEF:
    }
    private function msYkutivjiO(WmSe4qJ68rckH $pCi_z) : string
    {
        goto rEo8o;
        FFfAp:
        return $Wp3Im . $pCi_z->getFilename() . '.jpg';
        goto r2e4c;
        EUZEE:
        $this->riMoE->makeDirectory($Wp3Im, 0755, true);
        goto LL7lq;
        LL7lq:
        fVM5g:
        goto FFfAp;
        sSdJ3:
        if ($this->riMoE->exists($Wp3Im)) {
            goto fVM5g;
        }
        goto EUZEE;
        rEo8o:
        $J9IgU = $pCi_z->getLocation();
        goto jlLsc;
        jlLsc:
        $Wp3Im = dirname($J9IgU) . '/preview/';
        goto sSdJ3;
        r2e4c:
    }
}
