<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Illuminate\Support\Facades\Log;
class LCkcFQiH4HWmr implements StoreVideoToS3JobInterface
{
    private $zMpm5;
    private $rSfnv;
    private $GRsEs;
    public function __construct($RiWpQ, $uIWH1, $Zywh9)
    {
        goto gcsDX;
        Dzc_g:
        $this->GRsEs = $Zywh9;
        goto GFDyR;
        gcsDX:
        $this->rSfnv = $uIWH1;
        goto Dzc_g;
        GFDyR:
        $this->zMpm5 = $RiWpQ;
        goto xKxWE;
        xKxWE:
    }
    public function store(string $eeXS6) : void
    {
        goto m5QUD;
        m5QUD:
        Log::info('Storing video (local) to S3', ['fileId' => $eeXS6, 'bucketName' => $this->zMpm5]);
        goto e7D78;
        e7D78:
        ini_set('memory_limit', '-1');
        goto kiimb;
        klmh6:
        $pqHkE = N1wF7eNF4lYgo::find($eeXS6);
        goto OoLEp;
        H0Q5W:
        $dSWgf = memory_get_usage();
        goto A3pta;
        SXgJx:
        try {
            goto Kswvj;
            lTFKH:
            $dhkhm = $he4Hj->uploadPart(['Bucket' => $this->zMpm5, 'Key' => $pqHkE->getLocation(), 'UploadId' => $pYyLE, 'PartNumber' => $iDPmV, 'Body' => fread($m7b7F, $ZzjEq)]);
            goto RPGxC;
            xt0XI:
            $pYyLE = $RXeDC['UploadId'];
            goto WfBno;
            X41ab:
            fclose($m7b7F);
            goto GhGPh;
            cmYwu:
            $pqHkE->update(['driver' => PdN71mQX1JeZG::S3, 'status' => A7CVlqbpzhfLD::FINISHED]);
            goto GU3_2;
            bsasU:
            $iDPmV++;
            goto BaEbH;
            RPGxC:
            $Aw6Vd[] = ['PartNumber' => $iDPmV, 'ETag' => $dhkhm['ETag']];
            goto bsasU;
            LWLhC:
            $Aw6Vd = [];
            goto N2qYi;
            d_Ux6:
            R_MVc:
            goto X41ab;
            Kswvj:
            $RXeDC = $he4Hj->createMultipartUpload(['Bucket' => $this->zMpm5, 'Key' => $pqHkE->getLocation(), 'ContentType' => $s1vwz, 'ContentDisposition' => 'inline']);
            goto xt0XI;
            zWQAp:
            if (feof($m7b7F)) {
                goto R_MVc;
            }
            goto lTFKH;
            GU3_2:
            $Zywh9->delete($pqHkE->getLocation());
            goto utzPZ;
            BaEbH:
            goto Ah77w;
            goto d_Ux6;
            WfBno:
            $iDPmV = 1;
            goto LWLhC;
            GhGPh:
            $he4Hj->completeMultipartUpload(['Bucket' => $this->zMpm5, 'Key' => $pqHkE->getLocation(), 'UploadId' => $pYyLE, 'MultipartUpload' => ['Parts' => $Aw6Vd]]);
            goto cmYwu;
            N2qYi:
            Ah77w:
            goto zWQAp;
            utzPZ:
        } catch (AwsException $kJgSA) {
            goto NftWY;
            NftWY:
            if (!isset($pYyLE)) {
                goto lR2KK;
            }
            goto OqLOw;
            ag7yy:
            Log::error('Failed to store video: ' . $pqHkE->getLocation() . ' - ' . $kJgSA->getMessage());
            goto AYaxN;
            OqLOw:
            try {
                $he4Hj->abortMultipartUpload(['Bucket' => $this->zMpm5, 'Key' => $pqHkE->getLocation(), 'UploadId' => $pYyLE]);
            } catch (AwsException $plv_y) {
                Log::error('Error aborting multipart upload: ' . $plv_y->getMessage());
            }
            goto zid1q;
            zid1q:
            lR2KK:
            goto ag7yy;
            AYaxN:
        } finally {
            $kreUc = microtime(true);
            $VUnvt = memory_get_usage();
            $dR0uy = memory_get_peak_usage();
            Log::info('Store N1wF7eNF4lYgo to S3 function resource usage', ['imageId' => $eeXS6, 'execution_time_sec' => $kreUc - $OYvfo, 'memory_usage_mb' => ($VUnvt - $dSWgf) / 1024 / 1024, 'peak_memory_usage_mb' => ($dR0uy - $WT5nk) / 1024 / 1024]);
        }
        goto UVlPt;
        tckmi:
        return;
        goto Ntdc9;
        kiimb:
        $he4Hj = $this->rSfnv->getClient();
        goto hcoeC;
        Ntdc9:
        q3szA:
        goto YFho7;
        KH91t:
        $OYvfo = microtime(true);
        goto H0Q5W;
        iON5h:
        $ZzjEq = 1024 * 1024 * 50;
        goto kA8X2;
        XKD55:
        if ($Zywh9->exists($pqHkE->getLocation())) {
            goto q3szA;
        }
        goto OReg5;
        OoLEp:
        if ($pqHkE) {
            goto U8iet;
        }
        goto bpcjz;
        YFho7:
        $m7b7F = $Zywh9->readStream($pqHkE->getLocation());
        goto iON5h;
        Vy3ci:
        U8iet:
        goto XKD55;
        OReg5:
        Log::error("[LCkcFQiH4HWmr] File not found, discard it ", ['video' => $pqHkE->getLocation()]);
        goto tckmi;
        hcoeC:
        $Zywh9 = $this->GRsEs;
        goto klmh6;
        A3pta:
        $WT5nk = memory_get_peak_usage();
        goto SXgJx;
        FTn1y:
        return;
        goto Vy3ci;
        kA8X2:
        $s1vwz = $Zywh9->mimeType($pqHkE->getLocation());
        goto KH91t;
        bpcjz:
        Log::info("N1wF7eNF4lYgo has been deleted, discard it", ['fileId' => $eeXS6]);
        goto FTn1y;
        UVlPt:
    }
}
