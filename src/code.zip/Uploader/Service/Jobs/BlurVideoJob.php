<?php

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FileInterface;
use Jfs\Uploader\Core\Video;

class BlurVideoJob implements BlurVideoJobInterface
{
    const BLUR_THRESHOLD = 15;
    const FIX_WIDTH = 500;
    const FIX_HEIGHT = 500;
    /**
     * @var \Closure
     */
    private $maker;
    private $s3;
    private $localDisk;
    public function __construct($maker, $s3, $localDisk)
    {
        $this->localDisk = $localDisk;
        $this->s3 = $s3;
        $this->maker = $maker;
    }

    public function blur(string $id): void
    {
        Log::info("Blurring for video", ['videoID' => $id]);
        ini_set('memory_limit', '-1');
        $videoObject = Video::findOrFail($id);
        if ($videoObject->getAttribute('thumbnail')) {
            $this->localDisk->put($videoObject->getAttribute('thumbnail'), $this->s3->get($videoObject->getAttribute('thumbnail')));
            $image = $this->maker->call($this, $this->localDisk->path($videoObject->getAttribute('thumbnail')));

            $ratio = $image->width() / $image->height();
            // fit with the ratio
            $image->resize(self::FIX_WIDTH, self::FIX_HEIGHT / $ratio);
            $image->blur(self::BLUR_THRESHOLD);
            $previewPath = $this->createPath($videoObject);
            $absPreviewPath = $this->localDisk->path($previewPath);
            $image->save($absPreviewPath);
            $this->s3->put($previewPath, $this->localDisk->get($previewPath));
            $image->destroy();
            if (!chmod($absPreviewPath, 0664)) {
                \Log::warning('Failed to set final permissions on image file: ' . $absPreviewPath);
                throw new \Exception('Failed to set final permissions on image file: ' . $absPreviewPath);
            }
            $videoObject->update([
                'preview' => $previewPath,
            ]);
        }
    }

    private function createPath(FileInterface $imageObject): string
    {
        $path = $imageObject->getLocation();
        $folder = dirname($path) . '/preview/';

        if (!$this->localDisk->exists($folder)) {
            $this->localDisk->makeDirectory($folder, 0755, true);
        }

        return $folder .  $imageObject->getFilename() . '.jpg';
    }
}
