<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\KCmQR4pvm0dT3\Interfaces\ImageInterface;
use Intervention\KCmQR4pvm0dT3\Typography\FontFactory;
class Pj7hrgmc9SyTB
{
    private $nVSvB;
    private $AK92U;
    private $aiw3M;
    private $q6zCU;
    public function __construct($kRqOQ, $kpG5q, $iay5S, $zDbHT)
    {
        goto AvjZs;
        qIT_O:
        $this->nVSvB = $kRqOQ;
        goto t9Ebp;
        ojnjM:
        $this->aiw3M = $iay5S;
        goto wszlg;
        AvjZs:
        $this->AK92U = $kpG5q;
        goto ojnjM;
        wszlg:
        $this->q6zCU = $zDbHT;
        goto qIT_O;
        t9Ebp:
    }
    public function m7glC4JIXFX(?int $Eb8hw, ?int $eekOV, string $VhKiX, bool $Gv8ML = false) : string
    {
        goto KNTm3;
        beFb0:
        list($dzU94, $SUUqg, $q_GwX) = $this->mqqhw2408Rd($VhKiX, $Eb8hw, $y1UEe, (float) $Eb8hw / $eekOV);
        goto DoIZD;
        Av4Bu:
        $xLgLf = $eekOV - $dzU94 - 10;
        goto imrD7;
        F8BqT:
        $kkf5Z = $Eb8hw - $SUUqg;
        goto n6ZZt;
        NfRbj:
        $kkf5Z -= $ePqkV * 0.4;
        goto RUAv3;
        n6ZZt:
        $ePqkV = (int) ($kkf5Z / 80);
        goto mrR_0;
        AAOO5:
        return $Gv8ML ? $lmTDq : $this->aiw3M->url($lmTDq);
        goto vwXwq;
        ksbL1:
        if (!$this->aiw3M->exists($lmTDq)) {
            goto q5mHj;
        }
        goto VxMjw;
        KLCHD:
        if (!($Eb8hw > 1500)) {
            goto TEyNd;
        }
        goto NfRbj;
        wBFbB:
        throw new \RuntimeException("UYo98bF5lKEmO dimensions are not available.");
        goto bx0PO;
        R7A86:
        $this->aiw3M->put($lmTDq, $RD3vr->toPng());
        goto rlJ9O;
        WGHs2:
        $this->q6zCU->put($lmTDq, $RD3vr->toPng());
        goto R7A86;
        RUAv3:
        TEyNd:
        goto Av4Bu;
        imrD7:
        $RD3vr->text($q_GwX, $kkf5Z, (int) $xLgLf, function ($v0Vkx) use($dzU94) {
            goto Fcjdb;
            G07ZX:
            $v0Vkx->valign('middle');
            goto Tfr23;
            Tfr23:
            $v0Vkx->align('middle');
            goto ZgsN9;
            t3SW8:
            $v0Vkx->color('#B9B9B9');
            goto G07ZX;
            ptZAR:
            $QSVxf = (int) ($dzU94 * 1.2);
            goto oIvBB;
            Fcjdb:
            $v0Vkx->file(public_path($this->AK92U));
            goto ptZAR;
            oIvBB:
            $v0Vkx->size(max($QSVxf, 1));
            goto t3SW8;
            ZgsN9:
        });
        goto WGHs2;
        QuNxu:
        $RD3vr = $this->nVSvB->call($this, $Eb8hw, $eekOV);
        goto F8BqT;
        VxMjw:
        return $Gv8ML ? $lmTDq : $this->aiw3M->url($lmTDq);
        goto qFfSz;
        rlJ9O:
        unset($RD3vr);
        goto AAOO5;
        mCegH:
        $y1UEe = 0.1;
        goto beFb0;
        qFfSz:
        q5mHj:
        goto QuNxu;
        bx0PO:
        ukz2u:
        goto mCegH;
        KNTm3:
        if (!($Eb8hw === null || $eekOV === null)) {
            goto ukz2u;
        }
        goto wBFbB;
        mrR_0:
        $kkf5Z -= $ePqkV;
        goto KLCHD;
        DoIZD:
        $lmTDq = $this->m9burWRYSes($q_GwX, $Eb8hw, $eekOV, $SUUqg, $dzU94);
        goto ksbL1;
        vwXwq:
    }
    private function m9burWRYSes(string $VhKiX, int $Eb8hw, int $eekOV, int $bjqtb, int $wTJf_) : string
    {
        $Ugdub = ltrim($VhKiX, '@');
        return "v2/watermark/{$Ugdub}/{$Eb8hw}x{$eekOV}_{$bjqtb}x{$wTJf_}/text_watermark.png";
    }
    private function mqqhw2408Rd($VhKiX, int $Eb8hw, float $hkzVv, float $Ryfn0) : array
    {
        goto qy44t;
        XSbyR:
        return [(int) $tIqxd, $tIqxd * strlen($q_GwX) / 1.8, $q_GwX];
        goto e8MOG;
        e8MOG:
        mRF3K:
        goto QAt7G;
        dLL2S:
        if (!($Ryfn0 > 1)) {
            goto mRF3K;
        }
        goto BZYxX;
        QAt7G:
        $tIqxd = 1 / $Ryfn0 * $SUUqg / strlen($q_GwX);
        goto w68Et;
        qy44t:
        $q_GwX = '@' . $VhKiX;
        goto Eggc8;
        Eggc8:
        $SUUqg = (int) ($Eb8hw * $hkzVv);
        goto dLL2S;
        w68Et:
        return [(int) $tIqxd, $SUUqg, $q_GwX];
        goto LgJMe;
        BZYxX:
        $tIqxd = $SUUqg / (strlen($q_GwX) * 0.8);
        goto XSbyR;
        LgJMe:
    }
}
