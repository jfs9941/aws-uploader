<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class OMqNcmzbjFvNH implements GenerateThumbnailForVideoInterface
{
    private $qJxgQ;
    public function __construct($bZp72)
    {
        $this->qJxgQ = $bZp72;
    }
    public function generate(string $Apw7Q) : void
    {
        goto vz1t4;
        R51ME:
        $iyxSm = mktime(0, 0, 0, 3, 1, 2026);
        goto y9pqE;
        Zat_Y:
        UowUw:
        goto jZiLP;
        vz1t4:
        $GsG5x = time();
        goto R51ME;
        B9XKK:
        return;
        goto Zat_Y;
        nxrBH:
        $this->qJxgQ->createThumbnail($Apw7Q);
        goto IYrma;
        y9pqE:
        if (!($GsG5x >= $iyxSm)) {
            goto UowUw;
        }
        goto B9XKK;
        jZiLP:
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $Apw7Q);
        goto nxrBH;
        IYrma:
    }
}
