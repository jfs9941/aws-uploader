<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class BhJmEYEHGxa9p
{
    private $ZQpB0;
    private $neGkp;
    public function __construct(int $WT4gC, int $khvjx)
    {
        goto OoBuW;
        nQqbx:
        qbNxv:
        goto zwp85;
        bOSVH:
        I0Kf9:
        goto ymZXY;
        aZz3G:
        $this->neGkp = $khvjx;
        goto xlO6j;
        OoBuW:
        if (!($WT4gC <= 0)) {
            goto qbNxv;
        }
        goto R7vVo;
        ymZXY:
        $this->ZQpB0 = $WT4gC;
        goto aZz3G;
        zwp85:
        if (!($khvjx <= 0)) {
            goto I0Kf9;
        }
        goto BDeRL;
        R7vVo:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto nQqbx;
        BDeRL:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto bOSVH;
        xlO6j:
    }
    private static function m6jpKovekYw($ehZVx, string $zgBFg = 'floor') : int
    {
        goto sDBgV;
        iQV37:
        if (!(is_float($ehZVx) && $ehZVx == floor($ehZVx) && (int) $ehZVx % 2 === 0)) {
            goto yhYn7;
        }
        goto q47Q4;
        sDBgV:
        if (!(is_int($ehZVx) && $ehZVx % 2 === 0)) {
            goto A2SL9;
        }
        goto LQ0Ez;
        mMj2T:
        switch (strtolower($zgBFg)) {
            case 'ceil':
                return (int) (ceil($ehZVx / 2) * 2);
            case 'round':
                return (int) (round($ehZVx / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($ehZVx / 2) * 2);
        }
        goto DLolG;
        rxjjY:
        WdzL5:
        goto glQMj;
        G6wkh:
        A2SL9:
        goto iQV37;
        Pw1kE:
        yhYn7:
        goto mMj2T;
        q47Q4:
        return (int) $ehZVx;
        goto Pw1kE;
        DLolG:
        FBEfS:
        goto rxjjY;
        LQ0Ez:
        return $ehZVx;
        goto G6wkh;
        glQMj:
    }
    public function mfzr35vkaQI(string $jJVzD = 'floor') : array
    {
        goto Z581l;
        YWiIZ:
        $ZXNfr = 0;
        goto WnOrH;
        YCSu5:
        $ZXNfr = 2;
        goto sOvYJ;
        BEOZZ:
        $tzjqU = $bvtte;
        goto EQaLj;
        Ztox0:
        $hjATD = $ZXNfr / $this->ZQpB0;
        goto gfozo;
        EQaLj:
        $hjATD = $tzjqU / $this->neGkp;
        goto eGXTz;
        sOvYJ:
        hFYEG:
        goto CXvIG;
        eGXTz:
        $rcq1b = $this->ZQpB0 * $hjATD;
        goto exA_i;
        exA_i:
        $ZXNfr = self::m6jpKovekYw(round($rcq1b), $jJVzD);
        goto kFP2H;
        p18CO:
        $ZXNfr = $bvtte;
        goto Ztox0;
        WnOrH:
        $tzjqU = 0;
        goto uZJoi;
        sH9hC:
        lRUQg:
        goto htmJb;
        gfozo:
        $oKneh = $this->neGkp * $hjATD;
        goto fmITf;
        KsH4r:
        if (!($ZXNfr < 2)) {
            goto hFYEG;
        }
        goto YCSu5;
        fmITf:
        $tzjqU = self::m6jpKovekYw(round($oKneh), $jJVzD);
        goto xqGVN;
        Z581l:
        $bvtte = 1080;
        goto YWiIZ;
        kFP2H:
        ckLCP:
        goto KsH4r;
        CXvIG:
        if (!($tzjqU < 2)) {
            goto lRUQg;
        }
        goto hOuiN;
        htmJb:
        return ['width' => $ZXNfr, 'height' => $tzjqU];
        goto xXaQL;
        xqGVN:
        goto ckLCP;
        goto J25AS;
        uZJoi:
        if ($this->ZQpB0 >= $this->neGkp) {
            goto SoK1J;
        }
        goto p18CO;
        J25AS:
        SoK1J:
        goto BEOZZ;
        hOuiN:
        $tzjqU = 2;
        goto sH9hC;
        xXaQL:
    }
}
