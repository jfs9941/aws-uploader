<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class P38GAy8os1kzz implements GenerateThumbnailJobInterface
{
    const Afffq = 150;
    const lm_wJ = 150;
    private $lT6tT;
    private $qeI_k;
    private $lCKqa;
    public function __construct($W4G5n, $ShtWH, $T1zaF)
    {
        goto zR0wz;
        T4OBy:
        $this->lCKqa = $T1zaF;
        goto sXP2m;
        zR0wz:
        $this->lT6tT = $W4G5n;
        goto hkz_E;
        hkz_E:
        $this->qeI_k = $ShtWH;
        goto T4OBy;
        sXP2m:
    }
    public function generate(string $DWjir)
    {
        goto VL0AY;
        AhBQo:
        ini_set('memory_limit', '-1');
        goto bWrys;
        VL0AY:
        Log::info("Generating thumbnail", ['imageId' => $DWjir]);
        goto AhBQo;
        bWrys:
        try {
            goto f1oJg;
            CmFFw:
            $xOWpL = $this->lT6tT->call($this, $G3exm->path($KlHaV->getLocation()));
            goto YqmRi;
            gsIDS:
            unset($xOWpL);
            goto nNB3V;
            ehYzy:
            $KlHaV = IQJN6V0t7DC7c::findOrFail($DWjir);
            goto CmFFw;
            oi7_X:
            ePOvQ:
            goto csjwg;
            ZYXLu:
            $Ac7M4 = $this->lCKqa->put($iVcpi, $xOWpL->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto gsIDS;
            f1oJg:
            $G3exm = $this->qeI_k;
            goto ehYzy;
            IlFFf:
            $KlHaV->update(['thumbnail' => $iVcpi, 'status' => H7dtWZ2h5WAty::THUMBNAIL_PROCESSED]);
            goto oi7_X;
            nNB3V:
            if (!($Ac7M4 !== false)) {
                goto ePOvQ;
            }
            goto IlFFf;
            YqmRi:
            $xOWpL->orient()->resize(150, 150);
            goto kmcH5;
            kmcH5:
            $iVcpi = $this->m7L24yaZgjE($KlHaV);
            goto ZYXLu;
            csjwg:
        } catch (ModelNotFoundException $dMDxf) {
            Log::info("IQJN6V0t7DC7c has been deleted, discard it", ['imageId' => $DWjir]);
            return;
        } catch (\Exception $dMDxf) {
            Log::error("Failed to generate thumbnail", ['imageId' => $DWjir, 'error' => $dMDxf->getMessage()]);
        }
        goto HUZuR;
        HUZuR:
    }
    private function m7L24yaZgjE(F43pNWIrUhz3z $KlHaV) : string
    {
        goto prRdn;
        bzvnM:
        $Bn1eW = $F7Xbk . '/' . self::Afffq . 'X' . self::lm_wJ;
        goto i0g08;
        prRdn:
        $iVcpi = $KlHaV->getLocation();
        goto I9XDz;
        i0g08:
        return $Bn1eW . '/' . $KlHaV->getFilename() . '.jpg';
        goto xFh0z;
        I9XDz:
        $F7Xbk = dirname($iVcpi);
        goto bzvnM;
        xFh0z:
    }
}
