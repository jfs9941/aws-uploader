<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class KsIQL55FHbMhr implements StoreToS3JobInterface
{
    private $G25L6;
    private $VV2A8;
    private $QbAvB;
    public function __construct($G6zg7, $oOPBt, $UNh9U)
    {
        goto BFg_Y;
        hQZEJ:
        $this->QbAvB = $UNh9U;
        goto pxG3c;
        BFg_Y:
        $this->VV2A8 = $oOPBt;
        goto hQZEJ;
        pxG3c:
        $this->G25L6 = $G6zg7;
        goto BrZE1;
        BrZE1:
    }
    public function store(string $GhyxD) : void
    {
        goto OHgK4;
        bzFE5:
        Log::info("IZ5shp3JHuftD stored to S3, update the children attachments", ['fileId' => $GhyxD]);
        goto CoB_X;
        OHgK4:
        $PwAVf = IZ5shp3JHuftD::findOrFail($GhyxD);
        goto tqgXZ;
        r8fsr:
        $this->VV2A8->put($PwAVf->getAttribute('thumbnail'), $this->QbAvB->get($ioFuo), ['visibility' => 'public', 'ContentType' => $w6RVC->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Oi5Gl;
        opRan:
        if (!($ioFuo && $this->QbAvB->exists($ioFuo))) {
            goto iy6O4;
        }
        goto a9PNo;
        h5s7b:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $GhyxD]);
        goto XNZrz;
        AA8LD:
        $A71mT = $this->G25L6->call($this, $J1ZcC);
        goto PeOVQ;
        PeOVQ:
        $this->VV2A8->put($PwAVf->getAttribute('preview'), $this->QbAvB->get($PwAVf->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $A71mT->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto I8V3S;
        CoB_X:
        IZ5shp3JHuftD::where('parent_id', $GhyxD)->update(['driver' => GoWVLKcTGnffy::S3, 'preview' => $PwAVf->getAttribute('preview'), 'thumbnail' => $PwAVf->getAttribute('thumbnail')]);
        goto FGfmr;
        XwPR2:
        $w6RVC = $this->G25L6->call($this, $HSPqB);
        goto r8fsr;
        a9PNo:
        $HSPqB = $this->QbAvB->path($ioFuo);
        goto XwPR2;
        FGfmr:
        return;
        goto kyCMT;
        l_YLo:
        if (!($PwAVf->getAttribute('preview') && $this->QbAvB->exists($PwAVf->getAttribute('preview')))) {
            goto Ma4tL;
        }
        goto K6CR2;
        tqgXZ:
        if ($PwAVf) {
            goto mgcUR;
        }
        goto uT12V;
        C53Mx:
        $ioFuo = $PwAVf->getAttribute('thumbnail');
        goto opRan;
        kjzri:
        return;
        goto Ysj6i;
        YmOq7:
        if (!$PwAVf->update(['driver' => GoWVLKcTGnffy::S3, 'status' => LlMDscQw21XKp::FINISHED])) {
            goto IaqGD;
        }
        goto bzFE5;
        I8V3S:
        Ma4tL:
        goto YmOq7;
        mwS9b:
        $yRiLu = $this->QbAvB->path($PwAVf->getLocation());
        goto hyWVf;
        kyCMT:
        IaqGD:
        goto h5s7b;
        uT12V:
        Log::info("IZ5shp3JHuftD has been deleted, discard it", ['fileId' => $GhyxD]);
        goto kjzri;
        hyWVf:
        $this->m2aLWmczc2S($yRiLu, $PwAVf->getLocation());
        goto C53Mx;
        Ysj6i:
        mgcUR:
        goto mwS9b;
        K6CR2:
        $J1ZcC = $this->QbAvB->path($PwAVf->getAttribute('preview'));
        goto AA8LD;
        Oi5Gl:
        iy6O4:
        goto l_YLo;
        XNZrz:
    }
    private function m2aLWmczc2S($gcmGI, $uip8L, $N6gja = '')
    {
        goto OxPMZ;
        Yr5CD:
        jIEHs:
        goto TLTvN;
        HqpR2:
        $gcmGI = str_replace('.jpg', $N6gja, $gcmGI);
        goto Rw31Z;
        Rw31Z:
        $uip8L = str_replace('.jpg', $N6gja, $uip8L);
        goto Yr5CD;
        OxPMZ:
        if (!$N6gja) {
            goto jIEHs;
        }
        goto HqpR2;
        TLTvN:
        try {
            $oaIJp = $this->G25L6->call($this, $gcmGI);
            $this->VV2A8->put($uip8L, $this->QbAvB->get($uip8L), ['visibility' => 'public', 'ContentType' => $oaIJp->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $YIsP2) {
            Log::error("Failed to upload image to S3", ['s3Path' => $uip8L, 'error' => $YIsP2->getMessage()]);
        }
        goto IG4hW;
        IG4hW:
    }
}
