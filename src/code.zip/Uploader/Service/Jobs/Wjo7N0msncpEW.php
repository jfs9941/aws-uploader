<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
class Wjo7N0msncpEW implements DownloadToLocalJobInterface
{
    private $ifs25;
    private $gq_yF;
    public function __construct($PQlIa, $gBW_k)
    {
        $this->ifs25 = $PQlIa;
        $this->gq_yF = $gBW_k;
    }
    public function download(string $PV4mw) : void
    {
        goto SoA63;
        a_rQz:
        return;
        goto zVbiT;
        SoA63:
        $nKKn0 = McTg5Yp6FKC6z::findOrFail($PV4mw);
        goto DIkTk;
        DIkTk:
        Log::info("Start download file to local", ['fileId' => $PV4mw, 'filename' => $nKKn0->getLocation()]);
        goto jLdUk;
        jLdUk:
        if (!$this->gq_yF->exists($nKKn0->getLocation())) {
            goto GzQs8;
        }
        goto a_rQz;
        jEngt:
        $this->gq_yF->put($nKKn0->getLocation(), $this->ifs25->get($nKKn0->getLocation()));
        goto guvJV;
        zVbiT:
        GzQs8:
        goto jEngt;
        guvJV:
    }
}
