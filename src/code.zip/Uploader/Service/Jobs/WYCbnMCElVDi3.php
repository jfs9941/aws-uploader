<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Illuminate\Support\Facades\Log;
class WYCbnMCElVDi3 implements StoreVideoToS3JobInterface
{
    private $SYgsD;
    private $YHwpp;
    private $svYhv;
    public function __construct($ivxnu, $ehLvI, $uLgU3)
    {
        goto h2cUI;
        h2cUI:
        $this->YHwpp = $ehLvI;
        goto J1YWt;
        v1tk3:
        $this->SYgsD = $ivxnu;
        goto P5CZ8;
        J1YWt:
        $this->svYhv = $uLgU3;
        goto v1tk3;
        P5CZ8:
    }
    public function store(string $ShXx2) : void
    {
        goto H7cFg;
        oWckz:
        $xnQNU = $this->YHwpp->getClient();
        goto b6tkg;
        RVbjz:
        $Jq2KY = $uLgU3->readStream($XnDRs->getLocation());
        goto DwxkH;
        e82Gv:
        if ($uLgU3->exists($XnDRs->getLocation())) {
            goto CQH9l;
        }
        goto yBrs0;
        uJqO7:
        return;
        goto cL5Y3;
        lEth_:
        ini_set('memory_limit', '-1');
        goto oWckz;
        DwxkH:
        $PSFks = 1024 * 1024 * 50;
        goto FGSFk;
        C9b1R:
        Log::info("D6fOq8lm3n7T2 has been deleted, discard it", ['fileId' => $ShXx2]);
        goto f667b;
        ZPLkB:
        $xdRdR = memory_get_peak_usage();
        goto cL1Fp;
        cL5Y3:
        CQH9l:
        goto RVbjz;
        b6tkg:
        $uLgU3 = $this->svYhv;
        goto gTkyy;
        mytNc:
        if ($XnDRs) {
            goto MOrl3;
        }
        goto C9b1R;
        CfcLh:
        $yfGDI = memory_get_usage();
        goto ZPLkB;
        FGSFk:
        $sSjas = $uLgU3->mimeType($XnDRs->getLocation());
        goto w_Ml9;
        cL1Fp:
        try {
            goto pe52g;
            ALzbS:
            $PETvI = $xnQNU->uploadPart(['Bucket' => $this->SYgsD, 'Key' => $XnDRs->getLocation(), 'UploadId' => $s12IM, 'PartNumber' => $IaGso, 'Body' => fread($Jq2KY, $PSFks)]);
            goto N5gUA;
            mzZNU:
            $s12IM = $KJZOG['UploadId'];
            goto fz6xS;
            NIMH5:
            $uLgU3->delete($XnDRs->getLocation());
            goto cCldb;
            N5gUA:
            $GU93H[] = ['PartNumber' => $IaGso, 'ETag' => $PETvI['ETag']];
            goto naFW_;
            jxuiK:
            cnlOm:
            goto ERdbO;
            KFPnW:
            fclose($Jq2KY);
            goto i4ysB;
            ERdbO:
            if (feof($Jq2KY)) {
                goto qYtle;
            }
            goto ALzbS;
            naFW_:
            $IaGso++;
            goto O4rs4;
            mvRf0:
            $GU93H = [];
            goto jxuiK;
            MmpNM:
            $XnDRs->update(['driver' => TpPQGsuK0gyw2::S3, 'status' => HGmeWpZQSxAlO::FINISHED]);
            goto NIMH5;
            O4rs4:
            goto cnlOm;
            goto G_N4H;
            G_N4H:
            qYtle:
            goto KFPnW;
            i4ysB:
            $xnQNU->completeMultipartUpload(['Bucket' => $this->SYgsD, 'Key' => $XnDRs->getLocation(), 'UploadId' => $s12IM, 'MultipartUpload' => ['Parts' => $GU93H]]);
            goto MmpNM;
            fz6xS:
            $IaGso = 1;
            goto mvRf0;
            pe52g:
            $KJZOG = $xnQNU->createMultipartUpload(['Bucket' => $this->SYgsD, 'Key' => $XnDRs->getLocation(), 'ContentType' => $sSjas, 'ContentDisposition' => 'inline']);
            goto mzZNU;
            cCldb:
        } catch (AwsException $KY3Rq) {
            goto FyuYC;
            YIWqc:
            try {
                $xnQNU->abortMultipartUpload(['Bucket' => $this->SYgsD, 'Key' => $XnDRs->getLocation(), 'UploadId' => $s12IM]);
            } catch (AwsException $Y41qG) {
                Log::error('Error aborting multipart upload: ' . $Y41qG->getMessage());
            }
            goto itJf2;
            XlECb:
            Log::error('Failed to store video: ' . $XnDRs->getLocation() . ' - ' . $KY3Rq->getMessage());
            goto Afxg2;
            FyuYC:
            if (!isset($s12IM)) {
                goto rxrLS;
            }
            goto YIWqc;
            itJf2:
            rxrLS:
            goto XlECb;
            Afxg2:
        } finally {
            $w1aby = microtime(true);
            $u5HI9 = memory_get_usage();
            $LDlnt = memory_get_peak_usage();
            Log::info('Store D6fOq8lm3n7T2 to S3 function resource usage', ['imageId' => $ShXx2, 'execution_time_sec' => $w1aby - $NPFCL, 'memory_usage_mb' => ($u5HI9 - $yfGDI) / 1024 / 1024, 'peak_memory_usage_mb' => ($LDlnt - $xdRdR) / 1024 / 1024]);
        }
        goto LUt5s;
        w_Ml9:
        $NPFCL = microtime(true);
        goto CfcLh;
        yBrs0:
        Log::error("[WYCbnMCElVDi3] File not found, discard it ", ['video' => $XnDRs->getLocation()]);
        goto uJqO7;
        E0JlP:
        MOrl3:
        goto e82Gv;
        gTkyy:
        $XnDRs = D6fOq8lm3n7T2::find($ShXx2);
        goto mytNc;
        f667b:
        return;
        goto E0JlP;
        H7cFg:
        Log::info('Storing video (local) to S3', ['fileId' => $ShXx2, 'bucketName' => $this->SYgsD]);
        goto lEth_;
        LUt5s:
    }
}
