<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Illuminate\Support\Facades\Log;
class ZxQfUjZ4fsjtv implements DownloadToLocalJobInterface
{
    private $VJN91;
    private $EaJ_d;
    public function __construct($J83Op, $t9atP)
    {
        $this->VJN91 = $J83Op;
        $this->EaJ_d = $t9atP;
    }
    public function download(string $wAkkA) : void
    {
        goto NzqZJ;
        PMk4Q:
        Log::info("Start download file to local", ['fileId' => $wAkkA, 'filename' => $K9DZL->getLocation()]);
        goto ja9se;
        mWyQu:
        VJ5X2:
        goto xJlp5;
        ja9se:
        if (!$this->EaJ_d->exists($K9DZL->getLocation())) {
            goto VJ5X2;
        }
        goto Ml6Dm;
        NzqZJ:
        $K9DZL = A9olNyGXhDJnA::findOrFail($wAkkA);
        goto PMk4Q;
        Ml6Dm:
        return;
        goto mWyQu;
        xJlp5:
        $this->EaJ_d->put($K9DZL->getLocation(), $this->VJN91->get($K9DZL->getLocation()));
        goto heuOZ;
        heuOZ:
    }
}
