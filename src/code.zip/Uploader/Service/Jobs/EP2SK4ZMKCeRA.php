<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class EP2SK4ZMKCeRA implements StoreToS3JobInterface
{
    private $o4nAt;
    private $m2kWg;
    private $Jhhox;
    public function __construct($wpWQD, $Npup8, $bXh5v)
    {
        goto sESZu;
        sESZu:
        $this->m2kWg = $Npup8;
        goto TQ3O4;
        TQ3O4:
        $this->Jhhox = $bXh5v;
        goto Tf6ZU;
        Tf6ZU:
        $this->o4nAt = $wpWQD;
        goto DBEuo;
        DBEuo:
    }
    public function store(string $Brk87) : void
    {
        goto gFMRn;
        fxbuQ:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $Brk87]);
        goto YbvDM;
        MoebH:
        if (!($APOmp->getAttribute('preview') && $this->Jhhox->exists($APOmp->getAttribute('preview')))) {
            goto qZcL_;
        }
        goto cKtny;
        YZJmp:
        if (!$APOmp->update(['driver' => NFXMub09wSQVu::S3, 'status' => ZVJoOgH14iXBq::FINISHED])) {
            goto tRmgC;
        }
        goto cqtqu;
        cqtqu:
        Log::info("OjvWwjWRqBzIO stored to S3, update the children attachments", ['fileId' => $Brk87]);
        goto VsW2A;
        I3ShL:
        $F0ycc = $this->Jhhox->path($APOmp->getLocation());
        goto Nvmcq;
        VsW2A:
        OjvWwjWRqBzIO::where('parent_id', $Brk87)->update(['driver' => NFXMub09wSQVu::S3, 'preview' => $APOmp->getAttribute('preview'), 'thumbnail' => $APOmp->getAttribute('thumbnail')]);
        goto ZHBGw;
        gFMRn:
        $APOmp = OjvWwjWRqBzIO::findOrFail($Brk87);
        goto f5iZC;
        Ohau6:
        return;
        goto TJ1cK;
        HeivR:
        bJeRn:
        goto MoebH;
        epfB3:
        $HDWYI = $APOmp->getAttribute('thumbnail');
        goto OnmQs;
        TJ1cK:
        lxKvs:
        goto I3ShL;
        VahtO:
        $NQQfI = $this->o4nAt->call($this, $NXARd);
        goto MZoGW;
        OqRa0:
        $X71Xh = $this->o4nAt->call($this, $Tp_yG);
        goto CnEe4;
        OnmQs:
        if (!($HDWYI && $this->Jhhox->exists($HDWYI))) {
            goto bJeRn;
        }
        goto hqh_g;
        POa8x:
        qZcL_:
        goto YZJmp;
        ZHBGw:
        return;
        goto ggRJl;
        CnEe4:
        $this->m2kWg->put($APOmp->getAttribute('preview'), $this->Jhhox->get($APOmp->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $X71Xh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto POa8x;
        cKtny:
        $Tp_yG = $this->Jhhox->path($APOmp->getAttribute('preview'));
        goto OqRa0;
        f5iZC:
        if ($APOmp) {
            goto lxKvs;
        }
        goto jcDlj;
        hqh_g:
        $NXARd = $this->Jhhox->path($HDWYI);
        goto VahtO;
        jcDlj:
        Log::info("OjvWwjWRqBzIO has been deleted, discard it", ['fileId' => $Brk87]);
        goto Ohau6;
        MZoGW:
        $this->m2kWg->put($APOmp->getAttribute('thumbnail'), $this->Jhhox->get($HDWYI), ['visibility' => 'public', 'ContentType' => $NQQfI->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto HeivR;
        Nvmcq:
        $this->mZsizycBALV($F0ycc, $APOmp->getLocation());
        goto epfB3;
        ggRJl:
        tRmgC:
        goto fxbuQ;
        YbvDM:
    }
    private function mZsizycBALV($LM49M, $sKixu, $pwCiC = '')
    {
        goto B0Emv;
        T81XT:
        try {
            $Kc1eZ = $this->o4nAt->call($this, $LM49M);
            $this->m2kWg->put($sKixu, $this->Jhhox->get($sKixu), ['visibility' => 'public', 'ContentType' => $Kc1eZ->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $Fa7Tp) {
            Log::error("Failed to upload image to S3", ['s3Path' => $sKixu, 'error' => $Fa7Tp->getMessage()]);
        }
        goto Y0AXt;
        UsQKR:
        $LM49M = str_replace('.jpg', $pwCiC, $LM49M);
        goto g6FjZ;
        g6FjZ:
        $sKixu = str_replace('.jpg', $pwCiC, $sKixu);
        goto iLuyX;
        B0Emv:
        if (!$pwCiC) {
            goto suBPT;
        }
        goto UsQKR;
        iLuyX:
        suBPT:
        goto T81XT;
        Y0AXt:
    }
}
