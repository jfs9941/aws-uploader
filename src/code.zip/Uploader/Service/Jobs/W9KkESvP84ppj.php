<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class W9KkESvP84ppj implements GenerateThumbnailJobInterface
{
    const tKT9k = 150;
    const viX7F = 150;
    private $M9duE;
    private $SPj0U;
    private $F3J1W;
    public function __construct($U2Jsh, $KUQsT, $Tl5V5)
    {
        goto agnCK;
        SKQLO:
        $this->SPj0U = $KUQsT;
        goto pWHx9;
        pWHx9:
        $this->F3J1W = $Tl5V5;
        goto VJZRu;
        agnCK:
        $this->M9duE = $U2Jsh;
        goto SKQLO;
        VJZRu:
    }
    public function generate(string $g5e_r)
    {
        goto ioRFF;
        Gpv5B:
        try {
            goto pnVTR;
            gwR28:
            unset($i7LtR);
            goto BdTqI;
            ZWHpX:
            hyxGZ:
            goto jiTYu;
            BdTqI:
            if (!($gPD7s !== false)) {
                goto hyxGZ;
            }
            goto GUBAo;
            GUBAo:
            $MSkzT->update(['thumbnail' => $FlxOy, 'status' => MUu80sOhINyO3::THUMBNAIL_PROCESSED]);
            goto ZWHpX;
            Xm2mZ:
            $i7LtR = $this->M9duE->call($this, $Rgxn3->path($MSkzT->getLocation()));
            goto VQK3P;
            b2ZXb:
            $MSkzT = XqAJHKYeaW2YU::findOrFail($g5e_r);
            goto Xm2mZ;
            vWO5N:
            $FlxOy = $this->meeZjeiY684($MSkzT);
            goto w_giC;
            w_giC:
            $gPD7s = $this->F3J1W->put($FlxOy, $i7LtR->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto gwR28;
            VQK3P:
            $i7LtR->orient()->resize(150, 150);
            goto vWO5N;
            pnVTR:
            $Rgxn3 = $this->SPj0U;
            goto b2ZXb;
            jiTYu:
        } catch (ModelNotFoundException $X_03M) {
            Log::info("XqAJHKYeaW2YU has been deleted, discard it", ['imageId' => $g5e_r]);
            return;
        } catch (\Exception $X_03M) {
            Log::error("Failed to generate thumbnail", ['imageId' => $g5e_r, 'error' => $X_03M->getMessage()]);
        }
        goto RkDdl;
        ioRFF:
        Log::info("Generating thumbnail", ['imageId' => $g5e_r]);
        goto Ky31v;
        Ky31v:
        ini_set('memory_limit', '-1');
        goto Gpv5B;
        RkDdl:
    }
    private function meeZjeiY684(Fd8NTWwq2cQOc $MSkzT) : string
    {
        goto m3a7F;
        m3a7F:
        $FlxOy = $MSkzT->getLocation();
        goto b7pfk;
        b7pfk:
        $dHOYe = dirname($FlxOy);
        goto qJx19;
        qJx19:
        $fp16C = $dHOYe . '/' . self::tKT9k . 'X' . self::viX7F;
        goto NZ0Xg;
        NZ0Xg:
        return $fp16C . '/' . $MSkzT->getFilename() . '.jpg';
        goto oAGg_;
        oAGg_:
    }
}
