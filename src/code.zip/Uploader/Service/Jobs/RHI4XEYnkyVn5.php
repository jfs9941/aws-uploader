<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
use Jfs\Uploader\Enum\SsxWbUYXracun;
class RHI4XEYnkyVn5 implements StoreToS3JobInterface
{
    private $wEW4b;
    private $dhrkT;
    private $sf39X;
    public function __construct($jlVrW, $v8n0s, $ZqxJI)
    {
        goto BPv_r;
        chDhi:
        $this->wEW4b = $jlVrW;
        goto uN3iK;
        jk04A:
        $this->sf39X = $ZqxJI;
        goto chDhi;
        BPv_r:
        $this->dhrkT = $v8n0s;
        goto jk04A;
        uN3iK:
    }
    public function store(string $cQqZd) : void
    {
        goto JxEgc;
        pYWzv:
        $DU5Lh = $this->wEW4b->call($this, $VlHgt);
        goto IMy9W;
        F8BCC:
        $B2Uy_ = $Vh3Ai->getAttribute('thumbnail');
        goto YaCXr;
        sx_70:
        RJCV_:
        goto ToH5Q;
        JxEgc:
        $Vh3Ai = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
        goto XPono;
        XPono:
        if ($Vh3Ai) {
            goto j1YrC;
        }
        goto ZoHn3;
        uytc6:
        $VlHgt = $this->sf39X->path($B2Uy_);
        goto pYWzv;
        q8rky:
        return;
        goto i1vJZ;
        YaCXr:
        if (!($B2Uy_ && $this->sf39X->exists($B2Uy_))) {
            goto RJCV_;
        }
        goto uytc6;
        I5l93:
        a7cS_:
        goto kdM8J;
        i1vJZ:
        j1YrC:
        goto LD_5J;
        DiCfB:
        $this->dhrkT->put($Vh3Ai->getLocation(), $MpgR7->stream(), ['visibility' => 'public', 'ContentType' => $MpgR7->mime(), 'ContentDisposition' => 'inline']);
        goto F8BCC;
        LD_5J:
        $IJqE5 = $this->sf39X->path($Vh3Ai->getLocation());
        goto pMVNC;
        kdM8J:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $cQqZd]);
        goto KdMZE;
        IMy9W:
        $this->dhrkT->put($Vh3Ai->getAttribute('thumbnail'), $DU5Lh->stream(), ['visibility' => 'public', 'ContentType' => $DU5Lh->mime(), 'ContentDisposition' => 'inline']);
        goto sx_70;
        pMVNC:
        $MpgR7 = $this->wEW4b->call($this, $IJqE5);
        goto DiCfB;
        EKHAz:
        return;
        goto I5l93;
        ZoHn3:
        Log::info("Kx3NMUJqFpl5Q has been deleted, discard it", ['fileId' => $cQqZd]);
        goto q8rky;
        fkEUy:
        Kx3NMUJqFpl5Q::where('parent_id', $cQqZd)->update(['driver' => FW54oEnFetVYj::S3, 'preview' => $Vh3Ai->getAttribute('preview'), 'thumbnail' => $Vh3Ai->getAttribute('thumbnail')]);
        goto EKHAz;
        oPlQk:
        if (!$Vh3Ai->update(['driver' => FW54oEnFetVYj::S3, 'status' => SsxWbUYXracun::FINISHED])) {
            goto a7cS_;
        }
        goto U1t3d;
        rijY7:
        $Z83RY = $this->wEW4b->call($this, $RE6mo);
        goto rBDFG;
        U1t3d:
        Log::info("Kx3NMUJqFpl5Q stored to S3, update the children attachments", ['fileId' => $cQqZd]);
        goto fkEUy;
        p0q1B:
        $RE6mo = $this->sf39X->path($Vh3Ai->getAttribute('preview'));
        goto rijY7;
        n60y1:
        Mqx25:
        goto oPlQk;
        rBDFG:
        $this->dhrkT->put($Vh3Ai->getAttribute('preview'), $Z83RY->stream(), ['visibility' => 'public', 'ContentType' => $Z83RY->mime(), 'ContentDisposition' => 'inline']);
        goto n60y1;
        ToH5Q:
        if (!($Vh3Ai->getAttribute('preview') && $this->sf39X->exists($Vh3Ai->getAttribute('preview')))) {
            goto Mqx25;
        }
        goto p0q1B;
        KdMZE:
    }
}
