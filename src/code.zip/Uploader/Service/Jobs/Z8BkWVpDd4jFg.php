<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
class Z8BkWVpDd4jFg implements CompressJobInterface
{
    const TeEER = 80;
    private $Ie_ZE;
    private $P2FvH;
    public function __construct($jSZw8, $j8mv9)
    {
        $this->Ie_ZE = $jSZw8;
        $this->P2FvH = $j8mv9;
    }
    public function compress(string $FILUb)
    {
        goto is2YL;
        pwZhK:
        $sgrbS = memory_get_usage();
        goto d8OI8;
        is2YL:
        $riJ7Z = microtime(true);
        goto pwZhK;
        E8Y82:
        Log::info("Compress image", ['imageId' => $FILUb]);
        goto IfyKn;
        d8OI8:
        $AgLQ7 = memory_get_peak_usage();
        goto E8Y82;
        IfyKn:
        try {
            goto DeVkY;
            krtBt:
            $FGBix->save();
            goto vTe3m;
            xqHdM:
            $Appsm = $this->P2FvH->path($FGBix->getLocation());
            goto fWhxC;
            CLrwz:
            $FGBix->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $FGBix->getLocation()));
            goto krtBt;
            SD0_6:
            if (!(strtolower($FGBix->getExtension()) === 'png' || strtolower($FGBix->getExtension()) === 'heic')) {
                goto lkec3;
            }
            goto zVTBk;
            fWhxC:
            $k898t = $this->Ie_ZE->call($this, $v2PqH);
            goto VJRl6;
            DeVkY:
            $FGBix = XbYF8aa0XyGnI::findOrFail($FILUb);
            goto wg1qr;
            VJRl6:
            $k898t->orientate();
            goto wDlRr;
            wg1qr:
            $v2PqH = $this->P2FvH->path($FGBix->getLocation());
            goto SD0_6;
            Illbb:
            $k898t->destroy();
            goto GGjYD;
            wDlRr:
            $k898t->save($Appsm, self::TeEER);
            goto Illbb;
            vTe3m:
            lkec3:
            goto xqHdM;
            zVTBk:
            $FGBix->setAttribute('type', 'jpg');
            goto CLrwz;
            GGjYD:
        } catch (ModelNotFoundException) {
            Log::info("XbYF8aa0XyGnI has been deleted, discard it", ['imageId' => $FILUb]);
        } finally {
            $zG72F = microtime(true);
            $ehM97 = memory_get_usage();
            $qkTl8 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $FILUb, 'execution_time_sec' => $zG72F - $riJ7Z, 'memory_usage_mb' => ($ehM97 - $sgrbS) / 1024 / 1024, 'peak_memory_usage_mb' => ($qkTl8 - $AgLQ7) / 1024 / 1024]);
        }
        goto GD98F;
        GD98F:
    }
}
