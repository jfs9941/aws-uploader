<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Illuminate\Support\Facades\Log;
class XWquaRGGlU6YR implements BlurVideoJobInterface
{
    const jDaAv = 15;
    const ICKs3 = 500;
    const vL0T_ = 500;
    private $bLQUI;
    private $YHwpp;
    private $svYhv;
    public function __construct($xA3df, $ehLvI, $uLgU3)
    {
        goto a4Q7i;
        nI8BC:
        $this->bLQUI = $xA3df;
        goto pxLv5;
        d7c3G:
        $this->YHwpp = $ehLvI;
        goto nI8BC;
        a4Q7i:
        $this->svYhv = $uLgU3;
        goto d7c3G;
        pxLv5:
    }
    public function blur(string $ShXx2) : void
    {
        goto Lu06a;
        JSJV2:
        $this->svYhv->put($kty5v->getAttribute('thumbnail'), $this->YHwpp->get($kty5v->getAttribute('thumbnail')));
        goto jaade;
        Ed02N:
        unset($xixtT);
        goto AfVgj;
        qffvC:
        $QZDY1 = $this->mWVJtSErsNd($kty5v);
        goto jzBKs;
        ZVewk:
        $xixtT->save($EBJmp);
        goto LycR8;
        sxx7b:
        ini_set('memory_limit', '-1');
        goto Xnu0q;
        xvnBn:
        $xixtT->blur(self::jDaAv);
        goto qffvC;
        jzBKs:
        $EBJmp = $this->svYhv->path($QZDY1);
        goto ZVewk;
        AfVgj:
        if (chmod($EBJmp, 0664)) {
            goto ZeTGW;
        }
        goto l3mWy;
        TLMr1:
        $kty5v->update(['preview' => $QZDY1]);
        goto zohAM;
        Lu06a:
        Log::info("Blurring for video", ['videoID' => $ShXx2]);
        goto sxx7b;
        jaade:
        $xixtT = $this->bLQUI->call($this, $this->svYhv->path($kty5v->getAttribute('thumbnail')));
        goto a1IdM;
        EAikK:
        if (!$kty5v->getAttribute('thumbnail')) {
            goto YPGQI;
        }
        goto JSJV2;
        Xnu0q:
        $kty5v = D6fOq8lm3n7T2::findOrFail($ShXx2);
        goto EAikK;
        LycR8:
        $this->YHwpp->put($QZDY1, $this->svYhv->get($QZDY1));
        goto Ed02N;
        zTjq6:
        ZeTGW:
        goto TLMr1;
        zohAM:
        YPGQI:
        goto Vx50f;
        a1IdM:
        $dAykE = $xixtT->width() / $xixtT->height();
        goto X_uxq;
        X_uxq:
        $xixtT->resize(self::ICKs3, self::vL0T_ / $dAykE);
        goto xvnBn;
        l3mWy:
        \Log::warning('Failed to set final permissions on image file: ' . $EBJmp);
        goto O4k3v;
        O4k3v:
        throw new \Exception('Failed to set final permissions on image file: ' . $EBJmp);
        goto zTjq6;
        Vx50f:
    }
    private function mWVJtSErsNd(TXpC7TSf51nOz $d6FSb) : string
    {
        goto ttO7h;
        jSJbl:
        return $Nuuvd . $d6FSb->getFilename() . '.jpg';
        goto J7oqp;
        ttO7h:
        $lPyJj = $d6FSb->getLocation();
        goto ceBlf;
        zQwNz:
        eU7Qz:
        goto jSJbl;
        bYGSg:
        $this->svYhv->makeDirectory($Nuuvd, 0755, true);
        goto zQwNz;
        ceBlf:
        $Nuuvd = dirname($lPyJj) . '/preview/';
        goto L09a8;
        L09a8:
        if ($this->svYhv->exists($Nuuvd)) {
            goto eU7Qz;
        }
        goto bYGSg;
        J7oqp:
    }
}
