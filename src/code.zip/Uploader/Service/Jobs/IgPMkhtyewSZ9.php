<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\ArHGBW3uhkrTN;
use backup\Uploader\Core\AvisbyD0IE5xq;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class IgPMkhtyewSZ9 implements ArHGBW3uhkrTN
{
    public function prepareMetadata(string $EQQae) : void
    {
        goto XABtz;
        XABtz:
        $L2Ff8 = AvisbyD0IE5xq::findOrFail($EQQae);
        goto YeWji;
        EBWyk:
        $this->mJrLfb6iCas($L2Ff8);
        goto L598X;
        YeWji:
        if ($L2Ff8->width() > 0 && $L2Ff8->height() > 0) {
            goto lT9GO;
        }
        goto EBWyk;
        L598X:
        lT9GO:
        goto LQ4qA;
        LQ4qA:
    }
    private function mJrLfb6iCas(AvisbyD0IE5xq $hT4WG) : void
    {
        goto Irhbx;
        zRqfb:
        $LNw5K = $JmxQw->getDimensions();
        goto cXiyW;
        cXiyW:
        $hT4WG->update(['duration' => $tFHv6->getDurationInSeconds(), 'resolution' => $LNw5K->getWidth() . 'x' . $LNw5K->getHeight(), 'fps' => $JmxQw->get('r_frame_rate') ?? 30]);
        goto ln6Hl;
        GMYG0:
        $JmxQw = $tFHv6->getVideoStream();
        goto zRqfb;
        oGIFg:
        $tFHv6 = FFMpeg::fromDisk($wNj_Z['path'])->open($hT4WG->getAttribute('filename'));
        goto GMYG0;
        Irhbx:
        $wNj_Z = $hT4WG->getView();
        goto oGIFg;
        ln6Hl:
    }
}
