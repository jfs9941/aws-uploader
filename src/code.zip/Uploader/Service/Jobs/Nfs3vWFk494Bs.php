<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Illuminate\Support\Facades\Log;
class Nfs3vWFk494Bs implements BlurVideoJobInterface
{
    const nH991 = 15;
    const rv7IZ = 500;
    const FO1M2 = 500;
    private $PAMAL;
    private $hFxUe;
    private $Celh5;
    public function __construct($VX8yi, $KKbEP, $clScT)
    {
        goto QYUOo;
        QYUOo:
        $this->Celh5 = $clScT;
        goto BUvq6;
        EEOqk:
        $this->PAMAL = $VX8yi;
        goto qU7eA;
        BUvq6:
        $this->hFxUe = $KKbEP;
        goto EEOqk;
        qU7eA:
    }
    public function blur(string $SEOXv) : void
    {
        goto hr3eq;
        YPb2E:
        $this->Celh5->put($pG4YS->getAttribute('thumbnail'), $this->hFxUe->get($pG4YS->getAttribute('thumbnail')));
        goto xwNur;
        KUb9F:
        $XvBVB = $this->Celh5->path($ANxrm);
        goto KLf8K;
        kaA7V:
        ini_set('memory_limit', '-1');
        goto m5cfX;
        m5cfX:
        $pG4YS = IvT3V5jT5KEaA::findOrFail($SEOXv);
        goto uvhlp;
        c8iKF:
        EgJxr:
        goto vk8P2;
        hOasO:
        $o5smq = $dIrHq->width() / $dIrHq->height();
        goto ndoDM;
        xwNur:
        $dIrHq = $this->PAMAL->call($this, $this->Celh5->path($pG4YS->getAttribute('thumbnail')));
        goto hOasO;
        RZ5qu:
        \Log::warning('Failed to set final permissions on image file: ' . $XvBVB);
        goto Y6jo3;
        Y6jo3:
        throw new \Exception('Failed to set final permissions on image file: ' . $XvBVB);
        goto e7rCS;
        KLf8K:
        $dIrHq->save($XvBVB);
        goto hhTZt;
        D7GQc:
        unset($dIrHq);
        goto Z29ae;
        Q4rob:
        $ANxrm = $this->mrDOi780VNg($pG4YS);
        goto KUb9F;
        hhTZt:
        $this->hFxUe->put($ANxrm, $this->Celh5->get($ANxrm));
        goto D7GQc;
        uvhlp:
        if (!$pG4YS->getAttribute('thumbnail')) {
            goto EgJxr;
        }
        goto YPb2E;
        fjekq:
        $pG4YS->update(['preview' => $ANxrm]);
        goto c8iKF;
        m8Kiv:
        $dIrHq->blur(self::nH991);
        goto Q4rob;
        e7rCS:
        rvKIZ:
        goto fjekq;
        ndoDM:
        $dIrHq->resize(self::rv7IZ, self::FO1M2 / $o5smq);
        goto m8Kiv;
        Z29ae:
        if (chmod($XvBVB, 0664)) {
            goto rvKIZ;
        }
        goto RZ5qu;
        hr3eq:
        Log::info("Blurring for video", ['videoID' => $SEOXv]);
        goto kaA7V;
        vk8P2:
    }
    private function mrDOi780VNg(WEJt1TL92SawT $W2fxH) : string
    {
        goto JnMYz;
        JnMYz:
        $liQkG = $W2fxH->getLocation();
        goto YCBir;
        wiznd:
        return $lxDzB . $W2fxH->getFilename() . '.jpg';
        goto M4ydw;
        ZLNg5:
        lWika:
        goto wiznd;
        FWxbM:
        if ($this->Celh5->exists($lxDzB)) {
            goto lWika;
        }
        goto Wg4PP;
        YCBir:
        $lxDzB = dirname($liQkG) . '/preview/';
        goto FWxbM;
        Wg4PP:
        $this->Celh5->makeDirectory($lxDzB, 0755, true);
        goto ZLNg5;
        M4ydw:
    }
}
