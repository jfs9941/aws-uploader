<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class MFsckEdQzAs6x
{
    private $wVJ_V;
    private $rJ93d;
    private $hFxUe;
    private $IdG3S;
    public function __construct($wc3FE, $OPaP_, $KKbEP, $ftmEm)
    {
        goto O9lDx;
        dtYlw:
        $this->IdG3S = $ftmEm;
        goto fvsn9;
        O9lDx:
        $this->rJ93d = $OPaP_;
        goto AvXHA;
        fvsn9:
        $this->wVJ_V = $wc3FE;
        goto MQrV5;
        AvXHA:
        $this->hFxUe = $KKbEP;
        goto dtYlw;
        MQrV5:
    }
    public function mJjYfi06Dd5(?int $IxHFs, ?int $Ijyqc, string $uZL5Y, bool $zvpl2 = false) : string
    {
        goto MBh3V;
        O86yL:
        list($UOiMW, $T_gwD, $au_c7) = $this->mJredG4GwEI($uZL5Y, $IxHFs, $h8onj, (float) $IxHFs / $Ijyqc);
        goto cEdLR;
        GRhf3:
        $BEbiE -= $IwE5s;
        goto yc80A;
        zRs3K:
        return $zvpl2 ? $liQkG : $this->hFxUe->url($liQkG);
        goto Im6Nt;
        HNWzo:
        $dIrHq->text($au_c7, $BEbiE, (int) $dgHTY, function ($Jr8tP) use($UOiMW) {
            goto DaRR2;
            LSTjX:
            $Jr8tP->size(max($xBkt6, 1));
            goto eQgUQ;
            o3vXq:
            $Jr8tP->align('middle');
            goto K0zp7;
            bbkM0:
            $Jr8tP->valign('middle');
            goto o3vXq;
            eQgUQ:
            $Jr8tP->color([185, 185, 185, 1]);
            goto bbkM0;
            SShbg:
            $xBkt6 = (int) ($UOiMW * 1.2);
            goto LSTjX;
            DaRR2:
            $Jr8tP->file(public_path($this->rJ93d));
            goto SShbg;
            K0zp7:
        });
        goto GRhOx;
        jRrWC:
        $this->hFxUe->put($liQkG, $dIrHq->stream('png'));
        goto zRs3K;
        osY_3:
        $h8onj = 0.1;
        goto O86yL;
        cEdLR:
        $liQkG = $this->my44MDHigxJ($au_c7, $IxHFs, $Ijyqc, $T_gwD, $UOiMW);
        goto QDBgM;
        S1unL:
        $BEbiE = $IxHFs - $T_gwD;
        goto U0niR;
        hO8NC:
        throw new \RuntimeException("IvT3V5jT5KEaA dimensions are not available.");
        goto U8Q2O;
        U8Q2O:
        Evv9C:
        goto osY_3;
        wbJhx:
        J3Zm2:
        goto fQbZV;
        naIBR:
        $dgHTY = $Ijyqc - $UOiMW - 10;
        goto HNWzo;
        yc80A:
        if (!($IxHFs > 1500)) {
            goto r6M84;
        }
        goto o4mLa;
        GRhOx:
        $this->IdG3S->put($liQkG, $dIrHq->stream('png'));
        goto jRrWC;
        MBh3V:
        if (!($IxHFs === null || $Ijyqc === null)) {
            goto Evv9C;
        }
        goto hO8NC;
        vGGQZ:
        return $zvpl2 ? $liQkG : $this->hFxUe->url($liQkG);
        goto wbJhx;
        U0niR:
        $IwE5s = (int) ($BEbiE / 80);
        goto GRhf3;
        Sm64w:
        r6M84:
        goto naIBR;
        o4mLa:
        $BEbiE -= $IwE5s * 0.4;
        goto Sm64w;
        QDBgM:
        if (!$this->hFxUe->exists($liQkG)) {
            goto J3Zm2;
        }
        goto vGGQZ;
        fQbZV:
        $dIrHq = $this->wVJ_V->call($this, $IxHFs, $Ijyqc);
        goto S1unL;
        Im6Nt:
    }
    private function my44MDHigxJ(string $uZL5Y, int $IxHFs, int $Ijyqc, int $qaiTC, int $CBAhl) : string
    {
        $ELAlN = ltrim($uZL5Y, '@');
        return "v2/watermark/{$ELAlN}/{$IxHFs}x{$Ijyqc}_{$qaiTC}x{$CBAhl}/text_watermark.png";
    }
    private function mJredG4GwEI($uZL5Y, int $IxHFs, float $K7h9C, float $o5smq) : array
    {
        goto Z8Y7G;
        ji_33:
        if (!($o5smq > 1)) {
            goto xHh7W;
        }
        goto bD2TJ;
        tYH5Q:
        return [(int) $YbQZf, $T_gwD, $au_c7];
        goto RMy2V;
        MwfxB:
        $T_gwD = (int) ($IxHFs * $K7h9C);
        goto ji_33;
        bD2TJ:
        $YbQZf = $T_gwD / (strlen($au_c7) * 0.8);
        goto pzxik;
        oDVz3:
        $YbQZf = 1 / $o5smq * $T_gwD / strlen($au_c7);
        goto tYH5Q;
        IhDax:
        xHh7W:
        goto oDVz3;
        Z8Y7G:
        $au_c7 = '@' . $uZL5Y;
        goto MwfxB;
        pzxik:
        return [(int) $YbQZf, $YbQZf * strlen($au_c7) / 1.8, $au_c7];
        goto IhDax;
        RMy2V:
    }
}
