<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class JHHC2kywaX0sd implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $S6xyJ) : void
    {
        goto nIww0;
        UsDGI:
        JmckG:
        goto tgusy;
        nIww0:
        $yZXjN = Kt6NO3eUvdER6::findOrFail($S6xyJ);
        goto PGqMs;
        sP0bL:
        $this->mdtcI8Hv35P($yZXjN);
        goto UsDGI;
        PGqMs:
        if ($yZXjN->width() > 0 && $yZXjN->height() > 0) {
            goto JmckG;
        }
        goto sP0bL;
        tgusy:
    }
    private function mdtcI8Hv35P(Kt6NO3eUvdER6 $cS_yX) : void
    {
        goto fYrpy;
        RwYOH:
        $cS_yX->update(['duration' => $DzZNO->getDurationInSeconds(), 'resolution' => $GgKlH->getWidth() . 'x' . $GgKlH->getHeight(), 'fps' => $f5O3B->get('r_frame_rate') ?? 30]);
        goto f2EQ_;
        a5t53:
        $GgKlH = $f5O3B->getDimensions();
        goto RwYOH;
        fYrpy:
        $BxSpy = $cS_yX->getView();
        goto zKEvW;
        UyLuP:
        $f5O3B = $DzZNO->getVideoStream();
        goto a5t53;
        zKEvW:
        $DzZNO = FFMpeg::fromDisk($BxSpy['path'])->open($cS_yX->getAttribute('filename'));
        goto UyLuP;
        f2EQ_:
    }
}
