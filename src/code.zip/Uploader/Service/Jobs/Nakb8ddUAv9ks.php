<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Encoder\GaML3gHcwK0zE;
use Jfs\Uploader\Encoder\H5lPadPHkaEN4;
use Jfs\Uploader\Encoder\QuF8Qm4j71NF7;
use Jfs\Uploader\Encoder\TOxo8bdUFruh2;
use Jfs\Uploader\Encoder\CdioruI85bAAW;
use Jfs\Uploader\Encoder\Xx4ycHeslCT9O;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
use Jfs\Uploader\Service\JCjpIXXHThkPb;
use Webmozart\Assert\Assert;
class Nakb8ddUAv9ks implements MediaEncodeJobInterface
{
    private $ey_Bg;
    private $aB4Qh;
    private $IRlXr;
    private $dj1MR;
    private $AuZBF;
    public function __construct(string $F66z0, $Q0D24, $JGvdR, $ckm9x, $EuYOv)
    {
        goto XfqS_;
        Nihi8:
        $this->dj1MR = $ckm9x;
        goto DTRvf;
        QTdZ5:
        $this->IRlXr = $JGvdR;
        goto Nihi8;
        DTRvf:
        $this->AuZBF = $EuYOv;
        goto xTvSJ;
        XfqS_:
        $this->ey_Bg = $F66z0;
        goto pWBxy;
        pWBxy:
        $this->aB4Qh = $Q0D24;
        goto QTdZ5;
        xTvSJ:
    }
    public function encode(string $R7IrL, string $t1mLK, $XKnUe = true) : void
    {
        goto TkIKo;
        sOfzg:
        try {
            goto eVub2;
            X70Lp:
            if (!$jVTIb) {
                goto e8FbI;
            }
            goto PU0tt;
            eBP7A:
            $DGS9z = $DGS9z->mi3AeKscgdF($ZZnmk);
            goto r2fh7;
            G1mAn:
            if (!($yyWeX && $q2cOY)) {
                goto KJAaW;
            }
            goto ij3Nz;
            QzK8A:
            $DGS9z->mKUmuNn3Qqr($f_gqD->myhsV216ZZ9($cZ20c));
            goto G1mAn;
            Dkgoa:
            $DGS9z->mi3AeKscgdF($cHq8l);
            goto QzK8A;
            ESh_m:
            w47k0:
            goto Dkgoa;
            iycne:
            ge6xD:
            goto ThvXL;
            IiWqm:
            $Et4Ld = new YkQZ80FqJ5eHy($this->dj1MR, $this->AuZBF, $this->IRlXr, $this->aB4Qh);
            goto YyKSq;
            FUH96:
            $NHuxV = $this->moX1v8Dumgs($cZ20c);
            goto gYfT3;
            kHuTl:
            $DGS9z->mi3AeKscgdF($cHq8l);
            goto IzNuN;
            r2fh7:
            eD62U:
            goto v0aFs;
            IzNuN:
            $DGS9z->mKUmuNn3Qqr($f_gqD->myhsV216ZZ9($cZ20c));
            goto jYQws;
            yx_oT:
            $ZZnmk = new H5lPadPHkaEN4('1080p', $qSAQf['width'], $qSAQf['height'], $cZ20c->ma1vi ?? 30);
            goto pSyhM;
            q1LIY:
            $cZ20c->update(['aws_media_converter_job_id' => $R7IrL]);
            goto PbugB;
            YyKSq:
            $jVTIb = $this->mG0ytkY4NAl($Yfl_o, $Et4Ld->mwyFxhSDrij($cZ20c->width(), $cZ20c->height(), $t1mLK));
            goto olJP0;
            qZ8oj:
            Assert::isInstanceOf($cZ20c, B6s4AA1exjQ2T::class);
            goto EfbRW;
            PZEBB:
            $DGS9z = $DGS9z->m16g8cj8fQa(new TOxo8bdUFruh2($NHuxV));
            goto RoqXd;
            ThvXL:
            $yyWeX = $cZ20c->width();
            goto H6koM;
            PU0tt:
            $ZZnmk = $ZZnmk->m3JdvC1XUy1($jVTIb);
            goto kfPwO;
            GeR4Y:
            $R7IrL = $DGS9z->myfNrgFiVrt($this->munWoZCSBKX($cZ20c, $XKnUe));
            goto q1LIY;
            rgULm:
            $qSAQf = $this->mk4UwPwS0tY($yyWeX, $q2cOY);
            goto qBilI;
            olJP0:
            if (!$jVTIb) {
                goto w47k0;
            }
            goto q_jOE;
            RoqXd:
            $cHq8l = new H5lPadPHkaEN4('original', $yyWeX, $q2cOY, $cZ20c->ma1vi ?? 30);
            goto YKMHJ;
            eVub2:
            $cZ20c = B6s4AA1exjQ2T::findOrFail($R7IrL);
            goto qZ8oj;
            jYQws:
            $Yfl_o = app(JCjpIXXHThkPb::class);
            goto IiWqm;
            EfbRW:
            if (!($cZ20c->P462y !== R278OrMF6HCNB::S3)) {
                goto ge6xD;
            }
            goto WLKk3;
            kfPwO:
            e8FbI:
            goto eBP7A;
            H6koM:
            $q2cOY = $cZ20c->height();
            goto FUH96;
            pSyhM:
            $jVTIb = $this->mG0ytkY4NAl($Yfl_o, $Et4Ld->mwyFxhSDrij((int) $qSAQf['width'], (int) $qSAQf['height'], $t1mLK));
            goto X70Lp;
            WLKk3:
            throw new MediaConverterException("B6s4AA1exjQ2T {$cZ20c->id} is not S3 driver");
            goto iycne;
            i7350:
            $DGS9z = $DGS9z->mNWdGy0JfEa($i1LOg);
            goto GeR4Y;
            TgTG7:
            $DGS9z = app(CdioruI85bAAW::class);
            goto PZEBB;
            v0aFs:
            KJAaW:
            goto wpn3t;
            wpn3t:
            Log::info("Set thumbnail for B6s4AA1exjQ2T Job", ['videoId' => $cZ20c->getAttribute('id'), 'duration' => $cZ20c->getAttribute('duration')]);
            goto eId_z;
            qBilI:
            Log::info("Set 1080p resolution for Job", ['width' => $qSAQf['width'], 'height' => $qSAQf['height'], 'originalWidth' => $yyWeX, 'originalHeight' => $q2cOY]);
            goto yx_oT;
            YKMHJ:
            $f_gqD = app(QuF8Qm4j71NF7::class);
            goto kHuTl;
            eId_z:
            $i1LOg = new GaML3gHcwK0zE($cZ20c->NAC7E ?? 1, 2, $f_gqD->m6v0qp8Znam($cZ20c));
            goto i7350;
            q_jOE:
            $cHq8l = $cHq8l->m3JdvC1XUy1($jVTIb);
            goto ESh_m;
            gYfT3:
            Log::info("Set input video for Job", ['s3Uri' => $NHuxV]);
            goto TgTG7;
            ij3Nz:
            if (!$this->mFnB6tL0z8z($yyWeX, $q2cOY)) {
                goto eD62U;
            }
            goto rgULm;
            PbugB:
        } catch (\Exception $nhDP5) {
            Log::info("B6s4AA1exjQ2T has been deleted, discard it", ['fileId' => $R7IrL, 'err' => $nhDP5->getMessage()]);
            return;
        }
        goto XQbjt;
        XINQG:
        ini_set('memory_limit', '-1');
        goto sOfzg;
        TkIKo:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $R7IrL]);
        goto XINQG;
        XQbjt:
    }
    private function munWoZCSBKX(B6s4AA1exjQ2T $cZ20c, $XKnUe) : bool
    {
        goto xQ_A1;
        MY3ji:
        B5880:
        goto cFRRL;
        cFRRL:
        DGWmt:
        goto V6LAJ;
        kbFP0:
        DbZG_:
        goto U0cK0;
        s8OVn:
        switch (true) {
            case $cZ20c->width() * $cZ20c->height() >= 1920 * 1080 && $cZ20c->width() * $cZ20c->height() < 2560 * 1440:
                return $J0pub > 10 * 60;
            case $cZ20c->width() * $cZ20c->height() >= 2560 * 1440 && $cZ20c->width() * $cZ20c->height() < 3840 * 2160:
                return $J0pub > 5 * 60;
            case $cZ20c->width() * $cZ20c->height() >= 3840 * 2160:
                return $J0pub > 3 * 60;
            default:
                return false;
        }
        goto MY3ji;
        xQ_A1:
        if ($XKnUe) {
            goto DbZG_;
        }
        goto tyyEF;
        U0cK0:
        $J0pub = (int) round($cZ20c->getAttribute('duration') ?? 0);
        goto s8OVn;
        tyyEF:
        return false;
        goto kbFP0;
        V6LAJ:
    }
    private function mG0ytkY4NAl(JCjpIXXHThkPb $Yfl_o, string $CY2P6) : ?Xx4ycHeslCT9O
    {
        goto DJhgc;
        sVWIp:
        return new Xx4ycHeslCT9O($N2vMy, 0, 0, null, null);
        goto iZ2T0;
        OD7xD:
        Log::info("Resolve watermark for job with url", ['url' => $CY2P6, 'uri' => $N2vMy]);
        goto Qrvw4;
        DJhgc:
        $N2vMy = $Yfl_o->mxn2CZYthC4($CY2P6);
        goto OD7xD;
        u9RQb:
        return null;
        goto ZWkyP;
        Qrvw4:
        if (!$N2vMy) {
            goto MmQxd;
        }
        goto sVWIp;
        iZ2T0:
        MmQxd:
        goto u9RQb;
        ZWkyP:
    }
    private function mFnB6tL0z8z(int $yyWeX, int $q2cOY) : bool
    {
        return $yyWeX * $q2cOY > 1.5 * (1920 * 1080);
    }
    private function mk4UwPwS0tY(int $yyWeX, int $q2cOY) : array
    {
        $weQJL = new XnjxIRp8nLmSC($yyWeX, $q2cOY);
        return $weQJL->mRphStIkDpY();
    }
    private function moX1v8Dumgs(QfVdOZWAlX8Sl $sYOYc) : string
    {
        goto Dr8fA;
        Dr8fA:
        if (!($sYOYc->P462y == R278OrMF6HCNB::S3)) {
            goto Fv74W;
        }
        goto PYLk3;
        zIYaK:
        return $this->aB4Qh->url($sYOYc->filename);
        goto wEfam;
        PYLk3:
        return 's3://' . $this->ey_Bg . '/' . $sYOYc->filename;
        goto D2qxT;
        D2qxT:
        Fv74W:
        goto zIYaK;
        wEfam:
    }
}
