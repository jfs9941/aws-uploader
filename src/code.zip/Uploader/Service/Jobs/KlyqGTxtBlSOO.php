<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class KlyqGTxtBlSOO implements GenerateThumbnailJobInterface
{
    const fa1k2 = 150;
    const TqGuR = 150;
    private $j6_VZ;
    private $F8ilg;
    private $cbGQe;
    public function __construct($od_dm, $Pkopf, $yQFAj)
    {
        goto DGpqt;
        YPut6:
        $this->F8ilg = $Pkopf;
        goto lpHfA;
        DGpqt:
        $this->j6_VZ = $od_dm;
        goto YPut6;
        lpHfA:
        $this->cbGQe = $yQFAj;
        goto TSSko;
        TSSko:
    }
    public function generate(string $LpGEK)
    {
        goto TIhFj;
        TIhFj:
        Log::info("Generating thumbnail", ['imageId' => $LpGEK]);
        goto gcVrc;
        gcVrc:
        ini_set('memory_limit', '-1');
        goto bK1k2;
        bK1k2:
        try {
            goto dAtb9;
            l1Vt2:
            f9reQ:
            goto zrKlL;
            FMdlc:
            $ZQQzW = X9YHjKrAdcfhe::findOrFail($LpGEK);
            goto AQnjQ;
            MyFP3:
            if (!($ohfmJ !== false)) {
                goto f9reQ;
            }
            goto Yac9i;
            hP7_k:
            unset($szHtk);
            goto MyFP3;
            Yac9i:
            $ZQQzW->update(['thumbnail' => $AvgzF, 'status' => Tbw0jsMnRbOTP::THUMBNAIL_PROCESSED]);
            goto l1Vt2;
            AQnjQ:
            $szHtk = $this->j6_VZ->call($this, $jT0xz->path($ZQQzW->getLocation()));
            goto WwmEB;
            dAtb9:
            $jT0xz = $this->F8ilg;
            goto FMdlc;
            b2Jje:
            $ohfmJ = $this->cbGQe->put($AvgzF, $szHtk->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto hP7_k;
            WwmEB:
            $szHtk->orient()->resize(150, 150);
            goto h2jrc;
            h2jrc:
            $AvgzF = $this->mGZsOkXdFW4($ZQQzW);
            goto b2Jje;
            zrKlL:
        } catch (ModelNotFoundException $OtxN7) {
            Log::info("X9YHjKrAdcfhe has been deleted, discard it", ['imageId' => $LpGEK]);
            return;
        } catch (\Exception $OtxN7) {
            Log::error("Failed to generate thumbnail", ['imageId' => $LpGEK, 'error' => $OtxN7->getMessage()]);
        }
        goto mN8Pl;
        mN8Pl:
    }
    private function mGZsOkXdFW4(ALaATNTmuoFHt $ZQQzW) : string
    {
        goto x39EO;
        i6arb:
        return $MHcJn . '/' . $ZQQzW->getFilename() . '.jpg';
        goto HIFa6;
        kz7as:
        $lWrHD = dirname($AvgzF);
        goto s8i7Z;
        s8i7Z:
        $MHcJn = $lWrHD . '/' . self::fa1k2 . 'X' . self::TqGuR;
        goto i6arb;
        x39EO:
        $AvgzF = $ZQQzW->getLocation();
        goto kz7as;
        HIFa6:
    }
}
