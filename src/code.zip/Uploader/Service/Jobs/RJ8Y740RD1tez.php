<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class RJ8Y740RD1tez
{
    private $BdRZ9;
    private $O3tVw;
    public function __construct(int $cQWp8, int $y7IMm)
    {
        goto DuAyw;
        DuAyw:
        if (!($cQWp8 <= 0)) {
            goto cAHXS;
        }
        goto U2s11;
        U2s11:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto NlSd_;
        kGlV1:
        BuHPD:
        goto gJ54d;
        IkwzP:
        if (!($y7IMm <= 0)) {
            goto BuHPD;
        }
        goto Fgdok;
        NlSd_:
        cAHXS:
        goto IkwzP;
        uQ1lS:
        $this->O3tVw = $y7IMm;
        goto twXgb;
        gJ54d:
        $this->BdRZ9 = $cQWp8;
        goto uQ1lS;
        Fgdok:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto kGlV1;
        twXgb:
    }
    private static function mvjInHWhCr3($OCRwO, string $XgzKD = 'floor') : int
    {
        goto eJCl_;
        Ko7hm:
        return (int) $OCRwO;
        goto ElI7g;
        RdF0f:
        yaT1F:
        goto Q0484;
        UXlhx:
        return $OCRwO;
        goto xPkud;
        ElI7g:
        pom12:
        goto pkKqH;
        rAiMj:
        Yn9oq:
        goto RdF0f;
        xPkud:
        rHeZK:
        goto zIiMZ;
        zIiMZ:
        if (!(is_float($OCRwO) && $OCRwO == floor($OCRwO) && (int) $OCRwO % 2 === 0)) {
            goto pom12;
        }
        goto Ko7hm;
        pkKqH:
        switch (strtolower($XgzKD)) {
            case 'ceil':
                return (int) (ceil($OCRwO / 2) * 2);
            case 'round':
                return (int) (round($OCRwO / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($OCRwO / 2) * 2);
        }
        goto rAiMj;
        eJCl_:
        if (!(is_int($OCRwO) && $OCRwO % 2 === 0)) {
            goto rHeZK;
        }
        goto UXlhx;
        Q0484:
    }
    public function mv96vCYyPUk(string $Ih20V = 'floor') : array
    {
        goto o0enW;
        GPJmL:
        BgJLd:
        goto ET6x2;
        LA8YQ:
        if ($this->BdRZ9 >= $this->O3tVw) {
            goto qL1sV;
        }
        goto U8NrR;
        GoMST:
        $i4ytD = 0;
        goto I2w89;
        otgaF:
        $i4ytD = 2;
        goto GPJmL;
        dpJa_:
        r35LB:
        goto vclmf;
        QPAWM:
        $HP_qC = $i4ytD / $this->BdRZ9;
        goto azgVV;
        L9Rc0:
        YYPEu:
        goto el2sT;
        H6BGs:
        qL1sV:
        goto XbXcu;
        U8NrR:
        $i4ytD = $G1fgk;
        goto QPAWM;
        W2VRb:
        $tdAFy = 2;
        goto L9Rc0;
        Buo4t:
        $tdAFy = self::mvjInHWhCr3(round($R8kCW), $Ih20V);
        goto nnmVE;
        AkHCS:
        $HP_qC = $tdAFy / $this->O3tVw;
        goto lDUIc;
        el2sT:
        return ['width' => $i4ytD, 'height' => $tdAFy];
        goto ZtiFK;
        I2w89:
        $tdAFy = 0;
        goto LA8YQ;
        vclmf:
        if (!($i4ytD < 2)) {
            goto BgJLd;
        }
        goto otgaF;
        o0enW:
        $G1fgk = 1080;
        goto GoMST;
        lDUIc:
        $hKjtB = $this->BdRZ9 * $HP_qC;
        goto mkoQh;
        mkoQh:
        $i4ytD = self::mvjInHWhCr3(round($hKjtB), $Ih20V);
        goto dpJa_;
        ET6x2:
        if (!($tdAFy < 2)) {
            goto YYPEu;
        }
        goto W2VRb;
        nnmVE:
        goto r35LB;
        goto H6BGs;
        azgVV:
        $R8kCW = $this->O3tVw * $HP_qC;
        goto Buo4t;
        XbXcu:
        $tdAFy = $G1fgk;
        goto AkHCS;
        ZtiFK:
    }
}
