<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Service\Jobs\EO53Y7xMvE49W;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class AqTwSUrCn3doM implements WatermarkTextJobInterface
{
    private $awXpN;
    private $eKoQ3;
    private $T2ciG;
    private $tcoQz;
    private $uTYgy;
    public function __construct($ek1iS, $p1Hjh, $v70jj, $kVG4M, $Kl2G5)
    {
        goto Y_P_U;
        dbnDV:
        $this->tcoQz = $v70jj;
        goto brZxl;
        Y_P_U:
        $this->awXpN = $ek1iS;
        goto dbnDV;
        WLk3w:
        $this->T2ciG = $Kl2G5;
        goto eZTNc;
        eZTNc:
        $this->eKoQ3 = $p1Hjh;
        goto kInWe;
        brZxl:
        $this->uTYgy = $kVG4M;
        goto WLk3w;
        kInWe:
    }
    public function putWatermark(string $B5uQ4, string $pfZs5) : void
    {
        goto ilO45;
        cteYV:
        ini_set('memory_limit', '-1');
        goto epOxf;
        epOxf:
        try {
            goto XSmlT;
            eRx2O:
            if ($this->uTYgy->exists($jYl_6->getLocation())) {
                goto xOp1m;
            }
            goto vX6wQ;
            z2nrB:
            throw new \Exception('Failed to set final permissions on image file: ' . $uUtRl);
            goto rnT92;
            qdH2m:
            if (chmod($uUtRl, 0664)) {
                goto o4u7D;
            }
            goto M_nFD;
            R5m9T:
            return;
            goto viQwk;
            vX6wQ:
            Log::error("U0IzvN2kaLZHI is not on local, might be deleted before put watermark", ['imageId' => $B5uQ4]);
            goto R5m9T;
            FOQ0x:
            $this->m7OLxsWEFPD($vVpA1, $pfZs5);
            goto V42lS;
            QJpxY:
            $vVpA1 = $this->awXpN->call($this, $uUtRl);
            goto Myy4o;
            rnT92:
            o4u7D:
            goto kBIHe;
            XSmlT:
            $jYl_6 = U0IzvN2kaLZHI::findOrFail($B5uQ4);
            goto eRx2O;
            viQwk:
            xOp1m:
            goto mfYFF;
            Uw9yI:
            unset($vVpA1);
            goto qdH2m;
            Myy4o:
            $vVpA1->orient();
            goto FOQ0x;
            mfYFF:
            $uUtRl = $this->uTYgy->path($jYl_6->getLocation());
            goto QJpxY;
            V42lS:
            $this->tcoQz->put($uUtRl, $vVpA1->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto Uw9yI;
            M_nFD:
            \Log::warning('Failed to set final permissions on image file: ' . $uUtRl);
            goto z2nrB;
            kBIHe:
        } catch (\Throwable $CKq2b) {
            goto AvzZ3;
            MDXYo:
            Log::error("U0IzvN2kaLZHI is not readable", ['imageId' => $B5uQ4, 'error' => $CKq2b->getMessage()]);
            goto IbbN9;
            DooYe:
            return;
            goto M3coP;
            AvzZ3:
            if (!$CKq2b instanceof ModelNotFoundException) {
                goto N7H4k;
            }
            goto NLfey;
            M3coP:
            N7H4k:
            goto MDXYo;
            NLfey:
            Log::info("U0IzvN2kaLZHI has been deleted, discard it", ['imageId' => $B5uQ4]);
            goto DooYe;
            IbbN9:
        } finally {
            $YrIBh = microtime(true);
            $qjV8v = memory_get_usage();
            $iOIuO = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $B5uQ4, 'execution_time_sec' => $YrIBh - $Sb3tS, 'memory_usage_mb' => ($qjV8v - $Pykf_) / 1024 / 1024, 'peak_memory_usage_mb' => ($iOIuO - $EPciM) / 1024 / 1024]);
        }
        goto EkdjE;
        Rkxyz:
        Log::info("Adding watermark text to image", ['imageId' => $B5uQ4]);
        goto cteYV;
        s6y_U:
        $Pykf_ = memory_get_usage();
        goto uRmdd;
        uRmdd:
        $EPciM = memory_get_peak_usage();
        goto Rkxyz;
        ilO45:
        $Sb3tS = microtime(true);
        goto s6y_U;
        EkdjE:
    }
    private function m7OLxsWEFPD($vVpA1, $pfZs5) : void
    {
        goto oEIMP;
        r2aGp:
        $this->uTYgy->put($JJC3D, $this->tcoQz->get($JJC3D));
        goto Q89iz;
        Q89iz:
        $sU5QQ = $this->awXpN->call($this, $this->uTYgy->path($JJC3D));
        goto AHhdq;
        apOst:
        $JJC3D = $KrdFe->m2ADXial3qe($V0H7W, $nO8OT, $pfZs5, true);
        goto r2aGp;
        oEIMP:
        $V0H7W = $vVpA1->width();
        goto j1cUM;
        AHhdq:
        $vVpA1->place($sU5QQ, 'top-left', 0, 0, 30);
        goto wV4rO;
        j1cUM:
        $nO8OT = $vVpA1->height();
        goto gnKso;
        gnKso:
        $KrdFe = new EO53Y7xMvE49W($this->eKoQ3, $this->T2ciG, $this->tcoQz, $this->uTYgy);
        goto apOst;
        wV4rO:
    }
}
