<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Encoder\WJAE7lcMNfE1y;
use Jfs\Uploader\Encoder\UB8Ev08ZytFP3;
use Jfs\Uploader\Encoder\GYeGOleAx46En;
use Jfs\Uploader\Encoder\ZAV6YqtgGxk5Y;
use Jfs\Uploader\Encoder\Y272Vu6XdYN6L;
use Jfs\Uploader\Encoder\WIGsdnueGe9KG;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Jfs\Uploader\Service\Jobs\ErCveJ2oDsc0T;
use Jfs\Uploader\Service\Jobs\KdjM8JyD6nQG8;
use Jfs\Uploader\Service\HQQLwdzkwB4WZ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class GNwVJVmEUG20B implements MediaEncodeJobInterface
{
    private $VwfNm;
    private $h0iwI;
    private $iHPgt;
    private $VJ5nN;
    private $ujF3W;
    public function __construct(string $XbR1L, $jxMWP, $zeM4q, $TzB9b, $w6xg8)
    {
        goto T6YiF;
        feyk7:
        $this->ujF3W = $w6xg8;
        goto OS_lw;
        T6YiF:
        $this->VwfNm = $XbR1L;
        goto NviOd;
        o_cS8:
        $this->iHPgt = $zeM4q;
        goto jXjhu;
        NviOd:
        $this->h0iwI = $jxMWP;
        goto o_cS8;
        jXjhu:
        $this->VJ5nN = $TzB9b;
        goto feyk7;
        OS_lw:
    }
    public function encode(string $tu00C, string $gKVpe, $wB2MV = true) : void
    {
        goto NG_9J;
        NG_9J:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $tu00C]);
        goto DyPnl;
        DyPnl:
        ini_set('memory_limit', '-1');
        goto K2ofM;
        K2ofM:
        try {
            goto RqO5P;
            HmSCO:
            $UAHgP = new KdjM8JyD6nQG8($this->VJ5nN, $this->ujF3W, $this->iHPgt, $this->h0iwI);
            goto TzuJn;
            AnaqD:
            $QqKs2 = $QqKs2->mJ1YHTdmdO0($f4x0Z);
            goto d9w20;
            kTBaU:
            if (!($fxrDr->Gm9Y9 !== ISqBWmYzjt1eQ::S3)) {
                goto isdJ7;
            }
            goto A1vSM;
            UYhCp:
            if (!$this->mEerqUgSYKq($Nk4Te, $jCfbb)) {
                goto PRyeu;
            }
            goto eJa3d;
            VpJNL:
            $Nk4Te = $fxrDr->width();
            goto SyM7v;
            IVz80:
            $iSeOK = new WJAE7lcMNfE1y($fxrDr->WS8K7 ?? 1, 2, $ilcYW->mLf4sbUROSm($fxrDr));
            goto gNgEw;
            esKec:
            $QqKs2 = $QqKs2->mJgkRIqDk7b(new ZAV6YqtgGxk5Y($zWeiO));
            goto YwC6k;
            nTV_2:
            Assert::isInstanceOf($fxrDr, SNpic2wzC1yT8::class);
            goto kTBaU;
            EYr4Y:
            h0sBQ:
            goto AnaqD;
            LS_t1:
            $Y3Zr2 = app(HQQLwdzkwB4WZ::class);
            goto HmSCO;
            uwauv:
            $QqKs2->mJ1YHTdmdO0($tKe1R);
            goto MSKk8;
            TzuJn:
            $fxioG = $this->mWD7fXi69al($Y3Zr2, $UAHgP->mRm4cjztnmq($fxrDr->width(), $fxrDr->height(), $gKVpe));
            goto OtvS9;
            YwC6k:
            $tKe1R = new UB8Ev08ZytFP3('original', $Nk4Te, $jCfbb, $fxrDr->j4U64 ?? 30);
            goto YPdVP;
            SyM7v:
            $jCfbb = $fxrDr->height();
            goto Bv2Sa;
            LTCH_:
            YDUBu:
            goto Nm_Vs;
            DqCh0:
            $tu00C = $QqKs2->mplZWbqExUn($this->mk3y2pnSuhA($fxrDr, $wB2MV));
            goto Hbd8A;
            qYFXZ:
            $QqKs2 = app(Y272Vu6XdYN6L::class);
            goto esKec;
            MSKk8:
            $QqKs2->m4MqqD6YjaJ($ilcYW->mYJXdDWikdn($fxrDr));
            goto LS_t1;
            q2__0:
            $f4x0Z = new UB8Ev08ZytFP3('1080p', $tI9jV['width'], $tI9jV['height'], $fxrDr->j4U64 ?? 30);
            goto Dgji7;
            A1vSM:
            throw new MediaConverterException("SNpic2wzC1yT8 {$fxrDr->id} is not S3 driver");
            goto Lju4Q;
            oz1gK:
            Log::info("Set 1080p resolution for Job", ['width' => $tI9jV['width'], 'height' => $tI9jV['height'], 'originalWidth' => $Nk4Te, 'originalHeight' => $jCfbb]);
            goto q2__0;
            xClug:
            if (!($Nk4Te && $jCfbb)) {
                goto YDUBu;
            }
            goto UYhCp;
            d9w20:
            PRyeu:
            goto LTCH_;
            N0DBq:
            YGUHx:
            goto HWGn1;
            Hbd8A:
            $fxrDr->update(['aws_media_converter_job_id' => $tu00C]);
            goto lfpNY;
            eJa3d:
            $tI9jV = $this->mn1c2MeQWDA($Nk4Te, $jCfbb);
            goto oz1gK;
            yPnsv:
            $tKe1R = $tKe1R->mKw0MA0RSTd($fxioG);
            goto N0DBq;
            HWGn1:
            $QqKs2->mJ1YHTdmdO0($tKe1R);
            goto tmkiG;
            tmkiG:
            $QqKs2->m4MqqD6YjaJ($ilcYW->mYJXdDWikdn($fxrDr));
            goto xClug;
            RqO5P:
            $fxrDr = SNpic2wzC1yT8::findOrFail($tu00C);
            goto nTV_2;
            YPdVP:
            $ilcYW = app(GYeGOleAx46En::class);
            goto uwauv;
            NLrtM:
            $f4x0Z = $f4x0Z->mKw0MA0RSTd($fxioG);
            goto EYr4Y;
            Dgji7:
            $fxioG = $this->mWD7fXi69al($Y3Zr2, $UAHgP->mRm4cjztnmq((int) $tI9jV['width'], (int) $tI9jV['height'], $gKVpe));
            goto M4ngS;
            Xo1BG:
            Log::info("Set input video for Job", ['s3Uri' => $zWeiO]);
            goto qYFXZ;
            Nm_Vs:
            Log::info("Set thumbnail for SNpic2wzC1yT8 Job", ['videoId' => $fxrDr->getAttribute('id'), 'duration' => $fxrDr->getAttribute('duration')]);
            goto IVz80;
            Lju4Q:
            isdJ7:
            goto VpJNL;
            M4ngS:
            if (!$fxioG) {
                goto h0sBQ;
            }
            goto NLrtM;
            OtvS9:
            if (!$fxioG) {
                goto YGUHx;
            }
            goto yPnsv;
            Bv2Sa:
            $zWeiO = $this->m5C0HpJtdiA($fxrDr);
            goto Xo1BG;
            gNgEw:
            $QqKs2 = $QqKs2->mxOg1xgle9C($iSeOK);
            goto DqCh0;
            lfpNY:
        } catch (\Exception $OaHp2) {
            Log::info("SNpic2wzC1yT8 has been deleted, discard it", ['fileId' => $tu00C, 'err' => $OaHp2->getMessage()]);
            return;
        }
        goto juab_;
        juab_:
    }
    private function mk3y2pnSuhA(SNpic2wzC1yT8 $fxrDr, $wB2MV) : bool
    {
        goto surrN;
        yi8kB:
        UbsTN:
        goto DsVvT;
        KwUQX:
        MipLL:
        goto lkajs;
        surrN:
        if ($wB2MV) {
            goto UbsTN;
        }
        goto jQlHc;
        DsVvT:
        $Vg4SG = (int) round($fxrDr->getAttribute('duration') ?? 0);
        goto OLie2;
        OLie2:
        switch (true) {
            case $fxrDr->width() * $fxrDr->height() >= 1920 * 1080 && $fxrDr->width() * $fxrDr->height() < 2560 * 1440:
                return $Vg4SG > 10 * 60;
            case $fxrDr->width() * $fxrDr->height() >= 2560 * 1440 && $fxrDr->width() * $fxrDr->height() < 3840 * 2160:
                return $Vg4SG > 5 * 60;
            case $fxrDr->width() * $fxrDr->height() >= 3840 * 2160:
                return $Vg4SG > 3 * 60;
            default:
                return false;
        }
        goto lPm1I;
        jQlHc:
        return false;
        goto yi8kB;
        lPm1I:
        RRarR:
        goto KwUQX;
        lkajs:
    }
    private function mWD7fXi69al(HQQLwdzkwB4WZ $Y3Zr2, string $aIReC) : ?WIGsdnueGe9KG
    {
        goto X4ice;
        DGD_K:
        return null;
        goto cYPPI;
        X4ice:
        $xfjjJ = $Y3Zr2->mxS1IntlutZ($aIReC);
        goto Bih7B;
        Bih7B:
        Log::info("Resolve watermark for job with url", ['url' => $aIReC, 'uri' => $xfjjJ]);
        goto Wtmsb;
        ZRS3H:
        return new WIGsdnueGe9KG($xfjjJ, 0, 0, null, null);
        goto x4XaJ;
        Wtmsb:
        if (!$xfjjJ) {
            goto DLbwY;
        }
        goto ZRS3H;
        x4XaJ:
        DLbwY:
        goto DGD_K;
        cYPPI:
    }
    private function mEerqUgSYKq(int $Nk4Te, int $jCfbb) : bool
    {
        return $Nk4Te * $jCfbb > 1.5 * (1920 * 1080);
    }
    private function mn1c2MeQWDA(int $Nk4Te, int $jCfbb) : array
    {
        $g9fbU = new ErCveJ2oDsc0T($Nk4Te, $jCfbb);
        return $g9fbU->mydodEyR78l();
    }
    private function m5C0HpJtdiA(Z3KXO9qO3sUsa $ieBz5) : string
    {
        goto EEqgV;
        pAGxi:
        Rn0If:
        goto LR72v;
        uRmMx:
        return 's3://' . $this->VwfNm . '/' . $ieBz5->filename;
        goto pAGxi;
        EEqgV:
        if (!($ieBz5->Gm9Y9 == ISqBWmYzjt1eQ::S3)) {
            goto Rn0If;
        }
        goto uRmMx;
        LR72v:
        return $this->h0iwI->url($ieBz5->filename);
        goto tHdmq;
        tHdmq:
    }
}
