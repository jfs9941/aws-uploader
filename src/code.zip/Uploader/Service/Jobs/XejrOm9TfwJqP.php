<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Illuminate\Support\Facades\Log;
class XejrOm9TfwJqP implements StoreVideoToS3JobInterface
{
    private $oPVzD;
    private $PxC6l;
    private $MpAl4;
    public function __construct($h2Cp1, $kxhX9, $U2KRS)
    {
        goto cbmOS;
        cbmOS:
        $this->PxC6l = $kxhX9;
        goto U5lwS;
        JQTTm:
        $this->oPVzD = $h2Cp1;
        goto AyDPp;
        U5lwS:
        $this->MpAl4 = $U2KRS;
        goto JQTTm;
        AyDPp:
    }
    public function store(string $S580N) : void
    {
        goto YePnP;
        DVr_m:
        $nR1Wc = microtime(true);
        goto V_i8b;
        Nerxz:
        Log::error("[XejrOm9TfwJqP] File not found, discard it ", ['video' => $rHQOu->getLocation()]);
        goto KnZCW;
        GZYBT:
        ini_set('memory_limit', '-1');
        goto cQVux;
        vv7Ds:
        $LI_iG = $U2KRS->mimeType($rHQOu->getLocation());
        goto DVr_m;
        Guvjr:
        $JYKfw = memory_get_peak_usage();
        goto PbMoP;
        xdnXw:
        if ($U2KRS->exists($rHQOu->getLocation())) {
            goto X2f3T;
        }
        goto Nerxz;
        xeOfg:
        $y09ow = $U2KRS->readStream($rHQOu->getLocation());
        goto lGSjo;
        YePnP:
        Log::info('Storing video (local) to S3', ['fileId' => $S580N, 'bucketName' => $this->oPVzD]);
        goto GZYBT;
        cQVux:
        $ML8Ew = $this->PxC6l->getClient();
        goto cfv9a;
        lGSjo:
        $FTk6S = 1024 * 1024 * 50;
        goto vv7Ds;
        b2VdE:
        $rHQOu = BtruCfJoaSWZ6::find($S580N);
        goto ExJFj;
        eNFWK:
        Log::info("BtruCfJoaSWZ6 has been deleted, discard it", ['fileId' => $S580N]);
        goto kmHu1;
        PbMoP:
        try {
            goto IVHHL;
            x9evA:
            FyyP5:
            goto uAu3D;
            IVHHL:
            $COI2e = $ML8Ew->createMultipartUpload(['Bucket' => $this->oPVzD, 'Key' => $rHQOu->getLocation(), 'ContentType' => $LI_iG, 'ContentDisposition' => 'inline']);
            goto C4_N6;
            Tv3kd:
            $NCegP = [];
            goto x9evA;
            xnPWU:
            $U2KRS->delete($rHQOu->getLocation());
            goto h_oCi;
            axRZc:
            fclose($y09ow);
            goto VIpZ_;
            VIpZ_:
            $ML8Ew->completeMultipartUpload(['Bucket' => $this->oPVzD, 'Key' => $rHQOu->getLocation(), 'UploadId' => $fLy2e, 'MultipartUpload' => ['Parts' => $NCegP]]);
            goto MopFU;
            uAu3D:
            if (feof($y09ow)) {
                goto dAjwA;
            }
            goto N4Y27;
            PK48l:
            $Aljuh = 1;
            goto Tv3kd;
            lmppV:
            $Aljuh++;
            goto q0Ih9;
            vVxok:
            $NCegP[] = ['PartNumber' => $Aljuh, 'ETag' => $Cj8PO['ETag']];
            goto lmppV;
            fO7ms:
            dAjwA:
            goto axRZc;
            N4Y27:
            $Cj8PO = $ML8Ew->uploadPart(['Bucket' => $this->oPVzD, 'Key' => $rHQOu->getLocation(), 'UploadId' => $fLy2e, 'PartNumber' => $Aljuh, 'Body' => fread($y09ow, $FTk6S)]);
            goto vVxok;
            q0Ih9:
            goto FyyP5;
            goto fO7ms;
            MopFU:
            $rHQOu->update(['driver' => McZXbZmlQ53or::S3, 'status' => EHhCBxlsVyz9C::FINISHED]);
            goto xnPWU;
            C4_N6:
            $fLy2e = $COI2e['UploadId'];
            goto PK48l;
            h_oCi:
        } catch (AwsException $ah9h0) {
            goto zEr6Z;
            pHRoQ:
            zuBWt:
            goto fS7zE;
            fS7zE:
            Log::error('Failed to store video: ' . $rHQOu->getLocation() . ' - ' . $ah9h0->getMessage());
            goto OaFMd;
            VSgYq:
            try {
                $ML8Ew->abortMultipartUpload(['Bucket' => $this->oPVzD, 'Key' => $rHQOu->getLocation(), 'UploadId' => $fLy2e]);
            } catch (AwsException $Fs6TC) {
                Log::error('Error aborting multipart upload: ' . $Fs6TC->getMessage());
            }
            goto pHRoQ;
            zEr6Z:
            if (!isset($fLy2e)) {
                goto zuBWt;
            }
            goto VSgYq;
            OaFMd:
        } finally {
            $EX_rn = microtime(true);
            $r_Z2H = memory_get_usage();
            $I57ia = memory_get_peak_usage();
            Log::info('Store BtruCfJoaSWZ6 to S3 function resource usage', ['imageId' => $S580N, 'execution_time_sec' => $EX_rn - $nR1Wc, 'memory_usage_mb' => ($r_Z2H - $xM3o2) / 1024 / 1024, 'peak_memory_usage_mb' => ($I57ia - $JYKfw) / 1024 / 1024]);
        }
        goto OL84I;
        cfv9a:
        $U2KRS = $this->MpAl4;
        goto b2VdE;
        NpLZ8:
        X2f3T:
        goto xeOfg;
        ExJFj:
        if ($rHQOu) {
            goto YafZh;
        }
        goto eNFWK;
        kmHu1:
        return;
        goto u4Dgo;
        u4Dgo:
        YafZh:
        goto xdnXw;
        KnZCW:
        return;
        goto NpLZ8;
        V_i8b:
        $xM3o2 = memory_get_usage();
        goto Guvjr;
        OL84I:
    }
}
