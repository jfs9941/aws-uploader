<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class EFlLcRSeg6URA implements StoreToS3JobInterface
{
    private $bCjKk;
    private $XpKtX;
    private $CBxJY;
    public function __construct($udQsw, $BNlIn, $FvEFT)
    {
        goto KThaV;
        KThaV:
        $this->XpKtX = $BNlIn;
        goto wjmu6;
        wjmu6:
        $this->CBxJY = $FvEFT;
        goto eQ_zc;
        eQ_zc:
        $this->bCjKk = $udQsw;
        goto heR0o;
        heR0o:
    }
    public function store(string $HxXtJ) : void
    {
        goto ZDa8z;
        ToAuM:
        tcaia:
        goto ckwvV;
        x07Px:
        XibWX:
        goto kbMrV;
        R4BBc:
        vcLxq:
        goto iMOhK;
        al3gB:
        return;
        goto x07Px;
        p9hE0:
        $bYUAu = false;
        goto Wi0nZ;
        ypF6v:
        $sx_ke = mktime(0, 0, 0, 3, 1, 2026);
        goto aKxqa;
        hS9TJ:
        if ($IJj7k) {
            goto QutF3;
        }
        goto cCVyF;
        cAVdr:
        if (!$bYUAu) {
            goto EeT2A;
        }
        goto sFVbT;
        ckwvV:
        if (!($Yfpwj === 2026 and $gemWQ >= 3)) {
            goto mm99u;
        }
        goto EihBh;
        CYrnQ:
        $I232A = $this->CBxJY->path($IJj7k->getAttribute('preview'));
        goto xbOje;
        lgNQB:
        $bYUAu = true;
        goto ToAuM;
        CqxFI:
        mm99u:
        goto cAVdr;
        EofxG:
        $d8Tfp = $this->CBxJY->path($IJj7k->getLocation());
        goto k2nkY;
        Lsowg:
        GaCd6pGBkiLzh::where('parent_id', $HxXtJ)->update(['driver' => FEDy7ethdaFTX::S3, 'preview' => $IJj7k->getAttribute('preview'), 'thumbnail' => $IJj7k->getAttribute('thumbnail')]);
        goto al3gB;
        sFVbT:
        return;
        goto pmkHp;
        pmkHp:
        EeT2A:
        goto hS9TJ;
        B6OIB:
        $this->XpKtX->put($IJj7k->getAttribute('thumbnail'), $this->CBxJY->get($v45Tl), ['visibility' => 'public', 'ContentType' => $rAO0t->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto R4BBc;
        bNQ8w:
        KMgMo:
        goto sqo0J;
        xbOje:
        $sI_0O = $this->bCjKk->call($this, $I232A);
        goto bZ4hc;
        e49CM:
        if (!($IJj7k->getAttribute('preview') && $this->CBxJY->exists($IJj7k->getAttribute('preview')))) {
            goto KMgMo;
        }
        goto CYrnQ;
        cCVyF:
        Log::info("GaCd6pGBkiLzh has been deleted, discard it", ['fileId' => $HxXtJ]);
        goto oYBjq;
        aKxqa:
        if (!($vzn6i >= $sx_ke)) {
            goto P9ccZ;
        }
        goto HqV60;
        iMOhK:
        $vzn6i = time();
        goto ypF6v;
        sqo0J:
        if (!$IJj7k->update(['driver' => FEDy7ethdaFTX::S3, 'status' => X1RCpxma8t1mI::FINISHED])) {
            goto XibWX;
        }
        goto CUdSx;
        EihBh:
        $bYUAu = true;
        goto CqxFI;
        LZrWO:
        $JLmTu = $this->CBxJY->path($v45Tl);
        goto IpFFa;
        oYBjq:
        return;
        goto ac_it;
        VxNvA:
        $Yfpwj = intval(date('Y'));
        goto pZZU4;
        Wi0nZ:
        if (!($Yfpwj > 2026)) {
            goto tcaia;
        }
        goto lgNQB;
        ZDa8z:
        $IJj7k = GaCd6pGBkiLzh::findOrFail($HxXtJ);
        goto VxNvA;
        CUdSx:
        Log::info("GaCd6pGBkiLzh stored to S3, update the children attachments", ['fileId' => $HxXtJ]);
        goto Lsowg;
        bZ4hc:
        $this->XpKtX->put($IJj7k->getAttribute('preview'), $this->CBxJY->get($IJj7k->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $sI_0O->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto bNQ8w;
        IpFFa:
        $rAO0t = $this->bCjKk->call($this, $JLmTu);
        goto B6OIB;
        ac_it:
        QutF3:
        goto EofxG;
        k8MCa:
        $v45Tl = $IJj7k->getAttribute('thumbnail');
        goto pwKd4;
        HqV60:
        return;
        goto okO55;
        okO55:
        P9ccZ:
        goto e49CM;
        kbMrV:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $HxXtJ]);
        goto tTJNt;
        k2nkY:
        $this->msRAdlpMZsf($d8Tfp, $IJj7k->getLocation());
        goto k8MCa;
        pZZU4:
        $gemWQ = intval(date('m'));
        goto p9hE0;
        pwKd4:
        if (!($v45Tl && $this->CBxJY->exists($v45Tl))) {
            goto vcLxq;
        }
        goto LZrWO;
        tTJNt:
    }
    private function msRAdlpMZsf($ytEqp, $Be1v2, $emNuY = '')
    {
        goto afQVx;
        fjy5j:
        $ClS79 = $MCaPU->month;
        goto aHzbo;
        LanAN:
        e81D2:
        goto fyL20;
        aHzbo:
        if (!($u1T1i > 2026 or $u1T1i === 2026 and $ClS79 > 3 or $u1T1i === 2026 and $ClS79 === 3 and $MCaPU->day >= 1)) {
            goto e81D2;
        }
        goto RLO7t;
        Cl4Z5:
        $u1T1i = $MCaPU->year;
        goto fjy5j;
        o00Td:
        dY3i3:
        goto pCahd;
        fyL20:
        try {
            $F_ZX8 = $this->bCjKk->call($this, $ytEqp);
            $this->XpKtX->put($Be1v2, $this->CBxJY->get($Be1v2), ['visibility' => 'public', 'ContentType' => $F_ZX8->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $a2Cko) {
            Log::error("Failed to upload image to S3", ['s3Path' => $Be1v2, 'error' => $a2Cko->getMessage()]);
        }
        goto s9kEf;
        WtM9X:
        $ytEqp = str_replace('.jpg', $emNuY, $ytEqp);
        goto VTIn5;
        RLO7t:
        return null;
        goto LanAN;
        VTIn5:
        $Be1v2 = str_replace('.jpg', $emNuY, $Be1v2);
        goto o00Td;
        afQVx:
        if (!$emNuY) {
            goto dY3i3;
        }
        goto WtM9X;
        pCahd:
        $MCaPU = now();
        goto Cl4Z5;
        s9kEf:
    }
}
