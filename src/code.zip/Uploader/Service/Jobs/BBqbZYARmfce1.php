<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
class BBqbZYARmfce1 implements BlurJobInterface
{
    const gulgt = 15;
    const dqWi9 = 500;
    const I9e4n = 500;
    private $bIrxp;
    private $rSfnv;
    private $GRsEs;
    public function __construct($NJy8O, $uIWH1, $Zywh9)
    {
        goto bjFU3;
        kjpGj:
        $this->bIrxp = $NJy8O;
        goto uoFRW;
        bjFU3:
        $this->GRsEs = $Zywh9;
        goto BIUGd;
        BIUGd:
        $this->rSfnv = $uIWH1;
        goto kjpGj;
        uoFRW:
    }
    public function blur(string $eeXS6) : void
    {
        goto VhRh5;
        Kk83j:
        throw new \Exception('Failed to set final permissions on image file: ' . $sVWFg);
        goto ZN6Ij;
        Q5JEh:
        IR6pW:
        goto e7jwP;
        JSpnn:
        $this->GRsEs->put($zfULO->filename, $xK9d0);
        goto Q5JEh;
        aaxzN:
        ini_set('memory_limit', '-1');
        goto pVrRn;
        ZN6Ij:
        v_eiu:
        goto TIcyZ;
        LRJn0:
        \Log::warning('Failed to set final permissions on image file: ' . $sVWFg);
        goto Kk83j;
        iMxVA:
        $xK9d0 = $this->rSfnv->get($zfULO->filename);
        goto JSpnn;
        VhRh5:
        $zfULO = UG34Yjmf7IsbQ::findOrFail($eeXS6);
        goto aaxzN;
        jx8Gr:
        $AYtsf = $this->mopbvMljxg6($zfULO);
        goto kVHff;
        SSvVn:
        $K0J89->resize(self::dqWi9, self::I9e4n / $QZr52);
        goto nVK4B;
        natr5:
        $QZr52 = $K0J89->width() / $K0J89->height();
        goto SSvVn;
        RDSmt:
        unset($K0J89);
        goto X0shD;
        pVrRn:
        if (!($zfULO->Fd5Pz == PdN71mQX1JeZG::S3 && !$this->GRsEs->exists($zfULO->filename))) {
            goto IR6pW;
        }
        goto iMxVA;
        TIcyZ:
        $zfULO->update(['preview' => $AYtsf]);
        goto n0YwF;
        e7jwP:
        $K0J89 = $this->bIrxp->call($this, $this->GRsEs->path($zfULO->getLocation()));
        goto natr5;
        nVK4B:
        $K0J89->blur(self::gulgt);
        goto jx8Gr;
        X0shD:
        if (chmod($sVWFg, 0664)) {
            goto v_eiu;
        }
        goto LRJn0;
        kVHff:
        $sVWFg = $this->rSfnv->put($AYtsf, $K0J89->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto RDSmt;
        n0YwF:
    }
    private function mopbvMljxg6($I_gke) : string
    {
        goto yHvih;
        gTQM_:
        $this->GRsEs->makeDirectory($S4PZU, 0755, true);
        goto behrN;
        yHvih:
        $NSF8Y = $I_gke->getLocation();
        goto zsP6_;
        DnE3i:
        if ($this->GRsEs->exists($S4PZU)) {
            goto q7kcG;
        }
        goto gTQM_;
        behrN:
        q7kcG:
        goto jHH8o;
        zsP6_:
        $S4PZU = dirname($NSF8Y) . '/preview/';
        goto DnE3i;
        jHH8o:
        return $S4PZU . $I_gke->getFilename() . '.jpg';
        goto OOcR4;
        OOcR4:
    }
}
