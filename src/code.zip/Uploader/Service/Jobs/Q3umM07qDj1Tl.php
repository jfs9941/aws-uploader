<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Service\Jobs\Fqn9mxOf7ZTno;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Q3umM07qDj1Tl implements WatermarkTextJobInterface
{
    private $R2XXS;
    private $VEFSL;
    private $GpRfX;
    private $wEVdN;
    private $hYphi;
    public function __construct($I4Jnv, $ukBzg, $dzspH, $zuNM5, $R6gtP)
    {
        goto Um3aM;
        aZ_qD:
        $this->VEFSL = $ukBzg;
        goto O5jdi;
        Um3aM:
        $this->R2XXS = $I4Jnv;
        goto b3Z6a;
        uKdQM:
        $this->hYphi = $zuNM5;
        goto ZQqhI;
        b3Z6a:
        $this->wEVdN = $dzspH;
        goto uKdQM;
        ZQqhI:
        $this->GpRfX = $R6gtP;
        goto aZ_qD;
        O5jdi:
    }
    public function putWatermark(string $hOWbX, string $R6W2J) : void
    {
        goto Gyi4r;
        asDzm:
        $wkaBP = memory_get_peak_usage();
        goto gTDTG;
        DDsuv:
        ini_set('memory_limit', '-1');
        goto H5VIF;
        Gyi4r:
        $KyNi2 = microtime(true);
        goto iCCrl;
        H5VIF:
        try {
            goto M7_0h;
            PKUqD:
            if (chmod($D4enG, 0664)) {
                goto HhGvk;
            }
            goto XyASE;
            R453X:
            return;
            goto O3k5y;
            XyASE:
            \Log::warning('Failed to set final permissions on image file: ' . $D4enG);
            goto SwYtQ;
            LQqXF:
            Log::error("D6FgZi8OHmjic is not on local, might be deleted before put watermark", ['imageId' => $hOWbX]);
            goto R453X;
            M7_0h:
            $h169k = D6FgZi8OHmjic::findOrFail($hOWbX);
            goto D68kr;
            smCls:
            unset($JAxuw);
            goto PKUqD;
            bTnZx:
            HhGvk:
            goto gx2i0;
            JRnJy:
            $JAxuw->orient();
            goto xymF1;
            Zggxh:
            $D4enG = $this->hYphi->path($h169k->getLocation());
            goto Iu3XP;
            O3k5y:
            Auiiu:
            goto Zggxh;
            xymF1:
            $this->mSgjs1CNBNh($JAxuw, $R6W2J);
            goto FCcmB;
            Iu3XP:
            $JAxuw = $this->R2XXS->call($this, $D4enG);
            goto JRnJy;
            SwYtQ:
            throw new \Exception('Failed to set final permissions on image file: ' . $D4enG);
            goto bTnZx;
            D68kr:
            if ($this->hYphi->exists($h169k->getLocation())) {
                goto Auiiu;
            }
            goto LQqXF;
            FCcmB:
            $this->wEVdN->put($D4enG, $JAxuw->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto smCls;
            gx2i0:
        } catch (\Throwable $jQ8Ca) {
            goto y6NSP;
            NN5ED:
            cc6EP:
            goto KyGtg;
            y6NSP:
            if (!$jQ8Ca instanceof ModelNotFoundException) {
                goto cc6EP;
            }
            goto QOVhx;
            QOVhx:
            Log::info("D6FgZi8OHmjic has been deleted, discard it", ['imageId' => $hOWbX]);
            goto wx4W2;
            KyGtg:
            Log::error("D6FgZi8OHmjic is not readable", ['imageId' => $hOWbX, 'error' => $jQ8Ca->getMessage()]);
            goto RyGPm;
            wx4W2:
            return;
            goto NN5ED;
            RyGPm:
        } finally {
            $qtKWj = microtime(true);
            $MDW5Q = memory_get_usage();
            $NFJ5h = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $hOWbX, 'execution_time_sec' => $qtKWj - $KyNi2, 'memory_usage_mb' => ($MDW5Q - $W0709) / 1024 / 1024, 'peak_memory_usage_mb' => ($NFJ5h - $wkaBP) / 1024 / 1024]);
        }
        goto BByqZ;
        iCCrl:
        $W0709 = memory_get_usage();
        goto asDzm;
        gTDTG:
        Log::info("Adding watermark text to image", ['imageId' => $hOWbX]);
        goto DDsuv;
        BByqZ:
    }
    private function mSgjs1CNBNh($JAxuw, $R6W2J) : void
    {
        goto YM9OC;
        eRWHK:
        $aTlSl = $this->R2XXS->call($this, $this->hYphi->path($vmX29));
        goto i6mJI;
        VuHwJ:
        $this->hYphi->put($vmX29, $this->wEVdN->get($vmX29));
        goto eRWHK;
        i6mJI:
        $JAxuw->place($aTlSl, 'top-left', 0, 0, 30);
        goto kgDWc;
        YM9OC:
        $w0IG6 = $JAxuw->width();
        goto jn08c;
        EDwQ8:
        $u6wnM = new Fqn9mxOf7ZTno($this->VEFSL, $this->GpRfX, $this->wEVdN, $this->hYphi);
        goto p69IH;
        jn08c:
        $sIm70 = $JAxuw->height();
        goto EDwQ8;
        p69IH:
        $vmX29 = $u6wnM->mrMxekbVqKL($w0IG6, $sIm70, $R6W2J, true);
        goto VuHwJ;
        kgDWc:
    }
}
