<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class NLBQaelXAGK8F implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $y06DH) : void
    {
        goto R5fLq;
        rs7ly:
        HBHIn:
        goto pwYYq;
        r2PH1:
        if ($aiCaH->width() > 0 && $aiCaH->height() > 0) {
            goto HBHIn;
        }
        goto ijbYx;
        R5fLq:
        $aiCaH = GXtnGiMmIPEIc::findOrFail($y06DH);
        goto r2PH1;
        ijbYx:
        $this->mj1RIggVjbI($aiCaH);
        goto rs7ly;
        pwYYq:
    }
    private function mj1RIggVjbI(GXtnGiMmIPEIc $U9mNN) : void
    {
        goto gGXO9;
        rIYcM:
        $C33IP = $qRTR9->getVideoStream();
        goto T843g;
        Y8Vjz:
        $U9mNN->update(['duration' => $qRTR9->getDurationInSeconds(), 'resolution' => $vCBZt->getWidth() . 'x' . $vCBZt->getHeight(), 'fps' => $C33IP->get('r_frame_rate') ?? 30]);
        goto H1t1f;
        TYki4:
        $qRTR9 = FFMpeg::fromDisk($UY4mB['path'])->open($U9mNN->getAttribute('filename'));
        goto rIYcM;
        T843g:
        $vCBZt = $C33IP->getDimensions();
        goto Y8Vjz;
        gGXO9:
        $UY4mB = $U9mNN->getView();
        goto TYki4;
        H1t1f:
    }
}
