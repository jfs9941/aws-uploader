<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Illuminate\Support\Facades\Log;
class YeQsbwwlutyCe implements BlurVideoJobInterface
{
    const bO05L = 15;
    const HJo_T = 500;
    const JGlVE = 500;
    private $R2XXS;
    private $wEVdN;
    private $A8xPF;
    public function __construct($I4Jnv, $dzspH, $ZT237)
    {
        goto y0MgY;
        lBs1L:
        $this->wEVdN = $dzspH;
        goto SonVm;
        SonVm:
        $this->R2XXS = $I4Jnv;
        goto FOGsA;
        y0MgY:
        $this->A8xPF = $ZT237;
        goto lBs1L;
        FOGsA:
    }
    public function blur(string $hOWbX) : void
    {
        goto glFVA;
        gkbln:
        Y3jGv:
        goto bG5mh;
        glFVA:
        Log::info("Blurring for video", ['videoID' => $hOWbX]);
        goto tP0AX;
        BKVXw:
        $sIe1z->update(['preview' => $R7aL8]);
        goto gkbln;
        tP0AX:
        ini_set('memory_limit', '-1');
        goto AfPiW;
        EQx6t:
        if (chmod($kDNl9, 0664)) {
            goto HqP9i;
        }
        goto pvyOj;
        uUuJA:
        $h169k->save($kDNl9);
        goto IVBRk;
        lukYG:
        unset($h169k);
        goto EQx6t;
        kUSkc:
        if (!$sIe1z->getAttribute('thumbnail')) {
            goto Y3jGv;
        }
        goto NDE43;
        b6QN2:
        HqP9i:
        goto BKVXw;
        gkEdV:
        $JkoVl = $h169k->width() / $h169k->height();
        goto iBu0x;
        IVBRk:
        $this->wEVdN->put($R7aL8, $this->A8xPF->get($R7aL8));
        goto lukYG;
        pvyOj:
        \Log::warning('Failed to set final permissions on image file: ' . $kDNl9);
        goto WNh8k;
        z1juK:
        $R7aL8 = $this->mJI3AT3TwBf($sIe1z);
        goto zmdxa;
        zmdxa:
        $kDNl9 = $this->A8xPF->path($R7aL8);
        goto uUuJA;
        WNh8k:
        throw new \Exception('Failed to set final permissions on image file: ' . $kDNl9);
        goto b6QN2;
        kv8R3:
        $h169k = $this->R2XXS->call($this, $this->A8xPF->path($sIe1z->getAttribute('thumbnail')));
        goto gkEdV;
        NDE43:
        $this->A8xPF->put($sIe1z->getAttribute('thumbnail'), $this->wEVdN->get($sIe1z->getAttribute('thumbnail')));
        goto kv8R3;
        AfPiW:
        $sIe1z = HS7SZ3rYPI80t::findOrFail($hOWbX);
        goto kUSkc;
        iBu0x:
        $h169k->resize(self::HJo_T, self::JGlVE / $JkoVl);
        goto gluux;
        gluux:
        $h169k->blur(self::bO05L);
        goto z1juK;
        bG5mh:
    }
    private function mJI3AT3TwBf(J9AcMiQKgpvel $Z0EoW) : string
    {
        goto Cticc;
        Cticc:
        $D4enG = $Z0EoW->getLocation();
        goto scCC_;
        qgAO6:
        $this->A8xPF->makeDirectory($IreU2, 0755, true);
        goto c7eo_;
        c7eo_:
        e8t_7:
        goto ql9Lw;
        rWVLz:
        if ($this->A8xPF->exists($IreU2)) {
            goto e8t_7;
        }
        goto qgAO6;
        scCC_:
        $IreU2 = dirname($D4enG) . '/preview/';
        goto rWVLz;
        ql9Lw:
        return $IreU2 . $Z0EoW->getFilename() . '.jpg';
        goto VYyEl;
        VYyEl:
    }
}
