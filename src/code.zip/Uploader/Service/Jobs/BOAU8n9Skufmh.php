<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class BOAU8n9Skufmh implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $iG1wy) : void
    {
        goto xBRMu;
        KWfMW:
        if ($aHaxS->width() > 0 && $aHaxS->height() > 0) {
            goto MyUjU;
        }
        goto Ujtef;
        Ujtef:
        $this->mFPICc7v2H0($aHaxS);
        goto aFrF1;
        xBRMu:
        $aHaxS = AelPShnd8pMtD::findOrFail($iG1wy);
        goto KWfMW;
        aFrF1:
        MyUjU:
        goto jJkYH;
        jJkYH:
    }
    private function mFPICc7v2H0(AelPShnd8pMtD $UTk4B) : void
    {
        goto gwHGr;
        gwHGr:
        $lDcvo = $UTk4B->getAttribute('driver') === 1 ? 's3' : 'public';
        goto wdPMt;
        qzhy0:
        $UTk4B->update(['duration' => $mCZRt->getDurationInSeconds(), 'resolution' => $Tr193->getWidth() . 'x' . $Tr193->getHeight(), 'fps' => $CLer4->get('r_frame_rate') ?? 30]);
        goto w1ikT;
        xRJyj:
        $Tr193 = $CLer4->getDimensions();
        goto qzhy0;
        buLT7:
        $CLer4 = $mCZRt->getVideoStream();
        goto xRJyj;
        wdPMt:
        $mCZRt = FFMpeg::fromDisk($lDcvo)->open($UTk4B->getAttribute('filename'));
        goto buLT7;
        w1ikT:
    }
}
