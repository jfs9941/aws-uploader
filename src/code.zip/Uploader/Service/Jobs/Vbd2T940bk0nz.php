<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Jfs\Exposed\Jobs\DownloadToLocalJobInterface; use Illuminate\Support\Facades\Log; use Jfs\Uploader\Core\NoqRziJe9G7Nn; class Vbd2T940bk0nz implements DownloadToLocalJobInterface { private $yvqrD; private $BQQPt; public function __construct($bPZ2H, $EpDSi) { $this->yvqrD = $bPZ2H; $this->BQQPt = $EpDSi; } public function download(string $hJXEE) : void { goto qoO5m; QLt6S: return; goto xo_oN; qoO5m: $goH3d = NoqRziJe9G7Nn::findOrFail($hJXEE); goto IiqoT; PcDPo: $this->BQQPt->put($goH3d->getLocation(), $this->yvqrD->get($goH3d->getLocation())); goto Hk9_o; xo_oN: pVOBN: goto PcDPo; iCmUM: if (!$this->BQQPt->exists($goH3d->getLocation())) { goto pVOBN; } goto QLt6S; IiqoT: Log::info("Start download file to local", ['fileId' => $hJXEE, 'filename' => $goH3d->getLocation()]); goto iCmUM; Hk9_o: } }
