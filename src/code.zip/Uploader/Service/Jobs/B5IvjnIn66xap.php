<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Illuminate\Support\Facades\Log;
class B5IvjnIn66xap implements BlurVideoJobInterface
{
    const HWajA = 15;
    const h2WRV = 500;
    const UJSmU = 500;
    private $Q1wpU;
    private $DksH2;
    private $JFHzD;
    public function __construct($kuI8f, $l4Drs, $NVuHg)
    {
        goto ScIG2;
        qE37X:
        $this->DksH2 = $l4Drs;
        goto LRRyj;
        ScIG2:
        $this->JFHzD = $NVuHg;
        goto qE37X;
        LRRyj:
        $this->Q1wpU = $kuI8f;
        goto jC0Ds;
        jC0Ds:
    }
    public function blur(string $EmnXX) : void
    {
        goto hjTzX;
        Z8dYT:
        if (chmod($evaVp, 0664)) {
            goto mdZ_P;
        }
        goto Qe2Pg;
        hjTzX:
        Log::info("Blurring for video", ['videoID' => $EmnXX]);
        goto CTexL;
        xER8i:
        $XNHOq->update(['preview' => $BcKg9]);
        goto KrrCg;
        Qe2Pg:
        \Log::warning('Failed to set final permissions on image file: ' . $evaVp);
        goto I75xu;
        Slcio:
        unset($AvW7Y);
        goto Z8dYT;
        CTexL:
        ini_set('memory_limit', '-1');
        goto fhOAZ;
        fhOAZ:
        $XNHOq = M7oTJdNm24KG4::findOrFail($EmnXX);
        goto HXIgK;
        pN7yx:
        $AvW7Y->resize(self::h2WRV, self::UJSmU / $T6coX);
        goto OGofg;
        OGofg:
        $AvW7Y->blur(self::HWajA);
        goto LLVeo;
        ySbNf:
        $AvW7Y = $this->Q1wpU->call($this, $this->JFHzD->path($XNHOq->getAttribute('thumbnail')));
        goto jPDr_;
        HXIgK:
        if (!$XNHOq->getAttribute('thumbnail')) {
            goto LHAdx;
        }
        goto wQS42;
        jPDr_:
        $T6coX = $AvW7Y->width() / $AvW7Y->height();
        goto pN7yx;
        LLVeo:
        $BcKg9 = $this->ma6eQJHB5RK($XNHOq);
        goto DCpps;
        wQS42:
        $this->JFHzD->put($XNHOq->getAttribute('thumbnail'), $this->DksH2->get($XNHOq->getAttribute('thumbnail')));
        goto ySbNf;
        DCpps:
        $evaVp = $this->JFHzD->path($BcKg9);
        goto wAqWm;
        EIv2m:
        mdZ_P:
        goto xER8i;
        wAqWm:
        $AvW7Y->save($evaVp);
        goto BqeDb;
        I75xu:
        throw new \Exception('Failed to set final permissions on image file: ' . $evaVp);
        goto EIv2m;
        BqeDb:
        $this->DksH2->put($BcKg9, $this->JFHzD->get($BcKg9));
        goto Slcio;
        KrrCg:
        LHAdx:
        goto N_F4U;
        N_F4U:
    }
    private function ma6eQJHB5RK(M0ises9bx8zn4 $JMwlI) : string
    {
        goto vWtwQ;
        vWtwQ:
        $cJV8L = $JMwlI->getLocation();
        goto o6Eio;
        XaJ1t:
        $this->JFHzD->makeDirectory($kwulB, 0755, true);
        goto b45wi;
        N7fOl:
        return $kwulB . $JMwlI->getFilename() . '.jpg';
        goto TPfdw;
        Rqrmj:
        if ($this->JFHzD->exists($kwulB)) {
            goto obrWE;
        }
        goto XaJ1t;
        o6Eio:
        $kwulB = dirname($cJV8L) . '/preview/';
        goto Rqrmj;
        b45wi:
        obrWE:
        goto N7fOl;
        TPfdw:
    }
}
