<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Encoder\MpCHeVeVe42Fl;
use Jfs\Uploader\Encoder\Nue4ljWXYxKkO;
use Jfs\Uploader\Encoder\Gp4Z40z5XsT8O;
use Jfs\Uploader\Encoder\L9C5rmIuqLjkd;
use Jfs\Uploader\Encoder\QLlcCQX5acc3Y;
use Jfs\Uploader\Encoder\ZCb6lvFwrl5Hj;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Uploader\Service\R9h2iDidHZRXb;
use Webmozart\Assert\Assert;
class OoSp5crnVWwoi implements MediaEncodeJobInterface
{
    private $EBMt5;
    private $Lrwlv;
    private $Vhcrn;
    private $ooQeq;
    private $U9NM5;
    public function __construct(string $E6K8y, $AhP23, $Klx1U, $F_3Mm, $BuwNb)
    {
        goto MnuKf;
        kJr0b:
        $this->ooQeq = $F_3Mm;
        goto eYRfw;
        aEb_x:
        $this->Vhcrn = $Klx1U;
        goto kJr0b;
        MnuKf:
        $this->EBMt5 = $E6K8y;
        goto njAh7;
        eYRfw:
        $this->U9NM5 = $BuwNb;
        goto oYqNI;
        njAh7:
        $this->Lrwlv = $AhP23;
        goto aEb_x;
        oYqNI:
    }
    public function encode(string $mfjeD, string $ATagl, $DE0ka = true) : void
    {
        goto j3r5U;
        sVxM7:
        try {
            goto L3PVi;
            CKwPo:
            $YLIIQ->m1bThoELSk0($U3qZy);
            goto p3aib;
            VGvlg:
            $aio9s = $wmU7r->width();
            goto qN2Kr;
            rgfpi:
            if (!($wmU7r->pM1q4 !== GTmWxMidiCuj0::S3)) {
                goto EIVBy;
            }
            goto JDmAo;
            eTMZQ:
            if (!$fQF3P) {
                goto nS5Za;
            }
            goto LYYzz;
            lPhKy:
            $zPcvC = new Nue4ljWXYxKkO('1080p', $BiS93['width'], $BiS93['height'], $wmU7r->bzVFa ?? 30);
            goto alD0z;
            wnDHS:
            $YLIIQ->m1bThoELSk0($U3qZy);
            goto Lo3MP;
            CLG0o:
            svGEd:
            goto wnDHS;
            J3mB9:
            $N6VEb = app(Gp4Z40z5XsT8O::class);
            goto CKwPo;
            vVl42:
            if (!$fQF3P) {
                goto svGEd;
            }
            goto taF69;
            LYYzz:
            $zPcvC = $zPcvC->mSHHiajMkr5($fQF3P);
            goto gSUvg;
            Sc0oj:
            gDWQz:
            goto bxavK;
            Nt3ar:
            if (!$this->mqF0jeEXNod($aio9s, $E52ZJ)) {
                goto gDWQz;
            }
            goto Xgziy;
            g3aBi:
            $mfjeD = $YLIIQ->mwnIFXzW7FE($this->myXaZGIwZQ9($wmU7r, $DE0ka));
            goto FjqeL;
            qN2Kr:
            $E52ZJ = $wmU7r->height();
            goto dNx2V;
            PXe9p:
            $U3qZy = new Nue4ljWXYxKkO('original', $aio9s, $E52ZJ, $wmU7r->bzVFa ?? 30);
            goto J3mB9;
            DUStZ:
            $DngCm = app(R9h2iDidHZRXb::class);
            goto TkNQY;
            L3PVi:
            $wmU7r = ZSB2cdrwtZpmk::findOrFail($mfjeD);
            goto YjEot;
            Xgziy:
            $BiS93 = $this->mFNFaflY7yj($aio9s, $E52ZJ);
            goto VOo24;
            qWJwS:
            $fQF3P = $this->mR9PARGapEb($DngCm, $dH34S->meptZfZfkod($wmU7r->width(), $wmU7r->height(), $ATagl));
            goto vVl42;
            NC21J:
            $YLIIQ = $YLIIQ->m1bThoELSk0($zPcvC);
            goto Sc0oj;
            gSUvg:
            nS5Za:
            goto NC21J;
            alD0z:
            $fQF3P = $this->mR9PARGapEb($DngCm, $dH34S->meptZfZfkod((int) $BiS93['width'], (int) $BiS93['height'], $ATagl));
            goto eTMZQ;
            Lo3MP:
            $YLIIQ->mydfbNTfHog($N6VEb->mUFiV9Xi2ul($wmU7r));
            goto o2nlm;
            o2nlm:
            if (!($aio9s && $E52ZJ)) {
                goto HmgPa;
            }
            goto Nt3ar;
            xhFet:
            EIVBy:
            goto VGvlg;
            FjqeL:
            $wmU7r->update(['aws_media_converter_job_id' => $mfjeD]);
            goto smu_G;
            O0S6n:
            Log::info("Set thumbnail for ZSB2cdrwtZpmk Job", ['videoId' => $wmU7r->getAttribute('id'), 'duration' => $wmU7r->getAttribute('duration')]);
            goto rjTiU;
            JDmAo:
            throw new MediaConverterException("ZSB2cdrwtZpmk {$wmU7r->id} is not S3 driver");
            goto xhFet;
            YjEot:
            Assert::isInstanceOf($wmU7r, ZSB2cdrwtZpmk::class);
            goto rgfpi;
            VOo24:
            Log::info("Set 1080p resolution for Job", ['width' => $BiS93['width'], 'height' => $BiS93['height'], 'originalWidth' => $aio9s, 'originalHeight' => $E52ZJ]);
            goto lPhKy;
            dNx2V:
            $A72oB = $this->mnYAHv6SWa7($wmU7r);
            goto YXjhU;
            TkNQY:
            $dH34S = new TID08qSYJRKYD($this->ooQeq, $this->U9NM5, $this->Vhcrn, $this->Lrwlv);
            goto qWJwS;
            YXjhU:
            Log::info("Set input video for Job", ['s3Uri' => $A72oB]);
            goto r679o;
            bxavK:
            HmgPa:
            goto O0S6n;
            k2Wnb:
            $YLIIQ = $YLIIQ->mxfEK9czotL(new L9C5rmIuqLjkd($A72oB));
            goto PXe9p;
            I_SyJ:
            $YLIIQ = $YLIIQ->mmqTH1N5SVb($XGdv1);
            goto g3aBi;
            r679o:
            $YLIIQ = app(QLlcCQX5acc3Y::class);
            goto k2Wnb;
            rjTiU:
            $XGdv1 = new MpCHeVeVe42Fl($wmU7r->w7VGK ?? 1, 2, $N6VEb->muOJMFoqujS($wmU7r));
            goto I_SyJ;
            taF69:
            $U3qZy = $U3qZy->mSHHiajMkr5($fQF3P);
            goto CLG0o;
            p3aib:
            $YLIIQ->mydfbNTfHog($N6VEb->mUFiV9Xi2ul($wmU7r));
            goto DUStZ;
            smu_G:
        } catch (\Exception $tPAjT) {
            Log::info("ZSB2cdrwtZpmk has been deleted, discard it", ['fileId' => $mfjeD, 'err' => $tPAjT->getMessage()]);
            return;
        }
        goto nTZcK;
        cv3gR:
        ini_set('memory_limit', '-1');
        goto sVxM7;
        j3r5U:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $mfjeD]);
        goto cv3gR;
        nTZcK:
    }
    private function myXaZGIwZQ9(ZSB2cdrwtZpmk $wmU7r, $DE0ka) : bool
    {
        goto zNVOg;
        pIp16:
        switch (true) {
            case $wmU7r->width() * $wmU7r->height() >= 1920 * 1080 && $wmU7r->width() * $wmU7r->height() < 2560 * 1440:
                return $Um4xl > 10 * 60;
            case $wmU7r->width() * $wmU7r->height() >= 2560 * 1440 && $wmU7r->width() * $wmU7r->height() < 3840 * 2160:
                return $Um4xl > 5 * 60;
            case $wmU7r->width() * $wmU7r->height() >= 3840 * 2160:
                return $Um4xl > 3 * 60;
            default:
                return false;
        }
        goto lXYKo;
        zNVOg:
        if ($DE0ka) {
            goto OUkdV;
        }
        goto UJrvj;
        xvq8c:
        $Um4xl = (int) round($wmU7r->getAttribute('duration') ?? 0);
        goto pIp16;
        f_9l2:
        OUkdV:
        goto xvq8c;
        UJrvj:
        return false;
        goto f_9l2;
        lXYKo:
        uK2yL:
        goto ACnFM;
        ACnFM:
        JRKMu:
        goto m9q26;
        m9q26:
    }
    private function mR9PARGapEb(R9h2iDidHZRXb $DngCm, string $f6JTu) : ?ZCb6lvFwrl5Hj
    {
        goto IctEB;
        QdmhM:
        if (!$KBjc7) {
            goto ojKo7;
        }
        goto lCAQV;
        tGQ1a:
        return null;
        goto MwcPn;
        s2xSm:
        ojKo7:
        goto tGQ1a;
        IctEB:
        $KBjc7 = $DngCm->mUl8sXZE7Vb($f6JTu);
        goto vsW0_;
        vsW0_:
        Log::info("Resolve watermark for job with url", ['url' => $f6JTu, 'uri' => $KBjc7]);
        goto QdmhM;
        lCAQV:
        return new ZCb6lvFwrl5Hj($KBjc7, 0, 0, null, null);
        goto s2xSm;
        MwcPn:
    }
    private function mqF0jeEXNod(int $aio9s, int $E52ZJ) : bool
    {
        return $aio9s * $E52ZJ > 1.5 * (1920 * 1080);
    }
    private function mFNFaflY7yj(int $aio9s, int $E52ZJ) : array
    {
        $SMe2c = new ESNBpulqF3Yia($aio9s, $E52ZJ);
        return $SMe2c->mZinayPg81n();
    }
    private function mnYAHv6SWa7(Yn8aWzKzROkno $LKVOP) : string
    {
        goto S2xwv;
        EAlSk:
        return $this->Lrwlv->url($LKVOP->filename);
        goto aVUsu;
        S2xwv:
        if (!($LKVOP->pM1q4 == GTmWxMidiCuj0::S3)) {
            goto wjfxu;
        }
        goto S7A89;
        qX4s4:
        wjfxu:
        goto EAlSk;
        S7A89:
        return 's3://' . $this->EBMt5 . '/' . $LKVOP->filename;
        goto qX4s4;
        aVUsu:
    }
}
