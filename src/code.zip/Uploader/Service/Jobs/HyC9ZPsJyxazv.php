<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class HyC9ZPsJyxazv implements StoreToS3JobInterface
{
    private $T1B34;
    private $VJN91;
    private $EaJ_d;
    public function __construct($V0xce, $J83Op, $t9atP)
    {
        goto YZYBL;
        Clh4S:
        $this->EaJ_d = $t9atP;
        goto PEEO1;
        PEEO1:
        $this->T1B34 = $V0xce;
        goto a4ZrL;
        YZYBL:
        $this->VJN91 = $J83Op;
        goto Clh4S;
        a4ZrL:
    }
    public function store(string $wAkkA) : void
    {
        goto q55ot;
        q55ot:
        $c3HLM = A9olNyGXhDJnA::findOrFail($wAkkA);
        goto q8Xvf;
        LmbrF:
        $L5bJW = $this->EaJ_d->path($c3HLM->getLocation());
        goto FmwaY;
        cAt_Q:
        Log::info("A9olNyGXhDJnA stored to S3, update the children attachments", ['fileId' => $wAkkA]);
        goto KWEbw;
        fDZQx:
        $this->VJN91->put($c3HLM->getAttribute('preview'), $this->EaJ_d->get($c3HLM->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $RYJii->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto YMxiU;
        QI3ub:
        FPHOD:
        goto CIgNp;
        AzdTd:
        if (!$c3HLM->update(['driver' => Pj539Ru5gyMbt::S3, 'status' => GlPuUJKmzwUJ9::FINISHED])) {
            goto FPHOD;
        }
        goto cAt_Q;
        h97we:
        Cgug1:
        goto DkQ0Y;
        KWEbw:
        A9olNyGXhDJnA::where('parent_id', $wAkkA)->update(['driver' => Pj539Ru5gyMbt::S3, 'preview' => $c3HLM->getAttribute('preview'), 'thumbnail' => $c3HLM->getAttribute('thumbnail')]);
        goto DU1zx;
        dGIkt:
        $Dsu_D = $this->EaJ_d->path($KCUKl);
        goto RkOwK;
        FmwaY:
        $this->mG7lpMnde0g($L5bJW, $c3HLM->getLocation());
        goto OZwzX;
        YMxiU:
        bagUE:
        goto AzdTd;
        gHsm2:
        Log::info("A9olNyGXhDJnA has been deleted, discard it", ['fileId' => $wAkkA]);
        goto dfp8E;
        DU1zx:
        return;
        goto QI3ub;
        rnrKs:
        J4cO0:
        goto LmbrF;
        OZwzX:
        $KCUKl = $c3HLM->getAttribute('thumbnail');
        goto pK72K;
        pK72K:
        if (!($KCUKl && $this->EaJ_d->exists($KCUKl))) {
            goto Cgug1;
        }
        goto dGIkt;
        q8Xvf:
        if ($c3HLM) {
            goto J4cO0;
        }
        goto gHsm2;
        DkQ0Y:
        if (!($c3HLM->getAttribute('preview') && $this->EaJ_d->exists($c3HLM->getAttribute('preview')))) {
            goto bagUE;
        }
        goto xLO6p;
        h4I7y:
        $this->VJN91->put($c3HLM->getAttribute('thumbnail'), $this->EaJ_d->get($KCUKl), ['visibility' => 'public', 'ContentType' => $NHlhh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto h97we;
        dfp8E:
        return;
        goto rnrKs;
        xLO6p:
        $PI9rG = $this->EaJ_d->path($c3HLM->getAttribute('preview'));
        goto fXCX8;
        CIgNp:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $wAkkA]);
        goto rJjZn;
        fXCX8:
        $RYJii = $this->T1B34->call($this, $PI9rG);
        goto fDZQx;
        RkOwK:
        $NHlhh = $this->T1B34->call($this, $Dsu_D);
        goto h4I7y;
        rJjZn:
    }
    private function mG7lpMnde0g($tGAmw, $OHgC9, $iH2Av = '')
    {
        goto HQBmq;
        mrw_d:
        xLuPi:
        goto pdjA9;
        tXRA9:
        $tGAmw = str_replace('.jpg', $iH2Av, $tGAmw);
        goto OA20o;
        HQBmq:
        if (!$iH2Av) {
            goto xLuPi;
        }
        goto tXRA9;
        pdjA9:
        try {
            $lu07a = $this->T1B34->call($this, $tGAmw);
            $this->VJN91->put($OHgC9, $this->EaJ_d->get($OHgC9), ['visibility' => 'public', 'ContentType' => $lu07a->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $X2LoG) {
            Log::error("Failed to upload image to S3", ['s3Path' => $OHgC9, 'error' => $X2LoG->getMessage()]);
        }
        goto q7xwL;
        OA20o:
        $OHgC9 = str_replace('.jpg', $iH2Av, $OHgC9);
        goto mrw_d;
        q7xwL:
    }
}
