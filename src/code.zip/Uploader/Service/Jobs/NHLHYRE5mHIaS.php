<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class NHLHYRE5mHIaS implements GenerateThumbnailForVideoInterface
{
    private $wzgO7;
    public function __construct($gYPLP)
    {
        $this->wzgO7 = $gYPLP;
    }
    public function generate(string $B5uQ4) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $B5uQ4);
        $this->wzgO7->createThumbnail($B5uQ4);
    }
}
