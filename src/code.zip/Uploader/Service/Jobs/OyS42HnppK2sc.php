<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Illuminate\Support\Facades\Log;
class OyS42HnppK2sc implements StoreVideoToS3JobInterface
{
    private $KnQNf;
    private $p25eF;
    private $BqPa9;
    public function __construct($RfRbz, $hdDTr, $Vk6id)
    {
        goto HPvzS;
        J8xO0:
        $this->KnQNf = $RfRbz;
        goto smTz7;
        HPvzS:
        $this->p25eF = $hdDTr;
        goto uZHRL;
        uZHRL:
        $this->BqPa9 = $Vk6id;
        goto J8xO0;
        smTz7:
    }
    public function store(string $Apw7Q) : void
    {
        goto aeaHA;
        yiICJ:
        $xa9Tf = memory_get_peak_usage();
        goto xg_ko;
        nSAQC:
        if ($Vk6id->exists($lML4W->getLocation())) {
            goto X4qbq;
        }
        goto sLtn2;
        RyVVJ:
        $lML4W = ZWik6jMzUez6v::find($Apw7Q);
        goto rudPq;
        GeMZy:
        X4qbq:
        goto p0p15;
        v962e:
        $Vk6id = $this->BqPa9;
        goto RyVVJ;
        sLtn2:
        Log::error("[OyS42HnppK2sc] File not found, discard it ", ['video' => $lML4W->getLocation()]);
        goto qEJc6;
        WwliC:
        $PwEas = mktime(0, 0, 0, 3, 1, 2026);
        goto IWtw2;
        cFgex:
        return;
        goto fMUNO;
        srg_M:
        $qYDxT = $Vk6id->mimeType($lML4W->getLocation());
        goto X4LEZ;
        Wwsvm:
        $FJiRP = $this->p25eF->getClient();
        goto v962e;
        rudPq:
        if ($lML4W) {
            goto yt1__;
        }
        goto ToC4B;
        aeaHA:
        Log::info('Storing video (local) to S3', ['fileId' => $Apw7Q, 'bucketName' => $this->KnQNf]);
        goto QfN4n;
        IWtw2:
        if (!($nVO6t >= $PwEas)) {
            goto nyBdE;
        }
        goto KzOQB;
        fMUNO:
        yt1__:
        goto xWrak;
        YT9WS:
        $D9kcG = memory_get_usage();
        goto yiICJ;
        QfN4n:
        ini_set('memory_limit', '-1');
        goto Wwsvm;
        xg_ko:
        try {
            goto eRhpV;
            lVrJr:
            $r3epc = $FJiRP->uploadPart(['Bucket' => $this->KnQNf, 'Key' => $lML4W->getLocation(), 'UploadId' => $neQx8, 'PartNumber' => $gSLJF, 'Body' => fread($OXauP, $sQ7dF)]);
            goto XTC0R;
            XTC0R:
            $Luhos[] = ['PartNumber' => $gSLJF, 'ETag' => $r3epc['ETag']];
            goto UxkGD;
            FHBmF:
            $neQx8 = $sOkhb['UploadId'];
            goto obMac;
            ihgnY:
            fclose($OXauP);
            goto Kf9Ff;
            unUg5:
            UkKXB:
            goto ihgnY;
            JpyME:
            $lML4W->update(['driver' => PQEhKbCWody73::S3]);
            goto gUpd9;
            UxkGD:
            $gSLJF++;
            goto CHbH7;
            gUpd9:
            $Vk6id->delete($lML4W->getLocation());
            goto L0xIU;
            ehMMo:
            if (feof($OXauP)) {
                goto UkKXB;
            }
            goto lVrJr;
            eRhpV:
            $sOkhb = $FJiRP->createMultipartUpload(['Bucket' => $this->KnQNf, 'Key' => $lML4W->getLocation(), 'ContentType' => $qYDxT, 'ContentDisposition' => 'inline']);
            goto FHBmF;
            obMac:
            $gSLJF = 1;
            goto ZHI6_;
            Kf9Ff:
            $FJiRP->completeMultipartUpload(['Bucket' => $this->KnQNf, 'Key' => $lML4W->getLocation(), 'UploadId' => $neQx8, 'MultipartUpload' => ['Parts' => $Luhos]]);
            goto JpyME;
            WbuUq:
            tfIse:
            goto ehMMo;
            CHbH7:
            goto tfIse;
            goto unUg5;
            ZHI6_:
            $Luhos = [];
            goto WbuUq;
            L0xIU:
        } catch (AwsException $j7qgT) {
            goto a7xOp;
            R3Boz:
            try {
                $FJiRP->abortMultipartUpload(['Bucket' => $this->KnQNf, 'Key' => $lML4W->getLocation(), 'UploadId' => $neQx8]);
            } catch (AwsException $i3XrM) {
                Log::error('Error aborting multipart upload: ' . $i3XrM->getMessage());
            }
            goto mwsxm;
            a7xOp:
            if (!isset($neQx8)) {
                goto PeKf9;
            }
            goto R3Boz;
            mwsxm:
            PeKf9:
            goto lIr3I;
            lIr3I:
            Log::error('Failed to store video: ' . $lML4W->getLocation() . ' - ' . $j7qgT->getMessage());
            goto PEOhl;
            PEOhl:
        } finally {
            $K_xT8 = microtime(true);
            $PHwVM = memory_get_usage();
            $Mq13l = memory_get_peak_usage();
            Log::info('Store ZWik6jMzUez6v to S3 function resource usage', ['imageId' => $Apw7Q, 'execution_time_sec' => $K_xT8 - $Z9gjS, 'memory_usage_mb' => ($PHwVM - $D9kcG) / 1024 / 1024, 'peak_memory_usage_mb' => ($Mq13l - $xa9Tf) / 1024 / 1024]);
        }
        goto NEwTR;
        KzOQB:
        return;
        goto bQEIM;
        bQEIM:
        nyBdE:
        goto nSAQC;
        ToC4B:
        Log::info("ZWik6jMzUez6v has been deleted in database or not inserted yet, discard it", ['fileId' => $Apw7Q]);
        goto cFgex;
        p0p15:
        $OXauP = $Vk6id->readStream($lML4W->getLocation());
        goto GbLFm;
        GbLFm:
        $sQ7dF = 1024 * 1024 * 50;
        goto srg_M;
        qEJc6:
        return;
        goto GeMZy;
        xWrak:
        $nVO6t = time();
        goto WwliC;
        X4LEZ:
        $Z9gjS = microtime(true);
        goto YT9WS;
        NEwTR:
    }
}
