<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Encoder\WOsYo97dtq83f;
use Jfs\Uploader\Encoder\BzfUWKOHVrbmX;
use Jfs\Uploader\Encoder\EBrgb5DByuboN;
use Jfs\Uploader\Encoder\EVUJFq5ZpkhYa;
use Jfs\Uploader\Encoder\G5nvOO03RJEUp;
use Jfs\Uploader\Encoder\JOc7tbmnzw0x2;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Jfs\Uploader\Service\Jobs\N0u2MGGVwq0P4;
use Jfs\Uploader\Service\Jobs\Ka9F6ltS3EsKS;
use Jfs\Uploader\Service\RiRUUwVHtq3AY;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class BS48ZckuwR4zT implements MediaEncodeJobInterface
{
    private $mltiL;
    private $qqmnq;
    private $SxfKN;
    private $PvWfL;
    private $iKvr0;
    public function __construct(string $nIkcP, $vS8UC, $DPWG1, $Aeh19, $TK_MT)
    {
        goto Nytmb;
        JM21z:
        $this->qqmnq = $vS8UC;
        goto b3blA;
        Nytmb:
        $this->mltiL = $nIkcP;
        goto JM21z;
        jCwVC:
        $this->PvWfL = $Aeh19;
        goto YyzUR;
        YyzUR:
        $this->iKvr0 = $TK_MT;
        goto Jjuhx;
        b3blA:
        $this->SxfKN = $DPWG1;
        goto jCwVC;
        Jjuhx:
    }
    public function encode(string $GMwD5, string $g2Hrl, $OuQ85 = true) : void
    {
        goto TR_uS;
        TR_uS:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $GMwD5]);
        goto yZgYo;
        yZgYo:
        ini_set('memory_limit', '-1');
        goto QUiQg;
        QUiQg:
        try {
            goto JT8o2;
            O6tUl:
            OUz_E:
            goto jnnh7;
            Yei93:
            $uj0nf = $uj0nf->mk8mJ38Cnf1($gx7xw);
            goto Tqwh0;
            c4vrW:
            Log::info("Set 1080p resolution for Job", ['width' => $DyZ1y['width'], 'height' => $DyZ1y['height'], 'originalWidth' => $BmTCT, 'originalHeight' => $IkBoO]);
            goto r3ZXY;
            OcYlV:
            z_Cku:
            goto D0rmi;
            CQ_Zd:
            $uj0nf->mXTIb6qDvsw($EQGHb->m8zUVt0VPmE($UUt0Z));
            goto ye3qH;
            JGnwE:
            $IkBoO = $UUt0Z->height();
            goto EwarI;
            iws74:
            $c8xex = $this->mpTmUxjV99x($LmP6O, $oEi9I->mZ54QsRZLR3((int) $DyZ1y['width'], (int) $DyZ1y['height'], $g2Hrl));
            goto LCIV0;
            H3XLo:
            $ekR0D = $ekR0D->mQMmj8RRoI5($c8xex);
            goto OG1xC;
            zlryP:
            $gx7xw = new WOsYo97dtq83f($UUt0Z->tP9i2 ?? 1, 2, $EQGHb->mA0L7sGffv3($UUt0Z));
            goto Yei93;
            EwarI:
            $Mc_sP = $this->mt8hLLBtg6j($UUt0Z);
            goto Kgn7H;
            tJ1zl:
            throw new MediaConverterException("RhdJGUi8FOLBJ {$UUt0Z->id} is not S3 driver");
            goto cuEmm;
            zLIoh:
            $dGLTb = $dGLTb->mQMmj8RRoI5($c8xex);
            goto O6tUl;
            r3ZXY:
            $ekR0D = new BzfUWKOHVrbmX('1080p', $DyZ1y['width'], $DyZ1y['height'], $UUt0Z->BeY7H ?? 30);
            goto iws74;
            ye3qH:
            $LmP6O = app(RiRUUwVHtq3AY::class);
            goto k_n7m;
            VInsB:
            $DyZ1y = $this->mP5YYk73nDV($BmTCT, $IkBoO);
            goto c4vrW;
            sfvLV:
            if (!($UUt0Z->NQ3st !== CUySMhqlL7P49::S3)) {
                goto Wa5BS;
            }
            goto tJ1zl;
            cuEmm:
            Wa5BS:
            goto AcdBr;
            vMiIw:
            $c8xex = $this->mpTmUxjV99x($LmP6O, $oEi9I->mZ54QsRZLR3($UUt0Z->width(), $UUt0Z->height(), $g2Hrl));
            goto EZ0zj;
            BMuwY:
            $uj0nf = app(G5nvOO03RJEUp::class);
            goto XB_o9;
            a8alT:
            $EQGHb = app(EBrgb5DByuboN::class);
            goto HOLx1;
            ojxzb:
            Log::info("Set thumbnail for RhdJGUi8FOLBJ Job", ['videoId' => $UUt0Z->getAttribute('id'), 'duration' => $UUt0Z->getAttribute('duration')]);
            goto zlryP;
            EZ0zj:
            if (!$c8xex) {
                goto OUz_E;
            }
            goto zLIoh;
            jnnh7:
            $uj0nf->m29iTxK0Wba($dGLTb);
            goto blV3u;
            LCIV0:
            if (!$c8xex) {
                goto L0m42;
            }
            goto H3XLo;
            HOLx1:
            $uj0nf->m29iTxK0Wba($dGLTb);
            goto CQ_Zd;
            k_n7m:
            $oEi9I = new Ka9F6ltS3EsKS($this->PvWfL, $this->iKvr0, $this->SxfKN, $this->qqmnq);
            goto vMiIw;
            Tqwh0:
            $GMwD5 = $uj0nf->mz8om46iu2k($this->m5hlPlTJtgl($UUt0Z, $OuQ85));
            goto jp416;
            OG1xC:
            L0m42:
            goto CEAw6;
            afkhP:
            Assert::isInstanceOf($UUt0Z, RhdJGUi8FOLBJ::class);
            goto sfvLV;
            CEAw6:
            $uj0nf = $uj0nf->m29iTxK0Wba($ekR0D);
            goto OcYlV;
            CKg5R:
            if (!($BmTCT && $IkBoO)) {
                goto IyUa9;
            }
            goto RVZCz;
            pDDG0:
            $dGLTb = new BzfUWKOHVrbmX('original', $BmTCT, $IkBoO, $UUt0Z->BeY7H ?? 30);
            goto a8alT;
            JT8o2:
            $UUt0Z = RhdJGUi8FOLBJ::findOrFail($GMwD5);
            goto afkhP;
            jp416:
            $UUt0Z->update(['aws_media_converter_job_id' => $GMwD5]);
            goto tvWUd;
            AcdBr:
            $BmTCT = $UUt0Z->width();
            goto JGnwE;
            RVZCz:
            if (!$this->m2bQpLsNPiB($BmTCT, $IkBoO)) {
                goto z_Cku;
            }
            goto VInsB;
            D0rmi:
            IyUa9:
            goto ojxzb;
            blV3u:
            $uj0nf->mXTIb6qDvsw($EQGHb->m8zUVt0VPmE($UUt0Z));
            goto CKg5R;
            XB_o9:
            $uj0nf = $uj0nf->m8fLzkiZvIR(new EVUJFq5ZpkhYa($Mc_sP));
            goto pDDG0;
            Kgn7H:
            Log::info("Set input video for Job", ['s3Uri' => $Mc_sP]);
            goto BMuwY;
            tvWUd:
        } catch (\Exception $b6Bui) {
            Log::info("RhdJGUi8FOLBJ has been deleted, discard it", ['fileId' => $GMwD5, 'err' => $b6Bui->getMessage()]);
            return;
        }
        goto j6uXU;
        j6uXU:
    }
    private function m5hlPlTJtgl(RhdJGUi8FOLBJ $UUt0Z, $OuQ85) : bool
    {
        goto LcRCD;
        LcRCD:
        if ($OuQ85) {
            goto A_v34;
        }
        goto iE0pC;
        iE0pC:
        return false;
        goto o2rEk;
        P51X_:
        P__3u:
        goto UJUfP;
        wEubo:
        switch (true) {
            case $UUt0Z->width() * $UUt0Z->height() >= 1920 * 1080 && $UUt0Z->width() * $UUt0Z->height() < 2560 * 1440:
                return $XUslc > 10 * 60;
            case $UUt0Z->width() * $UUt0Z->height() >= 2560 * 1440 && $UUt0Z->width() * $UUt0Z->height() < 3840 * 2160:
                return $XUslc > 5 * 60;
            case $UUt0Z->width() * $UUt0Z->height() >= 3840 * 2160:
                return $XUslc > 3 * 60;
            default:
                return false;
        }
        goto P51X_;
        o2rEk:
        A_v34:
        goto QoP15;
        QoP15:
        $XUslc = (int) round($UUt0Z->getAttribute('duration') ?? 0);
        goto wEubo;
        UJUfP:
        smxXj:
        goto VqMwC;
        VqMwC:
    }
    private function mpTmUxjV99x(RiRUUwVHtq3AY $LmP6O, string $KOZO4) : ?JOc7tbmnzw0x2
    {
        goto Ane9F;
        Ane9F:
        $xAVvI = $LmP6O->mZ6Ua4pkUv7($KOZO4);
        goto b5JPR;
        s2K_t:
        return null;
        goto MIsVy;
        EJ_XZ:
        R4VJI:
        goto s2K_t;
        EiGq8:
        return new JOc7tbmnzw0x2($xAVvI, 0, 0, null, null);
        goto EJ_XZ;
        b5JPR:
        Log::info("Resolve watermark for job with url", ['url' => $KOZO4, 'uri' => $xAVvI]);
        goto qeCie;
        qeCie:
        if (!$xAVvI) {
            goto R4VJI;
        }
        goto EiGq8;
        MIsVy:
    }
    private function m2bQpLsNPiB(int $BmTCT, int $IkBoO) : bool
    {
        return $BmTCT * $IkBoO > 1.5 * (1920 * 1080);
    }
    private function mP5YYk73nDV(int $BmTCT, int $IkBoO) : array
    {
        $B9317 = new N0u2MGGVwq0P4($BmTCT, $IkBoO);
        return $B9317->mVaB48xRIWB();
    }
    private function mt8hLLBtg6j(EpIpyfdFnoTz6 $HZKvy) : string
    {
        goto TcGe0;
        hCX47:
        B4PAF:
        goto MtAx2;
        P51Pb:
        return 's3://' . $this->mltiL . '/' . $HZKvy->filename;
        goto hCX47;
        MtAx2:
        return $this->qqmnq->url($HZKvy->filename);
        goto APBOs;
        TcGe0:
        if (!($HZKvy->NQ3st == CUySMhqlL7P49::S3)) {
            goto B4PAF;
        }
        goto P51Pb;
        APBOs:
    }
}
