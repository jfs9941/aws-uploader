<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Illuminate\Support\Facades\Log;
class FNHIOteGjG0AW implements StoreVideoToS3JobInterface
{
    private $egcXt;
    private $RE_2F;
    private $F8ilg;
    public function __construct($wY6MR, $WmwnR, $Pkopf)
    {
        goto Nd9Jy;
        Im4DI:
        $this->F8ilg = $Pkopf;
        goto MPxX7;
        Nd9Jy:
        $this->RE_2F = $WmwnR;
        goto Im4DI;
        MPxX7:
        $this->egcXt = $wY6MR;
        goto cqrtl;
        cqrtl:
    }
    public function store(string $LpGEK) : void
    {
        goto f3kqi;
        wfD7F:
        $qIArj = $Pkopf->mimeType($VwjzG->getLocation());
        goto xJmH2;
        yItj9:
        $Pkopf = $this->F8ilg;
        goto Y0DvS;
        IJEYC:
        CTA4H:
        goto uF_YH;
        Y0DvS:
        $VwjzG = Jf5KRr8uE3t34::find($LpGEK);
        goto pu7y3;
        xJmH2:
        $bZyPc = microtime(true);
        goto f0Drt;
        uF_YH:
        if ($Pkopf->exists($VwjzG->getLocation())) {
            goto qU9a8;
        }
        goto Nh3DN;
        CbVk1:
        qU9a8:
        goto W_MOw;
        Caxi9:
        ini_set('memory_limit', '-1');
        goto Kit60;
        CELNa:
        Log::info("Jf5KRr8uE3t34 has been deleted, discard it", ['fileId' => $LpGEK]);
        goto mxecR;
        jZCCe:
        $Dn1eW = 1024 * 1024 * 50;
        goto wfD7F;
        f3kqi:
        Log::info('Storing video (local) to S3', ['fileId' => $LpGEK, 'bucketName' => $this->egcXt]);
        goto Caxi9;
        Kit60:
        $ZbtsO = $this->RE_2F->getClient();
        goto yItj9;
        STQc9:
        try {
            goto Nr9oP;
            qs0sq:
            $ZbtsO->completeMultipartUpload(['Bucket' => $this->egcXt, 'Key' => $VwjzG->getLocation(), 'UploadId' => $Adfm4, 'MultipartUpload' => ['Parts' => $wErBB]]);
            goto RvLfV;
            K2qIk:
            $wErBB = [];
            goto qytNf;
            PT8aS:
            $e9iJD = 1;
            goto K2qIk;
            ldrbf:
            if (feof($BSCjZ)) {
                goto Df9_M;
            }
            goto aHYyI;
            N1gQY:
            $Adfm4 = $LDmT4['UploadId'];
            goto PT8aS;
            qytNf:
            yedH1:
            goto ldrbf;
            d2Cl1:
            $Pkopf->delete($VwjzG->getLocation());
            goto hUV8I;
            ny5rB:
            $wErBB[] = ['PartNumber' => $e9iJD, 'ETag' => $TIMQx['ETag']];
            goto muzdN;
            lw1Wa:
            Df9_M:
            goto WTF_O;
            WTF_O:
            fclose($BSCjZ);
            goto qs0sq;
            Nr9oP:
            $LDmT4 = $ZbtsO->createMultipartUpload(['Bucket' => $this->egcXt, 'Key' => $VwjzG->getLocation(), 'ContentType' => $qIArj, 'ContentDisposition' => 'inline']);
            goto N1gQY;
            WFLdu:
            goto yedH1;
            goto lw1Wa;
            RvLfV:
            $VwjzG->update(['driver' => EzGWviwQDmAwI::S3, 'status' => Tbw0jsMnRbOTP::FINISHED]);
            goto d2Cl1;
            muzdN:
            $e9iJD++;
            goto WFLdu;
            aHYyI:
            $TIMQx = $ZbtsO->uploadPart(['Bucket' => $this->egcXt, 'Key' => $VwjzG->getLocation(), 'UploadId' => $Adfm4, 'PartNumber' => $e9iJD, 'Body' => fread($BSCjZ, $Dn1eW)]);
            goto ny5rB;
            hUV8I:
        } catch (AwsException $OtxN7) {
            goto fSNZa;
            U1vTp:
            Log::error('Failed to store video: ' . $VwjzG->getLocation() . ' - ' . $OtxN7->getMessage());
            goto gqvDK;
            Pvleq:
            mt35v:
            goto U1vTp;
            n_SdX:
            try {
                $ZbtsO->abortMultipartUpload(['Bucket' => $this->egcXt, 'Key' => $VwjzG->getLocation(), 'UploadId' => $Adfm4]);
            } catch (AwsException $YCYU5) {
                Log::error('Error aborting multipart upload: ' . $YCYU5->getMessage());
            }
            goto Pvleq;
            fSNZa:
            if (!isset($Adfm4)) {
                goto mt35v;
            }
            goto n_SdX;
            gqvDK:
        } finally {
            $U57EV = microtime(true);
            $N25yv = memory_get_usage();
            $E8PVY = memory_get_peak_usage();
            Log::info('Store Jf5KRr8uE3t34 to S3 function resource usage', ['imageId' => $LpGEK, 'execution_time_sec' => $U57EV - $bZyPc, 'memory_usage_mb' => ($N25yv - $xzy2m) / 1024 / 1024, 'peak_memory_usage_mb' => ($E8PVY - $oEqSJ) / 1024 / 1024]);
        }
        goto tJ359;
        W_MOw:
        $BSCjZ = $Pkopf->readStream($VwjzG->getLocation());
        goto jZCCe;
        mxecR:
        return;
        goto IJEYC;
        No4oJ:
        $oEqSJ = memory_get_peak_usage();
        goto STQc9;
        pu7y3:
        if ($VwjzG) {
            goto CTA4H;
        }
        goto CELNa;
        f0Drt:
        $xzy2m = memory_get_usage();
        goto No4oJ;
        Nh3DN:
        Log::error("[FNHIOteGjG0AW] File not found, discard it ", ['video' => $VwjzG->getLocation()]);
        goto N24Nb;
        N24Nb:
        return;
        goto CbVk1;
        tJ359:
    }
}
