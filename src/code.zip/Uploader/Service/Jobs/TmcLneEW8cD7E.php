<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Illuminate\Support\Facades\Log;
class TmcLneEW8cD7E implements DownloadToLocalJobInterface
{
    private $YHwpp;
    private $svYhv;
    public function __construct($ehLvI, $uLgU3)
    {
        $this->YHwpp = $ehLvI;
        $this->svYhv = $uLgU3;
    }
    public function download(string $ShXx2) : void
    {
        goto DE1Ce;
        bWFJE:
        $this->svYhv->put($Ga9Xm->getLocation(), $this->YHwpp->get($Ga9Xm->getLocation()));
        goto XqMCW;
        vA0h6:
        Log::info("Start download file to local", ['fileId' => $ShXx2, 'filename' => $Ga9Xm->getLocation()]);
        goto o3C0Z;
        Xw4wV:
        return;
        goto pHOyE;
        pHOyE:
        yetSz:
        goto bWFJE;
        DE1Ce:
        $Ga9Xm = Vt3ybt0yfaPAa::findOrFail($ShXx2);
        goto vA0h6;
        o3C0Z:
        if (!$this->svYhv->exists($Ga9Xm->getLocation())) {
            goto yetSz;
        }
        goto Xw4wV;
        XqMCW:
    }
}
