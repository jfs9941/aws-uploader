<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class TRJKjbzOlxjlO implements StoreToS3JobInterface
{
    private $Q1wpU;
    private $DksH2;
    private $JFHzD;
    public function __construct($kuI8f, $l4Drs, $NVuHg)
    {
        goto IYgEK;
        VQfv0:
        $this->JFHzD = $NVuHg;
        goto bnKD9;
        IYgEK:
        $this->DksH2 = $l4Drs;
        goto VQfv0;
        bnKD9:
        $this->Q1wpU = $kuI8f;
        goto nuTNE;
        nuTNE:
    }
    public function store(string $EmnXX) : void
    {
        goto sVSe7;
        aMmfA:
        if (!($DXXBS && $this->JFHzD->exists($DXXBS))) {
            goto aDtW_;
        }
        goto ODuqT;
        zlIfA:
        vnA4T:
        goto HFZBg;
        XhuJI:
        $BcKg9 = $this->JFHzD->path($uvyDL->getAttribute('preview'));
        goto N9qzh;
        FXjq9:
        aDtW_:
        goto JfxI4;
        n4HAE:
        Log::info("Q48IcpSr3UpAT has been deleted, discard it", ['fileId' => $EmnXX]);
        goto VXTv0;
        N9qzh:
        $LQUDT = $this->Q1wpU->call($this, $BcKg9);
        goto x0nkx;
        x0nkx:
        $this->DksH2->put($uvyDL->getAttribute('preview'), $this->JFHzD->get($uvyDL->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $LQUDT->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Ku42K;
        tjSd3:
        $BKlrl = $this->Q1wpU->call($this, $V1UKq);
        goto IpXii;
        VXTv0:
        return;
        goto Gvazf;
        IpXii:
        $this->DksH2->put($uvyDL->getAttribute('thumbnail'), $this->JFHzD->get($DXXBS), ['visibility' => 'public', 'ContentType' => $BKlrl->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto FXjq9;
        pv5du:
        return;
        goto zlIfA;
        JfxI4:
        if (!($uvyDL->getAttribute('preview') && $this->JFHzD->exists($uvyDL->getAttribute('preview')))) {
            goto rpOs3;
        }
        goto XhuJI;
        HFZBg:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $EmnXX]);
        goto NDcn9;
        bCSjc:
        $this->mHePQVRnd10($cJV8L, $uvyDL->getLocation());
        goto nPz4K;
        UwE1G:
        if (!$uvyDL->update(['driver' => Tfi7lQDVWUJD9::S3, 'status' => FmSSI1JLQCp0W::FINISHED])) {
            goto vnA4T;
        }
        goto gcChT;
        Gvazf:
        BXg6E:
        goto T2TrX;
        T2TrX:
        $cJV8L = $this->JFHzD->path($uvyDL->getLocation());
        goto bCSjc;
        sVSe7:
        $uvyDL = Q48IcpSr3UpAT::findOrFail($EmnXX);
        goto u0yI9;
        eT9Pc:
        Q48IcpSr3UpAT::where('parent_id', $EmnXX)->update(['driver' => Tfi7lQDVWUJD9::S3, 'preview' => $uvyDL->getAttribute('preview'), 'thumbnail' => $uvyDL->getAttribute('thumbnail')]);
        goto pv5du;
        u0yI9:
        if ($uvyDL) {
            goto BXg6E;
        }
        goto n4HAE;
        gcChT:
        Log::info("Q48IcpSr3UpAT stored to S3, update the children attachments", ['fileId' => $EmnXX]);
        goto eT9Pc;
        Ku42K:
        rpOs3:
        goto UwE1G;
        nPz4K:
        $DXXBS = $uvyDL->getAttribute('thumbnail');
        goto aMmfA;
        ODuqT:
        $V1UKq = $this->JFHzD->path($DXXBS);
        goto tjSd3;
        NDcn9:
    }
    private function mHePQVRnd10($yOjDt, $xPDup, $VYTXo = '')
    {
        goto tnvlP;
        tnvlP:
        if (!$VYTXo) {
            goto iqXA5;
        }
        goto gfDMX;
        gfDMX:
        $yOjDt = str_replace('.jpg', $VYTXo, $yOjDt);
        goto PJ02W;
        PJ02W:
        $xPDup = str_replace('.jpg', $VYTXo, $xPDup);
        goto bd89z;
        bd89z:
        iqXA5:
        goto q5e3R;
        q5e3R:
        try {
            $AvW7Y = $this->Q1wpU->call($this, $yOjDt);
            $this->DksH2->put($xPDup, $this->JFHzD->get($xPDup), ['visibility' => 'public', 'ContentType' => $AvW7Y->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $p7PBd) {
            Log::error("Failed to upload image to S3", ['s3Path' => $xPDup, 'error' => $p7PBd->getMessage()]);
        }
        goto lsOG_;
        lsOG_:
    }
}
