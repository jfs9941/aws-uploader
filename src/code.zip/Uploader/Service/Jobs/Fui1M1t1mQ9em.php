<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class Fui1M1t1mQ9em implements StoreToS3JobInterface
{
    private $z0km_;
    private $zbU8n;
    private $ofZvx;
    public function __construct($BSNlm, $Efy84, $suNmN)
    {
        goto FqDXZ;
        FqDXZ:
        $this->zbU8n = $Efy84;
        goto Qb1zL;
        Qb1zL:
        $this->ofZvx = $suNmN;
        goto dd66q;
        dd66q:
        $this->z0km_ = $BSNlm;
        goto Nl4bk;
        Nl4bk:
    }
    public function store(string $N2oAf) : void
    {
        goto U90oQ;
        Us4sq:
        $murmt = $this->ofZvx->path($TgKLf);
        goto K0sbB;
        Dngms:
        v5kRG:
        goto QY9Hb;
        Oowao:
        $this->m2DLUmGPALB($vRakW, $aSnHH->getLocation());
        goto v7GeL;
        k8tuP:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $N2oAf]);
        goto eTMR5;
        K0sbB:
        $oEyCz = $this->z0km_->call($this, $murmt);
        goto vjmQe;
        Dtn1I:
        U9ps2:
        goto CFxct;
        SmyVN:
        JMa7GBaLcnq3D::where('parent_id', $N2oAf)->update(['driver' => I5kpK7wkbRQvu::S3, 'preview' => $aSnHH->getAttribute('preview'), 'thumbnail' => $aSnHH->getAttribute('thumbnail')]);
        goto da_QX;
        U90oQ:
        $aSnHH = JMa7GBaLcnq3D::findOrFail($N2oAf);
        goto hnlq9;
        YhAYD:
        $vRakW = $this->ofZvx->path($aSnHH->getLocation());
        goto Oowao;
        Pw0q4:
        z3ZSQ:
        goto YhAYD;
        dDHlY:
        $Ffx70 = $this->z0km_->call($this, $M3UnW);
        goto pj91c;
        MTDC1:
        if (!($TgKLf && $this->ofZvx->exists($TgKLf))) {
            goto v5kRG;
        }
        goto Us4sq;
        vjmQe:
        $this->zbU8n->put($aSnHH->getAttribute('thumbnail'), $this->ofZvx->get($TgKLf), ['visibility' => 'public', 'ContentType' => $oEyCz->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Dngms;
        hnlq9:
        if ($aSnHH) {
            goto z3ZSQ;
        }
        goto lb7d3;
        da_QX:
        return;
        goto zQGlE;
        pj91c:
        $this->zbU8n->put($aSnHH->getAttribute('preview'), $this->ofZvx->get($aSnHH->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $Ffx70->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Dtn1I;
        NmfgY:
        Log::info("JMa7GBaLcnq3D stored to S3, update the children attachments", ['fileId' => $N2oAf]);
        goto SmyVN;
        TDXTJ:
        return;
        goto Pw0q4;
        v7GeL:
        $TgKLf = $aSnHH->getAttribute('thumbnail');
        goto MTDC1;
        QY9Hb:
        if (!($aSnHH->getAttribute('preview') && $this->ofZvx->exists($aSnHH->getAttribute('preview')))) {
            goto U9ps2;
        }
        goto t1GAL;
        lb7d3:
        Log::info("JMa7GBaLcnq3D has been deleted, discard it", ['fileId' => $N2oAf]);
        goto TDXTJ;
        zQGlE:
        kO1bu:
        goto k8tuP;
        t1GAL:
        $M3UnW = $this->ofZvx->path($aSnHH->getAttribute('preview'));
        goto dDHlY;
        CFxct:
        if (!$aSnHH->update(['driver' => I5kpK7wkbRQvu::S3, 'status' => A9q1Lm9l5QixG::FINISHED])) {
            goto kO1bu;
        }
        goto NmfgY;
        eTMR5:
    }
    private function m2DLUmGPALB($rVHFh, $g4EgD, $qlMII = '')
    {
        goto i7xCF;
        i7xCF:
        if (!$qlMII) {
            goto IwfFH;
        }
        goto F_v4a;
        z7CuA:
        $g4EgD = str_replace('.jpg', $qlMII, $g4EgD);
        goto guN3Z;
        DUdFZ:
        try {
            $RxSHk = $this->z0km_->call($this, $rVHFh);
            $this->zbU8n->put($g4EgD, $this->ofZvx->get($g4EgD), ['visibility' => 'public', 'ContentType' => $RxSHk->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $oKDQw) {
            Log::error("Failed to upload image to S3", ['s3Path' => $g4EgD, 'error' => $oKDQw->getMessage()]);
        }
        goto wg4M8;
        guN3Z:
        IwfFH:
        goto DUdFZ;
        F_v4a:
        $rVHFh = str_replace('.jpg', $qlMII, $rVHFh);
        goto z7CuA;
        wg4M8:
    }
}
