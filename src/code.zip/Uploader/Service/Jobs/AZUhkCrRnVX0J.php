<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class AZUhkCrRnVX0J implements CompressJobInterface
{
    const J2DPL = 60;
    private $lT6tT;
    private $qeI_k;
    private $lCKqa;
    public function __construct($W4G5n, $ShtWH, $T1zaF)
    {
        goto EfKGL;
        EfKGL:
        $this->lT6tT = $W4G5n;
        goto uzcS2;
        uzcS2:
        $this->lCKqa = $T1zaF;
        goto E2JFC;
        E2JFC:
        $this->qeI_k = $ShtWH;
        goto OPX1B;
        OPX1B:
    }
    public function compress(string $DWjir)
    {
        goto Mi8Jq;
        cBLQ1:
        $nmnvM = memory_get_peak_usage();
        goto c4xIe;
        iqtNJ:
        $eRyKR = memory_get_usage();
        goto cBLQ1;
        nnh2Y:
        try {
            goto WK_Qo;
            Ym9e8:
            $h3Mkx = $this->qeI_k->path($KlHaV->getLocation());
            goto MyZOq;
            WK_Qo:
            $KlHaV = IQJN6V0t7DC7c::findOrFail($DWjir);
            goto Ym9e8;
            PtyOY:
            mPzTJ:
            goto XW8PQ;
            MyZOq:
            if (!(strtolower($KlHaV->getExtension()) === 'png' || strtolower($KlHaV->getExtension()) === 'heic')) {
                goto mPzTJ;
            }
            goto WDASP;
            XW8PQ:
            try {
                goto Rj2qr;
                GsUhJ:
                $this->mLrvi9OMT06($h3Mkx, $wHSbH);
                goto vf3IW;
                vf3IW:
                $this->mk2aDadtinJ($KlHaV, 'webp');
                goto tgrVb;
                Rj2qr:
                $wHSbH = $this->qeI_k->path(str_replace('.jpg', '.webp', $KlHaV->getLocation()));
                goto GsUhJ;
                tgrVb:
            } catch (\Exception $dMDxf) {
                goto WoGBa;
                WoGBa:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $DWjir, 'error' => $dMDxf->getMessage()]);
                goto UqlWq;
                GPJ5O:
                $this->mhykvl9Ekay($h3Mkx, $wHSbH);
                goto eFs08;
                UqlWq:
                $wHSbH = $this->qeI_k->path($KlHaV->getLocation());
                goto GPJ5O;
                eFs08:
            }
            goto Bu2ah;
            WDASP:
            $KlHaV = $this->mk2aDadtinJ($KlHaV, 'jpg');
            goto PtyOY;
            Bu2ah:
        } catch (\Throwable $dMDxf) {
            goto dweLT;
            day70:
            Log::error("Failed to compress image", ['imageId' => $DWjir, 'error' => $dMDxf->getMessage()]);
            goto xG87a;
            h_2NR:
            bG_RH:
            goto day70;
            Uk05d:
            Log::info("IQJN6V0t7DC7c has been deleted, discard it", ['imageId' => $DWjir]);
            goto xqklu;
            xqklu:
            return;
            goto h_2NR;
            dweLT:
            if (!$dMDxf instanceof ModelNotFoundException) {
                goto bG_RH;
            }
            goto Uk05d;
            xG87a:
        } finally {
            $SoVKt = microtime(true);
            $aV3nd = memory_get_usage();
            $PoneH = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $DWjir, 'execution_time_sec' => $SoVKt - $oDOT6, 'memory_usage_mb' => ($aV3nd - $eRyKR) / 1024 / 1024, 'peak_memory_usage_mb' => ($PoneH - $nmnvM) / 1024 / 1024]);
        }
        goto L1ziC;
        c4xIe:
        Log::info("Compress image", ['imageId' => $DWjir]);
        goto nnh2Y;
        Mi8Jq:
        $oDOT6 = microtime(true);
        goto iqtNJ;
        L1ziC:
    }
    private function mhykvl9Ekay($h3Mkx, $wHSbH)
    {
        goto y8Bet;
        y8Bet:
        $C_gXz = $this->lT6tT->call($this, $h3Mkx);
        goto yWnkB;
        mN7P2:
        unset($C_gXz);
        goto I1oF5;
        SDvwB:
        $this->lCKqa->put($wHSbH, $C_gXz->toJpeg(self::J2DPL), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto mN7P2;
        yWnkB:
        $C_gXz->orient()->toJpeg(self::J2DPL)->save($wHSbH);
        goto SDvwB;
        I1oF5:
    }
    private function mLrvi9OMT06($h3Mkx, $wHSbH)
    {
        goto xNKHy;
        Uj0tD:
        unset($C_gXz);
        goto p4coc;
        FHEB8:
        $C_gXz->orient()->toWebp(self::J2DPL);
        goto LsZar;
        LsZar:
        $this->lCKqa->put($wHSbH, $C_gXz->toJpeg(self::J2DPL), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto Uj0tD;
        xNKHy:
        $C_gXz = $this->lT6tT->call($this, $h3Mkx);
        goto FHEB8;
        p4coc:
    }
    private function mk2aDadtinJ($KlHaV, $X7Oue)
    {
        goto U9F0Q;
        Uj0C5:
        $KlHaV->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$X7Oue}", $KlHaV->getLocation()));
        goto EtWU0;
        EtWU0:
        $KlHaV->save();
        goto dZMjh;
        dZMjh:
        return $KlHaV;
        goto OxS3c;
        U9F0Q:
        $KlHaV->setAttribute('type', $X7Oue);
        goto Uj0C5;
        OxS3c:
    }
}
