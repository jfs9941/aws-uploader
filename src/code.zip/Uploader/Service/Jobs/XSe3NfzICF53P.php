<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Enum\DccywYjigTakI;
class XSe3NfzICF53P implements BlurJobInterface
{
    const aY9dS = 15;
    const ANrIH = 500;
    const jYR2C = 500;
    private $xy0Yf;
    private $gErml;
    private $mzObC;
    public function __construct($ppK7O, $DFpIk, $L1VX0)
    {
        goto SjF5Q;
        SjF5Q:
        $this->mzObC = $L1VX0;
        goto EQcA2;
        LTUrL:
        $this->xy0Yf = $ppK7O;
        goto xiKLw;
        EQcA2:
        $this->gErml = $DFpIk;
        goto LTUrL;
        xiKLw:
    }
    public function blur(string $J_scC) : void
    {
        goto AwqIS;
        aiCAl:
        $VWXEV->blur(self::aY9dS);
        goto Ap_q6;
        Gdydz:
        ev3or:
        goto d6sw0;
        pK71J:
        ini_set('memory_limit', '-1');
        goto cmYyU;
        cmYyU:
        if (!($VNJ0D->driver == DccywYjigTakI::S3 && !$this->mzObC->exists($VNJ0D->filename))) {
            goto ev3or;
        }
        goto a32bX;
        Ap_q6:
        $qIpsP = $this->mKTAZroKjOI($VNJ0D);
        goto HQ2WL;
        d6sw0:
        $VWXEV = $this->xy0Yf->call($this, $this->mzObC->path($VNJ0D->getLocation()));
        goto eNh3H;
        DLBPb:
        $VNJ0D->update(['preview' => $qIpsP]);
        goto t3kZv;
        gqcvt:
        if (chmod($NBdEx, 0664)) {
            goto QanhM;
        }
        goto DT1qG;
        W_lwr:
        $VWXEV->resize(self::ANrIH, self::jYR2C / $JKeeA);
        goto aiCAl;
        eNh3H:
        $JKeeA = $VWXEV->width() / $VWXEV->height();
        goto W_lwr;
        kP3YZ:
        $this->mzObC->put($VNJ0D->filename, $bwoAz);
        goto Gdydz;
        AwqIS:
        $VNJ0D = XK5kReLMTU1ob::findOrFail($J_scC);
        goto pK71J;
        HQ2WL:
        $NBdEx = $this->gErml->put($qIpsP, $VWXEV->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Q4iJ_;
        Ndr0Y:
        QanhM:
        goto DLBPb;
        mcbdP:
        throw new \Exception('Failed to set final permissions on image file: ' . $NBdEx);
        goto Ndr0Y;
        a32bX:
        $bwoAz = $this->gErml->get($VNJ0D->filename);
        goto kP3YZ;
        Q4iJ_:
        unset($VWXEV);
        goto gqcvt;
        DT1qG:
        \Log::warning('Failed to set final permissions on image file: ' . $NBdEx);
        goto mcbdP;
        t3kZv:
    }
    private function mKTAZroKjOI($MPjk0) : string
    {
        goto JevUH;
        JevUH:
        $hU2b_ = $MPjk0->getLocation();
        goto FZIRe;
        NrvDs:
        ohnmD:
        goto gAstv;
        zTvYx:
        $this->mzObC->makeDirectory($uH7tx, 0755, true);
        goto NrvDs;
        SI1WB:
        if ($this->mzObC->exists($uH7tx)) {
            goto ohnmD;
        }
        goto zTvYx;
        gAstv:
        return $uH7tx . $MPjk0->getFilename() . '.jpg';
        goto ONOmg;
        FZIRe:
        $uH7tx = dirname($hU2b_) . '/preview/';
        goto SI1WB;
        ONOmg:
    }
}
