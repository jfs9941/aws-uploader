<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\NBWuSM65HseqY;
class HqeYjYMoPzMvo implements WatermarkTextJobInterface
{
    private $xI8aP;
    private $NzdTN;
    private $h6c5V;
    private $GQuun;
    private $OKvrN;
    public function __construct($uIkIq, $DvaDk, $Q0shJ, $GiTtn, $b1Yah)
    {
        goto WnI6O;
        qTDEp:
        $this->OKvrN = $GiTtn;
        goto LNsm1;
        qrRkY:
        $this->GQuun = $Q0shJ;
        goto qTDEp;
        LGHkv:
        $this->NzdTN = $DvaDk;
        goto TjzN5;
        LNsm1:
        $this->h6c5V = $b1Yah;
        goto LGHkv;
        WnI6O:
        $this->xI8aP = $uIkIq;
        goto qrRkY;
        TjzN5:
    }
    public function putWatermark(string $eXur0, string $hkNHZ) : void
    {
        goto YbR6l;
        iAKt0:
        ini_set('memory_limit', '-1');
        goto xChTs;
        xChTs:
        try {
            goto x2RHm;
            WFYBb:
            $BIC8T->destroy();
            goto HLNAg;
            Bqqmw:
            \Log::warning('Failed to set final permissions on image file: ' . $Y7TgX);
            goto KFOYm;
            o5PEm:
            $this->mcpTMuIXhIk($BIC8T, $hkNHZ);
            goto l63Ky;
            mDw60:
            $BIC8T->orientate();
            goto o5PEm;
            FLzfr:
            if ($this->OKvrN->exists($CPHMS->getLocation())) {
                goto z8YAI;
            }
            goto QrURB;
            x2RHm:
            $CPHMS = NBWuSM65HseqY::findOrFail($eXur0);
            goto FLzfr;
            QrURB:
            Log::error("NBWuSM65HseqY is not on local, might be deleted before put watermark", ['imageId' => $eXur0]);
            goto HTsYC;
            MUIN5:
            nG9zb:
            goto Xq4C4;
            l63Ky:
            $BIC8T->save($Y7TgX);
            goto WFYBb;
            j1gr8:
            $BIC8T = $this->xI8aP->call($this, $Y7TgX);
            goto mDw60;
            KFOYm:
            throw new \Exception('Failed to set final permissions on image file: ' . $Y7TgX);
            goto MUIN5;
            SrjNl:
            $Y7TgX = $this->OKvrN->path($CPHMS->getLocation());
            goto j1gr8;
            HLNAg:
            if (chmod($Y7TgX, 0664)) {
                goto nG9zb;
            }
            goto Bqqmw;
            HTsYC:
            return;
            goto p7BLY;
            p7BLY:
            z8YAI:
            goto SrjNl;
            Xq4C4:
        } catch (\Throwable $E5ifV) {
            goto SV6C9;
            nAm3K:
            Log::info("NBWuSM65HseqY has been deleted, discard it", ['imageId' => $eXur0]);
            goto YifX2;
            SV6C9:
            if (!$E5ifV instanceof ModelNotFoundException) {
                goto zXxbK;
            }
            goto nAm3K;
            YifX2:
            return;
            goto Cax_d;
            Y_wUH:
            Log::error("NBWuSM65HseqY is not readable", ['imageId' => $eXur0, 'error' => $E5ifV->getMessage()]);
            goto xiiwv;
            Cax_d:
            zXxbK:
            goto Y_wUH;
            xiiwv:
        }
        goto lFPBc;
        YbR6l:
        Log::info("Adding watermark text to image", ['imageId' => $eXur0]);
        goto iAKt0;
        lFPBc:
    }
    private function mcpTMuIXhIk($BIC8T, $hkNHZ) : void
    {
        goto C55NS;
        C55NS:
        $vwL5B = $BIC8T->width();
        goto fCSMf;
        FhEPo:
        $BIC8T->insert($Hq1oM);
        goto d40jH;
        p7NDv:
        $vdOts = $mzkQL->mUbg5R9jG4v($vwL5B, $ttadT, $hkNHZ, true);
        goto JXusP;
        fCSMf:
        $ttadT = $BIC8T->height();
        goto oP1LV;
        GCCqx:
        $Hq1oM = $this->xI8aP->call($this, $this->OKvrN->path($vdOts));
        goto Dci_B;
        oP1LV:
        $mzkQL = new CPZOjRiIao943($this->NzdTN, $this->h6c5V, $this->GQuun, $this->OKvrN);
        goto p7NDv;
        JXusP:
        $this->OKvrN->put($vdOts, $this->GQuun->get($vdOts));
        goto GCCqx;
        Dci_B:
        $Hq1oM->opacity(35);
        goto FhEPo;
        d40jH:
    }
}
