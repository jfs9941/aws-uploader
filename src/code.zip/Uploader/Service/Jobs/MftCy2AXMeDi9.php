<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
class MftCy2AXMeDi9 implements StoreToS3JobInterface
{
    private $Ie_ZE;
    private $MV0lK;
    private $P2FvH;
    public function __construct($jSZw8, $tYsty, $j8mv9)
    {
        goto e2FY3;
        l4Q9U:
        $this->P2FvH = $j8mv9;
        goto cIy0C;
        e2FY3:
        $this->MV0lK = $tYsty;
        goto l4Q9U;
        cIy0C:
        $this->Ie_ZE = $jSZw8;
        goto whBEU;
        whBEU:
    }
    public function store(string $FILUb) : void
    {
        goto nD0Bq;
        fJlVh:
        Log::info("XbYF8aa0XyGnI has been deleted, discard it", ['fileId' => $FILUb]);
        goto yCt_K;
        ETLAg:
        return;
        goto QS10h;
        jMxBK:
        $lcE2B = $this->P2FvH->path($H0Tel);
        goto yzKR0;
        A0FXH:
        if ($QhMNH) {
            goto S35xc;
        }
        goto fJlVh;
        r5CZD:
        $H0Tel = $QhMNH->getAttribute('thumbnail');
        goto HyRSz;
        cahKv:
        $wdMF_ = $this->Ie_ZE->call($this, $pTbWI);
        goto c1p2w;
        tmyx_:
        $this->MV0lK->put($QhMNH->getLocation(), $FGBix->stream(), ['visibility' => 'public', 'ContentType' => $FGBix->mime(), 'ContentDisposition' => 'inline']);
        goto r5CZD;
        pJQ2Z:
        $FGBix = $this->Ie_ZE->call($this, $Sblyk);
        goto tmyx_;
        SlFjK:
        $Sblyk = $this->P2FvH->path($QhMNH->getLocation());
        goto pJQ2Z;
        yCt_K:
        return;
        goto Zf9tw;
        sbJoV:
        Mqknc:
        goto qlLHC;
        j9OIV:
        $this->MV0lK->put($QhMNH->getAttribute('thumbnail'), $E2RLT->stream(), ['visibility' => 'public', 'ContentType' => $E2RLT->mime(), 'ContentDisposition' => 'inline']);
        goto sbJoV;
        XcmvK:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $FILUb]);
        goto gOF6I;
        nD0Bq:
        $QhMNH = XbYF8aa0XyGnI::findOrFail($FILUb);
        goto A0FXH;
        qlLHC:
        if (!($QhMNH->getAttribute('preview') && $this->P2FvH->exists($QhMNH->getAttribute('preview')))) {
            goto v1Pao;
        }
        goto Su75C;
        c1p2w:
        $this->MV0lK->put($QhMNH->getAttribute('preview'), $wdMF_->stream(), ['visibility' => 'public', 'ContentType' => $wdMF_->mime(), 'ContentDisposition' => 'inline']);
        goto vuaBz;
        Zf9tw:
        S35xc:
        goto SlFjK;
        Su75C:
        $pTbWI = $this->P2FvH->path($QhMNH->getAttribute('preview'));
        goto cahKv;
        akMre:
        if (!$QhMNH->update(['driver' => N0ISad2bKF2Yp::S3, 'status' => EPmxqTVp5luXc::FINISHED])) {
            goto Ot3pA;
        }
        goto LHme9;
        CtsXB:
        XbYF8aa0XyGnI::where('parent_id', $FILUb)->update(['driver' => N0ISad2bKF2Yp::S3, 'preview' => $QhMNH->getAttribute('preview'), 'thumbnail' => $QhMNH->getAttribute('thumbnail')]);
        goto ETLAg;
        QS10h:
        Ot3pA:
        goto XcmvK;
        yzKR0:
        $E2RLT = $this->Ie_ZE->call($this, $lcE2B);
        goto j9OIV;
        vuaBz:
        v1Pao:
        goto akMre;
        LHme9:
        Log::info("XbYF8aa0XyGnI stored to S3, update the children attachments", ['fileId' => $FILUb]);
        goto CtsXB;
        HyRSz:
        if (!($H0Tel && $this->P2FvH->exists($H0Tel))) {
            goto Mqknc;
        }
        goto jMxBK;
        gOF6I:
    }
}
