<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class WMJwYTA7UMAWb implements StoreToS3JobInterface
{
    private $KXch8;
    private $VoF9h;
    private $oBaPs;
    public function __construct($FeIAB, $BQ2l1, $paaZf)
    {
        goto sJRjK;
        VrEPo:
        $this->KXch8 = $FeIAB;
        goto Yfsk3;
        sJRjK:
        $this->VoF9h = $BQ2l1;
        goto tLGnQ;
        tLGnQ:
        $this->oBaPs = $paaZf;
        goto VrEPo;
        Yfsk3:
    }
    public function store(string $JTwN4) : void
    {
        goto frh93;
        GOlvl:
        $uMpUA = $this->oBaPs->path($Oz_QK->getLocation());
        goto N0iH9;
        tZyqR:
        Log::info("Z7LUL65CwqbbF has been deleted, discard it", ['fileId' => $JTwN4]);
        goto dtLu9;
        oiqzp:
        sefWP:
        goto GOlvl;
        PzkaF:
        if (!$Oz_QK->update(['driver' => A3VATad7gvqZU::S3, 'status' => FdWrko7bmoI4Y::FINISHED])) {
            goto QxX5R;
        }
        goto KiNHF;
        ik1nY:
        Z7LUL65CwqbbF::where('parent_id', $JTwN4)->update(['driver' => A3VATad7gvqZU::S3, 'preview' => $Oz_QK->getAttribute('preview'), 'thumbnail' => $Oz_QK->getAttribute('thumbnail')]);
        goto Jtkhr;
        N0iH9:
        $this->m6Wqz2XT0tF($uMpUA, $Oz_QK->getLocation());
        goto KOkJy;
        frh93:
        $Oz_QK = Z7LUL65CwqbbF::findOrFail($JTwN4);
        goto uALKZ;
        WK6MR:
        P_ONl:
        goto PzkaF;
        KiNHF:
        Log::info("Z7LUL65CwqbbF stored to S3, update the children attachments", ['fileId' => $JTwN4]);
        goto ik1nY;
        fOYFJ:
        if (!($NGnKp && $this->oBaPs->exists($NGnKp))) {
            goto brcmT;
        }
        goto LtywE;
        G7pzT:
        if (!($Oz_QK->getAttribute('preview') && $this->oBaPs->exists($Oz_QK->getAttribute('preview')))) {
            goto P_ONl;
        }
        goto Vm2tY;
        b_mey:
        brcmT:
        goto G7pzT;
        GQCQC:
        QxX5R:
        goto fE0d_;
        zrYDx:
        $EOewM = $this->KXch8->call($this, $vk8Z1);
        goto rIuli;
        LtywE:
        $k8q_U = $this->oBaPs->path($NGnKp);
        goto TOdTb;
        Jtkhr:
        return;
        goto GQCQC;
        uALKZ:
        if ($Oz_QK) {
            goto sefWP;
        }
        goto tZyqR;
        rIuli:
        $this->VoF9h->put($Oz_QK->getAttribute('preview'), $this->oBaPs->get($Oz_QK->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $EOewM->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto WK6MR;
        fE0d_:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $JTwN4]);
        goto Hftg7;
        TOdTb:
        $fMTw4 = $this->KXch8->call($this, $k8q_U);
        goto qMSBp;
        qMSBp:
        $this->VoF9h->put($Oz_QK->getAttribute('thumbnail'), $this->oBaPs->get($NGnKp), ['visibility' => 'public', 'ContentType' => $fMTw4->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto b_mey;
        dtLu9:
        return;
        goto oiqzp;
        Vm2tY:
        $vk8Z1 = $this->oBaPs->path($Oz_QK->getAttribute('preview'));
        goto zrYDx;
        KOkJy:
        $NGnKp = $Oz_QK->getAttribute('thumbnail');
        goto fOYFJ;
        Hftg7:
    }
    private function m6Wqz2XT0tF($Bb6sk, $ZvoMh, $oBMq2 = '')
    {
        goto aKvQB;
        jk_FW:
        $Bb6sk = str_replace('.jpg', $oBMq2, $Bb6sk);
        goto qBeYA;
        w25Nd:
        e9SWi:
        goto MOf69;
        aKvQB:
        if (!$oBMq2) {
            goto e9SWi;
        }
        goto jk_FW;
        qBeYA:
        $ZvoMh = str_replace('.jpg', $oBMq2, $ZvoMh);
        goto w25Nd;
        MOf69:
        try {
            $a97TB = $this->KXch8->call($this, $Bb6sk);
            $this->VoF9h->put($ZvoMh, $this->oBaPs->get($ZvoMh), ['visibility' => 'public', 'ContentType' => $a97TB->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $tfcsO) {
            Log::error("Failed to upload image to S3", ['s3Path' => $ZvoMh, 'error' => $tfcsO->getMessage()]);
        }
        goto ws8x2;
        ws8x2:
    }
}
