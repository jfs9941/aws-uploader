<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Illuminate\Support\Facades\Log;
class C15thK7H3B3RF implements DownloadToLocalJobInterface
{
    private $BfyCm;
    private $S0euz;
    public function __construct($ejImE, $t9rFg)
    {
        $this->BfyCm = $ejImE;
        $this->S0euz = $t9rFg;
    }
    public function download(string $aK0gt) : void
    {
        goto UTTGq;
        amwCE:
        rtQ3s:
        goto La6__;
        UTTGq:
        $s2INV = MpPzMcfcRTISZ::findOrFail($aK0gt);
        goto WdDu3;
        La6__:
        $this->S0euz->put($s2INV->getLocation(), $this->BfyCm->get($s2INV->getLocation()));
        goto cMCJZ;
        ifz85:
        if (!$this->S0euz->exists($s2INV->getLocation())) {
            goto rtQ3s;
        }
        goto fnmg5;
        fnmg5:
        return;
        goto amwCE;
        WdDu3:
        Log::info("Start download file to local", ['fileId' => $aK0gt, 'filename' => $s2INV->getLocation()]);
        goto ifz85;
        cMCJZ:
    }
}
