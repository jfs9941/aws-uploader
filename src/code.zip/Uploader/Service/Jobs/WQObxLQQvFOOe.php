<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
use src\Uploader\Core\YdClVYDRbSDMR;
class WQObxLQQvFOOe implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $BFPg9) : void
    {
        goto nHmJH;
        mZDQE:
        $this->mm2zhjEvdRb($iit8z);
        goto f6zKk;
        f6zKk:
        JrPsO:
        goto lMYiB;
        nHmJH:
        $iit8z = YdClVYDRbSDMR::findOrFail($BFPg9);
        goto FGJcL;
        FGJcL:
        if ($iit8z->width() > 0 && $iit8z->height() > 0) {
            goto JrPsO;
        }
        goto mZDQE;
        lMYiB:
    }
    private function mm2zhjEvdRb(YdClVYDRbSDMR $BUvH7) : void
    {
        goto ou3fZ;
        Ch7ah:
        $seJh0 = $g3tXT->getDimensions();
        goto rMshr;
        EzHuG:
        $g3tXT = $ymghJ->getVideoStream();
        goto Ch7ah;
        ou3fZ:
        $S62kT = $BUvH7->getView();
        goto uK_0h;
        uK_0h:
        $ymghJ = FFMpeg::fromDisk($S62kT['path'])->open($BUvH7->getAttribute('filename'));
        goto EzHuG;
        rMshr:
        $BUvH7->update(['duration' => $ymghJ->getDurationInSeconds(), 'resolution' => $seJh0->getWidth() . 'x' . $seJh0->getHeight(), 'fps' => $g3tXT->get('r_frame_rate') ?? 30]);
        goto eLyad;
        eLyad:
    }
}
