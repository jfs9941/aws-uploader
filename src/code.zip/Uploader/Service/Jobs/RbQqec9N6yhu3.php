<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
class RbQqec9N6yhu3 implements StoreToS3JobInterface
{
    private $xI8aP;
    private $GQuun;
    private $Farqu;
    public function __construct($uIkIq, $Q0shJ, $MQQLd)
    {
        goto K7thw;
        U2gY1:
        $this->xI8aP = $uIkIq;
        goto HTh6E;
        K7thw:
        $this->GQuun = $Q0shJ;
        goto qabs9;
        qabs9:
        $this->Farqu = $MQQLd;
        goto U2gY1;
        HTh6E:
    }
    public function store(string $eXur0) : void
    {
        goto oLqVd;
        oU7PB:
        $Y7TgX = $this->Farqu->path($Wd8o2->getLocation());
        goto qck7g;
        Zsaku:
        if (!$Wd8o2->update(['driver' => VCKF0xK25vLxq::S3, 'status' => N4CY6qDTBAjPa::FINISHED])) {
            goto Ad1kW;
        }
        goto VvhTN;
        uVi8C:
        if (!($Wd8o2->getAttribute('preview') && $this->Farqu->exists($Wd8o2->getAttribute('preview')))) {
            goto wLS2p;
        }
        goto v21Ys;
        A39jc:
        Yi_wk:
        goto oU7PB;
        SI55o:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $eXur0]);
        goto tt1cv;
        eKVwM:
        XVu_f:
        goto uVi8C;
        uyWop:
        return;
        goto A39jc;
        oLqVd:
        $Wd8o2 = NBWuSM65HseqY::findOrFail($eXur0);
        goto vkV83;
        Eft4Z:
        $i0DCk = $Wd8o2->getAttribute('thumbnail');
        goto zAbXf;
        v21Ys:
        $Q0sMv = $this->Farqu->path($Wd8o2->getAttribute('preview'));
        goto YSyo7;
        vkV83:
        if ($Wd8o2) {
            goto Yi_wk;
        }
        goto ZR7Iy;
        WkI3G:
        $this->GQuun->put($Wd8o2->getLocation(), $CPHMS->stream(), ['visibility' => 'public', 'ContentType' => $CPHMS->mime(), 'ContentDisposition' => 'inline']);
        goto Eft4Z;
        tWpQJ:
        wLS2p:
        goto Zsaku;
        tTt3H:
        NBWuSM65HseqY::where('parent_id', $eXur0)->update(['driver' => VCKF0xK25vLxq::S3, 'preview' => $Wd8o2->getAttribute('preview'), 'thumbnail' => $Wd8o2->getAttribute('thumbnail')]);
        goto WTamk;
        ZR7Iy:
        Log::info("NBWuSM65HseqY has been deleted, discard it", ['fileId' => $eXur0]);
        goto uyWop;
        oE5UL:
        $jVS4s = $this->xI8aP->call($this, $qSReT);
        goto LN0k7;
        dcqDd:
        $this->GQuun->put($Wd8o2->getAttribute('preview'), $lzaF1->stream(), ['visibility' => 'public', 'ContentType' => $lzaF1->mime(), 'ContentDisposition' => 'inline']);
        goto tWpQJ;
        WTamk:
        return;
        goto x3t3_;
        VvhTN:
        Log::info("NBWuSM65HseqY stored to S3, update the children attachments", ['fileId' => $eXur0]);
        goto tTt3H;
        rogS0:
        $qSReT = $this->Farqu->path($i0DCk);
        goto oE5UL;
        YSyo7:
        $lzaF1 = $this->xI8aP->call($this, $Q0sMv);
        goto dcqDd;
        LN0k7:
        $this->GQuun->put($Wd8o2->getAttribute('thumbnail'), $jVS4s->stream(), ['visibility' => 'public', 'ContentType' => $jVS4s->mime(), 'ContentDisposition' => 'inline']);
        goto eKVwM;
        qck7g:
        $CPHMS = $this->xI8aP->call($this, $Y7TgX);
        goto WkI3G;
        x3t3_:
        Ad1kW:
        goto SI55o;
        zAbXf:
        if (!($i0DCk && $this->Farqu->exists($i0DCk))) {
            goto XVu_f;
        }
        goto rogS0;
        tt1cv:
    }
}
