<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DmB4kwnwstr5R implements GenerateThumbnailJobInterface
{
    const h2WRV = 150;
    const UJSmU = 150;
    private $Q1wpU;
    private $JFHzD;
    private $B0BKT;
    public function __construct($kuI8f, $NVuHg, $X3WMV)
    {
        goto WmbY6;
        WmbY6:
        $this->Q1wpU = $kuI8f;
        goto Hv_gB;
        xU28D:
        $this->B0BKT = $X3WMV;
        goto TqtAY;
        Hv_gB:
        $this->JFHzD = $NVuHg;
        goto xU28D;
        TqtAY:
    }
    public function generate(string $EmnXX)
    {
        goto sdixl;
        QYKaf:
        try {
            goto VTIjP;
            ane3q:
            $cJV8L = $this->ma6eQJHB5RK($AvW7Y);
            goto HpK7j;
            ho8K1:
            DNxkG:
            goto yJQk6;
            AD5vY:
            $R_9gW->orient()->resize(150, 150);
            goto ane3q;
            VTIjP:
            $YNIuu = $this->JFHzD;
            goto r5Ewc;
            n2wp5:
            unset($R_9gW);
            goto AA5ud;
            r5Ewc:
            $AvW7Y = Q48IcpSr3UpAT::findOrFail($EmnXX);
            goto Ks4ng;
            HpK7j:
            $d1Rfo = $this->B0BKT->put($cJV8L, $R_9gW->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto n2wp5;
            rjMmY:
            $AvW7Y->update(['thumbnail' => $cJV8L, 'status' => FmSSI1JLQCp0W::THUMBNAIL_PROCESSED]);
            goto ho8K1;
            AA5ud:
            if (!($d1Rfo !== false)) {
                goto DNxkG;
            }
            goto rjMmY;
            Ks4ng:
            $R_9gW = $this->Q1wpU->call($this, $YNIuu->path($AvW7Y->getLocation()));
            goto AD5vY;
            yJQk6:
        } catch (ModelNotFoundException $SoaRh) {
            Log::info("Q48IcpSr3UpAT has been deleted, discard it", ['imageId' => $EmnXX]);
            return;
        } catch (\Exception $SoaRh) {
            Log::error("Failed to generate thumbnail", ['imageId' => $EmnXX, 'error' => $SoaRh->getMessage()]);
        }
        goto nYn3a;
        Y14Rn:
        ini_set('memory_limit', '-1');
        goto QYKaf;
        sdixl:
        Log::info("Generating thumbnail", ['imageId' => $EmnXX]);
        goto Y14Rn;
        nYn3a:
    }
    private function ma6eQJHB5RK(THrRXrYMGJt0m $AvW7Y) : string
    {
        goto VQONg;
        y7kX3:
        $UlMgI = $kwulB . '/' . self::h2WRV . 'X' . self::UJSmU;
        goto FftsD;
        VQONg:
        $cJV8L = $AvW7Y->getLocation();
        goto hfzQj;
        FftsD:
        return $UlMgI . '/' . $AvW7Y->getFilename() . '.jpg';
        goto Ke45h;
        hfzQj:
        $kwulB = dirname($cJV8L);
        goto y7kX3;
        Ke45h:
    }
}
