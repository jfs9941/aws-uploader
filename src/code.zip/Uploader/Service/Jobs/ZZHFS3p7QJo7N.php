<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ZZHFS3p7QJo7N
{
    private $KgleU;
    private $WWN8T;
    public function __construct(int $GK7e4, int $ttxLD)
    {
        goto Y0NRK;
        NBsc9:
        we9p3:
        goto OLxyJ;
        OLxyJ:
        if (!($ttxLD <= 0)) {
            goto qB0lp;
        }
        goto eAP3k;
        AdjDc:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto NBsc9;
        Y0NRK:
        if (!($GK7e4 <= 0)) {
            goto we9p3;
        }
        goto AdjDc;
        vhy6O:
        qB0lp:
        goto KOd0A;
        eAP3k:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto vhy6O;
        KOd0A:
        $this->KgleU = $GK7e4;
        goto queWO;
        queWO:
        $this->WWN8T = $ttxLD;
        goto bMKcV;
        bMKcV:
    }
    private static function mcFG0MBBoYv($K1Ql5, string $CMGRt = 'floor') : int
    {
        goto Q5aue;
        JYRxk:
        if (!(is_float($K1Ql5) && $K1Ql5 == floor($K1Ql5) && (int) $K1Ql5 % 2 === 0)) {
            goto GShvM;
        }
        goto jI5xz;
        QQ8Mb:
        YxfN_:
        goto Rfeyz;
        Q5aue:
        if (!(is_int($K1Ql5) && $K1Ql5 % 2 === 0)) {
            goto Eqf0P;
        }
        goto ReIV_;
        Rfeyz:
        NpI0J:
        goto mmH9F;
        jZHws:
        switch (strtolower($CMGRt)) {
            case 'ceil':
                return (int) (ceil($K1Ql5 / 2) * 2);
            case 'round':
                return (int) (round($K1Ql5 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($K1Ql5 / 2) * 2);
        }
        goto QQ8Mb;
        X9Lsh:
        Eqf0P:
        goto JYRxk;
        qFWym:
        GShvM:
        goto jZHws;
        jI5xz:
        return (int) $K1Ql5;
        goto qFWym;
        ReIV_:
        return $K1Ql5;
        goto X9Lsh;
        mmH9F:
    }
    public function mJTgjdxagQ2(string $ngCKx = 'floor') : array
    {
        goto JaJyU;
        ZPf0o:
        $r9fI3 = 0;
        goto psuJT;
        lkucM:
        $r9fI3 = self::mcFG0MBBoYv(round($md02V), $ngCKx);
        goto yYunT;
        MorPW:
        $uAr_0 = $r9fI3 / $this->WWN8T;
        goto UaMv_;
        yYunT:
        goto yOaRC;
        goto M7VNe;
        b8rdg:
        $PKjeB = self::mcFG0MBBoYv(round($EPnYM), $ngCKx);
        goto hsGUo;
        kCIG4:
        $r9fI3 = $r351T;
        goto MorPW;
        yRHhm:
        $uAr_0 = $PKjeB / $this->KgleU;
        goto Z7leU;
        Hau3C:
        return ['width' => $PKjeB, 'height' => $r9fI3];
        goto gU4sY;
        Sgzy8:
        bbISX:
        goto Hau3C;
        XgPZL:
        $PKjeB = $r351T;
        goto yRHhm;
        TGHWN:
        dfJ9b:
        goto sun2Z;
        vS_iC:
        if (!($PKjeB < 2)) {
            goto dfJ9b;
        }
        goto pYI0m;
        sun2Z:
        if (!($r9fI3 < 2)) {
            goto bbISX;
        }
        goto V2QjL;
        pYI0m:
        $PKjeB = 2;
        goto TGHWN;
        psuJT:
        if ($this->KgleU >= $this->WWN8T) {
            goto w2kPC;
        }
        goto XgPZL;
        hsGUo:
        yOaRC:
        goto vS_iC;
        JaJyU:
        $r351T = 1080;
        goto ZfaTP;
        V2QjL:
        $r9fI3 = 2;
        goto Sgzy8;
        ZfaTP:
        $PKjeB = 0;
        goto ZPf0o;
        M7VNe:
        w2kPC:
        goto kCIG4;
        Z7leU:
        $md02V = $this->WWN8T * $uAr_0;
        goto lkucM;
        UaMv_:
        $EPnYM = $this->KgleU * $uAr_0;
        goto b8rdg;
        gU4sY:
    }
}
