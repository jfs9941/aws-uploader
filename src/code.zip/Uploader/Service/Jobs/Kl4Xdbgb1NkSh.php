<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Encoder\B0X93rEANSGOM;
use Jfs\Uploader\Encoder\PKHDooQHU3M1o;
use Jfs\Uploader\Encoder\Q0BHItA6POhGn;
use Jfs\Uploader\Encoder\Rfh6lYKf1Vsjf;
use Jfs\Uploader\Encoder\KrL5TSTQDAqUK;
use Jfs\Uploader\Encoder\Zp6bjD8AQnl45;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Jfs\Uploader\Service\Jobs\HOtxsT8ZNbu6T;
use Jfs\Uploader\Service\Jobs\LiCaZN7AKYxeE;
use Jfs\Uploader\Service\KA9RxVwCbkfZQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class Kl4Xdbgb1NkSh implements MediaEncodeJobInterface
{
    private $n4bxV;
    private $FHcNr;
    private $VJN91;
    private $ie3Jn;
    private $Fz8fG;
    public function __construct(string $dxOEL, $z279S, $J83Op, $VWeyA, $w9RjZ)
    {
        goto FYqil;
        FYqil:
        $this->n4bxV = $dxOEL;
        goto KWBkZ;
        KWBkZ:
        $this->FHcNr = $z279S;
        goto jur5n;
        jur5n:
        $this->VJN91 = $J83Op;
        goto vdenO;
        vdenO:
        $this->ie3Jn = $VWeyA;
        goto LdpBh;
        LdpBh:
        $this->Fz8fG = $w9RjZ;
        goto LuC4D;
        LuC4D:
    }
    public function encode(string $wAkkA, string $aBPF6, $JgYxs = true) : void
    {
        goto ZGg4p;
        ucdCk:
        try {
            goto icCda;
            icCda:
            $hgsqV = WI5WSPGRr1b2t::findOrFail($wAkkA);
            goto NjP3a;
            Gt54x:
            return;
            goto Gns4_;
            H76j_:
            $xGZ7p = $xGZ7p->mhGucTT4xgI($Znvj8);
            goto PyuPM;
            RyIcP:
            if (!$Xl0bs) {
                goto obWHN;
            }
            goto N0HWE;
            IP9Yz:
            $JfOlX = app(KA9RxVwCbkfZQ::class);
            goto bsSDF;
            ZtxVp:
            Log::info("Set input video for Job", ['s3Uri' => $lha2I]);
            goto baCTu;
            Q3Old:
            $hgsqV->update(['aws_media_converter_job_id' => $wAkkA]);
            goto DLoSD;
            bllZa:
            Log::info("Set thumbnail for WI5WSPGRr1b2t Job", ['videoId' => $hgsqV->getAttribute('id'), 'duration' => $hgsqV->getAttribute('duration')]);
            goto Ik3_W;
            IkLAw:
            $Xl0bs = $this->mNeDR5ySPGX($JfOlX, $rfEMk->mwjfcTF32q8((int) $aKLeu['width'], (int) $aKLeu['height'], $aBPF6));
            goto pvmlR;
            uPRvm:
            $xGZ7p->mOsOwAHtATa($EMafP->mj5X8Ukvo2M($hgsqV));
            goto CQgzY;
            zt1Fd:
            obWHN:
            goto jiVvN;
            CQgzY:
            if (!($yRrbE && $aQb9L)) {
                goto Ux8O0;
            }
            goto Ll5VE;
            BV9Wj:
            $lha2I = $this->miV8ZAF05zy($hgsqV);
            goto ZtxVp;
            FzVHF:
            $xGZ7p = $xGZ7p->mxx8qJ8mmoD($NHlhh);
            goto eL56Z;
            if1xi:
            TNrQH:
            goto tHlcx;
            M5Ezl:
            Log::info("Set 1080p resolution for Job", ['width' => $aKLeu['width'], 'height' => $aKLeu['height'], 'originalWidth' => $yRrbE, 'originalHeight' => $aQb9L]);
            goto JGG9G;
            JGG9G:
            $Znvj8 = new PKHDooQHU3M1o('1080p', $aKLeu['width'], $aKLeu['height'], $hgsqV->Eiyi9 ?? 30);
            goto IkLAw;
            tHlcx:
            if (!$hgsqV->getAttribute('aws_media_converter_job_id')) {
                goto GcNP6;
            }
            goto o3qYC;
            jiVvN:
            $xGZ7p->mhGucTT4xgI($enolk);
            goto uPRvm;
            sbqvS:
            Ux8O0:
            goto bllZa;
            KIJv5:
            $yRrbE = $hgsqV->width();
            goto zI5r1;
            cdGgQ:
            CToZp:
            goto H76j_;
            C2Puw:
            $EMafP = app(Q0BHItA6POhGn::class);
            goto hPnVb;
            bsSDF:
            $rfEMk = new LiCaZN7AKYxeE($this->ie3Jn, $this->Fz8fG, $this->VJN91, $this->FHcNr);
            goto AEvrZ;
            o3qYC:
            Log::info("WI5WSPGRr1b2t already has Media Converter Job ID, skip encoding", ['fileId' => $wAkkA, 'jobId' => $hgsqV->getAttribute('aws_media_converter_job_id')]);
            goto Gt54x;
            N3hsk:
            $aKLeu = $this->msCTanrYOk2($yRrbE, $aQb9L);
            goto M5Ezl;
            CE23m:
            $xGZ7p = $xGZ7p->mR7DlxFfzVl(new Rfh6lYKf1Vsjf($lha2I));
            goto vo5qq;
            Ik3_W:
            $NHlhh = new B0X93rEANSGOM($hgsqV->getAttribute('duration') ?? 1, 2, $EMafP->mv4HcxeNz7O($hgsqV));
            goto FzVHF;
            uTepR:
            throw new MediaConverterException("WI5WSPGRr1b2t {$hgsqV->id} is not S3 driver value = {$hgsqV->driver}");
            goto if1xi;
            Gns4_:
            GcNP6:
            goto KIJv5;
            vo5qq:
            $enolk = new PKHDooQHU3M1o('original', $yRrbE, $aQb9L, $hgsqV->Eiyi9 ?? 30);
            goto C2Puw;
            N0HWE:
            $enolk = $enolk->m9aio19t0Wx($Xl0bs);
            goto zt1Fd;
            AEvrZ:
            $Xl0bs = $this->mNeDR5ySPGX($JfOlX, $rfEMk->mwjfcTF32q8($hgsqV->width(), $hgsqV->height(), $aBPF6));
            goto RyIcP;
            eL56Z:
            $wAkkA = $xGZ7p->mJz8iIrLVJ5($this->mEkH2WhZk0D($hgsqV, $JgYxs));
            goto Q3Old;
            hPnVb:
            $xGZ7p->mOsOwAHtATa($EMafP->mj5X8Ukvo2M($hgsqV));
            goto IP9Yz;
            pvmlR:
            if (!$Xl0bs) {
                goto CToZp;
            }
            goto qRKU6;
            zI5r1:
            $aQb9L = $hgsqV->height();
            goto BV9Wj;
            eXhK9:
            if (!($hgsqV->driver != Pj539Ru5gyMbt::S3)) {
                goto TNrQH;
            }
            goto uTepR;
            Ll5VE:
            if (!$this->mTUgnDKNfnq($yRrbE, $aQb9L)) {
                goto p7Hfb;
            }
            goto N3hsk;
            qRKU6:
            $Znvj8 = $Znvj8->m9aio19t0Wx($Xl0bs);
            goto cdGgQ;
            baCTu:
            $xGZ7p = app(KrL5TSTQDAqUK::class);
            goto CE23m;
            PyuPM:
            p7Hfb:
            goto sbqvS;
            NjP3a:
            Assert::isInstanceOf($hgsqV, WI5WSPGRr1b2t::class);
            goto eXhK9;
            DLoSD:
        } catch (\Exception $X2LoG) {
            goto o0CD4;
            o0CD4:
            Log::warning("WI5WSPGRr1b2t has been deleted, discard it", ['fileId' => $wAkkA, 'err' => $X2LoG->getMessage()]);
            goto BTREZ;
            BTREZ:
            Sentry::captureException($X2LoG);
            goto ai7EM;
            ai7EM:
            return;
            goto GezZp;
            GezZp:
        }
        goto sSL1d;
        qivvx:
        ini_set('memory_limit', '-1');
        goto ucdCk;
        ZGg4p:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $wAkkA]);
        goto qivvx;
        sSL1d:
    }
    private function mEkH2WhZk0D(WI5WSPGRr1b2t $hgsqV, $JgYxs) : bool
    {
        goto xGHPS;
        BvX5R:
        ah_bk:
        goto B3quu;
        YY3sW:
        I3Fb4:
        goto BvX5R;
        xGHPS:
        if ($JgYxs) {
            goto CBlzE;
        }
        goto T9Qp2;
        Wnt_O:
        $rRWy1 = (int) round($hgsqV->getAttribute('duration') ?? 0);
        goto sND_y;
        T9Qp2:
        return false;
        goto JOFcU;
        sND_y:
        switch (true) {
            case $hgsqV->width() * $hgsqV->height() >= 1920 * 1080 && $hgsqV->width() * $hgsqV->height() < 2560 * 1440:
                return $rRWy1 > 30 * 60;
            case $hgsqV->width() * $hgsqV->height() >= 2560 * 1440 && $hgsqV->width() * $hgsqV->height() < 3840 * 2160:
                return $rRWy1 > 15 * 60;
            case $hgsqV->width() * $hgsqV->height() >= 3840 * 2160:
                return $rRWy1 > 10 * 60;
            default:
                return false;
        }
        goto YY3sW;
        JOFcU:
        CBlzE:
        goto Wnt_O;
        B3quu:
    }
    private function mNeDR5ySPGX(KA9RxVwCbkfZQ $JfOlX, string $uG0yw) : ?Zp6bjD8AQnl45
    {
        goto ai4Qo;
        IzJrt:
        QlUkW:
        goto dSIoz;
        dSIoz:
        return null;
        goto MMr9R;
        ai4Qo:
        $UQIfX = $JfOlX->m7A6Q5K6mHg($uG0yw);
        goto zmVGf;
        Vlz2p:
        if (!$UQIfX) {
            goto QlUkW;
        }
        goto nNhhd;
        zmVGf:
        Log::info("Resolve watermark for job with url", ['url' => $uG0yw, 'uri' => $UQIfX]);
        goto Vlz2p;
        nNhhd:
        return new Zp6bjD8AQnl45($UQIfX, 0, 0, null, null);
        goto IzJrt;
        MMr9R:
    }
    private function mTUgnDKNfnq(int $yRrbE, int $aQb9L) : bool
    {
        return $yRrbE * $aQb9L > 1.5 * (1920 * 1080);
    }
    private function msCTanrYOk2(int $yRrbE, int $aQb9L) : array
    {
        $BwZi1 = new HOtxsT8ZNbu6T($yRrbE, $aQb9L);
        return $BwZi1->m6L44Vkx35Q();
    }
    private function miV8ZAF05zy(NCmZ7rMVMWyvC $ldT2t) : string
    {
        goto aGq9O;
        JVQBL:
        return $this->FHcNr->url($ldT2t->filename);
        goto SMo9o;
        xzM3p:
        pZ67E:
        goto JVQBL;
        eo2mP:
        return 's3://' . $this->n4bxV . '/' . $ldT2t->filename;
        goto xzM3p;
        aGq9O:
        if (!($ldT2t->driver == Pj539Ru5gyMbt::S3)) {
            goto pZ67E;
        }
        goto eo2mP;
        SMo9o:
    }
}
