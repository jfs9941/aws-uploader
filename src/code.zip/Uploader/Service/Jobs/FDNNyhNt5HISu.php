<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
class FDNNyhNt5HISu implements CompressJobInterface
{
    const cHVIU = 80;
    private $TMqxn;
    private $foEoP;
    public function __construct($xskW6, $VGndK)
    {
        $this->TMqxn = $xskW6;
        $this->foEoP = $VGndK;
    }
    public function compress(string $R7IrL)
    {
        Log::info("Compress image", ['imageId' => $R7IrL]);
        try {
            goto DqiGY;
            OPl0G:
            $bQfZL->orientate();
            goto P21hm;
            I8pU0:
            if (!($Xxl6q->getExtension() === 'png')) {
                goto qgwOK;
            }
            goto Ni2ep;
            P21hm:
            $bQfZL->save($oFhW6, self::cHVIU);
            goto L3pMO;
            DqiGY:
            $Xxl6q = OcbNsXl9lpteB::findOrFail($R7IrL);
            goto Is3oN;
            kZ_kr:
            $oFhW6 = $this->foEoP->path($Xxl6q->getLocation());
            goto jVs4M;
            jVs4M:
            $bQfZL = $this->TMqxn->call($this, $dBLOV);
            goto OPl0G;
            L3pMO:
            $bQfZL->destroy();
            goto eONWs;
            Ni2ep:
            $Xxl6q->setAttribute('type', 'jpg');
            goto t14PL;
            owY6N:
            qgwOK:
            goto kZ_kr;
            Is3oN:
            $dBLOV = $this->foEoP->path($Xxl6q->getLocation());
            goto I8pU0;
            t14PL:
            $Xxl6q->setAttribute('filename', str_replace('.png', '.jpg', $Xxl6q->getLocation()));
            goto kZF9_;
            kZF9_:
            $Xxl6q->save();
            goto owY6N;
            eONWs:
        } catch (ModelNotFoundException) {
            Log::info("OcbNsXl9lpteB has been deleted, discard it", ['imageId' => $R7IrL]);
        }
    }
}
