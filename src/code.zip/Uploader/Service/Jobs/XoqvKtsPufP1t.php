<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface; use Jfs\Exposed\VideoPostHandleServiceInterface; use Illuminate\Support\Facades\Log; class XoqvKtsPufP1t implements GenerateThumbnailForVideoInterface { private $tD3jE; public function __construct($aa7e3) { $this->tD3jE = $aa7e3; } public function generate(string $hJXEE) : void { Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $hJXEE); $this->tD3jE->createThumbnail($hJXEE); } }
