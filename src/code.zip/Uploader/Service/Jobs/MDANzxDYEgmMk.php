<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
class MDANzxDYEgmMk implements GenerateThumbnailJobInterface
{
    const tqPMm = 150;
    const NMW3N = 150;
    private $TMqxn;
    private $foEoP;
    public function __construct($xskW6, $VGndK)
    {
        $this->TMqxn = $xskW6;
        $this->foEoP = $VGndK;
    }
    public function generate(string $R7IrL)
    {
        goto pvNvR;
        jLGqS:
        ini_set('memory_limit', '-1');
        goto cRckp;
        cRckp:
        try {
            goto xCtzj;
            y_9oW:
            $QwynI->encode('jpg', 80);
            goto YPjBp;
            rocIV:
            $QwynI->destroy();
            goto nfGgj;
            syomU:
            $oX1hR = $Q0D24->put($XkdbN, $QwynI->stream(), ['visibility' => 'public']);
            goto rocIV;
            s5V4U:
            G1yfT:
            goto tyyK_;
            Sqqd6:
            throw new \Exception('Failed to set file permissions for stored image: ' . $mGwgR);
            goto AgsMw;
            lCKd_:
            $mGwgR = $Q0D24->path($XkdbN);
            goto QvvJJ;
            x5OeG:
            $Xxl6q = OcbNsXl9lpteB::findOrFail($R7IrL);
            goto rvNpW;
            On7pC:
            $QwynI->fit(150, 150, function ($o6v3F) {
                $o6v3F->aspectRatio();
            });
            goto y_9oW;
            nfGgj:
            if (!($oX1hR !== false)) {
                goto G1yfT;
            }
            goto Ea568;
            QvvJJ:
            if (chmod($mGwgR, 0644)) {
                goto PVFl4;
            }
            goto ks0Xj;
            rvNpW:
            $QwynI = $this->TMqxn->call($this, $Q0D24->path($Xxl6q->getLocation()));
            goto On7pC;
            YPjBp:
            $XkdbN = $this->mn5o9IOn4V0($Xxl6q);
            goto syomU;
            Ea568:
            $Xxl6q->update(['thumbnail' => $XkdbN, 'status' => QUh2VVA2TE5xx::THUMBNAIL_PROCESSED]);
            goto lCKd_;
            ks0Xj:
            Log::warning('Failed to set file permissions for stored image: ' . $mGwgR);
            goto Sqqd6;
            xCtzj:
            $Q0D24 = $this->foEoP;
            goto x5OeG;
            AgsMw:
            PVFl4:
            goto s5V4U;
            tyyK_:
        } catch (ModelNotFoundException $jrXe_) {
            Log::info("OcbNsXl9lpteB has been deleted, discard it", ['imageId' => $R7IrL]);
            return;
        }
        goto pE2V8;
        pvNvR:
        Log::info("Generating thumbnail", ['imageId' => $R7IrL]);
        goto jLGqS;
        pE2V8:
    }
    private function mn5o9IOn4V0(QfVdOZWAlX8Sl $Xxl6q) : string
    {
        goto ZkA5K;
        nv67U:
        $gdRmc = dirname($XkdbN);
        goto ToLqV;
        Ft6Vi:
        return $dcU37 . '/' . $Xxl6q->getFilename() . '.jpg';
        goto ieQtq;
        ToLqV:
        $dcU37 = $gdRmc . '/' . self::tqPMm . 'X' . self::NMW3N;
        goto Ft6Vi;
        ZkA5K:
        $XkdbN = $Xxl6q->getLocation();
        goto nv67U;
        ieQtq:
    }
}
