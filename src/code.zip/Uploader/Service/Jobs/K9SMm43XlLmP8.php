<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use InvalidArgumentException;
class K9SMm43XlLmP8
{
    private $PRKfe;
    private $NIUfn;
    public function __construct(int $T1I17, int $IyJx2)
    {
        goto W0Chz;
        pI0c6:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto VFPUl;
        y3xyJ:
        if (!($IyJx2 <= 0)) {
            goto YQCnN;
        }
        goto OKOAY;
        vxHVO:
        $this->NIUfn = $IyJx2;
        goto d6pbY;
        vWZ6x:
        $this->PRKfe = $T1I17;
        goto vxHVO;
        VFPUl:
        ZXDr1:
        goto y3xyJ;
        P_hm3:
        YQCnN:
        goto vWZ6x;
        OKOAY:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto P_hm3;
        W0Chz:
        if (!($T1I17 <= 0)) {
            goto ZXDr1;
        }
        goto pI0c6;
        d6pbY:
    }
    private static function myd50e5pRnF($GiaYH, string $jxkNr = 'floor') : int
    {
        goto mZ1Lh;
        RE8qv:
        VRg1y:
        goto P9fWw;
        aSG1U:
        U1uvy:
        goto RE8qv;
        CYtGW:
        lBo8o:
        goto ZEJI_;
        GXs26:
        return $GiaYH;
        goto CYtGW;
        LPAwM:
        return (int) $GiaYH;
        goto vSvlb;
        ZEJI_:
        if (!(is_float($GiaYH) && $GiaYH == floor($GiaYH) && (int) $GiaYH % 2 === 0)) {
            goto qkRwe;
        }
        goto LPAwM;
        QoejJ:
        switch (strtolower($jxkNr)) {
            case 'ceil':
                return (int) (ceil($GiaYH / 2) * 2);
            case 'round':
                return (int) (round($GiaYH / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($GiaYH / 2) * 2);
        }
        goto aSG1U;
        vSvlb:
        qkRwe:
        goto QoejJ;
        mZ1Lh:
        if (!(is_int($GiaYH) && $GiaYH % 2 === 0)) {
            goto lBo8o;
        }
        goto GXs26;
        P9fWw:
    }
    public function mWhdXrMgyzn(string $KXfU9 = 'floor') : array
    {
        goto CLo1s;
        QA8Mi:
        $P7qLY = $this->PRKfe * $zKKi4;
        goto MgaNf;
        NzWII:
        $VQAoT = $MMij3;
        goto rvmo9;
        weh90:
        $FwunU = 2;
        goto YV9Ql;
        o4cPA:
        GvKWf:
        goto RUjz1;
        rvmo9:
        $zKKi4 = $VQAoT / $this->PRKfe;
        goto TwNwz;
        TwNwz:
        $LLjGL = $this->NIUfn * $zKKi4;
        goto v433F;
        v433F:
        $FwunU = self::myd50e5pRnF(round($LLjGL), $KXfU9);
        goto x9CLJ;
        YV9Ql:
        yq7GH:
        goto krS_T;
        RUjz1:
        if (!($FwunU < 2)) {
            goto yq7GH;
        }
        goto weh90;
        g6Tvu:
        $zKKi4 = $FwunU / $this->NIUfn;
        goto QA8Mi;
        HsQwH:
        $FwunU = 0;
        goto QNI8f;
        krS_T:
        return ['width' => $VQAoT, 'height' => $FwunU];
        goto kdWF0;
        Q87zl:
        $VQAoT = 2;
        goto o4cPA;
        X1T4o:
        $VQAoT = 0;
        goto HsQwH;
        qtW8M:
        if (!($VQAoT < 2)) {
            goto GvKWf;
        }
        goto Q87zl;
        CLo1s:
        $MMij3 = 1080;
        goto X1T4o;
        Afkqy:
        $FwunU = $MMij3;
        goto g6Tvu;
        Wu_EI:
        cR4lw:
        goto Afkqy;
        QNI8f:
        if ($this->PRKfe >= $this->NIUfn) {
            goto cR4lw;
        }
        goto NzWII;
        ACgZg:
        vlYce:
        goto qtW8M;
        MgaNf:
        $VQAoT = self::myd50e5pRnF(round($P7qLY), $KXfU9);
        goto ACgZg;
        x9CLJ:
        goto vlYce;
        goto Wu_EI;
        kdWF0:
    }
}
