<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Illuminate\Support\Facades\Log;
class UKVXmWnxnT4qp implements StoreVideoToS3JobInterface
{
    private $RwR9R;
    private $bLZP5;
    private $qeI_k;
    public function __construct($r087v, $C1By6, $ShtWH)
    {
        goto zrES8;
        EAAOx:
        $this->RwR9R = $r087v;
        goto ZYKnW;
        zrES8:
        $this->bLZP5 = $C1By6;
        goto cqVQw;
        cqVQw:
        $this->qeI_k = $ShtWH;
        goto EAAOx;
        ZYKnW:
    }
    public function store(string $DWjir) : void
    {
        goto mBbWM;
        dRGwL:
        $fSCPa = $ShtWH->mimeType($HkC3o->getLocation());
        goto Tpaqn;
        PWvYX:
        $eRyKR = memory_get_usage();
        goto ELCMD;
        LziOd:
        return;
        goto EI9g3;
        O8D2n:
        $ShtWH = $this->qeI_k;
        goto AbhD9;
        HpglE:
        try {
            goto G3XVG;
            E8vFp:
            $PoqoM[] = ['PartNumber' => $sBk8u, 'ETag' => $tNOZP['ETag']];
            goto ZBd6w;
            zVFaw:
            $PoqoM = [];
            goto VOIZl;
            rY3v1:
            $NB12w = $U_gac['UploadId'];
            goto OiCpg;
            M9M4N:
            fclose($AaTUJ);
            goto q4VMe;
            sBRHU:
            vE1X2:
            goto M9M4N;
            VOIZl:
            jSDVQ:
            goto CSC1i;
            ZBd6w:
            $sBk8u++;
            goto DkPUM;
            G3XVG:
            $U_gac = $w_9Ju->createMultipartUpload(['Bucket' => $this->RwR9R, 'Key' => $HkC3o->getLocation(), 'ContentType' => $fSCPa, 'ContentDisposition' => 'inline']);
            goto rY3v1;
            OiCpg:
            $sBk8u = 1;
            goto zVFaw;
            DkPUM:
            goto jSDVQ;
            goto sBRHU;
            CSC1i:
            if (feof($AaTUJ)) {
                goto vE1X2;
            }
            goto kZtqc;
            kZtqc:
            $tNOZP = $w_9Ju->uploadPart(['Bucket' => $this->RwR9R, 'Key' => $HkC3o->getLocation(), 'UploadId' => $NB12w, 'PartNumber' => $sBk8u, 'Body' => fread($AaTUJ, $EiBY9)]);
            goto E8vFp;
            i6dhN:
            $ShtWH->delete($HkC3o->getLocation());
            goto OBDnO;
            q4VMe:
            $w_9Ju->completeMultipartUpload(['Bucket' => $this->RwR9R, 'Key' => $HkC3o->getLocation(), 'UploadId' => $NB12w, 'MultipartUpload' => ['Parts' => $PoqoM]]);
            goto vfnqQ;
            vfnqQ:
            $HkC3o->update(['driver' => KkaUVP3OQvOtp::S3, 'status' => H7dtWZ2h5WAty::FINISHED]);
            goto i6dhN;
            OBDnO:
        } catch (AwsException $dMDxf) {
            goto U2SRN;
            SZNmN:
            RWhyM:
            goto Sj82I;
            Sj82I:
            Log::error('Failed to store video: ' . $HkC3o->getLocation() . ' - ' . $dMDxf->getMessage());
            goto uqbN1;
            tODNK:
            try {
                $w_9Ju->abortMultipartUpload(['Bucket' => $this->RwR9R, 'Key' => $HkC3o->getLocation(), 'UploadId' => $NB12w]);
            } catch (AwsException $bbhaX) {
                Log::error('Error aborting multipart upload: ' . $bbhaX->getMessage());
            }
            goto SZNmN;
            U2SRN:
            if (!isset($NB12w)) {
                goto RWhyM;
            }
            goto tODNK;
            uqbN1:
        } finally {
            $SoVKt = microtime(true);
            $aV3nd = memory_get_usage();
            $PoneH = memory_get_peak_usage();
            Log::info('Store J7sRaWo8um3yO to S3 function resource usage', ['imageId' => $DWjir, 'execution_time_sec' => $SoVKt - $oDOT6, 'memory_usage_mb' => ($aV3nd - $eRyKR) / 1024 / 1024, 'peak_memory_usage_mb' => ($PoneH - $nmnvM) / 1024 / 1024]);
        }
        goto zVP_h;
        mBbWM:
        Log::info('Storing video (local) to S3', ['fileId' => $DWjir, 'bucketName' => $this->RwR9R]);
        goto bQuzm;
        ELCMD:
        $nmnvM = memory_get_peak_usage();
        goto HpglE;
        sa31M:
        if ($HkC3o) {
            goto KTlAM;
        }
        goto yfEO4;
        vp6pi:
        return;
        goto XVvah;
        cEQMw:
        $w_9Ju = $this->bLZP5->getClient();
        goto O8D2n;
        AbhD9:
        $HkC3o = J7sRaWo8um3yO::find($DWjir);
        goto sa31M;
        EI9g3:
        GxF0O:
        goto bnmCs;
        bnmCs:
        $AaTUJ = $ShtWH->readStream($HkC3o->getLocation());
        goto VnxES;
        cY5mH:
        Log::error("[UKVXmWnxnT4qp] File not found, discard it ", ['video' => $HkC3o->getLocation()]);
        goto LziOd;
        dlcLc:
        if ($ShtWH->exists($HkC3o->getLocation())) {
            goto GxF0O;
        }
        goto cY5mH;
        Tpaqn:
        $oDOT6 = microtime(true);
        goto PWvYX;
        XVvah:
        KTlAM:
        goto dlcLc;
        VnxES:
        $EiBY9 = 1024 * 1024 * 50;
        goto dRGwL;
        yfEO4:
        Log::info("J7sRaWo8um3yO has been deleted, discard it", ['fileId' => $DWjir]);
        goto vp6pi;
        bQuzm:
        ini_set('memory_limit', '-1');
        goto cEQMw;
        zVP_h:
    }
}
