<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class QXJUwRt07aAu0
{
    private $eABgx;
    private $D1BPj;
    public function __construct(int $HwkeQ, int $dOI0A)
    {
        goto bYio9;
        G2RIC:
        $this->eABgx = $HwkeQ;
        goto EsMTU;
        XNUUS:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto NEjlL;
        sohDD:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto qi5q7;
        NEjlL:
        apFEy:
        goto G2RIC;
        bYio9:
        if (!($HwkeQ <= 0)) {
            goto wBJhM;
        }
        goto sohDD;
        ykqUM:
        if (!($dOI0A <= 0)) {
            goto apFEy;
        }
        goto XNUUS;
        EsMTU:
        $this->D1BPj = $dOI0A;
        goto R5hQr;
        qi5q7:
        wBJhM:
        goto ykqUM;
        R5hQr:
    }
    private static function mipXmcKOMhN($bHqI3, string $tk1Ly = 'floor') : int
    {
        goto Z0yGt;
        Z0yGt:
        if (!(is_int($bHqI3) && $bHqI3 % 2 === 0)) {
            goto fdAp1;
        }
        goto xfPEr;
        xfPEr:
        return $bHqI3;
        goto CtQ68;
        XHpSX:
        if (!(is_float($bHqI3) && $bHqI3 == floor($bHqI3) && (int) $bHqI3 % 2 === 0)) {
            goto M5ecI;
        }
        goto P1ugC;
        F1tSD:
        switch (strtolower($tk1Ly)) {
            case 'ceil':
                return (int) (ceil($bHqI3 / 2) * 2);
            case 'round':
                return (int) (round($bHqI3 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($bHqI3 / 2) * 2);
        }
        goto VN2PF;
        HGm8K:
        M5ecI:
        goto F1tSD;
        P1ugC:
        return (int) $bHqI3;
        goto HGm8K;
        CtQ68:
        fdAp1:
        goto XHpSX;
        eKEVD:
        sHnAl:
        goto ueBUk;
        VN2PF:
        yxSqz:
        goto eKEVD;
        ueBUk:
    }
    public function mFKsUsu1E6S(string $AjAYn = 'floor') : array
    {
        goto CFPDN;
        XIM71:
        $KUZjE = 0;
        goto BS3qQ;
        Zm11s:
        goto BaxWT;
        goto JENdE;
        B42oD:
        BaxWT:
        goto U8itJ;
        V4oYp:
        $KUZjE = $kUWQG;
        goto oYkjf;
        BBABb:
        if (!($KUZjE < 2)) {
            goto tLbnH;
        }
        goto UGYa2;
        BS3qQ:
        if ($this->eABgx >= $this->D1BPj) {
            goto GcLQr;
        }
        goto qT7TZ;
        CFPDN:
        $kUWQG = 1080;
        goto lKJif;
        mpXdO:
        $sMQVq = $this->eABgx * $ThiXW;
        goto vNp4z;
        oYkjf:
        $ThiXW = $KUZjE / $this->D1BPj;
        goto mpXdO;
        twcca:
        pFVDD:
        goto BBABb;
        wNknC:
        return ['width' => $JPpx8, 'height' => $KUZjE];
        goto Dt8C1;
        nQXY9:
        tLbnH:
        goto wNknC;
        vNp4z:
        $JPpx8 = self::mipXmcKOMhN(round($sMQVq), $AjAYn);
        goto B42oD;
        U8itJ:
        if (!($JPpx8 < 2)) {
            goto pFVDD;
        }
        goto hVrD1;
        JENdE:
        GcLQr:
        goto V4oYp;
        hVrD1:
        $JPpx8 = 2;
        goto twcca;
        UGYa2:
        $KUZjE = 2;
        goto nQXY9;
        tjAm7:
        $OO1je = $this->D1BPj * $ThiXW;
        goto ctdvm;
        qT7TZ:
        $JPpx8 = $kUWQG;
        goto HJaMU;
        lKJif:
        $JPpx8 = 0;
        goto XIM71;
        HJaMU:
        $ThiXW = $JPpx8 / $this->eABgx;
        goto tjAm7;
        ctdvm:
        $KUZjE = self::mipXmcKOMhN(round($OO1je), $AjAYn);
        goto Zm11s;
        Dt8C1:
    }
}
