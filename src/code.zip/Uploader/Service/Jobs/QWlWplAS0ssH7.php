<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
class QWlWplAS0ssH7 implements GenerateThumbnailJobInterface
{
    const g9ySt = 150;
    const o6MO3 = 150;
    private $K9RVo;
    private $ERIyl;
    public function __construct($Venjl, $nL6dR)
    {
        $this->K9RVo = $Venjl;
        $this->ERIyl = $nL6dR;
    }
    public function generate(string $ElvKF)
    {
        goto cmTea;
        cmTea:
        Log::info("Generating thumbnail", ['imageId' => $ElvKF]);
        goto ovrog;
        ovrog:
        ini_set('memory_limit', '-1');
        goto oKZ1T;
        oKZ1T:
        try {
            goto NnB1W;
            P5v1j:
            $anrPh->update(['thumbnail' => $lmCO9, 'status' => Q5pXt73hTeTVP::THUMBNAIL_PROCESSED]);
            goto CFuuF;
            pnPwX:
            $lmCO9 = $this->mvnXtFBjtmf($anrPh);
            goto lLVr8;
            lLVr8:
            $jiMZA = $nsgrL->put($lmCO9, $VW3R9->stream(), ['visibility' => 'public']);
            goto HNdN4;
            i3GVI:
            $VW3R9->encode('jpg', 80);
            goto pnPwX;
            NnB1W:
            $nsgrL = $this->ERIyl;
            goto jm1pH;
            kG_6D:
            Log::warning('Failed to set file permissions for stored image: ' . $h1aZp);
            goto vm1kD;
            CFuuF:
            $h1aZp = $nsgrL->path($lmCO9);
            goto SFgLF;
            zfKjQ:
            NMo6H:
            goto zs3vX;
            a5W3k:
            if (!($jiMZA !== false)) {
                goto NMo6H;
            }
            goto P5v1j;
            x7xAN:
            vWQCb:
            goto zfKjQ;
            HNdN4:
            $VW3R9->destroy();
            goto a5W3k;
            vm1kD:
            throw new \Exception('Failed to set file permissions for stored image: ' . $h1aZp);
            goto x7xAN;
            SFgLF:
            if (chmod($h1aZp, 0644)) {
                goto vWQCb;
            }
            goto kG_6D;
            Z__Jn:
            $VW3R9 = $this->K9RVo->call($this, $nsgrL->path($anrPh->getLocation()));
            goto RZiXr;
            RZiXr:
            $VW3R9->fit(150, 150, function ($XtPgo) {
                $XtPgo->aspectRatio();
            });
            goto i3GVI;
            jm1pH:
            $anrPh = WKX0l52zWptlF::findOrFail($ElvKF);
            goto Z__Jn;
            zs3vX:
        } catch (ModelNotFoundException $vGb1d) {
            Log::info("WKX0l52zWptlF has been deleted, discard it", ['imageId' => $ElvKF]);
            return;
        }
        goto Qhkgz;
        Qhkgz:
    }
    private function mvnXtFBjtmf(MXbLxov2QPqm4 $anrPh) : string
    {
        goto m091j;
        g_Q4Z:
        $rccNk = dirname($lmCO9);
        goto ZoVsN;
        ZoVsN:
        $twmu4 = $rccNk . '/' . self::g9ySt . 'X' . self::o6MO3;
        goto mdT2r;
        m091j:
        $lmCO9 = $anrPh->getLocation();
        goto g_Q4Z;
        mdT2r:
        return $twmu4 . '/' . $anrPh->getFilename() . '.jpg';
        goto GLRmQ;
        GLRmQ:
    }
}
