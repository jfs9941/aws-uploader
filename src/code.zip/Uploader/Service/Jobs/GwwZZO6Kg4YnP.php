<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
class GwwZZO6Kg4YnP implements DownloadToLocalJobInterface
{
    private $gGE8I;
    private $xbA_A;
    public function __construct($duBfR, $a_5ue)
    {
        $this->gGE8I = $duBfR;
        $this->xbA_A = $a_5ue;
    }
    public function download(string $ld8Ad) : void
    {
        goto G6t9Y;
        VJEim:
        if (!$this->xbA_A->exists($PQjbH->getLocation())) {
            goto v04qH;
        }
        goto o2GTg;
        awhST:
        $this->xbA_A->put($PQjbH->getLocation(), $this->gGE8I->get($PQjbH->getLocation()));
        goto wcceQ;
        nqP2W:
        Log::info("Start download file to local", ['fileId' => $ld8Ad, 'filename' => $PQjbH->getLocation()]);
        goto VJEim;
        HJFD4:
        v04qH:
        goto awhST;
        G6t9Y:
        $PQjbH = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
        goto nqP2W;
        o2GTg:
        return;
        goto HJFD4;
        wcceQ:
    }
}
