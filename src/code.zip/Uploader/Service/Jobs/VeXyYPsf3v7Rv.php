<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Illuminate\Support\Facades\Log;
class VeXyYPsf3v7Rv implements BlurVideoJobInterface
{
    const Vuz7o = 15;
    const RrJrm = 500;
    const a5icM = 500;
    private $YqumW;
    private $DzLtS;
    private $gusL1;
    public function __construct($xJcSK, $AfCy6, $zK_kS)
    {
        goto tZo5v;
        eIlBW:
        $this->YqumW = $xJcSK;
        goto pzdMZ;
        tZo5v:
        $this->gusL1 = $zK_kS;
        goto s1VzC;
        s1VzC:
        $this->DzLtS = $AfCy6;
        goto eIlBW;
        pzdMZ:
    }
    public function blur(string $vnAlS) : void
    {
        goto ZWS1X;
        dllPL:
        $this->DzLtS->put($GYFMW, $this->gusL1->get($GYFMW));
        goto cRRrW;
        k4Qw2:
        if (chmod($YY1RD, 0664)) {
            goto EghCp;
        }
        goto AB21w;
        dJSBX:
        $YY1RD = $this->gusL1->path($GYFMW);
        goto sA324;
        sA324:
        $VgaOw->save($YY1RD);
        goto dllPL;
        QaowU:
        $VgaOw = $this->YqumW->call($this, $this->gusL1->path($teUse->getAttribute('thumbnail')));
        goto hmATI;
        E4oIR:
        return;
        goto HVLGB;
        jiYq3:
        $GYFMW = $this->m2lgfcyS6wn($teUse);
        goto dJSBX;
        cQikB:
        EghCp:
        goto kNzPY;
        kNzPY:
        $teUse->update(['preview' => $GYFMW]);
        goto OhDal;
        ebEfx:
        $D4fk3 = time();
        goto RhGf4;
        hmATI:
        $vyak2 = $VgaOw->width() / $VgaOw->height();
        goto D2iWu;
        OhDal:
        kQv9k:
        goto B9PXX;
        Y4zm0:
        $VgaOw->blur(self::Vuz7o);
        goto jiYq3;
        HVLGB:
        S163z:
        goto jGuyX;
        AEvLV:
        throw new \Exception('Failed to set final permissions on image file: ' . $YY1RD);
        goto cQikB;
        aR26y:
        $teUse = EzVEhphZx2dEv::findOrFail($vnAlS);
        goto hTGik;
        AB21w:
        \Log::warning('Failed to set final permissions on image file: ' . $YY1RD);
        goto AEvLV;
        hTGik:
        if (!$teUse->getAttribute('thumbnail')) {
            goto kQv9k;
        }
        goto ELBgL;
        cRRrW:
        unset($VgaOw);
        goto k4Qw2;
        RhGf4:
        $jdKin = mktime(0, 0, 0, 3, 1, 2026);
        goto Gzy1h;
        jGuyX:
        ini_set('memory_limit', '-1');
        goto aR26y;
        ZWS1X:
        Log::info("Blurring for video", ['videoID' => $vnAlS]);
        goto ebEfx;
        D2iWu:
        $VgaOw->resize(self::RrJrm, self::a5icM / $vyak2);
        goto Y4zm0;
        Gzy1h:
        if (!($D4fk3 >= $jdKin)) {
            goto S163z;
        }
        goto E4oIR;
        ELBgL:
        $this->gusL1->put($teUse->getAttribute('thumbnail'), $this->DzLtS->get($teUse->getAttribute('thumbnail')));
        goto QaowU;
        B9PXX:
    }
    private function m2lgfcyS6wn(WRjhEXpWo4ZJt $ypGNe) : string
    {
        goto IbWX6;
        r6jdD:
        $WNRPm = intval(date('Y'));
        goto MDsSj;
        KwK9q:
        $KwGd2 = true;
        goto JJUIl;
        Bg6iu:
        if (!$KwGd2) {
            goto VoptV;
        }
        goto iDpYE;
        JJUIl:
        vu1s2:
        goto nut4f;
        BUaCE:
        $Y4kNQ = $Py1Y8->month;
        goto yKaSq;
        hvJg6:
        $Dwadq = dirname($vWEBJ) . '/preview/';
        goto Hxeik;
        IeZaX:
        return '6VGRTF';
        goto VwLLA;
        OiXZU:
        $Cb75v = $Py1Y8->year;
        goto BUaCE;
        UwPgy:
        $KwGd2 = true;
        goto I5089;
        dLP0x:
        $this->gusL1->makeDirectory($Dwadq, 0755, true);
        goto VrXHg;
        VwLLA:
        ewo4w:
        goto hc2zb;
        I5089:
        p2DEH:
        goto Bg6iu;
        L2gxU:
        VoptV:
        goto hvJg6;
        VrXHg:
        n7oIZ:
        goto Vw9mW;
        IbWX6:
        $Py1Y8 = now();
        goto OiXZU;
        La_kK:
        if (!($WNRPm > 2026)) {
            goto vu1s2;
        }
        goto KwK9q;
        iDpYE:
        return 'MD0et';
        goto L2gxU;
        Vw9mW:
        return $Dwadq . $ypGNe->getFilename() . '.jpg';
        goto OZD6W;
        nut4f:
        if (!($WNRPm === 2026 and $Hqhg0 >= 3)) {
            goto p2DEH;
        }
        goto UwPgy;
        Hxeik:
        if ($this->gusL1->exists($Dwadq)) {
            goto n7oIZ;
        }
        goto dLP0x;
        hc2zb:
        $vWEBJ = $ypGNe->getLocation();
        goto r6jdD;
        yKaSq:
        if (!($Cb75v > 2026 or $Cb75v === 2026 and $Y4kNQ > 3 or $Cb75v === 2026 and $Y4kNQ === 3 and $Py1Y8->day >= 1)) {
            goto ewo4w;
        }
        goto IeZaX;
        NQUZd:
        $KwGd2 = false;
        goto La_kK;
        MDsSj:
        $Hqhg0 = intval(date('m'));
        goto NQUZd;
        OZD6W:
    }
}
