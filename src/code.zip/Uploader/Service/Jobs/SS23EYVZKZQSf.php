<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Service\Jobs\FfdAEtVFCtHnp;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class SS23EYVZKZQSf implements WatermarkTextJobInterface
{
    private $z7YJI;
    private $i16be;
    private $xramE;
    private $PxC6l;
    private $zoOKU;
    public function __construct($fvRbj, $mBdvd, $kxhX9, $e3FbC, $NEcof)
    {
        goto tVitf;
        hXpkb:
        $this->PxC6l = $kxhX9;
        goto kD2MW;
        RacU1:
        $this->i16be = $mBdvd;
        goto omp7d;
        kD2MW:
        $this->zoOKU = $e3FbC;
        goto GQyZl;
        GQyZl:
        $this->xramE = $NEcof;
        goto RacU1;
        tVitf:
        $this->z7YJI = $fvRbj;
        goto hXpkb;
        omp7d:
    }
    public function putWatermark(string $S580N, string $tsV_X) : void
    {
        goto loRHR;
        U2IzZ:
        Log::info("Adding watermark text to image", ['imageId' => $S580N]);
        goto Rx9lP;
        Rx9lP:
        ini_set('memory_limit', '-1');
        goto gKNKH;
        loRHR:
        $nR1Wc = microtime(true);
        goto AKpUm;
        gKNKH:
        try {
            goto NOdYT;
            BBrxW:
            \Log::warning('Failed to set final permissions on image file: ' . $d1QWa);
            goto cUgaa;
            bfsY6:
            $cO2p_->orient();
            goto Tecr3;
            UoKof:
            $this->PxC6l->put($d1QWa, $cO2p_->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto acXLz;
            Tecr3:
            $this->mt38v78jWSK($cO2p_, $tsV_X);
            goto UoKof;
            UnuK5:
            if (chmod($d1QWa, 0664)) {
                goto hy6uq;
            }
            goto BBrxW;
            cUgaa:
            throw new \Exception('Failed to set final permissions on image file: ' . $d1QWa);
            goto Ajtop;
            MIFjz:
            return;
            goto K7M60;
            Ajtop:
            hy6uq:
            goto XTlbS;
            r_GLf:
            $cO2p_ = $this->z7YJI->call($this, $d1QWa);
            goto bfsY6;
            K7M60:
            gNECh:
            goto ctAqn;
            vkw3P:
            if ($this->zoOKU->exists($gNhb4->getLocation())) {
                goto gNECh;
            }
            goto VNyMj;
            VNyMj:
            Log::error("KfEJaEGpFJ0tm is not on local, might be deleted before put watermark", ['imageId' => $S580N]);
            goto MIFjz;
            acXLz:
            unset($cO2p_);
            goto UnuK5;
            NOdYT:
            $gNhb4 = KfEJaEGpFJ0tm::findOrFail($S580N);
            goto vkw3P;
            ctAqn:
            $d1QWa = $this->zoOKU->path($gNhb4->getLocation());
            goto r_GLf;
            XTlbS:
        } catch (\Throwable $YfxOS) {
            goto ldMR2;
            Dq8Ff:
            return;
            goto lBwMc;
            hcGY6:
            Log::info("KfEJaEGpFJ0tm has been deleted, discard it", ['imageId' => $S580N]);
            goto Dq8Ff;
            lBwMc:
            nn2i3:
            goto y9Zkb;
            ldMR2:
            if (!$YfxOS instanceof ModelNotFoundException) {
                goto nn2i3;
            }
            goto hcGY6;
            y9Zkb:
            Log::error("KfEJaEGpFJ0tm is not readable", ['imageId' => $S580N, 'error' => $YfxOS->getMessage()]);
            goto AKOjK;
            AKOjK:
        } finally {
            $EX_rn = microtime(true);
            $r_Z2H = memory_get_usage();
            $I57ia = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $S580N, 'execution_time_sec' => $EX_rn - $nR1Wc, 'memory_usage_mb' => ($r_Z2H - $xM3o2) / 1024 / 1024, 'peak_memory_usage_mb' => ($I57ia - $JYKfw) / 1024 / 1024]);
        }
        goto NDcTQ;
        AKpUm:
        $xM3o2 = memory_get_usage();
        goto uUZCT;
        uUZCT:
        $JYKfw = memory_get_peak_usage();
        goto U2IzZ;
        NDcTQ:
    }
    private function mt38v78jWSK($cO2p_, $tsV_X) : void
    {
        goto wHzhZ;
        IrUxa:
        $this->zoOKU->put($aQWhQ, $this->PxC6l->get($aQWhQ));
        goto p9ivN;
        wHzhZ:
        $Sv6q3 = $cO2p_->width();
        goto kOFlY;
        GBO3z:
        $aQWhQ = $I3tEC->mIeA78uqetR($Sv6q3, $G9pt9, $tsV_X, true);
        goto IrUxa;
        C4Fsv:
        $I3tEC = new FfdAEtVFCtHnp($this->i16be, $this->xramE, $this->PxC6l, $this->zoOKU);
        goto GBO3z;
        p9ivN:
        $a74x8 = $this->z7YJI->call($this, $this->zoOKU->path($aQWhQ));
        goto sFcvZ;
        sFcvZ:
        $cO2p_->place($a74x8, 'top-left', 0, 0, 30);
        goto dP9uV;
        kOFlY:
        $G9pt9 = $cO2p_->height();
        goto C4Fsv;
        dP9uV:
    }
}
