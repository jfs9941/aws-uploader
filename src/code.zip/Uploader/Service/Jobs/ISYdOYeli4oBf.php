<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
class ISYdOYeli4oBf implements WatermarkTextJobInterface
{
    private $bg_1H;
    private $ow_A9;
    private $agUMw;
    private $auR_S;
    private $bX3fI;
    public function __construct($IDVBi, $nNU6n, $JhAxH, $Q0hWX, $YZF64)
    {
        goto TgdV5;
        TgdV5:
        $this->bg_1H = $IDVBi;
        goto yji0g;
        LkaUT:
        $this->agUMw = $YZF64;
        goto Wpo1M;
        Wpo1M:
        $this->ow_A9 = $nNU6n;
        goto YD1BK;
        hoeOp:
        $this->bX3fI = $Q0hWX;
        goto LkaUT;
        yji0g:
        $this->auR_S = $JhAxH;
        goto hoeOp;
        YD1BK:
    }
    public function putWatermark(string $IaHim, string $sIqHa) : void
    {
        goto CD63s;
        CD63s:
        Log::info("Adding watermark text to image", ['imageId' => $IaHim]);
        goto xtOs8;
        m_9b8:
        try {
            goto SV18P;
            SV18P:
            $kHreC = FNGNxcyxjaxBG::findOrFail($IaHim);
            goto KMJHj;
            UK9Nd:
            if (chmod($JM0UK, 0664)) {
                goto V7Tez;
            }
            goto Un152;
            o21Ri:
            throw new \Exception('Failed to set final permissions on image file: ' . $JM0UK);
            goto WU1dY;
            Un152:
            \Log::warning('Failed to set final permissions on image file: ' . $JM0UK);
            goto o21Ri;
            K6rUr:
            p6GRg:
            goto Ujsl3;
            uhlIc:
            $HYrky = $this->bg_1H->call($this, $JM0UK);
            goto R2QwF;
            MPPXn:
            return;
            goto K6rUr;
            stV2B:
            $this->mOomjskkApu($HYrky, $sIqHa);
            goto ZORF3;
            R2QwF:
            $HYrky->orientate();
            goto stV2B;
            WU1dY:
            V7Tez:
            goto B1shV;
            KMJHj:
            if ($this->bX3fI->exists($kHreC->getLocation())) {
                goto p6GRg;
            }
            goto HVKU7;
            j2src:
            $HYrky->destroy();
            goto UK9Nd;
            ZORF3:
            $HYrky->save($JM0UK);
            goto j2src;
            HVKU7:
            Log::error("FNGNxcyxjaxBG is not on local, might be deleted before put watermark", ['imageId' => $IaHim]);
            goto MPPXn;
            Ujsl3:
            $JM0UK = $this->bX3fI->path($kHreC->getLocation());
            goto uhlIc;
            B1shV:
        } catch (\Throwable $fg0Tf) {
            goto abJ11;
            ithDR:
            Log::error("FNGNxcyxjaxBG is not readable", ['imageId' => $IaHim, 'error' => $fg0Tf->getMessage()]);
            goto KKbkT;
            EMDdz:
            gPXbJ:
            goto ithDR;
            abJ11:
            if (!$fg0Tf instanceof ModelNotFoundException) {
                goto gPXbJ;
            }
            goto hKmPB;
            hKmPB:
            Log::info("FNGNxcyxjaxBG has been deleted, discard it", ['imageId' => $IaHim]);
            goto rcDNG;
            rcDNG:
            return;
            goto EMDdz;
            KKbkT:
        }
        goto lNICX;
        xtOs8:
        ini_set('memory_limit', '-1');
        goto m_9b8;
        lNICX:
    }
    private function mOomjskkApu($HYrky, $sIqHa) : void
    {
        goto SNElX;
        SNElX:
        $ABqPe = $HYrky->width();
        goto CJ9YY;
        B6_yV:
        $ZR43H = $this->bg_1H->call($this, $this->bX3fI->path($SNvna));
        goto NP8zA;
        G7NRo:
        $HYrky->insert($ZR43H);
        goto u9RWm;
        tSQPz:
        $SNvna = $zVSZe->mqpgBukKPi0($ABqPe, $dE8ui, $sIqHa, true);
        goto nuv35;
        CJ9YY:
        $dE8ui = $HYrky->height();
        goto yIZWC;
        yIZWC:
        $zVSZe = new EJHKjyBhy7Tvv($this->ow_A9, $this->agUMw, $this->auR_S, $this->bX3fI);
        goto tSQPz;
        nuv35:
        $this->bX3fI->put($SNvna, $this->auR_S->get($SNvna));
        goto B6_yV;
        NP8zA:
        $ZR43H->opacity(35);
        goto G7NRo;
        u9RWm:
    }
}
