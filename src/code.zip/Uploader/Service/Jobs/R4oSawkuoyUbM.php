<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Illuminate\Support\Facades\Log;
class R4oSawkuoyUbM implements DownloadToLocalJobInterface
{
    private $tcoQz;
    private $AwDbR;
    public function __construct($v70jj, $uwOBm)
    {
        $this->tcoQz = $v70jj;
        $this->AwDbR = $uwOBm;
    }
    public function download(string $B5uQ4) : void
    {
        goto K0jwF;
        KNlMS:
        Log::info("Start download file to local", ['fileId' => $B5uQ4, 'filename' => $clm2Y->getLocation()]);
        goto HxBOX;
        BJJ26:
        return;
        goto odIXv;
        odIXv:
        eS1Gh:
        goto kulUg;
        kulUg:
        $this->AwDbR->put($clm2Y->getLocation(), $this->tcoQz->get($clm2Y->getLocation()));
        goto agRDg;
        K0jwF:
        $clm2Y = U0IzvN2kaLZHI::findOrFail($B5uQ4);
        goto KNlMS;
        HxBOX:
        if (!$this->AwDbR->exists($clm2Y->getLocation())) {
            goto eS1Gh;
        }
        goto BJJ26;
        agRDg:
    }
}
