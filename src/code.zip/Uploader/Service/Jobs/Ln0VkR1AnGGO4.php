<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Illuminate\Support\Facades\Log;
class Ln0VkR1AnGGO4 implements StoreVideoToS3JobInterface
{
    private $aHrC_;
    private $SxfKN;
    private $GmmTj;
    public function __construct($nIkcP, $DPWG1, $MYo5D)
    {
        goto BhWZe;
        RStdj:
        $this->aHrC_ = $nIkcP;
        goto Yn9WX;
        aqKv9:
        $this->GmmTj = $MYo5D;
        goto RStdj;
        BhWZe:
        $this->SxfKN = $DPWG1;
        goto aqKv9;
        Yn9WX:
    }
    public function store(string $GMwD5) : void
    {
        goto C8537;
        GagGe:
        Log::error("[Ln0VkR1AnGGO4] File not found, discard it ", ['video' => $OkIY3->getLocation()]);
        goto XcvFI;
        QnHYu:
        return;
        goto ZSEdM;
        DehDr:
        $ZV4fL = memory_get_peak_usage();
        goto gsU8b;
        WtsDy:
        $PY1oW = $MYo5D->readStream($OkIY3->getLocation());
        goto aY6vq;
        iiWTn:
        $MYo5D = $this->GmmTj;
        goto c5c1z;
        IppMz:
        ini_set('memory_limit', '-1');
        goto JQM12;
        XcvFI:
        return;
        goto dZAm6;
        JQM12:
        $Ylw8l = $this->SxfKN->getClient();
        goto iiWTn;
        MCxZu:
        $Dkgj8 = $MYo5D->mimeType($OkIY3->getLocation());
        goto MfNRH;
        aY6vq:
        $UmfS4 = 1024 * 1024 * 50;
        goto MCxZu;
        QDOzj:
        $u_Mwa = memory_get_usage();
        goto DehDr;
        dZAm6:
        GXUt3:
        goto WtsDy;
        gsU8b:
        try {
            goto Ntihw;
            qRTWk:
            $OkIY3->update(['driver' => CUySMhqlL7P49::S3, 'status' => Fsm7WCrUwVWh9::FINISHED]);
            goto EtlO_;
            cMx4I:
            $Ylw8l->completeMultipartUpload(['Bucket' => $this->aHrC_, 'Key' => $OkIY3->getLocation(), 'UploadId' => $cH0Pn, 'MultipartUpload' => ['Parts' => $zO8GR]]);
            goto qRTWk;
            Xxqn4:
            if (feof($PY1oW)) {
                goto uImRq;
            }
            goto mA3WY;
            J7mrQ:
            $zO8GR = [];
            goto yDOIC;
            mA3WY:
            $Qwbr_ = $Ylw8l->uploadPart(['Bucket' => $this->aHrC_, 'Key' => $OkIY3->getLocation(), 'UploadId' => $cH0Pn, 'PartNumber' => $bxAJc, 'Body' => fread($PY1oW, $UmfS4)]);
            goto C4FzH;
            yDOIC:
            DrQhI:
            goto Xxqn4;
            JH45D:
            fclose($PY1oW);
            goto cMx4I;
            DMgoB:
            $cH0Pn = $XDvUb['UploadId'];
            goto fhCek;
            fhCek:
            $bxAJc = 1;
            goto J7mrQ;
            oCRCg:
            $bxAJc++;
            goto ZRzqV;
            ZRzqV:
            goto DrQhI;
            goto SbHQV;
            SbHQV:
            uImRq:
            goto JH45D;
            Ntihw:
            $XDvUb = $Ylw8l->createMultipartUpload(['Bucket' => $this->aHrC_, 'Key' => $OkIY3->getLocation(), 'ContentType' => $Dkgj8, 'ContentDisposition' => 'inline']);
            goto DMgoB;
            EtlO_:
            $MYo5D->delete($OkIY3->getLocation());
            goto Bkics;
            C4FzH:
            $zO8GR[] = ['PartNumber' => $bxAJc, 'ETag' => $Qwbr_['ETag']];
            goto oCRCg;
            Bkics:
        } catch (AwsException $hPqRx) {
            goto WkuBL;
            WIQkq:
            try {
                $Ylw8l->abortMultipartUpload(['Bucket' => $this->aHrC_, 'Key' => $OkIY3->getLocation(), 'UploadId' => $cH0Pn]);
            } catch (AwsException $VEynW) {
                Log::error('Error aborting multipart upload: ' . $VEynW->getMessage());
            }
            goto KBGrS;
            WkuBL:
            if (!isset($cH0Pn)) {
                goto vfmt1;
            }
            goto WIQkq;
            fIqIu:
            Log::error('Failed to store video: ' . $OkIY3->getLocation() . ' - ' . $hPqRx->getMessage());
            goto GoYww;
            KBGrS:
            vfmt1:
            goto fIqIu;
            GoYww:
        } finally {
            $UWIzp = microtime(true);
            $nzC5Y = memory_get_usage();
            $gEpcX = memory_get_peak_usage();
            Log::info('Store RhdJGUi8FOLBJ to S3 function resource usage', ['imageId' => $GMwD5, 'execution_time_sec' => $UWIzp - $EztI0, 'memory_usage_mb' => ($nzC5Y - $u_Mwa) / 1024 / 1024, 'peak_memory_usage_mb' => ($gEpcX - $ZV4fL) / 1024 / 1024]);
        }
        goto UzzuJ;
        xP2TO:
        Log::info("RhdJGUi8FOLBJ has been deleted, discard it", ['fileId' => $GMwD5]);
        goto QnHYu;
        MfNRH:
        $EztI0 = microtime(true);
        goto QDOzj;
        C8537:
        Log::info('Storing video (local) to S3', ['fileId' => $GMwD5, 'bucketName' => $this->aHrC_]);
        goto IppMz;
        cGT1h:
        if ($MYo5D->exists($OkIY3->getLocation())) {
            goto GXUt3;
        }
        goto GagGe;
        ZSEdM:
        E8g6A:
        goto cGT1h;
        c5c1z:
        $OkIY3 = RhdJGUi8FOLBJ::find($GMwD5);
        goto v0Daf;
        v0Daf:
        if ($OkIY3) {
            goto E8g6A;
        }
        goto xP2TO;
        UzzuJ:
    }
}
