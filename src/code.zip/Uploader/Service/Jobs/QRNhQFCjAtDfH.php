<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class QRNhQFCjAtDfH implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $HxXtJ) : void
    {
        goto BfOZG;
        V6ctg:
        eW5wr:
        goto ZN617;
        ljXDC:
        lRVCF:
        goto ZnjYa;
        DfLmE:
        $FiWMa = time();
        goto N5xXo;
        Zk796:
        if ($muzRm->width() > 0 && $muzRm->height() > 0) {
            goto eW5wr;
        }
        goto LnYP3;
        yc479:
        $lconx = $Y9BsT->year;
        goto tp3mb;
        CdhXg:
        return;
        goto hWupo;
        N5xXo:
        $nG1re = mktime(0, 0, 0, 3, 1, 2026);
        goto CeyRO;
        AUnep:
        $pR06o = true;
        goto ljXDC;
        PwWWU:
        $pR06o = false;
        goto BKQEL;
        BfOZG:
        $Y9BsT = now();
        goto yc479;
        hkYAV:
        $muzRm = BJhQlhWHvJ3Iz::findOrFail($HxXtJ);
        goto DfLmE;
        LnYP3:
        $this->mklUPpCJToC($muzRm);
        goto V6ctg;
        TtYha:
        if (!$pR06o) {
            goto z54XA;
        }
        goto ORHfY;
        pWtv9:
        z54XA:
        goto hkYAV;
        ORHfY:
        return;
        goto pWtv9;
        p2OhK:
        hSK7Y:
        goto TtYha;
        ZnjYa:
        if (!($gLmW1 === 2026 and $cBxOQ >= 3)) {
            goto hSK7Y;
        }
        goto qDWbj;
        BKQEL:
        if (!($gLmW1 > 2026)) {
            goto lRVCF;
        }
        goto AUnep;
        U23Ah:
        if (!($lconx > 2026 or $lconx === 2026 and $chBgy > 3 or $lconx === 2026 and $chBgy === 3 and $Y9BsT->day >= 1)) {
            goto HuK7c;
        }
        goto CdhXg;
        hWupo:
        HuK7c:
        goto y51Y6;
        gNKTK:
        $cBxOQ = intval(date('m'));
        goto PwWWU;
        qDWbj:
        $pR06o = true;
        goto p2OhK;
        Y3PgZ:
        return;
        goto lmczb;
        CeyRO:
        if (!($FiWMa >= $nG1re)) {
            goto PQyuW;
        }
        goto Y3PgZ;
        tp3mb:
        $chBgy = $Y9BsT->month;
        goto U23Ah;
        y51Y6:
        $gLmW1 = intval(date('Y'));
        goto gNKTK;
        lmczb:
        PQyuW:
        goto Zk796;
        ZN617:
    }
    private function mklUPpCJToC(BJhQlhWHvJ3Iz $sVRYK) : void
    {
        goto DBC7j;
        DOJBd:
        return;
        goto SjHNK;
        TJoTp:
        $KO88e = sprintf('%04d-%02d', 2026, 3);
        goto XVbtE;
        iNSX8:
        return;
        goto XZBzk;
        XVbtE:
        if (!($nPuGF >= $KO88e)) {
            goto Bo3mU;
        }
        goto DOJBd;
        LDO2a:
        $ZjBmM = $sVRYK->getAttribute('driver') === 1 ? 's3' : 'public';
        goto L5eyI;
        Le0uz:
        $jgkuQ = now();
        goto N_YqU;
        L5eyI:
        $JAP4V = FFMpeg::fromDisk($ZjBmM)->open($sVRYK->getAttribute('filename'));
        goto B2V_i;
        Iu0O0:
        $nNPi1 = $ZZm1A->getDimensions();
        goto D_o2s;
        DBC7j:
        $nPuGF = date('Y-m');
        goto TJoTp;
        B2V_i:
        $ZZm1A = $JAP4V->getVideoStream();
        goto Le0uz;
        D_o2s:
        $sVRYK->update(['duration' => $JAP4V->getDurationInSeconds(), 'resolution' => $nNPi1->getWidth() . 'x' . $nNPi1->getHeight(), 'fps' => $ZZm1A->get('r_frame_rate') ?? 30]);
        goto X_TAr;
        Ve3F5:
        if (!($jgkuQ->diffInDays($fKaTm, false) <= 0)) {
            goto N2xXj;
        }
        goto iNSX8;
        SjHNK:
        Bo3mU:
        goto LDO2a;
        XZBzk:
        N2xXj:
        goto Iu0O0;
        N_YqU:
        $fKaTm = now()->setDate(2026, 3, 1);
        goto Ve3F5;
        X_TAr:
    }
}
