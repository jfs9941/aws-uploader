<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Service\Jobs\KdjM8JyD6nQG8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class QS26Y6E0tEcur implements WatermarkTextJobInterface
{
    private $kAoN_;
    private $VJ5nN;
    private $ujF3W;
    private $iHPgt;
    private $h0iwI;
    public function __construct($QJMxa, $TzB9b, $zeM4q, $jxMWP, $aKyb2)
    {
        goto vh9M5;
        REQMq:
        $this->ujF3W = $aKyb2;
        goto Luoku;
        vh9M5:
        $this->kAoN_ = $QJMxa;
        goto b2n1M;
        Luoku:
        $this->VJ5nN = $TzB9b;
        goto Z2TNN;
        b2n1M:
        $this->iHPgt = $zeM4q;
        goto VZbC9;
        VZbC9:
        $this->h0iwI = $jxMWP;
        goto REQMq;
        Z2TNN:
    }
    public function putWatermark(string $tu00C, string $gKVpe) : void
    {
        goto oxKjk;
        uVQOt:
        try {
            goto JG5Ao;
            HIJ4E:
            return;
            goto ruEwE;
            X54_u:
            Log::error("VPGaYsuFJzbQ0 is not on local, might be deleted before put watermark", ['imageId' => $tu00C]);
            goto HIJ4E;
            heWZO:
            if (chmod($fQjwQ, 0664)) {
                goto HXey5;
            }
            goto NSX6Q;
            NSX6Q:
            \Log::warning('Failed to set final permissions on image file: ' . $fQjwQ);
            goto ylt7v;
            xldIQ:
            $V3vQz = $this->kAoN_->call($this, $fQjwQ);
            goto PDePw;
            nSb7R:
            $this->iHPgt->put($fQjwQ, $V3vQz->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto RttE0;
            PDePw:
            $V3vQz->orient();
            goto F6bym;
            JG5Ao:
            $h4i8i = VPGaYsuFJzbQ0::findOrFail($tu00C);
            goto Viwlx;
            Viwlx:
            if ($this->h0iwI->exists($h4i8i->getLocation())) {
                goto r0u2a;
            }
            goto X54_u;
            x3WYf:
            HXey5:
            goto S7Cs8;
            ylt7v:
            throw new \Exception('Failed to set final permissions on image file: ' . $fQjwQ);
            goto x3WYf;
            AVJpn:
            $fQjwQ = $this->h0iwI->path($h4i8i->getLocation());
            goto xldIQ;
            ruEwE:
            r0u2a:
            goto AVJpn;
            F6bym:
            $this->mbYX1KC68By($V3vQz, $gKVpe);
            goto nSb7R;
            RttE0:
            unset($V3vQz);
            goto heWZO;
            S7Cs8:
        } catch (\Throwable $ihl9r) {
            goto RgOB9;
            fTJFj:
            nLM9J:
            goto fggGI;
            fggGI:
            Log::error("VPGaYsuFJzbQ0 is not readable", ['imageId' => $tu00C, 'error' => $ihl9r->getMessage()]);
            goto gJ8EW;
            RgOB9:
            if (!$ihl9r instanceof ModelNotFoundException) {
                goto nLM9J;
            }
            goto gGQw6;
            gGQw6:
            Log::info("VPGaYsuFJzbQ0 has been deleted, discard it", ['imageId' => $tu00C]);
            goto OzxT2;
            OzxT2:
            return;
            goto fTJFj;
            gJ8EW:
        } finally {
            $Taw_q = microtime(true);
            $rjavZ = memory_get_usage();
            $Szg_0 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $tu00C, 'execution_time_sec' => $Taw_q - $vLJkf, 'memory_usage_mb' => ($rjavZ - $SBeWo) / 1024 / 1024, 'peak_memory_usage_mb' => ($Szg_0 - $wsJtd) / 1024 / 1024]);
        }
        goto sCnUY;
        U2TVT:
        ini_set('memory_limit', '-1');
        goto uVQOt;
        CQudg:
        Log::info("Adding watermark text to image", ['imageId' => $tu00C]);
        goto U2TVT;
        jYtlm:
        $wsJtd = memory_get_peak_usage();
        goto CQudg;
        If8ha:
        $SBeWo = memory_get_usage();
        goto jYtlm;
        oxKjk:
        $vLJkf = microtime(true);
        goto If8ha;
        sCnUY:
    }
    private function mbYX1KC68By($V3vQz, $gKVpe) : void
    {
        goto LibWF;
        LibWF:
        $Nk4Te = $V3vQz->width();
        goto u00bl;
        usFvO:
        $GhaAI = $UAHgP->mRm4cjztnmq($Nk4Te, $jCfbb, $gKVpe, true);
        goto ssgzw;
        ssgzw:
        $this->h0iwI->put($GhaAI, $this->iHPgt->get($GhaAI));
        goto FxTP7;
        zACta:
        $UAHgP = new KdjM8JyD6nQG8($this->VJ5nN, $this->ujF3W, $this->iHPgt, $this->h0iwI);
        goto usFvO;
        paxVs:
        $V3vQz->place($RLzZk, 'top-left', 0, 0, 30);
        goto f0RSC;
        u00bl:
        $jCfbb = $V3vQz->height();
        goto zACta;
        FxTP7:
        $RLzZk = $this->kAoN_->call($this, $this->h0iwI->path($GhaAI));
        goto paxVs;
        f0RSC:
    }
}
