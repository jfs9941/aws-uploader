<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
class J8Eq2shmK5zdf implements DownloadToLocalJobInterface
{
    private $dhrkT;
    private $sf39X;
    public function __construct($v8n0s, $ZqxJI)
    {
        $this->dhrkT = $v8n0s;
        $this->sf39X = $ZqxJI;
    }
    public function download(string $cQqZd) : void
    {
        goto i5EL8;
        pIKNV:
        Y0Dfn:
        goto wD3Zd;
        wD3Zd:
        $this->sf39X->put($tscCi->getLocation(), $this->dhrkT->get($tscCi->getLocation()));
        goto NX1cu;
        i5EL8:
        $tscCi = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
        goto byEeO;
        vkth7:
        return;
        goto pIKNV;
        qYeyx:
        if (!$this->sf39X->exists($tscCi->getLocation())) {
            goto Y0Dfn;
        }
        goto vkth7;
        byEeO:
        Log::info("Start download file to local", ['fileId' => $cQqZd, 'filename' => $tscCi->getLocation()]);
        goto qYeyx;
        NX1cu:
    }
}
