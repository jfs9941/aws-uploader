<?php

namespace Jfs\Uploader\Service\Jobs;



use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Enum\FileDriver;
use Jfs\Uploader\Enum\FileStatus;

class StoreImageToS3Job implements StoreToS3JobInterface
{
    /**
     * @var \Closure
     */
    private $maker;
    private $s3;
    private $localDisk;
    public function __construct($maker, $s3, $localDisk)
    {
        $this->s3 = $s3;
        $this->localDisk = $localDisk;
        $this->maker = $maker;
    }

    public function store(string $id): void
    {
        $imageModel = Image::findOrFail($id);

        if (!$imageModel) {
            Log::info("Image has been deleted, discard it", ['fileId' => $id]);
            return;
        }

        $path = $this->localDisk->path($imageModel->getLocation());
        $image = $this->maker->call($this, $path);
        $this->s3->put($imageModel->getLocation(), $image->stream(), [
            'visibility' => 'public',
            'ContentType' => $image->mime(),
            'ContentDisposition' => 'inline',
        ]);
        $thumbnailValue = $imageModel->getAttribute('thumbnail');
        if ($thumbnailValue && $this->localDisk->exists($thumbnailValue)) {
            $thumbnailPath = $this->localDisk->path($thumbnailValue);

            $thumbnail = $this->maker->call($this, $thumbnailPath);
            $this->s3->put($imageModel->getAttribute('thumbnail'), $thumbnail->stream(), [
                'visibility' => 'public',
                'ContentType' => $thumbnail->mime(),
                'ContentDisposition' => 'inline',
            ]);
        }

        if ($imageModel->getAttribute('preview') && $this->localDisk->exists($imageModel->getAttribute('preview'))) {
            $previewPath = $this->localDisk->path($imageModel->getAttribute('preview'));

            $preview = $this->maker->call($this, $previewPath);
            $this->s3->put($imageModel->getAttribute('preview'), $preview->stream(), [
                'visibility' => 'public',
                'ContentType' => $preview->mime(),
                'ContentDisposition' => 'inline',
            ]);
        }

        if ($imageModel->update(['driver' => FileDriver::S3, 'status' => FileStatus::FINISHED])) {
            Log::info("Image stored to S3, update the children attachments", ['fileId' => $id]);
            Image::where('parent_id', $id)->update([
                'driver' => FileDriver::S3,
                'preview' => $imageModel->getAttribute('preview'),
                'thumbnail' => $imageModel->getAttribute('thumbnail'),
            ]);
            return;
        }
        Log::error("Failed to update image model after storing to S3", ['fileId' => $id]);
    }
}
