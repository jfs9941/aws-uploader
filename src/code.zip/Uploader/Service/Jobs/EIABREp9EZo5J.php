<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class EIABREp9EZo5J implements GenerateThumbnailForVideoInterface
{
    private $HnP1N;
    public function __construct($XGrIg)
    {
        $this->HnP1N = $XGrIg;
    }
    public function generate(string $InHEz) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $InHEz);
        $this->HnP1N->createThumbnail($InHEz);
    }
}
