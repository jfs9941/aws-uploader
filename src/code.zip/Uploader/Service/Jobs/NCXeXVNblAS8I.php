<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
class NCXeXVNblAS8I implements DownloadToLocalJobInterface
{
    private $IRlXr;
    private $foEoP;
    public function __construct($JGvdR, $VGndK)
    {
        $this->IRlXr = $JGvdR;
        $this->foEoP = $VGndK;
    }
    public function download(string $R7IrL) : void
    {
        goto oeOsF;
        J9pZK:
        Log::info("Start download file to local", ['fileId' => $R7IrL, 'filename' => $xdi9a->getLocation()]);
        goto WgVW_;
        WgVW_:
        if (!$this->foEoP->exists($xdi9a->getLocation())) {
            goto dL6os;
        }
        goto sHLiq;
        U9cF6:
        $this->foEoP->put($xdi9a->getLocation(), $this->IRlXr->get($xdi9a->getLocation()));
        goto lACvM;
        sHLiq:
        return;
        goto rFu9e;
        oeOsF:
        $xdi9a = OcbNsXl9lpteB::findOrFail($R7IrL);
        goto J9pZK;
        rFu9e:
        dL6os:
        goto U9cF6;
        lACvM:
    }
}
