<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class TzF4QjjMGsAzw
{
    private $BvcmA;
    private $M6ILS;
    public function __construct(int $dhJg5, int $KGraK)
    {
        goto BjIbO;
        CB9Ul:
        if (!($KGraK <= 0)) {
            goto g13PG;
        }
        goto iClhT;
        gvnJU:
        $this->M6ILS = $KGraK;
        goto Wp5jD;
        WAAfE:
        $this->BvcmA = $dhJg5;
        goto gvnJU;
        BjIbO:
        if (!($dhJg5 <= 0)) {
            goto XqbNV;
        }
        goto ouHjV;
        OV1nG:
        g13PG:
        goto WAAfE;
        iClhT:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto OV1nG;
        pYdmJ:
        XqbNV:
        goto CB9Ul;
        ouHjV:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto pYdmJ;
        Wp5jD:
    }
    private static function m4XstNafzQs($jfSN2, string $RJIDU = 'floor') : int
    {
        goto Ez6xf;
        G0mtB:
        switch (strtolower($RJIDU)) {
            case 'ceil':
                return (int) (ceil($jfSN2 / 2) * 2);
            case 'round':
                return (int) (round($jfSN2 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($jfSN2 / 2) * 2);
        }
        goto g2qTU;
        g2qTU:
        ECFT7:
        goto gptQQ;
        p53IN:
        if (!(is_float($jfSN2) && $jfSN2 == floor($jfSN2) && (int) $jfSN2 % 2 === 0)) {
            goto Whgly;
        }
        goto k_aoO;
        gptQQ:
        gZqc5:
        goto YRMui;
        Ez6xf:
        if (!(is_int($jfSN2) && $jfSN2 % 2 === 0)) {
            goto Xqxg1;
        }
        goto HEbbV;
        k_aoO:
        return (int) $jfSN2;
        goto jy5RR;
        jy5RR:
        Whgly:
        goto G0mtB;
        pciil:
        Xqxg1:
        goto p53IN;
        HEbbV:
        return $jfSN2;
        goto pciil;
        YRMui:
    }
    public function mOZ5Qjnxwu5(string $iw1uA = 'floor') : array
    {
        goto XtUrb;
        XtUrb:
        $PaZNt = 1080;
        goto VgqQ4;
        KNNPz:
        return ['width' => $ZmZdf, 'height' => $TYo5U];
        goto g6L2i;
        RoacU:
        $MzaFj = $this->M6ILS * $TNHKo;
        goto QwC91;
        yHAve:
        $ZmZdf = self::m4XstNafzQs(round($oliQY), $iw1uA);
        goto kaFIe;
        mOjt7:
        if (!($TYo5U < 2)) {
            goto oxhXz;
        }
        goto rqlDg;
        RB110:
        goto Nw8Ug;
        goto oR1HJ;
        kaFIe:
        Nw8Ug:
        goto OJ3RX;
        w6qSk:
        $TNHKo = $ZmZdf / $this->BvcmA;
        goto RoacU;
        dFNuf:
        oxhXz:
        goto KNNPz;
        jTMfz:
        iEWaZ:
        goto mOjt7;
        OJ3RX:
        if (!($ZmZdf < 2)) {
            goto iEWaZ;
        }
        goto r569n;
        irf8H:
        $oliQY = $this->BvcmA * $TNHKo;
        goto yHAve;
        EWKlw:
        if ($this->BvcmA >= $this->M6ILS) {
            goto Q_SVK;
        }
        goto IU5_u;
        r569n:
        $ZmZdf = 2;
        goto jTMfz;
        QwC91:
        $TYo5U = self::m4XstNafzQs(round($MzaFj), $iw1uA);
        goto RB110;
        oR1HJ:
        Q_SVK:
        goto G16w6;
        rqlDg:
        $TYo5U = 2;
        goto dFNuf;
        IU5_u:
        $ZmZdf = $PaZNt;
        goto w6qSk;
        X_bSa:
        $TNHKo = $TYo5U / $this->M6ILS;
        goto irf8H;
        bNjhG:
        $TYo5U = 0;
        goto EWKlw;
        VgqQ4:
        $ZmZdf = 0;
        goto bNjhG;
        G16w6:
        $TYo5U = $PaZNt;
        goto X_bSa;
        g6L2i:
    }
}
