<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class CR2ATNJKiDMBa implements StoreToS3JobInterface
{
    private $z7YJI;
    private $PxC6l;
    private $MpAl4;
    public function __construct($fvRbj, $kxhX9, $U2KRS)
    {
        goto ol2_X;
        dyUcm:
        $this->z7YJI = $fvRbj;
        goto CFjRw;
        ol2_X:
        $this->PxC6l = $kxhX9;
        goto zYhrY;
        zYhrY:
        $this->MpAl4 = $U2KRS;
        goto dyUcm;
        CFjRw:
    }
    public function store(string $S580N) : void
    {
        goto JjKD1;
        xmcTy:
        $m8nUu = $this->MpAl4->path($xEOjN);
        goto K12y1;
        gog6n:
        return;
        goto Q4cn2;
        NQQzE:
        if (!($xEOjN && $this->MpAl4->exists($xEOjN))) {
            goto gicbH;
        }
        goto xmcTy;
        RdZYU:
        $vnI54 = $this->z7YJI->call($this, $K5DbU);
        goto T1NV2;
        T1NV2:
        $this->PxC6l->put($Tw0WE->getAttribute('preview'), $this->MpAl4->get($Tw0WE->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $vnI54->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto FHVgt;
        kf_4E:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $S580N]);
        goto hjDSv;
        GCHFL:
        $xEOjN = $Tw0WE->getAttribute('thumbnail');
        goto NQQzE;
        ESft0:
        Log::info("KfEJaEGpFJ0tm has been deleted, discard it", ['fileId' => $S580N]);
        goto FWPwC;
        K12y1:
        $lSq7k = $this->z7YJI->call($this, $m8nUu);
        goto mrPpX;
        e2EXW:
        paOHS:
        goto HMC6H;
        hlvS7:
        $this->muUUxjZchwF($d1QWa, $Tw0WE->getLocation());
        goto GCHFL;
        HV1Ur:
        Log::info("KfEJaEGpFJ0tm stored to S3, update the children attachments", ['fileId' => $S580N]);
        goto u5Edu;
        wgHci:
        $K5DbU = $this->MpAl4->path($Tw0WE->getAttribute('preview'));
        goto RdZYU;
        FHVgt:
        ZRZS0:
        goto gY9qg;
        Q4cn2:
        QO7xZ:
        goto kf_4E;
        u5Edu:
        KfEJaEGpFJ0tm::where('parent_id', $S580N)->update(['driver' => McZXbZmlQ53or::S3, 'preview' => $Tw0WE->getAttribute('preview'), 'thumbnail' => $Tw0WE->getAttribute('thumbnail')]);
        goto gog6n;
        FWPwC:
        return;
        goto e2EXW;
        brLwo:
        if (!($Tw0WE->getAttribute('preview') && $this->MpAl4->exists($Tw0WE->getAttribute('preview')))) {
            goto ZRZS0;
        }
        goto wgHci;
        JjKD1:
        $Tw0WE = KfEJaEGpFJ0tm::findOrFail($S580N);
        goto xaSbR;
        HMC6H:
        $d1QWa = $this->MpAl4->path($Tw0WE->getLocation());
        goto hlvS7;
        mrPpX:
        $this->PxC6l->put($Tw0WE->getAttribute('thumbnail'), $this->MpAl4->get($xEOjN), ['visibility' => 'public', 'ContentType' => $lSq7k->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Cu0fI;
        xaSbR:
        if ($Tw0WE) {
            goto paOHS;
        }
        goto ESft0;
        gY9qg:
        if (!$Tw0WE->update(['driver' => McZXbZmlQ53or::S3, 'status' => EHhCBxlsVyz9C::FINISHED])) {
            goto QO7xZ;
        }
        goto HV1Ur;
        Cu0fI:
        gicbH:
        goto brLwo;
        hjDSv:
    }
    private function muUUxjZchwF($ycOnW, $V2aDe, $WXZ1K = '')
    {
        goto PEqML;
        Md1wX:
        C7K2F:
        goto xgNtJ;
        PEqML:
        if (!$WXZ1K) {
            goto C7K2F;
        }
        goto Lx2tF;
        xgNtJ:
        try {
            $gNhb4 = $this->z7YJI->call($this, $ycOnW);
            $this->PxC6l->put($V2aDe, $this->MpAl4->get($V2aDe), ['visibility' => 'public', 'ContentType' => $gNhb4->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $p0etA) {
            Log::error("Failed to upload image to S3", ['s3Path' => $V2aDe, 'error' => $p0etA->getMessage()]);
        }
        goto pyu6f;
        Lx2tF:
        $ycOnW = str_replace('.jpg', $WXZ1K, $ycOnW);
        goto z89Wu;
        z89Wu:
        $V2aDe = str_replace('.jpg', $WXZ1K, $V2aDe);
        goto Md1wX;
        pyu6f:
    }
}
