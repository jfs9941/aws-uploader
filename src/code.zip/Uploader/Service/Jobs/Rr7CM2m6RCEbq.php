<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class Rr7CM2m6RCEbq implements CompressJobInterface
{
    const NLSee = 60;
    private $VnheV;
    private $GmmTj;
    private $l6NR4;
    public function __construct($wUcGa, $MYo5D, $Y7rOa)
    {
        goto TkPsj;
        l4bOe:
        $this->GmmTj = $MYo5D;
        goto qGRZd;
        fWwr0:
        $this->l6NR4 = $Y7rOa;
        goto l4bOe;
        TkPsj:
        $this->VnheV = $wUcGa;
        goto fWwr0;
        qGRZd:
    }
    public function compress(string $GMwD5)
    {
        goto cCeZt;
        o1ZI1:
        try {
            goto hxUs3;
            WxYEn:
            $dmeuh = $this->mwNIJyFid8F($dmeuh, 'jpg');
            goto CmNxm;
            RnWgl:
            if (!(strtolower($dmeuh->getExtension()) === 'png' || strtolower($dmeuh->getExtension()) === 'heic')) {
                goto urcWs;
            }
            goto WxYEn;
            CmNxm:
            urcWs:
            goto PvGPB;
            hxUs3:
            $dmeuh = C6ftQJKUZRJIp::findOrFail($GMwD5);
            goto yDwj8;
            PvGPB:
            try {
                goto xd62t;
                yi7yv:
                $this->mwNIJyFid8F($dmeuh, 'webp');
                goto TD2Nr;
                xd62t:
                $ninXZ = $this->GmmTj->path(str_replace('.jpg', '.webp', $dmeuh->getLocation()));
                goto KK1oY;
                KK1oY:
                $this->m9zX9JTL9HY($CFmMK, $ninXZ);
                goto yi7yv;
                TD2Nr:
            } catch (\Exception $hPqRx) {
                goto lSFMW;
                lSFMW:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $GMwD5, 'error' => $hPqRx->getMessage()]);
                goto pJlbx;
                pJlbx:
                $ninXZ = $this->GmmTj->path($dmeuh->getLocation());
                goto UE1mm;
                UE1mm:
                $this->mtTxJBSA1N5($CFmMK, $ninXZ);
                goto vNZzZ;
                vNZzZ:
            }
            goto AVV0G;
            yDwj8:
            $CFmMK = $this->GmmTj->path($dmeuh->getLocation());
            goto RnWgl;
            AVV0G:
        } catch (\Throwable $hPqRx) {
            goto bVs1e;
            bVs1e:
            if (!$hPqRx instanceof ModelNotFoundException) {
                goto Si3CY;
            }
            goto ZMCGU;
            ZMCGU:
            Log::info("C6ftQJKUZRJIp has been deleted, discard it", ['imageId' => $GMwD5]);
            goto Bk13K;
            mqoob:
            Log::error("Failed to compress image", ['imageId' => $GMwD5, 'error' => $hPqRx->getMessage()]);
            goto eGxnE;
            Bk13K:
            return;
            goto rJtom;
            rJtom:
            Si3CY:
            goto mqoob;
            eGxnE:
        } finally {
            $UWIzp = microtime(true);
            $nzC5Y = memory_get_usage();
            $gEpcX = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $GMwD5, 'execution_time_sec' => $UWIzp - $EztI0, 'memory_usage_mb' => ($nzC5Y - $u_Mwa) / 1024 / 1024, 'peak_memory_usage_mb' => ($gEpcX - $ZV4fL) / 1024 / 1024]);
        }
        goto ZelIZ;
        j57aF:
        $ZV4fL = memory_get_peak_usage();
        goto vB0zE;
        cCeZt:
        $EztI0 = microtime(true);
        goto KBf_x;
        vB0zE:
        Log::info("Compress image", ['imageId' => $GMwD5]);
        goto o1ZI1;
        KBf_x:
        $u_Mwa = memory_get_usage();
        goto j57aF;
        ZelIZ:
    }
    private function mtTxJBSA1N5($CFmMK, $ninXZ)
    {
        goto UxgeV;
        ByKjr:
        $this->l6NR4->put($ninXZ, $VbqkY->toJpeg(self::NLSee), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto XHiIh;
        XHiIh:
        unset($VbqkY);
        goto G3HYO;
        r2AWE:
        $VbqkY->orient()->toJpeg(self::NLSee)->save($ninXZ);
        goto ByKjr;
        UxgeV:
        $VbqkY = $this->VnheV->call($this, $CFmMK);
        goto r2AWE;
        G3HYO:
    }
    private function m9zX9JTL9HY($CFmMK, $ninXZ)
    {
        goto aLU0i;
        NA9XG:
        unset($VbqkY);
        goto GhjA9;
        M03tJ:
        $VbqkY->orient()->toWebp(self::NLSee);
        goto D_cpQ;
        aLU0i:
        $VbqkY = $this->VnheV->call($this, $CFmMK);
        goto M03tJ;
        D_cpQ:
        $this->l6NR4->put($ninXZ, $VbqkY->toJpeg(self::NLSee), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto NA9XG;
        GhjA9:
    }
    private function mwNIJyFid8F($dmeuh, $MEDn0)
    {
        goto t5lhH;
        rlB1P:
        $dmeuh->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$MEDn0}", $dmeuh->getLocation()));
        goto cxxFG;
        t5lhH:
        $dmeuh->setAttribute('type', $MEDn0);
        goto rlB1P;
        cxxFG:
        $dmeuh->save();
        goto aCxh0;
        aCxh0:
        return $dmeuh;
        goto zS0ka;
        zS0ka:
    }
}
