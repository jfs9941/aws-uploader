<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Uploader\Service\Jobs; use Jfs\Exposed\Jobs\PrepareMetadataJobInterface; use Jfs\Uploader\Core\OgXvS9KDq1Lql; use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg; class ERyQr9GBfbWHe implements PrepareMetadataJobInterface { public function prepareMetadata(string $hJXEE) : void { goto RrVmV; btxMD: W8N5T: goto XEz1_; RrVmV: $mzQW8 = OgXvS9KDq1Lql::findOrFail($hJXEE); goto Tp07F; iJYcw: $this->mZ3RylpYWqq($mzQW8); goto btxMD; Tp07F: if ($mzQW8->width() > 0 && $mzQW8->height() > 0) { goto W8N5T; } goto iJYcw; XEz1_: } private function mZ3RylpYWqq(OgXvS9KDq1Lql $EOj9T) : void { goto tsdW4; tsdW4: $IBOkW = $EOj9T->getView(); goto N4xsG; rcrXT: $GkJe1 = $hr1eV->getDimensions(); goto fxOns; lhS7D: $hr1eV = $zSEOq->getVideoStream(); goto rcrXT; fxOns: $EOj9T->update(['duration' => $zSEOq->getDurationInSeconds(), 'resolution' => $GkJe1->getWidth() . 'x' . $GkJe1->getHeight(), 'fps' => $hr1eV->get('r_frame_rate') ?? 30]); goto YGrL4; N4xsG: $zSEOq = FFMpeg::fromDisk($IBOkW['path'])->open($EOj9T->getAttribute('filename')); goto lhS7D; YGrL4: } }
