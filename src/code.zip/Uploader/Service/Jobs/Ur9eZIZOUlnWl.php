<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Illuminate\Support\Facades\Log;
class Ur9eZIZOUlnWl implements DownloadToLocalJobInterface
{
    private $iHPgt;
    private $cGz6K;
    public function __construct($zeM4q, $DAY12)
    {
        $this->iHPgt = $zeM4q;
        $this->cGz6K = $DAY12;
    }
    public function download(string $tu00C) : void
    {
        goto cTJCq;
        PHJjV:
        xkNQe:
        goto hGPJH;
        hGPJH:
        $this->cGz6K->put($bwI0g->getLocation(), $this->iHPgt->get($bwI0g->getLocation()));
        goto bRfzz;
        SGMc2:
        if (!$this->cGz6K->exists($bwI0g->getLocation())) {
            goto xkNQe;
        }
        goto V3T0i;
        j1fbL:
        Log::info("Start download file to local", ['fileId' => $tu00C, 'filename' => $bwI0g->getLocation()]);
        goto SGMc2;
        cTJCq:
        $bwI0g = VPGaYsuFJzbQ0::findOrFail($tu00C);
        goto j1fbL;
        V3T0i:
        return;
        goto PHJjV;
        bRfzz:
    }
}
