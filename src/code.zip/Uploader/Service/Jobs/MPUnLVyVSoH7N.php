<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\DKKTuKFrzfZ51;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Service\Jobs\TB5JGG95O6Sla;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class MPUnLVyVSoH7N implements DKKTuKFrzfZ51
{
    private $W3SEw;
    private $s97Dj;
    private $CMe9Y;
    private $kEfMA;
    private $FJZRi;
    public function __construct($DrcMD, $VV0qO, $FP6ih, $UEDUm, $BoduH)
    {
        goto GCFig;
        m1G_X:
        $this->CMe9Y = $BoduH;
        goto gw1jP;
        GCFig:
        $this->W3SEw = $DrcMD;
        goto dtUAu;
        dtUAu:
        $this->kEfMA = $FP6ih;
        goto Wf7vf;
        gw1jP:
        $this->s97Dj = $VV0qO;
        goto pn8Dt;
        Wf7vf:
        $this->FJZRi = $UEDUm;
        goto m1G_X;
        pn8Dt:
    }
    public function putWatermark(string $EQQae, string $yy69B) : void
    {
        goto qGFlo;
        rnkUT:
        try {
            goto Qu4wU;
            W2vjt:
            unset($Y2mNU);
            goto X62og;
            QUR3T:
            gcUuf:
            goto LOwDK;
            lg1ol:
            Log::error("CrEYqpC23XUGo is not on local, might be deleted before put watermark", ['imageId' => $EQQae]);
            goto ufagE;
            kXgKd:
            IUO2O:
            goto qFC2Y;
            hl7ua:
            throw new \Exception('Failed to set final permissions on image file: ' . $KPnwr);
            goto QUR3T;
            X62og:
            if (chmod($KPnwr, 0664)) {
                goto gcUuf;
            }
            goto VIOSY;
            Oq4RK:
            $Y2mNU = $this->W3SEw->call($this, $KPnwr);
            goto T8M_Z;
            VIOSY:
            \Log::warning('Failed to set final permissions on image file: ' . $KPnwr);
            goto hl7ua;
            y46Pj:
            if ($this->FJZRi->exists($ulojh->getLocation())) {
                goto IUO2O;
            }
            goto lg1ol;
            Y8kqO:
            $this->kEfMA->put($KPnwr, $Y2mNU->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto W2vjt;
            Qu4wU:
            $ulojh = CrEYqpC23XUGo::findOrFail($EQQae);
            goto y46Pj;
            iTyYA:
            $this->m0g2ZYfLYI4($Y2mNU, $yy69B);
            goto Y8kqO;
            T8M_Z:
            $Y2mNU->orient();
            goto iTyYA;
            qFC2Y:
            $KPnwr = $this->FJZRi->path($ulojh->getLocation());
            goto Oq4RK;
            ufagE:
            return;
            goto kXgKd;
            LOwDK:
        } catch (\Throwable $flZyX) {
            goto ocb1X;
            oWCEO:
            DmMu9:
            goto WJvkY;
            VjrsU:
            Log::info("CrEYqpC23XUGo has been deleted, discard it", ['imageId' => $EQQae]);
            goto MiY0Q;
            ocb1X:
            if (!$flZyX instanceof ModelNotFoundException) {
                goto DmMu9;
            }
            goto VjrsU;
            MiY0Q:
            return;
            goto oWCEO;
            WJvkY:
            Log::error("CrEYqpC23XUGo is not readable", ['imageId' => $EQQae, 'error' => $flZyX->getMessage()]);
            goto N0UuR;
            N0UuR:
        } finally {
            $nQaGH = microtime(true);
            $QXkFj = memory_get_usage();
            $VfjfL = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $EQQae, 'execution_time_sec' => $nQaGH - $XzwBF, 'memory_usage_mb' => ($QXkFj - $CaFiz) / 1024 / 1024, 'peak_memory_usage_mb' => ($VfjfL - $m3FUa) / 1024 / 1024]);
        }
        goto R6SPH;
        iCBOu:
        Log::info("Adding watermark text to image", ['imageId' => $EQQae]);
        goto ip01a;
        t6Ylo:
        $m3FUa = memory_get_peak_usage();
        goto iCBOu;
        qGFlo:
        $XzwBF = microtime(true);
        goto zI0QI;
        zI0QI:
        $CaFiz = memory_get_usage();
        goto t6Ylo;
        ip01a:
        ini_set('memory_limit', '-1');
        goto rnkUT;
        R6SPH:
    }
    private function m0g2ZYfLYI4($Y2mNU, $yy69B) : void
    {
        goto iV4zG;
        FDAF_:
        $w2CQY = $rl8g3->mYCip0tFyl3($BxXBR, $w10Ma, $yy69B, true);
        goto nbpmb;
        Qi8ut:
        $rl8g3 = new TB5JGG95O6Sla($this->s97Dj, $this->CMe9Y, $this->kEfMA, $this->FJZRi);
        goto FDAF_;
        KiPy8:
        $w10Ma = $Y2mNU->height();
        goto Qi8ut;
        sdI5b:
        $MdWud = $this->W3SEw->call($this, $this->FJZRi->path($w2CQY));
        goto u1TzA;
        iV4zG:
        $BxXBR = $Y2mNU->width();
        goto KiPy8;
        nbpmb:
        $this->FJZRi->put($w2CQY, $this->kEfMA->get($w2CQY));
        goto sdI5b;
        u1TzA:
        $Y2mNU->place($MdWud, 'top-left', 0, 0, 30);
        goto lTrng;
        lTrng:
    }
}
