<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class SU5x9dXP1H4uj implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $ElvKF) : void
    {
        goto qVpei;
        qVpei:
        $eYbzj = UMeQT1ArE1U05::findOrFail($ElvKF);
        goto gXNxR;
        yP_P3:
        qv8PV:
        goto nEJKK;
        cVb9x:
        $this->mu9iPRm1RRn($eYbzj);
        goto yP_P3;
        gXNxR:
        if ($eYbzj->width() > 0 && $eYbzj->height() > 0) {
            goto qv8PV;
        }
        goto cVb9x;
        nEJKK:
    }
    private function mu9iPRm1RRn(UMeQT1ArE1U05 $q8Cz4) : void
    {
        goto a1y0J;
        sIS9p:
        $WhcQ6 = $p2x5d->getVideoStream();
        goto HhFuY;
        Nq8Ws:
        $q8Cz4->update(['duration' => $p2x5d->getDurationInSeconds(), 'resolution' => $kazw2->getWidth() . 'x' . $kazw2->getHeight(), 'fps' => $WhcQ6->get('r_frame_rate') ?? 30]);
        goto Ns00t;
        HhFuY:
        $kazw2 = $WhcQ6->getDimensions();
        goto Nq8Ws;
        a1y0J:
        $NyT6D = $q8Cz4->getView();
        goto BAIfJ;
        BAIfJ:
        $p2x5d = FFMpeg::fromDisk($NyT6D['path'])->open($q8Cz4->getAttribute('filename'));
        goto sIS9p;
        Ns00t:
    }
}
