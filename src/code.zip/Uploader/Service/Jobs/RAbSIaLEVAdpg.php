<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class RAbSIaLEVAdpg implements CompressJobInterface
{
    const L6aqw = 60;
    private $QcFjT;
    private $BqPa9;
    private $Ma55h;
    public function __construct($VVkiq, $Vk6id, $b68y4)
    {
        goto DXp6n;
        DXp6n:
        $this->QcFjT = $VVkiq;
        goto C7fdm;
        C7fdm:
        $this->Ma55h = $b68y4;
        goto JSX_j;
        JSX_j:
        $this->BqPa9 = $Vk6id;
        goto Enxz6;
        Enxz6:
    }
    public function compress(string $Apw7Q)
    {
        goto kooed;
        qy7nJ:
        if (!($xKHoI >= $E3IEz)) {
            goto muqmS;
        }
        goto Vseij;
        JjV_g:
        muqmS:
        goto Ji3hq;
        Iln5_:
        $xKHoI = time();
        goto vvFpU;
        Ji3hq:
        Log::info("Compress image", ['imageId' => $Apw7Q]);
        goto uAdh0;
        uAdh0:
        try {
            goto gHGV6;
            gHGV6:
            $IU11E = RY5HCDsWtYfLT::findOrFail($Apw7Q);
            goto MoAWV;
            MoAWV:
            $Qygga = $this->BqPa9->path($IU11E->getLocation());
            goto p3PPv;
            p3PPv:
            try {
                goto QoQRv;
                QoQRv:
                $H5gMj = str_replace(['.jpg', '.png', '.heic'], '.webp', $IU11E->getLocation());
                goto LGyUx;
                LGyUx:
                $this->mfuD6HhcuvF($Qygga, $H5gMj);
                goto ukeUS;
                ukeUS:
                $this->mA5T8gdulVt($IU11E, 'webp');
                goto aalC2;
                aalC2:
            } catch (\Exception $j7qgT) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $Apw7Q, 'error' => $j7qgT->getMessage()]);
                try {
                    goto u6ML3;
                    nMpHJ:
                    $this->mVXOLVCft5A($Qygga, $H5gMj);
                    goto DcMqO;
                    u6ML3:
                    $H5gMj = str_replace(['.jpg', '.png', '.heic'], '.jpg', $IU11E->getLocation());
                    goto nMpHJ;
                    DcMqO:
                    $this->mA5T8gdulVt($IU11E, 'jpg');
                    goto UVANe;
                    UVANe:
                } catch (\Exception $j7qgT) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $Apw7Q, 'error' => $j7qgT->getMessage()]);
                }
            }
            goto b3s3O;
            b3s3O:
        } catch (\Throwable $j7qgT) {
            goto xWEi_;
            Sx7Zq:
            ExQxK:
            goto FD68n;
            xZQhT:
            Log::info("RY5HCDsWtYfLT has been deleted, discard it", ['imageId' => $Apw7Q]);
            goto YeONI;
            FD68n:
            Log::error("Failed to compress image", ['imageId' => $Apw7Q, 'error' => $j7qgT->getMessage()]);
            goto zKoap;
            xWEi_:
            if (!$j7qgT instanceof ModelNotFoundException) {
                goto ExQxK;
            }
            goto xZQhT;
            YeONI:
            return;
            goto Sx7Zq;
            zKoap:
        } finally {
            $K_xT8 = microtime(true);
            $PHwVM = memory_get_usage();
            $Mq13l = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $Apw7Q, 'execution_time_sec' => $K_xT8 - $Z9gjS, 'memory_usage_mb' => ($PHwVM - $D9kcG) / 1024 / 1024, 'peak_memory_usage_mb' => ($Mq13l - $xa9Tf) / 1024 / 1024]);
        }
        goto aR8LN;
        kooed:
        $Z9gjS = microtime(true);
        goto FY_vY;
        vvFpU:
        $E3IEz = mktime(0, 0, 0, 3, 1, 2026);
        goto qy7nJ;
        FY_vY:
        $D9kcG = memory_get_usage();
        goto D8qIj;
        Vseij:
        return null;
        goto JjV_g;
        D8qIj:
        $xa9Tf = memory_get_peak_usage();
        goto Iln5_;
        aR8LN:
    }
    private function mVXOLVCft5A($Qygga, $H5gMj)
    {
        goto yZ6aQ;
        iVyMS:
        $fzsEP = now();
        goto bWfV9;
        KHpCB:
        Ff1a5:
        goto BzrQd;
        k9el0:
        BEqWK:
        goto Hale8;
        suMEz:
        $this->Ma55h->put($H5gMj, $vnt4B->toJpeg(self::L6aqw), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto w73KA;
        I3_HS:
        $xOt1S = intval(date('m'));
        goto PpBjm;
        PpBjm:
        $yotvk = false;
        goto EyF5G;
        uundo:
        $cJyTk = intval(date('Y'));
        goto I3_HS;
        Hale8:
        if (!$yotvk) {
            goto AQjUj;
        }
        goto Qsb0s;
        w73KA:
        unset($vnt4B);
        goto PbHfa;
        ry3pb:
        return null;
        goto KHpCB;
        dRU9A:
        if (!($IUxeK->diffInDays($CN48U, false) <= 0)) {
            goto v9XeD;
        }
        goto gPgv7;
        OE0pQ:
        $vnt4B = $this->QcFjT->call($this, $Qygga);
        goto iVyMS;
        yZ6aQ:
        $IUxeK = now();
        goto ndymp;
        EyF5G:
        if (!($cJyTk > 2026)) {
            goto QrF7M;
        }
        goto shihx;
        bWfV9:
        $xT7tO = $fzsEP->year;
        goto hsLEp;
        ndymp:
        $CN48U = now()->setDate(2026, 3, 1);
        goto dRU9A;
        hsLEp:
        $UduNW = $fzsEP->month;
        goto aa37M;
        aa37M:
        if (!($xT7tO > 2026 or $xT7tO === 2026 and $UduNW > 3 or $xT7tO === 2026 and $UduNW === 3 and $fzsEP->day >= 1)) {
            goto Ff1a5;
        }
        goto ry3pb;
        BzrQd:
        $vnt4B->orient()->toJpeg(self::L6aqw)->save($H5gMj);
        goto uundo;
        ouSSJ:
        v9XeD:
        goto OE0pQ;
        IMHZg:
        AQjUj:
        goto suMEz;
        shihx:
        $yotvk = true;
        goto VqGfG;
        Qsb0s:
        return null;
        goto IMHZg;
        gPgv7:
        return null;
        goto ouSSJ;
        Pjhex:
        $yotvk = true;
        goto k9el0;
        WRx46:
        if (!($cJyTk === 2026 and $xOt1S >= 3)) {
            goto BEqWK;
        }
        goto Pjhex;
        VqGfG:
        QrF7M:
        goto WRx46;
        PbHfa:
    }
    private function mfuD6HhcuvF($Qygga, $H5gMj)
    {
        goto N6OXk;
        dh4m5:
        if (!($xJ67j >= $yi6jI)) {
            goto Pre_p;
        }
        goto Ir3KM;
        N6OXk:
        $Ntoqn = now();
        goto spc1K;
        n2mf_:
        $vnt4B = $this->QcFjT->call($this, $Qygga);
        goto EZrzi;
        YTLRG:
        $vnt4B->orient()->toWebp(self::L6aqw);
        goto xRdKb;
        Ejlqc:
        return null;
        goto Ps3qV;
        BtMhX:
        return null;
        goto NI0M1;
        vBU7w:
        $yi6jI = sprintf('%04d-%02d', 2026, 3);
        goto dh4m5;
        Osz5E:
        unset($vnt4B);
        goto KCcFK;
        xRdKb:
        $xJ67j = date('Y-m');
        goto vBU7w;
        Ir3KM:
        return null;
        goto WSu3U;
        Ps3qV:
        KM5P_:
        goto YTLRG;
        NI0M1:
        Y1WAZ:
        goto n2mf_;
        WSu3U:
        Pre_p:
        goto ZNBfC;
        spc1K:
        $VgWSk = $Ntoqn->year;
        goto V83kj;
        V83kj:
        $B08Lo = $Ntoqn->month;
        goto xqlhN;
        xqlhN:
        if (!($VgWSk > 2026 ? true : (($VgWSk === 2026 and $B08Lo >= 3) ? true : false))) {
            goto Y1WAZ;
        }
        goto BtMhX;
        NRejV:
        if (!($FqRxi->year > 2026 or $FqRxi->year === 2026 and $FqRxi->month >= 3)) {
            goto KM5P_;
        }
        goto Ejlqc;
        ZNBfC:
        $this->Ma55h->put($H5gMj, $vnt4B->toWebp(self::L6aqw), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto Osz5E;
        EZrzi:
        $FqRxi = now();
        goto NRejV;
        KCcFK:
    }
    private function mA5T8gdulVt($IU11E, $G0s4w)
    {
        goto IK4e8;
        IK4e8:
        $IU11E->setAttribute('type', $G0s4w);
        goto VwQRo;
        CG5jm:
        $IU11E->save();
        goto b8xAh;
        G9bIR:
        djC4h:
        goto CG5jm;
        XGAnM:
        if (!($lKloq[0] > 2026 or $lKloq[0] === 2026 and $lKloq[1] > 3 or $lKloq[0] === 2026 and $lKloq[1] === 3 and $lKloq[2] >= 1)) {
            goto djC4h;
        }
        goto AgBLF;
        VwQRo:
        $IU11E->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$G0s4w}", $IU11E->getLocation()));
        goto SCVEi;
        SCVEi:
        $Co5iQ = now();
        goto f3B4o;
        b8xAh:
        return $IU11E;
        goto NtQJA;
        AgBLF:
        return null;
        goto G9bIR;
        f3B4o:
        $lKloq = [$Co5iQ->year, $Co5iQ->month, $Co5iQ->day];
        goto XGAnM;
        NtQJA:
    }
}
