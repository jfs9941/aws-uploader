<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class HI51OyVOVSVWY
{
    private $DyiCj;
    private $SRAbN;
    public function __construct(int $sDrx8, int $tc89y)
    {
        goto MuEGS;
        Ak9LQ:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto mABgK;
        MuEGS:
        if (!($sDrx8 <= 0)) {
            goto VWW0a;
        }
        goto Ak9LQ;
        CgITg:
        $this->DyiCj = $sDrx8;
        goto hMT5b;
        M7DO9:
        if (!($tc89y <= 0)) {
            goto ytHmS;
        }
        goto teOj0;
        teOj0:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto E5rxi;
        E5rxi:
        ytHmS:
        goto CgITg;
        hMT5b:
        $this->SRAbN = $tc89y;
        goto IroQB;
        mABgK:
        VWW0a:
        goto M7DO9;
        IroQB:
    }
    private static function mLtBV3XkAbJ($zLIL5, string $l79xT = 'floor') : int
    {
        goto ZJI3S;
        u46Zs:
        Ba8d1:
        goto iBY9t;
        iBY9t:
        iFiCZ:
        goto EBJUP;
        I0sHX:
        return $zLIL5;
        goto PY7Up;
        hZqGr:
        if (!(is_float($zLIL5) && $zLIL5 == floor($zLIL5) && (int) $zLIL5 % 2 === 0)) {
            goto YY1zd;
        }
        goto F1yO3;
        F1yO3:
        return (int) $zLIL5;
        goto WcU0Z;
        PY7Up:
        bStzG:
        goto hZqGr;
        nQd9f:
        switch (strtolower($l79xT)) {
            case 'ceil':
                return (int) (ceil($zLIL5 / 2) * 2);
            case 'round':
                return (int) (round($zLIL5 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($zLIL5 / 2) * 2);
        }
        goto u46Zs;
        ZJI3S:
        if (!(is_int($zLIL5) && $zLIL5 % 2 === 0)) {
            goto bStzG;
        }
        goto I0sHX;
        WcU0Z:
        YY1zd:
        goto nQd9f;
        EBJUP:
    }
    public function m2oW4LxRirL(string $G_O5m = 'floor') : array
    {
        goto w9io_;
        I8v0u:
        return ['width' => $SCSsl, 'height' => $W0p_Q];
        goto eWlou;
        kWe_R:
        if ($this->DyiCj >= $this->SRAbN) {
            goto r2j5X;
        }
        goto omOOZ;
        D6mh4:
        $l41NB = $SCSsl / $this->DyiCj;
        goto Pq_HW;
        pumlz:
        $SCSsl = 0;
        goto r3lX8;
        YNWNR:
        if (!($SCSsl < 2)) {
            goto yN0v9;
        }
        goto Qz2V9;
        LwoFF:
        r2j5X:
        goto D532z;
        gu4Gk:
        L12Zy:
        goto YNWNR;
        BytRd:
        $W0p_Q = 2;
        goto tmYm3;
        omOOZ:
        $SCSsl = $rFYvr;
        goto D6mh4;
        tmYm3:
        muSm0:
        goto I8v0u;
        b6bhI:
        $l41NB = $W0p_Q / $this->SRAbN;
        goto B44SJ;
        Jvzrd:
        if (!($W0p_Q < 2)) {
            goto muSm0;
        }
        goto BytRd;
        yncAI:
        goto L12Zy;
        goto LwoFF;
        gmPtY:
        yN0v9:
        goto Jvzrd;
        w9io_:
        $rFYvr = 1080;
        goto pumlz;
        VVpQy:
        $W0p_Q = self::mLtBV3XkAbJ(round($ySeDK), $G_O5m);
        goto yncAI;
        Qz2V9:
        $SCSsl = 2;
        goto gmPtY;
        D532z:
        $W0p_Q = $rFYvr;
        goto b6bhI;
        r3lX8:
        $W0p_Q = 0;
        goto kWe_R;
        B44SJ:
        $FzpPk = $this->DyiCj * $l41NB;
        goto FlRYB;
        Pq_HW:
        $ySeDK = $this->SRAbN * $l41NB;
        goto VVpQy;
        FlRYB:
        $SCSsl = self::mLtBV3XkAbJ(round($FzpPk), $G_O5m);
        goto gu4Gk;
        eWlou:
    }
}
