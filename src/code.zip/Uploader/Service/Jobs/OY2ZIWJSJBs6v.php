<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Service\Jobs\EcIjTx1IEEhqQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class OY2ZIWJSJBs6v implements WatermarkTextJobInterface
{
    private $wil31;
    private $hbjgl;
    private $l1YM3;
    private $ZN9hu;
    private $GUhIK;
    public function __construct($jwYYV, $Aye_M, $C2YXG, $kGo1c, $ggsAk)
    {
        goto goR5R;
        yk116:
        $this->l1YM3 = $ggsAk;
        goto qL08P;
        gDaIJ:
        $this->GUhIK = $kGo1c;
        goto yk116;
        BT7ie:
        $this->ZN9hu = $C2YXG;
        goto gDaIJ;
        qL08P:
        $this->hbjgl = $Aye_M;
        goto CNaEo;
        goR5R:
        $this->wil31 = $jwYYV;
        goto BT7ie;
        CNaEo:
    }
    public function putWatermark(string $uuHkQ, string $xt6u5) : void
    {
        goto g7htJ;
        F7BEL:
        Log::info("Adding watermark text to image", ['imageId' => $uuHkQ]);
        goto tH2Vt;
        g7htJ:
        $AzkxT = microtime(true);
        goto YLRfA;
        Y4O3n:
        try {
            goto UpLpL;
            PwqlA:
            $this->mi3xUWuLm7n($fFLHV, $xt6u5);
            goto KpjNj;
            dcG5y:
            EFIw9:
            goto i8l50;
            YwBbi:
            $fFLHV->orient();
            goto PwqlA;
            XDODF:
            if (chmod($dSgog, 0664)) {
                goto F8hNu;
            }
            goto YpaSw;
            LdXTF:
            return;
            goto dcG5y;
            YmDJu:
            unset($fFLHV);
            goto XDODF;
            UpLpL:
            $tCWWG = QFoN7Ibbm93if::findOrFail($uuHkQ);
            goto MMCVW;
            i8l50:
            $dSgog = $this->GUhIK->path($tCWWG->getLocation());
            goto OPuBp;
            KpjNj:
            $this->ZN9hu->put($dSgog, $fFLHV->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto YmDJu;
            y2Oz_:
            F8hNu:
            goto zkGnY;
            PINg9:
            Log::error("QFoN7Ibbm93if is not on local, might be deleted before put watermark", ['imageId' => $uuHkQ]);
            goto LdXTF;
            YpaSw:
            \Log::warning('Failed to set final permissions on image file: ' . $dSgog);
            goto wWSgg;
            wWSgg:
            throw new \Exception('Failed to set final permissions on image file: ' . $dSgog);
            goto y2Oz_;
            MMCVW:
            if ($this->GUhIK->exists($tCWWG->getLocation())) {
                goto EFIw9;
            }
            goto PINg9;
            OPuBp:
            $fFLHV = $this->wil31->call($this, $dSgog);
            goto YwBbi;
            zkGnY:
        } catch (\Throwable $b2flV) {
            goto JE21s;
            YZ4sl:
            Log::info("QFoN7Ibbm93if has been deleted, discard it", ['imageId' => $uuHkQ]);
            goto elcSs;
            JE21s:
            if (!$b2flV instanceof ModelNotFoundException) {
                goto mBmFy;
            }
            goto YZ4sl;
            Weh_4:
            mBmFy:
            goto TratB;
            elcSs:
            return;
            goto Weh_4;
            TratB:
            Log::error("QFoN7Ibbm93if is not readable", ['imageId' => $uuHkQ, 'error' => $b2flV->getMessage()]);
            goto ca_35;
            ca_35:
        } finally {
            $aNu_H = microtime(true);
            $RzZdv = memory_get_usage();
            $cUIGa = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $uuHkQ, 'execution_time_sec' => $aNu_H - $AzkxT, 'memory_usage_mb' => ($RzZdv - $f24Pb) / 1024 / 1024, 'peak_memory_usage_mb' => ($cUIGa - $QzVyt) / 1024 / 1024]);
        }
        goto evvKQ;
        tH2Vt:
        ini_set('memory_limit', '-1');
        goto Y4O3n;
        YLRfA:
        $f24Pb = memory_get_usage();
        goto HG6S1;
        HG6S1:
        $QzVyt = memory_get_peak_usage();
        goto F7BEL;
        evvKQ:
    }
    private function mi3xUWuLm7n($fFLHV, $xt6u5) : void
    {
        goto EmCwB;
        GUnUr:
        $this->GUhIK->put($ti0Iu, $this->ZN9hu->get($ti0Iu));
        goto yQyqr;
        LrZoj:
        $ti0Iu = $AbWam->mxU7tTNgJ1H($bvCsS, $WEPGl, $xt6u5, true);
        goto GUnUr;
        C28w1:
        $AbWam = new EcIjTx1IEEhqQ($this->hbjgl, $this->l1YM3, $this->ZN9hu, $this->GUhIK);
        goto LrZoj;
        yQyqr:
        $m_LFd = $this->wil31->call($this, $this->GUhIK->path($ti0Iu));
        goto Rx2AP;
        zXR35:
        $WEPGl = $fFLHV->height();
        goto C28w1;
        EmCwB:
        $bvCsS = $fFLHV->width();
        goto zXR35;
        Rx2AP:
        $fFLHV->place($m_LFd, 'top-left', 0, 0, 30);
        goto ZIJKG;
        ZIJKG:
    }
}
