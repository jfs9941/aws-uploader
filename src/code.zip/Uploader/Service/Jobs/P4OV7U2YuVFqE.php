<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
class P4OV7U2YuVFqE implements BlurJobInterface
{
    const IMf0z = 15;
    const tqPMm = 500;
    const NMW3N = 500;
    private $TMqxn;
    private $IRlXr;
    private $foEoP;
    public function __construct($xskW6, $JGvdR, $VGndK)
    {
        goto aRtAk;
        aRtAk:
        $this->foEoP = $VGndK;
        goto foNfa;
        foNfa:
        $this->IRlXr = $JGvdR;
        goto IRluH;
        IRluH:
        $this->TMqxn = $xskW6;
        goto HiNjw;
        HiNjw:
    }
    public function blur(string $R7IrL) : void
    {
        goto u_6u9;
        osOLf:
        $Xxl6q->save($gFaXo);
        goto jBYx2;
        OYH43:
        $gFaXo = $this->foEoP->path($s2oYj);
        goto osOLf;
        LlUhr:
        ini_set('memory_limit', '-1');
        goto pzETf;
        mB3BK:
        $this->foEoP->put($jaCUa->filename, $ZHZfB);
        goto gz3kZ;
        n7_Ca:
        $lN9cc = $Xxl6q->width() / $Xxl6q->height();
        goto zHyTe;
        pzETf:
        if (!($jaCUa->P462y == R278OrMF6HCNB::S3 && !$this->foEoP->exists($jaCUa->filename))) {
            goto C4P6P;
        }
        goto fe24Z;
        TG2QU:
        $jaCUa->update(['preview' => $s2oYj]);
        goto zfAsX;
        S3paW:
        \Log::warning('Failed to set final permissions on image file: ' . $gFaXo);
        goto KZhIq;
        slH5w:
        aerEK:
        goto TG2QU;
        tbs9u:
        $s2oYj = $this->mn5o9IOn4V0($jaCUa);
        goto OYH43;
        zHyTe:
        $Xxl6q->resize(self::tqPMm, self::NMW3N / $lN9cc);
        goto TcBYJ;
        uo0Mt:
        if (chmod($gFaXo, 0664)) {
            goto aerEK;
        }
        goto S3paW;
        KZhIq:
        throw new \Exception('Failed to set final permissions on image file: ' . $gFaXo);
        goto slH5w;
        jBYx2:
        $Xxl6q->destroy();
        goto uo0Mt;
        DU8_g:
        $Xxl6q = $this->TMqxn->call($this, $this->foEoP->path($jaCUa->getLocation()));
        goto n7_Ca;
        gz3kZ:
        C4P6P:
        goto DU8_g;
        TcBYJ:
        $Xxl6q->blur(self::IMf0z);
        goto tbs9u;
        fe24Z:
        $ZHZfB = $this->IRlXr->get($jaCUa->filename);
        goto mB3BK;
        u_6u9:
        $jaCUa = OcbNsXl9lpteB::findOrFail($R7IrL);
        goto LlUhr;
        zfAsX:
    }
    private function mn5o9IOn4V0($YTWPZ) : string
    {
        goto q3XSB;
        Cf1mB:
        k_usN:
        goto NjT12;
        q3XSB:
        $XkdbN = $YTWPZ->getLocation();
        goto pnt8A;
        ynpSv:
        $this->foEoP->makeDirectory($gdRmc, 0755, true);
        goto Cf1mB;
        tzfcy:
        if ($this->foEoP->exists($gdRmc)) {
            goto k_usN;
        }
        goto ynpSv;
        pnt8A:
        $gdRmc = dirname($XkdbN) . '/preview/';
        goto tzfcy;
        NjT12:
        return $gdRmc . $YTWPZ->getFilename() . '.jpg';
        goto FdDbw;
        FdDbw:
    }
}
