<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class ZaIKd6NxPOyf0 implements GenerateThumbnailJobInterface
{
    const vvzG4 = 150;
    const Ott5c = 150;
    private $GqFb6;
    private $S0euz;
    private $qh_2h;
    public function __construct($WV89v, $t9rFg, $Jno5S)
    {
        goto lwQgk;
        khYY_:
        $this->S0euz = $t9rFg;
        goto fhVRC;
        fhVRC:
        $this->qh_2h = $Jno5S;
        goto USEe7;
        lwQgk:
        $this->GqFb6 = $WV89v;
        goto khYY_;
        USEe7:
    }
    public function generate(string $aK0gt)
    {
        goto B8AB1;
        B8AB1:
        Log::info("Generating thumbnail", ['imageId' => $aK0gt]);
        goto R7rmH;
        R7rmH:
        ini_set('memory_limit', '-1');
        goto W0VUB;
        W0VUB:
        try {
            goto ohs7y;
            bzdV6:
            $XyIsI->orient()->resize(150, 150);
            goto K4eM7;
            DMyrX:
            $qKtXa = MpPzMcfcRTISZ::findOrFail($aK0gt);
            goto KBMId;
            g6N2m:
            $vADU7 = $this->qh_2h->put($HyAAV, $XyIsI->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto DRf9u;
            tbStp:
            if (!($vADU7 !== false)) {
                goto uZK6d;
            }
            goto OvU2F;
            K4eM7:
            $HyAAV = $this->mG102AKvrVC($qKtXa);
            goto g6N2m;
            KBMId:
            $XyIsI = $this->GqFb6->call($this, $Ape3_->path($qKtXa->getLocation()));
            goto bzdV6;
            RJiNJ:
            uZK6d:
            goto eLw2O;
            ohs7y:
            $Ape3_ = $this->S0euz;
            goto DMyrX;
            DRf9u:
            unset($XyIsI);
            goto tbStp;
            OvU2F:
            $qKtXa->update(['thumbnail' => $HyAAV, 'status' => IOEDyer18cpSA::THUMBNAIL_PROCESSED]);
            goto RJiNJ;
            eLw2O:
        } catch (ModelNotFoundException $t0AeI) {
            Log::info("MpPzMcfcRTISZ has been deleted, discard it", ['imageId' => $aK0gt]);
            return;
        } catch (\Exception $t0AeI) {
            Log::error("Failed to generate thumbnail", ['imageId' => $aK0gt, 'error' => $t0AeI->getMessage()]);
        }
        goto XbR_g;
        XbR_g:
    }
    private function mG102AKvrVC(OavRsjNQCayKr $qKtXa) : string
    {
        goto e4TFU;
        BMDpV:
        $ODUZC = dirname($HyAAV);
        goto Df3As;
        Df3As:
        $EmKxP = $ODUZC . '/' . self::vvzG4 . 'X' . self::Ott5c;
        goto zjeKF;
        e4TFU:
        $HyAAV = $qKtXa->getLocation();
        goto BMDpV;
        zjeKF:
        return $EmKxP . '/' . $qKtXa->getFilename() . '.jpg';
        goto s_cV7;
        s_cV7:
    }
}
