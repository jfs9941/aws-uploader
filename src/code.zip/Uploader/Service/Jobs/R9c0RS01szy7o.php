<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Service\Jobs\SBKmhirduBuxQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class R9c0RS01szy7o implements WatermarkTextJobInterface
{
    private $Q1wpU;
    private $kYQtS;
    private $XdOe7;
    private $DksH2;
    private $iAAqk;
    public function __construct($kuI8f, $vWUsi, $l4Drs, $YNIuu, $YqLJy)
    {
        goto EicCi;
        Iq1_3:
        $this->kYQtS = $vWUsi;
        goto Vk_w3;
        sz6xT:
        $this->XdOe7 = $YqLJy;
        goto Iq1_3;
        o9Rjx:
        $this->DksH2 = $l4Drs;
        goto GXClN;
        EicCi:
        $this->Q1wpU = $kuI8f;
        goto o9Rjx;
        GXClN:
        $this->iAAqk = $YNIuu;
        goto sz6xT;
        Vk_w3:
    }
    public function putWatermark(string $EmnXX, string $nm3TE) : void
    {
        goto dFmZA;
        dFmZA:
        $CH3jk = microtime(true);
        goto DKKs2;
        gd52R:
        Log::info("Adding watermark text to image", ['imageId' => $EmnXX]);
        goto ERIbj;
        DKKs2:
        $sebDh = memory_get_usage();
        goto IklLX;
        frk82:
        try {
            goto ceqnY;
            KIFO5:
            $this->DksH2->put($cJV8L, $pec9t->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto l08pt;
            l3RAW:
            $this->mttHBp5Y3kW($pec9t, $nm3TE);
            goto KIFO5;
            W6UXo:
            $pec9t = $this->Q1wpU->call($this, $cJV8L);
            goto tl3kF;
            sqPt6:
            Log::error("Q48IcpSr3UpAT is not on local, might be deleted before put watermark", ['imageId' => $EmnXX]);
            goto kORVg;
            OW5Mj:
            if ($this->iAAqk->exists($AvW7Y->getLocation())) {
                goto s3ynf;
            }
            goto sqPt6;
            WVldx:
            if (chmod($cJV8L, 0664)) {
                goto Bx8xO;
            }
            goto vRQZ8;
            ceqnY:
            $AvW7Y = Q48IcpSr3UpAT::findOrFail($EmnXX);
            goto OW5Mj;
            Wf_bd:
            throw new \Exception('Failed to set final permissions on image file: ' . $cJV8L);
            goto yXcCK;
            tl3kF:
            $pec9t->orient();
            goto l3RAW;
            GcML6:
            s3ynf:
            goto rdNxp;
            yXcCK:
            Bx8xO:
            goto MKnos;
            rdNxp:
            $cJV8L = $this->iAAqk->path($AvW7Y->getLocation());
            goto W6UXo;
            vRQZ8:
            \Log::warning('Failed to set final permissions on image file: ' . $cJV8L);
            goto Wf_bd;
            kORVg:
            return;
            goto GcML6;
            l08pt:
            unset($pec9t);
            goto WVldx;
            MKnos:
        } catch (\Throwable $GQlcz) {
            goto E79Hl;
            AZZXB:
            return;
            goto xwxi3;
            bYk2r:
            Log::error("Q48IcpSr3UpAT is not readable", ['imageId' => $EmnXX, 'error' => $GQlcz->getMessage()]);
            goto WSP23;
            r9o9P:
            Log::info("Q48IcpSr3UpAT has been deleted, discard it", ['imageId' => $EmnXX]);
            goto AZZXB;
            E79Hl:
            if (!$GQlcz instanceof ModelNotFoundException) {
                goto rEbqz;
            }
            goto r9o9P;
            xwxi3:
            rEbqz:
            goto bYk2r;
            WSP23:
        } finally {
            $ukbV6 = microtime(true);
            $A4_rm = memory_get_usage();
            $PEAvN = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $EmnXX, 'execution_time_sec' => $ukbV6 - $CH3jk, 'memory_usage_mb' => ($A4_rm - $sebDh) / 1024 / 1024, 'peak_memory_usage_mb' => ($PEAvN - $DGIY2) / 1024 / 1024]);
        }
        goto c3fCT;
        ERIbj:
        ini_set('memory_limit', '-1');
        goto frk82;
        IklLX:
        $DGIY2 = memory_get_peak_usage();
        goto gd52R;
        c3fCT:
    }
    private function mttHBp5Y3kW($pec9t, $nm3TE) : void
    {
        goto wF2Ro;
        ErU_h:
        $pec9t->place($S3ETt, 'top-left', 0, 0, 30);
        goto LZr7_;
        vkCcT:
        $this->iAAqk->put($XGlEF, $this->DksH2->get($XGlEF));
        goto rd5rj;
        rQGu0:
        $cklgV = new SBKmhirduBuxQ($this->kYQtS, $this->XdOe7, $this->DksH2, $this->iAAqk);
        goto bEgeC;
        rd5rj:
        $S3ETt = $this->Q1wpU->call($this, $this->iAAqk->path($XGlEF));
        goto ErU_h;
        dmCNs:
        $ldQdP = $pec9t->height();
        goto rQGu0;
        wF2Ro:
        $GPsTK = $pec9t->width();
        goto dmCNs;
        bEgeC:
        $XGlEF = $cklgV->m3ZG46sP9md($GPsTK, $ldQdP, $nm3TE, true);
        goto vkCcT;
        LZr7_:
    }
}
