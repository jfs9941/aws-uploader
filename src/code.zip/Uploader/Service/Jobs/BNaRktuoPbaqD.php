<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class BNaRktuoPbaqD implements CompressJobInterface
{
    const C7y1p = 60;
    private $PAMAL;
    private $Celh5;
    private $L7mR6;
    public function __construct($VX8yi, $clScT, $ZPeN2)
    {
        goto sauQH;
        xxWEw:
        $this->Celh5 = $clScT;
        goto yMHe3;
        sauQH:
        $this->PAMAL = $VX8yi;
        goto IsWv2;
        IsWv2:
        $this->L7mR6 = $ZPeN2;
        goto xxWEw;
        yMHe3:
    }
    public function compress(string $SEOXv)
    {
        goto U4lUY;
        JqDEi:
        Log::info("Compress image", ['imageId' => $SEOXv]);
        goto SsAo0;
        oO9kH:
        $BuLko = memory_get_usage();
        goto J59H6;
        SsAo0:
        try {
            goto yXxYv;
            ZHKul:
            $HGg1Q = $this->Celh5->path($dIrHq->getLocation());
            goto ttGWu;
            ttGWu:
            if (!(strtolower($dIrHq->getExtension()) === 'png' || strtolower($dIrHq->getExtension()) === 'heic')) {
                goto qSP_6;
            }
            goto D42TD;
            yXxYv:
            $dIrHq = FmmY71eXk0D8U::findOrFail($SEOXv);
            goto ZHKul;
            mKX92:
            try {
                goto CpWAP;
                CpWAP:
                $ivomn = $this->Celh5->path(str_replace('.jpg', '.webp', $dIrHq->getLocation()));
                goto Rk3pK;
                Rk3pK:
                $this->mnMbicDjjBx($HGg1Q, $ivomn);
                goto eQEHc;
                eQEHc:
                $this->mboU5Q2gzWN($dIrHq, 'webp');
                goto KDSvS;
                KDSvS:
            } catch (\Exception $HhXZM) {
                goto nS9HU;
                JAL5T:
                $this->mslCwage4JQ($HGg1Q, $ivomn);
                goto oAda4;
                ha4fy:
                $ivomn = $this->Celh5->path($dIrHq->getLocation());
                goto JAL5T;
                nS9HU:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $SEOXv, 'error' => $HhXZM->getMessage()]);
                goto ha4fy;
                oAda4:
            }
            goto jSBxU;
            eUYh8:
            qSP_6:
            goto mKX92;
            D42TD:
            $dIrHq = $this->mboU5Q2gzWN($dIrHq, 'jpg');
            goto eUYh8;
            jSBxU:
        } catch (\Throwable $HhXZM) {
            goto x3pkF;
            IsvJM:
            return;
            goto zdzlJ;
            BnDgZ:
            Log::error("Failed to compress image", ['imageId' => $SEOXv, 'error' => $HhXZM->getMessage()]);
            goto LjJO4;
            zdzlJ:
            yd7fq:
            goto BnDgZ;
            Zdw_5:
            Log::info("FmmY71eXk0D8U has been deleted, discard it", ['imageId' => $SEOXv]);
            goto IsvJM;
            x3pkF:
            if (!$HhXZM instanceof ModelNotFoundException) {
                goto yd7fq;
            }
            goto Zdw_5;
            LjJO4:
        } finally {
            $vmfo7 = microtime(true);
            $icHkX = memory_get_usage();
            $W9dV9 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $SEOXv, 'execution_time_sec' => $vmfo7 - $NR4hg, 'memory_usage_mb' => ($icHkX - $BuLko) / 1024 / 1024, 'peak_memory_usage_mb' => ($W9dV9 - $DAezb) / 1024 / 1024]);
        }
        goto M4CzR;
        U4lUY:
        $NR4hg = microtime(true);
        goto oO9kH;
        J59H6:
        $DAezb = memory_get_peak_usage();
        goto JqDEi;
        M4CzR:
    }
    private function mslCwage4JQ($HGg1Q, $ivomn)
    {
        goto DXhfD;
        DXhfD:
        $jHjzE = $this->PAMAL->call($this, $HGg1Q);
        goto U73Q1;
        U73Q1:
        $jHjzE->orient()->toJpeg(self::C7y1p)->save($ivomn);
        goto gtpfb;
        jIIG3:
        unset($jHjzE);
        goto TMYKT;
        gtpfb:
        $this->L7mR6->put($ivomn, $jHjzE->toJpeg(self::C7y1p), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto jIIG3;
        TMYKT:
    }
    private function mnMbicDjjBx($HGg1Q, $ivomn)
    {
        goto PVz0O;
        GchXa:
        unset($jHjzE);
        goto iv099;
        embE2:
        $jHjzE->orient()->toWebp(self::C7y1p);
        goto gUk2_;
        PVz0O:
        $jHjzE = $this->PAMAL->call($this, $HGg1Q);
        goto embE2;
        gUk2_:
        $this->L7mR6->put($ivomn, $jHjzE->toJpeg(self::C7y1p), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto GchXa;
        iv099:
    }
    private function mboU5Q2gzWN($dIrHq, $DkCVl)
    {
        goto Sw289;
        j0M8V:
        $dIrHq->save();
        goto iPM7a;
        SVRQf:
        $dIrHq->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$DkCVl}", $dIrHq->getLocation()));
        goto j0M8V;
        Sw289:
        $dIrHq->setAttribute('type', $DkCVl);
        goto SVRQf;
        iPM7a:
        return $dIrHq;
        goto ZwIZv;
        ZwIZv:
    }
}
