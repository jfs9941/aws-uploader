<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class JfBe5Y66zhkIN implements CompressJobInterface
{
    const uNThq = 60;
    private $kAoN_;
    private $cGz6K;
    private $qqa8Q;
    public function __construct($QJMxa, $DAY12, $mv1tg)
    {
        goto UYy5w;
        f4TSE:
        $this->qqa8Q = $mv1tg;
        goto UiRZ3;
        UiRZ3:
        $this->cGz6K = $DAY12;
        goto B0eNp;
        UYy5w:
        $this->kAoN_ = $QJMxa;
        goto f4TSE;
        B0eNp:
    }
    public function compress(string $tu00C)
    {
        goto MR2Hh;
        XDehs:
        try {
            goto gXQnt;
            NPBCQ:
            if (!(strtolower($h4i8i->getExtension()) === 'png' || strtolower($h4i8i->getExtension()) === 'heic')) {
                goto LNtsq;
            }
            goto kpr_4;
            kpr_4:
            $h4i8i = $this->mHMbF7Hk7pL($h4i8i, 'jpg');
            goto EDYj1;
            gXQnt:
            $h4i8i = VPGaYsuFJzbQ0::findOrFail($tu00C);
            goto nFl5v;
            PvQnU:
            try {
                goto lb3Py;
                lb3Py:
                $VSyiD = $this->cGz6K->path(str_replace('.jpg', '.webp', $h4i8i->getLocation()));
                goto BUg79;
                nytt0:
                $this->mHMbF7Hk7pL($h4i8i, 'webp');
                goto UmzbF;
                BUg79:
                $this->m0sKNL3N3KH($AGOm4, $VSyiD);
                goto nytt0;
                UmzbF:
            } catch (\Exception $hBzBz) {
                goto i9Ebt;
                i9Ebt:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $tu00C, 'error' => $hBzBz->getMessage()]);
                goto en98r;
                en98r:
                $VSyiD = $this->cGz6K->path($h4i8i->getLocation());
                goto UVl5v;
                UVl5v:
                $this->mgoyJwaW8Hw($AGOm4, $VSyiD);
                goto QZ87Y;
                QZ87Y:
            }
            goto wdPfX;
            EDYj1:
            LNtsq:
            goto PvQnU;
            nFl5v:
            $AGOm4 = $this->cGz6K->path($h4i8i->getLocation());
            goto NPBCQ;
            wdPfX:
        } catch (\Throwable $hBzBz) {
            goto hhq7n;
            g2hH2:
            Log::info("VPGaYsuFJzbQ0 has been deleted, discard it", ['imageId' => $tu00C]);
            goto ecx1w;
            ErN9X:
            eYo4w:
            goto VmH5d;
            hhq7n:
            if (!$hBzBz instanceof ModelNotFoundException) {
                goto eYo4w;
            }
            goto g2hH2;
            VmH5d:
            Log::error("Failed to compress image", ['imageId' => $tu00C, 'error' => $hBzBz->getMessage()]);
            goto RLHos;
            ecx1w:
            return;
            goto ErN9X;
            RLHos:
        } finally {
            $Taw_q = microtime(true);
            $rjavZ = memory_get_usage();
            $Szg_0 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $tu00C, 'execution_time_sec' => $Taw_q - $vLJkf, 'memory_usage_mb' => ($rjavZ - $SBeWo) / 1024 / 1024, 'peak_memory_usage_mb' => ($Szg_0 - $wsJtd) / 1024 / 1024]);
        }
        goto OYEU_;
        MR2Hh:
        $vLJkf = microtime(true);
        goto ufC3I;
        sR6I_:
        $wsJtd = memory_get_peak_usage();
        goto QZGZq;
        ufC3I:
        $SBeWo = memory_get_usage();
        goto sR6I_;
        QZGZq:
        Log::info("Compress image", ['imageId' => $tu00C]);
        goto XDehs;
        OYEU_:
    }
    private function mgoyJwaW8Hw($AGOm4, $VSyiD)
    {
        goto RCzgg;
        zOA3e:
        $this->qqa8Q->put($VSyiD, $V3vQz->toJpeg(self::uNThq), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto AAz_D;
        Jw1us:
        $V3vQz->orient()->toJpeg(self::uNThq)->save($VSyiD);
        goto zOA3e;
        AAz_D:
        unset($V3vQz);
        goto vcNTr;
        RCzgg:
        $V3vQz = $this->kAoN_->call($this, $AGOm4);
        goto Jw1us;
        vcNTr:
    }
    private function m0sKNL3N3KH($AGOm4, $VSyiD)
    {
        goto f4ex9;
        E2lYn:
        $V3vQz->orient()->toWebp(self::uNThq);
        goto Fi0Qv;
        Fi0Qv:
        $this->qqa8Q->put($VSyiD, $V3vQz->toJpeg(self::uNThq), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto JBQ_P;
        JBQ_P:
        unset($V3vQz);
        goto YqqyV;
        f4ex9:
        $V3vQz = $this->kAoN_->call($this, $AGOm4);
        goto E2lYn;
        YqqyV:
    }
    private function mHMbF7Hk7pL($h4i8i, $B7MU4)
    {
        goto pThCm;
        uLqQI:
        $h4i8i->save();
        goto UqDPv;
        vbzLX:
        $h4i8i->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$B7MU4}", $h4i8i->getLocation()));
        goto uLqQI;
        UqDPv:
        return $h4i8i;
        goto n1a7f;
        pThCm:
        $h4i8i->setAttribute('type', $B7MU4);
        goto vbzLX;
        n1a7f:
    }
}
