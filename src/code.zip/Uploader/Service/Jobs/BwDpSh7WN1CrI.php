<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class BwDpSh7WN1CrI implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $SEOXv) : void
    {
        goto cfo6R;
        cfo6R:
        $IrxWj = IvT3V5jT5KEaA::findOrFail($SEOXv);
        goto YQ0R1;
        YQ0R1:
        if ($IrxWj->width() > 0 && $IrxWj->height() > 0) {
            goto ap_Hn;
        }
        goto cEJr_;
        cEJr_:
        $this->mHqWvEITuqi($IrxWj);
        goto lcbpl;
        lcbpl:
        ap_Hn:
        goto qopIr;
        qopIr:
    }
    private function mHqWvEITuqi(IvT3V5jT5KEaA $tL_UH) : void
    {
        goto FibjR;
        bTirw:
        $tzY18 = FFMpeg::fromDisk($hhZ0v['path'])->open($tL_UH->getAttribute('filename'));
        goto beT9i;
        FibjR:
        $hhZ0v = $tL_UH->getView();
        goto bTirw;
        ATvw7:
        $tL_UH->update(['duration' => $tzY18->getDurationInSeconds(), 'resolution' => $QE9za->getWidth() . 'x' . $QE9za->getHeight(), 'fps' => $D3y80->get('r_frame_rate') ?? 30]);
        goto Q2lNt;
        beT9i:
        $D3y80 = $tzY18->getVideoStream();
        goto ZyN32;
        ZyN32:
        $QE9za = $D3y80->getDimensions();
        goto ATvw7;
        Q2lNt:
    }
}
