<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Illuminate\Support\Facades\Log;
class Kwx1S7WayMfoX implements DownloadToLocalJobInterface
{
    private $SxfKN;
    private $GmmTj;
    public function __construct($DPWG1, $MYo5D)
    {
        $this->SxfKN = $DPWG1;
        $this->GmmTj = $MYo5D;
    }
    public function download(string $GMwD5) : void
    {
        goto eBWmm;
        eBWmm:
        $RB3Ub = C6ftQJKUZRJIp::findOrFail($GMwD5);
        goto oNcyT;
        OAHwd:
        onagk:
        goto COqF1;
        mMibf:
        if (!$this->GmmTj->exists($RB3Ub->getLocation())) {
            goto onagk;
        }
        goto HliRL;
        COqF1:
        $this->GmmTj->put($RB3Ub->getLocation(), $this->SxfKN->get($RB3Ub->getLocation()));
        goto YGtfw;
        oNcyT:
        Log::info("Start download file to local", ['fileId' => $GMwD5, 'filename' => $RB3Ub->getLocation()]);
        goto mMibf;
        HliRL:
        return;
        goto OAHwd;
        YGtfw:
    }
}
