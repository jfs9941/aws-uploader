<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
class TmlmOlhnYgfo5 implements BlurJobInterface
{
    const DOSpu = 15;
    const q30Hb = 500;
    const D4nFA = 500;
    private $gVUAC;
    private $cC_4U;
    private $jhnu6;
    public function __construct($pe6Kp, $s1UdZ, $vWOwZ)
    {
        goto XbSyB;
        CY9L4:
        $this->cC_4U = $s1UdZ;
        goto rTIfp;
        rTIfp:
        $this->gVUAC = $pe6Kp;
        goto M0Wcm;
        XbSyB:
        $this->jhnu6 = $vWOwZ;
        goto CY9L4;
        M0Wcm:
    }
    public function blur(string $q8q1b) : void
    {
        goto Bs4hO;
        PkSHK:
        $jxgar = $this->mbczg5sL9TG($N8QeM);
        goto Vlnz8;
        D4829:
        $this->jhnu6->put($N8QeM->filename, $kwaUC);
        goto oBVQN;
        t40pX:
        $kwaUC = $this->cC_4U->get($N8QeM->filename);
        goto D4829;
        PklV0:
        if (chmod($wa8c_, 0664)) {
            goto UnnhZ;
        }
        goto ar6zp;
        NUcg2:
        ini_set('memory_limit', '-1');
        goto ovO6N;
        ovO6N:
        if (!($N8QeM->driver == Y9OZ7qWyGdhw2::S3 && !$this->jhnu6->exists($N8QeM->filename))) {
            goto xujBe;
        }
        goto t40pX;
        iB151:
        $PdjKE = $this->gVUAC->call($this, $this->jhnu6->path($N8QeM->getLocation()));
        goto QRNB4;
        oBVQN:
        xujBe:
        goto iB151;
        Bs4hO:
        $N8QeM = JOauoJMkgHWbh::findOrFail($q8q1b);
        goto NUcg2;
        wxxPX:
        $PdjKE->blur(self::DOSpu);
        goto PkSHK;
        BA5m5:
        $N8QeM->update(['preview' => $jxgar]);
        goto I9a2H;
        Vlnz8:
        $wa8c_ = $this->cC_4U->put($jxgar, $PdjKE->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto LZlMu;
        LZlMu:
        unset($PdjKE);
        goto PklV0;
        KWXpB:
        UnnhZ:
        goto BA5m5;
        ar6zp:
        \Log::warning('Failed to set final permissions on image file: ' . $wa8c_);
        goto dxyBj;
        QRNB4:
        $NTbDZ = $PdjKE->width() / $PdjKE->height();
        goto thjcy;
        dxyBj:
        throw new \Exception('Failed to set final permissions on image file: ' . $wa8c_);
        goto KWXpB;
        thjcy:
        $PdjKE->resize(self::q30Hb, self::D4nFA / $NTbDZ);
        goto wxxPX;
        I9a2H:
    }
    private function mbczg5sL9TG($RJr11) : string
    {
        goto ZLnQA;
        Xntbc:
        $IZRUn = dirname($K_YMm) . '/preview/';
        goto UdGJU;
        zFV7r:
        DQcpP:
        goto Pawwk;
        WswdZ:
        $this->jhnu6->makeDirectory($IZRUn, 0755, true);
        goto zFV7r;
        UdGJU:
        if ($this->jhnu6->exists($IZRUn)) {
            goto DQcpP;
        }
        goto WswdZ;
        Pawwk:
        return $IZRUn . $RJr11->getFilename() . '.jpg';
        goto UeWdM;
        ZLnQA:
        $K_YMm = $RJr11->getLocation();
        goto Xntbc;
        UeWdM:
    }
}
