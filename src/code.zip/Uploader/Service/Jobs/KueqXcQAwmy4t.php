<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
class KueqXcQAwmy4t implements BlurJobInterface
{
    const HWajA = 15;
    const h2WRV = 500;
    const UJSmU = 500;
    private $Q1wpU;
    private $DksH2;
    private $JFHzD;
    public function __construct($kuI8f, $l4Drs, $NVuHg)
    {
        goto VCC0A;
        DuFsx:
        $this->Q1wpU = $kuI8f;
        goto TaPTo;
        rrKKB:
        $this->DksH2 = $l4Drs;
        goto DuFsx;
        VCC0A:
        $this->JFHzD = $NVuHg;
        goto rrKKB;
        TaPTo:
    }
    public function blur(string $EmnXX) : void
    {
        goto ZCXZv;
        y299S:
        $AvW7Y = $this->Q1wpU->call($this, $this->JFHzD->path($uvyDL->getLocation()));
        goto MWqg3;
        HbMmp:
        if (!($uvyDL->driver == Tfi7lQDVWUJD9::S3 && !$this->JFHzD->exists($uvyDL->filename))) {
            goto r1pgl;
        }
        goto HMliC;
        utmnw:
        $evaVp = $this->DksH2->put($BcKg9, $AvW7Y->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto zgLTY;
        oJfRa:
        r1pgl:
        goto y299S;
        ORUsQ:
        throw new \Exception('Failed to set final permissions on image file: ' . $evaVp);
        goto vdlBY;
        vdlBY:
        FCIi0:
        goto GmAka;
        ciZUl:
        \Log::warning('Failed to set final permissions on image file: ' . $evaVp);
        goto ORUsQ;
        GmAka:
        $uvyDL->update(['preview' => $BcKg9]);
        goto EblNU;
        zgLTY:
        unset($AvW7Y);
        goto bd8br;
        CHuUi:
        $this->JFHzD->put($uvyDL->filename, $OHpY5);
        goto oJfRa;
        bPtVg:
        $BcKg9 = $this->ma6eQJHB5RK($uvyDL);
        goto utmnw;
        ODdam:
        ini_set('memory_limit', '-1');
        goto HbMmp;
        MWqg3:
        $T6coX = $AvW7Y->width() / $AvW7Y->height();
        goto mPWvL;
        ZCXZv:
        $uvyDL = Q48IcpSr3UpAT::findOrFail($EmnXX);
        goto ODdam;
        HMliC:
        $OHpY5 = $this->DksH2->get($uvyDL->filename);
        goto CHuUi;
        bd8br:
        if (chmod($evaVp, 0664)) {
            goto FCIi0;
        }
        goto ciZUl;
        xkaqv:
        $AvW7Y->blur(self::HWajA);
        goto bPtVg;
        mPWvL:
        $AvW7Y->resize(self::h2WRV, self::UJSmU / $T6coX);
        goto xkaqv;
        EblNU:
    }
    private function ma6eQJHB5RK($JMwlI) : string
    {
        goto OoOui;
        sOnY6:
        return $kwulB . $JMwlI->getFilename() . '.jpg';
        goto Sswqe;
        kGmOu:
        if ($this->JFHzD->exists($kwulB)) {
            goto RtxCs;
        }
        goto zErMC;
        OoOui:
        $cJV8L = $JMwlI->getLocation();
        goto jx2e6;
        zErMC:
        $this->JFHzD->makeDirectory($kwulB, 0755, true);
        goto xASln;
        jx2e6:
        $kwulB = dirname($cJV8L) . '/preview/';
        goto kGmOu;
        xASln:
        RtxCs:
        goto sOnY6;
        Sswqe:
    }
}
