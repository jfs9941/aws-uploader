<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Encoder\CoZlTEDusQdM7;
use Jfs\Uploader\Encoder\Ntz5hwm7VzzwJ;
use Jfs\Uploader\Encoder\Suk3MOIJcOQzt;
use Jfs\Uploader\Encoder\PHA10ASHyxJnC;
use Jfs\Uploader\Encoder\Evs9C2DhMDeMD;
use Jfs\Uploader\Encoder\NV3aOYfIycxy3;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Jfs\Uploader\Service\Jobs\GvnUWx3jUfPlo;
use Jfs\Uploader\Service\Jobs\MwudJaX1iKlH8;
use Jfs\Uploader\Service\CbfzS01NR7tQ9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class HliNbM0W1zC88 implements MediaEncodeJobInterface
{
    private $p_blM;
    private $BX0zD;
    private $m2kWg;
    private $z5gsb;
    private $o2VY1;
    public function __construct(string $b7Jn7, $MKJ1D, $Npup8, $ydoZC, $mjAYO)
    {
        goto PnkHa;
        raM3e:
        $this->BX0zD = $MKJ1D;
        goto eQgAN;
        eQgAN:
        $this->m2kWg = $Npup8;
        goto Ael8C;
        PnkHa:
        $this->p_blM = $b7Jn7;
        goto raM3e;
        SvOcr:
        $this->o2VY1 = $mjAYO;
        goto CiTs1;
        Ael8C:
        $this->z5gsb = $ydoZC;
        goto SvOcr;
        CiTs1:
    }
    public function encode(string $Brk87, string $li4hO, $JniqW = true) : void
    {
        goto U_Jm4;
        DnI22:
        ini_set('memory_limit', '-1');
        goto bMLP7;
        bMLP7:
        try {
            goto SSmsA;
            IrwUT:
            Log::info("Set input video for Job", ['s3Uri' => $mpqj5]);
            goto x2EqK;
            etBD7:
            Log::info("Set thumbnail for HVuLZHLrSam0d Job", ['videoId' => $jZqB7->getAttribute('id'), 'duration' => $jZqB7->getAttribute('duration')]);
            goto Hk_Wh;
            YFGZ6:
            throw new MediaConverterException("HVuLZHLrSam0d {$jZqB7->id} is not S3 driver");
            goto OdEVn;
            TmLQG:
            $wbDY2 = app(Suk3MOIJcOQzt::class);
            goto PXAux;
            gbW_Q:
            $sFhO3 = $this->mQGgT8lXTlF($cDtoP, $q1vwE->mljISqrPrHy($jZqB7->width(), $jZqB7->height(), $li4hO));
            goto N2Uvn;
            SSmsA:
            $jZqB7 = HVuLZHLrSam0d::findOrFail($Brk87);
            goto lIN8C;
            x2EqK:
            $epE20 = app(Evs9C2DhMDeMD::class);
            goto wm4ch;
            lIN8C:
            Assert::isInstanceOf($jZqB7, HVuLZHLrSam0d::class);
            goto uh7Qa;
            bwb5U:
            $bVpSc = $this->m17EpPrxGx8($p9c0Q, $erqpi);
            goto ZAj91;
            OdEVn:
            l0nSY:
            goto RfJC2;
            SkACb:
            rhYYt:
            goto bErqm;
            qZcqU:
            $epE20->mWG0LZ1bFAO($wbDY2->mgMoXe96s1W($jZqB7));
            goto nPg0i;
            AdEgR:
            if (!$this->mpqoPVRodwk($p9c0Q, $erqpi)) {
                goto rhYYt;
            }
            goto bwb5U;
            IMkm1:
            $epE20->mWG0LZ1bFAO($wbDY2->mgMoXe96s1W($jZqB7));
            goto FbHZu;
            uJQLs:
            $S2xbt = new Ntz5hwm7VzzwJ('1080p', $bVpSc['width'], $bVpSc['height'], $jZqB7->ls7Bg ?? 30);
            goto kE6r4;
            Bln07:
            $erqpi = $jZqB7->height();
            goto QLFoJ;
            MeBxN:
            Mf3rI:
            goto isCJp;
            uh7Qa:
            if (!($jZqB7->J42hQ !== NFXMub09wSQVu::S3)) {
                goto l0nSY;
            }
            goto YFGZ6;
            JWYt8:
            ApP3b:
            goto BqPo0;
            ReaAq:
            $S2xbt = $S2xbt->mlthDNEIzNb($sFhO3);
            goto JWYt8;
            Qjck7:
            $epE20 = $epE20->m5i1cg1abV9($NQQfI);
            goto WOppB;
            wm4ch:
            $epE20 = $epE20->mWylJfYFJ7F(new PHA10ASHyxJnC($mpqj5));
            goto UuQQL;
            Hk_Wh:
            $NQQfI = new CoZlTEDusQdM7($jZqB7->XEi1P ?? 1, 2, $wbDY2->mEFZAYLFLa1($jZqB7));
            goto Qjck7;
            PXAux:
            $epE20->m4ZQCKu4FSy($kQF53);
            goto IMkm1;
            ZLLHO:
            if (!$sFhO3) {
                goto ApP3b;
            }
            goto ReaAq;
            isCJp:
            $epE20->m4ZQCKu4FSy($kQF53);
            goto qZcqU;
            RfJC2:
            $p9c0Q = $jZqB7->width();
            goto Bln07;
            kE6r4:
            $sFhO3 = $this->mQGgT8lXTlF($cDtoP, $q1vwE->mljISqrPrHy((int) $bVpSc['width'], (int) $bVpSc['height'], $li4hO));
            goto ZLLHO;
            QLFoJ:
            $mpqj5 = $this->m5OGXMimkI7($jZqB7);
            goto IrwUT;
            nQ2Hz:
            $jZqB7->update(['aws_media_converter_job_id' => $Brk87]);
            goto IBVZ1;
            UuQQL:
            $kQF53 = new Ntz5hwm7VzzwJ('original', $p9c0Q, $erqpi, $jZqB7->ls7Bg ?? 30);
            goto TmLQG;
            nPg0i:
            if (!($p9c0Q && $erqpi)) {
                goto k4eMO;
            }
            goto AdEgR;
            FbHZu:
            $cDtoP = app(CbfzS01NR7tQ9::class);
            goto QHUtm;
            g5M89:
            $kQF53 = $kQF53->mlthDNEIzNb($sFhO3);
            goto MeBxN;
            bErqm:
            k4eMO:
            goto etBD7;
            ZAj91:
            Log::info("Set 1080p resolution for Job", ['width' => $bVpSc['width'], 'height' => $bVpSc['height'], 'originalWidth' => $p9c0Q, 'originalHeight' => $erqpi]);
            goto uJQLs;
            QHUtm:
            $q1vwE = new MwudJaX1iKlH8($this->z5gsb, $this->o2VY1, $this->m2kWg, $this->BX0zD);
            goto gbW_Q;
            BqPo0:
            $epE20 = $epE20->m4ZQCKu4FSy($S2xbt);
            goto SkACb;
            N2Uvn:
            if (!$sFhO3) {
                goto Mf3rI;
            }
            goto g5M89;
            WOppB:
            $Brk87 = $epE20->mHtOBPKXSuq($this->m6P2QUMR2wv($jZqB7, $JniqW));
            goto nQ2Hz;
            IBVZ1:
        } catch (\Exception $Fa7Tp) {
            Log::info("HVuLZHLrSam0d has been deleted, discard it", ['fileId' => $Brk87, 'err' => $Fa7Tp->getMessage()]);
            return;
        }
        goto W2V1G;
        U_Jm4:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $Brk87]);
        goto DnI22;
        W2V1G:
    }
    private function m6P2QUMR2wv(HVuLZHLrSam0d $jZqB7, $JniqW) : bool
    {
        goto ZhPlN;
        ZhPlN:
        if ($JniqW) {
            goto VzaWw;
        }
        goto ZjOcv;
        ZJX52:
        $CZyuP = (int) round($jZqB7->getAttribute('duration') ?? 0);
        goto tvXty;
        ZjOcv:
        return false;
        goto cbCwW;
        tvXty:
        switch (true) {
            case $jZqB7->width() * $jZqB7->height() >= 1920 * 1080 && $jZqB7->width() * $jZqB7->height() < 2560 * 1440:
                return $CZyuP > 10 * 60;
            case $jZqB7->width() * $jZqB7->height() >= 2560 * 1440 && $jZqB7->width() * $jZqB7->height() < 3840 * 2160:
                return $CZyuP > 5 * 60;
            case $jZqB7->width() * $jZqB7->height() >= 3840 * 2160:
                return $CZyuP > 3 * 60;
            default:
                return false;
        }
        goto hP0xN;
        cbCwW:
        VzaWw:
        goto ZJX52;
        hP0xN:
        uGhpH:
        goto IX23V;
        IX23V:
        pNKhU:
        goto TIVsc;
        TIVsc:
    }
    private function mQGgT8lXTlF(CbfzS01NR7tQ9 $cDtoP, string $S2YNe) : ?NV3aOYfIycxy3
    {
        goto NyhME;
        jvF2i:
        Log::info("Resolve watermark for job with url", ['url' => $S2YNe, 'uri' => $xDObD]);
        goto jetS8;
        jetS8:
        if (!$xDObD) {
            goto OlUjF;
        }
        goto lnWCE;
        NyhME:
        $xDObD = $cDtoP->mEq98tyAuTi($S2YNe);
        goto jvF2i;
        lnWCE:
        return new NV3aOYfIycxy3($xDObD, 0, 0, null, null);
        goto lxfSB;
        lxfSB:
        OlUjF:
        goto Jk6EE;
        Jk6EE:
        return null;
        goto uQ2_s;
        uQ2_s:
    }
    private function mpqoPVRodwk(int $p9c0Q, int $erqpi) : bool
    {
        return $p9c0Q * $erqpi > 1.5 * (1920 * 1080);
    }
    private function m17EpPrxGx8(int $p9c0Q, int $erqpi) : array
    {
        $CQC6l = new GvnUWx3jUfPlo($p9c0Q, $erqpi);
        return $CQC6l->mfwNBR9UoDO();
    }
    private function m5OGXMimkI7(D3Q3lppZQonk9 $mA8Ck) : string
    {
        goto TX9ng;
        mn4aF:
        return $this->BX0zD->url($mA8Ck->filename);
        goto YyTnN;
        jV9iA:
        ywG34:
        goto mn4aF;
        KV36G:
        return 's3://' . $this->p_blM . '/' . $mA8Ck->filename;
        goto jV9iA;
        TX9ng:
        if (!($mA8Ck->J42hQ == NFXMub09wSQVu::S3)) {
            goto ywG34;
        }
        goto KV36G;
        YyTnN:
    }
}
