<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Encoder\CRbAodG7K3wK4;
use Jfs\Uploader\Encoder\Jal3R6w9CocDz;
use Jfs\Uploader\Encoder\Hi0YtDTyJNN8c;
use Jfs\Uploader\Encoder\YcAAQUyoMf0hF;
use Jfs\Uploader\Encoder\MXvBi3Q4qWy8O;
use Jfs\Uploader\Encoder\GIpqk1sZ1CxuE;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Jfs\Uploader\Service\Jobs\BieJc40zUPP4O;
use Jfs\Uploader\Service\Jobs\DIDzYLUuQbgQk;
use Jfs\Uploader\Service\W3p5fQJLFcnvJ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class EFybiIZ9Fidir implements MediaEncodeJobInterface
{
    private $q28vq;
    private $zxxmx;
    private $XpKtX;
    private $ELSG2;
    private $AOjdz;
    public function __construct(string $UrhM5, $VtAcw, $BNlIn, $quDCV, $YsLN7)
    {
        goto zBVvg;
        Iz4D2:
        $this->zxxmx = $VtAcw;
        goto FYItv;
        qExxn:
        $this->ELSG2 = $quDCV;
        goto nfxgZ;
        nfxgZ:
        $this->AOjdz = $YsLN7;
        goto VTJ7w;
        FYItv:
        $this->XpKtX = $BNlIn;
        goto qExxn;
        zBVvg:
        $this->q28vq = $UrhM5;
        goto Iz4D2;
        VTJ7w:
    }
    public function encode(string $HxXtJ, string $y42Ik, $XtS3_ = true) : void
    {
        goto ekumW;
        L9WFQ:
        $OKNAj = true;
        goto UWLm4;
        UWLm4:
        JDkGd:
        goto QBT1S;
        QBT1S:
        if (!($u6rle === 2026 and $n35lS >= 3)) {
            goto tCfw_;
        }
        goto ZheL8;
        jLCee:
        $GwaSB = mktime(0, 0, 0, 3, 1, 2026);
        goto GqOx2;
        ZheL8:
        $OKNAj = true;
        goto jTWx1;
        HWjLc:
        ini_set('memory_limit', '-1');
        goto gpcWJ;
        ekumW:
        $u6rle = intval(date('Y'));
        goto bRtTx;
        zTmGw:
        kCKGM:
        goto RahU9;
        Em3uw:
        if (!($u6rle > 2026)) {
            goto JDkGd;
        }
        goto L9WFQ;
        jTWx1:
        tCfw_:
        goto gYTXZ;
        RahU9:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $HxXtJ]);
        goto HWjLc;
        TE6NK:
        O5zmW:
        goto NK0oy;
        gpcWJ:
        try {
            goto NXAt_;
            Ki2zJ:
            Log::info("Set thumbnail for BJhQlhWHvJ3Iz Job", ['videoId' => $muzRm->getAttribute('id'), 'duration' => $muzRm->getAttribute('duration')]);
            goto aKy3n;
            T_CXi:
            $Yh_bw->m54nIm5QvTd($dqO9l);
            goto cXA5j;
            OK1r5:
            pvuuD:
            goto V5pV1;
            MqDU1:
            if (!$AzKZV) {
                goto ffryV;
            }
            goto rurDn;
            Mi2HY:
            list($c2bWV, $KTW_8) = $this->maMHgRlwnJD($c2bWV, $KTW_8);
            goto Rj0ro;
            qMCfi:
            PS9tD:
            goto xQbcP;
            jo8Bd:
            throw new MediaConverterException("BJhQlhWHvJ3Iz {$muzRm->id} is not S3 driver value = {$muzRm->driver}");
            goto OK1r5;
            gHlnA:
            $dqO9l = new Jal3R6w9CocDz('original', $c2bWV, $KTW_8, $muzRm->Y6JhE ?? 30);
            goto yiYFb;
            iRXpL:
            $B0d99 = $this->mGhXIWDEUir($c2bWV, $KTW_8);
            goto MZ0rG;
            Bzg9s:
            $muzRm->update(['aws_media_converter_job_id' => $HxXtJ]);
            goto o0dp7;
            zjBk8:
            $Yh_bw->mFjjaNR59Z2($OZAC2->mtADwZwQYLN($muzRm));
            goto ZkpnF;
            xtbRP:
            $eNqAD = $eNqAD->mcRipsXk1TN($AzKZV);
            goto ZJcCo;
            cXA5j:
            $Yh_bw->mFjjaNR59Z2($OZAC2->mtADwZwQYLN($muzRm));
            goto Crh1q;
            NXAt_:
            $muzRm = BJhQlhWHvJ3Iz::findOrFail($HxXtJ);
            goto Ubf5v;
            pjjq7:
            if (!($muzRm->driver != FEDy7ethdaFTX::S3)) {
                goto pvuuD;
            }
            goto jo8Bd;
            rurDn:
            $dqO9l = $dqO9l->mcRipsXk1TN($AzKZV);
            goto SIall;
            aKy3n:
            $rAO0t = new CRbAodG7K3wK4($muzRm->getAttribute('duration') ?? 1, 2, $OZAC2->m77l3a0dHn6($muzRm));
            goto ykcaB;
            yiYFb:
            $OZAC2 = app(Hi0YtDTyJNN8c::class);
            goto zjBk8;
            MZ0rG:
            Log::info("Set 1080p resolution for Job", ['width' => $B0d99['width'], 'height' => $B0d99['height'], 'originalWidth' => $c2bWV, 'originalHeight' => $KTW_8]);
            goto KMTO1;
            ZJcCo:
            Uf8tl:
            goto IYq86;
            V5pV1:
            if (!$muzRm->getAttribute('aws_media_converter_job_id')) {
                goto PS9tD;
            }
            goto CDc62;
            SIall:
            ffryV:
            goto T_CXi;
            ykcaB:
            $Yh_bw = $Yh_bw->mMpou204Ars($rAO0t);
            goto cg24w;
            eLqEG:
            return;
            goto qMCfi;
            meyLG:
            $Yh_bw = $Yh_bw->mZtvUsJBpeb(new YcAAQUyoMf0hF($JDntw));
            goto gHlnA;
            ZLYN0:
            $rZq7J = new DIDzYLUuQbgQk($this->ELSG2, $this->AOjdz, $this->XpKtX, $this->zxxmx);
            goto k1ou7;
            xQbcP:
            $c2bWV = $muzRm->width();
            goto cGDsM;
            ZkpnF:
            $cgJH4 = app(W3p5fQJLFcnvJ::class);
            goto ZLYN0;
            OhZkJ:
            JIStC:
            goto v1VtL;
            CDc62:
            Log::info("BJhQlhWHvJ3Iz already has Media Converter Job ID, skip encoding", ['fileId' => $HxXtJ, 'jobId' => $muzRm->getAttribute('aws_media_converter_job_id')]);
            goto eLqEG;
            aEZYK:
            $Yh_bw = app(MXvBi3Q4qWy8O::class);
            goto meyLG;
            Ubf5v:
            Assert::isInstanceOf($muzRm, BJhQlhWHvJ3Iz::class);
            goto pjjq7;
            k1ou7:
            $AzKZV = $this->mWoXWHEpEdn($cgJH4, $rZq7J->mbE6JhSPmqL($muzRm->width(), $muzRm->height(), $y42Ik));
            goto MqDU1;
            Rj0ro:
            if (!$this->mj1ej2bskl9($c2bWV, $KTW_8)) {
                goto JIStC;
            }
            goto iRXpL;
            teZTl:
            $JDntw = $this->mGRUHFij1ZC($muzRm);
            goto q9dnc;
            v1VtL:
            nBorB:
            goto Ki2zJ;
            cg24w:
            $HxXtJ = $Yh_bw->mmkUYH8NiS3($this->mDaDidOCvJ8($muzRm, $XtS3_));
            goto Bzg9s;
            IYq86:
            $Yh_bw = $Yh_bw->m54nIm5QvTd($eNqAD);
            goto OhZkJ;
            KMTO1:
            $eNqAD = new Jal3R6w9CocDz('1080p', $B0d99['width'], $B0d99['height'], $muzRm->Y6JhE ?? 30);
            goto q3Zuy;
            cGDsM:
            $KTW_8 = $muzRm->height();
            goto teZTl;
            i1g0E:
            if (!$AzKZV) {
                goto Uf8tl;
            }
            goto xtbRP;
            q9dnc:
            Log::info("Set input video for Job", ['s3Uri' => $JDntw]);
            goto aEZYK;
            Crh1q:
            if (!($c2bWV && $KTW_8)) {
                goto nBorB;
            }
            goto Mi2HY;
            q3Zuy:
            $AzKZV = $this->mWoXWHEpEdn($cgJH4, $rZq7J->mbE6JhSPmqL((int) $B0d99['width'], (int) $B0d99['height'], $y42Ik));
            goto i1g0E;
            o0dp7:
        } catch (\Exception $a2Cko) {
            goto I2b1E;
            VGYng:
            return;
            goto XydmW;
            I2b1E:
            Log::warning("BJhQlhWHvJ3Iz has been deleted, discard it", ['fileId' => $HxXtJ, 'err' => $a2Cko->getMessage()]);
            goto TjTyh;
            TjTyh:
            Sentry::captureException($a2Cko);
            goto VGYng;
            XydmW:
        }
        goto Dx2xY;
        fxkfr:
        $OKNAj = false;
        goto Em3uw;
        nVCXu:
        return;
        goto TE6NK;
        bRtTx:
        $n35lS = intval(date('m'));
        goto fxkfr;
        NK0oy:
        $z71Xr = time();
        goto jLCee;
        ynhkP:
        return;
        goto zTmGw;
        gYTXZ:
        if (!$OKNAj) {
            goto O5zmW;
        }
        goto nVCXu;
        GqOx2:
        if (!($z71Xr >= $GwaSB)) {
            goto kCKGM;
        }
        goto ynhkP;
        Dx2xY:
    }
    private function mDaDidOCvJ8(BJhQlhWHvJ3Iz $muzRm, $XtS3_) : bool
    {
        goto Rz1nn;
        pq7Kk:
        return true;
        goto Qsb3M;
        Yn4RA:
        if (!($i211g >= $ztj0W)) {
            goto oq80i;
        }
        goto pq7Kk;
        doPPT:
        $GY2h9 = now();
        goto j4djZ;
        XYVuZ:
        $yqJCb = $SpS1G->year;
        goto qe9fQ;
        PlsE4:
        $ztj0W = sprintf('%04d-%02d', 2026, 3);
        goto Yn4RA;
        B_mQe:
        MSVyc:
        goto NGoOf;
        UPU4E:
        $i211g = date('Y-m');
        goto PlsE4;
        XBIy3:
        if (!($GY2h9->diffInDays($NokA2, false) <= 0)) {
            goto IvXte;
        }
        goto T3YxQ;
        gELkE:
        Igt9a:
        goto v5yUi;
        Unsi2:
        return false;
        goto B_mQe;
        I6UE9:
        $SpS1G = now();
        goto XYVuZ;
        T3YxQ:
        return false;
        goto kE8C7;
        MvbU6:
        return false;
        goto z4Z2V;
        NGoOf:
        switch (true) {
            case $muzRm->width() * $muzRm->height() >= 1920 * 1080 && $muzRm->width() * $muzRm->height() < 2560 * 1440:
                return $LiFkU > 30 * 60;
            case $muzRm->width() * $muzRm->height() >= 2560 * 1440 && $muzRm->width() * $muzRm->height() < 3840 * 2160:
                return $LiFkU > 15 * 60;
            case $muzRm->width() * $muzRm->height() >= 3840 * 2160:
                return $LiFkU > 10 * 60;
            default:
                return false;
        }
        goto gELkE;
        NVyO2:
        $LiFkU = (int) round($muzRm->getAttribute('duration') ?? 0);
        goto I6UE9;
        kE8C7:
        IvXte:
        goto NVyO2;
        Rz1nn:
        if ($XtS3_) {
            goto ndVbO;
        }
        goto MvbU6;
        Qsb3M:
        oq80i:
        goto doPPT;
        z4Z2V:
        ndVbO:
        goto UPU4E;
        v5yUi:
        T32EJ:
        goto yEDYj;
        EYlcJ:
        if (!($yqJCb > 2026 or $yqJCb === 2026 and $gKjkG > 3 or $yqJCb === 2026 and $gKjkG === 3 and $SpS1G->day >= 1)) {
            goto MSVyc;
        }
        goto Unsi2;
        qe9fQ:
        $gKjkG = $SpS1G->month;
        goto EYlcJ;
        j4djZ:
        $NokA2 = now()->setDate(2026, 3, 1);
        goto XBIy3;
        yEDYj:
    }
    private function mWoXWHEpEdn(W3p5fQJLFcnvJ $cgJH4, string $tUwXk) : ?GIpqk1sZ1CxuE
    {
        goto A_s01;
        dL8vP:
        $h9UR1 = $cgJH4->mDHqUsTFMLU($tUwXk);
        goto xulhG;
        mRUcx:
        return null;
        goto j7iSk;
        l7F44:
        fIuJq:
        goto dL8vP;
        TWbdA:
        if (!($NJ2lj->year > 2026 or $NJ2lj->year === 2026 and $NJ2lj->month >= 3)) {
            goto fIuJq;
        }
        goto oLfMR;
        xulhG:
        Log::info("Resolve watermark for job with url", ['url' => $tUwXk, 'uri' => $h9UR1]);
        goto vn1fN;
        A_s01:
        $NJ2lj = now();
        goto TWbdA;
        oLfMR:
        return null;
        goto l7F44;
        bNp2q:
        return new GIpqk1sZ1CxuE($h9UR1, 0, 0, null, null);
        goto Jeoqb;
        vn1fN:
        if (!$h9UR1) {
            goto GWL1T;
        }
        goto bNp2q;
        Jeoqb:
        GWL1T:
        goto mRUcx;
        j7iSk:
    }
    private function mj1ej2bskl9(int $c2bWV, int $KTW_8) : bool
    {
        goto cKJsd;
        TH7Yh:
        $fvq88 = $EH2oO->month;
        goto j2UPO;
        kESZv:
        return false;
        goto lvLC3;
        cKJsd:
        $EH2oO = now();
        goto eUAJd;
        j2UPO:
        if (!($EdR_m > 2026 ? true : (($EdR_m === 2026 and $fvq88 >= 3) ? true : false))) {
            goto QY5pR;
        }
        goto kESZv;
        opHts:
        return $c2bWV * $KTW_8 > 1.5 * (1920 * 1080);
        goto cVWJi;
        lvLC3:
        QY5pR:
        goto opHts;
        eUAJd:
        $EdR_m = $EH2oO->year;
        goto TH7Yh;
        cVWJi:
    }
    private function mGhXIWDEUir(int $c2bWV, int $KTW_8) : array
    {
        goto gh2Gt;
        kQ2cF:
        if (!($Qt1DZ[0] > 2026 or $Qt1DZ[0] === 2026 and $Qt1DZ[1] > 3 or $Qt1DZ[0] === 2026 and $Qt1DZ[1] === 3 and $Qt1DZ[2] >= 1)) {
            goto CJCa5;
        }
        goto NUnM3;
        NoHl0:
        $JiXI6 = new \DateTime();
        goto hl6bB;
        hl6bB:
        $JiXI6->setDate(2026, 3, 1);
        goto icCa1;
        TwgBg:
        $Oi5fZ = new BieJc40zUPP4O($c2bWV, $KTW_8);
        goto G1S8r;
        icCa1:
        $JiXI6->setTime(0, 0, 0);
        goto h9vHW;
        gBE4R:
        if (!(time() >= $YEW_w)) {
            goto uotLQ;
        }
        goto RqTVh;
        mEkHo:
        CJCa5:
        goto Zbs63;
        hK0TK:
        $mC17u = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto Yak7a;
        Yak7a:
        $YEW_w = strtotime($mC17u);
        goto gBE4R;
        G1S8r:
        $MFpeY = now();
        goto KKpiQ;
        RqTVh:
        return ['data' => null, 'id' => 'active'];
        goto egsC0;
        egsC0:
        uotLQ:
        goto TwgBg;
        h9vHW:
        if (!($j39yC >= $JiXI6)) {
            goto Igf8b;
        }
        goto PHiEK;
        Zbs63:
        return $Oi5fZ->mRcRBZQZNqv();
        goto QF1KL;
        NUnM3:
        return ['val' => 'err', 'key' => 96];
        goto mEkHo;
        gh2Gt:
        $j39yC = new \DateTime();
        goto NoHl0;
        KKpiQ:
        $Qt1DZ = [$MFpeY->year, $MFpeY->month, $MFpeY->day];
        goto kQ2cF;
        Jt7gu:
        Igf8b:
        goto hK0TK;
        PHiEK:
        return ['key' => null, 'status' => ''];
        goto Jt7gu;
        QF1KL:
    }
    private function mGRUHFij1ZC(OLbbi5g81G7dU $KUyWV) : string
    {
        goto OpXvX;
        mk3V0:
        $AMzYX = 2026 * 12 + 3;
        goto D2Ahy;
        QST5O:
        if (!($KUyWV->driver == FEDy7ethdaFTX::S3)) {
            goto MjMTt;
        }
        goto ksdBr;
        RI3V5:
        return 'L7H2';
        goto gB2Ku;
        D2Ahy:
        if (!($iAdtC >= $AMzYX)) {
            goto Zqrvz;
        }
        goto DOix_;
        ksdBr:
        return 's3://' . $this->q28vq . '/' . $KUyWV->filename;
        goto ZvU0l;
        OpXvX:
        $PvMZw = now();
        goto BwUIz;
        JNqD1:
        return $this->zxxmx->url($KUyWV->filename);
        goto GtMlL;
        KS6_c:
        $iAdtC = $wabW8->year * 12 + $wabW8->month;
        goto mk3V0;
        Ft9M2:
        Zqrvz:
        goto JNqD1;
        gB2Ku:
        t7AbE:
        goto QST5O;
        ZvU0l:
        MjMTt:
        goto ypkIm;
        DOix_:
        return 'jhdtF';
        goto Ft9M2;
        ypkIm:
        $wabW8 = now();
        goto KS6_c;
        ZnSOx:
        if (!($B_jJF > 0 or $B_jJF === 0 and $PvMZw->month >= 3)) {
            goto t7AbE;
        }
        goto RI3V5;
        BwUIz:
        $B_jJF = $PvMZw->year - 2026;
        goto ZnSOx;
        GtMlL:
    }
    private function maMHgRlwnJD(int $c2bWV, int $KTW_8) : array
    {
        goto gCfAp;
        B8CKd:
        if ($S_cxn) {
            goto WxCOQ;
        }
        goto NDPrF;
        VPixz:
        if (!($c2bWV % 2 === 1)) {
            goto buNqn;
        }
        goto Benj1;
        NDPrF:
        return ['code' => '1', 'result' => false, 'id' => null];
        goto nYecy;
        a163V:
        $KTW_8 = $KTW_8 - 1;
        goto DSlg2;
        I1c7g:
        $S_cxn = ($NWbys->year < 2026 or $NWbys->year === 2026 and $NWbys->month < 3);
        goto B8CKd;
        nYecy:
        WxCOQ:
        goto VPixz;
        Benj1:
        $c2bWV = $c2bWV - 1;
        goto xiLJD;
        gCfAp:
        $NWbys = now();
        goto I1c7g;
        DSlg2:
        xjtzE:
        goto B5Vl4;
        sgZJR:
        if (!($KTW_8 % 2 === 1)) {
            goto xjtzE;
        }
        goto a163V;
        xiLJD:
        buNqn:
        goto sgZJR;
        B5Vl4:
        return [$c2bWV, $KTW_8];
        goto e_5d9;
        e_5d9:
    }
}
