<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
class Wbzft70CbxsnJ implements BlurJobInterface
{
    const nV2uI = 15;
    const Qqf08 = 500;
    const jetsR = 500;
    private $Ie_ZE;
    private $MV0lK;
    private $P2FvH;
    public function __construct($jSZw8, $tYsty, $j8mv9)
    {
        goto nKqr9;
        iQJP_:
        $this->Ie_ZE = $jSZw8;
        goto fONfO;
        nKqr9:
        $this->P2FvH = $j8mv9;
        goto y2231;
        y2231:
        $this->MV0lK = $tYsty;
        goto iQJP_;
        fONfO:
    }
    public function blur(string $FILUb) : void
    {
        goto WL6sa;
        okoZY:
        $FGBix = $this->Ie_ZE->call($this, $this->P2FvH->path($QhMNH->getLocation()));
        goto bekNW;
        nBhlh:
        eFEUC:
        goto NWznd;
        NWznd:
        $QhMNH->update(['preview' => $pTbWI]);
        goto NhCFE;
        bekNW:
        $jG3UU = $FGBix->width() / $FGBix->height();
        goto OUnb8;
        WL6sa:
        $QhMNH = XbYF8aa0XyGnI::findOrFail($FILUb);
        goto XnxpW;
        pxQ16:
        $pTbWI = $this->mwfF58VrEJD($QhMNH);
        goto EVtWE;
        EVtWE:
        $UrnhP = $this->P2FvH->path($pTbWI);
        goto HJZWi;
        OUnb8:
        $FGBix->resize(self::Qqf08, self::jetsR / $jG3UU);
        goto SDpXM;
        tPKyh:
        if (!($QhMNH->tl1PH == N0ISad2bKF2Yp::S3 && !$this->P2FvH->exists($QhMNH->filename))) {
            goto bGUm5;
        }
        goto v887e;
        v887e:
        $lNHwD = $this->MV0lK->get($QhMNH->filename);
        goto ecWUs;
        rOu3i:
        \Log::warning('Failed to set final permissions on image file: ' . $UrnhP);
        goto RLGiH;
        SDpXM:
        $FGBix->blur(self::nV2uI);
        goto pxQ16;
        RLGiH:
        throw new \Exception('Failed to set final permissions on image file: ' . $UrnhP);
        goto nBhlh;
        YZJWr:
        bGUm5:
        goto okoZY;
        A3mPS:
        $FGBix->destroy();
        goto s54Z1;
        s54Z1:
        if (chmod($UrnhP, 0664)) {
            goto eFEUC;
        }
        goto rOu3i;
        HJZWi:
        $FGBix->save($UrnhP);
        goto A3mPS;
        XnxpW:
        ini_set('memory_limit', '-1');
        goto tPKyh;
        ecWUs:
        $this->P2FvH->put($QhMNH->filename, $lNHwD);
        goto YZJWr;
        NhCFE:
    }
    private function mwfF58VrEJD($eh8u9) : string
    {
        goto gEpvf;
        cBNtP:
        $this->P2FvH->makeDirectory($OhpSE, 0755, true);
        goto CFvCX;
        K6iw7:
        $OhpSE = dirname($Sblyk) . '/preview/';
        goto FM2Kf;
        sPzON:
        return $OhpSE . $eh8u9->getFilename() . '.jpg';
        goto OctAE;
        CFvCX:
        uXaby:
        goto sPzON;
        FM2Kf:
        if ($this->P2FvH->exists($OhpSE)) {
            goto uXaby;
        }
        goto cBNtP;
        gEpvf:
        $Sblyk = $eh8u9->getLocation();
        goto K6iw7;
        OctAE:
    }
}
