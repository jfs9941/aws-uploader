<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
class CtrinJDneAynd implements GenerateThumbnailJobInterface
{
    const Owfd3 = 150;
    const P_xoQ = 150;
    private $RFvhw;
    private $HyJkj;
    public function __construct($LDEwd, $N7YvB)
    {
        $this->RFvhw = $LDEwd;
        $this->HyJkj = $N7YvB;
    }
    public function generate(string $Qu08p)
    {
        goto Tavj2;
        Tavj2:
        Log::info("Generating thumbnail", ['imageId' => $Qu08p]);
        goto IScum;
        IScum:
        ini_set('memory_limit', '-1');
        goto Cxete;
        Cxete:
        try {
            goto E_mEI;
            txzIT:
            if (!($lZywC !== false)) {
                goto sh7BY;
            }
            goto uufJA;
            lzHmw:
            $fe3pc = YPgQPiPQjMu1g::findOrFail($Qu08p);
            goto PIP4P;
            rQZwQ:
            $Ozj2g->encode('jpg', 80);
            goto AguNR;
            AguNR:
            $TnwL2 = $this->m6TxZOKmY2G($fe3pc);
            goto RHoPF;
            uufJA:
            $fe3pc->update(['thumbnail' => $TnwL2, 'status' => OLX71luAn6XnP::THUMBNAIL_PROCESSED]);
            goto Snz2_;
            E_mEI:
            $mHTSY = $this->HyJkj;
            goto lzHmw;
            vOH0s:
            if (chmod($DQbZI, 0644)) {
                goto i7_FY;
            }
            goto MX0B6;
            OWnD0:
            $Ozj2g->fit(150, 150, function ($QnmUN) {
                $QnmUN->aspectRatio();
            });
            goto rQZwQ;
            Snz2_:
            $DQbZI = $mHTSY->path($TnwL2);
            goto vOH0s;
            yY2vl:
            throw new \Exception('Failed to set file permissions for stored image: ' . $DQbZI);
            goto BEtO9;
            VfsGf:
            $Ozj2g->destroy();
            goto txzIT;
            PIP4P:
            $Ozj2g = $this->RFvhw->call($this, $mHTSY->path($fe3pc->getLocation()));
            goto OWnD0;
            MX0B6:
            Log::warning('Failed to set file permissions for stored image: ' . $DQbZI);
            goto yY2vl;
            RHoPF:
            $lZywC = $mHTSY->put($TnwL2, $Ozj2g->stream(), ['visibility' => 'public']);
            goto VfsGf;
            BEtO9:
            i7_FY:
            goto DDeps;
            DDeps:
            sh7BY:
            goto nGNY0;
            nGNY0:
        } catch (ModelNotFoundException $WZ5dZ) {
            Log::info("YPgQPiPQjMu1g has been deleted, discard it", ['imageId' => $Qu08p]);
            return;
        }
        goto plmko;
        plmko:
    }
    private function m6TxZOKmY2G(LfWCTOqty2Slr $fe3pc) : string
    {
        goto w91C7;
        tUbS5:
        $VSZpN = $zvQmT . '/' . self::Owfd3 . 'X' . self::P_xoQ;
        goto acbNQ;
        gnSZq:
        $zvQmT = dirname($TnwL2);
        goto tUbS5;
        w91C7:
        $TnwL2 = $fe3pc->getLocation();
        goto gnSZq;
        acbNQ:
        return $VSZpN . '/' . $fe3pc->getFilename() . '.jpg';
        goto ATBY4;
        ATBY4:
    }
}
