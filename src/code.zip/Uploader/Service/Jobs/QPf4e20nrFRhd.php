<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Service\Jobs\DSUHtpZvOZQCp;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class QPf4e20nrFRhd implements WatermarkTextJobInterface
{
    private $UVc7_;
    private $QI7yZ;
    private $fyPpL;
    private $D9Jo8;
    private $gcP3F;
    public function __construct($h1yz3, $EAMKc, $v1Edp, $qxxOf, $cav1T)
    {
        goto MHmQZ;
        fqszQ:
        $this->QI7yZ = $EAMKc;
        goto Lbwiw;
        AWhR4:
        $this->gcP3F = $qxxOf;
        goto A3uoL;
        MHmQZ:
        $this->UVc7_ = $h1yz3;
        goto BJjYP;
        A3uoL:
        $this->fyPpL = $cav1T;
        goto fqszQ;
        BJjYP:
        $this->D9Jo8 = $v1Edp;
        goto AWhR4;
        Lbwiw:
    }
    public function putWatermark(string $poSkG, string $R5z2N) : void
    {
        goto MQA4E;
        VBvFS:
        $PY97I = memory_get_usage();
        goto LlTs3;
        iouc0:
        ini_set('memory_limit', '-1');
        goto IEeeM;
        IEeeM:
        try {
            goto jc1PO;
            BEG66:
            return;
            goto qMQp8;
            jc1PO:
            $VSbOm = KZbAaRxCqNUr3::findOrFail($poSkG);
            goto J6yXX;
            w7l5y:
            $NNmL6 = $this->UVc7_->call($this, $lT4E3);
            goto MM4Cq;
            OH5b3:
            throw new \Exception('Failed to set final permissions on image file: ' . $lT4E3);
            goto mtf0c;
            IIyxz:
            $this->mEN1zzIkDZG($NNmL6, $R5z2N);
            goto b4FFz;
            qMQp8:
            ySrbt:
            goto kXe7C;
            VJFih:
            unset($NNmL6);
            goto eolAx;
            b4FFz:
            $this->D9Jo8->put($lT4E3, $NNmL6->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto VJFih;
            eolAx:
            if (chmod($lT4E3, 0664)) {
                goto rN1Jv;
            }
            goto wXGnH;
            MM4Cq:
            $NNmL6->orient();
            goto IIyxz;
            kXe7C:
            $lT4E3 = $this->gcP3F->path($VSbOm->getLocation());
            goto w7l5y;
            mtf0c:
            rN1Jv:
            goto GcnX6;
            J6yXX:
            if ($this->gcP3F->exists($VSbOm->getLocation())) {
                goto ySrbt;
            }
            goto Wb30x;
            wXGnH:
            \Log::warning('Failed to set final permissions on image file: ' . $lT4E3);
            goto OH5b3;
            Wb30x:
            Log::error("KZbAaRxCqNUr3 is not on local, might be deleted before put watermark", ['imageId' => $poSkG]);
            goto BEG66;
            GcnX6:
        } catch (\Throwable $oreFK) {
            goto qqZuZ;
            XL3jS:
            Log::info("KZbAaRxCqNUr3 has been deleted, discard it", ['imageId' => $poSkG]);
            goto oIuP7;
            oIuP7:
            return;
            goto oI24M;
            qqZuZ:
            if (!$oreFK instanceof ModelNotFoundException) {
                goto WPYwK;
            }
            goto XL3jS;
            oI24M:
            WPYwK:
            goto QG13G;
            QG13G:
            Log::error("KZbAaRxCqNUr3 is not readable", ['imageId' => $poSkG, 'error' => $oreFK->getMessage()]);
            goto W1iii;
            W1iii:
        } finally {
            $BDOA4 = microtime(true);
            $GO2Jv = memory_get_usage();
            $Svmms = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $poSkG, 'execution_time_sec' => $BDOA4 - $EnuQ0, 'memory_usage_mb' => ($GO2Jv - $PY97I) / 1024 / 1024, 'peak_memory_usage_mb' => ($Svmms - $SH_2o) / 1024 / 1024]);
        }
        goto u1O0i;
        LlTs3:
        $SH_2o = memory_get_peak_usage();
        goto QCPIP;
        QCPIP:
        Log::info("Adding watermark text to image", ['imageId' => $poSkG]);
        goto iouc0;
        MQA4E:
        $EnuQ0 = microtime(true);
        goto VBvFS;
        u1O0i:
    }
    private function mEN1zzIkDZG($NNmL6, $R5z2N) : void
    {
        goto YB_ZJ;
        Ew9lr:
        $NNmL6->place($SqP0U, 'top-left', 0, 0, 30);
        goto rimKn;
        sZOWi:
        $rfhYJ = $NNmL6->height();
        goto J_6Si;
        BlWFS:
        $BZxYD = $SDn34->mrTKCqwq0WU($MpCza, $rfhYJ, $R5z2N, true);
        goto yBjZe;
        J_6Si:
        $SDn34 = new DSUHtpZvOZQCp($this->QI7yZ, $this->fyPpL, $this->D9Jo8, $this->gcP3F);
        goto BlWFS;
        F6ko1:
        $SqP0U = $this->UVc7_->call($this, $this->gcP3F->path($BZxYD));
        goto Ew9lr;
        YB_ZJ:
        $MpCza = $NNmL6->width();
        goto sZOWi;
        yBjZe:
        $this->gcP3F->put($BZxYD, $this->D9Jo8->get($BZxYD));
        goto F6ko1;
        rimKn:
    }
}
