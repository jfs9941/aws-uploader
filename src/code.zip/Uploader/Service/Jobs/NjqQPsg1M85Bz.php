<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Encoder\Z98THp6d6oPOr;
use Jfs\Uploader\Encoder\Ij7aQIVlXZdDe;
use Jfs\Uploader\Encoder\PERAjoCXLxFkm;
use Jfs\Uploader\Encoder\XTvyjq4TjM6Q2;
use Jfs\Uploader\Encoder\LTe1erTqXsoi2;
use Jfs\Uploader\Encoder\PsVrIC99Lkpu6;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
use Jfs\Uploader\Service\HTG7kEjmlWunD;
use Webmozart\Assert\Assert;
class NjqQPsg1M85Bz implements MediaEncodeJobInterface
{
    private $pBNm8;
    private $fodJQ;
    private $qrvF0;
    private $m12Fs;
    private $s1Ojb;
    public function __construct(string $QEIhn, $nsgrL, $eG_Pc, $a3Ry3, $yb5JT)
    {
        goto HhDDq;
        zuZHw:
        $this->m12Fs = $a3Ry3;
        goto bA8ab;
        HhDDq:
        $this->pBNm8 = $QEIhn;
        goto SYlCA;
        kNQVc:
        $this->qrvF0 = $eG_Pc;
        goto zuZHw;
        bA8ab:
        $this->s1Ojb = $yb5JT;
        goto tphSH;
        SYlCA:
        $this->fodJQ = $nsgrL;
        goto kNQVc;
        tphSH:
    }
    public function encode(string $ElvKF, string $MjBIh, $mdp1P = true) : void
    {
        goto hgPx9;
        hgPx9:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $ElvKF]);
        goto L7Jqc;
        L7Jqc:
        ini_set('memory_limit', '-1');
        goto ybWjt;
        ybWjt:
        try {
            goto v6Wrc;
            HJ0uC:
            Assert::isInstanceOf($eYbzj, UMeQT1ArE1U05::class);
            goto GVt5v;
            HDPMc:
            Log::info("Set input video for Job", ['s3Uri' => $Zuqik]);
            goto XbfEh;
            Nobp2:
            throw new MediaConverterException("UMeQT1ArE1U05 {$eYbzj->id} is not S3 driver");
            goto I0mHT;
            iTD1d:
            oRaIs:
            goto ZPQwR;
            v6Wrc:
            $eYbzj = UMeQT1ArE1U05::findOrFail($ElvKF);
            goto HJ0uC;
            Ot2Ue:
            if (!$qRUDk) {
                goto PCVLp;
            }
            goto P9Pcz;
            n2wVn:
            $kZRaS->mjeP04tsbZq($Sm2e5->mSVj4jx7Bwt($eYbzj));
            goto jsdVg;
            Yf8T7:
            $eYbzj->update(['aws_media_converter_job_id' => $ElvKF]);
            goto yfSjd;
            VzlRV:
            $t4CKs = $t4CKs->mxDwTPDk8te($qRUDk);
            goto sJXII;
            RXEfS:
            $qRUDk = $this->mIfsZs1oVfu($bUBvu, $hKkXZ->m3R2wWWZe8v($eYbzj->width(), $eYbzj->height(), $MjBIh));
            goto Ot2Ue;
            X_4o4:
            if (!($g5xFk && $zZl79)) {
                goto j_aD2;
            }
            goto o7m0d;
            YyXcJ:
            $ShE43 = new Ij7aQIVlXZdDe('original', $g5xFk, $zZl79, $eYbzj->gE1UH ?? 30);
            goto IWOm3;
            agiYa:
            $kZRaS = $kZRaS->m4GsFz2jrqE($t4CKs);
            goto iTD1d;
            kfNJZ:
            $kZRaS = $kZRaS->mi9Yzacz071(new XTvyjq4TjM6Q2($Zuqik));
            goto YyXcJ;
            Cu2an:
            $t4CKs = new Ij7aQIVlXZdDe('1080p', $z2a0l['width'], $z2a0l['height'], $eYbzj->gE1UH ?? 30);
            goto quTtc;
            quTtc:
            $qRUDk = $this->mIfsZs1oVfu($bUBvu, $hKkXZ->m3R2wWWZe8v((int) $z2a0l['width'], (int) $z2a0l['height'], $MjBIh));
            goto BGxP0;
            P9Pcz:
            $ShE43 = $ShE43->mxDwTPDk8te($qRUDk);
            goto tY8ul;
            W1P_M:
            $Zuqik = $this->m0nLPJo1vmd($eYbzj);
            goto HDPMc;
            gwUFg:
            $g5xFk = $eYbzj->width();
            goto lfzdp;
            I0mHT:
            gZD7w:
            goto gwUFg;
            ZPQwR:
            j_aD2:
            goto KMIUy;
            lfzdp:
            $zZl79 = $eYbzj->height();
            goto W1P_M;
            tY8ul:
            PCVLp:
            goto EdXY2;
            Sw_EV:
            $z2a0l = $this->mrqSPq0LbmS($g5xFk, $zZl79);
            goto xzH0Z;
            XrAkE:
            $hKkXZ = new VWi8iyX8y8IKN($this->m12Fs, $this->s1Ojb, $this->qrvF0, $this->fodJQ);
            goto RXEfS;
            xzH0Z:
            Log::info("Set 1080p resolution for Job", ['width' => $z2a0l['width'], 'height' => $z2a0l['height'], 'originalWidth' => $g5xFk, 'originalHeight' => $zZl79]);
            goto Cu2an;
            GVt5v:
            if (!($eYbzj->rbCCx !== I2Tze5VZcqaXS::S3)) {
                goto gZD7w;
            }
            goto Nobp2;
            sJXII:
            iiCc2:
            goto agiYa;
            jaILD:
            $I_Zk6 = new Z98THp6d6oPOr($eYbzj->PlVGB ?? 1, 2, $Sm2e5->mu7BtR6dJe8($eYbzj));
            goto xVJCa;
            KMIUy:
            Log::info("Set thumbnail for UMeQT1ArE1U05 Job", ['videoId' => $eYbzj->getAttribute('id'), 'duration' => $eYbzj->getAttribute('duration')]);
            goto jaILD;
            IWOm3:
            $Sm2e5 = app(PERAjoCXLxFkm::class);
            goto c4gDJ;
            XnWFn:
            $ElvKF = $kZRaS->mkFdgQFoaZa($this->my8zdYbZQZW($eYbzj, $mdp1P));
            goto Yf8T7;
            EdXY2:
            $kZRaS->m4GsFz2jrqE($ShE43);
            goto rqXg2;
            XbfEh:
            $kZRaS = app(LTe1erTqXsoi2::class);
            goto kfNJZ;
            xVJCa:
            $kZRaS = $kZRaS->munJ0Lc3jZX($I_Zk6);
            goto XnWFn;
            BGxP0:
            if (!$qRUDk) {
                goto iiCc2;
            }
            goto VzlRV;
            c4gDJ:
            $kZRaS->m4GsFz2jrqE($ShE43);
            goto n2wVn;
            rqXg2:
            $kZRaS->mjeP04tsbZq($Sm2e5->mSVj4jx7Bwt($eYbzj));
            goto X_4o4;
            o7m0d:
            if (!$this->maZaLWH4qBA($g5xFk, $zZl79)) {
                goto oRaIs;
            }
            goto Sw_EV;
            jsdVg:
            $bUBvu = app(HTG7kEjmlWunD::class);
            goto XrAkE;
            yfSjd:
        } catch (\Exception $xlNa7) {
            Log::info("UMeQT1ArE1U05 has been deleted, discard it", ['fileId' => $ElvKF, 'err' => $xlNa7->getMessage()]);
            return;
        }
        goto WlyFg;
        WlyFg:
    }
    private function my8zdYbZQZW(UMeQT1ArE1U05 $eYbzj, $mdp1P) : bool
    {
        goto NFx_k;
        D2enB:
        switch (true) {
            case $eYbzj->width() * $eYbzj->height() >= 1920 * 1080 && $eYbzj->width() * $eYbzj->height() < 2560 * 1440:
                return $yPVhK > 10 * 60;
            case $eYbzj->width() * $eYbzj->height() >= 2560 * 1440 && $eYbzj->width() * $eYbzj->height() < 3840 * 2160:
                return $yPVhK > 5 * 60;
            case $eYbzj->width() * $eYbzj->height() >= 3840 * 2160:
                return $yPVhK > 3 * 60;
            default:
                return false;
        }
        goto Gz2Ze;
        I4Vwo:
        return false;
        goto qlGgd;
        qlGgd:
        dE7OI:
        goto nt0ai;
        WwcQQ:
        EFNFF:
        goto Vk3M7;
        Gz2Ze:
        klt8x:
        goto WwcQQ;
        nt0ai:
        $yPVhK = (int) round($eYbzj->getAttribute('duration') ?? 0);
        goto D2enB;
        NFx_k:
        if ($mdp1P) {
            goto dE7OI;
        }
        goto I4Vwo;
        Vk3M7:
    }
    private function mIfsZs1oVfu(HTG7kEjmlWunD $bUBvu, string $iLxso) : ?PsVrIC99Lkpu6
    {
        goto rfED8;
        faLkj:
        return new PsVrIC99Lkpu6($voNbj, 0, 0, null, null);
        goto GsYde;
        ZFsxJ:
        return null;
        goto CtVzH;
        rfED8:
        $voNbj = $bUBvu->mbdoE5IwA7K($iLxso);
        goto I11ox;
        GsYde:
        crEwc:
        goto ZFsxJ;
        lZDRR:
        if (!$voNbj) {
            goto crEwc;
        }
        goto faLkj;
        I11ox:
        Log::info("Resolve watermark for job with url", ['url' => $iLxso, 'uri' => $voNbj]);
        goto lZDRR;
        CtVzH:
    }
    private function maZaLWH4qBA(int $g5xFk, int $zZl79) : bool
    {
        return $g5xFk * $zZl79 > 1.5 * (1920 * 1080);
    }
    private function mrqSPq0LbmS(int $g5xFk, int $zZl79) : array
    {
        $FuXdI = new Jac58S4hxlfDF($g5xFk, $zZl79);
        return $FuXdI->mMQ0ymsGfeo();
    }
    private function m0nLPJo1vmd(MXbLxov2QPqm4 $rXM0w) : string
    {
        goto ICF9W;
        esKjP:
        return 's3://' . $this->pBNm8 . '/' . $rXM0w->filename;
        goto S8Jg1;
        S8Jg1:
        mYGCL:
        goto Upkb0;
        ICF9W:
        if (!($rXM0w->rbCCx == I2Tze5VZcqaXS::S3)) {
            goto mYGCL;
        }
        goto esKjP;
        Upkb0:
        return $this->fodJQ->url($rXM0w->filename);
        goto j68eG;
        j68eG:
    }
}
