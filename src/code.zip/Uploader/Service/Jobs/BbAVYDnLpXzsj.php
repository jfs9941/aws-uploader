<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
class BbAVYDnLpXzsj implements BlurJobInterface
{
    const jDaAv = 15;
    const ICKs3 = 500;
    const vL0T_ = 500;
    private $bLQUI;
    private $YHwpp;
    private $svYhv;
    public function __construct($xA3df, $ehLvI, $uLgU3)
    {
        goto VmGA9;
        VmGA9:
        $this->svYhv = $uLgU3;
        goto ZGOoj;
        WQwty:
        $this->bLQUI = $xA3df;
        goto fIBvf;
        ZGOoj:
        $this->YHwpp = $ehLvI;
        goto WQwty;
        fIBvf:
    }
    public function blur(string $ShXx2) : void
    {
        goto BfIlD;
        HXQNU:
        TiAvs:
        goto jiIU3;
        JAzgl:
        $hwQfC = $this->YHwpp->get($ShgKl->filename);
        goto jKLJ1;
        RtRjY:
        ini_set('memory_limit', '-1');
        goto Vcoqr;
        CucQ8:
        throw new \Exception('Failed to set final permissions on image file: ' . $EBJmp);
        goto HXQNU;
        jKLJ1:
        $this->svYhv->put($ShgKl->filename, $hwQfC);
        goto h6arf;
        JqEM1:
        $xixtT->blur(self::jDaAv);
        goto alxf_;
        mPGxl:
        \Log::warning('Failed to set final permissions on image file: ' . $EBJmp);
        goto CucQ8;
        BhRg7:
        $xixtT = $this->bLQUI->call($this, $this->svYhv->path($ShgKl->getLocation()));
        goto zQTUV;
        sX8hq:
        if (chmod($EBJmp, 0664)) {
            goto TiAvs;
        }
        goto mPGxl;
        jiIU3:
        $ShgKl->update(['preview' => $QZDY1]);
        goto p19AU;
        Vcoqr:
        if (!($ShgKl->driver == TpPQGsuK0gyw2::S3 && !$this->svYhv->exists($ShgKl->filename))) {
            goto V1XGV;
        }
        goto JAzgl;
        alxf_:
        $QZDY1 = $this->mWVJtSErsNd($ShgKl);
        goto I49dW;
        l42T_:
        $xixtT->resize(self::ICKs3, self::vL0T_ / $dAykE);
        goto JqEM1;
        zQTUV:
        $dAykE = $xixtT->width() / $xixtT->height();
        goto l42T_;
        I49dW:
        $EBJmp = $this->YHwpp->put($QZDY1, $xixtT->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto sKWUx;
        BfIlD:
        $ShgKl = Vt3ybt0yfaPAa::findOrFail($ShXx2);
        goto RtRjY;
        sKWUx:
        unset($xixtT);
        goto sX8hq;
        h6arf:
        V1XGV:
        goto BhRg7;
        p19AU:
    }
    private function mWVJtSErsNd($d6FSb) : string
    {
        goto ylV8Z;
        FS2Wu:
        return $Nuuvd . $d6FSb->getFilename() . '.jpg';
        goto U0n5F;
        nIxuO:
        $Nuuvd = dirname($lPyJj) . '/preview/';
        goto S4laM;
        m3i9I:
        $this->svYhv->makeDirectory($Nuuvd, 0755, true);
        goto Wg70T;
        Wg70T:
        RWsKt:
        goto FS2Wu;
        ylV8Z:
        $lPyJj = $d6FSb->getLocation();
        goto nIxuO;
        S4laM:
        if ($this->svYhv->exists($Nuuvd)) {
            goto RWsKt;
        }
        goto m3i9I;
        U0n5F:
    }
}
