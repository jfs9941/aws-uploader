<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
class NB07P3JPQATso implements BlurJobInterface
{
    const nH991 = 15;
    const rv7IZ = 500;
    const FO1M2 = 500;
    private $PAMAL;
    private $hFxUe;
    private $Celh5;
    public function __construct($VX8yi, $KKbEP, $clScT)
    {
        goto EXKeR;
        xeHQU:
        $this->hFxUe = $KKbEP;
        goto xV_cE;
        xV_cE:
        $this->PAMAL = $VX8yi;
        goto snSN1;
        EXKeR:
        $this->Celh5 = $clScT;
        goto xeHQU;
        snSN1:
    }
    public function blur(string $SEOXv) : void
    {
        goto pwapC;
        BzDYo:
        unset($dIrHq);
        goto Zqkq4;
        xx2v_:
        $ANxrm = $this->mrDOi780VNg($NcJt_);
        goto j0T57;
        j0T57:
        $XvBVB = $this->hFxUe->put($ANxrm, $dIrHq->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto BzDYo;
        nI8Wt:
        if (!($NcJt_->driver == Rf7fPQasmK9R3::S3 && !$this->Celh5->exists($NcJt_->filename))) {
            goto k0c4m;
        }
        goto PrnCE;
        rSXTp:
        $dIrHq = $this->PAMAL->call($this, $this->Celh5->path($NcJt_->getLocation()));
        goto zoHbI;
        zoHbI:
        $o5smq = $dIrHq->width() / $dIrHq->height();
        goto E1x9p;
        E1x9p:
        $dIrHq->resize(self::rv7IZ, self::FO1M2 / $o5smq);
        goto uLTTq;
        Qjq6n:
        ini_set('memory_limit', '-1');
        goto nI8Wt;
        RYMFj:
        $this->Celh5->put($NcJt_->filename, $TKOdG);
        goto rgKbD;
        tc5du:
        WT_A0:
        goto B6Uuv;
        rgKbD:
        k0c4m:
        goto rSXTp;
        pwapC:
        $NcJt_ = FmmY71eXk0D8U::findOrFail($SEOXv);
        goto Qjq6n;
        B6Uuv:
        $NcJt_->update(['preview' => $ANxrm]);
        goto cBVBU;
        s26Ho:
        throw new \Exception('Failed to set final permissions on image file: ' . $XvBVB);
        goto tc5du;
        uLTTq:
        $dIrHq->blur(self::nH991);
        goto xx2v_;
        Zqkq4:
        if (chmod($XvBVB, 0664)) {
            goto WT_A0;
        }
        goto Pdiz3;
        Pdiz3:
        \Log::warning('Failed to set final permissions on image file: ' . $XvBVB);
        goto s26Ho;
        PrnCE:
        $TKOdG = $this->hFxUe->get($NcJt_->filename);
        goto RYMFj;
        cBVBU:
    }
    private function mrDOi780VNg($W2fxH) : string
    {
        goto FXyHx;
        JJQ9D:
        $this->Celh5->makeDirectory($lxDzB, 0755, true);
        goto HVGfa;
        HVGfa:
        dAReC:
        goto Us1gN;
        H9Bba:
        if ($this->Celh5->exists($lxDzB)) {
            goto dAReC;
        }
        goto JJQ9D;
        FXyHx:
        $liQkG = $W2fxH->getLocation();
        goto vml6l;
        vml6l:
        $lxDzB = dirname($liQkG) . '/preview/';
        goto H9Bba;
        Us1gN:
        return $lxDzB . $W2fxH->getFilename() . '.jpg';
        goto ZSfe3;
        ZSfe3:
    }
}
