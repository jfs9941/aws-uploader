<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Illuminate\Support\Facades\Log;
class LelhWj5hRA68a implements BlurVideoJobInterface
{
    const aY9dS = 15;
    const ANrIH = 500;
    const jYR2C = 500;
    private $xy0Yf;
    private $gErml;
    private $mzObC;
    public function __construct($ppK7O, $DFpIk, $L1VX0)
    {
        goto utjBp;
        utjBp:
        $this->mzObC = $L1VX0;
        goto dp3yN;
        boIM6:
        $this->xy0Yf = $ppK7O;
        goto ll551;
        dp3yN:
        $this->gErml = $DFpIk;
        goto boIM6;
        ll551:
    }
    public function blur(string $J_scC) : void
    {
        goto gU412;
        zThWr:
        if (!$RnUgV->getAttribute('thumbnail')) {
            goto yA50Z;
        }
        goto FmtnD;
        h4Kip:
        $NBdEx = $this->mzObC->path($qIpsP);
        goto BgrRU;
        z59xr:
        reaI2:
        goto DuV7d;
        fmZrT:
        $VWXEV->blur(self::aY9dS);
        goto hjql9;
        vhnVD:
        yA50Z:
        goto y3amv;
        J4Imn:
        $this->gErml->put($qIpsP, $this->mzObC->get($qIpsP));
        goto W5R7z;
        m3quU:
        ini_set('memory_limit', '-1');
        goto wvmU4;
        QhS13:
        throw new \Exception('Failed to set final permissions on image file: ' . $NBdEx);
        goto z59xr;
        VSRDe:
        \Log::warning('Failed to set final permissions on image file: ' . $NBdEx);
        goto QhS13;
        BgrRU:
        $VWXEV->save($NBdEx);
        goto J4Imn;
        J8IoN:
        $VWXEV->resize(self::ANrIH, self::jYR2C / $JKeeA);
        goto fmZrT;
        wvmU4:
        $RnUgV = BG2FRpwGrKqJx::findOrFail($J_scC);
        goto zThWr;
        yLP0K:
        $VWXEV = $this->xy0Yf->call($this, $this->mzObC->path($RnUgV->getAttribute('thumbnail')));
        goto D9oQ3;
        D9oQ3:
        $JKeeA = $VWXEV->width() / $VWXEV->height();
        goto J8IoN;
        W5R7z:
        unset($VWXEV);
        goto J1IBS;
        FmtnD:
        $this->mzObC->put($RnUgV->getAttribute('thumbnail'), $this->gErml->get($RnUgV->getAttribute('thumbnail')));
        goto yLP0K;
        hjql9:
        $qIpsP = $this->mKTAZroKjOI($RnUgV);
        goto h4Kip;
        gU412:
        Log::info("Blurring for video", ['videoID' => $J_scC]);
        goto m3quU;
        DuV7d:
        $RnUgV->update(['preview' => $qIpsP]);
        goto vhnVD;
        J1IBS:
        if (chmod($NBdEx, 0664)) {
            goto reaI2;
        }
        goto VSRDe;
        y3amv:
    }
    private function mKTAZroKjOI(YeOKDEuyU49Av $MPjk0) : string
    {
        goto x3Fgb;
        SqZUo:
        $this->mzObC->makeDirectory($uH7tx, 0755, true);
        goto pE2wy;
        x3Fgb:
        $hU2b_ = $MPjk0->getLocation();
        goto jIn_h;
        s3TlL:
        if ($this->mzObC->exists($uH7tx)) {
            goto IW1UI;
        }
        goto SqZUo;
        jIn_h:
        $uH7tx = dirname($hU2b_) . '/preview/';
        goto s3TlL;
        CgNeM:
        return $uH7tx . $MPjk0->getFilename() . '.jpg';
        goto CI35o;
        pE2wy:
        IW1UI:
        goto CgNeM;
        CI35o:
    }
}
