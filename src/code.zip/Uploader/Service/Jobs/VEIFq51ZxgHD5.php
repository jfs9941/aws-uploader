<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
class VEIFq51ZxgHD5 implements BlurJobInterface
{
    const l3YDx = 15;
    const YG24j = 500;
    const I1c9T = 500;
    private $SJRrZ;
    private $gGE8I;
    private $xbA_A;
    public function __construct($akc4V, $duBfR, $a_5ue)
    {
        goto i547F;
        WR3tL:
        $this->SJRrZ = $akc4V;
        goto L2puC;
        tbgTG:
        $this->gGE8I = $duBfR;
        goto WR3tL;
        i547F:
        $this->xbA_A = $a_5ue;
        goto tbgTG;
        L2puC:
    }
    public function blur(string $ld8Ad) : void
    {
        goto ZiG0N;
        M8FAX:
        $xobEP->blur(self::l3YDx);
        goto ebO7W;
        TPKms:
        $ShFvF = $this->xbA_A->path($DYrgW);
        goto Yfxf8;
        RC8eW:
        \Log::warning('Failed to set final permissions on image file: ' . $ShFvF);
        goto jcIsZ;
        ZiG0N:
        $UyUkP = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
        goto SJ8xd;
        ER57y:
        $LqyTb = $this->gGE8I->get($UyUkP->filename);
        goto A9jpx;
        Oj6vz:
        $xobEP->resize(self::YG24j, self::I1c9T / $vQG8k);
        goto M8FAX;
        jcIsZ:
        throw new \Exception('Failed to set final permissions on image file: ' . $ShFvF);
        goto R7TTw;
        igS4u:
        $vQG8k = $xobEP->width() / $xobEP->height();
        goto Oj6vz;
        JfEx7:
        if (chmod($ShFvF, 0664)) {
            goto e_LtK;
        }
        goto RC8eW;
        Yfxf8:
        $xobEP->save($ShFvF);
        goto F2DMt;
        LtJKv:
        if (!($UyUkP->jE_8B == ZBLpZ2qUZ4P6C::S3 && !$this->xbA_A->exists($UyUkP->filename))) {
            goto KE1vW;
        }
        goto ER57y;
        ebO7W:
        $DYrgW = $this->mnQ8tJizK2h($UyUkP);
        goto TPKms;
        F2DMt:
        unset($xobEP);
        goto JfEx7;
        SJ8xd:
        ini_set('memory_limit', '-1');
        goto LtJKv;
        K2Cmf:
        KE1vW:
        goto wnsyf;
        R7TTw:
        e_LtK:
        goto KfsxQ;
        KfsxQ:
        $UyUkP->update(['preview' => $DYrgW]);
        goto uPkgb;
        A9jpx:
        $this->xbA_A->put($UyUkP->filename, $LqyTb);
        goto K2Cmf;
        wnsyf:
        $xobEP = $this->SJRrZ->call($this, $this->xbA_A->path($UyUkP->getLocation()));
        goto igS4u;
        uPkgb:
    }
    private function mnQ8tJizK2h($PW97U) : string
    {
        goto NsFV6;
        YiXMG:
        xy5UZ:
        goto nCNpy;
        I6Wt2:
        $this->xbA_A->makeDirectory($BaehP, 0755, true);
        goto YiXMG;
        nCNpy:
        return $BaehP . $PW97U->getFilename() . '.jpg';
        goto Bo3Xy;
        NsFV6:
        $jGQTt = $PW97U->getLocation();
        goto qXOYn;
        PoMoS:
        if ($this->xbA_A->exists($BaehP)) {
            goto xy5UZ;
        }
        goto I6Wt2;
        qXOYn:
        $BaehP = dirname($jGQTt) . '/preview/';
        goto PoMoS;
        Bo3Xy:
    }
}
