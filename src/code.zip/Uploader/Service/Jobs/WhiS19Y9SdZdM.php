<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
class WhiS19Y9SdZdM implements WatermarkTextJobInterface
{
    private $mwf2R;
    private $ooQeq;
    private $U9NM5;
    private $Vhcrn;
    private $Lrwlv;
    public function __construct($eF8NA, $F_3Mm, $Klx1U, $AhP23, $MP0Wk)
    {
        goto dJdQw;
        grIpx:
        $this->Lrwlv = $AhP23;
        goto NQZ31;
        opJrr:
        $this->Vhcrn = $Klx1U;
        goto grIpx;
        u7P8n:
        $this->ooQeq = $F_3Mm;
        goto DjiRH;
        dJdQw:
        $this->mwf2R = $eF8NA;
        goto opJrr;
        NQZ31:
        $this->U9NM5 = $MP0Wk;
        goto u7P8n;
        DjiRH:
    }
    public function putWatermark(string $mfjeD, string $ATagl) : void
    {
        goto g61Hr;
        N6V_s:
        $HmKOk = memory_get_usage();
        goto GjFO2;
        vumCt:
        Log::info("Adding watermark text to image", ['imageId' => $mfjeD]);
        goto M0pWN;
        GjFO2:
        $ghcvh = memory_get_peak_usage();
        goto vumCt;
        g61Hr:
        $QEw_Q = microtime(true);
        goto N6V_s;
        jxjmh:
        try {
            goto o33ti;
            sFBR1:
            unset($edGSG);
            goto GUSLv;
            o33ti:
            $fK3zd = DsyQbNiy8VgJG::findOrFail($mfjeD);
            goto bxik5;
            XxsBC:
            L2qh8:
            goto bqISY;
            f9DVs:
            \Log::warning('Failed to set final permissions on image file: ' . $J9IgU);
            goto naWp1;
            NWIDJ:
            $edGSG->orient();
            goto z9N2e;
            GUSLv:
            if (chmod($J9IgU, 0664)) {
                goto p752a;
            }
            goto f9DVs;
            eKvd2:
            Log::error("DsyQbNiy8VgJG is not on local, might be deleted before put watermark", ['imageId' => $mfjeD]);
            goto QSWEU;
            bqISY:
            $J9IgU = $this->Lrwlv->path($fK3zd->getLocation());
            goto xhpfL;
            naWp1:
            throw new \Exception('Failed to set final permissions on image file: ' . $J9IgU);
            goto xqSZj;
            QSWEU:
            return;
            goto XxsBC;
            fDODz:
            $edGSG->save($J9IgU);
            goto sFBR1;
            xhpfL:
            $edGSG = $this->mwf2R->call($this, $J9IgU);
            goto NWIDJ;
            xqSZj:
            p752a:
            goto c6Qa7;
            z9N2e:
            $this->mFMLyuTKROG($edGSG, $ATagl);
            goto fDODz;
            bxik5:
            if ($this->Lrwlv->exists($fK3zd->getLocation())) {
                goto L2qh8;
            }
            goto eKvd2;
            c6Qa7:
        } catch (\Throwable $h6kqJ) {
            goto xMKM9;
            xMKM9:
            if (!$h6kqJ instanceof ModelNotFoundException) {
                goto QH4IB;
            }
            goto VYqD0;
            VYqD0:
            Log::info("DsyQbNiy8VgJG has been deleted, discard it", ['imageId' => $mfjeD]);
            goto zJx5c;
            XaIdu:
            QH4IB:
            goto rTCrT;
            zJx5c:
            return;
            goto XaIdu;
            rTCrT:
            Log::error("DsyQbNiy8VgJG is not readable", ['imageId' => $mfjeD, 'error' => $h6kqJ->getMessage()]);
            goto CJdtD;
            CJdtD:
        } finally {
            $j9xjg = microtime(true);
            $dJyQx = memory_get_usage();
            $RXP3o = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $mfjeD, 'execution_time_sec' => $j9xjg - $QEw_Q, 'memory_usage_mb' => ($dJyQx - $HmKOk) / 1024 / 1024, 'peak_memory_usage_mb' => ($RXP3o - $ghcvh) / 1024 / 1024]);
        }
        goto t8iUQ;
        M0pWN:
        ini_set('memory_limit', '-1');
        goto jxjmh;
        t8iUQ:
    }
    private function mFMLyuTKROG($edGSG, $ATagl) : void
    {
        goto WdzKx;
        SJKkZ:
        $this->Lrwlv->put($jK04r, $this->Vhcrn->get($jK04r));
        goto MpNxk;
        vNbIS:
        $E52ZJ = $edGSG->height();
        goto vymxx;
        vO5h_:
        $edGSG->place($MQenA, 'top-left', 0, 0, 30);
        goto WnJgS;
        vymxx:
        $dH34S = new TID08qSYJRKYD($this->ooQeq, $this->U9NM5, $this->Vhcrn, $this->Lrwlv);
        goto DHV2r;
        MpNxk:
        $MQenA = $this->mwf2R->call($this, $this->Lrwlv->path($jK04r));
        goto vO5h_;
        WdzKx:
        $aio9s = $edGSG->width();
        goto vNbIS;
        DHV2r:
        $jK04r = $dH34S->meptZfZfkod($aio9s, $E52ZJ, $ATagl, true);
        goto SJKkZ;
        WnJgS:
    }
}
