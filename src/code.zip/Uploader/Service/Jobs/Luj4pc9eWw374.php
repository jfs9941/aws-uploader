<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Illuminate\Support\Facades\Log;
class Luj4pc9eWw374 implements BlurVideoJobInterface
{
    const bTlMo = 15;
    const jH5gF = 500;
    const IIiB9 = 500;
    private $z7YJI;
    private $PxC6l;
    private $MpAl4;
    public function __construct($fvRbj, $kxhX9, $U2KRS)
    {
        goto i2aDM;
        i2aDM:
        $this->MpAl4 = $U2KRS;
        goto NM8Ks;
        NM8Ks:
        $this->PxC6l = $kxhX9;
        goto cG53L;
        cG53L:
        $this->z7YJI = $fvRbj;
        goto pjBMP;
        pjBMP:
    }
    public function blur(string $S580N) : void
    {
        goto GKAE_;
        U5tEt:
        \Log::warning('Failed to set final permissions on image file: ' . $j4iKK);
        goto hI9xw;
        R2iVZ:
        $JC9uJ = $gNhb4->width() / $gNhb4->height();
        goto Y6rK1;
        QKQZl:
        YHsX0:
        goto m1T3v;
        eYiiL:
        ini_set('memory_limit', '-1');
        goto qPuIQ;
        o86Gq:
        $gNhb4->save($j4iKK);
        goto I9Fd4;
        TYdqo:
        $K5DbU = $this->mE1oPwTqx6V($FMXvN);
        goto f6qTR;
        Y6rK1:
        $gNhb4->resize(self::jH5gF, self::IIiB9 / $JC9uJ);
        goto PLDkk;
        f6qTR:
        $j4iKK = $this->MpAl4->path($K5DbU);
        goto o86Gq;
        hI9xw:
        throw new \Exception('Failed to set final permissions on image file: ' . $j4iKK);
        goto QKQZl;
        PUdMl:
        $gNhb4 = $this->z7YJI->call($this, $this->MpAl4->path($FMXvN->getAttribute('thumbnail')));
        goto R2iVZ;
        m1T3v:
        $FMXvN->update(['preview' => $K5DbU]);
        goto oxRoA;
        oxRoA:
        YtPKd:
        goto I1OHE;
        GKAE_:
        Log::info("Blurring for video", ['videoID' => $S580N]);
        goto eYiiL;
        ChuU8:
        $this->MpAl4->put($FMXvN->getAttribute('thumbnail'), $this->PxC6l->get($FMXvN->getAttribute('thumbnail')));
        goto PUdMl;
        PLDkk:
        $gNhb4->blur(self::bTlMo);
        goto TYdqo;
        qwScS:
        unset($gNhb4);
        goto jxeYW;
        jxeYW:
        if (chmod($j4iKK, 0664)) {
            goto YHsX0;
        }
        goto U5tEt;
        ADlf2:
        if (!$FMXvN->getAttribute('thumbnail')) {
            goto YtPKd;
        }
        goto ChuU8;
        qPuIQ:
        $FMXvN = BtruCfJoaSWZ6::findOrFail($S580N);
        goto ADlf2;
        I9Fd4:
        $this->PxC6l->put($K5DbU, $this->MpAl4->get($K5DbU));
        goto qwScS;
        I1OHE:
    }
    private function mE1oPwTqx6V(OfMUIxZzii9Zu $BhlEo) : string
    {
        goto a00jb;
        NYSAJ:
        if ($this->MpAl4->exists($zVNDR)) {
            goto yAavx;
        }
        goto MkQUF;
        MzbrB:
        return $zVNDR . $BhlEo->getFilename() . '.jpg';
        goto fIBvq;
        a00jb:
        $d1QWa = $BhlEo->getLocation();
        goto ETQKu;
        WN3qz:
        yAavx:
        goto MzbrB;
        ETQKu:
        $zVNDR = dirname($d1QWa) . '/preview/';
        goto NYSAJ;
        MkQUF:
        $this->MpAl4->makeDirectory($zVNDR, 0755, true);
        goto WN3qz;
        fIBvq:
    }
}
