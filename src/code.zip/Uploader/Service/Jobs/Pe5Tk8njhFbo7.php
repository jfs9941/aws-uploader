<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class Pe5Tk8njhFbo7 implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $Qu08p) : void
    {
        goto Qo9hY;
        Qo9hY:
        $X0ufS = SmhkgG6le5p0r::findOrFail($Qu08p);
        goto eiKP7;
        eiKP7:
        if ($X0ufS->width() > 0 && $X0ufS->height() > 0) {
            goto TqrYR;
        }
        goto CjOhF;
        kISHc:
        TqrYR:
        goto T7HD9;
        CjOhF:
        $this->mx7xnLucxCF($X0ufS);
        goto kISHc;
        T7HD9:
    }
    private function mx7xnLucxCF(SmhkgG6le5p0r $FR_h8) : void
    {
        goto jD6sT;
        JSkvq:
        $poKNK = $BPQbo->getDimensions();
        goto tC2p2;
        jD6sT:
        $Th0F7 = $FR_h8->getView();
        goto u1E3A;
        tC2p2:
        $FR_h8->update(['duration' => $Y6vHu->getDurationInSeconds(), 'resolution' => $poKNK->getWidth() . 'x' . $poKNK->getHeight(), 'fps' => $BPQbo->get('r_frame_rate') ?? 30]);
        goto EKJKp;
        u1E3A:
        $Y6vHu = FFMpeg::fromDisk($Th0F7['path'])->open($FR_h8->getAttribute('filename'));
        goto gX0bH;
        gX0bH:
        $BPQbo = $Y6vHu->getVideoStream();
        goto JSkvq;
        EKJKp:
    }
}
