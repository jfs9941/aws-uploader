<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class Vn8jgXvFddzmt
{
    private $rXTE1;
    private $whLk_;
    public function __construct(int $L_DD4, int $p7nPV)
    {
        goto wILta;
        g_Ux2:
        $this->rXTE1 = $L_DD4;
        goto oBWAu;
        oBWAu:
        $this->whLk_ = $p7nPV;
        goto gdiJy;
        XSwqs:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto y4ig1;
        BtuTr:
        xZKho:
        goto cAv4o;
        y4ig1:
        F0zkP:
        goto g_Ux2;
        cAv4o:
        if (!($p7nPV <= 0)) {
            goto F0zkP;
        }
        goto XSwqs;
        wILta:
        if (!($L_DD4 <= 0)) {
            goto xZKho;
        }
        goto GGtex;
        GGtex:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto BtuTr;
        gdiJy:
    }
    private static function mLmgJUosEou($M4lhr, string $ZMu1m = 'floor') : int
    {
        goto eYzrC;
        b3rDS:
        switch (strtolower($ZMu1m)) {
            case 'ceil':
                return (int) (ceil($M4lhr / 2) * 2);
            case 'round':
                return (int) (round($M4lhr / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($M4lhr / 2) * 2);
        }
        goto ctK6x;
        EC3_0:
        yX4I7:
        goto b3rDS;
        Aiz8u:
        if (!(is_float($M4lhr) && $M4lhr == floor($M4lhr) && (int) $M4lhr % 2 === 0)) {
            goto yX4I7;
        }
        goto aJPu2;
        jbbHh:
        return $M4lhr;
        goto J74jL;
        eYzrC:
        if (!(is_int($M4lhr) && $M4lhr % 2 === 0)) {
            goto FY13M;
        }
        goto jbbHh;
        ctK6x:
        kkcx6:
        goto e6iiD;
        J74jL:
        FY13M:
        goto Aiz8u;
        e6iiD:
        cQPUI:
        goto z5aY9;
        aJPu2:
        return (int) $M4lhr;
        goto EC3_0;
        z5aY9:
    }
    public function my6nkWhyeQp(string $dBaqP = 'floor') : array
    {
        goto dIMvk;
        cNSS_:
        yRr78:
        goto aSuuy;
        jMoje:
        $HlhDo = 0;
        goto jFDXK;
        ytC4h:
        if ($this->rXTE1 >= $this->whLk_) {
            goto vx6E8;
        }
        goto Z4i3K;
        klyP8:
        $HDK9Q = $HlhDo / $this->rXTE1;
        goto tHbag;
        kvWa7:
        $HlhDo = self::mLmgJUosEou(round($Hdwe9), $dBaqP);
        goto rDVXI;
        zfXwK:
        $eL8bt = $iFlkM;
        goto KRw4a;
        rDVXI:
        HJK4R:
        goto aZM1H;
        aSuuy:
        return ['width' => $HlhDo, 'height' => $eL8bt];
        goto gGmSH;
        dIMvk:
        $iFlkM = 1080;
        goto jMoje;
        tHbag:
        $gZ_8F = $this->whLk_ * $HDK9Q;
        goto RfiMW;
        Elrtl:
        goto HJK4R;
        goto nYKuV;
        nYKuV:
        vx6E8:
        goto zfXwK;
        JkvTB:
        if (!($eL8bt < 2)) {
            goto yRr78;
        }
        goto R7CpR;
        Z4i3K:
        $HlhDo = $iFlkM;
        goto klyP8;
        R7CpR:
        $eL8bt = 2;
        goto cNSS_;
        RfiMW:
        $eL8bt = self::mLmgJUosEou(round($gZ_8F), $dBaqP);
        goto Elrtl;
        rv7E_:
        $Hdwe9 = $this->rXTE1 * $HDK9Q;
        goto kvWa7;
        DQ_Si:
        egx2s:
        goto JkvTB;
        KRw4a:
        $HDK9Q = $eL8bt / $this->whLk_;
        goto rv7E_;
        jFDXK:
        $eL8bt = 0;
        goto ytC4h;
        aZM1H:
        if (!($HlhDo < 2)) {
            goto egx2s;
        }
        goto mH6v8;
        mH6v8:
        $HlhDo = 2;
        goto DQ_Si;
        gGmSH:
    }
}
