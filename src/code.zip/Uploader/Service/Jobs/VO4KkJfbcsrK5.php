<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class VO4KkJfbcsrK5 implements GenerateThumbnailForVideoInterface
{
    private $BeTuk;
    public function __construct($D61aE)
    {
        $this->BeTuk = $D61aE;
    }
    public function generate(string $FILUb) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $FILUb);
        $this->BeTuk->createThumbnail($FILUb);
    }
}
