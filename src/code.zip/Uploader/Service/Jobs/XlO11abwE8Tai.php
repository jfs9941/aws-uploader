<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class XlO11abwE8Tai implements GenerateThumbnailForVideoInterface
{
    private $LFJaZ;
    public function __construct($wb5lI)
    {
        $this->LFJaZ = $wb5lI;
    }
    public function generate(string $wAkkA) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $wAkkA);
        $this->LFJaZ->createThumbnail($wAkkA);
    }
}
