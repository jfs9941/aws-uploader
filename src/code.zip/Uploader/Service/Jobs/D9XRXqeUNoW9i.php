<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class D9XRXqeUNoW9i
{
    private $BJUul;
    private $ef1uA;
    public function __construct(int $WJira, int $obgZN)
    {
        goto KP66J;
        TxrA9:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto JMgH0;
        nL6Hl:
        $this->BJUul = $WJira;
        goto lxTnW;
        KP66J:
        if (!($WJira <= 0)) {
            goto wQLYX;
        }
        goto TxrA9;
        JMgH0:
        wQLYX:
        goto bLni3;
        lxTnW:
        $this->ef1uA = $obgZN;
        goto gTvla;
        GI17W:
        OxuOb:
        goto nL6Hl;
        CrCLR:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto GI17W;
        bLni3:
        if (!($obgZN <= 0)) {
            goto OxuOb;
        }
        goto CrCLR;
        gTvla:
    }
    private static function mWUkFR7SFqk($fRbMD, string $b8qBD = 'floor') : int
    {
        goto eRo4Y;
        om3pt:
        Top50:
        goto x4mRD;
        RmTbC:
        lQWlZ:
        goto RBYMJ;
        eRo4Y:
        if (!(is_int($fRbMD) && $fRbMD % 2 === 0)) {
            goto Top50;
        }
        goto vbQUd;
        ZLone:
        ZcJoa:
        goto vgWm4;
        vgWm4:
        LMwy0:
        goto SyVuf;
        wWpT4:
        return (int) $fRbMD;
        goto RmTbC;
        vbQUd:
        return $fRbMD;
        goto om3pt;
        x4mRD:
        if (!(is_float($fRbMD) && $fRbMD == floor($fRbMD) && (int) $fRbMD % 2 === 0)) {
            goto lQWlZ;
        }
        goto wWpT4;
        RBYMJ:
        switch (strtolower($b8qBD)) {
            case 'ceil':
                return (int) (ceil($fRbMD / 2) * 2);
            case 'round':
                return (int) (round($fRbMD / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($fRbMD / 2) * 2);
        }
        goto ZLone;
        SyVuf:
    }
    public function mKpMMcKcNnM(string $nb_x6 = 'floor') : array
    {
        goto vrvpU;
        zkdpZ:
        $qCo6E = 0;
        goto hkuve;
        VcywI:
        $nxSk6 = 2;
        goto N0Ols;
        T3NBJ:
        $YuAod = $this->BJUul * $vyxdh;
        goto ANobx;
        WxCxG:
        $nxSk6 = $QmNst;
        goto hZQga;
        KIePD:
        if (!($nxSk6 < 2)) {
            goto PB40e;
        }
        goto VcywI;
        gNA0n:
        $nxSk6 = 0;
        goto zkdpZ;
        VajqB:
        if (!($qCo6E < 2)) {
            goto x__AJ;
        }
        goto PElbE;
        hZQga:
        $vyxdh = $nxSk6 / $this->BJUul;
        goto Dvr4z;
        fUafh:
        $qCo6E = self::mWUkFR7SFqk(round($w4Vsk), $nb_x6);
        goto Yf0yp;
        vrvpU:
        $QmNst = 1080;
        goto gNA0n;
        ANobx:
        $nxSk6 = self::mWUkFR7SFqk(round($YuAod), $nb_x6);
        goto Ln3tP;
        hkuve:
        if ($this->BJUul >= $this->ef1uA) {
            goto JFDim;
        }
        goto WxCxG;
        Ewvaw:
        $qCo6E = $QmNst;
        goto cuZS3;
        N0Ols:
        PB40e:
        goto VajqB;
        ca5jr:
        JFDim:
        goto Ewvaw;
        cuZS3:
        $vyxdh = $qCo6E / $this->ef1uA;
        goto T3NBJ;
        Ln3tP:
        VEbQW:
        goto KIePD;
        Dvr4z:
        $w4Vsk = $this->ef1uA * $vyxdh;
        goto fUafh;
        Yf0yp:
        goto VEbQW;
        goto ca5jr;
        SGMUU:
        x__AJ:
        goto nYWKp;
        PElbE:
        $qCo6E = 2;
        goto SGMUU;
        nYWKp:
        return ['width' => $nxSk6, 'height' => $qCo6E];
        goto WIWuX;
        WIWuX:
    }
}
