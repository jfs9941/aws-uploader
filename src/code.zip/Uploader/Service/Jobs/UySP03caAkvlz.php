<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
class UySP03caAkvlz implements BlurVideoJobInterface
{
    const IMf0z = 15;
    const tqPMm = 500;
    const NMW3N = 500;
    private $TMqxn;
    private $IRlXr;
    private $foEoP;
    public function __construct($xskW6, $JGvdR, $VGndK)
    {
        goto Tcc1v;
        VFHoI:
        $this->IRlXr = $JGvdR;
        goto pboSm;
        Tcc1v:
        $this->foEoP = $VGndK;
        goto VFHoI;
        pboSm:
        $this->TMqxn = $xskW6;
        goto Dq20X;
        Dq20X:
    }
    public function blur(string $R7IrL) : void
    {
        goto QKRCM;
        v_Hbz:
        $this->foEoP->put($IA_1I->getAttribute('thumbnail'), $this->IRlXr->get($IA_1I->getAttribute('thumbnail')));
        goto wC3RS;
        bcHqy:
        if (!$IA_1I->getAttribute('thumbnail')) {
            goto QAJeK;
        }
        goto v_Hbz;
        tw1L_:
        ini_set('memory_limit', '-1');
        goto skw9O;
        QKRCM:
        Log::info("Blurring for video", ['videoID' => $R7IrL]);
        goto tw1L_;
        CmcDw:
        $Xxl6q->save($gFaXo);
        goto uxls_;
        ZpE1k:
        throw new \Exception('Failed to set final permissions on image file: ' . $gFaXo);
        goto L7IUe;
        YgoOp:
        $lN9cc = $Xxl6q->width() / $Xxl6q->height();
        goto vuFR9;
        uxls_:
        $this->IRlXr->put($s2oYj, $this->foEoP->get($s2oYj));
        goto ef_ve;
        skw9O:
        $IA_1I = B6s4AA1exjQ2T::findOrFail($R7IrL);
        goto bcHqy;
        ef_ve:
        $Xxl6q->destroy();
        goto EsJ9Y;
        e16uj:
        $Xxl6q->blur(self::IMf0z);
        goto lKz8D;
        vuFR9:
        $Xxl6q->resize(self::tqPMm, self::NMW3N / $lN9cc);
        goto e16uj;
        bMCET:
        \Log::warning('Failed to set final permissions on image file: ' . $gFaXo);
        goto ZpE1k;
        wC3RS:
        $Xxl6q = $this->TMqxn->call($this, $this->foEoP->path($IA_1I->getAttribute('thumbnail')));
        goto YgoOp;
        EsJ9Y:
        if (chmod($gFaXo, 0664)) {
            goto arP6Y;
        }
        goto bMCET;
        lKz8D:
        $s2oYj = $this->mn5o9IOn4V0($IA_1I);
        goto tWaWl;
        uIs1q:
        $IA_1I->update(['preview' => $s2oYj]);
        goto bSxYS;
        bSxYS:
        QAJeK:
        goto LXo_h;
        L7IUe:
        arP6Y:
        goto uIs1q;
        tWaWl:
        $gFaXo = $this->foEoP->path($s2oYj);
        goto CmcDw;
        LXo_h:
    }
    private function mn5o9IOn4V0(KO2pC9qLVd4GD $YTWPZ) : string
    {
        goto dzxj7;
        dzxj7:
        $XkdbN = $YTWPZ->getLocation();
        goto bDXun;
        suxuG:
        if ($this->foEoP->exists($gdRmc)) {
            goto OxZLU;
        }
        goto pNO12;
        bDXun:
        $gdRmc = dirname($XkdbN) . '/preview/';
        goto suxuG;
        pNO12:
        $this->foEoP->makeDirectory($gdRmc, 0755, true);
        goto OXPcE;
        gaw2j:
        return $gdRmc . $YTWPZ->getFilename() . '.jpg';
        goto BT3ZW;
        OXPcE:
        OxZLU:
        goto gaw2j;
        BT3ZW:
    }
}
