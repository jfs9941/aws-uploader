<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
class UkLzQjDoxgOPs implements BlurJobInterface
{
    const nYHSl = 15;
    const ycJ33 = 500;
    const L31tq = 500;
    private $buleS;
    private $UoQI7;
    private $pCaD7;
    public function __construct($nFvaK, $UjVft, $P3zvl)
    {
        goto kMLpp;
        kMLpp:
        $this->pCaD7 = $P3zvl;
        goto m12Ns;
        m12Ns:
        $this->UoQI7 = $UjVft;
        goto PyJ3s;
        PyJ3s:
        $this->buleS = $nFvaK;
        goto dyFQv;
        dyFQv:
    }
    public function blur(string $InHEz) : void
    {
        goto G2ubs;
        G2ubs:
        $Oyqlq = UKkbXBDRxjSUY::findOrFail($InHEz);
        goto IIrdG;
        cnEuP:
        \Log::warning('Failed to set final permissions on image file: ' . $vBiuG);
        goto H3YTa;
        uW8Px:
        unset($VGttq);
        goto ibila;
        H3YTa:
        throw new \Exception('Failed to set final permissions on image file: ' . $vBiuG);
        goto LVR2h;
        e6q2D:
        Wz34K:
        goto Cg_15;
        s_jJY:
        $Aj9Of = $this->mb3XeVOKROc($Oyqlq);
        goto carrk;
        BkHSB:
        $Oyqlq->update(['preview' => $Aj9Of]);
        goto vUi03;
        IX7vQ:
        $VGttq->resize(self::ycJ33, self::L31tq / $BbstY);
        goto HITD8;
        Cg_15:
        $VGttq = $this->buleS->call($this, $this->pCaD7->path($Oyqlq->getLocation()));
        goto DZH8K;
        utHzY:
        if (!($Oyqlq->driver == YJGCddWUf6Zu2::S3 && !$this->pCaD7->exists($Oyqlq->filename))) {
            goto Wz34K;
        }
        goto EI0Vn;
        IIrdG:
        ini_set('memory_limit', '-1');
        goto utHzY;
        wpskM:
        $this->pCaD7->put($Oyqlq->filename, $T6mSg);
        goto e6q2D;
        carrk:
        $vBiuG = $this->UoQI7->put($Aj9Of, $VGttq->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto uW8Px;
        LVR2h:
        pfh5U:
        goto BkHSB;
        EI0Vn:
        $T6mSg = $this->UoQI7->get($Oyqlq->filename);
        goto wpskM;
        ibila:
        if (chmod($vBiuG, 0664)) {
            goto pfh5U;
        }
        goto cnEuP;
        HITD8:
        $VGttq->blur(self::nYHSl);
        goto s_jJY;
        DZH8K:
        $BbstY = $VGttq->width() / $VGttq->height();
        goto IX7vQ;
        vUi03:
    }
    private function mb3XeVOKROc($d8G8J) : string
    {
        goto omHd0;
        J8IXB:
        $jY69S = dirname($hKqqZ) . '/preview/';
        goto cpyFZ;
        omHd0:
        $hKqqZ = $d8G8J->getLocation();
        goto J8IXB;
        GdzXT:
        return $jY69S . $d8G8J->getFilename() . '.jpg';
        goto k3Ztt;
        XUXG7:
        AXhl3:
        goto GdzXT;
        cpyFZ:
        if ($this->pCaD7->exists($jY69S)) {
            goto AXhl3;
        }
        goto HWp3L;
        HWp3L:
        $this->pCaD7->makeDirectory($jY69S, 0755, true);
        goto XUXG7;
        k3Ztt:
    }
}
