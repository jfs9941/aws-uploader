<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Illuminate\Support\Facades\Log;
class ZV7rzOxLGIOtP implements BlurVideoJobInterface
{
    const ytBnH = 15;
    const b705n = 500;
    const yf4OB = 500;
    private $wil31;
    private $ZN9hu;
    private $MuT3J;
    public function __construct($jwYYV, $C2YXG, $tBTgN)
    {
        goto s72uT;
        s72uT:
        $this->MuT3J = $tBTgN;
        goto UEd8n;
        pzVTf:
        $this->wil31 = $jwYYV;
        goto Aqyhe;
        UEd8n:
        $this->ZN9hu = $C2YXG;
        goto pzVTf;
        Aqyhe:
    }
    public function blur(string $uuHkQ) : void
    {
        goto WlWgj;
        PVZGp:
        $o0xTX->update(['preview' => $IYAfF]);
        goto YiYrA;
        YiYrA:
        o9MXN:
        goto ymNb4;
        o6EIt:
        $IYAfF = $this->mHQ0rVDrgXm($o0xTX);
        goto aT4Nh;
        JKSgf:
        $this->ZN9hu->put($IYAfF, $this->MuT3J->get($IYAfF));
        goto SwoNG;
        SXMmK:
        $tCWWG = $this->wil31->call($this, $this->MuT3J->path($o0xTX->getAttribute('thumbnail')));
        goto V18JS;
        WlWgj:
        Log::info("Blurring for video", ['videoID' => $uuHkQ]);
        goto T6H93;
        T6H93:
        ini_set('memory_limit', '-1');
        goto Ic1ON;
        lUsCV:
        $tCWWG->blur(self::ytBnH);
        goto o6EIt;
        Ic1ON:
        $o0xTX = WrCq6RmnGcVh7::findOrFail($uuHkQ);
        goto SERRy;
        SwoNG:
        unset($tCWWG);
        goto r_IPv;
        XB77z:
        $tCWWG->save($oaqq9);
        goto JKSgf;
        f4Ram:
        throw new \Exception('Failed to set final permissions on image file: ' . $oaqq9);
        goto VkoGK;
        aT4Nh:
        $oaqq9 = $this->MuT3J->path($IYAfF);
        goto XB77z;
        r_IPv:
        if (chmod($oaqq9, 0664)) {
            goto m21R6;
        }
        goto UAJPg;
        MpvCq:
        $this->MuT3J->put($o0xTX->getAttribute('thumbnail'), $this->ZN9hu->get($o0xTX->getAttribute('thumbnail')));
        goto SXMmK;
        V18JS:
        $GOvRp = $tCWWG->width() / $tCWWG->height();
        goto rWjFb;
        UAJPg:
        \Log::warning('Failed to set final permissions on image file: ' . $oaqq9);
        goto f4Ram;
        VkoGK:
        m21R6:
        goto PVZGp;
        rWjFb:
        $tCWWG->resize(self::b705n, self::yf4OB / $GOvRp);
        goto lUsCV;
        SERRy:
        if (!$o0xTX->getAttribute('thumbnail')) {
            goto o9MXN;
        }
        goto MpvCq;
        ymNb4:
    }
    private function mHQ0rVDrgXm(QLOMBcv8tw1Qd $c4EHm) : string
    {
        goto gcB0C;
        z2Zl2:
        return $fgheN . $c4EHm->getFilename() . '.jpg';
        goto WaUNU;
        e1aDY:
        Wramu:
        goto z2Zl2;
        Xc294:
        $fgheN = dirname($dSgog) . '/preview/';
        goto JcbQv;
        JcbQv:
        if ($this->MuT3J->exists($fgheN)) {
            goto Wramu;
        }
        goto oBZBS;
        gcB0C:
        $dSgog = $c4EHm->getLocation();
        goto Xc294;
        oBZBS:
        $this->MuT3J->makeDirectory($fgheN, 0755, true);
        goto e1aDY;
        WaUNU:
    }
}
