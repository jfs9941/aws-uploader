<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\JyZaxpharsbun;
class RmktOLti8ErWo implements DownloadToLocalJobInterface
{
    private $zTo0t;
    private $uBhrQ;
    public function __construct($Vi8xq, $Ms6sq)
    {
        $this->zTo0t = $Vi8xq;
        $this->uBhrQ = $Ms6sq;
    }
    public function download(string $S6xyJ) : void
    {
        goto ckZNu;
        eFhJd:
        $this->uBhrQ->put($VZzWw->getLocation(), $this->zTo0t->get($VZzWw->getLocation()));
        goto VTCQw;
        XVPwL:
        return;
        goto gfM3N;
        gfM3N:
        NjNYl:
        goto eFhJd;
        tEyib:
        if (!$this->uBhrQ->exists($VZzWw->getLocation())) {
            goto NjNYl;
        }
        goto XVPwL;
        ckZNu:
        $VZzWw = JyZaxpharsbun::findOrFail($S6xyJ);
        goto y17K0;
        y17K0:
        Log::info("Start download file to local", ['fileId' => $S6xyJ, 'filename' => $VZzWw->getLocation()]);
        goto tEyib;
        VTCQw:
    }
}
