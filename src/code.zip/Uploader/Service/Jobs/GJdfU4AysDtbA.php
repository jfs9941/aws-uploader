<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class GJdfU4AysDtbA implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $cQqZd) : void
    {
        goto lrT11;
        m08ux:
        if ($WKps1->width() > 0 && $WKps1->height() > 0) {
            goto xvffL;
        }
        goto RHl4D;
        lrT11:
        $WKps1 = G4MP13yRAmltw::findOrFail($cQqZd);
        goto m08ux;
        RHl4D:
        $this->mmtxk0Kuh43($WKps1);
        goto KPoIT;
        KPoIT:
        xvffL:
        goto NwfcT;
        NwfcT:
    }
    private function mmtxk0Kuh43(G4MP13yRAmltw $wF34p) : void
    {
        goto JtJJm;
        IXTx_:
        $uK2Ki = $bqUCq->getDimensions();
        goto tT8qt;
        tT8qt:
        $wF34p->update(['duration' => $ahBEB->getDurationInSeconds(), 'resolution' => $uK2Ki->getWidth() . 'x' . $uK2Ki->getHeight(), 'fps' => $bqUCq->get('r_frame_rate') ?? 30]);
        goto pVCSI;
        JtJJm:
        $Q2Ihy = $wF34p->getView();
        goto c6KrX;
        t6Ng8:
        $bqUCq = $ahBEB->getVideoStream();
        goto IXTx_;
        c6KrX:
        $ahBEB = FFMpeg::fromDisk($Q2Ihy['path'])->open($wF34p->getAttribute('filename'));
        goto t6Ng8;
        pVCSI:
    }
}
