<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class WJRFs5dkBBuwo
{
    private $AQqBe;
    private $wmqIG;
    private $ifs25;
    private $kduDw;
    public function __construct($RuaCx, $mECUN, $PQlIa, $h5ffz)
    {
        goto GvgXA;
        GvgXA:
        $this->wmqIG = $mECUN;
        goto HVYfc;
        HVYfc:
        $this->ifs25 = $PQlIa;
        goto arU6k;
        arU6k:
        $this->kduDw = $h5ffz;
        goto lsV2X;
        lsV2X:
        $this->AQqBe = $RuaCx;
        goto p5H3v;
        p5H3v:
    }
    public function mRsy9eF6dlc(?int $NixDl, ?int $l4GK0, string $FmRvX, bool $mZkXl = false) : string
    {
        goto wRPuJ;
        wKs3m:
        xavxl:
        goto zQCzr;
        L1BWF:
        $Smbej = (int) ($ixZGg / 80);
        goto Pz3Dn;
        vXIvs:
        throw new \RuntimeException("CSQMvXC33KbbS dimensions are not available.");
        goto Hkbhm;
        w3ADD:
        $sEueW = $this->m5vdEkxKrxA($KDRmK, $NixDl, $l4GK0, $Xu9s1, $ukxcz);
        goto t71yR;
        pYY5k:
        $ixZGg -= $Smbej * 0.4;
        goto p1dyW;
        UOoit:
        list($ukxcz, $Xu9s1, $KDRmK) = $this->m5kgm8kw5Ly($FmRvX, $NixDl, $vK0c1, (float) $NixDl / $l4GK0);
        goto w3ADD;
        FKCkM:
        $bhlq_ = $l4GK0 - $ukxcz - 10;
        goto PaQtm;
        p1dyW:
        J4URX:
        goto FKCkM;
        Hkbhm:
        JqmUJ:
        goto ujTin;
        pb3_s:
        return $mZkXl ? $sEueW : $this->ifs25->url($sEueW);
        goto wKs3m;
        QQtnE:
        $this->kduDw->put($sEueW, $SYKC9->stream('png'));
        goto N99Rz;
        t71yR:
        if (!$this->ifs25->exists($sEueW)) {
            goto xavxl;
        }
        goto pb3_s;
        PaQtm:
        $SYKC9->text($KDRmK, $ixZGg, (int) $bhlq_, function ($XS5U_) use($ukxcz) {
            goto ReGej;
            ReGej:
            $XS5U_->file(public_path($this->wmqIG));
            goto NvjwG;
            DzF1l:
            $XS5U_->color([185, 185, 185, 1]);
            goto FyJq3;
            FyJq3:
            $XS5U_->valign('middle');
            goto F4Yo1;
            F4Yo1:
            $XS5U_->align('middle');
            goto QTUpk;
            YvB8J:
            $XS5U_->size(max($xu5jf, 1));
            goto DzF1l;
            NvjwG:
            $xu5jf = (int) ($ukxcz * 1.2);
            goto YvB8J;
            QTUpk:
        });
        goto QQtnE;
        ryiIt:
        $ixZGg = $NixDl - $Xu9s1;
        goto L1BWF;
        N99Rz:
        $this->ifs25->put($sEueW, $SYKC9->stream('png'));
        goto NZOjX;
        ujTin:
        $vK0c1 = 0.1;
        goto UOoit;
        wRPuJ:
        if (!($NixDl === null || $l4GK0 === null)) {
            goto JqmUJ;
        }
        goto vXIvs;
        zQCzr:
        $SYKC9 = $this->AQqBe->call($this, $NixDl, $l4GK0);
        goto ryiIt;
        NZOjX:
        return $mZkXl ? $sEueW : $this->ifs25->url($sEueW);
        goto ggqPY;
        Pz3Dn:
        $ixZGg -= $Smbej;
        goto MJZJH;
        MJZJH:
        if (!($NixDl > 1500)) {
            goto J4URX;
        }
        goto pYY5k;
        ggqPY:
    }
    private function m5vdEkxKrxA(string $FmRvX, int $NixDl, int $l4GK0, int $lBbOB, int $VUyOn) : string
    {
        $l5psz = ltrim($FmRvX, '@');
        return "v2/watermark/{$l5psz}/{$NixDl}x{$l4GK0}_{$lBbOB}x{$VUyOn}/text_watermark.png";
    }
    private function m5kgm8kw5Ly($FmRvX, int $NixDl, float $B5TZQ, float $Ubt2R) : array
    {
        goto umKbI;
        TD9hv:
        pjeui:
        goto etKJB;
        umKbI:
        $KDRmK = '@' . $FmRvX;
        goto jEPoa;
        XNn1B:
        return [(int) $ZW9yF, $ZW9yF * strlen($KDRmK) / 1.8, $KDRmK];
        goto TD9hv;
        V1s4H:
        return [(int) $ZW9yF, $Xu9s1, $KDRmK];
        goto XObHE;
        jEPoa:
        $Xu9s1 = (int) ($NixDl * $B5TZQ);
        goto zWsaU;
        zWsaU:
        if (!($Ubt2R > 1)) {
            goto pjeui;
        }
        goto CM07E;
        CM07E:
        $ZW9yF = $Xu9s1 / (strlen($KDRmK) * 0.8);
        goto XNn1B;
        etKJB:
        $ZW9yF = 1 / $Ubt2R * $Xu9s1 / strlen($KDRmK);
        goto V1s4H;
        XObHE:
    }
}
