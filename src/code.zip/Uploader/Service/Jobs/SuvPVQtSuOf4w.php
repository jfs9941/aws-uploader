<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Service\Jobs\BDQtoSYw7RsgD;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class SuvPVQtSuOf4w implements WatermarkTextJobInterface
{
    private $GqFb6;
    private $cQzus;
    private $cZsgg;
    private $BfyCm;
    private $c5PSU;
    public function __construct($WV89v, $Iv4Wx, $ejImE, $Ape3_, $N5C9l)
    {
        goto rjhAU;
        e_Mwr:
        $this->cZsgg = $N5C9l;
        goto EbPzZ;
        rjhAU:
        $this->GqFb6 = $WV89v;
        goto DVUD5;
        EbPzZ:
        $this->cQzus = $Iv4Wx;
        goto cVUjY;
        Zli74:
        $this->c5PSU = $Ape3_;
        goto e_Mwr;
        DVUD5:
        $this->BfyCm = $ejImE;
        goto Zli74;
        cVUjY:
    }
    public function putWatermark(string $aK0gt, string $w91p_) : void
    {
        goto KhHHp;
        Iw0sB:
        $SwK9A = memory_get_peak_usage();
        goto CQqB7;
        qk6P7:
        $bzMw6 = memory_get_usage();
        goto Iw0sB;
        L11AK:
        try {
            goto UCkwS;
            hDQQz:
            throw new \Exception('Failed to set final permissions on image file: ' . $HyAAV);
            goto KwNth;
            Un94J:
            $HyAAV = $this->c5PSU->path($qKtXa->getLocation());
            goto x63_a;
            ZF05N:
            unset($BXhsT);
            goto Uvwcy;
            mP7o8:
            return;
            goto FV7XB;
            x63_a:
            $BXhsT = $this->GqFb6->call($this, $HyAAV);
            goto rYF1W;
            KwNth:
            sEaZ5:
            goto E6Gw8;
            Uvwcy:
            if (chmod($HyAAV, 0664)) {
                goto sEaZ5;
            }
            goto uF6Pq;
            UCkwS:
            $qKtXa = MpPzMcfcRTISZ::findOrFail($aK0gt);
            goto Y3b4C;
            FV7XB:
            io0kt:
            goto Un94J;
            Y3b4C:
            if ($this->c5PSU->exists($qKtXa->getLocation())) {
                goto io0kt;
            }
            goto DFCvR;
            ec6Qb:
            $this->mStuQW4EmuG($BXhsT, $w91p_);
            goto WAhub;
            DFCvR:
            Log::error("MpPzMcfcRTISZ is not on local, might be deleted before put watermark", ['imageId' => $aK0gt]);
            goto mP7o8;
            WAhub:
            $this->BfyCm->put($HyAAV, $BXhsT->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto ZF05N;
            rYF1W:
            $BXhsT->orient();
            goto ec6Qb;
            uF6Pq:
            \Log::warning('Failed to set final permissions on image file: ' . $HyAAV);
            goto hDQQz;
            E6Gw8:
        } catch (\Throwable $HBbdo) {
            goto m6X7V;
            q0zcy:
            Log::info("MpPzMcfcRTISZ has been deleted, discard it", ['imageId' => $aK0gt]);
            goto Ub8cf;
            Ub8cf:
            return;
            goto yyXYt;
            yyXYt:
            gSz8h:
            goto l_7IA;
            m6X7V:
            if (!$HBbdo instanceof ModelNotFoundException) {
                goto gSz8h;
            }
            goto q0zcy;
            l_7IA:
            Log::error("MpPzMcfcRTISZ is not readable", ['imageId' => $aK0gt, 'error' => $HBbdo->getMessage()]);
            goto u8Tg7;
            u8Tg7:
        } finally {
            $Iy0Ri = microtime(true);
            $W1Mek = memory_get_usage();
            $s5Fdg = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $aK0gt, 'execution_time_sec' => $Iy0Ri - $Wz1mR, 'memory_usage_mb' => ($W1Mek - $bzMw6) / 1024 / 1024, 'peak_memory_usage_mb' => ($s5Fdg - $SwK9A) / 1024 / 1024]);
        }
        goto ApyuO;
        CQqB7:
        Log::info("Adding watermark text to image", ['imageId' => $aK0gt]);
        goto TVStq;
        TVStq:
        ini_set('memory_limit', '-1');
        goto L11AK;
        KhHHp:
        $Wz1mR = microtime(true);
        goto qk6P7;
        ApyuO:
    }
    private function mStuQW4EmuG($BXhsT, $w91p_) : void
    {
        goto EOQvo;
        CizLB:
        $FSDmn = $d2Z8D->mepv8nGH5jL($tp6F0, $iNVXG, $w91p_, true);
        goto Rlmge;
        Rlmge:
        $this->c5PSU->put($FSDmn, $this->BfyCm->get($FSDmn));
        goto s7GSN;
        s7GSN:
        $rJ0Rd = $this->GqFb6->call($this, $this->c5PSU->path($FSDmn));
        goto ARFoX;
        bPo2W:
        $iNVXG = $BXhsT->height();
        goto QPAcq;
        EOQvo:
        $tp6F0 = $BXhsT->width();
        goto bPo2W;
        ARFoX:
        $BXhsT->place($rJ0Rd, 'top-left', 0, 0, 30);
        goto uK9o2;
        QPAcq:
        $d2Z8D = new BDQtoSYw7RsgD($this->cQzus, $this->cZsgg, $this->BfyCm, $this->c5PSU);
        goto CizLB;
        uK9o2:
    }
}
