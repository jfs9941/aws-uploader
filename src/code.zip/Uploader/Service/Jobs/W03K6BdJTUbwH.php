<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Encoder\ZgVfK3mFV3vr8;
use Jfs\Uploader\Encoder\Afpajs92v0EVW;
use Jfs\Uploader\Encoder\FKhlIfmeSlJUJ;
use Jfs\Uploader\Encoder\ViOgwaI8qnaEG;
use Jfs\Uploader\Encoder\Hm4pS3oE1MMiy;
use Jfs\Uploader\Encoder\W2mjj6AmkKZSu;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Jfs\Uploader\Service\Jobs\ZvwnCKZP0hzEL;
use Jfs\Uploader\Service\Jobs\EcIjTx1IEEhqQ;
use Jfs\Uploader\Service\TUSrCGJanJHY8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class W03K6BdJTUbwH implements MediaEncodeJobInterface
{
    private $tA7Ds;
    private $GUhIK;
    private $ZN9hu;
    private $hbjgl;
    private $l1YM3;
    public function __construct(string $EcbH3, $kGo1c, $C2YXG, $Aye_M, $O0ZR1)
    {
        goto pCOk3;
        pCOk3:
        $this->tA7Ds = $EcbH3;
        goto vTSra;
        vTSra:
        $this->GUhIK = $kGo1c;
        goto DGZzk;
        jsrpg:
        $this->l1YM3 = $O0ZR1;
        goto uOruH;
        DGZzk:
        $this->ZN9hu = $C2YXG;
        goto QU9Mj;
        QU9Mj:
        $this->hbjgl = $Aye_M;
        goto jsrpg;
        uOruH:
    }
    public function encode(string $uuHkQ, string $xt6u5, $IhXuc = true) : void
    {
        goto y6HUX;
        lRxNp:
        try {
            goto z9IwE;
            Nj75X:
            L1cNg:
            goto QUJFO;
            phTQc:
            throw new MediaConverterException("WrCq6RmnGcVh7 {$XrW52->id} is not S3 driver value = {$XrW52->mb9Ag}");
            goto Nj75X;
            v3WGD:
            $EpLlV = new ZgVfK3mFV3vr8($XrW52->FGU_5 ?? 1, 2, $eny8I->mRNA9tPncMR($XrW52));
            goto A2mn3;
            KtqaT:
            $tdgEg = $tdgEg->mda1P5w8Yts(new ViOgwaI8qnaEG($gOhz2));
            goto oAuVz;
            O8REd:
            $meB0s = $this->m5yHWcpJ8op($Y5OI2, $AbWam->mxU7tTNgJ1H($XrW52->width(), $XrW52->height(), $xt6u5));
            goto CjazH;
            A2mn3:
            $tdgEg = $tdgEg->mwy5dUcYImb($EpLlV);
            goto lH4P8;
            niSV0:
            Log::info("Set input video for Job", ['s3Uri' => $gOhz2]);
            goto GL71c;
            oAuVz:
            $hSurI = new Afpajs92v0EVW('original', $bvCsS, $WEPGl, $XrW52->ZJgoZ ?? 30);
            goto y8kFn;
            ZC4nP:
            if (!($XrW52->mb9Ag != VNuaYSNcfVlT5::S3)) {
                goto L1cNg;
            }
            goto phTQc;
            Uw8Bl:
            $tdgEg = $tdgEg->mDDHzdphWex($vlGEJ);
            goto xYK5v;
            lCnOC:
            $AbWam = new EcIjTx1IEEhqQ($this->hbjgl, $this->l1YM3, $this->ZN9hu, $this->GUhIK);
            goto O8REd;
            I0QUc:
            spltq:
            goto R5tx6;
            if8tx:
            Assert::isInstanceOf($XrW52, WrCq6RmnGcVh7::class);
            goto ZC4nP;
            bg3Km:
            $vlGEJ = $vlGEJ->mdA0CFciA8Y($meB0s);
            goto y2Bi4;
            zmFtz:
            if (!$this->mtSgpNbO5ZU($bvCsS, $WEPGl)) {
                goto MvB77;
            }
            goto pxph8;
            AdevR:
            $gOhz2 = $this->mtQlEndJd9J($XrW52);
            goto niSV0;
            uoEfO:
            $vlGEJ = new Afpajs92v0EVW('1080p', $X_MTJ['width'], $X_MTJ['height'], $XrW52->ZJgoZ ?? 30);
            goto NG2p0;
            UadhX:
            if (!$meB0s) {
                goto Ki8Rx;
            }
            goto bg3Km;
            bpJna:
            $hSurI = $hSurI->mdA0CFciA8Y($meB0s);
            goto hUeje;
            y2Bi4:
            Ki8Rx:
            goto Uw8Bl;
            FEze6:
            $tdgEg->mhIO9vy381Z($eny8I->mY1QlrNe3OT($XrW52));
            goto J1hcD;
            y8kFn:
            $eny8I = app(FKhlIfmeSlJUJ::class);
            goto uOb1b;
            CjazH:
            if (!$meB0s) {
                goto tnACq;
            }
            goto bpJna;
            YJjX9:
            $Y5OI2 = app(TUSrCGJanJHY8::class);
            goto lCnOC;
            hUeje:
            tnACq:
            goto rLeCI;
            z9IwE:
            $XrW52 = WrCq6RmnGcVh7::findOrFail($uuHkQ);
            goto if8tx;
            NG2p0:
            $meB0s = $this->m5yHWcpJ8op($Y5OI2, $AbWam->mxU7tTNgJ1H((int) $X_MTJ['width'], (int) $X_MTJ['height'], $xt6u5));
            goto UadhX;
            pxph8:
            $X_MTJ = $this->m8vD7p9Fox7($bvCsS, $WEPGl);
            goto yyoba;
            xYK5v:
            MvB77:
            goto I0QUc;
            KEpnM:
            $tdgEg->mhIO9vy381Z($eny8I->mY1QlrNe3OT($XrW52));
            goto YJjX9;
            GL71c:
            $tdgEg = app(Hm4pS3oE1MMiy::class);
            goto KtqaT;
            uOb1b:
            $tdgEg->mDDHzdphWex($hSurI);
            goto KEpnM;
            QUJFO:
            $bvCsS = $XrW52->width();
            goto Sys4A;
            r52r9:
            $XrW52->update(['aws_media_converter_job_id' => $uuHkQ]);
            goto lzafs;
            rLeCI:
            $tdgEg->mDDHzdphWex($hSurI);
            goto FEze6;
            Sys4A:
            $WEPGl = $XrW52->height();
            goto AdevR;
            J1hcD:
            if (!($bvCsS && $WEPGl)) {
                goto spltq;
            }
            goto zmFtz;
            lH4P8:
            $uuHkQ = $tdgEg->mAkKGuYRFIH($this->mfaJvFHSNGt($XrW52, $IhXuc));
            goto r52r9;
            R5tx6:
            Log::info("Set thumbnail for WrCq6RmnGcVh7 Job", ['videoId' => $XrW52->getAttribute('id'), 'duration' => $XrW52->getAttribute('duration')]);
            goto v3WGD;
            yyoba:
            Log::info("Set 1080p resolution for Job", ['width' => $X_MTJ['width'], 'height' => $X_MTJ['height'], 'originalWidth' => $bvCsS, 'originalHeight' => $WEPGl]);
            goto uoEfO;
            lzafs:
        } catch (\Exception $IGLS9) {
            Log::info("WrCq6RmnGcVh7 has been deleted, discard it", ['fileId' => $uuHkQ, 'err' => $IGLS9->getMessage()]);
            return;
        }
        goto nrnbt;
        y6HUX:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $uuHkQ]);
        goto QFRQ2;
        QFRQ2:
        ini_set('memory_limit', '-1');
        goto lRxNp;
        nrnbt:
    }
    private function mfaJvFHSNGt(WrCq6RmnGcVh7 $XrW52, $IhXuc) : bool
    {
        goto Z7zph;
        uIuPc:
        $ShIKZ = (int) round($XrW52->getAttribute('duration') ?? 0);
        goto Jk3Ry;
        KABWq:
        GaqKA:
        goto uIuPc;
        Z7zph:
        if ($IhXuc) {
            goto GaqKA;
        }
        goto coaSA;
        jVRd5:
        x2dce:
        goto aiNNN;
        Jk3Ry:
        switch (true) {
            case $XrW52->width() * $XrW52->height() >= 1920 * 1080 && $XrW52->width() * $XrW52->height() < 2560 * 1440:
                return $ShIKZ > 10 * 60;
            case $XrW52->width() * $XrW52->height() >= 2560 * 1440 && $XrW52->width() * $XrW52->height() < 3840 * 2160:
                return $ShIKZ > 5 * 60;
            case $XrW52->width() * $XrW52->height() >= 3840 * 2160:
                return $ShIKZ > 3 * 60;
            default:
                return false;
        }
        goto SmgDB;
        SmgDB:
        Bpfo2:
        goto jVRd5;
        coaSA:
        return false;
        goto KABWq;
        aiNNN:
    }
    private function m5yHWcpJ8op(TUSrCGJanJHY8 $Y5OI2, string $KLu9w) : ?W2mjj6AmkKZSu
    {
        goto dEQ1V;
        T6tOS:
        return new W2mjj6AmkKZSu($eJgJl, 0, 0, null, null);
        goto t5dEd;
        t5dEd:
        gAZz0:
        goto nygaL;
        nygaL:
        return null;
        goto AOfsr;
        Hnh0N:
        Log::info("Resolve watermark for job with url", ['url' => $KLu9w, 'uri' => $eJgJl]);
        goto ILKnD;
        ILKnD:
        if (!$eJgJl) {
            goto gAZz0;
        }
        goto T6tOS;
        dEQ1V:
        $eJgJl = $Y5OI2->m5Tw0SVvXCN($KLu9w);
        goto Hnh0N;
        AOfsr:
    }
    private function mtSgpNbO5ZU(int $bvCsS, int $WEPGl) : bool
    {
        return $bvCsS * $WEPGl > 1.5 * (1920 * 1080);
    }
    private function m8vD7p9Fox7(int $bvCsS, int $WEPGl) : array
    {
        $znIsh = new ZvwnCKZP0hzEL($bvCsS, $WEPGl);
        return $znIsh->mA6zWsQJ3q2();
    }
    private function mtQlEndJd9J(VMj30iBgKeeJB $XcVxI) : string
    {
        goto s7KZd;
        eci19:
        return $this->GUhIK->url($XcVxI->filename);
        goto oxijD;
        s7KZd:
        if (!($XcVxI->mb9Ag == VNuaYSNcfVlT5::S3)) {
            goto tx3vq;
        }
        goto j44Tg;
        zTGGb:
        tx3vq:
        goto eci19;
        j44Tg:
        return 's3://' . $this->tA7Ds . '/' . $XcVxI->filename;
        goto zTGGb;
        oxijD:
    }
}
