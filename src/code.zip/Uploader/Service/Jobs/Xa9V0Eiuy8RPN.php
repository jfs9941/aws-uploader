<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
class Xa9V0Eiuy8RPN implements CompressJobInterface
{
    const wRtPJ = 60;
    private $SJRrZ;
    private $xbA_A;
    public function __construct($akc4V, $a_5ue)
    {
        $this->SJRrZ = $akc4V;
        $this->xbA_A = $a_5ue;
    }
    public function compress(string $ld8Ad)
    {
        goto NBSBA;
        wK2vQ:
        $BpzCH = memory_get_usage();
        goto ZpupA;
        Sn9s1:
        Log::info("Compress image", ['imageId' => $ld8Ad]);
        goto zOKbt;
        ZpupA:
        $VBJ1E = memory_get_peak_usage();
        goto Sn9s1;
        zOKbt:
        try {
            goto d0SbU;
            ePIdo:
            $xobEP->save();
            goto FXnNf;
            YnSOb:
            $B7Zjh = $this->SJRrZ->call($this, $U4aAW);
            goto xWkBV;
            xWkBV:
            $B7Zjh->orient()->toWebp(self::wRtPJ)->save($ZdSxT);
            goto fGc8m;
            CbSFr:
            $B7Zjh = $this->SJRrZ->call($this, $U4aAW);
            goto k7OYD;
            N0uHn:
            $xobEP->setAttribute('type', 'jpg');
            goto IZdx7;
            k7OYD:
            $B7Zjh->orient()->toJpeg(self::wRtPJ)->save($ZdSxT);
            goto G2Kha;
            eiw1y:
            $U4aAW = $this->xbA_A->path($xobEP->getLocation());
            goto Ci83A;
            IZdx7:
            $xobEP->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $xobEP->getLocation()));
            goto ePIdo;
            G2Kha:
            unset($B7Zjh);
            goto j8kUn;
            FXnNf:
            RUstD:
            goto AE92f;
            fGc8m:
            unset($B7Zjh);
            goto w9FV3;
            j8kUn:
            $ZdSxT = $this->xbA_A->path(str_replace('.jpg', '.webp', $xobEP->getLocation()));
            goto YnSOb;
            AE92f:
            $ZdSxT = $this->xbA_A->path($xobEP->getLocation());
            goto CbSFr;
            d0SbU:
            $xobEP = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
            goto eiw1y;
            Ci83A:
            if (!(strtolower($xobEP->getExtension()) === 'png' || strtolower($xobEP->getExtension()) === 'heic')) {
                goto RUstD;
            }
            goto N0uHn;
            w9FV3:
        } catch (ModelNotFoundException) {
            Log::info("Sf7MFJ2wUSx2k has been deleted, discard it", ['imageId' => $ld8Ad]);
        } finally {
            $RZBdd = microtime(true);
            $s2S1x = memory_get_usage();
            $J0pU0 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $ld8Ad, 'execution_time_sec' => $RZBdd - $p0d_Z, 'memory_usage_mb' => ($s2S1x - $BpzCH) / 1024 / 1024, 'peak_memory_usage_mb' => ($J0pU0 - $VBJ1E) / 1024 / 1024]);
        }
        goto bEH9I;
        NBSBA:
        $p0d_Z = microtime(true);
        goto wK2vQ;
        bEH9I:
    }
}
