<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class O43r6mUSFn56x implements GenerateThumbnailForVideoInterface
{
    private $KMLQG;
    public function __construct($NaJO5)
    {
        $this->KMLQG = $NaJO5;
    }
    public function generate(string $Qu08p) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $Qu08p);
        $this->KMLQG->createThumbnail($Qu08p);
    }
}
