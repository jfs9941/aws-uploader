<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class U067tOEktEiP1 implements CompressJobInterface
{
    const LtXXE = 60;
    private $T1B34;
    private $EaJ_d;
    private $NNxJF;
    public function __construct($V0xce, $t9atP, $xnyJl)
    {
        goto YMEdB;
        Fn4ib:
        $this->NNxJF = $xnyJl;
        goto O07JV;
        O07JV:
        $this->EaJ_d = $t9atP;
        goto f462j;
        YMEdB:
        $this->T1B34 = $V0xce;
        goto Fn4ib;
        f462j:
    }
    public function compress(string $wAkkA)
    {
        goto dry_7;
        U94ai:
        Log::info("Compress image", ['imageId' => $wAkkA]);
        goto BesX9;
        BesX9:
        try {
            goto pz7qZ;
            pz7qZ:
            $lu07a = A9olNyGXhDJnA::findOrFail($wAkkA);
            goto z9MYX;
            yUmrd:
            CiZY_:
            goto r1Pd3;
            u6pCl:
            $lu07a = $this->mDSaPPejkee($lu07a, 'jpg');
            goto yUmrd;
            aKj3d:
            if (!(strtolower($lu07a->getExtension()) === 'png' || strtolower($lu07a->getExtension()) === 'heic')) {
                goto CiZY_;
            }
            goto u6pCl;
            r1Pd3:
            try {
                goto ASOrh;
                YIIYi:
                $this->m8TBKKpvoW7($aiarZ, $LEhpY);
                goto P0ymv;
                P0ymv:
                $this->mDSaPPejkee($lu07a, 'webp');
                goto atB5C;
                ASOrh:
                $LEhpY = $this->EaJ_d->path(str_replace('.jpg', '.webp', $lu07a->getLocation()));
                goto YIIYi;
                atB5C:
            } catch (\Exception $EGnga) {
                goto NYRpe;
                wwwhu:
                $this->mvPW3pQzBhd($aiarZ, $LEhpY);
                goto CAUFu;
                Bz4ZC:
                $LEhpY = $this->EaJ_d->path($lu07a->getLocation());
                goto wwwhu;
                NYRpe:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $wAkkA, 'error' => $EGnga->getMessage()]);
                goto Bz4ZC;
                CAUFu:
            }
            goto B2xWF;
            z9MYX:
            $aiarZ = $this->EaJ_d->path($lu07a->getLocation());
            goto aKj3d;
            B2xWF:
        } catch (\Throwable $EGnga) {
            goto p2n4y;
            T1m08:
            return;
            goto DHQTI;
            IJHl3:
            Log::info("A9olNyGXhDJnA has been deleted, discard it", ['imageId' => $wAkkA]);
            goto T1m08;
            DHQTI:
            XQpR2:
            goto wmBXn;
            p2n4y:
            if (!$EGnga instanceof ModelNotFoundException) {
                goto XQpR2;
            }
            goto IJHl3;
            wmBXn:
            Log::error("Failed to compress image", ['imageId' => $wAkkA, 'error' => $EGnga->getMessage()]);
            goto hfauW;
            hfauW:
        } finally {
            $TFGkL = microtime(true);
            $D2XLx = memory_get_usage();
            $dMjbk = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $wAkkA, 'execution_time_sec' => $TFGkL - $fShTg, 'memory_usage_mb' => ($D2XLx - $XojxF) / 1024 / 1024, 'peak_memory_usage_mb' => ($dMjbk - $f0Zjf) / 1024 / 1024]);
        }
        goto NvdrI;
        iBDbQ:
        $f0Zjf = memory_get_peak_usage();
        goto U94ai;
        dry_7:
        $fShTg = microtime(true);
        goto gitLt;
        gitLt:
        $XojxF = memory_get_usage();
        goto iBDbQ;
        NvdrI:
    }
    private function mvPW3pQzBhd($aiarZ, $LEhpY)
    {
        goto ENsVQ;
        ENsVQ:
        $lmCmf = $this->T1B34->call($this, $aiarZ);
        goto B8euT;
        V2Bf5:
        unset($lmCmf);
        goto UtCxL;
        PZFmP:
        $this->NNxJF->put($LEhpY, $lmCmf->toJpeg(self::LtXXE), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto V2Bf5;
        B8euT:
        $lmCmf->orient()->toJpeg(self::LtXXE)->save($LEhpY);
        goto PZFmP;
        UtCxL:
    }
    private function m8TBKKpvoW7($aiarZ, $LEhpY)
    {
        goto s6zTI;
        KTSLo:
        $this->NNxJF->put($LEhpY, $lmCmf->toJpeg(self::LtXXE), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto lqF7l;
        s6zTI:
        $lmCmf = $this->T1B34->call($this, $aiarZ);
        goto U0U7t;
        lqF7l:
        unset($lmCmf);
        goto CcHCG;
        U0U7t:
        $lmCmf->orient()->toWebp(self::LtXXE);
        goto KTSLo;
        CcHCG:
    }
    private function mDSaPPejkee($lu07a, $iH2Av)
    {
        goto AIM0i;
        KTqfx:
        $lu07a->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$iH2Av}", $lu07a->getLocation()));
        goto ce0G4;
        AIM0i:
        $lu07a->setAttribute('type', $iH2Av);
        goto KTqfx;
        ce0G4:
        $lu07a->save();
        goto PjXlq;
        PjXlq:
        return $lu07a;
        goto zYAA_;
        zYAA_:
    }
}
