<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
class Rmj93vDJAXwoy implements StoreVideoToS3JobInterface
{
    private $Fx8p_;
    private $RaPnW;
    private $FFBPk;
    public function __construct($bqJVe, $hTkyv, $GHkBm)
    {
        goto vKOkB;
        vKOkB:
        $this->RaPnW = $hTkyv;
        goto r69hw;
        r69hw:
        $this->FFBPk = $GHkBm;
        goto zDu27;
        zDu27:
        $this->Fx8p_ = $bqJVe;
        goto IU36S;
        IU36S:
    }
    public function store(string $UcmDx) : void
    {
        goto Px9GL;
        wLUAn:
        $QMvmw = 1024 * 1024 * 50;
        goto Ovl5W;
        WGI_G:
        $PxIqk = $this->RaPnW->getClient();
        goto ivEVX;
        iBazt:
        try {
            goto HmAQ8;
            T0prH:
            $EXsQV = $k7Y7P['UploadId'];
            goto Bgpic;
            HmAQ8:
            $k7Y7P = $PxIqk->createMultipartUpload(['Bucket' => $this->Fx8p_, 'Key' => $NKZsn->getLocation(), 'ContentType' => $BVED2, 'ContentDisposition' => 'inline']);
            goto T0prH;
            BklhT:
            Lup_Y:
            goto vFP37;
            hc_4E:
            $dXBTl++;
            goto EIIL8;
            Qck4B:
            V26w9:
            goto vibpI;
            R7ZL4:
            $fN8yf = $PxIqk->uploadPart(['Bucket' => $this->Fx8p_, 'Key' => $NKZsn->getLocation(), 'UploadId' => $EXsQV, 'PartNumber' => $dXBTl, 'Body' => fread($S1cBQ, $QMvmw)]);
            goto RX4Iu;
            vibpI:
            fclose($S1cBQ);
            goto pAbf0;
            RX4Iu:
            $kr4UA[] = ['PartNumber' => $dXBTl, 'ETag' => $fN8yf['ETag']];
            goto hc_4E;
            pAbf0:
            $PxIqk->completeMultipartUpload(['Bucket' => $this->Fx8p_, 'Key' => $NKZsn->getLocation(), 'UploadId' => $EXsQV, 'MultipartUpload' => ['Parts' => $kr4UA]]);
            goto BPMls;
            L8Ta3:
            $GHkBm->delete($NKZsn->getLocation());
            goto q8Grg;
            EIIL8:
            goto Lup_Y;
            goto Qck4B;
            vFP37:
            if (feof($S1cBQ)) {
                goto V26w9;
            }
            goto R7ZL4;
            BPMls:
            $NKZsn->update(['driver' => KPpxBU3Qc8yRk::S3, 'status' => U8OFutptQGm3S::FINISHED]);
            goto L8Ta3;
            TV3Vr:
            $kr4UA = [];
            goto BklhT;
            Bgpic:
            $dXBTl = 1;
            goto TV3Vr;
            q8Grg:
        } catch (AwsException $XCxKc) {
            goto wo_UI;
            wo_UI:
            if (!isset($EXsQV)) {
                goto hSXA1;
            }
            goto pkrzI;
            jZv6l:
            Log::error('Failed to store video: ' . $NKZsn->getLocation() . ' - ' . $XCxKc->getMessage());
            goto rHDhw;
            wuVVJ:
            hSXA1:
            goto jZv6l;
            pkrzI:
            try {
                $PxIqk->abortMultipartUpload(['Bucket' => $this->Fx8p_, 'Key' => $NKZsn->getLocation(), 'UploadId' => $EXsQV]);
            } catch (AwsException $jaHCY) {
                Log::error('Error aborting multipart upload: ' . $jaHCY->getMessage());
            }
            goto wuVVJ;
            rHDhw:
        }
        goto u40wd;
        Ovl5W:
        $BVED2 = $GHkBm->mimeType($NKZsn->getLocation());
        goto iBazt;
        Px9GL:
        Log::info('Storing video (local) to S3', ['fileId' => $UcmDx, 'bucketName' => $this->Fx8p_]);
        goto J6obR;
        a52wR:
        if ($GHkBm->exists($NKZsn->getLocation())) {
            goto UBmrD;
        }
        goto Udn8S;
        Udn8S:
        Log::error("[Rmj93vDJAXwoy] File not found, discard it ", ['video' => $NKZsn->getLocation()]);
        goto UPnHU;
        ivEVX:
        $GHkBm = $this->FFBPk;
        goto o1Ubg;
        ZNV47:
        $S1cBQ = $GHkBm->readStream($NKZsn->getLocation());
        goto wLUAn;
        LPQZb:
        UBmrD:
        goto ZNV47;
        s9Jsw:
        GXXT3:
        goto a52wR;
        UPnHU:
        return;
        goto LPQZb;
        o1Ubg:
        $NKZsn = QdnSnf08v9RV7::find($UcmDx);
        goto o_iuQ;
        o_iuQ:
        if ($NKZsn) {
            goto GXXT3;
        }
        goto mhVKQ;
        HpNyD:
        return;
        goto s9Jsw;
        J6obR:
        ini_set('memory_limit', '-1');
        goto WGI_G;
        mhVKQ:
        Log::info("QdnSnf08v9RV7 has been deleted, discard it", ['fileId' => $UcmDx]);
        goto HpNyD;
        u40wd:
    }
}
