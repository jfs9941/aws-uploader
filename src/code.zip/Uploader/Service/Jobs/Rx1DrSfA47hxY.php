<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Rx1DrSfA47hxY implements GenerateThumbnailForVideoInterface
{
    private $v53Fp;
    public function __construct($HQsKB)
    {
        $this->v53Fp = $HQsKB;
    }
    public function generate(string $eeXS6) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $eeXS6);
        $this->v53Fp->createThumbnail($eeXS6);
    }
}
