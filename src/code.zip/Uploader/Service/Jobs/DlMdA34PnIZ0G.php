<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Service\Jobs\BfkurxdTziJpV;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DlMdA34PnIZ0G implements WatermarkTextJobInterface
{
    private $G25L6;
    private $qhFb9;
    private $Di2j4;
    private $VV2A8;
    private $niO3l;
    public function __construct($G6zg7, $lJlOD, $oOPBt, $xuow1, $DjP3u)
    {
        goto RvSIU;
        Pi88x:
        $this->niO3l = $xuow1;
        goto ldIyl;
        RvSIU:
        $this->G25L6 = $G6zg7;
        goto A6hMU;
        dznDU:
        $this->qhFb9 = $lJlOD;
        goto uQW7m;
        A6hMU:
        $this->VV2A8 = $oOPBt;
        goto Pi88x;
        ldIyl:
        $this->Di2j4 = $DjP3u;
        goto dznDU;
        uQW7m:
    }
    public function putWatermark(string $GhyxD, string $Dk9f1) : void
    {
        goto QaPeC;
        xziET:
        Log::info("Adding watermark text to image", ['imageId' => $GhyxD]);
        goto givZM;
        oshmS:
        $T8Pp2 = memory_get_peak_usage();
        goto xziET;
        IazuV:
        $Iifsd = memory_get_usage();
        goto oshmS;
        QaPeC:
        $FmdyL = microtime(true);
        goto IazuV;
        givZM:
        ini_set('memory_limit', '-1');
        goto xNfv8;
        xNfv8:
        try {
            goto K5FQX;
            PgFjD:
            $this->VV2A8->put($yRiLu, $GaG7q->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto MDFH0;
            S1Mfm:
            $GaG7q = $this->G25L6->call($this, $yRiLu);
            goto vnRsx;
            gRA5V:
            if ($this->niO3l->exists($oaIJp->getLocation())) {
                goto IQK7f;
            }
            goto TeUh1;
            QX1Jp:
            IQK7f:
            goto avBMc;
            cGHgX:
            W8DR2:
            goto oqN2r;
            avBMc:
            $yRiLu = $this->niO3l->path($oaIJp->getLocation());
            goto S1Mfm;
            ueO3Q:
            \Log::warning('Failed to set final permissions on image file: ' . $yRiLu);
            goto tobV9;
            MDFH0:
            unset($GaG7q);
            goto iUq7g;
            tobV9:
            throw new \Exception('Failed to set final permissions on image file: ' . $yRiLu);
            goto cGHgX;
            bP_c5:
            $this->miBbzeqPwpX($GaG7q, $Dk9f1);
            goto PgFjD;
            iUq7g:
            if (chmod($yRiLu, 0664)) {
                goto W8DR2;
            }
            goto ueO3Q;
            K5FQX:
            $oaIJp = IZ5shp3JHuftD::findOrFail($GhyxD);
            goto gRA5V;
            aNC6e:
            return;
            goto QX1Jp;
            TeUh1:
            Log::error("IZ5shp3JHuftD is not on local, might be deleted before put watermark", ['imageId' => $GhyxD]);
            goto aNC6e;
            vnRsx:
            $GaG7q->orient();
            goto bP_c5;
            oqN2r:
        } catch (\Throwable $dk8BY) {
            goto BfbV2;
            Lqr4H:
            Log::error("IZ5shp3JHuftD is not readable", ['imageId' => $GhyxD, 'error' => $dk8BY->getMessage()]);
            goto Yel8L;
            BfbV2:
            if (!$dk8BY instanceof ModelNotFoundException) {
                goto f2Y_b;
            }
            goto PAANq;
            UYM3V:
            f2Y_b:
            goto Lqr4H;
            plyvc:
            return;
            goto UYM3V;
            PAANq:
            Log::info("IZ5shp3JHuftD has been deleted, discard it", ['imageId' => $GhyxD]);
            goto plyvc;
            Yel8L:
        } finally {
            $SBKSV = microtime(true);
            $YOCUN = memory_get_usage();
            $Pkr75 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $GhyxD, 'execution_time_sec' => $SBKSV - $FmdyL, 'memory_usage_mb' => ($YOCUN - $Iifsd) / 1024 / 1024, 'peak_memory_usage_mb' => ($Pkr75 - $T8Pp2) / 1024 / 1024]);
        }
        goto HkQM8;
        HkQM8:
    }
    private function miBbzeqPwpX($GaG7q, $Dk9f1) : void
    {
        goto UEVt4;
        zkVjz:
        $GaG7q->place($cWYFB, 'top-left', 0, 0, 30);
        goto PQJic;
        D_6dh:
        $t6WEw = new BfkurxdTziJpV($this->qhFb9, $this->Di2j4, $this->VV2A8, $this->niO3l);
        goto ygMfO;
        V9RmQ:
        $cWYFB = $this->G25L6->call($this, $this->niO3l->path($RoF9L));
        goto zkVjz;
        UEVt4:
        $Un71V = $GaG7q->width();
        goto qnpN9;
        ygMfO:
        $RoF9L = $t6WEw->m9xBuLdlu22($Un71V, $aHbCv, $Dk9f1, true);
        goto R8fUY;
        R8fUY:
        $this->niO3l->put($RoF9L, $this->VV2A8->get($RoF9L));
        goto V9RmQ;
        qnpN9:
        $aHbCv = $GaG7q->height();
        goto D_6dh;
        PQJic:
    }
}
