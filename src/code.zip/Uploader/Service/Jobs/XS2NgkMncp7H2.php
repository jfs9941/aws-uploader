<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
class XS2NgkMncp7H2 implements DownloadToLocalJobInterface
{
    private $Aj6QZ;
    private $tGIcp;
    public function __construct($SaekO, $UR4Dl)
    {
        $this->Aj6QZ = $SaekO;
        $this->tGIcp = $UR4Dl;
    }
    public function download(string $BFPg9) : void
    {
        goto K3Wy5;
        K3Wy5:
        $d1aiC = ID6EZw1DKfqu4::findOrFail($BFPg9);
        goto hW4Jd;
        bCYjL:
        return;
        goto BBj7N;
        U8uZ6:
        if (!$this->tGIcp->exists($d1aiC->getLocation())) {
            goto MZ4Ll;
        }
        goto bCYjL;
        hW4Jd:
        Log::info("Start download file to local", ['fileId' => $BFPg9, 'filename' => $d1aiC->getLocation()]);
        goto U8uZ6;
        CqgqY:
        $this->tGIcp->put($d1aiC->getLocation(), $this->Aj6QZ->get($d1aiC->getLocation()));
        goto VAFm9;
        BBj7N:
        MZ4Ll:
        goto CqgqY;
        VAFm9:
    }
}
