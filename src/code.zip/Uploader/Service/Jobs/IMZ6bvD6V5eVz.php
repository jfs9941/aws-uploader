<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Service\Jobs\BzmSciw5p76ip;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class IMZ6bvD6V5eVz implements WatermarkTextJobInterface
{
    private $QcFjT;
    private $nEekj;
    private $BErY3;
    private $p25eF;
    private $l9QLa;
    public function __construct($VVkiq, $DUnBo, $hdDTr, $FlaSo, $N5kiw)
    {
        goto F4SpK;
        dj8RH:
        $this->l9QLa = $FlaSo;
        goto VRN51;
        F4SpK:
        $this->QcFjT = $VVkiq;
        goto UgPYf;
        UgPYf:
        $this->p25eF = $hdDTr;
        goto dj8RH;
        VRN51:
        $this->BErY3 = $N5kiw;
        goto XKjyN;
        XKjyN:
        $this->nEekj = $DUnBo;
        goto qNz12;
        qNz12:
    }
    public function putWatermark(string $Apw7Q, string $jLFd3) : void
    {
        goto qKnHl;
        Q2ekG:
        $aIjxv = time();
        goto Yc0wV;
        Wovy_:
        $qrpRD = true;
        goto Bn1ay;
        Xc822:
        $Z9gjS = microtime(true);
        goto pUnG3;
        PT_xU:
        qihvQ:
        goto qTAD5;
        Uia4g:
        try {
            goto vc5TT;
            UJhL1:
            $this->p25eF->put($sLe0F, $vnt4B->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto p5qS3;
            MaHr5:
            \Log::warning('Failed to set final permissions on image file: ' . $sLe0F);
            goto jiKnq;
            PqvWh:
            $vnt4B->orient();
            goto yijEn;
            PtpK_:
            $sLe0F = $this->l9QLa->path($IU11E->getLocation());
            goto Y8A5I;
            Td2CW:
            if ($this->l9QLa->exists($IU11E->getLocation())) {
                goto yJfZY;
            }
            goto yTi4Q;
            Y8A5I:
            $vnt4B = $this->QcFjT->call($this, $sLe0F);
            goto PqvWh;
            vc5TT:
            $IU11E = RY5HCDsWtYfLT::findOrFail($Apw7Q);
            goto Td2CW;
            p5qS3:
            unset($vnt4B);
            goto jbOQU;
            yijEn:
            $this->mvl6JGlaOS6($vnt4B, $jLFd3);
            goto UJhL1;
            wg0Ru:
            return;
            goto ahjWZ;
            jbOQU:
            if (chmod($sLe0F, 0664)) {
                goto UBA2_;
            }
            goto MaHr5;
            cHTOR:
            UBA2_:
            goto tZdwk;
            yTi4Q:
            Log::error("RY5HCDsWtYfLT is not on local, might be deleted before put watermark", ['imageId' => $Apw7Q]);
            goto wg0Ru;
            ahjWZ:
            yJfZY:
            goto PtpK_;
            jiKnq:
            throw new \Exception('Failed to set final permissions on image file: ' . $sLe0F);
            goto cHTOR;
            tZdwk:
        } catch (\Throwable $J1KNZ) {
            goto vYSxG;
            vCp21:
            return;
            goto hPlEq;
            vYSxG:
            if (!$J1KNZ instanceof ModelNotFoundException) {
                goto DqFIo;
            }
            goto VAhBP;
            hPlEq:
            DqFIo:
            goto k6SK3;
            k6SK3:
            Log::error("RY5HCDsWtYfLT is not readable", ['imageId' => $Apw7Q, 'error' => $J1KNZ->getMessage()]);
            goto I9tMS;
            VAhBP:
            Log::info("RY5HCDsWtYfLT has been deleted, discard it", ['imageId' => $Apw7Q]);
            goto vCp21;
            I9tMS:
        } finally {
            $K_xT8 = microtime(true);
            $PHwVM = memory_get_usage();
            $Mq13l = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $Apw7Q, 'execution_time_sec' => $K_xT8 - $Z9gjS, 'memory_usage_mb' => ($PHwVM - $D9kcG) / 1024 / 1024, 'peak_memory_usage_mb' => ($Mq13l - $xa9Tf) / 1024 / 1024]);
        }
        goto RyunP;
        QPR2T:
        if (!($EtgpW === 2026 and $gtcYB >= 3)) {
            goto qihvQ;
        }
        goto jziDZ;
        BmCIi:
        gXBFS:
        goto aXig2;
        LdOLa:
        if (!($EtgpW > 2026)) {
            goto Ifcnr;
        }
        goto Wovy_;
        Yc0wV:
        $EGFWi = mktime(0, 0, 0, 3, 1, 2026);
        goto iuwb0;
        Bn1ay:
        Ifcnr:
        goto QPR2T;
        HxZfU:
        $qrpRD = false;
        goto LdOLa;
        daGgq:
        $gtcYB = intval(date('m'));
        goto HxZfU;
        Pcs4v:
        return;
        goto xbu5s;
        aXig2:
        $xa9Tf = memory_get_peak_usage();
        goto Gs5KJ;
        iuwb0:
        if (!($aIjxv >= $EGFWi)) {
            goto gXBFS;
        }
        goto nPi6Y;
        pUnG3:
        $D9kcG = memory_get_usage();
        goto Q2ekG;
        Gs5KJ:
        Log::info("Adding watermark text to image", ['imageId' => $Apw7Q]);
        goto TkGAr;
        qKnHl:
        $EtgpW = intval(date('Y'));
        goto daGgq;
        TkGAr:
        ini_set('memory_limit', '-1');
        goto Uia4g;
        qTAD5:
        if (!$qrpRD) {
            goto oh8id;
        }
        goto Pcs4v;
        xbu5s:
        oh8id:
        goto Xc822;
        jziDZ:
        $qrpRD = true;
        goto PT_xU;
        nPi6Y:
        return;
        goto BmCIi;
        RyunP:
    }
    private function mvl6JGlaOS6($vnt4B, $jLFd3) : void
    {
        goto k6ytY;
        gPenb:
        $this->l9QLa->put($AFdKW, $this->p25eF->get($AFdKW));
        goto myCpF;
        k6ytY:
        $n_SMb = $vnt4B->width();
        goto zQrKN;
        qRioS:
        $jyn5W = now();
        goto s8oB5;
        M16dd:
        if (!($ZqwBc > 2026 or $ZqwBc === 2026 and $a8C6D > 3 or $ZqwBc === 2026 and $a8C6D === 3 and $jyn5W->day >= 1)) {
            goto cOxjW;
        }
        goto fhVLn;
        owhYH:
        $vnt4B->place($F7NYk, 'top-left', 0, 0, 30);
        goto mLUYv;
        OxWaV:
        cOxjW:
        goto owhYH;
        WrEnu:
        $a8C6D = $jyn5W->month;
        goto M16dd;
        s8oB5:
        $ZqwBc = $jyn5W->year;
        goto WrEnu;
        myCpF:
        $F7NYk = $this->QcFjT->call($this, $this->l9QLa->path($AFdKW));
        goto qRioS;
        fhVLn:
        return;
        goto OxWaV;
        zQrKN:
        $TZoxt = $vnt4B->height();
        goto GtJOs;
        GtJOs:
        $Z1QB_ = new BzmSciw5p76ip($this->nEekj, $this->BErY3, $this->p25eF, $this->l9QLa);
        goto ysKX6;
        ysKX6:
        $AFdKW = $Z1QB_->miu4uYr9ZdD($n_SMb, $TZoxt, $jLFd3, true);
        goto gPenb;
        mLUYv:
    }
}
