<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use backup\Exposed\Jobs\MdimVmV9yOs45;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Encoder\HtmI0wNZkfmpy;
use backup\Uploader\Encoder\OjOeu9zRWB4yz;
use backup\Uploader\Encoder\LZk9dEYagFbfv;
use backup\Uploader\Encoder\BJQ9kvYFDQhur;
use backup\Uploader\Encoder\ZfSpbyoegtO09;
use backup\Uploader\Encoder\KfWJUQxwOYvd8;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use backup\Uploader\Service\Jobs\ZjpvMqzM69PB5;
use backup\Uploader\Service\Jobs\TB5JGG95O6Sla;
use backup\Uploader\Service\HgXaT629cXC5e;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class SaQQK3QqJsRP8 implements MdimVmV9yOs45
{
    private $tv4bE;
    private $FJZRi;
    private $kEfMA;
    private $s97Dj;
    private $CMe9Y;
    public function __construct(string $ClLup, $UEDUm, $FP6ih, $VV0qO, $Yq15P)
    {
        goto qa2Kk;
        tMSoG:
        $this->FJZRi = $UEDUm;
        goto DBTIz;
        DBTIz:
        $this->kEfMA = $FP6ih;
        goto VLrrY;
        VLrrY:
        $this->s97Dj = $VV0qO;
        goto fJehh;
        qa2Kk:
        $this->tv4bE = $ClLup;
        goto tMSoG;
        fJehh:
        $this->CMe9Y = $Yq15P;
        goto gd4rj;
        gd4rj:
    }
    public function encode(string $EQQae, string $yy69B, $vOaSJ = true) : void
    {
        goto pmKJ1;
        mOS2q:
        try {
            goto IueMo;
            wgRPa:
            $ZBTET->m9lZUWoxALq($CR9ys->mUmeTTXTore($L2Ff8));
            goto OhuxC;
            C939j:
            $Nnuw6 = $Nnuw6->m8cVCMSJMPt($X8t8W);
            goto J33EQ;
            ACsc3:
            $bp6Lq = new HtmI0wNZkfmpy($L2Ff8->klbhQ ?? 1, 2, $CR9ys->mmYGSg1QZVV($L2Ff8));
            goto uQgym;
            uQgym:
            $ZBTET = $ZBTET->m8alkrtKZd4($bp6Lq);
            goto PrRvK;
            ey10i:
            $CR9ys = app(LZk9dEYagFbfv::class);
            goto mvTRn;
            FyEDe:
            PfbIJ:
            goto O8nys;
            mvTRn:
            $ZBTET->mnm3rGDP1tF($Nnuw6);
            goto wgRPa;
            KHBvY:
            v9cdV:
            goto XfcHd;
            ECDEV:
            if (!$X8t8W) {
                goto EeIV0;
            }
            goto C939j;
            XBBsx:
            $rl8g3 = new TB5JGG95O6Sla($this->s97Dj, $this->CMe9Y, $this->kEfMA, $this->FJZRi);
            goto x9Wl3;
            PrRvK:
            $EQQae = $ZBTET->mzHSsynqQRf($this->mTA4bH86kyL($L2Ff8, $vOaSJ));
            goto xqLzq;
            YhDIF:
            $ZBTET = app(ZfSpbyoegtO09::class);
            goto tD2NR;
            Vh1rv:
            $nG1t_ = $this->mk4pX5POad5($L2Ff8);
            goto XX2QU;
            mv0r3:
            $Nnuw6 = new OjOeu9zRWB4yz('original', $BxXBR, $w10Ma, $L2Ff8->BOAUz ?? 30);
            goto ey10i;
            lTu2K:
            if (!($L2Ff8->IykL3 !== XmcIS8CQn72i3::S3)) {
                goto Awvoz;
            }
            goto wwKmK;
            W2rk7:
            if (!$X8t8W) {
                goto v9cdV;
            }
            goto w1c_B;
            E_Ncz:
            i324c:
            goto FyEDe;
            LtxFu:
            Awvoz:
            goto OZw46;
            O8nys:
            Log::info("Set thumbnail for AvisbyD0IE5xq Job", ['videoId' => $L2Ff8->getAttribute('id'), 'duration' => $L2Ff8->getAttribute('duration')]);
            goto ACsc3;
            LMCxC:
            $gwaKl = new OjOeu9zRWB4yz('1080p', $VxhDu['width'], $VxhDu['height'], $L2Ff8->BOAUz ?? 30);
            goto tPWEg;
            w1c_B:
            $gwaKl = $gwaKl->m8cVCMSJMPt($X8t8W);
            goto KHBvY;
            CetyM:
            $w10Ma = $L2Ff8->height();
            goto Vh1rv;
            OZw46:
            $BxXBR = $L2Ff8->width();
            goto CetyM;
            tPWEg:
            $X8t8W = $this->mMAfXSy2iKG($oelhj, $rl8g3->mYCip0tFyl3((int) $VxhDu['width'], (int) $VxhDu['height'], $yy69B));
            goto W2rk7;
            XfcHd:
            $ZBTET = $ZBTET->mnm3rGDP1tF($gwaKl);
            goto E_Ncz;
            iTdW8:
            $ZBTET->m9lZUWoxALq($CR9ys->mUmeTTXTore($L2Ff8));
            goto Y7siY;
            x9Wl3:
            $X8t8W = $this->mMAfXSy2iKG($oelhj, $rl8g3->mYCip0tFyl3($L2Ff8->width(), $L2Ff8->height(), $yy69B));
            goto ECDEV;
            X60oP:
            Log::info("Set 1080p resolution for Job", ['width' => $VxhDu['width'], 'height' => $VxhDu['height'], 'originalWidth' => $BxXBR, 'originalHeight' => $w10Ma]);
            goto LMCxC;
            ftfk4:
            $ZBTET->mnm3rGDP1tF($Nnuw6);
            goto iTdW8;
            J33EQ:
            EeIV0:
            goto ftfk4;
            BXTOt:
            $VxhDu = $this->mfVRgTy43ae($BxXBR, $w10Ma);
            goto X60oP;
            Y7siY:
            if (!($BxXBR && $w10Ma)) {
                goto PfbIJ;
            }
            goto LXagj;
            OhuxC:
            $oelhj = app(HgXaT629cXC5e::class);
            goto XBBsx;
            XX2QU:
            Log::info("Set input video for Job", ['s3Uri' => $nG1t_]);
            goto YhDIF;
            xqLzq:
            $L2Ff8->update(['aws_media_converter_job_id' => $EQQae]);
            goto OZbve;
            tD2NR:
            $ZBTET = $ZBTET->mV7JVVzNJHP(new BJQ9kvYFDQhur($nG1t_));
            goto mv0r3;
            wwKmK:
            throw new MediaConverterException("AvisbyD0IE5xq {$L2Ff8->id} is not S3 driver");
            goto LtxFu;
            LXagj:
            if (!$this->mpsGYRyPlLN($BxXBR, $w10Ma)) {
                goto i324c;
            }
            goto BXTOt;
            b9eNC:
            Assert::isInstanceOf($L2Ff8, AvisbyD0IE5xq::class);
            goto lTu2K;
            IueMo:
            $L2Ff8 = AvisbyD0IE5xq::findOrFail($EQQae);
            goto b9eNC;
            OZbve:
        } catch (\Exception $eQXjs) {
            Log::info("AvisbyD0IE5xq has been deleted, discard it", ['fileId' => $EQQae, 'err' => $eQXjs->getMessage()]);
            return;
        }
        goto ubzqA;
        cHos2:
        ini_set('memory_limit', '-1');
        goto mOS2q;
        pmKJ1:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $EQQae]);
        goto cHos2;
        ubzqA:
    }
    private function mTA4bH86kyL(AvisbyD0IE5xq $L2Ff8, $vOaSJ) : bool
    {
        goto Dcccn;
        G6NQD:
        return false;
        goto YaDeV;
        YaDeV:
        qz35M:
        goto h0khN;
        F9icr:
        E583v:
        goto OkgmC;
        ELgHm:
        switch (true) {
            case $L2Ff8->width() * $L2Ff8->height() >= 1920 * 1080 && $L2Ff8->width() * $L2Ff8->height() < 2560 * 1440:
                return $TmAKp > 10 * 60;
            case $L2Ff8->width() * $L2Ff8->height() >= 2560 * 1440 && $L2Ff8->width() * $L2Ff8->height() < 3840 * 2160:
                return $TmAKp > 5 * 60;
            case $L2Ff8->width() * $L2Ff8->height() >= 3840 * 2160:
                return $TmAKp > 3 * 60;
            default:
                return false;
        }
        goto F9icr;
        h0khN:
        $TmAKp = (int) round($L2Ff8->getAttribute('duration') ?? 0);
        goto ELgHm;
        OkgmC:
        TBABA:
        goto FwIf0;
        Dcccn:
        if ($vOaSJ) {
            goto qz35M;
        }
        goto G6NQD;
        FwIf0:
    }
    private function mMAfXSy2iKG(HgXaT629cXC5e $oelhj, string $gdAso) : ?KfWJUQxwOYvd8
    {
        goto n1Beu;
        n1Beu:
        $lWJwn = $oelhj->my1sV4yCLdL($gdAso);
        goto a3_uS;
        rLWWS:
        if (!$lWJwn) {
            goto XohvC;
        }
        goto PJIHl;
        uJN9F:
        return null;
        goto PwMhI;
        qHIAK:
        XohvC:
        goto uJN9F;
        a3_uS:
        Log::info("Resolve watermark for job with url", ['url' => $gdAso, 'uri' => $lWJwn]);
        goto rLWWS;
        PJIHl:
        return new KfWJUQxwOYvd8($lWJwn, 0, 0, null, null);
        goto qHIAK;
        PwMhI:
    }
    private function mpsGYRyPlLN(int $BxXBR, int $w10Ma) : bool
    {
        return $BxXBR * $w10Ma > 1.5 * (1920 * 1080);
    }
    private function mfVRgTy43ae(int $BxXBR, int $w10Ma) : array
    {
        $rh3Ch = new ZjpvMqzM69PB5($BxXBR, $w10Ma);
        return $rh3Ch->m9Z9k3w3aSI();
    }
    private function mk4pX5POad5(PJqa0Yy2jwBHe $JFGfH) : string
    {
        goto EdXXu;
        EdXXu:
        if (!($JFGfH->IykL3 == XmcIS8CQn72i3::S3)) {
            goto p41dx;
        }
        goto AVoeV;
        wQf5c:
        p41dx:
        goto T7Fyt;
        T7Fyt:
        return $this->FJZRi->url($JFGfH->filename);
        goto CU_77;
        AVoeV:
        return 's3://' . $this->tv4bE . '/' . $JFGfH->filename;
        goto wQf5c;
        CU_77:
    }
}
