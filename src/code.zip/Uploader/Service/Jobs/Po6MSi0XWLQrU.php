<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Po6MSi0XWLQrU implements GenerateThumbnailForVideoInterface
{
    private $Z1zDQ;
    public function __construct($svBvM)
    {
        $this->Z1zDQ = $svBvM;
    }
    public function generate(string $S6xyJ) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $S6xyJ);
        $this->Z1zDQ->createThumbnail($S6xyJ);
    }
}
