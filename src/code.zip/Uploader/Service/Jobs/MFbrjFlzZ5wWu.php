<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class MFbrjFlzZ5wWu implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $g5e_r) : void
    {
        goto ernPG;
        D83ca:
        $this->mjZBkKva3mc($Uas5p);
        goto udmou;
        Gm5Yz:
        if ($Uas5p->width() > 0 && $Uas5p->height() > 0) {
            goto eOX8K;
        }
        goto D83ca;
        udmou:
        eOX8K:
        goto mLhZY;
        ernPG:
        $Uas5p = JbxOPjx4A3DUY::findOrFail($g5e_r);
        goto Gm5Yz;
        mLhZY:
    }
    private function mjZBkKva3mc(JbxOPjx4A3DUY $k3Lov) : void
    {
        goto eJz6T;
        eJz6T:
        $Exm_V = $k3Lov->getAttribute('driver') === 1 ? 's3' : 'public';
        goto cqtL2;
        MEiSh:
        $VBewt = $LiWvx->getVideoStream();
        goto sIUIc;
        HpxMo:
        $k3Lov->update(['duration' => $LiWvx->getDurationInSeconds(), 'resolution' => $Uv6md->getWidth() . 'x' . $Uv6md->getHeight(), 'fps' => 30]);
        goto QAewo;
        cqtL2:
        $LiWvx = FFMpeg::fromDisk($Exm_V)->open($k3Lov->getAttribute('filename'));
        goto MEiSh;
        sIUIc:
        $Uv6md = $VBewt->getDimensions();
        goto HpxMo;
        QAewo:
    }
}
