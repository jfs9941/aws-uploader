<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Illuminate\Support\Facades\Log;
class FWgOwuyh1XibA implements StoreVideoToS3JobInterface
{
    private $XZCIQ;
    private $tcoQz;
    private $AwDbR;
    public function __construct($Jkr71, $v70jj, $uwOBm)
    {
        goto Y3ljA;
        XUk0R:
        $this->AwDbR = $uwOBm;
        goto ixtmy;
        Y3ljA:
        $this->tcoQz = $v70jj;
        goto XUk0R;
        ixtmy:
        $this->XZCIQ = $Jkr71;
        goto wrWDq;
        wrWDq:
    }
    public function store(string $B5uQ4) : void
    {
        goto I9VD5;
        IaInm:
        $aIl3m = $uwOBm->readStream($AiP1U->getLocation());
        goto RC2x3;
        mNBYC:
        zNLN4:
        goto IaInm;
        RC2x3:
        $N70qa = 1024 * 1024 * 50;
        goto rWzQg;
        TT2T9:
        $Sb3tS = microtime(true);
        goto i8VDw;
        uuqnr:
        Log::error("[FWgOwuyh1XibA] File not found, discard it ", ['video' => $AiP1U->getLocation()]);
        goto nuqRQ;
        C0cBh:
        v6Lzy:
        goto Tw7Nw;
        UYq8Q:
        try {
            goto KgXDZ;
            KgXDZ:
            $lgyD_ = $Ubm8B->createMultipartUpload(['Bucket' => $this->XZCIQ, 'Key' => $AiP1U->getLocation(), 'ContentType' => $OWULU, 'ContentDisposition' => 'inline']);
            goto FfC_O;
            VqvNa:
            $AiP1U->update(['driver' => LrHrisEWQ9E5o::S3, 'status' => KidkTsWIjmNMb::FINISHED]);
            goto bMbVF;
            GbslL:
            $qWaIU = 1;
            goto kQcx_;
            xA5r4:
            puASh:
            goto w3Yz7;
            tcvq_:
            HpuMc:
            goto DnMrw;
            kQcx_:
            $M5tou = [];
            goto tcvq_;
            bMbVF:
            $uwOBm->delete($AiP1U->getLocation());
            goto qVfB2;
            Mvkx1:
            $qWaIU++;
            goto xKE8C;
            QWF6o:
            $M5tou[] = ['PartNumber' => $qWaIU, 'ETag' => $sG8QL['ETag']];
            goto Mvkx1;
            qZR5Y:
            $Ubm8B->completeMultipartUpload(['Bucket' => $this->XZCIQ, 'Key' => $AiP1U->getLocation(), 'UploadId' => $j1Tgu, 'MultipartUpload' => ['Parts' => $M5tou]]);
            goto VqvNa;
            xKE8C:
            goto HpuMc;
            goto xA5r4;
            Q2U4C:
            $sG8QL = $Ubm8B->uploadPart(['Bucket' => $this->XZCIQ, 'Key' => $AiP1U->getLocation(), 'UploadId' => $j1Tgu, 'PartNumber' => $qWaIU, 'Body' => fread($aIl3m, $N70qa)]);
            goto QWF6o;
            DnMrw:
            if (feof($aIl3m)) {
                goto puASh;
            }
            goto Q2U4C;
            FfC_O:
            $j1Tgu = $lgyD_['UploadId'];
            goto GbslL;
            w3Yz7:
            fclose($aIl3m);
            goto qZR5Y;
            qVfB2:
        } catch (AwsException $EgQtq) {
            goto E5f1j;
            E5f1j:
            if (!isset($j1Tgu)) {
                goto x2sDK;
            }
            goto SVE3E;
            cG83x:
            Log::error('Failed to store video: ' . $AiP1U->getLocation() . ' - ' . $EgQtq->getMessage());
            goto tTRTx;
            pgPZm:
            x2sDK:
            goto cG83x;
            SVE3E:
            try {
                $Ubm8B->abortMultipartUpload(['Bucket' => $this->XZCIQ, 'Key' => $AiP1U->getLocation(), 'UploadId' => $j1Tgu]);
            } catch (AwsException $wBDW6) {
                Log::error('Error aborting multipart upload: ' . $wBDW6->getMessage());
            }
            goto pgPZm;
            tTRTx:
        } finally {
            $YrIBh = microtime(true);
            $qjV8v = memory_get_usage();
            $iOIuO = memory_get_peak_usage();
            Log::info('Store CpeNYzI7e1ALA to S3 function resource usage', ['imageId' => $B5uQ4, 'execution_time_sec' => $YrIBh - $Sb3tS, 'memory_usage_mb' => ($qjV8v - $Pykf_) / 1024 / 1024, 'peak_memory_usage_mb' => ($iOIuO - $EPciM) / 1024 / 1024]);
        }
        goto Y9v51;
        JTYQC:
        return;
        goto C0cBh;
        HXEsL:
        $EPciM = memory_get_peak_usage();
        goto UYq8Q;
        JF_wf:
        ini_set('memory_limit', '-1');
        goto u1I29;
        rWzQg:
        $OWULU = $uwOBm->mimeType($AiP1U->getLocation());
        goto TT2T9;
        u1I29:
        $Ubm8B = $this->tcoQz->getClient();
        goto Z_LiU;
        Ot2Mm:
        Log::info("CpeNYzI7e1ALA has been deleted, discard it", ['fileId' => $B5uQ4]);
        goto JTYQC;
        i8VDw:
        $Pykf_ = memory_get_usage();
        goto HXEsL;
        nuqRQ:
        return;
        goto mNBYC;
        Tw7Nw:
        if ($uwOBm->exists($AiP1U->getLocation())) {
            goto zNLN4;
        }
        goto uuqnr;
        Z_LiU:
        $uwOBm = $this->AwDbR;
        goto n5xrA;
        n5xrA:
        $AiP1U = CpeNYzI7e1ALA::find($B5uQ4);
        goto MIoFq;
        I9VD5:
        Log::info('Storing video (local) to S3', ['fileId' => $B5uQ4, 'bucketName' => $this->XZCIQ]);
        goto JF_wf;
        MIoFq:
        if ($AiP1U) {
            goto v6Lzy;
        }
        goto Ot2Mm;
        Y9v51:
    }
}
