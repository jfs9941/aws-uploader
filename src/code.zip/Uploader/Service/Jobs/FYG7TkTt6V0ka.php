<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class FYG7TkTt6V0ka implements CompressJobInterface
{
    const mFpt1 = 60;
    private $UVc7_;
    private $s3l3u;
    private $z1k21;
    public function __construct($h1yz3, $lKCQu, $R6Lbx)
    {
        goto iBWsz;
        bWh93:
        $this->z1k21 = $R6Lbx;
        goto Mv39w;
        Mv39w:
        $this->s3l3u = $lKCQu;
        goto u_Mp1;
        iBWsz:
        $this->UVc7_ = $h1yz3;
        goto bWh93;
        u_Mp1:
    }
    public function compress(string $poSkG)
    {
        goto kXL10;
        Siun1:
        try {
            goto gQWwp;
            kiyVb:
            $LP1nP = $this->s3l3u->path($VSbOm->getLocation());
            goto F2eHO;
            hVhpn:
            XypK9:
            goto OvapQ;
            F2eHO:
            if (!(strtolower($VSbOm->getExtension()) === 'png' || strtolower($VSbOm->getExtension()) === 'heic')) {
                goto XypK9;
            }
            goto ZX832;
            OvapQ:
            try {
                goto zNOWu;
                fl9wN:
                $this->mNbgE25KKOt($LP1nP, $UDUyo);
                goto X77Gu;
                X77Gu:
                $this->m3jHGkW73B8($VSbOm, 'webp');
                goto Ihwcg;
                zNOWu:
                $UDUyo = $this->s3l3u->path(str_replace('.jpg', '.webp', $VSbOm->getLocation()));
                goto fl9wN;
                Ihwcg:
            } catch (\Exception $RUf1Z) {
                goto Yc_vj;
                Yc_vj:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $poSkG, 'error' => $RUf1Z->getMessage()]);
                goto j5NCC;
                j5NCC:
                $UDUyo = $this->s3l3u->path($VSbOm->getLocation());
                goto bV6AC;
                bV6AC:
                $this->msKAtp0hRgC($LP1nP, $UDUyo);
                goto raTWb;
                raTWb:
            }
            goto u9NA2;
            ZX832:
            $VSbOm = $this->m3jHGkW73B8($VSbOm, 'jpg');
            goto hVhpn;
            gQWwp:
            $VSbOm = KZbAaRxCqNUr3::findOrFail($poSkG);
            goto kiyVb;
            u9NA2:
        } catch (\Throwable $RUf1Z) {
            goto AL8US;
            cyDSo:
            eH8Ok:
            goto CDUiF;
            ysr00:
            Log::info("KZbAaRxCqNUr3 has been deleted, discard it", ['imageId' => $poSkG]);
            goto gC0Re;
            gC0Re:
            return;
            goto cyDSo;
            AL8US:
            if (!$RUf1Z instanceof ModelNotFoundException) {
                goto eH8Ok;
            }
            goto ysr00;
            CDUiF:
            Log::error("Failed to compress image", ['imageId' => $poSkG, 'error' => $RUf1Z->getMessage()]);
            goto wdNAB;
            wdNAB:
        } finally {
            $BDOA4 = microtime(true);
            $GO2Jv = memory_get_usage();
            $Svmms = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $poSkG, 'execution_time_sec' => $BDOA4 - $EnuQ0, 'memory_usage_mb' => ($GO2Jv - $PY97I) / 1024 / 1024, 'peak_memory_usage_mb' => ($Svmms - $SH_2o) / 1024 / 1024]);
        }
        goto zdGTe;
        PPhdT:
        $PY97I = memory_get_usage();
        goto CLtu2;
        kXL10:
        $EnuQ0 = microtime(true);
        goto PPhdT;
        CLtu2:
        $SH_2o = memory_get_peak_usage();
        goto JcXRc;
        JcXRc:
        Log::info("Compress image", ['imageId' => $poSkG]);
        goto Siun1;
        zdGTe:
    }
    private function msKAtp0hRgC($LP1nP, $UDUyo)
    {
        goto AED8Q;
        AED8Q:
        $NNmL6 = $this->UVc7_->call($this, $LP1nP);
        goto xqTQl;
        xqTQl:
        $NNmL6->orient()->toJpeg(self::mFpt1)->save($UDUyo);
        goto y8T_N;
        gCtaR:
        unset($NNmL6);
        goto fjMUQ;
        y8T_N:
        $this->z1k21->put($UDUyo, $NNmL6->toJpeg(self::mFpt1), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto gCtaR;
        fjMUQ:
    }
    private function mNbgE25KKOt($LP1nP, $UDUyo)
    {
        goto fYvLz;
        au1U3:
        $NNmL6->orient()->toWebp(self::mFpt1);
        goto O6giL;
        O6giL:
        $this->z1k21->put($UDUyo, $NNmL6->toJpeg(self::mFpt1), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto A9YJ1;
        A9YJ1:
        unset($NNmL6);
        goto JUrSL;
        fYvLz:
        $NNmL6 = $this->UVc7_->call($this, $LP1nP);
        goto au1U3;
        JUrSL:
    }
    private function m3jHGkW73B8($VSbOm, $JJ04k)
    {
        goto fYAH3;
        FAex0:
        return $VSbOm;
        goto yILeR;
        fYAH3:
        $VSbOm->setAttribute('type', $JJ04k);
        goto V8K0o;
        WhlUo:
        $VSbOm->save();
        goto FAex0;
        V8K0o:
        $VSbOm->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$JJ04k}", $VSbOm->getLocation()));
        goto WhlUo;
        yILeR:
    }
}
