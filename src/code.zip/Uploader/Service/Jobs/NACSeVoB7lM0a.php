<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
class NACSeVoB7lM0a implements DownloadToLocalJobInterface
{
    private $MV0lK;
    private $P2FvH;
    public function __construct($tYsty, $j8mv9)
    {
        $this->MV0lK = $tYsty;
        $this->P2FvH = $j8mv9;
    }
    public function download(string $FILUb) : void
    {
        goto pDSoY;
        L03N1:
        $this->P2FvH->put($I2SbP->getLocation(), $this->MV0lK->get($I2SbP->getLocation()));
        goto qOiIq;
        IDvE7:
        n7gpw:
        goto L03N1;
        lH86I:
        Log::info("Start download file to local", ['fileId' => $FILUb, 'filename' => $I2SbP->getLocation()]);
        goto WPaPX;
        WPaPX:
        if (!$this->P2FvH->exists($I2SbP->getLocation())) {
            goto n7gpw;
        }
        goto teJou;
        pDSoY:
        $I2SbP = XbYF8aa0XyGnI::findOrFail($FILUb);
        goto lH86I;
        teJou:
        return;
        goto IDvE7;
        qOiIq:
    }
}
