<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Illuminate\Support\Facades\Log;
class Usq3hiXOBWYMn implements DownloadToLocalJobInterface
{
    private $f1xKj;
    private $SPj0U;
    public function __construct($C6boj, $KUQsT)
    {
        $this->f1xKj = $C6boj;
        $this->SPj0U = $KUQsT;
    }
    public function download(string $g5e_r) : void
    {
        goto NNNUt;
        K0fKQ:
        GnFAi:
        goto hs9KT;
        eOxAW:
        return;
        goto K0fKQ;
        NNNUt:
        $eQ4Ln = XqAJHKYeaW2YU::findOrFail($g5e_r);
        goto vJ6Lm;
        jd0Uu:
        if (!$this->SPj0U->exists($eQ4Ln->getLocation())) {
            goto GnFAi;
        }
        goto eOxAW;
        vJ6Lm:
        Log::info("Start download file to local", ['fileId' => $g5e_r, 'filename' => $eQ4Ln->getLocation()]);
        goto jd0Uu;
        hs9KT:
        $this->SPj0U->put($eQ4Ln->getLocation(), $this->f1xKj->get($eQ4Ln->getLocation()));
        goto V3ULJ;
        V3ULJ:
    }
}
