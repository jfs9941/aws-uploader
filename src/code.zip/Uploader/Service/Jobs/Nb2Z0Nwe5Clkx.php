<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Illuminate\Support\Facades\Log;
class Nb2Z0Nwe5Clkx implements DownloadToLocalJobInterface
{
    private $QxLu3;
    private $aW0a3;
    public function __construct($bjIIR, $eEhuZ)
    {
        $this->QxLu3 = $bjIIR;
        $this->aW0a3 = $eEhuZ;
    }
    public function download(string $qMhfW) : void
    {
        goto X9JiQ;
        HWIs3:
        $this->aW0a3->put($ZPsYd->getLocation(), $this->QxLu3->get($ZPsYd->getLocation()));
        goto Cj1hQ;
        NLvVA:
        Log::info("Start download file to local", ['fileId' => $qMhfW, 'filename' => $ZPsYd->getLocation()]);
        goto Cgk7r;
        Cgk7r:
        if (!$this->aW0a3->exists($ZPsYd->getLocation())) {
            goto pMADo;
        }
        goto A2fB5;
        A2fB5:
        return;
        goto Bqs1D;
        X9JiQ:
        $ZPsYd = WUuz09CA4woAL::findOrFail($qMhfW);
        goto NLvVA;
        Bqs1D:
        pMADo:
        goto HWIs3;
        Cj1hQ:
    }
}
