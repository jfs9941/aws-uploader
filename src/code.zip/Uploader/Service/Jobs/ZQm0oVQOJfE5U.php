<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class ZQm0oVQOJfE5U implements CompressJobInterface
{
    const srcni = 60;
    private $X2VAb;
    private $nEL6Z;
    private $uykKi;
    public function __construct($aC0aM, $vWt2S, $sAVES)
    {
        goto iFP3x;
        kkxcr:
        $this->uykKi = $sAVES;
        goto LYTYr;
        LYTYr:
        $this->nEL6Z = $vWt2S;
        goto QAqm6;
        iFP3x:
        $this->X2VAb = $aC0aM;
        goto kkxcr;
        QAqm6:
    }
    public function compress(string $iG1wy)
    {
        goto mnDsP;
        knSwY:
        $QFj0j = memory_get_usage();
        goto FfkCn;
        tc_S1:
        Log::info("Compress image", ['imageId' => $iG1wy]);
        goto U1BZS;
        mnDsP:
        $mzMGr = microtime(true);
        goto knSwY;
        U1BZS:
        try {
            goto KLWuj;
            CXfTI:
            try {
                goto pn9OH;
                Nba1Q:
                $this->mq74zKXM3TC($fA_lE, $KSycU);
                goto y9aQq;
                y9aQq:
                $this->mZWDGZUNehf($cDDGh, 'webp');
                goto jhfxd;
                pn9OH:
                $KSycU = str_replace(['.jpg', '.png', '.heic'], '.webp', $cDDGh->getLocation());
                goto Nba1Q;
                jhfxd:
            } catch (\Exception $WqnXx) {
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $iG1wy, 'error' => $WqnXx->getMessage()]);
                try {
                    goto lQUbL;
                    lQUbL:
                    $KSycU = str_replace(['.jpg', '.png', '.heic'], '.jpg', $cDDGh->getLocation());
                    goto Vgx_q;
                    Vgx_q:
                    $this->mIHml259PQg($fA_lE, $KSycU);
                    goto CClUh;
                    CClUh:
                    $this->mZWDGZUNehf($cDDGh, 'jpg');
                    goto lQeo9;
                    lQeo9:
                } catch (\Exception $WqnXx) {
                    Log::error("Failed to compress to jpeg as well, back to original", ['imageId' => $iG1wy, 'error' => $WqnXx->getMessage()]);
                }
            }
            goto M9_Ma;
            J28yr:
            $fA_lE = $this->nEL6Z->path($cDDGh->getLocation());
            goto CXfTI;
            KLWuj:
            $cDDGh = KyoDVfv3eGItF::findOrFail($iG1wy);
            goto J28yr;
            M9_Ma:
        } catch (\Throwable $WqnXx) {
            goto WkaHL;
            WkaHL:
            if (!$WqnXx instanceof ModelNotFoundException) {
                goto PiEKJ;
            }
            goto PqCoC;
            VD7jr:
            return;
            goto PNYMQ;
            PqCoC:
            Log::info("KyoDVfv3eGItF has been deleted, discard it", ['imageId' => $iG1wy]);
            goto VD7jr;
            PNYMQ:
            PiEKJ:
            goto FcMQO;
            FcMQO:
            Log::error("Failed to compress image", ['imageId' => $iG1wy, 'error' => $WqnXx->getMessage()]);
            goto zyRIQ;
            zyRIQ:
        } finally {
            $ljc5H = microtime(true);
            $s7nhL = memory_get_usage();
            $h40IA = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $iG1wy, 'execution_time_sec' => $ljc5H - $mzMGr, 'memory_usage_mb' => ($s7nhL - $QFj0j) / 1024 / 1024, 'peak_memory_usage_mb' => ($h40IA - $qP_18) / 1024 / 1024]);
        }
        goto gjqYU;
        FfkCn:
        $qP_18 = memory_get_peak_usage();
        goto tc_S1;
        gjqYU:
    }
    private function mIHml259PQg($fA_lE, $KSycU)
    {
        goto MthSc;
        MthSc:
        $A6jce = $this->X2VAb->call($this, $fA_lE);
        goto h15Tk;
        EXPyw:
        unset($A6jce);
        goto wWopT;
        h15Tk:
        $A6jce->orient()->toJpeg(self::srcni)->save($KSycU);
        goto xzHhy;
        xzHhy:
        $this->uykKi->put($KSycU, $A6jce->toJpeg(self::srcni), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto EXPyw;
        wWopT:
    }
    private function mq74zKXM3TC($fA_lE, $KSycU)
    {
        goto YzZ_Q;
        YzZ_Q:
        $A6jce = $this->X2VAb->call($this, $fA_lE);
        goto wSR35;
        Z8N7e:
        unset($A6jce);
        goto Vbdzs;
        wSR35:
        $A6jce->orient()->toWebp(self::srcni);
        goto EOMdW;
        EOMdW:
        $this->uykKi->put($KSycU, $A6jce->toWebp(self::srcni), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto Z8N7e;
        Vbdzs:
    }
    private function mZWDGZUNehf($cDDGh, $nbBOs)
    {
        goto b5tpe;
        b5tpe:
        $cDDGh->setAttribute('type', $nbBOs);
        goto Ta1FD;
        Ta1FD:
        $cDDGh->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$nbBOs}", $cDDGh->getLocation()));
        goto LmkdF;
        LmkdF:
        $cDDGh->save();
        goto qgGUD;
        qgGUD:
        return $cDDGh;
        goto kqV95;
        kqV95:
    }
}
