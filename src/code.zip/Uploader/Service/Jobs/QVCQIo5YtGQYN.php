<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
class QVCQIo5YtGQYN implements CompressJobInterface
{
    const Wsm1s = 80;
    private $wEW4b;
    private $sf39X;
    public function __construct($jlVrW, $ZqxJI)
    {
        $this->wEW4b = $jlVrW;
        $this->sf39X = $ZqxJI;
    }
    public function compress(string $cQqZd)
    {
        goto F3gdS;
        sP63E:
        Log::info("Compress image", ['imageId' => $cQqZd]);
        goto wd_MY;
        F3gdS:
        $OKKdr = microtime(true);
        goto dP_rJ;
        wd_MY:
        try {
            goto iihEQ;
            i8BxK:
            $J_xQQ->orientate();
            goto Aiz3k;
            rDniX:
            $cNvvS = $this->sf39X->path($MpgR7->getLocation());
            goto LIo0a;
            LIo0a:
            if (!($MpgR7->getExtension() === 'png')) {
                goto SzxYH;
            }
            goto FlABY;
            IdBWZ:
            $MpgR7->save();
            goto jYKGl;
            T_jTB:
            $J_xQQ = $this->wEW4b->call($this, $cNvvS);
            goto i8BxK;
            EdH0h:
            $MpgR7->setAttribute('filename', str_replace('.png', '.jpg', $MpgR7->getLocation()));
            goto IdBWZ;
            Qjmq2:
            $J_xQQ->destroy();
            goto ZzRF4;
            iihEQ:
            $MpgR7 = Kx3NMUJqFpl5Q::findOrFail($cQqZd);
            goto rDniX;
            Aiz3k:
            $J_xQQ->save($sOfoK, self::Wsm1s);
            goto Qjmq2;
            FlABY:
            $MpgR7->setAttribute('type', 'jpg');
            goto EdH0h;
            MJdDQ:
            $sOfoK = $this->sf39X->path($MpgR7->getLocation());
            goto T_jTB;
            jYKGl:
            SzxYH:
            goto MJdDQ;
            ZzRF4:
        } catch (ModelNotFoundException) {
            Log::info("Kx3NMUJqFpl5Q has been deleted, discard it", ['imageId' => $cQqZd]);
        } finally {
            $yTnwM = microtime(true);
            $qw3CC = memory_get_usage();
            $uML0D = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $cQqZd, 'execution_time_sec' => $yTnwM - $OKKdr, 'memory_usage_mb' => ($qw3CC - $o3FRR) / 1024 / 1024, 'peak_memory_usage_mb' => ($uML0D - $wpG9k) / 1024 / 1024]);
        }
        goto BCBXs;
        ty6cn:
        $wpG9k = memory_get_peak_usage();
        goto sP63E;
        dP_rJ:
        $o3FRR = memory_get_usage();
        goto ty6cn;
        BCBXs:
    }
}
