<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class IZKRSdkDOxm73 implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $B_L9m) : void
    {
        goto HlxE0;
        XLe7p:
        if ($QCHmE->width() > 0 && $QCHmE->height() > 0) {
            goto sdbqT;
        }
        goto xpChi;
        xpChi:
        $this->mKs0ppwCJRw($QCHmE);
        goto LAlrM;
        HlxE0:
        $QCHmE = U9HMl0N8dP0ZH::findOrFail($B_L9m);
        goto XLe7p;
        LAlrM:
        sdbqT:
        goto LzruE;
        LzruE:
    }
    private function mKs0ppwCJRw(U9HMl0N8dP0ZH $PC1_p) : void
    {
        goto kiMIr;
        lsrF7:
        $iIOUX = $uTqKK->getVideoStream();
        goto juhHK;
        jNmd8:
        $uTqKK = FFMpeg::fromDisk($Wg92u['path'])->open($PC1_p->getAttribute('filename'));
        goto lsrF7;
        kiMIr:
        $Wg92u = $PC1_p->getView();
        goto jNmd8;
        Sqdhl:
        $PC1_p->update(['duration' => $uTqKK->getDurationInSeconds(), 'resolution' => $Q0tx8->getWidth() . 'x' . $Q0tx8->getHeight(), 'fps' => $iIOUX->get('r_frame_rate') ?? 30]);
        goto UImTv;
        juhHK:
        $Q0tx8 = $iIOUX->getDimensions();
        goto Sqdhl;
        UImTv:
    }
}
