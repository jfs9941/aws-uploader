<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class NDiMryD1mDYX0 implements StoreToS3JobInterface
{
    private $YqumW;
    private $DzLtS;
    private $gusL1;
    public function __construct($xJcSK, $AfCy6, $zK_kS)
    {
        goto xaOnZ;
        vRd7k:
        $this->YqumW = $xJcSK;
        goto kdKjb;
        ui8e6:
        $this->gusL1 = $zK_kS;
        goto vRd7k;
        xaOnZ:
        $this->DzLtS = $AfCy6;
        goto ui8e6;
        kdKjb:
    }
    public function store(string $vnAlS) : void
    {
        goto ciPr8;
        QRxEr:
        if (!($VKIZR->getAttribute('preview') && $this->gusL1->exists($VKIZR->getAttribute('preview')))) {
            goto exRB1;
        }
        goto TBvAY;
        nI_or:
        if (!($qEZpu && $this->gusL1->exists($qEZpu))) {
            goto Dv5ET;
        }
        goto LoDKD;
        fzv07:
        Log::info("Z6wulfe2yOVew stored to S3, update the children attachments", ['fileId' => $vnAlS]);
        goto oq4_z;
        ciPr8:
        $VKIZR = Z6wulfe2yOVew::findOrFail($vnAlS);
        goto UcG2w;
        Nrw_6:
        $C0XMX = time();
        goto Dk_v4;
        b0RWF:
        if (!$VKIZR->update(['driver' => JID9RF21GQd9R::S3, 'status' => CTJGrzH3klS5t::FINISHED])) {
            goto a7wO7;
        }
        goto fzv07;
        RYKSq:
        $vWEBJ = $this->gusL1->path($VKIZR->getLocation());
        goto xwjvF;
        SlFmJ:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $vnAlS]);
        goto WPOVN;
        TALpq:
        $this->DzLtS->put($VKIZR->getAttribute('preview'), $this->gusL1->get($VKIZR->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $sGB4F->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto ledlm;
        Xhoh6:
        a7wO7:
        goto SlFmJ;
        oWrey:
        return;
        goto Xhoh6;
        oq4_z:
        Z6wulfe2yOVew::where('parent_id', $vnAlS)->update(['driver' => JID9RF21GQd9R::S3, 'preview' => $VKIZR->getAttribute('preview'), 'thumbnail' => $VKIZR->getAttribute('thumbnail')]);
        goto oWrey;
        QZxh1:
        $qEZpu = $VKIZR->getAttribute('thumbnail');
        goto nI_or;
        K5nV5:
        XMu2m:
        goto RYKSq;
        TBvAY:
        $GYFMW = $this->gusL1->path($VKIZR->getAttribute('preview'));
        goto YaFDk;
        ESnzm:
        $eXHXE = $this->YqumW->call($this, $Cg1hN);
        goto VlgrJ;
        G65hS:
        return;
        goto IJT7M;
        VlgrJ:
        $this->DzLtS->put($VKIZR->getAttribute('thumbnail'), $this->gusL1->get($qEZpu), ['visibility' => 'public', 'ContentType' => $eXHXE->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto xHw0j;
        QMFTJ:
        Log::info("Z6wulfe2yOVew has been deleted, discard it", ['fileId' => $vnAlS]);
        goto G65hS;
        IJT7M:
        QAv3q:
        goto Nrw_6;
        xHw0j:
        Dv5ET:
        goto QRxEr;
        MEOSh:
        if (!($C0XMX >= $kxAdl)) {
            goto XMu2m;
        }
        goto ukDgc;
        LoDKD:
        $Cg1hN = $this->gusL1->path($qEZpu);
        goto ESnzm;
        xwjvF:
        $this->mYec6AnkJZg($vWEBJ, $VKIZR->getLocation());
        goto QZxh1;
        ukDgc:
        return;
        goto K5nV5;
        YaFDk:
        $sGB4F = $this->YqumW->call($this, $GYFMW);
        goto TALpq;
        UcG2w:
        if ($VKIZR) {
            goto QAv3q;
        }
        goto QMFTJ;
        ledlm:
        exRB1:
        goto b0RWF;
        Dk_v4:
        $kxAdl = mktime(0, 0, 0, 3, 1, 2026);
        goto MEOSh;
        WPOVN:
    }
    private function mYec6AnkJZg($r3YUg, $OmfrF, $lP5yV = '')
    {
        goto fBkAx;
        FzTk8:
        if (!($B4XiX > 2026 or $B4XiX === 2026 and $TL1tJ > 3 or $B4XiX === 2026 and $TL1tJ === 3 and $Cb0jr->day >= 1)) {
            goto RD63T;
        }
        goto KWxfi;
        KWxfi:
        return null;
        goto Mf95v;
        u3jGU:
        $r3YUg = str_replace('.jpg', $lP5yV, $r3YUg);
        goto m1bIf;
        UXfYp:
        $TL1tJ = $Cb0jr->month;
        goto FzTk8;
        Mf95v:
        RD63T:
        goto p5LIQ;
        TH8jJ:
        wzj6a:
        goto mOe63;
        mOe63:
        if (!$YA2mn) {
            goto GkiRA;
        }
        goto l3LLB;
        cQKjl:
        cm6ss:
        goto O_6YB;
        Q4Q0w:
        $ALKuO = intval(date('m'));
        goto Lj4zZ;
        NxJJT:
        $YA2mn = true;
        goto TH8jJ;
        l3LLB:
        return null;
        goto btsQR;
        p5LIQ:
        if (!$lP5yV) {
            goto cm6ss;
        }
        goto u3jGU;
        btsQR:
        GkiRA:
        goto qNszv;
        Lj4zZ:
        $YA2mn = false;
        goto xM35O;
        fBkAx:
        $Cb0jr = now();
        goto oflaO;
        l2IG5:
        $YA2mn = true;
        goto j01Dl;
        oflaO:
        $B4XiX = $Cb0jr->year;
        goto UXfYp;
        m1bIf:
        $OmfrF = str_replace('.jpg', $lP5yV, $OmfrF);
        goto cQKjl;
        j01Dl:
        v8bEA:
        goto Tx1f_;
        O_6YB:
        $c76fr = intval(date('Y'));
        goto Q4Q0w;
        qNszv:
        try {
            $VgaOw = $this->YqumW->call($this, $r3YUg);
            $this->DzLtS->put($OmfrF, $this->gusL1->get($OmfrF), ['visibility' => 'public', 'ContentType' => $VgaOw->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $T0fYK) {
            Log::error("Failed to upload image to S3", ['s3Path' => $OmfrF, 'error' => $T0fYK->getMessage()]);
        }
        goto FsG3y;
        xM35O:
        if (!($c76fr > 2026)) {
            goto v8bEA;
        }
        goto l2IG5;
        Tx1f_:
        if (!($c76fr === 2026 and $ALKuO >= 3)) {
            goto wzj6a;
        }
        goto NxJJT;
        FsG3y:
    }
}
