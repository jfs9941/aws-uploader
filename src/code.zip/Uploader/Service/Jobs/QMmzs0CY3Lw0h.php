<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\NBWuSM65HseqY;
class QMmzs0CY3Lw0h implements DownloadToLocalJobInterface
{
    private $GQuun;
    private $Farqu;
    public function __construct($Q0shJ, $MQQLd)
    {
        $this->GQuun = $Q0shJ;
        $this->Farqu = $MQQLd;
    }
    public function download(string $eXur0) : void
    {
        goto dcedt;
        pG6jP:
        Log::info("Start download file to local", ['fileId' => $eXur0, 'filename' => $ezBDN->getLocation()]);
        goto bzy0k;
        bzy0k:
        if (!$this->Farqu->exists($ezBDN->getLocation())) {
            goto RwYPR;
        }
        goto jOVgB;
        mZPgE:
        $this->Farqu->put($ezBDN->getLocation(), $this->GQuun->get($ezBDN->getLocation()));
        goto MYvvS;
        jOVgB:
        return;
        goto AibdD;
        dcedt:
        $ezBDN = NBWuSM65HseqY::findOrFail($eXur0);
        goto pG6jP;
        AibdD:
        RwYPR:
        goto mZPgE;
        MYvvS:
    }
}
