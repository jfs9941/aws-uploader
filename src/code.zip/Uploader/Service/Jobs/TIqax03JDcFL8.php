<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Illuminate\Support\Facades\Log;
class TIqax03JDcFL8 implements StoreVideoToS3JobInterface
{
    private $Y_UeI;
    private $huyLW;
    private $Ntit8;
    public function __construct($l286D, $A3hvZ, $MYg0D)
    {
        goto jMVdn;
        F3D8k:
        $this->Y_UeI = $l286D;
        goto JnpYt;
        jMVdn:
        $this->huyLW = $A3hvZ;
        goto xt3Zv;
        xt3Zv:
        $this->Ntit8 = $MYg0D;
        goto F3D8k;
        JnpYt:
    }
    public function store(string $arqvy) : void
    {
        goto MljCN;
        pPEp0:
        if ($MYg0D->exists($yTrkP->getLocation())) {
            goto mi5Ez;
        }
        goto aU1mq;
        sQbfF:
        if ($yTrkP) {
            goto GqkHS;
        }
        goto jXxFf;
        qeMjE:
        return;
        goto u3ET9;
        jXxFf:
        Log::info("RhSx2q5xIlh0Y has been deleted, discard it", ['fileId' => $arqvy]);
        goto qeMjE;
        YyL6a:
        $rMOii = 1024 * 1024 * 50;
        goto SE1B2;
        u3ET9:
        GqkHS:
        goto pPEp0;
        spisk:
        $zi0zx = microtime(true);
        goto TOgeU;
        SE1B2:
        $gkXJK = $MYg0D->mimeType($yTrkP->getLocation());
        goto spisk;
        YIZH7:
        $yTrkP = RhSx2q5xIlh0Y::find($arqvy);
        goto sQbfF;
        Y0Tlw:
        $kITZR = $MYg0D->readStream($yTrkP->getLocation());
        goto YyL6a;
        YaioK:
        $MYg0D = $this->Ntit8;
        goto YIZH7;
        MljCN:
        Log::info('Storing video (local) to S3', ['fileId' => $arqvy, 'bucketName' => $this->Y_UeI]);
        goto AFdGA;
        EpdNt:
        $Eq74o = memory_get_peak_usage();
        goto BP_Iy;
        xedNa:
        mi5Ez:
        goto Y0Tlw;
        TOgeU:
        $NAxoU = memory_get_usage();
        goto EpdNt;
        FarSx:
        return;
        goto xedNa;
        Vg_Yz:
        $NXlvU = $this->huyLW->getClient();
        goto YaioK;
        AFdGA:
        ini_set('memory_limit', '-1');
        goto Vg_Yz;
        aU1mq:
        Log::error("[TIqax03JDcFL8] File not found, discard it ", ['video' => $yTrkP->getLocation()]);
        goto FarSx;
        BP_Iy:
        try {
            goto nEolE;
            Fvnhy:
            goto AWxc5;
            goto WBrKJ;
            gqJqL:
            $YXgxQ[] = ['PartNumber' => $JQjJH, 'ETag' => $Y4cZf['ETag']];
            goto mng9Q;
            ieFDa:
            if (feof($kITZR)) {
                goto urzy_;
            }
            goto hbMBP;
            y8o1O:
            $rrVeh = $y0m_Q['UploadId'];
            goto QWp1B;
            WBrKJ:
            urzy_:
            goto qt4L3;
            mng9Q:
            $JQjJH++;
            goto Fvnhy;
            qt4L3:
            fclose($kITZR);
            goto MHu25;
            nEolE:
            $y0m_Q = $NXlvU->createMultipartUpload(['Bucket' => $this->Y_UeI, 'Key' => $yTrkP->getLocation(), 'ContentType' => $gkXJK, 'ContentDisposition' => 'inline']);
            goto y8o1O;
            xDfGh:
            $MYg0D->delete($yTrkP->getLocation());
            goto jkMW2;
            hbMBP:
            $Y4cZf = $NXlvU->uploadPart(['Bucket' => $this->Y_UeI, 'Key' => $yTrkP->getLocation(), 'UploadId' => $rrVeh, 'PartNumber' => $JQjJH, 'Body' => fread($kITZR, $rMOii)]);
            goto gqJqL;
            MHu25:
            $NXlvU->completeMultipartUpload(['Bucket' => $this->Y_UeI, 'Key' => $yTrkP->getLocation(), 'UploadId' => $rrVeh, 'MultipartUpload' => ['Parts' => $YXgxQ]]);
            goto pKvDS;
            pKvDS:
            $yTrkP->update(['driver' => Opdj0uZXaMJfa::S3, 'status' => EXecNg2hg7kwl::FINISHED]);
            goto xDfGh;
            YJS_C:
            $YXgxQ = [];
            goto Y5dTP;
            Y5dTP:
            AWxc5:
            goto ieFDa;
            QWp1B:
            $JQjJH = 1;
            goto YJS_C;
            jkMW2:
        } catch (AwsException $FTnqg) {
            goto L6HNk;
            wwHU2:
            Log::error('Failed to store video: ' . $yTrkP->getLocation() . ' - ' . $FTnqg->getMessage());
            goto PgS24;
            vafwm:
            C4DQk:
            goto wwHU2;
            L6HNk:
            if (!isset($rrVeh)) {
                goto C4DQk;
            }
            goto L1G1g;
            L1G1g:
            try {
                $NXlvU->abortMultipartUpload(['Bucket' => $this->Y_UeI, 'Key' => $yTrkP->getLocation(), 'UploadId' => $rrVeh]);
            } catch (AwsException $XwplX) {
                Log::error('Error aborting multipart upload: ' . $XwplX->getMessage());
            }
            goto vafwm;
            PgS24:
        } finally {
            $qEn0v = microtime(true);
            $itTa2 = memory_get_usage();
            $qUJq5 = memory_get_peak_usage();
            Log::info('Store RhSx2q5xIlh0Y to S3 function resource usage', ['imageId' => $arqvy, 'execution_time_sec' => $qEn0v - $zi0zx, 'memory_usage_mb' => ($itTa2 - $NAxoU) / 1024 / 1024, 'peak_memory_usage_mb' => ($qUJq5 - $Eq74o) / 1024 / 1024]);
        }
        goto o73MC;
        o73MC:
    }
}
