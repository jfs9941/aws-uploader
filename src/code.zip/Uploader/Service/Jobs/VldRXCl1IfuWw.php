<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class VldRXCl1IfuWw implements GenerateThumbnailJobInterface
{
    const Zebmp = 150;
    const dZ9Vg = 150;
    private $QcFjT;
    private $BqPa9;
    private $Ma55h;
    public function __construct($VVkiq, $Vk6id, $b68y4)
    {
        goto jzHI7;
        jzHI7:
        $this->QcFjT = $VVkiq;
        goto bdst4;
        bdst4:
        $this->BqPa9 = $Vk6id;
        goto C_anI;
        C_anI:
        $this->Ma55h = $b68y4;
        goto HvW3X;
        HvW3X:
    }
    public function generate(string $Apw7Q)
    {
        goto ATxG_;
        uMYWd:
        $Tw7D8 = mktime(0, 0, 0, 3, 1, 2026);
        goto RjBpy;
        w2wwI:
        pBVn5:
        goto LRkfc;
        rG30d:
        BHz6m:
        goto IUEiU;
        LmFz3:
        $b8lTr = intval(date('m'));
        goto ONVRv;
        HhfUS:
        if (!($THTRs === 2026 and $b8lTr >= 3)) {
            goto pBVn5;
        }
        goto CYAhU;
        LRkfc:
        if (!$mipNr) {
            goto Pu8Zo;
        }
        goto Go2CT;
        L0knv:
        return null;
        goto rG30d;
        CYAhU:
        $mipNr = true;
        goto w2wwI;
        Ms3Ix:
        $vDNzn = time();
        goto uMYWd;
        b8o5h:
        Pu8Zo:
        goto eYayG;
        ATxG_:
        $XhOlP = now();
        goto zoNEz;
        tM9jF:
        jMPlp:
        goto HhfUS;
        UP9vh:
        if (!($THTRs > 2026)) {
            goto jMPlp;
        }
        goto fMj_E;
        kjs__:
        if (!($OgBY1 > 2026 or $OgBY1 === 2026 and $Walix > 3 or $OgBY1 === 2026 and $Walix === 3 and $XhOlP->day >= 1)) {
            goto BHz6m;
        }
        goto L0knv;
        IUEiU:
        $THTRs = intval(date('Y'));
        goto LmFz3;
        fMj_E:
        $mipNr = true;
        goto tM9jF;
        pjdm0:
        $Walix = $XhOlP->month;
        goto kjs__;
        LeFvo:
        ini_set('memory_limit', '-1');
        goto V5TFA;
        V5TFA:
        try {
            goto moY4r;
            ibLdC:
            XNISj:
            goto e8Cbt;
            JpQ0V:
            $m5qab = $this->Ma55h->put($sLe0F, $oRjbj->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto ND0tv;
            w3BMW:
            $sLe0F = $this->m4PcU9vvbQK($IU11E);
            goto JpQ0V;
            LMZpl:
            $IU11E->update(['thumbnail' => $sLe0F, 'status' => PIKPXh9YBe2kZ::THUMBNAIL_PROCESSED]);
            goto ibLdC;
            ND0tv:
            unset($oRjbj);
            goto JJqA4;
            o32Zv:
            $oRjbj->orient()->resize(150, 150);
            goto w3BMW;
            JJqA4:
            if (!($m5qab !== false)) {
                goto XNISj;
            }
            goto LMZpl;
            k6YR7:
            $IU11E = RY5HCDsWtYfLT::findOrFail($Apw7Q);
            goto NZBRP;
            NZBRP:
            $oRjbj = $this->QcFjT->call($this, $FlaSo->path($IU11E->getLocation()));
            goto o32Zv;
            moY4r:
            $FlaSo = $this->BqPa9;
            goto k6YR7;
            e8Cbt:
        } catch (ModelNotFoundException $j7qgT) {
            Log::info("RY5HCDsWtYfLT has been deleted, discard it", ['imageId' => $Apw7Q]);
            return;
        } catch (\Exception $j7qgT) {
            Log::error("Failed to generate thumbnail", ['imageId' => $Apw7Q, 'error' => $j7qgT->getMessage()]);
        }
        goto QGHfG;
        eYayG:
        Log::info("Generating thumbnail", ['imageId' => $Apw7Q]);
        goto Ms3Ix;
        sqwbt:
        return null;
        goto zIIQZ;
        zIIQZ:
        laLG8:
        goto LeFvo;
        RjBpy:
        if (!($vDNzn >= $Tw7D8)) {
            goto laLG8;
        }
        goto sqwbt;
        zoNEz:
        $OgBY1 = $XhOlP->year;
        goto pjdm0;
        ONVRv:
        $mipNr = false;
        goto UP9vh;
        Go2CT:
        return null;
        goto b8o5h;
        QGHfG:
    }
    private function m4PcU9vvbQK(UBZJTNaXyHRoY $IU11E) : string
    {
        goto hTdHf;
        MDUsm:
        return 'polyla';
        goto G2AI6;
        wgocn:
        $Lg2A2 = $cF3e2 . '/' . self::Zebmp . 'X' . self::dZ9Vg;
        goto X8jyK;
        G2AI6:
        hxP_Y:
        goto wgocn;
        X8jyK:
        return $Lg2A2 . '/' . $IU11E->getFilename() . '.jpg';
        goto dU9M6;
        BFgNK:
        $zweTH = now()->setDate(2026, 3, 1);
        goto psaCX;
        psaCX:
        if (!($brAGg->diffInDays($zweTH, false) <= 0)) {
            goto hxP_Y;
        }
        goto MDUsm;
        pPuHP:
        $cF3e2 = dirname($sLe0F);
        goto D5_fe;
        D5_fe:
        $brAGg = now();
        goto BFgNK;
        hTdHf:
        $sLe0F = $IU11E->getLocation();
        goto pPuHP;
        dU9M6:
    }
}
