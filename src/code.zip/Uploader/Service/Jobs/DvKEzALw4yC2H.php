<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class DvKEzALw4yC2H implements StoreToS3JobInterface
{
    private $M9duE;
    private $f1xKj;
    private $SPj0U;
    public function __construct($U2Jsh, $C6boj, $KUQsT)
    {
        goto O3yuv;
        aiWnS:
        $this->SPj0U = $KUQsT;
        goto LYPH8;
        O3yuv:
        $this->f1xKj = $C6boj;
        goto aiWnS;
        LYPH8:
        $this->M9duE = $U2Jsh;
        goto JokMx;
        JokMx:
    }
    public function store(string $g5e_r) : void
    {
        goto CsqCm;
        kFcgL:
        return;
        goto HKC_K;
        CsqCm:
        $VadxA = XqAJHKYeaW2YU::findOrFail($g5e_r);
        goto b6Mrg;
        w082v:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $g5e_r]);
        goto xxS57;
        Zc4aZ:
        AFjal:
        goto b7dtK;
        zoAlU:
        $a1HS_ = $this->SPj0U->path($VadxA->getAttribute('preview'));
        goto pkpAF;
        LlhrU:
        $this->mPRRhHcu1ed($FlxOy, $VadxA->getLocation());
        goto NyANb;
        NyANb:
        $xU2jC = $VadxA->getAttribute('thumbnail');
        goto uhd25;
        YDEu3:
        Log::info("XqAJHKYeaW2YU stored to S3, update the children attachments", ['fileId' => $g5e_r]);
        goto h9K1D;
        b6Mrg:
        if ($VadxA) {
            goto l0JZt;
        }
        goto RXZB9;
        sdOio:
        t14H0:
        goto JVsPw;
        P1FVf:
        $this->f1xKj->put($VadxA->getAttribute('preview'), $this->SPj0U->get($VadxA->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $TkEfW->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Zc4aZ;
        JVsPw:
        if (!($VadxA->getAttribute('preview') && $this->SPj0U->exists($VadxA->getAttribute('preview')))) {
            goto AFjal;
        }
        goto zoAlU;
        RXZB9:
        Log::info("XqAJHKYeaW2YU has been deleted, discard it", ['fileId' => $g5e_r]);
        goto ryqKi;
        uhd25:
        if (!($xU2jC && $this->SPj0U->exists($xU2jC))) {
            goto t14H0;
        }
        goto E7qoI;
        pkpAF:
        $TkEfW = $this->M9duE->call($this, $a1HS_);
        goto P1FVf;
        fn212:
        $this->f1xKj->put($VadxA->getAttribute('thumbnail'), $this->SPj0U->get($xU2jC), ['visibility' => 'public', 'ContentType' => $T07ak->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto sdOio;
        h9K1D:
        XqAJHKYeaW2YU::where('parent_id', $g5e_r)->update(['driver' => Tq4KHV0o6oTIo::S3, 'preview' => $VadxA->getAttribute('preview'), 'thumbnail' => $VadxA->getAttribute('thumbnail')]);
        goto kFcgL;
        G8mjs:
        $T07ak = $this->M9duE->call($this, $C21b_);
        goto fn212;
        ryqKi:
        return;
        goto XlqCb;
        b7dtK:
        if (!$VadxA->update(['driver' => Tq4KHV0o6oTIo::S3, 'status' => MUu80sOhINyO3::FINISHED])) {
            goto DpWy6;
        }
        goto YDEu3;
        HKC_K:
        DpWy6:
        goto w082v;
        XlqCb:
        l0JZt:
        goto BBXyi;
        BBXyi:
        $FlxOy = $this->SPj0U->path($VadxA->getLocation());
        goto LlhrU;
        E7qoI:
        $C21b_ = $this->SPj0U->path($xU2jC);
        goto G8mjs;
        xxS57:
    }
    private function mPRRhHcu1ed($qC6je, $Oagnn, $Mwx3T = '')
    {
        goto Bf_60;
        ldqEI:
        $Oagnn = str_replace('.jpg', $Mwx3T, $Oagnn);
        goto ZlWDj;
        Bf_60:
        if (!$Mwx3T) {
            goto YMETP;
        }
        goto NXBB3;
        NXBB3:
        $qC6je = str_replace('.jpg', $Mwx3T, $qC6je);
        goto ldqEI;
        G8HfD:
        try {
            $MSkzT = $this->M9duE->call($this, $qC6je);
            $this->f1xKj->put($Oagnn, $this->SPj0U->get($Oagnn), ['visibility' => 'public', 'ContentType' => $MSkzT->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $lzebJ) {
            Log::error("Failed to upload image to S3", ['s3Path' => $Oagnn, 'error' => $lzebJ->getMessage()]);
        }
        goto Z9NJ6;
        ZlWDj:
        YMETP:
        goto G8HfD;
        Z9NJ6:
    }
}
