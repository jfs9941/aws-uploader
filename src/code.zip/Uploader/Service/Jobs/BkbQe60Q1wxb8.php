<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
class BkbQe60Q1wxb8 implements BlurJobInterface
{
    const bO05L = 15;
    const HJo_T = 500;
    const JGlVE = 500;
    private $R2XXS;
    private $wEVdN;
    private $A8xPF;
    public function __construct($I4Jnv, $dzspH, $ZT237)
    {
        goto TkaM0;
        MWBZw:
        $this->R2XXS = $I4Jnv;
        goto oKOR4;
        TkaM0:
        $this->A8xPF = $ZT237;
        goto hHHGm;
        hHHGm:
        $this->wEVdN = $dzspH;
        goto MWBZw;
        oKOR4:
    }
    public function blur(string $hOWbX) : void
    {
        goto bgIK1;
        cgwDe:
        Lq3_b:
        goto eVLga;
        eVLga:
        $Hxtzm->update(['preview' => $R7aL8]);
        goto GqdBO;
        B4h3M:
        if (!($Hxtzm->driver == NZ0k4EM0XOGE7::S3 && !$this->A8xPF->exists($Hxtzm->filename))) {
            goto qur1H;
        }
        goto zWWX8;
        uPhCn:
        throw new \Exception('Failed to set final permissions on image file: ' . $kDNl9);
        goto cgwDe;
        y2b5h:
        $h169k = $this->R2XXS->call($this, $this->A8xPF->path($Hxtzm->getLocation()));
        goto dcb3m;
        dcb3m:
        $JkoVl = $h169k->width() / $h169k->height();
        goto xcN4u;
        bgIK1:
        $Hxtzm = D6FgZi8OHmjic::findOrFail($hOWbX);
        goto Q3Mgx;
        xcN4u:
        $h169k->resize(self::HJo_T, self::JGlVE / $JkoVl);
        goto q8YuP;
        corfb:
        \Log::warning('Failed to set final permissions on image file: ' . $kDNl9);
        goto uPhCn;
        k5PHl:
        unset($h169k);
        goto mcIMF;
        VFJcE:
        $this->A8xPF->put($Hxtzm->filename, $CORO0);
        goto eIjHT;
        Q3Mgx:
        ini_set('memory_limit', '-1');
        goto B4h3M;
        q8YuP:
        $h169k->blur(self::bO05L);
        goto YaH3K;
        eIjHT:
        qur1H:
        goto y2b5h;
        zWWX8:
        $CORO0 = $this->wEVdN->get($Hxtzm->filename);
        goto VFJcE;
        mcIMF:
        if (chmod($kDNl9, 0664)) {
            goto Lq3_b;
        }
        goto corfb;
        YaH3K:
        $R7aL8 = $this->mJI3AT3TwBf($Hxtzm);
        goto vLAFQ;
        vLAFQ:
        $kDNl9 = $this->wEVdN->put($R7aL8, $h169k->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto k5PHl;
        GqdBO:
    }
    private function mJI3AT3TwBf($Z0EoW) : string
    {
        goto mlt8a;
        jAhHw:
        $IreU2 = dirname($D4enG) . '/preview/';
        goto shQJD;
        mlt8a:
        $D4enG = $Z0EoW->getLocation();
        goto jAhHw;
        shQJD:
        if ($this->A8xPF->exists($IreU2)) {
            goto ZYaRm;
        }
        goto dBGg3;
        u0mNE:
        ZYaRm:
        goto Zzcn1;
        dBGg3:
        $this->A8xPF->makeDirectory($IreU2, 0755, true);
        goto u0mNE;
        Zzcn1:
        return $IreU2 . $Z0EoW->getFilename() . '.jpg';
        goto Ka3k5;
        Ka3k5:
    }
}
