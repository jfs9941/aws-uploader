<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class SlR2p0ymVgfJp
{
    private $IzVXL;
    private $s434U;
    public function __construct(int $X0Yx9, int $ikLDa)
    {
        goto ph3Sp;
        tCU1R:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto RMpFd;
        ktJCQ:
        $this->IzVXL = $X0Yx9;
        goto d9yJv;
        gSGVi:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto s8VpN;
        s8VpN:
        cUgWy:
        goto LyrZ8;
        d9yJv:
        $this->s434U = $ikLDa;
        goto XSuCF;
        RMpFd:
        KQX9Y:
        goto ktJCQ;
        LyrZ8:
        if (!($ikLDa <= 0)) {
            goto KQX9Y;
        }
        goto tCU1R;
        ph3Sp:
        if (!($X0Yx9 <= 0)) {
            goto cUgWy;
        }
        goto gSGVi;
        XSuCF:
    }
    private static function mxHUfeaPnO9($V8W9z, string $g37Ct = 'floor') : int
    {
        goto Hd8IG;
        APPbM:
        return (int) $V8W9z;
        goto oUkhE;
        oUkhE:
        g3lXj:
        goto bCBYV;
        lS4pD:
        I5UmV:
        goto KfDl4;
        Gd4Xe:
        return $V8W9z;
        goto y633c;
        bCBYV:
        switch (strtolower($g37Ct)) {
            case 'ceil':
                return (int) (ceil($V8W9z / 2) * 2);
            case 'round':
                return (int) (round($V8W9z / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($V8W9z / 2) * 2);
        }
        goto lS4pD;
        y633c:
        OsJrK:
        goto VvyVt;
        VvyVt:
        if (!(is_float($V8W9z) && $V8W9z == floor($V8W9z) && (int) $V8W9z % 2 === 0)) {
            goto g3lXj;
        }
        goto APPbM;
        Hd8IG:
        if (!(is_int($V8W9z) && $V8W9z % 2 === 0)) {
            goto OsJrK;
        }
        goto Gd4Xe;
        KfDl4:
        kZGdp:
        goto guR9b;
        guR9b:
    }
    public function mIiWPR3OCUB(string $uHz0O = 'floor') : array
    {
        goto QCFpG;
        z2jcS:
        $dT4RR = 0;
        goto EFx4G;
        KpHkT:
        $dT4RR = 2;
        goto ReJlZ;
        N3McZ:
        return ['width' => $IF3Pq, 'height' => $dT4RR];
        goto JTZvj;
        eNxZg:
        $Om7yv = $IF3Pq / $this->IzVXL;
        goto ipeYH;
        b0kG2:
        $IF3Pq = self::mxHUfeaPnO9(round($xZJNR), $uHz0O);
        goto F9zR0;
        ReJlZ:
        pNBzv:
        goto N3McZ;
        PoSJt:
        $dT4RR = $pPTlm;
        goto Wh7hx;
        iGeh6:
        $IF3Pq = $pPTlm;
        goto eNxZg;
        EFx4G:
        if ($this->IzVXL >= $this->s434U) {
            goto a09xi;
        }
        goto iGeh6;
        DCz2O:
        $IF3Pq = 2;
        goto WnSaG;
        F9zR0:
        h6g2Q:
        goto uxrV3;
        TX55h:
        $dT4RR = self::mxHUfeaPnO9(round($hwj9f), $uHz0O);
        goto N7wOR;
        BQUEi:
        if (!($dT4RR < 2)) {
            goto pNBzv;
        }
        goto KpHkT;
        naH5y:
        $xZJNR = $this->IzVXL * $Om7yv;
        goto b0kG2;
        QCFpG:
        $pPTlm = 1080;
        goto RLY7m;
        N7wOR:
        goto h6g2Q;
        goto EaYaN;
        ipeYH:
        $hwj9f = $this->s434U * $Om7yv;
        goto TX55h;
        WnSaG:
        QM3wx:
        goto BQUEi;
        EaYaN:
        a09xi:
        goto PoSJt;
        RLY7m:
        $IF3Pq = 0;
        goto z2jcS;
        Wh7hx:
        $Om7yv = $dT4RR / $this->s434U;
        goto naH5y;
        uxrV3:
        if (!($IF3Pq < 2)) {
            goto QM3wx;
        }
        goto DCz2O;
        JTZvj:
    }
}
