<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class YkQZ80FqJ5eHy
{
    private $dj1MR;
    private $AuZBF;
    private $IRlXr;
    private $aB4Qh;
    public function __construct($ckm9x, $EuYOv, $JGvdR, $Q0D24)
    {
        goto ykC1T;
        ZoY9D:
        $this->dj1MR = $ckm9x;
        goto tPqJz;
        ykC1T:
        $this->AuZBF = $EuYOv;
        goto zloOE;
        zloOE:
        $this->IRlXr = $JGvdR;
        goto e1LtP;
        e1LtP:
        $this->aB4Qh = $Q0D24;
        goto ZoY9D;
        tPqJz:
    }
    public function mwyFxhSDrij(?int $yyWeX, ?int $q2cOY, string $t1mLK, bool $EJG7d = false) : string
    {
        goto jK5Jg;
        iulyy:
        $EVi_k = 0.1;
        goto j5jqW;
        KR3gd:
        if (!($yyWeX > 1500)) {
            goto z7XRM;
        }
        goto u3Sg9;
        u3Sg9:
        $X48SN -= $HHYMC * 0.4;
        goto BGyZ_;
        BGyZ_:
        z7XRM:
        goto K1bos;
        GAOHL:
        if (!$this->IRlXr->exists($XkdbN)) {
            goto bObRO;
        }
        goto tOesr;
        bxtLN:
        $XkdbN = $this->mEnHNn14CLr($S5jnz, $yyWeX, $q2cOY, $U1V1d, $YxPUt);
        goto GAOHL;
        K1bos:
        $fDQWm = $q2cOY - $YxPUt - 10;
        goto NwauN;
        NwauN:
        $Xxl6q->text($S5jnz, $X48SN, (int) $fDQWm, function ($WTeT_) use($YxPUt) {
            goto QO2nt;
            OJEof:
            $WTeT_->color([185, 185, 185, 1]);
            goto CcRsi;
            CcRsi:
            $WTeT_->valign('middle');
            goto ghvGf;
            QO2nt:
            $WTeT_->file(public_path($this->AuZBF));
            goto YytgL;
            ghvGf:
            $WTeT_->align('middle');
            goto WONf_;
            YytgL:
            $MxxAU = (int) ($YxPUt * 1.2);
            goto GwTSX;
            GwTSX:
            $WTeT_->size(max($MxxAU, 1));
            goto OJEof;
            WONf_:
        });
        goto n9kiU;
        oj36x:
        bObRO:
        goto kjwjX;
        qHMQn:
        ENSpM:
        goto iulyy;
        MucTP:
        $HHYMC = (int) ($X48SN / 80);
        goto FzJjB;
        FzJjB:
        $X48SN -= $HHYMC;
        goto KR3gd;
        cDlDW:
        return $EJG7d ? $XkdbN : $this->IRlXr->url($XkdbN);
        goto s1ygg;
        mWHcC:
        $this->IRlXr->put($XkdbN, $Xxl6q->stream('png'));
        goto cDlDW;
        tOesr:
        return $EJG7d ? $XkdbN : $this->IRlXr->url($XkdbN);
        goto oj36x;
        RfNlJ:
        $X48SN = $yyWeX - $U1V1d;
        goto MucTP;
        n9kiU:
        $this->aB4Qh->put($XkdbN, $Xxl6q->stream('png'));
        goto mWHcC;
        kjwjX:
        $Xxl6q = $this->dj1MR->call($this, $yyWeX, $q2cOY);
        goto RfNlJ;
        jK5Jg:
        if (!($yyWeX === null || $q2cOY === null)) {
            goto ENSpM;
        }
        goto ume8C;
        j5jqW:
        list($YxPUt, $U1V1d, $S5jnz) = $this->mSOQHLyBYWI($t1mLK, $yyWeX, $EVi_k, (float) $yyWeX / $q2cOY);
        goto bxtLN;
        ume8C:
        throw new \RuntimeException("B6s4AA1exjQ2T dimensions are not available.");
        goto qHMQn;
        s1ygg:
    }
    private function mEnHNn14CLr(string $t1mLK, int $yyWeX, int $q2cOY, int $X_Jpk, int $Vwfou) : string
    {
        $e0OWh = ltrim($t1mLK, '@');
        return "v2/watermark/{$e0OWh}/{$yyWeX}x{$q2cOY}_{$X_Jpk}x{$Vwfou}/text_watermark.png";
    }
    private function mSOQHLyBYWI($t1mLK, int $yyWeX, float $SYjcq, float $lN9cc) : array
    {
        goto iBem2;
        lNPza:
        return [(int) $kr02B, $U1V1d, $S5jnz];
        goto NlvRN;
        s5ZCG:
        $kr02B = $U1V1d / (strlen($S5jnz) * 0.8);
        goto Hlwmb;
        ZZycS:
        $kr02B = 1 / $lN9cc * $U1V1d / strlen($S5jnz);
        goto lNPza;
        Hlwmb:
        return [(int) $kr02B, $kr02B * strlen($S5jnz) / 1.8, $S5jnz];
        goto Lbn28;
        QANAE:
        if (!($lN9cc > 1)) {
            goto hQciQ;
        }
        goto s5ZCG;
        WO4V8:
        $U1V1d = (int) ($yyWeX * $SYjcq);
        goto QANAE;
        Lbn28:
        hQciQ:
        goto ZZycS;
        iBem2:
        $S5jnz = '@' . $t1mLK;
        goto WO4V8;
        NlvRN:
    }
}
