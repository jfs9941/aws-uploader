<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
class Rj1tg0wqN9jzV implements BlurVideoJobInterface
{
    const eSBnU = 15;
    const trREs = 500;
    const DSHY1 = 500;
    private $xI8aP;
    private $GQuun;
    private $Farqu;
    public function __construct($uIkIq, $Q0shJ, $MQQLd)
    {
        goto No5oI;
        WctqO:
        $this->xI8aP = $uIkIq;
        goto V7MF7;
        dpHIE:
        $this->GQuun = $Q0shJ;
        goto WctqO;
        No5oI:
        $this->Farqu = $MQQLd;
        goto dpHIE;
        V7MF7:
    }
    public function blur(string $eXur0) : void
    {
        goto mTCKp;
        k5vs3:
        fKSNY:
        goto jlLJN;
        x3BMZ:
        if (!$k0WzT->getAttribute('thumbnail')) {
            goto fKSNY;
        }
        goto ZMECH;
        EG01O:
        $k0WzT = S25BfMDKrX8cB::findOrFail($eXur0);
        goto x3BMZ;
        dN8DX:
        $h31Qj = $this->Farqu->path($Q0sMv);
        goto wp6JC;
        GpW6p:
        $Q0sMv = $this->mJKF51YZReG($k0WzT);
        goto dN8DX;
        HydR3:
        $CPHMS->blur(self::eSBnU);
        goto GpW6p;
        wp6JC:
        $CPHMS->save($h31Qj);
        goto T_brM;
        nK8Ia:
        $CPHMS = $this->xI8aP->call($this, $this->Farqu->path($k0WzT->getAttribute('thumbnail')));
        goto cJnDj;
        vmucC:
        $k0WzT->update(['preview' => $Q0sMv]);
        goto k5vs3;
        ldQGi:
        $CPHMS->resize(self::trREs, self::DSHY1 / $RgaZf);
        goto HydR3;
        B7yoW:
        if (chmod($h31Qj, 0664)) {
            goto i3BzR;
        }
        goto ETQP3;
        KbAZm:
        ini_set('memory_limit', '-1');
        goto EG01O;
        mN0sH:
        i3BzR:
        goto vmucC;
        mTCKp:
        Log::info("Blurring for video", ['videoID' => $eXur0]);
        goto KbAZm;
        ZMECH:
        $this->Farqu->put($k0WzT->getAttribute('thumbnail'), $this->GQuun->get($k0WzT->getAttribute('thumbnail')));
        goto nK8Ia;
        T_brM:
        $this->GQuun->put($Q0sMv, $this->Farqu->get($Q0sMv));
        goto W8KG6;
        ETQP3:
        \Log::warning('Failed to set final permissions on image file: ' . $h31Qj);
        goto wYKjL;
        cJnDj:
        $RgaZf = $CPHMS->width() / $CPHMS->height();
        goto ldQGi;
        W8KG6:
        $CPHMS->destroy();
        goto B7yoW;
        wYKjL:
        throw new \Exception('Failed to set final permissions on image file: ' . $h31Qj);
        goto mN0sH;
        jlLJN:
    }
    private function mJKF51YZReG(Y5tmWZcWsdzIB $cDHFV) : string
    {
        goto Undpn;
        Undpn:
        $Y7TgX = $cDHFV->getLocation();
        goto EHMMV;
        KTAh5:
        if ($this->Farqu->exists($jNq3M)) {
            goto n6OlI;
        }
        goto eqvic;
        Eea7R:
        n6OlI:
        goto qQ74D;
        EHMMV:
        $jNq3M = dirname($Y7TgX) . '/preview/';
        goto KTAh5;
        eqvic:
        $this->Farqu->makeDirectory($jNq3M, 0755, true);
        goto Eea7R;
        qQ74D:
        return $jNq3M . $cDHFV->getFilename() . '.jpg';
        goto wPpLt;
        wPpLt:
    }
}
