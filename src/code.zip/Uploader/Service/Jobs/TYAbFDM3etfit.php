<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Encoder\QskQm1izUO3G7;
use Jfs\Uploader\Encoder\LbzHNsWFIAPi8;
use Jfs\Uploader\Encoder\LoHH67lOeFp9J;
use Jfs\Uploader\Encoder\NdDX16WGrVibA;
use Jfs\Uploader\Encoder\SUstEnfinI8Ng;
use Jfs\Uploader\Encoder\NsAe9ORmo3m5D;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Jfs\Uploader\Service\Jobs\PcqFcOuDmkIRY;
use Jfs\Uploader\Service\Jobs\FfdAEtVFCtHnp;
use Jfs\Uploader\Service\KtvKQ6SgzhDbU;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class TYAbFDM3etfit implements MediaEncodeJobInterface
{
    private $pHuSQ;
    private $zoOKU;
    private $PxC6l;
    private $i16be;
    private $xramE;
    public function __construct(string $h2Cp1, $e3FbC, $kxhX9, $mBdvd, $rQUoL)
    {
        goto FV6iX;
        VChJx:
        $this->i16be = $mBdvd;
        goto lwu6Q;
        lwu6Q:
        $this->xramE = $rQUoL;
        goto bhL1T;
        FV6iX:
        $this->pHuSQ = $h2Cp1;
        goto UaORy;
        UaORy:
        $this->zoOKU = $e3FbC;
        goto pWPIo;
        pWPIo:
        $this->PxC6l = $kxhX9;
        goto VChJx;
        bhL1T:
    }
    public function encode(string $S580N, string $tsV_X, $arex_ = true) : void
    {
        goto j6hKK;
        j6hKK:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $S580N]);
        goto tp_oQ;
        tp_oQ:
        ini_set('memory_limit', '-1');
        goto OjEmV;
        OjEmV:
        try {
            goto XOkF8;
            XOkF8:
            $Bh2o5 = BtruCfJoaSWZ6::findOrFail($S580N);
            goto K0Pdx;
            IaJgH:
            if (!$ySKpa) {
                goto jz8M7;
            }
            goto d4Zen;
            kp3LZ:
            $b3eGW->mCnU6U0mCug($ZMuBa);
            goto TWMN7;
            qSIm_:
            $b3eGW = app(SUstEnfinI8Ng::class);
            goto EaHCA;
            EdPB2:
            $b3eGW = $b3eGW->mZ9LJlxWXDo($lSq7k);
            goto BL2FZ;
            Z1vfo:
            $ySKpa = $this->m8ax70zMOP4($j3pzE, $I3tEC->mIeA78uqetR($Bh2o5->width(), $Bh2o5->height(), $tsV_X));
            goto IaJgH;
            sVS50:
            Log::info("Set 1080p resolution for Job", ['width' => $qcXzW['width'], 'height' => $qcXzW['height'], 'originalWidth' => $Sv6q3, 'originalHeight' => $G9pt9]);
            goto qaTXp;
            zlWHg:
            $b3eGW->mr6h3IadK1P($jm7lB->mbeczwwgUpg($Bh2o5));
            goto iGe23;
            DjYI1:
            if (!($Sv6q3 && $G9pt9)) {
                goto Z8oE3;
            }
            goto VGzHD;
            EaHCA:
            $b3eGW = $b3eGW->mMPtSIN56BN(new NdDX16WGrVibA($b4XyD));
            goto fpG2f;
            dhFbB:
            $b4XyD = $this->mMhyBpeCxED($Bh2o5);
            goto eVtjI;
            CPzKy:
            $b3eGW = $b3eGW->mCnU6U0mCug($lST3v);
            goto kgMvv;
            d4Zen:
            $ZMuBa = $ZMuBa->mbryH9c0fv1($ySKpa);
            goto GqGOr;
            TWMN7:
            $b3eGW->mr6h3IadK1P($jm7lB->mbeczwwgUpg($Bh2o5));
            goto DjYI1;
            kgMvv:
            vmsEG:
            goto fvGY8;
            UiZ5u:
            $lST3v = $lST3v->mbryH9c0fv1($ySKpa);
            goto z5ipW;
            lskUl:
            $ySKpa = $this->m8ax70zMOP4($j3pzE, $I3tEC->mIeA78uqetR((int) $qcXzW['width'], (int) $qcXzW['height'], $tsV_X));
            goto eohhD;
            vgXUn:
            throw new MediaConverterException("BtruCfJoaSWZ6 {$Bh2o5->id} is not S3 driver");
            goto eu9wo;
            oQCzE:
            $lSq7k = new QskQm1izUO3G7($Bh2o5->nL5aO ?? 1, 2, $jm7lB->mItFQGnG9Ni($Bh2o5));
            goto EdPB2;
            iGe23:
            $j3pzE = app(KtvKQ6SgzhDbU::class);
            goto KVKgX;
            xloxo:
            $qcXzW = $this->mCIPfIfrD03($Sv6q3, $G9pt9);
            goto sVS50;
            eu9wo:
            jb31d:
            goto NXOEF;
            fvGY8:
            Z8oE3:
            goto xZqFN;
            xZqFN:
            Log::info("Set thumbnail for BtruCfJoaSWZ6 Job", ['videoId' => $Bh2o5->getAttribute('id'), 'duration' => $Bh2o5->getAttribute('duration')]);
            goto oQCzE;
            K0Pdx:
            Assert::isInstanceOf($Bh2o5, BtruCfJoaSWZ6::class);
            goto IMjOH;
            GqGOr:
            jz8M7:
            goto kp3LZ;
            NXOEF:
            $Sv6q3 = $Bh2o5->width();
            goto SR0uc;
            jP3FE:
            $b3eGW->mCnU6U0mCug($ZMuBa);
            goto zlWHg;
            fpG2f:
            $ZMuBa = new LbzHNsWFIAPi8('original', $Sv6q3, $G9pt9, $Bh2o5->diIgo ?? 30);
            goto NNcAO;
            NNcAO:
            $jm7lB = app(LoHH67lOeFp9J::class);
            goto jP3FE;
            qaTXp:
            $lST3v = new LbzHNsWFIAPi8('1080p', $qcXzW['width'], $qcXzW['height'], $Bh2o5->diIgo ?? 30);
            goto lskUl;
            IMjOH:
            if (!($Bh2o5->gUPdP !== McZXbZmlQ53or::S3)) {
                goto jb31d;
            }
            goto vgXUn;
            eVtjI:
            Log::info("Set input video for Job", ['s3Uri' => $b4XyD]);
            goto qSIm_;
            SR0uc:
            $G9pt9 = $Bh2o5->height();
            goto dhFbB;
            KVKgX:
            $I3tEC = new FfdAEtVFCtHnp($this->i16be, $this->xramE, $this->PxC6l, $this->zoOKU);
            goto Z1vfo;
            VGzHD:
            if (!$this->min1dwro8AR($Sv6q3, $G9pt9)) {
                goto vmsEG;
            }
            goto xloxo;
            eohhD:
            if (!$ySKpa) {
                goto j8r2e;
            }
            goto UiZ5u;
            z5ipW:
            j8r2e:
            goto CPzKy;
            BL2FZ:
            $S580N = $b3eGW->meN8mEENSn2($this->mpqsazzMz4q($Bh2o5, $arex_));
            goto N_xWo;
            N_xWo:
            $Bh2o5->update(['aws_media_converter_job_id' => $S580N]);
            goto STkxb;
            STkxb:
        } catch (\Exception $p0etA) {
            Log::info("BtruCfJoaSWZ6 has been deleted, discard it", ['fileId' => $S580N, 'err' => $p0etA->getMessage()]);
            return;
        }
        goto fN2Vt;
        fN2Vt:
    }
    private function mpqsazzMz4q(BtruCfJoaSWZ6 $Bh2o5, $arex_) : bool
    {
        goto A79HU;
        Jw282:
        $n5e3t = (int) round($Bh2o5->getAttribute('duration') ?? 0);
        goto I2SAP;
        A79HU:
        if ($arex_) {
            goto GR3yl;
        }
        goto OznbD;
        E9_D0:
        GR3yl:
        goto Jw282;
        OznbD:
        return false;
        goto E9_D0;
        emc2B:
        nuK5H:
        goto MYIkz;
        I2SAP:
        switch (true) {
            case $Bh2o5->width() * $Bh2o5->height() >= 1920 * 1080 && $Bh2o5->width() * $Bh2o5->height() < 2560 * 1440:
                return $n5e3t > 10 * 60;
            case $Bh2o5->width() * $Bh2o5->height() >= 2560 * 1440 && $Bh2o5->width() * $Bh2o5->height() < 3840 * 2160:
                return $n5e3t > 5 * 60;
            case $Bh2o5->width() * $Bh2o5->height() >= 3840 * 2160:
                return $n5e3t > 3 * 60;
            default:
                return false;
        }
        goto emc2B;
        MYIkz:
        uFC0P:
        goto R0Ixl;
        R0Ixl:
    }
    private function m8ax70zMOP4(KtvKQ6SgzhDbU $j3pzE, string $t1Sgh) : ?NsAe9ORmo3m5D
    {
        goto d0OMP;
        ufVuT:
        E6GEe:
        goto b7u4Y;
        d0OMP:
        $AXFFc = $j3pzE->m8fpXmJUzSQ($t1Sgh);
        goto y4Tha;
        b7u4Y:
        return null;
        goto tMLFg;
        rF4m7:
        return new NsAe9ORmo3m5D($AXFFc, 0, 0, null, null);
        goto ufVuT;
        G4xAU:
        if (!$AXFFc) {
            goto E6GEe;
        }
        goto rF4m7;
        y4Tha:
        Log::info("Resolve watermark for job with url", ['url' => $t1Sgh, 'uri' => $AXFFc]);
        goto G4xAU;
        tMLFg:
    }
    private function min1dwro8AR(int $Sv6q3, int $G9pt9) : bool
    {
        return $Sv6q3 * $G9pt9 > 1.5 * (1920 * 1080);
    }
    private function mCIPfIfrD03(int $Sv6q3, int $G9pt9) : array
    {
        $OTzfa = new PcqFcOuDmkIRY($Sv6q3, $G9pt9);
        return $OTzfa->mS2twOpS5px();
    }
    private function mMhyBpeCxED(GpdHFYchpZHPa $gR4Y3) : string
    {
        goto XEekJ;
        XEekJ:
        if (!($gR4Y3->gUPdP == McZXbZmlQ53or::S3)) {
            goto TOAP0;
        }
        goto AwwNF;
        pvQ70:
        return $this->zoOKU->url($gR4Y3->filename);
        goto uxPu7;
        DtKh7:
        TOAP0:
        goto pvQ70;
        AwwNF:
        return 's3://' . $this->pHuSQ . '/' . $gR4Y3->filename;
        goto DtKh7;
        uxPu7:
    }
}
