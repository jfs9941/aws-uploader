<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Encoder\PAx9IusVgAzRb;
use Jfs\Uploader\Encoder\RO20FOPlN3fZQ;
use Jfs\Uploader\Encoder\R1OfWFis73GHj;
use Jfs\Uploader\Encoder\Vgz1Jn4ZgdZ37;
use Jfs\Uploader\Encoder\PSvg4a6rPX3zY;
use Jfs\Uploader\Encoder\RAnwJh59aP1hj;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
use Jfs\Uploader\Service\BDt6SdH8IQ07z;
use Webmozart\Assert\Assert;
class SMCVIfKYGqQpy implements MediaEncodeJobInterface
{
    private $rczpf;
    private $bX3fI;
    private $auR_S;
    private $ow_A9;
    private $agUMw;
    public function __construct(string $qir1P, $Q0hWX, $JhAxH, $nNU6n, $Ein3P)
    {
        goto sdEmk;
        sLI0A:
        $this->bX3fI = $Q0hWX;
        goto jtStz;
        jtStz:
        $this->auR_S = $JhAxH;
        goto g59u7;
        sdEmk:
        $this->rczpf = $qir1P;
        goto sLI0A;
        g59u7:
        $this->ow_A9 = $nNU6n;
        goto oO1T6;
        oO1T6:
        $this->agUMw = $Ein3P;
        goto rBlL1;
        rBlL1:
    }
    public function encode(string $IaHim, string $sIqHa, $SIGoO = true) : void
    {
        goto Znq1X;
        h5ltK:
        try {
            goto niGoM;
            eID8G:
            xPVWm:
            goto s3ZKW;
            KTDFy:
            $zVSZe = new EJHKjyBhy7Tvv($this->ow_A9, $this->agUMw, $this->auR_S, $this->bX3fI);
            goto JKV1t;
            ibQ3s:
            $cOJfH = $cOJfH->mwRngGW0Uxm($vzwrQ);
            goto KY1Zx;
            eS_LK:
            Log::info("Set input video for Job", ['s3Uri' => $mKChv]);
            goto aQ8sO;
            xV_SB:
            $O81mB->m3c7HKHoooK($dJJYg->m4EDDeLZFBA($vd5JT));
            goto Sd9XI;
            ZeeV3:
            $jsBPG = $this->mF1Dg4pwSZU($ABqPe, $dE8ui);
            goto SfiMV;
            r6Z4i:
            $qxQtj = $qxQtj->mwRngGW0Uxm($vzwrQ);
            goto eID8G;
            vdF3C:
            throw new MediaConverterException("ACdpgX4YCYP6M {$vd5JT->id} is not S3 driver");
            goto hb3kr;
            myXN9:
            if (!$this->mlwLaNkxA7z($ABqPe, $dE8ui)) {
                goto iSIag;
            }
            goto ZeeV3;
            niGoM:
            $vd5JT = ACdpgX4YCYP6M::findOrFail($IaHim);
            goto yy4gX;
            sVx40:
            $IaHim = $O81mB->m7cvyyyEKtp($this->m6fObgI7xgU($vd5JT, $SIGoO));
            goto Qxg8F;
            SfiMV:
            Log::info("Set 1080p resolution for Job", ['width' => $jsBPG['width'], 'height' => $jsBPG['height'], 'originalWidth' => $ABqPe, 'originalHeight' => $dE8ui]);
            goto Ynhk8;
            KM9MX:
            $dJJYg = app(R1OfWFis73GHj::class);
            goto RuB3p;
            Zcz5b:
            Log::info("Set thumbnail for ACdpgX4YCYP6M Job", ['videoId' => $vd5JT->getAttribute('id'), 'duration' => $vd5JT->getAttribute('duration')]);
            goto n12qP;
            yy4gX:
            Assert::isInstanceOf($vd5JT, ACdpgX4YCYP6M::class);
            goto PeVsH;
            KY1Zx:
            dnlKc:
            goto dS1gy;
            RuB3p:
            $O81mB->m8SNYxL0llb($qxQtj);
            goto xV_SB;
            NN_Ya:
            $ABqPe = $vd5JT->width();
            goto EZmw6;
            gmWOy:
            $vzwrQ = $this->mZk05zjdrqJ($cEpkz, $zVSZe->mqpgBukKPi0((int) $jsBPG['width'], (int) $jsBPG['height'], $sIqHa));
            goto na0xb;
            Ynhk8:
            $cOJfH = new RO20FOPlN3fZQ('1080p', $jsBPG['width'], $jsBPG['height'], $vd5JT->ooHv4 ?? 30);
            goto gmWOy;
            o2_s0:
            iSIag:
            goto jsbTo;
            JKV1t:
            $vzwrQ = $this->mZk05zjdrqJ($cEpkz, $zVSZe->mqpgBukKPi0($vd5JT->width(), $vd5JT->height(), $sIqHa));
            goto Q1Y5u;
            I3Lec:
            $O81mB->m3c7HKHoooK($dJJYg->m4EDDeLZFBA($vd5JT));
            goto NoT93;
            dS1gy:
            $O81mB = $O81mB->m8SNYxL0llb($cOJfH);
            goto o2_s0;
            NiCIW:
            $O81mB = $O81mB->mBIEkztvl3g($NSw82);
            goto sVx40;
            KRje3:
            $qxQtj = new RO20FOPlN3fZQ('original', $ABqPe, $dE8ui, $vd5JT->ooHv4 ?? 30);
            goto KM9MX;
            NoT93:
            if (!($ABqPe && $dE8ui)) {
                goto mWWIE;
            }
            goto myXN9;
            jsbTo:
            mWWIE:
            goto Zcz5b;
            EZmw6:
            $dE8ui = $vd5JT->height();
            goto dYJe7;
            Qxg8F:
            $vd5JT->update(['aws_media_converter_job_id' => $IaHim]);
            goto Sj1bz;
            na0xb:
            if (!$vzwrQ) {
                goto dnlKc;
            }
            goto ibQ3s;
            aQ8sO:
            $O81mB = app(PSvg4a6rPX3zY::class);
            goto G5cGf;
            hb3kr:
            WQcSQ:
            goto NN_Ya;
            dYJe7:
            $mKChv = $this->mhZNFCLx5uj($vd5JT);
            goto eS_LK;
            Sd9XI:
            $cEpkz = app(BDt6SdH8IQ07z::class);
            goto KTDFy;
            G5cGf:
            $O81mB = $O81mB->mzedKEYcGcA(new Vgz1Jn4ZgdZ37($mKChv));
            goto KRje3;
            PeVsH:
            if (!($vd5JT->bdBtT !== FUIPeZ7ssitYw::S3)) {
                goto WQcSQ;
            }
            goto vdF3C;
            n12qP:
            $NSw82 = new PAx9IusVgAzRb($vd5JT->iJMBf ?? 1, 2, $dJJYg->mbcYqobUCzW($vd5JT));
            goto NiCIW;
            s3ZKW:
            $O81mB->m8SNYxL0llb($qxQtj);
            goto I3Lec;
            Q1Y5u:
            if (!$vzwrQ) {
                goto xPVWm;
            }
            goto r6Z4i;
            Sj1bz:
        } catch (\Exception $djmN_) {
            Log::info("ACdpgX4YCYP6M has been deleted, discard it", ['fileId' => $IaHim, 'err' => $djmN_->getMessage()]);
            return;
        }
        goto Xxc3I;
        WRx2q:
        ini_set('memory_limit', '-1');
        goto h5ltK;
        Znq1X:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $IaHim]);
        goto WRx2q;
        Xxc3I:
    }
    private function m6fObgI7xgU(ACdpgX4YCYP6M $vd5JT, $SIGoO) : bool
    {
        goto SmFmE;
        wm0wA:
        Mdutu:
        goto GNd2_;
        UPyEq:
        zm6SP:
        goto hijaw;
        GNd2_:
        $oR1K4 = (int) round($vd5JT->getAttribute('duration') ?? 0);
        goto uaa7d;
        SmFmE:
        if ($SIGoO) {
            goto Mdutu;
        }
        goto Meq52;
        uaa7d:
        switch (true) {
            case $vd5JT->width() * $vd5JT->height() >= 1920 * 1080 && $vd5JT->width() * $vd5JT->height() < 2560 * 1440:
                return $oR1K4 > 10 * 60;
            case $vd5JT->width() * $vd5JT->height() >= 2560 * 1440 && $vd5JT->width() * $vd5JT->height() < 3840 * 2160:
                return $oR1K4 > 5 * 60;
            case $vd5JT->width() * $vd5JT->height() >= 3840 * 2160:
                return $oR1K4 > 3 * 60;
            default:
                return false;
        }
        goto XrHf2;
        Meq52:
        return false;
        goto wm0wA;
        XrHf2:
        EM16R:
        goto UPyEq;
        hijaw:
    }
    private function mZk05zjdrqJ(BDt6SdH8IQ07z $cEpkz, string $vUmcN) : ?RAnwJh59aP1hj
    {
        goto h5tB4;
        h5tB4:
        $cMGVn = $cEpkz->mIzQ8ovCIrk($vUmcN);
        goto NFTDB;
        utbZd:
        return null;
        goto DRqVw;
        Pp2aK:
        if (!$cMGVn) {
            goto wZZtz;
        }
        goto gUC_b;
        gUC_b:
        return new RAnwJh59aP1hj($cMGVn, 0, 0, null, null);
        goto TuFAG;
        TuFAG:
        wZZtz:
        goto utbZd;
        NFTDB:
        Log::info("Resolve watermark for job with url", ['url' => $vUmcN, 'uri' => $cMGVn]);
        goto Pp2aK;
        DRqVw:
    }
    private function mlwLaNkxA7z(int $ABqPe, int $dE8ui) : bool
    {
        return $ABqPe * $dE8ui > 1.5 * (1920 * 1080);
    }
    private function mF1Dg4pwSZU(int $ABqPe, int $dE8ui) : array
    {
        $fNeya = new KCyL27foHGxFH($ABqPe, $dE8ui);
        return $fNeya->mHJWxewSCRp();
    }
    private function mhZNFCLx5uj(GuA6QuvssLUzf $nNNVD) : string
    {
        goto VGAg0;
        R1ua4:
        C482i:
        goto aBEfb;
        VGAg0:
        if (!($nNNVD->bdBtT == FUIPeZ7ssitYw::S3)) {
            goto C482i;
        }
        goto j_k03;
        j_k03:
        return 's3://' . $this->rczpf . '/' . $nNNVD->filename;
        goto R1ua4;
        aBEfb:
        return $this->bX3fI->url($nNNVD->filename);
        goto tEhgb;
        tEhgb:
    }
}
