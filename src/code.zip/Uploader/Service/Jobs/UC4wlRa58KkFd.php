<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
class UC4wlRa58KkFd implements StoreVideoToS3JobInterface
{
    private $yZ_G3;
    private $zTo0t;
    private $uBhrQ;
    public function __construct($vT463, $Vi8xq, $Ms6sq)
    {
        goto X1mip;
        OA4lP:
        $this->uBhrQ = $Ms6sq;
        goto iKzVe;
        iKzVe:
        $this->yZ_G3 = $vT463;
        goto Ng7k3;
        X1mip:
        $this->zTo0t = $Vi8xq;
        goto OA4lP;
        Ng7k3:
    }
    public function store(string $S6xyJ) : void
    {
        goto ufcEW;
        GDS08:
        GESZz:
        goto Ov1Ig;
        hksPB:
        $JMKzk = memory_get_usage();
        goto mvLy3;
        ddw95:
        $IHNE3 = $this->zTo0t->getClient();
        goto WAhcr;
        XJj9J:
        $piVF4 = microtime(true);
        goto hksPB;
        RAndG:
        CqxjS:
        goto mLHlq;
        TuoOm:
        return;
        goto RAndG;
        IAAEF:
        return;
        goto GDS08;
        z4v0_:
        if ($Zz1r7) {
            goto CqxjS;
        }
        goto Kp00J;
        Ov1Ig:
        $Sv8m2 = $Ms6sq->readStream($Zz1r7->getLocation());
        goto ZnNPf;
        ufcEW:
        Log::info('Storing video (local) to S3', ['fileId' => $S6xyJ, 'bucketName' => $this->yZ_G3]);
        goto Zksq0;
        ZnNPf:
        $lYoIc = 1024 * 1024 * 50;
        goto fqqlJ;
        fqqlJ:
        $qRKiQ = $Ms6sq->mimeType($Zz1r7->getLocation());
        goto XJj9J;
        mLHlq:
        if ($Ms6sq->exists($Zz1r7->getLocation())) {
            goto GESZz;
        }
        goto ixt71;
        Kp00J:
        Log::info("Kt6NO3eUvdER6 has been deleted, discard it", ['fileId' => $S6xyJ]);
        goto TuoOm;
        WAhcr:
        $Ms6sq = $this->uBhrQ;
        goto Bslqt;
        CKcr2:
        try {
            goto M3sIh;
            awmyT:
            $Ms6sq->delete($Zz1r7->getLocation());
            goto JmFsv;
            gEIwy:
            goto IAmlM;
            goto JUnzl;
            cSKCO:
            fclose($Sv8m2);
            goto FWa8L;
            N7A5W:
            $LG7Qm++;
            goto gEIwy;
            M3sIh:
            $hp3yb = $IHNE3->createMultipartUpload(['Bucket' => $this->yZ_G3, 'Key' => $Zz1r7->getLocation(), 'ContentType' => $qRKiQ, 'ContentDisposition' => 'inline']);
            goto dAtVE;
            f0FvL:
            IAmlM:
            goto r02Xc;
            FWa8L:
            $IHNE3->completeMultipartUpload(['Bucket' => $this->yZ_G3, 'Key' => $Zz1r7->getLocation(), 'UploadId' => $LX_Uw, 'MultipartUpload' => ['Parts' => $Wft18]]);
            goto Cq81t;
            r02Xc:
            if (feof($Sv8m2)) {
                goto LmQgR;
            }
            goto YjEDK;
            infI_:
            $Wft18 = [];
            goto f0FvL;
            Cq81t:
            $Zz1r7->update(['driver' => Rc6MZhMMdyG6A::S3, 'status' => EUkqoDwU9Zcvh::FINISHED]);
            goto awmyT;
            HeCrR:
            $LG7Qm = 1;
            goto infI_;
            JUnzl:
            LmQgR:
            goto cSKCO;
            dAtVE:
            $LX_Uw = $hp3yb['UploadId'];
            goto HeCrR;
            YjEDK:
            $flZk4 = $IHNE3->uploadPart(['Bucket' => $this->yZ_G3, 'Key' => $Zz1r7->getLocation(), 'UploadId' => $LX_Uw, 'PartNumber' => $LG7Qm, 'Body' => fread($Sv8m2, $lYoIc)]);
            goto IiRfZ;
            IiRfZ:
            $Wft18[] = ['PartNumber' => $LG7Qm, 'ETag' => $flZk4['ETag']];
            goto N7A5W;
            JmFsv:
        } catch (AwsException $WTk3U) {
            goto zvoko;
            nHPHE:
            CYH2g:
            goto rqwTc;
            rqwTc:
            Log::error('Failed to store video: ' . $Zz1r7->getLocation() . ' - ' . $WTk3U->getMessage());
            goto Lk8Yf;
            zvoko:
            if (!isset($LX_Uw)) {
                goto CYH2g;
            }
            goto Hql1S;
            Hql1S:
            try {
                $IHNE3->abortMultipartUpload(['Bucket' => $this->yZ_G3, 'Key' => $Zz1r7->getLocation(), 'UploadId' => $LX_Uw]);
            } catch (AwsException $Bklll) {
                Log::error('Error aborting multipart upload: ' . $Bklll->getMessage());
            }
            goto nHPHE;
            Lk8Yf:
        } finally {
            $Mzhg0 = microtime(true);
            $xdlh4 = memory_get_usage();
            $OC5ML = memory_get_peak_usage();
            Log::info('HCrMjr1ZIoi6r function resource usage', ['fileId' => $S6xyJ, 'execution_time_sec' => $Mzhg0 - $piVF4, 'memory_usage_bytes' => $xdlh4 - $JMKzk, 'peak_memory_usage_bytes' => $OC5ML - $V2At5]);
        }
        goto SBD6x;
        Zksq0:
        ini_set('memory_limit', '-1');
        goto ddw95;
        ixt71:
        Log::error("[UC4wlRa58KkFd] File not found, discard it ", ['video' => $Zz1r7->getLocation()]);
        goto IAAEF;
        Bslqt:
        $Zz1r7 = Kt6NO3eUvdER6::find($S6xyJ);
        goto z4v0_;
        mvLy3:
        $V2At5 = memory_get_peak_usage();
        goto CKcr2;
        SBD6x:
    }
}
