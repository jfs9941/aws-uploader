<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class ESNBpulqF3Yia
{
    private $FLPPb;
    private $mTrVt;
    public function __construct(int $iH3AM, int $A04ge)
    {
        goto GrSBG;
        GrSBG:
        if (!($iH3AM <= 0)) {
            goto SAWGn;
        }
        goto o_DNp;
        UjfGC:
        Gve27:
        goto kiaRf;
        axEY7:
        if (!($A04ge <= 0)) {
            goto Gve27;
        }
        goto oi2bV;
        mMlWA:
        $this->mTrVt = $A04ge;
        goto oUNEU;
        o_DNp:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto u7tla;
        kiaRf:
        $this->FLPPb = $iH3AM;
        goto mMlWA;
        u7tla:
        SAWGn:
        goto axEY7;
        oi2bV:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto UjfGC;
        oUNEU:
    }
    private static function mKqAVXAHjJd($gHdNq, string $eTCAA = 'floor') : int
    {
        goto s54of;
        JxpnM:
        switch (strtolower($eTCAA)) {
            case 'ceil':
                return (int) (ceil($gHdNq / 2) * 2);
            case 'round':
                return (int) (round($gHdNq / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($gHdNq / 2) * 2);
        }
        goto dBlTo;
        s54of:
        if (!(is_int($gHdNq) && $gHdNq % 2 === 0)) {
            goto EBddZ;
        }
        goto sdxv9;
        o0BSK:
        return (int) $gHdNq;
        goto An_xt;
        TcP0Q:
        if (!(is_float($gHdNq) && $gHdNq == floor($gHdNq) && (int) $gHdNq % 2 === 0)) {
            goto G2f20;
        }
        goto o0BSK;
        Pe6fp:
        wd1U5:
        goto LGdgd;
        sdxv9:
        return $gHdNq;
        goto g7I8s;
        g7I8s:
        EBddZ:
        goto TcP0Q;
        dBlTo:
        bvjru:
        goto Pe6fp;
        An_xt:
        G2f20:
        goto JxpnM;
        LGdgd:
    }
    public function mZinayPg81n(string $k_w94 = 'floor') : array
    {
        goto GOl3F;
        sCeXp:
        iABkY:
        goto T6PYj;
        h9RX7:
        if (!($QVvW8 < 2)) {
            goto NOJat;
        }
        goto qjnVA;
        tqPzs:
        $Qnv1S = $DXEWd;
        goto Dn_ji;
        SB8O4:
        $QVvW8 = 0;
        goto mgq2E;
        gSMMN:
        $G1OUo = $this->mTrVt * $tSV4u;
        goto WSsCK;
        nkkVl:
        if (!($Qnv1S < 2)) {
            goto iABkY;
        }
        goto aEiUb;
        eD_Rb:
        EdqhH:
        goto h9RX7;
        Gp6jg:
        $QVvW8 = self::mKqAVXAHjJd(round($rFtNo), $k_w94);
        goto eD_Rb;
        fCNZF:
        goto EdqhH;
        goto HFzYp;
        dv2_D:
        $rFtNo = $this->FLPPb * $tSV4u;
        goto Gp6jg;
        aEiUb:
        $Qnv1S = 2;
        goto sCeXp;
        T6PYj:
        return ['width' => $QVvW8, 'height' => $Qnv1S];
        goto sjrSm;
        uzomR:
        $QVvW8 = $DXEWd;
        goto dCNK9;
        eJsC2:
        if ($this->FLPPb >= $this->mTrVt) {
            goto jsp7G;
        }
        goto uzomR;
        qjnVA:
        $QVvW8 = 2;
        goto uD1ma;
        WSsCK:
        $Qnv1S = self::mKqAVXAHjJd(round($G1OUo), $k_w94);
        goto fCNZF;
        dCNK9:
        $tSV4u = $QVvW8 / $this->FLPPb;
        goto gSMMN;
        Dn_ji:
        $tSV4u = $Qnv1S / $this->mTrVt;
        goto dv2_D;
        uD1ma:
        NOJat:
        goto nkkVl;
        HFzYp:
        jsp7G:
        goto tqPzs;
        GOl3F:
        $DXEWd = 1080;
        goto SB8O4;
        mgq2E:
        $Qnv1S = 0;
        goto eJsC2;
        sjrSm:
    }
}
