<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Encoder\DdzEZ8yPIp5zI;
use Jfs\Uploader\Encoder\VLQyUVNUaHRA4;
use Jfs\Uploader\Encoder\QTx5zGpV1D5nP;
use Jfs\Uploader\Encoder\Hbut6W3eL4gpe;
use Jfs\Uploader\Encoder\H23Olmd74uCyo;
use Jfs\Uploader\Encoder\HCrMjr1ZIoi6r;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
use Jfs\Uploader\Service\B9bpWG3g8Q6mz;
use Webmozart\Assert\Assert;
class GrVNK6ig7zvOa implements MediaEncodeJobInterface
{
    private $kALX2;
    private $s0VP1;
    private $zTo0t;
    private $wzdVy;
    private $EHcHx;
    public function __construct(string $vT463, $TuWZt, $Vi8xq, $HIvH7, $Ly36A)
    {
        goto qPnBp;
        PeW6B:
        $this->s0VP1 = $TuWZt;
        goto tOmRP;
        BeCW8:
        $this->wzdVy = $HIvH7;
        goto oYzNO;
        oYzNO:
        $this->EHcHx = $Ly36A;
        goto JRpGk;
        tOmRP:
        $this->zTo0t = $Vi8xq;
        goto BeCW8;
        qPnBp:
        $this->kALX2 = $vT463;
        goto PeW6B;
        JRpGk:
    }
    public function encode(string $S6xyJ, string $QyRqP, $nvMxY = true) : void
    {
        goto PK1z4;
        OzZlq:
        ini_set('memory_limit', '-1');
        goto J3k4w;
        J3k4w:
        try {
            goto m9KS5;
            KJKce:
            $mn4R2 = $mn4R2->mOb5PRM026E($c2ORW);
            goto dsf3T;
            nEoKc:
            Assert::isInstanceOf($yZXjN, Kt6NO3eUvdER6::class);
            goto YU1ak;
            e2vYX:
            $mn4R2 = app(H23Olmd74uCyo::class);
            goto v22NM;
            DsSIZ:
            $Mnzeo = new KRAKiGGIqBhRX($this->wzdVy, $this->EHcHx, $this->zTo0t, $this->s0VP1);
            goto uPFI2;
            P203A:
            $jPx0d = $jPx0d->mZiMka8JQnR($fhBnS);
            goto ypPIb;
            YU1ak:
            if (!($yZXjN->n5TQN !== Rc6MZhMMdyG6A::S3)) {
                goto CEcL7;
            }
            goto EJG37;
            uPFI2:
            $fhBnS = $this->mtzyB9vcK0x($Hes5T, $Mnzeo->mpYSbSHWX85($yZXjN->width(), $yZXjN->height(), $QyRqP));
            goto y_B1L;
            O0xU1:
            $mn4R2->mM2V9PXAqLb($pXjq4->mLBw2o8Cbbe($yZXjN));
            goto uzQPq;
            KG1Uz:
            $c2ORW = new DdzEZ8yPIp5zI($yZXjN->Je8Me ?? 1, 2, $pXjq4->mtzqPJqcjI5($yZXjN));
            goto KJKce;
            jfkEd:
            $jPx0d = new VLQyUVNUaHRA4('1080p', $HyJ0I['width'], $HyJ0I['height'], $yZXjN->tivSy ?? 30);
            goto VZM6z;
            J12fC:
            Bf9t1:
            goto ZMyDP;
            ZMyDP:
            $mn4R2->mFshQbfbMkK($geJfj);
            goto O0xU1;
            VTNFO:
            $yZXjN->update(['aws_media_converter_job_id' => $S6xyJ]);
            goto OjWi7;
            SM1B1:
            $mn4R2->mM2V9PXAqLb($pXjq4->mLBw2o8Cbbe($yZXjN));
            goto B18ZA;
            EJG37:
            throw new MediaConverterException("Kt6NO3eUvdER6 {$yZXjN->id} is not S3 driver");
            goto TPpUj;
            ypPIb:
            kVHaM:
            goto M0HPb;
            Uh_t5:
            $pXjq4 = app(QTx5zGpV1D5nP::class);
            goto v8U5L;
            y_B1L:
            if (!$fhBnS) {
                goto Bf9t1;
            }
            goto xHhx9;
            ZDL44:
            Log::info("Set 1080p resolution for Job", ['width' => $HyJ0I['width'], 'height' => $HyJ0I['height'], 'originalWidth' => $kl8qs, 'originalHeight' => $nl3gy]);
            goto jfkEd;
            NpUx_:
            $l0kyu = $this->mZ28P1Fud69($yZXjN);
            goto M2Erq;
            hiN2o:
            Vcw8g:
            goto Zi3do;
            qsE4n:
            if (!$fhBnS) {
                goto kVHaM;
            }
            goto P203A;
            v8U5L:
            $mn4R2->mFshQbfbMkK($geJfj);
            goto SM1B1;
            v22NM:
            $mn4R2 = $mn4R2->mE1xDWPkYj2(new Hbut6W3eL4gpe($l0kyu));
            goto mHCC4;
            ikKz9:
            $HyJ0I = $this->mDK4HFGvo3M($kl8qs, $nl3gy);
            goto ZDL44;
            dsf3T:
            $S6xyJ = $mn4R2->mQx4taafmXW($this->mqDAt8QHL1T($yZXjN, $nvMxY));
            goto VTNFO;
            B18ZA:
            $Hes5T = app(B9bpWG3g8Q6mz::class);
            goto DsSIZ;
            OqVBe:
            if (!$this->m2u1wpIHFma($kl8qs, $nl3gy)) {
                goto scF_a;
            }
            goto ikKz9;
            pfUAB:
            scF_a:
            goto hiN2o;
            TPpUj:
            CEcL7:
            goto t3jeo;
            qTscY:
            $nl3gy = $yZXjN->height();
            goto NpUx_;
            M2Erq:
            Log::info("Set input video for Job", ['s3Uri' => $l0kyu]);
            goto e2vYX;
            xHhx9:
            $geJfj = $geJfj->mZiMka8JQnR($fhBnS);
            goto J12fC;
            Zi3do:
            Log::info("Set thumbnail for Kt6NO3eUvdER6 Job", ['videoId' => $yZXjN->getAttribute('id'), 'duration' => $yZXjN->getAttribute('duration')]);
            goto KG1Uz;
            uzQPq:
            if (!($kl8qs && $nl3gy)) {
                goto Vcw8g;
            }
            goto OqVBe;
            mHCC4:
            $geJfj = new VLQyUVNUaHRA4('original', $kl8qs, $nl3gy, $yZXjN->tivSy ?? 30);
            goto Uh_t5;
            VZM6z:
            $fhBnS = $this->mtzyB9vcK0x($Hes5T, $Mnzeo->mpYSbSHWX85((int) $HyJ0I['width'], (int) $HyJ0I['height'], $QyRqP));
            goto qsE4n;
            M0HPb:
            $mn4R2 = $mn4R2->mFshQbfbMkK($jPx0d);
            goto pfUAB;
            m9KS5:
            $yZXjN = Kt6NO3eUvdER6::findOrFail($S6xyJ);
            goto nEoKc;
            t3jeo:
            $kl8qs = $yZXjN->width();
            goto qTscY;
            OjWi7:
        } catch (\Exception $NvDiU) {
            Log::info("Kt6NO3eUvdER6 has been deleted, discard it", ['fileId' => $S6xyJ, 'err' => $NvDiU->getMessage()]);
            return;
        }
        goto Hq25C;
        PK1z4:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $S6xyJ]);
        goto OzZlq;
        Hq25C:
    }
    private function mqDAt8QHL1T(Kt6NO3eUvdER6 $yZXjN, $nvMxY) : bool
    {
        goto MqAI5;
        x3skD:
        Ooftf:
        goto m4Paq;
        Yxlgq:
        $cRxw9 = (int) round($yZXjN->getAttribute('duration') ?? 0);
        goto ugEoP;
        MqAI5:
        if ($nvMxY) {
            goto aiGnk;
        }
        goto n4eAm;
        YJqLy:
        aiGnk:
        goto Yxlgq;
        m4Paq:
        Jkv7C:
        goto oSGgE;
        ugEoP:
        switch (true) {
            case $yZXjN->width() * $yZXjN->height() >= 1920 * 1080 && $yZXjN->width() * $yZXjN->height() < 2560 * 1440:
                return $cRxw9 > 10 * 60;
            case $yZXjN->width() * $yZXjN->height() >= 2560 * 1440 && $yZXjN->width() * $yZXjN->height() < 3840 * 2160:
                return $cRxw9 > 5 * 60;
            case $yZXjN->width() * $yZXjN->height() >= 3840 * 2160:
                return $cRxw9 > 3 * 60;
            default:
                return false;
        }
        goto x3skD;
        n4eAm:
        return false;
        goto YJqLy;
        oSGgE:
    }
    private function mtzyB9vcK0x(B9bpWG3g8Q6mz $Hes5T, string $tfm8f) : ?HCrMjr1ZIoi6r
    {
        goto c4VRL;
        oBheh:
        return new HCrMjr1ZIoi6r($lLOjs, 0, 0, null, null);
        goto hh_bk;
        M00IG:
        if (!$lLOjs) {
            goto bzFMo;
        }
        goto oBheh;
        hh_bk:
        bzFMo:
        goto b7P6k;
        uOnhr:
        Log::info("Resolve watermark for job with url", ['url' => $tfm8f, 'uri' => $lLOjs]);
        goto M00IG;
        b7P6k:
        return null;
        goto nh9r9;
        c4VRL:
        $lLOjs = $Hes5T->mPXAqsMnwsu($tfm8f);
        goto uOnhr;
        nh9r9:
    }
    private function m2u1wpIHFma(int $kl8qs, int $nl3gy) : bool
    {
        return $kl8qs * $nl3gy > 1.5 * (1920 * 1080);
    }
    private function mDK4HFGvo3M(int $kl8qs, int $nl3gy) : array
    {
        $QkTdX = new LXFKX4tQX3D0P($kl8qs, $nl3gy);
        return $QkTdX->mHs8GaRQLfS();
    }
    private function mZ28P1Fud69(DMUaxGX7XHAI0 $hEivM) : string
    {
        goto wN1jH;
        jeNiI:
        return $this->s0VP1->url($hEivM->filename);
        goto P_yXd;
        Jw9dT:
        return 's3://' . $this->kALX2 . '/' . $hEivM->filename;
        goto jUzEF;
        jUzEF:
        W8o5C:
        goto jeNiI;
        wN1jH:
        if (!($hEivM->n5TQN == Rc6MZhMMdyG6A::S3)) {
            goto W8o5C;
        }
        goto Jw9dT;
        P_yXd:
    }
}
