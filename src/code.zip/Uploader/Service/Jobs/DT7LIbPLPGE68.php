<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Encoder\Du6R3WXKXjwE4;
use Jfs\Uploader\Encoder\WsTEbWEHtefqv;
use Jfs\Uploader\Encoder\A8w0sFEmIyJGd;
use Jfs\Uploader\Encoder\T5yvSbVhcIDJU;
use Jfs\Uploader\Encoder\AOVLsclrMzgAM;
use Jfs\Uploader\Encoder\NmK17VowgXji2;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Jfs\Uploader\Service\Jobs\HI51OyVOVSVWY;
use Jfs\Uploader\Service\Jobs\LGhbTm20DkXql;
use Jfs\Uploader\Service\WqQUjHBw41oKQ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class DT7LIbPLPGE68 implements MediaEncodeJobInterface
{
    private $nmHDC;
    private $TD3CW;
    private $Mayr9;
    private $XsZUt;
    private $Fv8Ey;
    public function __construct(string $wIlgi, $e3uVO, $KI4Gx, $K0xgM, $vKBlW)
    {
        goto YSJYK;
        leo21:
        $this->Mayr9 = $KI4Gx;
        goto bRTKo;
        U41GX:
        $this->Fv8Ey = $vKBlW;
        goto Lae1T;
        oBOkJ:
        $this->TD3CW = $e3uVO;
        goto leo21;
        bRTKo:
        $this->XsZUt = $K0xgM;
        goto U41GX;
        YSJYK:
        $this->nmHDC = $wIlgi;
        goto oBOkJ;
        Lae1T:
    }
    public function encode(string $iG1wy, string $Z9AwD, $U2Wy8 = true) : void
    {
        goto Qv_V4;
        IrfHY:
        try {
            goto vdO0j;
            GMU0e:
            if (!$nNqIA) {
                goto lDUKT;
            }
            goto dMrHM;
            TB8pb:
            Log::info("AelPShnd8pMtD already has Media Converter Job ID, skip encoding", ['fileId' => $iG1wy, 'jobId' => $aHaxS->getAttribute('aws_media_converter_job_id')]);
            goto d1QZ_;
            zH15W:
            $acmWA = app(A8w0sFEmIyJGd::class);
            goto AAEFr;
            gAaBr:
            $BlYNY = new WsTEbWEHtefqv('1080p', $hBSeR['width'], $hBSeR['height'], $aHaxS->hQ7Uv ?? 30);
            goto CSBPN;
            LTLb9:
            $ZdnGh = $ZdnGh->mKmhR9ypYTz($BlYNY);
            goto kpegG;
            Jbg6y:
            if (!$aHaxS->getAttribute('aws_media_converter_job_id')) {
                goto wBWpj;
            }
            goto TB8pb;
            C53Gq:
            $UTcqA = $UTcqA->m4kFWHhTxOv($nNqIA);
            goto D8XcY;
            Bvipw:
            $ZdnGh->mKmhR9ypYTz($UTcqA);
            goto iY9TO;
            q3EXb:
            Log::info("Set thumbnail for AelPShnd8pMtD Job", ['videoId' => $aHaxS->getAttribute('id'), 'duration' => $aHaxS->getAttribute('duration')]);
            goto ZKiiU;
            w4Pjl:
            $hBSeR = $this->mpRUUaHKNov($tz4Lg, $vmBjz);
            goto f1yJz;
            iY9TO:
            $ZdnGh->mfgWd86e8fk($acmWA->mWDWYOqR3MC($aHaxS));
            goto JCbDf;
            xsvxg:
            Assert::isInstanceOf($aHaxS, AelPShnd8pMtD::class);
            goto o6jWN;
            D8XcY:
            ECd4q:
            goto Bvipw;
            n7gT5:
            $ZdnGh = $ZdnGh->maQVxVjaJzf($uTfBu);
            goto sWRZg;
            LTf1G:
            $nNqIA = $this->mcupN21zBBg($paMBW, $VhU77->mNPBpvIvThx($aHaxS->width(), $aHaxS->height(), $Z9AwD));
            goto Cbz0R;
            AAEFr:
            $ZdnGh->mfgWd86e8fk($acmWA->mWDWYOqR3MC($aHaxS));
            goto FwyZB;
            ZeKbI:
            wBWpj:
            goto GSOMu;
            U_DLb:
            Log::info("Set input video for Job", ['s3Uri' => $p9KFp]);
            goto vjfW7;
            mtYoM:
            $ZdnGh = $ZdnGh->mMlllWaNf6p(new T5yvSbVhcIDJU($p9KFp));
            goto nOh5M;
            FwyZB:
            $paMBW = app(WqQUjHBw41oKQ::class);
            goto Bj5Ow;
            Bj5Ow:
            $VhU77 = new LGhbTm20DkXql($this->XsZUt, $this->Fv8Ey, $this->Mayr9, $this->TD3CW);
            goto LTf1G;
            dMrHM:
            $BlYNY = $BlYNY->m4kFWHhTxOv($nNqIA);
            goto cbajE;
            gpbYX:
            $vmBjz = $aHaxS->height();
            goto kI1w1;
            o6jWN:
            if (!($aHaxS->driver != Ef6Dy6MoUDei9::S3)) {
                goto b_OyC;
            }
            goto OnDLv;
            nOh5M:
            $UTcqA = new WsTEbWEHtefqv('original', $tz4Lg, $vmBjz, $aHaxS->hQ7Uv ?? 30);
            goto zH15W;
            djMyL:
            b_OyC:
            goto Jbg6y;
            vjfW7:
            $ZdnGh = app(AOVLsclrMzgAM::class);
            goto mtYoM;
            kI1w1:
            $p9KFp = $this->mCDchjUG6CP($aHaxS);
            goto U_DLb;
            d1QZ_:
            return;
            goto ZeKbI;
            TiayI:
            $aHaxS->update(['aws_media_converter_job_id' => $iG1wy]);
            goto OpBbS;
            kpegG:
            qfjry:
            goto NZ68b;
            osKLq:
            if (!$this->mIlj0yMs65L($tz4Lg, $vmBjz)) {
                goto qfjry;
            }
            goto w4Pjl;
            ZKiiU:
            $uTfBu = new Du6R3WXKXjwE4($aHaxS->getAttribute('duration') ?? 1, 2, $acmWA->mTmWGUwCChs($aHaxS));
            goto n7gT5;
            cbajE:
            lDUKT:
            goto LTLb9;
            f1yJz:
            Log::info("Set 1080p resolution for Job", ['width' => $hBSeR['width'], 'height' => $hBSeR['height'], 'originalWidth' => $tz4Lg, 'originalHeight' => $vmBjz]);
            goto gAaBr;
            vdO0j:
            $aHaxS = AelPShnd8pMtD::findOrFail($iG1wy);
            goto xsvxg;
            JCbDf:
            if (!($tz4Lg && $vmBjz)) {
                goto Ur_dq;
            }
            goto osKLq;
            GSOMu:
            $tz4Lg = $aHaxS->width();
            goto gpbYX;
            Cbz0R:
            if (!$nNqIA) {
                goto ECd4q;
            }
            goto C53Gq;
            sWRZg:
            $iG1wy = $ZdnGh->moR1n97kuyV($this->mLFQJTLUsiN($aHaxS, $U2Wy8));
            goto TiayI;
            OnDLv:
            throw new MediaConverterException("AelPShnd8pMtD {$aHaxS->id} is not S3 driver value = {$aHaxS->driver}");
            goto djMyL;
            NZ68b:
            Ur_dq:
            goto q3EXb;
            CSBPN:
            $nNqIA = $this->mcupN21zBBg($paMBW, $VhU77->mNPBpvIvThx((int) $hBSeR['width'], (int) $hBSeR['height'], $Z9AwD));
            goto GMU0e;
            OpBbS:
        } catch (\Exception $wEHhy) {
            goto PrP1U;
            PrP1U:
            Log::warning("AelPShnd8pMtD has been deleted, discard it", ['fileId' => $iG1wy, 'err' => $wEHhy->getMessage()]);
            goto zHFbI;
            TTWqT:
            return;
            goto aKzY1;
            zHFbI:
            Sentry::captureException($wEHhy);
            goto TTWqT;
            aKzY1:
        }
        goto Wifg4;
        lUkfz:
        ini_set('memory_limit', '-1');
        goto IrfHY;
        Qv_V4:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $iG1wy]);
        goto lUkfz;
        Wifg4:
    }
    private function mLFQJTLUsiN(AelPShnd8pMtD $aHaxS, $U2Wy8) : bool
    {
        goto ype95;
        CwHvm:
        bNdRq:
        goto cJGE1;
        M404b:
        $UEsjQ = (int) round($aHaxS->getAttribute('duration') ?? 0);
        goto qwcN1;
        fsQzg:
        dgN16:
        goto CwHvm;
        qwcN1:
        switch (true) {
            case $aHaxS->width() * $aHaxS->height() >= 1920 * 1080 && $aHaxS->width() * $aHaxS->height() < 2560 * 1440:
                return $UEsjQ > 30 * 60;
            case $aHaxS->width() * $aHaxS->height() >= 2560 * 1440 && $aHaxS->width() * $aHaxS->height() < 3840 * 2160:
                return $UEsjQ > 15 * 60;
            case $aHaxS->width() * $aHaxS->height() >= 3840 * 2160:
                return $UEsjQ > 10 * 60;
            default:
                return false;
        }
        goto fsQzg;
        ype95:
        if ($U2Wy8) {
            goto tgbxn;
        }
        goto ZQkRO;
        yEYBV:
        tgbxn:
        goto M404b;
        ZQkRO:
        return false;
        goto yEYBV;
        cJGE1:
    }
    private function mcupN21zBBg(WqQUjHBw41oKQ $paMBW, string $YHzDC) : ?NmK17VowgXji2
    {
        goto Pfi6R;
        XMlUR:
        Log::info("Resolve watermark for job with url", ['url' => $YHzDC, 'uri' => $UGalB]);
        goto l_EE8;
        r2pms:
        rCztq:
        goto yk6c0;
        l_EE8:
        if (!$UGalB) {
            goto rCztq;
        }
        goto zRFh4;
        zRFh4:
        return new NmK17VowgXji2($UGalB, 0, 0, null, null);
        goto r2pms;
        Pfi6R:
        $UGalB = $paMBW->mxGU2PsdveS($YHzDC);
        goto XMlUR;
        yk6c0:
        return null;
        goto TGuSa;
        TGuSa:
    }
    private function mIlj0yMs65L(int $tz4Lg, int $vmBjz) : bool
    {
        return $tz4Lg * $vmBjz > 1.5 * (1920 * 1080);
    }
    private function mpRUUaHKNov(int $tz4Lg, int $vmBjz) : array
    {
        $ZvXrM = new HI51OyVOVSVWY($tz4Lg, $vmBjz);
        return $ZvXrM->m2oW4LxRirL();
    }
    private function mCDchjUG6CP(GSmU4C9IL4AGB $qc05M) : string
    {
        goto RcKeg;
        RcKeg:
        if (!($qc05M->driver == Ef6Dy6MoUDei9::S3)) {
            goto yxSWt;
        }
        goto fiP22;
        SUDU0:
        yxSWt:
        goto Vinxh;
        Vinxh:
        return $this->TD3CW->url($qc05M->filename);
        goto tiQcX;
        fiP22:
        return 's3://' . $this->nmHDC . '/' . $qc05M->filename;
        goto SUDU0;
        tiQcX:
    }
}
