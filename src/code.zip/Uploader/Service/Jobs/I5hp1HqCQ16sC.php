<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service\Jobs;

use backup\Exposed\Jobs\SdQaPOKj9eEdP;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class I5hp1HqCQ16sC implements SdQaPOKj9eEdP
{
    private $W3SEw;
    private $kEfMA;
    private $c35HU;
    public function __construct($DrcMD, $FP6ih, $VHhUy)
    {
        goto aO0ED;
        PYjQ7:
        $this->W3SEw = $DrcMD;
        goto QphBy;
        HE9KM:
        $this->c35HU = $VHhUy;
        goto PYjQ7;
        aO0ED:
        $this->kEfMA = $FP6ih;
        goto HE9KM;
        QphBy:
    }
    public function store(string $EQQae) : void
    {
        goto OIlSX;
        x3xTN:
        $this->mml0LH1nNZo($KPnwr, $y42U4->getLocation());
        goto IV8ma;
        IV8ma:
        $iorE7 = $y42U4->getAttribute('thumbnail');
        goto wzQL7;
        sb3db:
        if (!$y42U4->update(['driver' => XmcIS8CQn72i3::S3, 'status' => Aetm2HiFuJE34::FINISHED])) {
            goto Y3ewV;
        }
        goto iuRIa;
        n2Cqa:
        $this->kEfMA->put($y42U4->getAttribute('preview'), $this->c35HU->get($y42U4->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $VMkP3->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto v27TL;
        eXNis:
        if (!($y42U4->getAttribute('preview') && $this->c35HU->exists($y42U4->getAttribute('preview')))) {
            goto Qprto;
        }
        goto W6Mca;
        uXrPD:
        return;
        goto TKIc1;
        qTsBq:
        mVopR:
        goto eXNis;
        kUZ2f:
        $KPnwr = $this->c35HU->path($y42U4->getLocation());
        goto x3xTN;
        PziK6:
        CrEYqpC23XUGo::where('parent_id', $EQQae)->update(['driver' => XmcIS8CQn72i3::S3, 'preview' => $y42U4->getAttribute('preview'), 'thumbnail' => $y42U4->getAttribute('thumbnail')]);
        goto YdiJU;
        DlxF4:
        Log::info("CrEYqpC23XUGo has been deleted, discard it", ['fileId' => $EQQae]);
        goto uXrPD;
        tIYFt:
        $g6MD1 = $this->c35HU->path($iorE7);
        goto FRj8R;
        v27TL:
        Qprto:
        goto sb3db;
        OIlSX:
        $y42U4 = CrEYqpC23XUGo::findOrFail($EQQae);
        goto V2XAY;
        YdiJU:
        return;
        goto AoE9Y;
        TKIc1:
        k3oe_:
        goto kUZ2f;
        wzQL7:
        if (!($iorE7 && $this->c35HU->exists($iorE7))) {
            goto mVopR;
        }
        goto tIYFt;
        qehku:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $EQQae]);
        goto VTClK;
        NpsJr:
        $this->kEfMA->put($y42U4->getAttribute('thumbnail'), $this->c35HU->get($iorE7), ['visibility' => 'public', 'ContentType' => $bp6Lq->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto qTsBq;
        W6Mca:
        $vHYos = $this->c35HU->path($y42U4->getAttribute('preview'));
        goto PN_1R;
        iuRIa:
        Log::info("CrEYqpC23XUGo stored to S3, update the children attachments", ['fileId' => $EQQae]);
        goto PziK6;
        FRj8R:
        $bp6Lq = $this->W3SEw->call($this, $g6MD1);
        goto NpsJr;
        PN_1R:
        $VMkP3 = $this->W3SEw->call($this, $vHYos);
        goto n2Cqa;
        V2XAY:
        if ($y42U4) {
            goto k3oe_;
        }
        goto DlxF4;
        AoE9Y:
        Y3ewV:
        goto qehku;
        VTClK:
    }
    private function mml0LH1nNZo($oX7F1, $T6Ro7, $VgtDV = '')
    {
        goto xf1Ng;
        aURId:
        try {
            $ulojh = $this->W3SEw->call($this, $oX7F1);
            $this->kEfMA->put($T6Ro7, $this->c35HU->get($T6Ro7), ['visibility' => 'public', 'ContentType' => $ulojh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $eQXjs) {
            Log::error("Failed to upload image to S3", ['s3Path' => $T6Ro7, 'error' => $eQXjs->getMessage()]);
        }
        goto d_PMl;
        OhtIq:
        lD36x:
        goto aURId;
        xf1Ng:
        if (!$VgtDV) {
            goto lD36x;
        }
        goto LTyfL;
        lJVWw:
        $T6Ro7 = str_replace('.jpg', $VgtDV, $T6Ro7);
        goto OhtIq;
        LTyfL:
        $oX7F1 = str_replace('.jpg', $VgtDV, $oX7F1);
        goto lJVWw;
        d_PMl:
    }
}
