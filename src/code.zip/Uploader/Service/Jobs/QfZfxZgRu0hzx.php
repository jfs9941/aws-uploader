<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
class QfZfxZgRu0hzx implements BlurJobInterface
{
    const nYZzX = 15;
    const a4eBw = 500;
    const HGSWR = 500;
    private $e2JZZ;
    private $uiTOc;
    private $dwubH;
    public function __construct($yGjLo, $ATeSz, $VzPPJ)
    {
        goto SyAlz;
        SyAlz:
        $this->dwubH = $VzPPJ;
        goto yHWkQ;
        jPfuQ:
        $this->e2JZZ = $yGjLo;
        goto WDX4Q;
        yHWkQ:
        $this->uiTOc = $ATeSz;
        goto jPfuQ;
        WDX4Q:
    }
    public function blur(string $B_L9m) : void
    {
        goto nL_c3;
        oVbb8:
        $zCabx = $this->e2JZZ->call($this, $this->dwubH->path($LS13w->getLocation()));
        goto RKI7t;
        RKI7t:
        $j3ttF = $zCabx->width() / $zCabx->height();
        goto xDvY4;
        WlfCi:
        $zCabx->blur(self::nYZzX);
        goto wJG2K;
        fmr2r:
        $LS13w->update(['preview' => $qGbOo]);
        goto iXTPS;
        e1ujX:
        if (!($LS13w->euRQL == J0IuL8wroLOWt::S3 && !$this->dwubH->exists($LS13w->filename))) {
            goto hIX0f;
        }
        goto u6lQe;
        u6lQe:
        $rk2Va = $this->uiTOc->get($LS13w->filename);
        goto zUml7;
        xDvY4:
        $zCabx->resize(self::a4eBw, self::HGSWR / $j3ttF);
        goto WlfCi;
        ePfKY:
        AqVhx:
        goto fmr2r;
        CzCOu:
        \Log::warning('Failed to set final permissions on image file: ' . $L_ixi);
        goto hmGJy;
        qY518:
        $L_ixi = $this->uiTOc->put($qGbOo, $zCabx->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto gu2og;
        zUml7:
        $this->dwubH->put($LS13w->filename, $rk2Va);
        goto d_UMn;
        pwuWS:
        ini_set('memory_limit', '-1');
        goto e1ujX;
        d_UMn:
        hIX0f:
        goto oVbb8;
        nL_c3:
        $LS13w = XMeo8SOmME8kj::findOrFail($B_L9m);
        goto pwuWS;
        wJG2K:
        $qGbOo = $this->myWULYwVwzq($LS13w);
        goto qY518;
        gu2og:
        unset($zCabx);
        goto Tao02;
        Tao02:
        if (chmod($L_ixi, 0664)) {
            goto AqVhx;
        }
        goto CzCOu;
        hmGJy:
        throw new \Exception('Failed to set final permissions on image file: ' . $L_ixi);
        goto ePfKY;
        iXTPS:
    }
    private function myWULYwVwzq($RvlqW) : string
    {
        goto eoB7T;
        eoB7T:
        $dTJxl = $RvlqW->getLocation();
        goto z7pw0;
        z7pw0:
        $WeJv6 = dirname($dTJxl) . '/preview/';
        goto NP1UY;
        oFVsw:
        $this->dwubH->makeDirectory($WeJv6, 0755, true);
        goto DIZaz;
        PXWGG:
        return $WeJv6 . $RvlqW->getFilename() . '.jpg';
        goto rOpvu;
        DIZaz:
        jdALz:
        goto PXWGG;
        NP1UY:
        if ($this->dwubH->exists($WeJv6)) {
            goto jdALz;
        }
        goto oFVsw;
        rOpvu:
    }
}
