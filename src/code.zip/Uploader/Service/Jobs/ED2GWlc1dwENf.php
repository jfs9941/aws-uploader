<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Encoder\SlQNgBAeh4N74;
use Jfs\Uploader\Encoder\IpF68nxcXPUAb;
use Jfs\Uploader\Encoder\WKWBYhZhEWOea;
use Jfs\Uploader\Encoder\FkO0riWkK3iiD;
use Jfs\Uploader\Encoder\Na4nP4czgqeSL;
use Jfs\Uploader\Encoder\HixSphBFBsnT0;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
use Jfs\Uploader\Service\SqWT6oYd97hAj;
use Webmozart\Assert\Assert;
class ED2GWlc1dwENf implements MediaEncodeJobInterface
{
    private $DK2hf;
    private $VFHFZ;
    private $dhrkT;
    private $q3KfI;
    private $i0IXb;
    public function __construct(string $TyFPC, $dOL2I, $v8n0s, $xsFIZ, $tJOVN)
    {
        goto ICd1K;
        ICd1K:
        $this->DK2hf = $TyFPC;
        goto jsB1p;
        wdpyr:
        $this->dhrkT = $v8n0s;
        goto L0z5j;
        L0z5j:
        $this->q3KfI = $xsFIZ;
        goto jLQ53;
        jLQ53:
        $this->i0IXb = $tJOVN;
        goto b83X1;
        jsB1p:
        $this->VFHFZ = $dOL2I;
        goto wdpyr;
        b83X1:
    }
    public function encode(string $cQqZd, string $mLgze, $zDA3Z = true) : void
    {
        goto hBGBz;
        S1FkR:
        try {
            goto DyKam;
            ZmQNN:
            $uXKnP->mz0T9B17Mut($AYeeJ);
            goto JTkyK;
            Lfc7b:
            $XORlr = $this->mdZY5wb2PQi($jgYSY, $TPtwR->mZn9oNgFPjz($WKps1->width(), $WKps1->height(), $mLgze));
            goto xzRTx;
            sL1fV:
            if (!($WKps1->ymE9n !== FW54oEnFetVYj::S3)) {
                goto mFbRJ;
            }
            goto Vhs0S;
            w0FT3:
            XeG0A:
            goto UD3Fw;
            qcLz7:
            Log::info("Set thumbnail for G4MP13yRAmltw Job", ['videoId' => $WKps1->getAttribute('id'), 'duration' => $WKps1->getAttribute('duration')]);
            goto EDqX9;
            USMfL:
            $WKps1->update(['aws_media_converter_job_id' => $cQqZd]);
            goto RoWxb;
            JDwu0:
            $Ly58A = $this->m8Aqsnw7CFO($X22ix, $LrYxj);
            goto Syxvr;
            Uulo7:
            mFbRJ:
            goto wi3FR;
            S7czU:
            n7UFj:
            goto PcD7g;
            Vhs0S:
            throw new MediaConverterException("G4MP13yRAmltw {$WKps1->id} is not S3 driver");
            goto Uulo7;
            eZF2l:
            $uXKnP = $uXKnP->mz0T9B17Mut($ia1S5);
            goto w0FT3;
            O4fH3:
            $XORlr = $this->mdZY5wb2PQi($jgYSY, $TPtwR->mZn9oNgFPjz((int) $Ly58A['width'], (int) $Ly58A['height'], $mLgze));
            goto HrPpr;
            UD3Fw:
            mmwv2:
            goto qcLz7;
            DpxQX:
            $uXKnP = $uXKnP->m2jNAxhQ2h6($DU5Lh);
            goto kmwjP;
            UoguS:
            $uXKnP = $uXKnP->mCEPq8cBaoV(new FkO0riWkK3iiD($TQbhc));
            goto Z5djE;
            be3D0:
            $uXKnP->mdXrOSrC95W($wFRhK->mfwMNRrlKMs($WKps1));
            goto ArFeM;
            Ut7Fg:
            Log::info("Set input video for Job", ['s3Uri' => $TQbhc]);
            goto EGtFY;
            PcD7g:
            $uXKnP->mz0T9B17Mut($AYeeJ);
            goto be3D0;
            HrPpr:
            if (!$XORlr) {
                goto Tr2y8;
            }
            goto qtex7;
            mBVX6:
            if (!$this->me3rI4pthi3($X22ix, $LrYxj)) {
                goto XeG0A;
            }
            goto JDwu0;
            lad4Y:
            $AYeeJ = $AYeeJ->mndqAm9sbqh($XORlr);
            goto S7czU;
            K0PRE:
            $jgYSY = app(SqWT6oYd97hAj::class);
            goto NiShm;
            JTkyK:
            $uXKnP->mdXrOSrC95W($wFRhK->mfwMNRrlKMs($WKps1));
            goto K0PRE;
            fVoEU:
            Tr2y8:
            goto eZF2l;
            qtex7:
            $ia1S5 = $ia1S5->mndqAm9sbqh($XORlr);
            goto fVoEU;
            ctTMl:
            $ia1S5 = new IpF68nxcXPUAb('1080p', $Ly58A['width'], $Ly58A['height'], $WKps1->uQdPz ?? 30);
            goto O4fH3;
            DyKam:
            $WKps1 = G4MP13yRAmltw::findOrFail($cQqZd);
            goto Nq2S6;
            Nq2S6:
            Assert::isInstanceOf($WKps1, G4MP13yRAmltw::class);
            goto sL1fV;
            NiShm:
            $TPtwR = new JLhS5pGupvbSs($this->q3KfI, $this->i0IXb, $this->dhrkT, $this->VFHFZ);
            goto Lfc7b;
            acqSQ:
            $wFRhK = app(WKWBYhZhEWOea::class);
            goto ZmQNN;
            kmwjP:
            $cQqZd = $uXKnP->m75n56qlfHB($this->m7G3DffDTVU($WKps1, $zDA3Z));
            goto USMfL;
            EGtFY:
            $uXKnP = app(Na4nP4czgqeSL::class);
            goto UoguS;
            xzRTx:
            if (!$XORlr) {
                goto n7UFj;
            }
            goto lad4Y;
            wi3FR:
            $X22ix = $WKps1->width();
            goto UWvIH;
            Z5djE:
            $AYeeJ = new IpF68nxcXPUAb('original', $X22ix, $LrYxj, $WKps1->uQdPz ?? 30);
            goto acqSQ;
            EDqX9:
            $DU5Lh = new SlQNgBAeh4N74($WKps1->A30_9 ?? 1, 2, $wFRhK->mNysMat2axz($WKps1));
            goto DpxQX;
            UWvIH:
            $LrYxj = $WKps1->height();
            goto dgA5O;
            ArFeM:
            if (!($X22ix && $LrYxj)) {
                goto mmwv2;
            }
            goto mBVX6;
            Syxvr:
            Log::info("Set 1080p resolution for Job", ['width' => $Ly58A['width'], 'height' => $Ly58A['height'], 'originalWidth' => $X22ix, 'originalHeight' => $LrYxj]);
            goto ctTMl;
            dgA5O:
            $TQbhc = $this->m6CfpYIk1n5($WKps1);
            goto Ut7Fg;
            RoWxb:
        } catch (\Exception $mz5ks) {
            Log::info("G4MP13yRAmltw has been deleted, discard it", ['fileId' => $cQqZd, 'err' => $mz5ks->getMessage()]);
            return;
        }
        goto ADGjJ;
        hBGBz:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $cQqZd]);
        goto g75eU;
        g75eU:
        ini_set('memory_limit', '-1');
        goto S1FkR;
        ADGjJ:
    }
    private function m7G3DffDTVU(G4MP13yRAmltw $WKps1, $zDA3Z) : bool
    {
        goto nOWYv;
        tTXDB:
        Roxwp:
        goto ZZPXQ;
        zFSmG:
        $enHz_ = (int) round($WKps1->getAttribute('duration') ?? 0);
        goto y9nrS;
        y9nrS:
        switch (true) {
            case $WKps1->width() * $WKps1->height() >= 1920 * 1080 && $WKps1->width() * $WKps1->height() < 2560 * 1440:
                return $enHz_ > 10 * 60;
            case $WKps1->width() * $WKps1->height() >= 2560 * 1440 && $WKps1->width() * $WKps1->height() < 3840 * 2160:
                return $enHz_ > 5 * 60;
            case $WKps1->width() * $WKps1->height() >= 3840 * 2160:
                return $enHz_ > 3 * 60;
            default:
                return false;
        }
        goto tTXDB;
        MknCL:
        W0G0O:
        goto zFSmG;
        ZZPXQ:
        Nenen:
        goto I7udU;
        nOWYv:
        if ($zDA3Z) {
            goto W0G0O;
        }
        goto amOXg;
        amOXg:
        return false;
        goto MknCL;
        I7udU:
    }
    private function mdZY5wb2PQi(SqWT6oYd97hAj $jgYSY, string $CSzte) : ?HixSphBFBsnT0
    {
        goto HC2rU;
        fNY8x:
        w98sH:
        goto ipkNp;
        HC2rU:
        $frqkY = $jgYSY->m18T4KMvq19($CSzte);
        goto C9rvF;
        ZDCWi:
        return new HixSphBFBsnT0($frqkY, 0, 0, null, null);
        goto fNY8x;
        C9rvF:
        Log::info("Resolve watermark for job with url", ['url' => $CSzte, 'uri' => $frqkY]);
        goto us_Jg;
        ipkNp:
        return null;
        goto YOwgA;
        us_Jg:
        if (!$frqkY) {
            goto w98sH;
        }
        goto ZDCWi;
        YOwgA:
    }
    private function me3rI4pthi3(int $X22ix, int $LrYxj) : bool
    {
        return $X22ix * $LrYxj > 1.5 * (1920 * 1080);
    }
    private function m8Aqsnw7CFO(int $X22ix, int $LrYxj) : array
    {
        $R3aZ3 = new UJLCuJqSGyuIr($X22ix, $LrYxj);
        return $R3aZ3->mmq9LFOiNJM();
    }
    private function m6CfpYIk1n5(ZujQPL2bQTbeI $Rcq7S) : string
    {
        goto XlRQu;
        gogkA:
        return 's3://' . $this->DK2hf . '/' . $Rcq7S->filename;
        goto S1G0t;
        S1G0t:
        yEAQE:
        goto MoIt_;
        MoIt_:
        return $this->VFHFZ->url($Rcq7S->filename);
        goto hDX32;
        XlRQu:
        if (!($Rcq7S->ymE9n == FW54oEnFetVYj::S3)) {
            goto yEAQE;
        }
        goto gogkA;
        hDX32:
    }
}
