<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\JyZaxpharsbun;
class G3vPIVUoMhuCv implements CompressJobInterface
{
    const hx6zO = 80;
    private $IfECA;
    private $uBhrQ;
    public function __construct($AaIEl, $Ms6sq)
    {
        $this->IfECA = $AaIEl;
        $this->uBhrQ = $Ms6sq;
    }
    public function compress(string $S6xyJ)
    {
        goto Yh9D5;
        x_RwF:
        try {
            goto UwEbo;
            SUbds:
            $pK6GK = $this->uBhrQ->path($iy9bs->getLocation());
            goto fbJko;
            YHBda:
            $WhAgX->save($hVnqO, self::hx6zO);
            goto iME3h;
            fgDvJ:
            $iy9bs->save();
            goto ODgmm;
            UwEbo:
            $iy9bs = JyZaxpharsbun::findOrFail($S6xyJ);
            goto SUbds;
            i38sF:
            $hVnqO = $this->uBhrQ->path($iy9bs->getLocation());
            goto jh2dS;
            iME3h:
            $WhAgX->destroy();
            goto tYy87;
            eVZmy:
            $iy9bs->setAttribute('filename', str_replace('.png', '.jpg', $iy9bs->getLocation()));
            goto fgDvJ;
            ODgmm:
            g4nEN:
            goto i38sF;
            jh2dS:
            $WhAgX = $this->IfECA->call($this, $pK6GK);
            goto r63Rq;
            RbD4y:
            $iy9bs->setAttribute('type', 'jpg');
            goto eVZmy;
            fbJko:
            if (!($iy9bs->getExtension() === 'png')) {
                goto g4nEN;
            }
            goto RbD4y;
            r63Rq:
            $WhAgX->orientate();
            goto YHBda;
            tYy87:
        } catch (ModelNotFoundException) {
            Log::info("JyZaxpharsbun has been deleted, discard it", ['imageId' => $S6xyJ]);
        } finally {
            $Mzhg0 = microtime(true);
            $xdlh4 = memory_get_usage();
            $OC5ML = memory_get_peak_usage();
            Log::info('HCrMjr1ZIoi6r function resource usage', ['imageId' => $S6xyJ, 'execution_time_sec' => $Mzhg0 - $piVF4, 'memory_usage_bytes' => $xdlh4 - $JMKzk, 'peak_memory_usage_bytes' => $OC5ML - $V2At5]);
        }
        goto b0wQa;
        qVWuV:
        Log::info("Compress image", ['imageId' => $S6xyJ]);
        goto x_RwF;
        Yh9D5:
        $piVF4 = microtime(true);
        goto zK5dJ;
        OrcaN:
        $V2At5 = memory_get_peak_usage();
        goto qVWuV;
        zK5dJ:
        $JMKzk = memory_get_usage();
        goto OrcaN;
        b0wQa:
    }
}
