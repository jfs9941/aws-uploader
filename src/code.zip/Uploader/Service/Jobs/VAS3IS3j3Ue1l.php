<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class VAS3IS3j3Ue1l
{
    private $Rq1Bv;
    private $SdSwZ;
    public function __construct(int $UoTN0, int $yNwY7)
    {
        goto qmBgY;
        Dsre4:
        $this->Rq1Bv = $UoTN0;
        goto pSVYk;
        cXIG4:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto T38n3;
        qmBgY:
        if (!($UoTN0 <= 0)) {
            goto Xk3Jg;
        }
        goto gA3la;
        pSVYk:
        $this->SdSwZ = $yNwY7;
        goto kzOp4;
        gA3la:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto qXW9z;
        T38n3:
        CjCY8:
        goto Dsre4;
        nRqHp:
        if (!($yNwY7 <= 0)) {
            goto CjCY8;
        }
        goto cXIG4;
        qXW9z:
        Xk3Jg:
        goto nRqHp;
        kzOp4:
    }
    private static function mGgLLbnB3pv($pLYjn, string $iNJxu = 'floor') : int
    {
        goto zykww;
        pLFcE:
        wfqHk:
        goto NySL2;
        Lrzxs:
        switch (strtolower($iNJxu)) {
            case 'ceil':
                return (int) (ceil($pLYjn / 2) * 2);
            case 'round':
                return (int) (round($pLYjn / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($pLYjn / 2) * 2);
        }
        goto wy07u;
        zykww:
        if (!(is_int($pLYjn) && $pLYjn % 2 === 0)) {
            goto wfqHk;
        }
        goto aV6NO;
        ZlcrT:
        return (int) $pLYjn;
        goto RUXfK;
        RUXfK:
        esxJf:
        goto Lrzxs;
        wy07u:
        Td5DT:
        goto cnCxy;
        cnCxy:
        vg_OI:
        goto xYunP;
        aV6NO:
        return $pLYjn;
        goto pLFcE;
        NySL2:
        if (!(is_float($pLYjn) && $pLYjn == floor($pLYjn) && (int) $pLYjn % 2 === 0)) {
            goto esxJf;
        }
        goto ZlcrT;
        xYunP:
    }
    public function mkTTqwPM1yd(string $CxTOU = 'floor') : array
    {
        goto XpFtM;
        aEtb_:
        $sR9PF = 2;
        goto ymoBh;
        mKQEw:
        EihI0:
        goto IJmeF;
        mM21i:
        goto AQDOf;
        goto mKQEw;
        MfVUo:
        AQDOf:
        goto pF7f3;
        oBSLf:
        $UMQ0U = $this->Rq1Bv * $fTF8K;
        goto j3nJe;
        XcT_V:
        $sR9PF = self::mGgLLbnB3pv(round($yuttJ), $CxTOU);
        goto mM21i;
        AbN1v:
        return ['width' => $gpIJg, 'height' => $sR9PF];
        goto jdsEc;
        pSTLb:
        if (!($sR9PF < 2)) {
            goto VFKWC;
        }
        goto aEtb_;
        j3nJe:
        $gpIJg = self::mGgLLbnB3pv(round($UMQ0U), $CxTOU);
        goto MfVUo;
        jRBwR:
        $fTF8K = $gpIJg / $this->Rq1Bv;
        goto QuuDq;
        PkOx2:
        if ($this->Rq1Bv >= $this->SdSwZ) {
            goto EihI0;
        }
        goto DBbzI;
        IJmeF:
        $sR9PF = $pRumG;
        goto bWVDx;
        pF7f3:
        if (!($gpIJg < 2)) {
            goto ZOkv7;
        }
        goto gWlbq;
        QuuDq:
        $yuttJ = $this->SdSwZ * $fTF8K;
        goto XcT_V;
        u0lqb:
        ZOkv7:
        goto pSTLb;
        ymoBh:
        VFKWC:
        goto AbN1v;
        CPvic:
        $gpIJg = 0;
        goto Qrrgz;
        Qrrgz:
        $sR9PF = 0;
        goto PkOx2;
        XpFtM:
        $pRumG = 1080;
        goto CPvic;
        gWlbq:
        $gpIJg = 2;
        goto u0lqb;
        bWVDx:
        $fTF8K = $sR9PF / $this->SdSwZ;
        goto oBSLf;
        DBbzI:
        $gpIJg = $pRumG;
        goto jRBwR;
        jdsEc:
    }
}
