<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

class VWi8iyX8y8IKN
{
    private $m12Fs;
    private $s1Ojb;
    private $qrvF0;
    private $fodJQ;
    public function __construct($a3Ry3, $yb5JT, $eG_Pc, $nsgrL)
    {
        goto LYuUg;
        LYuUg:
        $this->s1Ojb = $yb5JT;
        goto m04DV;
        KRd24:
        $this->fodJQ = $nsgrL;
        goto J0NqO;
        J0NqO:
        $this->m12Fs = $a3Ry3;
        goto ivIM2;
        m04DV:
        $this->qrvF0 = $eG_Pc;
        goto KRd24;
        ivIM2:
    }
    public function m3R2wWWZe8v(?int $g5xFk, ?int $zZl79, string $MjBIh, bool $r6QxQ = false) : string
    {
        goto LHO0w;
        B2PB7:
        list($zQ4c3, $GDGcU, $Y1nW8) = $this->mHSgM7lxeNb($MjBIh, $g5xFk, $PMD92, (float) $g5xFk / $zZl79);
        goto AJToi;
        mERxs:
        return $r6QxQ ? $lmCO9 : $this->qrvF0->url($lmCO9);
        goto sRreW;
        r8yzk:
        throw new \RuntimeException("UMeQT1ArE1U05 dimensions are not available.");
        goto MRkJd;
        G8m05:
        $anrPh = $this->m12Fs->call($this, $g5xFk, $zZl79);
        goto Y7hpU;
        LHO0w:
        if (!($g5xFk === null || $zZl79 === null)) {
            goto nr_x1;
        }
        goto r8yzk;
        sRreW:
        l_HKM:
        goto G8m05;
        Xm7zz:
        Q1Des:
        goto p4RbC;
        AJToi:
        $lmCO9 = $this->mvwTZhVExVX($Y1nW8, $g5xFk, $zZl79, $GDGcU, $zQ4c3);
        goto seoy9;
        Yczxx:
        return $r6QxQ ? $lmCO9 : $this->qrvF0->url($lmCO9);
        goto PNQYY;
        kq9z2:
        $u9ilD -= $gNEFd;
        goto sD7A4;
        X9CK2:
        $anrPh->text($Y1nW8, $u9ilD, (int) $OzaY2, function ($s31gF) use($zQ4c3) {
            goto KWF2M;
            WrNZ7:
            $s31gF->size(max($Bv7nc, 1));
            goto y4YAe;
            ankU2:
            $s31gF->valign('middle');
            goto a1wvz;
            h2Ziy:
            $Bv7nc = (int) ($zQ4c3 * 1.2);
            goto WrNZ7;
            y4YAe:
            $s31gF->color([185, 185, 185, 1]);
            goto ankU2;
            KWF2M:
            $s31gF->file(HJEbJ($this->s1Ojb));
            goto h2Ziy;
            a1wvz:
            $s31gF->align('middle');
            goto jDj0A;
            jDj0A:
        });
        goto YP0La;
        zFpe2:
        $u9ilD -= $gNEFd * 0.4;
        goto Xm7zz;
        p4RbC:
        $OzaY2 = $zZl79 - $zQ4c3 - 10;
        goto X9CK2;
        YP0La:
        $this->fodJQ->put($lmCO9, $anrPh->stream('png'));
        goto Ckyjh;
        seoy9:
        if (!$this->qrvF0->exists($lmCO9)) {
            goto l_HKM;
        }
        goto mERxs;
        Y7hpU:
        $u9ilD = $g5xFk - $GDGcU;
        goto Vf5gW;
        sD7A4:
        if (!($g5xFk > 1500)) {
            goto Q1Des;
        }
        goto zFpe2;
        MRkJd:
        nr_x1:
        goto tXf3M;
        Vf5gW:
        $gNEFd = (int) ($u9ilD / 80);
        goto kq9z2;
        Ckyjh:
        $this->qrvF0->put($lmCO9, $anrPh->stream('png'));
        goto Yczxx;
        tXf3M:
        $PMD92 = 0.1;
        goto B2PB7;
        PNQYY:
    }
    private function mvwTZhVExVX(string $MjBIh, int $g5xFk, int $zZl79, int $eAYgA, int $M9Htm) : string
    {
        $kEiQM = ltrim($MjBIh, '@');
        return "v2/watermark/{$kEiQM}/{$g5xFk}x{$zZl79}_{$eAYgA}x{$M9Htm}/text_watermark.png";
    }
    private function mHSgM7lxeNb($MjBIh, int $g5xFk, float $XyUyf, float $WTiec) : array
    {
        goto tA5_0;
        tA5_0:
        $Y1nW8 = '@' . $MjBIh;
        goto ctTmB;
        aj9no:
        return [(int) $URMO4, $GDGcU, $Y1nW8];
        goto Py6Vw;
        UVTZa:
        $URMO4 = 1 / $WTiec * $GDGcU / strlen($Y1nW8);
        goto aj9no;
        ctTmB:
        $GDGcU = (int) ($g5xFk * $XyUyf);
        goto yBB93;
        BAddP:
        td4HI:
        goto UVTZa;
        yBB93:
        if (!($WTiec > 1)) {
            goto td4HI;
        }
        goto BJN0M;
        BJN0M:
        $URMO4 = $GDGcU / (strlen($Y1nW8) * 0.8);
        goto JBUof;
        JBUof:
        return [(int) $URMO4, $URMO4 * strlen($Y1nW8) / 1.8, $Y1nW8];
        goto BAddP;
        Py6Vw:
    }
}
