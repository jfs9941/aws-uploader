<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
class EnHldbJrvjtuo implements BlurJobInterface
{
    const RwPcJ = 15;
    const vdsNB = 500;
    const cNKXz = 500;
    private $KbvBQ;
    private $RaPnW;
    private $FFBPk;
    public function __construct($twxgF, $hTkyv, $GHkBm)
    {
        goto dGo9C;
        dGo9C:
        $this->FFBPk = $GHkBm;
        goto AAens;
        GJwLS:
        $this->KbvBQ = $twxgF;
        goto LKy04;
        AAens:
        $this->RaPnW = $hTkyv;
        goto GJwLS;
        LKy04:
    }
    public function blur(string $UcmDx) : void
    {
        goto Y75L6;
        LbPws:
        $this->FFBPk->put($LW_ZO->filename, $SvtT7);
        goto Hbx6U;
        etE_0:
        $Ph2Eb = $this->m6HH5P3T3sI($LW_ZO);
        goto KeuuF;
        Z0HkJ:
        $IS6o1->resize(self::vdsNB, self::cNKXz / $aVX8K);
        goto g8C1R;
        IjLdK:
        $LW_ZO->update(['preview' => $Ph2Eb]);
        goto bmjL2;
        Yi9ZU:
        throw new \Exception('Failed to set final permissions on image file: ' . $WQYnm);
        goto Ur_hW;
        ujZeX:
        $SvtT7 = $this->RaPnW->get($LW_ZO->filename);
        goto LbPws;
        yUi96:
        ini_set('memory_limit', '-1');
        goto trQZG;
        tOerl:
        $IS6o1 = $this->KbvBQ->call($this, $this->FFBPk->path($LW_ZO->getLocation()));
        goto FyKBo;
        Nnhpb:
        $IS6o1->destroy();
        goto K0uVE;
        Ql1VP:
        \Log::warning('Failed to set final permissions on image file: ' . $WQYnm);
        goto Yi9ZU;
        FyKBo:
        $aVX8K = $IS6o1->width() / $IS6o1->height();
        goto Z0HkJ;
        Ur_hW:
        Yv9j1:
        goto IjLdK;
        Hbx6U:
        m3Rgg:
        goto tOerl;
        K0uVE:
        if (chmod($WQYnm, 0664)) {
            goto Yv9j1;
        }
        goto Ql1VP;
        L3hZU:
        $IS6o1->save($WQYnm);
        goto Nnhpb;
        trQZG:
        if (!($LW_ZO->H9HlK == KPpxBU3Qc8yRk::S3 && !$this->FFBPk->exists($LW_ZO->filename))) {
            goto m3Rgg;
        }
        goto ujZeX;
        Y75L6:
        $LW_ZO = HSe6BNUpJTSwE::findOrFail($UcmDx);
        goto yUi96;
        KeuuF:
        $WQYnm = $this->FFBPk->path($Ph2Eb);
        goto L3hZU;
        g8C1R:
        $IS6o1->blur(self::RwPcJ);
        goto etE_0;
        bmjL2:
    }
    private function m6HH5P3T3sI($aoAFq) : string
    {
        goto tjh54;
        rAOHD:
        $cKRb7 = dirname($eviRR) . '/preview/';
        goto IrMhN;
        tjh54:
        $eviRR = $aoAFq->getLocation();
        goto rAOHD;
        TtQBG:
        return $cKRb7 . $aoAFq->getFilename() . '.jpg';
        goto iQn7m;
        uXf61:
        $this->FFBPk->makeDirectory($cKRb7, 0755, true);
        goto Fby4m;
        Fby4m:
        A3FOj:
        goto TtQBG;
        IrMhN:
        if ($this->FFBPk->exists($cKRb7)) {
            goto A3FOj;
        }
        goto uXf61;
        iQn7m:
    }
}
