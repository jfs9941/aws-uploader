<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
class DdBdaWRDt30CD implements StoreVideoToS3JobInterface
{
    private $P2TpI;
    private $auR_S;
    private $P6k4O;
    public function __construct($qir1P, $JhAxH, $RNTis)
    {
        goto OXCWz;
        hSurT:
        $this->P2TpI = $qir1P;
        goto znOPg;
        OXCWz:
        $this->auR_S = $JhAxH;
        goto f1i4K;
        f1i4K:
        $this->P6k4O = $RNTis;
        goto hSurT;
        znOPg:
    }
    public function store(string $IaHim) : void
    {
        goto NLQ41;
        O0n89:
        if ($wFGVG) {
            goto Gz9qx;
        }
        goto L7d9M;
        OAc1H:
        UdNDL:
        goto TP7cM;
        WXrgw:
        ini_set('memory_limit', '-1');
        goto QNkh7;
        y__G4:
        Gz9qx:
        goto n8ry9;
        n8ry9:
        if ($RNTis->exists($wFGVG->getLocation())) {
            goto UdNDL;
        }
        goto dT3P8;
        lEsAE:
        $RNTis = $this->P6k4O;
        goto V8IeT;
        QNkh7:
        $fHhL2 = $this->auR_S->getClient();
        goto lEsAE;
        UNr2l:
        return;
        goto OAc1H;
        TP7cM:
        $s4zeg = $RNTis->readStream($wFGVG->getLocation());
        goto RvZCi;
        NLQ41:
        Log::info('Storing video (local) to S3', ['fileId' => $IaHim, 'bucketName' => $this->P2TpI]);
        goto WXrgw;
        RvZCi:
        $NM6rj = 1024 * 1024 * 50;
        goto tpPeP;
        dT3P8:
        Log::error("[DdBdaWRDt30CD] File not found, discard it ", ['video' => $wFGVG->getLocation()]);
        goto UNr2l;
        L7d9M:
        Log::info("ACdpgX4YCYP6M has been deleted, discard it", ['fileId' => $IaHim]);
        goto qzO_o;
        V8IeT:
        $wFGVG = ACdpgX4YCYP6M::find($IaHim);
        goto O0n89;
        qzO_o:
        return;
        goto y__G4;
        XcKER:
        try {
            goto qPaqq;
            sX1XC:
            $MF1dT = [];
            goto Rl5fb;
            rbwVT:
            goto B8oKy;
            goto eRXAl;
            TlIC6:
            $MF1dT[] = ['PartNumber' => $u2yxy, 'ETag' => $XJl0K['ETag']];
            goto wM3q7;
            Q3QCD:
            $Kps2Q = $rvOSs['UploadId'];
            goto Yo5Iv;
            qPaqq:
            $rvOSs = $fHhL2->createMultipartUpload(['Bucket' => $this->P2TpI, 'Key' => $wFGVG->getLocation(), 'ContentType' => $CwXhg, 'ContentDisposition' => 'inline']);
            goto Q3QCD;
            Yo5Iv:
            $u2yxy = 1;
            goto sX1XC;
            eRXAl:
            mzvaG:
            goto ZZoUd;
            v2jlV:
            $XJl0K = $fHhL2->uploadPart(['Bucket' => $this->P2TpI, 'Key' => $wFGVG->getLocation(), 'UploadId' => $Kps2Q, 'PartNumber' => $u2yxy, 'Body' => fread($s4zeg, $NM6rj)]);
            goto TlIC6;
            gK3GB:
            $fHhL2->completeMultipartUpload(['Bucket' => $this->P2TpI, 'Key' => $wFGVG->getLocation(), 'UploadId' => $Kps2Q, 'MultipartUpload' => ['Parts' => $MF1dT]]);
            goto zozpI;
            wM3q7:
            $u2yxy++;
            goto rbwVT;
            Rl5fb:
            B8oKy:
            goto UQOXI;
            TS_cv:
            $RNTis->delete($wFGVG->getLocation());
            goto ciX8L;
            ZZoUd:
            fclose($s4zeg);
            goto gK3GB;
            zozpI:
            $wFGVG->update(['driver' => FUIPeZ7ssitYw::S3, 'status' => QoCMzcKvH8Cw2::FINISHED]);
            goto TS_cv;
            UQOXI:
            if (feof($s4zeg)) {
                goto mzvaG;
            }
            goto v2jlV;
            ciX8L:
        } catch (AwsException $aa8DU) {
            goto e9rTO;
            NYFNp:
            Log::error('Failed to store video: ' . $wFGVG->getLocation() . ' - ' . $aa8DU->getMessage());
            goto E1rkH;
            e9rTO:
            if (!isset($Kps2Q)) {
                goto h6ID8;
            }
            goto aiR83;
            YyW3T:
            h6ID8:
            goto NYFNp;
            aiR83:
            try {
                $fHhL2->abortMultipartUpload(['Bucket' => $this->P2TpI, 'Key' => $wFGVG->getLocation(), 'UploadId' => $Kps2Q]);
            } catch (AwsException $RwmaD) {
                Log::error('Error aborting multipart upload: ' . $RwmaD->getMessage());
            }
            goto YyW3T;
            E1rkH:
        }
        goto ZkgJx;
        tpPeP:
        $CwXhg = $RNTis->mimeType($wFGVG->getLocation());
        goto XcKER;
        ZkgJx:
    }
}
