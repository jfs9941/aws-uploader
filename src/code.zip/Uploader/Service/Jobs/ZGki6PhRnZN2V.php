<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
class ZGki6PhRnZN2V implements BlurJobInterface
{
    const pcl6K = 15;
    const rl6ku = 500;
    const gi9mL = 500;
    private $awXpN;
    private $tcoQz;
    private $AwDbR;
    public function __construct($ek1iS, $v70jj, $uwOBm)
    {
        goto FkNTt;
        Pn0YV:
        $this->awXpN = $ek1iS;
        goto Vv4X1;
        FkNTt:
        $this->AwDbR = $uwOBm;
        goto pvy07;
        pvy07:
        $this->tcoQz = $v70jj;
        goto Pn0YV;
        Vv4X1:
    }
    public function blur(string $B5uQ4) : void
    {
        goto a9vC2;
        a9vC2:
        $XTF2w = U0IzvN2kaLZHI::findOrFail($B5uQ4);
        goto cA2Ea;
        nkGcW:
        $XTF2w->update(['preview' => $I4v2U]);
        goto uJLNM;
        nydZi:
        $jYl_6->blur(self::pcl6K);
        goto AYmOY;
        L5g1W:
        $UufE6 = $this->tcoQz->get($XTF2w->filename);
        goto VhBK8;
        mxcxc:
        $TZSdr = $jYl_6->width() / $jYl_6->height();
        goto pMbfa;
        pMbfa:
        $jYl_6->resize(self::rl6ku, self::gi9mL / $TZSdr);
        goto nydZi;
        ll3fD:
        if (chmod($vf0_W, 0664)) {
            goto mGv4G;
        }
        goto GzV0Z;
        KDW_v:
        mGv4G:
        goto nkGcW;
        cA2Ea:
        ini_set('memory_limit', '-1');
        goto JHEt5;
        mHUQA:
        $jYl_6 = $this->awXpN->call($this, $this->AwDbR->path($XTF2w->getLocation()));
        goto mxcxc;
        v0naI:
        unset($jYl_6);
        goto ll3fD;
        AYmOY:
        $I4v2U = $this->mv6VKtsmUGA($XTF2w);
        goto g5wG8;
        GzV0Z:
        \Log::warning('Failed to set final permissions on image file: ' . $vf0_W);
        goto XdVcN;
        VhBK8:
        $this->AwDbR->put($XTF2w->filename, $UufE6);
        goto OoueJ;
        g5wG8:
        $vf0_W = $this->tcoQz->put($I4v2U, $jYl_6->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto v0naI;
        XdVcN:
        throw new \Exception('Failed to set final permissions on image file: ' . $vf0_W);
        goto KDW_v;
        JHEt5:
        if (!($XTF2w->tcavr == LrHrisEWQ9E5o::S3 && !$this->AwDbR->exists($XTF2w->filename))) {
            goto R8Wkx;
        }
        goto L5g1W;
        OoueJ:
        R8Wkx:
        goto mHUQA;
        uJLNM:
    }
    private function mv6VKtsmUGA($nuWgw) : string
    {
        goto GZ08A;
        r5pZr:
        $pVfz3 = dirname($uUtRl) . '/preview/';
        goto GeHpO;
        S5_jW:
        $this->AwDbR->makeDirectory($pVfz3, 0755, true);
        goto y_rYU;
        y_rYU:
        fXRFL:
        goto i__WE;
        i__WE:
        return $pVfz3 . $nuWgw->getFilename() . '.jpg';
        goto K8Vmv;
        GZ08A:
        $uUtRl = $nuWgw->getLocation();
        goto r5pZr;
        GeHpO:
        if ($this->AwDbR->exists($pVfz3)) {
            goto fXRFL;
        }
        goto S5_jW;
        K8Vmv:
    }
}
