<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class R40XH3H6TVben
{
    private $QFCsF;
    private $G2Xe3;
    private $K79lK;
    private $x0wV5;
    public function __construct($OPDJh, $lCUIp, $yEBaZ, $mHTSY)
    {
        goto aBxYQ;
        hJX2r:
        $this->K79lK = $yEBaZ;
        goto cLqXX;
        CXmDt:
        $this->QFCsF = $OPDJh;
        goto dugJ_;
        cLqXX:
        $this->x0wV5 = $mHTSY;
        goto CXmDt;
        aBxYQ:
        $this->G2Xe3 = $lCUIp;
        goto hJX2r;
        dugJ_:
    }
    public function m2IlDRXB6cD(?int $qFAp6, ?int $bxUTl, string $S9w3S, bool $pb2nG = false) : string
    {
        goto Gh5QU;
        BbAZ0:
        $TnwL2 = $this->mmmxFibQ50O($VFqTL, $qFAp6, $bxUTl, $Xx_ZL, $EhATr);
        goto jowN8;
        PmoHV:
        return $pb2nG ? $TnwL2 : $this->K79lK->url($TnwL2);
        goto cAFw0;
        bPj7n:
        list($EhATr, $Xx_ZL, $VFqTL) = $this->mC6jKKGJtwW($S9w3S, $qFAp6, $CbOav, (float) $qFAp6 / $bxUTl);
        goto BbAZ0;
        HV5j9:
        throw new \RuntimeException("SmhkgG6le5p0r dimensions are not available.");
        goto NWUSB;
        Toevq:
        $tCZeH = $qFAp6 - $Xx_ZL;
        goto JnhSR;
        UqL8k:
        $tCZeH -= $rZyCr * 0.4;
        goto g656t;
        n6cTa:
        $this->x0wV5->put($TnwL2, $fe3pc->stream('png'));
        goto PgSSg;
        iGxCb:
        if (!($qFAp6 > 1500)) {
            goto ek5x2;
        }
        goto UqL8k;
        PgSSg:
        $this->K79lK->put($TnwL2, $fe3pc->stream('png'));
        goto PmoHV;
        NWUSB:
        ZBehF:
        goto uABS5;
        uABS5:
        $CbOav = 0.1;
        goto bPj7n;
        Gh5QU:
        if (!($qFAp6 === null || $bxUTl === null)) {
            goto ZBehF;
        }
        goto HV5j9;
        lLSDU:
        $tCZeH -= $rZyCr;
        goto iGxCb;
        AZA4R:
        GVaXj:
        goto ZLtO9;
        g656t:
        ek5x2:
        goto lqhj4;
        K9bJk:
        $fe3pc->text($VFqTL, $tCZeH, (int) $E0voK, function ($GEb0i) use($EhATr) {
            goto ecRri;
            POYkH:
            $GEb0i->valign('middle');
            goto l3qE1;
            l3qE1:
            $GEb0i->align('middle');
            goto Y0jfX;
            EvSGa:
            $GEb0i->color([185, 185, 185, 1]);
            goto POYkH;
            ecRri:
            $GEb0i->file(ZRkf6($this->G2Xe3));
            goto FR1Dy;
            FR1Dy:
            $iI4Nh = (int) ($EhATr * 1.2);
            goto JQVYf;
            JQVYf:
            $GEb0i->size(max($iI4Nh, 1));
            goto EvSGa;
            Y0jfX:
        });
        goto n6cTa;
        lqhj4:
        $E0voK = $bxUTl - $EhATr - 10;
        goto K9bJk;
        JnhSR:
        $rZyCr = (int) ($tCZeH / 80);
        goto lLSDU;
        ZLtO9:
        $fe3pc = $this->QFCsF->call($this, $qFAp6, $bxUTl);
        goto Toevq;
        p1lOw:
        return $pb2nG ? $TnwL2 : $this->K79lK->url($TnwL2);
        goto AZA4R;
        jowN8:
        if (!$this->K79lK->exists($TnwL2)) {
            goto GVaXj;
        }
        goto p1lOw;
        cAFw0:
    }
    private function mmmxFibQ50O(string $S9w3S, int $qFAp6, int $bxUTl, int $twdCl, int $Oa3FO) : string
    {
        $Cm2U3 = ltrim($S9w3S, '@');
        return "v2/watermark/{$Cm2U3}/{$qFAp6}x{$bxUTl}_{$twdCl}x{$Oa3FO}/text_watermark.png";
    }
    private function mC6jKKGJtwW($S9w3S, int $qFAp6, float $xuegt, float $EsMv0) : array
    {
        goto WtL21;
        rnSKr:
        $TP3tz = 1 / $EsMv0 * $Xx_ZL / strlen($VFqTL);
        goto r_bzq;
        rcqeE:
        $Xx_ZL = (int) ($qFAp6 * $xuegt);
        goto Mn2OS;
        Mn2OS:
        if (!($EsMv0 > 1)) {
            goto IlJU0;
        }
        goto a3UPY;
        WtL21:
        $VFqTL = '@' . $S9w3S;
        goto rcqeE;
        UPnVB:
        return [(int) $TP3tz, $TP3tz * strlen($VFqTL) / 1.8, $VFqTL];
        goto RMGLJ;
        a3UPY:
        $TP3tz = $Xx_ZL / (strlen($VFqTL) * 0.8);
        goto UPnVB;
        r_bzq:
        return [(int) $TP3tz, $Xx_ZL, $VFqTL];
        goto C6hlb;
        RMGLJ:
        IlJU0:
        goto rnSKr;
        C6hlb:
    }
}
