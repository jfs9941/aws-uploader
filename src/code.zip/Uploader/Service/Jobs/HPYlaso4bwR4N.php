<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Illuminate\Support\Facades\Log;
class HPYlaso4bwR4N implements StoreVideoToS3JobInterface
{
    private $nR9eC;
    private $VV2A8;
    private $QbAvB;
    public function __construct($xYZ3A, $oOPBt, $UNh9U)
    {
        goto VgKM8;
        K4l2l:
        $this->QbAvB = $UNh9U;
        goto YdEz2;
        VgKM8:
        $this->VV2A8 = $oOPBt;
        goto K4l2l;
        YdEz2:
        $this->nR9eC = $xYZ3A;
        goto j2ifJ;
        j2ifJ:
    }
    public function store(string $GhyxD) : void
    {
        goto n2TYK;
        a3vha:
        return;
        goto sV3qa;
        BkwWo:
        return;
        goto Kpeaz;
        Kpeaz:
        KDQGs:
        goto PbQzK;
        uLQGV:
        $T8Pp2 = memory_get_peak_usage();
        goto XZJKL;
        yAbaJ:
        $ZS1d_ = VHp3UACVYl357::find($GhyxD);
        goto b820Y;
        n2TYK:
        Log::info('Storing video (local) to S3', ['fileId' => $GhyxD, 'bucketName' => $this->nR9eC]);
        goto BnNCQ;
        pLiSq:
        $nxKEI = $this->VV2A8->getClient();
        goto C_P72;
        p5tVo:
        $uLgHj = $UNh9U->mimeType($ZS1d_->getLocation());
        goto S6NUu;
        XZJKL:
        try {
            goto Pah9I;
            r3hFe:
            fclose($gf_fo);
            goto c12T2;
            QcFDV:
            goto ZLoHJ;
            goto PisT7;
            PisT7:
            lvg6p:
            goto r3hFe;
            evo1W:
            ZLoHJ:
            goto vP6dM;
            gbpiR:
            $UNh9U->delete($ZS1d_->getLocation());
            goto oPDAo;
            Pah9I:
            $sx0QZ = $nxKEI->createMultipartUpload(['Bucket' => $this->nR9eC, 'Key' => $ZS1d_->getLocation(), 'ContentType' => $uLgHj, 'ContentDisposition' => 'inline']);
            goto Ju34h;
            JFG0R:
            $dXuiY[] = ['PartNumber' => $iIBLx, 'ETag' => $Drw68['ETag']];
            goto gaUdq;
            c12T2:
            $nxKEI->completeMultipartUpload(['Bucket' => $this->nR9eC, 'Key' => $ZS1d_->getLocation(), 'UploadId' => $ARG0J, 'MultipartUpload' => ['Parts' => $dXuiY]]);
            goto qmM3s;
            gaUdq:
            $iIBLx++;
            goto QcFDV;
            JEnwp:
            $dXuiY = [];
            goto evo1W;
            O7QaZ:
            $Drw68 = $nxKEI->uploadPart(['Bucket' => $this->nR9eC, 'Key' => $ZS1d_->getLocation(), 'UploadId' => $ARG0J, 'PartNumber' => $iIBLx, 'Body' => fread($gf_fo, $RwQud)]);
            goto JFG0R;
            vP6dM:
            if (feof($gf_fo)) {
                goto lvg6p;
            }
            goto O7QaZ;
            Ju34h:
            $ARG0J = $sx0QZ['UploadId'];
            goto PRt2a;
            qmM3s:
            $ZS1d_->update(['driver' => GoWVLKcTGnffy::S3, 'status' => LlMDscQw21XKp::FINISHED]);
            goto gbpiR;
            PRt2a:
            $iIBLx = 1;
            goto JEnwp;
            oPDAo:
        } catch (AwsException $w7Va8) {
            goto IhRhf;
            Kkh4n:
            Log::error('Failed to store video: ' . $ZS1d_->getLocation() . ' - ' . $w7Va8->getMessage());
            goto WodgS;
            tTL6Y:
            FYrWz:
            goto Kkh4n;
            IhRhf:
            if (!isset($ARG0J)) {
                goto FYrWz;
            }
            goto DWyuK;
            DWyuK:
            try {
                $nxKEI->abortMultipartUpload(['Bucket' => $this->nR9eC, 'Key' => $ZS1d_->getLocation(), 'UploadId' => $ARG0J]);
            } catch (AwsException $Wkt9v) {
                Log::error('Error aborting multipart upload: ' . $Wkt9v->getMessage());
            }
            goto tTL6Y;
            WodgS:
        } finally {
            $SBKSV = microtime(true);
            $YOCUN = memory_get_usage();
            $Pkr75 = memory_get_peak_usage();
            Log::info('Store VHp3UACVYl357 to S3 function resource usage', ['imageId' => $GhyxD, 'execution_time_sec' => $SBKSV - $FmdyL, 'memory_usage_mb' => ($YOCUN - $Iifsd) / 1024 / 1024, 'peak_memory_usage_mb' => ($Pkr75 - $T8Pp2) / 1024 / 1024]);
        }
        goto knXA2;
        thIrG:
        $Iifsd = memory_get_usage();
        goto uLQGV;
        S6NUu:
        $FmdyL = microtime(true);
        goto thIrG;
        Osn3e:
        Log::info("VHp3UACVYl357 has been deleted, discard it", ['fileId' => $GhyxD]);
        goto BkwWo;
        Q1LtL:
        $gf_fo = $UNh9U->readStream($ZS1d_->getLocation());
        goto PStHl;
        sV3qa:
        TkpfM:
        goto Q1LtL;
        PStHl:
        $RwQud = 1024 * 1024 * 50;
        goto p5tVo;
        PbQzK:
        if ($UNh9U->exists($ZS1d_->getLocation())) {
            goto TkpfM;
        }
        goto XzKJX;
        XzKJX:
        Log::error("[HPYlaso4bwR4N] File not found, discard it ", ['video' => $ZS1d_->getLocation()]);
        goto a3vha;
        BnNCQ:
        ini_set('memory_limit', '-1');
        goto pLiSq;
        b820Y:
        if ($ZS1d_) {
            goto KDQGs;
        }
        goto Osn3e;
        C_P72:
        $UNh9U = $this->QbAvB;
        goto yAbaJ;
        knXA2:
    }
}
