<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Encoder\Yj19iV1uFCxpK;
use Jfs\Uploader\Encoder\ObirvLOHr65Us;
use Jfs\Uploader\Encoder\VBDy3Gb7TKD1d;
use Jfs\Uploader\Encoder\TpYPhel5ae8Mx;
use Jfs\Uploader\Encoder\Wlw2CGgLj1kt6;
use Jfs\Uploader\Encoder\Ucavvzqn8yUfW;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Jfs\Uploader\Service\Jobs\ZZHFS3p7QJo7N;
use Jfs\Uploader\Service\Jobs\JQoP3jKbYunC3;
use Jfs\Uploader\Service\BJWEJOjkkZaRL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class N2RmE8OMymJfl implements MediaEncodeJobInterface
{
    private $PoRf3;
    private $SIeOC;
    private $UoQI7;
    private $aAXO2;
    private $PVphm;
    public function __construct(string $L2yxk, $Ay4fJ, $UjVft, $ZSFKK, $Tk5nz)
    {
        goto djOng;
        UClT_:
        $this->SIeOC = $Ay4fJ;
        goto YPMuZ;
        OxNc0:
        $this->PVphm = $Tk5nz;
        goto pEBpH;
        YQuU3:
        $this->aAXO2 = $ZSFKK;
        goto OxNc0;
        YPMuZ:
        $this->UoQI7 = $UjVft;
        goto YQuU3;
        djOng:
        $this->PoRf3 = $L2yxk;
        goto UClT_;
        pEBpH:
    }
    public function encode(string $InHEz, string $ubwD6, $AWg2o = true) : void
    {
        goto Z9TT4;
        Z9TT4:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $InHEz]);
        goto xO12K;
        xO12K:
        ini_set('memory_limit', '-1');
        goto RLxjV;
        RLxjV:
        try {
            goto RThfj;
            jpJvi:
            Log::info("Set thumbnail for JPkW9ix1EKo3T Job", ['videoId' => $qF0aQ->getAttribute('id'), 'duration' => $qF0aQ->getAttribute('duration')]);
            goto hDrDX;
            YVgzT:
            $ILKvW = app(BJWEJOjkkZaRL::class);
            goto rEPEb;
            qZ57E:
            $PWhHY = new ObirvLOHr65Us('original', $k2slg, $vci_g, $qF0aQ->p1n3K ?? 30);
            goto i3OJS;
            Eour3:
            Log::info("Set 1080p resolution for Job", ['width' => $NDSYh['width'], 'height' => $NDSYh['height'], 'originalWidth' => $k2slg, 'originalHeight' => $vci_g]);
            goto TrTaz;
            YOJLJ:
            $vci_g = $qF0aQ->height();
            goto msrVb;
            imK8F:
            $iAUh7 = app(Wlw2CGgLj1kt6::class);
            goto MgREx;
            YRSI0:
            $iAUh7->mlIMlreHZ0X($PWhHY);
            goto kmDUL;
            v5jVz:
            $qF0aQ->update(['aws_media_converter_job_id' => $InHEz]);
            goto ZKfvm;
            hDrDX:
            $NnQOx = new Yj19iV1uFCxpK($qF0aQ->getAttribute('duration') ?? 1, 2, $OKVxj->mVMlY7UBB1W($qF0aQ));
            goto AIWGU;
            TofVQ:
            $InHEz = $iAUh7->mvk1YpwJ4YW($this->m1N3fpBVJcx($qF0aQ, $AWg2o));
            goto v5jVz;
            EGmp2:
            if (!($k2slg && $vci_g)) {
                goto oCWwK;
            }
            goto NknU4;
            rEPEb:
            $Tdnut = new JQoP3jKbYunC3($this->aAXO2, $this->PVphm, $this->UoQI7, $this->SIeOC);
            goto Nzwng;
            kmDUL:
            $iAUh7->mCWif6BXvyD($OKVxj->mhSeqlHcPhr($qF0aQ));
            goto EGmp2;
            cleve:
            cYdVG:
            goto gU0YE;
            DPWLH:
            throw new MediaConverterException("JPkW9ix1EKo3T {$qF0aQ->id} is not S3 driver value = {$qF0aQ->driver}");
            goto cleve;
            DNR2g:
            BCFOv:
            goto YRSI0;
            jPKBk:
            $NDSYh = $this->mREv3e7Uvbq($k2slg, $vci_g);
            goto Eour3;
            H66ct:
            $PWhHY = $PWhHY->mxcgeB787nR($iu9vt);
            goto DNR2g;
            msrVb:
            $ag0fv = $this->mE3sPw9l2cH($qF0aQ);
            goto Oshl2;
            MgREx:
            $iAUh7 = $iAUh7->mbqxJAuhZaN(new TpYPhel5ae8Mx($ag0fv));
            goto qZ57E;
            Oshl2:
            Log::info("Set input video for Job", ['s3Uri' => $ag0fv]);
            goto imK8F;
            RThfj:
            $qF0aQ = JPkW9ix1EKo3T::findOrFail($InHEz);
            goto MgbtX;
            QPtkU:
            $MPvxT = $MPvxT->mxcgeB787nR($iu9vt);
            goto bT_U2;
            BlIXB:
            return;
            goto eN7MV;
            YXMJB:
            $iu9vt = $this->mg38BwGBBB2($ILKvW, $Tdnut->mF7paffjixE((int) $NDSYh['width'], (int) $NDSYh['height'], $ubwD6));
            goto x_T35;
            Xg1ip:
            $iAUh7->mCWif6BXvyD($OKVxj->mhSeqlHcPhr($qF0aQ));
            goto YVgzT;
            Nzwng:
            $iu9vt = $this->mg38BwGBBB2($ILKvW, $Tdnut->mF7paffjixE($qF0aQ->width(), $qF0aQ->height(), $ubwD6));
            goto aiqbn;
            pE0Pn:
            $iAUh7 = $iAUh7->mlIMlreHZ0X($MPvxT);
            goto Mp1g0;
            gU0YE:
            if (!$qF0aQ->getAttribute('aws_media_converter_job_id')) {
                goto RPmA6;
            }
            goto POUGO;
            x_T35:
            if (!$iu9vt) {
                goto xI4lG;
            }
            goto QPtkU;
            POUGO:
            Log::info("JPkW9ix1EKo3T already has Media Converter Job ID, skip encoding", ['fileId' => $InHEz, 'jobId' => $qF0aQ->getAttribute('aws_media_converter_job_id')]);
            goto BlIXB;
            aiqbn:
            if (!$iu9vt) {
                goto BCFOv;
            }
            goto H66ct;
            hAZhF:
            $k2slg = $qF0aQ->width();
            goto YOJLJ;
            MgbtX:
            Assert::isInstanceOf($qF0aQ, JPkW9ix1EKo3T::class);
            goto Xgbsy;
            AIWGU:
            $iAUh7 = $iAUh7->mTemmvhAvNc($NnQOx);
            goto TofVQ;
            TrTaz:
            $MPvxT = new ObirvLOHr65Us('1080p', $NDSYh['width'], $NDSYh['height'], $qF0aQ->p1n3K ?? 30);
            goto YXMJB;
            Mp1g0:
            HFdPD:
            goto lY60_;
            cqwJv:
            $iAUh7->mlIMlreHZ0X($PWhHY);
            goto Xg1ip;
            eN7MV:
            RPmA6:
            goto hAZhF;
            NknU4:
            if (!$this->mTyFPSdLPX4($k2slg, $vci_g)) {
                goto HFdPD;
            }
            goto jPKBk;
            bT_U2:
            xI4lG:
            goto pE0Pn;
            i3OJS:
            $OKVxj = app(VBDy3Gb7TKD1d::class);
            goto cqwJv;
            lY60_:
            oCWwK:
            goto jpJvi;
            Xgbsy:
            if (!($qF0aQ->driver != YJGCddWUf6Zu2::S3)) {
                goto cYdVG;
            }
            goto DPWLH;
            ZKfvm:
        } catch (\Exception $bAo2Y) {
            goto IeVQk;
            IeVQk:
            Log::warning("JPkW9ix1EKo3T has been deleted, discard it", ['fileId' => $InHEz, 'err' => $bAo2Y->getMessage()]);
            goto YBawV;
            Z71bV:
            return;
            goto I332Z;
            YBawV:
            Sentry::captureException($bAo2Y);
            goto Z71bV;
            I332Z:
        }
        goto IQnhC;
        IQnhC:
    }
    private function m1N3fpBVJcx(JPkW9ix1EKo3T $qF0aQ, $AWg2o) : bool
    {
        goto OydxZ;
        w7rIe:
        return false;
        goto F3xc3;
        OydxZ:
        if ($AWg2o) {
            goto CS1Jf;
        }
        goto w7rIe;
        hS2Af:
        I6We6:
        goto MeVGS;
        QK3uc:
        gaxSD:
        goto hS2Af;
        hSolR:
        switch (true) {
            case $qF0aQ->width() * $qF0aQ->height() >= 1920 * 1080 && $qF0aQ->width() * $qF0aQ->height() < 2560 * 1440:
                return $pvqTf > 30 * 60;
            case $qF0aQ->width() * $qF0aQ->height() >= 2560 * 1440 && $qF0aQ->width() * $qF0aQ->height() < 3840 * 2160:
                return $pvqTf > 15 * 60;
            case $qF0aQ->width() * $qF0aQ->height() >= 3840 * 2160:
                return $pvqTf > 10 * 60;
            default:
                return false;
        }
        goto QK3uc;
        h8Ovs:
        $pvqTf = (int) round($qF0aQ->getAttribute('duration') ?? 0);
        goto hSolR;
        F3xc3:
        CS1Jf:
        goto h8Ovs;
        MeVGS:
    }
    private function mg38BwGBBB2(BJWEJOjkkZaRL $ILKvW, string $NTSvS) : ?Ucavvzqn8yUfW
    {
        goto lJczU;
        T0Hs4:
        return null;
        goto vM0i0;
        wNRM0:
        Log::info("Resolve watermark for job with url", ['url' => $NTSvS, 'uri' => $cXZoo]);
        goto XrNs0;
        LApNh:
        return new Ucavvzqn8yUfW($cXZoo, 0, 0, null, null);
        goto WelrN;
        lJczU:
        $cXZoo = $ILKvW->mB1slIfbYNS($NTSvS);
        goto wNRM0;
        WelrN:
        peDmi:
        goto T0Hs4;
        XrNs0:
        if (!$cXZoo) {
            goto peDmi;
        }
        goto LApNh;
        vM0i0:
    }
    private function mTyFPSdLPX4(int $k2slg, int $vci_g) : bool
    {
        return $k2slg * $vci_g > 1.5 * (1920 * 1080);
    }
    private function mREv3e7Uvbq(int $k2slg, int $vci_g) : array
    {
        $eHhOR = new ZZHFS3p7QJo7N($k2slg, $vci_g);
        return $eHhOR->mJTgjdxagQ2();
    }
    private function mE3sPw9l2cH(IeEvjRaj1LMmG $UmLJ2) : string
    {
        goto P86xx;
        Y8txL:
        return $this->SIeOC->url($UmLJ2->filename);
        goto TM0Jg;
        P86xx:
        if (!($UmLJ2->driver == YJGCddWUf6Zu2::S3)) {
            goto igc9r;
        }
        goto iCIBk;
        iry8m:
        igc9r:
        goto Y8txL;
        iCIBk:
        return 's3://' . $this->PoRf3 . '/' . $UmLJ2->filename;
        goto iry8m;
        TM0Jg:
    }
}
