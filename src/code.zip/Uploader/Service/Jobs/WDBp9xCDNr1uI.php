<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class WDBp9xCDNr1uI
{
    private $IbMBG;
    private $mwdK1;
    public function __construct(int $Wd0Ft, int $NwwZE)
    {
        goto mB1ES;
        mB1ES:
        if (!($Wd0Ft <= 0)) {
            goto ALtHI;
        }
        goto nzVBZ;
        pjoww:
        nmXUE:
        goto LJ5GR;
        LJ5GR:
        $this->IbMBG = $Wd0Ft;
        goto sY5F6;
        zQ2km:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto pjoww;
        EkUcP:
        ALtHI:
        goto yteVY;
        nzVBZ:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto EkUcP;
        yteVY:
        if (!($NwwZE <= 0)) {
            goto nmXUE;
        }
        goto zQ2km;
        sY5F6:
        $this->mwdK1 = $NwwZE;
        goto rJIFn;
        rJIFn:
    }
    private static function m9lW5IQCVTI($A5ZOE, string $iLKmc = 'floor') : int
    {
        goto q1AcT;
        PGTqm:
        if (!(is_float($A5ZOE) && $A5ZOE == floor($A5ZOE) && (int) $A5ZOE % 2 === 0)) {
            goto Qk7i7;
        }
        goto wjqIa;
        q1AcT:
        if (!(is_int($A5ZOE) && $A5ZOE % 2 === 0)) {
            goto w9ji5;
        }
        goto ZUcFy;
        zf3yx:
        Qk7i7:
        goto oEiFj;
        I3qvf:
        ZDMT4:
        goto kvRSf;
        kfWog:
        HKvy8:
        goto I3qvf;
        oEiFj:
        switch (strtolower($iLKmc)) {
            case 'ceil':
                return (int) (ceil($A5ZOE / 2) * 2);
            case 'round':
                return (int) (round($A5ZOE / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($A5ZOE / 2) * 2);
        }
        goto kfWog;
        GrNzY:
        w9ji5:
        goto PGTqm;
        ZUcFy:
        return $A5ZOE;
        goto GrNzY;
        wjqIa:
        return (int) $A5ZOE;
        goto zf3yx;
        kvRSf:
    }
    public function mUvlefGiOaW(string $IxoM0 = 'floor') : array
    {
        goto K0oWo;
        NtHj6:
        if (!($bcib8 < 2)) {
            goto FT0qY;
        }
        goto KGN8W;
        SU32U:
        K8MOc:
        goto KT8Zh;
        p3YTR:
        FT0qY:
        goto jM7z5;
        aQRyU:
        fQ5Am:
        goto NtHj6;
        gesIJ:
        $WqmBr = $ygvmc / $this->mwdK1;
        goto BHnrl;
        paYfC:
        $ygvmc = self::m9lW5IQCVTI(round($sCdIR), $IxoM0);
        goto VbVbi;
        jM7z5:
        if (!($ygvmc < 2)) {
            goto K8MOc;
        }
        goto LQ28u;
        VbVbi:
        goto fQ5Am;
        goto RC6aC;
        Zo1on:
        if ($this->IbMBG >= $this->mwdK1) {
            goto CsTx4;
        }
        goto HKShS;
        ExSSJ:
        $ygvmc = $KLaVL;
        goto gesIJ;
        zRA0D:
        $bcib8 = 0;
        goto CGzt8;
        KGN8W:
        $bcib8 = 2;
        goto p3YTR;
        KT8Zh:
        return ['width' => $bcib8, 'height' => $ygvmc];
        goto d_29b;
        J2w3d:
        $sCdIR = $this->mwdK1 * $WqmBr;
        goto paYfC;
        K0oWo:
        $KLaVL = 1080;
        goto zRA0D;
        gBc7l:
        $WqmBr = $bcib8 / $this->IbMBG;
        goto J2w3d;
        LQ28u:
        $ygvmc = 2;
        goto SU32U;
        BHnrl:
        $MivpQ = $this->IbMBG * $WqmBr;
        goto QMoNr;
        CGzt8:
        $ygvmc = 0;
        goto Zo1on;
        RC6aC:
        CsTx4:
        goto ExSSJ;
        HKShS:
        $bcib8 = $KLaVL;
        goto gBc7l;
        QMoNr:
        $bcib8 = self::m9lW5IQCVTI(round($MivpQ), $IxoM0);
        goto aQRyU;
        d_29b:
    }
}
