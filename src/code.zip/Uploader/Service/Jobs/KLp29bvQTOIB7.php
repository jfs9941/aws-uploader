<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class KLp29bvQTOIB7 implements GenerateThumbnailForVideoInterface
{
    private $d8Yc5;
    public function __construct($OdiBr)
    {
        $this->d8Yc5 = $OdiBr;
    }
    public function generate(string $uuHkQ) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $uuHkQ);
        $this->d8Yc5->createThumbnail($uuHkQ);
    }
}
