<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class OFM3uMGaqzSr7 implements GenerateThumbnailForVideoInterface
{
    private $ZMr4M;
    public function __construct($RDm5V)
    {
        $this->ZMr4M = $RDm5V;
    }
    public function generate(string $BFPg9) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $BFPg9);
        $this->ZMr4M->createThumbnail($BFPg9);
    }
}
