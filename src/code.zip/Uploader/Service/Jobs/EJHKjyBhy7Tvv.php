<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class EJHKjyBhy7Tvv
{
    private $ow_A9;
    private $agUMw;
    private $auR_S;
    private $bX3fI;
    public function __construct($nNU6n, $Ein3P, $JhAxH, $Q0hWX)
    {
        goto O4NF_;
        SIxwi:
        $this->auR_S = $JhAxH;
        goto qRdKc;
        qRdKc:
        $this->bX3fI = $Q0hWX;
        goto p2vrg;
        O4NF_:
        $this->agUMw = $Ein3P;
        goto SIxwi;
        p2vrg:
        $this->ow_A9 = $nNU6n;
        goto ToQBT;
        ToQBT:
    }
    public function mqpgBukKPi0(?int $ABqPe, ?int $dE8ui, string $sIqHa, bool $BnWpx = false) : string
    {
        goto T6wdX;
        qMd7i:
        $isBC0 = $ABqPe - $WvTTh;
        goto xh9iO;
        SAMb5:
        throw new \RuntimeException("ACdpgX4YCYP6M dimensions are not available.");
        goto MxzJ0;
        GdZju:
        $kHreC = $this->ow_A9->call($this, $ABqPe, $dE8ui);
        goto qMd7i;
        aEgqn:
        $kHreC->text($yTvrS, $isBC0, (int) $VfBDS, function ($b1kdg) use($BpBDu) {
            goto qjB9R;
            Yjun9:
            $b1kdg->color([185, 185, 185, 1]);
            goto Q_yeK;
            lArCe:
            $vsu5D = (int) ($BpBDu * 1.2);
            goto AroD_;
            AroD_:
            $b1kdg->size(max($vsu5D, 1));
            goto Yjun9;
            vm3Re:
            $b1kdg->align('middle');
            goto KXKVs;
            qjB9R:
            $b1kdg->file(nTCyE($this->agUMw));
            goto lArCe;
            Q_yeK:
            $b1kdg->valign('middle');
            goto vm3Re;
            KXKVs:
        });
        goto f3nAV;
        vkDvm:
        return $BnWpx ? $JM0UK : $this->auR_S->url($JM0UK);
        goto xGxub;
        zMpW0:
        QnsVE:
        goto bBVQ8;
        dwk4P:
        $this->auR_S->put($JM0UK, $kHreC->stream('png'));
        goto vkDvm;
        YUMl_:
        if (!$this->auR_S->exists($JM0UK)) {
            goto bLW7t;
        }
        goto qKxlF;
        b24Yt:
        if (!($ABqPe > 1500)) {
            goto QnsVE;
        }
        goto Datsl;
        xh9iO:
        $IjyKs = (int) ($isBC0 / 80);
        goto RQhF_;
        Cmraa:
        $czpZs = 0.1;
        goto Cv4XP;
        bBVQ8:
        $VfBDS = $dE8ui - $BpBDu - 10;
        goto aEgqn;
        RQhF_:
        $isBC0 -= $IjyKs;
        goto b24Yt;
        qf2Ku:
        $JM0UK = $this->m4Vf0SXh4CN($yTvrS, $ABqPe, $dE8ui, $WvTTh, $BpBDu);
        goto YUMl_;
        MxzJ0:
        eEbHb:
        goto Cmraa;
        T6wdX:
        if (!($ABqPe === null || $dE8ui === null)) {
            goto eEbHb;
        }
        goto SAMb5;
        f3nAV:
        $this->bX3fI->put($JM0UK, $kHreC->stream('png'));
        goto dwk4P;
        qKxlF:
        return $BnWpx ? $JM0UK : $this->auR_S->url($JM0UK);
        goto m0OzO;
        m0OzO:
        bLW7t:
        goto GdZju;
        Datsl:
        $isBC0 -= $IjyKs * 0.4;
        goto zMpW0;
        Cv4XP:
        list($BpBDu, $WvTTh, $yTvrS) = $this->m2q7FdIGzgI($sIqHa, $ABqPe, $czpZs, (float) $ABqPe / $dE8ui);
        goto qf2Ku;
        xGxub:
    }
    private function m4Vf0SXh4CN(string $sIqHa, int $ABqPe, int $dE8ui, int $Cx9w0, int $Fhuzr) : string
    {
        $uEUFN = ltrim($sIqHa, '@');
        return "v2/watermark/{$uEUFN}/{$ABqPe}x{$dE8ui}_{$Cx9w0}x{$Fhuzr}/text_watermark.png";
    }
    private function m2q7FdIGzgI($sIqHa, int $ABqPe, float $iGkUG, float $SY1xU) : array
    {
        goto Xe_rJ;
        GwSRW:
        $WvTTh = (int) ($ABqPe * $iGkUG);
        goto icaNc;
        TH5_C:
        $VMUPk = $WvTTh / (strlen($yTvrS) * 0.8);
        goto J5jvV;
        GCZg3:
        lBEX9:
        goto KY6ce;
        KY6ce:
        $VMUPk = 1 / $SY1xU * $WvTTh / strlen($yTvrS);
        goto oleQr;
        icaNc:
        if (!($SY1xU > 1)) {
            goto lBEX9;
        }
        goto TH5_C;
        J5jvV:
        return [(int) $VMUPk, $VMUPk * strlen($yTvrS) / 1.8, $yTvrS];
        goto GCZg3;
        Xe_rJ:
        $yTvrS = '@' . $sIqHa;
        goto GwSRW;
        oleQr:
        return [(int) $VMUPk, $WvTTh, $yTvrS];
        goto KNQ_M;
        KNQ_M:
    }
}
