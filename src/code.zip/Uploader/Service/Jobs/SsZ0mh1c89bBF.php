<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class SsZ0mh1c89bBF
{
    private $eVAG5;
    private $r2W0C;
    private $RaPnW;
    private $OQTXf;
    public function __construct($Ar8h8, $ZoZ6N, $hTkyv, $eL8cO)
    {
        goto PzNhW;
        I9SZv:
        $this->RaPnW = $hTkyv;
        goto JVIpN;
        hi3OL:
        $this->eVAG5 = $Ar8h8;
        goto e0SB5;
        JVIpN:
        $this->OQTXf = $eL8cO;
        goto hi3OL;
        PzNhW:
        $this->r2W0C = $ZoZ6N;
        goto I9SZv;
        e0SB5:
    }
    public function mN7QCjDOwk9(?int $n9snl, ?int $M0J4r, string $grG7O, bool $uocSd = false) : string
    {
        goto R9sgY;
        ea7wU:
        $GBTcb = $n9snl - $fcYBT;
        goto IcjZ6;
        p3Oh5:
        $IS6o1->text($QYuJL, $GBTcb, (int) $AG3J4, function ($GhC6K) use($sVb1n) {
            goto swgeF;
            swgeF:
            $GhC6K->file(z6fVZ($this->r2W0C));
            goto gpjj3;
            Vzr1R:
            $GhC6K->color([185, 185, 185, 1]);
            goto Tv7nA;
            Tv7nA:
            $GhC6K->valign('middle');
            goto M0oz9;
            M0oz9:
            $GhC6K->align('middle');
            goto JS96n;
            ESSwn:
            $GhC6K->size(max($n3T2T, 1));
            goto Vzr1R;
            gpjj3:
            $n3T2T = (int) ($sVb1n * 1.2);
            goto ESSwn;
            JS96n:
        });
        goto Xmpw1;
        fcRtH:
        if (!($n9snl > 1500)) {
            goto IzHSb;
        }
        goto dbsnM;
        dUYhR:
        $eviRR = $this->mi9jzdtfI49($QYuJL, $n9snl, $M0J4r, $fcYBT, $sVb1n);
        goto Y4PrF;
        xFhrS:
        $IS6o1 = $this->eVAG5->call($this, $n9snl, $M0J4r);
        goto ea7wU;
        Xmpw1:
        $this->OQTXf->put($eviRR, $IS6o1->stream('png'));
        goto SdEX3;
        SdEX3:
        $this->RaPnW->put($eviRR, $IS6o1->stream('png'));
        goto wOKh3;
        d0vL5:
        PBhIa:
        goto xFhrS;
        wOKh3:
        return $uocSd ? $eviRR : $this->RaPnW->url($eviRR);
        goto oLYn7;
        Shvv4:
        s4117:
        goto S30Og;
        ppSBY:
        IzHSb:
        goto l3F7e;
        R9sgY:
        if (!($n9snl === null || $M0J4r === null)) {
            goto s4117;
        }
        goto Pmp70;
        LnnVe:
        $GBTcb -= $tNNrw;
        goto fcRtH;
        dbsnM:
        $GBTcb -= $tNNrw * 0.4;
        goto ppSBY;
        IcjZ6:
        $tNNrw = (int) ($GBTcb / 80);
        goto LnnVe;
        Y4PrF:
        if (!$this->RaPnW->exists($eviRR)) {
            goto PBhIa;
        }
        goto nWN5S;
        k4Vnm:
        list($sVb1n, $fcYBT, $QYuJL) = $this->mRo0PpsFn36($grG7O, $n9snl, $D69V0, (float) $n9snl / $M0J4r);
        goto dUYhR;
        l3F7e:
        $AG3J4 = $M0J4r - $sVb1n - 10;
        goto p3Oh5;
        nWN5S:
        return $uocSd ? $eviRR : $this->RaPnW->url($eviRR);
        goto d0vL5;
        Pmp70:
        throw new \RuntimeException("QdnSnf08v9RV7 dimensions are not available.");
        goto Shvv4;
        S30Og:
        $D69V0 = 0.1;
        goto k4Vnm;
        oLYn7:
    }
    private function mi9jzdtfI49(string $grG7O, int $n9snl, int $M0J4r, int $OQFXB, int $e3IF3) : string
    {
        $tmAT9 = ltrim($grG7O, '@');
        return "v2/watermark/{$tmAT9}/{$n9snl}x{$M0J4r}_{$OQFXB}x{$e3IF3}/text_watermark.png";
    }
    private function mRo0PpsFn36($grG7O, int $n9snl, float $VJZY4, float $aVX8K) : array
    {
        goto Jd0_S;
        Pa0ki:
        return [(int) $OhImS, $fcYBT, $QYuJL];
        goto ddxDY;
        J8CpT:
        $OhImS = 1 / $aVX8K * $fcYBT / strlen($QYuJL);
        goto Pa0ki;
        uaNcH:
        $OhImS = $fcYBT / (strlen($QYuJL) * 0.8);
        goto nO9kW;
        aIOXg:
        $fcYBT = (int) ($n9snl * $VJZY4);
        goto HfkyI;
        nO9kW:
        return [(int) $OhImS, $OhImS * strlen($QYuJL) / 1.8, $QYuJL];
        goto L1iaD;
        L1iaD:
        NkgFG:
        goto J8CpT;
        Jd0_S:
        $QYuJL = '@' . $grG7O;
        goto aIOXg;
        HfkyI:
        if (!($aVX8K > 1)) {
            goto NkgFG;
        }
        goto uaNcH;
        ddxDY:
    }
}
