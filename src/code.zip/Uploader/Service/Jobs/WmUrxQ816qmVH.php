<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class WmUrxQ816qmVH implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $eXur0) : void
    {
        goto RSDWP;
        RSDWP:
        $DuZ1o = S25BfMDKrX8cB::findOrFail($eXur0);
        goto rN6Rq;
        rN6Rq:
        if ($DuZ1o->width() > 0 && $DuZ1o->height() > 0) {
            goto RkP1A;
        }
        goto KIj_v;
        KIj_v:
        $this->m0zzaSyAXYE($DuZ1o);
        goto coACy;
        coACy:
        RkP1A:
        goto CtEit;
        CtEit:
    }
    private function m0zzaSyAXYE(S25BfMDKrX8cB $pwWUc) : void
    {
        goto QCFip;
        BcGgb:
        $Oq4R8 = $KZl7B->getDimensions();
        goto P7CkK;
        K7l9T:
        $KZl7B = $wpJD9->getVideoStream();
        goto BcGgb;
        W53KK:
        $wpJD9 = FFMpeg::fromDisk($pQ0Yz['path'])->open($pwWUc->getAttribute('filename'));
        goto K7l9T;
        QCFip:
        $pQ0Yz = $pwWUc->getView();
        goto W53KK;
        P7CkK:
        $pwWUc->update(['duration' => $wpJD9->getDurationInSeconds(), 'resolution' => $Oq4R8->getWidth() . 'x' . $Oq4R8->getHeight(), 'fps' => $KZl7B->get('r_frame_rate') ?? 30]);
        goto YeY4X;
        YeY4X:
    }
}
