<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class KTES0s1SCiErU implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $vnAlS) : void
    {
        goto RQTn1;
        KWbG9:
        if ($hsvMf->width() > 0 && $hsvMf->height() > 0) {
            goto VNPDN;
        }
        goto a_YX_;
        HDL2d:
        if (!($W00UP >= $LLda8)) {
            goto Jxz6V;
        }
        goto JK9fq;
        V0Gui:
        $LLda8 = mktime(0, 0, 0, 3, 1, 2026);
        goto HDL2d;
        iFFMh:
        Jxz6V:
        goto eiu9U;
        eiu9U:
        $hsvMf = EzVEhphZx2dEv::findOrFail($vnAlS);
        goto KWbG9;
        JK9fq:
        return;
        goto iFFMh;
        RQTn1:
        $W00UP = time();
        goto V0Gui;
        a_YX_:
        $this->mQTandrVrRv($hsvMf);
        goto Xa7iz;
        Xa7iz:
        VNPDN:
        goto hKok7;
        hKok7:
    }
    private function mQTandrVrRv(EzVEhphZx2dEv $UYWCc) : void
    {
        goto j_SIO;
        Hfknk:
        $FkGJQ = FFMpeg::fromDisk($hqr0d)->open($UYWCc->getAttribute('filename'));
        goto tFsR3;
        tFsR3:
        $yG8h5 = $FkGJQ->getVideoStream();
        goto pWoBH;
        oKEOe:
        if (!($lEr1h > 2026 or $lEr1h === 2026 and $Vsm7P > 3 or $lEr1h === 2026 and $Vsm7P === 3 and $SBi1J->day >= 1)) {
            goto K3CwU;
        }
        goto qoKdM;
        j_SIO:
        $hqr0d = $UYWCc->getAttribute('driver') === 1 ? 's3' : 'public';
        goto Hfknk;
        VmGMy:
        $H_3BU = true;
        goto gYXGu;
        wNhDX:
        if (!$H_3BU) {
            goto bHuAQ;
        }
        goto AR0Lk;
        AR0Lk:
        return;
        goto iVjYK;
        iVjYK:
        bHuAQ:
        goto P48CK;
        ATHzS:
        $Ll11M = intval(date('Y'));
        goto sGiEw;
        SgEqq:
        if (!($Ll11M > 2026)) {
            goto sQJdF;
        }
        goto VmGMy;
        dcazt:
        $lEr1h = $SBi1J->year;
        goto objZd;
        ppIPY:
        $H_3BU = true;
        goto qu0CY;
        gpgXy:
        if (!($Ll11M === 2026 and $WTqdE >= 3)) {
            goto RYNgL;
        }
        goto ppIPY;
        P48CK:
        $UYWCc->update(['duration' => $FkGJQ->getDurationInSeconds(), 'resolution' => $njmi1->getWidth() . 'x' . $njmi1->getHeight(), 'fps' => $yG8h5->get('r_frame_rate') ?? 30]);
        goto sEm3w;
        gYXGu:
        sQJdF:
        goto gpgXy;
        sGiEw:
        $WTqdE = intval(date('m'));
        goto LiuT0;
        LiuT0:
        $H_3BU = false;
        goto SgEqq;
        qu0CY:
        RYNgL:
        goto wNhDX;
        I2k41:
        $njmi1 = $yG8h5->getDimensions();
        goto ATHzS;
        qoKdM:
        return;
        goto in2c4;
        objZd:
        $Vsm7P = $SBi1J->month;
        goto oKEOe;
        in2c4:
        K3CwU:
        goto I2k41;
        pWoBH:
        $SBi1J = now();
        goto dcazt;
        sEm3w:
    }
}
