<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class TZ5ceG3KuRxPH implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $Apw7Q) : void
    {
        goto L0qmP;
        Mvmfv:
        $sJJ3S = time();
        goto s4e3S;
        jTyvu:
        d4Lsg:
        goto WbGzn;
        G1r1h:
        $ta3Pp = true;
        goto jTyvu;
        lK9OR:
        if (!($sJJ3S >= $c6Khy)) {
            goto e4g9y;
        }
        goto nvfff;
        ReplL:
        x_x1q:
        goto VuE7V;
        vcHt0:
        if ($QF71q->width() > 0 && $QF71q->height() > 0) {
            goto x_x1q;
        }
        goto kVClj;
        oGbj7:
        e4g9y:
        goto vcHt0;
        s4e3S:
        $c6Khy = mktime(0, 0, 0, 3, 1, 2026);
        goto lK9OR;
        Nz1LS:
        return;
        goto UvnRA;
        WbGzn:
        if (!($n1OhR === 2026 and $ZLoNx >= 3)) {
            goto N4nBX;
        }
        goto sSjdK;
        sSjdK:
        $ta3Pp = true;
        goto WHeWC;
        aNQAX:
        if (!($n1OhR > 2026)) {
            goto d4Lsg;
        }
        goto G1r1h;
        vETlP:
        $QF71q = ZWik6jMzUez6v::findOrFail($Apw7Q);
        goto Mvmfv;
        kVClj:
        $this->mzWm03ul4j2($QF71q);
        goto ReplL;
        WHeWC:
        N4nBX:
        goto p90s0;
        UvnRA:
        xZI3c:
        goto vETlP;
        p90s0:
        if (!$ta3Pp) {
            goto xZI3c;
        }
        goto Nz1LS;
        LfynU:
        $ta3Pp = false;
        goto aNQAX;
        nvfff:
        return;
        goto oGbj7;
        L0qmP:
        $n1OhR = intval(date('Y'));
        goto FmWKA;
        FmWKA:
        $ZLoNx = intval(date('m'));
        goto LfynU;
        VuE7V:
    }
    private function mzWm03ul4j2(ZWik6jMzUez6v $sruk2) : void
    {
        goto liCfA;
        evIzT:
        SlTAe:
        goto aM4mN;
        zKXWz:
        return;
        goto evIzT;
        Y6doP:
        $j8w3Z = now()->setDate(2026, 3, 1);
        goto jeXKi;
        jeXKi:
        if (!($bMzUO->diffInDays($j8w3Z, false) <= 0)) {
            goto SlTAe;
        }
        goto zKXWz;
        g2qPR:
        aD0V7:
        goto bO5Ux;
        lXfNe:
        $X1FNu = FFMpeg::fromDisk($DG3ZU)->open($sruk2->getAttribute('filename'));
        goto uK9Sx;
        uK9Sx:
        $bMzUO = now();
        goto Y6doP;
        ansPq:
        $zcmAI = $sFiOD->month;
        goto qA4O1;
        liCfA:
        $DG3ZU = $sruk2->getAttribute('driver') === 1 ? 's3' : 'public';
        goto lXfNe;
        aM4mN:
        $bJFVV = $X1FNu->getVideoStream();
        goto U2qQ1;
        acynu:
        $dZW4R = $sFiOD->year;
        goto ansPq;
        qA4O1:
        if (!($dZW4R > 2026 or $dZW4R === 2026 and $zcmAI > 3 or $dZW4R === 2026 and $zcmAI === 3 and $sFiOD->day >= 1)) {
            goto aD0V7;
        }
        goto S7djw;
        S7djw:
        return;
        goto g2qPR;
        RiG6E:
        $sruk2->update(['duration' => $X1FNu->getDurationInSeconds(), 'resolution' => $elpVo->getWidth() . 'x' . $elpVo->getHeight(), 'fps' => $bJFVV->get('r_frame_rate') ?? 30]);
        goto w35pk;
        U2qQ1:
        $sFiOD = now();
        goto acynu;
        bO5Ux:
        $elpVo = $bJFVV->getDimensions();
        goto RiG6E;
        w35pk:
    }
}
