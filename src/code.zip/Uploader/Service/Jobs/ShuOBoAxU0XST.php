<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class ShuOBoAxU0XST
{
    private $tiVps;
    private $aDr2m;
    private $rSfnv;
    private $unMfk;
    public function __construct($BYcL7, $Pa2dJ, $uIWH1, $L32kE)
    {
        goto za5Fk;
        za5Fk:
        $this->aDr2m = $Pa2dJ;
        goto ph1H3;
        tp1kJ:
        $this->unMfk = $L32kE;
        goto t5BDm;
        t5BDm:
        $this->tiVps = $BYcL7;
        goto P06Y4;
        ph1H3:
        $this->rSfnv = $uIWH1;
        goto tp1kJ;
        P06Y4:
    }
    public function mhwnG9Y7qwm(?int $XLJzE, ?int $X8shh, string $fmYhL, bool $vGFZ1 = false) : string
    {
        goto Z9a_K;
        KCXxv:
        $dtZyJ = (int) ($hvGY5 / 80);
        goto eoN0D;
        eoN0D:
        $hvGY5 -= $dtZyJ;
        goto oF4lP;
        X0klJ:
        $this->rSfnv->put($NSF8Y, $K0J89->stream('png'));
        goto KPReP;
        mgYyL:
        dmohX:
        goto qWJKb;
        HpQin:
        $hvGY5 -= $dtZyJ * 0.4;
        goto rC0vf;
        JZN5H:
        GfQlX:
        goto DeXcf;
        c_1LF:
        $v3u1G = $X8shh - $LCWxS - 10;
        goto YD8YK;
        lfS3b:
        $hvGY5 = $XLJzE - $ZaINr;
        goto KCXxv;
        cuU98:
        return $vGFZ1 ? $NSF8Y : $this->rSfnv->url($NSF8Y);
        goto JZN5H;
        YD8YK:
        $K0J89->text($Z9SbN, $hvGY5, (int) $v3u1G, function ($dkRSG) use($LCWxS) {
            goto KHpvW;
            wC3Ac:
            $dkRSG->valign('middle');
            goto IZFIf;
            fHGVn:
            $N0fHn = (int) ($LCWxS * 1.2);
            goto V1nA0;
            VZ0gX:
            $dkRSG->color([185, 185, 185, 1]);
            goto wC3Ac;
            IZFIf:
            $dkRSG->align('middle');
            goto sP0iR;
            V1nA0:
            $dkRSG->size(max($N0fHn, 1));
            goto VZ0gX;
            KHpvW:
            $dkRSG->file(public_path($this->aDr2m));
            goto fHGVn;
            sP0iR:
        });
        goto BZohE;
        oaukt:
        throw new \RuntimeException("N1wF7eNF4lYgo dimensions are not available.");
        goto mgYyL;
        DeXcf:
        $K0J89 = $this->tiVps->call($this, $XLJzE, $X8shh);
        goto lfS3b;
        rC0vf:
        VE2Va:
        goto c_1LF;
        KPReP:
        return $vGFZ1 ? $NSF8Y : $this->rSfnv->url($NSF8Y);
        goto UVhaB;
        gxZPT:
        if (!$this->rSfnv->exists($NSF8Y)) {
            goto GfQlX;
        }
        goto cuU98;
        XDwQ6:
        list($LCWxS, $ZaINr, $Z9SbN) = $this->mapdKvulF3l($fmYhL, $XLJzE, $f9PkJ, (float) $XLJzE / $X8shh);
        goto pWk2f;
        BZohE:
        $this->unMfk->put($NSF8Y, $K0J89->stream('png'));
        goto X0klJ;
        Z9a_K:
        if (!($XLJzE === null || $X8shh === null)) {
            goto dmohX;
        }
        goto oaukt;
        qWJKb:
        $f9PkJ = 0.1;
        goto XDwQ6;
        pWk2f:
        $NSF8Y = $this->mGmSxd94qBL($Z9SbN, $XLJzE, $X8shh, $ZaINr, $LCWxS);
        goto gxZPT;
        oF4lP:
        if (!($XLJzE > 1500)) {
            goto VE2Va;
        }
        goto HpQin;
        UVhaB:
    }
    private function mGmSxd94qBL(string $fmYhL, int $XLJzE, int $X8shh, int $lA9jL, int $Pp_mW) : string
    {
        $ap5D3 = ltrim($fmYhL, '@');
        return "v2/watermark/{$ap5D3}/{$XLJzE}x{$X8shh}_{$lA9jL}x{$Pp_mW}/text_watermark.png";
    }
    private function mapdKvulF3l($fmYhL, int $XLJzE, float $hWrb4, float $QZr52) : array
    {
        goto Np3gG;
        Np3gG:
        $Z9SbN = '@' . $fmYhL;
        goto IPjhg;
        wmRMn:
        $pgPkK = $ZaINr / (strlen($Z9SbN) * 0.8);
        goto WuuB_;
        Lkb1P:
        if (!($QZr52 > 1)) {
            goto YAMQZ;
        }
        goto wmRMn;
        WuuB_:
        return [(int) $pgPkK, $pgPkK * strlen($Z9SbN) / 1.8, $Z9SbN];
        goto NB_5k;
        IPjhg:
        $ZaINr = (int) ($XLJzE * $hWrb4);
        goto Lkb1P;
        NB_5k:
        YAMQZ:
        goto dPAUp;
        dPAUp:
        $pgPkK = 1 / $QZr52 * $ZaINr / strlen($Z9SbN);
        goto B389s;
        B389s:
        return [(int) $pgPkK, $ZaINr, $Z9SbN];
        goto CI0Yt;
        CI0Yt:
    }
}
