<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
class TzmwdyxO2Rgcq implements BlurJobInterface
{
    const oFxit = 15;
    const YOzWW = 500;
    const R0Xku = 500;
    private $KXch8;
    private $VoF9h;
    private $oBaPs;
    public function __construct($FeIAB, $BQ2l1, $paaZf)
    {
        goto CXGYJ;
        CfJ_M:
        $this->KXch8 = $FeIAB;
        goto gmA5V;
        A81Je:
        $this->VoF9h = $BQ2l1;
        goto CfJ_M;
        CXGYJ:
        $this->oBaPs = $paaZf;
        goto A81Je;
        gmA5V:
    }
    public function blur(string $JTwN4) : void
    {
        goto fVF2_;
        mjBza:
        ini_set('memory_limit', '-1');
        goto kjSYq;
        GjHvZ:
        $BC7bB = $this->VoF9h->put($vk8Z1, $a97TB->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto Wp2wP;
        fVF2_:
        $Oz_QK = Z7LUL65CwqbbF::findOrFail($JTwN4);
        goto mjBza;
        cwCpr:
        $a97TB = $this->KXch8->call($this, $this->oBaPs->path($Oz_QK->getLocation()));
        goto lCNsk;
        Wp2wP:
        unset($a97TB);
        goto lSrFi;
        CLFYo:
        $Oz_QK->update(['preview' => $vk8Z1]);
        goto C9bjn;
        iAevp:
        throw new \Exception('Failed to set final permissions on image file: ' . $BC7bB);
        goto rATFm;
        TTRcK:
        $a97TB->resize(self::YOzWW, self::R0Xku / $C2pdE);
        goto zwUbn;
        Bx895:
        $GQLo2 = $this->VoF9h->get($Oz_QK->filename);
        goto Rxl0o;
        rATFm:
        dcinn:
        goto CLFYo;
        Rxl0o:
        $this->oBaPs->put($Oz_QK->filename, $GQLo2);
        goto EeG3a;
        EeG3a:
        Y87Aq:
        goto cwCpr;
        L4oRw:
        \Log::warning('Failed to set final permissions on image file: ' . $BC7bB);
        goto iAevp;
        BHu_8:
        $vk8Z1 = $this->m0Ihgaxh2Ma($Oz_QK);
        goto GjHvZ;
        kjSYq:
        if (!($Oz_QK->avC90 == A3VATad7gvqZU::S3 && !$this->oBaPs->exists($Oz_QK->filename))) {
            goto Y87Aq;
        }
        goto Bx895;
        lSrFi:
        if (chmod($BC7bB, 0664)) {
            goto dcinn;
        }
        goto L4oRw;
        zwUbn:
        $a97TB->blur(self::oFxit);
        goto BHu_8;
        lCNsk:
        $C2pdE = $a97TB->width() / $a97TB->height();
        goto TTRcK;
        C9bjn:
    }
    private function m0Ihgaxh2Ma($QRnM3) : string
    {
        goto f7YrY;
        yOqn5:
        $this->oBaPs->makeDirectory($ksWJO, 0755, true);
        goto kDtyC;
        f7YrY:
        $uMpUA = $QRnM3->getLocation();
        goto rjp_1;
        rjp_1:
        $ksWJO = dirname($uMpUA) . '/preview/';
        goto fwwOs;
        fwwOs:
        if ($this->oBaPs->exists($ksWJO)) {
            goto WjbER;
        }
        goto yOqn5;
        Ojiqz:
        return $ksWJO . $QRnM3->getFilename() . '.jpg';
        goto mgT1e;
        kDtyC:
        WjbER:
        goto Ojiqz;
        mgT1e:
    }
}
