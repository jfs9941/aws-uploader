<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Illuminate\Support\Facades\Log;
class N4xvQ8HUrxUqz implements DownloadToLocalJobInterface
{
    private $VV2A8;
    private $QbAvB;
    public function __construct($oOPBt, $UNh9U)
    {
        $this->VV2A8 = $oOPBt;
        $this->QbAvB = $UNh9U;
    }
    public function download(string $GhyxD) : void
    {
        goto VniDR;
        s6s4f:
        $this->QbAvB->put($spSJx->getLocation(), $this->VV2A8->get($spSJx->getLocation()));
        goto r3872;
        k9foI:
        qBDeo:
        goto s6s4f;
        GjZPW:
        Log::info("Start download file to local", ['fileId' => $GhyxD, 'filename' => $spSJx->getLocation()]);
        goto wGqai;
        DbVzs:
        return;
        goto k9foI;
        wGqai:
        if (!$this->QbAvB->exists($spSJx->getLocation())) {
            goto qBDeo;
        }
        goto DbVzs;
        VniDR:
        $spSJx = IZ5shp3JHuftD::findOrFail($GhyxD);
        goto GjZPW;
        r3872:
    }
}
