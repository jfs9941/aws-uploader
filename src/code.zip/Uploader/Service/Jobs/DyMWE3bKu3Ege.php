<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class DyMWE3bKu3Ege implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $LpGEK) : void
    {
        goto l8CNK;
        l8CNK:
        $Qw86m = Jf5KRr8uE3t34::findOrFail($LpGEK);
        goto b6Mgb;
        fBMfy:
        $this->mtV0EIkXDWU($Qw86m);
        goto qtQ00;
        qtQ00:
        fp7UL:
        goto mMuc0;
        b6Mgb:
        if ($Qw86m->width() > 0 && $Qw86m->height() > 0) {
            goto fp7UL;
        }
        goto fBMfy;
        mMuc0:
    }
    private function mtV0EIkXDWU(Jf5KRr8uE3t34 $x95Gi) : void
    {
        goto O8Vl_;
        pk_IM:
        $qA6Ck = $IH9NP->getVideoStream();
        goto V201v;
        vrMti:
        $x95Gi->update(['duration' => $IH9NP->getDurationInSeconds(), 'resolution' => $qVrmJ->getWidth() . 'x' . $qVrmJ->getHeight(), 'fps' => $qA6Ck->get('r_frame_rate') ?? 30]);
        goto FqMY6;
        V201v:
        $qVrmJ = $qA6Ck->getDimensions();
        goto vrMti;
        dGVPP:
        $IH9NP = FFMpeg::fromDisk($n65l6['path'])->open($x95Gi->getAttribute('filename'));
        goto pk_IM;
        O8Vl_:
        $n65l6 = $x95Gi->getView();
        goto dGVPP;
        FqMY6:
    }
}
