<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Service\Jobs\LGhbTm20DkXql;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class WGP0OYATm1caa implements WatermarkTextJobInterface
{
    private $X2VAb;
    private $XsZUt;
    private $Fv8Ey;
    private $Mayr9;
    private $TD3CW;
    public function __construct($aC0aM, $K0xgM, $KI4Gx, $e3uVO, $Ep3r2)
    {
        goto ziv07;
        ndKgb:
        $this->TD3CW = $e3uVO;
        goto Q1G8I;
        ziv07:
        $this->X2VAb = $aC0aM;
        goto xjWd8;
        xjWd8:
        $this->Mayr9 = $KI4Gx;
        goto ndKgb;
        Q1G8I:
        $this->Fv8Ey = $Ep3r2;
        goto FHwnB;
        FHwnB:
        $this->XsZUt = $K0xgM;
        goto Xdtq8;
        Xdtq8:
    }
    public function putWatermark(string $iG1wy, string $Z9AwD) : void
    {
        goto Roe4i;
        VX3Y5:
        Log::info("Adding watermark text to image", ['imageId' => $iG1wy]);
        goto tp2nI;
        K5tpm:
        try {
            goto uY5t7;
            j6Mfo:
            $HCRCz = $this->TD3CW->path($cDDGh->getLocation());
            goto R261Y;
            a2DrW:
            YArrb:
            goto DTzRW;
            HdyGv:
            if (chmod($HCRCz, 0664)) {
                goto YArrb;
            }
            goto JglCt;
            MxS8z:
            throw new \Exception('Failed to set final permissions on image file: ' . $HCRCz);
            goto a2DrW;
            fk0kz:
            $this->Mayr9->put($HCRCz, $A6jce->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto C2WKH;
            tVvRo:
            if ($this->TD3CW->exists($cDDGh->getLocation())) {
                goto ddggK;
            }
            goto rL1H6;
            R261Y:
            $A6jce = $this->X2VAb->call($this, $HCRCz);
            goto Ndrx3;
            g4EeV:
            $this->myrS8H6BA08($A6jce, $Z9AwD);
            goto fk0kz;
            JglCt:
            \Log::warning('Failed to set final permissions on image file: ' . $HCRCz);
            goto MxS8z;
            C2WKH:
            unset($A6jce);
            goto HdyGv;
            uY5t7:
            $cDDGh = KyoDVfv3eGItF::findOrFail($iG1wy);
            goto tVvRo;
            zG4m4:
            ddggK:
            goto j6Mfo;
            EKdDI:
            return;
            goto zG4m4;
            Ndrx3:
            $A6jce->orient();
            goto g4EeV;
            rL1H6:
            Log::error("KyoDVfv3eGItF is not on local, might be deleted before put watermark", ['imageId' => $iG1wy]);
            goto EKdDI;
            DTzRW:
        } catch (\Throwable $OhWQt) {
            goto ijsEB;
            ijsEB:
            if (!$OhWQt instanceof ModelNotFoundException) {
                goto DmyUE;
            }
            goto QYdhs;
            Y1DWW:
            Log::error("KyoDVfv3eGItF is not readable", ['imageId' => $iG1wy, 'error' => $OhWQt->getMessage()]);
            goto ulMpC;
            QYdhs:
            Log::info("KyoDVfv3eGItF has been deleted, discard it", ['imageId' => $iG1wy]);
            goto vV_PJ;
            zIWiJ:
            DmyUE:
            goto Y1DWW;
            vV_PJ:
            return;
            goto zIWiJ;
            ulMpC:
        } finally {
            $ljc5H = microtime(true);
            $s7nhL = memory_get_usage();
            $h40IA = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $iG1wy, 'execution_time_sec' => $ljc5H - $mzMGr, 'memory_usage_mb' => ($s7nhL - $QFj0j) / 1024 / 1024, 'peak_memory_usage_mb' => ($h40IA - $qP_18) / 1024 / 1024]);
        }
        goto jCsCm;
        Roe4i:
        $mzMGr = microtime(true);
        goto v22St;
        Ko2Um:
        $qP_18 = memory_get_peak_usage();
        goto VX3Y5;
        tp2nI:
        ini_set('memory_limit', '-1');
        goto K5tpm;
        v22St:
        $QFj0j = memory_get_usage();
        goto Ko2Um;
        jCsCm:
    }
    private function myrS8H6BA08($A6jce, $Z9AwD) : void
    {
        goto tHCud;
        tHCud:
        $tz4Lg = $A6jce->width();
        goto NhkC4;
        Izub6:
        $VhU77 = new LGhbTm20DkXql($this->XsZUt, $this->Fv8Ey, $this->Mayr9, $this->TD3CW);
        goto XoNYM;
        XoNYM:
        $nhxtD = $VhU77->mNPBpvIvThx($tz4Lg, $vmBjz, $Z9AwD, true);
        goto nnkIl;
        nnkIl:
        $this->TD3CW->put($nhxtD, $this->Mayr9->get($nhxtD));
        goto WoPva;
        D_VoL:
        $A6jce->place($l80kV, 'top-left', 0, 0, 30);
        goto smbyX;
        NhkC4:
        $vmBjz = $A6jce->height();
        goto Izub6;
        WoPva:
        $l80kV = $this->X2VAb->call($this, $this->TD3CW->path($nhxtD));
        goto D_VoL;
        smbyX:
    }
}
