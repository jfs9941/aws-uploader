<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Illuminate\Support\Facades\Log;
class FA3PJ8mQILvi5 implements BlurVideoJobInterface
{
    const NwGhq = 15;
    const JDAdP = 500;
    const VfFIV = 500;
    private $X2VAb;
    private $Mayr9;
    private $nEL6Z;
    public function __construct($aC0aM, $KI4Gx, $vWt2S)
    {
        goto vEhUO;
        HY6rF:
        $this->Mayr9 = $KI4Gx;
        goto y8BFI;
        vEhUO:
        $this->nEL6Z = $vWt2S;
        goto HY6rF;
        y8BFI:
        $this->X2VAb = $aC0aM;
        goto bIzFJ;
        bIzFJ:
    }
    public function blur(string $iG1wy) : void
    {
        goto VBHkB;
        QSe_F:
        $cDDGh->blur(self::NwGhq);
        goto RMHDU;
        RMHDU:
        $JFak1 = $this->mWZUIOYeINf($OXHlS);
        goto XlfDX;
        gO2VU:
        unset($cDDGh);
        goto JpQKy;
        q8jvA:
        throw new \Exception('Failed to set final permissions on image file: ' . $xOCo0);
        goto VJh4D;
        OSHfR:
        $cDDGh->save($xOCo0);
        goto uPiM9;
        uPiM9:
        $this->Mayr9->put($JFak1, $this->nEL6Z->get($JFak1));
        goto gO2VU;
        ubiQ5:
        $this->nEL6Z->put($OXHlS->getAttribute('thumbnail'), $this->Mayr9->get($OXHlS->getAttribute('thumbnail')));
        goto akPy7;
        akPy7:
        $cDDGh = $this->X2VAb->call($this, $this->nEL6Z->path($OXHlS->getAttribute('thumbnail')));
        goto BQheL;
        D9rOI:
        $OXHlS->update(['preview' => $JFak1]);
        goto n9mQW;
        XlfDX:
        $xOCo0 = $this->nEL6Z->path($JFak1);
        goto OSHfR;
        n9mQW:
        zaAM8:
        goto OVNXm;
        VBHkB:
        Log::info("Blurring for video", ['videoID' => $iG1wy]);
        goto aATd8;
        JpQKy:
        if (chmod($xOCo0, 0664)) {
            goto FEFop;
        }
        goto dsUov;
        aATd8:
        ini_set('memory_limit', '-1');
        goto xNvMJ;
        dsUov:
        \Log::warning('Failed to set final permissions on image file: ' . $xOCo0);
        goto q8jvA;
        xNvMJ:
        $OXHlS = AelPShnd8pMtD::findOrFail($iG1wy);
        goto VHF6F;
        VJh4D:
        FEFop:
        goto D9rOI;
        LXQMr:
        $cDDGh->resize(self::JDAdP, self::VfFIV / $J0wvK);
        goto QSe_F;
        VHF6F:
        if (!$OXHlS->getAttribute('thumbnail')) {
            goto zaAM8;
        }
        goto ubiQ5;
        BQheL:
        $J0wvK = $cDDGh->width() / $cDDGh->height();
        goto LXQMr;
        OVNXm:
    }
    private function mWZUIOYeINf(VpkgrrmDu5rEh $p1zVs) : string
    {
        goto jkCuL;
        sP5vV:
        return $qmsbj . $p1zVs->getFilename() . '.jpg';
        goto jj2Yt;
        l9HXi:
        $this->nEL6Z->makeDirectory($qmsbj, 0755, true);
        goto BVrMg;
        h7bSp:
        $qmsbj = dirname($HCRCz) . '/preview/';
        goto i4P39;
        jkCuL:
        $HCRCz = $p1zVs->getLocation();
        goto h7bSp;
        i4P39:
        if ($this->nEL6Z->exists($qmsbj)) {
            goto Hhyu9;
        }
        goto l9HXi;
        BVrMg:
        Hhyu9:
        goto sP5vV;
        jj2Yt:
    }
}
