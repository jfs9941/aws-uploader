<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Illuminate\Support\Facades\Log;
class Aey2EfoFbVvmA implements StoreVideoToS3JobInterface
{
    private $plOtQ;
    private $ZN9hu;
    private $MuT3J;
    public function __construct($EcbH3, $C2YXG, $tBTgN)
    {
        goto RxYKy;
        H3V2D:
        $this->plOtQ = $EcbH3;
        goto Gm1iw;
        Dk2rQ:
        $this->MuT3J = $tBTgN;
        goto H3V2D;
        RxYKy:
        $this->ZN9hu = $C2YXG;
        goto Dk2rQ;
        Gm1iw:
    }
    public function store(string $uuHkQ) : void
    {
        goto VxaHy;
        MrEwm:
        $w2No1 = $this->ZN9hu->getClient();
        goto PuQqg;
        XeTKj:
        if ($g9vuR) {
            goto xPn4Z;
        }
        goto jIFds;
        Y4QDH:
        $LbW7D = $tBTgN->readStream($g9vuR->getLocation());
        goto KD5IK;
        Yyz0h:
        if ($tBTgN->exists($g9vuR->getLocation())) {
            goto Z0_9D;
        }
        goto JiXF6;
        Unqf2:
        $f24Pb = memory_get_usage();
        goto Y39pR;
        LDO3V:
        return;
        goto pIiFW;
        KD5IK:
        $EBuuG = 1024 * 1024 * 50;
        goto u2jnO;
        EkmVy:
        $g9vuR = WrCq6RmnGcVh7::find($uuHkQ);
        goto XeTKj;
        PuQqg:
        $tBTgN = $this->MuT3J;
        goto EkmVy;
        JiXF6:
        Log::error("[Aey2EfoFbVvmA] File not found, discard it ", ['video' => $g9vuR->getLocation()]);
        goto LDO3V;
        MZvTq:
        ini_set('memory_limit', '-1');
        goto MrEwm;
        sIMlc:
        xPn4Z:
        goto Yyz0h;
        jIFds:
        Log::info("WrCq6RmnGcVh7 has been deleted, discard it", ['fileId' => $uuHkQ]);
        goto ktdQ1;
        pIiFW:
        Z0_9D:
        goto Y4QDH;
        vTZz5:
        try {
            goto i4M9H;
            DaaJ0:
            $w2No1->completeMultipartUpload(['Bucket' => $this->plOtQ, 'Key' => $g9vuR->getLocation(), 'UploadId' => $zSVro, 'MultipartUpload' => ['Parts' => $l5I6a]]);
            goto ydoKs;
            yUnyb:
            $l5I6a[] = ['PartNumber' => $ySLip, 'ETag' => $MF7pi['ETag']];
            goto hLbfm;
            JZZrA:
            $ySLip = 1;
            goto qmmuh;
            qmmuh:
            $l5I6a = [];
            goto RM25Z;
            dCHRO:
            $tBTgN->delete($g9vuR->getLocation());
            goto vfZGv;
            rxOeF:
            $MF7pi = $w2No1->uploadPart(['Bucket' => $this->plOtQ, 'Key' => $g9vuR->getLocation(), 'UploadId' => $zSVro, 'PartNumber' => $ySLip, 'Body' => fread($LbW7D, $EBuuG)]);
            goto yUnyb;
            ydoKs:
            $g9vuR->update(['driver' => VNuaYSNcfVlT5::S3, 'status' => Xy3InMky6jKYf::FINISHED]);
            goto dCHRO;
            RM25Z:
            arWUE:
            goto Iwkup;
            UbvBx:
            igYyg:
            goto YZNLL;
            loS4Q:
            $zSVro = $CT4ZU['UploadId'];
            goto JZZrA;
            VBB1F:
            goto arWUE;
            goto UbvBx;
            Iwkup:
            if (feof($LbW7D)) {
                goto igYyg;
            }
            goto rxOeF;
            i4M9H:
            $CT4ZU = $w2No1->createMultipartUpload(['Bucket' => $this->plOtQ, 'Key' => $g9vuR->getLocation(), 'ContentType' => $kJivh, 'ContentDisposition' => 'inline']);
            goto loS4Q;
            hLbfm:
            $ySLip++;
            goto VBB1F;
            YZNLL:
            fclose($LbW7D);
            goto DaaJ0;
            vfZGv:
        } catch (AwsException $bhoVz) {
            goto FTkJA;
            un5pv:
            try {
                $w2No1->abortMultipartUpload(['Bucket' => $this->plOtQ, 'Key' => $g9vuR->getLocation(), 'UploadId' => $zSVro]);
            } catch (AwsException $OF9Iw) {
                Log::error('Error aborting multipart upload: ' . $OF9Iw->getMessage());
            }
            goto gnQeF;
            gnQeF:
            mFcf_:
            goto EUMa0;
            FTkJA:
            if (!isset($zSVro)) {
                goto mFcf_;
            }
            goto un5pv;
            EUMa0:
            Log::error('Failed to store video: ' . $g9vuR->getLocation() . ' - ' . $bhoVz->getMessage());
            goto B8jbq;
            B8jbq:
        } finally {
            $aNu_H = microtime(true);
            $RzZdv = memory_get_usage();
            $cUIGa = memory_get_peak_usage();
            Log::info('Store WrCq6RmnGcVh7 to S3 function resource usage', ['imageId' => $uuHkQ, 'execution_time_sec' => $aNu_H - $AzkxT, 'memory_usage_mb' => ($RzZdv - $f24Pb) / 1024 / 1024, 'peak_memory_usage_mb' => ($cUIGa - $QzVyt) / 1024 / 1024]);
        }
        goto FTE3N;
        Y39pR:
        $QzVyt = memory_get_peak_usage();
        goto vTZz5;
        z2pos:
        $AzkxT = microtime(true);
        goto Unqf2;
        VxaHy:
        Log::info('Storing video (local) to S3', ['fileId' => $uuHkQ, 'bucketName' => $this->plOtQ]);
        goto MZvTq;
        u2jnO:
        $kJivh = $tBTgN->mimeType($g9vuR->getLocation());
        goto z2pos;
        ktdQ1:
        return;
        goto sIMlc;
        FTE3N:
    }
}
