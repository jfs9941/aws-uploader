<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class J6dPhRQ5icZd8 implements GenerateThumbnailJobInterface
{
    const b705n = 150;
    const yf4OB = 150;
    private $wil31;
    private $MuT3J;
    private $UIHwe;
    public function __construct($jwYYV, $tBTgN, $W_qUx)
    {
        goto jyb_n;
        YUZ53:
        $this->UIHwe = $W_qUx;
        goto J_B_L;
        jyb_n:
        $this->wil31 = $jwYYV;
        goto LrE0O;
        LrE0O:
        $this->MuT3J = $tBTgN;
        goto YUZ53;
        J_B_L:
    }
    public function generate(string $uuHkQ)
    {
        goto g2Exo;
        NoSy5:
        ini_set('memory_limit', '-1');
        goto FIHWA;
        g2Exo:
        Log::info("Generating thumbnail", ['imageId' => $uuHkQ]);
        goto NoSy5;
        FIHWA:
        try {
            goto CddBs;
            I0yFt:
            a0AgI:
            goto uI342;
            E5a2O:
            $dSgog = $this->mHQ0rVDrgXm($tCWWG);
            goto PJTbV;
            CddBs:
            $kGo1c = $this->MuT3J;
            goto e7LGT;
            e7LGT:
            $tCWWG = QFoN7Ibbm93if::findOrFail($uuHkQ);
            goto yUNex;
            WYx31:
            unset($O7w3A);
            goto symdo;
            yUNex:
            $O7w3A = $this->wil31->call($this, $kGo1c->path($tCWWG->getLocation()));
            goto K4S_o;
            PJTbV:
            $FiqgV = $this->UIHwe->put($dSgog, $O7w3A->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto WYx31;
            K4S_o:
            $O7w3A->orient()->resize(150, 150);
            goto E5a2O;
            symdo:
            if (!($FiqgV !== false)) {
                goto a0AgI;
            }
            goto T1cWu;
            T1cWu:
            $tCWWG->update(['thumbnail' => $dSgog, 'status' => Xy3InMky6jKYf::THUMBNAIL_PROCESSED]);
            goto I0yFt;
            uI342:
        } catch (ModelNotFoundException $bhoVz) {
            Log::info("QFoN7Ibbm93if has been deleted, discard it", ['imageId' => $uuHkQ]);
            return;
        } catch (\Exception $bhoVz) {
            Log::error("Failed to generate thumbnail", ['imageId' => $uuHkQ, 'error' => $bhoVz->getMessage()]);
        }
        goto siRaV;
        siRaV:
    }
    private function mHQ0rVDrgXm(VMj30iBgKeeJB $tCWWG) : string
    {
        goto kSRKO;
        IL6gL:
        $FRM29 = $fgheN . '/' . self::b705n . 'X' . self::yf4OB;
        goto djqMa;
        kSRKO:
        $dSgog = $tCWWG->getLocation();
        goto T8Ohq;
        djqMa:
        return $FRM29 . '/' . $tCWWG->getFilename() . '.jpg';
        goto FaWar;
        T8Ohq:
        $fgheN = dirname($dSgog);
        goto IL6gL;
        FaWar:
    }
}
