<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Core\YdClVYDRbSDMR;
class Qj7VgmJfGZBVj implements BlurVideoJobInterface
{
    const CUgxQ = 15;
    const VOqXQ = 500;
    const kI5ZC = 500;
    private $Q1e5h;
    private $Aj6QZ;
    private $tGIcp;
    public function __construct($OdpJM, $SaekO, $UR4Dl)
    {
        goto zd8T6;
        zd8T6:
        $this->tGIcp = $UR4Dl;
        goto Xgt3w;
        Xgt3w:
        $this->Aj6QZ = $SaekO;
        goto gXq6C;
        gXq6C:
        $this->Q1e5h = $OdpJM;
        goto ufdDI;
        ufdDI:
    }
    public function blur(string $BFPg9) : void
    {
        goto NqO1I;
        mBQFB:
        $ab1g_->save($zRrOa);
        goto RuUJE;
        p1XVT:
        $UStoI = $this->myy6cfLsqHs($Qh8Qy);
        goto EYATe;
        S103I:
        $Qh8Qy = YdClVYDRbSDMR::findOrFail($BFPg9);
        goto Mrpb2;
        Kv8Gr:
        $ab1g_ = $this->Q1e5h->call($this, $this->tGIcp->path($Qh8Qy->getAttribute('thumbnail')));
        goto IQbRT;
        EYATe:
        $zRrOa = $this->tGIcp->path($UStoI);
        goto mBQFB;
        RuUJE:
        $this->Aj6QZ->put($UStoI, $this->tGIcp->get($UStoI));
        goto f1hua;
        XJZLh:
        $Qh8Qy->update(['preview' => $UStoI]);
        goto aaC04;
        Mrpb2:
        if (!$Qh8Qy->getAttribute('thumbnail')) {
            goto fUO2T;
        }
        goto SnSTX;
        byNy0:
        $ab1g_->resize(self::VOqXQ, self::kI5ZC / $JA9pQ);
        goto q30Pd;
        SnSTX:
        $this->tGIcp->put($Qh8Qy->getAttribute('thumbnail'), $this->Aj6QZ->get($Qh8Qy->getAttribute('thumbnail')));
        goto Kv8Gr;
        dYZjT:
        if (chmod($zRrOa, 0664)) {
            goto UzaeY;
        }
        goto vDg9O;
        q30Pd:
        $ab1g_->blur(self::CUgxQ);
        goto p1XVT;
        IQbRT:
        $JA9pQ = $ab1g_->width() / $ab1g_->height();
        goto byNy0;
        brZgE:
        ini_set('memory_limit', '-1');
        goto S103I;
        vDg9O:
        \Log::warning('Failed to set final permissions on image file: ' . $zRrOa);
        goto mpFHR;
        mpFHR:
        throw new \Exception('Failed to set final permissions on image file: ' . $zRrOa);
        goto NMaEc;
        f1hua:
        $ab1g_->destroy();
        goto dYZjT;
        NMaEc:
        UzaeY:
        goto XJZLh;
        aaC04:
        fUO2T:
        goto SOc3V;
        NqO1I:
        Log::info("Blurring for video", ['videoID' => $BFPg9]);
        goto brZgE;
        SOc3V:
    }
    private function myy6cfLsqHs(UZjgdpyMf06F7 $ZiVxT) : string
    {
        goto SRfIl;
        SRfIl:
        $fdqWg = $ZiVxT->getLocation();
        goto Tb0vW;
        BFLfI:
        HjwZr:
        goto qRl3r;
        Tb0vW:
        $kZACY = dirname($fdqWg) . '/preview/';
        goto cnVIT;
        bw_nN:
        $this->tGIcp->makeDirectory($kZACY, 0755, true);
        goto BFLfI;
        qRl3r:
        return $kZACY . $ZiVxT->getFilename() . '.jpg';
        goto k30KY;
        cnVIT:
        if ($this->tGIcp->exists($kZACY)) {
            goto HjwZr;
        }
        goto bw_nN;
        k30KY:
    }
}
