<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
class YLAM2pJCDHJ2V implements BlurVideoJobInterface
{
    const diTWl = 15;
    const Owfd3 = 500;
    const P_xoQ = 500;
    private $RFvhw;
    private $K79lK;
    private $HyJkj;
    public function __construct($LDEwd, $yEBaZ, $N7YvB)
    {
        goto EiXGG;
        Qbc5t:
        $this->K79lK = $yEBaZ;
        goto DBGai;
        DBGai:
        $this->RFvhw = $LDEwd;
        goto DJylD;
        EiXGG:
        $this->HyJkj = $N7YvB;
        goto Qbc5t;
        DJylD:
    }
    public function blur(string $Qu08p) : void
    {
        goto e_803;
        XpH2a:
        $u3yva = $this->m6TxZOKmY2G($WRCmQ);
        goto kDqov;
        Bprtp:
        $fe3pc->save($HWIuu);
        goto WWZhj;
        kiQMe:
        e1Akc:
        goto OxlRH;
        YBrz7:
        $this->HyJkj->put($WRCmQ->getAttribute('thumbnail'), $this->K79lK->get($WRCmQ->getAttribute('thumbnail')));
        goto KVRo7;
        Ex2u0:
        ij0uq:
        goto N7pDy;
        m8nD5:
        $WRCmQ = SmhkgG6le5p0r::findOrFail($Qu08p);
        goto OXjUZ;
        VB6tB:
        $EsMv0 = $fe3pc->width() / $fe3pc->height();
        goto oKxJK;
        OXjUZ:
        if (!$WRCmQ->getAttribute('thumbnail')) {
            goto e1Akc;
        }
        goto YBrz7;
        oKxJK:
        $fe3pc->resize(self::Owfd3, self::P_xoQ / $EsMv0);
        goto bpG3t;
        e_803:
        Log::info("Blurring for video", ['videoID' => $Qu08p]);
        goto nG3Tz;
        kDqov:
        $HWIuu = $this->HyJkj->path($u3yva);
        goto Bprtp;
        NKa2c:
        if (chmod($HWIuu, 0664)) {
            goto ij0uq;
        }
        goto ish_M;
        KVRo7:
        $fe3pc = $this->RFvhw->call($this, $this->HyJkj->path($WRCmQ->getAttribute('thumbnail')));
        goto VB6tB;
        bpG3t:
        $fe3pc->blur(self::diTWl);
        goto XpH2a;
        N7pDy:
        $WRCmQ->update(['preview' => $u3yva]);
        goto kiQMe;
        ish_M:
        \Log::warning('Failed to set final permissions on image file: ' . $HWIuu);
        goto TX0pB;
        WWZhj:
        $this->K79lK->put($u3yva, $this->HyJkj->get($u3yva));
        goto MIrCO;
        MIrCO:
        $fe3pc->destroy();
        goto NKa2c;
        nG3Tz:
        ini_set('memory_limit', '-1');
        goto m8nD5;
        TX0pB:
        throw new \Exception('Failed to set final permissions on image file: ' . $HWIuu);
        goto Ex2u0;
        OxlRH:
    }
    private function m6TxZOKmY2G(WEM4ywoGgpPLK $vyzSI) : string
    {
        goto psml5;
        AzU_I:
        VIRzh:
        goto Z5GbS;
        Z5GbS:
        return $zvQmT . $vyzSI->getFilename() . '.jpg';
        goto mCfXp;
        iuFaV:
        if ($this->HyJkj->exists($zvQmT)) {
            goto VIRzh;
        }
        goto gYKoN;
        psml5:
        $TnwL2 = $vyzSI->getLocation();
        goto Y9JU_;
        Y9JU_:
        $zvQmT = dirname($TnwL2) . '/preview/';
        goto iuFaV;
        gYKoN:
        $this->HyJkj->makeDirectory($zvQmT, 0755, true);
        goto AzU_I;
        mCfXp:
    }
}
