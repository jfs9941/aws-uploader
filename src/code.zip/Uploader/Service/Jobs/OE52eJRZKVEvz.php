<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Illuminate\Support\Facades\Log;
class OE52eJRZKVEvz implements BlurVideoJobInterface
{
    const C1gt6 = 15;
    const fa1k2 = 500;
    const TqGuR = 500;
    private $j6_VZ;
    private $RE_2F;
    private $F8ilg;
    public function __construct($od_dm, $WmwnR, $Pkopf)
    {
        goto ln8CQ;
        tuOLb:
        $this->RE_2F = $WmwnR;
        goto RNdm1;
        RNdm1:
        $this->j6_VZ = $od_dm;
        goto O27eY;
        ln8CQ:
        $this->F8ilg = $Pkopf;
        goto tuOLb;
        O27eY:
    }
    public function blur(string $LpGEK) : void
    {
        goto xROFH;
        Rdm6M:
        $ZQQzW->blur(self::C1gt6);
        goto Ff0LY;
        wF02a:
        unset($ZQQzW);
        goto FrZKI;
        xXfNc:
        $this->F8ilg->put($BEGLP->getAttribute('thumbnail'), $this->RE_2F->get($BEGLP->getAttribute('thumbnail')));
        goto O1qIX;
        OarDH:
        throw new \Exception('Failed to set final permissions on image file: ' . $jd4oJ);
        goto m35zW;
        m35zW:
        K34Kd:
        goto F1mvc;
        NwyMU:
        if (!$BEGLP->getAttribute('thumbnail')) {
            goto f0aT2;
        }
        goto xXfNc;
        HnQ7H:
        $lkDG2 = $ZQQzW->width() / $ZQQzW->height();
        goto PHfES;
        FrZKI:
        if (chmod($jd4oJ, 0664)) {
            goto K34Kd;
        }
        goto z1cEp;
        DbIwA:
        $this->RE_2F->put($XC0PR, $this->F8ilg->get($XC0PR));
        goto wF02a;
        xROFH:
        Log::info("Blurring for video", ['videoID' => $LpGEK]);
        goto FQA9I;
        O1qIX:
        $ZQQzW = $this->j6_VZ->call($this, $this->F8ilg->path($BEGLP->getAttribute('thumbnail')));
        goto HnQ7H;
        mf8sI:
        $BEGLP = Jf5KRr8uE3t34::findOrFail($LpGEK);
        goto NwyMU;
        BuHBg:
        $ZQQzW->save($jd4oJ);
        goto DbIwA;
        PHfES:
        $ZQQzW->resize(self::fa1k2, self::TqGuR / $lkDG2);
        goto Rdm6M;
        ZTqZy:
        $jd4oJ = $this->F8ilg->path($XC0PR);
        goto BuHBg;
        F1mvc:
        $BEGLP->update(['preview' => $XC0PR]);
        goto WF4aj;
        FQA9I:
        ini_set('memory_limit', '-1');
        goto mf8sI;
        Ff0LY:
        $XC0PR = $this->mGZsOkXdFW4($BEGLP);
        goto ZTqZy;
        WF4aj:
        f0aT2:
        goto PzG42;
        z1cEp:
        \Log::warning('Failed to set final permissions on image file: ' . $jd4oJ);
        goto OarDH;
        PzG42:
    }
    private function mGZsOkXdFW4(PaQmIZL22EnpA $GGyW5) : string
    {
        goto tW3mN;
        DZtyq:
        if ($this->F8ilg->exists($lWrHD)) {
            goto Bksyd;
        }
        goto Q2AlA;
        gBtBd:
        Bksyd:
        goto ZhoUO;
        ZhoUO:
        return $lWrHD . $GGyW5->getFilename() . '.jpg';
        goto ufJWE;
        Q2AlA:
        $this->F8ilg->makeDirectory($lWrHD, 0755, true);
        goto gBtBd;
        sDblR:
        $lWrHD = dirname($AvgzF) . '/preview/';
        goto DZtyq;
        tW3mN:
        $AvgzF = $GGyW5->getLocation();
        goto sDblR;
        ufJWE:
    }
}
