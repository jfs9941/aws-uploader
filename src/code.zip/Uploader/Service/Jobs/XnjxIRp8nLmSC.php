<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class XnjxIRp8nLmSC
{
    private $FWnBJ;
    private $CPEn3;
    public function __construct(int $eaQOG, int $mvAg1)
    {
        goto Z355A;
        FNDhc:
        $this->CPEn3 = $mvAg1;
        goto u_KFB;
        vhK9g:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto nGNHG;
        nGNHG:
        I0bEA:
        goto OH0j3;
        fNrat:
        if (!($mvAg1 <= 0)) {
            goto I0bEA;
        }
        goto vhK9g;
        Z355A:
        if (!($eaQOG <= 0)) {
            goto F3suR;
        }
        goto ngS0j;
        OH0j3:
        $this->FWnBJ = $eaQOG;
        goto FNDhc;
        Zqrb3:
        F3suR:
        goto fNrat;
        ngS0j:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto Zqrb3;
        u_KFB:
    }
    private static function maSnWLDfUZf($XTi0J, string $tg9jk = 'floor') : int
    {
        goto rpAnk;
        dlC3F:
        gX7oq:
        goto moFAc;
        wCtX8:
        switch (strtolower($tg9jk)) {
            case 'ceil':
                return (int) (ceil($XTi0J / 2) * 2);
            case 'round':
                return (int) (round($XTi0J / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($XTi0J / 2) * 2);
        }
        goto dlC3F;
        KCCDO:
        FO2YX:
        goto KS_U0;
        rpAnk:
        if (!(is_int($XTi0J) && $XTi0J % 2 === 0)) {
            goto FO2YX;
        }
        goto nzNwX;
        nzNwX:
        return $XTi0J;
        goto KCCDO;
        moFAc:
        AhB8K:
        goto KFlC0;
        KS_U0:
        if (!(is_float($XTi0J) && $XTi0J == floor($XTi0J) && (int) $XTi0J % 2 === 0)) {
            goto geIlK;
        }
        goto Q2pH3;
        Q2pH3:
        return (int) $XTi0J;
        goto aKh9m;
        aKh9m:
        geIlK:
        goto wCtX8;
        KFlC0:
    }
    public function mRphStIkDpY(string $tCZOl = 'floor') : array
    {
        goto kqJIR;
        G2_IB:
        $q5uQ2 = 0;
        goto XxmOM;
        WYLUf:
        uFTeT:
        goto akCI7;
        ktrbP:
        W90bq:
        goto xynXo;
        g7jqb:
        $ku8D5 = 2;
        goto aUOan;
        L1hPZ:
        if (!($q5uQ2 < 2)) {
            goto uFTeT;
        }
        goto MD3ro;
        xynXo:
        if (!($ku8D5 < 2)) {
            goto W2f0m;
        }
        goto g7jqb;
        wJqCm:
        $ku8D5 = $dwnPR;
        goto yztwz;
        MU0Rf:
        $q5uQ2 = $dwnPR;
        goto R4FyV;
        kqJIR:
        $dwnPR = 1080;
        goto Pre_M;
        XxmOM:
        if ($this->FWnBJ >= $this->CPEn3) {
            goto vU7wz;
        }
        goto wJqCm;
        ABGLp:
        vU7wz:
        goto MU0Rf;
        MD3ro:
        $q5uQ2 = 2;
        goto WYLUf;
        akCI7:
        return ['width' => $ku8D5, 'height' => $q5uQ2];
        goto HL2Qt;
        yztwz:
        $EaB1p = $ku8D5 / $this->FWnBJ;
        goto Bh_Mg;
        AF4wk:
        $ku8D5 = self::maSnWLDfUZf(round($TWawz), $tCZOl);
        goto ktrbP;
        GfMCV:
        goto W90bq;
        goto ABGLp;
        vSMZx:
        $TWawz = $this->FWnBJ * $EaB1p;
        goto AF4wk;
        aUOan:
        W2f0m:
        goto L1hPZ;
        R4FyV:
        $EaB1p = $q5uQ2 / $this->CPEn3;
        goto vSMZx;
        Pre_M:
        $ku8D5 = 0;
        goto G2_IB;
        Bh_Mg:
        $hvOgk = $this->CPEn3 * $EaB1p;
        goto Wkhrn;
        Wkhrn:
        $q5uQ2 = self::maSnWLDfUZf(round($hvOgk), $tCZOl);
        goto GfMCV;
        HL2Qt:
    }
}
