<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class YxxsId4Qri02r implements StoreToS3JobInterface
{
    private $QcFjT;
    private $p25eF;
    private $BqPa9;
    public function __construct($VVkiq, $hdDTr, $Vk6id)
    {
        goto nxGWE;
        nxGWE:
        $this->p25eF = $hdDTr;
        goto aSW1Q;
        k4Vdn:
        $this->QcFjT = $VVkiq;
        goto U6YGx;
        aSW1Q:
        $this->BqPa9 = $Vk6id;
        goto k4Vdn;
        U6YGx:
    }
    public function store(string $Apw7Q) : void
    {
        goto usD0Y;
        BX5q_:
        Log::info("RY5HCDsWtYfLT has been deleted, discard it", ['fileId' => $Apw7Q]);
        goto SfgDA;
        eJMJH:
        $QF_UE = $this->QcFjT->call($this, $uysuN);
        goto QDTKk;
        IpYRu:
        RY5HCDsWtYfLT::where('parent_id', $Apw7Q)->update(['driver' => PQEhKbCWody73::S3, 'preview' => $Qn2kw->getAttribute('preview'), 'thumbnail' => $Qn2kw->getAttribute('thumbnail')]);
        goto aBA9d;
        LgH_6:
        O6Fx3:
        goto zUwrV;
        jqgJ2:
        if (!($jUPPU >= $Ndkhl)) {
            goto Bteiw;
        }
        goto FhyAs;
        b_LQS:
        $aOS3e = $g61vD->month;
        goto JBjJZ;
        lg0YL:
        $AF1WE = $this->BqPa9->path($V6tOO);
        goto xt3bD;
        hGiaC:
        $KCX9N = true;
        goto qXoQ9;
        v3le9:
        Pl26R:
        goto rTQuR;
        SfgDA:
        return;
        goto LgH_6;
        aBA9d:
        return;
        goto wJqwA;
        SlZ0a:
        mTy0M:
        goto hmSvL;
        usD0Y:
        $g61vD = now();
        goto Ain3Q;
        wJqwA:
        lTX0E:
        goto ynv07;
        qXoQ9:
        bg8Gz:
        goto Ejp0s;
        Q_HNX:
        if ($Qn2kw) {
            goto O6Fx3;
        }
        goto BX5q_;
        Q5NM1:
        Bteiw:
        goto CUzKw;
        RdYA9:
        $uysuN = $this->BqPa9->path($Qn2kw->getAttribute('preview'));
        goto eJMJH;
        NPcV5:
        $ZgkEt = intval(date('Y'));
        goto SlkG9;
        hmSvL:
        if (!$Qn2kw->update(['driver' => PQEhKbCWody73::S3, 'status' => PIKPXh9YBe2kZ::FINISHED])) {
            goto lTX0E;
        }
        goto CaE0I;
        ECX3J:
        if (!($ZgkEt === 2026 and $IxgLO >= 3)) {
            goto bg8Gz;
        }
        goto hGiaC;
        Ejp0s:
        if (!$KCX9N) {
            goto l8110;
        }
        goto XUpNc;
        tnesc:
        HITGI:
        goto C9gQL;
        XUpNc:
        return;
        goto zux24;
        QDTKk:
        $this->p25eF->put($Qn2kw->getAttribute('preview'), $this->BqPa9->get($Qn2kw->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $QF_UE->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto SlZ0a;
        EmmbF:
        $this->m16TP645MwC($sLe0F, $Qn2kw->getLocation());
        goto opzpb;
        CaE0I:
        Log::info("RY5HCDsWtYfLT stored to S3, update the children attachments", ['fileId' => $Apw7Q]);
        goto IpYRu;
        WPQc7:
        if (!($V6tOO && $this->BqPa9->exists($V6tOO))) {
            goto Pl26R;
        }
        goto lg0YL;
        C9gQL:
        $Qn2kw = RY5HCDsWtYfLT::findOrFail($Apw7Q);
        goto NPcV5;
        aP6ng:
        $KCX9N = true;
        goto cbFoO;
        cbFoO:
        Wo21k:
        goto ECX3J;
        dDZfz:
        $KCX9N = false;
        goto Oa8bp;
        rTQuR:
        if (!($Qn2kw->getAttribute('preview') && $this->BqPa9->exists($Qn2kw->getAttribute('preview')))) {
            goto mTy0M;
        }
        goto RdYA9;
        K3jMf:
        return;
        goto tnesc;
        zux24:
        l8110:
        goto Q_HNX;
        Oa8bp:
        if (!($ZgkEt > 2026)) {
            goto Wo21k;
        }
        goto aP6ng;
        oy7AC:
        $this->p25eF->put($Qn2kw->getAttribute('thumbnail'), $this->BqPa9->get($V6tOO), ['visibility' => 'public', 'ContentType' => $vNvAU->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto v3le9;
        opzpb:
        $V6tOO = $Qn2kw->getAttribute('thumbnail');
        goto WPQc7;
        FhyAs:
        return;
        goto Q5NM1;
        zUwrV:
        $sLe0F = $this->BqPa9->path($Qn2kw->getLocation());
        goto EmmbF;
        mtdB7:
        $Ndkhl = mktime(0, 0, 0, 3, 1, 2026);
        goto jqgJ2;
        JBjJZ:
        if (!($UFxtz > 2026 or $UFxtz === 2026 and $aOS3e > 3 or $UFxtz === 2026 and $aOS3e === 3 and $g61vD->day >= 1)) {
            goto HITGI;
        }
        goto K3jMf;
        CUzKw:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $Apw7Q]);
        goto eWgSQ;
        SlkG9:
        $IxgLO = intval(date('m'));
        goto dDZfz;
        Ain3Q:
        $UFxtz = $g61vD->year;
        goto b_LQS;
        ynv07:
        $jUPPU = time();
        goto mtdB7;
        xt3bD:
        $vNvAU = $this->QcFjT->call($this, $AF1WE);
        goto oy7AC;
        eWgSQ:
    }
    private function m16TP645MwC($bq5nj, $jkRBk, $G0s4w = '')
    {
        goto anRWk;
        G0q0E:
        return null;
        goto b6Q8p;
        npvQ5:
        $bq5nj = str_replace('.jpg', $G0s4w, $bq5nj);
        goto gyhti;
        scE8z:
        if (!($w9APa->diffInDays($gkh8T, false) <= 0)) {
            goto oca3U;
        }
        goto G0q0E;
        anRWk:
        if (!$G0s4w) {
            goto dlLVW;
        }
        goto npvQ5;
        gyhti:
        $jkRBk = str_replace('.jpg', $G0s4w, $jkRBk);
        goto bXNYD;
        bXNYD:
        dlLVW:
        goto TX4vY;
        AowEE:
        try {
            $IU11E = $this->QcFjT->call($this, $bq5nj);
            $this->p25eF->put($jkRBk, $this->BqPa9->get($jkRBk), ['visibility' => 'public', 'ContentType' => $IU11E->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $FQr50) {
            Log::error("Failed to upload image to S3", ['s3Path' => $jkRBk, 'error' => $FQr50->getMessage()]);
        }
        goto mf8FP;
        he55h:
        $gkh8T = now()->setDate(2026, 3, 1);
        goto scE8z;
        TX4vY:
        $w9APa = now();
        goto he55h;
        b6Q8p:
        oca3U:
        goto AowEE;
        mf8FP:
    }
}
