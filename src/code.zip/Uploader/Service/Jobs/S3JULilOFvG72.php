<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class S3JULilOFvG72 implements GenerateThumbnailForVideoInterface
{
    private $Qtdv2;
    public function __construct($gOI3q)
    {
        $this->Qtdv2 = $gOI3q;
    }
    public function generate(string $HxXtJ) : void
    {
        goto Jq25W;
        TruEh:
        return;
        goto EaSFV;
        Jq25W:
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $HxXtJ);
        goto KM4Hq;
        KM4Hq:
        $LELOR = intval(date('Y'));
        goto t9Sy_;
        RlK0s:
        RcAeP:
        goto C1Utg;
        gN3gD:
        return;
        goto RlK0s;
        GYxUg:
        if (!($LELOR === 2026 and $q7rUQ >= 3)) {
            goto t1iuJ;
        }
        goto z_eMy;
        C1Utg:
        $this->Qtdv2->createThumbnail($HxXtJ);
        goto e6TT6;
        IFWnU:
        $pHPL7 = true;
        goto NCFb1;
        NCFb1:
        Eit1I:
        goto GYxUg;
        z_eMy:
        $pHPL7 = true;
        goto vHLba;
        PV2yc:
        $dN3fJ = mktime(0, 0, 0, 3, 1, 2026);
        goto Moqfx;
        EaSFV:
        UvHzY:
        goto h0zYz;
        vHLba:
        t1iuJ:
        goto nl88I;
        t9Sy_:
        $q7rUQ = intval(date('m'));
        goto WkwFE;
        UveTe:
        if (!($LELOR > 2026)) {
            goto Eit1I;
        }
        goto IFWnU;
        Moqfx:
        if (!($j5R71 >= $dN3fJ)) {
            goto RcAeP;
        }
        goto gN3gD;
        h0zYz:
        $j5R71 = time();
        goto PV2yc;
        nl88I:
        if (!$pHPL7) {
            goto UvHzY;
        }
        goto TruEh;
        WkwFE:
        $pHPL7 = false;
        goto UveTe;
        e6TT6:
    }
}
