<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Service\Jobs\Cxaa8rnKaz018;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class DuJSnFZWzPgxp implements WatermarkTextJobInterface
{
    private $M9duE;
    private $HSLaS;
    private $O1fTR;
    private $f1xKj;
    private $IA8m0;
    public function __construct($U2Jsh, $TNkgI, $C6boj, $Rgxn3, $HZTTi)
    {
        goto I7M0L;
        ihYH0:
        $this->O1fTR = $HZTTi;
        goto i_2A5;
        d7NQz:
        $this->f1xKj = $C6boj;
        goto zkBvA;
        i_2A5:
        $this->HSLaS = $TNkgI;
        goto Lybgz;
        I7M0L:
        $this->M9duE = $U2Jsh;
        goto d7NQz;
        zkBvA:
        $this->IA8m0 = $Rgxn3;
        goto ihYH0;
        Lybgz:
    }
    public function putWatermark(string $g5e_r, string $QZS56) : void
    {
        goto dc7Ol;
        Q1CfJ:
        Log::info("Adding watermark text to image", ['imageId' => $g5e_r]);
        goto hnhD0;
        LJJny:
        $kVF0z = memory_get_usage();
        goto a2pyh;
        hnhD0:
        ini_set('memory_limit', '-1');
        goto dTS6R;
        dc7Ol:
        $DbNb5 = microtime(true);
        goto LJJny;
        a2pyh:
        $i4hys = memory_get_peak_usage();
        goto Q1CfJ;
        dTS6R:
        try {
            goto qhDzT;
            UuPB7:
            \Log::warning('Failed to set final permissions on image file: ' . $FlxOy);
            goto UBLcW;
            xaWtq:
            $this->f1xKj->put($FlxOy, $Ucqv9->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto iRcfz;
            XMS_k:
            return;
            goto zQ2mR;
            qhDzT:
            $MSkzT = XqAJHKYeaW2YU::findOrFail($g5e_r);
            goto z7lsk;
            aHn8t:
            $Ucqv9 = $this->M9duE->call($this, $FlxOy);
            goto Nhdsr;
            sTAr5:
            $this->mqH8o0cNpuJ($Ucqv9, $QZS56);
            goto xaWtq;
            zQ2mR:
            tyw4w:
            goto CP69C;
            whZjz:
            Log::error("XqAJHKYeaW2YU is not on local, might be deleted before put watermark", ['imageId' => $g5e_r]);
            goto XMS_k;
            iRcfz:
            unset($Ucqv9);
            goto mn84e;
            CP69C:
            $FlxOy = $this->IA8m0->path($MSkzT->getLocation());
            goto aHn8t;
            z7lsk:
            if ($this->IA8m0->exists($MSkzT->getLocation())) {
                goto tyw4w;
            }
            goto whZjz;
            vaC8m:
            QBxyn:
            goto t7NIF;
            UBLcW:
            throw new \Exception('Failed to set final permissions on image file: ' . $FlxOy);
            goto vaC8m;
            Nhdsr:
            $Ucqv9->orient();
            goto sTAr5;
            mn84e:
            if (chmod($FlxOy, 0664)) {
                goto QBxyn;
            }
            goto UuPB7;
            t7NIF:
        } catch (\Throwable $LQFIY) {
            goto vy2xo;
            vy2xo:
            if (!$LQFIY instanceof ModelNotFoundException) {
                goto LnRhQ;
            }
            goto acjSY;
            acjSY:
            Log::info("XqAJHKYeaW2YU has been deleted, discard it", ['imageId' => $g5e_r]);
            goto nTqsn;
            nTqsn:
            return;
            goto XpYYB;
            Xq0N9:
            Log::error("XqAJHKYeaW2YU is not readable", ['imageId' => $g5e_r, 'error' => $LQFIY->getMessage()]);
            goto DKXA5;
            XpYYB:
            LnRhQ:
            goto Xq0N9;
            DKXA5:
        } finally {
            $nQGPQ = microtime(true);
            $E4uJa = memory_get_usage();
            $Q2gUW = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $g5e_r, 'execution_time_sec' => $nQGPQ - $DbNb5, 'memory_usage_mb' => ($E4uJa - $kVF0z) / 1024 / 1024, 'peak_memory_usage_mb' => ($Q2gUW - $i4hys) / 1024 / 1024]);
        }
        goto sQR61;
        sQR61:
    }
    private function mqH8o0cNpuJ($Ucqv9, $QZS56) : void
    {
        goto qTpoi;
        C0SpH:
        $vwirX = $Ucqv9->height();
        goto MdxA7;
        F8end:
        $this->IA8m0->put($byFsq, $this->f1xKj->get($byFsq));
        goto aqDyH;
        YV6Bb:
        $Ucqv9->place($oi6Ld, 'top-left', 0, 0, 30);
        goto NKk_t;
        MdxA7:
        $hAiuI = new Cxaa8rnKaz018($this->HSLaS, $this->O1fTR, $this->f1xKj, $this->IA8m0);
        goto NKiBy;
        aqDyH:
        $oi6Ld = $this->M9duE->call($this, $this->IA8m0->path($byFsq));
        goto YV6Bb;
        NKiBy:
        $byFsq = $hAiuI->m1xtUeFcf7X($SeDOJ, $vwirX, $QZS56, true);
        goto F8end;
        qTpoi:
        $SeDOJ = $Ucqv9->width();
        goto C0SpH;
        NKk_t:
    }
}
