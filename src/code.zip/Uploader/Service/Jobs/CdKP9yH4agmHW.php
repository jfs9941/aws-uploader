<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Illuminate\Support\Facades\Log;
class CdKP9yH4agmHW implements BlurVideoJobInterface
{
    const wSWQU = 15;
    const tKT9k = 500;
    const viX7F = 500;
    private $M9duE;
    private $f1xKj;
    private $SPj0U;
    public function __construct($U2Jsh, $C6boj, $KUQsT)
    {
        goto f94Ep;
        T6wEI:
        $this->M9duE = $U2Jsh;
        goto XBa5O;
        tJVpI:
        $this->f1xKj = $C6boj;
        goto T6wEI;
        f94Ep:
        $this->SPj0U = $KUQsT;
        goto tJVpI;
        XBa5O:
    }
    public function blur(string $g5e_r) : void
    {
        goto qG9Mm;
        s3BIo:
        \Log::warning('Failed to set final permissions on image file: ' . $uM9Pr);
        goto DXUOK;
        DXUOK:
        throw new \Exception('Failed to set final permissions on image file: ' . $uM9Pr);
        goto e9sGD;
        DXug2:
        $this->SPj0U->put($liMBK->getAttribute('thumbnail'), $this->f1xKj->get($liMBK->getAttribute('thumbnail')));
        goto n5zJK;
        WLsfS:
        if (chmod($uM9Pr, 0664)) {
            goto x6ZN8;
        }
        goto s3BIo;
        kzMPL:
        $MSkzT->resize(self::tKT9k, self::viX7F / $J6BhQ);
        goto nmb7F;
        BfEZ_:
        $liMBK = JbxOPjx4A3DUY::findOrFail($g5e_r);
        goto i1wXj;
        A_zxk:
        $uM9Pr = $this->SPj0U->path($a1HS_);
        goto ptw3O;
        i1wXj:
        if (!$liMBK->getAttribute('thumbnail')) {
            goto Dzu7Z;
        }
        goto DXug2;
        zjx0_:
        $this->f1xKj->put($a1HS_, $this->SPj0U->get($a1HS_));
        goto fgux6;
        nmb7F:
        $MSkzT->blur(self::wSWQU);
        goto mDcON;
        e9sGD:
        x6ZN8:
        goto ljVcw;
        X2LZy:
        ini_set('memory_limit', '-1');
        goto BfEZ_;
        ljVcw:
        $liMBK->update(['preview' => $a1HS_]);
        goto t3Sjy;
        qG9Mm:
        Log::info("Blurring for video", ['videoID' => $g5e_r]);
        goto X2LZy;
        mDcON:
        $a1HS_ = $this->meeZjeiY684($liMBK);
        goto A_zxk;
        ptw3O:
        $MSkzT->save($uM9Pr);
        goto zjx0_;
        n5zJK:
        $MSkzT = $this->M9duE->call($this, $this->SPj0U->path($liMBK->getAttribute('thumbnail')));
        goto WV9wB;
        fgux6:
        unset($MSkzT);
        goto WLsfS;
        WV9wB:
        $J6BhQ = $MSkzT->width() / $MSkzT->height();
        goto kzMPL;
        t3Sjy:
        Dzu7Z:
        goto N4i0j;
        N4i0j:
    }
    private function meeZjeiY684(KhQ4OQYybZ7Vk $wu1wA) : string
    {
        goto pbJr4;
        pBZim:
        $this->SPj0U->makeDirectory($dHOYe, 0755, true);
        goto jWBg0;
        pq9Nv:
        $dHOYe = dirname($FlxOy) . '/preview/';
        goto VlNJi;
        GiPP4:
        return $dHOYe . $wu1wA->getFilename() . '.jpg';
        goto WOWuY;
        VlNJi:
        if ($this->SPj0U->exists($dHOYe)) {
            goto PLgT3;
        }
        goto pBZim;
        pbJr4:
        $FlxOy = $wu1wA->getLocation();
        goto pq9Nv;
        jWBg0:
        PLgT3:
        goto GiPP4;
        WOWuY:
    }
}
