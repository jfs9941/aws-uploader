<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
class Z0qBcqYZD1txB implements StoreToS3JobInterface
{
    private $TMqxn;
    private $IRlXr;
    private $foEoP;
    public function __construct($xskW6, $JGvdR, $VGndK)
    {
        goto scspN;
        x6t_r:
        $this->TMqxn = $xskW6;
        goto mjeD_;
        ZPcBC:
        $this->foEoP = $VGndK;
        goto x6t_r;
        scspN:
        $this->IRlXr = $JGvdR;
        goto ZPcBC;
        mjeD_:
    }
    public function store(string $R7IrL) : void
    {
        goto a2EDw;
        jNZ8N:
        SZrGc:
        goto hl0MB;
        a2EDw:
        $jaCUa = OcbNsXl9lpteB::findOrFail($R7IrL);
        goto LZbCx;
        lwKl_:
        QP6cU:
        goto iOObL;
        G1ltv:
        $Qy7YW = $jaCUa->getAttribute('thumbnail');
        goto dUT7P;
        DnhoY:
        s_k9o:
        goto QEj50;
        iOObL:
        $XkdbN = $this->foEoP->path($jaCUa->getLocation());
        goto X4MAV;
        l9Kk0:
        if (!($jaCUa->getAttribute('preview') && $this->foEoP->exists($jaCUa->getAttribute('preview')))) {
            goto s_k9o;
        }
        goto lvCZe;
        cdpsS:
        $f1mMW = $this->foEoP->path($Qy7YW);
        goto whiX1;
        C7BHl:
        $xxeX2 = $this->TMqxn->call($this, $s2oYj);
        goto RfN3i;
        RfN3i:
        $this->IRlXr->put($jaCUa->getAttribute('preview'), $xxeX2->stream(), ['visibility' => 'public', 'ContentType' => $xxeX2->mime(), 'ContentDisposition' => 'inline']);
        goto DnhoY;
        NMbs4:
        tMyoM:
        goto l9Kk0;
        YlhVu:
        $this->IRlXr->put($jaCUa->getAttribute('thumbnail'), $i1LOg->stream(), ['visibility' => 'public', 'ContentType' => $i1LOg->mime(), 'ContentDisposition' => 'inline']);
        goto NMbs4;
        hl0MB:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $R7IrL]);
        goto bJUki;
        dUT7P:
        if (!($Qy7YW && $this->foEoP->exists($Qy7YW))) {
            goto tMyoM;
        }
        goto cdpsS;
        LZbCx:
        if ($jaCUa) {
            goto QP6cU;
        }
        goto eAHIf;
        whiX1:
        $i1LOg = $this->TMqxn->call($this, $f1mMW);
        goto YlhVu;
        HlGRo:
        OcbNsXl9lpteB::where('parent_id', $R7IrL)->update(['driver' => R278OrMF6HCNB::S3, 'preview' => $jaCUa->getAttribute('preview'), 'thumbnail' => $jaCUa->getAttribute('thumbnail')]);
        goto jfThp;
        I_33u:
        $this->IRlXr->put($jaCUa->getLocation(), $Xxl6q->stream(), ['visibility' => 'public', 'ContentType' => $Xxl6q->mime(), 'ContentDisposition' => 'inline']);
        goto G1ltv;
        jfThp:
        return;
        goto jNZ8N;
        eQ5Kx:
        return;
        goto lwKl_;
        eAHIf:
        Log::info("OcbNsXl9lpteB has been deleted, discard it", ['fileId' => $R7IrL]);
        goto eQ5Kx;
        QEj50:
        if (!$jaCUa->update(['driver' => R278OrMF6HCNB::S3, 'status' => QUh2VVA2TE5xx::FINISHED])) {
            goto SZrGc;
        }
        goto sRrqx;
        lvCZe:
        $s2oYj = $this->foEoP->path($jaCUa->getAttribute('preview'));
        goto C7BHl;
        X4MAV:
        $Xxl6q = $this->TMqxn->call($this, $XkdbN);
        goto I_33u;
        sRrqx:
        Log::info("OcbNsXl9lpteB stored to S3, update the children attachments", ['fileId' => $R7IrL]);
        goto HlGRo;
        bJUki:
    }
}
