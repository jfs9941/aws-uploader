<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class T5ZZWWFggB97v
{
    private $w6Q9a;
    private $RjfA2;
    public function __construct(int $Nnshy, int $hdVMA)
    {
        goto xAuIM;
        tRGU0:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto Z1see;
        RSQwN:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto q2OWm;
        xAuIM:
        if (!($Nnshy <= 0)) {
            goto NC9p2;
        }
        goto tRGU0;
        q2OWm:
        FSlPV:
        goto b_yKa;
        Z1see:
        NC9p2:
        goto G9Urb;
        KDMO4:
        $this->RjfA2 = $hdVMA;
        goto nKL16;
        b_yKa:
        $this->w6Q9a = $Nnshy;
        goto KDMO4;
        G9Urb:
        if (!($hdVMA <= 0)) {
            goto FSlPV;
        }
        goto RSQwN;
        nKL16:
    }
    private static function mUjqNimVCbi($KCH5r, string $p4BR3 = 'floor') : int
    {
        goto Lus8W;
        u4xL9:
        HA8GF:
        goto JNO_x;
        Lus8W:
        if (!(is_int($KCH5r) && $KCH5r % 2 === 0)) {
            goto EZmwY;
        }
        goto LaIPm;
        WuGQI:
        wpi0L:
        goto u4xL9;
        rjW_G:
        if (!(is_float($KCH5r) && $KCH5r == floor($KCH5r) && (int) $KCH5r % 2 === 0)) {
            goto DGHId;
        }
        goto C21Qf;
        nIn3g:
        switch (strtolower($p4BR3)) {
            case 'ceil':
                return (int) (ceil($KCH5r / 2) * 2);
            case 'round':
                return (int) (round($KCH5r / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($KCH5r / 2) * 2);
        }
        goto WuGQI;
        l5yZ2:
        EZmwY:
        goto rjW_G;
        LaIPm:
        return $KCH5r;
        goto l5yZ2;
        C21Qf:
        return (int) $KCH5r;
        goto NLhpB;
        NLhpB:
        DGHId:
        goto nIn3g;
        JNO_x:
    }
    public function miOYf0zDgHO(string $RPpLS = 'floor') : array
    {
        goto W2a5S;
        FOpgM:
        $Re4We = $BOouI / $this->w6Q9a;
        goto dosiv;
        dC9oz:
        $BOouI = self::mUjqNimVCbi(round($L2jJg), $RPpLS);
        goto inE1j;
        qH9G1:
        if ($this->w6Q9a >= $this->RjfA2) {
            goto fLqtc;
        }
        goto cZRsT;
        roKb0:
        $Z53z7 = $cDozq;
        goto C9aEG;
        C9aEG:
        $Re4We = $Z53z7 / $this->RjfA2;
        goto HVUZw;
        OZN1k:
        p5sDf:
        goto rMYwB;
        TxgiK:
        fLqtc:
        goto roKb0;
        z653F:
        $Z53z7 = self::mUjqNimVCbi(round($Ovuii), $RPpLS);
        goto xo0en;
        inE1j:
        Dux5z:
        goto wvtfF;
        dosiv:
        $Ovuii = $this->RjfA2 * $Re4We;
        goto z653F;
        cpy55:
        lb4sT:
        goto bIZ8v;
        rMYwB:
        if (!($Z53z7 < 2)) {
            goto lb4sT;
        }
        goto t_c8R;
        bIZ8v:
        return ['width' => $BOouI, 'height' => $Z53z7];
        goto t0801;
        W2a5S:
        $cDozq = 1080;
        goto E3cnz;
        trumh:
        $Z53z7 = 0;
        goto qH9G1;
        G2b5j:
        $BOouI = 2;
        goto OZN1k;
        t_c8R:
        $Z53z7 = 2;
        goto cpy55;
        xo0en:
        goto Dux5z;
        goto TxgiK;
        E3cnz:
        $BOouI = 0;
        goto trumh;
        cZRsT:
        $BOouI = $cDozq;
        goto FOpgM;
        wvtfF:
        if (!($BOouI < 2)) {
            goto p5sDf;
        }
        goto G2b5j;
        HVUZw:
        $L2jJg = $this->w6Q9a * $Re4We;
        goto dC9oz;
        t0801:
    }
}
