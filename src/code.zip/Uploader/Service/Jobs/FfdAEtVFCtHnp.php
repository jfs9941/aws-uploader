<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class FfdAEtVFCtHnp
{
    private $i16be;
    private $xramE;
    private $PxC6l;
    private $zoOKU;
    public function __construct($mBdvd, $rQUoL, $kxhX9, $e3FbC)
    {
        goto wJVoN;
        clZYS:
        $this->i16be = $mBdvd;
        goto LalUF;
        wJVoN:
        $this->xramE = $rQUoL;
        goto bcDDm;
        bcDDm:
        $this->PxC6l = $kxhX9;
        goto gCy00;
        gCy00:
        $this->zoOKU = $e3FbC;
        goto clZYS;
        LalUF:
    }
    public function mIeA78uqetR(?int $Sv6q3, ?int $G9pt9, string $tsV_X, bool $QPnhQ = false) : string
    {
        goto wajVx;
        yHzUk:
        list($KmhZ9, $qwJnp, $PG210) = $this->mh4cKpscB2C($tsV_X, $Sv6q3, $LtKBi, (float) $Sv6q3 / $G9pt9);
        goto XrEA8;
        W4Yvp:
        $FicCA = $Sv6q3 - $qwJnp;
        goto pOdiB;
        XZCy6:
        $B856r = $G9pt9 - $KmhZ9 - 10;
        goto imQoy;
        nDWFA:
        $gNhb4 = $this->i16be->call($this, $Sv6q3, $G9pt9);
        goto W4Yvp;
        djHB4:
        $FicCA -= $QnTXp;
        goto TJ4iq;
        JZ4gD:
        return $QPnhQ ? $d1QWa : $this->PxC6l->url($d1QWa);
        goto l9X4J;
        jA15w:
        $LtKBi = 0.1;
        goto yHzUk;
        pOdiB:
        $QnTXp = (int) ($FicCA / 80);
        goto djHB4;
        Rlj0W:
        $this->PxC6l->put($d1QWa, $gNhb4->stream('png'));
        goto JZ4gD;
        Vu0JM:
        return $QPnhQ ? $d1QWa : $this->PxC6l->url($d1QWa);
        goto Wk0J8;
        Wk0J8:
        vWUrd:
        goto nDWFA;
        DcohX:
        pmTOp:
        goto jA15w;
        wajVx:
        if (!($Sv6q3 === null || $G9pt9 === null)) {
            goto pmTOp;
        }
        goto hhEBP;
        ETfjg:
        $this->zoOKU->put($d1QWa, $gNhb4->stream('png'));
        goto Rlj0W;
        TJ4iq:
        if (!($Sv6q3 > 1500)) {
            goto nkgVu;
        }
        goto EI6AY;
        XrEA8:
        $d1QWa = $this->mhuyl1jtM6f($PG210, $Sv6q3, $G9pt9, $qwJnp, $KmhZ9);
        goto khshC;
        khshC:
        if (!$this->PxC6l->exists($d1QWa)) {
            goto vWUrd;
        }
        goto Vu0JM;
        imQoy:
        $gNhb4->text($PG210, $FicCA, (int) $B856r, function ($E1PBE) use($KmhZ9) {
            goto JBdBo;
            JBdBo:
            $E1PBE->file(public_path($this->xramE));
            goto hejmU;
            Cr9pJ:
            $E1PBE->align('middle');
            goto btwQZ;
            aP9QQ:
            $E1PBE->size(max($gKchC, 1));
            goto ZJOcp;
            ZJOcp:
            $E1PBE->color([185, 185, 185, 1]);
            goto wna8O;
            wna8O:
            $E1PBE->valign('middle');
            goto Cr9pJ;
            hejmU:
            $gKchC = (int) ($KmhZ9 * 1.2);
            goto aP9QQ;
            btwQZ:
        });
        goto ETfjg;
        hhEBP:
        throw new \RuntimeException("BtruCfJoaSWZ6 dimensions are not available.");
        goto DcohX;
        ukofl:
        nkgVu:
        goto XZCy6;
        EI6AY:
        $FicCA -= $QnTXp * 0.4;
        goto ukofl;
        l9X4J:
    }
    private function mhuyl1jtM6f(string $tsV_X, int $Sv6q3, int $G9pt9, int $YsRRB, int $VXTUD) : string
    {
        $YxYhR = ltrim($tsV_X, '@');
        return "v2/watermark/{$YxYhR}/{$Sv6q3}x{$G9pt9}_{$YsRRB}x{$VXTUD}/text_watermark.png";
    }
    private function mh4cKpscB2C($tsV_X, int $Sv6q3, float $h0LNd, float $JC9uJ) : array
    {
        goto zLL1O;
        IE9mm:
        vRy6f:
        goto PcFWO;
        tZ4K7:
        if (!($JC9uJ > 1)) {
            goto vRy6f;
        }
        goto Ec4wi;
        Ec4wi:
        $WVsRN = $qwJnp / (strlen($PG210) * 0.8);
        goto zjVQs;
        InmFW:
        return [(int) $WVsRN, $qwJnp, $PG210];
        goto xalPX;
        PcFWO:
        $WVsRN = 1 / $JC9uJ * $qwJnp / strlen($PG210);
        goto InmFW;
        zLL1O:
        $PG210 = '@' . $tsV_X;
        goto cqygb;
        cqygb:
        $qwJnp = (int) ($Sv6q3 * $h0LNd);
        goto tZ4K7;
        zjVQs:
        return [(int) $WVsRN, $WVsRN * strlen($PG210) / 1.8, $PG210];
        goto IE9mm;
        xalPX:
    }
}
