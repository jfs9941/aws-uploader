<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
class Tql71Fg24MO85 implements GenerateThumbnailJobInterface
{
    const YG24j = 150;
    const I1c9T = 150;
    private $SJRrZ;
    private $xbA_A;
    public function __construct($akc4V, $a_5ue)
    {
        $this->SJRrZ = $akc4V;
        $this->xbA_A = $a_5ue;
    }
    public function generate(string $ld8Ad)
    {
        goto r1u0W;
        r1u0W:
        Log::info("Generating thumbnail", ['imageId' => $ld8Ad]);
        goto KxHat;
        KxHat:
        ini_set('memory_limit', '-1');
        goto ALXe8;
        ALXe8:
        try {
            goto lMWEb;
            DFZqN:
            $q27M2 = $this->SJRrZ->call($this, $e1L33->path($xobEP->getLocation()));
            goto G1mEz;
            zLmBX:
            if (chmod($BP5jC, 0644)) {
                goto YL3wq;
            }
            goto wTwJ1;
            EmDEv:
            $BP5jC = $e1L33->path($jGQTt);
            goto zLmBX;
            fj4Wa:
            $xobEP = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
            goto DFZqN;
            lMWEb:
            $e1L33 = $this->xbA_A;
            goto fj4Wa;
            B2bHQ:
            YL3wq:
            goto zvaD7;
            zvaD7:
            wfDp6:
            goto TuE4B;
            wyZGj:
            if (!($x8tHY !== false)) {
                goto wfDp6;
            }
            goto gHoT3;
            G1mEz:
            $q27M2 = $q27M2->orient()->resize(150, 150);
            goto NlMWu;
            wTwJ1:
            Log::warning('Failed to set file permissions for stored image: ' . $BP5jC);
            goto hBqyR;
            gzo1S:
            unset($q27M2);
            goto wyZGj;
            hBqyR:
            throw new \Exception('Failed to set file permissions for stored image: ' . $BP5jC);
            goto B2bHQ;
            gHoT3:
            $xobEP->update(['thumbnail' => $jGQTt, 'status' => UimQKBIuLCEAO::THUMBNAIL_PROCESSED]);
            goto EmDEv;
            nAas0:
            $x8tHY = $e1L33->put($jGQTt, $q27M2->toWebp(70), ['visibility' => 'public']);
            goto gzo1S;
            NlMWu:
            $jGQTt = $this->mnQ8tJizK2h($xobEP);
            goto nAas0;
            TuE4B:
        } catch (ModelNotFoundException $nXJFP) {
            Log::info("Sf7MFJ2wUSx2k has been deleted, discard it", ['imageId' => $ld8Ad]);
            return;
        }
        goto DCdN8;
        DCdN8:
    }
    private function mnQ8tJizK2h(O4HsadxAyKjYq $xobEP) : string
    {
        goto o0inG;
        o0inG:
        $jGQTt = $xobEP->getLocation();
        goto dZ2wo;
        FRj0O:
        return $kggc6 . '/' . $xobEP->getFilename() . '.jpg';
        goto uIG9g;
        dZ2wo:
        $BaehP = dirname($jGQTt);
        goto a0BpB;
        a0BpB:
        $kggc6 = $BaehP . '/' . self::YG24j . 'X' . self::I1c9T;
        goto FRj0O;
        uIG9g:
    }
}
