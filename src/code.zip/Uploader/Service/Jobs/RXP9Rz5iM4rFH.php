<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class RXP9Rz5iM4rFH implements StoreToS3JobInterface
{
    private $ABFqP;
    private $QxLu3;
    private $aW0a3;
    public function __construct($xLMar, $bjIIR, $eEhuZ)
    {
        goto eTgqh;
        xkhz5:
        $this->ABFqP = $xLMar;
        goto fPEYD;
        OLV6u:
        $this->aW0a3 = $eEhuZ;
        goto xkhz5;
        eTgqh:
        $this->QxLu3 = $bjIIR;
        goto OLV6u;
        fPEYD:
    }
    public function store(string $qMhfW) : void
    {
        goto GQ5QI;
        Q1zD2:
        GoePD:
        goto VXecE;
        ZqdKN:
        klzGq:
        goto rRNKX;
        jRNXy:
        y4p7J:
        goto jBCyv;
        h8mxb:
        $tbsXX = $this->aW0a3->path($ij6Dh->getAttribute('preview'));
        goto O4pgH;
        LCXNE:
        Log::info("WUuz09CA4woAL has been deleted, discard it", ['fileId' => $qMhfW]);
        goto SgJD1;
        O4pgH:
        $CrDYv = $this->ABFqP->call($this, $tbsXX);
        goto icvOA;
        ZZdA3:
        $this->QxLu3->put($ij6Dh->getAttribute('thumbnail'), $this->aW0a3->get($pViZL), ['visibility' => 'public', 'ContentType' => $f_EWh->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Q1zD2;
        mVsXr:
        UKv7B:
        goto JQXGp;
        FQt5N:
        $this->m9Dc8YTTZH4($b0LKC, $ij6Dh->getLocation());
        goto o1KCq;
        icvOA:
        $this->QxLu3->put($ij6Dh->getAttribute('preview'), $this->aW0a3->get($ij6Dh->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $CrDYv->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto mVsXr;
        nv3Uq:
        WUuz09CA4woAL::where('parent_id', $qMhfW)->update(['driver' => YOaiWCgFM7tRK::S3, 'preview' => $ij6Dh->getAttribute('preview'), 'thumbnail' => $ij6Dh->getAttribute('thumbnail')]);
        goto Iosu0;
        VXecE:
        if (!($ij6Dh->getAttribute('preview') && $this->aW0a3->exists($ij6Dh->getAttribute('preview')))) {
            goto UKv7B;
        }
        goto h8mxb;
        SgJD1:
        return;
        goto ZqdKN;
        jBCyv:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $qMhfW]);
        goto bhpSr;
        o1KCq:
        $pViZL = $ij6Dh->getAttribute('thumbnail');
        goto xgnaD;
        ndA4e:
        $f_EWh = $this->ABFqP->call($this, $SwPnY);
        goto ZZdA3;
        OIK1c:
        if ($ij6Dh) {
            goto klzGq;
        }
        goto LCXNE;
        rRNKX:
        $b0LKC = $this->aW0a3->path($ij6Dh->getLocation());
        goto FQt5N;
        v2HDm:
        Log::info("WUuz09CA4woAL stored to S3, update the children attachments", ['fileId' => $qMhfW]);
        goto nv3Uq;
        GQ5QI:
        $ij6Dh = WUuz09CA4woAL::findOrFail($qMhfW);
        goto OIK1c;
        Iosu0:
        return;
        goto jRNXy;
        JQXGp:
        if (!$ij6Dh->update(['driver' => YOaiWCgFM7tRK::S3, 'status' => TSfaBZEUMcbl0::FINISHED])) {
            goto y4p7J;
        }
        goto v2HDm;
        xgnaD:
        if (!($pViZL && $this->aW0a3->exists($pViZL))) {
            goto GoePD;
        }
        goto clBFu;
        clBFu:
        $SwPnY = $this->aW0a3->path($pViZL);
        goto ndA4e;
        bhpSr:
    }
    private function m9Dc8YTTZH4($HNFqH, $O9gvw, $G5Hlr = '')
    {
        goto gnBVr;
        gnBVr:
        if (!$G5Hlr) {
            goto fJH1J;
        }
        goto kRQPh;
        xuuWz:
        fJH1J:
        goto hCPv8;
        dn0VL:
        $O9gvw = str_replace('.jpg', $G5Hlr, $O9gvw);
        goto xuuWz;
        hCPv8:
        try {
            $T4AWF = $this->ABFqP->call($this, $HNFqH);
            $this->QxLu3->put($O9gvw, $this->aW0a3->get($O9gvw), ['visibility' => 'public', 'ContentType' => $T4AWF->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $jupeT) {
            Log::error("Failed to upload image to S3", ['s3Path' => $O9gvw, 'error' => $jupeT->getMessage()]);
        }
        goto EPzoe;
        kRQPh:
        $HNFqH = str_replace('.jpg', $G5Hlr, $HNFqH);
        goto dn0VL;
        EPzoe:
    }
}
