<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class JBQKHDBrqHJhX implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $InHEz) : void
    {
        goto LtUJJ;
        LtUJJ:
        $qF0aQ = JPkW9ix1EKo3T::findOrFail($InHEz);
        goto hNJMH;
        BO_cV:
        rA7hh:
        goto A_EFj;
        jpRzp:
        $this->mcvi6zkEScY($qF0aQ);
        goto BO_cV;
        hNJMH:
        if ($qF0aQ->width() > 0 && $qF0aQ->height() > 0) {
            goto rA7hh;
        }
        goto jpRzp;
        A_EFj:
    }
    private function mcvi6zkEScY(JPkW9ix1EKo3T $Q8IO8) : void
    {
        goto m0s_a;
        xl4Bb:
        $Lp_UD = $P82oP->getVideoStream();
        goto Tcex4;
        m0s_a:
        $rtMM2 = $Q8IO8->getView();
        goto wtWcM;
        Tcex4:
        $bY3x7 = $Lp_UD->getDimensions();
        goto sBv2v;
        sBv2v:
        $Q8IO8->update(['duration' => $P82oP->getDurationInSeconds(), 'resolution' => $bY3x7->getWidth() . 'x' . $bY3x7->getHeight(), 'fps' => $Lp_UD->get('r_frame_rate') ?? 30]);
        goto ioHrN;
        wtWcM:
        $P82oP = FFMpeg::fromDisk($rtMM2['path'])->open($Q8IO8->getAttribute('filename'));
        goto xl4Bb;
        ioHrN:
    }
}
