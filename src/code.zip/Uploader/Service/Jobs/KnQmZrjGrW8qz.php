<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
class KnQmZrjGrW8qz implements BlurVideoJobInterface
{
    const VyMMp = 15;
    const WkNZV = 500;
    const HuM8M = 500;
    private $z59AQ;
    private $W_Kti;
    private $kxBLk;
    public function __construct($fbqBq, $agzKA, $dgfeu)
    {
        goto qk2Du;
        qk2Du:
        $this->kxBLk = $dgfeu;
        goto ityWQ;
        p64LI:
        $this->z59AQ = $fbqBq;
        goto fWiQp;
        ityWQ:
        $this->W_Kti = $agzKA;
        goto p64LI;
        fWiQp:
    }
    public function blur(string $y06DH) : void
    {
        goto u_rxE;
        OU9nT:
        throw new \Exception('Failed to set final permissions on image file: ' . $yXh7z);
        goto MzjZY;
        u_rxE:
        Log::info("Blurring for video", ['videoID' => $y06DH]);
        goto iqeCt;
        I9WRx:
        $Lk8zo = GXtnGiMmIPEIc::findOrFail($y06DH);
        goto R1Oxu;
        iqeCt:
        ini_set('memory_limit', '-1');
        goto I9WRx;
        U8y4U:
        \Log::warning('Failed to set final permissions on image file: ' . $yXh7z);
        goto OU9nT;
        MzjZY:
        rl4_W:
        goto YByBz;
        CkNk5:
        Lt032:
        goto ItNnP;
        bR54q:
        $oJEk8 = $this->mtdKgh29brn($Lk8zo);
        goto rqooL;
        j1fqR:
        if (chmod($yXh7z, 0664)) {
            goto rl4_W;
        }
        goto U8y4U;
        wUFLv:
        $P2AJQ->blur(self::VyMMp);
        goto bR54q;
        Gt0K0:
        $P2AJQ->save($yXh7z);
        goto Fd7Wo;
        RZoUR:
        $pUtvf = $P2AJQ->width() / $P2AJQ->height();
        goto uIY3G;
        BrjzL:
        $this->kxBLk->put($Lk8zo->getAttribute('thumbnail'), $this->W_Kti->get($Lk8zo->getAttribute('thumbnail')));
        goto KY4hE;
        uIY3G:
        $P2AJQ->resize(self::WkNZV, self::HuM8M / $pUtvf);
        goto wUFLv;
        rqooL:
        $yXh7z = $this->kxBLk->path($oJEk8);
        goto Gt0K0;
        rMUv0:
        $P2AJQ->destroy();
        goto j1fqR;
        R1Oxu:
        if (!$Lk8zo->getAttribute('thumbnail')) {
            goto Lt032;
        }
        goto BrjzL;
        YByBz:
        $Lk8zo->update(['preview' => $oJEk8]);
        goto CkNk5;
        Fd7Wo:
        $this->W_Kti->put($oJEk8, $this->kxBLk->get($oJEk8));
        goto rMUv0;
        KY4hE:
        $P2AJQ = $this->z59AQ->call($this, $this->kxBLk->path($Lk8zo->getAttribute('thumbnail')));
        goto RZoUR;
        ItNnP:
    }
    private function mtdKgh29brn(JQSlbB9QkzzhT $Ab2Uc) : string
    {
        goto jQfY2;
        jQfY2:
        $IB9Pt = $Ab2Uc->getLocation();
        goto VEM4V;
        RAY9V:
        if ($this->kxBLk->exists($vQ3Gb)) {
            goto qrd1j;
        }
        goto QrCKW;
        CYgn_:
        qrd1j:
        goto M8oG6;
        M8oG6:
        return $vQ3Gb . $Ab2Uc->getFilename() . '.jpg';
        goto SrIIt;
        VEM4V:
        $vQ3Gb = dirname($IB9Pt) . '/preview/';
        goto RAY9V;
        QrCKW:
        $this->kxBLk->makeDirectory($vQ3Gb, 0755, true);
        goto CYgn_;
        SrIIt:
    }
}
