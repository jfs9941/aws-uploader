<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Service\Jobs\MFBwl1BTODZYU;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class IVN9EwgQzxbpT implements WatermarkTextJobInterface
{
    private $KXch8;
    private $pUKMn;
    private $wyfwp;
    private $VoF9h;
    private $hhcR1;
    public function __construct($FeIAB, $BetpK, $BQ2l1, $nQYui, $pfO_b)
    {
        goto xyEPH;
        AZBwH:
        $this->wyfwp = $pfO_b;
        goto yFA3L;
        yFA3L:
        $this->pUKMn = $BetpK;
        goto CDDGy;
        xyEPH:
        $this->KXch8 = $FeIAB;
        goto vTK0L;
        vTK0L:
        $this->VoF9h = $BQ2l1;
        goto APy4w;
        APy4w:
        $this->hhcR1 = $nQYui;
        goto AZBwH;
        CDDGy:
    }
    public function putWatermark(string $JTwN4, string $FkoJ6) : void
    {
        goto hYxhW;
        GIlPk:
        Log::info("Adding watermark text to image", ['imageId' => $JTwN4]);
        goto d2Ow2;
        krmlr:
        $iPamH = memory_get_peak_usage();
        goto GIlPk;
        d2Ow2:
        ini_set('memory_limit', '-1');
        goto hzBxV;
        hzBxV:
        try {
            goto oliXM;
            UO9Fm:
            throw new \Exception('Failed to set final permissions on image file: ' . $uMpUA);
            goto E2MDX;
            OPY_t:
            if (chmod($uMpUA, 0664)) {
                goto w3ViV;
            }
            goto j8DA4;
            oliXM:
            $a97TB = Z7LUL65CwqbbF::findOrFail($JTwN4);
            goto hNVNZ;
            hNVNZ:
            if ($this->hhcR1->exists($a97TB->getLocation())) {
                goto oSVPM;
            }
            goto zLsVV;
            U10dB:
            $this->VoF9h->put($uMpUA, $uxqi9->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto pBZSX;
            sqqYq:
            $this->me3RarFYiuf($uxqi9, $FkoJ6);
            goto U10dB;
            E2MDX:
            w3ViV:
            goto bZ867;
            qUrzm:
            return;
            goto jXvY7;
            ZVQ3P:
            $uMpUA = $this->hhcR1->path($a97TB->getLocation());
            goto ofN08;
            zLsVV:
            Log::error("Z7LUL65CwqbbF is not on local, might be deleted before put watermark", ['imageId' => $JTwN4]);
            goto qUrzm;
            jXvY7:
            oSVPM:
            goto ZVQ3P;
            pBZSX:
            unset($uxqi9);
            goto OPY_t;
            iqD2i:
            $uxqi9->orient();
            goto sqqYq;
            j8DA4:
            \Log::warning('Failed to set final permissions on image file: ' . $uMpUA);
            goto UO9Fm;
            ofN08:
            $uxqi9 = $this->KXch8->call($this, $uMpUA);
            goto iqD2i;
            bZ867:
        } catch (\Throwable $WxOB2) {
            goto rEVzG;
            rEVzG:
            if (!$WxOB2 instanceof ModelNotFoundException) {
                goto JzaAY;
            }
            goto C2_Oy;
            KoXZr:
            Log::error("Z7LUL65CwqbbF is not readable", ['imageId' => $JTwN4, 'error' => $WxOB2->getMessage()]);
            goto JoKm7;
            JspAh:
            JzaAY:
            goto KoXZr;
            JlOdQ:
            return;
            goto JspAh;
            C2_Oy:
            Log::info("Z7LUL65CwqbbF has been deleted, discard it", ['imageId' => $JTwN4]);
            goto JlOdQ;
            JoKm7:
        } finally {
            $ZCyht = microtime(true);
            $n3g31 = memory_get_usage();
            $b0QCz = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $JTwN4, 'execution_time_sec' => $ZCyht - $yvtjt, 'memory_usage_mb' => ($n3g31 - $cH3VP) / 1024 / 1024, 'peak_memory_usage_mb' => ($b0QCz - $iPamH) / 1024 / 1024]);
        }
        goto qEcjJ;
        ZflYP:
        $cH3VP = memory_get_usage();
        goto krmlr;
        hYxhW:
        $yvtjt = microtime(true);
        goto ZflYP;
        qEcjJ:
    }
    private function me3RarFYiuf($uxqi9, $FkoJ6) : void
    {
        goto UQngz;
        eK7sq:
        $fjHjk = $this->KXch8->call($this, $this->hhcR1->path($tkIsk));
        goto plPlU;
        UQngz:
        $SAWrT = $uxqi9->width();
        goto llShi;
        llShi:
        $rnPww = $uxqi9->height();
        goto SNq39;
        UDXHY:
        $this->hhcR1->put($tkIsk, $this->VoF9h->get($tkIsk));
        goto eK7sq;
        n7eox:
        $tkIsk = $EeySv->mvALyMgg8ca($SAWrT, $rnPww, $FkoJ6, true);
        goto UDXHY;
        SNq39:
        $EeySv = new MFBwl1BTODZYU($this->pUKMn, $this->wyfwp, $this->VoF9h, $this->hhcR1);
        goto n7eox;
        plPlU:
        $uxqi9->place($fjHjk, 'top-left', 0, 0, 30);
        goto RPR5a;
        RPR5a:
    }
}
