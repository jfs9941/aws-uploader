<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Illuminate\Support\Facades\Log;
class ODrXS1LMYXHij implements DownloadToLocalJobInterface
{
    private $DksH2;
    private $JFHzD;
    public function __construct($l4Drs, $NVuHg)
    {
        $this->DksH2 = $l4Drs;
        $this->JFHzD = $NVuHg;
    }
    public function download(string $EmnXX) : void
    {
        goto K6tLn;
        EHgfG:
        Log::info("Start download file to local", ['fileId' => $EmnXX, 'filename' => $cNpq7->getLocation()]);
        goto pqiMD;
        AN4Ph:
        return;
        goto uYEQk;
        pqiMD:
        if (!$this->JFHzD->exists($cNpq7->getLocation())) {
            goto QsD3C;
        }
        goto AN4Ph;
        K6tLn:
        $cNpq7 = Q48IcpSr3UpAT::findOrFail($EmnXX);
        goto EHgfG;
        uYEQk:
        QsD3C:
        goto R3Vku;
        R3Vku:
        $this->JFHzD->put($cNpq7->getLocation(), $this->DksH2->get($cNpq7->getLocation()));
        goto VyeMz;
        VyeMz:
    }
}
