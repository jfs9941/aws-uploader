<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class W1JnoTI1C0JPA implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $GMwD5) : void
    {
        goto qA0Ev;
        bIei3:
        if ($UUt0Z->width() > 0 && $UUt0Z->height() > 0) {
            goto CGcVE;
        }
        goto o4Qtz;
        o4Qtz:
        $this->m4hMDPauo0O($UUt0Z);
        goto gPnYx;
        gPnYx:
        CGcVE:
        goto hzN0r;
        qA0Ev:
        $UUt0Z = RhdJGUi8FOLBJ::findOrFail($GMwD5);
        goto bIei3;
        hzN0r:
    }
    private function m4hMDPauo0O(RhdJGUi8FOLBJ $WFvTF) : void
    {
        goto syvZB;
        ErZXm:
        $SoOrH = $pCzkY->getDimensions();
        goto ws9sW;
        bdoSL:
        $pCzkY = $jBims->getVideoStream();
        goto ErZXm;
        syvZB:
        $cYXE_ = $WFvTF->getView();
        goto qgVtW;
        qgVtW:
        $jBims = FFMpeg::fromDisk($cYXE_['path'])->open($WFvTF->getAttribute('filename'));
        goto bdoSL;
        ws9sW:
        $WFvTF->update(['duration' => $jBims->getDurationInSeconds(), 'resolution' => $SoOrH->getWidth() . 'x' . $SoOrH->getHeight(), 'fps' => $pCzkY->get('r_frame_rate') ?? 30]);
        goto HM8S2;
        HM8S2:
    }
}
