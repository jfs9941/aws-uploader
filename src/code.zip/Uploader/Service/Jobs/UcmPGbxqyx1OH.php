<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Service\Jobs\MwudJaX1iKlH8;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class UcmPGbxqyx1OH implements WatermarkTextJobInterface
{
    private $o4nAt;
    private $z5gsb;
    private $o2VY1;
    private $m2kWg;
    private $BX0zD;
    public function __construct($wpWQD, $ydoZC, $Npup8, $MKJ1D, $v05s8)
    {
        goto CALRO;
        CALRO:
        $this->o4nAt = $wpWQD;
        goto vroCa;
        Dw2_J:
        $this->o2VY1 = $v05s8;
        goto yjrkT;
        yjrkT:
        $this->z5gsb = $ydoZC;
        goto Ewjaq;
        vroCa:
        $this->m2kWg = $Npup8;
        goto rwTDP;
        rwTDP:
        $this->BX0zD = $MKJ1D;
        goto Dw2_J;
        Ewjaq:
    }
    public function putWatermark(string $Brk87, string $li4hO) : void
    {
        goto x0fou;
        RxuVY:
        $NzcES = memory_get_peak_usage();
        goto vxEmK;
        oTXrF:
        ini_set('memory_limit', '-1');
        goto pNtjt;
        vxEmK:
        Log::info("Adding watermark text to image", ['imageId' => $Brk87]);
        goto oTXrF;
        MzhhP:
        $aPZAx = memory_get_usage();
        goto RxuVY;
        pNtjt:
        try {
            goto pFq98;
            pFq98:
            $Kc1eZ = OjvWwjWRqBzIO::findOrFail($Brk87);
            goto Z52ne;
            G6XsP:
            iQXQ_:
            goto kzGW1;
            MSoRx:
            return;
            goto fGNw7;
            fwc5M:
            unset($EusLJ);
            goto b01qb;
            KS7Ot:
            $this->mflHR82t1A7($EusLJ, $li4hO);
            goto zlMQP;
            Z52ne:
            if ($this->BX0zD->exists($Kc1eZ->getLocation())) {
                goto fqPP_;
            }
            goto vgOWa;
            zlMQP:
            $this->m2kWg->put($F0ycc, $EusLJ->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto fwc5M;
            I2Wnr:
            $EusLJ->orient();
            goto KS7Ot;
            thBuh:
            throw new \Exception('Failed to set final permissions on image file: ' . $F0ycc);
            goto G6XsP;
            vgOWa:
            Log::error("OjvWwjWRqBzIO is not on local, might be deleted before put watermark", ['imageId' => $Brk87]);
            goto MSoRx;
            b01qb:
            if (chmod($F0ycc, 0664)) {
                goto iQXQ_;
            }
            goto k8iDF;
            zrNaW:
            $F0ycc = $this->BX0zD->path($Kc1eZ->getLocation());
            goto LeMLn;
            fGNw7:
            fqPP_:
            goto zrNaW;
            LeMLn:
            $EusLJ = $this->o4nAt->call($this, $F0ycc);
            goto I2Wnr;
            k8iDF:
            \Log::warning('Failed to set final permissions on image file: ' . $F0ycc);
            goto thBuh;
            kzGW1:
        } catch (\Throwable $CcqnY) {
            goto AbJfQ;
            jFB6q:
            Log::info("OjvWwjWRqBzIO has been deleted, discard it", ['imageId' => $Brk87]);
            goto fJLNd;
            pRTkn:
            Log::error("OjvWwjWRqBzIO is not readable", ['imageId' => $Brk87, 'error' => $CcqnY->getMessage()]);
            goto TM7h8;
            fJLNd:
            return;
            goto c3G2u;
            c3G2u:
            i58ge:
            goto pRTkn;
            AbJfQ:
            if (!$CcqnY instanceof ModelNotFoundException) {
                goto i58ge;
            }
            goto jFB6q;
            TM7h8:
        } finally {
            $Gy4_y = microtime(true);
            $aEdXV = memory_get_usage();
            $pE3ho = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $Brk87, 'execution_time_sec' => $Gy4_y - $aRKLJ, 'memory_usage_mb' => ($aEdXV - $aPZAx) / 1024 / 1024, 'peak_memory_usage_mb' => ($pE3ho - $NzcES) / 1024 / 1024]);
        }
        goto j0K7H;
        x0fou:
        $aRKLJ = microtime(true);
        goto MzhhP;
        j0K7H:
    }
    private function mflHR82t1A7($EusLJ, $li4hO) : void
    {
        goto FODiA;
        JFWya:
        $EusLJ->place($jA6ko, 'top-left', 0, 0, 30);
        goto jz1X8;
        DdDrE:
        $this->BX0zD->put($qAtvn, $this->m2kWg->get($qAtvn));
        goto ncZGC;
        FODiA:
        $p9c0Q = $EusLJ->width();
        goto d1R7p;
        MU3dn:
        $qAtvn = $q1vwE->mljISqrPrHy($p9c0Q, $erqpi, $li4hO, true);
        goto DdDrE;
        ncZGC:
        $jA6ko = $this->o4nAt->call($this, $this->BX0zD->path($qAtvn));
        goto JFWya;
        d1R7p:
        $erqpi = $EusLJ->height();
        goto cRXS1;
        cRXS1:
        $q1vwE = new MwudJaX1iKlH8($this->z5gsb, $this->o2VY1, $this->m2kWg, $this->BX0zD);
        goto MU3dn;
        jz1X8:
    }
}
