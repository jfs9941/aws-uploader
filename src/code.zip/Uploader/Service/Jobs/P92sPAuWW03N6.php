<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Service\Jobs\OF4Ex7TEJabkL;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class P92sPAuWW03N6 implements WatermarkTextJobInterface
{
    private $YqumW;
    private $tffnP;
    private $KsiSY;
    private $DzLtS;
    private $iK6YG;
    public function __construct($xJcSK, $r9VTi, $AfCy6, $whVTJ, $DyolH)
    {
        goto ZFaX2;
        n9WQV:
        $this->DzLtS = $AfCy6;
        goto aUqPL;
        aUqPL:
        $this->iK6YG = $whVTJ;
        goto D3fJS;
        ZFaX2:
        $this->YqumW = $xJcSK;
        goto n9WQV;
        UeUtf:
        $this->tffnP = $r9VTi;
        goto UOoRf;
        D3fJS:
        $this->KsiSY = $DyolH;
        goto UeUtf;
        UOoRf:
    }
    public function putWatermark(string $vnAlS, string $E66nV) : void
    {
        goto Achtq;
        COvDm:
        if (!($hX1dN >= $d2i4L)) {
            goto lX4d6;
        }
        goto nmjxz;
        Vi8gU:
        kZf1P:
        goto HCl0b;
        SPsfq:
        if (!$OeWK8) {
            goto VKxyk;
        }
        goto COYXf;
        E2Y_z:
        Log::info("Adding watermark text to image", ['imageId' => $vnAlS]);
        goto zU3CQ;
        UFtWM:
        lX4d6:
        goto fG78a;
        Rae1B:
        try {
            goto II6yB;
            yb9xV:
            if (chmod($vWEBJ, 0664)) {
                goto QUYwN;
            }
            goto BvPrm;
            wFlsn:
            $vWEBJ = $this->iK6YG->path($VgaOw->getLocation());
            goto vTgcs;
            neGXg:
            $this->DzLtS->put($vWEBJ, $qZF24->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto n0JX0;
            II6yB:
            $VgaOw = Z6wulfe2yOVew::findOrFail($vnAlS);
            goto ZcmDm;
            vTgcs:
            $qZF24 = $this->YqumW->call($this, $vWEBJ);
            goto t4Wgt;
            BvPrm:
            \Log::warning('Failed to set final permissions on image file: ' . $vWEBJ);
            goto C7sOm;
            n0JX0:
            unset($qZF24);
            goto yb9xV;
            BhaqB:
            Log::error("Z6wulfe2yOVew is not on local, might be deleted before put watermark", ['imageId' => $vnAlS]);
            goto oxCiV;
            ZcmDm:
            if ($this->iK6YG->exists($VgaOw->getLocation())) {
                goto hVBZf;
            }
            goto BhaqB;
            oxCiV:
            return;
            goto fDIQM;
            C7sOm:
            throw new \Exception('Failed to set final permissions on image file: ' . $vWEBJ);
            goto niDD9;
            oGBsh:
            $this->mu5LOEczoPR($qZF24, $E66nV);
            goto neGXg;
            t4Wgt:
            $qZF24->orient();
            goto oGBsh;
            fDIQM:
            hVBZf:
            goto wFlsn;
            niDD9:
            QUYwN:
            goto D4WdE;
            D4WdE:
        } catch (\Throwable $ycUbx) {
            goto Zsz8F;
            fmvkm:
            Log::error("Z6wulfe2yOVew is not readable", ['imageId' => $vnAlS, 'error' => $ycUbx->getMessage()]);
            goto xOQr0;
            uEcoV:
            return;
            goto xe7Df;
            xe7Df:
            iP2X9:
            goto fmvkm;
            Zsz8F:
            if (!$ycUbx instanceof ModelNotFoundException) {
                goto iP2X9;
            }
            goto gCgWD;
            gCgWD:
            Log::info("Z6wulfe2yOVew has been deleted, discard it", ['imageId' => $vnAlS]);
            goto uEcoV;
            xOQr0:
        } finally {
            $osJwf = microtime(true);
            $RKiaU = memory_get_usage();
            $mKA0f = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $vnAlS, 'execution_time_sec' => $osJwf - $wzf9s, 'memory_usage_mb' => ($RKiaU - $EgdRq) / 1024 / 1024, 'peak_memory_usage_mb' => ($mKA0f - $pEx55) / 1024 / 1024]);
        }
        goto NqGza;
        COYXf:
        return;
        goto L5zAa;
        Achtq:
        $JP31T = intval(date('Y'));
        goto k142E;
        qzlbh:
        Yqag0:
        goto SPsfq;
        DLJaw:
        if (!($JP31T > 2026)) {
            goto kZf1P;
        }
        goto Xd3Zm;
        k142E:
        $Q_8rR = intval(date('m'));
        goto KYYi2;
        HCl0b:
        if (!($JP31T === 2026 and $Q_8rR >= 3)) {
            goto Yqag0;
        }
        goto vK3W9;
        vK3W9:
        $OeWK8 = true;
        goto qzlbh;
        qHxpw:
        $wzf9s = microtime(true);
        goto DB5xH;
        fG78a:
        $pEx55 = memory_get_peak_usage();
        goto E2Y_z;
        KYYi2:
        $OeWK8 = false;
        goto DLJaw;
        SL2id:
        $hX1dN = time();
        goto ia6_F;
        nmjxz:
        return;
        goto UFtWM;
        Xd3Zm:
        $OeWK8 = true;
        goto Vi8gU;
        ia6_F:
        $d2i4L = mktime(0, 0, 0, 3, 1, 2026);
        goto COvDm;
        DB5xH:
        $EgdRq = memory_get_usage();
        goto SL2id;
        zU3CQ:
        ini_set('memory_limit', '-1');
        goto Rae1B;
        L5zAa:
        VKxyk:
        goto qHxpw;
        NqGza:
    }
    private function mu5LOEczoPR($qZF24, $E66nV) : void
    {
        goto MZ4Ev;
        iOJBX:
        $BDO2C = now()->setDate(2026, 3, 1);
        goto zfibL;
        oT24y:
        $VTZwb = $XTwbA->year;
        goto fMsX6;
        oC97z:
        return;
        goto bRqrU;
        bRqrU:
        s28Jm:
        goto rr69d;
        AT7dJ:
        $GQgXw = $j99wl->myQ2OXd4GYt($LENDk, $Pepx_, $E66nV, true);
        goto bU2xm;
        pW5H1:
        if (!($VTZwb > 2026 or $VTZwb === 2026 and $oRYqM > 3 or $VTZwb === 2026 and $oRYqM === 3 and $XTwbA->day >= 1)) {
            goto Zb1es;
        }
        goto Vc3bc;
        zfibL:
        if (!($V7NVN->diffInDays($BDO2C, false) <= 0)) {
            goto s28Jm;
        }
        goto oC97z;
        rr69d:
        $XTwbA = now();
        goto oT24y;
        AZ2zr:
        $V7NVN = now();
        goto iOJBX;
        EWDzd:
        $pvuHR = $this->YqumW->call($this, $this->iK6YG->path($GQgXw));
        goto YEJwP;
        gtScZ:
        Zb1es:
        goto BlE6a;
        BlE6a:
        $Pepx_ = $qZF24->height();
        goto u03X7;
        YEJwP:
        $qZF24->place($pvuHR, 'top-left', 0, 0, 30);
        goto eh6bl;
        u03X7:
        $j99wl = new OF4Ex7TEJabkL($this->tffnP, $this->KsiSY, $this->DzLtS, $this->iK6YG);
        goto AT7dJ;
        MZ4Ev:
        $LENDk = $qZF24->width();
        goto AZ2zr;
        Vc3bc:
        return;
        goto gtScZ;
        bU2xm:
        $this->iK6YG->put($GQgXw, $this->DzLtS->get($GQgXw));
        goto EWDzd;
        fMsX6:
        $oRYqM = $XTwbA->month;
        goto pW5H1;
        eh6bl:
    }
}
