<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class Jac58S4hxlfDF
{
    private $WZn6v;
    private $uQsMS;
    public function __construct(int $rTjtg, int $hiIuM)
    {
        goto d_Ku9;
        b7vRv:
        $this->uQsMS = $hiIuM;
        goto JxYIG;
        SZuvJ:
        QIex0:
        goto ZaylS;
        P8TQW:
        if (!($hiIuM <= 0)) {
            goto QIex0;
        }
        goto iTmwB;
        ZaylS:
        $this->WZn6v = $rTjtg;
        goto b7vRv;
        aYM8b:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto Ng9PL;
        Ng9PL:
        RVCA4:
        goto P8TQW;
        d_Ku9:
        if (!($rTjtg <= 0)) {
            goto RVCA4;
        }
        goto aYM8b;
        iTmwB:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto SZuvJ;
        JxYIG:
    }
    private static function m8cfOMqVbAs($gp9pu, string $TEdr1 = 'floor') : int
    {
        goto WG09W;
        NjZB8:
        RE8bN:
        goto ddH9B;
        XowML:
        return $gp9pu;
        goto i1udC;
        tJ07a:
        return (int) $gp9pu;
        goto NjZB8;
        V73jd:
        if (!(is_float($gp9pu) && $gp9pu == floor($gp9pu) && (int) $gp9pu % 2 === 0)) {
            goto RE8bN;
        }
        goto tJ07a;
        oc7PC:
        zju8h:
        goto ZVRJ4;
        ddH9B:
        switch (strtolower($TEdr1)) {
            case 'ceil':
                return (int) (ceil($gp9pu / 2) * 2);
            case 'round':
                return (int) (round($gp9pu / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($gp9pu / 2) * 2);
        }
        goto oc7PC;
        WG09W:
        if (!(is_int($gp9pu) && $gp9pu % 2 === 0)) {
            goto Oq3eg;
        }
        goto XowML;
        ZVRJ4:
        QsAHq:
        goto UGL17;
        i1udC:
        Oq3eg:
        goto V73jd;
        UGL17:
    }
    public function mMQ0ymsGfeo(string $CfVcY = 'floor') : array
    {
        goto vvFFA;
        fA_3J:
        $QqXOg = self::m8cfOMqVbAs(round($pGmdc), $CfVcY);
        goto JDLPY;
        YaulJ:
        $vtJGd = $QqXOg / $this->uQsMS;
        goto mfPTN;
        jPDPu:
        $n5Kyt = self::m8cfOMqVbAs(round($L8f6m), $CfVcY);
        goto ZiFHo;
        KYqaA:
        $pGmdc = $this->uQsMS * $vtJGd;
        goto fA_3J;
        Cz8u5:
        $vtJGd = $n5Kyt / $this->WZn6v;
        goto KYqaA;
        vvFFA:
        $cmJsO = 1080;
        goto eeIOn;
        IwRZL:
        $QqXOg = $cmJsO;
        goto YaulJ;
        dyn8W:
        if ($this->WZn6v >= $this->uQsMS) {
            goto Ukzn2;
        }
        goto lx2G8;
        d6MU8:
        return ['width' => $n5Kyt, 'height' => $QqXOg];
        goto UsTC6;
        xrX_Z:
        $n5Kyt = 2;
        goto WTsPy;
        o5voX:
        if (!($n5Kyt < 2)) {
            goto vDlwG;
        }
        goto xrX_Z;
        Et1o6:
        $QqXOg = 0;
        goto dyn8W;
        jbjdc:
        S6MKA:
        goto d6MU8;
        mfPTN:
        $L8f6m = $this->WZn6v * $vtJGd;
        goto jPDPu;
        JDLPY:
        goto vt3qP;
        goto VfMxa;
        fLz4J:
        if (!($QqXOg < 2)) {
            goto S6MKA;
        }
        goto rpl5B;
        lx2G8:
        $n5Kyt = $cmJsO;
        goto Cz8u5;
        eeIOn:
        $n5Kyt = 0;
        goto Et1o6;
        VfMxa:
        Ukzn2:
        goto IwRZL;
        WTsPy:
        vDlwG:
        goto fLz4J;
        rpl5B:
        $QqXOg = 2;
        goto jbjdc;
        ZiFHo:
        vt3qP:
        goto o5voX;
        UsTC6:
    }
}
