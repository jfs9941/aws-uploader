<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
class Pnv2QYDRYqXfq implements BlurJobInterface
{
    const t_7Fw = 15;
    const YWeMK = 500;
    const dgUo2 = 500;
    private $z0km_;
    private $zbU8n;
    private $ofZvx;
    public function __construct($BSNlm, $Efy84, $suNmN)
    {
        goto klkrB;
        zCkPY:
        $this->zbU8n = $Efy84;
        goto eTfwS;
        klkrB:
        $this->ofZvx = $suNmN;
        goto zCkPY;
        eTfwS:
        $this->z0km_ = $BSNlm;
        goto QIX70;
        QIX70:
    }
    public function blur(string $N2oAf) : void
    {
        goto tQUn2;
        cgVcG:
        throw new \Exception('Failed to set final permissions on image file: ' . $qelwB);
        goto QfJj2;
        SjlgP:
        $RxSHk = $this->z0km_->call($this, $this->ofZvx->path($aSnHH->getLocation()));
        goto FodEI;
        hR7Iw:
        \Log::warning('Failed to set final permissions on image file: ' . $qelwB);
        goto cgVcG;
        KPuT4:
        unset($RxSHk);
        goto I62HH;
        uzI0a:
        $aSnHH->update(['preview' => $M3UnW]);
        goto xfsTm;
        Abj6l:
        $RxSHk->blur(self::t_7Fw);
        goto tWivk;
        tWivk:
        $M3UnW = $this->ml6PXtGY4oU($aSnHH);
        goto u_NKD;
        u_NKD:
        $qelwB = $this->zbU8n->put($M3UnW, $RxSHk->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto KPuT4;
        FodEI:
        $yzNoO = $RxSHk->width() / $RxSHk->height();
        goto s3vGR;
        I62HH:
        if (chmod($qelwB, 0664)) {
            goto hVcMI;
        }
        goto hR7Iw;
        lhQrK:
        if (!($aSnHH->Sc6J1 == I5kpK7wkbRQvu::S3 && !$this->ofZvx->exists($aSnHH->filename))) {
            goto PyJHR;
        }
        goto DQrQ8;
        DQrQ8:
        $EUrof = $this->zbU8n->get($aSnHH->filename);
        goto Ou4MT;
        s3vGR:
        $RxSHk->resize(self::YWeMK, self::dgUo2 / $yzNoO);
        goto Abj6l;
        tQUn2:
        $aSnHH = JMa7GBaLcnq3D::findOrFail($N2oAf);
        goto xjr9z;
        xjr9z:
        ini_set('memory_limit', '-1');
        goto lhQrK;
        Ou4MT:
        $this->ofZvx->put($aSnHH->filename, $EUrof);
        goto f8T9H;
        f8T9H:
        PyJHR:
        goto SjlgP;
        QfJj2:
        hVcMI:
        goto uzI0a;
        xfsTm:
    }
    private function ml6PXtGY4oU($OagJi) : string
    {
        goto pwp3b;
        I_PMk:
        if ($this->ofZvx->exists($TQLOY)) {
            goto ATJw0;
        }
        goto zY2K8;
        pwp3b:
        $vRakW = $OagJi->getLocation();
        goto kLQK5;
        wTslx:
        return $TQLOY . $OagJi->getFilename() . '.jpg';
        goto fsrNn;
        OP8uA:
        ATJw0:
        goto wTslx;
        zY2K8:
        $this->ofZvx->makeDirectory($TQLOY, 0755, true);
        goto OP8uA;
        kLQK5:
        $TQLOY = dirname($vRakW) . '/preview/';
        goto I_PMk;
        fsrNn:
    }
}
