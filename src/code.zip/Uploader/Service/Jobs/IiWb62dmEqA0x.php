<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class IiWb62dmEqA0x implements GenerateThumbnailForVideoInterface
{
    private $OZiHs;
    public function __construct($DbOCd)
    {
        $this->OZiHs = $DbOCd;
    }
    public function generate(string $J_scC) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $J_scC);
        $this->OZiHs->createThumbnail($J_scC);
    }
}
