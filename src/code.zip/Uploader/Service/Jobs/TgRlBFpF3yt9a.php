<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

class TgRlBFpF3yt9a
{
    private $kkvUd;
    private $s28PC;
    private $Aj6QZ;
    private $SiK3b;
    public function __construct($UOGFe, $vimS1, $SaekO, $eX8wo)
    {
        goto qd2Pv;
        QR7JT:
        $this->Aj6QZ = $SaekO;
        goto IFuav;
        qd2Pv:
        $this->s28PC = $vimS1;
        goto QR7JT;
        tz6Fo:
        $this->kkvUd = $UOGFe;
        goto HiPYd;
        IFuav:
        $this->SiK3b = $eX8wo;
        goto tz6Fo;
        HiPYd:
    }
    public function m8dbiOiHCTI(?int $Lu5LP, ?int $IPfYY, string $XT0rv, bool $NLH9s = false) : string
    {
        goto MD4Ol;
        E9bGC:
        $fdqWg = $this->mKWVGevH9Ka($TXR_X, $Lu5LP, $IPfYY, $XDQ6b, $tEHwY);
        goto ntCkv;
        XVyX4:
        VQycS:
        goto wpzD3;
        YM9uV:
        $XYd14 = $Lu5LP - $XDQ6b;
        goto L8C0U;
        DezC3:
        return $NLH9s ? $fdqWg : $this->Aj6QZ->url($fdqWg);
        goto DgVJ3;
        ntCkv:
        if (!$this->Aj6QZ->exists($fdqWg)) {
            goto vVZq3;
        }
        goto bgVHj;
        L8C0U:
        $SN5Nu = (int) ($XYd14 / 80);
        goto RF4WJ;
        b5vDR:
        $this->SiK3b->put($fdqWg, $ab1g_->stream('png'));
        goto x2ycR;
        Wh2Do:
        if (!($Lu5LP > 1500)) {
            goto VQycS;
        }
        goto tguyH;
        MD4Ol:
        if (!($Lu5LP === null || $IPfYY === null)) {
            goto lcw90;
        }
        goto Ln96G;
        Ln96G:
        throw new \RuntimeException("YdClVYDRbSDMR dimensions are not available.");
        goto jeZWM;
        bgVHj:
        return $NLH9s ? $fdqWg : $this->Aj6QZ->url($fdqWg);
        goto xqAdL;
        xqAdL:
        vVZq3:
        goto KezJ2;
        tguyH:
        $XYd14 -= $SN5Nu * 0.4;
        goto XVyX4;
        iPMmg:
        $EmpLO = 0.1;
        goto qoVp8;
        qoVp8:
        list($tEHwY, $XDQ6b, $TXR_X) = $this->mfhSuSObhBn($XT0rv, $Lu5LP, $EmpLO, (float) $Lu5LP / $IPfYY);
        goto E9bGC;
        jeZWM:
        lcw90:
        goto iPMmg;
        wpzD3:
        $pZ_X9 = $IPfYY - $tEHwY - 10;
        goto eXucg;
        KezJ2:
        $ab1g_ = $this->kkvUd->call($this, $Lu5LP, $IPfYY);
        goto YM9uV;
        RF4WJ:
        $XYd14 -= $SN5Nu;
        goto Wh2Do;
        x2ycR:
        $this->Aj6QZ->put($fdqWg, $ab1g_->stream('png'));
        goto DezC3;
        eXucg:
        $ab1g_->text($TXR_X, $XYd14, (int) $pZ_X9, function ($sUXb0) use($tEHwY) {
            goto IDdxp;
            hxdHM:
            $sUXb0->color([185, 185, 185, 1]);
            goto qAtuW;
            jbs2J:
            $sUXb0->size(max($XQB6F, 1));
            goto hxdHM;
            fPI93:
            $sUXb0->align('middle');
            goto RCCIz;
            qAtuW:
            $sUXb0->valign('middle');
            goto fPI93;
            IDdxp:
            $sUXb0->file(Nlc3D($this->s28PC));
            goto NktX7;
            NktX7:
            $XQB6F = (int) ($tEHwY * 1.2);
            goto jbs2J;
            RCCIz:
        });
        goto b5vDR;
        DgVJ3:
    }
    private function mKWVGevH9Ka(string $XT0rv, int $Lu5LP, int $IPfYY, int $PfphH, int $xbj0t) : string
    {
        $CjsuS = ltrim($XT0rv, '@');
        return "v2/watermark/{$CjsuS}/{$Lu5LP}x{$IPfYY}_{$PfphH}x{$xbj0t}/text_watermark.png";
    }
    private function mfhSuSObhBn($XT0rv, int $Lu5LP, float $X556c, float $JA9pQ) : array
    {
        goto CIb0u;
        bM528:
        $KnpZJ = $XDQ6b / (strlen($TXR_X) * 0.8);
        goto VK9Rr;
        VK9Rr:
        return [(int) $KnpZJ, $KnpZJ * strlen($TXR_X) / 1.8, $TXR_X];
        goto j7nh6;
        cUIfD:
        $KnpZJ = 1 / $JA9pQ * $XDQ6b / strlen($TXR_X);
        goto No0FN;
        j7nh6:
        l2sOj:
        goto cUIfD;
        B3bAq:
        $XDQ6b = (int) ($Lu5LP * $X556c);
        goto K7kge;
        K7kge:
        if (!($JA9pQ > 1)) {
            goto l2sOj;
        }
        goto bM528;
        No0FN:
        return [(int) $KnpZJ, $XDQ6b, $TXR_X];
        goto Y2cuv;
        CIb0u:
        $TXR_X = '@' . $XT0rv;
        goto B3bAq;
        Y2cuv:
    }
}
