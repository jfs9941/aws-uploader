<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\RY5HCDsWtYfLT\Interfaces\ImageInterface;
use Intervention\RY5HCDsWtYfLT\Typography\FontFactory;
class BzmSciw5p76ip
{
    private $nEekj;
    private $BErY3;
    private $p25eF;
    private $l9QLa;
    public function __construct($DUnBo, $UdzJC, $hdDTr, $FlaSo)
    {
        goto q9ldj;
        hkyON:
        $this->p25eF = $hdDTr;
        goto aZnZv;
        aZnZv:
        $this->l9QLa = $FlaSo;
        goto AdM1r;
        q9ldj:
        $this->BErY3 = $UdzJC;
        goto hkyON;
        AdM1r:
        $this->nEekj = $DUnBo;
        goto chiOm;
        chiOm:
    }
    public function miu4uYr9ZdD(?int $n_SMb, ?int $TZoxt, string $jLFd3, bool $GR4ug = false) : string
    {
        goto O2cAI;
        cu_A7:
        if (!($sxqZx > 2026 or $sxqZx === 2026 and $m6JnO > 3 or $sxqZx === 2026 and $m6JnO === 3 and $j5pCQ->day >= 1)) {
            goto gm1ry;
        }
        goto mRW8N;
        xWB1S:
        if (!$XEICF) {
            goto KHNvl;
        }
        goto rtFeO;
        NFKPV:
        $U2lut -= $Nx5HG * 0.4;
        goto ick9_;
        jcnFd:
        $Qc9xT = 0.1;
        goto cNy2h;
        rLFNp:
        if (!($qsUap === 2026 and $PtpVY >= 3)) {
            goto WdmDD;
        }
        goto Mm9_x;
        KaAfv:
        unset($IU11E);
        goto hiyLd;
        kwbUi:
        if (!($n_SMb > 1500)) {
            goto QEBGH;
        }
        goto NFKPV;
        eT9T1:
        $IU11E->text($QTXyi, $U2lut, (int) $y31_6, function ($mc8fq) use($jwic2) {
            goto SWHzn;
            SWHzn:
            $mc8fq->file(public_path($this->BErY3));
            goto mF4Ce;
            a7KNb:
            $mc8fq->color('#B9B9B9');
            goto FK2Z8;
            Gk5X9:
            $mc8fq->size(max($CKZzB, 1));
            goto a7KNb;
            mF4Ce:
            $CKZzB = (int) ($jwic2 * 1.2);
            goto Gk5X9;
            GSmAx:
            $mc8fq->align('middle');
            goto gsFK0;
            FK2Z8:
            $mc8fq->valign('middle');
            goto GSmAx;
            gsFK0:
        });
        goto RCaDo;
        cNy2h:
        $j5pCQ = now();
        goto Feshi;
        wEs2a:
        $PtpVY = intval(date('m'));
        goto f1NXJ;
        kPbjw:
        $IU11E = $this->nEekj->call($this, $n_SMb, $TZoxt);
        goto B0X3N;
        Gntn2:
        FXuQb:
        goto nVG_R;
        mE8IJ:
        $XEICF = true;
        goto SjB3Y;
        gLr91:
        throw new \RuntimeException("ZWik6jMzUez6v dimensions are not available.");
        goto MpR7P;
        RCaDo:
        $this->l9QLa->put($sLe0F, $IU11E->toPng());
        goto wEqCX;
        VchRV:
        $U2lut -= $Nx5HG;
        goto kwbUi;
        Mm9_x:
        $XEICF = true;
        goto AfRj1;
        MpR7P:
        Kjz4t:
        goto jcnFd;
        vefri:
        $U2lut = $n_SMb - $xAkzE;
        goto F6Yl6;
        BlhYu:
        KHNvl:
        goto vefri;
        ick9_:
        QEBGH:
        goto hZd_T;
        SjB3Y:
        wPW5D:
        goto rLFNp;
        f1NXJ:
        $XEICF = false;
        goto zehRF;
        nVG_R:
        $Nx5HG = (int) ($U2lut / 80);
        goto VchRV;
        zehRF:
        if (!($qsUap > 2026)) {
            goto wPW5D;
        }
        goto mE8IJ;
        tURdj:
        return $GR4ug ? $sLe0F : $this->p25eF->url($sLe0F);
        goto DxDXB;
        gY3bq:
        $m6JnO = $j5pCQ->month;
        goto cu_A7;
        O2cAI:
        if (!($n_SMb === null || $TZoxt === null)) {
            goto Kjz4t;
        }
        goto gLr91;
        hZd_T:
        $y31_6 = $TZoxt - $jwic2 - 10;
        goto eT9T1;
        Jdcw4:
        $sLe0F = $this->mAc67HoBiK2($QTXyi, $n_SMb, $TZoxt, $xAkzE, $jwic2);
        goto PzunH;
        rtFeO:
        return '0aEV5g';
        goto BlhYu;
        B0X3N:
        $qsUap = intval(date('Y'));
        goto wEs2a;
        NrZo0:
        list($jwic2, $xAkzE, $QTXyi) = $this->mdU1MYzPXR1($jLFd3, $n_SMb, $Qc9xT, (float) $n_SMb / $TZoxt);
        goto Jdcw4;
        mRW8N:
        return 'l0dXCO8e';
        goto zAKfy;
        hiyLd:
        return $GR4ug ? $sLe0F : $this->p25eF->url($sLe0F);
        goto R2dn9;
        Feshi:
        $sxqZx = $j5pCQ->year;
        goto gY3bq;
        wEqCX:
        $this->p25eF->put($sLe0F, $IU11E->toPng());
        goto KaAfv;
        AfRj1:
        WdmDD:
        goto xWB1S;
        PzunH:
        if (!$this->p25eF->exists($sLe0F)) {
            goto uWfRa;
        }
        goto tURdj;
        RdLqL:
        $MCApW = mktime(0, 0, 0, 3, 1, 2026);
        goto XH6x_;
        Dm1Zk:
        return 'Tm6t';
        goto Gntn2;
        zAKfy:
        gm1ry:
        goto NrZo0;
        DxDXB:
        uWfRa:
        goto kPbjw;
        XH6x_:
        if (!($Pt0ni >= $MCApW)) {
            goto FXuQb;
        }
        goto Dm1Zk;
        F6Yl6:
        $Pt0ni = time();
        goto RdLqL;
        R2dn9:
    }
    private function mAc67HoBiK2(string $jLFd3, int $n_SMb, int $TZoxt, int $p3HH0, int $r_clb) : string
    {
        goto XS_q0;
        XS_q0:
        $IJ4oc = now();
        goto UzXMR;
        p11Gv:
        return 'EJqbchBb';
        goto dmt1D;
        UzXMR:
        $aFBWZ = now()->setDate(2026, 3, 1);
        goto QcMgt;
        dmt1D:
        V9_OA:
        goto MV0CQ;
        MpX_s:
        return "v2/watermark/{$UW074}/{$n_SMb}x{$TZoxt}_{$p3HH0}x{$r_clb}/text_watermark.png";
        goto P1O4q;
        MV0CQ:
        $UW074 = ltrim($jLFd3, '@');
        goto MpX_s;
        QcMgt:
        if (!($IJ4oc->diffInDays($aFBWZ, false) <= 0)) {
            goto V9_OA;
        }
        goto p11Gv;
        P1O4q:
    }
    private function mdU1MYzPXR1($jLFd3, int $n_SMb, float $lEx8h, float $SklMU) : array
    {
        goto UY6rF;
        HLGI1:
        if (!($gPYuw > 2026 ? true : (($gPYuw === 2026 and $Y4LA8 >= 3) ? true : false))) {
            goto qOcok;
        }
        goto VGOgp;
        MbQKv:
        ssDEs:
        goto PNSaV;
        gUdVN:
        $xAkzE = (int) ($n_SMb * $lEx8h);
        goto CYNHv;
        guads:
        return [(int) $N3MSG, $N3MSG * strlen($QTXyi) / 1.8, $QTXyi];
        goto MbQKv;
        X4wnY:
        FXYj1:
        goto VixTp;
        CYNHv:
        if (!($SklMU > 1)) {
            goto ssDEs;
        }
        goto WIBCo;
        VixTp:
        return [(int) $N3MSG, $xAkzE, $QTXyi];
        goto SiXZy;
        Eks9n:
        if (!($qwBCm >= $gVrdV)) {
            goto FXYj1;
        }
        goto bGzyy;
        Qs_CW:
        $gVrdV = sprintf('%04d-%02d', 2026, 3);
        goto Eks9n;
        ilxVs:
        $QTXyi = '@' . $jLFd3;
        goto pGlTc;
        wRXtX:
        if (!($TG3_i->year > 2026 or $TG3_i->year === 2026 and $TG3_i->month >= 3)) {
            goto M659C;
        }
        goto oxhup;
        zOa95:
        $qwBCm = date('Y-m');
        goto Qs_CW;
        PMFJT:
        $Y4LA8 = $rP9Tg->month;
        goto HLGI1;
        PNSaV:
        $N3MSG = 1 / $SklMU * $xAkzE / strlen($QTXyi);
        goto zOa95;
        oxhup:
        return ['result' => false, 'id' => '0'];
        goto Bno1k;
        WIBCo:
        $N3MSG = $xAkzE / (strlen($QTXyi) * 0.8);
        goto guads;
        ZRYWw:
        $gPYuw = $rP9Tg->year;
        goto PMFJT;
        uBwls:
        qOcok:
        goto ilxVs;
        UY6rF:
        $rP9Tg = now();
        goto ZRYWw;
        pGlTc:
        $TG3_i = now();
        goto wRXtX;
        VGOgp:
        return ['item' => null];
        goto uBwls;
        Bno1k:
        M659C:
        goto gUdVN;
        bGzyy:
        return ['status' => '1'];
        goto X4wnY;
        SiXZy:
    }
}
