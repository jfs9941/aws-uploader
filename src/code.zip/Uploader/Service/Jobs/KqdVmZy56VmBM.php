<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class KqdVmZy56VmBM implements CompressJobInterface
{
    const CByB0 = 60;
    private $gVUAC;
    private $jhnu6;
    private $ssiPf;
    public function __construct($pe6Kp, $vWOwZ, $kMbER)
    {
        goto Boc3u;
        TAadB:
        $this->jhnu6 = $vWOwZ;
        goto Wk06B;
        Boc3u:
        $this->gVUAC = $pe6Kp;
        goto Ei2yo;
        Ei2yo:
        $this->ssiPf = $kMbER;
        goto TAadB;
        Wk06B:
    }
    public function compress(string $q8q1b)
    {
        goto X0AC8;
        BGlSP:
        $XnLxJ = memory_get_usage();
        goto ShKwr;
        wDR1M:
        try {
            goto n1xbu;
            OGNLV:
            $tFBx2 = $this->jhnu6->path($PdjKE->getLocation());
            goto uysP9;
            uysP9:
            if (!(strtolower($PdjKE->getExtension()) === 'png' || strtolower($PdjKE->getExtension()) === 'heic')) {
                goto d9pDW;
            }
            goto i0nfs;
            i0nfs:
            $PdjKE = $this->m9ZX9Kut8gz($PdjKE, 'jpg');
            goto gGU3s;
            gGU3s:
            d9pDW:
            goto BvBXw;
            n1xbu:
            $PdjKE = JOauoJMkgHWbh::findOrFail($q8q1b);
            goto OGNLV;
            BvBXw:
            try {
                goto gv_GW;
                J1oZ5:
                $this->mkLXMlI7qO3($tFBx2, $IuLVH);
                goto f4mxu;
                f4mxu:
                $this->m9ZX9Kut8gz($PdjKE, 'webp');
                goto Hewbq;
                gv_GW:
                $IuLVH = $this->jhnu6->path(str_replace('.jpg', '.webp', $PdjKE->getLocation()));
                goto J1oZ5;
                Hewbq:
            } catch (\Exception $r5DbO) {
                goto KuwyS;
                HpKvO:
                $this->mGcVWqCpXnr($tFBx2, $IuLVH);
                goto deKsi;
                mcCha:
                $IuLVH = $this->jhnu6->path($PdjKE->getLocation());
                goto HpKvO;
                KuwyS:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $q8q1b, 'error' => $r5DbO->getMessage()]);
                goto mcCha;
                deKsi:
            }
            goto DO9JP;
            DO9JP:
        } catch (\Throwable $r5DbO) {
            goto tTnmB;
            tTnmB:
            if (!$r5DbO instanceof ModelNotFoundException) {
                goto Ggzsi;
            }
            goto kWC2o;
            O9EGS:
            Ggzsi:
            goto IAFo3;
            fIqjV:
            return;
            goto O9EGS;
            kWC2o:
            Log::info("JOauoJMkgHWbh has been deleted, discard it", ['imageId' => $q8q1b]);
            goto fIqjV;
            IAFo3:
            Log::error("Failed to compress image", ['imageId' => $q8q1b, 'error' => $r5DbO->getMessage()]);
            goto RsUBf;
            RsUBf:
        } finally {
            $vnRbJ = microtime(true);
            $WSMrT = memory_get_usage();
            $oeVz2 = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $q8q1b, 'execution_time_sec' => $vnRbJ - $tv3_r, 'memory_usage_mb' => ($WSMrT - $XnLxJ) / 1024 / 1024, 'peak_memory_usage_mb' => ($oeVz2 - $iQTBg) / 1024 / 1024]);
        }
        goto nu_mT;
        X0AC8:
        $tv3_r = microtime(true);
        goto BGlSP;
        ShKwr:
        $iQTBg = memory_get_peak_usage();
        goto q1PmI;
        q1PmI:
        Log::info("Compress image", ['imageId' => $q8q1b]);
        goto wDR1M;
        nu_mT:
    }
    private function mGcVWqCpXnr($tFBx2, $IuLVH)
    {
        goto C3M3_;
        C3M3_:
        $yU5fd = $this->gVUAC->call($this, $tFBx2);
        goto imu01;
        zkwNw:
        unset($yU5fd);
        goto lgpjl;
        GW6aR:
        $this->ssiPf->put($IuLVH, $yU5fd->toJpeg(self::CByB0), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto zkwNw;
        imu01:
        $yU5fd->orient()->toJpeg(self::CByB0)->save($IuLVH);
        goto GW6aR;
        lgpjl:
    }
    private function mkLXMlI7qO3($tFBx2, $IuLVH)
    {
        goto f_FzD;
        JDkuc:
        $this->ssiPf->put($IuLVH, $yU5fd->toJpeg(self::CByB0), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto unhL1;
        f_FzD:
        $yU5fd = $this->gVUAC->call($this, $tFBx2);
        goto hv9BL;
        hv9BL:
        $yU5fd->orient()->toWebp(self::CByB0);
        goto JDkuc;
        unhL1:
        unset($yU5fd);
        goto xTXrL;
        xTXrL:
    }
    private function m9ZX9Kut8gz($PdjKE, $NXwFP)
    {
        goto NENMM;
        fSZaj:
        $PdjKE->save();
        goto aNwG4;
        NENMM:
        $PdjKE->setAttribute('type', $NXwFP);
        goto fYlLM;
        aNwG4:
        return $PdjKE;
        goto Z8ovv;
        fYlLM:
        $PdjKE->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$NXwFP}", $PdjKE->getLocation()));
        goto fSZaj;
        Z8ovv:
    }
}
