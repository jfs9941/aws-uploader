<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Illuminate\Support\Facades\Log;
class KyfgQxmnoRboH implements BlurVideoJobInterface
{
    const DOSpu = 15;
    const q30Hb = 500;
    const D4nFA = 500;
    private $gVUAC;
    private $cC_4U;
    private $jhnu6;
    public function __construct($pe6Kp, $s1UdZ, $vWOwZ)
    {
        goto N5GWJ;
        b0eo9:
        $this->cC_4U = $s1UdZ;
        goto IrDV0;
        IrDV0:
        $this->gVUAC = $pe6Kp;
        goto DuQoz;
        N5GWJ:
        $this->jhnu6 = $vWOwZ;
        goto b0eo9;
        DuQoz:
    }
    public function blur(string $q8q1b) : void
    {
        goto h4aPn;
        R1ZkL:
        if (chmod($wa8c_, 0664)) {
            goto RT8Hv;
        }
        goto GbPQl;
        N66TD:
        $PdjKE->resize(self::q30Hb, self::D4nFA / $NTbDZ);
        goto BjjOR;
        BjjOR:
        $PdjKE->blur(self::DOSpu);
        goto D3w6X;
        EvoZ1:
        $this->jhnu6->put($I3j8s->getAttribute('thumbnail'), $this->cC_4U->get($I3j8s->getAttribute('thumbnail')));
        goto cz9Dn;
        r2lka:
        if (!$I3j8s->getAttribute('thumbnail')) {
            goto Ec4Z1;
        }
        goto EvoZ1;
        WfFqD:
        ini_set('memory_limit', '-1');
        goto lmrAK;
        PWiRj:
        unset($PdjKE);
        goto R1ZkL;
        h4aPn:
        Log::info("Blurring for video", ['videoID' => $q8q1b]);
        goto WfFqD;
        dUE21:
        Ec4Z1:
        goto y3cO7;
        GbPQl:
        \Log::warning('Failed to set final permissions on image file: ' . $wa8c_);
        goto dS05K;
        ruHQl:
        $PdjKE->save($wa8c_);
        goto sdnlH;
        bMaQH:
        $I3j8s->update(['preview' => $jxgar]);
        goto dUE21;
        Y1kYP:
        $NTbDZ = $PdjKE->width() / $PdjKE->height();
        goto N66TD;
        yztNY:
        $wa8c_ = $this->jhnu6->path($jxgar);
        goto ruHQl;
        cz9Dn:
        $PdjKE = $this->gVUAC->call($this, $this->jhnu6->path($I3j8s->getAttribute('thumbnail')));
        goto Y1kYP;
        sdnlH:
        $this->cC_4U->put($jxgar, $this->jhnu6->get($jxgar));
        goto PWiRj;
        dS05K:
        throw new \Exception('Failed to set final permissions on image file: ' . $wa8c_);
        goto ponY_;
        ponY_:
        RT8Hv:
        goto bMaQH;
        lmrAK:
        $I3j8s = O1jfuwJR340k5::findOrFail($q8q1b);
        goto r2lka;
        D3w6X:
        $jxgar = $this->mbczg5sL9TG($I3j8s);
        goto yztNY;
        y3cO7:
    }
    private function mbczg5sL9TG(SYLdN2QnIYYwa $RJr11) : string
    {
        goto p7a1_;
        RxOJp:
        $IZRUn = dirname($K_YMm) . '/preview/';
        goto uz9EC;
        LqCtP:
        $this->jhnu6->makeDirectory($IZRUn, 0755, true);
        goto fNXCy;
        fNXCy:
        DUCb5:
        goto P9Rp7;
        p7a1_:
        $K_YMm = $RJr11->getLocation();
        goto RxOJp;
        P9Rp7:
        return $IZRUn . $RJr11->getFilename() . '.jpg';
        goto n1FTX;
        uz9EC:
        if ($this->jhnu6->exists($IZRUn)) {
            goto DUCb5;
        }
        goto LqCtP;
        n1FTX:
    }
}
