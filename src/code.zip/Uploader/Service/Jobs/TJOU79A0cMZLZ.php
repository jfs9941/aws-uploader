<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class TJOU79A0cMZLZ implements GenerateThumbnailJobInterface
{
    const HJo_T = 150;
    const JGlVE = 150;
    private $R2XXS;
    private $A8xPF;
    private $SLOAZ;
    public function __construct($I4Jnv, $ZT237, $JzkDu)
    {
        goto oEj6h;
        s2WC_:
        $this->A8xPF = $ZT237;
        goto iGrrS;
        oEj6h:
        $this->R2XXS = $I4Jnv;
        goto s2WC_;
        iGrrS:
        $this->SLOAZ = $JzkDu;
        goto c_QYl;
        c_QYl:
    }
    public function generate(string $hOWbX)
    {
        goto s7tID;
        s7tID:
        Log::info("Generating thumbnail", ['imageId' => $hOWbX]);
        goto agkc3;
        agkc3:
        ini_set('memory_limit', '-1');
        goto xH_8D;
        xH_8D:
        try {
            goto uUrmn;
            feGGn:
            unset($xk_ZK);
            goto oT512;
            SgIaG:
            $h169k->update(['thumbnail' => $D4enG, 'status' => T93Mcsw1gA3an::THUMBNAIL_PROCESSED]);
            goto CEK6x;
            MHOrI:
            $D4enG = $this->mJI3AT3TwBf($h169k);
            goto aDMUG;
            zftH2:
            $h169k = D6FgZi8OHmjic::findOrFail($hOWbX);
            goto rgQXM;
            rgQXM:
            $xk_ZK = $this->R2XXS->call($this, $zuNM5->path($h169k->getLocation()));
            goto fHuYe;
            aDMUG:
            $aH4zT = $this->SLOAZ->put($D4enG, $xk_ZK->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto feGGn;
            CEK6x:
            uTDxe:
            goto ItiYO;
            fHuYe:
            $xk_ZK->orient()->resize(150, 150);
            goto MHOrI;
            oT512:
            if (!($aH4zT !== false)) {
                goto uTDxe;
            }
            goto SgIaG;
            uUrmn:
            $zuNM5 = $this->A8xPF;
            goto zftH2;
            ItiYO:
        } catch (ModelNotFoundException $aGVU4) {
            Log::info("D6FgZi8OHmjic has been deleted, discard it", ['imageId' => $hOWbX]);
            return;
        } catch (\Exception $aGVU4) {
            Log::error("Failed to generate thumbnail", ['imageId' => $hOWbX, 'error' => $aGVU4->getMessage()]);
        }
        goto nbaLt;
        nbaLt:
    }
    private function mJI3AT3TwBf(GGOMDClEFMcsH $h169k) : string
    {
        goto IspeW;
        e7fhd:
        $T5TN1 = $IreU2 . '/' . self::HJo_T . 'X' . self::JGlVE;
        goto h5BvX;
        IspeW:
        $D4enG = $h169k->getLocation();
        goto cOmze;
        h5BvX:
        return $T5TN1 . '/' . $h169k->getFilename() . '.jpg';
        goto MzkRi;
        cOmze:
        $IreU2 = dirname($D4enG);
        goto e7fhd;
        MzkRi:
    }
}
