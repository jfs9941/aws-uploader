<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Encoder\ONqwzbh5EX8u2;
use Jfs\Uploader\Encoder\AjEME9FDV5xPI;
use Jfs\Uploader\Encoder\K98g74EXAn8Vy;
use Jfs\Uploader\Encoder\QUORU8TxE6XQu;
use Jfs\Uploader\Encoder\PtMcpMno1bPjl;
use Jfs\Uploader\Encoder\X6Szg0wTsQzEf;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Jfs\Uploader\Service\Jobs\D9XRXqeUNoW9i;
use Jfs\Uploader\Service\Jobs\YQyGyJgebc6kw;
use Jfs\Uploader\Service\A7wFfsLiK9DEe;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class QsJ3RwfJ2VxHB implements MediaEncodeJobInterface
{
    private $q34dl;
    private $j5MRz;
    private $YHwpp;
    private $uAKaW;
    private $qzWWz;
    public function __construct(string $ivxnu, $nkmCX, $ehLvI, $X3Bm8, $E53dc)
    {
        goto LJ3AE;
        LJ3AE:
        $this->q34dl = $ivxnu;
        goto Qr0M_;
        lPczC:
        $this->YHwpp = $ehLvI;
        goto f2TdK;
        f2TdK:
        $this->uAKaW = $X3Bm8;
        goto z4Ja1;
        z4Ja1:
        $this->qzWWz = $E53dc;
        goto do2id;
        Qr0M_:
        $this->j5MRz = $nkmCX;
        goto lPczC;
        do2id:
    }
    public function encode(string $ShXx2, string $gQ74Q, $JRIs3 = true) : void
    {
        goto iRkyH;
        f5LG1:
        try {
            goto Prta4;
            L9_0N:
            $kclx2->mN1B3PvsfLM($JZ81Z->mFOkdY1WvwG($uA7Bz));
            goto oq29X;
            m4sPL:
            $kclx2 = $kclx2->mMpjMmgh5Yd($MziiT);
            goto R1LQp;
            F7hMM:
            $kclx2->mMpjMmgh5Yd($JR2gX);
            goto dfvuI;
            l4WSY:
            throw new MediaConverterException("D6fOq8lm3n7T2 {$uA7Bz->id} is not S3 driver value = {$uA7Bz->driver}");
            goto Vh8uV;
            GwG2A:
            $kclx2->mMpjMmgh5Yd($JR2gX);
            goto L9_0N;
            oq29X:
            $mYBhd = app(A7wFfsLiK9DEe::class);
            goto Tkb10;
            IJJk7:
            JdHil:
            goto F7hMM;
            Tkb10:
            $MrpIx = new YQyGyJgebc6kw($this->uAKaW, $this->qzWWz, $this->YHwpp, $this->j5MRz);
            goto FQmgo;
            cGfGb:
            $Brsit = $uA7Bz->height();
            goto nzxor;
            gM49v:
            $UEDAU = $this->mXdbLP9rfUe($mYBhd, $MrpIx->mzWhDzHAaay((int) $CDv2j['width'], (int) $CDv2j['height'], $gQ74Q));
            goto hPnHh;
            dfvuI:
            $kclx2->mN1B3PvsfLM($JZ81Z->mFOkdY1WvwG($uA7Bz));
            goto eKu3h;
            R1LQp:
            I_447:
            goto TCJpb;
            hPnHh:
            if (!$UEDAU) {
                goto l11gQ;
            }
            goto KzIxl;
            Vh8uV:
            Cw2Xv:
            goto BQJtk;
            TIZ2Q:
            Log::info("Set thumbnail for D6fOq8lm3n7T2 Job", ['videoId' => $uA7Bz->getAttribute('id'), 'duration' => $uA7Bz->getAttribute('duration')]);
            goto kmshB;
            RMHaZ:
            $MziiT = new AjEME9FDV5xPI('1080p', $CDv2j['width'], $CDv2j['height'], $uA7Bz->iG1Nr ?? 30);
            goto gM49v;
            elACv:
            $CDv2j = $this->m7zL92ykEvR($Evdiw, $Brsit);
            goto kmcxO;
            G1IMZ:
            $JZ81Z = app(K98g74EXAn8Vy::class);
            goto GwG2A;
            eKu3h:
            if (!($Evdiw && $Brsit)) {
                goto MjBy4;
            }
            goto uhuUa;
            BLPHN:
            $kclx2 = app(PtMcpMno1bPjl::class);
            goto n0zbN;
            K0hx0:
            Log::info("Set input video for Job", ['s3Uri' => $TlLms]);
            goto BLPHN;
            FQmgo:
            $UEDAU = $this->mXdbLP9rfUe($mYBhd, $MrpIx->mzWhDzHAaay($uA7Bz->width(), $uA7Bz->height(), $gQ74Q));
            goto htenz;
            BQJtk:
            $Evdiw = $uA7Bz->width();
            goto cGfGb;
            TCJpb:
            MjBy4:
            goto TIZ2Q;
            K8wGP:
            $JR2gX = new AjEME9FDV5xPI('original', $Evdiw, $Brsit, $uA7Bz->iG1Nr ?? 30);
            goto G1IMZ;
            Prta4:
            $uA7Bz = D6fOq8lm3n7T2::findOrFail($ShXx2);
            goto tJJlR;
            BN1oY:
            if (!($uA7Bz->driver != TpPQGsuK0gyw2::S3)) {
                goto Cw2Xv;
            }
            goto l4WSY;
            dGOhA:
            $kclx2 = $kclx2->mrbOORmqO7u($weLf2);
            goto sojqs;
            rTGtU:
            $uA7Bz->update(['aws_media_converter_job_id' => $ShXx2]);
            goto g1fs_;
            tJJlR:
            Assert::isInstanceOf($uA7Bz, D6fOq8lm3n7T2::class);
            goto BN1oY;
            sojqs:
            $ShXx2 = $kclx2->mWujk7mYe9B($this->miQR7ChbXPP($uA7Bz, $JRIs3));
            goto rTGtU;
            I18vR:
            l11gQ:
            goto m4sPL;
            htenz:
            if (!$UEDAU) {
                goto JdHil;
            }
            goto sTOD2;
            kmshB:
            $weLf2 = new ONqwzbh5EX8u2($uA7Bz->m8jNw ?? 1, 2, $JZ81Z->mleGbwXoN7a($uA7Bz));
            goto dGOhA;
            n0zbN:
            $kclx2 = $kclx2->mwJZxnrBZaN(new QUORU8TxE6XQu($TlLms));
            goto K8wGP;
            sTOD2:
            $JR2gX = $JR2gX->mMadnArWAph($UEDAU);
            goto IJJk7;
            nzxor:
            $TlLms = $this->mvsdblwWaRZ($uA7Bz);
            goto K0hx0;
            kmcxO:
            Log::info("Set 1080p resolution for Job", ['width' => $CDv2j['width'], 'height' => $CDv2j['height'], 'originalWidth' => $Evdiw, 'originalHeight' => $Brsit]);
            goto RMHaZ;
            uhuUa:
            if (!$this->mEnn9ySHiEF($Evdiw, $Brsit)) {
                goto I_447;
            }
            goto elACv;
            KzIxl:
            $MziiT = $MziiT->mMadnArWAph($UEDAU);
            goto I18vR;
            g1fs_:
        } catch (\Exception $kE48F) {
            Log::info("D6fOq8lm3n7T2 has been deleted, discard it", ['fileId' => $ShXx2, 'err' => $kE48F->getMessage()]);
            return;
        }
        goto M7uuM;
        iRkyH:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $ShXx2]);
        goto NaEbz;
        NaEbz:
        ini_set('memory_limit', '-1');
        goto f5LG1;
        M7uuM:
    }
    private function miQR7ChbXPP(D6fOq8lm3n7T2 $uA7Bz, $JRIs3) : bool
    {
        goto pRJyG;
        fmDzC:
        eBAdj:
        goto z84pz;
        K31WT:
        fGfTn:
        goto enc_e;
        JNtfy:
        return false;
        goto K31WT;
        pRJyG:
        if ($JRIs3) {
            goto fGfTn;
        }
        goto JNtfy;
        enc_e:
        $G6K7F = (int) round($uA7Bz->getAttribute('duration') ?? 0);
        goto KJIJJ;
        nseYQ:
        fah5c:
        goto fmDzC;
        KJIJJ:
        switch (true) {
            case $uA7Bz->width() * $uA7Bz->height() >= 1920 * 1080 && $uA7Bz->width() * $uA7Bz->height() < 2560 * 1440:
                return $G6K7F > 10 * 60;
            case $uA7Bz->width() * $uA7Bz->height() >= 2560 * 1440 && $uA7Bz->width() * $uA7Bz->height() < 3840 * 2160:
                return $G6K7F > 5 * 60;
            case $uA7Bz->width() * $uA7Bz->height() >= 3840 * 2160:
                return $G6K7F > 3 * 60;
            default:
                return false;
        }
        goto nseYQ;
        z84pz:
    }
    private function mXdbLP9rfUe(A7wFfsLiK9DEe $mYBhd, string $MaCW5) : ?X6Szg0wTsQzEf
    {
        goto KT60d;
        XYAt3:
        Log::info("Resolve watermark for job with url", ['url' => $MaCW5, 'uri' => $by3Ob]);
        goto uiSNA;
        q2PeO:
        return new X6Szg0wTsQzEf($by3Ob, 0, 0, null, null);
        goto kTzXL;
        uiSNA:
        if (!$by3Ob) {
            goto PIAEA;
        }
        goto q2PeO;
        kTzXL:
        PIAEA:
        goto LmGGP;
        KT60d:
        $by3Ob = $mYBhd->m3y6OhUxTq5($MaCW5);
        goto XYAt3;
        LmGGP:
        return null;
        goto R7SI7;
        R7SI7:
    }
    private function mEnn9ySHiEF(int $Evdiw, int $Brsit) : bool
    {
        return $Evdiw * $Brsit > 1.5 * (1920 * 1080);
    }
    private function m7zL92ykEvR(int $Evdiw, int $Brsit) : array
    {
        $nTTsk = new D9XRXqeUNoW9i($Evdiw, $Brsit);
        return $nTTsk->mKpMMcKcNnM();
    }
    private function mvsdblwWaRZ(UXdXfw71iQGkx $xlFVb) : string
    {
        goto CZ49k;
        CZ49k:
        if (!($xlFVb->driver == TpPQGsuK0gyw2::S3)) {
            goto nRS1h;
        }
        goto hEqOP;
        DOq1p:
        nRS1h:
        goto Kq8pZ;
        Kq8pZ:
        return $this->j5MRz->url($xlFVb->filename);
        goto MHrGO;
        hEqOP:
        return 's3://' . $this->q34dl . '/' . $xlFVb->filename;
        goto DOq1p;
        MHrGO:
    }
}
