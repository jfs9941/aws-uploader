<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class JVAIrsPxLCKFc implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $JTwN4) : void
    {
        goto klGRd;
        oEsQ5:
        rUe0M:
        goto gJOZ5;
        klGRd:
        $B4_PH = MbOYV1VlUGCys::findOrFail($JTwN4);
        goto U2iGu;
        U2iGu:
        if ($B4_PH->width() > 0 && $B4_PH->height() > 0) {
            goto rUe0M;
        }
        goto P2keF;
        P2keF:
        $this->myQXAvB9kyx($B4_PH);
        goto oEsQ5;
        gJOZ5:
    }
    private function myQXAvB9kyx(MbOYV1VlUGCys $gGdNk) : void
    {
        goto a1tjR;
        FfitE:
        $gGdNk->update(['duration' => $p0I5F->getDurationInSeconds(), 'resolution' => $LencO->getWidth() . 'x' . $LencO->getHeight(), 'fps' => $h2QdJ->get('r_frame_rate') ?? 30]);
        goto nFljU;
        XRGvh:
        $h2QdJ = $p0I5F->getVideoStream();
        goto zP3a_;
        a1tjR:
        $M7zOf = $gGdNk->getView();
        goto DCzP3;
        zP3a_:
        $LencO = $h2QdJ->getDimensions();
        goto FfitE;
        DCzP3:
        $p0I5F = FFMpeg::fromDisk($M7zOf['path'])->open($gGdNk->getAttribute('filename'));
        goto XRGvh;
        nFljU:
    }
}
