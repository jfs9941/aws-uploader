<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\VHp3UACVYl357;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class O0yceq44mJaYq implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $GhyxD) : void
    {
        goto ZJbJc;
        sP3RK:
        if ($bKijV->width() > 0 && $bKijV->height() > 0) {
            goto C0HBM;
        }
        goto ewp6h;
        ZJbJc:
        $bKijV = VHp3UACVYl357::findOrFail($GhyxD);
        goto sP3RK;
        ewp6h:
        $this->mlKECbDORe7($bKijV);
        goto e6QuP;
        e6QuP:
        C0HBM:
        goto iRaFA;
        iRaFA:
    }
    private function mlKECbDORe7(VHp3UACVYl357 $VSIgF) : void
    {
        goto cBckw;
        cBckw:
        $nv2Qs = $VSIgF->getView();
        goto Oh50t;
        xyCEH:
        $VSIgF->update(['duration' => $pDny3->getDurationInSeconds(), 'resolution' => $nxJmY->getWidth() . 'x' . $nxJmY->getHeight(), 'fps' => $olTA6->get('r_frame_rate') ?? 30]);
        goto hSvUV;
        jAT9T:
        $nxJmY = $olTA6->getDimensions();
        goto xyCEH;
        fa1D0:
        $olTA6 = $pDny3->getVideoStream();
        goto jAT9T;
        Oh50t:
        $pDny3 = FFMpeg::fromDisk($nv2Qs['path'])->open($VSIgF->getAttribute('filename'));
        goto fa1D0;
        hSvUV:
    }
}
