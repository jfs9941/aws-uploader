<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class IdvlsRb4mglny implements GenerateThumbnailForVideoInterface
{
    private $KDCfD;
    public function __construct($QIruz)
    {
        $this->KDCfD = $QIruz;
    }
    public function generate(string $qMhfW) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $qMhfW);
        $this->KDCfD->createThumbnail($qMhfW);
    }
}
