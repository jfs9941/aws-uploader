<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
class Cg5BSQdsKnyz3 implements StoreVideoToS3JobInterface
{
    private $mobBJ;
    private $IRlXr;
    private $foEoP;
    public function __construct($F66z0, $JGvdR, $VGndK)
    {
        goto x8xeE;
        UC2ue:
        $this->foEoP = $VGndK;
        goto LEX9L;
        x8xeE:
        $this->IRlXr = $JGvdR;
        goto UC2ue;
        LEX9L:
        $this->mobBJ = $F66z0;
        goto Ejp0j;
        Ejp0j:
    }
    public function store(string $R7IrL) : void
    {
        goto vO7Av;
        vO7Av:
        Log::info('Storing video (local) to S3', ['fileId' => $R7IrL, 'bucketName' => $this->mobBJ]);
        goto D81lx;
        uDuLR:
        $FJqqf = 1024 * 1024 * 50;
        goto VXoia;
        D81lx:
        ini_set('memory_limit', '-1');
        goto Yow0P;
        ZzdSm:
        if ($VGndK->exists($rWweO->getLocation())) {
            goto PRypJ;
        }
        goto QYE0Q;
        i7ky4:
        Log::info("B6s4AA1exjQ2T has been deleted, discard it", ['fileId' => $R7IrL]);
        goto d4KC3;
        khlit:
        try {
            goto g4vbe;
            uZ43Q:
            $VGndK->delete($rWweO->getLocation());
            goto q14Xb;
            DanNB:
            z_cZa:
            goto Lefqv;
            JmSWQ:
            $mZtuW = $hrLIq['UploadId'];
            goto CKLKa;
            QNZIP:
            $rWweO->update(['driver' => R278OrMF6HCNB::S3, 'status' => QUh2VVA2TE5xx::FINISHED]);
            goto uZ43Q;
            g4vbe:
            $hrLIq = $HuLvb->createMultipartUpload(['Bucket' => $this->mobBJ, 'Key' => $rWweO->getLocation(), 'ContentType' => $Z2jso, 'ContentDisposition' => 'inline']);
            goto JmSWQ;
            Lfy6f:
            $sGu64[] = ['PartNumber' => $VbErM, 'ETag' => $k9lEC['ETag']];
            goto nAmRH;
            apX0Y:
            $k9lEC = $HuLvb->uploadPart(['Bucket' => $this->mobBJ, 'Key' => $rWweO->getLocation(), 'UploadId' => $mZtuW, 'PartNumber' => $VbErM, 'Body' => fread($SISqw, $FJqqf)]);
            goto Lfy6f;
            Xdpee:
            $HuLvb->completeMultipartUpload(['Bucket' => $this->mobBJ, 'Key' => $rWweO->getLocation(), 'UploadId' => $mZtuW, 'MultipartUpload' => ['Parts' => $sGu64]]);
            goto QNZIP;
            A0XJG:
            goto z_cZa;
            goto tRBDR;
            lwjxy:
            $sGu64 = [];
            goto DanNB;
            tRBDR:
            QhOQc:
            goto xPqMY;
            Lefqv:
            if (feof($SISqw)) {
                goto QhOQc;
            }
            goto apX0Y;
            nAmRH:
            $VbErM++;
            goto A0XJG;
            CKLKa:
            $VbErM = 1;
            goto lwjxy;
            xPqMY:
            fclose($SISqw);
            goto Xdpee;
            q14Xb:
        } catch (AwsException $jrXe_) {
            goto aJTTu;
            aJTTu:
            if (!isset($mZtuW)) {
                goto ZseTA;
            }
            goto TUxXH;
            sWecp:
            ZseTA:
            goto oC1bW;
            oC1bW:
            Log::error('Failed to store video: ' . $rWweO->getLocation() . ' - ' . $jrXe_->getMessage());
            goto flp7e;
            TUxXH:
            try {
                $HuLvb->abortMultipartUpload(['Bucket' => $this->mobBJ, 'Key' => $rWweO->getLocation(), 'UploadId' => $mZtuW]);
            } catch (AwsException $VJ81M) {
                Log::error('Error aborting multipart upload: ' . $VJ81M->getMessage());
            }
            goto sWecp;
            flp7e:
        }
        goto vVPbK;
        pemh7:
        h7RAP:
        goto ZzdSm;
        edPg0:
        PRypJ:
        goto A7c9C;
        QYE0Q:
        Log::error("[Cg5BSQdsKnyz3] File not found, discard it ", ['video' => $rWweO->getLocation()]);
        goto CLJ00;
        JP310:
        $rWweO = B6s4AA1exjQ2T::find($R7IrL);
        goto q9bVY;
        q9bVY:
        if ($rWweO) {
            goto h7RAP;
        }
        goto i7ky4;
        VXoia:
        $Z2jso = $VGndK->mimeType($rWweO->getLocation());
        goto khlit;
        CLJ00:
        return;
        goto edPg0;
        Yow0P:
        $HuLvb = $this->IRlXr->getClient();
        goto AoNtg;
        d4KC3:
        return;
        goto pemh7;
        AoNtg:
        $VGndK = $this->foEoP;
        goto JP310;
        A7c9C:
        $SISqw = $VGndK->readStream($rWweO->getLocation());
        goto uDuLR;
        vVPbK:
    }
}
