<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class AMUtYtPIPSaQA implements StoreToS3JobInterface
{
    private $UVc7_;
    private $D9Jo8;
    private $s3l3u;
    public function __construct($h1yz3, $v1Edp, $lKCQu)
    {
        goto QILwQ;
        ktni1:
        $this->s3l3u = $lKCQu;
        goto AiK07;
        QILwQ:
        $this->D9Jo8 = $v1Edp;
        goto ktni1;
        AiK07:
        $this->UVc7_ = $h1yz3;
        goto suNc_;
        suNc_:
    }
    public function store(string $poSkG) : void
    {
        goto IBBuZ;
        AlAm9:
        if (!($gDINk && $this->s3l3u->exists($gDINk))) {
            goto K2s2r;
        }
        goto lAbLe;
        lAbLe:
        $seZ3K = $this->s3l3u->path($gDINk);
        goto E9D1c;
        IBBuZ:
        $F1_0l = KZbAaRxCqNUr3::findOrFail($poSkG);
        goto E_gi5;
        i6VNF:
        $xQVcJ = $this->UVc7_->call($this, $W4B_D);
        goto I0Q73;
        QBbbv:
        $lT4E3 = $this->s3l3u->path($F1_0l->getLocation());
        goto RArcP;
        I0Q73:
        $this->D9Jo8->put($F1_0l->getAttribute('preview'), $this->s3l3u->get($F1_0l->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $xQVcJ->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto AmmSD;
        E_gi5:
        if ($F1_0l) {
            goto ButKD;
        }
        goto zcV2Z;
        eeu09:
        kRNbm:
        goto S6JSD;
        AmmSD:
        ZolZp:
        goto nFsLF;
        RArcP:
        $this->mg1v2KbeXO2($lT4E3, $F1_0l->getLocation());
        goto XLFco;
        XLFco:
        $gDINk = $F1_0l->getAttribute('thumbnail');
        goto AlAm9;
        S6JSD:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $poSkG]);
        goto qLAOx;
        BxtwP:
        if (!($F1_0l->getAttribute('preview') && $this->s3l3u->exists($F1_0l->getAttribute('preview')))) {
            goto ZolZp;
        }
        goto Zv_lL;
        nFsLF:
        if (!$F1_0l->update(['driver' => L2PWLPeQEFi6U::S3, 'status' => IOOvAXAyKHLW2::FINISHED])) {
            goto kRNbm;
        }
        goto nyHEf;
        Zv_lL:
        $W4B_D = $this->s3l3u->path($F1_0l->getAttribute('preview'));
        goto i6VNF;
        eryW9:
        $this->D9Jo8->put($F1_0l->getAttribute('thumbnail'), $this->s3l3u->get($gDINk), ['visibility' => 'public', 'ContentType' => $eeT1E->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto fg6ps;
        bdZRm:
        ButKD:
        goto QBbbv;
        HRFOL:
        KZbAaRxCqNUr3::where('parent_id', $poSkG)->update(['driver' => L2PWLPeQEFi6U::S3, 'preview' => $F1_0l->getAttribute('preview'), 'thumbnail' => $F1_0l->getAttribute('thumbnail')]);
        goto TcTfe;
        zcV2Z:
        Log::info("KZbAaRxCqNUr3 has been deleted, discard it", ['fileId' => $poSkG]);
        goto KC9OC;
        fg6ps:
        K2s2r:
        goto BxtwP;
        TcTfe:
        return;
        goto eeu09;
        KC9OC:
        return;
        goto bdZRm;
        nyHEf:
        Log::info("KZbAaRxCqNUr3 stored to S3, update the children attachments", ['fileId' => $poSkG]);
        goto HRFOL;
        E9D1c:
        $eeT1E = $this->UVc7_->call($this, $seZ3K);
        goto eryW9;
        qLAOx:
    }
    private function mg1v2KbeXO2($rvyBk, $MhiKs, $JJ04k = '')
    {
        goto CJTDO;
        I9bm7:
        $rvyBk = str_replace('.jpg', $JJ04k, $rvyBk);
        goto Upwg5;
        xsoHH:
        try {
            $VSbOm = $this->UVc7_->call($this, $rvyBk);
            $this->D9Jo8->put($MhiKs, $this->s3l3u->get($MhiKs), ['visibility' => 'public', 'ContentType' => $VSbOm->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $R1uEk) {
            Log::error("Failed to upload image to S3", ['s3Path' => $MhiKs, 'error' => $R1uEk->getMessage()]);
        }
        goto D0PUk;
        Upwg5:
        $MhiKs = str_replace('.jpg', $JJ04k, $MhiKs);
        goto svNOj;
        svNOj:
        CmlPH:
        goto xsoHH;
        CJTDO:
        if (!$JJ04k) {
            goto CmlPH;
        }
        goto I9bm7;
        D0PUk:
    }
}
