<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class Qb6H2lXA5jPLg implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $mfjeD) : void
    {
        goto GdzD6;
        n5TFP:
        $this->m3aup1htMDg($wmU7r);
        goto zjf7j;
        j7Qsr:
        if ($wmU7r->width() > 0 && $wmU7r->height() > 0) {
            goto LMa81;
        }
        goto n5TFP;
        zjf7j:
        LMa81:
        goto L9XGu;
        GdzD6:
        $wmU7r = ZSB2cdrwtZpmk::findOrFail($mfjeD);
        goto j7Qsr;
        L9XGu:
    }
    private function m3aup1htMDg(ZSB2cdrwtZpmk $v17Df) : void
    {
        goto dMNuQ;
        KF4M_:
        $F1c5u = $g1333->getVideoStream();
        goto n3shl;
        n3shl:
        $xiwWW = $F1c5u->getDimensions();
        goto xX6Js;
        dMNuQ:
        $ZUnAd = $v17Df->getView();
        goto JblI9;
        JblI9:
        $g1333 = FFMpeg::fromDisk($ZUnAd['path'])->open($v17Df->getAttribute('filename'));
        goto KF4M_;
        xX6Js:
        $v17Df->update(['duration' => $g1333->getDurationInSeconds(), 'resolution' => $xiwWW->getWidth() . 'x' . $xiwWW->getHeight(), 'fps' => $F1c5u->get('r_frame_rate') ?? 30]);
        goto GLaFn;
        GLaFn:
    }
}
