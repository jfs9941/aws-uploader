<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class JQoP3jKbYunC3
{
    private $aAXO2;
    private $PVphm;
    private $UoQI7;
    private $SIeOC;
    public function __construct($ZSFKK, $Tk5nz, $UjVft, $Ay4fJ)
    {
        goto hox_r;
        mLzva:
        $this->UoQI7 = $UjVft;
        goto sUHCk;
        hox_r:
        $this->PVphm = $Tk5nz;
        goto mLzva;
        uOAKh:
        $this->aAXO2 = $ZSFKK;
        goto jdvV7;
        sUHCk:
        $this->SIeOC = $Ay4fJ;
        goto uOAKh;
        jdvV7:
    }
    public function mF7paffjixE(?int $k2slg, ?int $vci_g, string $ubwD6, bool $NPMtL = false) : string
    {
        goto Wm1Qa;
        U0mR0:
        list($rIi2F, $rpQ1x, $iQcqr) = $this->mSDpbVQgVFP($ubwD6, $k2slg, $LyCpK, (float) $k2slg / $vci_g);
        goto TnaTC;
        qsWZz:
        $VGttq->text($iQcqr, $i8jBJ, (int) $xTBkh, function ($O3MQn) use($rIi2F) {
            goto pITtl;
            HQR13:
            $O3MQn->size(max($ZkK1E, 1));
            goto nPjKL;
            tsese:
            $O3MQn->valign('middle');
            goto JO6V7;
            JO6V7:
            $O3MQn->align('middle');
            goto zXOIa;
            pITtl:
            $O3MQn->file(public_path($this->PVphm));
            goto oAX2j;
            oAX2j:
            $ZkK1E = (int) ($rIi2F * 1.2);
            goto HQR13;
            nPjKL:
            $O3MQn->color([185, 185, 185, 1]);
            goto tsese;
            zXOIa:
        });
        goto WPo9o;
        kWdzH:
        $VGttq = $this->aAXO2->call($this, $k2slg, $vci_g);
        goto Wzd30;
        zKCXg:
        throw new \RuntimeException("JPkW9ix1EKo3T dimensions are not available.");
        goto zcY7r;
        Wzd30:
        $i8jBJ = $k2slg - $rpQ1x;
        goto dhmRE;
        zcY7r:
        L9PCO:
        goto Cyx6M;
        LQ_th:
        $this->UoQI7->put($hKqqZ, $VGttq->stream('png'));
        goto EZaX4;
        Cyx6M:
        $LyCpK = 0.1;
        goto U0mR0;
        TnaTC:
        $hKqqZ = $this->m2pX4IJzQqM($iQcqr, $k2slg, $vci_g, $rpQ1x, $rIi2F);
        goto kZdK0;
        kZdK0:
        if (!$this->UoQI7->exists($hKqqZ)) {
            goto j2Bfq;
        }
        goto r1W7M;
        dhmRE:
        $eTkK1 = (int) ($i8jBJ / 80);
        goto XmTjB;
        Wm1Qa:
        if (!($k2slg === null || $vci_g === null)) {
            goto L9PCO;
        }
        goto zKCXg;
        EZaX4:
        return $NPMtL ? $hKqqZ : $this->UoQI7->url($hKqqZ);
        goto LxtZj;
        hvNEG:
        Z9XF5:
        goto vExPf;
        WPo9o:
        $this->SIeOC->put($hKqqZ, $VGttq->stream('png'));
        goto LQ_th;
        EsnA9:
        j2Bfq:
        goto kWdzH;
        vExPf:
        $xTBkh = $vci_g - $rIi2F - 10;
        goto qsWZz;
        r1W7M:
        return $NPMtL ? $hKqqZ : $this->UoQI7->url($hKqqZ);
        goto EsnA9;
        XmTjB:
        $i8jBJ -= $eTkK1;
        goto bWXZh;
        m3Gup:
        $i8jBJ -= $eTkK1 * 0.4;
        goto hvNEG;
        bWXZh:
        if (!($k2slg > 1500)) {
            goto Z9XF5;
        }
        goto m3Gup;
        LxtZj:
    }
    private function m2pX4IJzQqM(string $ubwD6, int $k2slg, int $vci_g, int $LuJm7, int $jjvTZ) : string
    {
        $a5n2C = ltrim($ubwD6, '@');
        return "v2/watermark/{$a5n2C}/{$k2slg}x{$vci_g}_{$LuJm7}x{$jjvTZ}/text_watermark.png";
    }
    private function mSDpbVQgVFP($ubwD6, int $k2slg, float $nFQsq, float $BbstY) : array
    {
        goto k5cJX;
        fOFOX:
        $AglIr = $rpQ1x / (strlen($iQcqr) * 0.8);
        goto ix5o3;
        D812V:
        $rpQ1x = (int) ($k2slg * $nFQsq);
        goto BEzor;
        FMwRP:
        return [(int) $AglIr, $rpQ1x, $iQcqr];
        goto C28PW;
        YnAZC:
        zG_gS:
        goto HL5bO;
        HL5bO:
        $AglIr = 1 / $BbstY * $rpQ1x / strlen($iQcqr);
        goto FMwRP;
        BEzor:
        if (!($BbstY > 1)) {
            goto zG_gS;
        }
        goto fOFOX;
        ix5o3:
        return [(int) $AglIr, $AglIr * strlen($iQcqr) / 1.8, $iQcqr];
        goto YnAZC;
        k5cJX:
        $iQcqr = '@' . $ubwD6;
        goto D812V;
        C28PW:
    }
}
