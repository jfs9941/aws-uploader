<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Illuminate\Support\Facades\Log;
class GwraMaH3spWuw implements DownloadToLocalJobInterface
{
    private $m2kWg;
    private $Jhhox;
    public function __construct($Npup8, $bXh5v)
    {
        $this->m2kWg = $Npup8;
        $this->Jhhox = $bXh5v;
    }
    public function download(string $Brk87) : void
    {
        goto po1tC;
        BcCjF:
        $this->Jhhox->put($ZQzpf->getLocation(), $this->m2kWg->get($ZQzpf->getLocation()));
        goto Jycnm;
        nGQBj:
        if (!$this->Jhhox->exists($ZQzpf->getLocation())) {
            goto dqOgV;
        }
        goto uMwFh;
        po1tC:
        $ZQzpf = OjvWwjWRqBzIO::findOrFail($Brk87);
        goto H6j3F;
        kUMUe:
        dqOgV:
        goto BcCjF;
        uMwFh:
        return;
        goto kUMUe;
        H6j3F:
        Log::info("Start download file to local", ['fileId' => $Brk87, 'filename' => $ZQzpf->getLocation()]);
        goto nGQBj;
        Jycnm:
    }
}
