<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class CGYQ7lCcqAtRC implements StoreToS3JobInterface
{
    private $PAMAL;
    private $hFxUe;
    private $Celh5;
    public function __construct($VX8yi, $KKbEP, $clScT)
    {
        goto wDEgt;
        wDEgt:
        $this->hFxUe = $KKbEP;
        goto rIRuO;
        G4EGm:
        $this->PAMAL = $VX8yi;
        goto YfiKz;
        rIRuO:
        $this->Celh5 = $clScT;
        goto G4EGm;
        YfiKz:
    }
    public function store(string $SEOXv) : void
    {
        goto xJrty;
        D2Y8u:
        $nAHnj = $this->Celh5->path($sh41Q);
        goto dwH7R;
        RbLVp:
        $ANxrm = $this->Celh5->path($NcJt_->getAttribute('preview'));
        goto WJ_5Q;
        mLU6x:
        OSP5y:
        goto IkbON;
        CwqK9:
        $this->m6Uu2SDPuC1($liQkG, $NcJt_->getLocation());
        goto hVJDw;
        ktInW:
        $this->hFxUe->put($NcJt_->getAttribute('preview'), $this->Celh5->get($NcJt_->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $OmA6p->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto EOtYS;
        y9Byc:
        Log::info("FmmY71eXk0D8U has been deleted, discard it", ['fileId' => $SEOXv]);
        goto K9uca;
        Wg3tu:
        return;
        goto itsMM;
        RYW51:
        if (!$NcJt_->update(['driver' => Rf7fPQasmK9R3::S3, 'status' => QE1dzvgcPWV6R::FINISHED])) {
            goto RPjTY;
        }
        goto TsTy2;
        b7uaJ:
        FmmY71eXk0D8U::where('parent_id', $SEOXv)->update(['driver' => Rf7fPQasmK9R3::S3, 'preview' => $NcJt_->getAttribute('preview'), 'thumbnail' => $NcJt_->getAttribute('thumbnail')]);
        goto Wg3tu;
        xJrty:
        $NcJt_ = FmmY71eXk0D8U::findOrFail($SEOXv);
        goto sxeGT;
        ETX73:
        $liQkG = $this->Celh5->path($NcJt_->getLocation());
        goto CwqK9;
        dwH7R:
        $th60a = $this->PAMAL->call($this, $nAHnj);
        goto FYUFQ;
        sxeGT:
        if ($NcJt_) {
            goto DYk1V;
        }
        goto y9Byc;
        g059d:
        DYk1V:
        goto ETX73;
        LVz06:
        if (!($sh41Q && $this->Celh5->exists($sh41Q))) {
            goto OSP5y;
        }
        goto D2Y8u;
        IkbON:
        if (!($NcJt_->getAttribute('preview') && $this->Celh5->exists($NcJt_->getAttribute('preview')))) {
            goto Jr2I5;
        }
        goto RbLVp;
        K9uca:
        return;
        goto g059d;
        TsTy2:
        Log::info("FmmY71eXk0D8U stored to S3, update the children attachments", ['fileId' => $SEOXv]);
        goto b7uaJ;
        WJ_5Q:
        $OmA6p = $this->PAMAL->call($this, $ANxrm);
        goto ktInW;
        EOtYS:
        Jr2I5:
        goto RYW51;
        rVKyf:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $SEOXv]);
        goto Y1d1h;
        hVJDw:
        $sh41Q = $NcJt_->getAttribute('thumbnail');
        goto LVz06;
        itsMM:
        RPjTY:
        goto rVKyf;
        FYUFQ:
        $this->hFxUe->put($NcJt_->getAttribute('thumbnail'), $this->Celh5->get($sh41Q), ['visibility' => 'public', 'ContentType' => $th60a->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto mLU6x;
        Y1d1h:
    }
    private function m6Uu2SDPuC1($KD5tq, $a8Z1d, $DkCVl = '')
    {
        goto Gnpsn;
        OHY65:
        $a8Z1d = str_replace('.jpg', $DkCVl, $a8Z1d);
        goto eYCGv;
        eYCGv:
        hzGpk:
        goto ROM5I;
        ROM5I:
        try {
            $dIrHq = $this->PAMAL->call($this, $KD5tq);
            $this->hFxUe->put($a8Z1d, $this->Celh5->get($a8Z1d), ['visibility' => 'public', 'ContentType' => $dIrHq->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $L0fOk) {
            Log::error("Failed to upload image to S3", ['s3Path' => $a8Z1d, 'error' => $L0fOk->getMessage()]);
        }
        goto r5KYP;
        K0wOC:
        $KD5tq = str_replace('.jpg', $DkCVl, $KD5tq);
        goto OHY65;
        Gnpsn:
        if (!$DkCVl) {
            goto hzGpk;
        }
        goto K0wOC;
        r5KYP:
    }
}
