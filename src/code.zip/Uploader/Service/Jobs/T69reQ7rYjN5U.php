<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
class T69reQ7rYjN5U implements WatermarkTextJobInterface
{
    private $KbvBQ;
    private $eVAG5;
    private $r2W0C;
    private $RaPnW;
    private $OQTXf;
    public function __construct($twxgF, $Ar8h8, $hTkyv, $eL8cO, $KhWq_)
    {
        goto W2apN;
        W2apN:
        $this->KbvBQ = $twxgF;
        goto PC4Qi;
        PC4Qi:
        $this->RaPnW = $hTkyv;
        goto Kxfgj;
        WKeHM:
        $this->r2W0C = $KhWq_;
        goto wbw3a;
        wbw3a:
        $this->eVAG5 = $Ar8h8;
        goto yMtjc;
        Kxfgj:
        $this->OQTXf = $eL8cO;
        goto WKeHM;
        yMtjc:
    }
    public function putWatermark(string $UcmDx, string $grG7O) : void
    {
        goto xxGt9;
        xxGt9:
        Log::info("Adding watermark text to image", ['imageId' => $UcmDx]);
        goto vAjoH;
        uSWNG:
        try {
            goto C4sFF;
            AQHZv:
            Log::error("HSe6BNUpJTSwE is not on local, might be deleted before put watermark", ['imageId' => $UcmDx]);
            goto nT4ke;
            mJzeX:
            \Log::warning('Failed to set final permissions on image file: ' . $eviRR);
            goto LOS4a;
            zjpkX:
            $yq22P->destroy();
            goto g0YDa;
            Fipm1:
            NiQeK:
            goto p7Jl0;
            nT4ke:
            return;
            goto Fipm1;
            mORwt:
            o8JZf:
            goto tylkR;
            Ayp7L:
            $yq22P->orientate();
            goto ql7_I;
            aJFMf:
            if ($this->OQTXf->exists($IS6o1->getLocation())) {
                goto NiQeK;
            }
            goto AQHZv;
            ql7_I:
            $this->m2lXdM2te2U($yq22P, $grG7O);
            goto QJ1I0;
            QJ1I0:
            $yq22P->save($eviRR);
            goto zjpkX;
            m0OHs:
            $yq22P = $this->KbvBQ->call($this, $eviRR);
            goto Ayp7L;
            C4sFF:
            $IS6o1 = HSe6BNUpJTSwE::findOrFail($UcmDx);
            goto aJFMf;
            LOS4a:
            throw new \Exception('Failed to set final permissions on image file: ' . $eviRR);
            goto mORwt;
            g0YDa:
            if (chmod($eviRR, 0664)) {
                goto o8JZf;
            }
            goto mJzeX;
            p7Jl0:
            $eviRR = $this->OQTXf->path($IS6o1->getLocation());
            goto m0OHs;
            tylkR:
        } catch (\Throwable $AIjTM) {
            goto x4bTA;
            x4bTA:
            if (!$AIjTM instanceof ModelNotFoundException) {
                goto GmNxy;
            }
            goto NaKj4;
            NaKj4:
            Log::info("HSe6BNUpJTSwE has been deleted, discard it", ['imageId' => $UcmDx]);
            goto UMfXF;
            EIe36:
            Log::error("HSe6BNUpJTSwE is not readable", ['imageId' => $UcmDx, 'error' => $AIjTM->getMessage()]);
            goto vHb6k;
            sLXTy:
            GmNxy:
            goto EIe36;
            UMfXF:
            return;
            goto sLXTy;
            vHb6k:
        }
        goto Ss9Nh;
        vAjoH:
        ini_set('memory_limit', '-1');
        goto uSWNG;
        Ss9Nh:
    }
    private function m2lXdM2te2U($yq22P, $grG7O) : void
    {
        goto vXBUu;
        v3Rof:
        $M0J4r = $yq22P->height();
        goto GdUzK;
        DbiQd:
        $N_UFb = $this->KbvBQ->call($this, $this->OQTXf->path($TvmtZ));
        goto e1h04;
        W7Hzi:
        $this->OQTXf->put($TvmtZ, $this->RaPnW->get($TvmtZ));
        goto DbiQd;
        k3r3B:
        $TvmtZ = $aeumJ->mN7QCjDOwk9($n9snl, $M0J4r, $grG7O, true);
        goto W7Hzi;
        vXBUu:
        $n9snl = $yq22P->width();
        goto v3Rof;
        wO1io:
        $yq22P->insert($N_UFb);
        goto oZveH;
        e1h04:
        $N_UFb->opacity(35);
        goto wO1io;
        GdUzK:
        $aeumJ = new SsZ0mh1c89bBF($this->eVAG5, $this->r2W0C, $this->RaPnW, $this->OQTXf);
        goto k3r3B;
        oZveH:
    }
}
