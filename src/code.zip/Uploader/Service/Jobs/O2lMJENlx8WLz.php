<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
class O2lMJENlx8WLz implements BlurJobInterface
{
    const C1gt6 = 15;
    const fa1k2 = 500;
    const TqGuR = 500;
    private $j6_VZ;
    private $RE_2F;
    private $F8ilg;
    public function __construct($od_dm, $WmwnR, $Pkopf)
    {
        goto bd1pj;
        bd1pj:
        $this->F8ilg = $Pkopf;
        goto TuCVe;
        CHuim:
        $this->j6_VZ = $od_dm;
        goto gbY28;
        TuCVe:
        $this->RE_2F = $WmwnR;
        goto CHuim;
        gbY28:
    }
    public function blur(string $LpGEK) : void
    {
        goto aQ_a9;
        sG5w1:
        $ZQQzW = $this->j6_VZ->call($this, $this->F8ilg->path($zmqC_->getLocation()));
        goto YKB5X;
        s3v0W:
        $this->F8ilg->put($zmqC_->filename, $pLVBb);
        goto dE9F4;
        aQ_a9:
        $zmqC_ = X9YHjKrAdcfhe::findOrFail($LpGEK);
        goto mYUcz;
        mYUcz:
        ini_set('memory_limit', '-1');
        goto KW1M2;
        GMfKc:
        $jd4oJ = $this->RE_2F->put($XC0PR, $ZQQzW->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto ADhqn;
        Uc523:
        $ZQQzW->blur(self::C1gt6);
        goto tMCk6;
        MiIGW:
        m52HG:
        goto cndSk;
        XXkpx:
        throw new \Exception('Failed to set final permissions on image file: ' . $jd4oJ);
        goto MiIGW;
        cndSk:
        $zmqC_->update(['preview' => $XC0PR]);
        goto vMgbQ;
        KW1M2:
        if (!($zmqC_->xiRsU == EzGWviwQDmAwI::S3 && !$this->F8ilg->exists($zmqC_->filename))) {
            goto Fz_PC;
        }
        goto MaLde;
        dE9F4:
        Fz_PC:
        goto sG5w1;
        YKB5X:
        $lkDG2 = $ZQQzW->width() / $ZQQzW->height();
        goto Td2tu;
        tMCk6:
        $XC0PR = $this->mGZsOkXdFW4($zmqC_);
        goto GMfKc;
        MaLde:
        $pLVBb = $this->RE_2F->get($zmqC_->filename);
        goto s3v0W;
        Td2tu:
        $ZQQzW->resize(self::fa1k2, self::TqGuR / $lkDG2);
        goto Uc523;
        arPYs:
        if (chmod($jd4oJ, 0664)) {
            goto m52HG;
        }
        goto l2QND;
        l2QND:
        \Log::warning('Failed to set final permissions on image file: ' . $jd4oJ);
        goto XXkpx;
        ADhqn:
        unset($ZQQzW);
        goto arPYs;
        vMgbQ:
    }
    private function mGZsOkXdFW4($GGyW5) : string
    {
        goto XjRYx;
        SpCza:
        $this->F8ilg->makeDirectory($lWrHD, 0755, true);
        goto LCoZd;
        LCoZd:
        RyBMp:
        goto gP13U;
        SV_eP:
        $lWrHD = dirname($AvgzF) . '/preview/';
        goto CajrM;
        XjRYx:
        $AvgzF = $GGyW5->getLocation();
        goto SV_eP;
        CajrM:
        if ($this->F8ilg->exists($lWrHD)) {
            goto RyBMp;
        }
        goto SpCza;
        gP13U:
        return $lWrHD . $GGyW5->getFilename() . '.jpg';
        goto y3CmX;
        y3CmX:
    }
}
