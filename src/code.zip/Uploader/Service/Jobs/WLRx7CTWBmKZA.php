<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Illuminate\Support\Facades\Log;
class WLRx7CTWBmKZA implements StoreVideoToS3JobInterface
{
    private $IQnf0;
    private $uiTOc;
    private $dwubH;
    public function __construct($O893k, $ATeSz, $VzPPJ)
    {
        goto HWzfJ;
        PaeIS:
        $this->dwubH = $VzPPJ;
        goto undeT;
        HWzfJ:
        $this->uiTOc = $ATeSz;
        goto PaeIS;
        undeT:
        $this->IQnf0 = $O893k;
        goto sqUnZ;
        sqUnZ:
    }
    public function store(string $B_L9m) : void
    {
        goto KHAec;
        m41Ab:
        $zKkyV = $VzPPJ->readStream($YIEpX->getLocation());
        goto hDbsP;
        ieP0L:
        return;
        goto eEOUX;
        PmdAj:
        $N3akJ = $this->uiTOc->getClient();
        goto X7d_y;
        JNlJM:
        Log::error("[WLRx7CTWBmKZA] File not found, discard it ", ['video' => $YIEpX->getLocation()]);
        goto Sawfb;
        Liv3u:
        ini_set('memory_limit', '-1');
        goto PmdAj;
        C5FrG:
        try {
            goto Ey28k;
            z_3I0:
            $Pg2Nq = 1;
            goto D0HBL;
            EU2ZV:
            goto FIFlW;
            goto BCX57;
            Fc0jY:
            $TOKNh = $N3akJ->uploadPart(['Bucket' => $this->IQnf0, 'Key' => $YIEpX->getLocation(), 'UploadId' => $v5Sny, 'PartNumber' => $Pg2Nq, 'Body' => fread($zKkyV, $eEti6)]);
            goto SHgHz;
            kASJb:
            $v5Sny = $h1oLe['UploadId'];
            goto z_3I0;
            ILivN:
            $VzPPJ->delete($YIEpX->getLocation());
            goto mT4MU;
            PbAED:
            $N3akJ->completeMultipartUpload(['Bucket' => $this->IQnf0, 'Key' => $YIEpX->getLocation(), 'UploadId' => $v5Sny, 'MultipartUpload' => ['Parts' => $MZWng]]);
            goto znSM9;
            D0HBL:
            $MZWng = [];
            goto QmUkB;
            PQrWM:
            $Pg2Nq++;
            goto EU2ZV;
            BCX57:
            VGfhW:
            goto fB5l6;
            fB5l6:
            fclose($zKkyV);
            goto PbAED;
            kj17d:
            if (feof($zKkyV)) {
                goto VGfhW;
            }
            goto Fc0jY;
            Ey28k:
            $h1oLe = $N3akJ->createMultipartUpload(['Bucket' => $this->IQnf0, 'Key' => $YIEpX->getLocation(), 'ContentType' => $obUpg, 'ContentDisposition' => 'inline']);
            goto kASJb;
            znSM9:
            $YIEpX->update(['driver' => J0IuL8wroLOWt::S3, 'status' => LV0wDYHZInswq::FINISHED]);
            goto ILivN;
            QmUkB:
            FIFlW:
            goto kj17d;
            SHgHz:
            $MZWng[] = ['PartNumber' => $Pg2Nq, 'ETag' => $TOKNh['ETag']];
            goto PQrWM;
            mT4MU:
        } catch (AwsException $kHEpW) {
            goto k0vVr;
            k0vVr:
            if (!isset($v5Sny)) {
                goto l3Ukk;
            }
            goto o11P7;
            o11P7:
            try {
                $N3akJ->abortMultipartUpload(['Bucket' => $this->IQnf0, 'Key' => $YIEpX->getLocation(), 'UploadId' => $v5Sny]);
            } catch (AwsException $YsnwS) {
                Log::error('Error aborting multipart upload: ' . $YsnwS->getMessage());
            }
            goto L5R2i;
            asKBQ:
            Log::error('Failed to store video: ' . $YIEpX->getLocation() . ' - ' . $kHEpW->getMessage());
            goto XvQoo;
            L5R2i:
            l3Ukk:
            goto asKBQ;
            XvQoo:
        } finally {
            $C_8tm = microtime(true);
            $U52Iz = memory_get_usage();
            $QtsLN = memory_get_peak_usage();
            Log::info('Store U9HMl0N8dP0ZH to S3 function resource usage', ['imageId' => $B_L9m, 'execution_time_sec' => $C_8tm - $iw0Jp, 'memory_usage_mb' => ($U52Iz - $hi2m0) / 1024 / 1024, 'peak_memory_usage_mb' => ($QtsLN - $n0RF8) / 1024 / 1024]);
        }
        goto ZuO7B;
        ezleZ:
        $hi2m0 = memory_get_usage();
        goto XrBUl;
        qO02L:
        lAio2:
        goto m41Ab;
        MFPuh:
        if ($VzPPJ->exists($YIEpX->getLocation())) {
            goto lAio2;
        }
        goto JNlJM;
        LC3vO:
        $obUpg = $VzPPJ->mimeType($YIEpX->getLocation());
        goto fzlGz;
        X7d_y:
        $VzPPJ = $this->dwubH;
        goto SqOpr;
        KHAec:
        Log::info('Storing video (local) to S3', ['fileId' => $B_L9m, 'bucketName' => $this->IQnf0]);
        goto Liv3u;
        oqFGw:
        if ($YIEpX) {
            goto pbWV3;
        }
        goto mCZ5t;
        Sawfb:
        return;
        goto qO02L;
        fzlGz:
        $iw0Jp = microtime(true);
        goto ezleZ;
        hDbsP:
        $eEti6 = 1024 * 1024 * 50;
        goto LC3vO;
        mCZ5t:
        Log::info("U9HMl0N8dP0ZH has been deleted, discard it", ['fileId' => $B_L9m]);
        goto ieP0L;
        SqOpr:
        $YIEpX = U9HMl0N8dP0ZH::find($B_L9m);
        goto oqFGw;
        XrBUl:
        $n0RF8 = memory_get_peak_usage();
        goto C5FrG;
        eEOUX:
        pbWV3:
        goto MFPuh;
        ZuO7B:
    }
}
