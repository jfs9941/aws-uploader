<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Illuminate\Support\Facades\Log;
class D1vCpLdf7hzzL implements DownloadToLocalJobInterface
{
    private $uiTOc;
    private $dwubH;
    public function __construct($ATeSz, $VzPPJ)
    {
        $this->uiTOc = $ATeSz;
        $this->dwubH = $VzPPJ;
    }
    public function download(string $B_L9m) : void
    {
        goto iMdFh;
        HBLio:
        return;
        goto tXVHj;
        tXVHj:
        JXXz1:
        goto TOLQx;
        oCcyp:
        if (!$this->dwubH->exists($YfsmL->getLocation())) {
            goto JXXz1;
        }
        goto HBLio;
        TOLQx:
        $this->dwubH->put($YfsmL->getLocation(), $this->uiTOc->get($YfsmL->getLocation()));
        goto DRWSL;
        iMdFh:
        $YfsmL = XMeo8SOmME8kj::findOrFail($B_L9m);
        goto dXbWG;
        dXbWG:
        Log::info("Start download file to local", ['fileId' => $B_L9m, 'filename' => $YfsmL->getLocation()]);
        goto oCcyp;
        DRWSL:
    }
}
