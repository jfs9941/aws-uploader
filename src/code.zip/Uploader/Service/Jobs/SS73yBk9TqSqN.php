<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Illuminate\Support\Facades\Log;
class SS73yBk9TqSqN implements DownloadToLocalJobInterface
{
    private $D9Jo8;
    private $s3l3u;
    public function __construct($v1Edp, $lKCQu)
    {
        $this->D9Jo8 = $v1Edp;
        $this->s3l3u = $lKCQu;
    }
    public function download(string $poSkG) : void
    {
        goto uVdv_;
        ggDIz:
        Log::info("Start download file to local", ['fileId' => $poSkG, 'filename' => $pemjO->getLocation()]);
        goto qDcfb;
        c1Xym:
        $this->s3l3u->put($pemjO->getLocation(), $this->D9Jo8->get($pemjO->getLocation()));
        goto T4dyM;
        uVdv_:
        $pemjO = KZbAaRxCqNUr3::findOrFail($poSkG);
        goto ggDIz;
        wu3Dg:
        hIZcQ:
        goto c1Xym;
        VNN25:
        return;
        goto wu3Dg;
        qDcfb:
        if (!$this->s3l3u->exists($pemjO->getLocation())) {
            goto hIZcQ;
        }
        goto VNN25;
        T4dyM:
    }
}
