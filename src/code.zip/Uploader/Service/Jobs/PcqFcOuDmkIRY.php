<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class PcqFcOuDmkIRY
{
    private $Zzac4;
    private $RVbPJ;
    public function __construct(int $D9Vmm, int $GP1G3)
    {
        goto rdL7K;
        mr0ic:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto OAC6x;
        Y1rMw:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto QQ7HQ;
        tq5Tb:
        $this->RVbPJ = $GP1G3;
        goto SJGfO;
        OAC6x:
        klEAH:
        goto DULQX;
        QosJM:
        $this->Zzac4 = $D9Vmm;
        goto tq5Tb;
        rdL7K:
        if (!($D9Vmm <= 0)) {
            goto klEAH;
        }
        goto mr0ic;
        QQ7HQ:
        Xo74L:
        goto QosJM;
        DULQX:
        if (!($GP1G3 <= 0)) {
            goto Xo74L;
        }
        goto Y1rMw;
        SJGfO:
    }
    private static function mcK3FDCKZNp($tfrZA, string $Eds9L = 'floor') : int
    {
        goto GNfkj;
        ozMkq:
        if (!(is_float($tfrZA) && $tfrZA == floor($tfrZA) && (int) $tfrZA % 2 === 0)) {
            goto LVXfX;
        }
        goto wpImI;
        HKLMu:
        WBWX3:
        goto w0YVs;
        om1aL:
        LVXfX:
        goto sU6xP;
        sU6xP:
        switch (strtolower($Eds9L)) {
            case 'ceil':
                return (int) (ceil($tfrZA / 2) * 2);
            case 'round':
                return (int) (round($tfrZA / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($tfrZA / 2) * 2);
        }
        goto HKLMu;
        w0YVs:
        yZHcG:
        goto B2vm7;
        paTp2:
        return $tfrZA;
        goto cXq8X;
        GNfkj:
        if (!(is_int($tfrZA) && $tfrZA % 2 === 0)) {
            goto Flddp;
        }
        goto paTp2;
        cXq8X:
        Flddp:
        goto ozMkq;
        wpImI:
        return (int) $tfrZA;
        goto om1aL;
        B2vm7:
    }
    public function mS2twOpS5px(string $ZEITY = 'floor') : array
    {
        goto bZHcq;
        CNC49:
        $c2579 = $mHpZt / $this->Zzac4;
        goto nIHDR;
        e7KMJ:
        aa7JG:
        goto Iqrn_;
        N82FS:
        $aRSV3 = self::mcK3FDCKZNp(round($NaxNH), $ZEITY);
        goto mwNBu;
        c24Dp:
        $mHpZt = 2;
        goto cLmFk;
        mzBjP:
        return ['width' => $mHpZt, 'height' => $aRSV3];
        goto pgi6Z;
        DL6df:
        if (!($aRSV3 < 2)) {
            goto CUv0t;
        }
        goto FtbI7;
        u0NYm:
        $mHpZt = self::mcK3FDCKZNp(round($YDVY8), $ZEITY);
        goto e7KMJ;
        GOwhf:
        CUv0t:
        goto mzBjP;
        FtbI7:
        $aRSV3 = 2;
        goto GOwhf;
        mwNBu:
        goto aa7JG;
        goto rTUk6;
        w4S3u:
        $aRSV3 = 0;
        goto CRogi;
        CRogi:
        if ($this->Zzac4 >= $this->RVbPJ) {
            goto LAKkP;
        }
        goto FNiQX;
        bZHcq:
        $ozLRl = 1080;
        goto nT6Bt;
        FNiQX:
        $mHpZt = $ozLRl;
        goto CNC49;
        FIbxZ:
        $YDVY8 = $this->Zzac4 * $c2579;
        goto u0NYm;
        cLmFk:
        qH4di:
        goto DL6df;
        Iqrn_:
        if (!($mHpZt < 2)) {
            goto qH4di;
        }
        goto c24Dp;
        nIHDR:
        $NaxNH = $this->RVbPJ * $c2579;
        goto N82FS;
        htHVK:
        $aRSV3 = $ozLRl;
        goto sZo8B;
        rTUk6:
        LAKkP:
        goto htHVK;
        nT6Bt:
        $mHpZt = 0;
        goto w4S3u;
        sZo8B:
        $c2579 = $aRSV3 / $this->RVbPJ;
        goto FIbxZ;
        pgi6Z:
    }
}
