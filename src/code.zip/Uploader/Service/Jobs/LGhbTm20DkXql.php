<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\KyoDVfv3eGItF\Interfaces\ImageInterface;
use Intervention\KyoDVfv3eGItF\Typography\FontFactory;
class LGhbTm20DkXql
{
    private $XsZUt;
    private $Fv8Ey;
    private $Mayr9;
    private $TD3CW;
    public function __construct($K0xgM, $vKBlW, $KI4Gx, $e3uVO)
    {
        goto DJu8J;
        ALVJc:
        $this->TD3CW = $e3uVO;
        goto rx2PZ;
        rx2PZ:
        $this->XsZUt = $K0xgM;
        goto K7MBo;
        hIkN9:
        $this->Mayr9 = $KI4Gx;
        goto ALVJc;
        DJu8J:
        $this->Fv8Ey = $vKBlW;
        goto hIkN9;
        K7MBo:
    }
    public function mNPBpvIvThx(?int $tz4Lg, ?int $vmBjz, string $Z9AwD, bool $eh2hX = false) : string
    {
        goto OEdqI;
        J68RI:
        $M0UwA = $vmBjz - $CJi2N - 10;
        goto azlW2;
        ELHEI:
        $L38Mw = $tz4Lg - $g3NsF;
        goto C1qHd;
        iyzhs:
        if (!($tz4Lg > 1500)) {
            goto UJjjY;
        }
        goto fCA2i;
        lJ62L:
        $Tel1b = 0.1;
        goto UVCVF;
        bnN5z:
        $this->TD3CW->put($HCRCz, $cDDGh->toPng());
        goto SFS31;
        B5xGu:
        UJjjY:
        goto J68RI;
        UVCVF:
        list($CJi2N, $g3NsF, $JLh2l) = $this->mXUyatsadIr($Z9AwD, $tz4Lg, $Tel1b, (float) $tz4Lg / $vmBjz);
        goto fRWD0;
        ve2As:
        return $eh2hX ? $HCRCz : $this->Mayr9->url($HCRCz);
        goto e4xc3;
        nq8L6:
        unset($cDDGh);
        goto ve2As;
        v1J7n:
        if (!$this->Mayr9->exists($HCRCz)) {
            goto OV00T;
        }
        goto tjpwS;
        eKpjv:
        OV00T:
        goto t_ulA;
        tjpwS:
        return $eh2hX ? $HCRCz : $this->Mayr9->url($HCRCz);
        goto eKpjv;
        fRWD0:
        $HCRCz = $this->mmgtEUEQmmE($JLh2l, $tz4Lg, $vmBjz, $g3NsF, $CJi2N);
        goto v1J7n;
        nWSng:
        throw new \RuntimeException("AelPShnd8pMtD dimensions are not available.");
        goto rljjK;
        fCA2i:
        $L38Mw -= $R4QVo * 0.4;
        goto B5xGu;
        SFS31:
        $this->Mayr9->put($HCRCz, $cDDGh->toPng());
        goto nq8L6;
        OEdqI:
        if (!($tz4Lg === null || $vmBjz === null)) {
            goto VOApO;
        }
        goto nWSng;
        DrvKv:
        $L38Mw -= $R4QVo;
        goto iyzhs;
        C1qHd:
        $R4QVo = (int) ($L38Mw / 80);
        goto DrvKv;
        azlW2:
        $cDDGh->text($JLh2l, $L38Mw, (int) $M0UwA, function ($qcDzp) use($CJi2N) {
            goto AL0QY;
            KXDmz:
            $qcDzp->size(max($NkP7w, 1));
            goto NpwtE;
            V0CDW:
            $qcDzp->valign('middle');
            goto Zsu0Y;
            AL0QY:
            $qcDzp->file(public_path($this->Fv8Ey));
            goto nNqyv;
            Zsu0Y:
            $qcDzp->align('middle');
            goto fnnU8;
            NpwtE:
            $qcDzp->color('#B9B9B9');
            goto V0CDW;
            nNqyv:
            $NkP7w = (int) ($CJi2N * 1.2);
            goto KXDmz;
            fnnU8:
        });
        goto bnN5z;
        rljjK:
        VOApO:
        goto lJ62L;
        t_ulA:
        $cDDGh = $this->XsZUt->call($this, $tz4Lg, $vmBjz);
        goto ELHEI;
        e4xc3:
    }
    private function mmgtEUEQmmE(string $Z9AwD, int $tz4Lg, int $vmBjz, int $fgiCc, int $x_F2T) : string
    {
        $pGLcf = ltrim($Z9AwD, '@');
        return "v2/watermark/{$pGLcf}/{$tz4Lg}x{$vmBjz}_{$fgiCc}x{$x_F2T}/text_watermark.png";
    }
    private function mXUyatsadIr($Z9AwD, int $tz4Lg, float $x6JoV, float $J0wvK) : array
    {
        goto iMXWh;
        GGeQf:
        return [(int) $uSU0Y, $uSU0Y * strlen($JLh2l) / 1.8, $JLh2l];
        goto LzA6X;
        DPsGb:
        $uSU0Y = 1 / $J0wvK * $g3NsF / strlen($JLh2l);
        goto E0Cr7;
        LzA6X:
        c7vVn:
        goto DPsGb;
        iMXWh:
        $JLh2l = '@' . $Z9AwD;
        goto lTPpZ;
        lTPpZ:
        $g3NsF = (int) ($tz4Lg * $x6JoV);
        goto HJG52;
        zcQX_:
        $uSU0Y = $g3NsF / (strlen($JLh2l) * 0.8);
        goto GGeQf;
        E0Cr7:
        return [(int) $uSU0Y, $g3NsF, $JLh2l];
        goto aJAxC;
        HJG52:
        if (!($J0wvK > 1)) {
            goto c7vVn;
        }
        goto zcQX_;
        aJAxC:
    }
}
