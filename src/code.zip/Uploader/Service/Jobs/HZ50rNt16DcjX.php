<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
class HZ50rNt16DcjX implements BlurJobInterface
{
    const bTlMo = 15;
    const jH5gF = 500;
    const IIiB9 = 500;
    private $z7YJI;
    private $PxC6l;
    private $MpAl4;
    public function __construct($fvRbj, $kxhX9, $U2KRS)
    {
        goto Y9vXl;
        hxiAT:
        $this->PxC6l = $kxhX9;
        goto MuBcE;
        MuBcE:
        $this->z7YJI = $fvRbj;
        goto tibDP;
        Y9vXl:
        $this->MpAl4 = $U2KRS;
        goto hxiAT;
        tibDP:
    }
    public function blur(string $S580N) : void
    {
        goto SxAjI;
        PIRAZ:
        if (chmod($j4iKK, 0664)) {
            goto ptJdi;
        }
        goto QFc95;
        gsHYz:
        $Tw0WE->update(['preview' => $K5DbU]);
        goto gT5T5;
        l2sG1:
        ptJdi:
        goto gsHYz;
        QFc95:
        \Log::warning('Failed to set final permissions on image file: ' . $j4iKK);
        goto KmW2J;
        SxAjI:
        $Tw0WE = KfEJaEGpFJ0tm::findOrFail($S580N);
        goto dVI7S;
        Jd0tu:
        wFY0X:
        goto cBwfg;
        ZFM_l:
        $gNhb4->resize(self::jH5gF, self::IIiB9 / $JC9uJ);
        goto t0kJm;
        cVX9d:
        unset($gNhb4);
        goto PIRAZ;
        KmW2J:
        throw new \Exception('Failed to set final permissions on image file: ' . $j4iKK);
        goto l2sG1;
        Us0gH:
        $j4iKK = $this->PxC6l->put($K5DbU, $gNhb4->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto cVX9d;
        s98G6:
        $JC9uJ = $gNhb4->width() / $gNhb4->height();
        goto ZFM_l;
        xqRlY:
        if (!($Tw0WE->gUPdP == McZXbZmlQ53or::S3 && !$this->MpAl4->exists($Tw0WE->filename))) {
            goto wFY0X;
        }
        goto Quu4B;
        Pd5Z1:
        $K5DbU = $this->mE1oPwTqx6V($Tw0WE);
        goto Us0gH;
        Quu4B:
        $UPqRI = $this->PxC6l->get($Tw0WE->filename);
        goto VmCgw;
        cBwfg:
        $gNhb4 = $this->z7YJI->call($this, $this->MpAl4->path($Tw0WE->getLocation()));
        goto s98G6;
        VmCgw:
        $this->MpAl4->put($Tw0WE->filename, $UPqRI);
        goto Jd0tu;
        t0kJm:
        $gNhb4->blur(self::bTlMo);
        goto Pd5Z1;
        dVI7S:
        ini_set('memory_limit', '-1');
        goto xqRlY;
        gT5T5:
    }
    private function mE1oPwTqx6V($BhlEo) : string
    {
        goto ivqew;
        jEFBW:
        $zVNDR = dirname($d1QWa) . '/preview/';
        goto XeXo8;
        tHVgw:
        $this->MpAl4->makeDirectory($zVNDR, 0755, true);
        goto E030r;
        XeXo8:
        if ($this->MpAl4->exists($zVNDR)) {
            goto LLOqP;
        }
        goto tHVgw;
        E030r:
        LLOqP:
        goto UTCiV;
        ivqew:
        $d1QWa = $BhlEo->getLocation();
        goto jEFBW;
        UTCiV:
        return $zVNDR . $BhlEo->getFilename() . '.jpg';
        goto GdqJP;
        GdqJP:
    }
}
