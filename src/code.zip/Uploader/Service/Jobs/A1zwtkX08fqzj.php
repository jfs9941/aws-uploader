<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Illuminate\Support\Facades\Log;
class A1zwtkX08fqzj implements DownloadToLocalJobInterface
{
    private $RE_2F;
    private $F8ilg;
    public function __construct($WmwnR, $Pkopf)
    {
        $this->RE_2F = $WmwnR;
        $this->F8ilg = $Pkopf;
    }
    public function download(string $LpGEK) : void
    {
        goto ltDyS;
        ltDyS:
        $RCdwx = X9YHjKrAdcfhe::findOrFail($LpGEK);
        goto STNx3;
        Vtsc7:
        $this->F8ilg->put($RCdwx->getLocation(), $this->RE_2F->get($RCdwx->getLocation()));
        goto fuORm;
        cDlML:
        return;
        goto uH0lc;
        uH0lc:
        QV31T:
        goto Vtsc7;
        VlEKL:
        if (!$this->F8ilg->exists($RCdwx->getLocation())) {
            goto QV31T;
        }
        goto cDlML;
        STNx3:
        Log::info("Start download file to local", ['fileId' => $LpGEK, 'filename' => $RCdwx->getLocation()]);
        goto VlEKL;
        fuORm:
    }
}
