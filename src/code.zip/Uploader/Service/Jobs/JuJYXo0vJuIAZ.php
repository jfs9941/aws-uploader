<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
class JuJYXo0vJuIAZ implements GenerateThumbnailJobInterface
{
    const DJPIp = 150;
    const adkDy = 150;
    private $IfECA;
    private $uBhrQ;
    public function __construct($AaIEl, $Ms6sq)
    {
        $this->IfECA = $AaIEl;
        $this->uBhrQ = $Ms6sq;
    }
    public function generate(string $S6xyJ)
    {
        goto QM6so;
        qXuZR:
        ini_set('memory_limit', '-1');
        goto J1LOG;
        QM6so:
        Log::info("Generating thumbnail", ['imageId' => $S6xyJ]);
        goto qXuZR;
        J1LOG:
        try {
            goto wnvtd;
            wnvtd:
            $TuWZt = $this->uBhrQ;
            goto rCkzc;
            Bh_rT:
            if (chmod($rcNa_, 0644)) {
                goto KkKKh;
            }
            goto I9c9o;
            e_2ln:
            throw new \Exception('Failed to set file permissions for stored image: ' . $rcNa_);
            goto zjxRA;
            n1kHe:
            $QDo5o = $this->IfECA->call($this, $TuWZt->path($iy9bs->getLocation()));
            goto JV61E;
            I9c9o:
            Log::warning('Failed to set file permissions for stored image: ' . $rcNa_);
            goto e_2ln;
            JV61E:
            $QDo5o->fit(150, 150, function ($Gl6kc) {
                $Gl6kc->aspectRatio();
            });
            goto M7mHW;
            M7mHW:
            $QDo5o->encode('jpg', 80);
            goto KqYHi;
            Q13ww:
            $QDo5o->destroy();
            goto llLHU;
            llLHU:
            if (!($Fhaq8 !== false)) {
                goto C0TiL;
            }
            goto CMANM;
            KqYHi:
            $z69yI = $this->mnofwe5vgIs($iy9bs);
            goto efKQA;
            zjxRA:
            KkKKh:
            goto xTlDw;
            xTlDw:
            C0TiL:
            goto u05I7;
            CMANM:
            $iy9bs->update(['thumbnail' => $z69yI, 'status' => EUkqoDwU9Zcvh::THUMBNAIL_PROCESSED]);
            goto DlXr4;
            DlXr4:
            $rcNa_ = $TuWZt->path($z69yI);
            goto Bh_rT;
            rCkzc:
            $iy9bs = JyZaxpharsbun::findOrFail($S6xyJ);
            goto n1kHe;
            efKQA:
            $Fhaq8 = $TuWZt->put($z69yI, $QDo5o->stream(), ['visibility' => 'public']);
            goto Q13ww;
            u05I7:
        } catch (ModelNotFoundException $WTk3U) {
            Log::info("JyZaxpharsbun has been deleted, discard it", ['imageId' => $S6xyJ]);
            return;
        }
        goto uJsfx;
        uJsfx:
    }
    private function mnofwe5vgIs(DMUaxGX7XHAI0 $iy9bs) : string
    {
        goto znGzp;
        qDpCO:
        $sSGQz = dirname($z69yI);
        goto xAYxB;
        znGzp:
        $z69yI = $iy9bs->getLocation();
        goto qDpCO;
        ezC0C:
        return $lvpvw . '/' . $iy9bs->getFilename() . '.jpg';
        goto aXqX7;
        xAYxB:
        $lvpvw = $sSGQz . '/' . self::DJPIp . 'X' . self::adkDy;
        goto ezC0C;
        aXqX7:
    }
}
