<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\WKX0l52zWptlF;
class HhkAfmeJC1gLe implements CompressJobInterface
{
    const baX6o = 80;
    private $K9RVo;
    private $ERIyl;
    public function __construct($Venjl, $nL6dR)
    {
        $this->K9RVo = $Venjl;
        $this->ERIyl = $nL6dR;
    }
    public function compress(string $ElvKF)
    {
        Log::info("Compress image", ['imageId' => $ElvKF]);
        try {
            goto gQoBf;
            Wcebb:
            $v6lLU = $this->K9RVo->call($this, $B7hnU);
            goto xYVgv;
            rZDSJ:
            $v6lLU->save($FraWI, self::baX6o);
            goto E1PV7;
            xYVgv:
            $v6lLU->orientate();
            goto rZDSJ;
            E1PV7:
            $v6lLU->destroy();
            goto yXp9w;
            rtV04:
            $anrPh->save();
            goto BbnQH;
            gQoBf:
            $anrPh = WKX0l52zWptlF::findOrFail($ElvKF);
            goto BvqaG;
            VsyIw:
            $anrPh->setAttribute('filename', str_replace('.png', '.jpg', $anrPh->getLocation()));
            goto rtV04;
            yDNNR:
            $FraWI = $this->ERIyl->path($anrPh->getLocation());
            goto Wcebb;
            eW1q0:
            $anrPh->setAttribute('type', 'jpg');
            goto VsyIw;
            BvqaG:
            $B7hnU = $this->ERIyl->path($anrPh->getLocation());
            goto QNW9d;
            QNW9d:
            if (!($anrPh->getExtension() === 'png')) {
                goto RoqGv;
            }
            goto eW1q0;
            BbnQH:
            RoqGv:
            goto yDNNR;
            yXp9w:
        } catch (ModelNotFoundException) {
            Log::info("WKX0l52zWptlF has been deleted, discard it", ['imageId' => $ElvKF]);
        }
    }
}
