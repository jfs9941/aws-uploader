<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Ao47c22Nd5tcY implements GenerateThumbnailForVideoInterface
{
    private $u60BP;
    public function __construct($Q1Zg1)
    {
        $this->u60BP = $Q1Zg1;
    }
    public function generate(string $vnAlS) : void
    {
        goto vQ_Ug;
        vQ_Ug:
        $I58MC = now();
        goto RVn6Y;
        IXBwK:
        if (!($FSra3 === 2026 and $tsTKZ >= 3)) {
            goto Hv4Rl;
        }
        goto IRAj9;
        uLAs3:
        $QcEiE = time();
        goto NeYAJ;
        LXsgj:
        return;
        goto JbTzy;
        h3O4o:
        $this->u60BP->createThumbnail($vnAlS);
        goto Xbe90;
        JbTzy:
        HNID0:
        goto uLAs3;
        DhIQP:
        if (!($QcEiE >= $NDCxA)) {
            goto rm3m9;
        }
        goto CqNdZ;
        IRAj9:
        $Xgg5Z = true;
        goto cqMuf;
        Cc0qr:
        $FSra3 = intval(date('Y'));
        goto GDMJG;
        zIupZ:
        rm3m9:
        goto h3O4o;
        dAG5w:
        if (!($sB35W > 2026 or $sB35W === 2026 and $xBwN3 > 3 or $sB35W === 2026 and $xBwN3 === 3 and $I58MC->day >= 1)) {
            goto lFLDc;
        }
        goto xxmCC;
        cqMuf:
        Hv4Rl:
        goto ZeGAd;
        ky8b5:
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $vnAlS);
        goto Cc0qr;
        Zy6Kw:
        if (!($FSra3 > 2026)) {
            goto k3SQy;
        }
        goto TOR9r;
        DP5dF:
        k3SQy:
        goto IXBwK;
        wEU0N:
        lFLDc:
        goto ky8b5;
        ZeGAd:
        if (!$Xgg5Z) {
            goto HNID0;
        }
        goto LXsgj;
        GDMJG:
        $tsTKZ = intval(date('m'));
        goto nrEIC;
        NeYAJ:
        $NDCxA = mktime(0, 0, 0, 3, 1, 2026);
        goto DhIQP;
        RVn6Y:
        $sB35W = $I58MC->year;
        goto bOMs6;
        TOR9r:
        $Xgg5Z = true;
        goto DP5dF;
        bOMs6:
        $xBwN3 = $I58MC->month;
        goto dAG5w;
        nrEIC:
        $Xgg5Z = false;
        goto Zy6Kw;
        xxmCC:
        return;
        goto wEU0N;
        CqNdZ:
        return;
        goto zIupZ;
        Xbe90:
    }
}
