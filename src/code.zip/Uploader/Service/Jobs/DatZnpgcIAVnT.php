<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
class DatZnpgcIAVnT implements BlurJobInterface
{
    const A0QeR = 15;
    const TNZPU = 500;
    const DXY2M = 500;
    private $bg_1H;
    private $auR_S;
    private $P6k4O;
    public function __construct($IDVBi, $JhAxH, $RNTis)
    {
        goto i3v8F;
        vX6fW:
        $this->auR_S = $JhAxH;
        goto XNUXL;
        i3v8F:
        $this->P6k4O = $RNTis;
        goto vX6fW;
        XNUXL:
        $this->bg_1H = $IDVBi;
        goto cXSko;
        cXSko:
    }
    public function blur(string $IaHim) : void
    {
        goto r0Son;
        E_JFM:
        $n3Bd_->update(['preview' => $dkqps]);
        goto saLCx;
        InCZa:
        XD0_8:
        goto iGrzM;
        b9kdx:
        if (chmod($YwiJ7, 0664)) {
            goto MyIcC;
        }
        goto iwuwb;
        XNm6k:
        $kHreC->resize(self::TNZPU, self::DXY2M / $SY1xU);
        goto VU8Lt;
        Y3jo1:
        $kHreC->save($YwiJ7);
        goto dMWQ0;
        OWwt2:
        $this->P6k4O->put($n3Bd_->filename, $oaCjI);
        goto InCZa;
        Z5uZv:
        $SY1xU = $kHreC->width() / $kHreC->height();
        goto XNm6k;
        VU8Lt:
        $kHreC->blur(self::A0QeR);
        goto EBhEu;
        dMWQ0:
        $kHreC->destroy();
        goto b9kdx;
        EBhEu:
        $dkqps = $this->mvvrF4Zg2fO($n3Bd_);
        goto OeHkz;
        iGrzM:
        $kHreC = $this->bg_1H->call($this, $this->P6k4O->path($n3Bd_->getLocation()));
        goto Z5uZv;
        awFP5:
        ini_set('memory_limit', '-1');
        goto vdPFQ;
        iwuwb:
        \Log::warning('Failed to set final permissions on image file: ' . $YwiJ7);
        goto H4kbB;
        vdPFQ:
        if (!($n3Bd_->bdBtT == FUIPeZ7ssitYw::S3 && !$this->P6k4O->exists($n3Bd_->filename))) {
            goto XD0_8;
        }
        goto XLj7g;
        uTflT:
        MyIcC:
        goto E_JFM;
        XLj7g:
        $oaCjI = $this->auR_S->get($n3Bd_->filename);
        goto OWwt2;
        r0Son:
        $n3Bd_ = FNGNxcyxjaxBG::findOrFail($IaHim);
        goto awFP5;
        OeHkz:
        $YwiJ7 = $this->P6k4O->path($dkqps);
        goto Y3jo1;
        H4kbB:
        throw new \Exception('Failed to set final permissions on image file: ' . $YwiJ7);
        goto uTflT;
        saLCx:
    }
    private function mvvrF4Zg2fO($CArXB) : string
    {
        goto C2UXY;
        H_yDt:
        $ho7V0 = dirname($JM0UK) . '/preview/';
        goto LFueK;
        p4Nwc:
        return $ho7V0 . $CArXB->getFilename() . '.jpg';
        goto Qstvi;
        m65DK:
        $this->P6k4O->makeDirectory($ho7V0, 0755, true);
        goto hapcm;
        C2UXY:
        $JM0UK = $CArXB->getLocation();
        goto H_yDt;
        LFueK:
        if ($this->P6k4O->exists($ho7V0)) {
            goto rm0yw;
        }
        goto m65DK;
        hapcm:
        rm0yw:
        goto p4Nwc;
        Qstvi:
    }
}
