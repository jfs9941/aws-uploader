<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class SWUwFIAVXk4XG implements GenerateThumbnailJobInterface
{
    const ANrIH = 150;
    const jYR2C = 150;
    private $xy0Yf;
    private $mzObC;
    private $eUSBH;
    public function __construct($ppK7O, $L1VX0, $rDA3i)
    {
        goto TDVNO;
        Pvo2w:
        $this->mzObC = $L1VX0;
        goto f0LlN;
        TDVNO:
        $this->xy0Yf = $ppK7O;
        goto Pvo2w;
        f0LlN:
        $this->eUSBH = $rDA3i;
        goto EkRNE;
        EkRNE:
    }
    public function generate(string $J_scC)
    {
        goto azdu6;
        BIfHG:
        ini_set('memory_limit', '-1');
        goto yBCo6;
        azdu6:
        Log::info("Generating thumbnail", ['imageId' => $J_scC]);
        goto BIfHG;
        yBCo6:
        try {
            goto Pt1Eq;
            BWmQC:
            $hU2b_ = $this->mKTAZroKjOI($VWXEV);
            goto qkW42;
            xvmiR:
            unset($sktuB);
            goto TaFTc;
            iFyOJ:
            d6zH7:
            goto F4pbO;
            qkW42:
            $j9qnL = $this->eUSBH->put($hU2b_, $sktuB->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto xvmiR;
            PgMeg:
            $VWXEV = XK5kReLMTU1ob::findOrFail($J_scC);
            goto qMU0K;
            r7ziO:
            $VWXEV->update(['thumbnail' => $hU2b_, 'status' => EpMPhiTVzNYqA::THUMBNAIL_PROCESSED]);
            goto iFyOJ;
            qMU0K:
            $sktuB = $this->xy0Yf->call($this, $RndMA->path($VWXEV->getLocation()));
            goto txrQZ;
            txrQZ:
            $sktuB->orient()->resize(150, 150);
            goto BWmQC;
            TaFTc:
            if (!($j9qnL !== false)) {
                goto d6zH7;
            }
            goto r7ziO;
            Pt1Eq:
            $RndMA = $this->mzObC;
            goto PgMeg;
            F4pbO:
        } catch (ModelNotFoundException $XViIf) {
            Log::info("XK5kReLMTU1ob has been deleted, discard it", ['imageId' => $J_scC]);
            return;
        } catch (\Exception $XViIf) {
            Log::error("Failed to generate thumbnail", ['imageId' => $J_scC, 'error' => $XViIf->getMessage()]);
        }
        goto UsvWv;
        UsvWv:
    }
    private function mKTAZroKjOI(KFe2ZCctciwsA $VWXEV) : string
    {
        goto rS59a;
        ZDUPh:
        $UW46t = $uH7tx . '/' . self::ANrIH . 'X' . self::jYR2C;
        goto VnogR;
        uZ11U:
        $uH7tx = dirname($hU2b_);
        goto ZDUPh;
        VnogR:
        return $UW46t . '/' . $VWXEV->getFilename() . '.jpg';
        goto w2B9y;
        rS59a:
        $hU2b_ = $VWXEV->getLocation();
        goto uZ11U;
        w2B9y:
    }
}
