<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class PcyDFjxwhaJkE
{
    private $CsR73;
    private $lanUP;
    public function __construct(int $YIZW2, int $sadYt)
    {
        goto zSeNL;
        FZC5m:
        HZxqM:
        goto vY3BC;
        kvIEA:
        $this->lanUP = $sadYt;
        goto foUF6;
        vY3BC:
        $this->CsR73 = $YIZW2;
        goto kvIEA;
        cKeX2:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto FZC5m;
        zSeNL:
        if (!($YIZW2 <= 0)) {
            goto Ra06b;
        }
        goto xV3fm;
        GnmDU:
        if (!($sadYt <= 0)) {
            goto HZxqM;
        }
        goto cKeX2;
        xV3fm:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto oW8FL;
        oW8FL:
        Ra06b:
        goto GnmDU;
        foUF6:
    }
    private static function ma5oOqJ5pYI($tip61, string $ufi9L = 'floor') : int
    {
        goto nwcJ5;
        nwcJ5:
        if (!(is_int($tip61) && $tip61 % 2 === 0)) {
            goto Sw1nE;
        }
        goto jJn4q;
        SYtpk:
        Sw1nE:
        goto Y6evD;
        jJn4q:
        return $tip61;
        goto SYtpk;
        kvQE4:
        switch (strtolower($ufi9L)) {
            case 'ceil':
                return (int) (ceil($tip61 / 2) * 2);
            case 'round':
                return (int) (round($tip61 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($tip61 / 2) * 2);
        }
        goto wcxzK;
        I5R5k:
        return (int) $tip61;
        goto AlbR5;
        Y6evD:
        if (!(is_float($tip61) && $tip61 == floor($tip61) && (int) $tip61 % 2 === 0)) {
            goto l80EV;
        }
        goto I5R5k;
        wcxzK:
        U3b1B:
        goto O8dJL;
        O8dJL:
        qZr_X:
        goto lkRYr;
        AlbR5:
        l80EV:
        goto kvQE4;
        lkRYr:
    }
    public function mmVTXzOoiLf(string $BTbkd = 'floor') : array
    {
        goto Qq4MJ;
        H1GJD:
        yeCGi:
        goto EYHO6;
        MZe26:
        $f82Ak = 0;
        goto LzjnR;
        AnzFQ:
        return ['width' => $gvI4m, 'height' => $f82Ak];
        goto Ya4UV;
        tlthG:
        $gvI4m = $h3U2A;
        goto bRJXp;
        b1chP:
        $Ns1yG = $f82Ak / $this->lanUP;
        goto hulBw;
        Z41Me:
        $gvI4m = 2;
        goto oncHI;
        BjOMA:
        $gvI4m = 0;
        goto MZe26;
        fC1t5:
        goto yeCGi;
        goto K0xMh;
        EYHO6:
        if (!($gvI4m < 2)) {
            goto daP4G;
        }
        goto Z41Me;
        PvbF2:
        $f82Ak = 2;
        goto ChlUM;
        ChlUM:
        Xm6TK:
        goto AnzFQ;
        oncHI:
        daP4G:
        goto Uklx8;
        Fjs5C:
        $f82Ak = $h3U2A;
        goto b1chP;
        Qq4MJ:
        $h3U2A = 1080;
        goto BjOMA;
        Uklx8:
        if (!($f82Ak < 2)) {
            goto Xm6TK;
        }
        goto PvbF2;
        K0xMh:
        DT8ZY:
        goto Fjs5C;
        CZQS5:
        $gvI4m = self::ma5oOqJ5pYI(round($HlJdh), $BTbkd);
        goto H1GJD;
        Y4tYM:
        $l4Ll1 = $this->lanUP * $Ns1yG;
        goto l58ar;
        LzjnR:
        if ($this->CsR73 >= $this->lanUP) {
            goto DT8ZY;
        }
        goto tlthG;
        l58ar:
        $f82Ak = self::ma5oOqJ5pYI(round($l4Ll1), $BTbkd);
        goto fC1t5;
        bRJXp:
        $Ns1yG = $gvI4m / $this->CsR73;
        goto Y4tYM;
        hulBw:
        $HlJdh = $this->CsR73 * $Ns1yG;
        goto CZQS5;
        Ya4UV:
    }
}
