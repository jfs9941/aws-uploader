<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class MUj7qNTqyUnPf implements GenerateThumbnailForVideoInterface
{
    private $ssrI7;
    public function __construct($apPS_)
    {
        $this->ssrI7 = $apPS_;
    }
    public function generate(string $ShXx2) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $ShXx2);
        $this->ssrI7->createThumbnail($ShXx2);
    }
}
