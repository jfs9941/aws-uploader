<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Encoder\FcRTXS1DgCu2b;
use Jfs\Uploader\Encoder\N5IONLvfizlXB;
use Jfs\Uploader\Encoder\O4lVkPvpn6cme;
use Jfs\Uploader\Encoder\AB1zr7gVTXVIM;
use Jfs\Uploader\Encoder\FhlmmSZhUQ7B8;
use Jfs\Uploader\Encoder\OzgH8oKjuAzfW;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Jfs\Uploader\Service\Jobs\ImR2RBQBrahNh;
use Jfs\Uploader\Service\Jobs\H09smfnGPffl7;
use Jfs\Uploader\Service\XxTGlKndb3r5q;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class Kj8R2ay3IQqos implements MediaEncodeJobInterface
{
    private $omjLi;
    private $W2Sfl;
    private $uiTOc;
    private $ScRnx;
    private $Daa3m;
    public function __construct(string $O893k, $d_Wiu, $ATeSz, $tUc4C, $gQHhb)
    {
        goto AemvT;
        sBHJl:
        $this->ScRnx = $tUc4C;
        goto atzZt;
        AemvT:
        $this->omjLi = $O893k;
        goto KpTMo;
        KpTMo:
        $this->W2Sfl = $d_Wiu;
        goto Pkq0Q;
        atzZt:
        $this->Daa3m = $gQHhb;
        goto GIiai;
        Pkq0Q:
        $this->uiTOc = $ATeSz;
        goto sBHJl;
        GIiai:
    }
    public function encode(string $B_L9m, string $i4v7Y, $Ne6qE = true) : void
    {
        goto Q2UQ6;
        EfaYf:
        ini_set('memory_limit', '-1');
        goto VbsvR;
        VbsvR:
        try {
            goto Hxxx5;
            dV8Tn:
            Log::info("Set input video for Job", ['s3Uri' => $V7lhS]);
            goto B9hLp;
            up3f2:
            $V7lhS = $this->mbX0xJUlnfq($QCHmE);
            goto dV8Tn;
            c9JGt:
            $DTD0q->mfCtO1syYcq($hNWjg->mJ2UMQMVQsK($QCHmE));
            goto aGwZx;
            Hxxx5:
            $QCHmE = U9HMl0N8dP0ZH::findOrFail($B_L9m);
            goto KNHeF;
            ab6ZH:
            $DTD0q = $DTD0q->mSmTcfzKCKL(new AB1zr7gVTXVIM($V7lhS));
            goto HQOpI;
            qrD60:
            $DTD0q = $DTD0q->mrrvD6Mk756($Fg8fa);
            goto zBdyg;
            HQOpI:
            $MS0jf = new N5IONLvfizlXB('original', $BKFYC, $ZDe2g, $QCHmE->F2Mlr ?? 30);
            goto PiaDt;
            KFW1Z:
            if (!($QCHmE->euRQL !== J0IuL8wroLOWt::S3)) {
                goto LXizV;
            }
            goto yE4PN;
            j8qWo:
            Log::info("Set thumbnail for U9HMl0N8dP0ZH Job", ['videoId' => $QCHmE->getAttribute('id'), 'duration' => $QCHmE->getAttribute('duration')]);
            goto O88yG;
            F0InI:
            $DTD0q = $DTD0q->mTdFt36cBRn($i7XwP);
            goto g44xU;
            ltGQz:
            if (!$this->mR37cCAIBGt($BKFYC, $ZDe2g)) {
                goto qcOoQ;
            }
            goto PPF5E;
            hp8ZJ:
            LXizV:
            goto kIkuI;
            O88yG:
            $i7XwP = new FcRTXS1DgCu2b($QCHmE->be2Dj ?? 1, 2, $hNWjg->mDxawBhtXH2($QCHmE));
            goto F0InI;
            xaLx7:
            $QCHmE->update(['aws_media_converter_job_id' => $B_L9m]);
            goto kedep;
            xjBgy:
            QQQt0:
            goto qrD60;
            BbnWp:
            $Fg8fa = $Fg8fa->mBwzh0U9GWp($uXVJz);
            goto xjBgy;
            kIkuI:
            $BKFYC = $QCHmE->width();
            goto S0xtb;
            sF85J:
            $Cn0jL = new H09smfnGPffl7($this->ScRnx, $this->Daa3m, $this->uiTOc, $this->W2Sfl);
            goto uWgXh;
            QVSuf:
            $DTD0q->mrrvD6Mk756($MS0jf);
            goto c9JGt;
            S0xtb:
            $ZDe2g = $QCHmE->height();
            goto up3f2;
            nylfx:
            $Fg8fa = new N5IONLvfizlXB('1080p', $sJdHA['width'], $sJdHA['height'], $QCHmE->F2Mlr ?? 30);
            goto msrgi;
            msrgi:
            $uXVJz = $this->mtnsG48LOSB($FpmNM, $Cn0jL->mR2ojYBGTKb((int) $sJdHA['width'], (int) $sJdHA['height'], $i4v7Y));
            goto ZpwvX;
            aGwZx:
            if (!($BKFYC && $ZDe2g)) {
                goto k0W8h;
            }
            goto ltGQz;
            uWgXh:
            $uXVJz = $this->mtnsG48LOSB($FpmNM, $Cn0jL->mR2ojYBGTKb($QCHmE->width(), $QCHmE->height(), $i4v7Y));
            goto vuQfJ;
            BX2yg:
            $MS0jf = $MS0jf->mBwzh0U9GWp($uXVJz);
            goto xUkvf;
            PPF5E:
            $sJdHA = $this->mWIH3KELEAs($BKFYC, $ZDe2g);
            goto Vn5QN;
            HRkns:
            $FpmNM = app(XxTGlKndb3r5q::class);
            goto sF85J;
            zBdyg:
            qcOoQ:
            goto Atk_L;
            PiaDt:
            $hNWjg = app(O4lVkPvpn6cme::class);
            goto EU42l;
            ZpwvX:
            if (!$uXVJz) {
                goto QQQt0;
            }
            goto BbnWp;
            g44xU:
            $B_L9m = $DTD0q->mxTnwNqG8Jk($this->mC0aYWyY2T9($QCHmE, $Ne6qE));
            goto xaLx7;
            Atk_L:
            k0W8h:
            goto j8qWo;
            KNHeF:
            Assert::isInstanceOf($QCHmE, U9HMl0N8dP0ZH::class);
            goto KFW1Z;
            EU42l:
            $DTD0q->mrrvD6Mk756($MS0jf);
            goto bLFEW;
            yE4PN:
            throw new MediaConverterException("U9HMl0N8dP0ZH {$QCHmE->id} is not S3 driver");
            goto hp8ZJ;
            Vn5QN:
            Log::info("Set 1080p resolution for Job", ['width' => $sJdHA['width'], 'height' => $sJdHA['height'], 'originalWidth' => $BKFYC, 'originalHeight' => $ZDe2g]);
            goto nylfx;
            B9hLp:
            $DTD0q = app(FhlmmSZhUQ7B8::class);
            goto ab6ZH;
            bLFEW:
            $DTD0q->mfCtO1syYcq($hNWjg->mJ2UMQMVQsK($QCHmE));
            goto HRkns;
            vuQfJ:
            if (!$uXVJz) {
                goto Q_Wro;
            }
            goto BX2yg;
            xUkvf:
            Q_Wro:
            goto QVSuf;
            kedep:
        } catch (\Exception $bIOBo) {
            Log::info("U9HMl0N8dP0ZH has been deleted, discard it", ['fileId' => $B_L9m, 'err' => $bIOBo->getMessage()]);
            return;
        }
        goto pZHaX;
        Q2UQ6:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $B_L9m]);
        goto EfaYf;
        pZHaX:
    }
    private function mC0aYWyY2T9(U9HMl0N8dP0ZH $QCHmE, $Ne6qE) : bool
    {
        goto lvjb7;
        Awh8R:
        $Vcmsu = (int) round($QCHmE->getAttribute('duration') ?? 0);
        goto ymwDz;
        iaVFF:
        sJxRA:
        goto Awh8R;
        wJJj8:
        XvnnT:
        goto EmqvI;
        lvjb7:
        if ($Ne6qE) {
            goto sJxRA;
        }
        goto iGQxa;
        ymwDz:
        switch (true) {
            case $QCHmE->width() * $QCHmE->height() >= 1920 * 1080 && $QCHmE->width() * $QCHmE->height() < 2560 * 1440:
                return $Vcmsu > 10 * 60;
            case $QCHmE->width() * $QCHmE->height() >= 2560 * 1440 && $QCHmE->width() * $QCHmE->height() < 3840 * 2160:
                return $Vcmsu > 5 * 60;
            case $QCHmE->width() * $QCHmE->height() >= 3840 * 2160:
                return $Vcmsu > 3 * 60;
            default:
                return false;
        }
        goto aqrQA;
        aqrQA:
        ST2KC:
        goto wJJj8;
        iGQxa:
        return false;
        goto iaVFF;
        EmqvI:
    }
    private function mtnsG48LOSB(XxTGlKndb3r5q $FpmNM, string $JyzhY) : ?OzgH8oKjuAzfW
    {
        goto i6Uw2;
        Qmsvw:
        return new OzgH8oKjuAzfW($GGB7r, 0, 0, null, null);
        goto ZAKIZ;
        qy_BG:
        Log::info("Resolve watermark for job with url", ['url' => $JyzhY, 'uri' => $GGB7r]);
        goto JN7oT;
        i6Uw2:
        $GGB7r = $FpmNM->mLMEQYOm9i9($JyzhY);
        goto qy_BG;
        ZAKIZ:
        rqakA:
        goto U3zYx;
        JN7oT:
        if (!$GGB7r) {
            goto rqakA;
        }
        goto Qmsvw;
        U3zYx:
        return null;
        goto SLbuk;
        SLbuk:
    }
    private function mR37cCAIBGt(int $BKFYC, int $ZDe2g) : bool
    {
        return $BKFYC * $ZDe2g > 1.5 * (1920 * 1080);
    }
    private function mWIH3KELEAs(int $BKFYC, int $ZDe2g) : array
    {
        $fLnjT = new ImR2RBQBrahNh($BKFYC, $ZDe2g);
        return $fLnjT->mmJk1byti6a();
    }
    private function mbX0xJUlnfq(Zl4rdW32ufaUx $vPecg) : string
    {
        goto MrYjT;
        hyTmr:
        uadTz:
        goto qFVwU;
        qFVwU:
        return $this->W2Sfl->url($vPecg->filename);
        goto zX8IT;
        taW1T:
        return 's3://' . $this->omjLi . '/' . $vPecg->filename;
        goto hyTmr;
        MrYjT:
        if (!($vPecg->euRQL == J0IuL8wroLOWt::S3)) {
            goto uadTz;
        }
        goto taW1T;
        zX8IT:
    }
}
