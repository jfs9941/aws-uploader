<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class CqS1mpKkV7Z4F
{
    private $uf3Xu;
    private $cpfum;
    public function __construct(int $c0PSD, int $DRwKH)
    {
        goto ZraeR;
        pNwFS:
        $this->uf3Xu = $c0PSD;
        goto YszVL;
        ZraeR:
        if (!($c0PSD <= 0)) {
            goto nvamD;
        }
        goto Rw8hC;
        QcV9r:
        eK269:
        goto pNwFS;
        qoNdz:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto QcV9r;
        OnV3T:
        nvamD:
        goto AicnS;
        YszVL:
        $this->cpfum = $DRwKH;
        goto kZy2V;
        Rw8hC:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto OnV3T;
        AicnS:
        if (!($DRwKH <= 0)) {
            goto eK269;
        }
        goto qoNdz;
        kZy2V:
    }
    private static function mqQKe1wuRKd($DRYTf, string $c70Ep = 'floor') : int
    {
        goto ca1wC;
        Gkn4h:
        rO2pi:
        goto UyAXX;
        YAxly:
        return $DRYTf;
        goto Gkn4h;
        CC1iu:
        BTfVk:
        goto tWKsL;
        W3cZz:
        Q8cm_:
        goto ZwjwC;
        tWKsL:
        switch (strtolower($c70Ep)) {
            case 'ceil':
                return (int) (ceil($DRYTf / 2) * 2);
            case 'round':
                return (int) (round($DRYTf / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($DRYTf / 2) * 2);
        }
        goto mqJWY;
        mqJWY:
        TEY8y:
        goto W3cZz;
        yqY5f:
        return (int) $DRYTf;
        goto CC1iu;
        ca1wC:
        if (!(is_int($DRYTf) && $DRYTf % 2 === 0)) {
            goto rO2pi;
        }
        goto YAxly;
        UyAXX:
        if (!(is_float($DRYTf) && $DRYTf == floor($DRYTf) && (int) $DRYTf % 2 === 0)) {
            goto BTfVk;
        }
        goto yqY5f;
        ZwjwC:
    }
    public function mtPJz994WEd(string $iGhIj = 'floor') : array
    {
        goto SFu7B;
        TolbL:
        W1i8E:
        goto LtiIa;
        JFR3v:
        if ($this->uf3Xu >= $this->cpfum) {
            goto x8hys;
        }
        goto fVvRt;
        TsU3Q:
        if (!($seSfM < 2)) {
            goto W1i8E;
        }
        goto fe1Wd;
        wH6rq:
        $E5EGT = self::mqQKe1wuRKd(round($knxvE), $iGhIj);
        goto hLBmQ;
        IH_Md:
        sh7Sf:
        goto o0LsA;
        O9_m9:
        BDWjN:
        goto TsU3Q;
        Etux3:
        $seSfM = self::mqQKe1wuRKd(round($SyTjX), $iGhIj);
        goto O9_m9;
        NPNWl:
        $lC6G4 = $E5EGT / $this->cpfum;
        goto pgvbU;
        pk0FZ:
        $seSfM = 0;
        goto bTJ_p;
        DbUdh:
        $E5EGT = $iEY_Z;
        goto NPNWl;
        M8Kjx:
        $lC6G4 = $seSfM / $this->uf3Xu;
        goto q2IdE;
        LtiIa:
        if (!($E5EGT < 2)) {
            goto sh7Sf;
        }
        goto N8hD1;
        fe1Wd:
        $seSfM = 2;
        goto TolbL;
        fVvRt:
        $seSfM = $iEY_Z;
        goto M8Kjx;
        vK0pp:
        x8hys:
        goto DbUdh;
        q2IdE:
        $knxvE = $this->cpfum * $lC6G4;
        goto wH6rq;
        o0LsA:
        return ['width' => $seSfM, 'height' => $E5EGT];
        goto Si1Di;
        SFu7B:
        $iEY_Z = 1080;
        goto pk0FZ;
        hLBmQ:
        goto BDWjN;
        goto vK0pp;
        pgvbU:
        $SyTjX = $this->uf3Xu * $lC6G4;
        goto Etux3;
        N8hD1:
        $E5EGT = 2;
        goto IH_Md;
        bTJ_p:
        $E5EGT = 0;
        goto JFR3v;
        Si1Di:
    }
}
