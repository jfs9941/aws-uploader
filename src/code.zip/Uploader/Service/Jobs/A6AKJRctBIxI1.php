<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Illuminate\Support\Facades\Log;
class A6AKJRctBIxI1 implements StoreVideoToS3JobInterface
{
    private $ujbSo;
    private $UoQI7;
    private $pCaD7;
    public function __construct($L2yxk, $UjVft, $P3zvl)
    {
        goto naBwY;
        hZWy2:
        $this->ujbSo = $L2yxk;
        goto OiMnm;
        vA_b_:
        $this->pCaD7 = $P3zvl;
        goto hZWy2;
        naBwY:
        $this->UoQI7 = $UjVft;
        goto vA_b_;
        OiMnm:
    }
    public function store(string $InHEz) : void
    {
        goto bFkpN;
        s1Gon:
        $oo167 = JPkW9ix1EKo3T::find($InHEz);
        goto B8x_i;
        NXph2:
        Hb0mK:
        goto a8vsf;
        a8vsf:
        $XCN9Q = $P3zvl->readStream($oo167->getLocation());
        goto w0D2y;
        nYMax:
        Ht5z1:
        goto i2_jr;
        JIdDI:
        $TNT8K = memory_get_usage();
        goto c9OdI;
        Ls48Z:
        return;
        goto nYMax;
        jsxwA:
        $P3zvl = $this->pCaD7;
        goto s1Gon;
        c9OdI:
        $LOR1V = memory_get_peak_usage();
        goto PfigU;
        i2_jr:
        if ($P3zvl->exists($oo167->getLocation())) {
            goto Hb0mK;
        }
        goto iw8HY;
        uby01:
        Log::info("JPkW9ix1EKo3T has been deleted in database or not inserted yet, discard it", ['fileId' => $InHEz]);
        goto Ls48Z;
        B8x_i:
        if ($oo167) {
            goto Ht5z1;
        }
        goto uby01;
        w0D2y:
        $G2mdJ = 1024 * 1024 * 50;
        goto nm86c;
        nm86c:
        $FSnUv = $P3zvl->mimeType($oo167->getLocation());
        goto b8nQb;
        cd2mm:
        ini_set('memory_limit', '-1');
        goto Rfuhm;
        bFkpN:
        Log::info('Storing video (local) to S3', ['fileId' => $InHEz, 'bucketName' => $this->ujbSo]);
        goto cd2mm;
        iw8HY:
        Log::error("[A6AKJRctBIxI1] File not found, discard it ", ['video' => $oo167->getLocation()]);
        goto M8YnD;
        Rfuhm:
        $PcTXE = $this->UoQI7->getClient();
        goto jsxwA;
        PfigU:
        try {
            goto UxLk2;
            eCIcz:
            $oo167->update(['driver' => YJGCddWUf6Zu2::S3, 'status' => ZP6Ky842t6y9Y::FINISHED]);
            goto cBjWq;
            mdWwm:
            goto SnE_l;
            goto KuPw1;
            qDUa4:
            $FeFdM = [];
            goto mgV15;
            rVwyZ:
            $AP_MX = 1;
            goto qDUa4;
            BKHtK:
            $PcTXE->completeMultipartUpload(['Bucket' => $this->ujbSo, 'Key' => $oo167->getLocation(), 'UploadId' => $b2o4e, 'MultipartUpload' => ['Parts' => $FeFdM]]);
            goto eCIcz;
            KuPw1:
            BzyVR:
            goto Qm4mS;
            DQW_7:
            if (feof($XCN9Q)) {
                goto BzyVR;
            }
            goto cjFZC;
            cBjWq:
            $P3zvl->delete($oo167->getLocation());
            goto vadtN;
            cjFZC:
            $GOUsS = $PcTXE->uploadPart(['Bucket' => $this->ujbSo, 'Key' => $oo167->getLocation(), 'UploadId' => $b2o4e, 'PartNumber' => $AP_MX, 'Body' => fread($XCN9Q, $G2mdJ)]);
            goto Q3N0Q;
            nXGK9:
            $AP_MX++;
            goto mdWwm;
            Q3N0Q:
            $FeFdM[] = ['PartNumber' => $AP_MX, 'ETag' => $GOUsS['ETag']];
            goto nXGK9;
            g18ub:
            $b2o4e = $HgLpI['UploadId'];
            goto rVwyZ;
            UxLk2:
            $HgLpI = $PcTXE->createMultipartUpload(['Bucket' => $this->ujbSo, 'Key' => $oo167->getLocation(), 'ContentType' => $FSnUv, 'ContentDisposition' => 'inline']);
            goto g18ub;
            mgV15:
            SnE_l:
            goto DQW_7;
            Qm4mS:
            fclose($XCN9Q);
            goto BKHtK;
            vadtN:
        } catch (AwsException $uF3lz) {
            goto saDtu;
            saDtu:
            if (!isset($b2o4e)) {
                goto SHzOZ;
            }
            goto eoK3j;
            nFnKE:
            SHzOZ:
            goto WVXh_;
            WVXh_:
            Log::error('Failed to store video: ' . $oo167->getLocation() . ' - ' . $uF3lz->getMessage());
            goto Wc6MB;
            eoK3j:
            try {
                $PcTXE->abortMultipartUpload(['Bucket' => $this->ujbSo, 'Key' => $oo167->getLocation(), 'UploadId' => $b2o4e]);
            } catch (AwsException $Pcrjr) {
                Log::error('Error aborting multipart upload: ' . $Pcrjr->getMessage());
            }
            goto nFnKE;
            Wc6MB:
        } finally {
            $xYgEl = microtime(true);
            $FqOnS = memory_get_usage();
            $U8b7Q = memory_get_peak_usage();
            Log::info('Store JPkW9ix1EKo3T to S3 function resource usage', ['imageId' => $InHEz, 'execution_time_sec' => $xYgEl - $Eceqa, 'memory_usage_mb' => ($FqOnS - $TNT8K) / 1024 / 1024, 'peak_memory_usage_mb' => ($U8b7Q - $LOR1V) / 1024 / 1024]);
        }
        goto uafN9;
        M8YnD:
        return;
        goto NXph2;
        b8nQb:
        $Eceqa = microtime(true);
        goto JIdDI;
        uafN9:
    }
}
