<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class CvJTxFkMTLBgC implements GenerateThumbnailForVideoInterface
{
    private $tZ0XU;
    public function __construct($oHId8)
    {
        $this->tZ0XU = $oHId8;
    }
    public function generate(string $ld8Ad) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $ld8Ad);
        $this->tZ0XU->createThumbnail($ld8Ad);
    }
}
