<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
class A1Bq1DhATt4LG implements WatermarkTextJobInterface
{
    private $SJRrZ;
    private $hOV1v;
    private $SRWQz;
    private $gGE8I;
    private $UBJ9G;
    public function __construct($akc4V, $s_InJ, $duBfR, $e1L33, $s11YB)
    {
        goto WTyoP;
        yeyT9:
        $this->hOV1v = $s_InJ;
        goto NC0Ss;
        AlCqf:
        $this->gGE8I = $duBfR;
        goto Y1C0Q;
        DCCuH:
        $this->SRWQz = $s11YB;
        goto yeyT9;
        Y1C0Q:
        $this->UBJ9G = $e1L33;
        goto DCCuH;
        WTyoP:
        $this->SJRrZ = $akc4V;
        goto AlCqf;
        NC0Ss:
    }
    public function putWatermark(string $ld8Ad, string $fbB2w) : void
    {
        goto TbXSy;
        nZ1un:
        ini_set('memory_limit', '-1');
        goto wCZ9S;
        Qr6J6:
        $VBJ1E = memory_get_peak_usage();
        goto KUAHz;
        KUAHz:
        Log::info("Adding watermark text to image", ['imageId' => $ld8Ad]);
        goto nZ1un;
        TbXSy:
        $p0d_Z = microtime(true);
        goto sJ7GB;
        wCZ9S:
        try {
            goto tva0D;
            A_y_t:
            return;
            goto jl4vb;
            lebva:
            unset($B7Zjh);
            goto BkK_b;
            a2OVK:
            $B7Zjh->save($jGQTt);
            goto lebva;
            kQazD:
            $B7Zjh = $this->SJRrZ->call($this, $jGQTt);
            goto goXyZ;
            CG4JT:
            UmO3X:
            goto M_gCO;
            goXyZ:
            $B7Zjh->orient();
            goto jcOCb;
            JCAS1:
            \Log::warning('Failed to set final permissions on image file: ' . $jGQTt);
            goto dgfzK;
            rEcMS:
            Log::error("Sf7MFJ2wUSx2k is not on local, might be deleted before put watermark", ['imageId' => $ld8Ad]);
            goto A_y_t;
            jcOCb:
            $this->mYRwEATpvLI($B7Zjh, $fbB2w);
            goto a2OVK;
            BkK_b:
            if (chmod($jGQTt, 0664)) {
                goto UmO3X;
            }
            goto JCAS1;
            dgfzK:
            throw new \Exception('Failed to set final permissions on image file: ' . $jGQTt);
            goto CG4JT;
            jl4vb:
            HiLnI:
            goto zJnYJ;
            zJnYJ:
            $jGQTt = $this->UBJ9G->path($xobEP->getLocation());
            goto kQazD;
            tva0D:
            $xobEP = Sf7MFJ2wUSx2k::findOrFail($ld8Ad);
            goto GwU7m;
            GwU7m:
            if ($this->UBJ9G->exists($xobEP->getLocation())) {
                goto HiLnI;
            }
            goto rEcMS;
            M_gCO:
        } catch (\Throwable $fVShp) {
            goto jKS41;
            KTKfS:
            return;
            goto PebaA;
            nDwF7:
            Log::error("Sf7MFJ2wUSx2k is not readable", ['imageId' => $ld8Ad, 'error' => $fVShp->getMessage()]);
            goto GTein;
            jKS41:
            if (!$fVShp instanceof ModelNotFoundException) {
                goto TPBYB;
            }
            goto sSFfm;
            sSFfm:
            Log::info("Sf7MFJ2wUSx2k has been deleted, discard it", ['imageId' => $ld8Ad]);
            goto KTKfS;
            PebaA:
            TPBYB:
            goto nDwF7;
            GTein:
        } finally {
            $RZBdd = microtime(true);
            $s2S1x = memory_get_usage();
            $J0pU0 = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $ld8Ad, 'execution_time_sec' => $RZBdd - $p0d_Z, 'memory_usage_mb' => ($s2S1x - $BpzCH) / 1024 / 1024, 'peak_memory_usage_mb' => ($J0pU0 - $VBJ1E) / 1024 / 1024]);
        }
        goto cCG0z;
        sJ7GB:
        $BpzCH = memory_get_usage();
        goto Qr6J6;
        cCG0z:
    }
    private function mYRwEATpvLI($B7Zjh, $fbB2w) : void
    {
        goto jvan3;
        G_oU8:
        $B7Zjh->place($Lx01S, 'top-left', 0, 0, 30);
        goto fLSl2;
        M3xEY:
        $iM4bK = $B7Zjh->height();
        goto MEhWJ;
        p27rg:
        $this->UBJ9G->put($Qlxwu, $this->gGE8I->get($Qlxwu));
        goto RBlJv;
        g9n0D:
        $Qlxwu = $eATF4->mAceo7BJgV2($Gsmm4, $iM4bK, $fbB2w, true);
        goto p27rg;
        RBlJv:
        $Lx01S = $this->SJRrZ->call($this, $this->UBJ9G->path($Qlxwu));
        goto G_oU8;
        MEhWJ:
        $eATF4 = new WQ9DxjOkuISPT($this->hOV1v, $this->SRWQz, $this->gGE8I, $this->UBJ9G);
        goto g9n0D;
        jvan3:
        $Gsmm4 = $B7Zjh->width();
        goto M3xEY;
        fLSl2:
    }
}
