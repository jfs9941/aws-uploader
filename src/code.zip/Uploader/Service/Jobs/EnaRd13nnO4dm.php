<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
class EnaRd13nnO4dm implements BlurJobInterface
{
    const EqRUT = 15;
    const g9ySt = 500;
    const o6MO3 = 500;
    private $K9RVo;
    private $qrvF0;
    private $ERIyl;
    public function __construct($Venjl, $eG_Pc, $nL6dR)
    {
        goto OAUxb;
        mxmxU:
        $this->qrvF0 = $eG_Pc;
        goto i0JoZ;
        i0JoZ:
        $this->K9RVo = $Venjl;
        goto cYOU2;
        OAUxb:
        $this->ERIyl = $nL6dR;
        goto mxmxU;
        cYOU2:
    }
    public function blur(string $ElvKF) : void
    {
        goto fraai;
        t0v8n:
        $QIqs2 = $this->qrvF0->get($cdk3_->filename);
        goto vFuMe;
        SHzc5:
        throw new \Exception('Failed to set final permissions on image file: ' . $qUAdC);
        goto EjDX3;
        uaQhF:
        ini_set('memory_limit', '-1');
        goto fzb7a;
        sebwH:
        $anrPh->blur(self::EqRUT);
        goto ZLitD;
        vFuMe:
        $this->ERIyl->put($cdk3_->filename, $QIqs2);
        goto jgxcz;
        prGJ9:
        $anrPh->save($qUAdC);
        goto CT5Fr;
        blOji:
        $cdk3_->update(['preview' => $Q60Mb]);
        goto oGCRa;
        NJXMm:
        \Log::warning('Failed to set final permissions on image file: ' . $qUAdC);
        goto SHzc5;
        CT5Fr:
        $anrPh->destroy();
        goto sN2WP;
        y1zpk:
        $anrPh = $this->K9RVo->call($this, $this->ERIyl->path($cdk3_->getLocation()));
        goto vjQZJ;
        PJnYi:
        $qUAdC = $this->ERIyl->path($Q60Mb);
        goto prGJ9;
        EjDX3:
        qidw9:
        goto blOji;
        vjQZJ:
        $WTiec = $anrPh->width() / $anrPh->height();
        goto TfT59;
        TfT59:
        $anrPh->resize(self::g9ySt, self::o6MO3 / $WTiec);
        goto sebwH;
        ZLitD:
        $Q60Mb = $this->mvnXtFBjtmf($cdk3_);
        goto PJnYi;
        fraai:
        $cdk3_ = WKX0l52zWptlF::findOrFail($ElvKF);
        goto uaQhF;
        jgxcz:
        fw04E:
        goto y1zpk;
        fzb7a:
        if (!($cdk3_->rbCCx == I2Tze5VZcqaXS::S3 && !$this->ERIyl->exists($cdk3_->filename))) {
            goto fw04E;
        }
        goto t0v8n;
        sN2WP:
        if (chmod($qUAdC, 0664)) {
            goto qidw9;
        }
        goto NJXMm;
        oGCRa:
    }
    private function mvnXtFBjtmf($jAFG4) : string
    {
        goto rnerg;
        Hy2Pc:
        $rccNk = dirname($lmCO9) . '/preview/';
        goto TxPwk;
        rnerg:
        $lmCO9 = $jAFG4->getLocation();
        goto Hy2Pc;
        TxPwk:
        if ($this->ERIyl->exists($rccNk)) {
            goto pguPr;
        }
        goto jIvVI;
        G5cJ0:
        pguPr:
        goto xJNxW;
        xJNxW:
        return $rccNk . $jAFG4->getFilename() . '.jpg';
        goto wxZx2;
        jIvVI:
        $this->ERIyl->makeDirectory($rccNk, 0755, true);
        goto G5cJ0;
        wxZx2:
    }
}
