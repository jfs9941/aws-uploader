<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Encoder\DqtyTdqDXiARq;
use Jfs\Uploader\Encoder\XmIUTGy65GCBf;
use Jfs\Uploader\Encoder\XeMVcGXMtTgrJ;
use Jfs\Uploader\Encoder\J7daXwtzv3QYS;
use Jfs\Uploader\Encoder\PBLLq55t18yGF;
use Jfs\Uploader\Encoder\LCD9zDkiJube7;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Jfs\Uploader\Service\Jobs\CqS1mpKkV7Z4F;
use Jfs\Uploader\Service\Jobs\T2CJnBIhoexXE;
use Jfs\Uploader\Service\Vxy5RzsyYlKDb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class AdFYWfmNJLcjB implements MediaEncodeJobInterface
{
    private $XbarW;
    private $yt19t;
    private $gErml;
    private $jD7oG;
    private $jsGTU;
    public function __construct(string $YctT5, $RndMA, $DFpIk, $ksSJg, $lylEe)
    {
        goto UouNT;
        Thxjt:
        $this->jsGTU = $lylEe;
        goto kGBHJ;
        UouNT:
        $this->XbarW = $YctT5;
        goto pchd0;
        eEe6C:
        $this->gErml = $DFpIk;
        goto VSCI3;
        VSCI3:
        $this->jD7oG = $ksSJg;
        goto Thxjt;
        pchd0:
        $this->yt19t = $RndMA;
        goto eEe6C;
        kGBHJ:
    }
    public function encode(string $J_scC, string $SqwFQ, $hKHD2 = true) : void
    {
        goto LAi3M;
        LAi3M:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $J_scC]);
        goto i0V_1;
        LAEDx:
        try {
            goto St7Ec;
            a7jGv:
            $cOdCv = new DqtyTdqDXiARq($Zpy0I->getAttribute('duration') ?? 1, 2, $zxYNZ->mUl9fifEdB6($Zpy0I));
            goto WSm3b;
            EtAMC:
            $lh42H = $lh42H->mdHGFiK9opO(new J7daXwtzv3QYS($E2XUK));
            goto JfKfN;
            LzTQJ:
            if (!$uuAZB) {
                goto DHtja;
            }
            goto rgBdo;
            Vs16w:
            $lh42H = $lh42H->mT8dO9E71jK($IbDg2);
            goto fTYds;
            dKOMa:
            if (!$uuAZB) {
                goto yb29W;
            }
            goto a6O5u;
            DlxPK:
            if (!($Zpy0I->driver != DccywYjigTakI::S3)) {
                goto d52wV;
            }
            goto fEXZG;
            UhZ2K:
            $uuAZB = $this->mwB1TjRnzwd($vCrTa, $XLq95->mmlHyHPZIWI((int) $i896J['width'], (int) $i896J['height'], $SqwFQ));
            goto dKOMa;
            yd7nr:
            $lh42H->mCDHuWcYHCY($zxYNZ->mdkxdp2enva($Zpy0I));
            goto OfV9G;
            pKhe3:
            $lh42H = app(PBLLq55t18yGF::class);
            goto EtAMC;
            vvhSO:
            d52wV:
            goto CvuOa;
            wOPhq:
            $E2XUK = $this->maJ4Ob7NLC9($Zpy0I);
            goto h1wYZ;
            a6O5u:
            $IbDg2 = $IbDg2->mqvISxlQg3I($uuAZB);
            goto dvyGE;
            ugv06:
            $IbDg2 = new XmIUTGy65GCBf('1080p', $i896J['width'], $i896J['height'], $Zpy0I->DQ3b0 ?? 30);
            goto UhZ2K;
            emzlX:
            $kc4oX = $Zpy0I->width();
            goto rIH3p;
            WSm3b:
            $lh42H = $lh42H->mgJwyiXLves($cOdCv);
            goto aqLgD;
            St7Ec:
            $Zpy0I = BG2FRpwGrKqJx::findOrFail($J_scC);
            goto Qb0Oc;
            azD9B:
            $vCrTa = app(Vxy5RzsyYlKDb::class);
            goto Azjc7;
            TwIJc:
            $lh42H->mT8dO9E71jK($mzp0C);
            goto Y2n9I;
            h1wYZ:
            Log::info("Set input video for Job", ['s3Uri' => $E2XUK]);
            goto pKhe3;
            aqLgD:
            $J_scC = $lh42H->moLasCdrpJY($this->mepT1f37FtT($Zpy0I, $hKHD2));
            goto Ca3fO;
            epYao:
            UL5gi:
            goto eroiJ;
            Dw30N:
            return;
            goto YNaIo;
            XDv3q:
            Log::info("BG2FRpwGrKqJx already has Media Converter Job ID, skip encoding", ['fileId' => $J_scC, 'jobId' => $Zpy0I->getAttribute('aws_media_converter_job_id')]);
            goto Dw30N;
            OfV9G:
            if (!($kc4oX && $lIw1W)) {
                goto UL5gi;
            }
            goto yOuZX;
            Ca3fO:
            $Zpy0I->update(['aws_media_converter_job_id' => $J_scC]);
            goto woy4U;
            CvuOa:
            if (!$Zpy0I->getAttribute('aws_media_converter_job_id')) {
                goto ooXf4;
            }
            goto XDv3q;
            Azjc7:
            $XLq95 = new T2CJnBIhoexXE($this->jD7oG, $this->jsGTU, $this->gErml, $this->yt19t);
            goto xT8ki;
            JfKfN:
            $mzp0C = new XmIUTGy65GCBf('original', $kc4oX, $lIw1W, $Zpy0I->DQ3b0 ?? 30);
            goto b6s8G;
            b6s8G:
            $zxYNZ = app(XeMVcGXMtTgrJ::class);
            goto TwIJc;
            Y2n9I:
            $lh42H->mCDHuWcYHCY($zxYNZ->mdkxdp2enva($Zpy0I));
            goto azD9B;
            YNaIo:
            ooXf4:
            goto emzlX;
            fEXZG:
            throw new MediaConverterException("BG2FRpwGrKqJx {$Zpy0I->id} is not S3 driver value = {$Zpy0I->driver}");
            goto vvhSO;
            fTYds:
            mJZmq:
            goto epYao;
            Qb0Oc:
            Assert::isInstanceOf($Zpy0I, BG2FRpwGrKqJx::class);
            goto DlxPK;
            cIBmr:
            $i896J = $this->mrpkb38RlA4($kc4oX, $lIw1W);
            goto vup7g;
            dvyGE:
            yb29W:
            goto Vs16w;
            vup7g:
            Log::info("Set 1080p resolution for Job", ['width' => $i896J['width'], 'height' => $i896J['height'], 'originalWidth' => $kc4oX, 'originalHeight' => $lIw1W]);
            goto ugv06;
            stJ4y:
            DHtja:
            goto Y329Z;
            eroiJ:
            Log::info("Set thumbnail for BG2FRpwGrKqJx Job", ['videoId' => $Zpy0I->getAttribute('id'), 'duration' => $Zpy0I->getAttribute('duration')]);
            goto a7jGv;
            Y329Z:
            $lh42H->mT8dO9E71jK($mzp0C);
            goto yd7nr;
            rgBdo:
            $mzp0C = $mzp0C->mqvISxlQg3I($uuAZB);
            goto stJ4y;
            rIH3p:
            $lIw1W = $Zpy0I->height();
            goto wOPhq;
            yOuZX:
            if (!$this->mWLEKrIlpfm($kc4oX, $lIw1W)) {
                goto mJZmq;
            }
            goto cIBmr;
            xT8ki:
            $uuAZB = $this->mwB1TjRnzwd($vCrTa, $XLq95->mmlHyHPZIWI($Zpy0I->width(), $Zpy0I->height(), $SqwFQ));
            goto LzTQJ;
            woy4U:
        } catch (\Exception $Jtg9A) {
            goto EoLYg;
            EoLYg:
            Log::warning("BG2FRpwGrKqJx has been deleted, discard it", ['fileId' => $J_scC, 'err' => $Jtg9A->getMessage()]);
            goto dWfyw;
            HdzH5:
            return;
            goto ALleF;
            dWfyw:
            Sentry::captureException($Jtg9A);
            goto HdzH5;
            ALleF:
        }
        goto FCq7M;
        i0V_1:
        ini_set('memory_limit', '-1');
        goto LAEDx;
        FCq7M:
    }
    private function mepT1f37FtT(BG2FRpwGrKqJx $Zpy0I, $hKHD2) : bool
    {
        goto xeK4t;
        M66eu:
        GnGJM:
        goto iHsj0;
        NtHh8:
        switch (true) {
            case $Zpy0I->width() * $Zpy0I->height() >= 1920 * 1080 && $Zpy0I->width() * $Zpy0I->height() < 2560 * 1440:
                return $F000X > 30 * 60;
            case $Zpy0I->width() * $Zpy0I->height() >= 2560 * 1440 && $Zpy0I->width() * $Zpy0I->height() < 3840 * 2160:
                return $F000X > 15 * 60;
            case $Zpy0I->width() * $Zpy0I->height() >= 3840 * 2160:
                return $F000X > 10 * 60;
            default:
                return false;
        }
        goto afmRg;
        AQZ1f:
        return false;
        goto buX6H;
        afmRg:
        a75pO:
        goto M66eu;
        xeK4t:
        if ($hKHD2) {
            goto lGKFc;
        }
        goto AQZ1f;
        buX6H:
        lGKFc:
        goto gihC2;
        gihC2:
        $F000X = (int) round($Zpy0I->getAttribute('duration') ?? 0);
        goto NtHh8;
        iHsj0:
    }
    private function mwB1TjRnzwd(Vxy5RzsyYlKDb $vCrTa, string $A8jlG) : ?LCD9zDkiJube7
    {
        goto TAAip;
        mH0j8:
        return null;
        goto ppyZC;
        iPUmL:
        if (!$XhgjV) {
            goto RN5MR;
        }
        goto YGSzD;
        TAAip:
        $XhgjV = $vCrTa->mjWpIQG8bPS($A8jlG);
        goto dtvCY;
        YGSzD:
        return new LCD9zDkiJube7($XhgjV, 0, 0, null, null);
        goto YL6z8;
        dtvCY:
        Log::info("Resolve watermark for job with url", ['url' => $A8jlG, 'uri' => $XhgjV]);
        goto iPUmL;
        YL6z8:
        RN5MR:
        goto mH0j8;
        ppyZC:
    }
    private function mWLEKrIlpfm(int $kc4oX, int $lIw1W) : bool
    {
        return $kc4oX * $lIw1W > 1.5 * (1920 * 1080);
    }
    private function mrpkb38RlA4(int $kc4oX, int $lIw1W) : array
    {
        $PlC4a = new CqS1mpKkV7Z4F($kc4oX, $lIw1W);
        return $PlC4a->mtPJz994WEd();
    }
    private function maJ4Ob7NLC9(KFe2ZCctciwsA $Hz32I) : string
    {
        goto YfzkF;
        HtOZW:
        return 's3://' . $this->XbarW . '/' . $Hz32I->filename;
        goto LoXPg;
        LoXPg:
        fuJeC:
        goto Fe9fn;
        Fe9fn:
        return $this->yt19t->url($Hz32I->filename);
        goto h9svp;
        YfzkF:
        if (!($Hz32I->driver == DccywYjigTakI::S3)) {
            goto fuJeC;
        }
        goto HtOZW;
        h9svp:
    }
}
