<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class KRAKiGGIqBhRX
{
    private $wzdVy;
    private $EHcHx;
    private $zTo0t;
    private $s0VP1;
    public function __construct($HIvH7, $Ly36A, $Vi8xq, $TuWZt)
    {
        goto MhSAv;
        i3U5m:
        $this->s0VP1 = $TuWZt;
        goto HHg7H;
        ZmXz1:
        $this->zTo0t = $Vi8xq;
        goto i3U5m;
        MhSAv:
        $this->EHcHx = $Ly36A;
        goto ZmXz1;
        HHg7H:
        $this->wzdVy = $HIvH7;
        goto VG5BF;
        VG5BF:
    }
    public function mpYSbSHWX85(?int $kl8qs, ?int $nl3gy, string $QyRqP, bool $SfDJ2 = false) : string
    {
        goto LLrqq;
        R742G:
        $this->s0VP1->put($z69yI, $iy9bs->stream('png'));
        goto t3vem;
        k52zS:
        $iy9bs->text($wHJjj, $Yvq5B, (int) $slR9R, function ($bA7Wp) use($XOVfg) {
            goto IZd2N;
            U58at:
            $bA7Wp->align('middle');
            goto y30GL;
            kT2Vj:
            $Y3yX7 = (int) ($XOVfg * 1.2);
            goto V2olR;
            IZd2N:
            $bA7Wp->file(public_path($this->EHcHx));
            goto kT2Vj;
            sPZmE:
            $bA7Wp->valign('middle');
            goto U58at;
            V2olR:
            $bA7Wp->size(max($Y3yX7, 1));
            goto k4BBl;
            k4BBl:
            $bA7Wp->color([185, 185, 185, 1]);
            goto sPZmE;
            y30GL:
        });
        goto R742G;
        vh820:
        $iy9bs = $this->wzdVy->call($this, $kl8qs, $nl3gy);
        goto lYDgQ;
        utmzZ:
        $Yvq5B -= $ink9J;
        goto TW_Dv;
        GTqMR:
        $ink9J = (int) ($Yvq5B / 80);
        goto utmzZ;
        LLrqq:
        if (!($kl8qs === null || $nl3gy === null)) {
            goto F0__a;
        }
        goto oZVmF;
        B_m6o:
        F0__a:
        goto FXIGc;
        zPMwE:
        $Yvq5B -= $ink9J * 0.4;
        goto jZ25R;
        lYDgQ:
        $Yvq5B = $kl8qs - $rfVMD;
        goto GTqMR;
        tWFEH:
        $z69yI = $this->mTxdfMuFPlt($wHJjj, $kl8qs, $nl3gy, $rfVMD, $XOVfg);
        goto nK6ur;
        jZ25R:
        i5byR:
        goto COlJb;
        FXIGc:
        $GYWEC = 0.1;
        goto qs5sp;
        bviq4:
        return $SfDJ2 ? $z69yI : $this->zTo0t->url($z69yI);
        goto JvYsP;
        qs5sp:
        list($XOVfg, $rfVMD, $wHJjj) = $this->mzjrJ9OpzTx($QyRqP, $kl8qs, $GYWEC, (float) $kl8qs / $nl3gy);
        goto tWFEH;
        oZVmF:
        throw new \RuntimeException("Kt6NO3eUvdER6 dimensions are not available.");
        goto B_m6o;
        COlJb:
        $slR9R = $nl3gy - $XOVfg - 10;
        goto k52zS;
        TW_Dv:
        if (!($kl8qs > 1500)) {
            goto i5byR;
        }
        goto zPMwE;
        kmneR:
        return $SfDJ2 ? $z69yI : $this->zTo0t->url($z69yI);
        goto zbk0K;
        t3vem:
        $this->zTo0t->put($z69yI, $iy9bs->stream('png'));
        goto bviq4;
        zbk0K:
        Ec81e:
        goto vh820;
        nK6ur:
        if (!$this->zTo0t->exists($z69yI)) {
            goto Ec81e;
        }
        goto kmneR;
        JvYsP:
    }
    private function mTxdfMuFPlt(string $QyRqP, int $kl8qs, int $nl3gy, int $cbTrj, int $rk7XH) : string
    {
        $qXLig = ltrim($QyRqP, '@');
        return "v2/watermark/{$qXLig}/{$kl8qs}x{$nl3gy}_{$cbTrj}x{$rk7XH}/text_watermark.png";
    }
    private function mzjrJ9OpzTx($QyRqP, int $kl8qs, float $pRLIL, float $Xb5Jr) : array
    {
        goto GfJ8u;
        cLLvF:
        CUEh3:
        goto jF3IK;
        OtgeP:
        return [(int) $otal2, $otal2 * strlen($wHJjj) / 1.8, $wHJjj];
        goto cLLvF;
        PhYRX:
        $otal2 = $rfVMD / (strlen($wHJjj) * 0.8);
        goto OtgeP;
        GUhuL:
        if (!($Xb5Jr > 1)) {
            goto CUEh3;
        }
        goto PhYRX;
        qRXsA:
        return [(int) $otal2, $rfVMD, $wHJjj];
        goto YrviT;
        mn769:
        $rfVMD = (int) ($kl8qs * $pRLIL);
        goto GUhuL;
        GfJ8u:
        $wHJjj = '@' . $QyRqP;
        goto mn769;
        jF3IK:
        $otal2 = 1 / $Xb5Jr * $rfVMD / strlen($wHJjj);
        goto qRXsA;
        YrviT:
    }
}
