<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Encoder\BPO1kQM9JvpAH;
use Jfs\Uploader\Encoder\PbrjZTdWh0VlQ;
use Jfs\Uploader\Encoder\VNaEXNVKcqr6v;
use Jfs\Uploader\Encoder\M00Y0GeagnFt6;
use Jfs\Uploader\Encoder\YtOeto201sjfh;
use Jfs\Uploader\Encoder\CQZusEgvlBWXI;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Jfs\Uploader\Service\Jobs\EgnVqoEVePjkf;
use Jfs\Uploader\Service\Jobs\Pj7hrgmc9SyTB;
use Jfs\Uploader\Service\FpvVyCHYf1EbW;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Sentry;
use Webmozart\Assert\Assert;
class L8msOtDP8qgmS implements MediaEncodeJobInterface
{
    private $xhfp2;
    private $q6zCU;
    private $aiw3M;
    private $nVSvB;
    private $AK92U;
    public function __construct(string $C1Y4p, $zDbHT, $iay5S, $kRqOQ, $kpG5q)
    {
        goto mC1eN;
        XFlmK:
        $this->nVSvB = $kRqOQ;
        goto IqszP;
        mC1eN:
        $this->xhfp2 = $C1Y4p;
        goto UByL8;
        fMqBA:
        $this->aiw3M = $iay5S;
        goto XFlmK;
        UByL8:
        $this->q6zCU = $zDbHT;
        goto fMqBA;
        IqszP:
        $this->AK92U = $kpG5q;
        goto YLeSZ;
        YLeSZ:
    }
    public function encode(string $zV1kl, string $VhKiX, $OR2s7 = true) : void
    {
        goto ht4wX;
        JTHqF:
        try {
            goto A6_7q;
            TjI9p:
            if (!$this->mfwMB2DDZKq($Eb8hw, $eekOV)) {
                goto Z3LGE;
            }
            goto etXvv;
            XXhit:
            $hXUx3 = $hXUx3->mShL5oBOMms($cplVg);
            goto Gm38c;
            BFxuW:
            h9vkj:
            goto Xmz9M;
            e5puU:
            $hXUx3->mekXAnWu5fR($DURrE->mJ5jZAk1Nqd($EVGvq));
            goto caf3S;
            Lrn9I:
            $T7Fli = app(FpvVyCHYf1EbW::class);
            goto Sio1R;
            Msd7j:
            $cplVg = new PbrjZTdWh0VlQ('1080p', $srZ28['width'], $srZ28['height'], $EVGvq->SHsM5 ?? 30);
            goto xnktN;
            heZPS:
            $cplVg = $cplVg->mAm6iztaCSu($hoLAl);
            goto tYm5u;
            Xmz9M:
            $Eb8hw = $EVGvq->width();
            goto J0M8j;
            OuFyQ:
            Eih4z:
            goto cy9Pw;
            Np4yT:
            if (!$EVGvq->getAttribute('aws_media_converter_job_id')) {
                goto h9vkj;
            }
            goto CHExi;
            Sio1R:
            $Hj32z = new Pj7hrgmc9SyTB($this->nVSvB, $this->AK92U, $this->aiw3M, $this->q6zCU);
            goto yX5Fd;
            FJOGQ:
            $EVGvq->update(['aws_media_converter_job_id' => $zV1kl]);
            goto IlMhc;
            g7Vzc:
            Log::info("Set input video for Job", ['s3Uri' => $UZWEC]);
            goto z_Ld7;
            AW7Ew:
            if (!$hoLAl) {
                goto Eih4z;
            }
            goto T2xVU;
            z_Ld7:
            $hXUx3 = app(YtOeto201sjfh::class);
            goto GJhBT;
            xnktN:
            $hoLAl = $this->mHUcYWFvBxz($T7Fli, $Hj32z->m7glC4JIXFX((int) $srZ28['width'], (int) $srZ28['height'], $VhKiX));
            goto Vx7yo;
            CHExi:
            Log::info("UYo98bF5lKEmO already has Media Converter Job ID, skip encoding", ['fileId' => $zV1kl, 'jobId' => $EVGvq->getAttribute('aws_media_converter_job_id')]);
            goto CoLPK;
            tYm5u:
            StAMF:
            goto XXhit;
            etXvv:
            $srZ28 = $this->mPjfCNhb0C4($Eb8hw, $eekOV);
            goto yfmy8;
            G32Bc:
            $hXUx3->mekXAnWu5fR($DURrE->mJ5jZAk1Nqd($EVGvq));
            goto Lrn9I;
            puarf:
            $DURrE = app(VNaEXNVKcqr6v::class);
            goto G32Bc;
            eWkJt:
            Assert::isInstanceOf($EVGvq, UYo98bF5lKEmO::class);
            goto UWRdx;
            Gm38c:
            Z3LGE:
            goto lfh7L;
            gUe18:
            $UZWEC = $this->mIIXQtDH8Uh($EVGvq);
            goto g7Vzc;
            hekwT:
            Log::info("Set thumbnail for UYo98bF5lKEmO Job", ['videoId' => $EVGvq->getAttribute('id'), 'duration' => $EVGvq->getAttribute('duration')]);
            goto niRBX;
            cy9Pw:
            $hXUx3->mShL5oBOMms($DOnK6);
            goto e5puU;
            yX5Fd:
            $hoLAl = $this->mHUcYWFvBxz($T7Fli, $Hj32z->m7glC4JIXFX($EVGvq->width(), $EVGvq->height(), $VhKiX));
            goto AW7Ew;
            ZGQXb:
            $zV1kl = $hXUx3->mlifLdaVPgE($this->mwHquHvz3ef($EVGvq, $OR2s7));
            goto FJOGQ;
            Vx7yo:
            if (!$hoLAl) {
                goto StAMF;
            }
            goto heZPS;
            caf3S:
            if (!($Eb8hw && $eekOV)) {
                goto F99Tn;
            }
            goto TjI9p;
            x0gPe:
            CzHJV:
            goto Np4yT;
            UWRdx:
            if (!($EVGvq->driver != X4ZiOQdPeeHKI::S3)) {
                goto CzHJV;
            }
            goto FfvIA;
            J0M8j:
            $eekOV = $EVGvq->height();
            goto gUe18;
            A6_7q:
            $EVGvq = UYo98bF5lKEmO::findOrFail($zV1kl);
            goto eWkJt;
            G7vu1:
            $DOnK6 = new PbrjZTdWh0VlQ('original', $Eb8hw, $eekOV, $EVGvq->SHsM5 ?? 30);
            goto puarf;
            tySeq:
            $hXUx3 = $hXUx3->mdLrbFP7twl($X9APK);
            goto ZGQXb;
            yfmy8:
            Log::info("Set 1080p resolution for Job", ['width' => $srZ28['width'], 'height' => $srZ28['height'], 'originalWidth' => $Eb8hw, 'originalHeight' => $eekOV]);
            goto Msd7j;
            T2xVU:
            $DOnK6 = $DOnK6->mAm6iztaCSu($hoLAl);
            goto OuFyQ;
            FfvIA:
            throw new MediaConverterException("UYo98bF5lKEmO {$EVGvq->id} is not S3 driver value = {$EVGvq->driver}");
            goto x0gPe;
            lfh7L:
            F99Tn:
            goto hekwT;
            GJhBT:
            $hXUx3 = $hXUx3->mM7U9bka4qD(new M00Y0GeagnFt6($UZWEC));
            goto G7vu1;
            niRBX:
            $X9APK = new BPO1kQM9JvpAH($EVGvq->getAttribute('duration') ?? 1, 2, $DURrE->mLj5q7uotj2($EVGvq));
            goto tySeq;
            CoLPK:
            return;
            goto BFxuW;
            IlMhc:
        } catch (\Exception $VJRSZ) {
            goto NLz0J;
            FcU_p:
            return;
            goto fPVZ3;
            RmBou:
            Sentry::captureException($VJRSZ);
            goto FcU_p;
            NLz0J:
            Log::warning("UYo98bF5lKEmO has been deleted, discard it", ['fileId' => $zV1kl, 'err' => $VJRSZ->getMessage()]);
            goto RmBou;
            fPVZ3:
        }
        goto SXxdn;
        ZMPUm:
        ini_set('memory_limit', '-1');
        goto JTHqF;
        ht4wX:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $zV1kl]);
        goto ZMPUm;
        SXxdn:
    }
    private function mwHquHvz3ef(UYo98bF5lKEmO $EVGvq, $OR2s7) : bool
    {
        goto IANH5;
        Ditn0:
        $bI9gh = (int) round($EVGvq->getAttribute('duration') ?? 0);
        goto y1Tbu;
        JG5Ev:
        return false;
        goto q65x0;
        q65x0:
        bSsRH:
        goto Ditn0;
        PwWRQ:
        kKIYm:
        goto xdKvr;
        OJTA9:
        rHKJ8:
        goto PwWRQ;
        IANH5:
        if ($OR2s7) {
            goto bSsRH;
        }
        goto JG5Ev;
        y1Tbu:
        switch (true) {
            case $EVGvq->width() * $EVGvq->height() >= 1920 * 1080 && $EVGvq->width() * $EVGvq->height() < 2560 * 1440:
                return $bI9gh > 30 * 60;
            case $EVGvq->width() * $EVGvq->height() >= 2560 * 1440 && $EVGvq->width() * $EVGvq->height() < 3840 * 2160:
                return $bI9gh > 15 * 60;
            case $EVGvq->width() * $EVGvq->height() >= 3840 * 2160:
                return $bI9gh > 10 * 60;
            default:
                return false;
        }
        goto OJTA9;
        xdKvr:
    }
    private function mHUcYWFvBxz(FpvVyCHYf1EbW $T7Fli, string $igIiY) : ?CQZusEgvlBWXI
    {
        goto taB_g;
        rIdcK:
        return new CQZusEgvlBWXI($pQKSa, 0, 0, null, null);
        goto a2Yx0;
        N2Mt0:
        if (!$pQKSa) {
            goto LWWt9;
        }
        goto rIdcK;
        taB_g:
        $pQKSa = $T7Fli->mswcXsXm4i0($igIiY);
        goto iOYdQ;
        a2Yx0:
        LWWt9:
        goto oTl2L;
        oTl2L:
        return null;
        goto a9XX9;
        iOYdQ:
        Log::info("Resolve watermark for job with url", ['url' => $igIiY, 'uri' => $pQKSa]);
        goto N2Mt0;
        a9XX9:
    }
    private function mfwMB2DDZKq(int $Eb8hw, int $eekOV) : bool
    {
        return $Eb8hw * $eekOV > 1.5 * (1920 * 1080);
    }
    private function mPjfCNhb0C4(int $Eb8hw, int $eekOV) : array
    {
        $vOCIs = new EgnVqoEVePjkf($Eb8hw, $eekOV);
        return $vOCIs->m2zXdGiw2g6();
    }
    private function mIIXQtDH8Uh(AtQh9cRLX7xL8 $hckxR) : string
    {
        goto SW8KG;
        SW8KG:
        if (!($hckxR->driver == X4ZiOQdPeeHKI::S3)) {
            goto r9PQx;
        }
        goto VDqgo;
        wspXn:
        return $this->q6zCU->url($hckxR->filename);
        goto aHMMT;
        X64nE:
        r9PQx:
        goto wspXn;
        VDqgo:
        return 's3://' . $this->xhfp2 . '/' . $hckxR->filename;
        goto X64nE;
        aHMMT:
    }
}
