<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class Vp9wsivKgNgSA implements GenerateThumbnailForVideoInterface
{
    private $ZdSYj;
    public function __construct($jl__r)
    {
        $this->ZdSYj = $jl__r;
    }
    public function generate(string $Brk87) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $Brk87);
        $this->ZdSYj->createThumbnail($Brk87);
    }
}
