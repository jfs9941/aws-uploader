<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Encoder\T4E7bNu9othaO;
use Jfs\Uploader\Encoder\VzCP01fc7F1B6;
use Jfs\Uploader\Encoder\Saum77EIMVl09;
use Jfs\Uploader\Encoder\IuBzMgccmnzY0;
use Jfs\Uploader\Encoder\CJIFKD65bWskH;
use Jfs\Uploader\Encoder\Mk5y6pFXlppNf;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
use Jfs\Uploader\Service\NzkrkFhIBihmO;
use Webmozart\Assert\Assert;
class BILJHBmslj2vI implements MediaEncodeJobInterface
{
    private $ZCKne;
    private $OKvrN;
    private $GQuun;
    private $NzdTN;
    private $h6c5V;
    public function __construct(string $mJZ7g, $GiTtn, $Q0shJ, $DvaDk, $RogsX)
    {
        goto YFmhD;
        mxcsO:
        $this->OKvrN = $GiTtn;
        goto vbjDk;
        vbjDk:
        $this->GQuun = $Q0shJ;
        goto fn94l;
        tFSQD:
        $this->h6c5V = $RogsX;
        goto UxT6b;
        YFmhD:
        $this->ZCKne = $mJZ7g;
        goto mxcsO;
        fn94l:
        $this->NzdTN = $DvaDk;
        goto tFSQD;
        UxT6b:
    }
    public function encode(string $eXur0, string $hkNHZ, $x9Hx2 = true) : void
    {
        goto fwx53;
        fwx53:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $eXur0]);
        goto wkwgO;
        AwWFP:
        try {
            goto Qvfdi;
            KN2AN:
            $PuAgf->mWhvNa0nJyI($nGk9y->m3AjunF2pKL($DuZ1o));
            goto Hzi4v;
            pnKDN:
            $PuAgf = $PuAgf->mjQpyVD7qjf($Iw48H);
            goto cpbI2;
            Hzi4v:
            $ggIs8 = app(NzkrkFhIBihmO::class);
            goto miqMU;
            yNTDP:
            $y1L0s = new VzCP01fc7F1B6('original', $vwL5B, $ttadT, $DuZ1o->skPJC ?? 30);
            goto qUwuY;
            rg15P:
            if (!($vwL5B && $ttadT)) {
                goto q8uKG;
            }
            goto c0O0T;
            zb0fc:
            Assert::isInstanceOf($DuZ1o, S25BfMDKrX8cB::class);
            goto PzS2f;
            FSPs3:
            throw new MediaConverterException("S25BfMDKrX8cB {$DuZ1o->id} is not S3 driver");
            goto fCnsG;
            TCfz1:
            $jVS4s = new T4E7bNu9othaO($DuZ1o->Q8y9m ?? 1, 2, $nGk9y->m7iW1If9qU3($DuZ1o));
            goto tONaj;
            GS_vf:
            $PuAgf->mjQpyVD7qjf($y1L0s);
            goto KN2AN;
            TS9Qa:
            $mgPq9 = $this->mDr1EOCIFyv($DuZ1o);
            goto EJCZk;
            EJCZk:
            Log::info("Set input video for Job", ['s3Uri' => $mgPq9]);
            goto H1kD1;
            r8tO8:
            if (!$bNFYR) {
                goto mX71b;
            }
            goto c4a9R;
            Vkpd9:
            $PuAgf->mjQpyVD7qjf($y1L0s);
            goto c6iQx;
            eLASH:
            $Iw48H = new VzCP01fc7F1B6('1080p', $rbUVW['width'], $rbUVW['height'], $DuZ1o->skPJC ?? 30);
            goto tSiqf;
            cpbI2:
            SfcqX:
            goto b3R5h;
            zQ0C3:
            Log::info("Set thumbnail for S25BfMDKrX8cB Job", ['videoId' => $DuZ1o->getAttribute('id'), 'duration' => $DuZ1o->getAttribute('duration')]);
            goto TCfz1;
            UWudc:
            $bNFYR = $this->m9reGjTaOJW($ggIs8, $mzkQL->mUbg5R9jG4v($DuZ1o->width(), $DuZ1o->height(), $hkNHZ));
            goto StVOD;
            qUwuY:
            $nGk9y = app(Saum77EIMVl09::class);
            goto GS_vf;
            Qvfdi:
            $DuZ1o = S25BfMDKrX8cB::findOrFail($eXur0);
            goto zb0fc;
            KI0ZO:
            $eXur0 = $PuAgf->mEw24Bz5MMa($this->m5oIXuU27UI($DuZ1o, $x9Hx2));
            goto d0Cp4;
            ATJ9X:
            $rbUVW = $this->mrTeS3smYj8($vwL5B, $ttadT);
            goto a8PRn;
            miqMU:
            $mzkQL = new CPZOjRiIao943($this->NzdTN, $this->h6c5V, $this->GQuun, $this->OKvrN);
            goto UWudc;
            c0O0T:
            if (!$this->mVH9MOZ85ko($vwL5B, $ttadT)) {
                goto SfcqX;
            }
            goto ATJ9X;
            cSslt:
            mX71b:
            goto pnKDN;
            H1kD1:
            $PuAgf = app(CJIFKD65bWskH::class);
            goto N_sZy;
            tONaj:
            $PuAgf = $PuAgf->mESxosCFZd0($jVS4s);
            goto KI0ZO;
            eSFyf:
            $vwL5B = $DuZ1o->width();
            goto qg3Fy;
            c4a9R:
            $Iw48H = $Iw48H->mHELPZjOMXP($bNFYR);
            goto cSslt;
            fCnsG:
            Hl0Ug:
            goto eSFyf;
            c6iQx:
            $PuAgf->mWhvNa0nJyI($nGk9y->m3AjunF2pKL($DuZ1o));
            goto rg15P;
            N_sZy:
            $PuAgf = $PuAgf->m6usEXjPvyX(new IuBzMgccmnzY0($mgPq9));
            goto yNTDP;
            tSiqf:
            $bNFYR = $this->m9reGjTaOJW($ggIs8, $mzkQL->mUbg5R9jG4v((int) $rbUVW['width'], (int) $rbUVW['height'], $hkNHZ));
            goto r8tO8;
            a8PRn:
            Log::info("Set 1080p resolution for Job", ['width' => $rbUVW['width'], 'height' => $rbUVW['height'], 'originalWidth' => $vwL5B, 'originalHeight' => $ttadT]);
            goto eLASH;
            NTaQs:
            $y1L0s = $y1L0s->mHELPZjOMXP($bNFYR);
            goto ThWJF;
            StVOD:
            if (!$bNFYR) {
                goto t7FuC;
            }
            goto NTaQs;
            d0Cp4:
            $DuZ1o->update(['aws_media_converter_job_id' => $eXur0]);
            goto tibeG;
            PzS2f:
            if (!($DuZ1o->BlJMK !== VCKF0xK25vLxq::S3)) {
                goto Hl0Ug;
            }
            goto FSPs3;
            qg3Fy:
            $ttadT = $DuZ1o->height();
            goto TS9Qa;
            b3R5h:
            q8uKG:
            goto zQ0C3;
            ThWJF:
            t7FuC:
            goto Vkpd9;
            tibeG:
        } catch (\Exception $QEfxK) {
            Log::info("S25BfMDKrX8cB has been deleted, discard it", ['fileId' => $eXur0, 'err' => $QEfxK->getMessage()]);
            return;
        }
        goto PLwca;
        wkwgO:
        ini_set('memory_limit', '-1');
        goto AwWFP;
        PLwca:
    }
    private function m5oIXuU27UI(S25BfMDKrX8cB $DuZ1o, $x9Hx2) : bool
    {
        goto U6RhB;
        U6RhB:
        if ($x9Hx2) {
            goto lIQyf;
        }
        goto Ngv4U;
        oUDi4:
        $s2u07 = (int) round($DuZ1o->getAttribute('duration') ?? 0);
        goto Y9yFK;
        ByFe8:
        lIQyf:
        goto oUDi4;
        Ngv4U:
        return false;
        goto ByFe8;
        Y9yFK:
        switch (true) {
            case $DuZ1o->width() * $DuZ1o->height() >= 1920 * 1080 && $DuZ1o->width() * $DuZ1o->height() < 2560 * 1440:
                return $s2u07 > 10 * 60;
            case $DuZ1o->width() * $DuZ1o->height() >= 2560 * 1440 && $DuZ1o->width() * $DuZ1o->height() < 3840 * 2160:
                return $s2u07 > 5 * 60;
            case $DuZ1o->width() * $DuZ1o->height() >= 3840 * 2160:
                return $s2u07 > 3 * 60;
            default:
                return false;
        }
        goto D7_oU;
        D7_oU:
        yHbec:
        goto M6EA2;
        M6EA2:
        OIGdV:
        goto y5p5i;
        y5p5i:
    }
    private function m9reGjTaOJW(NzkrkFhIBihmO $ggIs8, string $JjMYw) : ?Mk5y6pFXlppNf
    {
        goto gKOqV;
        bIaoh:
        return new Mk5y6pFXlppNf($qOvCf, 0, 0, null, null);
        goto NA0dl;
        gKOqV:
        $qOvCf = $ggIs8->mPPnQnRyeLv($JjMYw);
        goto Xuf3J;
        z5rGd:
        if (!$qOvCf) {
            goto TBIa_;
        }
        goto bIaoh;
        Xuf3J:
        Log::info("Resolve watermark for job with url", ['url' => $JjMYw, 'uri' => $qOvCf]);
        goto z5rGd;
        YpBiJ:
        return null;
        goto w9bBk;
        NA0dl:
        TBIa_:
        goto YpBiJ;
        w9bBk:
    }
    private function mVH9MOZ85ko(int $vwL5B, int $ttadT) : bool
    {
        return $vwL5B * $ttadT > 1.5 * (1920 * 1080);
    }
    private function mrTeS3smYj8(int $vwL5B, int $ttadT) : array
    {
        $F0A3p = new BhJmEYEHGxa9p($vwL5B, $ttadT);
        return $F0A3p->mfzr35vkaQI();
    }
    private function mDr1EOCIFyv(HJJu0xs0QACaQ $MgH4F) : string
    {
        goto RA9DF;
        CMEbA:
        return 's3://' . $this->ZCKne . '/' . $MgH4F->filename;
        goto Tal2u;
        RA9DF:
        if (!($MgH4F->BlJMK == VCKF0xK25vLxq::S3)) {
            goto nfAeC;
        }
        goto CMEbA;
        v_4zx:
        return $this->OKvrN->url($MgH4F->filename);
        goto S718_;
        Tal2u:
        nfAeC:
        goto v_4zx;
        S718_:
    }
}
