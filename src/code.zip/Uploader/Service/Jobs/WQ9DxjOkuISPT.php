<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class WQ9DxjOkuISPT
{
    private $hOV1v;
    private $SRWQz;
    private $gGE8I;
    private $UBJ9G;
    public function __construct($s_InJ, $FRjEq, $duBfR, $e1L33)
    {
        goto xbkRB;
        InUF0:
        $this->hOV1v = $s_InJ;
        goto tyVLW;
        xbkRB:
        $this->SRWQz = $FRjEq;
        goto y2s2l;
        w7WLt:
        $this->UBJ9G = $e1L33;
        goto InUF0;
        y2s2l:
        $this->gGE8I = $duBfR;
        goto w7WLt;
        tyVLW:
    }
    public function mAceo7BJgV2(?int $Gsmm4, ?int $iM4bK, string $fbB2w, bool $T9cmY = false) : string
    {
        goto rhnCA;
        RinAd:
        if (!$this->gGE8I->exists($jGQTt)) {
            goto q7Sua;
        }
        goto EVoBZ;
        mqtpR:
        $QCOId = 0.1;
        goto db8Zy;
        jiyAJ:
        if (!($Gsmm4 > 1500)) {
            goto W4vej;
        }
        goto nfqX3;
        gs54z:
        $rAoIP = $Gsmm4 - $PYMNQ;
        goto JcHI3;
        A8R8U:
        throw new \RuntimeException("RVcEF1JsGQd8M dimensions are not available.");
        goto sQpQD;
        db8Zy:
        list($GbyUm, $PYMNQ, $Nv4fG) = $this->moGnSvxaPa5($fbB2w, $Gsmm4, $QCOId, (float) $Gsmm4 / $iM4bK);
        goto AbjOD;
        kyn3E:
        q7Sua:
        goto nmFbx;
        mHJr4:
        $rAoIP -= $XnVIF;
        goto jiyAJ;
        JcHI3:
        $XnVIF = (int) ($rAoIP / 80);
        goto mHJr4;
        tcBoy:
        $xobEP->text($Nv4fG, $rAoIP, (int) $U9Wdm, function ($Wtz9R) use($GbyUm) {
            goto ngibz;
            ngibz:
            $Wtz9R->file(public_path($this->SRWQz));
            goto t2Qzw;
            DFVP2:
            $Wtz9R->valign('middle');
            goto Xvtvv;
            t2Qzw:
            $dA41u = (int) ($GbyUm * 1.2);
            goto DNX9R;
            c8kzm:
            $Wtz9R->color([185, 185, 185, 1]);
            goto DFVP2;
            Xvtvv:
            $Wtz9R->align('middle');
            goto avKJQ;
            DNX9R:
            $Wtz9R->size(max($dA41u, 1));
            goto c8kzm;
            avKJQ:
        });
        goto jO6Py;
        rhnCA:
        if (!($Gsmm4 === null || $iM4bK === null)) {
            goto R2uR8;
        }
        goto A8R8U;
        AbjOD:
        $jGQTt = $this->mioCGCuINp2($Nv4fG, $Gsmm4, $iM4bK, $PYMNQ, $GbyUm);
        goto RinAd;
        J0Az6:
        W4vej:
        goto Id6AS;
        nmFbx:
        $xobEP = $this->hOV1v->call($this, $Gsmm4, $iM4bK);
        goto gs54z;
        Id6AS:
        $U9Wdm = $iM4bK - $GbyUm - 10;
        goto tcBoy;
        LgN9c:
        $this->gGE8I->put($jGQTt, $xobEP->stream('png'));
        goto GCMmR;
        jO6Py:
        $this->UBJ9G->put($jGQTt, $xobEP->stream('png'));
        goto LgN9c;
        sQpQD:
        R2uR8:
        goto mqtpR;
        GCMmR:
        return $T9cmY ? $jGQTt : $this->gGE8I->url($jGQTt);
        goto b4wyf;
        EVoBZ:
        return $T9cmY ? $jGQTt : $this->gGE8I->url($jGQTt);
        goto kyn3E;
        nfqX3:
        $rAoIP -= $XnVIF * 0.4;
        goto J0Az6;
        b4wyf:
    }
    private function mioCGCuINp2(string $fbB2w, int $Gsmm4, int $iM4bK, int $b6g3o, int $lxnBk) : string
    {
        $vKkjE = ltrim($fbB2w, '@');
        return "v2/watermark/{$vKkjE}/{$Gsmm4}x{$iM4bK}_{$b6g3o}x{$lxnBk}/text_watermark.png";
    }
    private function moGnSvxaPa5($fbB2w, int $Gsmm4, float $lOa1f, float $vQG8k) : array
    {
        goto AemSr;
        eTtzH:
        $REhhm = $PYMNQ / (strlen($Nv4fG) * 0.8);
        goto tlJO2;
        tlJO2:
        return [(int) $REhhm, $REhhm * strlen($Nv4fG) / 1.8, $Nv4fG];
        goto DUNDs;
        XaSg0:
        $PYMNQ = (int) ($Gsmm4 * $lOa1f);
        goto tPvia;
        LnWio:
        return [(int) $REhhm, $PYMNQ, $Nv4fG];
        goto uG2yL;
        LFhou:
        $REhhm = 1 / $vQG8k * $PYMNQ / strlen($Nv4fG);
        goto LnWio;
        AemSr:
        $Nv4fG = '@' . $fbB2w;
        goto XaSg0;
        tPvia:
        if (!($vQG8k > 1)) {
            goto bcWah;
        }
        goto eTtzH;
        DUNDs:
        bcWah:
        goto LFhou;
        uG2yL:
    }
}
