<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class DwSSl2FPmKKoS implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $FILUb) : void
    {
        goto HO0ue;
        m27OS:
        ENf8V:
        goto V1Fum;
        y8kFw:
        if ($zef_R->width() > 0 && $zef_R->height() > 0) {
            goto ENf8V;
        }
        goto vYiJJ;
        HO0ue:
        $zef_R = CUaMUcjkFHEwK::findOrFail($FILUb);
        goto y8kFw;
        vYiJJ:
        $this->mH20aM57tFy($zef_R);
        goto m27OS;
        V1Fum:
    }
    private function mH20aM57tFy(CUaMUcjkFHEwK $kvzTH) : void
    {
        goto mlh3J;
        mlh3J:
        $RrBvn = $kvzTH->getView();
        goto qJJT3;
        V9A0G:
        $tCSTz = $xUtpC->getVideoStream();
        goto BoIR3;
        BoIR3:
        $xCBjf = $tCSTz->getDimensions();
        goto zdT1D;
        zdT1D:
        $kvzTH->update(['duration' => $xUtpC->getDurationInSeconds(), 'resolution' => $xCBjf->getWidth() . 'x' . $xCBjf->getHeight(), 'fps' => $tCSTz->get('r_frame_rate') ?? 30]);
        goto IR4Fi;
        qJJT3:
        $xUtpC = FFMpeg::fromDisk($RrBvn['path'])->open($kvzTH->getAttribute('filename'));
        goto V9A0G;
        IR4Fi:
    }
}
