<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class ByT9ChyiVIKXx implements GenerateThumbnailJobInterface
{
    const jH5gF = 150;
    const IIiB9 = 150;
    private $z7YJI;
    private $MpAl4;
    private $wi_W5;
    public function __construct($fvRbj, $U2KRS, $WLmZw)
    {
        goto cPhIz;
        DMvMU:
        $this->MpAl4 = $U2KRS;
        goto g0tiJ;
        g0tiJ:
        $this->wi_W5 = $WLmZw;
        goto BETWr;
        cPhIz:
        $this->z7YJI = $fvRbj;
        goto DMvMU;
        BETWr:
    }
    public function generate(string $S580N)
    {
        goto ERuIb;
        S6ilw:
        try {
            goto DjDUH;
            gnMeo:
            unset($O7eUx);
            goto QYfyn;
            ve84q:
            $gNhb4->update(['thumbnail' => $d1QWa, 'status' => EHhCBxlsVyz9C::THUMBNAIL_PROCESSED]);
            goto tvN90;
            DjDUH:
            $e3FbC = $this->MpAl4;
            goto sRKYy;
            LzEVn:
            $O7eUx = $this->z7YJI->call($this, $e3FbC->path($gNhb4->getLocation()));
            goto sA_4b;
            QYfyn:
            if (!($j0Wbx !== false)) {
                goto J9Kfp;
            }
            goto ve84q;
            sA_4b:
            $O7eUx->orient()->resize(150, 150);
            goto u8T_N;
            sRKYy:
            $gNhb4 = KfEJaEGpFJ0tm::findOrFail($S580N);
            goto LzEVn;
            RTTqI:
            $j0Wbx = $this->wi_W5->put($d1QWa, $O7eUx->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto gnMeo;
            tvN90:
            J9Kfp:
            goto XeAvZ;
            u8T_N:
            $d1QWa = $this->mE1oPwTqx6V($gNhb4);
            goto RTTqI;
            XeAvZ:
        } catch (ModelNotFoundException $ah9h0) {
            Log::info("KfEJaEGpFJ0tm has been deleted, discard it", ['imageId' => $S580N]);
            return;
        } catch (\Exception $ah9h0) {
            Log::error("Failed to generate thumbnail", ['imageId' => $S580N, 'error' => $ah9h0->getMessage()]);
        }
        goto sa00s;
        ERuIb:
        Log::info("Generating thumbnail", ['imageId' => $S580N]);
        goto YG7oF;
        YG7oF:
        ini_set('memory_limit', '-1');
        goto S6ilw;
        sa00s:
    }
    private function mE1oPwTqx6V(GpdHFYchpZHPa $gNhb4) : string
    {
        goto rBoJ8;
        rsjk0:
        return $KNxTL . '/' . $gNhb4->getFilename() . '.jpg';
        goto opaZD;
        Sh0xY:
        $KNxTL = $zVNDR . '/' . self::jH5gF . 'X' . self::IIiB9;
        goto rsjk0;
        e5FIJ:
        $zVNDR = dirname($d1QWa);
        goto Sh0xY;
        rBoJ8:
        $d1QWa = $gNhb4->getLocation();
        goto e5FIJ;
        opaZD:
    }
}
