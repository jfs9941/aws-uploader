<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
class AS2qU8Di95CMu implements BlurJobInterface
{
    const QST3M = 15;
    const vvzG4 = 500;
    const Ott5c = 500;
    private $GqFb6;
    private $BfyCm;
    private $S0euz;
    public function __construct($WV89v, $ejImE, $t9rFg)
    {
        goto JQJOd;
        ktGTv:
        $this->GqFb6 = $WV89v;
        goto wKHA_;
        JQJOd:
        $this->S0euz = $t9rFg;
        goto tDDB7;
        tDDB7:
        $this->BfyCm = $ejImE;
        goto ktGTv;
        wKHA_:
    }
    public function blur(string $aK0gt) : void
    {
        goto PO1hN;
        Zzoat:
        throw new \Exception('Failed to set final permissions on image file: ' . $e78sf);
        goto Aewlb;
        Wm71r:
        $SjjXB = $this->mG102AKvrVC($F1u8w);
        goto pXM8c;
        VmYnS:
        $this->S0euz->put($F1u8w->filename, $ptRL8);
        goto m2G3z;
        Ow3bE:
        if (chmod($e78sf, 0664)) {
            goto StM2d;
        }
        goto RiA7y;
        RiA7y:
        \Log::warning('Failed to set final permissions on image file: ' . $e78sf);
        goto Zzoat;
        ohXpM:
        ini_set('memory_limit', '-1');
        goto ThH7y;
        bWBOe:
        $qKtXa->resize(self::vvzG4, self::Ott5c / $e61mr);
        goto lfLHT;
        pXM8c:
        $e78sf = $this->BfyCm->put($SjjXB, $qKtXa->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto RwPnU;
        m2G3z:
        Sp1NN:
        goto gzQiE;
        PO1hN:
        $F1u8w = MpPzMcfcRTISZ::findOrFail($aK0gt);
        goto ohXpM;
        Aewlb:
        StM2d:
        goto f5WhP;
        ifYwX:
        $e61mr = $qKtXa->width() / $qKtXa->height();
        goto bWBOe;
        RwDfO:
        $ptRL8 = $this->BfyCm->get($F1u8w->filename);
        goto VmYnS;
        RwPnU:
        unset($qKtXa);
        goto Ow3bE;
        lfLHT:
        $qKtXa->blur(self::QST3M);
        goto Wm71r;
        gzQiE:
        $qKtXa = $this->GqFb6->call($this, $this->S0euz->path($F1u8w->getLocation()));
        goto ifYwX;
        ThH7y:
        if (!($F1u8w->nP7o5 == ZuZC67ch9j73R::S3 && !$this->S0euz->exists($F1u8w->filename))) {
            goto Sp1NN;
        }
        goto RwDfO;
        f5WhP:
        $F1u8w->update(['preview' => $SjjXB]);
        goto a9Ddm;
        a9Ddm:
    }
    private function mG102AKvrVC($bBmy0) : string
    {
        goto k3EUI;
        LFhpD:
        $ODUZC = dirname($HyAAV) . '/preview/';
        goto V3SK8;
        IqiOd:
        b1WuD:
        goto TGM4_;
        V3SK8:
        if ($this->S0euz->exists($ODUZC)) {
            goto b1WuD;
        }
        goto mopR_;
        TGM4_:
        return $ODUZC . $bBmy0->getFilename() . '.jpg';
        goto EbI0Z;
        mopR_:
        $this->S0euz->makeDirectory($ODUZC, 0755, true);
        goto IqiOd;
        k3EUI:
        $HyAAV = $bBmy0->getLocation();
        goto LFhpD;
        EbI0Z:
    }
}
