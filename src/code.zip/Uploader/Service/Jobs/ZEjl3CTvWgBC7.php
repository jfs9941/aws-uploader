<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class ZEjl3CTvWgBC7 implements CompressJobInterface
{
    const FRWsg = 60;
    private $e2JZZ;
    private $dwubH;
    private $g23qO;
    public function __construct($yGjLo, $VzPPJ, $EWJhD)
    {
        goto cJabI;
        cJabI:
        $this->e2JZZ = $yGjLo;
        goto EryL7;
        EryL7:
        $this->g23qO = $EWJhD;
        goto HP35J;
        HP35J:
        $this->dwubH = $VzPPJ;
        goto MP8Ey;
        MP8Ey:
    }
    public function compress(string $B_L9m)
    {
        goto KiaUm;
        y0bao:
        $n0RF8 = memory_get_peak_usage();
        goto kXZW3;
        KiaUm:
        $iw0Jp = microtime(true);
        goto cXEW7;
        ZOoed:
        try {
            goto CCUTU;
            agIXr:
            $B3hDm = $this->dwubH->path($zCabx->getLocation());
            goto kZMjO;
            CCUTU:
            $zCabx = XMeo8SOmME8kj::findOrFail($B_L9m);
            goto agIXr;
            deUuR:
            try {
                goto DsKiH;
                DsKiH:
                $QHJY0 = $this->dwubH->path(str_replace('.jpg', '.webp', $zCabx->getLocation()));
                goto vy3p6;
                vy3p6:
                $this->mrWnrzq0Oii($B3hDm, $QHJY0);
                goto W699K;
                W699K:
                $this->mQofxYzPkwi($zCabx, 'webp');
                goto jRMh6;
                jRMh6:
            } catch (\Exception $kHEpW) {
                goto JDm8c;
                JDm8c:
                Log::error("Failed to create webp version, fallback to the jpeg", ['imageId' => $B_L9m, 'error' => $kHEpW->getMessage()]);
                goto IrJn1;
                WR9Q3:
                $this->mW1N78uOxhq($B3hDm, $QHJY0);
                goto yLF2G;
                IrJn1:
                $QHJY0 = $this->dwubH->path($zCabx->getLocation());
                goto WR9Q3;
                yLF2G:
            }
            goto cvL6s;
            lBN5g:
            $zCabx = $this->mQofxYzPkwi($zCabx, 'jpg');
            goto Pgzu8;
            kZMjO:
            if (!(strtolower($zCabx->getExtension()) === 'png' || strtolower($zCabx->getExtension()) === 'heic')) {
                goto qndLl;
            }
            goto lBN5g;
            Pgzu8:
            qndLl:
            goto deUuR;
            cvL6s:
        } catch (\Throwable $kHEpW) {
            goto v5lEP;
            g0MEH:
            EJBVj:
            goto gkUcp;
            gkUcp:
            Log::error("Failed to compress image", ['imageId' => $B_L9m, 'error' => $kHEpW->getMessage()]);
            goto QxtId;
            v5lEP:
            if (!$kHEpW instanceof ModelNotFoundException) {
                goto EJBVj;
            }
            goto zRTQm;
            zRTQm:
            Log::info("XMeo8SOmME8kj has been deleted, discard it", ['imageId' => $B_L9m]);
            goto dxLKR;
            dxLKR:
            return;
            goto g0MEH;
            QxtId:
        } finally {
            $C_8tm = microtime(true);
            $U52Iz = memory_get_usage();
            $QtsLN = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $B_L9m, 'execution_time_sec' => $C_8tm - $iw0Jp, 'memory_usage_mb' => ($U52Iz - $hi2m0) / 1024 / 1024, 'peak_memory_usage_mb' => ($QtsLN - $n0RF8) / 1024 / 1024]);
        }
        goto jgVRJ;
        kXZW3:
        Log::info("Compress image", ['imageId' => $B_L9m]);
        goto ZOoed;
        cXEW7:
        $hi2m0 = memory_get_usage();
        goto y0bao;
        jgVRJ:
    }
    private function mW1N78uOxhq($B3hDm, $QHJY0)
    {
        goto dClEo;
        ZKmKY:
        $e5260->orient()->toJpeg(self::FRWsg)->save($QHJY0);
        goto vsyvT;
        vsyvT:
        $this->g23qO->put($QHJY0, $e5260->toJpeg(self::FRWsg), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
        goto W0L8y;
        W0L8y:
        unset($e5260);
        goto wQp8O;
        dClEo:
        $e5260 = $this->e2JZZ->call($this, $B3hDm);
        goto ZKmKY;
        wQp8O:
    }
    private function mrWnrzq0Oii($B3hDm, $QHJY0)
    {
        goto Xpkb4;
        lEyAh:
        $this->g23qO->put($QHJY0, $e5260->toJpeg(self::FRWsg), ['visibility' => 'public', 'ContentType' => 'image/webp', 'ContentDisposition' => 'inline']);
        goto pM3Gl;
        JEqI_:
        $e5260->orient()->toWebp(self::FRWsg);
        goto lEyAh;
        pM3Gl:
        unset($e5260);
        goto hfuZG;
        Xpkb4:
        $e5260 = $this->e2JZZ->call($this, $B3hDm);
        goto JEqI_;
        hfuZG:
    }
    private function mQofxYzPkwi($zCabx, $hhhcy)
    {
        goto ZgLqw;
        aS5_g:
        return $zCabx;
        goto gkgDO;
        ZgLqw:
        $zCabx->setAttribute('type', $hhhcy);
        goto bdKva;
        sajtz:
        $zCabx->save();
        goto aS5_g;
        bdKva:
        $zCabx->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC', '.jpg'], ".{$hhhcy}", $zCabx->getLocation()));
        goto sajtz;
        gkgDO:
    }
}
