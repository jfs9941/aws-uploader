<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Intervention\Q48IcpSr3UpAT\Interfaces\ImageInterface;
use Intervention\Q48IcpSr3UpAT\Typography\FontFactory;
class SBKmhirduBuxQ
{
    private $kYQtS;
    private $XdOe7;
    private $DksH2;
    private $iAAqk;
    public function __construct($vWUsi, $ZKVnw, $l4Drs, $YNIuu)
    {
        goto IDVQN;
        d11lV:
        $this->kYQtS = $vWUsi;
        goto Rq05y;
        IDVQN:
        $this->XdOe7 = $ZKVnw;
        goto oNarp;
        KuYiH:
        $this->iAAqk = $YNIuu;
        goto d11lV;
        oNarp:
        $this->DksH2 = $l4Drs;
        goto KuYiH;
        Rq05y:
    }
    public function m3ZG46sP9md(?int $GPsTK, ?int $ldQdP, string $nm3TE, bool $WA0Mf = false) : string
    {
        goto ujLM4;
        VTlPf:
        $AvW7Y = $this->kYQtS->call($this, $GPsTK, $ldQdP);
        goto J4TTq;
        bAp8u:
        $azt1o -= $iLyoc * 0.4;
        goto GCKIm;
        Zgosy:
        if (!$this->DksH2->exists($cJV8L)) {
            goto lKyFy;
        }
        goto HNYf_;
        DpKsq:
        U5riZ:
        goto jk0g2;
        TUciN:
        return $WA0Mf ? $cJV8L : $this->DksH2->url($cJV8L);
        goto X_oQa;
        QODCh:
        $iLyoc = (int) ($azt1o / 80);
        goto nuWrL;
        J4TTq:
        $azt1o = $GPsTK - $IT0r1;
        goto QODCh;
        l2fza:
        $this->DksH2->put($cJV8L, $AvW7Y->toPng());
        goto ZDe0j;
        ujLM4:
        if (!($GPsTK === null || $ldQdP === null)) {
            goto U5riZ;
        }
        goto J3GCP;
        GCKIm:
        ZgTgU:
        goto ZPFRM;
        CWIlX:
        $this->iAAqk->put($cJV8L, $AvW7Y->toPng());
        goto l2fza;
        wzXeP:
        $AvW7Y->text($u5luO, $azt1o, (int) $LQimB, function ($DlsEs) use($jxCs9) {
            goto azBrz;
            VJOxC:
            $DlsEs->size(max($aNz5T, 1));
            goto TBjzg;
            KeWXg:
            $DlsEs->align('middle');
            goto ZKAe8;
            jx1m2:
            $aNz5T = (int) ($jxCs9 * 1.2);
            goto VJOxC;
            iXc0J:
            $DlsEs->valign('middle');
            goto KeWXg;
            azBrz:
            $DlsEs->file(public_path($this->XdOe7));
            goto jx1m2;
            TBjzg:
            $DlsEs->color('#B9B9B9');
            goto iXc0J;
            ZKAe8:
        });
        goto CWIlX;
        WTaHa:
        $cJV8L = $this->mek6xyAVy6I($u5luO, $GPsTK, $ldQdP, $IT0r1, $jxCs9);
        goto Zgosy;
        ZPFRM:
        $LQimB = $ldQdP - $jxCs9 - 10;
        goto wzXeP;
        yYAvu:
        if (!($GPsTK > 1500)) {
            goto ZgTgU;
        }
        goto bAp8u;
        nuWrL:
        $azt1o -= $iLyoc;
        goto yYAvu;
        ZDe0j:
        unset($AvW7Y);
        goto TUciN;
        nvgN7:
        lKyFy:
        goto VTlPf;
        HNYf_:
        return $WA0Mf ? $cJV8L : $this->DksH2->url($cJV8L);
        goto nvgN7;
        oeH2z:
        list($jxCs9, $IT0r1, $u5luO) = $this->mIdLFCUGmXq($nm3TE, $GPsTK, $gm45r, (float) $GPsTK / $ldQdP);
        goto WTaHa;
        J3GCP:
        throw new \RuntimeException("M7oTJdNm24KG4 dimensions are not available.");
        goto DpKsq;
        jk0g2:
        $gm45r = 0.1;
        goto oeH2z;
        X_oQa:
    }
    private function mek6xyAVy6I(string $nm3TE, int $GPsTK, int $ldQdP, int $dLEBQ, int $tXqC7) : string
    {
        $f531E = ltrim($nm3TE, '@');
        return "v2/watermark/{$f531E}/{$GPsTK}x{$ldQdP}_{$dLEBQ}x{$tXqC7}/text_watermark.png";
    }
    private function mIdLFCUGmXq($nm3TE, int $GPsTK, float $kUwzW, float $T6coX) : array
    {
        goto bS0Le;
        YYp3i:
        $cT8kZ = 1 / $T6coX * $IT0r1 / strlen($u5luO);
        goto cwuvw;
        xJIBe:
        $IT0r1 = (int) ($GPsTK * $kUwzW);
        goto SwXrL;
        bS0Le:
        $u5luO = '@' . $nm3TE;
        goto xJIBe;
        vCCdr:
        return [(int) $cT8kZ, $cT8kZ * strlen($u5luO) / 1.8, $u5luO];
        goto HV7dg;
        HV7dg:
        tjNjL:
        goto YYp3i;
        zEFaf:
        $cT8kZ = $IT0r1 / (strlen($u5luO) * 0.8);
        goto vCCdr;
        SwXrL:
        if (!($T6coX > 1)) {
            goto tjNjL;
        }
        goto zEFaf;
        cwuvw:
        return [(int) $cT8kZ, $IT0r1, $u5luO];
        goto yO0Cm;
        yO0Cm:
    }
}
