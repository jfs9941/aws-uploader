<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class H6PUY3r1zkBDt implements StoreToS3JobInterface
{
    private $kAoN_;
    private $iHPgt;
    private $cGz6K;
    public function __construct($QJMxa, $zeM4q, $DAY12)
    {
        goto TQHIy;
        TQHIy:
        $this->iHPgt = $zeM4q;
        goto HRTHA;
        zb0EA:
        $this->kAoN_ = $QJMxa;
        goto aW0zG;
        HRTHA:
        $this->cGz6K = $DAY12;
        goto zb0EA;
        aW0zG:
    }
    public function store(string $tu00C) : void
    {
        goto HQch7;
        d6bi5:
        Log::info("VPGaYsuFJzbQ0 has been deleted, discard it", ['fileId' => $tu00C]);
        goto LlXwJ;
        FOw1T:
        $fQjwQ = $this->cGz6K->path($bKiC5->getLocation());
        goto obYge;
        FkI9E:
        if (!($bKiC5->getAttribute('preview') && $this->cGz6K->exists($bKiC5->getAttribute('preview')))) {
            goto vF7VF;
        }
        goto hffzH;
        Z6kqG:
        vF7VF:
        goto bSerh;
        obYge:
        $this->mUouwUfgoVJ($fQjwQ, $bKiC5->getLocation());
        goto K2QNo;
        IX_Hj:
        $FS81q = $this->cGz6K->path($uuWX0);
        goto ANAXI;
        bSerh:
        if (!$bKiC5->update(['driver' => ISqBWmYzjt1eQ::S3, 'status' => WSEQ88VDOa3X0::FINISHED])) {
            goto uivf2;
        }
        goto VTSoV;
        ivd5b:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $tu00C]);
        goto l74xJ;
        HQch7:
        $bKiC5 = VPGaYsuFJzbQ0::findOrFail($tu00C);
        goto bwNcf;
        YJxHz:
        uJlyb:
        goto FOw1T;
        SvLA6:
        return;
        goto UYFsj;
        ANAXI:
        $iSeOK = $this->kAoN_->call($this, $FS81q);
        goto zIsQB;
        VTSoV:
        Log::info("VPGaYsuFJzbQ0 stored to S3, update the children attachments", ['fileId' => $tu00C]);
        goto ye56J;
        zIsQB:
        $this->iHPgt->put($bKiC5->getAttribute('thumbnail'), $this->cGz6K->get($uuWX0), ['visibility' => 'public', 'ContentType' => $iSeOK->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Vj_v2;
        bwNcf:
        if ($bKiC5) {
            goto uJlyb;
        }
        goto d6bi5;
        y7aff:
        $this->iHPgt->put($bKiC5->getAttribute('preview'), $this->cGz6K->get($bKiC5->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $VkWDl->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Z6kqG;
        H6Zv2:
        $VkWDl = $this->kAoN_->call($this, $OXbOZ);
        goto y7aff;
        Vj_v2:
        e3fsv:
        goto FkI9E;
        AOmEs:
        if (!($uuWX0 && $this->cGz6K->exists($uuWX0))) {
            goto e3fsv;
        }
        goto IX_Hj;
        K2QNo:
        $uuWX0 = $bKiC5->getAttribute('thumbnail');
        goto AOmEs;
        UYFsj:
        uivf2:
        goto ivd5b;
        LlXwJ:
        return;
        goto YJxHz;
        ye56J:
        VPGaYsuFJzbQ0::where('parent_id', $tu00C)->update(['driver' => ISqBWmYzjt1eQ::S3, 'preview' => $bKiC5->getAttribute('preview'), 'thumbnail' => $bKiC5->getAttribute('thumbnail')]);
        goto SvLA6;
        hffzH:
        $OXbOZ = $this->cGz6K->path($bKiC5->getAttribute('preview'));
        goto H6Zv2;
        l74xJ:
    }
    private function mUouwUfgoVJ($we_6L, $RlcMn, $B7MU4 = '')
    {
        goto Vm1fK;
        KYS_T:
        $we_6L = str_replace('.jpg', $B7MU4, $we_6L);
        goto WmmYe;
        Vm1fK:
        if (!$B7MU4) {
            goto A0dzT;
        }
        goto KYS_T;
        IJnzZ:
        try {
            $h4i8i = $this->kAoN_->call($this, $we_6L);
            $this->iHPgt->put($RlcMn, $this->cGz6K->get($RlcMn), ['visibility' => 'public', 'ContentType' => $h4i8i->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $OaHp2) {
            Log::error("Failed to upload image to S3", ['s3Path' => $RlcMn, 'error' => $OaHp2->getMessage()]);
        }
        goto jdQM0;
        WmmYe:
        $RlcMn = str_replace('.jpg', $B7MU4, $RlcMn);
        goto wMRVH;
        wMRVH:
        A0dzT:
        goto IJnzZ;
        jdQM0:
    }
}
