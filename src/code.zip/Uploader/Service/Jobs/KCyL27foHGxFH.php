<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class KCyL27foHGxFH
{
    private $Lx2z9;
    private $YtzgG;
    public function __construct(int $LvC_1, int $hl5ZR)
    {
        goto dY6cw;
        CZ9XH:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto cTXH3;
        C0bnw:
        HMFre:
        goto yM8t8;
        dY6cw:
        if (!($LvC_1 <= 0)) {
            goto HMFre;
        }
        goto SVJ_T;
        ZxYPu:
        $this->Lx2z9 = $LvC_1;
        goto jTBJS;
        cTXH3:
        kfHD4:
        goto ZxYPu;
        SVJ_T:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto C0bnw;
        jTBJS:
        $this->YtzgG = $hl5ZR;
        goto nl8Om;
        yM8t8:
        if (!($hl5ZR <= 0)) {
            goto kfHD4;
        }
        goto CZ9XH;
        nl8Om:
    }
    private static function m9lHjSQ03KS($AG_WC, string $Q_9ae = 'floor') : int
    {
        goto OO5Dk;
        gG_GV:
        rUuQm:
        goto LRdOJ;
        qMVwp:
        return $AG_WC;
        goto BZrIs;
        uBy3b:
        if (!(is_float($AG_WC) && $AG_WC == floor($AG_WC) && (int) $AG_WC % 2 === 0)) {
            goto cQjHP;
        }
        goto lXrEf;
        BZrIs:
        GolGH:
        goto uBy3b;
        oxDAx:
        switch (strtolower($Q_9ae)) {
            case 'ceil':
                return (int) (ceil($AG_WC / 2) * 2);
            case 'round':
                return (int) (round($AG_WC / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($AG_WC / 2) * 2);
        }
        goto DnOBq;
        DnOBq:
        RPpUi:
        goto gG_GV;
        lXrEf:
        return (int) $AG_WC;
        goto lRs9k;
        OO5Dk:
        if (!(is_int($AG_WC) && $AG_WC % 2 === 0)) {
            goto GolGH;
        }
        goto qMVwp;
        lRs9k:
        cQjHP:
        goto oxDAx;
        LRdOJ:
    }
    public function mHJWxewSCRp(string $ukBnb = 'floor') : array
    {
        goto Ml993;
        Yzynn:
        kyU9q:
        goto oVLZ1;
        sK9QF:
        $ei1O1 = 2;
        goto n3FAp;
        BpUHb:
        $mmJOK = $tyxFK;
        goto UVUT_;
        ubsbN:
        $Lt_hi = $this->Lx2z9 * $roHs7;
        goto ndTjT;
        XhIaA:
        $mmJOK = 2;
        goto Yzynn;
        UVUT_:
        $roHs7 = $mmJOK / $this->Lx2z9;
        goto B2Jva;
        hyBZQ:
        $roHs7 = $ei1O1 / $this->YtzgG;
        goto ubsbN;
        zLO9y:
        if (!($mmJOK < 2)) {
            goto kyU9q;
        }
        goto XhIaA;
        tKftq:
        nEks8:
        goto zLO9y;
        myR8F:
        if ($this->Lx2z9 >= $this->YtzgG) {
            goto awI5r;
        }
        goto BpUHb;
        Xud8y:
        $ei1O1 = 0;
        goto myR8F;
        ndTjT:
        $mmJOK = self::m9lHjSQ03KS(round($Lt_hi), $ukBnb);
        goto tKftq;
        Ml993:
        $tyxFK = 1080;
        goto i0PpL;
        FJ6Ew:
        return ['width' => $mmJOK, 'height' => $ei1O1];
        goto ZrY4Z;
        GGAgv:
        goto nEks8;
        goto Vh5FD;
        B2Jva:
        $ydSaH = $this->YtzgG * $roHs7;
        goto k5M0x;
        jApfq:
        $ei1O1 = $tyxFK;
        goto hyBZQ;
        oVLZ1:
        if (!($ei1O1 < 2)) {
            goto uc9fj;
        }
        goto sK9QF;
        n3FAp:
        uc9fj:
        goto FJ6Ew;
        Vh5FD:
        awI5r:
        goto jApfq;
        k5M0x:
        $ei1O1 = self::m9lHjSQ03KS(round($ydSaH), $ukBnb);
        goto GGAgv;
        i0PpL:
        $mmJOK = 0;
        goto Xud8y;
        ZrY4Z:
    }
}
