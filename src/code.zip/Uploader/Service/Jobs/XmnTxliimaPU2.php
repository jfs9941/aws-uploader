<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Core\G4MP13yRAmltw;
class XmnTxliimaPU2 implements BlurVideoJobInterface
{
    const S50FG = 15;
    const z_WAJ = 500;
    const i_ulN = 500;
    private $wEW4b;
    private $dhrkT;
    private $sf39X;
    public function __construct($jlVrW, $v8n0s, $ZqxJI)
    {
        goto qJqrm;
        ybfhv:
        $this->dhrkT = $v8n0s;
        goto TvyOO;
        TvyOO:
        $this->wEW4b = $jlVrW;
        goto pn5A3;
        qJqrm:
        $this->sf39X = $ZqxJI;
        goto ybfhv;
        pn5A3:
    }
    public function blur(string $cQqZd) : void
    {
        goto SkUPX;
        zHb8_:
        $this->sf39X->put($EhQyh->getAttribute('thumbnail'), $this->dhrkT->get($EhQyh->getAttribute('thumbnail')));
        goto SnG7J;
        eLeKK:
        $MpgR7->resize(self::z_WAJ, self::i_ulN / $NE9ag);
        goto yV6CV;
        yV6CV:
        $MpgR7->blur(self::S50FG);
        goto UrGR3;
        UrGR3:
        $RE6mo = $this->mZsjzUjcnba($EhQyh);
        goto pm7Ie;
        fg3gi:
        if (chmod($nkKif, 0664)) {
            goto wU_lp;
        }
        goto xhueF;
        qzbZx:
        $MpgR7->destroy();
        goto fg3gi;
        apyaI:
        if (!$EhQyh->getAttribute('thumbnail')) {
            goto gmFlS;
        }
        goto zHb8_;
        SkUPX:
        Log::info("Blurring for video", ['videoID' => $cQqZd]);
        goto BUhwL;
        xhueF:
        \Log::warning('Failed to set final permissions on image file: ' . $nkKif);
        goto Pu3P0;
        pstQV:
        $MpgR7->save($nkKif);
        goto gOayT;
        pm7Ie:
        $nkKif = $this->sf39X->path($RE6mo);
        goto pstQV;
        Ib43a:
        wU_lp:
        goto bsN3r;
        xVP7R:
        $NE9ag = $MpgR7->width() / $MpgR7->height();
        goto eLeKK;
        SnG7J:
        $MpgR7 = $this->wEW4b->call($this, $this->sf39X->path($EhQyh->getAttribute('thumbnail')));
        goto xVP7R;
        gOayT:
        $this->dhrkT->put($RE6mo, $this->sf39X->get($RE6mo));
        goto qzbZx;
        LZM8d:
        $EhQyh = G4MP13yRAmltw::findOrFail($cQqZd);
        goto apyaI;
        bgeBK:
        gmFlS:
        goto ADvLr;
        bsN3r:
        $EhQyh->update(['preview' => $RE6mo]);
        goto bgeBK;
        Pu3P0:
        throw new \Exception('Failed to set final permissions on image file: ' . $nkKif);
        goto Ib43a;
        BUhwL:
        ini_set('memory_limit', '-1');
        goto LZM8d;
        ADvLr:
    }
    private function mZsjzUjcnba(El0vMUwnHgT49 $VAWGs) : string
    {
        goto jFUg8;
        jFUg8:
        $IJqE5 = $VAWGs->getLocation();
        goto eCjo0;
        ccKGl:
        if ($this->sf39X->exists($ZJ0e5)) {
            goto MUxBs;
        }
        goto KxqDF;
        cxeMr:
        MUxBs:
        goto t1v74;
        eCjo0:
        $ZJ0e5 = dirname($IJqE5) . '/preview/';
        goto ccKGl;
        KxqDF:
        $this->sf39X->makeDirectory($ZJ0e5, 0755, true);
        goto cxeMr;
        t1v74:
        return $ZJ0e5 . $VAWGs->getFilename() . '.jpg';
        goto rxCXQ;
        rxCXQ:
    }
}
