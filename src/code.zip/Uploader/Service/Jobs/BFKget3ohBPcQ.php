<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class BFKget3ohBPcQ implements GenerateThumbnailForVideoInterface
{
    private $Uj0k0;
    public function __construct($mH5MU)
    {
        $this->Uj0k0 = $mH5MU;
    }
    public function generate(string $SEOXv) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $SEOXv);
        $this->Uj0k0->createThumbnail($SEOXv);
    }
}
