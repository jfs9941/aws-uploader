<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class RREwrmnTZh1cK
{
    private $megrO;
    private $RUNic;
    public function __construct(int $AyzUn, int $UxEzh)
    {
        goto yAsu5;
        XzG3i:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto dcZbQ;
        TlX6Q:
        $this->RUNic = $UxEzh;
        goto ohMt4;
        BxI6U:
        if (!($UxEzh <= 0)) {
            goto j4lRj;
        }
        goto XzG3i;
        dcZbQ:
        j4lRj:
        goto z3rrT;
        yAsu5:
        if (!($AyzUn <= 0)) {
            goto Qd_bg;
        }
        goto K3q1V;
        z3rrT:
        $this->megrO = $AyzUn;
        goto TlX6Q;
        dD6bV:
        Qd_bg:
        goto BxI6U;
        K3q1V:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto dD6bV;
        ohMt4:
    }
    private static function ma5imvWxBO6($NKl8O, string $nKxMF = 'floor') : int
    {
        goto jTnjS;
        rSPIm:
        return (int) $NKl8O;
        goto uym1p;
        y04mq:
        KlVd8:
        goto dEPO0;
        dEPO0:
        if (!(is_float($NKl8O) && $NKl8O == floor($NKl8O) && (int) $NKl8O % 2 === 0)) {
            goto eNrDr;
        }
        goto rSPIm;
        jTnjS:
        if (!(is_int($NKl8O) && $NKl8O % 2 === 0)) {
            goto KlVd8;
        }
        goto SBr1z;
        hD5Od:
        GfdgL:
        goto v7st1;
        uym1p:
        eNrDr:
        goto Dq5Ps;
        SBr1z:
        return $NKl8O;
        goto y04mq;
        Dq5Ps:
        switch (strtolower($nKxMF)) {
            case 'ceil':
                return (int) (ceil($NKl8O / 2) * 2);
            case 'round':
                return (int) (round($NKl8O / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($NKl8O / 2) * 2);
        }
        goto hD5Od;
        v7st1:
        b9Q_J:
        goto hX3nw;
        hX3nw:
    }
    public function mb5nAkDPCjm(string $uLHBA = 'floor') : array
    {
        goto R9yGc;
        bpPyF:
        $cdz8_ = 2;
        goto Km32C;
        aBEV8:
        if (!($cdz8_ < 2)) {
            goto Ll6KQ;
        }
        goto bpPyF;
        puNwo:
        oO3kG:
        goto FVMVo;
        XEBYa:
        VrNkt:
        goto Q6BZQ;
        Q6BZQ:
        $cdz8_ = $OimOg;
        goto Rpu0t;
        Hsb3p:
        return ['width' => $WsRZ0, 'height' => $cdz8_];
        goto zXDb1;
        OzddJ:
        $WsRZ0 = $OimOg;
        goto y3r0U;
        Rpu0t:
        $Trjtu = $cdz8_ / $this->RUNic;
        goto jwdwr;
        yHO94:
        if ($this->megrO >= $this->RUNic) {
            goto VrNkt;
        }
        goto OzddJ;
        UY3aB:
        goto oO3kG;
        goto XEBYa;
        R9yGc:
        $OimOg = 1080;
        goto f6_Nx;
        f6_Nx:
        $WsRZ0 = 0;
        goto xs7RC;
        WhUxm:
        nHiZ8:
        goto aBEV8;
        suFXB:
        $WsRZ0 = self::ma5imvWxBO6(round($nQ0LL), $uLHBA);
        goto puNwo;
        xs7RC:
        $cdz8_ = 0;
        goto yHO94;
        V9y5G:
        $WsRZ0 = 2;
        goto WhUxm;
        Km32C:
        Ll6KQ:
        goto Hsb3p;
        y3r0U:
        $Trjtu = $WsRZ0 / $this->megrO;
        goto jGDgg;
        jwdwr:
        $nQ0LL = $this->megrO * $Trjtu;
        goto suFXB;
        FVMVo:
        if (!($WsRZ0 < 2)) {
            goto nHiZ8;
        }
        goto V9y5G;
        jGDgg:
        $gYaS6 = $this->RUNic * $Trjtu;
        goto UL56J;
        UL56J:
        $cdz8_ = self::ma5imvWxBO6(round($gYaS6), $uLHBA);
        goto UY3aB;
        zXDb1:
    }
}
