<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service\Jobs;

use Illuminate\Support\Facades\Log;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Enum\FileDriver;
use src\Uploader\Enum\FileStatus;
class ZP0zVc8Tj5QCR implements StoreToS3JobInterface
{
    private $Q1e5h;
    private $Aj6QZ;
    private $tGIcp;
    public function __construct($OdpJM, $SaekO, $UR4Dl)
    {
        goto A9NhP;
        A9NhP:
        $this->Aj6QZ = $SaekO;
        goto LAdty;
        LAdty:
        $this->tGIcp = $UR4Dl;
        goto mYCeJ;
        mYCeJ:
        $this->Q1e5h = $OdpJM;
        goto Ngjs7;
        Ngjs7:
    }
    public function store(string $BFPg9) : void
    {
        goto VgphV;
        aB2Pd:
        if (!$JPzNm->update(['driver' => FileDriver::S3, 'status' => FileStatus::FINISHED])) {
            goto ZzEXM;
        }
        goto jvCgr;
        Hd5LB:
        ZzEXM:
        goto JJKvg;
        KRAGq:
        $ab1g_ = $this->Q1e5h->call($this, $fdqWg);
        goto GpzhN;
        iixsB:
        $this->Aj6QZ->put($JPzNm->getAttribute('thumbnail'), $pIzqs->stream(), ['visibility' => 'public', 'ContentType' => $pIzqs->mime(), 'ContentDisposition' => 'inline']);
        goto RCc3a;
        gjAEc:
        $pIzqs = $this->Q1e5h->call($this, $dKCXk);
        goto iixsB;
        RCc3a:
        rMpJJ:
        goto kYL9f;
        IMh01:
        ID6EZw1DKfqu4::where('parent_id', $BFPg9)->update(['driver' => FileDriver::S3, 'preview' => $JPzNm->getAttribute('preview'), 'thumbnail' => $JPzNm->getAttribute('thumbnail')]);
        goto Wkujr;
        s4Q_m:
        Log::info("ID6EZw1DKfqu4 has been deleted, discard it", ['fileId' => $BFPg9]);
        goto RX5Kn;
        GpzhN:
        $this->Aj6QZ->put($JPzNm->getLocation(), $ab1g_->stream(), ['visibility' => 'public', 'ContentType' => $ab1g_->mime(), 'ContentDisposition' => 'inline']);
        goto gg7yq;
        dyBW1:
        PoNcP:
        goto aB2Pd;
        kYL9f:
        if (!($JPzNm->getAttribute('preview') && $this->tGIcp->exists($JPzNm->getAttribute('preview')))) {
            goto PoNcP;
        }
        goto RGFvS;
        Hhr08:
        if (!($X6p18 && $this->tGIcp->exists($X6p18))) {
            goto rMpJJ;
        }
        goto SeL8T;
        Wkujr:
        return;
        goto Hd5LB;
        jvCgr:
        Log::info("ID6EZw1DKfqu4 stored to S3, update the children attachments", ['fileId' => $BFPg9]);
        goto IMh01;
        RX5Kn:
        return;
        goto HCbrH;
        RGFvS:
        $UStoI = $this->tGIcp->path($JPzNm->getAttribute('preview'));
        goto GVECX;
        u56q5:
        $this->Aj6QZ->put($JPzNm->getAttribute('preview'), $yNGdh->stream(), ['visibility' => 'public', 'ContentType' => $yNGdh->mime(), 'ContentDisposition' => 'inline']);
        goto dyBW1;
        bT_gs:
        $fdqWg = $this->tGIcp->path($JPzNm->getLocation());
        goto KRAGq;
        VgphV:
        $JPzNm = ID6EZw1DKfqu4::findOrFail($BFPg9);
        goto dhlqJ;
        dhlqJ:
        if ($JPzNm) {
            goto LN9_v;
        }
        goto s4Q_m;
        gg7yq:
        $X6p18 = $JPzNm->getAttribute('thumbnail');
        goto Hhr08;
        JJKvg:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $BFPg9]);
        goto u1eWn;
        HCbrH:
        LN9_v:
        goto bT_gs;
        SeL8T:
        $dKCXk = $this->tGIcp->path($X6p18);
        goto gjAEc;
        GVECX:
        $yNGdh = $this->Q1e5h->call($this, $UStoI);
        goto u56q5;
        u1eWn:
    }
}
