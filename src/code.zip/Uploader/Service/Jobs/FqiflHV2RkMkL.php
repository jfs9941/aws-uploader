<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class FqiflHV2RkMkL implements GenerateThumbnailJobInterface
{
    const clrxQ = 150;
    const xFDkW = 150;
    private $T1B34;
    private $EaJ_d;
    private $NNxJF;
    public function __construct($V0xce, $t9atP, $xnyJl)
    {
        goto wVd1X;
        vzgSE:
        $this->NNxJF = $xnyJl;
        goto oG9bc;
        EDgGV:
        $this->EaJ_d = $t9atP;
        goto vzgSE;
        wVd1X:
        $this->T1B34 = $V0xce;
        goto EDgGV;
        oG9bc:
    }
    public function generate(string $wAkkA)
    {
        goto rU73X;
        rU73X:
        Log::info("Generating thumbnail", ['imageId' => $wAkkA]);
        goto JVHil;
        F1dSL:
        try {
            goto wQyKR;
            dXCv2:
            $lu07a = A9olNyGXhDJnA::findOrFail($wAkkA);
            goto V3jQ0;
            wQyKR:
            $z279S = $this->EaJ_d;
            goto dXCv2;
            kq_gB:
            $lu07a->update(['thumbnail' => $L5bJW, 'status' => GlPuUJKmzwUJ9::THUMBNAIL_PROCESSED]);
            goto AgS4g;
            V3jQ0:
            $zXKv7 = $this->T1B34->call($this, $z279S->path($lu07a->getLocation()));
            goto IeCOm;
            AgS4g:
            bfx6l:
            goto JdqqF;
            VrbRM:
            $AGDxK = $this->NNxJF->put($L5bJW, $zXKv7->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto pHkAI;
            rUKoY:
            if (!($AGDxK !== false)) {
                goto bfx6l;
            }
            goto kq_gB;
            lqbIb:
            $L5bJW = $this->msiqSPM5Pal($lu07a);
            goto VrbRM;
            pHkAI:
            unset($zXKv7);
            goto rUKoY;
            IeCOm:
            $zXKv7->orient()->resize(150, 150);
            goto lqbIb;
            JdqqF:
        } catch (ModelNotFoundException $EGnga) {
            Log::info("A9olNyGXhDJnA has been deleted, discard it", ['imageId' => $wAkkA]);
            return;
        } catch (\Exception $EGnga) {
            Log::error("Failed to generate thumbnail", ['imageId' => $wAkkA, 'error' => $EGnga->getMessage()]);
        }
        goto FRquu;
        JVHil:
        ini_set('memory_limit', '-1');
        goto F1dSL;
        FRquu:
    }
    private function msiqSPM5Pal(NCmZ7rMVMWyvC $lu07a) : string
    {
        goto rPtyT;
        rPtyT:
        $L5bJW = $lu07a->getLocation();
        goto yT4_t;
        yT4_t:
        $QbBrE = dirname($L5bJW);
        goto GP8d0;
        GP8d0:
        $YG4Wy = $QbBrE . '/' . self::clrxQ . 'X' . self::xFDkW;
        goto zlHam;
        zlHam:
        return $YG4Wy . '/' . $lu07a->getFilename() . '.jpg';
        goto IijC4;
        IijC4:
    }
}
