<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
class DH1HW9dm6et7G implements CompressJobInterface
{
    const HgJAx = 60;
    private $mwf2R;
    private $riMoE;
    public function __construct($eF8NA, $BP_p5)
    {
        $this->mwf2R = $eF8NA;
        $this->riMoE = $BP_p5;
    }
    public function compress(string $mfjeD)
    {
        goto D3Eb2;
        gEMrG:
        $HmKOk = memory_get_usage();
        goto md2HW;
        md2HW:
        $ghcvh = memory_get_peak_usage();
        goto zUThe;
        D3Eb2:
        $QEw_Q = microtime(true);
        goto gEMrG;
        zUThe:
        Log::info("Compress image", ['imageId' => $mfjeD]);
        goto sjiEf;
        sjiEf:
        try {
            goto UAuOI;
            UAuOI:
            $fK3zd = DsyQbNiy8VgJG::findOrFail($mfjeD);
            goto Bjvdl;
            QpUyo:
            KLDuW:
            goto d4qlQ;
            NPnuI:
            $fK3zd->save();
            goto QpUyo;
            Dgav9:
            unset($edGSG);
            goto Ab9aH;
            vrhXm:
            $fK3zd->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $fK3zd->getLocation()));
            goto NPnuI;
            taQ0U:
            unset($edGSG);
            goto jxQP0;
            Bjvdl:
            $JYKCK = $this->riMoE->path($fK3zd->getLocation());
            goto rDGrt;
            NA6dM:
            $edGSG = $this->mwf2R->call($this, $JYKCK);
            goto phGFR;
            IzxHR:
            $fK3zd->setAttribute('type', 'jpg');
            goto vrhXm;
            BNGHK:
            $edGSG->orient()->toJpeg(self::HgJAx)->save($Kl1Qp);
            goto taQ0U;
            rDGrt:
            if (!(strtolower($fK3zd->getExtension()) === 'png' || strtolower($fK3zd->getExtension()) === 'heic')) {
                goto KLDuW;
            }
            goto IzxHR;
            d4qlQ:
            $Kl1Qp = $this->riMoE->path($fK3zd->getLocation());
            goto Vfj06;
            Vfj06:
            $edGSG = $this->mwf2R->call($this, $JYKCK);
            goto BNGHK;
            jxQP0:
            $Kl1Qp = $this->riMoE->path(str_replace('.jpg', '.webp', $fK3zd->getLocation()));
            goto NA6dM;
            phGFR:
            $edGSG->orient()->toWebp(self::HgJAx)->save($Kl1Qp);
            goto Dgav9;
            Ab9aH:
        } catch (ModelNotFoundException) {
            Log::info("DsyQbNiy8VgJG has been deleted, discard it", ['imageId' => $mfjeD]);
        } finally {
            $j9xjg = microtime(true);
            $dJyQx = memory_get_usage();
            $RXP3o = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $mfjeD, 'execution_time_sec' => $j9xjg - $QEw_Q, 'memory_usage_mb' => ($dJyQx - $HmKOk) / 1024 / 1024, 'peak_memory_usage_mb' => ($RXP3o - $ghcvh) / 1024 / 1024]);
        }
        goto ULNKN;
        ULNKN:
    }
}
