<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class XQV78gU2vgTCr implements GenerateThumbnailJobInterface
{
    const rv7IZ = 150;
    const FO1M2 = 150;
    private $PAMAL;
    private $Celh5;
    private $L7mR6;
    public function __construct($VX8yi, $clScT, $ZPeN2)
    {
        goto qXFdU;
        u_LKt:
        $this->L7mR6 = $ZPeN2;
        goto qQlSq;
        NhtGM:
        $this->Celh5 = $clScT;
        goto u_LKt;
        qXFdU:
        $this->PAMAL = $VX8yi;
        goto NhtGM;
        qQlSq:
    }
    public function generate(string $SEOXv)
    {
        goto Cgwsf;
        DkBNX:
        try {
            goto gyqII;
            nFgFY:
            if (!($DnfS3 !== false)) {
                goto mf57n;
            }
            goto scBYF;
            Ur5FT:
            $zwQF5 = $this->PAMAL->call($this, $ftmEm->path($dIrHq->getLocation()));
            goto t2Lt5;
            gyqII:
            $ftmEm = $this->Celh5;
            goto LvS57;
            fdYPX:
            mf57n:
            goto tNq49;
            XWMAB:
            $DnfS3 = $this->L7mR6->put($liQkG, $zwQF5->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto VVn3o;
            scBYF:
            $dIrHq->update(['thumbnail' => $liQkG, 'status' => QE1dzvgcPWV6R::THUMBNAIL_PROCESSED]);
            goto fdYPX;
            VVn3o:
            unset($zwQF5);
            goto nFgFY;
            gwEEl:
            $liQkG = $this->mrDOi780VNg($dIrHq);
            goto XWMAB;
            LvS57:
            $dIrHq = FmmY71eXk0D8U::findOrFail($SEOXv);
            goto Ur5FT;
            t2Lt5:
            $zwQF5->orient()->resize(150, 150);
            goto gwEEl;
            tNq49:
        } catch (ModelNotFoundException $HhXZM) {
            Log::info("FmmY71eXk0D8U has been deleted, discard it", ['imageId' => $SEOXv]);
            return;
        } catch (\Exception $HhXZM) {
            Log::error("Failed to generate thumbnail", ['imageId' => $SEOXv, 'error' => $HhXZM->getMessage()]);
        }
        goto yL84n;
        Cgwsf:
        Log::info("Generating thumbnail", ['imageId' => $SEOXv]);
        goto nmwhT;
        nmwhT:
        ini_set('memory_limit', '-1');
        goto DkBNX;
        yL84n:
    }
    private function mrDOi780VNg(ZZfsW9KHWsMrx $dIrHq) : string
    {
        goto w83W0;
        maKRF:
        $Aah7c = $lxDzB . '/' . self::rv7IZ . 'X' . self::FO1M2;
        goto D5lPO;
        D5lPO:
        return $Aah7c . '/' . $dIrHq->getFilename() . '.jpg';
        goto WpvGM;
        w83W0:
        $liQkG = $dIrHq->getLocation();
        goto ADW0y;
        ADW0y:
        $lxDzB = dirname($liQkG);
        goto maKRF;
        WpvGM:
    }
}
