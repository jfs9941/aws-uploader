<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
class IkVJWlo3nFZFD implements StoreToS3JobInterface
{
    private $e2JZZ;
    private $uiTOc;
    private $dwubH;
    public function __construct($yGjLo, $ATeSz, $VzPPJ)
    {
        goto x1399;
        x1399:
        $this->uiTOc = $ATeSz;
        goto fVpBj;
        fVpBj:
        $this->dwubH = $VzPPJ;
        goto z4srY;
        z4srY:
        $this->e2JZZ = $yGjLo;
        goto jHD1H;
        jHD1H:
    }
    public function store(string $B_L9m) : void
    {
        goto zXg2D;
        ktt2f:
        $qGbOo = $this->dwubH->path($LS13w->getAttribute('preview'));
        goto hS6cS;
        j5GWa:
        $i7XwP = $this->e2JZZ->call($this, $W4_7k);
        goto xdxmo;
        jRjFB:
        XMeo8SOmME8kj::where('parent_id', $B_L9m)->update(['driver' => J0IuL8wroLOWt::S3, 'preview' => $LS13w->getAttribute('preview'), 'thumbnail' => $LS13w->getAttribute('thumbnail')]);
        goto wDteg;
        zWJVW:
        ogyNk:
        goto jqPRa;
        BncFI:
        Log::info("XMeo8SOmME8kj stored to S3, update the children attachments", ['fileId' => $B_L9m]);
        goto jRjFB;
        Tj3QY:
        if ($LS13w) {
            goto GW7PK;
        }
        goto S3m8m;
        wDteg:
        return;
        goto C1HcI;
        IAA4V:
        if (!($gQuVn && $this->dwubH->exists($gQuVn))) {
            goto r_UNY;
        }
        goto JzUwF;
        X1hCS:
        $dTJxl = $this->dwubH->path($LS13w->getLocation());
        goto aCR3m;
        lhVhj:
        return;
        goto qPgkl;
        hS6cS:
        $RyVnU = $this->e2JZZ->call($this, $qGbOo);
        goto Oun3c;
        qPgkl:
        GW7PK:
        goto X1hCS;
        g3CNV:
        if (!($LS13w->getAttribute('preview') && $this->dwubH->exists($LS13w->getAttribute('preview')))) {
            goto ogyNk;
        }
        goto ktt2f;
        aCR3m:
        $this->mnJKAWSCHMt($dTJxl, $LS13w->getLocation());
        goto HlJd7;
        jqPRa:
        if (!$LS13w->update(['driver' => J0IuL8wroLOWt::S3, 'status' => LV0wDYHZInswq::FINISHED])) {
            goto Bq0h6;
        }
        goto BncFI;
        S3m8m:
        Log::info("XMeo8SOmME8kj has been deleted, discard it", ['fileId' => $B_L9m]);
        goto lhVhj;
        dYlxT:
        r_UNY:
        goto g3CNV;
        Oun3c:
        $this->uiTOc->put($LS13w->getAttribute('preview'), $this->dwubH->get($LS13w->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $RyVnU->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto zWJVW;
        HlJd7:
        $gQuVn = $LS13w->getAttribute('thumbnail');
        goto IAA4V;
        TPLW3:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $B_L9m]);
        goto YaPEG;
        C1HcI:
        Bq0h6:
        goto TPLW3;
        JzUwF:
        $W4_7k = $this->dwubH->path($gQuVn);
        goto j5GWa;
        zXg2D:
        $LS13w = XMeo8SOmME8kj::findOrFail($B_L9m);
        goto Tj3QY;
        xdxmo:
        $this->uiTOc->put($LS13w->getAttribute('thumbnail'), $this->dwubH->get($gQuVn), ['visibility' => 'public', 'ContentType' => $i7XwP->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto dYlxT;
        YaPEG:
    }
    private function mnJKAWSCHMt($gTbMX, $Cqk5G, $hhhcy = '')
    {
        goto NY9oE;
        g23tY:
        try {
            $zCabx = $this->e2JZZ->call($this, $gTbMX);
            $this->uiTOc->put($Cqk5G, $this->dwubH->get($Cqk5G), ['visibility' => 'public', 'ContentType' => $zCabx->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $bIOBo) {
            Log::error("Failed to upload image to S3", ['s3Path' => $Cqk5G, 'error' => $bIOBo->getMessage()]);
        }
        goto keOX1;
        NY9oE:
        if (!$hhhcy) {
            goto Nku41;
        }
        goto Ls13Y;
        Ls13Y:
        $gTbMX = str_replace('.jpg', $hhhcy, $gTbMX);
        goto WPHFU;
        WPHFU:
        $Cqk5G = str_replace('.jpg', $hhhcy, $Cqk5G);
        goto QAXPj;
        QAXPj:
        Nku41:
        goto g23tY;
        keOX1:
    }
}
