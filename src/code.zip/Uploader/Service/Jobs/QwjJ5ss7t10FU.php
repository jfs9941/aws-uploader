<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Service\Jobs\LiCaZN7AKYxeE;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
class QwjJ5ss7t10FU implements WatermarkTextJobInterface
{
    private $T1B34;
    private $ie3Jn;
    private $Fz8fG;
    private $VJN91;
    private $FHcNr;
    public function __construct($V0xce, $VWeyA, $J83Op, $z279S, $Xy1j0)
    {
        goto V4tWm;
        KJYI8:
        $this->Fz8fG = $Xy1j0;
        goto MIS2J;
        MIS2J:
        $this->ie3Jn = $VWeyA;
        goto ZZuUn;
        V4tWm:
        $this->T1B34 = $V0xce;
        goto nh8f1;
        sBKg_:
        $this->FHcNr = $z279S;
        goto KJYI8;
        nh8f1:
        $this->VJN91 = $J83Op;
        goto sBKg_;
        ZZuUn:
    }
    public function putWatermark(string $wAkkA, string $aBPF6) : void
    {
        goto xbg_t;
        iPcwA:
        Log::info("Adding watermark text to image", ['imageId' => $wAkkA]);
        goto lwY3j;
        xbg_t:
        $fShTg = microtime(true);
        goto Z556T;
        uTcr7:
        try {
            goto SCDMV;
            PuvmD:
            x6T27:
            goto crQxI;
            md8YI:
            unset($lmCmf);
            goto SX3AK;
            AWr5X:
            if ($this->FHcNr->exists($lu07a->getLocation())) {
                goto x6T27;
            }
            goto Pkk_F;
            LAUje:
            return;
            goto PuvmD;
            qWhyl:
            \Log::warning('Failed to set final permissions on image file: ' . $L5bJW);
            goto yUzLl;
            crQxI:
            $L5bJW = $this->FHcNr->path($lu07a->getLocation());
            goto WKT_x;
            VkhHy:
            $lmCmf->orient();
            goto i9Vby;
            WKT_x:
            $lmCmf = $this->T1B34->call($this, $L5bJW);
            goto VkhHy;
            EvyFs:
            $this->VJN91->put($L5bJW, $lmCmf->toJpeg(70), ['visibility' => 'public', 'ContentType' => 'image/jpeg', 'ContentDisposition' => 'inline']);
            goto md8YI;
            SCDMV:
            $lu07a = A9olNyGXhDJnA::findOrFail($wAkkA);
            goto AWr5X;
            i9Vby:
            $this->mRfge58efOK($lmCmf, $aBPF6);
            goto EvyFs;
            yUzLl:
            throw new \Exception('Failed to set final permissions on image file: ' . $L5bJW);
            goto VNvMU;
            SX3AK:
            if (chmod($L5bJW, 0664)) {
                goto HH9Qz;
            }
            goto qWhyl;
            VNvMU:
            HH9Qz:
            goto LTmft;
            Pkk_F:
            Log::error("A9olNyGXhDJnA is not on local, might be deleted before put watermark", ['imageId' => $wAkkA]);
            goto LAUje;
            LTmft:
        } catch (\Throwable $iOV2Z) {
            goto ksPa3;
            ksPa3:
            if (!$iOV2Z instanceof ModelNotFoundException) {
                goto GSwgg;
            }
            goto D6YCE;
            EnFHP:
            GSwgg:
            goto hOdGJ;
            hOdGJ:
            Log::error("A9olNyGXhDJnA is not readable", ['imageId' => $wAkkA, 'error' => $iOV2Z->getMessage()]);
            goto mKon0;
            WdEzu:
            return;
            goto EnFHP;
            D6YCE:
            Log::info("A9olNyGXhDJnA has been deleted, discard it", ['imageId' => $wAkkA]);
            goto WdEzu;
            mKon0:
        } finally {
            $TFGkL = microtime(true);
            $D2XLx = memory_get_usage();
            $dMjbk = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $wAkkA, 'execution_time_sec' => $TFGkL - $fShTg, 'memory_usage_mb' => ($D2XLx - $XojxF) / 1024 / 1024, 'peak_memory_usage_mb' => ($dMjbk - $f0Zjf) / 1024 / 1024]);
        }
        goto QfF2Z;
        heq86:
        $f0Zjf = memory_get_peak_usage();
        goto iPcwA;
        lwY3j:
        ini_set('memory_limit', '-1');
        goto uTcr7;
        Z556T:
        $XojxF = memory_get_usage();
        goto heq86;
        QfF2Z:
    }
    private function mRfge58efOK($lmCmf, $aBPF6) : void
    {
        goto rHXEb;
        rekDf:
        $rfEMk = new LiCaZN7AKYxeE($this->ie3Jn, $this->Fz8fG, $this->VJN91, $this->FHcNr);
        goto K14no;
        K14no:
        $FTOPT = $rfEMk->mwjfcTF32q8($yRrbE, $aQb9L, $aBPF6, true);
        goto uq9Kh;
        E3V8o:
        $WPGHr = $this->T1B34->call($this, $this->FHcNr->path($FTOPT));
        goto enGSs;
        rHXEb:
        $yRrbE = $lmCmf->width();
        goto smu_o;
        smu_o:
        $aQb9L = $lmCmf->height();
        goto rekDf;
        uq9Kh:
        $this->FHcNr->put($FTOPT, $this->VJN91->get($FTOPT));
        goto E3V8o;
        enGSs:
        $lmCmf->place($WPGHr, 'top-left', 0, 0, 30);
        goto gsqS2;
        gsqS2:
    }
}
