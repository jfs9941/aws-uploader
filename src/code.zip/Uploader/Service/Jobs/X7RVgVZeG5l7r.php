<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Illuminate\Support\Facades\Log;
class X7RVgVZeG5l7r implements StoreVideoToS3JobInterface
{
    private $YsmCK;
    private $DksH2;
    private $JFHzD;
    public function __construct($iwKga, $l4Drs, $NVuHg)
    {
        goto LYpQz;
        dDJ2Y:
        $this->JFHzD = $NVuHg;
        goto lOsCt;
        LYpQz:
        $this->DksH2 = $l4Drs;
        goto dDJ2Y;
        lOsCt:
        $this->YsmCK = $iwKga;
        goto Kew_O;
        Kew_O:
    }
    public function store(string $EmnXX) : void
    {
        goto Qrmsn;
        cUxpl:
        $v08TZ = $NVuHg->readStream($R9GsR->getLocation());
        goto Kh1FW;
        DUFL_:
        return;
        goto cY2Jn;
        UFh6G:
        UJS7I:
        goto mbzJl;
        TgO9E:
        if ($R9GsR) {
            goto UJS7I;
        }
        goto DSrXu;
        Kh1FW:
        $pYJII = 1024 * 1024 * 50;
        goto mpJFX;
        DSrXu:
        Log::info("M7oTJdNm24KG4 has been deleted in database or not inserted yet, discard it", ['fileId' => $EmnXX]);
        goto rKFxJ;
        pNjpE:
        $sebDh = memory_get_usage();
        goto hkwVw;
        IG0Fc:
        $CH3jk = microtime(true);
        goto pNjpE;
        pUJCF:
        $q2eKB = $this->DksH2->getClient();
        goto a6A08;
        h0ioe:
        $R9GsR = M7oTJdNm24KG4::find($EmnXX);
        goto TgO9E;
        dLev6:
        ini_set('memory_limit', '-1');
        goto pUJCF;
        hkwVw:
        $DGIY2 = memory_get_peak_usage();
        goto f8Au2;
        mpJFX:
        $AqJic = $NVuHg->mimeType($R9GsR->getLocation());
        goto IG0Fc;
        mbzJl:
        if ($NVuHg->exists($R9GsR->getLocation())) {
            goto dN_tk;
        }
        goto AmU9W;
        a6A08:
        $NVuHg = $this->JFHzD;
        goto h0ioe;
        AmU9W:
        Log::error("[X7RVgVZeG5l7r] File not found, discard it ", ['video' => $R9GsR->getLocation()]);
        goto DUFL_;
        rKFxJ:
        return;
        goto UFh6G;
        f8Au2:
        try {
            goto hxX4E;
            GIvrO:
            $NVuHg->delete($R9GsR->getLocation());
            goto BuDeV;
            N52l5:
            $FvGiZ[] = ['PartNumber' => $fbpzZ, 'ETag' => $IOMqM['ETag']];
            goto WCKxY;
            hxX4E:
            $SKvTz = $q2eKB->createMultipartUpload(['Bucket' => $this->YsmCK, 'Key' => $R9GsR->getLocation(), 'ContentType' => $AqJic, 'ContentDisposition' => 'inline']);
            goto Zu9q3;
            Zu9q3:
            $I0nMz = $SKvTz['UploadId'];
            goto d6rS2;
            Z9e8a:
            goto L8zXf;
            goto xbKBb;
            dnYOK:
            $FvGiZ = [];
            goto kfDEI;
            McfRb:
            $R9GsR->update(['driver' => Tfi7lQDVWUJD9::S3]);
            goto GIvrO;
            J9xe3:
            fclose($v08TZ);
            goto TGt_H;
            WCKxY:
            $fbpzZ++;
            goto Z9e8a;
            kfDEI:
            L8zXf:
            goto uBCUB;
            uBCUB:
            if (feof($v08TZ)) {
                goto AlK_4;
            }
            goto y1m73;
            y1m73:
            $IOMqM = $q2eKB->uploadPart(['Bucket' => $this->YsmCK, 'Key' => $R9GsR->getLocation(), 'UploadId' => $I0nMz, 'PartNumber' => $fbpzZ, 'Body' => fread($v08TZ, $pYJII)]);
            goto N52l5;
            TGt_H:
            $q2eKB->completeMultipartUpload(['Bucket' => $this->YsmCK, 'Key' => $R9GsR->getLocation(), 'UploadId' => $I0nMz, 'MultipartUpload' => ['Parts' => $FvGiZ]]);
            goto McfRb;
            xbKBb:
            AlK_4:
            goto J9xe3;
            d6rS2:
            $fbpzZ = 1;
            goto dnYOK;
            BuDeV:
        } catch (AwsException $SoaRh) {
            goto CLY0G;
            rp6BN:
            try {
                $q2eKB->abortMultipartUpload(['Bucket' => $this->YsmCK, 'Key' => $R9GsR->getLocation(), 'UploadId' => $I0nMz]);
            } catch (AwsException $IBWix) {
                Log::error('Error aborting multipart upload: ' . $IBWix->getMessage());
            }
            goto Uzthb;
            CLY0G:
            if (!isset($I0nMz)) {
                goto NLedL;
            }
            goto rp6BN;
            Uzthb:
            NLedL:
            goto aVo0I;
            aVo0I:
            Log::error('Failed to store video: ' . $R9GsR->getLocation() . ' - ' . $SoaRh->getMessage());
            goto v53di;
            v53di:
        } finally {
            $ukbV6 = microtime(true);
            $A4_rm = memory_get_usage();
            $PEAvN = memory_get_peak_usage();
            Log::info('Store M7oTJdNm24KG4 to S3 function resource usage', ['imageId' => $EmnXX, 'execution_time_sec' => $ukbV6 - $CH3jk, 'memory_usage_mb' => ($A4_rm - $sebDh) / 1024 / 1024, 'peak_memory_usage_mb' => ($PEAvN - $DGIY2) / 1024 / 1024]);
        }
        goto VbSmK;
        cY2Jn:
        dN_tk:
        goto cUxpl;
        Qrmsn:
        Log::info('Storing video (local) to S3', ['fileId' => $EmnXX, 'bucketName' => $this->YsmCK]);
        goto dLev6;
        VbSmK:
    }
}
