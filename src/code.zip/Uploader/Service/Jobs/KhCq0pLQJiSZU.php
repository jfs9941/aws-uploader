<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Encoder\PvdMmITg3OR2U;
use Jfs\Uploader\Encoder\VJyQpEMUBJg8a;
use Jfs\Uploader\Encoder\LzL89H4g6zwMz;
use Jfs\Uploader\Encoder\PR0yJBVlrU7TV;
use Jfs\Uploader\Encoder\Z4OscliFEOmvr;
use Jfs\Uploader\Encoder\V5o1ro3gU3c2A;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
use Jfs\Uploader\Service\WK3vb1oP6Xm31;
use Webmozart\Assert\Assert;
class KhCq0pLQJiSZU implements MediaEncodeJobInterface
{
    private $Jbhpc;
    private $N3F9R;
    private $W_Kti;
    private $BmRID;
    private $TOG_e;
    public function __construct(string $A745z, $mFX9i, $agzKA, $VtFJQ, $QLRyU)
    {
        goto NyYsN;
        EEBke:
        $this->W_Kti = $agzKA;
        goto ZFCqp;
        lpM1a:
        $this->N3F9R = $mFX9i;
        goto EEBke;
        lNJQp:
        $this->TOG_e = $QLRyU;
        goto nYmYG;
        ZFCqp:
        $this->BmRID = $VtFJQ;
        goto lNJQp;
        NyYsN:
        $this->Jbhpc = $A745z;
        goto lpM1a;
        nYmYG:
    }
    public function encode(string $y06DH, string $Hx65l, $KG59o = true) : void
    {
        goto anygw;
        ZTXxr:
        try {
            goto z_k4O;
            pgjnY:
            $zzw5E = $this->mTqibzStslo($Kacxo, $Q2TKK->mShOxL4HISe((int) $pfDHu['width'], (int) $pfDHu['height'], $Hx65l));
            goto WjRqw;
            lwLMi:
            $xAWQW = $xAWQW->mpbrd1Q9bSN($qeDss);
            goto zJkuV;
            EmrAN:
            $qeDss = $qeDss->mEpCe2i4JcG($zzw5E);
            goto kTY8J;
            asNxd:
            if (!$zzw5E) {
                goto t9nWa;
            }
            goto ddjj1;
            z2DTt:
            $kjHqO = new VJyQpEMUBJg8a('original', $K2lK4, $Mq4V6, $aiCaH->iH9_n ?? 30);
            goto Q6mLT;
            ddjj1:
            $kjHqO = $kjHqO->mEpCe2i4JcG($zzw5E);
            goto X5ccv;
            E6q4L:
            $xAWQW->mpbrd1Q9bSN($kjHqO);
            goto W7RlE;
            O4rpF:
            hIHNx:
            goto UKFYG;
            hHSjP:
            $y06DH = $xAWQW->mWdVr0b3yO7($this->mjZtUnGFaf5($aiCaH, $KG59o));
            goto TBbC8;
            hmDE0:
            $qqIkT = new PvdMmITg3OR2U($aiCaH->QfIsl ?? 1, 2, $fawdl->m2SUp89509K($aiCaH));
            goto OjecS;
            jlbaS:
            nM7ya:
            goto JXViQ;
            ty0oY:
            $fBbIu = $this->mAorBMY1NcM($aiCaH);
            goto u3ihe;
            L3tUk:
            $pfDHu = $this->m7gBZYnGpI7($K2lK4, $Mq4V6);
            goto lwcIb;
            lNbyM:
            if (!($K2lK4 && $Mq4V6)) {
                goto hIHNx;
            }
            goto zyAER;
            UKFYG:
            Log::info("Set thumbnail for GXtnGiMmIPEIc Job", ['videoId' => $aiCaH->getAttribute('id'), 'duration' => $aiCaH->getAttribute('duration')]);
            goto hmDE0;
            p_cWV:
            $xAWQW = app(Z4OscliFEOmvr::class);
            goto kBcTU;
            W7RlE:
            $xAWQW->mUaO46dda49($fawdl->msFrbNLmSbV($aiCaH));
            goto lNbyM;
            TBbC8:
            $aiCaH->update(['aws_media_converter_job_id' => $y06DH]);
            goto YeKcJ;
            QeQ5j:
            $Mq4V6 = $aiCaH->height();
            goto ty0oY;
            u3ihe:
            Log::info("Set input video for Job", ['s3Uri' => $fBbIu]);
            goto p_cWV;
            X5ccv:
            t9nWa:
            goto E6q4L;
            fea4C:
            if (!($aiCaH->vZVzF !== WG4kCv0INtCV4::S3)) {
                goto nM7ya;
            }
            goto oNEsJ;
            WjRqw:
            if (!$zzw5E) {
                goto YEHgt;
            }
            goto EmrAN;
            ySsZb:
            $qeDss = new VJyQpEMUBJg8a('1080p', $pfDHu['width'], $pfDHu['height'], $aiCaH->iH9_n ?? 30);
            goto pgjnY;
            z_k4O:
            $aiCaH = GXtnGiMmIPEIc::findOrFail($y06DH);
            goto mzUFW;
            lwcIb:
            Log::info("Set 1080p resolution for Job", ['width' => $pfDHu['width'], 'height' => $pfDHu['height'], 'originalWidth' => $K2lK4, 'originalHeight' => $Mq4V6]);
            goto ySsZb;
            zJkuV:
            dEyhA:
            goto O4rpF;
            zyAER:
            if (!$this->mMLmk3vleye($K2lK4, $Mq4V6)) {
                goto dEyhA;
            }
            goto L3tUk;
            Xlk6E:
            $Kacxo = app(WK3vb1oP6Xm31::class);
            goto J2KR0;
            J2KR0:
            $Q2TKK = new UiLxI3bJTv3i0($this->BmRID, $this->TOG_e, $this->W_Kti, $this->N3F9R);
            goto ylMiV;
            kBcTU:
            $xAWQW = $xAWQW->m0zGgXopQXk(new PR0yJBVlrU7TV($fBbIu));
            goto z2DTt;
            Q6mLT:
            $fawdl = app(LzL89H4g6zwMz::class);
            goto EHBvG;
            oNEsJ:
            throw new MediaConverterException("GXtnGiMmIPEIc {$aiCaH->id} is not S3 driver");
            goto jlbaS;
            mzUFW:
            Assert::isInstanceOf($aiCaH, GXtnGiMmIPEIc::class);
            goto fea4C;
            ylMiV:
            $zzw5E = $this->mTqibzStslo($Kacxo, $Q2TKK->mShOxL4HISe($aiCaH->width(), $aiCaH->height(), $Hx65l));
            goto asNxd;
            EHBvG:
            $xAWQW->mpbrd1Q9bSN($kjHqO);
            goto HUsHn;
            JXViQ:
            $K2lK4 = $aiCaH->width();
            goto QeQ5j;
            OjecS:
            $xAWQW = $xAWQW->mcN42vKef2E($qqIkT);
            goto hHSjP;
            kTY8J:
            YEHgt:
            goto lwLMi;
            HUsHn:
            $xAWQW->mUaO46dda49($fawdl->msFrbNLmSbV($aiCaH));
            goto Xlk6E;
            YeKcJ:
        } catch (\Exception $ZkRqE) {
            Log::info("GXtnGiMmIPEIc has been deleted, discard it", ['fileId' => $y06DH, 'err' => $ZkRqE->getMessage()]);
            return;
        }
        goto s2MdW;
        anygw:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $y06DH]);
        goto f9rFl;
        f9rFl:
        ini_set('memory_limit', '-1');
        goto ZTXxr;
        s2MdW:
    }
    private function mjZtUnGFaf5(GXtnGiMmIPEIc $aiCaH, $KG59o) : bool
    {
        goto LMWO4;
        mfQkY:
        switch (true) {
            case $aiCaH->width() * $aiCaH->height() >= 1920 * 1080 && $aiCaH->width() * $aiCaH->height() < 2560 * 1440:
                return $qGHjI > 10 * 60;
            case $aiCaH->width() * $aiCaH->height() >= 2560 * 1440 && $aiCaH->width() * $aiCaH->height() < 3840 * 2160:
                return $qGHjI > 5 * 60;
            case $aiCaH->width() * $aiCaH->height() >= 3840 * 2160:
                return $qGHjI > 3 * 60;
            default:
                return false;
        }
        goto N0a3d;
        XZqKN:
        return false;
        goto geO4E;
        V2W52:
        mLEKh:
        goto NzNvA;
        LMWO4:
        if ($KG59o) {
            goto KIbee;
        }
        goto XZqKN;
        KcVAc:
        $qGHjI = (int) round($aiCaH->getAttribute('duration') ?? 0);
        goto mfQkY;
        N0a3d:
        zUjK8:
        goto V2W52;
        geO4E:
        KIbee:
        goto KcVAc;
        NzNvA:
    }
    private function mTqibzStslo(WK3vb1oP6Xm31 $Kacxo, string $AGOMy) : ?V5o1ro3gU3c2A
    {
        goto UiF34;
        UiF34:
        $naCQf = $Kacxo->mgvMVogHFjU($AGOMy);
        goto xDwxe;
        aFWdQ:
        if (!$naCQf) {
            goto opTHD;
        }
        goto XZ_B4;
        XZ_B4:
        return new V5o1ro3gU3c2A($naCQf, 0, 0, null, null);
        goto Qy2a2;
        xDwxe:
        Log::info("Resolve watermark for job with url", ['url' => $AGOMy, 'uri' => $naCQf]);
        goto aFWdQ;
        Qy2a2:
        opTHD:
        goto hV0T3;
        hV0T3:
        return null;
        goto lvmxT;
        lvmxT:
    }
    private function mMLmk3vleye(int $K2lK4, int $Mq4V6) : bool
    {
        return $K2lK4 * $Mq4V6 > 1.5 * (1920 * 1080);
    }
    private function m7gBZYnGpI7(int $K2lK4, int $Mq4V6) : array
    {
        $siz4c = new PcyDFjxwhaJkE($K2lK4, $Mq4V6);
        return $siz4c->mmVTXzOoiLf();
    }
    private function mAorBMY1NcM(UKWxL8i4Jx2NZ $xKDWF) : string
    {
        goto e57Aw;
        NWg7Z:
        return 's3://' . $this->Jbhpc . '/' . $xKDWF->filename;
        goto i_ldm;
        i_ldm:
        NHlG_:
        goto rsYzE;
        rsYzE:
        return $this->N3F9R->url($xKDWF->filename);
        goto GVzxn;
        e57Aw:
        if (!($xKDWF->vZVzF == WG4kCv0INtCV4::S3)) {
            goto NHlG_;
        }
        goto NWg7Z;
        GVzxn:
    }
}
