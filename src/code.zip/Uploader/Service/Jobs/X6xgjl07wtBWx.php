<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Encoder\CQtYwlDJg3DU8;
use Jfs\Uploader\Encoder\T1BQgatbMpEau;
use Jfs\Uploader\Encoder\OIG3Aes8wHMT8;
use Jfs\Uploader\Encoder\S3pSMlpyA7cu9;
use Jfs\Uploader\Encoder\MUNOklcvw7X2T;
use Jfs\Uploader\Encoder\TSR3742mYKFfW;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Jfs\Uploader\Service\Jobs\Vn8jgXvFddzmt;
use Jfs\Uploader\Service\Jobs\Pwzrr2Hyspqqd;
use Jfs\Uploader\Service\B0o6VsHdCPn65;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class X6xgjl07wtBWx implements MediaEncodeJobInterface
{
    private $t4Y2D;
    private $P8Yzg;
    private $RE_2F;
    private $zZRNN;
    private $b8AQe;
    public function __construct(string $wY6MR, $jT0xz, $WmwnR, $BLhUh, $WjOtg)
    {
        goto QpeNF;
        rtdya:
        $this->P8Yzg = $jT0xz;
        goto ASoqh;
        QnBc0:
        $this->b8AQe = $WjOtg;
        goto res1t;
        nhI8a:
        $this->zZRNN = $BLhUh;
        goto QnBc0;
        QpeNF:
        $this->t4Y2D = $wY6MR;
        goto rtdya;
        ASoqh:
        $this->RE_2F = $WmwnR;
        goto nhI8a;
        res1t:
    }
    public function encode(string $LpGEK, string $WkdyW, $nEVEM = true) : void
    {
        goto VPi_0;
        VPi_0:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $LpGEK]);
        goto U5pvR;
        Kbp1C:
        try {
            goto LCln7;
            S3Sps:
            $DmFxf = app(MUNOklcvw7X2T::class);
            goto blJs3;
            l0dyS:
            $saBWi = new CQtYwlDJg3DU8($Qw86m->bhGGf ?? 1, 2, $qTc4J->mJ6ktCXV95B($Qw86m));
            goto ExgZ1;
            siIOF:
            brxKj:
            goto axVj1;
            vBDrr:
            if (!($tYCg4 && $Xnjcp)) {
                goto tycmk;
            }
            goto l8FGx;
            simnv:
            $g_EaB = new T1BQgatbMpEau('1080p', $j4RFe['width'], $j4RFe['height'], $Qw86m->kU6BP ?? 30);
            goto g9owC;
            Bv6gG:
            $zIWYo = new Pwzrr2Hyspqqd($this->zZRNN, $this->b8AQe, $this->RE_2F, $this->P8Yzg);
            goto qUqPx;
            u1bG1:
            $DmFxf->mq6otmNgdyR($qTc4J->mywROX8HPuh($Qw86m));
            goto GTmW7;
            DYGDo:
            $DmFxf->mSYOhWTD4Da($bdbZN);
            goto u1bG1;
            TfthV:
            UN2Ma:
            goto yLEF6;
            x3pXY:
            Assert::isInstanceOf($Qw86m, Jf5KRr8uE3t34::class);
            goto yLtGh;
            LCln7:
            $Qw86m = Jf5KRr8uE3t34::findOrFail($LpGEK);
            goto x3pXY;
            ZHv9I:
            if (!$EhyUo) {
                goto Nb7Cy;
            }
            goto B2dV0;
            Qpgqs:
            Log::info("Set thumbnail for Jf5KRr8uE3t34 Job", ['videoId' => $Qw86m->getAttribute('id'), 'duration' => $Qw86m->getAttribute('duration')]);
            goto l0dyS;
            yLEF6:
            tycmk:
            goto Qpgqs;
            iEa8S:
            $Y52cg = $this->m4IlrkQicO1($Qw86m);
            goto NT24_;
            oJHVY:
            $LpGEK = $DmFxf->mChY6xrKY4C($this->mZ0GH2IEPyw($Qw86m, $nEVEM));
            goto d3xcD;
            qUqPx:
            $EhyUo = $this->m2jBn4i5DI5($BkHR5, $zIWYo->mtN0xu2kbrL($Qw86m->width(), $Qw86m->height(), $WkdyW));
            goto ZHv9I;
            VXVHj:
            throw new MediaConverterException("Jf5KRr8uE3t34 {$Qw86m->id} is not S3 driver");
            goto siIOF;
            GTmW7:
            $BkHR5 = app(B0o6VsHdCPn65::class);
            goto Bv6gG;
            B2dV0:
            $bdbZN = $bdbZN->mXNYSK9aLXq($EhyUo);
            goto jFtB9;
            WNV4u:
            $j4RFe = $this->mrrT59ltuBE($tYCg4, $Xnjcp);
            goto Zl2NL;
            l8FGx:
            if (!$this->m2YRJzg7JKc($tYCg4, $Xnjcp)) {
                goto UN2Ma;
            }
            goto WNV4u;
            blJs3:
            $DmFxf = $DmFxf->mqOy77vTjcl(new S3pSMlpyA7cu9($Y52cg));
            goto pGlr4;
            jFtB9:
            Nb7Cy:
            goto PrVlN;
            olrKv:
            gifl5:
            goto sYpaf;
            ExgZ1:
            $DmFxf = $DmFxf->mOZPZtQYDfS($saBWi);
            goto oJHVY;
            g9owC:
            $EhyUo = $this->m2jBn4i5DI5($BkHR5, $zIWYo->mtN0xu2kbrL((int) $j4RFe['width'], (int) $j4RFe['height'], $WkdyW));
            goto DNZee;
            rHxcd:
            $Xnjcp = $Qw86m->height();
            goto iEa8S;
            sYpaf:
            $DmFxf = $DmFxf->mSYOhWTD4Da($g_EaB);
            goto TfthV;
            PrVlN:
            $DmFxf->mSYOhWTD4Da($bdbZN);
            goto M8OQp;
            M8OQp:
            $DmFxf->mq6otmNgdyR($qTc4J->mywROX8HPuh($Qw86m));
            goto vBDrr;
            NT24_:
            Log::info("Set input video for Job", ['s3Uri' => $Y52cg]);
            goto S3Sps;
            d3xcD:
            $Qw86m->update(['aws_media_converter_job_id' => $LpGEK]);
            goto S9wIR;
            FbrNd:
            $g_EaB = $g_EaB->mXNYSK9aLXq($EhyUo);
            goto olrKv;
            BPkfb:
            $qTc4J = app(OIG3Aes8wHMT8::class);
            goto DYGDo;
            Zl2NL:
            Log::info("Set 1080p resolution for Job", ['width' => $j4RFe['width'], 'height' => $j4RFe['height'], 'originalWidth' => $tYCg4, 'originalHeight' => $Xnjcp]);
            goto simnv;
            yLtGh:
            if (!($Qw86m->xiRsU !== EzGWviwQDmAwI::S3)) {
                goto brxKj;
            }
            goto VXVHj;
            pGlr4:
            $bdbZN = new T1BQgatbMpEau('original', $tYCg4, $Xnjcp, $Qw86m->kU6BP ?? 30);
            goto BPkfb;
            axVj1:
            $tYCg4 = $Qw86m->width();
            goto rHxcd;
            DNZee:
            if (!$EhyUo) {
                goto gifl5;
            }
            goto FbrNd;
            S9wIR:
        } catch (\Exception $AUVE0) {
            Log::info("Jf5KRr8uE3t34 has been deleted, discard it", ['fileId' => $LpGEK, 'err' => $AUVE0->getMessage()]);
            return;
        }
        goto WFcQw;
        U5pvR:
        ini_set('memory_limit', '-1');
        goto Kbp1C;
        WFcQw:
    }
    private function mZ0GH2IEPyw(Jf5KRr8uE3t34 $Qw86m, $nEVEM) : bool
    {
        goto WWAAf;
        WWAAf:
        if ($nEVEM) {
            goto cI72r;
        }
        goto GmGF5;
        ddG0E:
        UQLQl:
        goto F15AP;
        GmGF5:
        return false;
        goto Wd4zF;
        Np50v:
        switch (true) {
            case $Qw86m->width() * $Qw86m->height() >= 1920 * 1080 && $Qw86m->width() * $Qw86m->height() < 2560 * 1440:
                return $pJ_ey > 10 * 60;
            case $Qw86m->width() * $Qw86m->height() >= 2560 * 1440 && $Qw86m->width() * $Qw86m->height() < 3840 * 2160:
                return $pJ_ey > 5 * 60;
            case $Qw86m->width() * $Qw86m->height() >= 3840 * 2160:
                return $pJ_ey > 3 * 60;
            default:
                return false;
        }
        goto d4o6h;
        d4o6h:
        zCutN:
        goto ddG0E;
        Wd4zF:
        cI72r:
        goto lG3bi;
        lG3bi:
        $pJ_ey = (int) round($Qw86m->getAttribute('duration') ?? 0);
        goto Np50v;
        F15AP:
    }
    private function m2jBn4i5DI5(B0o6VsHdCPn65 $BkHR5, string $NLPuF) : ?TSR3742mYKFfW
    {
        goto iWZFe;
        g5EJr:
        BsVnl:
        goto yMjCb;
        NY7k7:
        return new TSR3742mYKFfW($pD4F_, 0, 0, null, null);
        goto g5EJr;
        ToyNF:
        Log::info("Resolve watermark for job with url", ['url' => $NLPuF, 'uri' => $pD4F_]);
        goto QLBBm;
        QLBBm:
        if (!$pD4F_) {
            goto BsVnl;
        }
        goto NY7k7;
        yMjCb:
        return null;
        goto QQZuz;
        iWZFe:
        $pD4F_ = $BkHR5->mQNUjIdrdPB($NLPuF);
        goto ToyNF;
        QQZuz:
    }
    private function m2YRJzg7JKc(int $tYCg4, int $Xnjcp) : bool
    {
        return $tYCg4 * $Xnjcp > 1.5 * (1920 * 1080);
    }
    private function mrrT59ltuBE(int $tYCg4, int $Xnjcp) : array
    {
        $qFaCN = new Vn8jgXvFddzmt($tYCg4, $Xnjcp);
        return $qFaCN->my6nkWhyeQp();
    }
    private function m4IlrkQicO1(ALaATNTmuoFHt $nu6qO) : string
    {
        goto wAtx0;
        wAtx0:
        if (!($nu6qO->xiRsU == EzGWviwQDmAwI::S3)) {
            goto t8Y55;
        }
        goto IHHAX;
        nlePC:
        t8Y55:
        goto tzDiQ;
        tzDiQ:
        return $this->P8Yzg->url($nu6qO->filename);
        goto YisvE;
        IHHAX:
        return 's3://' . $this->t4Y2D . '/' . $nu6qO->filename;
        goto nlePC;
        YisvE:
    }
}
