<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Encoder\Wu1TTCZqWFpNm;
use Jfs\Uploader\Encoder\HYlcVVWzTHXE3;
use Jfs\Uploader\Encoder\PBaAMCftTA2PY;
use Jfs\Uploader\Encoder\AnydI1mi8QjAt;
use Jfs\Uploader\Encoder\XNoKVl02kaW7f;
use Jfs\Uploader\Encoder\Rcz6vFPVp31Qt;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Jfs\Uploader\Service\Jobs\Chhl641vTeaPG;
use Jfs\Uploader\Service\Jobs\ShuOBoAxU0XST;
use Jfs\Uploader\Service\ZKiz9aeWXGIZz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Webmozart\Assert\Assert;
class XcZgi0c3uWmjG implements MediaEncodeJobInterface
{
    private $petAu;
    private $unMfk;
    private $rSfnv;
    private $tiVps;
    private $aDr2m;
    public function __construct(string $RiWpQ, $L32kE, $uIWH1, $BYcL7, $Pa2dJ)
    {
        goto yNb2l;
        VWtcR:
        $this->unMfk = $L32kE;
        goto ktpID;
        Irrcw:
        $this->aDr2m = $Pa2dJ;
        goto PnB0r;
        v1G_W:
        $this->tiVps = $BYcL7;
        goto Irrcw;
        yNb2l:
        $this->petAu = $RiWpQ;
        goto VWtcR;
        ktpID:
        $this->rSfnv = $uIWH1;
        goto v1G_W;
        PnB0r:
    }
    public function encode(string $eeXS6, string $fmYhL, $jwEgQ = true) : void
    {
        goto RETXo;
        Sexbc:
        try {
            goto G2fV2;
            G6xqb:
            if (!($XLJzE && $X8shh)) {
                goto zvmCL;
            }
            goto tu24H;
            OkjyJ:
            $jXmWz = $this->mjJtnsPlr1D($XpJJ6, $Y6S2V->mhwnG9Y7qwm($JfLWA->width(), $JfLWA->height(), $fmYhL));
            goto DbjBl;
            jUPkO:
            $W04kQ->mFyps98x3f5($VCOTu);
            goto XdX27;
            s3r2f:
            $jXmWz = $this->mjJtnsPlr1D($XpJJ6, $Y6S2V->mhwnG9Y7qwm((int) $ST6aQ['width'], (int) $ST6aQ['height'], $fmYhL));
            goto Q_HWC;
            dnt0G:
            Log::info("Set 1080p resolution for Job", ['width' => $ST6aQ['width'], 'height' => $ST6aQ['height'], 'originalWidth' => $XLJzE, 'originalHeight' => $X8shh]);
            goto T1BbT;
            jE5cm:
            $W04kQ = $W04kQ->mFyps98x3f5($x_H_6);
            goto qbY7p;
            Gg_T2:
            $ST6aQ = $this->ma8zeHOZg60($XLJzE, $X8shh);
            goto dnt0G;
            K1xVI:
            $ikeQ2 = app(PBaAMCftTA2PY::class);
            goto ySZfz;
            Y_FgA:
            $gYP4D = new Wu1TTCZqWFpNm($JfLWA->f0PCE ?? 1, 2, $ikeQ2->mKEJxGQm5jf($JfLWA));
            goto XPF9D;
            t6vVc:
            $eeXS6 = $W04kQ->mjExSoX837A($this->mmH9IlIqfK9($JfLWA, $jwEgQ));
            goto w13qm;
            tu24H:
            if (!$this->myDbASfm7we($XLJzE, $X8shh)) {
                goto mzSd6;
            }
            goto Gg_T2;
            qbY7p:
            mzSd6:
            goto nuPLN;
            TiCC8:
            $W04kQ->mqAfGivyjzw($ikeQ2->m2xueZkh93c($JfLWA));
            goto agPmu;
            w8xuI:
            $W04kQ = app(XNoKVl02kaW7f::class);
            goto gEDD9;
            ySZfz:
            $W04kQ->mFyps98x3f5($VCOTu);
            goto TiCC8;
            Q_HWC:
            if (!$jXmWz) {
                goto L57Mj;
            }
            goto WToSW;
            G2fV2:
            $JfLWA = N1wF7eNF4lYgo::findOrFail($eeXS6);
            goto N_MAQ;
            nuPLN:
            zvmCL:
            goto Wz2Kw;
            MdoDr:
            if (!($JfLWA->Fd5Pz !== PdN71mQX1JeZG::S3)) {
                goto S1nfk;
            }
            goto PkvLw;
            RHlky:
            $X8shh = $JfLWA->height();
            goto zJqoB;
            zJqoB:
            $jJfLf = $this->mS3loCO2ggJ($JfLWA);
            goto t9J1w;
            gEDD9:
            $W04kQ = $W04kQ->mTQPJyjSSLG(new AnydI1mi8QjAt($jJfLf));
            goto WO76m;
            C1DL9:
            $XLJzE = $JfLWA->width();
            goto RHlky;
            N_MAQ:
            Assert::isInstanceOf($JfLWA, N1wF7eNF4lYgo::class);
            goto MdoDr;
            dC2vr:
            TDeFo:
            goto jUPkO;
            agPmu:
            $XpJJ6 = app(ZKiz9aeWXGIZz::class);
            goto BNsZQ;
            BNsZQ:
            $Y6S2V = new ShuOBoAxU0XST($this->tiVps, $this->aDr2m, $this->rSfnv, $this->unMfk);
            goto OkjyJ;
            S3etE:
            L57Mj:
            goto jE5cm;
            w13qm:
            $JfLWA->update(['aws_media_converter_job_id' => $eeXS6]);
            goto VruZJ;
            xtxWu:
            S1nfk:
            goto C1DL9;
            PkvLw:
            throw new MediaConverterException("N1wF7eNF4lYgo {$JfLWA->id} is not S3 driver");
            goto xtxWu;
            tuMvG:
            $VCOTu = $VCOTu->mMiBm0pSYGw($jXmWz);
            goto dC2vr;
            Wz2Kw:
            Log::info("Set thumbnail for N1wF7eNF4lYgo Job", ['videoId' => $JfLWA->getAttribute('id'), 'duration' => $JfLWA->getAttribute('duration')]);
            goto Y_FgA;
            DbjBl:
            if (!$jXmWz) {
                goto TDeFo;
            }
            goto tuMvG;
            XPF9D:
            $W04kQ = $W04kQ->mVuZJqIFVcS($gYP4D);
            goto t6vVc;
            t9J1w:
            Log::info("Set input video for Job", ['s3Uri' => $jJfLf]);
            goto w8xuI;
            XdX27:
            $W04kQ->mqAfGivyjzw($ikeQ2->m2xueZkh93c($JfLWA));
            goto G6xqb;
            WToSW:
            $x_H_6 = $x_H_6->mMiBm0pSYGw($jXmWz);
            goto S3etE;
            WO76m:
            $VCOTu = new HYlcVVWzTHXE3('original', $XLJzE, $X8shh, $JfLWA->I4W1t ?? 30);
            goto K1xVI;
            T1BbT:
            $x_H_6 = new HYlcVVWzTHXE3('1080p', $ST6aQ['width'], $ST6aQ['height'], $JfLWA->I4W1t ?? 30);
            goto s3r2f;
            VruZJ:
        } catch (\Exception $dhJHu) {
            Log::info("N1wF7eNF4lYgo has been deleted, discard it", ['fileId' => $eeXS6, 'err' => $dhJHu->getMessage()]);
            return;
        }
        goto YiCog;
        RETXo:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $eeXS6]);
        goto jek0J;
        jek0J:
        ini_set('memory_limit', '-1');
        goto Sexbc;
        YiCog:
    }
    private function mmH9IlIqfK9(N1wF7eNF4lYgo $JfLWA, $jwEgQ) : bool
    {
        goto p8CAb;
        RBB9a:
        return false;
        goto bzBcu;
        QwGWC:
        $atGxb = (int) round($JfLWA->getAttribute('duration') ?? 0);
        goto aIE20;
        cJHMk:
        wHvjk:
        goto MJIwx;
        p8CAb:
        if ($jwEgQ) {
            goto qRCHs;
        }
        goto RBB9a;
        bzBcu:
        qRCHs:
        goto QwGWC;
        ES2KS:
        G_LLU:
        goto cJHMk;
        aIE20:
        switch (true) {
            case $JfLWA->width() * $JfLWA->height() >= 1920 * 1080 && $JfLWA->width() * $JfLWA->height() < 2560 * 1440:
                return $atGxb > 10 * 60;
            case $JfLWA->width() * $JfLWA->height() >= 2560 * 1440 && $JfLWA->width() * $JfLWA->height() < 3840 * 2160:
                return $atGxb > 5 * 60;
            case $JfLWA->width() * $JfLWA->height() >= 3840 * 2160:
                return $atGxb > 3 * 60;
            default:
                return false;
        }
        goto ES2KS;
        MJIwx:
    }
    private function mjJtnsPlr1D(ZKiz9aeWXGIZz $XpJJ6, string $p3Xay) : ?Rcz6vFPVp31Qt
    {
        goto jytPa;
        U0ywR:
        C5HpX:
        goto dwvMJ;
        H5_Y3:
        return new Rcz6vFPVp31Qt($HdJYb, 0, 0, null, null);
        goto U0ywR;
        UxpAS:
        Log::info("Resolve watermark for job with url", ['url' => $p3Xay, 'uri' => $HdJYb]);
        goto gGij0;
        dwvMJ:
        return null;
        goto mOTlk;
        gGij0:
        if (!$HdJYb) {
            goto C5HpX;
        }
        goto H5_Y3;
        jytPa:
        $HdJYb = $XpJJ6->mVIRRSjgwAP($p3Xay);
        goto UxpAS;
        mOTlk:
    }
    private function myDbASfm7we(int $XLJzE, int $X8shh) : bool
    {
        return $XLJzE * $X8shh > 1.5 * (1920 * 1080);
    }
    private function ma8zeHOZg60(int $XLJzE, int $X8shh) : array
    {
        $FIOB2 = new Chhl641vTeaPG($XLJzE, $X8shh);
        return $FIOB2->mKPzSzy82MY();
    }
    private function mS3loCO2ggJ(OWEQTdXGAAFta $QWQ9j) : string
    {
        goto aU1i9;
        uSChU:
        return $this->unMfk->url($QWQ9j->filename);
        goto StirS;
        aU1i9:
        if (!($QWQ9j->Fd5Pz == PdN71mQX1JeZG::S3)) {
            goto h7XHx;
        }
        goto mbTes;
        mbTes:
        return 's3://' . $this->petAu . '/' . $QWQ9j->filename;
        goto DKpbV;
        DKpbV:
        h7XHx:
        goto uSChU;
        StirS:
    }
}
