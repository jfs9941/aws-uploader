<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class DSUHtpZvOZQCp
{
    private $QI7yZ;
    private $fyPpL;
    private $D9Jo8;
    private $gcP3F;
    public function __construct($EAMKc, $UJQDg, $v1Edp, $qxxOf)
    {
        goto kfHvR;
        dJzOA:
        $this->D9Jo8 = $v1Edp;
        goto jBA22;
        jBA22:
        $this->gcP3F = $qxxOf;
        goto EEkok;
        kfHvR:
        $this->fyPpL = $UJQDg;
        goto dJzOA;
        EEkok:
        $this->QI7yZ = $EAMKc;
        goto vCmxV;
        vCmxV:
    }
    public function mrTKCqwq0WU(?int $MpCza, ?int $rfhYJ, string $R5z2N, bool $nKuzl = false) : string
    {
        goto Ia9HT;
        v8iIJ:
        $nBdFw = (int) ($iNuu2 / 80);
        goto md3YV;
        Ia9HT:
        if (!($MpCza === null || $rfhYJ === null)) {
            goto KlMjQ;
        }
        goto AD6j7;
        AD6j7:
        throw new \RuntimeException("ISYJHQo8eqdfc dimensions are not available.");
        goto gAG9c;
        md3YV:
        $iNuu2 -= $nBdFw;
        goto LA90H;
        LA90H:
        if (!($MpCza > 1500)) {
            goto EM_D2;
        }
        goto IAtZc;
        gAG9c:
        KlMjQ:
        goto FgER1;
        iZQTD:
        $tPe6m = $rfhYJ - $pf9E0 - 10;
        goto GizA3;
        Y1OoJ:
        $iNuu2 = $MpCza - $a59o0;
        goto v8iIJ;
        nZ7xA:
        $this->D9Jo8->put($lT4E3, $VSbOm->stream('png'));
        goto G3eLp;
        iHL78:
        uoa2m:
        goto tLfhm;
        tLfhm:
        $VSbOm = $this->QI7yZ->call($this, $MpCza, $rfhYJ);
        goto Y1OoJ;
        FgER1:
        $RHgox = 0.1;
        goto llV_f;
        IAtZc:
        $iNuu2 -= $nBdFw * 0.4;
        goto eNU5Q;
        GizA3:
        $VSbOm->text($hhC1s, $iNuu2, (int) $tPe6m, function ($NcgAr) use($pf9E0) {
            goto VVWhP;
            skETS:
            $NcgAr->align('middle');
            goto EX5lv;
            CawtW:
            $NcgAr->valign('middle');
            goto skETS;
            GZTIs:
            $NcgAr->color([185, 185, 185, 1]);
            goto CawtW;
            oLKrT:
            $NcgAr->size(max($y4S91, 1));
            goto GZTIs;
            uv2RB:
            $y4S91 = (int) ($pf9E0 * 1.2);
            goto oLKrT;
            VVWhP:
            $NcgAr->file(public_path($this->fyPpL));
            goto uv2RB;
            EX5lv:
        });
        goto elwm9;
        eNU5Q:
        EM_D2:
        goto iZQTD;
        llV_f:
        list($pf9E0, $a59o0, $hhC1s) = $this->m9uSX6f9FkH($R5z2N, $MpCza, $RHgox, (float) $MpCza / $rfhYJ);
        goto L84el;
        L84el:
        $lT4E3 = $this->muTb8mGbFxU($hhC1s, $MpCza, $rfhYJ, $a59o0, $pf9E0);
        goto p63Zp;
        G3eLp:
        return $nKuzl ? $lT4E3 : $this->D9Jo8->url($lT4E3);
        goto sbxaP;
        p63Zp:
        if (!$this->D9Jo8->exists($lT4E3)) {
            goto uoa2m;
        }
        goto ZR2xI;
        ZR2xI:
        return $nKuzl ? $lT4E3 : $this->D9Jo8->url($lT4E3);
        goto iHL78;
        elwm9:
        $this->gcP3F->put($lT4E3, $VSbOm->stream('png'));
        goto nZ7xA;
        sbxaP:
    }
    private function muTb8mGbFxU(string $R5z2N, int $MpCza, int $rfhYJ, int $ImUmY, int $sFMi1) : string
    {
        $Vnt1J = ltrim($R5z2N, '@');
        return "v2/watermark/{$Vnt1J}/{$MpCza}x{$rfhYJ}_{$ImUmY}x{$sFMi1}/text_watermark.png";
    }
    private function m9uSX6f9FkH($R5z2N, int $MpCza, float $V8Lqs, float $vMMem) : array
    {
        goto EbTo6;
        vNhP6:
        return [(int) $QIzOp, $a59o0, $hhC1s];
        goto zd9YR;
        lKqfw:
        if (!($vMMem > 1)) {
            goto IvBJM;
        }
        goto bqLLH;
        O6ytS:
        return [(int) $QIzOp, $QIzOp * strlen($hhC1s) / 1.8, $hhC1s];
        goto XXp8Y;
        EbTo6:
        $hhC1s = '@' . $R5z2N;
        goto rnQMR;
        bqLLH:
        $QIzOp = $a59o0 / (strlen($hhC1s) * 0.8);
        goto O6ytS;
        PHodf:
        $QIzOp = 1 / $vMMem * $a59o0 / strlen($hhC1s);
        goto vNhP6;
        rnQMR:
        $a59o0 = (int) ($MpCza * $V8Lqs);
        goto lKqfw;
        XXp8Y:
        IvBJM:
        goto PHodf;
        zd9YR:
    }
}
