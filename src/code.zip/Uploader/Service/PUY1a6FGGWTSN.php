<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\T1J9j7WqyAUZ6;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Core\JmK3jjuoaQvAV;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
final class PUY1a6FGGWTSN implements T1J9j7WqyAUZ6
{
    private $vxhFt;
    private $fceIW;
    public $Qap3S;
    private $jsnmT;
    private $rMK37;
    private $A8xPF;
    public function __construct($WI6o3, $YtFdu, $P1i0X, $qpwNB, $iBRdA, $ZT237)
    {
        goto RQWMW;
        KH9Mp:
        $this->Qap3S = $P1i0X;
        goto rmxtp;
        FSMpu:
        $this->vxhFt = $WI6o3;
        goto OmKfE;
        RQWMW:
        $this->A8xPF = $ZT237;
        goto FSMpu;
        ruwpb:
        $this->rMK37 = $iBRdA;
        goto Pqyrl;
        rmxtp:
        $this->jsnmT = $qpwNB;
        goto ruwpb;
        OmKfE:
        $this->fceIW = $YtFdu;
        goto KH9Mp;
        Pqyrl:
    }
    public function resolvePath($WtNuf, $WCiFa = NZ0k4EM0XOGE7::S3) : string
    {
        goto Bl9X2;
        Tx8DA:
        return trim($this->Qap3S, '/') . '/' . $WtNuf;
        goto JbOdj;
        nKhw2:
        if (!(!empty($this->jsnmT) && !empty($this->rMK37))) {
            goto uAUL0;
        }
        goto PapNW;
        Bl9X2:
        if (!$WtNuf instanceof GGOMDClEFMcsH) {
            goto mgskk;
        }
        goto LZT3B;
        ZKcgZ:
        return config('upload.home') . '/' . $WtNuf;
        goto lhOuf;
        JbOdj:
        YLZ1G:
        goto cWw09;
        YbR3V:
        mgskk:
        goto lDXg6;
        LZT3B:
        $WtNuf = $WtNuf->getAttribute('filename');
        goto YbR3V;
        cWw09:
        return trim($this->fceIW, '/') . '/' . $WtNuf;
        goto Glmsq;
        lhOuf:
        wmDSj:
        goto nKhw2;
        axD7L:
        if (!$this->vxhFt) {
            goto YLZ1G;
        }
        goto Tx8DA;
        j3vQ9:
        uAUL0:
        goto axD7L;
        lDXg6:
        if (!($WCiFa === NZ0k4EM0XOGE7::LOCAL)) {
            goto wmDSj;
        }
        goto ZKcgZ;
        PapNW:
        return $this->mrCE3ys9cyT($WtNuf);
        goto j3vQ9;
        Glmsq:
    }
    public function resolveThumbnail(GGOMDClEFMcsH $WtNuf) : string
    {
        goto gEou8;
        uEiBv:
        return asset('/img/pdf-preview.svg');
        goto i3svK;
        gEou8:
        $N07Z2 = $WtNuf->getAttribute('thumbnail');
        goto zDPPz;
        zDPPz:
        if (!$N07Z2) {
            goto DAAeb;
        }
        goto C2Qnf;
        iGJZx:
        $qu_31 = D6FgZi8OHmjic::find($WtNuf->getAttribute('thumbnail_id'));
        goto t6J8j;
        rBBD6:
        return '';
        goto JGnHQ;
        vxFYc:
        DX9F7:
        goto ahgR2;
        kFlsP:
        if (!$WtNuf->getAttribute('thumbnail_id')) {
            goto j5nCA;
        }
        goto iGJZx;
        C2Qnf:
        return $this->url($N07Z2, $WtNuf->getAttribute('driver'));
        goto HwYZj;
        mQ_E6:
        j5nCA:
        goto P70Qz;
        DheYU:
        return $this->resolvePath($WtNuf, $WtNuf->getAttribute('driver'));
        goto vxFYc;
        P70Qz:
        if (!$WtNuf instanceof D6FgZi8OHmjic) {
            goto DX9F7;
        }
        goto DheYU;
        HwYZj:
        DAAeb:
        goto kFlsP;
        t6J8j:
        if (!$qu_31) {
            goto L2nWd;
        }
        goto FFvjW;
        i3svK:
        n8PfK:
        goto rBBD6;
        ahgR2:
        if (!$WtNuf instanceof JmK3jjuoaQvAV) {
            goto n8PfK;
        }
        goto uEiBv;
        FFvjW:
        return $this->resolvePath($qu_31, $qu_31->getAttribute('driver'));
        goto Hnk65;
        Hnk65:
        L2nWd:
        goto mQ_E6;
        JGnHQ:
    }
    private function url($D4enG, $WCiFa)
    {
        goto tw53w;
        tw53w:
        if (!($WCiFa == NZ0k4EM0XOGE7::LOCAL)) {
            goto IpeQZ;
        }
        goto mcYEs;
        mcYEs:
        return config('upload.home') . '/' . $D4enG;
        goto vhz1z;
        vhz1z:
        IpeQZ:
        goto oyvkF;
        oyvkF:
        return $this->resolvePath($D4enG);
        goto l8efW;
        l8efW:
    }
    private function mrCE3ys9cyT($D4enG)
    {
        goto KLpz9;
        IVtgY:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto qvreg;
        cG9E0:
        return $OXxGm->getSignedUrl($this->Qap3S . '/' . $D4enG, $mxcFh);
        goto nCsqJ;
        WKrXz:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto jig21;
        qvreg:
        ILznY:
        goto ZQEDi;
        KLpz9:
        if (!(strpos($D4enG, 'https://') === 0)) {
            goto wAogX;
        }
        goto WKrXz;
        ZQEDi:
        $mxcFh = now()->addMinutes(60)->timestamp;
        goto Bdow0;
        Bdow0:
        $OXxGm = new UrlSigner($this->jsnmT, $this->A8xPF->path($this->rMK37));
        goto cG9E0;
        GitMF:
        if (!(strpos($D4enG, 'm3u8') !== false)) {
            goto ILznY;
        }
        goto IVtgY;
        jig21:
        wAogX:
        goto GitMF;
        nCsqJ:
    }
    public function resolvePathForHlsVideo(HS7SZ3rYPI80t $ZtI9P, $AZVuE = false) : string
    {
        goto RSvZ6;
        dGG6L:
        return $this->Qap3S . '/' . $ZtI9P->getAttribute('hls_path');
        goto tLDmK;
        u0gGS:
        FA8o3:
        goto dGG6L;
        RSvZ6:
        if ($ZtI9P->getAttribute('hls_path')) {
            goto FA8o3;
        }
        goto dZ9DL;
        dZ9DL:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto u0gGS;
        tLDmK:
    }
    public function resolvePathForHlsVideos()
    {
        goto uauL_;
        YTT70:
        $uMJBE = $this->Qap3S . '/v2/hls/';
        goto DQ9C8;
        uauL_:
        $mxcFh = now()->addDays(3)->timestamp;
        goto YTT70;
        DIftE:
        $ceFnr = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto nhTCQ;
        U5KKx:
        return [$JNROg, $mxcFh];
        goto M6Stl;
        nhTCQ:
        $JNROg = $ceFnr->getSignedCookie(['key_pair_id' => $this->jsnmT, 'private_key' => $this->A8xPF->path($this->rMK37), 'policy' => $JKLJk]);
        goto U5KKx;
        DQ9C8:
        $JKLJk = json_encode(['Statement' => [['Resource' => sprintf('%s*', $uMJBE), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $mxcFh]]]]]);
        goto DIftE;
        M6Stl:
    }
}
