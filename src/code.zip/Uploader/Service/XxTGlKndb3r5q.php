<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
use Illuminate\Contracts\Filesystem\Filesystem;
final class XxTGlKndb3r5q
{
    private $omjLi;
    private $fvRLJ;
    private $W2Sfl;
    public function __construct(string $O893k, string $a9pfQ, Filesystem $d_Wiu)
    {
        goto eteDX;
        sbN8n:
        $this->fvRLJ = $a9pfQ;
        goto nyEeJ;
        eteDX:
        $this->omjLi = $O893k;
        goto sbN8n;
        nyEeJ:
        $this->W2Sfl = $d_Wiu;
        goto SlIEk;
        SlIEk:
    }
    public function mbX0xJUlnfq(Zl4rdW32ufaUx $vPecg) : string
    {
        goto sYNc5;
        sYNc5:
        if (!(J0IuL8wroLOWt::S3 == $vPecg->getAttribute('driver'))) {
            goto xAM_j;
        }
        goto Mtw4e;
        BwVvC:
        xAM_j:
        goto jNaiq;
        jNaiq:
        return $this->W2Sfl->url($vPecg->getAttribute('filename'));
        goto qCkf2;
        Mtw4e:
        return 's3://' . $this->omjLi . '/' . $vPecg->getAttribute('filename');
        goto BwVvC;
        qCkf2:
    }
    public function mLMEQYOm9i9(?string $JyzhY) : ?string
    {
        goto sdsM5;
        rEENa:
        if (!LxqDZ($JyzhY, $this->omjLi)) {
            goto CONn8;
        }
        goto asoyQ;
        sdsM5:
        if (!$JyzhY) {
            goto pG3lv;
        }
        goto rEENa;
        EOcJk:
        return null;
        goto M12z2;
        Qtd_6:
        CONn8:
        goto ACrRF;
        asoyQ:
        $dTJxl = parse_url($JyzhY, PHP_URL_PATH);
        goto AW2eY;
        AW2eY:
        return 's3://' . $this->omjLi . '/' . ltrim($dTJxl, '/');
        goto Qtd_6;
        ACrRF:
        pG3lv:
        goto EOcJk;
        M12z2:
    }
    public function mOlYglCbH4y(string $dTJxl) : string
    {
        return 's3://' . $this->omjLi . '/' . $dTJxl;
    }
}
