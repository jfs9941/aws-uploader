<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\FTr6mgGRFf157;
use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\I0VIwBtNAG2Lq;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Jfs\Uploader\Exception\R2XNcytHoXlGH;
use Jfs\Uploader\Exception\NCCpOFnEetEh7;
use Jfs\Uploader\Exception\Mfea9FZrXQil7;
use Jfs\Uploader\Service\Sr0k4NPxeSoLY;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Dp3MBIkJYF9HF implements UploadServiceInterface
{
    private $dKA28;
    private $W2Sfl;
    private $dMiJj;
    private $BZL0L;
    public function __construct(Sr0k4NPxeSoLY $QS0XP, Filesystem $d_Wiu, Filesystem $F17Nf, string $O8sB2)
    {
        goto LpbgD;
        ExSv3:
        $this->dMiJj = $F17Nf;
        goto JudRZ;
        rCo3t:
        $this->W2Sfl = $d_Wiu;
        goto ExSv3;
        LpbgD:
        $this->dKA28 = $QS0XP;
        goto rCo3t;
        JudRZ:
        $this->BZL0L = $O8sB2;
        goto bebTU;
        bebTU:
    }
    public function storeSingleFile(SingleUploadInterface $plhoa) : array
    {
        goto nQP3k;
        nQP3k:
        $YfsmL = $this->dKA28->mLeTwaifGjO($plhoa);
        goto esMQS;
        hWHCf:
        if (false !== $dTJxl && $YfsmL instanceof FTr6mgGRFf157) {
            goto UG2lt;
        }
        goto KjCZY;
        kMTF_:
        $YfsmL->mWYAL72rhSp(LV0wDYHZInswq::UPLOADED);
        goto nfiko;
        nfiko:
        jbjVi:
        goto PGTG9;
        D0rOX:
        UG2lt:
        goto kMTF_;
        PGTG9:
        return $YfsmL->getView();
        goto fBe8X;
        ITlbY:
        goto jbjVi;
        goto D0rOX;
        esMQS:
        $dTJxl = $this->dMiJj->putFileAs(dirname($YfsmL->getLocation()), $plhoa->getFile(), $YfsmL->getFilename() . '.' . $YfsmL->getExtension(), ['visibility' => 'public']);
        goto hWHCf;
        KjCZY:
        throw new \LogicException('File upload failed, check permissions');
        goto ITlbY;
        fBe8X:
    }
    public function storePreSignedFile(array $RyZmY)
    {
        goto y09E3;
        fqddP:
        $RHBLn->mFwOe5ikmX6($RyZmY['mime'], $RyZmY['file_size'], $RyZmY['chunk_size'], $RyZmY['checksums'], $RyZmY['user_id'], $RyZmY['driver']);
        goto bTQaX;
        GEzcV:
        $RHBLn = I0VIwBtNAG2Lq::mmdXYFst0Sk($YfsmL, $this->W2Sfl, $this->dMiJj, $this->BZL0L, true);
        goto fqddP;
        t5yMp:
        return ['filename' => $RHBLn->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $RHBLn->mL5bQmqdkQa()];
        goto w17AW;
        y09E3:
        $YfsmL = $this->dKA28->mLeTwaifGjO($RyZmY);
        goto GEzcV;
        bTQaX:
        $RHBLn->mNVtShfNZH5();
        goto t5yMp;
        w17AW:
    }
    public function updatePreSignedFile(string $L0rJG, int $EWywO)
    {
        goto obpPg;
        O1NUx:
        D3uM6:
        goto OMoj6;
        obpPg:
        $RHBLn = I0VIwBtNAG2Lq::mHhSqUKEaDa($L0rJG, $this->W2Sfl, $this->dMiJj, $this->BZL0L);
        goto glrdH;
        glrdH:
        switch ($EWywO) {
            case LV0wDYHZInswq::UPLOADED:
                $RHBLn->m39s5lPmBsY();
                goto tC2bL;
            case LV0wDYHZInswq::PROCESSING:
                $RHBLn->mAIknZtEWxh();
                goto tC2bL;
            case LV0wDYHZInswq::FINISHED:
                $RHBLn->mUjWcAtiIZU();
                goto tC2bL;
            case LV0wDYHZInswq::ABORTED:
                $RHBLn->mhAfcCsxAoF();
                goto tC2bL;
        }
        goto O1NUx;
        OMoj6:
        tC2bL:
        goto hym21;
        hym21:
    }
    public function completePreSignedFile(string $L0rJG, array $MZWng)
    {
        goto rSbMu;
        kXbFk:
        $RHBLn->mAOwHvxkwWq()->mMyEb8uTkGj($MZWng);
        goto SCOfZ;
        rSbMu:
        $RHBLn = I0VIwBtNAG2Lq::mHhSqUKEaDa($L0rJG, $this->W2Sfl, $this->dMiJj, $this->BZL0L);
        goto kXbFk;
        DLstW:
        return ['path' => $RHBLn->getFile()->getView()['path'], 'thumbnail' => $RHBLn->getFile()->hrRlC, 'id' => $L0rJG];
        goto D04d3;
        SCOfZ:
        $RHBLn->m39s5lPmBsY();
        goto DLstW;
        D04d3:
    }
    public function updateFile(string $L0rJG, int $EWywO) : X5WvqPHlZPq50
    {
        goto cL2aF;
        cL2aF:
        $YfsmL = $this->dKA28->mNA739rY1kw($L0rJG);
        goto clvus;
        clvus:
        $YfsmL->mWYAL72rhSp($EWywO);
        goto NF_Kl;
        NF_Kl:
        return $YfsmL;
        goto v1Pz9;
        v1Pz9:
    }
}
