<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\LuYApSsjKQvJj;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Core\JmnRmflAnvBc1;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
final class NCOAFhLniyr9A implements LuYApSsjKQvJj
{
    private $BPcWO;
    private $jrGQo;
    public $Jf5T0;
    private $yPKyr;
    private $WoX2z;
    private $jhnu6;
    public function __construct($HJSEs, $r1Hp9, $Iq_In, $cWhQQ, $QMWhh, $vWOwZ)
    {
        goto Wb5mw;
        Wb5mw:
        $this->jhnu6 = $vWOwZ;
        goto RfSTD;
        hvpjZ:
        $this->WoX2z = $QMWhh;
        goto yK1wC;
        Bn2Q0:
        $this->yPKyr = $cWhQQ;
        goto hvpjZ;
        r2zqi:
        $this->Jf5T0 = $Iq_In;
        goto Bn2Q0;
        RfSTD:
        $this->BPcWO = $HJSEs;
        goto wxYhW;
        wxYhW:
        $this->jrGQo = $r1Hp9;
        goto r2zqi;
        yK1wC:
    }
    public function resolvePath($XCcud, $UPm3o = Y9OZ7qWyGdhw2::S3) : string
    {
        goto y5oR2;
        sQhmL:
        $XCcud = $XCcud->getAttribute('filename');
        goto m_ISD;
        B0yx5:
        if (!$this->BPcWO) {
            goto u4AOL;
        }
        goto r7fx1;
        ZcIjM:
        m4zxU:
        goto vXMTi;
        nbMm6:
        u4AOL:
        goto xYoj0;
        vXMTi:
        if (!(!empty($this->yPKyr) && !empty($this->WoX2z))) {
            goto hUPkf;
        }
        goto avwOf;
        y5oR2:
        if (!$XCcud instanceof Lx6EggVsR2j6q) {
            goto Y2Uv3;
        }
        goto sQhmL;
        xYoj0:
        return trim($this->jrGQo, '/') . '/' . $XCcud;
        goto DIsvN;
        r7fx1:
        return trim($this->Jf5T0, '/') . '/' . $XCcud;
        goto nbMm6;
        m_ISD:
        Y2Uv3:
        goto wrZwP;
        wrZwP:
        if (!($UPm3o === Y9OZ7qWyGdhw2::LOCAL)) {
            goto m4zxU;
        }
        goto lSlYd;
        lSlYd:
        return config('upload.home') . '/' . $XCcud;
        goto ZcIjM;
        OqM_q:
        hUPkf:
        goto B0yx5;
        avwOf:
        return $this->mkUwWONljoU($XCcud);
        goto OqM_q;
        DIsvN:
    }
    public function resolveThumbnail(Lx6EggVsR2j6q $XCcud) : string
    {
        goto Jfiwv;
        tuPmT:
        if (!$XqjZc) {
            goto kzZic;
        }
        goto py4GX;
        qEF8K:
        return '';
        goto icq4z;
        GY_YS:
        if (!$qguRr) {
            goto KrYM_;
        }
        goto fSdux;
        i3_bE:
        KrYM_:
        goto yjQ3_;
        SOPYg:
        hnvDn:
        goto qEF8K;
        py4GX:
        return $this->url($XqjZc, $XCcud->getAttribute('driver'));
        goto WY9VJ;
        yjQ3_:
        d5Tzu:
        goto x4lvA;
        WY9VJ:
        kzZic:
        goto tlFJ5;
        Jfiwv:
        $XqjZc = $XCcud->getAttribute('thumbnail');
        goto tuPmT;
        tgLGK:
        return asset('/img/pdf-preview.svg');
        goto SOPYg;
        SzNz6:
        if (!$XCcud instanceof JmnRmflAnvBc1) {
            goto hnvDn;
        }
        goto tgLGK;
        tlFJ5:
        if (!$XCcud->getAttribute('thumbnail_id')) {
            goto d5Tzu;
        }
        goto Pp18r;
        x4lvA:
        if (!$XCcud instanceof JOauoJMkgHWbh) {
            goto CwX2v;
        }
        goto fEKeO;
        Pp18r:
        $qguRr = JOauoJMkgHWbh::find($XCcud->getAttribute('thumbnail_id'));
        goto GY_YS;
        fEKeO:
        return $this->resolvePath($XCcud, $XCcud->getAttribute('driver'));
        goto DvwoE;
        DvwoE:
        CwX2v:
        goto SzNz6;
        fSdux:
        return $this->resolvePath($qguRr, $qguRr->getAttribute('driver'));
        goto i3_bE;
        icq4z:
    }
    private function url($K_YMm, $UPm3o)
    {
        goto OKaTr;
        GWBqA:
        return $this->resolvePath($K_YMm);
        goto L7Ewx;
        C6QO2:
        return config('upload.home') . '/' . $K_YMm;
        goto ofl21;
        ofl21:
        uAXAu:
        goto GWBqA;
        OKaTr:
        if (!($UPm3o == Y9OZ7qWyGdhw2::LOCAL)) {
            goto uAXAu;
        }
        goto C6QO2;
        L7Ewx:
    }
    private function mkUwWONljoU($K_YMm)
    {
        goto FPhoZ;
        GKA4O:
        $jliDa = new UrlSigner($this->yPKyr, $this->jhnu6->path($this->WoX2z));
        goto iPIdL;
        qPBii:
        FNpwE:
        goto BvaAm;
        hdoeR:
        if (!(strpos($K_YMm, 'm3u8') !== false)) {
            goto FNpwE;
        }
        goto qcNPG;
        iPIdL:
        return $jliDa->getSignedUrl($this->Jf5T0 . '/' . $K_YMm, $JxF0U);
        goto GKhO6;
        BvaAm:
        $JxF0U = now()->addMinutes(60)->timestamp;
        goto GKA4O;
        FPhoZ:
        if (!(strpos($K_YMm, 'https://') === 0)) {
            goto gAoy1;
        }
        goto DsZt4;
        XiPww:
        gAoy1:
        goto hdoeR;
        qcNPG:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto qPBii;
        DsZt4:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto XiPww;
        GKhO6:
    }
    public function resolvePathForHlsVideo(O1jfuwJR340k5 $cFlec, $z3VTt = false) : string
    {
        goto BOESR;
        WIWOa:
        Yn1sn:
        goto ge5HS;
        ge5HS:
        return $this->Jf5T0 . '/' . $cFlec->getAttribute('hls_path');
        goto VA2pU;
        BOESR:
        if ($cFlec->getAttribute('hls_path')) {
            goto Yn1sn;
        }
        goto YlLA1;
        YlLA1:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto WIWOa;
        VA2pU:
    }
    public function resolvePathForHlsVideos()
    {
        goto OsYAF;
        OsYAF:
        $JxF0U = now()->addDays(3)->timestamp;
        goto Pk6hM;
        j3qOs:
        $wBeCI = $hTP7M->getSignedCookie(['key_pair_id' => $this->yPKyr, 'private_key' => $this->jhnu6->path($this->WoX2z), 'policy' => $bbX_M]);
        goto OfYtr;
        OfYtr:
        return [$wBeCI, $JxF0U];
        goto l6OZe;
        mvc4M:
        $hTP7M = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto j3qOs;
        Pk6hM:
        $Npdka = $this->Jf5T0 . '/v2/hls/';
        goto th9w4;
        th9w4:
        $bbX_M = json_encode(['Statement' => [['Resource' => sprintf('%s*', $Npdka), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $JxF0U]]]]]);
        goto mvc4M;
        l6OZe:
    }
}
