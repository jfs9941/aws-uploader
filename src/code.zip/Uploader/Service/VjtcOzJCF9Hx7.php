<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Illuminate\Contracts\Filesystem\Filesystem;
final class VjtcOzJCF9Hx7
{
    private $pKUHV;
    private $Zzvae;
    private $hYphi;
    public function __construct(string $drKb4, string $zjacU, Filesystem $zuNM5)
    {
        goto i62BZ;
        fiJQF:
        $this->Zzvae = $zjacU;
        goto qjE1k;
        i62BZ:
        $this->pKUHV = $drKb4;
        goto fiJQF;
        qjE1k:
        $this->hYphi = $zuNM5;
        goto jswWM;
        jswWM:
    }
    public function mHTF8ZHpQ2c(GGOMDClEFMcsH $FX5Wq) : string
    {
        goto rIBTv;
        HTKEn:
        return $this->hYphi->url($FX5Wq->getAttribute('filename'));
        goto FEbnp;
        rIBTv:
        if (!(NZ0k4EM0XOGE7::S3 == $FX5Wq->getAttribute('driver'))) {
            goto lpgR3;
        }
        goto WsSTF;
        WKykF:
        lpgR3:
        goto HTKEn;
        WsSTF:
        return 's3://' . $this->pKUHV . '/' . $FX5Wq->getAttribute('filename');
        goto WKykF;
        FEbnp:
    }
    public function mvgEw85RtYY(?string $UoeVh) : ?string
    {
        goto GtZfi;
        FMWFv:
        RPzkl:
        goto tu5u8;
        YXBoF:
        q6Sx6:
        goto FMWFv;
        PLsWx:
        return 's3://' . $this->pKUHV . '/' . ltrim($D4enG, '/');
        goto YXBoF;
        tu5u8:
        return null;
        goto tbdBn;
        Oh69B:
        $D4enG = parse_url($UoeVh, PHP_URL_PATH);
        goto PLsWx;
        GtZfi:
        if (!$UoeVh) {
            goto RPzkl;
        }
        goto ZofD7;
        ZofD7:
        if (!str_contains($UoeVh, $this->pKUHV)) {
            goto q6Sx6;
        }
        goto Oh69B;
        tbdBn:
    }
    public function m98cY8xF205(string $D4enG) : string
    {
        return 's3://' . $this->pKUHV . '/' . $D4enG;
    }
}
