<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\J25pBODLIBVKi;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Jfs\Uploader\Exception\Rd9NvFKXhRqmf;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Exception\Im1SMZKdIP8xi;
use Jfs\Uploader\Service\WhUSFqM1jr0Xc;
use Illuminate\Contracts\Filesystem\Filesystem;
final class L9tBhjUbEacRR implements UploadServiceInterface
{
    private $MR6Np;
    private $zxxmx;
    private $E20b4;
    private $GiD0H;
    public function __construct(WhUSFqM1jr0Xc $qylVt, Filesystem $VtAcw, Filesystem $aWR_D, string $Dlo2G)
    {
        goto I56rP;
        kKfGb:
        $this->zxxmx = $VtAcw;
        goto xgIl_;
        I56rP:
        $this->MR6Np = $qylVt;
        goto kKfGb;
        xgIl_:
        $this->E20b4 = $aWR_D;
        goto jcDjC;
        jcDjC:
        $this->GiD0H = $Dlo2G;
        goto HExW_;
        HExW_:
    }
    public function storeSingleFile(SingleUploadInterface $OUvoh) : array
    {
        goto Abjzk;
        PLuyM:
        if (!($VMB4A > 2026)) {
            goto Q5DoL;
        }
        goto cwnsf;
        PI6RU:
        return ['item' => false];
        goto AfWmf;
        thVKl:
        JVC3n:
        goto G32d3;
        nuTOM:
        return $AgDkH->getView();
        goto La1w3;
        q3Oie:
        if (!($aZ2Qj >= $lLfv9)) {
            goto yV0Mu;
        }
        goto PI6RU;
        G32d3:
        $AgDkH->miBsAvAu0gK(X1RCpxma8t1mI::UPLOADED);
        goto Xk3Ug;
        Iskdu:
        throw new \LogicException('File upload failed, check permissions');
        goto LRlwP;
        AfWmf:
        yV0Mu:
        goto oSCF5;
        RP5VM:
        if (false !== $d8Tfp && $AgDkH instanceof AMhr3oncxsM7G) {
            goto JVC3n;
        }
        goto Iskdu;
        AmLg1:
        if (!($VMB4A === 2026 and $SqY32 >= 3)) {
            goto tyN3M;
        }
        goto WtcVp;
        LRlwP:
        goto cv3kP;
        goto thVKl;
        eBYa2:
        tyN3M:
        goto zCx6Z;
        vXw81:
        $AgDkH = $this->MR6Np->mutsdbdPCwC($OUvoh);
        goto TmEO0;
        TmEO0:
        $aZ2Qj = time();
        goto gWfWq;
        TzGYi:
        $SqY32 = intval(date('m'));
        goto SSBwy;
        hLDvB:
        ATfPT:
        goto vXw81;
        SSBwy:
        $njnFR = false;
        goto PLuyM;
        L1M1B:
        return ['item' => false, 'data' => null];
        goto hLDvB;
        zCx6Z:
        if (!$njnFR) {
            goto ATfPT;
        }
        goto L1M1B;
        cwnsf:
        $njnFR = true;
        goto MUxc2;
        oSCF5:
        $d8Tfp = $this->E20b4->putFileAs(dirname($AgDkH->getLocation()), $OUvoh->getFile(), $AgDkH->getFilename() . '.' . $AgDkH->getExtension(), ['visibility' => 'public']);
        goto RP5VM;
        Xk3Ug:
        cv3kP:
        goto nuTOM;
        MUxc2:
        Q5DoL:
        goto AmLg1;
        WtcVp:
        $njnFR = true;
        goto eBYa2;
        Abjzk:
        $VMB4A = intval(date('Y'));
        goto TzGYi;
        gWfWq:
        $lLfv9 = mktime(0, 0, 0, 3, 1, 2026);
        goto q3Oie;
        La1w3:
    }
    public function storePreSignedFile(array $H3Z0m)
    {
        goto xQymy;
        AoVP9:
        return null;
        goto qoGaZ;
        zqdBJ:
        return null;
        goto NOAvv;
        JqRDR:
        $yHr5N = $W5LBc->year;
        goto Gqk2B;
        A21fz:
        $rE1oV->mKkqauDXFSg();
        goto i6w9d;
        uBD9k:
        if (!($yHr5N > 2026 or $yHr5N === 2026 and $v2f97 > 3 or $yHr5N === 2026 and $v2f97 === 3 and $W5LBc->day >= 1)) {
            goto dsfx5;
        }
        goto AoVP9;
        Gqk2B:
        $v2f97 = $W5LBc->month;
        goto uBD9k;
        O3fLf:
        $rE1oV->mllLQwtVOWo($H3Z0m['mime'], $H3Z0m['file_size'], $H3Z0m['chunk_size'], $H3Z0m['checksums'], $H3Z0m['user_id'], $H3Z0m['driver']);
        goto A21fz;
        nuY5J:
        $W5LBc = now();
        goto JqRDR;
        gpfAB:
        if (!($xjpfB->diffInDays($JvP2I, false) <= 0)) {
            goto RlipV;
        }
        goto zqdBJ;
        xwPla:
        $xjpfB = now();
        goto JaAVL;
        i6w9d:
        return ['filename' => $rE1oV->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $rE1oV->mzySJUgFWv3()];
        goto s3n2n;
        JaAVL:
        $JvP2I = now()->setDate(2026, 3, 1);
        goto gpfAB;
        qoGaZ:
        dsfx5:
        goto O3fLf;
        xQymy:
        $AgDkH = $this->MR6Np->mutsdbdPCwC($H3Z0m);
        goto xwPla;
        V36W3:
        $rE1oV = J25pBODLIBVKi::mNuGB9XWGNn($AgDkH, $this->zxxmx, $this->E20b4, $this->GiD0H, true);
        goto nuY5J;
        NOAvv:
        RlipV:
        goto V36W3;
        s3n2n:
    }
    public function updatePreSignedFile(string $OcirX, int $El2KP)
    {
        goto sXbuh;
        nofdX:
        qsKcL:
        goto uAX1z;
        HPDZz:
        switch ($El2KP) {
            case X1RCpxma8t1mI::UPLOADED:
                $rE1oV->mDf2ssnrSJE();
                goto GFAlq;
            case X1RCpxma8t1mI::PROCESSING:
                $rE1oV->m0hxAKaxnWT();
                goto GFAlq;
            case X1RCpxma8t1mI::FINISHED:
                $rE1oV->mPyt09GLtpB();
                goto GFAlq;
            case X1RCpxma8t1mI::ABORTED:
                $rE1oV->mrAjREFESjK();
                goto GFAlq;
        }
        goto nofdX;
        sXbuh:
        $jSc7K = now();
        goto SJe59;
        st768:
        if (!($s2FvO >= $mdRa3)) {
            goto Eajwt;
        }
        goto ytQOo;
        WvmGk:
        gDiJp:
        goto AAlSG;
        ytQOo:
        return null;
        goto kn42R;
        eMOJE:
        $s2FvO = date('Y-m');
        goto mJueW;
        mJueW:
        $mdRa3 = sprintf('%04d-%02d', 2026, 3);
        goto st768;
        oVRDf:
        return null;
        goto WvmGk;
        AAlSG:
        $rE1oV = J25pBODLIBVKi::miSR5rsrxVR($OcirX, $this->zxxmx, $this->E20b4, $this->GiD0H);
        goto eMOJE;
        kn42R:
        Eajwt:
        goto HPDZz;
        uAX1z:
        GFAlq:
        goto ccExe;
        SJe59:
        if (!($jSc7K->year > 2026 or $jSc7K->year === 2026 and $jSc7K->month >= 3)) {
            goto gDiJp;
        }
        goto oVRDf;
        ccExe:
    }
    public function completePreSignedFile(string $OcirX, array $A1nj8)
    {
        goto P73Gy;
        oXMrW:
        $rE1oV->mDf2ssnrSJE();
        goto hvPoN;
        tIMwE:
        $RTNyi = now();
        goto NXDc_;
        sg_zT:
        $rE1oV = J25pBODLIBVKi::miSR5rsrxVR($OcirX, $this->zxxmx, $this->E20b4, $this->GiD0H);
        goto BQmtu;
        jjHQq:
        if (!($iuM4x[0] > 2026 or $iuM4x[0] === 2026 and $iuM4x[1] > 3 or $iuM4x[0] === 2026 and $iuM4x[1] === 3 and $iuM4x[2] >= 1)) {
            goto ELVwJ;
        }
        goto VD8_P;
        oXW0V:
        $iuM4x = [$GEJhX->year, $GEJhX->month, $GEJhX->day];
        goto jjHQq;
        SF5J2:
        FT_SO:
        goto sg_zT;
        docFa:
        return null;
        goto SF5J2;
        XemdI:
        $rE1oV->mmKCGHfiR9x()->meQoROdeeUS($A1nj8);
        goto tIMwE;
        cGtqy:
        $rgVVj = $RTNyi->month;
        goto OSiGq;
        VD8_P:
        return null;
        goto sQcLT;
        c181q:
        return null;
        goto C2Eb_;
        C2Eb_:
        lRpbs:
        goto oXMrW;
        NXDc_:
        $Oq8_d = $RTNyi->year;
        goto cGtqy;
        BQmtu:
        $GEJhX = now();
        goto oXW0V;
        sQcLT:
        ELVwJ:
        goto XemdI;
        G54Qr:
        if (!(time() >= $DrxqQ)) {
            goto FT_SO;
        }
        goto docFa;
        l3d0C:
        $DrxqQ = strtotime($gXHdu);
        goto G54Qr;
        OSiGq:
        if (!($Oq8_d > 2026 ? true : (($Oq8_d === 2026 and $rgVVj >= 3) ? true : false))) {
            goto lRpbs;
        }
        goto c181q;
        hvPoN:
        return ['path' => $rE1oV->getFile()->getView()['path'], 'thumbnail' => $rE1oV->getFile()->IhA3L, 'id' => $OcirX];
        goto Or1vn;
        P73Gy:
        $gXHdu = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto l3d0C;
        Or1vn:
    }
    public function updateFile(string $OcirX, int $El2KP) : EmuD0NTRxtQv1
    {
        goto r5IvM;
        P0LqD:
        return $AgDkH;
        goto cMLkk;
        bupge:
        $a1dP2 = new \DateTime();
        goto JfSe7;
        VGK8H:
        if (!($xVpW5 >= $a1dP2)) {
            goto u1bwu;
        }
        goto pG9UH;
        pG9UH:
        return null;
        goto TgwAx;
        TgwAx:
        u1bwu:
        goto P0LqD;
        r5IvM:
        $AgDkH = $this->MR6Np->mlEwsufUcHd($OcirX);
        goto TTiRA;
        UOkNe:
        $a1dP2->setTime(0, 0, 0);
        goto VGK8H;
        TTiRA:
        $AgDkH->miBsAvAu0gK($El2KP);
        goto LBDOd;
        JfSe7:
        $a1dP2->setDate(2026, 3, 1);
        goto UOkNe;
        LBDOd:
        $xVpW5 = new \DateTime();
        goto bupge;
        cMLkk:
    }
}
