<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Core\Observer\O8TC4bcvVFiB0;
use Jfs\Uploader\Core\Observer\HxI1l4gkv9iZP;
use Jfs\Uploader\Core\QJ9aA37t27inE;
use Jfs\Uploader\Core\E4a2957rpFTRJ;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Exception\Pwrqemn2dhCsC;
use Jfs\Uploader\Service\FileResolver\MSiFUZOGwRG6e;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class GxQCvfot4aISP
{
    private $go7Mf;
    private $IaFSl;
    private $huyLW;
    public function __construct($cZzRx, $B27Pk, $A3hvZ)
    {
        goto P1J6w;
        GXqhQ:
        $this->IaFSl = $B27Pk;
        goto ZiQH3;
        ZiQH3:
        $this->huyLW = $A3hvZ;
        goto xv6cz;
        P1J6w:
        $this->go7Mf = $cZzRx;
        goto GXqhQ;
        xv6cz:
    }
    public function mYrzKv4DgHd($ZJ06D)
    {
        goto GpeH_;
        GpeH_:
        if (!$ZJ06D instanceof SingleUploadInterface) {
            goto Yt1BF;
        }
        goto PWZPj;
        xx8tR:
        Yt1BF:
        goto sDOSm;
        qCihW:
        return $this->mrCvjSWuZ9I($JXoUa->extension(), Opdj0uZXaMJfa::S3, null, $ZJ06D->options());
        goto xx8tR;
        sDOSm:
        return $this->mrCvjSWuZ9I($ZJ06D['file_extension'], 's3' === $ZJ06D['driver'] ? Opdj0uZXaMJfa::S3 : Opdj0uZXaMJfa::LOCAL);
        goto NDq85;
        PWZPj:
        $JXoUa = $ZJ06D->getFile();
        goto qCihW;
        NDq85:
    }
    public function mby5fO9zINL(string $arqvy)
    {
        goto dtuoY;
        IZsRt:
        $FJFJj = $this->mrCvjSWuZ9I($pCAnX->getAttribute('type'), $pCAnX->getAttribute('driver'), $pCAnX->getAttribute('id'));
        goto iQGEt;
        dtuoY:
        $pCAnX = config('upload.attachment_model')::findOrFail($arqvy);
        goto IZsRt;
        R5DSw:
        return $FJFJj;
        goto H8VmK;
        EFrZY:
        $FJFJj->setRawAttributes($pCAnX->getAttributes());
        goto R5DSw;
        iQGEt:
        $FJFJj->exists = true;
        goto EFrZY;
        H8VmK:
    }
    public function miGkXiiUjT8(string $lFeYw) : IzCykbeCOYPNB
    {
        goto lncPU;
        cmHdA:
        if (!$vOZNn) {
            goto p92Uy;
        }
        goto MP11i;
        lncPU:
        $qkQ5g = $this->IaFSl->get($lFeYw);
        goto zzMe6;
        QUfuh:
        throw new B9AWimnd5WRl4('metadata file not found');
        goto PEOF_;
        XVVK2:
        p92Uy:
        goto QUfuh;
        MP11i:
        $z64Gv = E4a2957rpFTRJ::mmma09KXsnd($vOZNn);
        goto J8K9c;
        uRTMY:
        OcBdh:
        goto Qwcnr;
        ckgtE:
        $qkQ5g = $this->huyLW->get($lFeYw);
        goto uRTMY;
        J8K9c:
        return $this->mrCvjSWuZ9I($z64Gv->vYbvm, $z64Gv->m1D4daBT764(), $z64Gv->filename);
        goto XVVK2;
        zzMe6:
        if ($qkQ5g) {
            goto OcBdh;
        }
        goto ckgtE;
        Qwcnr:
        $vOZNn = json_decode($qkQ5g, true);
        goto cmHdA;
        PEOF_:
    }
    private function mrCvjSWuZ9I(string $DMC5n, $CjTHv, ?string $arqvy = null, array $RvoDa = [])
    {
        goto h0kiX;
        JOmfO:
        foreach ($this->go7Mf as $IuV7H) {
            goto gZ4kV;
            e3RFX:
            dg0dQ:
            goto og8uH;
            Clctu:
            return $I72qC->initLocation($IuV7H->mb8NmWrIddR($I72qC));
            goto e3RFX;
            gZ4kV:
            if (!$IuV7H->mQroel6wQ9R($I72qC)) {
                goto dg0dQ;
            }
            goto Clctu;
            og8uH:
            GNQS1:
            goto xwOkP;
            xwOkP:
        }
        goto Zh5w7;
        Zh5w7:
        cxXrq:
        goto irsjf;
        h0kiX:
        $arqvy = $arqvy ?? Uuid::uuid4()->getHex()->toString();
        goto RoG03;
        Hb8I5:
        rE09d:
        goto trjiz;
        Eoo_h:
        $I72qC = $I72qC->mcQ0B6abPWV($CjTHv);
        goto ObVFc;
        yhU1T:
        $I72qC->mf8n37ngIzn(new HxI1l4gkv9iZP($I72qC, $this->huyLW, $RvoDa));
        goto JOmfO;
        irsjf:
        throw new Pwrqemn2dhCsC("not support file type {$DMC5n}");
        goto y8nK2;
        RoG03:
        switch ($DMC5n) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $I72qC = S7LEoIprYtLQw::createFromScratch($arqvy, $DMC5n);
                goto r29xv;
            case 'mp4':
            case 'mov':
                $I72qC = RhSx2q5xIlh0Y::createFromScratch($arqvy, $DMC5n);
                goto r29xv;
            case 'pdf':
                $I72qC = QJ9aA37t27inE::createFromScratch($arqvy, $DMC5n);
                goto r29xv;
            default:
                throw new Pwrqemn2dhCsC("not support file type {$DMC5n}");
        }
        goto Hb8I5;
        trjiz:
        r29xv:
        goto Eoo_h;
        ObVFc:
        $I72qC->mf8n37ngIzn(new O8TC4bcvVFiB0($I72qC));
        goto yhU1T;
        y8nK2:
    }
}
