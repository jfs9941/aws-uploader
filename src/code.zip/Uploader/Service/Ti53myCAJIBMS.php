<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Core\Observer\YcvxUMkSY8zdA;
use Jfs\Uploader\Core\Observer\MPRhglOgVUwL1;
use Jfs\Uploader\Core\NvNhGXZYZ9DLW;
use Jfs\Uploader\Core\IVTeeOwHA8NRW;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Jfs\Uploader\Exception\MbrGjey4Z1MjR;
use Jfs\Uploader\Service\FileResolver\WEvsKO38EVJMP;
use Ramsey\Uuid\Uuid;
final class Ti53myCAJIBMS
{
    private $DMb9w;
    private $OKvrN;
    private $GQuun;
    public function __construct($D1TBG, $GiTtn, $Q0shJ)
    {
        goto lhaWB;
        RwTw0:
        $this->GQuun = $Q0shJ;
        goto I75Ym;
        jbu5j:
        $this->OKvrN = $GiTtn;
        goto RwTw0;
        lhaWB:
        $this->DMb9w = $D1TBG;
        goto jbu5j;
        I75Ym:
    }
    public function mJtZyq3Xt3p($D7dkI)
    {
        goto Y_qFU;
        Zf_GF:
        return $this->mBzXB1Jp76b($UvQM5->extension(), VCKF0xK25vLxq::S3, null, $D7dkI->options());
        goto LPkBr;
        PZaQN:
        $UvQM5 = $D7dkI->getFile();
        goto Zf_GF;
        Y_qFU:
        if (!$D7dkI instanceof SingleUploadInterface) {
            goto Aogle;
        }
        goto PZaQN;
        MH48B:
        return $this->mBzXB1Jp76b($D7dkI['file_extension'], 's3' === $D7dkI['driver'] ? VCKF0xK25vLxq::S3 : VCKF0xK25vLxq::LOCAL);
        goto pv4b2;
        LPkBr:
        Aogle:
        goto MH48B;
        pv4b2:
    }
    public function mZLmNe9WEbQ(string $eXur0)
    {
        goto NVaGg;
        VTwow:
        $ezBDN->setRawAttributes($pwWUc->getAttributes());
        goto fbfjG;
        Kg4bd:
        $ezBDN = $this->mBzXB1Jp76b($pwWUc->getAttribute('type'), $pwWUc->getAttribute('driver'), $pwWUc->getAttribute('id'));
        goto R5LQd;
        R5LQd:
        $ezBDN->exists = true;
        goto VTwow;
        NVaGg:
        $pwWUc = config('upload.attachment_model')::findOrFail($eXur0);
        goto Kg4bd;
        fbfjG:
        return $ezBDN;
        goto XoL3L;
        XoL3L:
    }
    public function mt7BmR82Kvz(string $sQd3y) : IEfiXfym24wIp
    {
        goto BHAmS;
        zccqw:
        rY57g:
        goto ogrLe;
        RvDtF:
        $zJ7eR = IVTeeOwHA8NRW::m9H3IbCYV7f($jJ8fr);
        goto clgci;
        BHAmS:
        $R_cHc = $this->OKvrN->get($sQd3y);
        goto zC1dX;
        clgci:
        return $this->mBzXB1Jp76b($zJ7eR->CVNc9, $zJ7eR->m7gGHc9dD7O(), $zJ7eR->filename);
        goto NFwB9;
        NFwB9:
        cW4tX:
        goto miirT;
        ogrLe:
        $jJ8fr = json_decode($R_cHc, true);
        goto s243g;
        zC1dX:
        if ($R_cHc) {
            goto rY57g;
        }
        goto ZvS54;
        ZvS54:
        $R_cHc = $this->GQuun->get($sQd3y);
        goto zccqw;
        miirT:
        throw new Wp4p9VCmIjK6G('metadata file not found');
        goto jUvms;
        s243g:
        if (!$jJ8fr) {
            goto cW4tX;
        }
        goto RvDtF;
        jUvms:
    }
    private function mBzXB1Jp76b(string $chXuT, $IlTmR, ?string $eXur0 = null, array $XGlwJ = [])
    {
        goto MxMdj;
        rT9mk:
        Y3O9A:
        goto wGiWb;
        R24BF:
        foreach ($this->DMb9w as $ggIs8) {
            goto LfKVP;
            o70jJ:
            return $HZr_o->initLocation($ggIs8->mVeDSPX1Tlz($HZr_o));
            goto LF9Db;
            LF9Db:
            WetSt:
            goto E4mJn;
            E4mJn:
            zDcOw:
            goto hyaXC;
            LfKVP:
            if (!$ggIs8->mS9eeM6KIgR($HZr_o)) {
                goto WetSt;
            }
            goto o70jJ;
            hyaXC:
        }
        goto rT9mk;
        nRXpu:
        $HZr_o->m7NixpKJfrg(new MPRhglOgVUwL1($HZr_o, $this->GQuun, $XGlwJ));
        goto R24BF;
        pHIE6:
        Xs5Wd:
        goto TWFv4;
        oGuZL:
        switch ($chXuT) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $HZr_o = NBWuSM65HseqY::createFromScratch($eXur0, $chXuT);
                goto pnmb8;
            case 'mp4':
            case 'mov':
                $HZr_o = S25BfMDKrX8cB::createFromScratch($eXur0, $chXuT);
                goto pnmb8;
            case 'pdf':
                $HZr_o = NvNhGXZYZ9DLW::createFromScratch($eXur0, $chXuT);
                goto pnmb8;
            default:
                throw new MbrGjey4Z1MjR("not support file type {$chXuT}");
        }
        goto pHIE6;
        TWFv4:
        pnmb8:
        goto B5BoA;
        B5BoA:
        $HZr_o = $HZr_o->mAL3TYgu7M8($IlTmR);
        goto gHZ1x;
        MxMdj:
        $eXur0 = $eXur0 ?? Uuid::uuid4()->getHex()->toString();
        goto oGuZL;
        gHZ1x:
        $HZr_o->m7NixpKJfrg(new YcvxUMkSY8zdA($HZr_o));
        goto nRXpu;
        wGiWb:
        throw new MbrGjey4Z1MjR("not support file type {$chXuT}");
        goto V3xjy;
        V3xjy:
    }
}
