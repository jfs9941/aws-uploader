<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Core\Observer\FhPHJXipLxQC9;
use Jfs\Uploader\Core\Observer\IASUYv8MKeNRq;
use Jfs\Uploader\Core\TXSCPefqEsBH1;
use Jfs\Uploader\Core\ZQCRUoYnm7ASE;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Jfs\Uploader\Exception\KkJ7iB3slsUjq;
use Jfs\Uploader\Service\FileResolver\DLulLsFkRdSfW;
use Ramsey\Uuid\Uuid;
final class VRKkgi2bc4uRE
{
    private $SBuSg;
    private $bX3fI;
    private $auR_S;
    public function __construct($hNiiZ, $Q0hWX, $JhAxH)
    {
        goto SItBm;
        X8Adj:
        $this->auR_S = $JhAxH;
        goto qoowj;
        SItBm:
        $this->SBuSg = $hNiiZ;
        goto j8wDJ;
        j8wDJ:
        $this->bX3fI = $Q0hWX;
        goto X8Adj;
        qoowj:
    }
    public function mH6KTH4GAyq($zvcov)
    {
        goto tRJTd;
        a5cdJ:
        return $this->mF9BEBqnjrF($zvcov['file_extension'], 's3' === $zvcov['driver'] ? FUIPeZ7ssitYw::S3 : FUIPeZ7ssitYw::LOCAL);
        goto RREIP;
        tRJTd:
        if (!$zvcov instanceof SingleUploadInterface) {
            goto P796p;
        }
        goto O0b9I;
        TVzxa:
        return $this->mF9BEBqnjrF($igdgs->extension(), FUIPeZ7ssitYw::S3, null, $zvcov->options());
        goto a8fQq;
        O0b9I:
        $igdgs = $zvcov->getFile();
        goto TVzxa;
        a8fQq:
        P796p:
        goto a5cdJ;
        RREIP:
    }
    public function mGWQRgYK3NA(string $IaHim)
    {
        goto HALFJ;
        aZ3Pe:
        return $QuYzZ;
        goto TZE_X;
        j8E0g:
        $QuYzZ->exists = true;
        goto kY_t3;
        HALFJ:
        $qW6LM = config('upload.attachment_model')::findOrFail($IaHim);
        goto sLk6a;
        kY_t3:
        $QuYzZ->setRawAttributes($qW6LM->getAttributes());
        goto aZ3Pe;
        sLk6a:
        $QuYzZ = $this->mF9BEBqnjrF($qW6LM->getAttribute('type'), $qW6LM->getAttribute('driver'), $qW6LM->getAttribute('id'));
        goto j8E0g;
        TZE_X:
    }
    public function mZxcNvu3WfY(string $omEdT) : JGFha5eJXVoQK
    {
        goto qvBfo;
        xq3eW:
        Aq265:
        goto R5rB8;
        zXguf:
        if (!$szNd7) {
            goto Aq265;
        }
        goto cP6As;
        uFE5Y:
        dRvBR:
        goto cHz5R;
        cHz5R:
        $szNd7 = json_decode($noBGd, true);
        goto zXguf;
        biUKv:
        if ($noBGd) {
            goto dRvBR;
        }
        goto OqOi_;
        cP6As:
        $Y9KWX = ZQCRUoYnm7ASE::mFWPQDqpxn6($szNd7);
        goto fW7BP;
        R5rB8:
        throw new DbtXptYiNGheI('metadata file not found');
        goto g3El1;
        fW7BP:
        return $this->mF9BEBqnjrF($Y9KWX->le4b_, $Y9KWX->mU0MQafHL2j(), $Y9KWX->filename);
        goto xq3eW;
        qvBfo:
        $noBGd = $this->bX3fI->get($omEdT);
        goto biUKv;
        OqOi_:
        $noBGd = $this->auR_S->get($omEdT);
        goto uFE5Y;
        g3El1:
    }
    private function mF9BEBqnjrF(string $uXg0E, $PEPwf, ?string $IaHim = null, array $KKAWP = [])
    {
        goto gTQYC;
        oQbdw:
        $QxF3a->mubjGF8zmdt(new FhPHJXipLxQC9($QxF3a));
        goto rQq5n;
        wZ2kN:
        foreach ($this->SBuSg as $cEpkz) {
            goto Nylu9;
            oItM6:
            return $QxF3a->initLocation($cEpkz->mJcSQ1v4tEu($QxF3a));
            goto OpQcX;
            Nylu9:
            if (!$cEpkz->m6o9uHdan7v($QxF3a)) {
                goto nU133;
            }
            goto oItM6;
            OpQcX:
            nU133:
            goto c_xow;
            c_xow:
            QEXKg:
            goto fR3d1;
            fR3d1:
        }
        goto P89N3;
        rQq5n:
        $QxF3a->mubjGF8zmdt(new IASUYv8MKeNRq($QxF3a, $this->auR_S, $KKAWP));
        goto wZ2kN;
        C4vSs:
        switch ($uXg0E) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $QxF3a = FNGNxcyxjaxBG::createFromScratch($IaHim, $uXg0E);
                goto zJ_u5;
            case 'mp4':
            case 'mov':
                $QxF3a = ACdpgX4YCYP6M::createFromScratch($IaHim, $uXg0E);
                goto zJ_u5;
            case 'pdf':
                $QxF3a = TXSCPefqEsBH1::createFromScratch($IaHim, $uXg0E);
                goto zJ_u5;
            default:
                throw new KkJ7iB3slsUjq("not support file type {$uXg0E}");
        }
        goto MVMf8;
        R1fhF:
        throw new KkJ7iB3slsUjq("not support file type {$uXg0E}");
        goto eFSk9;
        GMyEk:
        $QxF3a = $QxF3a->mIbNz0PKhyF($PEPwf);
        goto oQbdw;
        P89N3:
        Jy1Pd:
        goto R1fhF;
        MVMf8:
        azL5K:
        goto Aj9IE;
        Aj9IE:
        zJ_u5:
        goto GMyEk;
        gTQYC:
        $IaHim = $IaHim ?? Uuid::uuid4()->getHex()->toString();
        goto C4vSs;
        eFSk9:
    }
}
