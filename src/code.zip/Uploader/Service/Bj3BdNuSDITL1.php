<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\TmESz0lUHO033;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Jfs\Uploader\Exception\RRyzFa9lvheK9;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Exception\GNBoSRgkmhvfn;
use Jfs\Uploader\Service\SLO5cl2ibvGWu;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Bj3BdNuSDITL1 implements UploadServiceInterface
{
    private $X0zGy;
    private $hYphi;
    private $DtvHw;
    private $GP7Ww;
    public function __construct(SLO5cl2ibvGWu $Avitm, Filesystem $zuNM5, Filesystem $S3rMg, string $mLK01)
    {
        goto WEp1H;
        WEp1H:
        $this->X0zGy = $Avitm;
        goto YS_Ha;
        YS_Ha:
        $this->hYphi = $zuNM5;
        goto N4tpb;
        DPbFE:
        $this->GP7Ww = $mLK01;
        goto B3Zsa;
        N4tpb:
        $this->DtvHw = $S3rMg;
        goto DPbFE;
        B3Zsa:
    }
    public function storeSingleFile(SingleUploadInterface $Eg7U0) : array
    {
        goto NYvSf;
        XRFrZ:
        if (false !== $D4enG && $VslFR instanceof WHyfIbzEzUFEe) {
            goto jCLta;
        }
        goto Qy08c;
        SZ7xj:
        goto tJaRN;
        goto rROoi;
        oDEEX:
        $D4enG = $this->DtvHw->putFileAs(dirname($VslFR->getLocation()), $Eg7U0->getFile(), $VslFR->getFilename() . '.' . $VslFR->getExtension(), ['visibility' => 'public']);
        goto XRFrZ;
        dY82J:
        $VslFR->m6ASJ5S5Ktp(T93Mcsw1gA3an::UPLOADED);
        goto GKnpW;
        Qy08c:
        throw new \LogicException('File upload failed, check permissions');
        goto SZ7xj;
        rROoi:
        jCLta:
        goto dY82J;
        E0zML:
        return $VslFR->getView();
        goto RF4ti;
        NYvSf:
        $VslFR = $this->X0zGy->mPQtt4SML7U($Eg7U0);
        goto oDEEX;
        GKnpW:
        tJaRN:
        goto E0zML;
        RF4ti:
    }
    public function storePreSignedFile(array $K63ET)
    {
        goto tQvh2;
        zPGUV:
        return ['filename' => $X318G->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $X318G->mrYymiL7sqz()];
        goto DblWp;
        zZLGy:
        $X318G->mjFzSbhVEvi($K63ET['mime'], $K63ET['file_size'], $K63ET['chunk_size'], $K63ET['checksums'], $K63ET['user_id'], $K63ET['driver']);
        goto gJY63;
        q0Y2g:
        $X318G = TmESz0lUHO033::meJnQ0MYaF2($VslFR, $this->hYphi, $this->DtvHw, $this->GP7Ww, true);
        goto zZLGy;
        gJY63:
        $X318G->mmsgjSZc6hq();
        goto zPGUV;
        tQvh2:
        $VslFR = $this->X0zGy->mPQtt4SML7U($K63ET);
        goto q0Y2g;
        DblWp:
    }
    public function updatePreSignedFile(string $J7quw, int $F0JXA)
    {
        goto p9SWI;
        Fczoj:
        switch ($F0JXA) {
            case T93Mcsw1gA3an::UPLOADED:
                $X318G->mq97dowG195();
                goto NRM7q;
            case T93Mcsw1gA3an::PROCESSING:
                $X318G->mgcQEZj794T();
                goto NRM7q;
            case T93Mcsw1gA3an::FINISHED:
                $X318G->mQiWiRCpHOL();
                goto NRM7q;
            case T93Mcsw1gA3an::ABORTED:
                $X318G->mYIhZteZDyD();
                goto NRM7q;
        }
        goto PIZPJ;
        p9SWI:
        $X318G = TmESz0lUHO033::mtugZzzj6Hx($J7quw, $this->hYphi, $this->DtvHw, $this->GP7Ww);
        goto Fczoj;
        Iskis:
        NRM7q:
        goto UH659;
        PIZPJ:
        jiQcZ:
        goto Iskis;
        UH659:
    }
    public function completePreSignedFile(string $J7quw, array $jOnpR)
    {
        goto OmyLC;
        c1b1k:
        $X318G->miyJ5feZwpY()->mzTDXTOmD3o($jOnpR);
        goto VMFTQ;
        OmyLC:
        $X318G = TmESz0lUHO033::mtugZzzj6Hx($J7quw, $this->hYphi, $this->DtvHw, $this->GP7Ww);
        goto c1b1k;
        WF6_J:
        return ['path' => $X318G->getFile()->getView()['path'], 'thumbnail' => $X318G->getFile()->Lkzkq, 'id' => $J7quw];
        goto IGona;
        VMFTQ:
        $X318G->mq97dowG195();
        goto WF6_J;
        IGona:
    }
    public function updateFile(string $J7quw, int $F0JXA) : J9AcMiQKgpvel
    {
        goto hGgzs;
        hGgzs:
        $VslFR = $this->X0zGy->mWHA2SKypE0($J7quw);
        goto zGF47;
        pn2Fd:
        return $VslFR;
        goto Y1TAM;
        zGF47:
        $VslFR->m6ASJ5S5Ktp($F0JXA);
        goto pn2Fd;
        Y1TAM:
    }
}
