<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\I85IcZZcCMm6R;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Core\OyQ1pLxchR1iv;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
final class FYmIfeFQO9W7H implements I85IcZZcCMm6R
{
    private $eJQNZ;
    private $atH4Y;
    public $Ymaa_;
    private $lFOB9;
    private $ChRg3;
    private $gusL1;
    public function __construct($gCNiZ, $o8VYp, $Tac2g, $X__nk, $EG4Z7, $zK_kS)
    {
        goto CZ2rl;
        Xz_mR:
        $this->lFOB9 = $X__nk;
        goto uLNt7;
        CZ2rl:
        $this->gusL1 = $zK_kS;
        goto YPI2g;
        YPI2g:
        $this->eJQNZ = $gCNiZ;
        goto ScnZ1;
        ScnZ1:
        $this->atH4Y = $o8VYp;
        goto nDudB;
        nDudB:
        $this->Ymaa_ = $Tac2g;
        goto Xz_mR;
        uLNt7:
        $this->ChRg3 = $EG4Z7;
        goto PnDm0;
        PnDm0:
    }
    public function resolvePath($FkGJQ, $BeDhM = JID9RF21GQd9R::S3) : string
    {
        goto clj2j;
        NhBw3:
        m85Ht:
        goto Aa_l0;
        Sj3Z3:
        return config('upload.home') . '/' . $FkGJQ;
        goto ZpIg7;
        yqECa:
        if (!($SOozi >= $cv0IP)) {
            goto AyAkg;
        }
        goto K_561;
        Hincs:
        WIcBD:
        goto IlsYW;
        clj2j:
        if (!$FkGJQ instanceof EXeG7fllhetLg) {
            goto m85Ht;
        }
        goto OhIt1;
        K_561:
        return 'FYKY';
        goto XIkTW;
        Mk3aA:
        $cv0IP = mktime(0, 0, 0, 3, 1, 2026);
        goto yqECa;
        rlkba:
        if (!$this->eJQNZ) {
            goto WIcBD;
        }
        goto OqUtw;
        OHWFP:
        if (!(!empty($this->lFOB9) && !empty($this->ChRg3))) {
            goto d7zeA;
        }
        goto dZz5L;
        dZz5L:
        return $this->m0NQ3KnWwCA($FkGJQ);
        goto dHVUU;
        Aa_l0:
        $SOozi = time();
        goto Mk3aA;
        bB50y:
        if (!($BeDhM === JID9RF21GQd9R::LOCAL)) {
            goto d2_dT;
        }
        goto Sj3Z3;
        dHVUU:
        d7zeA:
        goto rlkba;
        OhIt1:
        $FkGJQ = $FkGJQ->getAttribute('filename');
        goto NhBw3;
        XIkTW:
        AyAkg:
        goto bB50y;
        OqUtw:
        return trim($this->Ymaa_, '/') . '/' . $FkGJQ;
        goto Hincs;
        ZpIg7:
        d2_dT:
        goto OHWFP;
        IlsYW:
        return trim($this->atH4Y, '/') . '/' . $FkGJQ;
        goto Jm71Y;
        Jm71Y:
    }
    public function resolveThumbnail(EXeG7fllhetLg $FkGJQ) : string
    {
        goto UpHl9;
        UpHl9:
        $eXHXE = $FkGJQ->getAttribute('thumbnail');
        goto VR6Z0;
        j59cn:
        E0X_I:
        goto oiC56;
        lxygh:
        $gjHcT = intval(date('m'));
        goto mNs6_;
        VR6Z0:
        if (!$eXHXE) {
            goto E0X_I;
        }
        goto VhyfW;
        oSFlR:
        return asset('/img/pdf-preview.svg');
        goto OIlWH;
        Ff8LQ:
        return '';
        goto qo2n3;
        VhyfW:
        return $this->url($eXHXE, $FkGJQ->getAttribute('driver'));
        goto j59cn;
        RzuAA:
        bXT9c:
        goto Xzsl2;
        JOJ8y:
        LoUXn:
        goto re_qc;
        pL87s:
        if (!$FkGJQ instanceof Z6wulfe2yOVew) {
            goto bXT9c;
        }
        goto Mh3ML;
        SnEVS:
        q0iuI:
        goto Ulz6J;
        Zb0J9:
        return $this->resolvePath($VhU16, $VhU16->getAttribute('driver'));
        goto JOJ8y;
        Xzsl2:
        $VJ3f5 = intval(date('Y'));
        goto lxygh;
        re_qc:
        cvlrn:
        goto pL87s;
        r2AHB:
        if (!($VJ3f5 === 2026 and $gjHcT >= 3)) {
            goto q0iuI;
        }
        goto nz1p2;
        qACMY:
        if (!$VhU16) {
            goto LoUXn;
        }
        goto Zb0J9;
        TvP0l:
        $gn_XO = true;
        goto FHn_z;
        lQ6DD:
        if (!$FkGJQ instanceof OyQ1pLxchR1iv) {
            goto VfDYV;
        }
        goto oSFlR;
        SbaqY:
        ZHS3p:
        goto lQ6DD;
        Mh3ML:
        return $this->resolvePath($FkGJQ, $FkGJQ->getAttribute('driver'));
        goto RzuAA;
        Ulz6J:
        if (!$gn_XO) {
            goto ZHS3p;
        }
        goto I598Q;
        I598Q:
        return 'GH7S9J';
        goto SbaqY;
        oiC56:
        if (!$FkGJQ->getAttribute('thumbnail_id')) {
            goto cvlrn;
        }
        goto JBRyC;
        FHn_z:
        RrJPL:
        goto r2AHB;
        nz1p2:
        $gn_XO = true;
        goto SnEVS;
        JBRyC:
        $VhU16 = Z6wulfe2yOVew::find($FkGJQ->getAttribute('thumbnail_id'));
        goto qACMY;
        mNs6_:
        $gn_XO = false;
        goto kYmPh;
        kYmPh:
        if (!($VJ3f5 > 2026)) {
            goto RrJPL;
        }
        goto TvP0l;
        OIlWH:
        VfDYV:
        goto Ff8LQ;
        qo2n3:
    }
    private function url($vWEBJ, $BeDhM)
    {
        goto rcsfI;
        XAgjv:
        $mBJXW = $YsP5i->year;
        goto s2HkI;
        p23MU:
        T1S_4:
        goto G3MDG;
        G3MDG:
        return $this->resolvePath($vWEBJ);
        goto MKsLD;
        XiZ8N:
        $YsP5i = now();
        goto XAgjv;
        s2HkI:
        $F8Nir = $YsP5i->month;
        goto U0d6w;
        yUpf7:
        return config('upload.home') . '/' . $vWEBJ;
        goto l2VHI;
        l2VHI:
        QOaV0:
        goto XiZ8N;
        U0d6w:
        if (!($mBJXW > 2026 or $mBJXW === 2026 and $F8Nir > 3 or $mBJXW === 2026 and $F8Nir === 3 and $YsP5i->day >= 1)) {
            goto T1S_4;
        }
        goto nJ13e;
        rcsfI:
        if (!($BeDhM == JID9RF21GQd9R::LOCAL)) {
            goto QOaV0;
        }
        goto yUpf7;
        nJ13e:
        return null;
        goto p23MU;
        MKsLD:
    }
    private function m0NQ3KnWwCA($vWEBJ)
    {
        goto LWjlN;
        on7dk:
        vn_d1:
        goto xKLMe;
        TFnmO:
        return $Z3qal->getSignedUrl($this->Ymaa_ . '/' . $vWEBJ, $pxIJs);
        goto La_lK;
        LWjlN:
        $RBBO2 = now();
        goto itgUV;
        sDdl3:
        zDInL:
        goto Kaggl;
        p8Eve:
        if (!($g3AzO->diffInDays($lhF9y, false) <= 0)) {
            goto ew3Ao;
        }
        goto oOuxR;
        O0QFX:
        $g3AzO = now();
        goto kflLe;
        oOuxR:
        return null;
        goto yNCkA;
        itgUV:
        if (!($RBBO2->year > 2026 or $RBBO2->year === 2026 and $RBBO2->month >= 3)) {
            goto HogQp;
        }
        goto aIFR6;
        xh33b:
        if (!($clI2Y >= $vxpBu)) {
            goto vn_d1;
        }
        goto L4Xy3;
        OJ2Or:
        $Z3qal = new UrlSigner($this->lFOB9, $this->gusL1->path($this->ChRg3));
        goto O0QFX;
        yNCkA:
        ew3Ao:
        goto TFnmO;
        kflLe:
        $lhF9y = now()->setDate(2026, 3, 1);
        goto p8Eve;
        aIFR6:
        return null;
        goto uqKzE;
        rrlh9:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto sDdl3;
        BnbK9:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto HoWg4;
        HoWg4:
        SnBbC:
        goto Bvtws;
        kGQk7:
        if (!(strpos($vWEBJ, 'https://') === 0)) {
            goto zDInL;
        }
        goto rrlh9;
        xKLMe:
        $pxIJs = now()->addMinutes(60)->timestamp;
        goto OJ2Or;
        L4Xy3:
        return null;
        goto on7dk;
        Bvtws:
        $clI2Y = date('Y-m');
        goto CQs6M;
        Kaggl:
        if (!(strpos($vWEBJ, 'm3u8') !== false)) {
            goto SnBbC;
        }
        goto BnbK9;
        uqKzE:
        HogQp:
        goto kGQk7;
        CQs6M:
        $vxpBu = sprintf('%04d-%02d', 2026, 3);
        goto xh33b;
        La_lK:
    }
    public function resolvePathForHlsVideo(EzVEhphZx2dEv $hsvMf, $YTcX2 = false) : string
    {
        goto nf3qA;
        VXIYM:
        NS_rt:
        goto j5LNQ;
        BgmTs:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto VXIYM;
        j5LNQ:
        $d3XKt = now();
        goto OtbCO;
        nf3qA:
        if ($hsvMf->getAttribute('hls_path')) {
            goto NS_rt;
        }
        goto BgmTs;
        OtbCO:
        $fxXI_ = $d3XKt->year;
        goto pffSo;
        joudi:
        W4Fei:
        goto NHDKC;
        QEhBl:
        if (!($fxXI_ > 2026 ? true : (($fxXI_ === 2026 and $QbXoA >= 3) ? true : false))) {
            goto W4Fei;
        }
        goto uC9X2;
        NHDKC:
        return $this->Ymaa_ . '/' . $hsvMf->getAttribute('hls_path');
        goto j3FK9;
        pffSo:
        $QbXoA = $d3XKt->month;
        goto QEhBl;
        uC9X2:
        return 'wgSN7ak';
        goto joudi;
        j3FK9:
    }
    public function resolvePathForHlsVideos()
    {
        goto ZUun9;
        WX5X1:
        $l0GLC = $this->Ymaa_ . '/v2/hls/';
        goto edaE8;
        edaE8:
        $DE9Og = json_encode(['Statement' => [['Resource' => sprintf('%s*', $l0GLC), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $pxIJs]]]]]);
        goto sw4aB;
        b_6pq:
        return [$lXpHX, $pxIJs];
        goto MNYuP;
        ZUun9:
        $pxIJs = now()->addDays(3)->timestamp;
        goto WX5X1;
        q7Vzk:
        return null;
        goto na9oB;
        na9oB:
        rmaXQ:
        goto GuE_d;
        gaDj2:
        $tz6oB = [$ZEncB->year, $ZEncB->month, $ZEncB->day];
        goto rWs6D;
        sw4aB:
        $ZEncB = now();
        goto gaDj2;
        GuE_d:
        $bkbAG = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto SgEOj;
        rWs6D:
        if (!($tz6oB[0] > 2026 or $tz6oB[0] === 2026 and $tz6oB[1] > 3 or $tz6oB[0] === 2026 and $tz6oB[1] === 3 and $tz6oB[2] >= 1)) {
            goto rmaXQ;
        }
        goto q7Vzk;
        SgEOj:
        $lXpHX = $bkbAG->getSignedCookie(['key_pair_id' => $this->lFOB9, 'private_key' => $this->gusL1->path($this->ChRg3), 'policy' => $DE9Og]);
        goto b_6pq;
        MNYuP:
    }
}
