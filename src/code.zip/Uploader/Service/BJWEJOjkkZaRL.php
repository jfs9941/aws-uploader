<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Illuminate\Contracts\Filesystem\Filesystem;
final class BJWEJOjkkZaRL
{
    private $PoRf3;
    private $eWuWD;
    private $SIeOC;
    public function __construct(string $L2yxk, string $F0uQn, Filesystem $Ay4fJ)
    {
        goto Q8y40;
        dP5Xy:
        $this->SIeOC = $Ay4fJ;
        goto TkAOh;
        Xnulm:
        $this->eWuWD = $F0uQn;
        goto dP5Xy;
        Q8y40:
        $this->PoRf3 = $L2yxk;
        goto Xnulm;
        TkAOh:
    }
    public function mE3sPw9l2cH(IeEvjRaj1LMmG $UmLJ2) : string
    {
        goto lmpm5;
        OaKeo:
        gRcs8:
        goto ItBoH;
        ItBoH:
        return $this->SIeOC->url($UmLJ2->getAttribute('filename'));
        goto Xu8Rt;
        USm9R:
        return 's3://' . $this->PoRf3 . '/' . $UmLJ2->getAttribute('filename');
        goto OaKeo;
        lmpm5:
        if (!(YJGCddWUf6Zu2::S3 == $UmLJ2->getAttribute('driver'))) {
            goto gRcs8;
        }
        goto USm9R;
        Xu8Rt:
    }
    public function mB1slIfbYNS(?string $NTSvS) : ?string
    {
        goto B00Pu;
        cE6tm:
        qpAvI:
        goto vpw_Y;
        p7D2w:
        if (!str_contains($NTSvS, $this->PoRf3)) {
            goto qpAvI;
        }
        goto agbUe;
        agbUe:
        $hKqqZ = parse_url($NTSvS, PHP_URL_PATH);
        goto utr6J;
        B00Pu:
        if (!$NTSvS) {
            goto womK3;
        }
        goto p7D2w;
        vpw_Y:
        womK3:
        goto vzF4P;
        vzF4P:
        return null;
        goto dF76E;
        utr6J:
        return 's3://' . $this->PoRf3 . '/' . ltrim($hKqqZ, '/');
        goto cE6tm;
        dF76E:
    }
    public function m544f5UHTMS(string $hKqqZ) : string
    {
        return 's3://' . $this->PoRf3 . '/' . $hKqqZ;
    }
}
