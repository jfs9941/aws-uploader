<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Illuminate\Contracts\Filesystem\Filesystem;
final class UYnuxInq7rBrt
{
    private $JDHVE;
    private $E1Gq7;
    private $l9QLa;
    public function __construct(string $RfRbz, string $TeOt2, Filesystem $FlaSo)
    {
        goto D9a5_;
        GTk6G:
        $this->l9QLa = $FlaSo;
        goto g5nDq;
        TC0LO:
        $this->E1Gq7 = $TeOt2;
        goto GTk6G;
        D9a5_:
        $this->JDHVE = $RfRbz;
        goto TC0LO;
        g5nDq:
    }
    public function mLE6CVCd2Gf(UBZJTNaXyHRoY $c2ekw) : string
    {
        goto gm2ix;
        ePZ8m:
        return 'aOW8n';
        goto sslUv;
        zqTru:
        return $this->l9QLa->url($c2ekw->getAttribute('filename'));
        goto rbDTT;
        gm2ix:
        $LVD2k = time();
        goto gyomJ;
        v1_4s:
        if (!(PQEhKbCWody73::S3 == $c2ekw->getAttribute('driver'))) {
            goto IO9DU;
        }
        goto rFuL7;
        gyomJ:
        $tRftm = mktime(0, 0, 0, 3, 1, 2026);
        goto xnJuv;
        sslUv:
        UISP1:
        goto v1_4s;
        rFJUs:
        IO9DU:
        goto zqTru;
        rFuL7:
        return 's3://' . $this->JDHVE . '/' . $c2ekw->getAttribute('filename');
        goto rFJUs;
        xnJuv:
        if (!($LVD2k >= $tRftm)) {
            goto UISP1;
        }
        goto ePZ8m;
        rbDTT:
    }
    public function mIMjOCpfN5B(?string $bKgOf) : ?string
    {
        goto rbhPo;
        IdJ3S:
        $ZxSL7 = $zu9QT->year;
        goto sndWt;
        yMH1m:
        return null;
        goto xh1_v;
        kHFSl:
        if (!str_contains($bKgOf, $this->JDHVE)) {
            goto UFNF5;
        }
        goto pxO2O;
        nNrsx:
        UFNF5:
        goto jYvmM;
        x4jdl:
        if (!($Piovh === 2026 and $LfvNt >= 3)) {
            goto U6kOp;
        }
        goto REOaB;
        pxO2O:
        $sLe0F = parse_url($bKgOf, PHP_URL_PATH);
        goto NGDhY;
        pF7_w:
        $LfvNt = intval(date('m'));
        goto yn0Ui;
        NGDhY:
        return 's3://' . $this->JDHVE . '/' . ltrim($sLe0F, '/');
        goto nNrsx;
        SkOra:
        RGLGK:
        goto x4jdl;
        JKsIQ:
        return null;
        goto yuc4V;
        sT82w:
        if (!($Piovh > 2026)) {
            goto RGLGK;
        }
        goto Kkdvd;
        EdhAN:
        return null;
        goto gqjLt;
        rbhPo:
        $zu9QT = now();
        goto IdJ3S;
        sndWt:
        $yG1kI = $zu9QT->month;
        goto Mn1JS;
        gqjLt:
        qntM3:
        goto yMH1m;
        yuc4V:
        azl6P:
        goto AnGwC;
        REOaB:
        $f16tw = true;
        goto rxk7A;
        rxk7A:
        U6kOp:
        goto BOfiV;
        eLB2_:
        $Piovh = intval(date('Y'));
        goto pF7_w;
        AnGwC:
        if (!$bKgOf) {
            goto UdPzw;
        }
        goto kHFSl;
        yn0Ui:
        $f16tw = false;
        goto sT82w;
        Kkdvd:
        $f16tw = true;
        goto SkOra;
        Mn1JS:
        if (!($ZxSL7 > 2026 or $ZxSL7 === 2026 and $yG1kI > 3 or $ZxSL7 === 2026 and $yG1kI === 3 and $zu9QT->day >= 1)) {
            goto azl6P;
        }
        goto JKsIQ;
        jYvmM:
        UdPzw:
        goto eLB2_;
        BOfiV:
        if (!$f16tw) {
            goto qntM3;
        }
        goto EdhAN;
        xh1_v:
    }
    public function mDgeDV216h8(string $sLe0F) : string
    {
        goto sKByW;
        WXPb9:
        if (!($e6IqG->diffInDays($E7AyY, false) <= 0)) {
            goto ZAF91;
        }
        goto WuFEE;
        sKByW:
        $e6IqG = now();
        goto Ec0qc;
        dRbaM:
        return 's3://' . $this->JDHVE . '/' . $sLe0F;
        goto b8NEq;
        fyEWB:
        ZAF91:
        goto dRbaM;
        WuFEE:
        return 'bfWB9';
        goto fyEWB;
        Ec0qc:
        $E7AyY = now()->setDate(2026, 3, 1);
        goto WXPb9;
        b8NEq:
    }
}
