<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\K0dipGcxtVboz;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Core\QJ9aA37t27inE;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
final class FiQYSbwR1Ly8I implements K0dipGcxtVboz
{
    private $AlAG_;
    private $MvJk5;
    public $tv4c_;
    private $thCJ_;
    private $gebLK;
    private $Ntit8;
    public function __construct($uylxa, $xBfMV, $UcSdO, $JbQF2, $ebaH0, $MYg0D)
    {
        goto HsVOe;
        YKitJ:
        $this->MvJk5 = $xBfMV;
        goto pnG46;
        R4Wsl:
        $this->AlAG_ = $uylxa;
        goto YKitJ;
        pnG46:
        $this->tv4c_ = $UcSdO;
        goto g3M9w;
        g3M9w:
        $this->thCJ_ = $JbQF2;
        goto wBgc1;
        HsVOe:
        $this->Ntit8 = $MYg0D;
        goto R4Wsl;
        wBgc1:
        $this->gebLK = $ebaH0;
        goto jpgeA;
        jpgeA:
    }
    public function resolvePath($Nb_Od, $uV7lV = Opdj0uZXaMJfa::S3) : string
    {
        goto XhMUU;
        F_CG2:
        EIFn9:
        goto bKM6v;
        b2Bu8:
        JE0qH:
        goto HvG1b;
        XhMUU:
        if (!$Nb_Od instanceof NRDoWGrbd9WhU) {
            goto JE0qH;
        }
        goto PTZS1;
        LojIx:
        CEdgA:
        goto jhYAU;
        hIYWV:
        if (!(!empty($this->thCJ_) && !empty($this->gebLK))) {
            goto EIFn9;
        }
        goto xAO2b;
        BHXsx:
        return config('upload.home') . '/' . $Nb_Od;
        goto Bp3gE;
        xAO2b:
        return $this->mN2Gc1OuBWQ($Nb_Od);
        goto F_CG2;
        cog9F:
        return trim($this->tv4c_, '/') . '/' . $Nb_Od;
        goto LojIx;
        HvG1b:
        if (!($uV7lV === Opdj0uZXaMJfa::LOCAL)) {
            goto efnV4;
        }
        goto BHXsx;
        bKM6v:
        if (!$this->AlAG_) {
            goto CEdgA;
        }
        goto cog9F;
        PTZS1:
        $Nb_Od = $Nb_Od->getAttribute('filename');
        goto b2Bu8;
        jhYAU:
        return trim($this->MvJk5, '/') . '/' . $Nb_Od;
        goto yd28E;
        Bp3gE:
        efnV4:
        goto hIYWV;
        yd28E:
    }
    public function resolveThumbnail(NRDoWGrbd9WhU $Nb_Od) : string
    {
        goto ORvTR;
        sEVKB:
        if (!$Nb_Od->getAttribute('thumbnail_id')) {
            goto vZSiE;
        }
        goto T6PjE;
        PWE8G:
        if (!$n_Bq7) {
            goto m53KC;
        }
        goto cqZ_j;
        ORvTR:
        $dZvCS = $Nb_Od->getAttribute('thumbnail');
        goto ntMtj;
        KjclZ:
        if (!$Nb_Od instanceof QJ9aA37t27inE) {
            goto ntHcu;
        }
        goto aTaP3;
        XMPgC:
        ntHcu:
        goto EHa7Z;
        T6PjE:
        $n_Bq7 = S7LEoIprYtLQw::find($Nb_Od->getAttribute('thumbnail_id'));
        goto PWE8G;
        NM7Cw:
        return $this->url($dZvCS, $Nb_Od->getAttribute('driver'));
        goto u1Cgr;
        bF7Hm:
        return $this->resolvePath($Nb_Od, $Nb_Od->getAttribute('driver'));
        goto EnF27;
        u1Cgr:
        tUpUP:
        goto sEVKB;
        EHa7Z:
        return '';
        goto wqh7l;
        aTaP3:
        return asset('/img/pdf-preview.svg');
        goto XMPgC;
        Ilf7A:
        vZSiE:
        goto uV46X;
        cqZ_j:
        return $this->resolvePath($n_Bq7, $n_Bq7->getAttribute('driver'));
        goto SHNtF;
        uV46X:
        if (!$Nb_Od instanceof S7LEoIprYtLQw) {
            goto U13Q6;
        }
        goto bF7Hm;
        SHNtF:
        m53KC:
        goto Ilf7A;
        EnF27:
        U13Q6:
        goto KjclZ;
        ntMtj:
        if (!$dZvCS) {
            goto tUpUP;
        }
        goto NM7Cw;
        wqh7l:
    }
    private function url($lxbX3, $uV7lV)
    {
        goto fQ3FD;
        JiK5F:
        return config('upload.home') . '/' . $lxbX3;
        goto rErnT;
        rErnT:
        fnnml:
        goto Oayl8;
        Oayl8:
        return $this->resolvePath($lxbX3);
        goto ZKb03;
        fQ3FD:
        if (!($uV7lV == Opdj0uZXaMJfa::LOCAL)) {
            goto fnnml;
        }
        goto JiK5F;
        ZKb03:
    }
    private function mN2Gc1OuBWQ($lxbX3)
    {
        goto mGt_F;
        iSMvT:
        $bks07 = now()->addMinutes(60)->timestamp;
        goto LcTla;
        Ep5FN:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto OU33y;
        zsZPm:
        BmMaL:
        goto D5q_M;
        D5q_M:
        if (!(strpos($lxbX3, 'm3u8') !== false)) {
            goto kJTsr;
        }
        goto Ep5FN;
        wTTXO:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto zsZPm;
        OU33y:
        kJTsr:
        goto iSMvT;
        uADyI:
        return $l2PqQ->getSignedUrl($this->tv4c_ . '/' . $lxbX3, $bks07);
        goto q4ouC;
        mGt_F:
        if (!(strpos($lxbX3, 'https://') === 0)) {
            goto BmMaL;
        }
        goto wTTXO;
        LcTla:
        $l2PqQ = new UrlSigner($this->thCJ_, $this->Ntit8->path($this->gebLK));
        goto uADyI;
        q4ouC:
    }
    public function resolvePathForHlsVideo(RhSx2q5xIlh0Y $XFeNv, $e_9pG = false) : string
    {
        goto rSsHj;
        rSsHj:
        if ($XFeNv->getAttribute('hls_path')) {
            goto f59fJ;
        }
        goto c22ui;
        HE5nq:
        f59fJ:
        goto TtKJQ;
        c22ui:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto HE5nq;
        TtKJQ:
        return $this->tv4c_ . '/' . $XFeNv->getAttribute('hls_path');
        goto uzEpj;
        uzEpj:
    }
    public function resolvePathForHlsVideos()
    {
        goto jTe_m;
        GKtAm:
        $SIsCC = $MMQCM->getSignedCookie(['key_pair_id' => $this->thCJ_, 'private_key' => $this->Ntit8->path($this->gebLK), 'policy' => $mdypc]);
        goto m6tWZ;
        b2T0c:
        $YUNXT = $this->tv4c_ . '/v2/hls/';
        goto xynbc;
        vddG2:
        $MMQCM = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto GKtAm;
        m6tWZ:
        return [$SIsCC, $bks07];
        goto MaiWJ;
        jTe_m:
        $bks07 = now()->addDays(3)->timestamp;
        goto b2T0c;
        xynbc:
        $mdypc = json_encode(['Statement' => [['Resource' => sprintf('%s*', $YUNXT), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $bks07]]]]]);
        goto vddG2;
        MaiWJ:
    }
}
