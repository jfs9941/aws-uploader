<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
final class MEBayMa8o64NU implements VideoPostHandleServiceInterface
{
    private $huoeI;
    private $K79lK;
    public function __construct(UploadServiceInterface $r3kqP, Filesystem $yEBaZ)
    {
        $this->huoeI = $r3kqP;
        $this->K79lK = $yEBaZ;
    }
    public function saveMetadata(string $Qu08p, array $RHxcL)
    {
        goto KYZYh;
        khCsx:
        throw new \Exception("SmhkgG6le5p0r metadata store failed for unknown reason ... " . $Qu08p);
        goto qga_Z;
        IA7LA:
        $I0dvq['resolution'] = $RHxcL['resolution'];
        goto f0eCw;
        H2J7E:
        RwgDp:
        goto SPiKh;
        vXUtH:
        if (!$X0ufS->update($I0dvq)) {
            goto RwgDp;
        }
        goto Pps0I;
        qlo5x:
        $this->huoeI->updateFile($X0ufS->getAttribute('id'), OLX71luAn6XnP::PROCESSING);
        goto iNnz6;
        agZr2:
        bqHL1:
        goto a_Szj;
        CftVT:
        $I0dvq['duration'] = $RHxcL['duration'];
        goto agZr2;
        KYZYh:
        $X0ufS = SmhkgG6le5p0r::findOrFail($Qu08p);
        goto Gb_KD;
        kfjeA:
        if (!isset($RHxcL['thumbnail'])) {
            goto DmnTt;
        }
        goto TQpXx;
        kvsuE:
        $I0dvq['fps'] = $RHxcL['fps'];
        goto uDsTo;
        a_Szj:
        if (!isset($RHxcL['resolution'])) {
            goto jyNwn;
        }
        goto IA7LA;
        Pps0I:
        if (!(isset($RHxcL['change_status']) && $RHxcL['change_status'])) {
            goto LJsgo;
        }
        goto qlo5x;
        P2s72:
        if (!isset($RHxcL['fps'])) {
            goto DPATZ;
        }
        goto kvsuE;
        qkjs3:
        if (!isset($RHxcL['duration'])) {
            goto bqHL1;
        }
        goto CftVT;
        XGsmd:
        return $X0ufS->getView();
        goto H2J7E;
        TQpXx:
        try {
            goto p8jEa;
            p8jEa:
            $O8BOu = $this->huoeI->storeSingleFile(new class($RHxcL['thumbnail']) implements SingleUploadInterface
            {
                private $woTf1;
                public function __construct($oYtbp)
                {
                    $this->woTf1 = $oYtbp;
                }
                public function getFile()
                {
                    return $this->woTf1;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto epO3P;
            frBRV:
            $I0dvq['thumbnail'] = $O8BOu['filename'];
            goto lSAyL;
            epO3P:
            $I0dvq['thumbnail_id'] = $O8BOu['id'];
            goto frBRV;
            lSAyL:
        } catch (\Throwable $L1ZUQ) {
            Log::warning("SmhkgG6le5p0r thumbnail store failed: " . $L1ZUQ->getMessage());
        }
        goto G4kUr;
        uDsTo:
        DPATZ:
        goto vXUtH;
        iNnz6:
        LJsgo:
        goto XGsmd;
        f0eCw:
        jyNwn:
        goto P2s72;
        G4kUr:
        DmnTt:
        goto qkjs3;
        Gb_KD:
        $I0dvq = [];
        goto kfjeA;
        SPiKh:
        Log::warning("SmhkgG6le5p0r metadata store failed for unknown reason ... " . $Qu08p);
        goto khCsx;
        qga_Z:
    }
    public function createThumbnail(string $YC2e2) : void
    {
        goto PN8nR;
        p8DuV:
        if (!(!$this->K79lK->directoryExists($tinpi) && empty($X0ufS->mMRXnJUidzH()))) {
            goto sECO6;
        }
        goto G_iPK;
        G_iPK:
        $XG8kT = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto g03NZ;
        MLwZ9:
        sECO6:
        goto Y3hHO;
        P2L0K:
        $tinpi = "v2/hls/thumbnails/{$YC2e2}/";
        goto p8DuV;
        PN8nR:
        Log::info("Use Lambda to generate thumbnail for video: " . $YC2e2);
        goto lMv1W;
        g03NZ:
        try {
            goto k84oL;
            Bwxwn:
            $U2K2u = $zrALR->get('QueueUrl');
            goto wjHJ2;
            k84oL:
            $zrALR = $XG8kT->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto Bwxwn;
            wjHJ2:
            $XG8kT->sendMessage(['QueueUrl' => $U2K2u, 'MessageBody' => json_encode(['file_path' => $X0ufS->getLocation()])]);
            goto vDfXK;
            vDfXK:
        } catch (\Throwable $WZ5dZ) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$WZ5dZ->getMessage()}");
        }
        goto MLwZ9;
        lMv1W:
        $X0ufS = SmhkgG6le5p0r::findOrFail($YC2e2);
        goto P2L0K;
        Y3hHO:
    }
    public function mydGrAugjc2(string $YC2e2) : void
    {
        goto YGTvV;
        swkzY:
        Log::error("Message back with success data but not found thumbnail " . $YC2e2);
        goto mBLuL;
        ssiZa:
        Log::error("Message back with success data but not found thumbnail files " . $YC2e2);
        goto sOVYR;
        xRxvP:
        GhIVO:
        goto HIAqv;
        f3bm7:
        $tinpi = "v2/hls/thumbnails/{$YC2e2}/";
        goto fMFL9;
        sOVYR:
        throw new \Exception("Message back with success data but not found thumbnail files " . $YC2e2);
        goto APFAo;
        YGTvV:
        $X0ufS = SmhkgG6le5p0r::findOrFail($YC2e2);
        goto f3bm7;
        APFAo:
        lbVqW:
        goto Kk2qP;
        HIAqv:
        $lFYWw = $this->K79lK->files($tinpi);
        goto PaG5c;
        fMFL9:
        if ($this->K79lK->directoryExists($tinpi)) {
            goto GhIVO;
        }
        goto swkzY;
        Kk2qP:
        $X0ufS->update(['generated_previews' => $tinpi]);
        goto FhIb5;
        PaG5c:
        if (!(count($lFYWw) === 0)) {
            goto lbVqW;
        }
        goto ssiZa;
        mBLuL:
        throw new \Exception("Message back with success data but not found thumbnail " . $YC2e2);
        goto xRxvP;
        FhIb5:
    }
    public function getThumbnails(string $YC2e2) : array
    {
        $X0ufS = SmhkgG6le5p0r::findOrFail($YC2e2);
        return $X0ufS->getThumbnails();
    }
}
