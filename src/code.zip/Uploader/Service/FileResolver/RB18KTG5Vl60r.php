<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
interface RB18KTG5Vl60r
{
    public function mLafR2p9xTN(EmuD0NTRxtQv1 $AgDkH);
    public function mjBXkyALLd9(EmuD0NTRxtQv1 $AgDkH);
}
