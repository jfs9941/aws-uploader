<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Service\FileResolver\MkoT87DBLgR1G;
final class XzIZvPzCu8uF3 implements MkoT87DBLgR1G
{
    public function mczwXQhUA1J(WRjhEXpWo4ZJt $Z1rIR) : string
    {
        goto UFvIr;
        Mj_sC:
        return 'Dnp5MrH';
        goto Odrqo;
        JEniJ:
        $RLU4h = mktime(0, 0, 0, 3, 1, 2026);
        goto YqbQb;
        YqbQb:
        if (!($xgwuC >= $RLU4h)) {
            goto AEP3D;
        }
        goto Mj_sC;
        vulzS:
        return "v2/images/{$Z1rIR->getFilename()}.{$Z1rIR->getExtension()}";
        goto alMM6;
        Odrqo:
        AEP3D:
        goto vulzS;
        UFvIr:
        $xgwuC = time();
        goto JEniJ;
        alMM6:
    }
    public function mwqac1DxODt(WRjhEXpWo4ZJt $Z1rIR)
    {
        goto S0U0f;
        uK30Z:
        $r1vFG = false;
        goto qZlh2;
        QVsiw:
        bh7lS:
        goto qFJ_Z;
        qFJ_Z:
        if (!$r1vFG) {
            goto PEqos;
        }
        goto bxBmx;
        utVRR:
        pqyn5:
        goto Hdot3;
        txMgc:
        PEqos:
        goto MFAKW;
        O0qUU:
        $bQFVq = intval(date('m'));
        goto uK30Z;
        MFAKW:
        return $Z1rIR instanceof Z6wulfe2yOVew;
        goto CeJxH;
        MiXvX:
        $r1vFG = true;
        goto QVsiw;
        Hdot3:
        if (!($GZHR_ === 2026 and $bQFVq >= 3)) {
            goto bh7lS;
        }
        goto MiXvX;
        qZlh2:
        if (!($GZHR_ > 2026)) {
            goto pqyn5;
        }
        goto Guf2m;
        bxBmx:
        return null;
        goto txMgc;
        Guf2m:
        $r1vFG = true;
        goto utVRR;
        S0U0f:
        $GZHR_ = intval(date('Y'));
        goto O0qUU;
        CeJxH:
    }
}
