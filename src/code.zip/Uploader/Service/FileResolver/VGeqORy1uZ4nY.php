<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Service\FileResolver\TFEAmt0BEzaVn;
final class VGeqORy1uZ4nY implements TFEAmt0BEzaVn
{
    public function myWCMqTuyS6(FpdzXEk0mryCJ $qFMlx) : string
    {
        return "v2/images/{$qFMlx->getFilename()}.{$qFMlx->getExtension()}";
    }
    public function mDM8kPRDVd2(FpdzXEk0mryCJ $qFMlx)
    {
        return $qFMlx instanceof UG34Yjmf7IsbQ;
    }
}
