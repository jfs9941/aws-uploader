<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Service\FileResolver\Xy3vRB2WznbRN;
final class UfSGg88XxSQs2 implements Xy3vRB2WznbRN
{
    public function mt5gIDk9pzn(IN9Uizy4TAywx $Z5ydB) : string
    {
        return "v2/videos/{$Z5ydB->getFileName()}.{$Z5ydB->getExtension()}";
    }
    public function m5fbxzyNLYU(IN9Uizy4TAywx $Z5ydB)
    {
        return $Z5ydB instanceof UYo98bF5lKEmO;
    }
}
