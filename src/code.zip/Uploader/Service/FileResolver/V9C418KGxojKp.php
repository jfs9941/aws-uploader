<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
final class V9C418KGxojKp implements PmKs34zySAetJ
{
    public function mEuh2Srd8MD(DNmcAdktLJtqn $QxvEM) : string
    {
        return "v2/videos/{$QxvEM->getFileName()}.{$QxvEM->getExtension()}";
    }
    public function mDoiLw48pZs(DNmcAdktLJtqn $QxvEM)
    {
        return $QxvEM instanceof QdnSnf08v9RV7;
    }
}
