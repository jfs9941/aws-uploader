<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Service\FileResolver\H01EOIlyzOh6S;
final class GHCHb5QJKfdyT implements H01EOIlyzOh6S
{
    public function mvcG6A09lVY(WGN88W9AFumiX $s2INV) : string
    {
        return "v2/videos/{$s2INV->getFileName()}.{$s2INV->getExtension()}";
    }
    public function mrhZmHyyvU4(WGN88W9AFumiX $s2INV)
    {
        return $s2INV instanceof IfBHv1AJhiIDu;
    }
}
