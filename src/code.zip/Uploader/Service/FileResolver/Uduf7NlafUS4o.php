<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\JVAg1Gkd0EvTM;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Service\FileResolver\LBgBBJ5A98RMN;
final class Uduf7NlafUS4o implements LBgBBJ5A98RMN
{
    public function m3xAJz0xWf1(JVAg1Gkd0EvTM $YEF57) : string
    {
        return "v2/videos/{$YEF57->getFileName()}.{$YEF57->getExtension()}";
    }
    public function mug0hsvdBIy(JVAg1Gkd0EvTM $YEF57)
    {
        return $YEF57 instanceof JPkW9ix1EKo3T;
    }
}
