<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
final class RJnv1it5FKNoM implements DLulLsFkRdSfW
{
    public function mJcSQ1v4tEu(GYWdiuSbqNHgT $QuYzZ) : string
    {
        return "v2/videos/{$QuYzZ->getFileName()}.{$QuYzZ->getExtension()}";
    }
    public function m6o9uHdan7v(GYWdiuSbqNHgT $QuYzZ)
    {
        return $QuYzZ instanceof ACdpgX4YCYP6M;
    }
}
