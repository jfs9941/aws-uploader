<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\YeOKDEuyU49Av;
interface YlkMj7hiefpew
{
    public function mELOenBEMpO(YeOKDEuyU49Av $dV9QE);
    public function mBo2PjwPlax(YeOKDEuyU49Av $dV9QE);
}
