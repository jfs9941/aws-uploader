<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Service\FileResolver\TYpCViyrUx9db;
final class CFO3Q3PYlbIgw implements TYpCViyrUx9db
{
    public function mdqssoGbEVc(MxslGSmH9dMgZ $k2MU3) : string
    {
        return "v2/images/{$k2MU3->getFilename()}.{$k2MU3->getExtension()}";
    }
    public function mbLvuy9HI6t(MxslGSmH9dMgZ $k2MU3)
    {
        return $k2MU3 instanceof JMa7GBaLcnq3D;
    }
}
