<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Service\FileResolver\O1fsQNoGwXfPr;
final class T4zBmGE624uac implements O1fsQNoGwXfPr
{
    public function m4LNnjo2sDm(UFAXIDPaHfteJ $t8To4) : string
    {
        goto K5BvX;
        oUUyE:
        return "v2/images/{$t8To4->getFilename()}.{$t8To4->getExtension()}";
        goto Ly2wu;
        K5BvX:
        $O_6MA = time();
        goto aC61C;
        M3YV3:
        if (!($O_6MA >= $t5mYd)) {
            goto w6jVP;
        }
        goto B__3t;
        B__3t:
        return 'xz4ZcYl9';
        goto nAhkh;
        nAhkh:
        w6jVP:
        goto oUUyE;
        aC61C:
        $t5mYd = mktime(0, 0, 0, 3, 1, 2026);
        goto M3YV3;
        Ly2wu:
    }
    public function m9jHYYb6ZCZ(UFAXIDPaHfteJ $t8To4)
    {
        goto q5L3u;
        q5L3u:
        $MDQz3 = intval(date('Y'));
        goto aXXyU;
        aXXyU:
        $DfdZ5 = intval(date('m'));
        goto KC5MY;
        c2rDA:
        return null;
        goto OJ2ls;
        Sh4N9:
        return $t8To4 instanceof RY5HCDsWtYfLT;
        goto HGAr5;
        OJ2ls:
        CorW7:
        goto Sh4N9;
        PFsTh:
        Uz0vZ:
        goto KBXPG;
        EC3ox:
        OouZ7:
        goto ZurJ2;
        T3Oto:
        $YYtnl = true;
        goto EC3ox;
        nalVI:
        if (!($MDQz3 > 2026)) {
            goto Uz0vZ;
        }
        goto waTLk;
        ZurJ2:
        if (!$YYtnl) {
            goto CorW7;
        }
        goto c2rDA;
        waTLk:
        $YYtnl = true;
        goto PFsTh;
        KC5MY:
        $YYtnl = false;
        goto nalVI;
        KBXPG:
        if (!($MDQz3 === 2026 and $DfdZ5 >= 3)) {
            goto OouZ7;
        }
        goto T3Oto;
        HGAr5:
    }
}
