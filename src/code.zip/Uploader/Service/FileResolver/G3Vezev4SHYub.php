<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\XpjbCMtbhbQNm;
use Jfs\Uploader\Service\FileResolver\TYpCViyrUx9db;
final class G3Vezev4SHYub implements TYpCViyrUx9db
{
    public function mdqssoGbEVc(MxslGSmH9dMgZ $k2MU3) : string
    {
        return "v2/pdfs/{$k2MU3->getFileName()}.{$k2MU3->getExtension()}";
    }
    public function mbLvuy9HI6t(MxslGSmH9dMgZ $k2MU3)
    {
        return $k2MU3 instanceof XpjbCMtbhbQNm;
    }
}
