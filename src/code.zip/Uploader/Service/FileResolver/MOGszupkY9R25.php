<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\QJ9aA37t27inE;
use Jfs\Uploader\Service\FileResolver\MSiFUZOGwRG6e;
final class MOGszupkY9R25 implements MSiFUZOGwRG6e
{
    public function mb8NmWrIddR(BTuo2UPlpfSoS $FJFJj) : string
    {
        return "v2/pdfs/{$FJFJj->getFileName()}.{$FJFJj->getExtension()}";
    }
    public function mQroel6wQ9R(BTuo2UPlpfSoS $FJFJj)
    {
        return $FJFJj instanceof QJ9aA37t27inE;
    }
}
