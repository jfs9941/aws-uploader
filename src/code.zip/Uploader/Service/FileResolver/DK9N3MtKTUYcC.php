<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Service\FileResolver\UTeyx3rE4BuDl;
final class DK9N3MtKTUYcC implements UTeyx3rE4BuDl
{
    public function mrpxgImfrf8(WlFu7DaMUEnSS $K9DZL) : string
    {
        return "v2/images/{$K9DZL->getFilename()}.{$K9DZL->getExtension()}";
    }
    public function m8bnBZQeVfZ(WlFu7DaMUEnSS $K9DZL)
    {
        return $K9DZL instanceof A9olNyGXhDJnA;
    }
}
