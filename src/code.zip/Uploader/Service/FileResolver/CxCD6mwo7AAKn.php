<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Service\FileResolver\WXA8QNbPhilkb;
final class CxCD6mwo7AAKn implements WXA8QNbPhilkb
{
    public function m5jaJGYYMNB(N8O216tH1Gxax $pemjO) : string
    {
        return "v2/videos/{$pemjO->getFileName()}.{$pemjO->getExtension()}";
    }
    public function mGIGUCsbdzj(N8O216tH1Gxax $pemjO)
    {
        return $pemjO instanceof ISYJHQo8eqdfc;
    }
}
