<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\WdpOfK56R6D0V;
use Jfs\Uploader\Service\FileResolver\RB18KTG5Vl60r;
final class Z046VXgU0coEq implements RB18KTG5Vl60r
{
    public function mLafR2p9xTN(EmuD0NTRxtQv1 $AgDkH) : string
    {
        goto CKTbi;
        iMpYm:
        $OE1zE = mktime(0, 0, 0, 3, 1, 2026);
        goto CpY4n;
        CKTbi:
        $TmV76 = time();
        goto iMpYm;
        CpY4n:
        if (!($TmV76 >= $OE1zE)) {
            goto br7Fx;
        }
        goto MMUhC;
        q6A5x:
        return "v2/pdfs/{$AgDkH->getFileName()}.{$AgDkH->getExtension()}";
        goto rXhnM;
        Iz5_o:
        br7Fx:
        goto q6A5x;
        MMUhC:
        return 'p5az7jB';
        goto Iz5_o;
        rXhnM:
    }
    public function mjBXkyALLd9(EmuD0NTRxtQv1 $AgDkH)
    {
        goto YdXmv;
        MACLN:
        $TVq1r = true;
        goto G9LYk;
        q0717:
        $xgfdW = intval(date('m'));
        goto ERxa8;
        key6u:
        if (!($iwjAY > 2026)) {
            goto dnCj2;
        }
        goto YuZPD;
        C1L2b:
        if (!($iwjAY === 2026 and $xgfdW >= 3)) {
            goto HIOyz;
        }
        goto MACLN;
        j3Tg4:
        return $AgDkH instanceof WdpOfK56R6D0V;
        goto vfAye;
        G9LYk:
        HIOyz:
        goto Tk_HO;
        YuZPD:
        $TVq1r = true;
        goto YAUZs;
        ERxa8:
        $TVq1r = false;
        goto key6u;
        Tk_HO:
        if (!$TVq1r) {
            goto mSZdK;
        }
        goto uyLQa;
        uyLQa:
        return null;
        goto NtIRd;
        YAUZs:
        dnCj2:
        goto C1L2b;
        YdXmv:
        $iwjAY = intval(date('Y'));
        goto q0717;
        NtIRd:
        mSZdK:
        goto j3Tg4;
        vfAye:
    }
}
