<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\C1MO7dubi2ia5;
use Jfs\Uploader\Service\FileResolver\FWwhMhsKRtjS2;
final class KD0PGR8YZihQ4 implements FWwhMhsKRtjS2
{
    public function mYoRGITjmKk(VpkgrrmDu5rEh $D55CH) : string
    {
        return "v2/pdfs/{$D55CH->getFileName()}.{$D55CH->getExtension()}";
    }
    public function mBw7y4FcoRu(VpkgrrmDu5rEh $D55CH)
    {
        return $D55CH instanceof C1MO7dubi2ia5;
    }
}
