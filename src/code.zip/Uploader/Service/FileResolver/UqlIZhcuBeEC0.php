<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Service\FileResolver\FgPa7IfKHhnis;
final class UqlIZhcuBeEC0 implements FgPa7IfKHhnis
{
    public function mRy05oXxdyH(Mty95KsoNkhJl $RB3Ub) : string
    {
        return "v2/videos/{$RB3Ub->getFileName()}.{$RB3Ub->getExtension()}";
    }
    public function mEvcd0RuR8y(Mty95KsoNkhJl $RB3Ub)
    {
        return $RB3Ub instanceof RhdJGUi8FOLBJ;
    }
}
