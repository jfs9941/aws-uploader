<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\A7djqU0sacoRX;
interface YWL2m71sSqZd2
{
    public function mAVCiwzictn(A7djqU0sacoRX $bwI0g);
    public function mnhMARrN4iG(A7djqU0sacoRX $bwI0g);
}
