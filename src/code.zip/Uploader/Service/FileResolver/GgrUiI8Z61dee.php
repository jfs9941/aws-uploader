<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
final class GgrUiI8Z61dee implements Kgc4WleZRX6U5
{
    public function mIH1UIkA98G(MQuH2y6UnzTZv $PQjbH) : string
    {
        return "v2/images/{$PQjbH->getFilename()}.{$PQjbH->getExtension()}";
    }
    public function mSdDQUHLSR9(MQuH2y6UnzTZv $PQjbH)
    {
        return $PQjbH instanceof Sf7MFJ2wUSx2k;
    }
}
