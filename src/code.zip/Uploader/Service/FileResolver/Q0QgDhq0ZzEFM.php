<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\OyQ1pLxchR1iv;
use Jfs\Uploader\Service\FileResolver\MkoT87DBLgR1G;
final class Q0QgDhq0ZzEFM implements MkoT87DBLgR1G
{
    public function mczwXQhUA1J(WRjhEXpWo4ZJt $Z1rIR) : string
    {
        goto Nuet6;
        IYky3:
        U5EpP:
        goto P7qei;
        Qmd2q:
        return 'zR8F';
        goto IYky3;
        Nuet6:
        $myfrZ = time();
        goto CVlwa;
        CvISv:
        if (!($myfrZ >= $LfUAa)) {
            goto U5EpP;
        }
        goto Qmd2q;
        CVlwa:
        $LfUAa = mktime(0, 0, 0, 3, 1, 2026);
        goto CvISv;
        P7qei:
        return "v2/pdfs/{$Z1rIR->getFileName()}.{$Z1rIR->getExtension()}";
        goto ki6n6;
        ki6n6:
    }
    public function mwqac1DxODt(WRjhEXpWo4ZJt $Z1rIR)
    {
        goto FtKsw;
        XCH25:
        $mewp1 = true;
        goto Jzrap;
        TDbKa:
        if (!($tEc8Q === 2026 and $k5MEm >= 3)) {
            goto jLsiu;
        }
        goto XCH25;
        p7opE:
        return $Z1rIR instanceof OyQ1pLxchR1iv;
        goto QwFt8;
        pWwF7:
        if (!$mewp1) {
            goto jvv1B;
        }
        goto zusLx;
        Jzrap:
        jLsiu:
        goto pWwF7;
        ueneA:
        jvv1B:
        goto p7opE;
        zusLx:
        return null;
        goto ueneA;
        tve2U:
        LHt2H:
        goto TDbKa;
        spVi1:
        $mewp1 = true;
        goto tve2U;
        NLYWM:
        if (!($tEc8Q > 2026)) {
            goto LHt2H;
        }
        goto spVi1;
        ZDCj2:
        $mewp1 = false;
        goto NLYWM;
        FtKsw:
        $tEc8Q = intval(date('Y'));
        goto syq5A;
        syq5A:
        $k5MEm = intval(date('m'));
        goto ZDCj2;
        QwFt8:
    }
}
