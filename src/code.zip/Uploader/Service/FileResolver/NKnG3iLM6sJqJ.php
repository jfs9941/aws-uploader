<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Service\FileResolver; use Jfs\Uploader\Core\DIYGIfCt7MLhm; use Jfs\Uploader\Core\OgXvS9KDq1Lql; final class NKnG3iLM6sJqJ implements KwaTcvWfkU3Lr { public function mLRw7Y0dqGM(DIYGIfCt7MLhm $goH3d) : string { return "v2/videos/{$goH3d->getFileName()}.{$goH3d->getExtension()}"; } public function mDQQd4bwuSM(DIYGIfCt7MLhm $goH3d) { return $goH3d instanceof OgXvS9KDq1Lql; } }
