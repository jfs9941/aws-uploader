<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WGN88W9AFumiX;
interface H01EOIlyzOh6S
{
    public function mvcG6A09lVY(WGN88W9AFumiX $s2INV);
    public function mrhZmHyyvU4(WGN88W9AFumiX $s2INV);
}
