<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\A9R6iJFlMGSBV;
interface M4mASNosdA3Eb
{
    public function mcu4iIFvGwu(A9R6iJFlMGSBV $VZzWw);
    public function mSaIEl1i6XJ(A9R6iJFlMGSBV $VZzWw);
}
