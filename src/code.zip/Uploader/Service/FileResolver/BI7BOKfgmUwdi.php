<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Service\FileResolver;

use backup\Uploader\Core\YcdplGVWzA91v;
interface BI7BOKfgmUwdi
{
    public function mUY17sPgYP6(YcdplGVWzA91v $eVZrJ);
    public function mtsKpJFvGEz(YcdplGVWzA91v $eVZrJ);
}
