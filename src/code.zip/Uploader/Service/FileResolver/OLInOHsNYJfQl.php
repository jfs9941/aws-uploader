<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Service\FileResolver\Ebj614gXdZiar;
final class OLInOHsNYJfQl implements Ebj614gXdZiar
{
    public function mYKZM8V80kU(SYLdN2QnIYYwa $mz56v) : string
    {
        return "v2/images/{$mz56v->getFilename()}.{$mz56v->getExtension()}";
    }
    public function mZbDnySw1PK(SYLdN2QnIYYwa $mz56v)
    {
        return $mz56v instanceof JOauoJMkgHWbh;
    }
}
