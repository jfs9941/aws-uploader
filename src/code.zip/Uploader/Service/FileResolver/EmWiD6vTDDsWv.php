<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Core\G4MP13yRAmltw;
final class EmWiD6vTDDsWv implements DoGxgFeojHDo9
{
    public function mGOW8dL2ZJj(El0vMUwnHgT49 $tscCi) : string
    {
        return "v2/videos/{$tscCi->getFileName()}.{$tscCi->getExtension()}";
    }
    public function moOde7C6xS3(El0vMUwnHgT49 $tscCi)
    {
        return $tscCi instanceof G4MP13yRAmltw;
    }
}
