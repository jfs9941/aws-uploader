<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Service\FileResolver\YlkMj7hiefpew;
final class Ffgyfl3hsIZIl implements YlkMj7hiefpew
{
    public function mELOenBEMpO(YeOKDEuyU49Av $dV9QE) : string
    {
        return "v2/videos/{$dV9QE->getFileName()}.{$dV9QE->getExtension()}";
    }
    public function mBo2PjwPlax(YeOKDEuyU49Av $dV9QE)
    {
        return $dV9QE instanceof BG2FRpwGrKqJx;
    }
}
