<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Service\FileResolver;

use src\Uploader\Core\UZjgdpyMf06F7;
interface XTKfH8zm66SCQ
{
    public function mwKoOSwhjuo(UZjgdpyMf06F7 $d1aiC);
    public function mr4oEpfz1tt(UZjgdpyMf06F7 $d1aiC);
}
