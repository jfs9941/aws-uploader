<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Service\FileResolver;

use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Service\FileResolver\BI7BOKfgmUwdi;
final class V5bG2LjR6NHvU implements BI7BOKfgmUwdi
{
    public function mUY17sPgYP6(YcdplGVWzA91v $eVZrJ) : string
    {
        return "v2/images/{$eVZrJ->getFilename()}.{$eVZrJ->getExtension()}";
    }
    public function mtsKpJFvGEz(YcdplGVWzA91v $eVZrJ)
    {
        return $eVZrJ instanceof CrEYqpC23XUGo;
    }
}
