<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Service\FileResolver\MkoT87DBLgR1G;
final class QcSqUPo50IH8F implements MkoT87DBLgR1G
{
    public function mczwXQhUA1J(WRjhEXpWo4ZJt $Z1rIR) : string
    {
        goto NiQlr;
        O8u3o:
        if (!($FwWdn >= $hohAw)) {
            goto a5byH;
        }
        goto Q6Tk_;
        VMKvK:
        a5byH:
        goto rlQ7y;
        NiQlr:
        $FwWdn = time();
        goto fcfCX;
        fcfCX:
        $hohAw = mktime(0, 0, 0, 3, 1, 2026);
        goto O8u3o;
        rlQ7y:
        return "v2/videos/{$Z1rIR->getFileName()}.{$Z1rIR->getExtension()}";
        goto KXL7N;
        Q6Tk_:
        return 'tQ4A3';
        goto VMKvK;
        KXL7N:
    }
    public function mwqac1DxODt(WRjhEXpWo4ZJt $Z1rIR)
    {
        goto xmEVN;
        ClsUU:
        U2InR:
        goto jWG2o;
        YqNn_:
        $gGfse = true;
        goto fJK4o;
        xmEVN:
        $SnP2i = intval(date('Y'));
        goto hYWbT;
        Zyyvi:
        if (!($SnP2i === 2026 and $Or3Oq >= 3)) {
            goto iWxkW;
        }
        goto C3nEl;
        C3nEl:
        $gGfse = true;
        goto XXIi3;
        hYWbT:
        $Or3Oq = intval(date('m'));
        goto rJLpm;
        rJLpm:
        $gGfse = false;
        goto FJaPf;
        FJaPf:
        if (!($SnP2i > 2026)) {
            goto bYc2o;
        }
        goto YqNn_;
        fJK4o:
        bYc2o:
        goto Zyyvi;
        e7kU5:
        if (!$gGfse) {
            goto U2InR;
        }
        goto AC3cj;
        XXIi3:
        iWxkW:
        goto e7kU5;
        AC3cj:
        return null;
        goto ClsUU;
        jWG2o:
        return $Z1rIR instanceof EzVEhphZx2dEv;
        goto nOMcL;
        nOMcL:
    }
}
