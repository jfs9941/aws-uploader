<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\D7CMsi4o836Y7;
use Jfs\Uploader\Service\FileResolver\PfK9DYjwsXm74;
final class QmWoqwpqcvj4M implements PfK9DYjwsXm74
{
    public function mH4C7t0zM7i(M0ises9bx8zn4 $cNpq7) : string
    {
        return "v2/pdfs/{$cNpq7->getFileName()}.{$cNpq7->getExtension()}";
    }
    public function mG6UvoJSEGE(M0ises9bx8zn4 $cNpq7)
    {
        return $cNpq7 instanceof D7CMsi4o836Y7;
    }
}
