<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Service\FileResolver\Wira7hKoOHFj6;
final class EkEWqweUhBR8J implements Wira7hKoOHFj6
{
    public function mCNUjEbsWBz(TXpC7TSf51nOz $Ga9Xm) : string
    {
        return "v2/images/{$Ga9Xm->getFilename()}.{$Ga9Xm->getExtension()}";
    }
    public function mQlbPWyS91p(TXpC7TSf51nOz $Ga9Xm)
    {
        return $Ga9Xm instanceof Vt3ybt0yfaPAa;
    }
}
