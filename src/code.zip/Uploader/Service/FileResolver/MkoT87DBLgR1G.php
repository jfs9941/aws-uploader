<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
interface MkoT87DBLgR1G
{
    public function mczwXQhUA1J(WRjhEXpWo4ZJt $Z1rIR);
    public function mwqac1DxODt(WRjhEXpWo4ZJt $Z1rIR);
}
