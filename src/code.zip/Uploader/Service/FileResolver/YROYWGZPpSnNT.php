<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Service\FileResolver\FWwhMhsKRtjS2;
final class YROYWGZPpSnNT implements FWwhMhsKRtjS2
{
    public function mYoRGITjmKk(VpkgrrmDu5rEh $D55CH) : string
    {
        return "v2/videos/{$D55CH->getFileName()}.{$D55CH->getExtension()}";
    }
    public function mBw7y4FcoRu(VpkgrrmDu5rEh $D55CH)
    {
        return $D55CH instanceof AelPShnd8pMtD;
    }
}
