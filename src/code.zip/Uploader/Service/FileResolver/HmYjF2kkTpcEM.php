<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
interface HmYjF2kkTpcEM
{
    public function mPZreWm8gaB(J5Mj1pjSQG0SH $nKKn0);
    public function mmEJ9rtxhah(J5Mj1pjSQG0SH $nKKn0);
}
