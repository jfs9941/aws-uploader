<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
final class WSTu5CxKi3ckv implements FgJbra0UeoOsX
{
    public function m7pgB8X0Csa(KO2pC9qLVd4GD $xdi9a) : string
    {
        return "v2/images/{$xdi9a->getFilename()}.{$xdi9a->getExtension()}";
    }
    public function m8bW1LjLFz2(KO2pC9qLVd4GD $xdi9a)
    {
        return $xdi9a instanceof OcbNsXl9lpteB;
    }
}
