<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\GPZ0EQoHpj04q;
use Jfs\Uploader\Service\FileResolver\TPvC7BatUSSwb;
final class D3qhwpI60OqBf implements TPvC7BatUSSwb
{
    public function mnkMEbTAHB9(QLOMBcv8tw1Qd $DejZC) : string
    {
        return "v2/pdfs/{$DejZC->getFileName()}.{$DejZC->getExtension()}";
    }
    public function mz3nF5W6NWk(QLOMBcv8tw1Qd $DejZC)
    {
        return $DejZC instanceof GPZ0EQoHpj04q;
    }
}
