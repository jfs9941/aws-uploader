<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Core\IyqtwINobs6go;
final class Wc0QMmHjHkJXD implements Af4ZCqs0KIlAV
{
    public function m8SrIJLXyX6(WEM4ywoGgpPLK $oYtbp) : string
    {
        return "v2/pdfs/{$oYtbp->getFileName()}.{$oYtbp->getExtension()}";
    }
    public function m4gfXZPb4I7(WEM4ywoGgpPLK $oYtbp)
    {
        return $oYtbp instanceof IyqtwINobs6go;
    }
}
