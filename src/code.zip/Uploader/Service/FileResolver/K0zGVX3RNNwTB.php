<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\EqLr3PLlMLHwV;
use Jfs\Uploader\Service\FileResolver\PbX8rA6e8y75x;
final class K0zGVX3RNNwTB implements PbX8rA6e8y75x
{
    public function mQD7yz7G3cT(HWHmqgxgfYrsZ $ZQzpf) : string
    {
        return "v2/pdfs/{$ZQzpf->getFileName()}.{$ZQzpf->getExtension()}";
    }
    public function mXhruH8jlx5(HWHmqgxgfYrsZ $ZQzpf)
    {
        return $ZQzpf instanceof EqLr3PLlMLHwV;
    }
}
