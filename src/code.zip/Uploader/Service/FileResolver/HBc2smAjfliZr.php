<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\J9AcMiQKgpvel;
use Jfs\Uploader\Core\JmK3jjuoaQvAV;
use Jfs\Uploader\Service\FileResolver\Q2XJ8i6Pqd1lE;
final class HBc2smAjfliZr implements Q2XJ8i6Pqd1lE
{
    public function mtelO84CPhd(J9AcMiQKgpvel $VslFR) : string
    {
        return "v2/pdfs/{$VslFR->getFileName()}.{$VslFR->getExtension()}";
    }
    public function mbKoMYNQJOO(J9AcMiQKgpvel $VslFR)
    {
        return $VslFR instanceof JmK3jjuoaQvAV;
    }
}
