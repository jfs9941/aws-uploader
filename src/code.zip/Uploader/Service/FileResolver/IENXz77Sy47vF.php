<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Service\FileResolver;

use src\Uploader\Core\GoopVn9iYwlO0;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Service\FileResolver\XTKfH8zm66SCQ;
final class IENXz77Sy47vF implements XTKfH8zm66SCQ
{
    public function mwKoOSwhjuo(UZjgdpyMf06F7 $d1aiC) : string
    {
        return "v2/pdfs/{$d1aiC->getFileName()}.{$d1aiC->getExtension()}";
    }
    public function mr4oEpfz1tt(UZjgdpyMf06F7 $d1aiC)
    {
        return $d1aiC instanceof GoopVn9iYwlO0;
    }
}
