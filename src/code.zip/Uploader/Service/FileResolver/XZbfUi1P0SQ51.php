<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Service\FileResolver\UioryE8ZMrMRb;
final class XZbfUi1P0SQ51 implements UioryE8ZMrMRb
{
    public function mkNRCD3SXo1(EeWreEFdq3Xdf $nbWJE) : string
    {
        return "v2/videos/{$nbWJE->getFileName()}.{$nbWJE->getExtension()}";
    }
    public function mhxeHYl2m9g(EeWreEFdq3Xdf $nbWJE)
    {
        return $nbWJE instanceof J7sRaWo8um3yO;
    }
}
