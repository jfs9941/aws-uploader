<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Service\FileResolver\Vos9aJIGFYrKk;
final class K5BCpRZRa8Eqv implements Vos9aJIGFYrKk
{
    public function mqskwBwLx22(WEJt1TL92SawT $z620p) : string
    {
        return "v2/images/{$z620p->getFilename()}.{$z620p->getExtension()}";
    }
    public function mUiB3m5cXoA(WEJt1TL92SawT $z620p)
    {
        return $z620p instanceof FmmY71eXk0D8U;
    }
}
