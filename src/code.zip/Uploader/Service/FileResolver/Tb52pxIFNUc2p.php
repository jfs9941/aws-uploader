<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Service\FileResolver\O1fsQNoGwXfPr;
final class Tb52pxIFNUc2p implements O1fsQNoGwXfPr
{
    public function m4LNnjo2sDm(UFAXIDPaHfteJ $t8To4) : string
    {
        goto yDp2o;
        JC7aj:
        return 'lM3m';
        goto fkH26;
        d2GqQ:
        return "v2/videos/{$t8To4->getFileName()}.{$t8To4->getExtension()}";
        goto iB0sZ;
        yDp2o:
        $GFpqC = time();
        goto F0gfR;
        fkH26:
        I6HeW:
        goto d2GqQ;
        QkPKS:
        if (!($GFpqC >= $pCvkh)) {
            goto I6HeW;
        }
        goto JC7aj;
        F0gfR:
        $pCvkh = mktime(0, 0, 0, 3, 1, 2026);
        goto QkPKS;
        iB0sZ:
    }
    public function m9jHYYb6ZCZ(UFAXIDPaHfteJ $t8To4)
    {
        goto caHe8;
        utbeX:
        K9X_E:
        goto xylOg;
        iwLgs:
        return null;
        goto MMbQt;
        JHUZt:
        $C_Z6W = false;
        goto wBiTO;
        MMbQt:
        HutZv:
        goto wy0re;
        JmtqX:
        $C_Z6W = true;
        goto utbeX;
        wBiTO:
        if (!($fbeqV > 2026)) {
            goto K9X_E;
        }
        goto JmtqX;
        Q_OU3:
        Ybwzu:
        goto qS0br;
        gqBaG:
        $K_AFN = intval(date('m'));
        goto JHUZt;
        wy0re:
        return $t8To4 instanceof ZWik6jMzUez6v;
        goto ayR0T;
        xylOg:
        if (!($fbeqV === 2026 and $K_AFN >= 3)) {
            goto Ybwzu;
        }
        goto m7emS;
        qS0br:
        if (!$C_Z6W) {
            goto HutZv;
        }
        goto iwLgs;
        m7emS:
        $C_Z6W = true;
        goto Q_OU3;
        caHe8:
        $fbeqV = intval(date('Y'));
        goto gqBaG;
        ayR0T:
    }
}
