<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
interface WEvsKO38EVJMP
{
    public function mVeDSPX1Tlz(Y5tmWZcWsdzIB $ezBDN);
    public function mS9eeM6KIgR(Y5tmWZcWsdzIB $ezBDN);
}
