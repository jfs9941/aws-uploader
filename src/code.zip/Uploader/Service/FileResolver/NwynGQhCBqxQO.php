<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Service\FileResolver\Xx9PGVcJPphhb;
final class NwynGQhCBqxQO implements Xx9PGVcJPphhb
{
    public function mIu6wGqIDWx(PaQmIZL22EnpA $RCdwx) : string
    {
        return "v2/videos/{$RCdwx->getFileName()}.{$RCdwx->getExtension()}";
    }
    public function m43iLY4iJnJ(PaQmIZL22EnpA $RCdwx)
    {
        return $RCdwx instanceof Jf5KRr8uE3t34;
    }
}
