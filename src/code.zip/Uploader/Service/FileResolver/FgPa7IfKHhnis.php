<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Mty95KsoNkhJl;
interface FgPa7IfKHhnis
{
    public function mRy05oXxdyH(Mty95KsoNkhJl $RB3Ub);
    public function mEvcd0RuR8y(Mty95KsoNkhJl $RB3Ub);
}
