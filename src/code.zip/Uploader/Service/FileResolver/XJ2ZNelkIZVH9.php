<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\Y8GGC9jt5i0Qv;
use Jfs\Uploader\Service\FileResolver\O1fsQNoGwXfPr;
final class XJ2ZNelkIZVH9 implements O1fsQNoGwXfPr
{
    public function m4LNnjo2sDm(UFAXIDPaHfteJ $t8To4) : string
    {
        goto ocTRM;
        Yjkw0:
        $USp22 = mktime(0, 0, 0, 3, 1, 2026);
        goto rw6sE;
        M5S0K:
        qa7vR:
        goto Om8DA;
        Om8DA:
        return "v2/pdfs/{$t8To4->getFileName()}.{$t8To4->getExtension()}";
        goto eBZOY;
        zFyaf:
        return 'mP33lw';
        goto M5S0K;
        ocTRM:
        $z1Fvd = time();
        goto Yjkw0;
        rw6sE:
        if (!($z1Fvd >= $USp22)) {
            goto qa7vR;
        }
        goto zFyaf;
        eBZOY:
    }
    public function m9jHYYb6ZCZ(UFAXIDPaHfteJ $t8To4)
    {
        goto JyDMy;
        MHutb:
        if (!$uu3m3) {
            goto L1FaA;
        }
        goto sgjU8;
        ydiLz:
        $uu3m3 = false;
        goto JlqOq;
        JlqOq:
        if (!($XNDbt > 2026)) {
            goto asJgK;
        }
        goto BOL1E;
        wpaqF:
        asJgK:
        goto Xi1GO;
        yN1mx:
        $uu3m3 = true;
        goto eggYs;
        WDqEw:
        L1FaA:
        goto YX1F4;
        JyDMy:
        $XNDbt = intval(date('Y'));
        goto Wfrho;
        Xi1GO:
        if (!($XNDbt === 2026 and $L419Y >= 3)) {
            goto C3LCq;
        }
        goto yN1mx;
        sgjU8:
        return null;
        goto WDqEw;
        BOL1E:
        $uu3m3 = true;
        goto wpaqF;
        Wfrho:
        $L419Y = intval(date('m'));
        goto ydiLz;
        YX1F4:
        return $t8To4 instanceof Y8GGC9jt5i0Qv;
        goto Ur8cB;
        eggYs:
        C3LCq:
        goto MHutb;
        Ur8cB:
    }
}
