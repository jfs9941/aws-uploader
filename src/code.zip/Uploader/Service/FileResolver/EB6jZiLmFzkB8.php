<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
interface EB6jZiLmFzkB8
{
    public function m35XKxRLotY(UkjvJ3zCZNh6F $TFA4Z);
    public function mYFN2fW6LzZ(UkjvJ3zCZNh6F $TFA4Z);
}
