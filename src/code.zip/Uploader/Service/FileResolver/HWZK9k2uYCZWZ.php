<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Service\FileResolver\G52L06e5mJkBd;
final class HWZK9k2uYCZWZ implements G52L06e5mJkBd
{
    public function m7DsbapOQgU(Guvqjk2EvHsmF $clm2Y) : string
    {
        return "v2/images/{$clm2Y->getFilename()}.{$clm2Y->getExtension()}";
    }
    public function mxxEwscu3Zo(Guvqjk2EvHsmF $clm2Y)
    {
        return $clm2Y instanceof U0IzvN2kaLZHI;
    }
}
