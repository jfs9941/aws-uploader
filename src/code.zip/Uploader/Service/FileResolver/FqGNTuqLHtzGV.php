<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Core\XWqfTCKHy5X8X;
final class FqGNTuqLHtzGV implements HmYjF2kkTpcEM
{
    public function mPZreWm8gaB(J5Mj1pjSQG0SH $nKKn0) : string
    {
        return "v2/pdfs/{$nKKn0->getFileName()}.{$nKKn0->getExtension()}";
    }
    public function mmEJ9rtxhah(J5Mj1pjSQG0SH $nKKn0)
    {
        return $nKKn0 instanceof XWqfTCKHy5X8X;
    }
}
