<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
final class XB7bGLKz5CnoV implements Izd3tOHzlJ2qv
{
    public function mCnkSwB0bhR(WmSe4qJ68rckH $rQ18B) : string
    {
        return "v2/videos/{$rQ18B->getFileName()}.{$rQ18B->getExtension()}";
    }
    public function mfyfR1AYL8M(WmSe4qJ68rckH $rQ18B)
    {
        return $rQ18B instanceof ZSB2cdrwtZpmk;
    }
}
