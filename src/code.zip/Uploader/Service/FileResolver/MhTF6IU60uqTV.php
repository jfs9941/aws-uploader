<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\UpreKuqs00udz;
use Jfs\Uploader\Service\FileResolver\DQhGn0SNJLxYb;
final class MhTF6IU60uqTV implements DQhGn0SNJLxYb
{
    public function m82tJsXuL8g(LxwvVLXJMU3yo $spSJx) : string
    {
        return "v2/pdfs/{$spSJx->getFileName()}.{$spSJx->getExtension()}";
    }
    public function mZvoYrXcyva(LxwvVLXJMU3yo $spSJx)
    {
        return $spSJx instanceof UpreKuqs00udz;
    }
}
