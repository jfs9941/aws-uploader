<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\J9AcMiQKgpvel;
interface Q2XJ8i6Pqd1lE
{
    public function mtelO84CPhd(J9AcMiQKgpvel $VslFR);
    public function mbKoMYNQJOO(J9AcMiQKgpvel $VslFR);
}
