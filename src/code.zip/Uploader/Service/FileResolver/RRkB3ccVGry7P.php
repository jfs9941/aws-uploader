<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\OfMUIxZzii9Zu;
interface RRkB3ccVGry7P
{
    public function mmGrLEMKSzu(OfMUIxZzii9Zu $gNVOT);
    public function mH8VrxJ67sd(OfMUIxZzii9Zu $gNVOT);
}
