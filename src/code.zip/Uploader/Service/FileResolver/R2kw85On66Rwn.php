<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Service\FileResolver\TPvC7BatUSSwb;
final class R2kw85On66Rwn implements TPvC7BatUSSwb
{
    public function mnkMEbTAHB9(QLOMBcv8tw1Qd $DejZC) : string
    {
        return "v2/images/{$DejZC->getFilename()}.{$DejZC->getExtension()}";
    }
    public function mz3nF5W6NWk(QLOMBcv8tw1Qd $DejZC)
    {
        return $DejZC instanceof QFoN7Ibbm93if;
    }
}
