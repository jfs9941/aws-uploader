<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Service\FileResolver\ZZ7ar02ykwlAz;
final class CDcuArOllQrjI implements ZZ7ar02ykwlAz
{
    public function mmDXpZuuXxW(RV6vDyOPhxLM1 $ZPsYd) : string
    {
        return "v2/videos/{$ZPsYd->getFileName()}.{$ZPsYd->getExtension()}";
    }
    public function mOmk7130QrW(RV6vDyOPhxLM1 $ZPsYd)
    {
        return $ZPsYd instanceof NYx4mhlHSMgHF;
    }
}
