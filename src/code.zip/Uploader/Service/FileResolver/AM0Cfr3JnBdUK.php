<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Service\FileResolver\RB18KTG5Vl60r;
final class AM0Cfr3JnBdUK implements RB18KTG5Vl60r
{
    public function mLafR2p9xTN(EmuD0NTRxtQv1 $AgDkH) : string
    {
        goto xdf46;
        gaNn5:
        $uomaz = mktime(0, 0, 0, 3, 1, 2026);
        goto SJDWJ;
        xdf46:
        $LQBLV = time();
        goto gaNn5;
        PfIM_:
        MXlQg:
        goto bxXdD;
        bxXdD:
        return "v2/images/{$AgDkH->getFilename()}.{$AgDkH->getExtension()}";
        goto mdwuJ;
        SJDWJ:
        if (!($LQBLV >= $uomaz)) {
            goto MXlQg;
        }
        goto fyoRD;
        fyoRD:
        return 'AG0Rc8p';
        goto PfIM_;
        mdwuJ:
    }
    public function mjBXkyALLd9(EmuD0NTRxtQv1 $AgDkH)
    {
        goto gVIeT;
        VJqGF:
        $uLTQN = true;
        goto yeJTI;
        ijggI:
        BSxZG:
        goto e6i0f;
        JU9xG:
        if (!($a8ln4 === 2026 and $W8cjB >= 3)) {
            goto BSxZG;
        }
        goto aH5JS;
        zUA81:
        return $AgDkH instanceof GaCd6pGBkiLzh;
        goto suI6E;
        vvTHe:
        $uLTQN = false;
        goto oKVrz;
        yeJTI:
        XSCnA:
        goto JU9xG;
        ddkgS:
        $W8cjB = intval(date('m'));
        goto vvTHe;
        CWqMS:
        IOT6z:
        goto zUA81;
        e6i0f:
        if (!$uLTQN) {
            goto IOT6z;
        }
        goto sXG8n;
        gVIeT:
        $a8ln4 = intval(date('Y'));
        goto ddkgS;
        oKVrz:
        if (!($a8ln4 > 2026)) {
            goto XSCnA;
        }
        goto VJqGF;
        aH5JS:
        $uLTQN = true;
        goto ijggI;
        sXG8n:
        return null;
        goto CWqMS;
        suI6E:
    }
}
