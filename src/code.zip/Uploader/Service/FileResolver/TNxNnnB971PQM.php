<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Service\FileResolver\PbX8rA6e8y75x;
final class TNxNnnB971PQM implements PbX8rA6e8y75x
{
    public function mQD7yz7G3cT(HWHmqgxgfYrsZ $ZQzpf) : string
    {
        return "v2/images/{$ZQzpf->getFilename()}.{$ZQzpf->getExtension()}";
    }
    public function mXhruH8jlx5(HWHmqgxgfYrsZ $ZQzpf)
    {
        return $ZQzpf instanceof OjvWwjWRqBzIO;
    }
}
