<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\X5WvqPHlZPq50;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Service\FileResolver\DUxtF4CYlybbO;
final class QExWxPokjFmrd implements DUxtF4CYlybbO
{
    public function mNnMQokzwcj(X5WvqPHlZPq50 $YfsmL) : string
    {
        return "v2/images/{$YfsmL->getFilename()}.{$YfsmL->getExtension()}";
    }
    public function mVxygpHw1dN(X5WvqPHlZPq50 $YfsmL)
    {
        return $YfsmL instanceof XMeo8SOmME8kj;
    }
}
