<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EmuD0NTRxtQv1;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Service\FileResolver\RB18KTG5Vl60r;
final class BNKj2B1P7cOGL implements RB18KTG5Vl60r
{
    public function mLafR2p9xTN(EmuD0NTRxtQv1 $AgDkH) : string
    {
        goto OpVHp;
        ITlCI:
        return "v2/videos/{$AgDkH->getFileName()}.{$AgDkH->getExtension()}";
        goto HOqEv;
        YBQsC:
        return 'EtmBMu8b';
        goto xrh9M;
        xrh9M:
        D5Y__:
        goto ITlCI;
        OpVHp:
        $isml6 = time();
        goto eMACR;
        xm3Cm:
        if (!($isml6 >= $PWCrt)) {
            goto D5Y__;
        }
        goto YBQsC;
        eMACR:
        $PWCrt = mktime(0, 0, 0, 3, 1, 2026);
        goto xm3Cm;
        HOqEv:
    }
    public function mjBXkyALLd9(EmuD0NTRxtQv1 $AgDkH)
    {
        goto rUcBF;
        en4GW:
        $R3RQT = true;
        goto a0M3I;
        yKfm0:
        if (!$R3RQT) {
            goto TODeS;
        }
        goto J8yB3;
        NFrsI:
        $R3RQT = false;
        goto A_QCd;
        JWM2p:
        $R3RQT = true;
        goto lulmb;
        L3ntr:
        return $AgDkH instanceof BJhQlhWHvJ3Iz;
        goto BrWPn;
        Ja4rR:
        if (!($DzpeN === 2026 and $sReO5 >= 3)) {
            goto KzV7z;
        }
        goto en4GW;
        rUcBF:
        $DzpeN = intval(date('Y'));
        goto sM0n2;
        J8yB3:
        return null;
        goto wn_vT;
        lulmb:
        hAeMs:
        goto Ja4rR;
        a0M3I:
        KzV7z:
        goto yKfm0;
        wn_vT:
        TODeS:
        goto L3ntr;
        A_QCd:
        if (!($DzpeN > 2026)) {
            goto hAeMs;
        }
        goto JWM2p;
        sM0n2:
        $sReO5 = intval(date('m'));
        goto NFrsI;
        BrWPn:
    }
}
