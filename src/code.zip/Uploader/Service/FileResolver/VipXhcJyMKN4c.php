<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Service\FileResolver\QfOW6Hr4RJSCz;
final class VipXhcJyMKN4c implements QfOW6Hr4RJSCz
{
    public function mXSGuQe5X91(KhQ4OQYybZ7Vk $eQ4Ln) : string
    {
        return "v2/images/{$eQ4Ln->getFilename()}.{$eQ4Ln->getExtension()}";
    }
    public function m9XWpVeJaHm(KhQ4OQYybZ7Vk $eQ4Ln)
    {
        return $eQ4Ln instanceof XqAJHKYeaW2YU;
    }
}
