<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\DNmcAdktLJtqn;
interface PmKs34zySAetJ
{
    public function mEuh2Srd8MD(DNmcAdktLJtqn $QxvEM);
    public function mDoiLw48pZs(DNmcAdktLJtqn $QxvEM);
}
