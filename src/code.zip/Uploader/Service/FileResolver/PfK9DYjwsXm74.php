<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\M0ises9bx8zn4;
interface PfK9DYjwsXm74
{
    public function mH4C7t0zM7i(M0ises9bx8zn4 $cNpq7);
    public function mG6UvoJSEGE(M0ises9bx8zn4 $cNpq7);
}
