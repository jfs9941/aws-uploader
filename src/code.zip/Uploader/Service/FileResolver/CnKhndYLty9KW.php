<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
final class CnKhndYLty9KW implements MVK8yqlkSgksf
{
    public function mLYfWApn4bI(JQSlbB9QkzzhT $a3XOL) : string
    {
        return "v2/images/{$a3XOL->getFilename()}.{$a3XOL->getExtension()}";
    }
    public function mQWLmEjfuDm(JQSlbB9QkzzhT $a3XOL)
    {
        return $a3XOL instanceof LGMw063tEE9ZC;
    }
}
