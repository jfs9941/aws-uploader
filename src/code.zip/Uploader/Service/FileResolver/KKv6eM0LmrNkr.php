<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Core\WabYRJvOEOksh;
final class KKv6eM0LmrNkr implements BXlzeSomKKkd4
{
    public function mP2UVkYV346(Zvx9VGBGZQ0lD $I2SbP) : string
    {
        return "v2/pdfs/{$I2SbP->getFileName()}.{$I2SbP->getExtension()}";
    }
    public function mU6k4DMBmtn(Zvx9VGBGZQ0lD $I2SbP)
    {
        return $I2SbP instanceof WabYRJvOEOksh;
    }
}
