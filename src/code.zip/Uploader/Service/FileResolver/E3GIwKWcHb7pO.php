<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Service\FileResolver\MSiFUZOGwRG6e;
final class E3GIwKWcHb7pO implements MSiFUZOGwRG6e
{
    public function mb8NmWrIddR(BTuo2UPlpfSoS $FJFJj) : string
    {
        return "v2/videos/{$FJFJj->getFileName()}.{$FJFJj->getExtension()}";
    }
    public function mQroel6wQ9R(BTuo2UPlpfSoS $FJFJj)
    {
        return $FJFJj instanceof RhSx2q5xIlh0Y;
    }
}
