<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\A7djqU0sacoRX;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Service\FileResolver\YWL2m71sSqZd2;
final class HEN6zgaoMBijr implements YWL2m71sSqZd2
{
    public function mAVCiwzictn(A7djqU0sacoRX $bwI0g) : string
    {
        return "v2/images/{$bwI0g->getFilename()}.{$bwI0g->getExtension()}";
    }
    public function mnhMARrN4iG(A7djqU0sacoRX $bwI0g)
    {
        return $bwI0g instanceof VPGaYsuFJzbQ0;
    }
}
