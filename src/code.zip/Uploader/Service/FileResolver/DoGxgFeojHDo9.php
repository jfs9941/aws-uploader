<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\El0vMUwnHgT49;
interface DoGxgFeojHDo9
{
    public function mGOW8dL2ZJj(El0vMUwnHgT49 $tscCi);
    public function moOde7C6xS3(El0vMUwnHgT49 $tscCi);
}
