<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Service\FileResolver\MSiFUZOGwRG6e;
final class ZQyAzi2Ks3Ble implements MSiFUZOGwRG6e
{
    public function mb8NmWrIddR(BTuo2UPlpfSoS $FJFJj) : string
    {
        return "v2/images/{$FJFJj->getFilename()}.{$FJFJj->getExtension()}";
    }
    public function mQroel6wQ9R(BTuo2UPlpfSoS $FJFJj)
    {
        return $FJFJj instanceof S7LEoIprYtLQw;
    }
}
