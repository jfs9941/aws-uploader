<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Service\FileResolver\ShUSAHz6olRoV;
final class LFAm9Qfh94lZh implements ShUSAHz6olRoV
{
    public function mFMTAmQv5ze(Q0JnJtyNI6T0p $hFrf7) : string
    {
        return "v2/videos/{$hFrf7->getFileName()}.{$hFrf7->getExtension()}";
    }
    public function mEyKasCU45H(Q0JnJtyNI6T0p $hFrf7)
    {
        return $hFrf7 instanceof MbOYV1VlUGCys;
    }
}
