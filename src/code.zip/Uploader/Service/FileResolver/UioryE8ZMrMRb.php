<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\EeWreEFdq3Xdf;
interface UioryE8ZMrMRb
{
    public function mkNRCD3SXo1(EeWreEFdq3Xdf $nbWJE);
    public function mhxeHYl2m9g(EeWreEFdq3Xdf $nbWJE);
}
