<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class PtQPpsdtUMxZM implements VideoPostHandleServiceInterface
{
    private $nYO66;
    private $huyLW;
    public function __construct(UploadServiceInterface $lErFf, Filesystem $A3hvZ)
    {
        $this->nYO66 = $lErFf;
        $this->huyLW = $A3hvZ;
    }
    public function saveMetadata(string $arqvy, array $vOZNn)
    {
        goto vzwkY;
        RhLj_:
        $N8lmi['fps'] = $vOZNn['fps'];
        goto UTXR3;
        TPO1P:
        if (!isset($vOZNn['thumbnail_url'])) {
            goto K8hXR;
        }
        goto YiegW;
        YiegW:
        $N8lmi['thumbnail'] = pathinfo($vOZNn['thumbnail_url'], PATHINFO_FILENAME);
        goto HgSAh;
        dPQBD:
        $N8lmi['resolution'] = $vOZNn['resolution'];
        goto A7Sj_;
        psbtU:
        xLZxP:
        goto T7h7b;
        P3Xgp:
        return $XFeNv->getView();
        goto moY8h;
        klCdp:
        $this->nYO66->updateFile($XFeNv->getAttribute('id'), EXecNg2hg7kwl::PROCESSING);
        goto aIYSG;
        JCiMM:
        if (!isset($vOZNn['thumbnail'])) {
            goto NmYkk;
        }
        goto Yi9k1;
        lhKXS:
        if (!(isset($vOZNn['change_status']) && $vOZNn['change_status'])) {
            goto G3xfY;
        }
        goto klCdp;
        r8WAY:
        $N8lmi = [];
        goto TPO1P;
        xInwn:
        unset($N8lmi['thumbnail']);
        goto lNPpb;
        h1JOw:
        throw new \Exception("RhSx2q5xIlh0Y metadata store failed for unknown reason ... " . $arqvy);
        goto dDvJf;
        LmajU:
        if (!isset($vOZNn['duration'])) {
            goto xLZxP;
        }
        goto MJktg;
        Yi9k1:
        try {
            goto S9HyB;
            H3rWR:
            $N8lmi['thumbnail_id'] = $dZvCS['id'];
            goto FEAe5;
            S9HyB:
            $dZvCS = $this->nYO66->storeSingleFile(new class($vOZNn['thumbnail']) implements SingleUploadInterface
            {
                private $i_qo1;
                public function __construct($FJFJj)
                {
                    $this->i_qo1 = $FJFJj;
                }
                public function getFile()
                {
                    return $this->i_qo1;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto H3rWR;
            FEAe5:
            $N8lmi['thumbnail'] = $dZvCS['filename'];
            goto koedJ;
            koedJ:
        } catch (\Throwable $vR5RQ) {
            Log::warning("RhSx2q5xIlh0Y thumbnail store failed: " . $vR5RQ->getMessage());
        }
        goto lTkHq;
        UTXR3:
        PalV0:
        goto iYt9v;
        aIYSG:
        G3xfY:
        goto P3Xgp;
        MJktg:
        $N8lmi['duration'] = $vOZNn['duration'];
        goto psbtU;
        lTkHq:
        NmYkk:
        goto LmajU;
        SJofw:
        if (!$XFeNv->update($N8lmi)) {
            goto V6pGN;
        }
        goto lhKXS;
        moY8h:
        V6pGN:
        goto P2dmw;
        A7Sj_:
        MJqVv:
        goto nZIzI;
        P2dmw:
        Log::warning("RhSx2q5xIlh0Y metadata store failed for unknown reason ... " . $arqvy);
        goto h1JOw;
        vzwkY:
        $XFeNv = RhSx2q5xIlh0Y::findOrFail($arqvy);
        goto r8WAY;
        lNPpb:
        zfv37:
        goto SJofw;
        T7h7b:
        if (!isset($vOZNn['resolution'])) {
            goto MJqVv;
        }
        goto dPQBD;
        iYt9v:
        if (!$XFeNv->ywiLP) {
            goto zfv37;
        }
        goto xInwn;
        HgSAh:
        K8hXR:
        goto JCiMM;
        nZIzI:
        if (!isset($vOZNn['fps'])) {
            goto PalV0;
        }
        goto RhLj_;
        dDvJf:
    }
    public function createThumbnail(string $LMGY1) : void
    {
        goto j6bfW;
        j6bfW:
        Log::info("Use Lambda to generate thumbnail for video: " . $LMGY1);
        goto ig3d1;
        ue2Sn:
        $gKXa4 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto U01ZI;
        rG9Wk:
        if (!(!$this->huyLW->directoryExists($iZ2jw) && empty($XFeNv->m9ScitPYDnM()))) {
            goto Zrr2R;
        }
        goto ue2Sn;
        sQhhF:
        Zrr2R:
        goto sfTe4;
        i1eRL:
        $iZ2jw = "v2/hls/thumbnails/{$LMGY1}/";
        goto rG9Wk;
        ig3d1:
        $XFeNv = RhSx2q5xIlh0Y::findOrFail($LMGY1);
        goto i1eRL;
        U01ZI:
        try {
            goto lQEdd;
            lQEdd:
            $PRRz1 = $gKXa4->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto AtMAn;
            AtMAn:
            $EgzO2 = $PRRz1->get('QueueUrl');
            goto mkM46;
            mkM46:
            $gKXa4->sendMessage(['QueueUrl' => $EgzO2, 'MessageBody' => json_encode(['file_path' => $XFeNv->getLocation()])]);
            goto cnOZM;
            cnOZM:
        } catch (\Throwable $FTnqg) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$FTnqg->getMessage()}");
        }
        goto sQhhF;
        sfTe4:
    }
    public function mt3I8Sbnima(string $LMGY1) : void
    {
        goto vrbby;
        vrbby:
        $XFeNv = RhSx2q5xIlh0Y::findOrFail($LMGY1);
        goto mUy10;
        srHSM:
        throw new \Exception("Message back with success data but not found thumbnail files " . $LMGY1);
        goto ZRfDb;
        ig3j0:
        Log::error("Message back with success data but not found thumbnail " . $LMGY1);
        goto a1XNc;
        a1XNc:
        throw new \Exception("Message back with success data but not found thumbnail " . $LMGY1);
        goto Hdqp8;
        Hdqp8:
        CXB_5:
        goto u8nVX;
        RAH01:
        if (!(count($ypBNL) === 0)) {
            goto c8Lzh;
        }
        goto LedgP;
        LedgP:
        Log::error("Message back with success data but not found thumbnail files " . $LMGY1);
        goto srHSM;
        u8nVX:
        $ypBNL = $this->huyLW->files($iZ2jw);
        goto RAH01;
        DMxnY:
        if ($this->huyLW->directoryExists($iZ2jw)) {
            goto CXB_5;
        }
        goto ig3j0;
        mUy10:
        $iZ2jw = "v2/hls/thumbnails/{$LMGY1}/";
        goto DMxnY;
        ZRfDb:
        c8Lzh:
        goto OOXBc;
        OOXBc:
        $XFeNv->update(['generated_previews' => $iZ2jw]);
        goto xLmM3;
        xLmM3:
    }
    public function getThumbnails(string $LMGY1) : array
    {
        $XFeNv = RhSx2q5xIlh0Y::findOrFail($LMGY1);
        return $XFeNv->getThumbnails();
    }
    public function getMedia(string $LMGY1) : array
    {
        $Nb_Od = Media::findOrFail($LMGY1);
        return $Nb_Od->getView();
    }
}
