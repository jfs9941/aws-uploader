<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\X1RCpxma8t1mI;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class DQUjnzZGBNcVM implements VideoPostHandleServiceInterface
{
    private $gjlBb;
    private $XpKtX;
    public function __construct(UploadServiceInterface $r1qCJ, Filesystem $BNlIn)
    {
        $this->gjlBb = $r1qCJ;
        $this->XpKtX = $BNlIn;
    }
    public function saveMetadata(string $HxXtJ, array $UTrEg)
    {
        goto leHt9;
        kwRzI:
        if (!isset($UTrEg['fps'])) {
            goto D4Kfd;
        }
        goto NBP4E;
        Nrf_k:
        x0tcC:
        goto t4Fel;
        hvSP1:
        if (!$muzRm->update($rUBzd)) {
            goto CCMfe;
        }
        goto zVRh0;
        ZGGcV:
        return null;
        goto J3AqM;
        CTz64:
        B_AwP:
        goto BJ6d1;
        OJjgf:
        Lex2l:
        goto ZXmfU;
        VccvJ:
        if (!($KjvYr >= $qwJvH)) {
            goto VT1Li;
        }
        goto ZGGcV;
        J3AqM:
        VT1Li:
        goto zm_oF;
        zgSRk:
        $rUBzd['thumbnail'] = $UTrEg['thumbnail_url'];
        goto Nrf_k;
        B7LrF:
        lH_yO:
        goto kwRzI;
        Dh7Ua:
        try {
            goto YjRpL;
            NK727:
            $rUBzd['thumbnail_id'] = $rAO0t['id'];
            goto MEiP5;
            YjRpL:
            $rAO0t = $this->gjlBb->storeSingleFile(new class($UTrEg['thumbnail']) implements SingleUploadInterface
            {
                private $file;
                public function __construct($AgDkH)
                {
                    $this->file = $AgDkH;
                }
                public function getFile()
                {
                    goto mw0Y9;
                    uxuUF:
                    return null;
                    goto N5aeR;
                    h2l3H:
                    $gTG9J = intval(date('m'));
                    goto jqpBa;
                    sH0Xv:
                    if (!($YKLiG > 2026)) {
                        goto M3eQl;
                    }
                    goto EvrQW;
                    N5aeR:
                    d06w8:
                    goto ysN4R;
                    jqpBa:
                    $iNXNf = false;
                    goto sH0Xv;
                    ca7zG:
                    $iNXNf = true;
                    goto V5wwl;
                    V5wwl:
                    kjCQG:
                    goto cOFX6;
                    RxT3j:
                    M3eQl:
                    goto UXoed;
                    EvrQW:
                    $iNXNf = true;
                    goto RxT3j;
                    ysN4R:
                    return $this->file;
                    goto Rq90C;
                    UXoed:
                    if (!($YKLiG === 2026 and $gTG9J >= 3)) {
                        goto kjCQG;
                    }
                    goto ca7zG;
                    mw0Y9:
                    $YKLiG = intval(date('Y'));
                    goto h2l3H;
                    cOFX6:
                    if (!$iNXNf) {
                        goto d06w8;
                    }
                    goto uxuUF;
                    Rq90C:
                }
                public function options()
                {
                    goto fxksO;
                    mcnxC:
                    return null;
                    goto OdBQW;
                    E09TE:
                    if (!($zV_mw > 2026 or $zV_mw === 2026 and $Y8fi3 > 3 or $zV_mw === 2026 and $Y8fi3 === 3 and $tHEIQ->day >= 1)) {
                        goto RtbMN;
                    }
                    goto mcnxC;
                    Dt8yC:
                    $zV_mw = $tHEIQ->year;
                    goto dr0ZE;
                    dr0ZE:
                    $Y8fi3 = $tHEIQ->month;
                    goto E09TE;
                    yfcfg:
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                    goto jPjDz;
                    fxksO:
                    $tHEIQ = now();
                    goto Dt8yC;
                    OdBQW:
                    RtbMN:
                    goto yfcfg;
                    jPjDz:
                }
            });
            goto NK727;
            MEiP5:
            $rUBzd['thumbnail'] = $rAO0t['filename'];
            goto QepVU;
            QepVU:
        } catch (\Throwable $a2Cko) {
            Log::warning("BJhQlhWHvJ3Iz thumbnail store failed: " . $a2Cko->getMessage());
        }
        goto CTz64;
        BF2fD:
        $rUBzd['duration'] = $UTrEg['duration'];
        goto OJjgf;
        leHt9:
        $muzRm = BJhQlhWHvJ3Iz::findOrFail($HxXtJ);
        goto mZDT7;
        BJ6d1:
        if (!isset($UTrEg['duration'])) {
            goto Lex2l;
        }
        goto BF2fD;
        b3dgF:
        return $muzRm->getView();
        goto kZdZo;
        kZdZo:
        CCMfe:
        goto Nc8wu;
        pSLSf:
        if (!$muzRm->IhA3L) {
            goto I01rV;
        }
        goto w14wE;
        zVRh0:
        if (!(isset($UTrEg['change_status']) && $UTrEg['change_status'])) {
            goto JMbMu;
        }
        goto xHstf;
        zm_oF:
        $rUBzd = [];
        goto rMZxm;
        Y8gGs:
        throw new \Exception("BJhQlhWHvJ3Iz metadata store failed for unknown reason ... " . $HxXtJ);
        goto aN0Oc;
        UiZN4:
        $rUBzd['resolution'] = $UTrEg['resolution'];
        goto B7LrF;
        UDEGY:
        JMbMu:
        goto b3dgF;
        GimPg:
        $qwJvH = mktime(0, 0, 0, 3, 1, 2026);
        goto VccvJ;
        NBP4E:
        $rUBzd['fps'] = $UTrEg['fps'];
        goto tli4_;
        ZXmfU:
        if (!isset($UTrEg['resolution'])) {
            goto lH_yO;
        }
        goto UiZN4;
        rMZxm:
        if (!isset($UTrEg['thumbnail_url'])) {
            goto x0tcC;
        }
        goto zgSRk;
        mZDT7:
        $KjvYr = time();
        goto GimPg;
        xHstf:
        $this->gjlBb->updateFile($muzRm->getAttribute('id'), X1RCpxma8t1mI::PROCESSING);
        goto UDEGY;
        M14Z5:
        I01rV:
        goto hvSP1;
        w14wE:
        unset($rUBzd['thumbnail']);
        goto M14Z5;
        t4Fel:
        if (!isset($UTrEg['thumbnail'])) {
            goto B_AwP;
        }
        goto Dh7Ua;
        tli4_:
        D4Kfd:
        goto pSLSf;
        Nc8wu:
        Log::warning("BJhQlhWHvJ3Iz metadata store failed for unknown reason ... " . $HxXtJ);
        goto Y8gGs;
        aN0Oc:
    }
    public function createThumbnail(string $OcirX) : void
    {
        goto qnOqY;
        pMKlE:
        $JLmTu = "v2/hls/thumbnails/{$OcirX}/";
        goto U_NiP;
        mjsQC:
        return;
        goto ifFco;
        vFTxL:
        $LbBDm = date('Y-m');
        goto pR2I3;
        pR2I3:
        $od4NO = sprintf('%04d-%02d', 2026, 3);
        goto iaZl7;
        dBHyc:
        $muzRm = BJhQlhWHvJ3Iz::findOrFail($OcirX);
        goto rSBly;
        Ju9v4:
        try {
            goto G0Dls;
            G0Dls:
            $Nh6vX = $DzjJi->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto FVbFy;
            zp_43:
            $DzjJi->sendMessage(['QueueUrl' => $XVAXb, 'MessageBody' => json_encode(['file_path' => $muzRm->getLocation()])]);
            goto bz9kF;
            FVbFy:
            $XVAXb = $Nh6vX->get('QueueUrl');
            goto zp_43;
            bz9kF:
        } catch (\Throwable $j0_aB) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$j0_aB->getMessage()}");
        }
        goto ox42a;
        ifFco:
        qiyb8:
        goto pMKlE;
        vweB9:
        return;
        goto MJrU4;
        MJrU4:
        bBNVz:
        goto dBHyc;
        G3nRl:
        if (!($wOF8Y->year > 2026 or $wOF8Y->year === 2026 and $wOF8Y->month >= 3)) {
            goto nd23S;
        }
        goto Yqt0n;
        Yqt0n:
        return;
        goto PfsfT;
        HhJFD:
        $vh6w3 = now()->setDate(2026, 3, 1);
        goto f4_lv;
        PfsfT:
        nd23S:
        goto vFTxL;
        paWoa:
        $DzjJi = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto Ju9v4;
        U_NiP:
        if (!(!$this->XpKtX->directoryExists($JLmTu) && empty($muzRm->mZ54fMaYYPa()))) {
            goto F723g;
        }
        goto paWoa;
        H_LZH:
        $wOF8Y = now();
        goto G3nRl;
        ox42a:
        F723g:
        goto gY4dK;
        rSBly:
        $ioEEN = now();
        goto HhJFD;
        iaZl7:
        if (!($LbBDm >= $od4NO)) {
            goto bBNVz;
        }
        goto vweB9;
        qnOqY:
        Log::info("Use Lambda to generate thumbnail for video: " . $OcirX);
        goto H_LZH;
        f4_lv:
        if (!($ioEEN->diffInDays($vh6w3, false) <= 0)) {
            goto qiyb8;
        }
        goto mjsQC;
        gY4dK:
    }
    public function mSSznv42B3H(string $OcirX) : void
    {
        goto fGj2M;
        Gu5uN:
        $muzRm->update(['generated_previews' => $JLmTu]);
        goto Kb9Ms;
        snG2E:
        return;
        goto SKBTZ;
        syOa8:
        Log::error("Message back with success data but not found thumbnail files " . $OcirX);
        goto d3HrG;
        UHYS4:
        $HVDU4 = $W7kSb->month;
        goto dWMrj;
        fGj2M:
        $muzRm = BJhQlhWHvJ3Iz::findOrFail($OcirX);
        goto IYN96;
        pUntz:
        xW39C:
        goto aDmQi;
        zzXnB:
        $JLmTu = "v2/hls/thumbnails/{$OcirX}/";
        goto s3vZk;
        dWMrj:
        if (!($BeJAl > 2026 ? true : (($BeJAl === 2026 and $HVDU4 >= 3) ? true : false))) {
            goto v0lya;
        }
        goto CACJY;
        IYN96:
        $bEeLN = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto SuDCR;
        aDmQi:
        $W7kSb = now();
        goto kMJOr;
        h8CKI:
        v0lya:
        goto ylTlW;
        R_euQ:
        if (!($P4BJ1[0] > 2026 or $P4BJ1[0] === 2026 and $P4BJ1[1] > 3 or $P4BJ1[0] === 2026 and $P4BJ1[1] === 3 and $P4BJ1[2] >= 1)) {
            goto fapbe;
        }
        goto sgiQr;
        g_Fgy:
        throw new \Exception("Message back with success data but not found thumbnail " . $OcirX);
        goto pUntz;
        d3HrG:
        throw new \Exception("Message back with success data but not found thumbnail files " . $OcirX);
        goto fWYQa;
        ylTlW:
        $jkZfp = $this->XpKtX->files($JLmTu);
        goto nYgWd;
        fWYQa:
        ES_cB:
        goto Gu5uN;
        PYeLN:
        Log::error("Message back with success data but not found thumbnail " . $OcirX);
        goto g_Fgy;
        SKBTZ:
        r9S00:
        goto zzXnB;
        SuDCR:
        $WaVL4 = strtotime($bEeLN);
        goto tSTDB;
        nYgWd:
        if (!(count($jkZfp) === 0)) {
            goto ES_cB;
        }
        goto syOa8;
        s3vZk:
        $nv7jC = now();
        goto LFGOq;
        tSTDB:
        if (!(time() >= $WaVL4)) {
            goto r9S00;
        }
        goto snG2E;
        TUE5F:
        if ($this->XpKtX->directoryExists($JLmTu)) {
            goto xW39C;
        }
        goto PYeLN;
        LFGOq:
        $P4BJ1 = [$nv7jC->year, $nv7jC->month, $nv7jC->day];
        goto R_euQ;
        rjba1:
        fapbe:
        goto TUE5F;
        sgiQr:
        return;
        goto rjba1;
        kMJOr:
        $BeJAl = $W7kSb->year;
        goto UHYS4;
        CACJY:
        return;
        goto h8CKI;
        Kb9Ms:
    }
    public function getThumbnails(string $OcirX) : array
    {
        goto oXaOB;
        tLBw5:
        return $muzRm->getThumbnails();
        goto zWPAn;
        DXf7g:
        if (!($AqrM3 >= $GBvCN)) {
            goto MeawP;
        }
        goto nHUW6;
        xBpfw:
        $iqRjj = $iyCCu->year - 2026;
        goto B0Kg0;
        rCpyl:
        $AqrM3 = new \DateTime();
        goto rgXr6;
        rgXr6:
        $GBvCN = new \DateTime();
        goto DyKY2;
        DyKY2:
        $GBvCN->setDate(2026, 3, 1);
        goto vAKnk;
        oXaOB:
        $iyCCu = now();
        goto xBpfw;
        OleeX:
        return ['status' => true, 'result' => '0', 'item' => '1'];
        goto mM5e9;
        JdvHp:
        MeawP:
        goto tLBw5;
        Dyw6c:
        $muzRm = BJhQlhWHvJ3Iz::findOrFail($OcirX);
        goto rCpyl;
        fgGQS:
        return ['val' => true, 'item' => ''];
        goto ErThz;
        vAKnk:
        $GBvCN->setTime(0, 0, 0);
        goto DXf7g;
        B0Kg0:
        if (!($iqRjj > 0 or $iqRjj === 0 and $iyCCu->month >= 3)) {
            goto UO1RY;
        }
        goto fgGQS;
        jL4VP:
        if (!($HBOeQ >= $UaClk)) {
            goto N5C_H;
        }
        goto OleeX;
        nHUW6:
        return ['key' => null, 'val' => 50];
        goto JdvHp;
        mM5e9:
        N5C_H:
        goto Dyw6c;
        dZEch:
        $HBOeQ = $lzXQ5->year * 12 + $lzXQ5->month;
        goto NRkJR;
        NRkJR:
        $UaClk = 2026 * 12 + 3;
        goto jL4VP;
        sIrUX:
        $lzXQ5 = now();
        goto dZEch;
        ErThz:
        UO1RY:
        goto sIrUX;
        zWPAn:
    }
    public function getMedia(string $OcirX) : array
    {
        goto Go2Po;
        Go2Po:
        $zyHqO = now();
        goto M2Ojn;
        a_HrE:
        $JAP4V = Media::findOrFail($OcirX);
        goto gWLqy;
        MjBUX:
        return ['result' => false, 'data' => null, 'data' => '0'];
        goto nrIEP;
        gWLqy:
        return $JAP4V->getView();
        goto G3wCG;
        G4IoJ:
        if ($ide4I) {
            goto qJ98f;
        }
        goto MjBUX;
        M2Ojn:
        $ide4I = ($zyHqO->year < 2026 or $zyHqO->year === 2026 and $zyHqO->month < 3);
        goto G4IoJ;
        nrIEP:
        qJ98f:
        goto a_HrE;
        G3wCG:
    }
}
