<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Core\Observer\S3SDRlCvwlTH3;
use Jfs\Uploader\Core\Observer\Ql15qMvLic9ux;
use Jfs\Uploader\Core\ZwUpr8c0hc8qN;
use Jfs\Uploader\Core\Z4Tul5rPROvzh;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Exception\IgLoDg5bjroxA;
use Jfs\Uploader\Service\FileResolver\Xx9PGVcJPphhb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class CYgJOMj8wExPk
{
    private $eTozC;
    private $P8Yzg;
    private $RE_2F;
    public function __construct($Xm4zz, $jT0xz, $WmwnR)
    {
        goto Zh4KF;
        Zh4KF:
        $this->eTozC = $Xm4zz;
        goto wwJw0;
        jHJOd:
        $this->RE_2F = $WmwnR;
        goto UF2OV;
        wwJw0:
        $this->P8Yzg = $jT0xz;
        goto jHJOd;
        UF2OV:
    }
    public function moVlbNp73q6($SOogy)
    {
        goto HQcjI;
        KvMcr:
        $QTjfq = $SOogy->getFile();
        goto d0r_N;
        cuPeR:
        return $this->mTFUa9QTtBd($SOogy['file_extension'], 's3' === $SOogy['driver'] ? EzGWviwQDmAwI::S3 : EzGWviwQDmAwI::LOCAL);
        goto byeaT;
        HQcjI:
        if (!$SOogy instanceof SingleUploadInterface) {
            goto d1XFQ;
        }
        goto KvMcr;
        bdvIU:
        d1XFQ:
        goto cuPeR;
        d0r_N:
        return $this->mTFUa9QTtBd($QTjfq->extension(), EzGWviwQDmAwI::S3, null, $SOogy->options());
        goto bdvIU;
        byeaT:
    }
    public function mNMIxO04xMD(string $LpGEK)
    {
        goto FVyhM;
        k3Qy_:
        $RCdwx->exists = true;
        goto fjlnm;
        fjlnm:
        $RCdwx->setRawAttributes($x95Gi->getAttributes());
        goto LElkC;
        LElkC:
        return $RCdwx;
        goto U3jXo;
        FVyhM:
        $x95Gi = config('upload.attachment_model')::findOrFail($LpGEK);
        goto qmuH5;
        qmuH5:
        $RCdwx = $this->mTFUa9QTtBd($x95Gi->getAttribute('type'), $x95Gi->getAttribute('driver'), $x95Gi->getAttribute('id'));
        goto k3Qy_;
        U3jXo:
    }
    public function mjowAcEjDR3(string $bnMMP) : MB8DYpNdVV1bz
    {
        goto BUntK;
        I7stq:
        $SaEd8 = json_decode($JjvkS, true);
        goto I24dg;
        fbyYv:
        throw new OLKFtR17budEQ('metadata file not found');
        goto Np43B;
        dSiQr:
        Sl2Py:
        goto I7stq;
        I24dg:
        if (!$SaEd8) {
            goto BJnW7;
        }
        goto ulzhC;
        kKNe8:
        if ($JjvkS) {
            goto Sl2Py;
        }
        goto avCTZ;
        CI3kI:
        BJnW7:
        goto fbyYv;
        ulzhC:
        $DLk9Y = Z4Tul5rPROvzh::mwsiK5ghIKF($SaEd8);
        goto R22qY;
        R22qY:
        return $this->mTFUa9QTtBd($DLk9Y->YRAxZ, $DLk9Y->mThngkFXA4R(), $DLk9Y->filename);
        goto CI3kI;
        avCTZ:
        $JjvkS = $this->RE_2F->get($bnMMP);
        goto dSiQr;
        BUntK:
        $JjvkS = $this->P8Yzg->get($bnMMP);
        goto kKNe8;
        Np43B:
    }
    private function mTFUa9QTtBd(string $YN8Mo, $dVQ7P, ?string $LpGEK = null, array $fXXZn = [])
    {
        goto MIeyS;
        BPWbY:
        ybycX:
        goto gMhZ0;
        k3ve6:
        switch ($YN8Mo) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $CeqrK = X9YHjKrAdcfhe::createFromScratch($LpGEK, $YN8Mo);
                goto j75Un;
            case 'mp4':
            case 'mov':
                $CeqrK = Jf5KRr8uE3t34::createFromScratch($LpGEK, $YN8Mo);
                goto j75Un;
            case 'pdf':
                $CeqrK = ZwUpr8c0hc8qN::createFromScratch($LpGEK, $YN8Mo);
                goto j75Un;
            default:
                throw new IgLoDg5bjroxA("not support file type {$YN8Mo}");
        }
        goto oKfZM;
        Oe_sv:
        j75Un:
        goto LN1M_;
        LN1M_:
        $CeqrK = $CeqrK->mr47iwJw7QB($dVQ7P);
        goto ZKEzH;
        lujnG:
        foreach ($this->eTozC as $BkHR5) {
            goto ICtuW;
            PsTiN:
            return $CeqrK->initLocation($BkHR5->mIu6wGqIDWx($CeqrK));
            goto lTRnJ;
            ICtuW:
            if (!$BkHR5->m43iLY4iJnJ($CeqrK)) {
                goto azHCL;
            }
            goto PsTiN;
            lTRnJ:
            azHCL:
            goto lAUZF;
            lAUZF:
            RUiZq:
            goto IcJtL;
            IcJtL:
        }
        goto BPWbY;
        MIeyS:
        $LpGEK = $LpGEK ?? Uuid::uuid4()->getHex()->toString();
        goto k3ve6;
        ZKEzH:
        $CeqrK->mYvBQMWkcb5(new S3SDRlCvwlTH3($CeqrK));
        goto xwhRe;
        gMhZ0:
        throw new IgLoDg5bjroxA("not support file type {$YN8Mo}");
        goto C6k8u;
        oKfZM:
        s3znn:
        goto Oe_sv;
        xwhRe:
        $CeqrK->mYvBQMWkcb5(new Ql15qMvLic9ux($CeqrK, $this->RE_2F, $fXXZn));
        goto lujnG;
        C6k8u:
    }
}
