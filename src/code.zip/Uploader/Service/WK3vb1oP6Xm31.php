<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
final class WK3vb1oP6Xm31
{
    private $Jbhpc;
    private $U2nFC;
    private $N3F9R;
    public function __construct(string $A745z, string $KJVQQ, Filesystem $mFX9i)
    {
        goto nnOWw;
        AFjpw:
        $this->N3F9R = $mFX9i;
        goto cXkFn;
        nnOWw:
        $this->Jbhpc = $A745z;
        goto f5vTg;
        f5vTg:
        $this->U2nFC = $KJVQQ;
        goto AFjpw;
        cXkFn:
    }
    public function mAorBMY1NcM(UKWxL8i4Jx2NZ $xKDWF) : string
    {
        goto a4AJz;
        GFEge:
        MSKO8:
        goto O0f4Z;
        I7BiK:
        return 's3://' . $this->Jbhpc . '/' . $xKDWF->getAttribute('filename');
        goto GFEge;
        a4AJz:
        if (!(WG4kCv0INtCV4::S3 == $xKDWF->getAttribute('driver'))) {
            goto MSKO8;
        }
        goto I7BiK;
        O0f4Z:
        return $this->N3F9R->url($xKDWF->getAttribute('filename'));
        goto r9Dux;
        r9Dux:
    }
    public function mgvMVogHFjU(?string $AGOMy) : ?string
    {
        goto k62gb;
        NpS54:
        $IB9Pt = parse_url($AGOMy, PHP_URL_PATH);
        goto LfuJB;
        C7dHi:
        return null;
        goto Zf080;
        LfuJB:
        return 's3://' . $this->Jbhpc . '/' . ltrim($IB9Pt, '/');
        goto oSWia;
        oSWia:
        c_bGq:
        goto ovgJe;
        k62gb:
        if (!$AGOMy) {
            goto L_WMj;
        }
        goto hDUXH;
        ovgJe:
        L_WMj:
        goto C7dHi;
        hDUXH:
        if (!Frbwd($AGOMy, $this->Jbhpc)) {
            goto c_bGq;
        }
        goto NpS54;
        Zf080:
    }
    public function mfEtqflWIF3(string $IB9Pt) : string
    {
        return 's3://' . $this->Jbhpc . '/' . $IB9Pt;
    }
}
