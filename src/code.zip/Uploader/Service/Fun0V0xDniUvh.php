<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\JGFha5eJXVoQK;
use Jfs\Uploader\Core\GYWdiuSbqNHgT;
use Jfs\Uploader\Core\FUCc1kyYZtja3;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
use Jfs\Uploader\Exception\Z1EmnB00QcmrE;
use Jfs\Uploader\Exception\DbtXptYiNGheI;
use Jfs\Uploader\Exception\KkJ7iB3slsUjq;
final class Fun0V0xDniUvh implements UploadServiceInterface
{
    private $sSbey;
    private $bX3fI;
    private $UAt4g;
    private $KMszH;
    public function __construct(VRKkgi2bc4uRE $nAuRn, Filesystem $Q0hWX, Filesystem $RdfoB, string $UBqrO)
    {
        goto hhUsq;
        hhUsq:
        $this->sSbey = $nAuRn;
        goto lB1nO;
        rEtqQ:
        $this->UAt4g = $RdfoB;
        goto Gf_ex;
        Gf_ex:
        $this->KMszH = $UBqrO;
        goto ljg4y;
        lB1nO:
        $this->bX3fI = $Q0hWX;
        goto rEtqQ;
        ljg4y:
    }
    public function storeSingleFile(SingleUploadInterface $dqyba) : array
    {
        goto i0wso;
        eptd8:
        return $QuYzZ->getView();
        goto ZTNT2;
        D6tPV:
        if (false !== $JM0UK && $QuYzZ instanceof JGFha5eJXVoQK) {
            goto N41Fy;
        }
        goto zH6NW;
        GnsHE:
        goto Uzpxd;
        goto G9FIM;
        TVuV8:
        Uzpxd:
        goto eptd8;
        zH6NW:
        throw new \LogicException('File upload failed, check permissions');
        goto GnsHE;
        Hyb1J:
        $QuYzZ->mVwoe0E3Z3I(QoCMzcKvH8Cw2::UPLOADED);
        goto TVuV8;
        G9FIM:
        N41Fy:
        goto Hyb1J;
        fncgI:
        $JM0UK = $this->UAt4g->putFileAs(dirname($QuYzZ->getLocation()), $dqyba->getFile(), $QuYzZ->getFilename() . '.' . $QuYzZ->getExtension(), ['visibility' => 'public']);
        goto D6tPV;
        i0wso:
        $QuYzZ = $this->sSbey->mH6KTH4GAyq($dqyba);
        goto fncgI;
        ZTNT2:
    }
    public function storePreSignedFile(array $i_un9)
    {
        goto g0C7E;
        SZCzd:
        $ld3oH->mljBX6varR4($i_un9['mime'], $i_un9['file_size'], $i_un9['chunk_size'], $i_un9['checksums'], $i_un9['user_id'], $i_un9['driver']);
        goto qURcB;
        qURcB:
        $ld3oH->miBesHZJWLk();
        goto sv9w4;
        ebrwT:
        $ld3oH = FUCc1kyYZtja3::mwh2q3yWrxX($QuYzZ, $this->bX3fI, $this->UAt4g, $this->KMszH, true);
        goto SZCzd;
        sv9w4:
        return ['filename' => $ld3oH->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $ld3oH->mz2SyXwjq0Q()];
        goto kS7a8;
        g0C7E:
        $QuYzZ = $this->sSbey->mH6KTH4GAyq($i_un9);
        goto ebrwT;
        kS7a8:
    }
    public function updatePreSignedFile(string $NdYXZ, int $pKysJ)
    {
        goto Gdl4g;
        Gdl4g:
        $ld3oH = FUCc1kyYZtja3::m4JkzRY3KVI($NdYXZ, $this->bX3fI, $this->UAt4g, $this->KMszH);
        goto iqZ6T;
        iqZ6T:
        switch ($pKysJ) {
            case QoCMzcKvH8Cw2::UPLOADED:
                $ld3oH->mmCSQPib4jl();
                goto E4k_Z;
            case QoCMzcKvH8Cw2::PROCESSING:
                $ld3oH->mjSXa8Ftxu0();
                goto E4k_Z;
            case QoCMzcKvH8Cw2::FINISHED:
                $ld3oH->mBoWi6Q7mka();
                goto E4k_Z;
            case QoCMzcKvH8Cw2::ABORTED:
                $ld3oH->mEkyhuJA3e0();
                goto E4k_Z;
        }
        goto Vnsgu;
        XYSWG:
        E4k_Z:
        goto VLDFT;
        Vnsgu:
        yqJcY:
        goto XYSWG;
        VLDFT:
    }
    public function completePreSignedFile(string $NdYXZ, array $MF1dT)
    {
        goto wWglV;
        vJkXC:
        return ['path' => $ld3oH->getFile()->getView()['path'], 'thumbnail' => $ld3oH->getFile()->VPjF9, 'id' => $NdYXZ];
        goto BKVgR;
        wWglV:
        $ld3oH = FUCc1kyYZtja3::m4JkzRY3KVI($NdYXZ, $this->bX3fI, $this->UAt4g, $this->KMszH);
        goto LUueg;
        cEdGi:
        $ld3oH->mmCSQPib4jl();
        goto vJkXC;
        LUueg:
        $ld3oH->mkBf6Gw5jFn()->mItmJG4vJnm($MF1dT);
        goto cEdGi;
        BKVgR:
    }
    public function updateFile(string $NdYXZ, int $pKysJ) : GYWdiuSbqNHgT
    {
        goto sNMDX;
        LJ9uP:
        $QuYzZ->mVwoe0E3Z3I($pKysJ);
        goto veqa3;
        sNMDX:
        $QuYzZ = $this->sSbey->mGWQRgYK3NA($NdYXZ);
        goto LJ9uP;
        veqa3:
        return $QuYzZ;
        goto VbX09;
        VbX09:
    }
}
