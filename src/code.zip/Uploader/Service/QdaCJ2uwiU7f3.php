<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class QdaCJ2uwiU7f3 implements VideoPostHandleServiceInterface
{
    private $BAhsc;
    private $aiw3M;
    public function __construct(UploadServiceInterface $JjEev, Filesystem $iay5S)
    {
        $this->BAhsc = $JjEev;
        $this->aiw3M = $iay5S;
    }
    public function saveMetadata(string $zV1kl, array $OFuou)
    {
        goto Hj6iC;
        jd6iV:
        if (!isset($OFuou['resolution'])) {
            goto pJ3Mm;
        }
        goto agOp2;
        Glm5p:
        if (!isset($OFuou['duration'])) {
            goto pt42Y;
        }
        goto l7djp;
        ZTIUc:
        WOP01:
        goto ZWRQ2;
        vcS_h:
        $this->BAhsc->updateFile($EVGvq->getAttribute('id'), M7O7NSiJU2JG5::PROCESSING);
        goto sH3wF;
        ZWRQ2:
        if (!$EVGvq->update($rHDGG)) {
            goto U30IP;
        }
        goto WLjFz;
        Ou6K3:
        if (!isset($OFuou['thumbnail'])) {
            goto nFYhi;
        }
        goto yaHBJ;
        gEl2Q:
        $rHDGG['thumbnail'] = $OFuou['thumbnail_url'];
        goto xX6z1;
        l7djp:
        $rHDGG['duration'] = $OFuou['duration'];
        goto fWNRR;
        S7MqR:
        return $EVGvq->getView();
        goto M23DY;
        Hj6iC:
        $EVGvq = UYo98bF5lKEmO::findOrFail($zV1kl);
        goto MODQO;
        M23DY:
        U30IP:
        goto c84o9;
        AhMPT:
        $rHDGG['fps'] = $OFuou['fps'];
        goto VNp4_;
        Qy1b8:
        if (!$EVGvq->u4XxL) {
            goto WOP01;
        }
        goto kf24B;
        xX6z1:
        dh_4c:
        goto Ou6K3;
        OoGAq:
        throw new \Exception("UYo98bF5lKEmO metadata store failed for unknown reason ... " . $zV1kl);
        goto vK3sg;
        YFrRB:
        pJ3Mm:
        goto LRFkC;
        MODQO:
        $rHDGG = [];
        goto aySrq;
        WLjFz:
        if (!(isset($OFuou['change_status']) && $OFuou['change_status'])) {
            goto VlQCf;
        }
        goto vcS_h;
        yaHBJ:
        try {
            goto Es1Im;
            Es1Im:
            $X9APK = $this->BAhsc->storeSingleFile(new class($OFuou['thumbnail']) implements SingleUploadInterface
            {
                private $YG65u;
                public function __construct($Z5ydB)
                {
                    $this->YG65u = $Z5ydB;
                }
                public function getFile()
                {
                    return $this->YG65u;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto yqaKh;
            yqaKh:
            $rHDGG['thumbnail_id'] = $X9APK['id'];
            goto gb7AA;
            gb7AA:
            $rHDGG['thumbnail'] = $X9APK['filename'];
            goto ic7Br;
            ic7Br:
        } catch (\Throwable $VJRSZ) {
            Log::warning("UYo98bF5lKEmO thumbnail store failed: " . $VJRSZ->getMessage());
        }
        goto r7uJp;
        sH3wF:
        VlQCf:
        goto S7MqR;
        LRFkC:
        if (!isset($OFuou['fps'])) {
            goto P8Mnd;
        }
        goto AhMPT;
        kf24B:
        unset($rHDGG['thumbnail']);
        goto ZTIUc;
        VNp4_:
        P8Mnd:
        goto Qy1b8;
        r7uJp:
        nFYhi:
        goto Glm5p;
        aySrq:
        if (!isset($OFuou['thumbnail_url'])) {
            goto dh_4c;
        }
        goto gEl2Q;
        agOp2:
        $rHDGG['resolution'] = $OFuou['resolution'];
        goto YFrRB;
        fWNRR:
        pt42Y:
        goto jd6iV;
        c84o9:
        Log::warning("UYo98bF5lKEmO metadata store failed for unknown reason ... " . $zV1kl);
        goto OoGAq;
        vK3sg:
    }
    public function createThumbnail(string $N555I) : void
    {
        goto DpRIt;
        Indzu:
        $sQ5Vj = "v2/hls/thumbnails/{$N555I}/";
        goto Sbq2x;
        Sbq2x:
        if (!(!$this->aiw3M->directoryExists($sQ5Vj) && empty($EVGvq->mFDStEnPbwd()))) {
            goto WUERJ;
        }
        goto r9agl;
        OX1yK:
        try {
            goto wqLJq;
            NsPdE:
            $aahJM->sendMessage(['QueueUrl' => $PzOew, 'MessageBody' => json_encode(['file_path' => $EVGvq->getLocation()])]);
            goto XWtGh;
            wqLJq:
            $OSnqs = $aahJM->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto UROg6;
            UROg6:
            $PzOew = $OSnqs->get('QueueUrl');
            goto NsPdE;
            XWtGh:
        } catch (\Throwable $nV19i) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$nV19i->getMessage()}");
        }
        goto yL2mK;
        r9agl:
        $aahJM = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto OX1yK;
        Gur32:
        $EVGvq = UYo98bF5lKEmO::findOrFail($N555I);
        goto Indzu;
        yL2mK:
        WUERJ:
        goto r5jSR;
        DpRIt:
        Log::info("Use Lambda to generate thumbnail for video: " . $N555I);
        goto Gur32;
        r5jSR:
    }
    public function mv8ncDuGoxL(string $N555I) : void
    {
        goto B51h2;
        LE0Ob:
        TWbdI:
        goto HS6dI;
        Pir8Q:
        $SIBhP = $this->aiw3M->files($sQ5Vj);
        goto mQtPZ;
        rRoTS:
        $sQ5Vj = "v2/hls/thumbnails/{$N555I}/";
        goto K6tSg;
        hVGMB:
        Log::error("Message back with success data but not found thumbnail " . $N555I);
        goto KGt2y;
        HS6dI:
        $EVGvq->update(['generated_previews' => $sQ5Vj]);
        goto Go953;
        KGt2y:
        throw new \Exception("Message back with success data but not found thumbnail " . $N555I);
        goto uewqo;
        B51h2:
        $EVGvq = UYo98bF5lKEmO::findOrFail($N555I);
        goto rRoTS;
        yiF34:
        throw new \Exception("Message back with success data but not found thumbnail files " . $N555I);
        goto LE0Ob;
        K6tSg:
        if ($this->aiw3M->directoryExists($sQ5Vj)) {
            goto pL4Au;
        }
        goto hVGMB;
        mQtPZ:
        if (!(count($SIBhP) === 0)) {
            goto TWbdI;
        }
        goto uukYw;
        uewqo:
        pL4Au:
        goto Pir8Q;
        uukYw:
        Log::error("Message back with success data but not found thumbnail files " . $N555I);
        goto yiF34;
        Go953:
    }
    public function getThumbnails(string $N555I) : array
    {
        $EVGvq = UYo98bF5lKEmO::findOrFail($N555I);
        return $EVGvq->getThumbnails();
    }
    public function getMedia(string $N555I) : array
    {
        $zacay = Media::findOrFail($N555I);
        return $zacay->getView();
    }
}
