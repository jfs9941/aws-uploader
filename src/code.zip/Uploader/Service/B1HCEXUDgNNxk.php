<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Core\Observer\W5RHn15ZxBOgZ;
use Jfs\Uploader\Core\Observer\LWyHsnHVJ7f6T;
use Jfs\Uploader\Core\PvOVRr4EuSa8e;
use Jfs\Uploader\Core\YOSIkvkyMSIKR;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Exception\NxfDNhkjIm1nw;
use Jfs\Uploader\Service\FileResolver\UTeyx3rE4BuDl;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class B1HCEXUDgNNxk
{
    private $TDA8h;
    private $FHcNr;
    private $VJN91;
    public function __construct($QM7uk, $z279S, $J83Op)
    {
        goto t3O_w;
        kym5i:
        $this->FHcNr = $z279S;
        goto UHrMV;
        UHrMV:
        $this->VJN91 = $J83Op;
        goto tGSKb;
        t3O_w:
        $this->TDA8h = $QM7uk;
        goto kym5i;
        tGSKb:
    }
    public function muNv0MUfhR1($knNY9)
    {
        goto XaPFc;
        bWlOk:
        return $this->mVtMcXXO83v($knNY9['file_extension'], 's3' === $knNY9['driver'] ? Pj539Ru5gyMbt::S3 : Pj539Ru5gyMbt::LOCAL);
        goto CX01W;
        Qz76Q:
        $hg8P1 = $knNY9->getFile();
        goto AcfQV;
        Q4Pur:
        Rr1nP:
        goto bWlOk;
        XaPFc:
        if (!$knNY9 instanceof SingleUploadInterface) {
            goto Rr1nP;
        }
        goto Qz76Q;
        AcfQV:
        return $this->mVtMcXXO83v($hg8P1->extension(), Pj539Ru5gyMbt::S3, null, $knNY9->options());
        goto Q4Pur;
        CX01W:
    }
    public function mQZkuaB2q4d(string $wAkkA)
    {
        goto zfOgY;
        pUIro:
        $K9DZL = $this->mVtMcXXO83v($OwKVg->getAttribute('type'), $OwKVg->getAttribute('driver'), $OwKVg->getAttribute('id'));
        goto hIgVT;
        KcIR7:
        $K9DZL->setRawAttributes($OwKVg->getAttributes());
        goto isQfK;
        isQfK:
        return $K9DZL;
        goto D3qDM;
        zfOgY:
        $OwKVg = config('upload.attachment_model')::findOrFail($wAkkA);
        goto pUIro;
        hIgVT:
        $K9DZL->exists = true;
        goto KcIR7;
        D3qDM:
    }
    public function mkPNWfQwT5u(string $rpsWV) : LKF23eYmlDs0w
    {
        goto k6k02;
        jwxRA:
        kdm8x:
        goto vWb1j;
        sGoW2:
        $KA7xg = $this->VJN91->get($rpsWV);
        goto AuMZ6;
        AuMZ6:
        o_iWX:
        goto tjlTc;
        k6k02:
        $KA7xg = $this->FHcNr->get($rpsWV);
        goto AkOv4;
        T_KnB:
        if (!$eSKpN) {
            goto kdm8x;
        }
        goto gK7Wo;
        AkOv4:
        if ($KA7xg) {
            goto o_iWX;
        }
        goto sGoW2;
        vWb1j:
        throw new LvyLnQ2Iyddt1('metadata file not found');
        goto adFCJ;
        tjlTc:
        $eSKpN = json_decode($KA7xg, true);
        goto T_KnB;
        gK7Wo:
        $dR8c0 = YOSIkvkyMSIKR::mX9azFknIp3($eSKpN);
        goto zNec7;
        zNec7:
        return $this->mVtMcXXO83v($dR8c0->e2m7j, $dR8c0->mFM26p1pjc0(), $dR8c0->filename);
        goto jwxRA;
        adFCJ:
    }
    private function mVtMcXXO83v(string $W4kN6, $G1ccT, ?string $wAkkA = null, array $RxjAn = [])
    {
        goto vFSU6;
        MXyzY:
        switch ($W4kN6) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $IaXcH = A9olNyGXhDJnA::createFromScratch($wAkkA, $W4kN6);
                goto IAGS0;
            case 'mp4':
            case 'mov':
                $IaXcH = WI5WSPGRr1b2t::createFromScratch($wAkkA, $W4kN6);
                goto IAGS0;
            case 'pdf':
                $IaXcH = PvOVRr4EuSa8e::createFromScratch($wAkkA, $W4kN6);
                goto IAGS0;
            default:
                throw new NxfDNhkjIm1nw("not support file type {$W4kN6}");
        }
        goto sALJ7;
        IsVDi:
        throw new NxfDNhkjIm1nw("not support file type {$W4kN6}");
        goto WGqxB;
        XrgoW:
        kJVOR:
        goto IsVDi;
        sALJ7:
        M9UcK:
        goto XNBRF;
        vFSU6:
        $wAkkA = $wAkkA ?? Uuid::uuid4()->getHex()->toString();
        goto MXyzY;
        iKJt0:
        foreach ($this->TDA8h as $JfOlX) {
            goto h0b0K;
            i9nqG:
            return $IaXcH->initLocation($JfOlX->mrpxgImfrf8($IaXcH));
            goto lwB3o;
            lwB3o:
            u6nTV:
            goto FvlbT;
            h0b0K:
            if (!$JfOlX->m8bnBZQeVfZ($IaXcH)) {
                goto u6nTV;
            }
            goto i9nqG;
            FvlbT:
            DAE4c:
            goto MJJCS;
            MJJCS:
        }
        goto XrgoW;
        d5H_R:
        $IaXcH->m0Xpg1VLHmO(new W5RHn15ZxBOgZ($IaXcH));
        goto Ukp68;
        Hh_s6:
        $IaXcH = $IaXcH->mfcWcvjrY3w($G1ccT);
        goto d5H_R;
        XNBRF:
        IAGS0:
        goto Hh_s6;
        Ukp68:
        $IaXcH->m0Xpg1VLHmO(new LWyHsnHVJ7f6T($IaXcH, $this->VJN91, $RxjAn));
        goto iKJt0;
        WGqxB:
    }
}
