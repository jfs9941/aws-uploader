<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Core\Observer\Oapdre1ziGKMT;
use Jfs\Uploader\Core\Observer\AeijDznoes1FO;
use Jfs\Uploader\Core\DrXBch7yBj5qf;
use Jfs\Uploader\Core\FB4qGXxRRUqXX;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Exception\Hs8uHMlcZHaHS;
use Jfs\Uploader\Service\FileResolver\Vos9aJIGFYrKk;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class S0Eg4TIBvz6Wk
{
    private $XB6FR;
    private $IdG3S;
    private $hFxUe;
    public function __construct($McMo4, $ftmEm, $KKbEP)
    {
        goto IWGag;
        IWGag:
        $this->XB6FR = $McMo4;
        goto qI1A_;
        zkymj:
        $this->hFxUe = $KKbEP;
        goto Q5r0v;
        qI1A_:
        $this->IdG3S = $ftmEm;
        goto zkymj;
        Q5r0v:
    }
    public function m7cwl4D8wFi($NUcE_)
    {
        goto v41PK;
        gGQA7:
        BJVOg:
        goto m8WdB;
        v41PK:
        if (!$NUcE_ instanceof SingleUploadInterface) {
            goto BJVOg;
        }
        goto vhP1S;
        o7eRW:
        return $this->m1EMntXP3ID($owoBw->extension(), Rf7fPQasmK9R3::S3, null, $NUcE_->options());
        goto gGQA7;
        vhP1S:
        $owoBw = $NUcE_->getFile();
        goto o7eRW;
        m8WdB:
        return $this->m1EMntXP3ID($NUcE_['file_extension'], 's3' === $NUcE_['driver'] ? Rf7fPQasmK9R3::S3 : Rf7fPQasmK9R3::LOCAL);
        goto PdV81;
        PdV81:
    }
    public function mwNZkm8EAWD(string $SEOXv)
    {
        goto FnhUW;
        E4iIw:
        $z620p = $this->m1EMntXP3ID($tL_UH->getAttribute('type'), $tL_UH->getAttribute('driver'), $tL_UH->getAttribute('id'));
        goto lyZ_5;
        FnhUW:
        $tL_UH = config('upload.attachment_model')::findOrFail($SEOXv);
        goto E4iIw;
        lyZ_5:
        $z620p->exists = true;
        goto uMuvW;
        uMuvW:
        $z620p->setRawAttributes($tL_UH->getAttributes());
        goto xgOYR;
        xgOYR:
        return $z620p;
        goto gnTSG;
        gnTSG:
    }
    public function mU3n1Ivg8jW(string $pmkZp) : N6d9ndnX4hqae
    {
        goto dZt11;
        vK30w:
        $Zdd8I = FB4qGXxRRUqXX::mL8fXp7GapT($W8N2W);
        goto jLR96;
        jLR96:
        return $this->m1EMntXP3ID($Zdd8I->zx_Nm, $Zdd8I->mVYxyAg5des(), $Zdd8I->filename);
        goto Kdegi;
        unlwn:
        $W8N2W = json_decode($bDZFO, true);
        goto KySaa;
        Kdegi:
        B1oBO:
        goto Vi2Tv;
        TVcw6:
        if ($bDZFO) {
            goto Zz8wc;
        }
        goto asEe_;
        dZt11:
        $bDZFO = $this->IdG3S->get($pmkZp);
        goto TVcw6;
        KySaa:
        if (!$W8N2W) {
            goto B1oBO;
        }
        goto vK30w;
        g7BOR:
        Zz8wc:
        goto unlwn;
        asEe_:
        $bDZFO = $this->hFxUe->get($pmkZp);
        goto g7BOR;
        Vi2Tv:
        throw new KWF9YuEFOPZRY('metadata file not found');
        goto ejlIo;
        ejlIo:
    }
    private function m1EMntXP3ID(string $t0nwn, $K8DFi, ?string $SEOXv = null, array $N33e6 = [])
    {
        goto YTOzQ;
        hMAEe:
        $W7KXm->mRlOizT0SxG(new Oapdre1ziGKMT($W7KXm));
        goto AYFAK;
        lMbos:
        throw new Hs8uHMlcZHaHS("not support file type {$t0nwn}");
        goto oBqsf;
        AYFAK:
        $W7KXm->mRlOizT0SxG(new AeijDznoes1FO($W7KXm, $this->hFxUe, $N33e6));
        goto VetzN;
        Abc1Q:
        Oiszm:
        goto lMbos;
        VetzN:
        foreach ($this->XB6FR as $rKcW0) {
            goto ioFx2;
            h57h2:
            PcU4q:
            goto coUT5;
            TUgzn:
            return $W7KXm->initLocation($rKcW0->mqskwBwLx22($W7KXm));
            goto Wft4P;
            Wft4P:
            lIKBS:
            goto h57h2;
            ioFx2:
            if (!$rKcW0->mUiB3m5cXoA($W7KXm)) {
                goto lIKBS;
            }
            goto TUgzn;
            coUT5:
        }
        goto Abc1Q;
        a1yzE:
        switch ($t0nwn) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $W7KXm = FmmY71eXk0D8U::createFromScratch($SEOXv, $t0nwn);
                goto OdMEC;
            case 'mp4':
            case 'mov':
                $W7KXm = IvT3V5jT5KEaA::createFromScratch($SEOXv, $t0nwn);
                goto OdMEC;
            case 'pdf':
                $W7KXm = DrXBch7yBj5qf::createFromScratch($SEOXv, $t0nwn);
                goto OdMEC;
            default:
                throw new Hs8uHMlcZHaHS("not support file type {$t0nwn}");
        }
        goto y0BBW;
        YTOzQ:
        $SEOXv = $SEOXv ?? Uuid::uuid4()->getHex()->toString();
        goto a1yzE;
        y0BBW:
        DPnaY:
        goto yNHWp;
        wfTsu:
        $W7KXm = $W7KXm->mIoe426fTH0($K8DFi);
        goto hMAEe;
        yNHWp:
        OdMEC:
        goto wfTsu;
        oBqsf:
    }
}
