<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Core\Observer\KrCJD18qpEqnY;
use Jfs\Uploader\Core\Observer\J3SiPGv4roNIq;
use Jfs\Uploader\Core\AvQy1eDjm0AkP;
use Jfs\Uploader\Core\X5zE8bFBbBVcm;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Exception\VTCsTRR34DAEZ;
use Jfs\Uploader\Service\FileResolver\QfOW6Hr4RJSCz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class PwjTg62cqDtZB
{
    private $m9JgX;
    private $IA8m0;
    private $f1xKj;
    public function __construct($bcWY9, $Rgxn3, $C6boj)
    {
        goto uWxym;
        WhHIw:
        $this->IA8m0 = $Rgxn3;
        goto dokpb;
        uWxym:
        $this->m9JgX = $bcWY9;
        goto WhHIw;
        dokpb:
        $this->f1xKj = $C6boj;
        goto k0bcc;
        k0bcc:
    }
    public function mLYT9Dr0S76($DyTUr)
    {
        goto TPXyX;
        Gv5A0:
        return $this->m6hPVE3OaAZ($DyTUr['file_extension'], 's3' === $DyTUr['driver'] ? Tq4KHV0o6oTIo::S3 : Tq4KHV0o6oTIo::LOCAL);
        goto qpdVD;
        THrfp:
        d58rW:
        goto Gv5A0;
        TPXyX:
        if (!$DyTUr instanceof SingleUploadInterface) {
            goto d58rW;
        }
        goto hDzi3;
        hDzi3:
        $tEsSr = $DyTUr->getFile();
        goto hWah8;
        hWah8:
        return $this->m6hPVE3OaAZ($tEsSr->extension(), Tq4KHV0o6oTIo::S3, null, $DyTUr->options());
        goto THrfp;
        qpdVD:
    }
    public function m8Yz5AURItB(string $g5e_r)
    {
        goto s5ojX;
        kY91V:
        $eQ4Ln = $this->m6hPVE3OaAZ($k3Lov->getAttribute('type'), $k3Lov->getAttribute('driver'), $k3Lov->getAttribute('id'));
        goto sYmM9;
        sYmM9:
        $eQ4Ln->exists = true;
        goto Pd13p;
        s5ojX:
        $k3Lov = config('upload.attachment_model')::findOrFail($g5e_r);
        goto kY91V;
        Pd13p:
        $eQ4Ln->setRawAttributes($k3Lov->getAttributes());
        goto IrXoN;
        IrXoN:
        return $eQ4Ln;
        goto E3PUl;
        E3PUl:
    }
    public function mbFD6M3QdNh(string $Y9HDF) : BbauDy0pIbj64
    {
        goto A86Bt;
        lYRM9:
        $KZB0P = $this->f1xKj->get($Y9HDF);
        goto OtxdN;
        hZVbh:
        $w4sAX = X5zE8bFBbBVcm::mlJAlG3FIjn($cor5J);
        goto MV6sl;
        OtxdN:
        Nppm4:
        goto TyAwr;
        bMq9b:
        throw new AsUdPM9ttxh6c('metadata file not found');
        goto e_KeV;
        TyAwr:
        $cor5J = json_decode($KZB0P, true);
        goto STg_s;
        STg_s:
        if (!$cor5J) {
            goto lNYXQ;
        }
        goto hZVbh;
        MV6sl:
        return $this->m6hPVE3OaAZ($w4sAX->lrNoe, $w4sAX->mp8oQSQ6jYh(), $w4sAX->filename);
        goto ogfiY;
        A86Bt:
        $KZB0P = $this->IA8m0->get($Y9HDF);
        goto ohNoJ;
        ohNoJ:
        if ($KZB0P) {
            goto Nppm4;
        }
        goto lYRM9;
        ogfiY:
        lNYXQ:
        goto bMq9b;
        e_KeV:
    }
    private function m6hPVE3OaAZ(string $b2ITX, $yihxq, ?string $g5e_r = null, array $as2bQ = [])
    {
        goto qGlQO;
        k7i3_:
        throw new VTCsTRR34DAEZ("not support file type {$b2ITX}");
        goto y1rnI;
        o97NT:
        $LvJ3R->mHWivXnN62Y(new J3SiPGv4roNIq($LvJ3R, $this->f1xKj, $as2bQ));
        goto vdlyS;
        vdlyS:
        foreach ($this->m9JgX as $S5eAy) {
            goto SJvlM;
            ecff6:
            ufwf0:
            goto bNFjd;
            PEJ4n:
            l2Uk6:
            goto ecff6;
            SJvlM:
            if (!$S5eAy->m9XWpVeJaHm($LvJ3R)) {
                goto l2Uk6;
            }
            goto PDtrJ;
            PDtrJ:
            return $LvJ3R->initLocation($S5eAy->mXSGuQe5X91($LvJ3R));
            goto PEJ4n;
            bNFjd:
        }
        goto Xn7hC;
        SBhus:
        $LvJ3R->mHWivXnN62Y(new KrCJD18qpEqnY($LvJ3R));
        goto o97NT;
        kdmOZ:
        f1dpv:
        goto YdPMN;
        qGlQO:
        $g5e_r = $g5e_r ?? Uuid::uuid4()->getHex()->toString();
        goto syvPb;
        syvPb:
        switch ($b2ITX) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $LvJ3R = XqAJHKYeaW2YU::createFromScratch($g5e_r, $b2ITX);
                goto f1dpv;
            case 'mp4':
            case 'mov':
                $LvJ3R = JbxOPjx4A3DUY::createFromScratch($g5e_r, $b2ITX);
                goto f1dpv;
            case 'pdf':
                $LvJ3R = AvQy1eDjm0AkP::createFromScratch($g5e_r, $b2ITX);
                goto f1dpv;
            default:
                throw new VTCsTRR34DAEZ("not support file type {$b2ITX}");
        }
        goto g1BeW;
        g1BeW:
        rIMeu:
        goto kdmOZ;
        YdPMN:
        $LvJ3R = $LvJ3R->mdhwv91TPd5($yihxq);
        goto SBhus;
        Xn7hC:
        mOESJ:
        goto k7i3_;
        y1rnI:
    }
}
