<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
final class Ukb0hQ0zAujsG implements VideoPostHandleServiceInterface
{
    private $n9rsV;
    private $gGE8I;
    public function __construct(UploadServiceInterface $q5E0I, Filesystem $duBfR)
    {
        $this->n9rsV = $q5E0I;
        $this->gGE8I = $duBfR;
    }
    public function saveMetadata(string $ld8Ad, array $yqV2Y)
    {
        goto OFCfP;
        OFCfP:
        $Ipllx = RVcEF1JsGQd8M::findOrFail($ld8Ad);
        goto Yo5HO;
        xjtW1:
        return $Ipllx->getView();
        goto Gjraa;
        xIqt3:
        if (!isset($yqV2Y['resolution'])) {
            goto v7tbL;
        }
        goto D9obI;
        cRIr1:
        if (!$Ipllx->update($r73eK)) {
            goto sKQat;
        }
        goto gWMbk;
        DHII_:
        if (!isset($yqV2Y['fps'])) {
            goto QRl3y;
        }
        goto Ap9Cf;
        tZ_bM:
        QRl3y:
        goto cyHt2;
        f91z4:
        if (!isset($yqV2Y['thumbnail'])) {
            goto M7Bqk;
        }
        goto w0unU;
        gWMbk:
        if (!(isset($yqV2Y['change_status']) && $yqV2Y['change_status'])) {
            goto CGIR4;
        }
        goto cdST3;
        Q3sSB:
        $r73eK['duration'] = $yqV2Y['duration'];
        goto ZbIdV;
        j9Hel:
        CGIR4:
        goto xjtW1;
        DS2gT:
        if (!isset($yqV2Y['duration'])) {
            goto tBQj2;
        }
        goto Q3sSB;
        Gjraa:
        sKQat:
        goto sGm5I;
        umijj:
        throw new \Exception("RVcEF1JsGQd8M metadata store failed for unknown reason ... " . $ld8Ad);
        goto NsTRj;
        w0unU:
        try {
            goto tuEtT;
            qRc8H:
            $r73eK['thumbnail'] = $pBU9S['filename'];
            goto xf1lL;
            ggyUP:
            $r73eK['thumbnail_id'] = $pBU9S['id'];
            goto qRc8H;
            tuEtT:
            $pBU9S = $this->n9rsV->storeSingleFile(new class($yqV2Y['thumbnail']) implements SingleUploadInterface
            {
                private $T6rAm;
                public function __construct($PQjbH)
                {
                    $this->T6rAm = $PQjbH;
                }
                public function getFile()
                {
                    return $this->T6rAm;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto ggyUP;
            xf1lL:
        } catch (\Throwable $I8puu) {
            Log::warning("RVcEF1JsGQd8M thumbnail store failed: " . $I8puu->getMessage());
        }
        goto R5NBp;
        ZbIdV:
        tBQj2:
        goto xIqt3;
        cdST3:
        $this->n9rsV->updateFile($Ipllx->getAttribute('id'), UimQKBIuLCEAO::PROCESSING);
        goto j9Hel;
        D9obI:
        $r73eK['resolution'] = $yqV2Y['resolution'];
        goto wIZCf;
        Yo5HO:
        $r73eK = [];
        goto f91z4;
        sGm5I:
        Log::warning("RVcEF1JsGQd8M metadata store failed for unknown reason ... " . $ld8Ad);
        goto umijj;
        cyHt2:
        if (!$Ipllx->QWfdD) {
            goto nNDxI;
        }
        goto espl_;
        wIZCf:
        v7tbL:
        goto DHII_;
        espl_:
        unset($r73eK['thumbnail']);
        goto K4TFX;
        Ap9Cf:
        $r73eK['fps'] = $yqV2Y['fps'];
        goto tZ_bM;
        R5NBp:
        M7Bqk:
        goto DS2gT;
        K4TFX:
        nNDxI:
        goto cRIr1;
        NsTRj:
    }
    public function createThumbnail(string $fBLtd) : void
    {
        goto SYWi2;
        jbjVC:
        if (!(!$this->gGE8I->directoryExists($ky3cI) && empty($Ipllx->mUG4jgFJWzb()))) {
            goto h0kF6;
        }
        goto dwFIx;
        hCYjM:
        h0kF6:
        goto bpnJM;
        Tp57y:
        $ky3cI = "v2/hls/thumbnails/{$fBLtd}/";
        goto jbjVC;
        SYWi2:
        Log::info("Use Lambda to generate thumbnail for video: " . $fBLtd);
        goto TCJIt;
        VS0ax:
        try {
            goto zgO0L;
            OlPZa:
            $oW1jB->sendMessage(['QueueUrl' => $w3PEW, 'MessageBody' => json_encode(['file_path' => $Ipllx->getLocation()])]);
            goto GptvI;
            pGif1:
            $w3PEW = $tufiY->get('QueueUrl');
            goto OlPZa;
            zgO0L:
            $tufiY = $oW1jB->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto pGif1;
            GptvI:
        } catch (\Throwable $nXJFP) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$nXJFP->getMessage()}");
        }
        goto hCYjM;
        TCJIt:
        $Ipllx = RVcEF1JsGQd8M::findOrFail($fBLtd);
        goto Tp57y;
        dwFIx:
        $oW1jB = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto VS0ax;
        bpnJM:
    }
    public function mYv1smIYNlD(string $fBLtd) : void
    {
        goto koVS8;
        oons4:
        $Ipllx->update(['generated_previews' => $ky3cI]);
        goto nIN0U;
        cpj24:
        $ky3cI = "v2/hls/thumbnails/{$fBLtd}/";
        goto WD2Ws;
        WD2Ws:
        if ($this->gGE8I->directoryExists($ky3cI)) {
            goto ziBiJ;
        }
        goto pzQgy;
        BnmyH:
        ziBiJ:
        goto qIJ10;
        ZzEdA:
        if (!(count($MmVmJ) === 0)) {
            goto LgThU;
        }
        goto Twr7v;
        W4GYz:
        LgThU:
        goto oons4;
        OBq0d:
        throw new \Exception("Message back with success data but not found thumbnail files " . $fBLtd);
        goto W4GYz;
        Twr7v:
        Log::error("Message back with success data but not found thumbnail files " . $fBLtd);
        goto OBq0d;
        AmVK5:
        throw new \Exception("Message back with success data but not found thumbnail " . $fBLtd);
        goto BnmyH;
        qIJ10:
        $MmVmJ = $this->gGE8I->files($ky3cI);
        goto ZzEdA;
        pzQgy:
        Log::error("Message back with success data but not found thumbnail " . $fBLtd);
        goto AmVK5;
        koVS8:
        $Ipllx = RVcEF1JsGQd8M::findOrFail($fBLtd);
        goto cpj24;
        nIN0U:
    }
    public function getThumbnails(string $fBLtd) : array
    {
        $Ipllx = RVcEF1JsGQd8M::findOrFail($fBLtd);
        return $Ipllx->getThumbnails();
    }
}
