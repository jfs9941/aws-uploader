<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
final class HuNYafgkpKFHi implements VideoPostHandleServiceInterface
{
    private $pGdUO;
    private $MV0lK;
    public function __construct(UploadServiceInterface $M6KgX, Filesystem $tYsty)
    {
        $this->pGdUO = $M6KgX;
        $this->MV0lK = $tYsty;
    }
    public function saveMetadata(string $FILUb, array $Cva33)
    {
        goto R5122;
        upJwN:
        $J3pKK = [];
        goto aCBNb;
        EjV6H:
        ATsI5:
        goto LiXIR;
        R5122:
        $zef_R = CUaMUcjkFHEwK::findOrFail($FILUb);
        goto upJwN;
        w1Zeq:
        gYj5P:
        goto TbGFH;
        ewIum:
        tjOlf:
        goto zW9DC;
        aCBNb:
        if (!isset($Cva33['thumbnail'])) {
            goto gYj5P;
        }
        goto Ee3Iu;
        boH9v:
        if (!(isset($Cva33['change_status']) && $Cva33['change_status'])) {
            goto BiMVe;
        }
        goto lzyUx;
        GfZzE:
        AtFyH:
        goto CvG_N;
        eJP6g:
        return $zef_R->getView();
        goto ewIum;
        jmgYk:
        $J3pKK['fps'] = $Cva33['fps'];
        goto EjV6H;
        HG4mj:
        throw new \Exception("CUaMUcjkFHEwK metadata store failed for unknown reason ... " . $FILUb);
        goto bHYTs;
        lzyUx:
        $this->pGdUO->updateFile($zef_R->getAttribute('id'), EPmxqTVp5luXc::PROCESSING);
        goto RYWFB;
        LiXIR:
        if (!$zef_R->LBxSS) {
            goto AtFyH;
        }
        goto F8nbf;
        TbGFH:
        if (!isset($Cva33['duration'])) {
            goto ohDSX;
        }
        goto yT9LO;
        yT9LO:
        $J3pKK['duration'] = $Cva33['duration'];
        goto OXOQm;
        zW9DC:
        Log::warning("CUaMUcjkFHEwK metadata store failed for unknown reason ... " . $FILUb);
        goto HG4mj;
        hNOrI:
        if (!isset($Cva33['fps'])) {
            goto ATsI5;
        }
        goto jmgYk;
        OXOQm:
        ohDSX:
        goto ToHny;
        Ee3Iu:
        try {
            goto uUePA;
            asLXw:
            $J3pKK['thumbnail_id'] = $E2RLT['id'];
            goto sulT_;
            uUePA:
            $E2RLT = $this->pGdUO->storeSingleFile(new class($Cva33['thumbnail']) implements SingleUploadInterface
            {
                private $oWuCn;
                public function __construct($I2SbP)
                {
                    $this->oWuCn = $I2SbP;
                }
                public function getFile()
                {
                    return $this->oWuCn;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto asLXw;
            sulT_:
            $J3pKK['thumbnail'] = $E2RLT['filename'];
            goto y9lVs;
            y9lVs:
        } catch (\Throwable $cy3Ei) {
            Log::warning("CUaMUcjkFHEwK thumbnail store failed: " . $cy3Ei->getMessage());
        }
        goto w1Zeq;
        F8nbf:
        unset($J3pKK['thumbnail']);
        goto GfZzE;
        CvG_N:
        if (!$zef_R->update($J3pKK)) {
            goto tjOlf;
        }
        goto boH9v;
        RYWFB:
        BiMVe:
        goto eJP6g;
        zSGif:
        pBk3U:
        goto hNOrI;
        ToHny:
        if (!isset($Cva33['resolution'])) {
            goto pBk3U;
        }
        goto vOU90;
        vOU90:
        $J3pKK['resolution'] = $Cva33['resolution'];
        goto zSGif;
        bHYTs:
    }
    public function createThumbnail(string $GLW0Y) : void
    {
        goto ChLhR;
        lw27n:
        $zef_R = CUaMUcjkFHEwK::findOrFail($GLW0Y);
        goto SRbin;
        gAQz6:
        $fkOsW = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto PwmtR;
        si6nW:
        if (!(!$this->MV0lK->directoryExists($lcE2B) && empty($zef_R->mq07jEGcxvW()))) {
            goto EOaTv;
        }
        goto gAQz6;
        SRbin:
        $lcE2B = "v2/hls/thumbnails/{$GLW0Y}/";
        goto si6nW;
        ChLhR:
        Log::info("Use Lambda to generate thumbnail for video: " . $GLW0Y);
        goto lw27n;
        sTTnp:
        EOaTv:
        goto v9iC7;
        PwmtR:
        try {
            goto mqrGw;
            uFYtq:
            $jtAWe = $qR0fV->get('QueueUrl');
            goto ArZ_l;
            mqrGw:
            $qR0fV = $fkOsW->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto uFYtq;
            ArZ_l:
            $fkOsW->sendMessage(['QueueUrl' => $jtAWe, 'MessageBody' => json_encode(['file_path' => $zef_R->getLocation()])]);
            goto OrfMy;
            OrfMy:
        } catch (\Throwable $AWFah) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$AWFah->getMessage()}");
        }
        goto sTTnp;
        v9iC7:
    }
    public function mahmxyg9Dtx(string $GLW0Y) : void
    {
        goto NIrQX;
        r83W_:
        $zef_R->update(['generated_previews' => $lcE2B]);
        goto aVGbc;
        GbHeu:
        if ($this->MV0lK->directoryExists($lcE2B)) {
            goto BHVPT;
        }
        goto Xq6lZ;
        e3QkI:
        throw new \Exception("Message back with success data but not found thumbnail files " . $GLW0Y);
        goto gvtIJ;
        dJg4M:
        $DOcNO = $this->MV0lK->files($lcE2B);
        goto x_1w6;
        zvtG_:
        BHVPT:
        goto dJg4M;
        hc0bb:
        Log::error("Message back with success data but not found thumbnail files " . $GLW0Y);
        goto e3QkI;
        NIrQX:
        $zef_R = CUaMUcjkFHEwK::findOrFail($GLW0Y);
        goto JioPf;
        Xq6lZ:
        Log::error("Message back with success data but not found thumbnail " . $GLW0Y);
        goto TsAup;
        x_1w6:
        if (!(count($DOcNO) === 0)) {
            goto e9yk3;
        }
        goto hc0bb;
        TsAup:
        throw new \Exception("Message back with success data but not found thumbnail " . $GLW0Y);
        goto zvtG_;
        JioPf:
        $lcE2B = "v2/hls/thumbnails/{$GLW0Y}/";
        goto GbHeu;
        gvtIJ:
        e9yk3:
        goto r83W_;
        aVGbc:
    }
    public function getThumbnails(string $GLW0Y) : array
    {
        $zef_R = CUaMUcjkFHEwK::findOrFail($GLW0Y);
        return $zef_R->getThumbnails();
    }
}
