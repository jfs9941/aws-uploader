<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\TdTpyTw87RXgQ;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Core\En8A7e3KRqXQ0;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
final class JujbASFciElku implements TdTpyTw87RXgQ
{
    private $KY0K1;
    private $O71XZ;
    public $AS8_H;
    private $qISiR;
    private $otzcU;
    private $S0euz;
    public function __construct($nujKR, $OIl8L, $Su8gE, $SLGJp, $Xcc4o, $t9rFg)
    {
        goto W_L2c;
        rVI5R:
        $this->AS8_H = $Su8gE;
        goto t1z4_;
        W_L2c:
        $this->S0euz = $t9rFg;
        goto NZtNL;
        t1z4_:
        $this->qISiR = $SLGJp;
        goto iqUOT;
        ATlIr:
        $this->O71XZ = $OIl8L;
        goto rVI5R;
        NZtNL:
        $this->KY0K1 = $nujKR;
        goto ATlIr;
        iqUOT:
        $this->otzcU = $Xcc4o;
        goto uJ2W_;
        uJ2W_:
    }
    public function resolvePath($SmLAm, $wU0QX = ZuZC67ch9j73R::S3) : string
    {
        goto rz3lp;
        yJbDu:
        if (!(!empty($this->qISiR) && !empty($this->otzcU))) {
            goto JD0Zp;
        }
        goto XnLNk;
        Tz3b0:
        JD0Zp:
        goto V_R1k;
        zfdoL:
        Q3jBr:
        goto GJhK0;
        rz3lp:
        if (!$SmLAm instanceof OavRsjNQCayKr) {
            goto Q3jBr;
        }
        goto V7u8f;
        CBXQ3:
        rpykz:
        goto hmFv2;
        GdnhM:
        return config('upload.home') . '/' . $SmLAm;
        goto rp4aT;
        rp4aT:
        BVJ9d:
        goto yJbDu;
        GJhK0:
        if (!($wU0QX === ZuZC67ch9j73R::LOCAL)) {
            goto BVJ9d;
        }
        goto GdnhM;
        XnLNk:
        return $this->mSs33cf3gi6($SmLAm);
        goto Tz3b0;
        V_R1k:
        if (!$this->KY0K1) {
            goto rpykz;
        }
        goto aLeZu;
        hmFv2:
        return trim($this->O71XZ, '/') . '/' . $SmLAm;
        goto AjX4k;
        V7u8f:
        $SmLAm = $SmLAm->getAttribute('filename');
        goto zfdoL;
        aLeZu:
        return trim($this->AS8_H, '/') . '/' . $SmLAm;
        goto CBXQ3;
        AjX4k:
    }
    public function resolveThumbnail(OavRsjNQCayKr $SmLAm) : string
    {
        goto gfRTs;
        x_8H7:
        return asset('/img/pdf-preview.svg');
        goto sSSXR;
        S5qS7:
        return $this->resolvePath($rg1ey, $rg1ey->getAttribute('driver'));
        goto WSji9;
        fmbBp:
        if (!$SmLAm instanceof En8A7e3KRqXQ0) {
            goto Y6gix;
        }
        goto x_8H7;
        G7suj:
        MntU4:
        goto fmbBp;
        kf_g6:
        $rg1ey = MpPzMcfcRTISZ::find($SmLAm->getAttribute('thumbnail_id'));
        goto PsJg7;
        PsJg7:
        if (!$rg1ey) {
            goto E28dh;
        }
        goto S5qS7;
        w9iag:
        if (!$SmLAm instanceof MpPzMcfcRTISZ) {
            goto MntU4;
        }
        goto laFS2;
        laFS2:
        return $this->resolvePath($SmLAm, $SmLAm->getAttribute('driver'));
        goto G7suj;
        NRtvL:
        if (!$SmLAm->getAttribute('thumbnail_id')) {
            goto eSAoW;
        }
        goto kf_g6;
        sSSXR:
        Y6gix:
        goto C9SQu;
        xncqI:
        WoaPA:
        goto NRtvL;
        WSji9:
        E28dh:
        goto Zz_vz;
        gfRTs:
        $oChgQ = $SmLAm->getAttribute('thumbnail');
        goto oSrEs;
        oSrEs:
        if (!$oChgQ) {
            goto WoaPA;
        }
        goto ra26S;
        C9SQu:
        return '';
        goto gSWPL;
        Zz_vz:
        eSAoW:
        goto w9iag;
        ra26S:
        return $this->url($oChgQ, $SmLAm->getAttribute('driver'));
        goto xncqI;
        gSWPL:
    }
    private function url($HyAAV, $wU0QX)
    {
        goto zX4Lb;
        A21VQ:
        return config('upload.home') . '/' . $HyAAV;
        goto Jc1j_;
        zX4Lb:
        if (!($wU0QX == ZuZC67ch9j73R::LOCAL)) {
            goto J0F1E;
        }
        goto A21VQ;
        Jc1j_:
        J0F1E:
        goto k5H7f;
        k5H7f:
        return $this->resolvePath($HyAAV);
        goto ykagi;
        ykagi:
    }
    private function mSs33cf3gi6($HyAAV)
    {
        goto aZUhw;
        putJD:
        QRXIQ:
        goto fL7y0;
        LCKYY:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto psJoV;
        aZUhw:
        if (!(strpos($HyAAV, 'https://') === 0)) {
            goto QRXIQ;
        }
        goto gBxvk;
        FxbjA:
        $anW5S = now()->addMinutes(60)->timestamp;
        goto LBIhd;
        fL7y0:
        if (!(strpos($HyAAV, 'm3u8') !== false)) {
            goto YzvJs;
        }
        goto LCKYY;
        fQCBm:
        return $TVFmd->getSignedUrl($this->AS8_H . '/' . $HyAAV, $anW5S);
        goto FLOQ0;
        gBxvk:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto putJD;
        psJoV:
        YzvJs:
        goto FxbjA;
        LBIhd:
        $TVFmd = new UrlSigner($this->qISiR, $this->S0euz->path($this->otzcU));
        goto fQCBm;
        FLOQ0:
    }
    public function resolvePathForHlsVideo(IfBHv1AJhiIDu $dajVn, $B8mhH = false) : string
    {
        goto zIzHL;
        zIzHL:
        if ($dajVn->getAttribute('hls_path')) {
            goto UI3N9;
        }
        goto ISJI3;
        rMHk1:
        UI3N9:
        goto kgqfK;
        ISJI3:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto rMHk1;
        kgqfK:
        return $this->AS8_H . '/' . $dajVn->getAttribute('hls_path');
        goto zZcPW;
        zZcPW:
    }
    public function resolvePathForHlsVideos()
    {
        goto hjPcb;
        xFw1z:
        $cYes5 = $this->AS8_H . '/v2/hls/';
        goto SrlWG;
        TTs5_:
        $CuPwd = $Js9Ar->getSignedCookie(['key_pair_id' => $this->qISiR, 'private_key' => $this->S0euz->path($this->otzcU), 'policy' => $pbNDX]);
        goto XloO9;
        XloO9:
        return [$CuPwd, $anW5S];
        goto d0EDX;
        SrlWG:
        $pbNDX = json_encode(['Statement' => [['Resource' => sprintf('%s*', $cYes5), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $anW5S]]]]]);
        goto co4a2;
        co4a2:
        $Js9Ar = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto TTs5_;
        hjPcb:
        $anW5S = now()->addDays(3)->timestamp;
        goto xFw1z;
        d0EDX:
    }
}
