<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Core\El0vMUwnHgT49;
use Jfs\Uploader\Core\Y96dk3g6dPmcf;
use Jfs\Uploader\Enum\SsxWbUYXracun;
use Jfs\Uploader\Exception\Vkv9DR78jqmXg;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Jfs\Uploader\Exception\GddjQ7rhrkuyP;
final class BBJ8LO3rEX6wz implements UploadServiceInterface
{
    private $yotrU;
    private $VFHFZ;
    private $NP9R0;
    private $tIyXF;
    public function __construct(AYglkzXejDDAm $jOVDr, Filesystem $dOL2I, Filesystem $TLVVj, string $UcdwJ)
    {
        goto yvVJW;
        wlHUi:
        $this->tIyXF = $UcdwJ;
        goto HkGnU;
        yvVJW:
        $this->yotrU = $jOVDr;
        goto DY9go;
        udO7p:
        $this->NP9R0 = $TLVVj;
        goto wlHUi;
        DY9go:
        $this->VFHFZ = $dOL2I;
        goto udO7p;
        HkGnU:
    }
    public function storeSingleFile(SingleUploadInterface $x8HX1) : array
    {
        goto YfidW;
        YfidW:
        $tscCi = $this->yotrU->mTBpWZcol6e($x8HX1);
        goto NZpVt;
        mEjAG:
        $tscCi->mvUghb89hzW(SsxWbUYXracun::UPLOADED);
        goto VI_bJ;
        OvXF3:
        Uitjd:
        goto mEjAG;
        nKTLI:
        if (false !== $IJqE5 && $tscCi instanceof Y0vs5qDfvPebz) {
            goto Uitjd;
        }
        goto B5tOt;
        VI_bJ:
        qSmPF:
        goto OSSbo;
        NZpVt:
        $IJqE5 = $this->NP9R0->putFileAs(dirname($tscCi->getLocation()), $x8HX1->getFile(), $tscCi->getFilename() . '.' . $tscCi->getExtension(), ['visibility' => 'public']);
        goto nKTLI;
        B5tOt:
        throw new \LogicException('File upload failed, check permissions');
        goto cM9hW;
        cM9hW:
        goto qSmPF;
        goto OvXF3;
        OSSbo:
        return $tscCi->getView();
        goto GLHHC;
        GLHHC:
    }
    public function storePreSignedFile(array $BCDjj)
    {
        goto eO8Bj;
        ejixh:
        $lIPqb->mdO9aScQwEz($BCDjj['mime'], $BCDjj['file_size'], $BCDjj['chunk_size'], $BCDjj['checksums'], $BCDjj['user_id'], $BCDjj['driver']);
        goto G14qX;
        YSvoS:
        $lIPqb = Y96dk3g6dPmcf::mZhCZmPzfTk($tscCi, $this->VFHFZ, $this->NP9R0, $this->tIyXF, true);
        goto ejixh;
        kkRWb:
        return ['filename' => $lIPqb->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $lIPqb->msnuZYoW76Q()];
        goto oDeQK;
        G14qX:
        $lIPqb->mKvxjDVLcKI();
        goto kkRWb;
        eO8Bj:
        $tscCi = $this->yotrU->mTBpWZcol6e($BCDjj);
        goto YSvoS;
        oDeQK:
    }
    public function updatePreSignedFile(string $nE8tG, int $b9LX4)
    {
        goto zCKiW;
        zCKiW:
        $lIPqb = Y96dk3g6dPmcf::mF8XbeFNiMU($nE8tG, $this->VFHFZ, $this->NP9R0, $this->tIyXF);
        goto rIqQo;
        Tf2zT:
        NQbks:
        goto cyTqR;
        cyTqR:
        MCcgK:
        goto v82VT;
        rIqQo:
        switch ($b9LX4) {
            case SsxWbUYXracun::UPLOADED:
                $lIPqb->m4uX1pQb4Ux();
                goto MCcgK;
            case SsxWbUYXracun::PROCESSING:
                $lIPqb->mW5G3tLumNv();
                goto MCcgK;
            case SsxWbUYXracun::FINISHED:
                $lIPqb->mrPszRNnt2J();
                goto MCcgK;
            case SsxWbUYXracun::ABORTED:
                $lIPqb->mjSxgz0pE87();
                goto MCcgK;
        }
        goto Tf2zT;
        v82VT:
    }
    public function completePreSignedFile(string $nE8tG, array $Zkrnk)
    {
        goto jnhHP;
        MLCkp:
        $lIPqb->m4uX1pQb4Ux();
        goto v1bWR;
        jnhHP:
        $lIPqb = Y96dk3g6dPmcf::mF8XbeFNiMU($nE8tG, $this->VFHFZ, $this->NP9R0, $this->tIyXF);
        goto eGEsZ;
        eGEsZ:
        $lIPqb->mmWA2B9zVkK()->mbWSXS8s0no($Zkrnk);
        goto MLCkp;
        v1bWR:
        return ['path' => $lIPqb->getFile()->getView()['path'], 'thumbnail' => $lIPqb->getFile()->FH5aS, 'id' => $nE8tG];
        goto wWgXx;
        wWgXx:
    }
    public function updateFile(string $nE8tG, int $b9LX4) : El0vMUwnHgT49
    {
        goto q2qo0;
        XIWOH:
        $tscCi->mvUghb89hzW($b9LX4);
        goto vxjSa;
        q2qo0:
        $tscCi = $this->yotrU->mQArHYtNSiq($nE8tG);
        goto XIWOH;
        vxjSa:
        return $tscCi;
        goto PF9GL;
        PF9GL:
    }
}
