<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Core\VpkgrrmDu5rEh;
use Jfs\Uploader\Core\EpvE4BO9GOGFh;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Jfs\Uploader\Exception\SlPIHqOmIQ9pI;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Exception\RlwRtWSVPtDAe;
use Jfs\Uploader\Service\QPQBXT5xv2KsY;
use Illuminate\Contracts\Filesystem\Filesystem;
final class YtxSak1ZpKSPX implements UploadServiceInterface
{
    private $MDyio;
    private $TD3CW;
    private $Ht28P;
    private $Fwpjt;
    public function __construct(QPQBXT5xv2KsY $yVLWb, Filesystem $e3uVO, Filesystem $cUbzi, string $KZVVg)
    {
        goto G0Ume;
        G7v0f:
        $this->Fwpjt = $KZVVg;
        goto duhKz;
        c4yOi:
        $this->TD3CW = $e3uVO;
        goto kvXCd;
        G0Ume:
        $this->MDyio = $yVLWb;
        goto c4yOi;
        kvXCd:
        $this->Ht28P = $cUbzi;
        goto G7v0f;
        duhKz:
    }
    public function storeSingleFile(SingleUploadInterface $DyMZc) : array
    {
        goto Faoz6;
        GDl5g:
        goto d0tD1;
        goto FDdZH;
        BObrN:
        if (false !== $HCRCz && $D55CH instanceof N41GICKeJz2js) {
            goto rW_CW;
        }
        goto q2B2K;
        B6dbV:
        return $D55CH->getView();
        goto REBCs;
        q2B2K:
        throw new \LogicException('File upload failed, check permissions');
        goto GDl5g;
        lY1Dq:
        d0tD1:
        goto B6dbV;
        FXP75:
        $HCRCz = $this->Ht28P->putFileAs(dirname($D55CH->getLocation()), $DyMZc->getFile(), $D55CH->getFilename() . '.' . $D55CH->getExtension(), ['visibility' => 'public']);
        goto BObrN;
        FDdZH:
        rW_CW:
        goto PTheP;
        PTheP:
        $D55CH->mKP20BPk5QC(Zgh3BZ2JVlG1A::UPLOADED);
        goto lY1Dq;
        Faoz6:
        $D55CH = $this->MDyio->mOQnSHMUPr0($DyMZc);
        goto FXP75;
        REBCs:
    }
    public function storePreSignedFile(array $rVaV1)
    {
        goto WbHwq;
        K2hAA:
        return ['filename' => $N1xft->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $N1xft->m0SaDXylWqU()];
        goto ZWw45;
        E9yVj:
        $N1xft = EpvE4BO9GOGFh::mrq8ZeUTURA($D55CH, $this->TD3CW, $this->Ht28P, $this->Fwpjt, true);
        goto SLwaY;
        WbHwq:
        $D55CH = $this->MDyio->mOQnSHMUPr0($rVaV1);
        goto E9yVj;
        SLwaY:
        $N1xft->m1thepGV3RN($rVaV1['mime'], $rVaV1['file_size'], $rVaV1['chunk_size'], $rVaV1['checksums'], $rVaV1['user_id'], $rVaV1['driver']);
        goto rIGHX;
        rIGHX:
        $N1xft->mqWgNNXI687();
        goto K2hAA;
        ZWw45:
    }
    public function updatePreSignedFile(string $oxSbd, int $Exw0V)
    {
        goto G3J8b;
        cINuD:
        bALR7:
        goto IlUdz;
        UKA_M:
        BZKXA:
        goto cINuD;
        G3J8b:
        $N1xft = EpvE4BO9GOGFh::m8pMRCYnNnN($oxSbd, $this->TD3CW, $this->Ht28P, $this->Fwpjt);
        goto CmZ2Z;
        CmZ2Z:
        switch ($Exw0V) {
            case Zgh3BZ2JVlG1A::UPLOADED:
                $N1xft->mmizOPHltH3();
                goto bALR7;
            case Zgh3BZ2JVlG1A::PROCESSING:
                $N1xft->mGtG3lIWmKp();
                goto bALR7;
            case Zgh3BZ2JVlG1A::FINISHED:
                $N1xft->mqqZNuBB0hr();
                goto bALR7;
            case Zgh3BZ2JVlG1A::ABORTED:
                $N1xft->m5HRMPd4c7L();
                goto bALR7;
        }
        goto UKA_M;
        IlUdz:
    }
    public function completePreSignedFile(string $oxSbd, array $nN4jY)
    {
        goto MCMAg;
        MCMAg:
        $N1xft = EpvE4BO9GOGFh::m8pMRCYnNnN($oxSbd, $this->TD3CW, $this->Ht28P, $this->Fwpjt);
        goto fVXcG;
        fVXcG:
        $N1xft->mw6tRR1NtWf()->mo1S36hnlzS($nN4jY);
        goto hXXgc;
        hXXgc:
        $N1xft->mmizOPHltH3();
        goto fKK6k;
        fKK6k:
        return ['path' => $N1xft->getFile()->getView()['path'], 'thumbnail' => $N1xft->getFile()->AN0O0, 'id' => $oxSbd];
        goto eG8sR;
        eG8sR:
    }
    public function updateFile(string $oxSbd, int $Exw0V) : VpkgrrmDu5rEh
    {
        goto dTmAo;
        dTmAo:
        $D55CH = $this->MDyio->m8vjbo9rPgc($oxSbd);
        goto IAewO;
        jCLt0:
        return $D55CH;
        goto ooQTC;
        IAewO:
        $D55CH->mKP20BPk5QC($Exw0V);
        goto jCLt0;
        ooQTC:
    }
}
