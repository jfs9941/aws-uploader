<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Core\Observer\Gj1znMULTyeud;
use Jfs\Uploader\Core\Observer\F4rYz9eUIaudx;
use Jfs\Uploader\Core\QWYHsUCm1wCVE;
use Jfs\Uploader\Core\UAsHLG1mz8hdv;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Exception\N08aNyPgjV9qA;
use Jfs\Uploader\Service\FileResolver\Wira7hKoOHFj6;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class DpvqXIwAB5UAa
{
    private $hPdeM;
    private $j5MRz;
    private $YHwpp;
    public function __construct($Yptfl, $nkmCX, $ehLvI)
    {
        goto ArCFN;
        Qt5mc:
        $this->j5MRz = $nkmCX;
        goto j86Ti;
        ArCFN:
        $this->hPdeM = $Yptfl;
        goto Qt5mc;
        j86Ti:
        $this->YHwpp = $ehLvI;
        goto OU6hH;
        OU6hH:
    }
    public function m45nXWCsSWK($E2zmG)
    {
        goto EkjmQ;
        EkjmQ:
        if (!$E2zmG instanceof SingleUploadInterface) {
            goto coidc;
        }
        goto vxZAh;
        Ve8Ie:
        return $this->mohWXswRYZK($E2zmG['file_extension'], 's3' === $E2zmG['driver'] ? TpPQGsuK0gyw2::S3 : TpPQGsuK0gyw2::LOCAL);
        goto IoL7A;
        d3TSj:
        coidc:
        goto Ve8Ie;
        RN8b5:
        return $this->mohWXswRYZK($kriwd->extension(), TpPQGsuK0gyw2::S3, null, $E2zmG->options());
        goto d3TSj;
        vxZAh:
        $kriwd = $E2zmG->getFile();
        goto RN8b5;
        IoL7A:
    }
    public function mQjwVjj4omD(string $ShXx2)
    {
        goto UVr9x;
        EYH5I:
        $Ga9Xm->setRawAttributes($pRvih->getAttributes());
        goto iWBJ3;
        iWBJ3:
        return $Ga9Xm;
        goto UYye8;
        UVr9x:
        $pRvih = config('upload.attachment_model')::findOrFail($ShXx2);
        goto McZ0i;
        McZ0i:
        $Ga9Xm = $this->mohWXswRYZK($pRvih->getAttribute('type'), $pRvih->getAttribute('driver'), $pRvih->getAttribute('id'));
        goto xopei;
        xopei:
        $Ga9Xm->exists = true;
        goto EYH5I;
        UYye8:
    }
    public function mn14XV1nfnm(string $VyiBK) : RsTEqK0aKnthE
    {
        goto R3glE;
        CKxUl:
        YAr_t:
        goto wwilY;
        zdtFk:
        $Jqb3V = $this->YHwpp->get($VyiBK);
        goto MObhf;
        MObhf:
        CCVLM:
        goto VGTzI;
        R3glE:
        $Jqb3V = $this->j5MRz->get($VyiBK);
        goto SsWs3;
        duk3_:
        if (!$Zqaxi) {
            goto YAr_t;
        }
        goto NSlzV;
        q3hDM:
        return $this->mohWXswRYZK($IKjss->tux0n, $IKjss->maDg8VZIO83(), $IKjss->filename);
        goto CKxUl;
        SsWs3:
        if ($Jqb3V) {
            goto CCVLM;
        }
        goto zdtFk;
        NSlzV:
        $IKjss = UAsHLG1mz8hdv::mAUg5c8gbR3($Zqaxi);
        goto q3hDM;
        VGTzI:
        $Zqaxi = json_decode($Jqb3V, true);
        goto duk3_;
        wwilY:
        throw new YK7fJDaVPWKzB('metadata file not found');
        goto D5X4x;
        D5X4x:
    }
    private function mohWXswRYZK(string $IDPXc, $Jbwds, ?string $ShXx2 = null, array $hNsac = [])
    {
        goto AIAEZ;
        HXI3J:
        $rON1I->mv8Sk2uSFhz(new Gj1znMULTyeud($rON1I));
        goto bRE4G;
        AIAEZ:
        $ShXx2 = $ShXx2 ?? Uuid::uuid4()->getHex()->toString();
        goto lcyFy;
        Iph3c:
        throw new N08aNyPgjV9qA("not support file type {$IDPXc}");
        goto NOpwZ;
        J6qJi:
        foreach ($this->hPdeM as $mYBhd) {
            goto wteDE;
            COgmG:
            return $rON1I->initLocation($mYBhd->mCNUjEbsWBz($rON1I));
            goto FBRGc;
            jUEd4:
            xu1tp:
            goto V44Rf;
            FBRGc:
            Zu8tN:
            goto jUEd4;
            wteDE:
            if (!$mYBhd->mQlbPWyS91p($rON1I)) {
                goto Zu8tN;
            }
            goto COgmG;
            V44Rf:
        }
        goto pbfRm;
        pbfRm:
        bE2WF:
        goto Iph3c;
        bRE4G:
        $rON1I->mv8Sk2uSFhz(new F4rYz9eUIaudx($rON1I, $this->YHwpp, $hNsac));
        goto J6qJi;
        desuT:
        $rON1I = $rON1I->m2VUk4YFSbx($Jbwds);
        goto HXI3J;
        g0k8E:
        V2bLY:
        goto desuT;
        lcyFy:
        switch ($IDPXc) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $rON1I = Vt3ybt0yfaPAa::createFromScratch($ShXx2, $IDPXc);
                goto V2bLY;
            case 'mp4':
            case 'mov':
                $rON1I = D6fOq8lm3n7T2::createFromScratch($ShXx2, $IDPXc);
                goto V2bLY;
            case 'pdf':
                $rON1I = QWYHsUCm1wCVE::createFromScratch($ShXx2, $IDPXc);
                goto V2bLY;
            default:
                throw new N08aNyPgjV9qA("not support file type {$IDPXc}");
        }
        goto zvpi0;
        zvpi0:
        rU8Ak:
        goto g0k8E;
        NOpwZ:
    }
}
