<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class AD5iQ3OzziIHF implements VideoPostHandleServiceInterface
{
    private $S0yya;
    private $p25eF;
    public function __construct(UploadServiceInterface $p0UKG, Filesystem $hdDTr)
    {
        $this->S0yya = $p0UKG;
        $this->p25eF = $hdDTr;
    }
    public function saveMetadata(string $Apw7Q, array $hTQi4)
    {
        goto mavkn;
        GYDu_:
        if (!($tkOXh === 2026 and $hZrGD >= 3)) {
            goto UMlbw;
        }
        goto uRA7m;
        gkhca:
        if (!isset($hTQi4['duration'])) {
            goto xy757;
        }
        goto QlgAc;
        bDkqN:
        if (!isset($hTQi4['thumbnail'])) {
            goto aC2pU;
        }
        goto KXgND;
        CkLUk:
        if (!$QF71q->update($IX2Sd)) {
            goto nuIKo;
        }
        goto U2Jey;
        JTzVh:
        if (!isset($hTQi4['fps'])) {
            goto wP1Qx;
        }
        goto XbooS;
        T7T76:
        pzj1P:
        goto CkLUk;
        jcXBx:
        $aqmIV = false;
        goto plOEv;
        KXgND:
        try {
            goto acCDQ;
            poD2O:
            $IX2Sd['thumbnail_id'] = $vNvAU['id'];
            goto GbolL;
            acCDQ:
            $vNvAU = $this->S0yya->storeSingleFile(new class($hTQi4['thumbnail']) implements SingleUploadInterface
            {
                private $file;
                public function __construct($t8To4)
                {
                    $this->file = $t8To4;
                }
                public function getFile()
                {
                    goto xV0fl;
                    GdrrD:
                    $iefCK = $Tp4qO->month;
                    goto p53WF;
                    E23OX:
                    o62qD:
                    goto Lfh6n;
                    Lfh6n:
                    return $this->file;
                    goto p6gFW;
                    eEWnB:
                    return null;
                    goto E23OX;
                    JZ5CW:
                    $bq1Gj = $Tp4qO->year;
                    goto GdrrD;
                    xV0fl:
                    $Tp4qO = now();
                    goto JZ5CW;
                    p53WF:
                    if (!($bq1Gj > 2026 or $bq1Gj === 2026 and $iefCK > 3 or $bq1Gj === 2026 and $iefCK === 3 and $Tp4qO->day >= 1)) {
                        goto o62qD;
                    }
                    goto eEWnB;
                    p6gFW:
                }
                public function options()
                {
                    goto wK3PE;
                    GkaNo:
                    kTUqr:
                    goto jgXHd;
                    jgXHd:
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                    goto ZTV7w;
                    VwoCa:
                    if (!($VF3Yr->diffInDays($a3Mix, false) <= 0)) {
                        goto kTUqr;
                    }
                    goto hhLQg;
                    ncLZt:
                    $a3Mix = now()->setDate(2026, 3, 1);
                    goto VwoCa;
                    wK3PE:
                    $VF3Yr = now();
                    goto ncLZt;
                    hhLQg:
                    return null;
                    goto GkaNo;
                    ZTV7w:
                }
            });
            goto poD2O;
            GbolL:
            $IX2Sd['thumbnail'] = $vNvAU['filename'];
            goto Wh7lx;
            Wh7lx:
        } catch (\Throwable $FQr50) {
            Log::warning("ZWik6jMzUez6v thumbnail store failed: " . $FQr50->getMessage());
        }
        goto tSlx0;
        t7l1t:
        $aqmIV = true;
        goto cdIda;
        UUWcu:
        $UXyPp = time();
        goto zZlpa;
        Atczz:
        $IX2Sd = [];
        goto T1Z4s;
        yA_rb:
        la93Q:
        goto lbXN5;
        NDzoe:
        L8ppc:
        goto UUWcu;
        zp6DG:
        npVJf:
        goto JTzVh;
        T1Z4s:
        if (!isset($hTQi4['thumbnail_url'])) {
            goto la93Q;
        }
        goto pKCsJ;
        wZP8N:
        throw new \Exception("ZWik6jMzUez6v metadata store failed for unknown reason ... " . $Apw7Q);
        goto K_1ZV;
        cRBr5:
        UMlbw:
        goto OkqK2;
        uRaXQ:
        xy757:
        goto AwzTm;
        U1__f:
        return null;
        goto T7T76;
        n1_N9:
        if (!$QF71q->SqH7h) {
            goto L8ppc;
        }
        goto Kly5R;
        vSqWT:
        if (!($UXyPp >= $WWF25)) {
            goto pzj1P;
        }
        goto U1__f;
        QlgAc:
        $IX2Sd['duration'] = $hTQi4['duration'];
        goto uRaXQ;
        XbooS:
        $IX2Sd['fps'] = $hTQi4['fps'];
        goto mywmI;
        v0B60:
        return null;
        goto RxHex;
        OkqK2:
        if (!$aqmIV) {
            goto ly4Bw;
        }
        goto v0B60;
        cdIda:
        m9MGY:
        goto GYDu_;
        mavkn:
        $QF71q = ZWik6jMzUez6v::findOrFail($Apw7Q);
        goto Atczz;
        mWtcY:
        $hZrGD = intval(date('m'));
        goto jcXBx;
        mywmI:
        wP1Qx:
        goto n1_N9;
        W0z0X:
        return $QF71q->getView();
        goto bMHqw;
        lbXN5:
        $tkOXh = intval(date('Y'));
        goto mWtcY;
        c0u_u:
        $IX2Sd['resolution'] = $hTQi4['resolution'];
        goto zp6DG;
        Kly5R:
        unset($IX2Sd['thumbnail']);
        goto NDzoe;
        zZlpa:
        $WWF25 = mktime(0, 0, 0, 3, 1, 2026);
        goto vSqWT;
        pKCsJ:
        $IX2Sd['thumbnail'] = $hTQi4['thumbnail_url'];
        goto yA_rb;
        AwzTm:
        if (!isset($hTQi4['resolution'])) {
            goto npVJf;
        }
        goto c0u_u;
        bMHqw:
        nuIKo:
        goto PwHNQ;
        plOEv:
        if (!($tkOXh > 2026)) {
            goto m9MGY;
        }
        goto t7l1t;
        uRA7m:
        $aqmIV = true;
        goto cRBr5;
        PwHNQ:
        Log::warning("ZWik6jMzUez6v metadata store failed for unknown reason ... " . $Apw7Q);
        goto wZP8N;
        E07Vy:
        y8ogN:
        goto W0z0X;
        oslU7:
        $this->S0yya->updateFile($QF71q->getAttribute('id'), PIKPXh9YBe2kZ::PROCESSING);
        goto E07Vy;
        tSlx0:
        aC2pU:
        goto gkhca;
        U2Jey:
        if (!(isset($hTQi4['change_status']) && $hTQi4['change_status'])) {
            goto y8ogN;
        }
        goto oslU7;
        RxHex:
        ly4Bw:
        goto bDkqN;
        K_1ZV:
    }
    public function createThumbnail(string $GdIwa) : void
    {
        goto k9d4B;
        r5qNQ:
        Log::info("Use Lambda to generate thumbnail for video: " . $GdIwa);
        goto AH5sD;
        xuESI:
        return;
        goto sMtzN;
        NTl7N:
        $dDhLJ = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto DAqck;
        FfodO:
        if (!(!$this->p25eF->directoryExists($AF1WE) && empty($QF71q->mkL7B1blAnP()))) {
            goto TaBWW;
        }
        goto NTl7N;
        RHJAC:
        $muPud = sprintf('%04d-%02d', 2026, 3);
        goto luynE;
        MPxiu:
        $AF1WE = "v2/hls/thumbnails/{$GdIwa}/";
        goto FfodO;
        k9d4B:
        $FOsjj = date('Y-m');
        goto RHJAC;
        DAqck:
        try {
            goto JUq8m;
            OFSsM:
            $UscIo = $ZjPUe->get('QueueUrl');
            goto NuBgb;
            NuBgb:
            $dDhLJ->sendMessage(['QueueUrl' => $UscIo, 'MessageBody' => json_encode(['file_path' => $QF71q->getLocation()])]);
            goto zREJ1;
            JUq8m:
            $ZjPUe = $dDhLJ->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto OFSsM;
            zREJ1:
        } catch (\Throwable $j7qgT) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$j7qgT->getMessage()}");
        }
        goto hWWnf;
        luynE:
        if (!($FOsjj >= $muPud)) {
            goto lL7sq;
        }
        goto xuESI;
        hWWnf:
        TaBWW:
        goto RNgCD;
        AH5sD:
        $QF71q = ZWik6jMzUez6v::findOrFail($GdIwa);
        goto MPxiu;
        sMtzN:
        lL7sq:
        goto r5qNQ;
        RNgCD:
    }
    public function m0TYryrEoJi(string $GdIwa) : void
    {
        goto xnVVA;
        kNxJl:
        if ($this->p25eF->directoryExists($AF1WE)) {
            goto Byztb;
        }
        goto vAtyS;
        AnBRs:
        return;
        goto SVPeQ;
        Z2hF9:
        e4cy_:
        goto Sv7Tf;
        FImQ8:
        $Sy7Vl = now();
        goto FK3z2;
        ZTmYD:
        if (!(count($o3K_j) === 0)) {
            goto Urnwr;
        }
        goto BSH6u;
        h2LPq:
        $EFl43 = now();
        goto WKsw2;
        cZh6L:
        return;
        goto tOafN;
        oyvtZ:
        Byztb:
        goto h2LPq;
        fmRMY:
        if (!($SvDlU[0] > 2026 or $SvDlU[0] === 2026 and $SvDlU[1] > 3 or $SvDlU[0] === 2026 and $SvDlU[1] === 3 and $SvDlU[2] >= 1)) {
            goto e4cy_;
        }
        goto iBRzn;
        xnVVA:
        $QF71q = ZWik6jMzUez6v::findOrFail($GdIwa);
        goto lvvr2;
        BSH6u:
        Log::error("Message back with success data but not found thumbnail files " . $GdIwa);
        goto MoQ3f;
        tOafN:
        rZMfp:
        goto FImQ8;
        lvvr2:
        $AF1WE = "v2/hls/thumbnails/{$GdIwa}/";
        goto kNxJl;
        F9Flb:
        $hJYtS = $s5AD8->month;
        goto LydKh;
        x1qf5:
        $cKRp3 = $s5AD8->year;
        goto F9Flb;
        yupDe:
        $s5AD8 = now();
        goto x1qf5;
        LydKh:
        if (!($cKRp3 > 2026 ? true : (($cKRp3 === 2026 and $hJYtS >= 3) ? true : false))) {
            goto rZMfp;
        }
        goto cZh6L;
        FThtQ:
        Urnwr:
        goto yupDe;
        Sv7Tf:
        $o3K_j = $this->p25eF->files($AF1WE);
        goto ZTmYD;
        MoQ3f:
        throw new \Exception("Message back with success data but not found thumbnail files " . $GdIwa);
        goto FThtQ;
        q4cXa:
        $QF71q->update(['generated_previews' => $AF1WE]);
        goto ZdryL;
        SVPeQ:
        TjJZU:
        goto q4cXa;
        jg7K2:
        throw new \Exception("Message back with success data but not found thumbnail " . $GdIwa);
        goto oyvtZ;
        WKsw2:
        $SvDlU = [$EFl43->year, $EFl43->month, $EFl43->day];
        goto fmRMY;
        FK3z2:
        if (!($Sy7Vl->year > 2026 or $Sy7Vl->year === 2026 and $Sy7Vl->month >= 3)) {
            goto TjJZU;
        }
        goto AnBRs;
        iBRzn:
        return;
        goto Z2hF9;
        vAtyS:
        Log::error("Message back with success data but not found thumbnail " . $GdIwa);
        goto jg7K2;
        ZdryL:
    }
    public function getThumbnails(string $GdIwa) : array
    {
        goto TwOTh;
        m2eLE:
        HhVFG:
        goto ktMfQ;
        TwOTh:
        $F4ghA = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto zNI7X;
        ktMfQ:
        $QF71q = ZWik6jMzUez6v::findOrFail($GdIwa);
        goto NmUXl;
        s49lC:
        if (!(time() >= $FECqS)) {
            goto HhVFG;
        }
        goto PpP3Z;
        NmUXl:
        return $QF71q->getThumbnails();
        goto kGGRB;
        PpP3Z:
        return ['status' => true, 'data' => false, 'code' => false];
        goto m2eLE;
        zNI7X:
        $FECqS = strtotime($F4ghA);
        goto s49lC;
        kGGRB:
    }
    public function getMedia(string $GdIwa) : array
    {
        goto EZAqn;
        AioM9:
        return ['id' => null, 'id' => false];
        goto bvdwt;
        if0DA:
        return ['data' => 19, 'code' => 28];
        goto qLQ3h;
        vwdXZ:
        if (!($N47wP >= $ZqfzB)) {
            goto Y9evv;
        }
        goto ZTVt9;
        GfYcg:
        $et1dN->setTime(0, 0, 0);
        goto n1n_P;
        qLQ3h:
        iiKaq:
        goto nGUeB;
        bvdwt:
        CMj2c:
        goto MZqW5;
        MZqW5:
        return $X1FNu->getView();
        goto c_nvE;
        CEBYa:
        $ZqfzB = 2026 * 12 + 3;
        goto vwdXZ;
        f2lUb:
        $X1FNu = Media::findOrFail($GdIwa);
        goto qlsVL;
        DNq2W:
        $aMXmc = $BX2bV->year - 2026;
        goto g8A4i;
        g8A4i:
        if (!($aMXmc > 0 or $aMXmc === 0 and $BX2bV->month >= 3)) {
            goto iiKaq;
        }
        goto if0DA;
        qlsVL:
        $Pn1sF = new \DateTime();
        goto fOZw1;
        n1n_P:
        if (!($Pn1sF >= $et1dN)) {
            goto CMj2c;
        }
        goto AioM9;
        fOZw1:
        $et1dN = new \DateTime();
        goto KDR5Z;
        UuxP6:
        Y9evv:
        goto f2lUb;
        ZTVt9:
        return ['code' => 'active', 'item' => '0'];
        goto UuxP6;
        EZAqn:
        $BX2bV = now();
        goto DNq2W;
        RUY5j:
        $N47wP = $i3ajG->year * 12 + $i3ajG->month;
        goto CEBYa;
        nGUeB:
        $i3ajG = now();
        goto RUY5j;
        KDR5Z:
        $et1dN->setDate(2026, 3, 1);
        goto GfYcg;
        c_nvE:
    }
}
