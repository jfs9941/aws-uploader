<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Illuminate\Contracts\Filesystem\Filesystem;
final class RiRUUwVHtq3AY
{
    private $mltiL;
    private $Tu_r6;
    private $qqmnq;
    public function __construct(string $nIkcP, string $i3P_3, Filesystem $vS8UC)
    {
        goto BlOf8;
        BlOf8:
        $this->mltiL = $nIkcP;
        goto Doaxb;
        H7nEn:
        $this->qqmnq = $vS8UC;
        goto a8mN3;
        Doaxb:
        $this->Tu_r6 = $i3P_3;
        goto H7nEn;
        a8mN3:
    }
    public function mt8hLLBtg6j(EpIpyfdFnoTz6 $HZKvy) : string
    {
        goto rkx3h;
        rkx3h:
        if (!(CUySMhqlL7P49::S3 == $HZKvy->getAttribute('driver'))) {
            goto Z22Sw;
        }
        goto bjnUM;
        bhqzI:
        Z22Sw:
        goto IDCLz;
        bjnUM:
        return 's3://' . $this->mltiL . '/' . $HZKvy->getAttribute('filename');
        goto bhqzI;
        IDCLz:
        return $this->qqmnq->url($HZKvy->getAttribute('filename'));
        goto nVTCC;
        nVTCC:
    }
    public function mZ6Ua4pkUv7(?string $KOZO4) : ?string
    {
        goto Jyiqi;
        qxZx2:
        OIigJ:
        goto nRBy6;
        nRBy6:
        return null;
        goto n0hQd;
        rZ02h:
        W2V3n:
        goto qxZx2;
        LoEsA:
        return 's3://' . $this->mltiL . '/' . ltrim($iTIh6, '/');
        goto rZ02h;
        EQmSP:
        $iTIh6 = parse_url($KOZO4, PHP_URL_PATH);
        goto LoEsA;
        aWwZK:
        if (!YIyoW($KOZO4, $this->mltiL)) {
            goto W2V3n;
        }
        goto EQmSP;
        Jyiqi:
        if (!$KOZO4) {
            goto OIigJ;
        }
        goto aWwZK;
        n0hQd:
    }
    public function mIPY8uGtSTG(string $iTIh6) : string
    {
        return 's3://' . $this->mltiL . '/' . $iTIh6;
    }
}
