<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class VubK8U88WJUPq implements VideoPostHandleServiceInterface
{
    private $JlEZP;
    private $QxLu3;
    public function __construct(UploadServiceInterface $rhyQD, Filesystem $bjIIR)
    {
        $this->JlEZP = $rhyQD;
        $this->QxLu3 = $bjIIR;
    }
    public function saveMetadata(string $qMhfW, array $bsvnL)
    {
        goto haYRd;
        T0t8N:
        if (!$JhYqb->update($Yh3GL)) {
            goto ZAH68;
        }
        goto P7Yxf;
        gk5XM:
        XyMsz:
        goto sQDJa;
        QQrvt:
        if (!isset($bsvnL['resolution'])) {
            goto ycrf6;
        }
        goto pYX9p;
        YcqLw:
        if (!isset($bsvnL['thumbnail_url'])) {
            goto krUW6;
        }
        goto GwO3x;
        lAzxD:
        unset($Yh3GL['thumbnail']);
        goto ihLQX;
        eTvg9:
        if (!isset($bsvnL['fps'])) {
            goto XyMsz;
        }
        goto KCm1M;
        fWKIg:
        if (!isset($bsvnL['thumbnail'])) {
            goto VLrrx;
        }
        goto DbhKk;
        dcxuK:
        throw new \Exception("NYx4mhlHSMgHF metadata store failed for unknown reason ... " . $qMhfW);
        goto XJPRr;
        G5mKK:
        $Yh3GL['duration'] = $bsvnL['duration'];
        goto DpmMu;
        o5z8d:
        return $JhYqb->getView();
        goto IHTgA;
        sQDJa:
        if (!$JhYqb->PVDri) {
            goto yBRn0;
        }
        goto lAzxD;
        fKZw9:
        krUW6:
        goto fWKIg;
        pYX9p:
        $Yh3GL['resolution'] = $bsvnL['resolution'];
        goto uTr2W;
        CbvoJ:
        $Yh3GL = [];
        goto YcqLw;
        haYRd:
        $JhYqb = NYx4mhlHSMgHF::findOrFail($qMhfW);
        goto CbvoJ;
        ihLQX:
        yBRn0:
        goto T0t8N;
        KCm1M:
        $Yh3GL['fps'] = $bsvnL['fps'];
        goto gk5XM;
        P7Yxf:
        if (!(isset($bsvnL['change_status']) && $bsvnL['change_status'])) {
            goto d8J90;
        }
        goto uICFU;
        uICFU:
        $this->JlEZP->updateFile($JhYqb->getAttribute('id'), TSfaBZEUMcbl0::PROCESSING);
        goto BxibS;
        GwO3x:
        $Yh3GL['thumbnail'] = $bsvnL['thumbnail_url'];
        goto fKZw9;
        EuYfC:
        if (!isset($bsvnL['duration'])) {
            goto ikm9X;
        }
        goto G5mKK;
        DpmMu:
        ikm9X:
        goto QQrvt;
        BxibS:
        d8J90:
        goto o5z8d;
        uTr2W:
        ycrf6:
        goto eTvg9;
        IHTgA:
        ZAH68:
        goto Fzs1T;
        DbhKk:
        try {
            goto EtWAx;
            pWjGX:
            $Yh3GL['thumbnail'] = $f_EWh['filename'];
            goto j5OsB;
            EtWAx:
            $f_EWh = $this->JlEZP->storeSingleFile(new class($bsvnL['thumbnail']) implements SingleUploadInterface
            {
                private $d3RM8;
                public function __construct($ZPsYd)
                {
                    $this->d3RM8 = $ZPsYd;
                }
                public function getFile()
                {
                    return $this->d3RM8;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto y1pEL;
            y1pEL:
            $Yh3GL['thumbnail_id'] = $f_EWh['id'];
            goto pWjGX;
            j5OsB:
        } catch (\Throwable $jupeT) {
            Log::warning("NYx4mhlHSMgHF thumbnail store failed: " . $jupeT->getMessage());
        }
        goto oOQbc;
        Fzs1T:
        Log::warning("NYx4mhlHSMgHF metadata store failed for unknown reason ... " . $qMhfW);
        goto dcxuK;
        oOQbc:
        VLrrx:
        goto EuYfC;
        XJPRr:
    }
    public function createThumbnail(string $L5KaZ) : void
    {
        goto uRXMP;
        ap8iu:
        try {
            goto sl3Xf;
            FGfI3:
            $kRz4H = $LeLrV->get('QueueUrl');
            goto uEsEq;
            uEsEq:
            $hAaAy->sendMessage(['QueueUrl' => $kRz4H, 'MessageBody' => json_encode(['file_path' => $JhYqb->getLocation()])]);
            goto hh3Vs;
            sl3Xf:
            $LeLrV = $hAaAy->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto FGfI3;
            hh3Vs:
        } catch (\Throwable $X3u3n) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$X3u3n->getMessage()}");
        }
        goto q1Z69;
        IBF5u:
        $hAaAy = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto ap8iu;
        sK6ws:
        $SwPnY = "v2/hls/thumbnails/{$L5KaZ}/";
        goto cJreJ;
        j3HhJ:
        $JhYqb = NYx4mhlHSMgHF::findOrFail($L5KaZ);
        goto sK6ws;
        cJreJ:
        if (!(!$this->QxLu3->directoryExists($SwPnY) && empty($JhYqb->moeITb3KNRY()))) {
            goto MTY6G;
        }
        goto IBF5u;
        uRXMP:
        Log::info("Use Lambda to generate thumbnail for video: " . $L5KaZ);
        goto j3HhJ;
        q1Z69:
        MTY6G:
        goto nrOeh;
        nrOeh:
    }
    public function mwzCP3PuviL(string $L5KaZ) : void
    {
        goto Y45qe;
        jTfzH:
        Log::error("Message back with success data but not found thumbnail files " . $L5KaZ);
        goto u5ReE;
        WsV_Z:
        if ($this->QxLu3->directoryExists($SwPnY)) {
            goto WUsvM;
        }
        goto nOhob;
        wrS78:
        throw new \Exception("Message back with success data but not found thumbnail " . $L5KaZ);
        goto lBePN;
        dHJ39:
        u2CC6:
        goto SonLa;
        HWA0v:
        if (!(count($J4EAq) === 0)) {
            goto u2CC6;
        }
        goto jTfzH;
        TmcRq:
        $SwPnY = "v2/hls/thumbnails/{$L5KaZ}/";
        goto WsV_Z;
        nOhob:
        Log::error("Message back with success data but not found thumbnail " . $L5KaZ);
        goto wrS78;
        Y45qe:
        $JhYqb = NYx4mhlHSMgHF::findOrFail($L5KaZ);
        goto TmcRq;
        u5ReE:
        throw new \Exception("Message back with success data but not found thumbnail files " . $L5KaZ);
        goto dHJ39;
        SonLa:
        $JhYqb->update(['generated_previews' => $SwPnY]);
        goto VcLn_;
        vrHLT:
        $J4EAq = $this->QxLu3->files($SwPnY);
        goto HWA0v;
        lBePN:
        WUsvM:
        goto vrHLT;
        VcLn_:
    }
    public function getThumbnails(string $L5KaZ) : array
    {
        $JhYqb = NYx4mhlHSMgHF::findOrFail($L5KaZ);
        return $JhYqb->getThumbnails();
    }
    public function getMedia(string $L5KaZ) : array
    {
        $lOhz0 = Media::findOrFail($L5KaZ);
        return $lOhz0->getView();
    }
}
