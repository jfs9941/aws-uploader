<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\SsxWbUYXracun;
final class IEXX2bisrgAPc implements VideoPostHandleServiceInterface
{
    private $Er158;
    private $dhrkT;
    public function __construct(UploadServiceInterface $iwgB2, Filesystem $v8n0s)
    {
        $this->Er158 = $iwgB2;
        $this->dhrkT = $v8n0s;
    }
    public function saveMetadata(string $cQqZd, array $ag5JI)
    {
        goto BQ5xs;
        RiWjE:
        if (!$WKps1->update($nJ_X8)) {
            goto ovZpp;
        }
        goto LJeQO;
        X95Li:
        $nJ_X8['duration'] = $ag5JI['duration'];
        goto Ju2tI;
        uuuyF:
        if (!isset($ag5JI['resolution'])) {
            goto bWidB;
        }
        goto W6_ku;
        eyI2i:
        JqUS8:
        goto UTLMN;
        PMQHZ:
        $nJ_X8 = [];
        goto hyRq1;
        mgQBx:
        unset($nJ_X8['thumbnail']);
        goto EheSs;
        homJg:
        throw new \Exception("G4MP13yRAmltw metadata store failed for unknown reason ... " . $cQqZd);
        goto vZA08;
        Xi0Fv:
        return $WKps1->getView();
        goto Q3YpH;
        KlitJ:
        Log::warning("G4MP13yRAmltw metadata store failed for unknown reason ... " . $cQqZd);
        goto homJg;
        oGLTN:
        $nJ_X8['fps'] = $ag5JI['fps'];
        goto DDzu5;
        Ju2tI:
        aoXaJ:
        goto uuuyF;
        hyRq1:
        if (!isset($ag5JI['thumbnail'])) {
            goto JqUS8;
        }
        goto sgxKy;
        TQ3Wv:
        bWidB:
        goto rTrfI;
        LJeQO:
        if (!(isset($ag5JI['change_status']) && $ag5JI['change_status'])) {
            goto lkxTp;
        }
        goto PduOd;
        UTLMN:
        if (!isset($ag5JI['duration'])) {
            goto aoXaJ;
        }
        goto X95Li;
        W6_ku:
        $nJ_X8['resolution'] = $ag5JI['resolution'];
        goto TQ3Wv;
        xfJdJ:
        lkxTp:
        goto Xi0Fv;
        DDzu5:
        uPJkM:
        goto tInfN;
        EheSs:
        pVX_9:
        goto RiWjE;
        rTrfI:
        if (!isset($ag5JI['fps'])) {
            goto uPJkM;
        }
        goto oGLTN;
        Q3YpH:
        ovZpp:
        goto KlitJ;
        BQ5xs:
        $WKps1 = G4MP13yRAmltw::findOrFail($cQqZd);
        goto PMQHZ;
        sgxKy:
        try {
            goto Ms4BW;
            Ms4BW:
            $DU5Lh = $this->Er158->storeSingleFile(new class($ag5JI['thumbnail']) implements SingleUploadInterface
            {
                private $MF3ET;
                public function __construct($tscCi)
                {
                    $this->MF3ET = $tscCi;
                }
                public function getFile()
                {
                    return $this->MF3ET;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto FiBww;
            FiBww:
            $nJ_X8['thumbnail_id'] = $DU5Lh['id'];
            goto wc2W8;
            wc2W8:
            $nJ_X8['thumbnail'] = $DU5Lh['filename'];
            goto loncN;
            loncN:
        } catch (\Throwable $mz5ks) {
            Log::warning("G4MP13yRAmltw thumbnail store failed: " . $mz5ks->getMessage());
        }
        goto eyI2i;
        PduOd:
        $this->Er158->updateFile($WKps1->getAttribute('id'), SsxWbUYXracun::PROCESSING);
        goto xfJdJ;
        tInfN:
        if (!$WKps1->FH5aS) {
            goto pVX_9;
        }
        goto mgQBx;
        vZA08:
    }
    public function createThumbnail(string $nE8tG) : void
    {
        goto vtfAC;
        gfAxN:
        seOSv:
        goto h0zYC;
        G8QHU:
        $VlHgt = "v2/hls/thumbnails/{$nE8tG}/";
        goto mapfn;
        wxxvJ:
        $WKps1 = G4MP13yRAmltw::findOrFail($nE8tG);
        goto G8QHU;
        mapfn:
        if (!(!$this->dhrkT->directoryExists($VlHgt) && empty($WKps1->mevdJWCNKlG()))) {
            goto seOSv;
        }
        goto JF4wp;
        JF4wp:
        $c01zF = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto OpuSJ;
        vtfAC:
        Log::info("Use Lambda to generate thumbnail for video: " . $nE8tG);
        goto wxxvJ;
        OpuSJ:
        try {
            goto Plx3M;
            KDi3E:
            $taStc = $YC3pz->get('QueueUrl');
            goto KIzx6;
            KIzx6:
            $c01zF->sendMessage(['QueueUrl' => $taStc, 'MessageBody' => json_encode(['file_path' => $WKps1->getLocation()])]);
            goto fuvN1;
            Plx3M:
            $YC3pz = $c01zF->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto KDi3E;
            fuvN1:
        } catch (\Throwable $xA1Kf) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$xA1Kf->getMessage()}");
        }
        goto gfAxN;
        h0zYC:
    }
    public function mPPCbEmvyDT(string $nE8tG) : void
    {
        goto Is1Ng;
        NoQu4:
        frO9N:
        goto zUybm;
        KzzUj:
        mPm2r:
        goto lE0m9;
        AtYW1:
        Log::error("Message back with success data but not found thumbnail " . $nE8tG);
        goto phdW8;
        ljY4D:
        $VlHgt = "v2/hls/thumbnails/{$nE8tG}/";
        goto MURgQ;
        MnWw6:
        Log::error("Message back with success data but not found thumbnail files " . $nE8tG);
        goto hoSfZ;
        phdW8:
        throw new \Exception("Message back with success data but not found thumbnail " . $nE8tG);
        goto KzzUj;
        hoSfZ:
        throw new \Exception("Message back with success data but not found thumbnail files " . $nE8tG);
        goto NoQu4;
        SAFvL:
        if (!(count($uclEW) === 0)) {
            goto frO9N;
        }
        goto MnWw6;
        zUybm:
        $WKps1->update(['generated_previews' => $VlHgt]);
        goto a8Qmd;
        Is1Ng:
        $WKps1 = G4MP13yRAmltw::findOrFail($nE8tG);
        goto ljY4D;
        MURgQ:
        if ($this->dhrkT->directoryExists($VlHgt)) {
            goto mPm2r;
        }
        goto AtYW1;
        lE0m9:
        $uclEW = $this->dhrkT->files($VlHgt);
        goto SAFvL;
        a8Qmd:
    }
    public function getThumbnails(string $nE8tG) : array
    {
        $WKps1 = G4MP13yRAmltw::findOrFail($nE8tG);
        return $WKps1->getThumbnails();
    }
}
