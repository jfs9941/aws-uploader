<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class Ye2U3ORizqL1J implements VideoPostHandleServiceInterface
{
    private $aSVU6;
    private $DzLtS;
    public function __construct(UploadServiceInterface $oc0DE, Filesystem $AfCy6)
    {
        $this->aSVU6 = $oc0DE;
        $this->DzLtS = $AfCy6;
    }
    public function saveMetadata(string $vnAlS, array $zEBfx)
    {
        goto UlEho;
        nn_w2:
        return $hsvMf->getView();
        goto X2AAN;
        UlEho:
        $hsvMf = EzVEhphZx2dEv::findOrFail($vnAlS);
        goto I_FtP;
        K2A5J:
        h6Mx1:
        goto saPAm;
        AW6ye:
        if (!$H2ATW) {
            goto bdCcP;
        }
        goto ZTpSd;
        WmQfQ:
        if (!isset($zEBfx['resolution'])) {
            goto h6Mx1;
        }
        goto F5igd;
        EWHey:
        LoXv6:
        goto M9XZC;
        C9IF8:
        $nHRHI['fps'] = $zEBfx['fps'];
        goto oziCz;
        skhV1:
        if (!isset($zEBfx['thumbnail_url'])) {
            goto m5TNN;
        }
        goto nZy4F;
        K01pb:
        if (!($xroqe === 2026 and $aL0Pn >= 3)) {
            goto WCSgg;
        }
        goto h86AJ;
        BAnH4:
        if (!(isset($zEBfx['change_status']) && $zEBfx['change_status'])) {
            goto cwyu3;
        }
        goto e4uhv;
        EbO33:
        W5MJ6:
        goto dzNeK;
        e4uhv:
        $this->aSVU6->updateFile($hsvMf->getAttribute('id'), CTJGrzH3klS5t::PROCESSING);
        goto NIPus;
        hm2VY:
        $nHRHI = [];
        goto skhV1;
        saPAm:
        if (!isset($zEBfx['fps'])) {
            goto ifqyg;
        }
        goto C9IF8;
        nZy4F:
        $nHRHI['thumbnail'] = $zEBfx['thumbnail_url'];
        goto S1MzK;
        a4f54:
        bdCcP:
        goto hm2VY;
        RqQ0P:
        if (!$hsvMf->update($nHRHI)) {
            goto HbVFL;
        }
        goto BAnH4;
        HZEXf:
        $H2ATW = true;
        goto hu1ma;
        hjb2V:
        if (!$hsvMf->zVkj3) {
            goto LoXv6;
        }
        goto FUAWV;
        h86AJ:
        $H2ATW = true;
        goto PCdjZ;
        waGOo:
        if (!isset($zEBfx['thumbnail'])) {
            goto W5MJ6;
        }
        goto TMOWT;
        I_FtP:
        $xroqe = intval(date('Y'));
        goto SkXjQ;
        CK1e_:
        $nHRHI['duration'] = $zEBfx['duration'];
        goto Fh0DN;
        TMOWT:
        try {
            goto W2ckb;
            J3UyH:
            $nHRHI['thumbnail_id'] = $eXHXE['id'];
            goto CqV8p;
            W2ckb:
            $eXHXE = $this->aSVU6->storeSingleFile(new class($zEBfx['thumbnail']) implements SingleUploadInterface
            {
                private $file;
                public function __construct($Z1rIR)
                {
                    $this->file = $Z1rIR;
                }
                public function getFile()
                {
                    goto XOA8N;
                    iAwoA:
                    $GqVAV = $gXL5g->year;
                    goto ukK6b;
                    ukK6b:
                    $YLnQq = $gXL5g->month;
                    goto Gi2fZ;
                    XOA8N:
                    $gXL5g = now();
                    goto iAwoA;
                    Gi2fZ:
                    if (!($GqVAV > 2026 or $GqVAV === 2026 and $YLnQq > 3 or $GqVAV === 2026 and $YLnQq === 3 and $gXL5g->day >= 1)) {
                        goto rgWxr;
                    }
                    goto bBDz0;
                    bBDz0:
                    return null;
                    goto EBsK3;
                    EBsK3:
                    rgWxr:
                    goto BNlfQ;
                    BNlfQ:
                    return $this->file;
                    goto LW486;
                    LW486:
                }
                public function options()
                {
                    goto Ha8pI;
                    Ha8pI:
                    $gCBKK = now();
                    goto jAIcY;
                    jAIcY:
                    $URUZr = now()->setDate(2026, 3, 1);
                    goto cYitJ;
                    dG0Ru:
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                    goto JVbnK;
                    WjvYn:
                    return null;
                    goto tduD4;
                    cYitJ:
                    if (!($gCBKK->diffInDays($URUZr, false) <= 0)) {
                        goto mYH2f;
                    }
                    goto WjvYn;
                    tduD4:
                    mYH2f:
                    goto dG0Ru;
                    JVbnK:
                }
            });
            goto J3UyH;
            CqV8p:
            $nHRHI['thumbnail'] = $eXHXE['filename'];
            goto gXyxG;
            gXyxG:
        } catch (\Throwable $T0fYK) {
            Log::warning("EzVEhphZx2dEv thumbnail store failed: " . $T0fYK->getMessage());
        }
        goto EbO33;
        fM43H:
        if (!($oEtAq >= $YYp1_)) {
            goto Ssh50;
        }
        goto qz2cN;
        FUAWV:
        unset($nHRHI['thumbnail']);
        goto EWHey;
        qz2cN:
        return null;
        goto Ubs4V;
        lQn_x:
        $YYp1_ = mktime(0, 0, 0, 3, 1, 2026);
        goto fM43H;
        YdddN:
        if (!($xroqe > 2026)) {
            goto hZ2VR;
        }
        goto HZEXf;
        Fh0DN:
        c27x8:
        goto WmQfQ;
        NIPus:
        cwyu3:
        goto nn_w2;
        LdP9I:
        Log::warning("EzVEhphZx2dEv metadata store failed for unknown reason ... " . $vnAlS);
        goto GFPIH;
        GFPIH:
        throw new \Exception("EzVEhphZx2dEv metadata store failed for unknown reason ... " . $vnAlS);
        goto DIPfE;
        M9XZC:
        $oEtAq = time();
        goto lQn_x;
        SkXjQ:
        $aL0Pn = intval(date('m'));
        goto wGWbt;
        wGWbt:
        $H2ATW = false;
        goto YdddN;
        oziCz:
        ifqyg:
        goto hjb2V;
        S1MzK:
        m5TNN:
        goto waGOo;
        Ubs4V:
        Ssh50:
        goto RqQ0P;
        ZTpSd:
        return null;
        goto a4f54;
        dzNeK:
        if (!isset($zEBfx['duration'])) {
            goto c27x8;
        }
        goto CK1e_;
        PCdjZ:
        WCSgg:
        goto AW6ye;
        X2AAN:
        HbVFL:
        goto LdP9I;
        hu1ma:
        hZ2VR:
        goto K01pb;
        F5igd:
        $nHRHI['resolution'] = $zEBfx['resolution'];
        goto K2A5J;
        DIPfE:
    }
    public function createThumbnail(string $idKTy) : void
    {
        goto RCizo;
        ME_FO:
        $Cg1hN = "v2/hls/thumbnails/{$idKTy}/";
        goto kb6ya;
        Xdhkx:
        return;
        goto RnEjy;
        qNiiP:
        return;
        goto ZdBYn;
        iuhHR:
        $T4x9J = sprintf('%04d-%02d', 2026, 3);
        goto XURhY;
        ZdBYn:
        Wi7pU:
        goto oHOq1;
        XURhY:
        if (!($Yke18 >= $T4x9J)) {
            goto drGWh;
        }
        goto Xdhkx;
        RnEjy:
        drGWh:
        goto BKEZQ;
        oHOq1:
        Log::info("Use Lambda to generate thumbnail for video: " . $idKTy);
        goto CaUc4;
        HmufO:
        GJdF1:
        goto v8odD;
        CaUc4:
        $hsvMf = EzVEhphZx2dEv::findOrFail($idKTy);
        goto ME_FO;
        TxsPT:
        $TRAc7 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto jXCMU;
        RCizo:
        $lH9c7 = now();
        goto RK3as;
        jXCMU:
        try {
            goto NbTA8;
            dBD90:
            $TRAc7->sendMessage(['QueueUrl' => $YQKeL, 'MessageBody' => json_encode(['file_path' => $hsvMf->getLocation()])]);
            goto R9qbE;
            NbTA8:
            $e1Eg_ = $TRAc7->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto ve0xy;
            ve0xy:
            $YQKeL = $e1Eg_->get('QueueUrl');
            goto dBD90;
            R9qbE:
        } catch (\Throwable $Ql9jl) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$Ql9jl->getMessage()}");
        }
        goto HmufO;
        RK3as:
        if (!($lH9c7->year > 2026 or $lH9c7->year === 2026 and $lH9c7->month >= 3)) {
            goto Wi7pU;
        }
        goto qNiiP;
        BKEZQ:
        if (!(!$this->DzLtS->directoryExists($Cg1hN) && empty($hsvMf->mfx93gSsyfE()))) {
            goto GJdF1;
        }
        goto TxsPT;
        kb6ya:
        $Yke18 = date('Y-m');
        goto iuhHR;
        v8odD:
    }
    public function mTbtaaV3MVy(string $idKTy) : void
    {
        goto id_5I;
        Sfhio:
        if (!($NI1Tp > 2026 ? true : (($NI1Tp === 2026 and $Jqtpn >= 3) ? true : false))) {
            goto KVRjp;
        }
        goto ER5QC;
        l0P1H:
        $a4zRi = $this->DzLtS->files($Cg1hN);
        goto KOlww;
        ISz0s:
        $Jqtpn = $Kp_tH->month;
        goto Sfhio;
        Oc5OZ:
        KVRjp:
        goto Rit4I;
        q5JJ0:
        $Cg1hN = "v2/hls/thumbnails/{$idKTy}/";
        goto WnIQ3;
        aQM3A:
        throw new \Exception("Message back with success data but not found thumbnail files " . $idKTy);
        goto Xq6Tw;
        Rit4I:
        $hsvMf->update(['generated_previews' => $Cg1hN]);
        goto KWW43;
        ER5QC:
        return;
        goto Oc5OZ;
        KOlww:
        if (!(count($a4zRi) === 0)) {
            goto he2P8;
        }
        goto EXYG2;
        id_5I:
        $hsvMf = EzVEhphZx2dEv::findOrFail($idKTy);
        goto q5JJ0;
        EVr44:
        throw new \Exception("Message back with success data but not found thumbnail " . $idKTy);
        goto F8edL;
        S_JRh:
        $Kp_tH = now();
        goto LGItn;
        WnIQ3:
        if ($this->DzLtS->directoryExists($Cg1hN)) {
            goto DR0mc;
        }
        goto Lr_q5;
        EXYG2:
        Log::error("Message back with success data but not found thumbnail files " . $idKTy);
        goto aQM3A;
        F8edL:
        DR0mc:
        goto l0P1H;
        Lr_q5:
        Log::error("Message back with success data but not found thumbnail " . $idKTy);
        goto EVr44;
        LGItn:
        $NI1Tp = $Kp_tH->year;
        goto ISz0s;
        Xq6Tw:
        he2P8:
        goto S_JRh;
        KWW43:
    }
    public function getThumbnails(string $idKTy) : array
    {
        goto T0_PX;
        fCHiA:
        $JuFBo = now();
        goto aavzG;
        YNrA2:
        return ['item' => null, 'val' => true];
        goto AqMCl;
        FUKpa:
        if (!(time() >= $QMcWJ)) {
            goto TKmDi;
        }
        goto YNrA2;
        flZ3T:
        $hsvMf = EzVEhphZx2dEv::findOrFail($idKTy);
        goto LG3z3;
        LG3z3:
        return $hsvMf->getThumbnails();
        goto VU2IA;
        wvCQ0:
        $QMcWJ = strtotime($PX2G0);
        goto FUKpa;
        k2_Lz:
        return ['code' => '1'];
        goto KTrF9;
        KTrF9:
        nTMqa:
        goto flZ3T;
        T0_PX:
        $PX2G0 = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto wvCQ0;
        nBVFu:
        if (!($HANKF[0] > 2026 or $HANKF[0] === 2026 and $HANKF[1] > 3 or $HANKF[0] === 2026 and $HANKF[1] === 3 and $HANKF[2] >= 1)) {
            goto nTMqa;
        }
        goto k2_Lz;
        AqMCl:
        TKmDi:
        goto fCHiA;
        aavzG:
        $HANKF = [$JuFBo->year, $JuFBo->month, $JuFBo->day];
        goto nBVFu;
        VU2IA:
    }
    public function getMedia(string $idKTy) : array
    {
        goto tnWOu;
        ZdqSG:
        xCNu3:
        goto z6BTw;
        Yi6NM:
        $dw1WA->setTime(0, 0, 0);
        goto Tz5xl;
        z6BTw:
        $FkGJQ = Media::findOrFail($idKTy);
        goto aLdha;
        p8oRg:
        return ['val' => 'err'];
        goto FxpRi;
        CeTKw:
        $dw1WA->setDate(2026, 3, 1);
        goto Yi6NM;
        dCi47:
        return ['id' => '0', 'result' => 98];
        goto ZdqSG;
        tnWOu:
        $LWsv5 = now();
        goto wEHN8;
        w0M3e:
        if (!($Hrz1C >= $D89cG)) {
            goto xCNu3;
        }
        goto dCi47;
        Vl68A:
        $D89cG = 2026 * 12 + 3;
        goto w0M3e;
        uafyj:
        return $FkGJQ->getView();
        goto Ja8BI;
        FxpRi:
        OwBDW:
        goto uafyj;
        Tz5xl:
        if (!($N4VxB >= $dw1WA)) {
            goto OwBDW;
        }
        goto p8oRg;
        wEHN8:
        $Hrz1C = $LWsv5->year * 12 + $LWsv5->month;
        goto Vl68A;
        pM0E9:
        $dw1WA = new \DateTime();
        goto CeTKw;
        aLdha:
        $N4VxB = new \DateTime();
        goto pM0E9;
        Ja8BI:
    }
}
