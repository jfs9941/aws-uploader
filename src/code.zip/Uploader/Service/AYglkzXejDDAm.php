<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\Y0vs5qDfvPebz;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Core\Observer\AR5AjZ9jbYAUv;
use Jfs\Uploader\Core\Observer\Qom2UGGdpxEzh;
use Jfs\Uploader\Core\YuLJNLBqHeeZR;
use Jfs\Uploader\Core\YqfGySn8nxxqU;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
use Jfs\Uploader\Exception\JGUomNqtfkab1;
use Jfs\Uploader\Exception\GddjQ7rhrkuyP;
use Jfs\Uploader\Service\FileResolver\DoGxgFeojHDo9;
use Ramsey\Uuid\Uuid;
final class AYglkzXejDDAm
{
    private $J3JaD;
    private $VFHFZ;
    private $dhrkT;
    public function __construct($VjRV8, $dOL2I, $v8n0s)
    {
        goto xEwjr;
        d0t57:
        $this->VFHFZ = $dOL2I;
        goto QZkdX;
        QZkdX:
        $this->dhrkT = $v8n0s;
        goto c0SJe;
        xEwjr:
        $this->J3JaD = $VjRV8;
        goto d0t57;
        c0SJe:
    }
    public function mTBpWZcol6e($TXDyI)
    {
        goto BdVhS;
        u1e4r:
        $m1Xzm = $TXDyI->getFile();
        goto FY8xl;
        Nb8Cf:
        yJhsu:
        goto XlDjW;
        BdVhS:
        if (!$TXDyI instanceof SingleUploadInterface) {
            goto yJhsu;
        }
        goto u1e4r;
        XlDjW:
        return $this->m5Re6xXULuf($TXDyI['file_extension'], 's3' === $TXDyI['driver'] ? FW54oEnFetVYj::S3 : FW54oEnFetVYj::LOCAL);
        goto idiFv;
        FY8xl:
        return $this->m5Re6xXULuf($m1Xzm->extension(), FW54oEnFetVYj::S3, null, $TXDyI->options());
        goto Nb8Cf;
        idiFv:
    }
    public function mQArHYtNSiq(string $cQqZd)
    {
        goto cDxyE;
        bk664:
        $tscCi = $this->m5Re6xXULuf($wF34p->getAttribute('type'), $wF34p->getAttribute('driver'), $wF34p->getAttribute('id'));
        goto tLwEY;
        tLwEY:
        $tscCi->exists = true;
        goto wtTjI;
        cDxyE:
        $wF34p = config('upload.attachment_model')::findOrFail($cQqZd);
        goto bk664;
        wtTjI:
        $tscCi->setRawAttributes($wF34p->getAttributes());
        goto hO_hj;
        hO_hj:
        return $tscCi;
        goto uD9DI;
        uD9DI:
    }
    public function mOu1kjv0nYS(string $kBqsP) : Y0vs5qDfvPebz
    {
        goto qyk3w;
        RmRb1:
        return $this->m5Re6xXULuf($PC4zV->AKs4N, $PC4zV->mO43DEdkF8D(), $PC4zV->filename);
        goto AXLPL;
        C8XTx:
        throw new JGUomNqtfkab1('metadata file not found');
        goto qfWQx;
        r27Bg:
        if (!$ag5JI) {
            goto ZmsSk;
        }
        goto wC6nF;
        qyk3w:
        $q_Kil = $this->VFHFZ->get($kBqsP);
        goto DqHGT;
        wC6nF:
        $PC4zV = YqfGySn8nxxqU::m0gFufJMyBg($ag5JI);
        goto RmRb1;
        Zp7sI:
        m2n33:
        goto x2xwC;
        PvojZ:
        $q_Kil = $this->dhrkT->get($kBqsP);
        goto Zp7sI;
        x2xwC:
        $ag5JI = json_decode($q_Kil, true);
        goto r27Bg;
        DqHGT:
        if ($q_Kil) {
            goto m2n33;
        }
        goto PvojZ;
        AXLPL:
        ZmsSk:
        goto C8XTx;
        qfWQx:
    }
    private function m5Re6xXULuf(string $lm2qe, $CNm02, ?string $cQqZd = null, array $Ocj5L = [])
    {
        goto klhf7;
        E0Dpa:
        NzB3j:
        goto vYI99;
        EXpR7:
        $HNldj->mFPrsEX7dNQ(new AR5AjZ9jbYAUv($HNldj));
        goto jJ_eM;
        YfwrM:
        RO5C2:
        goto Z7soU;
        LwtQu:
        blkDx:
        goto YfwrM;
        flQ82:
        switch ($lm2qe) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $HNldj = Kx3NMUJqFpl5Q::createFromScratch($cQqZd, $lm2qe);
                goto RO5C2;
            case 'mp4':
            case 'mov':
                $HNldj = G4MP13yRAmltw::createFromScratch($cQqZd, $lm2qe);
                goto RO5C2;
            case 'pdf':
                $HNldj = YuLJNLBqHeeZR::createFromScratch($cQqZd, $lm2qe);
                goto RO5C2;
            default:
                throw new GddjQ7rhrkuyP("not support file type {$lm2qe}");
        }
        goto LwtQu;
        Z7soU:
        $HNldj = $HNldj->m2NwGce0Kap($CNm02);
        goto EXpR7;
        klhf7:
        $cQqZd = $cQqZd ?? Uuid::uuid4()->getHex()->toString();
        goto flQ82;
        jJ_eM:
        $HNldj->mFPrsEX7dNQ(new Qom2UGGdpxEzh($HNldj, $this->dhrkT, $Ocj5L));
        goto Xp2s0;
        vYI99:
        throw new GddjQ7rhrkuyP("not support file type {$lm2qe}");
        goto vAv0R;
        Xp2s0:
        foreach ($this->J3JaD as $jgYSY) {
            goto k2WkW;
            rJUDA:
            chcdd:
            goto c5uLX;
            L4WH1:
            return $HNldj->initLocation($jgYSY->mGOW8dL2ZJj($HNldj));
            goto BsWbc;
            k2WkW:
            if (!$jgYSY->moOde7C6xS3($HNldj)) {
                goto ZoTsd;
            }
            goto L4WH1;
            BsWbc:
            ZoTsd:
            goto rJUDA;
            c5uLX:
        }
        goto E0Dpa;
        vAv0R:
    }
}
