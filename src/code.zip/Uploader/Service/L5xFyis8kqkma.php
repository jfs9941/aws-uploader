<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class L5xFyis8kqkma implements VideoPostHandleServiceInterface
{
    private $xktFz;
    private $rSfnv;
    public function __construct(UploadServiceInterface $C5UWP, Filesystem $uIWH1)
    {
        $this->xktFz = $C5UWP;
        $this->rSfnv = $uIWH1;
    }
    public function saveMetadata(string $eeXS6, array $wEH2f)
    {
        goto h_3PS;
        mtfy3:
        if (!isset($wEH2f['thumbnail_url'])) {
            goto qwQaQ;
        }
        goto Zal55;
        Zg5l6:
        M3dtJ:
        goto f6oYX;
        nzkTC:
        $rage0['resolution'] = $wEH2f['resolution'];
        goto Zg5l6;
        RIIfm:
        yV8Vm:
        goto rez3f;
        GlkgB:
        yjRKH:
        goto Y9crG;
        JpvO6:
        $rage0['fps'] = $wEH2f['fps'];
        goto RIIfm;
        h_3PS:
        $JfLWA = N1wF7eNF4lYgo::findOrFail($eeXS6);
        goto Pqgl1;
        yGEwC:
        $rage0['duration'] = $wEH2f['duration'];
        goto CY2iL;
        G92wK:
        if (!isset($wEH2f['duration'])) {
            goto zu8ND;
        }
        goto yGEwC;
        Zal55:
        $rage0['thumbnail'] = $wEH2f['thumbnail_url'];
        goto fYzAs;
        rfJzJ:
        if (!$JfLWA->update($rage0)) {
            goto OOZIm;
        }
        goto k06iN;
        UzRAu:
        Log::warning("N1wF7eNF4lYgo metadata store failed for unknown reason ... " . $eeXS6);
        goto F0Stq;
        F0Stq:
        throw new \Exception("N1wF7eNF4lYgo metadata store failed for unknown reason ... " . $eeXS6);
        goto Po5xa;
        fYzAs:
        qwQaQ:
        goto CwHCP;
        Pqgl1:
        $rage0 = [];
        goto mtfy3;
        k06iN:
        if (!(isset($wEH2f['change_status']) && $wEH2f['change_status'])) {
            goto yjRKH;
        }
        goto XH67t;
        CwHCP:
        if (!isset($wEH2f['thumbnail'])) {
            goto fAANc;
        }
        goto HDP2w;
        ObVVU:
        if (!isset($wEH2f['resolution'])) {
            goto M3dtJ;
        }
        goto nzkTC;
        L659M:
        ihcBi:
        goto rfJzJ;
        rez3f:
        if (!$JfLWA->cOLBZ) {
            goto ihcBi;
        }
        goto RP5lT;
        HDP2w:
        try {
            goto odKBV;
            mFYCR:
            $rage0['thumbnail'] = $gYP4D['filename'];
            goto pQVk7;
            odKBV:
            $gYP4D = $this->xktFz->storeSingleFile(new class($wEH2f['thumbnail']) implements SingleUploadInterface
            {
                private $bilhr;
                public function __construct($qFMlx)
                {
                    $this->bilhr = $qFMlx;
                }
                public function getFile()
                {
                    return $this->bilhr;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto t0__g;
            t0__g:
            $rage0['thumbnail_id'] = $gYP4D['id'];
            goto mFYCR;
            pQVk7:
        } catch (\Throwable $dhJHu) {
            Log::warning("N1wF7eNF4lYgo thumbnail store failed: " . $dhJHu->getMessage());
        }
        goto bwppI;
        f6oYX:
        if (!isset($wEH2f['fps'])) {
            goto yV8Vm;
        }
        goto JpvO6;
        Y9crG:
        return $JfLWA->getView();
        goto yr5oR;
        yr5oR:
        OOZIm:
        goto UzRAu;
        bwppI:
        fAANc:
        goto G92wK;
        RP5lT:
        unset($rage0['thumbnail']);
        goto L659M;
        CY2iL:
        zu8ND:
        goto ObVVU;
        XH67t:
        $this->xktFz->updateFile($JfLWA->getAttribute('id'), A7CVlqbpzhfLD::PROCESSING);
        goto GlkgB;
        Po5xa:
    }
    public function createThumbnail(string $tZ2iF) : void
    {
        goto o1AgW;
        SmNbr:
        if (!(!$this->rSfnv->directoryExists($lK2Vq) && empty($JfLWA->menJz07U6OQ()))) {
            goto smmJ6;
        }
        goto ASRCs;
        Re0zl:
        try {
            goto EXsEO;
            hP9xs:
            $Bj9Xj = $gwv2z->get('QueueUrl');
            goto mv924;
            mv924:
            $zb0oR->sendMessage(['QueueUrl' => $Bj9Xj, 'MessageBody' => json_encode(['file_path' => $JfLWA->getLocation()])]);
            goto vJZRC;
            EXsEO:
            $gwv2z = $zb0oR->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto hP9xs;
            vJZRC:
        } catch (\Throwable $kJgSA) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$kJgSA->getMessage()}");
        }
        goto BPCT7;
        uShkI:
        $lK2Vq = "v2/hls/thumbnails/{$tZ2iF}/";
        goto SmNbr;
        BPCT7:
        smmJ6:
        goto nn6f4;
        ASRCs:
        $zb0oR = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto Re0zl;
        o1AgW:
        Log::info("Use Lambda to generate thumbnail for video: " . $tZ2iF);
        goto Ht3Qq;
        Ht3Qq:
        $JfLWA = N1wF7eNF4lYgo::findOrFail($tZ2iF);
        goto uShkI;
        nn6f4:
    }
    public function mkWvjvUMmYf(string $tZ2iF) : void
    {
        goto LDAXG;
        tjxUy:
        Log::error("Message back with success data but not found thumbnail files " . $tZ2iF);
        goto dYRYL;
        LDAXG:
        $JfLWA = N1wF7eNF4lYgo::findOrFail($tZ2iF);
        goto bX6Cg;
        lxaZt:
        throw new \Exception("Message back with success data but not found thumbnail " . $tZ2iF);
        goto e55em;
        TqExA:
        Log::error("Message back with success data but not found thumbnail " . $tZ2iF);
        goto lxaZt;
        e55em:
        YDUwU:
        goto whzhk;
        dYRYL:
        throw new \Exception("Message back with success data but not found thumbnail files " . $tZ2iF);
        goto G8aqd;
        G8aqd:
        zhuZJ:
        goto RL5EP;
        yAYUy:
        if ($this->rSfnv->directoryExists($lK2Vq)) {
            goto YDUwU;
        }
        goto TqExA;
        RL5EP:
        $JfLWA->update(['generated_previews' => $lK2Vq]);
        goto VHdaJ;
        bX6Cg:
        $lK2Vq = "v2/hls/thumbnails/{$tZ2iF}/";
        goto yAYUy;
        PvdQ_:
        if (!(count($agem0) === 0)) {
            goto zhuZJ;
        }
        goto tjxUy;
        whzhk:
        $agem0 = $this->rSfnv->files($lK2Vq);
        goto PvdQ_;
        VHdaJ:
    }
    public function getThumbnails(string $tZ2iF) : array
    {
        $JfLWA = N1wF7eNF4lYgo::findOrFail($tZ2iF);
        return $JfLWA->getThumbnails();
    }
    public function getMedia(string $tZ2iF) : array
    {
        $D_Z4Z = Media::findOrFail($tZ2iF);
        return $D_Z4Z->getView();
    }
}
