<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class YgVoFfrzQglik implements VideoPostHandleServiceInterface
{
    private $lLwQV;
    private $SxfKN;
    public function __construct(UploadServiceInterface $Fsxoy, Filesystem $DPWG1)
    {
        $this->lLwQV = $Fsxoy;
        $this->SxfKN = $DPWG1;
    }
    public function saveMetadata(string $GMwD5, array $wt893)
    {
        goto Wyuh0;
        NO17A:
        if (!isset($wt893['fps'])) {
            goto hRyLb;
        }
        goto bBh1b;
        UvZ6p:
        throw new \Exception("RhdJGUi8FOLBJ metadata store failed for unknown reason ... " . $GMwD5);
        goto rRTkb;
        DARJ2:
        b79uf:
        goto O1Rtk;
        KLsZV:
        if (!$UUt0Z->LWDKv) {
            goto b79uf;
        }
        goto APRkN;
        O1Rtk:
        if (!$UUt0Z->update($xAeKl)) {
            goto Jtlec;
        }
        goto se2GC;
        LxZD_:
        if (!isset($wt893['thumbnail_url'])) {
            goto Meloy;
        }
        goto Qz4lN;
        GgVc2:
        Jtlec:
        goto E1nXs;
        se2GC:
        if (!(isset($wt893['change_status']) && $wt893['change_status'])) {
            goto EPJHg;
        }
        goto anM1P;
        GJ9h3:
        tDagn:
        goto NO17A;
        RmOuz:
        return $UUt0Z->getView();
        goto GgVc2;
        X82kh:
        $xAeKl = [];
        goto LxZD_;
        RrMxq:
        if (!isset($wt893['thumbnail'])) {
            goto SrtVg;
        }
        goto x0D7O;
        Wyuh0:
        $UUt0Z = RhdJGUi8FOLBJ::findOrFail($GMwD5);
        goto X82kh;
        bBh1b:
        $xAeKl['fps'] = $wt893['fps'];
        goto gvu2j;
        jtEMv:
        if (!isset($wt893['resolution'])) {
            goto tDagn;
        }
        goto NAtfo;
        VRAsK:
        $xAeKl['duration'] = $wt893['duration'];
        goto sqwE8;
        x0D7O:
        try {
            goto dVRwd;
            dVRwd:
            $gx7xw = $this->lLwQV->storeSingleFile(new class($wt893['thumbnail']) implements SingleUploadInterface
            {
                private $MhOEp;
                public function __construct($RB3Ub)
                {
                    $this->MhOEp = $RB3Ub;
                }
                public function getFile()
                {
                    return $this->MhOEp;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto ZrQIR;
            ZrQIR:
            $xAeKl['thumbnail_id'] = $gx7xw['id'];
            goto xjQYH;
            xjQYH:
            $xAeKl['thumbnail'] = $gx7xw['filename'];
            goto Ag2A4;
            Ag2A4:
        } catch (\Throwable $b6Bui) {
            Log::warning("RhdJGUi8FOLBJ thumbnail store failed: " . $b6Bui->getMessage());
        }
        goto YBlvI;
        E1nXs:
        Log::warning("RhdJGUi8FOLBJ metadata store failed for unknown reason ... " . $GMwD5);
        goto UvZ6p;
        GmRyc:
        if (!isset($wt893['duration'])) {
            goto NWTha;
        }
        goto VRAsK;
        Qz4lN:
        $xAeKl['thumbnail'] = $wt893['thumbnail_url'];
        goto y7GQ7;
        APRkN:
        unset($xAeKl['thumbnail']);
        goto DARJ2;
        vXS1x:
        EPJHg:
        goto RmOuz;
        YBlvI:
        SrtVg:
        goto GmRyc;
        gvu2j:
        hRyLb:
        goto KLsZV;
        sqwE8:
        NWTha:
        goto jtEMv;
        anM1P:
        $this->lLwQV->updateFile($UUt0Z->getAttribute('id'), Fsm7WCrUwVWh9::PROCESSING);
        goto vXS1x;
        NAtfo:
        $xAeKl['resolution'] = $wt893['resolution'];
        goto GJ9h3;
        y7GQ7:
        Meloy:
        goto RrMxq;
        rRTkb:
    }
    public function createThumbnail(string $kIF2h) : void
    {
        goto iqFy7;
        jHJ5R:
        $UUt0Z = RhdJGUi8FOLBJ::findOrFail($kIF2h);
        goto qLTH8;
        qLTH8:
        $rA0h7 = "v2/hls/thumbnails/{$kIF2h}/";
        goto BfShM;
        BfShM:
        if (!(!$this->SxfKN->directoryExists($rA0h7) && empty($UUt0Z->myIwWlFb6Za()))) {
            goto l5jxF;
        }
        goto OSfne;
        iqFy7:
        Log::info("Use Lambda to generate thumbnail for video: " . $kIF2h);
        goto jHJ5R;
        YiCuO:
        try {
            goto BrTCy;
            fqbER:
            $GT7Xe = $yT3oJ->get('QueueUrl');
            goto NAMOW;
            BrTCy:
            $yT3oJ = $ihyxN->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto fqbER;
            NAMOW:
            $ihyxN->sendMessage(['QueueUrl' => $GT7Xe, 'MessageBody' => json_encode(['file_path' => $UUt0Z->getLocation()])]);
            goto RlKVq;
            RlKVq:
        } catch (\Throwable $hPqRx) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$hPqRx->getMessage()}");
        }
        goto uFsAQ;
        OSfne:
        $ihyxN = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto YiCuO;
        uFsAQ:
        l5jxF:
        goto VAZ0y;
        VAZ0y:
    }
    public function m1vnDxRbgBE(string $kIF2h) : void
    {
        goto dy3Bh;
        IH_5e:
        AWgr3:
        goto NWvJT;
        D5nIw:
        if ($this->SxfKN->directoryExists($rA0h7)) {
            goto IwfkU;
        }
        goto Cga6F;
        dy3Bh:
        $UUt0Z = RhdJGUi8FOLBJ::findOrFail($kIF2h);
        goto vV22i;
        oFF8L:
        if (!(count($Ybwit) === 0)) {
            goto AWgr3;
        }
        goto ILkLi;
        X9C5U:
        throw new \Exception("Message back with success data but not found thumbnail files " . $kIF2h);
        goto IH_5e;
        vV22i:
        $rA0h7 = "v2/hls/thumbnails/{$kIF2h}/";
        goto D5nIw;
        ILkLi:
        Log::error("Message back with success data but not found thumbnail files " . $kIF2h);
        goto X9C5U;
        e6KZl:
        IwfkU:
        goto QJiMl;
        Cga6F:
        Log::error("Message back with success data but not found thumbnail " . $kIF2h);
        goto uv34V;
        uv34V:
        throw new \Exception("Message back with success data but not found thumbnail " . $kIF2h);
        goto e6KZl;
        QJiMl:
        $Ybwit = $this->SxfKN->files($rA0h7);
        goto oFF8L;
        NWvJT:
        $UUt0Z->update(['generated_previews' => $rA0h7]);
        goto w5CsC;
        w5CsC:
    }
    public function getThumbnails(string $kIF2h) : array
    {
        $UUt0Z = RhdJGUi8FOLBJ::findOrFail($kIF2h);
        return $UUt0Z->getThumbnails();
    }
    public function getMedia(string $kIF2h) : array
    {
        $jBims = Media::findOrFail($kIF2h);
        return $jBims->getView();
    }
}
