<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Core\XWqfTCKHy5X8X;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
final class WILlDNuoyQRBR implements MpZUpGr3YFIhj
{
    private $QbHVG;
    private $cpROw;
    public $WmgCT;
    private $WeXvt;
    private $gdG3t;
    private $gq_yF;
    public function __construct($HatCV, $pjZeY, $vp0Uq, $ctCWX, $F3aJr, $gBW_k)
    {
        goto UbYeM;
        tLCn5:
        $this->gdG3t = $F3aJr;
        goto ArfVA;
        Jx7yX:
        $this->cpROw = $pjZeY;
        goto nsMNp;
        nsMNp:
        $this->WmgCT = $vp0Uq;
        goto UwixO;
        cjJi_:
        $this->QbHVG = $HatCV;
        goto Jx7yX;
        UbYeM:
        $this->gq_yF = $gBW_k;
        goto cjJi_;
        UwixO:
        $this->WeXvt = $ctCWX;
        goto tLCn5;
        ArfVA:
    }
    public function resolvePath($HpL55, $yXj4Q = GrPXtp41lLmde::S3) : string
    {
        goto H_CfS;
        E63Az:
        return trim($this->WmgCT, '/') . '/' . $HpL55;
        goto tatUH;
        YJ41T:
        $HpL55 = $HpL55->getAttribute('filename');
        goto ku0lo;
        H_CfS:
        if (!$HpL55 instanceof Dup6KVtAFNCUq) {
            goto RwNTz;
        }
        goto YJ41T;
        d8v18:
        G6Td1:
        goto zZSFZ;
        lhQ1q:
        return trim($this->cpROw, '/') . '/' . $HpL55;
        goto H3OaS;
        tatUH:
        hHlBn:
        goto lhQ1q;
        EJae_:
        return config('upload.home') . '/' . $HpL55;
        goto Y_o1R;
        Y_o1R:
        wmkE_:
        goto aZ6js;
        aZ6js:
        if (!(!empty($this->WeXvt) && !empty($this->gdG3t))) {
            goto G6Td1;
        }
        goto rUJ3k;
        rUJ3k:
        return $this->mT8KpE7njP9($HpL55);
        goto d8v18;
        yrNMq:
        if (!($yXj4Q === GrPXtp41lLmde::LOCAL)) {
            goto wmkE_;
        }
        goto EJae_;
        ku0lo:
        RwNTz:
        goto yrNMq;
        zZSFZ:
        if (!$this->QbHVG) {
            goto hHlBn;
        }
        goto E63Az;
        H3OaS:
    }
    public function resolveThumbnail(Dup6KVtAFNCUq $HpL55) : string
    {
        goto iM_dJ;
        kAtlb:
        w33kY:
        goto qNsXQ;
        n_VyP:
        return $this->resolvePath($HpL55, $HpL55->getAttribute('driver'));
        goto kAtlb;
        yqBya:
        vF9mE:
        goto aDgIz;
        aDgIz:
        if (!$HpL55->getAttribute('thumbnail_id')) {
            goto eMnb5;
        }
        goto BVv_S;
        fljWb:
        return $this->url($IlGiN, $HpL55->getAttribute('driver'));
        goto yqBya;
        iM_dJ:
        $IlGiN = $HpL55->getAttribute('thumbnail');
        goto EAN9J;
        KGdJe:
        if (!$OuCmK) {
            goto soS0e;
        }
        goto s9d1f;
        fwdHz:
        if (!$HpL55 instanceof McTg5Yp6FKC6z) {
            goto w33kY;
        }
        goto n_VyP;
        EAN9J:
        if (!$IlGiN) {
            goto vF9mE;
        }
        goto fljWb;
        qNsXQ:
        if (!$HpL55 instanceof XWqfTCKHy5X8X) {
            goto QvOiF;
        }
        goto G8vFM;
        BVv_S:
        $OuCmK = McTg5Yp6FKC6z::find($HpL55->getAttribute('thumbnail_id'));
        goto KGdJe;
        KxEzj:
        soS0e:
        goto rpDoR;
        s9d1f:
        return $this->resolvePath($OuCmK, $OuCmK->getAttribute('driver'));
        goto KxEzj;
        DIy6V:
        QvOiF:
        goto o4hTo;
        o4hTo:
        return '';
        goto pPP5c;
        rpDoR:
        eMnb5:
        goto fwdHz;
        G8vFM:
        return asset('/img/pdf-preview.svg');
        goto DIy6V;
        pPP5c:
    }
    private function url($sEueW, $yXj4Q)
    {
        goto HP6GY;
        PvU6i:
        return config('upload.home') . '/' . $sEueW;
        goto zgWZL;
        zgWZL:
        gQP_I:
        goto HnN3i;
        HnN3i:
        return $this->resolvePath($sEueW);
        goto O_Pj8;
        HP6GY:
        if (!($yXj4Q == GrPXtp41lLmde::LOCAL)) {
            goto gQP_I;
        }
        goto PvU6i;
        O_Pj8:
    }
    private function mT8KpE7njP9($sEueW)
    {
        goto Gj2Q3;
        FPS0v:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto k5S_Z;
        k5S_Z:
        KvV3e:
        goto ftHWP;
        c9U_8:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto FiCT4;
        Gj2Q3:
        if (!(strpos($sEueW, 'https://') === 0)) {
            goto KvV3e;
        }
        goto FPS0v;
        ftHWP:
        if (!(strpos($sEueW, 'm3u8') !== false)) {
            goto B6riN;
        }
        goto c9U_8;
        FiCT4:
        B6riN:
        goto A7gdT;
        wjmaf:
        return $C5Dv0->getSignedUrl($this->WmgCT . '/' . $sEueW, $hOaQI);
        goto LXj73;
        A7gdT:
        $hOaQI = now()->addMinutes(60)->timestamp;
        goto zM1Gl;
        zM1Gl:
        $C5Dv0 = new UrlSigner($this->WeXvt, $this->gq_yF->path($this->gdG3t));
        goto wjmaf;
        LXj73:
    }
    public function resolvePathForHlsVideo(CSQMvXC33KbbS $vtvs_, $w_8cE = false) : string
    {
        goto EEQIX;
        xjOSK:
        zTLcq:
        goto eXOS7;
        P2_QK:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto xjOSK;
        eXOS7:
        return $this->WmgCT . '/' . $vtvs_->getAttribute('hls_path');
        goto XO1Ga;
        EEQIX:
        if ($vtvs_->getAttribute('hls_path')) {
            goto zTLcq;
        }
        goto P2_QK;
        XO1Ga:
    }
    public function resolvePathForHlsVideos()
    {
        goto W0s8v;
        UzTY1:
        return [$srDr3, $hOaQI];
        goto cawif;
        B7CX2:
        $mnex9 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto F5obK;
        djXby:
        $UH6Pu = $this->WmgCT . '/v2/hls/';
        goto S9Uk8;
        W0s8v:
        $hOaQI = now()->addDays(3)->timestamp;
        goto djXby;
        S9Uk8:
        $CI3L7 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $UH6Pu), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $hOaQI]]]]]);
        goto B7CX2;
        F5obK:
        $srDr3 = $mnex9->getSignedCookie(['key_pair_id' => $this->WeXvt, 'private_key' => $this->gq_yF->path($this->gdG3t), 'policy' => $CI3L7]);
        goto UzTY1;
        cawif:
    }
}
