<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
final class JCjpIXXHThkPb
{
    private $ey_Bg;
    private $RZJPv;
    private $aB4Qh;
    public function __construct(string $F66z0, string $mEP13, Filesystem $Q0D24)
    {
        goto GVg23;
        wOgJH:
        $this->aB4Qh = $Q0D24;
        goto Xt8SI;
        DJmFK:
        $this->RZJPv = $mEP13;
        goto wOgJH;
        GVg23:
        $this->ey_Bg = $F66z0;
        goto DJmFK;
        Xt8SI:
    }
    public function moX1v8Dumgs(QfVdOZWAlX8Sl $sYOYc) : string
    {
        goto y_ede;
        zf0_y:
        return 's3://' . $this->ey_Bg . '/' . $sYOYc->getAttribute('filename');
        goto isrrA;
        bk9kN:
        return $this->aB4Qh->url($sYOYc->getAttribute('filename'));
        goto DhxXI;
        isrrA:
        HFR6x:
        goto bk9kN;
        y_ede:
        if (!(R278OrMF6HCNB::S3 == $sYOYc->getAttribute('driver'))) {
            goto HFR6x;
        }
        goto zf0_y;
        DhxXI:
    }
    public function mxn2CZYthC4(?string $CY2P6) : ?string
    {
        goto VXKb7;
        ig35L:
        Zms_U:
        goto kqrvQ;
        SzaHA:
        return null;
        goto PSVTT;
        aSp8S:
        return 's3://' . $this->ey_Bg . '/' . ltrim($XkdbN, '/');
        goto ig35L;
        VXKb7:
        if (!$CY2P6) {
            goto AiS4z;
        }
        goto VS9pj;
        kqrvQ:
        AiS4z:
        goto SzaHA;
        VS9pj:
        if (!eC7GZ($CY2P6, $this->ey_Bg)) {
            goto Zms_U;
        }
        goto fHL8b;
        fHL8b:
        $XkdbN = parse_url($CY2P6, PHP_URL_PATH);
        goto aSp8S;
        PSVTT:
    }
    public function myhpQsmTvHJ(string $XkdbN) : string
    {
        return 's3://' . $this->ey_Bg . '/' . $XkdbN;
    }
}
