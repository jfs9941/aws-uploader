<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
final class SqWT6oYd97hAj
{
    private $DK2hf;
    private $pGk5e;
    private $VFHFZ;
    public function __construct(string $TyFPC, string $zqsPw, Filesystem $dOL2I)
    {
        goto lHsB4;
        lHsB4:
        $this->DK2hf = $TyFPC;
        goto mz5Ce;
        BD687:
        $this->VFHFZ = $dOL2I;
        goto LwBEn;
        mz5Ce:
        $this->pGk5e = $zqsPw;
        goto BD687;
        LwBEn:
    }
    public function m6CfpYIk1n5(ZujQPL2bQTbeI $Rcq7S) : string
    {
        goto TsAFK;
        TsAFK:
        if (!(FW54oEnFetVYj::S3 == $Rcq7S->getAttribute('driver'))) {
            goto T2bzw;
        }
        goto Q8fRh;
        Kwes9:
        return $this->VFHFZ->url($Rcq7S->getAttribute('filename'));
        goto EVOxa;
        UklMU:
        T2bzw:
        goto Kwes9;
        Q8fRh:
        return 's3://' . $this->DK2hf . '/' . $Rcq7S->getAttribute('filename');
        goto UklMU;
        EVOxa:
    }
    public function m18T4KMvq19(?string $CSzte) : ?string
    {
        goto RFZiZ;
        nUtyr:
        $IJqE5 = parse_url($CSzte, PHP_URL_PATH);
        goto Oo6uy;
        i3fpy:
        qY_7r:
        goto qvqGc;
        RFZiZ:
        if (!$CSzte) {
            goto qY_7r;
        }
        goto ZzoqC;
        tJBPK:
        nBCM8:
        goto i3fpy;
        qvqGc:
        return null;
        goto zZGUf;
        ZzoqC:
        if (!KD1nQ($CSzte, $this->DK2hf)) {
            goto nBCM8;
        }
        goto nUtyr;
        Oo6uy:
        return 's3://' . $this->DK2hf . '/' . ltrim($IJqE5, '/');
        goto tJBPK;
        zZGUf:
    }
    public function m6XZqiSGZzc(string $IJqE5) : string
    {
        return 's3://' . $this->DK2hf . '/' . $IJqE5;
    }
}
