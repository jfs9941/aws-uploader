<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
final class M4zqWF6NkWe3n implements VideoPostHandleServiceInterface
{
    private $N3dRj;
    private $zTo0t;
    public function __construct(UploadServiceInterface $zdw61, Filesystem $Vi8xq)
    {
        $this->N3dRj = $zdw61;
        $this->zTo0t = $Vi8xq;
    }
    public function saveMetadata(string $S6xyJ, array $b679I)
    {
        goto csGj_;
        Z4xpb:
        $dMSDt['resolution'] = $b679I['resolution'];
        goto O3Keg;
        UKKOZ:
        vb4LX:
        goto a2UfJ;
        LT6q4:
        $dMSDt['fps'] = $b679I['fps'];
        goto vcQJ7;
        hM_tA:
        if (!$yZXjN->update($dMSDt)) {
            goto vb4LX;
        }
        goto T1chA;
        CR4W_:
        try {
            goto MY6ab;
            hnMk3:
            $dMSDt['thumbnail'] = $c2ORW['filename'];
            goto QdI9i;
            r5oYU:
            $dMSDt['thumbnail_id'] = $c2ORW['id'];
            goto hnMk3;
            MY6ab:
            $c2ORW = $this->N3dRj->storeSingleFile(new class($b679I['thumbnail']) implements SingleUploadInterface
            {
                private $PxcXo;
                public function __construct($VZzWw)
                {
                    $this->PxcXo = $VZzWw;
                }
                public function getFile()
                {
                    return $this->PxcXo;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto r5oYU;
            QdI9i:
        } catch (\Throwable $NvDiU) {
            Log::warning("Kt6NO3eUvdER6 thumbnail store failed: " . $NvDiU->getMessage());
        }
        goto gmMPi;
        gmMPi:
        bw4rB:
        goto ERrjG;
        ERrjG:
        if (!isset($b679I['duration'])) {
            goto FkLMB;
        }
        goto U6Ynb;
        CDwZq:
        $dMSDt = [];
        goto Shq5y;
        tYlWX:
        if (!isset($b679I['fps'])) {
            goto tUKD9;
        }
        goto LT6q4;
        T1chA:
        if (!(isset($b679I['change_status']) && $b679I['change_status'])) {
            goto cShW3;
        }
        goto XZCo2;
        NUaOb:
        throw new \Exception("Kt6NO3eUvdER6 metadata store failed for unknown reason ... " . $S6xyJ);
        goto KWF2i;
        GjkBi:
        cShW3:
        goto Mq5bH;
        csGj_:
        $yZXjN = Kt6NO3eUvdER6::findOrFail($S6xyJ);
        goto CDwZq;
        TGGVA:
        unset($dMSDt['thumbnail']);
        goto bktiL;
        O3Keg:
        bycGj:
        goto tYlWX;
        u6lDv:
        if (!isset($b679I['resolution'])) {
            goto bycGj;
        }
        goto Z4xpb;
        U6Ynb:
        $dMSDt['duration'] = $b679I['duration'];
        goto lbQHV;
        Shq5y:
        if (!isset($b679I['thumbnail'])) {
            goto bw4rB;
        }
        goto CR4W_;
        vcQJ7:
        tUKD9:
        goto nVtsP;
        XZCo2:
        $this->N3dRj->updateFile($yZXjN->getAttribute('id'), EUkqoDwU9Zcvh::PROCESSING);
        goto GjkBi;
        a2UfJ:
        Log::warning("Kt6NO3eUvdER6 metadata store failed for unknown reason ... " . $S6xyJ);
        goto NUaOb;
        lbQHV:
        FkLMB:
        goto u6lDv;
        bktiL:
        hunxB:
        goto hM_tA;
        nVtsP:
        if (!$yZXjN->YLj7w) {
            goto hunxB;
        }
        goto TGGVA;
        Mq5bH:
        return $yZXjN->getView();
        goto UKKOZ;
        KWF2i:
    }
    public function createThumbnail(string $P0cHT) : void
    {
        goto T2phW;
        Rq3ue:
        TdEg6:
        goto QekVG;
        T2phW:
        Log::info("Use Lambda to generate thumbnail for video: " . $P0cHT);
        goto SJXt_;
        ZfwUU:
        try {
            goto ABBIL;
            ABBIL:
            $nRPpu = $IheD_->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto kmMBJ;
            kmMBJ:
            $SCsoF = $nRPpu->get('QueueUrl');
            goto tBwGd;
            tBwGd:
            $IheD_->sendMessage(['QueueUrl' => $SCsoF, 'MessageBody' => json_encode(['file_path' => $yZXjN->getLocation()])]);
            goto ZA6w9;
            ZA6w9:
        } catch (\Throwable $WTk3U) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$WTk3U->getMessage()}");
        }
        goto Rq3ue;
        MsQ1j:
        if (!(!$this->zTo0t->directoryExists($sZx9U) && empty($yZXjN->m44JVj32w1m()))) {
            goto TdEg6;
        }
        goto GY2mq;
        C9E2S:
        $sZx9U = "v2/hls/thumbnails/{$P0cHT}/";
        goto MsQ1j;
        GY2mq:
        $IheD_ = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto ZfwUU;
        SJXt_:
        $yZXjN = Kt6NO3eUvdER6::findOrFail($P0cHT);
        goto C9E2S;
        QekVG:
    }
    public function mNGhuxc3OV5(string $P0cHT) : void
    {
        goto Y1C5F;
        mPBBv:
        $yZXjN->update(['generated_previews' => $sZx9U]);
        goto Lxujz;
        baRnb:
        throw new \Exception("Message back with success data but not found thumbnail " . $P0cHT);
        goto JkZpA;
        gAW4Q:
        throw new \Exception("Message back with success data but not found thumbnail files " . $P0cHT);
        goto DAv6P;
        DAv6P:
        xY_k6:
        goto mPBBv;
        QAQsi:
        $sZx9U = "v2/hls/thumbnails/{$P0cHT}/";
        goto Z7XTn;
        QcIQb:
        if (!(count($W6w1N) === 0)) {
            goto xY_k6;
        }
        goto ydR9N;
        ydR9N:
        Log::error("Message back with success data but not found thumbnail files " . $P0cHT);
        goto gAW4Q;
        Z7XTn:
        if ($this->zTo0t->directoryExists($sZx9U)) {
            goto hPoTT;
        }
        goto hrWLT;
        Y1C5F:
        $yZXjN = Kt6NO3eUvdER6::findOrFail($P0cHT);
        goto QAQsi;
        hrWLT:
        Log::error("Message back with success data but not found thumbnail " . $P0cHT);
        goto baRnb;
        w8snT:
        $W6w1N = $this->zTo0t->files($sZx9U);
        goto QcIQb;
        JkZpA:
        hPoTT:
        goto w8snT;
        Lxujz:
    }
    public function getThumbnails(string $P0cHT) : array
    {
        $yZXjN = Kt6NO3eUvdER6::findOrFail($P0cHT);
        return $yZXjN->getThumbnails();
    }
}
