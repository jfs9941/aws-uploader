<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Core\Zvx9VGBGZQ0lD;
use Jfs\Uploader\Core\ZOwA486ueqbmD;
use Jfs\Uploader\Enum\EPmxqTVp5luXc;
use Jfs\Uploader\Exception\KVgPdowMikNnK;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Jfs\Uploader\Exception\WgiszEiQkEJPG;
final class W2KgpvTX4ze05 implements UploadServiceInterface
{
    private $C7soC;
    private $Hf14x;
    private $tYBKb;
    private $XvCcg;
    public function __construct(RLP5XS0nrqtBl $BMjhW, Filesystem $p1fCH, Filesystem $zCXkD, string $Fi5IU)
    {
        goto R4wOo;
        R4wOo:
        $this->C7soC = $BMjhW;
        goto fsQCx;
        fsQCx:
        $this->Hf14x = $p1fCH;
        goto nnvWZ;
        nnvWZ:
        $this->tYBKb = $zCXkD;
        goto QNraT;
        QNraT:
        $this->XvCcg = $Fi5IU;
        goto S3Jp1;
        S3Jp1:
    }
    public function storeSingleFile(SingleUploadInterface $G4bXu) : array
    {
        goto T9pTR;
        geftT:
        return $I2SbP->getView();
        goto CWbwr;
        T9pTR:
        $I2SbP = $this->C7soC->mqS9kASZOme($G4bXu);
        goto YrMqn;
        AJZh0:
        if (false !== $Sblyk && $I2SbP instanceof VH6naaofz5IuZ) {
            goto s_9e0;
        }
        goto j8Z8l;
        Mmomq:
        qmluE:
        goto geftT;
        QLocG:
        s_9e0:
        goto tO1v5;
        YrMqn:
        $Sblyk = $this->tYBKb->putFileAs(dirname($I2SbP->getLocation()), $G4bXu->getFile(), $I2SbP->getFilename() . '.' . $I2SbP->getExtension(), ['visibility' => 'public']);
        goto AJZh0;
        j8Z8l:
        throw new \LogicException('File upload failed, check permissions');
        goto efx2l;
        tO1v5:
        $I2SbP->mY8gUThQFjU(EPmxqTVp5luXc::UPLOADED);
        goto Mmomq;
        efx2l:
        goto qmluE;
        goto QLocG;
        CWbwr:
    }
    public function storePreSignedFile(array $kTs4h)
    {
        goto GdLnI;
        GdLnI:
        $I2SbP = $this->C7soC->mqS9kASZOme($kTs4h);
        goto VO3Oe;
        SEArG:
        $X40HK->mq8iABfp1UB($kTs4h['mime'], $kTs4h['file_size'], $kTs4h['chunk_size'], $kTs4h['checksums'], $kTs4h['user_id'], $kTs4h['driver']);
        goto ejdzE;
        VO3Oe:
        $X40HK = ZOwA486ueqbmD::mxZLeTghw2H($I2SbP, $this->Hf14x, $this->tYBKb, $this->XvCcg, true);
        goto SEArG;
        ejdzE:
        $X40HK->maJTK30GZlo();
        goto HK5n7;
        HK5n7:
        return ['filename' => $X40HK->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $X40HK->mJ33AkKTqbd()];
        goto hjXuI;
        hjXuI:
    }
    public function updatePreSignedFile(string $GLW0Y, int $hh8Nu)
    {
        goto oQDPd;
        O0_jW:
        j5FlM:
        goto KWQlR;
        oQDPd:
        $X40HK = ZOwA486ueqbmD::mAtEUX947sU($GLW0Y, $this->Hf14x, $this->tYBKb, $this->XvCcg);
        goto F51ue;
        F51ue:
        switch ($hh8Nu) {
            case EPmxqTVp5luXc::UPLOADED:
                $X40HK->mxnfqLi70gc();
                goto j5FlM;
            case EPmxqTVp5luXc::PROCESSING:
                $X40HK->mrbL8K4c0Iy();
                goto j5FlM;
            case EPmxqTVp5luXc::FINISHED:
                $X40HK->m6RMo1yoqSN();
                goto j5FlM;
            case EPmxqTVp5luXc::ABORTED:
                $X40HK->mk8zM424oMJ();
                goto j5FlM;
        }
        goto riZaa;
        riZaa:
        K6Jnj:
        goto O0_jW;
        KWQlR:
    }
    public function completePreSignedFile(string $GLW0Y, array $bLIUr)
    {
        goto H42tf;
        ufE84:
        $X40HK->mxnfqLi70gc();
        goto CG7IY;
        N4t79:
        $X40HK->mFmRtrLmgsB()->mwcq8pQL0f2($bLIUr);
        goto ufE84;
        CG7IY:
        return ['path' => $X40HK->getFile()->getView()['path'], 'thumbnail' => $X40HK->getFile()->LBxSS, 'id' => $GLW0Y];
        goto fX0C7;
        H42tf:
        $X40HK = ZOwA486ueqbmD::mAtEUX947sU($GLW0Y, $this->Hf14x, $this->tYBKb, $this->XvCcg);
        goto N4t79;
        fX0C7:
    }
    public function updateFile(string $GLW0Y, int $hh8Nu) : Zvx9VGBGZQ0lD
    {
        goto dR32x;
        G2svS:
        return $I2SbP;
        goto hUj6p;
        dR32x:
        $I2SbP = $this->C7soC->mX3gJ2vlhl7($GLW0Y);
        goto eS2wA;
        eS2wA:
        $I2SbP->mY8gUThQFjU($hh8Nu);
        goto G2svS;
        hUj6p:
    }
}
