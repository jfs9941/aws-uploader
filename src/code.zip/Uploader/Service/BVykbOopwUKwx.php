<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Enum\FileDriver;
final class BVykbOopwUKwx
{
    private $tVqMs;
    private $t0nMK;
    private $SiK3b;
    public function __construct(string $FQWsT, string $YRBh9, Filesystem $eX8wo)
    {
        goto VJdXQ;
        p1w1v:
        $this->SiK3b = $eX8wo;
        goto rUCKa;
        VJdXQ:
        $this->tVqMs = $FQWsT;
        goto VcX9A;
        VcX9A:
        $this->t0nMK = $YRBh9;
        goto p1w1v;
        rUCKa:
    }
    public function mPD7CEbQWGG(TvpGfrAj9WMXE $jVT23) : string
    {
        goto PboVG;
        npzm3:
        caoL4:
        goto YLOyK;
        hiI0Z:
        return 's3://' . $this->tVqMs . '/' . $jVT23->getAttribute('filename');
        goto npzm3;
        YLOyK:
        return $this->SiK3b->url($jVT23->getAttribute('filename'));
        goto udwyv;
        PboVG:
        if (!(FileDriver::S3 == $jVT23->getAttribute('driver'))) {
            goto caoL4;
        }
        goto hiI0Z;
        udwyv:
    }
    public function mZtEu4MfD0R(?string $lKtRX) : ?string
    {
        goto bwAS1;
        oTvKv:
        return null;
        goto sqkqq;
        CNZBH:
        h3OXa:
        goto oTvKv;
        bwAS1:
        if (!$lKtRX) {
            goto h3OXa;
        }
        goto bGeWM;
        GMoeF:
        return 's3://' . $this->tVqMs . '/' . ltrim($fdqWg, '/');
        goto Itiwk;
        bGeWM:
        if (!oPqDX($lKtRX, $this->tVqMs)) {
            goto V0UPg;
        }
        goto mdczm;
        mdczm:
        $fdqWg = parse_url($lKtRX, PHP_URL_PATH);
        goto GMoeF;
        Itiwk:
        V0UPg:
        goto CNZBH;
        sqkqq:
    }
    public function mDJ5zUrqdk7(string $fdqWg) : string
    {
        return 's3://' . $this->tVqMs . '/' . $fdqWg;
    }
}
