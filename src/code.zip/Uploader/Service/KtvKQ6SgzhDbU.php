<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Illuminate\Contracts\Filesystem\Filesystem;
final class KtvKQ6SgzhDbU
{
    private $pHuSQ;
    private $CIt3l;
    private $zoOKU;
    public function __construct(string $h2Cp1, string $oHMnd, Filesystem $e3FbC)
    {
        goto LK8BK;
        g_om5:
        $this->zoOKU = $e3FbC;
        goto YQ0yh;
        LK8BK:
        $this->pHuSQ = $h2Cp1;
        goto iKOrJ;
        iKOrJ:
        $this->CIt3l = $oHMnd;
        goto g_om5;
        YQ0yh:
    }
    public function mMhyBpeCxED(GpdHFYchpZHPa $gR4Y3) : string
    {
        goto dttOK;
        yRhnE:
        return $this->zoOKU->url($gR4Y3->getAttribute('filename'));
        goto KYMqS;
        dNyyR:
        TtPXX:
        goto yRhnE;
        dttOK:
        if (!(McZXbZmlQ53or::S3 == $gR4Y3->getAttribute('driver'))) {
            goto TtPXX;
        }
        goto wzn9e;
        wzn9e:
        return 's3://' . $this->pHuSQ . '/' . $gR4Y3->getAttribute('filename');
        goto dNyyR;
        KYMqS:
    }
    public function m8fpXmJUzSQ(?string $t1Sgh) : ?string
    {
        goto TOnma;
        ZOd6z:
        vJrgZ:
        goto Yim1t;
        TOnma:
        if (!$t1Sgh) {
            goto vJrgZ;
        }
        goto eYGVE;
        jX3SL:
        return 's3://' . $this->pHuSQ . '/' . ltrim($d1QWa, '/');
        goto sJlf0;
        vKsEQ:
        $d1QWa = parse_url($t1Sgh, PHP_URL_PATH);
        goto jX3SL;
        sJlf0:
        s2bAQ:
        goto ZOd6z;
        Yim1t:
        return null;
        goto uVt7n;
        eYGVE:
        if (!YAIqz($t1Sgh, $this->pHuSQ)) {
            goto s2bAQ;
        }
        goto vKsEQ;
        uVt7n:
    }
    public function mBxHLXgL7Y0(string $d1QWa) : string
    {
        return 's3://' . $this->pHuSQ . '/' . $d1QWa;
    }
}
