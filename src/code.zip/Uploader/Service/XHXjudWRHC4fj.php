<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\XuIaPR4PMryqL;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Core\AvQy1eDjm0AkP;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
final class XHXjudWRHC4fj implements XuIaPR4PMryqL
{
    private $GRWnN;
    private $KLqz2;
    public $oZOCN;
    private $xqrp0;
    private $Ecam6;
    private $SPj0U;
    public function __construct($SszIp, $bspwu, $OyS_6, $zqwkn, $T109_, $KUQsT)
    {
        goto YCCI0;
        YCCI0:
        $this->SPj0U = $KUQsT;
        goto OF7Qb;
        nwb4a:
        $this->KLqz2 = $bspwu;
        goto kzBjk;
        d1kDU:
        $this->Ecam6 = $T109_;
        goto mg7qw;
        OF7Qb:
        $this->GRWnN = $SszIp;
        goto nwb4a;
        mLtL4:
        $this->xqrp0 = $zqwkn;
        goto d1kDU;
        kzBjk:
        $this->oZOCN = $OyS_6;
        goto mLtL4;
        mg7qw:
    }
    public function resolvePath($LiWvx, $NjcWd = Tq4KHV0o6oTIo::S3) : string
    {
        goto rrbHX;
        Dhz6h:
        passM:
        goto CA35m;
        dx71g:
        wRgjr:
        goto Fsky2;
        rrbHX:
        if (!$LiWvx instanceof Fd8NTWwq2cQOc) {
            goto o3Wl2;
        }
        goto nm_9d;
        SIK1m:
        return trim($this->oZOCN, '/') . '/' . $LiWvx;
        goto dx71g;
        CA35m:
        if (!$this->GRWnN) {
            goto wRgjr;
        }
        goto SIK1m;
        lSkLU:
        uRRYk:
        goto HXnQ6;
        Fsky2:
        return trim($this->KLqz2, '/') . '/' . $LiWvx;
        goto RseuM;
        HXnQ6:
        if (!(!empty($this->xqrp0) && !empty($this->Ecam6))) {
            goto passM;
        }
        goto IF1Da;
        dfZMb:
        o3Wl2:
        goto cXJCE;
        IF1Da:
        return $this->mWnmlQ9P8xI($LiWvx);
        goto Dhz6h;
        cXJCE:
        if (!($NjcWd === Tq4KHV0o6oTIo::LOCAL)) {
            goto uRRYk;
        }
        goto qZutQ;
        nm_9d:
        $LiWvx = $LiWvx->getAttribute('filename');
        goto dfZMb;
        qZutQ:
        return config('upload.home') . '/' . $LiWvx;
        goto lSkLU;
        RseuM:
    }
    public function resolveThumbnail(Fd8NTWwq2cQOc $LiWvx) : string
    {
        goto QSttG;
        qHBXK:
        if (!$LiWvx instanceof AvQy1eDjm0AkP) {
            goto Jl4WU;
        }
        goto B0N0t;
        Z6r2H:
        tsrD1:
        goto SqXkg;
        vtILK:
        ICcTw:
        goto VUDeB;
        MtAN_:
        return $this->url($T07ak, $LiWvx->getAttribute('driver'));
        goto vtILK;
        l8UKb:
        qdJKr:
        goto Z6r2H;
        O1h4M:
        return $this->resolvePath($LiWvx, $LiWvx->getAttribute('driver'));
        goto LJ0SH;
        LJ0SH:
        X2Bo3:
        goto qHBXK;
        B0N0t:
        return asset('/img/pdf-preview.svg');
        goto tgPTe;
        h_HBB:
        if (!$GZc4j) {
            goto qdJKr;
        }
        goto mWzmi;
        KRUM1:
        if (!$T07ak) {
            goto ICcTw;
        }
        goto MtAN_;
        mWzmi:
        return $this->resolvePath($GZc4j, $GZc4j->getAttribute('driver'));
        goto l8UKb;
        a3wE6:
        $GZc4j = XqAJHKYeaW2YU::find($LiWvx->getAttribute('thumbnail_id'));
        goto h_HBB;
        VUDeB:
        if (!$LiWvx->getAttribute('thumbnail_id')) {
            goto tsrD1;
        }
        goto a3wE6;
        QSttG:
        $T07ak = $LiWvx->getAttribute('thumbnail');
        goto KRUM1;
        tgPTe:
        Jl4WU:
        goto LtSfS;
        LtSfS:
        return '';
        goto u02k6;
        SqXkg:
        if (!$LiWvx instanceof XqAJHKYeaW2YU) {
            goto X2Bo3;
        }
        goto O1h4M;
        u02k6:
    }
    private function url($FlxOy, $NjcWd)
    {
        goto MpK72;
        OgkPb:
        UEFpQ:
        goto XJMXQ;
        XJMXQ:
        return $this->resolvePath($FlxOy);
        goto Ba23s;
        MpK72:
        if (!($NjcWd == Tq4KHV0o6oTIo::LOCAL)) {
            goto UEFpQ;
        }
        goto FtszJ;
        FtszJ:
        return config('upload.home') . '/' . $FlxOy;
        goto OgkPb;
        Ba23s:
    }
    private function mWnmlQ9P8xI($FlxOy)
    {
        goto OrYwf;
        iCIT5:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto cKM0E;
        X37CM:
        return $DwyUx->getSignedUrl($this->oZOCN . '/' . $FlxOy, $pDJCT);
        goto Wz4LM;
        cKM0E:
        B_7XJ:
        goto T8yUy;
        uI_JR:
        $DwyUx = new UrlSigner($this->xqrp0, $this->SPj0U->path($this->Ecam6));
        goto X37CM;
        Wr36E:
        if (!(strpos($FlxOy, 'm3u8') !== false)) {
            goto B_7XJ;
        }
        goto iCIT5;
        T8yUy:
        $pDJCT = now()->addMinutes(60)->timestamp;
        goto uI_JR;
        huZc5:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto Pdlsy;
        Pdlsy:
        alpnp:
        goto Wr36E;
        OrYwf:
        if (!(strpos($FlxOy, 'https://') === 0)) {
            goto alpnp;
        }
        goto huZc5;
        Wz4LM:
    }
    public function resolvePathForHlsVideo(JbxOPjx4A3DUY $Uas5p, $S_18w = false) : string
    {
        goto q1aZT;
        ES4fQ:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto QGGAy;
        QGGAy:
        nR3DX:
        goto jEkEb;
        jEkEb:
        return $this->oZOCN . '/' . $Uas5p->getAttribute('hls_path');
        goto sYVw1;
        q1aZT:
        if ($Uas5p->getAttribute('hls_path')) {
            goto nR3DX;
        }
        goto ES4fQ;
        sYVw1:
    }
    public function resolvePathForHlsVideos()
    {
        goto rCyzm;
        vfQ2x:
        $piFd6 = $this->oZOCN . '/v2/hls/';
        goto H85Yy;
        kRiGZ:
        $wIdGd = $qxcbo->getSignedCookie(['key_pair_id' => $this->xqrp0, 'private_key' => $this->SPj0U->path($this->Ecam6), 'policy' => $THbqm]);
        goto nwoM2;
        jvLs4:
        $qxcbo = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto kRiGZ;
        H85Yy:
        $THbqm = json_encode(['Statement' => [['Resource' => sprintf('%s*', $piFd6), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $pDJCT]]]]]);
        goto jvLs4;
        rCyzm:
        $pDJCT = now()->addDays(3)->timestamp;
        goto vfQ2x;
        nwoM2:
        return [$wIdGd, $pDJCT];
        goto acE1P;
        acE1P:
    }
}
