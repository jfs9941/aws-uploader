<?php

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileStatus;

final class VideoPostHandleService implements VideoPostHandleServiceInterface
{
    /**
     * @var UploadServiceInterface
     */
    private $uploadService;
    private $s3;
    public function __construct(UploadServiceInterface $uploadService, Filesystem $s3)
    {
        $this->uploadService = $uploadService;
        $this->s3 = $s3;
    }

    public function saveMetadata(string $id, array $metadata)
    {
        $video = Video::findOrFail($id);
        $savedMetadata = [];
        if (isset($metadata['thumbnail'])) {
            try {
                $thumbnail = $this->uploadService->storeSingleFile(new class($metadata['thumbnail']) implements SingleUploadInterface {
                    private $file;
                    public function __construct($file)
                    {
                        $this->file = $file;
                    }

                    public function getFile()
                    {
                        return $this->file;
                    }

                    public function options()
                    {
                        return [
                            'thumbnail' => false,
                            'watermark' => false,
                            's3' => true,
                            'compress' => true
                        ];
                    }
                });

                $savedMetadata['thumbnail_id'] = $thumbnail['id'];
                $savedMetadata['thumbnail'] = $thumbnail['path'];
            } catch (\Throwable $exception) {
                Log::warning("Video thumbnail store failed: " . $exception->getMessage());
            }
        }

        if (isset($metadata['duration'])) {
            $savedMetadata['duration'] = $metadata['duration'];
        }
        if (isset($metadata['resolution'])) {
            $savedMetadata['resolution'] = $metadata['resolution'];
        }
        if (isset($metadata['fps'])) {
            $savedMetadata['fps'] = $metadata['fps'];
        }

        if ($video->update($savedMetadata)) {
            if (isset($metadata['change_status']) && $metadata['change_status']) {
                $this->uploadService->updateFile($video->getAttribute('id'), FileStatus::PROCESSING);
            }

            return $video;
        }
        Log::warning("Video metadata store failed for unknown reason ... " . $id);
        throw new \Exception("Video metadata store failed for unknown reason ... " . $id);
    }

    public function createThumbnail(string $uuid): void
    {
       Log::info("Use Lambda to generate thumbnail for video: " . $uuid);
       $video = Video::findOrFail($uuid);
       $thumbnailPath = "v2/hls/thumbnails/$uuid/";
       if (!$this->s3->directoryExists($thumbnailPath) && empty($video->getPreviewThumbnail())) {
            //call to AWS Lambda to generate thumbnails
           $sqsClient = new SqsClient([
               'region'      => config('filesystems.disks.s3.region'),
               'version'     => 'latest',
               'credentials' => [
                   'key'    => config('upload.lambda_key'),
                   'secret' => config('upload.lambda_secret'),
               ],
           ]);

           try {
               $queueUrlResult = $sqsClient->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
               $queueUrl = $queueUrlResult->get('QueueUrl');
               $sqsClient->sendMessage([
                   'QueueUrl' => $queueUrl,
                   'MessageBody' => json_encode([
                       'file_path' => $video->getLocation()
                   ]),
               ]);
           } catch (\Throwable $e) {
               \Log::error("Failed to invoke Lambda function for thumbnail generation: {$e->getMessage()}");
           }
       }
    }

    public function storeThumbnail(string $uuid): void
    {
        $video = Video::findOrFail($uuid);
        $thumbnailPath = "v2/hls/thumbnails/$uuid/";
        if (!$this->s3->directoryExists($thumbnailPath)) {
            Log::error("Message back with success data but not found thumbnail " . $uuid);
            throw new \Exception("Message back with success data but not found thumbnail " . $uuid);
        }

        $files = $this->s3->files($thumbnailPath);
        if (count($files) === 0) {
            Log::error("Message back with success data but not found thumbnail files " . $uuid);
            throw new \Exception("Message back with success data but not found thumbnail files " . $uuid);
        }

        $video->update([
            'generated_previews' => $thumbnailPath
        ]);
    }

    public function getThumbnails(string $uuid): array
    {
        $video = Video::findOrFail($uuid);

        return $video->getThumbnails();
    }
}
