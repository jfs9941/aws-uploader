<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Core\Observer\DDw1EM7mX7hwX;
use Jfs\Uploader\Core\Observer\ZbCruJtdtlRqO;
use Jfs\Uploader\Core\QzHAZxZkrX5gT;
use Jfs\Uploader\Core\XfZUz9XnPzPJ1;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Exception\W9MQd1eHMaESp;
use Jfs\Uploader\Service\FileResolver\ZZ7ar02ykwlAz;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class VQRb8yFeCwEOC
{
    private $qmCLE;
    private $pXh9P;
    private $QxLu3;
    public function __construct($uAPx4, $TWZho, $bjIIR)
    {
        goto XLAY3;
        MEC5o:
        $this->QxLu3 = $bjIIR;
        goto IqA_h;
        hCt7a:
        $this->pXh9P = $TWZho;
        goto MEC5o;
        XLAY3:
        $this->qmCLE = $uAPx4;
        goto hCt7a;
        IqA_h:
    }
    public function mFTsQyvMslN($K3cqG)
    {
        goto BmvKm;
        BmvKm:
        if (!$K3cqG instanceof SingleUploadInterface) {
            goto ZkkJ2;
        }
        goto JLghN;
        HkHTF:
        return $this->md0tLSiHjpo($K3cqG['file_extension'], 's3' === $K3cqG['driver'] ? YOaiWCgFM7tRK::S3 : YOaiWCgFM7tRK::LOCAL);
        goto P2pZL;
        ZC0tC:
        return $this->md0tLSiHjpo($VjPDC->extension(), YOaiWCgFM7tRK::S3, null, $K3cqG->options());
        goto Hv1Mp;
        JLghN:
        $VjPDC = $K3cqG->getFile();
        goto ZC0tC;
        Hv1Mp:
        ZkkJ2:
        goto HkHTF;
        P2pZL:
    }
    public function mVldyNQ2YMB(string $qMhfW)
    {
        goto RhV6s;
        iLYYM:
        $ZPsYd->exists = true;
        goto x9OR2;
        x9OR2:
        $ZPsYd->setRawAttributes($uC0lG->getAttributes());
        goto iP2MZ;
        iP2MZ:
        return $ZPsYd;
        goto ilni2;
        UM50d:
        $ZPsYd = $this->md0tLSiHjpo($uC0lG->getAttribute('type'), $uC0lG->getAttribute('driver'), $uC0lG->getAttribute('id'));
        goto iLYYM;
        RhV6s:
        $uC0lG = config('upload.attachment_model')::findOrFail($qMhfW);
        goto UM50d;
        ilni2:
    }
    public function mdDQ8kqbTiD(string $e4WnR) : ZE3znzkASutzh
    {
        goto jKz0z;
        GEg7X:
        $iVtF2 = XfZUz9XnPzPJ1::mki1v3aMtnh($bsvnL);
        goto v3g0a;
        jWiDX:
        jscJk:
        goto E6fnT;
        jKz0z:
        $LVSUx = $this->pXh9P->get($e4WnR);
        goto PJEml;
        E6fnT:
        $bsvnL = json_decode($LVSUx, true);
        goto VuPMv;
        gfMP3:
        TYnWg:
        goto OLOdu;
        vcyGn:
        $LVSUx = $this->QxLu3->get($e4WnR);
        goto jWiDX;
        PJEml:
        if ($LVSUx) {
            goto jscJk;
        }
        goto vcyGn;
        OLOdu:
        throw new Jcm0L35ZiDWQ6('metadata file not found');
        goto X35qL;
        VuPMv:
        if (!$bsvnL) {
            goto TYnWg;
        }
        goto GEg7X;
        v3g0a:
        return $this->md0tLSiHjpo($iVtF2->C3SKe, $iVtF2->mO1plATSwB3(), $iVtF2->filename);
        goto gfMP3;
        X35qL:
    }
    private function md0tLSiHjpo(string $CA538, $lbF7_, ?string $qMhfW = null, array $eoTgM = [])
    {
        goto GWquu;
        qctmY:
        foreach ($this->qmCLE as $uLczT) {
            goto nymxs;
            nymxs:
            if (!$uLczT->mOmk7130QrW($djA2z)) {
                goto tCOL3;
            }
            goto CNldo;
            CNldo:
            return $djA2z->initLocation($uLczT->mmDXpZuuXxW($djA2z));
            goto wVeAU;
            wVeAU:
            tCOL3:
            goto Yv6pj;
            Yv6pj:
            Df_cp:
            goto eIXZK;
            eIXZK:
        }
        goto S5nVQ;
        onJeI:
        switch ($CA538) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $djA2z = WUuz09CA4woAL::createFromScratch($qMhfW, $CA538);
                goto OoYNx;
            case 'mp4':
            case 'mov':
                $djA2z = NYx4mhlHSMgHF::createFromScratch($qMhfW, $CA538);
                goto OoYNx;
            case 'pdf':
                $djA2z = QzHAZxZkrX5gT::createFromScratch($qMhfW, $CA538);
                goto OoYNx;
            default:
                throw new W9MQd1eHMaESp("not support file type {$CA538}");
        }
        goto tbobW;
        tuM80:
        $djA2z->m1QMTCQtDK5(new DDw1EM7mX7hwX($djA2z));
        goto VceDl;
        tbobW:
        Fzr1g:
        goto Wdcl0;
        q3zpG:
        throw new W9MQd1eHMaESp("not support file type {$CA538}");
        goto WCIN9;
        S5nVQ:
        L5AXk:
        goto q3zpG;
        Wdcl0:
        OoYNx:
        goto uKWCq;
        uKWCq:
        $djA2z = $djA2z->mmo2ywJzL9K($lbF7_);
        goto tuM80;
        GWquu:
        $qMhfW = $qMhfW ?? Uuid::uuid4()->getHex()->toString();
        goto onJeI;
        VceDl:
        $djA2z->m1QMTCQtDK5(new ZbCruJtdtlRqO($djA2z, $this->QxLu3, $eoTgM));
        goto qctmY;
        WCIN9:
    }
}
