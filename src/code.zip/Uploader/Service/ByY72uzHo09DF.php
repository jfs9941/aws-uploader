<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
final class ByY72uzHo09DF implements VideoPostHandleServiceInterface
{
    private $RzZvU;
    private $RaPnW;
    public function __construct(UploadServiceInterface $HgQGs, Filesystem $hTkyv)
    {
        $this->RzZvU = $HgQGs;
        $this->RaPnW = $hTkyv;
    }
    public function saveMetadata(string $UcmDx, array $JFwxi)
    {
        goto P6OTq;
        QJERx:
        $x06FK['fps'] = $JFwxi['fps'];
        goto ORWOo;
        s3kSb:
        y2bfj:
        goto SIKUB;
        j17__:
        if (!isset($JFwxi['duration'])) {
            goto NAwIS;
        }
        goto ojN_0;
        ojN_0:
        $x06FK['duration'] = $JFwxi['duration'];
        goto Svw42;
        kOLTG:
        if (!isset($JFwxi['thumbnail'])) {
            goto h0JrV;
        }
        goto k6mZu;
        ru7H5:
        $x06FK['resolution'] = $JFwxi['resolution'];
        goto KeHCA;
        ThbjQ:
        if (!isset($JFwxi['resolution'])) {
            goto vvHy9;
        }
        goto ru7H5;
        e2daV:
        if (!isset($JFwxi['fps'])) {
            goto qAzan;
        }
        goto QJERx;
        Hjumd:
        if (!(isset($JFwxi['change_status']) && $JFwxi['change_status'])) {
            goto y2bfj;
        }
        goto fYNa2;
        aQ7Tv:
        if (!$KuX31->update($x06FK)) {
            goto lI7S5;
        }
        goto Hjumd;
        Ucejl:
        $x06FK = [];
        goto kOLTG;
        ldXhR:
        h0JrV:
        goto j17__;
        Svw42:
        NAwIS:
        goto ThbjQ;
        k6mZu:
        try {
            goto RD4hB;
            QYmRo:
            $x06FK['thumbnail_id'] = $FFU0R['id'];
            goto pv6HX;
            RD4hB:
            $FFU0R = $this->RzZvU->storeSingleFile(new class($JFwxi['thumbnail']) implements SingleUploadInterface
            {
                private $a2FAI;
                public function __construct($QxvEM)
                {
                    $this->a2FAI = $QxvEM;
                }
                public function getFile()
                {
                    return $this->a2FAI;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto QYmRo;
            pv6HX:
            $x06FK['thumbnail'] = $FFU0R['filename'];
            goto G90BC;
            G90BC:
        } catch (\Throwable $sdtX4) {
            Log::warning("QdnSnf08v9RV7 thumbnail store failed: " . $sdtX4->getMessage());
        }
        goto ldXhR;
        KeHCA:
        vvHy9:
        goto e2daV;
        ORWOo:
        qAzan:
        goto aQ7Tv;
        HJsPd:
        throw new \Exception("QdnSnf08v9RV7 metadata store failed for unknown reason ... " . $UcmDx);
        goto LNc_F;
        SIKUB:
        return $KuX31->getView();
        goto mOnBa;
        mOnBa:
        lI7S5:
        goto b8Uot;
        fYNa2:
        $this->RzZvU->updateFile($KuX31->getAttribute('id'), U8OFutptQGm3S::PROCESSING);
        goto s3kSb;
        P6OTq:
        $KuX31 = QdnSnf08v9RV7::findOrFail($UcmDx);
        goto Ucejl;
        b8Uot:
        Log::warning("QdnSnf08v9RV7 metadata store failed for unknown reason ... " . $UcmDx);
        goto HJsPd;
        LNc_F:
    }
    public function createThumbnail(string $Ls0bH) : void
    {
        goto a61c3;
        a61c3:
        Log::info("Use Lambda to generate thumbnail for video: " . $Ls0bH);
        goto RVMYQ;
        FGnhk:
        try {
            goto vEMaC;
            lGCSm:
            $YGJ3U = $XD47Z->get('QueueUrl');
            goto G0R2T;
            G0R2T:
            $uoNlT->sendMessage(['QueueUrl' => $YGJ3U, 'MessageBody' => json_encode(['file_path' => $KuX31->getLocation()])]);
            goto x_JS0;
            vEMaC:
            $XD47Z = $uoNlT->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto lGCSm;
            x_JS0:
        } catch (\Throwable $XCxKc) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$XCxKc->getMessage()}");
        }
        goto nk0Y0;
        RVMYQ:
        $KuX31 = QdnSnf08v9RV7::findOrFail($Ls0bH);
        goto FqyRH;
        egmmf:
        if (!(!$this->RaPnW->directoryExists($fYb1T) && empty($KuX31->m9BigqkeLJt()))) {
            goto uKIZ8;
        }
        goto pF5OJ;
        pF5OJ:
        $uoNlT = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto FGnhk;
        FqyRH:
        $fYb1T = "v2/hls/thumbnails/{$Ls0bH}/";
        goto egmmf;
        nk0Y0:
        uKIZ8:
        goto UPc5G;
        UPc5G:
    }
    public function m1XMeb4wcux(string $Ls0bH) : void
    {
        goto LvcvD;
        LYZTT:
        E3x7v:
        goto PIR44;
        VNBmE:
        Log::error("Message back with success data but not found thumbnail " . $Ls0bH);
        goto o1yUB;
        xDIwK:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Ls0bH);
        goto gcbX1;
        gcbX1:
        yexg_:
        goto WbDlM;
        i2Rnf:
        Log::error("Message back with success data but not found thumbnail files " . $Ls0bH);
        goto xDIwK;
        wXqEv:
        $fYb1T = "v2/hls/thumbnails/{$Ls0bH}/";
        goto vMMVQ;
        WbDlM:
        $KuX31->update(['generated_previews' => $fYb1T]);
        goto etL03;
        dmnId:
        if (!(count($YNsmS) === 0)) {
            goto yexg_;
        }
        goto i2Rnf;
        PIR44:
        $YNsmS = $this->RaPnW->files($fYb1T);
        goto dmnId;
        o1yUB:
        throw new \Exception("Message back with success data but not found thumbnail " . $Ls0bH);
        goto LYZTT;
        vMMVQ:
        if ($this->RaPnW->directoryExists($fYb1T)) {
            goto E3x7v;
        }
        goto VNBmE;
        LvcvD:
        $KuX31 = QdnSnf08v9RV7::findOrFail($Ls0bH);
        goto wXqEv;
        etL03:
    }
    public function getThumbnails(string $Ls0bH) : array
    {
        $KuX31 = QdnSnf08v9RV7::findOrFail($Ls0bH);
        return $KuX31->getThumbnails();
    }
}
