<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\WHyfIbzEzUFEe;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Core\Observer\B24zI37icS20t;
use Jfs\Uploader\Core\Observer\D2rOZBl7n0bql;
use Jfs\Uploader\Core\JmK3jjuoaQvAV;
use Jfs\Uploader\Core\S6ysKpQv89ofz;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
use Jfs\Uploader\Exception\DS3DIAJ2eyUA5;
use Jfs\Uploader\Exception\GNBoSRgkmhvfn;
use Jfs\Uploader\Service\FileResolver\Q2XJ8i6Pqd1lE;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class SLO5cl2ibvGWu
{
    private $VuglK;
    private $hYphi;
    private $wEVdN;
    public function __construct($ePcpM, $zuNM5, $dzspH)
    {
        goto gUQKj;
        gUQKj:
        $this->VuglK = $ePcpM;
        goto fA3ki;
        eaJ9T:
        $this->wEVdN = $dzspH;
        goto V_1Zt;
        fA3ki:
        $this->hYphi = $zuNM5;
        goto eaJ9T;
        V_1Zt:
    }
    public function mPQtt4SML7U($RVNMk)
    {
        goto x75Fb;
        x75Fb:
        if (!$RVNMk instanceof SingleUploadInterface) {
            goto ryEIa;
        }
        goto lkj01;
        Oh11B:
        ryEIa:
        goto AVNVM;
        lkj01:
        $hrJ9T = $RVNMk->getFile();
        goto XAJwr;
        XAJwr:
        return $this->mBnH8UJaZrB($hrJ9T->extension(), NZ0k4EM0XOGE7::S3, null, $RVNMk->options());
        goto Oh11B;
        AVNVM:
        return $this->mBnH8UJaZrB($RVNMk['file_extension'], 's3' === $RVNMk['driver'] ? NZ0k4EM0XOGE7::S3 : NZ0k4EM0XOGE7::LOCAL);
        goto ZBhz0;
        ZBhz0:
    }
    public function mWHA2SKypE0(string $hOWbX)
    {
        goto rjA5a;
        qgLU9:
        $VslFR = $this->mBnH8UJaZrB($s86ub->getAttribute('type'), $s86ub->getAttribute('driver'), $s86ub->getAttribute('id'));
        goto pc_gq;
        pc_gq:
        $VslFR->exists = true;
        goto t_tEP;
        rjA5a:
        $s86ub = config('upload.attachment_model')::findOrFail($hOWbX);
        goto qgLU9;
        t_tEP:
        $VslFR->setRawAttributes($s86ub->getAttributes());
        goto awctV;
        awctV:
        return $VslFR;
        goto TzU6k;
        TzU6k:
    }
    public function mARUIML1iFB(string $R2Ic5) : WHyfIbzEzUFEe
    {
        goto nfiaG;
        xvyRH:
        AHGAn:
        goto wnAsi;
        nfiaG:
        $Nc6Y1 = $this->hYphi->get($R2Ic5);
        goto BUwzn;
        PLL2E:
        $Nc6Y1 = $this->wEVdN->get($R2Ic5);
        goto xvyRH;
        fIDTO:
        xBwTC:
        goto BVL79;
        tYdXF:
        return $this->mBnH8UJaZrB($amuOv->LZRFL, $amuOv->m8OHhB52nVI(), $amuOv->filename);
        goto fIDTO;
        yL6Du:
        $amuOv = S6ysKpQv89ofz::m5UeYs1KdsH($p3JMC);
        goto tYdXF;
        wnAsi:
        $p3JMC = json_decode($Nc6Y1, true);
        goto KM1MP;
        BUwzn:
        if ($Nc6Y1) {
            goto AHGAn;
        }
        goto PLL2E;
        BVL79:
        throw new DS3DIAJ2eyUA5('metadata file not found');
        goto vFBKU;
        KM1MP:
        if (!$p3JMC) {
            goto xBwTC;
        }
        goto yL6Du;
        vFBKU:
    }
    private function mBnH8UJaZrB(string $yuhEU, $lA3pe, ?string $hOWbX = null, array $bbFOe = [])
    {
        goto D5SHi;
        DhnCX:
        throw new GNBoSRgkmhvfn("not support file type {$yuhEU}");
        goto tDQKW;
        Y7zsb:
        $dUCAx->mhhx9gSDj1U(new D2rOZBl7n0bql($dUCAx, $this->wEVdN, $bbFOe));
        goto ZJ2i1;
        AcHaF:
        $dUCAx = $dUCAx->m1YqyhBMS3V($lA3pe);
        goto Lv2ac;
        zKWQs:
        H2c20:
        goto DhnCX;
        D5SHi:
        $hOWbX = $hOWbX ?? Uuid::uuid4()->getHex()->toString();
        goto qQ6Gp;
        ZJ2i1:
        foreach ($this->VuglK as $JpnD6) {
            goto l7apq;
            yRUsW:
            return $dUCAx->initLocation($JpnD6->mtelO84CPhd($dUCAx));
            goto a0Uv4;
            a0Uv4:
            pYAH7:
            goto INHL2;
            l7apq:
            if (!$JpnD6->mbKoMYNQJOO($dUCAx)) {
                goto pYAH7;
            }
            goto yRUsW;
            INHL2:
            a6Oax:
            goto RMY7U;
            RMY7U:
        }
        goto zKWQs;
        qQ6Gp:
        switch ($yuhEU) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $dUCAx = D6FgZi8OHmjic::createFromScratch($hOWbX, $yuhEU);
                goto PPu0l;
            case 'mp4':
            case 'mov':
                $dUCAx = HS7SZ3rYPI80t::createFromScratch($hOWbX, $yuhEU);
                goto PPu0l;
            case 'pdf':
                $dUCAx = JmK3jjuoaQvAV::createFromScratch($hOWbX, $yuhEU);
                goto PPu0l;
            default:
                throw new GNBoSRgkmhvfn("not support file type {$yuhEU}");
        }
        goto S1scq;
        rabzB:
        PPu0l:
        goto AcHaF;
        S1scq:
        ZeS_G:
        goto rabzB;
        Lv2ac:
        $dUCAx->mhhx9gSDj1U(new B24zI37icS20t($dUCAx));
        goto Y7zsb;
        tDQKW:
    }
}
