<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Core\Observer\FroWfgAkxQDYE;
use Jfs\Uploader\Core\Observer\TxC84kcTUFPDC;
use Jfs\Uploader\Core\NGxsa4jamJSuW;
use Jfs\Uploader\Core\Ex01fdHOlxlg8;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Jfs\Uploader\Exception\LlZ7jHsX0xmpK;
use Jfs\Uploader\Service\FileResolver\MVK8yqlkSgksf;
use Ramsey\Uuid\Uuid;
final class SPtrbk9kcnPEI
{
    private $pvrKq;
    private $N3F9R;
    private $W_Kti;
    public function __construct($ljiNR, $mFX9i, $agzKA)
    {
        goto bqh7w;
        bqh7w:
        $this->pvrKq = $ljiNR;
        goto fbiAR;
        fbiAR:
        $this->N3F9R = $mFX9i;
        goto PZNWL;
        PZNWL:
        $this->W_Kti = $agzKA;
        goto gpEbL;
        gpEbL:
    }
    public function mOBwvyofVsV($i38y4)
    {
        goto aRy3Z;
        t3AJ1:
        return $this->mgqMVKS8ll9($i38y4['file_extension'], 's3' === $i38y4['driver'] ? WG4kCv0INtCV4::S3 : WG4kCv0INtCV4::LOCAL);
        goto ylIX8;
        aRy3Z:
        if (!$i38y4 instanceof SingleUploadInterface) {
            goto kJjoc;
        }
        goto GTumO;
        VGWs6:
        return $this->mgqMVKS8ll9($Y7BEv->extension(), WG4kCv0INtCV4::S3, null, $i38y4->options());
        goto wPEPi;
        GTumO:
        $Y7BEv = $i38y4->getFile();
        goto VGWs6;
        wPEPi:
        kJjoc:
        goto t3AJ1;
        ylIX8:
    }
    public function m3a9ZXSdFap(string $y06DH)
    {
        goto coKUE;
        qViGD:
        $a3XOL = $this->mgqMVKS8ll9($U9mNN->getAttribute('type'), $U9mNN->getAttribute('driver'), $U9mNN->getAttribute('id'));
        goto m8zSa;
        CXrCR:
        $a3XOL->setRawAttributes($U9mNN->getAttributes());
        goto eGwKk;
        m8zSa:
        $a3XOL->exists = true;
        goto CXrCR;
        eGwKk:
        return $a3XOL;
        goto zrimO;
        coKUE:
        $U9mNN = config('upload.attachment_model')::findOrFail($y06DH);
        goto qViGD;
        zrimO:
    }
    public function mdMn4oMULx2(string $ykG9Y) : SK7fSNbDSRmCO
    {
        goto vrt5v;
        j1ryM:
        $N_pEQ = $this->W_Kti->get($ykG9Y);
        goto akSrJ;
        vrt5v:
        $N_pEQ = $this->N3F9R->get($ykG9Y);
        goto tUTDd;
        O59NI:
        AMRhf:
        goto HjKDy;
        vxg7W:
        $fzJCm = Ex01fdHOlxlg8::mM0E1wVRoI2($Ds24j);
        goto pZt7n;
        pZt7n:
        return $this->mgqMVKS8ll9($fzJCm->b11vd, $fzJCm->mwR4ZNqPtM8(), $fzJCm->filename);
        goto O59NI;
        tUTDd:
        if ($N_pEQ) {
            goto DUQZB;
        }
        goto j1ryM;
        HjKDy:
        throw new Uxbn1AMqHjlda('metadata file not found');
        goto kp2JU;
        Y_2xg:
        if (!$Ds24j) {
            goto AMRhf;
        }
        goto vxg7W;
        akSrJ:
        DUQZB:
        goto HlFLo;
        HlFLo:
        $Ds24j = json_decode($N_pEQ, true);
        goto Y_2xg;
        kp2JU:
    }
    private function mgqMVKS8ll9(string $flPmP, $TWprQ, ?string $y06DH = null, array $AMB6h = [])
    {
        goto PN1jL;
        yyEaW:
        U3rM_:
        goto rHX5o;
        f0e51:
        $uynMQ->mqyYIlRyjYD(new FroWfgAkxQDYE($uynMQ));
        goto LyBNw;
        VRI4a:
        throw new LlZ7jHsX0xmpK("not support file type {$flPmP}");
        goto JipSo;
        PN1jL:
        $y06DH = $y06DH ?? Uuid::uuid4()->getHex()->toString();
        goto WL_vR;
        LyBNw:
        $uynMQ->mqyYIlRyjYD(new TxC84kcTUFPDC($uynMQ, $this->W_Kti, $AMB6h));
        goto yLrOL;
        yLrOL:
        foreach ($this->pvrKq as $Kacxo) {
            goto MFP6q;
            E3YHw:
            hVmjI:
            goto fVAk_;
            fVAk_:
            J9d_K:
            goto JzXbD;
            MFP6q:
            if (!$Kacxo->mQWLmEjfuDm($uynMQ)) {
                goto hVmjI;
            }
            goto OyjNi;
            OyjNi:
            return $uynMQ->initLocation($Kacxo->mLYfWApn4bI($uynMQ));
            goto E3YHw;
            JzXbD:
        }
        goto dgwk6;
        rHX5o:
        $uynMQ = $uynMQ->mI9YcjXiudZ($TWprQ);
        goto f0e51;
        CNoaL:
        mpsUb:
        goto yyEaW;
        WL_vR:
        switch ($flPmP) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $uynMQ = LGMw063tEE9ZC::createFromScratch($y06DH, $flPmP);
                goto U3rM_;
            case 'mp4':
            case 'mov':
                $uynMQ = GXtnGiMmIPEIc::createFromScratch($y06DH, $flPmP);
                goto U3rM_;
            case 'pdf':
                $uynMQ = NGxsa4jamJSuW::createFromScratch($y06DH, $flPmP);
                goto U3rM_;
            default:
                throw new LlZ7jHsX0xmpK("not support file type {$flPmP}");
        }
        goto CNoaL;
        dgwk6:
        nLa6x:
        goto VRI4a;
        JipSo:
    }
}
