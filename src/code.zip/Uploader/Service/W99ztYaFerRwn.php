<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\Zv4WZkC8rwgvt;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Core\Observer\OIvzAwPhFJac5;
use Jfs\Uploader\Core\Observer\Jw8i93eV2m7dB;
use Jfs\Uploader\Core\McjNajNYCqDZl;
use Jfs\Uploader\Core\UH9DV4SMWOQOz;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Jfs\Uploader\Exception\Javj89gHS43od;
use Jfs\Uploader\Exception\HaB2yhTzru90X;
use Jfs\Uploader\Service\FileResolver\YWL2m71sSqZd2;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class W99ztYaFerRwn
{
    private $DfTeA;
    private $h0iwI;
    private $iHPgt;
    public function __construct($K067z, $jxMWP, $zeM4q)
    {
        goto JsOXA;
        JsOXA:
        $this->DfTeA = $K067z;
        goto ws_OW;
        ws_OW:
        $this->h0iwI = $jxMWP;
        goto W5_cQ;
        W5_cQ:
        $this->iHPgt = $zeM4q;
        goto s18PM;
        s18PM:
    }
    public function mAhVG2DCuhs($wBusQ)
    {
        goto Z0W4J;
        Z0W4J:
        if (!$wBusQ instanceof SingleUploadInterface) {
            goto TWKW7;
        }
        goto XSr5v;
        WCEuj:
        TWKW7:
        goto sqneQ;
        sqneQ:
        return $this->mNhE3jal8I6($wBusQ['file_extension'], 's3' === $wBusQ['driver'] ? ISqBWmYzjt1eQ::S3 : ISqBWmYzjt1eQ::LOCAL);
        goto AEkF_;
        VlHNI:
        return $this->mNhE3jal8I6($q6xnu->extension(), ISqBWmYzjt1eQ::S3, null, $wBusQ->options());
        goto WCEuj;
        XSr5v:
        $q6xnu = $wBusQ->getFile();
        goto VlHNI;
        AEkF_:
    }
    public function mhd5AAeH9hj(string $tu00C)
    {
        goto R2A2z;
        V9OdO:
        $bwI0g->exists = true;
        goto qjEuk;
        dk0zW:
        $bwI0g = $this->mNhE3jal8I6($kPdH9->getAttribute('type'), $kPdH9->getAttribute('driver'), $kPdH9->getAttribute('id'));
        goto V9OdO;
        e2V4W:
        return $bwI0g;
        goto kx0SA;
        qjEuk:
        $bwI0g->setRawAttributes($kPdH9->getAttributes());
        goto e2V4W;
        R2A2z:
        $kPdH9 = config('upload.attachment_model')::findOrFail($tu00C);
        goto dk0zW;
        kx0SA:
    }
    public function morhAThw6LY(string $zWYZN) : Zv4WZkC8rwgvt
    {
        goto jxv0F;
        meXRm:
        zpr8C:
        goto bCWdv;
        bCWdv:
        $V5lrw = json_decode($SYHld, true);
        goto LVY3C;
        YYCky:
        $aij2G = UH9DV4SMWOQOz::mOTyUjsFr9A($V5lrw);
        goto nN1xk;
        nN1xk:
        return $this->mNhE3jal8I6($aij2G->B2Zq2, $aij2G->mgJNw7RoTDj(), $aij2G->filename);
        goto wiLRC;
        I59h3:
        $SYHld = $this->iHPgt->get($zWYZN);
        goto meXRm;
        LVY3C:
        if (!$V5lrw) {
            goto Jahcy;
        }
        goto YYCky;
        s8u5m:
        if ($SYHld) {
            goto zpr8C;
        }
        goto I59h3;
        wiLRC:
        Jahcy:
        goto y3Kuh;
        y3Kuh:
        throw new Javj89gHS43od('metadata file not found');
        goto zRqab;
        jxv0F:
        $SYHld = $this->h0iwI->get($zWYZN);
        goto s8u5m;
        zRqab:
    }
    private function mNhE3jal8I6(string $is_cA, $TndRN, ?string $tu00C = null, array $v5VWU = [])
    {
        goto we0Xe;
        Sw_ly:
        switch ($is_cA) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $CxDwZ = VPGaYsuFJzbQ0::createFromScratch($tu00C, $is_cA);
                goto gVpYj;
            case 'mp4':
            case 'mov':
                $CxDwZ = SNpic2wzC1yT8::createFromScratch($tu00C, $is_cA);
                goto gVpYj;
            case 'pdf':
                $CxDwZ = McjNajNYCqDZl::createFromScratch($tu00C, $is_cA);
                goto gVpYj;
            default:
                throw new HaB2yhTzru90X("not support file type {$is_cA}");
        }
        goto caWB0;
        caWB0:
        XNlwF:
        goto Kj7qS;
        Kj7qS:
        gVpYj:
        goto tVfch;
        QVmeA:
        throw new HaB2yhTzru90X("not support file type {$is_cA}");
        goto GSEcI;
        pGemB:
        WV95M:
        goto QVmeA;
        mM63E:
        $CxDwZ->meWhUv2FYYU(new Jw8i93eV2m7dB($CxDwZ, $this->iHPgt, $v5VWU));
        goto NIBH7;
        tVfch:
        $CxDwZ = $CxDwZ->mx3HfzNQyRc($TndRN);
        goto B85C9;
        NIBH7:
        foreach ($this->DfTeA as $Y3Zr2) {
            goto iGlzM;
            iGlzM:
            if (!$Y3Zr2->mnhMARrN4iG($CxDwZ)) {
                goto gIQGI;
            }
            goto Us_BF;
            Us_BF:
            return $CxDwZ->initLocation($Y3Zr2->mAVCiwzictn($CxDwZ));
            goto jK7Ns;
            jK7Ns:
            gIQGI:
            goto SnmI1;
            SnmI1:
            hQeGN:
            goto jib49;
            jib49:
        }
        goto pGemB;
        we0Xe:
        $tu00C = $tu00C ?? Uuid::uuid4()->getHex()->toString();
        goto Sw_ly;
        B85C9:
        $CxDwZ->meWhUv2FYYU(new OIvzAwPhFJac5($CxDwZ));
        goto mM63E;
        GSEcI:
    }
}
