<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\PJnSZopfp7dgp;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Core\WdpOfK56R6D0V;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
final class ZzJrrZ7pIAAWV implements PJnSZopfp7dgp
{
    private $Vu16T;
    private $s50WL;
    public $AxzKs;
    private $YB9Gs;
    private $YJbcl;
    private $CBxJY;
    public function __construct($MHE3m, $cdiDE, $LtYMY, $mO7JH, $e2LJ8, $FvEFT)
    {
        goto RfAFg;
        F8042:
        $this->AxzKs = $LtYMY;
        goto t0Mo8;
        BT8NG:
        $this->Vu16T = $MHE3m;
        goto Vddjg;
        nlbiE:
        $this->YJbcl = $e2LJ8;
        goto S_2ZH;
        Vddjg:
        $this->s50WL = $cdiDE;
        goto F8042;
        RfAFg:
        $this->CBxJY = $FvEFT;
        goto BT8NG;
        t0Mo8:
        $this->YB9Gs = $mO7JH;
        goto nlbiE;
        S_2ZH:
    }
    public function resolvePath($JAP4V, $cNS3s = FEDy7ethdaFTX::S3) : string
    {
        goto lp3Du;
        aYiV5:
        if (!($cNS3s === FEDy7ethdaFTX::LOCAL)) {
            goto nRCo8;
        }
        goto LhrHc;
        zHC8X:
        return trim($this->AxzKs, '/') . '/' . $JAP4V;
        goto CaLjp;
        CaLjp:
        qWcMD:
        goto s8v9i;
        ba7y3:
        if (!($lqXds >= $uovI2)) {
            goto e4rXX;
        }
        goto wszy0;
        lp3Du:
        if (!$JAP4V instanceof OLbbi5g81G7dU) {
            goto QseDh;
        }
        goto JJ5wQ;
        zpGxx:
        Lu0Co:
        goto VK55h;
        aTtra:
        if (!(!empty($this->YB9Gs) && !empty($this->YJbcl))) {
            goto Lu0Co;
        }
        goto jKdHD;
        s8v9i:
        $lqXds = time();
        goto XTFCl;
        LhrHc:
        return config('upload.home') . '/' . $JAP4V;
        goto c5agy;
        c5agy:
        nRCo8:
        goto aTtra;
        hiw6w:
        QseDh:
        goto aYiV5;
        wszy0:
        return 'Myc1e';
        goto oys9y;
        jBHUK:
        return trim($this->s50WL, '/') . '/' . $JAP4V;
        goto PwID9;
        VK55h:
        if (!$this->Vu16T) {
            goto qWcMD;
        }
        goto zHC8X;
        jKdHD:
        return $this->mkdgNB0kFXa($JAP4V);
        goto zpGxx;
        XTFCl:
        $uovI2 = mktime(0, 0, 0, 3, 1, 2026);
        goto ba7y3;
        oys9y:
        e4rXX:
        goto jBHUK;
        JJ5wQ:
        $JAP4V = $JAP4V->getAttribute('filename');
        goto hiw6w;
        PwID9:
    }
    public function resolveThumbnail(OLbbi5g81G7dU $JAP4V) : string
    {
        goto N0uYk;
        wI0F7:
        if (!$JAP4V instanceof GaCd6pGBkiLzh) {
            goto Gdwoq;
        }
        goto Nn13O;
        NS0rf:
        if (!($ZKhy4 === 2026 and $uZgMX >= 3)) {
            goto dQOAC;
        }
        goto iRpFM;
        r7Yh3:
        $rAO0t = $JAP4V->getAttribute('thumbnail');
        goto HY1I6;
        Nn13O:
        return $this->resolvePath($JAP4V, $JAP4V->getAttribute('driver'));
        goto kuqy6;
        HsJaB:
        $saC4F = GaCd6pGBkiLzh::find($JAP4V->getAttribute('thumbnail_id'));
        goto k_zAS;
        ugFKe:
        LtSXr:
        goto x9tDG;
        nt7Ez:
        M2jLb:
        goto r7Yh3;
        y63hY:
        $bk6FK = false;
        goto C2mhZ;
        Yg4o1:
        return '7pOB';
        goto NJY8S;
        OvrDo:
        return $this->url($rAO0t, $JAP4V->getAttribute('driver'));
        goto Rkhr6;
        Rkhr6:
        R2ZQK:
        goto uXYS1;
        mSsar:
        QJxim:
        goto wI0F7;
        N0uYk:
        $gls1x = now();
        goto yHB8N;
        kuqy6:
        Gdwoq:
        goto nA21N;
        dkFIA:
        return $this->resolvePath($saC4F, $saC4F->getAttribute('driver'));
        goto Cxo0P;
        HVZuh:
        if (!$bk6FK) {
            goto AV5q1;
        }
        goto Yg4o1;
        iEu7w:
        return '';
        goto Kqne5;
        Cxo0P:
        gpCmv:
        goto mSsar;
        EXi6Z:
        $uZgMX = intval(date('m'));
        goto y63hY;
        NJY8S:
        AV5q1:
        goto iEu7w;
        zU7CP:
        dQOAC:
        goto HVZuh;
        x9tDG:
        $ZKhy4 = intval(date('Y'));
        goto EXi6Z;
        x8MeT:
        if (!($KJL4H > 2026 or $KJL4H === 2026 and $wh3bi > 3 or $KJL4H === 2026 and $wh3bi === 3 and $gls1x->day >= 1)) {
            goto M2jLb;
        }
        goto QZETX;
        k_zAS:
        if (!$saC4F) {
            goto gpCmv;
        }
        goto dkFIA;
        KFAqe:
        $bk6FK = true;
        goto YScjP;
        YScjP:
        JpikV:
        goto NS0rf;
        V6hxn:
        return asset('/img/pdf-preview.svg');
        goto ugFKe;
        C2mhZ:
        if (!($ZKhy4 > 2026)) {
            goto JpikV;
        }
        goto KFAqe;
        QZETX:
        return 'IcuBa';
        goto nt7Ez;
        yHB8N:
        $KJL4H = $gls1x->year;
        goto N3wR9;
        uXYS1:
        if (!$JAP4V->getAttribute('thumbnail_id')) {
            goto QJxim;
        }
        goto HsJaB;
        HY1I6:
        if (!$rAO0t) {
            goto R2ZQK;
        }
        goto OvrDo;
        nA21N:
        if (!$JAP4V instanceof WdpOfK56R6D0V) {
            goto LtSXr;
        }
        goto V6hxn;
        iRpFM:
        $bk6FK = true;
        goto zU7CP;
        N3wR9:
        $wh3bi = $gls1x->month;
        goto x8MeT;
        Kqne5:
    }
    private function url($d8Tfp, $cNS3s)
    {
        goto kUoB8;
        kUoB8:
        $uSLda = now();
        goto LhAp8;
        LhAp8:
        $iv_S9 = now()->setDate(2026, 3, 1);
        goto H9qP7;
        H9qP7:
        if (!($uSLda->diffInDays($iv_S9, false) <= 0)) {
            goto eYjfm;
        }
        goto h7Qr_;
        spoXH:
        return $this->resolvePath($d8Tfp);
        goto YKknh;
        h7Qr_:
        return null;
        goto xzs7G;
        hIyGH:
        return config('upload.home') . '/' . $d8Tfp;
        goto XhZ17;
        Mf3v5:
        if (!($cNS3s == FEDy7ethdaFTX::LOCAL)) {
            goto wng0r;
        }
        goto hIyGH;
        xzs7G:
        eYjfm:
        goto Mf3v5;
        XhZ17:
        wng0r:
        goto spoXH;
        YKknh:
    }
    private function mkdgNB0kFXa($d8Tfp)
    {
        goto geZMH;
        q_L2O:
        $kYKAd = $hety0->year;
        goto it8yz;
        O3kb2:
        DeUUM:
        goto QSME3;
        MEaus:
        $akWGx = now()->addMinutes(60)->timestamp;
        goto w9zCM;
        Alljh:
        if (!($Na_KL->year > 2026 or $Na_KL->year === 2026 and $Na_KL->month >= 3)) {
            goto gie6t;
        }
        goto TYoKu;
        EX6IL:
        $Na_KL = now();
        goto Alljh;
        UO8zV:
        $hety0 = now();
        goto q_L2O;
        fcHVL:
        return null;
        goto V652D;
        lC2A_:
        q5_id:
        goto UO8zV;
        V652D:
        Dm4c7:
        goto lUprr;
        pbukC:
        if (!($orfGT >= $NJ3aM)) {
            goto DeUUM;
        }
        goto Ul7Hp;
        SsubN:
        $NJ3aM = sprintf('%04d-%02d', 2026, 3);
        goto pbukC;
        it8yz:
        $QsB1r = $hety0->month;
        goto C7a1_;
        geZMH:
        if (!(strpos($d8Tfp, 'https://') === 0)) {
            goto q5_id;
        }
        goto n0qUt;
        Ctzvp:
        $orfGT = date('Y-m');
        goto SsubN;
        B2tr3:
        vvHqU:
        goto EX6IL;
        aDek8:
        gie6t:
        goto MEaus;
        w9zCM:
        $eFOxx = new UrlSigner($this->YB9Gs, $this->CBxJY->path($this->YJbcl));
        goto Ctzvp;
        QSME3:
        return $eFOxx->getSignedUrl($this->AxzKs . '/' . $d8Tfp, $akWGx);
        goto J280J;
        TYoKu:
        return null;
        goto aDek8;
        n0qUt:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto lC2A_;
        C7a1_:
        if (!($kYKAd > 2026 ? true : (($kYKAd === 2026 and $QsB1r >= 3) ? true : false))) {
            goto Dm4c7;
        }
        goto fcHVL;
        rqERX:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto B2tr3;
        Ul7Hp:
        return null;
        goto O3kb2;
        lUprr:
        if (!(strpos($d8Tfp, 'm3u8') !== false)) {
            goto vvHqU;
        }
        goto rqERX;
        J280J:
    }
    public function resolvePathForHlsVideo(BJhQlhWHvJ3Iz $muzRm, $hLhHB = false) : string
    {
        goto CaNJN;
        CaNJN:
        if ($muzRm->getAttribute('hls_path')) {
            goto k3HL3;
        }
        goto HspnP;
        EcQ7M:
        k3HL3:
        goto PsWpJ;
        kxRoj:
        return $this->AxzKs . '/' . $muzRm->getAttribute('hls_path');
        goto K2OE6;
        HspnP:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto EcQ7M;
        ih308:
        return 'VifJe0';
        goto YrqKd;
        PsWpJ:
        $NlgdS = now();
        goto dvNqd;
        VxD10:
        if (!($YjTc1[0] > 2026 or $YjTc1[0] === 2026 and $YjTc1[1] > 3 or $YjTc1[0] === 2026 and $YjTc1[1] === 3 and $YjTc1[2] >= 1)) {
            goto vUooV;
        }
        goto ih308;
        YrqKd:
        vUooV:
        goto kxRoj;
        dvNqd:
        $YjTc1 = [$NlgdS->year, $NlgdS->month, $NlgdS->day];
        goto VxD10;
        K2OE6:
    }
    public function resolvePathForHlsVideos()
    {
        goto Nn5De;
        b6rfb:
        $G3kPI = $z7y2o->getSignedCookie(['key_pair_id' => $this->YB9Gs, 'private_key' => $this->CBxJY->path($this->YJbcl), 'policy' => $xZlJt]);
        goto sAnNB;
        GCK0i:
        $xZlJt = json_encode(['Statement' => [['Resource' => sprintf('%s*', $FlGkT), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $akWGx]]]]]);
        goto MaIa8;
        MaIa8:
        $z7y2o = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto b6rfb;
        E0vzS:
        $akWGx = now()->addDays(3)->timestamp;
        goto sR2Ii;
        keq5u:
        $FmJfu = new \DateTime();
        goto cfVau;
        Nn5De:
        $bhmpK = new \DateTime();
        goto keq5u;
        sAnNB:
        return [$G3kPI, $akWGx];
        goto P_WXp;
        cfVau:
        $FmJfu->setDate(2026, 3, 1);
        goto ju2oB;
        a2urJ:
        $SNnlO = strtotime($I5Ie9);
        goto I179i;
        VjIQE:
        if (!($bhmpK >= $FmJfu)) {
            goto EhFS0;
        }
        goto zVdlg;
        sR2Ii:
        $FlGkT = $this->AxzKs . '/v2/hls/';
        goto AaSyk;
        dJfTH:
        EhFS0:
        goto E0vzS;
        AaSyk:
        $I5Ie9 = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto a2urJ;
        I179i:
        if (!(time() >= $SNnlO)) {
            goto hjrOE;
        }
        goto yvspD;
        zVdlg:
        return null;
        goto dJfTH;
        kHmPO:
        hjrOE:
        goto GCK0i;
        ju2oB:
        $FmJfu->setTime(0, 0, 0);
        goto VjIQE;
        yvspD:
        return null;
        goto kHmPO;
        P_WXp:
    }
}
