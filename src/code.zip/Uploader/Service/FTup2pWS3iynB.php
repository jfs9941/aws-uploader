<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Illuminate\Contracts\Filesystem\Filesystem;
final class FTup2pWS3iynB
{
    private $gHJ_C;
    private $cidN5;
    private $iAAqk;
    public function __construct(string $iwKga, string $EO_Zv, Filesystem $YNIuu)
    {
        goto BtS7T;
        szuCQ:
        $this->iAAqk = $YNIuu;
        goto Fi41R;
        a4ApU:
        $this->cidN5 = $EO_Zv;
        goto szuCQ;
        BtS7T:
        $this->gHJ_C = $iwKga;
        goto a4ApU;
        Fi41R:
    }
    public function m21ZRedpx8D(THrRXrYMGJt0m $IdScp) : string
    {
        goto bV5am;
        dm9Vy:
        LEoGM:
        goto qsTJB;
        F3MvK:
        return 's3://' . $this->gHJ_C . '/' . $IdScp->getAttribute('filename');
        goto dm9Vy;
        bV5am:
        if (!(Tfi7lQDVWUJD9::S3 == $IdScp->getAttribute('driver'))) {
            goto LEoGM;
        }
        goto F3MvK;
        qsTJB:
        return $this->iAAqk->url($IdScp->getAttribute('filename'));
        goto a1xyS;
        a1xyS:
    }
    public function mQq6t1OfiF4(?string $yGB2u) : ?string
    {
        goto NZLKh;
        O1MFH:
        bHw2l:
        goto VpBc2;
        NZLKh:
        if (!$yGB2u) {
            goto yXWtn;
        }
        goto BO7ZA;
        gYKVM:
        return 's3://' . $this->gHJ_C . '/' . ltrim($cJV8L, '/');
        goto O1MFH;
        TRIwI:
        return null;
        goto gt0BI;
        c0wCt:
        $cJV8L = parse_url($yGB2u, PHP_URL_PATH);
        goto gYKVM;
        VpBc2:
        yXWtn:
        goto TRIwI;
        BO7ZA:
        if (!str_contains($yGB2u, $this->gHJ_C)) {
            goto bHw2l;
        }
        goto c0wCt;
        gt0BI:
    }
    public function mWPnOJO9f3o(string $cJV8L) : string
    {
        return 's3://' . $this->gHJ_C . '/' . $cJV8L;
    }
}
