<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ETNYJFyUYZrNI
{
    private $QNBCN;
    private $cN5hJ;
    private $W9e5K;
    public function __construct(string $APN4u, string $WZqbO, Filesystem $XCkIj)
    {
        goto RJXAo;
        RJXAo:
        $this->QNBCN = $APN4u;
        goto rTVHe;
        z91EK:
        $this->W9e5K = $XCkIj;
        goto j29Q0;
        rTVHe:
        $this->cN5hJ = $WZqbO;
        goto z91EK;
        j29Q0:
    }
    public function mKYdGXvWtEV(MIyg7KY6jn9L1 $IcEa3) : string
    {
        goto KKSGj;
        QEiWQ:
        wNk9I:
        goto xOj4f;
        ULf1D:
        return 's3://' . $this->QNBCN . '/' . $IcEa3->getAttribute('filename');
        goto QEiWQ;
        xOj4f:
        return $this->W9e5K->url($IcEa3->getAttribute('filename'));
        goto dAtLQ;
        KKSGj:
        if (!(I5kpK7wkbRQvu::S3 == $IcEa3->getAttribute('driver'))) {
            goto wNk9I;
        }
        goto ULf1D;
        dAtLQ:
    }
    public function mbQN4XBftAz(?string $RfsQZ) : ?string
    {
        goto ACpOn;
        sJJg9:
        return null;
        goto OvnNx;
        ACpOn:
        if (!$RfsQZ) {
            goto GrouD;
        }
        goto p3JKD;
        TilOX:
        GrouD:
        goto sJJg9;
        E78PG:
        return 's3://' . $this->QNBCN . '/' . ltrim($vRakW, '/');
        goto V1aai;
        V1aai:
        Xl2Ov:
        goto TilOX;
        p3JKD:
        if (!k7pSg($RfsQZ, $this->QNBCN)) {
            goto Xl2Ov;
        }
        goto nyk7t;
        nyk7t:
        $vRakW = parse_url($RfsQZ, PHP_URL_PATH);
        goto E78PG;
        OvnNx:
    }
    public function mQGt2T4MpQP(string $vRakW) : string
    {
        return 's3://' . $this->QNBCN . '/' . $vRakW;
    }
}
