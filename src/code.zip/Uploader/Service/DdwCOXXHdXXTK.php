<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\FK56xL1HuXbff;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Core\NYMdb5NeWwwAT;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
final class DdwCOXXHdXXTK implements FK56xL1HuXbff
{
    private $T9_uY;
    private $eH_8M;
    public $NB2su;
    private $z2hLB;
    private $t6Ra6;
    private $s3l3u;
    public function __construct($nfhs7, $wY4S8, $inaT5, $Koq5T, $QRSs_, $lKCQu)
    {
        goto Lipve;
        vtcM8:
        $this->T9_uY = $nfhs7;
        goto gD9DE;
        Lipve:
        $this->s3l3u = $lKCQu;
        goto vtcM8;
        sq5wk:
        $this->NB2su = $inaT5;
        goto BQH7s;
        gD9DE:
        $this->eH_8M = $wY4S8;
        goto sq5wk;
        BQH7s:
        $this->z2hLB = $Koq5T;
        goto GgjIM;
        GgjIM:
        $this->t6Ra6 = $QRSs_;
        goto dNj1l;
        dNj1l:
    }
    public function resolvePath($F251H, $Mf3Ow = L2PWLPeQEFi6U::S3) : string
    {
        goto XF6df;
        jLMnw:
        $F251H = $F251H->getAttribute('filename');
        goto usoUZ;
        usoUZ:
        hPAMQ:
        goto oz0_O;
        zTX5p:
        return trim($this->NB2su, '/') . '/' . $F251H;
        goto iyrv5;
        gc1NI:
        if (!$this->T9_uY) {
            goto m3ORR;
        }
        goto zTX5p;
        gjRjQ:
        if (!(!empty($this->z2hLB) && !empty($this->t6Ra6))) {
            goto XAskK;
        }
        goto GSzj1;
        XF6df:
        if (!$F251H instanceof HtHJXf7xellNX) {
            goto hPAMQ;
        }
        goto jLMnw;
        Cqi9b:
        return trim($this->eH_8M, '/') . '/' . $F251H;
        goto b_CfD;
        wkSLg:
        XAskK:
        goto gc1NI;
        D5GlX:
        return config('upload.home') . '/' . $F251H;
        goto jW1kO;
        GSzj1:
        return $this->m48yvUjNTOC($F251H);
        goto wkSLg;
        oz0_O:
        if (!($Mf3Ow === L2PWLPeQEFi6U::LOCAL)) {
            goto A3aWc;
        }
        goto D5GlX;
        jW1kO:
        A3aWc:
        goto gjRjQ;
        iyrv5:
        m3ORR:
        goto Cqi9b;
        b_CfD:
    }
    public function resolveThumbnail(HtHJXf7xellNX $F251H) : string
    {
        goto yMOwA;
        ALjmy:
        return $this->resolvePath($O84MW, $O84MW->getAttribute('driver'));
        goto H0xRf;
        xjJ0W:
        if (!$eeT1E) {
            goto nKdYn;
        }
        goto TKIdF;
        Sehyp:
        GgMzf:
        goto OgGTE;
        oMFG1:
        return '';
        goto Sl0IQ;
        g_ZBl:
        WHqo4:
        goto EsSvK;
        OgGTE:
        if (!$F251H instanceof NYMdb5NeWwwAT) {
            goto GVwHT;
        }
        goto BgGr5;
        MB73f:
        if (!$O84MW) {
            goto RW29u;
        }
        goto ALjmy;
        H0xRf:
        RW29u:
        goto g_ZBl;
        TKIdF:
        return $this->url($eeT1E, $F251H->getAttribute('driver'));
        goto P_65U;
        Mkk7G:
        GVwHT:
        goto oMFG1;
        P_65U:
        nKdYn:
        goto UNOtN;
        UNOtN:
        if (!$F251H->getAttribute('thumbnail_id')) {
            goto WHqo4;
        }
        goto eHIP8;
        yMOwA:
        $eeT1E = $F251H->getAttribute('thumbnail');
        goto xjJ0W;
        eHIP8:
        $O84MW = KZbAaRxCqNUr3::find($F251H->getAttribute('thumbnail_id'));
        goto MB73f;
        EsSvK:
        if (!$F251H instanceof KZbAaRxCqNUr3) {
            goto GgMzf;
        }
        goto A2UDi;
        A2UDi:
        return $this->resolvePath($F251H, $F251H->getAttribute('driver'));
        goto Sehyp;
        BgGr5:
        return asset('/img/pdf-preview.svg');
        goto Mkk7G;
        Sl0IQ:
    }
    private function url($lT4E3, $Mf3Ow)
    {
        goto GXOa7;
        zGtwR:
        return config('upload.home') . '/' . $lT4E3;
        goto FxGBU;
        GXOa7:
        if (!($Mf3Ow == L2PWLPeQEFi6U::LOCAL)) {
            goto NNPBG;
        }
        goto zGtwR;
        FxGBU:
        NNPBG:
        goto cOAvZ;
        cOAvZ:
        return $this->resolvePath($lT4E3);
        goto FSzEO;
        FSzEO:
    }
    private function m48yvUjNTOC($lT4E3)
    {
        goto pFlmH;
        pFlmH:
        if (!(strpos($lT4E3, 'https://') === 0)) {
            goto iSy9J;
        }
        goto mATgU;
        zaIID:
        return $yTljE->getSignedUrl($this->NB2su . '/' . $lT4E3, $QrKGn);
        goto neYfx;
        BiZLP:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto B8HGc;
        mATgU:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto xNHPW;
        xNHPW:
        iSy9J:
        goto GdKr4;
        Fi0_7:
        $yTljE = new UrlSigner($this->z2hLB, $this->s3l3u->path($this->t6Ra6));
        goto zaIID;
        B8HGc:
        S29Wr:
        goto YRvDe;
        YRvDe:
        $QrKGn = now()->addMinutes(60)->timestamp;
        goto Fi0_7;
        GdKr4:
        if (!(strpos($lT4E3, 'm3u8') !== false)) {
            goto S29Wr;
        }
        goto BiZLP;
        neYfx:
    }
    public function resolvePathForHlsVideo(ISYJHQo8eqdfc $qNHE7, $QBBdE = false) : string
    {
        goto BGlaf;
        HBxiP:
        a_UqA:
        goto VX2Yc;
        VX2Yc:
        return $this->NB2su . '/' . $qNHE7->getAttribute('hls_path');
        goto cpvPQ;
        xvSA8:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto HBxiP;
        BGlaf:
        if ($qNHE7->getAttribute('hls_path')) {
            goto a_UqA;
        }
        goto xvSA8;
        cpvPQ:
    }
    public function resolvePathForHlsVideos()
    {
        goto yrbJ8;
        wVSdS:
        $iTX0K = $this->NB2su . '/v2/hls/';
        goto G9ncp;
        y_WSQ:
        $jA8Ll = $WhkCf->getSignedCookie(['key_pair_id' => $this->z2hLB, 'private_key' => $this->s3l3u->path($this->t6Ra6), 'policy' => $iJPjG]);
        goto tDQT4;
        yrbJ8:
        $QrKGn = now()->addDays(3)->timestamp;
        goto wVSdS;
        h0itQ:
        $WhkCf = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto y_WSQ;
        G9ncp:
        $iJPjG = json_encode(['Statement' => [['Resource' => sprintf('%s*', $iTX0K), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $QrKGn]]]]]);
        goto h0itQ;
        tDQT4:
        return [$jA8Ll, $QrKGn];
        goto uxte2;
        uxte2:
    }
}
