<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Core\MxslGSmH9dMgZ;
use Jfs\Uploader\Core\D4VgMZN43BF8o;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Jfs\Uploader\Exception\O21XtZt2mzRw1;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Exception\ST4IwPMeWC8T9;
use Jfs\Uploader\Service\L3m1gGxcrxodn;
use Illuminate\Contracts\Filesystem\Filesystem;
final class NyCbXtNoSpUdB implements UploadServiceInterface
{
    private $llJyR;
    private $W9e5K;
    private $cEZhz;
    private $ErdYm;
    public function __construct(L3m1gGxcrxodn $rk6ee, Filesystem $XCkIj, Filesystem $UubHF, string $intl8)
    {
        goto PRHWl;
        o63to:
        $this->cEZhz = $UubHF;
        goto Tla0U;
        NT4uy:
        $this->W9e5K = $XCkIj;
        goto o63to;
        Tla0U:
        $this->ErdYm = $intl8;
        goto J_fSX;
        PRHWl:
        $this->llJyR = $rk6ee;
        goto NT4uy;
        J_fSX:
    }
    public function storeSingleFile(SingleUploadInterface $iY7b2) : array
    {
        goto oa6qJ;
        vRvdz:
        return $k2MU3->getView();
        goto wCk3o;
        ELsem:
        $k2MU3->ms4OoFrTljH(A9q1Lm9l5QixG::UPLOADED);
        goto U3HuE;
        jVG3z:
        $vRakW = $this->cEZhz->putFileAs(dirname($k2MU3->getLocation()), $iY7b2->getFile(), $k2MU3->getFilename() . '.' . $k2MU3->getExtension(), ['visibility' => 'public']);
        goto LjL_a;
        LjL_a:
        if (false !== $vRakW && $k2MU3 instanceof CyraHfwSfcIZC) {
            goto eCyIS;
        }
        goto ikZJ9;
        U3HuE:
        QHi7S:
        goto vRvdz;
        ihtqQ:
        goto QHi7S;
        goto oQo6h;
        ikZJ9:
        throw new \LogicException('File upload failed, check permissions');
        goto ihtqQ;
        oQo6h:
        eCyIS:
        goto ELsem;
        oa6qJ:
        $k2MU3 = $this->llJyR->mg4ua8yTKdn($iY7b2);
        goto jVG3z;
        wCk3o:
    }
    public function storePreSignedFile(array $BJSZl)
    {
        goto PfYwE;
        bFpUH:
        return ['filename' => $oXu1C->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $oXu1C->mD2bzG2lTmU()];
        goto cVVWJ;
        PfYwE:
        $k2MU3 = $this->llJyR->mg4ua8yTKdn($BJSZl);
        goto emU4Y;
        aAx2u:
        $oXu1C->mlJIEdRvYbl();
        goto bFpUH;
        emU4Y:
        $oXu1C = D4VgMZN43BF8o::miICgCVs1tP($k2MU3, $this->W9e5K, $this->cEZhz, $this->ErdYm, true);
        goto bhxYk;
        bhxYk:
        $oXu1C->mvibDOOdADV($BJSZl['mime'], $BJSZl['file_size'], $BJSZl['chunk_size'], $BJSZl['checksums'], $BJSZl['user_id'], $BJSZl['driver']);
        goto aAx2u;
        cVVWJ:
    }
    public function updatePreSignedFile(string $bM41o, int $y312N)
    {
        goto D22Cf;
        D22Cf:
        $oXu1C = D4VgMZN43BF8o::mZrdRG94VR0($bM41o, $this->W9e5K, $this->cEZhz, $this->ErdYm);
        goto anQ6Y;
        a52TZ:
        TxWAj:
        goto Ch0Tq;
        anQ6Y:
        switch ($y312N) {
            case A9q1Lm9l5QixG::UPLOADED:
                $oXu1C->mNfgZ31Jw4I();
                goto TxWAj;
            case A9q1Lm9l5QixG::PROCESSING:
                $oXu1C->mAGlms8OKHG();
                goto TxWAj;
            case A9q1Lm9l5QixG::FINISHED:
                $oXu1C->m7yElLj3XNe();
                goto TxWAj;
            case A9q1Lm9l5QixG::ABORTED:
                $oXu1C->mes5Pm0Gmgd();
                goto TxWAj;
        }
        goto b57Pk;
        b57Pk:
        pkdti:
        goto a52TZ;
        Ch0Tq:
    }
    public function completePreSignedFile(string $bM41o, array $IovhQ)
    {
        goto DpxZG;
        DpxZG:
        $oXu1C = D4VgMZN43BF8o::mZrdRG94VR0($bM41o, $this->W9e5K, $this->cEZhz, $this->ErdYm);
        goto t5ZsU;
        t5ZsU:
        $oXu1C->mlPpDqeRPNC()->mJUDWybeVPc($IovhQ);
        goto LKIDL;
        LKIDL:
        $oXu1C->mNfgZ31Jw4I();
        goto qjsJg;
        qjsJg:
        return ['path' => $oXu1C->getFile()->getView()['path'], 'thumbnail' => $oXu1C->getFile()->Rp1Uk, 'id' => $bM41o];
        goto OdQ6P;
        OdQ6P:
    }
    public function updateFile(string $bM41o, int $y312N) : MxslGSmH9dMgZ
    {
        goto aI9uA;
        aI9uA:
        $k2MU3 = $this->llJyR->mAfT4A17NDR($bM41o);
        goto jb2Pp;
        Gelps:
        return $k2MU3;
        goto zm9hE;
        jb2Pp:
        $k2MU3->ms4OoFrTljH($y312N);
        goto Gelps;
        zm9hE:
    }
}
