<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\HU7bCai77CgrB;
use src\Uploader\Core\UZjgdpyMf06F7;
use src\Uploader\Enum\FileStatus;
use src\Uploader\Exception\BUbHQrtyLH6v0;
use src\Uploader\Exception\Hm3sz2t6t56o2;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Service\TMv85L5ZRTfOP;
final class KqR0KCt0ft284 implements UploadServiceInterface
{
    private $OHqHH;
    private $SiK3b;
    private $TDmz_;
    private $kkVnF;
    public function __construct(TMv85L5ZRTfOP $KNjxJ, Filesystem $eX8wo, Filesystem $RustJ, string $Sl0oM)
    {
        goto y3ZpO;
        AjtqG:
        $this->TDmz_ = $RustJ;
        goto aBeZD;
        y3ZpO:
        $this->OHqHH = $KNjxJ;
        goto QzoHz;
        aBeZD:
        $this->kkVnF = $Sl0oM;
        goto igwSP;
        QzoHz:
        $this->SiK3b = $eX8wo;
        goto AjtqG;
        igwSP:
    }
    public function storeSingleFile(SingleUploadInterface $YofOF) : array
    {
        goto uAAzq;
        bRr9e:
        throw new \LogicException('File upload failed, check permissions');
        goto AvDIk;
        VFAgE:
        if (false !== $fdqWg && $d1aiC instanceof PxmUcH2EZiEWo) {
            goto FHjoV;
        }
        goto bRr9e;
        mRVoZ:
        FHjoV:
        goto McwYR;
        uAAzq:
        $d1aiC = $this->OHqHH->mnYGA0CegVR($YofOF);
        goto iOBxq;
        rp4nJ:
        vOcvO:
        goto aY8IE;
        aY8IE:
        return $d1aiC->getView();
        goto Ula5Q;
        iOBxq:
        $fdqWg = $this->TDmz_->putFileAs(dirname($d1aiC->getLocation()), $YofOF->getFile(), $d1aiC->getFilename() . '.' . $d1aiC->getExtension(), ['visibility' => 'public']);
        goto VFAgE;
        AvDIk:
        goto vOcvO;
        goto mRVoZ;
        McwYR:
        $d1aiC->mIjUnedc3Mq(FileStatus::UPLOADED);
        goto rp4nJ;
        Ula5Q:
    }
    public function storePreSignedFile(array $WKMAP)
    {
        goto sfn5o;
        xd4du:
        $kmQTT->mjSvIMmmptp($WKMAP['mime'], $WKMAP['file_size'], $WKMAP['chunk_size'], $WKMAP['checksums'], $WKMAP['user_id'], $WKMAP['driver']);
        goto iLSrs;
        ae5oc:
        $kmQTT = HU7bCai77CgrB::m6VkC76XUFm($d1aiC, $this->SiK3b, $this->TDmz_, $this->kkVnF, true);
        goto xd4du;
        iLSrs:
        $kmQTT->mzzcnzYtz82();
        goto I5gd8;
        I5gd8:
        return ['filename' => $kmQTT->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $kmQTT->mAjoRKsAUe1()];
        goto gFW20;
        sfn5o:
        $d1aiC = $this->OHqHH->mnYGA0CegVR($WKMAP);
        goto ae5oc;
        gFW20:
    }
    public function updatePreSignedFile(string $CyoXz, int $CpP3T)
    {
        goto YVorP;
        o3NW0:
        switch ($CpP3T) {
            case FileStatus::UPLOADED:
                $kmQTT->meMUPYyDn2z();
                goto Uc_2u;
            case FileStatus::PROCESSING:
                $kmQTT->moiKSY5Wv01();
                goto Uc_2u;
            case FileStatus::FINISHED:
                $kmQTT->mtFuuuTsRfl();
                goto Uc_2u;
            case FileStatus::ABORTED:
                $kmQTT->mfqxR02QQww();
                goto Uc_2u;
        }
        goto lg2H1;
        lg2H1:
        dmJ9u:
        goto L0b0M;
        YVorP:
        $kmQTT = HU7bCai77CgrB::mqJlQQxUtrR($CyoXz, $this->SiK3b, $this->TDmz_, $this->kkVnF);
        goto o3NW0;
        L0b0M:
        Uc_2u:
        goto aWKhF;
        aWKhF:
    }
    public function completePreSignedFile(string $CyoXz, array $qj0o5)
    {
        goto CqGsK;
        Lrol_:
        $kmQTT->mH4ZGE0jflN()->m8MkEEzPals($qj0o5);
        goto baPyc;
        QRBC2:
        return ['path' => $kmQTT->getFile()->getView()['path'], 'thumbnail' => $kmQTT->getFile()->VjYPs, 'id' => $CyoXz];
        goto Vw7i_;
        CqGsK:
        $kmQTT = HU7bCai77CgrB::mqJlQQxUtrR($CyoXz, $this->SiK3b, $this->TDmz_, $this->kkVnF);
        goto Lrol_;
        baPyc:
        $kmQTT->meMUPYyDn2z();
        goto QRBC2;
        Vw7i_:
    }
    public function updateFile(string $CyoXz, int $CpP3T) : UZjgdpyMf06F7
    {
        goto fn3As;
        fn3As:
        $d1aiC = $this->OHqHH->m9EcALACjNK($CyoXz);
        goto ILfnH;
        qtPlL:
        return $d1aiC;
        goto c0CG1;
        ILfnH:
        $d1aiC->mIjUnedc3Mq($CpP3T);
        goto qtPlL;
        c0CG1:
    }
}
