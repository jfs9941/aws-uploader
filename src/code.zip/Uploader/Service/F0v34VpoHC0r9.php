<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class F0v34VpoHC0r9 implements VideoPostHandleServiceInterface
{
    private $LDQds;
    private $VJN91;
    public function __construct(UploadServiceInterface $uxMXB, Filesystem $J83Op)
    {
        $this->LDQds = $uxMXB;
        $this->VJN91 = $J83Op;
    }
    public function saveMetadata(string $wAkkA, array $eSKpN)
    {
        goto E17oR;
        fG1Kz:
        Log::warning("WI5WSPGRr1b2t metadata store failed for unknown reason ... " . $wAkkA);
        goto jdczJ;
        HYF1S:
        $H3P6O['thumbnail'] = $eSKpN['thumbnail_url'];
        goto obVbH;
        E17oR:
        $hgsqV = WI5WSPGRr1b2t::findOrFail($wAkkA);
        goto R5yHg;
        sSwpz:
        if (!isset($eSKpN['thumbnail_url'])) {
            goto kcaWw;
        }
        goto HYF1S;
        J4_XB:
        $H3P6O['duration'] = $eSKpN['duration'];
        goto FS263;
        WQ4Ww:
        xS1qQ:
        goto fG1Kz;
        ieDvc:
        if (!isset($eSKpN['duration'])) {
            goto VtiVL;
        }
        goto J4_XB;
        Gu4iL:
        $H3P6O['resolution'] = $eSKpN['resolution'];
        goto ycrLP;
        Wdq8O:
        if (!$hgsqV->update($H3P6O)) {
            goto xS1qQ;
        }
        goto W1cUN;
        FS263:
        VtiVL:
        goto IdVeg;
        yshRY:
        try {
            goto CL1Ji;
            YOMVO:
            $H3P6O['thumbnail'] = $NHlhh['filename'];
            goto v4Mbr;
            szB1S:
            $H3P6O['thumbnail_id'] = $NHlhh['id'];
            goto YOMVO;
            CL1Ji:
            $NHlhh = $this->LDQds->storeSingleFile(new class($eSKpN['thumbnail']) implements SingleUploadInterface
            {
                private $wM7km;
                public function __construct($K9DZL)
                {
                    $this->wM7km = $K9DZL;
                }
                public function getFile()
                {
                    return $this->wM7km;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto szB1S;
            v4Mbr:
        } catch (\Throwable $X2LoG) {
            Log::warning("WI5WSPGRr1b2t thumbnail store failed: " . $X2LoG->getMessage());
        }
        goto iuzZ9;
        FS3YR:
        $this->LDQds->updateFile($hgsqV->getAttribute('id'), GlPuUJKmzwUJ9::PROCESSING);
        goto CqrSg;
        R5yHg:
        $H3P6O = [];
        goto sSwpz;
        CqrSg:
        vKquz:
        goto uGdWc;
        iuzZ9:
        Ofv6w:
        goto ieDvc;
        jdczJ:
        throw new \Exception("WI5WSPGRr1b2t metadata store failed for unknown reason ... " . $wAkkA);
        goto ynM2s;
        pskwQ:
        if (!isset($eSKpN['fps'])) {
            goto x2O4W;
        }
        goto zEwiO;
        R63tK:
        x2O4W:
        goto mZwLp;
        giAHE:
        unset($H3P6O['thumbnail']);
        goto G4Svl;
        W1cUN:
        if (!(isset($eSKpN['change_status']) && $eSKpN['change_status'])) {
            goto vKquz;
        }
        goto FS3YR;
        IdVeg:
        if (!isset($eSKpN['resolution'])) {
            goto s6vZx;
        }
        goto Gu4iL;
        zEwiO:
        $H3P6O['fps'] = $eSKpN['fps'];
        goto R63tK;
        obVbH:
        kcaWw:
        goto MFkXb;
        mZwLp:
        if (!$hgsqV->rHzhB) {
            goto WeQdo;
        }
        goto giAHE;
        MFkXb:
        if (!isset($eSKpN['thumbnail'])) {
            goto Ofv6w;
        }
        goto yshRY;
        ycrLP:
        s6vZx:
        goto pskwQ;
        G4Svl:
        WeQdo:
        goto Wdq8O;
        uGdWc:
        return $hgsqV->getView();
        goto WQ4Ww;
        ynM2s:
    }
    public function createThumbnail(string $NxCnq) : void
    {
        goto QeP9D;
        xMrBg:
        try {
            goto wbcb4;
            wbcb4:
            $Gi91d = $RDsag->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto EPUmv;
            A0jid:
            $RDsag->sendMessage(['QueueUrl' => $mLTag, 'MessageBody' => json_encode(['file_path' => $hgsqV->getLocation()])]);
            goto noxAZ;
            EPUmv:
            $mLTag = $Gi91d->get('QueueUrl');
            goto A0jid;
            noxAZ:
        } catch (\Throwable $EGnga) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$EGnga->getMessage()}");
        }
        goto qY4Ho;
        fiXCt:
        $hgsqV = WI5WSPGRr1b2t::findOrFail($NxCnq);
        goto oQt9i;
        qY4Ho:
        o6Ke9:
        goto BC1fS;
        QeP9D:
        Log::info("Use Lambda to generate thumbnail for video: " . $NxCnq);
        goto fiXCt;
        nZHBR:
        if (!(!$this->VJN91->directoryExists($Dsu_D) && empty($hgsqV->mrBzZlfZZRk()))) {
            goto o6Ke9;
        }
        goto Pio6R;
        Pio6R:
        $RDsag = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto xMrBg;
        oQt9i:
        $Dsu_D = "v2/hls/thumbnails/{$NxCnq}/";
        goto nZHBR;
        BC1fS:
    }
    public function mbNrvbJpYTL(string $NxCnq) : void
    {
        goto MqScO;
        qGFbC:
        $oxmmX = $this->VJN91->files($Dsu_D);
        goto zRK4g;
        zRK4g:
        if (!(count($oxmmX) === 0)) {
            goto mqHHK;
        }
        goto JJHmj;
        JJHmj:
        Log::error("Message back with success data but not found thumbnail files " . $NxCnq);
        goto YztDL;
        YztDL:
        throw new \Exception("Message back with success data but not found thumbnail files " . $NxCnq);
        goto VPt8z;
        tyLEt:
        $hgsqV->update(['generated_previews' => $Dsu_D]);
        goto QgvwV;
        VPt8z:
        mqHHK:
        goto tyLEt;
        Zcr47:
        if ($this->VJN91->directoryExists($Dsu_D)) {
            goto qLrrU;
        }
        goto VBs6q;
        MqScO:
        $hgsqV = WI5WSPGRr1b2t::findOrFail($NxCnq);
        goto T0W7c;
        T0W7c:
        $Dsu_D = "v2/hls/thumbnails/{$NxCnq}/";
        goto Zcr47;
        HRHrK:
        throw new \Exception("Message back with success data but not found thumbnail " . $NxCnq);
        goto CPZqQ;
        CPZqQ:
        qLrrU:
        goto qGFbC;
        VBs6q:
        Log::error("Message back with success data but not found thumbnail " . $NxCnq);
        goto HRHrK;
        QgvwV:
    }
    public function getThumbnails(string $NxCnq) : array
    {
        $hgsqV = WI5WSPGRr1b2t::findOrFail($NxCnq);
        return $hgsqV->getThumbnails();
    }
    public function getMedia(string $NxCnq) : array
    {
        $G2mX1 = Media::findOrFail($NxCnq);
        return $G2mX1->getView();
    }
}
