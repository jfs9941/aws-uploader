<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
use Illuminate\Contracts\Filesystem\Filesystem;
final class A7wFfsLiK9DEe
{
    private $q34dl;
    private $KXuAS;
    private $j5MRz;
    public function __construct(string $ivxnu, string $lvGX1, Filesystem $nkmCX)
    {
        goto b50hO;
        AgL8B:
        $this->KXuAS = $lvGX1;
        goto GrYCb;
        GrYCb:
        $this->j5MRz = $nkmCX;
        goto kRSDB;
        b50hO:
        $this->q34dl = $ivxnu;
        goto AgL8B;
        kRSDB:
    }
    public function mvsdblwWaRZ(UXdXfw71iQGkx $xlFVb) : string
    {
        goto yNIgr;
        WJ6nw:
        return 's3://' . $this->q34dl . '/' . $xlFVb->getAttribute('filename');
        goto Lsyxz;
        nQGWj:
        return $this->j5MRz->url($xlFVb->getAttribute('filename'));
        goto rUtCx;
        yNIgr:
        if (!(TpPQGsuK0gyw2::S3 == $xlFVb->getAttribute('driver'))) {
            goto wUdmR;
        }
        goto WJ6nw;
        Lsyxz:
        wUdmR:
        goto nQGWj;
        rUtCx:
    }
    public function m3y6OhUxTq5(?string $MaCW5) : ?string
    {
        goto T2Hpg;
        gaJyE:
        return 's3://' . $this->q34dl . '/' . ltrim($lPyJj, '/');
        goto Firwv;
        aYSQk:
        return null;
        goto IWf9f;
        wOIkY:
        So2T9:
        goto aYSQk;
        T01IF:
        $lPyJj = parse_url($MaCW5, PHP_URL_PATH);
        goto gaJyE;
        T2Hpg:
        if (!$MaCW5) {
            goto So2T9;
        }
        goto Qu57T;
        Qu57T:
        if (!HKpMe($MaCW5, $this->q34dl)) {
            goto QXHva;
        }
        goto T01IF;
        Firwv:
        QXHva:
        goto wOIkY;
        IWf9f:
    }
    public function mW4AkQf5njc(string $lPyJj) : string
    {
        return 's3://' . $this->q34dl . '/' . $lPyJj;
    }
}
