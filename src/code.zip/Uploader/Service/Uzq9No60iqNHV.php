<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Core\NvNhGXZYZ9DLW;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
final class Uzq9No60iqNHV implements UKSr4EAd7qrlK
{
    private $qPDC_;
    private $MMRCE;
    public $QzEQx;
    private $PxsYl;
    private $JPZ8u;
    private $Farqu;
    public function __construct($ix_2R, $DcplI, $D8lfC, $tRxIP, $Pg6oB, $MQQLd)
    {
        goto M2pXP;
        bOMRi:
        $this->PxsYl = $tRxIP;
        goto kLmtP;
        M2pXP:
        $this->Farqu = $MQQLd;
        goto DbrbE;
        D8TaG:
        $this->MMRCE = $DcplI;
        goto NzGNq;
        DbrbE:
        $this->qPDC_ = $ix_2R;
        goto D8TaG;
        NzGNq:
        $this->QzEQx = $D8lfC;
        goto bOMRi;
        kLmtP:
        $this->JPZ8u = $Pg6oB;
        goto wJ5Ub;
        wJ5Ub:
    }
    public function resolvePath($wpJD9, $DzFpv = VCKF0xK25vLxq::S3) : string
    {
        goto HmbF4;
        JRyUB:
        sOLL1:
        goto y0e3p;
        paPTG:
        LizvT:
        goto VrpEQ;
        lZVtj:
        return $this->mz0ArSPmKPm($wpJD9);
        goto paPTG;
        VrpEQ:
        if (!$this->qPDC_) {
            goto XSiNK;
        }
        goto gsxUg;
        V_saJ:
        return trim($this->MMRCE, '/') . '/' . $wpJD9;
        goto fdeQ7;
        IEwPO:
        if (!($DzFpv === VCKF0xK25vLxq::LOCAL)) {
            goto sOLL1;
        }
        goto OWjcr;
        PXbDM:
        ftYuE:
        goto IEwPO;
        HmbF4:
        if (!$wpJD9 instanceof HJJu0xs0QACaQ) {
            goto ftYuE;
        }
        goto k_Q6G;
        y0e3p:
        if (!(!empty($this->PxsYl) && !empty($this->JPZ8u))) {
            goto LizvT;
        }
        goto lZVtj;
        OWjcr:
        return route('home') . '/' . $wpJD9;
        goto JRyUB;
        gsxUg:
        return trim($this->QzEQx, '/') . '/' . $wpJD9;
        goto xjkMK;
        k_Q6G:
        $wpJD9 = $wpJD9->getAttribute('filename');
        goto PXbDM;
        xjkMK:
        XSiNK:
        goto V_saJ;
        fdeQ7:
    }
    public function resolveThumbnail(HJJu0xs0QACaQ $wpJD9) : string
    {
        goto RPVRC;
        T6ZJC:
        oczjO:
        goto Xqa1K;
        SYm_x:
        return $this->url($jVS4s, $wpJD9->getAttribute('driver'));
        goto vKWos;
        c6TgO:
        return $this->resolvePath($wpJD9, $wpJD9->getAttribute('driver'));
        goto T6ZJC;
        WkwSq:
        return $this->resolvePath($ukz3O, $ukz3O->getAttribute('driver'));
        goto i9liO;
        pHURE:
        $ukz3O = NBWuSM65HseqY::find($wpJD9->getAttribute('thumbnail_id'));
        goto lDfL8;
        i9liO:
        V6tOF:
        goto AYrBO;
        vKWos:
        TbwqN:
        goto AWnIy;
        mO0qW:
        if (!$jVS4s) {
            goto TbwqN;
        }
        goto SYm_x;
        QR4zg:
        z2V1j:
        goto qxYdX;
        Xqa1K:
        if (!$wpJD9 instanceof NvNhGXZYZ9DLW) {
            goto z2V1j;
        }
        goto Hiuk6;
        N7aor:
        if (!$wpJD9 instanceof NBWuSM65HseqY) {
            goto oczjO;
        }
        goto c6TgO;
        RPVRC:
        $jVS4s = $wpJD9->Et6ec;
        goto mO0qW;
        AWnIy:
        if (!$wpJD9->getAttribute('thumbnail_id')) {
            goto zrmxP;
        }
        goto pHURE;
        qxYdX:
        return '';
        goto btC1h;
        lDfL8:
        if (!$ukz3O) {
            goto V6tOF;
        }
        goto WkwSq;
        Hiuk6:
        return asset('/img/pdf-preview.svg');
        goto QR4zg;
        AYrBO:
        zrmxP:
        goto N7aor;
        btC1h:
    }
    private function url($Y7TgX, $DzFpv)
    {
        goto zrTLz;
        uwMwr:
        return route('home') . '/' . $Y7TgX;
        goto w1OvD;
        zrTLz:
        if (!($DzFpv == VCKF0xK25vLxq::LOCAL)) {
            goto SMEaK;
        }
        goto uwMwr;
        kEGAj:
        return $this->resolvePath($Y7TgX);
        goto oJRq3;
        w1OvD:
        SMEaK:
        goto kEGAj;
        oJRq3:
    }
    private function mz0ArSPmKPm($Y7TgX)
    {
        goto mLPU2;
        mLPU2:
        if (!(strpos($Y7TgX, 'https://') === 0)) {
            goto SbWi_;
        }
        goto UbcPC;
        UbcPC:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto ixspJ;
        PIMoS:
        return $hthFm->getSignedUrl($this->QzEQx . '/' . $Y7TgX, $jUf0y);
        goto GJrMO;
        ACdar:
        fBlx5:
        goto FWJoU;
        FWJoU:
        $jUf0y = now()->addMinutes(60)->timestamp;
        goto zaeMB;
        ixspJ:
        SbWi_:
        goto hmxh0;
        zaeMB:
        $hthFm = new UrlSigner($this->PxsYl, $this->Farqu->path($this->JPZ8u));
        goto PIMoS;
        bxIHH:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto ACdar;
        hmxh0:
        if (!(strpos($Y7TgX, 'm3u8') !== false)) {
            goto fBlx5;
        }
        goto bxIHH;
        GJrMO:
    }
    public function resolvePathForHlsVideo(S25BfMDKrX8cB $DuZ1o, $Xl3ZR = false) : string
    {
        goto ew2b_;
        Wes7F:
        return $this->QzEQx . '/' . $DuZ1o->yOGE3;
        goto KY28w;
        ew2b_:
        if ($DuZ1o->yOGE3) {
            goto irEmD;
        }
        goto WZ36g;
        d0aIw:
        irEmD:
        goto Wes7F;
        WZ36g:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto d0aIw;
        KY28w:
    }
    public function resolvePathForHlsVideos()
    {
        goto OUpy0;
        EuaLT:
        $B53yw = json_encode(['Statement' => [['Resource' => sprintf('%s*', $sk_l3), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $jUf0y]]]]]);
        goto MBAM0;
        j7EUl:
        $sk_l3 = $this->QzEQx . '/v2/hls/';
        goto EuaLT;
        pmbjL:
        $ytzpt = $N6n_V->getSignedCookie(['key_pair_id' => $this->PxsYl, 'private_key' => $this->Farqu->path($this->JPZ8u), 'policy' => $B53yw]);
        goto Qon7D;
        Qon7D:
        return [$ytzpt, $jUf0y];
        goto qkNMh;
        MBAM0:
        $N6n_V = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto pmbjL;
        OUpy0:
        $jUf0y = now()->addDays(3)->timestamp;
        goto j7EUl;
        qkNMh:
    }
}
