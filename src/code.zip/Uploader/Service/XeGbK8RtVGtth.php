<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Core\JUuiYtFOGewFF;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
final class XeGbK8RtVGtth implements LlbXoUBShkgwJ
{
    private $uTjk3;
    private $suAl0;
    public $TUcxr;
    private $Pzxh0;
    private $Ez5lv;
    private $ERIyl;
    public function __construct($UpGl2, $iMAc6, $akjEk, $BN5Ox, $WmKNR, $nL6dR)
    {
        goto KK_lo;
        So8Aa:
        $this->suAl0 = $iMAc6;
        goto U222K;
        M1Me1:
        $this->Pzxh0 = $BN5Ox;
        goto Y9N_6;
        KK_lo:
        $this->ERIyl = $nL6dR;
        goto rdDbP;
        U222K:
        $this->TUcxr = $akjEk;
        goto M1Me1;
        Y9N_6:
        $this->Ez5lv = $WmKNR;
        goto Dr7PP;
        rdDbP:
        $this->uTjk3 = $UpGl2;
        goto So8Aa;
        Dr7PP:
    }
    public function resolvePath($p2x5d, $PAfML = I2Tze5VZcqaXS::S3) : string
    {
        goto zcq6H;
        Jnm3W:
        return trim($this->suAl0, '/') . '/' . $p2x5d;
        goto vJZqo;
        zoqrF:
        Qw2db:
        goto K8ogn;
        vLKRK:
        p9_hB:
        goto Jnm3W;
        Agn9x:
        return trim($this->TUcxr, '/') . '/' . $p2x5d;
        goto vLKRK;
        NEBI8:
        $p2x5d = $p2x5d->getAttribute('filename');
        goto mPCl_;
        zcq6H:
        if (!$p2x5d instanceof MXbLxov2QPqm4) {
            goto TzxKf;
        }
        goto NEBI8;
        IlCcJ:
        if (!(!empty($this->Pzxh0) && !empty($this->Ez5lv))) {
            goto Qw2db;
        }
        goto VfArX;
        WBstO:
        if (!($PAfML === I2Tze5VZcqaXS::LOCAL)) {
            goto VHfNm;
        }
        goto xC98L;
        NzOWp:
        VHfNm:
        goto IlCcJ;
        mPCl_:
        TzxKf:
        goto WBstO;
        xC98L:
        return route('home') . '/' . $p2x5d;
        goto NzOWp;
        K8ogn:
        if (!$this->uTjk3) {
            goto p9_hB;
        }
        goto Agn9x;
        VfArX:
        return $this->mFAWBKjaYIF($p2x5d);
        goto zoqrF;
        vJZqo:
    }
    public function resolveThumbnail(MXbLxov2QPqm4 $p2x5d) : string
    {
        goto VUgJ0;
        B6isa:
        return $this->resolvePath($zDRHf, $zDRHf->getAttribute('driver'));
        goto Zcgzr;
        IJTww:
        if (!$p2x5d->getAttribute('thumbnail_id')) {
            goto DYjMu;
        }
        goto lmHh4;
        LFTcg:
        return $this->resolvePath($p2x5d, $p2x5d->getAttribute('driver'));
        goto PLC5E;
        ZKMvg:
        DYjMu:
        goto b5teR;
        bO5nF:
        aiojt:
        goto IJTww;
        SWQIR:
        UxMps:
        goto SsjOX;
        AeJrx:
        return $this->url($I_Zk6, $p2x5d->getAttribute('driver'));
        goto bO5nF;
        b5teR:
        if (!$p2x5d instanceof WKX0l52zWptlF) {
            goto p_Due;
        }
        goto LFTcg;
        Zcgzr:
        bpYxm:
        goto ZKMvg;
        SsjOX:
        return '';
        goto fyktf;
        df9_O:
        if (!$p2x5d instanceof JUuiYtFOGewFF) {
            goto UxMps;
        }
        goto Xz8tS;
        D_SKY:
        if (!$zDRHf) {
            goto bpYxm;
        }
        goto B6isa;
        Xz8tS:
        return asset('/img/pdf-preview.svg');
        goto SWQIR;
        VUgJ0:
        $I_Zk6 = $p2x5d->pxIiA;
        goto cVB5d;
        PLC5E:
        p_Due:
        goto df9_O;
        cVB5d:
        if (!$I_Zk6) {
            goto aiojt;
        }
        goto AeJrx;
        lmHh4:
        $zDRHf = WKX0l52zWptlF::find($p2x5d->getAttribute('thumbnail_id'));
        goto D_SKY;
        fyktf:
    }
    private function url($lmCO9, $PAfML)
    {
        goto x5TIG;
        Uz0k3:
        return route('home') . '/' . $lmCO9;
        goto rAwxF;
        rAwxF:
        RPO5_:
        goto TLZzk;
        TLZzk:
        return $this->resolvePath($lmCO9);
        goto BmDJq;
        x5TIG:
        if (!($PAfML == I2Tze5VZcqaXS::LOCAL)) {
            goto RPO5_;
        }
        goto Uz0k3;
        BmDJq:
    }
    private function mFAWBKjaYIF($lmCO9)
    {
        goto zqkFb;
        Vm8_Z:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto CTKq_;
        wGYA1:
        if (!(strpos($lmCO9, 'm3u8') !== false)) {
            goto UOFAk;
        }
        goto Vm8_Z;
        CTKq_:
        UOFAk:
        goto I1nnZ;
        XMV2z:
        TZnV4:
        goto wGYA1;
        zqkFb:
        if (!(strpos($lmCO9, 'https://') === 0)) {
            goto TZnV4;
        }
        goto ng5bH;
        I1nnZ:
        $GuF2N = now()->addMinutes(60)->timestamp;
        goto cWMJ_;
        cWMJ_:
        $nCtyw = new UrlSigner($this->Pzxh0, $this->ERIyl->path($this->Ez5lv));
        goto VJTDq;
        VJTDq:
        return $nCtyw->getSignedUrl($this->TUcxr . '/' . $lmCO9, $GuF2N);
        goto vg_ZF;
        ng5bH:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto XMV2z;
        vg_ZF:
    }
    public function resolvePathForHlsVideo(UMeQT1ArE1U05 $eYbzj, $Yid4s = false) : string
    {
        goto h4P3V;
        cWU97:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto sCO9V;
        h4P3V:
        if ($eYbzj->L0dyI) {
            goto p_o5n;
        }
        goto cWU97;
        sCO9V:
        p_o5n:
        goto yRKqf;
        yRKqf:
        return $this->TUcxr . '/' . $eYbzj->L0dyI;
        goto w3C8q;
        w3C8q:
    }
    public function resolvePathForHlsVideos()
    {
        goto cpJ4e;
        q9H9C:
        $zprY9 = $JRllY->getSignedCookie(['key_pair_id' => $this->Pzxh0, 'private_key' => $this->ERIyl->path($this->Ez5lv), 'policy' => $cJKM8]);
        goto eGvdi;
        GomY4:
        $dsLED = $this->TUcxr . '/v2/hls/';
        goto Aohtq;
        eGvdi:
        return [$zprY9, $GuF2N];
        goto PFS9z;
        Aohtq:
        $cJKM8 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $dsLED), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $GuF2N]]]]]);
        goto F0aWD;
        F0aWD:
        $JRllY = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto q9H9C;
        cpJ4e:
        $GuF2N = now()->addDays(3)->timestamp;
        goto GomY4;
        PFS9z:
    }
}
