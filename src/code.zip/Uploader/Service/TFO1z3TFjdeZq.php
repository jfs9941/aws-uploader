<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Core\Observer\Q8yWq8yZ2btxz;
use Jfs\Uploader\Core\Observer\UbyVbTevhbBtv;
use Jfs\Uploader\Core\UpreKuqs00udz;
use Jfs\Uploader\Core\Icfhroj1Rrrzn;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Exception\WWU79WdJSmf1K;
use Jfs\Uploader\Service\FileResolver\DQhGn0SNJLxYb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class TFO1z3TFjdeZq
{
    private $TZJ0I;
    private $niO3l;
    private $VV2A8;
    public function __construct($TOKVA, $xuow1, $oOPBt)
    {
        goto F_3Az;
        eRlQw:
        $this->niO3l = $xuow1;
        goto lmE3h;
        lmE3h:
        $this->VV2A8 = $oOPBt;
        goto bkiQZ;
        F_3Az:
        $this->TZJ0I = $TOKVA;
        goto eRlQw;
        bkiQZ:
    }
    public function mkZ600365Ts($IIGMq)
    {
        goto CgMvz;
        cpnFg:
        return $this->mXTAMhJrwLq($B4OJM->extension(), GoWVLKcTGnffy::S3, null, $IIGMq->options());
        goto Mqo6g;
        Mqo6g:
        h1Jjb:
        goto SgYoq;
        SgYoq:
        return $this->mXTAMhJrwLq($IIGMq['file_extension'], 's3' === $IIGMq['driver'] ? GoWVLKcTGnffy::S3 : GoWVLKcTGnffy::LOCAL);
        goto tMmQ4;
        G6Ehw:
        $B4OJM = $IIGMq->getFile();
        goto cpnFg;
        CgMvz:
        if (!$IIGMq instanceof SingleUploadInterface) {
            goto h1Jjb;
        }
        goto G6Ehw;
        tMmQ4:
    }
    public function mIY1MPztZJp(string $GhyxD)
    {
        goto p8X3F;
        Mzhpl:
        return $spSJx;
        goto qPXx3;
        xqxul:
        $spSJx->setRawAttributes($VSIgF->getAttributes());
        goto Mzhpl;
        g0Gs5:
        $spSJx->exists = true;
        goto xqxul;
        p8X3F:
        $VSIgF = config('upload.attachment_model')::findOrFail($GhyxD);
        goto NzWV7;
        NzWV7:
        $spSJx = $this->mXTAMhJrwLq($VSIgF->getAttribute('type'), $VSIgF->getAttribute('driver'), $VSIgF->getAttribute('id'));
        goto g0Gs5;
        qPXx3:
    }
    public function mW8OyAsEfnb(string $y_eaT) : CxOTyXYpS0zWZ
    {
        goto JBQJy;
        P7Oi7:
        $ZTJaQ = json_decode($XFfiT, true);
        goto Y3xWY;
        xxky2:
        $XFfiT = $this->VV2A8->get($y_eaT);
        goto eA1Bk;
        eA1Bk:
        O0kqw:
        goto P7Oi7;
        Y3xWY:
        if (!$ZTJaQ) {
            goto I_h8q;
        }
        goto Nn68D;
        Bxyip:
        throw new QBvwqKevOagSc('metadata file not found');
        goto Met8F;
        JBQJy:
        $XFfiT = $this->niO3l->get($y_eaT);
        goto xIFBn;
        Nn68D:
        $UfcrH = Icfhroj1Rrrzn::msP2FJQJ6fD($ZTJaQ);
        goto ltWL0;
        Ro7xi:
        I_h8q:
        goto Bxyip;
        ltWL0:
        return $this->mXTAMhJrwLq($UfcrH->bga3I, $UfcrH->mpIm2o8nKEH(), $UfcrH->filename);
        goto Ro7xi;
        xIFBn:
        if ($XFfiT) {
            goto O0kqw;
        }
        goto xxky2;
        Met8F:
    }
    private function mXTAMhJrwLq(string $Q7FgY, $ZZKBI, ?string $GhyxD = null, array $KF9cQ = [])
    {
        goto WQGqO;
        Qkv_c:
        throw new WWU79WdJSmf1K("not support file type {$Q7FgY}");
        goto P9aWX;
        KJaWp:
        switch ($Q7FgY) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $WmWtw = IZ5shp3JHuftD::createFromScratch($GhyxD, $Q7FgY);
                goto yC6eQ;
            case 'mp4':
            case 'mov':
                $WmWtw = VHp3UACVYl357::createFromScratch($GhyxD, $Q7FgY);
                goto yC6eQ;
            case 'pdf':
                $WmWtw = UpreKuqs00udz::createFromScratch($GhyxD, $Q7FgY);
                goto yC6eQ;
            default:
                throw new WWU79WdJSmf1K("not support file type {$Q7FgY}");
        }
        goto mr8dP;
        XvNUt:
        $WmWtw->m4PcztHRQdJ(new Q8yWq8yZ2btxz($WmWtw));
        goto wZN17;
        g_ZAD:
        $WmWtw = $WmWtw->meqa5efkEcT($ZZKBI);
        goto XvNUt;
        KEn2g:
        yC6eQ:
        goto g_ZAD;
        WQGqO:
        $GhyxD = $GhyxD ?? Uuid::uuid4()->getHex()->toString();
        goto KJaWp;
        mr8dP:
        Pfr8a:
        goto KEn2g;
        wZN17:
        $WmWtw->m4PcztHRQdJ(new UbyVbTevhbBtv($WmWtw, $this->VV2A8, $KF9cQ));
        goto WTrY7;
        WTrY7:
        foreach ($this->TZJ0I as $moIQT) {
            goto rjDDb;
            wo96n:
            ZWp1h:
            goto sN9O3;
            dCK7_:
            return $WmWtw->initLocation($moIQT->m82tJsXuL8g($WmWtw));
            goto HfMWM;
            HfMWM:
            CFBr7:
            goto wo96n;
            rjDDb:
            if (!$moIQT->mZvoYrXcyva($WmWtw)) {
                goto CFBr7;
            }
            goto dCK7_;
            sN9O3:
        }
        goto vLesD;
        vLesD:
        Uf5K9:
        goto Qkv_c;
        P9aWX:
    }
}
