<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Ramsey\Uuid\Uuid;
use src\Uploader\Contracts\PxmUcH2EZiEWo;
use src\Uploader\Core\GoopVn9iYwlO0;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\Observer\B4X2uxI8Q50V1;
use src\Uploader\Core\Observer\Ec1EcOLRoz2Si;
use src\Uploader\Core\ON6DdH7AqGsXP;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileDriver;
use src\Uploader\Exception\Hm3sz2t6t56o2;
use src\Uploader\Exception\LFqKVWobEBTVI;
use src\Uploader\Service\FileResolver\XTKfH8zm66SCQ;
final class TMv85L5ZRTfOP
{
    private $XmXJh;
    private $SiK3b;
    private $Aj6QZ;
    public function __construct($OKKTh, $eX8wo, $SaekO)
    {
        goto ErASC;
        ErASC:
        $this->XmXJh = $OKKTh;
        goto esmul;
        esmul:
        $this->SiK3b = $eX8wo;
        goto R9cZJ;
        R9cZJ:
        $this->Aj6QZ = $SaekO;
        goto dPG9Y;
        dPG9Y:
    }
    public function mnYGA0CegVR($oSO2Q)
    {
        goto j7eg5;
        K2o07:
        $b3Ce2 = $oSO2Q->getFile();
        goto ocqF2;
        ocqF2:
        return $this->mwxGoEgEwwQ($b3Ce2->extension(), FileDriver::S3, null, $oSO2Q->options());
        goto kbiwJ;
        kbiwJ:
        CfmdU:
        goto X5Bii;
        X5Bii:
        return $this->mwxGoEgEwwQ($oSO2Q['file_extension'], 's3' === $oSO2Q['driver'] ? FileDriver::S3 : FileDriver::LOCAL);
        goto xwLtd;
        j7eg5:
        if (!$oSO2Q instanceof SingleUploadInterface) {
            goto CfmdU;
        }
        goto K2o07;
        xwLtd:
    }
    public function m9EcALACjNK(string $BFPg9)
    {
        goto zwXjP;
        INt3p:
        return $d1aiC;
        goto YqXW8;
        luVhl:
        $d1aiC->exists = true;
        goto YjdsQ;
        YjdsQ:
        $d1aiC->setRawAttributes($BUvH7->getAttributes());
        goto INt3p;
        Qs5ER:
        $d1aiC = $this->mwxGoEgEwwQ($BUvH7->getAttribute('type'), $BUvH7->getAttribute('driver'), $BUvH7->getAttribute('id'));
        goto luVhl;
        zwXjP:
        $BUvH7 = config('upload.attachment_model')::findOrFail($BFPg9);
        goto Qs5ER;
        YqXW8:
    }
    public function mn1IICjO3Jz(string $ZnBMd) : PxmUcH2EZiEWo
    {
        goto HQamf;
        GdhVD:
        return $this->mwxGoEgEwwQ($poGIg->VkTLD, $poGIg->mbO4gUDBrKb(), $poGIg->filename);
        goto IfNRB;
        cGkrw:
        $poGIg = ON6DdH7AqGsXP::myKxYsIh7WE($rEWu2);
        goto GdhVD;
        zz8mg:
        $rEWu2 = json_decode($IvSDD, true);
        goto oxK5U;
        HQamf:
        $IvSDD = $this->SiK3b->get($ZnBMd);
        goto ulvyr;
        w0SZa:
        qbKeJ:
        goto zz8mg;
        KwP7r:
        $IvSDD = $this->Aj6QZ->get($ZnBMd);
        goto w0SZa;
        sCXca:
        throw new LFqKVWobEBTVI('metadata file not found');
        goto N6Bts;
        IfNRB:
        vIDpn:
        goto sCXca;
        ulvyr:
        if ($IvSDD) {
            goto qbKeJ;
        }
        goto KwP7r;
        oxK5U:
        if (!$rEWu2) {
            goto vIDpn;
        }
        goto cGkrw;
        N6Bts:
    }
    private function mwxGoEgEwwQ(string $JhwC_, $DBkPx, ?string $BFPg9 = null, array $VtGhn = [])
    {
        goto jOiaJ;
        hHpDq:
        s7snt:
        goto QDGyV;
        jOiaJ:
        $BFPg9 = $BFPg9 ?? Uuid::uuid4()->getHex()->toString();
        goto tJFfT;
        tJFfT:
        switch ($JhwC_) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $YB0MO = ID6EZw1DKfqu4::createFromScratch($BFPg9, $JhwC_);
                goto kGNiN;
            case 'mp4':
            case 'mov':
                $YB0MO = YdClVYDRbSDMR::createFromScratch($BFPg9, $JhwC_);
                goto kGNiN;
            case 'pdf':
                $YB0MO = GoopVn9iYwlO0::createFromScratch($BFPg9, $JhwC_);
                goto kGNiN;
            default:
                throw new Hm3sz2t6t56o2("not support file type {$JhwC_}");
        }
        goto WL3Oa;
        vFn5y:
        $YB0MO->mLnW7ZmkfSj(new Ec1EcOLRoz2Si($YB0MO, $this->Aj6QZ, $VtGhn));
        goto kDEk_;
        dS9og:
        kGNiN:
        goto PWpn3;
        PWpn3:
        $YB0MO = $YB0MO->mPBkxSSbGYK($DBkPx);
        goto qMioz;
        WL3Oa:
        qUG3q:
        goto dS9og;
        QDGyV:
        throw new Hm3sz2t6t56o2("not support file type {$JhwC_}");
        goto fGcoH;
        qMioz:
        $YB0MO->mLnW7ZmkfSj(new B4X2uxI8Q50V1($YB0MO));
        goto vFn5y;
        kDEk_:
        foreach ($this->XmXJh as $YotoQ) {
            goto VjgRi;
            oBA7o:
            dEVku:
            goto k9YRw;
            k9YRw:
            DmOKr:
            goto cuRzh;
            w0g2c:
            return $YB0MO->initLocation($YotoQ->mwKoOSwhjuo($YB0MO));
            goto oBA7o;
            VjgRi:
            if (!$YotoQ->mr4oEpfz1tt($YB0MO)) {
                goto dEVku;
            }
            goto w0g2c;
            cuRzh:
        }
        goto hHpDq;
        fGcoH:
    }
}
