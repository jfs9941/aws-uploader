<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
final class NzkrkFhIBihmO
{
    private $ZCKne;
    private $mPdFF;
    private $OKvrN;
    public function __construct(string $mJZ7g, string $WRHRT, Filesystem $GiTtn)
    {
        goto zS1Qf;
        OfDio:
        $this->mPdFF = $WRHRT;
        goto JRWlj;
        JRWlj:
        $this->OKvrN = $GiTtn;
        goto TWHPv;
        zS1Qf:
        $this->ZCKne = $mJZ7g;
        goto OfDio;
        TWHPv:
    }
    public function mDr1EOCIFyv(HJJu0xs0QACaQ $MgH4F) : string
    {
        goto Ugz0U;
        Ugz0U:
        if (!(VCKF0xK25vLxq::S3 == $MgH4F->getAttribute('driver'))) {
            goto xBxat;
        }
        goto y3ijb;
        GMI4T:
        xBxat:
        goto cR1vn;
        cR1vn:
        return $this->OKvrN->url($MgH4F->getAttribute('filename'));
        goto CddIG;
        y3ijb:
        return 's3://' . $this->ZCKne . '/' . $MgH4F->getAttribute('filename');
        goto GMI4T;
        CddIG:
    }
    public function mPPnQnRyeLv(?string $JjMYw) : ?string
    {
        goto xrt_j;
        spdBK:
        return null;
        goto B1v6c;
        IIWYM:
        if (!LMtV6($JjMYw, $this->ZCKne)) {
            goto obhww;
        }
        goto BD8Ea;
        BD8Ea:
        $Y7TgX = parse_url($JjMYw, PHP_URL_PATH);
        goto CSEj8;
        C8ezI:
        et5sf:
        goto spdBK;
        CSEj8:
        return 's3://' . $this->ZCKne . '/' . ltrim($Y7TgX, '/');
        goto bAf6T;
        bAf6T:
        obhww:
        goto C8ezI;
        xrt_j:
        if (!$JjMYw) {
            goto et5sf;
        }
        goto IIWYM;
        B1v6c:
    }
    public function mam0y8xjZWF(string $Y7TgX) : string
    {
        return 's3://' . $this->ZCKne . '/' . $Y7TgX;
    }
}
