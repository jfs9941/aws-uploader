<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Core\M0ises9bx8zn4;
use Jfs\Uploader\Core\IQDEtKorMDqYa;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Jfs\Uploader\Exception\GpiFZublserD8;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Exception\WhP3OD3EOngaS;
use Jfs\Uploader\Service\I399kYrV05irP;
use Illuminate\Contracts\Filesystem\Filesystem;
final class RNb2RMbrRcSVj implements UploadServiceInterface
{
    private $te8Yg;
    private $iAAqk;
    private $PrHIa;
    private $Vmfm5;
    public function __construct(I399kYrV05irP $QnkO4, Filesystem $YNIuu, Filesystem $NP1kd, string $EpJi8)
    {
        goto Cj4Vw;
        aRru3:
        $this->iAAqk = $YNIuu;
        goto aF4pT;
        Cj4Vw:
        $this->te8Yg = $QnkO4;
        goto aRru3;
        Ce2D9:
        $this->Vmfm5 = $EpJi8;
        goto NLwll;
        aF4pT:
        $this->PrHIa = $NP1kd;
        goto Ce2D9;
        NLwll:
    }
    public function storeSingleFile(SingleUploadInterface $h5XRn) : array
    {
        goto NH8fT;
        NH8fT:
        $cNpq7 = $this->te8Yg->m47tVQzeONq($h5XRn);
        goto D1YWd;
        fL0y_:
        ykD6c:
        goto fkdSP;
        Vmlcy:
        if (false !== $cJV8L && $cNpq7 instanceof Dsl7Uurv4XRG0) {
            goto ykD6c;
        }
        goto uS6tC;
        OGAz4:
        goto atTRe;
        goto fL0y_;
        D1YWd:
        $cJV8L = $this->PrHIa->putFileAs(dirname($cNpq7->getLocation()), $h5XRn->getFile(), $cNpq7->getFilename() . '.' . $cNpq7->getExtension(), ['visibility' => 'public']);
        goto Vmlcy;
        MBOsO:
        return $cNpq7->getView();
        goto GltuO;
        ZcjnW:
        atTRe:
        goto MBOsO;
        uS6tC:
        throw new \LogicException('File upload failed, check permissions');
        goto OGAz4;
        fkdSP:
        $cNpq7->muggTul6CGA(FmSSI1JLQCp0W::UPLOADED);
        goto ZcjnW;
        GltuO:
    }
    public function storePreSignedFile(array $dD1d_)
    {
        goto E36ZQ;
        iurf3:
        $r4uPF->mVDPno93DCr();
        goto Qx3Nw;
        E36ZQ:
        $cNpq7 = $this->te8Yg->m47tVQzeONq($dD1d_);
        goto rDqIH;
        Qx3Nw:
        return ['filename' => $r4uPF->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $r4uPF->mdhEWtQ1WBe()];
        goto Okpje;
        rDqIH:
        $r4uPF = IQDEtKorMDqYa::mVVyjmMk9BR($cNpq7, $this->iAAqk, $this->PrHIa, $this->Vmfm5, true);
        goto nAfdl;
        nAfdl:
        $r4uPF->m56tQT9akP6($dD1d_['mime'], $dD1d_['file_size'], $dD1d_['chunk_size'], $dD1d_['checksums'], $dD1d_['user_id'], $dD1d_['driver']);
        goto iurf3;
        Okpje:
    }
    public function updatePreSignedFile(string $tN0Hb, int $dgRV_)
    {
        goto tuB0U;
        it4Vn:
        JtKXH:
        goto ntRnM;
        z1Wh6:
        switch ($dgRV_) {
            case FmSSI1JLQCp0W::UPLOADED:
                $r4uPF->mGgqz89H6Ay();
                goto JtKXH;
            case FmSSI1JLQCp0W::PROCESSING:
                $r4uPF->mSYXQYiCPVo();
                goto JtKXH;
            case FmSSI1JLQCp0W::FINISHED:
                $r4uPF->mu1B247a8LX();
                goto JtKXH;
            case FmSSI1JLQCp0W::ABORTED:
                $r4uPF->mIacc5D3d9X();
                goto JtKXH;
        }
        goto jEXc4;
        jEXc4:
        Iwddr:
        goto it4Vn;
        tuB0U:
        $r4uPF = IQDEtKorMDqYa::mEtjWMS7bRc($tN0Hb, $this->iAAqk, $this->PrHIa, $this->Vmfm5);
        goto z1Wh6;
        ntRnM:
    }
    public function completePreSignedFile(string $tN0Hb, array $FvGiZ)
    {
        goto xdibA;
        zmHa0:
        $r4uPF->mGgqz89H6Ay();
        goto KXHtF;
        xdibA:
        $r4uPF = IQDEtKorMDqYa::mEtjWMS7bRc($tN0Hb, $this->iAAqk, $this->PrHIa, $this->Vmfm5);
        goto Hl5a7;
        KXHtF:
        return ['path' => $r4uPF->getFile()->getView()['path'], 'thumbnail' => $r4uPF->getFile()->bYlO6, 'id' => $tN0Hb];
        goto FNq1u;
        Hl5a7:
        $r4uPF->mIrarJhaP0j()->mxgcnkdEArR($FvGiZ);
        goto zmHa0;
        FNq1u:
    }
    public function updateFile(string $tN0Hb, int $dgRV_) : M0ises9bx8zn4
    {
        goto Sa4gc;
        Sa4gc:
        $cNpq7 = $this->te8Yg->mzxf0TVLumi($tN0Hb);
        goto vSyo4;
        IPy2J:
        return $cNpq7;
        goto m92DE;
        vSyo4:
        $cNpq7->muggTul6CGA($dgRV_);
        goto IPy2J;
        m92DE:
    }
}
