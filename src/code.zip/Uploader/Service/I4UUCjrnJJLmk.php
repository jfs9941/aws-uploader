<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class I4UUCjrnJJLmk implements VideoPostHandleServiceInterface
{
    private $LjUI0;
    private $YHwpp;
    public function __construct(UploadServiceInterface $v1_h2, Filesystem $ehLvI)
    {
        $this->LjUI0 = $v1_h2;
        $this->YHwpp = $ehLvI;
    }
    public function saveMetadata(string $ShXx2, array $Zqaxi)
    {
        goto OCq9G;
        IN1YF:
        if (!isset($Zqaxi['duration'])) {
            goto CVuBz;
        }
        goto WnKPY;
        IhPQv:
        KbDkG:
        goto o8Bf8;
        uJYF5:
        if (!isset($Zqaxi['fps'])) {
            goto bDCyU;
        }
        goto MP7AB;
        E2TyY:
        unset($unZFV['thumbnail']);
        goto Ga28z;
        fWNK0:
        Q80Qb:
        goto IN1YF;
        EjPnw:
        if (!(isset($Zqaxi['change_status']) && $Zqaxi['change_status'])) {
            goto rt7OX;
        }
        goto tiAUt;
        MP7AB:
        $unZFV['fps'] = $Zqaxi['fps'];
        goto Zzcs8;
        PbU8f:
        $unZFV['thumbnail'] = $Zqaxi['thumbnail_url'];
        goto IhPQv;
        Hs5QD:
        $unZFV = [];
        goto n3uvj;
        OCq9G:
        $uA7Bz = D6fOq8lm3n7T2::findOrFail($ShXx2);
        goto Hs5QD;
        Mho1S:
        CVuBz:
        goto lhNEP;
        YcWlp:
        e31rv:
        goto BYBaS;
        Lxcb9:
        throw new \Exception("D6fOq8lm3n7T2 metadata store failed for unknown reason ... " . $ShXx2);
        goto vyiHl;
        ckkUA:
        return $uA7Bz->getView();
        goto YcWlp;
        VYZP_:
        $unZFV['resolution'] = $Zqaxi['resolution'];
        goto UJ9fc;
        BYBaS:
        Log::warning("D6fOq8lm3n7T2 metadata store failed for unknown reason ... " . $ShXx2);
        goto Lxcb9;
        Ga28z:
        ow0JW:
        goto gYP_a;
        i365i:
        if (!$uA7Bz->k7emd) {
            goto ow0JW;
        }
        goto E2TyY;
        o8Bf8:
        if (!isset($Zqaxi['thumbnail'])) {
            goto Q80Qb;
        }
        goto mQXrw;
        Zzcs8:
        bDCyU:
        goto i365i;
        UJ9fc:
        n5mTm:
        goto uJYF5;
        nDT5N:
        rt7OX:
        goto ckkUA;
        mQXrw:
        try {
            goto mTx6A;
            RBZqR:
            $unZFV['thumbnail_id'] = $weLf2['id'];
            goto Dfk7G;
            mTx6A:
            $weLf2 = $this->LjUI0->storeSingleFile(new class($Zqaxi['thumbnail']) implements SingleUploadInterface
            {
                private $N1jgO;
                public function __construct($Ga9Xm)
                {
                    $this->N1jgO = $Ga9Xm;
                }
                public function getFile()
                {
                    return $this->N1jgO;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto RBZqR;
            Dfk7G:
            $unZFV['thumbnail'] = $weLf2['filename'];
            goto dGFTq;
            dGFTq:
        } catch (\Throwable $kE48F) {
            Log::warning("D6fOq8lm3n7T2 thumbnail store failed: " . $kE48F->getMessage());
        }
        goto fWNK0;
        tiAUt:
        $this->LjUI0->updateFile($uA7Bz->getAttribute('id'), HGmeWpZQSxAlO::PROCESSING);
        goto nDT5N;
        gYP_a:
        if (!$uA7Bz->update($unZFV)) {
            goto e31rv;
        }
        goto EjPnw;
        n3uvj:
        if (!isset($Zqaxi['thumbnail_url'])) {
            goto KbDkG;
        }
        goto PbU8f;
        lhNEP:
        if (!isset($Zqaxi['resolution'])) {
            goto n5mTm;
        }
        goto VYZP_;
        WnKPY:
        $unZFV['duration'] = $Zqaxi['duration'];
        goto Mho1S;
        vyiHl:
    }
    public function createThumbnail(string $jFW_i) : void
    {
        goto ibAd1;
        x0maA:
        $WlrB2 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto Kr42d;
        Kr42d:
        try {
            goto jfn3L;
            jfn3L:
            $gI6cP = $WlrB2->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto Qof5p;
            z20G8:
            $WlrB2->sendMessage(['QueueUrl' => $zjFo2, 'MessageBody' => json_encode(['file_path' => $uA7Bz->getLocation()])]);
            goto TAEtH;
            Qof5p:
            $zjFo2 = $gI6cP->get('QueueUrl');
            goto z20G8;
            TAEtH:
        } catch (\Throwable $KY3Rq) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$KY3Rq->getMessage()}");
        }
        goto sashp;
        Y1EIw:
        if (!(!$this->YHwpp->directoryExists($F78UR) && empty($uA7Bz->mo7s2mpNg8m()))) {
            goto S0fpb;
        }
        goto x0maA;
        sashp:
        S0fpb:
        goto MX2uZ;
        ISFHG:
        $uA7Bz = D6fOq8lm3n7T2::findOrFail($jFW_i);
        goto MZGw_;
        MZGw_:
        $F78UR = "v2/hls/thumbnails/{$jFW_i}/";
        goto Y1EIw;
        ibAd1:
        Log::info("Use Lambda to generate thumbnail for video: " . $jFW_i);
        goto ISFHG;
        MX2uZ:
    }
    public function mLMVJnYU4UZ(string $jFW_i) : void
    {
        goto JCchl;
        JCchl:
        $uA7Bz = D6fOq8lm3n7T2::findOrFail($jFW_i);
        goto JZOQU;
        yuUkZ:
        throw new \Exception("Message back with success data but not found thumbnail files " . $jFW_i);
        goto y14Tq;
        JZOQU:
        $F78UR = "v2/hls/thumbnails/{$jFW_i}/";
        goto pDYlh;
        LME1P:
        Log::error("Message back with success data but not found thumbnail " . $jFW_i);
        goto FGFpd;
        hT1ok:
        $fXv_l = $this->YHwpp->files($F78UR);
        goto bXEVn;
        pDYlh:
        if ($this->YHwpp->directoryExists($F78UR)) {
            goto Wqqj6;
        }
        goto LME1P;
        FGFpd:
        throw new \Exception("Message back with success data but not found thumbnail " . $jFW_i);
        goto vOduF;
        y14Tq:
        lq6qi:
        goto teQ2t;
        LShwD:
        Log::error("Message back with success data but not found thumbnail files " . $jFW_i);
        goto yuUkZ;
        bXEVn:
        if (!(count($fXv_l) === 0)) {
            goto lq6qi;
        }
        goto LShwD;
        teQ2t:
        $uA7Bz->update(['generated_previews' => $F78UR]);
        goto LYa_Z;
        vOduF:
        Wqqj6:
        goto hT1ok;
        LYa_Z:
    }
    public function getThumbnails(string $jFW_i) : array
    {
        $uA7Bz = D6fOq8lm3n7T2::findOrFail($jFW_i);
        return $uA7Bz->getThumbnails();
    }
    public function getMedia(string $jFW_i) : array
    {
        $PK0_J = Media::findOrFail($jFW_i);
        return $PK0_J->getView();
    }
}
