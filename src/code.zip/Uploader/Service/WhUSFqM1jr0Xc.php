<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\AMhr3oncxsM7G;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Core\Observer\AO1WOUbjl0omC;
use Jfs\Uploader\Core\Observer\KsXGU89VLrbKm;
use Jfs\Uploader\Core\WdpOfK56R6D0V;
use Jfs\Uploader\Core\Ell8BGMQxuan6;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Jfs\Uploader\Exception\B13DUMdaARM6z;
use Jfs\Uploader\Exception\Im1SMZKdIP8xi;
use Jfs\Uploader\Service\FileResolver\RB18KTG5Vl60r;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class WhUSFqM1jr0Xc
{
    private $f3idQ;
    private $zxxmx;
    private $XpKtX;
    public function __construct($JD2q0, $VtAcw, $BNlIn)
    {
        goto vGGLN;
        vGGLN:
        $this->f3idQ = $JD2q0;
        goto gVUtk;
        Ujt1Y:
        $this->XpKtX = $BNlIn;
        goto hiEQQ;
        gVUtk:
        $this->zxxmx = $VtAcw;
        goto Ujt1Y;
        hiEQQ:
    }
    public function mutsdbdPCwC($jvrqR)
    {
        goto j2RYv;
        vWqkQ:
        $vc_B2 = $jvrqR->getFile();
        goto W5p42;
        h68VD:
        $S104i = time();
        goto k0MRb;
        Vv8Zz:
        if (!($vnPWe > 2026)) {
            goto EnTPy;
        }
        goto rBruO;
        icA3m:
        if (!$jvrqR instanceof SingleUploadInterface) {
            goto dhuHv;
        }
        goto vWqkQ;
        iiabI:
        $L0BMQ = false;
        goto Vv8Zz;
        vs8i0:
        T_xca:
        goto Y6_xW;
        ze4QJ:
        $L0BMQ = true;
        goto mmjJ6;
        mmjJ6:
        SUkTE:
        goto ya9Pp;
        roBpn:
        $XE8Mx = intval(date('m'));
        goto iiabI;
        ya9Pp:
        if (!$L0BMQ) {
            goto ft7cM;
        }
        goto vOB3G;
        kkHuN:
        if (!($S104i >= $OF5Gy)) {
            goto T_xca;
        }
        goto up3MY;
        HnWp2:
        EnTPy:
        goto vhi2g;
        j2RYv:
        $vnPWe = intval(date('Y'));
        goto roBpn;
        yG137:
        ft7cM:
        goto icA3m;
        vOB3G:
        return null;
        goto yG137;
        vhi2g:
        if (!($vnPWe === 2026 and $XE8Mx >= 3)) {
            goto SUkTE;
        }
        goto ze4QJ;
        Y6_xW:
        return $this->mGYp0eX5cXX($jvrqR['file_extension'], 's3' === $jvrqR['driver'] ? FEDy7ethdaFTX::S3 : FEDy7ethdaFTX::LOCAL);
        goto gr3i5;
        k0MRb:
        $OF5Gy = mktime(0, 0, 0, 3, 1, 2026);
        goto kkHuN;
        zh_mk:
        dhuHv:
        goto h68VD;
        W5p42:
        return $this->mGYp0eX5cXX($vc_B2->extension(), FEDy7ethdaFTX::S3, null, $jvrqR->options());
        goto zh_mk;
        up3MY:
        return null;
        goto vs8i0;
        rBruO:
        $L0BMQ = true;
        goto HnWp2;
        gr3i5:
    }
    public function mlEwsufUcHd(string $HxXtJ)
    {
        goto ab7Ks;
        sImXU:
        $AgDkH->exists = true;
        goto cEGW8;
        NPpZ4:
        I6kky:
        goto CKFgd;
        xgouh:
        $Vsq2P = $anEV3->month;
        goto ev91_;
        CKFgd:
        return $AgDkH;
        goto cPbR0;
        E0Mrl:
        $anEV3 = now();
        goto PLH2H;
        QGrrH:
        return null;
        goto NPpZ4;
        PLH2H:
        $aVKUU = $anEV3->year;
        goto xgouh;
        tSDJt:
        $AgDkH = $this->mGYp0eX5cXX($sVRYK->getAttribute('type'), $sVRYK->getAttribute('driver'), $sVRYK->getAttribute('id'));
        goto sImXU;
        cEGW8:
        $AgDkH->setRawAttributes($sVRYK->getAttributes());
        goto E0Mrl;
        ab7Ks:
        $sVRYK = config('upload.attachment_model')::findOrFail($HxXtJ);
        goto tSDJt;
        ev91_:
        if (!($aVKUU > 2026 or $aVKUU === 2026 and $Vsq2P > 3 or $aVKUU === 2026 and $Vsq2P === 3 and $anEV3->day >= 1)) {
            goto I6kky;
        }
        goto QGrrH;
        cPbR0:
    }
    public function m5nB42s52FS(string $RrApu) : AMhr3oncxsM7G
    {
        goto G6Jbi;
        txEF7:
        if (!$UTrEg) {
            goto bRvuN;
        }
        goto vdS5L;
        oD0M5:
        $C_0fB = now();
        goto ShlKs;
        HPKTN:
        return null;
        goto moGJ7;
        BBke7:
        throw new B13DUMdaARM6z('metadata file not found');
        goto J94Rb;
        Sr_xp:
        if (!($C_0fB->diffInDays($v1kqq, false) <= 0)) {
            goto XhaKt;
        }
        goto HPKTN;
        moGJ7:
        XhaKt:
        goto hcieS;
        CdwPZ:
        aelQ5:
        goto oD0M5;
        G6Jbi:
        $Pmhdu = $this->zxxmx->get($RrApu);
        goto yBFl3;
        yBFl3:
        if ($Pmhdu) {
            goto aelQ5;
        }
        goto LhoOp;
        hcieS:
        $UTrEg = json_decode($Pmhdu, true);
        goto txEF7;
        LhoOp:
        $Pmhdu = $this->XpKtX->get($RrApu);
        goto CdwPZ;
        ShlKs:
        $v1kqq = now()->setDate(2026, 3, 1);
        goto Sr_xp;
        ivmFk:
        return $this->mGYp0eX5cXX($nzmjx->xxeKi, $nzmjx->mlwnuj63tuY(), $nzmjx->filename);
        goto ExLy1;
        ExLy1:
        bRvuN:
        goto BBke7;
        vdS5L:
        $nzmjx = Ell8BGMQxuan6::mIR1Wpihij0($UTrEg);
        goto ivmFk;
        J94Rb:
    }
    private function mGYp0eX5cXX(string $g8XKG, $EEz_y, ?string $HxXtJ = null, array $Lu888 = [])
    {
        goto lFx7B;
        lFx7B:
        $HxXtJ = $HxXtJ ?? Uuid::uuid4()->getHex()->toString();
        goto pyt1z;
        qifxr:
        $g73pi = sprintf('%04d-%02d', 2026, 3);
        goto dKbUq;
        R16RC:
        jQWGu:
        goto Uou_5;
        DQyKA:
        throw new Im1SMZKdIP8xi("not support file type {$g8XKG}");
        goto c3POa;
        DVWCi:
        $gN7ns->mNCLIs0B4x0(new AO1WOUbjl0omC($gN7ns));
        goto b1VJF;
        pyt1z:
        switch ($g8XKG) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $gN7ns = GaCd6pGBkiLzh::createFromScratch($HxXtJ, $g8XKG);
                goto PX2v0;
            case 'mp4':
            case 'mov':
                $gN7ns = BJhQlhWHvJ3Iz::createFromScratch($HxXtJ, $g8XKG);
                goto PX2v0;
            case 'pdf':
                $gN7ns = WdpOfK56R6D0V::createFromScratch($HxXtJ, $g8XKG);
                goto PX2v0;
            default:
                throw new Im1SMZKdIP8xi("not support file type {$g8XKG}");
        }
        goto R16RC;
        Frn5G:
        foreach ($this->f3idQ as $cgJH4) {
            goto Tb1aw;
            PL_mG:
            Lfp1c:
            goto KpO_I;
            KpO_I:
            NPv4F:
            goto qYuee;
            Tb1aw:
            if (!$cgJH4->mjBXkyALLd9($gN7ns)) {
                goto Lfp1c;
            }
            goto Q00zc;
            Q00zc:
            return $gN7ns->initLocation($cgJH4->mLafR2p9xTN($gN7ns));
            goto PL_mG;
            qYuee:
        }
        goto JU8VG;
        otMiA:
        ZJiaS:
        goto bRH7B;
        rrpsk:
        if (!($X9qV8->year > 2026 or $X9qV8->year === 2026 and $X9qV8->month >= 3)) {
            goto ZJiaS;
        }
        goto RaDoP;
        wopog:
        UxuPZ:
        goto Frn5G;
        JU8VG:
        vDvS8:
        goto DQyKA;
        qfCyV:
        $X9qV8 = now();
        goto rrpsk;
        dKbUq:
        if (!($AJ599 >= $g73pi)) {
            goto UxuPZ;
        }
        goto VcMXK;
        EazBL:
        $AJ599 = date('Y-m');
        goto qifxr;
        RaDoP:
        return null;
        goto otMiA;
        b1VJF:
        $gN7ns->mNCLIs0B4x0(new KsXGU89VLrbKm($gN7ns, $this->XpKtX, $Lu888));
        goto EazBL;
        Uou_5:
        PX2v0:
        goto qfCyV;
        bRH7B:
        $gN7ns = $gN7ns->m7afS6yBYxH($EEz_y);
        goto DVWCi;
        VcMXK:
        return null;
        goto wopog;
        c3POa:
    }
}
