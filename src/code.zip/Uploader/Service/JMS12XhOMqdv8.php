<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Core\Observer\B8CrW6kZZ9ym6;
use Jfs\Uploader\Core\Observer\NAEOJn29TQ9eM;
use Jfs\Uploader\Core\B1V448YMelQAT;
use Jfs\Uploader\Core\OGqakwzIfzu7z;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Exception\ZEPVfMQDBdCIh;
use Jfs\Uploader\Service\FileResolver\ShUSAHz6olRoV;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class JMS12XhOMqdv8
{
    private $m1L3L;
    private $hhcR1;
    private $VoF9h;
    public function __construct($Gh1kl, $nQYui, $BQ2l1)
    {
        goto uPkpx;
        uPkpx:
        $this->m1L3L = $Gh1kl;
        goto wYHA0;
        tNh0c:
        $this->VoF9h = $BQ2l1;
        goto xuzD0;
        wYHA0:
        $this->hhcR1 = $nQYui;
        goto tNh0c;
        xuzD0:
    }
    public function mUTjgOHTDsT($OUQ3r)
    {
        goto nBcby;
        nBcby:
        if (!$OUQ3r instanceof SingleUploadInterface) {
            goto A9I4o;
        }
        goto ZGWwG;
        BfoG8:
        return $this->m1fYBts1rnN($Cv47p->extension(), A3VATad7gvqZU::S3, null, $OUQ3r->options());
        goto yTEp3;
        ZGWwG:
        $Cv47p = $OUQ3r->getFile();
        goto BfoG8;
        A3EDZ:
        return $this->m1fYBts1rnN($OUQ3r['file_extension'], 's3' === $OUQ3r['driver'] ? A3VATad7gvqZU::S3 : A3VATad7gvqZU::LOCAL);
        goto kIbnD;
        yTEp3:
        A9I4o:
        goto A3EDZ;
        kIbnD:
    }
    public function m6gPzko8cqh(string $JTwN4)
    {
        goto ps0cs;
        ps0cs:
        $gGdNk = config('upload.attachment_model')::findOrFail($JTwN4);
        goto K8Auh;
        VJ9Md:
        $hFrf7->setRawAttributes($gGdNk->getAttributes());
        goto hFmI2;
        K8Auh:
        $hFrf7 = $this->m1fYBts1rnN($gGdNk->getAttribute('type'), $gGdNk->getAttribute('driver'), $gGdNk->getAttribute('id'));
        goto VUKGg;
        VUKGg:
        $hFrf7->exists = true;
        goto VJ9Md;
        hFmI2:
        return $hFrf7;
        goto M43W6;
        M43W6:
    }
    public function mYuIBEF54DA(string $dyw5J) : MEWwofwAYqgaI
    {
        goto BTTyr;
        Uu0xB:
        if (!$apROX) {
            goto tw0xt;
        }
        goto cuaSV;
        BTTyr:
        $jI6JZ = $this->hhcR1->get($dyw5J);
        goto yhLsS;
        KRXWd:
        return $this->m1fYBts1rnN($V_TBo->ZOUax, $V_TBo->md5H9xoYDzG(), $V_TBo->filename);
        goto Ht3FT;
        yhLsS:
        if ($jI6JZ) {
            goto WaPuG;
        }
        goto najCw;
        epGsQ:
        throw new EpflNcDLOJeck('metadata file not found');
        goto mIWjf;
        najCw:
        $jI6JZ = $this->VoF9h->get($dyw5J);
        goto os12_;
        Ht3FT:
        tw0xt:
        goto epGsQ;
        OhZKb:
        $apROX = json_decode($jI6JZ, true);
        goto Uu0xB;
        os12_:
        WaPuG:
        goto OhZKb;
        cuaSV:
        $V_TBo = OGqakwzIfzu7z::m1nymnx8GaJ($apROX);
        goto KRXWd;
        mIWjf:
    }
    private function m1fYBts1rnN(string $cOgQS, $S_01a, ?string $JTwN4 = null, array $sjhjO = [])
    {
        goto IL7co;
        fcXB9:
        dy02x:
        goto Ae3hf;
        xTaIh:
        SFLOI:
        goto bZk7v;
        meTMt:
        switch ($cOgQS) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $BAhJs = Z7LUL65CwqbbF::createFromScratch($JTwN4, $cOgQS);
                goto ORTce;
            case 'mp4':
            case 'mov':
                $BAhJs = MbOYV1VlUGCys::createFromScratch($JTwN4, $cOgQS);
                goto ORTce;
            case 'pdf':
                $BAhJs = B1V448YMelQAT::createFromScratch($JTwN4, $cOgQS);
                goto ORTce;
            default:
                throw new ZEPVfMQDBdCIh("not support file type {$cOgQS}");
        }
        goto xTaIh;
        IL7co:
        $JTwN4 = $JTwN4 ?? Uuid::uuid4()->getHex()->toString();
        goto meTMt;
        rlpDK:
        $BAhJs->m1RJrReO70j(new B8CrW6kZZ9ym6($BAhJs));
        goto U6nO2;
        Ae3hf:
        throw new ZEPVfMQDBdCIh("not support file type {$cOgQS}");
        goto fAWR8;
        bZk7v:
        ORTce:
        goto gs2ZE;
        U6nO2:
        $BAhJs->m1RJrReO70j(new NAEOJn29TQ9eM($BAhJs, $this->VoF9h, $sjhjO));
        goto IhU78;
        gs2ZE:
        $BAhJs = $BAhJs->mfoyQ3jZcJ6($S_01a);
        goto rlpDK;
        IhU78:
        foreach ($this->m1L3L as $fkBVz) {
            goto fkNkm;
            ms19Z:
            dQj_N:
            goto hQzSk;
            CjxDT:
            return $BAhJs->initLocation($fkBVz->mFMTAmQv5ze($BAhJs));
            goto ms19Z;
            hQzSk:
            GON2G:
            goto tHC0H;
            fkNkm:
            if (!$fkBVz->mEyKasCU45H($BAhJs)) {
                goto dQj_N;
            }
            goto CjxDT;
            tHC0H:
        }
        goto fcXB9;
        fAWR8:
    }
}
