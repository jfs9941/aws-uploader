<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\SK7fSNbDSRmCO;
use Jfs\Uploader\Core\JQSlbB9QkzzhT;
use Jfs\Uploader\Core\VX3gdl3bFyp5B;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
use Jfs\Uploader\Exception\J0z9iIrDgeD3q;
use Jfs\Uploader\Exception\Uxbn1AMqHjlda;
use Jfs\Uploader\Exception\LlZ7jHsX0xmpK;
final class WHlU6fbS2AP5Y implements UploadServiceInterface
{
    private $Fr1B7;
    private $N3F9R;
    private $LmK5y;
    private $yEK8A;
    public function __construct(SPtrbk9kcnPEI $tSoA4, Filesystem $mFX9i, Filesystem $ExTI3, string $RcTVE)
    {
        goto GT_Nq;
        GT_Nq:
        $this->Fr1B7 = $tSoA4;
        goto q8wqw;
        q8wqw:
        $this->N3F9R = $mFX9i;
        goto N4Q0r;
        o2g3D:
        $this->yEK8A = $RcTVE;
        goto LWwuf;
        N4Q0r:
        $this->LmK5y = $ExTI3;
        goto o2g3D;
        LWwuf:
    }
    public function storeSingleFile(SingleUploadInterface $aizRh) : array
    {
        goto hE__X;
        hE__X:
        $a3XOL = $this->Fr1B7->mOBwvyofVsV($aizRh);
        goto qp5m2;
        Z4MJP:
        return $a3XOL->getView();
        goto hQtsM;
        E5t2g:
        goto T0mxx;
        goto L3sWg;
        qp5m2:
        $IB9Pt = $this->LmK5y->putFileAs(dirname($a3XOL->getLocation()), $aizRh->getFile(), $a3XOL->getFilename() . '.' . $a3XOL->getExtension(), ['visibility' => 'public']);
        goto KAfBA;
        eH4i8:
        $a3XOL->mGQfJhYWpvR(RwOJkCXwa9RQz::UPLOADED);
        goto Hu1e6;
        L3sWg:
        s6VOI:
        goto eH4i8;
        KAfBA:
        if (false !== $IB9Pt && $a3XOL instanceof SK7fSNbDSRmCO) {
            goto s6VOI;
        }
        goto kw6Ky;
        Hu1e6:
        T0mxx:
        goto Z4MJP;
        kw6Ky:
        throw new \LogicException('File upload failed, check permissions');
        goto E5t2g;
        hQtsM:
    }
    public function storePreSignedFile(array $dUIJq)
    {
        goto rgk2k;
        PSMCP:
        return ['filename' => $KnLpk->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $KnLpk->mx7V80CwNdJ()];
        goto iLvxX;
        rgk2k:
        $a3XOL = $this->Fr1B7->mOBwvyofVsV($dUIJq);
        goto M2VD1;
        M2VD1:
        $KnLpk = VX3gdl3bFyp5B::mkQV9Hcse0B($a3XOL, $this->N3F9R, $this->LmK5y, $this->yEK8A, true);
        goto mxRoa;
        jZPMB:
        $KnLpk->mOO2hGx6WBJ();
        goto PSMCP;
        mxRoa:
        $KnLpk->mdu95DPFMR9($dUIJq['mime'], $dUIJq['file_size'], $dUIJq['chunk_size'], $dUIJq['checksums'], $dUIJq['user_id'], $dUIJq['driver']);
        goto jZPMB;
        iLvxX:
    }
    public function updatePreSignedFile(string $OSPuD, int $Ftc2f)
    {
        goto Ctkbe;
        epYfC:
        VzK1o:
        goto Eso7R;
        HguIk:
        switch ($Ftc2f) {
            case RwOJkCXwa9RQz::UPLOADED:
                $KnLpk->mgJpdXKB3Xn();
                goto VzK1o;
            case RwOJkCXwa9RQz::PROCESSING:
                $KnLpk->mGzGyHD99FA();
                goto VzK1o;
            case RwOJkCXwa9RQz::FINISHED:
                $KnLpk->mZMcj35DCr3();
                goto VzK1o;
            case RwOJkCXwa9RQz::ABORTED:
                $KnLpk->mPg3VUD81kn();
                goto VzK1o;
        }
        goto mEWoP;
        mEWoP:
        VuuW4:
        goto epYfC;
        Ctkbe:
        $KnLpk = VX3gdl3bFyp5B::mLpgBe5q0Rd($OSPuD, $this->N3F9R, $this->LmK5y, $this->yEK8A);
        goto HguIk;
        Eso7R:
    }
    public function completePreSignedFile(string $OSPuD, array $tFMn9)
    {
        goto VUghw;
        QvmEL:
        $KnLpk->mDwF61YxuNq()->mhQJzLNptS8($tFMn9);
        goto VaiTS;
        eMpPC:
        return ['path' => $KnLpk->getFile()->getView()['path'], 'thumbnail' => $KnLpk->getFile()->CKPey, 'id' => $OSPuD];
        goto zTLpx;
        VUghw:
        $KnLpk = VX3gdl3bFyp5B::mLpgBe5q0Rd($OSPuD, $this->N3F9R, $this->LmK5y, $this->yEK8A);
        goto QvmEL;
        VaiTS:
        $KnLpk->mgJpdXKB3Xn();
        goto eMpPC;
        zTLpx:
    }
    public function updateFile(string $OSPuD, int $Ftc2f) : JQSlbB9QkzzhT
    {
        goto FOvYN;
        FOvYN:
        $a3XOL = $this->Fr1B7->m3a9ZXSdFap($OSPuD);
        goto y7Q3E;
        y7Q3E:
        $a3XOL->mGQfJhYWpvR($Ftc2f);
        goto Y_1rL;
        Y_1rL:
        return $a3XOL;
        goto PY89O;
        PY89O:
    }
}
