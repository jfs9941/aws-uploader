<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
final class L3oEPipUZv9oB
{
    private $Jc4z2;
    private $y1jqe;
    private $kduDw;
    public function __construct(string $rhVEO, string $nQM7l, Filesystem $h5ffz)
    {
        goto jEMWl;
        e_NRJ:
        $this->kduDw = $h5ffz;
        goto eMxvq;
        xrXdI:
        $this->y1jqe = $nQM7l;
        goto e_NRJ;
        jEMWl:
        $this->Jc4z2 = $rhVEO;
        goto xrXdI;
        eMxvq:
    }
    public function mY4nsY6JGPc(Dup6KVtAFNCUq $FFbb9) : string
    {
        goto RSe93;
        RSe93:
        if (!(GrPXtp41lLmde::S3 == $FFbb9->getAttribute('driver'))) {
            goto dZuU9;
        }
        goto jBFEO;
        uTL7A:
        dZuU9:
        goto H7Tow;
        H7Tow:
        return $this->kduDw->url($FFbb9->getAttribute('filename'));
        goto woTBv;
        jBFEO:
        return 's3://' . $this->Jc4z2 . '/' . $FFbb9->getAttribute('filename');
        goto uTL7A;
        woTBv:
    }
    public function mZoCLBw0Osx(?string $ltOFR) : ?string
    {
        goto c32ka;
        G11zJ:
        return null;
        goto BSgOc;
        ougkK:
        return 's3://' . $this->Jc4z2 . '/' . ltrim($sEueW, '/');
        goto ytEbz;
        zpF2i:
        $sEueW = parse_url($ltOFR, PHP_URL_PATH);
        goto ougkK;
        y4Tcz:
        if (!TCuDL($ltOFR, $this->Jc4z2)) {
            goto TWRMv;
        }
        goto zpF2i;
        ytEbz:
        TWRMv:
        goto R4Iml;
        c32ka:
        if (!$ltOFR) {
            goto BhIu2;
        }
        goto y4Tcz;
        R4Iml:
        BhIu2:
        goto G11zJ;
        BSgOc:
    }
    public function m6AMr5gMVyk(string $sEueW) : string
    {
        return 's3://' . $this->Jc4z2 . '/' . $sEueW;
    }
}
