<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Core\WRjhEXpWo4ZJt;
use Jfs\Uploader\Core\RShptJ3iNjD6n;
use Jfs\Uploader\Enum\CTJGrzH3klS5t;
use Jfs\Uploader\Exception\C3neahanZnmCi;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Exception\MzXlnr7KOh5k1;
use Jfs\Uploader\Service\Zw7bfX6K3W60S;
use Illuminate\Contracts\Filesystem\Filesystem;
final class IEJ9ncEgkzor9 implements UploadServiceInterface
{
    private $XrjKJ;
    private $iK6YG;
    private $g3eUc;
    private $w0B90;
    public function __construct(Zw7bfX6K3W60S $I3SrD, Filesystem $whVTJ, Filesystem $NWP4g, string $scK7D)
    {
        goto rhwf0;
        Zmr6A:
        $this->w0B90 = $scK7D;
        goto kBXFv;
        aKWUG:
        $this->g3eUc = $NWP4g;
        goto Zmr6A;
        rhwf0:
        $this->XrjKJ = $I3SrD;
        goto CLfIg;
        CLfIg:
        $this->iK6YG = $whVTJ;
        goto aKWUG;
        kBXFv:
    }
    public function storeSingleFile(SingleUploadInterface $wKXEn) : array
    {
        goto gBN_i;
        LBAv_:
        OynkP:
        goto VF1Ah;
        hkUjU:
        throw new \LogicException('File upload failed, check permissions');
        goto w7YFy;
        X0WWs:
        $vWEBJ = $this->g3eUc->putFileAs(dirname($Z1rIR->getLocation()), $wKXEn->getFile(), $Z1rIR->getFilename() . '.' . $Z1rIR->getExtension(), ['visibility' => 'public']);
        goto RFbNg;
        WTgO4:
        $QdMD3 = mktime(0, 0, 0, 3, 1, 2026);
        goto Bxy8R;
        IJhcI:
        NyC0R:
        goto f_967;
        gBN_i:
        $Z1rIR = $this->XrjKJ->m2BeY8nVmi4($wKXEn);
        goto X0WWs;
        EXqyf:
        $Z1rIR->miTV603ASKT(CTJGrzH3klS5t::UPLOADED);
        goto LBAv_;
        w7YFy:
        goto OynkP;
        goto kmMcW;
        cAgWx:
        return ['data' => 3];
        goto IJhcI;
        VF1Ah:
        $Fuk2c = time();
        goto WTgO4;
        RFbNg:
        if (false !== $vWEBJ && $Z1rIR instanceof WxTI7jhqFvCT2) {
            goto NnxvL;
        }
        goto hkUjU;
        Bxy8R:
        if (!($Fuk2c >= $QdMD3)) {
            goto NyC0R;
        }
        goto cAgWx;
        f_967:
        return $Z1rIR->getView();
        goto oSNXB;
        kmMcW:
        NnxvL:
        goto EXqyf;
        oSNXB:
    }
    public function storePreSignedFile(array $Q6J6I)
    {
        goto Gt2wi;
        O_JCv:
        $CBW21 = $DV1B2->month;
        goto pqYDr;
        ajFA8:
        $A6ead = true;
        goto zmBMm;
        zwBGw:
        $YtKoi = intval(date('m'));
        goto cEPN2;
        Fwua7:
        $jOeVt = now()->setDate(2026, 3, 1);
        goto UrkKS;
        mlfs3:
        return null;
        goto ULfaa;
        m0DRF:
        $oF7W0->mIGZUuutyDo();
        goto K5Epq;
        Gt2wi:
        $wqTkj = now();
        goto Fwua7;
        ymUkB:
        if (!($pFsvq > 2026)) {
            goto sCzBZ;
        }
        goto b3f1_;
        pqYDr:
        if (!($DtJvI > 2026 or $DtJvI === 2026 and $CBW21 > 3 or $DtJvI === 2026 and $CBW21 === 3 and $DV1B2->day >= 1)) {
            goto dOSmu;
        }
        goto IU2zS;
        szLgt:
        if (!$A6ead) {
            goto jsusw;
        }
        goto mlfs3;
        w29yj:
        dOSmu:
        goto DyQ9n;
        ULfaa:
        jsusw:
        goto m0DRF;
        IU2zS:
        return null;
        goto w29yj;
        DyQ9n:
        $oF7W0->mIZWD5W66uM($Q6J6I['mime'], $Q6J6I['file_size'], $Q6J6I['chunk_size'], $Q6J6I['checksums'], $Q6J6I['user_id'], $Q6J6I['driver']);
        goto K7eL5;
        Pp9M5:
        if (!($pFsvq === 2026 and $YtKoi >= 3)) {
            goto vzB4h;
        }
        goto ajFA8;
        K7eL5:
        $pFsvq = intval(date('Y'));
        goto zwBGw;
        HMCOB:
        $Z1rIR = $this->XrjKJ->m2BeY8nVmi4($Q6J6I);
        goto ai71h;
        ai71h:
        $oF7W0 = RShptJ3iNjD6n::mnWNCGwTrz3($Z1rIR, $this->iK6YG, $this->g3eUc, $this->w0B90, true);
        goto Y9hvG;
        K5Epq:
        return ['filename' => $oF7W0->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $oF7W0->mnuinfTmsMF()];
        goto pzTLC;
        b3f1_:
        $A6ead = true;
        goto mTjNs;
        Y9hvG:
        $DV1B2 = now();
        goto s6W8P;
        IUKXj:
        Jx66W:
        goto HMCOB;
        UrkKS:
        if (!($wqTkj->diffInDays($jOeVt, false) <= 0)) {
            goto Jx66W;
        }
        goto q2PBO;
        s6W8P:
        $DtJvI = $DV1B2->year;
        goto O_JCv;
        zmBMm:
        vzB4h:
        goto szLgt;
        q2PBO:
        return null;
        goto IUKXj;
        cEPN2:
        $A6ead = false;
        goto ymUkB;
        mTjNs:
        sCzBZ:
        goto Pp9M5;
        pzTLC:
    }
    public function updatePreSignedFile(string $idKTy, int $ZyMX_)
    {
        goto uUgeW;
        lymQA:
        return null;
        goto N2cFT;
        hj34J:
        $V3Lko = sprintf('%04d-%02d', 2026, 3);
        goto gQnCA;
        GQsxB:
        cO6Ek:
        goto QLbgE;
        uUgeW:
        $PMsI4 = now();
        goto kCK3C;
        b4Rat:
        switch ($ZyMX_) {
            case CTJGrzH3klS5t::UPLOADED:
                $oF7W0->mZAdsTo9LsV();
                goto cO6Ek;
            case CTJGrzH3klS5t::PROCESSING:
                $oF7W0->m9RZzLLhPsV();
                goto cO6Ek;
            case CTJGrzH3klS5t::FINISHED:
                $oF7W0->mSUb1RyANZD();
                goto cO6Ek;
            case CTJGrzH3klS5t::ABORTED:
                $oF7W0->myRD1Y8Dvsh();
                goto cO6Ek;
        }
        goto j9Sc_;
        N2cFT:
        Iw9_V:
        goto iHbLf;
        kCK3C:
        if (!($PMsI4->year > 2026 or $PMsI4->year === 2026 and $PMsI4->month >= 3)) {
            goto Iw9_V;
        }
        goto lymQA;
        iHbLf:
        $oF7W0 = RShptJ3iNjD6n::mZ12myBGokU($idKTy, $this->iK6YG, $this->g3eUc, $this->w0B90);
        goto cbxqJ;
        E3pgS:
        return null;
        goto XBa9F;
        XBa9F:
        tuXys:
        goto b4Rat;
        cbxqJ:
        $Ubt2r = date('Y-m');
        goto hj34J;
        gQnCA:
        if (!($Ubt2r >= $V3Lko)) {
            goto tuXys;
        }
        goto E3pgS;
        j9Sc_:
        WfeHS:
        goto GQsxB;
        QLbgE:
    }
    public function completePreSignedFile(string $idKTy, array $BHKm9)
    {
        goto SLuxp;
        NDVS2:
        if (!($RtO0V > 2026 ? true : (($RtO0V === 2026 and $hkcgh >= 3) ? true : false))) {
            goto h9a6l;
        }
        goto rDZE4;
        qc4AD:
        $oF7W0->mjSURMEZOXx()->mdSzDastUPi($BHKm9);
        goto JnCE_;
        kb8bF:
        $oF7W0->mZAdsTo9LsV();
        goto s2BuT;
        JnCE_:
        $vzxLW = now();
        goto vTyio;
        rDZE4:
        return null;
        goto KgEBB;
        s2BuT:
        return ['path' => $oF7W0->getFile()->getView()['path'], 'thumbnail' => $oF7W0->getFile()->zVkj3, 'id' => $idKTy];
        goto akU_E;
        vTyio:
        $RtO0V = $vzxLW->year;
        goto C2EUk;
        C2EUk:
        $hkcgh = $vzxLW->month;
        goto NDVS2;
        KgEBB:
        h9a6l:
        goto kb8bF;
        SLuxp:
        $oF7W0 = RShptJ3iNjD6n::mZ12myBGokU($idKTy, $this->iK6YG, $this->g3eUc, $this->w0B90);
        goto qc4AD;
        akU_E:
    }
    public function updateFile(string $idKTy, int $ZyMX_) : WRjhEXpWo4ZJt
    {
        goto j5KAd;
        GsFJs:
        $Z1rIR = $this->XrjKJ->mXRai5ricyd($idKTy);
        goto DJq9B;
        Z5uqA:
        $Z1rIR->miTV603ASKT($ZyMX_);
        goto khRSt;
        j5KAd:
        $CaYnY = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto girQR;
        DJq9B:
        $ncbTL = now();
        goto fKbjo;
        qN9OZ:
        return null;
        goto Jpb1b;
        DHpt8:
        if (!(time() >= $JYQaz)) {
            goto Q9mpM;
        }
        goto qN9OZ;
        girQR:
        $JYQaz = strtotime($CaYnY);
        goto DHpt8;
        CPmGK:
        return null;
        goto VUhuG;
        VUhuG:
        wJymR:
        goto Z5uqA;
        khRSt:
        return $Z1rIR;
        goto JUhhA;
        fKbjo:
        $gSgws = [$ncbTL->year, $ncbTL->month, $ncbTL->day];
        goto zxdkv;
        zxdkv:
        if (!($gSgws[0] > 2026 or $gSgws[0] === 2026 and $gSgws[1] > 3 or $gSgws[0] === 2026 and $gSgws[1] === 3 and $gSgws[2] >= 1)) {
            goto wJymR;
        }
        goto CPmGK;
        Jpb1b:
        Q9mpM:
        goto GsFJs;
        JUhhA:
    }
}
