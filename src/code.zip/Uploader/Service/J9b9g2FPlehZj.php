<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class J9b9g2FPlehZj implements VideoPostHandleServiceInterface
{
    private $qnMwV;
    private $m2kWg;
    public function __construct(UploadServiceInterface $nuS5c, Filesystem $Npup8)
    {
        $this->qnMwV = $nuS5c;
        $this->m2kWg = $Npup8;
    }
    public function saveMetadata(string $Brk87, array $bxW1r)
    {
        goto TT_75;
        ziBGH:
        if (!(isset($bxW1r['change_status']) && $bxW1r['change_status'])) {
            goto oZ4nT;
        }
        goto GSkC1;
        Lk375:
        if (!isset($bxW1r['thumbnail_url'])) {
            goto Tjtzg;
        }
        goto EZayO;
        swJzt:
        kZ_uF:
        goto x1PKx;
        gs43O:
        oSgSj:
        goto UmG_W;
        t1Xpo:
        oZ4nT:
        goto Yr_Ak;
        IYRWH:
        fvk1v:
        goto mIrgG;
        kTTM1:
        unset($XWuOL['thumbnail']);
        goto IYRWH;
        mIrgG:
        if (!$jZqB7->update($XWuOL)) {
            goto kZ_uF;
        }
        goto ziBGH;
        lNbME:
        $XWuOL = [];
        goto Lk375;
        W4BKL:
        try {
            goto c0Hx6;
            ucxyK:
            $XWuOL['thumbnail'] = $NQQfI['filename'];
            goto hOraS;
            DJ2uy:
            $XWuOL['thumbnail_id'] = $NQQfI['id'];
            goto ucxyK;
            c0Hx6:
            $NQQfI = $this->qnMwV->storeSingleFile(new class($bxW1r['thumbnail']) implements SingleUploadInterface
            {
                private $bQMHT;
                public function __construct($ZQzpf)
                {
                    $this->bQMHT = $ZQzpf;
                }
                public function getFile()
                {
                    return $this->bQMHT;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto DJ2uy;
            hOraS:
        } catch (\Throwable $Fa7Tp) {
            Log::warning("HVuLZHLrSam0d thumbnail store failed: " . $Fa7Tp->getMessage());
        }
        goto rZE43;
        rZE43:
        TmsYx:
        goto aWzE2;
        kRxHQ:
        if (!isset($bxW1r['fps'])) {
            goto oSgSj;
        }
        goto sSMKz;
        lkm1i:
        if (!isset($bxW1r['resolution'])) {
            goto mjl8P;
        }
        goto wVwzw;
        orOas:
        throw new \Exception("HVuLZHLrSam0d metadata store failed for unknown reason ... " . $Brk87);
        goto wGjKO;
        Yr_Ak:
        return $jZqB7->getView();
        goto swJzt;
        aWzE2:
        if (!isset($bxW1r['duration'])) {
            goto v_qxj;
        }
        goto JOQg4;
        sSMKz:
        $XWuOL['fps'] = $bxW1r['fps'];
        goto gs43O;
        EZayO:
        $XWuOL['thumbnail'] = $bxW1r['thumbnail_url'];
        goto gBZIW;
        gjH0y:
        v_qxj:
        goto lkm1i;
        TT_75:
        $jZqB7 = HVuLZHLrSam0d::findOrFail($Brk87);
        goto lNbME;
        GSkC1:
        $this->qnMwV->updateFile($jZqB7->getAttribute('id'), ZVJoOgH14iXBq::PROCESSING);
        goto t1Xpo;
        x7NQz:
        if (!isset($bxW1r['thumbnail'])) {
            goto TmsYx;
        }
        goto W4BKL;
        x1PKx:
        Log::warning("HVuLZHLrSam0d metadata store failed for unknown reason ... " . $Brk87);
        goto orOas;
        JOQg4:
        $XWuOL['duration'] = $bxW1r['duration'];
        goto gjH0y;
        gBZIW:
        Tjtzg:
        goto x7NQz;
        UmG_W:
        if (!$jZqB7->bcO9d) {
            goto fvk1v;
        }
        goto kTTM1;
        ms864:
        mjl8P:
        goto kRxHQ;
        wVwzw:
        $XWuOL['resolution'] = $bxW1r['resolution'];
        goto ms864;
        wGjKO:
    }
    public function createThumbnail(string $P9w4z) : void
    {
        goto P9qni;
        lv1wI:
        $jZqB7 = HVuLZHLrSam0d::findOrFail($P9w4z);
        goto I2zCa;
        I2zCa:
        $NXARd = "v2/hls/thumbnails/{$P9w4z}/";
        goto RcGG1;
        QBB0_:
        try {
            goto bcqBF;
            aPu6K:
            $EHLSS = $H785W->get('QueueUrl');
            goto jzi_a;
            jzi_a:
            $ob1gn->sendMessage(['QueueUrl' => $EHLSS, 'MessageBody' => json_encode(['file_path' => $jZqB7->getLocation()])]);
            goto MCfy1;
            bcqBF:
            $H785W = $ob1gn->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto aPu6K;
            MCfy1:
        } catch (\Throwable $fGlZL) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$fGlZL->getMessage()}");
        }
        goto RCp04;
        EHNCm:
        $ob1gn = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto QBB0_;
        RCp04:
        j82sl:
        goto YwK51;
        RcGG1:
        if (!(!$this->m2kWg->directoryExists($NXARd) && empty($jZqB7->mT5TzE9XKm8()))) {
            goto j82sl;
        }
        goto EHNCm;
        P9qni:
        Log::info("Use Lambda to generate thumbnail for video: " . $P9w4z);
        goto lv1wI;
        YwK51:
    }
    public function mLOddrHkNeg(string $P9w4z) : void
    {
        goto xMomV;
        xMomV:
        $jZqB7 = HVuLZHLrSam0d::findOrFail($P9w4z);
        goto fXGVJ;
        Dq0xT:
        $jZqB7->update(['generated_previews' => $NXARd]);
        goto Z1biA;
        dIrLg:
        if ($this->m2kWg->directoryExists($NXARd)) {
            goto BoJ1l;
        }
        goto waeTR;
        nYIWn:
        throw new \Exception("Message back with success data but not found thumbnail files " . $P9w4z);
        goto rCHhj;
        WkSq7:
        if (!(count($njpzc) === 0)) {
            goto AV44w;
        }
        goto T23zY;
        T23zY:
        Log::error("Message back with success data but not found thumbnail files " . $P9w4z);
        goto nYIWn;
        ZHRK8:
        $njpzc = $this->m2kWg->files($NXARd);
        goto WkSq7;
        rCHhj:
        AV44w:
        goto Dq0xT;
        fXGVJ:
        $NXARd = "v2/hls/thumbnails/{$P9w4z}/";
        goto dIrLg;
        Jb5Cs:
        BoJ1l:
        goto ZHRK8;
        Wr8J7:
        throw new \Exception("Message back with success data but not found thumbnail " . $P9w4z);
        goto Jb5Cs;
        waeTR:
        Log::error("Message back with success data but not found thumbnail " . $P9w4z);
        goto Wr8J7;
        Z1biA:
    }
    public function getThumbnails(string $P9w4z) : array
    {
        $jZqB7 = HVuLZHLrSam0d::findOrFail($P9w4z);
        return $jZqB7->getThumbnails();
    }
    public function getMedia(string $P9w4z) : array
    {
        $mDwO7 = Media::findOrFail($P9w4z);
        return $mDwO7->getView();
    }
}
