<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\ZP6Ky842t6y9Y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class LBGXGWApjgxw9 implements VideoPostHandleServiceInterface
{
    private $io8NS;
    private $UoQI7;
    public function __construct(UploadServiceInterface $t3TZw, Filesystem $UjVft)
    {
        $this->io8NS = $t3TZw;
        $this->UoQI7 = $UjVft;
    }
    public function saveMetadata(string $InHEz, array $CLKCW)
    {
        goto k9eB1;
        gAg4v:
        eEKnz:
        goto OaCos;
        inb3S:
        Log::warning("JPkW9ix1EKo3T metadata store failed for unknown reason ... " . $InHEz);
        goto g0JhB;
        nUL8X:
        I475x:
        goto mpsRd;
        APR0j:
        unset($EOid0['thumbnail']);
        goto nd8uJ;
        yU6K2:
        $EOid0['duration'] = $CLKCW['duration'];
        goto gwhKD;
        g0JhB:
        throw new \Exception("JPkW9ix1EKo3T metadata store failed for unknown reason ... " . $InHEz);
        goto JqdYk;
        lR34L:
        if (!(isset($CLKCW['change_status']) && $CLKCW['change_status'])) {
            goto mqK7W;
        }
        goto mFEWK;
        OaCos:
        if (!isset($CLKCW['thumbnail'])) {
            goto Ry4CG;
        }
        goto BgGTf;
        WUk_z:
        $EOid0['resolution'] = $CLKCW['resolution'];
        goto nUL8X;
        DMLYh:
        fpJtx:
        goto amkTu;
        BgGTf:
        try {
            goto GXvOa;
            iEaxv:
            $EOid0['thumbnail'] = $NnQOx['filename'];
            goto v_fXT;
            Wo0bN:
            $EOid0['thumbnail_id'] = $NnQOx['id'];
            goto iEaxv;
            GXvOa:
            $NnQOx = $this->io8NS->storeSingleFile(new class($CLKCW['thumbnail']) implements SingleUploadInterface
            {
                private $QEMhI;
                public function __construct($YEF57)
                {
                    $this->QEMhI = $YEF57;
                }
                public function getFile()
                {
                    return $this->QEMhI;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Wo0bN;
            v_fXT:
        } catch (\Throwable $bAo2Y) {
            Log::warning("JPkW9ix1EKo3T thumbnail store failed: " . $bAo2Y->getMessage());
        }
        goto JurD6;
        amkTu:
        if (!$qF0aQ->OFuJP) {
            goto WfuCI;
        }
        goto APR0j;
        mFEWK:
        $this->io8NS->updateFile($qF0aQ->getAttribute('id'), ZP6Ky842t6y9Y::PROCESSING);
        goto tQyWb;
        BdHR0:
        if (!isset($CLKCW['duration'])) {
            goto Pc1Nc;
        }
        goto yU6K2;
        k9eB1:
        $qF0aQ = JPkW9ix1EKo3T::findOrFail($InHEz);
        goto jiU0X;
        yqInx:
        if (!isset($CLKCW['resolution'])) {
            goto I475x;
        }
        goto WUk_z;
        JurD6:
        Ry4CG:
        goto BdHR0;
        gwhKD:
        Pc1Nc:
        goto yqInx;
        VDwEY:
        if (!$qF0aQ->update($EOid0)) {
            goto gM08V;
        }
        goto lR34L;
        UhSMU:
        $EOid0['fps'] = $CLKCW['fps'];
        goto DMLYh;
        x342a:
        gM08V:
        goto inb3S;
        Sqqce:
        $EOid0['thumbnail'] = $CLKCW['thumbnail_url'];
        goto gAg4v;
        mpsRd:
        if (!isset($CLKCW['fps'])) {
            goto fpJtx;
        }
        goto UhSMU;
        zd49Y:
        return $qF0aQ->getView();
        goto x342a;
        jiU0X:
        $EOid0 = [];
        goto Ut3jg;
        tQyWb:
        mqK7W:
        goto zd49Y;
        Ut3jg:
        if (!isset($CLKCW['thumbnail_url'])) {
            goto eEKnz;
        }
        goto Sqqce;
        nd8uJ:
        WfuCI:
        goto VDwEY;
        JqdYk:
    }
    public function createThumbnail(string $TZ9kY) : void
    {
        goto xmETF;
        RtnQx:
        if (!(!$this->UoQI7->directoryExists($Kx5MS) && empty($qF0aQ->mKxwmdskQMr()))) {
            goto kt8l1;
        }
        goto Vy4D6;
        pUkc_:
        $Kx5MS = "v2/hls/thumbnails/{$TZ9kY}/";
        goto RtnQx;
        VPAHq:
        $qF0aQ = JPkW9ix1EKo3T::findOrFail($TZ9kY);
        goto pUkc_;
        rtHy1:
        kt8l1:
        goto g3Pc5;
        Vy4D6:
        $h5Cx7 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto LA0W8;
        xmETF:
        Log::info("Use Lambda to generate thumbnail for video: " . $TZ9kY);
        goto VPAHq;
        LA0W8:
        try {
            goto R4b2y;
            R4b2y:
            $ro4eS = $h5Cx7->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto nmkq_;
            R4TMx:
            $h5Cx7->sendMessage(['QueueUrl' => $e8ELr, 'MessageBody' => json_encode(['file_path' => $qF0aQ->getLocation()])]);
            goto j2Zpn;
            nmkq_:
            $e8ELr = $ro4eS->get('QueueUrl');
            goto R4TMx;
            j2Zpn:
        } catch (\Throwable $uF3lz) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$uF3lz->getMessage()}");
        }
        goto rtHy1;
        g3Pc5:
    }
    public function mHbNzVGYjki(string $TZ9kY) : void
    {
        goto IIB87;
        vnOIU:
        if (!(count($esB70) === 0)) {
            goto AZS2_;
        }
        goto g_Xdy;
        CB_od:
        Log::error("Message back with success data but not found thumbnail " . $TZ9kY);
        goto eCtPn;
        s6vZ0:
        L400N:
        goto SwCUM;
        eCtPn:
        throw new \Exception("Message back with success data but not found thumbnail " . $TZ9kY);
        goto s6vZ0;
        VGTwa:
        if ($this->UoQI7->directoryExists($Kx5MS)) {
            goto L400N;
        }
        goto CB_od;
        EYx6_:
        $qF0aQ->update(['generated_previews' => $Kx5MS]);
        goto OYm8d;
        VqKUC:
        AZS2_:
        goto EYx6_;
        g_Xdy:
        Log::error("Message back with success data but not found thumbnail files " . $TZ9kY);
        goto wWK0f;
        SwCUM:
        $esB70 = $this->UoQI7->files($Kx5MS);
        goto vnOIU;
        wWK0f:
        throw new \Exception("Message back with success data but not found thumbnail files " . $TZ9kY);
        goto VqKUC;
        XsqCN:
        $Kx5MS = "v2/hls/thumbnails/{$TZ9kY}/";
        goto VGTwa;
        IIB87:
        $qF0aQ = JPkW9ix1EKo3T::findOrFail($TZ9kY);
        goto XsqCN;
        OYm8d:
    }
    public function getThumbnails(string $TZ9kY) : array
    {
        $qF0aQ = JPkW9ix1EKo3T::findOrFail($TZ9kY);
        return $qF0aQ->getThumbnails();
    }
    public function getMedia(string $TZ9kY) : array
    {
        $P82oP = Media::findOrFail($TZ9kY);
        return $P82oP->getView();
    }
}
