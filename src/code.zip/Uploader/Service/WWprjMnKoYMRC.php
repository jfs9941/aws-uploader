<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Core\UkjvJ3zCZNh6F;
use Jfs\Uploader\Core\TVInkZGE2Z8Ja;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
use Jfs\Uploader\Exception\CWn6V46ojDVJy;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Jfs\Uploader\Exception\AJ3Q8FcxdzdHb;
final class WWprjMnKoYMRC implements UploadServiceInterface
{
    private $y10O6;
    private $fodJQ;
    private $i9Sna;
    private $f16Yr;
    public function __construct(Fqe4ryAftaAFD $H1h34, Filesystem $nsgrL, Filesystem $moAxa, string $hdFO8)
    {
        goto k4POJ;
        vwihm:
        $this->fodJQ = $nsgrL;
        goto vhL3n;
        k4POJ:
        $this->y10O6 = $H1h34;
        goto vwihm;
        X8Dl4:
        $this->f16Yr = $hdFO8;
        goto b0eDr;
        vhL3n:
        $this->i9Sna = $moAxa;
        goto X8Dl4;
        b0eDr:
    }
    public function storeSingleFile(SingleUploadInterface $MuyIU) : array
    {
        goto VAQ3u;
        AeGOy:
        $lmCO9 = $this->i9Sna->putFileAs(dirname($TFA4Z->getLocation()), $MuyIU->getFile(), $TFA4Z->getFilename() . '.' . $TFA4Z->getExtension(), ['visibility' => 'public']);
        goto SicHT;
        VAQ3u:
        $TFA4Z = $this->y10O6->mPmak256rWq($MuyIU);
        goto AeGOy;
        TnSfq:
        E1HX0:
        goto bp8xd;
        VGcE1:
        tHfr0:
        goto Xzn3X;
        Xzn3X:
        return $TFA4Z->getView();
        goto UHXm0;
        SicHT:
        if (false !== $lmCO9 && $TFA4Z instanceof HpFoUL2Zq7Sem) {
            goto E1HX0;
        }
        goto V754s;
        V754s:
        throw new \LogicException('File upload failed, check permissions');
        goto D_QV7;
        D_QV7:
        goto tHfr0;
        goto TnSfq;
        bp8xd:
        $TFA4Z->mhK1eUHzFBK(Q5pXt73hTeTVP::UPLOADED);
        goto VGcE1;
        UHXm0:
    }
    public function storePreSignedFile(array $dyM7u)
    {
        goto IrQju;
        ovUCd:
        $y4PP7->mx86PeUtHxR($dyM7u['mime'], $dyM7u['file_size'], $dyM7u['chunk_size'], $dyM7u['checksums'], $dyM7u['user_id'], $dyM7u['driver']);
        goto wEj4g;
        bpoA5:
        $y4PP7 = TVInkZGE2Z8Ja::mVq9qo82Pv9($TFA4Z, $this->fodJQ, $this->i9Sna, $this->f16Yr, true);
        goto ovUCd;
        Kpl2d:
        return ['filename' => $y4PP7->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $y4PP7->mQ5l5Rz3Gya()];
        goto rqfpa;
        IrQju:
        $TFA4Z = $this->y10O6->mPmak256rWq($dyM7u);
        goto bpoA5;
        wEj4g:
        $y4PP7->mQ3Hz0K13wy();
        goto Kpl2d;
        rqfpa:
    }
    public function updatePreSignedFile(string $aE1_B, int $QLXaJ)
    {
        goto Igv_j;
        mYcg4:
        NLxxW:
        goto QAhD1;
        gxNVH:
        switch ($QLXaJ) {
            case Q5pXt73hTeTVP::UPLOADED:
                $y4PP7->m2odgyXv0kz();
                goto YKM_m;
            case Q5pXt73hTeTVP::PROCESSING:
                $y4PP7->mZjDGQM2XwH();
                goto YKM_m;
            case Q5pXt73hTeTVP::FINISHED:
                $y4PP7->mbd2W2I8k2m();
                goto YKM_m;
            case Q5pXt73hTeTVP::ABORTED:
                $y4PP7->m9tUPySfwFH();
                goto YKM_m;
        }
        goto mYcg4;
        Igv_j:
        $y4PP7 = TVInkZGE2Z8Ja::mhsqHynhNgV($aE1_B, $this->fodJQ, $this->i9Sna, $this->f16Yr);
        goto gxNVH;
        QAhD1:
        YKM_m:
        goto B48kg;
        B48kg:
    }
    public function completePreSignedFile(string $aE1_B, array $u2DUU)
    {
        goto KGUPZ;
        OlQdx:
        return ['path' => $y4PP7->getFile()->getView()['path'], 'thumbnail' => $y4PP7->getFile()->pxIiA, 'id' => $aE1_B];
        goto UAMPf;
        KGUPZ:
        $y4PP7 = TVInkZGE2Z8Ja::mhsqHynhNgV($aE1_B, $this->fodJQ, $this->i9Sna, $this->f16Yr);
        goto pW5e0;
        pW5e0:
        $y4PP7->mlnKeX4eawe()->mB7eRZmk2xa($u2DUU);
        goto r07U_;
        r07U_:
        $y4PP7->m2odgyXv0kz();
        goto OlQdx;
        UAMPf:
    }
    public function updateFile(string $aE1_B, int $QLXaJ) : UkjvJ3zCZNh6F
    {
        goto lMtaV;
        wRDo6:
        $TFA4Z->mhK1eUHzFBK($QLXaJ);
        goto AzI7X;
        lMtaV:
        $TFA4Z = $this->y10O6->mNcRAQdwyxl($aE1_B);
        goto wRDo6;
        AzI7X:
        return $TFA4Z;
        goto GuGJE;
        GuGJE:
    }
}
