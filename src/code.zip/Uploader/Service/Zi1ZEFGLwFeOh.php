<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\Q5pXt73hTeTVP;
final class Zi1ZEFGLwFeOh implements VideoPostHandleServiceInterface
{
    private $g7Tvj;
    private $qrvF0;
    public function __construct(UploadServiceInterface $Czn8i, Filesystem $eG_Pc)
    {
        $this->g7Tvj = $Czn8i;
        $this->qrvF0 = $eG_Pc;
    }
    public function saveMetadata(string $ElvKF, array $xf_XV)
    {
        goto PM34Y;
        gyAQw:
        if (!(isset($xf_XV['change_status']) && $xf_XV['change_status'])) {
            goto bSKt4;
        }
        goto VxP_v;
        HYiX_:
        if (!isset($xf_XV['thumbnail'])) {
            goto muMaZ;
        }
        goto UXGeP;
        ysey5:
        if (!isset($xf_XV['fps'])) {
            goto xhWjf;
        }
        goto IZjyW;
        gQSOC:
        vs3O8:
        goto ysey5;
        l18O3:
        bSKt4:
        goto g9Iht;
        g9Iht:
        return $eYbzj->getView();
        goto xQEjf;
        KwpAr:
        muMaZ:
        goto SRWQr;
        IZjyW:
        $ifpKJ['fps'] = $xf_XV['fps'];
        goto yludQ;
        UXGeP:
        try {
            goto WHFBh;
            WHFBh:
            $I_Zk6 = $this->g7Tvj->storeSingleFile(new class($xf_XV['thumbnail']) implements SingleUploadInterface
            {
                private $PV7YF;
                public function __construct($TFA4Z)
                {
                    $this->PV7YF = $TFA4Z;
                }
                public function getFile()
                {
                    return $this->PV7YF;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto XzvTP;
            XzvTP:
            $ifpKJ['thumbnail_id'] = $I_Zk6['id'];
            goto imqdV;
            imqdV:
            $ifpKJ['thumbnail'] = $I_Zk6['filename'];
            goto fU6BX;
            fU6BX:
        } catch (\Throwable $xlNa7) {
            Log::warning("UMeQT1ArE1U05 thumbnail store failed: " . $xlNa7->getMessage());
        }
        goto KwpAr;
        I3s2r:
        if (!$eYbzj->update($ifpKJ)) {
            goto aZA62;
        }
        goto gyAQw;
        PM34Y:
        $eYbzj = UMeQT1ArE1U05::findOrFail($ElvKF);
        goto XwbUP;
        L3Mi1:
        if (!isset($xf_XV['resolution'])) {
            goto vs3O8;
        }
        goto uHLFL;
        i5LXK:
        XLeXJ:
        goto L3Mi1;
        uHLFL:
        $ifpKJ['resolution'] = $xf_XV['resolution'];
        goto gQSOC;
        XwbUP:
        $ifpKJ = [];
        goto HYiX_;
        bqfwZ:
        $ifpKJ['duration'] = $xf_XV['duration'];
        goto i5LXK;
        xQEjf:
        aZA62:
        goto wj4su;
        SRWQr:
        if (!isset($xf_XV['duration'])) {
            goto XLeXJ;
        }
        goto bqfwZ;
        fvn6v:
        throw new \Exception("UMeQT1ArE1U05 metadata store failed for unknown reason ... " . $ElvKF);
        goto iHeTk;
        yludQ:
        xhWjf:
        goto I3s2r;
        wj4su:
        Log::warning("UMeQT1ArE1U05 metadata store failed for unknown reason ... " . $ElvKF);
        goto fvn6v;
        VxP_v:
        $this->g7Tvj->updateFile($eYbzj->getAttribute('id'), Q5pXt73hTeTVP::PROCESSING);
        goto l18O3;
        iHeTk:
    }
    public function createThumbnail(string $aE1_B) : void
    {
        goto jLzFS;
        rS30_:
        $LNc0i = "v2/hls/thumbnails/{$aE1_B}/";
        goto nGsw0;
        LClpc:
        $uyBKT = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto vIIiD;
        jLzFS:
        Log::info("Use Lambda to generate thumbnail for video: " . $aE1_B);
        goto haErZ;
        haErZ:
        $eYbzj = UMeQT1ArE1U05::findOrFail($aE1_B);
        goto rS30_;
        vIIiD:
        try {
            goto iT447;
            iT447:
            $M3Yy_ = $uyBKT->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto fw0CU;
            Qr9mL:
            $uyBKT->sendMessage(['QueueUrl' => $Yqk4m, 'MessageBody' => json_encode(['file_path' => $eYbzj->getLocation()])]);
            goto UQ4XD;
            fw0CU:
            $Yqk4m = $M3Yy_->get('QueueUrl');
            goto Qr9mL;
            UQ4XD:
        } catch (\Throwable $vGb1d) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$vGb1d->getMessage()}");
        }
        goto I83nB;
        nGsw0:
        if (!(!$this->qrvF0->directoryExists($LNc0i) && empty($eYbzj->mM4X26Op2hl()))) {
            goto O1A99;
        }
        goto LClpc;
        I83nB:
        O1A99:
        goto MxUsv;
        MxUsv:
    }
    public function mxCHq1EbvVa(string $aE1_B) : void
    {
        goto l5qS1;
        k3xE7:
        Log::error("Message back with success data but not found thumbnail " . $aE1_B);
        goto CtVwz;
        l5qS1:
        $eYbzj = UMeQT1ArE1U05::findOrFail($aE1_B);
        goto pxg8J;
        nJjRq:
        Log::error("Message back with success data but not found thumbnail files " . $aE1_B);
        goto zmPDq;
        pxg8J:
        $LNc0i = "v2/hls/thumbnails/{$aE1_B}/";
        goto Dggm2;
        CtVwz:
        throw new \Exception("Message back with success data but not found thumbnail " . $aE1_B);
        goto kt_MT;
        Dggm2:
        if ($this->qrvF0->directoryExists($LNc0i)) {
            goto CHPYZ;
        }
        goto k3xE7;
        zmPDq:
        throw new \Exception("Message back with success data but not found thumbnail files " . $aE1_B);
        goto Gr_Qo;
        EKULu:
        $YqCWq = $this->qrvF0->files($LNc0i);
        goto xIxK8;
        izeGc:
        $eYbzj->update(['generated_previews' => $LNc0i]);
        goto t03cp;
        Gr_Qo:
        if3NJ:
        goto izeGc;
        kt_MT:
        CHPYZ:
        goto EKULu;
        xIxK8:
        if (!(count($YqCWq) === 0)) {
            goto if3NJ;
        }
        goto nJjRq;
        t03cp:
    }
    public function getThumbnails(string $aE1_B) : array
    {
        $eYbzj = UMeQT1ArE1U05::findOrFail($aE1_B);
        return $eYbzj->getThumbnails();
    }
}
