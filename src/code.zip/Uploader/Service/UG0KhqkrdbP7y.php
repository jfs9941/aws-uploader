<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Core\Observer\Ad0kM8s4uFNGP;
use Jfs\Uploader\Core\Observer\Rl3CLrtPgaz2O;
use Jfs\Uploader\Core\En8A7e3KRqXQ0;
use Jfs\Uploader\Core\QeUknjvnDpCFf;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Exception\B3AeVUIqKwlr4;
use Jfs\Uploader\Service\FileResolver\H01EOIlyzOh6S;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class UG0KhqkrdbP7y
{
    private $vpxdN;
    private $c5PSU;
    private $BfyCm;
    public function __construct($SCzIm, $Ape3_, $ejImE)
    {
        goto HRivi;
        klMy_:
        $this->BfyCm = $ejImE;
        goto PnXox;
        oQtvq:
        $this->c5PSU = $Ape3_;
        goto klMy_;
        HRivi:
        $this->vpxdN = $SCzIm;
        goto oQtvq;
        PnXox:
    }
    public function m4VrCkMB9Yn($O1a5E)
    {
        goto UgWTL;
        vrat5:
        $Y1lVb = $O1a5E->getFile();
        goto jqE32;
        UgWTL:
        if (!$O1a5E instanceof SingleUploadInterface) {
            goto Ml9Rn;
        }
        goto vrat5;
        oWT12:
        return $this->mpgWL5Dx4Yd($O1a5E['file_extension'], 's3' === $O1a5E['driver'] ? ZuZC67ch9j73R::S3 : ZuZC67ch9j73R::LOCAL);
        goto BQCR8;
        NUxv2:
        Ml9Rn:
        goto oWT12;
        jqE32:
        return $this->mpgWL5Dx4Yd($Y1lVb->extension(), ZuZC67ch9j73R::S3, null, $O1a5E->options());
        goto NUxv2;
        BQCR8:
    }
    public function m0MzbMShfS0(string $aK0gt)
    {
        goto s6FFf;
        s6FFf:
        $ZygbT = config('upload.attachment_model')::findOrFail($aK0gt);
        goto LlfI0;
        LlfI0:
        $s2INV = $this->mpgWL5Dx4Yd($ZygbT->getAttribute('type'), $ZygbT->getAttribute('driver'), $ZygbT->getAttribute('id'));
        goto jLE7Q;
        Z2DRJ:
        return $s2INV;
        goto JEQG1;
        oAkoM:
        $s2INV->setRawAttributes($ZygbT->getAttributes());
        goto Z2DRJ;
        jLE7Q:
        $s2INV->exists = true;
        goto oAkoM;
        JEQG1:
    }
    public function mxX6QwgrEaW(string $OZQS1) : QguGxHrrpjTia
    {
        goto S94kr;
        DcYH7:
        c3OMi:
        goto x0f2B;
        OkVIe:
        if (!$j1WQY) {
            goto c3OMi;
        }
        goto WltsU;
        S94kr:
        $EGMVX = $this->c5PSU->get($OZQS1);
        goto KB9wF;
        KB9wF:
        if ($EGMVX) {
            goto X9lsG;
        }
        goto WCVji;
        x0f2B:
        throw new XEcmSsCY89ji0('metadata file not found');
        goto jq4MX;
        WltsU:
        $lTtg8 = QeUknjvnDpCFf::mYS380Xuxy2($j1WQY);
        goto aTCOj;
        L2UPH:
        $j1WQY = json_decode($EGMVX, true);
        goto OkVIe;
        que1h:
        X9lsG:
        goto L2UPH;
        aTCOj:
        return $this->mpgWL5Dx4Yd($lTtg8->RrB1K, $lTtg8->mXr1uBNwdLJ(), $lTtg8->filename);
        goto DcYH7;
        WCVji:
        $EGMVX = $this->BfyCm->get($OZQS1);
        goto que1h;
        jq4MX:
    }
    private function mpgWL5Dx4Yd(string $CKu1g, $RsM0s, ?string $aK0gt = null, array $GNSO9 = [])
    {
        goto BHXku;
        BHXku:
        $aK0gt = $aK0gt ?? Uuid::uuid4()->getHex()->toString();
        goto BOo9Q;
        ZNOsL:
        $rneSb->m8X5yYN5PxJ(new Ad0kM8s4uFNGP($rneSb));
        goto rSC21;
        BOo9Q:
        switch ($CKu1g) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $rneSb = MpPzMcfcRTISZ::createFromScratch($aK0gt, $CKu1g);
                goto JK8GS;
            case 'mp4':
            case 'mov':
                $rneSb = IfBHv1AJhiIDu::createFromScratch($aK0gt, $CKu1g);
                goto JK8GS;
            case 'pdf':
                $rneSb = En8A7e3KRqXQ0::createFromScratch($aK0gt, $CKu1g);
                goto JK8GS;
            default:
                throw new B3AeVUIqKwlr4("not support file type {$CKu1g}");
        }
        goto ZNXZQ;
        Wrbmk:
        JK8GS:
        goto rclh1;
        XAJJV:
        BkVJx:
        goto qjfOe;
        qjfOe:
        throw new B3AeVUIqKwlr4("not support file type {$CKu1g}");
        goto uKodu;
        HWm3T:
        foreach ($this->vpxdN as $Upw6m) {
            goto MXzcV;
            ZYPlx:
            ojjIm:
            goto i6VRA;
            MXzcV:
            if (!$Upw6m->mrhZmHyyvU4($rneSb)) {
                goto zHspa;
            }
            goto AbfDI;
            FH3ba:
            zHspa:
            goto ZYPlx;
            AbfDI:
            return $rneSb->initLocation($Upw6m->mvcG6A09lVY($rneSb));
            goto FH3ba;
            i6VRA:
        }
        goto XAJJV;
        ZNXZQ:
        I5ugR:
        goto Wrbmk;
        rclh1:
        $rneSb = $rneSb->m5HAmARgDxI($RsM0s);
        goto ZNOsL;
        rSC21:
        $rneSb->m8X5yYN5PxJ(new Rl3CLrtPgaz2O($rneSb, $this->BfyCm, $GNSO9));
        goto HWm3T;
        uKodu:
    }
}
