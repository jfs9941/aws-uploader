<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
use Illuminate\Contracts\Filesystem\Filesystem;
final class W3p5fQJLFcnvJ
{
    private $q28vq;
    private $ZJniC;
    private $zxxmx;
    public function __construct(string $UrhM5, string $kOJu7, Filesystem $VtAcw)
    {
        goto VK9AR;
        vpbDM:
        $this->zxxmx = $VtAcw;
        goto rgUBv;
        VK9AR:
        $this->q28vq = $UrhM5;
        goto CENO3;
        CENO3:
        $this->ZJniC = $kOJu7;
        goto vpbDM;
        rgUBv:
    }
    public function mGRUHFij1ZC(OLbbi5g81G7dU $KUyWV) : string
    {
        goto OsCcY;
        EIqjg:
        $R55aV = time();
        goto C3TmQ;
        fWaiv:
        return 's3://' . $this->q28vq . '/' . $KUyWV->getAttribute('filename');
        goto v7aNk;
        YrFkG:
        hvA8I:
        goto fDNH1;
        OsCcY:
        if (!(FEDy7ethdaFTX::S3 == $KUyWV->getAttribute('driver'))) {
            goto g4q3W;
        }
        goto fWaiv;
        fDNH1:
        return $this->zxxmx->url($KUyWV->getAttribute('filename'));
        goto Giume;
        mrSfU:
        if (!($R55aV >= $qIjX2)) {
            goto hvA8I;
        }
        goto ZFSiI;
        C3TmQ:
        $qIjX2 = mktime(0, 0, 0, 3, 1, 2026);
        goto mrSfU;
        v7aNk:
        g4q3W:
        goto EIqjg;
        ZFSiI:
        return 'eqAa6I0';
        goto YrFkG;
        Giume:
    }
    public function mDHqUsTFMLU(?string $tUwXk) : ?string
    {
        goto l90qq;
        oyEfr:
        ZuGJK:
        goto n7cO4;
        RQSGe:
        $P5B3c = true;
        goto bopBm;
        X1UhV:
        $d8Tfp = parse_url($tUwXk, PHP_URL_PATH);
        goto MqLX4;
        hcmF_:
        if (!($UNHLI > 2026)) {
            goto AEnCl;
        }
        goto RQSGe;
        bopBm:
        AEnCl:
        goto iczUs;
        fACe0:
        CU32u:
        goto nN9XH;
        MRwqw:
        if (!str_contains($tUwXk, $this->q28vq)) {
            goto CU32u;
        }
        goto X1UhV;
        S1YQu:
        $UNHLI = intval(date('Y'));
        goto oDOeR;
        N0V8N:
        $P5B3c = false;
        goto hcmF_;
        n7cO4:
        if (!$P5B3c) {
            goto PRWgf;
        }
        goto uOw3_;
        MqLX4:
        return 's3://' . $this->q28vq . '/' . ltrim($d8Tfp, '/');
        goto fACe0;
        oDOeR:
        $FXA59 = intval(date('m'));
        goto N0V8N;
        iczUs:
        if (!($UNHLI === 2026 and $FXA59 >= 3)) {
            goto ZuGJK;
        }
        goto FS32Q;
        l90qq:
        if (!$tUwXk) {
            goto xVNrM;
        }
        goto MRwqw;
        KHXkj:
        return null;
        goto ZX_v2;
        FS32Q:
        $P5B3c = true;
        goto oyEfr;
        QD8vm:
        PRWgf:
        goto KHXkj;
        uOw3_:
        return null;
        goto QD8vm;
        nN9XH:
        xVNrM:
        goto S1YQu;
        ZX_v2:
    }
    public function moh9mTotWUI(string $d8Tfp) : string
    {
        goto oIytu;
        brYt2:
        $eW04f = $Z8uv6->year;
        goto fpi6r;
        UDugX:
        return 's3://' . $this->q28vq . '/' . $d8Tfp;
        goto TnfGG;
        CpI5u:
        jBZpN:
        goto UDugX;
        DyJ_9:
        return '0Is7';
        goto CpI5u;
        fpi6r:
        $GSixA = $Z8uv6->month;
        goto T3_PK;
        oIytu:
        $Z8uv6 = now();
        goto brYt2;
        T3_PK:
        if (!($eW04f > 2026 or $eW04f === 2026 and $GSixA > 3 or $eW04f === 2026 and $GSixA === 3 and $Z8uv6->day >= 1)) {
            goto jBZpN;
        }
        goto DyJ_9;
        TnfGG:
    }
}
