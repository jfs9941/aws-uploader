<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Core\Observer\CoATXhCrVwYZs;
use Jfs\Uploader\Core\Observer\CSlB1hwdQhS6x;
use Jfs\Uploader\Core\IFOKBvW1HTPmz;
use Jfs\Uploader\Core\XXOVbK7SeD5pn;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Exception\YIRQaRmojMDyD;
use Jfs\Uploader\Service\FileResolver\UioryE8ZMrMRb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class ZZ32LbChqQKFG
{
    private $B_btD;
    private $ZPzJH;
    private $bLZP5;
    public function __construct($RHGhq, $G3exm, $C1By6)
    {
        goto dmA5o;
        dmA5o:
        $this->B_btD = $RHGhq;
        goto UmGi4;
        C7l8M:
        $this->bLZP5 = $C1By6;
        goto sWpcb;
        UmGi4:
        $this->ZPzJH = $G3exm;
        goto C7l8M;
        sWpcb:
    }
    public function mVYQ2BeVof6($tIb8s)
    {
        goto DSvN2;
        DSvN2:
        if (!$tIb8s instanceof SingleUploadInterface) {
            goto lr6tm;
        }
        goto KvoFI;
        aZyLD:
        return $this->md9CSIv52DM($tIb8s['file_extension'], 's3' === $tIb8s['driver'] ? KkaUVP3OQvOtp::S3 : KkaUVP3OQvOtp::LOCAL);
        goto K5Tdw;
        O0cxq:
        return $this->md9CSIv52DM($aeIOI->extension(), KkaUVP3OQvOtp::S3, null, $tIb8s->options());
        goto KxHFA;
        KvoFI:
        $aeIOI = $tIb8s->getFile();
        goto O0cxq;
        KxHFA:
        lr6tm:
        goto aZyLD;
        K5Tdw:
    }
    public function mIxY0jRYaf1(string $DWjir)
    {
        goto YTZ1m;
        H66Ko:
        return $nbWJE;
        goto m23B6;
        LWF_U:
        $nbWJE->setRawAttributes($ks3oC->getAttributes());
        goto H66Ko;
        ikAyD:
        $nbWJE = $this->md9CSIv52DM($ks3oC->getAttribute('type'), $ks3oC->getAttribute('driver'), $ks3oC->getAttribute('id'));
        goto iPvzA;
        YTZ1m:
        $ks3oC = config('upload.attachment_model')::findOrFail($DWjir);
        goto ikAyD;
        iPvzA:
        $nbWJE->exists = true;
        goto LWF_U;
        m23B6:
    }
    public function mR8BiHWgoQR(string $Gaoh0) : F9PXWR72LBMoZ
    {
        goto aVM4e;
        aVM4e:
        $LOE_G = $this->ZPzJH->get($Gaoh0);
        goto ZjBG1;
        eHrTG:
        $nqIut = XXOVbK7SeD5pn::m5NrbL3FbvV($PSxFL);
        goto DLSti;
        AmUC6:
        XlG9I:
        goto djDSM;
        djDSM:
        $PSxFL = json_decode($LOE_G, true);
        goto sL8Ae;
        gbMYh:
        $LOE_G = $this->bLZP5->get($Gaoh0);
        goto AmUC6;
        BKrhB:
        throw new CB5eg0zuzdVv8('metadata file not found');
        goto p8zz4;
        AFDWQ:
        oEfBK:
        goto BKrhB;
        sL8Ae:
        if (!$PSxFL) {
            goto oEfBK;
        }
        goto eHrTG;
        ZjBG1:
        if ($LOE_G) {
            goto XlG9I;
        }
        goto gbMYh;
        DLSti:
        return $this->md9CSIv52DM($nqIut->qt3V6, $nqIut->mdf0USGjs5G(), $nqIut->filename);
        goto AFDWQ;
        p8zz4:
    }
    private function md9CSIv52DM(string $JZtiC, $A84dK, ?string $DWjir = null, array $fjrI6 = [])
    {
        goto lNZzr;
        h3Dq3:
        $LsFCw->mPghak6SKwq(new CSlB1hwdQhS6x($LsFCw, $this->bLZP5, $fjrI6));
        goto uOwlB;
        k6YVk:
        wIBrB:
        goto q_Q7c;
        lNZzr:
        $DWjir = $DWjir ?? Uuid::uuid4()->getHex()->toString();
        goto gmyvB;
        gmyvB:
        switch ($JZtiC) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $LsFCw = IQJN6V0t7DC7c::createFromScratch($DWjir, $JZtiC);
                goto BSLvu;
            case 'mp4':
            case 'mov':
                $LsFCw = J7sRaWo8um3yO::createFromScratch($DWjir, $JZtiC);
                goto BSLvu;
            case 'pdf':
                $LsFCw = IFOKBvW1HTPmz::createFromScratch($DWjir, $JZtiC);
                goto BSLvu;
            default:
                throw new YIRQaRmojMDyD("not support file type {$JZtiC}");
        }
        goto yl07p;
        yl07p:
        BwxFM:
        goto o9kKJ;
        dff2q:
        $LsFCw = $LsFCw->mkrv0g8HFnn($A84dK);
        goto ze9y2;
        q_Q7c:
        throw new YIRQaRmojMDyD("not support file type {$JZtiC}");
        goto m7n3A;
        ze9y2:
        $LsFCw->mPghak6SKwq(new CoATXhCrVwYZs($LsFCw));
        goto h3Dq3;
        o9kKJ:
        BSLvu:
        goto dff2q;
        uOwlB:
        foreach ($this->B_btD as $IEOZW) {
            goto gCLZE;
            J5Ie6:
            ygyqD:
            goto wFd5D;
            gCLZE:
            if (!$IEOZW->mhxeHYl2m9g($LsFCw)) {
                goto ygyqD;
            }
            goto DtBzO;
            DtBzO:
            return $LsFCw->initLocation($IEOZW->mkNRCD3SXo1($LsFCw));
            goto J5Ie6;
            wFd5D:
            aZ79G:
            goto Xknxa;
            Xknxa:
        }
        goto k6YVk;
        m7n3A:
    }
}
