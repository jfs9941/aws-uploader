<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Core\Observer\IuCSRQJyNQ7L0;
use Jfs\Uploader\Core\Observer\Ks8FIG92YhfLc;
use Jfs\Uploader\Core\GPZ0EQoHpj04q;
use Jfs\Uploader\Core\KHzXmciCVGzLc;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Exception\KQCoJb7DnfcxZ;
use Jfs\Uploader\Service\FileResolver\TPvC7BatUSSwb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class EJdnYZtMjtUUp
{
    private $gbggl;
    private $GUhIK;
    private $ZN9hu;
    public function __construct($g3nEa, $kGo1c, $C2YXG)
    {
        goto n6Fd9;
        b9wB1:
        $this->GUhIK = $kGo1c;
        goto G72Nn;
        G72Nn:
        $this->ZN9hu = $C2YXG;
        goto ps4vA;
        n6Fd9:
        $this->gbggl = $g3nEa;
        goto b9wB1;
        ps4vA:
    }
    public function mGiOPQ9gXel($RmpMA)
    {
        goto P2ICd;
        P2ICd:
        if (!$RmpMA instanceof SingleUploadInterface) {
            goto wOi0R;
        }
        goto lsivJ;
        ITSYa:
        return $this->meM4AUYk4HT($RmpMA['file_extension'], 's3' === $RmpMA['driver'] ? VNuaYSNcfVlT5::S3 : VNuaYSNcfVlT5::LOCAL);
        goto Ty9Vg;
        PoEoM:
        return $this->meM4AUYk4HT($pqvp9->extension(), VNuaYSNcfVlT5::S3, null, $RmpMA->options());
        goto YCNGz;
        lsivJ:
        $pqvp9 = $RmpMA->getFile();
        goto PoEoM;
        YCNGz:
        wOi0R:
        goto ITSYa;
        Ty9Vg:
    }
    public function mEO5B1SrbJB(string $uuHkQ)
    {
        goto cH6YA;
        cH6YA:
        $uQMyN = config('upload.attachment_model')::findOrFail($uuHkQ);
        goto oVzN2;
        Uh3PS:
        $DejZC->setRawAttributes($uQMyN->getAttributes());
        goto lEgFJ;
        oVzN2:
        $DejZC = $this->meM4AUYk4HT($uQMyN->getAttribute('type'), $uQMyN->getAttribute('driver'), $uQMyN->getAttribute('id'));
        goto PSGBG;
        lEgFJ:
        return $DejZC;
        goto yE3XW;
        PSGBG:
        $DejZC->exists = true;
        goto Uh3PS;
        yE3XW:
    }
    public function mwXd6exkzqF(string $h7v2K) : SOB6nK7CGVegh
    {
        goto Yl3dP;
        OVJId:
        if ($nNKlU) {
            goto u_pMo;
        }
        goto RA6n6;
        jdwOn:
        $EctgY = KHzXmciCVGzLc::mlMxIdLqjuU($i4bQp);
        goto Y_7lp;
        ZGDC0:
        $i4bQp = json_decode($nNKlU, true);
        goto VMIj1;
        VMIj1:
        if (!$i4bQp) {
            goto S73d1;
        }
        goto jdwOn;
        jNrK8:
        u_pMo:
        goto ZGDC0;
        REsqz:
        S73d1:
        goto yd7jk;
        yd7jk:
        throw new Pl4WlsTHZq9V7('metadata file not found');
        goto GZ1b3;
        RA6n6:
        $nNKlU = $this->ZN9hu->get($h7v2K);
        goto jNrK8;
        Yl3dP:
        $nNKlU = $this->GUhIK->get($h7v2K);
        goto OVJId;
        Y_7lp:
        return $this->meM4AUYk4HT($EctgY->kkcKh, $EctgY->m3S3ukXw02k(), $EctgY->filename);
        goto REsqz;
        GZ1b3:
    }
    private function meM4AUYk4HT(string $BhZGI, $U_6aW, ?string $uuHkQ = null, array $bJnIM = [])
    {
        goto aORC7;
        p0vAk:
        $shE7i->mdS7hIgNvPC(new IuCSRQJyNQ7L0($shE7i));
        goto j5EkH;
        z4cNm:
        e26zd:
        goto COeQT;
        j5EkH:
        $shE7i->mdS7hIgNvPC(new Ks8FIG92YhfLc($shE7i, $this->ZN9hu, $bJnIM));
        goto QBjNb;
        COeQT:
        UZcsQ:
        goto wkMrQ;
        zsoEg:
        switch ($BhZGI) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $shE7i = QFoN7Ibbm93if::createFromScratch($uuHkQ, $BhZGI);
                goto UZcsQ;
            case 'mp4':
            case 'mov':
                $shE7i = WrCq6RmnGcVh7::createFromScratch($uuHkQ, $BhZGI);
                goto UZcsQ;
            case 'pdf':
                $shE7i = GPZ0EQoHpj04q::createFromScratch($uuHkQ, $BhZGI);
                goto UZcsQ;
            default:
                throw new KQCoJb7DnfcxZ("not support file type {$BhZGI}");
        }
        goto z4cNm;
        aORC7:
        $uuHkQ = $uuHkQ ?? Uuid::uuid4()->getHex()->toString();
        goto zsoEg;
        QBjNb:
        foreach ($this->gbggl as $Y5OI2) {
            goto qOpo6;
            qKets:
            fWyhy:
            goto fauqs;
            fauqs:
            GdDw8:
            goto zisQh;
            SACvU:
            return $shE7i->initLocation($Y5OI2->mnkMEbTAHB9($shE7i));
            goto qKets;
            qOpo6:
            if (!$Y5OI2->mz3nF5W6NWk($shE7i)) {
                goto fWyhy;
            }
            goto SACvU;
            zisQh:
        }
        goto aiLCq;
        wkMrQ:
        $shE7i = $shE7i->mjOpMrHF08N($U_6aW);
        goto p0vAk;
        tCm90:
        throw new KQCoJb7DnfcxZ("not support file type {$BhZGI}");
        goto nL1tz;
        aiLCq:
        KsJEH:
        goto tCm90;
        nL1tz:
    }
}
