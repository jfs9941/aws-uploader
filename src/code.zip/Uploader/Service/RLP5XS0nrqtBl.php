<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\VH6naaofz5IuZ;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Core\Observer\PFasU3Jn9742f;
use Jfs\Uploader\Core\Observer\IRilQlp89k7ga;
use Jfs\Uploader\Core\WabYRJvOEOksh;
use Jfs\Uploader\Core\LwEuADzdXxX43;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
use Jfs\Uploader\Exception\GoWX7Rl7j3VtX;
use Jfs\Uploader\Exception\WgiszEiQkEJPG;
use Jfs\Uploader\Service\FileResolver\BXlzeSomKKkd4;
use Ramsey\Uuid\Uuid;
final class RLP5XS0nrqtBl
{
    private $Sjj0v;
    private $Hf14x;
    private $MV0lK;
    public function __construct($aXdgx, $p1fCH, $tYsty)
    {
        goto yJsD5;
        Ak9m5:
        $this->Hf14x = $p1fCH;
        goto agVcI;
        yJsD5:
        $this->Sjj0v = $aXdgx;
        goto Ak9m5;
        agVcI:
        $this->MV0lK = $tYsty;
        goto bC_7U;
        bC_7U:
    }
    public function mqS9kASZOme($EgdaE)
    {
        goto uAcf0;
        kqM1C:
        return $this->m0plmw0jmbD($SQqRt->extension(), N0ISad2bKF2Yp::S3, null, $EgdaE->options());
        goto qeaGY;
        p6vhW:
        $SQqRt = $EgdaE->getFile();
        goto kqM1C;
        uAcf0:
        if (!$EgdaE instanceof SingleUploadInterface) {
            goto vZ23g;
        }
        goto p6vhW;
        qeaGY:
        vZ23g:
        goto XhuRd;
        XhuRd:
        return $this->m0plmw0jmbD($EgdaE['file_extension'], 's3' === $EgdaE['driver'] ? N0ISad2bKF2Yp::S3 : N0ISad2bKF2Yp::LOCAL);
        goto HVHyC;
        HVHyC:
    }
    public function mX3gJ2vlhl7(string $FILUb)
    {
        goto lKYI0;
        rFJvu:
        return $I2SbP;
        goto G7Aa2;
        CuQbt:
        $I2SbP = $this->m0plmw0jmbD($kvzTH->getAttribute('type'), $kvzTH->getAttribute('driver'), $kvzTH->getAttribute('id'));
        goto DCnC5;
        lKYI0:
        $kvzTH = config('upload.attachment_model')::findOrFail($FILUb);
        goto CuQbt;
        DCnC5:
        $I2SbP->exists = true;
        goto ciC27;
        ciC27:
        $I2SbP->setRawAttributes($kvzTH->getAttributes());
        goto rFJvu;
        G7Aa2:
    }
    public function mlImLDi7VHC(string $zBaJI) : VH6naaofz5IuZ
    {
        goto m3q8A;
        DeO7e:
        if (!$Cva33) {
            goto fGRif;
        }
        goto eRyEB;
        m3q8A:
        $YU0Db = $this->Hf14x->get($zBaJI);
        goto qjMQc;
        eRyEB:
        $D8zcb = LwEuADzdXxX43::mgaobc77vO7($Cva33);
        goto o1PD2;
        a6Gmw:
        $YU0Db = $this->MV0lK->get($zBaJI);
        goto DjA1U;
        DlRRs:
        fGRif:
        goto HGMNt;
        DjA1U:
        z946A:
        goto ixIv9;
        HGMNt:
        throw new GoWX7Rl7j3VtX('metadata file not found');
        goto b6z_S;
        ixIv9:
        $Cva33 = json_decode($YU0Db, true);
        goto DeO7e;
        qjMQc:
        if ($YU0Db) {
            goto z946A;
        }
        goto a6Gmw;
        o1PD2:
        return $this->m0plmw0jmbD($D8zcb->zFvPC, $D8zcb->myxGNaRTrut(), $D8zcb->filename);
        goto DlRRs;
        b6z_S:
    }
    private function m0plmw0jmbD(string $lxg_s, $C83JB, ?string $FILUb = null, array $j7R1u = [])
    {
        goto whIG1;
        ADci_:
        $KTvJz->mcp2uALDwNg(new PFasU3Jn9742f($KTvJz));
        goto YKQ00;
        NiNKh:
        switch ($lxg_s) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $KTvJz = XbYF8aa0XyGnI::createFromScratch($FILUb, $lxg_s);
                goto F4KzC;
            case 'mp4':
            case 'mov':
                $KTvJz = CUaMUcjkFHEwK::createFromScratch($FILUb, $lxg_s);
                goto F4KzC;
            case 'pdf':
                $KTvJz = WabYRJvOEOksh::createFromScratch($FILUb, $lxg_s);
                goto F4KzC;
            default:
                throw new WgiszEiQkEJPG("not support file type {$lxg_s}");
        }
        goto CnQOD;
        whIG1:
        $FILUb = $FILUb ?? Uuid::uuid4()->getHex()->toString();
        goto NiNKh;
        CnQOD:
        latyR:
        goto Cle7l;
        srKqH:
        foreach ($this->Sjj0v as $Geai1) {
            goto zB1oS;
            ol_BK:
            return $KTvJz->initLocation($Geai1->mP2UVkYV346($KTvJz));
            goto rZT9e;
            rZT9e:
            SDzpC:
            goto x8aLn;
            zB1oS:
            if (!$Geai1->mU6k4DMBmtn($KTvJz)) {
                goto SDzpC;
            }
            goto ol_BK;
            x8aLn:
            QRACh:
            goto q0ifw;
            q0ifw:
        }
        goto A_Z6u;
        YKQ00:
        $KTvJz->mcp2uALDwNg(new IRilQlp89k7ga($KTvJz, $this->MV0lK, $j7R1u));
        goto srKqH;
        Ncxat:
        $KTvJz = $KTvJz->m8BEENsZavF($C83JB);
        goto ADci_;
        OfTzW:
        throw new WgiszEiQkEJPG("not support file type {$lxg_s}");
        goto WKcB1;
        Cle7l:
        F4KzC:
        goto Ncxat;
        A_Z6u:
        JhNnk:
        goto OfTzW;
        WKcB1:
    }
}
