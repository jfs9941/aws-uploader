<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Core\FpdzXEk0mryCJ;
use Jfs\Uploader\Core\DcQiQqj2PVL2z;
use Jfs\Uploader\Enum\A7CVlqbpzhfLD;
use Jfs\Uploader\Exception\CIAjwsRYu6S6e;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Exception\L8JNHBuVqji1P;
use Jfs\Uploader\Service\UkWgTCfbgTMD8;
use Illuminate\Contracts\Filesystem\Filesystem;
final class NHI9qC8LenJeR implements UploadServiceInterface
{
    private $M0M8h;
    private $unMfk;
    private $x5SUA;
    private $AOnDV;
    public function __construct(UkWgTCfbgTMD8 $MwwN5, Filesystem $L32kE, Filesystem $j3j3G, string $t_joZ)
    {
        goto asBqa;
        uN91y:
        $this->unMfk = $L32kE;
        goto GhUD2;
        asBqa:
        $this->M0M8h = $MwwN5;
        goto uN91y;
        JnqCJ:
        $this->AOnDV = $t_joZ;
        goto W42em;
        GhUD2:
        $this->x5SUA = $j3j3G;
        goto JnqCJ;
        W42em:
    }
    public function storeSingleFile(SingleUploadInterface $GKjbl) : array
    {
        goto FsRRl;
        TAmNH:
        $NSF8Y = $this->x5SUA->putFileAs(dirname($qFMlx->getLocation()), $GKjbl->getFile(), $qFMlx->getFilename() . '.' . $qFMlx->getExtension(), ['visibility' => 'public']);
        goto fljiV;
        OSiZM:
        goto zVtty;
        goto iRSMd;
        SL46t:
        return $qFMlx->getView();
        goto OaUnv;
        iRSMd:
        D6EbJ:
        goto Xm1Jo;
        KCbvp:
        throw new \LogicException('File upload failed, check permissions');
        goto OSiZM;
        FsRRl:
        $qFMlx = $this->M0M8h->ms21D4wcb4q($GKjbl);
        goto TAmNH;
        o53yy:
        zVtty:
        goto SL46t;
        fljiV:
        if (false !== $NSF8Y && $qFMlx instanceof DHtESYY0VyGQJ) {
            goto D6EbJ;
        }
        goto KCbvp;
        Xm1Jo:
        $qFMlx->m1WocvV9yZy(A7CVlqbpzhfLD::UPLOADED);
        goto o53yy;
        OaUnv:
    }
    public function storePreSignedFile(array $zzvcv)
    {
        goto CXEJ3;
        ylkkf:
        $m3Blp = DcQiQqj2PVL2z::m4O81XSiD24($qFMlx, $this->unMfk, $this->x5SUA, $this->AOnDV, true);
        goto gFNUP;
        CXEJ3:
        $qFMlx = $this->M0M8h->ms21D4wcb4q($zzvcv);
        goto ylkkf;
        CRq72:
        $m3Blp->mo8QDvgchjh();
        goto XEy8N;
        gFNUP:
        $m3Blp->mv25hoqapeT($zzvcv['mime'], $zzvcv['file_size'], $zzvcv['chunk_size'], $zzvcv['checksums'], $zzvcv['user_id'], $zzvcv['driver']);
        goto CRq72;
        XEy8N:
        return ['filename' => $m3Blp->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $m3Blp->mrQkNHRXp1P()];
        goto YZQGw;
        YZQGw:
    }
    public function updatePreSignedFile(string $tZ2iF, int $hDSFz)
    {
        goto oxKcL;
        H6wnf:
        wDvD0:
        goto gLIdN;
        TUEPa:
        switch ($hDSFz) {
            case A7CVlqbpzhfLD::UPLOADED:
                $m3Blp->mlgNMO0kMNH();
                goto wDvD0;
            case A7CVlqbpzhfLD::PROCESSING:
                $m3Blp->mhbSMT2U64r();
                goto wDvD0;
            case A7CVlqbpzhfLD::FINISHED:
                $m3Blp->mqPI3SWHixP();
                goto wDvD0;
            case A7CVlqbpzhfLD::ABORTED:
                $m3Blp->mmrZucbHhSd();
                goto wDvD0;
        }
        goto FRf18;
        FRf18:
        LLdUO:
        goto H6wnf;
        oxKcL:
        $m3Blp = DcQiQqj2PVL2z::msanA4csySx($tZ2iF, $this->unMfk, $this->x5SUA, $this->AOnDV);
        goto TUEPa;
        gLIdN:
    }
    public function completePreSignedFile(string $tZ2iF, array $Aw6Vd)
    {
        goto QXrpj;
        rdavn:
        $m3Blp->mlgNMO0kMNH();
        goto tz2cA;
        D4SLt:
        $m3Blp->mYn06Pxlq0m()->mtdG7YaeXtg($Aw6Vd);
        goto rdavn;
        tz2cA:
        return ['path' => $m3Blp->getFile()->getView()['path'], 'thumbnail' => $m3Blp->getFile()->cOLBZ, 'id' => $tZ2iF];
        goto N1sMc;
        QXrpj:
        $m3Blp = DcQiQqj2PVL2z::msanA4csySx($tZ2iF, $this->unMfk, $this->x5SUA, $this->AOnDV);
        goto D4SLt;
        N1sMc:
    }
    public function updateFile(string $tZ2iF, int $hDSFz) : FpdzXEk0mryCJ
    {
        goto i9jf8;
        yVmwg:
        return $qFMlx;
        goto rXSO7;
        HvcUb:
        $qFMlx->m1WocvV9yZy($hDSFz);
        goto yVmwg;
        i9jf8:
        $qFMlx = $this->M0M8h->mUoy9MBUQK3($tZ2iF);
        goto HvcUb;
        rXSO7:
    }
}
