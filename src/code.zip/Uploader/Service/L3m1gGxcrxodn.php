<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\CyraHfwSfcIZC;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Core\Observer\SY8gU52rT5c5k;
use Jfs\Uploader\Core\Observer\ZNuCIvAvq8xNS;
use Jfs\Uploader\Core\XpjbCMtbhbQNm;
use Jfs\Uploader\Core\XxIkOu3r3u4yJ;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
use Jfs\Uploader\Exception\PgT1yqHzwrHid;
use Jfs\Uploader\Exception\ST4IwPMeWC8T9;
use Jfs\Uploader\Service\FileResolver\TYpCViyrUx9db;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class L3m1gGxcrxodn
{
    private $XBCAr;
    private $W9e5K;
    private $zbU8n;
    public function __construct($ygEYI, $XCkIj, $Efy84)
    {
        goto wZGcz;
        geJeG:
        $this->zbU8n = $Efy84;
        goto CRb5u;
        eQM3T:
        $this->W9e5K = $XCkIj;
        goto geJeG;
        wZGcz:
        $this->XBCAr = $ygEYI;
        goto eQM3T;
        CRb5u:
    }
    public function mg4ua8yTKdn($qWafP)
    {
        goto L4txs;
        YzxsZ:
        PsBSb:
        goto CIZwE;
        CIZwE:
        return $this->mbftBDpn35J($qWafP['file_extension'], 's3' === $qWafP['driver'] ? I5kpK7wkbRQvu::S3 : I5kpK7wkbRQvu::LOCAL);
        goto xZDS1;
        WXEtA:
        return $this->mbftBDpn35J($SK0Zb->extension(), I5kpK7wkbRQvu::S3, null, $qWafP->options());
        goto YzxsZ;
        sbp1f:
        $SK0Zb = $qWafP->getFile();
        goto WXEtA;
        L4txs:
        if (!$qWafP instanceof SingleUploadInterface) {
            goto PsBSb;
        }
        goto sbp1f;
        xZDS1:
    }
    public function mAfT4A17NDR(string $N2oAf)
    {
        goto W8FrZ;
        xWlm_:
        $k2MU3->setRawAttributes($dYGNV->getAttributes());
        goto X_9Yw;
        W8FrZ:
        $dYGNV = config('upload.attachment_model')::findOrFail($N2oAf);
        goto wR2as;
        y8IXa:
        $k2MU3->exists = true;
        goto xWlm_;
        wR2as:
        $k2MU3 = $this->mbftBDpn35J($dYGNV->getAttribute('type'), $dYGNV->getAttribute('driver'), $dYGNV->getAttribute('id'));
        goto y8IXa;
        X_9Yw:
        return $k2MU3;
        goto X9zib;
        X9zib:
    }
    public function mCcF1uxq2Dw(string $OwNWt) : CyraHfwSfcIZC
    {
        goto aR_lW;
        PruNo:
        $w_bTx = XxIkOu3r3u4yJ::mtqR12H52AU($u_EX6);
        goto pqLoL;
        rZ6vR:
        if ($Rmjku) {
            goto w0pvA;
        }
        goto C8r_h;
        nd2aB:
        w0pvA:
        goto sJJTS;
        sJJTS:
        $u_EX6 = json_decode($Rmjku, true);
        goto Lz0TY;
        C8r_h:
        $Rmjku = $this->zbU8n->get($OwNWt);
        goto nd2aB;
        pqLoL:
        return $this->mbftBDpn35J($w_bTx->dvco0, $w_bTx->mR1UAaczC6v(), $w_bTx->filename);
        goto j56Iu;
        Lz0TY:
        if (!$u_EX6) {
            goto AJWDT;
        }
        goto PruNo;
        RLeZg:
        throw new PgT1yqHzwrHid('metadata file not found');
        goto ECKGz;
        j56Iu:
        AJWDT:
        goto RLeZg;
        aR_lW:
        $Rmjku = $this->W9e5K->get($OwNWt);
        goto rZ6vR;
        ECKGz:
    }
    private function mbftBDpn35J(string $pF_y5, $SvS6t, ?string $N2oAf = null, array $rS7iQ = [])
    {
        goto IWC3I;
        NUYlC:
        ahBZM:
        goto hLUnV;
        Lmr7b:
        $WE5Vp->mZHCv5SIdJ7(new SY8gU52rT5c5k($WE5Vp));
        goto Ws10o;
        uthyO:
        switch ($pF_y5) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $WE5Vp = JMa7GBaLcnq3D::createFromScratch($N2oAf, $pF_y5);
                goto w0ipa;
            case 'mp4':
            case 'mov':
                $WE5Vp = VPegVN4NByLqJ::createFromScratch($N2oAf, $pF_y5);
                goto w0ipa;
            case 'pdf':
                $WE5Vp = XpjbCMtbhbQNm::createFromScratch($N2oAf, $pF_y5);
                goto w0ipa;
            default:
                throw new ST4IwPMeWC8T9("not support file type {$pF_y5}");
        }
        goto NUYlC;
        hLUnV:
        w0ipa:
        goto uhYUu;
        uhYUu:
        $WE5Vp = $WE5Vp->m63O64FsTyr($SvS6t);
        goto Lmr7b;
        zf5s3:
        throw new ST4IwPMeWC8T9("not support file type {$pF_y5}");
        goto j52nD;
        E7oOq:
        foreach ($this->XBCAr as $aPiO3) {
            goto wiH3j;
            v6LFO:
            xiqFl:
            goto ikIhW;
            UKvJH:
            H1c9P:
            goto v6LFO;
            YOL_b:
            return $WE5Vp->initLocation($aPiO3->mdqssoGbEVc($WE5Vp));
            goto UKvJH;
            wiH3j:
            if (!$aPiO3->mbLvuy9HI6t($WE5Vp)) {
                goto H1c9P;
            }
            goto YOL_b;
            ikIhW:
        }
        goto ubakN;
        ubakN:
        FwzDd:
        goto zf5s3;
        Ws10o:
        $WE5Vp->mZHCv5SIdJ7(new ZNuCIvAvq8xNS($WE5Vp, $this->zbU8n, $rS7iQ));
        goto E7oOq;
        IWC3I:
        $N2oAf = $N2oAf ?? Uuid::uuid4()->getHex()->toString();
        goto uthyO;
        j52nD:
    }
}
