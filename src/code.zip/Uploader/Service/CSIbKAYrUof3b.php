<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class CSIbKAYrUof3b implements VideoPostHandleServiceInterface
{
    private $YnAAJ;
    private $tcoQz;
    public function __construct(UploadServiceInterface $jkP9H, Filesystem $v70jj)
    {
        $this->YnAAJ = $jkP9H;
        $this->tcoQz = $v70jj;
    }
    public function saveMetadata(string $B5uQ4, array $H8A56)
    {
        goto P2l1n;
        dg59k:
        if (!$jYLmK->update($iWFU2)) {
            goto e4FqV;
        }
        goto Nfl_i;
        JF_f1:
        e4FqV:
        goto OYBoe;
        s8qUK:
        try {
            goto R4uPN;
            R4uPN:
            $dWEzY = $this->YnAAJ->storeSingleFile(new class($H8A56['thumbnail']) implements SingleUploadInterface
            {
                private $EidfR;
                public function __construct($clm2Y)
                {
                    $this->EidfR = $clm2Y;
                }
                public function getFile()
                {
                    return $this->EidfR;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto lZBsn;
            lZBsn:
            $iWFU2['thumbnail_id'] = $dWEzY['id'];
            goto OhAEl;
            OhAEl:
            $iWFU2['thumbnail'] = $dWEzY['filename'];
            goto Cz25q;
            Cz25q:
        } catch (\Throwable $xMxrQ) {
            Log::warning("CpeNYzI7e1ALA thumbnail store failed: " . $xMxrQ->getMessage());
        }
        goto cXwQG;
        P2l1n:
        $jYLmK = CpeNYzI7e1ALA::findOrFail($B5uQ4);
        goto Cn8Sz;
        tskPX:
        if (!isset($H8A56['thumbnail'])) {
            goto Gapyd;
        }
        goto s8qUK;
        TKu7q:
        $iWFU2['fps'] = $H8A56['fps'];
        goto jzc9u;
        OYBoe:
        Log::warning("CpeNYzI7e1ALA metadata store failed for unknown reason ... " . $B5uQ4);
        goto U2wSJ;
        I_5Zt:
        if (!isset($H8A56['resolution'])) {
            goto OSp0D;
        }
        goto n3oge;
        h121A:
        $this->YnAAJ->updateFile($jYLmK->getAttribute('id'), KidkTsWIjmNMb::PROCESSING);
        goto Rd5qm;
        G3N9d:
        if (!isset($H8A56['thumbnail_url'])) {
            goto uZhYK;
        }
        goto CSMrz;
        GAQzr:
        $iWFU2['duration'] = $H8A56['duration'];
        goto zIlC3;
        XQypw:
        if (!$jYLmK->aVfpf) {
            goto ziJb8;
        }
        goto PV5y7;
        llLE6:
        ziJb8:
        goto dg59k;
        U2wSJ:
        throw new \Exception("CpeNYzI7e1ALA metadata store failed for unknown reason ... " . $B5uQ4);
        goto xwRJM;
        cXwQG:
        Gapyd:
        goto FE6FH;
        Cn8Sz:
        $iWFU2 = [];
        goto G3N9d;
        CSMrz:
        $iWFU2['thumbnail'] = pathinfo($H8A56['thumbnail_url'], PATHINFO_FILENAME);
        goto jOXYg;
        PV5y7:
        unset($iWFU2['thumbnail']);
        goto llLE6;
        jzc9u:
        MRmXs:
        goto XQypw;
        n3oge:
        $iWFU2['resolution'] = $H8A56['resolution'];
        goto qbrmp;
        zIlC3:
        opJwI:
        goto I_5Zt;
        zwhn6:
        if (!isset($H8A56['fps'])) {
            goto MRmXs;
        }
        goto TKu7q;
        FE6FH:
        if (!isset($H8A56['duration'])) {
            goto opJwI;
        }
        goto GAQzr;
        Nfl_i:
        if (!(isset($H8A56['change_status']) && $H8A56['change_status'])) {
            goto vhWcX;
        }
        goto h121A;
        T9B5G:
        return $jYLmK->getView();
        goto JF_f1;
        Rd5qm:
        vhWcX:
        goto T9B5G;
        jOXYg:
        uZhYK:
        goto tskPX;
        qbrmp:
        OSp0D:
        goto zwhn6;
        xwRJM:
    }
    public function createThumbnail(string $uuOqF) : void
    {
        goto buvK9;
        t2n8Q:
        $I9Rl0 = "v2/hls/thumbnails/{$uuOqF}/";
        goto ed1UQ;
        RlRzt:
        $P8Iy0 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto gIYHD;
        gIYHD:
        try {
            goto d5eIZ;
            L4sOo:
            $Ywy3u = $Oo66f->get('QueueUrl');
            goto myoeA;
            d5eIZ:
            $Oo66f = $P8Iy0->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto L4sOo;
            myoeA:
            $P8Iy0->sendMessage(['QueueUrl' => $Ywy3u, 'MessageBody' => json_encode(['file_path' => $jYLmK->getLocation()])]);
            goto DOqmy;
            DOqmy:
        } catch (\Throwable $EgQtq) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$EgQtq->getMessage()}");
        }
        goto n3f7y;
        sU9Id:
        $jYLmK = CpeNYzI7e1ALA::findOrFail($uuOqF);
        goto t2n8Q;
        n3f7y:
        hBzE6:
        goto XJRCX;
        ed1UQ:
        if (!(!$this->tcoQz->directoryExists($I9Rl0) && empty($jYLmK->mxcQxXSjpmn()))) {
            goto hBzE6;
        }
        goto RlRzt;
        buvK9:
        Log::info("Use Lambda to generate thumbnail for video: " . $uuOqF);
        goto sU9Id;
        XJRCX:
    }
    public function mdbCisiPmew(string $uuOqF) : void
    {
        goto kPLwj;
        OKftj:
        mZT68:
        goto O5r46;
        t52pZ:
        $I9Rl0 = "v2/hls/thumbnails/{$uuOqF}/";
        goto hE_ST;
        AQqGe:
        throw new \Exception("Message back with success data but not found thumbnail " . $uuOqF);
        goto OKftj;
        YDtzu:
        $jYLmK->update(['generated_previews' => $I9Rl0]);
        goto fQANA;
        O5r46:
        $a0LP8 = $this->tcoQz->files($I9Rl0);
        goto myK1_;
        akLG3:
        AdEyY:
        goto YDtzu;
        AtPZ1:
        throw new \Exception("Message back with success data but not found thumbnail files " . $uuOqF);
        goto akLG3;
        kPLwj:
        $jYLmK = CpeNYzI7e1ALA::findOrFail($uuOqF);
        goto t52pZ;
        fOUSj:
        Log::error("Message back with success data but not found thumbnail " . $uuOqF);
        goto AQqGe;
        myK1_:
        if (!(count($a0LP8) === 0)) {
            goto AdEyY;
        }
        goto ejKdx;
        ejKdx:
        Log::error("Message back with success data but not found thumbnail files " . $uuOqF);
        goto AtPZ1;
        hE_ST:
        if ($this->tcoQz->directoryExists($I9Rl0)) {
            goto mZT68;
        }
        goto fOUSj;
        fQANA:
    }
    public function getThumbnails(string $uuOqF) : array
    {
        $jYLmK = CpeNYzI7e1ALA::findOrFail($uuOqF);
        return $jYLmK->getThumbnails();
    }
    public function getMedia(string $uuOqF) : array
    {
        $m5Vy1 = Media::findOrFail($uuOqF);
        return $m5Vy1->getView();
    }
}
