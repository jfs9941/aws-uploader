<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Service;

use backup\Exposed\AVqShGCH8LOrP;
use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Core\Observer\Jzgh0IwrfyoJe;
use backup\Uploader\Core\Observer\MxWo1C1itIr69;
use backup\Uploader\Core\OzgWWRogA2eJF;
use backup\Uploader\Core\AxmsWfJr0hDcu;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Exception\HXV6iIC92kwG6;
use backup\Uploader\Service\FileResolver\BI7BOKfgmUwdi;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class IJhG5F6LYY6Bm
{
    private $CDfit;
    private $FJZRi;
    private $kEfMA;
    public function __construct($NFQBq, $UEDUm, $FP6ih)
    {
        goto v0L3o;
        RRxpA:
        $this->FJZRi = $UEDUm;
        goto O6Lhm;
        O6Lhm:
        $this->kEfMA = $FP6ih;
        goto KNzTW;
        v0L3o:
        $this->CDfit = $NFQBq;
        goto RRxpA;
        KNzTW:
    }
    public function mS3C4QCDDWI($yvt_J)
    {
        goto C5axf;
        osMEf:
        $Jp8ot = $yvt_J->getFile();
        goto Px3NO;
        Px3NO:
        return $this->mTKa6EcNIiY($Jp8ot->extension(), XmcIS8CQn72i3::S3, null, $yvt_J->options());
        goto X97tx;
        C5axf:
        if (!$yvt_J instanceof AVqShGCH8LOrP) {
            goto ZtXqP;
        }
        goto osMEf;
        X97tx:
        ZtXqP:
        goto NJ1Wr;
        NJ1Wr:
        return $this->mTKa6EcNIiY($yvt_J['file_extension'], 's3' === $yvt_J['driver'] ? XmcIS8CQn72i3::S3 : XmcIS8CQn72i3::LOCAL);
        goto IbxSB;
        IbxSB:
    }
    public function mRfTuN5hXz0(string $EQQae)
    {
        goto PBII_;
        FifS3:
        $eVZrJ->exists = true;
        goto jN1ln;
        jN1ln:
        $eVZrJ->setRawAttributes($hT4WG->getAttributes());
        goto Vl5N6;
        PBII_:
        $hT4WG = config('upload.attachment_model')::findOrFail($EQQae);
        goto jAkDJ;
        Vl5N6:
        return $eVZrJ;
        goto uWWkA;
        jAkDJ:
        $eVZrJ = $this->mTKa6EcNIiY($hT4WG->getAttribute('type'), $hT4WG->getAttribute('driver'), $hT4WG->getAttribute('id'));
        goto FifS3;
        uWWkA:
    }
    public function m9LaZIEPg91(string $StSVL) : VnrpqIkXJe1mn
    {
        goto jNAwU;
        jrNyx:
        return $this->mTKa6EcNIiY($DRC6o->k_wlU, $DRC6o->mshRaudEy4y(), $DRC6o->filename);
        goto Blmo5;
        YFOyq:
        if ($Z2tSd) {
            goto ut3ju;
        }
        goto bSNGh;
        eYXQD:
        throw new Asi2ubH37e0l9('metadata file not found');
        goto zpNNa;
        bSNGh:
        $Z2tSd = $this->kEfMA->get($StSVL);
        goto mJnfw;
        jNAwU:
        $Z2tSd = $this->FJZRi->get($StSVL);
        goto YFOyq;
        pU87w:
        if (!$JbFc7) {
            goto e74fp;
        }
        goto d4cj9;
        mQ3YP:
        $JbFc7 = json_decode($Z2tSd, true);
        goto pU87w;
        mJnfw:
        ut3ju:
        goto mQ3YP;
        Blmo5:
        e74fp:
        goto eYXQD;
        d4cj9:
        $DRC6o = AxmsWfJr0hDcu::mS99Egimp5G($JbFc7);
        goto jrNyx;
        zpNNa:
    }
    private function mTKa6EcNIiY(string $dFAQm, $BSZEB, ?string $EQQae = null, array $FxiIj = [])
    {
        goto YK34s;
        YK34s:
        $EQQae = $EQQae ?? Uuid::uuid4()->getHex()->toString();
        goto Or2lA;
        G3lqM:
        hvUQB:
        goto R3U1o;
        R3U1o:
        throw new HXV6iIC92kwG6("not support file type {$dFAQm}");
        goto B1GWN;
        Q0pwl:
        lYo_p:
        goto D1GPl;
        D1GPl:
        N23bu:
        goto R4zF4;
        OSEWG:
        $y4pVx->mJOjnVefuIu(new Jzgh0IwrfyoJe($y4pVx));
        goto px5J1;
        R4zF4:
        $y4pVx = $y4pVx->mZUs5513q7N($BSZEB);
        goto OSEWG;
        Or2lA:
        switch ($dFAQm) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $y4pVx = CrEYqpC23XUGo::createFromScratch($EQQae, $dFAQm);
                goto N23bu;
            case 'mp4':
            case 'mov':
                $y4pVx = AvisbyD0IE5xq::createFromScratch($EQQae, $dFAQm);
                goto N23bu;
            case 'pdf':
                $y4pVx = OzgWWRogA2eJF::createFromScratch($EQQae, $dFAQm);
                goto N23bu;
            default:
                throw new HXV6iIC92kwG6("not support file type {$dFAQm}");
        }
        goto Q0pwl;
        px5J1:
        $y4pVx->mJOjnVefuIu(new MxWo1C1itIr69($y4pVx, $this->kEfMA, $FxiIj));
        goto KOMsM;
        KOMsM:
        foreach ($this->CDfit as $oelhj) {
            goto uVou1;
            ra2oH:
            dxTG2:
            goto A7PhA;
            uVou1:
            if (!$oelhj->mtsKpJFvGEz($y4pVx)) {
                goto FHFkb;
            }
            goto YoqtG;
            WFadS:
            FHFkb:
            goto ra2oH;
            YoqtG:
            return $y4pVx->initLocation($oelhj->mUY17sPgYP6($y4pVx));
            goto WFadS;
            A7PhA:
        }
        goto G3lqM;
        B1GWN:
    }
}
