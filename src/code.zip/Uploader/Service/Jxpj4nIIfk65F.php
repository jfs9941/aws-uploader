<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class Jxpj4nIIfk65F implements VideoPostHandleServiceInterface
{
    private $CTTz3;
    private $PxC6l;
    public function __construct(UploadServiceInterface $K3KtI, Filesystem $kxhX9)
    {
        $this->CTTz3 = $K3KtI;
        $this->PxC6l = $kxhX9;
    }
    public function saveMetadata(string $S580N, array $AOnlH)
    {
        goto hcONl;
        pgQQF:
        if (!$Bh2o5->aweuO) {
            goto YdAIB;
        }
        goto my_oV;
        sZOFn:
        if (!$Bh2o5->update($CQAur)) {
            goto PWnBW;
        }
        goto nP45_;
        Z6_zP:
        if (!isset($AOnlH['fps'])) {
            goto DGEfd;
        }
        goto J89jQ;
        hcONl:
        $Bh2o5 = BtruCfJoaSWZ6::findOrFail($S580N);
        goto hKZZL;
        hWVdF:
        KOaG7:
        goto CddMs;
        dI_iE:
        try {
            goto EJZZ7;
            SobqH:
            $CQAur['thumbnail_id'] = $lSq7k['id'];
            goto R4NJg;
            R4NJg:
            $CQAur['thumbnail'] = $lSq7k['filename'];
            goto OtZ0p;
            EJZZ7:
            $lSq7k = $this->CTTz3->storeSingleFile(new class($AOnlH['thumbnail']) implements SingleUploadInterface
            {
                private $uq849;
                public function __construct($gNVOT)
                {
                    $this->uq849 = $gNVOT;
                }
                public function getFile()
                {
                    return $this->uq849;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto SobqH;
            OtZ0p:
        } catch (\Throwable $p0etA) {
            Log::warning("BtruCfJoaSWZ6 thumbnail store failed: " . $p0etA->getMessage());
        }
        goto hWVdF;
        CddMs:
        if (!isset($AOnlH['duration'])) {
            goto F0_Ao;
        }
        goto XzIEo;
        hKZZL:
        $CQAur = [];
        goto z1BXP;
        h3Rh8:
        DGEfd:
        goto pgQQF;
        W7I9U:
        PWnBW:
        goto y_Pn6;
        afPf4:
        Xq6a7:
        goto bPzEN;
        z1BXP:
        if (!isset($AOnlH['thumbnail'])) {
            goto KOaG7;
        }
        goto dI_iE;
        y_Pn6:
        Log::warning("BtruCfJoaSWZ6 metadata store failed for unknown reason ... " . $S580N);
        goto oUvGh;
        XzIEo:
        $CQAur['duration'] = $AOnlH['duration'];
        goto dDVW6;
        DolMd:
        $this->CTTz3->updateFile($Bh2o5->getAttribute('id'), EHhCBxlsVyz9C::PROCESSING);
        goto afPf4;
        J89jQ:
        $CQAur['fps'] = $AOnlH['fps'];
        goto h3Rh8;
        bVmOG:
        YdAIB:
        goto sZOFn;
        zLaMK:
        $CQAur['resolution'] = $AOnlH['resolution'];
        goto Dlc6n;
        oUvGh:
        throw new \Exception("BtruCfJoaSWZ6 metadata store failed for unknown reason ... " . $S580N);
        goto IILfu;
        nP45_:
        if (!(isset($AOnlH['change_status']) && $AOnlH['change_status'])) {
            goto Xq6a7;
        }
        goto DolMd;
        dsuTg:
        if (!isset($AOnlH['resolution'])) {
            goto ZNrWJ;
        }
        goto zLaMK;
        dDVW6:
        F0_Ao:
        goto dsuTg;
        my_oV:
        unset($CQAur['thumbnail']);
        goto bVmOG;
        Dlc6n:
        ZNrWJ:
        goto Z6_zP;
        bPzEN:
        return $Bh2o5->getView();
        goto W7I9U;
        IILfu:
    }
    public function createThumbnail(string $kFpT0) : void
    {
        goto UmQez;
        QpOwR:
        $m8nUu = "v2/hls/thumbnails/{$kFpT0}/";
        goto vOOuA;
        ZOe7o:
        $FSHo0 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto fhvy5;
        fhvy5:
        try {
            goto sDib3;
            FS6MR:
            $FSHo0->sendMessage(['QueueUrl' => $M9ejR, 'MessageBody' => json_encode(['file_path' => $Bh2o5->getLocation()])]);
            goto tCofH;
            sDib3:
            $twVVW = $FSHo0->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto k4hKr;
            k4hKr:
            $M9ejR = $twVVW->get('QueueUrl');
            goto FS6MR;
            tCofH:
        } catch (\Throwable $ah9h0) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$ah9h0->getMessage()}");
        }
        goto XJKEa;
        UmQez:
        Log::info("Use Lambda to generate thumbnail for video: " . $kFpT0);
        goto oQNCX;
        vOOuA:
        if (!(!$this->PxC6l->directoryExists($m8nUu) && empty($Bh2o5->mNw1wWRnNGn()))) {
            goto uhErP;
        }
        goto ZOe7o;
        oQNCX:
        $Bh2o5 = BtruCfJoaSWZ6::findOrFail($kFpT0);
        goto QpOwR;
        XJKEa:
        uhErP:
        goto RC4mh;
        RC4mh:
    }
    public function mfq0JSRkAM4(string $kFpT0) : void
    {
        goto AMASe;
        LsNoL:
        bzaI3:
        goto j83Fi;
        j83Fi:
        $Bh2o5->update(['generated_previews' => $m8nUu]);
        goto PbNLg;
        KGxxP:
        throw new \Exception("Message back with success data but not found thumbnail " . $kFpT0);
        goto mKCnn;
        h1wbb:
        $m8nUu = "v2/hls/thumbnails/{$kFpT0}/";
        goto eJKFz;
        eJKFz:
        if ($this->PxC6l->directoryExists($m8nUu)) {
            goto JIWmu;
        }
        goto XLPIL;
        mKCnn:
        JIWmu:
        goto fXFZy;
        P5lWp:
        Log::error("Message back with success data but not found thumbnail files " . $kFpT0);
        goto xkVKB;
        AMASe:
        $Bh2o5 = BtruCfJoaSWZ6::findOrFail($kFpT0);
        goto h1wbb;
        bpBVc:
        if (!(count($AvEgW) === 0)) {
            goto bzaI3;
        }
        goto P5lWp;
        xkVKB:
        throw new \Exception("Message back with success data but not found thumbnail files " . $kFpT0);
        goto LsNoL;
        XLPIL:
        Log::error("Message back with success data but not found thumbnail " . $kFpT0);
        goto KGxxP;
        fXFZy:
        $AvEgW = $this->PxC6l->files($m8nUu);
        goto bpBVc;
        PbNLg:
    }
    public function getThumbnails(string $kFpT0) : array
    {
        $Bh2o5 = BtruCfJoaSWZ6::findOrFail($kFpT0);
        return $Bh2o5->getThumbnails();
    }
    public function getMedia(string $kFpT0) : array
    {
        $zr5kh = Media::findOrFail($kFpT0);
        return $zr5kh->getView();
    }
}
