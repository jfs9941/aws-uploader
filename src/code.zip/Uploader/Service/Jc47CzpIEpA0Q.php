<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class Jc47CzpIEpA0Q implements VideoPostHandleServiceInterface
{
    private $dzj8j;
    private $bLZP5;
    public function __construct(UploadServiceInterface $EYu_2, Filesystem $C1By6)
    {
        $this->dzj8j = $EYu_2;
        $this->bLZP5 = $C1By6;
    }
    public function saveMetadata(string $DWjir, array $PSxFL)
    {
        goto Yla3T;
        A7DaT:
        if (!$lamFK->ipAoK) {
            goto kZeqT;
        }
        goto Nt8a2;
        u2QAW:
        return $lamFK->getView();
        goto WCNIP;
        WCNIP:
        sywZy:
        goto VjkR3;
        M4TxZ:
        $rFe6t['duration'] = $PSxFL['duration'];
        goto jDZbF;
        E2akS:
        $rFe6t['fps'] = $PSxFL['fps'];
        goto KiP34;
        VjkR3:
        Log::warning("J7sRaWo8um3yO metadata store failed for unknown reason ... " . $DWjir);
        goto wgFo_;
        vVqpZ:
        $rFe6t['resolution'] = $PSxFL['resolution'];
        goto SKuaJ;
        VbPtR:
        eGiZR:
        goto spD6s;
        F85GK:
        MpUE8:
        goto UBgVZ;
        BR6v4:
        aWoQb:
        goto u2QAW;
        mcnI6:
        if (!isset($PSxFL['thumbnail_url'])) {
            goto eGiZR;
        }
        goto WSZte;
        GMVen:
        $rFe6t = [];
        goto mcnI6;
        peBDn:
        if (!isset($PSxFL['resolution'])) {
            goto TlgXy;
        }
        goto vVqpZ;
        ZgQRE:
        if (!(isset($PSxFL['change_status']) && $PSxFL['change_status'])) {
            goto aWoQb;
        }
        goto lH8Cm;
        WSZte:
        $rFe6t['thumbnail'] = $PSxFL['thumbnail_url'];
        goto VbPtR;
        jDZbF:
        SpVBv:
        goto peBDn;
        KiP34:
        s6rlh:
        goto A7DaT;
        t2bE7:
        if (!isset($PSxFL['fps'])) {
            goto s6rlh;
        }
        goto E2akS;
        lH8Cm:
        $this->dzj8j->updateFile($lamFK->getAttribute('id'), H7dtWZ2h5WAty::PROCESSING);
        goto BR6v4;
        Yla3T:
        $lamFK = J7sRaWo8um3yO::findOrFail($DWjir);
        goto GMVen;
        Lp6WC:
        try {
            goto UBLWK;
            egHuE:
            $rFe6t['thumbnail_id'] = $UT4QS['id'];
            goto I_ELg;
            UBLWK:
            $UT4QS = $this->dzj8j->storeSingleFile(new class($PSxFL['thumbnail']) implements SingleUploadInterface
            {
                private $tEOkh;
                public function __construct($nbWJE)
                {
                    $this->tEOkh = $nbWJE;
                }
                public function getFile()
                {
                    return $this->tEOkh;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto egHuE;
            I_ELg:
            $rFe6t['thumbnail'] = $UT4QS['filename'];
            goto aK22T;
            aK22T:
        } catch (\Throwable $x4bzR) {
            Log::warning("J7sRaWo8um3yO thumbnail store failed: " . $x4bzR->getMessage());
        }
        goto F85GK;
        wgFo_:
        throw new \Exception("J7sRaWo8um3yO metadata store failed for unknown reason ... " . $DWjir);
        goto Srjju;
        SKuaJ:
        TlgXy:
        goto t2bE7;
        UBgVZ:
        if (!isset($PSxFL['duration'])) {
            goto SpVBv;
        }
        goto M4TxZ;
        rao_Q:
        if (!$lamFK->update($rFe6t)) {
            goto sywZy;
        }
        goto ZgQRE;
        spD6s:
        if (!isset($PSxFL['thumbnail'])) {
            goto MpUE8;
        }
        goto Lp6WC;
        LvusC:
        kZeqT:
        goto rao_Q;
        Nt8a2:
        unset($rFe6t['thumbnail']);
        goto LvusC;
        Srjju:
    }
    public function createThumbnail(string $vip8M) : void
    {
        goto EgKKP;
        SMo2y:
        try {
            goto HW29z;
            bV1ct:
            $YHrQ5->sendMessage(['QueueUrl' => $hhf5N, 'MessageBody' => json_encode(['file_path' => $lamFK->getLocation()])]);
            goto mr0hw;
            pmsRx:
            $hhf5N = $XjaIU->get('QueueUrl');
            goto bV1ct;
            HW29z:
            $XjaIU = $YHrQ5->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto pmsRx;
            mr0hw:
        } catch (\Throwable $dMDxf) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$dMDxf->getMessage()}");
        }
        goto xXArF;
        EgKKP:
        Log::info("Use Lambda to generate thumbnail for video: " . $vip8M);
        goto ecfoY;
        xXArF:
        DeKec:
        goto HWDSB;
        FxMxy:
        $YHrQ5 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto SMo2y;
        jJLyg:
        $XZj6d = "v2/hls/thumbnails/{$vip8M}/";
        goto eT8VB;
        ecfoY:
        $lamFK = J7sRaWo8um3yO::findOrFail($vip8M);
        goto jJLyg;
        eT8VB:
        if (!(!$this->bLZP5->directoryExists($XZj6d) && empty($lamFK->m6jJ8zpiUpK()))) {
            goto DeKec;
        }
        goto FxMxy;
        HWDSB:
    }
    public function mrJPL9W17P3(string $vip8M) : void
    {
        goto QD4Lq;
        EQrgq:
        $XZj6d = "v2/hls/thumbnails/{$vip8M}/";
        goto CL5fu;
        WiQ2u:
        $cYYQf = $this->bLZP5->files($XZj6d);
        goto iMbzw;
        iMbzw:
        if (!(count($cYYQf) === 0)) {
            goto DzIVD;
        }
        goto vjjas;
        QLpDP:
        pxw_s:
        goto WiQ2u;
        vjjas:
        Log::error("Message back with success data but not found thumbnail files " . $vip8M);
        goto P4X6P;
        PuSGb:
        $lamFK->update(['generated_previews' => $XZj6d]);
        goto vrrkD;
        QD4Lq:
        $lamFK = J7sRaWo8um3yO::findOrFail($vip8M);
        goto EQrgq;
        w5uWY:
        DzIVD:
        goto PuSGb;
        bHt7o:
        Log::error("Message back with success data but not found thumbnail " . $vip8M);
        goto ReoDp;
        P4X6P:
        throw new \Exception("Message back with success data but not found thumbnail files " . $vip8M);
        goto w5uWY;
        CL5fu:
        if ($this->bLZP5->directoryExists($XZj6d)) {
            goto pxw_s;
        }
        goto bHt7o;
        ReoDp:
        throw new \Exception("Message back with success data but not found thumbnail " . $vip8M);
        goto QLpDP;
        vrrkD:
    }
    public function getThumbnails(string $vip8M) : array
    {
        $lamFK = J7sRaWo8um3yO::findOrFail($vip8M);
        return $lamFK->getThumbnails();
    }
    public function getMedia(string $vip8M) : array
    {
        $jKCuO = Media::findOrFail($vip8M);
        return $jKCuO->getView();
    }
}
