<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\Bvfii9tMROJRp;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Core\MDV8LxETbMtpJ;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
final class PYjKYaymEKJyi implements Bvfii9tMROJRp
{
    private $Ju7YN;
    private $cQd2k;
    public $i5ZeE;
    private $uCM72;
    private $qT39W;
    private $pCaD7;
    public function __construct($PP3t4, $T0mVy, $f1vDJ, $k3NY1, $dqQto, $P3zvl)
    {
        goto MrDGS;
        yOLXn:
        $this->Ju7YN = $PP3t4;
        goto EwSZu;
        yCvbz:
        $this->i5ZeE = $f1vDJ;
        goto vKlQ3;
        EwSZu:
        $this->cQd2k = $T0mVy;
        goto yCvbz;
        vKlQ3:
        $this->uCM72 = $k3NY1;
        goto SFVz2;
        MrDGS:
        $this->pCaD7 = $P3zvl;
        goto yOLXn;
        SFVz2:
        $this->qT39W = $dqQto;
        goto iMrNV;
        iMrNV:
    }
    public function resolvePath($P82oP, $RpHBQ = YJGCddWUf6Zu2::S3) : string
    {
        goto pKWMW;
        OCkv0:
        return trim($this->cQd2k, '/') . '/' . $P82oP;
        goto ze6nP;
        JwRfH:
        return $this->mAJ0SReQAgd($P82oP);
        goto k6wHd;
        JzYtN:
        U0SA3:
        goto OCkv0;
        F3mj9:
        return trim($this->i5ZeE, '/') . '/' . $P82oP;
        goto JzYtN;
        Cg1HR:
        $P82oP = $P82oP->getAttribute('filename');
        goto xCe36;
        UmLnh:
        if (!($RpHBQ === YJGCddWUf6Zu2::LOCAL)) {
            goto lUivH;
        }
        goto q_zpq;
        q_zpq:
        return config('upload.home') . '/' . $P82oP;
        goto vysaU;
        zAFnE:
        if (!(!empty($this->uCM72) && !empty($this->qT39W))) {
            goto BYXZm;
        }
        goto JwRfH;
        xCe36:
        MvuYm:
        goto UmLnh;
        BsuMx:
        if (!$this->Ju7YN) {
            goto U0SA3;
        }
        goto F3mj9;
        vysaU:
        lUivH:
        goto zAFnE;
        k6wHd:
        BYXZm:
        goto BsuMx;
        pKWMW:
        if (!$P82oP instanceof IeEvjRaj1LMmG) {
            goto MvuYm;
        }
        goto Cg1HR;
        ze6nP:
    }
    public function resolveThumbnail(IeEvjRaj1LMmG $P82oP) : string
    {
        goto Jq3oY;
        qhKJX:
        e_qfB:
        goto F5K0n;
        ez9Fb:
        $KQQQz = UKkbXBDRxjSUY::find($P82oP->getAttribute('thumbnail_id'));
        goto BdvrV;
        VevzT:
        kSnvt:
        goto dcmv2;
        AkaCD:
        if (!$P82oP instanceof MDV8LxETbMtpJ) {
            goto kSnvt;
        }
        goto N74rS;
        N74rS:
        return asset('/img/pdf-preview.svg');
        goto VevzT;
        BdvrV:
        if (!$KQQQz) {
            goto pVoT0;
        }
        goto F907F;
        fDJQH:
        pVoT0:
        goto FKrsN;
        FgP7Q:
        if (!$NnQOx) {
            goto e_qfB;
        }
        goto ltQY9;
        F5K0n:
        if (!$P82oP->getAttribute('thumbnail_id')) {
            goto oBBjJ;
        }
        goto ez9Fb;
        F907F:
        return $this->resolvePath($KQQQz, $KQQQz->getAttribute('driver'));
        goto fDJQH;
        X9_62:
        CN6LN:
        goto AkaCD;
        ltQY9:
        return $this->url($NnQOx, $P82oP->getAttribute('driver'));
        goto qhKJX;
        Jq3oY:
        $NnQOx = $P82oP->getAttribute('thumbnail');
        goto FgP7Q;
        Q_Tmz:
        if (!$P82oP instanceof UKkbXBDRxjSUY) {
            goto CN6LN;
        }
        goto gLJwS;
        FKrsN:
        oBBjJ:
        goto Q_Tmz;
        gLJwS:
        return $this->resolvePath($P82oP, $P82oP->getAttribute('driver'));
        goto X9_62;
        dcmv2:
        return '';
        goto xIF4e;
        xIF4e:
    }
    private function url($hKqqZ, $RpHBQ)
    {
        goto Omf_n;
        kKFvF:
        return config('upload.home') . '/' . $hKqqZ;
        goto INd5A;
        INd5A:
        TfjUN:
        goto tz3CU;
        Omf_n:
        if (!($RpHBQ == YJGCddWUf6Zu2::LOCAL)) {
            goto TfjUN;
        }
        goto kKFvF;
        tz3CU:
        return $this->resolvePath($hKqqZ);
        goto twik_;
        twik_:
    }
    private function mAJ0SReQAgd($hKqqZ)
    {
        goto V4lOy;
        kDPrE:
        LU3XF:
        goto XAkKa;
        AL4Nh:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto cG9eN;
        kM_nn:
        $UYOFc = new UrlSigner($this->uCM72, $this->pCaD7->path($this->qT39W));
        goto XFVJq;
        V4lOy:
        if (!(strpos($hKqqZ, 'https://') === 0)) {
            goto LU3XF;
        }
        goto fCEYJ;
        fCEYJ:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto kDPrE;
        z03fC:
        $AunUY = now()->addMinutes(60)->timestamp;
        goto kM_nn;
        XAkKa:
        if (!(strpos($hKqqZ, 'm3u8') !== false)) {
            goto I1Kx3;
        }
        goto AL4Nh;
        cG9eN:
        I1Kx3:
        goto z03fC;
        XFVJq:
        return $UYOFc->getSignedUrl($this->i5ZeE . '/' . $hKqqZ, $AunUY);
        goto w2DnQ;
        w2DnQ:
    }
    public function resolvePathForHlsVideo(JPkW9ix1EKo3T $qF0aQ, $Aq2wX = false) : string
    {
        goto D8n5K;
        wLntL:
        V48gk:
        goto YXr7Z;
        VAMzo:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto wLntL;
        D8n5K:
        if ($qF0aQ->getAttribute('hls_path')) {
            goto V48gk;
        }
        goto VAMzo;
        YXr7Z:
        return $this->i5ZeE . '/' . $qF0aQ->getAttribute('hls_path');
        goto fN157;
        fN157:
    }
    public function resolvePathForHlsVideos()
    {
        goto rj4Qh;
        UUvya:
        return [$WxxMh, $AunUY];
        goto KjIjA;
        d1i9s:
        $MSWCX = $this->i5ZeE . '/v2/hls/';
        goto XvH2H;
        rj4Qh:
        $AunUY = now()->addDays(3)->timestamp;
        goto d1i9s;
        zzXX2:
        $WxxMh = $fIU4n->getSignedCookie(['key_pair_id' => $this->uCM72, 'private_key' => $this->pCaD7->path($this->qT39W), 'policy' => $PBA6H]);
        goto UUvya;
        XvH2H:
        $PBA6H = json_encode(['Statement' => [['Resource' => sprintf('%s*', $MSWCX), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $AunUY]]]]]);
        goto JHBPF;
        JHBPF:
        $fIU4n = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto zzXX2;
        KjIjA:
    }
}
