<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class SJvf1oBIJv75H implements VideoPostHandleServiceInterface
{
    private $Y5wYE;
    private $f1xKj;
    public function __construct(UploadServiceInterface $U13eD, Filesystem $C6boj)
    {
        $this->Y5wYE = $U13eD;
        $this->f1xKj = $C6boj;
    }
    public function saveMetadata(string $g5e_r, array $cor5J)
    {
        goto oJHIv;
        PPOSM:
        if (!$Uas5p->update($zbotp)) {
            goto OBTFm;
        }
        goto aSHUm;
        ts8GM:
        p_DUf:
        goto Yjp2G;
        XjUgu:
        if (!isset($cor5J['thumbnail_url'])) {
            goto p_DUf;
        }
        goto lfJPo;
        aSHUm:
        if (!(isset($cor5J['change_status']) && $cor5J['change_status'])) {
            goto BTvvU;
        }
        goto on73I;
        SY40q:
        return $Uas5p->getView();
        goto QpP2Q;
        xl4zP:
        try {
            goto XcJan;
            Uia2X:
            $zbotp['thumbnail_id'] = $T07ak['id'];
            goto gNSVd;
            gNSVd:
            $zbotp['thumbnail'] = $T07ak['filename'];
            goto B3aGa;
            XcJan:
            $T07ak = $this->Y5wYE->storeSingleFile(new class($cor5J['thumbnail']) implements SingleUploadInterface
            {
                private $R_58H;
                public function __construct($eQ4Ln)
                {
                    $this->R_58H = $eQ4Ln;
                }
                public function getFile()
                {
                    return $this->R_58H;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Uia2X;
            B3aGa:
        } catch (\Throwable $lzebJ) {
            Log::warning("JbxOPjx4A3DUY thumbnail store failed: " . $lzebJ->getMessage());
        }
        goto YmQ4a;
        Yjp2G:
        if (!isset($cor5J['thumbnail'])) {
            goto bdez2;
        }
        goto xl4zP;
        k5zXA:
        if (!isset($cor5J['duration'])) {
            goto kx8Vh;
        }
        goto un4wX;
        un4wX:
        $zbotp['duration'] = $cor5J['duration'];
        goto IYMNz;
        KlxVh:
        $zbotp['resolution'] = $cor5J['resolution'];
        goto PPfJs;
        hR6n0:
        jT3Ll:
        goto PPOSM;
        on73I:
        $this->Y5wYE->updateFile($Uas5p->getAttribute('id'), MUu80sOhINyO3::PROCESSING);
        goto VZKRP;
        YnjVP:
        if (!isset($cor5J['fps'])) {
            goto kE8u5;
        }
        goto fpPkS;
        YmQ4a:
        bdez2:
        goto k5zXA;
        c8ktY:
        $zbotp = [];
        goto XjUgu;
        iKhK0:
        throw new \Exception("JbxOPjx4A3DUY metadata store failed for unknown reason ... " . $g5e_r);
        goto gSjv2;
        lfJPo:
        $zbotp['thumbnail'] = $cor5J['thumbnail_url'];
        goto ts8GM;
        nUVat:
        unset($zbotp['thumbnail']);
        goto hR6n0;
        PPfJs:
        JINnY:
        goto YnjVP;
        VZKRP:
        BTvvU:
        goto SY40q;
        fpPkS:
        $zbotp['fps'] = $cor5J['fps'];
        goto TSX8z;
        oJHIv:
        $Uas5p = JbxOPjx4A3DUY::findOrFail($g5e_r);
        goto c8ktY;
        OXUb2:
        if (!$Uas5p->wVPkg) {
            goto jT3Ll;
        }
        goto nUVat;
        IYMNz:
        kx8Vh:
        goto x7Q67;
        TSX8z:
        kE8u5:
        goto OXUb2;
        QpP2Q:
        OBTFm:
        goto yO1QW;
        x7Q67:
        if (!isset($cor5J['resolution'])) {
            goto JINnY;
        }
        goto KlxVh;
        yO1QW:
        Log::warning("JbxOPjx4A3DUY metadata store failed for unknown reason ... " . $g5e_r);
        goto iKhK0;
        gSjv2:
    }
    public function createThumbnail(string $kLFNR) : void
    {
        goto cT7Tg;
        NFGMg:
        if (!(!$this->f1xKj->directoryExists($C21b_) && empty($Uas5p->mclJFenLDZi()))) {
            goto K57AB;
        }
        goto htPhQ;
        cT7Tg:
        Log::info("Use Lambda to generate thumbnail for video: " . $kLFNR);
        goto d4o2n;
        H1gto:
        try {
            goto wcdXJ;
            kp5_M:
            $jA7hc = $hgkP6->get('QueueUrl');
            goto mq6Mw;
            mq6Mw:
            $L3XiW->sendMessage(['QueueUrl' => $jA7hc, 'MessageBody' => json_encode(['file_path' => $Uas5p->getLocation()])]);
            goto jraHp;
            wcdXJ:
            $hgkP6 = $L3XiW->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto kp5_M;
            jraHp:
        } catch (\Throwable $X_03M) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$X_03M->getMessage()}");
        }
        goto YisIn;
        aoK9E:
        $C21b_ = "v2/hls/thumbnails/{$kLFNR}/";
        goto NFGMg;
        YisIn:
        K57AB:
        goto GL4h0;
        htPhQ:
        $L3XiW = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto H1gto;
        d4o2n:
        $Uas5p = JbxOPjx4A3DUY::findOrFail($kLFNR);
        goto aoK9E;
        GL4h0:
    }
    public function mYKbCh57okv(string $kLFNR) : void
    {
        goto t7msS;
        PWONA:
        leRiM:
        goto LLohS;
        cmtyp:
        G4RaW:
        goto UW_I0;
        RZJKF:
        Log::error("Message back with success data but not found thumbnail files " . $kLFNR);
        goto LfzxV;
        XiyQl:
        $C21b_ = "v2/hls/thumbnails/{$kLFNR}/";
        goto E4x1n;
        LLohS:
        $Uas5p->update(['generated_previews' => $C21b_]);
        goto k90Q_;
        LfzxV:
        throw new \Exception("Message back with success data but not found thumbnail files " . $kLFNR);
        goto PWONA;
        t7msS:
        $Uas5p = JbxOPjx4A3DUY::findOrFail($kLFNR);
        goto XiyQl;
        E4x1n:
        if ($this->f1xKj->directoryExists($C21b_)) {
            goto G4RaW;
        }
        goto goer0;
        VsRiG:
        if (!(count($B1xo6) === 0)) {
            goto leRiM;
        }
        goto RZJKF;
        UoYVc:
        throw new \Exception("Message back with success data but not found thumbnail " . $kLFNR);
        goto cmtyp;
        goer0:
        Log::error("Message back with success data but not found thumbnail " . $kLFNR);
        goto UoYVc;
        UW_I0:
        $B1xo6 = $this->f1xKj->files($C21b_);
        goto VsRiG;
        k90Q_:
    }
    public function getThumbnails(string $kLFNR) : array
    {
        $Uas5p = JbxOPjx4A3DUY::findOrFail($kLFNR);
        return $Uas5p->getThumbnails();
    }
    public function getMedia(string $kLFNR) : array
    {
        $LiWvx = Media::findOrFail($kLFNR);
        return $LiWvx->getView();
    }
}
