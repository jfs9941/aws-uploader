<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\IqdLBxImTkuBV;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Core\XHvEDPKBjvWLs;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
final class KS7YippgDSDNy implements IqdLBxImTkuBV
{
    private $K43hy;
    private $jm7e0;
    public $Yh9Mj;
    private $K1NZa;
    private $KwP6K;
    private $MpAl4;
    public function __construct($SlUKz, $Zlm1z, $H4V7t, $iTwya, $PWm_j, $U2KRS)
    {
        goto x5Ic5;
        gX2Kn:
        $this->KwP6K = $PWm_j;
        goto RCFeI;
        x5Ic5:
        $this->MpAl4 = $U2KRS;
        goto Ztiwp;
        jU3Aw:
        $this->Yh9Mj = $H4V7t;
        goto RQTiM;
        FSn39:
        $this->jm7e0 = $Zlm1z;
        goto jU3Aw;
        RQTiM:
        $this->K1NZa = $iTwya;
        goto gX2Kn;
        Ztiwp:
        $this->K43hy = $SlUKz;
        goto FSn39;
        RCFeI:
    }
    public function resolvePath($zr5kh, $X0gtT = McZXbZmlQ53or::S3) : string
    {
        goto AduY7;
        Sh5XG:
        if (!$this->K43hy) {
            goto MaCoZ;
        }
        goto F4O4K;
        hzy9v:
        MaCoZ:
        goto CVIEY;
        F4O4K:
        return trim($this->Yh9Mj, '/') . '/' . $zr5kh;
        goto hzy9v;
        gdyhD:
        if (!(!empty($this->K1NZa) && !empty($this->KwP6K))) {
            goto iBQUE;
        }
        goto u3WAi;
        CVIEY:
        return trim($this->jm7e0, '/') . '/' . $zr5kh;
        goto RhYqZ;
        YU2zw:
        return config('upload.home') . '/' . $zr5kh;
        goto U1GR7;
        AduY7:
        if (!$zr5kh instanceof GpdHFYchpZHPa) {
            goto vVjYH;
        }
        goto uTpVi;
        u3WAi:
        return $this->mJHF1E3f5ID($zr5kh);
        goto PYLX3;
        LP7Hp:
        vVjYH:
        goto UJ1Ek;
        uTpVi:
        $zr5kh = $zr5kh->getAttribute('filename');
        goto LP7Hp;
        UJ1Ek:
        if (!($X0gtT === McZXbZmlQ53or::LOCAL)) {
            goto xEyeA;
        }
        goto YU2zw;
        PYLX3:
        iBQUE:
        goto Sh5XG;
        U1GR7:
        xEyeA:
        goto gdyhD;
        RhYqZ:
    }
    public function resolveThumbnail(GpdHFYchpZHPa $zr5kh) : string
    {
        goto JROTU;
        l6aeY:
        if (!$zr5kh->getAttribute('thumbnail_id')) {
            goto fKEsb;
        }
        goto DM4WS;
        wwtPs:
        if (!$Doe8z) {
            goto nj83j;
        }
        goto UhH2e;
        sHwqD:
        return $this->url($lSq7k, $zr5kh->getAttribute('driver'));
        goto YMZLg;
        guaIM:
        if (!$zr5kh instanceof XHvEDPKBjvWLs) {
            goto mVPRv;
        }
        goto A1jCT;
        UhH2e:
        return $this->resolvePath($Doe8z, $Doe8z->getAttribute('driver'));
        goto gzIbr;
        ddz4r:
        mVPRv:
        goto USt1s;
        gzIbr:
        nj83j:
        goto KdWHL;
        KdWHL:
        fKEsb:
        goto HB2EC;
        YMZLg:
        SR7ML:
        goto l6aeY;
        JROTU:
        $lSq7k = $zr5kh->getAttribute('thumbnail');
        goto PnQoA;
        HB2EC:
        if (!$zr5kh instanceof KfEJaEGpFJ0tm) {
            goto x1r57;
        }
        goto HxTyy;
        O5873:
        x1r57:
        goto guaIM;
        A1jCT:
        return asset('/img/pdf-preview.svg');
        goto ddz4r;
        HxTyy:
        return $this->resolvePath($zr5kh, $zr5kh->getAttribute('driver'));
        goto O5873;
        PnQoA:
        if (!$lSq7k) {
            goto SR7ML;
        }
        goto sHwqD;
        USt1s:
        return '';
        goto sTJc9;
        DM4WS:
        $Doe8z = KfEJaEGpFJ0tm::find($zr5kh->getAttribute('thumbnail_id'));
        goto wwtPs;
        sTJc9:
    }
    private function url($d1QWa, $X0gtT)
    {
        goto QJwtB;
        V6gPd:
        Rj6zX:
        goto mwund;
        SHqMJ:
        return config('upload.home') . '/' . $d1QWa;
        goto V6gPd;
        QJwtB:
        if (!($X0gtT == McZXbZmlQ53or::LOCAL)) {
            goto Rj6zX;
        }
        goto SHqMJ;
        mwund:
        return $this->resolvePath($d1QWa);
        goto c8rcA;
        c8rcA:
    }
    private function mJHF1E3f5ID($d1QWa)
    {
        goto mzKED;
        YaejV:
        $isV1D = new UrlSigner($this->K1NZa, $this->MpAl4->path($this->KwP6K));
        goto n0CVd;
        rScFe:
        DqUe3:
        goto upGgM;
        UXlry:
        oi6Rv:
        goto IEgop;
        lMdu2:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto UXlry;
        upGgM:
        if (!(strpos($d1QWa, 'm3u8') !== false)) {
            goto oi6Rv;
        }
        goto lMdu2;
        mzKED:
        if (!(strpos($d1QWa, 'https://') === 0)) {
            goto DqUe3;
        }
        goto qgqfm;
        n0CVd:
        return $isV1D->getSignedUrl($this->Yh9Mj . '/' . $d1QWa, $UnF8u);
        goto AUnxh;
        IEgop:
        $UnF8u = now()->addMinutes(60)->timestamp;
        goto YaejV;
        qgqfm:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto rScFe;
        AUnxh:
    }
    public function resolvePathForHlsVideo(BtruCfJoaSWZ6 $Bh2o5, $Y0x4V = false) : string
    {
        goto Qr9h3;
        DqNW3:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto gwyBe;
        Qr9h3:
        if ($Bh2o5->getAttribute('hls_path')) {
            goto dgbZA;
        }
        goto DqNW3;
        gwyBe:
        dgbZA:
        goto iEqXv;
        iEqXv:
        return $this->Yh9Mj . '/' . $Bh2o5->getAttribute('hls_path');
        goto mfUQW;
        mfUQW:
    }
    public function resolvePathForHlsVideos()
    {
        goto q1TUv;
        vNJk7:
        $Zsc2n = json_encode(['Statement' => [['Resource' => sprintf('%s*', $mwYKS), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $UnF8u]]]]]);
        goto xooSh;
        xooSh:
        $De3o9 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Yeqnu;
        q1TUv:
        $UnF8u = now()->addDays(3)->timestamp;
        goto ZifH1;
        ZifH1:
        $mwYKS = $this->Yh9Mj . '/v2/hls/';
        goto vNJk7;
        Yeqnu:
        $Gr607 = $De3o9->getSignedCookie(['key_pair_id' => $this->K1NZa, 'private_key' => $this->MpAl4->path($this->KwP6K), 'policy' => $Zsc2n]);
        goto OgEze;
        OgEze:
        return [$Gr607, $UnF8u];
        goto rZn3u;
        rZn3u:
    }
}
