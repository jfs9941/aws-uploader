<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Core\NGxsa4jamJSuW;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
final class JNMuh7Oo3jHTF implements QhwgYzl056fwk
{
    private $O37bQ;
    private $Jhlkd;
    public $nmxA2;
    private $OoMX9;
    private $tbdHN;
    private $kxBLk;
    public function __construct($uHGgk, $gFKtf, $YqKCW, $urtJY, $zLA7R, $dgfeu)
    {
        goto WiEFT;
        IIKVN:
        $this->OoMX9 = $urtJY;
        goto l_txx;
        rr818:
        $this->O37bQ = $uHGgk;
        goto B7IYj;
        XZuUt:
        $this->nmxA2 = $YqKCW;
        goto IIKVN;
        WiEFT:
        $this->kxBLk = $dgfeu;
        goto rr818;
        B7IYj:
        $this->Jhlkd = $gFKtf;
        goto XZuUt;
        l_txx:
        $this->tbdHN = $zLA7R;
        goto qig2A;
        qig2A:
    }
    public function resolvePath($qRTR9, $doABn = WG4kCv0INtCV4::S3) : string
    {
        goto HHaHh;
        KaG46:
        Ri68l:
        goto uxS6t;
        ZM817:
        iJ1ev:
        goto Ix1Jz;
        Ix1Jz:
        if (!(!empty($this->OoMX9) && !empty($this->tbdHN))) {
            goto Eea4o;
        }
        goto g3Bq9;
        FG5H1:
        Uz4uU:
        goto pUVYM;
        FQ6Bp:
        $qRTR9 = $qRTR9->getAttribute('filename');
        goto KaG46;
        C3vcX:
        if (!$this->O37bQ) {
            goto Uz4uU;
        }
        goto jHt8N;
        uxS6t:
        if (!($doABn === WG4kCv0INtCV4::LOCAL)) {
            goto iJ1ev;
        }
        goto FuG4R;
        pUVYM:
        return trim($this->Jhlkd, '/') . '/' . $qRTR9;
        goto Il2X1;
        FuG4R:
        return config('upload.home') . '/' . $qRTR9;
        goto ZM817;
        g3Bq9:
        return $this->mtuSATt2NTy($qRTR9);
        goto uQBni;
        uQBni:
        Eea4o:
        goto C3vcX;
        jHt8N:
        return trim($this->nmxA2, '/') . '/' . $qRTR9;
        goto FG5H1;
        HHaHh:
        if (!$qRTR9 instanceof UKWxL8i4Jx2NZ) {
            goto Ri68l;
        }
        goto FQ6Bp;
        Il2X1:
    }
    public function resolveThumbnail(UKWxL8i4Jx2NZ $qRTR9) : string
    {
        goto kVLPD;
        gvv5Q:
        if (!$qRTR9 instanceof NGxsa4jamJSuW) {
            goto wrRPU;
        }
        goto oLaa3;
        wgRqC:
        if (!$qRTR9->getAttribute('thumbnail_id')) {
            goto IhUnf;
        }
        goto jSX0M;
        iRuaG:
        return '';
        goto MKZVi;
        isG6n:
        if (!$qRTR9 instanceof LGMw063tEE9ZC) {
            goto yZnjb;
        }
        goto LOofA;
        oBM4c:
        if (!$w0nRj) {
            goto H1Ow6;
        }
        goto SpOmQ;
        cBgDD:
        IhUnf:
        goto isG6n;
        jSX0M:
        $w0nRj = LGMw063tEE9ZC::find($qRTR9->getAttribute('thumbnail_id'));
        goto oBM4c;
        kVLPD:
        $qqIkT = $qRTR9->getAttribute('thumbnail');
        goto w6NG5;
        p5mAQ:
        yZnjb:
        goto gvv5Q;
        SpOmQ:
        return $this->resolvePath($w0nRj, $w0nRj->getAttribute('driver'));
        goto zM4rI;
        OL73i:
        zm_TZ:
        goto wgRqC;
        PMVdh:
        wrRPU:
        goto iRuaG;
        oLaa3:
        return asset('/img/pdf-preview.svg');
        goto PMVdh;
        w6NG5:
        if (!$qqIkT) {
            goto zm_TZ;
        }
        goto JvoRw;
        LOofA:
        return $this->resolvePath($qRTR9, $qRTR9->getAttribute('driver'));
        goto p5mAQ;
        JvoRw:
        return $this->url($qqIkT, $qRTR9->getAttribute('driver'));
        goto OL73i;
        zM4rI:
        H1Ow6:
        goto cBgDD;
        MKZVi:
    }
    private function url($IB9Pt, $doABn)
    {
        goto e7IR1;
        B41l5:
        return $this->resolvePath($IB9Pt);
        goto tx8cu;
        xBhqO:
        return config('upload.home') . '/' . $IB9Pt;
        goto y2nYH;
        e7IR1:
        if (!($doABn == WG4kCv0INtCV4::LOCAL)) {
            goto YSo2M;
        }
        goto xBhqO;
        y2nYH:
        YSo2M:
        goto B41l5;
        tx8cu:
    }
    private function mtuSATt2NTy($IB9Pt)
    {
        goto pg3L9;
        tK7MD:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto N8ChQ;
        hFJM7:
        if (!(strpos($IB9Pt, 'm3u8') !== false)) {
            goto mlaKa;
        }
        goto PjWHt;
        WsAba:
        return $fLF8A->getSignedUrl($this->nmxA2 . '/' . $IB9Pt, $DecoN);
        goto jUlUT;
        pg3L9:
        if (!(strpos($IB9Pt, 'https://') === 0)) {
            goto ouo5E;
        }
        goto tK7MD;
        PjWHt:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto Ltpmn;
        VblBH:
        $fLF8A = new UrlSigner($this->OoMX9, $this->kxBLk->path($this->tbdHN));
        goto WsAba;
        Ltpmn:
        mlaKa:
        goto VJAHb;
        VJAHb:
        $DecoN = now()->addMinutes(60)->timestamp;
        goto VblBH;
        N8ChQ:
        ouo5E:
        goto hFJM7;
        jUlUT:
    }
    public function resolvePathForHlsVideo(GXtnGiMmIPEIc $aiCaH, $pAoAm = false) : string
    {
        goto VE2Jd;
        J013z:
        return $this->nmxA2 . '/' . $aiCaH->getAttribute('hls_path');
        goto O_SKq;
        Z6ebl:
        hZw0w:
        goto J013z;
        VE2Jd:
        if ($aiCaH->getAttribute('hls_path')) {
            goto hZw0w;
        }
        goto RdpXT;
        RdpXT:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Z6ebl;
        O_SKq:
    }
    public function resolvePathForHlsVideos()
    {
        goto cMAD0;
        PYxxF:
        return [$uRTHx, $DecoN];
        goto LL3Bq;
        E5fHR:
        $uRTHx = $JSrSN->getSignedCookie(['key_pair_id' => $this->OoMX9, 'private_key' => $this->kxBLk->path($this->tbdHN), 'policy' => $X30Gv]);
        goto PYxxF;
        ksqsf:
        $X30Gv = json_encode(['Statement' => [['Resource' => sprintf('%s*', $ac3gK), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $DecoN]]]]]);
        goto b4w1S;
        b4w1S:
        $JSrSN = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto E5fHR;
        cMAD0:
        $DecoN = now()->addDays(3)->timestamp;
        goto A8LCD;
        A8LCD:
        $ac3gK = $this->nmxA2 . '/v2/hls/';
        goto ksqsf;
        LL3Bq:
    }
}
