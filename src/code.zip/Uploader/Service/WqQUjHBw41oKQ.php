<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Illuminate\Contracts\Filesystem\Filesystem;
final class WqQUjHBw41oKQ
{
    private $nmHDC;
    private $K8UNE;
    private $TD3CW;
    public function __construct(string $wIlgi, string $O04KP, Filesystem $e3uVO)
    {
        goto V2NHJ;
        V2NHJ:
        $this->nmHDC = $wIlgi;
        goto ib0WA;
        ib0WA:
        $this->K8UNE = $O04KP;
        goto Myq94;
        Myq94:
        $this->TD3CW = $e3uVO;
        goto ESkgO;
        ESkgO:
    }
    public function mCDchjUG6CP(GSmU4C9IL4AGB $qc05M) : string
    {
        goto P9X0A;
        kTtd1:
        return 's3://' . $this->nmHDC . '/' . $qc05M->getAttribute('filename');
        goto Zy5hF;
        Zy5hF:
        iiW4Z:
        goto qtguO;
        P9X0A:
        if (!(Ef6Dy6MoUDei9::S3 == $qc05M->getAttribute('driver'))) {
            goto iiW4Z;
        }
        goto kTtd1;
        qtguO:
        return $this->TD3CW->url($qc05M->getAttribute('filename'));
        goto BZwR1;
        BZwR1:
    }
    public function mxGU2PsdveS(?string $YHzDC) : ?string
    {
        goto XeDhl;
        EoPfD:
        Nc6C7:
        goto XXKiu;
        XXKiu:
        ew0Dt:
        goto CoMtB;
        XeDhl:
        if (!$YHzDC) {
            goto ew0Dt;
        }
        goto TnMij;
        CoMtB:
        return null;
        goto qETJt;
        TnMij:
        if (!str_contains($YHzDC, $this->nmHDC)) {
            goto Nc6C7;
        }
        goto qNLsp;
        achtE:
        return 's3://' . $this->nmHDC . '/' . ltrim($HCRCz, '/');
        goto EoPfD;
        qNLsp:
        $HCRCz = parse_url($YHzDC, PHP_URL_PATH);
        goto achtE;
        qETJt:
    }
    public function mLlkzeq9PSv(string $HCRCz) : string
    {
        return 's3://' . $this->nmHDC . '/' . $HCRCz;
    }
}
