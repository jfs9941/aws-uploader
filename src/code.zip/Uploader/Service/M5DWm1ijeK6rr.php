<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Core\Observer\AtOTtTkiX6GMV;
use Jfs\Uploader\Core\Observer\Evt0eRmgZr9qI;
use Jfs\Uploader\Core\NYMdb5NeWwwAT;
use Jfs\Uploader\Core\VxPWGO5HkTQsP;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Exception\C4FBIUHwDz2gM;
use Jfs\Uploader\Service\FileResolver\WXA8QNbPhilkb;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class M5DWm1ijeK6rr
{
    private $wovlm;
    private $gcP3F;
    private $D9Jo8;
    public function __construct($BZRr2, $qxxOf, $v1Edp)
    {
        goto g9oBs;
        uu5pN:
        $this->gcP3F = $qxxOf;
        goto o06g1;
        g9oBs:
        $this->wovlm = $BZRr2;
        goto uu5pN;
        o06g1:
        $this->D9Jo8 = $v1Edp;
        goto A1CFt;
        A1CFt:
    }
    public function mTnv6u1hmho($uSgC_)
    {
        goto bhdX3;
        eZ6Ua:
        $Y_BIU = $uSgC_->getFile();
        goto XEZHr;
        XEZHr:
        return $this->mDyovwb5hof($Y_BIU->extension(), L2PWLPeQEFi6U::S3, null, $uSgC_->options());
        goto qYTKM;
        wNcUx:
        return $this->mDyovwb5hof($uSgC_['file_extension'], 's3' === $uSgC_['driver'] ? L2PWLPeQEFi6U::S3 : L2PWLPeQEFi6U::LOCAL);
        goto kwQwb;
        qYTKM:
        u38hc:
        goto wNcUx;
        bhdX3:
        if (!$uSgC_ instanceof SingleUploadInterface) {
            goto u38hc;
        }
        goto eZ6Ua;
        kwQwb:
    }
    public function mMSQxytue1Q(string $poSkG)
    {
        goto waCSQ;
        waCSQ:
        $xLiVA = config('upload.attachment_model')::findOrFail($poSkG);
        goto YHXCM;
        oDKJo:
        $pemjO->exists = true;
        goto SmQ1g;
        YHXCM:
        $pemjO = $this->mDyovwb5hof($xLiVA->getAttribute('type'), $xLiVA->getAttribute('driver'), $xLiVA->getAttribute('id'));
        goto oDKJo;
        mKMfW:
        return $pemjO;
        goto jacHX;
        SmQ1g:
        $pemjO->setRawAttributes($xLiVA->getAttributes());
        goto mKMfW;
        jacHX:
    }
    public function mMpOj656eUB(string $GhmM9) : H1Ax5lj0mb7kw
    {
        goto ffijL;
        S8yGB:
        $KaQe1 = VxPWGO5HkTQsP::mG35AK3eSZV($LGjda);
        goto rZi8V;
        f1457:
        throw new DRgeXfZrFFnZd('metadata file not found');
        goto CPye_;
        djZQd:
        if ($PeqKg) {
            goto cM3MT;
        }
        goto pJKcv;
        GJsu3:
        O1uZg:
        goto f1457;
        GsMdB:
        if (!$LGjda) {
            goto O1uZg;
        }
        goto S8yGB;
        rZi8V:
        return $this->mDyovwb5hof($KaQe1->hQA9w, $KaQe1->m1e3rAwPpDG(), $KaQe1->filename);
        goto GJsu3;
        pJKcv:
        $PeqKg = $this->D9Jo8->get($GhmM9);
        goto brlHk;
        ffijL:
        $PeqKg = $this->gcP3F->get($GhmM9);
        goto djZQd;
        brlHk:
        cM3MT:
        goto NgRtP;
        NgRtP:
        $LGjda = json_decode($PeqKg, true);
        goto GsMdB;
        CPye_:
    }
    private function mDyovwb5hof(string $bpe62, $VccJL, ?string $poSkG = null, array $KzVpB = [])
    {
        goto xyxPW;
        rmyzw:
        ZNSoP:
        goto px6T3;
        MxQFv:
        $Cewcr = $Cewcr->mJVMJSwyqT5($VccJL);
        goto SY0zw;
        rG3zv:
        Lb3EB:
        goto oWZEd;
        xwax_:
        $Cewcr->mj3Wprz3dA2(new Evt0eRmgZr9qI($Cewcr, $this->D9Jo8, $KzVpB));
        goto Er8nw;
        Er8nw:
        foreach ($this->wovlm as $oiRO1) {
            goto plWvo;
            plWvo:
            if (!$oiRO1->mGIGUCsbdzj($Cewcr)) {
                goto lGizq;
            }
            goto uV9gR;
            uV9gR:
            return $Cewcr->initLocation($oiRO1->m5jaJGYYMNB($Cewcr));
            goto thqBb;
            k_Xh1:
            FKC3a:
            goto LvERg;
            thqBb:
            lGizq:
            goto k_Xh1;
            LvERg:
        }
        goto rmyzw;
        SY0zw:
        $Cewcr->mj3Wprz3dA2(new AtOTtTkiX6GMV($Cewcr));
        goto xwax_;
        px6T3:
        throw new C4FBIUHwDz2gM("not support file type {$bpe62}");
        goto QHKil;
        oWZEd:
        ZADRs:
        goto MxQFv;
        xyxPW:
        $poSkG = $poSkG ?? Uuid::uuid4()->getHex()->toString();
        goto K07DB;
        K07DB:
        switch ($bpe62) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $Cewcr = KZbAaRxCqNUr3::createFromScratch($poSkG, $bpe62);
                goto ZADRs;
            case 'mp4':
            case 'mov':
                $Cewcr = ISYJHQo8eqdfc::createFromScratch($poSkG, $bpe62);
                goto ZADRs;
            case 'pdf':
                $Cewcr = NYMdb5NeWwwAT::createFromScratch($poSkG, $bpe62);
                goto ZADRs;
            default:
                throw new C4FBIUHwDz2gM("not support file type {$bpe62}");
        }
        goto rG3zv;
        QHKil:
    }
}
