<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HQQLwdzkwB4WZ
{
    private $VwfNm;
    private $ouKTQ;
    private $h0iwI;
    public function __construct(string $XbR1L, string $sSJTk, Filesystem $jxMWP)
    {
        goto PHLOE;
        WgV4z:
        $this->ouKTQ = $sSJTk;
        goto Z7jgM;
        PHLOE:
        $this->VwfNm = $XbR1L;
        goto WgV4z;
        Z7jgM:
        $this->h0iwI = $jxMWP;
        goto aK1uL;
        aK1uL:
    }
    public function m5C0HpJtdiA(Z3KXO9qO3sUsa $ieBz5) : string
    {
        goto t1UKt;
        QS7wN:
        return $this->h0iwI->url($ieBz5->getAttribute('filename'));
        goto JH85c;
        t1UKt:
        if (!(ISqBWmYzjt1eQ::S3 == $ieBz5->getAttribute('driver'))) {
            goto SLAkp;
        }
        goto lVxOb;
        HQrtG:
        SLAkp:
        goto QS7wN;
        lVxOb:
        return 's3://' . $this->VwfNm . '/' . $ieBz5->getAttribute('filename');
        goto HQrtG;
        JH85c:
    }
    public function mxS1IntlutZ(?string $aIReC) : ?string
    {
        goto bmPRc;
        sswvw:
        UjPwP:
        goto oFVMr;
        C43ph:
        $fQjwQ = parse_url($aIReC, PHP_URL_PATH);
        goto Xf494;
        yGFL1:
        return null;
        goto xYtpT;
        bmPRc:
        if (!$aIReC) {
            goto iwAOK;
        }
        goto oCfIa;
        oFVMr:
        iwAOK:
        goto yGFL1;
        oCfIa:
        if (!d9V0h($aIReC, $this->VwfNm)) {
            goto UjPwP;
        }
        goto C43ph;
        Xf494:
        return 's3://' . $this->VwfNm . '/' . ltrim($fQjwQ, '/');
        goto sswvw;
        xYtpT:
    }
    public function mmrCLjm7lkY(string $fQjwQ) : string
    {
        return 's3://' . $this->VwfNm . '/' . $fQjwQ;
    }
}
