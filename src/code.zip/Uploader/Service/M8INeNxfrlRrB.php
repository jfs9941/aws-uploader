<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\N6d9ndnX4hqae;
use Jfs\Uploader\Core\WEJt1TL92SawT;
use Jfs\Uploader\Core\JNVd14WbS7J31;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Jfs\Uploader\Exception\JcxKbdowoFJnP;
use Jfs\Uploader\Exception\KWF9YuEFOPZRY;
use Jfs\Uploader\Exception\Hs8uHMlcZHaHS;
use Jfs\Uploader\Service\S0Eg4TIBvz6Wk;
use Illuminate\Contracts\Filesystem\Filesystem;
final class M8INeNxfrlRrB implements UploadServiceInterface
{
    private $vsgGh;
    private $IdG3S;
    private $m1Mjp;
    private $ty10_;
    public function __construct(S0Eg4TIBvz6Wk $N67XC, Filesystem $ftmEm, Filesystem $ZIdyH, string $KHqmZ)
    {
        goto UVqmE;
        jrw8J:
        $this->ty10_ = $KHqmZ;
        goto CL2Dx;
        nUFuq:
        $this->m1Mjp = $ZIdyH;
        goto jrw8J;
        UVqmE:
        $this->vsgGh = $N67XC;
        goto iSm76;
        iSm76:
        $this->IdG3S = $ftmEm;
        goto nUFuq;
        CL2Dx:
    }
    public function storeSingleFile(SingleUploadInterface $Sb1Tl) : array
    {
        goto v3192;
        V5142:
        return $z620p->getView();
        goto dq8EK;
        v3192:
        $z620p = $this->vsgGh->m7cwl4D8wFi($Sb1Tl);
        goto IuSzJ;
        sgn0w:
        $z620p->mmjJCJ3ck7B(QE1dzvgcPWV6R::UPLOADED);
        goto s2x96;
        qJoLt:
        if (false !== $liQkG && $z620p instanceof N6d9ndnX4hqae) {
            goto CjZVY;
        }
        goto ycgK5;
        o6yUO:
        goto PKWs6;
        goto zkJyH;
        s2x96:
        PKWs6:
        goto V5142;
        zkJyH:
        CjZVY:
        goto sgn0w;
        ycgK5:
        throw new \LogicException('File upload failed, check permissions');
        goto o6yUO;
        IuSzJ:
        $liQkG = $this->m1Mjp->putFileAs(dirname($z620p->getLocation()), $Sb1Tl->getFile(), $z620p->getFilename() . '.' . $z620p->getExtension(), ['visibility' => 'public']);
        goto qJoLt;
        dq8EK:
    }
    public function storePreSignedFile(array $qJ3Yb)
    {
        goto hv4i7;
        wWzEG:
        return ['filename' => $G3hwE->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $G3hwE->mu3g2CSVJ9h()];
        goto JXBa9;
        NuBPI:
        $G3hwE->mGSEj9gXQjR();
        goto wWzEG;
        hv4i7:
        $z620p = $this->vsgGh->m7cwl4D8wFi($qJ3Yb);
        goto FmUIt;
        oQ0qM:
        $G3hwE->mCCDubV0cmy($qJ3Yb['mime'], $qJ3Yb['file_size'], $qJ3Yb['chunk_size'], $qJ3Yb['checksums'], $qJ3Yb['user_id'], $qJ3Yb['driver']);
        goto NuBPI;
        FmUIt:
        $G3hwE = JNVd14WbS7J31::m7yAyRmGtiO($z620p, $this->IdG3S, $this->m1Mjp, $this->ty10_, true);
        goto oQ0qM;
        JXBa9:
    }
    public function updatePreSignedFile(string $N2QfI, int $ysV4o)
    {
        goto faWXg;
        faWXg:
        $G3hwE = JNVd14WbS7J31::m8oJUULbBkM($N2QfI, $this->IdG3S, $this->m1Mjp, $this->ty10_);
        goto Jp2L6;
        kNNEY:
        GIGCG:
        goto LjqX6;
        Jp2L6:
        switch ($ysV4o) {
            case QE1dzvgcPWV6R::UPLOADED:
                $G3hwE->mRPr5DiMacW();
                goto GIGCG;
            case QE1dzvgcPWV6R::PROCESSING:
                $G3hwE->mKRSYThlX7Q();
                goto GIGCG;
            case QE1dzvgcPWV6R::FINISHED:
                $G3hwE->mquRbyd079o();
                goto GIGCG;
            case QE1dzvgcPWV6R::ABORTED:
                $G3hwE->m7ENYq6iRcE();
                goto GIGCG;
        }
        goto LWoIY;
        LWoIY:
        hMh_s:
        goto kNNEY;
        LjqX6:
    }
    public function completePreSignedFile(string $N2QfI, array $p4mmG)
    {
        goto kbgQ_;
        kbgQ_:
        $G3hwE = JNVd14WbS7J31::m8oJUULbBkM($N2QfI, $this->IdG3S, $this->m1Mjp, $this->ty10_);
        goto LJfGL;
        h4ts2:
        return ['path' => $G3hwE->getFile()->getView()['path'], 'thumbnail' => $G3hwE->getFile()->BvW5c, 'id' => $N2QfI];
        goto bOqof;
        LJfGL:
        $G3hwE->m8Hi8VWicy3()->mPDjkmS6FtI($p4mmG);
        goto zqF_W;
        zqF_W:
        $G3hwE->mRPr5DiMacW();
        goto h4ts2;
        bOqof:
    }
    public function updateFile(string $N2QfI, int $ysV4o) : WEJt1TL92SawT
    {
        goto kQwbt;
        PQlLf:
        $z620p->mmjJCJ3ck7B($ysV4o);
        goto RdEiy;
        kQwbt:
        $z620p = $this->vsgGh->mwNZkm8EAWD($N2QfI);
        goto PQlLf;
        RdEiy:
        return $z620p;
        goto Xb1S7;
        Xb1S7:
    }
}
