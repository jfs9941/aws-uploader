<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Core\A9R6iJFlMGSBV;
use Jfs\Uploader\Core\DXmfT6CslVApB;
use Jfs\Uploader\Enum\EUkqoDwU9Zcvh;
use Jfs\Uploader\Exception\BtFXMjsbQEzWB;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Jfs\Uploader\Exception\A0pWCtOCA3zPw;
final class NUNTQNmKEOem3 implements UploadServiceInterface
{
    private $skXZ4;
    private $s0VP1;
    private $JjUJH;
    private $fIQJR;
    public function __construct(ANTOKA6KWzE7t $qI_Ml, Filesystem $TuWZt, Filesystem $qg6AO, string $B1cTW)
    {
        goto TszN7;
        Cs3_K:
        $this->fIQJR = $B1cTW;
        goto j0Siz;
        PMS19:
        $this->s0VP1 = $TuWZt;
        goto ZjwrQ;
        TszN7:
        $this->skXZ4 = $qI_Ml;
        goto PMS19;
        ZjwrQ:
        $this->JjUJH = $qg6AO;
        goto Cs3_K;
        j0Siz:
    }
    public function storeSingleFile(SingleUploadInterface $vKDlk) : array
    {
        goto GaM6S;
        lUEoX:
        $z69yI = $this->JjUJH->putFileAs(dirname($VZzWw->getLocation()), $vKDlk->getFile(), $VZzWw->getFilename() . '.' . $VZzWw->getExtension(), ['visibility' => 'public']);
        goto WeA93;
        uAKe6:
        gDnUf:
        goto qvoqi;
        GaM6S:
        $VZzWw = $this->skXZ4->mG1Vpid3zRU($vKDlk);
        goto lUEoX;
        czF7D:
        goto V_2J_;
        goto uAKe6;
        WeA93:
        if (false !== $z69yI && $VZzWw instanceof BCa3K9pPFzXM0) {
            goto gDnUf;
        }
        goto cG43h;
        EWwst:
        V_2J_:
        goto xUj61;
        qvoqi:
        $VZzWw->mhWKUa6jAoa(EUkqoDwU9Zcvh::UPLOADED);
        goto EWwst;
        xUj61:
        return $VZzWw->getView();
        goto kEmuq;
        cG43h:
        throw new \LogicException('File upload failed, check permissions');
        goto czF7D;
        kEmuq:
    }
    public function storePreSignedFile(array $bnV2N)
    {
        goto hxsu1;
        hxsu1:
        $VZzWw = $this->skXZ4->mG1Vpid3zRU($bnV2N);
        goto iK6gW;
        iK6gW:
        $C2BaX = DXmfT6CslVApB::mj70qEmfHlK($VZzWw, $this->s0VP1, $this->JjUJH, $this->fIQJR, true);
        goto Jx2wB;
        y25cD:
        $C2BaX->mvqJM3fUrjw();
        goto omMCF;
        Jx2wB:
        $C2BaX->mh4ISMbiacT($bnV2N['mime'], $bnV2N['file_size'], $bnV2N['chunk_size'], $bnV2N['checksums'], $bnV2N['user_id'], $bnV2N['driver']);
        goto y25cD;
        omMCF:
        return ['filename' => $C2BaX->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $C2BaX->mS0UOkfpCpF()];
        goto w9dkc;
        w9dkc:
    }
    public function updatePreSignedFile(string $P0cHT, int $PQkD0)
    {
        goto ewtEG;
        UEFA6:
        K6oPj:
        goto O1j64;
        ewtEG:
        $C2BaX = DXmfT6CslVApB::mRdLbWPGoE4($P0cHT, $this->s0VP1, $this->JjUJH, $this->fIQJR);
        goto mtBAg;
        O1j64:
        Sf29M:
        goto WQhm5;
        mtBAg:
        switch ($PQkD0) {
            case EUkqoDwU9Zcvh::UPLOADED:
                $C2BaX->mmU0aSbrCKc();
                goto Sf29M;
            case EUkqoDwU9Zcvh::PROCESSING:
                $C2BaX->mxra39H1jik();
                goto Sf29M;
            case EUkqoDwU9Zcvh::FINISHED:
                $C2BaX->mxI99kBkJYY();
                goto Sf29M;
            case EUkqoDwU9Zcvh::ABORTED:
                $C2BaX->mh0nhrQjPJe();
                goto Sf29M;
        }
        goto UEFA6;
        WQhm5:
    }
    public function completePreSignedFile(string $P0cHT, array $Wft18)
    {
        goto HmcaR;
        lJRr2:
        $C2BaX->mmU0aSbrCKc();
        goto YgRdM;
        FfTKp:
        $C2BaX->m6oz0N1G29M()->mzqBOhybw6d($Wft18);
        goto lJRr2;
        HmcaR:
        $C2BaX = DXmfT6CslVApB::mRdLbWPGoE4($P0cHT, $this->s0VP1, $this->JjUJH, $this->fIQJR);
        goto FfTKp;
        YgRdM:
        return ['path' => $C2BaX->getFile()->getView()['path'], 'thumbnail' => $C2BaX->getFile()->YLj7w, 'id' => $P0cHT];
        goto jvSic;
        jvSic:
    }
    public function updateFile(string $P0cHT, int $PQkD0) : A9R6iJFlMGSBV
    {
        goto EQr5x;
        EQr5x:
        $VZzWw = $this->skXZ4->m8OPFlA7Pti($P0cHT);
        goto Orqfy;
        Orqfy:
        $VZzWw->mhWKUa6jAoa($PQkD0);
        goto a2zgJ;
        a2zgJ:
        return $VZzWw;
        goto I1O19;
        I1O19:
    }
}
