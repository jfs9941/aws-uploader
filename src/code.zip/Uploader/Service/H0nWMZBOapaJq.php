<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\Jhd15nso8PpYk;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Core\QzHAZxZkrX5gT;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
final class H0nWMZBOapaJq implements Jhd15nso8PpYk
{
    private $bcZuK;
    private $ChEaS;
    public $Ic6gr;
    private $mZsg0;
    private $ofBsB;
    private $aW0a3;
    public function __construct($A9ZFD, $WMvjc, $JLAs7, $maqzq, $pw490, $eEhuZ)
    {
        goto K61Dj;
        PGbPp:
        $this->ChEaS = $WMvjc;
        goto VozMF;
        K61Dj:
        $this->aW0a3 = $eEhuZ;
        goto mB4EV;
        QiqOS:
        $this->mZsg0 = $maqzq;
        goto W7IEp;
        mB4EV:
        $this->bcZuK = $A9ZFD;
        goto PGbPp;
        W7IEp:
        $this->ofBsB = $pw490;
        goto vTKWw;
        VozMF:
        $this->Ic6gr = $JLAs7;
        goto QiqOS;
        vTKWw:
    }
    public function resolvePath($lOhz0, $tbIVu = YOaiWCgFM7tRK::S3) : string
    {
        goto Y3fB6;
        CosUo:
        return config('upload.home') . '/' . $lOhz0;
        goto qq93r;
        lb13k:
        if (!$this->bcZuK) {
            goto gVZ0e;
        }
        goto bMKQM;
        BJN74:
        if (!($tbIVu === YOaiWCgFM7tRK::LOCAL)) {
            goto MH0x1;
        }
        goto CosUo;
        zZxLh:
        TjRdP:
        goto lb13k;
        YQlra:
        if (!(!empty($this->mZsg0) && !empty($this->ofBsB))) {
            goto TjRdP;
        }
        goto MDMBk;
        qq93r:
        MH0x1:
        goto YQlra;
        d_Fg2:
        return trim($this->ChEaS, '/') . '/' . $lOhz0;
        goto Vtnth;
        lbX14:
        kSctX:
        goto BJN74;
        mS81R:
        gVZ0e:
        goto d_Fg2;
        MDMBk:
        return $this->mh3IDfc2UEG($lOhz0);
        goto zZxLh;
        bMKQM:
        return trim($this->Ic6gr, '/') . '/' . $lOhz0;
        goto mS81R;
        Y3fB6:
        if (!$lOhz0 instanceof Rqw1PJIt1YU1r) {
            goto kSctX;
        }
        goto NnMkh;
        NnMkh:
        $lOhz0 = $lOhz0->getAttribute('filename');
        goto lbX14;
        Vtnth:
    }
    public function resolveThumbnail(Rqw1PJIt1YU1r $lOhz0) : string
    {
        goto fAFnp;
        Cv51Q:
        yHtks:
        goto Ep3rC;
        E6Nz8:
        return $this->url($f_EWh, $lOhz0->getAttribute('driver'));
        goto kYwSt;
        nLMz0:
        IE2lN:
        goto q3fNE;
        q3fNE:
        return '';
        goto zHFSP;
        BL0d7:
        if (!$f_EWh) {
            goto pKGpk;
        }
        goto E6Nz8;
        Ep3rC:
        N7MgA:
        goto B4XB4;
        B4XB4:
        if (!$lOhz0 instanceof WUuz09CA4woAL) {
            goto N3pl6;
        }
        goto t1_9B;
        JQ01f:
        if (!$lOhz0 instanceof QzHAZxZkrX5gT) {
            goto IE2lN;
        }
        goto fTPmF;
        fTPmF:
        return asset('/img/pdf-preview.svg');
        goto nLMz0;
        jUOW_:
        return $this->resolvePath($mXEmG, $mXEmG->getAttribute('driver'));
        goto Cv51Q;
        GVKEc:
        if (!$lOhz0->getAttribute('thumbnail_id')) {
            goto N7MgA;
        }
        goto rM2vw;
        jUA12:
        N3pl6:
        goto JQ01f;
        kYwSt:
        pKGpk:
        goto GVKEc;
        YYR1o:
        if (!$mXEmG) {
            goto yHtks;
        }
        goto jUOW_;
        fAFnp:
        $f_EWh = $lOhz0->getAttribute('thumbnail');
        goto BL0d7;
        rM2vw:
        $mXEmG = WUuz09CA4woAL::find($lOhz0->getAttribute('thumbnail_id'));
        goto YYR1o;
        t1_9B:
        return $this->resolvePath($lOhz0, $lOhz0->getAttribute('driver'));
        goto jUA12;
        zHFSP:
    }
    private function url($b0LKC, $tbIVu)
    {
        goto r9Owa;
        mEv3i:
        return config('upload.home') . '/' . $b0LKC;
        goto BaelU;
        BaelU:
        S8GMW:
        goto i66qT;
        i66qT:
        return $this->resolvePath($b0LKC);
        goto zJAsD;
        r9Owa:
        if (!($tbIVu == YOaiWCgFM7tRK::LOCAL)) {
            goto S8GMW;
        }
        goto mEv3i;
        zJAsD:
    }
    private function mh3IDfc2UEG($b0LKC)
    {
        goto S_0be;
        S_0be:
        if (!(strpos($b0LKC, 'https://') === 0)) {
            goto XPrVm;
        }
        goto sHBWK;
        yehN1:
        WtPUq:
        goto TPAxt;
        IDg6Q:
        return $rY4IV->getSignedUrl($this->Ic6gr . '/' . $b0LKC, $bAovC);
        goto SaAsv;
        sHBWK:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto bIj49;
        QvttU:
        $rY4IV = new UrlSigner($this->mZsg0, $this->aW0a3->path($this->ofBsB));
        goto IDg6Q;
        vyUfD:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto yehN1;
        pmS24:
        if (!(strpos($b0LKC, 'm3u8') !== false)) {
            goto WtPUq;
        }
        goto vyUfD;
        bIj49:
        XPrVm:
        goto pmS24;
        TPAxt:
        $bAovC = now()->addMinutes(60)->timestamp;
        goto QvttU;
        SaAsv:
    }
    public function resolvePathForHlsVideo(NYx4mhlHSMgHF $JhYqb, $zVZeW = false) : string
    {
        goto UNMRP;
        Lk3Z6:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto xnjgP;
        UNMRP:
        if ($JhYqb->getAttribute('hls_path')) {
            goto gMFab;
        }
        goto Lk3Z6;
        xnjgP:
        gMFab:
        goto v2hSv;
        v2hSv:
        return $this->Ic6gr . '/' . $JhYqb->getAttribute('hls_path');
        goto ys4Hi;
        ys4Hi:
    }
    public function resolvePathForHlsVideos()
    {
        goto HgvWB;
        Ov2G1:
        $SROZT = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto wDQGY;
        HgvWB:
        $bAovC = now()->addDays(3)->timestamp;
        goto iWOFO;
        bWN87:
        $hsM93 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $sYEX2), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $bAovC]]]]]);
        goto Ov2G1;
        iWOFO:
        $sYEX2 = $this->Ic6gr . '/v2/hls/';
        goto bWN87;
        lwGop:
        return [$mQls3, $bAovC];
        goto bHSO0;
        wDQGY:
        $mQls3 = $SROZT->getSignedCookie(['key_pair_id' => $this->mZsg0, 'private_key' => $this->aW0a3->path($this->ofBsB), 'policy' => $hsM93]);
        goto lwGop;
        bHSO0:
    }
}
