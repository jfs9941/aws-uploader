<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\QguGxHrrpjTia;
use Jfs\Uploader\Core\WGN88W9AFumiX;
use Jfs\Uploader\Core\VxCHgU78wg1To;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Jfs\Uploader\Exception\VwJ7WJWdWWDDp;
use Jfs\Uploader\Exception\XEcmSsCY89ji0;
use Jfs\Uploader\Exception\B3AeVUIqKwlr4;
use Jfs\Uploader\Service\UG0KhqkrdbP7y;
use Illuminate\Contracts\Filesystem\Filesystem;
final class T8lrozxGunpO1 implements UploadServiceInterface
{
    private $Oj7XK;
    private $c5PSU;
    private $RGW8z;
    private $IpFZx;
    public function __construct(UG0KhqkrdbP7y $umSaF, Filesystem $Ape3_, Filesystem $Dm30C, string $Gwv6p)
    {
        goto M06zn;
        ze2VZ:
        $this->IpFZx = $Gwv6p;
        goto U55pX;
        Sw6Lr:
        $this->RGW8z = $Dm30C;
        goto ze2VZ;
        M06zn:
        $this->Oj7XK = $umSaF;
        goto rmAy_;
        rmAy_:
        $this->c5PSU = $Ape3_;
        goto Sw6Lr;
        U55pX:
    }
    public function storeSingleFile(SingleUploadInterface $xPe8Y) : array
    {
        goto Py356;
        kd1VY:
        return $s2INV->getView();
        goto wLgFx;
        P16Xe:
        goto d_zXQ;
        goto N11eB;
        N11eB:
        VRpmj:
        goto V3g3s;
        Py356:
        $s2INV = $this->Oj7XK->m4VrCkMB9Yn($xPe8Y);
        goto rpo4H;
        rpo4H:
        $HyAAV = $this->RGW8z->putFileAs(dirname($s2INV->getLocation()), $xPe8Y->getFile(), $s2INV->getFilename() . '.' . $s2INV->getExtension(), ['visibility' => 'public']);
        goto XplNQ;
        sPNJg:
        d_zXQ:
        goto kd1VY;
        V3g3s:
        $s2INV->mImL6eGj9Ei(IOEDyer18cpSA::UPLOADED);
        goto sPNJg;
        Svgr7:
        throw new \LogicException('File upload failed, check permissions');
        goto P16Xe;
        XplNQ:
        if (false !== $HyAAV && $s2INV instanceof QguGxHrrpjTia) {
            goto VRpmj;
        }
        goto Svgr7;
        wLgFx:
    }
    public function storePreSignedFile(array $Rc_sg)
    {
        goto LmrLJ;
        LmrLJ:
        $s2INV = $this->Oj7XK->m4VrCkMB9Yn($Rc_sg);
        goto pL1oH;
        qXTOO:
        $TUNr2->mUDGSa6H1gD();
        goto eXmUf;
        eXmUf:
        return ['filename' => $TUNr2->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $TUNr2->mhgeh6QrYq1()];
        goto HzfZv;
        pL1oH:
        $TUNr2 = VxCHgU78wg1To::maXmMkbjItR($s2INV, $this->c5PSU, $this->RGW8z, $this->IpFZx, true);
        goto KYwMu;
        KYwMu:
        $TUNr2->mpVytGF7tI4($Rc_sg['mime'], $Rc_sg['file_size'], $Rc_sg['chunk_size'], $Rc_sg['checksums'], $Rc_sg['user_id'], $Rc_sg['driver']);
        goto qXTOO;
        HzfZv:
    }
    public function updatePreSignedFile(string $WParL, int $IyxEG)
    {
        goto vmSrs;
        DZdoL:
        switch ($IyxEG) {
            case IOEDyer18cpSA::UPLOADED:
                $TUNr2->mDoXvmsg17o();
                goto Ru1_k;
            case IOEDyer18cpSA::PROCESSING:
                $TUNr2->mhuIi5rAodZ();
                goto Ru1_k;
            case IOEDyer18cpSA::FINISHED:
                $TUNr2->muVkUevgapd();
                goto Ru1_k;
            case IOEDyer18cpSA::ABORTED:
                $TUNr2->mNhdxZgLIOC();
                goto Ru1_k;
        }
        goto SH2EY;
        TSJDN:
        Ru1_k:
        goto OoyXE;
        SH2EY:
        h2n8M:
        goto TSJDN;
        vmSrs:
        $TUNr2 = VxCHgU78wg1To::migKxo4kk5f($WParL, $this->c5PSU, $this->RGW8z, $this->IpFZx);
        goto DZdoL;
        OoyXE:
    }
    public function completePreSignedFile(string $WParL, array $RNKEH)
    {
        goto QDJmM;
        Gpzlo:
        $TUNr2->muUg8to4YNh()->mNQMB9ljE16($RNKEH);
        goto bWiH7;
        bWiH7:
        $TUNr2->mDoXvmsg17o();
        goto G8NTz;
        QDJmM:
        $TUNr2 = VxCHgU78wg1To::migKxo4kk5f($WParL, $this->c5PSU, $this->RGW8z, $this->IpFZx);
        goto Gpzlo;
        G8NTz:
        return ['path' => $TUNr2->getFile()->getView()['path'], 'thumbnail' => $TUNr2->getFile()->vo8A1, 'id' => $WParL];
        goto pAp7r;
        pAp7r:
    }
    public function updateFile(string $WParL, int $IyxEG) : WGN88W9AFumiX
    {
        goto XXaFK;
        G113W:
        return $s2INV;
        goto o4_uR;
        XXaFK:
        $s2INV = $this->Oj7XK->m0MzbMShfS0($WParL);
        goto sNzxU;
        sNzxU:
        $s2INV->mImL6eGj9Ei($IyxEG);
        goto G113W;
        o4_uR:
    }
}
