<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Service;

use backup\Exposed\AVqShGCH8LOrP;
use backup\Exposed\ArCSgsnvTg6Tv;
use backup\Uploader\Contracts\VnrpqIkXJe1mn;
use backup\Uploader\Core\YcdplGVWzA91v;
use backup\Uploader\Core\Pb0Dvv7XIOUP3;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use backup\Uploader\Exception\Y86LODF9txYbT;
use backup\Uploader\Exception\Asi2ubH37e0l9;
use backup\Uploader\Exception\HXV6iIC92kwG6;
use backup\Uploader\Service\IJhG5F6LYY6Bm;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ZRCryMN7FHJvx implements ArCSgsnvTg6Tv
{
    private $VetPU;
    private $FJZRi;
    private $JINyv;
    private $Vv8Nv;
    public function __construct(IJhG5F6LYY6Bm $QA3AV, Filesystem $UEDUm, Filesystem $s49oM, string $oDPJ3)
    {
        goto lrqGx;
        YE1Vs:
        $this->FJZRi = $UEDUm;
        goto evEk3;
        VMg3c:
        $this->Vv8Nv = $oDPJ3;
        goto Gagti;
        lrqGx:
        $this->VetPU = $QA3AV;
        goto YE1Vs;
        evEk3:
        $this->JINyv = $s49oM;
        goto VMg3c;
        Gagti:
    }
    public function storeSingleFile(AVqShGCH8LOrP $eHM2N) : array
    {
        goto DltRr;
        qBd8u:
        return $eVZrJ->getView();
        goto y9Pni;
        W2h3l:
        $KPnwr = $this->JINyv->putFileAs(dirname($eVZrJ->getLocation()), $eHM2N->getFile(), $eVZrJ->getFilename() . '.' . $eVZrJ->getExtension(), ['visibility' => 'public']);
        goto wf2bk;
        wT6yV:
        iVPp9:
        goto qBd8u;
        KVAc3:
        throw new \LogicException('File upload failed, check permissions');
        goto odA39;
        f8h_g:
        rKPmc:
        goto P0dIb;
        wf2bk:
        if (false !== $KPnwr && $eVZrJ instanceof VnrpqIkXJe1mn) {
            goto rKPmc;
        }
        goto KVAc3;
        odA39:
        goto iVPp9;
        goto f8h_g;
        DltRr:
        $eVZrJ = $this->VetPU->mS3C4QCDDWI($eHM2N);
        goto W2h3l;
        P0dIb:
        $eVZrJ->mKOiTrzpM4V(Aetm2HiFuJE34::UPLOADED);
        goto wT6yV;
        y9Pni:
    }
    public function storePreSignedFile(array $pmYea)
    {
        goto KRDTY;
        fZWek:
        $D5W64 = Pb0Dvv7XIOUP3::mbt3puUz4JF($eVZrJ, $this->FJZRi, $this->JINyv, $this->Vv8Nv, true);
        goto UT89C;
        QeouY:
        return ['filename' => $D5W64->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $D5W64->m9pzqYgcboi()];
        goto uu5Hl;
        PenCY:
        $D5W64->mbBXZP0P4f9();
        goto QeouY;
        UT89C:
        $D5W64->m3gXtxRraDA($pmYea['mime'], $pmYea['file_size'], $pmYea['chunk_size'], $pmYea['checksums'], $pmYea['user_id'], $pmYea['driver']);
        goto PenCY;
        KRDTY:
        $eVZrJ = $this->VetPU->mS3C4QCDDWI($pmYea);
        goto fZWek;
        uu5Hl:
    }
    public function updatePreSignedFile(string $Pa87e, int $l3ws7)
    {
        goto hjMG9;
        srMAM:
        switch ($l3ws7) {
            case Aetm2HiFuJE34::UPLOADED:
                $D5W64->meHZvCsm6LD();
                goto mvz2A;
            case Aetm2HiFuJE34::PROCESSING:
                $D5W64->mj70zs86IlD();
                goto mvz2A;
            case Aetm2HiFuJE34::FINISHED:
                $D5W64->mM9Bg0ljJBz();
                goto mvz2A;
            case Aetm2HiFuJE34::ABORTED:
                $D5W64->mlQSGoMVhvh();
                goto mvz2A;
        }
        goto WQhDf;
        hjMG9:
        $D5W64 = Pb0Dvv7XIOUP3::mDPNDjYdhNx($Pa87e, $this->FJZRi, $this->JINyv, $this->Vv8Nv);
        goto srMAM;
        zLMER:
        mvz2A:
        goto lcxQv;
        WQhDf:
        blcQI:
        goto zLMER;
        lcxQv:
    }
    public function completePreSignedFile(string $Pa87e, array $QIhb6)
    {
        goto PeQpp;
        PeQpp:
        $D5W64 = Pb0Dvv7XIOUP3::mDPNDjYdhNx($Pa87e, $this->FJZRi, $this->JINyv, $this->Vv8Nv);
        goto BoR9X;
        z90hh:
        return ['path' => $D5W64->getFile()->getView()['path'], 'thumbnail' => $D5W64->getFile()->PLX0U, 'id' => $Pa87e];
        goto uuVrd;
        BoR9X:
        $D5W64->m77UJKssxZ5()->mWjGOocUYVy($QIhb6);
        goto lHP6y;
        lHP6y:
        $D5W64->meHZvCsm6LD();
        goto z90hh;
        uuVrd:
    }
    public function updateFile(string $Pa87e, int $l3ws7) : YcdplGVWzA91v
    {
        goto Vt6KA;
        ZBvx3:
        $eVZrJ->mKOiTrzpM4V($l3ws7);
        goto yd1Bs;
        yd1Bs:
        return $eVZrJ;
        goto wmRae;
        Vt6KA:
        $eVZrJ = $this->VetPU->mRfTuN5hXz0($Pa87e);
        goto ZBvx3;
        wmRae:
    }
}
