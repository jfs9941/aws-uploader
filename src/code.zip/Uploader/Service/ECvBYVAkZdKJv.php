<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class ECvBYVAkZdKJv implements VideoPostHandleServiceInterface
{
    private $mZ31h;
    private $D9Jo8;
    public function __construct(UploadServiceInterface $hMd62, Filesystem $v1Edp)
    {
        $this->mZ31h = $hMd62;
        $this->D9Jo8 = $v1Edp;
    }
    public function saveMetadata(string $poSkG, array $LGjda)
    {
        goto Z_O0A;
        kJT23:
        if (!isset($LGjda['resolution'])) {
            goto Zzs_9;
        }
        goto wXC3O;
        CGVV2:
        etmtj:
        goto FvR_V;
        awDd3:
        $Z41QP['thumbnail'] = $LGjda['thumbnail_url'];
        goto IQkVR;
        FvR_V:
        return $qNHE7->getView();
        goto m9PGU;
        m9PGU:
        rVrRL:
        goto YgwR4;
        Hsw1m:
        N7AF9:
        goto kJT23;
        wXC3O:
        $Z41QP['resolution'] = $LGjda['resolution'];
        goto RvigN;
        RvigN:
        Zzs_9:
        goto vo09Q;
        heWT5:
        $Z41QP['fps'] = $LGjda['fps'];
        goto qmde0;
        FNjfG:
        $Z41QP = [];
        goto U1ck0;
        vBFfX:
        IJA8Z:
        goto E6N_B;
        Fzwzv:
        if (!isset($LGjda['thumbnail'])) {
            goto Ovlui;
        }
        goto mrp1G;
        CJLA1:
        unset($Z41QP['thumbnail']);
        goto vBFfX;
        bG8fP:
        $Z41QP['duration'] = $LGjda['duration'];
        goto Hsw1m;
        E6N_B:
        if (!$qNHE7->update($Z41QP)) {
            goto rVrRL;
        }
        goto Mn16K;
        mrp1G:
        try {
            goto dRYv5;
            sqg00:
            $Z41QP['thumbnail_id'] = $eeT1E['id'];
            goto rnaJc;
            rnaJc:
            $Z41QP['thumbnail'] = $eeT1E['filename'];
            goto EMTtr;
            dRYv5:
            $eeT1E = $this->mZ31h->storeSingleFile(new class($LGjda['thumbnail']) implements SingleUploadInterface
            {
                private $XHy23;
                public function __construct($pemjO)
                {
                    $this->XHy23 = $pemjO;
                }
                public function getFile()
                {
                    return $this->XHy23;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto sqg00;
            EMTtr:
        } catch (\Throwable $R1uEk) {
            Log::warning("ISYJHQo8eqdfc thumbnail store failed: " . $R1uEk->getMessage());
        }
        goto O1fjZ;
        qmde0:
        xjr3S:
        goto C9rc6;
        U1ck0:
        if (!isset($LGjda['thumbnail_url'])) {
            goto y5Qpu;
        }
        goto awDd3;
        Mn16K:
        if (!(isset($LGjda['change_status']) && $LGjda['change_status'])) {
            goto etmtj;
        }
        goto DfNbM;
        IQkVR:
        y5Qpu:
        goto Fzwzv;
        DfNbM:
        $this->mZ31h->updateFile($qNHE7->getAttribute('id'), IOOvAXAyKHLW2::PROCESSING);
        goto CGVV2;
        vo09Q:
        if (!isset($LGjda['fps'])) {
            goto xjr3S;
        }
        goto heWT5;
        Z_O0A:
        $qNHE7 = ISYJHQo8eqdfc::findOrFail($poSkG);
        goto FNjfG;
        UxrHZ:
        if (!isset($LGjda['duration'])) {
            goto N7AF9;
        }
        goto bG8fP;
        O1fjZ:
        Ovlui:
        goto UxrHZ;
        C9rc6:
        if (!$qNHE7->Ij3xP) {
            goto IJA8Z;
        }
        goto CJLA1;
        eSPrY:
        throw new \Exception("ISYJHQo8eqdfc metadata store failed for unknown reason ... " . $poSkG);
        goto BtZfv;
        YgwR4:
        Log::warning("ISYJHQo8eqdfc metadata store failed for unknown reason ... " . $poSkG);
        goto eSPrY;
        BtZfv:
    }
    public function createThumbnail(string $SIB_I) : void
    {
        goto oisyI;
        u401s:
        try {
            goto RGV1v;
            eYqY7:
            $VpYX3->sendMessage(['QueueUrl' => $C_cV4, 'MessageBody' => json_encode(['file_path' => $qNHE7->getLocation()])]);
            goto zs6wk;
            r0bPk:
            $C_cV4 = $RHAJI->get('QueueUrl');
            goto eYqY7;
            RGV1v:
            $RHAJI = $VpYX3->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto r0bPk;
            zs6wk:
        } catch (\Throwable $RUf1Z) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$RUf1Z->getMessage()}");
        }
        goto L76Jo;
        L76Jo:
        gdrza:
        goto TBSpF;
        k128C:
        if (!(!$this->D9Jo8->directoryExists($seZ3K) && empty($qNHE7->mbYASwyVXoG()))) {
            goto gdrza;
        }
        goto GKjtS;
        oisyI:
        Log::info("Use Lambda to generate thumbnail for video: " . $SIB_I);
        goto vyIYk;
        sdGGk:
        $seZ3K = "v2/hls/thumbnails/{$SIB_I}/";
        goto k128C;
        vyIYk:
        $qNHE7 = ISYJHQo8eqdfc::findOrFail($SIB_I);
        goto sdGGk;
        GKjtS:
        $VpYX3 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto u401s;
        TBSpF:
    }
    public function m7CIgBQXF6i(string $SIB_I) : void
    {
        goto oaBPj;
        GJdcc:
        throw new \Exception("Message back with success data but not found thumbnail files " . $SIB_I);
        goto PBPnB;
        ooGUE:
        Log::error("Message back with success data but not found thumbnail files " . $SIB_I);
        goto GJdcc;
        kvgBS:
        X2yhf:
        goto NIBZ6;
        qoo98:
        $seZ3K = "v2/hls/thumbnails/{$SIB_I}/";
        goto U3Pi0;
        Rjroi:
        Log::error("Message back with success data but not found thumbnail " . $SIB_I);
        goto Ex8g6;
        ERGl0:
        $qNHE7->update(['generated_previews' => $seZ3K]);
        goto cgBi_;
        U3Pi0:
        if ($this->D9Jo8->directoryExists($seZ3K)) {
            goto X2yhf;
        }
        goto Rjroi;
        PBPnB:
        K0wwi:
        goto ERGl0;
        Ex8g6:
        throw new \Exception("Message back with success data but not found thumbnail " . $SIB_I);
        goto kvgBS;
        sl4Zl:
        if (!(count($OAqPH) === 0)) {
            goto K0wwi;
        }
        goto ooGUE;
        oaBPj:
        $qNHE7 = ISYJHQo8eqdfc::findOrFail($SIB_I);
        goto qoo98;
        NIBZ6:
        $OAqPH = $this->D9Jo8->files($seZ3K);
        goto sl4Zl;
        cgBi_:
    }
    public function getThumbnails(string $SIB_I) : array
    {
        $qNHE7 = ISYJHQo8eqdfc::findOrFail($SIB_I);
        return $qNHE7->getThumbnails();
    }
    public function getMedia(string $SIB_I) : array
    {
        $F251H = Media::findOrFail($SIB_I);
        return $F251H->getView();
    }
}
