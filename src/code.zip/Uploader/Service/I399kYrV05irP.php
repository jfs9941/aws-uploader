<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\Dsl7Uurv4XRG0;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Core\Observer\WWNfwtucxYruU;
use Jfs\Uploader\Core\Observer\EZe8einihXqrI;
use Jfs\Uploader\Core\D7CMsi4o836Y7;
use Jfs\Uploader\Core\XlkXvlTYaUWJ1;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
use Jfs\Uploader\Exception\CU2TWW78cXYKP;
use Jfs\Uploader\Exception\WhP3OD3EOngaS;
use Jfs\Uploader\Service\FileResolver\PfK9DYjwsXm74;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class I399kYrV05irP
{
    private $ZfPjd;
    private $iAAqk;
    private $DksH2;
    public function __construct($cwuOU, $YNIuu, $l4Drs)
    {
        goto fdEEv;
        PcauE:
        $this->DksH2 = $l4Drs;
        goto UYZzj;
        fdEEv:
        $this->ZfPjd = $cwuOU;
        goto KEefu;
        KEefu:
        $this->iAAqk = $YNIuu;
        goto PcauE;
        UYZzj:
    }
    public function m47tVQzeONq($FT61L)
    {
        goto ArRaG;
        ArRaG:
        if (!$FT61L instanceof SingleUploadInterface) {
            goto fR8kZ;
        }
        goto fnmfI;
        HcAgl:
        fR8kZ:
        goto PV_AM;
        PV_AM:
        return $this->mSbFNWrLv8q($FT61L['file_extension'], 's3' === $FT61L['driver'] ? Tfi7lQDVWUJD9::S3 : Tfi7lQDVWUJD9::LOCAL);
        goto H2y9W;
        mNGyq:
        return $this->mSbFNWrLv8q($ld6S7->extension(), Tfi7lQDVWUJD9::S3, null, $FT61L->options());
        goto HcAgl;
        fnmfI:
        $ld6S7 = $FT61L->getFile();
        goto mNGyq;
        H2y9W:
    }
    public function mzxf0TVLumi(string $EmnXX)
    {
        goto xL81w;
        xL81w:
        $vvube = config('upload.attachment_model')::findOrFail($EmnXX);
        goto YTQZA;
        rxyoy:
        $cNpq7->exists = true;
        goto Po2c6;
        E9odg:
        return $cNpq7;
        goto QALr9;
        Po2c6:
        $cNpq7->setRawAttributes($vvube->getAttributes());
        goto E9odg;
        YTQZA:
        $cNpq7 = $this->mSbFNWrLv8q($vvube->getAttribute('type'), $vvube->getAttribute('driver'), $vvube->getAttribute('id'));
        goto rxyoy;
        QALr9:
    }
    public function mRh0zUGhT1w(string $xxhf_) : Dsl7Uurv4XRG0
    {
        goto jn8eG;
        GDWdD:
        kYyGs:
        goto AaL3Y;
        AaL3Y:
        throw new CU2TWW78cXYKP('metadata file not found');
        goto Rfbqz;
        VPYqF:
        $TxsWN = json_decode($OsZho, true);
        goto E_1JX;
        Ta3Yc:
        return $this->mSbFNWrLv8q($azgF8->L2IE8, $azgF8->mz7vW5seO1n(), $azgF8->filename);
        goto GDWdD;
        IlnEV:
        $azgF8 = XlkXvlTYaUWJ1::m8FyGRJIBo2($TxsWN);
        goto Ta3Yc;
        L2jrK:
        $OsZho = $this->DksH2->get($xxhf_);
        goto L5ysB;
        Wl0c3:
        if ($OsZho) {
            goto PK_1O;
        }
        goto L2jrK;
        E_1JX:
        if (!$TxsWN) {
            goto kYyGs;
        }
        goto IlnEV;
        jn8eG:
        $OsZho = $this->iAAqk->get($xxhf_);
        goto Wl0c3;
        L5ysB:
        PK_1O:
        goto VPYqF;
        Rfbqz:
    }
    private function mSbFNWrLv8q(string $lCXAT, $DXtxN, ?string $EmnXX = null, array $taWvo = [])
    {
        goto mbKZp;
        xjl4u:
        foreach ($this->ZfPjd as $WXNzZ) {
            goto mF_Et;
            dDpd0:
            EKA13:
            goto kjFyO;
            mF_Et:
            if (!$WXNzZ->mG6UvoJSEGE($cXy0J)) {
                goto EKA13;
            }
            goto bz6Ui;
            kjFyO:
            XoSBo:
            goto qOiRf;
            bz6Ui:
            return $cXy0J->initLocation($WXNzZ->mH4C7t0zM7i($cXy0J));
            goto dDpd0;
            qOiRf:
        }
        goto u5dVT;
        GQxGP:
        eRjME:
        goto mJYJy;
        jBdAK:
        $cXy0J->mi2D2FjJnRk(new WWNfwtucxYruU($cXy0J));
        goto daMPa;
        LgYzi:
        $cXy0J = $cXy0J->mFqiQhCCpL2($DXtxN);
        goto jBdAK;
        y1t9p:
        throw new WhP3OD3EOngaS("not support file type {$lCXAT}");
        goto Jr_1T;
        mJYJy:
        lYtNJ:
        goto LgYzi;
        mbKZp:
        $EmnXX = $EmnXX ?? Uuid::uuid4()->getHex()->toString();
        goto NkQuj;
        daMPa:
        $cXy0J->mi2D2FjJnRk(new EZe8einihXqrI($cXy0J, $this->DksH2, $taWvo));
        goto xjl4u;
        NkQuj:
        switch ($lCXAT) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $cXy0J = Q48IcpSr3UpAT::createFromScratch($EmnXX, $lCXAT);
                goto lYtNJ;
            case 'mp4':
            case 'mov':
                $cXy0J = M7oTJdNm24KG4::createFromScratch($EmnXX, $lCXAT);
                goto lYtNJ;
            case 'pdf':
                $cXy0J = D7CMsi4o836Y7::createFromScratch($EmnXX, $lCXAT);
                goto lYtNJ;
            default:
                throw new WhP3OD3EOngaS("not support file type {$lCXAT}");
        }
        goto GQxGP;
        u5dVT:
        wMeVE:
        goto y1t9p;
        Jr_1T:
    }
}
