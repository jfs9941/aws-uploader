<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup\Uploader\Service;

use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Enum\XmcIS8CQn72i3;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HgXaT629cXC5e
{
    private $tv4bE;
    private $m6auY;
    private $FJZRi;
    public function __construct(string $ClLup, string $y5d6a, Filesystem $UEDUm)
    {
        goto k5LFt;
        k5LFt:
        $this->tv4bE = $ClLup;
        goto FgP3w;
        FgP3w:
        $this->m6auY = $y5d6a;
        goto LxPkv;
        LxPkv:
        $this->FJZRi = $UEDUm;
        goto wwqG_;
        wwqG_:
    }
    public function mk4pX5POad5(PJqa0Yy2jwBHe $JFGfH) : string
    {
        goto enA3b;
        oTvyp:
        return $this->FJZRi->url($JFGfH->getAttribute('filename'));
        goto Vq1Qv;
        enA3b:
        if (!(XmcIS8CQn72i3::S3 == $JFGfH->getAttribute('driver'))) {
            goto XcuKf;
        }
        goto erNa9;
        jh2Ny:
        XcuKf:
        goto oTvyp;
        erNa9:
        return 's3://' . $this->tv4bE . '/' . $JFGfH->getAttribute('filename');
        goto jh2Ny;
        Vq1Qv:
    }
    public function my1sV4yCLdL(?string $gdAso) : ?string
    {
        goto Zn34C;
        Se75o:
        return null;
        goto kgQxy;
        yBLRn:
        return 's3://' . $this->tv4bE . '/' . ltrim($KPnwr, '/');
        goto ak9_u;
        MDt3R:
        if (!aKu6Z($gdAso, $this->tv4bE)) {
            goto WtWhC;
        }
        goto THB77;
        ak9_u:
        WtWhC:
        goto IIC20;
        Zn34C:
        if (!$gdAso) {
            goto VBzDw;
        }
        goto MDt3R;
        IIC20:
        VBzDw:
        goto Se75o;
        THB77:
        $KPnwr = parse_url($gdAso, PHP_URL_PATH);
        goto yBLRn;
        kgQxy:
    }
    public function m9W44hJCIbw(string $KPnwr) : string
    {
        return 's3://' . $this->tv4bE . '/' . $KPnwr;
    }
}
