<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\ZE3znzkASutzh;
use Jfs\Uploader\Core\RV6vDyOPhxLM1;
use Jfs\Uploader\Core\PLi20pZSTTBHP;
use Jfs\Uploader\Enum\TSfaBZEUMcbl0;
use Jfs\Uploader\Exception\FLUrTiCUjjZmC;
use Jfs\Uploader\Exception\Jcm0L35ZiDWQ6;
use Jfs\Uploader\Exception\W9MQd1eHMaESp;
use Jfs\Uploader\Service\VQRb8yFeCwEOC;
use Illuminate\Contracts\Filesystem\Filesystem;
final class UJeFcSXtJOW66 implements UploadServiceInterface
{
    private $MojYA;
    private $pXh9P;
    private $Tfy0l;
    private $t4e7r;
    public function __construct(VQRb8yFeCwEOC $zeQ6j, Filesystem $TWZho, Filesystem $bnvNm, string $JjE4f)
    {
        goto vsH66;
        SmDMX:
        $this->Tfy0l = $bnvNm;
        goto wAAAy;
        vsH66:
        $this->MojYA = $zeQ6j;
        goto AJpWB;
        AJpWB:
        $this->pXh9P = $TWZho;
        goto SmDMX;
        wAAAy:
        $this->t4e7r = $JjE4f;
        goto mlgwM;
        mlgwM:
    }
    public function storeSingleFile(SingleUploadInterface $K1Nwh) : array
    {
        goto pitKp;
        CJsWk:
        goto Oa909;
        goto jVAsn;
        NBlrL:
        throw new \LogicException('File upload failed, check permissions');
        goto CJsWk;
        vZu6G:
        $b0LKC = $this->Tfy0l->putFileAs(dirname($ZPsYd->getLocation()), $K1Nwh->getFile(), $ZPsYd->getFilename() . '.' . $ZPsYd->getExtension(), ['visibility' => 'public']);
        goto XyIf0;
        XyIf0:
        if (false !== $b0LKC && $ZPsYd instanceof ZE3znzkASutzh) {
            goto WphzG;
        }
        goto NBlrL;
        jVAsn:
        WphzG:
        goto jaWJG;
        rc4NP:
        Oa909:
        goto D5EL6;
        D5EL6:
        return $ZPsYd->getView();
        goto pvXLw;
        jaWJG:
        $ZPsYd->mvj3nnnI629(TSfaBZEUMcbl0::UPLOADED);
        goto rc4NP;
        pitKp:
        $ZPsYd = $this->MojYA->mFTsQyvMslN($K1Nwh);
        goto vZu6G;
        pvXLw:
    }
    public function storePreSignedFile(array $xGbvr)
    {
        goto ib9hD;
        mbyiT:
        $k0UDg->mhqFrMTjd6I();
        goto YekvO;
        eL_Yu:
        $k0UDg->mrsdCE1eS2e($xGbvr['mime'], $xGbvr['file_size'], $xGbvr['chunk_size'], $xGbvr['checksums'], $xGbvr['user_id'], $xGbvr['driver']);
        goto mbyiT;
        ib9hD:
        $ZPsYd = $this->MojYA->mFTsQyvMslN($xGbvr);
        goto niWa0;
        YekvO:
        return ['filename' => $k0UDg->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $k0UDg->mmY4tt6vTUT()];
        goto AZEEL;
        niWa0:
        $k0UDg = PLi20pZSTTBHP::mKV13015Spd($ZPsYd, $this->pXh9P, $this->Tfy0l, $this->t4e7r, true);
        goto eL_Yu;
        AZEEL:
    }
    public function updatePreSignedFile(string $L5KaZ, int $E1cd2)
    {
        goto k5PGT;
        DUEPf:
        Sj4EX:
        goto GosUg;
        dlV5M:
        switch ($E1cd2) {
            case TSfaBZEUMcbl0::UPLOADED:
                $k0UDg->mOpCwXOW98b();
                goto c2PXV;
            case TSfaBZEUMcbl0::PROCESSING:
                $k0UDg->mdd0tVETjoQ();
                goto c2PXV;
            case TSfaBZEUMcbl0::FINISHED:
                $k0UDg->moHiCVeO1lG();
                goto c2PXV;
            case TSfaBZEUMcbl0::ABORTED:
                $k0UDg->mwraXPs7B5c();
                goto c2PXV;
        }
        goto DUEPf;
        GosUg:
        c2PXV:
        goto dzAdr;
        k5PGT:
        $k0UDg = PLi20pZSTTBHP::mLt8oIFAn3d($L5KaZ, $this->pXh9P, $this->Tfy0l, $this->t4e7r);
        goto dlV5M;
        dzAdr:
    }
    public function completePreSignedFile(string $L5KaZ, array $bQ_Iq)
    {
        goto M1_B0;
        M1_B0:
        $k0UDg = PLi20pZSTTBHP::mLt8oIFAn3d($L5KaZ, $this->pXh9P, $this->Tfy0l, $this->t4e7r);
        goto Aa2iK;
        Aa2iK:
        $k0UDg->mzbGvZW3SMF()->mJjlZb6LEdy($bQ_Iq);
        goto s0Y1Y;
        s0Y1Y:
        $k0UDg->mOpCwXOW98b();
        goto j9kJM;
        j9kJM:
        return ['path' => $k0UDg->getFile()->getView()['path'], 'thumbnail' => $k0UDg->getFile()->PVDri, 'id' => $L5KaZ];
        goto DzcIe;
        DzcIe:
    }
    public function updateFile(string $L5KaZ, int $E1cd2) : RV6vDyOPhxLM1
    {
        goto kzZLc;
        OIHxD:
        return $ZPsYd;
        goto a4hLj;
        Gcc7T:
        $ZPsYd->mvj3nnnI629($E1cd2);
        goto OIHxD;
        kzZLc:
        $ZPsYd = $this->MojYA->mVldyNQ2YMB($L5KaZ);
        goto Gcc7T;
        a4hLj:
    }
}
