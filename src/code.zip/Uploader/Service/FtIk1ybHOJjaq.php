<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use src\Uploader\Contracts\MGwfEiRGIYlUs;
use src\Uploader\Core\GoopVn9iYwlO0;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileDriver;
final class FtIk1ybHOJjaq implements MGwfEiRGIYlUs
{
    private $nr2GE;
    private $cBjL2;
    public $x2oZI;
    private $HBF4F;
    private $qiPaC;
    private $tGIcp;
    public function __construct($yNl5v, $SZYqg, $OEKSf, $IHRzz, $J5uW9, $UR4Dl)
    {
        goto gy30d;
        c9nu0:
        $this->cBjL2 = $SZYqg;
        goto WM31K;
        iSpMQ:
        $this->HBF4F = $IHRzz;
        goto goics;
        goics:
        $this->qiPaC = $J5uW9;
        goto omLq6;
        WM31K:
        $this->x2oZI = $OEKSf;
        goto iSpMQ;
        jK9mJ:
        $this->nr2GE = $yNl5v;
        goto c9nu0;
        gy30d:
        $this->tGIcp = $UR4Dl;
        goto jK9mJ;
        omLq6:
    }
    public function resolvePath($ymghJ, $PwWrM = FileDriver::S3) : string
    {
        goto TiVQM;
        tATTy:
        if (!(!empty($this->HBF4F) && !empty($this->qiPaC))) {
            goto i1bJQ;
        }
        goto YCd2Z;
        n1aBk:
        if (!$this->nr2GE) {
            goto VoAFr;
        }
        goto VYg_R;
        QUWcF:
        i1bJQ:
        goto n1aBk;
        YCd2Z:
        return $this->mRQ2i9NM4n7($ymghJ);
        goto QUWcF;
        ghY64:
        Luin6:
        goto tATTy;
        DFDZt:
        $ymghJ = $ymghJ->getAttribute('filename');
        goto So4Pk;
        PDCel:
        return route('home') . '/' . $ymghJ;
        goto ghY64;
        DBJ_6:
        if (!($PwWrM === FileDriver::LOCAL)) {
            goto Luin6;
        }
        goto PDCel;
        r3rcd:
        return trim($this->cBjL2, '/') . '/' . $ymghJ;
        goto pqqoB;
        TiVQM:
        if (!$ymghJ instanceof TvpGfrAj9WMXE) {
            goto vWfAs;
        }
        goto DFDZt;
        ER6xF:
        VoAFr:
        goto r3rcd;
        VYg_R:
        return trim($this->x2oZI, '/') . '/' . $ymghJ;
        goto ER6xF;
        So4Pk:
        vWfAs:
        goto DBJ_6;
        pqqoB:
    }
    public function resolveThumbnail(TvpGfrAj9WMXE $ymghJ) : string
    {
        goto qk5Bs;
        YtML4:
        NAts4:
        goto guaIB;
        guaIB:
        if (!$ymghJ instanceof GoopVn9iYwlO0) {
            goto uwnUw;
        }
        goto ck6Ce;
        ck6Ce:
        return asset('/img/pdf-preview.svg');
        goto W9F8p;
        ebDM4:
        return $this->resolvePath($CG9hE, $CG9hE->getAttribute('driver'));
        goto ywxs4;
        eyZGx:
        return $this->resolvePath($ymghJ, $ymghJ->getAttribute('driver'));
        goto YtML4;
        SuMSh:
        if (!$CG9hE) {
            goto a1TYx;
        }
        goto ebDM4;
        sXYhl:
        PfM3t:
        goto Z3Mg2;
        lgAFu:
        if (!$ymghJ->getAttribute('thumbnail_id')) {
            goto PfM3t;
        }
        goto jRdZn;
        c5isp:
        return $this->url($pIzqs, $ymghJ->getAttribute('driver'));
        goto T27el;
        OjhNQ:
        return '';
        goto NOOj3;
        Z3Mg2:
        if (!$ymghJ instanceof ID6EZw1DKfqu4) {
            goto NAts4;
        }
        goto eyZGx;
        T27el:
        Pqkfb:
        goto lgAFu;
        IVW6j:
        if (!$pIzqs) {
            goto Pqkfb;
        }
        goto c5isp;
        qk5Bs:
        $pIzqs = $ymghJ->VjYPs;
        goto IVW6j;
        W9F8p:
        uwnUw:
        goto OjhNQ;
        ywxs4:
        a1TYx:
        goto sXYhl;
        jRdZn:
        $CG9hE = ID6EZw1DKfqu4::find($ymghJ->getAttribute('thumbnail_id'));
        goto SuMSh;
        NOOj3:
    }
    private function url($fdqWg, $PwWrM)
    {
        goto nOiFm;
        b6Lt5:
        return $this->resolvePath($fdqWg);
        goto I2c_F;
        nOiFm:
        if (!($PwWrM == FileDriver::LOCAL)) {
            goto dt3HC;
        }
        goto jnBUY;
        jnBUY:
        return route('home') . '/' . $fdqWg;
        goto sboah;
        sboah:
        dt3HC:
        goto b6Lt5;
        I2c_F:
    }
    private function mRQ2i9NM4n7($fdqWg)
    {
        goto GG4SD;
        WbU73:
        nVHp3:
        goto rVeMV;
        AobdT:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto b6we6;
        LBFM3:
        $eIN5x = now()->addMinutes(60)->timestamp;
        goto EFNLh;
        EFNLh:
        $ffD9V = new UrlSigner($this->HBF4F, $this->tGIcp->path($this->qiPaC));
        goto t67wH;
        b6we6:
        PSk4E:
        goto LBFM3;
        GG4SD:
        if (!(strpos($fdqWg, 'https://') === 0)) {
            goto nVHp3;
        }
        goto Ti1zk;
        t67wH:
        return $ffD9V->getSignedUrl($this->x2oZI . '/' . $fdqWg, $eIN5x);
        goto z_t6X;
        rVeMV:
        if (!(strpos($fdqWg, 'm3u8') !== false)) {
            goto PSk4E;
        }
        goto AobdT;
        Ti1zk:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto WbU73;
        z_t6X:
    }
    public function resolvePathForHlsVideo(YdClVYDRbSDMR $iit8z, $W67xp = false) : string
    {
        goto zVTQ4;
        zVTQ4:
        if ($iit8z->Ei8zq) {
            goto ZmuqY;
        }
        goto LKgKb;
        LKgKb:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto clqVK;
        FA_mS:
        return $this->x2oZI . '/' . $iit8z->Ei8zq;
        goto NqTwM;
        clqVK:
        ZmuqY:
        goto FA_mS;
        NqTwM:
    }
    public function resolvePathForHlsVideos()
    {
        goto bC84d;
        oa8a3:
        $cSjsI = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto X0P3T;
        qjwz7:
        $uumAR = $this->x2oZI . '/v2/hls/';
        goto u7cp2;
        X0P3T:
        $uZgYf = $cSjsI->getSignedCookie(['key_pair_id' => $this->HBF4F, 'private_key' => $this->tGIcp->path($this->qiPaC), 'policy' => $GB6lA]);
        goto meH83;
        meH83:
        return [$uZgYf, $eIN5x];
        goto bVPNK;
        bC84d:
        $eIN5x = now()->addDays(3)->timestamp;
        goto qjwz7;
        u7cp2:
        $GB6lA = json_encode(['Statement' => [['Resource' => sprintf('%s*', $uumAR), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $eIN5x]]]]]);
        goto oa8a3;
        bVPNK:
    }
}
