<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
use Illuminate\Contracts\Filesystem\Filesystem;
final class KA9RxVwCbkfZQ
{
    private $n4bxV;
    private $GF0ML;
    private $FHcNr;
    public function __construct(string $dxOEL, string $E8mHB, Filesystem $z279S)
    {
        goto eIE3D;
        eIE3D:
        $this->n4bxV = $dxOEL;
        goto nP01_;
        sj_ii:
        $this->FHcNr = $z279S;
        goto WOsVA;
        nP01_:
        $this->GF0ML = $E8mHB;
        goto sj_ii;
        WOsVA:
    }
    public function miV8ZAF05zy(NCmZ7rMVMWyvC $ldT2t) : string
    {
        goto F27QG;
        wRcRS:
        return $this->FHcNr->url($ldT2t->getAttribute('filename'));
        goto c8vCq;
        jJV8O:
        EKKCT:
        goto wRcRS;
        DRQC5:
        return 's3://' . $this->n4bxV . '/' . $ldT2t->getAttribute('filename');
        goto jJV8O;
        F27QG:
        if (!(Pj539Ru5gyMbt::S3 == $ldT2t->getAttribute('driver'))) {
            goto EKKCT;
        }
        goto DRQC5;
        c8vCq:
    }
    public function m7A6Q5K6mHg(?string $uG0yw) : ?string
    {
        goto jE4xp;
        HsA2U:
        return null;
        goto uiBsS;
        jE4xp:
        if (!$uG0yw) {
            goto b7dCn;
        }
        goto HXBV8;
        HXBV8:
        if (!str_contains($uG0yw, $this->n4bxV)) {
            goto N_XBT;
        }
        goto g43zK;
        qZiJn:
        b7dCn:
        goto HsA2U;
        g43zK:
        $L5bJW = parse_url($uG0yw, PHP_URL_PATH);
        goto mvPF3;
        SfPsd:
        N_XBT:
        goto qZiJn;
        mvPF3:
        return 's3://' . $this->n4bxV . '/' . ltrim($L5bJW, '/');
        goto SfPsd;
        uiBsS:
    }
    public function mLFqrKiNQ5K(string $L5bJW) : string
    {
        return 's3://' . $this->n4bxV . '/' . $L5bJW;
    }
}
