<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
final class JrqDsqkHsYBsl
{
    private $HY2hW;
    private $CcrJO;
    private $OQTXf;
    public function __construct(string $bqJVe, string $ENSvT, Filesystem $eL8cO)
    {
        goto gB7sN;
        gB7sN:
        $this->HY2hW = $bqJVe;
        goto Aib0v;
        opyO4:
        $this->OQTXf = $eL8cO;
        goto vrSk1;
        Aib0v:
        $this->CcrJO = $ENSvT;
        goto opyO4;
        vrSk1:
    }
    public function mCbPnZv8YZ1(DYGJpbj9Ye8wY $bcJEK) : string
    {
        goto UEsXa;
        UEsXa:
        if (!(KPpxBU3Qc8yRk::S3 == $bcJEK->getAttribute('driver'))) {
            goto G0jKw;
        }
        goto J7UXh;
        ZV_cG:
        return $this->OQTXf->url($bcJEK->getAttribute('filename'));
        goto b8rvx;
        Iicfm:
        G0jKw:
        goto ZV_cG;
        J7UXh:
        return 's3://' . $this->HY2hW . '/' . $bcJEK->getAttribute('filename');
        goto Iicfm;
        b8rvx:
    }
    public function mGPyo7PQkAc(?string $HH5aT) : ?string
    {
        goto S_C9g;
        tFKJh:
        if (!Ox8w4($HH5aT, $this->HY2hW)) {
            goto zr7Ih;
        }
        goto T1i9B;
        kI19t:
        return 's3://' . $this->HY2hW . '/' . ltrim($eviRR, '/');
        goto d3RI_;
        S_C9g:
        if (!$HH5aT) {
            goto t1NSC;
        }
        goto tFKJh;
        T1i9B:
        $eviRR = parse_url($HH5aT, PHP_URL_PATH);
        goto kI19t;
        d3RI_:
        zr7Ih:
        goto i827u;
        i827u:
        t1NSC:
        goto aNk5F;
        aNk5F:
        return null;
        goto s0H2m;
        s0H2m:
    }
    public function mmWy415CetN(string $eviRR) : string
    {
        return 's3://' . $this->HY2hW . '/' . $eviRR;
    }
}
