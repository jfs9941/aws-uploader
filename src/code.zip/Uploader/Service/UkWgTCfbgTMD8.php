<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\DHtESYY0VyGQJ;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Core\Observer\Y6oPTyLuea0QN;
use Jfs\Uploader\Core\Observer\T1IY0RFpO9tB3;
use Jfs\Uploader\Core\OrjVhA5InRPZV;
use Jfs\Uploader\Core\XWPIITmssZr7Q;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Jfs\Uploader\Exception\B5gPy0GuqF3TT;
use Jfs\Uploader\Exception\L8JNHBuVqji1P;
use Jfs\Uploader\Service\FileResolver\TFEAmt0BEzaVn;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class UkWgTCfbgTMD8
{
    private $f6U8y;
    private $unMfk;
    private $rSfnv;
    public function __construct($kT3eN, $L32kE, $uIWH1)
    {
        goto NHt4Y;
        Jbc6W:
        $this->unMfk = $L32kE;
        goto sXwSA;
        sXwSA:
        $this->rSfnv = $uIWH1;
        goto p8_LM;
        NHt4Y:
        $this->f6U8y = $kT3eN;
        goto Jbc6W;
        p8_LM:
    }
    public function ms21D4wcb4q($jSk1X)
    {
        goto B23bQ;
        n0g0h:
        tvwHI:
        goto iskpH;
        B23bQ:
        if (!$jSk1X instanceof SingleUploadInterface) {
            goto tvwHI;
        }
        goto nXAIj;
        fXKzv:
        return $this->miyaEGxTA9X($CDlX4->extension(), PdN71mQX1JeZG::S3, null, $jSk1X->options());
        goto n0g0h;
        iskpH:
        return $this->miyaEGxTA9X($jSk1X['file_extension'], 's3' === $jSk1X['driver'] ? PdN71mQX1JeZG::S3 : PdN71mQX1JeZG::LOCAL);
        goto embwT;
        nXAIj:
        $CDlX4 = $jSk1X->getFile();
        goto fXKzv;
        embwT:
    }
    public function mUoy9MBUQK3(string $eeXS6)
    {
        goto znbTG;
        Gzbgu:
        return $qFMlx;
        goto mk5fJ;
        tIpmW:
        $qFMlx->exists = true;
        goto fpn3E;
        SjcDY:
        $qFMlx = $this->miyaEGxTA9X($DwGmR->getAttribute('type'), $DwGmR->getAttribute('driver'), $DwGmR->getAttribute('id'));
        goto tIpmW;
        fpn3E:
        $qFMlx->setRawAttributes($DwGmR->getAttributes());
        goto Gzbgu;
        znbTG:
        $DwGmR = config('upload.attachment_model')::findOrFail($eeXS6);
        goto SjcDY;
        mk5fJ:
    }
    public function mndT5zgzcel(string $QVfQS) : DHtESYY0VyGQJ
    {
        goto GdQBc;
        QTTml:
        if ($EY3QL) {
            goto ThwJs;
        }
        goto vfKVI;
        i_ahO:
        if (!$wEH2f) {
            goto esU29;
        }
        goto SFCo_;
        fvPGh:
        throw new B5gPy0GuqF3TT('metadata file not found');
        goto I9Hzg;
        SFCo_:
        $ws9h9 = XWPIITmssZr7Q::mzuRsecsHYw($wEH2f);
        goto cIe5U;
        XALDd:
        $wEH2f = json_decode($EY3QL, true);
        goto i_ahO;
        vfKVI:
        $EY3QL = $this->rSfnv->get($QVfQS);
        goto stIWZ;
        cIe5U:
        return $this->miyaEGxTA9X($ws9h9->WB5M9, $ws9h9->mIn7Gc5C2IC(), $ws9h9->filename);
        goto dREXf;
        stIWZ:
        ThwJs:
        goto XALDd;
        GdQBc:
        $EY3QL = $this->unMfk->get($QVfQS);
        goto QTTml;
        dREXf:
        esU29:
        goto fvPGh;
        I9Hzg:
    }
    private function miyaEGxTA9X(string $suRrh, $XjxJT, ?string $eeXS6 = null, array $H3592 = [])
    {
        goto b4CHS;
        yg3v4:
        pfooN:
        goto OGdMy;
        GaMEI:
        throw new L8JNHBuVqji1P("not support file type {$suRrh}");
        goto eHH1f;
        b4CHS:
        $eeXS6 = $eeXS6 ?? Uuid::uuid4()->getHex()->toString();
        goto RDObO;
        LKxN0:
        $WKPAl->mPs1JYkvGIi(new T1IY0RFpO9tB3($WKPAl, $this->rSfnv, $H3592));
        goto VMhrz;
        VMhrz:
        foreach ($this->f6U8y as $XpJJ6) {
            goto XX58T;
            Va3v2:
            ek1wK:
            goto jRwVf;
            mQZko:
            Jaewy:
            goto Va3v2;
            pRRUw:
            return $WKPAl->initLocation($XpJJ6->myWCMqTuyS6($WKPAl));
            goto mQZko;
            XX58T:
            if (!$XpJJ6->mDM8kPRDVd2($WKPAl)) {
                goto Jaewy;
            }
            goto pRRUw;
            jRwVf:
        }
        goto b_E1n;
        RDObO:
        switch ($suRrh) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $WKPAl = UG34Yjmf7IsbQ::createFromScratch($eeXS6, $suRrh);
                goto RF_0Q;
            case 'mp4':
            case 'mov':
                $WKPAl = N1wF7eNF4lYgo::createFromScratch($eeXS6, $suRrh);
                goto RF_0Q;
            case 'pdf':
                $WKPAl = OrjVhA5InRPZV::createFromScratch($eeXS6, $suRrh);
                goto RF_0Q;
            default:
                throw new L8JNHBuVqji1P("not support file type {$suRrh}");
        }
        goto yg3v4;
        b_E1n:
        Vera6:
        goto GaMEI;
        OGdMy:
        RF_0Q:
        goto OBAdv;
        VNPeJ:
        $WKPAl->mPs1JYkvGIi(new Y6oPTyLuea0QN($WKPAl));
        goto LKxN0;
        OBAdv:
        $WKPAl = $WKPAl->mJT12vZI3KE($XjxJT);
        goto VNPeJ;
        eHH1f:
    }
}
