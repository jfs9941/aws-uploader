<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\GN9q1LiHnFGKa;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Core\QWYHsUCm1wCVE;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
final class P4kAqVwxHUI1r implements GN9q1LiHnFGKa
{
    private $VsoZV;
    private $l5rCB;
    public $jp8fm;
    private $M2SBw;
    private $OLmyd;
    private $svYhv;
    public function __construct($l49Da, $PsrKJ, $t9oOc, $KT1nC, $SJVJt, $uLgU3)
    {
        goto IPtlG;
        HM1N8:
        $this->OLmyd = $SJVJt;
        goto aVOI_;
        hbAFx:
        $this->l5rCB = $PsrKJ;
        goto YjUWU;
        YjUWU:
        $this->jp8fm = $t9oOc;
        goto TuF_M;
        lApOi:
        $this->VsoZV = $l49Da;
        goto hbAFx;
        IPtlG:
        $this->svYhv = $uLgU3;
        goto lApOi;
        TuF_M:
        $this->M2SBw = $KT1nC;
        goto HM1N8;
        aVOI_:
    }
    public function resolvePath($PK0_J, $WpjdV = TpPQGsuK0gyw2::S3) : string
    {
        goto AtJb9;
        bcYPM:
        if (!($WpjdV === TpPQGsuK0gyw2::LOCAL)) {
            goto LAPLe;
        }
        goto bkmCc;
        AtJb9:
        if (!$PK0_J instanceof UXdXfw71iQGkx) {
            goto I957K;
        }
        goto G0Vr9;
        VataX:
        return $this->mZSzjcwgRy1($PK0_J);
        goto GryTZ;
        GryTZ:
        VTsq9:
        goto CrXx4;
        rDJ3T:
        qXOsZ:
        goto HwqtO;
        Zj32f:
        return trim($this->jp8fm, '/') . '/' . $PK0_J;
        goto rDJ3T;
        JKyuv:
        if (!(!empty($this->M2SBw) && !empty($this->OLmyd))) {
            goto VTsq9;
        }
        goto VataX;
        YnKF2:
        LAPLe:
        goto JKyuv;
        QA3qD:
        I957K:
        goto bcYPM;
        CrXx4:
        if (!$this->VsoZV) {
            goto qXOsZ;
        }
        goto Zj32f;
        G0Vr9:
        $PK0_J = $PK0_J->getAttribute('filename');
        goto QA3qD;
        bkmCc:
        return config('upload.home') . '/' . $PK0_J;
        goto YnKF2;
        HwqtO:
        return trim($this->l5rCB, '/') . '/' . $PK0_J;
        goto RBcrM;
        RBcrM:
    }
    public function resolveThumbnail(UXdXfw71iQGkx $PK0_J) : string
    {
        goto mUH5l;
        LrkWS:
        return $this->url($weLf2, $PK0_J->getAttribute('driver'));
        goto vRCHC;
        Tk_R0:
        if (!$PK0_J->getAttribute('thumbnail_id')) {
            goto DGc8N;
        }
        goto PDwfx;
        BG1tc:
        if (!$tYQb9) {
            goto oEzZI;
        }
        goto QAtVu;
        gmIZl:
        DGc8N:
        goto HO3GB;
        thoXJ:
        if (!$PK0_J instanceof QWYHsUCm1wCVE) {
            goto dr8Di;
        }
        goto bugXU;
        mUH5l:
        $weLf2 = $PK0_J->getAttribute('thumbnail');
        goto WyyWd;
        rTbIO:
        return '';
        goto PyREX;
        bugXU:
        return asset('/img/pdf-preview.svg');
        goto D__44;
        QAtVu:
        return $this->resolvePath($tYQb9, $tYQb9->getAttribute('driver'));
        goto a5PZ2;
        D__44:
        dr8Di:
        goto rTbIO;
        HO3GB:
        if (!$PK0_J instanceof Vt3ybt0yfaPAa) {
            goto FIy6B;
        }
        goto RHDJw;
        PDwfx:
        $tYQb9 = Vt3ybt0yfaPAa::find($PK0_J->getAttribute('thumbnail_id'));
        goto BG1tc;
        a5PZ2:
        oEzZI:
        goto gmIZl;
        tEw3F:
        FIy6B:
        goto thoXJ;
        RHDJw:
        return $this->resolvePath($PK0_J, $PK0_J->getAttribute('driver'));
        goto tEw3F;
        WyyWd:
        if (!$weLf2) {
            goto Kx4mw;
        }
        goto LrkWS;
        vRCHC:
        Kx4mw:
        goto Tk_R0;
        PyREX:
    }
    private function url($lPyJj, $WpjdV)
    {
        goto RSmbm;
        YrGUt:
        return config('upload.home') . '/' . $lPyJj;
        goto qyrka;
        wdZOd:
        return $this->resolvePath($lPyJj);
        goto WUQAQ;
        RSmbm:
        if (!($WpjdV == TpPQGsuK0gyw2::LOCAL)) {
            goto FY9eQ;
        }
        goto YrGUt;
        qyrka:
        FY9eQ:
        goto wdZOd;
        WUQAQ:
    }
    private function mZSzjcwgRy1($lPyJj)
    {
        goto BDfdZ;
        CiiGC:
        return $a0Dro->getSignedUrl($this->jp8fm . '/' . $lPyJj, $Eo2u3);
        goto sN_01;
        xBCaZ:
        if (!(strpos($lPyJj, 'm3u8') !== false)) {
            goto wNjzr;
        }
        goto Sp8Gk;
        NHKOU:
        $a0Dro = new UrlSigner($this->M2SBw, $this->svYhv->path($this->OLmyd));
        goto CiiGC;
        BDfdZ:
        if (!(strpos($lPyJj, 'https://') === 0)) {
            goto WwaO7;
        }
        goto AVNfR;
        AVNfR:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto yWx_I;
        yWx_I:
        WwaO7:
        goto xBCaZ;
        Sp8Gk:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto YY4cZ;
        YY4cZ:
        wNjzr:
        goto iURi_;
        iURi_:
        $Eo2u3 = now()->addMinutes(60)->timestamp;
        goto NHKOU;
        sN_01:
    }
    public function resolvePathForHlsVideo(D6fOq8lm3n7T2 $uA7Bz, $tDsiv = false) : string
    {
        goto AfuYg;
        AfuYg:
        if ($uA7Bz->getAttribute('hls_path')) {
            goto Aa6C5;
        }
        goto FhqTn;
        kxyD5:
        return $this->jp8fm . '/' . $uA7Bz->getAttribute('hls_path');
        goto Kzt7k;
        FhqTn:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Wg6hE;
        Wg6hE:
        Aa6C5:
        goto kxyD5;
        Kzt7k:
    }
    public function resolvePathForHlsVideos()
    {
        goto SSVK7;
        SSVK7:
        $Eo2u3 = now()->addDays(3)->timestamp;
        goto q5CAc;
        uAfS8:
        $DmodS = json_encode(['Statement' => [['Resource' => sprintf('%s*', $Bni8x), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $Eo2u3]]]]]);
        goto bO7Yl;
        bO7Yl:
        $XZNYf = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto nP16g;
        gypRp:
        return [$YoBR0, $Eo2u3];
        goto B3VQS;
        nP16g:
        $YoBR0 = $XZNYf->getSignedCookie(['key_pair_id' => $this->M2SBw, 'private_key' => $this->svYhv->path($this->OLmyd), 'policy' => $DmodS]);
        goto gypRp;
        q5CAc:
        $Bni8x = $this->jp8fm . '/v2/hls/';
        goto uAfS8;
        B3VQS:
    }
}
