<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\RwOJkCXwa9RQz;
final class QvYupJP8OKMno implements VideoPostHandleServiceInterface
{
    private $CU0n7;
    private $W_Kti;
    public function __construct(UploadServiceInterface $JFh3o, Filesystem $agzKA)
    {
        $this->CU0n7 = $JFh3o;
        $this->W_Kti = $agzKA;
    }
    public function saveMetadata(string $y06DH, array $Ds24j)
    {
        goto XiPG6;
        HqK7Q:
        e0bm4:
        goto a4koO;
        bJhkD:
        if (!isset($Ds24j['fps'])) {
            goto f3b1P;
        }
        goto s9MYp;
        H_MFl:
        unset($edrnW['thumbnail']);
        goto HqK7Q;
        jYmrK:
        if (!isset($Ds24j['resolution'])) {
            goto JoP3O;
        }
        goto PH5qx;
        di_jY:
        try {
            goto LkG83;
            LkG83:
            $qqIkT = $this->CU0n7->storeSingleFile(new class($Ds24j['thumbnail']) implements SingleUploadInterface
            {
                private $cyroT;
                public function __construct($a3XOL)
                {
                    $this->cyroT = $a3XOL;
                }
                public function getFile()
                {
                    return $this->cyroT;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto NAxmv;
            k9t27:
            $edrnW['thumbnail'] = $qqIkT['filename'];
            goto ApCYx;
            NAxmv:
            $edrnW['thumbnail_id'] = $qqIkT['id'];
            goto k9t27;
            ApCYx:
        } catch (\Throwable $ZkRqE) {
            Log::warning("GXtnGiMmIPEIc thumbnail store failed: " . $ZkRqE->getMessage());
        }
        goto RDgP_;
        XiPG6:
        $aiCaH = GXtnGiMmIPEIc::findOrFail($y06DH);
        goto rk1R7;
        s9MYp:
        $edrnW['fps'] = $Ds24j['fps'];
        goto jrw1D;
        RDgP_:
        q68qq:
        goto xbIJM;
        r2P0N:
        return $aiCaH->getView();
        goto FEjeS;
        wEEpa:
        throw new \Exception("GXtnGiMmIPEIc metadata store failed for unknown reason ... " . $y06DH);
        goto ytYcn;
        wSiFe:
        if (!isset($Ds24j['thumbnail'])) {
            goto q68qq;
        }
        goto di_jY;
        jrw1D:
        f3b1P:
        goto yM5X4;
        fufz5:
        if (!(isset($Ds24j['change_status']) && $Ds24j['change_status'])) {
            goto K8R6t;
        }
        goto fvp27;
        AJmmF:
        Log::warning("GXtnGiMmIPEIc metadata store failed for unknown reason ... " . $y06DH);
        goto wEEpa;
        qFLJw:
        JoP3O:
        goto bJhkD;
        PH5qx:
        $edrnW['resolution'] = $Ds24j['resolution'];
        goto qFLJw;
        KGjWJ:
        NrNlF:
        goto jYmrK;
        kxXMx:
        K8R6t:
        goto r2P0N;
        xbIJM:
        if (!isset($Ds24j['duration'])) {
            goto NrNlF;
        }
        goto c32NU;
        rk1R7:
        $edrnW = [];
        goto wSiFe;
        a4koO:
        if (!$aiCaH->update($edrnW)) {
            goto e14Mr;
        }
        goto fufz5;
        yM5X4:
        if (!$aiCaH->CKPey) {
            goto e0bm4;
        }
        goto H_MFl;
        FEjeS:
        e14Mr:
        goto AJmmF;
        c32NU:
        $edrnW['duration'] = $Ds24j['duration'];
        goto KGjWJ;
        fvp27:
        $this->CU0n7->updateFile($aiCaH->getAttribute('id'), RwOJkCXwa9RQz::PROCESSING);
        goto kxXMx;
        ytYcn:
    }
    public function createThumbnail(string $OSPuD) : void
    {
        goto f4H8K;
        RmgJV:
        $D8etQ = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto Au81q;
        Au81q:
        try {
            goto MuQ_J;
            INE01:
            $D8etQ->sendMessage(['QueueUrl' => $pu1Pe, 'MessageBody' => json_encode(['file_path' => $aiCaH->getLocation()])]);
            goto gbmmU;
            TJIYj:
            $pu1Pe = $RGqxu->get('QueueUrl');
            goto INE01;
            MuQ_J:
            $RGqxu = $D8etQ->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto TJIYj;
            gbmmU:
        } catch (\Throwable $rq1wj) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$rq1wj->getMessage()}");
        }
        goto GDbsK;
        f4H8K:
        Log::info("Use Lambda to generate thumbnail for video: " . $OSPuD);
        goto SjS1v;
        MIC29:
        if (!(!$this->W_Kti->directoryExists($WE_A0) && empty($aiCaH->mvgKPBGbzn9()))) {
            goto BmC8R;
        }
        goto RmgJV;
        GDbsK:
        BmC8R:
        goto gTkMY;
        z3m1C:
        $WE_A0 = "v2/hls/thumbnails/{$OSPuD}/";
        goto MIC29;
        SjS1v:
        $aiCaH = GXtnGiMmIPEIc::findOrFail($OSPuD);
        goto z3m1C;
        gTkMY:
    }
    public function mI0Ek62yXGR(string $OSPuD) : void
    {
        goto jSODn;
        LSMuY:
        $WE_A0 = "v2/hls/thumbnails/{$OSPuD}/";
        goto KZOrJ;
        KZOrJ:
        if ($this->W_Kti->directoryExists($WE_A0)) {
            goto YJcmD;
        }
        goto KulFd;
        H1xnO:
        YJcmD:
        goto yqb6n;
        yqb6n:
        $NwKya = $this->W_Kti->files($WE_A0);
        goto BwSaf;
        D3DIe:
        G1kh0:
        goto gDP_4;
        jSODn:
        $aiCaH = GXtnGiMmIPEIc::findOrFail($OSPuD);
        goto LSMuY;
        A6ycK:
        Log::error("Message back with success data but not found thumbnail files " . $OSPuD);
        goto naIgu;
        naIgu:
        throw new \Exception("Message back with success data but not found thumbnail files " . $OSPuD);
        goto D3DIe;
        KulFd:
        Log::error("Message back with success data but not found thumbnail " . $OSPuD);
        goto UmYcd;
        BwSaf:
        if (!(count($NwKya) === 0)) {
            goto G1kh0;
        }
        goto A6ycK;
        UmYcd:
        throw new \Exception("Message back with success data but not found thumbnail " . $OSPuD);
        goto H1xnO;
        gDP_4:
        $aiCaH->update(['generated_previews' => $WE_A0]);
        goto OjnPy;
        OjnPy:
    }
    public function getThumbnails(string $OSPuD) : array
    {
        $aiCaH = GXtnGiMmIPEIc::findOrFail($OSPuD);
        return $aiCaH->getThumbnails();
    }
}
