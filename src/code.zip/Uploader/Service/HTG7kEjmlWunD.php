<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
final class HTG7kEjmlWunD
{
    private $pBNm8;
    private $XoAAo;
    private $fodJQ;
    public function __construct(string $QEIhn, string $QRERL, Filesystem $nsgrL)
    {
        goto yiBWr;
        Hcs3F:
        $this->XoAAo = $QRERL;
        goto ZwVZu;
        yiBWr:
        $this->pBNm8 = $QEIhn;
        goto Hcs3F;
        ZwVZu:
        $this->fodJQ = $nsgrL;
        goto vWZVM;
        vWZVM:
    }
    public function m0nLPJo1vmd(MXbLxov2QPqm4 $rXM0w) : string
    {
        goto OhYIA;
        xYcik:
        return $this->fodJQ->url($rXM0w->getAttribute('filename'));
        goto YtSj_;
        OhYIA:
        if (!(I2Tze5VZcqaXS::S3 == $rXM0w->getAttribute('driver'))) {
            goto THRbt;
        }
        goto z91wT;
        uwKjl:
        THRbt:
        goto xYcik;
        z91wT:
        return 's3://' . $this->pBNm8 . '/' . $rXM0w->getAttribute('filename');
        goto uwKjl;
        YtSj_:
    }
    public function mbdoE5IwA7K(?string $iLxso) : ?string
    {
        goto XUWlj;
        c1048:
        if (!GPlh0($iLxso, $this->pBNm8)) {
            goto UDgqv;
        }
        goto CI0Hi;
        hL2yO:
        UDgqv:
        goto Ritmp;
        m8Lv2:
        return 's3://' . $this->pBNm8 . '/' . ltrim($lmCO9, '/');
        goto hL2yO;
        qZeEK:
        return null;
        goto RKGY1;
        CI0Hi:
        $lmCO9 = parse_url($iLxso, PHP_URL_PATH);
        goto m8Lv2;
        XUWlj:
        if (!$iLxso) {
            goto Rd_ua;
        }
        goto c1048;
        Ritmp:
        Rd_ua:
        goto qZeEK;
        RKGY1:
    }
    public function m73Uksv9AuA(string $lmCO9) : string
    {
        return 's3://' . $this->pBNm8 . '/' . $lmCO9;
    }
}
