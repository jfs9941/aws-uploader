<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Uploader\Service;

use Aws\Sqs\SqsClient;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileStatus;
final class DVTM10SQ2B4z3 implements VideoPostHandleServiceInterface
{
    private $ELJQ0;
    private $Aj6QZ;
    public function __construct(UploadServiceInterface $NMt5g, Filesystem $SaekO)
    {
        $this->ELJQ0 = $NMt5g;
        $this->Aj6QZ = $SaekO;
    }
    public function saveMetadata(string $BFPg9, array $rEWu2)
    {
        goto m5hZS;
        Nlwvn:
        if (!isset($rEWu2['fps'])) {
            goto OB22z;
        }
        goto Bc3OH;
        J3YRg:
        if (!isset($rEWu2['duration'])) {
            goto eoBMZ;
        }
        goto YS17W;
        Bc3OH:
        $knqaT['fps'] = $rEWu2['fps'];
        goto Zakzc;
        nTq4u:
        $knqaT = [];
        goto AJW0f;
        LruXh:
        try {
            goto BWxjv;
            HV8WP:
            $knqaT['thumbnail'] = $pIzqs['filename'];
            goto h4OwW;
            BWxjv:
            $pIzqs = $this->ELJQ0->storeSingleFile(new class($rEWu2['thumbnail']) implements SingleUploadInterface
            {
                private $dfQse;
                public function __construct($d1aiC)
                {
                    $this->dfQse = $d1aiC;
                }
                public function getFile()
                {
                    return $this->dfQse;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto O26j9;
            O26j9:
            $knqaT['thumbnail_id'] = $pIzqs['id'];
            goto HV8WP;
            h4OwW:
        } catch (\Throwable $lrm5K) {
            Log::warning("YdClVYDRbSDMR thumbnail store failed: " . $lrm5K->getMessage());
        }
        goto W8wFv;
        Zakzc:
        OB22z:
        goto Yjvbc;
        W8wFv:
        aOwJW:
        goto J3YRg;
        YS17W:
        $knqaT['duration'] = $rEWu2['duration'];
        goto nEnL5;
        GwuFc:
        throw new \Exception("YdClVYDRbSDMR metadata store failed for unknown reason ... " . $BFPg9);
        goto VLYgY;
        XpPQX:
        v93Xh:
        goto pxFtJ;
        Zhw6b:
        $this->ELJQ0->updateFile($iit8z->getAttribute('id'), FileStatus::PROCESSING);
        goto uYJjf;
        pxFtJ:
        Log::warning("YdClVYDRbSDMR metadata store failed for unknown reason ... " . $BFPg9);
        goto GwuFc;
        uYJjf:
        EALnG:
        goto go9Qe;
        M1qZu:
        ZxbPw:
        goto Nlwvn;
        rmylK:
        if (!isset($rEWu2['resolution'])) {
            goto ZxbPw;
        }
        goto dt7b9;
        go9Qe:
        return $iit8z->getView();
        goto XpPQX;
        AJW0f:
        if (!isset($rEWu2['thumbnail'])) {
            goto aOwJW;
        }
        goto LruXh;
        m5hZS:
        $iit8z = YdClVYDRbSDMR::findOrFail($BFPg9);
        goto nTq4u;
        nEnL5:
        eoBMZ:
        goto rmylK;
        dt7b9:
        $knqaT['resolution'] = $rEWu2['resolution'];
        goto M1qZu;
        h2kCX:
        if (!(isset($rEWu2['change_status']) && $rEWu2['change_status'])) {
            goto EALnG;
        }
        goto Zhw6b;
        Yjvbc:
        if (!$iit8z->update($knqaT)) {
            goto v93Xh;
        }
        goto h2kCX;
        VLYgY:
    }
    public function createThumbnail(string $CyoXz) : void
    {
        goto ZcZty;
        iIDV1:
        $OJMPz = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto dxT07;
        ywYe1:
        DT8yY:
        goto Wq291;
        lJy1v:
        if (!(!$this->Aj6QZ->directoryExists($dKCXk) && empty($iit8z->mb79LXbe2H3()))) {
            goto DT8yY;
        }
        goto iIDV1;
        ZcZty:
        Log::info("Use Lambda to generate thumbnail for video: " . $CyoXz);
        goto jFYtI;
        dxT07:
        try {
            goto Km2U8;
            Km2U8:
            $tsZbU = $OJMPz->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto Fbq9N;
            W7gyJ:
            $OJMPz->sendMessage(['QueueUrl' => $PuIYl, 'MessageBody' => json_encode(['file_path' => $iit8z->getLocation()])]);
            goto XuSB8;
            Fbq9N:
            $PuIYl = $tsZbU->get('QueueUrl');
            goto W7gyJ;
            XuSB8:
        } catch (\Throwable $X1eT0) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$X1eT0->getMessage()}");
        }
        goto ywYe1;
        jFYtI:
        $iit8z = YdClVYDRbSDMR::findOrFail($CyoXz);
        goto OSB8C;
        OSB8C:
        $dKCXk = "v2/hls/thumbnails/{$CyoXz}/";
        goto lJy1v;
        Wq291:
    }
    public function m1CC1so59MS(string $CyoXz) : void
    {
        goto vEu21;
        z3S6K:
        if ($this->Aj6QZ->directoryExists($dKCXk)) {
            goto N05_x;
        }
        goto wmLEQ;
        wmLEQ:
        Log::error("Message back with success data but not found thumbnail " . $CyoXz);
        goto jVmmH;
        jVmmH:
        throw new \Exception("Message back with success data but not found thumbnail " . $CyoXz);
        goto v0yYy;
        Ywet0:
        $dKCXk = "v2/hls/thumbnails/{$CyoXz}/";
        goto z3S6K;
        i0dWo:
        $CaSyV = $this->Aj6QZ->files($dKCXk);
        goto PKtWX;
        PKtWX:
        if (!(count($CaSyV) === 0)) {
            goto J7Hnn;
        }
        goto Cb5Cg;
        C29tk:
        throw new \Exception("Message back with success data but not found thumbnail files " . $CyoXz);
        goto a2yZQ;
        a2yZQ:
        J7Hnn:
        goto ZFalY;
        v0yYy:
        N05_x:
        goto i0dWo;
        ZFalY:
        $iit8z->update(['generated_previews' => $dKCXk]);
        goto CZwAX;
        Cb5Cg:
        Log::error("Message back with success data but not found thumbnail files " . $CyoXz);
        goto C29tk;
        vEu21:
        $iit8z = YdClVYDRbSDMR::findOrFail($CyoXz);
        goto Ywet0;
        CZwAX:
    }
    public function getThumbnails(string $CyoXz) : array
    {
        $iit8z = YdClVYDRbSDMR::findOrFail($CyoXz);
        return $iit8z->getThumbnails();
    }
}
