<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\IKjdKLYqqHsDJ;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Core\ZwUpr8c0hc8qN;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
final class H38a3dsu2FMgf implements IKjdKLYqqHsDJ
{
    private $Tlvj5;
    private $Ofs2e;
    public $xZaaO;
    private $GVrK3;
    private $z9642;
    private $F8ilg;
    public function __construct($w0cRs, $hqq4e, $HNNdQ, $IUBDN, $Ic8oM, $Pkopf)
    {
        goto lG1zZ;
        NfISE:
        $this->Tlvj5 = $w0cRs;
        goto KQCjz;
        KQCjz:
        $this->Ofs2e = $hqq4e;
        goto eGSgV;
        BpXec:
        $this->z9642 = $Ic8oM;
        goto o6jUk;
        eGSgV:
        $this->xZaaO = $HNNdQ;
        goto i4pTI;
        i4pTI:
        $this->GVrK3 = $IUBDN;
        goto BpXec;
        lG1zZ:
        $this->F8ilg = $Pkopf;
        goto NfISE;
        o6jUk:
    }
    public function resolvePath($IH9NP, $ZVbDm = EzGWviwQDmAwI::S3) : string
    {
        goto dwnAt;
        WIfIc:
        if (!(!empty($this->GVrK3) && !empty($this->z9642))) {
            goto SCdvH;
        }
        goto B93rk;
        bFDcq:
        SCdvH:
        goto R98H5;
        dwnAt:
        if (!$IH9NP instanceof ALaATNTmuoFHt) {
            goto Ff7cB;
        }
        goto X_J4H;
        QEvYG:
        if (!($ZVbDm === EzGWviwQDmAwI::LOCAL)) {
            goto Z_XIc;
        }
        goto gtlcb;
        yq8SC:
        DBZY3:
        goto MdJZh;
        R98H5:
        if (!$this->Tlvj5) {
            goto DBZY3;
        }
        goto LOM7r;
        LOM7r:
        return trim($this->xZaaO, '/') . '/' . $IH9NP;
        goto yq8SC;
        gtlcb:
        return config('upload.home') . '/' . $IH9NP;
        goto mO_Qs;
        mQKFM:
        Ff7cB:
        goto QEvYG;
        B93rk:
        return $this->mXsf03eMbDb($IH9NP);
        goto bFDcq;
        MdJZh:
        return trim($this->Ofs2e, '/') . '/' . $IH9NP;
        goto AL8rO;
        mO_Qs:
        Z_XIc:
        goto WIfIc;
        X_J4H:
        $IH9NP = $IH9NP->getAttribute('filename');
        goto mQKFM;
        AL8rO:
    }
    public function resolveThumbnail(ALaATNTmuoFHt $IH9NP) : string
    {
        goto oOuDN;
        qiDlm:
        q5iMj:
        goto inJfP;
        ChPi3:
        $JI0pf = X9YHjKrAdcfhe::find($IH9NP->getAttribute('thumbnail_id'));
        goto UYmVo;
        B77dl:
        eknnF:
        goto S2o2z;
        BywZB:
        if (!$saBWi) {
            goto v18GF;
        }
        goto Lx1mG;
        UYmVo:
        if (!$JI0pf) {
            goto eknnF;
        }
        goto trCee;
        CyYp5:
        return '';
        goto j6LrM;
        V80y5:
        return $this->resolvePath($IH9NP, $IH9NP->getAttribute('driver'));
        goto qiDlm;
        L30U3:
        if (!$IH9NP->getAttribute('thumbnail_id')) {
            goto WDyDS;
        }
        goto ChPi3;
        oMWk2:
        k2xMZ:
        goto CyYp5;
        S2o2z:
        WDyDS:
        goto xHulX;
        b_qk3:
        v18GF:
        goto L30U3;
        oOuDN:
        $saBWi = $IH9NP->getAttribute('thumbnail');
        goto BywZB;
        Lx1mG:
        return $this->url($saBWi, $IH9NP->getAttribute('driver'));
        goto b_qk3;
        trCee:
        return $this->resolvePath($JI0pf, $JI0pf->getAttribute('driver'));
        goto B77dl;
        xHulX:
        if (!$IH9NP instanceof X9YHjKrAdcfhe) {
            goto q5iMj;
        }
        goto V80y5;
        zBTyI:
        return asset('/img/pdf-preview.svg');
        goto oMWk2;
        inJfP:
        if (!$IH9NP instanceof ZwUpr8c0hc8qN) {
            goto k2xMZ;
        }
        goto zBTyI;
        j6LrM:
    }
    private function url($AvgzF, $ZVbDm)
    {
        goto YTZlF;
        lsShM:
        return config('upload.home') . '/' . $AvgzF;
        goto JDZhy;
        h8h5l:
        return $this->resolvePath($AvgzF);
        goto XGJwS;
        YTZlF:
        if (!($ZVbDm == EzGWviwQDmAwI::LOCAL)) {
            goto tIlkV;
        }
        goto lsShM;
        JDZhy:
        tIlkV:
        goto h8h5l;
        XGJwS:
    }
    private function mXsf03eMbDb($AvgzF)
    {
        goto vZHQb;
        ynCvT:
        return $enviR->getSignedUrl($this->xZaaO . '/' . $AvgzF, $f2H6T);
        goto CEI51;
        BaPnA:
        $f2H6T = now()->addMinutes(60)->timestamp;
        goto KOCJg;
        DxXp2:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto MCpyx;
        vZHQb:
        if (!(strpos($AvgzF, 'https://') === 0)) {
            goto Sa2iD;
        }
        goto MAy70;
        MAy70:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto F7tIf;
        D6XXN:
        if (!(strpos($AvgzF, 'm3u8') !== false)) {
            goto oux7v;
        }
        goto DxXp2;
        MCpyx:
        oux7v:
        goto BaPnA;
        F7tIf:
        Sa2iD:
        goto D6XXN;
        KOCJg:
        $enviR = new UrlSigner($this->GVrK3, $this->F8ilg->path($this->z9642));
        goto ynCvT;
        CEI51:
    }
    public function resolvePathForHlsVideo(Jf5KRr8uE3t34 $Qw86m, $cOKx2 = false) : string
    {
        goto rngdj;
        GhH8q:
        return $this->xZaaO . '/' . $Qw86m->getAttribute('hls_path');
        goto gdpCT;
        rngdj:
        if ($Qw86m->getAttribute('hls_path')) {
            goto gTe7v;
        }
        goto SRQ7_;
        ikWZk:
        gTe7v:
        goto GhH8q;
        SRQ7_:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto ikWZk;
        gdpCT:
    }
    public function resolvePathForHlsVideos()
    {
        goto H5s13;
        yfTBd:
        $QDa7x = json_encode(['Statement' => [['Resource' => sprintf('%s*', $KtPIb), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $f2H6T]]]]]);
        goto i9j1y;
        INL46:
        $mid4E = $iP0Sl->getSignedCookie(['key_pair_id' => $this->GVrK3, 'private_key' => $this->F8ilg->path($this->z9642), 'policy' => $QDa7x]);
        goto Ha3ht;
        Mw9F4:
        $KtPIb = $this->xZaaO . '/v2/hls/';
        goto yfTBd;
        i9j1y:
        $iP0Sl = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto INL46;
        Ha3ht:
        return [$mid4E, $f2H6T];
        goto MjUHQ;
        H5s13:
        $f2H6T = now()->addDays(3)->timestamp;
        goto Mw9F4;
        MjUHQ:
    }
}
