<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
final class PP4BnfgX7sVAN
{
    private $iqyyD;
    private $DfPU0;
    private $UBJ9G;
    public function __construct(string $TnK9g, string $vaqtH, Filesystem $e1L33)
    {
        goto bTfdC;
        aSNNP:
        $this->DfPU0 = $vaqtH;
        goto oq3uK;
        bTfdC:
        $this->iqyyD = $TnK9g;
        goto aSNNP;
        oq3uK:
        $this->UBJ9G = $e1L33;
        goto bdjcJ;
        bdjcJ:
    }
    public function msVX9GnHpGz(O4HsadxAyKjYq $NyN9S) : string
    {
        goto D0mU9;
        ppemr:
        csorp:
        goto nb4mu;
        iyzhU:
        return 's3://' . $this->iqyyD . '/' . $NyN9S->getAttribute('filename');
        goto ppemr;
        D0mU9:
        if (!(ZBLpZ2qUZ4P6C::S3 == $NyN9S->getAttribute('driver'))) {
            goto csorp;
        }
        goto iyzhU;
        nb4mu:
        return $this->UBJ9G->url($NyN9S->getAttribute('filename'));
        goto U933o;
        U933o:
    }
    public function ma7jkuHlWQB(?string $ui0MU) : ?string
    {
        goto qe0_F;
        FT7Rp:
        return 's3://' . $this->iqyyD . '/' . ltrim($jGQTt, '/');
        goto Y2AJ0;
        au6BB:
        $jGQTt = parse_url($ui0MU, PHP_URL_PATH);
        goto FT7Rp;
        t5H36:
        if (!oLfm9($ui0MU, $this->iqyyD)) {
            goto jJBtf;
        }
        goto au6BB;
        qe0_F:
        if (!$ui0MU) {
            goto gKwkN;
        }
        goto t5H36;
        iQn6A:
        return null;
        goto GvRI3;
        Y2AJ0:
        jJBtf:
        goto eMMFk;
        eMMFk:
        gKwkN:
        goto iQn6A;
        GvRI3:
    }
    public function mMoRkdSHlVz(string $jGQTt) : string
    {
        return 's3://' . $this->iqyyD . '/' . $jGQTt;
    }
}
