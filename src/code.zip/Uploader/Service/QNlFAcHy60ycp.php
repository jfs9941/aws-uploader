<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\Dm945121dFKVW;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Core\NfPkVduXHwQBz;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
final class QNlFAcHy60ycp implements Dm945121dFKVW
{
    private $If132;
    private $Ilzbu;
    public $WFBxs;
    private $vPlkt;
    private $IeM4A;
    private $dwubH;
    public function __construct($e2idc, $f21W4, $J2Nbm, $RVkpf, $Q_BCI, $VzPPJ)
    {
        goto zZeG1;
        GkB8N:
        $this->If132 = $e2idc;
        goto kIUSb;
        zZeG1:
        $this->dwubH = $VzPPJ;
        goto GkB8N;
        NhuzF:
        $this->vPlkt = $RVkpf;
        goto OHc0w;
        l_BJ2:
        $this->WFBxs = $J2Nbm;
        goto NhuzF;
        OHc0w:
        $this->IeM4A = $Q_BCI;
        goto YjlpL;
        kIUSb:
        $this->Ilzbu = $f21W4;
        goto l_BJ2;
        YjlpL:
    }
    public function resolvePath($uTqKK, $Rmh9e = J0IuL8wroLOWt::S3) : string
    {
        goto bBc_D;
        bBc_D:
        if (!$uTqKK instanceof Zl4rdW32ufaUx) {
            goto swhke;
        }
        goto hzk_g;
        tPE4e:
        swhke:
        goto X16Hh;
        kqokR:
        if (!(!empty($this->vPlkt) && !empty($this->IeM4A))) {
            goto agc5z;
        }
        goto VdG13;
        VdG13:
        return $this->msHCwO7qxvM($uTqKK);
        goto Fxpja;
        hzk_g:
        $uTqKK = $uTqKK->getAttribute('filename');
        goto tPE4e;
        X16Hh:
        if (!($Rmh9e === J0IuL8wroLOWt::LOCAL)) {
            goto gg2KZ;
        }
        goto fdnSW;
        lNNpT:
        CJGWG:
        goto WrpdW;
        fdnSW:
        return config('upload.home') . '/' . $uTqKK;
        goto x5sOq;
        yIQXE:
        return trim($this->WFBxs, '/') . '/' . $uTqKK;
        goto lNNpT;
        cR23J:
        if (!$this->If132) {
            goto CJGWG;
        }
        goto yIQXE;
        WrpdW:
        return trim($this->Ilzbu, '/') . '/' . $uTqKK;
        goto DCpv3;
        x5sOq:
        gg2KZ:
        goto kqokR;
        Fxpja:
        agc5z:
        goto cR23J;
        DCpv3:
    }
    public function resolveThumbnail(Zl4rdW32ufaUx $uTqKK) : string
    {
        goto a8Squ;
        M1Oth:
        $WUni0 = XMeo8SOmME8kj::find($uTqKK->getAttribute('thumbnail_id'));
        goto LHKeB;
        O4COo:
        if (!$uTqKK instanceof NfPkVduXHwQBz) {
            goto LHUrB;
        }
        goto x2bbf;
        x2bbf:
        return asset('/img/pdf-preview.svg');
        goto VWN92;
        cTVrT:
        return $this->resolvePath($WUni0, $WUni0->getAttribute('driver'));
        goto ObFkx;
        fFojC:
        wwDyc:
        goto Ut4H6;
        PWV00:
        if (!$uTqKK->getAttribute('thumbnail_id')) {
            goto wwDyc;
        }
        goto M1Oth;
        VWN92:
        LHUrB:
        goto ksK6l;
        NIehj:
        return $this->url($i7XwP, $uTqKK->getAttribute('driver'));
        goto WvR9u;
        ksK6l:
        return '';
        goto t0FmB;
        a8Squ:
        $i7XwP = $uTqKK->getAttribute('thumbnail');
        goto Oq7fV;
        Ut4H6:
        if (!$uTqKK instanceof XMeo8SOmME8kj) {
            goto Ex5bs;
        }
        goto x0FtI;
        LHKeB:
        if (!$WUni0) {
            goto U7VKb;
        }
        goto cTVrT;
        xQcd_:
        Ex5bs:
        goto O4COo;
        WvR9u:
        VUMex:
        goto PWV00;
        x0FtI:
        return $this->resolvePath($uTqKK, $uTqKK->getAttribute('driver'));
        goto xQcd_;
        Oq7fV:
        if (!$i7XwP) {
            goto VUMex;
        }
        goto NIehj;
        ObFkx:
        U7VKb:
        goto fFojC;
        t0FmB:
    }
    private function url($dTJxl, $Rmh9e)
    {
        goto rofJS;
        d2P26:
        c6uei:
        goto LZCsz;
        LZCsz:
        return $this->resolvePath($dTJxl);
        goto QV3SM;
        rofJS:
        if (!($Rmh9e == J0IuL8wroLOWt::LOCAL)) {
            goto c6uei;
        }
        goto Qkcjx;
        Qkcjx:
        return config('upload.home') . '/' . $dTJxl;
        goto d2P26;
        QV3SM:
    }
    private function msHCwO7qxvM($dTJxl)
    {
        goto oKhcr;
        n7aK8:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto I3W46;
        oKhcr:
        if (!(strpos($dTJxl, 'https://') === 0)) {
            goto guyGt;
        }
        goto n7aK8;
        YkY4O:
        return $eYbAM->getSignedUrl($this->WFBxs . '/' . $dTJxl, $beqfL);
        goto QKeo6;
        qcXmd:
        yXdCj:
        goto P_Ppe;
        J4NEl:
        if (!(strpos($dTJxl, 'm3u8') !== false)) {
            goto yXdCj;
        }
        goto s95cr;
        I3W46:
        guyGt:
        goto J4NEl;
        EZZ8B:
        $eYbAM = new UrlSigner($this->vPlkt, $this->dwubH->path($this->IeM4A));
        goto YkY4O;
        P_Ppe:
        $beqfL = now()->addMinutes(60)->timestamp;
        goto EZZ8B;
        s95cr:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto qcXmd;
        QKeo6:
    }
    public function resolvePathForHlsVideo(U9HMl0N8dP0ZH $QCHmE, $cuEie = false) : string
    {
        goto f6ITH;
        f6ITH:
        if ($QCHmE->getAttribute('hls_path')) {
            goto LRQPp;
        }
        goto Gi43r;
        As7Vo:
        LRQPp:
        goto DTsuM;
        Gi43r:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto As7Vo;
        DTsuM:
        return $this->WFBxs . '/' . $QCHmE->getAttribute('hls_path');
        goto g2zc2;
        g2zc2:
    }
    public function resolvePathForHlsVideos()
    {
        goto cztIp;
        sZ0eR:
        $avkoV = $this->WFBxs . '/v2/hls/';
        goto IAQfN;
        IAQfN:
        $QwxeI = json_encode(['Statement' => [['Resource' => sprintf('%s*', $avkoV), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $beqfL]]]]]);
        goto bS4rk;
        ZLWpi:
        return [$I27l2, $beqfL];
        goto UbYoD;
        bS4rk:
        $Tm97b = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto IH6DK;
        IH6DK:
        $I27l2 = $Tm97b->getSignedCookie(['key_pair_id' => $this->vPlkt, 'private_key' => $this->dwubH->path($this->IeM4A), 'policy' => $QwxeI]);
        goto ZLWpi;
        cztIp:
        $beqfL = now()->addDays(3)->timestamp;
        goto sZ0eR;
        UbYoD:
    }
}
