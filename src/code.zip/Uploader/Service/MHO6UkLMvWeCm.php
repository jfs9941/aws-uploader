<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Service; use Illuminate\Contracts\Filesystem\Filesystem; use Jfs\Uploader\Core\J5wym0qxH1hlR; use Jfs\Uploader\Enum\FileDriver; final class MHO6UkLMvWeCm { private $WavYc; private $VTuMt; private $SLWkL; public function __construct(string $b40i2, string $sgBxY, Filesystem $a8JFR) { goto WkkVW; sWTJO: $this->SLWkL = $a8JFR; goto ZDAcV; FgbjD: $this->VTuMt = $sgBxY; goto sWTJO; WkkVW: $this->WavYc = $b40i2; goto FgbjD; ZDAcV: } public function muhxnHbZJJF(J5wym0qxH1hlR $fihHa) : string { goto TK12f; gxooh: return $this->SLWkL->url($fihHa->getAttribute('filename')); goto vC8Gz; TK12f: if (!(FileDriver::S3 == $fihHa->getAttribute('driver'))) { goto zPVbZ; } goto vLlMe; vLlMe: return 's3://' . $this->WavYc . '/' . $fihHa->getAttribute('filename'); goto AHxf1; AHxf1: zPVbZ: goto gxooh; vC8Gz: } public function mgTJVwk8KYJ(?string $HCz77) : ?string { goto jcLYV; sr857: return null; goto vgr7U; EIi3r: UqWFq: goto IoD3a; ohz15: $lb3BP = parse_url($HCz77, PHP_URL_PATH); goto Bftwb; IoD3a: WYq3M: goto sr857; vEr7D: if (!YuREv($HCz77, $this->WavYc)) { goto UqWFq; } goto ohz15; jcLYV: if (!$HCz77) { goto WYq3M; } goto vEr7D; Bftwb: return 's3://' . $this->WavYc . '/' . ltrim($lb3BP, '/'); goto EIi3r; vgr7U: } public function mISCdNwM4Qe(string $lb3BP) : string { return 's3://' . $this->WavYc . '/' . $lb3BP; } }
