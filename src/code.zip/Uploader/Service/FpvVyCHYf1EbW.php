<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Illuminate\Contracts\Filesystem\Filesystem;
final class FpvVyCHYf1EbW
{
    private $xhfp2;
    private $Lt6YN;
    private $q6zCU;
    public function __construct(string $C1Y4p, string $ZeDX1, Filesystem $zDbHT)
    {
        goto zkFPX;
        V52nh:
        $this->Lt6YN = $ZeDX1;
        goto Wevu9;
        Wevu9:
        $this->q6zCU = $zDbHT;
        goto FKruf;
        zkFPX:
        $this->xhfp2 = $C1Y4p;
        goto V52nh;
        FKruf:
    }
    public function mIIXQtDH8Uh(AtQh9cRLX7xL8 $hckxR) : string
    {
        goto Q6o0N;
        BvZdn:
        return 's3://' . $this->xhfp2 . '/' . $hckxR->getAttribute('filename');
        goto KwTM2;
        Q6o0N:
        if (!(X4ZiOQdPeeHKI::S3 == $hckxR->getAttribute('driver'))) {
            goto sSFSF;
        }
        goto BvZdn;
        w1Q3N:
        return $this->q6zCU->url($hckxR->getAttribute('filename'));
        goto KCf7b;
        KwTM2:
        sSFSF:
        goto w1Q3N;
        KCf7b:
    }
    public function mswcXsXm4i0(?string $igIiY) : ?string
    {
        goto NCtnq;
        WY0Lq:
        return 's3://' . $this->xhfp2 . '/' . ltrim($lmTDq, '/');
        goto m7n96;
        d3xIF:
        $lmTDq = parse_url($igIiY, PHP_URL_PATH);
        goto WY0Lq;
        NCtnq:
        if (!$igIiY) {
            goto A4vfH;
        }
        goto uEdh3;
        m7n96:
        npyJE:
        goto nely3;
        nely3:
        A4vfH:
        goto adRz0;
        adRz0:
        return null;
        goto V2Pvo;
        uEdh3:
        if (!str_contains($igIiY, $this->xhfp2)) {
            goto npyJE;
        }
        goto d3xIF;
        V2Pvo:
    }
    public function m0rBCqDFu8S(string $lmTDq) : string
    {
        return 's3://' . $this->xhfp2 . '/' . $lmTDq;
    }
}
