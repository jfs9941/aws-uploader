<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\MEWwofwAYqgaI;
use Jfs\Uploader\Core\Q0JnJtyNI6T0p;
use Jfs\Uploader\Core\S3bwZBI8SlQQZ;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Jfs\Uploader\Exception\HF2PbTFQhW3Rr;
use Jfs\Uploader\Exception\EpflNcDLOJeck;
use Jfs\Uploader\Exception\ZEPVfMQDBdCIh;
use Jfs\Uploader\Service\JMS12XhOMqdv8;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Eb0cApEJe5wrS implements UploadServiceInterface
{
    private $DoHhE;
    private $hhcR1;
    private $GkraP;
    private $h0NR3;
    public function __construct(JMS12XhOMqdv8 $gDQkK, Filesystem $nQYui, Filesystem $jkGKh, string $Re2rf)
    {
        goto q4f_7;
        n5Ru3:
        $this->GkraP = $jkGKh;
        goto T0Q8o;
        q4f_7:
        $this->DoHhE = $gDQkK;
        goto o34_K;
        T0Q8o:
        $this->h0NR3 = $Re2rf;
        goto AFt8D;
        o34_K:
        $this->hhcR1 = $nQYui;
        goto n5Ru3;
        AFt8D:
    }
    public function storeSingleFile(SingleUploadInterface $GvWwj) : array
    {
        goto Z10ee;
        QnVLd:
        goto PBtZJ;
        goto uxcos;
        K0Qw7:
        if (false !== $uMpUA && $hFrf7 instanceof MEWwofwAYqgaI) {
            goto TD0_E;
        }
        goto Wllp8;
        wKuw1:
        $hFrf7->mvlhr18w6fy(FdWrko7bmoI4Y::UPLOADED);
        goto z4NW5;
        Z10ee:
        $hFrf7 = $this->DoHhE->mUTjgOHTDsT($GvWwj);
        goto NYAu3;
        z4NW5:
        PBtZJ:
        goto b15iP;
        NYAu3:
        $uMpUA = $this->GkraP->putFileAs(dirname($hFrf7->getLocation()), $GvWwj->getFile(), $hFrf7->getFilename() . '.' . $hFrf7->getExtension(), ['visibility' => 'public']);
        goto K0Qw7;
        uxcos:
        TD0_E:
        goto wKuw1;
        b15iP:
        return $hFrf7->getView();
        goto OqXzG;
        Wllp8:
        throw new \LogicException('File upload failed, check permissions');
        goto QnVLd;
        OqXzG:
    }
    public function storePreSignedFile(array $RJsYt)
    {
        goto GK2ZU;
        gHfpq:
        $GNrIm->mkAB4wFX7me();
        goto PEe05;
        iArEx:
        $GNrIm->mynhW1oCAAA($RJsYt['mime'], $RJsYt['file_size'], $RJsYt['chunk_size'], $RJsYt['checksums'], $RJsYt['user_id'], $RJsYt['driver']);
        goto gHfpq;
        PEe05:
        return ['filename' => $GNrIm->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $GNrIm->mG4DLei2D97()];
        goto JAzky;
        GK2ZU:
        $hFrf7 = $this->DoHhE->mUTjgOHTDsT($RJsYt);
        goto EQ5Y1;
        EQ5Y1:
        $GNrIm = S3bwZBI8SlQQZ::m9WH9Zbzrb2($hFrf7, $this->hhcR1, $this->GkraP, $this->h0NR3, true);
        goto iArEx;
        JAzky:
    }
    public function updatePreSignedFile(string $ufjUS, int $jO319)
    {
        goto l3jpD;
        XwVi0:
        nE6y1:
        goto jrYcr;
        dMmb4:
        v5TlK:
        goto XwVi0;
        wXKWi:
        switch ($jO319) {
            case FdWrko7bmoI4Y::UPLOADED:
                $GNrIm->mKgTkN0NdQK();
                goto nE6y1;
            case FdWrko7bmoI4Y::PROCESSING:
                $GNrIm->mpGmUw1FiUx();
                goto nE6y1;
            case FdWrko7bmoI4Y::FINISHED:
                $GNrIm->mIU23Rr1WEO();
                goto nE6y1;
            case FdWrko7bmoI4Y::ABORTED:
                $GNrIm->mVYs88Gfpix();
                goto nE6y1;
        }
        goto dMmb4;
        l3jpD:
        $GNrIm = S3bwZBI8SlQQZ::mZJaGcF41eX($ufjUS, $this->hhcR1, $this->GkraP, $this->h0NR3);
        goto wXKWi;
        jrYcr:
    }
    public function completePreSignedFile(string $ufjUS, array $DvSBV)
    {
        goto GpudH;
        GpudH:
        $GNrIm = S3bwZBI8SlQQZ::mZJaGcF41eX($ufjUS, $this->hhcR1, $this->GkraP, $this->h0NR3);
        goto sXjCR;
        TnSQS:
        $GNrIm->mKgTkN0NdQK();
        goto JvUd2;
        sXjCR:
        $GNrIm->mAorhKFxc5x()->m1j3l70ZkLu($DvSBV);
        goto TnSQS;
        JvUd2:
        return ['path' => $GNrIm->getFile()->getView()['path'], 'thumbnail' => $GNrIm->getFile()->B6Fhn, 'id' => $ufjUS];
        goto gkm1h;
        gkm1h:
    }
    public function updateFile(string $ufjUS, int $jO319) : Q0JnJtyNI6T0p
    {
        goto CyQZh;
        CyQZh:
        $hFrf7 = $this->DoHhE->m6gPzko8cqh($ufjUS);
        goto tkl2E;
        Hf2iA:
        return $hFrf7;
        goto upw1e;
        tkl2E:
        $hFrf7->mvlhr18w6fy($jO319);
        goto Hf2iA;
        upw1e:
    }
}
