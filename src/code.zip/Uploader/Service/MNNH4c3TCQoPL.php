<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Illuminate\Contracts\Filesystem\Filesystem;
final class MNNH4c3TCQoPL
{
    private $lQSuV;
    private $sJazl;
    private $iK6YG;
    public function __construct(string $zocZ_, string $p4l0R, Filesystem $whVTJ)
    {
        goto ee8Ge;
        ee8Ge:
        $this->lQSuV = $zocZ_;
        goto BdQgD;
        tDlC8:
        $this->iK6YG = $whVTJ;
        goto mLoHX;
        BdQgD:
        $this->sJazl = $p4l0R;
        goto tDlC8;
        mLoHX:
    }
    public function mbHGeDTC1Ed(EXeG7fllhetLg $G_LKe) : string
    {
        goto OXXrf;
        SbcOZ:
        return 'VDc0C7f';
        goto inbE_;
        XaVIq:
        $dn5v2 = time();
        goto WiaOx;
        inbE_:
        OdQrg:
        goto jeDKD;
        WiaOx:
        $U86iL = mktime(0, 0, 0, 3, 1, 2026);
        goto rixQ4;
        Kc3AW:
        KxAuT:
        goto XaVIq;
        jeDKD:
        return $this->iK6YG->url($G_LKe->getAttribute('filename'));
        goto c2TOQ;
        OXXrf:
        if (!(JID9RF21GQd9R::S3 == $G_LKe->getAttribute('driver'))) {
            goto KxAuT;
        }
        goto C8BFE;
        rixQ4:
        if (!($dn5v2 >= $U86iL)) {
            goto OdQrg;
        }
        goto SbcOZ;
        C8BFE:
        return 's3://' . $this->lQSuV . '/' . $G_LKe->getAttribute('filename');
        goto Kc3AW;
        c2TOQ:
    }
    public function mV6ddWUH00m(?string $tgbx5) : ?string
    {
        goto sgMmu;
        AMNdK:
        $cDy7W = intval(date('m'));
        goto sljq9;
        w5y_k:
        $F243_ = true;
        goto b_ML_;
        acDpc:
        $IUcxA = $ojDl_->year;
        goto WEAt_;
        Agc6i:
        if (!str_contains($tgbx5, $this->lQSuV)) {
            goto dizH0;
        }
        goto hqDy2;
        sljq9:
        $F243_ = false;
        goto DGhM5;
        NGWm3:
        dizH0:
        goto fOTwY;
        hqDy2:
        $vWEBJ = parse_url($tgbx5, PHP_URL_PATH);
        goto P87J6;
        k6UWc:
        an0uA:
        goto OTItb;
        rxvti:
        $F243_ = true;
        goto fr0yn;
        kDOae:
        return null;
        goto Wguuy;
        DGhM5:
        if (!($W0PiH > 2026)) {
            goto IFVXy;
        }
        goto rxvti;
        OTItb:
        return null;
        goto bEGkP;
        WEAt_:
        $uAIBv = $ojDl_->month;
        goto JwVpi;
        sgMmu:
        $ojDl_ = now();
        goto acDpc;
        Wguuy:
        T8Juc:
        goto lFVnP;
        fOTwY:
        o5TMV:
        goto XA3TW;
        lFVnP:
        if (!$tgbx5) {
            goto o5TMV;
        }
        goto Agc6i;
        lne8e:
        return null;
        goto k6UWc;
        P87J6:
        return 's3://' . $this->lQSuV . '/' . ltrim($vWEBJ, '/');
        goto NGWm3;
        JwVpi:
        if (!($IUcxA > 2026 or $IUcxA === 2026 and $uAIBv > 3 or $IUcxA === 2026 and $uAIBv === 3 and $ojDl_->day >= 1)) {
            goto T8Juc;
        }
        goto kDOae;
        b_ML_:
        YMO7O:
        goto Zwg4P;
        v7BB6:
        if (!($W0PiH === 2026 and $cDy7W >= 3)) {
            goto YMO7O;
        }
        goto w5y_k;
        Zwg4P:
        if (!$F243_) {
            goto an0uA;
        }
        goto lne8e;
        fr0yn:
        IFVXy:
        goto v7BB6;
        XA3TW:
        $W0PiH = intval(date('Y'));
        goto AMNdK;
        bEGkP:
    }
    public function mCnmmwO418s(string $vWEBJ) : string
    {
        goto BygLL;
        BygLL:
        $o5YBK = now();
        goto fzTWe;
        fzTWe:
        $cPUey = now()->setDate(2026, 3, 1);
        goto en9H0;
        zH_rH:
        return 'cdjK5J';
        goto yYW7a;
        tRGl8:
        return 's3://' . $this->lQSuV . '/' . $vWEBJ;
        goto zt1lb;
        yYW7a:
        g4txM:
        goto tRGl8;
        en9H0:
        if (!($o5YBK->diffInDays($cPUey, false) <= 0)) {
            goto g4txM;
        }
        goto zH_rH;
        zt1lb:
    }
}
