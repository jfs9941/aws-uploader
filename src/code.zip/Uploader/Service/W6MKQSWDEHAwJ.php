<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\QPcmBScQDUpcH;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Core\B1V448YMelQAT;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
final class W6MKQSWDEHAwJ implements QPcmBScQDUpcH
{
    private $lcjaw;
    private $LQzy0;
    public $iMh7s;
    private $AYoYk;
    private $XIn9O;
    private $oBaPs;
    public function __construct($o3YYj, $CXRZ3, $SI80F, $GTBRJ, $uuUzE, $paaZf)
    {
        goto XExBR;
        ESRiW:
        $this->LQzy0 = $CXRZ3;
        goto H_hYY;
        H_hYY:
        $this->iMh7s = $SI80F;
        goto ZO6W4;
        ZO6W4:
        $this->AYoYk = $GTBRJ;
        goto N6qO5;
        N6qO5:
        $this->XIn9O = $uuUzE;
        goto wPLYz;
        XExBR:
        $this->oBaPs = $paaZf;
        goto fV_Zh;
        fV_Zh:
        $this->lcjaw = $o3YYj;
        goto ESRiW;
        wPLYz:
    }
    public function resolvePath($p0I5F, $bWJ0p = A3VATad7gvqZU::S3) : string
    {
        goto lNGpM;
        YFWUG:
        return trim($this->iMh7s, '/') . '/' . $p0I5F;
        goto X0eOa;
        Ofl0N:
        if (!($bWJ0p === A3VATad7gvqZU::LOCAL)) {
            goto lMrKq;
        }
        goto k_CXp;
        X0eOa:
        uieP4:
        goto vg229;
        k_CXp:
        return config('upload.home') . '/' . $p0I5F;
        goto gj48A;
        s7G3o:
        if (!$this->lcjaw) {
            goto uieP4;
        }
        goto YFWUG;
        lNGpM:
        if (!$p0I5F instanceof MEyH4ejCzSk64) {
            goto qV8_b;
        }
        goto evbfv;
        vg229:
        return trim($this->LQzy0, '/') . '/' . $p0I5F;
        goto eyh6q;
        gj48A:
        lMrKq:
        goto LAGVN;
        yzp9L:
        qV8_b:
        goto Ofl0N;
        LAGVN:
        if (!(!empty($this->AYoYk) && !empty($this->XIn9O))) {
            goto iTj3B;
        }
        goto aRSw7;
        GJTV9:
        iTj3B:
        goto s7G3o;
        aRSw7:
        return $this->miFTPpnujBw($p0I5F);
        goto GJTV9;
        evbfv:
        $p0I5F = $p0I5F->getAttribute('filename');
        goto yzp9L;
        eyh6q:
    }
    public function resolveThumbnail(MEyH4ejCzSk64 $p0I5F) : string
    {
        goto OO1af;
        l7dIz:
        if (!$p0I5F instanceof Z7LUL65CwqbbF) {
            goto YWJej;
        }
        goto ZH__M;
        LARgb:
        uS1Ra:
        goto RXVXi;
        ZH__M:
        return $this->resolvePath($p0I5F, $p0I5F->getAttribute('driver'));
        goto CI_3I;
        XsgFP:
        return $this->url($fMTw4, $p0I5F->getAttribute('driver'));
        goto LARgb;
        TcOfr:
        geOCV:
        goto d1rYN;
        Il9wF:
        return '';
        goto WBXxW;
        RXVXi:
        if (!$p0I5F->getAttribute('thumbnail_id')) {
            goto kp9yg;
        }
        goto gj5uQ;
        LKRKl:
        return asset('/img/pdf-preview.svg');
        goto xp6Bo;
        lNBK_:
        return $this->resolvePath($OM3Be, $OM3Be->getAttribute('driver'));
        goto TcOfr;
        CI_3I:
        YWJej:
        goto z8r4J;
        d1rYN:
        kp9yg:
        goto l7dIz;
        gj5uQ:
        $OM3Be = Z7LUL65CwqbbF::find($p0I5F->getAttribute('thumbnail_id'));
        goto ixqHq;
        xp6Bo:
        fa_lI:
        goto Il9wF;
        ixqHq:
        if (!$OM3Be) {
            goto geOCV;
        }
        goto lNBK_;
        OO1af:
        $fMTw4 = $p0I5F->getAttribute('thumbnail');
        goto QNWoI;
        z8r4J:
        if (!$p0I5F instanceof B1V448YMelQAT) {
            goto fa_lI;
        }
        goto LKRKl;
        QNWoI:
        if (!$fMTw4) {
            goto uS1Ra;
        }
        goto XsgFP;
        WBXxW:
    }
    private function url($uMpUA, $bWJ0p)
    {
        goto eO5Xi;
        eO5Xi:
        if (!($bWJ0p == A3VATad7gvqZU::LOCAL)) {
            goto wjXcP;
        }
        goto xro2b;
        eZ4Vh:
        return $this->resolvePath($uMpUA);
        goto tIYsH;
        sX0tX:
        wjXcP:
        goto eZ4Vh;
        xro2b:
        return config('upload.home') . '/' . $uMpUA;
        goto sX0tX;
        tIYsH:
    }
    private function miFTPpnujBw($uMpUA)
    {
        goto Q6ZUe;
        Q6ZUe:
        if (!(strpos($uMpUA, 'https://') === 0)) {
            goto hhNqe;
        }
        goto U_gtS;
        waSQp:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto UVHsV;
        P707l:
        hhNqe:
        goto uD0tf;
        U_gtS:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto P707l;
        uD0tf:
        if (!(strpos($uMpUA, 'm3u8') !== false)) {
            goto OKX5l;
        }
        goto waSQp;
        UVHsV:
        OKX5l:
        goto l1fsL;
        n6P2A:
        return $L10y3->getSignedUrl($this->iMh7s . '/' . $uMpUA, $qkMD8);
        goto jg4qN;
        l1fsL:
        $qkMD8 = now()->addMinutes(60)->timestamp;
        goto FGmr9;
        FGmr9:
        $L10y3 = new UrlSigner($this->AYoYk, $this->oBaPs->path($this->XIn9O));
        goto n6P2A;
        jg4qN:
    }
    public function resolvePathForHlsVideo(MbOYV1VlUGCys $B4_PH, $fIYrO = false) : string
    {
        goto a7jBT;
        TdDBn:
        return $this->iMh7s . '/' . $B4_PH->getAttribute('hls_path');
        goto oUv_Q;
        a7jBT:
        if ($B4_PH->getAttribute('hls_path')) {
            goto ePC97;
        }
        goto XHMhR;
        KZLb4:
        ePC97:
        goto TdDBn;
        XHMhR:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto KZLb4;
        oUv_Q:
    }
    public function resolvePathForHlsVideos()
    {
        goto ilhaA;
        AZ6Ms:
        return [$s2smp, $qkMD8];
        goto BlvO3;
        ilhaA:
        $qkMD8 = now()->addDays(3)->timestamp;
        goto Xe3C8;
        C_NrH:
        $s2smp = $drXFx->getSignedCookie(['key_pair_id' => $this->AYoYk, 'private_key' => $this->oBaPs->path($this->XIn9O), 'policy' => $f3agD]);
        goto AZ6Ms;
        Nepxg:
        $drXFx = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto C_NrH;
        Xe3C8:
        $yAXe3 = $this->iMh7s . '/v2/hls/';
        goto cD_d9;
        cD_d9:
        $f3agD = json_encode(['Statement' => [['Resource' => sprintf('%s*', $yAXe3), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $qkMD8]]]]]);
        goto Nepxg;
        BlvO3:
    }
}
