<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\QE1dzvgcPWV6R;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class RJTPiKnpoHlD0 implements VideoPostHandleServiceInterface
{
    private $qOB2N;
    private $hFxUe;
    public function __construct(UploadServiceInterface $UBWQe, Filesystem $KKbEP)
    {
        $this->qOB2N = $UBWQe;
        $this->hFxUe = $KKbEP;
    }
    public function saveMetadata(string $SEOXv, array $W8N2W)
    {
        goto nvptV;
        tTTfI:
        $zKdCf['duration'] = $W8N2W['duration'];
        goto udHjf;
        zCM1R:
        Log::warning("IvT3V5jT5KEaA metadata store failed for unknown reason ... " . $SEOXv);
        goto Gx2_d;
        nTvDI:
        unset($zKdCf['thumbnail']);
        goto Wv_Ml;
        OZrFD:
        $this->qOB2N->updateFile($IrxWj->getAttribute('id'), QE1dzvgcPWV6R::PROCESSING);
        goto MGLRR;
        d7eHj:
        g_sme:
        goto EJVxK;
        rFe7b:
        U7iIQ:
        goto mVpWw;
        X0zrj:
        $zKdCf = [];
        goto eIfRy;
        Wv_Ml:
        p3_jg:
        goto GGo0O;
        h6AQf:
        if (!$IrxWj->BvW5c) {
            goto p3_jg;
        }
        goto nTvDI;
        LWxC8:
        $zKdCf['fps'] = $W8N2W['fps'];
        goto IjcyH;
        GGo0O:
        if (!$IrxWj->update($zKdCf)) {
            goto N2pvP;
        }
        goto h2C47;
        MGLRR:
        AJug7:
        goto BW3Hy;
        mVpWw:
        if (!isset($W8N2W['fps'])) {
            goto SPabP;
        }
        goto LWxC8;
        xZfDY:
        if (!isset($W8N2W['duration'])) {
            goto ZKGAH;
        }
        goto tTTfI;
        h2C47:
        if (!(isset($W8N2W['change_status']) && $W8N2W['change_status'])) {
            goto AJug7;
        }
        goto OZrFD;
        BW3Hy:
        return $IrxWj->getView();
        goto RBvlh;
        qvuXz:
        if (!isset($W8N2W['resolution'])) {
            goto U7iIQ;
        }
        goto Jjxzv;
        eIfRy:
        if (!isset($W8N2W['thumbnail_url'])) {
            goto g_sme;
        }
        goto IlM3p;
        tN_s7:
        try {
            goto NhCVT;
            VsR5W:
            $zKdCf['thumbnail'] = $th60a['filename'];
            goto dc0R2;
            sVtu0:
            $zKdCf['thumbnail_id'] = $th60a['id'];
            goto VsR5W;
            NhCVT:
            $th60a = $this->qOB2N->storeSingleFile(new class($W8N2W['thumbnail']) implements SingleUploadInterface
            {
                private $SnpXu;
                public function __construct($z620p)
                {
                    $this->SnpXu = $z620p;
                }
                public function getFile()
                {
                    return $this->SnpXu;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto sVtu0;
            dc0R2:
        } catch (\Throwable $L0fOk) {
            Log::warning("IvT3V5jT5KEaA thumbnail store failed: " . $L0fOk->getMessage());
        }
        goto pvk9X;
        Gx2_d:
        throw new \Exception("IvT3V5jT5KEaA metadata store failed for unknown reason ... " . $SEOXv);
        goto c0CLw;
        EJVxK:
        if (!isset($W8N2W['thumbnail'])) {
            goto i9LlQ;
        }
        goto tN_s7;
        udHjf:
        ZKGAH:
        goto qvuXz;
        nvptV:
        $IrxWj = IvT3V5jT5KEaA::findOrFail($SEOXv);
        goto X0zrj;
        pvk9X:
        i9LlQ:
        goto xZfDY;
        RBvlh:
        N2pvP:
        goto zCM1R;
        IjcyH:
        SPabP:
        goto h6AQf;
        IlM3p:
        $zKdCf['thumbnail'] = $W8N2W['thumbnail_url'];
        goto d7eHj;
        Jjxzv:
        $zKdCf['resolution'] = $W8N2W['resolution'];
        goto rFe7b;
        c0CLw:
    }
    public function createThumbnail(string $N2QfI) : void
    {
        goto Gvpz4;
        XW0KY:
        $ncHNI = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto bd88C;
        n2EkW:
        if (!(!$this->hFxUe->directoryExists($nAHnj) && empty($IrxWj->mdFeGNmju5e()))) {
            goto nznIQ;
        }
        goto XW0KY;
        Lb8_x:
        $IrxWj = IvT3V5jT5KEaA::findOrFail($N2QfI);
        goto fHJ17;
        fHJ17:
        $nAHnj = "v2/hls/thumbnails/{$N2QfI}/";
        goto n2EkW;
        U5Ukg:
        nznIQ:
        goto Nhkbt;
        bd88C:
        try {
            goto NPtRM;
            NPtRM:
            $GyvzZ = $ncHNI->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto k32C1;
            qVZFC:
            $ncHNI->sendMessage(['QueueUrl' => $LATCR, 'MessageBody' => json_encode(['file_path' => $IrxWj->getLocation()])]);
            goto M9wzA;
            k32C1:
            $LATCR = $GyvzZ->get('QueueUrl');
            goto qVZFC;
            M9wzA:
        } catch (\Throwable $HhXZM) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$HhXZM->getMessage()}");
        }
        goto U5Ukg;
        Gvpz4:
        Log::info("Use Lambda to generate thumbnail for video: " . $N2QfI);
        goto Lb8_x;
        Nhkbt:
    }
    public function mrveAQnRHOO(string $N2QfI) : void
    {
        goto sDqKf;
        RwrqM:
        Log::error("Message back with success data but not found thumbnail " . $N2QfI);
        goto Q0v59;
        QsA9I:
        throw new \Exception("Message back with success data but not found thumbnail files " . $N2QfI);
        goto q0j3y;
        Sgue0:
        $IrxWj->update(['generated_previews' => $nAHnj]);
        goto N9Odg;
        MpC4Q:
        UtKDs:
        goto l0BCX;
        R011a:
        if (!(count($jhUCR) === 0)) {
            goto qcXmo;
        }
        goto tVpRX;
        q0j3y:
        qcXmo:
        goto Sgue0;
        tVpRX:
        Log::error("Message back with success data but not found thumbnail files " . $N2QfI);
        goto QsA9I;
        l0BCX:
        $jhUCR = $this->hFxUe->files($nAHnj);
        goto R011a;
        Q0v59:
        throw new \Exception("Message back with success data but not found thumbnail " . $N2QfI);
        goto MpC4Q;
        sDqKf:
        $IrxWj = IvT3V5jT5KEaA::findOrFail($N2QfI);
        goto heUJQ;
        heUJQ:
        $nAHnj = "v2/hls/thumbnails/{$N2QfI}/";
        goto dkkf6;
        dkkf6:
        if ($this->hFxUe->directoryExists($nAHnj)) {
            goto UtKDs;
        }
        goto RwrqM;
        N9Odg:
    }
    public function getThumbnails(string $N2QfI) : array
    {
        $IrxWj = IvT3V5jT5KEaA::findOrFail($N2QfI);
        return $IrxWj->getThumbnails();
    }
    public function getMedia(string $N2QfI) : array
    {
        $tzY18 = Media::findOrFail($N2QfI);
        return $tzY18->getView();
    }
}
