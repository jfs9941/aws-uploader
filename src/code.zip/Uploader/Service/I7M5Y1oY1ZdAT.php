<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Core\DNmcAdktLJtqn;
use Jfs\Uploader\Core\CzJP6Lt3zlYLL;
use Jfs\Uploader\Enum\U8OFutptQGm3S;
use Jfs\Uploader\Exception\HA83jJulZGJMz;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Jfs\Uploader\Exception\GK2ekyHdTOcHc;
final class I7M5Y1oY1ZdAT implements UploadServiceInterface
{
    private $xmHlb;
    private $OQTXf;
    private $TMwRg;
    private $AKsNy;
    public function __construct(WkAFfUCbIBC7t $vMz_g, Filesystem $eL8cO, Filesystem $phksh, string $BbzeO)
    {
        goto Q2boK;
        P4efZ:
        $this->OQTXf = $eL8cO;
        goto KlC90;
        Q2boK:
        $this->xmHlb = $vMz_g;
        goto P4efZ;
        W5czo:
        $this->AKsNy = $BbzeO;
        goto bUoPd;
        KlC90:
        $this->TMwRg = $phksh;
        goto W5czo;
        bUoPd:
    }
    public function storeSingleFile(SingleUploadInterface $GDJwi) : array
    {
        goto FyYxp;
        njtRg:
        if (false !== $eviRR && $QxvEM instanceof M9ges0moH9yTs) {
            goto rGvxe;
        }
        goto saUDR;
        k1J4L:
        goto GqdFR;
        goto qoxH1;
        vJJeh:
        $eviRR = $this->TMwRg->putFileAs(dirname($QxvEM->getLocation()), $GDJwi->getFile(), $QxvEM->getFilename() . '.' . $QxvEM->getExtension(), ['visibility' => 'public']);
        goto njtRg;
        qoxH1:
        rGvxe:
        goto BRkXc;
        saUDR:
        throw new \LogicException('File upload failed, check permissions');
        goto k1J4L;
        HhCKd:
        return $QxvEM->getView();
        goto pj_Vb;
        BRkXc:
        $QxvEM->mZunb8ueiKo(U8OFutptQGm3S::UPLOADED);
        goto Se9uJ;
        FyYxp:
        $QxvEM = $this->xmHlb->mqyyNqenhOZ($GDJwi);
        goto vJJeh;
        Se9uJ:
        GqdFR:
        goto HhCKd;
        pj_Vb:
    }
    public function storePreSignedFile(array $on9K1)
    {
        goto xlWng;
        Gqeuh:
        $WoRRL->mg1NNZpymHK();
        goto cG4FW;
        cG4FW:
        return ['filename' => $WoRRL->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $WoRRL->mlc1qkgLpks()];
        goto WPKKh;
        iqI9t:
        $WoRRL = CzJP6Lt3zlYLL::mv2dA6jVf9e($QxvEM, $this->OQTXf, $this->TMwRg, $this->AKsNy, true);
        goto Wv6Ug;
        xlWng:
        $QxvEM = $this->xmHlb->mqyyNqenhOZ($on9K1);
        goto iqI9t;
        Wv6Ug:
        $WoRRL->muVuvEIhLu9($on9K1['mime'], $on9K1['file_size'], $on9K1['chunk_size'], $on9K1['checksums'], $on9K1['user_id'], $on9K1['driver']);
        goto Gqeuh;
        WPKKh:
    }
    public function updatePreSignedFile(string $Ls0bH, int $KQ8tB)
    {
        goto yFqGl;
        F32rh:
        switch ($KQ8tB) {
            case U8OFutptQGm3S::UPLOADED:
                $WoRRL->mQIKqLN2iux();
                goto UvV1F;
            case U8OFutptQGm3S::PROCESSING:
                $WoRRL->mOIa032st9z();
                goto UvV1F;
            case U8OFutptQGm3S::FINISHED:
                $WoRRL->mZwjDyPYlWH();
                goto UvV1F;
            case U8OFutptQGm3S::ABORTED:
                $WoRRL->mPlcqHUs2ma();
                goto UvV1F;
        }
        goto g5win;
        yFqGl:
        $WoRRL = CzJP6Lt3zlYLL::mVy96SS3Bzs($Ls0bH, $this->OQTXf, $this->TMwRg, $this->AKsNy);
        goto F32rh;
        Qh0Vo:
        UvV1F:
        goto SKq8B;
        g5win:
        V7wXr:
        goto Qh0Vo;
        SKq8B:
    }
    public function completePreSignedFile(string $Ls0bH, array $kr4UA)
    {
        goto KJXW0;
        KJXW0:
        $WoRRL = CzJP6Lt3zlYLL::mVy96SS3Bzs($Ls0bH, $this->OQTXf, $this->TMwRg, $this->AKsNy);
        goto ypd8q;
        ypd8q:
        $WoRRL->m0Sl3pG3XHq()->mtth1J5nOXP($kr4UA);
        goto H1iRX;
        H1iRX:
        $WoRRL->mQIKqLN2iux();
        goto Ek7ne;
        Ek7ne:
        return ['path' => $WoRRL->getFile()->getView()['path'], 'thumbnail' => $WoRRL->getFile()->DwgfU, 'id' => $Ls0bH];
        goto txPHl;
        txPHl:
    }
    public function updateFile(string $Ls0bH, int $KQ8tB) : DNmcAdktLJtqn
    {
        goto PamNz;
        QQQhF:
        return $QxvEM;
        goto j37QT;
        PamNz:
        $QxvEM = $this->xmHlb->mnByRjIFcze($Ls0bH);
        goto iiW7b;
        iiW7b:
        $QxvEM->mZunb8ueiKo($KQ8tB);
        goto QQQhF;
        j37QT:
    }
}
