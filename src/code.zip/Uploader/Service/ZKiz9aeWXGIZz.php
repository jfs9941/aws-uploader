<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ZKiz9aeWXGIZz
{
    private $petAu;
    private $MeF4W;
    private $unMfk;
    public function __construct(string $RiWpQ, string $dgo6m, Filesystem $L32kE)
    {
        goto dymw_;
        dymw_:
        $this->petAu = $RiWpQ;
        goto TVIZN;
        UtLXY:
        $this->unMfk = $L32kE;
        goto FmZSi;
        TVIZN:
        $this->MeF4W = $dgo6m;
        goto UtLXY;
        FmZSi:
    }
    public function mS3loCO2ggJ(OWEQTdXGAAFta $QWQ9j) : string
    {
        goto hfE1C;
        XlX7P:
        return $this->unMfk->url($QWQ9j->getAttribute('filename'));
        goto l64yV;
        hfE1C:
        if (!(PdN71mQX1JeZG::S3 == $QWQ9j->getAttribute('driver'))) {
            goto Vsog2;
        }
        goto Y7iVU;
        M036Y:
        Vsog2:
        goto XlX7P;
        Y7iVU:
        return 's3://' . $this->petAu . '/' . $QWQ9j->getAttribute('filename');
        goto M036Y;
        l64yV:
    }
    public function mVIRRSjgwAP(?string $p3Xay) : ?string
    {
        goto bZq3M;
        Z6FQQ:
        $NSF8Y = parse_url($p3Xay, PHP_URL_PATH);
        goto PuTlw;
        PuTlw:
        return 's3://' . $this->petAu . '/' . ltrim($NSF8Y, '/');
        goto I69bQ;
        bZq3M:
        if (!$p3Xay) {
            goto ei9uk;
        }
        goto ij0yW;
        I69bQ:
        rPNkd:
        goto oQqlw;
        QUp5h:
        return null;
        goto mGIy6;
        oQqlw:
        ei9uk:
        goto QUp5h;
        ij0yW:
        if (!y0zfK($p3Xay, $this->petAu)) {
            goto rPNkd;
        }
        goto Z6FQQ;
        mGIy6:
    }
    public function mxCxc9kMwDl(string $NSF8Y) : string
    {
        return 's3://' . $this->petAu . '/' . $NSF8Y;
    }
}
