<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\IOEDyer18cpSA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class Kaz50wg6tz9Qz implements VideoPostHandleServiceInterface
{
    private $p_igU;
    private $BfyCm;
    public function __construct(UploadServiceInterface $NUa77, Filesystem $ejImE)
    {
        $this->p_igU = $NUa77;
        $this->BfyCm = $ejImE;
    }
    public function saveMetadata(string $aK0gt, array $j1WQY)
    {
        goto Iox2G;
        bPWDp:
        if (!(isset($j1WQY['change_status']) && $j1WQY['change_status'])) {
            goto CyuIT;
        }
        goto CrUAv;
        WCvni:
        pjhYu:
        goto gdcNN;
        Iox2G:
        $dajVn = IfBHv1AJhiIDu::findOrFail($aK0gt);
        goto Elfb4;
        rQVA7:
        if (!isset($j1WQY['resolution'])) {
            goto pjhYu;
        }
        goto Ds8WR;
        gdcNN:
        if (!isset($j1WQY['fps'])) {
            goto o3Qn3;
        }
        goto tzZmK;
        hMsbH:
        $u1Dzi['duration'] = $j1WQY['duration'];
        goto CiHPo;
        mYHRh:
        o3Qn3:
        goto chaOe;
        C3dJ7:
        unset($u1Dzi['thumbnail']);
        goto LI0xF;
        CiHPo:
        YU_1j:
        goto rQVA7;
        ytQYf:
        throw new \Exception("IfBHv1AJhiIDu metadata store failed for unknown reason ... " . $aK0gt);
        goto O5_pe;
        cjlCJ:
        try {
            goto q0yJ4;
            q0yJ4:
            $oChgQ = $this->p_igU->storeSingleFile(new class($j1WQY['thumbnail']) implements SingleUploadInterface
            {
                private $VbAbt;
                public function __construct($s2INV)
                {
                    $this->VbAbt = $s2INV;
                }
                public function getFile()
                {
                    return $this->VbAbt;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto NRBW9;
            RqMgj:
            $u1Dzi['thumbnail'] = $oChgQ['filename'];
            goto PZpvD;
            NRBW9:
            $u1Dzi['thumbnail_id'] = $oChgQ['id'];
            goto RqMgj;
            PZpvD:
        } catch (\Throwable $z6tFS) {
            Log::warning("IfBHv1AJhiIDu thumbnail store failed: " . $z6tFS->getMessage());
        }
        goto vy0HH;
        fn8os:
        return $dajVn->getView();
        goto ePtfA;
        ok43R:
        if (!isset($j1WQY['thumbnail'])) {
            goto HtegP;
        }
        goto cjlCJ;
        tzZmK:
        $u1Dzi['fps'] = $j1WQY['fps'];
        goto mYHRh;
        Ds8WR:
        $u1Dzi['resolution'] = $j1WQY['resolution'];
        goto WCvni;
        ePtfA:
        afpDL:
        goto MrY1t;
        YhtV0:
        CyuIT:
        goto fn8os;
        Elfb4:
        $u1Dzi = [];
        goto a6UR0;
        MrY1t:
        Log::warning("IfBHv1AJhiIDu metadata store failed for unknown reason ... " . $aK0gt);
        goto ytQYf;
        vy0HH:
        HtegP:
        goto JqKia;
        CrUAv:
        $this->p_igU->updateFile($dajVn->getAttribute('id'), IOEDyer18cpSA::PROCESSING);
        goto YhtV0;
        JqKia:
        if (!isset($j1WQY['duration'])) {
            goto YU_1j;
        }
        goto hMsbH;
        YYHOs:
        vqv9u:
        goto ok43R;
        mKLSg:
        $u1Dzi['thumbnail'] = $j1WQY['thumbnail_url'];
        goto YYHOs;
        a6UR0:
        if (!isset($j1WQY['thumbnail_url'])) {
            goto vqv9u;
        }
        goto mKLSg;
        LI0xF:
        EJ_JU:
        goto I_9wb;
        I_9wb:
        if (!$dajVn->update($u1Dzi)) {
            goto afpDL;
        }
        goto bPWDp;
        chaOe:
        if (!$dajVn->vo8A1) {
            goto EJ_JU;
        }
        goto C3dJ7;
        O5_pe:
    }
    public function createThumbnail(string $WParL) : void
    {
        goto ayAAf;
        BbeDl:
        $ICE3b = "v2/hls/thumbnails/{$WParL}/";
        goto Mp5q4;
        es6cL:
        wk1yC:
        goto VA_Bp;
        ayAAf:
        Log::info("Use Lambda to generate thumbnail for video: " . $WParL);
        goto nkuQu;
        nkuQu:
        $dajVn = IfBHv1AJhiIDu::findOrFail($WParL);
        goto BbeDl;
        s4Ypx:
        try {
            goto uq7ya;
            NzWiD:
            $RB0uu = $cr4A9->get('QueueUrl');
            goto m2BAE;
            m2BAE:
            $Oe8se->sendMessage(['QueueUrl' => $RB0uu, 'MessageBody' => json_encode(['file_path' => $dajVn->getLocation()])]);
            goto HTcvz;
            uq7ya:
            $cr4A9 = $Oe8se->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto NzWiD;
            HTcvz:
        } catch (\Throwable $t0AeI) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$t0AeI->getMessage()}");
        }
        goto es6cL;
        CBPZP:
        $Oe8se = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto s4Ypx;
        Mp5q4:
        if (!(!$this->BfyCm->directoryExists($ICE3b) && empty($dajVn->mfTv2JQLnYd()))) {
            goto wk1yC;
        }
        goto CBPZP;
        VA_Bp:
    }
    public function m6iYMOsFkWV(string $WParL) : void
    {
        goto GFdcT;
        Thgz3:
        Log::error("Message back with success data but not found thumbnail " . $WParL);
        goto x4Kbs;
        mEdUE:
        Log::error("Message back with success data but not found thumbnail files " . $WParL);
        goto M9f9X;
        rHnPT:
        if (!(count($bFf3l) === 0)) {
            goto CPw22;
        }
        goto mEdUE;
        Z_858:
        if ($this->BfyCm->directoryExists($ICE3b)) {
            goto IWLPP;
        }
        goto Thgz3;
        GFdcT:
        $dajVn = IfBHv1AJhiIDu::findOrFail($WParL);
        goto nmTLV;
        tv03E:
        CPw22:
        goto WDAHw;
        nmTLV:
        $ICE3b = "v2/hls/thumbnails/{$WParL}/";
        goto Z_858;
        WDAHw:
        $dajVn->update(['generated_previews' => $ICE3b]);
        goto yweR4;
        fuOxC:
        IWLPP:
        goto gQ1Nf;
        M9f9X:
        throw new \Exception("Message back with success data but not found thumbnail files " . $WParL);
        goto tv03E;
        gQ1Nf:
        $bFf3l = $this->BfyCm->files($ICE3b);
        goto rHnPT;
        x4Kbs:
        throw new \Exception("Message back with success data but not found thumbnail " . $WParL);
        goto fuOxC;
        yweR4:
    }
    public function getThumbnails(string $WParL) : array
    {
        $dajVn = IfBHv1AJhiIDu::findOrFail($WParL);
        return $dajVn->getThumbnails();
    }
    public function getMedia(string $WParL) : array
    {
        $SmLAm = Media::findOrFail($WParL);
        return $SmLAm->getView();
    }
}
