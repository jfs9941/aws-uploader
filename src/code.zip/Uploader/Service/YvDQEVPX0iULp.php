<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Intervention\Sf7MFJ2wUSx2k\Drivers\Imagick\Driver;
use Intervention\Sf7MFJ2wUSx2k\ImageManager;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\XZsrc8KnXftCK;
use Jfs\Uploader\Core\MQuH2y6UnzTZv;
use Jfs\Uploader\Core\I9eXouytPf2zH;
use Jfs\Uploader\Enum\UimQKBIuLCEAO;
use Jfs\Uploader\Exception\SwRmuIL9tuB7h;
use Jfs\Uploader\Exception\Lki0sGWiU5Kzv;
use Jfs\Uploader\Exception\SXcV92PG8WkeS;
final class YvDQEVPX0iULp implements UploadServiceInterface
{
    private $Bk_J6;
    private $UBJ9G;
    private $Mq65A;
    private $YyruY;
    public function __construct(B0zx05APUr70A $wBB3I, Filesystem $e1L33, Filesystem $o9ClE, string $JOAbq)
    {
        goto rhWgZ;
        rhWgZ:
        $this->Bk_J6 = $wBB3I;
        goto N_USY;
        ckz_r:
        $this->Mq65A = $o9ClE;
        goto Td4Xe;
        N_USY:
        $this->UBJ9G = $e1L33;
        goto ckz_r;
        Td4Xe:
        $this->YyruY = $JOAbq;
        goto Aod5L;
        Aod5L:
    }
    public function storeSingleFile(SingleUploadInterface $EIENe) : array
    {
        goto XDvwf;
        d7ITj:
        $jGQTt = $this->Mq65A->putFileAs(dirname($PQjbH->getLocation()), $EIENe->getFile(), $PQjbH->getFilename() . '.' . $PQjbH->getExtension(), ['visibility' => 'public']);
        goto VwZxw;
        VwZxw:
        if (false !== $jGQTt && $PQjbH instanceof XZsrc8KnXftCK) {
            goto yqVzv;
        }
        goto z982X;
        TNH2M:
        $PQjbH->mTKyaraJgz7(UimQKBIuLCEAO::UPLOADED);
        goto Eb1HG;
        XDvwf:
        $PQjbH = $this->Bk_J6->mI1QeFDQhTT($EIENe);
        goto d7ITj;
        elY7B:
        yqVzv:
        goto TNH2M;
        z982X:
        throw new \LogicException('File upload failed, check permissions');
        goto ikqe0;
        ikqe0:
        goto Eyxov;
        goto elY7B;
        D3SKT:
        return $PQjbH->getView();
        goto Cmh4X;
        Eb1HG:
        Eyxov:
        goto D3SKT;
        Cmh4X:
    }
    public function storePreSignedFile(array $J_Dyr)
    {
        goto HWC3F;
        HWC3F:
        $PQjbH = $this->Bk_J6->mI1QeFDQhTT($J_Dyr);
        goto V54_1;
        K1104:
        $N50om->mHX5nftJZ3k();
        goto Hg4ce;
        S0xQU:
        $N50om->myV5jotB85j($J_Dyr['mime'], $J_Dyr['file_size'], $J_Dyr['chunk_size'], $J_Dyr['checksums'], $J_Dyr['user_id'], $J_Dyr['driver']);
        goto K1104;
        Hg4ce:
        return ['filename' => $N50om->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $N50om->m8jeis941P9()];
        goto X2Vvo;
        V54_1:
        $N50om = I9eXouytPf2zH::mP5oYjcuGW4($PQjbH, $this->UBJ9G, $this->Mq65A, $this->YyruY, true);
        goto S0xQU;
        X2Vvo:
    }
    public function updatePreSignedFile(string $fBLtd, int $MFgvd)
    {
        goto y_ry1;
        cR6cz:
        orkIO:
        goto B9doS;
        y_ry1:
        $N50om = I9eXouytPf2zH::ml9d4ws1Cxk($fBLtd, $this->UBJ9G, $this->Mq65A, $this->YyruY);
        goto Y_fSP;
        B9doS:
        eo9uk:
        goto V5brZ;
        Y_fSP:
        switch ($MFgvd) {
            case UimQKBIuLCEAO::UPLOADED:
                $N50om->m0JbWcPZhsK();
                goto eo9uk;
            case UimQKBIuLCEAO::PROCESSING:
                $N50om->malfoqLbNuP();
                goto eo9uk;
            case UimQKBIuLCEAO::FINISHED:
                $N50om->mwyn7VO1lcF();
                goto eo9uk;
            case UimQKBIuLCEAO::ABORTED:
                $N50om->ms51lN9QOM3();
                goto eo9uk;
        }
        goto cR6cz;
        V5brZ:
    }
    public function completePreSignedFile(string $fBLtd, array $IDZ5l)
    {
        goto m9x7x;
        ZrLu8:
        return ['path' => $N50om->getFile()->getView()['path'], 'thumbnail' => $N50om->getFile()->QWfdD, 'id' => $fBLtd];
        goto BTILE;
        m9x7x:
        $N50om = I9eXouytPf2zH::ml9d4ws1Cxk($fBLtd, $this->UBJ9G, $this->Mq65A, $this->YyruY);
        goto qhlzc;
        qhlzc:
        $N50om->mbu93E3v49T()->meN28KiYulF($IDZ5l);
        goto Fs7Ba;
        Fs7Ba:
        $N50om->m0JbWcPZhsK();
        goto ZrLu8;
        BTILE:
    }
    public function updateFile(string $fBLtd, int $MFgvd) : MQuH2y6UnzTZv
    {
        goto UTnnG;
        UTnnG:
        $PQjbH = $this->Bk_J6->mUT7Vao1x5z($fBLtd);
        goto MvVdc;
        MvVdc:
        $PQjbH->mTKyaraJgz7($MFgvd);
        goto ktUjF;
        ktUjF:
        return $PQjbH;
        goto pEGCr;
        pEGCr:
    }
}
