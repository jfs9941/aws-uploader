<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\CxOTyXYpS0zWZ;
use Jfs\Uploader\Core\LxwvVLXJMU3yo;
use Jfs\Uploader\Core\Wa740mKVvCN9d;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Jfs\Uploader\Exception\JgcJVhkHS65KD;
use Jfs\Uploader\Exception\QBvwqKevOagSc;
use Jfs\Uploader\Exception\WWU79WdJSmf1K;
use Jfs\Uploader\Service\TFO1z3TFjdeZq;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HszAWPogkYfHW implements UploadServiceInterface
{
    private $pjoUw;
    private $niO3l;
    private $aplH5;
    private $UtKAt;
    public function __construct(TFO1z3TFjdeZq $Ob3Wp, Filesystem $xuow1, Filesystem $C82jg, string $OeB5z)
    {
        goto lYieF;
        UmLdl:
        $this->niO3l = $xuow1;
        goto noVHR;
        noVHR:
        $this->aplH5 = $C82jg;
        goto stFjd;
        lYieF:
        $this->pjoUw = $Ob3Wp;
        goto UmLdl;
        stFjd:
        $this->UtKAt = $OeB5z;
        goto ylvEe;
        ylvEe:
    }
    public function storeSingleFile(SingleUploadInterface $wpudO) : array
    {
        goto bad2b;
        I90j7:
        goto H9wEY;
        goto WFkAP;
        G3VDM:
        if (false !== $yRiLu && $spSJx instanceof CxOTyXYpS0zWZ) {
            goto twwu_;
        }
        goto Omo3P;
        C5VZZ:
        $yRiLu = $this->aplH5->putFileAs(dirname($spSJx->getLocation()), $wpudO->getFile(), $spSJx->getFilename() . '.' . $spSJx->getExtension(), ['visibility' => 'public']);
        goto G3VDM;
        C88Eh:
        H9wEY:
        goto dODHU;
        pJZDk:
        $spSJx->mmrYWGPqYWx(LlMDscQw21XKp::UPLOADED);
        goto C88Eh;
        dODHU:
        return $spSJx->getView();
        goto p6USx;
        bad2b:
        $spSJx = $this->pjoUw->mkZ600365Ts($wpudO);
        goto C5VZZ;
        WFkAP:
        twwu_:
        goto pJZDk;
        Omo3P:
        throw new \LogicException('File upload failed, check permissions');
        goto I90j7;
        p6USx:
    }
    public function storePreSignedFile(array $uDjs2)
    {
        goto XoLAV;
        wvTaf:
        $QJo2h->m6ciYNnybZO($uDjs2['mime'], $uDjs2['file_size'], $uDjs2['chunk_size'], $uDjs2['checksums'], $uDjs2['user_id'], $uDjs2['driver']);
        goto nC2xQ;
        nC2xQ:
        $QJo2h->mFYCb5T2MTm();
        goto bZb0J;
        bZb0J:
        return ['filename' => $QJo2h->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $QJo2h->mYn0NQBvboY()];
        goto JpIwQ;
        XoLAV:
        $spSJx = $this->pjoUw->mkZ600365Ts($uDjs2);
        goto Lu6Xh;
        Lu6Xh:
        $QJo2h = Wa740mKVvCN9d::mxISck3N94O($spSJx, $this->niO3l, $this->aplH5, $this->UtKAt, true);
        goto wvTaf;
        JpIwQ:
    }
    public function updatePreSignedFile(string $UVUKT, int $jIflK)
    {
        goto f5aTl;
        f5aTl:
        $QJo2h = Wa740mKVvCN9d::mubHrcw8ws9($UVUKT, $this->niO3l, $this->aplH5, $this->UtKAt);
        goto S2rwo;
        S2rwo:
        switch ($jIflK) {
            case LlMDscQw21XKp::UPLOADED:
                $QJo2h->mieXlIddk03();
                goto pTgjS;
            case LlMDscQw21XKp::PROCESSING:
                $QJo2h->mCTgD0MzwOX();
                goto pTgjS;
            case LlMDscQw21XKp::FINISHED:
                $QJo2h->mALZJatptUu();
                goto pTgjS;
            case LlMDscQw21XKp::ABORTED:
                $QJo2h->mo2jzTGzJop();
                goto pTgjS;
        }
        goto mBPSY;
        Tg3aX:
        pTgjS:
        goto sJmPd;
        mBPSY:
        BQLJ_:
        goto Tg3aX;
        sJmPd:
    }
    public function completePreSignedFile(string $UVUKT, array $dXuiY)
    {
        goto G7MSI;
        unrwa:
        $QJo2h->mieXlIddk03();
        goto XGLO3;
        G7MSI:
        $QJo2h = Wa740mKVvCN9d::mubHrcw8ws9($UVUKT, $this->niO3l, $this->aplH5, $this->UtKAt);
        goto HmSzb;
        XGLO3:
        return ['path' => $QJo2h->getFile()->getView()['path'], 'thumbnail' => $QJo2h->getFile()->tWztK, 'id' => $UVUKT];
        goto se3eS;
        HmSzb:
        $QJo2h->mBE2ZEQSaNO()->mMt8Z43ZMyY($dXuiY);
        goto unrwa;
        se3eS:
    }
    public function updateFile(string $UVUKT, int $jIflK) : LxwvVLXJMU3yo
    {
        goto pdI_p;
        TdXlT:
        return $spSJx;
        goto MSI_j;
        j8wcL:
        $spSJx->mmrYWGPqYWx($jIflK);
        goto TdXlT;
        pdI_p:
        $spSJx = $this->pjoUw->mIY1MPztZJp($UVUKT);
        goto j8wcL;
        MSI_j:
    }
}
