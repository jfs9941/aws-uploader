<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Core\Observer\ZiVoxGfurmBI7;
use Jfs\Uploader\Core\Observer\LK57MVeZYodze;
use Jfs\Uploader\Core\IyqtwINobs6go;
use Jfs\Uploader\Core\Hyi6BrRTUHRYH;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Jfs\Uploader\Exception\RpmK0FOGWoQmq;
use Jfs\Uploader\Service\FileResolver\Af4ZCqs0KIlAV;
use Ramsey\Uuid\Uuid;
final class XqoSwDelQBsQt
{
    private $AIk9h;
    private $x0wV5;
    private $K79lK;
    public function __construct($gD2vu, $mHTSY, $yEBaZ)
    {
        goto xndsD;
        UAZVB:
        $this->x0wV5 = $mHTSY;
        goto AC6GD;
        xndsD:
        $this->AIk9h = $gD2vu;
        goto UAZVB;
        AC6GD:
        $this->K79lK = $yEBaZ;
        goto raQ7g;
        raQ7g:
    }
    public function mV3nnu59hwG($MJA1T)
    {
        goto ppshw;
        wi9Jq:
        ajZdO:
        goto MWvR1;
        MWvR1:
        return $this->mO95PchXWkh($MJA1T['file_extension'], 's3' === $MJA1T['driver'] ? NYPGraEb3Ennl::S3 : NYPGraEb3Ennl::LOCAL);
        goto k5rTf;
        ppshw:
        if (!$MJA1T instanceof SingleUploadInterface) {
            goto ajZdO;
        }
        goto FCc88;
        ix9D0:
        return $this->mO95PchXWkh($WA3QB->extension(), NYPGraEb3Ennl::S3, null, $MJA1T->options());
        goto wi9Jq;
        FCc88:
        $WA3QB = $MJA1T->getFile();
        goto ix9D0;
        k5rTf:
    }
    public function m4N8ntnagh6(string $Qu08p)
    {
        goto xczan;
        xczan:
        $FR_h8 = config('upload.attachment_model')::findOrFail($Qu08p);
        goto DnlOs;
        BgrmL:
        $oYtbp->exists = true;
        goto Fx7Lh;
        DnlOs:
        $oYtbp = $this->mO95PchXWkh($FR_h8->getAttribute('type'), $FR_h8->getAttribute('driver'), $FR_h8->getAttribute('id'));
        goto BgrmL;
        mGqon:
        return $oYtbp;
        goto Baylw;
        Fx7Lh:
        $oYtbp->setRawAttributes($FR_h8->getAttributes());
        goto mGqon;
        Baylw:
    }
    public function mcIC6oHbrkQ(string $JclXR) : EknRcwWhw5aDZ
    {
        goto ykxqw;
        TqmC1:
        $eq0T_ = Hyi6BrRTUHRYH::mMt2F10WYwv($RHxcL);
        goto aYimX;
        Vdh2B:
        $RHxcL = json_decode($xx6rx, true);
        goto SrPPJ;
        fb9Nk:
        throw new KzbSFcd7qiwCv('metadata file not found');
        goto HFy2N;
        SrPPJ:
        if (!$RHxcL) {
            goto wrctv;
        }
        goto TqmC1;
        FeZ7S:
        $xx6rx = $this->K79lK->get($JclXR);
        goto QW7l1;
        ykxqw:
        $xx6rx = $this->x0wV5->get($JclXR);
        goto a1PuN;
        aYimX:
        return $this->mO95PchXWkh($eq0T_->eBQ45, $eq0T_->m6VKberL6M5(), $eq0T_->filename);
        goto WG0A6;
        WG0A6:
        wrctv:
        goto fb9Nk;
        a1PuN:
        if ($xx6rx) {
            goto ZUync;
        }
        goto FeZ7S;
        QW7l1:
        ZUync:
        goto Vdh2B;
        HFy2N:
    }
    private function mO95PchXWkh(string $BI43q, $lA8Ud, ?string $Qu08p = null, array $i6jr_ = [])
    {
        goto D5yNF;
        L8PQw:
        $zFcrc = $zFcrc->mJj4qrv3i53($lA8Ud);
        goto pQbad;
        yEfe8:
        switch ($BI43q) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $zFcrc = YPgQPiPQjMu1g::createFromScratch($Qu08p, $BI43q);
                goto APUO7;
            case 'mp4':
            case 'mov':
                $zFcrc = SmhkgG6le5p0r::createFromScratch($Qu08p, $BI43q);
                goto APUO7;
            case 'pdf':
                $zFcrc = IyqtwINobs6go::createFromScratch($Qu08p, $BI43q);
                goto APUO7;
            default:
                throw new RpmK0FOGWoQmq("not support file type {$BI43q}");
        }
        goto M0rE4;
        M0rE4:
        e1XyB:
        goto NmHru;
        pQbad:
        $zFcrc->m0Ku2PvnNzM(new ZiVoxGfurmBI7($zFcrc));
        goto Ulben;
        D5yNF:
        $Qu08p = $Qu08p ?? Uuid::uuid4()->getHex()->toString();
        goto yEfe8;
        Ulben:
        $zFcrc->m0Ku2PvnNzM(new LK57MVeZYodze($zFcrc, $this->K79lK, $i6jr_));
        goto dHjO2;
        NmHru:
        APUO7:
        goto L8PQw;
        lkhH8:
        tdX7D:
        goto z8J1U;
        z8J1U:
        throw new RpmK0FOGWoQmq("not support file type {$BI43q}");
        goto w0Jg3;
        dHjO2:
        foreach ($this->AIk9h as $qrahj) {
            goto zlc4i;
            zlc4i:
            if (!$qrahj->m4gfXZPb4I7($zFcrc)) {
                goto Mmb6Y;
            }
            goto tCswG;
            tCswG:
            return $zFcrc->initLocation($qrahj->m8SrIJLXyX6($zFcrc));
            goto uU5vi;
            Nlv3E:
            TKkB9:
            goto QKvIO;
            uU5vi:
            Mmb6Y:
            goto Nlv3E;
            QKvIO:
        }
        goto lkhH8;
        w0Jg3:
    }
}
