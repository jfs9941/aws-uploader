<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
use Illuminate\Contracts\Filesystem\Filesystem;
final class B0o6VsHdCPn65
{
    private $t4Y2D;
    private $P898I;
    private $P8Yzg;
    public function __construct(string $wY6MR, string $o7KnU, Filesystem $jT0xz)
    {
        goto GwXmK;
        jaem7:
        $this->P8Yzg = $jT0xz;
        goto GGmOD;
        Lgpkt:
        $this->P898I = $o7KnU;
        goto jaem7;
        GwXmK:
        $this->t4Y2D = $wY6MR;
        goto Lgpkt;
        GGmOD:
    }
    public function m4IlrkQicO1(ALaATNTmuoFHt $nu6qO) : string
    {
        goto XDYxh;
        WHKVT:
        axHHt:
        goto WW5iM;
        XDYxh:
        if (!(EzGWviwQDmAwI::S3 == $nu6qO->getAttribute('driver'))) {
            goto axHHt;
        }
        goto hvquT;
        hvquT:
        return 's3://' . $this->t4Y2D . '/' . $nu6qO->getAttribute('filename');
        goto WHKVT;
        WW5iM:
        return $this->P8Yzg->url($nu6qO->getAttribute('filename'));
        goto EFKdd;
        EFKdd:
    }
    public function mQNUjIdrdPB(?string $NLPuF) : ?string
    {
        goto Tpt4x;
        e9xN0:
        $AvgzF = parse_url($NLPuF, PHP_URL_PATH);
        goto Y_S3e;
        IIDbx:
        qm8iT:
        goto z6oyq;
        UVi0o:
        return null;
        goto SYP7q;
        RNSAA:
        if (!A6zLO($NLPuF, $this->t4Y2D)) {
            goto qm8iT;
        }
        goto e9xN0;
        Y_S3e:
        return 's3://' . $this->t4Y2D . '/' . ltrim($AvgzF, '/');
        goto IIDbx;
        Tpt4x:
        if (!$NLPuF) {
            goto vIsZE;
        }
        goto RNSAA;
        z6oyq:
        vIsZE:
        goto UVi0o;
        SYP7q:
    }
    public function mASHNMJyavd(string $AvgzF) : string
    {
        return 's3://' . $this->t4Y2D . '/' . $AvgzF;
    }
}
