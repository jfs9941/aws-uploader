<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\QmpIhYv3zjvt7;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Core\D7CMsi4o836Y7;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
final class GRHQHm8JVCKmn implements QmpIhYv3zjvt7
{
    private $IjOzB;
    private $AsuR8;
    public $iZ0gH;
    private $zFYiP;
    private $HLnn9;
    private $JFHzD;
    public function __construct($binwr, $aGpHz, $vJHQo, $EWCI3, $LUoQM, $NVuHg)
    {
        goto scWKT;
        HO92V:
        $this->zFYiP = $EWCI3;
        goto bP8kX;
        WOeo3:
        $this->iZ0gH = $vJHQo;
        goto HO92V;
        bP8kX:
        $this->HLnn9 = $LUoQM;
        goto zf6zV;
        scWKT:
        $this->JFHzD = $NVuHg;
        goto La3i3;
        a1GZj:
        $this->AsuR8 = $aGpHz;
        goto WOeo3;
        La3i3:
        $this->IjOzB = $binwr;
        goto a1GZj;
        zf6zV:
    }
    public function resolvePath($Zt12Z, $LvK26 = Tfi7lQDVWUJD9::S3) : string
    {
        goto mrQpo;
        Oh1d_:
        Y3SHI:
        goto BntrQ;
        X9AsN:
        $Zt12Z = $Zt12Z->getAttribute('filename');
        goto RMmsG;
        sF3hc:
        return config('upload.home') . '/' . $Zt12Z;
        goto Rsi98;
        wXCe5:
        if (!($LvK26 === Tfi7lQDVWUJD9::LOCAL)) {
            goto nLqQ1;
        }
        goto sF3hc;
        Rsi98:
        nLqQ1:
        goto ICDG7;
        RMmsG:
        taapB:
        goto wXCe5;
        v5FQH:
        return trim($this->AsuR8, '/') . '/' . $Zt12Z;
        goto PPbQ6;
        B45b3:
        return trim($this->iZ0gH, '/') . '/' . $Zt12Z;
        goto M3OaS;
        M3OaS:
        bt8aI:
        goto v5FQH;
        Sn8Um:
        return $this->mnEBhRbT6G0($Zt12Z);
        goto Oh1d_;
        mrQpo:
        if (!$Zt12Z instanceof THrRXrYMGJt0m) {
            goto taapB;
        }
        goto X9AsN;
        BntrQ:
        if (!$this->IjOzB) {
            goto bt8aI;
        }
        goto B45b3;
        ICDG7:
        if (!(!empty($this->zFYiP) && !empty($this->HLnn9))) {
            goto Y3SHI;
        }
        goto Sn8Um;
        PPbQ6:
    }
    public function resolveThumbnail(THrRXrYMGJt0m $Zt12Z) : string
    {
        goto FCezV;
        SqCxV:
        if (!$BKlrl) {
            goto Ujbch;
        }
        goto qApFw;
        qApFw:
        return $this->url($BKlrl, $Zt12Z->getAttribute('driver'));
        goto PUIbT;
        vC1js:
        Ny6BD:
        goto yFllR;
        J7Evm:
        $TZIoz = Q48IcpSr3UpAT::find($Zt12Z->getAttribute('thumbnail_id'));
        goto pHEkS;
        apFBd:
        return $this->resolvePath($TZIoz, $TZIoz->getAttribute('driver'));
        goto FMTEG;
        mVkBJ:
        dRbme:
        goto YV9VF;
        HQhvu:
        KzyrW:
        goto jhnMw;
        FMTEG:
        tupp_:
        goto mVkBJ;
        yFllR:
        return '';
        goto Hj3W0;
        I1dO9:
        if (!$Zt12Z->getAttribute('thumbnail_id')) {
            goto dRbme;
        }
        goto J7Evm;
        XU1eG:
        return $this->resolvePath($Zt12Z, $Zt12Z->getAttribute('driver'));
        goto HQhvu;
        r8gip:
        return asset('/img/pdf-preview.svg');
        goto vC1js;
        pHEkS:
        if (!$TZIoz) {
            goto tupp_;
        }
        goto apFBd;
        YV9VF:
        if (!$Zt12Z instanceof Q48IcpSr3UpAT) {
            goto KzyrW;
        }
        goto XU1eG;
        jhnMw:
        if (!$Zt12Z instanceof D7CMsi4o836Y7) {
            goto Ny6BD;
        }
        goto r8gip;
        FCezV:
        $BKlrl = $Zt12Z->getAttribute('thumbnail');
        goto SqCxV;
        PUIbT:
        Ujbch:
        goto I1dO9;
        Hj3W0:
    }
    private function url($cJV8L, $LvK26)
    {
        goto dkgxX;
        zXyNG:
        return $this->resolvePath($cJV8L);
        goto L4zZD;
        dkgxX:
        if (!($LvK26 == Tfi7lQDVWUJD9::LOCAL)) {
            goto SC0N0;
        }
        goto Dt3Ga;
        Dt3Ga:
        return config('upload.home') . '/' . $cJV8L;
        goto fgnvF;
        fgnvF:
        SC0N0:
        goto zXyNG;
        L4zZD:
    }
    private function mnEBhRbT6G0($cJV8L)
    {
        goto LNv4x;
        SxIdx:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto cFGhD;
        WjWrs:
        $AgpdT = new UrlSigner($this->zFYiP, $this->JFHzD->path($this->HLnn9));
        goto dagk5;
        dagk5:
        return $AgpdT->getSignedUrl($this->iZ0gH . '/' . $cJV8L, $TBx6A);
        goto jr9mF;
        stIz7:
        OOLLV:
        goto y3dA3;
        y3dA3:
        $TBx6A = now()->addMinutes(60)->timestamp;
        goto WjWrs;
        cFGhD:
        jAOTM:
        goto yPUot;
        qq3Mk:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto stIz7;
        LNv4x:
        if (!(strpos($cJV8L, 'https://') === 0)) {
            goto jAOTM;
        }
        goto SxIdx;
        yPUot:
        if (!(strpos($cJV8L, 'm3u8') !== false)) {
            goto OOLLV;
        }
        goto qq3Mk;
        jr9mF:
    }
    public function resolvePathForHlsVideo(M7oTJdNm24KG4 $oS5x2, $TsCWA = false) : string
    {
        goto f1KZq;
        xgaI4:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto tVkz8;
        ZmqZ7:
        return $this->iZ0gH . '/' . $oS5x2->getAttribute('hls_path');
        goto yPlW5;
        f1KZq:
        if ($oS5x2->getAttribute('hls_path')) {
            goto fAtfA;
        }
        goto xgaI4;
        tVkz8:
        fAtfA:
        goto ZmqZ7;
        yPlW5:
    }
    public function resolvePathForHlsVideos()
    {
        goto JUxZi;
        JNE6Z:
        return [$yLBDD, $TBx6A];
        goto cRtZj;
        mlQch:
        $yLBDD = $pokVA->getSignedCookie(['key_pair_id' => $this->zFYiP, 'private_key' => $this->JFHzD->path($this->HLnn9), 'policy' => $lJLWV]);
        goto JNE6Z;
        ztV8U:
        $lJLWV = json_encode(['Statement' => [['Resource' => sprintf('%s*', $S91pq), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $TBx6A]]]]]);
        goto l5c2z;
        JUxZi:
        $TBx6A = now()->addDays(3)->timestamp;
        goto c86dx;
        l5c2z:
        $pokVA = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto mlQch;
        c86dx:
        $S91pq = $this->iZ0gH . '/v2/hls/';
        goto ztV8U;
        cRtZj:
    }
}
