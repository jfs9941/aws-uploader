<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
use Illuminate\Contracts\Filesystem\Filesystem;
final class JkVi3Kv2ThmJv
{
    private $GCETN;
    private $jHBWO;
    private $c5PSU;
    public function __construct(string $wiZGO, string $Jvu_x, Filesystem $Ape3_)
    {
        goto BdlZU;
        JFM9W:
        $this->c5PSU = $Ape3_;
        goto yVYyC;
        BdlZU:
        $this->GCETN = $wiZGO;
        goto q7t8I;
        q7t8I:
        $this->jHBWO = $Jvu_x;
        goto JFM9W;
        yVYyC:
    }
    public function m1EBsZazL7t(OavRsjNQCayKr $jGsBp) : string
    {
        goto wcWcb;
        UHsF3:
        return 's3://' . $this->GCETN . '/' . $jGsBp->getAttribute('filename');
        goto DrdAl;
        wcWcb:
        if (!(ZuZC67ch9j73R::S3 == $jGsBp->getAttribute('driver'))) {
            goto B7B9O;
        }
        goto UHsF3;
        J59ZE:
        return $this->c5PSU->url($jGsBp->getAttribute('filename'));
        goto na1If;
        DrdAl:
        B7B9O:
        goto J59ZE;
        na1If:
    }
    public function mvbnzr7CgdU(?string $zbNSu) : ?string
    {
        goto Xty1T;
        Ic3Hj:
        Q92cZ:
        goto T4fNw;
        HheZT:
        if (!Rri3l($zbNSu, $this->GCETN)) {
            goto Q92cZ;
        }
        goto koe7g;
        Xty1T:
        if (!$zbNSu) {
            goto k0C_3;
        }
        goto HheZT;
        L44aJ:
        return 's3://' . $this->GCETN . '/' . ltrim($HyAAV, '/');
        goto Ic3Hj;
        RrntY:
        return null;
        goto JNje6;
        koe7g:
        $HyAAV = parse_url($zbNSu, PHP_URL_PATH);
        goto L44aJ;
        T4fNw:
        k0C_3:
        goto RrntY;
        JNje6:
    }
    public function mEwXI6TBtNV(string $HyAAV) : string
    {
        return 's3://' . $this->GCETN . '/' . $HyAAV;
    }
}
