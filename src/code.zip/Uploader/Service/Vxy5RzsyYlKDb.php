<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Vxy5RzsyYlKDb
{
    private $XbarW;
    private $LFjXi;
    private $yt19t;
    public function __construct(string $YctT5, string $II_ch, Filesystem $RndMA)
    {
        goto NXeKK;
        Sm2il:
        $this->LFjXi = $II_ch;
        goto lqGQT;
        NXeKK:
        $this->XbarW = $YctT5;
        goto Sm2il;
        lqGQT:
        $this->yt19t = $RndMA;
        goto uVqTA;
        uVqTA:
    }
    public function maJ4Ob7NLC9(KFe2ZCctciwsA $Hz32I) : string
    {
        goto wJbp8;
        EDU3M:
        return $this->yt19t->url($Hz32I->getAttribute('filename'));
        goto XA0MO;
        HBwLP:
        dXRgX:
        goto EDU3M;
        wJbp8:
        if (!(DccywYjigTakI::S3 == $Hz32I->getAttribute('driver'))) {
            goto dXRgX;
        }
        goto fGejS;
        fGejS:
        return 's3://' . $this->XbarW . '/' . $Hz32I->getAttribute('filename');
        goto HBwLP;
        XA0MO:
    }
    public function mjWpIQG8bPS(?string $A8jlG) : ?string
    {
        goto WAPCv;
        cqT35:
        $hU2b_ = parse_url($A8jlG, PHP_URL_PATH);
        goto aXSQ8;
        usNHx:
        if (!zCu3a($A8jlG, $this->XbarW)) {
            goto xzsR3;
        }
        goto cqT35;
        WAPCv:
        if (!$A8jlG) {
            goto BdyOr;
        }
        goto usNHx;
        aXSQ8:
        return 's3://' . $this->XbarW . '/' . ltrim($hU2b_, '/');
        goto saarM;
        saarM:
        xzsR3:
        goto Lx_yA;
        Hk9M_:
        return null;
        goto TkXNc;
        Lx_yA:
        BdyOr:
        goto Hk9M_;
        TkXNc:
    }
    public function mTU0gDxsVs7(string $hU2b_) : string
    {
        return 's3://' . $this->XbarW . '/' . $hU2b_;
    }
}
