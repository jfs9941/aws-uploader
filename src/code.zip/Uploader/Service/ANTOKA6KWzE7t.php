<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\BCa3K9pPFzXM0;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Core\Observer\K5kKBgfmxrNjt;
use Jfs\Uploader\Core\Observer\RnNnPMo6r46rb;
use Jfs\Uploader\Core\SzJ0JuIDdEumD;
use Jfs\Uploader\Core\BnU61laaiajX2;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
use Jfs\Uploader\Exception\NaLxNTATn0Ubr;
use Jfs\Uploader\Exception\A0pWCtOCA3zPw;
use Jfs\Uploader\Service\FileResolver\M4mASNosdA3Eb;
use Ramsey\Uuid\Uuid;
final class ANTOKA6KWzE7t
{
    private $pC7h2;
    private $s0VP1;
    private $zTo0t;
    public function __construct($l0cG3, $TuWZt, $Vi8xq)
    {
        goto ty8QR;
        NdPLi:
        $this->zTo0t = $Vi8xq;
        goto HPDIJ;
        E89XF:
        $this->s0VP1 = $TuWZt;
        goto NdPLi;
        ty8QR:
        $this->pC7h2 = $l0cG3;
        goto E89XF;
        HPDIJ:
    }
    public function mG1Vpid3zRU($OyRI8)
    {
        goto OH5uV;
        RPcll:
        return $this->mLfwT0K2BWw($q7OeR->extension(), Rc6MZhMMdyG6A::S3, null, $OyRI8->options());
        goto AkkA4;
        OH5uV:
        if (!$OyRI8 instanceof SingleUploadInterface) {
            goto FSDNk;
        }
        goto OgnCL;
        OgnCL:
        $q7OeR = $OyRI8->getFile();
        goto RPcll;
        GDnBw:
        return $this->mLfwT0K2BWw($OyRI8['file_extension'], 's3' === $OyRI8['driver'] ? Rc6MZhMMdyG6A::S3 : Rc6MZhMMdyG6A::LOCAL);
        goto p0vCk;
        AkkA4:
        FSDNk:
        goto GDnBw;
        p0vCk:
    }
    public function m8OPFlA7Pti(string $S6xyJ)
    {
        goto gtAdK;
        l0fW2:
        $VZzWw->exists = true;
        goto sspdf;
        lM8GG:
        return $VZzWw;
        goto tbkjN;
        sspdf:
        $VZzWw->setRawAttributes($cS_yX->getAttributes());
        goto lM8GG;
        oalZf:
        $VZzWw = $this->mLfwT0K2BWw($cS_yX->getAttribute('type'), $cS_yX->getAttribute('driver'), $cS_yX->getAttribute('id'));
        goto l0fW2;
        gtAdK:
        $cS_yX = config('upload.attachment_model')::findOrFail($S6xyJ);
        goto oalZf;
        tbkjN:
    }
    public function mfzCIE4XvGW(string $nSpsP) : BCa3K9pPFzXM0
    {
        goto wA6Yz;
        VxK6c:
        throw new NaLxNTATn0Ubr('metadata file not found');
        goto cgKqx;
        jooV7:
        return $this->mLfwT0K2BWw($d31o8->PFcfx, $d31o8->mn8AUEYdqqT(), $d31o8->filename);
        goto BZ0hn;
        lyXcz:
        OLNPH:
        goto eli6d;
        wA6Yz:
        $i5wGJ = $this->s0VP1->get($nSpsP);
        goto vlRA8;
        VlZ2q:
        $d31o8 = BnU61laaiajX2::mowxdHh44rb($b679I);
        goto jooV7;
        g9p2k:
        if (!$b679I) {
            goto Wq9C4;
        }
        goto VlZ2q;
        BZ0hn:
        Wq9C4:
        goto VxK6c;
        CUeXl:
        $i5wGJ = $this->zTo0t->get($nSpsP);
        goto lyXcz;
        eli6d:
        $b679I = json_decode($i5wGJ, true);
        goto g9p2k;
        vlRA8:
        if ($i5wGJ) {
            goto OLNPH;
        }
        goto CUeXl;
        cgKqx:
    }
    private function mLfwT0K2BWw(string $ObZOl, $PSXn5, ?string $S6xyJ = null, array $kEeaF = [])
    {
        goto LCBVX;
        McVMO:
        kitSv:
        goto HKrZ_;
        LCBVX:
        $S6xyJ = $S6xyJ ?? Uuid::uuid4()->getHex()->toString();
        goto KxzkF;
        vStao:
        throw new A0pWCtOCA3zPw("not support file type {$ObZOl}");
        goto afYgM;
        KxzkF:
        switch ($ObZOl) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $QkNTC = JyZaxpharsbun::createFromScratch($S6xyJ, $ObZOl);
                goto kitSv;
            case 'mp4':
            case 'mov':
                $QkNTC = Kt6NO3eUvdER6::createFromScratch($S6xyJ, $ObZOl);
                goto kitSv;
            case 'pdf':
                $QkNTC = SzJ0JuIDdEumD::createFromScratch($S6xyJ, $ObZOl);
                goto kitSv;
            default:
                throw new A0pWCtOCA3zPw("not support file type {$ObZOl}");
        }
        goto muu60;
        RGRwI:
        $QkNTC->mCa4XumvZrx(new RnNnPMo6r46rb($QkNTC, $this->zTo0t, $kEeaF));
        goto k3niv;
        fBH7x:
        s_5Bh:
        goto vStao;
        k3niv:
        foreach ($this->pC7h2 as $Hes5T) {
            goto wcBqh;
            PWoCr:
            eScD2:
            goto HD_Ij;
            U7ZH8:
            KPuff:
            goto PWoCr;
            kSPZH:
            return $QkNTC->initLocation($Hes5T->mcu4iIFvGwu($QkNTC));
            goto U7ZH8;
            wcBqh:
            if (!$Hes5T->mSaIEl1i6XJ($QkNTC)) {
                goto KPuff;
            }
            goto kSPZH;
            HD_Ij:
        }
        goto fBH7x;
        nvwXS:
        $QkNTC->mCa4XumvZrx(new K5kKBgfmxrNjt($QkNTC));
        goto RGRwI;
        muu60:
        jcj3I:
        goto McVMO;
        HKrZ_:
        $QkNTC = $QkNTC->mWhIZSP1zew($PSXn5);
        goto nvwXS;
        afYgM:
    }
}
