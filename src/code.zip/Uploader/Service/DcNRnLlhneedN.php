<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class DcNRnLlhneedN implements VideoPostHandleServiceInterface
{
    private $ZzTK7;
    private $ZN9hu;
    public function __construct(UploadServiceInterface $x96QO, Filesystem $C2YXG)
    {
        $this->ZzTK7 = $x96QO;
        $this->ZN9hu = $C2YXG;
    }
    public function saveMetadata(string $uuHkQ, array $i4bQp)
    {
        goto Tx2GP;
        PKQYK:
        $Nn0uq = [];
        goto b7OO8;
        adeGC:
        JWkGx:
        goto gfnUe;
        b7OO8:
        if (!isset($i4bQp['thumbnail_url'])) {
            goto tHsDj;
        }
        goto ODK32;
        nf7tA:
        FNSsb:
        goto GDnQG;
        GDnQG:
        if (!$XrW52->oMOXS) {
            goto olA3H;
        }
        goto SaZ7z;
        gf7HK:
        if (!(isset($i4bQp['change_status']) && $i4bQp['change_status'])) {
            goto ox32O;
        }
        goto nPUKm;
        nPUKm:
        $this->ZzTK7->updateFile($XrW52->getAttribute('id'), Xy3InMky6jKYf::PROCESSING);
        goto hfG29;
        PTGak:
        DcL0m:
        goto JZhnC;
        aczCu:
        return $XrW52->getView();
        goto adeGC;
        iBTKP:
        $Nn0uq['fps'] = $i4bQp['fps'];
        goto nf7tA;
        ODK32:
        $Nn0uq['thumbnail'] = $i4bQp['thumbnail_url'];
        goto iNDra;
        GvGjV:
        u0M27:
        goto b1E6v;
        kwXwf:
        olA3H:
        goto maUmH;
        gfnUe:
        Log::warning("WrCq6RmnGcVh7 metadata store failed for unknown reason ... " . $uuHkQ);
        goto qdW6C;
        POAjS:
        JJm9T:
        goto HJPcA;
        qcZzq:
        $Nn0uq['duration'] = $i4bQp['duration'];
        goto PTGak;
        iNDra:
        tHsDj:
        goto FQhnG;
        qdW6C:
        throw new \Exception("WrCq6RmnGcVh7 metadata store failed for unknown reason ... " . $uuHkQ);
        goto hSY2Y;
        ZiPfQ:
        $Nn0uq['resolution'] = $i4bQp['resolution'];
        goto GvGjV;
        Tx2GP:
        $XrW52 = WrCq6RmnGcVh7::findOrFail($uuHkQ);
        goto PKQYK;
        SaZ7z:
        unset($Nn0uq['thumbnail']);
        goto kwXwf;
        HJPcA:
        if (!isset($i4bQp['duration'])) {
            goto DcL0m;
        }
        goto qcZzq;
        b1E6v:
        if (!isset($i4bQp['fps'])) {
            goto FNSsb;
        }
        goto iBTKP;
        JZhnC:
        if (!isset($i4bQp['resolution'])) {
            goto u0M27;
        }
        goto ZiPfQ;
        hfG29:
        ox32O:
        goto aczCu;
        ygJ8c:
        try {
            goto Qh_Ib;
            Na3xf:
            $Nn0uq['thumbnail_id'] = $EpLlV['id'];
            goto QH_xp;
            QH_xp:
            $Nn0uq['thumbnail'] = $EpLlV['filename'];
            goto UaxNU;
            Qh_Ib:
            $EpLlV = $this->ZzTK7->storeSingleFile(new class($i4bQp['thumbnail']) implements SingleUploadInterface
            {
                private $tp12K;
                public function __construct($DejZC)
                {
                    $this->tp12K = $DejZC;
                }
                public function getFile()
                {
                    return $this->tp12K;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Na3xf;
            UaxNU:
        } catch (\Throwable $IGLS9) {
            Log::warning("WrCq6RmnGcVh7 thumbnail store failed: " . $IGLS9->getMessage());
        }
        goto POAjS;
        maUmH:
        if (!$XrW52->update($Nn0uq)) {
            goto JWkGx;
        }
        goto gf7HK;
        FQhnG:
        if (!isset($i4bQp['thumbnail'])) {
            goto JJm9T;
        }
        goto ygJ8c;
        hSY2Y:
    }
    public function createThumbnail(string $hQAfC) : void
    {
        goto UXf0o;
        es_OP:
        $f_RJe = "v2/hls/thumbnails/{$hQAfC}/";
        goto b14kg;
        rW6fx:
        $teWZs = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto rZDuy;
        KliNU:
        AJU_C:
        goto EpCjH;
        rZDuy:
        try {
            goto hz6pL;
            hz6pL:
            $Pnq0e = $teWZs->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto NESDj;
            Ha0DE:
            $teWZs->sendMessage(['QueueUrl' => $PdPF0, 'MessageBody' => json_encode(['file_path' => $XrW52->getLocation()])]);
            goto CpYdy;
            NESDj:
            $PdPF0 = $Pnq0e->get('QueueUrl');
            goto Ha0DE;
            CpYdy:
        } catch (\Throwable $bhoVz) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$bhoVz->getMessage()}");
        }
        goto KliNU;
        UXf0o:
        Log::info("Use Lambda to generate thumbnail for video: " . $hQAfC);
        goto ZkNO1;
        ZkNO1:
        $XrW52 = WrCq6RmnGcVh7::findOrFail($hQAfC);
        goto es_OP;
        b14kg:
        if (!(!$this->ZN9hu->directoryExists($f_RJe) && empty($XrW52->mRQns5hMdU2()))) {
            goto AJU_C;
        }
        goto rW6fx;
        EpCjH:
    }
    public function mWUwlnrwQqk(string $hQAfC) : void
    {
        goto tSmS9;
        GsLTe:
        throw new \Exception("Message back with success data but not found thumbnail " . $hQAfC);
        goto GtOjP;
        tSmS9:
        $XrW52 = WrCq6RmnGcVh7::findOrFail($hQAfC);
        goto rM5RJ;
        rM5RJ:
        $f_RJe = "v2/hls/thumbnails/{$hQAfC}/";
        goto dTWhB;
        dTWhB:
        if ($this->ZN9hu->directoryExists($f_RJe)) {
            goto u9TQ0;
        }
        goto huOTI;
        GtOjP:
        u9TQ0:
        goto gqJcG;
        wNWzV:
        if (!(count($UZokb) === 0)) {
            goto Swi_s;
        }
        goto ozbM1;
        gqJcG:
        $UZokb = $this->ZN9hu->files($f_RJe);
        goto wNWzV;
        ozbM1:
        Log::error("Message back with success data but not found thumbnail files " . $hQAfC);
        goto xpmC0;
        xpmC0:
        throw new \Exception("Message back with success data but not found thumbnail files " . $hQAfC);
        goto csWIu;
        QgcvN:
        $XrW52->update(['generated_previews' => $f_RJe]);
        goto secos;
        csWIu:
        Swi_s:
        goto QgcvN;
        huOTI:
        Log::error("Message back with success data but not found thumbnail " . $hQAfC);
        goto GsLTe;
        secos:
    }
    public function getThumbnails(string $hQAfC) : array
    {
        $XrW52 = WrCq6RmnGcVh7::findOrFail($hQAfC);
        return $XrW52->getThumbnails();
    }
    public function getMedia(string $hQAfC) : array
    {
        $HO_3Y = Media::findOrFail($hQAfC);
        return $HO_3Y->getView();
    }
}
