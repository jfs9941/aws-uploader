<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\IEfiXfym24wIp;
use Jfs\Uploader\Core\Y5tmWZcWsdzIB;
use Jfs\Uploader\Core\Awxn6mQyQaPNK;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
use Jfs\Uploader\Exception\DQNrWKzuuQ4gB;
use Jfs\Uploader\Exception\Wp4p9VCmIjK6G;
use Jfs\Uploader\Exception\MbrGjey4Z1MjR;
final class ZIwWW145kLPpp implements UploadServiceInterface
{
    private $WqhIW;
    private $OKvrN;
    private $y_rdZ;
    private $VoG37;
    public function __construct(Ti53myCAJIBMS $l_6jf, Filesystem $GiTtn, Filesystem $Cv4pg, string $X1Qp9)
    {
        goto Z6YbE;
        Z6YbE:
        $this->WqhIW = $l_6jf;
        goto DRbiG;
        BN_V4:
        $this->VoG37 = $X1Qp9;
        goto P7A0c;
        DRbiG:
        $this->OKvrN = $GiTtn;
        goto eDDWa;
        eDDWa:
        $this->y_rdZ = $Cv4pg;
        goto BN_V4;
        P7A0c:
    }
    public function storeSingleFile(SingleUploadInterface $PHDxa) : array
    {
        goto iwHsG;
        VvTzH:
        throw new \LogicException('File upload failed, check permissions');
        goto UyVBS;
        E0Ybc:
        $ezBDN->mNT1f7OoTvx(N4CY6qDTBAjPa::UPLOADED);
        goto j4yEC;
        ZGNG5:
        if (false !== $Y7TgX && $ezBDN instanceof IEfiXfym24wIp) {
            goto zLp0b;
        }
        goto VvTzH;
        iwHsG:
        $ezBDN = $this->WqhIW->mJtZyq3Xt3p($PHDxa);
        goto eWh3f;
        eWh3f:
        $Y7TgX = $this->y_rdZ->putFileAs(dirname($ezBDN->getLocation()), $PHDxa->getFile(), $ezBDN->getFilename() . '.' . $ezBDN->getExtension(), ['visibility' => 'public']);
        goto ZGNG5;
        UyVBS:
        goto NI1AT;
        goto gC6Nr;
        j4yEC:
        NI1AT:
        goto Bm6nW;
        Bm6nW:
        return $ezBDN->getView();
        goto gq4x8;
        gC6Nr:
        zLp0b:
        goto E0Ybc;
        gq4x8:
    }
    public function storePreSignedFile(array $z9Ym6)
    {
        goto qQKxl;
        GSWm2:
        return ['filename' => $sqnmv->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $sqnmv->mQYPLqpKYRv()];
        goto EV5So;
        Pcjew:
        $sqnmv->myBIkhgLRk4($z9Ym6['mime'], $z9Ym6['file_size'], $z9Ym6['chunk_size'], $z9Ym6['checksums'], $z9Ym6['user_id'], $z9Ym6['driver']);
        goto VSL39;
        qQKxl:
        $ezBDN = $this->WqhIW->mJtZyq3Xt3p($z9Ym6);
        goto BMqXZ;
        VSL39:
        $sqnmv->mG1W4IroAB2();
        goto GSWm2;
        BMqXZ:
        $sqnmv = Awxn6mQyQaPNK::mvBhEH5MI4h($ezBDN, $this->OKvrN, $this->y_rdZ, $this->VoG37, true);
        goto Pcjew;
        EV5So:
    }
    public function updatePreSignedFile(string $Z5IKY, int $ZKgDf)
    {
        goto SOXOf;
        iFoHx:
        AzwlK:
        goto N3Ol_;
        N7IUJ:
        switch ($ZKgDf) {
            case N4CY6qDTBAjPa::UPLOADED:
                $sqnmv->mS05uU0WwUI();
                goto JXFSc;
            case N4CY6qDTBAjPa::PROCESSING:
                $sqnmv->mtjblsgDS7P();
                goto JXFSc;
            case N4CY6qDTBAjPa::FINISHED:
                $sqnmv->mShQCOziZtK();
                goto JXFSc;
            case N4CY6qDTBAjPa::ABORTED:
                $sqnmv->muYcE6LnfOG();
                goto JXFSc;
        }
        goto iFoHx;
        N3Ol_:
        JXFSc:
        goto MgKyq;
        SOXOf:
        $sqnmv = Awxn6mQyQaPNK::mlonyXM23q3($Z5IKY, $this->OKvrN, $this->y_rdZ, $this->VoG37);
        goto N7IUJ;
        MgKyq:
    }
    public function completePreSignedFile(string $Z5IKY, array $WuWD8)
    {
        goto rOF7v;
        rOF7v:
        $sqnmv = Awxn6mQyQaPNK::mlonyXM23q3($Z5IKY, $this->OKvrN, $this->y_rdZ, $this->VoG37);
        goto Yt_Mx;
        DTvpy:
        return ['path' => $sqnmv->getFile()->getView()['path'], 'thumbnail' => $sqnmv->getFile()->Et6ec, 'id' => $Z5IKY];
        goto i0Uzw;
        Yt_Mx:
        $sqnmv->mdWxraqGvMN()->m26TEtnpzx5($WuWD8);
        goto cjK2z;
        cjK2z:
        $sqnmv->mS05uU0WwUI();
        goto DTvpy;
        i0Uzw:
    }
    public function updateFile(string $Z5IKY, int $ZKgDf) : Y5tmWZcWsdzIB
    {
        goto qrEex;
        S1THN:
        return $ezBDN;
        goto prpFD;
        qrEex:
        $ezBDN = $this->WqhIW->mZLmNe9WEbQ($Z5IKY);
        goto ooYN8;
        ooYN8:
        $ezBDN->mNT1f7OoTvx($ZKgDf);
        goto S1THN;
        prpFD:
    }
}
