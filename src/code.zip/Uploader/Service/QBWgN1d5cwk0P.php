<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Core\TXSCPefqEsBH1;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
final class QBWgN1d5cwk0P implements HqWA5DdMiDW1U
{
    private $UpuDl;
    private $Qr2Z0;
    public $GfO7k;
    private $hkwHL;
    private $iQenW;
    private $P6k4O;
    public function __construct($l_DHA, $ZV00A, $eg6c3, $i0beL, $shNBE, $RNTis)
    {
        goto XiY0T;
        XiY0T:
        $this->P6k4O = $RNTis;
        goto nziTD;
        nziTD:
        $this->UpuDl = $l_DHA;
        goto TBPgZ;
        lltaA:
        $this->iQenW = $shNBE;
        goto WoACk;
        TBPgZ:
        $this->Qr2Z0 = $ZV00A;
        goto MqW6A;
        MqW6A:
        $this->GfO7k = $eg6c3;
        goto XvOLC;
        XvOLC:
        $this->hkwHL = $i0beL;
        goto lltaA;
        WoACk:
    }
    public function resolvePath($UWZG3, $nHjZR = FUIPeZ7ssitYw::S3) : string
    {
        goto TSe_W;
        fCdaV:
        eUZB3:
        goto NeSY4;
        r_Qh0:
        if (!$this->UpuDl) {
            goto bMxnO;
        }
        goto Y381W;
        Y381W:
        return trim($this->GfO7k, '/') . '/' . $UWZG3;
        goto z5xCx;
        dfkXA:
        return $this->mKjQBiNtZFF($UWZG3);
        goto JjsUO;
        AUp8l:
        J0B2g:
        goto n55tX;
        VikRQ:
        return config('upload.home') . '/' . $UWZG3;
        goto fCdaV;
        NeSY4:
        if (!(!empty($this->hkwHL) && !empty($this->iQenW))) {
            goto PTh7Y;
        }
        goto dfkXA;
        TSe_W:
        if (!$UWZG3 instanceof GuA6QuvssLUzf) {
            goto J0B2g;
        }
        goto LrQ1_;
        LrQ1_:
        $UWZG3 = $UWZG3->getAttribute('filename');
        goto AUp8l;
        JjsUO:
        PTh7Y:
        goto r_Qh0;
        z5xCx:
        bMxnO:
        goto UxnON;
        UxnON:
        return trim($this->Qr2Z0, '/') . '/' . $UWZG3;
        goto EH9Ut;
        n55tX:
        if (!($nHjZR === FUIPeZ7ssitYw::LOCAL)) {
            goto eUZB3;
        }
        goto VikRQ;
        EH9Ut:
    }
    public function resolveThumbnail(GuA6QuvssLUzf $UWZG3) : string
    {
        goto PjdS0;
        kAS2G:
        $yDRnE = FNGNxcyxjaxBG::find($UWZG3->getAttribute('thumbnail_id'));
        goto tvl4w;
        qGHN7:
        C0xt0:
        goto y3qSk;
        fIwns:
        s3tQn:
        goto PTQlx;
        xoAeW:
        if (!$UWZG3 instanceof FNGNxcyxjaxBG) {
            goto erIof;
        }
        goto qX_Sx;
        qX_Sx:
        return $this->resolvePath($UWZG3, $UWZG3->getAttribute('driver'));
        goto GzYHa;
        PTQlx:
        return '';
        goto qPpht;
        lshQN:
        return asset('/img/pdf-preview.svg');
        goto fIwns;
        KIwv8:
        if (!$UWZG3 instanceof TXSCPefqEsBH1) {
            goto s3tQn;
        }
        goto lshQN;
        U0SiW:
        EkNrF:
        goto ovS_Z;
        y3qSk:
        if (!$UWZG3->getAttribute('thumbnail_id')) {
            goto qeiBE;
        }
        goto kAS2G;
        cotGS:
        return $this->resolvePath($yDRnE, $yDRnE->getAttribute('driver'));
        goto U0SiW;
        PjdS0:
        $NSw82 = $UWZG3->getAttribute('thumbnail');
        goto Zvszl;
        tvl4w:
        if (!$yDRnE) {
            goto EkNrF;
        }
        goto cotGS;
        zjGmi:
        return $this->url($NSw82, $UWZG3->getAttribute('driver'));
        goto qGHN7;
        Zvszl:
        if (!$NSw82) {
            goto C0xt0;
        }
        goto zjGmi;
        GzYHa:
        erIof:
        goto KIwv8;
        ovS_Z:
        qeiBE:
        goto xoAeW;
        qPpht:
    }
    private function url($JM0UK, $nHjZR)
    {
        goto G8CBY;
        mHrUh:
        return config('upload.home') . '/' . $JM0UK;
        goto MNJ3P;
        vpKLG:
        return $this->resolvePath($JM0UK);
        goto xZ5mo;
        MNJ3P:
        Njdz4:
        goto vpKLG;
        G8CBY:
        if (!($nHjZR == FUIPeZ7ssitYw::LOCAL)) {
            goto Njdz4;
        }
        goto mHrUh;
        xZ5mo:
    }
    private function mKjQBiNtZFF($JM0UK)
    {
        goto r6i0w;
        nEysA:
        XSTpP:
        goto M0slr;
        VWRLk:
        $eT6kv = new UrlSigner($this->hkwHL, $this->P6k4O->path($this->iQenW));
        goto X3vj2;
        TlTLU:
        if (!(strpos($JM0UK, 'm3u8') !== false)) {
            goto XSTpP;
        }
        goto Ukcfp;
        Ukcfp:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto nEysA;
        M0slr:
        $JWtPi = now()->addMinutes(60)->timestamp;
        goto VWRLk;
        X3vj2:
        return $eT6kv->getSignedUrl($this->GfO7k . '/' . $JM0UK, $JWtPi);
        goto KKmr4;
        xkCA6:
        KVQne:
        goto TlTLU;
        cKe3Q:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto xkCA6;
        r6i0w:
        if (!(strpos($JM0UK, 'https://') === 0)) {
            goto KVQne;
        }
        goto cKe3Q;
        KKmr4:
    }
    public function resolvePathForHlsVideo(ACdpgX4YCYP6M $vd5JT, $LC7vn = false) : string
    {
        goto AVlEC;
        AVlEC:
        if ($vd5JT->getAttribute('hls_path')) {
            goto c1Z69;
        }
        goto ZXZUD;
        BX84h:
        c1Z69:
        goto icq8g;
        icq8g:
        return $this->GfO7k . '/' . $vd5JT->getAttribute('hls_path');
        goto CDJ5z;
        ZXZUD:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto BX84h;
        CDJ5z:
    }
    public function resolvePathForHlsVideos()
    {
        goto fmZJO;
        WOn1L:
        $Zj5y_ = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Hb0pl;
        Hb0pl:
        $k2WDv = $Zj5y_->getSignedCookie(['key_pair_id' => $this->hkwHL, 'private_key' => $this->P6k4O->path($this->iQenW), 'policy' => $Ql8QM]);
        goto kw0kC;
        fmZJO:
        $JWtPi = now()->addDays(3)->timestamp;
        goto ygWNM;
        ygWNM:
        $DOOFR = $this->GfO7k . '/v2/hls/';
        goto k113_;
        k113_:
        $Ql8QM = json_encode(['Statement' => [['Resource' => sprintf('%s*', $DOOFR), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $JWtPi]]]]]);
        goto WOn1L;
        kw0kC:
        return [$k2WDv, $JWtPi];
        goto o316_;
        o316_:
    }
}
