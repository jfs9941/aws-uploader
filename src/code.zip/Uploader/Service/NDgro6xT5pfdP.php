<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\B7NusEU08Li4E;
use Jfs\Uploader\Core\Guvqjk2EvHsmF;
use Jfs\Uploader\Core\Hm5kuVZJdTKtj;
use Jfs\Uploader\Enum\KidkTsWIjmNMb;
use Jfs\Uploader\Exception\LDB12Ub0rXHOx;
use Jfs\Uploader\Exception\LFhGkQpjCxWvG;
use Jfs\Uploader\Exception\Eau0ZADkUwi6b;
use Jfs\Uploader\Service\JVjr2CUQxg9ep;
use Illuminate\Contracts\Filesystem\Filesystem;
final class NDgro6xT5pfdP implements UploadServiceInterface
{
    private $WMPCh;
    private $uTYgy;
    private $gG9Jm;
    private $cwPUX;
    public function __construct(JVjr2CUQxg9ep $Jd_qH, Filesystem $kVG4M, Filesystem $crBgX, string $O9ms6)
    {
        goto eBU1U;
        qu951:
        $this->gG9Jm = $crBgX;
        goto qkq9c;
        eBU1U:
        $this->WMPCh = $Jd_qH;
        goto i_LSI;
        qkq9c:
        $this->cwPUX = $O9ms6;
        goto graxY;
        i_LSI:
        $this->uTYgy = $kVG4M;
        goto qu951;
        graxY:
    }
    public function storeSingleFile(SingleUploadInterface $L96Jj) : array
    {
        goto wPhQe;
        vv0mv:
        goto LcAA3;
        goto t7L4k;
        wPhQe:
        $clm2Y = $this->WMPCh->mV2eo5mkU4s($L96Jj);
        goto ur9d4;
        sy5sj:
        throw new \LogicException('File upload failed, check permissions');
        goto vv0mv;
        xrfgK:
        LcAA3:
        goto G8W4E;
        t7L4k:
        qxQ1J:
        goto qb4zu;
        J7jO9:
        if (false !== $uUtRl && $clm2Y instanceof B7NusEU08Li4E) {
            goto qxQ1J;
        }
        goto sy5sj;
        ur9d4:
        $uUtRl = $this->gG9Jm->putFileAs(dirname($clm2Y->getLocation()), $L96Jj->getFile(), $clm2Y->getFilename() . '.' . $clm2Y->getExtension(), ['visibility' => 'public']);
        goto J7jO9;
        qb4zu:
        $clm2Y->mfzy7DteKHJ(KidkTsWIjmNMb::UPLOADED);
        goto xrfgK;
        G8W4E:
        return $clm2Y->getView();
        goto Q2yh_;
        Q2yh_:
    }
    public function storePreSignedFile(array $EO8vH)
    {
        goto KB4o7;
        BNNar:
        $DiwBV = Hm5kuVZJdTKtj::mF4HpoMwsvA($clm2Y, $this->uTYgy, $this->gG9Jm, $this->cwPUX, true);
        goto wSoE2;
        lAdgh:
        $DiwBV->mquAMRxtIy1();
        goto AyJo0;
        wSoE2:
        $DiwBV->mxxDjrcKeAD($EO8vH['mime'], $EO8vH['file_size'], $EO8vH['chunk_size'], $EO8vH['checksums'], $EO8vH['user_id'], $EO8vH['driver']);
        goto lAdgh;
        KB4o7:
        $clm2Y = $this->WMPCh->mV2eo5mkU4s($EO8vH);
        goto BNNar;
        AyJo0:
        return ['filename' => $DiwBV->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $DiwBV->mhxGN0alAfz()];
        goto JyEs_;
        JyEs_:
    }
    public function updatePreSignedFile(string $uuOqF, int $WstHI)
    {
        goto bQ2Th;
        kBRYD:
        UXOzk:
        goto qmf6R;
        b4mPf:
        switch ($WstHI) {
            case KidkTsWIjmNMb::UPLOADED:
                $DiwBV->mvC383jw5Pn();
                goto rD6Fb;
            case KidkTsWIjmNMb::PROCESSING:
                $DiwBV->mNEe3D8nMJc();
                goto rD6Fb;
            case KidkTsWIjmNMb::FINISHED:
                $DiwBV->moi51oZ3ZVJ();
                goto rD6Fb;
            case KidkTsWIjmNMb::ABORTED:
                $DiwBV->mOojEH10uoP();
                goto rD6Fb;
        }
        goto kBRYD;
        qmf6R:
        rD6Fb:
        goto vlvPx;
        bQ2Th:
        $DiwBV = Hm5kuVZJdTKtj::m97qZMsyYLc($uuOqF, $this->uTYgy, $this->gG9Jm, $this->cwPUX);
        goto b4mPf;
        vlvPx:
    }
    public function completePreSignedFile(string $uuOqF, array $M5tou)
    {
        goto V7rEV;
        LJNNa:
        $DiwBV->mvC383jw5Pn();
        goto SMHLg;
        V7rEV:
        $DiwBV = Hm5kuVZJdTKtj::m97qZMsyYLc($uuOqF, $this->uTYgy, $this->gG9Jm, $this->cwPUX);
        goto R8AIq;
        SMHLg:
        return ['path' => $DiwBV->getFile()->getView()['path'], 'thumbnail' => $DiwBV->getFile()->aVfpf, 'id' => $uuOqF];
        goto lNiX1;
        R8AIq:
        $DiwBV->mFV2s6jujmR()->mcm2drtC6xl($M5tou);
        goto LJNNa;
        lNiX1:
    }
    public function updateFile(string $uuOqF, int $WstHI) : Guvqjk2EvHsmF
    {
        goto c3TwZ;
        Wylq7:
        $clm2Y->mfzy7DteKHJ($WstHI);
        goto poinv;
        c3TwZ:
        $clm2Y = $this->WMPCh->mJH7h8hd8oT($uuOqF);
        goto Wylq7;
        poinv:
        return $clm2Y;
        goto J_EkK;
        J_EkK:
    }
}
