<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\FdWrko7bmoI4Y;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class NarZk2mlAS1LS implements VideoPostHandleServiceInterface
{
    private $ZdDAB;
    private $VoF9h;
    public function __construct(UploadServiceInterface $RtkwV, Filesystem $BQ2l1)
    {
        $this->ZdDAB = $RtkwV;
        $this->VoF9h = $BQ2l1;
    }
    public function saveMetadata(string $JTwN4, array $apROX)
    {
        goto nyjog;
        DCTUQ:
        $Ckr3y['resolution'] = $apROX['resolution'];
        goto cudKo;
        P1j2P:
        oa3d3:
        goto GtaBr;
        OfJoG:
        $Ckr3y = [];
        goto csnov;
        hXqlz:
        unset($Ckr3y['thumbnail']);
        goto P1j2P;
        LuxK_:
        if (!$B4_PH->B6Fhn) {
            goto oa3d3;
        }
        goto hXqlz;
        r21Kn:
        Fdcsd:
        goto L9hw7;
        NRtkO:
        $Ckr3y['fps'] = $apROX['fps'];
        goto fIkG8;
        eKerj:
        hpFdU:
        goto L04AR;
        u1tZ4:
        if (!isset($apROX['duration'])) {
            goto hpFdU;
        }
        goto tuv2K;
        MFroG:
        $Ckr3y['thumbnail'] = $apROX['thumbnail_url'];
        goto r21Kn;
        F2vkS:
        if (!isset($apROX['fps'])) {
            goto E6Pog;
        }
        goto NRtkO;
        GtaBr:
        if (!$B4_PH->update($Ckr3y)) {
            goto togCJ;
        }
        goto OyWN4;
        hfRCD:
        $this->ZdDAB->updateFile($B4_PH->getAttribute('id'), FdWrko7bmoI4Y::PROCESSING);
        goto CDcO3;
        xhMb4:
        return $B4_PH->getView();
        goto DEOPd;
        CDcO3:
        Vi55_:
        goto xhMb4;
        csnov:
        if (!isset($apROX['thumbnail_url'])) {
            goto Fdcsd;
        }
        goto MFroG;
        nyjog:
        $B4_PH = MbOYV1VlUGCys::findOrFail($JTwN4);
        goto OfJoG;
        OyWN4:
        if (!(isset($apROX['change_status']) && $apROX['change_status'])) {
            goto Vi55_;
        }
        goto hfRCD;
        hvYNx:
        Log::warning("MbOYV1VlUGCys metadata store failed for unknown reason ... " . $JTwN4);
        goto dA8GC;
        fIkG8:
        E6Pog:
        goto LuxK_;
        tuv2K:
        $Ckr3y['duration'] = $apROX['duration'];
        goto eKerj;
        MUnp_:
        try {
            goto imT3j;
            Qe00n:
            $Ckr3y['thumbnail'] = $fMTw4['filename'];
            goto rx4qW;
            Ti4RN:
            $Ckr3y['thumbnail_id'] = $fMTw4['id'];
            goto Qe00n;
            imT3j:
            $fMTw4 = $this->ZdDAB->storeSingleFile(new class($apROX['thumbnail']) implements SingleUploadInterface
            {
                private $HyWI1;
                public function __construct($hFrf7)
                {
                    $this->HyWI1 = $hFrf7;
                }
                public function getFile()
                {
                    return $this->HyWI1;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Ti4RN;
            rx4qW:
        } catch (\Throwable $tfcsO) {
            Log::warning("MbOYV1VlUGCys thumbnail store failed: " . $tfcsO->getMessage());
        }
        goto JJ4ZF;
        L9hw7:
        if (!isset($apROX['thumbnail'])) {
            goto yE9d2;
        }
        goto MUnp_;
        L04AR:
        if (!isset($apROX['resolution'])) {
            goto QC5Px;
        }
        goto DCTUQ;
        dA8GC:
        throw new \Exception("MbOYV1VlUGCys metadata store failed for unknown reason ... " . $JTwN4);
        goto kpJq1;
        cudKo:
        QC5Px:
        goto F2vkS;
        JJ4ZF:
        yE9d2:
        goto u1tZ4;
        DEOPd:
        togCJ:
        goto hvYNx;
        kpJq1:
    }
    public function createThumbnail(string $ufjUS) : void
    {
        goto Nl9IQ;
        taLTM:
        $B4_PH = MbOYV1VlUGCys::findOrFail($ufjUS);
        goto MLHNR;
        DzLOn:
        yc2SS:
        goto jK662;
        yjHbN:
        try {
            goto DUOvB;
            GvKjH:
            $ZxVR4 = $g2kAu->get('QueueUrl');
            goto KfS5v;
            DUOvB:
            $g2kAu = $rF7H9->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto GvKjH;
            KfS5v:
            $rF7H9->sendMessage(['QueueUrl' => $ZxVR4, 'MessageBody' => json_encode(['file_path' => $B4_PH->getLocation()])]);
            goto lFZxs;
            lFZxs:
        } catch (\Throwable $QtemZ) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$QtemZ->getMessage()}");
        }
        goto DzLOn;
        PL0he:
        $rF7H9 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto yjHbN;
        Nl9IQ:
        Log::info("Use Lambda to generate thumbnail for video: " . $ufjUS);
        goto taLTM;
        U7Jcl:
        if (!(!$this->VoF9h->directoryExists($k8q_U) && empty($B4_PH->meAUtXAL5iT()))) {
            goto yc2SS;
        }
        goto PL0he;
        MLHNR:
        $k8q_U = "v2/hls/thumbnails/{$ufjUS}/";
        goto U7Jcl;
        jK662:
    }
    public function mmsPwUTFsgS(string $ufjUS) : void
    {
        goto OXhVx;
        tWamf:
        $B4_PH->update(['generated_previews' => $k8q_U]);
        goto v4GKU;
        ME_7m:
        if (!(count($AKGYB) === 0)) {
            goto DHXhn;
        }
        goto Outpw;
        YTRMA:
        throw new \Exception("Message back with success data but not found thumbnail files " . $ufjUS);
        goto U2PCf;
        i8ytR:
        throw new \Exception("Message back with success data but not found thumbnail " . $ufjUS);
        goto keEOc;
        bZC0d:
        $AKGYB = $this->VoF9h->files($k8q_U);
        goto ME_7m;
        ZhS9o:
        $k8q_U = "v2/hls/thumbnails/{$ufjUS}/";
        goto XFEIZ;
        keEOc:
        u0dRk:
        goto bZC0d;
        P3BNq:
        Log::error("Message back with success data but not found thumbnail " . $ufjUS);
        goto i8ytR;
        OXhVx:
        $B4_PH = MbOYV1VlUGCys::findOrFail($ufjUS);
        goto ZhS9o;
        XFEIZ:
        if ($this->VoF9h->directoryExists($k8q_U)) {
            goto u0dRk;
        }
        goto P3BNq;
        U2PCf:
        DHXhn:
        goto tWamf;
        Outpw:
        Log::error("Message back with success data but not found thumbnail files " . $ufjUS);
        goto YTRMA;
        v4GKU:
    }
    public function getThumbnails(string $ufjUS) : array
    {
        $B4_PH = MbOYV1VlUGCys::findOrFail($ufjUS);
        return $B4_PH->getThumbnails();
    }
    public function getMedia(string $ufjUS) : array
    {
        $p0I5F = Media::findOrFail($ufjUS);
        return $p0I5F->getView();
    }
}
