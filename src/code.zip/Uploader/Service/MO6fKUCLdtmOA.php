<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Core\Mty95KsoNkhJl;
use Jfs\Uploader\Core\ED7I8bwNqdusd;
use Jfs\Uploader\Enum\Fsm7WCrUwVWh9;
use Jfs\Uploader\Exception\Vfh0JNvlNsuXG;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Exception\Ki9g9bsseJGaK;
use Jfs\Uploader\Service\G0pnBs62axPuz;
use Illuminate\Contracts\Filesystem\Filesystem;
final class MO6fKUCLdtmOA implements UploadServiceInterface
{
    private $qfdmm;
    private $qqmnq;
    private $iIDXy;
    private $xfVPn;
    public function __construct(G0pnBs62axPuz $nUogw, Filesystem $vS8UC, Filesystem $vKILS, string $Kyvst)
    {
        goto Ivzsz;
        yBTL5:
        $this->iIDXy = $vKILS;
        goto Z4udE;
        i6qc8:
        $this->qqmnq = $vS8UC;
        goto yBTL5;
        Z4udE:
        $this->xfVPn = $Kyvst;
        goto SNgte;
        Ivzsz:
        $this->qfdmm = $nUogw;
        goto i6qc8;
        SNgte:
    }
    public function storeSingleFile(SingleUploadInterface $PqTH7) : array
    {
        goto EYwzO;
        oPr4M:
        throw new \LogicException('File upload failed, check permissions');
        goto ydKUw;
        EYwzO:
        $RB3Ub = $this->qfdmm->mmjnDwnp1Ap($PqTH7);
        goto E3wKh;
        lAxpF:
        VUEzu:
        goto DbRys;
        DbRys:
        return $RB3Ub->getView();
        goto gom2n;
        hSDgO:
        CNKVR:
        goto QwehN;
        QwehN:
        $RB3Ub->mtyCvJ3PeFW(Fsm7WCrUwVWh9::UPLOADED);
        goto lAxpF;
        ydKUw:
        goto VUEzu;
        goto hSDgO;
        yej0H:
        if (false !== $iTIh6 && $RB3Ub instanceof WZhCwGsxQbxug) {
            goto CNKVR;
        }
        goto oPr4M;
        E3wKh:
        $iTIh6 = $this->iIDXy->putFileAs(dirname($RB3Ub->getLocation()), $PqTH7->getFile(), $RB3Ub->getFilename() . '.' . $RB3Ub->getExtension(), ['visibility' => 'public']);
        goto yej0H;
        gom2n:
    }
    public function storePreSignedFile(array $i_UvC)
    {
        goto c07Uj;
        mXnFc:
        $lJ5H4->mXxX3rLJeae($i_UvC['mime'], $i_UvC['file_size'], $i_UvC['chunk_size'], $i_UvC['checksums'], $i_UvC['user_id'], $i_UvC['driver']);
        goto Nx431;
        Nx431:
        $lJ5H4->mHHfX0Ii621();
        goto bqneG;
        bqneG:
        return ['filename' => $lJ5H4->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $lJ5H4->meYr1FY5Tzr()];
        goto Jd5kk;
        KVRaW:
        $lJ5H4 = ED7I8bwNqdusd::mQ0StC5mkdO($RB3Ub, $this->qqmnq, $this->iIDXy, $this->xfVPn, true);
        goto mXnFc;
        c07Uj:
        $RB3Ub = $this->qfdmm->mmjnDwnp1Ap($i_UvC);
        goto KVRaW;
        Jd5kk:
    }
    public function updatePreSignedFile(string $kIF2h, int $lw9P6)
    {
        goto KjMk2;
        KjMk2:
        $lJ5H4 = ED7I8bwNqdusd::mWTo7Ll57d8($kIF2h, $this->qqmnq, $this->iIDXy, $this->xfVPn);
        goto bV9_R;
        bV9_R:
        switch ($lw9P6) {
            case Fsm7WCrUwVWh9::UPLOADED:
                $lJ5H4->m7ADqcvZTcv();
                goto As1Qz;
            case Fsm7WCrUwVWh9::PROCESSING:
                $lJ5H4->mnY0ADZFWtN();
                goto As1Qz;
            case Fsm7WCrUwVWh9::FINISHED:
                $lJ5H4->mWH9dIalKQo();
                goto As1Qz;
            case Fsm7WCrUwVWh9::ABORTED:
                $lJ5H4->mNHCFjdXofT();
                goto As1Qz;
        }
        goto difpB;
        difpB:
        dEr17:
        goto KT6Mh;
        KT6Mh:
        As1Qz:
        goto TeCkS;
        TeCkS:
    }
    public function completePreSignedFile(string $kIF2h, array $zO8GR)
    {
        goto zJbi5;
        zJbi5:
        $lJ5H4 = ED7I8bwNqdusd::mWTo7Ll57d8($kIF2h, $this->qqmnq, $this->iIDXy, $this->xfVPn);
        goto Xdjes;
        VGqlL:
        return ['path' => $lJ5H4->getFile()->getView()['path'], 'thumbnail' => $lJ5H4->getFile()->LWDKv, 'id' => $kIF2h];
        goto W1PgI;
        Xdjes:
        $lJ5H4->mvHStueAWqd()->mxcZy8PDib7($zO8GR);
        goto uSzcI;
        uSzcI:
        $lJ5H4->m7ADqcvZTcv();
        goto VGqlL;
        W1PgI:
    }
    public function updateFile(string $kIF2h, int $lw9P6) : Mty95KsoNkhJl
    {
        goto oaopJ;
        KpNch:
        $RB3Ub->mtyCvJ3PeFW($lw9P6);
        goto ZEaRl;
        ZEaRl:
        return $RB3Ub;
        goto qDUYF;
        oaopJ:
        $RB3Ub = $this->qfdmm->miU2tSnkH6P($kIF2h);
        goto KpNch;
        qDUYF:
    }
}
