<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\BbauDy0pIbj64;
use Jfs\Uploader\Core\KhQ4OQYybZ7Vk;
use Jfs\Uploader\Core\VhdgLYFn8a0ds;
use Jfs\Uploader\Enum\MUu80sOhINyO3;
use Jfs\Uploader\Exception\KlKPTBnDHVeRD;
use Jfs\Uploader\Exception\AsUdPM9ttxh6c;
use Jfs\Uploader\Exception\VTCsTRR34DAEZ;
use Jfs\Uploader\Service\PwjTg62cqDtZB;
use Illuminate\Contracts\Filesystem\Filesystem;
final class ZbWSSLhlYKy4u implements UploadServiceInterface
{
    private $zMtP2;
    private $IA8m0;
    private $mzEj7;
    private $Pz4fV;
    public function __construct(PwjTg62cqDtZB $zKHN7, Filesystem $Rgxn3, Filesystem $z6qdY, string $zm3ED)
    {
        goto ur8lY;
        ur8lY:
        $this->zMtP2 = $zKHN7;
        goto t41Db;
        U9isy:
        $this->Pz4fV = $zm3ED;
        goto o3ivM;
        t41Db:
        $this->IA8m0 = $Rgxn3;
        goto YEm1D;
        YEm1D:
        $this->mzEj7 = $z6qdY;
        goto U9isy;
        o3ivM:
    }
    public function storeSingleFile(SingleUploadInterface $lNZ2p) : array
    {
        goto dYxRS;
        YmYWi:
        throw new \LogicException('File upload failed, check permissions');
        goto pFCw_;
        xAtpj:
        $FlxOy = $this->mzEj7->putFileAs(dirname($eQ4Ln->getLocation()), $lNZ2p->getFile(), $eQ4Ln->getFilename() . '.' . $eQ4Ln->getExtension(), ['visibility' => 'public']);
        goto q9Gxq;
        QATw5:
        $eQ4Ln->mG7ZLOSfPOQ(MUu80sOhINyO3::UPLOADED);
        goto Vrn07;
        dYxRS:
        $eQ4Ln = $this->zMtP2->mLYT9Dr0S76($lNZ2p);
        goto xAtpj;
        lRv41:
        ua_7B:
        goto QATw5;
        q9Gxq:
        if (false !== $FlxOy && $eQ4Ln instanceof BbauDy0pIbj64) {
            goto ua_7B;
        }
        goto YmYWi;
        Vrn07:
        R3lmA:
        goto OEMeq;
        pFCw_:
        goto R3lmA;
        goto lRv41;
        OEMeq:
        return $eQ4Ln->getView();
        goto t4LI1;
        t4LI1:
    }
    public function storePreSignedFile(array $Oj_IY)
    {
        goto vUH5X;
        x36XA:
        $Fr4mD = VhdgLYFn8a0ds::mzj7ofubaMq($eQ4Ln, $this->IA8m0, $this->mzEj7, $this->Pz4fV, true);
        goto jFrKl;
        bfUl7:
        $Fr4mD->m8aUqROEDGc();
        goto u3_Lp;
        vUH5X:
        $eQ4Ln = $this->zMtP2->mLYT9Dr0S76($Oj_IY);
        goto x36XA;
        u3_Lp:
        return ['filename' => $Fr4mD->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $Fr4mD->mgj2km2k8NC()];
        goto N6v7O;
        jFrKl:
        $Fr4mD->maYcy0QKzJE($Oj_IY['mime'], $Oj_IY['file_size'], $Oj_IY['chunk_size'], $Oj_IY['checksums'], $Oj_IY['user_id'], $Oj_IY['driver']);
        goto bfUl7;
        N6v7O:
    }
    public function updatePreSignedFile(string $kLFNR, int $F_6r0)
    {
        goto aPHBG;
        as7PU:
        YTM5p:
        goto go4ZF;
        aPHBG:
        $Fr4mD = VhdgLYFn8a0ds::mboVEfx7koj($kLFNR, $this->IA8m0, $this->mzEj7, $this->Pz4fV);
        goto SYy4M;
        go4ZF:
        D6Sjc:
        goto W3U15;
        SYy4M:
        switch ($F_6r0) {
            case MUu80sOhINyO3::UPLOADED:
                $Fr4mD->moAD0rX8JZT();
                goto D6Sjc;
            case MUu80sOhINyO3::PROCESSING:
                $Fr4mD->mJg0jPE5Pwv();
                goto D6Sjc;
            case MUu80sOhINyO3::FINISHED:
                $Fr4mD->memZgKrrsgW();
                goto D6Sjc;
            case MUu80sOhINyO3::ABORTED:
                $Fr4mD->mWZjTDDlJBZ();
                goto D6Sjc;
        }
        goto as7PU;
        W3U15:
    }
    public function completePreSignedFile(string $kLFNR, array $qwLXm)
    {
        goto eHAMz;
        HzRLC:
        $Fr4mD->mMYcEvkVSg5()->mjoM4ZDVVFf($qwLXm);
        goto hvU3S;
        nbeob:
        return ['path' => $Fr4mD->getFile()->getView()['path'], 'thumbnail' => $Fr4mD->getFile()->wVPkg, 'id' => $kLFNR];
        goto LQnis;
        hvU3S:
        $Fr4mD->moAD0rX8JZT();
        goto nbeob;
        eHAMz:
        $Fr4mD = VhdgLYFn8a0ds::mboVEfx7koj($kLFNR, $this->IA8m0, $this->mzEj7, $this->Pz4fV);
        goto HzRLC;
        LQnis:
    }
    public function updateFile(string $kLFNR, int $F_6r0) : KhQ4OQYybZ7Vk
    {
        goto kz4yO;
        PCukQ:
        $eQ4Ln->mG7ZLOSfPOQ($F_6r0);
        goto MbpND;
        kz4yO:
        $eQ4Ln = $this->zMtP2->m8Yz5AURItB($kLFNR);
        goto PCukQ;
        MbpND:
        return $eQ4Ln;
        goto P7AZz;
        P7AZz:
    }
}
