<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Core\Observer\AwMOzStxKOie9;
use Jfs\Uploader\Core\Observer\TeFjie1JxTTn2;
use Jfs\Uploader\Core\SK0zQTH7YFzcx;
use Jfs\Uploader\Core\ZCG0C7zP3e4el;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Exception\TLy3l2bn56lcq;
use Jfs\Uploader\Service\FileResolver\Xy3vRB2WznbRN;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class XaaDhpdqTL9N3
{
    private $BNAZM;
    private $q6zCU;
    private $aiw3M;
    public function __construct($Iriij, $zDbHT, $iay5S)
    {
        goto L4ERK;
        L4ERK:
        $this->BNAZM = $Iriij;
        goto Q_72V;
        Q_72V:
        $this->q6zCU = $zDbHT;
        goto B1Ry7;
        B1Ry7:
        $this->aiw3M = $iay5S;
        goto VgpTw;
        VgpTw:
    }
    public function mDWXGQfZ7p1($WEMKz)
    {
        goto iFUPS;
        lffck:
        return $this->mW49FEr0gHV($hSylV->extension(), X4ZiOQdPeeHKI::S3, null, $WEMKz->options());
        goto OHF6l;
        u951a:
        $hSylV = $WEMKz->getFile();
        goto lffck;
        iFUPS:
        if (!$WEMKz instanceof SingleUploadInterface) {
            goto zWXs2;
        }
        goto u951a;
        KEfc_:
        return $this->mW49FEr0gHV($WEMKz['file_extension'], 's3' === $WEMKz['driver'] ? X4ZiOQdPeeHKI::S3 : X4ZiOQdPeeHKI::LOCAL);
        goto W2V1G;
        OHF6l:
        zWXs2:
        goto KEfc_;
        W2V1G:
    }
    public function mqtjUnfOvTD(string $zV1kl)
    {
        goto N_BAA;
        N_BAA:
        $sLwwk = config('upload.attachment_model')::findOrFail($zV1kl);
        goto P7v2h;
        P7v2h:
        $Z5ydB = $this->mW49FEr0gHV($sLwwk->getAttribute('type'), $sLwwk->getAttribute('driver'), $sLwwk->getAttribute('id'));
        goto eTAzu;
        erArt:
        return $Z5ydB;
        goto gEDvb;
        rlClc:
        $Z5ydB->setRawAttributes($sLwwk->getAttributes());
        goto erArt;
        eTAzu:
        $Z5ydB->exists = true;
        goto rlClc;
        gEDvb:
    }
    public function mKop8RuHqqs(string $V259Y) : Fk274vNY0LJnp
    {
        goto ZhdXQ;
        ajUX4:
        return $this->mW49FEr0gHV($ETZZ7->h9ixw, $ETZZ7->mphSn0us0TW(), $ETZZ7->filename);
        goto ZeFAz;
        Fd5MO:
        cfvKH:
        goto Ii27S;
        ysJ7W:
        if (!$OFuou) {
            goto RIQUJ;
        }
        goto uaF11;
        CyHHD:
        if ($O2RSG) {
            goto cfvKH;
        }
        goto H0hkN;
        ZhdXQ:
        $O2RSG = $this->q6zCU->get($V259Y);
        goto CyHHD;
        H0hkN:
        $O2RSG = $this->aiw3M->get($V259Y);
        goto Fd5MO;
        ZeFAz:
        RIQUJ:
        goto hdhQB;
        hdhQB:
        throw new SLsozGEgkOpxH('metadata file not found');
        goto EugWz;
        uaF11:
        $ETZZ7 = ZCG0C7zP3e4el::mPUATnUONu9($OFuou);
        goto ajUX4;
        Ii27S:
        $OFuou = json_decode($O2RSG, true);
        goto ysJ7W;
        EugWz:
    }
    private function mW49FEr0gHV(string $DNpTL, $xOqSj, ?string $zV1kl = null, array $sUzkn = [])
    {
        goto Dqeft;
        D1fpD:
        K9yt4:
        goto cpTWh;
        KMBf7:
        $Ab9PW->m3qxyKjPsWx(new TeFjie1JxTTn2($Ab9PW, $this->aiw3M, $sUzkn));
        goto sbI_2;
        AosU7:
        On4AK:
        goto w1beG;
        bBvQ8:
        $Ab9PW = $Ab9PW->mjVGv2JTN8s($xOqSj);
        goto JjcN7;
        sbI_2:
        foreach ($this->BNAZM as $T7Fli) {
            goto WvOMD;
            knlLN:
            sIn8e:
            goto LjoD3;
            WvOMD:
            if (!$T7Fli->m5fbxzyNLYU($Ab9PW)) {
                goto sIn8e;
            }
            goto WkPQx;
            LjoD3:
            HdFOt:
            goto peSJa;
            WkPQx:
            return $Ab9PW->initLocation($T7Fli->mt5gIDk9pzn($Ab9PW));
            goto knlLN;
            peSJa:
        }
        goto AosU7;
        JpZ5K:
        switch ($DNpTL) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $Ab9PW = KCmQR4pvm0dT3::createFromScratch($zV1kl, $DNpTL);
                goto aS1MP;
            case 'mp4':
            case 'mov':
                $Ab9PW = UYo98bF5lKEmO::createFromScratch($zV1kl, $DNpTL);
                goto aS1MP;
            case 'pdf':
                $Ab9PW = SK0zQTH7YFzcx::createFromScratch($zV1kl, $DNpTL);
                goto aS1MP;
            default:
                throw new TLy3l2bn56lcq("not support file type {$DNpTL}");
        }
        goto D1fpD;
        w1beG:
        throw new TLy3l2bn56lcq("not support file type {$DNpTL}");
        goto hxRRI;
        Dqeft:
        $zV1kl = $zV1kl ?? Uuid::uuid4()->getHex()->toString();
        goto JpZ5K;
        JjcN7:
        $Ab9PW->m3qxyKjPsWx(new AwMOzStxKOie9($Ab9PW));
        goto KMBf7;
        cpTWh:
        aS1MP:
        goto bBvQ8;
        hxRRI:
    }
}
