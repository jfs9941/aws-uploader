<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\WSEQ88VDOa3X0;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class SSpFOwqWBwfrA implements VideoPostHandleServiceInterface
{
    private $E71oj;
    private $iHPgt;
    public function __construct(UploadServiceInterface $owpm8, Filesystem $zeM4q)
    {
        $this->E71oj = $owpm8;
        $this->iHPgt = $zeM4q;
    }
    public function saveMetadata(string $tu00C, array $V5lrw)
    {
        goto dSWTo;
        MC8Qv:
        $ykdpf['fps'] = $V5lrw['fps'];
        goto ce5zn;
        LbFhu:
        unset($ykdpf['thumbnail']);
        goto RUqv7;
        abb7e:
        if (!(isset($V5lrw['change_status']) && $V5lrw['change_status'])) {
            goto Lcj5a;
        }
        goto zkFUh;
        CElba:
        QaUaP:
        goto FnB4D;
        aONbl:
        try {
            goto GJroG;
            GJroG:
            $iSeOK = $this->E71oj->storeSingleFile(new class($V5lrw['thumbnail']) implements SingleUploadInterface
            {
                private $iN_s5;
                public function __construct($bwI0g)
                {
                    $this->iN_s5 = $bwI0g;
                }
                public function getFile()
                {
                    return $this->iN_s5;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Sllh4;
            ph3lS:
            $ykdpf['thumbnail'] = $iSeOK['filename'];
            goto tM1bq;
            Sllh4:
            $ykdpf['thumbnail_id'] = $iSeOK['id'];
            goto ph3lS;
            tM1bq:
        } catch (\Throwable $OaHp2) {
            Log::warning("SNpic2wzC1yT8 thumbnail store failed: " . $OaHp2->getMessage());
        }
        goto OYrFc;
        HH7uR:
        Lcj5a:
        goto c9q1J;
        V2V_N:
        if (!isset($V5lrw['thumbnail'])) {
            goto oqlmZ;
        }
        goto aONbl;
        z62UN:
        $ykdpf = [];
        goto L9Z6O;
        DWmpu:
        Pc2hJ:
        goto V2V_N;
        ce5zn:
        Pe2Rr:
        goto SLiI_;
        dXXHQ:
        $ykdpf['duration'] = $V5lrw['duration'];
        goto l5hzR;
        I7eEM:
        throw new \Exception("SNpic2wzC1yT8 metadata store failed for unknown reason ... " . $tu00C);
        goto DNF8X;
        TU4GD:
        $ykdpf['resolution'] = $V5lrw['resolution'];
        goto CElba;
        rgG9i:
        if (!$fxrDr->update($ykdpf)) {
            goto vGmUx;
        }
        goto abb7e;
        COPNR:
        if (!isset($V5lrw['resolution'])) {
            goto QaUaP;
        }
        goto TU4GD;
        FnB4D:
        if (!isset($V5lrw['fps'])) {
            goto Pe2Rr;
        }
        goto MC8Qv;
        l5hzR:
        mT6LS:
        goto COPNR;
        RUqv7:
        aJUXo:
        goto rgG9i;
        SLiI_:
        if (!$fxrDr->zeJHK) {
            goto aJUXo;
        }
        goto LbFhu;
        eamXb:
        if (!isset($V5lrw['duration'])) {
            goto mT6LS;
        }
        goto dXXHQ;
        nU2kk:
        Log::warning("SNpic2wzC1yT8 metadata store failed for unknown reason ... " . $tu00C);
        goto I7eEM;
        g3hK8:
        $ykdpf['thumbnail'] = $V5lrw['thumbnail_url'];
        goto DWmpu;
        L9Z6O:
        if (!isset($V5lrw['thumbnail_url'])) {
            goto Pc2hJ;
        }
        goto g3hK8;
        dSWTo:
        $fxrDr = SNpic2wzC1yT8::findOrFail($tu00C);
        goto z62UN;
        OYrFc:
        oqlmZ:
        goto eamXb;
        brg54:
        vGmUx:
        goto nU2kk;
        c9q1J:
        return $fxrDr->getView();
        goto brg54;
        zkFUh:
        $this->E71oj->updateFile($fxrDr->getAttribute('id'), WSEQ88VDOa3X0::PROCESSING);
        goto HH7uR;
        DNF8X:
    }
    public function createThumbnail(string $Q4iyS) : void
    {
        goto d5EyD;
        cOCYN:
        tDwRR:
        goto YgNBj;
        d5EyD:
        Log::info("Use Lambda to generate thumbnail for video: " . $Q4iyS);
        goto kADHA;
        kADHA:
        $fxrDr = SNpic2wzC1yT8::findOrFail($Q4iyS);
        goto hNsVw;
        mn58M:
        try {
            goto sUQc4;
            UPPOm:
            $Ao1x0->sendMessage(['QueueUrl' => $auQFM, 'MessageBody' => json_encode(['file_path' => $fxrDr->getLocation()])]);
            goto b5_n1;
            zQqhi:
            $auQFM = $T0iAQ->get('QueueUrl');
            goto UPPOm;
            sUQc4:
            $T0iAQ = $Ao1x0->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto zQqhi;
            b5_n1:
        } catch (\Throwable $hBzBz) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$hBzBz->getMessage()}");
        }
        goto cOCYN;
        lGb4b:
        if (!(!$this->iHPgt->directoryExists($FS81q) && empty($fxrDr->mCiKNgvmk5J()))) {
            goto tDwRR;
        }
        goto yLy7H;
        yLy7H:
        $Ao1x0 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto mn58M;
        hNsVw:
        $FS81q = "v2/hls/thumbnails/{$Q4iyS}/";
        goto lGb4b;
        YgNBj:
    }
    public function m4fSQUMEo17(string $Q4iyS) : void
    {
        goto hMID0;
        yQggg:
        $EKpu2 = $this->iHPgt->files($FS81q);
        goto Ynpw_;
        wMZNq:
        SitqN:
        goto lW9A7;
        cCmTM:
        $FS81q = "v2/hls/thumbnails/{$Q4iyS}/";
        goto tjcGH;
        Ynpw_:
        if (!(count($EKpu2) === 0)) {
            goto SitqN;
        }
        goto BtgNE;
        aaxra:
        throw new \Exception("Message back with success data but not found thumbnail " . $Q4iyS);
        goto S6Ou1;
        UOpOp:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Q4iyS);
        goto wMZNq;
        BtgNE:
        Log::error("Message back with success data but not found thumbnail files " . $Q4iyS);
        goto UOpOp;
        tjcGH:
        if ($this->iHPgt->directoryExists($FS81q)) {
            goto nYeez;
        }
        goto tT7uM;
        hMID0:
        $fxrDr = SNpic2wzC1yT8::findOrFail($Q4iyS);
        goto cCmTM;
        S6Ou1:
        nYeez:
        goto yQggg;
        tT7uM:
        Log::error("Message back with success data but not found thumbnail " . $Q4iyS);
        goto aaxra;
        lW9A7:
        $fxrDr->update(['generated_previews' => $FS81q]);
        goto aCADh;
        aCADh:
    }
    public function getThumbnails(string $Q4iyS) : array
    {
        $fxrDr = SNpic2wzC1yT8::findOrFail($Q4iyS);
        return $fxrDr->getThumbnails();
    }
    public function getMedia(string $Q4iyS) : array
    {
        $I80en = Media::findOrFail($Q4iyS);
        return $I80en->getView();
    }
}
