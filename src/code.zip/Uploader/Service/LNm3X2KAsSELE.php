<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\GuNvSDjrDhnZX;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Core\WLv4xzk21eiAP;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\DccywYjigTakI;
final class LNm3X2KAsSELE implements GuNvSDjrDhnZX
{
    private $toCgH;
    private $l6_v4;
    public $BTKoQ;
    private $sApFE;
    private $MRxps;
    private $mzObC;
    public function __construct($Z3tvj, $g8d2J, $wmYab, $IEo2R, $ose1f, $L1VX0)
    {
        goto c5NUg;
        S2CPa:
        $this->sApFE = $IEo2R;
        goto bYBzL;
        c5NUg:
        $this->mzObC = $L1VX0;
        goto YFKNO;
        jnHaK:
        $this->BTKoQ = $wmYab;
        goto S2CPa;
        YFKNO:
        $this->toCgH = $Z3tvj;
        goto Bui5K;
        bYBzL:
        $this->MRxps = $ose1f;
        goto I5T_b;
        Bui5K:
        $this->l6_v4 = $g8d2J;
        goto jnHaK;
        I5T_b:
    }
    public function resolvePath($wiCE2, $XHDhR = DccywYjigTakI::S3) : string
    {
        goto Fdlel;
        Xw1zh:
        fBK_W:
        goto EICgg;
        erV03:
        return trim($this->BTKoQ, '/') . '/' . $wiCE2;
        goto Xw1zh;
        ylcco:
        if (!($XHDhR === DccywYjigTakI::LOCAL)) {
            goto IZA7k;
        }
        goto JSqrF;
        A4VLf:
        BCuo4:
        goto IuKDj;
        EICgg:
        return trim($this->l6_v4, '/') . '/' . $wiCE2;
        goto OeDxQ;
        Fdlel:
        if (!$wiCE2 instanceof KFe2ZCctciwsA) {
            goto GOYgs;
        }
        goto VTxgp;
        JSqrF:
        return config('upload.home') . '/' . $wiCE2;
        goto j3ylk;
        VTxgp:
        $wiCE2 = $wiCE2->getAttribute('filename');
        goto zlKcv;
        zlKcv:
        GOYgs:
        goto ylcco;
        IuKDj:
        if (!$this->toCgH) {
            goto fBK_W;
        }
        goto erV03;
        krTzx:
        return $this->m9PDpDljJXm($wiCE2);
        goto A4VLf;
        j3ylk:
        IZA7k:
        goto ouKhq;
        ouKhq:
        if (!(!empty($this->sApFE) && !empty($this->MRxps))) {
            goto BCuo4;
        }
        goto krTzx;
        OeDxQ:
    }
    public function resolveThumbnail(KFe2ZCctciwsA $wiCE2) : string
    {
        goto oSODv;
        oSODv:
        $cOdCv = $wiCE2->getAttribute('thumbnail');
        goto oWmPL;
        lQr4T:
        if (!$OZg23) {
            goto Vdfma;
        }
        goto XXyXW;
        L98Pe:
        ZBMmk:
        goto LB7Dj;
        Zluzu:
        if (!$wiCE2->getAttribute('thumbnail_id')) {
            goto ZBMmk;
        }
        goto di0To;
        gwJ6h:
        return $this->url($cOdCv, $wiCE2->getAttribute('driver'));
        goto qoVCK;
        Yw_xJ:
        STd1s:
        goto a6y9E;
        di0To:
        $OZg23 = XK5kReLMTU1ob::find($wiCE2->getAttribute('thumbnail_id'));
        goto lQr4T;
        XXyXW:
        return $this->resolvePath($OZg23, $OZg23->getAttribute('driver'));
        goto KUP9K;
        KUP9K:
        Vdfma:
        goto L98Pe;
        hdsRG:
        return $this->resolvePath($wiCE2, $wiCE2->getAttribute('driver'));
        goto ElGpq;
        KmpFC:
        if (!$wiCE2 instanceof WLv4xzk21eiAP) {
            goto STd1s;
        }
        goto pilbl;
        pilbl:
        return asset('/img/pdf-preview.svg');
        goto Yw_xJ;
        LB7Dj:
        if (!$wiCE2 instanceof XK5kReLMTU1ob) {
            goto i7cSL;
        }
        goto hdsRG;
        oWmPL:
        if (!$cOdCv) {
            goto n5HgI;
        }
        goto gwJ6h;
        qoVCK:
        n5HgI:
        goto Zluzu;
        a6y9E:
        return '';
        goto F3fY6;
        ElGpq:
        i7cSL:
        goto KmpFC;
        F3fY6:
    }
    private function url($hU2b_, $XHDhR)
    {
        goto MFWKS;
        MFWKS:
        if (!($XHDhR == DccywYjigTakI::LOCAL)) {
            goto kgW_U;
        }
        goto IDz3f;
        IDz3f:
        return config('upload.home') . '/' . $hU2b_;
        goto SnlI3;
        SnlI3:
        kgW_U:
        goto qps1g;
        qps1g:
        return $this->resolvePath($hU2b_);
        goto X_uNW;
        X_uNW:
    }
    private function m9PDpDljJXm($hU2b_)
    {
        goto Q180D;
        KY26j:
        rYEVw:
        goto LiJlL;
        CryqQ:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto KY26j;
        WmBQK:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto aPuMq;
        rG9N3:
        $znjVe = new UrlSigner($this->sApFE, $this->mzObC->path($this->MRxps));
        goto c8j9Y;
        Q180D:
        if (!(strpos($hU2b_, 'https://') === 0)) {
            goto xQWTX;
        }
        goto WmBQK;
        LiJlL:
        $NPI6C = now()->addMinutes(60)->timestamp;
        goto rG9N3;
        c8j9Y:
        return $znjVe->getSignedUrl($this->BTKoQ . '/' . $hU2b_, $NPI6C);
        goto WlSbv;
        KB877:
        if (!(strpos($hU2b_, 'm3u8') !== false)) {
            goto rYEVw;
        }
        goto CryqQ;
        aPuMq:
        xQWTX:
        goto KB877;
        WlSbv:
    }
    public function resolvePathForHlsVideo(BG2FRpwGrKqJx $Zpy0I, $g95hj = false) : string
    {
        goto IXWhd;
        jEsL3:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto PvguR;
        gZ9Bg:
        return $this->BTKoQ . '/' . $Zpy0I->getAttribute('hls_path');
        goto z1dJi;
        PvguR:
        lApoX:
        goto gZ9Bg;
        IXWhd:
        if ($Zpy0I->getAttribute('hls_path')) {
            goto lApoX;
        }
        goto jEsL3;
        z1dJi:
    }
    public function resolvePathForHlsVideos()
    {
        goto AN2t2;
        QkW4E:
        $MZipT = json_encode(['Statement' => [['Resource' => sprintf('%s*', $Ux2D0), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $NPI6C]]]]]);
        goto DVzKW;
        DVzKW:
        $oRHDF = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Z8cdM;
        Z8cdM:
        $KklhX = $oRHDF->getSignedCookie(['key_pair_id' => $this->sApFE, 'private_key' => $this->mzObC->path($this->MRxps), 'policy' => $MZipT]);
        goto JC30o;
        JC30o:
        return [$KklhX, $NPI6C];
        goto EG9Ky;
        QwEfZ:
        $Ux2D0 = $this->BTKoQ . '/v2/hls/';
        goto QkW4E;
        AN2t2:
        $NPI6C = now()->addDays(3)->timestamp;
        goto QwEfZ;
        EG9Ky:
    }
}
