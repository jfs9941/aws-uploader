<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\F9PXWR72LBMoZ;
use Jfs\Uploader\Core\EeWreEFdq3Xdf;
use Jfs\Uploader\Core\XWJCs1ZDQGYBH;
use Jfs\Uploader\Enum\H7dtWZ2h5WAty;
use Jfs\Uploader\Exception\ZKaX19yQXS7pD;
use Jfs\Uploader\Exception\CB5eg0zuzdVv8;
use Jfs\Uploader\Exception\YIRQaRmojMDyD;
use Jfs\Uploader\Service\ZZ32LbChqQKFG;
use Illuminate\Contracts\Filesystem\Filesystem;
final class NEgSZo0taipsZ implements UploadServiceInterface
{
    private $YYj_K;
    private $ZPzJH;
    private $luUdx;
    private $nuNN3;
    public function __construct(ZZ32LbChqQKFG $eG3Fk, Filesystem $G3exm, Filesystem $u0SLj, string $NHzHX)
    {
        goto EZpSS;
        O1yY4:
        $this->ZPzJH = $G3exm;
        goto iLsJV;
        JgsUd:
        $this->nuNN3 = $NHzHX;
        goto qpuCx;
        iLsJV:
        $this->luUdx = $u0SLj;
        goto JgsUd;
        EZpSS:
        $this->YYj_K = $eG3Fk;
        goto O1yY4;
        qpuCx:
    }
    public function storeSingleFile(SingleUploadInterface $LMzxE) : array
    {
        goto i9JdW;
        i9JdW:
        $nbWJE = $this->YYj_K->mVYQ2BeVof6($LMzxE);
        goto DH92C;
        d1AvC:
        goto tvCk3;
        goto CLx7V;
        IcwpY:
        tvCk3:
        goto orZqZ;
        CLx7V:
        g2yB2:
        goto RJINI;
        txrgA:
        if (false !== $iVcpi && $nbWJE instanceof F9PXWR72LBMoZ) {
            goto g2yB2;
        }
        goto q0gct;
        orZqZ:
        return $nbWJE->getView();
        goto hCzR0;
        DH92C:
        $iVcpi = $this->luUdx->putFileAs(dirname($nbWJE->getLocation()), $LMzxE->getFile(), $nbWJE->getFilename() . '.' . $nbWJE->getExtension(), ['visibility' => 'public']);
        goto txrgA;
        q0gct:
        throw new \LogicException('File upload failed, check permissions');
        goto d1AvC;
        RJINI:
        $nbWJE->mI0VzEtubJR(H7dtWZ2h5WAty::UPLOADED);
        goto IcwpY;
        hCzR0:
    }
    public function storePreSignedFile(array $ombFX)
    {
        goto f_Ur6;
        r2gnF:
        $iZsfk->mEiiqnL3tge($ombFX['mime'], $ombFX['file_size'], $ombFX['chunk_size'], $ombFX['checksums'], $ombFX['user_id'], $ombFX['driver']);
        goto z0Pj6;
        f_Ur6:
        $nbWJE = $this->YYj_K->mVYQ2BeVof6($ombFX);
        goto vYdwT;
        z0Pj6:
        $iZsfk->mkiR97Ha49x();
        goto h2tQj;
        vYdwT:
        $iZsfk = XWJCs1ZDQGYBH::mJKhvElAoMA($nbWJE, $this->ZPzJH, $this->luUdx, $this->nuNN3, true);
        goto r2gnF;
        h2tQj:
        return ['filename' => $iZsfk->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $iZsfk->mawDjlibMZT()];
        goto lfhy1;
        lfhy1:
    }
    public function updatePreSignedFile(string $vip8M, int $EicWK)
    {
        goto Q60ZE;
        zYr3c:
        VgfGV:
        goto OEsC0;
        MjL3_:
        switch ($EicWK) {
            case H7dtWZ2h5WAty::UPLOADED:
                $iZsfk->mPDWZFDXnAa();
                goto VSH76;
            case H7dtWZ2h5WAty::PROCESSING:
                $iZsfk->m8ElVxQrBb4();
                goto VSH76;
            case H7dtWZ2h5WAty::FINISHED:
                $iZsfk->mT8xp5pS6is();
                goto VSH76;
            case H7dtWZ2h5WAty::ABORTED:
                $iZsfk->mcr2nAulWjL();
                goto VSH76;
        }
        goto zYr3c;
        Q60ZE:
        $iZsfk = XWJCs1ZDQGYBH::m7IezPqzN0k($vip8M, $this->ZPzJH, $this->luUdx, $this->nuNN3);
        goto MjL3_;
        OEsC0:
        VSH76:
        goto gPwKH;
        gPwKH:
    }
    public function completePreSignedFile(string $vip8M, array $PoqoM)
    {
        goto tL1qG;
        N_0e7:
        $iZsfk->mLzfhDWzVE5()->mylZ97z2J2s($PoqoM);
        goto XGUBU;
        tL1qG:
        $iZsfk = XWJCs1ZDQGYBH::m7IezPqzN0k($vip8M, $this->ZPzJH, $this->luUdx, $this->nuNN3);
        goto N_0e7;
        tO7QH:
        return ['path' => $iZsfk->getFile()->getView()['path'], 'thumbnail' => $iZsfk->getFile()->ipAoK, 'id' => $vip8M];
        goto kuEkK;
        XGUBU:
        $iZsfk->mPDWZFDXnAa();
        goto tO7QH;
        kuEkK:
    }
    public function updateFile(string $vip8M, int $EicWK) : EeWreEFdq3Xdf
    {
        goto pD9Pr;
        TIBv4:
        $nbWJE->mI0VzEtubJR($EicWK);
        goto v_OVD;
        v_OVD:
        return $nbWJE;
        goto KiIZO;
        pD9Pr:
        $nbWJE = $this->YYj_K->mIxY0jRYaf1($vip8M);
        goto TIBv4;
        KiIZO:
    }
}
