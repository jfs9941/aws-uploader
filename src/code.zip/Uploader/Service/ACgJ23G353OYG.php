<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Core\J5Mj1pjSQG0SH;
use Jfs\Uploader\Core\T9ZXYI5O5GjGl;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
use Jfs\Uploader\Exception\B2PcuiERDfNqQ;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Jfs\Uploader\Exception\QdafZI2suLm2R;
final class ACgJ23G353OYG implements UploadServiceInterface
{
    private $K1zSF;
    private $kduDw;
    private $w2y98;
    private $AutqI;
    public function __construct(UKpsYHdguB77R $t7BJ8, Filesystem $h5ffz, Filesystem $uANLN, string $vEJpS)
    {
        goto aRRrD;
        zE9fL:
        $this->kduDw = $h5ffz;
        goto S0jZ1;
        pheYz:
        $this->AutqI = $vEJpS;
        goto k6FP0;
        S0jZ1:
        $this->w2y98 = $uANLN;
        goto pheYz;
        aRRrD:
        $this->K1zSF = $t7BJ8;
        goto zE9fL;
        k6FP0:
    }
    public function storeSingleFile(SingleUploadInterface $y4Nyd) : array
    {
        goto qGgXa;
        QHHNL:
        $sEueW = $this->w2y98->putFileAs(dirname($nKKn0->getLocation()), $y4Nyd->getFile(), $nKKn0->getFilename() . '.' . $nKKn0->getExtension(), ['visibility' => 'public']);
        goto cGEpY;
        Dd1kC:
        return $nKKn0->getView();
        goto EJqHI;
        qGgXa:
        $nKKn0 = $this->K1zSF->mmFTiQbv1u8($y4Nyd);
        goto QHHNL;
        qbkm6:
        K01xh:
        goto Dd1kC;
        cGEpY:
        if (false !== $sEueW && $nKKn0 instanceof PxTzgsobiHpcX) {
            goto IpZkN;
        }
        goto MfAdC;
        Rs63y:
        goto K01xh;
        goto b_e2e;
        b_e2e:
        IpZkN:
        goto d3x34;
        MfAdC:
        throw new \LogicException('File upload failed, check permissions');
        goto Rs63y;
        d3x34:
        $nKKn0->mSAdKjgXIhj(O8RzIjGmSN6fG::UPLOADED);
        goto qbkm6;
        EJqHI:
    }
    public function storePreSignedFile(array $xIZGg)
    {
        goto vRo6Q;
        g8scy:
        $B107M = T9ZXYI5O5GjGl::mtmgv9I6Ki6($nKKn0, $this->kduDw, $this->w2y98, $this->AutqI, true);
        goto RyhJW;
        Ud6fw:
        $B107M->m5XpvJSSw8B();
        goto HNx3c;
        HNx3c:
        return ['filename' => $B107M->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $B107M->m1HynR3TcF6()];
        goto FZPR3;
        RyhJW:
        $B107M->mF6PC7tYEYz($xIZGg['mime'], $xIZGg['file_size'], $xIZGg['chunk_size'], $xIZGg['checksums'], $xIZGg['user_id'], $xIZGg['driver']);
        goto Ud6fw;
        vRo6Q:
        $nKKn0 = $this->K1zSF->mmFTiQbv1u8($xIZGg);
        goto g8scy;
        FZPR3:
    }
    public function updatePreSignedFile(string $vChc2, int $nZuhb)
    {
        goto owfyM;
        N9A8Y:
        switch ($nZuhb) {
            case O8RzIjGmSN6fG::UPLOADED:
                $B107M->mal1fCPSgtX();
                goto woAK8;
            case O8RzIjGmSN6fG::PROCESSING:
                $B107M->mxyeOEjPoFu();
                goto woAK8;
            case O8RzIjGmSN6fG::FINISHED:
                $B107M->mcpT1XONZF5();
                goto woAK8;
            case O8RzIjGmSN6fG::ABORTED:
                $B107M->moRGnOr8s5k();
                goto woAK8;
        }
        goto vG3Kv;
        vG3Kv:
        FHn_T:
        goto rCLTu;
        rCLTu:
        woAK8:
        goto J_KdW;
        owfyM:
        $B107M = T9ZXYI5O5GjGl::mqLELyC8VTa($vChc2, $this->kduDw, $this->w2y98, $this->AutqI);
        goto N9A8Y;
        J_KdW:
    }
    public function completePreSignedFile(string $vChc2, array $cJl2t)
    {
        goto Y_RQN;
        IC0h2:
        $B107M->mew8rrjhK4U()->mUivlA2O4YU($cJl2t);
        goto v2x1z;
        l_sRv:
        return ['path' => $B107M->getFile()->getView()['path'], 'thumbnail' => $B107M->getFile()->g97cm, 'id' => $vChc2];
        goto yWva2;
        v2x1z:
        $B107M->mal1fCPSgtX();
        goto l_sRv;
        Y_RQN:
        $B107M = T9ZXYI5O5GjGl::mqLELyC8VTa($vChc2, $this->kduDw, $this->w2y98, $this->AutqI);
        goto IC0h2;
        yWva2:
    }
    public function updateFile(string $vChc2, int $nZuhb) : J5Mj1pjSQG0SH
    {
        goto To_LV;
        WLDSX:
        return $nKKn0;
        goto bj94O;
        To_LV:
        $nKKn0 = $this->K1zSF->m7zch1W8BLm($vChc2);
        goto jIogR;
        jIogR:
        $nKKn0->mSAdKjgXIhj($nZuhb);
        goto WLDSX;
        bj94O:
    }
}
