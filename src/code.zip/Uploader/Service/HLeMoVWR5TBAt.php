<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Core\YeOKDEuyU49Av;
use Jfs\Uploader\Core\ZFuimKZywyxo2;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Jfs\Uploader\Exception\GUt8ZmYbCCh9b;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Exception\YoMZumD8PRcVT;
use Jfs\Uploader\Service\RIRnT0b6ENemU;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HLeMoVWR5TBAt implements UploadServiceInterface
{
    private $LuW4v;
    private $yt19t;
    private $wKOGL;
    private $rtDvi;
    public function __construct(RIRnT0b6ENemU $C_Oeu, Filesystem $RndMA, Filesystem $luwqK, string $VwJzJ)
    {
        goto AO1mn;
        KmayY:
        $this->rtDvi = $VwJzJ;
        goto DzhoH;
        HwOt6:
        $this->wKOGL = $luwqK;
        goto KmayY;
        nrl53:
        $this->yt19t = $RndMA;
        goto HwOt6;
        AO1mn:
        $this->LuW4v = $C_Oeu;
        goto nrl53;
        DzhoH:
    }
    public function storeSingleFile(SingleUploadInterface $FeNY0) : array
    {
        goto s33fR;
        F3KL8:
        $hU2b_ = $this->wKOGL->putFileAs(dirname($dV9QE->getLocation()), $FeNY0->getFile(), $dV9QE->getFilename() . '.' . $dV9QE->getExtension(), ['visibility' => 'public']);
        goto uD1xS;
        yiKXx:
        goto apw8p;
        goto Bx9Um;
        r3_G9:
        $dV9QE->mKd8O9TpYCH(EpMPhiTVzNYqA::UPLOADED);
        goto P63OD;
        s33fR:
        $dV9QE = $this->LuW4v->mZ7qxQ2pqeJ($FeNY0);
        goto F3KL8;
        P63OD:
        apw8p:
        goto mIfqX;
        mIfqX:
        return $dV9QE->getView();
        goto eF6UO;
        uD1xS:
        if (false !== $hU2b_ && $dV9QE instanceof GCZ2vyVNpj70n) {
            goto MuXSw;
        }
        goto HfpJR;
        HfpJR:
        throw new \LogicException('File upload failed, check permissions');
        goto yiKXx;
        Bx9Um:
        MuXSw:
        goto r3_G9;
        eF6UO:
    }
    public function storePreSignedFile(array $MtIaz)
    {
        goto hFg9o;
        qQsnL:
        $araMZ->mj1uGcThg9p();
        goto RjsWb;
        hFg9o:
        $dV9QE = $this->LuW4v->mZ7qxQ2pqeJ($MtIaz);
        goto jgj3M;
        RjsWb:
        return ['filename' => $araMZ->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $araMZ->mt4urd3oc3e()];
        goto TdiXf;
        jgj3M:
        $araMZ = ZFuimKZywyxo2::marMbitayPI($dV9QE, $this->yt19t, $this->wKOGL, $this->rtDvi, true);
        goto l9LDR;
        l9LDR:
        $araMZ->miNwUSV7YyC($MtIaz['mime'], $MtIaz['file_size'], $MtIaz['chunk_size'], $MtIaz['checksums'], $MtIaz['user_id'], $MtIaz['driver']);
        goto qQsnL;
        TdiXf:
    }
    public function updatePreSignedFile(string $rQxXm, int $qzw_R)
    {
        goto UGQRL;
        UGQRL:
        $araMZ = ZFuimKZywyxo2::mXj7mf0akQX($rQxXm, $this->yt19t, $this->wKOGL, $this->rtDvi);
        goto CYulo;
        QOLRp:
        HA0pE:
        goto PhUqW;
        CYulo:
        switch ($qzw_R) {
            case EpMPhiTVzNYqA::UPLOADED:
                $araMZ->mdvy7fR7OrW();
                goto x_uxl;
            case EpMPhiTVzNYqA::PROCESSING:
                $araMZ->mHHMfsWbC3y();
                goto x_uxl;
            case EpMPhiTVzNYqA::FINISHED:
                $araMZ->m1Elx5LUPo1();
                goto x_uxl;
            case EpMPhiTVzNYqA::ABORTED:
                $araMZ->mtVbnRXO7El();
                goto x_uxl;
        }
        goto QOLRp;
        PhUqW:
        x_uxl:
        goto Juqza;
        Juqza:
    }
    public function completePreSignedFile(string $rQxXm, array $O39m9)
    {
        goto LBjwH;
        LBjwH:
        $araMZ = ZFuimKZywyxo2::mXj7mf0akQX($rQxXm, $this->yt19t, $this->wKOGL, $this->rtDvi);
        goto ps67e;
        xwKwv:
        return ['path' => $araMZ->getFile()->getView()['path'], 'thumbnail' => $araMZ->getFile()->r1f8r, 'id' => $rQxXm];
        goto hg0wE;
        dLwbq:
        $araMZ->mdvy7fR7OrW();
        goto xwKwv;
        ps67e:
        $araMZ->mf47A6FAs7u()->mp5vEwdLUkf($O39m9);
        goto dLwbq;
        hg0wE:
    }
    public function updateFile(string $rQxXm, int $qzw_R) : YeOKDEuyU49Av
    {
        goto N9OYf;
        N9OYf:
        $dV9QE = $this->LuW4v->mE3a97ii6ha($rQxXm);
        goto yg6oN;
        yg6oN:
        $dV9QE->mKd8O9TpYCH($qzw_R);
        goto wlL4C;
        wlL4C:
        return $dV9QE;
        goto oJtDJ;
        oJtDJ:
    }
}
