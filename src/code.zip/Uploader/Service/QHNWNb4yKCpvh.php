<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use backup\Uploader\Contracts\NTBMTa29AeaJq;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Core\OzgWWRogA2eJF;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\XmcIS8CQn72i3;
final class QHNWNb4yKCpvh implements NTBMTa29AeaJq
{
    private $OdM3k;
    private $Dm1If;
    public $AqfGp;
    private $ITiAO;
    private $L0RWk;
    private $c35HU;
    public function __construct($EqAK1, $Mzfhr, $mFei1, $FlrVt, $qqpJ4, $VHhUy)
    {
        goto g5nfl;
        nK0kT:
        $this->ITiAO = $FlrVt;
        goto Qa6Lb;
        r83ou:
        $this->AqfGp = $mFei1;
        goto nK0kT;
        g5nfl:
        $this->c35HU = $VHhUy;
        goto hGSA9;
        Qa6Lb:
        $this->L0RWk = $qqpJ4;
        goto UMWlf;
        PmwED:
        $this->Dm1If = $Mzfhr;
        goto r83ou;
        hGSA9:
        $this->OdM3k = $EqAK1;
        goto PmwED;
        UMWlf:
    }
    public function resolvePath($tFHv6, $agJ1D = XmcIS8CQn72i3::S3) : string
    {
        goto MZkoZ;
        mVlwZ:
        return config('upload.home') . '/' . $tFHv6;
        goto DJx4S;
        hFw6i:
        SDlDq:
        goto nGdV8;
        RF4Al:
        return trim($this->AqfGp, '/') . '/' . $tFHv6;
        goto secif;
        O13w_:
        return $this->mSkQ1ayz5pd($tFHv6);
        goto hFw6i;
        nGdV8:
        if (!$this->OdM3k) {
            goto FaDTs;
        }
        goto RF4Al;
        iGmJJ:
        return trim($this->Dm1If, '/') . '/' . $tFHv6;
        goto rBnQI;
        DJx4S:
        aAvYu:
        goto HdeQK;
        secif:
        FaDTs:
        goto iGmJJ;
        BiRVD:
        BV3SD:
        goto r5_Xi;
        HdeQK:
        if (!(!empty($this->ITiAO) && !empty($this->L0RWk))) {
            goto SDlDq;
        }
        goto O13w_;
        r5_Xi:
        if (!($agJ1D === XmcIS8CQn72i3::LOCAL)) {
            goto aAvYu;
        }
        goto mVlwZ;
        SflbG:
        $tFHv6 = $tFHv6->getAttribute('filename');
        goto BiRVD;
        MZkoZ:
        if (!$tFHv6 instanceof PJqa0Yy2jwBHe) {
            goto BV3SD;
        }
        goto SflbG;
        rBnQI:
    }
    public function resolveThumbnail(PJqa0Yy2jwBHe $tFHv6) : string
    {
        goto zgY8J;
        xYSB7:
        return '';
        goto vBmaZ;
        ZjQDj:
        if (!$eUYaV) {
            goto dRTxR;
        }
        goto IYsV9;
        uUlo5:
        if (!$tFHv6 instanceof OzgWWRogA2eJF) {
            goto pL_Fs;
        }
        goto sgTm5;
        ICmvh:
        if (!$tFHv6 instanceof CrEYqpC23XUGo) {
            goto ipkIy;
        }
        goto fXRYQ;
        CWXcq:
        pL_Fs:
        goto xYSB7;
        LHeof:
        I3q0o:
        goto ICmvh;
        WE61e:
        if (!$bp6Lq) {
            goto SUJwE;
        }
        goto F1wbz;
        wvG6P:
        ipkIy:
        goto uUlo5;
        CZOCa:
        SUJwE:
        goto IN1_a;
        sgTm5:
        return asset('/img/pdf-preview.svg');
        goto CWXcq;
        gTI1A:
        dRTxR:
        goto LHeof;
        IYsV9:
        return $this->resolvePath($eUYaV, $eUYaV->getAttribute('driver'));
        goto gTI1A;
        IN1_a:
        if (!$tFHv6->getAttribute('thumbnail_id')) {
            goto I3q0o;
        }
        goto R9Qi8;
        F1wbz:
        return $this->url($bp6Lq, $tFHv6->getAttribute('driver'));
        goto CZOCa;
        R9Qi8:
        $eUYaV = CrEYqpC23XUGo::find($tFHv6->getAttribute('thumbnail_id'));
        goto ZjQDj;
        fXRYQ:
        return $this->resolvePath($tFHv6, $tFHv6->getAttribute('driver'));
        goto wvG6P;
        zgY8J:
        $bp6Lq = $tFHv6->getAttribute('thumbnail');
        goto WE61e;
        vBmaZ:
    }
    private function url($KPnwr, $agJ1D)
    {
        goto tKX1T;
        iIjRJ:
        BQ0kt:
        goto R50ku;
        tKX1T:
        if (!($agJ1D == XmcIS8CQn72i3::LOCAL)) {
            goto BQ0kt;
        }
        goto xI7Ag;
        R50ku:
        return $this->resolvePath($KPnwr);
        goto wQ1fF;
        xI7Ag:
        return config('upload.home') . '/' . $KPnwr;
        goto iIjRJ;
        wQ1fF:
    }
    private function mSkQ1ayz5pd($KPnwr)
    {
        goto C9P1g;
        ZIGFu:
        mkZ1h:
        goto OIUMR;
        ESKCC:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto ZIGFu;
        QrE2S:
        C24EA:
        goto a5HdL;
        Yooth:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto QrE2S;
        nI_VO:
        return $hiHYr->getSignedUrl($this->AqfGp . '/' . $KPnwr, $iw1fj);
        goto AaIA2;
        wqkFi:
        $hiHYr = new UrlSigner($this->ITiAO, $this->c35HU->path($this->L0RWk));
        goto nI_VO;
        OIUMR:
        if (!(strpos($KPnwr, 'm3u8') !== false)) {
            goto C24EA;
        }
        goto Yooth;
        a5HdL:
        $iw1fj = now()->addMinutes(60)->timestamp;
        goto wqkFi;
        C9P1g:
        if (!(strpos($KPnwr, 'https://') === 0)) {
            goto mkZ1h;
        }
        goto ESKCC;
        AaIA2:
    }
    public function resolvePathForHlsVideo(AvisbyD0IE5xq $L2Ff8, $tQWZK = false) : string
    {
        goto Io74M;
        qYirm:
        return $this->AqfGp . '/' . $L2Ff8->getAttribute('hls_path');
        goto cg5ed;
        vlZvL:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Wpy_k;
        Wpy_k:
        LQPKG:
        goto qYirm;
        Io74M:
        if ($L2Ff8->getAttribute('hls_path')) {
            goto LQPKG;
        }
        goto vlZvL;
        cg5ed:
    }
    public function resolvePathForHlsVideos()
    {
        goto ktrM2;
        JG_uE:
        $W1OEY = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto FziNp;
        MDtSf:
        $DwtTY = $this->AqfGp . '/v2/hls/';
        goto iY4eP;
        ktrM2:
        $iw1fj = now()->addDays(3)->timestamp;
        goto MDtSf;
        iY4eP:
        $ffzPf = json_encode(['Statement' => [['Resource' => sprintf('%s*', $DwtTY), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $iw1fj]]]]]);
        goto JG_uE;
        FziNp:
        $yGnGC = $W1OEY->getSignedCookie(['key_pair_id' => $this->ITiAO, 'private_key' => $this->c35HU->path($this->L0RWk), 'policy' => $ffzPf]);
        goto iGOaH;
        iGOaH:
        return [$yGnGC, $iw1fj];
        goto sGSMU;
        sGSMU:
    }
}
