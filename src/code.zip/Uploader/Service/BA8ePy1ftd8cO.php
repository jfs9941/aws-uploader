<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\VdjamMvtIkwfN;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Core\GPZ0EQoHpj04q;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
final class BA8ePy1ftd8cO implements VdjamMvtIkwfN
{
    private $Q3zY4;
    private $HrdWI;
    public $MQ4dI;
    private $lbGRr;
    private $gz8Mk;
    private $MuT3J;
    public function __construct($e_2bR, $NRp_I, $vEJAF, $RaH2w, $vPvsU, $tBTgN)
    {
        goto odgpe;
        odgpe:
        $this->MuT3J = $tBTgN;
        goto s86lE;
        rkO0_:
        $this->HrdWI = $NRp_I;
        goto TDmqz;
        s86lE:
        $this->Q3zY4 = $e_2bR;
        goto rkO0_;
        TDmqz:
        $this->MQ4dI = $vEJAF;
        goto xcpCw;
        xcpCw:
        $this->lbGRr = $RaH2w;
        goto fXRfk;
        fXRfk:
        $this->gz8Mk = $vPvsU;
        goto VBrPb;
        VBrPb:
    }
    public function resolvePath($HO_3Y, $OFz0s = VNuaYSNcfVlT5::S3) : string
    {
        goto OoMMK;
        oAfBk:
        TH6kq:
        goto tn8b8;
        L30Eb:
        if (!(!empty($this->lbGRr) && !empty($this->gz8Mk))) {
            goto CIxdF;
        }
        goto FUOW_;
        USaVL:
        return trim($this->HrdWI, '/') . '/' . $HO_3Y;
        goto rzH1Y;
        euH99:
        n9OPv:
        goto USaVL;
        Ou3xm:
        return trim($this->MQ4dI, '/') . '/' . $HO_3Y;
        goto euH99;
        OoMMK:
        if (!$HO_3Y instanceof VMj30iBgKeeJB) {
            goto TH6kq;
        }
        goto ZH6UL;
        fjFtH:
        CIxdF:
        goto oz2Eo;
        TAvtq:
        return config('upload.home') . '/' . $HO_3Y;
        goto rCt3H;
        ZH6UL:
        $HO_3Y = $HO_3Y->getAttribute('filename');
        goto oAfBk;
        FUOW_:
        return $this->mDezx3li3fw($HO_3Y);
        goto fjFtH;
        oz2Eo:
        if (!$this->Q3zY4) {
            goto n9OPv;
        }
        goto Ou3xm;
        tn8b8:
        if (!($OFz0s === VNuaYSNcfVlT5::LOCAL)) {
            goto FVxYi;
        }
        goto TAvtq;
        rCt3H:
        FVxYi:
        goto L30Eb;
        rzH1Y:
    }
    public function resolveThumbnail(VMj30iBgKeeJB $HO_3Y) : string
    {
        goto EfasH;
        m21ky:
        if (!$HO_3Y instanceof GPZ0EQoHpj04q) {
            goto BuT1u;
        }
        goto Wdz9U;
        J4atL:
        $pWYY6 = QFoN7Ibbm93if::find($HO_3Y->getAttribute('thumbnail_id'));
        goto t7pFy;
        QbHpW:
        if (!$EpLlV) {
            goto V8wG1;
        }
        goto DzW2H;
        DzW2H:
        return $this->url($EpLlV, $HO_3Y->getAttribute('driver'));
        goto hGd42;
        FnQPm:
        return $this->resolvePath($pWYY6, $pWYY6->getAttribute('driver'));
        goto ZgnEn;
        J_b0O:
        return $this->resolvePath($HO_3Y, $HO_3Y->getAttribute('driver'));
        goto FbMeZ;
        FbMeZ:
        A3oRL:
        goto m21ky;
        ZgnEn:
        N23uE:
        goto hUhxm;
        hGd42:
        V8wG1:
        goto opg7c;
        opg7c:
        if (!$HO_3Y->getAttribute('thumbnail_id')) {
            goto fl8Jp;
        }
        goto J4atL;
        EfasH:
        $EpLlV = $HO_3Y->getAttribute('thumbnail');
        goto QbHpW;
        xsYv_:
        if (!$HO_3Y instanceof QFoN7Ibbm93if) {
            goto A3oRL;
        }
        goto J_b0O;
        hUhxm:
        fl8Jp:
        goto xsYv_;
        Wdz9U:
        return asset('/img/pdf-preview.svg');
        goto OCeFO;
        OCeFO:
        BuT1u:
        goto iSTDB;
        iSTDB:
        return '';
        goto zlMFE;
        t7pFy:
        if (!$pWYY6) {
            goto N23uE;
        }
        goto FnQPm;
        zlMFE:
    }
    private function url($dSgog, $OFz0s)
    {
        goto DvxE3;
        DvxE3:
        if (!($OFz0s == VNuaYSNcfVlT5::LOCAL)) {
            goto JYOTN;
        }
        goto rS61e;
        rS61e:
        return config('upload.home') . '/' . $dSgog;
        goto Tg4uo;
        DxWdX:
        return $this->resolvePath($dSgog);
        goto EaGoy;
        Tg4uo:
        JYOTN:
        goto DxWdX;
        EaGoy:
    }
    private function mDezx3li3fw($dSgog)
    {
        goto Cyzoq;
        KtsZi:
        n94vm:
        goto uDuE7;
        VjEuy:
        $OYfEi = new UrlSigner($this->lbGRr, $this->MuT3J->path($this->gz8Mk));
        goto hnKNE;
        kaZZY:
        $sRgVA = now()->addMinutes(60)->timestamp;
        goto VjEuy;
        kx5BI:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto KtsZi;
        uDuE7:
        if (!(strpos($dSgog, 'm3u8') !== false)) {
            goto vC_aJ;
        }
        goto brrdd;
        Cyzoq:
        if (!(strpos($dSgog, 'https://') === 0)) {
            goto n94vm;
        }
        goto kx5BI;
        Ae84s:
        vC_aJ:
        goto kaZZY;
        hnKNE:
        return $OYfEi->getSignedUrl($this->MQ4dI . '/' . $dSgog, $sRgVA);
        goto SoHv0;
        brrdd:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto Ae84s;
        SoHv0:
    }
    public function resolvePathForHlsVideo(WrCq6RmnGcVh7 $XrW52, $z0gV9 = false) : string
    {
        goto z2PWe;
        fADxa:
        return $this->MQ4dI . '/' . $XrW52->getAttribute('hls_path');
        goto ZqBta;
        S2Adl:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto eWEXX;
        z2PWe:
        if ($XrW52->getAttribute('hls_path')) {
            goto iV9nu;
        }
        goto S2Adl;
        eWEXX:
        iV9nu:
        goto fADxa;
        ZqBta:
    }
    public function resolvePathForHlsVideos()
    {
        goto e1p3c;
        ILXuX:
        $s8jhQ = $this->MQ4dI . '/v2/hls/';
        goto vTCEu;
        yaouv:
        $BTGnj = $Ny43j->getSignedCookie(['key_pair_id' => $this->lbGRr, 'private_key' => $this->MuT3J->path($this->gz8Mk), 'policy' => $YNgRF]);
        goto XQdj0;
        XbRNF:
        $Ny43j = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto yaouv;
        e1p3c:
        $sRgVA = now()->addDays(3)->timestamp;
        goto ILXuX;
        XQdj0:
        return [$BTGnj, $sRgVA];
        goto eY0dq;
        vTCEu:
        $YNgRF = json_encode(['Statement' => [['Resource' => sprintf('%s*', $s8jhQ), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $sRgVA]]]]]);
        goto XbRNF;
        eY0dq:
    }
}
