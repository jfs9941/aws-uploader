<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Core\OfMUIxZzii9Zu;
use Jfs\Uploader\Core\UYVrA8my964mM;
use Jfs\Uploader\Enum\EHhCBxlsVyz9C;
use Jfs\Uploader\Exception\EJQS1ugI78hby;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Exception\Im4dmRuVGtM4W;
use Jfs\Uploader\Service\K3koL2kq4QSAu;
use Illuminate\Contracts\Filesystem\Filesystem;
final class PPI0EdnxstwVb implements UploadServiceInterface
{
    private $eLxV1;
    private $zoOKU;
    private $NICMg;
    private $D4ptD;
    public function __construct(K3koL2kq4QSAu $wOM2X, Filesystem $e3FbC, Filesystem $iw6E8, string $mywzH)
    {
        goto Xf1Yh;
        I_dOY:
        $this->D4ptD = $mywzH;
        goto HzYER;
        hTd00:
        $this->NICMg = $iw6E8;
        goto I_dOY;
        Xf1Yh:
        $this->eLxV1 = $wOM2X;
        goto iUzgE;
        iUzgE:
        $this->zoOKU = $e3FbC;
        goto hTd00;
        HzYER:
    }
    public function storeSingleFile(SingleUploadInterface $VZoSn) : array
    {
        goto yQfCM;
        eF9_t:
        $gNVOT->ml2jBQKKXoS(EHhCBxlsVyz9C::UPLOADED);
        goto awBfk;
        sMHq0:
        hvcAo:
        goto eF9_t;
        B9aDO:
        return $gNVOT->getView();
        goto LLThI;
        E1YMJ:
        $d1QWa = $this->NICMg->putFileAs(dirname($gNVOT->getLocation()), $VZoSn->getFile(), $gNVOT->getFilename() . '.' . $gNVOT->getExtension(), ['visibility' => 'public']);
        goto MTXS2;
        awBfk:
        RCbVR:
        goto B9aDO;
        MTXS2:
        if (false !== $d1QWa && $gNVOT instanceof OFkaCU82i4KNX) {
            goto hvcAo;
        }
        goto EKSlF;
        o1_Nw:
        goto RCbVR;
        goto sMHq0;
        yQfCM:
        $gNVOT = $this->eLxV1->m2wXw1yUeMq($VZoSn);
        goto E1YMJ;
        EKSlF:
        throw new \LogicException('File upload failed, check permissions');
        goto o1_Nw;
        LLThI:
    }
    public function storePreSignedFile(array $Feyxr)
    {
        goto ueSjs;
        MEXit:
        $e0yCg = UYVrA8my964mM::mG4IkP4BCe5($gNVOT, $this->zoOKU, $this->NICMg, $this->D4ptD, true);
        goto aSeLT;
        iJOi8:
        return ['filename' => $e0yCg->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $e0yCg->mVEsQY97kz8()];
        goto TpA2t;
        AeepX:
        $e0yCg->mbd9isjgURj();
        goto iJOi8;
        ueSjs:
        $gNVOT = $this->eLxV1->m2wXw1yUeMq($Feyxr);
        goto MEXit;
        aSeLT:
        $e0yCg->m1rPM77PMvw($Feyxr['mime'], $Feyxr['file_size'], $Feyxr['chunk_size'], $Feyxr['checksums'], $Feyxr['user_id'], $Feyxr['driver']);
        goto AeepX;
        TpA2t:
    }
    public function updatePreSignedFile(string $kFpT0, int $aaU14)
    {
        goto B06Q2;
        r9cCm:
        DTpRA:
        goto Qu354;
        Qu354:
        Y8ZMc:
        goto q1Ijp;
        Jisy6:
        switch ($aaU14) {
            case EHhCBxlsVyz9C::UPLOADED:
                $e0yCg->mf3Ko95nDis();
                goto Y8ZMc;
            case EHhCBxlsVyz9C::PROCESSING:
                $e0yCg->maOgBiOkDjI();
                goto Y8ZMc;
            case EHhCBxlsVyz9C::FINISHED:
                $e0yCg->mHeIKrJiKk6();
                goto Y8ZMc;
            case EHhCBxlsVyz9C::ABORTED:
                $e0yCg->m6onpnUSJKd();
                goto Y8ZMc;
        }
        goto r9cCm;
        B06Q2:
        $e0yCg = UYVrA8my964mM::motvAxgHBzG($kFpT0, $this->zoOKU, $this->NICMg, $this->D4ptD);
        goto Jisy6;
        q1Ijp:
    }
    public function completePreSignedFile(string $kFpT0, array $NCegP)
    {
        goto RQWT1;
        awyCF:
        return ['path' => $e0yCg->getFile()->getView()['path'], 'thumbnail' => $e0yCg->getFile()->aweuO, 'id' => $kFpT0];
        goto GmqtZ;
        CEd6V:
        $e0yCg->m8KWEnHETkc()->mkpVwrkBWKg($NCegP);
        goto HT6v0;
        HT6v0:
        $e0yCg->mf3Ko95nDis();
        goto awyCF;
        RQWT1:
        $e0yCg = UYVrA8my964mM::motvAxgHBzG($kFpT0, $this->zoOKU, $this->NICMg, $this->D4ptD);
        goto CEd6V;
        GmqtZ:
    }
    public function updateFile(string $kFpT0, int $aaU14) : OfMUIxZzii9Zu
    {
        goto lvaul;
        lvaul:
        $gNVOT = $this->eLxV1->m6FtHGGCs4T($kFpT0);
        goto zlsC3;
        DWspU:
        return $gNVOT;
        goto Tz5F4;
        zlsC3:
        $gNVOT->ml2jBQKKXoS($aaU14);
        goto DWspU;
        Tz5F4:
    }
}
