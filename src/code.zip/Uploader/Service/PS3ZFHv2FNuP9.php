<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\LlMDscQw21XKp;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class PS3ZFHv2FNuP9 implements VideoPostHandleServiceInterface
{
    private $eq3Hl;
    private $VV2A8;
    public function __construct(UploadServiceInterface $hth4p, Filesystem $oOPBt)
    {
        $this->eq3Hl = $hth4p;
        $this->VV2A8 = $oOPBt;
    }
    public function saveMetadata(string $GhyxD, array $ZTJaQ)
    {
        goto U4IIn;
        fldCB:
        a1U4n:
        goto RRc17;
        AS8mg:
        $jYzWT = [];
        goto AxFP9;
        VWi_h:
        if (!isset($ZTJaQ['resolution'])) {
            goto RRKpA;
        }
        goto glFP9;
        WYrHi:
        bYN7o:
        goto L8T3s;
        NofFK:
        J_Ax6:
        goto VWi_h;
        NTP7v:
        if (!isset($ZTJaQ['fps'])) {
            goto a1U4n;
        }
        goto UOwPj;
        AxFP9:
        if (!isset($ZTJaQ['thumbnail'])) {
            goto bYN7o;
        }
        goto Hk502;
        U4IIn:
        $bKijV = VHp3UACVYl357::findOrFail($GhyxD);
        goto AS8mg;
        MZTOO:
        $this->eq3Hl->updateFile($bKijV->getAttribute('id'), LlMDscQw21XKp::PROCESSING);
        goto lI7TW;
        dykJ0:
        RRKpA:
        goto NTP7v;
        FlJJ1:
        unset($jYzWT['thumbnail']);
        goto S8jdE;
        RRc17:
        if (!$bKijV->tWztK) {
            goto y7g_B;
        }
        goto FlJJ1;
        L8T3s:
        if (!isset($ZTJaQ['duration'])) {
            goto J_Ax6;
        }
        goto t3RiK;
        FG6O9:
        throw new \Exception("VHp3UACVYl357 metadata store failed for unknown reason ... " . $GhyxD);
        goto Fh80F;
        S8jdE:
        y7g_B:
        goto d3ksu;
        t3RiK:
        $jYzWT['duration'] = $ZTJaQ['duration'];
        goto NofFK;
        SwrHq:
        pKZu2:
        goto eURNu;
        NEXDH:
        if (!(isset($ZTJaQ['change_status']) && $ZTJaQ['change_status'])) {
            goto U8Fok;
        }
        goto MZTOO;
        cEVFr:
        return $bKijV->getView();
        goto SwrHq;
        UOwPj:
        $jYzWT['fps'] = $ZTJaQ['fps'];
        goto fldCB;
        Hk502:
        try {
            goto nPv2U;
            nPv2U:
            $w6RVC = $this->eq3Hl->storeSingleFile(new class($ZTJaQ['thumbnail']) implements SingleUploadInterface
            {
                private $Fhq5F;
                public function __construct($spSJx)
                {
                    $this->Fhq5F = $spSJx;
                }
                public function getFile()
                {
                    return $this->Fhq5F;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto TXbEP;
            aNVeM:
            $jYzWT['thumbnail'] = $w6RVC['filename'];
            goto ZBmzi;
            TXbEP:
            $jYzWT['thumbnail_id'] = $w6RVC['id'];
            goto aNVeM;
            ZBmzi:
        } catch (\Throwable $YIsP2) {
            Log::warning("VHp3UACVYl357 thumbnail store failed: " . $YIsP2->getMessage());
        }
        goto WYrHi;
        glFP9:
        $jYzWT['resolution'] = $ZTJaQ['resolution'];
        goto dykJ0;
        lI7TW:
        U8Fok:
        goto cEVFr;
        d3ksu:
        if (!$bKijV->update($jYzWT)) {
            goto pKZu2;
        }
        goto NEXDH;
        eURNu:
        Log::warning("VHp3UACVYl357 metadata store failed for unknown reason ... " . $GhyxD);
        goto FG6O9;
        Fh80F:
    }
    public function createThumbnail(string $UVUKT) : void
    {
        goto rMrzZ;
        ORrwV:
        HZWZF:
        goto m71Ya;
        kcEao:
        $HSPqB = "v2/hls/thumbnails/{$UVUKT}/";
        goto GZ9VG;
        Yesx9:
        $bKijV = VHp3UACVYl357::findOrFail($UVUKT);
        goto kcEao;
        rMrzZ:
        Log::info("Use Lambda to generate thumbnail for video: " . $UVUKT);
        goto Yesx9;
        vBK5C:
        try {
            goto nWYuW;
            rzsWg:
            $Bz6pn = $EHIYF->get('QueueUrl');
            goto FmoaP;
            FmoaP:
            $ExF3y->sendMessage(['QueueUrl' => $Bz6pn, 'MessageBody' => json_encode(['file_path' => $bKijV->getLocation()])]);
            goto rVca5;
            nWYuW:
            $EHIYF = $ExF3y->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto rzsWg;
            rVca5:
        } catch (\Throwable $w7Va8) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$w7Va8->getMessage()}");
        }
        goto ORrwV;
        PHJeo:
        $ExF3y = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto vBK5C;
        GZ9VG:
        if (!(!$this->VV2A8->directoryExists($HSPqB) && empty($bKijV->m4QVUgAQsLB()))) {
            goto HZWZF;
        }
        goto PHJeo;
        m71Ya:
    }
    public function mTbEZMMrdep(string $UVUKT) : void
    {
        goto P85tP;
        wid8T:
        $GA5_K = $this->VV2A8->files($HSPqB);
        goto S51th;
        EpmnE:
        $HSPqB = "v2/hls/thumbnails/{$UVUKT}/";
        goto Spv5F;
        hYWbk:
        throw new \Exception("Message back with success data but not found thumbnail files " . $UVUKT);
        goto i1shP;
        i1shP:
        xGxTw:
        goto BRawp;
        Ma48o:
        cBkl4:
        goto wid8T;
        Xm9e9:
        Log::error("Message back with success data but not found thumbnail files " . $UVUKT);
        goto hYWbk;
        ufbV_:
        Log::error("Message back with success data but not found thumbnail " . $UVUKT);
        goto kdwnO;
        P85tP:
        $bKijV = VHp3UACVYl357::findOrFail($UVUKT);
        goto EpmnE;
        Spv5F:
        if ($this->VV2A8->directoryExists($HSPqB)) {
            goto cBkl4;
        }
        goto ufbV_;
        kdwnO:
        throw new \Exception("Message back with success data but not found thumbnail " . $UVUKT);
        goto Ma48o;
        BRawp:
        $bKijV->update(['generated_previews' => $HSPqB]);
        goto MPI_w;
        S51th:
        if (!(count($GA5_K) === 0)) {
            goto xGxTw;
        }
        goto Xm9e9;
        MPI_w:
    }
    public function getThumbnails(string $UVUKT) : array
    {
        $bKijV = VHp3UACVYl357::findOrFail($UVUKT);
        return $bKijV->getThumbnails();
    }
    public function getMedia(string $UVUKT) : array
    {
        $pDny3 = Media::findOrFail($UVUKT);
        return $pDny3->getView();
    }
}
