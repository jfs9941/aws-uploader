<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\A9q1Lm9l5QixG;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class WSkgEM3WwLYPA implements VideoPostHandleServiceInterface
{
    private $u1HPE;
    private $zbU8n;
    public function __construct(UploadServiceInterface $Dz7Zg, Filesystem $Efy84)
    {
        $this->u1HPE = $Dz7Zg;
        $this->zbU8n = $Efy84;
    }
    public function saveMetadata(string $N2oAf, array $u_EX6)
    {
        goto mZ36c;
        DKbRy:
        GxIrF:
        goto hECcB;
        AmMc4:
        LXrUi:
        goto RyZal;
        i8Tc3:
        OgjIE:
        goto LN48l;
        hECcB:
        if (!isset($u_EX6['fps'])) {
            goto bS6T8;
        }
        goto yP6fr;
        sNp1z:
        rLUej:
        goto iCLUr;
        Mz3Zc:
        if (!(isset($u_EX6['change_status']) && $u_EX6['change_status'])) {
            goto FDbML;
        }
        goto ToolI;
        WbJBU:
        unset($GjBi3['thumbnail']);
        goto i8Tc3;
        LN48l:
        if (!$fTkob->update($GjBi3)) {
            goto O6Cau;
        }
        goto Mz3Zc;
        mq0bC:
        try {
            goto tdMq3;
            mo4bN:
            $GjBi3['thumbnail_id'] = $oEyCz['id'];
            goto Xlbno;
            tdMq3:
            $oEyCz = $this->u1HPE->storeSingleFile(new class($u_EX6['thumbnail']) implements SingleUploadInterface
            {
                private $VCrIB;
                public function __construct($k2MU3)
                {
                    $this->VCrIB = $k2MU3;
                }
                public function getFile()
                {
                    return $this->VCrIB;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto mo4bN;
            Xlbno:
            $GjBi3['thumbnail'] = $oEyCz['filename'];
            goto HOwnj;
            HOwnj:
        } catch (\Throwable $oKDQw) {
            Log::warning("VPegVN4NByLqJ thumbnail store failed: " . $oKDQw->getMessage());
        }
        goto sNp1z;
        k3CqG:
        BxJhH:
        goto r8YFu;
        Q_iRU:
        Log::warning("VPegVN4NByLqJ metadata store failed for unknown reason ... " . $N2oAf);
        goto tva4y;
        r8YFu:
        if (!isset($u_EX6['resolution'])) {
            goto GxIrF;
        }
        goto hke5A;
        LKGDK:
        O6Cau:
        goto Q_iRU;
        hke5A:
        $GjBi3['resolution'] = $u_EX6['resolution'];
        goto DKbRy;
        UcUu5:
        $GjBi3 = [];
        goto S0JJ1;
        tva4y:
        throw new \Exception("VPegVN4NByLqJ metadata store failed for unknown reason ... " . $N2oAf);
        goto o_tXZ;
        iCLUr:
        if (!isset($u_EX6['duration'])) {
            goto BxJhH;
        }
        goto FIkPl;
        ckGTF:
        $GjBi3['thumbnail'] = $u_EX6['thumbnail_url'];
        goto AmMc4;
        Xg0by:
        FDbML:
        goto FoHp1;
        mZ36c:
        $fTkob = VPegVN4NByLqJ::findOrFail($N2oAf);
        goto UcUu5;
        ToolI:
        $this->u1HPE->updateFile($fTkob->getAttribute('id'), A9q1Lm9l5QixG::PROCESSING);
        goto Xg0by;
        FoHp1:
        return $fTkob->getView();
        goto LKGDK;
        yP6fr:
        $GjBi3['fps'] = $u_EX6['fps'];
        goto kmUGa;
        RyZal:
        if (!isset($u_EX6['thumbnail'])) {
            goto rLUej;
        }
        goto mq0bC;
        S0JJ1:
        if (!isset($u_EX6['thumbnail_url'])) {
            goto LXrUi;
        }
        goto ckGTF;
        zfnhj:
        if (!$fTkob->Rp1Uk) {
            goto OgjIE;
        }
        goto WbJBU;
        FIkPl:
        $GjBi3['duration'] = $u_EX6['duration'];
        goto k3CqG;
        kmUGa:
        bS6T8:
        goto zfnhj;
        o_tXZ:
    }
    public function createThumbnail(string $bM41o) : void
    {
        goto iKDes;
        WWoXP:
        $e2mfP = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto tJ1QC;
        a93mJ:
        if (!(!$this->zbU8n->directoryExists($murmt) && empty($fTkob->mcxyVxlfFDn()))) {
            goto vezCq;
        }
        goto WWoXP;
        tJ1QC:
        try {
            goto HQyfH;
            b5iba:
            $hiS17 = $tGq5d->get('QueueUrl');
            goto RbBbn;
            RbBbn:
            $e2mfP->sendMessage(['QueueUrl' => $hiS17, 'MessageBody' => json_encode(['file_path' => $fTkob->getLocation()])]);
            goto IB3ej;
            HQyfH:
            $tGq5d = $e2mfP->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto b5iba;
            IB3ej:
        } catch (\Throwable $a9JiP) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$a9JiP->getMessage()}");
        }
        goto HvdZV;
        hIo4x:
        $murmt = "v2/hls/thumbnails/{$bM41o}/";
        goto a93mJ;
        iKDes:
        Log::info("Use Lambda to generate thumbnail for video: " . $bM41o);
        goto ymN2z;
        HvdZV:
        vezCq:
        goto fLsd6;
        ymN2z:
        $fTkob = VPegVN4NByLqJ::findOrFail($bM41o);
        goto hIo4x;
        fLsd6:
    }
    public function mZLlJCCwERM(string $bM41o) : void
    {
        goto qhAKR;
        YFV5B:
        Log::error("Message back with success data but not found thumbnail " . $bM41o);
        goto yf3fk;
        ApP3Z:
        if (!(count($lak6A) === 0)) {
            goto mKv4O;
        }
        goto JeAep;
        yf3fk:
        throw new \Exception("Message back with success data but not found thumbnail " . $bM41o);
        goto C0CTB;
        fOd3c:
        $lak6A = $this->zbU8n->files($murmt);
        goto ApP3Z;
        JeAep:
        Log::error("Message back with success data but not found thumbnail files " . $bM41o);
        goto zJgwh;
        C0CTB:
        xWuDk:
        goto fOd3c;
        Nn21T:
        $murmt = "v2/hls/thumbnails/{$bM41o}/";
        goto FdIjn;
        AdGb5:
        mKv4O:
        goto xJgeW;
        qhAKR:
        $fTkob = VPegVN4NByLqJ::findOrFail($bM41o);
        goto Nn21T;
        FdIjn:
        if ($this->zbU8n->directoryExists($murmt)) {
            goto xWuDk;
        }
        goto YFV5B;
        zJgwh:
        throw new \Exception("Message back with success data but not found thumbnail files " . $bM41o);
        goto AdGb5;
        xJgeW:
        $fTkob->update(['generated_previews' => $murmt]);
        goto m7Ww0;
        m7Ww0:
    }
    public function getThumbnails(string $bM41o) : array
    {
        $fTkob = VPegVN4NByLqJ::findOrFail($bM41o);
        return $fTkob->getThumbnails();
    }
    public function getMedia(string $bM41o) : array
    {
        $aB0a5 = Media::findOrFail($bM41o);
        return $aB0a5->getView();
    }
}
