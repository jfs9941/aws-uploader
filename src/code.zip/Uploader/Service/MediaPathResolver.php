<?php
declare(strict_types=1);

namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Enum\FileDriver;

final class MediaPathResolver
{
    private $bucket;
    private $s3BaseUrl;
    private $localStorage;

    public function __construct(string $bucket,
        string $s3BaseUrl,
        Filesystem $localStorage)
    {
        $this->bucket = $bucket;
        $this->s3BaseUrl = $s3BaseUrl;
        $this->localStorage = $localStorage;
    }

    public function resolve(BaseFileModel $fileModel): string
    {
        if (FileDriver::S3 == $fileModel->getAttribute('driver')) {
            return 's3://'.$this->bucket.'/'.$fileModel->getAttribute('filename');
        }

        return $this->localStorage->url($fileModel->getAttribute('filename'));
    }

    public function resolveForUrl(?string $url): ?string
    {
        if ($url) {
            if (str_contains($url, $this->bucket)) {
                $path = parse_url($url, PHP_URL_PATH);

                return 's3://'.$this->bucket.'/'.ltrim($path, '/');
            }
        }

        return null;
    }

    public function resolveForPath(string $path): string
    {
        return 's3://'.$this->bucket.'/'.$path;
    }
}
