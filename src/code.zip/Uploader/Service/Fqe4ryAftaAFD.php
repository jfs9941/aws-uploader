<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\HpFoUL2Zq7Sem;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Core\Observer\KSSLW3aWl2cII;
use Jfs\Uploader\Core\Observer\AkWmj2jJHpl00;
use Jfs\Uploader\Core\JUuiYtFOGewFF;
use Jfs\Uploader\Core\QUscYuYxMDsuz;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
use Jfs\Uploader\Exception\JQsXv6HTe1n89;
use Jfs\Uploader\Exception\AJ3Q8FcxdzdHb;
use Jfs\Uploader\Service\FileResolver\EB6jZiLmFzkB8;
use Ramsey\Uuid\Uuid;
final class Fqe4ryAftaAFD
{
    private $HgY_O;
    private $fodJQ;
    private $qrvF0;
    public function __construct($TDMcm, $nsgrL, $eG_Pc)
    {
        goto JXmEm;
        G0CDP:
        $this->fodJQ = $nsgrL;
        goto BfxiF;
        JXmEm:
        $this->HgY_O = $TDMcm;
        goto G0CDP;
        BfxiF:
        $this->qrvF0 = $eG_Pc;
        goto w1NlV;
        w1NlV:
    }
    public function mPmak256rWq($klbBD)
    {
        goto PcyPI;
        UouTf:
        $eppkf = $klbBD->getFile();
        goto w4EpB;
        w4EpB:
        return $this->ml42v8GMQn1($eppkf->extension(), I2Tze5VZcqaXS::S3, null, $klbBD->options());
        goto FgyKA;
        FgyKA:
        fp3vY:
        goto udajr;
        PcyPI:
        if (!$klbBD instanceof SingleUploadInterface) {
            goto fp3vY;
        }
        goto UouTf;
        udajr:
        return $this->ml42v8GMQn1($klbBD['file_extension'], 's3' === $klbBD['driver'] ? I2Tze5VZcqaXS::S3 : I2Tze5VZcqaXS::LOCAL);
        goto uHMs7;
        uHMs7:
    }
    public function mNcRAQdwyxl(string $ElvKF)
    {
        goto C7BYd;
        srUyX:
        $TFA4Z->exists = true;
        goto Sxt8b;
        C7BYd:
        $q8Cz4 = config('upload.attachment_model')::findOrFail($ElvKF);
        goto x_MCh;
        Sxt8b:
        $TFA4Z->setRawAttributes($q8Cz4->getAttributes());
        goto i6wCu;
        x_MCh:
        $TFA4Z = $this->ml42v8GMQn1($q8Cz4->getAttribute('type'), $q8Cz4->getAttribute('driver'), $q8Cz4->getAttribute('id'));
        goto srUyX;
        i6wCu:
        return $TFA4Z;
        goto mWdZe;
        mWdZe:
    }
    public function mN1PoxnHLL6(string $klJj6) : HpFoUL2Zq7Sem
    {
        goto awWzK;
        rBRk4:
        if ($mHWzt) {
            goto iCHCR;
        }
        goto EifhN;
        Qf24s:
        hDRfx:
        goto FEC7U;
        CKDxy:
        if (!$xf_XV) {
            goto hDRfx;
        }
        goto Ae7os;
        Ae7os:
        $f4Kkc = QUscYuYxMDsuz::mEDJWbnim9M($xf_XV);
        goto yTcu9;
        G1oRT:
        $xf_XV = json_decode($mHWzt, true);
        goto CKDxy;
        FEC7U:
        throw new JQsXv6HTe1n89('metadata file not found');
        goto vBUff;
        awWzK:
        $mHWzt = $this->fodJQ->get($klJj6);
        goto rBRk4;
        AhWvK:
        iCHCR:
        goto G1oRT;
        EifhN:
        $mHWzt = $this->qrvF0->get($klJj6);
        goto AhWvK;
        yTcu9:
        return $this->ml42v8GMQn1($f4Kkc->iYo0H, $f4Kkc->mCI3IPXqltF(), $f4Kkc->filename);
        goto Qf24s;
        vBUff:
    }
    private function ml42v8GMQn1(string $YoNIV, $e3mve, ?string $ElvKF = null, array $rXnFu = [])
    {
        goto s28Fz;
        n8ygx:
        xf_QK:
        goto coLq5;
        AOcsc:
        u7JUX:
        goto i3w6x;
        R17JV:
        $BlNzA->mMajp12kCYR(new KSSLW3aWl2cII($BlNzA));
        goto QQkmB;
        QVaqO:
        foreach ($this->HgY_O as $bUBvu) {
            goto BvLvn;
            mwYPh:
            wqCvc:
            goto kMAK9;
            BvLvn:
            if (!$bUBvu->mYFN2fW6LzZ($BlNzA)) {
                goto wqCvc;
            }
            goto HCMqD;
            kMAK9:
            Va32o:
            goto UMyVq;
            HCMqD:
            return $BlNzA->initLocation($bUBvu->m35XKxRLotY($BlNzA));
            goto mwYPh;
            UMyVq:
        }
        goto n8ygx;
        s28Fz:
        $ElvKF = $ElvKF ?? Uuid::uuid4()->getHex()->toString();
        goto BhSAj;
        coLq5:
        throw new AJ3Q8FcxdzdHb("not support file type {$YoNIV}");
        goto KZOc6;
        BhSAj:
        switch ($YoNIV) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $BlNzA = WKX0l52zWptlF::createFromScratch($ElvKF, $YoNIV);
                goto u7JUX;
            case 'mp4':
            case 'mov':
                $BlNzA = UMeQT1ArE1U05::createFromScratch($ElvKF, $YoNIV);
                goto u7JUX;
            case 'pdf':
                $BlNzA = JUuiYtFOGewFF::createFromScratch($ElvKF, $YoNIV);
                goto u7JUX;
            default:
                throw new AJ3Q8FcxdzdHb("not support file type {$YoNIV}");
        }
        goto dFA9S;
        dFA9S:
        tvxYN:
        goto AOcsc;
        QQkmB:
        $BlNzA->mMajp12kCYR(new AkWmj2jJHpl00($BlNzA, $this->qrvF0, $rXnFu));
        goto QVaqO;
        i3w6x:
        $BlNzA = $BlNzA->mPnbTRgHcvw($e3mve);
        goto R17JV;
        KZOc6:
    }
}
