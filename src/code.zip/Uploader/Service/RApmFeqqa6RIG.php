<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\O8RzIjGmSN6fG;
final class RApmFeqqa6RIG implements VideoPostHandleServiceInterface
{
    private $Pbvpl;
    private $ifs25;
    public function __construct(UploadServiceInterface $cTMlz, Filesystem $PQlIa)
    {
        $this->Pbvpl = $cTMlz;
        $this->ifs25 = $PQlIa;
    }
    public function saveMetadata(string $PV4mw, array $kvLls)
    {
        goto q72wg;
        UiwwK:
        Log::warning("CSQMvXC33KbbS metadata store failed for unknown reason ... " . $PV4mw);
        goto m1axU;
        vX3tN:
        $KYBqU['resolution'] = $kvLls['resolution'];
        goto a0jkM;
        oZnos:
        $this->Pbvpl->updateFile($vtvs_->getAttribute('id'), O8RzIjGmSN6fG::PROCESSING);
        goto qqLha;
        Z9qBT:
        if (!isset($kvLls['fps'])) {
            goto dHR5U;
        }
        goto Rue9K;
        szWjE:
        MUn0E:
        goto UfXQi;
        fthg1:
        return $vtvs_->getView();
        goto I1gSK;
        OinjN:
        if (!isset($kvLls['duration'])) {
            goto MUn0E;
        }
        goto tkdLB;
        c4ewr:
        dHR5U:
        goto IvJZt;
        v0HZd:
        try {
            goto XTjug;
            EyKZT:
            $KYBqU['thumbnail'] = $IlGiN['filename'];
            goto LgW20;
            XTjug:
            $IlGiN = $this->Pbvpl->storeSingleFile(new class($kvLls['thumbnail']) implements SingleUploadInterface
            {
                private $AO_te;
                public function __construct($nKKn0)
                {
                    $this->AO_te = $nKKn0;
                }
                public function getFile()
                {
                    return $this->AO_te;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto zx205;
            zx205:
            $KYBqU['thumbnail_id'] = $IlGiN['id'];
            goto EyKZT;
            LgW20:
        } catch (\Throwable $Z8tVK) {
            Log::warning("CSQMvXC33KbbS thumbnail store failed: " . $Z8tVK->getMessage());
        }
        goto iijr0;
        I1gSK:
        pHELz:
        goto UiwwK;
        qqLha:
        VRfDQ:
        goto fthg1;
        IvJZt:
        if (!$vtvs_->g97cm) {
            goto gpoyn;
        }
        goto taHBb;
        m1axU:
        throw new \Exception("CSQMvXC33KbbS metadata store failed for unknown reason ... " . $PV4mw);
        goto F3oO1;
        iijr0:
        SqfNu:
        goto OinjN;
        taHBb:
        unset($KYBqU['thumbnail']);
        goto FLZuX;
        tkdLB:
        $KYBqU['duration'] = $kvLls['duration'];
        goto szWjE;
        pFgCh:
        if (!isset($kvLls['thumbnail'])) {
            goto SqfNu;
        }
        goto v0HZd;
        Rue9K:
        $KYBqU['fps'] = $kvLls['fps'];
        goto c4ewr;
        ynFoH:
        if (!$vtvs_->update($KYBqU)) {
            goto pHELz;
        }
        goto UXcja;
        UXcja:
        if (!(isset($kvLls['change_status']) && $kvLls['change_status'])) {
            goto VRfDQ;
        }
        goto oZnos;
        B5XN7:
        $KYBqU = [];
        goto pFgCh;
        a0jkM:
        SraU8:
        goto Z9qBT;
        FLZuX:
        gpoyn:
        goto ynFoH;
        UfXQi:
        if (!isset($kvLls['resolution'])) {
            goto SraU8;
        }
        goto vX3tN;
        q72wg:
        $vtvs_ = CSQMvXC33KbbS::findOrFail($PV4mw);
        goto B5XN7;
        F3oO1:
    }
    public function createThumbnail(string $vChc2) : void
    {
        goto j835_;
        CDLil:
        $vtvs_ = CSQMvXC33KbbS::findOrFail($vChc2);
        goto yTlFf;
        lE31z:
        try {
            goto h4F1A;
            h4F1A:
            $Z3VUT = $ssyh7->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto v3k5f;
            v3k5f:
            $cyQyu = $Z3VUT->get('QueueUrl');
            goto hX5f9;
            hX5f9:
            $ssyh7->sendMessage(['QueueUrl' => $cyQyu, 'MessageBody' => json_encode(['file_path' => $vtvs_->getLocation()])]);
            goto iK8pO;
            iK8pO:
        } catch (\Throwable $Uh0GK) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$Uh0GK->getMessage()}");
        }
        goto FrQz2;
        yTlFf:
        $iSO5V = "v2/hls/thumbnails/{$vChc2}/";
        goto aboQv;
        FrQz2:
        uMxub:
        goto DcmaB;
        j835_:
        Log::info("Use Lambda to generate thumbnail for video: " . $vChc2);
        goto CDLil;
        Oba8y:
        $ssyh7 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto lE31z;
        aboQv:
        if (!(!$this->ifs25->directoryExists($iSO5V) && empty($vtvs_->m3eM3et8YPc()))) {
            goto uMxub;
        }
        goto Oba8y;
        DcmaB:
    }
    public function mBq8TUle8Qv(string $vChc2) : void
    {
        goto WdAiC;
        A0ka8:
        $iSO5V = "v2/hls/thumbnails/{$vChc2}/";
        goto Pj1T3;
        lWL76:
        throw new \Exception("Message back with success data but not found thumbnail " . $vChc2);
        goto lrftG;
        n_JH3:
        throw new \Exception("Message back with success data but not found thumbnail files " . $vChc2);
        goto W7fZs;
        Ks93F:
        $TgJkF = $this->ifs25->files($iSO5V);
        goto eD6hg;
        lrftG:
        CmykH:
        goto Ks93F;
        emswD:
        Log::error("Message back with success data but not found thumbnail files " . $vChc2);
        goto n_JH3;
        WdAiC:
        $vtvs_ = CSQMvXC33KbbS::findOrFail($vChc2);
        goto A0ka8;
        eD6hg:
        if (!(count($TgJkF) === 0)) {
            goto qbJhO;
        }
        goto emswD;
        sDxBu:
        $vtvs_->update(['generated_previews' => $iSO5V]);
        goto ksC9O;
        tdMDn:
        Log::error("Message back with success data but not found thumbnail " . $vChc2);
        goto lWL76;
        W7fZs:
        qbJhO:
        goto sDxBu;
        Pj1T3:
        if ($this->ifs25->directoryExists($iSO5V)) {
            goto CmykH;
        }
        goto tdMDn;
        ksC9O:
    }
    public function getThumbnails(string $vChc2) : array
    {
        $vtvs_ = CSQMvXC33KbbS::findOrFail($vChc2);
        return $vtvs_->getThumbnails();
    }
}
