<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
use Illuminate\Contracts\Filesystem\Filesystem;
final class KiBRYQgrRVRtv
{
    private $VzV90;
    private $dBqNw;
    private $pXh9P;
    public function __construct(string $v4kIW, string $NBo4T, Filesystem $TWZho)
    {
        goto Vu13T;
        jZM2O:
        $this->pXh9P = $TWZho;
        goto ygFfG;
        Vu13T:
        $this->VzV90 = $v4kIW;
        goto ng0HA;
        ng0HA:
        $this->dBqNw = $NBo4T;
        goto jZM2O;
        ygFfG:
    }
    public function maaEYjSSTdf(Rqw1PJIt1YU1r $ift9y) : string
    {
        goto qUJUw;
        qUJUw:
        if (!(YOaiWCgFM7tRK::S3 == $ift9y->getAttribute('driver'))) {
            goto trPf_;
        }
        goto tttQW;
        gPyeX:
        return $this->pXh9P->url($ift9y->getAttribute('filename'));
        goto zVfZS;
        tttQW:
        return 's3://' . $this->VzV90 . '/' . $ift9y->getAttribute('filename');
        goto Nj17p;
        Nj17p:
        trPf_:
        goto gPyeX;
        zVfZS:
    }
    public function mWj7taGWPTi(?string $wvH7y) : ?string
    {
        goto soHSW;
        UOH7c:
        $b0LKC = parse_url($wvH7y, PHP_URL_PATH);
        goto c2757;
        soHSW:
        if (!$wvH7y) {
            goto ccGqK;
        }
        goto FcTUh;
        fETDH:
        GqsHx:
        goto Nsioi;
        FcTUh:
        if (!EVeqX($wvH7y, $this->VzV90)) {
            goto GqsHx;
        }
        goto UOH7c;
        c2757:
        return 's3://' . $this->VzV90 . '/' . ltrim($b0LKC, '/');
        goto fETDH;
        Nsioi:
        ccGqK:
        goto dBIQo;
        dBIQo:
        return null;
        goto C4_J2;
        C4_J2:
    }
    public function m3Csu51ee5L(string $b0LKC) : string
    {
        return 's3://' . $this->VzV90 . '/' . $b0LKC;
    }
}
