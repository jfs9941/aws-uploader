<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
use Illuminate\Contracts\Filesystem\Filesystem;
final class HHzuA41ccyXtA
{
    private $F_eut;
    private $cfpCv;
    private $uTYgy;
    public function __construct(string $Jkr71, string $Cd9fC, Filesystem $kVG4M)
    {
        goto kgh9_;
        a2OyL:
        $this->uTYgy = $kVG4M;
        goto ig_1X;
        lpZKi:
        $this->cfpCv = $Cd9fC;
        goto a2OyL;
        kgh9_:
        $this->F_eut = $Jkr71;
        goto lpZKi;
        ig_1X:
    }
    public function mhI4VtxS5Px(UfttW7MErNAIK $gYpY3) : string
    {
        goto UwNRG;
        m10cf:
        return $this->uTYgy->url($gYpY3->getAttribute('filename'));
        goto T5fx9;
        sa8cn:
        return 's3://' . $this->F_eut . '/' . $gYpY3->getAttribute('filename');
        goto NE4qD;
        NE4qD:
        q6v2Y:
        goto m10cf;
        UwNRG:
        if (!(LrHrisEWQ9E5o::S3 == $gYpY3->getAttribute('driver'))) {
            goto q6v2Y;
        }
        goto sa8cn;
        T5fx9:
    }
    public function mqIYoB5vSE8(?string $Qtoey) : ?string
    {
        goto b5VGL;
        uhiTE:
        if (!Rt6LV($Qtoey, $this->F_eut)) {
            goto hYJgv;
        }
        goto QfI8A;
        QfI8A:
        $uUtRl = parse_url($Qtoey, PHP_URL_PATH);
        goto ZfQxp;
        XGV2X:
        VqRlh:
        goto uk84O;
        b5VGL:
        if (!$Qtoey) {
            goto VqRlh;
        }
        goto uhiTE;
        uk84O:
        return null;
        goto K0igT;
        MdD6G:
        hYJgv:
        goto XGV2X;
        ZfQxp:
        return 's3://' . $this->F_eut . '/' . ltrim($uUtRl, '/');
        goto MdD6G;
        K0igT:
    }
    public function mfUYQYCCxiQ(string $uUtRl) : string
    {
        return 's3://' . $this->F_eut . '/' . $uUtRl;
    }
}
