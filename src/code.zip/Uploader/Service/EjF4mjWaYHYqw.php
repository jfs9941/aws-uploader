<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
use Illuminate\Contracts\Filesystem\Filesystem;
final class EjF4mjWaYHYqw
{
    private $S7Zrn;
    private $BnY2F;
    private $niO3l;
    public function __construct(string $xYZ3A, string $sGcVC, Filesystem $xuow1)
    {
        goto Lnnoc;
        lM6jd:
        $this->BnY2F = $sGcVC;
        goto HkkSK;
        Lnnoc:
        $this->S7Zrn = $xYZ3A;
        goto lM6jd;
        HkkSK:
        $this->niO3l = $xuow1;
        goto HqqZv;
        HqqZv:
    }
    public function m1CbP8mAqVj(OXsaQ69LP2fiA $L7rEe) : string
    {
        goto LhwKp;
        SXAlj:
        return $this->niO3l->url($L7rEe->getAttribute('filename'));
        goto lkC4O;
        LhwKp:
        if (!(GoWVLKcTGnffy::S3 == $L7rEe->getAttribute('driver'))) {
            goto QVV70;
        }
        goto N8W0v;
        xgNgr:
        QVV70:
        goto SXAlj;
        N8W0v:
        return 's3://' . $this->S7Zrn . '/' . $L7rEe->getAttribute('filename');
        goto xgNgr;
        lkC4O:
    }
    public function mYtzp5wmt0Q(?string $RRgGr) : ?string
    {
        goto w23ya;
        w23ya:
        if (!$RRgGr) {
            goto lPyEq;
        }
        goto APojQ;
        kD2cw:
        return 's3://' . $this->S7Zrn . '/' . ltrim($yRiLu, '/');
        goto IH3e1;
        APojQ:
        if (!nijPH($RRgGr, $this->S7Zrn)) {
            goto gTypJ;
        }
        goto F5Rk9;
        F5Rk9:
        $yRiLu = parse_url($RRgGr, PHP_URL_PATH);
        goto kD2cw;
        BIYr4:
        return null;
        goto bo8Ba;
        OuQOZ:
        lPyEq:
        goto BIYr4;
        IH3e1:
        gTypJ:
        goto OuQOZ;
        bo8Ba:
    }
    public function mCs8X0WLjcY(string $yRiLu) : string
    {
        return 's3://' . $this->S7Zrn . '/' . $yRiLu;
    }
}
