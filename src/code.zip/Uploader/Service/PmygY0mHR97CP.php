<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\EpMPhiTVzNYqA;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class PmygY0mHR97CP implements VideoPostHandleServiceInterface
{
    private $xvFqu;
    private $gErml;
    public function __construct(UploadServiceInterface $MhOtU, Filesystem $DFpIk)
    {
        $this->xvFqu = $MhOtU;
        $this->gErml = $DFpIk;
    }
    public function saveMetadata(string $J_scC, array $zkqCI)
    {
        goto E7PgL;
        yqXpP:
        eSS0h:
        goto FRUKf;
        bUM0n:
        $ck1U4 = [];
        goto UBEij;
        jdt0K:
        $ck1U4['fps'] = $zkqCI['fps'];
        goto yqXpP;
        N3EKf:
        if (!(isset($zkqCI['change_status']) && $zkqCI['change_status'])) {
            goto QK2xx;
        }
        goto alspu;
        Vv1wE:
        return $Zpy0I->getView();
        goto Tg2M3;
        FRUKf:
        if (!$Zpy0I->r1f8r) {
            goto hesNU;
        }
        goto DsIMe;
        UBEij:
        if (!isset($zkqCI['thumbnail_url'])) {
            goto Tmg8L;
        }
        goto IuYsn;
        RkJ7G:
        if (!isset($zkqCI['duration'])) {
            goto ZMJld;
        }
        goto Qv4d2;
        FLssw:
        ZMJld:
        goto Qlhqq;
        JtX_W:
        $ck1U4['resolution'] = $zkqCI['resolution'];
        goto MGwsg;
        JBsUn:
        QK2xx:
        goto Vv1wE;
        Qv4d2:
        $ck1U4['duration'] = $zkqCI['duration'];
        goto FLssw;
        ERo4T:
        Tmg8L:
        goto DPVVZ;
        fglUd:
        hesNU:
        goto NmRNW;
        alspu:
        $this->xvFqu->updateFile($Zpy0I->getAttribute('id'), EpMPhiTVzNYqA::PROCESSING);
        goto JBsUn;
        FQsK3:
        throw new \Exception("BG2FRpwGrKqJx metadata store failed for unknown reason ... " . $J_scC);
        goto deNhW;
        E7PgL:
        $Zpy0I = BG2FRpwGrKqJx::findOrFail($J_scC);
        goto bUM0n;
        UlkWD:
        if (!isset($zkqCI['fps'])) {
            goto eSS0h;
        }
        goto jdt0K;
        rX_zn:
        try {
            goto FTnxZ;
            Q5BhA:
            $ck1U4['thumbnail'] = $cOdCv['filename'];
            goto Jeccx;
            FTnxZ:
            $cOdCv = $this->xvFqu->storeSingleFile(new class($zkqCI['thumbnail']) implements SingleUploadInterface
            {
                private $pnMmg;
                public function __construct($dV9QE)
                {
                    $this->pnMmg = $dV9QE;
                }
                public function getFile()
                {
                    return $this->pnMmg;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto bZT49;
            bZT49:
            $ck1U4['thumbnail_id'] = $cOdCv['id'];
            goto Q5BhA;
            Jeccx:
        } catch (\Throwable $Jtg9A) {
            Log::warning("BG2FRpwGrKqJx thumbnail store failed: " . $Jtg9A->getMessage());
        }
        goto nyG1V;
        MGwsg:
        NwCZ1:
        goto UlkWD;
        NmRNW:
        if (!$Zpy0I->update($ck1U4)) {
            goto WwezT;
        }
        goto N3EKf;
        DsIMe:
        unset($ck1U4['thumbnail']);
        goto fglUd;
        DPVVZ:
        if (!isset($zkqCI['thumbnail'])) {
            goto nEP98;
        }
        goto rX_zn;
        PPTc5:
        Log::warning("BG2FRpwGrKqJx metadata store failed for unknown reason ... " . $J_scC);
        goto FQsK3;
        Tg2M3:
        WwezT:
        goto PPTc5;
        Qlhqq:
        if (!isset($zkqCI['resolution'])) {
            goto NwCZ1;
        }
        goto JtX_W;
        IuYsn:
        $ck1U4['thumbnail'] = $zkqCI['thumbnail_url'];
        goto ERo4T;
        nyG1V:
        nEP98:
        goto RkJ7G;
        deNhW:
    }
    public function createThumbnail(string $rQxXm) : void
    {
        goto wkIJc;
        WK4D9:
        VqhDV:
        goto DVuQ2;
        BdTCF:
        if (!(!$this->gErml->directoryExists($ktqja) && empty($Zpy0I->mHNglQRBQMN()))) {
            goto VqhDV;
        }
        goto faq2o;
        YmwsK:
        try {
            goto YBZ9Z;
            IwEFh:
            $DfMBu->sendMessage(['QueueUrl' => $sO8V2, 'MessageBody' => json_encode(['file_path' => $Zpy0I->getLocation()])]);
            goto JVQYs;
            r12Y4:
            $sO8V2 = $wnmr8->get('QueueUrl');
            goto IwEFh;
            YBZ9Z:
            $wnmr8 = $DfMBu->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto r12Y4;
            JVQYs:
        } catch (\Throwable $XViIf) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$XViIf->getMessage()}");
        }
        goto WK4D9;
        faq2o:
        $DfMBu = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto YmwsK;
        BRudn:
        $ktqja = "v2/hls/thumbnails/{$rQxXm}/";
        goto BdTCF;
        wkIJc:
        Log::info("Use Lambda to generate thumbnail for video: " . $rQxXm);
        goto h1vMv;
        h1vMv:
        $Zpy0I = BG2FRpwGrKqJx::findOrFail($rQxXm);
        goto BRudn;
        DVuQ2:
    }
    public function miVVqqDQMZd(string $rQxXm) : void
    {
        goto WuFcO;
        pABjO:
        throw new \Exception("Message back with success data but not found thumbnail " . $rQxXm);
        goto qkTDT;
        lrRUt:
        if (!(count($oik6g) === 0)) {
            goto YV_Qd;
        }
        goto b5Pkb;
        o7jQP:
        throw new \Exception("Message back with success data but not found thumbnail files " . $rQxXm);
        goto Ocob9;
        qkTDT:
        cN8lN:
        goto KhOro;
        Ocob9:
        YV_Qd:
        goto XOyry;
        b5Pkb:
        Log::error("Message back with success data but not found thumbnail files " . $rQxXm);
        goto o7jQP;
        WuFcO:
        $Zpy0I = BG2FRpwGrKqJx::findOrFail($rQxXm);
        goto LxQ8W;
        XOyry:
        $Zpy0I->update(['generated_previews' => $ktqja]);
        goto sNpJR;
        p654J:
        Log::error("Message back with success data but not found thumbnail " . $rQxXm);
        goto pABjO;
        KhOro:
        $oik6g = $this->gErml->files($ktqja);
        goto lrRUt;
        LxQ8W:
        $ktqja = "v2/hls/thumbnails/{$rQxXm}/";
        goto mjOsX;
        mjOsX:
        if ($this->gErml->directoryExists($ktqja)) {
            goto cN8lN;
        }
        goto p654J;
        sNpJR:
    }
    public function getThumbnails(string $rQxXm) : array
    {
        $Zpy0I = BG2FRpwGrKqJx::findOrFail($rQxXm);
        return $Zpy0I->getThumbnails();
    }
    public function getMedia(string $rQxXm) : array
    {
        $wiCE2 = Media::findOrFail($rQxXm);
        return $wiCE2->getView();
    }
}
