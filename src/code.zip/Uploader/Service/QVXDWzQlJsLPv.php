<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\PmQuktZiUDRAI;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Core\C1MO7dubi2ia5;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
final class QVXDWzQlJsLPv implements PmQuktZiUDRAI
{
    private $E3QwM;
    private $Urk5D;
    public $GKwe3;
    private $xHPN3;
    private $i2yWR;
    private $nEL6Z;
    public function __construct($VT76j, $ij4ax, $jEp0Y, $MTHZh, $kYPee, $vWt2S)
    {
        goto l5QnX;
        NH5Tw:
        $this->xHPN3 = $MTHZh;
        goto Qq34I;
        l5QnX:
        $this->nEL6Z = $vWt2S;
        goto D1RhG;
        FbUkj:
        $this->Urk5D = $ij4ax;
        goto jBtnk;
        jBtnk:
        $this->GKwe3 = $jEp0Y;
        goto NH5Tw;
        Qq34I:
        $this->i2yWR = $kYPee;
        goto dj2w2;
        D1RhG:
        $this->E3QwM = $VT76j;
        goto FbUkj;
        dj2w2:
    }
    public function resolvePath($mCZRt, $wLwvk = Ef6Dy6MoUDei9::S3) : string
    {
        goto vTcZC;
        fgHSn:
        $mCZRt = $mCZRt->getAttribute('filename');
        goto tLJek;
        p5LJZ:
        return config('upload.home') . '/' . $mCZRt;
        goto HnNQs;
        RTlJ9:
        if (!(!empty($this->xHPN3) && !empty($this->i2yWR))) {
            goto ygMgb;
        }
        goto O066h;
        KeH2_:
        return trim($this->Urk5D, '/') . '/' . $mCZRt;
        goto I55ix;
        BdEE6:
        return trim($this->GKwe3, '/') . '/' . $mCZRt;
        goto R9oCi;
        HnNQs:
        CeLrS:
        goto RTlJ9;
        tLJek:
        nxdB9:
        goto EkooY;
        vTcZC:
        if (!$mCZRt instanceof GSmU4C9IL4AGB) {
            goto nxdB9;
        }
        goto fgHSn;
        hQoBd:
        ygMgb:
        goto FffrP;
        FffrP:
        if (!$this->E3QwM) {
            goto xAY50;
        }
        goto BdEE6;
        O066h:
        return $this->mTl1rtfBeMm($mCZRt);
        goto hQoBd;
        EkooY:
        if (!($wLwvk === Ef6Dy6MoUDei9::LOCAL)) {
            goto CeLrS;
        }
        goto p5LJZ;
        R9oCi:
        xAY50:
        goto KeH2_;
        I55ix:
    }
    public function resolveThumbnail(GSmU4C9IL4AGB $mCZRt) : string
    {
        goto mqaxM;
        XBB8c:
        Nou8m:
        goto AIsWu;
        ovEsu:
        return $this->resolvePath($mCZRt, $mCZRt->getAttribute('driver'));
        goto eTiiQ;
        YLtQ7:
        LmJv9:
        goto Fegi1;
        rC33y:
        if (!$uTfBu) {
            goto Nou8m;
        }
        goto M2rzv;
        H9E4Q:
        if (!$mCZRt instanceof C1MO7dubi2ia5) {
            goto VV6Wl;
        }
        goto mCRJg;
        mqaxM:
        $uTfBu = $mCZRt->getAttribute('thumbnail');
        goto rC33y;
        uqRwo:
        if (!$mCZRt instanceof KyoDVfv3eGItF) {
            goto Q72q9;
        }
        goto ovEsu;
        AIsWu:
        if (!$mCZRt->getAttribute('thumbnail_id')) {
            goto TtvXo;
        }
        goto pqTlF;
        Fegi1:
        TtvXo:
        goto uqRwo;
        M2rzv:
        return $this->url($uTfBu, $mCZRt->getAttribute('driver'));
        goto XBB8c;
        pqTlF:
        $XVScD = KyoDVfv3eGItF::find($mCZRt->getAttribute('thumbnail_id'));
        goto ojJlI;
        YbaLj:
        return '';
        goto Dv_Yl;
        cT5PN:
        VV6Wl:
        goto YbaLj;
        xDJVX:
        return $this->resolvePath($XVScD, $XVScD->getAttribute('driver'));
        goto YLtQ7;
        mCRJg:
        return asset('/img/pdf-preview.svg');
        goto cT5PN;
        ojJlI:
        if (!$XVScD) {
            goto LmJv9;
        }
        goto xDJVX;
        eTiiQ:
        Q72q9:
        goto H9E4Q;
        Dv_Yl:
    }
    private function url($HCRCz, $wLwvk)
    {
        goto S6q0S;
        e1XJ7:
        Sdjyl:
        goto XyreJ;
        D6_Z5:
        return config('upload.home') . '/' . $HCRCz;
        goto e1XJ7;
        XyreJ:
        return $this->resolvePath($HCRCz);
        goto F0aq7;
        S6q0S:
        if (!($wLwvk == Ef6Dy6MoUDei9::LOCAL)) {
            goto Sdjyl;
        }
        goto D6_Z5;
        F0aq7:
    }
    private function mTl1rtfBeMm($HCRCz)
    {
        goto qPTvU;
        B8o98:
        if (!(strpos($HCRCz, 'm3u8') !== false)) {
            goto Xag3d;
        }
        goto NPsJu;
        EXRT9:
        $VMUgK = new UrlSigner($this->xHPN3, $this->nEL6Z->path($this->i2yWR));
        goto nKjTS;
        NPsJu:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto fzzGN;
        qPTvU:
        if (!(strpos($HCRCz, 'https://') === 0)) {
            goto tfCQA;
        }
        goto Bm8yn;
        l0mR9:
        $wZEuG = now()->addMinutes(60)->timestamp;
        goto EXRT9;
        nKjTS:
        return $VMUgK->getSignedUrl($this->GKwe3 . '/' . $HCRCz, $wZEuG);
        goto qw_pK;
        Bm8yn:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto VChDu;
        fzzGN:
        Xag3d:
        goto l0mR9;
        VChDu:
        tfCQA:
        goto B8o98;
        qw_pK:
    }
    public function resolvePathForHlsVideo(AelPShnd8pMtD $aHaxS, $gnS3j = false) : string
    {
        goto A7XHg;
        XMIOx:
        return $this->GKwe3 . '/' . $aHaxS->getAttribute('hls_path');
        goto XDcXW;
        A7XHg:
        if ($aHaxS->getAttribute('hls_path')) {
            goto bpgvT;
        }
        goto lM8xw;
        OUvi9:
        bpgvT:
        goto XMIOx;
        lM8xw:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto OUvi9;
        XDcXW:
    }
    public function resolvePathForHlsVideos()
    {
        goto s2ki9;
        KTFw8:
        $EWfpN = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto z2ev4;
        z2ev4:
        $q82m6 = $EWfpN->getSignedCookie(['key_pair_id' => $this->xHPN3, 'private_key' => $this->nEL6Z->path($this->i2yWR), 'policy' => $k7eE0]);
        goto G2_Fv;
        SEy0Y:
        $k7eE0 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $onVj9), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $wZEuG]]]]]);
        goto KTFw8;
        zMYqS:
        $onVj9 = $this->GKwe3 . '/v2/hls/';
        goto SEy0Y;
        s2ki9:
        $wZEuG = now()->addDays(3)->timestamp;
        goto zMYqS;
        G2_Fv:
        return [$q82m6, $wZEuG];
        goto JvBCA;
        JvBCA:
    }
}
