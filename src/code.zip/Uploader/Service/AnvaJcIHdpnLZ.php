<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\PLPNmbBnD48xL;
use Jfs\Uploader\Core\SYLdN2QnIYYwa;
use Jfs\Uploader\Core\McnafHoTolEIL;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Jfs\Uploader\Exception\HAdknCimVLDdp;
use Jfs\Uploader\Exception\Yhh7VdR99pXtm;
use Jfs\Uploader\Exception\J2167am6BJakj;
use Jfs\Uploader\Service\Mw0dAyuvhKDel;
use Illuminate\Contracts\Filesystem\Filesystem;
final class AnvaJcIHdpnLZ implements UploadServiceInterface
{
    private $PcAMf;
    private $Ybatl;
    private $sKQBJ;
    private $cxNqK;
    public function __construct(Mw0dAyuvhKDel $Rph7F, Filesystem $FHlTP, Filesystem $F1Ry9, string $ig4cC)
    {
        goto hJwb2;
        PUh7G:
        $this->cxNqK = $ig4cC;
        goto RYOZj;
        hJwb2:
        $this->PcAMf = $Rph7F;
        goto PqVzQ;
        PqVzQ:
        $this->Ybatl = $FHlTP;
        goto HyCi8;
        HyCi8:
        $this->sKQBJ = $F1Ry9;
        goto PUh7G;
        RYOZj:
    }
    public function storeSingleFile(SingleUploadInterface $RNNXs) : array
    {
        goto Eyt2v;
        ly0I5:
        if (false !== $K_YMm && $mz56v instanceof PLPNmbBnD48xL) {
            goto de8KO;
        }
        goto A3W6g;
        zWNYz:
        $K_YMm = $this->sKQBJ->putFileAs(dirname($mz56v->getLocation()), $RNNXs->getFile(), $mz56v->getFilename() . '.' . $mz56v->getExtension(), ['visibility' => 'public']);
        goto ly0I5;
        oaQla:
        i0IwH:
        goto epUqq;
        A3W6g:
        throw new \LogicException('File upload failed, check permissions');
        goto UEJ8N;
        Eyt2v:
        $mz56v = $this->PcAMf->mQjJoIWKZGy($RNNXs);
        goto zWNYz;
        UEJ8N:
        goto i0IwH;
        goto mHkfB;
        mHkfB:
        de8KO:
        goto A0aah;
        epUqq:
        return $mz56v->getView();
        goto ylgM0;
        A0aah:
        $mz56v->mo8ljKgMJTJ(IfP50GBBbx63a::UPLOADED);
        goto oaQla;
        ylgM0:
    }
    public function storePreSignedFile(array $tN7M0)
    {
        goto ZpDri;
        ZpDri:
        $mz56v = $this->PcAMf->mQjJoIWKZGy($tN7M0);
        goto OjChm;
        OjChm:
        $LlwTr = McnafHoTolEIL::m6kvMwmvowU($mz56v, $this->Ybatl, $this->sKQBJ, $this->cxNqK, true);
        goto bN021;
        bN021:
        $LlwTr->mDFPWp3g70A($tN7M0['mime'], $tN7M0['file_size'], $tN7M0['chunk_size'], $tN7M0['checksums'], $tN7M0['user_id'], $tN7M0['driver']);
        goto fnIoo;
        LcutZ:
        return ['filename' => $LlwTr->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $LlwTr->mTXe5sX9ImK()];
        goto fyFa2;
        fnIoo:
        $LlwTr->mNajreqTIRK();
        goto LcutZ;
        fyFa2:
    }
    public function updatePreSignedFile(string $pX6WZ, int $xEjVb)
    {
        goto ie3rb;
        ie3rb:
        $LlwTr = McnafHoTolEIL::mCw4yOZBMLn($pX6WZ, $this->Ybatl, $this->sKQBJ, $this->cxNqK);
        goto qE3EU;
        lFxX5:
        iIAPQ:
        goto t2vP3;
        qE3EU:
        switch ($xEjVb) {
            case IfP50GBBbx63a::UPLOADED:
                $LlwTr->mdDhYTZHeh1();
                goto iIAPQ;
            case IfP50GBBbx63a::PROCESSING:
                $LlwTr->mMN16ytbF2G();
                goto iIAPQ;
            case IfP50GBBbx63a::FINISHED:
                $LlwTr->mhF86wltUF5();
                goto iIAPQ;
            case IfP50GBBbx63a::ABORTED:
                $LlwTr->mRB36QVvSnU();
                goto iIAPQ;
        }
        goto EuOm_;
        EuOm_:
        l7it8:
        goto lFxX5;
        t2vP3:
    }
    public function completePreSignedFile(string $pX6WZ, array $sYIWJ)
    {
        goto EmQ8R;
        JDKai:
        $LlwTr->muHFWbWFrae()->mwJqYjbl9h0($sYIWJ);
        goto zWE9K;
        EmQ8R:
        $LlwTr = McnafHoTolEIL::mCw4yOZBMLn($pX6WZ, $this->Ybatl, $this->sKQBJ, $this->cxNqK);
        goto JDKai;
        Sl1oH:
        return ['path' => $LlwTr->getFile()->getView()['path'], 'thumbnail' => $LlwTr->getFile()->nuqvM, 'id' => $pX6WZ];
        goto vYv6H;
        zWE9K:
        $LlwTr->mdDhYTZHeh1();
        goto Sl1oH;
        vYv6H:
    }
    public function updateFile(string $pX6WZ, int $xEjVb) : SYLdN2QnIYYwa
    {
        goto wtGGB;
        wtGGB:
        $mz56v = $this->PcAMf->mUrMbdZyAMf($pX6WZ);
        goto gAxLN;
        dkDqj:
        return $mz56v;
        goto IupYX;
        gAxLN:
        $mz56v->mo8ljKgMJTJ($xEjVb);
        goto dkDqj;
        IupYX:
    }
}
