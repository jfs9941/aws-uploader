<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\MB8DYpNdVV1bz;
use Jfs\Uploader\Core\PaQmIZL22EnpA;
use Jfs\Uploader\Core\Q4cNg0cF0Oivx;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Jfs\Uploader\Exception\VSaAUeOOPZiL5;
use Jfs\Uploader\Exception\OLKFtR17budEQ;
use Jfs\Uploader\Exception\IgLoDg5bjroxA;
use Jfs\Uploader\Service\CYgJOMj8wExPk;
use Illuminate\Contracts\Filesystem\Filesystem;
final class IZmBxrHFIfA2p implements UploadServiceInterface
{
    private $tG6LD;
    private $P8Yzg;
    private $Lrbr9;
    private $TRmgk;
    public function __construct(CYgJOMj8wExPk $rLTAf, Filesystem $jT0xz, Filesystem $x4E8s, string $gWITH)
    {
        goto D51iW;
        D51iW:
        $this->tG6LD = $rLTAf;
        goto SVtLv;
        EoABe:
        $this->Lrbr9 = $x4E8s;
        goto dLGJb;
        dLGJb:
        $this->TRmgk = $gWITH;
        goto uUm3r;
        SVtLv:
        $this->P8Yzg = $jT0xz;
        goto EoABe;
        uUm3r:
    }
    public function storeSingleFile(SingleUploadInterface $yvZyv) : array
    {
        goto WeKR6;
        uFcdo:
        return $RCdwx->getView();
        goto SQLJm;
        DHHwY:
        if (false !== $AvgzF && $RCdwx instanceof MB8DYpNdVV1bz) {
            goto qqarB;
        }
        goto yfEQq;
        WeKR6:
        $RCdwx = $this->tG6LD->moVlbNp73q6($yvZyv);
        goto gmuWI;
        cp76f:
        goto iOYwW;
        goto GxSsw;
        fvYxE:
        iOYwW:
        goto uFcdo;
        GxSsw:
        qqarB:
        goto YLEkb;
        gmuWI:
        $AvgzF = $this->Lrbr9->putFileAs(dirname($RCdwx->getLocation()), $yvZyv->getFile(), $RCdwx->getFilename() . '.' . $RCdwx->getExtension(), ['visibility' => 'public']);
        goto DHHwY;
        YLEkb:
        $RCdwx->mIiE80g96Fo(Tbw0jsMnRbOTP::UPLOADED);
        goto fvYxE;
        yfEQq:
        throw new \LogicException('File upload failed, check permissions');
        goto cp76f;
        SQLJm:
    }
    public function storePreSignedFile(array $ogaAB)
    {
        goto EB7Kd;
        F8yAR:
        return ['filename' => $XqWFu->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $XqWFu->mQC0gqARkin()];
        goto k9MDN;
        EWrVR:
        $XqWFu = Q4cNg0cF0Oivx::mopG22rfXNL($RCdwx, $this->P8Yzg, $this->Lrbr9, $this->TRmgk, true);
        goto ppVNY;
        ppVNY:
        $XqWFu->mn5rCiQWG82($ogaAB['mime'], $ogaAB['file_size'], $ogaAB['chunk_size'], $ogaAB['checksums'], $ogaAB['user_id'], $ogaAB['driver']);
        goto aUU_7;
        EB7Kd:
        $RCdwx = $this->tG6LD->moVlbNp73q6($ogaAB);
        goto EWrVR;
        aUU_7:
        $XqWFu->mPIJfcVqq6f();
        goto F8yAR;
        k9MDN:
    }
    public function updatePreSignedFile(string $Vv6Mk, int $qCASZ)
    {
        goto s0Qlu;
        s0Qlu:
        $XqWFu = Q4cNg0cF0Oivx::mJFDfbjInru($Vv6Mk, $this->P8Yzg, $this->Lrbr9, $this->TRmgk);
        goto YDuFp;
        Y4Den:
        AFYwf:
        goto e8nnN;
        e8nnN:
        zpnec:
        goto PUBtx;
        YDuFp:
        switch ($qCASZ) {
            case Tbw0jsMnRbOTP::UPLOADED:
                $XqWFu->mO37wAXSj7j();
                goto zpnec;
            case Tbw0jsMnRbOTP::PROCESSING:
                $XqWFu->m3jdVw0RTz1();
                goto zpnec;
            case Tbw0jsMnRbOTP::FINISHED:
                $XqWFu->mm4RMr8V0Ds();
                goto zpnec;
            case Tbw0jsMnRbOTP::ABORTED:
                $XqWFu->m725LM7dq7t();
                goto zpnec;
        }
        goto Y4Den;
        PUBtx:
    }
    public function completePreSignedFile(string $Vv6Mk, array $wErBB)
    {
        goto olZoL;
        olZoL:
        $XqWFu = Q4cNg0cF0Oivx::mJFDfbjInru($Vv6Mk, $this->P8Yzg, $this->Lrbr9, $this->TRmgk);
        goto Mo6mC;
        bYCMk:
        $XqWFu->mO37wAXSj7j();
        goto xO1WD;
        Mo6mC:
        $XqWFu->mjt4KTTPlCK()->mpxsTOv0vOY($wErBB);
        goto bYCMk;
        xO1WD:
        return ['path' => $XqWFu->getFile()->getView()['path'], 'thumbnail' => $XqWFu->getFile()->r3OVR, 'id' => $Vv6Mk];
        goto f0gqX;
        f0gqX:
    }
    public function updateFile(string $Vv6Mk, int $qCASZ) : PaQmIZL22EnpA
    {
        goto mgONa;
        oAJI7:
        return $RCdwx;
        goto bBOu9;
        mgONa:
        $RCdwx = $this->tG6LD->mNMIxO04xMD($Vv6Mk);
        goto S67qA;
        S67qA:
        $RCdwx->mIiE80g96Fo($qCASZ);
        goto oAJI7;
        bBOu9:
    }
}
