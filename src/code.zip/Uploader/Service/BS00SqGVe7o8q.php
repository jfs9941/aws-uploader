<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Core\HWHmqgxgfYrsZ;
use Jfs\Uploader\Core\JxGHPMjqmk9TF;
use Jfs\Uploader\Enum\ZVJoOgH14iXBq;
use Jfs\Uploader\Exception\F8y1xdPRStgQx;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Exception\DDrY5gI5aE4u5;
use Jfs\Uploader\Service\P8Uf7dWabbyOG;
use Illuminate\Contracts\Filesystem\Filesystem;
final class BS00SqGVe7o8q implements UploadServiceInterface
{
    private $Ul23A;
    private $BX0zD;
    private $lIJMo;
    private $YnkyX;
    public function __construct(P8Uf7dWabbyOG $N0h3H, Filesystem $MKJ1D, Filesystem $niM9V, string $hyv7_)
    {
        goto FOYDu;
        af2Vb:
        $this->BX0zD = $MKJ1D;
        goto V_glO;
        FOYDu:
        $this->Ul23A = $N0h3H;
        goto af2Vb;
        V_glO:
        $this->lIJMo = $niM9V;
        goto DUtF8;
        DUtF8:
        $this->YnkyX = $hyv7_;
        goto rvfXg;
        rvfXg:
    }
    public function storeSingleFile(SingleUploadInterface $chXNL) : array
    {
        goto qJMct;
        wkyIW:
        return $ZQzpf->getView();
        goto cVetb;
        aVbbr:
        $F0ycc = $this->lIJMo->putFileAs(dirname($ZQzpf->getLocation()), $chXNL->getFile(), $ZQzpf->getFilename() . '.' . $ZQzpf->getExtension(), ['visibility' => 'public']);
        goto QbCKk;
        zOD4j:
        EpusM:
        goto wkyIW;
        qJMct:
        $ZQzpf = $this->Ul23A->mfuNHmUqiJj($chXNL);
        goto aVbbr;
        QbCKk:
        if (false !== $F0ycc && $ZQzpf instanceof ZEs3XZLglwgUu) {
            goto Thjbn;
        }
        goto DB1Yk;
        m03Lh:
        goto EpusM;
        goto rSpKC;
        rSpKC:
        Thjbn:
        goto xC106;
        DB1Yk:
        throw new \LogicException('File upload failed, check permissions');
        goto m03Lh;
        xC106:
        $ZQzpf->mzoKjbCd8Ap(ZVJoOgH14iXBq::UPLOADED);
        goto zOD4j;
        cVetb:
    }
    public function storePreSignedFile(array $dAvO3)
    {
        goto eCqaq;
        UQdDA:
        $Gauo2->mErn5ZjMDWP($dAvO3['mime'], $dAvO3['file_size'], $dAvO3['chunk_size'], $dAvO3['checksums'], $dAvO3['user_id'], $dAvO3['driver']);
        goto BKOPM;
        Y3HdR:
        $Gauo2 = JxGHPMjqmk9TF::mLtryTMXpSi($ZQzpf, $this->BX0zD, $this->lIJMo, $this->YnkyX, true);
        goto UQdDA;
        tEQui:
        return ['filename' => $Gauo2->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $Gauo2->mo3Tm9vFFgH()];
        goto OixzC;
        BKOPM:
        $Gauo2->mvO2oUl7xnV();
        goto tEQui;
        eCqaq:
        $ZQzpf = $this->Ul23A->mfuNHmUqiJj($dAvO3);
        goto Y3HdR;
        OixzC:
    }
    public function updatePreSignedFile(string $P9w4z, int $Zrk6R)
    {
        goto hD5aH;
        hD5aH:
        $Gauo2 = JxGHPMjqmk9TF::m1ImageHwyB($P9w4z, $this->BX0zD, $this->lIJMo, $this->YnkyX);
        goto O4KGe;
        O4KGe:
        switch ($Zrk6R) {
            case ZVJoOgH14iXBq::UPLOADED:
                $Gauo2->merteJGz1sz();
                goto mDRIT;
            case ZVJoOgH14iXBq::PROCESSING:
                $Gauo2->mjj6gPMGYbo();
                goto mDRIT;
            case ZVJoOgH14iXBq::FINISHED:
                $Gauo2->ml1mJhuT6E0();
                goto mDRIT;
            case ZVJoOgH14iXBq::ABORTED:
                $Gauo2->mnYi7oWpgZr();
                goto mDRIT;
        }
        goto YvZ0Y;
        jrnmt:
        mDRIT:
        goto GfoVG;
        YvZ0Y:
        HljCf:
        goto jrnmt;
        GfoVG:
    }
    public function completePreSignedFile(string $P9w4z, array $vZh2W)
    {
        goto hLQKJ;
        HXVnE:
        return ['path' => $Gauo2->getFile()->getView()['path'], 'thumbnail' => $Gauo2->getFile()->bcO9d, 'id' => $P9w4z];
        goto KzxVH;
        ngay6:
        $Gauo2->merteJGz1sz();
        goto HXVnE;
        I4kGK:
        $Gauo2->mU5hpD7riBK()->mZmVKFliuYD($vZh2W);
        goto ngay6;
        hLQKJ:
        $Gauo2 = JxGHPMjqmk9TF::m1ImageHwyB($P9w4z, $this->BX0zD, $this->lIJMo, $this->YnkyX);
        goto I4kGK;
        KzxVH:
    }
    public function updateFile(string $P9w4z, int $Zrk6R) : HWHmqgxgfYrsZ
    {
        goto lgV0m;
        lgV0m:
        $ZQzpf = $this->Ul23A->mau1vComm37($P9w4z);
        goto lRgDR;
        lRgDR:
        $ZQzpf->mzoKjbCd8Ap($Zrk6R);
        goto Tluvh;
        Tluvh:
        return $ZQzpf;
        goto hXFQg;
        hXFQg:
    }
}
