<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\VrVag0CyeQKdN;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Core\DPPVKylVXE4k4;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
final class GALKiO0auT3sq implements VrVag0CyeQKdN
{
    private $UjaCK;
    private $nJ4kw;
    public $xzpuR;
    private $qO5jn;
    private $j320Z;
    private $riMoE;
    public function __construct($Nnz8s, $rRMfO, $Dqty0, $dsrl0, $RZKp2, $BP_p5)
    {
        goto HInrH;
        avbty:
        $this->j320Z = $RZKp2;
        goto V1DfU;
        HInrH:
        $this->riMoE = $BP_p5;
        goto SZ6Ef;
        YEmIn:
        $this->nJ4kw = $rRMfO;
        goto IuOb1;
        H4oQF:
        $this->qO5jn = $dsrl0;
        goto avbty;
        SZ6Ef:
        $this->UjaCK = $Nnz8s;
        goto YEmIn;
        IuOb1:
        $this->xzpuR = $Dqty0;
        goto H4oQF;
        V1DfU:
    }
    public function resolvePath($g1333, $NigPe = GTmWxMidiCuj0::S3) : string
    {
        goto RK4np;
        Rq7cT:
        OZrlP:
        goto vfkRX;
        xnlq1:
        if (!$this->UjaCK) {
            goto aPE3H;
        }
        goto Iiy38;
        ho9li:
        return $this->m8vmbWS56kI($g1333);
        goto mLd3p;
        LAoHB:
        if (!(!empty($this->qO5jn) && !empty($this->j320Z))) {
            goto OEv_3;
        }
        goto ho9li;
        A2fvU:
        $g1333 = $g1333->getAttribute('filename');
        goto Rq7cT;
        VYGUd:
        return trim($this->nJ4kw, '/') . '/' . $g1333;
        goto eBZl2;
        RK4np:
        if (!$g1333 instanceof Yn8aWzKzROkno) {
            goto OZrlP;
        }
        goto A2fvU;
        QE3Bt:
        return config('upload.home') . '/' . $g1333;
        goto ODUcl;
        Iiy38:
        return trim($this->xzpuR, '/') . '/' . $g1333;
        goto vSkXJ;
        ODUcl:
        Uwit5:
        goto LAoHB;
        vSkXJ:
        aPE3H:
        goto VYGUd;
        mLd3p:
        OEv_3:
        goto xnlq1;
        vfkRX:
        if (!($NigPe === GTmWxMidiCuj0::LOCAL)) {
            goto Uwit5;
        }
        goto QE3Bt;
        eBZl2:
    }
    public function resolveThumbnail(Yn8aWzKzROkno $g1333) : string
    {
        goto KOBVS;
        d9qMl:
        BGZKB:
        goto QsTFU;
        GusJi:
        a2Iy0:
        goto NyxUu;
        mOL1o:
        return $this->url($XGdv1, $g1333->getAttribute('driver'));
        goto GusJi;
        hl3Bd:
        if (!$g1333 instanceof DsyQbNiy8VgJG) {
            goto tTeqd;
        }
        goto I2L0I;
        QsTFU:
        VfEgk:
        goto hl3Bd;
        U0can:
        $eWsMA = DsyQbNiy8VgJG::find($g1333->getAttribute('thumbnail_id'));
        goto Oei_y;
        rjKHX:
        fADqS:
        goto zZHcF;
        I2L0I:
        return $this->resolvePath($g1333, $g1333->getAttribute('driver'));
        goto zWnRZ;
        KOBVS:
        $XGdv1 = $g1333->getAttribute('thumbnail');
        goto jTu3Y;
        fqZgT:
        return asset('/img/pdf-preview.svg');
        goto rjKHX;
        jTu3Y:
        if (!$XGdv1) {
            goto a2Iy0;
        }
        goto mOL1o;
        BIykg:
        return $this->resolvePath($eWsMA, $eWsMA->getAttribute('driver'));
        goto d9qMl;
        lnt1u:
        if (!$g1333 instanceof DPPVKylVXE4k4) {
            goto fADqS;
        }
        goto fqZgT;
        Oei_y:
        if (!$eWsMA) {
            goto BGZKB;
        }
        goto BIykg;
        NyxUu:
        if (!$g1333->getAttribute('thumbnail_id')) {
            goto VfEgk;
        }
        goto U0can;
        zZHcF:
        return '';
        goto g02jD;
        zWnRZ:
        tTeqd:
        goto lnt1u;
        g02jD:
    }
    private function url($J9IgU, $NigPe)
    {
        goto vX6Og;
        jVI8J:
        return $this->resolvePath($J9IgU);
        goto dgJ1y;
        Y3BGY:
        EIT9C:
        goto jVI8J;
        BgvNi:
        return config('upload.home') . '/' . $J9IgU;
        goto Y3BGY;
        vX6Og:
        if (!($NigPe == GTmWxMidiCuj0::LOCAL)) {
            goto EIT9C;
        }
        goto BgvNi;
        dgJ1y:
    }
    private function m8vmbWS56kI($J9IgU)
    {
        goto sQ2Jz;
        sQ2Jz:
        if (!(strpos($J9IgU, 'https://') === 0)) {
            goto TVGqc;
        }
        goto IS96C;
        sW2wb:
        BT6tz:
        goto DupDa;
        ZBRYu:
        TVGqc:
        goto j_DP0;
        DupDa:
        $am1kR = now()->addMinutes(60)->timestamp;
        goto we6lG;
        Q29mR:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto sW2wb;
        we6lG:
        $jAPgL = new UrlSigner($this->qO5jn, $this->riMoE->path($this->j320Z));
        goto fu7fL;
        IS96C:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto ZBRYu;
        j_DP0:
        if (!(strpos($J9IgU, 'm3u8') !== false)) {
            goto BT6tz;
        }
        goto Q29mR;
        fu7fL:
        return $jAPgL->getSignedUrl($this->xzpuR . '/' . $J9IgU, $am1kR);
        goto jU7gc;
        jU7gc:
    }
    public function resolvePathForHlsVideo(ZSB2cdrwtZpmk $wmU7r, $H7KQx = false) : string
    {
        goto oq_Yj;
        a04mB:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Wfkus;
        kcVYQ:
        return $this->xzpuR . '/' . $wmU7r->getAttribute('hls_path');
        goto moU8L;
        Wfkus:
        c8VcT:
        goto kcVYQ;
        oq_Yj:
        if ($wmU7r->getAttribute('hls_path')) {
            goto c8VcT;
        }
        goto a04mB;
        moU8L:
    }
    public function resolvePathForHlsVideos()
    {
        goto GZPal;
        Q7JZ2:
        $kSvcn = $this->xzpuR . '/v2/hls/';
        goto psSIJ;
        GZPal:
        $am1kR = now()->addDays(3)->timestamp;
        goto Q7JZ2;
        ykL_C:
        return [$pU7fK, $am1kR];
        goto ah8xr;
        psSIJ:
        $Na7S7 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $kSvcn), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $am1kR]]]]]);
        goto k5BIj;
        k5BIj:
        $GiUdT = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Pwp7o;
        Pwp7o:
        $pU7fK = $GiUdT->getSignedCookie(['key_pair_id' => $this->qO5jn, 'private_key' => $this->riMoE->path($this->j320Z), 'policy' => $Na7S7]);
        goto ykL_C;
        ah8xr:
    }
}
