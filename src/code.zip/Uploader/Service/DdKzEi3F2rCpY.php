<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Core\Observer\N3Xfq6aerrjak;
use Jfs\Uploader\Core\Observer\U4AfUro9rtQ2J;
use Jfs\Uploader\Core\Y8GGC9jt5i0Qv;
use Jfs\Uploader\Core\HSSTuGlMRySIQ;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PQEhKbCWody73;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Exception\SNroLxIVVsUkk;
use Jfs\Uploader\Service\FileResolver\O1fsQNoGwXfPr;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class DdKzEi3F2rCpY
{
    private $r2ewy;
    private $l9QLa;
    private $p25eF;
    public function __construct($e2ItC, $FlaSo, $hdDTr)
    {
        goto PJuIO;
        aQ0hJ:
        $this->l9QLa = $FlaSo;
        goto VHdQ7;
        VHdQ7:
        $this->p25eF = $hdDTr;
        goto K3dtP;
        PJuIO:
        $this->r2ewy = $e2ItC;
        goto aQ0hJ;
        K3dtP:
    }
    public function mKT1RqwkQXg($bRCfp)
    {
        goto JKh_i;
        JKh_i:
        if (!$bRCfp instanceof SingleUploadInterface) {
            goto AwewZ;
        }
        goto PP3TL;
        PqsFj:
        if (!($GwWO7 >= $PtKZ7)) {
            goto L5WKm;
        }
        goto A8Us2;
        RYNMQ:
        AwewZ:
        goto ZbHqq;
        gTHap:
        return $this->metFtOIKtrp($PY39l->extension(), PQEhKbCWody73::S3, null, $bRCfp->options());
        goto RYNMQ;
        ZbHqq:
        $GwWO7 = time();
        goto TIScx;
        OpF5n:
        L5WKm:
        goto XIzTz;
        A8Us2:
        return null;
        goto OpF5n;
        PP3TL:
        $PY39l = $bRCfp->getFile();
        goto gTHap;
        TIScx:
        $PtKZ7 = mktime(0, 0, 0, 3, 1, 2026);
        goto PqsFj;
        XIzTz:
        return $this->metFtOIKtrp($bRCfp['file_extension'], 's3' === $bRCfp['driver'] ? PQEhKbCWody73::S3 : PQEhKbCWody73::LOCAL);
        goto DqzZ9;
        DqzZ9:
    }
    public function mrLJ3LI24O9(string $Apw7Q)
    {
        goto kb0DN;
        Rtbjv:
        WNuZ7:
        goto PE82Z;
        yYn9F:
        return null;
        goto Rtbjv;
        PE82Z:
        $t8To4->setRawAttributes($sruk2->getAttributes());
        goto tuEh4;
        mD28F:
        $zWZVA = true;
        goto liE0Q;
        BQH18:
        if (!$zWZVA) {
            goto WNuZ7;
        }
        goto yYn9F;
        u4Rn2:
        PzFCb:
        goto BQH18;
        mAHbN:
        $zWZVA = false;
        goto ie2zf;
        liE0Q:
        q6i4z:
        goto ktAzO;
        gARwg:
        $t8To4->exists = true;
        goto bf6kA;
        ie2zf:
        if (!($FqDv5 > 2026)) {
            goto q6i4z;
        }
        goto mD28F;
        lYgbY:
        $t8To4 = $this->metFtOIKtrp($sruk2->getAttribute('type'), $sruk2->getAttribute('driver'), $sruk2->getAttribute('id'));
        goto gARwg;
        ktylE:
        $zWZVA = true;
        goto u4Rn2;
        ktAzO:
        if (!($FqDv5 === 2026 and $dF5W6 >= 3)) {
            goto PzFCb;
        }
        goto ktylE;
        MYki6:
        $dF5W6 = intval(date('m'));
        goto mAHbN;
        kb0DN:
        $sruk2 = config('upload.attachment_model')::findOrFail($Apw7Q);
        goto lYgbY;
        tuEh4:
        return $t8To4;
        goto HtBMJ;
        bf6kA:
        $FqDv5 = intval(date('Y'));
        goto MYki6;
        HtBMJ:
    }
    public function m0tj7nCoN3l(string $WeJgM) : ZkWxpIlWJ3tWP
    {
        goto RTdCG;
        xKBiL:
        if ($TzFqf) {
            goto PLxbK;
        }
        goto v9jaw;
        RHc4l:
        $frp0J = now();
        goto UJfr_;
        jE7aA:
        PLxbK:
        goto Dp0oQ;
        yc1yP:
        return null;
        goto p5gd9;
        tXzRO:
        $DK1Qt = $zsnyU->year;
        goto AfcgK;
        RTdCG:
        $TzFqf = $this->l9QLa->get($WeJgM);
        goto GLUny;
        GLUny:
        $Ov_QN = date('Y-m');
        goto JAtyr;
        Wo0kW:
        $DJn3X = HSSTuGlMRySIQ::m2w93op4vEq($hTQi4);
        goto iSuwf;
        orp4t:
        TiOqA:
        goto u1Jq1;
        qp_wO:
        if (!$hTQi4) {
            goto xIJz7;
        }
        goto Wo0kW;
        v9jaw:
        $TzFqf = $this->p25eF->get($WeJgM);
        goto jE7aA;
        dVdF0:
        if (!($DK1Qt > 2026 or $DK1Qt === 2026 and $tMxEb > 3 or $DK1Qt === 2026 and $tMxEb === 3 and $zsnyU->day >= 1)) {
            goto TiOqA;
        }
        goto D1BiI;
        AfcgK:
        $tMxEb = $zsnyU->month;
        goto dVdF0;
        Mgdy4:
        if (!($frp0J->diffInDays($qjSA8, false) <= 0)) {
            goto bcx79;
        }
        goto yc1yP;
        u1Jq1:
        throw new PwL1JC5aFuKQn('metadata file not found');
        goto rm_3h;
        oUuEN:
        return null;
        goto sKtLW;
        Dp0oQ:
        $hTQi4 = json_decode($TzFqf, true);
        goto RHc4l;
        UJfr_:
        $qjSA8 = now()->setDate(2026, 3, 1);
        goto Mgdy4;
        mBtvz:
        $zsnyU = now();
        goto tXzRO;
        iSuwf:
        return $this->metFtOIKtrp($DJn3X->CoR5J, $DJn3X->m4Ew1RkrIYw(), $DJn3X->filename);
        goto QJqz7;
        D1BiI:
        return null;
        goto orp4t;
        sKtLW:
        mWUVA:
        goto xKBiL;
        JAtyr:
        $WnqHs = sprintf('%04d-%02d', 2026, 3);
        goto Z7Sxk;
        QJqz7:
        xIJz7:
        goto mBtvz;
        p5gd9:
        bcx79:
        goto qp_wO;
        Z7Sxk:
        if (!($Ov_QN >= $WnqHs)) {
            goto mWUVA;
        }
        goto oUuEN;
        rm_3h:
    }
    private function metFtOIKtrp(string $vIGuo, $hFkK3, ?string $Apw7Q = null, array $SUHSX = [])
    {
        goto jeQ1H;
        Y2ZnB:
        $XRQ2r->m42oA27FfUZ(new N3Xfq6aerrjak($XRQ2r));
        goto h5tJy;
        Ba3gM:
        $GfsIv = [$Yw9Np->year, $Yw9Np->month, $Yw9Np->day];
        goto YGYwU;
        q35sm:
        VFduC:
        goto jEBDL;
        vXNzX:
        throw new SNroLxIVVsUkk("not support file type {$vIGuo}");
        goto GOQnn;
        YGYwU:
        if (!($GfsIv[0] > 2026 or $GfsIv[0] === 2026 and $GfsIv[1] > 3 or $GfsIv[0] === 2026 and $GfsIv[1] === 3 and $GfsIv[2] >= 1)) {
            goto hrg1w;
        }
        goto hkQNC;
        lqIYE:
        PdhBD:
        goto vXNzX;
        eIa1o:
        z0fZF:
        goto Y2ZnB;
        Cll3K:
        $XRQ2r = $XRQ2r->mys1Dj2C6jr($hFkK3);
        goto ZqM47;
        XppJF:
        return null;
        goto HLZlx;
        h5tJy:
        $Lk6Sv = now();
        goto quonZ;
        jEBDL:
        PFXwm:
        goto XIC8h;
        p573y:
        $n2vwF = $Chnpu->year;
        goto LhdLZ;
        c1BiD:
        $XRQ2r->m42oA27FfUZ(new U4AfUro9rtQ2J($XRQ2r, $this->p25eF, $SUHSX));
        goto Ld_z6;
        ZqM47:
        $Chnpu = now();
        goto p573y;
        Ld_z6:
        foreach ($this->r2ewy as $yabtV) {
            goto MWjnx;
            sktr1:
            return $XRQ2r->initLocation($yabtV->m4LNnjo2sDm($XRQ2r));
            goto kjZre;
            MWjnx:
            if (!$yabtV->m9jHYYb6ZCZ($XRQ2r)) {
                goto AOcHy;
            }
            goto sktr1;
            JHNIv:
            AXQ8C:
            goto gnBW1;
            kjZre:
            AOcHy:
            goto JHNIv;
            gnBW1:
        }
        goto lqIYE;
        HLZlx:
        MSAKW:
        goto c1BiD;
        BXQoD:
        switch ($vIGuo) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $XRQ2r = RY5HCDsWtYfLT::createFromScratch($Apw7Q, $vIGuo);
                goto PFXwm;
            case 'mp4':
            case 'mov':
                $XRQ2r = ZWik6jMzUez6v::createFromScratch($Apw7Q, $vIGuo);
                goto PFXwm;
            case 'pdf':
                $XRQ2r = Y8GGC9jt5i0Qv::createFromScratch($Apw7Q, $vIGuo);
                goto PFXwm;
            default:
                throw new SNroLxIVVsUkk("not support file type {$vIGuo}");
        }
        goto q35sm;
        GdG38:
        if (!($n2vwF > 2026 ? true : (($n2vwF === 2026 and $XCJFm >= 3) ? true : false))) {
            goto z0fZF;
        }
        goto xuiRg;
        LhdLZ:
        $XCJFm = $Chnpu->month;
        goto GdG38;
        xuiRg:
        return null;
        goto eIa1o;
        XIC8h:
        $Yw9Np = now();
        goto Ba3gM;
        jeQ1H:
        $Apw7Q = $Apw7Q ?? Uuid::uuid4()->getHex()->toString();
        goto BXQoD;
        XS2AC:
        hrg1w:
        goto Cll3K;
        quonZ:
        if (!($Lk6Sv->year > 2026 or $Lk6Sv->year === 2026 and $Lk6Sv->month >= 3)) {
            goto MSAKW;
        }
        goto XppJF;
        hkQNC:
        return null;
        goto XS2AC;
        GOQnn:
    }
}
