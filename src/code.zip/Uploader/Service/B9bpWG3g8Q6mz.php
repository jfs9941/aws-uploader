<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
final class B9bpWG3g8Q6mz
{
    private $kALX2;
    private $U70G6;
    private $s0VP1;
    public function __construct(string $vT463, string $KawKE, Filesystem $TuWZt)
    {
        goto gsmSv;
        TLXKX:
        $this->s0VP1 = $TuWZt;
        goto ZvqDg;
        gsmSv:
        $this->kALX2 = $vT463;
        goto lVu3C;
        lVu3C:
        $this->U70G6 = $KawKE;
        goto TLXKX;
        ZvqDg:
    }
    public function mZ28P1Fud69(DMUaxGX7XHAI0 $hEivM) : string
    {
        goto fuWCh;
        pXJ11:
        return $this->s0VP1->url($hEivM->getAttribute('filename'));
        goto ixsuq;
        A_2ug:
        BHvFq:
        goto pXJ11;
        fuWCh:
        if (!(Rc6MZhMMdyG6A::S3 == $hEivM->getAttribute('driver'))) {
            goto BHvFq;
        }
        goto iR_jD;
        iR_jD:
        return 's3://' . $this->kALX2 . '/' . $hEivM->getAttribute('filename');
        goto A_2ug;
        ixsuq:
    }
    public function mPXAqsMnwsu(?string $tfm8f) : ?string
    {
        goto RkSwG;
        P3Tr1:
        if (!E8LCc($tfm8f, $this->kALX2)) {
            goto I1W8H;
        }
        goto XfuYP;
        RkSwG:
        if (!$tfm8f) {
            goto fN8_g;
        }
        goto P3Tr1;
        kbIYb:
        return null;
        goto WOBsF;
        ec1rF:
        I1W8H:
        goto Lvvcf;
        MnMvE:
        return 's3://' . $this->kALX2 . '/' . ltrim($z69yI, '/');
        goto ec1rF;
        Lvvcf:
        fN8_g:
        goto kbIYb;
        XfuYP:
        $z69yI = parse_url($tfm8f, PHP_URL_PATH);
        goto MnMvE;
        WOBsF:
    }
    public function mH6lVS0EYin(string $z69yI) : string
    {
        return 's3://' . $this->kALX2 . '/' . $z69yI;
    }
}
