<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Lqd1WdK14h5gQ
{
    private $kJEi8;
    private $JlvG_;
    private $ZPzJH;
    public function __construct(string $r087v, string $Cv6Xb, Filesystem $G3exm)
    {
        goto BfvoZ;
        BfvoZ:
        $this->kJEi8 = $r087v;
        goto v2P8b;
        SKODK:
        $this->ZPzJH = $G3exm;
        goto bAT2p;
        v2P8b:
        $this->JlvG_ = $Cv6Xb;
        goto SKODK;
        bAT2p:
    }
    public function mvhTnR9BfpN(F43pNWIrUhz3z $bPdTZ) : string
    {
        goto oD8D9;
        mrDgP:
        return 's3://' . $this->kJEi8 . '/' . $bPdTZ->getAttribute('filename');
        goto pGFWJ;
        bMnsr:
        return $this->ZPzJH->url($bPdTZ->getAttribute('filename'));
        goto BdpUT;
        pGFWJ:
        nEXbI:
        goto bMnsr;
        oD8D9:
        if (!(KkaUVP3OQvOtp::S3 == $bPdTZ->getAttribute('driver'))) {
            goto nEXbI;
        }
        goto mrDgP;
        BdpUT:
    }
    public function mRya8qVbTAk(?string $YrdXo) : ?string
    {
        goto a8U11;
        jtaVs:
        $iVcpi = parse_url($YrdXo, PHP_URL_PATH);
        goto s2Rd1;
        GUSZd:
        u6GqS:
        goto F74Tk;
        s2Rd1:
        return 's3://' . $this->kJEi8 . '/' . ltrim($iVcpi, '/');
        goto yejin;
        yejin:
        mTW4G:
        goto GUSZd;
        F74Tk:
        return null;
        goto QdhsF;
        B6ovh:
        if (!vIbb_($YrdXo, $this->kJEi8)) {
            goto mTW4G;
        }
        goto jtaVs;
        a8U11:
        if (!$YrdXo) {
            goto u6GqS;
        }
        goto B6ovh;
        QdhsF:
    }
    public function mSCDeeKb5du(string $iVcpi) : string
    {
        return 's3://' . $this->kJEi8 . '/' . $iVcpi;
    }
}
