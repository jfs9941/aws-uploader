<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
use Illuminate\Contracts\Filesystem\Filesystem;
final class TUSrCGJanJHY8
{
    private $tA7Ds;
    private $V0HjE;
    private $GUhIK;
    public function __construct(string $EcbH3, string $uGQtg, Filesystem $kGo1c)
    {
        goto WhemM;
        KrBqH:
        $this->V0HjE = $uGQtg;
        goto F3Jed;
        WhemM:
        $this->tA7Ds = $EcbH3;
        goto KrBqH;
        F3Jed:
        $this->GUhIK = $kGo1c;
        goto Lkn8T;
        Lkn8T:
    }
    public function mtQlEndJd9J(VMj30iBgKeeJB $XcVxI) : string
    {
        goto N3U5T;
        E8amW:
        return $this->GUhIK->url($XcVxI->getAttribute('filename'));
        goto pGvAt;
        N3U5T:
        if (!(VNuaYSNcfVlT5::S3 == $XcVxI->getAttribute('driver'))) {
            goto bRQuV;
        }
        goto JNbgz;
        JNbgz:
        return 's3://' . $this->tA7Ds . '/' . $XcVxI->getAttribute('filename');
        goto dtQgC;
        dtQgC:
        bRQuV:
        goto E8amW;
        pGvAt:
    }
    public function m5Tw0SVvXCN(?string $KLu9w) : ?string
    {
        goto KeQok;
        PkLBs:
        opRIx:
        goto MPAqd;
        MPAqd:
        Or47J:
        goto VNli0;
        VNli0:
        return null;
        goto Yf_PZ;
        TPGwE:
        if (!Hh2MB($KLu9w, $this->tA7Ds)) {
            goto opRIx;
        }
        goto TkQbw;
        TkQbw:
        $dSgog = parse_url($KLu9w, PHP_URL_PATH);
        goto cY3OF;
        KeQok:
        if (!$KLu9w) {
            goto Or47J;
        }
        goto TPGwE;
        cY3OF:
        return 's3://' . $this->tA7Ds . '/' . ltrim($dSgog, '/');
        goto PkLBs;
        Yf_PZ:
    }
    public function meJLhlZY0za(string $dSgog) : string
    {
        return 's3://' . $this->tA7Ds . '/' . $dSgog;
    }
}
