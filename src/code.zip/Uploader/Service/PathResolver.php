<?php

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\PathResolverInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Core\Pdf;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileDriver;

final class PathResolver implements PathResolverInterface
{
    private $cdnEnabled;
    private $s3Url;
    public $cdnUrl;
    private $keyId;
    private $keyPath;
    private $localDisk;

    public function __construct(
        $cdnEnabled,
        $s3Url,
        $cdnUrl,
        $keyId,
        $keyPath,
        $localDisk
    ) {
        $this->localDisk = $localDisk;
        $this->cdnEnabled = $cdnEnabled;
        $this->s3Url = $s3Url;
        $this->cdnUrl = $cdnUrl;
        $this->keyId = $keyId;
        $this->keyPath = $keyPath;
    }

    public function resolvePath($media, $driver = FileDriver::S3): string
    {
        if ($media instanceof BaseFileModel) {
            $media = $media->getAttribute('filename');
        }
        if ($driver === FileDriver::LOCAL) {
            return route('home') . '/' . $media;
        }

        if (!empty($this->keyId) && !empty($this->keyPath)) {
            return $this->generatePresignUrl($media);
        }

        if ($this->cdnEnabled) {
            return trim($this->cdnUrl, '/') . '/' . $media;
        }

        return trim($this->s3Url, '/') . '/' . $media;
    }

    public function resolveThumbnail(BaseFileModel $media): string
    {
        $thumbnail = $media->thumbnail;
        if ($thumbnail) {
            return $this->url($thumbnail, $media->getAttribute('driver'));
        }
        if ($media->getAttribute('thumbnail_id')) {
            $thumbnailObject = Image::find($media->getAttribute('thumbnail_id'));
            if ($thumbnailObject) {
                return $this->resolvePath($thumbnailObject, $thumbnailObject->getAttribute('driver'));
            }
        }

        if ($media instanceof Image) {
            return $this->resolvePath($media, $media->getAttribute('driver'));
        }
        if ($media instanceof Pdf) {
            return asset('/img/pdf-preview.svg');
        }

        return '';
    }

    private function url($path, $driver)
    {
        if ($driver == FileDriver::LOCAL) {
            return route('home') . '/' . $path;
        }
        return $this->resolvePath($path);
    }

    private function generatePresignUrl($path)
    {
        if (strpos($path, 'https://') === 0) {
            throw new \RuntimeException('can not generate presign url for full url path');
        }
        if (strpos($path, 'm3u8') !== false) {
            throw new \RuntimeException('can not generate presign url for m3u8 here');
        }
        $expires = now()->addMinutes(60)->timestamp;
        $urlSigner = new UrlSigner($this->keyId, $this->localDisk->path($this->keyPath));
        return $urlSigner->getSignedUrl(
            $this->cdnUrl . '/' . $path,
            $expires
        );
    }

    /**
     * @param Video $video
     * @param bool $strict
     * @return string
     */
    public function resolvePathForHlsVideo(Video $video, $strict = false): string
    {
        if (!$video->hls_path) {
            throw new \RuntimeException('can not resolve video not processed yet');
        }
        return $this->cdnUrl . '/' . $video->hls_path;
    }

    public function resolvePathForHlsVideos()
    {
        $expires = now()->addDays(3)->timestamp;
        $tsFiles = $this->cdnUrl . '/v2/hls/';
        $policyForTsFiles = json_encode([
            'Statement' => [
                [
                    'Resource' => sprintf('%s*', $tsFiles),
                    'Condition' => [
                        'DateLessThan' => ['AWS:EpochTime' => $expires],
                    ],
                ],
            ],
        ]);
        $cloudFrontClient = new CloudFrontClient([
            'version' => 'latest',
            'region'  => config('filesystems.disks.s3.region'),
        ]);

        $cookies = $cloudFrontClient->getSignedCookie([
            'key_pair_id' => $this->keyId,
            'private_key' => $this->localDisk->path($this->keyPath),
            'policy' => $policyForTsFiles,
        ]);
        return [
            $cookies,
            $expires
        ];
    }
}
