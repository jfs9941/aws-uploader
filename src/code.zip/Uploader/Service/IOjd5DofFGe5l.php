<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\H1Ax5lj0mb7kw;
use Jfs\Uploader\Core\N8O216tH1Gxax;
use Jfs\Uploader\Core\RQ9bDEqcUZdSJ;
use Jfs\Uploader\Enum\IOOvAXAyKHLW2;
use Jfs\Uploader\Exception\D2GpNcz5KiI9K;
use Jfs\Uploader\Exception\DRgeXfZrFFnZd;
use Jfs\Uploader\Exception\C4FBIUHwDz2gM;
use Jfs\Uploader\Service\M5DWm1ijeK6rr;
use Illuminate\Contracts\Filesystem\Filesystem;
final class IOjd5DofFGe5l implements UploadServiceInterface
{
    private $ZWFrp;
    private $gcP3F;
    private $Ck8AK;
    private $zdCj3;
    public function __construct(M5DWm1ijeK6rr $RF7zx, Filesystem $qxxOf, Filesystem $P4KJD, string $kbxaq)
    {
        goto KWk7y;
        KWk7y:
        $this->ZWFrp = $RF7zx;
        goto tTAzf;
        DjX_S:
        $this->Ck8AK = $P4KJD;
        goto OzjTY;
        OzjTY:
        $this->zdCj3 = $kbxaq;
        goto KJacp;
        tTAzf:
        $this->gcP3F = $qxxOf;
        goto DjX_S;
        KJacp:
    }
    public function storeSingleFile(SingleUploadInterface $W1gZI) : array
    {
        goto NgT3q;
        Zflgy:
        $pemjO->mVhOJ1PgG8J(IOOvAXAyKHLW2::UPLOADED);
        goto WxTn2;
        XM2Bd:
        if (false !== $lT4E3 && $pemjO instanceof H1Ax5lj0mb7kw) {
            goto oXsA5;
        }
        goto wQPtp;
        pGzKr:
        oXsA5:
        goto Zflgy;
        dYaBb:
        $lT4E3 = $this->Ck8AK->putFileAs(dirname($pemjO->getLocation()), $W1gZI->getFile(), $pemjO->getFilename() . '.' . $pemjO->getExtension(), ['visibility' => 'public']);
        goto XM2Bd;
        WxTn2:
        eBoLS:
        goto hdD3x;
        wQPtp:
        throw new \LogicException('File upload failed, check permissions');
        goto YPt1Z;
        YPt1Z:
        goto eBoLS;
        goto pGzKr;
        hdD3x:
        return $pemjO->getView();
        goto hmCzf;
        NgT3q:
        $pemjO = $this->ZWFrp->mTnv6u1hmho($W1gZI);
        goto dYaBb;
        hmCzf:
    }
    public function storePreSignedFile(array $JaEOQ)
    {
        goto lNjDZ;
        FAXQz:
        $HuGK_->mQohhvSlrsq();
        goto PAadu;
        PAadu:
        return ['filename' => $HuGK_->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $HuGK_->mvk1TQJ0UZn()];
        goto b_F7X;
        WnAH1:
        $HuGK_->mawAF9SpveM($JaEOQ['mime'], $JaEOQ['file_size'], $JaEOQ['chunk_size'], $JaEOQ['checksums'], $JaEOQ['user_id'], $JaEOQ['driver']);
        goto FAXQz;
        SdJMF:
        $HuGK_ = RQ9bDEqcUZdSJ::mFnXGqx5dSJ($pemjO, $this->gcP3F, $this->Ck8AK, $this->zdCj3, true);
        goto WnAH1;
        lNjDZ:
        $pemjO = $this->ZWFrp->mTnv6u1hmho($JaEOQ);
        goto SdJMF;
        b_F7X:
    }
    public function updatePreSignedFile(string $SIB_I, int $LBcXf)
    {
        goto yCdii;
        uNEFT:
        w2GLG:
        goto fgX5q;
        hGGBN:
        switch ($LBcXf) {
            case IOOvAXAyKHLW2::UPLOADED:
                $HuGK_->mHRc1ZRuqIi();
                goto w2GLG;
            case IOOvAXAyKHLW2::PROCESSING:
                $HuGK_->mswQ3I4yjQj();
                goto w2GLG;
            case IOOvAXAyKHLW2::FINISHED:
                $HuGK_->mL49nMTa7sX();
                goto w2GLG;
            case IOOvAXAyKHLW2::ABORTED:
                $HuGK_->mG6Vb9gFdPg();
                goto w2GLG;
        }
        goto K1_zC;
        K1_zC:
        dSFm0:
        goto uNEFT;
        yCdii:
        $HuGK_ = RQ9bDEqcUZdSJ::mTOMSSad6UN($SIB_I, $this->gcP3F, $this->Ck8AK, $this->zdCj3);
        goto hGGBN;
        fgX5q:
    }
    public function completePreSignedFile(string $SIB_I, array $Y_W7Y)
    {
        goto jIz8E;
        txXrX:
        $HuGK_->mg099Xaz8Vo()->mAJTVIUlwdH($Y_W7Y);
        goto UEOdC;
        cx2j9:
        return ['path' => $HuGK_->getFile()->getView()['path'], 'thumbnail' => $HuGK_->getFile()->Ij3xP, 'id' => $SIB_I];
        goto vIoOJ;
        UEOdC:
        $HuGK_->mHRc1ZRuqIi();
        goto cx2j9;
        jIz8E:
        $HuGK_ = RQ9bDEqcUZdSJ::mTOMSSad6UN($SIB_I, $this->gcP3F, $this->Ck8AK, $this->zdCj3);
        goto txXrX;
        vIoOJ:
    }
    public function updateFile(string $SIB_I, int $LBcXf) : N8O216tH1Gxax
    {
        goto mkGGc;
        mkGGc:
        $pemjO = $this->ZWFrp->mMSQxytue1Q($SIB_I);
        goto Z5jE8;
        Z5jE8:
        $pemjO->mVhOJ1PgG8J($LBcXf);
        goto PU33j;
        PU33j:
        return $pemjO;
        goto V3lp3;
        V3lp3:
    }
}
