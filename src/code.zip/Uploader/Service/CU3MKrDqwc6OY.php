<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
use Illuminate\Contracts\Filesystem\Filesystem;
final class CU3MKrDqwc6OY
{
    private $n_TUX;
    private $J1vIa;
    private $gcP3F;
    public function __construct(string $EwO1g, string $rtMO9, Filesystem $qxxOf)
    {
        goto Ma8NV;
        Ma8NV:
        $this->n_TUX = $EwO1g;
        goto fktTS;
        E5BkH:
        $this->gcP3F = $qxxOf;
        goto r0iHK;
        fktTS:
        $this->J1vIa = $rtMO9;
        goto E5BkH;
        r0iHK:
    }
    public function mz5B94lMFzq(HtHJXf7xellNX $I6_Gg) : string
    {
        goto qecJ8;
        fQQp2:
        return 's3://' . $this->n_TUX . '/' . $I6_Gg->getAttribute('filename');
        goto vYeIw;
        YJ5TU:
        return $this->gcP3F->url($I6_Gg->getAttribute('filename'));
        goto u68AT;
        qecJ8:
        if (!(L2PWLPeQEFi6U::S3 == $I6_Gg->getAttribute('driver'))) {
            goto l3Fai;
        }
        goto fQQp2;
        vYeIw:
        l3Fai:
        goto YJ5TU;
        u68AT:
    }
    public function mTB7a9Zz2c9(?string $Y_JtS) : ?string
    {
        goto az_zz;
        F6P0I:
        if (!str_contains($Y_JtS, $this->n_TUX)) {
            goto bH20P;
        }
        goto m8rVN;
        CJlS_:
        return null;
        goto twemR;
        IIguA:
        return 's3://' . $this->n_TUX . '/' . ltrim($lT4E3, '/');
        goto s2IT9;
        az_zz:
        if (!$Y_JtS) {
            goto D5jrC;
        }
        goto F6P0I;
        s2IT9:
        bH20P:
        goto BeRyc;
        m8rVN:
        $lT4E3 = parse_url($Y_JtS, PHP_URL_PATH);
        goto IIguA;
        BeRyc:
        D5jrC:
        goto CJlS_;
        twemR:
    }
    public function m6kgrtCrHHH(string $lT4E3) : string
    {
        return 's3://' . $this->n_TUX . '/' . $lT4E3;
    }
}
