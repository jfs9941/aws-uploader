<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\M9ges0moH9yTs;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Core\Observer\FrrYTGwRJFcqC;
use Jfs\Uploader\Core\Observer\Mp088ZrzJyHBF;
use Jfs\Uploader\Core\E2ynNzu6kpbgj;
use Jfs\Uploader\Core\TNpNhMZr7RgP2;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
use Jfs\Uploader\Exception\YZ6TFg5btsXHA;
use Jfs\Uploader\Exception\GK2ekyHdTOcHc;
use Jfs\Uploader\Service\FileResolver\PmKs34zySAetJ;
use Ramsey\Uuid\Uuid;
final class WkAFfUCbIBC7t
{
    private $C3JcD;
    private $OQTXf;
    private $RaPnW;
    public function __construct($SabDL, $eL8cO, $hTkyv)
    {
        goto RTEqC;
        GQ9_j:
        $this->OQTXf = $eL8cO;
        goto LlNSp;
        RTEqC:
        $this->C3JcD = $SabDL;
        goto GQ9_j;
        LlNSp:
        $this->RaPnW = $hTkyv;
        goto HxENP;
        HxENP:
    }
    public function mqyyNqenhOZ($Y_D0Z)
    {
        goto LVZql;
        Getd5:
        return $this->muT2CTFJOyT($lWX60->extension(), KPpxBU3Qc8yRk::S3, null, $Y_D0Z->options());
        goto ra7GW;
        LVZql:
        if (!$Y_D0Z instanceof SingleUploadInterface) {
            goto JmX6K;
        }
        goto o3ihd;
        o3ihd:
        $lWX60 = $Y_D0Z->getFile();
        goto Getd5;
        v231M:
        return $this->muT2CTFJOyT($Y_D0Z['file_extension'], 's3' === $Y_D0Z['driver'] ? KPpxBU3Qc8yRk::S3 : KPpxBU3Qc8yRk::LOCAL);
        goto K9qkN;
        ra7GW:
        JmX6K:
        goto v231M;
        K9qkN:
    }
    public function mnByRjIFcze(string $UcmDx)
    {
        goto wm4nM;
        SJAWU:
        $QxvEM->exists = true;
        goto MtTDI;
        Da5jW:
        $QxvEM = $this->muT2CTFJOyT($TeAou->getAttribute('type'), $TeAou->getAttribute('driver'), $TeAou->getAttribute('id'));
        goto SJAWU;
        MtTDI:
        $QxvEM->setRawAttributes($TeAou->getAttributes());
        goto CNHBP;
        wm4nM:
        $TeAou = config('upload.attachment_model')::findOrFail($UcmDx);
        goto Da5jW;
        CNHBP:
        return $QxvEM;
        goto mj7J3;
        mj7J3:
    }
    public function mfrezBo3W7l(string $y79QG) : M9ges0moH9yTs
    {
        goto r8xv6;
        P4Ozw:
        if ($s5_9D) {
            goto ljZ9c;
        }
        goto Ve1T4;
        tF0JN:
        if (!$JFwxi) {
            goto Uly6r;
        }
        goto sF022;
        DvE4D:
        throw new YZ6TFg5btsXHA('metadata file not found');
        goto HdUJF;
        z52Ju:
        $JFwxi = json_decode($s5_9D, true);
        goto tF0JN;
        VjJM2:
        ljZ9c:
        goto z52Ju;
        sF022:
        $jzf_w = TNpNhMZr7RgP2::mQOHluOGp5O($JFwxi);
        goto aMg1G;
        aMg1G:
        return $this->muT2CTFJOyT($jzf_w->EZhJ0, $jzf_w->mQPtzgYPpFf(), $jzf_w->filename);
        goto P21bj;
        P21bj:
        Uly6r:
        goto DvE4D;
        Ve1T4:
        $s5_9D = $this->RaPnW->get($y79QG);
        goto VjJM2;
        r8xv6:
        $s5_9D = $this->OQTXf->get($y79QG);
        goto P4Ozw;
        HdUJF:
    }
    private function muT2CTFJOyT(string $DHTsY, $jhH1x, ?string $UcmDx = null, array $xBmsh = [])
    {
        goto vm7DM;
        XY0MH:
        throw new GK2ekyHdTOcHc("not support file type {$DHTsY}");
        goto enj60;
        cLOXW:
        switch ($DHTsY) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $AlO7n = HSe6BNUpJTSwE::createFromScratch($UcmDx, $DHTsY);
                goto sLItt;
            case 'mp4':
            case 'mov':
                $AlO7n = QdnSnf08v9RV7::createFromScratch($UcmDx, $DHTsY);
                goto sLItt;
            case 'pdf':
                $AlO7n = E2ynNzu6kpbgj::createFromScratch($UcmDx, $DHTsY);
                goto sLItt;
            default:
                throw new GK2ekyHdTOcHc("not support file type {$DHTsY}");
        }
        goto ZhNGB;
        ZhNGB:
        LiN1w:
        goto NJ3cy;
        Z5imS:
        $AlO7n->mPleB6N0Rmu(new FrrYTGwRJFcqC($AlO7n));
        goto UciGh;
        o1AqX:
        $AlO7n = $AlO7n->mGPs830qtvy($jhH1x);
        goto Z5imS;
        NJ3cy:
        sLItt:
        goto o1AqX;
        UciGh:
        $AlO7n->mPleB6N0Rmu(new Mp088ZrzJyHBF($AlO7n, $this->RaPnW, $xBmsh));
        goto TWfMI;
        vm7DM:
        $UcmDx = $UcmDx ?? Uuid::uuid4()->getHex()->toString();
        goto cLOXW;
        IEZVa:
        MZ22Z:
        goto XY0MH;
        TWfMI:
        foreach ($this->C3JcD as $XNWw2) {
            goto pc3pT;
            pc3pT:
            if (!$XNWw2->mDoiLw48pZs($AlO7n)) {
                goto VdG1K;
            }
            goto IzXA6;
            C0Zs5:
            lbFd4:
            goto q4leE;
            jCMmd:
            VdG1K:
            goto C0Zs5;
            IzXA6:
            return $AlO7n->initLocation($XNWw2->mEuh2Srd8MD($AlO7n));
            goto jCMmd;
            q4leE:
        }
        goto IEZVa;
        enj60:
    }
}
