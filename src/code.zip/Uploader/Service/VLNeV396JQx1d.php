<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\WLzh1GrcHwitv;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Core\CuvWXGDQ9mxt7;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
final class VLNeV396JQx1d implements WLzh1GrcHwitv
{
    private $SXU7X;
    private $eIW3t;
    public $qT1zw;
    private $lzmVQ;
    private $pry58;
    private $AwDbR;
    public function __construct($QrPUa, $HcCGC, $AlPpU, $UCMZD, $VQ6Ko, $uwOBm)
    {
        goto yNbgw;
        p53fp:
        $this->eIW3t = $HcCGC;
        goto sthRz;
        PzJkS:
        $this->SXU7X = $QrPUa;
        goto p53fp;
        QW4HL:
        $this->lzmVQ = $UCMZD;
        goto ykFbs;
        yNbgw:
        $this->AwDbR = $uwOBm;
        goto PzJkS;
        ykFbs:
        $this->pry58 = $VQ6Ko;
        goto XUtbS;
        sthRz:
        $this->qT1zw = $AlPpU;
        goto QW4HL;
        XUtbS:
    }
    public function resolvePath($m5Vy1, $sjEM3 = LrHrisEWQ9E5o::S3) : string
    {
        goto UKQ2a;
        uxcJL:
        F6Oyg:
        goto b_hDq;
        H0RrH:
        return trim($this->qT1zw, '/') . '/' . $m5Vy1;
        goto rLFbV;
        uZqkf:
        return trim($this->eIW3t, '/') . '/' . $m5Vy1;
        goto zpRpy;
        rLFbV:
        im7R9:
        goto uZqkf;
        E2Nlk:
        $m5Vy1 = $m5Vy1->getAttribute('filename');
        goto uxcJL;
        tY_uS:
        tDKwa:
        goto lM3Sc;
        LkpCa:
        OyeDa:
        goto hduOz;
        b_hDq:
        if (!($sjEM3 === LrHrisEWQ9E5o::LOCAL)) {
            goto OyeDa;
        }
        goto bCadb;
        bCadb:
        return config('upload.home') . '/' . $m5Vy1;
        goto LkpCa;
        ah8Le:
        return $this->mJHKuMjCtF1($m5Vy1);
        goto tY_uS;
        lM3Sc:
        if (!$this->SXU7X) {
            goto im7R9;
        }
        goto H0RrH;
        hduOz:
        if (!(!empty($this->lzmVQ) && !empty($this->pry58))) {
            goto tDKwa;
        }
        goto ah8Le;
        UKQ2a:
        if (!$m5Vy1 instanceof UfttW7MErNAIK) {
            goto F6Oyg;
        }
        goto E2Nlk;
        zpRpy:
    }
    public function resolveThumbnail(UfttW7MErNAIK $m5Vy1) : string
    {
        goto RPvOc;
        dpMHI:
        LQmKD:
        goto h_ca7;
        vyjFJ:
        return $this->url($dWEzY, $m5Vy1->getAttribute('driver'));
        goto qQBoh;
        UDyWM:
        if (!$UeiFy) {
            goto aZaEq;
        }
        goto kuUnt;
        IINoe:
        aZaEq:
        goto Mo2Hu;
        ijOWn:
        $UeiFy = U0IzvN2kaLZHI::find($m5Vy1->getAttribute('thumbnail_id'));
        goto UDyWM;
        h_ca7:
        if (!$m5Vy1 instanceof CuvWXGDQ9mxt7) {
            goto HKVUA;
        }
        goto lVfC8;
        RPvOc:
        $dWEzY = $m5Vy1->getAttribute('thumbnail');
        goto Zf52e;
        oN4Sd:
        return $this->resolvePath($m5Vy1, $m5Vy1->getAttribute('driver'));
        goto dpMHI;
        Zf52e:
        if (!$dWEzY) {
            goto O44RD;
        }
        goto vyjFJ;
        lVfC8:
        return asset('/img/pdf-preview.svg');
        goto hcD2I;
        hcD2I:
        HKVUA:
        goto BBU9m;
        gumTv:
        if (!$m5Vy1 instanceof U0IzvN2kaLZHI) {
            goto LQmKD;
        }
        goto oN4Sd;
        Mo2Hu:
        BKi3N:
        goto gumTv;
        qQBoh:
        O44RD:
        goto sVey9;
        sVey9:
        if (!$m5Vy1->getAttribute('thumbnail_id')) {
            goto BKi3N;
        }
        goto ijOWn;
        BBU9m:
        return '';
        goto xKXet;
        kuUnt:
        return $this->resolvePath($UeiFy, $UeiFy->getAttribute('driver'));
        goto IINoe;
        xKXet:
    }
    private function url($uUtRl, $sjEM3)
    {
        goto W2BgF;
        HpRuV:
        return config('upload.home') . '/' . $uUtRl;
        goto nsRoh;
        YuwGn:
        return $this->resolvePath($uUtRl);
        goto d_TbA;
        W2BgF:
        if (!($sjEM3 == LrHrisEWQ9E5o::LOCAL)) {
            goto VO5ki;
        }
        goto HpRuV;
        nsRoh:
        VO5ki:
        goto YuwGn;
        d_TbA:
    }
    private function mJHKuMjCtF1($uUtRl)
    {
        goto jVT_x;
        QtcKB:
        $c3vDU = now()->addMinutes(60)->timestamp;
        goto HnU_d;
        HnU_d:
        $wCS6H = new UrlSigner($this->lzmVQ, $this->AwDbR->path($this->pry58));
        goto pD0wC;
        vTRvm:
        cQ6k8:
        goto maV7v;
        LuDuz:
        nv9oV:
        goto QtcKB;
        nFvQZ:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto LuDuz;
        maV7v:
        if (!(strpos($uUtRl, 'm3u8') !== false)) {
            goto nv9oV;
        }
        goto nFvQZ;
        pD0wC:
        return $wCS6H->getSignedUrl($this->qT1zw . '/' . $uUtRl, $c3vDU);
        goto HL9F4;
        ihpYq:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto vTRvm;
        jVT_x:
        if (!(strpos($uUtRl, 'https://') === 0)) {
            goto cQ6k8;
        }
        goto ihpYq;
        HL9F4:
    }
    public function resolvePathForHlsVideo(CpeNYzI7e1ALA $jYLmK, $jVzeG = false) : string
    {
        goto eck0x;
        mylSe:
        aWtHW:
        goto mQ7iu;
        eck0x:
        if ($jYLmK->getAttribute('hls_path')) {
            goto aWtHW;
        }
        goto ibGr2;
        mQ7iu:
        return $this->qT1zw . '/' . $jYLmK->getAttribute('hls_path');
        goto nJhxp;
        ibGr2:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto mylSe;
        nJhxp:
    }
    public function resolvePathForHlsVideos()
    {
        goto FHcnx;
        o52Hk:
        $aMW4n = json_encode(['Statement' => [['Resource' => sprintf('%s*', $TuxfP), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $c3vDU]]]]]);
        goto maFu2;
        GCzN1:
        $kAtNe = $mXJQQ->getSignedCookie(['key_pair_id' => $this->lzmVQ, 'private_key' => $this->AwDbR->path($this->pry58), 'policy' => $aMW4n]);
        goto tB8j3;
        maFu2:
        $mXJQQ = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto GCzN1;
        FHcnx:
        $c3vDU = now()->addDays(3)->timestamp;
        goto VOxW8;
        VOxW8:
        $TuxfP = $this->qT1zw . '/v2/hls/';
        goto o52Hk;
        tB8j3:
        return [$kAtNe, $c3vDU];
        goto broyv;
        broyv:
    }
}
