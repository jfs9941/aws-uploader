<?php
declare(strict_types=1);

namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Core\FileInterface;
use Jfs\Uploader\Core\PreSignedModel;
use Jfs\Uploader\Enum\FileStatus;
use Jfs\Uploader\Exception\InvalidStateTransitionException;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Jfs\Uploader\Exception\NonAcceptedFileException;

final class UploadService implements UploadServiceInterface
{
    /** @var FileFactory */
    private $factory;

    /** @var Filesystem */
    private $localStorage;

    /** @var Filesystem */
    private $s3Storage;

    /** @var string */
    private $s3Bucket;

    public function __construct(
        FileFactory $factory,
        Filesystem $localStorage,
        Filesystem $s3Storage,
        string $s3Bucket,
    ) {
        $this->factory = $factory;
        $this->localStorage = $localStorage;
        $this->s3Storage = $s3Storage;
        $this->s3Bucket = $s3Bucket;
    }

    /**
     * @throws NonAcceptedFileException|InvalidStateTransitionException
     */
    public function storeSingleFile(SingleUploadInterface $singleUpload): array
    {
        $file = $this->factory->createFile($singleUpload);

        // Store file in local storage
        $path = $this->s3Storage->putFileAs(
            dirname($file->getLocation()),
            $singleUpload->getFile(),
            $file->getFilename().'.'.$file->getExtension(),
            ['visibility' => 'public']
        );
        if (false !== $path && $file instanceof FileStateInterface) {
            $file->transitionTo(FileStatus::UPLOADED);
        } else {
            throw new \LogicException('File upload failed, check permissions');
        }

        // trigger event
        return $file->getView();
    }

    /**
     * @throws NonAcceptedFileException
     * @throws InvalidStateTransitionException
     */
    public function storePreSignedFile(array $preSignedUpload)
    {
        $file = $this->factory->createFile($preSignedUpload);
        $preSignedModel = PreSignedModel::fromFile($file, $this->localStorage, $this->s3Storage, $this->s3Bucket, true);
        $preSignedModel->createTempMetadata(
            $preSignedUpload['mime'],
            $preSignedUpload['file_size'],
            $preSignedUpload['chunk_size'],
            $preSignedUpload['checksums'],
            $preSignedUpload['user_id'],
            $preSignedUpload['driver']
        );
        $preSignedModel->markAsUploading();

        return [
            'filename' => $preSignedModel->getFile()->getFilename(),
            'chunkSize' => config('upload.chunk_size'),
            'urls' => $preSignedModel->getTempUrls(),
        ];
    }

    /**
     * @throws InvalidTempFileException|InvalidStateTransitionException|NonAcceptedFileException
     */
    public function updatePreSignedFile(string $uuid, int $fileStatus)
    {
        $preSignedModel = PreSignedModel::fromId($uuid, $this->localStorage, $this->s3Storage, $this->s3Bucket);

        switch ($fileStatus) {
            case FileStatus::UPLOADED:
                $preSignedModel->markAsUploaded();
                break;
            case FileStatus::PROCESSING:
                $preSignedModel->markAsProcessing();
                break;
            case FileStatus::FINISHED:
                $preSignedModel->markAsFinished();
                break;
            case FileStatus::ABORTED:
                $preSignedModel->markAsAborted();
                break;
        }
    }

    /**
     * @throws InvalidTempFileException
     * @throws InvalidStateTransitionException|NonAcceptedFileException
     */
    public function completePreSignedFile(string $uuid, array $parts)
    {
        $preSignedModel = PreSignedModel::fromId($uuid, $this->localStorage, $this->s3Storage, $this->s3Bucket);
        $preSignedModel->metadata()->setParts($parts);

        $preSignedModel->markAsUploaded();

        return [
            'path' => $preSignedModel->getFile()->getView()['path'],
            'thumbnail' => $preSignedModel->getFile()->thumbnail,
            'id' => $uuid
        ];
    }

    /**
     * @throws InvalidStateTransitionException
     * @throws NonAcceptedFileException
     */
    public function updateFile(string $uuid, int $fileStatus): FileInterface
    {
        $file = $this->factory->initFile($uuid);

        $file->transitionTo($fileStatus);

        return $file;
    }
}
