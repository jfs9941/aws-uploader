<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
final class VmrgwQFNELOFc
{
    private $zzcfY;
    private $bhIna;
    private $Hf14x;
    public function __construct(string $UYSBS, string $tW_EM, Filesystem $p1fCH)
    {
        goto RpWWa;
        WoxVm:
        $this->bhIna = $tW_EM;
        goto O3WQV;
        O3WQV:
        $this->Hf14x = $p1fCH;
        goto Y78cM;
        RpWWa:
        $this->zzcfY = $UYSBS;
        goto WoxVm;
        Y78cM:
    }
    public function m5oGWtlQvEX(CZj9PTf9Cv9Eq $dCHQU) : string
    {
        goto sQo0P;
        SsxV9:
        ukLDV:
        goto xbiWd;
        xbiWd:
        return $this->Hf14x->url($dCHQU->getAttribute('filename'));
        goto gEy9b;
        SRatL:
        return 's3://' . $this->zzcfY . '/' . $dCHQU->getAttribute('filename');
        goto SsxV9;
        sQo0P:
        if (!(N0ISad2bKF2Yp::S3 == $dCHQU->getAttribute('driver'))) {
            goto ukLDV;
        }
        goto SRatL;
        gEy9b:
    }
    public function m3Axrl68gEU(?string $tdBtP) : ?string
    {
        goto K5_Ri;
        XxTIv:
        zvKVo:
        goto AzdTO;
        K5_Ri:
        if (!$tdBtP) {
            goto zvKVo;
        }
        goto Y3rbV;
        AzdTO:
        return null;
        goto VtC8T;
        A1xMe:
        $Sblyk = parse_url($tdBtP, PHP_URL_PATH);
        goto ibPx4;
        Cqs3H:
        nWoP9:
        goto XxTIv;
        ibPx4:
        return 's3://' . $this->zzcfY . '/' . ltrim($Sblyk, '/');
        goto Cqs3H;
        Y3rbV:
        if (!A9cz2($tdBtP, $this->zzcfY)) {
            goto nWoP9;
        }
        goto A1xMe;
        VtC8T:
    }
    public function m18Gs7IFa4t(string $Sblyk) : string
    {
        return 's3://' . $this->zzcfY . '/' . $Sblyk;
    }
}
