<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\SXC0PdU9S8rem;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Core\McjNajNYCqDZl;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
final class PyfePz8BX4gVQ implements SXC0PdU9S8rem
{
    private $Rysye;
    private $p76mO;
    public $EgYO5;
    private $tVsWT;
    private $zsgwg;
    private $cGz6K;
    public function __construct($CmG38, $D9GOP, $l80O1, $Ne6in, $aeyrF, $DAY12)
    {
        goto n1LeD;
        HNNtv:
        $this->tVsWT = $Ne6in;
        goto TcLhd;
        TcLhd:
        $this->zsgwg = $aeyrF;
        goto fl1hp;
        I2mDl:
        $this->p76mO = $D9GOP;
        goto WqP2P;
        n1LeD:
        $this->cGz6K = $DAY12;
        goto SVaYo;
        WqP2P:
        $this->EgYO5 = $l80O1;
        goto HNNtv;
        SVaYo:
        $this->Rysye = $CmG38;
        goto I2mDl;
        fl1hp:
    }
    public function resolvePath($I80en, $bwFaL = ISqBWmYzjt1eQ::S3) : string
    {
        goto XRP6F;
        RZJPl:
        return trim($this->p76mO, '/') . '/' . $I80en;
        goto Rek8m;
        oums1:
        Ce4j5:
        goto cs7Ho;
        VzUVZ:
        if (!(!empty($this->tVsWT) && !empty($this->zsgwg))) {
            goto QDW3J;
        }
        goto mQYyY;
        XRP6F:
        if (!$I80en instanceof Z3KXO9qO3sUsa) {
            goto Ce4j5;
        }
        goto a8bEu;
        tCVe_:
        if (!$this->Rysye) {
            goto mJNju;
        }
        goto wll5b;
        gju2o:
        return config('upload.home') . '/' . $I80en;
        goto hS_vm;
        opVBv:
        mJNju:
        goto RZJPl;
        a8bEu:
        $I80en = $I80en->getAttribute('filename');
        goto oums1;
        hS_vm:
        QqzcK:
        goto VzUVZ;
        cs7Ho:
        if (!($bwFaL === ISqBWmYzjt1eQ::LOCAL)) {
            goto QqzcK;
        }
        goto gju2o;
        VoDsq:
        QDW3J:
        goto tCVe_;
        wll5b:
        return trim($this->EgYO5, '/') . '/' . $I80en;
        goto opVBv;
        mQYyY:
        return $this->m5m81p16dBo($I80en);
        goto VoDsq;
        Rek8m:
    }
    public function resolveThumbnail(Z3KXO9qO3sUsa $I80en) : string
    {
        goto DVsvn;
        ErP6_:
        sgY2r:
        goto Htd4X;
        fD13Q:
        fJUqs:
        goto V16lL;
        DVsvn:
        $iSeOK = $I80en->getAttribute('thumbnail');
        goto fZvh4;
        drfT_:
        return '';
        goto KC8Qg;
        klLr9:
        if (!$I80en->getAttribute('thumbnail_id')) {
            goto sgY2r;
        }
        goto CYCAV;
        gbmLA:
        return $this->resolvePath($I80en, $I80en->getAttribute('driver'));
        goto fD13Q;
        fZvh4:
        if (!$iSeOK) {
            goto oyxPk;
        }
        goto ZoEMC;
        StjIp:
        bh1L9:
        goto drfT_;
        V16lL:
        if (!$I80en instanceof McjNajNYCqDZl) {
            goto bh1L9;
        }
        goto PkiRu;
        FSEKV:
        mA08q:
        goto ErP6_;
        PkiRu:
        return asset('/img/pdf-preview.svg');
        goto StjIp;
        ocy25:
        return $this->resolvePath($ASIuN, $ASIuN->getAttribute('driver'));
        goto FSEKV;
        UvaED:
        oyxPk:
        goto klLr9;
        Htd4X:
        if (!$I80en instanceof VPGaYsuFJzbQ0) {
            goto fJUqs;
        }
        goto gbmLA;
        ZoEMC:
        return $this->url($iSeOK, $I80en->getAttribute('driver'));
        goto UvaED;
        CYCAV:
        $ASIuN = VPGaYsuFJzbQ0::find($I80en->getAttribute('thumbnail_id'));
        goto ZKr25;
        ZKr25:
        if (!$ASIuN) {
            goto mA08q;
        }
        goto ocy25;
        KC8Qg:
    }
    private function url($fQjwQ, $bwFaL)
    {
        goto GuhXq;
        Tf9ww:
        return $this->resolvePath($fQjwQ);
        goto CWoCU;
        h_YV9:
        v31ZL:
        goto Tf9ww;
        J7cSg:
        return config('upload.home') . '/' . $fQjwQ;
        goto h_YV9;
        GuhXq:
        if (!($bwFaL == ISqBWmYzjt1eQ::LOCAL)) {
            goto v31ZL;
        }
        goto J7cSg;
        CWoCU:
    }
    private function m5m81p16dBo($fQjwQ)
    {
        goto ixGT4;
        w5Dt3:
        if (!(strpos($fQjwQ, 'm3u8') !== false)) {
            goto udkhq;
        }
        goto b0UR6;
        AB5Q5:
        return $tFykE->getSignedUrl($this->EgYO5 . '/' . $fQjwQ, $sCFQV);
        goto m5pPd;
        V2XRZ:
        jfP0D:
        goto w5Dt3;
        ixGT4:
        if (!(strpos($fQjwQ, 'https://') === 0)) {
            goto jfP0D;
        }
        goto K762H;
        b0UR6:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto PsDlQ;
        ndzKA:
        $tFykE = new UrlSigner($this->tVsWT, $this->cGz6K->path($this->zsgwg));
        goto AB5Q5;
        K762H:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto V2XRZ;
        PsDlQ:
        udkhq:
        goto Mf07a;
        Mf07a:
        $sCFQV = now()->addMinutes(60)->timestamp;
        goto ndzKA;
        m5pPd:
    }
    public function resolvePathForHlsVideo(SNpic2wzC1yT8 $fxrDr, $TzR45 = false) : string
    {
        goto PNMkp;
        NS6qD:
        return $this->EgYO5 . '/' . $fxrDr->getAttribute('hls_path');
        goto EJuzx;
        PNMkp:
        if ($fxrDr->getAttribute('hls_path')) {
            goto t_NPO;
        }
        goto lTE7j;
        lTE7j:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto S1Qxx;
        S1Qxx:
        t_NPO:
        goto NS6qD;
        EJuzx:
    }
    public function resolvePathForHlsVideos()
    {
        goto Vwk_K;
        HZaec:
        $Fji9i = json_encode(['Statement' => [['Resource' => sprintf('%s*', $dsy6q), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $sCFQV]]]]]);
        goto Ao3KA;
        Ao3KA:
        $BjXiM = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto naCfd;
        naCfd:
        $Id1G1 = $BjXiM->getSignedCookie(['key_pair_id' => $this->tVsWT, 'private_key' => $this->cGz6K->path($this->zsgwg), 'policy' => $Fji9i]);
        goto efxBP;
        z_eJE:
        $dsy6q = $this->EgYO5 . '/v2/hls/';
        goto HZaec;
        Vwk_K:
        $sCFQV = now()->addDays(3)->timestamp;
        goto z_eJE;
        efxBP:
        return [$Id1G1, $sCFQV];
        goto nafbM;
        nafbM:
    }
}
