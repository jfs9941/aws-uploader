<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\VwiVLFCuZN4fA;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Core\EqLr3PLlMLHwV;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
final class M9fyBFwLMDM67 implements VwiVLFCuZN4fA
{
    private $bvzFO;
    private $RHt6R;
    public $Kvvlv;
    private $JqZhh;
    private $VPJur;
    private $Jhhox;
    public function __construct($KOhF0, $Ilb4N, $S98il, $eUUxe, $gvNcW, $bXh5v)
    {
        goto wJxOm;
        wJxOm:
        $this->Jhhox = $bXh5v;
        goto MuSSn;
        y0LxS:
        $this->Kvvlv = $S98il;
        goto RKLdc;
        eWM04:
        $this->RHt6R = $Ilb4N;
        goto y0LxS;
        MuSSn:
        $this->bvzFO = $KOhF0;
        goto eWM04;
        zaLAr:
        $this->VPJur = $gvNcW;
        goto OLJJ6;
        RKLdc:
        $this->JqZhh = $eUUxe;
        goto zaLAr;
        OLJJ6:
    }
    public function resolvePath($mDwO7, $C7qXl = NFXMub09wSQVu::S3) : string
    {
        goto ESmbT;
        ESmbT:
        if (!$mDwO7 instanceof D3Q3lppZQonk9) {
            goto SkCYF;
        }
        goto KOIop;
        qMM1m:
        return trim($this->Kvvlv, '/') . '/' . $mDwO7;
        goto BO4EL;
        KOIop:
        $mDwO7 = $mDwO7->getAttribute('filename');
        goto v8hWe;
        hmqkp:
        vSqlD:
        goto WbahJ;
        e1M79:
        WS_Lv:
        goto K1ELi;
        K1ELi:
        if (!(!empty($this->JqZhh) && !empty($this->VPJur))) {
            goto vSqlD;
        }
        goto LKf_P;
        BO4EL:
        dxIlr:
        goto sd8QB;
        sd8QB:
        return trim($this->RHt6R, '/') . '/' . $mDwO7;
        goto uArFH;
        v8hWe:
        SkCYF:
        goto dr6N3;
        WbahJ:
        if (!$this->bvzFO) {
            goto dxIlr;
        }
        goto qMM1m;
        dr6N3:
        if (!($C7qXl === NFXMub09wSQVu::LOCAL)) {
            goto WS_Lv;
        }
        goto rawDY;
        rawDY:
        return config('upload.home') . '/' . $mDwO7;
        goto e1M79;
        LKf_P:
        return $this->mre79WC6GAD($mDwO7);
        goto hmqkp;
        uArFH:
    }
    public function resolveThumbnail(D3Q3lppZQonk9 $mDwO7) : string
    {
        goto cvrJL;
        uyXMP:
        if (!$mDwO7 instanceof EqLr3PLlMLHwV) {
            goto LiKhq;
        }
        goto KZE3f;
        cvrJL:
        $NQQfI = $mDwO7->getAttribute('thumbnail');
        goto gRqqN;
        BPxXQ:
        $PNHef = OjvWwjWRqBzIO::find($mDwO7->getAttribute('thumbnail_id'));
        goto P6dki;
        JwXaz:
        LiKhq:
        goto BGfXt;
        P6dki:
        if (!$PNHef) {
            goto veodS;
        }
        goto eIIyG;
        YGL3W:
        if (!$mDwO7 instanceof OjvWwjWRqBzIO) {
            goto GHtKB;
        }
        goto dlbEi;
        KZE3f:
        return asset('/img/pdf-preview.svg');
        goto JwXaz;
        VmQDz:
        HnFj3:
        goto fpkx7;
        z5gZJ:
        veodS:
        goto onjVy;
        onjVy:
        TQUh0:
        goto YGL3W;
        x0SVY:
        GHtKB:
        goto uyXMP;
        eIIyG:
        return $this->resolvePath($PNHef, $PNHef->getAttribute('driver'));
        goto z5gZJ;
        gRqqN:
        if (!$NQQfI) {
            goto HnFj3;
        }
        goto r5vY3;
        BGfXt:
        return '';
        goto lSVxn;
        r5vY3:
        return $this->url($NQQfI, $mDwO7->getAttribute('driver'));
        goto VmQDz;
        dlbEi:
        return $this->resolvePath($mDwO7, $mDwO7->getAttribute('driver'));
        goto x0SVY;
        fpkx7:
        if (!$mDwO7->getAttribute('thumbnail_id')) {
            goto TQUh0;
        }
        goto BPxXQ;
        lSVxn:
    }
    private function url($F0ycc, $C7qXl)
    {
        goto dtwMR;
        fOLdA:
        fVlgT:
        goto DZUwh;
        DZUwh:
        return $this->resolvePath($F0ycc);
        goto iFaRX;
        dtwMR:
        if (!($C7qXl == NFXMub09wSQVu::LOCAL)) {
            goto fVlgT;
        }
        goto WFUiV;
        WFUiV:
        return config('upload.home') . '/' . $F0ycc;
        goto fOLdA;
        iFaRX:
    }
    private function mre79WC6GAD($F0ycc)
    {
        goto VK2Zs;
        GifY6:
        return $ItAMy->getSignedUrl($this->Kvvlv . '/' . $F0ycc, $vBIDS);
        goto LxawL;
        m6ss1:
        rWvE7:
        goto O2XQ2;
        O2XQ2:
        $vBIDS = now()->addMinutes(60)->timestamp;
        goto gLc2O;
        gLc2O:
        $ItAMy = new UrlSigner($this->JqZhh, $this->Jhhox->path($this->VPJur));
        goto GifY6;
        ah5C3:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto JPc5b;
        VK2Zs:
        if (!(strpos($F0ycc, 'https://') === 0)) {
            goto ga2ry;
        }
        goto ah5C3;
        JPc5b:
        ga2ry:
        goto zzJDs;
        ahUJA:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto m6ss1;
        zzJDs:
        if (!(strpos($F0ycc, 'm3u8') !== false)) {
            goto rWvE7;
        }
        goto ahUJA;
        LxawL:
    }
    public function resolvePathForHlsVideo(HVuLZHLrSam0d $jZqB7, $sNDDn = false) : string
    {
        goto v1Zu_;
        nfpfR:
        PIb6O:
        goto Pl7Um;
        U2Rc7:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto nfpfR;
        v1Zu_:
        if ($jZqB7->getAttribute('hls_path')) {
            goto PIb6O;
        }
        goto U2Rc7;
        Pl7Um:
        return $this->Kvvlv . '/' . $jZqB7->getAttribute('hls_path');
        goto VY3pF;
        VY3pF:
    }
    public function resolvePathForHlsVideos()
    {
        goto sW0X8;
        FKkUG:
        $JnQ0m = $OxFJF->getSignedCookie(['key_pair_id' => $this->JqZhh, 'private_key' => $this->Jhhox->path($this->VPJur), 'policy' => $ktalT]);
        goto OPjI1;
        NaPPt:
        $wbC0R = $this->Kvvlv . '/v2/hls/';
        goto EgFxV;
        OPjI1:
        return [$JnQ0m, $vBIDS];
        goto PFX49;
        WG22i:
        $OxFJF = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto FKkUG;
        EgFxV:
        $ktalT = json_encode(['Statement' => [['Resource' => sprintf('%s*', $wbC0R), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $vBIDS]]]]]);
        goto WG22i;
        sW0X8:
        $vBIDS = now()->addDays(3)->timestamp;
        goto NaPPt;
        PFX49:
    }
}
