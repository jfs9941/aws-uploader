<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
final class BDt6SdH8IQ07z
{
    private $rczpf;
    private $CNVFy;
    private $bX3fI;
    public function __construct(string $qir1P, string $EfwTq, Filesystem $Q0hWX)
    {
        goto W2wbq;
        JZkyG:
        $this->bX3fI = $Q0hWX;
        goto ZFz3n;
        W2wbq:
        $this->rczpf = $qir1P;
        goto OeWmt;
        OeWmt:
        $this->CNVFy = $EfwTq;
        goto JZkyG;
        ZFz3n:
    }
    public function mhZNFCLx5uj(GuA6QuvssLUzf $nNNVD) : string
    {
        goto HfXuE;
        HfXuE:
        if (!(FUIPeZ7ssitYw::S3 == $nNNVD->getAttribute('driver'))) {
            goto V5Y49;
        }
        goto Lw8fm;
        Lvwrw:
        V5Y49:
        goto eHCp7;
        Lw8fm:
        return 's3://' . $this->rczpf . '/' . $nNNVD->getAttribute('filename');
        goto Lvwrw;
        eHCp7:
        return $this->bX3fI->url($nNNVD->getAttribute('filename'));
        goto nIQP4;
        nIQP4:
    }
    public function mIzQ8ovCIrk(?string $vUmcN) : ?string
    {
        goto wKpzB;
        kpJHN:
        if (!eAGx1($vUmcN, $this->rczpf)) {
            goto NgZBv;
        }
        goto Pu_Hf;
        G9q1a:
        return 's3://' . $this->rczpf . '/' . ltrim($JM0UK, '/');
        goto da9BM;
        P2Llo:
        j4ue3:
        goto jEsw_;
        jEsw_:
        return null;
        goto gLBMV;
        da9BM:
        NgZBv:
        goto P2Llo;
        Pu_Hf:
        $JM0UK = parse_url($vUmcN, PHP_URL_PATH);
        goto G9q1a;
        wKpzB:
        if (!$vUmcN) {
            goto j4ue3;
        }
        goto kpJHN;
        gLBMV:
    }
    public function mNE0zVY6w96(string $JM0UK) : string
    {
        return 's3://' . $this->rczpf . '/' . $JM0UK;
    }
}
