<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\IfP50GBBbx63a;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class FXddnQ0BHKM8d implements VideoPostHandleServiceInterface
{
    private $E0k8p;
    private $cC_4U;
    public function __construct(UploadServiceInterface $GvWap, Filesystem $s1UdZ)
    {
        $this->E0k8p = $GvWap;
        $this->cC_4U = $s1UdZ;
    }
    public function saveMetadata(string $q8q1b, array $MCnj4)
    {
        goto UAe4o;
        VZSY1:
        if (!(isset($MCnj4['change_status']) && $MCnj4['change_status'])) {
            goto Mx8M5;
        }
        goto zRr2Q;
        rew40:
        if (!isset($MCnj4['fps'])) {
            goto lwtWa;
        }
        goto Y4itQ;
        VRYuO:
        unset($WTI43['thumbnail']);
        goto B1d68;
        Fnmrd:
        return $cFlec->getView();
        goto KGgOs;
        zRr2Q:
        $this->E0k8p->updateFile($cFlec->getAttribute('id'), IfP50GBBbx63a::PROCESSING);
        goto tR2bB;
        nI1Am:
        $WTI43['duration'] = $MCnj4['duration'];
        goto mbpeO;
        jF8LL:
        throw new \Exception("O1jfuwJR340k5 metadata store failed for unknown reason ... " . $q8q1b);
        goto TDL3f;
        Y4itQ:
        $WTI43['fps'] = $MCnj4['fps'];
        goto bve50;
        NKsWX:
        if (!isset($MCnj4['thumbnail_url'])) {
            goto CBS_0;
        }
        goto pMJ1t;
        c2h93:
        $WTI43['resolution'] = $MCnj4['resolution'];
        goto UDVy4;
        B1d68:
        wEDtC:
        goto sjvV_;
        IgxNF:
        if (!$cFlec->nuqvM) {
            goto wEDtC;
        }
        goto VRYuO;
        tR2bB:
        Mx8M5:
        goto Fnmrd;
        bIA4A:
        CBS_0:
        goto T6d3l;
        zpBCx:
        if (!isset($MCnj4['duration'])) {
            goto eCOUX;
        }
        goto nI1Am;
        yXrih:
        IScVB:
        goto zpBCx;
        UDVy4:
        zYAI7:
        goto rew40;
        mbpeO:
        eCOUX:
        goto OK3nx;
        WyRxm:
        Log::warning("O1jfuwJR340k5 metadata store failed for unknown reason ... " . $q8q1b);
        goto jF8LL;
        VcTcG:
        $WTI43 = [];
        goto NKsWX;
        UAe4o:
        $cFlec = O1jfuwJR340k5::findOrFail($q8q1b);
        goto VcTcG;
        Q4fCg:
        try {
            goto Apjuu;
            hYV3Z:
            $WTI43['thumbnail_id'] = $XqjZc['id'];
            goto YjXOy;
            YjXOy:
            $WTI43['thumbnail'] = $XqjZc['filename'];
            goto EIFQQ;
            Apjuu:
            $XqjZc = $this->E0k8p->storeSingleFile(new class($MCnj4['thumbnail']) implements SingleUploadInterface
            {
                private $U4MDy;
                public function __construct($mz56v)
                {
                    $this->U4MDy = $mz56v;
                }
                public function getFile()
                {
                    return $this->U4MDy;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto hYV3Z;
            EIFQQ:
        } catch (\Throwable $j62Rn) {
            Log::warning("O1jfuwJR340k5 thumbnail store failed: " . $j62Rn->getMessage());
        }
        goto yXrih;
        OK3nx:
        if (!isset($MCnj4['resolution'])) {
            goto zYAI7;
        }
        goto c2h93;
        sjvV_:
        if (!$cFlec->update($WTI43)) {
            goto U_Huc;
        }
        goto VZSY1;
        KGgOs:
        U_Huc:
        goto WyRxm;
        bve50:
        lwtWa:
        goto IgxNF;
        T6d3l:
        if (!isset($MCnj4['thumbnail'])) {
            goto IScVB;
        }
        goto Q4fCg;
        pMJ1t:
        $WTI43['thumbnail'] = $MCnj4['thumbnail_url'];
        goto bIA4A;
        TDL3f:
    }
    public function createThumbnail(string $pX6WZ) : void
    {
        goto vfO4Z;
        zabiG:
        $YHu8P = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto NxfNh;
        ihmNk:
        pj1tI:
        goto Kw0Z0;
        vfO4Z:
        Log::info("Use Lambda to generate thumbnail for video: " . $pX6WZ);
        goto Sa1xP;
        NxfNh:
        try {
            goto TRYMS;
            aZHgV:
            $YHu8P->sendMessage(['QueueUrl' => $NB3VH, 'MessageBody' => json_encode(['file_path' => $cFlec->getLocation()])]);
            goto XqEho;
            TRYMS:
            $vhnY5 = $YHu8P->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto RtR7a;
            RtR7a:
            $NB3VH = $vhnY5->get('QueueUrl');
            goto aZHgV;
            XqEho:
        } catch (\Throwable $r5DbO) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$r5DbO->getMessage()}");
        }
        goto ihmNk;
        Sa1xP:
        $cFlec = O1jfuwJR340k5::findOrFail($pX6WZ);
        goto p5tO9;
        mW9CC:
        if (!(!$this->cC_4U->directoryExists($WtKC3) && empty($cFlec->mBE1dTRMsWC()))) {
            goto pj1tI;
        }
        goto zabiG;
        p5tO9:
        $WtKC3 = "v2/hls/thumbnails/{$pX6WZ}/";
        goto mW9CC;
        Kw0Z0:
    }
    public function mrvGJOXQs9Z(string $pX6WZ) : void
    {
        goto CtkMI;
        kkYlW:
        if (!(count($gLc71) === 0)) {
            goto Xjcnu;
        }
        goto VSJRM;
        UUO88:
        if ($this->cC_4U->directoryExists($WtKC3)) {
            goto dqvK_;
        }
        goto muS2e;
        muS2e:
        Log::error("Message back with success data but not found thumbnail " . $pX6WZ);
        goto BEqlp;
        JaX1E:
        $cFlec->update(['generated_previews' => $WtKC3]);
        goto jQtBG;
        d23pC:
        $gLc71 = $this->cC_4U->files($WtKC3);
        goto kkYlW;
        UmYVD:
        dqvK_:
        goto d23pC;
        Gqj96:
        $WtKC3 = "v2/hls/thumbnails/{$pX6WZ}/";
        goto UUO88;
        LNjXO:
        Xjcnu:
        goto JaX1E;
        BEqlp:
        throw new \Exception("Message back with success data but not found thumbnail " . $pX6WZ);
        goto UmYVD;
        ck3hi:
        throw new \Exception("Message back with success data but not found thumbnail files " . $pX6WZ);
        goto LNjXO;
        CtkMI:
        $cFlec = O1jfuwJR340k5::findOrFail($pX6WZ);
        goto Gqj96;
        VSJRM:
        Log::error("Message back with success data but not found thumbnail files " . $pX6WZ);
        goto ck3hi;
        jQtBG:
    }
    public function getThumbnails(string $pX6WZ) : array
    {
        $cFlec = O1jfuwJR340k5::findOrFail($pX6WZ);
        return $cFlec->getThumbnails();
    }
    public function getMedia(string $pX6WZ) : array
    {
        $XCcud = Media::findOrFail($pX6WZ);
        return $XCcud->getView();
    }
}
