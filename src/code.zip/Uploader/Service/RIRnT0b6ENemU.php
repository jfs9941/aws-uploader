<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\GCZ2vyVNpj70n;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Core\Observer\H00Qys9fnO6eZ;
use Jfs\Uploader\Core\Observer\QDZMpb9AGAW1H;
use Jfs\Uploader\Core\WLv4xzk21eiAP;
use Jfs\Uploader\Core\HMzvJtEcyxrN7;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\DccywYjigTakI;
use Jfs\Uploader\Exception\Wu1EwEzrOvt3c;
use Jfs\Uploader\Exception\YoMZumD8PRcVT;
use Jfs\Uploader\Service\FileResolver\YlkMj7hiefpew;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class RIRnT0b6ENemU
{
    private $UmlA6;
    private $yt19t;
    private $gErml;
    public function __construct($ChWoO, $RndMA, $DFpIk)
    {
        goto YcLph;
        YcLph:
        $this->UmlA6 = $ChWoO;
        goto W4gBV;
        W4gBV:
        $this->yt19t = $RndMA;
        goto RGimt;
        RGimt:
        $this->gErml = $DFpIk;
        goto WyRhs;
        WyRhs:
    }
    public function mZ7qxQ2pqeJ($qKUtj)
    {
        goto XPfRZ;
        pnY87:
        return $this->mKJnpTEfN3l($dzquN->extension(), DccywYjigTakI::S3, null, $qKUtj->options());
        goto PbRUO;
        g0oEh:
        $dzquN = $qKUtj->getFile();
        goto pnY87;
        PbRUO:
        yy8cG:
        goto qB_ZC;
        XPfRZ:
        if (!$qKUtj instanceof SingleUploadInterface) {
            goto yy8cG;
        }
        goto g0oEh;
        qB_ZC:
        return $this->mKJnpTEfN3l($qKUtj['file_extension'], 's3' === $qKUtj['driver'] ? DccywYjigTakI::S3 : DccywYjigTakI::LOCAL);
        goto Ct5pq;
        Ct5pq:
    }
    public function mE3a97ii6ha(string $J_scC)
    {
        goto Rtq1U;
        x89IU:
        $dV9QE = $this->mKJnpTEfN3l($b55fD->getAttribute('type'), $b55fD->getAttribute('driver'), $b55fD->getAttribute('id'));
        goto hOps2;
        hOps2:
        $dV9QE->exists = true;
        goto EG7I1;
        EG7I1:
        $dV9QE->setRawAttributes($b55fD->getAttributes());
        goto kBYBW;
        kBYBW:
        return $dV9QE;
        goto iQeJ3;
        Rtq1U:
        $b55fD = config('upload.attachment_model')::findOrFail($J_scC);
        goto x89IU;
        iQeJ3:
    }
    public function mw8WSqR4dJv(string $e4V97) : GCZ2vyVNpj70n
    {
        goto X38_v;
        SOr78:
        JsFSx:
        goto AXnQ2;
        FyXKA:
        return $this->mKJnpTEfN3l($x4Fhj->RIBGm, $x4Fhj->mUhQWRUP9sw(), $x4Fhj->filename);
        goto SOr78;
        JTkaM:
        if (!$zkqCI) {
            goto JsFSx;
        }
        goto k7R8K;
        Yv0Pn:
        $x4_nr = $this->gErml->get($e4V97);
        goto lxSeh;
        ImWKG:
        if ($x4_nr) {
            goto IFjtl;
        }
        goto Yv0Pn;
        AXnQ2:
        throw new Wu1EwEzrOvt3c('metadata file not found');
        goto vKMmh;
        lxSeh:
        IFjtl:
        goto OozRo;
        X38_v:
        $x4_nr = $this->yt19t->get($e4V97);
        goto ImWKG;
        OozRo:
        $zkqCI = json_decode($x4_nr, true);
        goto JTkaM;
        k7R8K:
        $x4Fhj = HMzvJtEcyxrN7::mqHLSM6Jtbu($zkqCI);
        goto FyXKA;
        vKMmh:
    }
    private function mKJnpTEfN3l(string $QUdr3, $nsjb1, ?string $J_scC = null, array $wNMDX = [])
    {
        goto boQOD;
        Pfo94:
        ILK8T:
        goto XeOsf;
        PAq4j:
        HY957:
        goto PnKaX;
        KKRiv:
        $vx3tN->mJpwZRYg1fj(new H00Qys9fnO6eZ($vx3tN));
        goto RVP1J;
        RVP1J:
        $vx3tN->mJpwZRYg1fj(new QDZMpb9AGAW1H($vx3tN, $this->gErml, $wNMDX));
        goto JZPjX;
        nJ1FK:
        switch ($QUdr3) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $vx3tN = XK5kReLMTU1ob::createFromScratch($J_scC, $QUdr3);
                goto ILK8T;
            case 'mp4':
            case 'mov':
                $vx3tN = BG2FRpwGrKqJx::createFromScratch($J_scC, $QUdr3);
                goto ILK8T;
            case 'pdf':
                $vx3tN = WLv4xzk21eiAP::createFromScratch($J_scC, $QUdr3);
                goto ILK8T;
            default:
                throw new YoMZumD8PRcVT("not support file type {$QUdr3}");
        }
        goto fpf8K;
        JZPjX:
        foreach ($this->UmlA6 as $vCrTa) {
            goto HQ5jX;
            O7HAI:
            iCWL2:
            goto MZIa5;
            HQ5jX:
            if (!$vCrTa->mBo2PjwPlax($vx3tN)) {
                goto iCWL2;
            }
            goto wzVq3;
            wzVq3:
            return $vx3tN->initLocation($vCrTa->mELOenBEMpO($vx3tN));
            goto O7HAI;
            MZIa5:
            eiVjV:
            goto b_DVg;
            b_DVg:
        }
        goto PAq4j;
        PnKaX:
        throw new YoMZumD8PRcVT("not support file type {$QUdr3}");
        goto BLc0a;
        fpf8K:
        u8u5f:
        goto Pfo94;
        XeOsf:
        $vx3tN = $vx3tN->m2ptukIdZbw($nsjb1);
        goto KKRiv;
        boQOD:
        $J_scC = $J_scC ?? Uuid::uuid4()->getHex()->toString();
        goto nJ1FK;
        BLc0a:
    }
}
