<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\ZBw3vE9HMeZfI;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Core\XpjbCMtbhbQNm;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
final class Q9u6o449sXscP implements ZBw3vE9HMeZfI
{
    private $TsPrf;
    private $Ia5Qi;
    public $ZZmGn;
    private $QUy9F;
    private $f4PHR;
    private $ofZvx;
    public function __construct($D1KjV, $DuUVd, $G6Lsm, $vctpN, $meQ80, $suNmN)
    {
        goto HTkXm;
        Xx3B7:
        $this->Ia5Qi = $DuUVd;
        goto CsgoH;
        Lt1k2:
        $this->f4PHR = $meQ80;
        goto TyRy1;
        HTkXm:
        $this->ofZvx = $suNmN;
        goto Yzqln;
        CsgoH:
        $this->ZZmGn = $G6Lsm;
        goto W29RO;
        Yzqln:
        $this->TsPrf = $D1KjV;
        goto Xx3B7;
        W29RO:
        $this->QUy9F = $vctpN;
        goto Lt1k2;
        TyRy1:
    }
    public function resolvePath($aB0a5, $N4v2t = I5kpK7wkbRQvu::S3) : string
    {
        goto L5UQr;
        Hrwxx:
        return trim($this->ZZmGn, '/') . '/' . $aB0a5;
        goto qlvsI;
        RF20i:
        if (!(!empty($this->QUy9F) && !empty($this->f4PHR))) {
            goto Mqo4D;
        }
        goto vsAtk;
        vsAtk:
        return $this->mn8ITED0HhV($aB0a5);
        goto wxqvm;
        DNk1G:
        return config('upload.home') . '/' . $aB0a5;
        goto m_spr;
        UwUqE:
        $aB0a5 = $aB0a5->getAttribute('filename');
        goto EMzCP;
        m_spr:
        GnN1G:
        goto RF20i;
        uMiA8:
        if (!($N4v2t === I5kpK7wkbRQvu::LOCAL)) {
            goto GnN1G;
        }
        goto DNk1G;
        xLJX2:
        if (!$this->TsPrf) {
            goto XZ_yU;
        }
        goto Hrwxx;
        wxqvm:
        Mqo4D:
        goto xLJX2;
        qlvsI:
        XZ_yU:
        goto SlzEK;
        SlzEK:
        return trim($this->Ia5Qi, '/') . '/' . $aB0a5;
        goto g4uUV;
        EMzCP:
        GbEMP:
        goto uMiA8;
        L5UQr:
        if (!$aB0a5 instanceof MIyg7KY6jn9L1) {
            goto GbEMP;
        }
        goto UwUqE;
        g4uUV:
    }
    public function resolveThumbnail(MIyg7KY6jn9L1 $aB0a5) : string
    {
        goto ur1Nv;
        YSQBy:
        if (!$aB0a5 instanceof XpjbCMtbhbQNm) {
            goto ghAS5;
        }
        goto lOBeq;
        WWVf3:
        $LcfJB = JMa7GBaLcnq3D::find($aB0a5->getAttribute('thumbnail_id'));
        goto MQLM_;
        wVC0m:
        return $this->resolvePath($aB0a5, $aB0a5->getAttribute('driver'));
        goto YxPQC;
        xUkro:
        return $this->url($oEyCz, $aB0a5->getAttribute('driver'));
        goto lIYJb;
        YxPQC:
        Enmaw:
        goto YSQBy;
        MQLM_:
        if (!$LcfJB) {
            goto mf2Xs;
        }
        goto PlZf1;
        lIYJb:
        Z4Pp3:
        goto lB5C7;
        pyaLp:
        if (!$oEyCz) {
            goto Z4Pp3;
        }
        goto xUkro;
        lOBeq:
        return asset('/img/pdf-preview.svg');
        goto TbFgt;
        X83BQ:
        mf2Xs:
        goto WwfEA;
        hoORn:
        return '';
        goto WVAa5;
        lB5C7:
        if (!$aB0a5->getAttribute('thumbnail_id')) {
            goto ZSN9c;
        }
        goto WWVf3;
        PlZf1:
        return $this->resolvePath($LcfJB, $LcfJB->getAttribute('driver'));
        goto X83BQ;
        ur1Nv:
        $oEyCz = $aB0a5->getAttribute('thumbnail');
        goto pyaLp;
        WwfEA:
        ZSN9c:
        goto sVQw8;
        TbFgt:
        ghAS5:
        goto hoORn;
        sVQw8:
        if (!$aB0a5 instanceof JMa7GBaLcnq3D) {
            goto Enmaw;
        }
        goto wVC0m;
        WVAa5:
    }
    private function url($vRakW, $N4v2t)
    {
        goto zYv9T;
        zYv9T:
        if (!($N4v2t == I5kpK7wkbRQvu::LOCAL)) {
            goto FSM43;
        }
        goto ieXsb;
        TK8Dm:
        FSM43:
        goto BI_vy;
        ieXsb:
        return config('upload.home') . '/' . $vRakW;
        goto TK8Dm;
        BI_vy:
        return $this->resolvePath($vRakW);
        goto O9ATf;
        O9ATf:
    }
    private function mn8ITED0HhV($vRakW)
    {
        goto hemu4;
        vH2uR:
        if (!(strpos($vRakW, 'm3u8') !== false)) {
            goto BJk2f;
        }
        goto S4F81;
        UhjZ9:
        BJk2f:
        goto GUyq4;
        pfcIm:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto NKd4K;
        NKd4K:
        X43jx:
        goto vH2uR;
        S4F81:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto UhjZ9;
        bkz9Y:
        $o4M_N = new UrlSigner($this->QUy9F, $this->ofZvx->path($this->f4PHR));
        goto AbC2S;
        GUyq4:
        $AHxlQ = now()->addMinutes(60)->timestamp;
        goto bkz9Y;
        hemu4:
        if (!(strpos($vRakW, 'https://') === 0)) {
            goto X43jx;
        }
        goto pfcIm;
        AbC2S:
        return $o4M_N->getSignedUrl($this->ZZmGn . '/' . $vRakW, $AHxlQ);
        goto BDSLh;
        BDSLh:
    }
    public function resolvePathForHlsVideo(VPegVN4NByLqJ $fTkob, $bRIpC = false) : string
    {
        goto uY6sk;
        ebHug:
        hES2v:
        goto DsJOs;
        DsJOs:
        return $this->ZZmGn . '/' . $fTkob->getAttribute('hls_path');
        goto i6FXo;
        Tpwij:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto ebHug;
        uY6sk:
        if ($fTkob->getAttribute('hls_path')) {
            goto hES2v;
        }
        goto Tpwij;
        i6FXo:
    }
    public function resolvePathForHlsVideos()
    {
        goto VmXrj;
        mB7AD:
        $sYHUu = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto BWVPb;
        aTLws:
        return [$Hcovv, $AHxlQ];
        goto ngYj8;
        VmXrj:
        $AHxlQ = now()->addDays(3)->timestamp;
        goto jd4eb;
        jd4eb:
        $RM2nT = $this->ZZmGn . '/v2/hls/';
        goto aIlT3;
        aIlT3:
        $Kplv8 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $RM2nT), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $AHxlQ]]]]]);
        goto mB7AD;
        BWVPb:
        $Hcovv = $sYHUu->getSignedCookie(['key_pair_id' => $this->QUy9F, 'private_key' => $this->ofZvx->path($this->f4PHR), 'policy' => $Kplv8]);
        goto aTLws;
        ngYj8:
    }
}
