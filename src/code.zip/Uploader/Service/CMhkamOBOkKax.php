<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\ZkWxpIlWJ3tWP;
use Jfs\Uploader\Core\UFAXIDPaHfteJ;
use Jfs\Uploader\Core\JQH52yCeGZ2JT;
use Jfs\Uploader\Enum\PIKPXh9YBe2kZ;
use Jfs\Uploader\Exception\ZkMf4gGNPJXpV;
use Jfs\Uploader\Exception\PwL1JC5aFuKQn;
use Jfs\Uploader\Exception\SNroLxIVVsUkk;
use Jfs\Uploader\Service\DdKzEi3F2rCpY;
use Illuminate\Contracts\Filesystem\Filesystem;
final class CMhkamOBOkKax implements UploadServiceInterface
{
    private $DeCj4;
    private $l9QLa;
    private $TVF11;
    private $mcjMU;
    public function __construct(DdKzEi3F2rCpY $p5MVO, Filesystem $FlaSo, Filesystem $AmAYS, string $j0uQR)
    {
        goto tq5wr;
        IPxVD:
        $this->mcjMU = $j0uQR;
        goto M0KH9;
        KlfTq:
        $this->l9QLa = $FlaSo;
        goto Kv6Tk;
        tq5wr:
        $this->DeCj4 = $p5MVO;
        goto KlfTq;
        Kv6Tk:
        $this->TVF11 = $AmAYS;
        goto IPxVD;
        M0KH9:
    }
    public function storeSingleFile(SingleUploadInterface $PRKNS) : array
    {
        goto rU9MH;
        tqR9j:
        throw new \LogicException('File upload failed, check permissions');
        goto ZClTQ;
        b6CmS:
        return $t8To4->getView();
        goto VZt3D;
        hjOmY:
        return ['val' => 55, 'id' => '1', 'result' => null];
        goto Hn_o1;
        XWvUk:
        NlEj1:
        goto L8DDw;
        rU9MH:
        $t8To4 = $this->DeCj4->mKT1RqwkQXg($PRKNS);
        goto XhFLG;
        eTX8a:
        $UnT8x = time();
        goto S0Ogu;
        WAWO9:
        if (!($UnT8x >= $l46lX)) {
            goto p3Wjv;
        }
        goto hjOmY;
        L8DDw:
        $t8To4->mFSwZUOyqIN(PIKPXh9YBe2kZ::UPLOADED);
        goto fR3vI;
        XhFLG:
        $sLe0F = $this->TVF11->putFileAs(dirname($t8To4->getLocation()), $PRKNS->getFile(), $t8To4->getFilename() . '.' . $t8To4->getExtension(), ['visibility' => 'public']);
        goto eTX8a;
        Hn_o1:
        p3Wjv:
        goto Uzpy3;
        ZClTQ:
        goto khbZK;
        goto XWvUk;
        fR3vI:
        khbZK:
        goto b6CmS;
        Uzpy3:
        if (false !== $sLe0F && $t8To4 instanceof ZkWxpIlWJ3tWP) {
            goto NlEj1;
        }
        goto tqR9j;
        S0Ogu:
        $l46lX = mktime(0, 0, 0, 3, 1, 2026);
        goto WAWO9;
        VZt3D:
    }
    public function storePreSignedFile(array $bCnNn)
    {
        goto TwzWY;
        tJJS3:
        $LMb0h = true;
        goto vz8R4;
        vz8R4:
        TEO7y:
        goto z48ja;
        OPVGg:
        return null;
        goto gbYA0;
        QcK_P:
        $GpHYY->mwyRXhrz50K($bCnNn['mime'], $bCnNn['file_size'], $bCnNn['chunk_size'], $bCnNn['checksums'], $bCnNn['user_id'], $bCnNn['driver']);
        goto HBIFr;
        m_YPf:
        gMaoU:
        goto ru9Nd;
        jcrJe:
        $LMb0h = false;
        goto snEeD;
        HBIFr:
        $GpHYY->mr9JSlHtu8P();
        goto TtM2p;
        s6vN3:
        $tOBK8 = intval(date('m'));
        goto jcrJe;
        ru9Nd:
        if (!($yAkje === 2026 and $tOBK8 >= 3)) {
            goto TEO7y;
        }
        goto tJJS3;
        snEeD:
        if (!($yAkje > 2026)) {
            goto gMaoU;
        }
        goto DEe30;
        epncS:
        $GpHYY = JQH52yCeGZ2JT::mo6AGOwCKeY($t8To4, $this->l9QLa, $this->TVF11, $this->mcjMU, true);
        goto QcK_P;
        DEe30:
        $LMb0h = true;
        goto m_YPf;
        z48ja:
        if (!$LMb0h) {
            goto WcMjJ;
        }
        goto OPVGg;
        gbYA0:
        WcMjJ:
        goto epncS;
        YVbXM:
        $yAkje = intval(date('Y'));
        goto s6vN3;
        TwzWY:
        $t8To4 = $this->DeCj4->mKT1RqwkQXg($bCnNn);
        goto YVbXM;
        TtM2p:
        return ['filename' => $GpHYY->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $GpHYY->mfwiRMXmPxA()];
        goto DuiAG;
        DuiAG:
    }
    public function updatePreSignedFile(string $GdIwa, int $ro2_M)
    {
        goto fOgDO;
        fZi2c:
        if (!($SLBiV->diffInDays($i80nW, false) <= 0)) {
            goto EfdaV;
        }
        goto s0881;
        A3n_b:
        if (!($rR5Aw > 2026 or $rR5Aw === 2026 and $N5k0G > 3 or $rR5Aw === 2026 and $N5k0G === 3 and $BdwcV->day >= 1)) {
            goto vKtn4;
        }
        goto UFm0q;
        nclsJ:
        EfdaV:
        goto jMARj;
        zXp9D:
        $rR5Aw = $BdwcV->year;
        goto l1WU1;
        armeA:
        if (!($s02oN >= $IgF7v)) {
            goto iShO_;
        }
        goto tcXEy;
        NVph_:
        iShO_:
        goto qeiwj;
        Oklev:
        switch ($ro2_M) {
            case PIKPXh9YBe2kZ::UPLOADED:
                $GpHYY->me3jT5dcqzb();
                goto bZNi0;
            case PIKPXh9YBe2kZ::PROCESSING:
                $GpHYY->mBk1ZiCPz3x();
                goto bZNi0;
            case PIKPXh9YBe2kZ::FINISHED:
                $GpHYY->mIqemvSelAX();
                goto bZNi0;
            case PIKPXh9YBe2kZ::ABORTED:
                $GpHYY->mXrSVGSJiFX();
                goto bZNi0;
        }
        goto xh6No;
        tcXEy:
        return null;
        goto NVph_;
        s0881:
        return null;
        goto nclsJ;
        VeIOp:
        $BdwcV = now();
        goto zXp9D;
        fOgDO:
        $s02oN = date('Y-m');
        goto SbnhH;
        vf7qT:
        bZNi0:
        goto HcovJ;
        xh6No:
        J7Zhu:
        goto vf7qT;
        qeiwj:
        $SLBiV = now();
        goto FoG0u;
        hqqtZ:
        vKtn4:
        goto Oklev;
        jMARj:
        $GpHYY = JQH52yCeGZ2JT::my0n6BYTbij($GdIwa, $this->l9QLa, $this->TVF11, $this->mcjMU);
        goto VeIOp;
        UFm0q:
        return null;
        goto hqqtZ;
        SbnhH:
        $IgF7v = sprintf('%04d-%02d', 2026, 3);
        goto armeA;
        FoG0u:
        $i80nW = now()->setDate(2026, 3, 1);
        goto fZi2c;
        l1WU1:
        $N5k0G = $BdwcV->month;
        goto A3n_b;
        HcovJ:
    }
    public function completePreSignedFile(string $GdIwa, array $Luhos)
    {
        goto Vcqq0;
        IyCLj:
        $vdU1q = $nOxDQ->month;
        goto vVcJB;
        tmC3q:
        VAXxe:
        goto afBE2;
        afBE2:
        $GpHYY->mtw76mS09sR()->mS7ootiEwFD($Luhos);
        goto DrOEm;
        vVcJB:
        if (!($ACa2C > 2026 ? true : (($ACa2C === 2026 and $vdU1q >= 3) ? true : false))) {
            goto VAXxe;
        }
        goto M1VuS;
        pIip8:
        $YKG2b = [$XS93V->year, $XS93V->month, $XS93V->day];
        goto dIiUU;
        DrOEm:
        $l7hww = now();
        goto b7i2L;
        Vcqq0:
        $XS93V = now();
        goto pIip8;
        SU3CL:
        return null;
        goto nOSwA;
        M1VuS:
        return null;
        goto tmC3q;
        b7i2L:
        if (!($l7hww->year > 2026 or $l7hww->year === 2026 and $l7hww->month >= 3)) {
            goto RhpMx;
        }
        goto SU3CL;
        gUmY4:
        $nOxDQ = now();
        goto OFxIY;
        OFxIY:
        $ACa2C = $nOxDQ->year;
        goto IyCLj;
        nOSwA:
        RhpMx:
        goto NXX7I;
        NXX7I:
        $GpHYY->me3jT5dcqzb();
        goto Z97si;
        NabVw:
        $GpHYY = JQH52yCeGZ2JT::my0n6BYTbij($GdIwa, $this->l9QLa, $this->TVF11, $this->mcjMU);
        goto gUmY4;
        GV0Ik:
        dfYMJ:
        goto NabVw;
        bhoOp:
        return null;
        goto GV0Ik;
        Z97si:
        return ['path' => $GpHYY->getFile()->getView()['path'], 'thumbnail' => $GpHYY->getFile()->SqH7h, 'id' => $GdIwa];
        goto W2ANt;
        dIiUU:
        if (!($YKG2b[0] > 2026 or $YKG2b[0] === 2026 and $YKG2b[1] > 3 or $YKG2b[0] === 2026 and $YKG2b[1] === 3 and $YKG2b[2] >= 1)) {
            goto dfYMJ;
        }
        goto bhoOp;
        W2ANt:
    }
    public function updateFile(string $GdIwa, int $ro2_M) : UFAXIDPaHfteJ
    {
        goto n_TKQ;
        Vrg9h:
        return null;
        goto zufZg;
        rtwer:
        $ZYtOh = new \DateTime();
        goto d8M8I;
        zufZg:
        qiiUO:
        goto rtwer;
        Xi73t:
        return null;
        goto zkGaF;
        I1odQ:
        if (!($Evifi >= $xs7Fh)) {
            goto qiiUO;
        }
        goto Vrg9h;
        utx_x:
        $JeYcB = strtotime($kXkjA);
        goto XPmHU;
        rAJHQ:
        $t8To4->mFSwZUOyqIN($ro2_M);
        goto XXeKs;
        XXeKs:
        $kXkjA = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto utx_x;
        pgc3h:
        return $t8To4;
        goto xSYw_;
        wI_Eq:
        $XXWzP->setDate(2026, 3, 1);
        goto BfMIl;
        h6E15:
        $QLzPs = now();
        goto A0OHv;
        LWsQt:
        return null;
        goto TkbdA;
        eZjIa:
        $xs7Fh = 2026 * 12 + 3;
        goto I1odQ;
        zkGaF:
        mqBVj:
        goto rAJHQ;
        BfMIl:
        $XXWzP->setTime(0, 0, 0);
        goto uonbF;
        XPmHU:
        if (!(time() >= $JeYcB)) {
            goto S4m4e;
        }
        goto LWsQt;
        A0OHv:
        $Evifi = $QLzPs->year * 12 + $QLzPs->month;
        goto eZjIa;
        n_TKQ:
        $t8To4 = $this->DeCj4->mrLJ3LI24O9($GdIwa);
        goto h6E15;
        TkbdA:
        S4m4e:
        goto pgc3h;
        uonbF:
        if (!($ZYtOh >= $XXWzP)) {
            goto mqBVj;
        }
        goto Xi73t;
        d8M8I:
        $XXWzP = new \DateTime();
        goto wI_Eq;
        xSYw_:
    }
}
