<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Core\KO2pC9qLVd4GD;
use Jfs\Uploader\Core\UvoAmV0bL7M3i;
use Jfs\Uploader\Enum\QUh2VVA2TE5xx;
use Jfs\Uploader\Exception\DTlKOLT8tkTnv;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Jfs\Uploader\Exception\Eh512bCz7e47V;
final class MUA7XYPYpaXPj implements UploadServiceInterface
{
    private $TKfwZ;
    private $aB4Qh;
    private $qFnIc;
    private $H67LP;
    public function __construct(AicOtR7ItsXZc $ySe22, Filesystem $Q0D24, Filesystem $A8Sfn, string $PmjSk)
    {
        goto xV3Bg;
        yVfVF:
        $this->qFnIc = $A8Sfn;
        goto Q_ncd;
        Q_ncd:
        $this->H67LP = $PmjSk;
        goto BYunD;
        byJfT:
        $this->aB4Qh = $Q0D24;
        goto yVfVF;
        xV3Bg:
        $this->TKfwZ = $ySe22;
        goto byJfT;
        BYunD:
    }
    public function storeSingleFile(SingleUploadInterface $t7xSE) : array
    {
        goto Y0HPW;
        qzcg3:
        $XkdbN = $this->qFnIc->putFileAs(dirname($xdi9a->getLocation()), $t7xSE->getFile(), $xdi9a->getFilename() . '.' . $xdi9a->getExtension(), ['visibility' => 'public']);
        goto mgx1S;
        p9ZcH:
        return $xdi9a->getView();
        goto UEMra;
        TqAho:
        $xdi9a->meQCGHEeK80(QUh2VVA2TE5xx::UPLOADED);
        goto Tx15a;
        i2mqo:
        t6j0I:
        goto TqAho;
        mgx1S:
        if (false !== $XkdbN && $xdi9a instanceof QBvcnDryrzxsL) {
            goto t6j0I;
        }
        goto PoDVG;
        Tx15a:
        B1g4N:
        goto p9ZcH;
        PoDVG:
        throw new \LogicException('File upload failed, check permissions');
        goto hBTkW;
        Y0HPW:
        $xdi9a = $this->TKfwZ->mcI8ojv1n1h($t7xSE);
        goto qzcg3;
        hBTkW:
        goto B1g4N;
        goto i2mqo;
        UEMra:
    }
    public function storePreSignedFile(array $S5poz)
    {
        goto Oor3O;
        s5Sl3:
        $au4Kn->m2F1EPzYY9n();
        goto FCEe5;
        IgSwD:
        $au4Kn->mg7fMGnSg3l($S5poz['mime'], $S5poz['file_size'], $S5poz['chunk_size'], $S5poz['checksums'], $S5poz['user_id'], $S5poz['driver']);
        goto s5Sl3;
        FCEe5:
        return ['filename' => $au4Kn->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $au4Kn->mH1aFytVAxg()];
        goto bEKJc;
        hKROz:
        $au4Kn = UvoAmV0bL7M3i::mQBbDXqCtS1($xdi9a, $this->aB4Qh, $this->qFnIc, $this->H67LP, true);
        goto IgSwD;
        Oor3O:
        $xdi9a = $this->TKfwZ->mcI8ojv1n1h($S5poz);
        goto hKROz;
        bEKJc:
    }
    public function updatePreSignedFile(string $wsssR, int $LWTPO)
    {
        goto RJ85_;
        I8Imt:
        NTzCE:
        goto Hbcu4;
        Z9vOD:
        xQD9H:
        goto I8Imt;
        oxrDn:
        switch ($LWTPO) {
            case QUh2VVA2TE5xx::UPLOADED:
                $au4Kn->mo8qIQpHjyT();
                goto NTzCE;
            case QUh2VVA2TE5xx::PROCESSING:
                $au4Kn->mRtrYr13h28();
                goto NTzCE;
            case QUh2VVA2TE5xx::FINISHED:
                $au4Kn->mphReRfpATd();
                goto NTzCE;
            case QUh2VVA2TE5xx::ABORTED:
                $au4Kn->mOkx2I7mq0D();
                goto NTzCE;
        }
        goto Z9vOD;
        RJ85_:
        $au4Kn = UvoAmV0bL7M3i::mNrAp4L40uP($wsssR, $this->aB4Qh, $this->qFnIc, $this->H67LP);
        goto oxrDn;
        Hbcu4:
    }
    public function completePreSignedFile(string $wsssR, array $sGu64)
    {
        goto KZuk4;
        zeSss:
        $au4Kn->mo8qIQpHjyT();
        goto LYYjk;
        LYYjk:
        return ['path' => $au4Kn->getFile()->getView()['path'], 'thumbnail' => $au4Kn->getFile()->q4Ui5, 'id' => $wsssR];
        goto Jdw2I;
        AvxxL:
        $au4Kn->mLK5jSa9bhL()->mVK4b8O7i66($sGu64);
        goto zeSss;
        KZuk4:
        $au4Kn = UvoAmV0bL7M3i::mNrAp4L40uP($wsssR, $this->aB4Qh, $this->qFnIc, $this->H67LP);
        goto AvxxL;
        Jdw2I:
    }
    public function updateFile(string $wsssR, int $LWTPO) : KO2pC9qLVd4GD
    {
        goto mFbnU;
        mFbnU:
        $xdi9a = $this->TKfwZ->mqGqxIhP6SJ($wsssR);
        goto GyAAP;
        hRjSc:
        return $xdi9a;
        goto FtQFF;
        GyAAP:
        $xdi9a->meQCGHEeK80($LWTPO);
        goto hRjSc;
        FtQFF:
    }
}
