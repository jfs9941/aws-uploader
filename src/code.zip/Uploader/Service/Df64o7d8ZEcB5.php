<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Core\WabYRJvOEOksh;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
final class Df64o7d8ZEcB5 implements BEzZsfn3kKkr3
{
    private $NjzMa;
    private $r3o_s;
    public $EA8jm;
    private $ywxGs;
    private $Ba3BM;
    private $P2FvH;
    public function __construct($XY6eG, $WcbpG, $OWAgq, $qluH3, $qupk9, $j8mv9)
    {
        goto VfxvM;
        JbUvv:
        $this->NjzMa = $XY6eG;
        goto tUBvS;
        tUBvS:
        $this->r3o_s = $WcbpG;
        goto GCLt1;
        GCLt1:
        $this->EA8jm = $OWAgq;
        goto EBA08;
        VfxvM:
        $this->P2FvH = $j8mv9;
        goto JbUvv;
        KJNcQ:
        $this->Ba3BM = $qupk9;
        goto PAtAe;
        EBA08:
        $this->ywxGs = $qluH3;
        goto KJNcQ;
        PAtAe:
    }
    public function resolvePath($xUtpC, $hCnVR = N0ISad2bKF2Yp::S3) : string
    {
        goto wz3eo;
        jbwZP:
        jYrUT:
        goto EtIvx;
        QhPSJ:
        return config('upload.home') . '/' . $xUtpC;
        goto MId8e;
        z6A3Q:
        $xUtpC = $xUtpC->getAttribute('filename');
        goto HFg5k;
        wz3eo:
        if (!$xUtpC instanceof CZj9PTf9Cv9Eq) {
            goto oyrwZ;
        }
        goto z6A3Q;
        HFg5k:
        oyrwZ:
        goto UqUYV;
        ku_R_:
        return $this->m5dEOGUtvqw($xUtpC);
        goto jbwZP;
        Aj0NV:
        return trim($this->r3o_s, '/') . '/' . $xUtpC;
        goto js19B;
        hbUmE:
        return trim($this->EA8jm, '/') . '/' . $xUtpC;
        goto h3Wg2;
        UqUYV:
        if (!($hCnVR === N0ISad2bKF2Yp::LOCAL)) {
            goto zy4WT;
        }
        goto QhPSJ;
        EOO1S:
        if (!(!empty($this->ywxGs) && !empty($this->Ba3BM))) {
            goto jYrUT;
        }
        goto ku_R_;
        h3Wg2:
        dbtzy:
        goto Aj0NV;
        MId8e:
        zy4WT:
        goto EOO1S;
        EtIvx:
        if (!$this->NjzMa) {
            goto dbtzy;
        }
        goto hbUmE;
        js19B:
    }
    public function resolveThumbnail(CZj9PTf9Cv9Eq $xUtpC) : string
    {
        goto UfVHA;
        zmS5M:
        $JuU34 = XbYF8aa0XyGnI::find($xUtpC->getAttribute('thumbnail_id'));
        goto zRFLs;
        zRFLs:
        if (!$JuU34) {
            goto O33G6;
        }
        goto C0HR3;
        BkzKK:
        if (!$xUtpC instanceof XbYF8aa0XyGnI) {
            goto IU6IG;
        }
        goto Lj7AA;
        jeJUV:
        v7Sfn:
        goto BkzKK;
        t3GU8:
        if (!$xUtpC instanceof WabYRJvOEOksh) {
            goto YTGQ9;
        }
        goto aUGqU;
        UfVHA:
        $E2RLT = $xUtpC->getAttribute('thumbnail');
        goto xjwn2;
        xjwn2:
        if (!$E2RLT) {
            goto ST0pC;
        }
        goto YGw0g;
        e0U1x:
        YTGQ9:
        goto sqh7y;
        Lj7AA:
        return $this->resolvePath($xUtpC, $xUtpC->getAttribute('driver'));
        goto IXtEr;
        aUGqU:
        return asset('/img/pdf-preview.svg');
        goto e0U1x;
        YGw0g:
        return $this->url($E2RLT, $xUtpC->getAttribute('driver'));
        goto Vj_0t;
        u7FoW:
        if (!$xUtpC->getAttribute('thumbnail_id')) {
            goto v7Sfn;
        }
        goto zmS5M;
        sqh7y:
        return '';
        goto QWZsU;
        IXtEr:
        IU6IG:
        goto t3GU8;
        ACX_9:
        O33G6:
        goto jeJUV;
        C0HR3:
        return $this->resolvePath($JuU34, $JuU34->getAttribute('driver'));
        goto ACX_9;
        Vj_0t:
        ST0pC:
        goto u7FoW;
        QWZsU:
    }
    private function url($Sblyk, $hCnVR)
    {
        goto ynEqm;
        T3EQT:
        GJ0Bz:
        goto dob5P;
        MH0eS:
        return config('upload.home') . '/' . $Sblyk;
        goto T3EQT;
        dob5P:
        return $this->resolvePath($Sblyk);
        goto QHEsl;
        ynEqm:
        if (!($hCnVR == N0ISad2bKF2Yp::LOCAL)) {
            goto GJ0Bz;
        }
        goto MH0eS;
        QHEsl:
    }
    private function m5dEOGUtvqw($Sblyk)
    {
        goto nkdJY;
        yuGCe:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto z021D;
        j5dVd:
        if (!(strpos($Sblyk, 'm3u8') !== false)) {
            goto e4pgY;
        }
        goto yuGCe;
        mmAPV:
        return $LWiix->getSignedUrl($this->EA8jm . '/' . $Sblyk, $wNDHD);
        goto vcyAr;
        bV81i:
        ywOvA:
        goto j5dVd;
        Vcbwi:
        $LWiix = new UrlSigner($this->ywxGs, $this->P2FvH->path($this->Ba3BM));
        goto mmAPV;
        ojNfY:
        $wNDHD = now()->addMinutes(60)->timestamp;
        goto Vcbwi;
        nkdJY:
        if (!(strpos($Sblyk, 'https://') === 0)) {
            goto ywOvA;
        }
        goto RFhbb;
        RFhbb:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto bV81i;
        z021D:
        e4pgY:
        goto ojNfY;
        vcyAr:
    }
    public function resolvePathForHlsVideo(CUaMUcjkFHEwK $zef_R, $wwEy0 = false) : string
    {
        goto MeE7O;
        njNBR:
        return $this->EA8jm . '/' . $zef_R->getAttribute('hls_path');
        goto iTb4c;
        fSDUF:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto qxZZy;
        qxZZy:
        X5Vd0:
        goto njNBR;
        MeE7O:
        if ($zef_R->getAttribute('hls_path')) {
            goto X5Vd0;
        }
        goto fSDUF;
        iTb4c:
    }
    public function resolvePathForHlsVideos()
    {
        goto S52vy;
        e8kXx:
        $Ib7eO = $d4evf->getSignedCookie(['key_pair_id' => $this->ywxGs, 'private_key' => $this->P2FvH->path($this->Ba3BM), 'policy' => $uWws6]);
        goto ZzxuE;
        qPqRY:
        $d4evf = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto e8kXx;
        S52vy:
        $wNDHD = now()->addDays(3)->timestamp;
        goto b_JeV;
        b_JeV:
        $qDsN7 = $this->EA8jm . '/v2/hls/';
        goto BzYXO;
        BzYXO:
        $uWws6 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $qDsN7), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $wNDHD]]]]]);
        goto qPqRY;
        ZzxuE:
        return [$Ib7eO, $wNDHD];
        goto IlWYL;
        IlWYL:
    }
}
