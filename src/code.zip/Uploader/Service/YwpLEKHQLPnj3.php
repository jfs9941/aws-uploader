<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Intervention\DsyQbNiy8VgJG\Drivers\Imagick\Driver;
use Intervention\DsyQbNiy8VgJG\ImageManager;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Core\WmSe4qJ68rckH;
use Jfs\Uploader\Core\Eyra2OnsK5qBk;
use Jfs\Uploader\Enum\SwAwanZG36Yx6;
use Jfs\Uploader\Exception\BI7zT0hnXVI9h;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Jfs\Uploader\Exception\HAf99Vtg3teX9;
final class YwpLEKHQLPnj3 implements UploadServiceInterface
{
    private $usddO;
    private $Lrwlv;
    private $OjeW5;
    private $K88GF;
    public function __construct(IsJEOSgV8mPOx $r24cR, Filesystem $AhP23, Filesystem $A6wTz, string $rOGmu)
    {
        goto NAaZk;
        ZPMKV:
        $this->Lrwlv = $AhP23;
        goto rzjhF;
        NAaZk:
        $this->usddO = $r24cR;
        goto ZPMKV;
        rzjhF:
        $this->OjeW5 = $A6wTz;
        goto RGyR3;
        RGyR3:
        $this->K88GF = $rOGmu;
        goto GZDik;
        GZDik:
    }
    public function storeSingleFile(SingleUploadInterface $wjtUT) : array
    {
        goto EI3QM;
        LAdBa:
        goto pSvVD;
        goto BGcfp;
        hVFU2:
        return $rQ18B->getView();
        goto tMvXz;
        gGSPQ:
        $J9IgU = $this->OjeW5->putFileAs(dirname($rQ18B->getLocation()), $wjtUT->getFile(), $rQ18B->getFilename() . '.' . $rQ18B->getExtension(), ['visibility' => 'public']);
        goto CB7wz;
        BGcfp:
        MLajJ:
        goto eW063;
        FD9Vv:
        pSvVD:
        goto hVFU2;
        q4AnQ:
        throw new \LogicException('File upload failed, check permissions');
        goto LAdBa;
        EI3QM:
        $rQ18B = $this->usddO->mN7eQARIGto($wjtUT);
        goto gGSPQ;
        CB7wz:
        if (false !== $J9IgU && $rQ18B instanceof CxLspzxS91nUL) {
            goto MLajJ;
        }
        goto q4AnQ;
        eW063:
        $rQ18B->mZecThKyfk1(SwAwanZG36Yx6::UPLOADED);
        goto FD9Vv;
        tMvXz:
    }
    public function storePreSignedFile(array $BJHPA)
    {
        goto afoOg;
        afoOg:
        $rQ18B = $this->usddO->mN7eQARIGto($BJHPA);
        goto SGepY;
        SGepY:
        $Ry7nX = Eyra2OnsK5qBk::mdv2fYQaPU1($rQ18B, $this->Lrwlv, $this->OjeW5, $this->K88GF, true);
        goto k_1PW;
        k_1PW:
        $Ry7nX->mpyVFiyEScS($BJHPA['mime'], $BJHPA['file_size'], $BJHPA['chunk_size'], $BJHPA['checksums'], $BJHPA['user_id'], $BJHPA['driver']);
        goto fgJZs;
        fgJZs:
        $Ry7nX->mGDIq8tG9F4();
        goto r7mXR;
        r7mXR:
        return ['filename' => $Ry7nX->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $Ry7nX->mGK46yiocdc()];
        goto onU90;
        onU90:
    }
    public function updatePreSignedFile(string $Ru7zy, int $lqL6o)
    {
        goto KfNjG;
        r0VGs:
        AckuI:
        goto Frklp;
        JS1yA:
        switch ($lqL6o) {
            case SwAwanZG36Yx6::UPLOADED:
                $Ry7nX->miGXX9YY39t();
                goto UhkVQ;
            case SwAwanZG36Yx6::PROCESSING:
                $Ry7nX->m9PSw2qxohj();
                goto UhkVQ;
            case SwAwanZG36Yx6::FINISHED:
                $Ry7nX->mcDH5mwYJpF();
                goto UhkVQ;
            case SwAwanZG36Yx6::ABORTED:
                $Ry7nX->m4lSEjYc3Qj();
                goto UhkVQ;
        }
        goto r0VGs;
        KfNjG:
        $Ry7nX = Eyra2OnsK5qBk::meMp6HqhH3z($Ru7zy, $this->Lrwlv, $this->OjeW5, $this->K88GF);
        goto JS1yA;
        Frklp:
        UhkVQ:
        goto bgS4e;
        bgS4e:
    }
    public function completePreSignedFile(string $Ru7zy, array $iHezl)
    {
        goto tg5Qh;
        V80m4:
        $Ry7nX->mROzB90pF6O()->miFvLtB9QkN($iHezl);
        goto BW6h_;
        dpSeq:
        return ['path' => $Ry7nX->getFile()->getView()['path'], 'thumbnail' => $Ry7nX->getFile()->xC5r_, 'id' => $Ru7zy];
        goto C3wJN;
        tg5Qh:
        $Ry7nX = Eyra2OnsK5qBk::meMp6HqhH3z($Ru7zy, $this->Lrwlv, $this->OjeW5, $this->K88GF);
        goto V80m4;
        BW6h_:
        $Ry7nX->miGXX9YY39t();
        goto dpSeq;
        C3wJN:
    }
    public function updateFile(string $Ru7zy, int $lqL6o) : WmSe4qJ68rckH
    {
        goto w8nPw;
        oqyIj:
        return $rQ18B;
        goto hO08m;
        Dr7No:
        $rQ18B->mZecThKyfk1($lqL6o);
        goto oqyIj;
        w8nPw:
        $rQ18B = $this->usddO->mzL9TaONfCV($Ru7zy);
        goto Dr7No;
        hO08m:
    }
}
