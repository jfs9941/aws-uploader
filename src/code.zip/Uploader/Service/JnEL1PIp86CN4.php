<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\IzCykbeCOYPNB;
use Jfs\Uploader\Core\BTuo2UPlpfSoS;
use Jfs\Uploader\Core\T1237kNnrvH7d;
use Jfs\Uploader\Enum\EXecNg2hg7kwl;
use Jfs\Uploader\Exception\JTzKeriqU61FK;
use Jfs\Uploader\Exception\B9AWimnd5WRl4;
use Jfs\Uploader\Exception\Pwrqemn2dhCsC;
use Jfs\Uploader\Service\GxQCvfot4aISP;
use Illuminate\Contracts\Filesystem\Filesystem;
final class JnEL1PIp86CN4 implements UploadServiceInterface
{
    private $tznqY;
    private $IaFSl;
    private $QO2Ul;
    private $b8F1i;
    public function __construct(GxQCvfot4aISP $sKVdW, Filesystem $B27Pk, Filesystem $YzAw4, string $xR3jE)
    {
        goto yX6Rm;
        hactv:
        $this->QO2Ul = $YzAw4;
        goto NkoJ4;
        yX6Rm:
        $this->tznqY = $sKVdW;
        goto P3n5z;
        P3n5z:
        $this->IaFSl = $B27Pk;
        goto hactv;
        NkoJ4:
        $this->b8F1i = $xR3jE;
        goto LJcJ5;
        LJcJ5:
    }
    public function storeSingleFile(SingleUploadInterface $k99vy) : array
    {
        goto hJejM;
        eKji0:
        goto GWZAW;
        goto LVhR4;
        D4KC9:
        if (false !== $lxbX3 && $FJFJj instanceof IzCykbeCOYPNB) {
            goto hgdzD;
        }
        goto ELCQg;
        LVhR4:
        hgdzD:
        goto cNat9;
        PMZHG:
        return $FJFJj->getView();
        goto JfgYp;
        qvsy_:
        GWZAW:
        goto PMZHG;
        cNat9:
        $FJFJj->m7ddHwazacD(EXecNg2hg7kwl::UPLOADED);
        goto qvsy_;
        F7UQb:
        $lxbX3 = $this->QO2Ul->putFileAs(dirname($FJFJj->getLocation()), $k99vy->getFile(), $FJFJj->getFilename() . '.' . $FJFJj->getExtension(), ['visibility' => 'public']);
        goto D4KC9;
        ELCQg:
        throw new \LogicException('File upload failed, check permissions');
        goto eKji0;
        hJejM:
        $FJFJj = $this->tznqY->mYrzKv4DgHd($k99vy);
        goto F7UQb;
        JfgYp:
    }
    public function storePreSignedFile(array $bG7NT)
    {
        goto aZCdb;
        zNbty:
        $IXO6X->mijOp1YUOWt($bG7NT['mime'], $bG7NT['file_size'], $bG7NT['chunk_size'], $bG7NT['checksums'], $bG7NT['user_id'], $bG7NT['driver']);
        goto elZXz;
        aZCdb:
        $FJFJj = $this->tznqY->mYrzKv4DgHd($bG7NT);
        goto pdezU;
        pdezU:
        $IXO6X = T1237kNnrvH7d::mYFzhFbMdlE($FJFJj, $this->IaFSl, $this->QO2Ul, $this->b8F1i, true);
        goto zNbty;
        ubRrU:
        return ['filename' => $IXO6X->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $IXO6X->mNQAK4zjaHM()];
        goto a2h4x;
        elZXz:
        $IXO6X->mc2MBS4iICj();
        goto ubRrU;
        a2h4x:
    }
    public function updatePreSignedFile(string $LMGY1, int $aMRoj)
    {
        goto Vq_Gl;
        xr1b9:
        switch ($aMRoj) {
            case EXecNg2hg7kwl::UPLOADED:
                $IXO6X->mGAA4GybF91();
                goto C2jOq;
            case EXecNg2hg7kwl::PROCESSING:
                $IXO6X->mMXPPeKoHyt();
                goto C2jOq;
            case EXecNg2hg7kwl::FINISHED:
                $IXO6X->mOYaQi1Iv9G();
                goto C2jOq;
            case EXecNg2hg7kwl::ABORTED:
                $IXO6X->mPVzXBizobT();
                goto C2jOq;
        }
        goto GMD4u;
        GMD4u:
        XTjMi:
        goto PSey9;
        Vq_Gl:
        $IXO6X = T1237kNnrvH7d::mfD5HTn0hZZ($LMGY1, $this->IaFSl, $this->QO2Ul, $this->b8F1i);
        goto xr1b9;
        PSey9:
        C2jOq:
        goto hZdTv;
        hZdTv:
    }
    public function completePreSignedFile(string $LMGY1, array $YXgxQ)
    {
        goto FzkYR;
        FzkYR:
        $IXO6X = T1237kNnrvH7d::mfD5HTn0hZZ($LMGY1, $this->IaFSl, $this->QO2Ul, $this->b8F1i);
        goto SbKL3;
        SbKL3:
        $IXO6X->m20XUNl7Aaq()->m8MM5cUIu7J($YXgxQ);
        goto XNdCk;
        XNdCk:
        $IXO6X->mGAA4GybF91();
        goto v_9Mb;
        v_9Mb:
        return ['path' => $IXO6X->getFile()->getView()['path'], 'thumbnail' => $IXO6X->getFile()->ywiLP, 'id' => $LMGY1];
        goto hO_ua;
        hO_ua:
    }
    public function updateFile(string $LMGY1, int $aMRoj) : BTuo2UPlpfSoS
    {
        goto w6Pos;
        TtZr0:
        return $FJFJj;
        goto W6eWl;
        w6Pos:
        $FJFJj = $this->tznqY->mby5fO9zINL($LMGY1);
        goto gnkdp;
        gnkdp:
        $FJFJj->m7ddHwazacD($aMRoj);
        goto TtZr0;
        W6eWl:
    }
}
