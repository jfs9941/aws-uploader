<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\QBvcnDryrzxsL;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Core\Observer\FXS39IwxBart4;
use Jfs\Uploader\Core\Observer\RCEd2a5p9PuRm;
use Jfs\Uploader\Core\RkSRDDbIFKZE9;
use Jfs\Uploader\Core\HGG0krL7DaFQk;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
use Jfs\Uploader\Exception\LBGqEnYC0ItIS;
use Jfs\Uploader\Exception\Eh512bCz7e47V;
use Jfs\Uploader\Service\FileResolver\FgJbra0UeoOsX;
use Ramsey\Uuid\Uuid;
final class AicOtR7ItsXZc
{
    private $nZPqF;
    private $aB4Qh;
    private $IRlXr;
    public function __construct($Wy93k, $Q0D24, $JGvdR)
    {
        goto Ww5xW;
        Ww5xW:
        $this->nZPqF = $Wy93k;
        goto X3VOY;
        JIVOW:
        $this->IRlXr = $JGvdR;
        goto pn5RF;
        X3VOY:
        $this->aB4Qh = $Q0D24;
        goto JIVOW;
        pn5RF:
    }
    public function mcI8ojv1n1h($mo0dd)
    {
        goto k074J;
        y98s3:
        return $this->m3Qwl7BMnqD($mo0dd['file_extension'], 's3' === $mo0dd['driver'] ? R278OrMF6HCNB::S3 : R278OrMF6HCNB::LOCAL);
        goto X6NHl;
        apKW2:
        return $this->m3Qwl7BMnqD($H3_9m->extension(), R278OrMF6HCNB::S3, null, $mo0dd->options());
        goto rKkGE;
        k074J:
        if (!$mo0dd instanceof SingleUploadInterface) {
            goto yyyR_;
        }
        goto mhgG1;
        rKkGE:
        yyyR_:
        goto y98s3;
        mhgG1:
        $H3_9m = $mo0dd->getFile();
        goto apKW2;
        X6NHl:
    }
    public function mqGqxIhP6SJ(string $R7IrL)
    {
        goto U9QpJ;
        qpm90:
        return $xdi9a;
        goto Flr2z;
        sLMGX:
        $xdi9a = $this->m3Qwl7BMnqD($js0c_->getAttribute('type'), $js0c_->getAttribute('driver'), $js0c_->getAttribute('id'));
        goto kCX3r;
        U9QpJ:
        $js0c_ = config('upload.attachment_model')::findOrFail($R7IrL);
        goto sLMGX;
        SGZmP:
        $xdi9a->setRawAttributes($js0c_->getAttributes());
        goto qpm90;
        kCX3r:
        $xdi9a->exists = true;
        goto SGZmP;
        Flr2z:
    }
    public function mxe6CYqgnS9(string $OSB1a) : QBvcnDryrzxsL
    {
        goto z2B3_;
        z2B3_:
        $n1lXi = $this->aB4Qh->get($OSB1a);
        goto Cdl0e;
        Ha4IG:
        Cr0BB:
        goto qVpJD;
        Cdl0e:
        if ($n1lXi) {
            goto Cr0BB;
        }
        goto pvakr;
        t1ZG4:
        return $this->m3Qwl7BMnqD($rES43->domka, $rES43->mSio1r6bavY(), $rES43->filename);
        goto JRO0r;
        uUygg:
        $rES43 = HGG0krL7DaFQk::mTqakSdzYAy($YKW91);
        goto t1ZG4;
        pvakr:
        $n1lXi = $this->IRlXr->get($OSB1a);
        goto Ha4IG;
        JRO0r:
        U1QqV:
        goto ZhdCc;
        AnMav:
        if (!$YKW91) {
            goto U1QqV;
        }
        goto uUygg;
        qVpJD:
        $YKW91 = json_decode($n1lXi, true);
        goto AnMav;
        ZhdCc:
        throw new LBGqEnYC0ItIS('metadata file not found');
        goto qPGO1;
        qPGO1:
    }
    private function m3Qwl7BMnqD(string $Moe0A, $QJqS9, ?string $R7IrL = null, array $GwkoE = [])
    {
        goto v98KD;
        GWaUa:
        throw new Eh512bCz7e47V("not support file type {$Moe0A}");
        goto IWN22;
        NQ3jB:
        $xd9AP->m3FXSxRxwBi(new FXS39IwxBart4($xd9AP));
        goto h1gZ2;
        MitS0:
        REsFB:
        goto C3p3M;
        EAAf8:
        $xd9AP = $xd9AP->mRfrN2KO4NJ($QJqS9);
        goto NQ3jB;
        j1ZeK:
        NXfm_:
        goto GWaUa;
        KNT5P:
        foreach ($this->nZPqF as $Yfl_o) {
            goto gnkM6;
            lOTso:
            nbglm:
            goto fgxSo;
            gnkM6:
            if (!$Yfl_o->m8bW1LjLFz2($xd9AP)) {
                goto GeREM;
            }
            goto P2lJ3;
            P2lJ3:
            return $xd9AP->initLocation($Yfl_o->m7pgB8X0Csa($xd9AP));
            goto woQ0H;
            woQ0H:
            GeREM:
            goto lOTso;
            fgxSo:
        }
        goto j1ZeK;
        h1gZ2:
        $xd9AP->m3FXSxRxwBi(new RCEd2a5p9PuRm($xd9AP, $this->IRlXr, $GwkoE));
        goto KNT5P;
        SQKCY:
        switch ($Moe0A) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $xd9AP = OcbNsXl9lpteB::createFromScratch($R7IrL, $Moe0A);
                goto N4XfD;
            case 'mp4':
            case 'mov':
                $xd9AP = B6s4AA1exjQ2T::createFromScratch($R7IrL, $Moe0A);
                goto N4XfD;
            case 'pdf':
                $xd9AP = RkSRDDbIFKZE9::createFromScratch($R7IrL, $Moe0A);
                goto N4XfD;
            default:
                throw new Eh512bCz7e47V("not support file type {$Moe0A}");
        }
        goto MitS0;
        v98KD:
        $R7IrL = $R7IrL ?? Uuid::uuid4()->getHex()->toString();
        goto SQKCY;
        C3p3M:
        N4XfD:
        goto EAAf8;
        IWN22:
    }
}
