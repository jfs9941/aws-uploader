<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\SOB6nK7CGVegh;
use Jfs\Uploader\Core\QLOMBcv8tw1Qd;
use Jfs\Uploader\Core\NfmgXUF97Fg3H;
use Jfs\Uploader\Enum\Xy3InMky6jKYf;
use Jfs\Uploader\Exception\BC4l4MMxB4wtt;
use Jfs\Uploader\Exception\Pl4WlsTHZq9V7;
use Jfs\Uploader\Exception\KQCoJb7DnfcxZ;
use Jfs\Uploader\Service\EJdnYZtMjtUUp;
use Illuminate\Contracts\Filesystem\Filesystem;
final class GhJcjgLYvxYxE implements UploadServiceInterface
{
    private $XKd15;
    private $GUhIK;
    private $bBnq9;
    private $TWPgG;
    public function __construct(EJdnYZtMjtUUp $X2wOD, Filesystem $kGo1c, Filesystem $k6y5k, string $T0Gu0)
    {
        goto TlpG6;
        o0UfX:
        $this->TWPgG = $T0Gu0;
        goto y9LGZ;
        SjIbh:
        $this->GUhIK = $kGo1c;
        goto bmI5M;
        bmI5M:
        $this->bBnq9 = $k6y5k;
        goto o0UfX;
        TlpG6:
        $this->XKd15 = $X2wOD;
        goto SjIbh;
        y9LGZ:
    }
    public function storeSingleFile(SingleUploadInterface $K_Sgy) : array
    {
        goto AbAgJ;
        qy418:
        if (false !== $dSgog && $DejZC instanceof SOB6nK7CGVegh) {
            goto eHU4B;
        }
        goto gG7R2;
        gG7R2:
        throw new \LogicException('File upload failed, check permissions');
        goto T6MS6;
        T6MS6:
        goto bi9mQ;
        goto BHbOS;
        AbAgJ:
        $DejZC = $this->XKd15->mGiOPQ9gXel($K_Sgy);
        goto JKf9y;
        BHbOS:
        eHU4B:
        goto aoBgR;
        N9EDL:
        return $DejZC->getView();
        goto Jc4g7;
        JKf9y:
        $dSgog = $this->bBnq9->putFileAs(dirname($DejZC->getLocation()), $K_Sgy->getFile(), $DejZC->getFilename() . '.' . $DejZC->getExtension(), ['visibility' => 'public']);
        goto qy418;
        aoBgR:
        $DejZC->mAPPeV3mHXi(Xy3InMky6jKYf::UPLOADED);
        goto NGbMj;
        NGbMj:
        bi9mQ:
        goto N9EDL;
        Jc4g7:
    }
    public function storePreSignedFile(array $h5Nu6)
    {
        goto UqCjh;
        NIGu4:
        $TtzPI->mFzFxyOyRhP();
        goto ay7lq;
        ay7lq:
        return ['filename' => $TtzPI->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $TtzPI->musHtpPk4T9()];
        goto K0Jxo;
        G1IC2:
        $TtzPI->myYWHwbPX4L($h5Nu6['mime'], $h5Nu6['file_size'], $h5Nu6['chunk_size'], $h5Nu6['checksums'], $h5Nu6['user_id'], $h5Nu6['driver']);
        goto NIGu4;
        UqCjh:
        $DejZC = $this->XKd15->mGiOPQ9gXel($h5Nu6);
        goto htia_;
        htia_:
        $TtzPI = NfmgXUF97Fg3H::mkOth94gJm0($DejZC, $this->GUhIK, $this->bBnq9, $this->TWPgG, true);
        goto G1IC2;
        K0Jxo:
    }
    public function updatePreSignedFile(string $hQAfC, int $swoUd)
    {
        goto Tx3nY;
        Tx3nY:
        $TtzPI = NfmgXUF97Fg3H::m2baxpBz3iI($hQAfC, $this->GUhIK, $this->bBnq9, $this->TWPgG);
        goto xjVo1;
        rkS6H:
        LxNR7:
        goto mm6Rx;
        xjVo1:
        switch ($swoUd) {
            case Xy3InMky6jKYf::UPLOADED:
                $TtzPI->mSSLoFg4dyG();
                goto ZT4Pt;
            case Xy3InMky6jKYf::PROCESSING:
                $TtzPI->m1XtLIZYW3f();
                goto ZT4Pt;
            case Xy3InMky6jKYf::FINISHED:
                $TtzPI->mj9BDEGvAB1();
                goto ZT4Pt;
            case Xy3InMky6jKYf::ABORTED:
                $TtzPI->maBosN2qJq3();
                goto ZT4Pt;
        }
        goto rkS6H;
        mm6Rx:
        ZT4Pt:
        goto WyOLH;
        WyOLH:
    }
    public function completePreSignedFile(string $hQAfC, array $l5I6a)
    {
        goto lPX8t;
        WTITT:
        $TtzPI->mSSLoFg4dyG();
        goto KM321;
        Dabgq:
        $TtzPI->mu6Z5XKe7fC()->mOtcCAQ9c6f($l5I6a);
        goto WTITT;
        KM321:
        return ['path' => $TtzPI->getFile()->getView()['path'], 'thumbnail' => $TtzPI->getFile()->oMOXS, 'id' => $hQAfC];
        goto jL6q5;
        lPX8t:
        $TtzPI = NfmgXUF97Fg3H::m2baxpBz3iI($hQAfC, $this->GUhIK, $this->bBnq9, $this->TWPgG);
        goto Dabgq;
        jL6q5:
    }
    public function updateFile(string $hQAfC, int $swoUd) : QLOMBcv8tw1Qd
    {
        goto UeCVf;
        s6vFk:
        return $DejZC;
        goto g9Pn5;
        UeCVf:
        $DejZC = $this->XKd15->mEO5B1SrbJB($hQAfC);
        goto mS_pa;
        mS_pa:
        $DejZC->mAPPeV3mHXi($swoUd);
        goto s6vFk;
        g9Pn5:
    }
}
