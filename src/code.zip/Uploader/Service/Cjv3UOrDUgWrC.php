<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
final class Cjv3UOrDUgWrC
{
    private $q3TFM;
    private $xZqfX;
    private $x0wV5;
    public function __construct(string $ahaqc, string $ZUiOi, Filesystem $mHTSY)
    {
        goto dFdJe;
        EdlY8:
        $this->x0wV5 = $mHTSY;
        goto SN0T8;
        mf78f:
        $this->xZqfX = $ZUiOi;
        goto EdlY8;
        dFdJe:
        $this->q3TFM = $ahaqc;
        goto mf78f;
        SN0T8:
    }
    public function mU60j122Kur(LfWCTOqty2Slr $FjxfJ) : string
    {
        goto oiGos;
        oiGos:
        if (!(NYPGraEb3Ennl::S3 == $FjxfJ->getAttribute('driver'))) {
            goto dzUvV;
        }
        goto tQE0S;
        tQE0S:
        return 's3://' . $this->q3TFM . '/' . $FjxfJ->getAttribute('filename');
        goto q3kcV;
        q3kcV:
        dzUvV:
        goto Z5EMb;
        Z5EMb:
        return $this->x0wV5->url($FjxfJ->getAttribute('filename'));
        goto hBwo8;
        hBwo8:
    }
    public function mSEGzvUlW0b(?string $szoiw) : ?string
    {
        goto Cs3Rg;
        f20up:
        $TnwL2 = parse_url($szoiw, PHP_URL_PATH);
        goto v6hkz;
        R3O9y:
        pbIYK:
        goto UCQ3K;
        v6hkz:
        return 's3://' . $this->q3TFM . '/' . ltrim($TnwL2, '/');
        goto n3dge;
        Cs3Rg:
        if (!$szoiw) {
            goto pbIYK;
        }
        goto Wj_6o;
        n3dge:
        d5BzQ:
        goto R3O9y;
        UCQ3K:
        return null;
        goto na7_3;
        Wj_6o:
        if (!fxvg7($szoiw, $this->q3TFM)) {
            goto d5BzQ;
        }
        goto f20up;
        na7_3:
    }
    public function mUfXNHGNmAK(string $TnwL2) : string
    {
        return 's3://' . $this->q3TFM . '/' . $TnwL2;
    }
}
