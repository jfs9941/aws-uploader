<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\Hj0NrxjG6qaVy;
use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Core\EW5dO98pv4IzW;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
final class RkcpO1qn0gOFt implements Hj0NrxjG6qaVy
{
    private $JPCb0;
    private $lD6rS;
    public $hyPZZ;
    private $FdPg0;
    private $A8IPs;
    private $xbA_A;
    public function __construct($rTxAJ, $Qt2wG, $z6O7y, $RwpWI, $zzSB2, $a_5ue)
    {
        goto agRfR;
        agRfR:
        $this->xbA_A = $a_5ue;
        goto xUq28;
        eZHpN:
        $this->lD6rS = $Qt2wG;
        goto apqBj;
        apqBj:
        $this->hyPZZ = $z6O7y;
        goto kMbUB;
        UCICq:
        $this->A8IPs = $zzSB2;
        goto kD7z0;
        xUq28:
        $this->JPCb0 = $rTxAJ;
        goto eZHpN;
        kMbUB:
        $this->FdPg0 = $RwpWI;
        goto UCICq;
        kD7z0:
    }
    public function resolvePath($csSew, $GWbyt = ZBLpZ2qUZ4P6C::S3) : string
    {
        goto ZKdRw;
        AEDgl:
        return trim($this->hyPZZ, '/') . '/' . $csSew;
        goto DZMUI;
        HiUpv:
        yVvQh:
        goto HR_b2;
        rYgYY:
        if (!$this->JPCb0) {
            goto zjX9e;
        }
        goto AEDgl;
        BMT7c:
        return trim($this->lD6rS, '/') . '/' . $csSew;
        goto acus7;
        pSSwt:
        byQGJ:
        goto rYgYY;
        s82iM:
        $csSew = $csSew->getAttribute('filename');
        goto HiUpv;
        DZMUI:
        zjX9e:
        goto BMT7c;
        txv5Z:
        if (!(!empty($this->FdPg0) && !empty($this->A8IPs))) {
            goto byQGJ;
        }
        goto nLDlW;
        nLDlW:
        return $this->mRxwykWM1jR($csSew);
        goto pSSwt;
        HR_b2:
        if (!($GWbyt === ZBLpZ2qUZ4P6C::LOCAL)) {
            goto q9Eop;
        }
        goto FYryL;
        FYryL:
        return config('upload.home') . '/' . $csSew;
        goto VVHxZ;
        ZKdRw:
        if (!$csSew instanceof O4HsadxAyKjYq) {
            goto yVvQh;
        }
        goto s82iM;
        VVHxZ:
        q9Eop:
        goto txv5Z;
        acus7:
    }
    public function resolveThumbnail(O4HsadxAyKjYq $csSew) : string
    {
        goto BGCmx;
        DMBRs:
        if (!$csSew->getAttribute('thumbnail_id')) {
            goto c5mb1;
        }
        goto OADWm;
        kgl6S:
        if (!$csSew instanceof EW5dO98pv4IzW) {
            goto wn2tS;
        }
        goto PvK1M;
        qR2eW:
        return $this->resolvePath($csSew, $csSew->getAttribute('driver'));
        goto Njsus;
        RPwah:
        if (!$qVNYt) {
            goto Y1p_E;
        }
        goto a0Unl;
        a0Unl:
        return $this->resolvePath($qVNYt, $qVNYt->getAttribute('driver'));
        goto kGIm0;
        kGIm0:
        Y1p_E:
        goto CSnen;
        PvK1M:
        return asset('/img/pdf-preview.svg');
        goto EKCih;
        OADWm:
        $qVNYt = Sf7MFJ2wUSx2k::find($csSew->getAttribute('thumbnail_id'));
        goto RPwah;
        yuc90:
        return $this->url($pBU9S, $csSew->getAttribute('driver'));
        goto VQON8;
        EKCih:
        wn2tS:
        goto tgz4I;
        Njsus:
        z0ipS:
        goto kgl6S;
        BGCmx:
        $pBU9S = $csSew->getAttribute('thumbnail');
        goto JbR0n;
        tgz4I:
        return '';
        goto nNPI9;
        A0RkS:
        if (!$csSew instanceof Sf7MFJ2wUSx2k) {
            goto z0ipS;
        }
        goto qR2eW;
        VQON8:
        XBh9W:
        goto DMBRs;
        JbR0n:
        if (!$pBU9S) {
            goto XBh9W;
        }
        goto yuc90;
        CSnen:
        c5mb1:
        goto A0RkS;
        nNPI9:
    }
    private function url($jGQTt, $GWbyt)
    {
        goto wbarw;
        GcFSD:
        return $this->resolvePath($jGQTt);
        goto gd5ji;
        EA5Ju:
        return config('upload.home') . '/' . $jGQTt;
        goto PR1QI;
        wbarw:
        if (!($GWbyt == ZBLpZ2qUZ4P6C::LOCAL)) {
            goto baDcw;
        }
        goto EA5Ju;
        PR1QI:
        baDcw:
        goto GcFSD;
        gd5ji:
    }
    private function mRxwykWM1jR($jGQTt)
    {
        goto pfzbN;
        l70pV:
        $ZmjRC = new UrlSigner($this->FdPg0, $this->xbA_A->path($this->A8IPs));
        goto uEZ0n;
        hf7X0:
        $uuQ6O = now()->addMinutes(60)->timestamp;
        goto l70pV;
        pfzbN:
        if (!(strpos($jGQTt, 'https://') === 0)) {
            goto pv_Vz;
        }
        goto HkFLh;
        FjzL0:
        pv_Vz:
        goto B0M3j;
        B0M3j:
        if (!(strpos($jGQTt, 'm3u8') !== false)) {
            goto jtiIZ;
        }
        goto z_L2X;
        lpub0:
        jtiIZ:
        goto hf7X0;
        HkFLh:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto FjzL0;
        z_L2X:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto lpub0;
        uEZ0n:
        return $ZmjRC->getSignedUrl($this->hyPZZ . '/' . $jGQTt, $uuQ6O);
        goto k9Y8U;
        k9Y8U:
    }
    public function resolvePathForHlsVideo(RVcEF1JsGQd8M $Ipllx, $t6Po9 = false) : string
    {
        goto XQZNv;
        Pji0u:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto Kmk2w;
        XQZNv:
        if ($Ipllx->getAttribute('hls_path')) {
            goto pQgBB;
        }
        goto Pji0u;
        Kmk2w:
        pQgBB:
        goto xh9NU;
        xh9NU:
        return $this->hyPZZ . '/' . $Ipllx->getAttribute('hls_path');
        goto wfN84;
        wfN84:
    }
    public function resolvePathForHlsVideos()
    {
        goto pXrEo;
        ytdkv:
        return [$xbtGz, $uuQ6O];
        goto wvZnP;
        qspM6:
        $IooL6 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto qMNdo;
        nNd7a:
        $N7bok = json_encode(['Statement' => [['Resource' => sprintf('%s*', $r8Gxo), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $uuQ6O]]]]]);
        goto qspM6;
        qMNdo:
        $xbtGz = $IooL6->getSignedCookie(['key_pair_id' => $this->FdPg0, 'private_key' => $this->xbA_A->path($this->A8IPs), 'policy' => $N7bok]);
        goto ytdkv;
        IyQND:
        $r8Gxo = $this->hyPZZ . '/v2/hls/';
        goto nNd7a;
        pXrEo:
        $uuQ6O = now()->addDays(3)->timestamp;
        goto IyQND;
        wvZnP:
    }
}
