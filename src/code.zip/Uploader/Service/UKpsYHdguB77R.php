<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\PxTzgsobiHpcX;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Core\Observer\OJfgYP3lLycLT;
use Jfs\Uploader\Core\Observer\Cfjbs9GHhe8pj;
use Jfs\Uploader\Core\XWqfTCKHy5X8X;
use Jfs\Uploader\Core\ASReQHmrabNfg;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
use Jfs\Uploader\Exception\OK51HRfKr7bLh;
use Jfs\Uploader\Exception\QdafZI2suLm2R;
use Jfs\Uploader\Service\FileResolver\HmYjF2kkTpcEM;
use Ramsey\Uuid\Uuid;
final class UKpsYHdguB77R
{
    private $zHYih;
    private $kduDw;
    private $ifs25;
    public function __construct($z4LlZ, $h5ffz, $PQlIa)
    {
        goto Ej0sB;
        lV_FJ:
        $this->kduDw = $h5ffz;
        goto ilL2R;
        Ej0sB:
        $this->zHYih = $z4LlZ;
        goto lV_FJ;
        ilL2R:
        $this->ifs25 = $PQlIa;
        goto gePqw;
        gePqw:
    }
    public function mmFTiQbv1u8($xiYXO)
    {
        goto NO9fB;
        NO9fB:
        if (!$xiYXO instanceof SingleUploadInterface) {
            goto giPwK;
        }
        goto cBqOK;
        gxIPT:
        return $this->mT1ck4LGIM0($rwAPO->extension(), GrPXtp41lLmde::S3, null, $xiYXO->options());
        goto xGHeH;
        cBqOK:
        $rwAPO = $xiYXO->getFile();
        goto gxIPT;
        BUtA7:
        return $this->mT1ck4LGIM0($xiYXO['file_extension'], 's3' === $xiYXO['driver'] ? GrPXtp41lLmde::S3 : GrPXtp41lLmde::LOCAL);
        goto y0pFo;
        xGHeH:
        giPwK:
        goto BUtA7;
        y0pFo:
    }
    public function m7zch1W8BLm(string $PV4mw)
    {
        goto C2aOS;
        ExS91:
        $nKKn0->setRawAttributes($TUPIK->getAttributes());
        goto m3Cgw;
        m3Cgw:
        return $nKKn0;
        goto r8Cbq;
        wPKH5:
        $nKKn0 = $this->mT1ck4LGIM0($TUPIK->getAttribute('type'), $TUPIK->getAttribute('driver'), $TUPIK->getAttribute('id'));
        goto swUC7;
        swUC7:
        $nKKn0->exists = true;
        goto ExS91;
        C2aOS:
        $TUPIK = config('upload.attachment_model')::findOrFail($PV4mw);
        goto wPKH5;
        r8Cbq:
    }
    public function mDTj3kUFDAD(string $aDi_y) : PxTzgsobiHpcX
    {
        goto MSDt9;
        V6vEu:
        throw new OK51HRfKr7bLh('metadata file not found');
        goto eeWq9;
        oqTpx:
        vyS20:
        goto V6vEu;
        vHZaA:
        $PYNm9 = ASReQHmrabNfg::mb0B4CHQcgE($kvLls);
        goto syrEE;
        JUkMp:
        cH5IA:
        goto Bv8RW;
        syrEE:
        return $this->mT1ck4LGIM0($PYNm9->D32Aw, $PYNm9->mpmJbSjDsFB(), $PYNm9->filename);
        goto oqTpx;
        BTFrA:
        if (!$kvLls) {
            goto vyS20;
        }
        goto vHZaA;
        Mox9q:
        if ($qxqXp) {
            goto cH5IA;
        }
        goto oGAnI;
        MSDt9:
        $qxqXp = $this->kduDw->get($aDi_y);
        goto Mox9q;
        oGAnI:
        $qxqXp = $this->ifs25->get($aDi_y);
        goto JUkMp;
        Bv8RW:
        $kvLls = json_decode($qxqXp, true);
        goto BTFrA;
        eeWq9:
    }
    private function mT1ck4LGIM0(string $SrbsC, $XwDVd, ?string $PV4mw = null, array $NSs5T = [])
    {
        goto xmCnR;
        udC34:
        ln71t:
        goto tcNgO;
        C1qN3:
        $DzRIS->mW7YosDFYf5(new Cfjbs9GHhe8pj($DzRIS, $this->ifs25, $NSs5T));
        goto LwNfV;
        JqnFj:
        switch ($SrbsC) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $DzRIS = McTg5Yp6FKC6z::createFromScratch($PV4mw, $SrbsC);
                goto eBzY7;
            case 'mp4':
            case 'mov':
                $DzRIS = CSQMvXC33KbbS::createFromScratch($PV4mw, $SrbsC);
                goto eBzY7;
            case 'pdf':
                $DzRIS = XWqfTCKHy5X8X::createFromScratch($PV4mw, $SrbsC);
                goto eBzY7;
            default:
                throw new QdafZI2suLm2R("not support file type {$SrbsC}");
        }
        goto udC34;
        LwNfV:
        foreach ($this->zHYih as $OZKMn) {
            goto ZWt0_;
            ZWt0_:
            if (!$OZKMn->mmEJ9rtxhah($DzRIS)) {
                goto tVzEt;
            }
            goto C_2BU;
            C_2BU:
            return $DzRIS->initLocation($OZKMn->mPZreWm8gaB($DzRIS));
            goto nker3;
            e7fT0:
            ZkkkT:
            goto kaJJJ;
            nker3:
            tVzEt:
            goto e7fT0;
            kaJJJ:
        }
        goto mgq57;
        LQ8ol:
        throw new QdafZI2suLm2R("not support file type {$SrbsC}");
        goto KCyJv;
        sdJ96:
        $DzRIS->mW7YosDFYf5(new OJfgYP3lLycLT($DzRIS));
        goto C1qN3;
        QfS0Y:
        $DzRIS = $DzRIS->m9DPiOrTNeU($XwDVd);
        goto sdJ96;
        xmCnR:
        $PV4mw = $PV4mw ?? Uuid::uuid4()->getHex()->toString();
        goto JqnFj;
        mgq57:
        HHmHZ:
        goto LQ8ol;
        tcNgO:
        eBzY7:
        goto QfS0Y;
        KCyJv:
    }
}
