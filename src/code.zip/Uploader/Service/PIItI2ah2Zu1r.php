<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\O79PdR1cao6Xq;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Core\UpreKuqs00udz;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
final class PIItI2ah2Zu1r implements O79PdR1cao6Xq
{
    private $ur8z1;
    private $mHv0r;
    public $yzP7k;
    private $eWiqr;
    private $oZX7W;
    private $QbAvB;
    public function __construct($cpXxv, $RjwI6, $fjVGN, $jtYDo, $dCRMx, $UNh9U)
    {
        goto ILGpG;
        lXlSI:
        $this->ur8z1 = $cpXxv;
        goto ZrNq9;
        RNJVt:
        $this->oZX7W = $dCRMx;
        goto eR74C;
        dJIbt:
        $this->yzP7k = $fjVGN;
        goto lOpYW;
        lOpYW:
        $this->eWiqr = $jtYDo;
        goto RNJVt;
        ILGpG:
        $this->QbAvB = $UNh9U;
        goto lXlSI;
        ZrNq9:
        $this->mHv0r = $RjwI6;
        goto dJIbt;
        eR74C:
    }
    public function resolvePath($pDny3, $Cnmk0 = GoWVLKcTGnffy::S3) : string
    {
        goto D_ghl;
        Oj5qV:
        return $this->mXGo7ZmHkce($pDny3);
        goto e3mUF;
        Z20yu:
        zLm_P:
        goto pg3MC;
        pg3MC:
        if (!(!empty($this->eWiqr) && !empty($this->oZX7W))) {
            goto jDVRh;
        }
        goto Oj5qV;
        Vk8Q5:
        $pDny3 = $pDny3->getAttribute('filename');
        goto OZQbh;
        D_ghl:
        if (!$pDny3 instanceof OXsaQ69LP2fiA) {
            goto WE_v9;
        }
        goto Vk8Q5;
        e3mUF:
        jDVRh:
        goto K3t6Q;
        kZJuK:
        return trim($this->mHv0r, '/') . '/' . $pDny3;
        goto i9h6d;
        JdllS:
        ALJSr:
        goto kZJuK;
        S9IKK:
        return config('upload.home') . '/' . $pDny3;
        goto Z20yu;
        zHdt9:
        return trim($this->yzP7k, '/') . '/' . $pDny3;
        goto JdllS;
        SnSMW:
        if (!($Cnmk0 === GoWVLKcTGnffy::LOCAL)) {
            goto zLm_P;
        }
        goto S9IKK;
        K3t6Q:
        if (!$this->ur8z1) {
            goto ALJSr;
        }
        goto zHdt9;
        OZQbh:
        WE_v9:
        goto SnSMW;
        i9h6d:
    }
    public function resolveThumbnail(OXsaQ69LP2fiA $pDny3) : string
    {
        goto aNfNk;
        UngCc:
        O0ZQo:
        goto DuQvx;
        X98kr:
        return '';
        goto Nb0s5;
        IsVw4:
        return $this->url($w6RVC, $pDny3->getAttribute('driver'));
        goto szlVw;
        Gwkcn:
        if (!$w6RVC) {
            goto Il2r3;
        }
        goto IsVw4;
        Xn0vJ:
        if (!$lW04N) {
            goto hlnB2;
        }
        goto ErNSz;
        aNfNk:
        $w6RVC = $pDny3->getAttribute('thumbnail');
        goto Gwkcn;
        w7tG3:
        hlnB2:
        goto UngCc;
        EWysJ:
        return $this->resolvePath($pDny3, $pDny3->getAttribute('driver'));
        goto Ik3_3;
        ylzH5:
        $lW04N = IZ5shp3JHuftD::find($pDny3->getAttribute('thumbnail_id'));
        goto Xn0vJ;
        Ik3_3:
        hdtCL:
        goto g5HH6;
        DuQvx:
        if (!$pDny3 instanceof IZ5shp3JHuftD) {
            goto hdtCL;
        }
        goto EWysJ;
        zVhz_:
        UX7G0:
        goto X98kr;
        ErNSz:
        return $this->resolvePath($lW04N, $lW04N->getAttribute('driver'));
        goto w7tG3;
        g5HH6:
        if (!$pDny3 instanceof UpreKuqs00udz) {
            goto UX7G0;
        }
        goto asgUs;
        szlVw:
        Il2r3:
        goto WYSyg;
        WYSyg:
        if (!$pDny3->getAttribute('thumbnail_id')) {
            goto O0ZQo;
        }
        goto ylzH5;
        asgUs:
        return asset('/img/pdf-preview.svg');
        goto zVhz_;
        Nb0s5:
    }
    private function url($yRiLu, $Cnmk0)
    {
        goto QKHJK;
        NN0K1:
        return config('upload.home') . '/' . $yRiLu;
        goto PpRsu;
        PpRsu:
        c0Z8j:
        goto fAmVd;
        fAmVd:
        return $this->resolvePath($yRiLu);
        goto Co8a6;
        QKHJK:
        if (!($Cnmk0 == GoWVLKcTGnffy::LOCAL)) {
            goto c0Z8j;
        }
        goto NN0K1;
        Co8a6:
    }
    private function mXGo7ZmHkce($yRiLu)
    {
        goto bZZVw;
        P3gmY:
        if (!(strpos($yRiLu, 'm3u8') !== false)) {
            goto MXfLN;
        }
        goto Z49dE;
        Lw8z1:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto e9GiB;
        bZZVw:
        if (!(strpos($yRiLu, 'https://') === 0)) {
            goto lBsbc;
        }
        goto Lw8z1;
        PgCvD:
        $Virw5 = new UrlSigner($this->eWiqr, $this->QbAvB->path($this->oZX7W));
        goto VERbO;
        i_XaB:
        MXfLN:
        goto AOTgu;
        VERbO:
        return $Virw5->getSignedUrl($this->yzP7k . '/' . $yRiLu, $RGoDQ);
        goto n6C9C;
        Z49dE:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto i_XaB;
        AOTgu:
        $RGoDQ = now()->addMinutes(60)->timestamp;
        goto PgCvD;
        e9GiB:
        lBsbc:
        goto P3gmY;
        n6C9C:
    }
    public function resolvePathForHlsVideo(VHp3UACVYl357 $bKijV, $Yj8qC = false) : string
    {
        goto hEGOI;
        a4YDH:
        return $this->yzP7k . '/' . $bKijV->getAttribute('hls_path');
        goto Ly8mw;
        h7s5e:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto vWlht;
        vWlht:
        jhtQN:
        goto a4YDH;
        hEGOI:
        if ($bKijV->getAttribute('hls_path')) {
            goto jhtQN;
        }
        goto h7s5e;
        Ly8mw:
    }
    public function resolvePathForHlsVideos()
    {
        goto zDPQ7;
        On3SE:
        $A_Tt4 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto ZJKwl;
        PVMOA:
        $y0U6G = $this->yzP7k . '/v2/hls/';
        goto aouKJ;
        jdFbc:
        return [$oyriV, $RGoDQ];
        goto sGmaW;
        aouKJ:
        $q6moK = json_encode(['Statement' => [['Resource' => sprintf('%s*', $y0U6G), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $RGoDQ]]]]]);
        goto On3SE;
        zDPQ7:
        $RGoDQ = now()->addDays(3)->timestamp;
        goto PVMOA;
        ZJKwl:
        $oyriV = $A_Tt4->getSignedCookie(['key_pair_id' => $this->eWiqr, 'private_key' => $this->QbAvB->path($this->oZX7W), 'policy' => $q6moK]);
        goto jdFbc;
        sGmaW:
    }
}
