<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\FmSSI1JLQCp0W;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class TfPYBqlVL98zf implements VideoPostHandleServiceInterface
{
    private $d8OUG;
    private $DksH2;
    public function __construct(UploadServiceInterface $Jml33, Filesystem $l4Drs)
    {
        $this->d8OUG = $Jml33;
        $this->DksH2 = $l4Drs;
    }
    public function saveMetadata(string $EmnXX, array $TxsWN)
    {
        goto eEerY;
        ksoNb:
        r0L7I:
        goto OaFoo;
        BskC0:
        if (!isset($TxsWN['thumbnail_url'])) {
            goto r0L7I;
        }
        goto zQvmI;
        JCUdU:
        if (!$oS5x2->bYlO6) {
            goto DSXPx;
        }
        goto Ch3Ib;
        eEerY:
        $oS5x2 = M7oTJdNm24KG4::findOrFail($EmnXX);
        goto BXuJ9;
        OaFoo:
        if (!isset($TxsWN['thumbnail'])) {
            goto Pgx7k;
        }
        goto tBI20;
        lNXlx:
        if (!isset($TxsWN['fps'])) {
            goto Q8Mkf;
        }
        goto b38YJ;
        m9GwD:
        if (!(isset($TxsWN['change_status']) && $TxsWN['change_status'])) {
            goto puN57;
        }
        goto dBlXN;
        llpNc:
        puN57:
        goto tb5jg;
        Ch3Ib:
        unset($H4Qx5['thumbnail']);
        goto AmHaa;
        M9G2n:
        Q8Mkf:
        goto JCUdU;
        dBlXN:
        $this->d8OUG->updateFile($oS5x2->getAttribute('id'), FmSSI1JLQCp0W::PROCESSING);
        goto llpNc;
        T82Lt:
        if (!$oS5x2->update($H4Qx5)) {
            goto SQjlj;
        }
        goto m9GwD;
        yAsLI:
        $H4Qx5['duration'] = $TxsWN['duration'];
        goto baygt;
        kmZy0:
        m0DaP:
        goto lNXlx;
        baygt:
        pt7BV:
        goto PQRWn;
        S3HcZ:
        $H4Qx5['resolution'] = $TxsWN['resolution'];
        goto kmZy0;
        tBI20:
        try {
            goto atR7O;
            atR7O:
            $BKlrl = $this->d8OUG->storeSingleFile(new class($TxsWN['thumbnail']) implements SingleUploadInterface
            {
                private $WpbZG;
                public function __construct($cNpq7)
                {
                    $this->WpbZG = $cNpq7;
                }
                public function getFile()
                {
                    return $this->WpbZG;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto BXGzv;
            zNaRM:
            $H4Qx5['thumbnail'] = $BKlrl['filename'];
            goto D2RdP;
            BXGzv:
            $H4Qx5['thumbnail_id'] = $BKlrl['id'];
            goto zNaRM;
            D2RdP:
        } catch (\Throwable $p7PBd) {
            Log::warning("M7oTJdNm24KG4 thumbnail store failed: " . $p7PBd->getMessage());
        }
        goto sb6WK;
        hDr2k:
        Log::warning("M7oTJdNm24KG4 metadata store failed for unknown reason ... " . $EmnXX);
        goto ZTqTD;
        ZTqTD:
        throw new \Exception("M7oTJdNm24KG4 metadata store failed for unknown reason ... " . $EmnXX);
        goto SEYof;
        mBE0e:
        SQjlj:
        goto hDr2k;
        PQRWn:
        if (!isset($TxsWN['resolution'])) {
            goto m0DaP;
        }
        goto S3HcZ;
        Lecxt:
        if (!isset($TxsWN['duration'])) {
            goto pt7BV;
        }
        goto yAsLI;
        tb5jg:
        return $oS5x2->getView();
        goto mBE0e;
        b38YJ:
        $H4Qx5['fps'] = $TxsWN['fps'];
        goto M9G2n;
        zQvmI:
        $H4Qx5['thumbnail'] = $TxsWN['thumbnail_url'];
        goto ksoNb;
        AmHaa:
        DSXPx:
        goto T82Lt;
        BXuJ9:
        $H4Qx5 = [];
        goto BskC0;
        sb6WK:
        Pgx7k:
        goto Lecxt;
        SEYof:
    }
    public function createThumbnail(string $tN0Hb) : void
    {
        goto EtXVz;
        JkkuD:
        if (!(!$this->DksH2->directoryExists($V1UKq) && empty($oS5x2->mRgpEKGn1n7()))) {
            goto HJvqB;
        }
        goto exQPY;
        J0KeP:
        $V1UKq = "v2/hls/thumbnails/{$tN0Hb}/";
        goto JkkuD;
        IkcEs:
        HJvqB:
        goto vEE03;
        exQPY:
        $xMvKw = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto c8NcJ;
        qPJwc:
        $oS5x2 = M7oTJdNm24KG4::findOrFail($tN0Hb);
        goto J0KeP;
        EtXVz:
        Log::info("Use Lambda to generate thumbnail for video: " . $tN0Hb);
        goto qPJwc;
        c8NcJ:
        try {
            goto R1mqb;
            SmT0X:
            $xMvKw->sendMessage(['QueueUrl' => $hLNMJ, 'MessageBody' => json_encode(['file_path' => $oS5x2->getLocation()])]);
            goto P8avX;
            UzJFc:
            $hLNMJ = $ZM3uf->get('QueueUrl');
            goto SmT0X;
            R1mqb:
            $ZM3uf = $xMvKw->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto UzJFc;
            P8avX:
        } catch (\Throwable $SoaRh) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$SoaRh->getMessage()}");
        }
        goto IkcEs;
        vEE03:
    }
    public function mQutqYQoz1E(string $tN0Hb) : void
    {
        goto RMe9Y;
        PqFsl:
        Log::error("Message back with success data but not found thumbnail " . $tN0Hb);
        goto ATVfW;
        Avug5:
        $V1UKq = "v2/hls/thumbnails/{$tN0Hb}/";
        goto aomE8;
        U_041:
        hzF0e:
        goto NOSms;
        AxfEN:
        lN29V:
        goto qrhs5;
        qrhs5:
        $oS5x2->update(['generated_previews' => $V1UKq]);
        goto Bgqjl;
        NOSms:
        $lS7oP = $this->DksH2->files($V1UKq);
        goto PH6vF;
        ATVfW:
        throw new \Exception("Message back with success data but not found thumbnail " . $tN0Hb);
        goto U_041;
        Gvi0H:
        Log::error("Message back with success data but not found thumbnail files " . $tN0Hb);
        goto A9UlX;
        A9UlX:
        throw new \Exception("Message back with success data but not found thumbnail files " . $tN0Hb);
        goto AxfEN;
        aomE8:
        if ($this->DksH2->directoryExists($V1UKq)) {
            goto hzF0e;
        }
        goto PqFsl;
        RMe9Y:
        $oS5x2 = M7oTJdNm24KG4::findOrFail($tN0Hb);
        goto Avug5;
        PH6vF:
        if (!(count($lS7oP) === 0)) {
            goto lN29V;
        }
        goto Gvi0H;
        Bgqjl:
    }
    public function getThumbnails(string $tN0Hb) : array
    {
        $oS5x2 = M7oTJdNm24KG4::findOrFail($tN0Hb);
        return $oS5x2->getThumbnails();
    }
    public function getMedia(string $tN0Hb) : array
    {
        $Zt12Z = Media::findOrFail($tN0Hb);
        return $Zt12Z->getView();
    }
}
