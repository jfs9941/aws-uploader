<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Illuminate\Contracts\Filesystem\Filesystem;
final class CbfzS01NR7tQ9
{
    private $p_blM;
    private $yIRQ_;
    private $BX0zD;
    public function __construct(string $b7Jn7, string $D5p6X, Filesystem $MKJ1D)
    {
        goto I9_GC;
        QDxB8:
        $this->BX0zD = $MKJ1D;
        goto KJZHl;
        I9_GC:
        $this->p_blM = $b7Jn7;
        goto GrztK;
        GrztK:
        $this->yIRQ_ = $D5p6X;
        goto QDxB8;
        KJZHl:
    }
    public function m5OGXMimkI7(D3Q3lppZQonk9 $mA8Ck) : string
    {
        goto XnPnO;
        XnPnO:
        if (!(NFXMub09wSQVu::S3 == $mA8Ck->getAttribute('driver'))) {
            goto LLOV8;
        }
        goto ksXRK;
        SJAc1:
        LLOV8:
        goto DDC_O;
        DDC_O:
        return $this->BX0zD->url($mA8Ck->getAttribute('filename'));
        goto rqIqh;
        ksXRK:
        return 's3://' . $this->p_blM . '/' . $mA8Ck->getAttribute('filename');
        goto SJAc1;
        rqIqh:
    }
    public function mEq98tyAuTi(?string $S2YNe) : ?string
    {
        goto ZOI0S;
        bQ7MG:
        z6tTG:
        goto A2rRB;
        ZcjBc:
        if (!pGUXP($S2YNe, $this->p_blM)) {
            goto gtkiF;
        }
        goto ijZBY;
        ZOI0S:
        if (!$S2YNe) {
            goto z6tTG;
        }
        goto ZcjBc;
        A2rRB:
        return null;
        goto xSxjD;
        bWf_O:
        return 's3://' . $this->p_blM . '/' . ltrim($F0ycc, '/');
        goto wmAIF;
        wmAIF:
        gtkiF:
        goto bQ7MG;
        ijZBY:
        $F0ycc = parse_url($S2YNe, PHP_URL_PATH);
        goto bWf_O;
        xSxjD:
    }
    public function mAH1KdigIIv(string $F0ycc) : string
    {
        return 's3://' . $this->p_blM . '/' . $F0ycc;
    }
}
