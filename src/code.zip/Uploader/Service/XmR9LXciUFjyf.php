<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
use Illuminate\Contracts\Filesystem\Filesystem;
final class XmR9LXciUFjyf
{
    private $XWRu9;
    private $zY6nV;
    private $IdG3S;
    public function __construct(string $Ba5m3, string $zMXpL, Filesystem $ftmEm)
    {
        goto afUi0;
        afUi0:
        $this->XWRu9 = $Ba5m3;
        goto dM5T_;
        dM5T_:
        $this->zY6nV = $zMXpL;
        goto OFjQy;
        OFjQy:
        $this->IdG3S = $ftmEm;
        goto l2vCA;
        l2vCA:
    }
    public function mxWazagsF3t(ZZfsW9KHWsMrx $mbUjE) : string
    {
        goto CHBrm;
        mjKce:
        return $this->IdG3S->url($mbUjE->getAttribute('filename'));
        goto xBHI_;
        kcMkm:
        GcxWe:
        goto mjKce;
        CHBrm:
        if (!(Rf7fPQasmK9R3::S3 == $mbUjE->getAttribute('driver'))) {
            goto GcxWe;
        }
        goto efigJ;
        efigJ:
        return 's3://' . $this->XWRu9 . '/' . $mbUjE->getAttribute('filename');
        goto kcMkm;
        xBHI_:
    }
    public function mwu24m1eaLt(?string $GKxAm) : ?string
    {
        goto EYNmC;
        nfRIM:
        Fx_uM:
        goto MUtvU;
        HjLcS:
        PwHrH:
        goto nfRIM;
        MUtvU:
        return null;
        goto fOgu4;
        g6o4W:
        if (!INYmT($GKxAm, $this->XWRu9)) {
            goto PwHrH;
        }
        goto kaL0D;
        HXTbL:
        return 's3://' . $this->XWRu9 . '/' . ltrim($liQkG, '/');
        goto HjLcS;
        kaL0D:
        $liQkG = parse_url($GKxAm, PHP_URL_PATH);
        goto HXTbL;
        EYNmC:
        if (!$GKxAm) {
            goto Fx_uM;
        }
        goto g6o4W;
        fOgu4:
    }
    public function mqr1lHgkTtT(string $liQkG) : string
    {
        return 's3://' . $this->XWRu9 . '/' . $liQkG;
    }
}
