<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\N4CY6qDTBAjPa;
final class XPbFd7sAajZAw implements VideoPostHandleServiceInterface
{
    private $q0dgM;
    private $GQuun;
    public function __construct(UploadServiceInterface $OvvM0, Filesystem $Q0shJ)
    {
        $this->q0dgM = $OvvM0;
        $this->GQuun = $Q0shJ;
    }
    public function saveMetadata(string $eXur0, array $jJ8fr)
    {
        goto XS6GK;
        XS6GK:
        $DuZ1o = S25BfMDKrX8cB::findOrFail($eXur0);
        goto ljge0;
        bBQzA:
        $B2_gB['fps'] = $jJ8fr['fps'];
        goto zCPue;
        zCPue:
        SJOz4:
        goto PUMJ3;
        Kw295:
        $B2_gB['duration'] = $jJ8fr['duration'];
        goto Ee6yX;
        PUMJ3:
        if (!$DuZ1o->update($B2_gB)) {
            goto VB8Ot;
        }
        goto hiFeY;
        K3MSn:
        $this->q0dgM->updateFile($DuZ1o->getAttribute('id'), N4CY6qDTBAjPa::PROCESSING);
        goto k39fb;
        hhSK2:
        $B2_gB['resolution'] = $jJ8fr['resolution'];
        goto ECooL;
        xNKv9:
        return $DuZ1o->getView();
        goto YyMcb;
        k39fb:
        ygm9O:
        goto xNKv9;
        UpIkF:
        if (!isset($jJ8fr['resolution'])) {
            goto FD8jc;
        }
        goto hhSK2;
        CCjtL:
        if (!isset($jJ8fr['thumbnail'])) {
            goto Y10hY;
        }
        goto R98u2;
        YyMcb:
        VB8Ot:
        goto lKAH3;
        iAPGA:
        if (!isset($jJ8fr['duration'])) {
            goto wKj1s;
        }
        goto Kw295;
        PdANN:
        if (!isset($jJ8fr['fps'])) {
            goto SJOz4;
        }
        goto bBQzA;
        ECooL:
        FD8jc:
        goto PdANN;
        R98u2:
        try {
            goto KOIWd;
            ehc9O:
            $B2_gB['thumbnail_id'] = $jVS4s['id'];
            goto tjHDp;
            KOIWd:
            $jVS4s = $this->q0dgM->storeSingleFile(new class($jJ8fr['thumbnail']) implements SingleUploadInterface
            {
                private $CqvUz;
                public function __construct($ezBDN)
                {
                    $this->CqvUz = $ezBDN;
                }
                public function getFile()
                {
                    return $this->CqvUz;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto ehc9O;
            tjHDp:
            $B2_gB['thumbnail'] = $jVS4s['filename'];
            goto jSc3t;
            jSc3t:
        } catch (\Throwable $QEfxK) {
            Log::warning("S25BfMDKrX8cB thumbnail store failed: " . $QEfxK->getMessage());
        }
        goto Xzwo1;
        Xzwo1:
        Y10hY:
        goto iAPGA;
        ljge0:
        $B2_gB = [];
        goto CCjtL;
        MpZZQ:
        throw new \Exception("S25BfMDKrX8cB metadata store failed for unknown reason ... " . $eXur0);
        goto HR853;
        Ee6yX:
        wKj1s:
        goto UpIkF;
        lKAH3:
        Log::warning("S25BfMDKrX8cB metadata store failed for unknown reason ... " . $eXur0);
        goto MpZZQ;
        hiFeY:
        if (!(isset($jJ8fr['change_status']) && $jJ8fr['change_status'])) {
            goto ygm9O;
        }
        goto K3MSn;
        HR853:
    }
    public function createThumbnail(string $Z5IKY) : void
    {
        goto GqFIj;
        GqFIj:
        Log::info("Use Lambda to generate thumbnail for video: " . $Z5IKY);
        goto ssE2X;
        f17G0:
        E_SLk:
        goto hs8MD;
        ssE2X:
        $DuZ1o = S25BfMDKrX8cB::findOrFail($Z5IKY);
        goto ILcFn;
        i13J1:
        $k4DiW = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto HDdra;
        qokOD:
        if (!(!$this->GQuun->directoryExists($qSReT) && empty($DuZ1o->m23611Wf1SX()))) {
            goto E_SLk;
        }
        goto i13J1;
        ILcFn:
        $qSReT = "v2/hls/thumbnails/{$Z5IKY}/";
        goto qokOD;
        HDdra:
        try {
            goto lrFe2;
            lrFe2:
            $D1FVR = $k4DiW->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto rM87W;
            rM87W:
            $eSzBs = $D1FVR->get('QueueUrl');
            goto Ap2Xb;
            Ap2Xb:
            $k4DiW->sendMessage(['QueueUrl' => $eSzBs, 'MessageBody' => json_encode(['file_path' => $DuZ1o->getLocation()])]);
            goto dCNXh;
            dCNXh:
        } catch (\Throwable $HqoZE) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$HqoZE->getMessage()}");
        }
        goto f17G0;
        hs8MD:
    }
    public function mS6VG1cfSdI(string $Z5IKY) : void
    {
        goto UWZIE;
        seQKZ:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Z5IKY);
        goto k7WGs;
        yDUQn:
        $qSReT = "v2/hls/thumbnails/{$Z5IKY}/";
        goto yX1oa;
        k7WGs:
        zqGUc:
        goto FJPVG;
        JqN27:
        $LJkda = $this->GQuun->files($qSReT);
        goto sAWxc;
        UWZIE:
        $DuZ1o = S25BfMDKrX8cB::findOrFail($Z5IKY);
        goto yDUQn;
        FJPVG:
        $DuZ1o->update(['generated_previews' => $qSReT]);
        goto gZwzE;
        CW9rN:
        zF0wR:
        goto JqN27;
        CqR6X:
        Log::error("Message back with success data but not found thumbnail " . $Z5IKY);
        goto FgXU3;
        EDAvQ:
        Log::error("Message back with success data but not found thumbnail files " . $Z5IKY);
        goto seQKZ;
        yX1oa:
        if ($this->GQuun->directoryExists($qSReT)) {
            goto zF0wR;
        }
        goto CqR6X;
        FgXU3:
        throw new \Exception("Message back with success data but not found thumbnail " . $Z5IKY);
        goto CW9rN;
        sAWxc:
        if (!(count($LJkda) === 0)) {
            goto zqGUc;
        }
        goto EDAvQ;
        gZwzE:
    }
    public function getThumbnails(string $Z5IKY) : array
    {
        $DuZ1o = S25BfMDKrX8cB::findOrFail($Z5IKY);
        return $DuZ1o->getThumbnails();
    }
}
