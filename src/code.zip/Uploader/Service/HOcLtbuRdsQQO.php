<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\LV0wDYHZInswq;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class HOcLtbuRdsQQO implements VideoPostHandleServiceInterface
{
    private $fzNFy;
    private $uiTOc;
    public function __construct(UploadServiceInterface $eDdBl, Filesystem $ATeSz)
    {
        $this->fzNFy = $eDdBl;
        $this->uiTOc = $ATeSz;
    }
    public function saveMetadata(string $B_L9m, array $fK0e7)
    {
        goto pkJU6;
        mnWHr:
        $this->fzNFy->updateFile($QCHmE->getAttribute('id'), LV0wDYHZInswq::PROCESSING);
        goto JFE_q;
        ZKfqW:
        if (!isset($fK0e7['duration'])) {
            goto rguYZ;
        }
        goto l5Z6S;
        D_YMu:
        SerD9:
        goto ZKfqW;
        Xwkv9:
        if (!isset($fK0e7['thumbnail'])) {
            goto SerD9;
        }
        goto aX0GJ;
        l5Z6S:
        $NSxZE['duration'] = $fK0e7['duration'];
        goto j0T1A;
        IdFiA:
        if (!$QCHmE->update($NSxZE)) {
            goto DosBO;
        }
        goto tSrCu;
        pkJU6:
        $QCHmE = U9HMl0N8dP0ZH::findOrFail($B_L9m);
        goto k6OZZ;
        vfMCA:
        J_uWF:
        goto IdFiA;
        k6OZZ:
        $NSxZE = [];
        goto bS866;
        JFE_q:
        LtYzV:
        goto MWR2l;
        kd6Fg:
        HQVq9:
        goto hXlBx;
        j0T1A:
        rguYZ:
        goto Ia1zh;
        MWR2l:
        return $QCHmE->getView();
        goto CaIRq;
        ZiGsa:
        v77oI:
        goto sZRNF;
        IJShO:
        throw new \Exception("U9HMl0N8dP0ZH metadata store failed for unknown reason ... " . $B_L9m);
        goto G723_;
        YEC45:
        t82Wx:
        goto Xwkv9;
        hXlBx:
        if (!$QCHmE->hrRlC) {
            goto J_uWF;
        }
        goto nJn39;
        velvR:
        Log::warning("U9HMl0N8dP0ZH metadata store failed for unknown reason ... " . $B_L9m);
        goto IJShO;
        aX0GJ:
        try {
            goto JlWDe;
            PYY3S:
            $NSxZE['thumbnail'] = $i7XwP['filename'];
            goto vd3mB;
            PLecj:
            $NSxZE['thumbnail_id'] = $i7XwP['id'];
            goto PYY3S;
            JlWDe:
            $i7XwP = $this->fzNFy->storeSingleFile(new class($fK0e7['thumbnail']) implements SingleUploadInterface
            {
                private $EA4YD;
                public function __construct($YfsmL)
                {
                    $this->EA4YD = $YfsmL;
                }
                public function getFile()
                {
                    return $this->EA4YD;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto PLecj;
            vd3mB:
        } catch (\Throwable $bIOBo) {
            Log::warning("U9HMl0N8dP0ZH thumbnail store failed: " . $bIOBo->getMessage());
        }
        goto D_YMu;
        GrYXz:
        $NSxZE['resolution'] = $fK0e7['resolution'];
        goto ZiGsa;
        fmNoY:
        $NSxZE['thumbnail'] = $fK0e7['thumbnail_url'];
        goto YEC45;
        sZRNF:
        if (!isset($fK0e7['fps'])) {
            goto HQVq9;
        }
        goto sCp8a;
        Ia1zh:
        if (!isset($fK0e7['resolution'])) {
            goto v77oI;
        }
        goto GrYXz;
        tSrCu:
        if (!(isset($fK0e7['change_status']) && $fK0e7['change_status'])) {
            goto LtYzV;
        }
        goto mnWHr;
        CaIRq:
        DosBO:
        goto velvR;
        bS866:
        if (!isset($fK0e7['thumbnail_url'])) {
            goto t82Wx;
        }
        goto fmNoY;
        sCp8a:
        $NSxZE['fps'] = $fK0e7['fps'];
        goto kd6Fg;
        nJn39:
        unset($NSxZE['thumbnail']);
        goto vfMCA;
        G723_:
    }
    public function createThumbnail(string $L0rJG) : void
    {
        goto R0qbc;
        R0qbc:
        Log::info("Use Lambda to generate thumbnail for video: " . $L0rJG);
        goto wSMwP;
        tXYAz:
        if (!(!$this->uiTOc->directoryExists($W4_7k) && empty($QCHmE->mrmperSQ6nG()))) {
            goto RG4Kt;
        }
        goto FHbQF;
        wSMwP:
        $QCHmE = U9HMl0N8dP0ZH::findOrFail($L0rJG);
        goto svx4D;
        svx4D:
        $W4_7k = "v2/hls/thumbnails/{$L0rJG}/";
        goto tXYAz;
        iUwzV:
        try {
            goto f1ihd;
            ONSDa:
            $jsVnD = $Yxe5x->get('QueueUrl');
            goto sFnzb;
            sFnzb:
            $zU9w2->sendMessage(['QueueUrl' => $jsVnD, 'MessageBody' => json_encode(['file_path' => $QCHmE->getLocation()])]);
            goto ji8cJ;
            f1ihd:
            $Yxe5x = $zU9w2->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto ONSDa;
            ji8cJ:
        } catch (\Throwable $kHEpW) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$kHEpW->getMessage()}");
        }
        goto uYn3n;
        uYn3n:
        RG4Kt:
        goto JiSu1;
        FHbQF:
        $zU9w2 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto iUwzV;
        JiSu1:
    }
    public function mEyQWcoCb0X(string $L0rJG) : void
    {
        goto qH7P2;
        SK9_X:
        if ($this->uiTOc->directoryExists($W4_7k)) {
            goto QGGAV;
        }
        goto F4yAB;
        qV3Sc:
        if (!(count($siX1k) === 0)) {
            goto ZAQZs;
        }
        goto hLtA5;
        NvGNL:
        throw new \Exception("Message back with success data but not found thumbnail files " . $L0rJG);
        goto ksnzR;
        bAWPE:
        throw new \Exception("Message back with success data but not found thumbnail " . $L0rJG);
        goto Rmgeh;
        Rmgeh:
        QGGAV:
        goto ljn7U;
        YTiGf:
        $QCHmE->update(['generated_previews' => $W4_7k]);
        goto G5IXd;
        qH7P2:
        $QCHmE = U9HMl0N8dP0ZH::findOrFail($L0rJG);
        goto UnIS0;
        UnIS0:
        $W4_7k = "v2/hls/thumbnails/{$L0rJG}/";
        goto SK9_X;
        F4yAB:
        Log::error("Message back with success data but not found thumbnail " . $L0rJG);
        goto bAWPE;
        ksnzR:
        ZAQZs:
        goto YTiGf;
        ljn7U:
        $siX1k = $this->uiTOc->files($W4_7k);
        goto qV3Sc;
        hLtA5:
        Log::error("Message back with success data but not found thumbnail files " . $L0rJG);
        goto NvGNL;
        G5IXd:
    }
    public function getThumbnails(string $L0rJG) : array
    {
        $QCHmE = U9HMl0N8dP0ZH::findOrFail($L0rJG);
        return $QCHmE->getThumbnails();
    }
    public function getMedia(string $L0rJG) : array
    {
        $uTqKK = Media::findOrFail($L0rJG);
        return $uTqKK->getView();
    }
}
