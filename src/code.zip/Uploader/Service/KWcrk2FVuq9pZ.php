<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Core\SzJ0JuIDdEumD;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
final class KWcrk2FVuq9pZ implements Yuf8dMzRcjZ21
{
    private $J6ge1;
    private $sV8xR;
    public $log92;
    private $Mivhj;
    private $I4KpB;
    private $uBhrQ;
    public function __construct($nKN22, $uV1ua, $kquF2, $onKA1, $WUVFG, $Ms6sq)
    {
        goto GvJNw;
        C8gZT:
        $this->Mivhj = $onKA1;
        goto LN4fV;
        LN4fV:
        $this->I4KpB = $WUVFG;
        goto jsWNX;
        LVz2r:
        $this->J6ge1 = $nKN22;
        goto zEwvj;
        GvJNw:
        $this->uBhrQ = $Ms6sq;
        goto LVz2r;
        zEwvj:
        $this->sV8xR = $uV1ua;
        goto zLzMW;
        zLzMW:
        $this->log92 = $kquF2;
        goto C8gZT;
        jsWNX:
    }
    public function resolvePath($DzZNO, $Zqemz = Rc6MZhMMdyG6A::S3) : string
    {
        goto yhlzR;
        kR7SV:
        return trim($this->log92, '/') . '/' . $DzZNO;
        goto XI_Zd;
        E_EzQ:
        return $this->mTQtJl53omu($DzZNO);
        goto iLB7t;
        xX099:
        return config('upload.home') . '/' . $DzZNO;
        goto Mi2d1;
        C0lB3:
        return trim($this->sV8xR, '/') . '/' . $DzZNO;
        goto hcUQh;
        TyOjF:
        if (!($Zqemz === Rc6MZhMMdyG6A::LOCAL)) {
            goto EUDha;
        }
        goto xX099;
        ypTtR:
        $DzZNO = $DzZNO->getAttribute('filename');
        goto VFyXX;
        Mi2d1:
        EUDha:
        goto S_LGo;
        S_LGo:
        if (!(!empty($this->Mivhj) && !empty($this->I4KpB))) {
            goto TMdvk;
        }
        goto E_EzQ;
        wKa2w:
        if (!$this->J6ge1) {
            goto DIthk;
        }
        goto kR7SV;
        iLB7t:
        TMdvk:
        goto wKa2w;
        VFyXX:
        lU2RS:
        goto TyOjF;
        yhlzR:
        if (!$DzZNO instanceof DMUaxGX7XHAI0) {
            goto lU2RS;
        }
        goto ypTtR;
        XI_Zd:
        DIthk:
        goto C0lB3;
        hcUQh:
    }
    public function resolveThumbnail(DMUaxGX7XHAI0 $DzZNO) : string
    {
        goto uqeLU;
        YfkMV:
        cWwYu:
        goto VVS_S;
        hA2SM:
        if (!$DzZNO->getAttribute('thumbnail_id')) {
            goto cWwYu;
        }
        goto g4oww;
        WR3_p:
        GJXyA:
        goto vHVHI;
        NRS3P:
        return asset('/img/pdf-preview.svg');
        goto jU6Q4;
        hNThw:
        if (!$c2ORW) {
            goto kUSkd;
        }
        goto a1WaE;
        E_vge:
        return $this->resolvePath($CaD8L, $CaD8L->getAttribute('driver'));
        goto N5Rcq;
        N5Rcq:
        Fksp3:
        goto YfkMV;
        a1WaE:
        return $this->url($c2ORW, $DzZNO->getAttribute('driver'));
        goto aYiqG;
        VVS_S:
        if (!$DzZNO instanceof JyZaxpharsbun) {
            goto GJXyA;
        }
        goto ATeyl;
        g4oww:
        $CaD8L = JyZaxpharsbun::find($DzZNO->getAttribute('thumbnail_id'));
        goto hJg5t;
        WdkaF:
        return '';
        goto Wnph1;
        jU6Q4:
        WBO8R:
        goto WdkaF;
        aYiqG:
        kUSkd:
        goto hA2SM;
        hJg5t:
        if (!$CaD8L) {
            goto Fksp3;
        }
        goto E_vge;
        uqeLU:
        $c2ORW = $DzZNO->getAttribute('thumbnail');
        goto hNThw;
        ATeyl:
        return $this->resolvePath($DzZNO, $DzZNO->getAttribute('driver'));
        goto WR3_p;
        vHVHI:
        if (!$DzZNO instanceof SzJ0JuIDdEumD) {
            goto WBO8R;
        }
        goto NRS3P;
        Wnph1:
    }
    private function url($z69yI, $Zqemz)
    {
        goto LefWp;
        CUWto:
        ypFs0:
        goto l1tuZ;
        l1tuZ:
        return $this->resolvePath($z69yI);
        goto K73GK;
        Efjqh:
        return config('upload.home') . '/' . $z69yI;
        goto CUWto;
        LefWp:
        if (!($Zqemz == Rc6MZhMMdyG6A::LOCAL)) {
            goto ypFs0;
        }
        goto Efjqh;
        K73GK:
    }
    private function mTQtJl53omu($z69yI)
    {
        goto S0z0U;
        J0z7L:
        kYAYX:
        goto twGvP;
        O9AIn:
        return $daG8X->getSignedUrl($this->log92 . '/' . $z69yI, $gMhiu);
        goto lVTYy;
        q0Lb2:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto UB9_R;
        bW5eP:
        $daG8X = new UrlSigner($this->Mivhj, $this->uBhrQ->path($this->I4KpB));
        goto O9AIn;
        wUMJ3:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto J0z7L;
        twGvP:
        if (!(strpos($z69yI, 'm3u8') !== false)) {
            goto onjqf;
        }
        goto q0Lb2;
        UB9_R:
        onjqf:
        goto e2Ouj;
        e2Ouj:
        $gMhiu = now()->addMinutes(60)->timestamp;
        goto bW5eP;
        S0z0U:
        if (!(strpos($z69yI, 'https://') === 0)) {
            goto kYAYX;
        }
        goto wUMJ3;
        lVTYy:
    }
    public function resolvePathForHlsVideo(Kt6NO3eUvdER6 $yZXjN, $Nki3P = false) : string
    {
        goto tP1hp;
        HstXc:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto P7pXn;
        P7pXn:
        j2Qc7:
        goto JR52V;
        JR52V:
        return $this->log92 . '/' . $yZXjN->getAttribute('hls_path');
        goto rRc9M;
        tP1hp:
        if ($yZXjN->getAttribute('hls_path')) {
            goto j2Qc7;
        }
        goto HstXc;
        rRc9M:
    }
    public function resolvePathForHlsVideos()
    {
        goto f3w2i;
        f3w2i:
        $gMhiu = now()->addDays(3)->timestamp;
        goto oFBMg;
        s3SLK:
        $RMkOe = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto zEDid;
        tIV_4:
        return [$DexuR, $gMhiu];
        goto Ne7ps;
        dkGz1:
        $O6VS9 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $eFd9Q), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $gMhiu]]]]]);
        goto s3SLK;
        zEDid:
        $DexuR = $RMkOe->getSignedCookie(['key_pair_id' => $this->Mivhj, 'private_key' => $this->uBhrQ->path($this->I4KpB), 'policy' => $O6VS9]);
        goto tIV_4;
        oFBMg:
        $eFd9Q = $this->log92 . '/v2/hls/';
        goto dkGz1;
        Ne7ps:
    }
}
