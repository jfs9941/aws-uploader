<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\Tbw0jsMnRbOTP;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class BQJIbuRaJNRQo implements VideoPostHandleServiceInterface
{
    private $Kcs_8;
    private $RE_2F;
    public function __construct(UploadServiceInterface $g7xMm, Filesystem $WmwnR)
    {
        $this->Kcs_8 = $g7xMm;
        $this->RE_2F = $WmwnR;
    }
    public function saveMetadata(string $LpGEK, array $SaEd8)
    {
        goto Fp6we;
        qv5fY:
        gFQwS:
        goto Hwjoi;
        UKOss:
        throw new \Exception("Jf5KRr8uE3t34 metadata store failed for unknown reason ... " . $LpGEK);
        goto gIz18;
        FkhhW:
        return $Qw86m->getView();
        goto Btcxq;
        u4bCi:
        $wDkzz['resolution'] = $SaEd8['resolution'];
        goto SpWfD;
        i4e7h:
        VCqe8:
        goto PPgC7;
        FNvCL:
        if (!(isset($SaEd8['change_status']) && $SaEd8['change_status'])) {
            goto M3C0d;
        }
        goto n3Z5R;
        lDbVx:
        nG6c8:
        goto RJAmx;
        imK4m:
        Log::warning("Jf5KRr8uE3t34 metadata store failed for unknown reason ... " . $LpGEK);
        goto UKOss;
        Fp6we:
        $Qw86m = Jf5KRr8uE3t34::findOrFail($LpGEK);
        goto uv4xD;
        RJAmx:
        if (!$Qw86m->r3OVR) {
            goto VCqe8;
        }
        goto ZL2f9;
        Btcxq:
        m03Eq:
        goto imK4m;
        wHM7Y:
        $wDkzz['thumbnail'] = $SaEd8['thumbnail_url'];
        goto qv5fY;
        t_4Hq:
        $wDkzz['fps'] = $SaEd8['fps'];
        goto lDbVx;
        SpWfD:
        QSez6:
        goto sCobq;
        uv4xD:
        $wDkzz = [];
        goto IoKp2;
        hWDFH:
        if (!isset($SaEd8['duration'])) {
            goto H3sdX;
        }
        goto MNQPF;
        Ihk23:
        try {
            goto Voep2;
            t31Gt:
            $wDkzz['thumbnail'] = $saBWi['filename'];
            goto J13Dc;
            T0Mls:
            $wDkzz['thumbnail_id'] = $saBWi['id'];
            goto t31Gt;
            Voep2:
            $saBWi = $this->Kcs_8->storeSingleFile(new class($SaEd8['thumbnail']) implements SingleUploadInterface
            {
                private $Suzy5;
                public function __construct($RCdwx)
                {
                    $this->Suzy5 = $RCdwx;
                }
                public function getFile()
                {
                    return $this->Suzy5;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto T0Mls;
            J13Dc:
        } catch (\Throwable $AUVE0) {
            Log::warning("Jf5KRr8uE3t34 thumbnail store failed: " . $AUVE0->getMessage());
        }
        goto JI7j8;
        PPgC7:
        if (!$Qw86m->update($wDkzz)) {
            goto m03Eq;
        }
        goto FNvCL;
        Vmffd:
        if (!isset($SaEd8['resolution'])) {
            goto QSez6;
        }
        goto u4bCi;
        MNQPF:
        $wDkzz['duration'] = $SaEd8['duration'];
        goto JUncS;
        JI7j8:
        b6CG8:
        goto hWDFH;
        IoKp2:
        if (!isset($SaEd8['thumbnail_url'])) {
            goto gFQwS;
        }
        goto wHM7Y;
        ZL2f9:
        unset($wDkzz['thumbnail']);
        goto i4e7h;
        JUncS:
        H3sdX:
        goto Vmffd;
        kAbaF:
        M3C0d:
        goto FkhhW;
        n3Z5R:
        $this->Kcs_8->updateFile($Qw86m->getAttribute('id'), Tbw0jsMnRbOTP::PROCESSING);
        goto kAbaF;
        sCobq:
        if (!isset($SaEd8['fps'])) {
            goto nG6c8;
        }
        goto t_4Hq;
        Hwjoi:
        if (!isset($SaEd8['thumbnail'])) {
            goto b6CG8;
        }
        goto Ihk23;
        gIz18:
    }
    public function createThumbnail(string $Vv6Mk) : void
    {
        goto RtTcQ;
        kUsvT:
        $Zk9Zo = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto NTuZ4;
        wf9nz:
        $Qw86m = Jf5KRr8uE3t34::findOrFail($Vv6Mk);
        goto JikSf;
        RtTcQ:
        Log::info("Use Lambda to generate thumbnail for video: " . $Vv6Mk);
        goto wf9nz;
        NTuZ4:
        try {
            goto fyiKZ;
            fyiKZ:
            $Bl6vV = $Zk9Zo->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto TojCO;
            TojCO:
            $ZgJmz = $Bl6vV->get('QueueUrl');
            goto kdhTj;
            kdhTj:
            $Zk9Zo->sendMessage(['QueueUrl' => $ZgJmz, 'MessageBody' => json_encode(['file_path' => $Qw86m->getLocation()])]);
            goto GhQUS;
            GhQUS:
        } catch (\Throwable $OtxN7) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$OtxN7->getMessage()}");
        }
        goto n8c1_;
        n8c1_:
        cvQ2l:
        goto yMYn6;
        JikSf:
        $yGhrF = "v2/hls/thumbnails/{$Vv6Mk}/";
        goto bnzFm;
        bnzFm:
        if (!(!$this->RE_2F->directoryExists($yGhrF) && empty($Qw86m->mcMblSBRNAQ()))) {
            goto cvQ2l;
        }
        goto kUsvT;
        yMYn6:
    }
    public function m5H8dzBb8XI(string $Vv6Mk) : void
    {
        goto lfwRR;
        AvgIV:
        if (!(count($i0dgv) === 0)) {
            goto caIdM;
        }
        goto n2SOy;
        AmvW3:
        $i0dgv = $this->RE_2F->files($yGhrF);
        goto AvgIV;
        yTBBL:
        if ($this->RE_2F->directoryExists($yGhrF)) {
            goto B3zHo;
        }
        goto QmYLN;
        M_PKN:
        $yGhrF = "v2/hls/thumbnails/{$Vv6Mk}/";
        goto yTBBL;
        UhXrG:
        $Qw86m->update(['generated_previews' => $yGhrF]);
        goto BncKS;
        QmYLN:
        Log::error("Message back with success data but not found thumbnail " . $Vv6Mk);
        goto pQk_S;
        ywlNq:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Vv6Mk);
        goto r0VYv;
        MKq4h:
        B3zHo:
        goto AmvW3;
        lfwRR:
        $Qw86m = Jf5KRr8uE3t34::findOrFail($Vv6Mk);
        goto M_PKN;
        r0VYv:
        caIdM:
        goto UhXrG;
        pQk_S:
        throw new \Exception("Message back with success data but not found thumbnail " . $Vv6Mk);
        goto MKq4h;
        n2SOy:
        Log::error("Message back with success data but not found thumbnail files " . $Vv6Mk);
        goto ywlNq;
        BncKS:
    }
    public function getThumbnails(string $Vv6Mk) : array
    {
        $Qw86m = Jf5KRr8uE3t34::findOrFail($Vv6Mk);
        return $Qw86m->getThumbnails();
    }
    public function getMedia(string $Vv6Mk) : array
    {
        $IH9NP = Media::findOrFail($Vv6Mk);
        return $IH9NP->getView();
    }
}
