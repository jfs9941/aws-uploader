<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\AbPtLXucv9ja8;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Core\OrjVhA5InRPZV;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
final class AkmCl9xAlobwb implements AbPtLXucv9ja8
{
    private $HTAsb;
    private $SXR9x;
    public $jKfln;
    private $Umyol;
    private $QscF0;
    private $GRsEs;
    public function __construct($wiEXQ, $yHOnu, $FIlxI, $EGaHi, $zSfKO, $Zywh9)
    {
        goto mtOqZ;
        UxcJW:
        $this->SXR9x = $yHOnu;
        goto GeUcU;
        wcx_A:
        $this->QscF0 = $zSfKO;
        goto fhZ8y;
        N_uvZ:
        $this->HTAsb = $wiEXQ;
        goto UxcJW;
        GeUcU:
        $this->jKfln = $FIlxI;
        goto U7UOO;
        mtOqZ:
        $this->GRsEs = $Zywh9;
        goto N_uvZ;
        U7UOO:
        $this->Umyol = $EGaHi;
        goto wcx_A;
        fhZ8y:
    }
    public function resolvePath($D_Z4Z, $E6W0h = PdN71mQX1JeZG::S3) : string
    {
        goto rH1mS;
        GqlpT:
        return trim($this->SXR9x, '/') . '/' . $D_Z4Z;
        goto nqFvr;
        HshEG:
        xOaOa:
        goto GqlpT;
        vj0zT:
        if (!$this->HTAsb) {
            goto xOaOa;
        }
        goto x84I7;
        lm0Z4:
        epO1M:
        goto NEcuY;
        NEcuY:
        if (!(!empty($this->Umyol) && !empty($this->QscF0))) {
            goto aXKph;
        }
        goto aVMps;
        DpAb0:
        WP_Rr:
        goto sb81q;
        aVMps:
        return $this->mzI4dNmpkoi($D_Z4Z);
        goto MKfXR;
        x84I7:
        return trim($this->jKfln, '/') . '/' . $D_Z4Z;
        goto HshEG;
        MKfXR:
        aXKph:
        goto vj0zT;
        rH1mS:
        if (!$D_Z4Z instanceof OWEQTdXGAAFta) {
            goto WP_Rr;
        }
        goto VA5iI;
        VA5iI:
        $D_Z4Z = $D_Z4Z->getAttribute('filename');
        goto DpAb0;
        sb81q:
        if (!($E6W0h === PdN71mQX1JeZG::LOCAL)) {
            goto epO1M;
        }
        goto QTYcG;
        QTYcG:
        return config('upload.home') . '/' . $D_Z4Z;
        goto lm0Z4;
        nqFvr:
    }
    public function resolveThumbnail(OWEQTdXGAAFta $D_Z4Z) : string
    {
        goto MTIok;
        zTP9k:
        return $this->url($gYP4D, $D_Z4Z->getAttribute('driver'));
        goto U2kge;
        U2kge:
        c9qHo:
        goto CGkLU;
        Ttr6Z:
        aUJae:
        goto UvvFn;
        CGkLU:
        if (!$D_Z4Z->getAttribute('thumbnail_id')) {
            goto wSox6;
        }
        goto I4sPp;
        R_sCZ:
        if (!$gYP4D) {
            goto c9qHo;
        }
        goto zTP9k;
        oScTr:
        return $this->resolvePath($hBD7b, $hBD7b->getAttribute('driver'));
        goto Ttr6Z;
        Sw1Q8:
        iLgpt:
        goto eoLBn;
        lV_t4:
        if (!$D_Z4Z instanceof UG34Yjmf7IsbQ) {
            goto iLgpt;
        }
        goto r5BFC;
        MTIok:
        $gYP4D = $D_Z4Z->getAttribute('thumbnail');
        goto R_sCZ;
        r5BFC:
        return $this->resolvePath($D_Z4Z, $D_Z4Z->getAttribute('driver'));
        goto Sw1Q8;
        xXT5F:
        GgeJR:
        goto Tx4bU;
        I4sPp:
        $hBD7b = UG34Yjmf7IsbQ::find($D_Z4Z->getAttribute('thumbnail_id'));
        goto YDZVk;
        eoLBn:
        if (!$D_Z4Z instanceof OrjVhA5InRPZV) {
            goto GgeJR;
        }
        goto rfXhK;
        YDZVk:
        if (!$hBD7b) {
            goto aUJae;
        }
        goto oScTr;
        Tx4bU:
        return '';
        goto wrxj2;
        UvvFn:
        wSox6:
        goto lV_t4;
        rfXhK:
        return asset('/img/pdf-preview.svg');
        goto xXT5F;
        wrxj2:
    }
    private function url($NSF8Y, $E6W0h)
    {
        goto y3z8N;
        gEloY:
        return config('upload.home') . '/' . $NSF8Y;
        goto ELjI8;
        ELjI8:
        OiKto:
        goto EnlyD;
        EnlyD:
        return $this->resolvePath($NSF8Y);
        goto uu1Bu;
        y3z8N:
        if (!($E6W0h == PdN71mQX1JeZG::LOCAL)) {
            goto OiKto;
        }
        goto gEloY;
        uu1Bu:
    }
    private function mzI4dNmpkoi($NSF8Y)
    {
        goto DbfZ_;
        DYDXR:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto CMEwd;
        jwKaV:
        return $uoR37->getSignedUrl($this->jKfln . '/' . $NSF8Y, $qtOW7);
        goto F8Hit;
        x834s:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto PrEQs;
        CMEwd:
        vCfIc:
        goto aClZ7;
        JI1Qu:
        $uoR37 = new UrlSigner($this->Umyol, $this->GRsEs->path($this->QscF0));
        goto jwKaV;
        aClZ7:
        $qtOW7 = now()->addMinutes(60)->timestamp;
        goto JI1Qu;
        PrEQs:
        je0FD:
        goto ROg0g;
        DbfZ_:
        if (!(strpos($NSF8Y, 'https://') === 0)) {
            goto je0FD;
        }
        goto x834s;
        ROg0g:
        if (!(strpos($NSF8Y, 'm3u8') !== false)) {
            goto vCfIc;
        }
        goto DYDXR;
        F8Hit:
    }
    public function resolvePathForHlsVideo(N1wF7eNF4lYgo $JfLWA, $rkKq3 = false) : string
    {
        goto l515L;
        nTP7T:
        N_8Rm:
        goto PRGSf;
        l515L:
        if ($JfLWA->getAttribute('hls_path')) {
            goto N_8Rm;
        }
        goto jPFgh;
        PRGSf:
        return $this->jKfln . '/' . $JfLWA->getAttribute('hls_path');
        goto B5D7p;
        jPFgh:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto nTP7T;
        B5D7p:
    }
    public function resolvePathForHlsVideos()
    {
        goto KjFkR;
        vkm9k:
        return [$y0CDv, $qtOW7];
        goto SLE0_;
        s4oh5:
        $QPQJ3 = $this->jKfln . '/v2/hls/';
        goto t0r2j;
        t0r2j:
        $VzoiW = json_encode(['Statement' => [['Resource' => sprintf('%s*', $QPQJ3), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $qtOW7]]]]]);
        goto apWIz;
        KjFkR:
        $qtOW7 = now()->addDays(3)->timestamp;
        goto s4oh5;
        z_Xye:
        $y0CDv = $jnPgI->getSignedCookie(['key_pair_id' => $this->Umyol, 'private_key' => $this->GRsEs->path($this->QscF0), 'policy' => $VzoiW]);
        goto vkm9k;
        apWIz:
        $jnPgI = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto z_Xye;
        SLE0_:
    }
}
