<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
final class R9h2iDidHZRXb
{
    private $EBMt5;
    private $ihqbk;
    private $Lrwlv;
    public function __construct(string $E6K8y, string $buCIM, Filesystem $AhP23)
    {
        goto Uk6xt;
        F8otZ:
        $this->ihqbk = $buCIM;
        goto KZRKN;
        KZRKN:
        $this->Lrwlv = $AhP23;
        goto zQRCE;
        Uk6xt:
        $this->EBMt5 = $E6K8y;
        goto F8otZ;
        zQRCE:
    }
    public function mnYAHv6SWa7(Yn8aWzKzROkno $LKVOP) : string
    {
        goto IlUQ1;
        IlUQ1:
        if (!(GTmWxMidiCuj0::S3 == $LKVOP->getAttribute('driver'))) {
            goto XdIKq;
        }
        goto TNl2n;
        SvbiT:
        XdIKq:
        goto WR_Qw;
        TNl2n:
        return 's3://' . $this->EBMt5 . '/' . $LKVOP->getAttribute('filename');
        goto SvbiT;
        WR_Qw:
        return $this->Lrwlv->url($LKVOP->getAttribute('filename'));
        goto mvjKr;
        mvjKr:
    }
    public function mUl8sXZE7Vb(?string $f6JTu) : ?string
    {
        goto qnZ6v;
        qcL6l:
        if (!dwzlG($f6JTu, $this->EBMt5)) {
            goto szufY;
        }
        goto sgXlC;
        V4rUx:
        mIKSM:
        goto legeA;
        sgXlC:
        $J9IgU = parse_url($f6JTu, PHP_URL_PATH);
        goto NIJc3;
        d5mtr:
        szufY:
        goto V4rUx;
        NIJc3:
        return 's3://' . $this->EBMt5 . '/' . ltrim($J9IgU, '/');
        goto d5mtr;
        legeA:
        return null;
        goto k1FDh;
        qnZ6v:
        if (!$f6JTu) {
            goto mIKSM;
        }
        goto qcL6l;
        k1FDh:
    }
    public function m1SSZoFHCOG(string $J9IgU) : string
    {
        return 's3://' . $this->EBMt5 . '/' . $J9IgU;
    }
}
