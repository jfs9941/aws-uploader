<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\SRErb8bXZXjuL;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Core\PvOVRr4EuSa8e;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
final class K2TtTNcFSFguA implements SRErb8bXZXjuL
{
    private $SZN1N;
    private $KkF8l;
    public $ptqO2;
    private $kaeoS;
    private $wyJoc;
    private $EaJ_d;
    public function __construct($FF8zF, $qL78n, $nSaGr, $f9_ha, $ZdGSn, $t9atP)
    {
        goto rceml;
        hFBR4:
        $this->wyJoc = $ZdGSn;
        goto falWY;
        jIH7l:
        $this->KkF8l = $qL78n;
        goto mrUf5;
        EgC9N:
        $this->kaeoS = $f9_ha;
        goto hFBR4;
        mrUf5:
        $this->ptqO2 = $nSaGr;
        goto EgC9N;
        rceml:
        $this->EaJ_d = $t9atP;
        goto ES1Il;
        ES1Il:
        $this->SZN1N = $FF8zF;
        goto jIH7l;
        falWY:
    }
    public function resolvePath($G2mX1, $n8L3v = Pj539Ru5gyMbt::S3) : string
    {
        goto U6JZk;
        lGsVC:
        return trim($this->ptqO2, '/') . '/' . $G2mX1;
        goto ZN8qI;
        wuSmZ:
        return config('upload.home') . '/' . $G2mX1;
        goto o_GxA;
        Ysv3Z:
        if (!($n8L3v === Pj539Ru5gyMbt::LOCAL)) {
            goto YSxQp;
        }
        goto wuSmZ;
        o_GxA:
        YSxQp:
        goto yajR9;
        yajR9:
        if (!(!empty($this->kaeoS) && !empty($this->wyJoc))) {
            goto IqutY;
        }
        goto TaEq_;
        TaEq_:
        return $this->m2SxjKsDJOz($G2mX1);
        goto mgyuM;
        q7VOR:
        return trim($this->KkF8l, '/') . '/' . $G2mX1;
        goto TVULM;
        ZN8qI:
        b3Nv1:
        goto q7VOR;
        ifGuh:
        $G2mX1 = $G2mX1->getAttribute('filename');
        goto CfqDR;
        kXw12:
        if (!$this->SZN1N) {
            goto b3Nv1;
        }
        goto lGsVC;
        U6JZk:
        if (!$G2mX1 instanceof NCmZ7rMVMWyvC) {
            goto dmaiL;
        }
        goto ifGuh;
        mgyuM:
        IqutY:
        goto kXw12;
        CfqDR:
        dmaiL:
        goto Ysv3Z;
        TVULM:
    }
    public function resolveThumbnail(NCmZ7rMVMWyvC $G2mX1) : string
    {
        goto JoLlN;
        v1IAo:
        MhP6E:
        goto X1eFF;
        aEOmS:
        if (!$Y4sj7) {
            goto CGktA;
        }
        goto ZjKzb;
        fZ5Fl:
        if (!$G2mX1->getAttribute('thumbnail_id')) {
            goto KNIeJ;
        }
        goto ZlbCL;
        p2iAv:
        return $this->resolvePath($G2mX1, $G2mX1->getAttribute('driver'));
        goto v1IAo;
        XI83h:
        return asset('/img/pdf-preview.svg');
        goto jxcwN;
        X1eFF:
        if (!$G2mX1 instanceof PvOVRr4EuSa8e) {
            goto pdp15;
        }
        goto XI83h;
        Rz2SK:
        CGktA:
        goto pEgen;
        pEgen:
        KNIeJ:
        goto W3dIt;
        JoLlN:
        $NHlhh = $G2mX1->getAttribute('thumbnail');
        goto EOBmK;
        jxcwN:
        pdp15:
        goto yeQVT;
        S6GBu:
        vtUaF:
        goto fZ5Fl;
        ZjKzb:
        return $this->resolvePath($Y4sj7, $Y4sj7->getAttribute('driver'));
        goto Rz2SK;
        W3dIt:
        if (!$G2mX1 instanceof A9olNyGXhDJnA) {
            goto MhP6E;
        }
        goto p2iAv;
        ZlbCL:
        $Y4sj7 = A9olNyGXhDJnA::find($G2mX1->getAttribute('thumbnail_id'));
        goto aEOmS;
        yeQVT:
        return '';
        goto l_1Ab;
        lu30u:
        return $this->url($NHlhh, $G2mX1->getAttribute('driver'));
        goto S6GBu;
        EOBmK:
        if (!$NHlhh) {
            goto vtUaF;
        }
        goto lu30u;
        l_1Ab:
    }
    private function url($L5bJW, $n8L3v)
    {
        goto cCm9B;
        cCm9B:
        if (!($n8L3v == Pj539Ru5gyMbt::LOCAL)) {
            goto tiO70;
        }
        goto L36nv;
        eS0bZ:
        return $this->resolvePath($L5bJW);
        goto UH6nC;
        jJ5mX:
        tiO70:
        goto eS0bZ;
        L36nv:
        return config('upload.home') . '/' . $L5bJW;
        goto jJ5mX;
        UH6nC:
    }
    private function m2SxjKsDJOz($L5bJW)
    {
        goto P3TrE;
        FpUD0:
        quy4I:
        goto izTG0;
        rVI9e:
        $z1Jf_ = new UrlSigner($this->kaeoS, $this->EaJ_d->path($this->wyJoc));
        goto gmOkq;
        GruQ9:
        $AeQKH = now()->addMinutes(60)->timestamp;
        goto rVI9e;
        FcUql:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto LyduW;
        LyduW:
        k0ZYb:
        goto GruQ9;
        P3TrE:
        if (!(strpos($L5bJW, 'https://') === 0)) {
            goto quy4I;
        }
        goto t3o56;
        izTG0:
        if (!(strpos($L5bJW, 'm3u8') !== false)) {
            goto k0ZYb;
        }
        goto FcUql;
        gmOkq:
        return $z1Jf_->getSignedUrl($this->ptqO2 . '/' . $L5bJW, $AeQKH);
        goto coUTz;
        t3o56:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto FpUD0;
        coUTz:
    }
    public function resolvePathForHlsVideo(WI5WSPGRr1b2t $hgsqV, $sQJWZ = false) : string
    {
        goto e08Cd;
        e08Cd:
        if ($hgsqV->getAttribute('hls_path')) {
            goto C09Kv;
        }
        goto X60sn;
        CnARe:
        C09Kv:
        goto h5ioR;
        X60sn:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto CnARe;
        h5ioR:
        return $this->ptqO2 . '/' . $hgsqV->getAttribute('hls_path');
        goto C2W_t;
        C2W_t:
    }
    public function resolvePathForHlsVideos()
    {
        goto THkh4;
        QVnQ1:
        $wyiQq = json_encode(['Statement' => [['Resource' => sprintf('%s*', $Fu07t), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $AeQKH]]]]]);
        goto wqeze;
        THkh4:
        $AeQKH = now()->addDays(3)->timestamp;
        goto gbRNi;
        EXAz3:
        return [$zj9z6, $AeQKH];
        goto ApU6X;
        YiZAu:
        $zj9z6 = $g7HW2->getSignedCookie(['key_pair_id' => $this->kaeoS, 'private_key' => $this->EaJ_d->path($this->wyJoc), 'policy' => $wyiQq]);
        goto EXAz3;
        gbRNi:
        $Fu07t = $this->ptqO2 . '/v2/hls/';
        goto QVnQ1;
        wqeze:
        $g7HW2 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto YiZAu;
        ApU6X:
    }
}
