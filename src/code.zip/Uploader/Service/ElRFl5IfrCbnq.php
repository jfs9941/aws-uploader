<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\Ijay4AiPvrqAE;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Core\DrXBch7yBj5qf;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
final class ElRFl5IfrCbnq implements Ijay4AiPvrqAE
{
    private $NOUNC;
    private $HA3Xf;
    public $jzcxd;
    private $U4Jsm;
    private $hNn3D;
    private $Celh5;
    public function __construct($SG_p5, $wz45B, $U4uK2, $lsFLe, $ibMv2, $clScT)
    {
        goto aIOvp;
        IprBP:
        $this->U4Jsm = $lsFLe;
        goto ZaigY;
        BhnvH:
        $this->jzcxd = $U4uK2;
        goto IprBP;
        Pwshr:
        $this->HA3Xf = $wz45B;
        goto BhnvH;
        Epmvh:
        $this->NOUNC = $SG_p5;
        goto Pwshr;
        ZaigY:
        $this->hNn3D = $ibMv2;
        goto HCj2o;
        aIOvp:
        $this->Celh5 = $clScT;
        goto Epmvh;
        HCj2o:
    }
    public function resolvePath($tzY18, $dHaKA = Rf7fPQasmK9R3::S3) : string
    {
        goto UtRtT;
        s5k1Y:
        return trim($this->jzcxd, '/') . '/' . $tzY18;
        goto ip0TM;
        y5d1A:
        aEzLZ:
        goto x0WVm;
        jgq26:
        Pix5H:
        goto IIRcR;
        x0WVm:
        if (!(!empty($this->U4Jsm) && !empty($this->hNn3D))) {
            goto VKpRQ;
        }
        goto Kg0kI;
        aNLAF:
        return config('upload.home') . '/' . $tzY18;
        goto y5d1A;
        ip0TM:
        fETKB:
        goto SzXBv;
        NoXhC:
        $tzY18 = $tzY18->getAttribute('filename');
        goto jgq26;
        IIRcR:
        if (!($dHaKA === Rf7fPQasmK9R3::LOCAL)) {
            goto aEzLZ;
        }
        goto aNLAF;
        UtRtT:
        if (!$tzY18 instanceof ZZfsW9KHWsMrx) {
            goto Pix5H;
        }
        goto NoXhC;
        Kg0kI:
        return $this->mHr3hZon2L0($tzY18);
        goto gjIIi;
        Xe5KL:
        if (!$this->NOUNC) {
            goto fETKB;
        }
        goto s5k1Y;
        SzXBv:
        return trim($this->HA3Xf, '/') . '/' . $tzY18;
        goto DxPQ0;
        gjIIi:
        VKpRQ:
        goto Xe5KL;
        DxPQ0:
    }
    public function resolveThumbnail(ZZfsW9KHWsMrx $tzY18) : string
    {
        goto dFhht;
        SIRV_:
        if (!$tzY18 instanceof DrXBch7yBj5qf) {
            goto urQ77;
        }
        goto oqLoa;
        ZWW7T:
        paJId:
        goto SIRV_;
        GL0OZ:
        urQ77:
        goto kkzq3;
        t5RvR:
        MwwwL:
        goto iZSRu;
        i9rzA:
        if (!$tzY18 instanceof FmmY71eXk0D8U) {
            goto paJId;
        }
        goto WTRrQ;
        dFhht:
        $th60a = $tzY18->getAttribute('thumbnail');
        goto OXGWQ;
        iZSRu:
        if (!$tzY18->getAttribute('thumbnail_id')) {
            goto evbuq;
        }
        goto wAp6_;
        wAp6_:
        $gVvnZ = FmmY71eXk0D8U::find($tzY18->getAttribute('thumbnail_id'));
        goto LpQXn;
        kkzq3:
        return '';
        goto cQfS2;
        LpQXn:
        if (!$gVvnZ) {
            goto LSQlm;
        }
        goto h7cYf;
        WTRrQ:
        return $this->resolvePath($tzY18, $tzY18->getAttribute('driver'));
        goto ZWW7T;
        OXGWQ:
        if (!$th60a) {
            goto MwwwL;
        }
        goto d2XvG;
        oqLoa:
        return asset('/img/pdf-preview.svg');
        goto GL0OZ;
        QQwde:
        LSQlm:
        goto NQvzH;
        NQvzH:
        evbuq:
        goto i9rzA;
        d2XvG:
        return $this->url($th60a, $tzY18->getAttribute('driver'));
        goto t5RvR;
        h7cYf:
        return $this->resolvePath($gVvnZ, $gVvnZ->getAttribute('driver'));
        goto QQwde;
        cQfS2:
    }
    private function url($liQkG, $dHaKA)
    {
        goto KTbjq;
        P2jB9:
        return $this->resolvePath($liQkG);
        goto vOBaN;
        lCOMW:
        return config('upload.home') . '/' . $liQkG;
        goto ktf1t;
        KTbjq:
        if (!($dHaKA == Rf7fPQasmK9R3::LOCAL)) {
            goto hNxHT;
        }
        goto lCOMW;
        ktf1t:
        hNxHT:
        goto P2jB9;
        vOBaN:
    }
    private function mHr3hZon2L0($liQkG)
    {
        goto oocso;
        FJPXf:
        $bgwpm = new UrlSigner($this->U4Jsm, $this->Celh5->path($this->hNn3D));
        goto cIqq9;
        eCAum:
        fdemm:
        goto igPmA;
        mr10G:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto gP987;
        igPmA:
        if (!(strpos($liQkG, 'm3u8') !== false)) {
            goto eEZHz;
        }
        goto mr10G;
        Ao8Vj:
        $WQ3h6 = now()->addMinutes(60)->timestamp;
        goto FJPXf;
        BitSX:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto eCAum;
        cIqq9:
        return $bgwpm->getSignedUrl($this->jzcxd . '/' . $liQkG, $WQ3h6);
        goto Kh2ZR;
        oocso:
        if (!(strpos($liQkG, 'https://') === 0)) {
            goto fdemm;
        }
        goto BitSX;
        gP987:
        eEZHz:
        goto Ao8Vj;
        Kh2ZR:
    }
    public function resolvePathForHlsVideo(IvT3V5jT5KEaA $IrxWj, $yPpDu = false) : string
    {
        goto c4ZOZ;
        O8orc:
        LBJvv:
        goto GK9kI;
        KjuU_:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto O8orc;
        c4ZOZ:
        if ($IrxWj->getAttribute('hls_path')) {
            goto LBJvv;
        }
        goto KjuU_;
        GK9kI:
        return $this->jzcxd . '/' . $IrxWj->getAttribute('hls_path');
        goto gs1Un;
        gs1Un:
    }
    public function resolvePathForHlsVideos()
    {
        goto vYwAl;
        FSU3M:
        $yoeCT = $akzKT->getSignedCookie(['key_pair_id' => $this->U4Jsm, 'private_key' => $this->Celh5->path($this->hNn3D), 'policy' => $gPJ7o]);
        goto Bvqzb;
        ErPU8:
        $akzKT = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto FSU3M;
        BMooz:
        $gPJ7o = json_encode(['Statement' => [['Resource' => sprintf('%s*', $vCmZt), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $WQ3h6]]]]]);
        goto ErPU8;
        Bvqzb:
        return [$yoeCT, $WQ3h6];
        goto qNtOA;
        vYwAl:
        $WQ3h6 = now()->addDays(3)->timestamp;
        goto hi5UI;
        hi5UI:
        $vCmZt = $this->jzcxd . '/v2/hls/';
        goto BMooz;
        qNtOA:
    }
}
