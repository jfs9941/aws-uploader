<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\CxLspzxS91nUL;
use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Core\Observer\LoxzkrUyn5kRt;
use Jfs\Uploader\Core\Observer\ZzUGksp4JHo6t;
use Jfs\Uploader\Core\DPPVKylVXE4k4;
use Jfs\Uploader\Core\LJgttSC2SO5Qb;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Uploader\Exception\TvagaDpTwJZ4h;
use Jfs\Uploader\Exception\HAf99Vtg3teX9;
use Jfs\Uploader\Service\FileResolver\Izd3tOHzlJ2qv;
use Ramsey\Uuid\Uuid;
final class IsJEOSgV8mPOx
{
    private $k147L;
    private $Lrwlv;
    private $Vhcrn;
    public function __construct($wF26G, $AhP23, $Klx1U)
    {
        goto i3vbu;
        i3vbu:
        $this->k147L = $wF26G;
        goto l1CvV;
        l1CvV:
        $this->Lrwlv = $AhP23;
        goto bJNVm;
        bJNVm:
        $this->Vhcrn = $Klx1U;
        goto HFvnR;
        HFvnR:
    }
    public function mN7eQARIGto($wyHtt)
    {
        goto mK0QS;
        mK0QS:
        if (!$wyHtt instanceof SingleUploadInterface) {
            goto csh_s;
        }
        goto RRVqG;
        bQXNA:
        csh_s:
        goto Cv7Wt;
        RRVqG:
        $Day_X = $wyHtt->getFile();
        goto n4wxH;
        n4wxH:
        return $this->mgfgxluJman($Day_X->extension(), GTmWxMidiCuj0::S3, null, $wyHtt->options());
        goto bQXNA;
        Cv7Wt:
        return $this->mgfgxluJman($wyHtt['file_extension'], 's3' === $wyHtt['driver'] ? GTmWxMidiCuj0::S3 : GTmWxMidiCuj0::LOCAL);
        goto rsRH0;
        rsRH0:
    }
    public function mzL9TaONfCV(string $mfjeD)
    {
        goto SJAaJ;
        jTTVL:
        $rQ18B->setRawAttributes($v17Df->getAttributes());
        goto c5Sjr;
        SJAaJ:
        $v17Df = config('upload.attachment_model')::findOrFail($mfjeD);
        goto MjTAu;
        JP6Hr:
        $rQ18B->exists = true;
        goto jTTVL;
        MjTAu:
        $rQ18B = $this->mgfgxluJman($v17Df->getAttribute('type'), $v17Df->getAttribute('driver'), $v17Df->getAttribute('id'));
        goto JP6Hr;
        c5Sjr:
        return $rQ18B;
        goto XvzvI;
        XvzvI:
    }
    public function mpQZT6Vp0sV(string $GQVHx) : CxLspzxS91nUL
    {
        goto Je1iK;
        iFIi5:
        $uJKYp = json_decode($kVIaY, true);
        goto Xo1mk;
        zaENs:
        return $this->mgfgxluJman($xyipk->Qz2nr, $xyipk->m7yPyvn12Q1(), $xyipk->filename);
        goto Jnhuz;
        Xo1mk:
        if (!$uJKYp) {
            goto LZQaf;
        }
        goto dS8U2;
        wfSIL:
        throw new TvagaDpTwJZ4h('metadata file not found');
        goto dh2x0;
        Jnhuz:
        LZQaf:
        goto wfSIL;
        Je1iK:
        $kVIaY = $this->Lrwlv->get($GQVHx);
        goto EC5Oq;
        dS8U2:
        $xyipk = LJgttSC2SO5Qb::mKduiIpARYo($uJKYp);
        goto zaENs;
        TYROr:
        Xk7ch:
        goto iFIi5;
        uU8M4:
        $kVIaY = $this->Vhcrn->get($GQVHx);
        goto TYROr;
        EC5Oq:
        if ($kVIaY) {
            goto Xk7ch;
        }
        goto uU8M4;
        dh2x0:
    }
    private function mgfgxluJman(string $A7wHd, $r2Cq9, ?string $mfjeD = null, array $FiE4q = [])
    {
        goto LvAf7;
        ArzyO:
        throw new HAf99Vtg3teX9("not support file type {$A7wHd}");
        goto Y_A8u;
        jfYDp:
        qb4XF:
        goto DAxhI;
        LvAf7:
        $mfjeD = $mfjeD ?? Uuid::uuid4()->getHex()->toString();
        goto fyt3H;
        q0V2Y:
        E35xN:
        goto ArzyO;
        cL1hO:
        foreach ($this->k147L as $DngCm) {
            goto rp2m7;
            ANuy7:
            syhkI:
            goto lPamu;
            rp2m7:
            if (!$DngCm->mfyfR1AYL8M($rVzUN)) {
                goto syhkI;
            }
            goto zOZIV;
            lPamu:
            CGhO1:
            goto ZIfjO;
            zOZIV:
            return $rVzUN->initLocation($DngCm->mCnkSwB0bhR($rVzUN));
            goto ANuy7;
            ZIfjO:
        }
        goto q0V2Y;
        nfe8K:
        $rVzUN->mUpiDytTDuT(new ZzUGksp4JHo6t($rVzUN, $this->Vhcrn, $FiE4q));
        goto cL1hO;
        aMUpO:
        FcQvr:
        goto jfYDp;
        fyt3H:
        switch ($A7wHd) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $rVzUN = DsyQbNiy8VgJG::createFromScratch($mfjeD, $A7wHd);
                goto qb4XF;
            case 'mp4':
            case 'mov':
                $rVzUN = ZSB2cdrwtZpmk::createFromScratch($mfjeD, $A7wHd);
                goto qb4XF;
            case 'pdf':
                $rVzUN = DPPVKylVXE4k4::createFromScratch($mfjeD, $A7wHd);
                goto qb4XF;
            default:
                throw new HAf99Vtg3teX9("not support file type {$A7wHd}");
        }
        goto aMUpO;
        LHSK7:
        $rVzUN->mUpiDytTDuT(new LoxzkrUyn5kRt($rVzUN));
        goto nfe8K;
        DAxhI:
        $rVzUN = $rVzUN->mxdCrkCmezY($r2Cq9);
        goto LHSK7;
        Y_A8u:
    }
}
