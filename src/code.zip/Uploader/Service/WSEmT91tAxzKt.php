<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\LQJLoPxiuxgfZ;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Core\SK0zQTH7YFzcx;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
final class WSEmT91tAxzKt implements LQJLoPxiuxgfZ
{
    private $YsAXO;
    private $DdwJl;
    public $WnJ0H;
    private $b5qjV;
    private $i37oX;
    private $n8EBo;
    public function __construct($p2SEF, $JaDBl, $z0qFF, $g5aO5, $XtrR9, $gdQ3g)
    {
        goto py1So;
        aaPqD:
        $this->YsAXO = $p2SEF;
        goto PRJI_;
        py1So:
        $this->n8EBo = $gdQ3g;
        goto aaPqD;
        ZLQOe:
        $this->b5qjV = $g5aO5;
        goto CABbg;
        CABbg:
        $this->i37oX = $XtrR9;
        goto fwh_B;
        rTXVL:
        $this->WnJ0H = $z0qFF;
        goto ZLQOe;
        PRJI_:
        $this->DdwJl = $JaDBl;
        goto rTXVL;
        fwh_B:
    }
    public function resolvePath($zacay, $YKOlB = X4ZiOQdPeeHKI::S3) : string
    {
        goto ZAsrj;
        Ks4Oa:
        CFCVY:
        goto HCjBK;
        eZ4mo:
        return config('upload.home') . '/' . $zacay;
        goto Ks4Oa;
        iK22Q:
        $zacay = $zacay->getAttribute('filename');
        goto UhoWh;
        HCjBK:
        if (!(!empty($this->b5qjV) && !empty($this->i37oX))) {
            goto h8XKd;
        }
        goto IzDxE;
        mHzFk:
        if (!$this->YsAXO) {
            goto PoVHW;
        }
        goto Y8AXG;
        Y8AXG:
        return trim($this->WnJ0H, '/') . '/' . $zacay;
        goto sryKS;
        JdJfa:
        if (!($YKOlB === X4ZiOQdPeeHKI::LOCAL)) {
            goto CFCVY;
        }
        goto eZ4mo;
        IzDxE:
        return $this->mzlWNeXgEsx($zacay);
        goto x1xmm;
        ZAsrj:
        if (!$zacay instanceof AtQh9cRLX7xL8) {
            goto zsxW6;
        }
        goto iK22Q;
        UhoWh:
        zsxW6:
        goto JdJfa;
        hv13f:
        return trim($this->DdwJl, '/') . '/' . $zacay;
        goto XP5GX;
        sryKS:
        PoVHW:
        goto hv13f;
        x1xmm:
        h8XKd:
        goto mHzFk;
        XP5GX:
    }
    public function resolveThumbnail(AtQh9cRLX7xL8 $zacay) : string
    {
        goto UPm__;
        af81E:
        if (!$AmFHD) {
            goto Qjk3z;
        }
        goto Gylof;
        FGcoT:
        if (!$zacay instanceof SK0zQTH7YFzcx) {
            goto Z4EGH;
        }
        goto QKNHo;
        AGqCY:
        $AmFHD = KCmQR4pvm0dT3::find($zacay->getAttribute('thumbnail_id'));
        goto af81E;
        gpFg4:
        b3lC1:
        goto L_ft2;
        L_ft2:
        if (!$zacay instanceof KCmQR4pvm0dT3) {
            goto qtM8v;
        }
        goto Bm7sg;
        Bm7sg:
        return $this->resolvePath($zacay, $zacay->getAttribute('driver'));
        goto Z7wb6;
        FccBx:
        return '';
        goto YvHE6;
        Z7wb6:
        qtM8v:
        goto FGcoT;
        lxHNX:
        if (!$zacay->getAttribute('thumbnail_id')) {
            goto b3lC1;
        }
        goto AGqCY;
        UxqcG:
        aYoy3:
        goto lxHNX;
        PE9nc:
        Qjk3z:
        goto gpFg4;
        Gylof:
        return $this->resolvePath($AmFHD, $AmFHD->getAttribute('driver'));
        goto PE9nc;
        IYByx:
        if (!$X9APK) {
            goto aYoy3;
        }
        goto SWf4A;
        wzUTB:
        Z4EGH:
        goto FccBx;
        QKNHo:
        return asset('/img/pdf-preview.svg');
        goto wzUTB;
        UPm__:
        $X9APK = $zacay->getAttribute('thumbnail');
        goto IYByx;
        SWf4A:
        return $this->url($X9APK, $zacay->getAttribute('driver'));
        goto UxqcG;
        YvHE6:
    }
    private function url($lmTDq, $YKOlB)
    {
        goto ZblIF;
        TAvaO:
        return $this->resolvePath($lmTDq);
        goto Su_Nh;
        QigSG:
        return config('upload.home') . '/' . $lmTDq;
        goto tu051;
        ZblIF:
        if (!($YKOlB == X4ZiOQdPeeHKI::LOCAL)) {
            goto CQfXZ;
        }
        goto QigSG;
        tu051:
        CQfXZ:
        goto TAvaO;
        Su_Nh:
    }
    private function mzlWNeXgEsx($lmTDq)
    {
        goto YuMK9;
        YuMK9:
        if (!(strpos($lmTDq, 'https://') === 0)) {
            goto MqoS3;
        }
        goto xcjE0;
        hPeLq:
        $BE8_y = now()->addMinutes(60)->timestamp;
        goto HJiIx;
        xcjE0:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto nmfTp;
        vwk3D:
        DcWsD:
        goto hPeLq;
        fM8xT:
        return $F3dim->getSignedUrl($this->WnJ0H . '/' . $lmTDq, $BE8_y);
        goto P6K7C;
        nmfTp:
        MqoS3:
        goto cw7Rf;
        MpcmE:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto vwk3D;
        HJiIx:
        $F3dim = new UrlSigner($this->b5qjV, $this->n8EBo->path($this->i37oX));
        goto fM8xT;
        cw7Rf:
        if (!(strpos($lmTDq, 'm3u8') !== false)) {
            goto DcWsD;
        }
        goto MpcmE;
        P6K7C:
    }
    public function resolvePathForHlsVideo(UYo98bF5lKEmO $EVGvq, $r0jD0 = false) : string
    {
        goto navhS;
        Dq2L6:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto MPPaV;
        Iwnv1:
        return $this->WnJ0H . '/' . $EVGvq->getAttribute('hls_path');
        goto z4zGU;
        navhS:
        if ($EVGvq->getAttribute('hls_path')) {
            goto GtNeh;
        }
        goto Dq2L6;
        MPPaV:
        GtNeh:
        goto Iwnv1;
        z4zGU:
    }
    public function resolvePathForHlsVideos()
    {
        goto LrJvO;
        P06Mz:
        return [$RsGAv, $BE8_y];
        goto c3klv;
        LrJvO:
        $BE8_y = now()->addDays(3)->timestamp;
        goto J0SQu;
        dD27I:
        $rnhz3 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $l3DkB), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $BE8_y]]]]]);
        goto HB2Wk;
        HB2Wk:
        $yzL9z = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto WHWYD;
        WHWYD:
        $RsGAv = $yzL9z->getSignedCookie(['key_pair_id' => $this->b5qjV, 'private_key' => $this->n8EBo->path($this->i37oX), 'policy' => $rnhz3]);
        goto P06Mz;
        J0SQu:
        $l3DkB = $this->WnJ0H . '/v2/hls/';
        goto dD27I;
        c3klv:
    }
}
