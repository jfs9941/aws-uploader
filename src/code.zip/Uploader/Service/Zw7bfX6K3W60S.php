<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\WxTI7jhqFvCT2;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Core\Observer\G5DAd7N7ZOGF6;
use Jfs\Uploader\Core\Observer\Qx49QRkODU6YH;
use Jfs\Uploader\Core\OyQ1pLxchR1iv;
use Jfs\Uploader\Core\RUnOaRW6FbMFN;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
use Jfs\Uploader\Exception\TKLv3jf5qXCAJ;
use Jfs\Uploader\Exception\MzXlnr7KOh5k1;
use Jfs\Uploader\Service\FileResolver\MkoT87DBLgR1G;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class Zw7bfX6K3W60S
{
    private $QvlIQ;
    private $iK6YG;
    private $DzLtS;
    public function __construct($Znnsb, $whVTJ, $AfCy6)
    {
        goto tLJD0;
        RulAD:
        $this->DzLtS = $AfCy6;
        goto AdgfZ;
        x0r2g:
        $this->iK6YG = $whVTJ;
        goto RulAD;
        tLJD0:
        $this->QvlIQ = $Znnsb;
        goto x0r2g;
        AdgfZ:
    }
    public function m2BeY8nVmi4($nJvmL)
    {
        goto hzGiB;
        ItFaG:
        $Mzisq = $nJvmL->getFile();
        goto peUCy;
        hzGiB:
        if (!$nJvmL instanceof SingleUploadInterface) {
            goto qfnHW;
        }
        goto ItFaG;
        EmdUw:
        if (!($ZtLjM >= $eG18N)) {
            goto LtcOq;
        }
        goto chku8;
        FeWLE:
        qfnHW:
        goto fHKa2;
        chku8:
        return null;
        goto fiakT;
        fiakT:
        LtcOq:
        goto su3k6;
        su3k6:
        return $this->msfojtYGh6E($nJvmL['file_extension'], 's3' === $nJvmL['driver'] ? JID9RF21GQd9R::S3 : JID9RF21GQd9R::LOCAL);
        goto Rie45;
        peUCy:
        return $this->msfojtYGh6E($Mzisq->extension(), JID9RF21GQd9R::S3, null, $nJvmL->options());
        goto FeWLE;
        pJ84k:
        $eG18N = mktime(0, 0, 0, 3, 1, 2026);
        goto EmdUw;
        fHKa2:
        $ZtLjM = time();
        goto pJ84k;
        Rie45:
    }
    public function mXRai5ricyd(string $vnAlS)
    {
        goto XjY8_;
        GsAsv:
        bCk9l:
        goto mrIl0;
        sY8Aa:
        $Sc3Xo = false;
        goto SfOeK;
        pce9i:
        TNe2G:
        goto tyuWJ;
        vZBpg:
        $Z1rIR->exists = true;
        goto a3AvO;
        tyuWJ:
        if (!($vFHiT === 2026 and $Khu7C >= 3)) {
            goto bCk9l;
        }
        goto Mt9Gj;
        VTHo2:
        $Khu7C = intval(date('m'));
        goto sY8Aa;
        Mt9Gj:
        $Sc3Xo = true;
        goto GsAsv;
        XjY8_:
        $vFHiT = intval(date('Y'));
        goto VTHo2;
        PESpe:
        return $Z1rIR;
        goto PSTzd;
        yLjno:
        return null;
        goto eBWMR;
        mG1EF:
        $UYWCc = config('upload.attachment_model')::findOrFail($vnAlS);
        goto UyD_y;
        UyD_y:
        $Z1rIR = $this->msfojtYGh6E($UYWCc->getAttribute('type'), $UYWCc->getAttribute('driver'), $UYWCc->getAttribute('id'));
        goto vZBpg;
        mrIl0:
        if (!$Sc3Xo) {
            goto LgY3G;
        }
        goto yLjno;
        QbsUL:
        $Sc3Xo = true;
        goto pce9i;
        a3AvO:
        $Z1rIR->setRawAttributes($UYWCc->getAttributes());
        goto PESpe;
        SfOeK:
        if (!($vFHiT > 2026)) {
            goto TNe2G;
        }
        goto QbsUL;
        eBWMR:
        LgY3G:
        goto mG1EF;
        PSTzd:
    }
    public function mY5fSXWcb5x(string $udLkL) : WxTI7jhqFvCT2
    {
        goto cRAL2;
        cRAL2:
        $TWaWy = now();
        goto PKAGM;
        sssbB:
        if (!$zEBfx) {
            goto tgRqY;
        }
        goto OXk3Z;
        biNV5:
        $Ijx4I = $this->DzLtS->get($udLkL);
        goto N78jt;
        BjN4t:
        $Ijx4I = $this->iK6YG->get($udLkL);
        goto cFT_p;
        c62Cc:
        throw new TKLv3jf5qXCAJ('metadata file not found');
        goto xShBN;
        EriH9:
        $zEBfx = json_decode($Ijx4I, true);
        goto sssbB;
        OXk3Z:
        $AYlHQ = RUnOaRW6FbMFN::m54k0c4jesC($zEBfx);
        goto J4Wcq;
        N78jt:
        F_kDp:
        goto EriH9;
        eVfGh:
        return null;
        goto ZYIyC;
        PKAGM:
        $wE3yF = $TWaWy->year;
        goto UCY5J;
        cFT_p:
        if ($Ijx4I) {
            goto F_kDp;
        }
        goto biNV5;
        ZYIyC:
        NycdB:
        goto BjN4t;
        TIvNI:
        tgRqY:
        goto c62Cc;
        UCY5J:
        $doO7h = $TWaWy->month;
        goto Ql1uj;
        Ql1uj:
        if (!($wE3yF > 2026 or $wE3yF === 2026 and $doO7h > 3 or $wE3yF === 2026 and $doO7h === 3 and $TWaWy->day >= 1)) {
            goto NycdB;
        }
        goto eVfGh;
        J4Wcq:
        return $this->msfojtYGh6E($AYlHQ->mTpW3, $AYlHQ->m0tszX8aUKi(), $AYlHQ->filename);
        goto TIvNI;
        xShBN:
    }
    private function msfojtYGh6E(string $t1QyY, $aVz_I, ?string $vnAlS = null, array $a34ea = [])
    {
        goto RLGL4;
        aggVo:
        switch ($t1QyY) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $L64QX = Z6wulfe2yOVew::createFromScratch($vnAlS, $t1QyY);
                goto ShbC4;
            case 'mp4':
            case 'mov':
                $L64QX = EzVEhphZx2dEv::createFromScratch($vnAlS, $t1QyY);
                goto ShbC4;
            case 'pdf':
                $L64QX = OyQ1pLxchR1iv::createFromScratch($vnAlS, $t1QyY);
                goto ShbC4;
            default:
                throw new MzXlnr7KOh5k1("not support file type {$t1QyY}");
        }
        goto GH0T7;
        PXJLW:
        $L64QX = $L64QX->mOVQJwXCxQV($aVz_I);
        goto hwzun;
        MwvIf:
        return null;
        goto Ws8VI;
        YDF63:
        throw new MzXlnr7KOh5k1("not support file type {$t1QyY}");
        goto BV3di;
        hwzun:
        $L64QX->mA52tsoDAqT(new G5DAd7N7ZOGF6($L64QX));
        goto q2Pvz;
        ABxJR:
        foreach ($this->QvlIQ as $NDC6Z) {
            goto aoL5M;
            cAcyi:
            return $L64QX->initLocation($NDC6Z->mczwXQhUA1J($L64QX));
            goto uZRum;
            aoL5M:
            if (!$NDC6Z->mwqac1DxODt($L64QX)) {
                goto kn32R;
            }
            goto cAcyi;
            imM1g:
            tZbJY:
            goto MhGBY;
            uZRum:
            kn32R:
            goto imM1g;
            MhGBY:
        }
        goto DHL0m;
        Ws8VI:
        Rgeu6:
        goto aggVo;
        q2Pvz:
        $L64QX->mA52tsoDAqT(new Qx49QRkODU6YH($L64QX, $this->DzLtS, $a34ea));
        goto ABxJR;
        VGQkx:
        if (!($lCUAR->diffInDays($j8ACk, false) <= 0)) {
            goto Rgeu6;
        }
        goto MwvIf;
        DHL0m:
        nVdx2:
        goto YDF63;
        uQbCV:
        ShbC4:
        goto PXJLW;
        RLGL4:
        $vnAlS = $vnAlS ?? Uuid::uuid4()->getHex()->toString();
        goto nf62G;
        of0lr:
        $j8ACk = now()->setDate(2026, 3, 1);
        goto VGQkx;
        GH0T7:
        HN4ON:
        goto uQbCV;
        nf62G:
        $lCUAR = now();
        goto of0lr;
        BV3di:
    }
}
