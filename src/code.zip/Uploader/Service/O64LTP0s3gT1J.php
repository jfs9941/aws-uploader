<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
use Illuminate\Contracts\Filesystem\Filesystem;
final class O64LTP0s3gT1J
{
    private $SmbHD;
    private $zQRVW;
    private $IaFSl;
    public function __construct(string $l286D, string $QkyZo, Filesystem $B27Pk)
    {
        goto M6Vy5;
        M6Vy5:
        $this->SmbHD = $l286D;
        goto vJfZ_;
        M7sP7:
        $this->IaFSl = $B27Pk;
        goto UWHKr;
        vJfZ_:
        $this->zQRVW = $QkyZo;
        goto M7sP7;
        UWHKr:
    }
    public function mgqwFmQ3edt(NRDoWGrbd9WhU $S8CpP) : string
    {
        goto dK1m2;
        dK1m2:
        if (!(Opdj0uZXaMJfa::S3 == $S8CpP->getAttribute('driver'))) {
            goto In0KW;
        }
        goto ak1RQ;
        ak1RQ:
        return 's3://' . $this->SmbHD . '/' . $S8CpP->getAttribute('filename');
        goto J0CsN;
        G3FTr:
        return $this->IaFSl->url($S8CpP->getAttribute('filename'));
        goto mCVo3;
        J0CsN:
        In0KW:
        goto G3FTr;
        mCVo3:
    }
    public function meCjKC5izfh(?string $IOBET) : ?string
    {
        goto pXrXv;
        dOOD9:
        By26W:
        goto YoQls;
        Mpjm7:
        if (!JhMEC($IOBET, $this->SmbHD)) {
            goto QCBQZ;
        }
        goto fcib2;
        YoQls:
        return null;
        goto ZrQ_N;
        fcib2:
        $lxbX3 = parse_url($IOBET, PHP_URL_PATH);
        goto uxOOT;
        uxOOT:
        return 's3://' . $this->SmbHD . '/' . ltrim($lxbX3, '/');
        goto QWkbm;
        pXrXv:
        if (!$IOBET) {
            goto By26W;
        }
        goto Mpjm7;
        QWkbm:
        QCBQZ:
        goto dOOD9;
        ZrQ_N:
    }
    public function mNNTgT6UPFH(string $lxbX3) : string
    {
        return 's3://' . $this->SmbHD . '/' . $lxbX3;
    }
}
