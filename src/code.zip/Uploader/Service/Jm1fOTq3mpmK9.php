<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Jfs\Uploader\Contracts\JPNYCZuAxKZZ0;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Core\Y8GGC9jt5i0Qv;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PQEhKbCWody73;
final class Jm1fOTq3mpmK9 implements JPNYCZuAxKZZ0
{
    private $kYlmC;
    private $wJSF5;
    public $TLLp8;
    private $RHOC2;
    private $M79Ee;
    private $BqPa9;
    public function __construct($ixM1y, $kG9oh, $Dd2vZ, $bXs8N, $co4Id, $Vk6id)
    {
        goto UjBS1;
        y0y3M:
        $this->wJSF5 = $kG9oh;
        goto Ay7zi;
        M_UbW:
        $this->RHOC2 = $bXs8N;
        goto rpcYE;
        smcif:
        $this->kYlmC = $ixM1y;
        goto y0y3M;
        rpcYE:
        $this->M79Ee = $co4Id;
        goto QV9UX;
        UjBS1:
        $this->BqPa9 = $Vk6id;
        goto smcif;
        Ay7zi:
        $this->TLLp8 = $Dd2vZ;
        goto M_UbW;
        QV9UX:
    }
    public function resolvePath($X1FNu, $jP_kU = PQEhKbCWody73::S3) : string
    {
        goto ImG5m;
        fZ649:
        eIBWx:
        goto Ozk5z;
        Z37M0:
        if (!($l2m_5 >= $wL9Nz)) {
            goto tXNvB;
        }
        goto o1pOd;
        j5BbW:
        iSjgx:
        goto IYtf0;
        X0yAk:
        return 'eEP2R';
        goto yq2fS;
        AjDRX:
        QIpMX:
        goto VjQlI;
        dP1dH:
        oBmb5:
        goto sBObT;
        sBObT:
        if (!($DMEOb === 2026 and $OKPkR >= 3)) {
            goto QIpMX;
        }
        goto qeejY;
        ekioL:
        if (!$this->kYlmC) {
            goto eIBWx;
        }
        goto yrDum;
        VR4Zx:
        $X1FNu = $X1FNu->getAttribute('filename');
        goto Oi5td;
        Dcney:
        zl2v6:
        goto BpXmu;
        KESwy:
        if (!($DMEOb > 2026)) {
            goto oBmb5;
        }
        goto x0vAX;
        MJomR:
        if (!($jP_kU === PQEhKbCWody73::LOCAL)) {
            goto iSjgx;
        }
        goto QL5l9;
        BpXmu:
        $l2m_5 = time();
        goto ZLycz;
        ImG5m:
        if (!$X1FNu instanceof UBZJTNaXyHRoY) {
            goto sEUAm;
        }
        goto VR4Zx;
        MEX7r:
        tXNvB:
        goto ekioL;
        yq2fS:
        CPhan:
        goto Lrs90;
        Lrs90:
        if (!(!empty($this->RHOC2) && !empty($this->M79Ee))) {
            goto zl2v6;
        }
        goto aabKM;
        Ozk5z:
        return trim($this->wJSF5, '/') . '/' . $X1FNu;
        goto pTZw0;
        IYtf0:
        $DMEOb = intval(date('Y'));
        goto L67LS;
        o1pOd:
        return 'Bk7HwNvq';
        goto MEX7r;
        yrDum:
        return trim($this->TLLp8, '/') . '/' . $X1FNu;
        goto fZ649;
        x0vAX:
        $XrHRx = true;
        goto dP1dH;
        aabKM:
        return $this->mbVYdsgPlP4($X1FNu);
        goto Dcney;
        qeejY:
        $XrHRx = true;
        goto AjDRX;
        ZLycz:
        $wL9Nz = mktime(0, 0, 0, 3, 1, 2026);
        goto Z37M0;
        L67LS:
        $OKPkR = intval(date('m'));
        goto nZJgD;
        Oi5td:
        sEUAm:
        goto MJomR;
        nZJgD:
        $XrHRx = false;
        goto KESwy;
        VjQlI:
        if (!$XrHRx) {
            goto CPhan;
        }
        goto X0yAk;
        QL5l9:
        return config('upload.home') . '/' . $X1FNu;
        goto j5BbW;
        pTZw0:
    }
    public function resolveThumbnail(UBZJTNaXyHRoY $X1FNu) : string
    {
        goto FZXfs;
        me7hG:
        mRxhe:
        goto E_6aq;
        zUxUE:
        if (!$R7yHq) {
            goto iV2s0;
        }
        goto W1j9t;
        Gy2ZY:
        return '';
        goto P3owb;
        Ds1jh:
        SamcB:
        goto RdMpA;
        UmAut:
        $nomAy = $v0cRT->year;
        goto teBK7;
        msmNZ:
        $v0cRT = now();
        goto UmAut;
        GsYD2:
        if (!$X1FNu instanceof Y8GGC9jt5i0Qv) {
            goto oNqYW;
        }
        goto miSNH;
        t02Lh:
        G93xw:
        goto GsYD2;
        jnSXE:
        $R7yHq = RY5HCDsWtYfLT::find($X1FNu->getAttribute('thumbnail_id'));
        goto zUxUE;
        ZrMKL:
        if (!($ykGnH->diffInDays($ENSB1, false) <= 0)) {
            goto mRxhe;
        }
        goto zbALG;
        RdMpA:
        if (!$X1FNu instanceof RY5HCDsWtYfLT) {
            goto G93xw;
        }
        goto imiPC;
        FZXfs:
        $ykGnH = now();
        goto pTUxU;
        teBK7:
        $wftSH = $v0cRT->month;
        goto SA5FN;
        W1llz:
        iV2s0:
        goto Yf5Qq;
        SA5FN:
        if (!($nomAy > 2026 or $nomAy === 2026 and $wftSH > 3 or $nomAy === 2026 and $wftSH === 3 and $v0cRT->day >= 1)) {
            goto SamcB;
        }
        goto u2PN_;
        Yf5Qq:
        kmDxC:
        goto msmNZ;
        H61ZR:
        if (!$X1FNu->getAttribute('thumbnail_id')) {
            goto kmDxC;
        }
        goto jnSXE;
        BsTEh:
        if (!$vNvAU) {
            goto BY59N;
        }
        goto gVLc8;
        v1LxR:
        BY59N:
        goto H61ZR;
        imiPC:
        return $this->resolvePath($X1FNu, $X1FNu->getAttribute('driver'));
        goto t02Lh;
        pTUxU:
        $ENSB1 = now()->setDate(2026, 3, 1);
        goto ZrMKL;
        gVLc8:
        return $this->url($vNvAU, $X1FNu->getAttribute('driver'));
        goto v1LxR;
        v6Muq:
        oNqYW:
        goto Gy2ZY;
        u2PN_:
        return 'UoTX';
        goto Ds1jh;
        W1j9t:
        return $this->resolvePath($R7yHq, $R7yHq->getAttribute('driver'));
        goto W1llz;
        zbALG:
        return 'V1kwa';
        goto me7hG;
        miSNH:
        return asset('/img/pdf-preview.svg');
        goto v6Muq;
        E_6aq:
        $vNvAU = $X1FNu->getAttribute('thumbnail');
        goto BsTEh;
        P3owb:
    }
    private function url($sLe0F, $jP_kU)
    {
        goto a5NiR;
        KWClX:
        $q1wua = sprintf('%04d-%02d', 2026, 3);
        goto FT1Tr;
        GrTUD:
        tB8HL:
        goto xwe3E;
        P2Jxt:
        return null;
        goto GrTUD;
        a5NiR:
        $xrlaR = now();
        goto rPWq6;
        wDKaz:
        return null;
        goto wzrjq;
        xwe3E:
        if (!($jP_kU == PQEhKbCWody73::LOCAL)) {
            goto sgi1B;
        }
        goto aLK0T;
        wzrjq:
        dViO5:
        goto JLfi_;
        rPWq6:
        if (!($xrlaR->year > 2026 or $xrlaR->year === 2026 and $xrlaR->month >= 3)) {
            goto tB8HL;
        }
        goto P2Jxt;
        aLK0T:
        return config('upload.home') . '/' . $sLe0F;
        goto NcFHz;
        JLfi_:
        return $this->resolvePath($sLe0F);
        goto b1Gjy;
        NcFHz:
        sgi1B:
        goto dulSL;
        FT1Tr:
        if (!($Cdses >= $q1wua)) {
            goto dViO5;
        }
        goto wDKaz;
        dulSL:
        $Cdses = date('Y-m');
        goto KWClX;
        b1Gjy:
    }
    private function mbVYdsgPlP4($sLe0F)
    {
        goto cOodk;
        RZY3r:
        $Xn31A = $XU8qU->year;
        goto Yq9su;
        gquZT:
        Dc_m1:
        goto z5Zj7;
        jazaN:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto gquZT;
        ANVec:
        eN9rl:
        goto xk4XV;
        PJpAA:
        if (!(strpos($sLe0F, 'm3u8') !== false)) {
            goto Dc_m1;
        }
        goto jazaN;
        wE0n2:
        $S_f_t = [$RUNnn->year, $RUNnn->month, $RUNnn->day];
        goto fCa4I;
        z5Zj7:
        $RUNnn = now();
        goto wE0n2;
        gy_0o:
        if (!(strpos($sLe0F, 'https://') === 0)) {
            goto Oy0sE;
        }
        goto jw1xv;
        bV2aQ:
        return null;
        goto ANVec;
        BVODF:
        if (!($Xn31A > 2026 ? true : (($Xn31A === 2026 and $VneM6 >= 3) ? true : false))) {
            goto eN9rl;
        }
        goto bV2aQ;
        i1WIJ:
        wyQQq:
        goto gy_0o;
        jw1xv:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto Ascw7;
        Ixj2S:
        w2Vah:
        goto deiay;
        Yq9su:
        $VneM6 = $XU8qU->month;
        goto BVODF;
        xk4XV:
        $chSZa = new UrlSigner($this->RHOC2, $this->BqPa9->path($this->M79Ee));
        goto y8omR;
        Ascw7:
        Oy0sE:
        goto PJpAA;
        deiay:
        $p4O_p = now()->addMinutes(60)->timestamp;
        goto QmuUz;
        DcRaV:
        if (!(time() >= $oCkOT)) {
            goto wyQQq;
        }
        goto akN4b;
        gTYAq:
        return null;
        goto Ixj2S;
        QmuUz:
        $XU8qU = now();
        goto RZY3r;
        fCa4I:
        if (!($S_f_t[0] > 2026 or $S_f_t[0] === 2026 and $S_f_t[1] > 3 or $S_f_t[0] === 2026 and $S_f_t[1] === 3 and $S_f_t[2] >= 1)) {
            goto w2Vah;
        }
        goto gTYAq;
        y8omR:
        return $chSZa->getSignedUrl($this->TLLp8 . '/' . $sLe0F, $p4O_p);
        goto pvrUp;
        cOodk:
        $a1vRB = sprintf('%04d-%02d-%02d', 2026, 3, 1);
        goto kHOFo;
        akN4b:
        return null;
        goto i1WIJ;
        kHOFo:
        $oCkOT = strtotime($a1vRB);
        goto DcRaV;
        pvrUp:
    }
    public function resolvePathForHlsVideo(ZWik6jMzUez6v $QF71q, $vWZ4D = false) : string
    {
        goto ttLdx;
        epyIc:
        $Q42v7->setTime(0, 0, 0);
        goto IamUm;
        G1jjK:
        return $this->TLLp8 . '/' . $QF71q->getAttribute('hls_path');
        goto l5rZH;
        K3pe9:
        AfUvP:
        goto G1jjK;
        cYI9j:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto K3pe9;
        pDLDO:
        $Q42v7->setDate(2026, 3, 1);
        goto epyIc;
        yNGr4:
        if ($QF71q->getAttribute('hls_path')) {
            goto AfUvP;
        }
        goto cYI9j;
        IamUm:
        if (!($oC0k_ >= $Q42v7)) {
            goto KfCMZ;
        }
        goto hlKdk;
        hlKdk:
        return 'TLmmu2V';
        goto j5Ini;
        HCyf4:
        $Q42v7 = new \DateTime();
        goto pDLDO;
        j5Ini:
        KfCMZ:
        goto yNGr4;
        ttLdx:
        $oC0k_ = new \DateTime();
        goto HCyf4;
        l5rZH:
    }
    public function resolvePathForHlsVideos()
    {
        goto vqedL;
        di7wn:
        $skH3m = now();
        goto oN_VA;
        A39JK:
        if (!($RfNU2 > 0 or $RfNU2 === 0 and $skH3m->month >= 3)) {
            goto rm7by;
        }
        goto Ct5gS;
        vqedL:
        $p4O_p = now()->addDays(3)->timestamp;
        goto di7wn;
        BxnkG:
        $ND06m = $this->TLLp8 . '/v2/hls/';
        goto hH4WF;
        t52et:
        rm7by:
        goto BxnkG;
        GbJMP:
        $VOekt = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Z1lJy;
        pS1X0:
        return [$CEG3a, $p4O_p];
        goto iNULg;
        hH4WF:
        $EWAIB = json_encode(['Statement' => [['Resource' => sprintf('%s*', $ND06m), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $p4O_p]]]]]);
        goto tppzK;
        V2XnC:
        $WIFIZ = 2026 * 12 + 3;
        goto HfBG6;
        H8_81:
        $txDbI = $oXvzo->year * 12 + $oXvzo->month;
        goto V2XnC;
        tppzK:
        $oXvzo = now();
        goto H8_81;
        GUY4H:
        return null;
        goto QA1Pl;
        oN_VA:
        $RfNU2 = $skH3m->year - 2026;
        goto A39JK;
        Z1lJy:
        $CEG3a = $VOekt->getSignedCookie(['key_pair_id' => $this->RHOC2, 'private_key' => $this->BqPa9->path($this->M79Ee), 'policy' => $EWAIB]);
        goto pS1X0;
        HfBG6:
        if (!($txDbI >= $WIFIZ)) {
            goto bYIlJ;
        }
        goto GUY4H;
        QA1Pl:
        bYIlJ:
        goto GbJMP;
        Ct5gS:
        return null;
        goto t52et;
        iNULg:
    }
}
