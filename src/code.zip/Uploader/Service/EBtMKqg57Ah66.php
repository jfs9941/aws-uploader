<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Core\IyqtwINobs6go;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
final class EBtMKqg57Ah66 implements TC3rpsU2GuKAE
{
    private $OY6sE;
    private $a1pUv;
    public $JOSB4;
    private $Q1kUc;
    private $gd0AM;
    private $HyJkj;
    public function __construct($IAYA1, $LjkIy, $onbIN, $Ub3li, $hA59V, $N7YvB)
    {
        goto Z291Y;
        qOGrn:
        $this->gd0AM = $hA59V;
        goto ot61d;
        j78a1:
        $this->Q1kUc = $Ub3li;
        goto qOGrn;
        Z291Y:
        $this->HyJkj = $N7YvB;
        goto Yuty3;
        Yfak6:
        $this->JOSB4 = $onbIN;
        goto j78a1;
        pkF_C:
        $this->a1pUv = $LjkIy;
        goto Yfak6;
        Yuty3:
        $this->OY6sE = $IAYA1;
        goto pkF_C;
        ot61d:
    }
    public function resolvePath($Y6vHu, $ewvCB = NYPGraEb3Ennl::S3) : string
    {
        goto hT97M;
        j0_ZV:
        if (!$this->OY6sE) {
            goto mjxp4;
        }
        goto aQjO7;
        ulvyp:
        $Y6vHu = $Y6vHu->getAttribute('filename');
        goto QY_lr;
        oqLzZ:
        mjxp4:
        goto frX2M;
        Ke7n8:
        if (!(!empty($this->Q1kUc) && !empty($this->gd0AM))) {
            goto Bp13n;
        }
        goto Gv0Wo;
        HeCb3:
        return route('home') . '/' . $Y6vHu;
        goto pn6tE;
        Gv0Wo:
        return $this->moxVz3FaKrw($Y6vHu);
        goto WMVau;
        frX2M:
        return trim($this->a1pUv, '/') . '/' . $Y6vHu;
        goto F3fzZ;
        pn6tE:
        zrh2W:
        goto Ke7n8;
        hT97M:
        if (!$Y6vHu instanceof LfWCTOqty2Slr) {
            goto OIn0i;
        }
        goto ulvyp;
        WMVau:
        Bp13n:
        goto j0_ZV;
        Tkm7x:
        if (!($ewvCB === NYPGraEb3Ennl::LOCAL)) {
            goto zrh2W;
        }
        goto HeCb3;
        QY_lr:
        OIn0i:
        goto Tkm7x;
        aQjO7:
        return trim($this->JOSB4, '/') . '/' . $Y6vHu;
        goto oqLzZ;
        F3fzZ:
    }
    public function resolveThumbnail(LfWCTOqty2Slr $Y6vHu) : string
    {
        goto JARPT;
        G4UOJ:
        nINGh:
        goto jdT03;
        ulbtG:
        if (!$Y6vHu instanceof IyqtwINobs6go) {
            goto jg_sH;
        }
        goto a3hsY;
        ugKMj:
        return $this->resolvePath($cc37y, $cc37y->getAttribute('driver'));
        goto oUWO1;
        aOSNK:
        return $this->url($O8BOu, $Y6vHu->getAttribute('driver'));
        goto llboQ;
        oUWO1:
        cT05y:
        goto G4UOJ;
        Hxaxz:
        if (!$Y6vHu->getAttribute('thumbnail_id')) {
            goto nINGh;
        }
        goto rZE3s;
        rZE3s:
        $cc37y = YPgQPiPQjMu1g::find($Y6vHu->getAttribute('thumbnail_id'));
        goto QGcUt;
        dWtM5:
        uRYL6:
        goto ulbtG;
        D3Qb5:
        jg_sH:
        goto EWT6L;
        JARPT:
        $O8BOu = $Y6vHu->pIIgF;
        goto I8HlX;
        GrNW2:
        return $this->resolvePath($Y6vHu, $Y6vHu->getAttribute('driver'));
        goto dWtM5;
        a3hsY:
        return asset('/img/pdf-preview.svg');
        goto D3Qb5;
        I8HlX:
        if (!$O8BOu) {
            goto A4OGa;
        }
        goto aOSNK;
        jdT03:
        if (!$Y6vHu instanceof YPgQPiPQjMu1g) {
            goto uRYL6;
        }
        goto GrNW2;
        EWT6L:
        return '';
        goto r_Ufg;
        llboQ:
        A4OGa:
        goto Hxaxz;
        QGcUt:
        if (!$cc37y) {
            goto cT05y;
        }
        goto ugKMj;
        r_Ufg:
    }
    private function url($TnwL2, $ewvCB)
    {
        goto pAPA1;
        Ymmsc:
        return route('home') . '/' . $TnwL2;
        goto I4Pc5;
        pAPA1:
        if (!($ewvCB == NYPGraEb3Ennl::LOCAL)) {
            goto c3qps;
        }
        goto Ymmsc;
        I4Pc5:
        c3qps:
        goto DDwcp;
        DDwcp:
        return $this->resolvePath($TnwL2);
        goto pWvcX;
        pWvcX:
    }
    private function moxVz3FaKrw($TnwL2)
    {
        goto Sv1k7;
        zLnkz:
        if (!(strpos($TnwL2, 'm3u8') !== false)) {
            goto ndyMa;
        }
        goto Fb20X;
        I7Hht:
        $U8imA = new UrlSigner($this->Q1kUc, $this->HyJkj->path($this->gd0AM));
        goto eTXX6;
        Sv1k7:
        if (!(strpos($TnwL2, 'https://') === 0)) {
            goto Dn8Sa;
        }
        goto XSRnz;
        eTXX6:
        return $U8imA->getSignedUrl($this->JOSB4 . '/' . $TnwL2, $zv7wW);
        goto iQa4T;
        LemY7:
        Dn8Sa:
        goto zLnkz;
        Fb20X:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto PLJ2Z;
        XSRnz:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto LemY7;
        PCZTX:
        $zv7wW = now()->addMinutes(60)->timestamp;
        goto I7Hht;
        PLJ2Z:
        ndyMa:
        goto PCZTX;
        iQa4T:
    }
    public function resolvePathForHlsVideo(SmhkgG6le5p0r $X0ufS, $TiZWw = false) : string
    {
        goto cNtHt;
        ofU1O:
        return $this->JOSB4 . '/' . $X0ufS->B9wma;
        goto EOi0H;
        cNtHt:
        if ($X0ufS->B9wma) {
            goto tOmcO;
        }
        goto QD2Kr;
        QD2Kr:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto O0QeU;
        O0QeU:
        tOmcO:
        goto ofU1O;
        EOi0H:
    }
    public function resolvePathForHlsVideos()
    {
        goto SBNs6;
        UVh3n:
        $E6JeN = json_encode(['Statement' => [['Resource' => sprintf('%s*', $QPzFt), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $zv7wW]]]]]);
        goto bVYQQ;
        bVYQQ:
        $Riyb3 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto xPiJU;
        exqtF:
        return [$QvlqN, $zv7wW];
        goto b6K6n;
        SBNs6:
        $zv7wW = now()->addDays(3)->timestamp;
        goto NxXki;
        xPiJU:
        $QvlqN = $Riyb3->getSignedCookie(['key_pair_id' => $this->Q1kUc, 'private_key' => $this->HyJkj->path($this->gd0AM), 'policy' => $E6JeN]);
        goto exqtF;
        NxXki:
        $QPzFt = $this->JOSB4 . '/v2/hls/';
        goto UVh3n;
        b6K6n:
    }
}
