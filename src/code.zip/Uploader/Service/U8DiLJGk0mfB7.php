<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Core\RkSRDDbIFKZE9;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
final class U8DiLJGk0mfB7 implements E97atJzeJ1gs5
{
    private $wUSfJ;
    private $oS8mw;
    public $K9MJF;
    private $xhsCb;
    private $z7vpO;
    private $foEoP;
    public function __construct($fTadi, $CapE6, $sc_FL, $wCJ8c, $ajL6L, $VGndK)
    {
        goto BCDGg;
        HIck0:
        $this->wUSfJ = $fTadi;
        goto i7uWo;
        BCDGg:
        $this->foEoP = $VGndK;
        goto HIck0;
        iSAiU:
        $this->K9MJF = $sc_FL;
        goto nt274;
        nt274:
        $this->xhsCb = $wCJ8c;
        goto KpcG2;
        KpcG2:
        $this->z7vpO = $ajL6L;
        goto QmBtc;
        i7uWo:
        $this->oS8mw = $CapE6;
        goto iSAiU;
        QmBtc:
    }
    public function resolvePath($BOX5t, $gaBy3 = R278OrMF6HCNB::S3) : string
    {
        goto AiVt8;
        PmVWe:
        return trim($this->K9MJF, '/') . '/' . $BOX5t;
        goto fQDAX;
        vL3HY:
        return trim($this->oS8mw, '/') . '/' . $BOX5t;
        goto roKfe;
        fQDAX:
        XYAcE:
        goto vL3HY;
        a2xO8:
        return config('upload.home') . '/' . $BOX5t;
        goto p3Nxn;
        SkvvR:
        if (!(!empty($this->xhsCb) && !empty($this->z7vpO))) {
            goto OsAcs;
        }
        goto uxVyK;
        qE58C:
        if (!($gaBy3 === R278OrMF6HCNB::LOCAL)) {
            goto cwnlV;
        }
        goto a2xO8;
        uxVyK:
        return $this->m1RMpWr5oAZ($BOX5t);
        goto otVM8;
        T19lx:
        if (!$this->wUSfJ) {
            goto XYAcE;
        }
        goto PmVWe;
        otVM8:
        OsAcs:
        goto T19lx;
        EUGz0:
        $BOX5t = $BOX5t->getAttribute('filename');
        goto qOG21;
        AiVt8:
        if (!$BOX5t instanceof QfVdOZWAlX8Sl) {
            goto ULyEH;
        }
        goto EUGz0;
        qOG21:
        ULyEH:
        goto qE58C;
        p3Nxn:
        cwnlV:
        goto SkvvR;
        roKfe:
    }
    public function resolveThumbnail(QfVdOZWAlX8Sl $BOX5t) : string
    {
        goto cd_63;
        yR6pp:
        return '';
        goto bQUyr;
        GZT0d:
        if (!$DAiAn) {
            goto Ttt4D;
        }
        goto Lu6Xh;
        X1U_6:
        if (!$BOX5t instanceof OcbNsXl9lpteB) {
            goto bJL3G;
        }
        goto HQCrT;
        M1Ys6:
        bJL3G:
        goto PoFzy;
        d3LmH:
        Ttt4D:
        goto fWPyP;
        dHY86:
        return asset('/img/pdf-preview.svg');
        goto YsU07;
        HQCrT:
        return $this->resolvePath($BOX5t, $BOX5t->getAttribute('driver'));
        goto M1Ys6;
        FK4Yv:
        wBkir:
        goto HyFvv;
        YsU07:
        BMIjG:
        goto yR6pp;
        Lu6Xh:
        return $this->resolvePath($DAiAn, $DAiAn->getAttribute('driver'));
        goto d3LmH;
        PoFzy:
        if (!$BOX5t instanceof RkSRDDbIFKZE9) {
            goto BMIjG;
        }
        goto dHY86;
        HyFvv:
        if (!$BOX5t->getAttribute('thumbnail_id')) {
            goto QgJfR;
        }
        goto clckE;
        mvDGd:
        if (!$i1LOg) {
            goto wBkir;
        }
        goto KW31x;
        cd_63:
        $i1LOg = $BOX5t->getAttribute('thumbnail');
        goto mvDGd;
        KW31x:
        return $this->url($i1LOg, $BOX5t->getAttribute('driver'));
        goto FK4Yv;
        fWPyP:
        QgJfR:
        goto X1U_6;
        clckE:
        $DAiAn = OcbNsXl9lpteB::find($BOX5t->getAttribute('thumbnail_id'));
        goto GZT0d;
        bQUyr:
    }
    private function url($XkdbN, $gaBy3)
    {
        goto NqUWV;
        MWjEK:
        return $this->resolvePath($XkdbN);
        goto BqiEL;
        NqUWV:
        if (!($gaBy3 == R278OrMF6HCNB::LOCAL)) {
            goto m0e3A;
        }
        goto WpUOM;
        WpUOM:
        return config('upload.home') . '/' . $XkdbN;
        goto Byqqr;
        Byqqr:
        m0e3A:
        goto MWjEK;
        BqiEL:
    }
    private function m1RMpWr5oAZ($XkdbN)
    {
        goto xkaig;
        lme9c:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto lc1sb;
        Sbbov:
        F0tC0:
        goto VQjom;
        w5DSy:
        if (!(strpos($XkdbN, 'm3u8') !== false)) {
            goto F0tC0;
        }
        goto uIHkp;
        uIHkp:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto Sbbov;
        xkaig:
        if (!(strpos($XkdbN, 'https://') === 0)) {
            goto i09T2;
        }
        goto lme9c;
        Qy4Dy:
        return $P9Ta9->getSignedUrl($this->K9MJF . '/' . $XkdbN, $ie8nC);
        goto cWyKW;
        lc1sb:
        i09T2:
        goto w5DSy;
        f252o:
        $P9Ta9 = new UrlSigner($this->xhsCb, $this->foEoP->path($this->z7vpO));
        goto Qy4Dy;
        VQjom:
        $ie8nC = now()->addMinutes(60)->timestamp;
        goto f252o;
        cWyKW:
    }
    public function resolvePathForHlsVideo(B6s4AA1exjQ2T $cZ20c, $eH5et = false) : string
    {
        goto psdO6;
        uTgK1:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto z2brS;
        psdO6:
        if ($cZ20c->getAttribute('hls_path')) {
            goto pOfI8;
        }
        goto uTgK1;
        pi2mg:
        return $this->K9MJF . '/' . $cZ20c->getAttribute('hls_path');
        goto IL8k3;
        z2brS:
        pOfI8:
        goto pi2mg;
        IL8k3:
    }
    public function resolvePathForHlsVideos()
    {
        goto wCxd2;
        xSlL8:
        return [$p3nfG, $ie8nC];
        goto noq1R;
        WqbTZ:
        $DOYwp = $this->K9MJF . '/v2/hls/';
        goto Rch2I;
        Rch2I:
        $GW2Fs = json_encode(['Statement' => [['Resource' => sprintf('%s*', $DOYwp), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $ie8nC]]]]]);
        goto Mn3XJ;
        Mn3XJ:
        $PFg5i = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto Mtup0;
        Mtup0:
        $p3nfG = $PFg5i->getSignedCookie(['key_pair_id' => $this->xhsCb, 'private_key' => $this->foEoP->path($this->z7vpO), 'policy' => $GW2Fs]);
        goto xSlL8;
        wCxd2:
        $ie8nC = now()->addDays(3)->timestamp;
        goto WqbTZ;
        noq1R:
    }
}
