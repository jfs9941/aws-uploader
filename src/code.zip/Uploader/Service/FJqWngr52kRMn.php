<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\VuQzRNCSz5bHK;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Core\Observer\VlTX8Oy4qKZ4i;
use Jfs\Uploader\Core\Observer\IGMWSmHCNUsVb;
use Jfs\Uploader\Core\MDV8LxETbMtpJ;
use Jfs\Uploader\Core\ShrdF6p8QWYqf;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
use Jfs\Uploader\Exception\Q2lfI5IWmjyoJ;
use Jfs\Uploader\Exception\NTczwCygSFCCc;
use Jfs\Uploader\Service\FileResolver\LBgBBJ5A98RMN;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class FJqWngr52kRMn
{
    private $GMBHj;
    private $SIeOC;
    private $UoQI7;
    public function __construct($dMnLA, $Ay4fJ, $UjVft)
    {
        goto IazyN;
        IazyN:
        $this->GMBHj = $dMnLA;
        goto aDT1W;
        RHIv0:
        $this->UoQI7 = $UjVft;
        goto R_SDs;
        aDT1W:
        $this->SIeOC = $Ay4fJ;
        goto RHIv0;
        R_SDs:
    }
    public function mhUxRFmyxFS($Rygto)
    {
        goto nD06T;
        ut5kZ:
        LXgOB:
        goto Do9Xm;
        QMb46:
        $aK3lg = $Rygto->getFile();
        goto zpBET;
        zpBET:
        return $this->miIOL7OHM1I($aK3lg->extension(), YJGCddWUf6Zu2::S3, null, $Rygto->options());
        goto ut5kZ;
        Do9Xm:
        return $this->miIOL7OHM1I($Rygto['file_extension'], 's3' === $Rygto['driver'] ? YJGCddWUf6Zu2::S3 : YJGCddWUf6Zu2::LOCAL);
        goto H9dvm;
        nD06T:
        if (!$Rygto instanceof SingleUploadInterface) {
            goto LXgOB;
        }
        goto QMb46;
        H9dvm:
    }
    public function m0mcH6s2Skm(string $InHEz)
    {
        goto jSliM;
        jSliM:
        $Q8IO8 = config('upload.attachment_model')::findOrFail($InHEz);
        goto isgcA;
        isgcA:
        $YEF57 = $this->miIOL7OHM1I($Q8IO8->getAttribute('type'), $Q8IO8->getAttribute('driver'), $Q8IO8->getAttribute('id'));
        goto O_Ghh;
        Y02qa:
        $YEF57->setRawAttributes($Q8IO8->getAttributes());
        goto rmGaZ;
        O_Ghh:
        $YEF57->exists = true;
        goto Y02qa;
        rmGaZ:
        return $YEF57;
        goto O1g_z;
        O1g_z:
    }
    public function m4MXHxxcRTe(string $ZKsHh) : VuQzRNCSz5bHK
    {
        goto VMl1x;
        sSBSs:
        $Vl6f_ = ShrdF6p8QWYqf::mqhTVnRl0yJ($CLKCW);
        goto V9LJ3;
        v4tyC:
        throw new Q2lfI5IWmjyoJ('metadata file not found');
        goto frSA8;
        VMl1x:
        $jEIlh = $this->SIeOC->get($ZKsHh);
        goto Qfk6H;
        vHBT1:
        if (!$CLKCW) {
            goto F3zsJ;
        }
        goto sSBSs;
        oBkxC:
        $CLKCW = json_decode($jEIlh, true);
        goto vHBT1;
        sUmwS:
        F3zsJ:
        goto v4tyC;
        TbK99:
        XR8wC:
        goto oBkxC;
        sIsw3:
        $jEIlh = $this->UoQI7->get($ZKsHh);
        goto TbK99;
        V9LJ3:
        return $this->miIOL7OHM1I($Vl6f_->ghW3E, $Vl6f_->mUz5QoCeD2Y(), $Vl6f_->filename);
        goto sUmwS;
        Qfk6H:
        if ($jEIlh) {
            goto XR8wC;
        }
        goto sIsw3;
        frSA8:
    }
    private function miIOL7OHM1I(string $UCO1s, $N00hA, ?string $InHEz = null, array $K4w3R = [])
    {
        goto R6V6Q;
        UlIqn:
        foreach ($this->GMBHj as $ILKvW) {
            goto QAaH3;
            QAaH3:
            if (!$ILKvW->mug0hsvdBIy($bGOfE)) {
                goto d6q_6;
            }
            goto Valhk;
            Valhk:
            return $bGOfE->initLocation($ILKvW->m3xAJz0xWf1($bGOfE));
            goto MZzQC;
            vdZN6:
            b0cl3:
            goto gy7SB;
            MZzQC:
            d6q_6:
            goto vdZN6;
            gy7SB:
        }
        goto bAEhB;
        bAEhB:
        ISoTE:
        goto tEE61;
        c8hFH:
        switch ($UCO1s) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $bGOfE = UKkbXBDRxjSUY::createFromScratch($InHEz, $UCO1s);
                goto Fy2aM;
            case 'mp4':
            case 'mov':
                $bGOfE = JPkW9ix1EKo3T::createFromScratch($InHEz, $UCO1s);
                goto Fy2aM;
            case 'pdf':
                $bGOfE = MDV8LxETbMtpJ::createFromScratch($InHEz, $UCO1s);
                goto Fy2aM;
            default:
                throw new NTczwCygSFCCc("not support file type {$UCO1s}");
        }
        goto H3uC7;
        wkDJQ:
        Fy2aM:
        goto IuEi4;
        R6V6Q:
        $InHEz = $InHEz ?? Uuid::uuid4()->getHex()->toString();
        goto c8hFH;
        wqH55:
        $bGOfE->m2Ak24UoC8E(new VlTX8Oy4qKZ4i($bGOfE));
        goto B49oe;
        B49oe:
        $bGOfE->m2Ak24UoC8E(new IGMWSmHCNUsVb($bGOfE, $this->UoQI7, $K4w3R));
        goto UlIqn;
        tEE61:
        throw new NTczwCygSFCCc("not support file type {$UCO1s}");
        goto Ly3vz;
        IuEi4:
        $bGOfE = $bGOfE->mlb6XSjg7tP($N00hA);
        goto wqH55;
        H3uC7:
        t35VE:
        goto wkDJQ;
        Ly3vz:
    }
}
