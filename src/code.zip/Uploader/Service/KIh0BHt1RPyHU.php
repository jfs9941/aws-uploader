<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Uploader\Service;

use Aws\Sqs\SqsClient;
use backup\Exposed\AVqShGCH8LOrP;
use backup\Exposed\ArCSgsnvTg6Tv;
use backup\Exposed\MWQEI3qnbYMuU;
use backup\Gallery\Model\QyxVvo5lhAzix;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\Aetm2HiFuJE34;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class KIh0BHt1RPyHU implements MWQEI3qnbYMuU
{
    private $K1dBX;
    private $kEfMA;
    public function __construct(ArCSgsnvTg6Tv $WyTVH, Filesystem $FP6ih)
    {
        $this->K1dBX = $WyTVH;
        $this->kEfMA = $FP6ih;
    }
    public function saveMetadata(string $EQQae, array $JbFc7)
    {
        goto inuvp;
        inuvp:
        $L2Ff8 = AvisbyD0IE5xq::findOrFail($EQQae);
        goto uK5XC;
        MdAZt:
        $uqSxi['duration'] = $JbFc7['duration'];
        goto ALhEQ;
        zhq4K:
        YZEt8:
        goto SfB64;
        LNbyn:
        try {
            goto uMA59;
            uMA59:
            $bp6Lq = $this->K1dBX->storeSingleFile(new class($JbFc7['thumbnail']) implements AVqShGCH8LOrP
            {
                private $i31Dp;
                public function __construct($eVZrJ)
                {
                    $this->i31Dp = $eVZrJ;
                }
                public function getFile()
                {
                    return $this->i31Dp;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto grSfQ;
            grSfQ:
            $uqSxi['thumbnail_id'] = $bp6Lq['id'];
            goto aO321;
            aO321:
            $uqSxi['thumbnail'] = $bp6Lq['filename'];
            goto eX2zG;
            eX2zG:
        } catch (\Throwable $eQXjs) {
            Log::warning("AvisbyD0IE5xq thumbnail store failed: " . $eQXjs->getMessage());
        }
        goto VKtCD;
        uK5XC:
        $uqSxi = [];
        goto UANsC;
        UANsC:
        if (!isset($JbFc7['thumbnail'])) {
            goto GEumA;
        }
        goto LNbyn;
        SfB64:
        if (!$L2Ff8->PLX0U) {
            goto zgeo5;
        }
        goto BvMva;
        qnUyy:
        if (!(isset($JbFc7['change_status']) && $JbFc7['change_status'])) {
            goto TH80R;
        }
        goto IPeJW;
        ytd1R:
        $uqSxi['resolution'] = $JbFc7['resolution'];
        goto WtOh0;
        O328m:
        QyRca:
        goto pJsRz;
        XgI6t:
        throw new \Exception("AvisbyD0IE5xq metadata store failed for unknown reason ... " . $EQQae);
        goto eZjc6;
        IPeJW:
        $this->K1dBX->updateFile($L2Ff8->getAttribute('id'), Aetm2HiFuJE34::PROCESSING);
        goto q5ZbE;
        VKtCD:
        GEumA:
        goto QYj49;
        yTmzs:
        if (!isset($JbFc7['fps'])) {
            goto YZEt8;
        }
        goto pKjtL;
        q5ZbE:
        TH80R:
        goto en_v2;
        WtOh0:
        IMsKB:
        goto yTmzs;
        QYj49:
        if (!isset($JbFc7['duration'])) {
            goto tLo1g;
        }
        goto MdAZt;
        sx0Af:
        if (!isset($JbFc7['resolution'])) {
            goto IMsKB;
        }
        goto ytd1R;
        GXWv1:
        zgeo5:
        goto G7W6a;
        en_v2:
        return $L2Ff8->getView();
        goto O328m;
        pJsRz:
        Log::warning("AvisbyD0IE5xq metadata store failed for unknown reason ... " . $EQQae);
        goto XgI6t;
        ALhEQ:
        tLo1g:
        goto sx0Af;
        G7W6a:
        if (!$L2Ff8->update($uqSxi)) {
            goto QyRca;
        }
        goto qnUyy;
        BvMva:
        unset($uqSxi['thumbnail']);
        goto GXWv1;
        pKjtL:
        $uqSxi['fps'] = $JbFc7['fps'];
        goto zhq4K;
        eZjc6:
    }
    public function createThumbnail(string $Pa87e) : void
    {
        goto yOXHu;
        dDN00:
        $NvC_G = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto jgpor;
        jo2CD:
        $L2Ff8 = AvisbyD0IE5xq::findOrFail($Pa87e);
        goto g8GSk;
        g8GSk:
        $g6MD1 = "v2/hls/thumbnails/{$Pa87e}/";
        goto CDZ_J;
        I2HS_:
        nsTQw:
        goto fVOfY;
        CDZ_J:
        if (!(!$this->kEfMA->directoryExists($g6MD1) && empty($L2Ff8->mrAKUJLucZ8()))) {
            goto nsTQw;
        }
        goto dDN00;
        jgpor:
        try {
            goto bgl3v;
            LBQYG:
            $NvC_G->sendMessage(['QueueUrl' => $s84Yt, 'MessageBody' => json_encode(['file_path' => $L2Ff8->getLocation()])]);
            goto T1npy;
            bgl3v:
            $Reca4 = $NvC_G->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto c5Bx2;
            c5Bx2:
            $s84Yt = $Reca4->get('QueueUrl');
            goto LBQYG;
            T1npy:
        } catch (\Throwable $AfYww) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$AfYww->getMessage()}");
        }
        goto I2HS_;
        yOXHu:
        Log::info("Use Lambda to generate thumbnail for video: " . $Pa87e);
        goto jo2CD;
        fVOfY:
    }
    public function mm9kFUdQOug(string $Pa87e) : void
    {
        goto aWxot;
        RYPiQ:
        throw new \Exception("Message back with success data but not found thumbnail files " . $Pa87e);
        goto wpVVF;
        HLd4c:
        $L2Ff8->update(['generated_previews' => $g6MD1]);
        goto tfakL;
        porDE:
        throw new \Exception("Message back with success data but not found thumbnail " . $Pa87e);
        goto id6af;
        BFNpI:
        $g6MD1 = "v2/hls/thumbnails/{$Pa87e}/";
        goto cIT2u;
        bycmJ:
        if (!(count($w37Ul) === 0)) {
            goto fQeQD;
        }
        goto EX2nl;
        cIT2u:
        if ($this->kEfMA->directoryExists($g6MD1)) {
            goto Kxv6l;
        }
        goto dIC3X;
        dIC3X:
        Log::error("Message back with success data but not found thumbnail " . $Pa87e);
        goto porDE;
        aWxot:
        $L2Ff8 = AvisbyD0IE5xq::findOrFail($Pa87e);
        goto BFNpI;
        wpVVF:
        fQeQD:
        goto HLd4c;
        id6af:
        Kxv6l:
        goto Ce6pX;
        EX2nl:
        Log::error("Message back with success data but not found thumbnail files " . $Pa87e);
        goto RYPiQ;
        Ce6pX:
        $w37Ul = $this->kEfMA->files($g6MD1);
        goto bycmJ;
        tfakL:
    }
    public function getThumbnails(string $Pa87e) : array
    {
        $L2Ff8 = AvisbyD0IE5xq::findOrFail($Pa87e);
        return $L2Ff8->getThumbnails();
    }
    public function getMedia(string $Pa87e) : array
    {
        $tFHv6 = QyxVvo5lhAzix::findOrFail($Pa87e);
        return $tFHv6->getView();
    }
}
