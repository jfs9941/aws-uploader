<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\EknRcwWhw5aDZ;
use Jfs\Uploader\Core\WEM4ywoGgpPLK;
use Jfs\Uploader\Core\GHjLMBSnTOoC3;
use Jfs\Uploader\Enum\OLX71luAn6XnP;
use Jfs\Uploader\Exception\LiA5BOk62pit2;
use Jfs\Uploader\Exception\KzbSFcd7qiwCv;
use Jfs\Uploader\Exception\RpmK0FOGWoQmq;
final class Q7Ya1DOnGbc8X implements UploadServiceInterface
{
    private $GgLuj;
    private $x0wV5;
    private $f3yJU;
    private $z8R_z;
    public function __construct(XqoSwDelQBsQt $LTIWF, Filesystem $mHTSY, Filesystem $RUQUm, string $d63Yh)
    {
        goto X04jo;
        X04jo:
        $this->GgLuj = $LTIWF;
        goto Vfybg;
        nL08q:
        $this->z8R_z = $d63Yh;
        goto qlS9w;
        zApJP:
        $this->f3yJU = $RUQUm;
        goto nL08q;
        Vfybg:
        $this->x0wV5 = $mHTSY;
        goto zApJP;
        qlS9w:
    }
    public function storeSingleFile(SingleUploadInterface $zwZsL) : array
    {
        goto XMwZt;
        nTij3:
        if (false !== $TnwL2 && $oYtbp instanceof EknRcwWhw5aDZ) {
            goto fhYEF;
        }
        goto A0n_b;
        jSAg7:
        BlSCd:
        goto A6K4a;
        dXvfU:
        $oYtbp->m3irf1LtLKT(OLX71luAn6XnP::UPLOADED);
        goto jSAg7;
        A6K4a:
        return $oYtbp->getView();
        goto X9iER;
        Bm8Ez:
        goto BlSCd;
        goto v8Ogz;
        A0n_b:
        throw new \LogicException('File upload failed, check permissions');
        goto Bm8Ez;
        XMwZt:
        $oYtbp = $this->GgLuj->mV3nnu59hwG($zwZsL);
        goto Ql_Vc;
        Ql_Vc:
        $TnwL2 = $this->f3yJU->putFileAs(dirname($oYtbp->getLocation()), $zwZsL->getFile(), $oYtbp->getFilename() . '.' . $oYtbp->getExtension(), ['visibility' => 'public']);
        goto nTij3;
        v8Ogz:
        fhYEF:
        goto dXvfU;
        X9iER:
    }
    public function storePreSignedFile(array $sO5N2)
    {
        goto gqQtZ;
        fh52x:
        $UEurj = GHjLMBSnTOoC3::m3JDOCfNVAu($oYtbp, $this->x0wV5, $this->f3yJU, $this->z8R_z, true);
        goto lNcDx;
        gqQtZ:
        $oYtbp = $this->GgLuj->mV3nnu59hwG($sO5N2);
        goto fh52x;
        gMNNg:
        $UEurj->m2SZC1hpix5();
        goto ZNGGV;
        ZNGGV:
        return ['filename' => $UEurj->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $UEurj->mbZSkEgKpwb()];
        goto ikEfN;
        lNcDx:
        $UEurj->mO1FRqgwloA($sO5N2['mime'], $sO5N2['file_size'], $sO5N2['chunk_size'], $sO5N2['checksums'], $sO5N2['user_id'], $sO5N2['driver']);
        goto gMNNg;
        ikEfN:
    }
    public function updatePreSignedFile(string $YC2e2, int $JjYPr)
    {
        goto tDazy;
        tDazy:
        $UEurj = GHjLMBSnTOoC3::mOivyCa3f9G($YC2e2, $this->x0wV5, $this->f3yJU, $this->z8R_z);
        goto RCihx;
        CmXp3:
        Dn77K:
        goto KBfQ5;
        RCihx:
        switch ($JjYPr) {
            case OLX71luAn6XnP::UPLOADED:
                $UEurj->m2j98qj1KZT();
                goto Kign2;
            case OLX71luAn6XnP::PROCESSING:
                $UEurj->mpJKmbIe9Ju();
                goto Kign2;
            case OLX71luAn6XnP::FINISHED:
                $UEurj->miNo8ZpQs0F();
                goto Kign2;
            case OLX71luAn6XnP::ABORTED:
                $UEurj->mZfuX6Fne2U();
                goto Kign2;
        }
        goto CmXp3;
        KBfQ5:
        Kign2:
        goto RQieH;
        RQieH:
    }
    public function completePreSignedFile(string $YC2e2, array $AbKCX)
    {
        goto n3I2S;
        UjL3Q:
        $UEurj->m2j98qj1KZT();
        goto y0ysB;
        n3I2S:
        $UEurj = GHjLMBSnTOoC3::mOivyCa3f9G($YC2e2, $this->x0wV5, $this->f3yJU, $this->z8R_z);
        goto Qv79G;
        y0ysB:
        return ['path' => $UEurj->getFile()->getView()['path'], 'thumbnail' => $UEurj->getFile()->pIIgF, 'id' => $YC2e2];
        goto nJ1oj;
        Qv79G:
        $UEurj->mCZg2QiXqrg()->mIwkuoaBBlU($AbKCX);
        goto UjL3Q;
        nJ1oj:
    }
    public function updateFile(string $YC2e2, int $JjYPr) : WEM4ywoGgpPLK
    {
        goto kQIIQ;
        izhUQ:
        return $oYtbp;
        goto ScThl;
        kQIIQ:
        $oYtbp = $this->GgLuj->m4N8ntnagh6($YC2e2);
        goto FGDBG;
        FGDBG:
        $oYtbp->m3irf1LtLKT($JjYPr);
        goto izhUQ;
        ScThl:
    }
}
