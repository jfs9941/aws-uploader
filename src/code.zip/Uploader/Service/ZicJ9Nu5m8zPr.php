<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\T93Mcsw1gA3an;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class ZicJ9Nu5m8zPr implements VideoPostHandleServiceInterface
{
    private $YB6ID;
    private $wEVdN;
    public function __construct(UploadServiceInterface $SUxKx, Filesystem $dzspH)
    {
        $this->YB6ID = $SUxKx;
        $this->wEVdN = $dzspH;
    }
    public function saveMetadata(string $hOWbX, array $p3JMC)
    {
        goto AhuK4;
        n1Eem:
        if (!isset($p3JMC['fps'])) {
            goto blpfE;
        }
        goto CmV6Q;
        w0Xuc:
        throw new \Exception("HS7SZ3rYPI80t metadata store failed for unknown reason ... " . $hOWbX);
        goto JN0yH;
        oq9G3:
        $this->YB6ID->updateFile($ZtI9P->getAttribute('id'), T93Mcsw1gA3an::PROCESSING);
        goto HToSs;
        CmV6Q:
        $KB7Ux['fps'] = $p3JMC['fps'];
        goto Q12Fd;
        AhuK4:
        $ZtI9P = HS7SZ3rYPI80t::findOrFail($hOWbX);
        goto pqXlh;
        Z7g_E:
        gwfyh:
        goto eE7n_;
        FGKDC:
        try {
            goto ydlTX;
            ptxSL:
            $KB7Ux['thumbnail_id'] = $N07Z2['id'];
            goto diLXJ;
            ydlTX:
            $N07Z2 = $this->YB6ID->storeSingleFile(new class($p3JMC['thumbnail']) implements SingleUploadInterface
            {
                private $LXD2P;
                public function __construct($VslFR)
                {
                    $this->LXD2P = $VslFR;
                }
                public function getFile()
                {
                    return $this->LXD2P;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto ptxSL;
            diLXJ:
            $KB7Ux['thumbnail'] = $N07Z2['filename'];
            goto cmqLQ;
            cmqLQ:
        } catch (\Throwable $qeKgz) {
            Log::warning("HS7SZ3rYPI80t thumbnail store failed: " . $qeKgz->getMessage());
        }
        goto Z7g_E;
        XcIgZ:
        $KB7Ux['resolution'] = $p3JMC['resolution'];
        goto I2OCi;
        HToSs:
        gCnep:
        goto S7nn0;
        U5T3i:
        tT3iT:
        goto GztSp;
        eE7n_:
        if (!isset($p3JMC['duration'])) {
            goto ga_6N;
        }
        goto X3ARK;
        GztSp:
        Log::warning("HS7SZ3rYPI80t metadata store failed for unknown reason ... " . $hOWbX);
        goto w0Xuc;
        s10kA:
        UncZu:
        goto HZqWs;
        Q12Fd:
        blpfE:
        goto uFaxa;
        z7aN1:
        if (!isset($p3JMC['resolution'])) {
            goto bnDqZ;
        }
        goto XcIgZ;
        HZqWs:
        if (!$ZtI9P->update($KB7Ux)) {
            goto tT3iT;
        }
        goto JBeCm;
        X3ARK:
        $KB7Ux['duration'] = $p3JMC['duration'];
        goto wxmH1;
        I2OCi:
        bnDqZ:
        goto n1Eem;
        pqXlh:
        $KB7Ux = [];
        goto qfrl3;
        OMbIB:
        wgweD:
        goto MQV7M;
        qwMdQ:
        unset($KB7Ux['thumbnail']);
        goto s10kA;
        uFaxa:
        if (!$ZtI9P->Lkzkq) {
            goto UncZu;
        }
        goto qwMdQ;
        MQV7M:
        if (!isset($p3JMC['thumbnail'])) {
            goto gwfyh;
        }
        goto FGKDC;
        qfrl3:
        if (!isset($p3JMC['thumbnail_url'])) {
            goto wgweD;
        }
        goto gVdbc;
        S7nn0:
        return $ZtI9P->getView();
        goto U5T3i;
        gVdbc:
        $KB7Ux['thumbnail'] = $p3JMC['thumbnail_url'];
        goto OMbIB;
        wxmH1:
        ga_6N:
        goto z7aN1;
        JBeCm:
        if (!(isset($p3JMC['change_status']) && $p3JMC['change_status'])) {
            goto gCnep;
        }
        goto oq9G3;
        JN0yH:
    }
    public function createThumbnail(string $J7quw) : void
    {
        goto qkezD;
        kCshA:
        if (!(!$this->wEVdN->directoryExists($IXbv1) && empty($ZtI9P->m8MX0IHyJMe()))) {
            goto V9Dp9;
        }
        goto YBo4f;
        qkezD:
        Log::info("Use Lambda to generate thumbnail for video: " . $J7quw);
        goto EUvIL;
        YBo4f:
        $AORC1 = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto OylbJ;
        EUvIL:
        $ZtI9P = HS7SZ3rYPI80t::findOrFail($J7quw);
        goto xRVtP;
        OylbJ:
        try {
            goto BkxM6;
            TWvEp:
            $rd159 = $cH_PJ->get('QueueUrl');
            goto P1RtQ;
            BkxM6:
            $cH_PJ = $AORC1->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto TWvEp;
            P1RtQ:
            $AORC1->sendMessage(['QueueUrl' => $rd159, 'MessageBody' => json_encode(['file_path' => $ZtI9P->getLocation()])]);
            goto jspDC;
            jspDC:
        } catch (\Throwable $aGVU4) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$aGVU4->getMessage()}");
        }
        goto CCas6;
        CCas6:
        V9Dp9:
        goto iJz1D;
        xRVtP:
        $IXbv1 = "v2/hls/thumbnails/{$J7quw}/";
        goto kCshA;
        iJz1D:
    }
    public function mGEsqukOYqJ(string $J7quw) : void
    {
        goto U7IXg;
        U7IXg:
        $ZtI9P = HS7SZ3rYPI80t::findOrFail($J7quw);
        goto pamTL;
        L7yY2:
        throw new \Exception("Message back with success data but not found thumbnail " . $J7quw);
        goto EZZwI;
        R4GwB:
        SAtUP:
        goto cnZYc;
        JLVCc:
        throw new \Exception("Message back with success data but not found thumbnail files " . $J7quw);
        goto R4GwB;
        gkh_O:
        if ($this->wEVdN->directoryExists($IXbv1)) {
            goto bkT1q;
        }
        goto ftgXw;
        AeywG:
        $IlvN_ = $this->wEVdN->files($IXbv1);
        goto D09p6;
        cnZYc:
        $ZtI9P->update(['generated_previews' => $IXbv1]);
        goto tt0lQ;
        tjh0n:
        Log::error("Message back with success data but not found thumbnail files " . $J7quw);
        goto JLVCc;
        ftgXw:
        Log::error("Message back with success data but not found thumbnail " . $J7quw);
        goto L7yY2;
        EZZwI:
        bkT1q:
        goto AeywG;
        D09p6:
        if (!(count($IlvN_) === 0)) {
            goto SAtUP;
        }
        goto tjh0n;
        pamTL:
        $IXbv1 = "v2/hls/thumbnails/{$J7quw}/";
        goto gkh_O;
        tt0lQ:
    }
    public function getThumbnails(string $J7quw) : array
    {
        $ZtI9P = HS7SZ3rYPI80t::findOrFail($J7quw);
        return $ZtI9P->getThumbnails();
    }
    public function getMedia(string $J7quw) : array
    {
        $WtNuf = Media::findOrFail($J7quw);
        return $WtNuf->getView();
    }
}
