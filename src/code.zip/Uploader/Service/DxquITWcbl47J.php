<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\QoCMzcKvH8Cw2;
final class DxquITWcbl47J implements VideoPostHandleServiceInterface
{
    private $FGcfi;
    private $auR_S;
    public function __construct(UploadServiceInterface $zpBsT, Filesystem $JhAxH)
    {
        $this->FGcfi = $zpBsT;
        $this->auR_S = $JhAxH;
    }
    public function saveMetadata(string $IaHim, array $szNd7)
    {
        goto twIdH;
        yZrne:
        Ups7n:
        goto fh8Cq;
        UIhZL:
        if (!(isset($szNd7['change_status']) && $szNd7['change_status'])) {
            goto u4Gqd;
        }
        goto Fx7lj;
        twIdH:
        $vd5JT = ACdpgX4YCYP6M::findOrFail($IaHim);
        goto c_X5K;
        po9TE:
        if (!$vd5JT->update($AP6R3)) {
            goto PM8nE;
        }
        goto UIhZL;
        FlLTC:
        throw new \Exception("ACdpgX4YCYP6M metadata store failed for unknown reason ... " . $IaHim);
        goto iTTvz;
        ovJ0C:
        pxvoC:
        goto po9TE;
        UJv1u:
        try {
            goto w9Wxc;
            RstEc:
            $AP6R3['thumbnail_id'] = $NSw82['id'];
            goto TOcES;
            w9Wxc:
            $NSw82 = $this->FGcfi->storeSingleFile(new class($szNd7['thumbnail']) implements SingleUploadInterface
            {
                private $nIFfY;
                public function __construct($QuYzZ)
                {
                    $this->nIFfY = $QuYzZ;
                }
                public function getFile()
                {
                    return $this->nIFfY;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto RstEc;
            TOcES:
            $AP6R3['thumbnail'] = $NSw82['filename'];
            goto KSEPC;
            KSEPC:
        } catch (\Throwable $djmN_) {
            Log::warning("ACdpgX4YCYP6M thumbnail store failed: " . $djmN_->getMessage());
        }
        goto HgfW3;
        fh8Cq:
        if (!isset($szNd7['resolution'])) {
            goto krGlX;
        }
        goto r76xN;
        HgfW3:
        HNshM:
        goto ThQBS;
        Fx7lj:
        $this->FGcfi->updateFile($vd5JT->getAttribute('id'), QoCMzcKvH8Cw2::PROCESSING);
        goto JquQO;
        PYnsH:
        Log::warning("ACdpgX4YCYP6M metadata store failed for unknown reason ... " . $IaHim);
        goto FlLTC;
        eAe0e:
        krGlX:
        goto vU4og;
        jmnFf:
        $AP6R3['duration'] = $szNd7['duration'];
        goto yZrne;
        vU4og:
        if (!isset($szNd7['fps'])) {
            goto pxvoC;
        }
        goto HPojr;
        ThQBS:
        if (!isset($szNd7['duration'])) {
            goto Ups7n;
        }
        goto jmnFf;
        HPojr:
        $AP6R3['fps'] = $szNd7['fps'];
        goto ovJ0C;
        kR53n:
        return $vd5JT->getView();
        goto uctHc;
        TauPQ:
        if (!isset($szNd7['thumbnail'])) {
            goto HNshM;
        }
        goto UJv1u;
        c_X5K:
        $AP6R3 = [];
        goto TauPQ;
        JquQO:
        u4Gqd:
        goto kR53n;
        r76xN:
        $AP6R3['resolution'] = $szNd7['resolution'];
        goto eAe0e;
        uctHc:
        PM8nE:
        goto PYnsH;
        iTTvz:
    }
    public function createThumbnail(string $NdYXZ) : void
    {
        goto QevOQ;
        uev7b:
        try {
            goto kwPyn;
            Z6WfX:
            $v_nB2 = $YNnSt->get('QueueUrl');
            goto Yi4N5;
            Yi4N5:
            $b45NA->sendMessage(['QueueUrl' => $v_nB2, 'MessageBody' => json_encode(['file_path' => $vd5JT->getLocation()])]);
            goto qTCzz;
            kwPyn:
            $YNnSt = $b45NA->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto Z6WfX;
            qTCzz:
        } catch (\Throwable $aa8DU) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$aa8DU->getMessage()}");
        }
        goto J5B3r;
        HCyce:
        $vd5JT = ACdpgX4YCYP6M::findOrFail($NdYXZ);
        goto HncBM;
        D4PGo:
        if (!(!$this->auR_S->directoryExists($cwZhh) && empty($vd5JT->mtkJpGLr3yD()))) {
            goto JwB_p;
        }
        goto zMSuW;
        HncBM:
        $cwZhh = "v2/hls/thumbnails/{$NdYXZ}/";
        goto D4PGo;
        J5B3r:
        JwB_p:
        goto OiAIg;
        QevOQ:
        Log::info("Use Lambda to generate thumbnail for video: " . $NdYXZ);
        goto HCyce;
        zMSuW:
        $b45NA = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto uev7b;
        OiAIg:
    }
    public function mKJnHSZ2vXS(string $NdYXZ) : void
    {
        goto P42Wc;
        WDmYE:
        throw new \Exception("Message back with success data but not found thumbnail " . $NdYXZ);
        goto KKsXZ;
        QQfgy:
        $cwZhh = "v2/hls/thumbnails/{$NdYXZ}/";
        goto fwbom;
        YsF8J:
        GxbKd:
        goto CZ4GU;
        XYPvf:
        Log::error("Message back with success data but not found thumbnail " . $NdYXZ);
        goto WDmYE;
        P42Wc:
        $vd5JT = ACdpgX4YCYP6M::findOrFail($NdYXZ);
        goto QQfgy;
        vtkCJ:
        Log::error("Message back with success data but not found thumbnail files " . $NdYXZ);
        goto CD08G;
        lZOE6:
        if (!(count($tBSWh) === 0)) {
            goto GxbKd;
        }
        goto vtkCJ;
        KKsXZ:
        fy0Ti:
        goto eiBhF;
        CD08G:
        throw new \Exception("Message back with success data but not found thumbnail files " . $NdYXZ);
        goto YsF8J;
        eiBhF:
        $tBSWh = $this->auR_S->files($cwZhh);
        goto lZOE6;
        fwbom:
        if ($this->auR_S->directoryExists($cwZhh)) {
            goto fy0Ti;
        }
        goto XYPvf;
        CZ4GU:
        $vd5JT->update(['generated_previews' => $cwZhh]);
        goto viQwU;
        viQwU:
    }
    public function getThumbnails(string $NdYXZ) : array
    {
        $vd5JT = ACdpgX4YCYP6M::findOrFail($NdYXZ);
        return $vd5JT->getThumbnails();
    }
}
