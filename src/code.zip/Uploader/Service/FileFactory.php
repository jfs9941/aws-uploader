<?php
declare(strict_types=1);

namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\FileStateInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Core\Observer\FileLifeCircleObserver;
use Jfs\Uploader\Core\Observer\FileProcessingObserver;
use Jfs\Uploader\Core\Pdf;
use Jfs\Uploader\Core\PreSignedMetadata;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileDriver;
use Jfs\Uploader\Exception\InvalidTempFileException;
use Jfs\Uploader\Exception\NonAcceptedFileException;
use Jfs\Uploader\Service\FileResolver\FileLocationResolverInterface;
use Ramsey\Uuid\Uuid;

final class FileFactory
{
    private $fileLocationResolvers;
    private $localStorage;
    private $s3;

    /**
     * @param iterable<FileLocationResolverInterface> $fileLocationResolvers
     * @param Filesystem                              $localStorage
     * @param Filesystem                              $s3
     */
    public function __construct($fileLocationResolvers,
        $localStorage,
        $s3)
    {
        $this->fileLocationResolvers = $fileLocationResolvers;
        $this->localStorage = $localStorage;
        $this->s3 = $s3;
    }

    /**
     * @param SingleUploadInterface|array $fileUploadRequest
     *
     * @return BaseFileModel|FileStateInterface
     * @return BaseFileModel|FileStateInterface
     *
     * @throws NonAcceptedFileException
     */
    public function createFile($fileUploadRequest)
    {
        if ($fileUploadRequest instanceof SingleUploadInterface) {
            $fileObject = $fileUploadRequest->getFile();

            return $this->createFileWithConcreteClass($fileObject->extension(), FileDriver::S3, null, $fileUploadRequest->options());
        }

        return $this->createFileWithConcreteClass(
            $fileUploadRequest['file_extension'],
            's3' === $fileUploadRequest['driver'] ? FileDriver::S3 : FileDriver::LOCAL
        );
    }

    /**
     * @return BaseFileModel|FileStateInterface
     *
     * @throws NonAcceptedFileException
     */
    public function initFile(string $id)
    {
        $attachment = config('upload.attachment_model')::findOrFail($id);
        $file = $this->createFileWithConcreteClass($attachment->getAttribute('type'), $attachment->getAttribute('driver'), $attachment->getAttribute('id'));
        $file->exists = true;
        $file->setRawAttributes($attachment->getAttributes());

        return $file;
    }

    /**
     * @throws NonAcceptedFileException|InvalidTempFileException
     */
    public function initFromMetadata(string $filePath): FileStateInterface
    {
        $content = $this->localStorage->get($filePath);
        if (!$content) {
            $content = $this->s3->get($filePath);
        }
        $metadata = json_decode($content, true);
        if ($metadata) {
            $metadataObject = PreSignedMetadata::fromFileContent($metadata);

            return $this->createFileWithConcreteClass($metadataObject->fileExtension, $metadataObject->getDriver(), $metadataObject->filename);
        }
        throw new InvalidTempFileException('metadata file not found');
    }

    /**
     * @param int $fileDriver
     *
     * @return FileStateInterface|BaseFileModel
     *
     * @throws NonAcceptedFileException
     */
    private function createFileWithConcreteClass(string $fileExtension, $fileDriver, ?string $id = null, array $options = [])
    {
        $id = $id ?? Uuid::uuid4()->getHex()->toString();
        switch ($fileExtension) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $fileCreated = Image::createFromScratch($id, $fileExtension);
                break;
            case 'mp4':
            case 'mov':
                $fileCreated = Video::createFromScratch($id, $fileExtension);
                break;
            case 'pdf':
                $fileCreated = Pdf::createFromScratch($id, $fileExtension);
                break;
            default:
                throw new NonAcceptedFileException("not support file type {$fileExtension}");
        }
        $fileCreated = $fileCreated->selectStorage($fileDriver);
        $fileCreated->addObserver(new FileLifeCircleObserver($fileCreated));
        $fileCreated->addObserver(new FileProcessingObserver($fileCreated, $this->s3, $options));
        foreach ($this->fileLocationResolvers as $resolver) {
            if ($resolver->supports($fileCreated)) {
                return $fileCreated->initLocation($resolver->resolveLocation($fileCreated));
            }
        }

        throw new NonAcceptedFileException("not support file type {$fileExtension}");
    }
}
