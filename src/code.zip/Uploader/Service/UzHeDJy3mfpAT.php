<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\LKF23eYmlDs0w;
use Jfs\Uploader\Core\WlFu7DaMUEnSS;
use Jfs\Uploader\Core\El1EbMj6pC2Ez;
use Jfs\Uploader\Enum\GlPuUJKmzwUJ9;
use Jfs\Uploader\Exception\FQ1SutuqCRD5X;
use Jfs\Uploader\Exception\LvyLnQ2Iyddt1;
use Jfs\Uploader\Exception\NxfDNhkjIm1nw;
use Jfs\Uploader\Service\B1HCEXUDgNNxk;
use Illuminate\Contracts\Filesystem\Filesystem;
final class UzHeDJy3mfpAT implements UploadServiceInterface
{
    private $BG4Fe;
    private $FHcNr;
    private $p5xeF;
    private $P3Kgf;
    public function __construct(B1HCEXUDgNNxk $e6M1z, Filesystem $z279S, Filesystem $AA8Bi, string $D0jvO)
    {
        goto eb2yY;
        eb2yY:
        $this->BG4Fe = $e6M1z;
        goto n51Bs;
        NkJqY:
        $this->P3Kgf = $D0jvO;
        goto Dw01J;
        n51Bs:
        $this->FHcNr = $z279S;
        goto m842h;
        m842h:
        $this->p5xeF = $AA8Bi;
        goto NkJqY;
        Dw01J:
    }
    public function storeSingleFile(SingleUploadInterface $FrEmo) : array
    {
        goto VsP9M;
        VsP9M:
        $K9DZL = $this->BG4Fe->muNv0MUfhR1($FrEmo);
        goto TXTdZ;
        Dlfg9:
        $K9DZL->miF5zZlQWZD(GlPuUJKmzwUJ9::UPLOADED);
        goto nbeKg;
        hHTXH:
        goto ALyNF;
        goto IXqnG;
        IXqnG:
        xi7BY:
        goto Dlfg9;
        htPa2:
        if (false !== $L5bJW && $K9DZL instanceof LKF23eYmlDs0w) {
            goto xi7BY;
        }
        goto TKWbT;
        nbeKg:
        ALyNF:
        goto ZlVke;
        TXTdZ:
        $L5bJW = $this->p5xeF->putFileAs(dirname($K9DZL->getLocation()), $FrEmo->getFile(), $K9DZL->getFilename() . '.' . $K9DZL->getExtension(), ['visibility' => 'public']);
        goto htPa2;
        TKWbT:
        throw new \LogicException('File upload failed, check permissions');
        goto hHTXH;
        ZlVke:
        return $K9DZL->getView();
        goto wKITk;
        wKITk:
    }
    public function storePreSignedFile(array $IGztm)
    {
        goto wuKNw;
        hTwM8:
        return ['filename' => $tzb77->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $tzb77->mTlk22kDycI()];
        goto bq5vP;
        inCBq:
        $tzb77->mo3qfcJAbt4();
        goto hTwM8;
        wuKNw:
        $K9DZL = $this->BG4Fe->muNv0MUfhR1($IGztm);
        goto mM5Gs;
        mM5Gs:
        $tzb77 = El1EbMj6pC2Ez::mV7s1eh48Zx($K9DZL, $this->FHcNr, $this->p5xeF, $this->P3Kgf, true);
        goto uJ7FD;
        uJ7FD:
        $tzb77->mYZDh1mMlqv($IGztm['mime'], $IGztm['file_size'], $IGztm['chunk_size'], $IGztm['checksums'], $IGztm['user_id'], $IGztm['driver']);
        goto inCBq;
        bq5vP:
    }
    public function updatePreSignedFile(string $NxCnq, int $vmaQI)
    {
        goto WOiGa;
        wfgnT:
        switch ($vmaQI) {
            case GlPuUJKmzwUJ9::UPLOADED:
                $tzb77->mTiwVD0wyAm();
                goto ZZzcy;
            case GlPuUJKmzwUJ9::PROCESSING:
                $tzb77->mNYdU3XLwW7();
                goto ZZzcy;
            case GlPuUJKmzwUJ9::FINISHED:
                $tzb77->mEYcZubsvcH();
                goto ZZzcy;
            case GlPuUJKmzwUJ9::ABORTED:
                $tzb77->m7wvF9ApT8n();
                goto ZZzcy;
        }
        goto ssdaY;
        VO1Q5:
        ZZzcy:
        goto NmlY_;
        ssdaY:
        JaXzQ:
        goto VO1Q5;
        WOiGa:
        $tzb77 = El1EbMj6pC2Ez::mYtsf4mp97v($NxCnq, $this->FHcNr, $this->p5xeF, $this->P3Kgf);
        goto wfgnT;
        NmlY_:
    }
    public function completePreSignedFile(string $NxCnq, array $oDHkw)
    {
        goto KZsTl;
        EKZAR:
        $tzb77->mFBfBagZ9x6()->mJxwEU3Y3Aa($oDHkw);
        goto Z7b0F;
        Z7b0F:
        $tzb77->mTiwVD0wyAm();
        goto zjqdT;
        zjqdT:
        return ['path' => $tzb77->getFile()->getView()['path'], 'thumbnail' => $tzb77->getFile()->rHzhB, 'id' => $NxCnq];
        goto JqRQv;
        KZsTl:
        $tzb77 = El1EbMj6pC2Ez::mYtsf4mp97v($NxCnq, $this->FHcNr, $this->p5xeF, $this->P3Kgf);
        goto EKZAR;
        JqRQv:
    }
    public function updateFile(string $NxCnq, int $vmaQI) : WlFu7DaMUEnSS
    {
        goto qCUSh;
        b4La9:
        return $K9DZL;
        goto jngpo;
        qCUSh:
        $K9DZL = $this->BG4Fe->mQZkuaB2q4d($NxCnq);
        goto TM7j4;
        TM7j4:
        $K9DZL->miF5zZlQWZD($vmaQI);
        goto b4La9;
        jngpo:
    }
}
