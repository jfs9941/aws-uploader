<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\RsTEqK0aKnthE;
use Jfs\Uploader\Core\TXpC7TSf51nOz;
use Jfs\Uploader\Core\Rfow5q0HYgflu;
use Jfs\Uploader\Enum\HGmeWpZQSxAlO;
use Jfs\Uploader\Exception\LjuaNh4VOaOkF;
use Jfs\Uploader\Exception\YK7fJDaVPWKzB;
use Jfs\Uploader\Exception\N08aNyPgjV9qA;
use Jfs\Uploader\Service\DpvqXIwAB5UAa;
use Illuminate\Contracts\Filesystem\Filesystem;
final class Rc7HXyVNsfevS implements UploadServiceInterface
{
    private $hRcOl;
    private $j5MRz;
    private $Diye_;
    private $UZkM2;
    public function __construct(DpvqXIwAB5UAa $Hwf6y, Filesystem $nkmCX, Filesystem $NYASv, string $pfApK)
    {
        goto Sb5lu;
        lzKOz:
        $this->j5MRz = $nkmCX;
        goto pKLYp;
        MS0B4:
        $this->UZkM2 = $pfApK;
        goto Yzp86;
        pKLYp:
        $this->Diye_ = $NYASv;
        goto MS0B4;
        Sb5lu:
        $this->hRcOl = $Hwf6y;
        goto lzKOz;
        Yzp86:
    }
    public function storeSingleFile(SingleUploadInterface $L177H) : array
    {
        goto cArcm;
        cArcm:
        $Ga9Xm = $this->hRcOl->m45nXWCsSWK($L177H);
        goto Nzr4S;
        R39UM:
        WzTMs:
        goto HUnhb;
        Nzr4S:
        $lPyJj = $this->Diye_->putFileAs(dirname($Ga9Xm->getLocation()), $L177H->getFile(), $Ga9Xm->getFilename() . '.' . $Ga9Xm->getExtension(), ['visibility' => 'public']);
        goto SzivX;
        SzivX:
        if (false !== $lPyJj && $Ga9Xm instanceof RsTEqK0aKnthE) {
            goto WzTMs;
        }
        goto NpsqD;
        qklyC:
        return $Ga9Xm->getView();
        goto BY2HN;
        HUnhb:
        $Ga9Xm->muO5nIQPKS7(HGmeWpZQSxAlO::UPLOADED);
        goto E6IBR;
        NpsqD:
        throw new \LogicException('File upload failed, check permissions');
        goto FxI2c;
        E6IBR:
        tYYyQ:
        goto qklyC;
        FxI2c:
        goto tYYyQ;
        goto R39UM;
        BY2HN:
    }
    public function storePreSignedFile(array $ik3TB)
    {
        goto jxdUB;
        Gi0I_:
        $LaHja = Rfow5q0HYgflu::mS8Dcpb0iRh($Ga9Xm, $this->j5MRz, $this->Diye_, $this->UZkM2, true);
        goto s2GIv;
        jxdUB:
        $Ga9Xm = $this->hRcOl->m45nXWCsSWK($ik3TB);
        goto Gi0I_;
        s2GIv:
        $LaHja->mViFa4XEhmd($ik3TB['mime'], $ik3TB['file_size'], $ik3TB['chunk_size'], $ik3TB['checksums'], $ik3TB['user_id'], $ik3TB['driver']);
        goto nwXo0;
        rmMnV:
        return ['filename' => $LaHja->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $LaHja->mVtrBORQO9n()];
        goto H1Nv5;
        nwXo0:
        $LaHja->mqwYUMOn9gH();
        goto rmMnV;
        H1Nv5:
    }
    public function updatePreSignedFile(string $jFW_i, int $wwV0z)
    {
        goto u63fd;
        r3QVM:
        uHS5J:
        goto X_wm6;
        u63fd:
        $LaHja = Rfow5q0HYgflu::mORSzsBkcxt($jFW_i, $this->j5MRz, $this->Diye_, $this->UZkM2);
        goto k4CeT;
        X_wm6:
        fZMxm:
        goto HQj6o;
        k4CeT:
        switch ($wwV0z) {
            case HGmeWpZQSxAlO::UPLOADED:
                $LaHja->mGxDGBRUj3Q();
                goto fZMxm;
            case HGmeWpZQSxAlO::PROCESSING:
                $LaHja->m4mw3ZqvLga();
                goto fZMxm;
            case HGmeWpZQSxAlO::FINISHED:
                $LaHja->mgJQBwKqV80();
                goto fZMxm;
            case HGmeWpZQSxAlO::ABORTED:
                $LaHja->mZZl5H6bEXr();
                goto fZMxm;
        }
        goto r3QVM;
        HQj6o:
    }
    public function completePreSignedFile(string $jFW_i, array $GU93H)
    {
        goto aUP9X;
        aUP9X:
        $LaHja = Rfow5q0HYgflu::mORSzsBkcxt($jFW_i, $this->j5MRz, $this->Diye_, $this->UZkM2);
        goto H5rJw;
        v7skA:
        return ['path' => $LaHja->getFile()->getView()['path'], 'thumbnail' => $LaHja->getFile()->k7emd, 'id' => $jFW_i];
        goto cI04l;
        H5rJw:
        $LaHja->mLISLvz7JU3()->mLvel7PmmCO($GU93H);
        goto Wa7Hc;
        Wa7Hc:
        $LaHja->mGxDGBRUj3Q();
        goto v7skA;
        cI04l:
    }
    public function updateFile(string $jFW_i, int $wwV0z) : TXpC7TSf51nOz
    {
        goto Rsbam;
        WMDAW:
        return $Ga9Xm;
        goto xGZhN;
        RZcLc:
        $Ga9Xm->muO5nIQPKS7($wwV0z);
        goto WMDAW;
        Rsbam:
        $Ga9Xm = $this->hRcOl->mQjwVjj4omD($jFW_i);
        goto RZcLc;
        xGZhN:
    }
}
