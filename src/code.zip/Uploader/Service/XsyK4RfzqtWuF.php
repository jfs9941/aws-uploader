<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Core\E2ynNzu6kpbgj;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
final class XsyK4RfzqtWuF implements ZOxMhYUF0fAsi
{
    private $HlD2y;
    private $uuIFk;
    public $Quxsy;
    private $tBmhy;
    private $RH0PZ;
    private $FFBPk;
    public function __construct($Zl2JQ, $epJDz, $Ulxpl, $zGZAc, $LkvMZ, $GHkBm)
    {
        goto gDVfC;
        mOPZi:
        $this->HlD2y = $Zl2JQ;
        goto AidU3;
        RZoRV:
        $this->RH0PZ = $LkvMZ;
        goto s0pXf;
        gDVfC:
        $this->FFBPk = $GHkBm;
        goto mOPZi;
        PHLhN:
        $this->Quxsy = $Ulxpl;
        goto Vl0wD;
        Vl0wD:
        $this->tBmhy = $zGZAc;
        goto RZoRV;
        AidU3:
        $this->uuIFk = $epJDz;
        goto PHLhN;
        s0pXf:
    }
    public function resolvePath($Mhc38, $TYPZ5 = KPpxBU3Qc8yRk::S3) : string
    {
        goto Hw6sh;
        qkv2R:
        return trim($this->Quxsy, '/') . '/' . $Mhc38;
        goto XyGyb;
        OFB5H:
        vqUvv:
        goto cNqO1;
        KPS48:
        return route('home') . '/' . $Mhc38;
        goto gyJXW;
        sNVUZ:
        if (!$this->HlD2y) {
            goto MREky;
        }
        goto qkv2R;
        cNqO1:
        if (!($TYPZ5 === KPpxBU3Qc8yRk::LOCAL)) {
            goto Qx0pP;
        }
        goto KPS48;
        gyJXW:
        Qx0pP:
        goto UtOqZ;
        UtOqZ:
        if (!(!empty($this->tBmhy) && !empty($this->RH0PZ))) {
            goto sfbW2;
        }
        goto Ow44J;
        XyGyb:
        MREky:
        goto p9TyR;
        stKJ8:
        $Mhc38 = $Mhc38->getAttribute('filename');
        goto OFB5H;
        p9TyR:
        return trim($this->uuIFk, '/') . '/' . $Mhc38;
        goto aNG0p;
        Ow44J:
        return $this->m19cnksBOS3($Mhc38);
        goto J1P97;
        J1P97:
        sfbW2:
        goto sNVUZ;
        Hw6sh:
        if (!$Mhc38 instanceof DYGJpbj9Ye8wY) {
            goto vqUvv;
        }
        goto stKJ8;
        aNG0p:
    }
    public function resolveThumbnail(DYGJpbj9Ye8wY $Mhc38) : string
    {
        goto byRiB;
        byRiB:
        $FFU0R = $Mhc38->getAttribute('thumbnail');
        goto ocj7g;
        YY1X7:
        if (!$Mhc38 instanceof HSe6BNUpJTSwE) {
            goto M00M9;
        }
        goto q8iMd;
        e2mWq:
        jh71Q:
        goto YY1X7;
        nzYoN:
        return $this->resolvePath($urvlN, $urvlN->getAttribute('driver'));
        goto yxI4D;
        DlmGa:
        if (!$urvlN) {
            goto Mt0Q0;
        }
        goto nzYoN;
        q5eiB:
        return '';
        goto r5Que;
        eVvdM:
        $urvlN = HSe6BNUpJTSwE::find($Mhc38->getAttribute('thumbnail_id'));
        goto DlmGa;
        uD0ZZ:
        M00M9:
        goto wQJYf;
        Sf04j:
        return $this->url($FFU0R, $Mhc38->getAttribute('driver'));
        goto alFKA;
        ocj7g:
        if (!$FFU0R) {
            goto zvOrr;
        }
        goto Sf04j;
        dOE0I:
        if (!$Mhc38->getAttribute('thumbnail_id')) {
            goto jh71Q;
        }
        goto eVvdM;
        wQJYf:
        if (!$Mhc38 instanceof E2ynNzu6kpbgj) {
            goto mR2Gp;
        }
        goto wTaPc;
        alFKA:
        zvOrr:
        goto dOE0I;
        KdcaN:
        mR2Gp:
        goto q5eiB;
        q8iMd:
        return $this->resolvePath($Mhc38, $Mhc38->getAttribute('driver'));
        goto uD0ZZ;
        wTaPc:
        return asset('/img/pdf-preview.svg');
        goto KdcaN;
        yxI4D:
        Mt0Q0:
        goto e2mWq;
        r5Que:
    }
    private function url($eviRR, $TYPZ5)
    {
        goto GEpsP;
        GEpsP:
        if (!($TYPZ5 == KPpxBU3Qc8yRk::LOCAL)) {
            goto Npn0I;
        }
        goto ywwll;
        yWY2a:
        Npn0I:
        goto F_rqN;
        ywwll:
        return route('home') . '/' . $eviRR;
        goto yWY2a;
        F_rqN:
        return $this->resolvePath($eviRR);
        goto jQqz_;
        jQqz_:
    }
    private function m19cnksBOS3($eviRR)
    {
        goto V9cTV;
        oHP_g:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto vkDiJ;
        V9cTV:
        if (!(strpos($eviRR, 'https://') === 0)) {
            goto LZqZ5;
        }
        goto oHeFs;
        WGGDQ:
        return $ebT1i->getSignedUrl($this->Quxsy . '/' . $eviRR, $W8rbR);
        goto QA1RD;
        oHeFs:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto iAUP2;
        vkDiJ:
        AFeB7:
        goto nDbLn;
        nDbLn:
        $W8rbR = now()->addMinutes(60)->timestamp;
        goto PsKrq;
        Yrq1u:
        if (!(strpos($eviRR, 'm3u8') !== false)) {
            goto AFeB7;
        }
        goto oHP_g;
        PsKrq:
        $ebT1i = new UrlSigner($this->tBmhy, $this->FFBPk->path($this->RH0PZ));
        goto WGGDQ;
        iAUP2:
        LZqZ5:
        goto Yrq1u;
        QA1RD:
    }
    public function resolvePathForHlsVideo(QdnSnf08v9RV7 $KuX31, $yAUVl = false) : string
    {
        goto p7ZUK;
        YxRmw:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto YNhyg;
        YNhyg:
        kcPTI:
        goto OL7wj;
        OL7wj:
        return $this->Quxsy . '/' . $KuX31->getAttribute('hls_path');
        goto DNOBX;
        p7ZUK:
        if ($KuX31->getAttribute('hls_path')) {
            goto kcPTI;
        }
        goto YxRmw;
        DNOBX:
    }
    public function resolvePathForHlsVideos()
    {
        goto H9MJg;
        KEsXY:
        $Iyqky = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto XsYTq;
        AM8fI:
        $en1RA = json_encode(['Statement' => [['Resource' => sprintf('%s*', $Fe91H), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $W8rbR]]]]]);
        goto KEsXY;
        mPee0:
        return [$xPs4j, $W8rbR];
        goto nN53U;
        H9MJg:
        $W8rbR = now()->addDays(3)->timestamp;
        goto cBxiw;
        XsYTq:
        $xPs4j = $Iyqky->getSignedCookie(['key_pair_id' => $this->tBmhy, 'private_key' => $this->FFBPk->path($this->RH0PZ), 'policy' => $en1RA]);
        goto mPee0;
        cBxiw:
        $Fe91H = $this->Quxsy . '/v2/hls/';
        goto AM8fI;
        nN53U:
    }
}
