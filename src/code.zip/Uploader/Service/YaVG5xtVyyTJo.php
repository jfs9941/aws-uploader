<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Uploader\Contracts\Fk274vNY0LJnp;
use Jfs\Uploader\Core\IN9Uizy4TAywx;
use Jfs\Uploader\Core\TN0vqVlBODTOO;
use Jfs\Uploader\Enum\M7O7NSiJU2JG5;
use Jfs\Uploader\Exception\CBStNIBT6cwK0;
use Jfs\Uploader\Exception\SLsozGEgkOpxH;
use Jfs\Uploader\Exception\TLy3l2bn56lcq;
use Jfs\Uploader\Service\XaaDhpdqTL9N3;
use Illuminate\Contracts\Filesystem\Filesystem;
final class YaVG5xtVyyTJo implements UploadServiceInterface
{
    private $L8J_I;
    private $q6zCU;
    private $NTZHy;
    private $i5XrD;
    public function __construct(XaaDhpdqTL9N3 $JxTJu, Filesystem $zDbHT, Filesystem $pbv6a, string $NQRQT)
    {
        goto sY34J;
        qxA5z:
        $this->NTZHy = $pbv6a;
        goto DVM9b;
        W2lKK:
        $this->q6zCU = $zDbHT;
        goto qxA5z;
        sY34J:
        $this->L8J_I = $JxTJu;
        goto W2lKK;
        DVM9b:
        $this->i5XrD = $NQRQT;
        goto mGkJv;
        mGkJv:
    }
    public function storeSingleFile(SingleUploadInterface $LJcdT) : array
    {
        goto jGB0R;
        DwFjg:
        loYUt:
        goto Zs5Ty;
        F0s0W:
        return $Z5ydB->getView();
        goto X7i0V;
        jGB0R:
        $Z5ydB = $this->L8J_I->mDWXGQfZ7p1($LJcdT);
        goto TLtsg;
        Zs5Ty:
        $Z5ydB->mpDdU9lVtpc(M7O7NSiJU2JG5::UPLOADED);
        goto gzrR2;
        k02E0:
        if (false !== $lmTDq && $Z5ydB instanceof Fk274vNY0LJnp) {
            goto loYUt;
        }
        goto aqKDQ;
        QIzcF:
        goto E1JrO;
        goto DwFjg;
        TLtsg:
        $lmTDq = $this->NTZHy->putFileAs(dirname($Z5ydB->getLocation()), $LJcdT->getFile(), $Z5ydB->getFilename() . '.' . $Z5ydB->getExtension(), ['visibility' => 'public']);
        goto k02E0;
        gzrR2:
        E1JrO:
        goto F0s0W;
        aqKDQ:
        throw new \LogicException('File upload failed, check permissions');
        goto QIzcF;
        X7i0V:
    }
    public function storePreSignedFile(array $Ms5lC)
    {
        goto aW1PB;
        bzkjU:
        return ['filename' => $wJPdj->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $wJPdj->mWg9QPOd0Lf()];
        goto OCxyw;
        dbPdj:
        $wJPdj->m2ofC0YgLEm();
        goto bzkjU;
        iA3sl:
        $wJPdj->miKDxKJaSJG($Ms5lC['mime'], $Ms5lC['file_size'], $Ms5lC['chunk_size'], $Ms5lC['checksums'], $Ms5lC['user_id'], $Ms5lC['driver']);
        goto dbPdj;
        aW1PB:
        $Z5ydB = $this->L8J_I->mDWXGQfZ7p1($Ms5lC);
        goto RFtmX;
        RFtmX:
        $wJPdj = TN0vqVlBODTOO::mQGhDqDDpV5($Z5ydB, $this->q6zCU, $this->NTZHy, $this->i5XrD, true);
        goto iA3sl;
        OCxyw:
    }
    public function updatePreSignedFile(string $N555I, int $UiWkO)
    {
        goto jv9Bz;
        eFPa8:
        switch ($UiWkO) {
            case M7O7NSiJU2JG5::UPLOADED:
                $wJPdj->mDZARaYuIOd();
                goto nD7Mk;
            case M7O7NSiJU2JG5::PROCESSING:
                $wJPdj->mraPUzzIjKw();
                goto nD7Mk;
            case M7O7NSiJU2JG5::FINISHED:
                $wJPdj->miKCeZObvHV();
                goto nD7Mk;
            case M7O7NSiJU2JG5::ABORTED:
                $wJPdj->mLDJoHspaWH();
                goto nD7Mk;
        }
        goto FKmdA;
        FKmdA:
        VhE8p:
        goto G10GT;
        jv9Bz:
        $wJPdj = TN0vqVlBODTOO::mjR3Q7dHYyO($N555I, $this->q6zCU, $this->NTZHy, $this->i5XrD);
        goto eFPa8;
        G10GT:
        nD7Mk:
        goto g1Vj1;
        g1Vj1:
    }
    public function completePreSignedFile(string $N555I, array $R3nTL)
    {
        goto x02ZS;
        rQJQ1:
        $wJPdj->mDZARaYuIOd();
        goto GYSo9;
        GYSo9:
        return ['path' => $wJPdj->getFile()->getView()['path'], 'thumbnail' => $wJPdj->getFile()->u4XxL, 'id' => $N555I];
        goto YDbWi;
        x02ZS:
        $wJPdj = TN0vqVlBODTOO::mjR3Q7dHYyO($N555I, $this->q6zCU, $this->NTZHy, $this->i5XrD);
        goto UHJpw;
        UHJpw:
        $wJPdj->m67klYkiadk()->mp3ovv1LKfG($R3nTL);
        goto rQJQ1;
        YDbWi:
    }
    public function updateFile(string $N555I, int $UiWkO) : IN9Uizy4TAywx
    {
        goto ElXR0;
        DVesA:
        $Z5ydB->mpDdU9lVtpc($UiWkO);
        goto zsMJQ;
        ElXR0:
        $Z5ydB = $this->L8J_I->mqtjUnfOvTD($N555I);
        goto DVesA;
        zsMJQ:
        return $Z5ydB;
        goto BE7wq;
        BE7wq:
    }
}
