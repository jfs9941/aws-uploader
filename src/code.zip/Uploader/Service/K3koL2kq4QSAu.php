<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\OFkaCU82i4KNX;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Core\Observer\GQA6vtRwd42pY;
use Jfs\Uploader\Core\Observer\XE7R9TkGqTYDZ;
use Jfs\Uploader\Core\XHvEDPKBjvWLs;
use Jfs\Uploader\Core\D30TCm1otQUnt;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
use Jfs\Uploader\Exception\UZ54KLSfEVX7F;
use Jfs\Uploader\Exception\Im4dmRuVGtM4W;
use Jfs\Uploader\Service\FileResolver\RRkB3ccVGry7P;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class K3koL2kq4QSAu
{
    private $vQtW0;
    private $zoOKU;
    private $PxC6l;
    public function __construct($Whups, $e3FbC, $kxhX9)
    {
        goto nHvyY;
        nHvyY:
        $this->vQtW0 = $Whups;
        goto mthcR;
        mthcR:
        $this->zoOKU = $e3FbC;
        goto kRp8n;
        kRp8n:
        $this->PxC6l = $kxhX9;
        goto vCPC2;
        vCPC2:
    }
    public function m2wXw1yUeMq($rQINM)
    {
        goto qsP5p;
        oVtrL:
        return $this->mssdvsQyL0K($x7Y0M->extension(), McZXbZmlQ53or::S3, null, $rQINM->options());
        goto yVgHq;
        qsP5p:
        if (!$rQINM instanceof SingleUploadInterface) {
            goto HYnzP;
        }
        goto Nl0ok;
        yVgHq:
        HYnzP:
        goto Am88N;
        Am88N:
        return $this->mssdvsQyL0K($rQINM['file_extension'], 's3' === $rQINM['driver'] ? McZXbZmlQ53or::S3 : McZXbZmlQ53or::LOCAL);
        goto a_Lyx;
        Nl0ok:
        $x7Y0M = $rQINM->getFile();
        goto oVtrL;
        a_Lyx:
    }
    public function m6FtHGGCs4T(string $S580N)
    {
        goto pDk3W;
        JCjTS:
        $gNVOT->setRawAttributes($FnmXY->getAttributes());
        goto chZ0j;
        Ng58C:
        $gNVOT->exists = true;
        goto JCjTS;
        BnGFG:
        $gNVOT = $this->mssdvsQyL0K($FnmXY->getAttribute('type'), $FnmXY->getAttribute('driver'), $FnmXY->getAttribute('id'));
        goto Ng58C;
        pDk3W:
        $FnmXY = config('upload.attachment_model')::findOrFail($S580N);
        goto BnGFG;
        chZ0j:
        return $gNVOT;
        goto ehX0C;
        ehX0C:
    }
    public function mrANFNqI7Cg(string $pL5Qa) : OFkaCU82i4KNX
    {
        goto NhbIh;
        ARRN_:
        Bmmr_:
        goto anmb1;
        TcpWH:
        return $this->mssdvsQyL0K($JCVEp->O6Gdu, $JCVEp->mS69GwwTS4W(), $JCVEp->filename);
        goto NlmM7;
        anmb1:
        $AOnlH = json_decode($PTUaa, true);
        goto ZxaAE;
        NhbIh:
        $PTUaa = $this->zoOKU->get($pL5Qa);
        goto ll7PO;
        Llum6:
        $PTUaa = $this->PxC6l->get($pL5Qa);
        goto ARRN_;
        ZxaAE:
        if (!$AOnlH) {
            goto KzoTJ;
        }
        goto SqQvu;
        NlmM7:
        KzoTJ:
        goto ld0gK;
        ll7PO:
        if ($PTUaa) {
            goto Bmmr_;
        }
        goto Llum6;
        ld0gK:
        throw new UZ54KLSfEVX7F('metadata file not found');
        goto pQQg1;
        SqQvu:
        $JCVEp = D30TCm1otQUnt::mRt62ufLGnj($AOnlH);
        goto TcpWH;
        pQQg1:
    }
    private function mssdvsQyL0K(string $qm8Ow, $vhSzt, ?string $S580N = null, array $RH5Rq = [])
    {
        goto eBCfZ;
        aTAAz:
        foreach ($this->vQtW0 as $j3pzE) {
            goto isr46;
            dxKot:
            Cr0Oh:
            goto sV8QF;
            bex9e:
            return $K3pvM->initLocation($j3pzE->mmGrLEMKSzu($K3pvM));
            goto MXj6t;
            isr46:
            if (!$j3pzE->mH8VrxJ67sd($K3pvM)) {
                goto PA0I_;
            }
            goto bex9e;
            MXj6t:
            PA0I_:
            goto dxKot;
            sV8QF:
        }
        goto G41by;
        G41by:
        pLbOH:
        goto IlyoB;
        eBCfZ:
        $S580N = $S580N ?? Uuid::uuid4()->getHex()->toString();
        goto rLtTl;
        qJ33G:
        $K3pvM->m4opzeov9Jg(new GQA6vtRwd42pY($K3pvM));
        goto iNzU7;
        iNzU7:
        $K3pvM->m4opzeov9Jg(new XE7R9TkGqTYDZ($K3pvM, $this->PxC6l, $RH5Rq));
        goto aTAAz;
        rLtTl:
        switch ($qm8Ow) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $K3pvM = KfEJaEGpFJ0tm::createFromScratch($S580N, $qm8Ow);
                goto uqFzn;
            case 'mp4':
            case 'mov':
                $K3pvM = BtruCfJoaSWZ6::createFromScratch($S580N, $qm8Ow);
                goto uqFzn;
            case 'pdf':
                $K3pvM = XHvEDPKBjvWLs::createFromScratch($S580N, $qm8Ow);
                goto uqFzn;
            default:
                throw new Im4dmRuVGtM4W("not support file type {$qm8Ow}");
        }
        goto SdkuM;
        bG5Qy:
        uqFzn:
        goto Ggtel;
        SdkuM:
        pC5rS:
        goto bG5Qy;
        IlyoB:
        throw new Im4dmRuVGtM4W("not support file type {$qm8Ow}");
        goto z1RSQ;
        Ggtel:
        $K3pvM = $K3pvM->mUf0t7aKDYY($vhSzt);
        goto qJ33G;
        z1RSQ:
    }
}
