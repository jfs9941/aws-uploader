<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Core\YuLJNLBqHeeZR;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
final class TEgBbF7EqiUEB implements ECHrJsgxCR7OQ
{
    private $Nqj8h;
    private $VbBT1;
    public $deho_;
    private $mKFzE;
    private $q2m2y;
    private $sf39X;
    public function __construct($M_8OG, $pnBLZ, $fqgFL, $f_mUQ, $bZbtg, $ZqxJI)
    {
        goto SgrZ2;
        YbOqh:
        $this->Nqj8h = $M_8OG;
        goto My5qM;
        SgrZ2:
        $this->sf39X = $ZqxJI;
        goto YbOqh;
        Z0rrl:
        $this->deho_ = $fqgFL;
        goto lDu6A;
        lDu6A:
        $this->mKFzE = $f_mUQ;
        goto VqVhc;
        My5qM:
        $this->VbBT1 = $pnBLZ;
        goto Z0rrl;
        VqVhc:
        $this->q2m2y = $bZbtg;
        goto TOp4A;
        TOp4A:
    }
    public function resolvePath($ahBEB, $XokUJ = FW54oEnFetVYj::S3) : string
    {
        goto Rn1PG;
        ulK9p:
        riH3B:
        goto bkuDQ;
        T3fvy:
        $ahBEB = $ahBEB->getAttribute('filename');
        goto PMxFT;
        bkuDQ:
        if (!$this->Nqj8h) {
            goto PINWu;
        }
        goto IqVSf;
        h2NlZ:
        return trim($this->VbBT1, '/') . '/' . $ahBEB;
        goto NstyM;
        J0moZ:
        PINWu:
        goto h2NlZ;
        m9vUg:
        if (!($XokUJ === FW54oEnFetVYj::LOCAL)) {
            goto KgkfP;
        }
        goto fdWdB;
        x9MS1:
        KgkfP:
        goto FQIPT;
        QjLGd:
        return $this->mY0qflRQzwe($ahBEB);
        goto ulK9p;
        PMxFT:
        NMYKC:
        goto m9vUg;
        fdWdB:
        return config('upload.home') . '/' . $ahBEB;
        goto x9MS1;
        FQIPT:
        if (!(!empty($this->mKFzE) && !empty($this->q2m2y))) {
            goto riH3B;
        }
        goto QjLGd;
        IqVSf:
        return trim($this->deho_, '/') . '/' . $ahBEB;
        goto J0moZ;
        Rn1PG:
        if (!$ahBEB instanceof ZujQPL2bQTbeI) {
            goto NMYKC;
        }
        goto T3fvy;
        NstyM:
    }
    public function resolveThumbnail(ZujQPL2bQTbeI $ahBEB) : string
    {
        goto KnoL5;
        BUiFe:
        return $this->url($DU5Lh, $ahBEB->getAttribute('driver'));
        goto G0ItA;
        yRkPE:
        ft2uo:
        goto CXvlG;
        G0ItA:
        o1Y4_:
        goto C6Vgi;
        ohsBm:
        return $this->resolvePath($ahBEB, $ahBEB->getAttribute('driver'));
        goto kbaOj;
        F7yTR:
        AY_eX:
        goto MuNL7;
        kbaOj:
        c8xRZ:
        goto b3kUk;
        MuNL7:
        if (!$ahBEB instanceof Kx3NMUJqFpl5Q) {
            goto c8xRZ;
        }
        goto ohsBm;
        CXvlG:
        return '';
        goto D2xyk;
        cx0wU:
        $dZdUx = Kx3NMUJqFpl5Q::find($ahBEB->getAttribute('thumbnail_id'));
        goto sg41N;
        qWcU8:
        return $this->resolvePath($dZdUx, $dZdUx->getAttribute('driver'));
        goto NDVe9;
        NDVe9:
        QE2Yq:
        goto F7yTR;
        C6Vgi:
        if (!$ahBEB->getAttribute('thumbnail_id')) {
            goto AY_eX;
        }
        goto cx0wU;
        b3kUk:
        if (!$ahBEB instanceof YuLJNLBqHeeZR) {
            goto ft2uo;
        }
        goto Wmw06;
        aGaMZ:
        if (!$DU5Lh) {
            goto o1Y4_;
        }
        goto BUiFe;
        KnoL5:
        $DU5Lh = $ahBEB->getAttribute('thumbnail');
        goto aGaMZ;
        Wmw06:
        return asset('/img/pdf-preview.svg');
        goto yRkPE;
        sg41N:
        if (!$dZdUx) {
            goto QE2Yq;
        }
        goto qWcU8;
        D2xyk:
    }
    private function url($IJqE5, $XokUJ)
    {
        goto bsMGu;
        bsMGu:
        if (!($XokUJ == FW54oEnFetVYj::LOCAL)) {
            goto GYDjo;
        }
        goto Vd5hC;
        kSFLG:
        GYDjo:
        goto DN609;
        Vd5hC:
        return config('upload.home') . '/' . $IJqE5;
        goto kSFLG;
        DN609:
        return $this->resolvePath($IJqE5);
        goto IIFHv;
        IIFHv:
    }
    private function mY0qflRQzwe($IJqE5)
    {
        goto jzMj0;
        jzMj0:
        if (!(strpos($IJqE5, 'https://') === 0)) {
            goto zs3Sq;
        }
        goto PNpZc;
        TAlsZ:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto CIWzs;
        PNpZc:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto Bx9Vb;
        n0cn4:
        return $OggUG->getSignedUrl($this->deho_ . '/' . $IJqE5, $WS9jV);
        goto hFLv2;
        kWmja:
        if (!(strpos($IJqE5, 'm3u8') !== false)) {
            goto xs3sV;
        }
        goto TAlsZ;
        SGn32:
        $WS9jV = now()->addMinutes(60)->timestamp;
        goto wdyWI;
        wdyWI:
        $OggUG = new UrlSigner($this->mKFzE, $this->sf39X->path($this->q2m2y));
        goto n0cn4;
        Bx9Vb:
        zs3Sq:
        goto kWmja;
        CIWzs:
        xs3sV:
        goto SGn32;
        hFLv2:
    }
    public function resolvePathForHlsVideo(G4MP13yRAmltw $WKps1, $lFBPm = false) : string
    {
        goto N1rQI;
        e7ehp:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto mkgvb;
        N1rQI:
        if ($WKps1->getAttribute('hls_path')) {
            goto psecU;
        }
        goto e7ehp;
        R0hmV:
        return $this->deho_ . '/' . $WKps1->getAttribute('hls_path');
        goto jVvtN;
        mkgvb:
        psecU:
        goto R0hmV;
        jVvtN:
    }
    public function resolvePathForHlsVideos()
    {
        goto IA7Pm;
        VXLe7:
        $s6ojy = $kOr9i->getSignedCookie(['key_pair_id' => $this->mKFzE, 'private_key' => $this->sf39X->path($this->q2m2y), 'policy' => $eRHlY]);
        goto hfIOj;
        hfIOj:
        return [$s6ojy, $WS9jV];
        goto BwWHe;
        ELs4u:
        $eRHlY = json_encode(['Statement' => [['Resource' => sprintf('%s*', $nDmAt), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $WS9jV]]]]]);
        goto awhOg;
        xf05c:
        $nDmAt = $this->deho_ . '/v2/hls/';
        goto ELs4u;
        awhOg:
        $kOr9i = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto VXLe7;
        IA7Pm:
        $WS9jV = now()->addDays(3)->timestamp;
        goto xf05c;
        BwWHe:
    }
}
