<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:25              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\ZEs3XZLglwgUu;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Core\Observer\HPmSZ3ZEBbItt;
use Jfs\Uploader\Core\Observer\MvFcUZWgkmJyj;
use Jfs\Uploader\Core\EqLr3PLlMLHwV;
use Jfs\Uploader\Core\YcADon3ndBWYh;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
use Jfs\Uploader\Exception\RRuZixuGIQD7H;
use Jfs\Uploader\Exception\DDrY5gI5aE4u5;
use Jfs\Uploader\Service\FileResolver\PbX8rA6e8y75x;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class P8Uf7dWabbyOG
{
    private $N7zLo;
    private $BX0zD;
    private $m2kWg;
    public function __construct($nFuFm, $MKJ1D, $Npup8)
    {
        goto tVrIz;
        imIcu:
        $this->BX0zD = $MKJ1D;
        goto mcvWK;
        tVrIz:
        $this->N7zLo = $nFuFm;
        goto imIcu;
        mcvWK:
        $this->m2kWg = $Npup8;
        goto OiFYg;
        OiFYg:
    }
    public function mfuNHmUqiJj($qJDr9)
    {
        goto gE5r_;
        JywMt:
        lMeQB:
        goto SRKz7;
        RmyFO:
        return $this->m4czVc1DQg7($lZ5ut->extension(), NFXMub09wSQVu::S3, null, $qJDr9->options());
        goto JywMt;
        gE5r_:
        if (!$qJDr9 instanceof SingleUploadInterface) {
            goto lMeQB;
        }
        goto QBNII;
        SRKz7:
        return $this->m4czVc1DQg7($qJDr9['file_extension'], 's3' === $qJDr9['driver'] ? NFXMub09wSQVu::S3 : NFXMub09wSQVu::LOCAL);
        goto UWbZw;
        QBNII:
        $lZ5ut = $qJDr9->getFile();
        goto RmyFO;
        UWbZw:
    }
    public function mau1vComm37(string $Brk87)
    {
        goto JKIZr;
        CRc7a:
        $ZQzpf = $this->m4czVc1DQg7($VJuHB->getAttribute('type'), $VJuHB->getAttribute('driver'), $VJuHB->getAttribute('id'));
        goto OvOFe;
        zSWGi:
        return $ZQzpf;
        goto RQUxn;
        X3XOY:
        $ZQzpf->setRawAttributes($VJuHB->getAttributes());
        goto zSWGi;
        JKIZr:
        $VJuHB = config('upload.attachment_model')::findOrFail($Brk87);
        goto CRc7a;
        OvOFe:
        $ZQzpf->exists = true;
        goto X3XOY;
        RQUxn:
    }
    public function mliyzdgKEaf(string $z3D3X) : ZEs3XZLglwgUu
    {
        goto KczbK;
        A8jA5:
        $bxW1r = json_decode($CaLMs, true);
        goto K72PV;
        KczbK:
        $CaLMs = $this->BX0zD->get($z3D3X);
        goto HjP5A;
        HjP5A:
        if ($CaLMs) {
            goto AGGJJ;
        }
        goto F4KK9;
        oBmvf:
        AGGJJ:
        goto A8jA5;
        s2RWM:
        $ROMBo = YcADon3ndBWYh::mR3exW3vi8L($bxW1r);
        goto BCzKy;
        F4KK9:
        $CaLMs = $this->m2kWg->get($z3D3X);
        goto oBmvf;
        K72PV:
        if (!$bxW1r) {
            goto ythma;
        }
        goto s2RWM;
        BCzKy:
        return $this->m4czVc1DQg7($ROMBo->WYZ1W, $ROMBo->mfM4ZHuZc6K(), $ROMBo->filename);
        goto CB6fn;
        nFzZR:
        throw new RRuZixuGIQD7H('metadata file not found');
        goto UFCiU;
        CB6fn:
        ythma:
        goto nFzZR;
        UFCiU:
    }
    private function m4czVc1DQg7(string $DqpTR, $E_qUU, ?string $Brk87 = null, array $ZpGBL = [])
    {
        goto ZHEZ_;
        L0K2S:
        $wl0gj->mfE5Wdi7XQV(new MvFcUZWgkmJyj($wl0gj, $this->m2kWg, $ZpGBL));
        goto nJHzv;
        e_ptq:
        cQwYS:
        goto iagXT;
        aO86F:
        Yd_QW:
        goto C1r2j;
        ZHEZ_:
        $Brk87 = $Brk87 ?? Uuid::uuid4()->getHex()->toString();
        goto g0s0N;
        xXjdf:
        $wl0gj->mfE5Wdi7XQV(new HPmSZ3ZEBbItt($wl0gj));
        goto L0K2S;
        C1r2j:
        $wl0gj = $wl0gj->mm8WbIfPYrM($E_qUU);
        goto xXjdf;
        iagXT:
        throw new DDrY5gI5aE4u5("not support file type {$DqpTR}");
        goto EcSly;
        sbCW5:
        gT45k:
        goto aO86F;
        nJHzv:
        foreach ($this->N7zLo as $cDtoP) {
            goto qJtQE;
            pNxFf:
            mMKYU:
            goto aVbzO;
            aVbzO:
            Tn9tt:
            goto tH4r6;
            lUDuh:
            return $wl0gj->initLocation($cDtoP->mQD7yz7G3cT($wl0gj));
            goto pNxFf;
            qJtQE:
            if (!$cDtoP->mXhruH8jlx5($wl0gj)) {
                goto mMKYU;
            }
            goto lUDuh;
            tH4r6:
        }
        goto e_ptq;
        g0s0N:
        switch ($DqpTR) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $wl0gj = OjvWwjWRqBzIO::createFromScratch($Brk87, $DqpTR);
                goto Yd_QW;
            case 'mp4':
            case 'mov':
                $wl0gj = HVuLZHLrSam0d::createFromScratch($Brk87, $DqpTR);
                goto Yd_QW;
            case 'pdf':
                $wl0gj = EqLr3PLlMLHwV::createFromScratch($Brk87, $DqpTR);
                goto Yd_QW;
            default:
                throw new DDrY5gI5aE4u5("not support file type {$DqpTR}");
        }
        goto sbCW5;
        EcSly:
    }
}
