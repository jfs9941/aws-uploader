<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Zgh3BZ2JVlG1A;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
final class X2HBGfsI2UG6f implements VideoPostHandleServiceInterface
{
    private $mRJMt;
    private $Mayr9;
    public function __construct(UploadServiceInterface $hLWRj, Filesystem $KI4Gx)
    {
        $this->mRJMt = $hLWRj;
        $this->Mayr9 = $KI4Gx;
    }
    public function saveMetadata(string $iG1wy, array $abL5U)
    {
        goto rK783;
        oLDpJ:
        throw new \Exception("AelPShnd8pMtD metadata store failed for unknown reason ... " . $iG1wy);
        goto R3Qt7;
        I6Q3c:
        $gsgj9['duration'] = $abL5U['duration'];
        goto AO93f;
        WX3fr:
        if (!isset($abL5U['resolution'])) {
            goto GvwfH;
        }
        goto xNZGx;
        Qn4aY:
        $gsgj9 = [];
        goto dW5dG;
        kaeXZ:
        if (!(isset($abL5U['change_status']) && $abL5U['change_status'])) {
            goto EY7pS;
        }
        goto DBglv;
        CX7Fb:
        unset($gsgj9['thumbnail']);
        goto CRWY1;
        dW5dG:
        if (!isset($abL5U['thumbnail_url'])) {
            goto bz0Xi;
        }
        goto qbyix;
        yiL_Y:
        bz0Xi:
        goto WsvpR;
        gHlk6:
        try {
            goto jlaCK;
            Bt524:
            $gsgj9['thumbnail_id'] = $uTfBu['id'];
            goto Ztf1z;
            Ztf1z:
            $gsgj9['thumbnail'] = $uTfBu['filename'];
            goto vGSqA;
            jlaCK:
            $uTfBu = $this->mRJMt->storeSingleFile(new class($abL5U['thumbnail']) implements SingleUploadInterface
            {
                private $y_eVA;
                public function __construct($D55CH)
                {
                    $this->y_eVA = $D55CH;
                }
                public function getFile()
                {
                    return $this->y_eVA;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto Bt524;
            vGSqA:
        } catch (\Throwable $wEHhy) {
            Log::warning("AelPShnd8pMtD thumbnail store failed: " . $wEHhy->getMessage());
        }
        goto DrxTE;
        CflZj:
        jg4sa:
        goto U0U5O;
        U0U5O:
        if (!$aHaxS->AN0O0) {
            goto sQsjK;
        }
        goto CX7Fb;
        xNZGx:
        $gsgj9['resolution'] = $abL5U['resolution'];
        goto c4qhj;
        DBglv:
        $this->mRJMt->updateFile($aHaxS->getAttribute('id'), Zgh3BZ2JVlG1A::PROCESSING);
        goto jGVNJ;
        TXVSE:
        return $aHaxS->getView();
        goto jnW4h;
        DrxTE:
        ahLbZ:
        goto i93UX;
        c4qhj:
        GvwfH:
        goto punW1;
        i93UX:
        if (!isset($abL5U['duration'])) {
            goto SsMOP;
        }
        goto I6Q3c;
        rK783:
        $aHaxS = AelPShnd8pMtD::findOrFail($iG1wy);
        goto Qn4aY;
        jGVNJ:
        EY7pS:
        goto TXVSE;
        AO93f:
        SsMOP:
        goto WX3fr;
        sw27h:
        Log::warning("AelPShnd8pMtD metadata store failed for unknown reason ... " . $iG1wy);
        goto oLDpJ;
        WsvpR:
        if (!isset($abL5U['thumbnail'])) {
            goto ahLbZ;
        }
        goto gHlk6;
        punW1:
        if (!isset($abL5U['fps'])) {
            goto jg4sa;
        }
        goto nq1SQ;
        nq1SQ:
        $gsgj9['fps'] = $abL5U['fps'];
        goto CflZj;
        jnW4h:
        Z81zW:
        goto sw27h;
        qbyix:
        $gsgj9['thumbnail'] = $abL5U['thumbnail_url'];
        goto yiL_Y;
        DCL5O:
        if (!$aHaxS->update($gsgj9)) {
            goto Z81zW;
        }
        goto kaeXZ;
        CRWY1:
        sQsjK:
        goto DCL5O;
        R3Qt7:
    }
    public function createThumbnail(string $oxSbd) : void
    {
        goto C_2YG;
        XjBJd:
        twyGi:
        goto Ji2Ph;
        ShtxI:
        try {
            goto baj0K;
            baj0K:
            $SNiW3 = $iSaLT->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto oniXF;
            gBn3U:
            $iSaLT->sendMessage(['QueueUrl' => $IbfLd, 'MessageBody' => json_encode(['file_path' => $aHaxS->getLocation()])]);
            goto czL9V;
            oniXF:
            $IbfLd = $SNiW3->get('QueueUrl');
            goto gBn3U;
            czL9V:
        } catch (\Throwable $WqnXx) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$WqnXx->getMessage()}");
        }
        goto XjBJd;
        vJ52L:
        $aHaxS = AelPShnd8pMtD::findOrFail($oxSbd);
        goto K_gu2;
        K_gu2:
        $m7qW2 = "v2/hls/thumbnails/{$oxSbd}/";
        goto Pj00r;
        C_2YG:
        Log::info("Use Lambda to generate thumbnail for video: " . $oxSbd);
        goto vJ52L;
        dLccy:
        $iSaLT = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto ShtxI;
        Pj00r:
        if (!(!$this->Mayr9->directoryExists($m7qW2) && empty($aHaxS->mRBsoAr161k()))) {
            goto twyGi;
        }
        goto dLccy;
        Ji2Ph:
    }
    public function mWogVSj1Rqg(string $oxSbd) : void
    {
        goto Vynu5;
        NE4Qu:
        $aHaxS->update(['generated_previews' => $m7qW2]);
        goto PVm2W;
        Vynu5:
        $aHaxS = AelPShnd8pMtD::findOrFail($oxSbd);
        goto KvE6u;
        Gc0B4:
        if (!(count($ycEz7) === 0)) {
            goto hxWaC;
        }
        goto in0q4;
        aWr6R:
        $ycEz7 = $this->Mayr9->files($m7qW2);
        goto Gc0B4;
        SzDMw:
        Log::error("Message back with success data but not found thumbnail " . $oxSbd);
        goto nJbRY;
        OQb1P:
        naYf1:
        goto aWr6R;
        G_eif:
        if ($this->Mayr9->directoryExists($m7qW2)) {
            goto naYf1;
        }
        goto SzDMw;
        in0q4:
        Log::error("Message back with success data but not found thumbnail files " . $oxSbd);
        goto EnQb2;
        EnQb2:
        throw new \Exception("Message back with success data but not found thumbnail files " . $oxSbd);
        goto L8ns3;
        KvE6u:
        $m7qW2 = "v2/hls/thumbnails/{$oxSbd}/";
        goto G_eif;
        L8ns3:
        hxWaC:
        goto NE4Qu;
        nJbRY:
        throw new \Exception("Message back with success data but not found thumbnail " . $oxSbd);
        goto OQb1P;
        PVm2W:
    }
    public function getThumbnails(string $oxSbd) : array
    {
        $aHaxS = AelPShnd8pMtD::findOrFail($oxSbd);
        return $aHaxS->getThumbnails();
    }
    public function getMedia(string $oxSbd) : array
    {
        $mCZRt = Media::findOrFail($oxSbd);
        return $mCZRt->getView();
    }
}
