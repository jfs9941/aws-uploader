<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\WZhCwGsxQbxug;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Core\Observer\QLAmEQUR3Bkiu;
use Jfs\Uploader\Core\Observer\HpKIPTLevxmbx;
use Jfs\Uploader\Core\UF7LVTTMiEHny;
use Jfs\Uploader\Core\Ds7G2MSK6KX1Y;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
use Jfs\Uploader\Exception\WpKhE6K2C9AsD;
use Jfs\Uploader\Exception\Ki9g9bsseJGaK;
use Jfs\Uploader\Service\FileResolver\FgPa7IfKHhnis;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class G0pnBs62axPuz
{
    private $ZiPPZ;
    private $qqmnq;
    private $SxfKN;
    public function __construct($IIWT_, $vS8UC, $DPWG1)
    {
        goto qMzFW;
        qMzFW:
        $this->ZiPPZ = $IIWT_;
        goto xepA3;
        yM6mt:
        $this->SxfKN = $DPWG1;
        goto OWXea;
        xepA3:
        $this->qqmnq = $vS8UC;
        goto yM6mt;
        OWXea:
    }
    public function mmjnDwnp1Ap($Rp8Gx)
    {
        goto DorFI;
        DorFI:
        if (!$Rp8Gx instanceof SingleUploadInterface) {
            goto CRa7i;
        }
        goto wblu3;
        wblu3:
        $i7L5v = $Rp8Gx->getFile();
        goto Bny7T;
        VPj9z:
        return $this->mkRkPkkVYRW($Rp8Gx['file_extension'], 's3' === $Rp8Gx['driver'] ? CUySMhqlL7P49::S3 : CUySMhqlL7P49::LOCAL);
        goto P1rlH;
        Bny7T:
        return $this->mkRkPkkVYRW($i7L5v->extension(), CUySMhqlL7P49::S3, null, $Rp8Gx->options());
        goto FfUsy;
        FfUsy:
        CRa7i:
        goto VPj9z;
        P1rlH:
    }
    public function miU2tSnkH6P(string $GMwD5)
    {
        goto RybKo;
        cI0OP:
        $RB3Ub->setRawAttributes($WFvTF->getAttributes());
        goto VI4d_;
        VFk25:
        $RB3Ub = $this->mkRkPkkVYRW($WFvTF->getAttribute('type'), $WFvTF->getAttribute('driver'), $WFvTF->getAttribute('id'));
        goto f07fu;
        VI4d_:
        return $RB3Ub;
        goto jsH_N;
        f07fu:
        $RB3Ub->exists = true;
        goto cI0OP;
        RybKo:
        $WFvTF = config('upload.attachment_model')::findOrFail($GMwD5);
        goto VFk25;
        jsH_N:
    }
    public function mUduealZH9C(string $V7otT) : WZhCwGsxQbxug
    {
        goto tCWsp;
        vHtmB:
        $wt893 = json_decode($whzw2, true);
        goto ybWUd;
        d1ayu:
        return $this->mkRkPkkVYRW($Az4fW->vGRMi, $Az4fW->mbFbAgrHdil(), $Az4fW->filename);
        goto zmVZt;
        jtlhJ:
        throw new WpKhE6K2C9AsD('metadata file not found');
        goto hZeJf;
        tCWsp:
        $whzw2 = $this->qqmnq->get($V7otT);
        goto qTbRE;
        CiiKX:
        RxpMI:
        goto vHtmB;
        ybWUd:
        if (!$wt893) {
            goto TwXwb;
        }
        goto S8SBY;
        f_JZ4:
        $whzw2 = $this->SxfKN->get($V7otT);
        goto CiiKX;
        S8SBY:
        $Az4fW = Ds7G2MSK6KX1Y::mpjDCoOJz5V($wt893);
        goto d1ayu;
        qTbRE:
        if ($whzw2) {
            goto RxpMI;
        }
        goto f_JZ4;
        zmVZt:
        TwXwb:
        goto jtlhJ;
        hZeJf:
    }
    private function mkRkPkkVYRW(string $ML_Yw, $zQRzn, ?string $GMwD5 = null, array $ky5s4 = [])
    {
        goto VBVxx;
        drRhp:
        switch ($ML_Yw) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $I0nV2 = C6ftQJKUZRJIp::createFromScratch($GMwD5, $ML_Yw);
                goto FH8iN;
            case 'mp4':
            case 'mov':
                $I0nV2 = RhdJGUi8FOLBJ::createFromScratch($GMwD5, $ML_Yw);
                goto FH8iN;
            case 'pdf':
                $I0nV2 = UF7LVTTMiEHny::createFromScratch($GMwD5, $ML_Yw);
                goto FH8iN;
            default:
                throw new Ki9g9bsseJGaK("not support file type {$ML_Yw}");
        }
        goto TW7RF;
        da2bP:
        $I0nV2 = $I0nV2->maQCLDNolDd($zQRzn);
        goto RXdNX;
        AqA5a:
        foreach ($this->ZiPPZ as $LmP6O) {
            goto GUv67;
            GUv67:
            if (!$LmP6O->mEvcd0RuR8y($I0nV2)) {
                goto vFDkA;
            }
            goto nIBXZ;
            EfCnr:
            R31Mq:
            goto hq6_V;
            I4UgT:
            vFDkA:
            goto EfCnr;
            nIBXZ:
            return $I0nV2->initLocation($LmP6O->mRy05oXxdyH($I0nV2));
            goto I4UgT;
            hq6_V:
        }
        goto RYsLA;
        RXdNX:
        $I0nV2->mmI31EdIVP7(new QLAmEQUR3Bkiu($I0nV2));
        goto YCJd2;
        RYsLA:
        E2W2_:
        goto xPpun;
        xPpun:
        throw new Ki9g9bsseJGaK("not support file type {$ML_Yw}");
        goto IiJIL;
        YCJd2:
        $I0nV2->mmI31EdIVP7(new HpKIPTLevxmbx($I0nV2, $this->SxfKN, $ky5s4));
        goto AqA5a;
        VBVxx:
        $GMwD5 = $GMwD5 ?? Uuid::uuid4()->getHex()->toString();
        goto drRhp;
        OUrBs:
        FH8iN:
        goto da2bP;
        TW7RF:
        pZLgi:
        goto OUrBs;
        IiJIL:
    }
}
