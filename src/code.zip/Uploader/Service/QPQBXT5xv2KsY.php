<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Jfs\Uploader\Contracts\N41GICKeJz2js;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Core\Observer\FJEG2eFHx6sNT;
use Jfs\Uploader\Core\Observer\LdIwI6jiZcVmK;
use Jfs\Uploader\Core\C1MO7dubi2ia5;
use Jfs\Uploader\Core\YBVw3piEGeLeh;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
use Jfs\Uploader\Exception\MNuvuj1rJR1Zc;
use Jfs\Uploader\Exception\RlwRtWSVPtDAe;
use Jfs\Uploader\Service\FileResolver\FWwhMhsKRtjS2;
use Illuminate\Contracts\Filesystem\Filesystem;
use Ramsey\Uuid\Uuid;
final class QPQBXT5xv2KsY
{
    private $aKqd6;
    private $TD3CW;
    private $Mayr9;
    public function __construct($wFngj, $e3uVO, $KI4Gx)
    {
        goto GKku1;
        GKku1:
        $this->aKqd6 = $wFngj;
        goto dLQ1r;
        TwE6T:
        $this->Mayr9 = $KI4Gx;
        goto D42ac;
        dLQ1r:
        $this->TD3CW = $e3uVO;
        goto TwE6T;
        D42ac:
    }
    public function mOQnSHMUPr0($ZtnJ6)
    {
        goto Tbpcj;
        v4YPQ:
        $RBuRN = $ZtnJ6->getFile();
        goto L1YQS;
        L1YQS:
        return $this->mLDIsTmYdQt($RBuRN->extension(), Ef6Dy6MoUDei9::S3, null, $ZtnJ6->options());
        goto wobKF;
        mtIQO:
        return $this->mLDIsTmYdQt($ZtnJ6['file_extension'], 's3' === $ZtnJ6['driver'] ? Ef6Dy6MoUDei9::S3 : Ef6Dy6MoUDei9::LOCAL);
        goto nHmSK;
        Tbpcj:
        if (!$ZtnJ6 instanceof SingleUploadInterface) {
            goto oEHRH;
        }
        goto v4YPQ;
        wobKF:
        oEHRH:
        goto mtIQO;
        nHmSK:
    }
    public function m8vjbo9rPgc(string $iG1wy)
    {
        goto DAxrY;
        DAxrY:
        $UTk4B = config('upload.attachment_model')::findOrFail($iG1wy);
        goto WcDvL;
        WcDvL:
        $D55CH = $this->mLDIsTmYdQt($UTk4B->getAttribute('type'), $UTk4B->getAttribute('driver'), $UTk4B->getAttribute('id'));
        goto apA_Y;
        OXBje:
        return $D55CH;
        goto Xb1uM;
        Iwvcc:
        $D55CH->setRawAttributes($UTk4B->getAttributes());
        goto OXBje;
        apA_Y:
        $D55CH->exists = true;
        goto Iwvcc;
        Xb1uM:
    }
    public function mpNfVM2pYHG(string $IdzzX) : N41GICKeJz2js
    {
        goto vOXJt;
        vOXJt:
        $jVvw_ = $this->TD3CW->get($IdzzX);
        goto JHqne;
        OX1WK:
        $SQ5qY = YBVw3piEGeLeh::mQaSFCvGTKs($abL5U);
        goto h5iMz;
        tI6Pf:
        xE5E4:
        goto ERalg;
        h5iMz:
        return $this->mLDIsTmYdQt($SQ5qY->SeCMC, $SQ5qY->mPpnX73VLhM(), $SQ5qY->filename);
        goto tI6Pf;
        U2MEj:
        $jVvw_ = $this->Mayr9->get($IdzzX);
        goto udvp7;
        ERalg:
        throw new MNuvuj1rJR1Zc('metadata file not found');
        goto Lkma0;
        udvp7:
        zzuts:
        goto ZOwoQ;
        VSC1j:
        if (!$abL5U) {
            goto xE5E4;
        }
        goto OX1WK;
        JHqne:
        if ($jVvw_) {
            goto zzuts;
        }
        goto U2MEj;
        ZOwoQ:
        $abL5U = json_decode($jVvw_, true);
        goto VSC1j;
        Lkma0:
    }
    private function mLDIsTmYdQt(string $oUNBD, $ThqLD, ?string $iG1wy = null, array $Fsmva = [])
    {
        goto XNjAN;
        Z2hdE:
        $YI8Nz->mQp3zHVoxcU(new LdIwI6jiZcVmK($YI8Nz, $this->Mayr9, $Fsmva));
        goto ln6_s;
        kxFmK:
        Ls6fH:
        goto n1XZU;
        ovvE7:
        throw new RlwRtWSVPtDAe("not support file type {$oUNBD}");
        goto HRjSG;
        tPLfx:
        A6vmb:
        goto ovvE7;
        ln6_s:
        foreach ($this->aKqd6 as $paMBW) {
            goto COGbf;
            XbrbU:
            bKTOb:
            goto bdURE;
            GJ7Uj:
            return $YI8Nz->initLocation($paMBW->mYoRGITjmKk($YI8Nz));
            goto i5OFa;
            COGbf:
            if (!$paMBW->mBw7y4FcoRu($YI8Nz)) {
                goto UnKjH;
            }
            goto GJ7Uj;
            i5OFa:
            UnKjH:
            goto XbrbU;
            bdURE:
        }
        goto tPLfx;
        OAmKC:
        $YI8Nz->mQp3zHVoxcU(new FJEG2eFHx6sNT($YI8Nz));
        goto Z2hdE;
        n1XZU:
        $YI8Nz = $YI8Nz->mFyJYzfzJa3($ThqLD);
        goto OAmKC;
        abrym:
        N9mgZ:
        goto kxFmK;
        XNjAN:
        $iG1wy = $iG1wy ?? Uuid::uuid4()->getHex()->toString();
        goto x6wlr;
        x6wlr:
        switch ($oUNBD) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $YI8Nz = KyoDVfv3eGItF::createFromScratch($iG1wy, $oUNBD);
                goto Ls6fH;
            case 'mp4':
            case 'mov':
                $YI8Nz = AelPShnd8pMtD::createFromScratch($iG1wy, $oUNBD);
                goto Ls6fH;
            case 'pdf':
                $YI8Nz = C1MO7dubi2ia5::createFromScratch($iG1wy, $oUNBD);
                goto Ls6fH;
            default:
                throw new RlwRtWSVPtDAe("not support file type {$oUNBD}");
        }
        goto abrym;
        HRjSG:
    }
}
