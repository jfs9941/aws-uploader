<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class CXtUsGmTZ8ucb implements StoreVideoToS3JobInterface
{
    private $M06vn;
    private $bwFb2;
    private $k4mhD;
    public function __construct($XhEIi, $dR_xe, $ixEuN)
    {
        goto I3eP0;
        Gtrwf:
        $this->k4mhD = $ixEuN;
        goto LGV12;
        LGV12:
        $this->M06vn = $XhEIi;
        goto Q4W18;
        I3eP0:
        $this->bwFb2 = $dR_xe;
        goto Gtrwf;
        Q4W18:
    }
    public function store(string $G2Ngo) : void
    {
        goto m5SWy;
        DMWly:
        ini_set('memory_limit', '-1');
        goto y04JW;
        v_MBW:
        if ($EGnbr) {
            goto f3CGD;
        }
        goto aV3Rf;
        O1mHD:
        return;
        goto c5MPJ;
        aV3Rf:
        Log::info("UZrSkD9d5TXs1 has been deleted, discard it", ['fileId' => $G2Ngo]);
        goto wUrvN;
        DvkNK:
        $rDUTV = 1024 * 1024 * 50;
        goto sOz0r;
        WDoCo:
        $EGnbr = UZrSkD9d5TXs1::find($G2Ngo);
        goto v_MBW;
        aAYTI:
        $ixEuN = $this->k4mhD;
        goto WDoCo;
        xhXyY:
        $rV4t7 = microtime(true);
        goto iWvOR;
        z9vOT:
        if ($ixEuN->exists($EGnbr->getLocation())) {
            goto NzgN2;
        }
        goto scFGh;
        PK80t:
        try {
            goto s44SU;
            riysF:
            goto qHFV5;
            goto uUOKY;
            oYFnp:
            $ixEuN->delete($EGnbr->getLocation());
            goto vnSzr;
            NzNq3:
            if (feof($p4tN1)) {
                goto uO5xe;
            }
            goto Pe9MY;
            yEq9O:
            $wJ3ay = 1;
            goto lHXVN;
            s44SU:
            $x53s1 = $TrPq0->createMultipartUpload(['Bucket' => $this->M06vn, 'Key' => $EGnbr->getLocation(), 'ContentType' => $gKC0c, 'ContentDisposition' => 'inline']);
            goto aaayA;
            JsDty:
            $wJ3ay++;
            goto riysF;
            lHXVN:
            $haCEo = [];
            goto sQcOV;
            aaayA:
            $JC43m = $x53s1['UploadId'];
            goto yEq9O;
            sQcOV:
            qHFV5:
            goto NzNq3;
            Pe9MY:
            $oj8TY = $TrPq0->uploadPart(['Bucket' => $this->M06vn, 'Key' => $EGnbr->getLocation(), 'UploadId' => $JC43m, 'PartNumber' => $wJ3ay, 'Body' => fread($p4tN1, $rDUTV)]);
            goto LEgQu;
            uUOKY:
            uO5xe:
            goto NKYou;
            I4RQ4:
            $TrPq0->completeMultipartUpload(['Bucket' => $this->M06vn, 'Key' => $EGnbr->getLocation(), 'UploadId' => $JC43m, 'MultipartUpload' => ['Parts' => $haCEo]]);
            goto d2Cvi;
            d2Cvi:
            $EGnbr->update(['driver' => BHGv9oAB1EERw::S3, 'status' => YGB86F7VDD6Xo::FINISHED]);
            goto oYFnp;
            NKYou:
            fclose($p4tN1);
            goto I4RQ4;
            LEgQu:
            $haCEo[] = ['PartNumber' => $wJ3ay, 'ETag' => $oj8TY['ETag']];
            goto JsDty;
            vnSzr:
        } catch (AwsException $evr4M) {
            goto Stb_S;
            N2Ytr:
            jIGt6:
            goto kvZpm;
            Stb_S:
            if (!isset($JC43m)) {
                goto jIGt6;
            }
            goto VnXIL;
            kvZpm:
            Log::error('Failed to store video: ' . $EGnbr->getLocation() . ' - ' . $evr4M->getMessage());
            goto SpMwE;
            VnXIL:
            try {
                $TrPq0->abortMultipartUpload(['Bucket' => $this->M06vn, 'Key' => $EGnbr->getLocation(), 'UploadId' => $JC43m]);
            } catch (AwsException $GufR2) {
                Log::error('Error aborting multipart upload: ' . $GufR2->getMessage());
            }
            goto N2Ytr;
            SpMwE:
        } finally {
            $StTlK = microtime(true);
            $gljc1 = memory_get_usage();
            $eIfFK = memory_get_peak_usage();
            Log::info('Store UZrSkD9d5TXs1 to S3 function resource usage', ['imageId' => $G2Ngo, 'execution_time_sec' => $StTlK - $rV4t7, 'memory_usage_mb' => ($gljc1 - $yxfF3) / 1024 / 1024, 'peak_memory_usage_mb' => ($eIfFK - $MDCwv) / 1024 / 1024]);
        }
        goto lrTw2;
        wUrvN:
        return;
        goto XhK4p;
        XhK4p:
        f3CGD:
        goto z9vOT;
        YGx4d:
        $MDCwv = memory_get_peak_usage();
        goto PK80t;
        c5MPJ:
        NzgN2:
        goto Sm1Fx;
        sOz0r:
        $gKC0c = $ixEuN->mimeType($EGnbr->getLocation());
        goto xhXyY;
        m5SWy:
        Log::info('Storing video (local) to S3', ['fileId' => $G2Ngo, 'bucketName' => $this->M06vn]);
        goto DMWly;
        Sm1Fx:
        $p4tN1 = $ixEuN->readStream($EGnbr->getLocation());
        goto DvkNK;
        scFGh:
        Log::error("[CXtUsGmTZ8ucb] File not found, discard it ", ['video' => $EGnbr->getLocation()]);
        goto O1mHD;
        y04JW:
        $TrPq0 = $this->bwFb2->getClient();
        goto aAYTI;
        iWvOR:
        $yxfF3 = memory_get_usage();
        goto YGx4d;
        lrTw2:
    }
}
