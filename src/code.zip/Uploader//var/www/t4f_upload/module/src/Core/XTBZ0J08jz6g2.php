<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Uploader\Enum\IoCBJqqLig917;
final class XTBZ0J08jz6g2
{
    public $filename;
    public $OBJgU;
    public $kitse;
    public $t5_u0;
    public $D3XQc;
    public $pfuuj;
    public $kIsdK;
    public $status;
    public $ROItB;
    public $dzUxu;
    public $dduPi = 's3';
    public $l2MEk = [];
    public function __construct($CNNtA, $Z5How, $xjved, $N5vGY, $t16Bz, $vBE45, $W6NvJ, $XpJag, $HGoYr, $apWXG, $izVKZ = 's3', $O9jdF = [])
    {
        goto knvjT;
        ylm6n:
        $this->pfuuj = $vBE45;
        goto EJrdt;
        CqOTj:
        $this->dzUxu = $apWXG;
        goto mvYZI;
        EJrdt:
        $this->kIsdK = $W6NvJ;
        goto chI4H;
        chI4H:
        $this->status = $XpJag;
        goto z35BF;
        gAvUK:
        $this->kitse = $xjved;
        goto kNrkU;
        S_w0f:
        $this->OBJgU = $Z5How;
        goto gAvUK;
        Fref0:
        $this->D3XQc = $t16Bz;
        goto ylm6n;
        mvYZI:
        $this->dduPi = $izVKZ;
        goto emJcf;
        emJcf:
        $this->l2MEk = $O9jdF;
        goto BtwKu;
        kNrkU:
        $this->t5_u0 = $N5vGY;
        goto Fref0;
        z35BF:
        $this->ROItB = $HGoYr;
        goto CqOTj;
        knvjT:
        $this->filename = $CNNtA;
        goto S_w0f;
        BtwKu:
    }
    private static function mhzSwvvOMZY() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mZ9br4dQRkh() : array
    {
        return array_flip(self::mhzSwvvOMZY());
    }
    public function toArray() : array
    {
        $ihaWN = self::mhzSwvvOMZY();
        return [$ihaWN['filename'] => $this->filename, $ihaWN['fileExtension'] => $this->OBJgU, $ihaWN['mimeType'] => $this->kitse, $ihaWN['fileSize'] => $this->t5_u0, $ihaWN['chunkSize'] => $this->D3XQc, $ihaWN['checksums'] => $this->pfuuj, $ihaWN['totalChunk'] => $this->kIsdK, $ihaWN['status'] => $this->status, $ihaWN['userId'] => $this->ROItB, $ihaWN['uploadId'] => $this->dzUxu, $ihaWN['driver'] => $this->dduPi, $ihaWN['parts'] => $this->l2MEk];
    }
    public static function mwslghfePTb(array $aJZc4) : self
    {
        $YI5pa = array_flip(self::mZ9br4dQRkh());
        return new self($aJZc4[$YI5pa['filename']] ?? $aJZc4['filename'] ?? '', $aJZc4[$YI5pa['fileExtension']] ?? $aJZc4['fileExtension'] ?? '', $aJZc4[$YI5pa['mimeType']] ?? $aJZc4['mimeType'] ?? '', $aJZc4[$YI5pa['fileSize']] ?? $aJZc4['fileSize'] ?? 0, $aJZc4[$YI5pa['chunkSize']] ?? $aJZc4['chunkSize'] ?? 0, $aJZc4[$YI5pa['checksums']] ?? $aJZc4['checksums'] ?? [], $aJZc4[$YI5pa['totalChunk']] ?? $aJZc4['totalChunk'] ?? 0, $aJZc4[$YI5pa['status']] ?? $aJZc4['status'] ?? 0, $aJZc4[$YI5pa['userId']] ?? $aJZc4['userId'] ?? 0, $aJZc4[$YI5pa['uploadId']] ?? $aJZc4['uploadId'] ?? '', $aJZc4[$YI5pa['driver']] ?? $aJZc4['driver'] ?? 's3', $aJZc4[$YI5pa['parts']] ?? $aJZc4['parts'] ?? []);
    }
    public static function myImQtehpRT($fkX6b) : self
    {
        goto Gsp35;
        UzXb3:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto iNxQU;
        oc8A5:
        XcBHr:
        goto UzXb3;
        xlQSb:
        return self::mwslghfePTb($fkX6b);
        goto oc8A5;
        Gsp35:
        if (!(isset($fkX6b['fn']) || isset($fkX6b['fe']))) {
            goto XcBHr;
        }
        goto xlQSb;
        iNxQU:
    }
    public function m4KpNugol8f(string $apWXG) : void
    {
        $this->dzUxu = $apWXG;
    }
    public function mp2cpQG5SxY(array $O9jdF) : void
    {
        $this->l2MEk = $O9jdF;
    }
    public static function mF6fOqcw3uQ($m42Ed, $HszXi, $sFjFS, $HGoYr, $t16Bz, $vBE45, $izVKZ)
    {
        return new self($m42Ed->getFilename(), $m42Ed->getExtension(), $HszXi, $sFjFS, $t16Bz, $vBE45, count($vBE45), IoCBJqqLig917::UPLOADING, $HGoYr, 0, $izVKZ, []);
    }
    public static function mbTTXYu6dUz($C3gWL)
    {
        return 'metadata/' . $C3gWL . '.json';
    }
    public function mKE3VTU3YZK()
    {
        return 's3' === $this->dduPi ? YZ2lA0H3k4o6O::S3 : YZ2lA0H3k4o6O::LOCAL;
    }
}
