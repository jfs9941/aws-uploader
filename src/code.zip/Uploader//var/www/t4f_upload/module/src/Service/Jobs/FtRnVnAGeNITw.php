<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class FtRnVnAGeNITw implements GenerateThumbnailJobInterface
{
    const K6RHg = 150;
    const r36cV = 150;
    private $eE5H8;
    private $k4mhD;
    public function __construct($LCatz, $ixEuN)
    {
        $this->eE5H8 = $LCatz;
        $this->k4mhD = $ixEuN;
    }
    public function generate(string $G2Ngo)
    {
        goto DxM3Z;
        DxM3Z:
        Log::info("Generating thumbnail", ['imageId' => $G2Ngo]);
        goto OytOw;
        OytOw:
        ini_set('memory_limit', '-1');
        goto S81gW;
        S81gW:
        try {
            goto GONIY;
            e4ijC:
            unset($i1raP);
            goto v5w2f;
            GTlOF:
            Log::warning('Failed to set file permissions for stored image: ' . $euWMh);
            goto VNCYg;
            uEf6F:
            $BkP1c = $this->mgToDiXc5QE($LjRVY);
            goto DeMz2;
            uzn3G:
            $LjRVY->update(['thumbnail' => $BkP1c, 'status' => YGB86F7VDD6Xo::THUMBNAIL_PROCESSED]);
            goto oQN5n;
            oQN5n:
            $euWMh = $skn0D->path($BkP1c);
            goto Qjglp;
            Clil1:
            N2v1k:
            goto yTmDE;
            YMu5h:
            $i1raP = $this->eE5H8->call($this, $skn0D->path($LjRVY->getLocation()));
            goto P49zJ;
            P49zJ:
            $i1raP = $i1raP->orient()->resize(150, 150);
            goto uEf6F;
            v4pXx:
            $LjRVY = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
            goto YMu5h;
            DeMz2:
            $uMEJa = $skn0D->put($BkP1c, $i1raP->toWebp(70), ['visibility' => 'public']);
            goto e4ijC;
            VNCYg:
            throw new \Exception('Failed to set file permissions for stored image: ' . $euWMh);
            goto Clil1;
            GONIY:
            $skn0D = $this->k4mhD;
            goto v4pXx;
            Qjglp:
            if (chmod($euWMh, 0644)) {
                goto N2v1k;
            }
            goto GTlOF;
            yTmDE:
            L5rYH:
            goto nLcat;
            v5w2f:
            if (!($uMEJa !== false)) {
                goto L5rYH;
            }
            goto uzn3G;
            nLcat:
        } catch (ModelNotFoundException $evr4M) {
            Log::info("ZrqFFxIRVAAEU has been deleted, discard it", ['imageId' => $G2Ngo]);
            return;
        }
        goto P0jBS;
        P0jBS:
    }
    private function mgToDiXc5QE(VWfw9VfxzTDgS $LjRVY) : string
    {
        goto LwhH2;
        LwhH2:
        $BkP1c = $LjRVY->getLocation();
        goto PMh9W;
        PMh9W:
        $oYMhx = dirname($BkP1c);
        goto iMXyK;
        h4u2m:
        return $xO2gM . '/' . $LjRVY->getFilename() . '.jpg';
        goto fvybV;
        iMXyK:
        $xO2gM = $oYMhx . '/' . self::K6RHg . 'X' . self::r36cV;
        goto h4u2m;
        fvybV:
    }
}
