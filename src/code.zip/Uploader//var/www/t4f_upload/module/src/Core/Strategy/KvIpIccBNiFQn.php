<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Encoder\NLnbq513ssJFf;
class KvIpIccBNiFQn implements FileProcessingStrategyInterface
{
    private $lKuqW;
    private $qZ2Y_;
    private $gBXM3;
    public function __construct(TkBEwah2ZcKXB $A37bW, NLnbq513ssJFf $KwRPQ)
    {
        goto Cs5L1;
        qlPRb:
        $this->qZ2Y_ = $KwRPQ;
        goto fZbNo;
        Cs5L1:
        $this->lKuqW = $A37bW;
        goto qlPRb;
        OJksD:
        $this->gBXM3 = new $Na0s5($A37bW, $KwRPQ);
        goto KyGdH;
        fZbNo:
        $Na0s5 = config('upload.post_process_video');
        goto OJksD;
        KyGdH:
    }
    public function process($yO7fM)
    {
        $this->gBXM3->process($yO7fM);
    }
}
