<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Service\I2LnR7hUOOfvy;
final class DFtX4SxXxkHYz
{
    public const OIR8X = 'v2/hls/';
    private $x2AcY;
    private $bwFb2;
    public function __construct(I2LnR7hUOOfvy $wrTQA, Filesystem $dR_xe)
    {
        $this->x2AcY = $wrTQA;
        $this->bwFb2 = $dR_xe;
    }
    public function mK2m1HH3DXA($KdniT) : string
    {
        return $this->x2AcY->mgW507kxn2Z(self::OIR8X . $KdniT->getAttribute('id') . '/');
    }
    public function mwSlek9GVG5($KdniT) : string
    {
        return $this->x2AcY->mgW507kxn2Z(self::OIR8X . $KdniT->getAttribute('id') . '/thumbnail/');
    }
    public function mkQOe10nLnu($KdniT, $WxKDn = true) : string
    {
        goto TYeeY;
        R71x1:
        return self::OIR8X . $KdniT->getAttribute('id') . '/' . $KdniT->getAttribute('id') . '.m3u8';
        goto KtLeq;
        xZqXP:
        return $this->x2AcY->mgW507kxn2Z(self::OIR8X . $KdniT->getAttribute('id') . '/' . $KdniT->getAttribute('id') . '.m3u8');
        goto DkR77;
        KtLeq:
        cfpCN:
        goto xZqXP;
        TYeeY:
        if ($WxKDn) {
            goto cfpCN;
        }
        goto R71x1;
        DkR77:
    }
    public function resolveThumbnail($KdniT) : string
    {
        goto nM0Wm;
        nM0Wm:
        $G2Ngo = $KdniT->getAttribute('id');
        goto C_X6Y;
        C_X6Y:
        $tNYad = $this->bwFb2->files($this->mwSlek9GVG5($KdniT));
        goto eAG50;
        eAG50:
        return 1 == count($tNYad) ? self::OIR8X . $G2Ngo . '/thumbnail/' . $G2Ngo . '.0000000.jpg' : self::OIR8X . $G2Ngo . '/thumbnail/' . $G2Ngo . '.0000001.jpg';
        goto gjbN1;
        gjbN1:
    }
    public function m1ozdmpClqx(string $BkP1c) : string
    {
        return $this->bwFb2->url($BkP1c);
    }
}
