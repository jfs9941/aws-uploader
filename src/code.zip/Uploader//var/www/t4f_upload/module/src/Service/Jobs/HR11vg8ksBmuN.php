<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class HR11vg8ksBmuN
{
    private $zzXQW;
    private $nzim4;
    public function __construct(int $xLkML, int $s_SEB)
    {
        goto aIQl3;
        CCJdk:
        oE4_u:
        goto pFuoX;
        YS1PE:
        Qj87a:
        goto rkFyQ;
        TGnHT:
        $this->nzim4 = $s_SEB;
        goto g2uyt;
        aIQl3:
        if (!($xLkML <= 0)) {
            goto oE4_u;
        }
        goto bGB29;
        bGB29:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto CCJdk;
        pFuoX:
        if (!($s_SEB <= 0)) {
            goto Qj87a;
        }
        goto QZf0n;
        rkFyQ:
        $this->zzXQW = $xLkML;
        goto TGnHT;
        QZf0n:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto YS1PE;
        g2uyt:
    }
    private static function mWeSwv9jP8m($ZyEq6, string $lD3o1 = 'floor') : int
    {
        goto AuBgD;
        AuBgD:
        if (!(is_int($ZyEq6) && $ZyEq6 % 2 === 0)) {
            goto Ac46S;
        }
        goto lLaXX;
        TGVC1:
        Ac46S:
        goto JNuWE;
        Qs82P:
        UuykO:
        goto KSPpT;
        RuUEj:
        return (int) $ZyEq6;
        goto Qs82P;
        JgsTU:
        VJa5Y:
        goto isFcd;
        JNuWE:
        if (!(is_float($ZyEq6) && $ZyEq6 == floor($ZyEq6) && (int) $ZyEq6 % 2 === 0)) {
            goto UuykO;
        }
        goto RuUEj;
        KSPpT:
        switch (strtolower($lD3o1)) {
            case 'ceil':
                return (int) (ceil($ZyEq6 / 2) * 2);
            case 'round':
                return (int) (round($ZyEq6 / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($ZyEq6 / 2) * 2);
        }
        goto JgsTU;
        isFcd:
        z87Vs:
        goto S30lY;
        lLaXX:
        return $ZyEq6;
        goto TGVC1;
        S30lY:
    }
    public function mdqDpr44qfj(string $dSq8S = 'floor') : array
    {
        goto LPJGy;
        lpjCn:
        $lggLN = $mgGn9;
        goto UGKwj;
        xOeZA:
        eT5L3:
        goto P9cCZ;
        tkfUy:
        Yh_Jn:
        goto QvIHP;
        wcOb4:
        $K52qb = self::mWeSwv9jP8m(round($Yh_DQ), $dSq8S);
        goto YDRr8;
        N7aI4:
        if ($this->zzXQW >= $this->nzim4) {
            goto JULMR;
        }
        goto lpjCn;
        WY3Xo:
        $lggLN = self::mWeSwv9jP8m(round($fllv8), $dSq8S);
        goto l54ne;
        ggj7r:
        $fllv8 = $this->zzXQW * $mzWb0;
        goto WY3Xo;
        W8j32:
        JULMR:
        goto uU9DB;
        QvIHP:
        if (!($K52qb < 2)) {
            goto eT5L3;
        }
        goto J31nc;
        P9cCZ:
        return ['width' => $lggLN, 'height' => $K52qb];
        goto QDKeW;
        LPJGy:
        $mgGn9 = 1080;
        goto hgTR8;
        facus:
        $mzWb0 = $K52qb / $this->nzim4;
        goto ggj7r;
        J31nc:
        $K52qb = 2;
        goto xOeZA;
        sgPXz:
        if (!($lggLN < 2)) {
            goto Yh_Jn;
        }
        goto onRim;
        hgTR8:
        $lggLN = 0;
        goto gLPAr;
        l54ne:
        Ut2xV:
        goto sgPXz;
        YDRr8:
        goto Ut2xV;
        goto W8j32;
        UGKwj:
        $mzWb0 = $lggLN / $this->zzXQW;
        goto Fv_Ji;
        uU9DB:
        $K52qb = $mgGn9;
        goto facus;
        gLPAr:
        $K52qb = 0;
        goto N7aI4;
        onRim:
        $lggLN = 2;
        goto tkfUy;
        Fv_Ji:
        $Yh_DQ = $this->nzim4 * $mzWb0;
        goto wcOb4;
        QDKeW:
    }
}
