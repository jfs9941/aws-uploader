<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Contracts\SZm1UTyVUjPKK;
use Jfs\Uploader\Core\Traits\YzdWeu2LiemYK;
use Jfs\Uploader\Core\Traits\PNxZ9iFoUyPar;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Service\TTmP5DEq3oRIl;
class Il0T1UmENcpfh extends TWXq4PCBxnKLl implements PwKw6a6OizPW3
{
    use YzdWeu2LiemYK;
    use PNxZ9iFoUyPar;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $mRgNN, string $PavIR) : self
    {
        goto x41I9;
        NlsqA:
        $qj00p->m7j1OyKKnp8(OHa83BAIlECUz::UPLOADING);
        goto IzJv0;
        x41I9:
        $qj00p = new self(['id' => $mRgNN, 'type' => $PavIR, 'status' => OHa83BAIlECUz::UPLOADING]);
        goto NlsqA;
        IzJv0:
        return $qj00p;
        goto xXYsH;
        xXYsH:
    }
    public function getView() : array
    {
        $R0E9F = app(SZm1UTyVUjPKK::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $R0E9F->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $R0E9F->resolveThumbnail($this)];
    }
    public static function mXcR490FEJb(TWXq4PCBxnKLl $HRuZr) : Il0T1UmENcpfh
    {
        goto k9OMq;
        k9OMq:
        if (!$HRuZr instanceof Il0T1UmENcpfh) {
            goto PwNUw;
        }
        goto opKt8;
        ofqzB:
        return (new Il0T1UmENcpfh())->fill($HRuZr->getAttributes());
        goto N6wzO;
        woPe1:
        PwNUw:
        goto ofqzB;
        opKt8:
        return $HRuZr;
        goto woPe1;
        N6wzO:
    }
}
