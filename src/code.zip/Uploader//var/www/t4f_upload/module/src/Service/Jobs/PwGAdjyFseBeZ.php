<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
class PwGAdjyFseBeZ implements BlurVideoJobInterface
{
    const mXS9Z = 15;
    const POx3B = 500;
    const kdaR_ = 500;
    private $LPCI1;
    private $j_caY;
    private $NBa8l;
    public function __construct($VzMzb, $nFXer, $J2eOE)
    {
        goto ly3B8;
        fQ2wc:
        $this->j_caY = $nFXer;
        goto T2ecD;
        T2ecD:
        $this->LPCI1 = $VzMzb;
        goto iHBHj;
        ly3B8:
        $this->NBa8l = $J2eOE;
        goto fQ2wc;
        iHBHj:
    }
    public function blur(string $W0vWP) : void
    {
        goto WeEcg;
        Nimy7:
        if (chmod($Yqb0Z, 0664)) {
            goto yjQyH;
        }
        goto aXeVP;
        ruurm:
        $qj00p->blur(self::mXS9Z);
        goto LNWJt;
        WeEcg:
        Log::info("Blurring for video", ['videoID' => $W0vWP]);
        goto EqfkO;
        KMOfS:
        $qj00p = $this->LPCI1->call($this, $this->NBa8l->path($PyyUx->getAttribute('thumbnail')));
        goto sBHtZ;
        aXeVP:
        \Log::warning('Failed to set final permissions on image file: ' . $Yqb0Z);
        goto mX57y;
        C2GEx:
        yhX3b:
        goto nJjUZ;
        EqfkO:
        ini_set('memory_limit', '-1');
        goto Sw5dR;
        Dae7r:
        $Yqb0Z = $this->NBa8l->path($Mtf3A);
        goto NCOfP;
        NCOfP:
        $qj00p->save($Yqb0Z);
        goto VA0in;
        wJ2fO:
        if (!$PyyUx->getAttribute('thumbnail')) {
            goto yhX3b;
        }
        goto KNi7Z;
        W4Pbk:
        $PyyUx->update(['preview' => $Mtf3A]);
        goto C2GEx;
        VA0in:
        $this->j_caY->put($Mtf3A, $this->NBa8l->get($Mtf3A));
        goto tpRVy;
        jUvXJ:
        yjQyH:
        goto W4Pbk;
        tAxBO:
        $qj00p->resize(self::POx3B, self::kdaR_ / $rOwJo);
        goto ruurm;
        sBHtZ:
        $rOwJo = $qj00p->width() / $qj00p->height();
        goto tAxBO;
        tpRVy:
        unset($qj00p);
        goto Nimy7;
        mX57y:
        throw new \Exception('Failed to set final permissions on image file: ' . $Yqb0Z);
        goto jUvXJ;
        LNWJt:
        $Mtf3A = $this->m7fMCesQdpv($PyyUx);
        goto Dae7r;
        KNi7Z:
        $this->NBa8l->put($PyyUx->getAttribute('thumbnail'), $this->j_caY->get($PyyUx->getAttribute('thumbnail')));
        goto KMOfS;
        Sw5dR:
        $PyyUx = S1qX7zy4Guf94::findOrFail($W0vWP);
        goto wJ2fO;
        nJjUZ:
    }
    private function m7fMCesQdpv(TkBEwah2ZcKXB $w2pZ1) : string
    {
        goto Xk72P;
        Xk72P:
        $Iros8 = $w2pZ1->getLocation();
        goto E3j71;
        xKuLU:
        aGt84:
        goto tDjPP;
        tDjPP:
        return $wmLPG . $w2pZ1->getFilename() . '.jpg';
        goto hjjX0;
        U_2zC:
        $this->NBa8l->makeDirectory($wmLPG, 0755, true);
        goto xKuLU;
        dXGmA:
        if ($this->NBa8l->exists($wmLPG)) {
            goto aGt84;
        }
        goto U_2zC;
        E3j71:
        $wmLPG = dirname($Iros8) . '/preview/';
        goto dXGmA;
        hjjX0:
    }
}
