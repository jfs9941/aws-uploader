<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class MjNIYZYcN90xN
{
    private $n2W55;
    public function __construct(string $xtISY, ?int $bOYNe, ?int $tIdzi, float $JSovF)
    {
        goto aZZcW;
        v_cCp:
        vU4jQ:
        goto xC8E5;
        jG6Zh:
        $this->n2W55 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $v2nSS, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $xtISY];
        goto lW73c;
        yj8k0:
        if (!($bOYNe && $tIdzi)) {
            goto dfyhp;
        }
        goto rj1dJ;
        aZZcW:
        $v2nSS = 15000000;
        goto yj8k0;
        NHdpe:
        $this->n2W55['VideoDescription']['Height'] = $tIdzi;
        goto v_cCp;
        rj1dJ:
        $v2nSS = $this->mer3BuJVU4u($bOYNe, $tIdzi, $JSovF);
        goto PJO_A;
        PJO_A:
        dfyhp:
        goto jG6Zh;
        X7VEf:
        $this->n2W55['VideoDescription']['Width'] = $bOYNe;
        goto NHdpe;
        lW73c:
        if (!($bOYNe && $tIdzi)) {
            goto vU4jQ;
        }
        goto X7VEf;
        xC8E5:
    }
    public function m9EOseOC7Wz(Y4TF32dQUcyCj $mTZoR) : self
    {
        $this->n2W55['VideoDescription']['VideoPreprocessors'] = $mTZoR->mD7gh6R5HJe();
        return $this;
    }
    public function mZhszsrRiYi() : array
    {
        return $this->n2W55;
    }
    private function mer3BuJVU4u(int $bOYNe, int $tIdzi, float $s_y_U, string $ldHp9 = 'medium', string $Ab22H = 'h264', string $f_AxO = 'good') : ?int
    {
        goto MR1jH;
        OpOOk:
        return (int) ($sLinS * 1000 * 1000);
        goto kSQ_8;
        Q_8DR:
        $sLinS *= 0.65;
        goto h8jcg;
        IJWmx:
        goto N1Sbx;
        goto UL9A6;
        THSQ1:
        KLkX6:
        goto b8SvI;
        Xpg1q:
        goto N1Sbx;
        goto DXnbD;
        a9zOe:
        ywGEH:
        goto THSQ1;
        zTi6T:
        $vzOkv = 1.5;
        goto k9lOZ;
        zlHzu:
        if ($MDg7D <= 3840 * 2160) {
            goto USz9I;
        }
        goto erXC8;
        Xae6w:
        if ($MDg7D <= 2560 * 1440) {
            goto GNCl7;
        }
        goto zlHzu;
        bnfJh:
        $vzOkv = 20;
        goto hYvnW;
        bAw8Q:
        $vzOkv = 7;
        goto Y3ZtQ;
        ArW5s:
        if ($MDg7D <= 640 * 480) {
            goto gNGTK;
        }
        goto bdMD0;
        erXC8:
        $vzOkv = 30;
        goto l6LFJ;
        l6LFJ:
        goto N1Sbx;
        goto sIImI;
        QVXbj:
        switch (strtolower($f_AxO)) {
            case 'low':
                $sLinS *= 0.8;
                goto fXJcv;
            case 'high':
                $sLinS *= 1.2;
                goto fXJcv;
        }
        goto Rh0Qu;
        Navig:
        GNCl7:
        goto WvDp8;
        hYvnW:
        N1Sbx:
        goto vnVeu;
        QXZ5H:
        switch (strtolower($ldHp9)) {
            case 'low':
                $sLinS *= 0.7;
                goto KLkX6;
            case 'high':
                $sLinS *= 1.3;
                goto KLkX6;
            case 'veryhigh':
                $sLinS *= 1.6;
                goto KLkX6;
        }
        goto a9zOe;
        S6vfx:
        $vzOkv = 3;
        goto IJWmx;
        mLtfn:
        if ($MDg7D <= 1920 * 1080) {
            goto scACn;
        }
        goto Xae6w;
        b8SvI:
        if (!('h265' === strtolower($Ab22H) || 'hevc' === strtolower($Ab22H) || 'vp9' === strtolower($Ab22H))) {
            goto qI6V8;
        }
        goto Q_8DR;
        Y3ZtQ:
        goto N1Sbx;
        goto Navig;
        UL9A6:
        scACn:
        goto bAw8Q;
        WvDp8:
        $vzOkv = 12;
        goto Xpg1q;
        BDkxV:
        NMO7j:
        goto S6vfx;
        DXnbD:
        USz9I:
        goto bnfJh;
        sIImI:
        gNGTK:
        goto zTi6T;
        k9lOZ:
        goto N1Sbx;
        goto BDkxV;
        h8jcg:
        qI6V8:
        goto QVXbj;
        bdMD0:
        if ($MDg7D <= 1280 * 720) {
            goto NMO7j;
        }
        goto mLtfn;
        Rh0Qu:
        KDki0:
        goto hehNE;
        MR1jH:
        $MDg7D = $bOYNe * $tIdzi;
        goto ArW5s;
        hehNE:
        fXJcv:
        goto lNlO0;
        vnVeu:
        $sLinS = $vzOkv * ($s_y_U / 30);
        goto QXZ5H;
        lNlO0:
        $sLinS = max(0.5, $sLinS);
        goto OpOOk;
        kSQ_8:
    }
}
