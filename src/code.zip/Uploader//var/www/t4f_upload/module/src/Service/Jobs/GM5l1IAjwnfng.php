<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class GM5l1IAjwnfng
{
    private $knb6E;
    private $vtuC3;
    private $j_caY;
    private $JZDCA;
    public function __construct($HgWMY, $BMGzE, $nFXer, $WPRCg)
    {
        goto OsnGV;
        OsnGV:
        $this->vtuC3 = $BMGzE;
        goto MNMHx;
        MNMHx:
        $this->j_caY = $nFXer;
        goto RSo_F;
        RSo_F:
        $this->JZDCA = $WPRCg;
        goto hyUaX;
        hyUaX:
        $this->knb6E = $HgWMY;
        goto GzdlJ;
        GzdlJ:
    }
    public function mzmK96qCqJ0(?int $bOYNe, ?int $tIdzi, string $TP3pR, bool $fHpfV = false) : string
    {
        goto NbSbs;
        kAzQJ:
        rThA5:
        goto DwC5l;
        ukE8h:
        $this->j_caY->put($Iros8, $qj00p->stream('png'));
        goto mbeUc;
        Zm2Fn:
        $LCvVO = $bOYNe - $Po1Ay;
        goto yLORi;
        lA85s:
        return $fHpfV ? $Iros8 : $this->j_caY->url($Iros8);
        goto m0c2Q;
        m0c2Q:
        yECML:
        goto YrBGF;
        VuTfC:
        $LCvVO -= $pNgIw;
        goto HcfLx;
        YrBGF:
        $qj00p = $this->knb6E->call($this, $bOYNe, $tIdzi);
        goto Zm2Fn;
        nnBmG:
        $LCvVO -= $pNgIw * 0.4;
        goto igdG3;
        yLORi:
        $pNgIw = (int) ($LCvVO / 80);
        goto VuTfC;
        igdG3:
        Q6xox:
        goto cfbNX;
        mbeUc:
        return $fHpfV ? $Iros8 : $this->j_caY->url($Iros8);
        goto Pt80I;
        HcfLx:
        if (!($bOYNe > 1500)) {
            goto Q6xox;
        }
        goto nnBmG;
        lfJga:
        list($u9nUO, $Po1Ay, $BD8m8) = $this->mv5E2wL7GH0($TP3pR, $bOYNe, $m9BnZ, (float) $bOYNe / $tIdzi);
        goto NLFVG;
        rA5hr:
        $qj00p->text($BD8m8, $LCvVO, (int) $Heeh1, function ($iNWJe) use($u9nUO) {
            goto Nu6f9;
            zPuo3:
            $iNWJe->align('middle');
            goto UF32_;
            M4Zu6:
            $IFiQR = (int) ($u9nUO * 1.2);
            goto HZMo5;
            osH_U:
            $iNWJe->color([185, 185, 185, 1]);
            goto WUu6c;
            WUu6c:
            $iNWJe->valign('middle');
            goto zPuo3;
            HZMo5:
            $iNWJe->size(max($IFiQR, 1));
            goto osH_U;
            Nu6f9:
            $iNWJe->file(public_path($this->vtuC3));
            goto M4Zu6;
            UF32_:
        });
        goto b3mfL;
        CQZQb:
        if (!$this->j_caY->exists($Iros8)) {
            goto yECML;
        }
        goto lA85s;
        NLFVG:
        $Iros8 = $this->m7KCTnLuxuA($BD8m8, $bOYNe, $tIdzi, $Po1Ay, $u9nUO);
        goto CQZQb;
        pJ3L1:
        throw new \RuntimeException("S1qX7zy4Guf94 dimensions are not available.");
        goto kAzQJ;
        NbSbs:
        if (!($bOYNe === null || $tIdzi === null)) {
            goto rThA5;
        }
        goto pJ3L1;
        cfbNX:
        $Heeh1 = $tIdzi - $u9nUO - 10;
        goto rA5hr;
        b3mfL:
        $this->JZDCA->put($Iros8, $qj00p->stream('png'));
        goto ukE8h;
        DwC5l:
        $m9BnZ = 0.1;
        goto lfJga;
        Pt80I:
    }
    private function m7KCTnLuxuA(string $TP3pR, int $bOYNe, int $tIdzi, int $G4I9r, int $Tkqmt) : string
    {
        $UO4d1 = ltrim($TP3pR, '@');
        return "v2/watermark/{$UO4d1}/{$bOYNe}x{$tIdzi}_{$G4I9r}x{$Tkqmt}/text_watermark.png";
    }
    private function mv5E2wL7GH0($TP3pR, int $bOYNe, float $RdKFg, float $rOwJo) : array
    {
        goto N0Hqo;
        M20Hx:
        return [(int) $LRjx7, $Po1Ay, $BD8m8];
        goto m8FXl;
        tZwuJ:
        if (!($rOwJo > 1)) {
            goto teX9e;
        }
        goto tYi7r;
        emZPK:
        teX9e:
        goto MrKda;
        N0Hqo:
        $BD8m8 = '@' . $TP3pR;
        goto H2LDm;
        tYi7r:
        $LRjx7 = $Po1Ay / (strlen($BD8m8) * 0.8);
        goto hf0iu;
        MrKda:
        $LRjx7 = 1 / $rOwJo * $Po1Ay / strlen($BD8m8);
        goto M20Hx;
        hf0iu:
        return [(int) $LRjx7, $LRjx7 * strlen($BD8m8) / 1.8, $BD8m8];
        goto emZPK;
        H2LDm:
        $Po1Ay = (int) ($bOYNe * $RdKFg);
        goto tZwuJ;
        m8FXl:
    }
}
