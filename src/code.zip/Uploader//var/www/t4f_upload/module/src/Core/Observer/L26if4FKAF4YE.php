<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Contracts\DcxVJGuKhzqC9;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class L26if4FKAF4YE implements DcxVJGuKhzqC9
{
    private $sMj2E;
    public function __construct($PW_5C)
    {
        $this->sMj2E = $PW_5C;
    }
    public function mg4qJ1AespD($ie1o0, $X021H)
    {
        goto v8F34;
        tUrEI:
        $this->sMj2E->mdqb7va7pQ1(YGB86F7VDD6Xo::PROCESSING);
        goto n2nR7;
        et_DY:
        dqPhO:
        goto uGXvc;
        gQ63M:
        if (!$this->sMj2E instanceof ZrqFFxIRVAAEU) {
            goto O5ijm;
        }
        goto tUrEI;
        uGXvc:
        if (!(YGB86F7VDD6Xo::DELETED === $X021H && $this->sMj2E->mVz7It0sr6N())) {
            goto S3VsG;
        }
        goto P4BA_;
        n2nR7:
        O5ijm:
        goto WE7lY;
        P4BA_:
        $this->sMj2E->delete();
        goto q68y0;
        FiHkI:
        $this->sMj2E->status = YGB86F7VDD6Xo::UPLOADED;
        goto gQ63M;
        q68y0:
        S3VsG:
        goto hYXZ5;
        WE7lY:
        $this->sMj2E->save();
        goto et_DY;
        v8F34:
        if (!(YGB86F7VDD6Xo::UPLOADED === $X021H)) {
            goto dqPhO;
        }
        goto FiHkI;
        hYXZ5:
    }
}
