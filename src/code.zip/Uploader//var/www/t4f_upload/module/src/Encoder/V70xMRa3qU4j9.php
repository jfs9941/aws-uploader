<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Service\WhtZzd9QpH304;
final class V70xMRa3qU4j9
{
    public const ZIGgf = 'v2/hls/';
    private $Gvwxe;
    private $zl2D8;
    public function __construct(WhtZzd9QpH304 $gL9vu, Filesystem $VVGKi)
    {
        $this->Gvwxe = $gL9vu;
        $this->zl2D8 = $VVGKi;
    }
    public function mitcdV95FAy($jTXdP) : string
    {
        return $this->Gvwxe->mLeJP93wqJe(self::ZIGgf . $jTXdP->getAttribute('id') . '/');
    }
    public function mPonn9bA0t8($jTXdP) : string
    {
        return $this->Gvwxe->mLeJP93wqJe(self::ZIGgf . $jTXdP->getAttribute('id') . '/thumbnail/');
    }
    public function mMQ6nPUN4v9($jTXdP, $QqTYT = true) : string
    {
        goto rHx30;
        rHx30:
        if ($QqTYT) {
            goto xjvvg;
        }
        goto F5gd6;
        Zu4J9:
        return $this->Gvwxe->mLeJP93wqJe(self::ZIGgf . $jTXdP->getAttribute('id') . '/' . $jTXdP->getAttribute('id') . '.m3u8');
        goto y8CmY;
        F5gd6:
        return self::ZIGgf . $jTXdP->getAttribute('id') . '/' . $jTXdP->getAttribute('id') . '.m3u8';
        goto HU7LV;
        HU7LV:
        xjvvg:
        goto Zu4J9;
        y8CmY:
    }
    public function resolveThumbnail($jTXdP) : string
    {
        goto NzzcE;
        atDeQ:
        $lqJf8 = $this->zl2D8->files($this->mPonn9bA0t8($jTXdP));
        goto atKUL;
        NzzcE:
        $C3gWL = $jTXdP->getAttribute('id');
        goto atDeQ;
        atKUL:
        return 1 == count($lqJf8) ? self::ZIGgf . $C3gWL . '/thumbnail/' . $C3gWL . '.0000000.jpg' : self::ZIGgf . $C3gWL . '/thumbnail/' . $C3gWL . '.0000001.jpg';
        goto qDziw;
        qDziw:
    }
    public function mtNNCyM8AMA(string $PeSCk) : string
    {
        return $this->zl2D8->url($PeSCk);
    }
}
