<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class AzBQAvWLQPhGb implements StoreToS3JobInterface
{
    private $eE5H8;
    private $bwFb2;
    private $k4mhD;
    public function __construct($LCatz, $dR_xe, $ixEuN)
    {
        goto otBQ2;
        otBQ2:
        $this->bwFb2 = $dR_xe;
        goto hfTAw;
        hfTAw:
        $this->k4mhD = $ixEuN;
        goto uBZyh;
        uBZyh:
        $this->eE5H8 = $LCatz;
        goto HDnAz;
        HDnAz:
    }
    public function store(string $G2Ngo) : void
    {
        goto qcCcg;
        FWpWm:
        $t0jU5 = $this->k4mhD->path($zw5Jg->getAttribute('preview'));
        goto Fa2zs;
        xNhFD:
        $lXM_e = $zw5Jg->getAttribute('thumbnail');
        goto EzlWS;
        SFm8K:
        qM2If:
        goto m2MOf;
        HepAy:
        if (!$zw5Jg->update(['driver' => BHGv9oAB1EERw::S3, 'status' => YGB86F7VDD6Xo::FINISHED])) {
            goto qM2If;
        }
        goto fwq7G;
        Fa2zs:
        $z_33y = $this->eE5H8->call($this, $t0jU5);
        goto xTqQD;
        qskLc:
        $cxd2S = $this->eE5H8->call($this, $NyCw9);
        goto cx5cB;
        m2MOf:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $G2Ngo]);
        goto mkrv1;
        puGqp:
        return;
        goto SFm8K;
        WPBqO:
        return;
        goto hIuZl;
        lZqIz:
        $BkP1c = $this->k4mhD->path($zw5Jg->getLocation());
        goto l8roq;
        qcCcg:
        $zw5Jg = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
        goto guE_K;
        e9ynQ:
        Log::info("ZrqFFxIRVAAEU has been deleted, discard it", ['fileId' => $G2Ngo]);
        goto WPBqO;
        vokxP:
        ZrqFFxIRVAAEU::where('parent_id', $G2Ngo)->update(['driver' => BHGv9oAB1EERw::S3, 'preview' => $zw5Jg->getAttribute('preview'), 'thumbnail' => $zw5Jg->getAttribute('thumbnail'), 'webp_path' => $zw5Jg->getAttribute('webp_path')]);
        goto puGqp;
        guE_K:
        if ($zw5Jg) {
            goto v3jVk;
        }
        goto e9ynQ;
        xMsba:
        $this->mdeorngjj3D($BkP1c, $zw5Jg->getLocation(), '.webp');
        goto xNhFD;
        l8roq:
        $this->mdeorngjj3D($BkP1c, $zw5Jg->getLocation());
        goto xMsba;
        NL09h:
        if (!($zw5Jg->getAttribute('preview') && $this->k4mhD->exists($zw5Jg->getAttribute('preview')))) {
            goto bmmdr;
        }
        goto FWpWm;
        t3t3l:
        gCYIb:
        goto NL09h;
        cx5cB:
        $this->bwFb2->put($zw5Jg->getAttribute('thumbnail'), $this->k4mhD->get($lXM_e), ['visibility' => 'public', 'ContentType' => $cxd2S->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto t3t3l;
        hIuZl:
        v3jVk:
        goto lZqIz;
        xTqQD:
        $this->bwFb2->put($zw5Jg->getAttribute('preview'), $this->k4mhD->get($zw5Jg->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $z_33y->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto pQdyI;
        NS3sY:
        $NyCw9 = $this->k4mhD->path($lXM_e);
        goto qskLc;
        fwq7G:
        Log::info("ZrqFFxIRVAAEU stored to S3, update the children attachments", ['fileId' => $G2Ngo]);
        goto vokxP;
        pQdyI:
        bmmdr:
        goto HepAy;
        EzlWS:
        if (!($lXM_e && $this->k4mhD->exists($lXM_e))) {
            goto gCYIb;
        }
        goto NS3sY;
        mkrv1:
    }
    private function mdeorngjj3D($Rn97M, $MyVt0, $ENELG = '')
    {
        goto XkWLb;
        xx7jV:
        ALJsD:
        goto ZNibn;
        ZNibn:
        try {
            $LjRVY = $this->eE5H8->call($this, $Rn97M);
            $this->bwFb2->put($MyVt0, $this->k4mhD->get($MyVt0), ['visibility' => 'public', 'ContentType' => $LjRVY->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $uEMU5) {
            Log::error("Failed to upload image to S3", ['s3Path' => $MyVt0, 'error' => $uEMU5->getMessage()]);
        }
        goto qYNvA;
        uo0vY:
        $Rn97M = str_replace('.jpg', $ENELG, $Rn97M);
        goto DhFIM;
        DhFIM:
        $MyVt0 = str_replace('.jpg', $ENELG, $MyVt0);
        goto xx7jV;
        XkWLb:
        if (!$ENELG) {
            goto ALJsD;
        }
        goto uo0vY;
        qYNvA:
    }
}
