<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\FutyevYt174lN;
use Jfs\Uploader\Core\H7OWocYFy30FB;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
trait C4pYqesyjz4Qh
{
    private $sMj2E;
    private $VLten;
    private $mDoD9;
    public function mNRyYDQLTdL() : string
    {
        return FutyevYt174lN::mUYRC1czCXw($this->sMj2E->getFilename());
    }
    public function mpti44yUWjH() : FutyevYt174lN
    {
        goto ahfMS;
        qwy6P:
        return $this->VLten;
        goto k8umt;
        NQDea:
        $this->mbKUECQBo9A();
        goto KodCs;
        k8umt:
        QRF0u:
        goto NQDea;
        KodCs:
        return $this->VLten;
        goto i953U;
        ahfMS:
        if (!(null !== $this->VLten)) {
            goto QRF0u;
        }
        goto qwy6P;
        i953U:
    }
    private function mbKUECQBo9A() : H7OWocYFy30FB
    {
        goto ioLKV;
        yEW5k:
        dyFT8:
        goto xv43E;
        QblGs:
        $NP1hc = json_decode($lsA6L, true);
        goto j9L68;
        ioLKV:
        $lsA6L = $this->mDoD9->get($this->mNRyYDQLTdL());
        goto NoH_O;
        xv43E:
        throw new Esl5ysVUz7oPz("File {$this->sMj2E->getFilename()} is not PreSigned upload");
        goto HFltm;
        j9L68:
        $this->VLten = FutyevYt174lN::mK1lp7wm8WV($NP1hc);
        goto pBof_;
        NoH_O:
        if (!$lsA6L) {
            goto dyFT8;
        }
        goto QblGs;
        pBof_:
        return $this;
        goto yEW5k;
        HFltm:
    }
    public function mKULcwDJPhc($gbLld, $nrJPB, $rDUTV, $i51wU, $hVGUs, $yarYL = 's3') : void
    {
        $this->VLten = FutyevYt174lN::mP3MvfGsqFI($this->sMj2E, $gbLld, $nrJPB, $hVGUs, $rDUTV, $i51wU, $yarYL);
    }
}
