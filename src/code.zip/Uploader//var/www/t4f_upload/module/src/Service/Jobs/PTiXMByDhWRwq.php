<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
class PTiXMByDhWRwq implements BlurVideoJobInterface
{
    const CtLNy = 15;
    const c_n1E = 500;
    const PelEu = 500;
    private $u_yGf;
    private $zl2D8;
    private $IXK4e;
    public function __construct($pDQ4h, $VVGKi, $ZfrI6)
    {
        goto Ae4K2;
        YC6aG:
        $this->u_yGf = $pDQ4h;
        goto Z1IDa;
        tSsBF:
        $this->zl2D8 = $VVGKi;
        goto YC6aG;
        Ae4K2:
        $this->IXK4e = $ZfrI6;
        goto tSsBF;
        Z1IDa:
    }
    public function blur(string $C3gWL) : void
    {
        goto mmd7o;
        GgSDA:
        $iwovL = $this->mSCxjEH4neR($L4e7F);
        goto GOWXT;
        AYFHL:
        $L4e7F = Zr0izVmbs7QaE::findOrFail($C3gWL);
        goto bYozi;
        U0BmJ:
        $OgE9J->blur(self::CtLNy);
        goto GgSDA;
        Jml1j:
        oLSzr:
        goto UxFjq;
        juOtd:
        if (chmod($V4CGf, 0664)) {
            goto oLSzr;
        }
        goto lwRzf;
        mmd7o:
        Log::info("Blurring for video", ['videoID' => $C3gWL]);
        goto PfYbV;
        UxFjq:
        $L4e7F->update(['preview' => $iwovL]);
        goto rsvIv;
        AtQ33:
        throw new \Exception('Failed to set final permissions on image file: ' . $V4CGf);
        goto Jml1j;
        YQrt3:
        unset($OgE9J);
        goto juOtd;
        cjnrP:
        $U_mGc = $OgE9J->width() / $OgE9J->height();
        goto aatC7;
        PfYbV:
        ini_set('memory_limit', '-1');
        goto AYFHL;
        J0s1V:
        $OgE9J = $this->u_yGf->call($this, $this->IXK4e->path($L4e7F->getAttribute('thumbnail')));
        goto cjnrP;
        rsvIv:
        g0quu:
        goto H_b12;
        Our2l:
        $this->IXK4e->put($L4e7F->getAttribute('thumbnail'), $this->zl2D8->get($L4e7F->getAttribute('thumbnail')));
        goto J0s1V;
        bYozi:
        if (!$L4e7F->getAttribute('thumbnail')) {
            goto g0quu;
        }
        goto Our2l;
        lwRzf:
        \Log::warning('Failed to set final permissions on image file: ' . $V4CGf);
        goto AtQ33;
        vTZEF:
        $this->zl2D8->put($iwovL, $this->IXK4e->get($iwovL));
        goto YQrt3;
        MQhM2:
        $OgE9J->save($V4CGf);
        goto vTZEF;
        GOWXT:
        $V4CGf = $this->IXK4e->path($iwovL);
        goto MQhM2;
        aatC7:
        $OgE9J->resize(self::c_n1E, self::PelEu / $U_mGc);
        goto U0BmJ;
        H_b12:
    }
    private function mSCxjEH4neR(Ezj2tYBlqBPt9 $mgM7g) : string
    {
        goto vSK3d;
        vSK3d:
        $PeSCk = $mgM7g->getLocation();
        goto Y1JyP;
        Y1JyP:
        $jPesJ = dirname($PeSCk) . '/preview/';
        goto P9DJY;
        SYaHM:
        $this->IXK4e->makeDirectory($jPesJ, 0755, true);
        goto T7eHh;
        P9DJY:
        if ($this->IXK4e->exists($jPesJ)) {
            goto kfxb0;
        }
        goto SYaHM;
        E5eOv:
        return $jPesJ . $mgM7g->getFilename() . '.jpg';
        goto R_QHN;
        T7eHh:
        kfxb0:
        goto E5eOv;
        R_QHN:
    }
}
