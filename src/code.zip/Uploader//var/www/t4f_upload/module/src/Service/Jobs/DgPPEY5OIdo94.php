<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
class DgPPEY5OIdo94 implements DownloadToLocalJobInterface
{
    private $bwFb2;
    private $k4mhD;
    public function __construct($dR_xe, $ixEuN)
    {
        $this->bwFb2 = $dR_xe;
        $this->k4mhD = $ixEuN;
    }
    public function download(string $G2Ngo) : void
    {
        goto Rm_92;
        NyOZl:
        if (!$this->k4mhD->exists($PW_5C->getLocation())) {
            goto eEoOp;
        }
        goto q3zSB;
        V0W62:
        eEoOp:
        goto ghfBH;
        q3zSB:
        return;
        goto V0W62;
        Rm_92:
        $PW_5C = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
        goto VnYwo;
        ghfBH:
        $this->k4mhD->put($PW_5C->getLocation(), $this->bwFb2->get($PW_5C->getLocation()));
        goto BM2_W;
        VnYwo:
        Log::info("Start download file to local", ['fileId' => $G2Ngo, 'filename' => $PW_5C->getLocation()]);
        goto NyOZl;
        BM2_W:
    }
}
