<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\IoCBJqqLig917;
final class Kp1RFj3FeG2hA implements VideoPostHandleServiceInterface
{
    private $zJ9mq;
    private $zl2D8;
    public function __construct(UploadServiceInterface $jIvpP, Filesystem $VVGKi)
    {
        $this->zJ9mq = $jIvpP;
        $this->zl2D8 = $VVGKi;
    }
    public function saveMetadata(string $C3gWL, array $ToSwr)
    {
        goto gYLN0;
        VRUsx:
        M0X3W:
        goto CULOT;
        Un2jg:
        $DOITf['fps'] = $ToSwr['fps'];
        goto obYIg;
        jfDld:
        if (!isset($ToSwr['fps'])) {
            goto fv0s1;
        }
        goto Un2jg;
        MHIer:
        try {
            goto HLH2x;
            mpEHg:
            $DOITf['thumbnail_id'] = $MOwIc['id'];
            goto iyD1W;
            HLH2x:
            $MOwIc = $this->zJ9mq->storeSingleFile(new class($ToSwr['thumbnail']) implements SingleUploadInterface
            {
                private $k4fCM;
                public function __construct($m42Ed)
                {
                    $this->k4fCM = $m42Ed;
                }
                public function getFile()
                {
                    return $this->k4fCM;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto mpEHg;
            iyD1W:
            $DOITf['thumbnail'] = $MOwIc['filename'];
            goto YY1FK;
            YY1FK:
        } catch (\Throwable $TTMgE) {
            Log::warning("Zr0izVmbs7QaE thumbnail store failed: " . $TTMgE->getMessage());
        }
        goto y6LiO;
        Tihuu:
        Log::warning("Zr0izVmbs7QaE metadata store failed for unknown reason ... " . $C3gWL);
        goto cp7DJ;
        y6LiO:
        xUkq3:
        goto WcIrz;
        obYIg:
        fv0s1:
        goto glHi2;
        WVKAT:
        oDhLW:
        goto Tihuu;
        WcIrz:
        if (!isset($ToSwr['duration'])) {
            goto zn1qS;
        }
        goto Yp34B;
        J22lU:
        if (!isset($ToSwr['resolution'])) {
            goto zqx5u;
        }
        goto LKylQ;
        dAFOW:
        $DOITf = [];
        goto AMNew;
        LKylQ:
        $DOITf['resolution'] = $ToSwr['resolution'];
        goto DvUy3;
        Uvqan:
        $this->zJ9mq->updateFile($jTXdP->getAttribute('id'), IoCBJqqLig917::PROCESSING);
        goto nyz6G;
        cp7DJ:
        throw new \Exception("Zr0izVmbs7QaE metadata store failed for unknown reason ... " . $C3gWL);
        goto IGGsX;
        DvUy3:
        zqx5u:
        goto jfDld;
        Qxj_H:
        zn1qS:
        goto J22lU;
        gYLN0:
        $jTXdP = Zr0izVmbs7QaE::findOrFail($C3gWL);
        goto dAFOW;
        CVo6E:
        if (!(isset($ToSwr['change_status']) && $ToSwr['change_status'])) {
            goto N0Vuy;
        }
        goto Uvqan;
        Yp34B:
        $DOITf['duration'] = $ToSwr['duration'];
        goto Qxj_H;
        glHi2:
        if (!$jTXdP->X8D1W) {
            goto M0X3W;
        }
        goto tjqaR;
        CULOT:
        if (!$jTXdP->update($DOITf)) {
            goto oDhLW;
        }
        goto CVo6E;
        tjqaR:
        unset($DOITf['thumbnail']);
        goto VRUsx;
        zW3Yh:
        return $jTXdP->getView();
        goto WVKAT;
        AMNew:
        if (!isset($ToSwr['thumbnail'])) {
            goto xUkq3;
        }
        goto MHIer;
        nyz6G:
        N0Vuy:
        goto zW3Yh;
        IGGsX:
    }
    public function createThumbnail(string $CLIZc) : void
    {
        goto JljiG;
        cI0lC:
        $jTXdP = Zr0izVmbs7QaE::findOrFail($CLIZc);
        goto aM41H;
        Ol2zY:
        H5ngS:
        goto zIK2P;
        aM41H:
        $EJuN9 = "v2/hls/thumbnails/{$CLIZc}/";
        goto Q9X7d;
        Q9X7d:
        if (!(!$this->zl2D8->directoryExists($EJuN9) && empty($jTXdP->mymoRS5eees()))) {
            goto H5ngS;
        }
        goto ps7mH;
        ps7mH:
        $AbTjJ = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto IYIBQ;
        JljiG:
        Log::info("Use Lambda to generate thumbnail for video: " . $CLIZc);
        goto cI0lC;
        IYIBQ:
        try {
            goto zIHuL;
            OTc6u:
            $o7bjx = $Zft8l->get('QueueUrl');
            goto mIWcl;
            zIHuL:
            $Zft8l = $AbTjJ->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto OTc6u;
            mIWcl:
            $AbTjJ->sendMessage(['QueueUrl' => $o7bjx, 'MessageBody' => json_encode(['file_path' => $jTXdP->getLocation()])]);
            goto DURCB;
            DURCB:
        } catch (\Throwable $BTAgP) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$BTAgP->getMessage()}");
        }
        goto Ol2zY;
        zIK2P:
    }
    public function mbXUKvl01tF(string $CLIZc) : void
    {
        goto B66Pk;
        c1CwI:
        if (!(count($lqJf8) === 0)) {
            goto vAO7_;
        }
        goto rX12Y;
        J6MKy:
        N4ZZK:
        goto CHVqs;
        rX12Y:
        Log::error("Message back with success data but not found thumbnail files " . $CLIZc);
        goto w3d7a;
        saJFQ:
        if ($this->zl2D8->directoryExists($EJuN9)) {
            goto N4ZZK;
        }
        goto lLjCD;
        lLjCD:
        Log::error("Message back with success data but not found thumbnail " . $CLIZc);
        goto plDAL;
        lXrSx:
        vAO7_:
        goto NJ3gt;
        plDAL:
        throw new \Exception("Message back with success data but not found thumbnail " . $CLIZc);
        goto J6MKy;
        B66Pk:
        $jTXdP = Zr0izVmbs7QaE::findOrFail($CLIZc);
        goto QSoUY;
        CHVqs:
        $lqJf8 = $this->zl2D8->files($EJuN9);
        goto c1CwI;
        w3d7a:
        throw new \Exception("Message back with success data but not found thumbnail files " . $CLIZc);
        goto lXrSx;
        NJ3gt:
        $jTXdP->update(['generated_previews' => $EJuN9]);
        goto s7srb;
        QSoUY:
        $EJuN9 = "v2/hls/thumbnails/{$CLIZc}/";
        goto saJFQ;
        s7srb:
    }
    public function getThumbnails(string $CLIZc) : array
    {
        $jTXdP = Zr0izVmbs7QaE::findOrFail($CLIZc);
        return $jTXdP->getThumbnails();
    }
}
