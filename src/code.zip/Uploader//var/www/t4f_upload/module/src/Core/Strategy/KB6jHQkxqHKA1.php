<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Webmozart\Assert\Assert;
class KB6jHQkxqHKA1 implements FileProcessingStrategyInterface
{
    private $sswNC;
    private $S85eo;
    private $yfZae;
    public function __construct($OgE9J, $abuNK)
    {
        goto ciMh8;
        ciMh8:
        Assert::isInstanceOf($OgE9J, Yi7VDaCr23YjR::class);
        goto Lk7Qy;
        XoCZx:
        $jWont = config('upload.post_process_image');
        goto coSK5;
        Lk7Qy:
        $this->sswNC = $OgE9J;
        goto tPLby;
        coSK5:
        $this->yfZae = new $jWont($OgE9J, $abuNK);
        goto K_mpH;
        tPLby:
        $this->S85eo = $abuNK;
        goto XoCZx;
        K_mpH:
    }
    public function process($nP4E5) : void
    {
        $this->yfZae->process($nP4E5);
    }
}
