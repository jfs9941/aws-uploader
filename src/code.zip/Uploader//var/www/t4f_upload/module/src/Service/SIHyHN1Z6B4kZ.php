<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Core\Observer\EOiytBN64WRzq;
use Jfs\Uploader\Core\Observer\F4yAcsiRqIVH0;
use Jfs\Uploader\Core\FKnhGBzmViN0k;
use Jfs\Uploader\Core\UkuAPHfTiC1HI;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Jfs\Uploader\Exception\Bn3pSnwSmAp3g;
use Jfs\Uploader\Service\FileResolver\Iyn6qvHr19YOK;
use Ramsey\Uuid\Uuid;
final class SIHyHN1Z6B4kZ
{
    private $CAuDM;
    private $JZDCA;
    private $j_caY;
    public function __construct($GWIV5, $WPRCg, $nFXer)
    {
        goto VDHCH;
        jZL2Y:
        $this->JZDCA = $WPRCg;
        goto MJU5G;
        VDHCH:
        $this->CAuDM = $GWIV5;
        goto jZL2Y;
        MJU5G:
        $this->j_caY = $nFXer;
        goto ob4rT;
        ob4rT:
    }
    public function mkeTc9p3Urm($Gz0r2)
    {
        goto HJpS6;
        o_FCR:
        j0JaX:
        goto Btf2u;
        dQVfa:
        $lnvRc = $Gz0r2->getFile();
        goto Gz3jt;
        Btf2u:
        return $this->mewNyJaGAYf($Gz0r2['file_extension'], 's3' === $Gz0r2['driver'] ? ARsVGbfyHQlSz::S3 : ARsVGbfyHQlSz::LOCAL);
        goto sDbUk;
        HJpS6:
        if (!$Gz0r2 instanceof SingleUploadInterface) {
            goto j0JaX;
        }
        goto dQVfa;
        Gz3jt:
        return $this->mewNyJaGAYf($lnvRc->extension(), ARsVGbfyHQlSz::S3, null, $Gz0r2->options());
        goto o_FCR;
        sDbUk:
    }
    public function m0xLLeDOEWW(string $W0vWP)
    {
        goto yr8_D;
        yr8_D:
        $ippyD = config('upload.attachment_model')::findOrFail($W0vWP);
        goto mRDkO;
        bS6CR:
        return $uY0L7;
        goto kXgvH;
        mRDkO:
        $uY0L7 = $this->mewNyJaGAYf($ippyD->getAttribute('type'), $ippyD->getAttribute('driver'), $ippyD->getAttribute('id'));
        goto glj4J;
        RFefO:
        $uY0L7->setRawAttributes($ippyD->getAttributes());
        goto bS6CR;
        glj4J:
        $uY0L7->exists = true;
        goto RFefO;
        kXgvH:
    }
    public function mDUR5MNOpCD(string $QTbuH) : PwKw6a6OizPW3
    {
        goto Z2Caf;
        IsloN:
        if ($Uoymi) {
            goto CNIRn;
        }
        goto ggzjc;
        r90Hx:
        return $this->mewNyJaGAYf($RbQvx->vrLBz, $RbQvx->m9D3lqY7LIW(), $RbQvx->filename);
        goto lqnb_;
        coRKo:
        throw new NTFGijXrreOP3('metadata file not found');
        goto VnA6h;
        lqnb_:
        Wqh0J:
        goto coRKo;
        xyhXD:
        $eiM1z = json_decode($Uoymi, true);
        goto Q3dKq;
        Q3dKq:
        if (!$eiM1z) {
            goto Wqh0J;
        }
        goto Lo0kn;
        Z2Caf:
        $Uoymi = $this->JZDCA->get($QTbuH);
        goto IsloN;
        vIyFL:
        CNIRn:
        goto xyhXD;
        ggzjc:
        $Uoymi = $this->j_caY->get($QTbuH);
        goto vIyFL;
        Lo0kn:
        $RbQvx = UkuAPHfTiC1HI::mxcJmsH84Sf($eiM1z);
        goto r90Hx;
        VnA6h:
    }
    private function mewNyJaGAYf(string $xPRVh, $oUQSB, ?string $W0vWP = null, array $qC1gq = [])
    {
        goto PsI5d;
        m1vKA:
        GVym2:
        goto N7NC_;
        Gltic:
        throw new Bn3pSnwSmAp3g("not support file type {$xPRVh}");
        goto KvEhU;
        PsI5d:
        $W0vWP = $W0vWP ?? Uuid::uuid4()->getHex()->toString();
        goto C181f;
        N7NC_:
        vdXYd:
        goto SxxEa;
        SxxEa:
        $xD81a = $xD81a->mTn8Pzf13ed($oUQSB);
        goto oJ8HT;
        oJ8HT:
        $xD81a->mdmuA7GRonF(new EOiytBN64WRzq($xD81a));
        goto rv7tF;
        C181f:
        switch ($xPRVh) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $xD81a = Il0T1UmENcpfh::createFromScratch($W0vWP, $xPRVh);
                goto vdXYd;
            case 'mp4':
            case 'mov':
                $xD81a = S1qX7zy4Guf94::createFromScratch($W0vWP, $xPRVh);
                goto vdXYd;
            case 'pdf':
                $xD81a = FKnhGBzmViN0k::createFromScratch($W0vWP, $xPRVh);
                goto vdXYd;
            default:
                throw new Bn3pSnwSmAp3g("not support file type {$xPRVh}");
        }
        goto m1vKA;
        oi7Mf:
        xcn6r:
        goto Gltic;
        L3JCn:
        foreach ($this->CAuDM as $PqNmU) {
            goto j7zTl;
            T0350:
            return $xD81a->initLocation($PqNmU->mRTY2e8fhE7($xD81a));
            goto ezeNW;
            j7zTl:
            if (!$PqNmU->mTJiARnNt46($xD81a)) {
                goto BF3dc;
            }
            goto T0350;
            ihDrA:
            jIJht:
            goto p8QQF;
            ezeNW:
            BF3dc:
            goto ihDrA;
            p8QQF:
        }
        goto oi7Mf;
        rv7tF:
        $xD81a->mdmuA7GRonF(new F4yAcsiRqIVH0($xD81a, $this->j_caY, $qC1gq));
        goto L3JCn;
        KvEhU:
    }
}
