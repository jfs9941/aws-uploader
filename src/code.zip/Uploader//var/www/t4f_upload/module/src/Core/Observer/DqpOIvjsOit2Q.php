<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\DcxVJGuKhzqC9;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Exception\K5L2YJTJAchO8;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Jfs\Uploader\Presigned\M45l7IBx4Lpb2;
use Jfs\Uploader\Presigned\EfBaTjOz0p26r;
final class DqpOIvjsOit2Q implements DcxVJGuKhzqC9
{
    private $ChAAV;
    private $gMoIS;
    private $HO2X0;
    private $Q3Qp4;
    private $qNgj8;
    public function __construct($EljXk, $skn0D, $YS7_M, $XhEIi, $g4FSU = false)
    {
        goto j3dui;
        v9fqD:
        $this->HO2X0 = $skn0D;
        goto juawA;
        OhuMy:
        Y_DYG:
        goto nek9D;
        C01Gv:
        $this->mNjcd4uRVfc();
        goto OhuMy;
        juawA:
        $this->Q3Qp4 = $YS7_M;
        goto lrEAr;
        hcyGZ:
        if ($g4FSU) {
            goto Y_DYG;
        }
        goto C01Gv;
        j3dui:
        $this->gMoIS = $EljXk;
        goto v9fqD;
        lrEAr:
        $this->qNgj8 = $XhEIi;
        goto hcyGZ;
        nek9D:
    }
    private function mNjcd4uRVfc() : void
    {
        goto ZFLBq;
        O2KT3:
        Qj1g8:
        goto uJAry;
        ZFLBq:
        if (!(null !== $this->ChAAV)) {
            goto Qj1g8;
        }
        goto YI0lf;
        uJAry:
        try {
            $h0F7E = $this->gMoIS->mpti44yUWjH();
            $this->ChAAV = 's3' === $h0F7E->jWhvV ? new EfBaTjOz0p26r($this->gMoIS, $this->HO2X0, $this->Q3Qp4, $this->qNgj8) : new M45l7IBx4Lpb2($this->gMoIS, $this->HO2X0, $this->Q3Qp4);
        } catch (Esl5ysVUz7oPz $uEMU5) {
            Log::warning("Failed to set up presigned upload: {$uEMU5->getMessage()}");
        }
        goto qiGpc;
        YI0lf:
        return;
        goto O2KT3;
        qiGpc:
    }
    public function mg4qJ1AespD($ie1o0, $X021H)
    {
        goto uimPJ;
        EB74K:
        fKJKx:
        goto K68U9;
        uimPJ:
        $this->mNjcd4uRVfc();
        goto Qfoti;
        K68U9:
        XsNor:
        goto shIEs;
        Qfoti:
        switch ($X021H) {
            case YGB86F7VDD6Xo::UPLOADING:
                $this->mYelsAPgxKq();
                goto XsNor;
            case YGB86F7VDD6Xo::UPLOADED:
                $this->mtJO3okA4JX();
                goto XsNor;
            case YGB86F7VDD6Xo::ABORTED:
                $this->mhbFXqzCmKo();
                goto XsNor;
            default:
                goto XsNor;
        }
        goto EB74K;
        shIEs:
    }
    private function mtJO3okA4JX() : void
    {
        goto e2BEn;
        e2BEn:
        $this->ChAAV->mAYMPMrjwD6();
        goto y5zSy;
        aJVTq:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($PW_5C->id);
        goto kYuOD;
        KDjJ4:
        $PW_5C->mdqb7va7pQ1(YGB86F7VDD6Xo::UPLOADED);
        goto BqSHS;
        y5zSy:
        $PW_5C = $this->gMoIS->getFile();
        goto KDjJ4;
        kYuOD:
        eGiYW:
        goto hLwF_;
        BqSHS:
        if (!$PW_5C instanceof UZrSkD9d5TXs1) {
            goto eGiYW;
        }
        goto aJVTq;
        hLwF_:
    }
    private function mhbFXqzCmKo() : void
    {
        $this->ChAAV->mR8nrUJhhp7();
    }
    private function mYelsAPgxKq() : void
    {
        $this->ChAAV->m0BpXIBYPaJ();
    }
}
