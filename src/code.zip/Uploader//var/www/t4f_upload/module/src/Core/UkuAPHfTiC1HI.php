<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
final class UkuAPHfTiC1HI
{
    public $filename;
    public $vrLBz;
    public $uUw1e;
    public $I_Ajk;
    public $ePSQ2;
    public $l9aY9;
    public $z9NJt;
    public $status;
    public $TIo3k;
    public $RbFi9;
    public $WNE_L = 's3';
    public $kFsA4 = [];
    public function __construct($oPXry, $xPRVh, $mwVDA, $xjuwh, $l0Zz6, $h2fq3, $MGa2w, $a4AXJ, $dTwzD, $o0U9i, $CIuf5 = 's3', $AXziK = [])
    {
        goto MsIQK;
        On2tA:
        $this->TIo3k = $dTwzD;
        goto QrSF4;
        uz26L:
        $this->z9NJt = $MGa2w;
        goto iAXa9;
        MsIQK:
        $this->filename = $oPXry;
        goto fL3a3;
        Ztz_k:
        $this->I_Ajk = $xjuwh;
        goto ftERP;
        bkIzx:
        $this->kFsA4 = $AXziK;
        goto SdVCC;
        FMfMZ:
        $this->WNE_L = $CIuf5;
        goto bkIzx;
        QrSF4:
        $this->RbFi9 = $o0U9i;
        goto FMfMZ;
        iAXa9:
        $this->status = $a4AXJ;
        goto On2tA;
        afGYA:
        $this->uUw1e = $mwVDA;
        goto Ztz_k;
        UEfuo:
        $this->l9aY9 = $h2fq3;
        goto uz26L;
        ftERP:
        $this->ePSQ2 = $l0Zz6;
        goto UEfuo;
        fL3a3:
        $this->vrLBz = $xPRVh;
        goto afGYA;
        SdVCC:
    }
    private static function mBby73cAOAe() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mSbkX4dH9Y2() : array
    {
        return array_flip(self::mBby73cAOAe());
    }
    public function toArray() : array
    {
        $MtuJ4 = self::mBby73cAOAe();
        return [$MtuJ4['filename'] => $this->filename, $MtuJ4['fileExtension'] => $this->vrLBz, $MtuJ4['mimeType'] => $this->uUw1e, $MtuJ4['fileSize'] => $this->I_Ajk, $MtuJ4['chunkSize'] => $this->ePSQ2, $MtuJ4['checksums'] => $this->l9aY9, $MtuJ4['totalChunk'] => $this->z9NJt, $MtuJ4['status'] => $this->status, $MtuJ4['userId'] => $this->TIo3k, $MtuJ4['uploadId'] => $this->RbFi9, $MtuJ4['driver'] => $this->WNE_L, $MtuJ4['parts'] => $this->kFsA4];
    }
    public static function mvDfDvwhHEt(array $BJUR6) : self
    {
        $tzuje = array_flip(self::mSbkX4dH9Y2());
        return new self($BJUR6[$tzuje['filename']] ?? $BJUR6['filename'] ?? '', $BJUR6[$tzuje['fileExtension']] ?? $BJUR6['fileExtension'] ?? '', $BJUR6[$tzuje['mimeType']] ?? $BJUR6['mimeType'] ?? '', $BJUR6[$tzuje['fileSize']] ?? $BJUR6['fileSize'] ?? 0, $BJUR6[$tzuje['chunkSize']] ?? $BJUR6['chunkSize'] ?? 0, $BJUR6[$tzuje['checksums']] ?? $BJUR6['checksums'] ?? [], $BJUR6[$tzuje['totalChunk']] ?? $BJUR6['totalChunk'] ?? 0, $BJUR6[$tzuje['status']] ?? $BJUR6['status'] ?? 0, $BJUR6[$tzuje['userId']] ?? $BJUR6['userId'] ?? 0, $BJUR6[$tzuje['uploadId']] ?? $BJUR6['uploadId'] ?? '', $BJUR6[$tzuje['driver']] ?? $BJUR6['driver'] ?? 's3', $BJUR6[$tzuje['parts']] ?? $BJUR6['parts'] ?? []);
    }
    public static function mxcJmsH84Sf($rO3tY) : self
    {
        goto NCXQU;
        NCXQU:
        if (!(isset($rO3tY['fn']) || isset($rO3tY['fe']))) {
            goto VfYzy;
        }
        goto lmING;
        lmING:
        return self::mvDfDvwhHEt($rO3tY);
        goto YuNnC;
        YuNnC:
        VfYzy:
        goto GybH9;
        GybH9:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto fax3B;
        fax3B:
    }
    public function mCgnkilkBQI(string $o0U9i) : void
    {
        $this->RbFi9 = $o0U9i;
    }
    public function muXlR1o1rJn(array $AXziK) : void
    {
        $this->kFsA4 = $AXziK;
    }
    public static function ma2Ky8nMSA9($uY0L7, $piII1, $UswF4, $dTwzD, $l0Zz6, $h2fq3, $CIuf5)
    {
        return new self($uY0L7->getFilename(), $uY0L7->getExtension(), $piII1, $UswF4, $l0Zz6, $h2fq3, count($h2fq3), OHa83BAIlECUz::UPLOADING, $dTwzD, 0, $CIuf5, []);
    }
    public static function mCDZ3QhKdHV($W0vWP)
    {
        return 'metadata/' . $W0vWP . '.json';
    }
    public function m9D3lqY7LIW()
    {
        return 's3' === $this->WNE_L ? ARsVGbfyHQlSz::S3 : ARsVGbfyHQlSz::LOCAL;
    }
}
