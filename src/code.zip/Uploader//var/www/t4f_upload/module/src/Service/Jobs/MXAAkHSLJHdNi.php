<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class MXAAkHSLJHdNi implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $C3gWL) : void
    {
        goto Vkwk8;
        QRkUR:
        BU68T:
        goto mBfVY;
        AHRJr:
        $this->makxQDFZJxL($jTXdP);
        goto QRkUR;
        Vkwk8:
        $jTXdP = Zr0izVmbs7QaE::findOrFail($C3gWL);
        goto bd6Bq;
        bd6Bq:
        if ($jTXdP->width() > 0 && $jTXdP->height() > 0) {
            goto BU68T;
        }
        goto AHRJr;
        mBfVY:
    }
    private function makxQDFZJxL(Zr0izVmbs7QaE $FfPRr) : void
    {
        goto SKH12;
        A5UUL:
        $FfPRr->update(['duration' => $MoQri->getDurationInSeconds(), 'resolution' => $Y_Fv5->getWidth() . 'x' . $Y_Fv5->getHeight(), 'fps' => $ZwI89->get('r_frame_rate') ?? 30]);
        goto U1Wej;
        xU_32:
        $ZwI89 = $MoQri->getVideoStream();
        goto vDc80;
        SKH12:
        $hKeR1 = $FfPRr->getView();
        goto gcvqp;
        vDc80:
        $Y_Fv5 = $ZwI89->getDimensions();
        goto A5UUL;
        gcvqp:
        $MoQri = FFMpeg::fromDisk($hKeR1['path'])->open($FfPRr->getAttribute('filename'));
        goto xU_32;
        U1Wej:
    }
}
