<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class QcoiOgw1BN3hR
{
    private $IcOhC;
    public function __construct(float $wVp9o, int $t4dzx, string $K8sA2)
    {
        goto nPt1a;
        azwOS:
        $YGtJ5 = max($YGtJ5, 1);
        goto dJT5I;
        dJT5I:
        $this->IcOhC = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $YGtJ5]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $K8sA2]]];
        goto LemHb;
        nPt1a:
        $YGtJ5 = (int) $wVp9o / $t4dzx;
        goto azwOS;
        LemHb:
    }
    public function m1rLQgE527t() : array
    {
        return $this->IcOhC;
    }
}
