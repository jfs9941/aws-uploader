<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class FfVwOVCuREbLJ
{
    private $VuOeX;
    private $FbIBX;
    private $y41vy;
    private $K0X40;
    private $EgadS;
    private $Fy438;
    private $X8D1W;
    public function __construct(MediaConvertClient $KU20u, $STlwN, $T5tY7)
    {
        goto dzneK;
        b3qi0:
        $this->Fy438 = $T5tY7;
        goto X1XIF;
        FFGco:
        $this->EgadS = $STlwN;
        goto b3qi0;
        dzneK:
        $this->K0X40 = $KU20u;
        goto FFGco;
        X1XIF:
    }
    public function mQ7QTSgP1M2() : MediaConvertClient
    {
        return $this->K0X40;
    }
    public function mPFEq3MzyF6(L9UOl9SGHswpz $R20r0) : self
    {
        $this->VuOeX = $R20r0;
        return $this;
    }
    public function mGO0wMtb4vx(string $HNFAU) : self
    {
        $this->y41vy = $HNFAU;
        return $this;
    }
    public function mMkbNpolgvJ(N5z6dHogIzWBr $r6_rC) : self
    {
        $this->FbIBX[] = $r6_rC;
        return $this;
    }
    public function mTrkRFMsa9r(O3OTO3HMrAv4G $MOwIc) : self
    {
        $this->X8D1W = $MOwIc;
        return $this;
    }
    private function m8OEZuIYdob(bool $aOG2H) : array
    {
        goto W_urP;
        Obte_:
        $MC6cd['Settings']['OutputGroups'][] = $DBQ0Z;
        goto x3xNk;
        Irku1:
        foreach ($this->FbIBX as $r6_rC) {
            $DBQ0Z['Outputs'][] = $r6_rC->mCacZ9evS6P();
            MFjxa:
        }
        goto lp1Z4;
        mvTu0:
        Bwv0U:
        goto uxWPz;
        qwkD2:
        J50CX:
        goto YPtGY;
        SedQm:
        unset($MC6cd['Settings']['OutputGroups']);
        goto UEwUn;
        nYjJe:
        $this->FbIBX = [];
        goto GkYk3;
        YPtGY:
        if (!$aOG2H) {
            goto Ocj7f;
        }
        goto cE3FA;
        GkYk3:
        return $MC6cd;
        goto eq0p0;
        W_urP:
        $MC6cd = (require 'template.php');
        goto wopiY;
        Yiory:
        $DBQ0Z = $MC6cd['Settings']['OutputGroups'][0];
        goto SedQm;
        qlQZi:
        $this->VuOeX = null;
        goto nYjJe;
        aPPW2:
        throw new \LogicException('You must provide a input file to use');
        goto mvTu0;
        RNa0y:
        $DBQ0Z['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->y41vy;
        goto Obte_;
        wopiY:
        $MC6cd['Role'] = $this->EgadS;
        goto pdkzh;
        VxdfJ:
        $this->X8D1W = null;
        goto qlQZi;
        UEwUn:
        $DBQ0Z['Outputs'] = [];
        goto Irku1;
        x3xNk:
        if (!$this->X8D1W) {
            goto J50CX;
        }
        goto lnL9q;
        cE3FA:
        $MC6cd['AccelerationSettings']['Mode'] = 'ENABLED';
        goto y8Gm4;
        y8Gm4:
        Ocj7f:
        goto VxdfJ;
        uxWPz:
        $MC6cd['Settings']['Inputs'] = $this->VuOeX->mh1dRCigyf7();
        goto Yiory;
        lnL9q:
        $MC6cd['Settings']['OutputGroups'][] = $this->X8D1W->mTglVPctJiG();
        goto qwkD2;
        vw62N:
        if ($this->VuOeX) {
            goto Bwv0U;
        }
        goto aPPW2;
        lp1Z4:
        kXKFr:
        goto RNa0y;
        pdkzh:
        $MC6cd['Queue'] = $this->Fy438;
        goto vw62N;
        eq0p0:
    }
    public function mRfIOlsPLyR(bool $aOG2H = false) : string
    {
        try {
            $cUHx5 = $this->K0X40->createJob($this->m8OEZuIYdob($aOG2H));
            return $cUHx5->get('Jobs')['Id'];
        } catch (AwsException $TTMgE) {
            Log::error('Error creating MediaConvert job: ' . $TTMgE->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $TTMgE);
        }
    }
}
