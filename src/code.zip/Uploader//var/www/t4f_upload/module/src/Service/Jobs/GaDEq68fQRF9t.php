<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class GaDEq68fQRF9t
{
    private $iyhKM;
    private $vBgYT;
    private $bwFb2;
    private $HO2X0;
    public function __construct($G4OeZ, $lcWBa, $dR_xe, $skn0D)
    {
        goto lOYTW;
        Hcupd:
        $this->bwFb2 = $dR_xe;
        goto iQ32S;
        Ud46U:
        $this->iyhKM = $G4OeZ;
        goto xVwnS;
        lOYTW:
        $this->vBgYT = $lcWBa;
        goto Hcupd;
        iQ32S:
        $this->HO2X0 = $skn0D;
        goto Ud46U;
        xVwnS:
    }
    public function m7FTIyYsGpu(?int $DMzDj, ?int $T7AAY, string $nlTkR, bool $nvP3w = false) : string
    {
        goto oqdIb;
        dyFVn:
        if (!$this->bwFb2->exists($BkP1c)) {
            goto upe_n;
        }
        goto HCylt;
        VdX2K:
        $LjRVY = $this->iyhKM->call($this, $DMzDj, $T7AAY);
        goto Xyt3x;
        SrsJs:
        throw new \RuntimeException("UZrSkD9d5TXs1 dimensions are not available.");
        goto WVeca;
        WVeca:
        wcT4w:
        goto nVnVJ;
        HCylt:
        return $nvP3w ? $BkP1c : $this->bwFb2->url($BkP1c);
        goto Ni895;
        fuGTI:
        list($HqIi3, $KWMYm, $jU0Vh) = $this->myrcBTbFeHR($nlTkR, $DMzDj, $Ys8DA, (float) $DMzDj / $T7AAY);
        goto lUZdV;
        Xyt3x:
        $ujBQx = $DMzDj - $KWMYm;
        goto gVOhx;
        O1n7l:
        if (!($DMzDj > 1500)) {
            goto wO2QU;
        }
        goto IWt_T;
        Ni895:
        upe_n:
        goto VdX2K;
        lUZdV:
        $BkP1c = $this->mnHoS6A1l69($jU0Vh, $DMzDj, $T7AAY, $KWMYm, $HqIi3);
        goto dyFVn;
        I92at:
        wO2QU:
        goto MJTd0;
        Oq9N_:
        $ujBQx -= $vwo7f;
        goto O1n7l;
        MJTd0:
        $bn0UE = $T7AAY - $HqIi3 - 10;
        goto IWQWT;
        jaTTt:
        $this->bwFb2->put($BkP1c, $LjRVY->stream('png'));
        goto yqg6Q;
        oqdIb:
        if (!($DMzDj === null || $T7AAY === null)) {
            goto wcT4w;
        }
        goto SrsJs;
        nVnVJ:
        $Ys8DA = 0.1;
        goto fuGTI;
        yqg6Q:
        return $nvP3w ? $BkP1c : $this->bwFb2->url($BkP1c);
        goto gps9z;
        gVOhx:
        $vwo7f = (int) ($ujBQx / 80);
        goto Oq9N_;
        IDf2f:
        $this->HO2X0->put($BkP1c, $LjRVY->stream('png'));
        goto jaTTt;
        IWQWT:
        $LjRVY->text($jU0Vh, $ujBQx, (int) $bn0UE, function ($TO9yY) use($HqIi3) {
            goto Ey4z9;
            cg71V:
            $TO9yY->color([185, 185, 185, 1]);
            goto T9eqk;
            mc8Kk:
            $TO9yY->size(max($NW8wu, 1));
            goto cg71V;
            QL9AJ:
            $NW8wu = (int) ($HqIi3 * 1.2);
            goto mc8Kk;
            Ey4z9:
            $TO9yY->file(public_path($this->vBgYT));
            goto QL9AJ;
            BGfMH:
            $TO9yY->align('middle');
            goto Vmaq3;
            T9eqk:
            $TO9yY->valign('middle');
            goto BGfMH;
            Vmaq3:
        });
        goto IDf2f;
        IWt_T:
        $ujBQx -= $vwo7f * 0.4;
        goto I92at;
        gps9z:
    }
    private function mnHoS6A1l69(string $nlTkR, int $DMzDj, int $T7AAY, int $ai02C, int $HWDkO) : string
    {
        $vC0b3 = ltrim($nlTkR, '@');
        return "v2/watermark/{$vC0b3}/{$DMzDj}x{$T7AAY}_{$ai02C}x{$HWDkO}/text_watermark.png";
    }
    private function myrcBTbFeHR($nlTkR, int $DMzDj, float $cxljH, float $HiRXD) : array
    {
        goto PHwC3;
        AJGH3:
        $VhsEn = $KWMYm / (strlen($jU0Vh) * 0.8);
        goto scg0P;
        J9hNQ:
        $KWMYm = (int) ($DMzDj * $cxljH);
        goto uVdns;
        Ir7mo:
        return [(int) $VhsEn, $KWMYm, $jU0Vh];
        goto tPJSc;
        scg0P:
        return [(int) $VhsEn, $VhsEn * strlen($jU0Vh) / 1.8, $jU0Vh];
        goto wfuKu;
        wfuKu:
        Zw902:
        goto p8lo2;
        uVdns:
        if (!($HiRXD > 1)) {
            goto Zw902;
        }
        goto AJGH3;
        PHwC3:
        $jU0Vh = '@' . $nlTkR;
        goto J9hNQ;
        p8lo2:
        $VhsEn = 1 / $HiRXD * $KWMYm / strlen($jU0Vh);
        goto Ir7mo;
        tPJSc:
    }
}
