<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class K5L2YJTJAchO8 extends \Exception implements XZOQtSniPAkZY
{
    public function __construct(string $E4hPi = '', int $ZAwY1 = 0, ?\Throwable $q8Ah2 = null)
    {
        parent::__construct($E4hPi, $ZAwY1, $q8Ah2);
    }
    public static function moJWkEGvnSq($G2Ngo, $GLm9K, $wdtXQ)
    {
        $E4hPi = sprintf('File: %s -> Cannot transition from %s to %s', $G2Ngo, YGB86F7VDD6Xo::md3gCzPXO7o($GLm9K), YGB86F7VDD6Xo::md3gCzPXO7o($wdtXQ));
        return new self($E4hPi);
    }
}
