<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Webmozart\Assert\Assert;
class HDpjCubbG4QyD implements FileProcessingStrategyInterface
{
    private $YG6QO;
    private $J7w7y;
    private $iscTQ;
    public function __construct($LjRVY, $TBJiF)
    {
        goto KyZfh;
        ywOEC:
        $this->J7w7y = $TBJiF;
        goto HNv2l;
        I1wbc:
        $this->YG6QO = $LjRVY;
        goto ywOEC;
        KyZfh:
        Assert::isInstanceOf($LjRVY, ZrqFFxIRVAAEU::class);
        goto I1wbc;
        HNv2l:
        $l8Ozu = config('upload.post_process_image');
        goto bJE6z;
        bJE6z:
        $this->iscTQ = new $l8Ozu($LjRVY, $TBJiF);
        goto mv5dg;
        mv5dg:
    }
    public function process($Bz8s_) : void
    {
        $this->iscTQ->process($Bz8s_);
    }
}
