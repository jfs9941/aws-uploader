<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
class LsED92jvmYpAm implements WatermarkTextJobInterface
{
    private $u_yGf;
    private $n3RCf;
    private $Nv87Y;
    private $zl2D8;
    private $m1w1p;
    public function __construct($pDQ4h, $y4Sde, $VVGKi, $C14In, $Q8zfx)
    {
        goto CjASv;
        rIYAi:
        $this->zl2D8 = $VVGKi;
        goto y7XrM;
        CjASv:
        $this->u_yGf = $pDQ4h;
        goto rIYAi;
        iDQPj:
        $this->n3RCf = $y4Sde;
        goto ASwNj;
        y7XrM:
        $this->m1w1p = $C14In;
        goto rfys_;
        rfys_:
        $this->Nv87Y = $Q8zfx;
        goto iDQPj;
        ASwNj:
    }
    public function putWatermark(string $C3gWL, string $ojOHE) : void
    {
        goto OxjhX;
        K2Ake:
        try {
            goto Hd1og;
            Hd1og:
            $OgE9J = Yi7VDaCr23YjR::findOrFail($C3gWL);
            goto E5dm_;
            wwovq:
            \Log::warning('Failed to set final permissions on image file: ' . $PeSCk);
            goto C_ILv;
            sBoc4:
            $this->mPX9n8DyNQP($Jyrqg, $ojOHE);
            goto W5sfp;
            w2hzk:
            $Jyrqg->orient();
            goto sBoc4;
            W5sfp:
            $Jyrqg->save($PeSCk);
            goto wMOVp;
            xL2Az:
            if (chmod($PeSCk, 0664)) {
                goto WX5_T;
            }
            goto wwovq;
            hPRt9:
            $PeSCk = $this->m1w1p->path($OgE9J->getLocation());
            goto oZZ5m;
            Q5iHB:
            kfCv4:
            goto hPRt9;
            C_ILv:
            throw new \Exception('Failed to set final permissions on image file: ' . $PeSCk);
            goto SsNkV;
            wMOVp:
            unset($Jyrqg);
            goto xL2Az;
            PR7I2:
            return;
            goto Q5iHB;
            KR7Q6:
            Log::error("Yi7VDaCr23YjR is not on local, might be deleted before put watermark", ['imageId' => $C3gWL]);
            goto PR7I2;
            E5dm_:
            if ($this->m1w1p->exists($OgE9J->getLocation())) {
                goto kfCv4;
            }
            goto KR7Q6;
            oZZ5m:
            $Jyrqg = $this->u_yGf->call($this, $PeSCk);
            goto w2hzk;
            SsNkV:
            WX5_T:
            goto H4Y3f;
            H4Y3f:
        } catch (\Throwable $O3GIQ) {
            goto KY9bN;
            KY9bN:
            if (!$O3GIQ instanceof ModelNotFoundException) {
                goto jA2P3;
            }
            goto ATvnn;
            ATvnn:
            Log::info("Yi7VDaCr23YjR has been deleted, discard it", ['imageId' => $C3gWL]);
            goto x5vQY;
            B20OI:
            Log::error("Yi7VDaCr23YjR is not readable", ['imageId' => $C3gWL, 'error' => $O3GIQ->getMessage()]);
            goto Z1Una;
            bSvJs:
            jA2P3:
            goto B20OI;
            x5vQY:
            return;
            goto bSvJs;
            Z1Una:
        } finally {
            $y18o3 = microtime(true);
            $gFytm = memory_get_usage();
            $M3rCv = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $C3gWL, 'execution_time_sec' => $y18o3 - $vtCQy, 'memory_usage_mb' => ($gFytm - $V2w10) / 1024 / 1024, 'peak_memory_usage_mb' => ($M3rCv - $pQYLS) / 1024 / 1024]);
        }
        goto Jms4f;
        OxjhX:
        $vtCQy = microtime(true);
        goto o6QO4;
        o6QO4:
        $V2w10 = memory_get_usage();
        goto nbO1N;
        Ov33d:
        ini_set('memory_limit', '-1');
        goto K2Ake;
        nbO1N:
        $pQYLS = memory_get_peak_usage();
        goto YTtzo;
        YTtzo:
        Log::info("Adding watermark text to image", ['imageId' => $C3gWL]);
        goto Ov33d;
        Jms4f:
    }
    private function mPX9n8DyNQP($Jyrqg, $ojOHE) : void
    {
        goto CVZVH;
        z6ZFP:
        $this->m1w1p->put($lkjhr, $this->zl2D8->get($lkjhr));
        goto L1_sg;
        CVZVH:
        $Z_vN0 = $Jyrqg->width();
        goto GmCFI;
        GmCFI:
        $TPJAc = $Jyrqg->height();
        goto kyG1i;
        L1_sg:
        $DylMz = $this->u_yGf->call($this, $this->m1w1p->path($lkjhr));
        goto VjDG7;
        kyG1i:
        $TVH5M = new Ylymep3orr2As($this->n3RCf, $this->Nv87Y, $this->zl2D8, $this->m1w1p);
        goto r69rR;
        VjDG7:
        $Jyrqg->place($DylMz, 'top-left', 0, 0, 30);
        goto vmDEP;
        r69rR:
        $lkjhr = $TVH5M->mvfd3gqS7YV($Z_vN0, $TPJAc, $ojOHE, true);
        goto z6ZFP;
        vmDEP:
    }
}
