<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Uploader\Enum\IoCBJqqLig917;
class IkyXbdemqQ1go implements StoreToS3JobInterface
{
    private $u_yGf;
    private $zl2D8;
    private $IXK4e;
    public function __construct($pDQ4h, $VVGKi, $ZfrI6)
    {
        goto Pv8IQ;
        smcst:
        $this->u_yGf = $pDQ4h;
        goto fXPKJ;
        Pv8IQ:
        $this->zl2D8 = $VVGKi;
        goto CgEo0;
        CgEo0:
        $this->IXK4e = $ZfrI6;
        goto smcst;
        fXPKJ:
    }
    public function store(string $C3gWL) : void
    {
        goto IMYKI;
        hPEPq:
        $this->zl2D8->put($P9i2k->getAttribute('thumbnail'), $this->IXK4e->get($tA31P), ['visibility' => 'public', 'ContentType' => $MOwIc->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto C1uds;
        Xqjmn:
        Log::info("Yi7VDaCr23YjR has been deleted, discard it", ['fileId' => $C3gWL]);
        goto plPQq;
        fhpke:
        Log::info("Yi7VDaCr23YjR stored to S3, update the children attachments", ['fileId' => $C3gWL]);
        goto ek9oS;
        V3Gjj:
        $iwovL = $this->IXK4e->path($P9i2k->getAttribute('preview'));
        goto KxHQL;
        qhpR0:
        $this->mJYbMHBEBqw($PeSCk, $P9i2k->getLocation(), '.webp');
        goto YZ6cp;
        ek9oS:
        Yi7VDaCr23YjR::where('parent_id', $C3gWL)->update(['driver' => YZ2lA0H3k4o6O::S3, 'preview' => $P9i2k->getAttribute('preview'), 'thumbnail' => $P9i2k->getAttribute('thumbnail'), 'webp_path' => $P9i2k->getAttribute('webp_path')]);
        goto Dg3EE;
        VMqHK:
        if (!($P9i2k->getAttribute('preview') && $this->IXK4e->exists($P9i2k->getAttribute('preview')))) {
            goto MFqh6;
        }
        goto V3Gjj;
        GnCGE:
        iTq_w:
        goto cXzA5;
        DNscA:
        $this->zl2D8->put($P9i2k->getAttribute('preview'), $this->IXK4e->get($P9i2k->getAttribute('preview')), ['visibility' => 'public', 'ContentType' => $fo6KI->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Fn1az;
        Dg3EE:
        return;
        goto L9lqy;
        RdevP:
        $MOwIc = $this->u_yGf->call($this, $EJuN9);
        goto hPEPq;
        e7BVW:
        if ($P9i2k) {
            goto iTq_w;
        }
        goto Xqjmn;
        Fn1az:
        MFqh6:
        goto ZuXyX;
        IMYKI:
        $P9i2k = Yi7VDaCr23YjR::findOrFail($C3gWL);
        goto e7BVW;
        gVjlW:
        $this->mJYbMHBEBqw($PeSCk, $P9i2k->getLocation());
        goto qhpR0;
        ZuXyX:
        if (!$P9i2k->update(['driver' => YZ2lA0H3k4o6O::S3, 'status' => IoCBJqqLig917::FINISHED])) {
            goto lH5o5;
        }
        goto fhpke;
        KxHQL:
        $fo6KI = $this->u_yGf->call($this, $iwovL);
        goto DNscA;
        L9lqy:
        lH5o5:
        goto zdUX9;
        C1uds:
        CXFpB:
        goto VMqHK;
        zdUX9:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $C3gWL]);
        goto e9n7o;
        plPQq:
        return;
        goto GnCGE;
        cXzA5:
        $PeSCk = $this->IXK4e->path($P9i2k->getLocation());
        goto gVjlW;
        bBrqP:
        $EJuN9 = $this->IXK4e->path($tA31P);
        goto RdevP;
        YZ6cp:
        $tA31P = $P9i2k->getAttribute('thumbnail');
        goto eGNr5;
        eGNr5:
        if (!($tA31P && $this->IXK4e->exists($tA31P))) {
            goto CXFpB;
        }
        goto bBrqP;
        e9n7o:
    }
    private function mJYbMHBEBqw($SHi77, $mdr1C, $N_oUJ = '')
    {
        goto Koifj;
        kSrBp:
        try {
            $OgE9J = $this->u_yGf->call($this, $SHi77);
            $this->zl2D8->put($mdr1C, $this->IXK4e->get($mdr1C), ['visibility' => 'public', 'ContentType' => $OgE9J->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $TTMgE) {
            Log::error("Failed to upload image to S3", ['s3Path' => $mdr1C, 'error' => $TTMgE->getMessage()]);
        }
        goto EfA0X;
        Q0Gy9:
        $mdr1C = str_replace('.jpg', $N_oUJ, $mdr1C);
        goto rnB0L;
        qDLD1:
        $SHi77 = str_replace('.jpg', $N_oUJ, $SHi77);
        goto Q0Gy9;
        Koifj:
        if (!$N_oUJ) {
            goto oJhYs;
        }
        goto qDLD1;
        rnB0L:
        oJhYs:
        goto kSrBp;
        EfA0X:
    }
}
