<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
class MoIhgOdmNnptR implements DownloadToLocalJobInterface
{
    private $j_caY;
    private $NBa8l;
    public function __construct($nFXer, $J2eOE)
    {
        $this->j_caY = $nFXer;
        $this->NBa8l = $J2eOE;
    }
    public function download(string $W0vWP) : void
    {
        goto YsY3z;
        kUAof:
        aD6MX:
        goto cdzSU;
        afpwn:
        return;
        goto kUAof;
        tPEeB:
        Log::info("Start download file to local", ['fileId' => $W0vWP, 'filename' => $uY0L7->getLocation()]);
        goto eDkkj;
        cdzSU:
        $this->NBa8l->put($uY0L7->getLocation(), $this->j_caY->get($uY0L7->getLocation()));
        goto dqlE7;
        YsY3z:
        $uY0L7 = Il0T1UmENcpfh::findOrFail($W0vWP);
        goto tPEeB;
        eDkkj:
        if (!$this->NBa8l->exists($uY0L7->getLocation())) {
            goto aD6MX;
        }
        goto afpwn;
        dqlE7:
    }
}
