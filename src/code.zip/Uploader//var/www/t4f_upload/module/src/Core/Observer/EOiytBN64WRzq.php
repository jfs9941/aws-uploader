<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Contracts\TS9H8HOxifnQ6;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
class EOiytBN64WRzq implements TS9H8HOxifnQ6
{
    private $d2AB9;
    public function __construct($uY0L7)
    {
        $this->d2AB9 = $uY0L7;
    }
    public function m2AgYct6sO6($kUpO4, $negwf)
    {
        goto ibmMK;
        ibmMK:
        if (!(OHa83BAIlECUz::UPLOADED === $negwf)) {
            goto xm6VL;
        }
        goto c_Y1S;
        o0EJ9:
        S4yf_:
        goto IZLzr;
        eRPUg:
        $this->d2AB9->mySoGGDrYI4(OHa83BAIlECUz::PROCESSING);
        goto YTwAl;
        YTwAl:
        duQ35:
        goto HrRMS;
        t87R4:
        if (!(OHa83BAIlECUz::DELETED === $negwf && $this->d2AB9->mAEluUPupbN())) {
            goto S4yf_;
        }
        goto cwzml;
        cwzml:
        $this->d2AB9->delete();
        goto o0EJ9;
        c_Y1S:
        $this->d2AB9->status = OHa83BAIlECUz::UPLOADED;
        goto PFmHQ;
        HrRMS:
        $this->d2AB9->save();
        goto n2cRD;
        n2cRD:
        xm6VL:
        goto t87R4;
        PFmHQ:
        if (!$this->d2AB9 instanceof Il0T1UmENcpfh) {
            goto duQ35;
        }
        goto eRPUg;
        IZLzr:
    }
}
