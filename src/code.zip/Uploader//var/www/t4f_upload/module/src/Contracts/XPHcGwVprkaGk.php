<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\HHLHHofZj2D7E;
interface XPHcGwVprkaGk
{
    public function mN5D2NajOK4($juM0q);
    public function mDE3ncGQvuQ();
    public function mZJDINqUefY($DYYHY);
    public function mokNyFW0YPU($DYYHY);
    public function mKGeLgXFwuF(DMLDNHSs7xy9p $sPwJT);
}
