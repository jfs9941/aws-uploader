<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
final class FutyevYt174lN
{
    public $filename;
    public $SZq6f;
    public $lEUBo;
    public $O380t;
    public $kZCFD;
    public $x3RSN;
    public $L6G5Y;
    public $status;
    public $WAOt0;
    public $mxcVx;
    public $jWhvV = 's3';
    public $xAv8B = [];
    public function __construct($WEydE, $ueo5N, $gKC0c, $pM1zj, $rDUTV, $i51wU, $YPMFl, $wUV79, $hVGUs, $JC43m, $yarYL = 's3', $haCEo = [])
    {
        goto iLfAg;
        KbUx7:
        $this->x3RSN = $i51wU;
        goto vHqrG;
        CYg6Y:
        $this->xAv8B = $haCEo;
        goto IKp3Z;
        cqJj_:
        $this->SZq6f = $ueo5N;
        goto vfnat;
        Wi8F0:
        $this->jWhvV = $yarYL;
        goto CYg6Y;
        zCd3V:
        $this->O380t = $pM1zj;
        goto BzWKi;
        KEijV:
        $this->mxcVx = $JC43m;
        goto Wi8F0;
        DTx2E:
        $this->status = $wUV79;
        goto tSre9;
        vfnat:
        $this->lEUBo = $gKC0c;
        goto zCd3V;
        BzWKi:
        $this->kZCFD = $rDUTV;
        goto KbUx7;
        tSre9:
        $this->WAOt0 = $hVGUs;
        goto KEijV;
        vHqrG:
        $this->L6G5Y = $YPMFl;
        goto DTx2E;
        iLfAg:
        $this->filename = $WEydE;
        goto cqJj_;
        IKp3Z:
    }
    private static function mNsBHDzCVlw() : array
    {
        return ['filename' => 'fn', 'fileExtension' => 'fe', 'mimeType' => 'mt', 'fileSize' => 'fs', 'chunkSize' => 'cs', 'checksums' => 'ch', 'totalChunk' => 'tc', 'status' => 'st', 'userId' => 'ui', 'uploadId' => 'up', 'driver' => 'dr', 'parts' => 'pt'];
    }
    private static function mgCVpftpRRG() : array
    {
        return array_flip(self::mNsBHDzCVlw());
    }
    public function toArray() : array
    {
        $nmQyS = self::mNsBHDzCVlw();
        return [$nmQyS['filename'] => $this->filename, $nmQyS['fileExtension'] => $this->SZq6f, $nmQyS['mimeType'] => $this->lEUBo, $nmQyS['fileSize'] => $this->O380t, $nmQyS['chunkSize'] => $this->kZCFD, $nmQyS['checksums'] => $this->x3RSN, $nmQyS['totalChunk'] => $this->L6G5Y, $nmQyS['status'] => $this->status, $nmQyS['userId'] => $this->WAOt0, $nmQyS['uploadId'] => $this->mxcVx, $nmQyS['driver'] => $this->jWhvV, $nmQyS['parts'] => $this->xAv8B];
    }
    public static function mK1lp7wm8WV(array $jC20Z) : self
    {
        $v9a51 = array_flip(self::mgCVpftpRRG());
        return new self($jC20Z[$v9a51['filename']] ?? $jC20Z['filename'] ?? '', $jC20Z[$v9a51['fileExtension']] ?? $jC20Z['fileExtension'] ?? '', $jC20Z[$v9a51['mimeType']] ?? $jC20Z['mimeType'] ?? '', $jC20Z[$v9a51['fileSize']] ?? $jC20Z['fileSize'] ?? 0, $jC20Z[$v9a51['chunkSize']] ?? $jC20Z['chunkSize'] ?? 0, $jC20Z[$v9a51['checksums']] ?? $jC20Z['checksums'] ?? [], $jC20Z[$v9a51['totalChunk']] ?? $jC20Z['totalChunk'] ?? 0, $jC20Z[$v9a51['status']] ?? $jC20Z['status'] ?? 0, $jC20Z[$v9a51['userId']] ?? $jC20Z['userId'] ?? 0, $jC20Z[$v9a51['uploadId']] ?? $jC20Z['uploadId'] ?? '', $jC20Z[$v9a51['driver']] ?? $jC20Z['driver'] ?? 's3', $jC20Z[$v9a51['parts']] ?? $jC20Z['parts'] ?? []);
    }
    public static function mmVAophsLl6($id0wD) : self
    {
        goto jrwPp;
        OKg0e:
        xDxd4:
        goto ya66_;
        ya66_:
        throw new \Exception("Deprecated method called with unsupported format.");
        goto O6Mfm;
        S0SUm:
        return self::mK1lp7wm8WV($id0wD);
        goto OKg0e;
        jrwPp:
        if (!(isset($id0wD['fn']) || isset($id0wD['fe']))) {
            goto xDxd4;
        }
        goto S0SUm;
        O6Mfm:
    }
    public function mX4syai7ACI(string $JC43m) : void
    {
        $this->mxcVx = $JC43m;
    }
    public function mxcBhsFv9un(array $haCEo) : void
    {
        $this->xAv8B = $haCEo;
    }
    public static function mP3MvfGsqFI($PW_5C, $gbLld, $nrJPB, $hVGUs, $rDUTV, $i51wU, $yarYL)
    {
        return new self($PW_5C->getFilename(), $PW_5C->getExtension(), $gbLld, $nrJPB, $rDUTV, $i51wU, count($i51wU), YGB86F7VDD6Xo::UPLOADING, $hVGUs, 0, $yarYL, []);
    }
    public static function mUYRC1czCXw($G2Ngo)
    {
        return 'metadata/' . $G2Ngo . '.json';
    }
    public function myFHyucaYMH()
    {
        return 's3' === $this->jWhvV ? BHGv9oAB1EERw::S3 : BHGv9oAB1EERw::LOCAL;
    }
}
