<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
class SuMiYCAXAyp1p implements BlurJobInterface
{
    const CtLNy = 15;
    const c_n1E = 500;
    const PelEu = 500;
    private $u_yGf;
    private $zl2D8;
    private $IXK4e;
    public function __construct($pDQ4h, $VVGKi, $ZfrI6)
    {
        goto XMB5S;
        FUY0I:
        $this->u_yGf = $pDQ4h;
        goto uzkrw;
        XMB5S:
        $this->IXK4e = $ZfrI6;
        goto nJ1nJ;
        nJ1nJ:
        $this->zl2D8 = $VVGKi;
        goto FUY0I;
        uzkrw:
    }
    public function blur(string $C3gWL) : void
    {
        goto ZCvNX;
        ygysv:
        $OgE9J->save($V4CGf);
        goto NSrUJ;
        KeHEs:
        $OgE9J->resize(self::c_n1E, self::PelEu / $U_mGc);
        goto Nj_oo;
        rFCWN:
        $iwovL = $this->mSCxjEH4neR($P9i2k);
        goto cChWG;
        ZCvNX:
        $P9i2k = Yi7VDaCr23YjR::findOrFail($C3gWL);
        goto URe29;
        EQygE:
        throw new \Exception('Failed to set final permissions on image file: ' . $V4CGf);
        goto MLDQY;
        bi2KP:
        $P9i2k->update(['preview' => $iwovL]);
        goto NUgzS;
        Nj_oo:
        $OgE9J->blur(self::CtLNy);
        goto rFCWN;
        NSrUJ:
        unset($OgE9J);
        goto W9lQU;
        cXe1V:
        umTT0:
        goto lAstt;
        rNn35:
        \Log::warning('Failed to set final permissions on image file: ' . $V4CGf);
        goto EQygE;
        W9lQU:
        if (chmod($V4CGf, 0664)) {
            goto zWlzV;
        }
        goto rNn35;
        lAstt:
        $OgE9J = $this->u_yGf->call($this, $this->IXK4e->path($P9i2k->getLocation()));
        goto sEXFj;
        sEXFj:
        $U_mGc = $OgE9J->width() / $OgE9J->height();
        goto KeHEs;
        URe29:
        ini_set('memory_limit', '-1');
        goto nJ5R2;
        MLDQY:
        zWlzV:
        goto bi2KP;
        nJ5R2:
        if (!($P9i2k->dduPi == YZ2lA0H3k4o6O::S3 && !$this->IXK4e->exists($P9i2k->filename))) {
            goto umTT0;
        }
        goto b_7Rq;
        b_7Rq:
        $IzaHE = $this->zl2D8->get($P9i2k->filename);
        goto DdrUE;
        cChWG:
        $V4CGf = $this->IXK4e->path($iwovL);
        goto ygysv;
        DdrUE:
        $this->IXK4e->put($P9i2k->filename, $IzaHE);
        goto cXe1V;
        NUgzS:
    }
    private function mSCxjEH4neR($mgM7g) : string
    {
        goto USynP;
        Vu8L0:
        D5o3O:
        goto bpmhA;
        xT23o:
        $jPesJ = dirname($PeSCk) . '/preview/';
        goto m0y42;
        Vzp3T:
        $this->IXK4e->makeDirectory($jPesJ, 0755, true);
        goto Vu8L0;
        USynP:
        $PeSCk = $mgM7g->getLocation();
        goto xT23o;
        m0y42:
        if ($this->IXK4e->exists($jPesJ)) {
            goto D5o3O;
        }
        goto Vzp3T;
        bpmhA:
        return $jPesJ . $mgM7g->getFilename() . '.jpg';
        goto o1TQ0;
        o1TQ0:
    }
}
