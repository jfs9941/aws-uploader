<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Uploader\Enum\IoCBJqqLig917;
class OR1S3YAm3o8ZT implements StoreVideoToS3JobInterface
{
    private $Lfs5p;
    private $zl2D8;
    private $IXK4e;
    public function __construct($ysemJ, $VVGKi, $ZfrI6)
    {
        goto tSykL;
        E9m2y:
        $this->IXK4e = $ZfrI6;
        goto H_PDC;
        H_PDC:
        $this->Lfs5p = $ysemJ;
        goto mAHfx;
        tSykL:
        $this->zl2D8 = $VVGKi;
        goto E9m2y;
        mAHfx:
    }
    public function store(string $C3gWL) : void
    {
        goto i6qKu;
        HRnE0:
        my8fU:
        goto WT1xH;
        q2pcJ:
        JHwU6:
        goto scn7L;
        RtSz2:
        $pQYLS = memory_get_peak_usage();
        goto y7oOg;
        fb6MS:
        $ZfrI6 = $this->IXK4e;
        goto AboK8;
        Ekhse:
        ini_set('memory_limit', '-1');
        goto gnypb;
        scn7L:
        $Ddodd = $ZfrI6->readStream($NiCuJ->getLocation());
        goto LOxhg;
        AboK8:
        $NiCuJ = Zr0izVmbs7QaE::find($C3gWL);
        goto m4SJN;
        bi_pX:
        $V2w10 = memory_get_usage();
        goto RtSz2;
        m4SJN:
        if ($NiCuJ) {
            goto my8fU;
        }
        goto Xakcj;
        GDTt7:
        $vtCQy = microtime(true);
        goto bi_pX;
        gnypb:
        $ZwGMx = $this->zl2D8->getClient();
        goto fb6MS;
        WT1xH:
        if ($ZfrI6->exists($NiCuJ->getLocation())) {
            goto JHwU6;
        }
        goto jW0rm;
        jW0rm:
        Log::error("[OR1S3YAm3o8ZT] File not found, discard it ", ['video' => $NiCuJ->getLocation()]);
        goto zALUt;
        MVMzT:
        return;
        goto HRnE0;
        Xakcj:
        Log::info("Zr0izVmbs7QaE has been deleted, discard it", ['fileId' => $C3gWL]);
        goto MVMzT;
        LOxhg:
        $t16Bz = 1024 * 1024 * 50;
        goto Sph0p;
        zALUt:
        return;
        goto q2pcJ;
        y7oOg:
        try {
            goto deAyY;
            deAyY:
            $cUHx5 = $ZwGMx->createMultipartUpload(['Bucket' => $this->Lfs5p, 'Key' => $NiCuJ->getLocation(), 'ContentType' => $xjved, 'ContentDisposition' => 'inline']);
            goto xqkDs;
            xqkDs:
            $apWXG = $cUHx5['UploadId'];
            goto rax9S;
            XSDCB:
            $O9jdF[] = ['PartNumber' => $yX1zL, 'ETag' => $HM3WX['ETag']];
            goto XWcVb;
            hGJvC:
            $ZfrI6->delete($NiCuJ->getLocation());
            goto CVPs4;
            jfUJE:
            wC_JU:
            goto mn2ar;
            rax9S:
            $yX1zL = 1;
            goto rn5a7;
            qCAPK:
            fclose($Ddodd);
            goto prbKX;
            GGx77:
            LcU9N:
            goto qCAPK;
            prbKX:
            $ZwGMx->completeMultipartUpload(['Bucket' => $this->Lfs5p, 'Key' => $NiCuJ->getLocation(), 'UploadId' => $apWXG, 'MultipartUpload' => ['Parts' => $O9jdF]]);
            goto KwItX;
            jaUf0:
            goto wC_JU;
            goto GGx77;
            mn2ar:
            if (feof($Ddodd)) {
                goto LcU9N;
            }
            goto NqPfS;
            XWcVb:
            $yX1zL++;
            goto jaUf0;
            NqPfS:
            $HM3WX = $ZwGMx->uploadPart(['Bucket' => $this->Lfs5p, 'Key' => $NiCuJ->getLocation(), 'UploadId' => $apWXG, 'PartNumber' => $yX1zL, 'Body' => fread($Ddodd, $t16Bz)]);
            goto XSDCB;
            KwItX:
            $NiCuJ->update(['driver' => YZ2lA0H3k4o6O::S3, 'status' => IoCBJqqLig917::FINISHED]);
            goto hGJvC;
            rn5a7:
            $O9jdF = [];
            goto jfUJE;
            CVPs4:
        } catch (AwsException $BTAgP) {
            goto l2Z3H;
            ErP0_:
            Log::error('Failed to store video: ' . $NiCuJ->getLocation() . ' - ' . $BTAgP->getMessage());
            goto TuT_w;
            tN2LA:
            try {
                $ZwGMx->abortMultipartUpload(['Bucket' => $this->Lfs5p, 'Key' => $NiCuJ->getLocation(), 'UploadId' => $apWXG]);
            } catch (AwsException $ptjqS) {
                Log::error('Error aborting multipart upload: ' . $ptjqS->getMessage());
            }
            goto q_v9m;
            q_v9m:
            w8vwY:
            goto ErP0_;
            l2Z3H:
            if (!isset($apWXG)) {
                goto w8vwY;
            }
            goto tN2LA;
            TuT_w:
        } finally {
            $y18o3 = microtime(true);
            $gFytm = memory_get_usage();
            $M3rCv = memory_get_peak_usage();
            Log::info('Store Zr0izVmbs7QaE to S3 function resource usage', ['imageId' => $C3gWL, 'execution_time_sec' => $y18o3 - $vtCQy, 'memory_usage_mb' => ($gFytm - $V2w10) / 1024 / 1024, 'peak_memory_usage_mb' => ($M3rCv - $pQYLS) / 1024 / 1024]);
        }
        goto n9NgG;
        i6qKu:
        Log::info('Storing video (local) to S3', ['fileId' => $C3gWL, 'bucketName' => $this->Lfs5p]);
        goto Ekhse;
        Sph0p:
        $xjved = $ZfrI6->mimeType($NiCuJ->getLocation());
        goto GDTt7;
        n9NgG:
    }
}
