<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\TS9H8HOxifnQ6;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Exception\D6MBMAoedrGZe;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Jfs\Uploader\Presigned\H6tUwlNprrmIc;
use Jfs\Uploader\Presigned\OO649rn0rh8ZA;
final class SKEO676c9OopQ implements TS9H8HOxifnQ6
{
    private $yfA3L;
    private $i3lQr;
    private $JZDCA;
    private $BBjq4;
    private $wweWZ;
    public function __construct($wxGNA, $WPRCg, $XdRPm, $VxiVW, $AuYj0 = false)
    {
        goto av96E;
        eBX9P:
        $this->JZDCA = $WPRCg;
        goto vVpBE;
        vVpBE:
        $this->BBjq4 = $XdRPm;
        goto uhmUn;
        X0_nm:
        if ($AuYj0) {
            goto QHvJp;
        }
        goto Q3mk7;
        bzynT:
        QHvJp:
        goto JPA7Z;
        uhmUn:
        $this->wweWZ = $VxiVW;
        goto X0_nm;
        Q3mk7:
        $this->mkupeZWh2cQ();
        goto bzynT;
        av96E:
        $this->i3lQr = $wxGNA;
        goto eBX9P;
        JPA7Z:
    }
    private function mkupeZWh2cQ() : void
    {
        goto RZ76p;
        n8RY8:
        try {
            $eiM1z = $this->i3lQr->mhr9LcPnRdj();
            $this->yfA3L = 's3' === $eiM1z->WNE_L ? new OO649rn0rh8ZA($this->i3lQr, $this->JZDCA, $this->BBjq4, $this->wweWZ) : new H6tUwlNprrmIc($this->i3lQr, $this->JZDCA, $this->BBjq4);
        } catch (NTFGijXrreOP3 $iCEwa) {
            Log::warning("Failed to set up presigned upload: {$iCEwa->getMessage()}");
        }
        goto e_MrY;
        XYIe5:
        return;
        goto VW1Bv;
        VW1Bv:
        mW2NS:
        goto n8RY8;
        RZ76p:
        if (!(null !== $this->yfA3L)) {
            goto mW2NS;
        }
        goto XYIe5;
        e_MrY:
    }
    public function m2AgYct6sO6($kUpO4, $negwf)
    {
        goto jLfib;
        eoHKU:
        switch ($negwf) {
            case OHa83BAIlECUz::UPLOADING:
                $this->mEzX6VRX1UK();
                goto c1_3L;
            case OHa83BAIlECUz::UPLOADED:
                $this->m2LWu34gyJs();
                goto c1_3L;
            case OHa83BAIlECUz::ABORTED:
                $this->muZDJHQPEFJ();
                goto c1_3L;
            default:
                goto c1_3L;
        }
        goto ZNgbw;
        aZbR2:
        c1_3L:
        goto Tkkal;
        jLfib:
        $this->mkupeZWh2cQ();
        goto eoHKU;
        ZNgbw:
        ZcBm1:
        goto aZbR2;
        Tkkal:
    }
    private function m2LWu34gyJs() : void
    {
        goto Z5ppn;
        s1DAq:
        $uY0L7 = $this->i3lQr->getFile();
        goto GqyXx;
        GqyXx:
        $uY0L7->mySoGGDrYI4(OHa83BAIlECUz::UPLOADED);
        goto SD7xw;
        Z5ppn:
        $this->yfA3L->mdnRCqLYYn2();
        goto s1DAq;
        RbCzC:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($uY0L7->id);
        goto jqlQS;
        SD7xw:
        if (!$uY0L7 instanceof S1qX7zy4Guf94) {
            goto lrMNU;
        }
        goto RbCzC;
        jqlQS:
        lrMNU:
        goto ZbCzk;
        ZbCzk:
    }
    private function muZDJHQPEFJ() : void
    {
        $this->yfA3L->mwPLyydlbvG();
    }
    private function mEzX6VRX1UK() : void
    {
        $this->yfA3L->mWCsuh0MINY();
    }
}
