<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class UzbaS2PYzymry implements GenerateThumbnailForVideoInterface
{
    private $e2znc;
    public function __construct($llU5s)
    {
        $this->e2znc = $llU5s;
    }
    public function generate(string $C3gWL) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $C3gWL);
        $this->e2znc->createThumbnail($C3gWL);
    }
}
