<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Encoder\DFtX4SxXxkHYz;
class BCNuwPRfay7px implements FileProcessingStrategyInterface
{
    private $hq35s;
    private $jKNx0;
    private $iscTQ;
    public function __construct(J2nNudRqcfTj1 $KdniT, DFtX4SxXxkHYz $PbQYK)
    {
        goto er055;
        vn7WG:
        $l8Ozu = config('upload.post_process_video');
        goto G4SOo;
        G4SOo:
        $this->iscTQ = new $l8Ozu($KdniT, $PbQYK);
        goto mFiiu;
        S54yU:
        $this->jKNx0 = $PbQYK;
        goto vn7WG;
        er055:
        $this->hq35s = $KdniT;
        goto S54yU;
        mFiiu:
    }
    public function process($Bz8s_)
    {
        $this->iscTQ->process($Bz8s_);
    }
}
