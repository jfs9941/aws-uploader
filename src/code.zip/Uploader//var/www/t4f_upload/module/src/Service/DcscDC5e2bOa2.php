<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\CKc1zCD1DcxJi;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Core\RTkNv5GS7FY9w;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
final class DcscDC5e2bOa2 implements CKc1zCD1DcxJi
{
    private $BYYM3;
    private $ulgGa;
    public $PNQDA;
    private $qCf4s;
    private $E3Fo6;
    private $IXK4e;
    public function __construct($UpXat, $gmsTx, $imQaB, $UeJLv, $cKai3, $ZfrI6)
    {
        goto ykodJ;
        zzK2I:
        $this->qCf4s = $UeJLv;
        goto G7KVI;
        uvmIj:
        $this->PNQDA = $imQaB;
        goto zzK2I;
        nJ3oI:
        $this->BYYM3 = $UpXat;
        goto lMToR;
        ykodJ:
        $this->IXK4e = $ZfrI6;
        goto nJ3oI;
        G7KVI:
        $this->E3Fo6 = $cKai3;
        goto aBtF5;
        lMToR:
        $this->ulgGa = $gmsTx;
        goto uvmIj;
        aBtF5:
    }
    public function resolvePath($MoQri, $izVKZ = YZ2lA0H3k4o6O::S3) : string
    {
        goto UypkN;
        xT49w:
        return trim($this->ulgGa, '/') . '/' . $MoQri;
        goto Bmx4h;
        v8ohv:
        return $this->mw6cCl98dNa($MoQri);
        goto utfMG;
        Fi9Sy:
        $MoQri = $MoQri->getAttribute('filename');
        goto jSPgT;
        Tl_md:
        if (!$this->BYYM3) {
            goto SxaD0;
        }
        goto MC1tm;
        xZTEF:
        return config('upload.home') . '/' . $MoQri;
        goto iVHpn;
        MC1tm:
        return trim($this->PNQDA, '/') . '/' . $MoQri;
        goto IeD9x;
        Hp_kh:
        if (!(!empty($this->qCf4s) && !empty($this->E3Fo6))) {
            goto X9fh0;
        }
        goto v8ohv;
        iVHpn:
        ffrA9:
        goto Hp_kh;
        A17WB:
        if (!($izVKZ === YZ2lA0H3k4o6O::LOCAL)) {
            goto ffrA9;
        }
        goto xZTEF;
        IeD9x:
        SxaD0:
        goto xT49w;
        UypkN:
        if (!$MoQri instanceof REvUXqyajwths) {
            goto opVrx;
        }
        goto Fi9Sy;
        utfMG:
        X9fh0:
        goto Tl_md;
        jSPgT:
        opVrx:
        goto A17WB;
        Bmx4h:
    }
    public function resolveThumbnail(REvUXqyajwths $MoQri) : string
    {
        goto vDC4L;
        ky2D0:
        QNDGJ:
        goto pYPKx;
        MNfox:
        $RawVe = Yi7VDaCr23YjR::find($MoQri->getAttribute('thumbnail_id'));
        goto CU3X3;
        tqdMD:
        return '';
        goto uoYCN;
        dRCVY:
        LDWZB:
        goto w3EU0;
        DQOI8:
        if (!$MOwIc) {
            goto LDWZB;
        }
        goto Hmeba;
        CU3X3:
        if (!$RawVe) {
            goto QNDGJ;
        }
        goto U64wu;
        MK7NN:
        OxPl5:
        goto KtI7i;
        Hmeba:
        return $this->url($MOwIc, $MoQri->getAttribute('driver'));
        goto dRCVY;
        vDC4L:
        $MOwIc = $MoQri->getAttribute('thumbnail');
        goto DQOI8;
        KtI7i:
        if (!$MoQri instanceof RTkNv5GS7FY9w) {
            goto L2dXH;
        }
        goto NagQT;
        pYPKx:
        HK1Da:
        goto y2p3x;
        NagQT:
        return asset('/img/pdf-preview.svg');
        goto GSRKq;
        w3EU0:
        if (!$MoQri->getAttribute('thumbnail_id')) {
            goto HK1Da;
        }
        goto MNfox;
        GSRKq:
        L2dXH:
        goto tqdMD;
        U64wu:
        return $this->resolvePath($RawVe, $RawVe->getAttribute('driver'));
        goto ky2D0;
        OPc2m:
        return $this->resolvePath($MoQri, $MoQri->getAttribute('driver'));
        goto MK7NN;
        y2p3x:
        if (!$MoQri instanceof Yi7VDaCr23YjR) {
            goto OxPl5;
        }
        goto OPc2m;
        uoYCN:
    }
    private function url($PeSCk, $izVKZ)
    {
        goto bxw_Y;
        bxw_Y:
        if (!($izVKZ == YZ2lA0H3k4o6O::LOCAL)) {
            goto ESNvJ;
        }
        goto wPvyW;
        nXc6R:
        ESNvJ:
        goto DyfQr;
        wPvyW:
        return config('upload.home') . '/' . $PeSCk;
        goto nXc6R;
        DyfQr:
        return $this->resolvePath($PeSCk);
        goto Tkt7E;
        Tkt7E:
    }
    private function mw6cCl98dNa($PeSCk)
    {
        goto zJFgz;
        RZ0Ti:
        $m3xJV = now()->addMinutes(60)->timestamp;
        goto Q8_hA;
        wtHtC:
        H0ab0:
        goto RZ0Ti;
        lz346:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto wtHtC;
        eR6rA:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto g9fbw;
        UPou5:
        if (!(strpos($PeSCk, 'm3u8') !== false)) {
            goto H0ab0;
        }
        goto lz346;
        ssKly:
        return $y2cWJ->getSignedUrl($this->PNQDA . '/' . $PeSCk, $m3xJV);
        goto SPOqx;
        g9fbw:
        RyomA:
        goto UPou5;
        Q8_hA:
        $y2cWJ = new UrlSigner($this->qCf4s, $this->IXK4e->path($this->E3Fo6));
        goto ssKly;
        zJFgz:
        if (!(strpos($PeSCk, 'https://') === 0)) {
            goto RyomA;
        }
        goto eR6rA;
        SPOqx:
    }
    public function resolvePathForHlsVideo(Zr0izVmbs7QaE $jTXdP, $yFiE2 = false) : string
    {
        goto vTTPC;
        I4SUp:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto xsCTo;
        VXyCs:
        return $this->PNQDA . '/' . $jTXdP->getAttribute('hls_path');
        goto JZF_j;
        vTTPC:
        if ($jTXdP->getAttribute('hls_path')) {
            goto spcCs;
        }
        goto I4SUp;
        xsCTo:
        spcCs:
        goto VXyCs;
        JZF_j:
    }
    public function resolvePathForHlsVideos()
    {
        goto C01GK;
        BSRWu:
        $bPFlO = $this->PNQDA . '/v2/hls/';
        goto UU99_;
        of72F:
        $m9V2h = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto ywKFC;
        uguaB:
        return [$Me7dj, $m3xJV];
        goto VrsXn;
        C01GK:
        $m3xJV = now()->addDays(3)->timestamp;
        goto BSRWu;
        ywKFC:
        $Me7dj = $m9V2h->getSignedCookie(['key_pair_id' => $this->qCf4s, 'private_key' => $this->IXK4e->path($this->E3Fo6), 'policy' => $SLu27]);
        goto uguaB;
        UU99_:
        $SLu27 = json_encode(['Statement' => [['Resource' => sprintf('%s*', $bPFlO), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $m3xJV]]]]]);
        goto of72F;
        VrsXn:
    }
}
