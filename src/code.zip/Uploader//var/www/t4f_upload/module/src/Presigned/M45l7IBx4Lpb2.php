<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\H7OWocYFy30FB;
use Jfs\Uploader\Exception\Gv0aptVkeUozb;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class M45l7IBx4Lpb2 implements TBTGazsaTHh1M
{
    private static $MJ41w = 'chunks/';
    private $gMoIS;
    private $HO2X0;
    private $Q3Qp4;
    public function __construct(H7OWocYFy30FB $EljXk, Filesystem $skn0D, Filesystem $YS7_M)
    {
        goto YWPeg;
        YNPCh:
        $this->HO2X0 = $skn0D;
        goto NFY1u;
        NFY1u:
        $this->Q3Qp4 = $YS7_M;
        goto JboSR;
        YWPeg:
        $this->gMoIS = $EljXk;
        goto YNPCh;
        JboSR:
    }
    public function m0BpXIBYPaJ() : void
    {
        goto CVVTs;
        q_0FA:
        $JC43m = Uuid::v4()->toHex();
        goto fytC3;
        Nv3Sy:
        $this->gMoIS->mpti44yUWjH()->mX4syai7ACI($JC43m);
        goto lulHb;
        W1t2Z:
        goto AFm_M;
        goto ZpEn_;
        tvk1f:
        $Sc5jc = 1;
        goto DrO_Z;
        Spf0C:
        IdLwG:
        goto iGgrx;
        DrO_Z:
        AFm_M:
        goto KGLmk;
        fytC3:
        $this->gMoIS->mpti44yUWjH()->mX4syai7ACI($JC43m);
        goto tvk1f;
        lulHb:
        $this->HO2X0->put($this->gMoIS->mNRyYDQLTdL(), json_encode($this->gMoIS->mpti44yUWjH()->toArray()));
        goto s87sb;
        s4CLC:
        $bbcnG[] = ['index' => $Sc5jc, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $JC43m, 'index' => $Sc5jc])];
        goto Spf0C;
        iGgrx:
        ++$Sc5jc;
        goto W1t2Z;
        gzIbl:
        $jxa1X = ceil($h0F7E->O380t / $h0F7E->kZCFD);
        goto q_0FA;
        s87sb:
        $this->Q3Qp4->put($this->gMoIS->mNRyYDQLTdL(), json_encode($this->gMoIS->mpti44yUWjH()->toArray()));
        goto vB1r_;
        FWQoQ:
        $this->gMoIS->msorfj1OM9E($bbcnG);
        goto Nv3Sy;
        CVVTs:
        $h0F7E = $this->gMoIS->mpti44yUWjH();
        goto oTV7v;
        ZpEn_:
        hhHtK:
        goto FWQoQ;
        KGLmk:
        if (!($Sc5jc <= $jxa1X)) {
            goto hhHtK;
        }
        goto s4CLC;
        oTV7v:
        $bbcnG = [];
        goto gzIbl;
        vB1r_:
    }
    public function mR8nrUJhhp7() : void
    {
        goto JfsU_;
        qvjK4:
        $this->Q3Qp4->delete($this->gMoIS->mNRyYDQLTdL());
        goto PdGGa;
        JfsU_:
        $h0F7E = $this->gMoIS->mpti44yUWjH();
        goto V5pjX;
        V5pjX:
        $JC43m = $h0F7E->mxcVx;
        goto PGrhL;
        PGrhL:
        $this->HO2X0->deleteDirectory(self::$MJ41w . $JC43m);
        goto qvjK4;
        PdGGa:
    }
    public function mAYMPMrjwD6() : void
    {
        goto Fe06G;
        I5PXH:
        Assert::eq(count($fM8fX), $jxa1X, 'The number of parts and checksums must match.');
        goto c3r7Y;
        adBdT:
        $vc80w = $this->HO2X0->path($HDr30);
        goto wvenx;
        xx31F:
        $p5V30 = self::$MJ41w . $h0F7E->mxcVx;
        goto crKJN;
        eakNr:
        fvUtw:
        goto KUS8i;
        CCZDL:
        fclose($KAhBS);
        goto fGu_D;
        pz2U6:
        $jxa1X = $h0F7E->L6G5Y;
        goto xx31F;
        fGu_D:
        $euWMh = $this->HO2X0->path($HDr30);
        goto EbzSz;
        F05C7:
        if ($this->HO2X0->exists($Adve_)) {
            goto wcovP;
        }
        goto bp7I0;
        ZuXMD:
        JM7OA:
        goto CCZDL;
        pWSiE:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $euWMh);
        goto TQhLU;
        c3r7Y:
        natsort($fM8fX);
        goto sE1GM;
        GwksK:
        $KAhBS = @fopen($vc80w, 'wb');
        goto APyGq;
        APyGq:
        if (!(false === $KAhBS)) {
            goto DrmZ5;
        }
        goto zR5Au;
        TQhLU:
        throw new \Exception('Failed to set file permissions for stored image: ' . $euWMh);
        goto eakNr;
        KUS8i:
        $this->HO2X0->deleteDirectory($p5V30);
        goto GM8HO;
        zR5Au:
        throw new Gv0aptVkeUozb('Local chunk can not merge file (can create file): ' . $vc80w);
        goto uQKF5;
        wvenx:
        touch($vc80w);
        goto GwksK;
        fIGZg:
        $fM8fX = $this->HO2X0->files($p5V30);
        goto I5PXH;
        EbzSz:
        if (chmod($euWMh, 0644)) {
            goto fvUtw;
        }
        goto pWSiE;
        bp7I0:
        $this->HO2X0->makeDirectory($Adve_);
        goto xt3ep;
        Fe06G:
        $h0F7E = $this->gMoIS->mpti44yUWjH();
        goto pz2U6;
        xt3ep:
        wcovP:
        goto adBdT;
        crKJN:
        $HDr30 = $this->gMoIS->getFile()->getLocation();
        goto fIGZg;
        uQKF5:
        DrmZ5:
        goto tet12;
        tet12:
        foreach ($fM8fX as $NRs6v) {
            goto OlCl4;
            NKbeS:
            s9yNc:
            goto WxcR6;
            Ql872:
            fclose($Q8Xg_);
            goto GTz6x;
            rX7jm:
            if (!(false === $Q8Xg_)) {
                goto g1XwE;
            }
            goto urgDq;
            mOxC4:
            throw new Gv0aptVkeUozb('A chunk file content can not copy: ' . $xYZ2y);
            goto NKbeS;
            WxcR6:
            cL5ba:
            goto RorRZ;
            IoeD4:
            $BD3sS = stream_copy_to_stream($Q8Xg_, $KAhBS);
            goto Ql872;
            urgDq:
            throw new Gv0aptVkeUozb('A chunk file not existed: ' . $xYZ2y);
            goto Hh06V;
            Hh06V:
            g1XwE:
            goto IoeD4;
            OlCl4:
            $xYZ2y = $this->HO2X0->path($NRs6v);
            goto VcOYu;
            GTz6x:
            if (!(false === $BD3sS)) {
                goto s9yNc;
            }
            goto mOxC4;
            VcOYu:
            $Q8Xg_ = @fopen($xYZ2y, 'rb');
            goto rX7jm;
            RorRZ:
        }
        goto ZuXMD;
        sE1GM:
        $Adve_ = dirname($HDr30);
        goto F05C7;
        GM8HO:
    }
}
