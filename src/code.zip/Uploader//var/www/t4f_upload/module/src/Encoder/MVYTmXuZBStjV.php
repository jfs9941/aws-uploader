<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class MVYTmXuZBStjV
{
    private $HIARr;
    private $A0j2D;
    private $uWTRW;
    private $sO9bz;
    private $m7CD0;
    private $STPtl;
    private $Sn2qs;
    public function __construct(MediaConvertClient $pgVS2, $hDIVL, $jsQkI)
    {
        goto RfqSL;
        L5WOG:
        $this->m7CD0 = $hDIVL;
        goto oiTL_;
        RfqSL:
        $this->sO9bz = $pgVS2;
        goto L5WOG;
        oiTL_:
        $this->STPtl = $jsQkI;
        goto Wg0Yg;
        Wg0Yg:
    }
    public function mrTcjhq3Y1X() : MediaConvertClient
    {
        return $this->sO9bz;
    }
    public function mTnKmAP5Wlj(WPzRjIwEs52zf $mqo01) : self
    {
        $this->HIARr = $mqo01;
        return $this;
    }
    public function md9w6feguxo(string $gzv5N) : self
    {
        $this->uWTRW = $gzv5N;
        return $this;
    }
    public function mqq5NQEdzFA(MjNIYZYcN90xN $x3CP_) : self
    {
        $this->A0j2D[] = $x3CP_;
        return $this;
    }
    public function m7RZ4pLYc6E(Zct70JWnrBlBs $Pt753) : self
    {
        $this->Sn2qs = $Pt753;
        return $this;
    }
    private function mnAVHbOe1qo(bool $Jlf9l) : array
    {
        goto Qcc72;
        DUixt:
        $this->Sn2qs = null;
        goto ETs7z;
        uVfpP:
        $MEfPv['Outputs'] = [];
        goto VlWRC;
        vhc2W:
        if (!$Jlf9l) {
            goto kFjJT;
        }
        goto Aij1V;
        nvP71:
        return $T6iIy;
        goto KJMmw;
        KuhPa:
        $MEfPv = $T6iIy['Settings']['OutputGroups'][0];
        goto JuJsC;
        Aij1V:
        $T6iIy['AccelerationSettings']['Mode'] = 'ENABLED';
        goto qB6K7;
        kaLXu:
        $T6iIy['Queue'] = $this->STPtl;
        goto qXWcd;
        qPZBK:
        $T6iIy['Settings']['OutputGroups'][] = $this->Sn2qs->mIVzhhvnl0S();
        goto OWNyP;
        Qcc72:
        $T6iIy = (require 'template.php');
        goto RUwm5;
        qB6K7:
        kFjJT:
        goto DUixt;
        PiMv9:
        $T6iIy['Settings']['Inputs'] = $this->HIARr->mMCpXLSPjVT();
        goto KuhPa;
        OmUqw:
        if (!$this->Sn2qs) {
            goto J3Ujc;
        }
        goto qPZBK;
        JuJsC:
        unset($T6iIy['Settings']['OutputGroups']);
        goto uVfpP;
        OWNyP:
        J3Ujc:
        goto vhc2W;
        VlWRC:
        foreach ($this->A0j2D as $x3CP_) {
            $MEfPv['Outputs'][] = $x3CP_->mZhszsrRiYi();
            T54Y8:
        }
        goto cBaIP;
        ETs7z:
        $this->HIARr = null;
        goto QpPUU;
        qXWcd:
        if ($this->HIARr) {
            goto XgYPR;
        }
        goto VaFUK;
        VaFUK:
        throw new \LogicException('You must provide a input file to use');
        goto YZzKU;
        RUwm5:
        $T6iIy['Role'] = $this->m7CD0;
        goto kaLXu;
        NoVr0:
        $MEfPv['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->uWTRW;
        goto nHyom;
        nHyom:
        $T6iIy['Settings']['OutputGroups'][] = $MEfPv;
        goto OmUqw;
        QpPUU:
        $this->A0j2D = [];
        goto nvP71;
        cBaIP:
        GWcER:
        goto NoVr0;
        YZzKU:
        XgYPR:
        goto PiMv9;
        KJMmw:
    }
    public function mwQnTjtsW3i(bool $Jlf9l = false) : string
    {
        try {
            $d8Dwe = $this->sO9bz->createJob($this->mnAVHbOe1qo($Jlf9l));
            return $d8Dwe->get('Jobs')['Id'];
        } catch (AwsException $iCEwa) {
            Log::error('Error creating MediaConvert job: ' . $iCEwa->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $iCEwa);
        }
    }
}
