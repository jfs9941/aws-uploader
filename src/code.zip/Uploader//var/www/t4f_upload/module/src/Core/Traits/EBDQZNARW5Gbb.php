<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

trait EBDQZNARW5Gbb
{
    public function getFilename() : string
    {
        return $this->getAttribute('id');
    }
    public function getExtension() : string
    {
        return $this->getAttribute('type');
    }
    public function getLocation() : string
    {
        return $this->getAttribute('filename');
    }
    public function initLocation(string $slOTW)
    {
        $this->filename = $slOTW;
        return $this;
    }
    public function mY9sGcgKRNv($yarYL) : self
    {
        $this->setAttribute('driver', $yarYL);
        return $this;
    }
}
