<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
final class EI5IEB78IIoX0 implements Iyn6qvHr19YOK
{
    public function mRTY2e8fhE7(TkBEwah2ZcKXB $uY0L7) : string
    {
        return "v2/videos/{$uY0L7->getFileName()}.{$uY0L7->getExtension()}";
    }
    public function mTJiARnNt46(TkBEwah2ZcKXB $uY0L7)
    {
        return $uY0L7 instanceof S1qX7zy4Guf94;
    }
}
