<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Contracts\YcQilzjlu6PxW;
use Jfs\Uploader\Core\Traits\EBDQZNARW5Gbb;
use Jfs\Uploader\Core\Traits\XoQcBZc9LWj3k;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Service\JHcQzV9ciJhlf;
class ZrqFFxIRVAAEU extends VWfw9VfxzTDgS implements WMocRbcHaGWZG
{
    use EBDQZNARW5Gbb;
    use XoQcBZc9LWj3k;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $NPlHa, string $VPgya) : self
    {
        goto ujRlM;
        PGHEC:
        $LjRVY->mcDZhVNLw37(YGB86F7VDD6Xo::UPLOADING);
        goto IPzOi;
        IPzOi:
        return $LjRVY;
        goto Pjd7G;
        ujRlM:
        $LjRVY = new self(['id' => $NPlHa, 'type' => $VPgya, 'status' => YGB86F7VDD6Xo::UPLOADING]);
        goto PGHEC;
        Pjd7G:
    }
    public function getView() : array
    {
        $Tz6aF = app(YcQilzjlu6PxW::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $Tz6aF->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Tz6aF->resolveThumbnail($this)];
    }
    public static function mmskxNngb8G(VWfw9VfxzTDgS $iiESX) : ZrqFFxIRVAAEU
    {
        goto X9xtU;
        X9xtU:
        if (!$iiESX instanceof ZrqFFxIRVAAEU) {
            goto aPM8W;
        }
        goto ogyIY;
        ogyIY:
        return $iiESX;
        goto KdsFg;
        KdsFg:
        aPM8W:
        goto HBh1O;
        HBh1O:
        return (new ZrqFFxIRVAAEU())->fill($iiESX->getAttributes());
        goto R3yDz;
        R3yDz:
    }
}
