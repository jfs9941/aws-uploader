<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Aws\Exception\AwsException;
use Aws\S3\S3Client;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
class AN99zqQNCS4Av implements StoreVideoToS3JobInterface
{
    private $ct84z;
    private $j_caY;
    private $NBa8l;
    public function __construct($VxiVW, $nFXer, $J2eOE)
    {
        goto IHx8q;
        r3fgZ:
        $this->ct84z = $VxiVW;
        goto JSfo3;
        IHx8q:
        $this->j_caY = $nFXer;
        goto f7uEJ;
        f7uEJ:
        $this->NBa8l = $J2eOE;
        goto r3fgZ;
        JSfo3:
    }
    public function store(string $W0vWP) : void
    {
        goto Rv63Y;
        y5O6D:
        $J2eOE = $this->NBa8l;
        goto iYGG_;
        Rv63Y:
        Log::info('Storing video (local) to S3', ['fileId' => $W0vWP, 'bucketName' => $this->ct84z]);
        goto X4331;
        Ubh_m:
        $ZCkBl = memory_get_usage();
        goto rzNsC;
        eGqdy:
        jcuW9:
        goto gqDhG;
        gE0vD:
        $l0Zz6 = 1024 * 1024 * 50;
        goto Z4v5Y;
        iYGG_:
        $dn1L3 = S1qX7zy4Guf94::find($W0vWP);
        goto QnMyo;
        yk52f:
        Log::error("[AN99zqQNCS4Av] File not found, discard it ", ['video' => $dn1L3->getLocation()]);
        goto iNX07;
        sqw35:
        $NfAS3 = microtime(true);
        goto Ubh_m;
        CEnGB:
        try {
            goto I1f_1;
            Aai9o:
            $BQorC = $Yx96r->uploadPart(['Bucket' => $this->ct84z, 'Key' => $dn1L3->getLocation(), 'UploadId' => $o0U9i, 'PartNumber' => $P0Zww, 'Body' => fread($IkPEI, $l0Zz6)]);
            goto fNcvQ;
            YoBsT:
            $P0Zww = 1;
            goto kinuu;
            ofu6J:
            goxic:
            goto XD174;
            kinuu:
            $AXziK = [];
            goto ofu6J;
            pmBhB:
            $o0U9i = $d8Dwe['UploadId'];
            goto YoBsT;
            I1f_1:
            $d8Dwe = $Yx96r->createMultipartUpload(['Bucket' => $this->ct84z, 'Key' => $dn1L3->getLocation(), 'ContentType' => $mwVDA, 'ContentDisposition' => 'inline']);
            goto pmBhB;
            fNcvQ:
            $AXziK[] = ['PartNumber' => $P0Zww, 'ETag' => $BQorC['ETag']];
            goto xMNzh;
            uuhBe:
            uX1DD:
            goto SSUfd;
            XD174:
            if (feof($IkPEI)) {
                goto uX1DD;
            }
            goto Aai9o;
            j5lH1:
            $Yx96r->completeMultipartUpload(['Bucket' => $this->ct84z, 'Key' => $dn1L3->getLocation(), 'UploadId' => $o0U9i, 'MultipartUpload' => ['Parts' => $AXziK]]);
            goto cU8Z0;
            cU8Z0:
            $dn1L3->update(['driver' => ARsVGbfyHQlSz::S3, 'status' => OHa83BAIlECUz::FINISHED]);
            goto Amytc;
            SSUfd:
            fclose($IkPEI);
            goto j5lH1;
            bqFT9:
            goto goxic;
            goto uuhBe;
            Amytc:
            $J2eOE->delete($dn1L3->getLocation());
            goto Da5OH;
            xMNzh:
            $P0Zww++;
            goto bqFT9;
            Da5OH:
        } catch (AwsException $MHhGr) {
            goto ueYI9;
            ZaSYH:
            try {
                $Yx96r->abortMultipartUpload(['Bucket' => $this->ct84z, 'Key' => $dn1L3->getLocation(), 'UploadId' => $o0U9i]);
            } catch (AwsException $HibdM) {
                Log::error('Error aborting multipart upload: ' . $HibdM->getMessage());
            }
            goto XISdH;
            n4DX2:
            Log::error('Failed to store video: ' . $dn1L3->getLocation() . ' - ' . $MHhGr->getMessage());
            goto Fbs96;
            XISdH:
            xHYEA:
            goto n4DX2;
            ueYI9:
            if (!isset($o0U9i)) {
                goto xHYEA;
            }
            goto ZaSYH;
            Fbs96:
        } finally {
            $dTAkd = microtime(true);
            $odgxX = memory_get_usage();
            $th8uR = memory_get_peak_usage();
            Log::info('Store S1qX7zy4Guf94 to S3 function resource usage', ['imageId' => $W0vWP, 'execution_time_sec' => $dTAkd - $NfAS3, 'memory_usage_mb' => ($odgxX - $ZCkBl) / 1024 / 1024, 'peak_memory_usage_mb' => ($th8uR - $nrOlC) / 1024 / 1024]);
        }
        goto v2a2r;
        JEieI:
        $Yx96r = $this->j_caY->getClient();
        goto y5O6D;
        iNX07:
        return;
        goto eGqdy;
        rzNsC:
        $nrOlC = memory_get_peak_usage();
        goto CEnGB;
        hrIRg:
        if ($J2eOE->exists($dn1L3->getLocation())) {
            goto jcuW9;
        }
        goto yk52f;
        gqDhG:
        $IkPEI = $J2eOE->readStream($dn1L3->getLocation());
        goto gE0vD;
        QnMyo:
        if ($dn1L3) {
            goto D9zuk;
        }
        goto csi9s;
        MUDzZ:
        return;
        goto XxaR6;
        X4331:
        ini_set('memory_limit', '-1');
        goto JEieI;
        XxaR6:
        D9zuk:
        goto hrIRg;
        csi9s:
        Log::info("S1qX7zy4Guf94 has been deleted, discard it", ['fileId' => $W0vWP]);
        goto MUDzZ;
        Z4v5Y:
        $mwVDA = $J2eOE->mimeType($dn1L3->getLocation());
        goto sqw35;
        v2a2r:
    }
}
