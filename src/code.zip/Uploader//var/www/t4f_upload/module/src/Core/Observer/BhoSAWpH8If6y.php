<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Contracts\DMLDNHSs7xy9p;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Enum\IoCBJqqLig917;
class BhoSAWpH8If6y implements DMLDNHSs7xy9p
{
    private $k4fCM;
    public function __construct($m42Ed)
    {
        $this->k4fCM = $m42Ed;
    }
    public function mCp9vS69WVh($WHuV2, $nQCGg)
    {
        goto rl8OD;
        kD_dE:
        $this->k4fCM->mZJDINqUefY(IoCBJqqLig917::PROCESSING);
        goto QpyxH;
        U5ltf:
        $this->k4fCM->status = IoCBJqqLig917::UPLOADED;
        goto MVGaC;
        Memms:
        $this->k4fCM->delete();
        goto csmu7;
        JeAKb:
        if (!(IoCBJqqLig917::DELETED === $nQCGg && $this->k4fCM->msEWhiJwgQ9())) {
            goto Fr7b7;
        }
        goto Memms;
        Mdqgz:
        fHHwV:
        goto JeAKb;
        rl8OD:
        if (!(IoCBJqqLig917::UPLOADED === $nQCGg)) {
            goto fHHwV;
        }
        goto U5ltf;
        bux0O:
        $this->k4fCM->save();
        goto Mdqgz;
        csmu7:
        Fr7b7:
        goto F5tL2;
        MVGaC:
        if (!$this->k4fCM instanceof Yi7VDaCr23YjR) {
            goto aqtUO;
        }
        goto kD_dE;
        QpyxH:
        aqtUO:
        goto bux0O;
        F5tL2:
    }
}
