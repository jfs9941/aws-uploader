<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
interface YcQilzjlu6PxW
{
    public function resolvePath($esNyq, int $yarYL = BHGv9oAB1EERw::S3);
    public function resolveThumbnail(VWfw9VfxzTDgS $esNyq);
    public function resolvePathForHlsVideo(UZrSkD9d5TXs1 $KdniT, bool $cbmeZ = false);
    public function resolvePathForHlsVideos();
}
