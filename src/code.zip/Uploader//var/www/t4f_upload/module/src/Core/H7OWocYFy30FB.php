<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Core\Observer\DqpOIvjsOit2Q;
use Jfs\Uploader\Core\Traits\C4pYqesyjz4Qh;
use Jfs\Uploader\Core\Traits\XoQcBZc9LWj3k;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Exception\K5L2YJTJAchO8;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Jfs\Uploader\Exception\Mg06hAHKyE4EZ;
use Jfs\Uploader\Service\Havd45fq438gW;
final class H7OWocYFy30FB implements WMocRbcHaGWZG
{
    use C4pYqesyjz4Qh;
    use XoQcBZc9LWj3k;
    private $TZY35;
    private function __construct($PW_5C, $skn0D)
    {
        $this->sMj2E = $PW_5C;
        $this->mDoD9 = $skn0D;
    }
    private function mncVQRoDCjn(string $XhEIi, $skn0D, $YS7_M, bool $Ouqon = false) : void
    {
        $this->m383gIl5NHE(new DqpOIvjsOit2Q($this, $skn0D, $YS7_M, $XhEIi, $Ouqon));
    }
    public function getFile()
    {
        return $this->sMj2E;
    }
    public function msorfj1OM9E(array $MryVr) : void
    {
        $this->TZY35 = $MryVr;
    }
    public function myldP0Gqg0k() : void
    {
        $this->mdqb7va7pQ1(YGB86F7VDD6Xo::UPLOADING);
    }
    public function mcornw0X72M() : void
    {
        $this->mdqb7va7pQ1(YGB86F7VDD6Xo::UPLOADED);
    }
    public function m7Zxxcrsx6k() : void
    {
        $this->mdqb7va7pQ1(YGB86F7VDD6Xo::PROCESSING);
    }
    public function mKRsZJhWJtw() : void
    {
        $this->mdqb7va7pQ1(YGB86F7VDD6Xo::FINISHED);
    }
    public function mN0zImHtW79() : void
    {
        $this->mdqb7va7pQ1(YGB86F7VDD6Xo::ABORTED);
    }
    public function mRprE1AmkFe() : array
    {
        return $this->TZY35;
    }
    public static function mkh8EAtAe7X(string $G2Ngo, $gfNuR, $dR_xe, $XhEIi) : self
    {
        goto N_cJp;
        lNHLo:
        $cvaaS = new self($PW_5C, $gfNuR);
        goto uUzec;
        vJVgI:
        $cvaaS->mcDZhVNLw37(YGB86F7VDD6Xo::UPLOADING);
        goto hc09A;
        uUzec:
        $cvaaS->mncVQRoDCjn($XhEIi, $gfNuR, $dR_xe);
        goto vJVgI;
        hc09A:
        return $cvaaS->mbKUECQBo9A();
        goto jLfqR;
        N_cJp:
        $PW_5C = App::make(Havd45fq438gW::class)->moulPsxrnkx(FutyevYt174lN::mUYRC1czCXw($G2Ngo));
        goto lNHLo;
        jLfqR:
    }
    public static function mN0VLS8cESc($PW_5C, $skn0D, $YS7_M, $XhEIi, $Ouqon = false) : self
    {
        goto DpG2M;
        DpG2M:
        $cvaaS = new self($PW_5C, $skn0D);
        goto webrV;
        j0cDt:
        $cvaaS->mcDZhVNLw37(YGB86F7VDD6Xo::UPLOADING);
        goto kybNx;
        kybNx:
        return $cvaaS;
        goto VvIGH;
        webrV:
        $cvaaS->mncVQRoDCjn($XhEIi, $skn0D, $YS7_M, $Ouqon);
        goto j0cDt;
        VvIGH:
    }
}
