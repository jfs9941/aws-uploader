<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class HTLe1IA3Xgret implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $G2Ngo) : void
    {
        goto zv4If;
        zv4If:
        $KdniT = UZrSkD9d5TXs1::findOrFail($G2Ngo);
        goto N2hnP;
        E926q:
        $this->mfhAvbVzZ6l($KdniT);
        goto NHGby;
        NHGby:
        nEy1Q:
        goto Hv8i9;
        N2hnP:
        if ($KdniT->width() > 0 && $KdniT->height() > 0) {
            goto nEy1Q;
        }
        goto E926q;
        Hv8i9:
    }
    private function mfhAvbVzZ6l(UZrSkD9d5TXs1 $onOto) : void
    {
        goto ZUmZq;
        ZUmZq:
        $vKG6G = $onOto->getView();
        goto eM_z9;
        JKidN:
        $gNgZt = $eh3NZ->getDimensions();
        goto lN23i;
        lN23i:
        $onOto->update(['duration' => $esNyq->getDurationInSeconds(), 'resolution' => $gNgZt->getWidth() . 'x' . $gNgZt->getHeight(), 'fps' => $eh3NZ->get('r_frame_rate') ?? 30]);
        goto RDD7f;
        eM_z9:
        $esNyq = FFMpeg::fromDisk($vKG6G['path'])->open($onOto->getAttribute('filename'));
        goto gz5pG;
        gz5pG:
        $eh3NZ = $esNyq->getVideoStream();
        goto JKidN;
        RDD7f:
    }
}
