<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class DuIqygVrnYyD6
{
    private $aC81i;
    public function __construct(string $dqyyO, ?int $DMzDj, ?int $T7AAY, float $rxW1Y)
    {
        goto H7Vhi;
        bWCsk:
        if (!($DMzDj && $T7AAY)) {
            goto eM3j4;
        }
        goto q1mrB;
        H7Vhi:
        $CQ7Ew = 15000000;
        goto DtYee;
        DtYee:
        if (!($DMzDj && $T7AAY)) {
            goto dkvvs;
        }
        goto q3X9k;
        WPWKt:
        eM3j4:
        goto hpnYZ;
        M2MSl:
        $this->aC81i = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $CQ7Ew, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $dqyyO];
        goto bWCsk;
        q1mrB:
        $this->aC81i['VideoDescription']['Width'] = $DMzDj;
        goto zbLGN;
        zbLGN:
        $this->aC81i['VideoDescription']['Height'] = $T7AAY;
        goto WPWKt;
        q3X9k:
        $CQ7Ew = $this->mdehSQzuJbh($DMzDj, $T7AAY, $rxW1Y);
        goto Vi5yK;
        Vi5yK:
        dkvvs:
        goto M2MSl;
        hpnYZ:
    }
    public function m7kSdoKORhp(N18WZfZRjQqFL $aSxGT) : self
    {
        $this->aC81i['VideoDescription']['VideoPreprocessors'] = $aSxGT->m4RO3zaJjfm();
        return $this;
    }
    public function mHdn1PLh1Wl() : array
    {
        return $this->aC81i;
    }
    private function mdehSQzuJbh(int $DMzDj, int $T7AAY, float $QuA3K, string $urFrz = 'medium', string $egF50 = 'h264', string $A7Zsq = 'good') : ?int
    {
        goto oSmN2;
        ISN37:
        if ($COZst <= 2560 * 1440) {
            goto jgGbl;
        }
        goto wPB0p;
        kCG8g:
        goto usgIX;
        goto hvBBF;
        zyhxj:
        $INGwJ = 7;
        goto i15Vh;
        oSmN2:
        $COZst = $DMzDj * $T7AAY;
        goto jh4yj;
        qtrDT:
        V4BdI:
        goto rQJFv;
        YocXP:
        goto usgIX;
        goto KWaIT;
        zYa0E:
        $INGwJ = 3;
        goto YocXP;
        a6r8x:
        switch (strtolower($A7Zsq)) {
            case 'low':
                $gNU3j *= 0.8;
                goto V4BdI;
            case 'high':
                $gNU3j *= 1.2;
                goto V4BdI;
        }
        goto PDRgr;
        C3xvu:
        $gNU3j *= 0.65;
        goto LuRGV;
        eYRKG:
        nb_Nk:
        goto Pe5ZQ;
        DUeZd:
        ZKWjd:
        goto GtIWi;
        wPB0p:
        if ($COZst <= 3840 * 2160) {
            goto R0xQP;
        }
        goto R3uj2;
        Tl3an:
        goto usgIX;
        goto eYRKG;
        LcFwC:
        jYndy:
        goto zYa0E;
        PDRgr:
        bpndl:
        goto qtrDT;
        HJ8Qr:
        $gNU3j = $INGwJ * ($QuA3K / 30);
        goto EAsA7;
        i15Vh:
        goto usgIX;
        goto oRfK6;
        U2eeL:
        return (int) ($gNU3j * 1000 * 1000);
        goto hEp8n;
        R3uj2:
        $INGwJ = 30;
        goto Tl3an;
        rQJFv:
        $gNU3j = max(0.5, $gNU3j);
        goto U2eeL;
        TIp6N:
        goto usgIX;
        goto LcFwC;
        LuRGV:
        ygzUg:
        goto a6r8x;
        G5ojy:
        if ($COZst <= 1920 * 1080) {
            goto siaBU;
        }
        goto ISN37;
        KWaIT:
        siaBU:
        goto zyhxj;
        oRfK6:
        jgGbl:
        goto deihz;
        Ml5AR:
        if ($COZst <= 1280 * 720) {
            goto jYndy;
        }
        goto G5ojy;
        m53bb:
        if (!('h265' === strtolower($egF50) || 'hevc' === strtolower($egF50) || 'vp9' === strtolower($egF50))) {
            goto ygzUg;
        }
        goto C3xvu;
        APzzu:
        $INGwJ = 20;
        goto rz7Dn;
        jh4yj:
        if ($COZst <= 640 * 480) {
            goto nb_Nk;
        }
        goto Ml5AR;
        hvBBF:
        R0xQP:
        goto APzzu;
        rz7Dn:
        usgIX:
        goto HJ8Qr;
        deihz:
        $INGwJ = 12;
        goto kCG8g;
        GtIWi:
        k1WHs:
        goto m53bb;
        EAsA7:
        switch (strtolower($urFrz)) {
            case 'low':
                $gNU3j *= 0.7;
                goto k1WHs;
            case 'high':
                $gNU3j *= 1.3;
                goto k1WHs;
            case 'veryhigh':
                $gNU3j *= 1.6;
                goto k1WHs;
        }
        goto DUeZd;
        Pe5ZQ:
        $INGwJ = 1.5;
        goto TIp6N;
        hEp8n:
    }
}
