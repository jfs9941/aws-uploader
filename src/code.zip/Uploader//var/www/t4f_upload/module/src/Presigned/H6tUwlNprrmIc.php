<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Wzdcw9ZdKJxDa;
use Jfs\Uploader\Exception\ECJBTm7ayuLMp;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class H6tUwlNprrmIc implements LDes0oWAHPyua
{
    private static $np57P = 'chunks/';
    private $i3lQr;
    private $JZDCA;
    private $BBjq4;
    public function __construct(Wzdcw9ZdKJxDa $wxGNA, Filesystem $WPRCg, Filesystem $XdRPm)
    {
        goto sFf_r;
        d9X8K:
        $this->JZDCA = $WPRCg;
        goto my5z7;
        sFf_r:
        $this->i3lQr = $wxGNA;
        goto d9X8K;
        my5z7:
        $this->BBjq4 = $XdRPm;
        goto juGHT;
        juGHT:
    }
    public function mWCsuh0MINY() : void
    {
        goto IY6mo;
        ur1Vj:
        $this->JZDCA->put($this->i3lQr->mwP3lO68q7v(), json_encode($this->i3lQr->mhr9LcPnRdj()->toArray()));
        goto KvxT3;
        IY6mo:
        $eiM1z = $this->i3lQr->mhr9LcPnRdj();
        goto NH8nf;
        b3fiU:
        ++$p9FUM;
        goto kTNUJ;
        rQ1g8:
        bVirp:
        goto b3fiU;
        y3mNm:
        QGl2j:
        goto IXoho;
        cqyyW:
        $this->i3lQr->mhr9LcPnRdj()->mCgnkilkBQI($o0U9i);
        goto ur1Vj;
        IXoho:
        if (!($p9FUM <= $wtjf6)) {
            goto R_EwT;
        }
        goto a01mZ;
        a01mZ:
        $Lrr_X[] = ['index' => $p9FUM, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $o0U9i, 'index' => $p9FUM])];
        goto rQ1g8;
        xG_KU:
        $wtjf6 = ceil($eiM1z->I_Ajk / $eiM1z->ePSQ2);
        goto DDBBL;
        DDBBL:
        $o0U9i = Uuid::v4()->toHex();
        goto LU1sM;
        IAeVI:
        R_EwT:
        goto F0lk4;
        F0lk4:
        $this->i3lQr->mJhZVlPGxoU($Lrr_X);
        goto cqyyW;
        KvxT3:
        $this->BBjq4->put($this->i3lQr->mwP3lO68q7v(), json_encode($this->i3lQr->mhr9LcPnRdj()->toArray()));
        goto ps7KE;
        kTNUJ:
        goto QGl2j;
        goto IAeVI;
        NH8nf:
        $Lrr_X = [];
        goto xG_KU;
        LU1sM:
        $this->i3lQr->mhr9LcPnRdj()->mCgnkilkBQI($o0U9i);
        goto d3Epy;
        d3Epy:
        $p9FUM = 1;
        goto y3mNm;
        ps7KE:
    }
    public function mwPLyydlbvG() : void
    {
        goto QIrwc;
        yrdaj:
        $this->JZDCA->deleteDirectory(self::$np57P . $o0U9i);
        goto cqeh4;
        QIrwc:
        $eiM1z = $this->i3lQr->mhr9LcPnRdj();
        goto I6L0o;
        I6L0o:
        $o0U9i = $eiM1z->RbFi9;
        goto yrdaj;
        cqeh4:
        $this->BBjq4->delete($this->i3lQr->mwP3lO68q7v());
        goto mx5_o;
        mx5_o:
    }
    public function mdnRCqLYYn2() : void
    {
        goto GkwuG;
        oq82i:
        TrzES:
        goto UBsZD;
        JxRGG:
        Assert::eq(count($Ykzan), $wtjf6, 'The number of parts and checksums must match.');
        goto zx2ay;
        uLzva:
        throw new \Exception('Failed to set file permissions for stored image: ' . $s7UAV);
        goto FfEzm;
        Ht1UJ:
        fclose($OsLLJ);
        goto bGOax;
        Xhf2O:
        $this->JZDCA->deleteDirectory($bbsUP);
        goto PfOsA;
        RzYdF:
        if ($this->JZDCA->exists($oH8lZ)) {
            goto rXqYi;
        }
        goto rJWYM;
        GP3ps:
        if (!(false === $OsLLJ)) {
            goto TrzES;
        }
        goto wAcX8;
        GkwuG:
        $eiM1z = $this->i3lQr->mhr9LcPnRdj();
        goto d5vTK;
        jKmkD:
        touch($XtlFo);
        goto vGkZo;
        KCG0_:
        $XtlFo = $this->JZDCA->path($RZbeS);
        goto jKmkD;
        FfEzm:
        QdS3v:
        goto Xhf2O;
        UBsZD:
        foreach ($Ykzan as $E0wez) {
            goto LznhM;
            cWBDD:
            throw new ECJBTm7ayuLMp('A chunk file content can not copy: ' . $QYl3J);
            goto Jc9k_;
            r1qyo:
            fclose($E5_2x);
            goto bLojU;
            LznhM:
            $QYl3J = $this->JZDCA->path($E0wez);
            goto gJCzs;
            bLojU:
            if (!(false === $e09Kk)) {
                goto Aodra;
            }
            goto cWBDD;
            Vy7dE:
            if (!(false === $E5_2x)) {
                goto lYC2j;
            }
            goto P5q98;
            QH7IM:
            D5emW:
            goto MabAM;
            Mhr8g:
            lYC2j:
            goto DsZKJ;
            P5q98:
            throw new ECJBTm7ayuLMp('A chunk file not existed: ' . $QYl3J);
            goto Mhr8g;
            Jc9k_:
            Aodra:
            goto QH7IM;
            gJCzs:
            $E5_2x = @fopen($QYl3J, 'rb');
            goto Vy7dE;
            DsZKJ:
            $e09Kk = stream_copy_to_stream($E5_2x, $OsLLJ);
            goto r1qyo;
            MabAM:
        }
        goto qJOzB;
        d5vTK:
        $wtjf6 = $eiM1z->z9NJt;
        goto t8G2a;
        vGkZo:
        $OsLLJ = @fopen($XtlFo, 'wb');
        goto GP3ps;
        t8G2a:
        $bbsUP = self::$np57P . $eiM1z->RbFi9;
        goto i2JJE;
        XGsyM:
        $Ykzan = $this->JZDCA->files($bbsUP);
        goto JxRGG;
        bGOax:
        $s7UAV = $this->JZDCA->path($RZbeS);
        goto Zo5jW;
        xm1xd:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $s7UAV);
        goto uLzva;
        GMZrK:
        rXqYi:
        goto KCG0_;
        Zo5jW:
        if (chmod($s7UAV, 0644)) {
            goto QdS3v;
        }
        goto xm1xd;
        i2JJE:
        $RZbeS = $this->i3lQr->getFile()->getLocation();
        goto XGsyM;
        xJRSE:
        $oH8lZ = dirname($RZbeS);
        goto RzYdF;
        rJWYM:
        $this->JZDCA->makeDirectory($oH8lZ);
        goto GMZrK;
        wAcX8:
        throw new ECJBTm7ayuLMp('Local chunk can not merge file (can create file): ' . $XtlFo);
        goto oq82i;
        qJOzB:
        Q7uoO:
        goto Ht1UJ;
        zx2ay:
        natsort($Ykzan);
        goto xJRSE;
        PfOsA:
    }
}
