<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
class KBvlJjrPu3JyV implements BlurJobInterface
{
    const mXS9Z = 15;
    const POx3B = 500;
    const kdaR_ = 500;
    private $LPCI1;
    private $j_caY;
    private $NBa8l;
    public function __construct($VzMzb, $nFXer, $J2eOE)
    {
        goto wlv1q;
        PJHnr:
        $this->j_caY = $nFXer;
        goto nPjBy;
        nPjBy:
        $this->LPCI1 = $VzMzb;
        goto gN7aw;
        wlv1q:
        $this->NBa8l = $J2eOE;
        goto PJHnr;
        gN7aw:
    }
    public function blur(string $W0vWP) : void
    {
        goto PLt1B;
        CSehy:
        unset($qj00p);
        goto TP3uY;
        TP3uY:
        if (chmod($Yqb0Z, 0664)) {
            goto e33zK;
        }
        goto ALVCv;
        Ie_po:
        $Mtf3A = $this->m7fMCesQdpv($T3joe);
        goto QeW2S;
        ALVCv:
        \Log::warning('Failed to set final permissions on image file: ' . $Yqb0Z);
        goto Q6ppO;
        QSo0G:
        $T3joe->update(['preview' => $Mtf3A]);
        goto MM8rr;
        Nn5Nt:
        if (!($T3joe->WNE_L == ARsVGbfyHQlSz::S3 && !$this->NBa8l->exists($T3joe->filename))) {
            goto lc7ar;
        }
        goto dG4lg;
        fTRez:
        $qj00p->blur(self::mXS9Z);
        goto Ie_po;
        Sf2Ag:
        $this->NBa8l->put($T3joe->filename, $pkekc);
        goto lc6NI;
        h4nS0:
        ini_set('memory_limit', '-1');
        goto Nn5Nt;
        Q6ppO:
        throw new \Exception('Failed to set final permissions on image file: ' . $Yqb0Z);
        goto HRNhF;
        PLt1B:
        $T3joe = Il0T1UmENcpfh::findOrFail($W0vWP);
        goto h4nS0;
        I9JKG:
        $qj00p = $this->LPCI1->call($this, $this->NBa8l->path($T3joe->getLocation()));
        goto nPkXn;
        lc6NI:
        lc7ar:
        goto I9JKG;
        U8_Je:
        $qj00p->save($Yqb0Z);
        goto CSehy;
        QeW2S:
        $Yqb0Z = $this->NBa8l->path($Mtf3A);
        goto U8_Je;
        dG4lg:
        $pkekc = $this->j_caY->get($T3joe->filename);
        goto Sf2Ag;
        nPkXn:
        $rOwJo = $qj00p->width() / $qj00p->height();
        goto hC0RT;
        HRNhF:
        e33zK:
        goto QSo0G;
        hC0RT:
        $qj00p->resize(self::POx3B, self::kdaR_ / $rOwJo);
        goto fTRez;
        MM8rr:
    }
    private function m7fMCesQdpv($w2pZ1) : string
    {
        goto e5dVd;
        eTlgj:
        $this->NBa8l->makeDirectory($wmLPG, 0755, true);
        goto Ul7ev;
        Hu63N:
        $wmLPG = dirname($Iros8) . '/preview/';
        goto MbP2C;
        e5dVd:
        $Iros8 = $w2pZ1->getLocation();
        goto Hu63N;
        dbRxD:
        return $wmLPG . $w2pZ1->getFilename() . '.jpg';
        goto oSDne;
        MbP2C:
        if ($this->NBa8l->exists($wmLPG)) {
            goto cdkqW;
        }
        goto eTlgj;
        Ul7ev:
        cdkqW:
        goto dbRxD;
        oSDne:
    }
}
