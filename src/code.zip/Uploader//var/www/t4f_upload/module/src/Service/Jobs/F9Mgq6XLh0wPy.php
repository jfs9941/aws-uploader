<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
class F9Mgq6XLh0wPy implements GenerateThumbnailJobInterface
{
    const POx3B = 150;
    const kdaR_ = 150;
    private $LPCI1;
    private $NBa8l;
    public function __construct($VzMzb, $J2eOE)
    {
        $this->LPCI1 = $VzMzb;
        $this->NBa8l = $J2eOE;
    }
    public function generate(string $W0vWP)
    {
        goto AH786;
        AH786:
        Log::info("Generating thumbnail", ['imageId' => $W0vWP]);
        goto Tcxae;
        Tcxae:
        ini_set('memory_limit', '-1');
        goto e9uuT;
        e9uuT:
        try {
            goto N0wo0;
            lBBZ2:
            Log::warning('Failed to set file permissions for stored image: ' . $s7UAV);
            goto Y7vYT;
            HnaE_:
            if (chmod($s7UAV, 0644)) {
                goto IsRJG;
            }
            goto lBBZ2;
            SRJl2:
            if (!($ptog3 !== false)) {
                goto P9lLY;
            }
            goto D8nHG;
            bdCSJ:
            IsRJG:
            goto mFqbI;
            aCt8h:
            $Iros8 = $this->m7fMCesQdpv($qj00p);
            goto JJvbS;
            Y7vYT:
            throw new \Exception('Failed to set file permissions for stored image: ' . $s7UAV);
            goto bdCSJ;
            N0wo0:
            $WPRCg = $this->NBa8l;
            goto OMBvc;
            JJvbS:
            $ptog3 = $WPRCg->put($Iros8, $f1cNF, ['visibility' => 'public']);
            goto aYuTL;
            OMBvc:
            $qj00p = Il0T1UmENcpfh::findOrFail($W0vWP);
            goto kFimO;
            shThM:
            $s7UAV = $WPRCg->path($Iros8);
            goto HnaE_;
            qM_4Z:
            $f1cNF = $f1cNF->orient()->resize(150, 150);
            goto aCt8h;
            kFimO:
            $f1cNF = $this->LPCI1->call($this, $WPRCg->path($qj00p->getLocation()));
            goto qM_4Z;
            mFqbI:
            P9lLY:
            goto s120C;
            aYuTL:
            unset($f1cNF);
            goto SRJl2;
            D8nHG:
            $qj00p->update(['thumbnail' => $Iros8, 'status' => OHa83BAIlECUz::THUMBNAIL_PROCESSED]);
            goto shThM;
            s120C:
        } catch (ModelNotFoundException $MHhGr) {
            Log::info("Il0T1UmENcpfh has been deleted, discard it", ['imageId' => $W0vWP]);
            return;
        }
        goto vo0yZ;
        vo0yZ:
    }
    private function m7fMCesQdpv(TWXq4PCBxnKLl $qj00p) : string
    {
        goto SHmsZ;
        afjEX:
        $qUGBu = $wmLPG . '/' . self::POx3B . 'X' . self::kdaR_;
        goto Hmjx4;
        Hmjx4:
        return $qUGBu . '/' . $qj00p->getFilename() . '.jpg';
        goto vb59m;
        Y7t3E:
        $wmLPG = dirname($Iros8);
        goto afjEX;
        SHmsZ:
        $Iros8 = $qj00p->getLocation();
        goto Y7t3E;
        vb59m:
    }
}
