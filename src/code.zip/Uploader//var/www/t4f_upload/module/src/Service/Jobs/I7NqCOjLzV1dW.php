<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
class I7NqCOjLzV1dW implements BlurJobInterface
{
    const nghoA = 15;
    const K6RHg = 500;
    const r36cV = 500;
    private $eE5H8;
    private $bwFb2;
    private $k4mhD;
    public function __construct($LCatz, $dR_xe, $ixEuN)
    {
        goto N5AuQ;
        N5AuQ:
        $this->k4mhD = $ixEuN;
        goto Hl13J;
        Hl13J:
        $this->bwFb2 = $dR_xe;
        goto X3fIG;
        X3fIG:
        $this->eE5H8 = $LCatz;
        goto xVQ6Q;
        xVQ6Q:
    }
    public function blur(string $G2Ngo) : void
    {
        goto se7Ln;
        UOXJw:
        $LjRVY->save($F1HbZ);
        goto CVEZ2;
        zjjIK:
        $LjRVY->blur(self::nghoA);
        goto RAtsc;
        U6abU:
        if (chmod($F1HbZ, 0664)) {
            goto y3dzg;
        }
        goto CCh_x;
        w6FFQ:
        $PzjGK = $this->bwFb2->get($zw5Jg->filename);
        goto sITD0;
        UmzWQ:
        $LjRVY->resize(self::K6RHg, self::r36cV / $HiRXD);
        goto zjjIK;
        hwXgI:
        throw new \Exception('Failed to set final permissions on image file: ' . $F1HbZ);
        goto vwZJl;
        ijTgu:
        $F1HbZ = $this->k4mhD->path($t0jU5);
        goto UOXJw;
        ufKB5:
        if (!($zw5Jg->jWhvV == BHGv9oAB1EERw::S3 && !$this->k4mhD->exists($zw5Jg->filename))) {
            goto tke1n;
        }
        goto w6FFQ;
        rvzoP:
        ini_set('memory_limit', '-1');
        goto ufKB5;
        zfxQo:
        tke1n:
        goto ZkJad;
        jxyqt:
        $zw5Jg->update(['preview' => $t0jU5]);
        goto zI7Rn;
        RAtsc:
        $t0jU5 = $this->mgToDiXc5QE($zw5Jg);
        goto ijTgu;
        CVEZ2:
        unset($LjRVY);
        goto U6abU;
        iPptR:
        $HiRXD = $LjRVY->width() / $LjRVY->height();
        goto UmzWQ;
        ZkJad:
        $LjRVY = $this->eE5H8->call($this, $this->k4mhD->path($zw5Jg->getLocation()));
        goto iPptR;
        CCh_x:
        \Log::warning('Failed to set final permissions on image file: ' . $F1HbZ);
        goto hwXgI;
        vwZJl:
        y3dzg:
        goto jxyqt;
        sITD0:
        $this->k4mhD->put($zw5Jg->filename, $PzjGK);
        goto zfxQo;
        se7Ln:
        $zw5Jg = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
        goto rvzoP;
        zI7Rn:
    }
    private function mgToDiXc5QE($yfl0I) : string
    {
        goto OJzFC;
        fv_3W:
        $oYMhx = dirname($BkP1c) . '/preview/';
        goto wJsAV;
        G9AYx:
        return $oYMhx . $yfl0I->getFilename() . '.jpg';
        goto lmkPm;
        l78oc:
        $this->k4mhD->makeDirectory($oYMhx, 0755, true);
        goto YEHko;
        OJzFC:
        $BkP1c = $yfl0I->getLocation();
        goto fv_3W;
        wJsAV:
        if ($this->k4mhD->exists($oYMhx)) {
            goto BRXqW;
        }
        goto l78oc;
        YEHko:
        BRXqW:
        goto G9AYx;
        lmkPm:
    }
}
