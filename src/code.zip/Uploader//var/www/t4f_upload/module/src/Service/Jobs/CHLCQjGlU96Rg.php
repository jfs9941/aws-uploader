<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class CHLCQjGlU96Rg
{
    private $NOVxu;
    private $WORGE;
    public function __construct(int $HcOPT, int $lI1AK)
    {
        goto JU2gU;
        TBGgw:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto n2eof;
        n2eof:
        WbzZ6:
        goto wRKFg;
        dskMg:
        ZYzy4:
        goto mf7a6;
        wRKFg:
        $this->NOVxu = $HcOPT;
        goto nkpBV;
        qZ2TB:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto dskMg;
        JU2gU:
        if (!($HcOPT <= 0)) {
            goto ZYzy4;
        }
        goto qZ2TB;
        nkpBV:
        $this->WORGE = $lI1AK;
        goto mxpCj;
        mf7a6:
        if (!($lI1AK <= 0)) {
            goto WbzZ6;
        }
        goto TBGgw;
        mxpCj:
    }
    private static function mCl7ZMCu4lV($BIP4y, string $FI605 = 'floor') : int
    {
        goto PppTn;
        vWxRp:
        switch (strtolower($FI605)) {
            case 'ceil':
                return (int) (ceil($BIP4y / 2) * 2);
            case 'round':
                return (int) (round($BIP4y / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($BIP4y / 2) * 2);
        }
        goto wz1m9;
        jY36U:
        return $BIP4y;
        goto Kkq6G;
        ZGFoE:
        cL0JV:
        goto P1Ezl;
        wz1m9:
        xSZ05:
        goto ZGFoE;
        zxUUv:
        return (int) $BIP4y;
        goto BKkcZ;
        AgP_J:
        if (!(is_float($BIP4y) && $BIP4y == floor($BIP4y) && (int) $BIP4y % 2 === 0)) {
            goto Kk6S1;
        }
        goto zxUUv;
        PppTn:
        if (!(is_int($BIP4y) && $BIP4y % 2 === 0)) {
            goto IvME4;
        }
        goto jY36U;
        BKkcZ:
        Kk6S1:
        goto vWxRp;
        Kkq6G:
        IvME4:
        goto AgP_J;
        P1Ezl:
    }
    public function meEOCmaBy4M(string $SDQyz = 'floor') : array
    {
        goto iaVNM;
        ugssY:
        $j1CEw = $YWtYZ / $this->WORGE;
        goto evOWz;
        XSvJi:
        $YWtYZ = self::mCl7ZMCu4lV(round($Y001u), $SDQyz);
        goto kyHhk;
        xzJev:
        HCqeQ:
        goto mWJgL;
        AgEsZ:
        $KYmJ4 = 0;
        goto fJgav;
        Ahv25:
        $KYmJ4 = 2;
        goto v4zkF;
        RgK2D:
        $KYmJ4 = $aNcmE;
        goto a2bF6;
        qYhb7:
        $KYmJ4 = self::mCl7ZMCu4lV(round($tK8dZ), $SDQyz);
        goto xzJev;
        Png4e:
        uCoYE:
        goto LVCke;
        iaVNM:
        $aNcmE = 1080;
        goto AgEsZ;
        v4zkF:
        qE9Y4:
        goto DH2bk;
        mWJgL:
        if (!($KYmJ4 < 2)) {
            goto qE9Y4;
        }
        goto Ahv25;
        DcNWH:
        $Y001u = $this->WORGE * $j1CEw;
        goto XSvJi;
        evOWz:
        $tK8dZ = $this->NOVxu * $j1CEw;
        goto qYhb7;
        kyHhk:
        goto HCqeQ;
        goto oB7pJ;
        LVCke:
        return ['width' => $KYmJ4, 'height' => $YWtYZ];
        goto A5Vr7;
        fJgav:
        $YWtYZ = 0;
        goto AYbw8;
        NlXE6:
        $YWtYZ = $aNcmE;
        goto ugssY;
        zoDZH:
        $YWtYZ = 2;
        goto Png4e;
        oB7pJ:
        dTZUD:
        goto NlXE6;
        a2bF6:
        $j1CEw = $KYmJ4 / $this->NOVxu;
        goto DcNWH;
        AYbw8:
        if ($this->NOVxu >= $this->WORGE) {
            goto dTZUD;
        }
        goto RgK2D;
        DH2bk:
        if (!($YWtYZ < 2)) {
            goto uCoYE;
        }
        goto zoDZH;
        A5Vr7:
    }
}
