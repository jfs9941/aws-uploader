<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
final class TOAxIaYJeahur implements FsqkSkkGdgriL
{
    public function mBEFI4EGLt7(J2nNudRqcfTj1 $PW_5C) : string
    {
        return "v2/videos/{$PW_5C->getFileName()}.{$PW_5C->getExtension()}";
    }
    public function mTiUdGKTI9s(J2nNudRqcfTj1 $PW_5C)
    {
        return $PW_5C instanceof UZrSkD9d5TXs1;
    }
}
