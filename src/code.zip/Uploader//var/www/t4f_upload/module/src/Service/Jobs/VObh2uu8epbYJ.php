<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
class VObh2uu8epbYJ implements DownloadToLocalJobInterface
{
    private $zl2D8;
    private $IXK4e;
    public function __construct($VVGKi, $ZfrI6)
    {
        $this->zl2D8 = $VVGKi;
        $this->IXK4e = $ZfrI6;
    }
    public function download(string $C3gWL) : void
    {
        goto rEZ9o;
        zGs6b:
        gRWo0:
        goto WcLCG;
        WcLCG:
        $this->IXK4e->put($m42Ed->getLocation(), $this->zl2D8->get($m42Ed->getLocation()));
        goto B_kRf;
        pYDNE:
        if (!$this->IXK4e->exists($m42Ed->getLocation())) {
            goto gRWo0;
        }
        goto lMGeX;
        lMGeX:
        return;
        goto zGs6b;
        lo9Xv:
        Log::info("Start download file to local", ['fileId' => $C3gWL, 'filename' => $m42Ed->getLocation()]);
        goto pYDNE;
        rEZ9o:
        $m42Ed = Yi7VDaCr23YjR::findOrFail($C3gWL);
        goto lo9Xv;
        B_kRf:
    }
}
