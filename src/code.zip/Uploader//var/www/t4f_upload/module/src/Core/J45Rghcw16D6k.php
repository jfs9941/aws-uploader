<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Contracts\YcQilzjlu6PxW;
use Jfs\Uploader\Core\Traits\EBDQZNARW5Gbb;
use Jfs\Uploader\Core\Traits\XoQcBZc9LWj3k;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Service\JHcQzV9ciJhlf;
class J45Rghcw16D6k extends VWfw9VfxzTDgS implements WMocRbcHaGWZG
{
    use EBDQZNARW5Gbb;
    use XoQcBZc9LWj3k;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $NPlHa, string $VPgya) : self
    {
        goto Iualv;
        bLw0v:
        return $ZETpd;
        goto pOfLU;
        hfPzQ:
        $ZETpd->mcDZhVNLw37(YGB86F7VDD6Xo::UPLOADING);
        goto bLw0v;
        Iualv:
        $ZETpd = new self(['id' => $NPlHa, 'type' => $VPgya, 'status' => YGB86F7VDD6Xo::UPLOADING]);
        goto hfPzQ;
        pOfLU:
    }
    public function getView() : array
    {
        $Tz6aF = app(YcQilzjlu6PxW::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $Tz6aF->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Tz6aF->resolveThumbnail($this)];
    }
    public static function mxay1Yy042P(VWfw9VfxzTDgS $iiESX) : J45Rghcw16D6k
    {
        goto hdQrx;
        hdQrx:
        if (!$iiESX instanceof J45Rghcw16D6k) {
            goto pYd2N;
        }
        goto Y8a6i;
        Y8a6i:
        return $iiESX;
        goto IJyMu;
        MHZlD:
        return (new J45Rghcw16D6k())->fill($iiESX->getAttributes());
        goto wLIgC;
        IJyMu:
        pYd2N:
        goto MHZlD;
        wLIgC:
    }
}
