<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Contracts\SZm1UTyVUjPKK;
use Jfs\Uploader\Core\Traits\YzdWeu2LiemYK;
use Jfs\Uploader\Core\Traits\PNxZ9iFoUyPar;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Service\TTmP5DEq3oRIl;
class FKnhGBzmViN0k extends TWXq4PCBxnKLl implements PwKw6a6OizPW3
{
    use YzdWeu2LiemYK;
    use PNxZ9iFoUyPar;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $mRgNN, string $PavIR) : self
    {
        goto U5CE0;
        U5CE0:
        $ympmf = new self(['id' => $mRgNN, 'type' => $PavIR, 'status' => OHa83BAIlECUz::UPLOADING]);
        goto hjxoh;
        wNT3L:
        return $ympmf;
        goto Z1myk;
        hjxoh:
        $ympmf->m7j1OyKKnp8(OHa83BAIlECUz::UPLOADING);
        goto wNT3L;
        Z1myk:
    }
    public function getView() : array
    {
        $R0E9F = app(SZm1UTyVUjPKK::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $R0E9F->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $R0E9F->resolveThumbnail($this)];
    }
    public static function mj4mPciZrS9(TWXq4PCBxnKLl $HRuZr) : FKnhGBzmViN0k
    {
        goto a9zSO;
        UXBPo:
        return (new FKnhGBzmViN0k())->fill($HRuZr->getAttributes());
        goto Ryp3g;
        BjOLK:
        mfi5m:
        goto UXBPo;
        NJlX_:
        return $HRuZr;
        goto BjOLK;
        a9zSO:
        if (!$HRuZr instanceof FKnhGBzmViN0k) {
            goto mfi5m;
        }
        goto NJlX_;
        Ryp3g:
    }
}
