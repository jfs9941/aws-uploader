<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
class GvRzttjEZkkTh implements WatermarkTextJobInterface
{
    private $LPCI1;
    private $knb6E;
    private $vtuC3;
    private $j_caY;
    private $JZDCA;
    public function __construct($VzMzb, $HgWMY, $nFXer, $WPRCg, $BA6_T)
    {
        goto wtE99;
        wtE99:
        $this->LPCI1 = $VzMzb;
        goto lPe1c;
        wHOSa:
        $this->JZDCA = $WPRCg;
        goto zhdE_;
        zhdE_:
        $this->vtuC3 = $BA6_T;
        goto JF6cx;
        JF6cx:
        $this->knb6E = $HgWMY;
        goto RTAyF;
        lPe1c:
        $this->j_caY = $nFXer;
        goto wHOSa;
        RTAyF:
    }
    public function putWatermark(string $W0vWP, string $TP3pR) : void
    {
        goto G8nKa;
        G8nKa:
        $NfAS3 = microtime(true);
        goto KUUoi;
        bR_Nf:
        $nrOlC = memory_get_peak_usage();
        goto svkUT;
        A2K1m:
        try {
            goto xqILM;
            X2EPK:
            $XMcRK = $this->LPCI1->call($this, $Iros8);
            goto mA7eU;
            fOTcp:
            Log::error("Il0T1UmENcpfh is not on local, might be deleted before put watermark", ['imageId' => $W0vWP]);
            goto Q1otr;
            QkUNa:
            mcZJT:
            goto aTLbQ;
            mA7eU:
            $XMcRK->orient();
            goto rNjv3;
            rNjv3:
            $this->m6jqS7K8yAq($XMcRK, $TP3pR);
            goto S72Av;
            bZk_e:
            \Log::warning('Failed to set final permissions on image file: ' . $Iros8);
            goto bk5W_;
            bk5W_:
            throw new \Exception('Failed to set final permissions on image file: ' . $Iros8);
            goto lLyRN;
            xqILM:
            $qj00p = Il0T1UmENcpfh::findOrFail($W0vWP);
            goto YGcE3;
            ZF56J:
            if (chmod($Iros8, 0664)) {
                goto fkKev;
            }
            goto bZk_e;
            lLyRN:
            fkKev:
            goto IxaJI;
            aTLbQ:
            $Iros8 = $this->JZDCA->path($qj00p->getLocation());
            goto X2EPK;
            S72Av:
            $XMcRK->save($Iros8);
            goto kCsjS;
            kCsjS:
            unset($XMcRK);
            goto ZF56J;
            YGcE3:
            if ($this->JZDCA->exists($qj00p->getLocation())) {
                goto mcZJT;
            }
            goto fOTcp;
            Q1otr:
            return;
            goto QkUNa;
            IxaJI:
        } catch (\Throwable $jW9s3) {
            goto DpUZ0;
            Tx2Rt:
            mM1Vu:
            goto lFF49;
            TFdx_:
            Log::info("Il0T1UmENcpfh has been deleted, discard it", ['imageId' => $W0vWP]);
            goto wvh8d;
            lFF49:
            Log::error("Il0T1UmENcpfh is not readable", ['imageId' => $W0vWP, 'error' => $jW9s3->getMessage()]);
            goto qCMTK;
            wvh8d:
            return;
            goto Tx2Rt;
            DpUZ0:
            if (!$jW9s3 instanceof ModelNotFoundException) {
                goto mM1Vu;
            }
            goto TFdx_;
            qCMTK:
        } finally {
            $dTAkd = microtime(true);
            $odgxX = memory_get_usage();
            $th8uR = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $W0vWP, 'execution_time_sec' => $dTAkd - $NfAS3, 'memory_usage_mb' => ($odgxX - $ZCkBl) / 1024 / 1024, 'peak_memory_usage_mb' => ($th8uR - $nrOlC) / 1024 / 1024]);
        }
        goto ltrx8;
        svkUT:
        Log::info("Adding watermark text to image", ['imageId' => $W0vWP]);
        goto W22lw;
        W22lw:
        ini_set('memory_limit', '-1');
        goto A2K1m;
        KUUoi:
        $ZCkBl = memory_get_usage();
        goto bR_Nf;
        ltrx8:
    }
    private function m6jqS7K8yAq($XMcRK, $TP3pR) : void
    {
        goto S6UBn;
        iRk8_:
        $mTZoR = $this->LPCI1->call($this, $this->JZDCA->path($pi9zI));
        goto rRf2s;
        coC6P:
        $w53IY = new GM5l1IAjwnfng($this->knb6E, $this->vtuC3, $this->j_caY, $this->JZDCA);
        goto wReV4;
        ZXPqG:
        $this->JZDCA->put($pi9zI, $this->j_caY->get($pi9zI));
        goto iRk8_;
        jEY5F:
        $tIdzi = $XMcRK->height();
        goto coC6P;
        S6UBn:
        $bOYNe = $XMcRK->width();
        goto jEY5F;
        wReV4:
        $pi9zI = $w53IY->mzmK96qCqJ0($bOYNe, $tIdzi, $TP3pR, true);
        goto ZXPqG;
        rRf2s:
        $XMcRK->place($mTZoR, 'top-left', 0, 0, 30);
        goto qifb_;
        qifb_:
    }
}
