<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\H7OWocYFy30FB;
use Jfs\Uploader\Exception\K6wfiXH2axnXx;
use Jfs\Uploader\Exception\Gv0aptVkeUozb;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Jfs\Uploader\Exception\S3WgBj4LGorAN;
use Webmozart\Assert\Assert;
class EfBaTjOz0p26r implements TBTGazsaTHh1M
{
    private $gMoIS;
    private $HO2X0;
    private $Q3Qp4;
    private $qNgj8;
    public function __construct(H7OWocYFy30FB $EljXk, Filesystem $skn0D, Filesystem $YS7_M, string $XhEIi)
    {
        goto JolK3;
        zd5uG:
        $this->qNgj8 = $XhEIi;
        goto r4y2X;
        jTVyr:
        $this->HO2X0 = $skn0D;
        goto Iom5w;
        JolK3:
        $this->gMoIS = $EljXk;
        goto jTVyr;
        Iom5w:
        $this->Q3Qp4 = $YS7_M;
        goto zd5uG;
        r4y2X:
    }
    public function m0BpXIBYPaJ()
    {
        goto gMolz;
        lK6og:
        if (!($Sc5jc <= $jxa1X)) {
            goto tvvkv;
        }
        goto j6mgu;
        k9Y5q:
        $bbcnG[] = ['index' => $Sc5jc, 'url' => (string) $cvaaS->getUri()];
        goto zFOlH;
        Ek9D3:
        goto H8lwF;
        goto YIo6c;
        TdV7M:
        $this->Q3Qp4->put($this->gMoIS->mNRyYDQLTdL(), json_encode($this->gMoIS->mpti44yUWjH()->toArray()));
        goto HmX0F;
        YIo6c:
        tvvkv:
        goto XmJ1M;
        tEhHi:
        H8lwF:
        goto lK6og;
        QWfy_:
        $x53s1 = $TrPq0->createMultipartUpload(['Bucket' => $this->qNgj8, 'Key' => $this->gMoIS->getFile()->getLocation(), 'ContentType' => $this->gMoIS->mpti44yUWjH()->lEUBo, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto c2FWH;
        EOtqP:
        throw new S3WgBj4LGorAN("Failed to create multipart upload for file {$this->gMoIS->getFile()->getFilename()}, S3 return empty response");
        goto nZQqM;
        eTr9r:
        ++$Sc5jc;
        goto Ek9D3;
        gMolz:
        $h0F7E = $this->gMoIS->mpti44yUWjH();
        goto lcYpG;
        wUYnX:
        $cvaaS = $TrPq0->createPresignedRequest($bFv3Q, '+1 day');
        goto k9Y5q;
        j6mgu:
        $bFv3Q = $TrPq0->getCommand('UploadPart', ['Bucket' => $this->qNgj8, 'Key' => $this->gMoIS->getFile()->getLocation(), 'UploadId' => $x53s1['UploadId'], 'PartNumber' => $Sc5jc]);
        goto wUYnX;
        dFSe5:
        $this->HO2X0->put($this->gMoIS->mNRyYDQLTdL(), json_encode($this->gMoIS->mpti44yUWjH()->toArray()));
        goto TdV7M;
        zFOlH:
        Dul53:
        goto eTr9r;
        nZQqM:
        gYJyn:
        goto KlAW4;
        fEPqz:
        $this->gMoIS->mpti44yUWjH()->mX4syai7ACI($x53s1['UploadId']);
        goto dFSe5;
        lcYpG:
        $bbcnG = [];
        goto E43xU;
        c2FWH:
        if (!(0 === $x53s1->count())) {
            goto gYJyn;
        }
        goto EOtqP;
        KlAW4:
        $Sc5jc = 1;
        goto tEhHi;
        F3Nfg:
        $TrPq0 = $this->Q3Qp4->getClient();
        goto QWfy_;
        E43xU:
        $jxa1X = ceil($h0F7E->O380t / $h0F7E->kZCFD);
        goto F3Nfg;
        XmJ1M:
        $this->gMoIS->msorfj1OM9E($bbcnG);
        goto fEPqz;
        HmX0F:
    }
    public function mR8nrUJhhp7() : void
    {
        goto zljxn;
        zljxn:
        $TrPq0 = $this->Q3Qp4->getClient();
        goto ybL2t;
        ybL2t:
        try {
            $TrPq0->abortMultipartUpload(['Bucket' => $this->qNgj8, 'Key' => $this->gMoIS->getFile()->getLocation(), 'UploadId' => $this->gMoIS->mpti44yUWjH()->mxcVx]);
        } catch (\Throwable $uEMU5) {
            throw new K6wfiXH2axnXx("Failed to abort multipart upload of file {$this->gMoIS->getFile()->getFilename()}", 0, $uEMU5);
        }
        goto HbLf1;
        HbLf1:
        $this->HO2X0->delete($this->gMoIS->mNRyYDQLTdL());
        goto Dzha3;
        Dzha3:
        $this->Q3Qp4->delete($this->gMoIS->mNRyYDQLTdL());
        goto bYQpV;
        bYQpV:
    }
    public function mAYMPMrjwD6() : void
    {
        goto cSODY;
        gp9ft:
        Assert::eq(count($haCEo), count($i51wU), 'The number of parts and checksums must match.');
        goto Raxzh;
        cSODY:
        $h0F7E = $this->gMoIS->mpti44yUWjH();
        goto wYicc;
        HFemq:
        $i51wU = $h0F7E->x3RSN;
        goto gp9ft;
        b4L6m:
        a2AXz:
        goto F_YgC;
        IuvFA:
        foreach ($i51wU as $yDNi6) {
            goto cEmOd;
            I_it8:
            if (!($RrfcB['eTag'] !== $yDNi6['eTag'])) {
                goto DMXlC;
            }
            goto s_khE;
            ICM6E:
            $RrfcB = $HJ00Z[$qYEuO];
            goto I_it8;
            s_khE:
            throw new Gv0aptVkeUozb("Checksum mismatch for part {$qYEuO} of file {$this->gMoIS->getFile()->getFilename()}");
            goto ab2tF;
            ab2tF:
            DMXlC:
            goto cuvbf;
            cEmOd:
            $qYEuO = $yDNi6['partNumber'];
            goto ICM6E;
            cuvbf:
            SlQnq:
            goto coBzD;
            coBzD:
        }
        goto b4L6m;
        Raxzh:
        $HJ00Z = collect($haCEo)->keyBy('partNumber');
        goto IuvFA;
        wYicc:
        $haCEo = $h0F7E->xAv8B;
        goto HFemq;
        F_YgC:
        $TrPq0 = $this->Q3Qp4->getClient();
        goto nFXQP;
        nFXQP:
        try {
            $TrPq0->completeMultipartUpload(['Bucket' => $this->qNgj8, 'Key' => $this->gMoIS->getFile()->getLocation(), 'UploadId' => $this->gMoIS->mpti44yUWjH()->mxcVx, 'MultipartUpload' => ['Parts' => collect($this->gMoIS->mpti44yUWjH()->xAv8B)->sortBy('partNumber')->map(fn($RrfcB) => ['ETag' => $RrfcB['eTag'], 'PartNumber' => $RrfcB['partNumber']])->toArray()]]);
        } catch (\Throwable $uEMU5) {
            throw new Gv0aptVkeUozb("Failed to merge chunks of file {$this->gMoIS->getFile()->getFilename()}", 0, $uEMU5);
        }
        goto yGG0f;
        yGG0f:
    }
}
