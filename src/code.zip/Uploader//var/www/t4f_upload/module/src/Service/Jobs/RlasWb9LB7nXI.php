<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
class RlasWb9LB7nXI implements StoreToS3JobInterface
{
    private $LPCI1;
    private $j_caY;
    private $NBa8l;
    public function __construct($VzMzb, $nFXer, $J2eOE)
    {
        goto ytB7D;
        ytB7D:
        $this->j_caY = $nFXer;
        goto RPLbr;
        RPLbr:
        $this->NBa8l = $J2eOE;
        goto eAKph;
        eAKph:
        $this->LPCI1 = $VzMzb;
        goto NpcES;
        NpcES:
    }
    public function store(string $W0vWP) : void
    {
        goto Uog2k;
        cTcYC:
        if (!$T3joe->update(['driver' => ARsVGbfyHQlSz::S3, 'status' => OHa83BAIlECUz::FINISHED])) {
            goto roGEG;
        }
        goto RfLHz;
        zNlXR:
        $this->j_caY->put($T3joe->getAttribute('preview'), $jGG9m, ['visibility' => 'public', 'ContentType' => $jGG9m->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto Cv30A;
        mMLWk:
        $jGG9m = $this->LPCI1->call($this, $Mtf3A);
        goto zNlXR;
        H00Ra:
        if (!($EqiK4 && $this->NBa8l->exists($EqiK4))) {
            goto Y_Zr3;
        }
        goto LEfXg;
        NE18q:
        $this->m3Db1P7i37K($Iros8, $T3joe->getLocation(), '.webp');
        goto Q56rh;
        PgOGm:
        if ($T3joe) {
            goto ufKHy;
        }
        goto gepX3;
        ILYo6:
        Y_Zr3:
        goto czseF;
        Q56rh:
        $EqiK4 = $T3joe->getAttribute('thumbnail');
        goto H00Ra;
        uMDd8:
        $this->j_caY->put($T3joe->getAttribute('thumbnail'), $Pt753, ['visibility' => 'public', 'ContentType' => $Pt753->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        goto ILYo6;
        zTCf0:
        return;
        goto PtleN;
        OF4wO:
        Il0T1UmENcpfh::where('parent_id', $W0vWP)->update(['driver' => ARsVGbfyHQlSz::S3, 'preview' => $T3joe->getAttribute('preview'), 'thumbnail' => $T3joe->getAttribute('thumbnail'), 'webp_path' => $T3joe->getAttribute('webp_path')]);
        goto zTCf0;
        wfHdk:
        $Iros8 = $this->NBa8l->path($T3joe->getLocation());
        goto wmFPe;
        RfLHz:
        Log::info("Il0T1UmENcpfh stored to S3, update the children attachments", ['fileId' => $W0vWP]);
        goto OF4wO;
        Cv30A:
        FEZnX:
        goto cTcYC;
        fWQni:
        $Mtf3A = $this->NBa8l->path($T3joe->getAttribute('preview'));
        goto mMLWk;
        YcE2S:
        return;
        goto Vj5I7;
        PtleN:
        roGEG:
        goto jBS4o;
        LEfXg:
        $VSwZe = $this->NBa8l->path($EqiK4);
        goto SMBfO;
        jBS4o:
        Log::error("Failed to update image model after storing to S3", ['fileId' => $W0vWP]);
        goto yhxzf;
        SMBfO:
        $Pt753 = $this->LPCI1->call($this, $VSwZe);
        goto uMDd8;
        gepX3:
        Log::info("Il0T1UmENcpfh has been deleted, discard it", ['fileId' => $W0vWP]);
        goto YcE2S;
        czseF:
        if (!($T3joe->getAttribute('preview') && $this->NBa8l->exists($T3joe->getAttribute('preview')))) {
            goto FEZnX;
        }
        goto fWQni;
        Vj5I7:
        ufKHy:
        goto wfHdk;
        wmFPe:
        $this->m3Db1P7i37K($Iros8, $T3joe->getLocation());
        goto NE18q;
        Uog2k:
        $T3joe = Il0T1UmENcpfh::findOrFail($W0vWP);
        goto PgOGm;
        yhxzf:
    }
    private function m3Db1P7i37K($kfhku, $tKzQh, $j2g49 = '')
    {
        goto bPoMn;
        caq8p:
        $kfhku = str_replace('.jpg', $j2g49, $kfhku);
        goto lbr4P;
        lbr4P:
        $tKzQh = str_replace('.jpg', $j2g49, $tKzQh);
        goto ShJbS;
        Z6BfN:
        try {
            $qj00p = $this->LPCI1->call($this, $kfhku);
            $this->j_caY->put($tKzQh, $qj00p, ['visibility' => 'public', 'ContentType' => $qj00p->origin()->mediaType(), 'ContentDisposition' => 'inline']);
        } catch (\Exception $iCEwa) {
            Log::error("Failed to upload image to S3", ['s3Path' => $tKzQh, 'error' => $iCEwa->getMessage()]);
        }
        goto tMoAH;
        bPoMn:
        if (!$j2g49) {
            goto HQ2l2;
        }
        goto caq8p;
        ShJbS:
        HQ2l2:
        goto Z6BfN;
        tMoAH:
    }
}
