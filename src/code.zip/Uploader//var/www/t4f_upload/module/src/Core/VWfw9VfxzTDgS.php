<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
abstract  class VWfw9VfxzTDgS extends Model implements J2nNudRqcfTj1
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews', 'webp_path'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function mVz7It0sr6N() : bool
    {
        goto xVGp4;
        He6Aj:
        return true;
        goto MDmRJ;
        xVGp4:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto kE2n4;
        }
        goto He6Aj;
        bGISO:
        return !$this->mjRqdNmBJhn();
        goto lQ140;
        MDmRJ:
        kE2n4:
        goto bGISO;
        lQ140:
    }
    protected function mjRqdNmBJhn() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
