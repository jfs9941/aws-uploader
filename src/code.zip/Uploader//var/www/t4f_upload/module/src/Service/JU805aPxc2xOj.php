<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
final class JU805aPxc2xOj implements VideoPostHandleServiceInterface
{
    private $AP4jI;
    private $j_caY;
    public function __construct(UploadServiceInterface $Sop9x, Filesystem $nFXer)
    {
        $this->AP4jI = $Sop9x;
        $this->j_caY = $nFXer;
    }
    public function saveMetadata(string $W0vWP, array $eiM1z)
    {
        goto tyoOu;
        uUDfP:
        try {
            goto GftAz;
            KhFeK:
            $Cpjv5['thumbnail_id'] = $Pt753['id'];
            goto Wx1of;
            Wx1of:
            $Cpjv5['thumbnail'] = $Pt753['filename'];
            goto IKqWT;
            GftAz:
            $Pt753 = $this->AP4jI->storeSingleFile(new class($eiM1z['thumbnail']) implements SingleUploadInterface
            {
                private $d2AB9;
                public function __construct($uY0L7)
                {
                    $this->d2AB9 = $uY0L7;
                }
                public function getFile()
                {
                    return $this->d2AB9;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto KhFeK;
            IKqWT:
        } catch (\Throwable $iCEwa) {
            Log::warning("S1qX7zy4Guf94 thumbnail store failed: " . $iCEwa->getMessage());
        }
        goto ELKje;
        fZEPz:
        $this->AP4jI->updateFile($A37bW->getAttribute('id'), OHa83BAIlECUz::PROCESSING);
        goto QmKUn;
        BC07O:
        if (!(isset($eiM1z['change_status']) && $eiM1z['change_status'])) {
            goto XV0Ja;
        }
        goto fZEPz;
        TBcW3:
        throw new \Exception("S1qX7zy4Guf94 metadata store failed for unknown reason ... " . $W0vWP);
        goto qEYlv;
        lqtWI:
        dVgS8:
        goto tzXaP;
        tzXaP:
        if (!$A37bW->Sn2qs) {
            goto SK6ul;
        }
        goto EzaPq;
        MAG_6:
        xY9Dy:
        goto Y0d1j;
        ELKje:
        Aa466:
        goto qmh0D;
        Y0d1j:
        if (!isset($eiM1z['fps'])) {
            goto dVgS8;
        }
        goto tvScb;
        iWOAF:
        t2Pj4:
        goto rrhqJ;
        rrhqJ:
        Log::warning("S1qX7zy4Guf94 metadata store failed for unknown reason ... " . $W0vWP);
        goto TBcW3;
        boSQR:
        $Cpjv5 = [];
        goto IDGjs;
        IdU3i:
        return $A37bW->getView();
        goto iWOAF;
        cK1fK:
        $Cpjv5['duration'] = $eiM1z['duration'];
        goto IUX6z;
        BkX1A:
        $Cpjv5['resolution'] = $eiM1z['resolution'];
        goto MAG_6;
        IUX6z:
        DLpo2:
        goto FqY3K;
        QmKUn:
        XV0Ja:
        goto IdU3i;
        tvScb:
        $Cpjv5['fps'] = $eiM1z['fps'];
        goto lqtWI;
        FqY3K:
        if (!isset($eiM1z['resolution'])) {
            goto xY9Dy;
        }
        goto BkX1A;
        Vn4wZ:
        if (!$A37bW->update($Cpjv5)) {
            goto t2Pj4;
        }
        goto BC07O;
        EzaPq:
        unset($Cpjv5['thumbnail']);
        goto aGQdI;
        IDGjs:
        if (!isset($eiM1z['thumbnail'])) {
            goto Aa466;
        }
        goto uUDfP;
        tyoOu:
        $A37bW = S1qX7zy4Guf94::findOrFail($W0vWP);
        goto boSQR;
        aGQdI:
        SK6ul:
        goto Vn4wZ;
        qmh0D:
        if (!isset($eiM1z['duration'])) {
            goto DLpo2;
        }
        goto cK1fK;
        qEYlv:
    }
    public function createThumbnail(string $eQxqz) : void
    {
        goto cem4X;
        SIY3Y:
        qpjoW:
        goto eHCtm;
        bkLgY:
        $Ngs7e = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto pFI_o;
        cem4X:
        Log::info("Use Lambda to generate thumbnail for video: " . $eQxqz);
        goto cedoY;
        pFI_o:
        try {
            goto JhpB1;
            g5zIM:
            $Xsopm = $trIU7->get('QueueUrl');
            goto Ncsqj;
            Ncsqj:
            $Ngs7e->sendMessage(['QueueUrl' => $Xsopm, 'MessageBody' => json_encode(['file_path' => $A37bW->getLocation()])]);
            goto ZEu7F;
            JhpB1:
            $trIU7 = $Ngs7e->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto g5zIM;
            ZEu7F:
        } catch (\Throwable $MHhGr) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$MHhGr->getMessage()}");
        }
        goto SIY3Y;
        bjab3:
        $VSwZe = "v2/hls/thumbnails/{$eQxqz}/";
        goto mk3D9;
        mk3D9:
        if (!(!$this->j_caY->directoryExists($VSwZe) && empty($A37bW->mAHS3GrI6kI()))) {
            goto qpjoW;
        }
        goto bkLgY;
        cedoY:
        $A37bW = S1qX7zy4Guf94::findOrFail($eQxqz);
        goto bjab3;
        eHCtm:
    }
    public function mKDyUCha5sY(string $eQxqz) : void
    {
        goto WGvzb;
        biNHt:
        throw new \Exception("Message back with success data but not found thumbnail files " . $eQxqz);
        goto ckZZa;
        WGvzb:
        $A37bW = S1qX7zy4Guf94::findOrFail($eQxqz);
        goto ZGFeR;
        aB4n_:
        Log::error("Message back with success data but not found thumbnail " . $eQxqz);
        goto CkiX_;
        jQRSE:
        if (!(count($efDfT) === 0)) {
            goto R6BjI;
        }
        goto UhXc7;
        ckZZa:
        R6BjI:
        goto XEL01;
        UhXc7:
        Log::error("Message back with success data but not found thumbnail files " . $eQxqz);
        goto biNHt;
        xTtjl:
        if ($this->j_caY->directoryExists($VSwZe)) {
            goto wKUyE;
        }
        goto aB4n_;
        UmXrf:
        wKUyE:
        goto fED1T;
        CkiX_:
        throw new \Exception("Message back with success data but not found thumbnail " . $eQxqz);
        goto UmXrf;
        fED1T:
        $efDfT = $this->j_caY->files($VSwZe);
        goto jQRSE;
        ZGFeR:
        $VSwZe = "v2/hls/thumbnails/{$eQxqz}/";
        goto xTtjl;
        XEL01:
        $A37bW->update(['generated_previews' => $VSwZe]);
        goto VxCmp;
        VxCmp:
    }
    public function getThumbnails(string $eQxqz) : array
    {
        $A37bW = S1qX7zy4Guf94::findOrFail($eQxqz);
        return $A37bW->getThumbnails();
    }
}
