<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Core\RTkNv5GS7FY9w;
final class AdSBYUOvhOwhg implements IyHy3A57jqaFT
{
    public function mF4oZkheU68(Ezj2tYBlqBPt9 $m42Ed) : string
    {
        return "v2/pdfs/{$m42Ed->getFileName()}.{$m42Ed->getExtension()}";
    }
    public function mkexAYAWxp4(Ezj2tYBlqBPt9 $m42Ed)
    {
        return $m42Ed instanceof RTkNv5GS7FY9w;
    }
}
