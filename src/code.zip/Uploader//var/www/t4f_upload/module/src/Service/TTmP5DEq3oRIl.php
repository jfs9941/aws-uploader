<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\SZm1UTyVUjPKK;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Core\FKnhGBzmViN0k;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
final class TTmP5DEq3oRIl implements SZm1UTyVUjPKK
{
    private $rIiZx;
    private $PeFdG;
    public $B0Sdf;
    private $L70kv;
    private $S7EZB;
    private $NBa8l;
    public function __construct($kaz8n, $yPM6C, $vkPj7, $uiQAB, $liHGM, $J2eOE)
    {
        goto Up6xZ;
        ga1fQ:
        $this->B0Sdf = $vkPj7;
        goto zi310;
        pXEmz:
        $this->rIiZx = $kaz8n;
        goto Q0adZ;
        Q0adZ:
        $this->PeFdG = $yPM6C;
        goto ga1fQ;
        zi310:
        $this->L70kv = $uiQAB;
        goto Pv0C4;
        Pv0C4:
        $this->S7EZB = $liHGM;
        goto WSfT4;
        Up6xZ:
        $this->NBa8l = $J2eOE;
        goto pXEmz;
        WSfT4:
    }
    public function resolvePath($pm1yU, $CIuf5 = ARsVGbfyHQlSz::S3) : string
    {
        goto T3PwV;
        KL0of:
        if (!(!empty($this->L70kv) && !empty($this->S7EZB))) {
            goto F3Yiy;
        }
        goto tY3_w;
        T3PwV:
        if (!$pm1yU instanceof TWXq4PCBxnKLl) {
            goto xI43k;
        }
        goto vIgW9;
        ksqzq:
        clHo4:
        goto Xy7td;
        sR3MT:
        return config('upload.home') . '/' . $pm1yU;
        goto flUek;
        tmpyY:
        F3Yiy:
        goto QOojq;
        PRWMb:
        return trim($this->B0Sdf, '/') . '/' . $pm1yU;
        goto ksqzq;
        QOojq:
        if (!$this->rIiZx) {
            goto clHo4;
        }
        goto PRWMb;
        Xy7td:
        return trim($this->PeFdG, '/') . '/' . $pm1yU;
        goto uVJmy;
        tY3_w:
        return $this->mqBB3fXIgIv($pm1yU);
        goto tmpyY;
        JaXhl:
        if (!($CIuf5 === ARsVGbfyHQlSz::LOCAL)) {
            goto V4ryI;
        }
        goto sR3MT;
        vIgW9:
        $pm1yU = $pm1yU->getAttribute('filename');
        goto Eny7q;
        Eny7q:
        xI43k:
        goto JaXhl;
        flUek:
        V4ryI:
        goto KL0of;
        uVJmy:
    }
    public function resolveThumbnail(TWXq4PCBxnKLl $pm1yU) : string
    {
        goto pv9Jt;
        P0Ht3:
        return asset('/img/pdf-preview.svg');
        goto O27xy;
        n_0_F:
        $oQxV1 = Il0T1UmENcpfh::find($pm1yU->getAttribute('thumbnail_id'));
        goto EwmR3;
        M0NQU:
        if (!$Pt753) {
            goto QMnUh;
        }
        goto p3Cpo;
        HS4VD:
        if (!$pm1yU instanceof FKnhGBzmViN0k) {
            goto Zpx0G;
        }
        goto P0Ht3;
        ERzsf:
        QMnUh:
        goto aX0kJ;
        aX0kJ:
        if (!$pm1yU->getAttribute('thumbnail_id')) {
            goto Al8j7;
        }
        goto n_0_F;
        eHNI0:
        return '';
        goto w_3Sf;
        pv9Jt:
        $Pt753 = $pm1yU->getAttribute('thumbnail');
        goto M0NQU;
        EnXO1:
        lHvEp:
        goto Br9HY;
        dRC4i:
        return $this->resolvePath($oQxV1, $oQxV1->getAttribute('driver'));
        goto EnXO1;
        shj9h:
        return $this->resolvePath($pm1yU, $pm1yU->getAttribute('driver'));
        goto S6sxE;
        p3Cpo:
        return $this->url($Pt753, $pm1yU->getAttribute('driver'));
        goto ERzsf;
        O27xy:
        Zpx0G:
        goto eHNI0;
        Br9HY:
        Al8j7:
        goto LSBe_;
        LSBe_:
        if (!$pm1yU instanceof Il0T1UmENcpfh) {
            goto RDl4y;
        }
        goto shj9h;
        S6sxE:
        RDl4y:
        goto HS4VD;
        EwmR3:
        if (!$oQxV1) {
            goto lHvEp;
        }
        goto dRC4i;
        w_3Sf:
    }
    private function url($Iros8, $CIuf5)
    {
        goto zUzWT;
        hCHBj:
        return $this->resolvePath($Iros8);
        goto pyUdN;
        sWn0K:
        dG3NH:
        goto hCHBj;
        zUzWT:
        if (!($CIuf5 == ARsVGbfyHQlSz::LOCAL)) {
            goto dG3NH;
        }
        goto rKdNs;
        rKdNs:
        return config('upload.home') . '/' . $Iros8;
        goto sWn0K;
        pyUdN:
    }
    private function mqBB3fXIgIv($Iros8)
    {
        goto i1nIe;
        D_OjG:
        ywl99:
        goto unojY;
        mOJG3:
        azzX0:
        goto FjBJq;
        FN9mr:
        return $jwuEW->getSignedUrl($this->B0Sdf . '/' . $Iros8, $wvSBX);
        goto lHl1f;
        tcMNP:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto D_OjG;
        leOQS:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto mOJG3;
        V4_w7:
        $jwuEW = new UrlSigner($this->L70kv, $this->NBa8l->path($this->S7EZB));
        goto FN9mr;
        FjBJq:
        if (!(strpos($Iros8, 'm3u8') !== false)) {
            goto ywl99;
        }
        goto tcMNP;
        unojY:
        $wvSBX = now()->addMinutes(60)->timestamp;
        goto V4_w7;
        i1nIe:
        if (!(strpos($Iros8, 'https://') === 0)) {
            goto azzX0;
        }
        goto leOQS;
        lHl1f:
    }
    public function resolvePathForHlsVideo(S1qX7zy4Guf94 $A37bW, $cMMFb = false) : string
    {
        goto iNJ6c;
        Reeuf:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto BES5T;
        iNJ6c:
        if ($A37bW->getAttribute('hls_path')) {
            goto aKYGB;
        }
        goto Reeuf;
        BES5T:
        aKYGB:
        goto TRaHy;
        TRaHy:
        return $this->B0Sdf . '/' . $A37bW->getAttribute('hls_path');
        goto c1hfr;
        c1hfr:
    }
    public function resolvePathForHlsVideos()
    {
        goto cpRNP;
        ngzVR:
        $nfyyp = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto IbnmV;
        zix1v:
        $UgK3o = json_encode(['Statement' => [['Resource' => sprintf('%s*', $uNFw8), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $wvSBX]]]]]);
        goto ngzVR;
        HRlrU:
        return [$lueLW, $wvSBX];
        goto xM4kE;
        cpRNP:
        $wvSBX = now()->addDays(3)->timestamp;
        goto LleIS;
        LleIS:
        $uNFw8 = $this->B0Sdf . '/v2/hls/';
        goto zix1v;
        IbnmV:
        $lueLW = $nfyyp->getSignedCookie(['key_pair_id' => $this->L70kv, 'private_key' => $this->NBa8l->path($this->S7EZB), 'policy' => $UgK3o]);
        goto HRlrU;
        xM4kE:
    }
}
