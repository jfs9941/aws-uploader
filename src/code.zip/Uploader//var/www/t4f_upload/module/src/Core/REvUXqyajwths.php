<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
abstract  class REvUXqyajwths extends Model implements Ezj2tYBlqBPt9
{
    public $incrementing = false;
    protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews', 'webp_path'];
    protected $table = 'attachments';
    protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int'];
    public function msEWhiJwgQ9() : bool
    {
        goto Ascd9;
        hh3aj:
        return !$this->mkmF8c7zver();
        goto bK0Dc;
        Ascd9:
        if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) {
            goto t7ajF;
        }
        goto nQ4wX;
        nQ4wX:
        return true;
        goto EKmDL;
        EKmDL:
        t7ajF:
        goto hh3aj;
        bK0Dc:
    }
    protected function mkmF8c7zver() : bool
    {
        return null === $this->getAttribute('parent_id');
    }
    public abstract function getView() : array;
}
