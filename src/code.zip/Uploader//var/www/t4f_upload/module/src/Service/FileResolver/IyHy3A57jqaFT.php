<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
interface IyHy3A57jqaFT
{
    public function mF4oZkheU68(Ezj2tYBlqBPt9 $m42Ed);
    public function mkexAYAWxp4(Ezj2tYBlqBPt9 $m42Ed);
}
