<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\DcxVJGuKhzqC9;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Exception\K5L2YJTJAchO8;
trait XoQcBZc9LWj3k
{
    private $EUg8M = [];
    public function mcDZhVNLw37($qQ81e)
    {
        goto M0c2H;
        Z_wN3:
        $this->setAttribute('status', $qQ81e);
        goto ipa98;
        nj3rG:
        Hl4kc:
        goto Z_wN3;
        ipa98:
        U1275:
        goto GJ5y3;
        RXYHm:
        goto U1275;
        goto nj3rG;
        JqCpn:
        $this->status = $qQ81e;
        goto RXYHm;
        M0c2H:
        if ($this instanceof Model) {
            goto Hl4kc;
        }
        goto JqCpn;
        GJ5y3:
    }
    public function mxcJpAd2wzt()
    {
        goto IndQ3;
        VnFX8:
        return $this->status;
        goto y5lLN;
        IndQ3:
        if (!$this instanceof Model) {
            goto Xcpgt;
        }
        goto eP_8P;
        eP_8P:
        return $this->getAttribute('status');
        goto MyAGE;
        MyAGE:
        Xcpgt:
        goto VnFX8;
        y5lLN:
    }
    public function mdqb7va7pQ1($Uu5dC)
    {
        goto R6z83;
        nZY6h:
        $this->setAttribute('status', $Uu5dC);
        goto JFYHo;
        FW52o:
        ITURI:
        goto NfoRA;
        R6z83:
        if ($this->mKsdt4jxMYg($Uu5dC)) {
            goto f_Zou;
        }
        goto PoNRn;
        LtGRA:
        if ($this instanceof Model) {
            goto ZYxqL;
        }
        goto cZWXu;
        yXEc1:
        goto iz3d5;
        goto nmwt0;
        y3qrQ:
        $dKChl = $this->mxcJpAd2wzt();
        goto LtGRA;
        casv7:
        foreach ($this->EUg8M as $PH00I) {
            $PH00I->mg4qJ1AespD($dKChl, $Uu5dC);
            NBsq3:
        }
        goto FW52o;
        cZWXu:
        $this->status = $Uu5dC;
        goto yXEc1;
        JFYHo:
        iz3d5:
        goto casv7;
        PoNRn:
        throw K5L2YJTJAchO8::moJWkEGvnSq($this->id ?? 'unknown', $this->mxcJpAd2wzt(), $Uu5dC);
        goto KDL8n;
        nmwt0:
        ZYxqL:
        goto nZY6h;
        KDL8n:
        f_Zou:
        goto y3qrQ;
        NfoRA:
    }
    public function mKsdt4jxMYg($Uu5dC)
    {
        goto LN3Jw;
        Gcw5r:
        NA61r:
        goto PYWDn;
        zlLxj:
        lCq6C:
        goto Gcw5r;
        LN3Jw:
        switch ($this->status) {
            case YGB86F7VDD6Xo::UPLOADING:
                return YGB86F7VDD6Xo::UPLOADED == $Uu5dC || YGB86F7VDD6Xo::UPLOADING == $Uu5dC || YGB86F7VDD6Xo::ABORTED == $Uu5dC;
            case YGB86F7VDD6Xo::UPLOADED:
                return YGB86F7VDD6Xo::PROCESSING == $Uu5dC || YGB86F7VDD6Xo::DELETED == $Uu5dC;
            case YGB86F7VDD6Xo::PROCESSING:
                return in_array($Uu5dC, [YGB86F7VDD6Xo::WATERMARK_PROCESSED, YGB86F7VDD6Xo::THUMBNAIL_PROCESSED, YGB86F7VDD6Xo::ENCODING_PROCESSED, YGB86F7VDD6Xo::ENCODING_ERROR, YGB86F7VDD6Xo::BLUR_PROCESSED, YGB86F7VDD6Xo::DELETED, YGB86F7VDD6Xo::FINISHED, YGB86F7VDD6Xo::PROCESSING]);
            case YGB86F7VDD6Xo::FINISHED:
            case YGB86F7VDD6Xo::ABORTED:
                return YGB86F7VDD6Xo::DELETED == $Uu5dC;
            case YGB86F7VDD6Xo::ENCODING_PROCESSED:
                return YGB86F7VDD6Xo::FINISHED == $Uu5dC || YGB86F7VDD6Xo::DELETED == $Uu5dC;
            default:
                return false;
        }
        goto zlLxj;
        PYWDn:
    }
    public function m383gIl5NHE(DcxVJGuKhzqC9 $PH00I)
    {
        $this->EUg8M[] = $PH00I;
    }
}
