<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Encoder\QcoiOgw1BN3hR;
use Jfs\Uploader\Encoder\DuIqygVrnYyD6;
use Jfs\Uploader\Encoder\DFtX4SxXxkHYz;
use Jfs\Uploader\Encoder\NsrFDXbHHex5r;
use Jfs\Uploader\Encoder\GPKFcaJNi5OaU;
use Jfs\Uploader\Encoder\N18WZfZRjQqFL;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Uploader\Service\I2LnR7hUOOfvy;
use Webmozart\Assert\Assert;
class XP8OPFpw4ZXBL implements MediaEncodeJobInterface
{
    private $qNgj8;
    private $HO2X0;
    private $bwFb2;
    private $iyhKM;
    private $vBgYT;
    public function __construct(string $XhEIi, $skn0D, $dR_xe, $G4OeZ, $lcWBa)
    {
        goto urP6F;
        WkYuh:
        $this->bwFb2 = $dR_xe;
        goto FK9nD;
        urP6F:
        $this->qNgj8 = $XhEIi;
        goto jnz3b;
        k6es3:
        $this->vBgYT = $lcWBa;
        goto uXo_b;
        jnz3b:
        $this->HO2X0 = $skn0D;
        goto WkYuh;
        FK9nD:
        $this->iyhKM = $G4OeZ;
        goto k6es3;
        uXo_b:
    }
    public function encode(string $G2Ngo, string $nlTkR, $aacbt = true) : void
    {
        goto Zz4G0;
        t2iIa:
        ini_set('memory_limit', '-1');
        goto sJnaA;
        sJnaA:
        try {
            goto cgeWG;
            L6VNB:
            UqGbz:
            goto gmE13;
            FHJHJ:
            qPVrZ:
            goto j4X6g;
            zSlzr:
            $Q2vvf = $this->mD4Oz7H5TP3($wrTQA, $h1Fyx->m7FTIyYsGpu((int) $j2was['width'], (int) $j2was['height'], $nlTkR));
            goto xb7ZR;
            kiCI3:
            Log::info("Set input video for Job", ['s3Uri' => $kC5Yx]);
            goto SgLav;
            QpvPP:
            $Q2vvf = $this->mD4Oz7H5TP3($wrTQA, $h1Fyx->m7FTIyYsGpu($KdniT->width(), $KdniT->height(), $nlTkR));
            goto tuBZk;
            JRRTE:
            $PbQYK = app(DFtX4SxXxkHYz::class);
            goto v9V5f;
            bds87:
            $vFqZF->mpM00sU0QMr($PbQYK->mK2m1HH3DXA($KdniT));
            goto iWQ7C;
            xZV5K:
            K0siz:
            goto ivmVE;
            Ll8zQ:
            $XmIrJ = new DuIqygVrnYyD6('1080p', $j2was['width'], $j2was['height'], $KdniT->BRHdg ?? 30);
            goto zSlzr;
            OklZb:
            $j2was = $this->mOSVaAx2iPM($DMzDj, $T7AAY);
            goto aTWn8;
            Z7wC1:
            $G2Ngo = $vFqZF->msMi6BJaUlB($this->m876PLlEOPI($KdniT, $aacbt));
            goto tbYN6;
            Pcszn:
            if (!($KdniT->jWhvV !== BHGv9oAB1EERw::S3)) {
                goto qPVrZ;
            }
            goto doPMQ;
            YWvrr:
            if (!($DMzDj && $T7AAY)) {
                goto galZn;
            }
            goto z3U_H;
            tbYN6:
            $KdniT->update(['aws_media_converter_job_id' => $G2Ngo]);
            goto HExeo;
            ENx9n:
            $vFqZF = $vFqZF->mEg8CTn2ZIF($XmIrJ);
            goto xZV5K;
            QTS8Z:
            Assert::isInstanceOf($KdniT, UZrSkD9d5TXs1::class);
            goto Pcszn;
            SgLav:
            $vFqZF = app(GPKFcaJNi5OaU::class);
            goto gh6s9;
            j4X6g:
            $DMzDj = $KdniT->width();
            goto kVtp2;
            bU8cs:
            $h1Fyx = new GaDEq68fQRF9t($this->iyhKM, $this->vBgYT, $this->bwFb2, $this->HO2X0);
            goto QpvPP;
            j9x3d:
            $kC5Yx = $this->mFUZr0MmJiJ($KdniT);
            goto kiCI3;
            aTWn8:
            Log::info("Set 1080p resolution for Job", ['width' => $j2was['width'], 'height' => $j2was['height'], 'originalWidth' => $DMzDj, 'originalHeight' => $T7AAY]);
            goto Ll8zQ;
            tuBZk:
            if (!$Q2vvf) {
                goto UqGbz;
            }
            goto GyPN6;
            kVtp2:
            $T7AAY = $KdniT->height();
            goto j9x3d;
            K0ZSc:
            $vFqZF = $vFqZF->mMP4uIkcAhq($cxd2S);
            goto Z7wC1;
            xO1m6:
            $cxd2S = new QcoiOgw1BN3hR($KdniT->q7plI ?? 1, 2, $PbQYK->mwSlek9GVG5($KdniT));
            goto K0ZSc;
            GFU9F:
            $vFqZF->mpM00sU0QMr($PbQYK->mK2m1HH3DXA($KdniT));
            goto YWvrr;
            ivmVE:
            galZn:
            goto t0qom;
            cgeWG:
            $KdniT = UZrSkD9d5TXs1::findOrFail($G2Ngo);
            goto QTS8Z;
            DFdoo:
            $XmIrJ = $XmIrJ->m7kSdoKORhp($Q2vvf);
            goto R4rpG;
            v9V5f:
            $vFqZF->mEg8CTn2ZIF($r6gTn);
            goto bds87;
            z3U_H:
            if (!$this->msLuZZ5NR5m($DMzDj, $T7AAY)) {
                goto K0siz;
            }
            goto OklZb;
            xb7ZR:
            if (!$Q2vvf) {
                goto qhHOA;
            }
            goto DFdoo;
            t0qom:
            Log::info("Set thumbnail for UZrSkD9d5TXs1 Job", ['videoId' => $KdniT->getAttribute('id'), 'duration' => $KdniT->getAttribute('duration')]);
            goto xO1m6;
            doPMQ:
            throw new MediaConverterException("UZrSkD9d5TXs1 {$KdniT->id} is not S3 driver");
            goto FHJHJ;
            R4rpG:
            qhHOA:
            goto ENx9n;
            iWQ7C:
            $wrTQA = app(I2LnR7hUOOfvy::class);
            goto bU8cs;
            GyPN6:
            $r6gTn = $r6gTn->m7kSdoKORhp($Q2vvf);
            goto L6VNB;
            gmE13:
            $vFqZF->mEg8CTn2ZIF($r6gTn);
            goto GFU9F;
            O32hM:
            $r6gTn = new DuIqygVrnYyD6('original', $DMzDj, $T7AAY, $KdniT->BRHdg ?? 30);
            goto JRRTE;
            gh6s9:
            $vFqZF = $vFqZF->mfOFEyD5bTc(new NsrFDXbHHex5r($kC5Yx));
            goto O32hM;
            HExeo:
        } catch (\Exception $uEMU5) {
            Log::info("UZrSkD9d5TXs1 has been deleted, discard it", ['fileId' => $G2Ngo, 'err' => $uEMU5->getMessage()]);
            return;
        }
        goto y_TPj;
        Zz4G0:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $G2Ngo]);
        goto t2iIa;
        y_TPj:
    }
    private function m876PLlEOPI(UZrSkD9d5TXs1 $KdniT, $aacbt) : bool
    {
        goto GraPj;
        WQtNd:
        loS1J:
        goto wLsIH;
        sZzsm:
        $wVp9o = (int) round($KdniT->getAttribute('duration') ?? 0);
        goto nB8wc;
        iG7Ua:
        fWCEV:
        goto WQtNd;
        nhBHL:
        return false;
        goto TbQbE;
        GraPj:
        if ($aacbt) {
            goto vRHh2;
        }
        goto nhBHL;
        nB8wc:
        switch (true) {
            case $KdniT->width() * $KdniT->height() >= 1920 * 1080 && $KdniT->width() * $KdniT->height() < 2560 * 1440:
                return $wVp9o > 10 * 60;
            case $KdniT->width() * $KdniT->height() >= 2560 * 1440 && $KdniT->width() * $KdniT->height() < 3840 * 2160:
                return $wVp9o > 5 * 60;
            case $KdniT->width() * $KdniT->height() >= 3840 * 2160:
                return $wVp9o > 3 * 60;
            default:
                return false;
        }
        goto iG7Ua;
        TbQbE:
        vRHh2:
        goto sZzsm;
        wLsIH:
    }
    private function mD4Oz7H5TP3(I2LnR7hUOOfvy $wrTQA, string $Obh2s) : ?N18WZfZRjQqFL
    {
        goto G1IWE;
        rRtBn:
        return new N18WZfZRjQqFL($G66Hp, 0, 0, null, null);
        goto Gs1ie;
        T2_wJ:
        if (!$G66Hp) {
            goto zpFs7;
        }
        goto rRtBn;
        Gs1ie:
        zpFs7:
        goto zL1OO;
        zL1OO:
        return null;
        goto B6Zkz;
        ZG8UE:
        Log::info("Resolve watermark for job with url", ['url' => $Obh2s, 'uri' => $G66Hp]);
        goto T2_wJ;
        G1IWE:
        $G66Hp = $wrTQA->mysjBHznXFa($Obh2s);
        goto ZG8UE;
        B6Zkz:
    }
    private function msLuZZ5NR5m(int $DMzDj, int $T7AAY) : bool
    {
        return $DMzDj * $T7AAY > 1.5 * (1920 * 1080);
    }
    private function mOSVaAx2iPM(int $DMzDj, int $T7AAY) : array
    {
        $o4b3W = new EfYKxaDgxJrUK($DMzDj, $T7AAY);
        return $o4b3W->myOclZtMSgE();
    }
    private function mFUZr0MmJiJ(VWfw9VfxzTDgS $iiESX) : string
    {
        goto zb8OO;
        yAa4p:
        lGoNJ:
        goto mZvA_;
        zb8OO:
        if (!($iiESX->jWhvV == BHGv9oAB1EERw::S3)) {
            goto lGoNJ;
        }
        goto K1qHg;
        mZvA_:
        return $this->HO2X0->url($iiESX->filename);
        goto uzTM3;
        K1qHg:
        return 's3://' . $this->qNgj8 . '/' . $iiESX->filename;
        goto yAa4p;
        uzTM3:
    }
}
