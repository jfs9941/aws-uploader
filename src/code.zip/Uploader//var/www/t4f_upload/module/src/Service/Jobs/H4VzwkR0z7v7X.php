<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
class H4VzwkR0z7v7X implements CompressJobInterface
{
    const aX72r = 60;
    private $u_yGf;
    private $IXK4e;
    public function __construct($pDQ4h, $ZfrI6)
    {
        $this->u_yGf = $pDQ4h;
        $this->IXK4e = $ZfrI6;
    }
    public function compress(string $C3gWL)
    {
        goto KNMt4;
        p2eHG:
        Log::info("Compress image", ['imageId' => $C3gWL]);
        goto EqaAm;
        KNMt4:
        $vtCQy = microtime(true);
        goto DSuvu;
        DSuvu:
        $V2w10 = memory_get_usage();
        goto LuBJr;
        EqaAm:
        try {
            goto MA33K;
            yKs0a:
            unset($Jyrqg);
            goto p1ZCE;
            Jmnrf:
            $Jyrqg->orient()->toWebp(self::aX72r)->save($pLuaq);
            goto HCzuX;
            bm_2k:
            $Jyrqg = $this->u_yGf->call($this, $HS2N1);
            goto WX62f;
            tomGF:
            $OgE9J->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $OgE9J->getLocation()));
            goto fYtNj;
            iA4ZJ:
            if (!(strtolower($OgE9J->getExtension()) === 'png' || strtolower($OgE9J->getExtension()) === 'heic')) {
                goto Ot4g1;
            }
            goto U4Yfn;
            U4Yfn:
            $OgE9J->setAttribute('type', 'jpg');
            goto tomGF;
            gT1ar:
            Ot4g1:
            goto ttB6F;
            p1ZCE:
            $pLuaq = $this->IXK4e->path(str_replace('.jpg', '.webp', $OgE9J->getLocation()));
            goto CEOtD;
            ttB6F:
            $pLuaq = $this->IXK4e->path($OgE9J->getLocation());
            goto bm_2k;
            WX62f:
            $Jyrqg->orient()->toJpeg(self::aX72r)->save($pLuaq);
            goto yKs0a;
            MA33K:
            $OgE9J = Yi7VDaCr23YjR::findOrFail($C3gWL);
            goto C5v_F;
            CEOtD:
            $Jyrqg = $this->u_yGf->call($this, $HS2N1);
            goto Jmnrf;
            fYtNj:
            $OgE9J->save();
            goto gT1ar;
            HCzuX:
            unset($Jyrqg);
            goto v6UpL;
            C5v_F:
            $HS2N1 = $this->IXK4e->path($OgE9J->getLocation());
            goto iA4ZJ;
            v6UpL:
        } catch (ModelNotFoundException) {
            Log::info("Yi7VDaCr23YjR has been deleted, discard it", ['imageId' => $C3gWL]);
        } finally {
            $y18o3 = microtime(true);
            $gFytm = memory_get_usage();
            $M3rCv = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $C3gWL, 'execution_time_sec' => $y18o3 - $vtCQy, 'memory_usage_mb' => ($gFytm - $V2w10) / 1024 / 1024, 'peak_memory_usage_mb' => ($M3rCv - $pQYLS) / 1024 / 1024]);
        }
        goto gIxg0;
        LuBJr:
        $pQYLS = memory_get_peak_usage();
        goto p2eHG;
        gIxg0:
    }
}
