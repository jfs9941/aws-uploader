<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

final class N5z6dHogIzWBr
{
    private $Ie443;
    public function __construct(string $GBBD3, ?int $Z_vN0, ?int $TPJAc, float $ddvCH)
    {
        goto fll8c;
        rGR7j:
        $this->Ie443['VideoDescription']['Width'] = $Z_vN0;
        goto wr60b;
        GYVd_:
        E4nXP:
        goto oDaEC;
        fll8c:
        $XzXoZ = 15000000;
        goto Ehzbp;
        wr60b:
        $this->Ie443['VideoDescription']['Height'] = $TPJAc;
        goto XMW8A;
        t0JBH:
        if (!($Z_vN0 && $TPJAc)) {
            goto m2Agc;
        }
        goto rGR7j;
        Ehzbp:
        if (!($Z_vN0 && $TPJAc)) {
            goto E4nXP;
        }
        goto tQkCy;
        XMW8A:
        m2Agc:
        goto CBW9j;
        oDaEC:
        $this->Ie443 = ['ContainerSettings' => ['Container' => 'M3U8', 'M3u8Settings' => []], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'H_264', 'H264Settings' => ['MaxBitrate' => $XzXoZ, 'RateControlMode' => 'QVBR', 'SceneChangeDetect' => 'TRANSITION_DETECTION']]], 'AudioDescriptions' => [['CodecSettings' => ['Codec' => 'AAC', 'AacSettings' => ['Bitrate' => 96000, 'CodingMode' => 'CODING_MODE_2_0', 'SampleRate' => 48000]]]], 'OutputSettings' => ['HlsSettings' => []], 'NameModifier' => $GBBD3];
        goto t0JBH;
        tQkCy:
        $XzXoZ = $this->moyasHBRGQX($Z_vN0, $TPJAc, $ddvCH);
        goto GYVd_;
        CBW9j:
    }
    public function moa0T0iXoxB(BxOAxkVVSgnJt $DylMz) : self
    {
        $this->Ie443['VideoDescription']['VideoPreprocessors'] = $DylMz->m8CUk2ds1t3();
        return $this;
    }
    public function mCacZ9evS6P() : array
    {
        return $this->Ie443;
    }
    private function moyasHBRGQX(int $Z_vN0, int $TPJAc, float $CJfXw, string $hi5Ix = 'medium', string $QEyxX = 'h264', string $V_3TH = 'good') : ?int
    {
        goto w4u7r;
        z6nqY:
        goto AhP_j;
        goto Y8s0O;
        Idxdq:
        $THqwB = 30;
        goto jYhMZ;
        tXZUE:
        switch (strtolower($V_3TH)) {
            case 'low':
                $z50hy *= 0.8;
                goto Qgbjs;
            case 'high':
                $z50hy *= 1.2;
                goto Qgbjs;
        }
        goto VGf9q;
        bTjYL:
        if ($DTJ8Z <= 2560 * 1440) {
            goto fmdKH;
        }
        goto iMHSP;
        r_s3X:
        Qgbjs:
        goto ky7dx;
        NQw4T:
        zfF8A:
        goto kzg3X;
        W0ASE:
        Vnx4o:
        goto y0O1x;
        iMHSP:
        if ($DTJ8Z <= 3840 * 2160) {
            goto PXHnW;
        }
        goto Idxdq;
        vbkXT:
        if ($DTJ8Z <= 640 * 480) {
            goto nX1JQ;
        }
        goto tuFiV;
        tEG3h:
        switch (strtolower($hi5Ix)) {
            case 'low':
                $z50hy *= 0.7;
                goto XFKpL;
            case 'high':
                $z50hy *= 1.3;
                goto XFKpL;
            case 'veryhigh':
                $z50hy *= 1.6;
                goto XFKpL;
        }
        goto NQw4T;
        ejdUD:
        $THqwB = 1.5;
        goto z6nqY;
        P_l4G:
        $z50hy *= 0.65;
        goto OIArR;
        VDUaT:
        $THqwB = 20;
        goto hxm_0;
        he3j9:
        goto AhP_j;
        goto ozIO7;
        UHriV:
        if (!('h265' === strtolower($QEyxX) || 'hevc' === strtolower($QEyxX) || 'vp9' === strtolower($QEyxX))) {
            goto fpxck;
        }
        goto P_l4G;
        ky7dx:
        $z50hy = max(0.5, $z50hy);
        goto OBpJ4;
        wJfH5:
        fmdKH:
        goto SLyrt;
        y0O1x:
        $THqwB = 7;
        goto F8Fzj;
        hxm_0:
        AhP_j:
        goto UdTD2;
        w4u7r:
        $DTJ8Z = $Z_vN0 * $TPJAc;
        goto vbkXT;
        Y8s0O:
        dSTE2:
        goto aiZx4;
        OBpJ4:
        return (int) ($z50hy * 1000 * 1000);
        goto vI_o6;
        tuFiV:
        if ($DTJ8Z <= 1280 * 720) {
            goto dSTE2;
        }
        goto pqMHt;
        F8Fzj:
        goto AhP_j;
        goto wJfH5;
        iV5HY:
        nX1JQ:
        goto ejdUD;
        aiZx4:
        $THqwB = 3;
        goto oS0yB;
        oS0yB:
        goto AhP_j;
        goto W0ASE;
        kzg3X:
        XFKpL:
        goto UHriV;
        OIArR:
        fpxck:
        goto tXZUE;
        jYhMZ:
        goto AhP_j;
        goto iV5HY;
        SLyrt:
        $THqwB = 12;
        goto he3j9;
        ozIO7:
        PXHnW:
        goto VDUaT;
        VGf9q:
        CbYSv:
        goto r_s3X;
        UdTD2:
        $z50hy = $THqwB * ($CJfXw / 30);
        goto tEG3h;
        pqMHt:
        if ($DTJ8Z <= 1920 * 1080) {
            goto Vnx4o;
        }
        goto bTjYL;
        vI_o6:
    }
}
