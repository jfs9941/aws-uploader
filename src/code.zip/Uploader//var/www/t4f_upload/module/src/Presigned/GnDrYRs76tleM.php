<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\J21tNbgDxO48q;
use Jfs\Uploader\Exception\SN80ZGs6Yur2B;
use Jfs\Uploader\Exception\UhkliZbDzh8SV;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Jfs\Uploader\Exception\OKpMElw0zJrVZ;
use Webmozart\Assert\Assert;
class GnDrYRs76tleM implements Rz4POwbUwhVXa
{
    private $wUoTe;
    private $m1w1p;
    private $B4orz;
    private $jXO7P;
    public function __construct(J21tNbgDxO48q $HGYQh, Filesystem $C14In, Filesystem $NEN4P, string $ysemJ)
    {
        goto ZWhgJ;
        k69e1:
        $this->m1w1p = $C14In;
        goto Rw6Ty;
        ZWhgJ:
        $this->wUoTe = $HGYQh;
        goto k69e1;
        LKxs0:
        $this->jXO7P = $ysemJ;
        goto EkyxT;
        Rw6Ty:
        $this->B4orz = $NEN4P;
        goto LKxs0;
        EkyxT:
    }
    public function mcVIq3YSwoT()
    {
        goto J8ry_;
        zytaT:
        $msjEK = [];
        goto lANa6;
        xrEFL:
        $Z5H8N = $ZwGMx->getCommand('UploadPart', ['Bucket' => $this->jXO7P, 'Key' => $this->wUoTe->getFile()->getLocation(), 'UploadId' => $cUHx5['UploadId'], 'PartNumber' => $xOJpq]);
        goto QDWT6;
        lANa6:
        $JWi5D = ceil($ToSwr->t5_u0 / $ToSwr->D3XQc);
        goto QwTIy;
        L359F:
        if (!(0 === $cUHx5->count())) {
            goto tCWSR;
        }
        goto riChj;
        ECUbS:
        EcxI8:
        goto aIrPI;
        af2gt:
        Do2ar:
        goto fVoGL;
        riChj:
        throw new OKpMElw0zJrVZ("Failed to create multipart upload for file {$this->wUoTe->getFile()->getFilename()}, S3 return empty response");
        goto RdTdb;
        uPUys:
        goto F81N8;
        goto af2gt;
        fVoGL:
        $this->wUoTe->mMvFucyKTZs($msjEK);
        goto SN1qW;
        C5eK6:
        if (!($xOJpq <= $JWi5D)) {
            goto Do2ar;
        }
        goto xrEFL;
        Ap1_R:
        $msjEK[] = ['index' => $xOJpq, 'url' => (string) $x0BE4->getUri()];
        goto ECUbS;
        ElUm5:
        F81N8:
        goto C5eK6;
        J8ry_:
        $ToSwr = $this->wUoTe->m4Wida2haiR();
        goto zytaT;
        QD8aI:
        $this->m1w1p->put($this->wUoTe->mdSMfJlo5gi(), json_encode($this->wUoTe->m4Wida2haiR()->toArray()));
        goto MjuZ_;
        SN1qW:
        $this->wUoTe->m4Wida2haiR()->m4KpNugol8f($cUHx5['UploadId']);
        goto QD8aI;
        tudtx:
        $cUHx5 = $ZwGMx->createMultipartUpload(['Bucket' => $this->jXO7P, 'Key' => $this->wUoTe->getFile()->getLocation(), 'ContentType' => $this->wUoTe->m4Wida2haiR()->kitse, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto L359F;
        QDWT6:
        $x0BE4 = $ZwGMx->createPresignedRequest($Z5H8N, '+1 day');
        goto Ap1_R;
        UUMPx:
        $xOJpq = 1;
        goto ElUm5;
        MjuZ_:
        $this->B4orz->put($this->wUoTe->mdSMfJlo5gi(), json_encode($this->wUoTe->m4Wida2haiR()->toArray()));
        goto ItyC5;
        aIrPI:
        ++$xOJpq;
        goto uPUys;
        RdTdb:
        tCWSR:
        goto UUMPx;
        QwTIy:
        $ZwGMx = $this->B4orz->getClient();
        goto tudtx;
        ItyC5:
    }
    public function mA0bZyHVa8D() : void
    {
        goto d34Eb;
        v5wAA:
        try {
            $ZwGMx->abortMultipartUpload(['Bucket' => $this->jXO7P, 'Key' => $this->wUoTe->getFile()->getLocation(), 'UploadId' => $this->wUoTe->m4Wida2haiR()->dzUxu]);
        } catch (\Throwable $TTMgE) {
            throw new SN80ZGs6Yur2B("Failed to abort multipart upload of file {$this->wUoTe->getFile()->getFilename()}", 0, $TTMgE);
        }
        goto QXWrL;
        Z2wgq:
        $this->B4orz->delete($this->wUoTe->mdSMfJlo5gi());
        goto jCxqi;
        QXWrL:
        $this->m1w1p->delete($this->wUoTe->mdSMfJlo5gi());
        goto Z2wgq;
        d34Eb:
        $ZwGMx = $this->B4orz->getClient();
        goto v5wAA;
        jCxqi:
    }
    public function mTEjEDKjwaj() : void
    {
        goto ilfLg;
        AkJIM:
        Assert::eq(count($O9jdF), count($vBE45), 'The number of parts and checksums must match.');
        goto JwYdv;
        pIHMh:
        $O9jdF = $ToSwr->l2MEk;
        goto xx7Nq;
        JwYdv:
        $sILa1 = collect($O9jdF)->keyBy('partNumber');
        goto A6y1I;
        ntMux:
        BloZx:
        goto mHkUI;
        xx7Nq:
        $vBE45 = $ToSwr->pfuuj;
        goto AkJIM;
        ilfLg:
        $ToSwr = $this->wUoTe->m4Wida2haiR();
        goto pIHMh;
        A6y1I:
        foreach ($vBE45 as $ks7Vf) {
            goto xL3un;
            xL3un:
            $a35oG = $ks7Vf['partNumber'];
            goto B2H_l;
            B2H_l:
            $j7Veu = $sILa1[$a35oG];
            goto zT8Ke;
            IRCv5:
            throw new UhkliZbDzh8SV("Checksum mismatch for part {$a35oG} of file {$this->wUoTe->getFile()->getFilename()}");
            goto v1WWZ;
            ANGj9:
            j56wk:
            goto nFIl3;
            v1WWZ:
            E7kG6:
            goto ANGj9;
            zT8Ke:
            if (!($j7Veu['eTag'] !== $ks7Vf['eTag'])) {
                goto E7kG6;
            }
            goto IRCv5;
            nFIl3:
        }
        goto ntMux;
        mHkUI:
        $ZwGMx = $this->B4orz->getClient();
        goto jg0EC;
        jg0EC:
        try {
            $ZwGMx->completeMultipartUpload(['Bucket' => $this->jXO7P, 'Key' => $this->wUoTe->getFile()->getLocation(), 'UploadId' => $this->wUoTe->m4Wida2haiR()->dzUxu, 'MultipartUpload' => ['Parts' => collect($this->wUoTe->m4Wida2haiR()->l2MEk)->sortBy('partNumber')->map(fn($j7Veu) => ['ETag' => $j7Veu['eTag'], 'PartNumber' => $j7Veu['partNumber']])->toArray()]]);
        } catch (\Throwable $TTMgE) {
            throw new UhkliZbDzh8SV("Failed to merge chunks of file {$this->wUoTe->getFile()->getFilename()}", 0, $TTMgE);
        }
        goto pdNgQ;
        pdNgQ:
    }
}
