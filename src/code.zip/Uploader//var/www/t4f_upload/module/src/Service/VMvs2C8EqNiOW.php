<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Core\Observer\BhoSAWpH8If6y;
use Jfs\Uploader\Core\Observer\PksME5sRCOp6p;
use Jfs\Uploader\Core\RTkNv5GS7FY9w;
use Jfs\Uploader\Core\XTBZ0J08jz6g2;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Jfs\Uploader\Exception\LBmcQcFLDfSRa;
use Jfs\Uploader\Service\FileResolver\IyHy3A57jqaFT;
use Ramsey\Uuid\Uuid;
final class VMvs2C8EqNiOW
{
    private $TBC_a;
    private $m1w1p;
    private $zl2D8;
    public function __construct($bEpoM, $C14In, $VVGKi)
    {
        goto Ti3q8;
        Ti3q8:
        $this->TBC_a = $bEpoM;
        goto gYu9t;
        gYu9t:
        $this->m1w1p = $C14In;
        goto SBzls;
        SBzls:
        $this->zl2D8 = $VVGKi;
        goto mHId9;
        mHId9:
    }
    public function m9HMdBC6vWU($nW4k2)
    {
        goto iqSZT;
        yRBxJ:
        ZJGPt:
        goto ENq0r;
        zJvre:
        return $this->mCb8YJgNvWQ($o9UoH->extension(), YZ2lA0H3k4o6O::S3, null, $nW4k2->options());
        goto yRBxJ;
        W9Zez:
        $o9UoH = $nW4k2->getFile();
        goto zJvre;
        iqSZT:
        if (!$nW4k2 instanceof SingleUploadInterface) {
            goto ZJGPt;
        }
        goto W9Zez;
        ENq0r:
        return $this->mCb8YJgNvWQ($nW4k2['file_extension'], 's3' === $nW4k2['driver'] ? YZ2lA0H3k4o6O::S3 : YZ2lA0H3k4o6O::LOCAL);
        goto DPHmE;
        DPHmE:
    }
    public function mQnMZYLB5DS(string $C3gWL)
    {
        goto PUk8e;
        O1_OH:
        $m42Ed = $this->mCb8YJgNvWQ($FfPRr->getAttribute('type'), $FfPRr->getAttribute('driver'), $FfPRr->getAttribute('id'));
        goto kKJFj;
        N88vv:
        $m42Ed->setRawAttributes($FfPRr->getAttributes());
        goto eOHI2;
        PUk8e:
        $FfPRr = config('upload.attachment_model')::findOrFail($C3gWL);
        goto O1_OH;
        kKJFj:
        $m42Ed->exists = true;
        goto N88vv;
        eOHI2:
        return $m42Ed;
        goto cmRcg;
        cmRcg:
    }
    public function mXpJaN6vCRL(string $bdGKr) : XPHcGwVprkaGk
    {
        goto C7yNs;
        C7yNs:
        $hxoL8 = $this->m1w1p->get($bdGKr);
        goto AOxq4;
        y31O2:
        return $this->mCb8YJgNvWQ($BP4Q4->OBJgU, $BP4Q4->mKE3VTU3YZK(), $BP4Q4->filename);
        goto Y9zkt;
        Y9zkt:
        yBw1V:
        goto sb_im;
        AOxq4:
        if ($hxoL8) {
            goto QDgaY;
        }
        goto POSIl;
        POSIl:
        $hxoL8 = $this->zl2D8->get($bdGKr);
        goto Es30B;
        sb_im:
        throw new VKLvMBsGaTGC2('metadata file not found');
        goto kczby;
        yXBXc:
        $BP4Q4 = XTBZ0J08jz6g2::myImQtehpRT($ToSwr);
        goto y31O2;
        Es30B:
        QDgaY:
        goto Vz7cq;
        yX4GN:
        if (!$ToSwr) {
            goto yBw1V;
        }
        goto yXBXc;
        Vz7cq:
        $ToSwr = json_decode($hxoL8, true);
        goto yX4GN;
        kczby:
    }
    private function mCb8YJgNvWQ(string $Z5How, $IbRHn, ?string $C3gWL = null, array $abuNK = [])
    {
        goto NJB_7;
        yujFE:
        $Az6Q9 = $Az6Q9->mmlTwuwOyAY($IbRHn);
        goto AVGhq;
        ywVvQ:
        foreach ($this->TBC_a as $gL9vu) {
            goto FWnUH;
            IFtI0:
            eUoRt:
            goto PGcGp;
            FWnUH:
            if (!$gL9vu->mkexAYAWxp4($Az6Q9)) {
                goto xCzkV;
            }
            goto uL6fR;
            c6F8_:
            xCzkV:
            goto IFtI0;
            uL6fR:
            return $Az6Q9->initLocation($gL9vu->mF4oZkheU68($Az6Q9));
            goto c6F8_;
            PGcGp:
        }
        goto V8VAZ;
        btzyx:
        switch ($Z5How) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $Az6Q9 = Yi7VDaCr23YjR::createFromScratch($C3gWL, $Z5How);
                goto sNl3B;
            case 'mp4':
            case 'mov':
                $Az6Q9 = Zr0izVmbs7QaE::createFromScratch($C3gWL, $Z5How);
                goto sNl3B;
            case 'pdf':
                $Az6Q9 = RTkNv5GS7FY9w::createFromScratch($C3gWL, $Z5How);
                goto sNl3B;
            default:
                throw new LBmcQcFLDfSRa("not support file type {$Z5How}");
        }
        goto jts_J;
        Omjze:
        throw new LBmcQcFLDfSRa("not support file type {$Z5How}");
        goto ikVlm;
        NJB_7:
        $C3gWL = $C3gWL ?? Uuid::uuid4()->getHex()->toString();
        goto btzyx;
        u1no5:
        $Az6Q9->mKGeLgXFwuF(new PksME5sRCOp6p($Az6Q9, $this->zl2D8, $abuNK));
        goto ywVvQ;
        jts_J:
        l5m5L:
        goto NJP9b;
        V8VAZ:
        mPqBH:
        goto Omjze;
        NJP9b:
        sNl3B:
        goto yujFE;
        AVGhq:
        $Az6Q9->mKGeLgXFwuF(new BhoSAWpH8If6y($Az6Q9));
        goto u1no5;
        ikVlm:
    }
}
