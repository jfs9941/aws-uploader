<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Contracts\TS9H8HOxifnQ6;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Core\Strategy\Rz6pax6zBD0VN;
use Jfs\Uploader\Core\Strategy\KvIpIccBNiFQn;
use Jfs\Uploader\Encoder\NLnbq513ssJFf;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Service\IudiFfJzDfyEK;
final class F4yAcsiRqIVH0 implements TS9H8HOxifnQ6
{
    private $qmtXx;
    private $d2AB9;
    private $j_caY;
    private $q0UvW;
    public function __construct($uY0L7, $nFXer, $qC1gq)
    {
        goto k8Mm2;
        ahZUn:
        $this->q0UvW = $qC1gq;
        goto U9ALA;
        U9ALA:
        $this->qmtXx = $this->m615kitfR5q();
        goto URS2Y;
        k8Mm2:
        $this->d2AB9 = $uY0L7;
        goto RmAKb;
        RmAKb:
        $this->j_caY = $nFXer;
        goto ahZUn;
        URS2Y:
    }
    public function m2AgYct6sO6($kUpO4, $negwf) : void
    {
        goto qtJ26;
        Qpq0O:
        $this->qmtXx->process($negwf);
        goto S5E5N;
        FpYvk:
        if (!(OHa83BAIlECUz::ENCODING_PROCESSED === $negwf)) {
            goto AWkvM;
        }
        goto s1FO7;
        l6tmU:
        $this->d2AB9->save();
        goto ICQ3P;
        j2qYW:
        cfypy:
        goto DRIMC;
        s1FO7:
        $this->d2AB9->save();
        goto up87S;
        up87S:
        if (!$this->qmtXx) {
            goto cfypy;
        }
        goto DGSWq;
        JNLAP:
        Lu_Vu:
        goto FpYvk;
        DRIMC:
        AWkvM:
        goto Jqi1S;
        DGSWq:
        $this->qmtXx->process($negwf);
        goto j2qYW;
        ICQ3P:
        if (!$this->qmtXx) {
            goto uZ9Tp;
        }
        goto Qpq0O;
        qtJ26:
        if (!(OHa83BAIlECUz::PROCESSING === $negwf)) {
            goto Lu_Vu;
        }
        goto l6tmU;
        S5E5N:
        uZ9Tp:
        goto JNLAP;
        Jqi1S:
    }
    private function m615kitfR5q()
    {
        goto wtGEY;
        hGFJs:
        bm0lj:
        goto Gk9h8;
        l5qqt:
        oEFJH:
        goto hGFJs;
        wtGEY:
        switch ($this->d2AB9->getType()) {
            case 'image':
                return new Rz6pax6zBD0VN($this->d2AB9, $this->q0UvW);
            case 'video':
                return new KvIpIccBNiFQn($this->d2AB9, App::make(NLnbq513ssJFf::class));
            default:
                return null;
        }
        goto l5qqt;
        Gk9h8:
    }
}
