<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Core\Observer\NfcpcOhaS3qQx;
use Jfs\Uploader\Core\Traits\YVxJaYy0njJEj;
use Jfs\Uploader\Core\Traits\GDAKcbwJFwlZG;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Exception\HHLHHofZj2D7E;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Jfs\Uploader\Exception\LBmcQcFLDfSRa;
use Jfs\Uploader\Service\VMvs2C8EqNiOW;
final class J21tNbgDxO48q implements XPHcGwVprkaGk
{
    use YVxJaYy0njJEj;
    use GDAKcbwJFwlZG;
    private $LoL2N;
    private function __construct($m42Ed, $C14In)
    {
        $this->k4fCM = $m42Ed;
        $this->tFpzY = $C14In;
    }
    private function mcBNgLohOMt(string $ysemJ, $C14In, $NEN4P, bool $qeXOc = false) : void
    {
        $this->mKGeLgXFwuF(new NfcpcOhaS3qQx($this, $C14In, $NEN4P, $ysemJ, $qeXOc));
    }
    public function getFile()
    {
        return $this->k4fCM;
    }
    public function mMvFucyKTZs(array $AHrXj) : void
    {
        $this->LoL2N = $AHrXj;
    }
    public function mczj4yIsi68() : void
    {
        $this->mZJDINqUefY(IoCBJqqLig917::UPLOADING);
    }
    public function m8pjX8ammrh() : void
    {
        $this->mZJDINqUefY(IoCBJqqLig917::UPLOADED);
    }
    public function mkSCSngsfT0() : void
    {
        $this->mZJDINqUefY(IoCBJqqLig917::PROCESSING);
    }
    public function mqQzrXJ1FrU() : void
    {
        $this->mZJDINqUefY(IoCBJqqLig917::FINISHED);
    }
    public function mSm6MCJKJlZ() : void
    {
        $this->mZJDINqUefY(IoCBJqqLig917::ABORTED);
    }
    public function my0TBkaK6yN() : array
    {
        return $this->LoL2N;
    }
    public static function m5DtrRvRnse(string $C3gWL, $pZx_K, $VVGKi, $ysemJ) : self
    {
        goto a1r0r;
        a1r0r:
        $m42Ed = App::make(VMvs2C8EqNiOW::class)->mXpJaN6vCRL(XTBZ0J08jz6g2::mbTTXYu6dUz($C3gWL));
        goto XYVXW;
        ARzuc:
        $x0BE4->mN5D2NajOK4(IoCBJqqLig917::UPLOADING);
        goto Ua1Zj;
        XYVXW:
        $x0BE4 = new self($m42Ed, $pZx_K);
        goto i20r4;
        Ua1Zj:
        return $x0BE4->mIHtrED3u3o();
        goto DolM9;
        i20r4:
        $x0BE4->mcBNgLohOMt($ysemJ, $pZx_K, $VVGKi);
        goto ARzuc;
        DolM9:
    }
    public static function m87aEM3zIc5($m42Ed, $C14In, $NEN4P, $ysemJ, $qeXOc = false) : self
    {
        goto gBjmn;
        G2UIS:
        return $x0BE4;
        goto Akpd1;
        gBjmn:
        $x0BE4 = new self($m42Ed, $C14In);
        goto zcRqu;
        yCtoG:
        $x0BE4->mN5D2NajOK4(IoCBJqqLig917::UPLOADING);
        goto G2UIS;
        zcRqu:
        $x0BE4->mcBNgLohOMt($ysemJ, $C14In, $NEN4P, $qeXOc);
        goto yCtoG;
        Akpd1:
    }
}
