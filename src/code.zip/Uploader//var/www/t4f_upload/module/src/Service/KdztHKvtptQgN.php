<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Intervention\Yi7VDaCr23YjR\Drivers\Imagick\Driver;
use Intervention\Yi7VDaCr23YjR\ImageManager;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Core\J21tNbgDxO48q;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Exception\HHLHHofZj2D7E;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Jfs\Uploader\Exception\LBmcQcFLDfSRa;
final class KdztHKvtptQgN implements UploadServiceInterface
{
    private $xj5vh;
    private $m1w1p;
    private $B4orz;
    private $VEecH;
    public function __construct(VMvs2C8EqNiOW $VsW09, Filesystem $C14In, Filesystem $NEN4P, string $l5HTo)
    {
        goto whNUF;
        ZEI1F:
        $this->m1w1p = $C14In;
        goto dV5Z0;
        eU0Oq:
        $this->VEecH = $l5HTo;
        goto BxXGm;
        whNUF:
        $this->xj5vh = $VsW09;
        goto ZEI1F;
        dV5Z0:
        $this->B4orz = $NEN4P;
        goto eU0Oq;
        BxXGm:
    }
    public function storeSingleFile(SingleUploadInterface $Q3eD5) : array
    {
        goto pKLpW;
        kNI9Y:
        EyAT4:
        goto eMkA8;
        pKLpW:
        $m42Ed = $this->xj5vh->m9HMdBC6vWU($Q3eD5);
        goto ZiCnm;
        pzvF8:
        if (false !== $PeSCk && $m42Ed instanceof XPHcGwVprkaGk) {
            goto O1OAf;
        }
        goto zEe45;
        Xu2ig:
        goto EyAT4;
        goto Rjwpi;
        zEe45:
        throw new \LogicException('File upload failed, check permissions');
        goto Xu2ig;
        PE8RS:
        $m42Ed->mZJDINqUefY(IoCBJqqLig917::UPLOADED);
        goto kNI9Y;
        Rjwpi:
        O1OAf:
        goto PE8RS;
        eMkA8:
        return $m42Ed->getView();
        goto V7LeJ;
        ZiCnm:
        $PeSCk = $this->B4orz->putFileAs(dirname($m42Ed->getLocation()), $Q3eD5->getFile(), $m42Ed->getFilename() . '.' . $m42Ed->getExtension(), ['visibility' => 'public']);
        goto pzvF8;
        V7LeJ:
    }
    public function storePreSignedFile(array $FqNVe)
    {
        goto Ue2xh;
        SfwCF:
        $HGYQh = J21tNbgDxO48q::m87aEM3zIc5($m42Ed, $this->m1w1p, $this->B4orz, $this->VEecH, true);
        goto sYOrS;
        sYOrS:
        $HGYQh->mgbedfZIwhr($FqNVe['mime'], $FqNVe['file_size'], $FqNVe['chunk_size'], $FqNVe['checksums'], $FqNVe['user_id'], $FqNVe['driver']);
        goto qSjgl;
        Ue2xh:
        $m42Ed = $this->xj5vh->m9HMdBC6vWU($FqNVe);
        goto SfwCF;
        qSjgl:
        $HGYQh->mczj4yIsi68();
        goto u51xw;
        u51xw:
        return ['filename' => $HGYQh->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $HGYQh->my0TBkaK6yN()];
        goto mfSBW;
        mfSBW:
    }
    public function updatePreSignedFile(string $CLIZc, int $O3kOv)
    {
        goto CURo5;
        g2pLk:
        e5Wqd:
        goto qbWbF;
        CURo5:
        $HGYQh = J21tNbgDxO48q::m5DtrRvRnse($CLIZc, $this->m1w1p, $this->B4orz, $this->VEecH);
        goto NXD6V;
        qbWbF:
        aAH3c:
        goto hm_Xn;
        NXD6V:
        switch ($O3kOv) {
            case IoCBJqqLig917::UPLOADED:
                $HGYQh->m8pjX8ammrh();
                goto aAH3c;
            case IoCBJqqLig917::PROCESSING:
                $HGYQh->mkSCSngsfT0();
                goto aAH3c;
            case IoCBJqqLig917::FINISHED:
                $HGYQh->mqQzrXJ1FrU();
                goto aAH3c;
            case IoCBJqqLig917::ABORTED:
                $HGYQh->mSm6MCJKJlZ();
                goto aAH3c;
        }
        goto g2pLk;
        hm_Xn:
    }
    public function completePreSignedFile(string $CLIZc, array $O9jdF)
    {
        goto i3in5;
        Td6qt:
        return ['path' => $HGYQh->getFile()->getView()['path'], 'thumbnail' => $HGYQh->getFile()->X8D1W, 'id' => $CLIZc];
        goto uRAh5;
        zkcPZ:
        $HGYQh->m8pjX8ammrh();
        goto Td6qt;
        i3in5:
        $HGYQh = J21tNbgDxO48q::m5DtrRvRnse($CLIZc, $this->m1w1p, $this->B4orz, $this->VEecH);
        goto V6A4Y;
        V6A4Y:
        $HGYQh->m4Wida2haiR()->mp2cpQG5SxY($O9jdF);
        goto zkcPZ;
        uRAh5:
    }
    public function updateFile(string $CLIZc, int $O3kOv) : Ezj2tYBlqBPt9
    {
        goto C5SCx;
        pd3tf:
        return $m42Ed;
        goto FZA_2;
        C5SCx:
        $m42Ed = $this->xj5vh->mQnMZYLB5DS($CLIZc);
        goto alFgE;
        alFgE:
        $m42Ed->mZJDINqUefY($O3kOv);
        goto pd3tf;
        FZA_2:
    }
}
