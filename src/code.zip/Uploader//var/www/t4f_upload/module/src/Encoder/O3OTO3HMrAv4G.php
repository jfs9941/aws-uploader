<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class O3OTO3HMrAv4G
{
    private $X8D1W;
    public function __construct(float $pd9Fv, int $ly2mD, string $HNFAU)
    {
        goto lHgFD;
        cc_xH:
        $this->X8D1W = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $K3wxO]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $HNFAU]]];
        goto Dk9xZ;
        Wrzld:
        $K3wxO = max($K3wxO, 1);
        goto cc_xH;
        lHgFD:
        $K3wxO = (int) $pd9Fv / $ly2mD;
        goto Wrzld;
        Dk9xZ:
    }
    public function mTglVPctJiG() : array
    {
        return $this->X8D1W;
    }
}
