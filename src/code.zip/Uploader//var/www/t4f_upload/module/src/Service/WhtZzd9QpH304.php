<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
final class WhtZzd9QpH304
{
    private $jXO7P;
    private $GGRa9;
    private $m1w1p;
    public function __construct(string $ysemJ, string $wGqnQ, Filesystem $C14In)
    {
        goto f18DD;
        qK4bc:
        $this->GGRa9 = $wGqnQ;
        goto UO5kB;
        f18DD:
        $this->jXO7P = $ysemJ;
        goto qK4bc;
        UO5kB:
        $this->m1w1p = $C14In;
        goto OedwM;
        OedwM:
    }
    public function mo1kyPruDr0(REvUXqyajwths $vqGuD) : string
    {
        goto kY675;
        YMIkc:
        return $this->m1w1p->url($vqGuD->getAttribute('filename'));
        goto ftJAd;
        X7rmd:
        return 's3://' . $this->jXO7P . '/' . $vqGuD->getAttribute('filename');
        goto dA15L;
        dA15L:
        G6nK6:
        goto YMIkc;
        kY675:
        if (!(YZ2lA0H3k4o6O::S3 == $vqGuD->getAttribute('driver'))) {
            goto G6nK6;
        }
        goto X7rmd;
        ftJAd:
    }
    public function m1JgzE5VBur(?string $Z1XDV) : ?string
    {
        goto RZvXg;
        pyK7O:
        return null;
        goto XJXM7;
        GoTf6:
        nBaSH:
        goto DSq0O;
        RZvXg:
        if (!$Z1XDV) {
            goto gdcw1;
        }
        goto lDFmN;
        DSq0O:
        gdcw1:
        goto pyK7O;
        lDFmN:
        if (!eOpS0($Z1XDV, $this->jXO7P)) {
            goto nBaSH;
        }
        goto CFXn1;
        YB1g1:
        return 's3://' . $this->jXO7P . '/' . ltrim($PeSCk, '/');
        goto GoTf6;
        CFXn1:
        $PeSCk = parse_url($Z1XDV, PHP_URL_PATH);
        goto YB1g1;
        XJXM7:
    }
    public function mLeJP93wqJe(string $PeSCk) : string
    {
        return 's3://' . $this->jXO7P . '/' . $PeSCk;
    }
}
