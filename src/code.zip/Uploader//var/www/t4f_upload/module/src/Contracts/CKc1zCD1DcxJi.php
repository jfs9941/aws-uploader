<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
interface CKc1zCD1DcxJi
{
    public function resolvePath($MoQri, int $izVKZ = YZ2lA0H3k4o6O::S3);
    public function resolveThumbnail(REvUXqyajwths $MoQri);
    public function resolvePathForHlsVideo(Zr0izVmbs7QaE $jTXdP, bool $yFiE2 = false);
    public function resolvePathForHlsVideos();
}
