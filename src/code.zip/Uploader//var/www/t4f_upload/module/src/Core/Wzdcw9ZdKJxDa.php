<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Core\Observer\SKEO676c9OopQ;
use Jfs\Uploader\Core\Traits\AwYRMZN3aMGos;
use Jfs\Uploader\Core\Traits\PNxZ9iFoUyPar;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Exception\D6MBMAoedrGZe;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Jfs\Uploader\Exception\Bn3pSnwSmAp3g;
use Jfs\Uploader\Service\SIHyHN1Z6B4kZ;
final class Wzdcw9ZdKJxDa implements PwKw6a6OizPW3
{
    use AwYRMZN3aMGos;
    use PNxZ9iFoUyPar;
    private $j1o7p;
    private function __construct($uY0L7, $WPRCg)
    {
        $this->d2AB9 = $uY0L7;
        $this->s4AoW = $WPRCg;
    }
    private function mi4XfGexshW(string $VxiVW, $WPRCg, $XdRPm, bool $EnYUL = false) : void
    {
        $this->mdmuA7GRonF(new SKEO676c9OopQ($this, $WPRCg, $XdRPm, $VxiVW, $EnYUL));
    }
    public function getFile()
    {
        return $this->d2AB9;
    }
    public function mJhZVlPGxoU(array $jWndX) : void
    {
        $this->j1o7p = $jWndX;
    }
    public function myHKnooDJpw() : void
    {
        $this->mySoGGDrYI4(OHa83BAIlECUz::UPLOADING);
    }
    public function mY9a5qofcf2() : void
    {
        $this->mySoGGDrYI4(OHa83BAIlECUz::UPLOADED);
    }
    public function mALmUmJIvXf() : void
    {
        $this->mySoGGDrYI4(OHa83BAIlECUz::PROCESSING);
    }
    public function mRkvHAdTDFm() : void
    {
        $this->mySoGGDrYI4(OHa83BAIlECUz::FINISHED);
    }
    public function moTEbgOnFLa() : void
    {
        $this->mySoGGDrYI4(OHa83BAIlECUz::ABORTED);
    }
    public function mBy0KABRl9K() : array
    {
        return $this->j1o7p;
    }
    public static function m4EgfhwnPGO(string $W0vWP, $SsHDs, $nFXer, $VxiVW) : self
    {
        goto oXPEX;
        a1DBW:
        return $XGTCF->mEZUN9Z1X6x();
        goto Jv51n;
        AafmB:
        $XGTCF->m7j1OyKKnp8(OHa83BAIlECUz::UPLOADING);
        goto a1DBW;
        UJIhP:
        $XGTCF = new self($uY0L7, $SsHDs);
        goto HTxCq;
        HTxCq:
        $XGTCF->mi4XfGexshW($VxiVW, $SsHDs, $nFXer);
        goto AafmB;
        oXPEX:
        $uY0L7 = App::make(SIHyHN1Z6B4kZ::class)->mDUR5MNOpCD(UkuAPHfTiC1HI::mCDZ3QhKdHV($W0vWP));
        goto UJIhP;
        Jv51n:
    }
    public static function msSCTusTO0s($uY0L7, $WPRCg, $XdRPm, $VxiVW, $EnYUL = false) : self
    {
        goto bnjzG;
        Ztl3L:
        $XGTCF->mi4XfGexshW($VxiVW, $WPRCg, $XdRPm, $EnYUL);
        goto Mpzvg;
        EJvS5:
        return $XGTCF;
        goto BQTsc;
        bnjzG:
        $XGTCF = new self($uY0L7, $WPRCg);
        goto Ztl3L;
        Mpzvg:
        $XGTCF->m7j1OyKKnp8(OHa83BAIlECUz::UPLOADING);
        goto EJvS5;
        BQTsc:
    }
}
