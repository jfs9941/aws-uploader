<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Aws\S3\S3Client;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\Wzdcw9ZdKJxDa;
use Jfs\Uploader\Exception\JEdK4BhMTMGB3;
use Jfs\Uploader\Exception\ECJBTm7ayuLMp;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Jfs\Uploader\Exception\Hb8g7u01z9WXi;
use Webmozart\Assert\Assert;
class OO649rn0rh8ZA implements LDes0oWAHPyua
{
    private $i3lQr;
    private $JZDCA;
    private $BBjq4;
    private $wweWZ;
    public function __construct(Wzdcw9ZdKJxDa $wxGNA, Filesystem $WPRCg, Filesystem $XdRPm, string $VxiVW)
    {
        goto HTtEj;
        fyJAv:
        $this->JZDCA = $WPRCg;
        goto Crz5Y;
        S1bI4:
        $this->wweWZ = $VxiVW;
        goto sqn63;
        HTtEj:
        $this->i3lQr = $wxGNA;
        goto fyJAv;
        Crz5Y:
        $this->BBjq4 = $XdRPm;
        goto S1bI4;
        sqn63:
    }
    public function mWCsuh0MINY()
    {
        goto cneqp;
        PnkVa:
        goto wR1oF;
        goto OD_rz;
        sBL8A:
        $this->i3lQr->mJhZVlPGxoU($Lrr_X);
        goto FxQuT;
        KekM7:
        $d8Dwe = $Yx96r->createMultipartUpload(['Bucket' => $this->wweWZ, 'Key' => $this->i3lQr->getFile()->getLocation(), 'ContentType' => $this->i3lQr->mhr9LcPnRdj()->uUw1e, 'ContentDisposition' => 'inline', 'ACL' => 'public-read']);
        goto zVhSt;
        WeAT6:
        $Yx96r = $this->BBjq4->getClient();
        goto KekM7;
        bjawj:
        $Lrr_X[] = ['index' => $p9FUM, 'url' => (string) $XGTCF->getUri()];
        goto ucZ00;
        cpIXQ:
        if (!($p9FUM <= $wtjf6)) {
            goto f4Ls7;
        }
        goto aE04n;
        Uk49F:
        $Lrr_X = [];
        goto V7CY1;
        V7CY1:
        $wtjf6 = ceil($eiM1z->I_Ajk / $eiM1z->ePSQ2);
        goto WeAT6;
        hOIHP:
        $this->BBjq4->put($this->i3lQr->mwP3lO68q7v(), json_encode($this->i3lQr->mhr9LcPnRdj()->toArray()));
        goto m7EXS;
        EKYYo:
        $p9FUM = 1;
        goto w6Wr1;
        zVhSt:
        if (!(0 === $d8Dwe->count())) {
            goto ABZwr;
        }
        goto M5PoW;
        ucZ00:
        BbBg0:
        goto EaJ9u;
        w6Wr1:
        wR1oF:
        goto cpIXQ;
        aDxbS:
        $XGTCF = $Yx96r->createPresignedRequest($Wa8FN, '+1 day');
        goto bjawj;
        cneqp:
        $eiM1z = $this->i3lQr->mhr9LcPnRdj();
        goto Uk49F;
        OD_rz:
        f4Ls7:
        goto sBL8A;
        aE04n:
        $Wa8FN = $Yx96r->getCommand('UploadPart', ['Bucket' => $this->wweWZ, 'Key' => $this->i3lQr->getFile()->getLocation(), 'UploadId' => $d8Dwe['UploadId'], 'PartNumber' => $p9FUM]);
        goto aDxbS;
        Pupf6:
        $this->JZDCA->put($this->i3lQr->mwP3lO68q7v(), json_encode($this->i3lQr->mhr9LcPnRdj()->toArray()));
        goto hOIHP;
        FxQuT:
        $this->i3lQr->mhr9LcPnRdj()->mCgnkilkBQI($d8Dwe['UploadId']);
        goto Pupf6;
        EaJ9u:
        ++$p9FUM;
        goto PnkVa;
        M5PoW:
        throw new Hb8g7u01z9WXi("Failed to create multipart upload for file {$this->i3lQr->getFile()->getFilename()}, S3 return empty response");
        goto gfBIM;
        gfBIM:
        ABZwr:
        goto EKYYo;
        m7EXS:
    }
    public function mwPLyydlbvG() : void
    {
        goto oBbj4;
        Vbq4d:
        $this->BBjq4->delete($this->i3lQr->mwP3lO68q7v());
        goto xmQvh;
        oBbj4:
        $Yx96r = $this->BBjq4->getClient();
        goto ToyvN;
        ToyvN:
        try {
            $Yx96r->abortMultipartUpload(['Bucket' => $this->wweWZ, 'Key' => $this->i3lQr->getFile()->getLocation(), 'UploadId' => $this->i3lQr->mhr9LcPnRdj()->RbFi9]);
        } catch (\Throwable $iCEwa) {
            throw new JEdK4BhMTMGB3("Failed to abort multipart upload of file {$this->i3lQr->getFile()->getFilename()}", 0, $iCEwa);
        }
        goto Drgd6;
        Drgd6:
        $this->JZDCA->delete($this->i3lQr->mwP3lO68q7v());
        goto Vbq4d;
        xmQvh:
    }
    public function mdnRCqLYYn2() : void
    {
        goto BMmdS;
        OwS73:
        $AXziK = $eiM1z->kFsA4;
        goto KWgQo;
        tT5Mh:
        try {
            $Yx96r->completeMultipartUpload(['Bucket' => $this->wweWZ, 'Key' => $this->i3lQr->getFile()->getLocation(), 'UploadId' => $this->i3lQr->mhr9LcPnRdj()->RbFi9, 'MultipartUpload' => ['Parts' => collect($this->i3lQr->mhr9LcPnRdj()->kFsA4)->sortBy('partNumber')->map(fn($HJ3qr) => ['ETag' => $HJ3qr['eTag'], 'PartNumber' => $HJ3qr['partNumber']])->toArray()]]);
        } catch (\Throwable $iCEwa) {
            throw new ECJBTm7ayuLMp("Failed to merge chunks of file {$this->i3lQr->getFile()->getFilename()}", 0, $iCEwa);
        }
        goto BGQjd;
        BMmdS:
        $eiM1z = $this->i3lQr->mhr9LcPnRdj();
        goto OwS73;
        QP0nA:
        foreach ($h2fq3 as $grwqQ) {
            goto c3h46;
            c3h46:
            $vWQrE = $grwqQ['partNumber'];
            goto tFwkd;
            BtbfP:
            throw new ECJBTm7ayuLMp("Checksum mismatch for part {$vWQrE} of file {$this->i3lQr->getFile()->getFilename()}");
            goto pSVpu;
            tFwkd:
            $HJ3qr = $FvwUA[$vWQrE];
            goto zmuiL;
            pSVpu:
            Tv378:
            goto vJ12S;
            vJ12S:
            t8xSd:
            goto vbV0z;
            zmuiL:
            if (!($HJ3qr['eTag'] !== $grwqQ['eTag'])) {
                goto Tv378;
            }
            goto BtbfP;
            vbV0z:
        }
        goto FRLmD;
        KWgQo:
        $h2fq3 = $eiM1z->l9aY9;
        goto pTWwz;
        RaUL1:
        $Yx96r = $this->BBjq4->getClient();
        goto tT5Mh;
        pTWwz:
        Assert::eq(count($AXziK), count($h2fq3), 'The number of parts and checksums must match.');
        goto Ls1yB;
        FRLmD:
        b0snZ:
        goto RaUL1;
        Ls1yB:
        $FvwUA = collect($AXziK)->keyBy('partNumber');
        goto QP0nA;
        BGQjd:
    }
}
