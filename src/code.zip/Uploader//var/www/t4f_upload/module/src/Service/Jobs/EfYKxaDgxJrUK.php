<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use InvalidArgumentException;
class EfYKxaDgxJrUK
{
    private $UnwFX;
    private $T4LtW;
    public function __construct(int $ObdnX, int $xRw55)
    {
        goto gtjZH;
        YoY8I:
        if (!($xRw55 <= 0)) {
            goto PapMu;
        }
        goto Xl7kK;
        l5nvF:
        $this->T4LtW = $xRw55;
        goto MLujm;
        hXVsz:
        k3W6X:
        goto YoY8I;
        gtjZH:
        if (!($ObdnX <= 0)) {
            goto k3W6X;
        }
        goto QCMP_;
        QCMP_:
        throw new \InvalidArgumentException("Original width must be a positive integer.");
        goto hXVsz;
        L9gfX:
        $this->UnwFX = $ObdnX;
        goto l5nvF;
        OVrcV:
        PapMu:
        goto L9gfX;
        Xl7kK:
        throw new \InvalidArgumentException("Original height must be a positive integer.");
        goto OVrcV;
        MLujm:
    }
    private static function mEI5QAiOTMW($mPbnD, string $yo5Hg = 'floor') : int
    {
        goto oQSdO;
        Ul42d:
        aHdt3:
        goto KO4AN;
        bbrkO:
        return (int) $mPbnD;
        goto tObEN;
        tObEN:
        dgRDU:
        goto k34VO;
        K35QJ:
        vQzaM:
        goto fr0Ue;
        fr0Ue:
        Cm7DD:
        goto Yc7eR;
        oQSdO:
        if (!(is_int($mPbnD) && $mPbnD % 2 === 0)) {
            goto aHdt3;
        }
        goto o3LeI;
        KO4AN:
        if (!(is_float($mPbnD) && $mPbnD == floor($mPbnD) && (int) $mPbnD % 2 === 0)) {
            goto dgRDU;
        }
        goto bbrkO;
        k34VO:
        switch (strtolower($yo5Hg)) {
            case 'ceil':
                return (int) (ceil($mPbnD / 2) * 2);
            case 'round':
                return (int) (round($mPbnD / 2) * 2);
            case 'floor':
            default:
                return (int) (floor($mPbnD / 2) * 2);
        }
        goto K35QJ;
        o3LeI:
        return $mPbnD;
        goto Ul42d;
        Yc7eR:
    }
    public function myOclZtMSgE(string $t26dz = 'floor') : array
    {
        goto IoqEk;
        Z8s6Q:
        if (!($lmPuT < 2)) {
            goto Hl_Yz;
        }
        goto F5ujz;
        nRbl6:
        $vPG8i = $LjNub / $this->UnwFX;
        goto S4ucl;
        GFC9c:
        $LjNub = 2;
        goto F3Snn;
        o2G6Z:
        Hl_Yz:
        goto Zzi9w;
        E7nyi:
        $vPG8i = $lmPuT / $this->T4LtW;
        goto GAGsn;
        nQiaZ:
        KysM1:
        goto Wnqc4;
        F5ujz:
        $lmPuT = 2;
        goto o2G6Z;
        Zzi9w:
        return ['width' => $LjNub, 'height' => $lmPuT];
        goto IcMdU;
        zbSOA:
        ecUFz:
        goto aty6j;
        cutVz:
        $lmPuT = 0;
        goto ofiEU;
        aty6j:
        $lmPuT = $TlLMG;
        goto E7nyi;
        Wnqc4:
        if (!($LjNub < 2)) {
            goto P6TcZ;
        }
        goto GFC9c;
        S4ucl:
        $dIU3U = $this->T4LtW * $vPG8i;
        goto dAwEB;
        e9rjK:
        $LjNub = self::mEI5QAiOTMW(round($NdjFf), $t26dz);
        goto nQiaZ;
        ofiEU:
        if ($this->UnwFX >= $this->T4LtW) {
            goto ecUFz;
        }
        goto N4P44;
        Cuq4h:
        goto KysM1;
        goto zbSOA;
        dAwEB:
        $lmPuT = self::mEI5QAiOTMW(round($dIU3U), $t26dz);
        goto Cuq4h;
        lKdL0:
        $LjNub = 0;
        goto cutVz;
        N4P44:
        $LjNub = $TlLMG;
        goto nRbl6;
        IoqEk:
        $TlLMG = 1080;
        goto lKdL0;
        GAGsn:
        $NdjFf = $this->UnwFX * $vPG8i;
        goto e9rjK;
        F3Snn:
        P6TcZ:
        goto Z8s6Q;
        IcMdU:
    }
}
