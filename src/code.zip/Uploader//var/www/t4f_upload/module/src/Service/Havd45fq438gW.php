<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Jfs\Exposed\SingleUploadInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Core\Observer\L26if4FKAF4YE;
use Jfs\Uploader\Core\Observer\XA7LFlQMeGIUP;
use Jfs\Uploader\Core\J45Rghcw16D6k;
use Jfs\Uploader\Core\FutyevYt174lN;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Jfs\Uploader\Exception\Mg06hAHKyE4EZ;
use Jfs\Uploader\Service\FileResolver\FsqkSkkGdgriL;
use Ramsey\Uuid\Uuid;
final class Havd45fq438gW
{
    private $yInFB;
    private $HO2X0;
    private $bwFb2;
    public function __construct($LdwVh, $skn0D, $dR_xe)
    {
        goto tnVIX;
        SxXOh:
        $this->HO2X0 = $skn0D;
        goto IpseJ;
        tnVIX:
        $this->yInFB = $LdwVh;
        goto SxXOh;
        IpseJ:
        $this->bwFb2 = $dR_xe;
        goto Pb0eG;
        Pb0eG:
    }
    public function md2HYVU09cE($KaRmI)
    {
        goto vmsn6;
        vmsn6:
        if (!$KaRmI instanceof SingleUploadInterface) {
            goto IzMM_;
        }
        goto IaYJl;
        rGHBs:
        return $this->mlZSHfzRyyz($KaRmI['file_extension'], 's3' === $KaRmI['driver'] ? BHGv9oAB1EERw::S3 : BHGv9oAB1EERw::LOCAL);
        goto dDc_C;
        Ot5Zo:
        IzMM_:
        goto rGHBs;
        zbdHS:
        return $this->mlZSHfzRyyz($tTE2f->extension(), BHGv9oAB1EERw::S3, null, $KaRmI->options());
        goto Ot5Zo;
        IaYJl:
        $tTE2f = $KaRmI->getFile();
        goto zbdHS;
        dDc_C:
    }
    public function msGPTTWSAiD(string $G2Ngo)
    {
        goto wgTVc;
        qUMTN:
        $PW_5C->exists = true;
        goto fhJpi;
        d0uI4:
        return $PW_5C;
        goto tJ5fS;
        wgTVc:
        $onOto = config('upload.attachment_model')::findOrFail($G2Ngo);
        goto Krjpr;
        Krjpr:
        $PW_5C = $this->mlZSHfzRyyz($onOto->getAttribute('type'), $onOto->getAttribute('driver'), $onOto->getAttribute('id'));
        goto qUMTN;
        fhJpi:
        $PW_5C->setRawAttributes($onOto->getAttributes());
        goto d0uI4;
        tJ5fS:
    }
    public function moulPsxrnkx(string $cg5gF) : WMocRbcHaGWZG
    {
        goto BML5a;
        UZdW9:
        $h0F7E = json_decode($T8Wb_, true);
        goto fPXOd;
        fPXOd:
        if (!$h0F7E) {
            goto G49Pp;
        }
        goto itOw5;
        Of0L_:
        if ($T8Wb_) {
            goto Z0S1V;
        }
        goto dMuAs;
        dMuAs:
        $T8Wb_ = $this->bwFb2->get($cg5gF);
        goto aPH1d;
        wjijN:
        throw new Esl5ysVUz7oPz('metadata file not found');
        goto VNl6C;
        DFLyT:
        G49Pp:
        goto wjijN;
        KKFE9:
        return $this->mlZSHfzRyyz($gbTNa->SZq6f, $gbTNa->myFHyucaYMH(), $gbTNa->filename);
        goto DFLyT;
        itOw5:
        $gbTNa = FutyevYt174lN::mmVAophsLl6($h0F7E);
        goto KKFE9;
        aPH1d:
        Z0S1V:
        goto UZdW9;
        BML5a:
        $T8Wb_ = $this->HO2X0->get($cg5gF);
        goto Of0L_;
        VNl6C:
    }
    private function mlZSHfzRyyz(string $ueo5N, $rtKyr, ?string $G2Ngo = null, array $TBJiF = [])
    {
        goto KGhYn;
        OLSkZ:
        KcGdY:
        goto moBKs;
        tkmKi:
        throw new Mg06hAHKyE4EZ("not support file type {$ueo5N}");
        goto zF0Vg;
        HIRbQ:
        $GZ8Sl->m383gIl5NHE(new XA7LFlQMeGIUP($GZ8Sl, $this->bwFb2, $TBJiF));
        goto XPadC;
        SOri2:
        switch ($ueo5N) {
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'heic':
                $GZ8Sl = ZrqFFxIRVAAEU::createFromScratch($G2Ngo, $ueo5N);
                goto F6Vef;
            case 'mp4':
            case 'mov':
                $GZ8Sl = UZrSkD9d5TXs1::createFromScratch($G2Ngo, $ueo5N);
                goto F6Vef;
            case 'pdf':
                $GZ8Sl = J45Rghcw16D6k::createFromScratch($G2Ngo, $ueo5N);
                goto F6Vef;
            default:
                throw new Mg06hAHKyE4EZ("not support file type {$ueo5N}");
        }
        goto OLSkZ;
        VteoF:
        PBIQs:
        goto tkmKi;
        KGhYn:
        $G2Ngo = $G2Ngo ?? Uuid::uuid4()->getHex()->toString();
        goto SOri2;
        sn4dE:
        $GZ8Sl->m383gIl5NHE(new L26if4FKAF4YE($GZ8Sl));
        goto HIRbQ;
        moBKs:
        F6Vef:
        goto uBMo0;
        uBMo0:
        $GZ8Sl = $GZ8Sl->mY9sGcgKRNv($rtKyr);
        goto sn4dE;
        XPadC:
        foreach ($this->yInFB as $wrTQA) {
            goto fXsTQ;
            fXsTQ:
            if (!$wrTQA->mTiUdGKTI9s($GZ8Sl)) {
                goto jcyBd;
            }
            goto iqtYc;
            iqtYc:
            return $GZ8Sl->initLocation($wrTQA->mBEFI4EGLt7($GZ8Sl));
            goto T4bIb;
            Gc0LS:
            owhfz:
            goto WA1FD;
            T4bIb:
            jcyBd:
            goto Gc0LS;
            WA1FD:
        }
        goto VteoF;
        zF0Vg:
    }
}
