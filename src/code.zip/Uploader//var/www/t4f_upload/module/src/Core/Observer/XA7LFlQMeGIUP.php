<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Contracts\DcxVJGuKhzqC9;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Core\Strategy\HDpjCubbG4QyD;
use Jfs\Uploader\Core\Strategy\BCNuwPRfay7px;
use Jfs\Uploader\Encoder\DFtX4SxXxkHYz;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Service\I2LnR7hUOOfvy;
final class XA7LFlQMeGIUP implements DcxVJGuKhzqC9
{
    private $k5qUJ;
    private $sMj2E;
    private $bwFb2;
    private $J7w7y;
    public function __construct($PW_5C, $dR_xe, $TBJiF)
    {
        goto EAt3T;
        yBgJ0:
        $this->J7w7y = $TBJiF;
        goto BYra3;
        EAt3T:
        $this->sMj2E = $PW_5C;
        goto AMdHW;
        BYra3:
        $this->k5qUJ = $this->miZUYqYR43q();
        goto VQPU8;
        AMdHW:
        $this->bwFb2 = $dR_xe;
        goto yBgJ0;
        VQPU8:
    }
    public function mg4qJ1AespD($ie1o0, $X021H) : void
    {
        goto iMTOM;
        wseco:
        $this->sMj2E->save();
        goto cTOYw;
        G__q3:
        $this->k5qUJ->process($X021H);
        goto KLMvg;
        KLMvg:
        ikgr_:
        goto rutCO;
        Grk0B:
        $this->sMj2E->save();
        goto f3kCq;
        VMlPT:
        QEyDo:
        goto b7lWf;
        f3kCq:
        if (!$this->k5qUJ) {
            goto eGdg0;
        }
        goto Lv1Sp;
        Lv1Sp:
        $this->k5qUJ->process($X021H);
        goto MnTJo;
        iMTOM:
        if (!(YGB86F7VDD6Xo::PROCESSING === $X021H)) {
            goto QEyDo;
        }
        goto Grk0B;
        MnTJo:
        eGdg0:
        goto VMlPT;
        cTOYw:
        if (!$this->k5qUJ) {
            goto ikgr_;
        }
        goto G__q3;
        b7lWf:
        if (!(YGB86F7VDD6Xo::ENCODING_PROCESSED === $X021H)) {
            goto eQqUu;
        }
        goto wseco;
        rutCO:
        eQqUu:
        goto kk3oQ;
        kk3oQ:
    }
    private function miZUYqYR43q()
    {
        goto ILU_s;
        P2rBz:
        DXtEu:
        goto y7P1u;
        wfqr6:
        W6uZl:
        goto P2rBz;
        ILU_s:
        switch ($this->sMj2E->getType()) {
            case 'image':
                return new HDpjCubbG4QyD($this->sMj2E, $this->J7w7y);
            case 'video':
                return new BCNuwPRfay7px($this->sMj2E, App::make(DFtX4SxXxkHYz::class));
            default:
                return null;
        }
        goto wfqr6;
        y7P1u:
    }
}
