<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class BxOAxkVVSgnJt
{
    private $omQ4D;
    public function __construct(string $eEIhR, int $xPHbl, int $ZaRd_, ?int $Z_vN0, ?int $TPJAc)
    {
        goto wyEH5;
        e62JG:
        if (!($Z_vN0 && $TPJAc)) {
            goto pWFdb;
        }
        goto eBppc;
        eBppc:
        $this->omQ4D['ImageInserter']['InsertableImages'][0]['Width'] = $Z_vN0;
        goto xcRO0;
        qsF3y:
        pWFdb:
        goto LqhQF;
        wyEH5:
        $this->omQ4D = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $xPHbl, 'ImageY' => $ZaRd_, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $eEIhR, 'Opacity' => 35]]]];
        goto e62JG;
        xcRO0:
        $this->omQ4D['ImageInserter']['InsertableImages'][0]['Height'] = $TPJAc;
        goto qsF3y;
        LqhQF:
    }
    public function m8CUk2ds1t3() : array
    {
        return $this->omQ4D;
    }
}
