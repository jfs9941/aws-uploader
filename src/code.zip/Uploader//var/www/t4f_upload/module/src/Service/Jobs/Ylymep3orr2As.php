<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

class Ylymep3orr2As
{
    private $n3RCf;
    private $Nv87Y;
    private $zl2D8;
    private $m1w1p;
    public function __construct($y4Sde, $dQqAo, $VVGKi, $C14In)
    {
        goto UPAor;
        UPAor:
        $this->Nv87Y = $dQqAo;
        goto PX9Pz;
        zc2NE:
        $this->m1w1p = $C14In;
        goto LyVjt;
        PX9Pz:
        $this->zl2D8 = $VVGKi;
        goto zc2NE;
        LyVjt:
        $this->n3RCf = $y4Sde;
        goto IRgI1;
        IRgI1:
    }
    public function mvfd3gqS7YV(?int $Z_vN0, ?int $TPJAc, string $ojOHE, bool $obV2J = false) : string
    {
        goto QSwe9;
        IT0Gi:
        xoH6u:
        goto NcQcr;
        yIbBg:
        return $obV2J ? $PeSCk : $this->zl2D8->url($PeSCk);
        goto PIQfJ;
        XITBR:
        $this->zl2D8->put($PeSCk, $OgE9J->stream('png'));
        goto QttFb;
        x_NOo:
        $NfaR3 = (int) ($Cwyln / 80);
        goto Gpp1G;
        phLIp:
        $OgE9J->text($pyv1g, $Cwyln, (int) $S4ykR, function ($EmwTc) use($sZapk) {
            goto DdBAG;
            XxXV_:
            $EmwTc->align('middle');
            goto QvLbQ;
            Q3L75:
            $EmwTc->valign('middle');
            goto XxXV_;
            DdBAG:
            $EmwTc->file(public_path($this->Nv87Y));
            goto eAYc2;
            eAYc2:
            $uvGmT = (int) ($sZapk * 1.2);
            goto KinMC;
            axPdf:
            $EmwTc->color([185, 185, 185, 1]);
            goto Q3L75;
            KinMC:
            $EmwTc->size(max($uvGmT, 1));
            goto axPdf;
            QvLbQ:
        });
        goto EMiQa;
        oJW9t:
        $Cwyln -= $NfaR3 * 0.4;
        goto IT0Gi;
        YWK2N:
        if (!$this->zl2D8->exists($PeSCk)) {
            goto gMqI4;
        }
        goto yIbBg;
        y5lA2:
        $Cwyln = $Z_vN0 - $NHKb8;
        goto x_NOo;
        NcQcr:
        $S4ykR = $TPJAc - $sZapk - 10;
        goto phLIp;
        EMiQa:
        $this->m1w1p->put($PeSCk, $OgE9J->stream('png'));
        goto XITBR;
        ZIPMz:
        $OgE9J = $this->n3RCf->call($this, $Z_vN0, $TPJAc);
        goto y5lA2;
        QttFb:
        return $obV2J ? $PeSCk : $this->zl2D8->url($PeSCk);
        goto bV1iJ;
        LNAWC:
        if (!($Z_vN0 > 1500)) {
            goto xoH6u;
        }
        goto oJW9t;
        k9cdB:
        $PeSCk = $this->mBZ3zVZ1xyF($pyv1g, $Z_vN0, $TPJAc, $NHKb8, $sZapk);
        goto YWK2N;
        ktFhh:
        throw new \RuntimeException("Zr0izVmbs7QaE dimensions are not available.");
        goto CVXq7;
        Gpp1G:
        $Cwyln -= $NfaR3;
        goto LNAWC;
        QSwe9:
        if (!($Z_vN0 === null || $TPJAc === null)) {
            goto lWPWh;
        }
        goto ktFhh;
        IS3bJ:
        list($sZapk, $NHKb8, $pyv1g) = $this->m9u26wYqnFN($ojOHE, $Z_vN0, $d6Avw, (float) $Z_vN0 / $TPJAc);
        goto k9cdB;
        PIQfJ:
        gMqI4:
        goto ZIPMz;
        aDxj0:
        $d6Avw = 0.1;
        goto IS3bJ;
        CVXq7:
        lWPWh:
        goto aDxj0;
        bV1iJ:
    }
    private function mBZ3zVZ1xyF(string $ojOHE, int $Z_vN0, int $TPJAc, int $PORiT, int $ZfKPF) : string
    {
        $c9Ips = ltrim($ojOHE, '@');
        return "v2/watermark/{$c9Ips}/{$Z_vN0}x{$TPJAc}_{$PORiT}x{$ZfKPF}/text_watermark.png";
    }
    private function m9u26wYqnFN($ojOHE, int $Z_vN0, float $FmeF0, float $U_mGc) : array
    {
        goto ndolp;
        eaQHG:
        return [(int) $OuRHP, $OuRHP * strlen($pyv1g) / 1.8, $pyv1g];
        goto hQZzj;
        ndolp:
        $pyv1g = '@' . $ojOHE;
        goto V60Lf;
        K1hON:
        $OuRHP = $NHKb8 / (strlen($pyv1g) * 0.8);
        goto eaQHG;
        yP4fq:
        return [(int) $OuRHP, $NHKb8, $pyv1g];
        goto NAs6_;
        V60Lf:
        $NHKb8 = (int) ($Z_vN0 * $FmeF0);
        goto LC4ri;
        XKD8i:
        $OuRHP = 1 / $U_mGc * $NHKb8 / strlen($pyv1g);
        goto yP4fq;
        LC4ri:
        if (!($U_mGc > 1)) {
            goto yWwu9;
        }
        goto K1hON;
        hQZzj:
        yWwu9:
        goto XKD8i;
        NAs6_:
    }
}
