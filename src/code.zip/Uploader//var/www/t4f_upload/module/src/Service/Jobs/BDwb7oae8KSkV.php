<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
class BDwb7oae8KSkV implements WatermarkTextJobInterface
{
    private $eE5H8;
    private $iyhKM;
    private $vBgYT;
    private $bwFb2;
    private $HO2X0;
    public function __construct($LCatz, $G4OeZ, $dR_xe, $skn0D, $uO7oT)
    {
        goto agkz5;
        agkz5:
        $this->eE5H8 = $LCatz;
        goto pTOzN;
        SvjQb:
        $this->iyhKM = $G4OeZ;
        goto KpoHE;
        o6iEn:
        $this->vBgYT = $uO7oT;
        goto SvjQb;
        pTOzN:
        $this->bwFb2 = $dR_xe;
        goto gMNev;
        gMNev:
        $this->HO2X0 = $skn0D;
        goto o6iEn;
        KpoHE:
    }
    public function putWatermark(string $G2Ngo, string $nlTkR) : void
    {
        goto cyQoL;
        cyQoL:
        $rV4t7 = microtime(true);
        goto rQONT;
        NGiJi:
        $MDCwv = memory_get_peak_usage();
        goto RLVyM;
        hD_DA:
        try {
            goto KJ5IJ;
            RvQjZ:
            if (chmod($BkP1c, 0664)) {
                goto tLxRG;
            }
            goto m2mIW;
            ZSIz0:
            throw new \Exception('Failed to set final permissions on image file: ' . $BkP1c);
            goto PEuTL;
            PEuTL:
            tLxRG:
            goto kN5DJ;
            KJ5IJ:
            $LjRVY = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
            goto K43Dv;
            m2mIW:
            \Log::warning('Failed to set final permissions on image file: ' . $BkP1c);
            goto ZSIz0;
            K43Dv:
            if ($this->HO2X0->exists($LjRVY->getLocation())) {
                goto CNVm1;
            }
            goto z_Ii_;
            yTIXU:
            $this->mSNjNH9srKO($Qi02l, $nlTkR);
            goto vhVST;
            lTw3z:
            $Qi02l->orient();
            goto yTIXU;
            fxomM:
            unset($Qi02l);
            goto RvQjZ;
            NzNrU:
            $BkP1c = $this->HO2X0->path($LjRVY->getLocation());
            goto doRzy;
            z_Ii_:
            Log::error("ZrqFFxIRVAAEU is not on local, might be deleted before put watermark", ['imageId' => $G2Ngo]);
            goto KsuIb;
            KsuIb:
            return;
            goto x6OmB;
            x6OmB:
            CNVm1:
            goto NzNrU;
            doRzy:
            $Qi02l = $this->eE5H8->call($this, $BkP1c);
            goto lTw3z;
            vhVST:
            $Qi02l->save($BkP1c);
            goto fxomM;
            kN5DJ:
        } catch (\Throwable $JNJ6V) {
            goto pnUTi;
            pnUTi:
            if (!$JNJ6V instanceof ModelNotFoundException) {
                goto nds3x;
            }
            goto STNYI;
            BUQIN:
            nds3x:
            goto uTuDE;
            uTuDE:
            Log::error("ZrqFFxIRVAAEU is not readable", ['imageId' => $G2Ngo, 'error' => $JNJ6V->getMessage()]);
            goto ssSrN;
            STNYI:
            Log::info("ZrqFFxIRVAAEU has been deleted, discard it", ['imageId' => $G2Ngo]);
            goto D0zJK;
            D0zJK:
            return;
            goto BUQIN;
            ssSrN:
        } finally {
            $StTlK = microtime(true);
            $gljc1 = memory_get_usage();
            $eIfFK = memory_get_peak_usage();
            Log::info('put W4termark function resource usage', ['imageId' => $G2Ngo, 'execution_time_sec' => $StTlK - $rV4t7, 'memory_usage_mb' => ($gljc1 - $yxfF3) / 1024 / 1024, 'peak_memory_usage_mb' => ($eIfFK - $MDCwv) / 1024 / 1024]);
        }
        goto RWssw;
        RcOxO:
        ini_set('memory_limit', '-1');
        goto hD_DA;
        rQONT:
        $yxfF3 = memory_get_usage();
        goto NGiJi;
        RLVyM:
        Log::info("Adding watermark text to image", ['imageId' => $G2Ngo]);
        goto RcOxO;
        RWssw:
    }
    private function mSNjNH9srKO($Qi02l, $nlTkR) : void
    {
        goto uK6F7;
        twKTC:
        $T7AAY = $Qi02l->height();
        goto fLtE1;
        okOiH:
        $cK_06 = $h1Fyx->m7FTIyYsGpu($DMzDj, $T7AAY, $nlTkR, true);
        goto DC5Ex;
        uK6F7:
        $DMzDj = $Qi02l->width();
        goto twKTC;
        DC5Ex:
        $this->HO2X0->put($cK_06, $this->bwFb2->get($cK_06));
        goto JjPdm;
        ahMeQ:
        $Qi02l->place($aSxGT, 'top-left', 0, 0, 30);
        goto zaS7i;
        fLtE1:
        $h1Fyx = new GaDEq68fQRF9t($this->iyhKM, $this->vBgYT, $this->bwFb2, $this->HO2X0);
        goto okOiH;
        JjPdm:
        $aSxGT = $this->eE5H8->call($this, $this->HO2X0->path($cK_06));
        goto ahMeQ;
        zaS7i:
    }
}
