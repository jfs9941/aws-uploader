<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Webmozart\Assert\Assert;
class Rz6pax6zBD0VN implements FileProcessingStrategyInterface
{
    private $SnB7q;
    private $q0UvW;
    private $gBXM3;
    public function __construct($qj00p, $qC1gq)
    {
        goto f3nEw;
        f3nEw:
        Assert::isInstanceOf($qj00p, Il0T1UmENcpfh::class);
        goto HSZrY;
        BBIzH:
        $this->q0UvW = $qC1gq;
        goto hMG8y;
        hMG8y:
        $Na0s5 = config('upload.post_process_image');
        goto UPB6q;
        HSZrY:
        $this->SnB7q = $qj00p;
        goto BBIzH;
        UPB6q:
        $this->gBXM3 = new $Na0s5($qj00p, $qC1gq);
        goto KrR0C;
        KrR0C:
    }
    public function process($yO7fM) : void
    {
        $this->gBXM3->process($yO7fM);
    }
}
