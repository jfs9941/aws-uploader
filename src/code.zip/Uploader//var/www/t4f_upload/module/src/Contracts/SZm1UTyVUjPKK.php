<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
interface SZm1UTyVUjPKK
{
    public function resolvePath($pm1yU, int $CIuf5 = ARsVGbfyHQlSz::S3);
    public function resolveThumbnail(TWXq4PCBxnKLl $pm1yU);
    public function resolvePathForHlsVideo(S1qX7zy4Guf94 $A37bW, bool $cMMFb = false);
    public function resolvePathForHlsVideos();
}
