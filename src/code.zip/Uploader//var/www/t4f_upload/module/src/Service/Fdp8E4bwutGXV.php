<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Intervention\Il0T1UmENcpfh\Drivers\Imagick\Driver;
use Intervention\Il0T1UmENcpfh\ImageManager;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Core\Wzdcw9ZdKJxDa;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Exception\D6MBMAoedrGZe;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
use Jfs\Uploader\Exception\Bn3pSnwSmAp3g;
final class Fdp8E4bwutGXV implements UploadServiceInterface
{
    private $yF6WF;
    private $JZDCA;
    private $BBjq4;
    private $pDB1W;
    public function __construct(SIHyHN1Z6B4kZ $yMDGI, Filesystem $WPRCg, Filesystem $XdRPm, string $kMLl9)
    {
        goto Uh0ZX;
        HTWKL:
        $this->BBjq4 = $XdRPm;
        goto DYh7H;
        Uh0ZX:
        $this->yF6WF = $yMDGI;
        goto MlK8H;
        MlK8H:
        $this->JZDCA = $WPRCg;
        goto HTWKL;
        DYh7H:
        $this->pDB1W = $kMLl9;
        goto j5Ynj;
        j5Ynj:
    }
    public function storeSingleFile(SingleUploadInterface $maOLE) : array
    {
        goto yQR_P;
        yQR_P:
        $uY0L7 = $this->yF6WF->mkeTc9p3Urm($maOLE);
        goto h8PTl;
        CFKa7:
        goto B5GhU;
        goto hgJau;
        UjDMe:
        $uY0L7->mySoGGDrYI4(OHa83BAIlECUz::UPLOADED);
        goto XjmEU;
        GC_Nn:
        return $uY0L7->getView();
        goto j2V_I;
        hgJau:
        cMKVS:
        goto UjDMe;
        VqU2q:
        throw new \LogicException('File upload failed, check permissions');
        goto CFKa7;
        XjmEU:
        B5GhU:
        goto GC_Nn;
        h8PTl:
        $Iros8 = $this->BBjq4->putFileAs(dirname($uY0L7->getLocation()), $maOLE->getFile(), $uY0L7->getFilename() . '.' . $uY0L7->getExtension(), ['visibility' => 'public']);
        goto LZlJ2;
        LZlJ2:
        if (false !== $Iros8 && $uY0L7 instanceof PwKw6a6OizPW3) {
            goto cMKVS;
        }
        goto VqU2q;
        j2V_I:
    }
    public function storePreSignedFile(array $sBE3k)
    {
        goto lyDOr;
        De7wh:
        $wxGNA = Wzdcw9ZdKJxDa::msSCTusTO0s($uY0L7, $this->JZDCA, $this->BBjq4, $this->pDB1W, true);
        goto LK6oJ;
        hMEQn:
        $wxGNA->myHKnooDJpw();
        goto O0b4X;
        LK6oJ:
        $wxGNA->mhBaDMVGiz3($sBE3k['mime'], $sBE3k['file_size'], $sBE3k['chunk_size'], $sBE3k['checksums'], $sBE3k['user_id'], $sBE3k['driver']);
        goto hMEQn;
        lyDOr:
        $uY0L7 = $this->yF6WF->mkeTc9p3Urm($sBE3k);
        goto De7wh;
        O0b4X:
        return ['filename' => $wxGNA->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $wxGNA->mBy0KABRl9K()];
        goto jfiej;
        jfiej:
    }
    public function updatePreSignedFile(string $eQxqz, int $xwr38)
    {
        goto yA3Cw;
        FxkBQ:
        Iwbg8:
        goto G3Hpj;
        yA3Cw:
        $wxGNA = Wzdcw9ZdKJxDa::m4EgfhwnPGO($eQxqz, $this->JZDCA, $this->BBjq4, $this->pDB1W);
        goto ZFUXS;
        ZFUXS:
        switch ($xwr38) {
            case OHa83BAIlECUz::UPLOADED:
                $wxGNA->mY9a5qofcf2();
                goto Iwbg8;
            case OHa83BAIlECUz::PROCESSING:
                $wxGNA->mALmUmJIvXf();
                goto Iwbg8;
            case OHa83BAIlECUz::FINISHED:
                $wxGNA->mRkvHAdTDFm();
                goto Iwbg8;
            case OHa83BAIlECUz::ABORTED:
                $wxGNA->moTEbgOnFLa();
                goto Iwbg8;
        }
        goto cNlyI;
        cNlyI:
        kdWSn:
        goto FxkBQ;
        G3Hpj:
    }
    public function completePreSignedFile(string $eQxqz, array $AXziK)
    {
        goto rvYRE;
        BwE1f:
        $wxGNA->mY9a5qofcf2();
        goto EbGk1;
        rvYRE:
        $wxGNA = Wzdcw9ZdKJxDa::m4EgfhwnPGO($eQxqz, $this->JZDCA, $this->BBjq4, $this->pDB1W);
        goto vVmZA;
        EbGk1:
        return ['path' => $wxGNA->getFile()->getView()['path'], 'thumbnail' => $wxGNA->getFile()->Sn2qs, 'id' => $eQxqz];
        goto peJOW;
        vVmZA:
        $wxGNA->mhr9LcPnRdj()->muXlR1o1rJn($AXziK);
        goto BwE1f;
        peJOW:
    }
    public function updateFile(string $eQxqz, int $xwr38) : TkBEwah2ZcKXB
    {
        goto f_Vvm;
        zq4Tb:
        $uY0L7->mySoGGDrYI4($xwr38);
        goto TYYtW;
        f_Vvm:
        $uY0L7 = $this->yF6WF->m0xLLeDOEWW($eQxqz);
        goto zq4Tb;
        TYYtW:
        return $uY0L7;
        goto ZmgLA;
        ZmgLA:
    }
}
