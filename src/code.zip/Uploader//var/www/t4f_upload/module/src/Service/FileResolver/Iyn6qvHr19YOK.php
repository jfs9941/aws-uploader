<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service\FileResolver;

use Jfs\Uploader\Core\TkBEwah2ZcKXB;
interface Iyn6qvHr19YOK
{
    public function mRTY2e8fhE7(TkBEwah2ZcKXB $uY0L7);
    public function mTJiARnNt46(TkBEwah2ZcKXB $uY0L7);
}
