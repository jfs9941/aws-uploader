<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\XTBZ0J08jz6g2;
use Jfs\Uploader\Core\J21tNbgDxO48q;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
trait YVxJaYy0njJEj
{
    private $k4fCM;
    private $hSx9w;
    private $tFpzY;
    public function mdSMfJlo5gi() : string
    {
        return XTBZ0J08jz6g2::mbTTXYu6dUz($this->k4fCM->getFilename());
    }
    public function m4Wida2haiR() : XTBZ0J08jz6g2
    {
        goto nWcGZ;
        RDhpi:
        return $this->hSx9w;
        goto OXHiR;
        nWcGZ:
        if (!(null !== $this->hSx9w)) {
            goto eotW2;
        }
        goto RDhpi;
        OXHiR:
        eotW2:
        goto MacpQ;
        MacpQ:
        $this->mIHtrED3u3o();
        goto fRbXx;
        fRbXx:
        return $this->hSx9w;
        goto gQ9O4;
        gQ9O4:
    }
    private function mIHtrED3u3o() : J21tNbgDxO48q
    {
        goto vy0wr;
        YOEIR:
        $BkWqU = json_decode($Xr8O3, true);
        goto KxKJw;
        KxKJw:
        $this->hSx9w = XTBZ0J08jz6g2::mwslghfePTb($BkWqU);
        goto tR_hK;
        GsZnI:
        throw new VKLvMBsGaTGC2("File {$this->k4fCM->getFilename()} is not PreSigned upload");
        goto o6YT5;
        gzJiT:
        UHgGE:
        goto GsZnI;
        ftDwb:
        if (!$Xr8O3) {
            goto UHgGE;
        }
        goto YOEIR;
        vy0wr:
        $Xr8O3 = $this->tFpzY->get($this->mdSMfJlo5gi());
        goto ftDwb;
        tR_hK:
        return $this;
        goto gzJiT;
        o6YT5:
    }
    public function mgbedfZIwhr($HszXi, $sFjFS, $t16Bz, $vBE45, $HGoYr, $izVKZ = 's3') : void
    {
        $this->hSx9w = XTBZ0J08jz6g2::mF6fOqcw3uQ($this->k4fCM, $HszXi, $sFjFS, $HGoYr, $t16Bz, $vBE45, $izVKZ);
    }
}
