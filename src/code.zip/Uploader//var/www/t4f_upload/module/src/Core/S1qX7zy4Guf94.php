<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\PwKw6a6OizPW3;
use Jfs\Uploader\Contracts\SZm1UTyVUjPKK;
use Jfs\Uploader\Core\Traits\YzdWeu2LiemYK;
use Jfs\Uploader\Core\Traits\PNxZ9iFoUyPar;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
class S1qX7zy4Guf94 extends TWXq4PCBxnKLl implements PwKw6a6OizPW3
{
    use YzdWeu2LiemYK;
    use PNxZ9iFoUyPar;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $mRgNN, string $PavIR) : self
    {
        goto f73rr;
        f73rr:
        $A37bW = new self(['id' => $mRgNN, 'type' => $PavIR, 'status' => OHa83BAIlECUz::UPLOADING]);
        goto ZBCe7;
        ZBCe7:
        $A37bW->m7j1OyKKnp8(OHa83BAIlECUz::UPLOADING);
        goto CaMQI;
        CaMQI:
        return $A37bW;
        goto B__rV;
        B__rV:
    }
    public function width() : ?int
    {
        goto Hq_89;
        rZb7F:
        if (!$bOYNe) {
            goto nJcHl;
        }
        goto GN0Pt;
        mZm8Y:
        return null;
        goto UxPqI;
        GN0Pt:
        return $bOYNe;
        goto jDjER;
        Hq_89:
        $bOYNe = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto rZb7F;
        jDjER:
        nJcHl:
        goto mZm8Y;
        UxPqI:
    }
    public function height() : ?int
    {
        goto CqisT;
        q37iY:
        if (!$tIdzi) {
            goto Bk0xO;
        }
        goto iXyD1;
        iXyD1:
        return $tIdzi;
        goto gvW5s;
        CqisT:
        $tIdzi = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto q37iY;
        MymIy:
        return null;
        goto f8cxk;
        gvW5s:
        Bk0xO:
        goto MymIy;
        f8cxk:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($A37bW) {
            goto HPZR9;
            zuJKw:
            DgMPc:
            goto i5VSX;
            C36nz:
            if (!(!array_key_exists('thumbnail', $D61Mo) && !array_key_exists('hls_path', $D61Mo))) {
                goto DgMPc;
            }
            goto QM8Uv;
            HPZR9:
            $D61Mo = $A37bW->getDirty();
            goto C36nz;
            gRG8W:
            dpmrC:
            goto c9Jhn;
            QM8Uv:
            return;
            goto zuJKw;
            i5VSX:
            if (!($D61Mo['thumbnail'] || $D61Mo['hls_path'])) {
                goto dpmrC;
            }
            goto DjUP0;
            DjUP0:
            S1qX7zy4Guf94::where('parent_id', $A37bW->getAttribute('id'))->update(['thumbnail' => $A37bW->getAttributes()['thumbnail'], 'hls_path' => $A37bW->getAttributes()['hls_path']]);
            goto gRG8W;
            c9Jhn:
        });
    }
    public function mIVzhhvnl0S()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mSKVH7pETKD()
    {
        return $this->getAttribute('id');
    }
    public function mAHS3GrI6kI() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto HYfpM;
        HYfpM:
        $R0E9F = app(SZm1UTyVUjPKK::class);
        goto lYyLJ;
        dxCTg:
        return $LEGKz;
        goto DtWkz;
        anZHb:
        Vb6vL:
        goto KEsRY;
        q3bBh:
        goto Ox_Lv;
        goto anZHb;
        c18am:
        $LEGKz['thumbnail'] = $R0E9F->resolveThumbnail($this);
        goto dxCTg;
        lYyLJ:
        $LEGKz = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $R0E9F->resolvePath($this, $this->getAttribute('driver'))];
        goto IU00q;
        IU00q:
        if ($this->getAttribute('hls_path')) {
            goto Vb6vL;
        }
        goto elwzV;
        KEsRY:
        $LEGKz['player_url'] = $R0E9F->resolvePathForHlsVideo($this, true);
        goto cFoIx;
        elwzV:
        $LEGKz['player_url'] = $R0E9F->resolvePath($this, $this->getAttribute('driver'));
        goto q3bBh;
        cFoIx:
        Ox_Lv:
        goto c18am;
        DtWkz:
    }
    public function getThumbnails()
    {
        goto pxZYS;
        hIZFh:
        $R0E9F = app(SZm1UTyVUjPKK::class);
        goto T0kzr;
        T0kzr:
        return array_map(function ($Pt753) use($R0E9F) {
            return $R0E9F->resolvePath($Pt753);
        }, $QqC2E);
        goto Tnp7s;
        pxZYS:
        $QqC2E = $this->getAttribute('generated_previews') ?? [];
        goto hIZFh;
        Tnp7s:
    }
    public static function mVrTuyKgSgq(TWXq4PCBxnKLl $HRuZr) : S1qX7zy4Guf94
    {
        goto MKbOE;
        BRgXd:
        yFMO8:
        goto b9MWF;
        b9MWF:
        return (new S1qX7zy4Guf94())->fill($HRuZr->getAttributes());
        goto VPeut;
        MKbOE:
        if (!$HRuZr instanceof S1qX7zy4Guf94) {
            goto yFMO8;
        }
        goto MREB0;
        MREB0:
        return $HRuZr;
        goto BRgXd;
        VPeut:
    }
}
