<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Contracts\CKc1zCD1DcxJi;
use Jfs\Uploader\Core\Traits\PwaCHnhQOie1m;
use Jfs\Uploader\Core\Traits\GDAKcbwJFwlZG;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Service\DcscDC5e2bOa2;
class RTkNv5GS7FY9w extends REvUXqyajwths implements XPHcGwVprkaGk
{
    use PwaCHnhQOie1m;
    use GDAKcbwJFwlZG;
    public function getType() : string
    {
        return 'pdf';
    }
    public static function createFromScratch(string $tgQj8, string $gETyy) : self
    {
        goto Iwuf1;
        Iwuf1:
        $vISeL = new self(['id' => $tgQj8, 'type' => $gETyy, 'status' => IoCBJqqLig917::UPLOADING]);
        goto pYqO2;
        aYMLs:
        return $vISeL;
        goto VcBcw;
        pYqO2:
        $vISeL->mN5D2NajOK4(IoCBJqqLig917::UPLOADING);
        goto aYMLs;
        VcBcw:
    }
    public function getView() : array
    {
        $hbSur = app(CKc1zCD1DcxJi::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $hbSur->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $hbSur->resolveThumbnail($this)];
    }
    public static function m4vqZwtjNfc(REvUXqyajwths $vqGuD) : RTkNv5GS7FY9w
    {
        goto UJ8wq;
        UJ8wq:
        if (!$vqGuD instanceof RTkNv5GS7FY9w) {
            goto ZW3Lm;
        }
        goto krDFI;
        we3Ad:
        ZW3Lm:
        goto X2qmC;
        X2qmC:
        return (new RTkNv5GS7FY9w())->fill($vqGuD->getAttributes());
        goto TFvrn;
        krDFI:
        return $vqGuD;
        goto we3Ad;
        TFvrn:
    }
}
