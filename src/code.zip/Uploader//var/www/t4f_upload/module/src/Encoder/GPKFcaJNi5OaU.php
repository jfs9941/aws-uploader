<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use App\Exceptions\MediaConverterException;
use Aws\Exception\AwsException;
use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Support\Facades\Log;
final class GPKFcaJNi5OaU
{
    private $GE2eQ;
    private $yBgiy;
    private $hvChW;
    private $hswtG;
    private $eUhmj;
    private $VepaJ;
    private $IcOhC;
    public function __construct(MediaConvertClient $IfxK8, $ND24h, $l09fx)
    {
        goto pQxAO;
        pQxAO:
        $this->hswtG = $IfxK8;
        goto svyem;
        svyem:
        $this->eUhmj = $ND24h;
        goto PakdY;
        PakdY:
        $this->VepaJ = $l09fx;
        goto CF0eB;
        CF0eB:
    }
    public function mCEIf3GYxXr() : MediaConvertClient
    {
        return $this->hswtG;
    }
    public function mfOFEyD5bTc(NsrFDXbHHex5r $rwDE2) : self
    {
        $this->GE2eQ = $rwDE2;
        return $this;
    }
    public function mpM00sU0QMr(string $K8sA2) : self
    {
        $this->hvChW = $K8sA2;
        return $this;
    }
    public function mEg8CTn2ZIF(DuIqygVrnYyD6 $vWcko) : self
    {
        $this->yBgiy[] = $vWcko;
        return $this;
    }
    public function mMP4uIkcAhq(QcoiOgw1BN3hR $cxd2S) : self
    {
        $this->IcOhC = $cxd2S;
        return $this;
    }
    private function mj5pBvDld0y(bool $R_cjD) : array
    {
        goto xL2mK;
        vEVCv:
        $this->IcOhC = null;
        goto xtlff;
        wflTd:
        $uMN0m = $mlMTf['Settings']['OutputGroups'][0];
        goto kp61N;
        VPLOb:
        $mlMTf['Settings']['OutputGroups'][] = $uMN0m;
        goto oZpu5;
        qZFNP:
        $uMN0m['OutputGroupSettings']['HlsGroupSettings']['Destination'] = $this->hvChW;
        goto VPLOb;
        tlRB4:
        E257B:
        goto awdyj;
        vFnNH:
        LZdYN:
        goto vEVCv;
        IO5wU:
        if ($this->GE2eQ) {
            goto E257B;
        }
        goto sww9C;
        hTYAs:
        BxjVj:
        goto qZFNP;
        tqwDk:
        if (!$R_cjD) {
            goto LZdYN;
        }
        goto p2o5y;
        p2o5y:
        $mlMTf['AccelerationSettings']['Mode'] = 'ENABLED';
        goto vFnNH;
        kp61N:
        unset($mlMTf['Settings']['OutputGroups']);
        goto SL4iM;
        sww9C:
        throw new \LogicException('You must provide a input file to use');
        goto tlRB4;
        SL4iM:
        $uMN0m['Outputs'] = [];
        goto i5i5O;
        jqtMa:
        $mlMTf['Role'] = $this->eUhmj;
        goto gYfBD;
        oZpu5:
        if (!$this->IcOhC) {
            goto zFh9O;
        }
        goto FKQeJ;
        FKQeJ:
        $mlMTf['Settings']['OutputGroups'][] = $this->IcOhC->m1rLQgE527t();
        goto uM5Ks;
        gYfBD:
        $mlMTf['Queue'] = $this->VepaJ;
        goto IO5wU;
        r8HOy:
        $this->yBgiy = [];
        goto srOPO;
        uM5Ks:
        zFh9O:
        goto tqwDk;
        i5i5O:
        foreach ($this->yBgiy as $vWcko) {
            $uMN0m['Outputs'][] = $vWcko->mHdn1PLh1Wl();
            tKvSw:
        }
        goto hTYAs;
        xtlff:
        $this->GE2eQ = null;
        goto r8HOy;
        awdyj:
        $mlMTf['Settings']['Inputs'] = $this->GE2eQ->mfmsCpW5VQ3();
        goto wflTd;
        xL2mK:
        $mlMTf = (require 'template.php');
        goto jqtMa;
        srOPO:
        return $mlMTf;
        goto zi_1o;
        zi_1o:
    }
    public function msMi6BJaUlB(bool $R_cjD = false) : string
    {
        try {
            $x53s1 = $this->hswtG->createJob($this->mj5pBvDld0y($R_cjD));
            return $x53s1->get('Jobs')['Id'];
        } catch (AwsException $uEMU5) {
            Log::error('Error creating MediaConvert job: ' . $uEMU5->getMessage());
            throw new MediaConverterException('Error creating MediaConvert job', 0, $uEMU5);
        }
    }
}
