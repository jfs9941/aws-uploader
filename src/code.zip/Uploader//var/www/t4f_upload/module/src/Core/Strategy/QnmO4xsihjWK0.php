<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Strategy;

use Jfs\Exposed\FileProcessingStrategyInterface;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Encoder\V70xMRa3qU4j9;
class QnmO4xsihjWK0 implements FileProcessingStrategyInterface
{
    private $ySOba;
    private $HFBKU;
    private $yfZae;
    public function __construct(Ezj2tYBlqBPt9 $jTXdP, V70xMRa3qU4j9 $dJkso)
    {
        goto n5ZNJ;
        yw4jH:
        $this->HFBKU = $dJkso;
        goto S8gUO;
        n5ZNJ:
        $this->ySOba = $jTXdP;
        goto yw4jH;
        IOsY1:
        $this->yfZae = new $jWont($jTXdP, $dJkso);
        goto pBSqN;
        S8gUO:
        $jWont = config('upload.post_process_video');
        goto IOsY1;
        pBSqN:
    }
    public function process($nP4E5)
    {
        $this->yfZae->process($nP4E5);
    }
}
