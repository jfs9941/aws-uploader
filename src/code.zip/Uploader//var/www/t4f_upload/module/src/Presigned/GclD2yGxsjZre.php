<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Presigned;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\J21tNbgDxO48q;
use Jfs\Uploader\Exception\UhkliZbDzh8SV;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Symfony\Component\Uid\Uuid;
use Webmozart\Assert\Assert;
class GclD2yGxsjZre implements Rz4POwbUwhVXa
{
    private static $cygJI = 'chunks/';
    private $wUoTe;
    private $m1w1p;
    private $B4orz;
    public function __construct(J21tNbgDxO48q $HGYQh, Filesystem $C14In, Filesystem $NEN4P)
    {
        goto bI0rT;
        kjSqz:
        $this->B4orz = $NEN4P;
        goto u50x5;
        bI0rT:
        $this->wUoTe = $HGYQh;
        goto n2E5C;
        n2E5C:
        $this->m1w1p = $C14In;
        goto kjSqz;
        u50x5:
    }
    public function mcVIq3YSwoT() : void
    {
        goto sYzL0;
        ckpPn:
        if (!($xOJpq <= $JWi5D)) {
            goto Ds4ZO;
        }
        goto qTSbk;
        hbfQR:
        RyiV3:
        goto hxnSZ;
        wfQqy:
        goto VnBIE;
        goto Gaf49;
        sYzL0:
        $ToSwr = $this->wUoTe->m4Wida2haiR();
        goto iu828;
        jUp5p:
        $xOJpq = 1;
        goto ekPwU;
        Gaf49:
        Ds4ZO:
        goto ZM9oS;
        VugCz:
        $this->wUoTe->m4Wida2haiR()->m4KpNugol8f($apWXG);
        goto jUp5p;
        Ge2GA:
        $this->B4orz->put($this->wUoTe->mdSMfJlo5gi(), json_encode($this->wUoTe->m4Wida2haiR()->toArray()));
        goto aF2JG;
        ZM9oS:
        $this->wUoTe->mMvFucyKTZs($msjEK);
        goto Rq8Do;
        iu828:
        $msjEK = [];
        goto jgArL;
        hxnSZ:
        ++$xOJpq;
        goto wfQqy;
        jgArL:
        $JWi5D = ceil($ToSwr->t5_u0 / $ToSwr->D3XQc);
        goto BqFzV;
        ekPwU:
        VnBIE:
        goto ckpPn;
        qTSbk:
        $msjEK[] = ['index' => $xOJpq, 'url' => route('upload.api.local_chunk.upload', ['uploadId' => $apWXG, 'index' => $xOJpq])];
        goto hbfQR;
        Eg2th:
        $this->m1w1p->put($this->wUoTe->mdSMfJlo5gi(), json_encode($this->wUoTe->m4Wida2haiR()->toArray()));
        goto Ge2GA;
        BqFzV:
        $apWXG = Uuid::v4()->toHex();
        goto VugCz;
        Rq8Do:
        $this->wUoTe->m4Wida2haiR()->m4KpNugol8f($apWXG);
        goto Eg2th;
        aF2JG:
    }
    public function mA0bZyHVa8D() : void
    {
        goto nVqCn;
        nVqCn:
        $ToSwr = $this->wUoTe->m4Wida2haiR();
        goto xejOV;
        xejOV:
        $apWXG = $ToSwr->dzUxu;
        goto uB8gq;
        sKu90:
        $this->B4orz->delete($this->wUoTe->mdSMfJlo5gi());
        goto nljZM;
        uB8gq:
        $this->m1w1p->deleteDirectory(self::$cygJI . $apWXG);
        goto sKu90;
        nljZM:
    }
    public function mTEjEDKjwaj() : void
    {
        goto BLo9S;
        csGXq:
        if (!(false === $QD0wy)) {
            goto cd_BM;
        }
        goto SP1Gf;
        txKvw:
        if ($this->m1w1p->exists($wJwV0)) {
            goto Sqrr1;
        }
        goto AsFOi;
        M1LOd:
        Log::warning('Failed to set file permissions for stored video (chunk merge local): ' . $WTzuK);
        goto VexwN;
        U1zgY:
        $jPprZ = $this->m1w1p->path($jmJK9);
        goto vTGxX;
        oFm9G:
        $QD0wy = @fopen($jPprZ, 'wb');
        goto csGXq;
        Jyv_Z:
        $this->m1w1p->deleteDirectory($Dr8Gh);
        goto Xrzt7;
        AvHMi:
        foreach ($HuaaK as $r8LOv) {
            goto E4veB;
            x0xaO:
            throw new UhkliZbDzh8SV('A chunk file not existed: ' . $X_xfC);
            goto fggXr;
            sVwo1:
            $NMsGQ = @fopen($X_xfC, 'rb');
            goto qMcwU;
            qMcwU:
            if (!(false === $NMsGQ)) {
                goto Tngmc;
            }
            goto x0xaO;
            IvtgT:
            throw new UhkliZbDzh8SV('A chunk file content can not copy: ' . $X_xfC);
            goto GVg_X;
            fggXr:
            Tngmc:
            goto s5sQT;
            GVg_X:
            nARz2:
            goto sbwVu;
            s5sQT:
            $YF67e = stream_copy_to_stream($NMsGQ, $QD0wy);
            goto Fkrxz;
            E4veB:
            $X_xfC = $this->m1w1p->path($r8LOv);
            goto sVwo1;
            QGnfa:
            if (!(false === $YF67e)) {
                goto nARz2;
            }
            goto IvtgT;
            sbwVu:
            C7l75:
            goto FRqOx;
            Fkrxz:
            fclose($NMsGQ);
            goto QGnfa;
            FRqOx:
        }
        goto Cmi5c;
        KaSkh:
        $WTzuK = $this->m1w1p->path($jmJK9);
        goto LiKyB;
        tv2Wn:
        $JWi5D = $ToSwr->kIsdK;
        goto KHS3o;
        MOOK_:
        natsort($HuaaK);
        goto dV56B;
        SP1Gf:
        throw new UhkliZbDzh8SV('Local chunk can not merge file (can create file): ' . $jPprZ);
        goto V1JKJ;
        V1JKJ:
        cd_BM:
        goto AvHMi;
        VexwN:
        throw new \Exception('Failed to set file permissions for stored image: ' . $WTzuK);
        goto t3Lpz;
        vTGxX:
        touch($jPprZ);
        goto oFm9G;
        mRB10:
        $jmJK9 = $this->wUoTe->getFile()->getLocation();
        goto yj7Lu;
        t3Lpz:
        Gl0Xc:
        goto Jyv_Z;
        cdI_I:
        Assert::eq(count($HuaaK), $JWi5D, 'The number of parts and checksums must match.');
        goto MOOK_;
        pio6y:
        fclose($QD0wy);
        goto KaSkh;
        AsFOi:
        $this->m1w1p->makeDirectory($wJwV0);
        goto cSDQt;
        cSDQt:
        Sqrr1:
        goto U1zgY;
        yj7Lu:
        $HuaaK = $this->m1w1p->files($Dr8Gh);
        goto cdI_I;
        dV56B:
        $wJwV0 = dirname($jmJK9);
        goto txKvw;
        Cmi5c:
        qKdXF:
        goto pio6y;
        LiKyB:
        if (chmod($WTzuK, 0644)) {
            goto Gl0Xc;
        }
        goto M1LOd;
        KHS3o:
        $Dr8Gh = self::$cygJI . $ToSwr->dzUxu;
        goto mRB10;
        BLo9S:
        $ToSwr = $this->wUoTe->m4Wida2haiR();
        goto tv2Wn;
        Xrzt7:
    }
}
