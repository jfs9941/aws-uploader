<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class N18WZfZRjQqFL
{
    private $faVM1;
    public function __construct(string $weOwm, int $w9rAO, int $SHgX7, ?int $DMzDj, ?int $T7AAY)
    {
        goto LkWjg;
        fGifT:
        if (!($DMzDj && $T7AAY)) {
            goto t9Bv1;
        }
        goto ZDH76;
        scg2b:
        $this->faVM1['ImageInserter']['InsertableImages'][0]['Height'] = $T7AAY;
        goto uDoJP;
        LkWjg:
        $this->faVM1 = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $w9rAO, 'ImageY' => $SHgX7, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $weOwm, 'Opacity' => 35]]]];
        goto fGifT;
        ZDH76:
        $this->faVM1['ImageInserter']['InsertableImages'][0]['Width'] = $DMzDj;
        goto scg2b;
        uDoJP:
        t9Bv1:
        goto D6iaZ;
        D6iaZ:
    }
    public function m4RO3zaJjfm() : array
    {
        return $this->faVM1;
    }
}
