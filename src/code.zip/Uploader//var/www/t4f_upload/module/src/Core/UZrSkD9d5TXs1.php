<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Contracts\YcQilzjlu6PxW;
use Jfs\Uploader\Core\Traits\EBDQZNARW5Gbb;
use Jfs\Uploader\Core\Traits\XoQcBZc9LWj3k;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
class UZrSkD9d5TXs1 extends VWfw9VfxzTDgS implements WMocRbcHaGWZG
{
    use EBDQZNARW5Gbb;
    use XoQcBZc9LWj3k;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $NPlHa, string $VPgya) : self
    {
        goto DH055;
        K4Yoo:
        $KdniT->mcDZhVNLw37(YGB86F7VDD6Xo::UPLOADING);
        goto FvF5j;
        DH055:
        $KdniT = new self(['id' => $NPlHa, 'type' => $VPgya, 'status' => YGB86F7VDD6Xo::UPLOADING]);
        goto K4Yoo;
        FvF5j:
        return $KdniT;
        goto NQT78;
        NQT78:
    }
    public function width() : ?int
    {
        goto okMaW;
        RwGCH:
        return null;
        goto m8jYI;
        DDLyB:
        FYFef:
        goto RwGCH;
        okMaW:
        $DMzDj = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto QqLAM;
        KIkJq:
        return $DMzDj;
        goto DDLyB;
        QqLAM:
        if (!$DMzDj) {
            goto FYFef;
        }
        goto KIkJq;
        m8jYI:
    }
    public function height() : ?int
    {
        goto lJNBv;
        BhwzM:
        return $T7AAY;
        goto jLGed;
        jLGed:
        eK4xV:
        goto AHXss;
        ulqdH:
        if (!$T7AAY) {
            goto eK4xV;
        }
        goto BhwzM;
        lJNBv:
        $T7AAY = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto ulqdH;
        AHXss:
        return null;
        goto tXo7B;
        tXo7B:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($KdniT) {
            goto rGDcZ;
            rGDcZ:
            $QjCUT = $KdniT->getDirty();
            goto rBQgw;
            UcmHS:
            teZE_:
            goto CpQ78;
            jPYix:
            return;
            goto UcmHS;
            fNW_W:
            o4WZ4:
            goto at8xg;
            gQSbo:
            UZrSkD9d5TXs1::where('parent_id', $KdniT->getAttribute('id'))->update(['thumbnail' => $KdniT->getAttributes()['thumbnail'], 'hls_path' => $KdniT->getAttributes()['hls_path']]);
            goto fNW_W;
            rBQgw:
            if (!(!array_key_exists('thumbnail', $QjCUT) && !array_key_exists('hls_path', $QjCUT))) {
                goto teZE_;
            }
            goto jPYix;
            CpQ78:
            if (!($QjCUT['thumbnail'] || $QjCUT['hls_path'])) {
                goto o4WZ4;
            }
            goto gQSbo;
            at8xg:
        });
    }
    public function m1rLQgE527t()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mxhoBpw9TfG()
    {
        return $this->getAttribute('id');
    }
    public function m52GdSNg6eL() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto yLj7P;
        yLj7P:
        $Tz6aF = app(YcQilzjlu6PxW::class);
        goto RtEze;
        Kfpa2:
        sKZ9Y:
        goto jDBq2;
        vLFZ3:
        if ($this->getAttribute('hls_path')) {
            goto sKZ9Y;
        }
        goto ThD7c;
        RtEze:
        $vKG6G = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $Tz6aF->resolvePath($this, $this->getAttribute('driver'))];
        goto vLFZ3;
        jT2i1:
        return $vKG6G;
        goto wYKYN;
        ZnRvC:
        goto XzUux;
        goto Kfpa2;
        VbcB5:
        $vKG6G['thumbnail'] = $Tz6aF->resolveThumbnail($this);
        goto jT2i1;
        jDBq2:
        $vKG6G['player_url'] = $Tz6aF->resolvePathForHlsVideo($this, true);
        goto g1cK8;
        g1cK8:
        XzUux:
        goto VbcB5;
        ThD7c:
        $vKG6G['player_url'] = $Tz6aF->resolvePath($this, $this->getAttribute('driver'));
        goto ZnRvC;
        wYKYN:
    }
    public function getThumbnails()
    {
        goto zl0Bp;
        zl0Bp:
        $j2Oc8 = $this->getAttribute('generated_previews') ?? [];
        goto pxl0r;
        xjeRB:
        return array_map(function ($cxd2S) use($Tz6aF) {
            return $Tz6aF->resolvePath($cxd2S);
        }, $j2Oc8);
        goto WczNN;
        pxl0r:
        $Tz6aF = app(YcQilzjlu6PxW::class);
        goto xjeRB;
        WczNN:
    }
    public static function mcnCcUM8md7(VWfw9VfxzTDgS $iiESX) : UZrSkD9d5TXs1
    {
        goto mCL9H;
        mCL9H:
        if (!$iiESX instanceof UZrSkD9d5TXs1) {
            goto Q8Tmw;
        }
        goto WIojI;
        WIojI:
        return $iiESX;
        goto xrGqr;
        vzhaz:
        return (new UZrSkD9d5TXs1())->fill($iiESX->getAttributes());
        goto AbYoY;
        xrGqr:
        Q8Tmw:
        goto vzhaz;
        AbYoY:
    }
}
