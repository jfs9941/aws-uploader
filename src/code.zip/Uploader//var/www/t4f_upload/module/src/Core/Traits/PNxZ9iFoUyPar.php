<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\TS9H8HOxifnQ6;
use Jfs\Uploader\Enum\OHa83BAIlECUz;
use Jfs\Uploader\Exception\D6MBMAoedrGZe;
trait PNxZ9iFoUyPar
{
    private $Pipdf = [];
    public function m7j1OyKKnp8($RPEIo)
    {
        goto KcRNF;
        KcRNF:
        if ($this instanceof Model) {
            goto kI8Ur;
        }
        goto M4w4Q;
        M4w4Q:
        $this->status = $RPEIo;
        goto jKtfA;
        C3Pj5:
        K_g57:
        goto fY9fa;
        jKtfA:
        goto K_g57;
        goto sfTnS;
        W3bxw:
        $this->setAttribute('status', $RPEIo);
        goto C3Pj5;
        sfTnS:
        kI8Ur:
        goto W3bxw;
        fY9fa:
    }
    public function morh5iJk4Ks()
    {
        goto jt3hq;
        U5RtP:
        JEset:
        goto Zbe9J;
        jt3hq:
        if (!$this instanceof Model) {
            goto JEset;
        }
        goto IYzi6;
        IYzi6:
        return $this->getAttribute('status');
        goto U5RtP;
        Zbe9J:
        return $this->status;
        goto UWZly;
        UWZly:
    }
    public function mySoGGDrYI4($Vzk1z)
    {
        goto a7k3w;
        TunHk:
        $this->setAttribute('status', $Vzk1z);
        goto Nl_XX;
        W0KW_:
        throw D6MBMAoedrGZe::mbCwZ4sBJWF($this->id ?? 'unknown', $this->morh5iJk4Ks(), $Vzk1z);
        goto i0wtC;
        QNWah:
        goto tF8cR;
        goto wvTnn;
        a7k3w:
        if ($this->mexVK9ZDYkX($Vzk1z)) {
            goto smdef;
        }
        goto W0KW_;
        i0wtC:
        smdef:
        goto Gs9du;
        EIGlZ:
        if ($this instanceof Model) {
            goto lIH_9;
        }
        goto vUDas;
        wvTnn:
        lIH_9:
        goto TunHk;
        Nl_XX:
        tF8cR:
        goto xZB1g;
        Gs9du:
        $Kx3PH = $this->morh5iJk4Ks();
        goto EIGlZ;
        xZB1g:
        foreach ($this->Pipdf as $D5vXb) {
            $D5vXb->m2AgYct6sO6($Kx3PH, $Vzk1z);
            Bqf3y:
        }
        goto rPdOl;
        vUDas:
        $this->status = $Vzk1z;
        goto QNWah;
        rPdOl:
        T5AMN:
        goto ACEDs;
        ACEDs:
    }
    public function mexVK9ZDYkX($Vzk1z)
    {
        goto jI2cv;
        jI2cv:
        switch ($this->status) {
            case OHa83BAIlECUz::UPLOADING:
                return OHa83BAIlECUz::UPLOADED == $Vzk1z || OHa83BAIlECUz::UPLOADING == $Vzk1z || OHa83BAIlECUz::ABORTED == $Vzk1z;
            case OHa83BAIlECUz::UPLOADED:
                return OHa83BAIlECUz::PROCESSING == $Vzk1z || OHa83BAIlECUz::DELETED == $Vzk1z;
            case OHa83BAIlECUz::PROCESSING:
                return in_array($Vzk1z, [OHa83BAIlECUz::WATERMARK_PROCESSED, OHa83BAIlECUz::THUMBNAIL_PROCESSED, OHa83BAIlECUz::ENCODING_PROCESSED, OHa83BAIlECUz::ENCODING_ERROR, OHa83BAIlECUz::BLUR_PROCESSED, OHa83BAIlECUz::DELETED, OHa83BAIlECUz::FINISHED, OHa83BAIlECUz::PROCESSING]);
            case OHa83BAIlECUz::FINISHED:
            case OHa83BAIlECUz::ABORTED:
                return OHa83BAIlECUz::DELETED == $Vzk1z;
            case OHa83BAIlECUz::ENCODING_PROCESSED:
                return OHa83BAIlECUz::FINISHED == $Vzk1z || OHa83BAIlECUz::DELETED == $Vzk1z;
            default:
                return false;
        }
        goto Q5lAT;
        t0KP_:
        pA4hm:
        goto I4WeD;
        Q5lAT:
        Utga5:
        goto t0KP_;
        I4WeD:
    }
    public function mdmuA7GRonF(TS9H8HOxifnQ6 $D5vXb)
    {
        $this->Pipdf[] = $D5vXb;
    }
}
