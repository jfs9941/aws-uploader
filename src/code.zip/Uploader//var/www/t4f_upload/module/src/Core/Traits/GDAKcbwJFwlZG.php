<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Illuminate\Database\Eloquent\Model;
use Jfs\Uploader\Contracts\DMLDNHSs7xy9p;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Exception\HHLHHofZj2D7E;
trait GDAKcbwJFwlZG
{
    private $AthYu = [];
    public function mN5D2NajOK4($juM0q)
    {
        goto lfYX7;
        yJqPC:
        $this->setAttribute('status', $juM0q);
        goto awA20;
        j8hwy:
        QwB7S:
        goto yJqPC;
        lfYX7:
        if ($this instanceof Model) {
            goto QwB7S;
        }
        goto gWwdg;
        gWwdg:
        $this->status = $juM0q;
        goto lXQ22;
        awA20:
        xCIhV:
        goto ATFzr;
        lXQ22:
        goto xCIhV;
        goto j8hwy;
        ATFzr:
    }
    public function mDE3ncGQvuQ()
    {
        goto mYmQs;
        mYmQs:
        if (!$this instanceof Model) {
            goto PgQOG;
        }
        goto gK6z1;
        Zf4iH:
        PgQOG:
        goto Fp4UD;
        Fp4UD:
        return $this->status;
        goto YHl4j;
        gK6z1:
        return $this->getAttribute('status');
        goto Zf4iH;
        YHl4j:
    }
    public function mZJDINqUefY($DYYHY)
    {
        goto czHEG;
        Ofk8E:
        nsV7p:
        goto ZAtMS;
        m5jge:
        $this->status = $DYYHY;
        goto iw_hs;
        Yx03i:
        $tjdM9 = $this->mDE3ncGQvuQ();
        goto Q_pHh;
        bz56j:
        sYDm8:
        goto Yx03i;
        R3hiN:
        d9sCo:
        goto jvPqY;
        WPq11:
        throw HHLHHofZj2D7E::movvHZ5tn4l($this->id ?? 'unknown', $this->mDE3ncGQvuQ(), $DYYHY);
        goto bz56j;
        jvPqY:
        $this->setAttribute('status', $DYYHY);
        goto weD3Z;
        czHEG:
        if ($this->mokNyFW0YPU($DYYHY)) {
            goto sYDm8;
        }
        goto WPq11;
        EIBs1:
        foreach ($this->AthYu as $fV5gn) {
            $fV5gn->mCp9vS69WVh($tjdM9, $DYYHY);
            pB9bX:
        }
        goto Ofk8E;
        Q_pHh:
        if ($this instanceof Model) {
            goto d9sCo;
        }
        goto m5jge;
        weD3Z:
        JO8cE:
        goto EIBs1;
        iw_hs:
        goto JO8cE;
        goto R3hiN;
        ZAtMS:
    }
    public function mokNyFW0YPU($DYYHY)
    {
        goto Zyy2B;
        l3a9W:
        OeLzn:
        goto xkDf9;
        Zyy2B:
        switch ($this->status) {
            case IoCBJqqLig917::UPLOADING:
                return IoCBJqqLig917::UPLOADED == $DYYHY || IoCBJqqLig917::UPLOADING == $DYYHY || IoCBJqqLig917::ABORTED == $DYYHY;
            case IoCBJqqLig917::UPLOADED:
                return IoCBJqqLig917::PROCESSING == $DYYHY || IoCBJqqLig917::DELETED == $DYYHY;
            case IoCBJqqLig917::PROCESSING:
                return in_array($DYYHY, [IoCBJqqLig917::WATERMARK_PROCESSED, IoCBJqqLig917::THUMBNAIL_PROCESSED, IoCBJqqLig917::ENCODING_PROCESSED, IoCBJqqLig917::ENCODING_ERROR, IoCBJqqLig917::BLUR_PROCESSED, IoCBJqqLig917::DELETED, IoCBJqqLig917::FINISHED, IoCBJqqLig917::PROCESSING]);
            case IoCBJqqLig917::FINISHED:
            case IoCBJqqLig917::ABORTED:
                return IoCBJqqLig917::DELETED == $DYYHY;
            case IoCBJqqLig917::ENCODING_PROCESSED:
                return IoCBJqqLig917::FINISHED == $DYYHY || IoCBJqqLig917::DELETED == $DYYHY;
            default:
                return false;
        }
        goto AuozF;
        AuozF:
        SXIVo:
        goto l3a9W;
        xkDf9:
    }
    public function mKGeLgXFwuF(DMLDNHSs7xy9p $fV5gn)
    {
        $this->AthYu[] = $fV5gn;
    }
}
