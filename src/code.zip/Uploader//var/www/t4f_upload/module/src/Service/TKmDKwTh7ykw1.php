<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\Sqs\SqsClient;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
final class TKmDKwTh7ykw1 implements VideoPostHandleServiceInterface
{
    private $nl7Zz;
    private $bwFb2;
    public function __construct(UploadServiceInterface $kibPZ, Filesystem $dR_xe)
    {
        $this->nl7Zz = $kibPZ;
        $this->bwFb2 = $dR_xe;
    }
    public function saveMetadata(string $G2Ngo, array $h0F7E)
    {
        goto Pt4TI;
        srB2Y:
        return $KdniT->getView();
        goto lVUQI;
        miQRE:
        VmAGr:
        goto srB2Y;
        Jk_Zu:
        $kutv3['duration'] = $h0F7E['duration'];
        goto WhWLZ;
        vJ30k:
        V2HY2:
        goto IFyOH;
        lVUQI:
        I47HG:
        goto AVhJf;
        AVhJf:
        Log::warning("UZrSkD9d5TXs1 metadata store failed for unknown reason ... " . $G2Ngo);
        goto xP_6G;
        LlzlI:
        $this->nl7Zz->updateFile($KdniT->getAttribute('id'), YGB86F7VDD6Xo::PROCESSING);
        goto miQRE;
        PS1dz:
        yelB0:
        goto jWWgT;
        Wzj6x:
        unset($kutv3['thumbnail']);
        goto b1zFX;
        dgJ1T:
        if (!$KdniT->update($kutv3)) {
            goto I47HG;
        }
        goto cuY_N;
        b1zFX:
        ISfsq:
        goto dgJ1T;
        Pt4TI:
        $KdniT = UZrSkD9d5TXs1::findOrFail($G2Ngo);
        goto z5KTA;
        EQpmK:
        try {
            goto xUp0V;
            xUp0V:
            $cxd2S = $this->nl7Zz->storeSingleFile(new class($h0F7E['thumbnail']) implements SingleUploadInterface
            {
                private $sMj2E;
                public function __construct($PW_5C)
                {
                    $this->sMj2E = $PW_5C;
                }
                public function getFile()
                {
                    return $this->sMj2E;
                }
                public function options()
                {
                    return ['thumbnail' => false, 'watermark' => false, 's3' => true, 'compress' => true];
                }
            });
            goto RHz5l;
            RHz5l:
            $kutv3['thumbnail_id'] = $cxd2S['id'];
            goto qCnii;
            qCnii:
            $kutv3['thumbnail'] = $cxd2S['filename'];
            goto SzP1S;
            SzP1S:
        } catch (\Throwable $uEMU5) {
            Log::warning("UZrSkD9d5TXs1 thumbnail store failed: " . $uEMU5->getMessage());
        }
        goto PS1dz;
        tSFTn:
        $kutv3['fps'] = $h0F7E['fps'];
        goto yUwb5;
        WhWLZ:
        UxxQ5:
        goto voaKP;
        yUwb5:
        mheRk:
        goto IXa1R;
        z5KTA:
        $kutv3 = [];
        goto xozmB;
        voaKP:
        if (!isset($h0F7E['resolution'])) {
            goto V2HY2;
        }
        goto T_qdi;
        xP_6G:
        throw new \Exception("UZrSkD9d5TXs1 metadata store failed for unknown reason ... " . $G2Ngo);
        goto Re4ef;
        xozmB:
        if (!isset($h0F7E['thumbnail'])) {
            goto yelB0;
        }
        goto EQpmK;
        jWWgT:
        if (!isset($h0F7E['duration'])) {
            goto UxxQ5;
        }
        goto Jk_Zu;
        T_qdi:
        $kutv3['resolution'] = $h0F7E['resolution'];
        goto vJ30k;
        IFyOH:
        if (!isset($h0F7E['fps'])) {
            goto mheRk;
        }
        goto tSFTn;
        IXa1R:
        if (!$KdniT->IcOhC) {
            goto ISfsq;
        }
        goto Wzj6x;
        cuY_N:
        if (!(isset($h0F7E['change_status']) && $h0F7E['change_status'])) {
            goto VmAGr;
        }
        goto LlzlI;
        Re4ef:
    }
    public function createThumbnail(string $eE5fW) : void
    {
        goto ACupn;
        f3mWV:
        try {
            goto FCkIh;
            wPmJk:
            $u9r0h->sendMessage(['QueueUrl' => $mV80Z, 'MessageBody' => json_encode(['file_path' => $KdniT->getLocation()])]);
            goto uV7T0;
            NQ4xK:
            $mV80Z = $rs_A5->get('QueueUrl');
            goto wPmJk;
            FCkIh:
            $rs_A5 = $u9r0h->getQueueUrl(['QueueName' => config('upload.thumbnail_lambda_queue')]);
            goto NQ4xK;
            uV7T0:
        } catch (\Throwable $evr4M) {
            \Log::error("Failed to invoke Lambda function for thumbnail generation: {$evr4M->getMessage()}");
        }
        goto vZVld;
        vZVld:
        CMXAo:
        goto U3_FY;
        ACupn:
        Log::info("Use Lambda to generate thumbnail for video: " . $eE5fW);
        goto f9B_R;
        emI4l:
        if (!(!$this->bwFb2->directoryExists($NyCw9) && empty($KdniT->m52GdSNg6eL()))) {
            goto CMXAo;
        }
        goto XDp7K;
        f9B_R:
        $KdniT = UZrSkD9d5TXs1::findOrFail($eE5fW);
        goto v79Fb;
        v79Fb:
        $NyCw9 = "v2/hls/thumbnails/{$eE5fW}/";
        goto emI4l;
        XDp7K:
        $u9r0h = new SqsClient(['region' => config('filesystems.disks.s3.region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.lambda_key'), 'secret' => config('upload.lambda_secret')]]);
        goto f3mWV;
        U3_FY:
    }
    public function mM4WPt3ZUhT(string $eE5fW) : void
    {
        goto ua1cX;
        ipYpN:
        $tNYad = $this->bwFb2->files($NyCw9);
        goto IikUw;
        O36jw:
        Log::error("Message back with success data but not found thumbnail " . $eE5fW);
        goto UaMmR;
        nonx0:
        $KdniT->update(['generated_previews' => $NyCw9]);
        goto Tijtl;
        nws7D:
        if ($this->bwFb2->directoryExists($NyCw9)) {
            goto MgBcI;
        }
        goto O36jw;
        uUSeM:
        Log::error("Message back with success data but not found thumbnail files " . $eE5fW);
        goto IIU8G;
        ua1cX:
        $KdniT = UZrSkD9d5TXs1::findOrFail($eE5fW);
        goto nNODF;
        MnYKp:
        MgBcI:
        goto ipYpN;
        OPKxM:
        xMmKU:
        goto nonx0;
        UaMmR:
        throw new \Exception("Message back with success data but not found thumbnail " . $eE5fW);
        goto MnYKp;
        IIU8G:
        throw new \Exception("Message back with success data but not found thumbnail files " . $eE5fW);
        goto OPKxM;
        nNODF:
        $NyCw9 = "v2/hls/thumbnails/{$eE5fW}/";
        goto nws7D;
        IikUw:
        if (!(count($tNYad) === 0)) {
            goto xMmKU;
        }
        goto uUSeM;
        Tijtl:
    }
    public function getThumbnails(string $eE5fW) : array
    {
        $KdniT = UZrSkD9d5TXs1::findOrFail($eE5fW);
        return $KdniT->getThumbnails();
    }
}
