<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Y4TF32dQUcyCj
{
    private $On0Tm;
    public function __construct(string $bZzHz, int $pvqBm, int $e5HCP, ?int $bOYNe, ?int $tIdzi)
    {
        goto ZYKPP;
        lUstP:
        $this->On0Tm['ImageInserter']['InsertableImages'][0]['Width'] = $bOYNe;
        goto LATDX;
        LATDX:
        $this->On0Tm['ImageInserter']['InsertableImages'][0]['Height'] = $tIdzi;
        goto qN6fC;
        qN6fC:
        cRsyZ:
        goto iamQv;
        pGoYb:
        if (!($bOYNe && $tIdzi)) {
            goto cRsyZ;
        }
        goto lUstP;
        ZYKPP:
        $this->On0Tm = ['ImageInserter' => ['InsertableImages' => [['ImageX' => $pvqBm, 'ImageY' => $e5HCP, 'StartTime' => '00:00:00:00', 'Layer' => 0, 'ImageInserterInput' => $bZzHz, 'Opacity' => 35]]]];
        goto pGoYb;
        iamQv:
    }
    public function mD7gh6R5HJe() : array
    {
        return $this->On0Tm;
    }
}
