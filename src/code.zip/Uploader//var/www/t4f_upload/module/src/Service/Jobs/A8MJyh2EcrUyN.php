<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
class A8MJyh2EcrUyN implements CompressJobInterface
{
    const BhIuA = 60;
    private $eE5H8;
    private $k4mhD;
    public function __construct($LCatz, $ixEuN)
    {
        $this->eE5H8 = $LCatz;
        $this->k4mhD = $ixEuN;
    }
    public function compress(string $G2Ngo)
    {
        goto pC4JO;
        pC4JO:
        $rV4t7 = microtime(true);
        goto uoUXv;
        dILTc:
        try {
            goto zSwiD;
            gYnIA:
            $Z7RS1 = $this->k4mhD->path($LjRVY->getLocation());
            goto KcEy6;
            h6II0:
            unset($Qi02l);
            goto Hpv_A;
            qbzdE:
            $uCmBM = $this->k4mhD->path($LjRVY->getLocation());
            goto Xgbxa;
            Ae8Zt:
            cAlt3:
            goto gYnIA;
            urXCx:
            $LjRVY->save();
            goto Ae8Zt;
            Xgbxa:
            if (!(strtolower($LjRVY->getExtension()) === 'png' || strtolower($LjRVY->getExtension()) === 'heic')) {
                goto cAlt3;
            }
            goto prc73;
            mVtCQ:
            $Qi02l = $this->eE5H8->call($this, $uCmBM);
            goto QuF1Z;
            UhS6_:
            unset($Qi02l);
            goto qTz3r;
            yr6NA:
            $Qi02l->orient()->toJpeg(self::BhIuA)->save($Z7RS1);
            goto UhS6_;
            qTz3r:
            $Z7RS1 = $this->k4mhD->path(str_replace('.jpg', '.webp', $LjRVY->getLocation()));
            goto mVtCQ;
            Zxhgr:
            $LjRVY->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $LjRVY->getLocation()));
            goto urXCx;
            KcEy6:
            $Qi02l = $this->eE5H8->call($this, $uCmBM);
            goto yr6NA;
            prc73:
            $LjRVY->setAttribute('type', 'jpg');
            goto Zxhgr;
            QuF1Z:
            $Qi02l->orient()->toWebp(self::BhIuA)->save($Z7RS1);
            goto h6II0;
            zSwiD:
            $LjRVY = ZrqFFxIRVAAEU::findOrFail($G2Ngo);
            goto qbzdE;
            Hpv_A:
        } catch (ModelNotFoundException) {
            Log::info("ZrqFFxIRVAAEU has been deleted, discard it", ['imageId' => $G2Ngo]);
        } finally {
            $StTlK = microtime(true);
            $gljc1 = memory_get_usage();
            $eIfFK = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $G2Ngo, 'execution_time_sec' => $StTlK - $rV4t7, 'memory_usage_mb' => ($gljc1 - $yxfF3) / 1024 / 1024, 'peak_memory_usage_mb' => ($eIfFK - $MDCwv) / 1024 / 1024]);
        }
        goto xiazh;
        uoUXv:
        $yxfF3 = memory_get_usage();
        goto QQgL3;
        QQgL3:
        $MDCwv = memory_get_peak_usage();
        goto T3M7C;
        T3M7C:
        Log::info("Compress image", ['imageId' => $G2Ngo]);
        goto dILTc;
        xiazh:
    }
}
