<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\IoCBJqqLig917;
class HHLHHofZj2D7E extends \Exception implements FGKmj1d9UP6MC
{
    public function __construct(string $QTUUw = '', int $Tutko = 0, ?\Throwable $JIWq1 = null)
    {
        parent::__construct($QTUUw, $Tutko, $JIWq1);
    }
    public static function movvHZ5tn4l($C3gWL, $H4v0C, $AnSF1)
    {
        $QTUUw = sprintf('File: %s -> Cannot transition from %s to %s', $C3gWL, IoCBJqqLig917::mKoRy32IVGm($H4v0C), IoCBJqqLig917::mKoRy32IVGm($AnSF1));
        return new self($QTUUw);
    }
}
