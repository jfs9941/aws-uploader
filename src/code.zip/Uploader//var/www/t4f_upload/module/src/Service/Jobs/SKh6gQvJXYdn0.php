<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Encoder\O3OTO3HMrAv4G;
use Jfs\Uploader\Encoder\N5z6dHogIzWBr;
use Jfs\Uploader\Encoder\V70xMRa3qU4j9;
use Jfs\Uploader\Encoder\L9UOl9SGHswpz;
use Jfs\Uploader\Encoder\FfVwOVCuREbLJ;
use Jfs\Uploader\Encoder\BxOAxkVVSgnJt;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Uploader\Service\WhtZzd9QpH304;
use Webmozart\Assert\Assert;
class SKh6gQvJXYdn0 implements MediaEncodeJobInterface
{
    private $jXO7P;
    private $m1w1p;
    private $zl2D8;
    private $n3RCf;
    private $Nv87Y;
    public function __construct(string $ysemJ, $C14In, $VVGKi, $y4Sde, $dQqAo)
    {
        goto uB2z1;
        uB2z1:
        $this->jXO7P = $ysemJ;
        goto KseSJ;
        BZw4j:
        $this->Nv87Y = $dQqAo;
        goto G1Ym0;
        HWHxW:
        $this->n3RCf = $y4Sde;
        goto BZw4j;
        qrU9C:
        $this->zl2D8 = $VVGKi;
        goto HWHxW;
        KseSJ:
        $this->m1w1p = $C14In;
        goto qrU9C;
        G1Ym0:
    }
    public function encode(string $C3gWL, string $ojOHE, $Z7DAJ = true) : void
    {
        goto IFq0B;
        DAeA0:
        try {
            goto wOYFq;
            EkhqX:
            if (!($Z_vN0 && $TPJAc)) {
                goto cPHVB;
            }
            goto RzYnY;
            Pgbls:
            Log::info("Set thumbnail for Zr0izVmbs7QaE Job", ['videoId' => $jTXdP->getAttribute('id'), 'duration' => $jTXdP->getAttribute('duration')]);
            goto WWzyn;
            zKD4T:
            $M3Yvb = $this->mO5u2MrgGmt($gL9vu, $TVH5M->mvfd3gqS7YV((int) $XNdWe['width'], (int) $XNdWe['height'], $ojOHE));
            goto MYYRP;
            EyGgd:
            $QuH2G = $QuH2G->moa0T0iXoxB($M3Yvb);
            goto VeE4k;
            ZWL6S:
            $Z_vN0 = $jTXdP->width();
            goto adqJL;
            M9iRn:
            $FvF30->mGO0wMtb4vx($dJkso->mitcdV95FAy($jTXdP));
            goto EkhqX;
            kQkyu:
            bIk0I:
            goto ZWL6S;
            MYYRP:
            if (!$M3Yvb) {
                goto P11k7;
            }
            goto EyGgd;
            M5Lyp:
            $FvF30 = $FvF30->mMkbNpolgvJ($QuH2G);
            goto ZECUU;
            AGWAv:
            $FvF30->mMkbNpolgvJ($AhpA5);
            goto M9iRn;
            hVmK_:
            $TVH5M = new Ylymep3orr2As($this->n3RCf, $this->Nv87Y, $this->zl2D8, $this->m1w1p);
            goto NMMdy;
            w5YGj:
            Assert::isInstanceOf($jTXdP, Zr0izVmbs7QaE::class);
            goto twO89;
            ci6C0:
            $AhpA5 = $AhpA5->moa0T0iXoxB($M3Yvb);
            goto CKCHJ;
            WWzyn:
            $MOwIc = new O3OTO3HMrAv4G($jTXdP->JCIzx ?? 1, 2, $dJkso->mPonn9bA0t8($jTXdP));
            goto TaQxX;
            twO89:
            if (!($jTXdP->dduPi !== YZ2lA0H3k4o6O::S3)) {
                goto bIk0I;
            }
            goto zN2JI;
            uLZ_p:
            $gL9vu = app(WhtZzd9QpH304::class);
            goto hVmK_;
            AhPWj:
            $dJkso = app(V70xMRa3qU4j9::class);
            goto LNV6F;
            adqJL:
            $TPJAc = $jTXdP->height();
            goto e70Up;
            NMMdy:
            $M3Yvb = $this->mO5u2MrgGmt($gL9vu, $TVH5M->mvfd3gqS7YV($jTXdP->width(), $jTXdP->height(), $ojOHE));
            goto pyNV7;
            RzYnY:
            if (!$this->mHFWwqnmIdy($Z_vN0, $TPJAc)) {
                goto vBu3d;
            }
            goto XLaEa;
            ix4wg:
            $FvF30 = app(FfVwOVCuREbLJ::class);
            goto mWLaf;
            zN2JI:
            throw new MediaConverterException("Zr0izVmbs7QaE {$jTXdP->id} is not S3 driver");
            goto kQkyu;
            dOkD7:
            Log::info("Set input video for Job", ['s3Uri' => $m0gkf]);
            goto ix4wg;
            LNV6F:
            $FvF30->mMkbNpolgvJ($AhpA5);
            goto s360p;
            ZECUU:
            vBu3d:
            goto TPsaI;
            wOYFq:
            $jTXdP = Zr0izVmbs7QaE::findOrFail($C3gWL);
            goto w5YGj;
            TPsaI:
            cPHVB:
            goto Pgbls;
            p0ofh:
            $AhpA5 = new N5z6dHogIzWBr('original', $Z_vN0, $TPJAc, $jTXdP->RLktA ?? 30);
            goto AhPWj;
            TaQxX:
            $FvF30 = $FvF30->mTrkRFMsa9r($MOwIc);
            goto kU3ON;
            XLaEa:
            $XNdWe = $this->mLdMjoDnHsA($Z_vN0, $TPJAc);
            goto Z0X0p;
            mWLaf:
            $FvF30 = $FvF30->mPFEq3MzyF6(new L9UOl9SGHswpz($m0gkf));
            goto p0ofh;
            CKCHJ:
            oFD5J:
            goto AGWAv;
            kU3ON:
            $C3gWL = $FvF30->mRfIOlsPLyR($this->mFslLzUhIEA($jTXdP, $Z7DAJ));
            goto PfT7j;
            PfT7j:
            $jTXdP->update(['aws_media_converter_job_id' => $C3gWL]);
            goto sqLM6;
            s360p:
            $FvF30->mGO0wMtb4vx($dJkso->mitcdV95FAy($jTXdP));
            goto uLZ_p;
            e70Up:
            $m0gkf = $this->mo1kyPruDr0($jTXdP);
            goto dOkD7;
            Z0X0p:
            Log::info("Set 1080p resolution for Job", ['width' => $XNdWe['width'], 'height' => $XNdWe['height'], 'originalWidth' => $Z_vN0, 'originalHeight' => $TPJAc]);
            goto JtvzM;
            JtvzM:
            $QuH2G = new N5z6dHogIzWBr('1080p', $XNdWe['width'], $XNdWe['height'], $jTXdP->RLktA ?? 30);
            goto zKD4T;
            VeE4k:
            P11k7:
            goto M5Lyp;
            pyNV7:
            if (!$M3Yvb) {
                goto oFD5J;
            }
            goto ci6C0;
            sqLM6:
        } catch (\Exception $TTMgE) {
            Log::info("Zr0izVmbs7QaE has been deleted, discard it", ['fileId' => $C3gWL, 'err' => $TTMgE->getMessage()]);
            return;
        }
        goto wsJ6M;
        J8_fY:
        ini_set('memory_limit', '-1');
        goto DAeA0;
        IFq0B:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $C3gWL]);
        goto J8_fY;
        wsJ6M:
    }
    private function mFslLzUhIEA(Zr0izVmbs7QaE $jTXdP, $Z7DAJ) : bool
    {
        goto xkc77;
        RLZNc:
        ZkdDl:
        goto wuTAn;
        pEFwU:
        yShBR:
        goto RlB7c;
        ZisFL:
        ILrWs:
        goto RLZNc;
        pG69T:
        return false;
        goto pEFwU;
        RlB7c:
        $pd9Fv = (int) round($jTXdP->getAttribute('duration') ?? 0);
        goto M8yP1;
        xkc77:
        if ($Z7DAJ) {
            goto yShBR;
        }
        goto pG69T;
        M8yP1:
        switch (true) {
            case $jTXdP->width() * $jTXdP->height() >= 1920 * 1080 && $jTXdP->width() * $jTXdP->height() < 2560 * 1440:
                return $pd9Fv > 10 * 60;
            case $jTXdP->width() * $jTXdP->height() >= 2560 * 1440 && $jTXdP->width() * $jTXdP->height() < 3840 * 2160:
                return $pd9Fv > 5 * 60;
            case $jTXdP->width() * $jTXdP->height() >= 3840 * 2160:
                return $pd9Fv > 3 * 60;
            default:
                return false;
        }
        goto ZisFL;
        wuTAn:
    }
    private function mO5u2MrgGmt(WhtZzd9QpH304 $gL9vu, string $Z1XDV) : ?BxOAxkVVSgnJt
    {
        goto wSbSC;
        wSbSC:
        $wzfAD = $gL9vu->m1JgzE5VBur($Z1XDV);
        goto qshD1;
        OpgNZ:
        if (!$wzfAD) {
            goto GBf2y;
        }
        goto NsYqm;
        qshD1:
        Log::info("Resolve watermark for job with url", ['url' => $Z1XDV, 'uri' => $wzfAD]);
        goto OpgNZ;
        xKKap:
        GBf2y:
        goto QeaD8;
        QeaD8:
        return null;
        goto sV6qn;
        NsYqm:
        return new BxOAxkVVSgnJt($wzfAD, 0, 0, null, null);
        goto xKKap;
        sV6qn:
    }
    private function mHFWwqnmIdy(int $Z_vN0, int $TPJAc) : bool
    {
        return $Z_vN0 * $TPJAc > 1.5 * (1920 * 1080);
    }
    private function mLdMjoDnHsA(int $Z_vN0, int $TPJAc) : array
    {
        $AahnE = new HR11vg8ksBmuN($Z_vN0, $TPJAc);
        return $AahnE->mdqDpr44qfj();
    }
    private function mo1kyPruDr0(REvUXqyajwths $vqGuD) : string
    {
        goto ncgrL;
        JFQCV:
        return $this->m1w1p->url($vqGuD->filename);
        goto F0wI9;
        naJte:
        return 's3://' . $this->jXO7P . '/' . $vqGuD->filename;
        goto X0i76;
        X0i76:
        bmS7M:
        goto JFQCV;
        ncgrL:
        if (!($vqGuD->dduPi == YZ2lA0H3k4o6O::S3)) {
            goto bmS7M;
        }
        goto naJte;
        F0wI9:
    }
}
