<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Enum\IoCBJqqLig917;
class KwfSnyH0swhn3 implements GenerateThumbnailJobInterface
{
    const c_n1E = 150;
    const PelEu = 150;
    private $u_yGf;
    private $IXK4e;
    public function __construct($pDQ4h, $ZfrI6)
    {
        $this->u_yGf = $pDQ4h;
        $this->IXK4e = $ZfrI6;
    }
    public function generate(string $C3gWL)
    {
        goto CdXoX;
        OP6zQ:
        ini_set('memory_limit', '-1');
        goto gfKxr;
        gfKxr:
        try {
            goto Qk8vP;
            Qk8vP:
            $C14In = $this->IXK4e;
            goto DUBpi;
            nh0M2:
            $dzQhU = $dzQhU->orient()->resize(150, 150);
            goto dPF1x;
            hFDCB:
            gtjiX:
            goto QEz6r;
            fqtgr:
            $OgE9J->update(['thumbnail' => $PeSCk, 'status' => IoCBJqqLig917::THUMBNAIL_PROCESSED]);
            goto JTosG;
            iU6vF:
            if (chmod($WTzuK, 0644)) {
                goto gtjiX;
            }
            goto e5fTa;
            c_1Tb:
            $mINzf = $C14In->put($PeSCk, $dzQhU->toWebp(70), ['visibility' => 'public']);
            goto efvVG;
            dPF1x:
            $PeSCk = $this->mSCxjEH4neR($OgE9J);
            goto c_1Tb;
            rEJit:
            if (!($mINzf !== false)) {
                goto S5EPl;
            }
            goto fqtgr;
            DUBpi:
            $OgE9J = Yi7VDaCr23YjR::findOrFail($C3gWL);
            goto UmGMd;
            UmGMd:
            $dzQhU = $this->u_yGf->call($this, $C14In->path($OgE9J->getLocation()));
            goto nh0M2;
            efvVG:
            unset($dzQhU);
            goto rEJit;
            QEz6r:
            S5EPl:
            goto M_JSo;
            e5fTa:
            Log::warning('Failed to set file permissions for stored image: ' . $WTzuK);
            goto xtqzR;
            xtqzR:
            throw new \Exception('Failed to set file permissions for stored image: ' . $WTzuK);
            goto hFDCB;
            JTosG:
            $WTzuK = $C14In->path($PeSCk);
            goto iU6vF;
            M_JSo:
        } catch (ModelNotFoundException $BTAgP) {
            Log::info("Yi7VDaCr23YjR has been deleted, discard it", ['imageId' => $C3gWL]);
            return;
        }
        goto j09VM;
        CdXoX:
        Log::info("Generating thumbnail", ['imageId' => $C3gWL]);
        goto OP6zQ;
        j09VM:
    }
    private function mSCxjEH4neR(REvUXqyajwths $OgE9J) : string
    {
        goto Mw5LB;
        IYVju:
        $g4ngK = $jPesJ . '/' . self::c_n1E . 'X' . self::PelEu;
        goto Q9dXQ;
        Mw5LB:
        $PeSCk = $OgE9J->getLocation();
        goto l5Ne5;
        Q9dXQ:
        return $g4ngK . '/' . $OgE9J->getFilename() . '.jpg';
        goto KQFrn;
        l5Ne5:
        $jPesJ = dirname($PeSCk);
        goto IYVju;
        KQFrn:
    }
}
