<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Intervention\ZrqFFxIRVAAEU\Drivers\Imagick\Driver;
use Intervention\ZrqFFxIRVAAEU\ImageManager;
use Jfs\Exposed\SingleUploadInterface;
use Jfs\Exposed\UploadServiceInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Contracts\WMocRbcHaGWZG;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Core\H7OWocYFy30FB;
use Jfs\Uploader\Enum\YGB86F7VDD6Xo;
use Jfs\Uploader\Exception\K5L2YJTJAchO8;
use Jfs\Uploader\Exception\Esl5ysVUz7oPz;
use Jfs\Uploader\Exception\Mg06hAHKyE4EZ;
final class IsiO3rjepI18R implements UploadServiceInterface
{
    private $PSsgo;
    private $HO2X0;
    private $Q3Qp4;
    private $cYXJW;
    public function __construct(Havd45fq438gW $dCll3, Filesystem $skn0D, Filesystem $YS7_M, string $XwqyQ)
    {
        goto Vn4s9;
        F__nv:
        $this->Q3Qp4 = $YS7_M;
        goto asUEm;
        asUEm:
        $this->cYXJW = $XwqyQ;
        goto zYoEq;
        N9IJp:
        $this->HO2X0 = $skn0D;
        goto F__nv;
        Vn4s9:
        $this->PSsgo = $dCll3;
        goto N9IJp;
        zYoEq:
    }
    public function storeSingleFile(SingleUploadInterface $J059v) : array
    {
        goto OzoxI;
        zC0Lb:
        if (false !== $BkP1c && $PW_5C instanceof WMocRbcHaGWZG) {
            goto SsiHI;
        }
        goto xLv3p;
        OzoxI:
        $PW_5C = $this->PSsgo->md2HYVU09cE($J059v);
        goto vKLnS;
        vKLnS:
        $BkP1c = $this->Q3Qp4->putFileAs(dirname($PW_5C->getLocation()), $J059v->getFile(), $PW_5C->getFilename() . '.' . $PW_5C->getExtension(), ['visibility' => 'public']);
        goto zC0Lb;
        jImf5:
        return $PW_5C->getView();
        goto Bk3oj;
        teFuV:
        $PW_5C->mdqb7va7pQ1(YGB86F7VDD6Xo::UPLOADED);
        goto HMzlV;
        h0V68:
        SsiHI:
        goto teFuV;
        HMzlV:
        zv4rn:
        goto jImf5;
        xLv3p:
        throw new \LogicException('File upload failed, check permissions');
        goto cpmPS;
        cpmPS:
        goto zv4rn;
        goto h0V68;
        Bk3oj:
    }
    public function storePreSignedFile(array $EB0Gt)
    {
        goto jb0Go;
        wu0qv:
        return ['filename' => $EljXk->getFile()->getFilename(), 'chunkSize' => config('upload.chunk_size'), 'urls' => $EljXk->mRprE1AmkFe()];
        goto o83m4;
        j1RBm:
        $EljXk->myldP0Gqg0k();
        goto wu0qv;
        jb0Go:
        $PW_5C = $this->PSsgo->md2HYVU09cE($EB0Gt);
        goto pNQBe;
        pNQBe:
        $EljXk = H7OWocYFy30FB::mN0VLS8cESc($PW_5C, $this->HO2X0, $this->Q3Qp4, $this->cYXJW, true);
        goto s_xTy;
        s_xTy:
        $EljXk->mKULcwDJPhc($EB0Gt['mime'], $EB0Gt['file_size'], $EB0Gt['chunk_size'], $EB0Gt['checksums'], $EB0Gt['user_id'], $EB0Gt['driver']);
        goto j1RBm;
        o83m4:
    }
    public function updatePreSignedFile(string $eE5fW, int $mhPfL)
    {
        goto wzGxA;
        EVwUx:
        BN45F:
        goto dVjoM;
        RGPj0:
        switch ($mhPfL) {
            case YGB86F7VDD6Xo::UPLOADED:
                $EljXk->mcornw0X72M();
                goto zpvlJ;
            case YGB86F7VDD6Xo::PROCESSING:
                $EljXk->m7Zxxcrsx6k();
                goto zpvlJ;
            case YGB86F7VDD6Xo::FINISHED:
                $EljXk->mKRsZJhWJtw();
                goto zpvlJ;
            case YGB86F7VDD6Xo::ABORTED:
                $EljXk->mN0zImHtW79();
                goto zpvlJ;
        }
        goto EVwUx;
        dVjoM:
        zpvlJ:
        goto A9GN9;
        wzGxA:
        $EljXk = H7OWocYFy30FB::mkh8EAtAe7X($eE5fW, $this->HO2X0, $this->Q3Qp4, $this->cYXJW);
        goto RGPj0;
        A9GN9:
    }
    public function completePreSignedFile(string $eE5fW, array $haCEo)
    {
        goto uf2G9;
        FPuSt:
        $EljXk->mcornw0X72M();
        goto Qg66C;
        uf2G9:
        $EljXk = H7OWocYFy30FB::mkh8EAtAe7X($eE5fW, $this->HO2X0, $this->Q3Qp4, $this->cYXJW);
        goto GkpvD;
        GkpvD:
        $EljXk->mpti44yUWjH()->mxcBhsFv9un($haCEo);
        goto FPuSt;
        Qg66C:
        return ['path' => $EljXk->getFile()->getView()['path'], 'thumbnail' => $EljXk->getFile()->IcOhC, 'id' => $eE5fW];
        goto d8qLj;
        d8qLj:
    }
    public function updateFile(string $eE5fW, int $mhPfL) : J2nNudRqcfTj1
    {
        goto gYnBm;
        gYnBm:
        $PW_5C = $this->PSsgo->msGPTTWSAiD($eE5fW);
        goto DaMr0;
        sYuIt:
        return $PW_5C;
        goto BACNO;
        DaMr0:
        $PW_5C->mdqb7va7pQ1($mhPfL);
        goto sYuIt;
        BACNO:
    }
}
