<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service;

use Aws\CloudFront\CloudFrontClient;
use Aws\CloudFront\UrlSigner;
use Illuminate\Support\Facades\Storage;
use Jfs\Uploader\Contracts\YcQilzjlu6PxW;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Core\J45Rghcw16D6k;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
final class JHcQzV9ciJhlf implements YcQilzjlu6PxW
{
    private $lMtHm;
    private $v8z13;
    public $PjgMK;
    private $k0uUh;
    private $B4XzK;
    private $k4mhD;
    public function __construct($QKfBx, $AoJl8, $X3Tay, $M1yUH, $Sc7Rx, $ixEuN)
    {
        goto WTxdX;
        WTxdX:
        $this->k4mhD = $ixEuN;
        goto XLgc6;
        HHGat:
        $this->B4XzK = $Sc7Rx;
        goto TJq0s;
        XLgc6:
        $this->lMtHm = $QKfBx;
        goto njI2r;
        yoDWL:
        $this->k0uUh = $M1yUH;
        goto HHGat;
        njI2r:
        $this->v8z13 = $AoJl8;
        goto cxGQf;
        cxGQf:
        $this->PjgMK = $X3Tay;
        goto yoDWL;
        TJq0s:
    }
    public function resolvePath($esNyq, $yarYL = BHGv9oAB1EERw::S3) : string
    {
        goto gbfQg;
        gbfQg:
        if (!$esNyq instanceof VWfw9VfxzTDgS) {
            goto rE3qc;
        }
        goto I8J9t;
        HZ_IG:
        if (!$this->lMtHm) {
            goto BIGpq;
        }
        goto oBscX;
        z8zMs:
        return config('upload.home') . '/' . $esNyq;
        goto BVtEY;
        oBscX:
        return trim($this->PjgMK, '/') . '/' . $esNyq;
        goto h3HHE;
        h3HHE:
        BIGpq:
        goto lZUVv;
        lZUVv:
        return trim($this->v8z13, '/') . '/' . $esNyq;
        goto rVNV0;
        gIZ0H:
        if (!(!empty($this->k0uUh) && !empty($this->B4XzK))) {
            goto fDBst;
        }
        goto lRCER;
        BVtEY:
        Nwt5B:
        goto gIZ0H;
        lRCER:
        return $this->moDTOcWvFJ4($esNyq);
        goto NZRrV;
        oyLVM:
        rE3qc:
        goto cIjyW;
        cIjyW:
        if (!($yarYL === BHGv9oAB1EERw::LOCAL)) {
            goto Nwt5B;
        }
        goto z8zMs;
        NZRrV:
        fDBst:
        goto HZ_IG;
        I8J9t:
        $esNyq = $esNyq->getAttribute('filename');
        goto oyLVM;
        rVNV0:
    }
    public function resolveThumbnail(VWfw9VfxzTDgS $esNyq) : string
    {
        goto XeVZb;
        xoGjW:
        if (!$cxd2S) {
            goto ggNT0;
        }
        goto sBkxa;
        UeEwn:
        Pj4cK:
        goto SaaPf;
        cTGTe:
        return '';
        goto tvS0X;
        sBkxa:
        return $this->url($cxd2S, $esNyq->getAttribute('driver'));
        goto D8e2t;
        tOdz8:
        if (!$esNyq instanceof J45Rghcw16D6k) {
            goto jquOZ;
        }
        goto gcpke;
        lw6fl:
        return $this->resolvePath($Usw5w, $Usw5w->getAttribute('driver'));
        goto UeEwn;
        XeVZb:
        $cxd2S = $esNyq->getAttribute('thumbnail');
        goto xoGjW;
        riFsu:
        if (!$esNyq->getAttribute('thumbnail_id')) {
            goto yqqkt;
        }
        goto aoLkp;
        i8Pvb:
        TlqjP:
        goto tOdz8;
        SaaPf:
        yqqkt:
        goto jlbnA;
        RkDS8:
        jquOZ:
        goto cTGTe;
        gcpke:
        return asset('/img/pdf-preview.svg');
        goto RkDS8;
        vemTH:
        return $this->resolvePath($esNyq, $esNyq->getAttribute('driver'));
        goto i8Pvb;
        a5NoJ:
        if (!$Usw5w) {
            goto Pj4cK;
        }
        goto lw6fl;
        aoLkp:
        $Usw5w = ZrqFFxIRVAAEU::find($esNyq->getAttribute('thumbnail_id'));
        goto a5NoJ;
        D8e2t:
        ggNT0:
        goto riFsu;
        jlbnA:
        if (!$esNyq instanceof ZrqFFxIRVAAEU) {
            goto TlqjP;
        }
        goto vemTH;
        tvS0X:
    }
    private function url($BkP1c, $yarYL)
    {
        goto TZQK_;
        PLRKo:
        return $this->resolvePath($BkP1c);
        goto XmwMZ;
        haoME:
        return config('upload.home') . '/' . $BkP1c;
        goto CKxZv;
        CKxZv:
        QopUY:
        goto PLRKo;
        TZQK_:
        if (!($yarYL == BHGv9oAB1EERw::LOCAL)) {
            goto QopUY;
        }
        goto haoME;
        XmwMZ:
    }
    private function moDTOcWvFJ4($BkP1c)
    {
        goto kzt93;
        phvCf:
        $AUkqA = new UrlSigner($this->k0uUh, $this->k4mhD->path($this->B4XzK));
        goto on2px;
        Lvpf3:
        if (!(strpos($BkP1c, 'm3u8') !== false)) {
            goto F5O04;
        }
        goto wHmKz;
        on2px:
        return $AUkqA->getSignedUrl($this->PjgMK . '/' . $BkP1c, $wrA14);
        goto y0sgV;
        u2sru:
        F5O04:
        goto bG5Gj;
        bG5Gj:
        $wrA14 = now()->addMinutes(60)->timestamp;
        goto phvCf;
        efbzQ:
        throw new \RuntimeException('can not generate presign url for full url path');
        goto TNwiL;
        wHmKz:
        throw new \RuntimeException('can not generate presign url for m3u8 here');
        goto u2sru;
        TNwiL:
        ybURI:
        goto Lvpf3;
        kzt93:
        if (!(strpos($BkP1c, 'https://') === 0)) {
            goto ybURI;
        }
        goto efbzQ;
        y0sgV:
    }
    public function resolvePathForHlsVideo(UZrSkD9d5TXs1 $KdniT, $cbmeZ = false) : string
    {
        goto Cm3cE;
        DpqEd:
        throw new \RuntimeException('can not resolve video not processed yet');
        goto CWK6T;
        vLj_k:
        return $this->PjgMK . '/' . $KdniT->getAttribute('hls_path');
        goto NQNqt;
        CWK6T:
        ME0qm:
        goto vLj_k;
        Cm3cE:
        if ($KdniT->getAttribute('hls_path')) {
            goto ME0qm;
        }
        goto DpqEd;
        NQNqt:
    }
    public function resolvePathForHlsVideos()
    {
        goto c0M4i;
        DeFxs:
        $btW51 = new CloudFrontClient(['version' => 'latest', 'region' => config('filesystems.disks.s3.region')]);
        goto t5lRb;
        c0M4i:
        $wrA14 = now()->addDays(3)->timestamp;
        goto gjFcH;
        oNfcr:
        $ruCMp = json_encode(['Statement' => [['Resource' => sprintf('%s*', $rvn_z), 'Condition' => ['DateLessThan' => ['AWS:EpochTime' => $wrA14]]]]]);
        goto DeFxs;
        gjFcH:
        $rvn_z = $this->PjgMK . '/v2/hls/';
        goto oNfcr;
        W9H4C:
        return [$PSa9p, $wrA14];
        goto MWxgh;
        t5lRb:
        $PSa9p = $btW51->getSignedCookie(['key_pair_id' => $this->k0uUh, 'private_key' => $this->k4mhD->path($this->B4XzK), 'policy' => $ruCMp]);
        goto W9H4C;
        MWxgh:
    }
}
