<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Traits;

use Jfs\Uploader\Core\UkuAPHfTiC1HI;
use Jfs\Uploader\Core\Wzdcw9ZdKJxDa;
use Jfs\Uploader\Exception\NTFGijXrreOP3;
trait AwYRMZN3aMGos
{
    private $d2AB9;
    private $zgTz_;
    private $s4AoW;
    public function mwP3lO68q7v() : string
    {
        return UkuAPHfTiC1HI::mCDZ3QhKdHV($this->d2AB9->getFilename());
    }
    public function mhr9LcPnRdj() : UkuAPHfTiC1HI
    {
        goto tvupq;
        fjQGQ:
        return $this->zgTz_;
        goto whqMK;
        whqMK:
        HYKzY:
        goto o0gSm;
        o0gSm:
        $this->mEZUN9Z1X6x();
        goto duBzF;
        duBzF:
        return $this->zgTz_;
        goto LHXFL;
        tvupq:
        if (!(null !== $this->zgTz_)) {
            goto HYKzY;
        }
        goto fjQGQ;
        LHXFL:
    }
    private function mEZUN9Z1X6x() : Wzdcw9ZdKJxDa
    {
        goto zkU0A;
        LGAVu:
        return $this;
        goto YwRc_;
        bfSJp:
        $Kc1L6 = json_decode($asqqT, true);
        goto Zop3_;
        Zop3_:
        $this->zgTz_ = UkuAPHfTiC1HI::mvDfDvwhHEt($Kc1L6);
        goto LGAVu;
        AaJjL:
        if (!$asqqT) {
            goto y2SIe;
        }
        goto bfSJp;
        CS8AL:
        throw new NTFGijXrreOP3("File {$this->d2AB9->getFilename()} is not PreSigned upload");
        goto z8W4u;
        YwRc_:
        y2SIe:
        goto CS8AL;
        zkU0A:
        $asqqT = $this->s4AoW->get($this->mwP3lO68q7v());
        goto AaJjL;
        z8W4u:
    }
    public function mhBaDMVGiz3($piII1, $UswF4, $l0Zz6, $h2fq3, $dTwzD, $CIuf5 = 's3') : void
    {
        $this->zgTz_ = UkuAPHfTiC1HI::ma2Ky8nMSA9($this->d2AB9, $piII1, $UswF4, $dTwzD, $l0Zz6, $h2fq3, $CIuf5);
    }
}
