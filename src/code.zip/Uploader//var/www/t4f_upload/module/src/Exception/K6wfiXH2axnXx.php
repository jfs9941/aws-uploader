<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class K6wfiXH2axnXx extends \Exception implements XZOQtSniPAkZY
{
    public function __construct(string $E4hPi = '', int $ZAwY1 = 0, ?\Throwable $q8Ah2 = null)
    {
        parent::__construct($E4hPi, $ZAwY1, $q8Ah2);
    }
}
