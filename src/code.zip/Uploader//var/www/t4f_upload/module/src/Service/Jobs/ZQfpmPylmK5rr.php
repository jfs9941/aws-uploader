<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class ZQfpmPylmK5rr implements GenerateThumbnailForVideoInterface
{
    private $grR2P;
    public function __construct($pWO3n)
    {
        $this->grR2P = $pWO3n;
    }
    public function generate(string $W0vWP) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $W0vWP);
        $this->grR2P->createThumbnail($W0vWP);
    }
}
