<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Contracts;

use Jfs\Uploader\Exception\K5L2YJTJAchO8;
interface WMocRbcHaGWZG
{
    public function mcDZhVNLw37($qQ81e);
    public function mxcJpAd2wzt();
    public function mdqb7va7pQ1($Uu5dC);
    public function mKsdt4jxMYg($Uu5dC);
    public function m383gIl5NHE(DcxVJGuKhzqC9 $q77MJ);
}
