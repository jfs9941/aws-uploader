<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\GenerateThumbnailForVideoInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
class DIj80DMouMqdk implements GenerateThumbnailForVideoInterface
{
    private $B3CAq;
    public function __construct($nQx_V)
    {
        $this->B3CAq = $nQx_V;
    }
    public function generate(string $G2Ngo) : void
    {
        Log::info("[JOB] start use Lambda to generate thumbnail for video id: " . $G2Ngo);
        $this->B3CAq->createThumbnail($G2Ngo);
    }
}
