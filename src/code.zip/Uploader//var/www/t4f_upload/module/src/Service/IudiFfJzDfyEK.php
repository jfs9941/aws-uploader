<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
final class IudiFfJzDfyEK
{
    private $wweWZ;
    private $f5viR;
    private $JZDCA;
    public function __construct(string $VxiVW, string $MQR5B, Filesystem $WPRCg)
    {
        goto NtLso;
        rCSoo:
        $this->JZDCA = $WPRCg;
        goto BOu6a;
        C4f5t:
        $this->f5viR = $MQR5B;
        goto rCSoo;
        NtLso:
        $this->wweWZ = $VxiVW;
        goto C4f5t;
        BOu6a:
    }
    public function mRHSJURKFuz(TWXq4PCBxnKLl $HRuZr) : string
    {
        goto jIUuA;
        w6Abs:
        return $this->JZDCA->url($HRuZr->getAttribute('filename'));
        goto YJwmY;
        Q32RG:
        return 's3://' . $this->wweWZ . '/' . $HRuZr->getAttribute('filename');
        goto rRQ9D;
        jIUuA:
        if (!(ARsVGbfyHQlSz::S3 == $HRuZr->getAttribute('driver'))) {
            goto xHhvy;
        }
        goto Q32RG;
        rRQ9D:
        xHhvy:
        goto w6Abs;
        YJwmY:
    }
    public function mwI1qFiQfK7(?string $VgBHb) : ?string
    {
        goto wEVHe;
        m3_qA:
        return null;
        goto D3sNh;
        wEVHe:
        if (!$VgBHb) {
            goto RGu4C;
        }
        goto APi5N;
        xPhn7:
        $Iros8 = parse_url($VgBHb, PHP_URL_PATH);
        goto nwQYr;
        APi5N:
        if (!QB3cU($VgBHb, $this->wweWZ)) {
            goto gewy9;
        }
        goto xPhn7;
        FzA83:
        RGu4C:
        goto m3_qA;
        nwQYr:
        return 's3://' . $this->wweWZ . '/' . ltrim($Iros8, '/');
        goto WpPKP;
        WpPKP:
        gewy9:
        goto FzA83;
        D3sNh:
    }
    public function mAmZg7wUHom(string $Iros8) : string
    {
        return 's3://' . $this->wweWZ . '/' . $Iros8;
    }
}
