<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\CompressJobInterface;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
class JsNljjEaXd4oi implements CompressJobInterface
{
    const bR2jw = 60;
    private $LPCI1;
    private $NBa8l;
    public function __construct($VzMzb, $J2eOE)
    {
        $this->LPCI1 = $VzMzb;
        $this->NBa8l = $J2eOE;
    }
    public function compress(string $W0vWP)
    {
        goto sWK_p;
        L1FTV:
        $ZCkBl = memory_get_usage();
        goto FqhmK;
        AnxFJ:
        try {
            goto SiO29;
            ad_Am:
            unset($XMcRK);
            goto cxoDg;
            D9UuJ:
            $XMcRK = $this->LPCI1->call($this, $B1OUh);
            goto UohoS;
            UohoS:
            $XMcRK->orient()->toWebp(self::bR2jw)->save($KoTTS);
            goto ad_Am;
            JaSnq:
            $KoTTS = $this->NBa8l->path($qj00p->getLocation());
            goto Qqx1K;
            o8VA0:
            $qj00p->setAttribute('filename', str_replace(['.heic', '.png', '.PNG', '.HEIC'], '.jpg', $qj00p->getLocation()));
            goto bwcM1;
            GSopc:
            $XMcRK->orient()->toJpeg(self::bR2jw)->save($KoTTS);
            goto sUvtJ;
            EXFzl:
            $B1OUh = $this->NBa8l->path($qj00p->getLocation());
            goto pyjYT;
            plFKN:
            $qj00p->setAttribute('type', 'jpg');
            goto o8VA0;
            SiO29:
            $qj00p = Il0T1UmENcpfh::findOrFail($W0vWP);
            goto EXFzl;
            Jb33D:
            $KoTTS = $this->NBa8l->path(str_replace('.jpg', '.webp', $qj00p->getLocation()));
            goto D9UuJ;
            pyjYT:
            if (!(strtolower($qj00p->getExtension()) === 'png' || strtolower($qj00p->getExtension()) === 'heic')) {
                goto YcS5A;
            }
            goto plFKN;
            bwcM1:
            $qj00p->save();
            goto uiuuc;
            uiuuc:
            YcS5A:
            goto JaSnq;
            sUvtJ:
            unset($XMcRK);
            goto Jb33D;
            Qqx1K:
            $XMcRK = $this->LPCI1->call($this, $B1OUh);
            goto GSopc;
            cxoDg:
        } catch (ModelNotFoundException) {
            Log::info("Il0T1UmENcpfh has been deleted, discard it", ['imageId' => $W0vWP]);
        } finally {
            $dTAkd = microtime(true);
            $odgxX = memory_get_usage();
            $th8uR = memory_get_peak_usage();
            Log::info('Compress function resource usage', ['imageId' => $W0vWP, 'execution_time_sec' => $dTAkd - $NfAS3, 'memory_usage_mb' => ($odgxX - $ZCkBl) / 1024 / 1024, 'peak_memory_usage_mb' => ($th8uR - $nrOlC) / 1024 / 1024]);
        }
        goto h9BrV;
        sWK_p:
        $NfAS3 = microtime(true);
        goto L1FTV;
        FqhmK:
        $nrOlC = memory_get_peak_usage();
        goto Po2YR;
        Po2YR:
        Log::info("Compress image", ['imageId' => $W0vWP]);
        goto AnxFJ;
        h9BrV:
    }
}
