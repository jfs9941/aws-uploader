<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use ProtoneMedia\LaravelFFMpeg\Support\FFMpeg;
class VmktFTRePkYTG implements PrepareMetadataJobInterface
{
    public function prepareMetadata(string $W0vWP) : void
    {
        goto YY1aY;
        YY1aY:
        $A37bW = S1qX7zy4Guf94::findOrFail($W0vWP);
        goto i62EF;
        qLeR3:
        pcbBr:
        goto LzoB_;
        JDmyf:
        $this->mmKbSf6y9Di($A37bW);
        goto qLeR3;
        i62EF:
        if ($A37bW->width() > 0 && $A37bW->height() > 0) {
            goto pcbBr;
        }
        goto JDmyf;
        LzoB_:
    }
    private function mmKbSf6y9Di(S1qX7zy4Guf94 $ippyD) : void
    {
        goto C3QK7;
        BWPcW:
        $vdzlC = $pm1yU->getVideoStream();
        goto uYwis;
        uYwis:
        $TrsHH = $vdzlC->getDimensions();
        goto zxhqS;
        Ao_sV:
        $pm1yU = FFMpeg::fromDisk($LEGKz['path'])->open($ippyD->getAttribute('filename'));
        goto BWPcW;
        zxhqS:
        $ippyD->update(['duration' => $pm1yU->getDurationInSeconds(), 'resolution' => $TrsHH->getWidth() . 'x' . $TrsHH->getHeight(), 'fps' => $vdzlC->get('r_frame_rate') ?? 30]);
        goto mHH8S;
        C3QK7:
        $LEGKz = $ippyD->getView();
        goto Ao_sV;
        mHH8S:
    }
}
