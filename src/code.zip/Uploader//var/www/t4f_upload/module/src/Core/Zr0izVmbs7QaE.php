<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Contracts\CKc1zCD1DcxJi;
use Jfs\Uploader\Core\Traits\PwaCHnhQOie1m;
use Jfs\Uploader\Core\Traits\GDAKcbwJFwlZG;
use Jfs\Uploader\Enum\IoCBJqqLig917;
class Zr0izVmbs7QaE extends REvUXqyajwths implements XPHcGwVprkaGk
{
    use PwaCHnhQOie1m;
    use GDAKcbwJFwlZG;
    public function getType() : string
    {
        return 'video';
    }
    public static function createFromScratch(string $tgQj8, string $gETyy) : self
    {
        goto WORFl;
        M9Xcn:
        $jTXdP->mN5D2NajOK4(IoCBJqqLig917::UPLOADING);
        goto jzy47;
        jzy47:
        return $jTXdP;
        goto tvGuR;
        WORFl:
        $jTXdP = new self(['id' => $tgQj8, 'type' => $gETyy, 'status' => IoCBJqqLig917::UPLOADING]);
        goto M9Xcn;
        tvGuR:
    }
    public function width() : ?int
    {
        goto Xw0Vx;
        yrZVG:
        s3JwP:
        goto bGps4;
        PQ1mr:
        if (!$Z_vN0) {
            goto s3JwP;
        }
        goto enpuy;
        bGps4:
        return null;
        goto ABdDT;
        Xw0Vx:
        $Z_vN0 = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[0]) : null;
        goto PQ1mr;
        enpuy:
        return $Z_vN0;
        goto yrZVG;
        ABdDT:
    }
    public function height() : ?int
    {
        goto t0OhA;
        t0OhA:
        $TPJAc = $this->getAttribute('resolution') ? intval(explode('x', $this->getAttribute('resolution'))[1]) : null;
        goto bcDbP;
        R2zkp:
        return $TPJAc;
        goto C5PJp;
        MiAha:
        return null;
        goto XxIDO;
        bcDbP:
        if (!$TPJAc) {
            goto mad4Y;
        }
        goto R2zkp;
        C5PJp:
        mad4Y:
        goto MiAha;
        XxIDO:
    }
    protected static function boot()
    {
        parent::boot();
        static::updated(function ($jTXdP) {
            goto x5aw_;
            jDGZC:
            gUo8w:
            goto PFIL7;
            pmE5z:
            quWCX:
            goto htIco;
            x5aw_:
            $ciYee = $jTXdP->getDirty();
            goto Wtc7b;
            PFIL7:
            if (!($ciYee['thumbnail'] || $ciYee['hls_path'])) {
                goto quWCX;
            }
            goto CYv17;
            Wtc7b:
            if (!(!array_key_exists('thumbnail', $ciYee) && !array_key_exists('hls_path', $ciYee))) {
                goto gUo8w;
            }
            goto y1VFU;
            y1VFU:
            return;
            goto jDGZC;
            CYv17:
            Zr0izVmbs7QaE::where('parent_id', $jTXdP->getAttribute('id'))->update(['thumbnail' => $jTXdP->getAttributes()['thumbnail'], 'hls_path' => $jTXdP->getAttributes()['hls_path']]);
            goto pmE5z;
            htIco:
        });
    }
    public function mTglVPctJiG()
    {
        return $this->getAttribute('thumbnail');
    }
    public function mmcpYuK5vmt()
    {
        return $this->getAttribute('id');
    }
    public function mymoRS5eees() : array
    {
        return $this->getAttribute('generated_previews') ?? [];
    }
    public function getView() : array
    {
        goto FChYb;
        XvzDb:
        $hKeR1['player_url'] = $hbSur->resolvePathForHlsVideo($this, true);
        goto DjnoR;
        FChYb:
        $hbSur = app(CKc1zCD1DcxJi::class);
        goto HfHbL;
        vDf8S:
        return $hKeR1;
        goto i9oKL;
        JMVmW:
        JWOYZ:
        goto XvzDb;
        Fx2an:
        if ($this->getAttribute('hls_path')) {
            goto JWOYZ;
        }
        goto BkVoz;
        BkVoz:
        $hKeR1['player_url'] = $hbSur->resolvePath($this, $this->getAttribute('driver'));
        goto g52Ro;
        DjnoR:
        cuQIt:
        goto Bc6BC;
        g52Ro:
        goto cuQIt;
        goto JMVmW;
        Bc6BC:
        $hKeR1['thumbnail'] = $hbSur->resolveThumbnail($this);
        goto vDf8S;
        HfHbL:
        $hKeR1 = ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'video', 'path' => $hbSur->resolvePath($this, $this->getAttribute('driver'))];
        goto Fx2an;
        i9oKL:
    }
    public function getThumbnails()
    {
        goto LGtGB;
        nANoS:
        return array_map(function ($MOwIc) use($hbSur) {
            return $hbSur->resolvePath($MOwIc);
        }, $Y4tez);
        goto b_j0k;
        DCgRl:
        $hbSur = app(CKc1zCD1DcxJi::class);
        goto nANoS;
        LGtGB:
        $Y4tez = $this->getAttribute('generated_previews') ?? [];
        goto DCgRl;
        b_j0k:
    }
    public static function miY3fHXiCQq(REvUXqyajwths $vqGuD) : Zr0izVmbs7QaE
    {
        goto fnhy0;
        uEDwa:
        YYYL_:
        goto yXuLD;
        llzKU:
        return $vqGuD;
        goto uEDwa;
        fnhy0:
        if (!$vqGuD instanceof Zr0izVmbs7QaE) {
            goto YYYL_;
        }
        goto llzKU;
        yXuLD:
        return (new Zr0izVmbs7QaE())->fill($vqGuD->getAttributes());
        goto HBUeN;
        HBUeN:
    }
}
