<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

class SN80ZGs6Yur2B extends \Exception implements FGKmj1d9UP6MC
{
    public function __construct(string $QTUUw = '', int $Tutko = 0, ?\Throwable $JIWq1 = null)
    {
        parent::__construct($QTUUw, $Tutko, $JIWq1);
    }
}
