<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Exception;

use Jfs\Uploader\Enum\OHa83BAIlECUz;
class D6MBMAoedrGZe extends \Exception implements JN6A61N0tXmkh
{
    public function __construct(string $OvcEn = '', int $GXvEb = 0, ?\Throwable $BuOzC = null)
    {
        parent::__construct($OvcEn, $GXvEb, $BuOzC);
    }
    public static function mbCwZ4sBJWF($W0vWP, $HyDUA, $tkQpl)
    {
        $OvcEn = sprintf('File: %s -> Cannot transition from %s to %s', $W0vWP, OHa83BAIlECUz::m8TVzkJYeXb($HyDUA), OHa83BAIlECUz::m8TVzkJYeXb($tkQpl));
        return new self($OvcEn);
    }
}
