<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\App;
use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Contracts\DMLDNHSs7xy9p;
use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Ezj2tYBlqBPt9;
use Jfs\Uploader\Core\Strategy\KB6jHQkxqHKA1;
use Jfs\Uploader\Core\Strategy\QnmO4xsihjWK0;
use Jfs\Uploader\Encoder\V70xMRa3qU4j9;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Service\WhtZzd9QpH304;
final class PksME5sRCOp6p implements DMLDNHSs7xy9p
{
    private $CS9Wx;
    private $k4fCM;
    private $zl2D8;
    private $S85eo;
    public function __construct($m42Ed, $VVGKi, $abuNK)
    {
        goto Xdljq;
        L7PuS:
        $this->S85eo = $abuNK;
        goto nEq_Q;
        nEq_Q:
        $this->CS9Wx = $this->mDtssqWcBBj();
        goto DtzPu;
        oCAz2:
        $this->zl2D8 = $VVGKi;
        goto L7PuS;
        Xdljq:
        $this->k4fCM = $m42Ed;
        goto oCAz2;
        DtzPu:
    }
    public function mCp9vS69WVh($WHuV2, $nQCGg) : void
    {
        goto J9aqg;
        xnTi7:
        $this->k4fCM->save();
        goto SwfoD;
        ADtPT:
        YON6x:
        goto w6CeH;
        SwfoD:
        if (!$this->CS9Wx) {
            goto YON6x;
        }
        goto atVSs;
        w6CeH:
        R8z_S:
        goto b7l2u;
        J9aqg:
        if (!(IoCBJqqLig917::PROCESSING === $nQCGg)) {
            goto qIiV3;
        }
        goto RpI13;
        kmzQC:
        vlZbF:
        goto p28rj;
        K_sMi:
        $this->CS9Wx->process($nQCGg);
        goto kmzQC;
        KvxVB:
        if (!(IoCBJqqLig917::ENCODING_PROCESSED === $nQCGg)) {
            goto R8z_S;
        }
        goto xnTi7;
        RpI13:
        $this->k4fCM->save();
        goto VVecw;
        p28rj:
        qIiV3:
        goto KvxVB;
        atVSs:
        $this->CS9Wx->process($nQCGg);
        goto ADtPT;
        VVecw:
        if (!$this->CS9Wx) {
            goto vlZbF;
        }
        goto K_sMi;
        b7l2u:
    }
    private function mDtssqWcBBj()
    {
        goto VLMka;
        VLMka:
        switch ($this->k4fCM->getType()) {
            case 'image':
                return new KB6jHQkxqHKA1($this->k4fCM, $this->S85eo);
            case 'video':
                return new QnmO4xsihjWK0($this->k4fCM, App::make(V70xMRa3qU4j9::class));
            default:
                return null;
        }
        goto eTxYm;
        xOiUl:
        Cia7Y:
        goto Opk76;
        eTxYm:
        Byo0C:
        goto xOiUl;
        Opk76:
    }
}
