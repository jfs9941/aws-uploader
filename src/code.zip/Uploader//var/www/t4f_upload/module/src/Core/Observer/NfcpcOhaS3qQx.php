<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core\Observer;

use Jfs\Exposed\VideoPostHandleServiceInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Contracts\DMLDNHSs7xy9p;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Exception\HHLHHofZj2D7E;
use Jfs\Uploader\Exception\VKLvMBsGaTGC2;
use Jfs\Uploader\Presigned\GclD2yGxsjZre;
use Jfs\Uploader\Presigned\GnDrYRs76tleM;
final class NfcpcOhaS3qQx implements DMLDNHSs7xy9p
{
    private $pdSJC;
    private $wUoTe;
    private $m1w1p;
    private $B4orz;
    private $jXO7P;
    public function __construct($HGYQh, $C14In, $NEN4P, $ysemJ, $gkdBJ = false)
    {
        goto OsRIy;
        OsRIy:
        $this->wUoTe = $HGYQh;
        goto sDQ2l;
        MZA50:
        $this->mWu0T9aRjMF();
        goto ZTEEN;
        sDQ2l:
        $this->m1w1p = $C14In;
        goto NuqFy;
        ZTEEN:
        VKtk6:
        goto ooDtI;
        OqMu4:
        $this->jXO7P = $ysemJ;
        goto TpiLC;
        TpiLC:
        if ($gkdBJ) {
            goto VKtk6;
        }
        goto MZA50;
        NuqFy:
        $this->B4orz = $NEN4P;
        goto OqMu4;
        ooDtI:
    }
    private function mWu0T9aRjMF() : void
    {
        goto ti4iz;
        ti4iz:
        if (!(null !== $this->pdSJC)) {
            goto G2A6i;
        }
        goto vikEY;
        vV9E3:
        try {
            $ToSwr = $this->wUoTe->m4Wida2haiR();
            $this->pdSJC = 's3' === $ToSwr->dduPi ? new GnDrYRs76tleM($this->wUoTe, $this->m1w1p, $this->B4orz, $this->jXO7P) : new GclD2yGxsjZre($this->wUoTe, $this->m1w1p, $this->B4orz);
        } catch (VKLvMBsGaTGC2 $TTMgE) {
            Log::warning("Failed to set up presigned upload: {$TTMgE->getMessage()}");
        }
        goto LykOC;
        Y4m00:
        G2A6i:
        goto vV9E3;
        vikEY:
        return;
        goto Y4m00;
        LykOC:
    }
    public function mCp9vS69WVh($WHuV2, $nQCGg)
    {
        goto hSMnp;
        JemKg:
        rh_Ve:
        goto aNpXp;
        W1i1v:
        ftL0r:
        goto JemKg;
        hSMnp:
        $this->mWu0T9aRjMF();
        goto LdViJ;
        LdViJ:
        switch ($nQCGg) {
            case IoCBJqqLig917::UPLOADING:
                $this->mhVNo8YHlXg();
                goto rh_Ve;
            case IoCBJqqLig917::UPLOADED:
                $this->mijxqwzulm5();
                goto rh_Ve;
            case IoCBJqqLig917::ABORTED:
                $this->m3J23sZ46Gx();
                goto rh_Ve;
            default:
                goto rh_Ve;
        }
        goto W1i1v;
        aNpXp:
    }
    private function mijxqwzulm5() : void
    {
        goto Yk7uk;
        n280j:
        $m42Ed = $this->wUoTe->getFile();
        goto rEud7;
        s6njy:
        tUFO9:
        goto BuCFO;
        qjiX6:
        app(VideoPostHandleServiceInterface::class)->createThumbnail($m42Ed->id);
        goto s6njy;
        rEud7:
        $m42Ed->mZJDINqUefY(IoCBJqqLig917::UPLOADED);
        goto FWSin;
        Yk7uk:
        $this->pdSJC->mTEjEDKjwaj();
        goto n280j;
        FWSin:
        if (!$m42Ed instanceof Zr0izVmbs7QaE) {
            goto tUFO9;
        }
        goto qjiX6;
        BuCFO:
    }
    private function m3J23sZ46Gx() : void
    {
        $this->pdSJC->mA0bZyHVa8D();
    }
    private function mhVNo8YHlXg() : void
    {
        $this->pdSJC->mcVIq3YSwoT();
    }
}
