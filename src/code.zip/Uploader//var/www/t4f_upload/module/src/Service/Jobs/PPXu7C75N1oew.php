<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\J2nNudRqcfTj1;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
class PPXu7C75N1oew implements BlurVideoJobInterface
{
    const nghoA = 15;
    const K6RHg = 500;
    const r36cV = 500;
    private $eE5H8;
    private $bwFb2;
    private $k4mhD;
    public function __construct($LCatz, $dR_xe, $ixEuN)
    {
        goto Yx_R5;
        Yx_R5:
        $this->k4mhD = $ixEuN;
        goto aNF_W;
        aNF_W:
        $this->bwFb2 = $dR_xe;
        goto TJDhR;
        TJDhR:
        $this->eE5H8 = $LCatz;
        goto Yj0g3;
        Yj0g3:
    }
    public function blur(string $G2Ngo) : void
    {
        goto KqyZw;
        WJUvM:
        $F1HbZ = $this->k4mhD->path($t0jU5);
        goto jtd0U;
        ogaVG:
        $n0WvN = UZrSkD9d5TXs1::findOrFail($G2Ngo);
        goto mdJxb;
        HFVJ4:
        $t0jU5 = $this->mgToDiXc5QE($n0WvN);
        goto WJUvM;
        q4mLD:
        $LjRVY->resize(self::K6RHg, self::r36cV / $HiRXD);
        goto Fj4W1;
        jROdU:
        $HiRXD = $LjRVY->width() / $LjRVY->height();
        goto q4mLD;
        RVors:
        $this->k4mhD->put($n0WvN->getAttribute('thumbnail'), $this->bwFb2->get($n0WvN->getAttribute('thumbnail')));
        goto VUbLN;
        KqyZw:
        Log::info("Blurring for video", ['videoID' => $G2Ngo]);
        goto t2m8Y;
        VUbLN:
        $LjRVY = $this->eE5H8->call($this, $this->k4mhD->path($n0WvN->getAttribute('thumbnail')));
        goto jROdU;
        Fj4W1:
        $LjRVY->blur(self::nghoA);
        goto HFVJ4;
        mdJxb:
        if (!$n0WvN->getAttribute('thumbnail')) {
            goto LxrkS;
        }
        goto RVors;
        sgbTZ:
        $this->bwFb2->put($t0jU5, $this->k4mhD->get($t0jU5));
        goto l2WbN;
        l2WbN:
        unset($LjRVY);
        goto zwnhG;
        t2m8Y:
        ini_set('memory_limit', '-1');
        goto ogaVG;
        jtd0U:
        $LjRVY->save($F1HbZ);
        goto sgbTZ;
        Vczfo:
        $n0WvN->update(['preview' => $t0jU5]);
        goto Nn9nJ;
        Nn9nJ:
        LxrkS:
        goto UIDaN;
        aUvmh:
        throw new \Exception('Failed to set final permissions on image file: ' . $F1HbZ);
        goto ltVWO;
        HIv3m:
        \Log::warning('Failed to set final permissions on image file: ' . $F1HbZ);
        goto aUvmh;
        zwnhG:
        if (chmod($F1HbZ, 0664)) {
            goto VSTaQ;
        }
        goto HIv3m;
        ltVWO:
        VSTaQ:
        goto Vczfo;
        UIDaN:
    }
    private function mgToDiXc5QE(J2nNudRqcfTj1 $yfl0I) : string
    {
        goto ii7Pq;
        LUUCf:
        if ($this->k4mhD->exists($oYMhx)) {
            goto trjSh;
        }
        goto JL6PC;
        RmwE5:
        $oYMhx = dirname($BkP1c) . '/preview/';
        goto LUUCf;
        ii7Pq:
        $BkP1c = $yfl0I->getLocation();
        goto RmwE5;
        JL6PC:
        $this->k4mhD->makeDirectory($oYMhx, 0755, true);
        goto iIUM3;
        iIUM3:
        trjSh:
        goto IRlvI;
        IRlvI:
        return $oYMhx . $yfl0I->getFilename() . '.jpg';
        goto Nq7jE;
        Nq7jE:
    }
}
