<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

class Zct70JWnrBlBs
{
    private $Sn2qs;
    public function __construct(float $WPdu6, int $Z0flY, string $gzv5N)
    {
        goto byUGr;
        byUGr:
        $G2uu_ = (int) $WPdu6 / $Z0flY;
        goto Z_DDn;
        eRILs:
        $this->Sn2qs = ['CustomName' => 'thumbnail', 'Name' => 'File Group', 'Outputs' => [['ContainerSettings' => ['Container' => 'RAW'], 'VideoDescription' => ['CodecSettings' => ['Codec' => 'FRAME_CAPTURE', 'FrameCaptureSettings' => ['FramerateNumerator' => 1, 'FramerateDenominator' => $G2uu_]]], 'Extension' => '.jpg']], 'OutputGroupSettings' => ['Type' => 'FILE_GROUP_SETTINGS', 'FileGroupSettings' => ['Destination' => $gzv5N]]];
        goto F_fv3;
        Z_DDn:
        $G2uu_ = max($G2uu_, 1);
        goto eRILs;
        F_fv3:
    }
    public function mIVzhhvnl0S() : array
    {
        return $this->Sn2qs;
    }
}
