<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Core;

use Jfs\Uploader\Contracts\XPHcGwVprkaGk;
use Jfs\Uploader\Contracts\CKc1zCD1DcxJi;
use Jfs\Uploader\Core\Traits\PwaCHnhQOie1m;
use Jfs\Uploader\Core\Traits\GDAKcbwJFwlZG;
use Jfs\Uploader\Enum\IoCBJqqLig917;
use Jfs\Uploader\Service\DcscDC5e2bOa2;
class Yi7VDaCr23YjR extends REvUXqyajwths implements XPHcGwVprkaGk
{
    use PwaCHnhQOie1m;
    use GDAKcbwJFwlZG;
    public function getType() : string
    {
        return 'image';
    }
    public static function createFromScratch(string $tgQj8, string $gETyy) : self
    {
        goto XSix1;
        XSix1:
        $OgE9J = new self(['id' => $tgQj8, 'type' => $gETyy, 'status' => IoCBJqqLig917::UPLOADING]);
        goto c9tyE;
        c9tyE:
        $OgE9J->mN5D2NajOK4(IoCBJqqLig917::UPLOADING);
        goto x1p4t;
        x1p4t:
        return $OgE9J;
        goto zhFBp;
        zhFBp:
    }
    public function getView() : array
    {
        $hbSur = app(CKc1zCD1DcxJi::class);
        return ['id' => $this->getAttribute('id'), 'filename' => $this->getAttribute('filename'), 'type' => $this->getAttribute('type'), 'file_type' => 'image', 'path' => $hbSur->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $hbSur->resolveThumbnail($this)];
    }
    public static function m9Rhv5w4sFW(REvUXqyajwths $vqGuD) : Yi7VDaCr23YjR
    {
        goto HbjbD;
        MMdnU:
        return $vqGuD;
        goto v0lYT;
        bBu4P:
        return (new Yi7VDaCr23YjR())->fill($vqGuD->getAttributes());
        goto yLh95;
        HbjbD:
        if (!$vqGuD instanceof Yi7VDaCr23YjR) {
            goto lckPc;
        }
        goto MMdnU;
        v0lYT:
        lckPc:
        goto bBu4P;
        yLh95:
    }
}
