<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Encoder;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\TkBEwah2ZcKXB;
use Jfs\Uploader\Service\IudiFfJzDfyEK;
final class NLnbq513ssJFf
{
    public const dBoGT = 'v2/hls/';
    private $DFuSk;
    private $j_caY;
    public function __construct(IudiFfJzDfyEK $PqNmU, Filesystem $nFXer)
    {
        $this->DFuSk = $PqNmU;
        $this->j_caY = $nFXer;
    }
    public function mVfEH2RwNG0($A37bW) : string
    {
        return $this->DFuSk->mAmZg7wUHom(self::dBoGT . $A37bW->getAttribute('id') . '/');
    }
    public function mNsi8ID16q0($A37bW) : string
    {
        return $this->DFuSk->mAmZg7wUHom(self::dBoGT . $A37bW->getAttribute('id') . '/thumbnail/');
    }
    public function mxjiMFQ7ytK($A37bW, $XINSJ = true) : string
    {
        goto L0ywv;
        SV4O0:
        K1N2F:
        goto Cd2GF;
        Cd2GF:
        return $this->DFuSk->mAmZg7wUHom(self::dBoGT . $A37bW->getAttribute('id') . '/' . $A37bW->getAttribute('id') . '.m3u8');
        goto X3zYm;
        L0ywv:
        if ($XINSJ) {
            goto K1N2F;
        }
        goto AS1Fs;
        AS1Fs:
        return self::dBoGT . $A37bW->getAttribute('id') . '/' . $A37bW->getAttribute('id') . '.m3u8';
        goto SV4O0;
        X3zYm:
    }
    public function resolveThumbnail($A37bW) : string
    {
        goto RjFfb;
        RjFfb:
        $W0vWP = $A37bW->getAttribute('id');
        goto DCWQD;
        T_eY9:
        return 1 == count($efDfT) ? self::dBoGT . $W0vWP . '/thumbnail/' . $W0vWP . '.0000000.jpg' : self::dBoGT . $W0vWP . '/thumbnail/' . $W0vWP . '.0000001.jpg';
        goto ZXu9n;
        DCWQD:
        $efDfT = $this->j_caY->files($this->mNsi8ID16q0($A37bW));
        goto T_eY9;
        ZXu9n:
    }
    public function mjrJ9HU7Gnv(string $Iros8) : string
    {
        return $this->j_caY->url($Iros8);
    }
}
