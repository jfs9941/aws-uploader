<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Uploader\Service\Jobs;

use App\Exceptions\MediaConverterException;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Illuminate\Contracts\Filesystem\Filesystem;
use Illuminate\Support\Facades\Log;
use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Encoder\Zct70JWnrBlBs;
use Jfs\Uploader\Encoder\MjNIYZYcN90xN;
use Jfs\Uploader\Encoder\NLnbq513ssJFf;
use Jfs\Uploader\Encoder\WPzRjIwEs52zf;
use Jfs\Uploader\Encoder\MVYTmXuZBStjV;
use Jfs\Uploader\Encoder\Y4TF32dQUcyCj;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use Jfs\Uploader\Service\IudiFfJzDfyEK;
use Webmozart\Assert\Assert;
class Dq82E0jWABlYQ implements MediaEncodeJobInterface
{
    private $wweWZ;
    private $JZDCA;
    private $j_caY;
    private $knb6E;
    private $vtuC3;
    public function __construct(string $VxiVW, $WPRCg, $nFXer, $HgWMY, $BMGzE)
    {
        goto qmYnL;
        pzsVC:
        $this->vtuC3 = $BMGzE;
        goto lr8Bq;
        dWeFi:
        $this->j_caY = $nFXer;
        goto Y6wxV;
        qmYnL:
        $this->wweWZ = $VxiVW;
        goto tFSY1;
        Y6wxV:
        $this->knb6E = $HgWMY;
        goto pzsVC;
        tFSY1:
        $this->JZDCA = $WPRCg;
        goto dWeFi;
        lr8Bq:
    }
    public function encode(string $W0vWP, string $TP3pR, $tuKpm = true) : void
    {
        goto G6or4;
        Of5M1:
        try {
            goto lCAsc;
            cdbLx:
            if (!$IFITH) {
                goto Og5gq;
            }
            goto LxYgW;
            rAZrE:
            Og5gq:
            goto llOW3;
            aEyuD:
            TQdqx:
            goto cOu9Z;
            QIa2J:
            $yJoye->md9w6feguxo($KwRPQ->mVfEH2RwNG0($A37bW));
            goto yPdoA;
            LxYgW:
            $bGGuc = $bGGuc->m9EOseOC7Wz($IFITH);
            goto rAZrE;
            lxxOR:
            if (!($A37bW->WNE_L !== ARsVGbfyHQlSz::S3)) {
                goto zpdwh;
            }
            goto BImH6;
            llOW3:
            $yJoye = $yJoye->mqq5NQEdzFA($bGGuc);
            goto nWNzg;
            lCAsc:
            $A37bW = S1qX7zy4Guf94::findOrFail($W0vWP);
            goto sXiG8;
            nWNzg:
            wEXfV:
            goto aEyuD;
            LvxTl:
            $A37bW->update(['aws_media_converter_job_id' => $W0vWP]);
            goto KW4zZ;
            YFP28:
            $QJopm = $this->m0XSAZQkh0f($bOYNe, $tIdzi);
            goto Xx1aJ;
            Pp9g8:
            if (!($bOYNe && $tIdzi)) {
                goto TQdqx;
            }
            goto ZLIQo;
            ZLIQo:
            if (!$this->m5rso26KKoF($bOYNe, $tIdzi)) {
                goto wEXfV;
            }
            goto YFP28;
            mzjwL:
            $GYomW = new MjNIYZYcN90xN('original', $bOYNe, $tIdzi, $A37bW->JwD_p ?? 30);
            goto Bk34V;
            cOu9Z:
            Log::info("Set thumbnail for S1qX7zy4Guf94 Job", ['videoId' => $A37bW->getAttribute('id'), 'duration' => $A37bW->getAttribute('duration')]);
            goto E9w6k;
            hheTO:
            $W0vWP = $yJoye->mwQnTjtsW3i($this->mP8ISpw27Qc($A37bW, $tuKpm));
            goto LvxTl;
            E9w6k:
            $Pt753 = new Zct70JWnrBlBs($A37bW->dxsQk ?? 1, 2, $KwRPQ->mNsi8ID16q0($A37bW));
            goto GmhxJ;
            BImH6:
            throw new MediaConverterException("S1qX7zy4Guf94 {$A37bW->id} is not S3 driver");
            goto Btfd_;
            SOkNW:
            $w53IY = new GM5l1IAjwnfng($this->knb6E, $this->vtuC3, $this->j_caY, $this->JZDCA);
            goto N_zsf;
            Kp2QC:
            $bOYNe = $A37bW->width();
            goto ZZQVu;
            qlEo2:
            $yJoye = app(MVYTmXuZBStjV::class);
            goto q39zU;
            IVzPb:
            $yJoye->mqq5NQEdzFA($GYomW);
            goto GAXbk;
            yPdoA:
            $PqNmU = app(IudiFfJzDfyEK::class);
            goto SOkNW;
            tbtYH:
            $nB4xZ = $this->mRHSJURKFuz($A37bW);
            goto nvKWr;
            ii1Kp:
            $bGGuc = new MjNIYZYcN90xN('1080p', $QJopm['width'], $QJopm['height'], $A37bW->JwD_p ?? 30);
            goto zvADe;
            sXiG8:
            Assert::isInstanceOf($A37bW, S1qX7zy4Guf94::class);
            goto lxxOR;
            N_zsf:
            $IFITH = $this->makFoQhd0kL($PqNmU, $w53IY->mzmK96qCqJ0($A37bW->width(), $A37bW->height(), $TP3pR));
            goto TAnn2;
            wlRRp:
            $yJoye->mqq5NQEdzFA($GYomW);
            goto QIa2J;
            hOeLd:
            $GYomW = $GYomW->m9EOseOC7Wz($IFITH);
            goto lFXCE;
            Btfd_:
            zpdwh:
            goto Kp2QC;
            q39zU:
            $yJoye = $yJoye->mTnKmAP5Wlj(new WPzRjIwEs52zf($nB4xZ));
            goto mzjwL;
            Bk34V:
            $KwRPQ = app(NLnbq513ssJFf::class);
            goto wlRRp;
            zvADe:
            $IFITH = $this->makFoQhd0kL($PqNmU, $w53IY->mzmK96qCqJ0((int) $QJopm['width'], (int) $QJopm['height'], $TP3pR));
            goto cdbLx;
            lFXCE:
            h4e7e:
            goto IVzPb;
            GmhxJ:
            $yJoye = $yJoye->m7RZ4pLYc6E($Pt753);
            goto hheTO;
            nvKWr:
            Log::info("Set input video for Job", ['s3Uri' => $nB4xZ]);
            goto qlEo2;
            Xx1aJ:
            Log::info("Set 1080p resolution for Job", ['width' => $QJopm['width'], 'height' => $QJopm['height'], 'originalWidth' => $bOYNe, 'originalHeight' => $tIdzi]);
            goto ii1Kp;
            ZZQVu:
            $tIdzi = $A37bW->height();
            goto tbtYH;
            GAXbk:
            $yJoye->md9w6feguxo($KwRPQ->mVfEH2RwNG0($A37bW));
            goto Pp9g8;
            TAnn2:
            if (!$IFITH) {
                goto h4e7e;
            }
            goto hOeLd;
            KW4zZ:
        } catch (\Exception $iCEwa) {
            Log::info("S1qX7zy4Guf94 has been deleted, discard it", ['fileId' => $W0vWP, 'err' => $iCEwa->getMessage()]);
            return;
        }
        goto rE09m;
        G6or4:
        Log::info('[MediaEncodeVideoJob] Start execute AWS encode video', ['fileId' => $W0vWP]);
        goto OcSy3;
        OcSy3:
        ini_set('memory_limit', '-1');
        goto Of5M1;
        rE09m:
    }
    private function mP8ISpw27Qc(S1qX7zy4Guf94 $A37bW, $tuKpm) : bool
    {
        goto oPqGy;
        IZazI:
        bqq3j:
        goto EJgX7;
        vEI87:
        switch (true) {
            case $A37bW->width() * $A37bW->height() >= 1920 * 1080 && $A37bW->width() * $A37bW->height() < 2560 * 1440:
                return $WPdu6 > 10 * 60;
            case $A37bW->width() * $A37bW->height() >= 2560 * 1440 && $A37bW->width() * $A37bW->height() < 3840 * 2160:
                return $WPdu6 > 5 * 60;
            case $A37bW->width() * $A37bW->height() >= 3840 * 2160:
                return $WPdu6 > 3 * 60;
            default:
                return false;
        }
        goto qghoP;
        VPQIr:
        return false;
        goto QPZ5i;
        QPZ5i:
        yYVck:
        goto z5jh5;
        qghoP:
        vjQCY:
        goto IZazI;
        oPqGy:
        if ($tuKpm) {
            goto yYVck;
        }
        goto VPQIr;
        z5jh5:
        $WPdu6 = (int) round($A37bW->getAttribute('duration') ?? 0);
        goto vEI87;
        EJgX7:
    }
    private function makFoQhd0kL(IudiFfJzDfyEK $PqNmU, string $VgBHb) : ?Y4TF32dQUcyCj
    {
        goto gVQfb;
        O04ZR:
        jO5yb:
        goto anIu7;
        JOWeq:
        return new Y4TF32dQUcyCj($B7N3c, 0, 0, null, null);
        goto O04ZR;
        PhYuF:
        Log::info("Resolve watermark for job with url", ['url' => $VgBHb, 'uri' => $B7N3c]);
        goto SAj4E;
        anIu7:
        return null;
        goto vef5k;
        SAj4E:
        if (!$B7N3c) {
            goto jO5yb;
        }
        goto JOWeq;
        gVQfb:
        $B7N3c = $PqNmU->mwI1qFiQfK7($VgBHb);
        goto PhYuF;
        vef5k:
    }
    private function m5rso26KKoF(int $bOYNe, int $tIdzi) : bool
    {
        return $bOYNe * $tIdzi > 1.5 * (1920 * 1080);
    }
    private function m0XSAZQkh0f(int $bOYNe, int $tIdzi) : array
    {
        $yELm_ = new CHLCQjGlU96Rg($bOYNe, $tIdzi);
        return $yELm_->meEOCmaBy4M();
    }
    private function mRHSJURKFuz(TWXq4PCBxnKLl $HRuZr) : string
    {
        goto H8KXA;
        H8KXA:
        if (!($HRuZr->WNE_L == ARsVGbfyHQlSz::S3)) {
            goto FSHyZ;
        }
        goto z4lM1;
        qrz3b:
        return $this->JZDCA->url($HRuZr->filename);
        goto lp7Ze;
        wlmcW:
        FSHyZ:
        goto qrz3b;
        z4lM1:
        return 's3://' . $this->wweWZ . '/' . $HRuZr->filename;
        goto wlmcW;
        lp7Ze:
    }
}
