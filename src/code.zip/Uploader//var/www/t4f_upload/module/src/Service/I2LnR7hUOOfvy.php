<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Uploader\Service;

use Illuminate\Contracts\Filesystem\Filesystem;
use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
final class I2LnR7hUOOfvy
{
    private $qNgj8;
    private $y3ks7;
    private $HO2X0;
    public function __construct(string $XhEIi, string $FkG08, Filesystem $skn0D)
    {
        goto itJ97;
        eEaYt:
        $this->HO2X0 = $skn0D;
        goto g9suj;
        LgVbS:
        $this->y3ks7 = $FkG08;
        goto eEaYt;
        itJ97:
        $this->qNgj8 = $XhEIi;
        goto LgVbS;
        g9suj:
    }
    public function mFUZr0MmJiJ(VWfw9VfxzTDgS $iiESX) : string
    {
        goto h1FcM;
        zaJne:
        return $this->HO2X0->url($iiESX->getAttribute('filename'));
        goto MfAS4;
        yiR7t:
        return 's3://' . $this->qNgj8 . '/' . $iiESX->getAttribute('filename');
        goto Ou_Ib;
        h1FcM:
        if (!(BHGv9oAB1EERw::S3 == $iiESX->getAttribute('driver'))) {
            goto GG694;
        }
        goto yiR7t;
        Ou_Ib:
        GG694:
        goto zaJne;
        MfAS4:
    }
    public function mysjBHznXFa(?string $Obh2s) : ?string
    {
        goto FXc3P;
        I7tTO:
        return 's3://' . $this->qNgj8 . '/' . ltrim($BkP1c, '/');
        goto tg3jG;
        E0FCU:
        if (!ZF9PR($Obh2s, $this->qNgj8)) {
            goto n9O8V;
        }
        goto ewqL4;
        tg3jG:
        n9O8V:
        goto rL2sI;
        rL2sI:
        nBpgo:
        goto C3Ak8;
        FXc3P:
        if (!$Obh2s) {
            goto nBpgo;
        }
        goto E0FCU;
        ewqL4:
        $BkP1c = parse_url($Obh2s, PHP_URL_PATH);
        goto I7tTO;
        C3Ak8:
        return null;
        goto TG00z;
        TG00z:
    }
    public function mgW507kxn2Z(string $BkP1c) : string
    {
        return 's3://' . $this->qNgj8 . '/' . $BkP1c;
    }
}
