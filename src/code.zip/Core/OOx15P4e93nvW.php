<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; use Jfs\Uploader\Contracts\UjyuhX0WkYOek; use Jfs\Uploader\Contracts\Sbfs0QPHtoaIh; use Jfs\Uploader\Core\Traits\XLgNMpI6lnOF2; use Jfs\Uploader\Core\Traits\TAohsiwmbcOcI; use Jfs\Uploader\Enum\FileStatus; use Jfs\Uploader\Service\M8ps5utLXqn5b; class OOx15P4e93nvW extends KcksySJhJWYDc implements UjyuhX0WkYOek { use XLgNMpI6lnOF2; use TAohsiwmbcOcI; public function getType() : string { return 'pdf'; } public static function createFromScratch(string $zMg1g, string $u3z_C) : self { goto r5wq7; r5wq7: $Dp4ID = new self(['id' => $zMg1g, 'type' => $u3z_C, 'status' => FileStatus::UPLOADING]); goto QX61Q; QX61Q: $Dp4ID->mVfhO6b3M7d(FileStatus::UPLOADING); goto mZP81; mZP81: return $Dp4ID; goto BaJBc; BaJBc: } public function getView() : array { $Un7zV = app(Sbfs0QPHtoaIh::class); return ['id' => $this->getAttribute('id'), 'type' => $this->getAttribute('type'), 'file_type' => 'file', 'path' => $Un7zV->resolvePath($this, $this->getAttribute('driver')), 'thumbnail' => $Un7zV->resolveThumbnail($this)]; } }
