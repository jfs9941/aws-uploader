<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Observer; use Jfs\Uploader\Contracts\UjyuhX0WkYOek; use Jfs\Uploader\Contracts\XxrGtmtyc6nX6; use Jfs\Uploader\Core\KcksySJhJWYDc; use Jfs\Uploader\Core\LVQ91B8F8zY4F; use Jfs\Uploader\Enum\FileStatus; class GQdIrX5z8R9w7 implements XxrGtmtyc6nX6 { private $s5DwZ; public function __construct($mS7iH) { $this->s5DwZ = $mS7iH; } public function mFWlGPog2WD($oq3lD, $WUf3G) { goto gkdNq; T0_Ok: $this->s5DwZ->save(); goto uQfXc; V1bx7: $this->s5DwZ->mlmUyLKF8S5(FileStatus::PROCESSING); goto oU1xk; TtGZJ: if (!(FileStatus::DELETED === $WUf3G && $this->s5DwZ->mHOvcsb1GKM())) { goto zrZuy; } goto kkJbB; lQ45g: zrZuy: goto RysS2; oU1xk: MQv21: goto T0_Ok; TSHbu: if (!$this->s5DwZ instanceof LVQ91B8F8zY4F) { goto MQv21; } goto V1bx7; kkJbB: $this->s5DwZ->delete(); goto lQ45g; uQfXc: SU_gp: goto TtGZJ; gkdNq: if (!(FileStatus::UPLOADED === $WUf3G)) { goto SU_gp; } goto fVLpE; fVLpE: $this->s5DwZ->status = FileStatus::UPLOADED; goto TSHbu; RysS2: } }
