<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; use Illuminate\Database\Eloquent\Model; use Jfs\Uploader\Enum\FileDriver; abstract  class KcksySJhJWYDc extends Model implements Ip4S07jGB6Ssb { public $incrementing = false; protected $fillable = ['user_id', 'filename', 'thumbnail', 'preview', 'type', 'id', 'driver', 'duration', 'status', 'parent_id', 'thumbnail_id', 'resolution', 'hls_path', 'fps', 'aws_media_converter_job_id', 'thumbnail_url', 'approved', 'stock_message_id', 'generated_previews']; protected $table = 'attachments'; protected $casts = ['id' => 'string', 'generated_previews' => 'array', 'driver' => 'int', 'status' => 'int']; public function mHOvcsb1GKM() : bool { goto owOH1; WcogD: return !$this->mXTFAfJs9Hz(); goto NKuOz; LiCRL: return true; goto oJ5hD; oJ5hD: rOdct: goto WcogD; owOH1: if (!(null === $this->getAttribute('post_id') && null === $this->getAttribute('message_id') && null === $this->getAttribute('shop_item_id'))) { goto rOdct; } goto LiCRL; NKuOz: } protected function mXTFAfJs9Hz() : bool { return null === $this->getAttribute('parent_id'); } public abstract function getView() : array; }
