<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core; interface Ip4S07jGB6Ssb { public function getFilename() : string; public function getExtension() : string; public function getType() : string; public function getLocation() : string; public function initLocation(string $nG0Gr); public static function createFromScratch(string $zMg1g, string $u3z_C); public function getView(); }
