<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Strategy; use Jfs\Uploader\Exposed\FileProcessingStrategyInterface; use Jfs\Uploader\Core\Ip4S07jGB6Ssb; use Jfs\Uploader\Encoder\QeFUfZ0SaT3Tq; class V9rvXFB3KLrYC implements FileProcessingStrategyInterface { private $An7Ct; private $Wd0Lr; private $H2Js7; public function __construct(Ip4S07jGB6Ssb $tLx8G, QeFUfZ0SaT3Tq $RKvZT) { goto Tx7Qj; hJwMd: $this->H2Js7 = new $O7ye2($tLx8G, $RKvZT); goto lsyEE; eFcT5: $O7ye2 = config('upload.post_process_video'); goto hJwMd; Tx7Qj: $this->An7Ct = $tLx8G; goto N1sZW; N1sZW: $this->Wd0Lr = $RKvZT; goto eFcT5; lsyEE: } public function process($dv0eX) { $this->H2Js7->process($dv0eX); } }
