<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Strategy; use Jfs\Uploader\Exposed\FileProcessingStrategyInterface; use Jfs\Uploader\Core\KcksySJhJWYDc; use Jfs\Uploader\Core\Ip4S07jGB6Ssb; use Jfs\Uploader\Core\LVQ91B8F8zY4F; use Webmozart\Assert\Assert; class MOBJs3viyeTR5 implements FileProcessingStrategyInterface { private $yAjZC; private $bXL33; private $H2Js7; public function __construct($S8DUg, $KVGQr) { goto JAeLF; j6qi6: $this->yAjZC = $S8DUg; goto EQ5mC; XNAHv: $this->H2Js7 = new $O7ye2($S8DUg, $KVGQr); goto mewGE; JAeLF: Assert::isInstanceOf($S8DUg, LVQ91B8F8zY4F::class); goto j6qi6; EQ5mC: $this->bXL33 = $KVGQr; goto EGljE; EGljE: $O7ye2 = config('upload.post_process_image'); goto XNAHv; mewGE: } public function process($dv0eX) : void { $this->H2Js7->process($dv0eX); } }
