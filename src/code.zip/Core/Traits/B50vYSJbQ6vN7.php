<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Traits; use Jfs\Uploader\Core\ZXy1QZjBv7swQ; use Jfs\Uploader\Core\DIZctbtEI4eRo; use Jfs\Uploader\Exception\ZOYm7De3ZiZjt; trait B50vYSJbQ6vN7 { private $s5DwZ; private $am77f; private $wXtsk; public function mlmBCjBwP5N() : string { return ZXy1QZjBv7swQ::m4mlCFHIYbA($this->s5DwZ->getFilename()); } public function mzZPSDRrtO8() : ZXy1QZjBv7swQ { goto Sq2yk; I72f7: return $this->am77f; goto Ud62l; qytPw: zoM_J: goto B4kx1; Sq2yk: if (!(null !== $this->am77f)) { goto zoM_J; } goto M1n2A; M1n2A: return $this->am77f; goto qytPw; B4kx1: $this->mbC6J223kn8(); goto I72f7; Ud62l: } private function mbC6J223kn8() : DIZctbtEI4eRo { goto EInvt; IEK7M: return $this; goto ZCvSb; GfZBx: $this->am77f = ZXy1QZjBv7swQ::mq0Gz9TK71d($i8Z39); goto IEK7M; EInvt: $AXZW2 = $this->wXtsk->get($this->mlmBCjBwP5N()); goto hujpp; ZCvSb: e9gR_: goto BFirY; BFirY: throw new ZOYm7De3ZiZjt("File {$this->s5DwZ->getFilename()} is not PreSigned upload"); goto tvBUj; hujpp: if (!$AXZW2) { goto e9gR_; } goto PnXvr; PnXvr: $i8Z39 = json_decode($AXZW2, true); goto GfZBx; tvBUj: } public function mpy1PHxLS5Q($cNYaW, $q5dm6, $vcQWy, $d40Qz, $EF3Se, $gn0B8 = 's3') : void { $this->am77f = ZXy1QZjBv7swQ::m8ssJz8Q7gM($this->s5DwZ, $cNYaW, $q5dm6, $EF3Se, $vcQWy, $d40Qz, $gn0B8); } }
