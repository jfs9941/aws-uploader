<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Core\Traits; trait Ur0Q305wjq3m2 { private function mgjca5Rk7SI(string $QIXWV) : string { return str_replace(['https://', 'http://', 'www.'], '', route('profile', ['username' => $QIXWV])); } }
