<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Exposed;

interface VideoPostHandleServiceInterface
{
    public function saveMetadata(string $HxXtJ, array $UTrEg);
    public function createThumbnail(string $OcirX) : void;
    public function getThumbnails(string $OcirX) : array;
    public function getMedia(string $OcirX) : array;
}
