<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Exposed;

use Jfs\Exposed\SingleUploadInterface;
interface UploadServiceInterface
{
    public function storeSingleFile(SingleUploadInterface $PRKNS) : array;
    public function storePreSignedFile(array $bCnNn);
    public function updatePreSignedFile(string $GdIwa, int $ro2_M);
    public function completePreSignedFile(string $GdIwa, array $Luhos);
    public function updateFile(string $GdIwa, int $ro2_M);
}
