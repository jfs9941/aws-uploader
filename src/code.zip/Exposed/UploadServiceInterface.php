<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Exposed;

use Jfs\Exposed\SingleUploadInterface;
interface UploadServiceInterface
{
    public function storeSingleFile(SingleUploadInterface $wKXEn) : array;
    public function storePreSignedFile(array $Q6J6I);
    public function updatePreSignedFile(string $idKTy, int $ZyMX_);
    public function completePreSignedFile(string $idKTy, array $BHKm9);
    public function updateFile(string $idKTy, int $ZyMX_);
}
