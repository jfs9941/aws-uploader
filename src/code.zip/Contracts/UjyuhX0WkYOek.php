<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Contracts; use Jfs\Uploader\Exception\XTxuKg5Slx5F2; interface UjyuhX0WkYOek { public function mVfhO6b3M7d($LO0AJ); public function mbnYLpCfXIc(); public function mlmUyLKF8S5($vkYXX); public function micltPoZS1U($vkYXX); public function mi4TYGyy8bp(XxrGtmtyc6nX6 $y8_LU); }
