<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Contracts; use Jfs\Uploader\Core\KcksySJhJWYDc; use Jfs\Uploader\Core\Filz4eY0wJAZu; use Jfs\Uploader\Enum\FileDriver; interface Sbfs0QPHtoaIh { public function resolvePath($xd765, int $gn0B8 = FileDriver::S3); public function resolveThumbnail(KcksySJhJWYDc $xd765); public function resolvePathForHlsVideo(Filz4eY0wJAZu $tLx8G, bool $hjMbD = false); public function resolvePathForHlsVideos(); }
