<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\PGHqEiVt8yOaC;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Encoder\Saum77EIMVl09;
use Jfs\Uploader\Encoder\CJIFKD65bWskH;
use Jfs\Uploader\Service\Ti53myCAJIBMS;
use Jfs\Uploader\Service\FileResolver\HC3HmK7qPSSdu;
use Jfs\Uploader\Service\FileResolver\BthvEvdQd3NrL;
use Jfs\Uploader\Service\FileResolver\X1yNbGZA3KFUw;
use Jfs\Uploader\Service\Jobs\BcwvEQQFSKrVT;
use Jfs\Uploader\Service\Jobs\Rj1tg0wqN9jzV;
use Jfs\Uploader\Service\Jobs\PjKJJw0NoYH1u;
use Jfs\Uploader\Service\Jobs\QMmzs0CY3Lw0h;
use Jfs\Uploader\Service\Jobs\E8LfJDwxzYQlt;
use Jfs\Uploader\Service\Jobs\WmUrxQ816qmVH;
use Jfs\Uploader\Service\Jobs\RbQqec9N6yhu3;
use Jfs\Uploader\Service\Jobs\DaI3GR9qhtcKt;
use Jfs\Uploader\Service\Jobs\BILJHBmslj2vI;
use Jfs\Uploader\Service\Jobs\HqeYjYMoPzMvo;
use Jfs\Uploader\Service\NzkrkFhIBihmO;
use Jfs\Uploader\Service\Uzq9No60iqNHV;
use Jfs\Uploader\Service\ZIwWW145kLPpp;
use Jfs\Uploader\Service\XPbFd7sAajZAw;
class TqKxdwwvKq3io extends ServiceProvider
{
    public function register() : void
    {
        goto eojUA;
        j17zk:
        $this->app->singleton(UKSr4EAd7qrlK::class, function () {
            return new Uzq9No60iqNHV(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto eyJTq;
        pFYOE:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($gn4mo) {
            return new QMmzs0CY3Lw0h(Storage::disk('s3'), Storage::disk('public'));
        });
        goto PjJn6;
        aATHe:
        $this->app->bind(CompressJobInterface::class, function ($gn4mo) {
            return new PjKJJw0NoYH1u(config('upload.maker'), Storage::disk('public'));
        });
        goto pFYOE;
        IwGom:
        $this->app->bind(StoreToS3JobInterface::class, function ($gn4mo) {
            return new RbQqec9N6yhu3(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ck25t;
        FRJUX:
        $this->app->bind(CJIFKD65bWskH::class, function ($gn4mo) {
            return new CJIFKD65bWskH(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto zAodT;
        zAodT:
        $this->app->tag([X1yNbGZA3KFUw::class, BthvEvdQd3NrL::class, HC3HmK7qPSSdu::class], 'file.location.resolvers');
        goto YhLoB;
        afjTu:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($gn4mo) {
            return new XPbFd7sAajZAw($gn4mo->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto j17zk;
        PjJn6:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($gn4mo) {
            return new E8LfJDwxzYQlt(config('upload.maker'), Storage::disk('public'));
        });
        goto G4nVA;
        kho2f:
        $this->app->bind(GalleryCloudInterface::class, function ($gn4mo) {
            return new PGHqEiVt8yOaC();
        });
        goto A8w6E;
        TCggk:
        $this->app->singleton(Saum77EIMVl09::class, function ($gn4mo) {
            return new Saum77EIMVl09($gn4mo->make(NzkrkFhIBihmO::class), Storage::disk('s3'));
        });
        goto FRJUX;
        eojUA:
        $this->app->bind(UploadServiceInterface::class, function ($gn4mo) {
            return new ZIwWW145kLPpp($gn4mo->make(Ti53myCAJIBMS::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto afjTu;
        cXpZv:
        $this->app->bind(BlurVideoJobInterface::class, function ($gn4mo) {
            return new Rj1tg0wqN9jzV(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto aATHe;
        ck25t:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($gn4mo) {
            return new DaI3GR9qhtcKt(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto x8f5L;
        FTuXH:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($gn4mo) {
            return new WmUrxQ816qmVH();
        });
        goto IwGom;
        x8f5L:
        $this->app->bind(WatermarkTextJobInterface::class, function ($gn4mo) {
            return new HqeYjYMoPzMvo(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto kho2f;
        eyJTq:
        $this->app->singleton(Ti53myCAJIBMS::class, function ($gn4mo) {
            return new Ti53myCAJIBMS($gn4mo->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ISKSF;
        ISKSF:
        $this->app->singleton(NzkrkFhIBihmO::class, function ($gn4mo) {
            return new NzkrkFhIBihmO(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto TCggk;
        YhLoB:
        $this->app->bind(BlurJobInterface::class, function ($gn4mo) {
            return new BcwvEQQFSKrVT(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto cXpZv;
        G4nVA:
        $this->app->bind(MediaEncodeJobInterface::class, function ($gn4mo) {
            return new BILJHBmslj2vI(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto FTuXH;
        A8w6E:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
