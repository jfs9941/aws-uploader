<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\L5A9c1C4s5pof;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Uploader\Encoder\PERAjoCXLxFkm;
use Jfs\Uploader\Encoder\LTe1erTqXsoi2;
use Jfs\Uploader\Service\Fqe4ryAftaAFD;
use Jfs\Uploader\Service\FileResolver\Cx7yncamWYcxT;
use Jfs\Uploader\Service\FileResolver\X7Hcdw1gQNluq;
use Jfs\Uploader\Service\FileResolver\QIkXjwA0rbke5;
use Jfs\Uploader\Service\Jobs\EnaRd13nnO4dm;
use Jfs\Uploader\Service\Jobs\FPeakagokBcbc;
use Jfs\Uploader\Service\Jobs\HhkAfmeJC1gLe;
use Jfs\Uploader\Service\Jobs\IBBg01i3exMcV;
use Jfs\Uploader\Service\Jobs\QWlWplAS0ssH7;
use Jfs\Uploader\Service\Jobs\SU5x9dXP1H4uj;
use Jfs\Uploader\Service\Jobs\Y4j6zBUZX19T7;
use Jfs\Uploader\Service\Jobs\BYT5DBY3GZZvP;
use Jfs\Uploader\Service\Jobs\NjqQPsg1M85Bz;
use Jfs\Uploader\Service\Jobs\ONKKx7qfB4tWN;
use Jfs\Uploader\Service\HTG7kEjmlWunD;
use Jfs\Uploader\Service\XeGbK8RtVGtth;
use Jfs\Uploader\Service\WWprjMnKoYMRC;
use Jfs\Uploader\Service\Zi1ZEFGLwFeOh;
class JeADhu97QTb7b extends ServiceProvider
{
    public function register() : void
    {
        goto vHXmt;
        rFkq2:
        $this->app->singleton(HTG7kEjmlWunD::class, function ($MTSYu) {
            return new HTG7kEjmlWunD(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto lmxGb;
        Ue8he:
        $this->app->bind(BlurJobInterface::class, function ($MTSYu) {
            return new EnaRd13nnO4dm(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto H1bDs;
        lmxGb:
        $this->app->singleton(PERAjoCXLxFkm::class, function ($MTSYu) {
            return new PERAjoCXLxFkm($MTSYu->make(HTG7kEjmlWunD::class), Storage::disk('s3'));
        });
        goto aVWTr;
        znU6J:
        $this->app->bind(StoreToS3JobInterface::class, function ($MTSYu) {
            return new Y4j6zBUZX19T7(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto a8Uxw;
        a8Uxw:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($MTSYu) {
            return new BYT5DBY3GZZvP(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto jpaHH;
        fN30w:
        $this->app->singleton(LlbXoUBShkgwJ::class, function () {
            return new XeGbK8RtVGtth(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto DSfF8;
        OEl8w:
        $this->app->tag([QIkXjwA0rbke5::class, X7Hcdw1gQNluq::class, Cx7yncamWYcxT::class], 'file.location.resolvers');
        goto Ue8he;
        Nq2pR:
        $this->app->bind(CompressJobInterface::class, function ($MTSYu) {
            return new HhkAfmeJC1gLe(config('upload.maker'), Storage::disk('public'));
        });
        goto k_PXJ;
        jpaHH:
        $this->app->bind(WatermarkTextJobInterface::class, function ($MTSYu) {
            return new ONKKx7qfB4tWN(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto DLEiB;
        DLEiB:
        $this->app->bind(GalleryCloudInterface::class, function ($MTSYu) {
            return new L5A9c1C4s5pof();
        });
        goto Z_bHO;
        y1cfh:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($MTSYu) {
            return new QWlWplAS0ssH7(config('upload.maker'), Storage::disk('public'));
        });
        goto BDj2w;
        DSfF8:
        $this->app->singleton(Fqe4ryAftaAFD::class, function ($MTSYu) {
            return new Fqe4ryAftaAFD($MTSYu->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto rFkq2;
        k_PXJ:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($MTSYu) {
            return new IBBg01i3exMcV(Storage::disk('s3'), Storage::disk('public'));
        });
        goto y1cfh;
        H1bDs:
        $this->app->bind(BlurVideoJobInterface::class, function ($MTSYu) {
            return new FPeakagokBcbc(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Nq2pR;
        BDj2w:
        $this->app->bind(MediaEncodeJobInterface::class, function ($MTSYu) {
            return new NjqQPsg1M85Bz(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto MVbp1;
        vHXmt:
        $this->app->bind(UploadServiceInterface::class, function ($MTSYu) {
            return new WWprjMnKoYMRC($MTSYu->make(Fqe4ryAftaAFD::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto FWMVz;
        FWMVz:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($MTSYu) {
            return new Zi1ZEFGLwFeOh($MTSYu->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto fN30w;
        aVWTr:
        $this->app->bind(LTe1erTqXsoi2::class, function ($MTSYu) {
            return new LTe1erTqXsoi2(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto OEl8w;
        MVbp1:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($MTSYu) {
            return new SU5x9dXP1H4uj();
        });
        goto znU6J;
        Z_bHO:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
