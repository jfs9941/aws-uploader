<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\GctV2200KmYdA;
use Jfs\Uploader\Contracts\TdTpyTw87RXgQ;
use Jfs\Uploader\Encoder\VSKfJ2MZj0Tjg;
use Jfs\Uploader\Encoder\VTzJhiAsIieKq;
use Jfs\Uploader\Service\UG0KhqkrdbP7y;
use Jfs\Uploader\Service\FileResolver\Qaf6IEk4SdOqq;
use Jfs\Uploader\Service\FileResolver\DFICVtPsXzJOd;
use Jfs\Uploader\Service\FileResolver\GHCHb5QJKfdyT;
use Jfs\Uploader\Service\Jobs\AS2qU8Di95CMu;
use Jfs\Uploader\Service\Jobs\GYvWgtOURv76a;
use Jfs\Uploader\Service\Jobs\JY16BPSHUwdha;
use Jfs\Uploader\Service\Jobs\C15thK7H3B3RF;
use Jfs\Uploader\Service\Jobs\ZaIKd6NxPOyf0;
use Jfs\Uploader\Service\Jobs\VaEvj2mX8zofS;
use Jfs\Uploader\Service\Jobs\BwkBAms98kWtA;
use Jfs\Uploader\Service\Jobs\XdQh4dhyPWLr8;
use Jfs\Uploader\Service\Jobs\W4sWjQfO5W1OS;
use Jfs\Uploader\Service\Jobs\SuvPVQtSuOf4w;
use Jfs\Uploader\Service\JkVi3Kv2ThmJv;
use Jfs\Uploader\Service\JujbASFciElku;
use Jfs\Uploader\Service\T8lrozxGunpO1;
use Jfs\Uploader\Service\Kaz50wg6tz9Qz;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto tJtXn;
        kbtdI:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Pmm_w) {
            return new ZaIKd6NxPOyf0(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ijPXn;
        Rkykg:
        $this->app->singleton(JkVi3Kv2ThmJv::class, function ($Pmm_w) {
            return new JkVi3Kv2ThmJv(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto rnHx0;
        Z0Ur7:
        $this->app->singleton(UG0KhqkrdbP7y::class, function ($Pmm_w) {
            return new UG0KhqkrdbP7y($Pmm_w->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Rkykg;
        Z1H7b:
        $this->app->tag([GHCHb5QJKfdyT::class, DFICVtPsXzJOd::class, Qaf6IEk4SdOqq::class], 'file.location.resolvers');
        goto RTvMf;
        sgHCb:
        $this->app->bind(GalleryCloudInterface::class, function ($Pmm_w) {
            return new GctV2200KmYdA();
        });
        goto MI5vU;
        RTvMf:
        $this->app->bind(BlurJobInterface::class, function ($Pmm_w) {
            return new AS2qU8Di95CMu(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto QwxuQ;
        eme6O:
        $this->app->bind(VTzJhiAsIieKq::class, function ($Pmm_w) {
            return new VTzJhiAsIieKq(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto Z1H7b;
        djbId:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Pmm_w) {
            return new Kaz50wg6tz9Qz($Pmm_w->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto WbCj2;
        rnHx0:
        $this->app->singleton(VSKfJ2MZj0Tjg::class, function ($Pmm_w) {
            return new VSKfJ2MZj0Tjg($Pmm_w->make(JkVi3Kv2ThmJv::class), Storage::disk('s3'));
        });
        goto eme6O;
        JK2v8:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Pmm_w) {
            return new VaEvj2mX8zofS();
        });
        goto vLrt5;
        vLrt5:
        $this->app->bind(StoreToS3JobInterface::class, function ($Pmm_w) {
            return new BwkBAms98kWtA(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Kz2wj;
        C8U9z:
        $this->app->bind(CompressJobInterface::class, function ($Pmm_w) {
            return new JY16BPSHUwdha(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto oo6M3;
        QwxuQ:
        $this->app->bind(BlurVideoJobInterface::class, function ($Pmm_w) {
            return new GYvWgtOURv76a(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto C8U9z;
        pcIck:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Pmm_w) {
            return new SuvPVQtSuOf4w(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto sgHCb;
        tJtXn:
        $this->app->bind(UploadServiceInterface::class, function ($Pmm_w) {
            return new T8lrozxGunpO1($Pmm_w->make(UG0KhqkrdbP7y::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto djbId;
        Kz2wj:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Pmm_w) {
            return new XdQh4dhyPWLr8(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto pcIck;
        WbCj2:
        $this->app->singleton(TdTpyTw87RXgQ::class, function () {
            return new JujbASFciElku(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto Z0Ur7;
        ijPXn:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Pmm_w) {
            return new W4sWjQfO5W1OS(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto JK2v8;
        oo6M3:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Pmm_w) {
            return new C15thK7H3B3RF(Storage::disk('s3'), Storage::disk('public'));
        });
        goto kbtdI;
        MI5vU:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
