<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\UEJL05KV8YOjr;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Encoder\WKWBYhZhEWOea;
use Jfs\Uploader\Encoder\Na4nP4czgqeSL;
use Jfs\Uploader\Service\AYglkzXejDDAm;
use Jfs\Uploader\Service\FileResolver\VWN5bKRjxWDoL;
use Jfs\Uploader\Service\FileResolver\SzRSqs51PpSry;
use Jfs\Uploader\Service\FileResolver\EmWiD6vTDDsWv;
use Jfs\Uploader\Service\Jobs\WMQbeynlDd53w;
use Jfs\Uploader\Service\Jobs\XmnTxliimaPU2;
use Jfs\Uploader\Service\Jobs\QVCQIo5YtGQYN;
use Jfs\Uploader\Service\Jobs\J8Eq2shmK5zdf;
use Jfs\Uploader\Service\Jobs\Ny90NEOcoLuH1;
use Jfs\Uploader\Service\Jobs\GJdfU4AysDtbA;
use Jfs\Uploader\Service\Jobs\RHI4XEYnkyVn5;
use Jfs\Uploader\Service\Jobs\OWgEPQwqOvtmY;
use Jfs\Uploader\Service\Jobs\ED2GWlc1dwENf;
use Jfs\Uploader\Service\Jobs\QbIePD3Dvh953;
use Jfs\Uploader\Service\SqWT6oYd97hAj;
use Jfs\Uploader\Service\TEgBbF7EqiUEB;
use Jfs\Uploader\Service\BBJ8LO3rEX6wz;
use Jfs\Uploader\Service\IEXX2bisrgAPc;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto W_1XE;
        ypz7e:
        $this->app->bind(WatermarkTextJobInterface::class, function ($mXSQZ) {
            return new QbIePD3Dvh953(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto NRdrc;
        QzQnz:
        $this->app->singleton(WKWBYhZhEWOea::class, function ($mXSQZ) {
            return new WKWBYhZhEWOea($mXSQZ->make(SqWT6oYd97hAj::class), Storage::disk('s3'));
        });
        goto MGpIo;
        NRdrc:
        $this->app->bind(GalleryCloudInterface::class, function ($mXSQZ) {
            return new UEJL05KV8YOjr();
        });
        goto qDn9w;
        p3jxy:
        $this->app->bind(StoreToS3JobInterface::class, function ($mXSQZ) {
            return new RHI4XEYnkyVn5(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Ojq8l;
        fb0lK:
        $this->app->singleton(SqWT6oYd97hAj::class, function ($mXSQZ) {
            return new SqWT6oYd97hAj(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto QzQnz;
        MGpIo:
        $this->app->bind(Na4nP4czgqeSL::class, function ($mXSQZ) {
            return new Na4nP4czgqeSL(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto YqxHE;
        yGsB2:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($mXSQZ) {
            return new IEXX2bisrgAPc($mXSQZ->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto qPJr6;
        W_1XE:
        $this->app->bind(UploadServiceInterface::class, function ($mXSQZ) {
            return new BBJ8LO3rEX6wz($mXSQZ->make(AYglkzXejDDAm::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto yGsB2;
        Vcd4_:
        $this->app->bind(MediaEncodeJobInterface::class, function ($mXSQZ) {
            return new ED2GWlc1dwENf(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto LYwtB;
        YqxHE:
        $this->app->tag([EmWiD6vTDDsWv::class, SzRSqs51PpSry::class, VWN5bKRjxWDoL::class], 'file.location.resolvers');
        goto Bc64v;
        Bc64v:
        $this->app->bind(BlurJobInterface::class, function ($mXSQZ) {
            return new WMQbeynlDd53w(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto UZM0I;
        G3wWk:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($mXSQZ) {
            return new J8Eq2shmK5zdf(Storage::disk('s3'), Storage::disk('public'));
        });
        goto ZjEk7;
        ZjEk7:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($mXSQZ) {
            return new Ny90NEOcoLuH1(config('upload.maker'), Storage::disk('public'));
        });
        goto Vcd4_;
        UZM0I:
        $this->app->bind(BlurVideoJobInterface::class, function ($mXSQZ) {
            return new XmnTxliimaPU2(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto usKwh;
        usKwh:
        $this->app->bind(CompressJobInterface::class, function ($mXSQZ) {
            return new QVCQIo5YtGQYN(config('upload.maker'), Storage::disk('public'));
        });
        goto G3wWk;
        Ojq8l:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($mXSQZ) {
            return new OWgEPQwqOvtmY(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ypz7e;
        qPJr6:
        $this->app->singleton(ECHrJsgxCR7OQ::class, function () {
            return new TEgBbF7EqiUEB(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto yVkgp;
        yVkgp:
        $this->app->singleton(AYglkzXejDDAm::class, function ($mXSQZ) {
            return new AYglkzXejDDAm($mXSQZ->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto fb0lK;
        LYwtB:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($mXSQZ) {
            return new GJdfU4AysDtbA();
        });
        goto p3jxy;
        qDn9w:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
