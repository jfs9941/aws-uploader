<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\IEKt3iFXuaQha;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Encoder\QTx5zGpV1D5nP;
use Jfs\Uploader\Encoder\H23Olmd74uCyo;
use Jfs\Uploader\Service\ANTOKA6KWzE7t;
use Jfs\Uploader\Service\FileResolver\OCGSIUEk3it6k;
use Jfs\Uploader\Service\FileResolver\SRqyb2jR67DZL;
use Jfs\Uploader\Service\FileResolver\VZvrp1BOPL4ij;
use Jfs\Uploader\Service\Jobs\RiKa0AFj1NpUc;
use Jfs\Uploader\Service\Jobs\E2sByjkTI00yU;
use Jfs\Uploader\Service\Jobs\G3vPIVUoMhuCv;
use Jfs\Uploader\Service\Jobs\RmktOLti8ErWo;
use Jfs\Uploader\Service\Jobs\JuJYXo0vJuIAZ;
use Jfs\Uploader\Service\Jobs\JHHC2kywaX0sd;
use Jfs\Uploader\Service\Jobs\DMGQ9Xjdp3VxL;
use Jfs\Uploader\Service\Jobs\UC4wlRa58KkFd;
use Jfs\Uploader\Service\Jobs\GrVNK6ig7zvOa;
use Jfs\Uploader\Service\Jobs\F9RJ1S4hTeCdB;
use Jfs\Uploader\Service\B9bpWG3g8Q6mz;
use Jfs\Uploader\Service\KWcrk2FVuq9pZ;
use Jfs\Uploader\Service\NUNTQNmKEOem3;
use Jfs\Uploader\Service\M4zqWF6NkWe3n;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto yLhcC;
        hizRM:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($IMhHy) {
            return new M4zqWF6NkWe3n($IMhHy->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto m0CNI;
        SjPPU:
        $this->app->singleton(ANTOKA6KWzE7t::class, function ($IMhHy) {
            return new ANTOKA6KWzE7t($IMhHy->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto fBzxr;
        Gz3uF:
        $this->app->bind(MediaEncodeJobInterface::class, function ($IMhHy) {
            return new GrVNK6ig7zvOa(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto aQYx2;
        Qdl7t:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($IMhHy) {
            return new JuJYXo0vJuIAZ(config('upload.maker'), Storage::disk('public'));
        });
        goto Gz3uF;
        fBzxr:
        $this->app->singleton(B9bpWG3g8Q6mz::class, function ($IMhHy) {
            return new B9bpWG3g8Q6mz(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto qf43z;
        yLhcC:
        $this->app->bind(UploadServiceInterface::class, function ($IMhHy) {
            return new NUNTQNmKEOem3($IMhHy->make(ANTOKA6KWzE7t::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto hizRM;
        Tnz84:
        $this->app->bind(WatermarkTextJobInterface::class, function ($IMhHy) {
            return new F9RJ1S4hTeCdB(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto iKyqF;
        tqJwK:
        $this->app->bind(CompressJobInterface::class, function ($IMhHy) {
            return new G3vPIVUoMhuCv(config('upload.maker'), Storage::disk('public'));
        });
        goto JWBwA;
        W5spd:
        $this->app->tag([VZvrp1BOPL4ij::class, SRqyb2jR67DZL::class, OCGSIUEk3it6k::class], 'file.location.resolvers');
        goto wMLls;
        PQmOU:
        $this->app->bind(H23Olmd74uCyo::class, function ($IMhHy) {
            return new H23Olmd74uCyo(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto W5spd;
        wMLls:
        $this->app->bind(BlurJobInterface::class, function ($IMhHy) {
            return new RiKa0AFj1NpUc(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Og6jS;
        iKyqF:
        $this->app->bind(GalleryCloudInterface::class, function ($IMhHy) {
            return new IEKt3iFXuaQha();
        });
        goto V5VNn;
        m0CNI:
        $this->app->singleton(Yuf8dMzRcjZ21::class, function () {
            return new KWcrk2FVuq9pZ(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto SjPPU;
        ZNN6R:
        $this->app->bind(StoreToS3JobInterface::class, function ($IMhHy) {
            return new DMGQ9Xjdp3VxL(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto c951T;
        Og6jS:
        $this->app->bind(BlurVideoJobInterface::class, function ($IMhHy) {
            return new E2sByjkTI00yU(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto tqJwK;
        qf43z:
        $this->app->singleton(QTx5zGpV1D5nP::class, function ($IMhHy) {
            return new QTx5zGpV1D5nP($IMhHy->make(B9bpWG3g8Q6mz::class), Storage::disk('s3'));
        });
        goto PQmOU;
        JWBwA:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($IMhHy) {
            return new RmktOLti8ErWo(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Qdl7t;
        c951T:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($IMhHy) {
            return new UC4wlRa58KkFd(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Tnz84;
        aQYx2:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($IMhHy) {
            return new JHHC2kywaX0sd();
        });
        goto ZNN6R;
        V5VNn:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
