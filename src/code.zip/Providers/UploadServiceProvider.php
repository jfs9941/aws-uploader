<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\MOdNdLRLdg1gi;
use Jfs\Uploader\Contracts\VrVag0CyeQKdN;
use Jfs\Uploader\Encoder\Gp4Z40z5XsT8O;
use Jfs\Uploader\Encoder\QLlcCQX5acc3Y;
use Jfs\Uploader\Service\IsJEOSgV8mPOx;
use Jfs\Uploader\Service\FileResolver\EqUCMF0GFpf52;
use Jfs\Uploader\Service\FileResolver\HnIU38wZgiNSS;
use Jfs\Uploader\Service\FileResolver\XB7bGLKz5CnoV;
use Jfs\Uploader\Service\Jobs\KtcJDR2uF6Vca;
use Jfs\Uploader\Service\Jobs\Itv0XgFT5LYf2;
use Jfs\Uploader\Service\Jobs\DH1HW9dm6et7G;
use Jfs\Uploader\Service\Jobs\VxYi7ztJzQrYh;
use Jfs\Uploader\Service\Jobs\RtK6at3CRkntq;
use Jfs\Uploader\Service\Jobs\Qb6H2lXA5jPLg;
use Jfs\Uploader\Service\Jobs\HZhmY7rWGUNKn;
use Jfs\Uploader\Service\Jobs\L6eGDYualtpBX;
use Jfs\Uploader\Service\Jobs\OoSp5crnVWwoi;
use Jfs\Uploader\Service\Jobs\WhiS19Y9SdZdM;
use Jfs\Uploader\Service\R9h2iDidHZRXb;
use Jfs\Uploader\Service\GALKiO0auT3sq;
use Jfs\Uploader\Service\YwpLEKHQLPnj3;
use Jfs\Uploader\Service\MyogiksqjOJyS;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto tKbc6;
        DakEv:
        $this->app->singleton(R9h2iDidHZRXb::class, function ($ne8z6) {
            return new R9h2iDidHZRXb(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto gIYpo;
        AtpXJ:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($ne8z6) {
            return new L6eGDYualtpBX(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto VDZiX;
        VW8bS:
        $this->app->bind(MediaEncodeJobInterface::class, function ($ne8z6) {
            return new OoSp5crnVWwoi(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto txHzu;
        WoKtV:
        $this->app->bind(GalleryCloudInterface::class, function ($ne8z6) {
            return new MOdNdLRLdg1gi();
        });
        goto yfCp3;
        zIWyr:
        $this->app->tag([XB7bGLKz5CnoV::class, HnIU38wZgiNSS::class, EqUCMF0GFpf52::class], 'file.location.resolvers');
        goto gpYfX;
        wo8Gf:
        $this->app->bind(BlurVideoJobInterface::class, function ($ne8z6) {
            return new Itv0XgFT5LYf2(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto pFolQ;
        pFolQ:
        $this->app->bind(CompressJobInterface::class, function ($ne8z6) {
            return new DH1HW9dm6et7G(config('upload.maker'), Storage::disk('public'));
        });
        goto oxoKu;
        QNmMW:
        $this->app->singleton(IsJEOSgV8mPOx::class, function ($ne8z6) {
            return new IsJEOSgV8mPOx($ne8z6->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto DakEv;
        YHeBI:
        $this->app->bind(StoreToS3JobInterface::class, function ($ne8z6) {
            return new HZhmY7rWGUNKn(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto AtpXJ;
        oxoKu:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($ne8z6) {
            return new VxYi7ztJzQrYh(Storage::disk('s3'), Storage::disk('public'));
        });
        goto nEAFe;
        AhmL7:
        $this->app->bind(QLlcCQX5acc3Y::class, function ($ne8z6) {
            return new QLlcCQX5acc3Y(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto zIWyr;
        gpYfX:
        $this->app->bind(BlurJobInterface::class, function ($ne8z6) {
            return new KtcJDR2uF6Vca(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto wo8Gf;
        Bp4te:
        $this->app->singleton(VrVag0CyeQKdN::class, function () {
            return new GALKiO0auT3sq(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto QNmMW;
        nEAFe:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($ne8z6) {
            return new RtK6at3CRkntq(config('upload.maker'), Storage::disk('public'));
        });
        goto VW8bS;
        tKbc6:
        $this->app->bind(UploadServiceInterface::class, function ($ne8z6) {
            return new YwpLEKHQLPnj3($ne8z6->make(IsJEOSgV8mPOx::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto tMmuT;
        gIYpo:
        $this->app->singleton(Gp4Z40z5XsT8O::class, function ($ne8z6) {
            return new Gp4Z40z5XsT8O($ne8z6->make(R9h2iDidHZRXb::class), Storage::disk('s3'));
        });
        goto AhmL7;
        txHzu:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($ne8z6) {
            return new Qb6H2lXA5jPLg();
        });
        goto YHeBI;
        VDZiX:
        $this->app->bind(WatermarkTextJobInterface::class, function ($ne8z6) {
            return new WhiS19Y9SdZdM(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto WoKtV;
        tMmuT:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($ne8z6) {
            return new MyogiksqjOJyS($ne8z6->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Bp4te;
        yfCp3:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
