<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\D7QI1WB3tjv7r;
use Jfs\Uploader\Contracts\SRErb8bXZXjuL;
use Jfs\Uploader\Encoder\Q0BHItA6POhGn;
use Jfs\Uploader\Encoder\KrL5TSTQDAqUK;
use Jfs\Uploader\Service\B1HCEXUDgNNxk;
use Jfs\Uploader\Service\FileResolver\DK9N3MtKTUYcC;
use Jfs\Uploader\Service\FileResolver\SdKTImdUIFS2K;
use Jfs\Uploader\Service\FileResolver\HvEL5I10yFpwT;
use Jfs\Uploader\Service\Jobs\FkegjyoNFJs9n;
use Jfs\Uploader\Service\Jobs\OETqqRpOBuv1I;
use Jfs\Uploader\Service\Jobs\U067tOEktEiP1;
use Jfs\Uploader\Service\Jobs\ZxQfUjZ4fsjtv;
use Jfs\Uploader\Service\Jobs\FqiflHV2RkMkL;
use Jfs\Uploader\Service\Jobs\WTi0xLleXHLYV;
use Jfs\Uploader\Service\Jobs\HyC9ZPsJyxazv;
use Jfs\Uploader\Service\Jobs\Arzw85FFyUacX;
use Jfs\Uploader\Service\Jobs\Kl4Xdbgb1NkSh;
use Jfs\Uploader\Service\Jobs\QwjJ5ss7t10FU;
use Jfs\Uploader\Service\KA9RxVwCbkfZQ;
use Jfs\Uploader\Service\K2TtTNcFSFguA;
use Jfs\Uploader\Service\UzHeDJy3mfpAT;
use Jfs\Uploader\Service\F0v34VpoHC0r9;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto UqcQo;
        n5DxE:
        $this->app->singleton(B1HCEXUDgNNxk::class, function ($weH9u) {
            return new B1HCEXUDgNNxk($weH9u->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto kvwxr;
        Y53n_:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($weH9u) {
            return new WTi0xLleXHLYV();
        });
        goto HFf3K;
        fzz68:
        $this->app->bind(CompressJobInterface::class, function ($weH9u) {
            return new U067tOEktEiP1(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto KuXnO;
        UqcQo:
        $this->app->bind(UploadServiceInterface::class, function ($weH9u) {
            return new UzHeDJy3mfpAT($weH9u->make(B1HCEXUDgNNxk::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto wALyx;
        iCpiZ:
        $this->app->bind(KrL5TSTQDAqUK::class, function ($weH9u) {
            return new KrL5TSTQDAqUK(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto yXyis;
        cJiBN:
        $this->app->bind(BlurJobInterface::class, function ($weH9u) {
            return new FkegjyoNFJs9n(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto vMy6Q;
        O3ETT:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($weH9u) {
            return new FqiflHV2RkMkL(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto GooV_;
        yXyis:
        $this->app->tag([HvEL5I10yFpwT::class, SdKTImdUIFS2K::class, DK9N3MtKTUYcC::class], 'file.location.resolvers');
        goto cJiBN;
        wALyx:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($weH9u) {
            return new F0v34VpoHC0r9($weH9u->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto lA26B;
        KuXnO:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($weH9u) {
            return new ZxQfUjZ4fsjtv(Storage::disk('s3'), Storage::disk('public'));
        });
        goto O3ETT;
        vMy6Q:
        $this->app->bind(BlurVideoJobInterface::class, function ($weH9u) {
            return new OETqqRpOBuv1I(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto fzz68;
        kvwxr:
        $this->app->singleton(KA9RxVwCbkfZQ::class, function ($weH9u) {
            return new KA9RxVwCbkfZQ(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto QvOBs;
        FTQf2:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($weH9u) {
            return new Arzw85FFyUacX(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto sjy7r;
        oUY48:
        $this->app->bind(GalleryCloudInterface::class, function ($weH9u) {
            return new D7QI1WB3tjv7r();
        });
        goto miNkC;
        HFf3K:
        $this->app->bind(StoreToS3JobInterface::class, function ($weH9u) {
            return new HyC9ZPsJyxazv(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto FTQf2;
        GooV_:
        $this->app->bind(MediaEncodeJobInterface::class, function ($weH9u) {
            return new Kl4Xdbgb1NkSh(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto Y53n_;
        QvOBs:
        $this->app->singleton(Q0BHItA6POhGn::class, function ($weH9u) {
            return new Q0BHItA6POhGn($weH9u->make(KA9RxVwCbkfZQ::class), Storage::disk('s3'));
        });
        goto iCpiZ;
        lA26B:
        $this->app->singleton(SRErb8bXZXjuL::class, function () {
            return new K2TtTNcFSFguA(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto n5DxE;
        sjy7r:
        $this->app->bind(WatermarkTextJobInterface::class, function ($weH9u) {
            return new QwjJ5ss7t10FU(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto oUY48;
        miNkC:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
