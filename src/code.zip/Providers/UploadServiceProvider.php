<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\VBaUDvlE7QYCo;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Encoder\QuF8Qm4j71NF7;
use Jfs\Uploader\Encoder\CdioruI85bAAW;
use Jfs\Uploader\Service\AicOtR7ItsXZc;
use Jfs\Uploader\Service\FileResolver\WSTu5CxKi3ckv;
use Jfs\Uploader\Service\FileResolver\Rl1oBxbmxD3JI;
use Jfs\Uploader\Service\FileResolver\WDBWOTHBclxSq;
use Jfs\Uploader\Service\Jobs\P4OV7U2YuVFqE;
use Jfs\Uploader\Service\Jobs\UySP03caAkvlz;
use Jfs\Uploader\Service\Jobs\FDNNyhNt5HISu;
use Jfs\Uploader\Service\Jobs\NCXeXVNblAS8I;
use Jfs\Uploader\Service\Jobs\MDANzxDYEgmMk;
use Jfs\Uploader\Service\Jobs\I44Vegk5z0GAL;
use Jfs\Uploader\Service\Jobs\Z0qBcqYZD1txB;
use Jfs\Uploader\Service\Jobs\Cg5BSQdsKnyz3;
use Jfs\Uploader\Service\Jobs\Nakb8ddUAv9ks;
use Jfs\Uploader\Service\Jobs\QxCmYYAinhuSZ;
use Jfs\Uploader\Service\JCjpIXXHThkPb;
use Jfs\Uploader\Service\U8DiLJGk0mfB7;
use Jfs\Uploader\Service\MUA7XYPYpaXPj;
use Jfs\Uploader\Service\K9BQS1i37fxvm;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto yyN6r;
        GbRcG:
        $this->app->bind(StoreToS3JobInterface::class, function ($SiOFA) {
            return new Z0qBcqYZD1txB(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto l2OaP;
        oMtXM:
        $this->app->singleton(QuF8Qm4j71NF7::class, function ($SiOFA) {
            return new QuF8Qm4j71NF7($SiOFA->make(JCjpIXXHThkPb::class), Storage::disk('s3'));
        });
        goto B3gV9;
        I0b15:
        $this->app->bind(GalleryCloudInterface::class, function ($SiOFA) {
            return new VBaUDvlE7QYCo();
        });
        goto bDhr3;
        LcE2I:
        $this->app->singleton(JCjpIXXHThkPb::class, function ($SiOFA) {
            return new JCjpIXXHThkPb(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto oMtXM;
        k9VPj:
        $this->app->bind(BlurVideoJobInterface::class, function ($SiOFA) {
            return new UySP03caAkvlz(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto rllHG;
        B3gV9:
        $this->app->bind(CdioruI85bAAW::class, function ($SiOFA) {
            return new CdioruI85bAAW(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto bsJ0H;
        NCpGi:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($SiOFA) {
            return new MDANzxDYEgmMk(config('upload.maker'), Storage::disk('public'));
        });
        goto ZZd98;
        l2OaP:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($SiOFA) {
            return new Cg5BSQdsKnyz3(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ixUXu;
        B9pfz:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($SiOFA) {
            return new K9BQS1i37fxvm($SiOFA->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto qy9_U;
        vDkcX:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($SiOFA) {
            return new NCXeXVNblAS8I(Storage::disk('s3'), Storage::disk('public'));
        });
        goto NCpGi;
        zr5A9:
        $this->app->bind(BlurJobInterface::class, function ($SiOFA) {
            return new P4OV7U2YuVFqE(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto k9VPj;
        Mlc3j:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($SiOFA) {
            return new I44Vegk5z0GAL();
        });
        goto GbRcG;
        qy9_U:
        $this->app->singleton(E97atJzeJ1gs5::class, function () {
            return new U8DiLJGk0mfB7(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto cSFWt;
        ZZd98:
        $this->app->bind(MediaEncodeJobInterface::class, function ($SiOFA) {
            return new Nakb8ddUAv9ks(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto Mlc3j;
        cSFWt:
        $this->app->singleton(AicOtR7ItsXZc::class, function ($SiOFA) {
            return new AicOtR7ItsXZc($SiOFA->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto LcE2I;
        bsJ0H:
        $this->app->tag([WDBWOTHBclxSq::class, Rl1oBxbmxD3JI::class, WSTu5CxKi3ckv::class], 'file.location.resolvers');
        goto zr5A9;
        yyN6r:
        $this->app->bind(UploadServiceInterface::class, function ($SiOFA) {
            return new MUA7XYPYpaXPj($SiOFA->make(AicOtR7ItsXZc::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto B9pfz;
        ixUXu:
        $this->app->bind(WatermarkTextJobInterface::class, function ($SiOFA) {
            return new QxCmYYAinhuSZ(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto I0b15;
        rllHG:
        $this->app->bind(CompressJobInterface::class, function ($SiOFA) {
            return new FDNNyhNt5HISu(config('upload.maker'), Storage::disk('public'));
        });
        goto vDkcX;
        bDhr3:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
