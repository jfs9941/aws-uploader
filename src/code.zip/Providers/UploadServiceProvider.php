<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\E94a5bHUILBqo;
use Jfs\Uploader\Contracts\LQJLoPxiuxgfZ;
use Jfs\Uploader\Encoder\VNaEXNVKcqr6v;
use Jfs\Uploader\Encoder\YtOeto201sjfh;
use Jfs\Uploader\Service\XaaDhpdqTL9N3;
use Jfs\Uploader\Service\FileResolver\UyLF636DDCc1Y;
use Jfs\Uploader\Service\FileResolver\JnTu9srjsocnb;
use Jfs\Uploader\Service\FileResolver\UfSGg88XxSQs2;
use Jfs\Uploader\Service\Jobs\Pjc7ziAFrDbW8;
use Jfs\Uploader\Service\Jobs\IzTlBxDtBiIH0;
use Jfs\Uploader\Service\Jobs\NrByMq7i9Knt5;
use Jfs\Uploader\Service\Jobs\Rz5QzizFmN1lV;
use Jfs\Uploader\Service\Jobs\EeuBwwbhTRlwB;
use Jfs\Uploader\Service\Jobs\NxAwZoQC5RZsb;
use Jfs\Uploader\Service\Jobs\M3Xmvxbmi1S9y;
use Jfs\Uploader\Service\Jobs\YfUoFIujAyQF1;
use Jfs\Uploader\Service\Jobs\L8msOtDP8qgmS;
use Jfs\Uploader\Service\Jobs\McS3futGkobMF;
use Jfs\Uploader\Service\FpvVyCHYf1EbW;
use Jfs\Uploader\Service\WSEmT91tAxzKt;
use Jfs\Uploader\Service\YaVG5xtVyyTJo;
use Jfs\Uploader\Service\QdaCJ2uwiU7f3;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto B9XY5;
        B9XY5:
        $this->app->bind(UploadServiceInterface::class, function ($HrDn8) {
            return new YaVG5xtVyyTJo($HrDn8->make(XaaDhpdqTL9N3::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto rqYrS;
        MIjO4:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($HrDn8) {
            return new YfUoFIujAyQF1(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto sCETj;
        rqYrS:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($HrDn8) {
            return new QdaCJ2uwiU7f3($HrDn8->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto BeYCc;
        NSp2C:
        $this->app->tag([UfSGg88XxSQs2::class, JnTu9srjsocnb::class, UyLF636DDCc1Y::class], 'file.location.resolvers');
        goto sHQsL;
        sHQsL:
        $this->app->bind(BlurJobInterface::class, function ($HrDn8) {
            return new Pjc7ziAFrDbW8(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto DKurC;
        sCETj:
        $this->app->bind(WatermarkTextJobInterface::class, function ($HrDn8) {
            return new McS3futGkobMF(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto qLx1d;
        DKurC:
        $this->app->bind(BlurVideoJobInterface::class, function ($HrDn8) {
            return new IzTlBxDtBiIH0(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ejuLh;
        OMVuu:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($HrDn8) {
            return new EeuBwwbhTRlwB(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto P1ojt;
        To1Ub:
        $this->app->bind(StoreToS3JobInterface::class, function ($HrDn8) {
            return new M3Xmvxbmi1S9y(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto MIjO4;
        ZlVuz:
        $this->app->singleton(FpvVyCHYf1EbW::class, function ($HrDn8) {
            return new FpvVyCHYf1EbW(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto rosuE;
        wm6Sd:
        $this->app->bind(YtOeto201sjfh::class, function ($HrDn8) {
            return new YtOeto201sjfh(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto NSp2C;
        dne_H:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($HrDn8) {
            return new NxAwZoQC5RZsb();
        });
        goto To1Ub;
        qLx1d:
        $this->app->bind(GalleryCloudInterface::class, function ($HrDn8) {
            return new E94a5bHUILBqo();
        });
        goto i3QuS;
        JQnNM:
        $this->app->singleton(XaaDhpdqTL9N3::class, function ($HrDn8) {
            return new XaaDhpdqTL9N3($HrDn8->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ZlVuz;
        ejuLh:
        $this->app->bind(CompressJobInterface::class, function ($HrDn8) {
            return new NrByMq7i9Knt5(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto EYVa8;
        EYVa8:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($HrDn8) {
            return new Rz5QzizFmN1lV(Storage::disk('s3'), Storage::disk('public'));
        });
        goto OMVuu;
        rosuE:
        $this->app->singleton(VNaEXNVKcqr6v::class, function ($HrDn8) {
            return new VNaEXNVKcqr6v($HrDn8->make(FpvVyCHYf1EbW::class), Storage::disk('s3'));
        });
        goto wm6Sd;
        P1ojt:
        $this->app->bind(MediaEncodeJobInterface::class, function ($HrDn8) {
            return new L8msOtDP8qgmS(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto dne_H;
        BeYCc:
        $this->app->singleton(LQJLoPxiuxgfZ::class, function () {
            return new WSEmT91tAxzKt(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto JQnNM;
        i3QuS:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
