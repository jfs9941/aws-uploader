<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\DvLoYXfg5k6ye;
use Jfs\Uploader\Contracts\AbPtLXucv9ja8;
use Jfs\Uploader\Encoder\PBaAMCftTA2PY;
use Jfs\Uploader\Encoder\XNoKVl02kaW7f;
use Jfs\Uploader\Service\UkWgTCfbgTMD8;
use Jfs\Uploader\Service\FileResolver\VGeqORy1uZ4nY;
use Jfs\Uploader\Service\FileResolver\HrXgu8tN70dXp;
use Jfs\Uploader\Service\FileResolver\JCEzdBHx7ZcT4;
use Jfs\Uploader\Service\Jobs\BBqbZYARmfce1;
use Jfs\Uploader\Service\Jobs\KkScwFnedVqJt;
use Jfs\Uploader\Service\Jobs\GcKCYcdpK9Qwk;
use Jfs\Uploader\Service\Jobs\OwhDey8LQE6de;
use Jfs\Uploader\Service\Jobs\TYN4BeqY0zpXt;
use Jfs\Uploader\Service\Jobs\GgHzaYz2e0eoU;
use Jfs\Uploader\Service\Jobs\GV4Hx68IFb0Ap;
use Jfs\Uploader\Service\Jobs\LCkcFQiH4HWmr;
use Jfs\Uploader\Service\Jobs\XcZgi0c3uWmjG;
use Jfs\Uploader\Service\Jobs\IEmEByIZczjUB;
use Jfs\Uploader\Service\ZKiz9aeWXGIZz;
use Jfs\Uploader\Service\AkmCl9xAlobwb;
use Jfs\Uploader\Service\NHI9qC8LenJeR;
use Jfs\Uploader\Service\L5xFyis8kqkma;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto dMUi9;
        VsvXu:
        $this->app->bind(CompressJobInterface::class, function ($XXvQ6) {
            return new GcKCYcdpK9Qwk(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto gPlvL;
        k8Ug1:
        $this->app->singleton(UkWgTCfbgTMD8::class, function ($XXvQ6) {
            return new UkWgTCfbgTMD8($XXvQ6->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto eznNW;
        lXLAx:
        $this->app->bind(XNoKVl02kaW7f::class, function ($XXvQ6) {
            return new XNoKVl02kaW7f(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto VjZuV;
        dMUi9:
        $this->app->bind(UploadServiceInterface::class, function ($XXvQ6) {
            return new NHI9qC8LenJeR($XXvQ6->make(UkWgTCfbgTMD8::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto kqIaZ;
        dmAu4:
        $this->app->bind(WatermarkTextJobInterface::class, function ($XXvQ6) {
            return new IEmEByIZczjUB(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto PqdA1;
        n3Shj:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($XXvQ6) {
            return new LCkcFQiH4HWmr(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto dmAu4;
        LdZsI:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($XXvQ6) {
            return new TYN4BeqY0zpXt(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto aWrjv;
        aWrjv:
        $this->app->bind(MediaEncodeJobInterface::class, function ($XXvQ6) {
            return new XcZgi0c3uWmjG(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto WHekL;
        eznNW:
        $this->app->singleton(ZKiz9aeWXGIZz::class, function ($XXvQ6) {
            return new ZKiz9aeWXGIZz(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto EBbCh;
        WHekL:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($XXvQ6) {
            return new GgHzaYz2e0eoU();
        });
        goto uQ_kb;
        gPlvL:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($XXvQ6) {
            return new OwhDey8LQE6de(Storage::disk('s3'), Storage::disk('public'));
        });
        goto LdZsI;
        fbU7P:
        $this->app->bind(BlurVideoJobInterface::class, function ($XXvQ6) {
            return new KkScwFnedVqJt(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto VsvXu;
        kqIaZ:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($XXvQ6) {
            return new L5xFyis8kqkma($XXvQ6->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto LXXmO;
        QhRUF:
        $this->app->bind(BlurJobInterface::class, function ($XXvQ6) {
            return new BBqbZYARmfce1(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto fbU7P;
        LXXmO:
        $this->app->singleton(AbPtLXucv9ja8::class, function () {
            return new AkmCl9xAlobwb(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto k8Ug1;
        VjZuV:
        $this->app->tag([JCEzdBHx7ZcT4::class, HrXgu8tN70dXp::class, VGeqORy1uZ4nY::class], 'file.location.resolvers');
        goto QhRUF;
        uQ_kb:
        $this->app->bind(StoreToS3JobInterface::class, function ($XXvQ6) {
            return new GV4Hx68IFb0Ap(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto n3Shj;
        EBbCh:
        $this->app->singleton(PBaAMCftTA2PY::class, function ($XXvQ6) {
            return new PBaAMCftTA2PY($XXvQ6->make(ZKiz9aeWXGIZz::class), Storage::disk('s3'));
        });
        goto lXLAx;
        PqdA1:
        $this->app->bind(GalleryCloudInterface::class, function ($XXvQ6) {
            return new DvLoYXfg5k6ye();
        });
        goto PLzjE;
        PLzjE:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
