<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\R488buPG9MNDH;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Encoder\Koi3akneKfkiI;
use Jfs\Uploader\Encoder\HmpcWz3K8TIAu;
use Jfs\Uploader\Service\RLP5XS0nrqtBl;
use Jfs\Uploader\Service\FileResolver\MhGZofQ0pGMTt;
use Jfs\Uploader\Service\FileResolver\KKv6eM0LmrNkr;
use Jfs\Uploader\Service\FileResolver\PSTtViunkO6i5;
use Jfs\Uploader\Service\Jobs\Wbzft70CbxsnJ;
use Jfs\Uploader\Service\Jobs\U0eMlWUJpsRhi;
use Jfs\Uploader\Service\Jobs\Z8BkWVpDd4jFg;
use Jfs\Uploader\Service\Jobs\NACSeVoB7lM0a;
use Jfs\Uploader\Service\Jobs\YT4TKJO08txNA;
use Jfs\Uploader\Service\Jobs\DwSSl2FPmKKoS;
use Jfs\Uploader\Service\Jobs\MftCy2AXMeDi9;
use Jfs\Uploader\Service\Jobs\QxxyFIMkmTnPz;
use Jfs\Uploader\Service\Jobs\KKtNW0DDPuezX;
use Jfs\Uploader\Service\Jobs\Xq0MswJXBRMe6;
use Jfs\Uploader\Service\VmrgwQFNELOFc;
use Jfs\Uploader\Service\Df64o7d8ZEcB5;
use Jfs\Uploader\Service\W2KgpvTX4ze05;
use Jfs\Uploader\Service\HuNYafgkpKFHi;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto EjC6R;
        kAn25:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($iv9Nn) {
            return new YT4TKJO08txNA(config('upload.maker'), Storage::disk('public'));
        });
        goto BJ7eE;
        L2CGA:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($iv9Nn) {
            return new QxxyFIMkmTnPz(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto YeLNp;
        VOz5J:
        $this->app->bind(BlurVideoJobInterface::class, function ($iv9Nn) {
            return new U0eMlWUJpsRhi(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto cweCo;
        kNwzP:
        $this->app->singleton(RLP5XS0nrqtBl::class, function ($iv9Nn) {
            return new RLP5XS0nrqtBl($iv9Nn->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto BNJNw;
        xje3X:
        $this->app->bind(HmpcWz3K8TIAu::class, function ($iv9Nn) {
            return new HmpcWz3K8TIAu(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto B6iuh;
        BJ7eE:
        $this->app->bind(MediaEncodeJobInterface::class, function ($iv9Nn) {
            return new KKtNW0DDPuezX(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto eC1f0;
        UyjVU:
        $this->app->singleton(BEzZsfn3kKkr3::class, function () {
            return new Df64o7d8ZEcB5(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto kNwzP;
        B6iuh:
        $this->app->tag([PSTtViunkO6i5::class, KKv6eM0LmrNkr::class, MhGZofQ0pGMTt::class], 'file.location.resolvers');
        goto mtGCd;
        I5pK7:
        $this->app->singleton(Koi3akneKfkiI::class, function ($iv9Nn) {
            return new Koi3akneKfkiI($iv9Nn->make(VmrgwQFNELOFc::class), Storage::disk('s3'));
        });
        goto xje3X;
        mtGCd:
        $this->app->bind(BlurJobInterface::class, function ($iv9Nn) {
            return new Wbzft70CbxsnJ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto VOz5J;
        ryKAR:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($iv9Nn) {
            return new HuNYafgkpKFHi($iv9Nn->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto UyjVU;
        dGfqB:
        $this->app->bind(GalleryCloudInterface::class, function ($iv9Nn) {
            return new R488buPG9MNDH();
        });
        goto oBimt;
        YeLNp:
        $this->app->bind(WatermarkTextJobInterface::class, function ($iv9Nn) {
            return new Xq0MswJXBRMe6(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto dGfqB;
        Xn8Ai:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($iv9Nn) {
            return new NACSeVoB7lM0a(Storage::disk('s3'), Storage::disk('public'));
        });
        goto kAn25;
        EjC6R:
        $this->app->bind(UploadServiceInterface::class, function ($iv9Nn) {
            return new W2KgpvTX4ze05($iv9Nn->make(RLP5XS0nrqtBl::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto ryKAR;
        cweCo:
        $this->app->bind(CompressJobInterface::class, function ($iv9Nn) {
            return new Z8BkWVpDd4jFg(config('upload.maker'), Storage::disk('public'));
        });
        goto Xn8Ai;
        EpoH8:
        $this->app->bind(StoreToS3JobInterface::class, function ($iv9Nn) {
            return new MftCy2AXMeDi9(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto L2CGA;
        BNJNw:
        $this->app->singleton(VmrgwQFNELOFc::class, function ($iv9Nn) {
            return new VmrgwQFNELOFc(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto I5pK7;
        eC1f0:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($iv9Nn) {
            return new DwSSl2FPmKKoS();
        });
        goto EpoH8;
        oBimt:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
