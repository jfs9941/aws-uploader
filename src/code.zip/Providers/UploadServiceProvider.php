<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\M4njLDTMOF7To;
use Jfs\Uploader\Contracts\K0dipGcxtVboz;
use Jfs\Uploader\Encoder\GfGClJX90DRBN;
use Jfs\Uploader\Encoder\AZfEtdPfvJaWX;
use Jfs\Uploader\Service\GxQCvfot4aISP;
use Jfs\Uploader\Service\FileResolver\ZQyAzi2Ks3Ble;
use Jfs\Uploader\Service\FileResolver\MOGszupkY9R25;
use Jfs\Uploader\Service\FileResolver\E3GIwKWcHb7pO;
use Jfs\Uploader\Service\Jobs\V0uK13oOzmIi1;
use Jfs\Uploader\Service\Jobs\MhHB4RYsBoEkT;
use Jfs\Uploader\Service\Jobs\OpqQBTs2KV1dG;
use Jfs\Uploader\Service\Jobs\Ca7Q56pyzjVlo;
use Jfs\Uploader\Service\Jobs\VUqHyfzT9x00a;
use Jfs\Uploader\Service\Jobs\LDCjQXRpUGi7G;
use Jfs\Uploader\Service\Jobs\NfIVkJvjy5S9N;
use Jfs\Uploader\Service\Jobs\TIqax03JDcFL8;
use Jfs\Uploader\Service\Jobs\ZTXRDepAiJCzd;
use Jfs\Uploader\Service\Jobs\A1lArMwFsj8Rb;
use Jfs\Uploader\Service\O64LTP0s3gT1J;
use Jfs\Uploader\Service\FiQYSbwR1Ly8I;
use Jfs\Uploader\Service\JnEL1PIp86CN4;
use Jfs\Uploader\Service\PtQPpsdtUMxZM;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto f_b1q;
        mkPMn:
        $this->app->singleton(GxQCvfot4aISP::class, function ($mdbvd) {
            return new GxQCvfot4aISP($mdbvd->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto z7lw9;
        yaYI_:
        $this->app->tag([E3GIwKWcHb7pO::class, MOGszupkY9R25::class, ZQyAzi2Ks3Ble::class], 'file.location.resolvers');
        goto YFxbO;
        MFIdc:
        $this->app->bind(AZfEtdPfvJaWX::class, function ($mdbvd) {
            return new AZfEtdPfvJaWX(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto yaYI_;
        NY2v4:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($mdbvd) {
            return new PtQPpsdtUMxZM($mdbvd->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto SnLLd;
        pU_P1:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($mdbvd) {
            return new Ca7Q56pyzjVlo(Storage::disk('s3'), Storage::disk('public'));
        });
        goto wTu2I;
        Cx9WK:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($mdbvd) {
            return new TIqax03JDcFL8(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto bzHuy;
        z7lw9:
        $this->app->singleton(O64LTP0s3gT1J::class, function ($mdbvd) {
            return new O64LTP0s3gT1J(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto SS1ww;
        Zz7sf:
        $this->app->bind(GalleryCloudInterface::class, function ($mdbvd) {
            return new M4njLDTMOF7To();
        });
        goto roIu_;
        SS1ww:
        $this->app->singleton(GfGClJX90DRBN::class, function ($mdbvd) {
            return new GfGClJX90DRBN($mdbvd->make(O64LTP0s3gT1J::class), Storage::disk('s3'));
        });
        goto MFIdc;
        WiKRO:
        $this->app->bind(StoreToS3JobInterface::class, function ($mdbvd) {
            return new NfIVkJvjy5S9N(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Cx9WK;
        SnLLd:
        $this->app->singleton(K0dipGcxtVboz::class, function () {
            return new FiQYSbwR1Ly8I(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto mkPMn;
        YFxbO:
        $this->app->bind(BlurJobInterface::class, function ($mdbvd) {
            return new V0uK13oOzmIi1(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto jEysu;
        bzHuy:
        $this->app->bind(WatermarkTextJobInterface::class, function ($mdbvd) {
            return new A1lArMwFsj8Rb(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto Zz7sf;
        wTu2I:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($mdbvd) {
            return new VUqHyfzT9x00a(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto oh6Xv;
        jEysu:
        $this->app->bind(BlurVideoJobInterface::class, function ($mdbvd) {
            return new MhHB4RYsBoEkT(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Hd3Lb;
        a_GtZ:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($mdbvd) {
            return new LDCjQXRpUGi7G();
        });
        goto WiKRO;
        f_b1q:
        $this->app->bind(UploadServiceInterface::class, function ($mdbvd) {
            return new JnEL1PIp86CN4($mdbvd->make(GxQCvfot4aISP::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto NY2v4;
        Hd3Lb:
        $this->app->bind(CompressJobInterface::class, function ($mdbvd) {
            return new OpqQBTs2KV1dG(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto pU_P1;
        oh6Xv:
        $this->app->bind(MediaEncodeJobInterface::class, function ($mdbvd) {
            return new ZTXRDepAiJCzd(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto a_GtZ;
        roIu_:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
