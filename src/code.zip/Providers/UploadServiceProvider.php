<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\OYQwG3YORcksS;
use Jfs\Uploader\Contracts\PmQuktZiUDRAI;
use Jfs\Uploader\Encoder\A8w0sFEmIyJGd;
use Jfs\Uploader\Encoder\AOVLsclrMzgAM;
use Jfs\Uploader\Service\QPQBXT5xv2KsY;
use Jfs\Uploader\Service\FileResolver\VbBSM5aWQGxqj;
use Jfs\Uploader\Service\FileResolver\KD0PGR8YZihQ4;
use Jfs\Uploader\Service\FileResolver\YROYWGZPpSnNT;
use Jfs\Uploader\Service\Jobs\YBW4JNfYayQMJ;
use Jfs\Uploader\Service\Jobs\FA3PJ8mQILvi5;
use Jfs\Uploader\Service\Jobs\ZQm0oVQOJfE5U;
use Jfs\Uploader\Service\Jobs\EWoKOYpvUgSdR;
use Jfs\Uploader\Service\Jobs\SnHstyQ6PaKCL;
use Jfs\Uploader\Service\Jobs\BOAU8n9Skufmh;
use Jfs\Uploader\Service\Jobs\SQD0BQGV2sv5m;
use Jfs\Uploader\Service\Jobs\Pp54Ji7b1cVMH;
use Jfs\Uploader\Service\Jobs\DT7LIbPLPGE68;
use Jfs\Uploader\Service\Jobs\WGP0OYATm1caa;
use Jfs\Uploader\Service\WqQUjHBw41oKQ;
use Jfs\Uploader\Service\QVXDWzQlJsLPv;
use Jfs\Uploader\Service\YtxSak1ZpKSPX;
use Jfs\Uploader\Service\X2HBGfsI2UG6f;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto VxoeN;
        V0_n0:
        $this->app->bind(BlurJobInterface::class, function ($Xv8uP) {
            return new YBW4JNfYayQMJ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto fp_0z;
        YpxDe:
        $this->app->bind(StoreToS3JobInterface::class, function ($Xv8uP) {
            return new SQD0BQGV2sv5m(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto J9013;
        VxoeN:
        $this->app->bind(UploadServiceInterface::class, function ($Xv8uP) {
            return new YtxSak1ZpKSPX($Xv8uP->make(QPQBXT5xv2KsY::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto d13S7;
        y5XJQ:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Xv8uP) {
            return new BOAU8n9Skufmh();
        });
        goto YpxDe;
        COOZm:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Xv8uP) {
            return new SnHstyQ6PaKCL(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto OVNBf;
        s0C7i:
        $this->app->singleton(A8w0sFEmIyJGd::class, function ($Xv8uP) {
            return new A8w0sFEmIyJGd($Xv8uP->make(WqQUjHBw41oKQ::class), Storage::disk('s3'));
        });
        goto FE__a;
        XvYMl:
        $this->app->bind(CompressJobInterface::class, function ($Xv8uP) {
            return new ZQm0oVQOJfE5U(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto pCA3s;
        Sgyi6:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Xv8uP) {
            return new WGP0OYATm1caa(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto xfc5d;
        OVNBf:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Xv8uP) {
            return new DT7LIbPLPGE68(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto y5XJQ;
        fp_0z:
        $this->app->bind(BlurVideoJobInterface::class, function ($Xv8uP) {
            return new FA3PJ8mQILvi5(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto XvYMl;
        d13S7:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Xv8uP) {
            return new X2HBGfsI2UG6f($Xv8uP->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Ja4Ja;
        RI2Au:
        $this->app->tag([YROYWGZPpSnNT::class, KD0PGR8YZihQ4::class, VbBSM5aWQGxqj::class], 'file.location.resolvers');
        goto V0_n0;
        y8gf6:
        $this->app->singleton(WqQUjHBw41oKQ::class, function ($Xv8uP) {
            return new WqQUjHBw41oKQ(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto s0C7i;
        ELZTc:
        $this->app->singleton(QPQBXT5xv2KsY::class, function ($Xv8uP) {
            return new QPQBXT5xv2KsY($Xv8uP->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto y8gf6;
        J9013:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Xv8uP) {
            return new Pp54Ji7b1cVMH(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Sgyi6;
        Ja4Ja:
        $this->app->singleton(PmQuktZiUDRAI::class, function () {
            return new QVXDWzQlJsLPv(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto ELZTc;
        pCA3s:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Xv8uP) {
            return new EWoKOYpvUgSdR(Storage::disk('s3'), Storage::disk('public'));
        });
        goto COOZm;
        FE__a:
        $this->app->bind(AOVLsclrMzgAM::class, function ($Xv8uP) {
            return new AOVLsclrMzgAM(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto RI2Au;
        xfc5d:
        $this->app->bind(GalleryCloudInterface::class, function ($Xv8uP) {
            return new OYQwG3YORcksS();
        });
        goto IqJH6;
        IqJH6:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
