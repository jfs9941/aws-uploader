<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\PZKEJigPoqvhr;
use Jfs\Uploader\Contracts\Dm945121dFKVW;
use Jfs\Uploader\Encoder\O4lVkPvpn6cme;
use Jfs\Uploader\Encoder\FhlmmSZhUQ7B8;
use Jfs\Uploader\Service\Sr0k4NPxeSoLY;
use Jfs\Uploader\Service\FileResolver\QExWxPokjFmrd;
use Jfs\Uploader\Service\FileResolver\SDHydf9U3mbGd;
use Jfs\Uploader\Service\FileResolver\Td4a3HeA19oCJ;
use Jfs\Uploader\Service\Jobs\QfZfxZgRu0hzx;
use Jfs\Uploader\Service\Jobs\QzbCAADkZlRcJ;
use Jfs\Uploader\Service\Jobs\ZEjl3CTvWgBC7;
use Jfs\Uploader\Service\Jobs\D1vCpLdf7hzzL;
use Jfs\Uploader\Service\Jobs\F8s64tWMvnbqf;
use Jfs\Uploader\Service\Jobs\IZKRSdkDOxm73;
use Jfs\Uploader\Service\Jobs\IkVJWlo3nFZFD;
use Jfs\Uploader\Service\Jobs\WLRx7CTWBmKZA;
use Jfs\Uploader\Service\Jobs\Kj8R2ay3IQqos;
use Jfs\Uploader\Service\Jobs\AMgNoueOnZlUa;
use Jfs\Uploader\Service\XxTGlKndb3r5q;
use Jfs\Uploader\Service\QNlFAcHy60ycp;
use Jfs\Uploader\Service\Dp3MBIkJYF9HF;
use Jfs\Uploader\Service\HOcLtbuRdsQQO;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto woP8q;
        ZJjYo:
        $this->app->bind(StoreToS3JobInterface::class, function ($pP4pE) {
            return new IkVJWlo3nFZFD(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Xgm7Z;
        mGmc8:
        $this->app->bind(CompressJobInterface::class, function ($pP4pE) {
            return new ZEjl3CTvWgBC7(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Qf5QJ;
        xPqzj:
        $this->app->bind(MediaEncodeJobInterface::class, function ($pP4pE) {
            return new Kj8R2ay3IQqos(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto NhyHB;
        mBJym:
        $this->app->bind(BlurVideoJobInterface::class, function ($pP4pE) {
            return new QzbCAADkZlRcJ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto mGmc8;
        qxM63:
        $this->app->singleton(Dm945121dFKVW::class, function () {
            return new QNlFAcHy60ycp(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto XHX9x;
        JLUJa:
        $this->app->bind(WatermarkTextJobInterface::class, function ($pP4pE) {
            return new AMgNoueOnZlUa(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto xtrJK;
        woP8q:
        $this->app->bind(UploadServiceInterface::class, function ($pP4pE) {
            return new Dp3MBIkJYF9HF($pP4pE->make(Sr0k4NPxeSoLY::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto yNI7c;
        SKTz6:
        $this->app->singleton(O4lVkPvpn6cme::class, function ($pP4pE) {
            return new O4lVkPvpn6cme($pP4pE->make(XxTGlKndb3r5q::class), Storage::disk('s3'));
        });
        goto RNIOA;
        NWmyi:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($pP4pE) {
            return new F8s64tWMvnbqf(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto xPqzj;
        Xgm7Z:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($pP4pE) {
            return new WLRx7CTWBmKZA(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto JLUJa;
        yNI7c:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($pP4pE) {
            return new HOcLtbuRdsQQO($pP4pE->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto qxM63;
        Qf5QJ:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($pP4pE) {
            return new D1vCpLdf7hzzL(Storage::disk('s3'), Storage::disk('public'));
        });
        goto NWmyi;
        F1vWk:
        $this->app->singleton(XxTGlKndb3r5q::class, function ($pP4pE) {
            return new XxTGlKndb3r5q(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto SKTz6;
        RNIOA:
        $this->app->bind(FhlmmSZhUQ7B8::class, function ($pP4pE) {
            return new FhlmmSZhUQ7B8(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto KfaBL;
        KfaBL:
        $this->app->tag([Td4a3HeA19oCJ::class, SDHydf9U3mbGd::class, QExWxPokjFmrd::class], 'file.location.resolvers');
        goto pcz3N;
        pcz3N:
        $this->app->bind(BlurJobInterface::class, function ($pP4pE) {
            return new QfZfxZgRu0hzx(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto mBJym;
        xtrJK:
        $this->app->bind(GalleryCloudInterface::class, function ($pP4pE) {
            return new PZKEJigPoqvhr();
        });
        goto xre5D;
        NhyHB:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($pP4pE) {
            return new IZKRSdkDOxm73();
        });
        goto ZJjYo;
        XHX9x:
        $this->app->singleton(Sr0k4NPxeSoLY::class, function ($pP4pE) {
            return new Sr0k4NPxeSoLY($pP4pE->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto F1vWk;
        xre5D:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
