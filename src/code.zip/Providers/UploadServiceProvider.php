<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\MJSkBSumOTOvu;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Encoder\R1OfWFis73GHj;
use Jfs\Uploader\Encoder\PSvg4a6rPX3zY;
use Jfs\Uploader\Service\VRKkgi2bc4uRE;
use Jfs\Uploader\Service\FileResolver\NOVlArkNeFw2x;
use Jfs\Uploader\Service\FileResolver\Fr7834gvyQ8c2;
use Jfs\Uploader\Service\FileResolver\RJnv1it5FKNoM;
use Jfs\Uploader\Service\Jobs\DatZnpgcIAVnT;
use Jfs\Uploader\Service\Jobs\QH7g3jAWabotx;
use Jfs\Uploader\Service\Jobs\NUuJh7gYX8WkE;
use Jfs\Uploader\Service\Jobs\Vgs13ZVzwh4OK;
use Jfs\Uploader\Service\Jobs\HatHllS8Fo9Jk;
use Jfs\Uploader\Service\Jobs\WF4mDTL139IMZ;
use Jfs\Uploader\Service\Jobs\Cj6myNPs7MmOn;
use Jfs\Uploader\Service\Jobs\DdBdaWRDt30CD;
use Jfs\Uploader\Service\Jobs\SMCVIfKYGqQpy;
use Jfs\Uploader\Service\Jobs\ISYdOYeli4oBf;
use Jfs\Uploader\Service\BDt6SdH8IQ07z;
use Jfs\Uploader\Service\QBWgN1d5cwk0P;
use Jfs\Uploader\Service\Fun0V0xDniUvh;
use Jfs\Uploader\Service\DxquITWcbl47J;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto CGYSo;
        VF_ea:
        $this->app->singleton(HqWA5DdMiDW1U::class, function () {
            return new QBWgN1d5cwk0P(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto M_jWI;
        CGYSo:
        $this->app->bind(UploadServiceInterface::class, function ($vS231) {
            return new Fun0V0xDniUvh($vS231->make(VRKkgi2bc4uRE::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto gKj5A;
        M_jWI:
        $this->app->singleton(VRKkgi2bc4uRE::class, function ($vS231) {
            return new VRKkgi2bc4uRE($vS231->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SKWv2;
        D3XsR:
        $this->app->bind(PSvg4a6rPX3zY::class, function ($vS231) {
            return new PSvg4a6rPX3zY(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto iKcFe;
        LW_o0:
        $this->app->bind(WatermarkTextJobInterface::class, function ($vS231) {
            return new ISYdOYeli4oBf(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto uffxV;
        uffxV:
        $this->app->bind(GalleryCloudInterface::class, function ($vS231) {
            return new MJSkBSumOTOvu();
        });
        goto kVoek;
        SvBC9:
        $this->app->bind(CompressJobInterface::class, function ($vS231) {
            return new NUuJh7gYX8WkE(config('upload.maker'), Storage::disk('public'));
        });
        goto tZkKI;
        Tx1O6:
        $this->app->bind(MediaEncodeJobInterface::class, function ($vS231) {
            return new SMCVIfKYGqQpy(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto lF66l;
        mRqIa:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($vS231) {
            return new DdBdaWRDt30CD(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto LW_o0;
        G5TAg:
        $this->app->singleton(R1OfWFis73GHj::class, function ($vS231) {
            return new R1OfWFis73GHj($vS231->make(BDt6SdH8IQ07z::class), Storage::disk('s3'));
        });
        goto D3XsR;
        lF66l:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($vS231) {
            return new WF4mDTL139IMZ();
        });
        goto FpHl7;
        h2CjJ:
        $this->app->bind(BlurJobInterface::class, function ($vS231) {
            return new DatZnpgcIAVnT(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto oLwQH;
        FpHl7:
        $this->app->bind(StoreToS3JobInterface::class, function ($vS231) {
            return new Cj6myNPs7MmOn(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto mRqIa;
        yx2Ra:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($vS231) {
            return new HatHllS8Fo9Jk(config('upload.maker'), Storage::disk('public'));
        });
        goto Tx1O6;
        oLwQH:
        $this->app->bind(BlurVideoJobInterface::class, function ($vS231) {
            return new QH7g3jAWabotx(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto SvBC9;
        SKWv2:
        $this->app->singleton(BDt6SdH8IQ07z::class, function ($vS231) {
            return new BDt6SdH8IQ07z(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto G5TAg;
        tZkKI:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($vS231) {
            return new Vgs13ZVzwh4OK(Storage::disk('s3'), Storage::disk('public'));
        });
        goto yx2Ra;
        iKcFe:
        $this->app->tag([RJnv1it5FKNoM::class, Fr7834gvyQ8c2::class, NOVlArkNeFw2x::class], 'file.location.resolvers');
        goto h2CjJ;
        gKj5A:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($vS231) {
            return new DxquITWcbl47J($vS231->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto VF_ea;
        kVoek:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
