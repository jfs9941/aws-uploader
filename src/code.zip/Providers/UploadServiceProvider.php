<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\PGx0PxlUmQSuc;
use Jfs\Uploader\Contracts\Jhd15nso8PpYk;
use Jfs\Uploader\Encoder\FSb1vbQf2TVPX;
use Jfs\Uploader\Encoder\Y6FiBoyfJXwAc;
use Jfs\Uploader\Service\VQRb8yFeCwEOC;
use Jfs\Uploader\Service\FileResolver\AQmx4EUHopTcV;
use Jfs\Uploader\Service\FileResolver\O5YIxXxoitxIy;
use Jfs\Uploader\Service\FileResolver\CDcuArOllQrjI;
use Jfs\Uploader\Service\Jobs\WSym8BT460sEi;
use Jfs\Uploader\Service\Jobs\TaD0t1Qa5RBo8;
use Jfs\Uploader\Service\Jobs\R4p1iB7rUs4yU;
use Jfs\Uploader\Service\Jobs\Nb2Z0Nwe5Clkx;
use Jfs\Uploader\Service\Jobs\RlK5kQJKh8JXQ;
use Jfs\Uploader\Service\Jobs\OqJPoAnPhPJem;
use Jfs\Uploader\Service\Jobs\RXP9Rz5iM4rFH;
use Jfs\Uploader\Service\Jobs\KOeKE7qZsdPoS;
use Jfs\Uploader\Service\Jobs\LKkvz1qFhNZOK;
use Jfs\Uploader\Service\Jobs\L4Q9FvQSntfVP;
use Jfs\Uploader\Service\KiBRYQgrRVRtv;
use Jfs\Uploader\Service\H0nWMZBOapaJq;
use Jfs\Uploader\Service\UJeFcSXtJOW66;
use Jfs\Uploader\Service\VubK8U88WJUPq;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto pgryK;
        Hv57f:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($o67mK) {
            return new RlK5kQJKh8JXQ(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto LvQME;
        M0iJl:
        $this->app->singleton(Jhd15nso8PpYk::class, function () {
            return new H0nWMZBOapaJq(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto KaJ0R;
        V_4hD:
        $this->app->bind(StoreToS3JobInterface::class, function ($o67mK) {
            return new RXP9Rz5iM4rFH(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto KkmSC;
        QI6v1:
        $this->app->bind(BlurVideoJobInterface::class, function ($o67mK) {
            return new TaD0t1Qa5RBo8(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto nMgIY;
        SAi0x:
        $this->app->bind(GalleryCloudInterface::class, function ($o67mK) {
            return new PGx0PxlUmQSuc();
        });
        goto j5ycc;
        LvQME:
        $this->app->bind(MediaEncodeJobInterface::class, function ($o67mK) {
            return new LKkvz1qFhNZOK(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto zXw45;
        J5um9:
        $this->app->singleton(KiBRYQgrRVRtv::class, function ($o67mK) {
            return new KiBRYQgrRVRtv(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto v1yiW;
        nMgIY:
        $this->app->bind(CompressJobInterface::class, function ($o67mK) {
            return new R4p1iB7rUs4yU(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ynxqD;
        KaJ0R:
        $this->app->singleton(VQRb8yFeCwEOC::class, function ($o67mK) {
            return new VQRb8yFeCwEOC($o67mK->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto J5um9;
        zXw45:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($o67mK) {
            return new OqJPoAnPhPJem();
        });
        goto V_4hD;
        UyoVq:
        $this->app->bind(WatermarkTextJobInterface::class, function ($o67mK) {
            return new L4Q9FvQSntfVP(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto SAi0x;
        LXTI8:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($o67mK) {
            return new VubK8U88WJUPq($o67mK->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto M0iJl;
        pgryK:
        $this->app->bind(UploadServiceInterface::class, function ($o67mK) {
            return new UJeFcSXtJOW66($o67mK->make(VQRb8yFeCwEOC::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto LXTI8;
        v1yiW:
        $this->app->singleton(FSb1vbQf2TVPX::class, function ($o67mK) {
            return new FSb1vbQf2TVPX($o67mK->make(KiBRYQgrRVRtv::class), Storage::disk('s3'));
        });
        goto n3V0y;
        KkmSC:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($o67mK) {
            return new KOeKE7qZsdPoS(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto UyoVq;
        ynxqD:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($o67mK) {
            return new Nb2Z0Nwe5Clkx(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Hv57f;
        MIeNB:
        $this->app->tag([CDcuArOllQrjI::class, O5YIxXxoitxIy::class, AQmx4EUHopTcV::class], 'file.location.resolvers');
        goto P7b5t;
        n3V0y:
        $this->app->bind(Y6FiBoyfJXwAc::class, function ($o67mK) {
            return new Y6FiBoyfJXwAc(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto MIeNB;
        P7b5t:
        $this->app->bind(BlurJobInterface::class, function ($o67mK) {
            return new WSym8BT460sEi(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto QI6v1;
        j5ycc:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
