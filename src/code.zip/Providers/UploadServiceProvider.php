<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\KBPvzEE1A4UOK;
use Jfs\Uploader\Contracts\VwiVLFCuZN4fA;
use Jfs\Uploader\Encoder\Suk3MOIJcOQzt;
use Jfs\Uploader\Encoder\Evs9C2DhMDeMD;
use Jfs\Uploader\Service\P8Uf7dWabbyOG;
use Jfs\Uploader\Service\FileResolver\TNxNnnB971PQM;
use Jfs\Uploader\Service\FileResolver\K0zGVX3RNNwTB;
use Jfs\Uploader\Service\FileResolver\FNC7Nl9pXDCXV;
use Jfs\Uploader\Service\Jobs\WINFTU8An4GCx;
use Jfs\Uploader\Service\Jobs\Pcrrr4MQUNu8A;
use Jfs\Uploader\Service\Jobs\KivHERUZb00Ql;
use Jfs\Uploader\Service\Jobs\GwraMaH3spWuw;
use Jfs\Uploader\Service\Jobs\U0lMXXZ5ASfal;
use Jfs\Uploader\Service\Jobs\GcUirPy7BFSXk;
use Jfs\Uploader\Service\Jobs\EP2SK4ZMKCeRA;
use Jfs\Uploader\Service\Jobs\SiDF171XuEmgz;
use Jfs\Uploader\Service\Jobs\HliNbM0W1zC88;
use Jfs\Uploader\Service\Jobs\UcmPGbxqyx1OH;
use Jfs\Uploader\Service\CbfzS01NR7tQ9;
use Jfs\Uploader\Service\M9fyBFwLMDM67;
use Jfs\Uploader\Service\BS00SqGVe7o8q;
use Jfs\Uploader\Service\J9b9g2FPlehZj;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto Qdla9;
        yHaRt:
        $this->app->tag([FNC7Nl9pXDCXV::class, K0zGVX3RNNwTB::class, TNxNnnB971PQM::class], 'file.location.resolvers');
        goto vzIXK;
        z5gd1:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Es0et) {
            return new J9b9g2FPlehZj($Es0et->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto b3Pba;
        vzIXK:
        $this->app->bind(BlurJobInterface::class, function ($Es0et) {
            return new WINFTU8An4GCx(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto q6kxW;
        xQ0p0:
        $this->app->singleton(P8Uf7dWabbyOG::class, function ($Es0et) {
            return new P8Uf7dWabbyOG($Es0et->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto UBgUT;
        UBgUT:
        $this->app->singleton(CbfzS01NR7tQ9::class, function ($Es0et) {
            return new CbfzS01NR7tQ9(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto mA3ZJ;
        HbanS:
        $this->app->bind(Evs9C2DhMDeMD::class, function ($Es0et) {
            return new Evs9C2DhMDeMD(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto yHaRt;
        m2b7k:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Es0et) {
            return new UcmPGbxqyx1OH(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto RZdjL;
        azYmX:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Es0et) {
            return new U0lMXXZ5ASfal(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto lYuh7;
        njXcC:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Es0et) {
            return new GcUirPy7BFSXk();
        });
        goto i11VY;
        Qdla9:
        $this->app->bind(UploadServiceInterface::class, function ($Es0et) {
            return new BS00SqGVe7o8q($Es0et->make(P8Uf7dWabbyOG::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto z5gd1;
        b3Pba:
        $this->app->singleton(VwiVLFCuZN4fA::class, function () {
            return new M9fyBFwLMDM67(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto xQ0p0;
        lYuh7:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Es0et) {
            return new HliNbM0W1zC88(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto njXcC;
        j7RQR:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Es0et) {
            return new SiDF171XuEmgz(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto m2b7k;
        q6kxW:
        $this->app->bind(BlurVideoJobInterface::class, function ($Es0et) {
            return new Pcrrr4MQUNu8A(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto H5PzD;
        RZdjL:
        $this->app->bind(GalleryCloudInterface::class, function ($Es0et) {
            return new KBPvzEE1A4UOK();
        });
        goto fR0oL;
        mA3ZJ:
        $this->app->singleton(Suk3MOIJcOQzt::class, function ($Es0et) {
            return new Suk3MOIJcOQzt($Es0et->make(CbfzS01NR7tQ9::class), Storage::disk('s3'));
        });
        goto HbanS;
        H5PzD:
        $this->app->bind(CompressJobInterface::class, function ($Es0et) {
            return new KivHERUZb00Ql(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto NThkW;
        NThkW:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Es0et) {
            return new GwraMaH3spWuw(Storage::disk('s3'), Storage::disk('public'));
        });
        goto azYmX;
        i11VY:
        $this->app->bind(StoreToS3JobInterface::class, function ($Es0et) {
            return new EP2SK4ZMKCeRA(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto j7RQR;
        fR0oL:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
