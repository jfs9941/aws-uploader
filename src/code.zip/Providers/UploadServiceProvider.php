<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\GEgxmVnAZrsfm;
use Jfs\Uploader\Contracts\I85IcZZcCMm6R;
use Jfs\Uploader\Encoder\UTfSplvy0DRyY;
use Jfs\Uploader\Encoder\GQRImhPfYt9CY;
use Jfs\Uploader\Service\Zw7bfX6K3W60S;
use Jfs\Uploader\Service\FileResolver\XzIZvPzCu8uF3;
use Jfs\Uploader\Service\FileResolver\Q0QgDhq0ZzEFM;
use Jfs\Uploader\Service\FileResolver\QcSqUPo50IH8F;
use Jfs\Uploader\Service\Jobs\LPjpCCMFqwtFR;
use Jfs\Uploader\Service\Jobs\VeXyYPsf3v7Rv;
use Jfs\Uploader\Service\Jobs\DQ2FAeCOVTEFE;
use Jfs\Uploader\Service\Jobs\Q9qPrwYvftR6E;
use Jfs\Uploader\Service\Jobs\T7CMdJNsD1FiS;
use Jfs\Uploader\Service\Jobs\KTES0s1SCiErU;
use Jfs\Uploader\Service\Jobs\NDiMryD1mDYX0;
use Jfs\Uploader\Service\Jobs\LUtAQ1Dj0DdF0;
use Jfs\Uploader\Service\Jobs\JXp9fT6TZJwNb;
use Jfs\Uploader\Service\Jobs\P92sPAuWW03N6;
use Jfs\Uploader\Service\MNNH4c3TCQoPL;
use Jfs\Uploader\Service\FYmIfeFQO9W7H;
use Jfs\Uploader\Service\IEJ9ncEgkzor9;
use Jfs\Uploader\Service\Ye2U3ORizqL1J;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto F1PMu;
        CArde:
        $this->app->singleton(UTfSplvy0DRyY::class, function ($U701G) {
            return new UTfSplvy0DRyY($U701G->make(MNNH4c3TCQoPL::class), Storage::disk('s3'));
        });
        goto ADp5T;
        fhBBP:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($U701G) {
            return new Ye2U3ORizqL1J($U701G->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto tPqpx;
        DzZeU:
        $this->app->bind(GalleryCloudInterface::class, function ($U701G) {
            return new GEgxmVnAZrsfm();
        });
        goto acf0p;
        ZKQpx:
        $this->app->bind(BlurVideoJobInterface::class, function ($U701G) {
            return new VeXyYPsf3v7Rv(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ftL4o;
        YseXo:
        $this->app->bind(MediaEncodeJobInterface::class, function ($U701G) {
            return new JXp9fT6TZJwNb(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto v9r6E;
        tPqpx:
        $this->app->singleton(I85IcZZcCMm6R::class, function () {
            return new FYmIfeFQO9W7H(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto ID5FN;
        vxb0p:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($U701G) {
            return new LUtAQ1Dj0DdF0(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto kkzqJ;
        ADp5T:
        $this->app->bind(GQRImhPfYt9CY::class, function ($U701G) {
            return new GQRImhPfYt9CY(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto caxqw;
        kkzqJ:
        $this->app->bind(WatermarkTextJobInterface::class, function ($U701G) {
            return new P92sPAuWW03N6(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto DzZeU;
        v9r6E:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($U701G) {
            return new KTES0s1SCiErU();
        });
        goto d1jvh;
        ID5FN:
        $this->app->singleton(Zw7bfX6K3W60S::class, function ($U701G) {
            return new Zw7bfX6K3W60S($U701G->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto szefR;
        szefR:
        $this->app->singleton(MNNH4c3TCQoPL::class, function ($U701G) {
            return new MNNH4c3TCQoPL(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto CArde;
        caxqw:
        $this->app->tag([QcSqUPo50IH8F::class, Q0QgDhq0ZzEFM::class, XzIZvPzCu8uF3::class], 'file.location.resolvers');
        goto aKmpj;
        F1PMu:
        $this->app->bind(UploadServiceInterface::class, function ($U701G) {
            return new IEJ9ncEgkzor9($U701G->make(Zw7bfX6K3W60S::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto fhBBP;
        ftL4o:
        $this->app->bind(CompressJobInterface::class, function ($U701G) {
            return new DQ2FAeCOVTEFE(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto NQCtI;
        aKmpj:
        $this->app->bind(BlurJobInterface::class, function ($U701G) {
            return new LPjpCCMFqwtFR(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ZKQpx;
        MH5oC:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($U701G) {
            return new T7CMdJNsD1FiS(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto YseXo;
        NQCtI:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($U701G) {
            return new Q9qPrwYvftR6E(Storage::disk('s3'), Storage::disk('public'));
        });
        goto MH5oC;
        d1jvh:
        $this->app->bind(StoreToS3JobInterface::class, function ($U701G) {
            return new NDiMryD1mDYX0(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto vxb0p;
        acf0p:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
