<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

declare (strict_types=1);
namespace src;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Uploader\Service\DVTM10SQ2B4z3;
use src\Gallery\Service\MtcMGKmPLuFIX;
use src\Uploader\Contracts\MGwfEiRGIYlUs;
use src\Uploader\Encoder\CqIfz7C8PXyW1;
use src\Uploader\Encoder\SgVYdb34TZ3jy;
use src\Uploader\Service\BVykbOopwUKwx;
use src\Uploader\Service\FileResolver\Bp1dPQAlyY5ZG;
use src\Uploader\Service\FileResolver\DW6fwyai6DZqb;
use src\Uploader\Service\FileResolver\IENXz77Sy47vF;
use src\Uploader\Service\FtIk1ybHOJjaq;
use src\Uploader\Service\Jobs\AwGmBZFRTNTxI;
use src\Uploader\Service\Jobs\DI8u2F85sjfcm;
use src\Uploader\Service\Jobs\DUgUsbfTgkyq2;
use src\Uploader\Service\Jobs\Qj7VgmJfGZBVj;
use src\Uploader\Service\Jobs\QQvjRM8pgb9fV;
use src\Uploader\Service\Jobs\V9CWSktTGV1t6;
use src\Uploader\Service\Jobs\WQObxLQQvFOOe;
use src\Uploader\Service\Jobs\WZrAOwClqUV8d;
use src\Uploader\Service\Jobs\XS2NgkMncp7H2;
use src\Uploader\Service\Jobs\ZP0zVc8Tj5QCR;
use src\Uploader\Service\KqR0KCt0ft284;
use src\Uploader\Service\TMv85L5ZRTfOP;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto fOKdd;
        e_8Qz:
        $this->app->singleton(CqIfz7C8PXyW1::class, function ($gHBlb) {
            return new CqIfz7C8PXyW1($gHBlb->make(BVykbOopwUKwx::class), Storage::disk('s3'));
        });
        goto rEFSJ;
        ZTWQN:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($gHBlb) {
            return new WQObxLQQvFOOe();
        });
        goto zOWpm;
        zOWpm:
        $this->app->bind(StoreToS3JobInterface::class, function ($gHBlb) {
            return new ZP0zVc8Tj5QCR(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto we0Wz;
        Y2UMj:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($gHBlb) {
            return new XS2NgkMncp7H2(Storage::disk('s3'), Storage::disk('public'));
        });
        goto GNzRm;
        AkxGn:
        $this->app->singleton(MGwfEiRGIYlUs::class, function () {
            return new FtIk1ybHOJjaq(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto P89bP;
        fpdi2:
        $this->app->bind(BlurJobInterface::class, function ($gHBlb) {
            return new DUgUsbfTgkyq2(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto N7JXP;
        koJp2:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($gHBlb) {
            return new DVTM10SQ2B4z3($gHBlb->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto AkxGn;
        psyrJ:
        $this->app->bind(MediaEncodeJobInterface::class, function ($gHBlb) {
            return new V9CWSktTGV1t6(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto ZTWQN;
        P89bP:
        $this->app->singleton(TMv85L5ZRTfOP::class, function ($gHBlb) {
            return new TMv85L5ZRTfOP($gHBlb->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto sIEJZ;
        N7JXP:
        $this->app->bind(BlurVideoJobInterface::class, function ($gHBlb) {
            return new Qj7VgmJfGZBVj(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto gN1zQ;
        f1wU2:
        $this->app->tag([DW6fwyai6DZqb::class, IENXz77Sy47vF::class, Bp1dPQAlyY5ZG::class], 'file.location.resolvers');
        goto fpdi2;
        we0Wz:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($gHBlb) {
            return new DI8u2F85sjfcm(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto k7df7;
        GNzRm:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($gHBlb) {
            return new QQvjRM8pgb9fV(config('upload.maker'), Storage::disk('public'));
        });
        goto psyrJ;
        gN1zQ:
        $this->app->bind(CompressJobInterface::class, function ($gHBlb) {
            return new AwGmBZFRTNTxI(config('upload.maker'), Storage::disk('public'));
        });
        goto Y2UMj;
        fOKdd:
        $this->app->bind(UploadServiceInterface::class, function ($gHBlb) {
            return new KqR0KCt0ft284($gHBlb->make(TMv85L5ZRTfOP::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto koJp2;
        rEFSJ:
        $this->app->bind(SgVYdb34TZ3jy::class, function ($gHBlb) {
            return new SgVYdb34TZ3jy(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto f1wU2;
        k7df7:
        $this->app->bind(WatermarkTextJobInterface::class, function ($gHBlb) {
            return new WZrAOwClqUV8d(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto ljzp4;
        sIEJZ:
        $this->app->singleton(BVykbOopwUKwx::class, function ($gHBlb) {
            return new BVykbOopwUKwx(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto e_8Qz;
        ljzp4:
        $this->app->bind(GalleryCloudInterface::class, function ($gHBlb) {
            return new MtcMGKmPLuFIX();
        });
        goto MaSst;
        MaSst:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
