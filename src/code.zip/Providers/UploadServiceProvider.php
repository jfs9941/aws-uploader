<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace backup;

use Aws\MediaConvert\MediaConvertClient;
use backup\Exposed\Am3Ua9F8YERkp;
use backup\Exposed\Jobs\Kl3clWXNabHsa;
use backup\Exposed\Jobs\ZqqMnnLm0bshs;
use backup\Exposed\Jobs\BUMikUMmdvq7W;
use backup\Exposed\Jobs\PKlJoGnL129oy;
use backup\Exposed\Jobs\BAg6f47W8nEsi;
use backup\Exposed\Jobs\MdimVmV9yOs45;
use backup\Exposed\Jobs\ArHGBW3uhkrTN;
use backup\Exposed\Jobs\SdQaPOKj9eEdP;
use backup\Exposed\Jobs\O8CX6EuYCei1T;
use backup\Exposed\Jobs\DKKTuKFrzfZ51;
use backup\Exposed\ArCSgsnvTg6Tv;
use backup\Exposed\MWQEI3qnbYMuU;
use backup\Gallery\Service\HklcydyJAVS1s;
use backup\Uploader\Contracts\NTBMTa29AeaJq;
use backup\Uploader\Encoder\LZk9dEYagFbfv;
use backup\Uploader\Encoder\ZfSpbyoegtO09;
use backup\Uploader\Service\IJhG5F6LYY6Bm;
use backup\Uploader\Service\FileResolver\V5bG2LjR6NHvU;
use backup\Uploader\Service\FileResolver\TsXQKr79wRPcD;
use backup\Uploader\Service\FileResolver\PHqHiQfIgYlWK;
use backup\Uploader\Service\Jobs\RqOrW03KyLHEH;
use backup\Uploader\Service\Jobs\VdpemzuNhazRt;
use backup\Uploader\Service\Jobs\BjuzinLCgVkZl;
use backup\Uploader\Service\Jobs\B97GgB35i7hKl;
use backup\Uploader\Service\Jobs\N8QZCKh8bqKKO;
use backup\Uploader\Service\Jobs\IgPMkhtyewSZ9;
use backup\Uploader\Service\Jobs\I5hp1HqCQ16sC;
use backup\Uploader\Service\Jobs\Am402HUeF85Yj;
use backup\Uploader\Service\Jobs\SaQQK3QqJsRP8;
use backup\Uploader\Service\Jobs\MPUnLVyVSoH7N;
use backup\Uploader\Service\HgXaT629cXC5e;
use backup\Uploader\Service\QHNWNb4yKCpvh;
use backup\Uploader\Service\ZRCryMN7FHJvx;
use backup\Uploader\Service\KIh0BHt1RPyHU;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto VwLeB;
        OsUq3:
        $this->app->bind(SdQaPOKj9eEdP::class, function ($CJk8M) {
            return new I5hp1HqCQ16sC(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto g0HEl;
        FzMrM:
        $this->app->bind(BUMikUMmdvq7W::class, function ($CJk8M) {
            return new BjuzinLCgVkZl(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto dcFu1;
        YCeBa:
        $this->app->bind(MWQEI3qnbYMuU::class, function ($CJk8M) {
            return new KIh0BHt1RPyHU($CJk8M->make(ArCSgsnvTg6Tv::class), Storage::disk('s3'));
        });
        goto sZ2RD;
        Ozyuz:
        $this->app->bind(ZqqMnnLm0bshs::class, function ($CJk8M) {
            return new VdpemzuNhazRt(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto FzMrM;
        fjLpD:
        $this->app->bind(Am3Ua9F8YERkp::class, function ($CJk8M) {
            return new HklcydyJAVS1s();
        });
        goto EHNI4;
        mYEKW:
        $this->app->bind(ZfSpbyoegtO09::class, function ($CJk8M) {
            return new ZfSpbyoegtO09(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto SLcK6;
        eXhYr:
        $this->app->bind(BAg6f47W8nEsi::class, function ($CJk8M) {
            return new N8QZCKh8bqKKO(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SckHw;
        SckHw:
        $this->app->bind(MdimVmV9yOs45::class, function ($CJk8M) {
            return new SaQQK3QqJsRP8(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto aNUOp;
        AjCbY:
        $this->app->singleton(LZk9dEYagFbfv::class, function ($CJk8M) {
            return new LZk9dEYagFbfv($CJk8M->make(HgXaT629cXC5e::class), Storage::disk('s3'));
        });
        goto mYEKW;
        PIKjz:
        $this->app->bind(DKKTuKFrzfZ51::class, function ($CJk8M) {
            return new MPUnLVyVSoH7N(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto fjLpD;
        aNUOp:
        $this->app->bind(ArHGBW3uhkrTN::class, function ($CJk8M) {
            return new IgPMkhtyewSZ9();
        });
        goto OsUq3;
        g0HEl:
        $this->app->bind(O8CX6EuYCei1T::class, function ($CJk8M) {
            return new Am402HUeF85Yj(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto PIKjz;
        VwLeB:
        $this->app->bind(ArCSgsnvTg6Tv::class, function ($CJk8M) {
            return new ZRCryMN7FHJvx($CJk8M->make(IJhG5F6LYY6Bm::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto YCeBa;
        SLcK6:
        $this->app->tag([PHqHiQfIgYlWK::class, TsXQKr79wRPcD::class, V5bG2LjR6NHvU::class], 'file.location.resolvers');
        goto La1QB;
        dcFu1:
        $this->app->bind(PKlJoGnL129oy::class, function ($CJk8M) {
            return new B97GgB35i7hKl(Storage::disk('s3'), Storage::disk('public'));
        });
        goto eXhYr;
        bIRrQ:
        $this->app->singleton(IJhG5F6LYY6Bm::class, function ($CJk8M) {
            return new IJhG5F6LYY6Bm($CJk8M->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto G0WmF;
        G0WmF:
        $this->app->singleton(HgXaT629cXC5e::class, function ($CJk8M) {
            return new HgXaT629cXC5e(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto AjCbY;
        La1QB:
        $this->app->bind(Kl3clWXNabHsa::class, function ($CJk8M) {
            return new RqOrW03KyLHEH(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Ozyuz;
        sZ2RD:
        $this->app->singleton(NTBMTa29AeaJq::class, function () {
            return new QHNWNb4yKCpvh(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto bIRrQ;
        EHNI4:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
