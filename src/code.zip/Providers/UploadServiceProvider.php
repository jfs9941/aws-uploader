<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\B38tXjPCvNZ7f;
use Jfs\Uploader\Contracts\VdjamMvtIkwfN;
use Jfs\Uploader\Encoder\FKhlIfmeSlJUJ;
use Jfs\Uploader\Encoder\Hm4pS3oE1MMiy;
use Jfs\Uploader\Service\EJdnYZtMjtUUp;
use Jfs\Uploader\Service\FileResolver\R2kw85On66Rwn;
use Jfs\Uploader\Service\FileResolver\D3qhwpI60OqBf;
use Jfs\Uploader\Service\FileResolver\N63arDmw8Ftr8;
use Jfs\Uploader\Service\Jobs\PZjWL3TcIm7Pu;
use Jfs\Uploader\Service\Jobs\ZV7rzOxLGIOtP;
use Jfs\Uploader\Service\Jobs\WnOYy6ffBDUEl;
use Jfs\Uploader\Service\Jobs\ZDalWVzV8uSQP;
use Jfs\Uploader\Service\Jobs\J6dPhRQ5icZd8;
use Jfs\Uploader\Service\Jobs\DR8onqABR7YTb;
use Jfs\Uploader\Service\Jobs\SmsNKqbzjpIKf;
use Jfs\Uploader\Service\Jobs\Aey2EfoFbVvmA;
use Jfs\Uploader\Service\Jobs\W03K6BdJTUbwH;
use Jfs\Uploader\Service\Jobs\OY2ZIWJSJBs6v;
use Jfs\Uploader\Service\TUSrCGJanJHY8;
use Jfs\Uploader\Service\BA8ePy1ftd8cO;
use Jfs\Uploader\Service\GhJcjgLYvxYxE;
use Jfs\Uploader\Service\DcNRnLlhneedN;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto JIflx;
        WkJTd:
        $this->app->bind(BlurVideoJobInterface::class, function ($FuULR) {
            return new ZV7rzOxLGIOtP(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto SkOqc;
        SkOqc:
        $this->app->bind(CompressJobInterface::class, function ($FuULR) {
            return new WnOYy6ffBDUEl(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto G8XRG;
        VYtI9:
        $this->app->singleton(TUSrCGJanJHY8::class, function ($FuULR) {
            return new TUSrCGJanJHY8(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto N0YI0;
        JIflx:
        $this->app->bind(UploadServiceInterface::class, function ($FuULR) {
            return new GhJcjgLYvxYxE($FuULR->make(EJdnYZtMjtUUp::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto ZV7r2;
        RPkwQ:
        $this->app->bind(GalleryCloudInterface::class, function ($FuULR) {
            return new B38tXjPCvNZ7f();
        });
        goto S3Dbw;
        N0YI0:
        $this->app->singleton(FKhlIfmeSlJUJ::class, function ($FuULR) {
            return new FKhlIfmeSlJUJ($FuULR->make(TUSrCGJanJHY8::class), Storage::disk('s3'));
        });
        goto yxwXW;
        uz5XP:
        $this->app->singleton(VdjamMvtIkwfN::class, function () {
            return new BA8ePy1ftd8cO(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto mxqRk;
        z_Mey:
        $this->app->bind(StoreToS3JobInterface::class, function ($FuULR) {
            return new SmsNKqbzjpIKf(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto x4kVc;
        RQ310:
        $this->app->bind(BlurJobInterface::class, function ($FuULR) {
            return new PZjWL3TcIm7Pu(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto WkJTd;
        whWmw:
        $this->app->bind(MediaEncodeJobInterface::class, function ($FuULR) {
            return new W03K6BdJTUbwH(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto sAp2b;
        yxwXW:
        $this->app->bind(Hm4pS3oE1MMiy::class, function ($FuULR) {
            return new Hm4pS3oE1MMiy(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto BIikR;
        sAp2b:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($FuULR) {
            return new DR8onqABR7YTb();
        });
        goto z_Mey;
        BIikR:
        $this->app->tag([N63arDmw8Ftr8::class, D3qhwpI60OqBf::class, R2kw85On66Rwn::class], 'file.location.resolvers');
        goto RQ310;
        ZV7r2:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($FuULR) {
            return new DcNRnLlhneedN($FuULR->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto uz5XP;
        llKWZ:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($FuULR) {
            return new J6dPhRQ5icZd8(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto whWmw;
        nKp3g:
        $this->app->bind(WatermarkTextJobInterface::class, function ($FuULR) {
            return new OY2ZIWJSJBs6v(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto RPkwQ;
        G8XRG:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($FuULR) {
            return new ZDalWVzV8uSQP(Storage::disk('s3'), Storage::disk('public'));
        });
        goto llKWZ;
        x4kVc:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($FuULR) {
            return new Aey2EfoFbVvmA(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto nKp3g;
        mxqRk:
        $this->app->singleton(EJdnYZtMjtUUp::class, function ($FuULR) {
            return new EJdnYZtMjtUUp($FuULR->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto VYtI9;
        S3Dbw:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
