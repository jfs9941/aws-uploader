<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\TGvnyVZeZiXRC;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Uploader\Encoder\LzL89H4g6zwMz;
use Jfs\Uploader\Encoder\Z4OscliFEOmvr;
use Jfs\Uploader\Service\SPtrbk9kcnPEI;
use Jfs\Uploader\Service\FileResolver\CnKhndYLty9KW;
use Jfs\Uploader\Service\FileResolver\V3i0CuYSuJ7aD;
use Jfs\Uploader\Service\FileResolver\PxBPKfBRWbX2v;
use Jfs\Uploader\Service\Jobs\C1begswuMLD8K;
use Jfs\Uploader\Service\Jobs\KnQmZrjGrW8qz;
use Jfs\Uploader\Service\Jobs\FGw3qXsCOExxu;
use Jfs\Uploader\Service\Jobs\B3VZoRysOCjzj;
use Jfs\Uploader\Service\Jobs\WS55QHeCkNTn0;
use Jfs\Uploader\Service\Jobs\NLBQaelXAGK8F;
use Jfs\Uploader\Service\Jobs\PbRgcyVVWzH3Y;
use Jfs\Uploader\Service\Jobs\ErpEE0aoAkNcZ;
use Jfs\Uploader\Service\Jobs\KhCq0pLQJiSZU;
use Jfs\Uploader\Service\Jobs\OgNzZDvUX93rg;
use Jfs\Uploader\Service\WK3vb1oP6Xm31;
use Jfs\Uploader\Service\JNMuh7Oo3jHTF;
use Jfs\Uploader\Service\WHlU6fbS2AP5Y;
use Jfs\Uploader\Service\QvYupJP8OKMno;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto SwXw4;
        SwXw4:
        $this->app->bind(UploadServiceInterface::class, function ($Zu9qm) {
            return new WHlU6fbS2AP5Y($Zu9qm->make(SPtrbk9kcnPEI::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto ZMY_u;
        d8c2E:
        $this->app->bind(Z4OscliFEOmvr::class, function ($Zu9qm) {
            return new Z4OscliFEOmvr(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto Q4b2_;
        luqrK:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Zu9qm) {
            return new ErpEE0aoAkNcZ(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto f39U7;
        CCKQA:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Zu9qm) {
            return new NLBQaelXAGK8F();
        });
        goto wbYfs;
        crdwG:
        $this->app->bind(BlurVideoJobInterface::class, function ($Zu9qm) {
            return new KnQmZrjGrW8qz(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto HqRjU;
        Q4b2_:
        $this->app->tag([PxBPKfBRWbX2v::class, V3i0CuYSuJ7aD::class, CnKhndYLty9KW::class], 'file.location.resolvers');
        goto vRR7e;
        ZMY_u:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Zu9qm) {
            return new QvYupJP8OKMno($Zu9qm->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto mBZ9H;
        gCCXD:
        $this->app->singleton(SPtrbk9kcnPEI::class, function ($Zu9qm) {
            return new SPtrbk9kcnPEI($Zu9qm->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SFoIJ;
        iEfNy:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Zu9qm) {
            return new WS55QHeCkNTn0(config('upload.maker'), Storage::disk('public'));
        });
        goto CCFbo;
        HqRjU:
        $this->app->bind(CompressJobInterface::class, function ($Zu9qm) {
            return new FGw3qXsCOExxu(config('upload.maker'), Storage::disk('public'));
        });
        goto clDIq;
        f39U7:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Zu9qm) {
            return new OgNzZDvUX93rg(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto MA8Q2;
        MA8Q2:
        $this->app->bind(GalleryCloudInterface::class, function ($Zu9qm) {
            return new TGvnyVZeZiXRC();
        });
        goto cU5XL;
        SFoIJ:
        $this->app->singleton(WK3vb1oP6Xm31::class, function ($Zu9qm) {
            return new WK3vb1oP6Xm31(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto fx7v5;
        fx7v5:
        $this->app->singleton(LzL89H4g6zwMz::class, function ($Zu9qm) {
            return new LzL89H4g6zwMz($Zu9qm->make(WK3vb1oP6Xm31::class), Storage::disk('s3'));
        });
        goto d8c2E;
        CCFbo:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Zu9qm) {
            return new KhCq0pLQJiSZU(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto CCKQA;
        vRR7e:
        $this->app->bind(BlurJobInterface::class, function ($Zu9qm) {
            return new C1begswuMLD8K(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto crdwG;
        wbYfs:
        $this->app->bind(StoreToS3JobInterface::class, function ($Zu9qm) {
            return new PbRgcyVVWzH3Y(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto luqrK;
        mBZ9H:
        $this->app->singleton(QhwgYzl056fwk::class, function () {
            return new JNMuh7Oo3jHTF(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto gCCXD;
        clDIq:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Zu9qm) {
            return new B3VZoRysOCjzj(Storage::disk('s3'), Storage::disk('public'));
        });
        goto iEfNy;
        cU5XL:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
