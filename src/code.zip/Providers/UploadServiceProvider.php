<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\Or9CzXSuJl8wJ;
use Jfs\Uploader\Contracts\PZ7iLyA8MUs3A;
use Jfs\Uploader\Encoder\EVSDjuMy24t33;
use Jfs\Uploader\Encoder\MeWuDqb0fEhjz;
use Jfs\Uploader\Service\ZZ32LbChqQKFG;
use Jfs\Uploader\Service\FileResolver\MIJKNbKaQTcPb;
use Jfs\Uploader\Service\FileResolver\QsruakCqjsXAo;
use Jfs\Uploader\Service\FileResolver\XZbfUi1P0SQ51;
use Jfs\Uploader\Service\Jobs\NeB6vgUzAuVqg;
use Jfs\Uploader\Service\Jobs\IlP9qJIfRBYoX;
use Jfs\Uploader\Service\Jobs\AZUhkCrRnVX0J;
use Jfs\Uploader\Service\Jobs\YCwZ9hv6elAw6;
use Jfs\Uploader\Service\Jobs\P38GAy8os1kzz;
use Jfs\Uploader\Service\Jobs\SxPld9RPz1NNE;
use Jfs\Uploader\Service\Jobs\Mz7gU1sAJkoAF;
use Jfs\Uploader\Service\Jobs\UKVXmWnxnT4qp;
use Jfs\Uploader\Service\Jobs\T06efLboGzHGR;
use Jfs\Uploader\Service\Jobs\OAbv666w6Kulu;
use Jfs\Uploader\Service\Lqd1WdK14h5gQ;
use Jfs\Uploader\Service\Gu99j9QqeoWGc;
use Jfs\Uploader\Service\NEgSZo0taipsZ;
use Jfs\Uploader\Service\Jc47CzpIEpA0Q;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto UJzsg;
        CpZmO:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($PasGX) {
            return new YCwZ9hv6elAw6(Storage::disk('s3'), Storage::disk('public'));
        });
        goto MH7NY;
        oQkzG:
        $this->app->bind(BlurVideoJobInterface::class, function ($PasGX) {
            return new IlP9qJIfRBYoX(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto uVa51;
        khHrD:
        $this->app->singleton(PZ7iLyA8MUs3A::class, function () {
            return new Gu99j9QqeoWGc(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto n269D;
        IvjYR:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($PasGX) {
            return new UKVXmWnxnT4qp(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto LYGyE;
        UJzsg:
        $this->app->bind(UploadServiceInterface::class, function ($PasGX) {
            return new NEgSZo0taipsZ($PasGX->make(ZZ32LbChqQKFG::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto xc9Wh;
        kSguP:
        $this->app->tag([XZbfUi1P0SQ51::class, QsruakCqjsXAo::class, MIJKNbKaQTcPb::class], 'file.location.resolvers');
        goto oPsPF;
        OKMj6:
        $this->app->bind(GalleryCloudInterface::class, function ($PasGX) {
            return new Or9CzXSuJl8wJ();
        });
        goto F0DnN;
        uVa51:
        $this->app->bind(CompressJobInterface::class, function ($PasGX) {
            return new AZUhkCrRnVX0J(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto CpZmO;
        LYGyE:
        $this->app->bind(WatermarkTextJobInterface::class, function ($PasGX) {
            return new OAbv666w6Kulu(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto OKMj6;
        CPX3B:
        $this->app->singleton(EVSDjuMy24t33::class, function ($PasGX) {
            return new EVSDjuMy24t33($PasGX->make(Lqd1WdK14h5gQ::class), Storage::disk('s3'));
        });
        goto MSqjq;
        MH7NY:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($PasGX) {
            return new P38GAy8os1kzz(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Klo8Y;
        n269D:
        $this->app->singleton(ZZ32LbChqQKFG::class, function ($PasGX) {
            return new ZZ32LbChqQKFG($PasGX->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto yXH6c;
        xc9Wh:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($PasGX) {
            return new Jc47CzpIEpA0Q($PasGX->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto khHrD;
        MSqjq:
        $this->app->bind(MeWuDqb0fEhjz::class, function ($PasGX) {
            return new MeWuDqb0fEhjz(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto kSguP;
        fkREp:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($PasGX) {
            return new SxPld9RPz1NNE();
        });
        goto COB41;
        Klo8Y:
        $this->app->bind(MediaEncodeJobInterface::class, function ($PasGX) {
            return new T06efLboGzHGR(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto fkREp;
        yXH6c:
        $this->app->singleton(Lqd1WdK14h5gQ::class, function ($PasGX) {
            return new Lqd1WdK14h5gQ(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto CPX3B;
        COB41:
        $this->app->bind(StoreToS3JobInterface::class, function ($PasGX) {
            return new Mz7gU1sAJkoAF(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto IvjYR;
        oPsPF:
        $this->app->bind(BlurJobInterface::class, function ($PasGX) {
            return new NeB6vgUzAuVqg(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto oQkzG;
        F0DnN:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
