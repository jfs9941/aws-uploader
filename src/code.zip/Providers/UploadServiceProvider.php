<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\TkzWkdBbZ9D4r;
use Jfs\Uploader\Contracts\PJnSZopfp7dgp;
use Jfs\Uploader\Encoder\Hi0YtDTyJNN8c;
use Jfs\Uploader\Encoder\MXvBi3Q4qWy8O;
use Jfs\Uploader\Service\WhUSFqM1jr0Xc;
use Jfs\Uploader\Service\FileResolver\AM0Cfr3JnBdUK;
use Jfs\Uploader\Service\FileResolver\Z046VXgU0coEq;
use Jfs\Uploader\Service\FileResolver\BNKj2B1P7cOGL;
use Jfs\Uploader\Service\Jobs\UvXtLLaeBf8re;
use Jfs\Uploader\Service\Jobs\VRFlZJuiku6Dd;
use Jfs\Uploader\Service\Jobs\DaLnPasuV5QUI;
use Jfs\Uploader\Service\Jobs\VeYPDc1VawAJp;
use Jfs\Uploader\Service\Jobs\AxCKKV4Rc3F3G;
use Jfs\Uploader\Service\Jobs\QRNhQFCjAtDfH;
use Jfs\Uploader\Service\Jobs\EFlLcRSeg6URA;
use Jfs\Uploader\Service\Jobs\MIXStt9i96Hmf;
use Jfs\Uploader\Service\Jobs\EFybiIZ9Fidir;
use Jfs\Uploader\Service\Jobs\Q4zVFQDwWcjY8;
use Jfs\Uploader\Service\W3p5fQJLFcnvJ;
use Jfs\Uploader\Service\ZzJrrZ7pIAAWV;
use Jfs\Uploader\Service\L9tBhjUbEacRR;
use Jfs\Uploader\Service\DQUjnzZGBNcVM;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto H4tmk;
        CiwYc:
        $this->app->bind(CompressJobInterface::class, function ($JkMc1) {
            return new DaLnPasuV5QUI(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto BVm53;
        cy3Jf:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($JkMc1) {
            return new AxCKKV4Rc3F3G(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto fkpR2;
        COj72:
        $this->app->bind(GalleryCloudInterface::class, function ($JkMc1) {
            return new TkzWkdBbZ9D4r();
        });
        goto qB2Ij;
        R4EYb:
        $this->app->bind(BlurVideoJobInterface::class, function ($JkMc1) {
            return new VRFlZJuiku6Dd(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto CiwYc;
        UpBo6:
        $this->app->singleton(Hi0YtDTyJNN8c::class, function ($JkMc1) {
            return new Hi0YtDTyJNN8c($JkMc1->make(W3p5fQJLFcnvJ::class), Storage::disk('s3'));
        });
        goto BMFtb;
        gIIyh:
        $this->app->tag([BNKj2B1P7cOGL::class, Z046VXgU0coEq::class, AM0Cfr3JnBdUK::class], 'file.location.resolvers');
        goto O3fTi;
        BVm53:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($JkMc1) {
            return new VeYPDc1VawAJp(Storage::disk('s3'), Storage::disk('public'));
        });
        goto cy3Jf;
        CiVbH:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($JkMc1) {
            return new DQUjnzZGBNcVM($JkMc1->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto HzTlU;
        O3fTi:
        $this->app->bind(BlurJobInterface::class, function ($JkMc1) {
            return new UvXtLLaeBf8re(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto R4EYb;
        qxW0k:
        $this->app->bind(StoreToS3JobInterface::class, function ($JkMc1) {
            return new EFlLcRSeg6URA(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto OtmeQ;
        A6isN:
        $this->app->singleton(W3p5fQJLFcnvJ::class, function ($JkMc1) {
            return new W3p5fQJLFcnvJ(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto UpBo6;
        OtmeQ:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($JkMc1) {
            return new MIXStt9i96Hmf(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto aH5uv;
        Cs27s:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($JkMc1) {
            return new QRNhQFCjAtDfH();
        });
        goto qxW0k;
        aH5uv:
        $this->app->bind(WatermarkTextJobInterface::class, function ($JkMc1) {
            return new Q4zVFQDwWcjY8(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto COj72;
        fkpR2:
        $this->app->bind(MediaEncodeJobInterface::class, function ($JkMc1) {
            return new EFybiIZ9Fidir(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto Cs27s;
        lYkKA:
        $this->app->singleton(WhUSFqM1jr0Xc::class, function ($JkMc1) {
            return new WhUSFqM1jr0Xc($JkMc1->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto A6isN;
        HzTlU:
        $this->app->singleton(PJnSZopfp7dgp::class, function () {
            return new ZzJrrZ7pIAAWV(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto lYkKA;
        BMFtb:
        $this->app->bind(MXvBi3Q4qWy8O::class, function ($JkMc1) {
            return new MXvBi3Q4qWy8O(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto gIIyh;
        H4tmk:
        $this->app->bind(UploadServiceInterface::class, function ($JkMc1) {
            return new L9tBhjUbEacRR($JkMc1->make(WhUSFqM1jr0Xc::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto CiVbH;
        qB2Ij:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
