<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\RMpyfnEc6QmoE;
use Jfs\Uploader\Contracts\XuIaPR4PMryqL;
use Jfs\Uploader\Encoder\Uql37EhjWaxp7;
use Jfs\Uploader\Encoder\V9kB8ekPBG4Tf;
use Jfs\Uploader\Service\PwjTg62cqDtZB;
use Jfs\Uploader\Service\FileResolver\VipXhcJyMKN4c;
use Jfs\Uploader\Service\FileResolver\XXnWiFKz72F3J;
use Jfs\Uploader\Service\FileResolver\Ewa2UMtdzdVqO;
use Jfs\Uploader\Service\Jobs\Ux87OpCnMRhyU;
use Jfs\Uploader\Service\Jobs\CdKP9yH4agmHW;
use Jfs\Uploader\Service\Jobs\AHweyRiatCgBp;
use Jfs\Uploader\Service\Jobs\Usq3hiXOBWYMn;
use Jfs\Uploader\Service\Jobs\W9KkESvP84ppj;
use Jfs\Uploader\Service\Jobs\MFbrjFlzZ5wWu;
use Jfs\Uploader\Service\Jobs\DvKEzALw4yC2H;
use Jfs\Uploader\Service\Jobs\Og01R00FDMBgI;
use Jfs\Uploader\Service\Jobs\Hxzcw8z8mwsmX;
use Jfs\Uploader\Service\Jobs\DuJSnFZWzPgxp;
use Jfs\Uploader\Service\DkSooBIdtZWQo;
use Jfs\Uploader\Service\XHXjudWRHC4fj;
use Jfs\Uploader\Service\ZbWSSLhlYKy4u;
use Jfs\Uploader\Service\SJvf1oBIJv75H;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto qyCMU;
        vscO3:
        $this->app->tag([Ewa2UMtdzdVqO::class, XXnWiFKz72F3J::class, VipXhcJyMKN4c::class], 'file.location.resolvers');
        goto nXvKF;
        nXvKF:
        $this->app->bind(BlurJobInterface::class, function ($SyF3u) {
            return new Ux87OpCnMRhyU(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto nsfmD;
        qSFkL:
        $this->app->bind(GalleryCloudInterface::class, function ($SyF3u) {
            return new RMpyfnEc6QmoE();
        });
        goto jidPH;
        FnRcf:
        $this->app->bind(MediaEncodeJobInterface::class, function ($SyF3u) {
            return new Hxzcw8z8mwsmX(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto Jvwy_;
        JjOPP:
        $this->app->bind(V9kB8ekPBG4Tf::class, function ($SyF3u) {
            return new V9kB8ekPBG4Tf(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto vscO3;
        qyCMU:
        $this->app->bind(UploadServiceInterface::class, function ($SyF3u) {
            return new ZbWSSLhlYKy4u($SyF3u->make(PwjTg62cqDtZB::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto EIkEV;
        nsfmD:
        $this->app->bind(BlurVideoJobInterface::class, function ($SyF3u) {
            return new CdKP9yH4agmHW(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto VbPF0;
        VbPF0:
        $this->app->bind(CompressJobInterface::class, function ($SyF3u) {
            return new AHweyRiatCgBp(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto dUomG;
        GrQnR:
        $this->app->singleton(XuIaPR4PMryqL::class, function () {
            return new XHXjudWRHC4fj(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto vLz96;
        cjdKL:
        $this->app->bind(WatermarkTextJobInterface::class, function ($SyF3u) {
            return new DuJSnFZWzPgxp(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto qSFkL;
        hB8DN:
        $this->app->singleton(Uql37EhjWaxp7::class, function ($SyF3u) {
            return new Uql37EhjWaxp7($SyF3u->make(DkSooBIdtZWQo::class), Storage::disk('s3'));
        });
        goto JjOPP;
        G2WZm:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($SyF3u) {
            return new Og01R00FDMBgI(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto cjdKL;
        vLz96:
        $this->app->singleton(PwjTg62cqDtZB::class, function ($SyF3u) {
            return new PwjTg62cqDtZB($SyF3u->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto XJh1D;
        dUomG:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($SyF3u) {
            return new Usq3hiXOBWYMn(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Ka9WG;
        Ka9WG:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($SyF3u) {
            return new W9KkESvP84ppj(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto FnRcf;
        EIkEV:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($SyF3u) {
            return new SJvf1oBIJv75H($SyF3u->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto GrQnR;
        Jvwy_:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($SyF3u) {
            return new MFbrjFlzZ5wWu();
        });
        goto EjyEQ;
        XJh1D:
        $this->app->singleton(DkSooBIdtZWQo::class, function ($SyF3u) {
            return new DkSooBIdtZWQo(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto hB8DN;
        EjyEQ:
        $this->app->bind(StoreToS3JobInterface::class, function ($SyF3u) {
            return new DvKEzALw4yC2H(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto G2WZm;
        jidPH:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
