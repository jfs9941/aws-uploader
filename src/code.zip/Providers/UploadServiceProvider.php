<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\ZKOEqkwL8HGdI;
use Jfs\Uploader\Contracts\WLzh1GrcHwitv;
use Jfs\Uploader\Encoder\TMo64GtkgTgVY;
use Jfs\Uploader\Encoder\XLZ6utKYThkTc;
use Jfs\Uploader\Service\JVjr2CUQxg9ep;
use Jfs\Uploader\Service\FileResolver\HWZK9k2uYCZWZ;
use Jfs\Uploader\Service\FileResolver\J68vhobWm0YQ4;
use Jfs\Uploader\Service\FileResolver\IaAMBMy0ADmp6;
use Jfs\Uploader\Service\Jobs\ZGki6PhRnZN2V;
use Jfs\Uploader\Service\Jobs\WJlfwmcgPA8A1;
use Jfs\Uploader\Service\Jobs\PqjlDTKlvR5qC;
use Jfs\Uploader\Service\Jobs\R4oSawkuoyUbM;
use Jfs\Uploader\Service\Jobs\H3u7NmHvIxK7d;
use Jfs\Uploader\Service\Jobs\NFHQhgcCzjzZQ;
use Jfs\Uploader\Service\Jobs\CQsNjFBGsRnq3;
use Jfs\Uploader\Service\Jobs\FWgOwuyh1XibA;
use Jfs\Uploader\Service\Jobs\Jo1vXwLFOmnZA;
use Jfs\Uploader\Service\Jobs\AqTwSUrCn3doM;
use Jfs\Uploader\Service\HHzuA41ccyXtA;
use Jfs\Uploader\Service\VLNeV396JQx1d;
use Jfs\Uploader\Service\NDgro6xT5pfdP;
use Jfs\Uploader\Service\CSIbKAYrUof3b;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto Wvudw;
        mxBtA:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($yn8Mu) {
            return new H3u7NmHvIxK7d(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto pLEJS;
        wJtQ4:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($yn8Mu) {
            return new FWgOwuyh1XibA(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto i8DMB;
        wP_UD:
        $this->app->singleton(JVjr2CUQxg9ep::class, function ($yn8Mu) {
            return new JVjr2CUQxg9ep($yn8Mu->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto j2Nwg;
        SsWhs:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($yn8Mu) {
            return new NFHQhgcCzjzZQ();
        });
        goto dYo0w;
        pXQ4K:
        $this->app->tag([IaAMBMy0ADmp6::class, J68vhobWm0YQ4::class, HWZK9k2uYCZWZ::class], 'file.location.resolvers');
        goto e65gu;
        TV5h1:
        $this->app->bind(XLZ6utKYThkTc::class, function ($yn8Mu) {
            return new XLZ6utKYThkTc(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto pXQ4K;
        dYo0w:
        $this->app->bind(StoreToS3JobInterface::class, function ($yn8Mu) {
            return new CQsNjFBGsRnq3(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto wJtQ4;
        FGG3E:
        $this->app->singleton(TMo64GtkgTgVY::class, function ($yn8Mu) {
            return new TMo64GtkgTgVY($yn8Mu->make(HHzuA41ccyXtA::class), Storage::disk('s3'));
        });
        goto TV5h1;
        e65gu:
        $this->app->bind(BlurJobInterface::class, function ($yn8Mu) {
            return new ZGki6PhRnZN2V(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto tDChK;
        FOb2P:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($yn8Mu) {
            return new R4oSawkuoyUbM(Storage::disk('s3'), Storage::disk('public'));
        });
        goto mxBtA;
        R2n0C:
        $this->app->bind(GalleryCloudInterface::class, function ($yn8Mu) {
            return new ZKOEqkwL8HGdI();
        });
        goto A51nS;
        j2Nwg:
        $this->app->singleton(HHzuA41ccyXtA::class, function ($yn8Mu) {
            return new HHzuA41ccyXtA(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto FGG3E;
        i8DMB:
        $this->app->bind(WatermarkTextJobInterface::class, function ($yn8Mu) {
            return new AqTwSUrCn3doM(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto R2n0C;
        VzH8m:
        $this->app->bind(CompressJobInterface::class, function ($yn8Mu) {
            return new PqjlDTKlvR5qC(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto FOb2P;
        UtF_D:
        $this->app->singleton(WLzh1GrcHwitv::class, function () {
            return new VLNeV396JQx1d(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto wP_UD;
        Wvudw:
        $this->app->bind(UploadServiceInterface::class, function ($yn8Mu) {
            return new NDgro6xT5pfdP($yn8Mu->make(JVjr2CUQxg9ep::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto pDGfO;
        tDChK:
        $this->app->bind(BlurVideoJobInterface::class, function ($yn8Mu) {
            return new WJlfwmcgPA8A1(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto VzH8m;
        pDGfO:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($yn8Mu) {
            return new CSIbKAYrUof3b($yn8Mu->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto UtF_D;
        pLEJS:
        $this->app->bind(MediaEncodeJobInterface::class, function ($yn8Mu) {
            return new Jo1vXwLFOmnZA(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto SsWhs;
        A51nS:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
