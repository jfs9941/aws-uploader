<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\ZZCtF2oiXL4tR;
use Jfs\Uploader\Contracts\IKjdKLYqqHsDJ;
use Jfs\Uploader\Encoder\OIG3Aes8wHMT8;
use Jfs\Uploader\Encoder\MUNOklcvw7X2T;
use Jfs\Uploader\Service\CYgJOMj8wExPk;
use Jfs\Uploader\Service\FileResolver\YuEt0TYJzLBe7;
use Jfs\Uploader\Service\FileResolver\XvQrxzosUvLJZ;
use Jfs\Uploader\Service\FileResolver\NwynGQhCBqxQO;
use Jfs\Uploader\Service\Jobs\O2lMJENlx8WLz;
use Jfs\Uploader\Service\Jobs\OE52eJRZKVEvz;
use Jfs\Uploader\Service\Jobs\D40iMGMlqlJNR;
use Jfs\Uploader\Service\Jobs\A1zwtkX08fqzj;
use Jfs\Uploader\Service\Jobs\KlyqGTxtBlSOO;
use Jfs\Uploader\Service\Jobs\DyMWE3bKu3Ege;
use Jfs\Uploader\Service\Jobs\V2CWIPB9W9uFI;
use Jfs\Uploader\Service\Jobs\FNHIOteGjG0AW;
use Jfs\Uploader\Service\Jobs\X6xgjl07wtBWx;
use Jfs\Uploader\Service\Jobs\LrUeuibwhHXBv;
use Jfs\Uploader\Service\B0o6VsHdCPn65;
use Jfs\Uploader\Service\H38a3dsu2FMgf;
use Jfs\Uploader\Service\IZmBxrHFIfA2p;
use Jfs\Uploader\Service\BQJIbuRaJNRQo;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto LXve8;
        pgG8V:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($xKOfr) {
            return new FNHIOteGjG0AW(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto HnRC0;
        LXve8:
        $this->app->bind(UploadServiceInterface::class, function ($xKOfr) {
            return new IZmBxrHFIfA2p($xKOfr->make(CYgJOMj8wExPk::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto AF54n;
        VL3SU:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($xKOfr) {
            return new A1zwtkX08fqzj(Storage::disk('s3'), Storage::disk('public'));
        });
        goto iFHPB;
        mCLf8:
        $this->app->bind(MediaEncodeJobInterface::class, function ($xKOfr) {
            return new X6xgjl07wtBWx(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto zdH40;
        X2b0C:
        $this->app->singleton(CYgJOMj8wExPk::class, function ($xKOfr) {
            return new CYgJOMj8wExPk($xKOfr->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto b0svY;
        EwGLi:
        $this->app->bind(StoreToS3JobInterface::class, function ($xKOfr) {
            return new V2CWIPB9W9uFI(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto pgG8V;
        HnRC0:
        $this->app->bind(WatermarkTextJobInterface::class, function ($xKOfr) {
            return new LrUeuibwhHXBv(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto R2WUe;
        R2WUe:
        $this->app->bind(GalleryCloudInterface::class, function ($xKOfr) {
            return new ZZCtF2oiXL4tR();
        });
        goto QjCJZ;
        AF54n:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($xKOfr) {
            return new BQJIbuRaJNRQo($xKOfr->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto YsJGw;
        b0svY:
        $this->app->singleton(B0o6VsHdCPn65::class, function ($xKOfr) {
            return new B0o6VsHdCPn65(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto mo55Z;
        wlXNA:
        $this->app->tag([NwynGQhCBqxQO::class, XvQrxzosUvLJZ::class, YuEt0TYJzLBe7::class], 'file.location.resolvers');
        goto acncn;
        zdH40:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($xKOfr) {
            return new DyMWE3bKu3Ege();
        });
        goto EwGLi;
        TZJdP:
        $this->app->bind(MUNOklcvw7X2T::class, function ($xKOfr) {
            return new MUNOklcvw7X2T(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto wlXNA;
        f2GEo:
        $this->app->bind(BlurVideoJobInterface::class, function ($xKOfr) {
            return new OE52eJRZKVEvz(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto h7n7R;
        YsJGw:
        $this->app->singleton(IKjdKLYqqHsDJ::class, function () {
            return new H38a3dsu2FMgf(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto X2b0C;
        mo55Z:
        $this->app->singleton(OIG3Aes8wHMT8::class, function ($xKOfr) {
            return new OIG3Aes8wHMT8($xKOfr->make(B0o6VsHdCPn65::class), Storage::disk('s3'));
        });
        goto TZJdP;
        acncn:
        $this->app->bind(BlurJobInterface::class, function ($xKOfr) {
            return new O2lMJENlx8WLz(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto f2GEo;
        iFHPB:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($xKOfr) {
            return new KlyqGTxtBlSOO(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto mCLf8;
        h7n7R:
        $this->app->bind(CompressJobInterface::class, function ($xKOfr) {
            return new D40iMGMlqlJNR(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto VL3SU;
        QjCJZ:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
