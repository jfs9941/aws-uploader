<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\Qzdrz0OzvrtjS;
use Jfs\Uploader\Contracts\QPcmBScQDUpcH;
use Jfs\Uploader\Encoder\V6kCroy78Tmzg;
use Jfs\Uploader\Encoder\XDE8fToEPyv8f;
use Jfs\Uploader\Service\JMS12XhOMqdv8;
use Jfs\Uploader\Service\FileResolver\Eu2Y659i7SmJI;
use Jfs\Uploader\Service\FileResolver\KLYnjLrN4vRxX;
use Jfs\Uploader\Service\FileResolver\LFAm9Qfh94lZh;
use Jfs\Uploader\Service\Jobs\TzmwdyxO2Rgcq;
use Jfs\Uploader\Service\Jobs\E5KgbeJIWBS1V;
use Jfs\Uploader\Service\Jobs\G8G5pPpgiBqYu;
use Jfs\Uploader\Service\Jobs\Ied0DPIThkfud;
use Jfs\Uploader\Service\Jobs\IZyMlzZAiGKC3;
use Jfs\Uploader\Service\Jobs\JVAIrsPxLCKFc;
use Jfs\Uploader\Service\Jobs\WMJwYTA7UMAWb;
use Jfs\Uploader\Service\Jobs\ZkFu9BPpbLXNU;
use Jfs\Uploader\Service\Jobs\TTVnFdgrZz9G7;
use Jfs\Uploader\Service\Jobs\IVN9EwgQzxbpT;
use Jfs\Uploader\Service\PzfoMEiZi5U2a;
use Jfs\Uploader\Service\W6MKQSWDEHAwJ;
use Jfs\Uploader\Service\Eb0cApEJe5wrS;
use Jfs\Uploader\Service\NarZk2mlAS1LS;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto g4_5Z;
        abd1J:
        $this->app->bind(WatermarkTextJobInterface::class, function ($PT1Pm) {
            return new IVN9EwgQzxbpT(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto O9C_M;
        b_b0q:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($PT1Pm) {
            return new Ied0DPIThkfud(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Ygl9l;
        fP16g:
        $this->app->bind(CompressJobInterface::class, function ($PT1Pm) {
            return new G8G5pPpgiBqYu(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto b_b0q;
        o4jtM:
        $this->app->bind(XDE8fToEPyv8f::class, function ($PT1Pm) {
            return new XDE8fToEPyv8f(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto inlLW;
        B9Vxm:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($PT1Pm) {
            return new JVAIrsPxLCKFc();
        });
        goto pkAnO;
        nfOx2:
        $this->app->singleton(JMS12XhOMqdv8::class, function ($PT1Pm) {
            return new JMS12XhOMqdv8($PT1Pm->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto djlq1;
        O9C_M:
        $this->app->bind(GalleryCloudInterface::class, function ($PT1Pm) {
            return new Qzdrz0OzvrtjS();
        });
        goto VBedg;
        qTa3j:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($PT1Pm) {
            return new ZkFu9BPpbLXNU(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto abd1J;
        cRXq3:
        $this->app->bind(MediaEncodeJobInterface::class, function ($PT1Pm) {
            return new TTVnFdgrZz9G7(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto B9Vxm;
        inlLW:
        $this->app->tag([LFAm9Qfh94lZh::class, KLYnjLrN4vRxX::class, Eu2Y659i7SmJI::class], 'file.location.resolvers');
        goto lFDT0;
        fy8Pf:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($PT1Pm) {
            return new NarZk2mlAS1LS($PT1Pm->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto IIkJK;
        g4_5Z:
        $this->app->bind(UploadServiceInterface::class, function ($PT1Pm) {
            return new Eb0cApEJe5wrS($PT1Pm->make(JMS12XhOMqdv8::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto fy8Pf;
        J2hMo:
        $this->app->bind(BlurVideoJobInterface::class, function ($PT1Pm) {
            return new E5KgbeJIWBS1V(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto fP16g;
        Ygl9l:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($PT1Pm) {
            return new IZyMlzZAiGKC3(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto cRXq3;
        okQiw:
        $this->app->singleton(V6kCroy78Tmzg::class, function ($PT1Pm) {
            return new V6kCroy78Tmzg($PT1Pm->make(PzfoMEiZi5U2a::class), Storage::disk('s3'));
        });
        goto o4jtM;
        djlq1:
        $this->app->singleton(PzfoMEiZi5U2a::class, function ($PT1Pm) {
            return new PzfoMEiZi5U2a(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto okQiw;
        pkAnO:
        $this->app->bind(StoreToS3JobInterface::class, function ($PT1Pm) {
            return new WMJwYTA7UMAWb(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto qTa3j;
        lFDT0:
        $this->app->bind(BlurJobInterface::class, function ($PT1Pm) {
            return new TzmwdyxO2Rgcq(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto J2hMo;
        IIkJK:
        $this->app->singleton(QPcmBScQDUpcH::class, function () {
            return new W6MKQSWDEHAwJ(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto nfOx2;
        VBedg:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
