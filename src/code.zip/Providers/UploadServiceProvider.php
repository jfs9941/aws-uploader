<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\FdlFJzTILWMTP;
use Jfs\Uploader\Contracts\SXC0PdU9S8rem;
use Jfs\Uploader\Encoder\GYeGOleAx46En;
use Jfs\Uploader\Encoder\Y272Vu6XdYN6L;
use Jfs\Uploader\Service\W99ztYaFerRwn;
use Jfs\Uploader\Service\FileResolver\HEN6zgaoMBijr;
use Jfs\Uploader\Service\FileResolver\QpxMoZei1LT3L;
use Jfs\Uploader\Service\FileResolver\OPpsyG4zaN41t;
use Jfs\Uploader\Service\Jobs\L3eBiEs5P3Zb3;
use Jfs\Uploader\Service\Jobs\EVBxly7PyHLk2;
use Jfs\Uploader\Service\Jobs\JfBe5Y66zhkIN;
use Jfs\Uploader\Service\Jobs\Ur9eZIZOUlnWl;
use Jfs\Uploader\Service\Jobs\FVJYMpcYNuoCy;
use Jfs\Uploader\Service\Jobs\BZ4eujarFFlCo;
use Jfs\Uploader\Service\Jobs\H6PUY3r1zkBDt;
use Jfs\Uploader\Service\Jobs\DtnIIdWKxqdug;
use Jfs\Uploader\Service\Jobs\GNwVJVmEUG20B;
use Jfs\Uploader\Service\Jobs\QS26Y6E0tEcur;
use Jfs\Uploader\Service\HQQLwdzkwB4WZ;
use Jfs\Uploader\Service\PyfePz8BX4gVQ;
use Jfs\Uploader\Service\N2tPpcJn2iYGH;
use Jfs\Uploader\Service\SSpFOwqWBwfrA;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto auPuT;
        i7vqD:
        $this->app->singleton(SXC0PdU9S8rem::class, function () {
            return new PyfePz8BX4gVQ(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto vtGSq;
        vtGSq:
        $this->app->singleton(W99ztYaFerRwn::class, function ($v9EgP) {
            return new W99ztYaFerRwn($v9EgP->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto xittI;
        kuOPw:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($v9EgP) {
            return new SSpFOwqWBwfrA($v9EgP->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto i7vqD;
        JXAIL:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($v9EgP) {
            return new DtnIIdWKxqdug(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto WW1ZJ;
        eO0tg:
        $this->app->singleton(GYeGOleAx46En::class, function ($v9EgP) {
            return new GYeGOleAx46En($v9EgP->make(HQQLwdzkwB4WZ::class), Storage::disk('s3'));
        });
        goto qJOeD;
        qJOeD:
        $this->app->bind(Y272Vu6XdYN6L::class, function ($v9EgP) {
            return new Y272Vu6XdYN6L(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto UzuIg;
        xittI:
        $this->app->singleton(HQQLwdzkwB4WZ::class, function ($v9EgP) {
            return new HQQLwdzkwB4WZ(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto eO0tg;
        VUTT1:
        $this->app->bind(GalleryCloudInterface::class, function ($v9EgP) {
            return new FdlFJzTILWMTP();
        });
        goto t9cbg;
        MulUn:
        $this->app->bind(CompressJobInterface::class, function ($v9EgP) {
            return new JfBe5Y66zhkIN(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto xJX5K;
        PjLjT:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($v9EgP) {
            return new BZ4eujarFFlCo();
        });
        goto Pke7G;
        s2hl8:
        $this->app->bind(MediaEncodeJobInterface::class, function ($v9EgP) {
            return new GNwVJVmEUG20B(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto PjLjT;
        u9TRF:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($v9EgP) {
            return new FVJYMpcYNuoCy(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto s2hl8;
        Pke7G:
        $this->app->bind(StoreToS3JobInterface::class, function ($v9EgP) {
            return new H6PUY3r1zkBDt(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto JXAIL;
        xJX5K:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($v9EgP) {
            return new Ur9eZIZOUlnWl(Storage::disk('s3'), Storage::disk('public'));
        });
        goto u9TRF;
        N_jAl:
        $this->app->bind(BlurVideoJobInterface::class, function ($v9EgP) {
            return new EVBxly7PyHLk2(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto MulUn;
        UzuIg:
        $this->app->tag([OPpsyG4zaN41t::class, QpxMoZei1LT3L::class, HEN6zgaoMBijr::class], 'file.location.resolvers');
        goto BHGCm;
        auPuT:
        $this->app->bind(UploadServiceInterface::class, function ($v9EgP) {
            return new N2tPpcJn2iYGH($v9EgP->make(W99ztYaFerRwn::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto kuOPw;
        WW1ZJ:
        $this->app->bind(WatermarkTextJobInterface::class, function ($v9EgP) {
            return new QS26Y6E0tEcur(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto VUTT1;
        BHGCm:
        $this->app->bind(BlurJobInterface::class, function ($v9EgP) {
            return new L3eBiEs5P3Zb3(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto N_jAl;
        t9cbg:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
