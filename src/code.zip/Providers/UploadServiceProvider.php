<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\QwdElzovmeJgR;
use Jfs\Uploader\Contracts\T1J9j7WqyAUZ6;
use Jfs\Uploader\Encoder\ZgEcV5Ek5Li7G;
use Jfs\Uploader\Encoder\B5vx2QdfNEBBj;
use Jfs\Uploader\Service\SLO5cl2ibvGWu;
use Jfs\Uploader\Service\FileResolver\PJ71NuodjoMup;
use Jfs\Uploader\Service\FileResolver\HBc2smAjfliZr;
use Jfs\Uploader\Service\FileResolver\L4JIkhfC8JQ2x;
use Jfs\Uploader\Service\Jobs\BkbQe60Q1wxb8;
use Jfs\Uploader\Service\Jobs\YeQsbwwlutyCe;
use Jfs\Uploader\Service\Jobs\Qit2RZ1q0o2t5;
use Jfs\Uploader\Service\Jobs\Mo0etgsaKI3Tx;
use Jfs\Uploader\Service\Jobs\TJOU79A0cMZLZ;
use Jfs\Uploader\Service\Jobs\NPsTgHFUCWkD2;
use Jfs\Uploader\Service\Jobs\No6vPGWgBIaot;
use Jfs\Uploader\Service\Jobs\WefCGNyjg3dbO;
use Jfs\Uploader\Service\Jobs\Lv7jGJB44F8EE;
use Jfs\Uploader\Service\Jobs\Q3umM07qDj1Tl;
use Jfs\Uploader\Service\VjtcOzJCF9Hx7;
use Jfs\Uploader\Service\PUY1a6FGGWTSN;
use Jfs\Uploader\Service\Bj3BdNuSDITL1;
use Jfs\Uploader\Service\ZicJ9Nu5m8zPr;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto cTEzQ;
        cTEzQ:
        $this->app->bind(UploadServiceInterface::class, function ($bL6y4) {
            return new Bj3BdNuSDITL1($bL6y4->make(SLO5cl2ibvGWu::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto Nca00;
        jWaMp:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($bL6y4) {
            return new Mo0etgsaKI3Tx(Storage::disk('s3'), Storage::disk('public'));
        });
        goto eBrYM;
        SsoHP:
        $this->app->bind(MediaEncodeJobInterface::class, function ($bL6y4) {
            return new Lv7jGJB44F8EE(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto lbShl;
        kwhXg:
        $this->app->bind(CompressJobInterface::class, function ($bL6y4) {
            return new Qit2RZ1q0o2t5(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto jWaMp;
        gekO5:
        $this->app->bind(WatermarkTextJobInterface::class, function ($bL6y4) {
            return new Q3umM07qDj1Tl(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto Cjbwe;
        po9jP:
        $this->app->singleton(ZgEcV5Ek5Li7G::class, function ($bL6y4) {
            return new ZgEcV5Ek5Li7G($bL6y4->make(VjtcOzJCF9Hx7::class), Storage::disk('s3'));
        });
        goto Notba;
        Notba:
        $this->app->bind(B5vx2QdfNEBBj::class, function ($bL6y4) {
            return new B5vx2QdfNEBBj(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto wLtfc;
        V8L0f:
        $this->app->bind(StoreToS3JobInterface::class, function ($bL6y4) {
            return new No6vPGWgBIaot(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto sEjDM;
        H9NQm:
        $this->app->singleton(SLO5cl2ibvGWu::class, function ($bL6y4) {
            return new SLO5cl2ibvGWu($bL6y4->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto UdsC1;
        UdsC1:
        $this->app->singleton(VjtcOzJCF9Hx7::class, function ($bL6y4) {
            return new VjtcOzJCF9Hx7(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto po9jP;
        v5AwK:
        $this->app->bind(BlurVideoJobInterface::class, function ($bL6y4) {
            return new YeQsbwwlutyCe(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto kwhXg;
        eBrYM:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($bL6y4) {
            return new TJOU79A0cMZLZ(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SsoHP;
        dpFik:
        $this->app->bind(BlurJobInterface::class, function ($bL6y4) {
            return new BkbQe60Q1wxb8(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto v5AwK;
        lbShl:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($bL6y4) {
            return new NPsTgHFUCWkD2();
        });
        goto V8L0f;
        R9Z7d:
        $this->app->singleton(T1J9j7WqyAUZ6::class, function () {
            return new PUY1a6FGGWTSN(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto H9NQm;
        Nca00:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($bL6y4) {
            return new ZicJ9Nu5m8zPr($bL6y4->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto R9Z7d;
        sEjDM:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($bL6y4) {
            return new WefCGNyjg3dbO(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto gekO5;
        wLtfc:
        $this->app->tag([L4JIkhfC8JQ2x::class, HBc2smAjfliZr::class, PJ71NuodjoMup::class], 'file.location.resolvers');
        goto dpFik;
        Cjbwe:
        $this->app->bind(GalleryCloudInterface::class, function ($bL6y4) {
            return new QwdElzovmeJgR();
        });
        goto mePMm;
        mePMm:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
