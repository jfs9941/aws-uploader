<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\F80uokI9Tbra4;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Encoder\Rwcm9mhsmq7Wv;
use Jfs\Uploader\Encoder\GGjYAvfIx8jD2;
use Jfs\Uploader\Service\UKpsYHdguB77R;
use Jfs\Uploader\Service\FileResolver\Vll0SsEJmokew;
use Jfs\Uploader\Service\FileResolver\FqGNTuqLHtzGV;
use Jfs\Uploader\Service\FileResolver\JgwHATHYvxYRO;
use Jfs\Uploader\Service\Jobs\KunFjmoTBatUZ;
use Jfs\Uploader\Service\Jobs\TaTRPoVxVVwpo;
use Jfs\Uploader\Service\Jobs\Afrn0bzm4bLT4;
use Jfs\Uploader\Service\Jobs\Wjo7N0msncpEW;
use Jfs\Uploader\Service\Jobs\IcQoTzmDwRiUM;
use Jfs\Uploader\Service\Jobs\ZklglaQMmoVEa;
use Jfs\Uploader\Service\Jobs\HOkKTcQ4ZI88G;
use Jfs\Uploader\Service\Jobs\MNCz9zM0Bwk1l;
use Jfs\Uploader\Service\Jobs\H0biEBN4RT7n2;
use Jfs\Uploader\Service\Jobs\Gds2W9QX0HocO;
use Jfs\Uploader\Service\L3oEPipUZv9oB;
use Jfs\Uploader\Service\WILlDNuoyQRBR;
use Jfs\Uploader\Service\ACgJ23G353OYG;
use Jfs\Uploader\Service\RApmFeqqa6RIG;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto aq4Ot;
        yaWQB:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($BEwQS) {
            return new MNCz9zM0Bwk1l(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto McA_Y;
        ChdYB:
        $this->app->bind(GGjYAvfIx8jD2::class, function ($BEwQS) {
            return new GGjYAvfIx8jD2(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto i_xny;
        S94Do:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($BEwQS) {
            return new IcQoTzmDwRiUM(config('upload.maker'), Storage::disk('public'));
        });
        goto Q9CbK;
        i_xny:
        $this->app->tag([JgwHATHYvxYRO::class, FqGNTuqLHtzGV::class, Vll0SsEJmokew::class], 'file.location.resolvers');
        goto N5d2M;
        zai2a:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($BEwQS) {
            return new RApmFeqqa6RIG($BEwQS->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto WEUZ0;
        GuihD:
        $this->app->bind(GalleryCloudInterface::class, function ($BEwQS) {
            return new F80uokI9Tbra4();
        });
        goto BXcjv;
        wzkXd:
        $this->app->singleton(Rwcm9mhsmq7Wv::class, function ($BEwQS) {
            return new Rwcm9mhsmq7Wv($BEwQS->make(L3oEPipUZv9oB::class), Storage::disk('s3'));
        });
        goto ChdYB;
        McA_Y:
        $this->app->bind(WatermarkTextJobInterface::class, function ($BEwQS) {
            return new Gds2W9QX0HocO(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto GuihD;
        N5d2M:
        $this->app->bind(BlurJobInterface::class, function ($BEwQS) {
            return new KunFjmoTBatUZ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto KFWk8;
        m3f14:
        $this->app->singleton(L3oEPipUZv9oB::class, function ($BEwQS) {
            return new L3oEPipUZv9oB(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto wzkXd;
        PfR76:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($BEwQS) {
            return new Wjo7N0msncpEW(Storage::disk('s3'), Storage::disk('public'));
        });
        goto S94Do;
        YgOC2:
        $this->app->singleton(UKpsYHdguB77R::class, function ($BEwQS) {
            return new UKpsYHdguB77R($BEwQS->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto m3f14;
        v4c4H:
        $this->app->bind(CompressJobInterface::class, function ($BEwQS) {
            return new Afrn0bzm4bLT4(config('upload.maker'), Storage::disk('public'));
        });
        goto PfR76;
        E2S5b:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($BEwQS) {
            return new ZklglaQMmoVEa();
        });
        goto G52c2;
        G52c2:
        $this->app->bind(StoreToS3JobInterface::class, function ($BEwQS) {
            return new HOkKTcQ4ZI88G(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto yaWQB;
        WEUZ0:
        $this->app->singleton(MpZUpGr3YFIhj::class, function () {
            return new WILlDNuoyQRBR(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto YgOC2;
        aq4Ot:
        $this->app->bind(UploadServiceInterface::class, function ($BEwQS) {
            return new ACgJ23G353OYG($BEwQS->make(UKpsYHdguB77R::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto zai2a;
        KFWk8:
        $this->app->bind(BlurVideoJobInterface::class, function ($BEwQS) {
            return new TaTRPoVxVVwpo(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto v4c4H;
        Q9CbK:
        $this->app->bind(MediaEncodeJobInterface::class, function ($BEwQS) {
            return new H0biEBN4RT7n2(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto E2S5b;
        BXcjv:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
