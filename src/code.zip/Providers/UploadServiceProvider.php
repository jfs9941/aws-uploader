<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\XcyJIYC6NQKkO;
use Jfs\Uploader\Contracts\Bvfii9tMROJRp;
use Jfs\Uploader\Encoder\VBDy3Gb7TKD1d;
use Jfs\Uploader\Encoder\Wlw2CGgLj1kt6;
use Jfs\Uploader\Service\FJqWngr52kRMn;
use Jfs\Uploader\Service\FileResolver\XnlZvjyM30zQG;
use Jfs\Uploader\Service\FileResolver\WSGjH9D3DAAAw;
use Jfs\Uploader\Service\FileResolver\Uduf7NlafUS4o;
use Jfs\Uploader\Service\Jobs\UkLzQjDoxgOPs;
use Jfs\Uploader\Service\Jobs\PV5mhdJpGbLXd;
use Jfs\Uploader\Service\Jobs\Hc8YwIabio56u;
use Jfs\Uploader\Service\Jobs\KaGHuNXFVgGmh;
use Jfs\Uploader\Service\Jobs\Br9WkWCAnbAT8;
use Jfs\Uploader\Service\Jobs\JBQKHDBrqHJhX;
use Jfs\Uploader\Service\Jobs\GBO58BhrDNh2c;
use Jfs\Uploader\Service\Jobs\A6AKJRctBIxI1;
use Jfs\Uploader\Service\Jobs\N2RmE8OMymJfl;
use Jfs\Uploader\Service\Jobs\WVxsT78OVKxMa;
use Jfs\Uploader\Service\BJWEJOjkkZaRL;
use Jfs\Uploader\Service\PYjKYaymEKJyi;
use Jfs\Uploader\Service\QNkQFuwFoBPpA;
use Jfs\Uploader\Service\LBGXGWApjgxw9;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto Fa0VY;
        R3L8D:
        $this->app->singleton(VBDy3Gb7TKD1d::class, function ($QNzAg) {
            return new VBDy3Gb7TKD1d($QNzAg->make(BJWEJOjkkZaRL::class), Storage::disk('s3'));
        });
        goto N_5Qk;
        QnqOp:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($QNzAg) {
            return new LBGXGWApjgxw9($QNzAg->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto sPaKY;
        F9wcy:
        $this->app->bind(GalleryCloudInterface::class, function ($QNzAg) {
            return new XcyJIYC6NQKkO();
        });
        goto FXA0q;
        bSsZk:
        $this->app->bind(StoreToS3JobInterface::class, function ($QNzAg) {
            return new GBO58BhrDNh2c(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto CDXB7;
        sPaKY:
        $this->app->singleton(Bvfii9tMROJRp::class, function () {
            return new PYjKYaymEKJyi(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto HGdrp;
        LQbQs:
        $this->app->singleton(BJWEJOjkkZaRL::class, function ($QNzAg) {
            return new BJWEJOjkkZaRL(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto R3L8D;
        EJkXT:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($QNzAg) {
            return new Br9WkWCAnbAT8(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto wMuCp;
        wMuCp:
        $this->app->bind(MediaEncodeJobInterface::class, function ($QNzAg) {
            return new N2RmE8OMymJfl(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto C9wOR;
        C9wOR:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($QNzAg) {
            return new JBQKHDBrqHJhX();
        });
        goto bSsZk;
        d3YIL:
        $this->app->tag([Uduf7NlafUS4o::class, WSGjH9D3DAAAw::class, XnlZvjyM30zQG::class], 'file.location.resolvers');
        goto YvAy3;
        HWfoS:
        $this->app->bind(WatermarkTextJobInterface::class, function ($QNzAg) {
            return new WVxsT78OVKxMa(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto F9wcy;
        Fa0VY:
        $this->app->bind(UploadServiceInterface::class, function ($QNzAg) {
            return new QNkQFuwFoBPpA($QNzAg->make(FJqWngr52kRMn::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto QnqOp;
        KAXCq:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($QNzAg) {
            return new KaGHuNXFVgGmh(Storage::disk('s3'), Storage::disk('public'));
        });
        goto EJkXT;
        N_5Qk:
        $this->app->bind(Wlw2CGgLj1kt6::class, function ($QNzAg) {
            return new Wlw2CGgLj1kt6(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto d3YIL;
        YvAy3:
        $this->app->bind(BlurJobInterface::class, function ($QNzAg) {
            return new UkLzQjDoxgOPs(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto C_s8m;
        C_s8m:
        $this->app->bind(BlurVideoJobInterface::class, function ($QNzAg) {
            return new PV5mhdJpGbLXd(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto X8B_s;
        X8B_s:
        $this->app->bind(CompressJobInterface::class, function ($QNzAg) {
            return new Hc8YwIabio56u(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto KAXCq;
        HGdrp:
        $this->app->singleton(FJqWngr52kRMn::class, function ($QNzAg) {
            return new FJqWngr52kRMn($QNzAg->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto LQbQs;
        CDXB7:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($QNzAg) {
            return new A6AKJRctBIxI1(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto HWfoS;
        FXA0q:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
