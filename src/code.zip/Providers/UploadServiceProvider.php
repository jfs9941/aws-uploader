<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\JBNI3mZItZh1y;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Encoder\MquUYPN1EJDdI;
use Jfs\Uploader\Encoder\HOZ8jeXzeceNN;
use Jfs\Uploader\Service\WkAFfUCbIBC7t;
use Jfs\Uploader\Service\FileResolver\LoocOt1CuyUVF;
use Jfs\Uploader\Service\FileResolver\SCLUkMck5sD3t;
use Jfs\Uploader\Service\FileResolver\V9C418KGxojKp;
use Jfs\Uploader\Service\Jobs\EnHldbJrvjtuo;
use Jfs\Uploader\Service\Jobs\FZU8mOb1H995K;
use Jfs\Uploader\Service\Jobs\ZDAvU58qFgawR;
use Jfs\Uploader\Service\Jobs\FWgicZkq4ksHj;
use Jfs\Uploader\Service\Jobs\HINeytZSirxpb;
use Jfs\Uploader\Service\Jobs\HRtV6eHe7EdYB;
use Jfs\Uploader\Service\Jobs\FHPIZz3dTvdsC;
use Jfs\Uploader\Service\Jobs\Rmj93vDJAXwoy;
use Jfs\Uploader\Service\Jobs\RZtVIUu2mPjJE;
use Jfs\Uploader\Service\Jobs\T69reQ7rYjN5U;
use Jfs\Uploader\Service\JrqDsqkHsYBsl;
use Jfs\Uploader\Service\XsyK4RfzqtWuF;
use Jfs\Uploader\Service\I7M5Y1oY1ZdAT;
use Jfs\Uploader\Service\ByY72uzHo09DF;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto Od8hM;
        XLHVM:
        $this->app->bind(HOZ8jeXzeceNN::class, function ($IMjzj) {
            return new HOZ8jeXzeceNN(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto mw16a;
        sdXFv:
        $this->app->bind(StoreToS3JobInterface::class, function ($IMjzj) {
            return new FHPIZz3dTvdsC(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto MsqIn;
        Kl6jR:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($IMjzj) {
            return new FWgicZkq4ksHj(Storage::disk('s3'), Storage::disk('public'));
        });
        goto CDZWa;
        LQbIg:
        $this->app->bind(MediaEncodeJobInterface::class, function ($IMjzj) {
            return new RZtVIUu2mPjJE(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto YI7_T;
        z7vxq:
        $this->app->bind(BlurJobInterface::class, function ($IMjzj) {
            return new EnHldbJrvjtuo(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto SC3sy;
        zos3g:
        $this->app->singleton(WkAFfUCbIBC7t::class, function ($IMjzj) {
            return new WkAFfUCbIBC7t($IMjzj->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Sjps2;
        SC3sy:
        $this->app->bind(BlurVideoJobInterface::class, function ($IMjzj) {
            return new FZU8mOb1H995K(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto yCOHc;
        Od8hM:
        $this->app->bind(UploadServiceInterface::class, function ($IMjzj) {
            return new I7M5Y1oY1ZdAT($IMjzj->make(WkAFfUCbIBC7t::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto X3XuC;
        K4oa3:
        $this->app->bind(GalleryCloudInterface::class, function ($IMjzj) {
            return new JBNI3mZItZh1y();
        });
        goto edA9Y;
        X3XuC:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($IMjzj) {
            return new ByY72uzHo09DF($IMjzj->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto k4MLh;
        YI7_T:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($IMjzj) {
            return new HRtV6eHe7EdYB();
        });
        goto sdXFv;
        bQ_qY:
        $this->app->singleton(MquUYPN1EJDdI::class, function ($IMjzj) {
            return new MquUYPN1EJDdI($IMjzj->make(JrqDsqkHsYBsl::class), Storage::disk('s3'));
        });
        goto XLHVM;
        CDZWa:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($IMjzj) {
            return new HINeytZSirxpb(config('upload.maker'), Storage::disk('public'));
        });
        goto LQbIg;
        s4odB:
        $this->app->bind(WatermarkTextJobInterface::class, function ($IMjzj) {
            return new T69reQ7rYjN5U(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto K4oa3;
        MsqIn:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($IMjzj) {
            return new Rmj93vDJAXwoy(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto s4odB;
        k4MLh:
        $this->app->singleton(ZOxMhYUF0fAsi::class, function () {
            return new XsyK4RfzqtWuF(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto zos3g;
        yCOHc:
        $this->app->bind(CompressJobInterface::class, function ($IMjzj) {
            return new ZDAvU58qFgawR(config('upload.maker'), Storage::disk('public'));
        });
        goto Kl6jR;
        Sjps2:
        $this->app->singleton(JrqDsqkHsYBsl::class, function ($IMjzj) {
            return new JrqDsqkHsYBsl(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto bQ_qY;
        mw16a:
        $this->app->tag([V9C418KGxojKp::class, SCLUkMck5sD3t::class, LoocOt1CuyUVF::class], 'file.location.resolvers');
        goto z7vxq;
        edA9Y:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
