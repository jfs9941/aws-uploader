<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\GOwwZ3Q3r8QRr;
use Jfs\Uploader\Contracts\FK56xL1HuXbff;
use Jfs\Uploader\Encoder\AhS2r9oThLsk4;
use Jfs\Uploader\Encoder\OD4qD4m00G9FN;
use Jfs\Uploader\Service\M5DWm1ijeK6rr;
use Jfs\Uploader\Service\FileResolver\BG9NUZHiHwO5t;
use Jfs\Uploader\Service\FileResolver\UP2FGnLCkVARX;
use Jfs\Uploader\Service\FileResolver\CxCD6mwo7AAKn;
use Jfs\Uploader\Service\Jobs\M5yKotDOzwutt;
use Jfs\Uploader\Service\Jobs\VHmDG4EsbO5eS;
use Jfs\Uploader\Service\Jobs\FYG7TkTt6V0ka;
use Jfs\Uploader\Service\Jobs\SS73yBk9TqSqN;
use Jfs\Uploader\Service\Jobs\DxgrIjw5I3kXq;
use Jfs\Uploader\Service\Jobs\CCr1hJVTHpbUr;
use Jfs\Uploader\Service\Jobs\AMUtYtPIPSaQA;
use Jfs\Uploader\Service\Jobs\CibXqX7IkWYya;
use Jfs\Uploader\Service\Jobs\B1PYBuYszNkz7;
use Jfs\Uploader\Service\Jobs\QPf4e20nrFRhd;
use Jfs\Uploader\Service\CU3MKrDqwc6OY;
use Jfs\Uploader\Service\DdwCOXXHdXXTK;
use Jfs\Uploader\Service\IOjd5DofFGe5l;
use Jfs\Uploader\Service\ECvBYVAkZdKJv;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto DxfMN;
        S5SRb:
        $this->app->bind(BlurVideoJobInterface::class, function ($bmwWx) {
            return new VHmDG4EsbO5eS(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto tYo6l;
        tYo6l:
        $this->app->bind(CompressJobInterface::class, function ($bmwWx) {
            return new FYG7TkTt6V0ka(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto U385a;
        X4qok:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($bmwWx) {
            return new CCr1hJVTHpbUr();
        });
        goto SjAKr;
        s3TVu:
        $this->app->bind(GalleryCloudInterface::class, function ($bmwWx) {
            return new GOwwZ3Q3r8QRr();
        });
        goto nvyLm;
        SjAKr:
        $this->app->bind(StoreToS3JobInterface::class, function ($bmwWx) {
            return new AMUtYtPIPSaQA(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto RpXHO;
        U385a:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($bmwWx) {
            return new SS73yBk9TqSqN(Storage::disk('s3'), Storage::disk('public'));
        });
        goto cut02;
        dtIcI:
        $this->app->bind(BlurJobInterface::class, function ($bmwWx) {
            return new M5yKotDOzwutt(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto S5SRb;
        iOwYb:
        $this->app->singleton(M5DWm1ijeK6rr::class, function ($bmwWx) {
            return new M5DWm1ijeK6rr($bmwWx->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ztuAH;
        SK6ZQ:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($bmwWx) {
            return new ECvBYVAkZdKJv($bmwWx->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto eqLVs;
        eqLVs:
        $this->app->singleton(FK56xL1HuXbff::class, function () {
            return new DdwCOXXHdXXTK(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto iOwYb;
        ztuAH:
        $this->app->singleton(CU3MKrDqwc6OY::class, function ($bmwWx) {
            return new CU3MKrDqwc6OY(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto KPAU1;
        pVOP1:
        $this->app->tag([CxCD6mwo7AAKn::class, UP2FGnLCkVARX::class, BG9NUZHiHwO5t::class], 'file.location.resolvers');
        goto dtIcI;
        CRzQR:
        $this->app->bind(WatermarkTextJobInterface::class, function ($bmwWx) {
            return new QPf4e20nrFRhd(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto s3TVu;
        CDozd:
        $this->app->bind(MediaEncodeJobInterface::class, function ($bmwWx) {
            return new B1PYBuYszNkz7(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto X4qok;
        DxfMN:
        $this->app->bind(UploadServiceInterface::class, function ($bmwWx) {
            return new IOjd5DofFGe5l($bmwWx->make(M5DWm1ijeK6rr::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto SK6ZQ;
        RpXHO:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($bmwWx) {
            return new CibXqX7IkWYya(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto CRzQR;
        cut02:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($bmwWx) {
            return new DxgrIjw5I3kXq(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto CDozd;
        KPAU1:
        $this->app->singleton(AhS2r9oThLsk4::class, function ($bmwWx) {
            return new AhS2r9oThLsk4($bmwWx->make(CU3MKrDqwc6OY::class), Storage::disk('s3'));
        });
        goto jqS_P;
        jqS_P:
        $this->app->bind(OD4qD4m00G9FN::class, function ($bmwWx) {
            return new OD4qD4m00G9FN(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto pVOP1;
        nvyLm:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
