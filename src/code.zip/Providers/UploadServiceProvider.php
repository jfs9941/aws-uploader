<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\HiUIMM2knyFBk;
use Jfs\Uploader\Contracts\JPNYCZuAxKZZ0;
use Jfs\Uploader\Encoder\BLVdwIMNr8HKZ;
use Jfs\Uploader\Encoder\YPYrzGu9j2MTY;
use Jfs\Uploader\Service\DdKzEi3F2rCpY;
use Jfs\Uploader\Service\FileResolver\T4zBmGE624uac;
use Jfs\Uploader\Service\FileResolver\XJ2ZNelkIZVH9;
use Jfs\Uploader\Service\FileResolver\Tb52pxIFNUc2p;
use Jfs\Uploader\Service\Jobs\PPTHvn2ZZjDG2;
use Jfs\Uploader\Service\Jobs\OljztYPm2XT11;
use Jfs\Uploader\Service\Jobs\RAbSIaLEVAdpg;
use Jfs\Uploader\Service\Jobs\MvSastLUHfY8v;
use Jfs\Uploader\Service\Jobs\VldRXCl1IfuWw;
use Jfs\Uploader\Service\Jobs\TZ5ceG3KuRxPH;
use Jfs\Uploader\Service\Jobs\YxxsId4Qri02r;
use Jfs\Uploader\Service\Jobs\OyS42HnppK2sc;
use Jfs\Uploader\Service\Jobs\BHtHNvBZTQZKI;
use Jfs\Uploader\Service\Jobs\IMZ6bvD6V5eVz;
use Jfs\Uploader\Service\UYnuxInq7rBrt;
use Jfs\Uploader\Service\Jm1fOTq3mpmK9;
use Jfs\Uploader\Service\CMhkamOBOkKax;
use Jfs\Uploader\Service\AD5iQ3OzziIHF;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto Kc9Jj;
        c5sXd:
        $this->app->singleton(DdKzEi3F2rCpY::class, function ($iNlLx) {
            return new DdKzEi3F2rCpY($iNlLx->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto ilIIf;
        cSphI:
        $this->app->singleton(JPNYCZuAxKZZ0::class, function () {
            return new Jm1fOTq3mpmK9(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto c5sXd;
        d4zXY:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($iNlLx) {
            return new VldRXCl1IfuWw(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto y5QF5;
        D9Fxj:
        $this->app->bind(YPYrzGu9j2MTY::class, function ($iNlLx) {
            return new YPYrzGu9j2MTY(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto fJZBl;
        Wb9KD:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($iNlLx) {
            return new AD5iQ3OzziIHF($iNlLx->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto cSphI;
        vZ2WT:
        $this->app->bind(StoreToS3JobInterface::class, function ($iNlLx) {
            return new YxxsId4Qri02r(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto gNXvq;
        c6Qek:
        $this->app->singleton(BLVdwIMNr8HKZ::class, function ($iNlLx) {
            return new BLVdwIMNr8HKZ($iNlLx->make(UYnuxInq7rBrt::class), Storage::disk('s3'));
        });
        goto D9Fxj;
        fJZBl:
        $this->app->tag([Tb52pxIFNUc2p::class, XJ2ZNelkIZVH9::class, T4zBmGE624uac::class], 'file.location.resolvers');
        goto CjOdd;
        CjOdd:
        $this->app->bind(BlurJobInterface::class, function ($iNlLx) {
            return new PPTHvn2ZZjDG2(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Q70x1;
        ilIIf:
        $this->app->singleton(UYnuxInq7rBrt::class, function ($iNlLx) {
            return new UYnuxInq7rBrt(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto c6Qek;
        BE7vj:
        $this->app->bind(WatermarkTextJobInterface::class, function ($iNlLx) {
            return new IMZ6bvD6V5eVz(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto DcC_x;
        aJ2Ge:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($iNlLx) {
            return new TZ5ceG3KuRxPH();
        });
        goto vZ2WT;
        gNXvq:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($iNlLx) {
            return new OyS42HnppK2sc(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto BE7vj;
        y5QF5:
        $this->app->bind(MediaEncodeJobInterface::class, function ($iNlLx) {
            return new BHtHNvBZTQZKI(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto aJ2Ge;
        Q70x1:
        $this->app->bind(BlurVideoJobInterface::class, function ($iNlLx) {
            return new OljztYPm2XT11(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto yTQ5t;
        DcC_x:
        $this->app->bind(GalleryCloudInterface::class, function ($iNlLx) {
            return new HiUIMM2knyFBk();
        });
        goto hxWWP;
        Kc9Jj:
        $this->app->bind(UploadServiceInterface::class, function ($iNlLx) {
            return new CMhkamOBOkKax($iNlLx->make(DdKzEi3F2rCpY::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto Wb9KD;
        yTQ5t:
        $this->app->bind(CompressJobInterface::class, function ($iNlLx) {
            return new RAbSIaLEVAdpg(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto GEfjB;
        GEfjB:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($iNlLx) {
            return new MvSastLUHfY8v(Storage::disk('s3'), Storage::disk('public'));
        });
        goto d4zXY;
        hxWWP:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
