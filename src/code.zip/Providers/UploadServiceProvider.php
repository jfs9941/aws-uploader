<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\KNzRObv7c39L1;
use Jfs\Uploader\Contracts\ZBw3vE9HMeZfI;
use Jfs\Uploader\Encoder\NLoWoIWKwVnRR;
use Jfs\Uploader\Encoder\WAdrIkdjR1FAW;
use Jfs\Uploader\Service\L3m1gGxcrxodn;
use Jfs\Uploader\Service\FileResolver\CFO3Q3PYlbIgw;
use Jfs\Uploader\Service\FileResolver\G3Vezev4SHYub;
use Jfs\Uploader\Service\FileResolver\LhGdkM0htj9eX;
use Jfs\Uploader\Service\Jobs\Pnv2QYDRYqXfq;
use Jfs\Uploader\Service\Jobs\EH8WJRdSgiB4s;
use Jfs\Uploader\Service\Jobs\PTFvvXXiafc6j;
use Jfs\Uploader\Service\Jobs\EYY79LmU9qCZ5;
use Jfs\Uploader\Service\Jobs\K94er8DTblE32;
use Jfs\Uploader\Service\Jobs\FYcHdtuSdJaYc;
use Jfs\Uploader\Service\Jobs\Fui1M1t1mQ9em;
use Jfs\Uploader\Service\Jobs\R3u9wNZ862DVS;
use Jfs\Uploader\Service\Jobs\IWu8Y0IIGvCf9;
use Jfs\Uploader\Service\Jobs\LdRkQgcNcI7mH;
use Jfs\Uploader\Service\ETNYJFyUYZrNI;
use Jfs\Uploader\Service\Q9u6o449sXscP;
use Jfs\Uploader\Service\NyCbXtNoSpUdB;
use Jfs\Uploader\Service\WSkgEM3WwLYPA;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto EuMkN;
        tExXp:
        $this->app->bind(GalleryCloudInterface::class, function ($cE6Md) {
            return new KNzRObv7c39L1();
        });
        goto LqRyw;
        U2_zs:
        $this->app->singleton(ETNYJFyUYZrNI::class, function ($cE6Md) {
            return new ETNYJFyUYZrNI(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto s9QV4;
        aWUL1:
        $this->app->singleton(L3m1gGxcrxodn::class, function ($cE6Md) {
            return new L3m1gGxcrxodn($cE6Md->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto U2_zs;
        on1dE:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($cE6Md) {
            return new K94er8DTblE32(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto XkRNT;
        XkRNT:
        $this->app->bind(MediaEncodeJobInterface::class, function ($cE6Md) {
            return new IWu8Y0IIGvCf9(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto joByq;
        s9QV4:
        $this->app->singleton(NLoWoIWKwVnRR::class, function ($cE6Md) {
            return new NLoWoIWKwVnRR($cE6Md->make(ETNYJFyUYZrNI::class), Storage::disk('s3'));
        });
        goto UP01D;
        UP01D:
        $this->app->bind(WAdrIkdjR1FAW::class, function ($cE6Md) {
            return new WAdrIkdjR1FAW(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto IgrZj;
        ldDea:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($cE6Md) {
            return new R3u9wNZ862DVS(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto nxoIA;
        CXMBp:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($cE6Md) {
            return new EYY79LmU9qCZ5(Storage::disk('s3'), Storage::disk('public'));
        });
        goto on1dE;
        HLRX1:
        $this->app->bind(CompressJobInterface::class, function ($cE6Md) {
            return new PTFvvXXiafc6j(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto CXMBp;
        EoLvf:
        $this->app->bind(BlurVideoJobInterface::class, function ($cE6Md) {
            return new EH8WJRdSgiB4s(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto HLRX1;
        nxoIA:
        $this->app->bind(WatermarkTextJobInterface::class, function ($cE6Md) {
            return new LdRkQgcNcI7mH(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto tExXp;
        EuMkN:
        $this->app->bind(UploadServiceInterface::class, function ($cE6Md) {
            return new NyCbXtNoSpUdB($cE6Md->make(L3m1gGxcrxodn::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto xMwpc;
        ZECH4:
        $this->app->bind(StoreToS3JobInterface::class, function ($cE6Md) {
            return new Fui1M1t1mQ9em(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ldDea;
        xMwpc:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($cE6Md) {
            return new WSkgEM3WwLYPA($cE6Md->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto g9a7r;
        joByq:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($cE6Md) {
            return new FYcHdtuSdJaYc();
        });
        goto ZECH4;
        qQSS1:
        $this->app->bind(BlurJobInterface::class, function ($cE6Md) {
            return new Pnv2QYDRYqXfq(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto EoLvf;
        IgrZj:
        $this->app->tag([LhGdkM0htj9eX::class, G3Vezev4SHYub::class, CFO3Q3PYlbIgw::class], 'file.location.resolvers');
        goto qQSS1;
        g9a7r:
        $this->app->singleton(ZBw3vE9HMeZfI::class, function () {
            return new Q9u6o449sXscP(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto aWUL1;
        LqRyw:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
