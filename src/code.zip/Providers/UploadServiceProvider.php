<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\VliFid0C4Omc8;
use Jfs\Uploader\Contracts\QmpIhYv3zjvt7;
use Jfs\Uploader\Encoder\U69m2hVAaudAN;
use Jfs\Uploader\Encoder\UXK5mdKvFrtYj;
use Jfs\Uploader\Service\I399kYrV05irP;
use Jfs\Uploader\Service\FileResolver\LgEVckFqbG6iE;
use Jfs\Uploader\Service\FileResolver\QmWoqwpqcvj4M;
use Jfs\Uploader\Service\FileResolver\AxFxcCYGi0Njx;
use Jfs\Uploader\Service\Jobs\KueqXcQAwmy4t;
use Jfs\Uploader\Service\Jobs\B5IvjnIn66xap;
use Jfs\Uploader\Service\Jobs\Um6s5iLRGphZr;
use Jfs\Uploader\Service\Jobs\ODrXS1LMYXHij;
use Jfs\Uploader\Service\Jobs\DmB4kwnwstr5R;
use Jfs\Uploader\Service\Jobs\AmU2ZFYXYCTrO;
use Jfs\Uploader\Service\Jobs\TRJKjbzOlxjlO;
use Jfs\Uploader\Service\Jobs\X7RVgVZeG5l7r;
use Jfs\Uploader\Service\Jobs\VDvqdYRhzsIIF;
use Jfs\Uploader\Service\Jobs\R9c0RS01szy7o;
use Jfs\Uploader\Service\FTup2pWS3iynB;
use Jfs\Uploader\Service\GRHQHm8JVCKmn;
use Jfs\Uploader\Service\RNb2RMbrRcSVj;
use Jfs\Uploader\Service\TfPYBqlVL98zf;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto aAXx1;
        javIC:
        $this->app->bind(UXK5mdKvFrtYj::class, function ($eLucY) {
            return new UXK5mdKvFrtYj(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto rvKNE;
        cv3zb:
        $this->app->bind(MediaEncodeJobInterface::class, function ($eLucY) {
            return new VDvqdYRhzsIIF(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto QC92v;
        SMIV9:
        $this->app->singleton(U69m2hVAaudAN::class, function ($eLucY) {
            return new U69m2hVAaudAN($eLucY->make(FTup2pWS3iynB::class), Storage::disk('s3'));
        });
        goto javIC;
        bM8hS:
        $this->app->bind(GalleryCloudInterface::class, function ($eLucY) {
            return new VliFid0C4Omc8();
        });
        goto KOGDp;
        EqQ1y:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($eLucY) {
            return new X7RVgVZeG5l7r(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ZPgkY;
        QC92v:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($eLucY) {
            return new AmU2ZFYXYCTrO();
        });
        goto Zj6GM;
        rvKNE:
        $this->app->tag([AxFxcCYGi0Njx::class, QmWoqwpqcvj4M::class, LgEVckFqbG6iE::class], 'file.location.resolvers');
        goto Fvdps;
        MyxPf:
        $this->app->singleton(I399kYrV05irP::class, function ($eLucY) {
            return new I399kYrV05irP($eLucY->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto IQuXs;
        x0APE:
        $this->app->bind(BlurVideoJobInterface::class, function ($eLucY) {
            return new B5IvjnIn66xap(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto yyIzX;
        P9QcK:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($eLucY) {
            return new ODrXS1LMYXHij(Storage::disk('s3'), Storage::disk('public'));
        });
        goto wV_1W;
        XkW8J:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($eLucY) {
            return new TfPYBqlVL98zf($eLucY->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto ia9fb;
        aAXx1:
        $this->app->bind(UploadServiceInterface::class, function ($eLucY) {
            return new RNb2RMbrRcSVj($eLucY->make(I399kYrV05irP::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto XkW8J;
        wV_1W:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($eLucY) {
            return new DmB4kwnwstr5R(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto cv3zb;
        yyIzX:
        $this->app->bind(CompressJobInterface::class, function ($eLucY) {
            return new Um6s5iLRGphZr(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto P9QcK;
        ZPgkY:
        $this->app->bind(WatermarkTextJobInterface::class, function ($eLucY) {
            return new R9c0RS01szy7o(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto bM8hS;
        IQuXs:
        $this->app->singleton(FTup2pWS3iynB::class, function ($eLucY) {
            return new FTup2pWS3iynB(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto SMIV9;
        Zj6GM:
        $this->app->bind(StoreToS3JobInterface::class, function ($eLucY) {
            return new TRJKjbzOlxjlO(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto EqQ1y;
        Fvdps:
        $this->app->bind(BlurJobInterface::class, function ($eLucY) {
            return new KueqXcQAwmy4t(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto x0APE;
        ia9fb:
        $this->app->singleton(QmpIhYv3zjvt7::class, function () {
            return new GRHQHm8JVCKmn(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto MyxPf;
        KOGDp:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
