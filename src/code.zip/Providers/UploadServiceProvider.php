<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\JlFZ7iGHeBLrc;
use Jfs\Uploader\Contracts\O79PdR1cao6Xq;
use Jfs\Uploader\Encoder\HYDAkFMesEGUF;
use Jfs\Uploader\Encoder\FffZ2siMxgG2d;
use Jfs\Uploader\Service\TFO1z3TFjdeZq;
use Jfs\Uploader\Service\FileResolver\SmYZWuXRNKWP0;
use Jfs\Uploader\Service\FileResolver\MhTF6IU60uqTV;
use Jfs\Uploader\Service\FileResolver\PWsJgvKPEBgmL;
use Jfs\Uploader\Service\Jobs\R91BqBCvPLTzy;
use Jfs\Uploader\Service\Jobs\PP0MV7J3Kq0AT;
use Jfs\Uploader\Service\Jobs\QWiNN7Fkwlfp4;
use Jfs\Uploader\Service\Jobs\N4xvQ8HUrxUqz;
use Jfs\Uploader\Service\Jobs\DkGzFZQTsS4ip;
use Jfs\Uploader\Service\Jobs\O0yceq44mJaYq;
use Jfs\Uploader\Service\Jobs\KsIQL55FHbMhr;
use Jfs\Uploader\Service\Jobs\HPYlaso4bwR4N;
use Jfs\Uploader\Service\Jobs\Qj93lBMoCPwJq;
use Jfs\Uploader\Service\Jobs\DlMdA34PnIZ0G;
use Jfs\Uploader\Service\EjF4mjWaYHYqw;
use Jfs\Uploader\Service\PIItI2ah2Zu1r;
use Jfs\Uploader\Service\HszAWPogkYfHW;
use Jfs\Uploader\Service\PS3ZFHv2FNuP9;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto DbsZR;
        s3RD1:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($s3JEC) {
            return new O0yceq44mJaYq();
        });
        goto Lqdta;
        DbsZR:
        $this->app->bind(UploadServiceInterface::class, function ($s3JEC) {
            return new HszAWPogkYfHW($s3JEC->make(TFO1z3TFjdeZq::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto X_zDg;
        o6yIh:
        $this->app->bind(MediaEncodeJobInterface::class, function ($s3JEC) {
            return new Qj93lBMoCPwJq(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto s3RD1;
        SPuRW:
        $this->app->singleton(HYDAkFMesEGUF::class, function ($s3JEC) {
            return new HYDAkFMesEGUF($s3JEC->make(EjF4mjWaYHYqw::class), Storage::disk('s3'));
        });
        goto oZlKt;
        uxrXh:
        $this->app->singleton(EjF4mjWaYHYqw::class, function ($s3JEC) {
            return new EjF4mjWaYHYqw(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto SPuRW;
        X_zDg:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($s3JEC) {
            return new PS3ZFHv2FNuP9($s3JEC->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto n12XG;
        AuztW:
        $this->app->bind(CompressJobInterface::class, function ($s3JEC) {
            return new QWiNN7Fkwlfp4(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto xd0L_;
        Pl780:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($s3JEC) {
            return new HPYlaso4bwR4N(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ZVzwb;
        A73rs:
        $this->app->bind(GalleryCloudInterface::class, function ($s3JEC) {
            return new JlFZ7iGHeBLrc();
        });
        goto vJVgZ;
        LnqPb:
        $this->app->tag([PWsJgvKPEBgmL::class, MhTF6IU60uqTV::class, SmYZWuXRNKWP0::class], 'file.location.resolvers');
        goto kW9Qq;
        ZVzwb:
        $this->app->bind(WatermarkTextJobInterface::class, function ($s3JEC) {
            return new DlMdA34PnIZ0G(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto A73rs;
        kW9Qq:
        $this->app->bind(BlurJobInterface::class, function ($s3JEC) {
            return new R91BqBCvPLTzy(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto o9KR8;
        oZlKt:
        $this->app->bind(FffZ2siMxgG2d::class, function ($s3JEC) {
            return new FffZ2siMxgG2d(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto LnqPb;
        xd0L_:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($s3JEC) {
            return new N4xvQ8HUrxUqz(Storage::disk('s3'), Storage::disk('public'));
        });
        goto ADjFc;
        Lqdta:
        $this->app->bind(StoreToS3JobInterface::class, function ($s3JEC) {
            return new KsIQL55FHbMhr(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Pl780;
        fpYqH:
        $this->app->singleton(TFO1z3TFjdeZq::class, function ($s3JEC) {
            return new TFO1z3TFjdeZq($s3JEC->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto uxrXh;
        n12XG:
        $this->app->singleton(O79PdR1cao6Xq::class, function () {
            return new PIItI2ah2Zu1r(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto fpYqH;
        ADjFc:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($s3JEC) {
            return new DkGzFZQTsS4ip(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto o6yIh;
        o9KR8:
        $this->app->bind(BlurVideoJobInterface::class, function ($s3JEC) {
            return new PP0MV7J3Kq0AT(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto AuztW;
        vJVgZ:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
