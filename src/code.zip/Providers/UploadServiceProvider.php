<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\FlJAt0fGhvGBs;
use Jfs\Uploader\Contracts\LuYApSsjKQvJj;
use Jfs\Uploader\Encoder\Qyf5nkvkW6Bhl;
use Jfs\Uploader\Encoder\Ef3aL8loW3QaG;
use Jfs\Uploader\Service\Mw0dAyuvhKDel;
use Jfs\Uploader\Service\FileResolver\OLInOHsNYJfQl;
use Jfs\Uploader\Service\FileResolver\T3iXqHmdaf6tz;
use Jfs\Uploader\Service\FileResolver\MNFNRMC1rOgqv;
use Jfs\Uploader\Service\Jobs\TmlmOlhnYgfo5;
use Jfs\Uploader\Service\Jobs\KyfgQxmnoRboH;
use Jfs\Uploader\Service\Jobs\KqdVmZy56VmBM;
use Jfs\Uploader\Service\Jobs\B20s7JuKm8vWq;
use Jfs\Uploader\Service\Jobs\WwsvFxRROTAaB;
use Jfs\Uploader\Service\Jobs\WPhjmMzudmjL8;
use Jfs\Uploader\Service\Jobs\Y0kDKtH8tjxQG;
use Jfs\Uploader\Service\Jobs\F06O7XZhnHV45;
use Jfs\Uploader\Service\Jobs\Oaxl59EYXP0GF;
use Jfs\Uploader\Service\Jobs\EupLu2DTVns6G;
use Jfs\Uploader\Service\VEn7C5MII4ANw;
use Jfs\Uploader\Service\NCOAFhLniyr9A;
use Jfs\Uploader\Service\AnvaJcIHdpnLZ;
use Jfs\Uploader\Service\FXddnQ0BHKM8d;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto aAy_c;
        hMjxF:
        $this->app->tag([MNFNRMC1rOgqv::class, T3iXqHmdaf6tz::class, OLInOHsNYJfQl::class], 'file.location.resolvers');
        goto TIEfF;
        Fn5S_:
        $this->app->singleton(Qyf5nkvkW6Bhl::class, function ($udY3T) {
            return new Qyf5nkvkW6Bhl($udY3T->make(VEn7C5MII4ANw::class), Storage::disk('s3'));
        });
        goto P5iuz;
        z_Jgk:
        $this->app->bind(StoreToS3JobInterface::class, function ($udY3T) {
            return new Y0kDKtH8tjxQG(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto gSyRr;
        TGfDG:
        $this->app->bind(WatermarkTextJobInterface::class, function ($udY3T) {
            return new EupLu2DTVns6G(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto gvdk_;
        aAy_c:
        $this->app->bind(UploadServiceInterface::class, function ($udY3T) {
            return new AnvaJcIHdpnLZ($udY3T->make(Mw0dAyuvhKDel::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto sXRtn;
        GlCaz:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($udY3T) {
            return new WPhjmMzudmjL8();
        });
        goto z_Jgk;
        P5iuz:
        $this->app->bind(Ef3aL8loW3QaG::class, function ($udY3T) {
            return new Ef3aL8loW3QaG(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto hMjxF;
        Myh1W:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($udY3T) {
            return new WwsvFxRROTAaB(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto C5ggp;
        VmFHY:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($udY3T) {
            return new B20s7JuKm8vWq(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Myh1W;
        C5ggp:
        $this->app->bind(MediaEncodeJobInterface::class, function ($udY3T) {
            return new Oaxl59EYXP0GF(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto GlCaz;
        sXRtn:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($udY3T) {
            return new FXddnQ0BHKM8d($udY3T->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Fy0Jr;
        gSyRr:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($udY3T) {
            return new F06O7XZhnHV45(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto TGfDG;
        gvdk_:
        $this->app->bind(GalleryCloudInterface::class, function ($udY3T) {
            return new FlJAt0fGhvGBs();
        });
        goto IQjqz;
        qkIDH:
        $this->app->singleton(Mw0dAyuvhKDel::class, function ($udY3T) {
            return new Mw0dAyuvhKDel($udY3T->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SLIar;
        TIEfF:
        $this->app->bind(BlurJobInterface::class, function ($udY3T) {
            return new TmlmOlhnYgfo5(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Y7TWV;
        Y7TWV:
        $this->app->bind(BlurVideoJobInterface::class, function ($udY3T) {
            return new KyfgQxmnoRboH(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Vxr0c;
        SLIar:
        $this->app->singleton(VEn7C5MII4ANw::class, function ($udY3T) {
            return new VEn7C5MII4ANw(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto Fn5S_;
        Fy0Jr:
        $this->app->singleton(LuYApSsjKQvJj::class, function () {
            return new NCOAFhLniyr9A(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto qkIDH;
        Vxr0c:
        $this->app->bind(CompressJobInterface::class, function ($udY3T) {
            return new KqdVmZy56VmBM(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto VmFHY;
        IQjqz:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
