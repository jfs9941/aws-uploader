<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\Kw2zQAw3cEoNz;
use Jfs\Uploader\Contracts\GuNvSDjrDhnZX;
use Jfs\Uploader\Encoder\XeMVcGXMtTgrJ;
use Jfs\Uploader\Encoder\PBLLq55t18yGF;
use Jfs\Uploader\Service\RIRnT0b6ENemU;
use Jfs\Uploader\Service\FileResolver\TrxAwek9OyeV2;
use Jfs\Uploader\Service\FileResolver\AMWgKhecfqcJS;
use Jfs\Uploader\Service\FileResolver\Ffgyfl3hsIZIl;
use Jfs\Uploader\Service\Jobs\XSe3NfzICF53P;
use Jfs\Uploader\Service\Jobs\LelhWj5hRA68a;
use Jfs\Uploader\Service\Jobs\S0PLJbUBjodet;
use Jfs\Uploader\Service\Jobs\Y61vXfeIGD9zV;
use Jfs\Uploader\Service\Jobs\SWUwFIAVXk4XG;
use Jfs\Uploader\Service\Jobs\ZZJyRlQY3zMvI;
use Jfs\Uploader\Service\Jobs\JaU0LQwVRva8r;
use Jfs\Uploader\Service\Jobs\SNSPr6KDnypTR;
use Jfs\Uploader\Service\Jobs\AdFYWfmNJLcjB;
use Jfs\Uploader\Service\Jobs\Du7b19WbdeheC;
use Jfs\Uploader\Service\Vxy5RzsyYlKDb;
use Jfs\Uploader\Service\LNm3X2KAsSELE;
use Jfs\Uploader\Service\HLeMoVWR5TBAt;
use Jfs\Uploader\Service\PmygY0mHR97CP;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto kCJyV;
        kCJyV:
        $this->app->bind(UploadServiceInterface::class, function ($dAZo9) {
            return new HLeMoVWR5TBAt($dAZo9->make(RIRnT0b6ENemU::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto vss51;
        navi1:
        $this->app->singleton(GuNvSDjrDhnZX::class, function () {
            return new LNm3X2KAsSELE(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto SEYR9;
        GGIg1:
        $this->app->bind(StoreToS3JobInterface::class, function ($dAZo9) {
            return new JaU0LQwVRva8r(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto qtI9J;
        qtI9J:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($dAZo9) {
            return new SNSPr6KDnypTR(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto hX8bJ;
        qjqkq:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($dAZo9) {
            return new ZZJyRlQY3zMvI();
        });
        goto GGIg1;
        wkE5u:
        $this->app->bind(GalleryCloudInterface::class, function ($dAZo9) {
            return new Kw2zQAw3cEoNz();
        });
        goto aCYcx;
        vtrTk:
        $this->app->singleton(XeMVcGXMtTgrJ::class, function ($dAZo9) {
            return new XeMVcGXMtTgrJ($dAZo9->make(Vxy5RzsyYlKDb::class), Storage::disk('s3'));
        });
        goto xS9ov;
        Q_ToU:
        $this->app->bind(CompressJobInterface::class, function ($dAZo9) {
            return new S0PLJbUBjodet(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto oQ2YW;
        hX8bJ:
        $this->app->bind(WatermarkTextJobInterface::class, function ($dAZo9) {
            return new Du7b19WbdeheC(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto wkE5u;
        Kq88H:
        $this->app->bind(BlurJobInterface::class, function ($dAZo9) {
            return new XSe3NfzICF53P(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto m4nEQ;
        vss51:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($dAZo9) {
            return new PmygY0mHR97CP($dAZo9->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto navi1;
        oQ2YW:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($dAZo9) {
            return new Y61vXfeIGD9zV(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Zs1an;
        xS9ov:
        $this->app->bind(PBLLq55t18yGF::class, function ($dAZo9) {
            return new PBLLq55t18yGF(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto TyieC;
        SEYR9:
        $this->app->singleton(RIRnT0b6ENemU::class, function ($dAZo9) {
            return new RIRnT0b6ENemU($dAZo9->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto KBUwh;
        KBUwh:
        $this->app->singleton(Vxy5RzsyYlKDb::class, function ($dAZo9) {
            return new Vxy5RzsyYlKDb(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto vtrTk;
        Zs1an:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($dAZo9) {
            return new SWUwFIAVXk4XG(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto lC2IE;
        lC2IE:
        $this->app->bind(MediaEncodeJobInterface::class, function ($dAZo9) {
            return new AdFYWfmNJLcjB(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto qjqkq;
        TyieC:
        $this->app->tag([Ffgyfl3hsIZIl::class, AMWgKhecfqcJS::class, TrxAwek9OyeV2::class], 'file.location.resolvers');
        goto Kq88H;
        m4nEQ:
        $this->app->bind(BlurVideoJobInterface::class, function ($dAZo9) {
            return new LelhWj5hRA68a(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Q_ToU;
        aCYcx:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
