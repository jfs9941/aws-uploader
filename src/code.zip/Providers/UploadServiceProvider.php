<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\MO6RypyPX9Ssy;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Uploader\Encoder\Z476P5MAXqSnV;
use Jfs\Uploader\Encoder\QAZGS1jBxOIat;
use Jfs\Uploader\Service\XqoSwDelQBsQt;
use Jfs\Uploader\Service\FileResolver\TnttznqISry49;
use Jfs\Uploader\Service\FileResolver\Wc0QMmHjHkJXD;
use Jfs\Uploader\Service\FileResolver\IBhS6Sn3NgOzB;
use Jfs\Uploader\Service\Jobs\Kf7aQBaDvRG4E;
use Jfs\Uploader\Service\Jobs\YLAM2pJCDHJ2V;
use Jfs\Uploader\Service\Jobs\UT0do0vTgfaif;
use Jfs\Uploader\Service\Jobs\ELXG3ZFAS3r0j;
use Jfs\Uploader\Service\Jobs\CtrinJDneAynd;
use Jfs\Uploader\Service\Jobs\Pe5Tk8njhFbo7;
use Jfs\Uploader\Service\Jobs\DTho4X5GKmLwU;
use Jfs\Uploader\Service\Jobs\G7AIMeSUQ84TK;
use Jfs\Uploader\Service\Jobs\XL9VMQm4mpnzT;
use Jfs\Uploader\Service\Jobs\ONE13VivQKJcY;
use Jfs\Uploader\Service\Cjv3UOrDUgWrC;
use Jfs\Uploader\Service\EBtMKqg57Ah66;
use Jfs\Uploader\Service\Q7Ya1DOnGbc8X;
use Jfs\Uploader\Service\MEBayMa8o64NU;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto drEqR;
        b8K_m:
        $this->app->bind(CompressJobInterface::class, function ($bMNtH) {
            return new UT0do0vTgfaif(config('upload.maker'), Storage::disk('public'));
        });
        goto wA0Aq;
        xvJm4:
        $this->app->tag([IBhS6Sn3NgOzB::class, Wc0QMmHjHkJXD::class, TnttznqISry49::class], 'file.location.resolvers');
        goto HUB_U;
        ww36E:
        $this->app->bind(QAZGS1jBxOIat::class, function ($bMNtH) {
            return new QAZGS1jBxOIat(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto xvJm4;
        sZem9:
        $this->app->singleton(Cjv3UOrDUgWrC::class, function ($bMNtH) {
            return new Cjv3UOrDUgWrC(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto ej9VL;
        hBYjS:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($bMNtH) {
            return new G7AIMeSUQ84TK(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto nr_o_;
        ej9VL:
        $this->app->singleton(Z476P5MAXqSnV::class, function ($bMNtH) {
            return new Z476P5MAXqSnV($bMNtH->make(Cjv3UOrDUgWrC::class), Storage::disk('s3'));
        });
        goto ww36E;
        bZz3A:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($bMNtH) {
            return new CtrinJDneAynd(config('upload.maker'), Storage::disk('public'));
        });
        goto NVCCt;
        wA0Aq:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($bMNtH) {
            return new ELXG3ZFAS3r0j(Storage::disk('s3'), Storage::disk('public'));
        });
        goto bZz3A;
        NVCCt:
        $this->app->bind(MediaEncodeJobInterface::class, function ($bMNtH) {
            return new XL9VMQm4mpnzT(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto LYaS3;
        drEqR:
        $this->app->bind(UploadServiceInterface::class, function ($bMNtH) {
            return new Q7Ya1DOnGbc8X($bMNtH->make(XqoSwDelQBsQt::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto CSRBi;
        CSRBi:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($bMNtH) {
            return new MEBayMa8o64NU($bMNtH->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Nxhu0;
        HUB_U:
        $this->app->bind(BlurJobInterface::class, function ($bMNtH) {
            return new Kf7aQBaDvRG4E(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto GbMp7;
        Nxhu0:
        $this->app->singleton(TC3rpsU2GuKAE::class, function () {
            return new EBtMKqg57Ah66(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto Rx2jC;
        LYaS3:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($bMNtH) {
            return new Pe5Tk8njhFbo7();
        });
        goto KL4zM;
        nr_o_:
        $this->app->bind(WatermarkTextJobInterface::class, function ($bMNtH) {
            return new ONE13VivQKJcY(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto Wuojh;
        KL4zM:
        $this->app->bind(StoreToS3JobInterface::class, function ($bMNtH) {
            return new DTho4X5GKmLwU(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto hBYjS;
        GbMp7:
        $this->app->bind(BlurVideoJobInterface::class, function ($bMNtH) {
            return new YLAM2pJCDHJ2V(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto b8K_m;
        Rx2jC:
        $this->app->singleton(XqoSwDelQBsQt::class, function ($bMNtH) {
            return new XqoSwDelQBsQt($bMNtH->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto sZem9;
        Wuojh:
        $this->app->bind(GalleryCloudInterface::class, function ($bMNtH) {
            return new MO6RypyPX9Ssy();
        });
        goto SfeqT;
        SfeqT:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
