<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\Rcvt9IX4AhWY7;
use Jfs\Uploader\Contracts\VjEI9Nu3TyWfD;
use Jfs\Uploader\Encoder\EBrgb5DByuboN;
use Jfs\Uploader\Encoder\G5nvOO03RJEUp;
use Jfs\Uploader\Service\G0pnBs62axPuz;
use Jfs\Uploader\Service\FileResolver\U09A05jCkt068;
use Jfs\Uploader\Service\FileResolver\N6FqmS3fDh00l;
use Jfs\Uploader\Service\FileResolver\UqlIZhcuBeEC0;
use Jfs\Uploader\Service\Jobs\DQKLeJ4Y5B2NF;
use Jfs\Uploader\Service\Jobs\ZmxW7HzDtFwSi;
use Jfs\Uploader\Service\Jobs\Rr7CM2m6RCEbq;
use Jfs\Uploader\Service\Jobs\Kwx1S7WayMfoX;
use Jfs\Uploader\Service\Jobs\Be8e3mTWukO3v;
use Jfs\Uploader\Service\Jobs\W1JnoTI1C0JPA;
use Jfs\Uploader\Service\Jobs\KR94cJ8zm1N5K;
use Jfs\Uploader\Service\Jobs\Ln0VkR1AnGGO4;
use Jfs\Uploader\Service\Jobs\BS48ZckuwR4zT;
use Jfs\Uploader\Service\Jobs\E0x8XzlcbxlFA;
use Jfs\Uploader\Service\RiRUUwVHtq3AY;
use Jfs\Uploader\Service\IeMg7A21r884m;
use Jfs\Uploader\Service\MO6fKUCLdtmOA;
use Jfs\Uploader\Service\YgVoFfrzQglik;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto fZYeH;
        KYucE:
        $this->app->tag([UqlIZhcuBeEC0::class, N6FqmS3fDh00l::class, U09A05jCkt068::class], 'file.location.resolvers');
        goto ArBpM;
        M6qDl:
        $this->app->bind(StoreToS3JobInterface::class, function ($A5dSD) {
            return new KR94cJ8zm1N5K(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto lGWia;
        XrSdn:
        $this->app->singleton(EBrgb5DByuboN::class, function ($A5dSD) {
            return new EBrgb5DByuboN($A5dSD->make(RiRUUwVHtq3AY::class), Storage::disk('s3'));
        });
        goto HMHbk;
        h6yPP:
        $this->app->bind(WatermarkTextJobInterface::class, function ($A5dSD) {
            return new E0x8XzlcbxlFA(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto GuqxS;
        GuqxS:
        $this->app->bind(GalleryCloudInterface::class, function ($A5dSD) {
            return new Rcvt9IX4AhWY7();
        });
        goto TLOoV;
        ArBpM:
        $this->app->bind(BlurJobInterface::class, function ($A5dSD) {
            return new DQKLeJ4Y5B2NF(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto hHt_x;
        eJI4j:
        $this->app->singleton(VjEI9Nu3TyWfD::class, function () {
            return new IeMg7A21r884m(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto Lt5aR;
        xuKuY:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($A5dSD) {
            return new W1JnoTI1C0JPA();
        });
        goto M6qDl;
        s7BSG:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($A5dSD) {
            return new YgVoFfrzQglik($A5dSD->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto eJI4j;
        fZYeH:
        $this->app->bind(UploadServiceInterface::class, function ($A5dSD) {
            return new MO6fKUCLdtmOA($A5dSD->make(G0pnBs62axPuz::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto s7BSG;
        lGWia:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($A5dSD) {
            return new Ln0VkR1AnGGO4(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto h6yPP;
        HMHbk:
        $this->app->bind(G5nvOO03RJEUp::class, function ($A5dSD) {
            return new G5nvOO03RJEUp(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto KYucE;
        Lt5aR:
        $this->app->singleton(G0pnBs62axPuz::class, function ($A5dSD) {
            return new G0pnBs62axPuz($A5dSD->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto FgdFu;
        fh5os:
        $this->app->bind(CompressJobInterface::class, function ($A5dSD) {
            return new Rr7CM2m6RCEbq(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Ninjc;
        PYzEz:
        $this->app->bind(MediaEncodeJobInterface::class, function ($A5dSD) {
            return new BS48ZckuwR4zT(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto xuKuY;
        JK3X6:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($A5dSD) {
            return new Be8e3mTWukO3v(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto PYzEz;
        hHt_x:
        $this->app->bind(BlurVideoJobInterface::class, function ($A5dSD) {
            return new ZmxW7HzDtFwSi(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto fh5os;
        FgdFu:
        $this->app->singleton(RiRUUwVHtq3AY::class, function ($A5dSD) {
            return new RiRUUwVHtq3AY(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto XrSdn;
        Ninjc:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($A5dSD) {
            return new Kwx1S7WayMfoX(Storage::disk('s3'), Storage::disk('public'));
        });
        goto JK3X6;
        TLOoV:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
