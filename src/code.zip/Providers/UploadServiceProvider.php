<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\HUoKoAXzk5zWW;
use Jfs\Uploader\Contracts\Hj0NrxjG6qaVy;
use Jfs\Uploader\Encoder\OGmQ0hQJzIYby;
use Jfs\Uploader\Encoder\UKW6hIg5vZR7f;
use Jfs\Uploader\Service\B0zx05APUr70A;
use Jfs\Uploader\Service\FileResolver\GgrUiI8Z61dee;
use Jfs\Uploader\Service\FileResolver\LBp85HMARWSt0;
use Jfs\Uploader\Service\FileResolver\RFia4haQxwea6;
use Jfs\Uploader\Service\Jobs\VEIFq51ZxgHD5;
use Jfs\Uploader\Service\Jobs\MLiyILBJDI0eb;
use Jfs\Uploader\Service\Jobs\Xa9V0Eiuy8RPN;
use Jfs\Uploader\Service\Jobs\GwwZZO6Kg4YnP;
use Jfs\Uploader\Service\Jobs\Tql71Fg24MO85;
use Jfs\Uploader\Service\Jobs\KFoR9vPrqGQ44;
use Jfs\Uploader\Service\Jobs\MARg2GurDnSiZ;
use Jfs\Uploader\Service\Jobs\GBvckri6SF7xg;
use Jfs\Uploader\Service\Jobs\EDvFQ2Y6VjbT0;
use Jfs\Uploader\Service\Jobs\A1Bq1DhATt4LG;
use Jfs\Uploader\Service\PP4BnfgX7sVAN;
use Jfs\Uploader\Service\RkcpO1qn0gOFt;
use Jfs\Uploader\Service\YvDQEVPX0iULp;
use Jfs\Uploader\Service\Ukb0hQ0zAujsG;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto TLdAk;
        G_Sno:
        $this->app->singleton(Hj0NrxjG6qaVy::class, function () {
            return new RkcpO1qn0gOFt(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto mY8XR;
        nHoeK:
        $this->app->bind(MediaEncodeJobInterface::class, function ($t_1W4) {
            return new EDvFQ2Y6VjbT0(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto vcaPY;
        A4gsj:
        $this->app->singleton(OGmQ0hQJzIYby::class, function ($t_1W4) {
            return new OGmQ0hQJzIYby($t_1W4->make(PP4BnfgX7sVAN::class), Storage::disk('s3'));
        });
        goto h8AoT;
        Xkl81:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($t_1W4) {
            return new Tql71Fg24MO85(config('upload.maker'), Storage::disk('public'));
        });
        goto nHoeK;
        p10r0:
        $this->app->singleton(PP4BnfgX7sVAN::class, function ($t_1W4) {
            return new PP4BnfgX7sVAN(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto A4gsj;
        wYWsk:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($t_1W4) {
            return new Ukb0hQ0zAujsG($t_1W4->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto G_Sno;
        OSgTG:
        $this->app->bind(GalleryCloudInterface::class, function ($t_1W4) {
            return new HUoKoAXzk5zWW();
        });
        goto gVIkU;
        wQcXX:
        $this->app->bind(BlurVideoJobInterface::class, function ($t_1W4) {
            return new MLiyILBJDI0eb(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto DV263;
        h8AoT:
        $this->app->bind(UKW6hIg5vZR7f::class, function ($t_1W4) {
            return new UKW6hIg5vZR7f(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto E0fmP;
        olsdq:
        $this->app->bind(WatermarkTextJobInterface::class, function ($t_1W4) {
            return new A1Bq1DhATt4LG(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto OSgTG;
        YNXsn:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($t_1W4) {
            return new GwwZZO6Kg4YnP(Storage::disk('s3'), Storage::disk('public'));
        });
        goto Xkl81;
        mY8XR:
        $this->app->singleton(B0zx05APUr70A::class, function ($t_1W4) {
            return new B0zx05APUr70A($t_1W4->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto p10r0;
        vcaPY:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($t_1W4) {
            return new KFoR9vPrqGQ44();
        });
        goto cGGx5;
        DV263:
        $this->app->bind(CompressJobInterface::class, function ($t_1W4) {
            return new Xa9V0Eiuy8RPN(config('upload.maker'), Storage::disk('public'));
        });
        goto YNXsn;
        E0fmP:
        $this->app->tag([RFia4haQxwea6::class, LBp85HMARWSt0::class, GgrUiI8Z61dee::class], 'file.location.resolvers');
        goto d9329;
        cGGx5:
        $this->app->bind(StoreToS3JobInterface::class, function ($t_1W4) {
            return new MARg2GurDnSiZ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto YbTvI;
        YbTvI:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($t_1W4) {
            return new GBvckri6SF7xg(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto olsdq;
        d9329:
        $this->app->bind(BlurJobInterface::class, function ($t_1W4) {
            return new VEIFq51ZxgHD5(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto wQcXX;
        TLdAk:
        $this->app->bind(UploadServiceInterface::class, function ($t_1W4) {
            return new YvDQEVPX0iULp($t_1W4->make(B0zx05APUr70A::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto wYWsk;
        gVIkU:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
