<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\I7SvOr1BMBC5q;
use Jfs\Uploader\Contracts\GN9q1LiHnFGKa;
use Jfs\Uploader\Encoder\K98g74EXAn8Vy;
use Jfs\Uploader\Encoder\PtMcpMno1bPjl;
use Jfs\Uploader\Service\DpvqXIwAB5UAa;
use Jfs\Uploader\Service\FileResolver\EkEWqweUhBR8J;
use Jfs\Uploader\Service\FileResolver\AsY0mOh7z4UAW;
use Jfs\Uploader\Service\FileResolver\OpfEO5ACerkH7;
use Jfs\Uploader\Service\Jobs\BbAVYDnLpXzsj;
use Jfs\Uploader\Service\Jobs\XWquaRGGlU6YR;
use Jfs\Uploader\Service\Jobs\Z5igIonVEjAo9;
use Jfs\Uploader\Service\Jobs\TmcLneEW8cD7E;
use Jfs\Uploader\Service\Jobs\O05MgM29rHKIh;
use Jfs\Uploader\Service\Jobs\EE4XdZJqt4x0N;
use Jfs\Uploader\Service\Jobs\Rr8Esp3bF4WdL;
use Jfs\Uploader\Service\Jobs\WYCbnMCElVDi3;
use Jfs\Uploader\Service\Jobs\QsJ3RwfJ2VxHB;
use Jfs\Uploader\Service\Jobs\CXK2bDGLYItsc;
use Jfs\Uploader\Service\A7wFfsLiK9DEe;
use Jfs\Uploader\Service\P4kAqVwxHUI1r;
use Jfs\Uploader\Service\Rc7HXyVNsfevS;
use Jfs\Uploader\Service\I4UUCjrnJJLmk;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto r8OVM;
        rmK8E:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($UalhJ) {
            return new I4UUCjrnJJLmk($UalhJ->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto NHNPu;
        MSz2o:
        $this->app->singleton(DpvqXIwAB5UAa::class, function ($UalhJ) {
            return new DpvqXIwAB5UAa($UalhJ->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto mHSUr;
        tvYYS:
        $this->app->bind(BlurVideoJobInterface::class, function ($UalhJ) {
            return new XWquaRGGlU6YR(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto om6K0;
        vr2gC:
        $this->app->bind(StoreToS3JobInterface::class, function ($UalhJ) {
            return new Rr8Esp3bF4WdL(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto RNT61;
        NHNPu:
        $this->app->singleton(GN9q1LiHnFGKa::class, function () {
            return new P4kAqVwxHUI1r(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto MSz2o;
        tyNvb:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($UalhJ) {
            return new TmcLneEW8cD7E(Storage::disk('s3'), Storage::disk('public'));
        });
        goto MnwwJ;
        IzyYJ:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($UalhJ) {
            return new EE4XdZJqt4x0N();
        });
        goto vr2gC;
        Aiq8c:
        $this->app->bind(WatermarkTextJobInterface::class, function ($UalhJ) {
            return new CXK2bDGLYItsc(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto YlEV5;
        r8OVM:
        $this->app->bind(UploadServiceInterface::class, function ($UalhJ) {
            return new Rc7HXyVNsfevS($UalhJ->make(DpvqXIwAB5UAa::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto rmK8E;
        BBhkL:
        $this->app->bind(MediaEncodeJobInterface::class, function ($UalhJ) {
            return new QsJ3RwfJ2VxHB(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto IzyYJ;
        om6K0:
        $this->app->bind(CompressJobInterface::class, function ($UalhJ) {
            return new Z5igIonVEjAo9(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto tyNvb;
        Vd1xY:
        $this->app->bind(BlurJobInterface::class, function ($UalhJ) {
            return new BbAVYDnLpXzsj(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto tvYYS;
        AXLXs:
        $this->app->tag([OpfEO5ACerkH7::class, AsY0mOh7z4UAW::class, EkEWqweUhBR8J::class], 'file.location.resolvers');
        goto Vd1xY;
        RNT61:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($UalhJ) {
            return new WYCbnMCElVDi3(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Aiq8c;
        YlEV5:
        $this->app->bind(GalleryCloudInterface::class, function ($UalhJ) {
            return new I7SvOr1BMBC5q();
        });
        goto DoN8u;
        rU7i4:
        $this->app->bind(PtMcpMno1bPjl::class, function ($UalhJ) {
            return new PtMcpMno1bPjl(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto AXLXs;
        mHSUr:
        $this->app->singleton(A7wFfsLiK9DEe::class, function ($UalhJ) {
            return new A7wFfsLiK9DEe(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto vURKD;
        MnwwJ:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($UalhJ) {
            return new O05MgM29rHKIh(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto BBhkL;
        vURKD:
        $this->app->singleton(K98g74EXAn8Vy::class, function ($UalhJ) {
            return new K98g74EXAn8Vy($UalhJ->make(A7wFfsLiK9DEe::class), Storage::disk('s3'));
        });
        goto rU7i4;
        DoN8u:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
