<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\RCbUw2E5dV2hI;
use Jfs\Uploader\Contracts\Ijay4AiPvrqAE;
use Jfs\Uploader\Encoder\ASuKOsLEZrEeb;
use Jfs\Uploader\Encoder\HYHb7A2L6Ex2n;
use Jfs\Uploader\Service\S0Eg4TIBvz6Wk;
use Jfs\Uploader\Service\FileResolver\K5BCpRZRa8Eqv;
use Jfs\Uploader\Service\FileResolver\EPrCrT2rjwc2o;
use Jfs\Uploader\Service\FileResolver\O0cElSfxCT4LE;
use Jfs\Uploader\Service\Jobs\NB07P3JPQATso;
use Jfs\Uploader\Service\Jobs\Nfs3vWFk494Bs;
use Jfs\Uploader\Service\Jobs\BNaRktuoPbaqD;
use Jfs\Uploader\Service\Jobs\LY0JZ7eyOgkDa;
use Jfs\Uploader\Service\Jobs\XQV78gU2vgTCr;
use Jfs\Uploader\Service\Jobs\BwDpSh7WN1CrI;
use Jfs\Uploader\Service\Jobs\CGYQ7lCcqAtRC;
use Jfs\Uploader\Service\Jobs\VpU71S2wn5iXi;
use Jfs\Uploader\Service\Jobs\TCGbWudEvpDHl;
use Jfs\Uploader\Service\Jobs\N8Q607cilJDkf;
use Jfs\Uploader\Service\XmR9LXciUFjyf;
use Jfs\Uploader\Service\ElRFl5IfrCbnq;
use Jfs\Uploader\Service\M8INeNxfrlRrB;
use Jfs\Uploader\Service\RJTPiKnpoHlD0;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto IRUZQ;
        ni2TB:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($YI449) {
            return new VpU71S2wn5iXi(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto iTTPr;
        k70m0:
        $this->app->bind(BlurVideoJobInterface::class, function ($YI449) {
            return new Nfs3vWFk494Bs(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto mTRKR;
        oyVF6:
        $this->app->bind(BlurJobInterface::class, function ($YI449) {
            return new NB07P3JPQATso(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto k70m0;
        GfB7f:
        $this->app->bind(HYHb7A2L6Ex2n::class, function ($YI449) {
            return new HYHb7A2L6Ex2n(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto ryd03;
        iTTPr:
        $this->app->bind(WatermarkTextJobInterface::class, function ($YI449) {
            return new N8Q607cilJDkf(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto J7KR9;
        bYnqs:
        $this->app->bind(StoreToS3JobInterface::class, function ($YI449) {
            return new CGYQ7lCcqAtRC(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ni2TB;
        LHzj3:
        $this->app->singleton(S0Eg4TIBvz6Wk::class, function ($YI449) {
            return new S0Eg4TIBvz6Wk($YI449->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto XSQvH;
        bpM9b:
        $this->app->bind(MediaEncodeJobInterface::class, function ($YI449) {
            return new TCGbWudEvpDHl(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto De7KW;
        M6fAa:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($YI449) {
            return new LY0JZ7eyOgkDa(Storage::disk('s3'), Storage::disk('public'));
        });
        goto znzEm;
        De7KW:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($YI449) {
            return new BwDpSh7WN1CrI();
        });
        goto bYnqs;
        mTRKR:
        $this->app->bind(CompressJobInterface::class, function ($YI449) {
            return new BNaRktuoPbaqD(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto M6fAa;
        IRUZQ:
        $this->app->bind(UploadServiceInterface::class, function ($YI449) {
            return new M8INeNxfrlRrB($YI449->make(S0Eg4TIBvz6Wk::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto O1its;
        O1its:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($YI449) {
            return new RJTPiKnpoHlD0($YI449->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Buonx;
        ryd03:
        $this->app->tag([O0cElSfxCT4LE::class, EPrCrT2rjwc2o::class, K5BCpRZRa8Eqv::class], 'file.location.resolvers');
        goto oyVF6;
        znzEm:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($YI449) {
            return new XQV78gU2vgTCr(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto bpM9b;
        XSQvH:
        $this->app->singleton(XmR9LXciUFjyf::class, function ($YI449) {
            return new XmR9LXciUFjyf(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto Fy4ak;
        J7KR9:
        $this->app->bind(GalleryCloudInterface::class, function ($YI449) {
            return new RCbUw2E5dV2hI();
        });
        goto MLaCD;
        Fy4ak:
        $this->app->singleton(ASuKOsLEZrEeb::class, function ($YI449) {
            return new ASuKOsLEZrEeb($YI449->make(XmR9LXciUFjyf::class), Storage::disk('s3'));
        });
        goto GfB7f;
        Buonx:
        $this->app->singleton(Ijay4AiPvrqAE::class, function () {
            return new ElRFl5IfrCbnq(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto LHzj3;
        MLaCD:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
