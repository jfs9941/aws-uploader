<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\QFJqnQcj9Tdhh;
use Jfs\Uploader\Contracts\IqdLBxImTkuBV;
use Jfs\Uploader\Encoder\LoHH67lOeFp9J;
use Jfs\Uploader\Encoder\SUstEnfinI8Ng;
use Jfs\Uploader\Service\K3koL2kq4QSAu;
use Jfs\Uploader\Service\FileResolver\CAJ8pG33gWW19;
use Jfs\Uploader\Service\FileResolver\BXIcNJtxeyufn;
use Jfs\Uploader\Service\FileResolver\NrbpUJMoTjKfm;
use Jfs\Uploader\Service\Jobs\HZ50rNt16DcjX;
use Jfs\Uploader\Service\Jobs\Luj4pc9eWw374;
use Jfs\Uploader\Service\Jobs\UnyOeiIsEFHca;
use Jfs\Uploader\Service\Jobs\U8keiRd0JeOLQ;
use Jfs\Uploader\Service\Jobs\ByT9ChyiVIKXx;
use Jfs\Uploader\Service\Jobs\GcccsKR0ryVod;
use Jfs\Uploader\Service\Jobs\CR2ATNJKiDMBa;
use Jfs\Uploader\Service\Jobs\XejrOm9TfwJqP;
use Jfs\Uploader\Service\Jobs\TYAbFDM3etfit;
use Jfs\Uploader\Service\Jobs\SS23EYVZKZQSf;
use Jfs\Uploader\Service\KtvKQ6SgzhDbU;
use Jfs\Uploader\Service\KS7YippgDSDNy;
use Jfs\Uploader\Service\PPI0EdnxstwVb;
use Jfs\Uploader\Service\Jxpj4nIIfk65F;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto DWGvq;
        O67y4:
        $this->app->bind(BlurVideoJobInterface::class, function ($Y1GjH) {
            return new Luj4pc9eWw374(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto SQd6Z;
        fJYgJ:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Y1GjH) {
            return new TYAbFDM3etfit(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto bXisJ;
        L_p1V:
        $this->app->bind(BlurJobInterface::class, function ($Y1GjH) {
            return new HZ50rNt16DcjX(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto O67y4;
        XmzmI:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Y1GjH) {
            return new SS23EYVZKZQSf(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto mpmVA;
        SQd6Z:
        $this->app->bind(CompressJobInterface::class, function ($Y1GjH) {
            return new UnyOeiIsEFHca(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto Sg1X_;
        Sg1X_:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Y1GjH) {
            return new U8keiRd0JeOLQ(Storage::disk('s3'), Storage::disk('public'));
        });
        goto yUs3l;
        O7_fB:
        $this->app->tag([NrbpUJMoTjKfm::class, BXIcNJtxeyufn::class, CAJ8pG33gWW19::class], 'file.location.resolvers');
        goto L_p1V;
        Cs8B3:
        $this->app->singleton(LoHH67lOeFp9J::class, function ($Y1GjH) {
            return new LoHH67lOeFp9J($Y1GjH->make(KtvKQ6SgzhDbU::class), Storage::disk('s3'));
        });
        goto PfSZk;
        PfSZk:
        $this->app->bind(SUstEnfinI8Ng::class, function ($Y1GjH) {
            return new SUstEnfinI8Ng(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto O7_fB;
        bXisJ:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Y1GjH) {
            return new GcccsKR0ryVod();
        });
        goto MAsLL;
        MAsLL:
        $this->app->bind(StoreToS3JobInterface::class, function ($Y1GjH) {
            return new CR2ATNJKiDMBa(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto yxQBa;
        yxQBa:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Y1GjH) {
            return new XejrOm9TfwJqP(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto XmzmI;
        CBihi:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Y1GjH) {
            return new Jxpj4nIIfk65F($Y1GjH->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto Sy0t5;
        mpmVA:
        $this->app->bind(GalleryCloudInterface::class, function ($Y1GjH) {
            return new QFJqnQcj9Tdhh();
        });
        goto AiOT8;
        yUs3l:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Y1GjH) {
            return new ByT9ChyiVIKXx(config('upload.maker'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto fJYgJ;
        UVuWR:
        $this->app->singleton(K3koL2kq4QSAu::class, function ($Y1GjH) {
            return new K3koL2kq4QSAu($Y1GjH->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto QCOD8;
        DWGvq:
        $this->app->bind(UploadServiceInterface::class, function ($Y1GjH) {
            return new PPI0EdnxstwVb($Y1GjH->make(K3koL2kq4QSAu::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto CBihi;
        QCOD8:
        $this->app->singleton(KtvKQ6SgzhDbU::class, function ($Y1GjH) {
            return new KtvKQ6SgzhDbU(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto Cs8B3;
        Sy0t5:
        $this->app->singleton(IqdLBxImTkuBV::class, function () {
            return new KS7YippgDSDNy(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto UVuWR;
        AiOT8:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
