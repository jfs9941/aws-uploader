<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\PBI0DsEzGhtPt;
use Jfs\Uploader\Contracts\YcQilzjlu6PxW;
use Jfs\Uploader\Encoder\DFtX4SxXxkHYz;
use Jfs\Uploader\Encoder\GPKFcaJNi5OaU;
use Jfs\Uploader\Service\Havd45fq438gW;
use Jfs\Uploader\Service\FileResolver\YzSL5PlhjdUkL;
use Jfs\Uploader\Service\FileResolver\RBr7B5GULK2N5;
use Jfs\Uploader\Service\FileResolver\TOAxIaYJeahur;
use Jfs\Uploader\Service\Jobs\I7NqCOjLzV1dW;
use Jfs\Uploader\Service\Jobs\PPXu7C75N1oew;
use Jfs\Uploader\Service\Jobs\A8MJyh2EcrUyN;
use Jfs\Uploader\Service\Jobs\DgPPEY5OIdo94;
use Jfs\Uploader\Service\Jobs\FtRnVnAGeNITw;
use Jfs\Uploader\Service\Jobs\HTLe1IA3Xgret;
use Jfs\Uploader\Service\Jobs\AzBQAvWLQPhGb;
use Jfs\Uploader\Service\Jobs\CXtUsGmTZ8ucb;
use Jfs\Uploader\Service\Jobs\XP8OPFpw4ZXBL;
use Jfs\Uploader\Service\Jobs\BDwb7oae8KSkV;
use Jfs\Uploader\Service\I2LnR7hUOOfvy;
use Jfs\Uploader\Service\JHcQzV9ciJhlf;
use Jfs\Uploader\Service\IsiO3rjepI18R;
use Jfs\Uploader\Service\TKmDKwTh7ykw1;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto LABpM;
        hsLka:
        $this->app->bind(WatermarkTextJobInterface::class, function ($Fpn5o) {
            return new BDwb7oae8KSkV(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto K2ELr;
        XW4Qb:
        $this->app->singleton(DFtX4SxXxkHYz::class, function ($Fpn5o) {
            return new DFtX4SxXxkHYz($Fpn5o->make(I2LnR7hUOOfvy::class), Storage::disk('s3'));
        });
        goto Izuuk;
        Krzy4:
        $this->app->bind(StoreToS3JobInterface::class, function ($Fpn5o) {
            return new AzBQAvWLQPhGb(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto rJ35Q;
        k_cat:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($Fpn5o) {
            return new HTLe1IA3Xgret();
        });
        goto Krzy4;
        K2ELr:
        $this->app->bind(GalleryCloudInterface::class, function ($Fpn5o) {
            return new PBI0DsEzGhtPt();
        });
        goto iU3S0;
        RM4uB:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($Fpn5o) {
            return new FtRnVnAGeNITw(config('upload.maker'), Storage::disk('public'));
        });
        goto QWRxb;
        Izuuk:
        $this->app->bind(GPKFcaJNi5OaU::class, function ($Fpn5o) {
            return new GPKFcaJNi5OaU(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto UlHt9;
        rJ35Q:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($Fpn5o) {
            return new CXtUsGmTZ8ucb(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto hsLka;
        ikynN:
        $this->app->bind(CompressJobInterface::class, function ($Fpn5o) {
            return new A8MJyh2EcrUyN(config('upload.maker'), Storage::disk('public'));
        });
        goto cdIOK;
        LABpM:
        $this->app->bind(UploadServiceInterface::class, function ($Fpn5o) {
            return new IsiO3rjepI18R($Fpn5o->make(Havd45fq438gW::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto iKP8j;
        a1mb4:
        $this->app->singleton(I2LnR7hUOOfvy::class, function ($Fpn5o) {
            return new I2LnR7hUOOfvy(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto XW4Qb;
        QWRxb:
        $this->app->bind(MediaEncodeJobInterface::class, function ($Fpn5o) {
            return new XP8OPFpw4ZXBL(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto k_cat;
        kWYxQ:
        $this->app->singleton(Havd45fq438gW::class, function ($Fpn5o) {
            return new Havd45fq438gW($Fpn5o->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto a1mb4;
        RbWGa:
        $this->app->bind(BlurJobInterface::class, function ($Fpn5o) {
            return new I7NqCOjLzV1dW(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto t3VAB;
        t3VAB:
        $this->app->bind(BlurVideoJobInterface::class, function ($Fpn5o) {
            return new PPXu7C75N1oew(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto ikynN;
        iKP8j:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($Fpn5o) {
            return new TKmDKwTh7ykw1($Fpn5o->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto iWE64;
        cdIOK:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($Fpn5o) {
            return new DgPPEY5OIdo94(Storage::disk('s3'), Storage::disk('public'));
        });
        goto RM4uB;
        UlHt9:
        $this->app->tag([TOAxIaYJeahur::class, RBr7B5GULK2N5::class, YzSL5PlhjdUkL::class], 'file.location.resolvers');
        goto RbWGa;
        iWE64:
        $this->app->singleton(YcQilzjlu6PxW::class, function () {
            return new JHcQzV9ciJhlf(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto kWYxQ;
        iU3S0:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
