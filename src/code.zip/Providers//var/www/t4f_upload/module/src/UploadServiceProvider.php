<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\SiTQEeGHxDSOj;
use Jfs\Uploader\Contracts\CKc1zCD1DcxJi;
use Jfs\Uploader\Encoder\V70xMRa3qU4j9;
use Jfs\Uploader\Encoder\FfVwOVCuREbLJ;
use Jfs\Uploader\Service\VMvs2C8EqNiOW;
use Jfs\Uploader\Service\FileResolver\LoUDOzmU7C7BG;
use Jfs\Uploader\Service\FileResolver\AdSBYUOvhOwhg;
use Jfs\Uploader\Service\FileResolver\X4tX2r3AIpDJG;
use Jfs\Uploader\Service\Jobs\SuMiYCAXAyp1p;
use Jfs\Uploader\Service\Jobs\PTiXMByDhWRwq;
use Jfs\Uploader\Service\Jobs\H4VzwkR0z7v7X;
use Jfs\Uploader\Service\Jobs\VObh2uu8epbYJ;
use Jfs\Uploader\Service\Jobs\KwfSnyH0swhn3;
use Jfs\Uploader\Service\Jobs\MXAAkHSLJHdNi;
use Jfs\Uploader\Service\Jobs\IkyXbdemqQ1go;
use Jfs\Uploader\Service\Jobs\OR1S3YAm3o8ZT;
use Jfs\Uploader\Service\Jobs\SKh6gQvJXYdn0;
use Jfs\Uploader\Service\Jobs\LsED92jvmYpAm;
use Jfs\Uploader\Service\WhtZzd9QpH304;
use Jfs\Uploader\Service\DcscDC5e2bOa2;
use Jfs\Uploader\Service\KdztHKvtptQgN;
use Jfs\Uploader\Service\Kp1RFj3FeG2hA;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto cRNMI;
        crWJ5:
        $this->app->singleton(V70xMRa3qU4j9::class, function ($OfF9S) {
            return new V70xMRa3qU4j9($OfF9S->make(WhtZzd9QpH304::class), Storage::disk('s3'));
        });
        goto z9LvB;
        PVVMe:
        $this->app->bind(GalleryCloudInterface::class, function ($OfF9S) {
            return new SiTQEeGHxDSOj();
        });
        goto tvD8M;
        NDJPr:
        $this->app->bind(BlurVideoJobInterface::class, function ($OfF9S) {
            return new PTiXMByDhWRwq(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto Yr7vV;
        HwRCy:
        $this->app->singleton(CKc1zCD1DcxJi::class, function () {
            return new DcscDC5e2bOa2(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto O_pnW;
        Yr7vV:
        $this->app->bind(CompressJobInterface::class, function ($OfF9S) {
            return new H4VzwkR0z7v7X(config('upload.maker'), Storage::disk('public'));
        });
        goto ixuEH;
        O_pnW:
        $this->app->singleton(VMvs2C8EqNiOW::class, function ($OfF9S) {
            return new VMvs2C8EqNiOW($OfF9S->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto nE6lV;
        QRYQm:
        $this->app->tag([X4tX2r3AIpDJG::class, AdSBYUOvhOwhg::class, LoUDOzmU7C7BG::class], 'file.location.resolvers');
        goto mR1qs;
        nE6lV:
        $this->app->singleton(WhtZzd9QpH304::class, function ($OfF9S) {
            return new WhtZzd9QpH304(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto crWJ5;
        c1dBp:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($OfF9S) {
            return new MXAAkHSLJHdNi();
        });
        goto yOMxh;
        mR1qs:
        $this->app->bind(BlurJobInterface::class, function ($OfF9S) {
            return new SuMiYCAXAyp1p(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto NDJPr;
        a47jX:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($OfF9S) {
            return new OR1S3YAm3o8ZT(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto KIogq;
        PxtWo:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($OfF9S) {
            return new KwfSnyH0swhn3(config('upload.maker'), Storage::disk('public'));
        });
        goto oPYIu;
        z9LvB:
        $this->app->bind(FfVwOVCuREbLJ::class, function ($OfF9S) {
            return new FfVwOVCuREbLJ(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto QRYQm;
        oPYIu:
        $this->app->bind(MediaEncodeJobInterface::class, function ($OfF9S) {
            return new SKh6gQvJXYdn0(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto c1dBp;
        BTzc6:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($OfF9S) {
            return new Kp1RFj3FeG2hA($OfF9S->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto HwRCy;
        cRNMI:
        $this->app->bind(UploadServiceInterface::class, function ($OfF9S) {
            return new KdztHKvtptQgN($OfF9S->make(VMvs2C8EqNiOW::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto BTzc6;
        ixuEH:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($OfF9S) {
            return new VObh2uu8epbYJ(Storage::disk('s3'), Storage::disk('public'));
        });
        goto PxtWo;
        KIogq:
        $this->app->bind(WatermarkTextJobInterface::class, function ($OfF9S) {
            return new LsED92jvmYpAm(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto PVVMe;
        yOMxh:
        $this->app->bind(StoreToS3JobInterface::class, function ($OfF9S) {
            return new IkyXbdemqQ1go(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto a47jX;
        tvD8M:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
