<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

declare (strict_types=1);
namespace Jfs\Providers;

use Aws\MediaConvert\MediaConvertClient;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Exposed\Jobs\BlurJobInterface;
use Jfs\Exposed\Jobs\BlurVideoJobInterface;
use Jfs\Exposed\Jobs\CompressJobInterface;
use Jfs\Exposed\Jobs\DownloadToLocalJobInterface;
use Jfs\Exposed\Jobs\GenerateThumbnailJobInterface;
use Jfs\Exposed\Jobs\MediaEncodeJobInterface;
use Jfs\Exposed\Jobs\PrepareMetadataJobInterface;
use Jfs\Exposed\Jobs\StoreToS3JobInterface;
use Jfs\Exposed\Jobs\StoreVideoToS3JobInterface;
use Jfs\Exposed\Jobs\WatermarkTextJobInterface;
use Jfs\Exposed\UploadServiceInterface;
use Jfs\Exposed\VideoPostHandleServiceInterface;
use Jfs\Gallery\Service\GITMWtpihwT3w;
use Jfs\Uploader\Contracts\SZm1UTyVUjPKK;
use Jfs\Uploader\Encoder\NLnbq513ssJFf;
use Jfs\Uploader\Encoder\MVYTmXuZBStjV;
use Jfs\Uploader\Service\SIHyHN1Z6B4kZ;
use Jfs\Uploader\Service\FileResolver\BzePOpa41OmEp;
use Jfs\Uploader\Service\FileResolver\L6oy4PlHPAAvo;
use Jfs\Uploader\Service\FileResolver\EI5IEB78IIoX0;
use Jfs\Uploader\Service\Jobs\KBvlJjrPu3JyV;
use Jfs\Uploader\Service\Jobs\PwGAdjyFseBeZ;
use Jfs\Uploader\Service\Jobs\JsNljjEaXd4oi;
use Jfs\Uploader\Service\Jobs\MoIhgOdmNnptR;
use Jfs\Uploader\Service\Jobs\F9Mgq6XLh0wPy;
use Jfs\Uploader\Service\Jobs\VmktFTRePkYTG;
use Jfs\Uploader\Service\Jobs\RlasWb9LB7nXI;
use Jfs\Uploader\Service\Jobs\AN99zqQNCS4Av;
use Jfs\Uploader\Service\Jobs\Dq82E0jWABlYQ;
use Jfs\Uploader\Service\Jobs\GvRzttjEZkkTh;
use Jfs\Uploader\Service\IudiFfJzDfyEK;
use Jfs\Uploader\Service\TTmP5DEq3oRIl;
use Jfs\Uploader\Service\Fdp8E4bwutGXV;
use Jfs\Uploader\Service\JU805aPxc2xOj;
class UploadServiceProvider extends ServiceProvider
{
    public function register() : void
    {
        goto mfE2_;
        EzaxI:
        $this->app->bind(CompressJobInterface::class, function ($mWVER) {
            return new JsNljjEaXd4oi(config('upload.maker'), Storage::disk('public'));
        });
        goto OK2kx;
        q7pRT:
        $this->app->bind(WatermarkTextJobInterface::class, function ($mWVER) {
            return new GvRzttjEZkkTh(config('upload.maker'), config('upload.canvas'), Storage::disk('s3'), Storage::disk('public'), config('upload.watermark_font'));
        });
        goto Usgj_;
        y5ujA:
        $this->app->bind(StoreVideoToS3JobInterface::class, function ($mWVER) {
            return new AN99zqQNCS4Av(config('upload.s3_bucket'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto q7pRT;
        F7E5N:
        $this->app->bind(MediaEncodeJobInterface::class, function ($mWVER) {
            return new Dq82E0jWABlYQ(config('upload.s3_bucket'), Storage::disk('public'), Storage::disk('s3'), config('upload.canvas'), config('upload.watermark_font'));
        });
        goto uYu_6;
        ZfX5h:
        $this->app->bind(MVYTmXuZBStjV::class, function ($mWVER) {
            return new MVYTmXuZBStjV(new MediaConvertClient(['region' => config('upload.media_convert_region'), 'version' => 'latest', 'credentials' => ['key' => config('upload.media_convert_key'), 'secret' => config('upload.media_convert_secret')]]), config('upload.media_convert_role'), config('upload.media_convert_queue'));
        });
        goto fimGD;
        Usgj_:
        $this->app->bind(GalleryCloudInterface::class, function ($mWVER) {
            return new GITMWtpihwT3w();
        });
        goto VuhgR;
        OD5Gg:
        $this->app->bind(StoreToS3JobInterface::class, function ($mWVER) {
            return new RlasWb9LB7nXI(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto y5ujA;
        SDqoR:
        $this->app->singleton(IudiFfJzDfyEK::class, function ($mWVER) {
            return new IudiFfJzDfyEK(config('upload.s3_bucket'), config('upload.s3_base_url'), Storage::disk('public'));
        });
        goto iUpTQ;
        OK2kx:
        $this->app->bind(DownloadToLocalJobInterface::class, function ($mWVER) {
            return new MoIhgOdmNnptR(Storage::disk('s3'), Storage::disk('public'));
        });
        goto tWmTP;
        JPYAm:
        $this->app->bind(BlurJobInterface::class, function ($mWVER) {
            return new KBvlJjrPu3JyV(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto e_VRe;
        fimGD:
        $this->app->tag([EI5IEB78IIoX0::class, L6oy4PlHPAAvo::class, BzePOpa41OmEp::class], 'file.location.resolvers');
        goto JPYAm;
        uYu_6:
        $this->app->bind(PrepareMetadataJobInterface::class, function ($mWVER) {
            return new VmktFTRePkYTG();
        });
        goto OD5Gg;
        PWMuT:
        $this->app->singleton(SZm1UTyVUjPKK::class, function () {
            return new TTmP5DEq3oRIl(config('upload.cdn_enabled', false), config('upload.s3_base_url'), config('upload.cdn_base_url', 'https://cdn.example.com'), config('upload.cdn_key', ''), config('upload.cdn_path', ''), Storage::disk('public'));
        });
        goto hLzOf;
        e_VRe:
        $this->app->bind(BlurVideoJobInterface::class, function ($mWVER) {
            return new PwGAdjyFseBeZ(config('upload.maker'), Storage::disk('s3'), Storage::disk('public'));
        });
        goto EzaxI;
        mfE2_:
        $this->app->bind(UploadServiceInterface::class, function ($mWVER) {
            return new Fdp8E4bwutGXV($mWVER->make(SIHyHN1Z6B4kZ::class), Storage::disk('public'), Storage::disk('s3'), config('upload.s3_bucket'));
        });
        goto U8o0F;
        hLzOf:
        $this->app->singleton(SIHyHN1Z6B4kZ::class, function ($mWVER) {
            return new SIHyHN1Z6B4kZ($mWVER->tagged('file.location.resolvers'), Storage::disk('public'), Storage::disk('s3'));
        });
        goto SDqoR;
        tWmTP:
        $this->app->bind(GenerateThumbnailJobInterface::class, function ($mWVER) {
            return new F9Mgq6XLh0wPy(config('upload.maker'), Storage::disk('public'));
        });
        goto F7E5N;
        iUpTQ:
        $this->app->singleton(NLnbq513ssJFf::class, function ($mWVER) {
            return new NLnbq513ssJFf($mWVER->make(IudiFfJzDfyEK::class), Storage::disk('s3'));
        });
        goto ZfX5h;
        U8o0F:
        $this->app->bind(VideoPostHandleServiceInterface::class, function ($mWVER) {
            return new JU805aPxc2xOj($mWVER->make(UploadServiceInterface::class), Storage::disk('s3'));
        });
        goto PWMuT;
        VuhgR:
    }
    public function boot() : void
    {
        AwsS3V3Adapter::macro('getClient', function () {
            $this->client;
        });
    }
}
