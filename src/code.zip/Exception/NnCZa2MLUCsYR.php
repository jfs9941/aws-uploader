<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-04 10:53:40              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 declare (strict_types=1); namespace Jfs\Uploader\Exception; class NnCZa2MLUCsYR extends \Exception implements GNC5prO6q2h1q { public function __construct(string $qQp8B = '', int $wtj_G = 0, ?\Throwable $htqpq = null) { parent::__construct($qQp8B, $wtj_G, $htqpq); } }
