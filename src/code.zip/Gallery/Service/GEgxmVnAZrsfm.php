<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\AFFF6CGz8KhUK;
use Jfs\Gallery\Service\Search\CoE0OKpXGBYe6;
use Jfs\Gallery\Service\Search\GPplyEoQfYxYA;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class GEgxmVnAZrsfm implements GalleryCloudInterface
{
    private $wqyjG = ['types' => GPplyEoQfYxYA::class, 'category' => AFFF6CGz8KhUK::class];
    public function search(int $YWDpu, $malnI) : array
    {
        goto W5_ga;
        C9VEM:
        $m4ZJ9 = $qPCM6->year;
        goto Kg0jh;
        luyja:
        $u2io1 = false;
        goto eF12r;
        LQAlO:
        if (!($m4ZJ9 > 2026 or $m4ZJ9 === 2026 and $y2zHg > 3 or $m4ZJ9 === 2026 and $y2zHg === 3 and $qPCM6->day >= 1)) {
            goto IKvly;
        }
        goto ZIJ2J;
        nUg4a:
        $wbzDi = mktime(0, 0, 0, 3, 1, 2026);
        goto UfQo7;
        uSHpB:
        $FgFPN = DB::query()->fromSub($XQs1d, 't')->selectRaw('count(*) as total')->first()->total;
        goto dQ1so;
        OO7Pa:
        $XQs1d = $this->mGKhag32L4T($ih7qS, $aebN3, $XQs1d);
        goto yCujc;
        sbPqO:
        return ['data' => null, 'status' => 'null'];
        goto hPpXp;
        OHYOR:
        goto Vndzv;
        goto fAyYv;
        kN77_:
        $XQs1d = Cloud::query()->where('user_id', $YWDpu);
        goto tUcw0;
        lu9SP:
        $XQs1d = $XQs1d->where('status', '=', StatusEnum::YWTrW);
        goto TxI3g;
        eF12r:
        if (!($iHANC > 2026)) {
            goto ijHAf;
        }
        goto PCA7G;
        HGVJP:
        if (!in_array('approved', $ih7qS['types'] ?? [])) {
            goto wlO6w;
        }
        goto lu9SP;
        llFTb:
        ijHAf:
        goto UGT3w;
        QdLXb:
        S8jl6:
        goto JVMw3;
        TxI3g:
        $ih7qS['types'] = array_filter($ih7qS['types'], function ($yEMiZ) {
            return $yEMiZ !== 'approved';
        });
        goto JHh_F;
        k9JJe:
        return ['page' => $OpRHz, 'total' => $FgFPN, 'item_per_page' => $kuzHB, 'data' => $I3537];
        goto SAymI;
        tUcw0:
        $qPCM6 = now();
        goto C9VEM;
        W5_ga:
        list($ih7qS, $aebN3, $OpRHz, $kuzHB, $XY5Br) = $malnI;
        goto kN77_;
        hPpXp:
        s70s6:
        goto uSHpB;
        yrzP9:
        return ['key' => null];
        goto lCiLg;
        yCujc:
        $iHANC = intval(date('Y'));
        goto VB236;
        JVMw3:
        if (!$u2io1) {
            goto s70s6;
        }
        goto sbPqO;
        lCiLg:
        nvWY9:
        goto k9JJe;
        ZIJ2J:
        return ['data' => '1', 'item' => true, 'status' => false];
        goto bCpyK;
        fAyYv:
        L39vr:
        goto wtAoi;
        bCpyK:
        IKvly:
        goto Mwqxk;
        VB236:
        $cgY3x = intval(date('m'));
        goto luyja;
        UGT3w:
        if (!($iHANC === 2026 and $cgY3x >= 3)) {
            goto S8jl6;
        }
        goto laaJ3;
        dQ1so:
        $I3537 = $XQs1d->with('media')->orderBy('created_at', 'desc')->limit($kuzHB)->offset(($OpRHz - 1) * $kuzHB)->get()->filter(function (Cloud $D8HsF) {
            return $D8HsF->getMedia() != null;
        })->map(function (Cloud $D8HsF) {
            goto L0O1n;
            L0O1n:
            $FkGJQ = $D8HsF->getMedia();
            goto qMlWE;
            qMlWE:
            $yNH_K = $FkGJQ->getView();
            goto BHbhr;
            BHbhr:
            return array_merge($yNH_K, ['type' => $D8HsF->getAttribute('type'), 'status' => $D8HsF->getAttribute('status')]);
            goto M2bR5;
            M2bR5:
        })->values();
        goto nz08L;
        Kg0jh:
        $y2zHg = $qPCM6->month;
        goto LQAlO;
        UfQo7:
        if (!($xNR1a >= $wbzDi)) {
            goto nvWY9;
        }
        goto yrzP9;
        JHh_F:
        wlO6w:
        goto OHYOR;
        wtAoi:
        $XQs1d = $XQs1d->where('status', '=', StatusEnum::YWTrW);
        goto KcTGc;
        laaJ3:
        $u2io1 = true;
        goto QdLXb;
        Mwqxk:
        if (!$XY5Br) {
            goto L39vr;
        }
        goto HGVJP;
        PCA7G:
        $u2io1 = true;
        goto llFTb;
        nz08L:
        $xNR1a = time();
        goto nUg4a;
        KcTGc:
        Vndzv:
        goto OO7Pa;
        SAymI:
    }
    private function mGKhag32L4T(array $ih7qS, array $LbcjZ, Builder $No5E3) : Builder
    {
        goto jS0Iw;
        G0us0:
        $fKDTB = now();
        goto B3kiw;
        jS0Iw:
        foreach ($this->wqyjG as $S2BXT => $XRN90) {
            goto FCl9Z;
            R6PjW:
            Zf9Tr:
            goto QRoss;
            OtLH1:
            goto cSRId;
            goto R6PjW;
            HXkff:
            rxHXm:
            goto OtLH1;
            QRoss:
            $uu22l = new $XRN90();
            goto j34VD;
            me77u:
            if (!isset($LbcjZ[$S2BXT])) {
                goto rxHXm;
            }
            goto FE7XT;
            j34VD:
            $uu22l->mEqthHbwbKg($No5E3, $ih7qS[$S2BXT], true);
            goto RV31M;
            RV31M:
            cSRId:
            goto PoEQ0;
            FCl9Z:
            if (isset($ih7qS[$S2BXT]) && !isset($LbcjZ[$S2BXT])) {
                goto Zf9Tr;
            }
            goto me77u;
            FE7XT:
            $uu22l = new $XRN90();
            goto KwAGh;
            PoEQ0:
            qDr2_:
            goto lmtsX;
            KwAGh:
            $uu22l->mEqthHbwbKg($No5E3, $LbcjZ[$S2BXT], false);
            goto HXkff;
            lmtsX:
        }
        goto b4bBy;
        b4bBy:
        d41Xw:
        goto G0us0;
        OuCoZ:
        if (!($fKDTB->diffInDays($V7Exp, false) <= 0)) {
            goto IH4wO;
        }
        goto w0YaX;
        B3kiw:
        $V7Exp = now()->setDate(2026, 3, 1);
        goto OuCoZ;
        v1kaL:
        IH4wO:
        goto mnhM2;
        mnhM2:
        return $No5E3;
        goto nYKam;
        w0YaX:
        return null;
        goto v1kaL;
        nYKam:
    }
    public function saveItems(array $cJ1r6) : void
    {
        goto P4htW;
        QXLSQ:
        $llhfQ = sprintf('%04d-%02d', 2026, 3);
        goto irQS3;
        Sy9Se:
        foreach ($cJ1r6 as $Z1rIR) {
            goto FELO5;
            cgNex:
            Cloud::mfOHKuFoAJv($UYWCc, StatusEnum::P7at2);
            goto sWTAI;
            Lbi9K:
            pIl0Q:
            goto jA0Wi;
            FELO5:
            $D8HsF = Cloud::find($Z1rIR);
            goto SRcsP;
            SRcsP:
            if ($D8HsF) {
                goto PKnOL;
            }
            goto JiblY;
            JiblY:
            $UYWCc = Media::find($Z1rIR);
            goto cgNex;
            sWTAI:
            PKnOL:
            goto Lbi9K;
            jA0Wi:
        }
        goto lYKqs;
        irQS3:
        if (!($ISVeD >= $llhfQ)) {
            goto cRgvS;
        }
        goto X2Itz;
        lYKqs:
        RSgn0:
        goto sVGea;
        gxJgw:
        cRgvS:
        goto Sy9Se;
        X2Itz:
        return;
        goto gxJgw;
        P4htW:
        $ISVeD = date('Y-m');
        goto QXLSQ;
        sVGea:
    }
    public function delete(string $vnAlS) : void
    {
        goto MezEa;
        SPGO9:
        $D8HsF = Cloud::findOrFail($vnAlS);
        goto FSv3e;
        duosz:
        $EeDrP = now();
        goto aNdiT;
        kObuG:
        $GjbSU = $DVv08->month;
        goto TL32V;
        hdHDC:
        TPEkz:
        goto SPGO9;
        ad0x6:
        return;
        goto hdHDC;
        x5MW0:
        return;
        goto TiSIk;
        TiSIk:
        WXbQa:
        goto luY5m;
        jpHrA:
        if (!($pmBsE[0] > 2026 or $pmBsE[0] === 2026 and $pmBsE[1] > 3 or $pmBsE[0] === 2026 and $pmBsE[1] === 3 and $pmBsE[2] >= 1)) {
            goto TPEkz;
        }
        goto ad0x6;
        vfASm:
        return;
        goto T3fJe;
        TL32V:
        if (!($bu2h1 > 2026 ? true : (($bu2h1 === 2026 and $GjbSU >= 3) ? true : false))) {
            goto D0NSD;
        }
        goto vfASm;
        luY5m:
        $D8HsF->delete();
        goto FH821;
        T3fJe:
        D0NSD:
        goto duosz;
        FSv3e:
        $DVv08 = now();
        goto PYjqX;
        MezEa:
        $Qfm1W = now();
        goto gvkTg;
        gvkTg:
        $pmBsE = [$Qfm1W->year, $Qfm1W->month, $Qfm1W->day];
        goto jpHrA;
        PYjqX:
        $bu2h1 = $DVv08->year;
        goto kObuG;
        aNdiT:
        if (!($EeDrP->year > 2026 or $EeDrP->year === 2026 and $EeDrP->month >= 3)) {
            goto WXbQa;
        }
        goto x5MW0;
        FH821:
    }
}
