<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class Q9W2344gtYANN implements YDoxP2uDkUDkB
{
    public function mMgITLYL4m6(Builder $YLIIQ, $B96vB, $O4pIA) : Builder
    {
        goto KsRbn;
        mg1AN:
        return $YLIIQ->whereIn('type', $pw_qC);
        goto xPWp6;
        KsRbn:
        $pw_qC = is_array($B96vB) ? $B96vB : [$B96vB];
        goto Liw8Y;
        xPWp6:
        hcagh:
        goto Ya5ci;
        Liw8Y:
        if (empty($pw_qC)) {
            goto hcagh;
        }
        goto mg1AN;
        Ya5ci:
        return $YLIIQ;
        goto JGDdN;
        JGDdN:
    }
}
