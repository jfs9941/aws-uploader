<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use src\Gallery\Service\Search\TjfQAwaWAJ4N9;
class Hw9Pra3lWfHW0 implements TjfQAwaWAJ4N9
{
    public function mCaa0P7P2Ba(Builder $w31bN, $Yy1sZ) : Builder
    {
        goto iEga9;
        iEga9:
        $WrWpV = is_array($Yy1sZ) ? $Yy1sZ : [$Yy1sZ];
        goto Rs8_s;
        jxdaz:
        return $w31bN;
        goto C0xCf;
        diKQH:
        return $w31bN->whereIn('type', $WrWpV);
        goto gB5aX;
        Rs8_s:
        if (empty($WrWpV)) {
            goto bxg5b;
        }
        goto diKQH;
        gB5aX:
        bxg5b:
        goto jxdaz;
        C0xCf:
    }
}
