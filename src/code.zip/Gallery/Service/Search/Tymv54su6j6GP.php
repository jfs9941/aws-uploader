<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\GJ442z8TMlzkg;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Tymv54su6j6GP implements GJ442z8TMlzkg
{
    protected const b2AJk = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m0I9i9iKVnz(Builder $DmFxf, $ob_ZH, $X3RaZ = true) : Builder
    {
        goto jwKxs;
        zFKe6:
        $oKpYD = self::b2AJk[$q7U4x];
        goto WosTi;
        IGgBb:
        return $DmFxf;
        goto Szy2z;
        RyvRx:
        if (!isset(self::b2AJk[$q7U4x])) {
            goto Z17UC;
        }
        goto zFKe6;
        TaG7F:
        Z17UC:
        goto IGgBb;
        WosTi:
        return $DmFxf->where($oKpYD, '=', $X3RaZ);
        goto TaG7F;
        jwKxs:
        $q7U4x = Str::lower($ob_ZH);
        goto RyvRx;
        Szy2z:
    }
}
