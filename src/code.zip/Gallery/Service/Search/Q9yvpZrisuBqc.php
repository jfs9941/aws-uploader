<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\HpA17PWfMPObT;
use Illuminate\Database\Eloquent\Builder;
class Q9yvpZrisuBqc implements HpA17PWfMPObT
{
    public function m00oogy0owc(Builder $GkjMb, $In5x2, $Y9b7D) : Builder
    {
        goto V6V5f;
        V6V5f:
        $B2Kdf = is_array($In5x2) ? $In5x2 : [$In5x2];
        goto ywqLX;
        r_rK1:
        y4Sss:
        goto UNLjn;
        PusZs:
        goto JZaAp;
        goto r_rK1;
        G1BxN:
        return $GkjMb;
        goto Au66a;
        ywqLX:
        if (empty($B2Kdf)) {
            goto FXOYH;
        }
        goto DNTue;
        GEumg:
        JZaAp:
        goto SGsmW;
        pZefs:
        return $GkjMb->whereNotIn('type', $B2Kdf);
        goto PusZs;
        DNTue:
        if ($Y9b7D) {
            goto y4Sss;
        }
        goto pZefs;
        UNLjn:
        return $GkjMb->whereIn('type', $B2Kdf);
        goto GEumg;
        SGsmW:
        FXOYH:
        goto G1BxN;
        Au66a:
    }
}
