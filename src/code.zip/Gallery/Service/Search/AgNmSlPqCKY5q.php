<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class AgNmSlPqCKY5q implements X08LN7tFFGHa4
{
    public function mpCWvk5cF1i(Builder $PaniD, $z85MS, $Wnwak) : Builder
    {
        goto BpbP9;
        WqCMz:
        wzobt:
        goto X93F2;
        X93F2:
        return $PaniD;
        goto jrk7Q;
        TTclx:
        if (empty($mrYmS)) {
            goto wzobt;
        }
        goto lUlfZ;
        BpbP9:
        $mrYmS = is_array($z85MS) ? $z85MS : [$z85MS];
        goto TTclx;
        lUlfZ:
        return $PaniD->whereIn('type', $mrYmS);
        goto WqCMz;
        jrk7Q:
    }
}
