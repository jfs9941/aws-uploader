<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\FT3xONdY4ln2V;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class IkqZFYx3nV3bq implements FT3xONdY4ln2V
{
    protected const UONSU = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m2xXyEImnIi(Builder $BoTPl, $sTjof, $C1uxO = true) : Builder
    {
        goto Rf21v;
        RY_b1:
        return $BoTPl;
        goto Z1UlH;
        IjAmf:
        $Pr16o = self::UONSU[$jg_es];
        goto A1poj;
        jNYXd:
        if (!isset(self::UONSU[$jg_es])) {
            goto g7YNg;
        }
        goto IjAmf;
        mj5XQ:
        g7YNg:
        goto RY_b1;
        Rf21v:
        $jg_es = Str::lower($sTjof);
        goto jNYXd;
        A1poj:
        return $BoTPl->where($Pr16o, '=', $C1uxO);
        goto mj5XQ;
        Z1UlH:
    }
}
