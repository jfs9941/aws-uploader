<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\UjCdlzMnPdCKC;
use Illuminate\Database\Eloquent\Builder;
class OaaIy59IME9Kv implements UjCdlzMnPdCKC
{
    public function my0Gmz1GDju(Builder $tdgEg, $yvGQM, $t0rpw) : Builder
    {
        goto pzpds;
        RrIZZ:
        return $tdgEg->whereNotIn('type', $tyTaw);
        goto vmVYZ;
        vmVYZ:
        goto sgt10;
        goto M9aap;
        pzpds:
        $tyTaw = is_array($yvGQM) ? $yvGQM : [$yvGQM];
        goto L3fVk;
        ixdsB:
        return $tdgEg->whereIn('type', $tyTaw);
        goto YMabS;
        L3fVk:
        if (empty($tyTaw)) {
            goto nXgC9;
        }
        goto avxW_;
        avxW_:
        if ($t0rpw) {
            goto uMOHG;
        }
        goto RrIZZ;
        YMabS:
        sgt10:
        goto qD0tO;
        M9aap:
        uMOHG:
        goto ixdsB;
        qD0tO:
        nXgC9:
        goto BMeJ9;
        BMeJ9:
        return $tdgEg;
        goto C6XtN;
        C6XtN:
    }
}
