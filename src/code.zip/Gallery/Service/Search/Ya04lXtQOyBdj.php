<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\HpA17PWfMPObT;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Ya04lXtQOyBdj implements HpA17PWfMPObT
{
    protected const MvoBV = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m00oogy0owc(Builder $GkjMb, $In5x2, $Y9b7D = true) : Builder
    {
        goto wXorv;
        HXjRs:
        if (!isset(self::MvoBV[$IoqU_])) {
            goto K8pFC;
        }
        goto SkfRt;
        wXorv:
        $IoqU_ = Str::lower($In5x2);
        goto HXjRs;
        bbodj:
        K8pFC:
        goto M3Aat;
        QEh56:
        return $GkjMb->where($mGp0x, '=', $Y9b7D);
        goto bbodj;
        M3Aat:
        return $GkjMb;
        goto naipv;
        SkfRt:
        $mGp0x = self::MvoBV[$IoqU_];
        goto QEh56;
        naipv:
    }
}
