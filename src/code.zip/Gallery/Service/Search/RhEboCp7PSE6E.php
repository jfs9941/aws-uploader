<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\EWz4UlANqCQvW;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class RhEboCp7PSE6E implements EWz4UlANqCQvW
{
    protected const QWmwV = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mD0LEl18Mxz(Builder $gWJqy, $Xuk64, $Q5DjF = true) : Builder
    {
        goto M2qKG;
        R_LVV:
        gg1TA:
        goto ujc93;
        sT2AE:
        return $gWJqy->where($eCt2V, '=', $Q5DjF);
        goto R_LVV;
        ujc93:
        return $gWJqy;
        goto YZDAx;
        KnFLk:
        if (!isset(self::QWmwV[$q7fRF])) {
            goto gg1TA;
        }
        goto uVDKD;
        M2qKG:
        $q7fRF = Str::lower($Xuk64);
        goto KnFLk;
        uVDKD:
        $eCt2V = self::QWmwV[$q7fRF];
        goto sT2AE;
        YZDAx:
    }
}
