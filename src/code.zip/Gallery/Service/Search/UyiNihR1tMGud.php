<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class UyiNihR1tMGud implements Id1zmbqroCpYB
{
    protected const pEaBr = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mZbAw7ISZ0W(Builder $xAWQW, $tkbx1, $Te_Zg = true) : Builder
    {
        goto LrVMk;
        LrVMk:
        $rC1j_ = Str::lower($tkbx1);
        goto v7EIh;
        BrsVY:
        return $xAWQW;
        goto ZYx3_;
        v7EIh:
        if (!isset(self::pEaBr[$rC1j_])) {
            goto Ttmzi;
        }
        goto Iud5P;
        Iud5P:
        $Jci_d = self::pEaBr[$rC1j_];
        goto S00YH;
        S00YH:
        return $xAWQW->where($Jci_d, '=', $Te_Zg);
        goto WH3Cx;
        WH3Cx:
        Ttmzi:
        goto BrsVY;
        ZYx3_:
    }
}
