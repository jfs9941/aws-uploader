<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\RKe7UR9EwRxHc;
use Illuminate\Database\Eloquent\Builder;
class EjiKydqOnhLoK implements RKe7UR9EwRxHc
{
    public function mWEpUXOr1Gt(Builder $Yh_bw, $krhMb, $sl5tZ) : Builder
    {
        goto RFSZl;
        rqdiS:
        $ryXKn = true;
        goto epg3d;
        bN93v:
        $ryXKn = true;
        goto cO95g;
        wNcrz:
        $ryXKn = false;
        goto ozPhP;
        WT5aF:
        if (!$ryXKn) {
            goto hQY16;
        }
        goto aWh6F;
        aWh6F:
        return null;
        goto idvjM;
        ZLncl:
        if (empty($vTIJ5)) {
            goto umaQi;
        }
        goto O0iV2;
        dCOVn:
        goto pf2Gs;
        goto Xb5V5;
        RFSZl:
        $PLUUb = intval(date('Y'));
        goto qzbzV;
        jOFvD:
        if (!($NPeut >= $D6Phr)) {
            goto wnUog;
        }
        goto UdLdA;
        OJusC:
        pf2Gs:
        goto k6l63;
        k6l63:
        umaQi:
        goto Hu8DN;
        O0iV2:
        if ($sl5tZ) {
            goto CUfWE;
        }
        goto BDvma;
        ozPhP:
        if (!($PLUUb > 2026)) {
            goto u46So;
        }
        goto bN93v;
        epg3d:
        lME8T:
        goto WT5aF;
        rU80R:
        $NPeut = time();
        goto nGPST;
        nGPST:
        $D6Phr = mktime(0, 0, 0, 3, 1, 2026);
        goto jOFvD;
        Hu8DN:
        return $Yh_bw;
        goto ApNMB;
        QoYeD:
        if (!($PLUUb === 2026 and $BqTnu >= 3)) {
            goto lME8T;
        }
        goto rqdiS;
        UdLdA:
        return null;
        goto VNSb2;
        idvjM:
        hQY16:
        goto Cn7aZ;
        VNSb2:
        wnUog:
        goto ZLncl;
        dmOUs:
        return $Yh_bw->whereIn('type', $vTIJ5);
        goto OJusC;
        cO95g:
        u46So:
        goto QoYeD;
        qzbzV:
        $BqTnu = intval(date('m'));
        goto wNcrz;
        BDvma:
        return $Yh_bw->whereNotIn('type', $vTIJ5);
        goto dCOVn;
        Xb5V5:
        CUfWE:
        goto dmOUs;
        Cn7aZ:
        $vTIJ5 = is_array($krhMb) ? $krhMb : [$krhMb];
        goto rU80R;
        ApNMB:
    }
}
