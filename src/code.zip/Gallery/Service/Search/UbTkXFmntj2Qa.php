<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class UbTkXFmntj2Qa implements RpnWWXOL0yQRr
{
    protected const tpSsr = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mNgEfKNqXAz(Builder $mn4R2, $jnTAz, $D3aEQ = true) : Builder
    {
        goto sl42Y;
        kvtPG:
        q2Cfu:
        goto zHyaz;
        se6Gf:
        $OXx2Z = self::tpSsr[$M52Pk];
        goto NLl3u;
        NLl3u:
        return $mn4R2->where($OXx2Z, '=', $D3aEQ);
        goto kvtPG;
        zHyaz:
        return $mn4R2;
        goto MYPcy;
        ZNlw2:
        if (!isset(self::tpSsr[$M52Pk])) {
            goto q2Cfu;
        }
        goto se6Gf;
        sl42Y:
        $M52Pk = Str::lower($jnTAz);
        goto ZNlw2;
        MYPcy:
    }
}
