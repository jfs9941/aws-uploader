<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class ZNfqdDMft94dJ implements IzAnV0kIIRlzN
{
    public function mJIhndXL12f(Builder $uXKnP, $LIlJV, $UEH2j) : Builder
    {
        goto mfMVk;
        tJn2s:
        return $uXKnP;
        goto xe1Ia;
        wwfkx:
        return $uXKnP->whereIn('type', $HDdRC);
        goto PMA0C;
        mfMVk:
        $HDdRC = is_array($LIlJV) ? $LIlJV : [$LIlJV];
        goto MRsx6;
        PMA0C:
        vlzr9:
        goto tJn2s;
        MRsx6:
        if (empty($HDdRC)) {
            goto vlzr9;
        }
        goto wwfkx;
        xe1Ia:
    }
}
