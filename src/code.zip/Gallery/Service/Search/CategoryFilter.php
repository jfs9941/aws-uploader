<?php

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class CategoryFilter implements FilterInterface
{
    /**
     * A map of request values to database column names.
     */
    protected const COLUMN_MAP = [
        'post' => 'is_post',
        'message' => 'is_message',
        'shop' => 'is_shop',
    ];

    public function apply(Builder $builder, $value): Builder
    {
        // Sanitize the input value
        $categoryKey = Str::lower($value);

        // Check if the provided category is valid and mapped
        if (isset(self::COLUMN_MAP[$categoryKey])) {
            $columnName = self::COLUMN_MAP[$categoryKey];
            return $builder->where($columnName, '=' , true);
        }

        // If the category is not valid, return the builder unmodified
        return $builder;
    }
}
