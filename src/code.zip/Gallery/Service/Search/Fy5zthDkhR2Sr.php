<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\ABSmOmN8jVjWw;
use Illuminate\Database\Eloquent\Builder;
class Fy5zthDkhR2Sr implements ABSmOmN8jVjWw
{
    public function mfEhyMpa5RD(Builder $b3eGW, $ha4uD, $Z5HHo) : Builder
    {
        goto hwpNZ;
        H0gJR:
        V9Ls_:
        goto kV4iK;
        Fso2f:
        return $b3eGW->whereIn('type', $YQTgd);
        goto H0gJR;
        VvRDT:
        if (empty($YQTgd)) {
            goto V9Ls_;
        }
        goto Fso2f;
        kV4iK:
        return $b3eGW;
        goto MRuh4;
        hwpNZ:
        $YQTgd = is_array($ha4uD) ? $ha4uD : [$ha4uD];
        goto VvRDT;
        MRuh4:
    }
}
