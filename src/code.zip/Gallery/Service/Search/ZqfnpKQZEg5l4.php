<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\KrSr5QF5M5YfT;
use Illuminate\Database\Eloquent\Builder;
class ZqfnpKQZEg5l4 implements KrSr5QF5M5YfT
{
    public function mkZd1MmZovC(Builder $NLBFz, $TBVxN, $IYAcj) : Builder
    {
        goto Fhh6G;
        f82OH:
        return $NLBFz->whereNotIn('type', $K44Hp);
        goto gX6Dt;
        gFgeO:
        return $NLBFz->whereIn('type', $K44Hp);
        goto Ak11Z;
        nIl_d:
        KQkld:
        goto r2ra4;
        YuNOB:
        if ($IYAcj) {
            goto SoVcN;
        }
        goto f82OH;
        ITcg8:
        SoVcN:
        goto gFgeO;
        r2ra4:
        return $NLBFz;
        goto UyM23;
        Fhh6G:
        $K44Hp = is_array($TBVxN) ? $TBVxN : [$TBVxN];
        goto tTHeb;
        Ak11Z:
        TVCrO:
        goto nIl_d;
        gX6Dt:
        goto TVCrO;
        goto ITcg8;
        tTHeb:
        if (empty($K44Hp)) {
            goto KQkld;
        }
        goto YuNOB;
        UyM23:
    }
}
