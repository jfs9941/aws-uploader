<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\DoQSKTJEY2pjy;
use Illuminate\Database\Eloquent\Builder;
class ZTITG4LclaIsH implements DoQSKTJEY2pjy
{
    public function mRTrEmrRYkC(Builder $kclx2, $iDWQ2, $E8b71) : Builder
    {
        goto worQH;
        PSC40:
        xag5D:
        goto CN1s8;
        EPGJY:
        FBqON:
        goto kSE2a;
        Bhexv:
        MM8af:
        goto PSC40;
        yJNNy:
        goto MM8af;
        goto EPGJY;
        worQH:
        $wCZfT = is_array($iDWQ2) ? $iDWQ2 : [$iDWQ2];
        goto JUU2_;
        kSE2a:
        return $kclx2->whereIn('type', $wCZfT);
        goto Bhexv;
        Eoj4F:
        return $kclx2->whereNotIn('type', $wCZfT);
        goto yJNNy;
        CN1s8:
        return $kclx2;
        goto bUe5V;
        zHWzo:
        if ($E8b71) {
            goto FBqON;
        }
        goto Eoj4F;
        JUU2_:
        if (empty($wCZfT)) {
            goto xag5D;
        }
        goto zHWzo;
        bUe5V:
    }
}
