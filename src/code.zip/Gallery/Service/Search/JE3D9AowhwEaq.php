<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class JE3D9AowhwEaq implements AcpyJoTxMAGcI
{
    protected const oaTEm = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mCs88Lgj6p3(Builder $Eo278, $k7YY4, $Ctq8M = true) : Builder
    {
        goto VNEBp;
        KEWO5:
        return $Eo278;
        goto O5bDS;
        VNEBp:
        $K3c6H = Str::lower($k7YY4);
        goto LlqaV;
        LlqaV:
        if (!isset(self::oaTEm[$K3c6H])) {
            goto pleQi;
        }
        goto CUhDr;
        CUhDr:
        $SP2Wx = self::oaTEm[$K3c6H];
        goto zo6hH;
        zo6hH:
        return $Eo278->where($SP2Wx, '=', $Ctq8M);
        goto gFxsi;
        gFxsi:
        pleQi:
        goto KEWO5;
        O5bDS:
    }
}
