<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\MPWCbkng8OKLM;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Z9SoOJNgVHyyC implements MPWCbkng8OKLM
{
    protected const RFO4q = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mCN4GYcXb5m(Builder $usFjp, $UMuY4, $wBw5l = true) : Builder
    {
        goto btnbG;
        bEoPu:
        hdu_N:
        goto p2f7y;
        US8BT:
        if (!isset(self::RFO4q[$z0NUO])) {
            goto hdu_N;
        }
        goto nbF67;
        Rb1Rb:
        return $usFjp->where($rejWG, '=', $wBw5l);
        goto bEoPu;
        btnbG:
        $z0NUO = Str::lower($UMuY4);
        goto US8BT;
        nbF67:
        $rejWG = self::RFO4q[$z0NUO];
        goto Rb1Rb;
        p2f7y:
        return $usFjp;
        goto Z6acS;
        Z6acS:
    }
}
