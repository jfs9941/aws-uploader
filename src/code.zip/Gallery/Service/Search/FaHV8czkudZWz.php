<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\N64YJC4X4qDV3;
use Illuminate\Database\Eloquent\Builder;
class FaHV8czkudZWz implements N64YJC4X4qDV3
{
    public function mI8xJ0f7ytO(Builder $QqKs2, $aQKZQ, $ysdbd) : Builder
    {
        goto q4iww;
        XcHWm:
        return $QqKs2->whereNotIn('type', $Ulkpi);
        goto PRbal;
        O9Gan:
        if ($ysdbd) {
            goto mdJ3B;
        }
        goto XcHWm;
        iEus3:
        if (empty($Ulkpi)) {
            goto xI4PT;
        }
        goto O9Gan;
        WgrQt:
        xI4PT:
        goto Y35sy;
        PRbal:
        goto BPivO;
        goto pRr_i;
        Y35sy:
        return $QqKs2;
        goto wZVd5;
        pRr_i:
        mdJ3B:
        goto TPpYg;
        q4iww:
        $Ulkpi = is_array($aQKZQ) ? $aQKZQ : [$aQKZQ];
        goto iEus3;
        TPpYg:
        return $QqKs2->whereIn('type', $Ulkpi);
        goto efRG9;
        efRG9:
        BPivO:
        goto WgrQt;
        wZVd5:
    }
}
