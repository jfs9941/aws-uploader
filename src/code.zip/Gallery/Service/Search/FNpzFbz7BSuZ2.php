<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\KAYXaENrCFXh2;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class FNpzFbz7BSuZ2 implements KAYXaENrCFXh2
{
    protected const i0pMY = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m3XdntuV3ms(Builder $lh42H, $MNFD8, $Dcoua = true) : Builder
    {
        goto S8MlG;
        k1GNP:
        return $lh42H->where($ac4W6, '=', $Dcoua);
        goto Cgkjf;
        Rmovx:
        $ac4W6 = self::i0pMY[$csadN];
        goto k1GNP;
        iVTzQ:
        if (!isset(self::i0pMY[$csadN])) {
            goto yXPy2;
        }
        goto Rmovx;
        S8MlG:
        $csadN = Str::lower($MNFD8);
        goto iVTzQ;
        Cgkjf:
        yXPy2:
        goto Cnc9w;
        Cnc9w:
        return $lh42H;
        goto DUeOn;
        DUeOn:
    }
}
