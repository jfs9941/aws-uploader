<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class Y3m3hZl4G0uZi implements R3QFmJg6F6ARf
{
    public function mcTvhVRb3hm(Builder $PuAgf, $YogbQ) : Builder
    {
        goto sKPFR;
        Va0n6:
        if (empty($sUC1U)) {
            goto wKrHR;
        }
        goto a5Z76;
        leWkL:
        return $PuAgf;
        goto rhCnW;
        sKPFR:
        $sUC1U = is_array($YogbQ) ? $YogbQ : [$YogbQ];
        goto Va0n6;
        a5Z76:
        return $PuAgf->whereIn('type', $sUC1U);
        goto LicOG;
        LicOG:
        wKrHR:
        goto leWkL;
        rhCnW:
    }
}
