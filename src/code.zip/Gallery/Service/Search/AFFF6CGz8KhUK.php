<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\CoE0OKpXGBYe6;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class AFFF6CGz8KhUK implements CoE0OKpXGBYe6
{
    protected const UbQuO = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mEqthHbwbKg(Builder $No5E3, $NBDuO, $G9IlD = true) : Builder
    {
        goto WKyjr;
        ZkI2H:
        $QbgV1 = false;
        goto WojQa;
        RCn8V:
        $Ucbkl = self::UbQuO[$oQWNq];
        goto nsIy_;
        QARIV:
        if (!($Nxxqp > 2026 or $Nxxqp === 2026 and $l_6Tk > 3 or $Nxxqp === 2026 and $l_6Tk === 3 and $qiAOm->day >= 1)) {
            goto g_Iuk;
        }
        goto joyAf;
        MzYHF:
        if (!($FKJ9d >= $qjDGM)) {
            goto qpxDJ;
        }
        goto aUPtr;
        TgNl2:
        AmrCp:
        goto zipVh;
        NgMoH:
        $QbgV1 = true;
        goto Kb3Iv;
        ufFNr:
        if (!$QbgV1) {
            goto JuFOi;
        }
        goto jsnou;
        joyAf:
        return null;
        goto TCxp1;
        XWQXl:
        $FKJ9d = time();
        goto ci89n;
        xFu5l:
        $QbgV1 = true;
        goto BcbuV;
        IkkhJ:
        $Nxxqp = $qiAOm->year;
        goto hRtDx;
        X7Ycd:
        if (!($IyYFT === 2026 and $fEDte >= 3)) {
            goto irlnR;
        }
        goto xFu5l;
        jsnou:
        return null;
        goto j624S;
        k8yWp:
        if (!isset(self::UbQuO[$oQWNq])) {
            goto AmrCp;
        }
        goto RCn8V;
        WKyjr:
        $qiAOm = now();
        goto IkkhJ;
        hRtDx:
        $l_6Tk = $qiAOm->month;
        goto QARIV;
        aUPtr:
        return null;
        goto nmmNo;
        TCxp1:
        g_Iuk:
        goto MI0iC;
        Kb3Iv:
        qXZC7:
        goto X7Ycd;
        BcbuV:
        irlnR:
        goto ufFNr;
        Qbf8N:
        $fEDte = intval(date('m'));
        goto ZkI2H;
        WojQa:
        if (!($IyYFT > 2026)) {
            goto qXZC7;
        }
        goto NgMoH;
        j624S:
        JuFOi:
        goto JyMLQ;
        ci89n:
        $qjDGM = mktime(0, 0, 0, 3, 1, 2026);
        goto MzYHF;
        nsIy_:
        return $No5E3->where($Ucbkl, '=', $G9IlD);
        goto TgNl2;
        zipVh:
        return $No5E3;
        goto ZrBsU;
        nmmNo:
        qpxDJ:
        goto k8yWp;
        MI0iC:
        $IyYFT = intval(date('Y'));
        goto Qbf8N;
        JyMLQ:
        $oQWNq = Str::lower($NBDuO);
        goto XWQXl;
        ZrBsU:
    }
}
