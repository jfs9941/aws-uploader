<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\QX45eBU594VwZ;
use Illuminate\Database\Eloquent\Builder;
class BT7vr2KkCSjJ8 implements QX45eBU594VwZ
{
    public function mQZXyrFVvse(Builder $ONlVY, $lm2dB, $DY3jQ) : Builder
    {
        goto fz0w0;
        Wf_mt:
        if ($DY3jQ) {
            goto TJ7u7;
        }
        goto nVsMT;
        lIQXG:
        Sys8T:
        goto vlY1i;
        Zxpv0:
        TJ7u7:
        goto lozlO;
        vlY1i:
        return $ONlVY;
        goto bW586;
        v5lvj:
        if (empty($ZGWoS)) {
            goto Sys8T;
        }
        goto Wf_mt;
        fz0w0:
        $ZGWoS = is_array($lm2dB) ? $lm2dB : [$lm2dB];
        goto v5lvj;
        zjuKE:
        gXz7T:
        goto lIQXG;
        nVsMT:
        return $ONlVY->whereNotIn('type', $ZGWoS);
        goto NPup6;
        NPup6:
        goto gXz7T;
        goto Zxpv0;
        lozlO:
        return $ONlVY->whereIn('type', $ZGWoS);
        goto zjuKE;
        bW586:
    }
}
