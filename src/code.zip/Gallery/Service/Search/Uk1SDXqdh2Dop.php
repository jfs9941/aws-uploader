<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class Uk1SDXqdh2Dop implements YL1ekuEHjKHB6
{
    public function muv3MyLhlJm(Builder $RSfya, $u_YyZ, $E_FbM) : Builder
    {
        goto VdMXS;
        VdMXS:
        $MC6nD = is_array($u_YyZ) ? $u_YyZ : [$u_YyZ];
        goto pN_I3;
        pN_I3:
        if (empty($MC6nD)) {
            goto yxPs1;
        }
        goto pU3m4;
        TDZ8u:
        return $RSfya;
        goto Ab6_z;
        pU3m4:
        return $RSfya->whereIn('type', $MC6nD);
        goto M8eEb;
        M8eEb:
        yxPs1:
        goto TDZ8u;
        Ab6_z:
    }
}
