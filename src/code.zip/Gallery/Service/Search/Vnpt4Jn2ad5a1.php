<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\OMKcqo45IDWKI;
use Illuminate\Database\Eloquent\Builder;
class Vnpt4Jn2ad5a1 implements OMKcqo45IDWKI
{
    public function m1O95GkRtTP(Builder $DTD0q, $k_6Sv, $y3Hr1) : Builder
    {
        goto qyzFl;
        eWWWp:
        UvwaB:
        goto TIu0f;
        iqrvJ:
        return $DTD0q;
        goto Phqau;
        TIu0f:
        MN2OT:
        goto iqrvJ;
        qyzFl:
        $h1tV0 = is_array($k_6Sv) ? $k_6Sv : [$k_6Sv];
        goto qqHKL;
        qqHKL:
        if (empty($h1tV0)) {
            goto MN2OT;
        }
        goto XsgQe;
        XsgQe:
        if ($y3Hr1) {
            goto nUiLs;
        }
        goto psKk_;
        TwZX_:
        return $DTD0q->whereIn('type', $h1tV0);
        goto eWWWp;
        psKk_:
        return $DTD0q->whereNotIn('type', $h1tV0);
        goto l2zIk;
        l2zIk:
        goto UvwaB;
        goto wK5Wj;
        wK5Wj:
        nUiLs:
        goto TwZX_;
        Phqau:
    }
}
