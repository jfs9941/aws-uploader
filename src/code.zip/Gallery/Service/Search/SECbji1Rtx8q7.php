<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\I7VEXBdZYkDiA;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class SECbji1Rtx8q7 implements I7VEXBdZYkDiA
{
    protected const Q_ZR1 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mF5p1W7dbc2(Builder $hXUx3, $rQZNV, $kAphC = true) : Builder
    {
        goto ErYz4;
        ErYz4:
        $gdW1F = Str::lower($rQZNV);
        goto mcVps;
        xq6Dd:
        return $hXUx3->where($ptQoi, '=', $kAphC);
        goto Dxneq;
        BKc9v:
        return $hXUx3;
        goto xJn0c;
        mcVps:
        if (!isset(self::Q_ZR1[$gdW1F])) {
            goto tZ3kL;
        }
        goto wiuM_;
        Dxneq:
        tZ3kL:
        goto BKc9v;
        wiuM_:
        $ptQoi = self::Q_ZR1[$gdW1F];
        goto xq6Dd;
        xJn0c:
    }
}
