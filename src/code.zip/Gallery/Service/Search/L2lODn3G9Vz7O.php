<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\ZeSwZkTbZnxYR;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class L2lODn3G9Vz7O implements ZeSwZkTbZnxYR
{
    protected const u_mk0 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function maAXfSUX2mK(Builder $iAUh7, $loD4e, $XD8SW = true) : Builder
    {
        goto fldIB;
        fUhim:
        return $iAUh7;
        goto B7aYT;
        ZThN8:
        $s_8He = self::u_mk0[$aVz51];
        goto STj_m;
        STj_m:
        return $iAUh7->where($s_8He, '=', $XD8SW);
        goto A8BF8;
        A8BF8:
        eVWT4:
        goto fUhim;
        ev9dl:
        if (!isset(self::u_mk0[$aVz51])) {
            goto eVWT4;
        }
        goto ZThN8;
        fldIB:
        $aVz51 = Str::lower($loD4e);
        goto ev9dl;
        B7aYT:
    }
}
