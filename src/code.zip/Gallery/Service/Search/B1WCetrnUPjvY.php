<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Zb2RivTMNxeXN;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class B1WCetrnUPjvY implements Zb2RivTMNxeXN
{
    protected const vhi3Q = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mVPkONnVEF8(Builder $xGZ7p, $S9pFE, $hwwQ3 = true) : Builder
    {
        goto x62QY;
        r18Dg:
        return $xGZ7p->where($RMvnX, '=', $hwwQ3);
        goto zppQr;
        MoaRT:
        return $xGZ7p;
        goto wBdu5;
        x62QY:
        $aMrsK = Str::lower($S9pFE);
        goto Lj7IA;
        Lj7IA:
        if (!isset(self::vhi3Q[$aMrsK])) {
            goto a3ntu;
        }
        goto MqhVl;
        MqhVl:
        $RMvnX = self::vhi3Q[$aMrsK];
        goto r18Dg;
        zppQr:
        a3ntu:
        goto MoaRT;
        wBdu5:
    }
}
