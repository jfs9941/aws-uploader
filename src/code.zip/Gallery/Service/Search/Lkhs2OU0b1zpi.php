<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\FT3xONdY4ln2V;
use Illuminate\Database\Eloquent\Builder;
class Lkhs2OU0b1zpi implements FT3xONdY4ln2V
{
    public function m2xXyEImnIi(Builder $BoTPl, $sTjof, $C1uxO) : Builder
    {
        goto MN_2O;
        MN_2O:
        $g9159 = is_array($sTjof) ? $sTjof : [$sTjof];
        goto L1p20;
        yGpTk:
        return $BoTPl->whereIn('type', $g9159);
        goto hh_Kf;
        DcPQp:
        jn0uB:
        goto M19n1;
        hh_Kf:
        PNu91:
        goto DcPQp;
        P2Vw2:
        goto PNu91;
        goto LJDs2;
        L1p20:
        if (empty($g9159)) {
            goto jn0uB;
        }
        goto Uqqxo;
        beW_2:
        return $BoTPl->whereNotIn('type', $g9159);
        goto P2Vw2;
        M19n1:
        return $BoTPl;
        goto TEuej;
        LJDs2:
        e33mm:
        goto yGpTk;
        Uqqxo:
        if ($C1uxO) {
            goto e33mm;
        }
        goto beW_2;
        TEuej:
    }
}
