<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class PgziA1DkeVgwz implements Id1zmbqroCpYB
{
    public function mZbAw7ISZ0W(Builder $xAWQW, $tkbx1, $Te_Zg) : Builder
    {
        goto oLOa5;
        jEmMA:
        sQSdW:
        goto FZzWS;
        Chd3f:
        return $xAWQW->whereIn('type', $K7fbL);
        goto jEmMA;
        oLOa5:
        $K7fbL = is_array($tkbx1) ? $tkbx1 : [$tkbx1];
        goto eDRuH;
        FZzWS:
        return $xAWQW;
        goto QA20m;
        eDRuH:
        if (empty($K7fbL)) {
            goto sQSdW;
        }
        goto Chd3f;
        QA20m:
    }
}
