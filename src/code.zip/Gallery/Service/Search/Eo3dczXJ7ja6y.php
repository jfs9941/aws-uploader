<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\K9BaiSBUMOvJv;
use Illuminate\Database\Eloquent\Builder;
class Eo3dczXJ7ja6y implements K9BaiSBUMOvJv
{
    public function m8ceBUt3CYD(Builder $jknT2, $YK2ei, $KNnzx) : Builder
    {
        goto LFLNk;
        SOiVU:
        if ($KNnzx) {
            goto p1cAm;
        }
        goto jQUKI;
        Qi6x8:
        p1cAm:
        goto sakDI;
        jQUKI:
        return $jknT2->whereNotIn('type', $TfoY6);
        goto cvj4i;
        LFLNk:
        $TfoY6 = is_array($YK2ei) ? $YK2ei : [$YK2ei];
        goto YIo6V;
        cvj4i:
        goto nv8XZ;
        goto Qi6x8;
        Qrml3:
        nv8XZ:
        goto g8n5f;
        sakDI:
        return $jknT2->whereIn('type', $TfoY6);
        goto Qrml3;
        YIo6V:
        if (empty($TfoY6)) {
            goto O0P6A;
        }
        goto SOiVU;
        g8n5f:
        O0P6A:
        goto LJBUG;
        LJBUG:
        return $jknT2;
        goto XU3ji;
        XU3ji:
    }
}
