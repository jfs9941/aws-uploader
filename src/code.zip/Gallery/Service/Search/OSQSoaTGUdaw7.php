<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class OSQSoaTGUdaw7 implements YL1ekuEHjKHB6
{
    protected const DLxqk = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function muv3MyLhlJm(Builder $RSfya, $u_YyZ, $E_FbM = true) : Builder
    {
        goto z1_zg;
        bH0KW:
        return $RSfya;
        goto yIn7u;
        EwYG9:
        TyGKM:
        goto bH0KW;
        eHtR3:
        $E6luA = self::DLxqk[$EsJck];
        goto EETMR;
        EETMR:
        return $RSfya->where($E6luA, '=', $E_FbM);
        goto EwYG9;
        FujpH:
        if (!isset(self::DLxqk[$EsJck])) {
            goto TyGKM;
        }
        goto eHtR3;
        z1_zg:
        $EsJck = Str::lower($u_YyZ);
        goto FujpH;
        yIn7u:
    }
}
