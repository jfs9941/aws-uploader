<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\K9BaiSBUMOvJv;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class WQTiZa46K4y9I implements K9BaiSBUMOvJv
{
    protected const G2PVk = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m8ceBUt3CYD(Builder $jknT2, $YK2ei, $KNnzx = true) : Builder
    {
        goto M5bkj;
        M5bkj:
        $u5Z5_ = Str::lower($YK2ei);
        goto Vh_AU;
        Vh_AU:
        if (!isset(self::G2PVk[$u5Z5_])) {
            goto HBqIp;
        }
        goto g5fio;
        g5fio:
        $GhGFU = self::G2PVk[$u5Z5_];
        goto ihRA0;
        ihRA0:
        return $jknT2->where($GhGFU, '=', $KNnzx);
        goto Nvn1S;
        Nvn1S:
        HBqIp:
        goto zU2VL;
        zU2VL:
        return $jknT2;
        goto qoeB6;
        qoeB6:
    }
}
