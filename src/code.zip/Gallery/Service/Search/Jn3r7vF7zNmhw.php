<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class Jn3r7vF7zNmhw implements URI41WL8s209Q
{
    public function mvxFHVrMgPO(Builder $O81mB, $bzRbW) : Builder
    {
        goto gjSd6;
        EMICq:
        t99pE:
        goto PhaND;
        avddH:
        if (empty($zEjlY)) {
            goto t99pE;
        }
        goto CW6Dx;
        PhaND:
        return $O81mB;
        goto Fsncj;
        CW6Dx:
        return $O81mB->whereIn('type', $zEjlY);
        goto EMICq;
        gjSd6:
        $zEjlY = is_array($bzRbW) ? $bzRbW : [$bzRbW];
        goto avddH;
        Fsncj:
    }
}
