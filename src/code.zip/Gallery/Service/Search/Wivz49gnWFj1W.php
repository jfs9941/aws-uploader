<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Wivz49gnWFj1W implements R3QFmJg6F6ARf
{
    protected const hlMW2 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mcTvhVRb3hm(Builder $PuAgf, $YogbQ) : Builder
    {
        goto tziL8;
        UrhQa:
        return $PuAgf->where($aSkaF, '=', true);
        goto GQ3xa;
        tziL8:
        $Ldrrz = Str::lower($YogbQ);
        goto MQJyd;
        P3tUm:
        return $PuAgf;
        goto Ioz7I;
        V1ZwC:
        $aSkaF = self::hlMW2[$Ldrrz];
        goto UrhQa;
        GQ3xa:
        eQVQ7:
        goto P3tUm;
        MQJyd:
        if (!isset(self::hlMW2[$Ldrrz])) {
            goto eQVQ7;
        }
        goto V1ZwC;
        Ioz7I:
    }
}
