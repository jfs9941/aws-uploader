<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\U0EK8U2OUwM4T;
use Illuminate\Database\Eloquent\Builder;
class FI9Bt583XnkLm implements U0EK8U2OUwM4T
{
    public function mAKe1GASNgN(Builder $lqRvU, $XuStJ, $F5PpY) : Builder
    {
        goto LbYWT;
        pt4Wb:
        i_JQD:
        goto ceL_o;
        LbYWT:
        $lh30S = is_array($XuStJ) ? $XuStJ : [$XuStJ];
        goto x0tdA;
        ldGir:
        PgmdJ:
        goto pt4Wb;
        FQoyo:
        return $lqRvU->whereIn('type', $lh30S);
        goto ldGir;
        h6alK:
        if ($F5PpY) {
            goto Cwy1W;
        }
        goto DJ321;
        x0tdA:
        if (empty($lh30S)) {
            goto i_JQD;
        }
        goto h6alK;
        DJ321:
        return $lqRvU->whereNotIn('type', $lh30S);
        goto MbURh;
        MbURh:
        goto PgmdJ;
        goto vJaT7;
        vJaT7:
        Cwy1W:
        goto FQoyo;
        ceL_o:
        return $lqRvU;
        goto Gvc8N;
        Gvc8N:
    }
}
