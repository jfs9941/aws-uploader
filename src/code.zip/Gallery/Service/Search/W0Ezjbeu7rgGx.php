<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class W0Ezjbeu7rgGx implements NB807wm4Ssu2n
{
    protected const xfeQg = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mwNoa6ZRSqv(Builder $sQ_dN, $RbDOp) : Builder
    {
        goto jXjW8;
        n4Dlu:
        $R5sZI = self::xfeQg[$VFb1V];
        goto qBx1z;
        qBx1z:
        return $sQ_dN->where($R5sZI, '=', true);
        goto RIfZv;
        mMQqu:
        if (!isset(self::xfeQg[$VFb1V])) {
            goto AJ8Gg;
        }
        goto n4Dlu;
        h1qWC:
        return $sQ_dN;
        goto jRBGY;
        RIfZv:
        AJ8Gg:
        goto h1qWC;
        jXjW8:
        $VFb1V = Str::lower($RbDOp);
        goto mMQqu;
        jRBGY:
    }
}
