<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
use src\Gallery\Service\Search\TjfQAwaWAJ4N9;
class RIz3xZFjFmOcn implements TjfQAwaWAJ4N9
{
    protected const aV0pJ = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mCaa0P7P2Ba(Builder $w31bN, $Yy1sZ) : Builder
    {
        goto R8kMk;
        wBYFk:
        $FAXAG = self::aV0pJ[$jVBfN];
        goto L7Zm6;
        L7Zm6:
        return $w31bN->where($FAXAG, '=', true);
        goto ZEoZr;
        R8kMk:
        $jVBfN = Str::lower($Yy1sZ);
        goto mcYLm;
        SvHc1:
        return $w31bN;
        goto eVIye;
        ZEoZr:
        LrFje:
        goto SvHc1;
        mcYLm:
        if (!isset(self::aV0pJ[$jVBfN])) {
            goto LrFje;
        }
        goto wBYFk;
        eVIye:
    }
}
