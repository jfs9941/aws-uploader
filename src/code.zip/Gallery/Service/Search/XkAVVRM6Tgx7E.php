<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\RhZfhgCaIG6De;
use Illuminate\Database\Eloquent\Builder;
class XkAVVRM6Tgx7E implements RhZfhgCaIG6De
{
    public function m1TxhmCMHnu(Builder $epE20, $yfgmD, $eI6__) : Builder
    {
        goto vXjuO;
        xr3_T:
        return $epE20;
        goto YkZss;
        n7nrA:
        v_Qoj:
        goto uTH3V;
        O5Xh5:
        goto v_Qoj;
        goto XCJag;
        Y2Ee9:
        return $epE20->whereIn('type', $YbhDI);
        goto n7nrA;
        vXjuO:
        $YbhDI = is_array($yfgmD) ? $yfgmD : [$yfgmD];
        goto MR7CC;
        xqii2:
        if ($eI6__) {
            goto VEWdg;
        }
        goto f837M;
        XCJag:
        VEWdg:
        goto Y2Ee9;
        MR7CC:
        if (empty($YbhDI)) {
            goto W38cq;
        }
        goto xqii2;
        f837M:
        return $epE20->whereNotIn('type', $YbhDI);
        goto O5Xh5;
        uTH3V:
        W38cq:
        goto xr3_T;
        YkZss:
    }
}
