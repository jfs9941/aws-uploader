<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\UT9e3SybDr4LH;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class WrF4Cfb2NiWXX implements UT9e3SybDr4LH
{
    protected const goOOR = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mycbA1e4uHY(Builder $uj0nf, $N4rlE, $OkrL2 = true) : Builder
    {
        goto Mibyp;
        Mibyp:
        $N5D4S = Str::lower($N4rlE);
        goto cPlyW;
        opTCC:
        prjIT:
        goto NWWki;
        J2VZe:
        $aP8_B = self::goOOR[$N5D4S];
        goto TcD4H;
        NWWki:
        return $uj0nf;
        goto Cv2Um;
        TcD4H:
        return $uj0nf->where($aP8_B, '=', $OkrL2);
        goto opTCC;
        cPlyW:
        if (!isset(self::goOOR[$N5D4S])) {
            goto prjIT;
        }
        goto J2VZe;
        Cv2Um:
    }
}
