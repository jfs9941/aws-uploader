<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\KAYXaENrCFXh2;
use Illuminate\Database\Eloquent\Builder;
class Zg3o7SzbapJ3c implements KAYXaENrCFXh2
{
    public function m3XdntuV3ms(Builder $lh42H, $MNFD8, $Dcoua) : Builder
    {
        goto tvsmQ;
        e5jfY:
        bcoz8:
        goto rGjSx;
        S10Xk:
        jFOWe:
        goto pNvZ6;
        XTVr3:
        goto k7kKO;
        goto e5jfY;
        L0RGz:
        return $lh42H->whereNotIn('type', $bEuMX);
        goto XTVr3;
        qjUen:
        if (empty($bEuMX)) {
            goto jFOWe;
        }
        goto jY12v;
        tvsmQ:
        $bEuMX = is_array($MNFD8) ? $MNFD8 : [$MNFD8];
        goto qjUen;
        lAk1B:
        k7kKO:
        goto S10Xk;
        rGjSx:
        return $lh42H->whereIn('type', $bEuMX);
        goto lAk1B;
        jY12v:
        if ($Dcoua) {
            goto bcoz8;
        }
        goto L0RGz;
        pNvZ6:
        return $lh42H;
        goto YzpI5;
        YzpI5:
    }
}
