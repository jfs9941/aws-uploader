<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\N64YJC4X4qDV3;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class VbZ1kzTgNjr5r implements N64YJC4X4qDV3
{
    protected const bHXn3 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mI8xJ0f7ytO(Builder $QqKs2, $aQKZQ, $ysdbd = true) : Builder
    {
        goto v4erJ;
        UiL0S:
        $j6Y4Y = self::bHXn3[$ktKmg];
        goto eEyT7;
        v4erJ:
        $ktKmg = Str::lower($aQKZQ);
        goto Aecb3;
        G8BcG:
        YTFib:
        goto k3Q8m;
        eEyT7:
        return $QqKs2->where($j6Y4Y, '=', $ysdbd);
        goto G8BcG;
        Aecb3:
        if (!isset(self::bHXn3[$ktKmg])) {
            goto YTFib;
        }
        goto UiL0S;
        k3Q8m:
        return $QqKs2;
        goto UXAir;
        UXAir:
    }
}
