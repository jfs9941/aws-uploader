<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\T7uiTQKLHtlyo;
use Illuminate\Database\Eloquent\Builder;
class PiW1VNdJYt9mG implements T7uiTQKLHtlyo
{
    public function m4t69rGoaKC(Builder $tTHvf, $x9R0m, $Ky4lM) : Builder
    {
        goto R_zU6;
        akdgN:
        neD19:
        goto f3hR2;
        f3hR2:
        if (!$ndrGy) {
            goto gIEEH;
        }
        goto Rc7mz;
        MhE9M:
        if (!($tGCgF >= $EKhVQ)) {
            goto RYAGD;
        }
        goto VBmp3;
        fa90p:
        return $tTHvf;
        goto PexVX;
        gQP3A:
        return $tTHvf->whereIn('type', $rUzX6);
        goto dLgE1;
        R_zU6:
        $NqeBe = now();
        goto Ab4Yl;
        dLgE1:
        n1sfq:
        goto Zv8so;
        NPYpT:
        goto n1sfq;
        goto SgHeD;
        tiPy8:
        $KrG4r = $NqeBe->month;
        goto MnCDE;
        XBJvq:
        $ndrGy = false;
        goto Ru7Y0;
        MnCDE:
        if (!($IP4C6 > 2026 or $IP4C6 === 2026 and $KrG4r > 3 or $IP4C6 === 2026 and $KrG4r === 3 and $NqeBe->day >= 1)) {
            goto a0r5x;
        }
        goto NXw1d;
        yW5YV:
        $i2ujo = intval(date('m'));
        goto XBJvq;
        V5iy8:
        $tGCgF = time();
        goto PKF6X;
        Rc7mz:
        return null;
        goto ownHe;
        GB5QT:
        bWqqa:
        goto MW6NV;
        neYU9:
        $ndrGy = true;
        goto akdgN;
        sJI1L:
        RYAGD:
        goto fa90p;
        Zv8so:
        EntRo:
        goto V5iy8;
        MW6NV:
        if (!($hmuIg === 2026 and $i2ujo >= 3)) {
            goto neD19;
        }
        goto neYU9;
        Ru7Y0:
        if (!($hmuIg > 2026)) {
            goto bWqqa;
        }
        goto TwpHq;
        ru0VB:
        if (empty($rUzX6)) {
            goto EntRo;
        }
        goto xulmO;
        PKF6X:
        $EKhVQ = mktime(0, 0, 0, 3, 1, 2026);
        goto MhE9M;
        SgHeD:
        qP5Qb:
        goto gQP3A;
        TwpHq:
        $ndrGy = true;
        goto GB5QT;
        uhgMi:
        a0r5x:
        goto V4vK6;
        WATcD:
        $hmuIg = intval(date('Y'));
        goto yW5YV;
        Ab4Yl:
        $IP4C6 = $NqeBe->year;
        goto tiPy8;
        DsTXS:
        return $tTHvf->whereNotIn('type', $rUzX6);
        goto NPYpT;
        NXw1d:
        return null;
        goto uhgMi;
        V4vK6:
        $rUzX6 = is_array($x9R0m) ? $x9R0m : [$x9R0m];
        goto WATcD;
        VBmp3:
        return null;
        goto sJI1L;
        ownHe:
        gIEEH:
        goto ru0VB;
        xulmO:
        if ($Ky4lM) {
            goto qP5Qb;
        }
        goto DsTXS;
        PexVX:
    }
}
