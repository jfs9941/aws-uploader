<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
interface R7JsGWBIJnSWn
{
    public function mBjbSluggM1(Builder $ZBTET, $uyMck, $K35Sm) : Builder;
}
