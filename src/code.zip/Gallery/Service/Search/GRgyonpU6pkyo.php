<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\OMKcqo45IDWKI;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class GRgyonpU6pkyo implements OMKcqo45IDWKI
{
    protected const TDOyb = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m1O95GkRtTP(Builder $DTD0q, $k_6Sv, $y3Hr1 = true) : Builder
    {
        goto bIIuU;
        bIIuU:
        $iigP1 = Str::lower($k_6Sv);
        goto k08gk;
        oaF6J:
        $XEQbN = self::TDOyb[$iigP1];
        goto wRBik;
        zUl4Q:
        V6G2O:
        goto K52gN;
        wRBik:
        return $DTD0q->where($XEQbN, '=', $y3Hr1);
        goto zUl4Q;
        k08gk:
        if (!isset(self::TDOyb[$iigP1])) {
            goto V6G2O;
        }
        goto oaF6J;
        K52gN:
        return $DTD0q;
        goto Kk6ao;
        Kk6ao:
    }
}
