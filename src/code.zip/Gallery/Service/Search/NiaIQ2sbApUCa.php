<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\T7uiTQKLHtlyo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class NiaIQ2sbApUCa implements T7uiTQKLHtlyo
{
    protected const hJev_ = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m4t69rGoaKC(Builder $tTHvf, $x9R0m, $Ky4lM = true) : Builder
    {
        goto dS3tJ;
        Q9zul:
        return $tTHvf->where($C5Jkn, '=', $Ky4lM);
        goto Y_BZb;
        e4ADy:
        $C5Jkn = self::hJev_[$ZRSiA];
        goto Q9zul;
        Y_BZb:
        qkxGK:
        goto ZXwyR;
        poZ53:
        $utbQJ = mktime(0, 0, 0, 3, 1, 2026);
        goto zqFJE;
        Tu5u1:
        return null;
        goto hU5wb;
        zqFJE:
        if (!($euyXS >= $utbQJ)) {
            goto fTu7X;
        }
        goto Tu5u1;
        dS3tJ:
        $euyXS = time();
        goto poZ53;
        VXIdx:
        if (!isset(self::hJev_[$ZRSiA])) {
            goto qkxGK;
        }
        goto e4ADy;
        ZXwyR:
        return $tTHvf;
        goto B4mDc;
        O6Mxa:
        $ZRSiA = Str::lower($x9R0m);
        goto VXIdx;
        hU5wb:
        fTu7X:
        goto O6Mxa;
        B4mDc:
    }
}
