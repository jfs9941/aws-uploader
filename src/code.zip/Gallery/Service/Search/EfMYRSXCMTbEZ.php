<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Yr6SLx1QUngeE;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class EfMYRSXCMTbEZ implements Yr6SLx1QUngeE
{
    protected const gfKFq = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mRdnFSEH1J0(Builder $LRBQB, $vNXze, $udpSm = true) : Builder
    {
        goto RzZDM;
        WzJzW:
        $uiHv9 = self::gfKFq[$IRSgh];
        goto SIuNL;
        MGSnv:
        AmAUR:
        goto cepxQ;
        SIuNL:
        return $LRBQB->where($uiHv9, '=', $udpSm);
        goto MGSnv;
        cepxQ:
        return $LRBQB;
        goto qyV7m;
        V3MoG:
        if (!isset(self::gfKFq[$IRSgh])) {
            goto AmAUR;
        }
        goto WzJzW;
        RzZDM:
        $IRSgh = Str::lower($vNXze);
        goto V3MoG;
        qyV7m:
    }
}
