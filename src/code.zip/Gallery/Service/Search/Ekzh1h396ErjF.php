<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\DG30LE44ILv0n;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Ekzh1h396ErjF implements DG30LE44ILv0n
{
    protected const wHqJ4 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mdds6J6B8b2(Builder $jeWVI, $E2wv5, $xc5J4 = true) : Builder
    {
        goto DrOE2;
        rvaGW:
        return $jeWVI;
        goto F8JMM;
        UiKLt:
        if (!isset(self::wHqJ4[$oOc2B])) {
            goto jqMD7;
        }
        goto KbADR;
        KbADR:
        $t3Uiy = self::wHqJ4[$oOc2B];
        goto q90ME;
        DrOE2:
        $oOc2B = Str::lower($E2wv5);
        goto UiKLt;
        uHm4x:
        jqMD7:
        goto rvaGW;
        q90ME:
        return $jeWVI->where($t3Uiy, '=', $xc5J4);
        goto uHm4x;
        F8JMM:
    }
}
