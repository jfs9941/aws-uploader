<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\QX45eBU594VwZ;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class D0POpDmw1880G implements QX45eBU594VwZ
{
    protected const GFjUF = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mQZXyrFVvse(Builder $ONlVY, $lm2dB, $DY3jQ = true) : Builder
    {
        goto dab0m;
        Jra9_:
        return $ONlVY->where($fjdJd, '=', $DY3jQ);
        goto b8V5Z;
        dab0m:
        $C1g6W = Str::lower($lm2dB);
        goto l73jx;
        b8V5Z:
        wm20H:
        goto x_R8S;
        x_R8S:
        return $ONlVY;
        goto QNxzq;
        l73jx:
        if (!isset(self::GFjUF[$C1g6W])) {
            goto wm20H;
        }
        goto Av0N2;
        Av0N2:
        $fjdJd = self::GFjUF[$C1g6W];
        goto Jra9_;
        QNxzq:
    }
}
