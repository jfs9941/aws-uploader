<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Tb6XnnkLG7dBG;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class D82QX6UHjIKzU implements Tb6XnnkLG7dBG
{
    protected const EkrX2 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mFqhJmqKFVV(Builder $Vcwqy, $DOwCj, $IbXqm = true) : Builder
    {
        goto tdl6M;
        hMmJ_:
        if (!isset(self::EkrX2[$C3lRP])) {
            goto gyDLO;
        }
        goto STc5Q;
        STc5Q:
        $j0lDV = self::EkrX2[$C3lRP];
        goto WK50X;
        XJOZn:
        gyDLO:
        goto eIsAg;
        WK50X:
        return $Vcwqy->where($j0lDV, '=', $IbXqm);
        goto XJOZn;
        tdl6M:
        $C3lRP = Str::lower($DOwCj);
        goto hMmJ_;
        eIsAg:
        return $Vcwqy;
        goto i8sMm;
        i8sMm:
    }
}
