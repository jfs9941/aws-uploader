<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\DG30LE44ILv0n;
use Illuminate\Database\Eloquent\Builder;
class CCWYqIZaRxQlG implements DG30LE44ILv0n
{
    public function mdds6J6B8b2(Builder $jeWVI, $E2wv5, $xc5J4) : Builder
    {
        goto YVA2M;
        j3ZNw:
        Hzi7V:
        goto aoEiX;
        oUGDE:
        if (empty($m8y_i)) {
            goto Hzi7V;
        }
        goto qz03V;
        L6v7m:
        goto NsxGU;
        goto VoTWC;
        qz03V:
        if ($xc5J4) {
            goto jUtO1;
        }
        goto BQejy;
        BQejy:
        return $jeWVI->whereNotIn('type', $m8y_i);
        goto L6v7m;
        my1dw:
        NsxGU:
        goto j3ZNw;
        aoEiX:
        return $jeWVI;
        goto GGEMa;
        kjvmL:
        return $jeWVI->whereIn('type', $m8y_i);
        goto my1dw;
        YVA2M:
        $m8y_i = is_array($E2wv5) ? $E2wv5 : [$E2wv5];
        goto oUGDE;
        VoTWC:
        jUtO1:
        goto kjvmL;
        GGEMa:
    }
}
