<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\I7VEXBdZYkDiA;
use Illuminate\Database\Eloquent\Builder;
class IvFG77u08uARl implements I7VEXBdZYkDiA
{
    public function mF5p1W7dbc2(Builder $hXUx3, $rQZNV, $kAphC) : Builder
    {
        goto ROsRT;
        VjCFl:
        if ($kAphC) {
            goto wptOR;
        }
        goto NW431;
        l15Ti:
        return $hXUx3->whereIn('type', $wdDmU);
        goto LZ2GF;
        AsUeI:
        return $hXUx3;
        goto wKwK5;
        Y_7sa:
        wptOR:
        goto l15Ti;
        NW431:
        return $hXUx3->whereNotIn('type', $wdDmU);
        goto XYFB6;
        LZ2GF:
        arjYd:
        goto z02uZ;
        ROsRT:
        $wdDmU = is_array($rQZNV) ? $rQZNV : [$rQZNV];
        goto oyZcz;
        oyZcz:
        if (empty($wdDmU)) {
            goto FRJsN;
        }
        goto VjCFl;
        z02uZ:
        FRJsN:
        goto AsUeI;
        XYFB6:
        goto arjYd;
        goto Y_7sa;
        wKwK5:
    }
}
