<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\WMuZEU3jPyMCd;
use Illuminate\Database\Eloquent\Builder;
class UUyrUNf3wErVT implements WMuZEU3jPyMCd
{
    public function mE2Vq87744N(Builder $rRtwf, $TBVQr, $dVkrU) : Builder
    {
        goto i4IZx;
        pCOHc:
        goto XgieF;
        goto rPkRp;
        rPkRp:
        WWwN4:
        goto BsgrT;
        i4IZx:
        $NXXqj = is_array($TBVQr) ? $TBVQr : [$TBVQr];
        goto SRWFZ;
        gUoME:
        return $rRtwf->whereNotIn('type', $NXXqj);
        goto pCOHc;
        SRWFZ:
        if (empty($NXXqj)) {
            goto nQ95E;
        }
        goto DepR4;
        i3FT2:
        XgieF:
        goto uoJcm;
        BsgrT:
        return $rRtwf->whereIn('type', $NXXqj);
        goto i3FT2;
        DepR4:
        if ($dVkrU) {
            goto WWwN4;
        }
        goto gUoME;
        kaBYw:
        return $rRtwf;
        goto Tpniz;
        uoJcm:
        nQ95E:
        goto kaBYw;
        Tpniz:
    }
}
