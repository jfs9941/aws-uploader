<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\R4hgN1ScCYWoI;
use Illuminate\Database\Eloquent\Builder;
class YwVtfmlvVg9tW implements R4hgN1ScCYWoI
{
    public function mYE8mYEP5g7(Builder $hY2O_, $u2t_L, $WDsXQ) : Builder
    {
        goto ixNqI;
        I7j7q:
        return $hY2O_->whereIn('type', $d58zG);
        goto ikWbM;
        G6coJ:
        EmzlW:
        goto u50sH;
        u50sH:
        return $hY2O_;
        goto lznEB;
        oA0FU:
        goto fQCGq;
        goto S76SG;
        S76SG:
        Z_gMS:
        goto I7j7q;
        rakwl:
        if ($WDsXQ) {
            goto Z_gMS;
        }
        goto pOJHC;
        w68gy:
        if (empty($d58zG)) {
            goto EmzlW;
        }
        goto rakwl;
        pOJHC:
        return $hY2O_->whereNotIn('type', $d58zG);
        goto oA0FU;
        ikWbM:
        fQCGq:
        goto G6coJ;
        ixNqI:
        $d58zG = is_array($u2t_L) ? $u2t_L : [$u2t_L];
        goto w68gy;
        lznEB:
    }
}
