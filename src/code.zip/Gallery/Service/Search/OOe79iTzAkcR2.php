<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Service\Search;

use backup\Gallery\Service\Search\R7JsGWBIJnSWn;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class OOe79iTzAkcR2 implements R7JsGWBIJnSWn
{
    protected const jVf4d = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mBjbSluggM1(Builder $ZBTET, $uyMck, $K35Sm = true) : Builder
    {
        goto UL1sH;
        BLuub:
        return $ZBTET;
        goto ZL1D3;
        ifEVO:
        return $ZBTET->where($M1uOG, '=', $K35Sm);
        goto Fht1h;
        r59HA:
        $M1uOG = self::jVf4d[$xspHI];
        goto ifEVO;
        UL1sH:
        $xspHI = Str::lower($uyMck);
        goto HzhT9;
        Fht1h:
        VWY7w:
        goto BLuub;
        HzhT9:
        if (!isset(self::jVf4d[$xspHI])) {
            goto VWY7w;
        }
        goto r59HA;
        ZL1D3:
    }
}
