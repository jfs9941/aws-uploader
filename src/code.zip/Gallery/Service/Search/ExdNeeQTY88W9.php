<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\WMuZEU3jPyMCd;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class ExdNeeQTY88W9 implements WMuZEU3jPyMCd
{
    protected const refV0 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mE2Vq87744N(Builder $rRtwf, $TBVQr, $dVkrU = true) : Builder
    {
        goto h2xgq;
        h2xgq:
        $vdBZE = Str::lower($TBVQr);
        goto iKXDr;
        B2p1S:
        return $rRtwf->where($yfJao, '=', $dVkrU);
        goto f6UM3;
        f6UM3:
        tFbh1:
        goto UBxOe;
        OTi32:
        $yfJao = self::refV0[$vdBZE];
        goto B2p1S;
        iKXDr:
        if (!isset(self::refV0[$vdBZE])) {
            goto tFbh1;
        }
        goto OTi32;
        UBxOe:
        return $rRtwf;
        goto how4E;
        how4E:
    }
}
