<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\ZeSwZkTbZnxYR;
use Illuminate\Database\Eloquent\Builder;
class CzZmY5lMQqwjy implements ZeSwZkTbZnxYR
{
    public function maAXfSUX2mK(Builder $iAUh7, $loD4e, $XD8SW) : Builder
    {
        goto eHT0V;
        UsAIT:
        return $iAUh7;
        goto I1SVq;
        dUPUI:
        return $iAUh7->whereNotIn('type', $Jb__T);
        goto pxVSP;
        sSOSe:
        if ($XD8SW) {
            goto bScuh;
        }
        goto dUPUI;
        pxVSP:
        goto CUla1;
        goto XREUp;
        eHT0V:
        $Jb__T = is_array($loD4e) ? $loD4e : [$loD4e];
        goto XuPZP;
        N5Ega:
        pfyUO:
        goto UsAIT;
        lWV8O:
        CUla1:
        goto N5Ega;
        XuPZP:
        if (empty($Jb__T)) {
            goto pfyUO;
        }
        goto sSOSe;
        XREUp:
        bScuh:
        goto ioWia;
        ioWia:
        return $iAUh7->whereIn('type', $Jb__T);
        goto lWV8O;
        I1SVq:
    }
}
