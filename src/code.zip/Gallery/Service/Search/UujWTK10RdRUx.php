<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\R4hgN1ScCYWoI;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class UujWTK10RdRUx implements R4hgN1ScCYWoI
{
    protected const OkC2N = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mYE8mYEP5g7(Builder $hY2O_, $u2t_L, $WDsXQ = true) : Builder
    {
        goto MUWNE;
        qIlwT:
        if (!isset(self::OkC2N[$S3rcT])) {
            goto EUByV;
        }
        goto ANrRU;
        MUWNE:
        $S3rcT = Str::lower($u2t_L);
        goto qIlwT;
        sjMLF:
        EUByV:
        goto k82Jc;
        k82Jc:
        return $hY2O_;
        goto vYvEm;
        ANrRU:
        $MknGz = self::OkC2N[$S3rcT];
        goto VjLTE;
        VjLTE:
        return $hY2O_->where($MknGz, '=', $WDsXQ);
        goto sjMLF;
        vYvEm:
    }
}
