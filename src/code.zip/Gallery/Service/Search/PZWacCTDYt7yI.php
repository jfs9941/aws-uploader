<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\EWz4UlANqCQvW;
use Illuminate\Database\Eloquent\Builder;
class PZWacCTDYt7yI implements EWz4UlANqCQvW
{
    public function mD0LEl18Mxz(Builder $gWJqy, $Xuk64, $Q5DjF) : Builder
    {
        goto QpCxX;
        BsTwV:
        LK4VA:
        goto zBfXh;
        XPmUk:
        if (empty($RDfBD)) {
            goto He7kk;
        }
        goto TgF0q;
        vMxQI:
        return $gWJqy->whereNotIn('type', $RDfBD);
        goto SNbgz;
        DaSsJ:
        return $gWJqy;
        goto T08Um;
        KAx0j:
        He7kk:
        goto DaSsJ;
        ULJY_:
        WSvRx:
        goto KAx0j;
        QpCxX:
        $RDfBD = is_array($Xuk64) ? $Xuk64 : [$Xuk64];
        goto XPmUk;
        TgF0q:
        if ($Q5DjF) {
            goto LK4VA;
        }
        goto vMxQI;
        zBfXh:
        return $gWJqy->whereIn('type', $RDfBD);
        goto ULJY_;
        SNbgz:
        goto WSvRx;
        goto BsTwV;
        T08Um:
    }
}
