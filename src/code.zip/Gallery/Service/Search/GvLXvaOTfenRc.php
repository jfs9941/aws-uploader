<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\UjCdlzMnPdCKC;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class GvLXvaOTfenRc implements UjCdlzMnPdCKC
{
    protected const Cwm1W = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function my0Gmz1GDju(Builder $tdgEg, $yvGQM, $t0rpw = true) : Builder
    {
        goto TxUCH;
        SIiU3:
        L16Lr:
        goto gVnyG;
        Sp0Mt:
        $wkUVB = self::Cwm1W[$D3M4s];
        goto NDXSy;
        NDXSy:
        return $tdgEg->where($wkUVB, '=', $t0rpw);
        goto SIiU3;
        Jq4iS:
        if (!isset(self::Cwm1W[$D3M4s])) {
            goto L16Lr;
        }
        goto Sp0Mt;
        gVnyG:
        return $tdgEg;
        goto mZwCM;
        TxUCH:
        $D3M4s = Str::lower($yvGQM);
        goto Jq4iS;
        mZwCM:
    }
}
