<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class Tob2eSkuGGQz1 implements AcpyJoTxMAGcI
{
    public function mCs88Lgj6p3(Builder $Eo278, $k7YY4, $Ctq8M) : Builder
    {
        goto xLNVm;
        OkLRF:
        return $Eo278;
        goto F0U1r;
        lAmKR:
        FZCIU:
        goto OkLRF;
        xhDX6:
        return $Eo278->whereIn('type', $FIaLA);
        goto lAmKR;
        jIt5p:
        if (empty($FIaLA)) {
            goto FZCIU;
        }
        goto xhDX6;
        xLNVm:
        $FIaLA = is_array($k7YY4) ? $k7YY4 : [$k7YY4];
        goto jIt5p;
        F0U1r:
    }
}
