<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\UT9e3SybDr4LH;
use Illuminate\Database\Eloquent\Builder;
class Jv0kIHCxA40hC implements UT9e3SybDr4LH
{
    public function mycbA1e4uHY(Builder $uj0nf, $N4rlE, $OkrL2) : Builder
    {
        goto DuzE7;
        XnKXo:
        X4tad:
        goto hy6IW;
        DuzE7:
        $gVNMP = is_array($N4rlE) ? $N4rlE : [$N4rlE];
        goto YZui5;
        G5GRG:
        return $uj0nf->whereNotIn('type', $gVNMP);
        goto wSCs9;
        hy6IW:
        return $uj0nf;
        goto dhq2X;
        jU7NK:
        lGWJ5:
        goto XnKXo;
        szR4T:
        return $uj0nf->whereIn('type', $gVNMP);
        goto jU7NK;
        wSCs9:
        goto lGWJ5;
        goto cnK5I;
        MnW14:
        if ($OkrL2) {
            goto TriFW;
        }
        goto G5GRG;
        cnK5I:
        TriFW:
        goto szR4T;
        YZui5:
        if (empty($gVNMP)) {
            goto X4tad;
        }
        goto MnW14;
        dhq2X:
    }
}
