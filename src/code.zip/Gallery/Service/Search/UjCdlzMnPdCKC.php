<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
interface UjCdlzMnPdCKC
{
    public function my0Gmz1GDju(Builder $tdgEg, $yvGQM, $t0rpw) : Builder;
}
