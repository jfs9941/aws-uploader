<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Gallery\Service\Search; use Illuminate\Database\Eloquent\Builder; use Illuminate\Support\Str; class OSPpGLJSjzkd4 implements FfMIbRjs3pcRg { protected const YZO9o = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop']; public function m5JT1gz5kvk(Builder $ExZXu, $C1Daw) : Builder { goto C970Y; j97Ze: ytBs5: goto zo2Zc; C970Y: $e0cSp = Str::lower($C1Daw); goto o31L4; MT0H3: $Y_avj = self::YZO9o[$e0cSp]; goto Dxn0M; o31L4: if (!isset(self::YZO9o[$e0cSp])) { goto ytBs5; } goto MT0H3; zo2Zc: return $ExZXu; goto Gbhgs; Dxn0M: return $ExZXu->where($Y_avj, '=', true); goto j97Ze; Gbhgs: } }
