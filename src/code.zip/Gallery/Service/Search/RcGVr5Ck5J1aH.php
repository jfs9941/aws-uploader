<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Service\Search;

use backup\Gallery\Service\Search\R7JsGWBIJnSWn;
use Illuminate\Database\Eloquent\Builder;
class RcGVr5Ck5J1aH implements R7JsGWBIJnSWn
{
    public function mBjbSluggM1(Builder $ZBTET, $uyMck, $K35Sm) : Builder
    {
        goto tlGBO;
        htRiE:
        return $ZBTET;
        goto gLtKv;
        mzque:
        qZk1i:
        goto htRiE;
        WWBK_:
        return $ZBTET->whereIn('type', $rNts1);
        goto mzque;
        GUu1B:
        if (empty($rNts1)) {
            goto qZk1i;
        }
        goto WWBK_;
        tlGBO:
        $rNts1 = is_array($uyMck) ? $uyMck : [$uyMck];
        goto GUu1B;
        gLtKv:
    }
}
