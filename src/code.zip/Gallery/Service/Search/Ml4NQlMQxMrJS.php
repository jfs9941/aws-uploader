<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Ml4NQlMQxMrJS implements I2CdekWrLhBZD
{
    protected const mag1S = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mwjFqbEzoUX(Builder $kZRaS, $Wvobe) : Builder
    {
        goto oh1wY;
        ZOQr1:
        return $kZRaS->where($L7BPA, '=', true);
        goto GRTru;
        Dca5j:
        $L7BPA = self::mag1S[$uEVN2];
        goto ZOQr1;
        d2pbN:
        return $kZRaS;
        goto D3xWm;
        wa7CN:
        if (!isset(self::mag1S[$uEVN2])) {
            goto sjzv1;
        }
        goto Dca5j;
        GRTru:
        sjzv1:
        goto d2pbN;
        oh1wY:
        $uEVN2 = Str::lower($Wvobe);
        goto wa7CN;
        D3xWm:
    }
}
