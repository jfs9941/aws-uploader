<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\LNw87H7GLupMB;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class OMnp0t4NNpovR implements LNw87H7GLupMB
{
    protected const F7lGr = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mi5VybsYpOe(Builder $W04kQ, $i4UR_, $iksry = true) : Builder
    {
        goto nFKus;
        wRpnA:
        if (!isset(self::F7lGr[$VAGs7])) {
            goto TN_BF;
        }
        goto d1J6J;
        nFKus:
        $VAGs7 = Str::lower($i4UR_);
        goto wRpnA;
        b7vys:
        return $W04kQ;
        goto n2btY;
        R5kWm:
        return $W04kQ->where($oxxIf, '=', $iksry);
        goto cZPvd;
        cZPvd:
        TN_BF:
        goto b7vys;
        d1J6J:
        $oxxIf = self::F7lGr[$VAGs7];
        goto R5kWm;
        n2btY:
    }
}
