<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Tp6tWcRRLRlQL implements YDoxP2uDkUDkB
{
    protected const tD0wD = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mMgITLYL4m6(Builder $YLIIQ, $B96vB, $O4pIA = true) : Builder
    {
        goto kH9UI;
        X3RIV:
        return $YLIIQ;
        goto zPh45;
        ejNtz:
        return $YLIIQ->where($e014A, '=', $O4pIA);
        goto gfFNs;
        AYiCG:
        if (!isset(self::tD0wD[$i_iQn])) {
            goto ckY5Q;
        }
        goto SNtEO;
        kH9UI:
        $i_iQn = Str::lower($B96vB);
        goto AYiCG;
        gfFNs:
        ckY5Q:
        goto X3RIV;
        SNtEO:
        $e014A = self::tD0wD[$i_iQn];
        goto ejNtz;
        zPh45:
    }
}
