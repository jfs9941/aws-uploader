<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\MPWCbkng8OKLM;
use Illuminate\Database\Eloquent\Builder;
class TIVYbXp0sJS8H implements MPWCbkng8OKLM
{
    public function mCN4GYcXb5m(Builder $usFjp, $UMuY4, $wBw5l) : Builder
    {
        goto Hv65u;
        SVxl1:
        MuDpi:
        goto S5qOh;
        y27Mm:
        B_AMW:
        goto RqM09;
        aKAJ8:
        Hic7v:
        goto SVxl1;
        Hv65u:
        $KJHFk = is_array($UMuY4) ? $UMuY4 : [$UMuY4];
        goto lYahH;
        RqM09:
        return $usFjp->whereIn('type', $KJHFk);
        goto aKAJ8;
        S5qOh:
        return $usFjp;
        goto nVHQj;
        lYahH:
        if (empty($KJHFk)) {
            goto MuDpi;
        }
        goto uSQgj;
        R5dZl:
        goto Hic7v;
        goto y27Mm;
        D20LN:
        return $usFjp->whereNotIn('type', $KJHFk);
        goto R5dZl;
        uSQgj:
        if ($wBw5l) {
            goto B_AMW;
        }
        goto D20LN;
        nVHQj:
    }
}
