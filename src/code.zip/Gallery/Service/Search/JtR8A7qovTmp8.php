<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\KrSr5QF5M5YfT;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class JtR8A7qovTmp8 implements KrSr5QF5M5YfT
{
    protected const aY6_Y = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mkZd1MmZovC(Builder $NLBFz, $TBVxN, $IYAcj = true) : Builder
    {
        goto SH7My;
        pt_dX:
        hiNEv:
        goto x9TEV;
        qJiw4:
        return $NLBFz->where($vgrcX, '=', $IYAcj);
        goto pt_dX;
        x9TEV:
        return $NLBFz;
        goto H2oAv;
        ukqOe:
        $vgrcX = self::aY6_Y[$z6bdk];
        goto qJiw4;
        Q2qW3:
        if (!isset(self::aY6_Y[$z6bdk])) {
            goto hiNEv;
        }
        goto ukqOe;
        SH7My:
        $z6bdk = Str::lower($TBVxN);
        goto Q2qW3;
        H2oAv:
    }
}
