<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Zb2RivTMNxeXN;
use Illuminate\Database\Eloquent\Builder;
class BkkDHyBQdQ5xM implements Zb2RivTMNxeXN
{
    public function mVPkONnVEF8(Builder $xGZ7p, $S9pFE, $hwwQ3) : Builder
    {
        goto iCjH8;
        Wn74G:
        goto Iwusg;
        goto c2PIK;
        sYsyJ:
        return $xGZ7p->whereNotIn('type', $FLhNd);
        goto Wn74G;
        UHv_6:
        return $xGZ7p->whereIn('type', $FLhNd);
        goto Ee0NN;
        s07C1:
        if (empty($FLhNd)) {
            goto OWpiO;
        }
        goto TrIo0;
        iCjH8:
        $FLhNd = is_array($S9pFE) ? $S9pFE : [$S9pFE];
        goto s07C1;
        TrIo0:
        if ($hwwQ3) {
            goto nqNjs;
        }
        goto sYsyJ;
        Ee0NN:
        Iwusg:
        goto ImcY6;
        ImcY6:
        OWpiO:
        goto DDV8I;
        DDV8I:
        return $xGZ7p;
        goto qWIUA;
        c2PIK:
        nqNjs:
        goto UHv_6;
        qWIUA:
    }
}
