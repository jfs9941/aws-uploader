<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\BIsPBMapjBOdd;
use Illuminate\Database\Eloquent\Builder;
class YfirkFAsa7exj implements BIsPBMapjBOdd
{
    public function mgFtO7lTSCM(Builder $eyDUn, $h1Rzt, $acr0Y) : Builder
    {
        goto hmTpk;
        Ty549:
        Y0815:
        goto cSA9c;
        cSA9c:
        return $eyDUn;
        goto Yx2wb;
        hmTpk:
        $xoAMW = is_array($h1Rzt) ? $h1Rzt : [$h1Rzt];
        goto ctiX_;
        ctiX_:
        if (empty($xoAMW)) {
            goto Y0815;
        }
        goto xVbc3;
        xVbc3:
        return $eyDUn->whereIn('type', $xoAMW);
        goto Ty549;
        Yx2wb:
    }
}
