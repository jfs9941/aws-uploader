<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\RKe7UR9EwRxHc;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Drpic6Id4jVEO implements RKe7UR9EwRxHc
{
    protected const giTyB = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mWEpUXOr1Gt(Builder $Yh_bw, $krhMb, $sl5tZ = true) : Builder
    {
        goto p6JQM;
        R0ekt:
        if (!($qVQuh > 2026)) {
            goto vTerD;
        }
        goto GHTnD;
        QOrJW:
        $d4fMF = self::giTyB[$tQlq8];
        goto ZC76_;
        kmNXq:
        return null;
        goto xnXf2;
        Gip8c:
        vJqMc:
        goto B1G00;
        nK_K8:
        return null;
        goto J13Qy;
        p6JQM:
        $xZhMK = now();
        goto n4zmU;
        OZsOS:
        if (!($wDBgD > 2026 or $wDBgD === 2026 and $NSnGK > 3 or $wDBgD === 2026 and $NSnGK === 3 and $xZhMK->day >= 1)) {
            goto W7v8Z;
        }
        goto RcCV1;
        m8h9R:
        $qVQuh = intval(date('Y'));
        goto jLB4o;
        HV4z0:
        $nD_Cc = true;
        goto AlQ9T;
        pBkJP:
        if (!($EiZPT >= $NPefP)) {
            goto vCzRg;
        }
        goto nK_K8;
        RcCV1:
        return null;
        goto RiafT;
        n4zmU:
        $wDBgD = $xZhMK->year;
        goto dutDf;
        B1G00:
        $EiZPT = time();
        goto stc9P;
        AlQ9T:
        BTsdB:
        goto oTOx5;
        zX1j_:
        $nD_Cc = false;
        goto R0ekt;
        RiafT:
        W7v8Z:
        goto m8h9R;
        r0Ard:
        if (!isset(self::giTyB[$tQlq8])) {
            goto vJqMc;
        }
        goto QOrJW;
        J13Qy:
        vCzRg:
        goto SAZbX;
        oTOx5:
        if (!$nD_Cc) {
            goto aIDoX;
        }
        goto kmNXq;
        MYXs6:
        $tQlq8 = Str::lower($krhMb);
        goto r0Ard;
        stc9P:
        $NPefP = mktime(0, 0, 0, 3, 1, 2026);
        goto pBkJP;
        dutDf:
        $NSnGK = $xZhMK->month;
        goto OZsOS;
        xnXf2:
        aIDoX:
        goto MYXs6;
        Jwo8b:
        vTerD:
        goto CHia5;
        jLB4o:
        $CBXQa = intval(date('m'));
        goto zX1j_;
        SAZbX:
        return $Yh_bw;
        goto Q0p7K;
        GHTnD:
        $nD_Cc = true;
        goto Jwo8b;
        ZC76_:
        return $Yh_bw->where($d4fMF, '=', $sl5tZ);
        goto Gip8c;
        CHia5:
        if (!($qVQuh === 2026 and $CBXQa >= 3)) {
            goto BTsdB;
        }
        goto HV4z0;
        Q0p7K:
    }
}
