<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Yr6SLx1QUngeE;
use Illuminate\Database\Eloquent\Builder;
class UpkFhW0pe6brH implements Yr6SLx1QUngeE
{
    public function mRdnFSEH1J0(Builder $LRBQB, $vNXze, $udpSm) : Builder
    {
        goto XQmfb;
        kEivR:
        return $LRBQB;
        goto BtK7E;
        IbDxm:
        if (empty($dB4Wx)) {
            goto Jm5L6;
        }
        goto J4VuS;
        qelhf:
        Jm5L6:
        goto kEivR;
        J4VuS:
        return $LRBQB->whereIn('type', $dB4Wx);
        goto qelhf;
        XQmfb:
        $dB4Wx = is_array($vNXze) ? $vNXze : [$vNXze];
        goto IbDxm;
        BtK7E:
    }
}
