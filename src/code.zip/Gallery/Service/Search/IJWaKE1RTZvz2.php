<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\ABSmOmN8jVjWw;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class IJWaKE1RTZvz2 implements ABSmOmN8jVjWw
{
    protected const cquDH = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mfEhyMpa5RD(Builder $b3eGW, $ha4uD, $Z5HHo = true) : Builder
    {
        goto eWomA;
        YIqmG:
        if (!isset(self::cquDH[$XWTeZ])) {
            goto AF8np;
        }
        goto aBegp;
        EqES8:
        return $b3eGW;
        goto UrFDP;
        aBegp:
        $eJOtH = self::cquDH[$XWTeZ];
        goto Mwwse;
        Mwwse:
        return $b3eGW->where($eJOtH, '=', $Z5HHo);
        goto uG9P3;
        uG9P3:
        AF8np:
        goto EqES8;
        eWomA:
        $XWTeZ = Str::lower($ha4uD);
        goto YIqmG;
        UrFDP:
    }
}
