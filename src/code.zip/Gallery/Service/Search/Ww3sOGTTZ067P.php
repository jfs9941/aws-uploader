<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Ww3sOGTTZ067P implements URI41WL8s209Q
{
    protected const lFbAX = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mvxFHVrMgPO(Builder $O81mB, $bzRbW) : Builder
    {
        goto GsQ7s;
        Ywwry:
        return $O81mB->where($XnRsd, '=', true);
        goto uIElx;
        uIElx:
        NLaHz:
        goto nw2LQ;
        nw2LQ:
        return $O81mB;
        goto nudBu;
        GsQ7s:
        $XEG_j = Str::lower($bzRbW);
        goto whUPB;
        A1wj1:
        $XnRsd = self::lFbAX[$XEG_j];
        goto Ywwry;
        whUPB:
        if (!isset(self::lFbAX[$XEG_j])) {
            goto NLaHz;
        }
        goto A1wj1;
        nudBu:
    }
}
