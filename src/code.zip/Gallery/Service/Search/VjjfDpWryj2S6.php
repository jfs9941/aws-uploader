<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\RhZfhgCaIG6De;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class VjjfDpWryj2S6 implements RhZfhgCaIG6De
{
    protected const HDSlO = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function m1TxhmCMHnu(Builder $epE20, $yfgmD, $eI6__ = true) : Builder
    {
        goto zOMqu;
        LTXJX:
        if (!isset(self::HDSlO[$ApFoB])) {
            goto ZvsWD;
        }
        goto cZ9xF;
        Du7T2:
        ZvsWD:
        goto ygj3E;
        nbWlb:
        return $epE20->where($Hh__I, '=', $eI6__);
        goto Du7T2;
        zOMqu:
        $ApFoB = Str::lower($yfgmD);
        goto LTXJX;
        ygj3E:
        return $epE20;
        goto hnywV;
        cZ9xF:
        $Hh__I = self::HDSlO[$ApFoB];
        goto nbWlb;
        hnywV:
    }
}
