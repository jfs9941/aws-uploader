<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\CoE0OKpXGBYe6;
use Illuminate\Database\Eloquent\Builder;
class GPplyEoQfYxYA implements CoE0OKpXGBYe6
{
    public function mEqthHbwbKg(Builder $No5E3, $NBDuO, $G9IlD) : Builder
    {
        goto llMG3;
        ATWyq:
        if (empty($AWWGu)) {
            goto WbSev;
        }
        goto hfjjv;
        hfjjv:
        if ($G9IlD) {
            goto a2VD1;
        }
        goto ZAoLJ;
        a5Xet:
        return null;
        goto d_rAZ;
        mLKKa:
        goto wqVem;
        goto bbpSG;
        kj97f:
        wqVem:
        goto ajipI;
        WUb7z:
        $kaD8D = mktime(0, 0, 0, 3, 1, 2026);
        goto FEKI5;
        ZAoLJ:
        return $No5E3->whereNotIn('type', $AWWGu);
        goto mLKKa;
        FEKI5:
        if (!($JpiVk >= $kaD8D)) {
            goto fZSBa;
        }
        goto a5Xet;
        vmM2Q:
        return $No5E3;
        goto a1ksS;
        d_rAZ:
        fZSBa:
        goto ATWyq;
        bbpSG:
        a2VD1:
        goto qu9P5;
        llMG3:
        $AWWGu = is_array($NBDuO) ? $NBDuO : [$NBDuO];
        goto UbhQM;
        ajipI:
        WbSev:
        goto vmM2Q;
        UbhQM:
        $JpiVk = time();
        goto WUb7z;
        qu9P5:
        return $No5E3->whereIn('type', $AWWGu);
        goto kj97f;
        a1ksS:
    }
}
