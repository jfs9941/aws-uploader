<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\U0EK8U2OUwM4T;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class AquEvtCyrVDsB implements U0EK8U2OUwM4T
{
    protected const HG4eH = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mAKe1GASNgN(Builder $lqRvU, $XuStJ, $F5PpY = true) : Builder
    {
        goto SgsFg;
        qKjdZ:
        return $lqRvU->where($a6V9M, '=', $F5PpY);
        goto aKiSG;
        SgsFg:
        $P0icZ = Str::lower($XuStJ);
        goto GTj9v;
        WWt72:
        return $lqRvU;
        goto EcMai;
        aKiSG:
        nHgH3:
        goto WWt72;
        cdg87:
        $a6V9M = self::HG4eH[$P0icZ];
        goto qKjdZ;
        GTj9v:
        if (!isset(self::HG4eH[$P0icZ])) {
            goto nHgH3;
        }
        goto cdg87;
        EcMai:
    }
}
