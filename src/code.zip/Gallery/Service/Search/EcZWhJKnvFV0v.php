<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class EcZWhJKnvFV0v implements I2CdekWrLhBZD
{
    public function mwjFqbEzoUX(Builder $kZRaS, $Wvobe) : Builder
    {
        goto FrPz1;
        FrPz1:
        $oQGWO = is_array($Wvobe) ? $Wvobe : [$Wvobe];
        goto UQhNu;
        K944X:
        V_e_F:
        goto iyjvA;
        wF5S1:
        return $kZRaS->whereIn('type', $oQGWO);
        goto K944X;
        UQhNu:
        if (empty($oQGWO)) {
            goto V_e_F;
        }
        goto wF5S1;
        iyjvA:
        return $kZRaS;
        goto Fzazt;
        Fzazt:
    }
}
