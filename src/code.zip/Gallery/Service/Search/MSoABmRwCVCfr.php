<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class MSoABmRwCVCfr implements OzMM4FQspdFDS
{
    protected const HRdjq = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mbbjz07Cd8J(Builder $DGS9z, $H0DFL, $POfQa = true) : Builder
    {
        goto vD5vk;
        c_S7r:
        $pncNN = self::HRdjq[$PSyQU];
        goto cOmYj;
        d8uAR:
        mqITC:
        goto qI7ya;
        vD5vk:
        $PSyQU = Str::lower($H0DFL);
        goto OQjGs;
        qI7ya:
        return $DGS9z;
        goto WnXPH;
        OQjGs:
        if (!isset(self::HRdjq[$PSyQU])) {
            goto mqITC;
        }
        goto c_S7r;
        cOmYj:
        return $DGS9z->where($pncNN, '=', $POfQa);
        goto d8uAR;
        WnXPH:
    }
}
