<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\B1WYSVwQbhFq4;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class SKKED1C9QLrr4 implements B1WYSVwQbhFq4
{
    protected const ZrUSY = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mBV6RLZw0Oj(Builder $ZdnGh, $D3lOV, $cgMxk = true) : Builder
    {
        goto w4Dyc;
        NDKZU:
        YQ0om:
        goto xJ8hg;
        w4Dyc:
        $WsEx6 = Str::lower($D3lOV);
        goto x3yPZ;
        x3yPZ:
        if (!isset(self::ZrUSY[$WsEx6])) {
            goto YQ0om;
        }
        goto nCLxl;
        nCLxl:
        $cZ80w = self::ZrUSY[$WsEx6];
        goto Kb4Fg;
        Kb4Fg:
        return $ZdnGh->where($cZ80w, '=', $cgMxk);
        goto NDKZU;
        xJ8hg:
        return $ZdnGh;
        goto SlL_b;
        SlL_b:
    }
}
