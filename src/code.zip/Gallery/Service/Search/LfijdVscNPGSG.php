<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
interface LfijdVscNPGSG
{
    public function mHA5L0j5xr1(Builder $DUZKC, $x6eQ6) : Builder;
}
