<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
interface IzAnV0kIIRlzN
{
    public function mJIhndXL12f(Builder $uXKnP, $LIlJV, $UEH2j) : Builder;
}
