<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\B1WYSVwQbhFq4;
use Illuminate\Database\Eloquent\Builder;
class MyVOVzLeB1K52 implements B1WYSVwQbhFq4
{
    public function mBV6RLZw0Oj(Builder $ZdnGh, $D3lOV, $cgMxk) : Builder
    {
        goto S3gMG;
        dnIFQ:
        if (empty($EXjqy)) {
            goto mG2oP;
        }
        goto idT3s;
        Db3My:
        rdHmJ:
        goto R1aN6;
        c0v5h:
        return $ZdnGh->whereNotIn('type', $EXjqy);
        goto i8Zth;
        S3gMG:
        $EXjqy = is_array($D3lOV) ? $D3lOV : [$D3lOV];
        goto dnIFQ;
        R1aN6:
        mG2oP:
        goto O_ZVQ;
        Smd6d:
        return $ZdnGh->whereIn('type', $EXjqy);
        goto Db3My;
        idT3s:
        if ($cgMxk) {
            goto GBh51;
        }
        goto c0v5h;
        O_ZVQ:
        return $ZdnGh;
        goto pFtFi;
        i8Zth:
        goto rdHmJ;
        goto vtXua;
        vtXua:
        GBh51:
        goto Smd6d;
        pFtFi:
    }
}
