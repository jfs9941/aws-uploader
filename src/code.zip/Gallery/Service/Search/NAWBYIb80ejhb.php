<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\Tb6XnnkLG7dBG;
use Illuminate\Database\Eloquent\Builder;
class NAWBYIb80ejhb implements Tb6XnnkLG7dBG
{
    public function mFqhJmqKFVV(Builder $Vcwqy, $DOwCj, $IbXqm) : Builder
    {
        goto OqENO;
        P8IV5:
        return $Vcwqy->whereNotIn('type', $xX7Yt);
        goto N_lQQ;
        L8TEF:
        if (empty($xX7Yt)) {
            goto B_7W2;
        }
        goto poqfE;
        Tn2Lj:
        B_7W2:
        goto eD0zs;
        poqfE:
        if ($IbXqm) {
            goto nA9SI;
        }
        goto P8IV5;
        KctL5:
        nA9SI:
        goto ksnpH;
        OqENO:
        $xX7Yt = is_array($DOwCj) ? $DOwCj : [$DOwCj];
        goto L8TEF;
        lv03A:
        YbBM3:
        goto Tn2Lj;
        ksnpH:
        return $Vcwqy->whereIn('type', $xX7Yt);
        goto lv03A;
        eD0zs:
        return $Vcwqy;
        goto h2SwN;
        N_lQQ:
        goto YbBM3;
        goto KctL5;
        h2SwN:
    }
}
