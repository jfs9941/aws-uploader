<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class GbFpezpTmLLx1 implements OzMM4FQspdFDS
{
    public function mbbjz07Cd8J(Builder $DGS9z, $H0DFL, $POfQa) : Builder
    {
        goto QrIAL;
        cc1yp:
        if (empty($IcSkJ)) {
            goto z9Xi6;
        }
        goto QfuSn;
        R66C4:
        z9Xi6:
        goto US8rx;
        QrIAL:
        $IcSkJ = is_array($H0DFL) ? $H0DFL : [$H0DFL];
        goto cc1yp;
        US8rx:
        return $DGS9z;
        goto Tk8hC;
        QfuSn:
        return $DGS9z->whereIn('type', $IcSkJ);
        goto R66C4;
        Tk8hC:
    }
}
