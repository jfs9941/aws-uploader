<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\DoQSKTJEY2pjy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class NIvYDIodTjO0O implements DoQSKTJEY2pjy
{
    protected const cSGJD = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mRTrEmrRYkC(Builder $kclx2, $iDWQ2, $E8b71 = true) : Builder
    {
        goto X_7LF;
        ScCzr:
        $vib3M = self::cSGJD[$ADQhi];
        goto I1VLX;
        JKZeh:
        QqE3V:
        goto LGgRl;
        B0TRB:
        if (!isset(self::cSGJD[$ADQhi])) {
            goto QqE3V;
        }
        goto ScCzr;
        X_7LF:
        $ADQhi = Str::lower($iDWQ2);
        goto B0TRB;
        I1VLX:
        return $kclx2->where($vib3M, '=', $E8b71);
        goto JKZeh;
        LGgRl:
        return $kclx2;
        goto O442r;
        O442r:
    }
}
