<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\BIsPBMapjBOdd;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class Ue5sQd192Jr9b implements BIsPBMapjBOdd
{
    protected const YFVV5 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mgFtO7lTSCM(Builder $eyDUn, $h1Rzt, $acr0Y = true) : Builder
    {
        goto M4MRQ;
        x38D0:
        return $eyDUn->where($qyNf2, '=', $acr0Y);
        goto S2Bhq;
        NUXWE:
        return $eyDUn;
        goto eEu2B;
        KNYIp:
        $qyNf2 = self::YFVV5[$g94Av];
        goto x38D0;
        DHhlr:
        if (!isset(self::YFVV5[$g94Av])) {
            goto IzLQE;
        }
        goto KNYIp;
        M4MRQ:
        $g94Av = Str::lower($h1Rzt);
        goto DHhlr;
        S2Bhq:
        IzLQE:
        goto NUXWE;
        eEu2B:
    }
}
