<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
interface TjfQAwaWAJ4N9
{
    public function mCaa0P7P2Ba(Builder $w31bN, $Yy1sZ) : Builder;
}
