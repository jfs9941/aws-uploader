<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\GJ442z8TMlzkg;
use Illuminate\Database\Eloquent\Builder;
class N0UHMO15T9Rh2 implements GJ442z8TMlzkg
{
    public function m0I9i9iKVnz(Builder $DmFxf, $ob_ZH, $X3RaZ) : Builder
    {
        goto kvMjF;
        kvMjF:
        $Tyo2G = is_array($ob_ZH) ? $ob_ZH : [$ob_ZH];
        goto wKNhS;
        IghE8:
        return $DmFxf->whereNotIn('type', $Tyo2G);
        goto ZRCIP;
        vRHRs:
        return $DmFxf;
        goto y0vtQ;
        Nvqy4:
        if ($X3RaZ) {
            goto uTonU;
        }
        goto IghE8;
        IyWHC:
        return $DmFxf->whereIn('type', $Tyo2G);
        goto S96Je;
        wKNhS:
        if (empty($Tyo2G)) {
            goto YX2cL;
        }
        goto Nvqy4;
        SXshS:
        YX2cL:
        goto vRHRs;
        S96Je:
        YqcbY:
        goto SXshS;
        LLzev:
        uTonU:
        goto IyWHC;
        ZRCIP:
        goto YqcbY;
        goto LLzev;
        y0vtQ:
    }
}
