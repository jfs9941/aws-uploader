<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class A1UJerd6tbvh8 implements X08LN7tFFGHa4
{
    protected const A9NIR = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mpCWvk5cF1i(Builder $PaniD, $z85MS, $Wnwak = true) : Builder
    {
        goto B8NMj;
        n8Nop:
        $YUQCQ = self::A9NIR[$oRdGy];
        goto e1ntb;
        K_tcp:
        if (!isset(self::A9NIR[$oRdGy])) {
            goto RyiYR;
        }
        goto n8Nop;
        B8NMj:
        $oRdGy = Str::lower($z85MS);
        goto K_tcp;
        e1ntb:
        return $PaniD->where($YUQCQ, '=', $Wnwak);
        goto iBuWT;
        iBuWT:
        RyiYR:
        goto a1Qsd;
        a1Qsd:
        return $PaniD;
        goto sZJYY;
        sZJYY:
    }
}
