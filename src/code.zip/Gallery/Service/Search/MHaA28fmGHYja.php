<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class MHaA28fmGHYja implements LfijdVscNPGSG
{
    public function mHA5L0j5xr1(Builder $DUZKC, $x6eQ6) : Builder
    {
        goto APxGr;
        pCCoO:
        return $DUZKC;
        goto m_wOC;
        AjE1c:
        if (empty($Zz3Mt)) {
            goto cSb2O;
        }
        goto LSZ1u;
        Ite_E:
        cSb2O:
        goto pCCoO;
        LSZ1u:
        return $DUZKC->whereIn('type', $Zz3Mt);
        goto Ite_E;
        APxGr:
        $Zz3Mt = is_array($x6eQ6) ? $x6eQ6 : [$x6eQ6];
        goto AjE1c;
        m_wOC:
    }
}
