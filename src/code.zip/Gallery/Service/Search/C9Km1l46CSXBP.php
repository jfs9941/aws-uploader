<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class C9Km1l46CSXBP implements LfijdVscNPGSG
{
    protected const H5v35 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mHA5L0j5xr1(Builder $DUZKC, $x6eQ6) : Builder
    {
        goto d22_f;
        KnOZm:
        yAvPW:
        goto XUr4U;
        a1wy2:
        return $DUZKC->where($C2NGo, '=', true);
        goto KnOZm;
        F7Fp2:
        $C2NGo = self::H5v35[$KWWVz];
        goto a1wy2;
        d22_f:
        $KWWVz = Str::lower($x6eQ6);
        goto w4y_p;
        XUr4U:
        return $DUZKC;
        goto wx8UV;
        w4y_p:
        if (!isset(self::H5v35[$KWWVz])) {
            goto yAvPW;
        }
        goto F7Fp2;
        wx8UV:
    }
}
