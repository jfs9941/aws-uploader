<?php

namespace Jfs\Gallery\Service\Search;
use Illuminate\Database\Eloquent\Builder;

class MediaTypeFilter implements FilterInterface
{
    public function apply(Builder $builder, $value): Builder
    {
        // The 'type' query param can be a single value or an array
        $requestedTypes = is_array($value) ? $value : [$value];
        if (!empty($requestedTypes)) {
            return $builder->whereIn('type', $requestedTypes);
        }

        return $builder;
    }
}
