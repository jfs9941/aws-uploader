<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class W9cSt4BS0KnOf implements NB807wm4Ssu2n
{
    public function mwNoa6ZRSqv(Builder $sQ_dN, $RbDOp) : Builder
    {
        goto xWElE;
        xWElE:
        $WNOL3 = is_array($RbDOp) ? $RbDOp : [$RbDOp];
        goto eYgqj;
        eYgqj:
        if (empty($WNOL3)) {
            goto rRG98;
        }
        goto REl8f;
        Tukbl:
        return $sQ_dN;
        goto YqFXy;
        REl8f:
        return $sQ_dN->whereIn('type', $WNOL3);
        goto PfHmj;
        PfHmj:
        rRG98:
        goto Tukbl;
        YqFXy:
    }
}
