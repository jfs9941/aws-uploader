<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Jfs\Gallery\Service\Search\LNw87H7GLupMB;
use Illuminate\Database\Eloquent\Builder;
class U80hycPd8vamj implements LNw87H7GLupMB
{
    public function mi5VybsYpOe(Builder $W04kQ, $i4UR_, $iksry) : Builder
    {
        goto hZxdW;
        CtB9A:
        lSwmN:
        goto ktKtH;
        hZxdW:
        $eRfBr = is_array($i4UR_) ? $i4UR_ : [$i4UR_];
        goto YhN1l;
        YhN1l:
        if (empty($eRfBr)) {
            goto DingT;
        }
        goto O146s;
        O146s:
        if ($iksry) {
            goto h3X8n;
        }
        goto mVrww;
        ktKtH:
        DingT:
        goto XURGC;
        K8xH8:
        h3X8n:
        goto Re5nb;
        Re5nb:
        return $W04kQ->whereIn('type', $eRfBr);
        goto CtB9A;
        mVrww:
        return $W04kQ->whereNotIn('type', $eRfBr);
        goto GLsH1;
        XURGC:
        return $W04kQ;
        goto Iw1lM;
        GLsH1:
        goto lSwmN;
        goto K8xH8;
        Iw1lM:
    }
}
