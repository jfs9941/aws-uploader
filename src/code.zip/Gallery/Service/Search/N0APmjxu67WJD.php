<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Gallery\Service\Search; use Illuminate\Database\Eloquent\Builder; class N0APmjxu67WJD implements FfMIbRjs3pcRg { public function m5JT1gz5kvk(Builder $ExZXu, $C1Daw) : Builder { goto b93dn; FXFi4: return $ExZXu; goto HexXy; QYO2x: return $ExZXu->whereIn('type', $JA5eB); goto fhnL2; fhnL2: bqRY9: goto FXFi4; ifJAR: if (empty($JA5eB)) { goto bqRY9; } goto QYO2x; b93dn: $JA5eB = is_array($C1Daw) ? $C1Daw : [$C1Daw]; goto ifJAR; HexXy: } }
