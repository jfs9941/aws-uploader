<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\L2lODn3G9Vz7O;
use Jfs\Gallery\Service\Search\ZeSwZkTbZnxYR;
use Jfs\Gallery\Service\Search\CzZmY5lMQqwjy;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class XcyJIYC6NQKkO implements GalleryCloudInterface
{
    private $qhffx = ['types' => CzZmY5lMQqwjy::class, 'category' => L2lODn3G9Vz7O::class];
    public function search(int $SSeWP, $pdrhA) : array
    {
        goto eNldA;
        b60Hs:
        if (!in_array('approved', $gk4o8['types'] ?? [])) {
            goto fpsiW;
        }
        goto p1VjT;
        eNldA:
        list($gk4o8, $lvhXw, $q6JOo, $CpRqw, $NAUBt) = $pdrhA;
        goto TWZPl;
        d0qoW:
        $dSoHf = $this->m0EdaFWYWEa($gk4o8, $lvhXw, $dSoHf);
        goto T1K64;
        p1VjT:
        $dSoHf = $dSoHf->where('status', '=', StatusEnum::P_f3U);
        goto rrMt0;
        vzI_3:
        if (!$NAUBt) {
            goto wLNYz;
        }
        goto b60Hs;
        rrMt0:
        $gk4o8['types'] = array_filter($gk4o8['types'], function ($cw5ro) {
            return $cw5ro !== 'approved';
        });
        goto JEByR;
        gzzlW:
        return ['page' => $q6JOo, 'total' => $F6Rr5, 'item_per_page' => $CpRqw, 'data' => $HgLpI];
        goto wV0n9;
        T1K64:
        $F6Rr5 = DB::query()->fromSub($dSoHf, 't')->selectRaw('count(*) as total')->first()->total;
        goto LRR2J;
        TWZPl:
        $dSoHf = Cloud::query()->where('user_id', $SSeWP);
        goto vzI_3;
        f_hau:
        $dSoHf = $dSoHf->where('status', '=', StatusEnum::P_f3U);
        goto lKZkd;
        LRR2J:
        $HgLpI = $dSoHf->with('media')->orderBy('created_at', 'desc')->limit($CpRqw)->offset(($q6JOo - 1) * $CpRqw)->get()->filter(function (Cloud $ncGa7) {
            return $ncGa7->getMedia() != null;
        })->map(function (Cloud $ncGa7) {
            goto t4fZ7;
            lAj2B:
            $rtMM2 = $P82oP->getView();
            goto tlpFq;
            tlpFq:
            return array_merge($rtMM2, ['type' => $ncGa7->getAttribute('type'), 'status' => $ncGa7->getAttribute('status')]);
            goto QlD_j;
            t4fZ7:
            $P82oP = $ncGa7->getMedia();
            goto lAj2B;
            QlD_j:
        })->values();
        goto gzzlW;
        oLrcn:
        wLNYz:
        goto f_hau;
        Wzlv8:
        goto sFzUF;
        goto oLrcn;
        lKZkd:
        sFzUF:
        goto d0qoW;
        JEByR:
        fpsiW:
        goto Wzlv8;
        wV0n9:
    }
    private function m0EdaFWYWEa(array $gk4o8, array $GxMca, Builder $iAUh7) : Builder
    {
        goto HsBM4;
        HsBM4:
        foreach ($this->qhffx as $VoQj9 => $aZyf_) {
            goto ZvFIw;
            ddlyR:
            NJzE3:
            goto aMU93;
            joAE7:
            if (!isset($GxMca[$VoQj9])) {
                goto SPTjd;
            }
            goto R29Ya;
            IrfGK:
            goto RMRIc;
            goto YKfCC;
            ZvFIw:
            if (isset($gk4o8[$VoQj9]) && !isset($GxMca[$VoQj9])) {
                goto YYdln;
            }
            goto joAE7;
            tdlho:
            $QTMiM = new $aZyf_();
            goto T3r9Y;
            R29Ya:
            $QTMiM = new $aZyf_();
            goto UlO4l;
            UlO4l:
            $QTMiM->maAXfSUX2mK($iAUh7, $GxMca[$VoQj9], false);
            goto XenA8;
            YKfCC:
            YYdln:
            goto tdlho;
            XenA8:
            SPTjd:
            goto IrfGK;
            CDhRH:
            RMRIc:
            goto ddlyR;
            T3r9Y:
            $QTMiM->maAXfSUX2mK($iAUh7, $gk4o8[$VoQj9], true);
            goto CDhRH;
            aMU93:
        }
        goto Jp1Yf;
        Jp1Yf:
        ZkXDK:
        goto JzGtw;
        JzGtw:
        return $iAUh7;
        goto BezY7;
        BezY7:
    }
    public function saveItems(array $ESeUN) : void
    {
        foreach ($ESeUN as $YEF57) {
            goto Vm8rW;
            tcQ2Q:
            DSaUb:
            goto eKEPX;
            F3nQW:
            Cloud::m0su91aQW5m($Q8IO8, StatusEnum::ENaqo);
            goto tcQ2Q;
            eKEPX:
            rf885:
            goto Av7dZ;
            fhyFW:
            $Q8IO8 = Media::find($YEF57);
            goto F3nQW;
            Vm8rW:
            $ncGa7 = Cloud::find($YEF57);
            goto MRJZs;
            MRJZs:
            if ($ncGa7) {
                goto DSaUb;
            }
            goto fhyFW;
            Av7dZ:
        }
        GgfSV:
    }
    public function delete(string $InHEz) : void
    {
        $ncGa7 = Cloud::findOrFail($InHEz);
        $ncGa7->delete();
    }
}
