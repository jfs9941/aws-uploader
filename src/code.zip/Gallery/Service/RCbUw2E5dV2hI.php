<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\JtR8A7qovTmp8;
use Jfs\Gallery\Service\Search\KrSr5QF5M5YfT;
use Jfs\Gallery\Service\Search\ZqfnpKQZEg5l4;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class RCbUw2E5dV2hI implements GalleryCloudInterface
{
    private $iJlWN = ['types' => ZqfnpKQZEg5l4::class, 'category' => JtR8A7qovTmp8::class];
    public function search(int $VrvwN, $XUHFJ) : array
    {
        goto Wsg3V;
        LTWEk:
        $nDRV0 = DB::query()->fromSub($nIjI4, 't')->selectRaw('count(*) as total')->first()->total;
        goto edrtj;
        Wsg3V:
        list($gpfCs, $g0_s2, $J5ag7, $KjFD2, $Os7DF) = $XUHFJ;
        goto VwUgX;
        edrtj:
        $fNMAX = $nIjI4->with('media')->orderBy('created_at', 'desc')->limit($KjFD2)->offset(($J5ag7 - 1) * $KjFD2)->get()->filter(function (Cloud $kjrz1) {
            return $kjrz1->getMedia() != null;
        })->map(function (Cloud $kjrz1) {
            goto oVnPk;
            YPWS2:
            return array_merge($hhZ0v, ['type' => $kjrz1->getAttribute('type'), 'status' => $kjrz1->getAttribute('status')]);
            goto ZJQkv;
            oVnPk:
            $tzY18 = $kjrz1->getMedia();
            goto AvjVc;
            AvjVc:
            $hhZ0v = $tzY18->getView();
            goto YPWS2;
            ZJQkv:
        })->values();
        goto pldY3;
        pldY3:
        return ['page' => $J5ag7, 'total' => $nDRV0, 'item_per_page' => $KjFD2, 'data' => $fNMAX];
        goto Gz0sz;
        WyaSi:
        IHjrf:
        goto kGbvx;
        lTgLt:
        $nIjI4 = $nIjI4->where('status', '=', StatusEnum::GPHhd);
        goto tbPOk;
        VwUgX:
        $nIjI4 = Cloud::query()->where('user_id', $VrvwN);
        goto SukB8;
        hfL2L:
        ry8K3:
        goto BcsFr;
        kGbvx:
        $nIjI4 = $this->m84M0n4qEuj($gpfCs, $g0_s2, $nIjI4);
        goto LTWEk;
        tbPOk:
        $gpfCs['types'] = array_filter($gpfCs['types'], function ($tCZTv) {
            return $tCZTv !== 'approved';
        });
        goto hfL2L;
        cu31Z:
        $nIjI4 = $nIjI4->where('status', '=', StatusEnum::GPHhd);
        goto WyaSi;
        GMacI:
        if (!in_array('approved', $gpfCs['types'] ?? [])) {
            goto ry8K3;
        }
        goto lTgLt;
        dDqfN:
        xnaD5:
        goto cu31Z;
        BcsFr:
        goto IHjrf;
        goto dDqfN;
        SukB8:
        if (!$Os7DF) {
            goto xnaD5;
        }
        goto GMacI;
        Gz0sz:
    }
    private function m84M0n4qEuj(array $gpfCs, array $s7rfd, Builder $NLBFz) : Builder
    {
        goto CIC9S;
        D5NBA:
        return $NLBFz;
        goto SnOtr;
        oXOjX:
        RLKrM:
        goto D5NBA;
        CIC9S:
        foreach ($this->iJlWN as $XqeG1 => $jXzVQ) {
            goto OMdwI;
            CktOX:
            $mnQ6M = new $jXzVQ();
            goto efCvF;
            HUy0q:
            YLr0F:
            goto TIOS7;
            TIOS7:
            goto hBc_0;
            goto yKJob;
            OMdwI:
            if (isset($gpfCs[$XqeG1]) && !isset($s7rfd[$XqeG1])) {
                goto Sh3ia;
            }
            goto wueNE;
            xvTnu:
            $mnQ6M->mkZd1MmZovC($NLBFz, $s7rfd[$XqeG1], false);
            goto HUy0q;
            efCvF:
            $mnQ6M->mkZd1MmZovC($NLBFz, $gpfCs[$XqeG1], true);
            goto KCEeG;
            AWiP_:
            uqVJG:
            goto nZ0AK;
            yKJob:
            Sh3ia:
            goto CktOX;
            L0KM4:
            $mnQ6M = new $jXzVQ();
            goto xvTnu;
            wueNE:
            if (!isset($s7rfd[$XqeG1])) {
                goto YLr0F;
            }
            goto L0KM4;
            KCEeG:
            hBc_0:
            goto AWiP_;
            nZ0AK:
        }
        goto oXOjX;
        SnOtr:
    }
    public function saveItems(array $VmVOF) : void
    {
        foreach ($VmVOF as $z620p) {
            goto bhfSj;
            bhfSj:
            $kjrz1 = Cloud::find($z620p);
            goto cKmLl;
            cKmLl:
            if ($kjrz1) {
                goto vNx2y;
            }
            goto PVE4d;
            PVE4d:
            $tL_UH = Media::find($z620p);
            goto VgyG3;
            VgyG3:
            Cloud::m9Vez0sT79n($tL_UH, StatusEnum::gO2HS);
            goto IJ0L9;
            IJ0L9:
            vNx2y:
            goto nFjBI;
            nFjBI:
            or06H:
            goto YoIUJ;
            YoIUJ:
        }
        RHsNA:
    }
    public function delete(string $SEOXv) : void
    {
        $kjrz1 = Cloud::findOrFail($SEOXv);
        $kjrz1->delete();
    }
}
