<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Gallery\Service\Search\W0Ezjbeu7rgGx;
use Jfs\Gallery\Service\Search\NB807wm4Ssu2n;
use Jfs\Gallery\Service\Search\W9cSt4BS0KnOf;
use Illuminate\Database\Eloquent\Builder;
final class JBNI3mZItZh1y implements GalleryCloudInterface
{
    private $N8gQl = ['types' => W9cSt4BS0KnOf::class, 'category' => W0Ezjbeu7rgGx::class];
    public function search(int $qA0_A, $UjnAD) : array
    {
        goto bm3j1;
        qiMCq:
        dsPiB:
        goto tssW5;
        kFgdR:
        if (!in_array('approved', $z8seE['types'] ?? [])) {
            goto dsPiB;
        }
        goto c1k9d;
        IW0Ns:
        $k7Y7P = $ZkGOz->with('media')->orderBy('created_at', 'desc')->limit($HdksO)->offset(($APvCQ - 1) * $HdksO)->get()->filter(function (Cloud $SAf9N) {
            return $SAf9N->getMedia() != null;
        })->map(function (Cloud $SAf9N) {
            goto vwtNj;
            sKdzL:
            return array_merge($ORPyM, ['type' => $SAf9N->getAttribute('type'), 'status' => $SAf9N->getAttribute('status')]);
            goto uyGst;
            V8k54:
            $ORPyM = $Mhc38->getView();
            goto sKdzL;
            vwtNj:
            $Mhc38 = $SAf9N->getMedia();
            goto V8k54;
            uyGst:
        })->values();
        goto v44zH;
        Q9gbR:
        $ZkGOz = Cloud::query()->where('user_id', $qA0_A);
        goto Z6t81;
        mxrgO:
        k2Mdj:
        goto K1ole;
        Z6t81:
        if (!$AnUUI) {
            goto k2Mdj;
        }
        goto kFgdR;
        K1ole:
        $ZkGOz = $ZkGOz->where('status', '=', StatusEnum::z20Ze);
        goto pIae2;
        bm3j1:
        list($z8seE, $APvCQ, $HdksO, $AnUUI) = $UjnAD;
        goto Q9gbR;
        KDW6a:
        $g5Tbx = DB::query()->fromSub($ZkGOz, 't')->selectRaw('count(*) as total')->first()->total;
        goto IW0Ns;
        tssW5:
        goto di5Rj;
        goto mxrgO;
        pIae2:
        di5Rj:
        goto zJL8q;
        bBqHb:
        $z8seE['types'] = array_filter($z8seE['types'], function ($DgQ6B) {
            return $DgQ6B !== 'approved';
        });
        goto qiMCq;
        v44zH:
        return ['page' => $APvCQ, 'total' => $g5Tbx, 'item_per_page' => $HdksO, 'data' => $k7Y7P];
        goto iszfF;
        c1k9d:
        $ZkGOz = $ZkGOz->where('status', '=', StatusEnum::z20Ze);
        goto bBqHb;
        zJL8q:
        $ZkGOz = $this->makheXUepwy($z8seE, $ZkGOz);
        goto KDW6a;
        iszfF:
    }
    private function makheXUepwy(array $z8seE, Builder $sQ_dN) : Builder
    {
        goto wsTJY;
        TleLC:
        JmDdN:
        goto jJeNm;
        wsTJY:
        foreach ($this->N8gQl as $Fu1mk => $J2iC3) {
            goto TQuFh;
            iOEdN:
            EA0av:
            goto pY6LS;
            TQuFh:
            if (!isset($z8seE[$Fu1mk])) {
                goto WnD67;
            }
            goto emwwh;
            yJmq4:
            $ifnap->mwNoa6ZRSqv($sQ_dN, $z8seE[$Fu1mk]);
            goto XiKqf;
            emwwh:
            $ifnap = new $J2iC3();
            goto yJmq4;
            XiKqf:
            WnD67:
            goto iOEdN;
            pY6LS:
        }
        goto TleLC;
        jJeNm:
        return $sQ_dN;
        goto GJ0T_;
        GJ0T_:
    }
    public function saveItems(array $rT0w4) : void
    {
        foreach ($rT0w4 as $QxvEM) {
            goto dXmT3;
            LCwXw:
            x9oeR:
            goto mBRpk;
            rA6QW:
            $TeAou = Media::find($QxvEM);
            goto wLqOp;
            dXmT3:
            $SAf9N = Cloud::find($QxvEM);
            goto GdFoI;
            wLqOp:
            Cloud::miJAJTITkf4($TeAou, StatusEnum::gVhD3);
            goto Y1cdK;
            GdFoI:
            if ($SAf9N) {
                goto Og1Yk;
            }
            goto rA6QW;
            Y1cdK:
            Og1Yk:
            goto LCwXw;
            mBRpk:
        }
        ZqGKA:
    }
    public function delete(string $UcmDx) : void
    {
        $SAf9N = Cloud::findOrFail($UcmDx);
        $SAf9N->delete();
    }
}
