<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Gallery\Service\Search\UbTkXFmntj2Qa;
use Jfs\Gallery\Service\Search\RpnWWXOL0yQRr;
use Jfs\Gallery\Service\Search\L9AoHVLaG9UV7;
use Illuminate\Database\Eloquent\Builder;
final class IEKt3iFXuaQha implements GalleryCloudInterface
{
    private $BPs2q = ['types' => L9AoHVLaG9UV7::class, 'category' => UbTkXFmntj2Qa::class];
    public function search(int $W7h0k, $cH1x_) : array
    {
        goto D2ysi;
        QITo0:
        $KDvuZ = DB::query()->fromSub($DKN7p, 't')->selectRaw('count(*) as total')->first()->total;
        goto x3vhg;
        rslVj:
        Wu5ct:
        goto R56uR;
        cuVAG:
        $GWgkf['types'] = array_filter($GWgkf['types'], function ($HndI2) {
            return $HndI2 !== 'approved';
        });
        goto CEvIH;
        hz0FL:
        PhBjU:
        goto J1Nzo;
        sUcxw:
        if (!in_array('approved', $GWgkf['types'] ?? [])) {
            goto mpDzx;
        }
        goto MT8s3;
        J1Nzo:
        $DKN7p = $this->miegBK5EAO1($GWgkf, $s8iY5, $DKN7p);
        goto QITo0;
        MT8s3:
        $DKN7p = $DKN7p->where('status', '=', StatusEnum::f2t50);
        goto cuVAG;
        x3vhg:
        $hp3yb = $DKN7p->with('media')->orderBy('created_at', 'desc')->limit($fkmre)->offset(($FKC7d - 1) * $fkmre)->get()->filter(function (Cloud $kMK51) {
            return $kMK51->getMedia() != null;
        })->map(function (Cloud $kMK51) {
            goto FKUuP;
            FKUuP:
            $DzZNO = $kMK51->getMedia();
            goto GK5OB;
            GK5OB:
            $BxSpy = $DzZNO->getView();
            goto Yyj5E;
            Yyj5E:
            return array_merge($BxSpy, ['type' => $kMK51->getAttribute('type'), 'status' => $kMK51->getAttribute('status')]);
            goto iu5Zb;
            iu5Zb:
        })->values();
        goto Vq6j5;
        Vq6j5:
        return ['page' => $FKC7d, 'total' => $KDvuZ, 'item_per_page' => $fkmre, 'data' => $hp3yb];
        goto OfyBE;
        hJepG:
        $DKN7p = Cloud::query()->where('user_id', $W7h0k);
        goto amryT;
        R56uR:
        $DKN7p = $DKN7p->where('status', '=', StatusEnum::f2t50);
        goto hz0FL;
        amryT:
        if (!$j3ecc) {
            goto Wu5ct;
        }
        goto sUcxw;
        D2ysi:
        list($GWgkf, $s8iY5, $FKC7d, $fkmre, $j3ecc) = $cH1x_;
        goto hJepG;
        igu57:
        goto PhBjU;
        goto rslVj;
        CEvIH:
        mpDzx:
        goto igu57;
        OfyBE:
    }
    private function miegBK5EAO1(array $GWgkf, array $Y90CU, Builder $mn4R2) : Builder
    {
        goto YpG19;
        nkVbi:
        return $mn4R2;
        goto hTMNq;
        YpG19:
        foreach ($this->BPs2q as $evaEJ => $E_ThA) {
            goto Jql9p;
            QqlWh:
            $Asxvi->mNgEfKNqXAz($mn4R2, $Y90CU[$evaEJ], false);
            goto kwkJI;
            Jql9p:
            if (isset($GWgkf[$evaEJ]) && !isset($Y90CU[$evaEJ])) {
                goto RoOK9;
            }
            goto J21YY;
            wKmUi:
            kJlaj:
            goto cxq2k;
            kwkJI:
            mYeeN:
            goto kiOvY;
            G7Rv4:
            J4wKM:
            goto wKmUi;
            J21YY:
            if (!isset($Y90CU[$evaEJ])) {
                goto mYeeN;
            }
            goto TLyOx;
            tHq0z:
            $Asxvi->mNgEfKNqXAz($mn4R2, $GWgkf[$evaEJ]);
            goto G7Rv4;
            J0lPL:
            $Asxvi = new $E_ThA();
            goto tHq0z;
            TLyOx:
            $Asxvi = new $E_ThA();
            goto QqlWh;
            WP171:
            RoOK9:
            goto J0lPL;
            kiOvY:
            goto J4wKM;
            goto WP171;
            cxq2k:
        }
        goto JmDWM;
        JmDWM:
        H4jSy:
        goto nkVbi;
        hTMNq:
    }
    public function saveItems(array $a75IP) : void
    {
        foreach ($a75IP as $VZzWw) {
            goto L33OW;
            Y_UzD:
            if ($kMK51) {
                goto DnOMb;
            }
            goto JGppp;
            L33OW:
            $kMK51 = Cloud::find($VZzWw);
            goto Y_UzD;
            JGppp:
            $cS_yX = Media::find($VZzWw);
            goto Hr2Eb;
            wtdjY:
            DnOMb:
            goto f5Nxn;
            Hr2Eb:
            Cloud::mWSX4o3yTkk($cS_yX, StatusEnum::ZEkza);
            goto wtdjY;
            f5Nxn:
            vyjgf:
            goto QLTEk;
            QLTEk:
        }
        OJYiy:
    }
    public function delete(string $S6xyJ) : void
    {
        $kMK51 = Cloud::findOrFail($S6xyJ);
        $kMK51->delete();
    }
}
