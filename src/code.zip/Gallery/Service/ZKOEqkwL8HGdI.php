<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Z9SoOJNgVHyyC;
use Jfs\Gallery\Service\Search\MPWCbkng8OKLM;
use Jfs\Gallery\Service\Search\TIVYbXp0sJS8H;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class ZKOEqkwL8HGdI implements GalleryCloudInterface
{
    private $j31f8 = ['types' => TIVYbXp0sJS8H::class, 'category' => Z9SoOJNgVHyyC::class];
    public function search(int $IQBpu, $EU06K) : array
    {
        goto HqjlG;
        Bw0EA:
        if (!$gz1db) {
            goto Yd7mJ;
        }
        goto GQGtN;
        GQGtN:
        if (!in_array('approved', $DezzJ['types'] ?? [])) {
            goto GlEw7;
        }
        goto xZ2_z;
        c9d66:
        $Sqbk5 = $this->mg0EL8zYmRY($DezzJ, $KtWIf, $Sqbk5);
        goto fGNAd;
        ABfPD:
        return ['page' => $AXMJl, 'total' => $lyaDl, 'item_per_page' => $fo55s, 'data' => $lgyD_];
        goto JEPCZ;
        Mwt2u:
        $DezzJ['types'] = array_filter($DezzJ['types'], function ($N9K0D) {
            return $N9K0D !== 'approved';
        });
        goto n49Af;
        xZ2_z:
        $Sqbk5 = $Sqbk5->where('status', '=', StatusEnum::FtKxT);
        goto Mwt2u;
        XO9w9:
        $Sqbk5 = Cloud::query()->where('user_id', $IQBpu);
        goto Bw0EA;
        ZbKs7:
        $Sqbk5 = $Sqbk5->where('status', '=', StatusEnum::FtKxT);
        goto f1Q92;
        go4lL:
        Yd7mJ:
        goto ZbKs7;
        IVlHQ:
        $lgyD_ = $Sqbk5->with('media')->orderBy('created_at', 'desc')->limit($fo55s)->offset(($AXMJl - 1) * $fo55s)->get()->filter(function (Cloud $C4gcS) {
            return $C4gcS->getMedia() != null;
        })->map(function (Cloud $C4gcS) {
            goto NPzAn;
            H3HNZ:
            $XVLvQ = $m5Vy1->getView();
            goto WrfSY;
            WrfSY:
            return array_merge($XVLvQ, ['type' => $C4gcS->getAttribute('type'), 'status' => $C4gcS->getAttribute('status')]);
            goto EJ2PR;
            NPzAn:
            $m5Vy1 = $C4gcS->getMedia();
            goto H3HNZ;
            EJ2PR:
        })->values();
        goto ABfPD;
        HqjlG:
        list($DezzJ, $KtWIf, $AXMJl, $fo55s, $gz1db) = $EU06K;
        goto XO9w9;
        f1Q92:
        VcrHD:
        goto c9d66;
        fGNAd:
        $lyaDl = DB::query()->fromSub($Sqbk5, 't')->selectRaw('count(*) as total')->first()->total;
        goto IVlHQ;
        pHUeN:
        goto VcrHD;
        goto go4lL;
        n49Af:
        GlEw7:
        goto pHUeN;
        JEPCZ:
    }
    private function mg0EL8zYmRY(array $DezzJ, array $ZuD5_, Builder $usFjp) : Builder
    {
        goto aht7A;
        aht7A:
        foreach ($this->j31f8 as $zMFIB => $Nljja) {
            goto MlYOB;
            rv0TZ:
            $WjEbt = new $Nljja();
            goto DKROI;
            i6Oqn:
            AcD1O:
            goto rv0TZ;
            qfw0e:
            HJK0I:
            goto KRKFu;
            DKROI:
            $WjEbt->mCN4GYcXb5m($usFjp, $DezzJ[$zMFIB]);
            goto BRPtT;
            KRKFu:
            goto iF8s_;
            goto i6Oqn;
            OLV5I:
            if (!isset($ZuD5_[$zMFIB])) {
                goto HJK0I;
            }
            goto Cz6qp;
            Cz6qp:
            $WjEbt = new $Nljja();
            goto MA4B9;
            MlYOB:
            if (isset($DezzJ[$zMFIB]) && !isset($ZuD5_[$zMFIB])) {
                goto AcD1O;
            }
            goto OLV5I;
            MA4B9:
            $WjEbt->mCN4GYcXb5m($usFjp, $ZuD5_[$zMFIB], false);
            goto qfw0e;
            ZP3fW:
            VukI6:
            goto fN5Pw;
            BRPtT:
            iF8s_:
            goto ZP3fW;
            fN5Pw:
        }
        goto LOvgl;
        LOvgl:
        UVGnu:
        goto cNlbF;
        cNlbF:
        return $usFjp;
        goto jkuob;
        jkuob:
    }
    public function saveItems(array $x4Dm6) : void
    {
        foreach ($x4Dm6 as $clm2Y) {
            goto NGSBe;
            E3Z0q:
            P6VuE:
            goto dTdEp;
            hYVjf:
            Cloud::mhEdtGbCRFm($Eawqf, StatusEnum::QHdvo);
            goto E3Z0q;
            UST3w:
            $Eawqf = Media::find($clm2Y);
            goto hYVjf;
            dTdEp:
            H9Dzk:
            goto d4g_r;
            PtKQz:
            if ($C4gcS) {
                goto P6VuE;
            }
            goto UST3w;
            NGSBe:
            $C4gcS = Cloud::find($clm2Y);
            goto PtKQz;
            d4g_r:
        }
        Lsiu8:
    }
    public function delete(string $B5uQ4) : void
    {
        $C4gcS = Cloud::findOrFail($B5uQ4);
        $C4gcS->delete();
    }
}
