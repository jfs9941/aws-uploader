<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\VjjfDpWryj2S6;
use Jfs\Gallery\Service\Search\RhZfhgCaIG6De;
use Jfs\Gallery\Service\Search\XkAVVRM6Tgx7E;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class KBPvzEE1A4UOK implements GalleryCloudInterface
{
    private $wtpNF = ['types' => XkAVVRM6Tgx7E::class, 'category' => VjjfDpWryj2S6::class];
    public function search(int $vfxUB, $D6wM_) : array
    {
        goto nbsij;
        xdyEt:
        $GinZl = $this->mNsMFlf0fkG($vgocg, $hojBG, $GinZl);
        goto gol26;
        VhMrm:
        $vgocg['types'] = array_filter($vgocg['types'], function ($Tx5SO) {
            return $Tx5SO !== 'approved';
        });
        goto z9KZy;
        xZFtj:
        A1Z60:
        goto DPV9G;
        DPV9G:
        $GinZl = $GinZl->where('status', '=', StatusEnum::VpdjV);
        goto O_FFa;
        gol26:
        $p77iA = DB::query()->fromSub($GinZl, 't')->selectRaw('count(*) as total')->first()->total;
        goto oHSt7;
        UjwJ1:
        return ['page' => $uwmK7, 'total' => $p77iA, 'item_per_page' => $kFszC, 'data' => $EF1_E];
        goto SR4iY;
        XRetx:
        $GinZl = Cloud::query()->where('user_id', $vfxUB);
        goto C7Qcq;
        oHSt7:
        $EF1_E = $GinZl->with('media')->orderBy('created_at', 'desc')->limit($kFszC)->offset(($uwmK7 - 1) * $kFszC)->get()->filter(function (Cloud $jremf) {
            return $jremf->getMedia() != null;
        })->map(function (Cloud $jremf) {
            goto VYrBj;
            VYrBj:
            $mDwO7 = $jremf->getMedia();
            goto oQMxW;
            oQMxW:
            $jlkIR = $mDwO7->getView();
            goto r1Vxa;
            r1Vxa:
            return array_merge($jlkIR, ['type' => $jremf->getAttribute('type'), 'status' => $jremf->getAttribute('status')]);
            goto VlGU4;
            VlGU4:
        })->values();
        goto UjwJ1;
        IgVEq:
        goto u857s;
        goto xZFtj;
        C7Qcq:
        if (!$ItRnn) {
            goto A1Z60;
        }
        goto SPdzY;
        z9KZy:
        lYmhH:
        goto IgVEq;
        SPdzY:
        if (!in_array('approved', $vgocg['types'] ?? [])) {
            goto lYmhH;
        }
        goto vCY9M;
        vCY9M:
        $GinZl = $GinZl->where('status', '=', StatusEnum::VpdjV);
        goto VhMrm;
        O_FFa:
        u857s:
        goto xdyEt;
        nbsij:
        list($vgocg, $hojBG, $uwmK7, $kFszC, $ItRnn) = $D6wM_;
        goto XRetx;
        SR4iY:
    }
    private function mNsMFlf0fkG(array $vgocg, array $oSwwZ, Builder $epE20) : Builder
    {
        goto N2kp2;
        pOgdY:
        return $epE20;
        goto b4M5U;
        N2kp2:
        foreach ($this->wtpNF as $CFr3e => $xX5aY) {
            goto KVXp5;
            Pr7yq:
            R5v9X:
            goto E2v1U;
            URnVs:
            z4Ayz:
            goto YaIUW;
            utsHi:
            if (!isset($oSwwZ[$CFr3e])) {
                goto MbLNB;
            }
            goto g2PuZ;
            pYkfw:
            $t1jg5->m1TxhmCMHnu($epE20, $oSwwZ[$CFr3e], false);
            goto RL_0A;
            g2PuZ:
            $t1jg5 = new $xX5aY();
            goto pYkfw;
            KVXp5:
            if (isset($vgocg[$CFr3e]) && !isset($oSwwZ[$CFr3e])) {
                goto z4Ayz;
            }
            goto utsHi;
            YaIUW:
            $t1jg5 = new $xX5aY();
            goto tAr5s;
            gLfcJ:
            goto snYKK;
            goto URnVs;
            RL_0A:
            MbLNB:
            goto gLfcJ;
            tAr5s:
            $t1jg5->m1TxhmCMHnu($epE20, $vgocg[$CFr3e]);
            goto EgR2p;
            EgR2p:
            snYKK:
            goto Pr7yq;
            E2v1U:
        }
        goto EGOg8;
        EGOg8:
        FNewb:
        goto pOgdY;
        b4M5U:
    }
    public function saveItems(array $MjLiu) : void
    {
        foreach ($MjLiu as $ZQzpf) {
            goto oN3vA;
            q992M:
            MRiX8:
            goto TISOx;
            mOb_a:
            Cloud::mLAamkfxWka($VJuHB, StatusEnum::R_SBt);
            goto cB_rU;
            KAxQd:
            if ($jremf) {
                goto N12Oo;
            }
            goto RgAeB;
            cB_rU:
            N12Oo:
            goto q992M;
            RgAeB:
            $VJuHB = Media::find($ZQzpf);
            goto mOb_a;
            oN3vA:
            $jremf = Cloud::find($ZQzpf);
            goto KAxQd;
            TISOx:
        }
        PnjCP:
    }
    public function delete(string $Brk87) : void
    {
        $jremf = Cloud::findOrFail($Brk87);
        $jremf->delete();
    }
}
