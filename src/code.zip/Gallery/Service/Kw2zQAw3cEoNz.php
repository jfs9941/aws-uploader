<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\FNpzFbz7BSuZ2;
use Jfs\Gallery\Service\Search\KAYXaENrCFXh2;
use Jfs\Gallery\Service\Search\Zg3o7SzbapJ3c;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class Kw2zQAw3cEoNz implements GalleryCloudInterface
{
    private $dkw49 = ['types' => Zg3o7SzbapJ3c::class, 'category' => FNpzFbz7BSuZ2::class];
    public function search(int $Ps6ez, $T1Q11) : array
    {
        goto KDsc8;
        nS4Ml:
        $zflX4 = $zflX4->where('status', '=', StatusEnum::JHunj);
        goto xyv8p;
        C0VSW:
        $zflX4 = $this->mugYt7qvvMY($cym74, $NVJzb, $zflX4);
        goto cAALp;
        C52Ct:
        $zflX4 = Cloud::query()->where('user_id', $Ps6ez);
        goto XeNnA;
        rOh66:
        if (!in_array('approved', $cym74['types'] ?? [])) {
            goto IPmTa;
        }
        goto nS4Ml;
        YP2A0:
        $vnyRY = $zflX4->with('media')->orderBy('created_at', 'desc')->limit($GZF5u)->offset(($wT7bO - 1) * $GZF5u)->get()->filter(function (Cloud $wnxPt) {
            return $wnxPt->getMedia() != null;
        })->map(function (Cloud $wnxPt) {
            goto rhn3h;
            yRazx:
            $L5ARZ = $wiCE2->getView();
            goto sMdLE;
            rhn3h:
            $wiCE2 = $wnxPt->getMedia();
            goto yRazx;
            sMdLE:
            return array_merge($L5ARZ, ['type' => $wnxPt->getAttribute('type'), 'status' => $wnxPt->getAttribute('status')]);
            goto SrR_3;
            SrR_3:
        })->values();
        goto Al5Ar;
        cAALp:
        $CG1zD = DB::query()->fromSub($zflX4, 't')->selectRaw('count(*) as total')->first()->total;
        goto YP2A0;
        UJstg:
        goto fDsML;
        goto atrL7;
        I7xd8:
        IPmTa:
        goto UJstg;
        KDsc8:
        list($cym74, $NVJzb, $wT7bO, $GZF5u, $NCVKY) = $T1Q11;
        goto C52Ct;
        XeNnA:
        if (!$NCVKY) {
            goto vJo7u;
        }
        goto rOh66;
        atrL7:
        vJo7u:
        goto qD_i6;
        xyv8p:
        $cym74['types'] = array_filter($cym74['types'], function ($ds03H) {
            return $ds03H !== 'approved';
        });
        goto I7xd8;
        qD_i6:
        $zflX4 = $zflX4->where('status', '=', StatusEnum::JHunj);
        goto NPohl;
        NPohl:
        fDsML:
        goto C0VSW;
        Al5Ar:
        return ['page' => $wT7bO, 'total' => $CG1zD, 'item_per_page' => $GZF5u, 'data' => $vnyRY];
        goto t3WO2;
        t3WO2:
    }
    private function mugYt7qvvMY(array $cym74, array $j6N0R, Builder $lh42H) : Builder
    {
        goto GDbEM;
        W_Dbk:
        return $lh42H;
        goto TdlGJ;
        nwRq9:
        UtB2J:
        goto W_Dbk;
        GDbEM:
        foreach ($this->dkw49 as $lhk1u => $fKvX2) {
            goto Yk_ag;
            dVCK8:
            SiIC8:
            goto NESXs;
            Yxjk5:
            rBFuS:
            goto l9chC;
            GgFAT:
            if (!isset($j6N0R[$lhk1u])) {
                goto rBFuS;
            }
            goto ArHg7;
            Yk_ag:
            if (isset($cym74[$lhk1u]) && !isset($j6N0R[$lhk1u])) {
                goto zMb1X;
            }
            goto GgFAT;
            N3UM3:
            $scPax->m3XdntuV3ms($lh42H, $j6N0R[$lhk1u], false);
            goto Yxjk5;
            ArHg7:
            $scPax = new $fKvX2();
            goto N3UM3;
            l9chC:
            goto R5n0q;
            goto mfCEd;
            mfCEd:
            zMb1X:
            goto fQ91b;
            fQ91b:
            $scPax = new $fKvX2();
            goto jWpES;
            xttGm:
            R5n0q:
            goto dVCK8;
            jWpES:
            $scPax->m3XdntuV3ms($lh42H, $cym74[$lhk1u], true);
            goto xttGm;
            NESXs:
        }
        goto nwRq9;
        TdlGJ:
    }
    public function saveItems(array $cxSC5) : void
    {
        foreach ($cxSC5 as $dV9QE) {
            goto qDAF5;
            xf0d3:
            Z4KkZ:
            goto KMTZF;
            o8qyv:
            $b55fD = Media::find($dV9QE);
            goto EsRP2;
            qDAF5:
            $wnxPt = Cloud::find($dV9QE);
            goto CddWY;
            KMTZF:
            PdDLi:
            goto Gq72r;
            EsRP2:
            Cloud::mA57fqzccfA($b55fD, StatusEnum::sGCAQ);
            goto xf0d3;
            CddWY:
            if ($wnxPt) {
                goto Z4KkZ;
            }
            goto o8qyv;
            Gq72r:
        }
        TjZ6t:
    }
    public function delete(string $J_scC) : void
    {
        $wnxPt = Cloud::findOrFail($J_scC);
        $wnxPt->delete();
    }
}
