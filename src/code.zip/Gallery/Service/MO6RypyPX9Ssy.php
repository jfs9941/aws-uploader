<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Gallery\Service\Search\C9Km1l46CSXBP;
use Jfs\Gallery\Service\Search\LfijdVscNPGSG;
use Jfs\Gallery\Service\Search\MHaA28fmGHYja;
use Illuminate\Database\Eloquent\Builder;
final class MO6RypyPX9Ssy implements GalleryCloudInterface
{
    private $BnEv9 = ['types' => MHaA28fmGHYja::class, 'category' => C9Km1l46CSXBP::class];
    public function search(int $efA5J, $R90x9) : array
    {
        goto DQacY;
        yZh1M:
        C1Pn1:
        goto naZ3L;
        naZ3L:
        $C22HK = $C22HK->where('status', '=', StatusEnum::icH3y);
        goto D0ASP;
        Wlb7r:
        $C22HK = $C22HK->where('status', '=', StatusEnum::icH3y);
        goto R9hGs;
        NiT99:
        $C22HK = Cloud::query()->where('user_id', $efA5J);
        goto WR4w_;
        LOQKz:
        $aarcz = DB::query()->fromSub($C22HK, 't')->selectRaw('count(*) as total')->first()->total;
        goto aMkso;
        WR4w_:
        if (!$eV3Zd) {
            goto C1Pn1;
        }
        goto tnZbP;
        JCdbX:
        RKS7J:
        goto cQZqn;
        DQacY:
        list($oOLvG, $CiTvH, $Q_B6G, $eV3Zd) = $R90x9;
        goto NiT99;
        K9h2P:
        $C22HK = $this->mZADuia5GUB($oOLvG, $C22HK);
        goto LOQKz;
        tnZbP:
        if (!in_array('approved', $oOLvG['types'] ?? [])) {
            goto RKS7J;
        }
        goto Wlb7r;
        DFHZL:
        return ['page' => $CiTvH, 'total' => $aarcz, 'item_per_page' => $Q_B6G, 'data' => $rWjSy];
        goto etKeH;
        aMkso:
        $rWjSy = $C22HK->with('media')->orderBy('created_at', 'desc')->limit($Q_B6G)->offset(($CiTvH - 1) * $Q_B6G)->get()->filter(function (Cloud $KBT5q) {
            return $KBT5q->getMedia() != null;
        })->map(function (Cloud $KBT5q) {
            goto efdDS;
            efdDS:
            $Y6vHu = $KBT5q->getMedia();
            goto GlcMs;
            GlcMs:
            $Th0F7 = $Y6vHu->getView();
            goto ijDjt;
            ijDjt:
            return array_merge($Th0F7, ['type' => $KBT5q->getAttribute('type'), 'status' => $KBT5q->getAttribute('status')]);
            goto rcbRT;
            rcbRT:
        })->values();
        goto DFHZL;
        R9hGs:
        $oOLvG['types'] = array_filter($oOLvG['types'], function ($KHVrT) {
            return $KHVrT !== 'approved';
        });
        goto JCdbX;
        D0ASP:
        iq8kB:
        goto K9h2P;
        cQZqn:
        goto iq8kB;
        goto yZh1M;
        etKeH:
    }
    private function mZADuia5GUB(array $oOLvG, Builder $DUZKC) : Builder
    {
        goto Ih8Sj;
        YMRad:
        return $DUZKC;
        goto nuHg0;
        Ih8Sj:
        foreach ($this->BnEv9 as $Li7PR => $pcL0g) {
            goto W0w1D;
            nSpo_:
            $G_asm->mHA5L0j5xr1($DUZKC, $oOLvG[$Li7PR]);
            goto G1g0g;
            G1g0g:
            rv1Gc:
            goto DpPEC;
            DpPEC:
            cqppE:
            goto xLqr_;
            yqg61:
            $G_asm = new $pcL0g();
            goto nSpo_;
            W0w1D:
            if (!isset($oOLvG[$Li7PR])) {
                goto rv1Gc;
            }
            goto yqg61;
            xLqr_:
        }
        goto KLNZS;
        KLNZS:
        RJIBh:
        goto YMRad;
        nuHg0:
    }
    public function saveItems(array $dAtw8) : void
    {
        foreach ($dAtw8 as $oYtbp) {
            goto L1Rv1;
            lWucI:
            nIP06:
            goto FEs4N;
            mTwJX:
            Cloud::mjDBU0YLrFQ($FR_h8, StatusEnum::qSDdA);
            goto LtPr0;
            L1Rv1:
            $KBT5q = Cloud::find($oYtbp);
            goto bbLIb;
            bbLIb:
            if ($KBT5q) {
                goto yhkzm;
            }
            goto SiiG8;
            SiiG8:
            $FR_h8 = Media::find($oYtbp);
            goto mTwJX;
            LtPr0:
            yhkzm:
            goto lWucI;
            FEs4N:
        }
        QF0uN:
    }
    public function delete(string $Qu08p) : void
    {
        $KBT5q = Cloud::findOrFail($Qu08p);
        $KBT5q->delete();
    }
}
