<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Ekzh1h396ErjF;
use Jfs\Gallery\Service\Search\DG30LE44ILv0n;
use Jfs\Gallery\Service\Search\CCWYqIZaRxQlG;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class Qzdrz0OzvrtjS implements GalleryCloudInterface
{
    private $wldcU = ['types' => CCWYqIZaRxQlG::class, 'category' => Ekzh1h396ErjF::class];
    public function search(int $EiW4T, $Ao3wv) : array
    {
        goto if7tI;
        Qe75x:
        $lzChf = $lzChf->where('status', '=', StatusEnum::ihbzS);
        goto bpupi;
        if7tI:
        list($E4azD, $lGtxR, $ILoS5, $cOlDT, $Qd37g) = $Ao3wv;
        goto pPBlV;
        VcbZV:
        $JETM_ = DB::query()->fromSub($lzChf, 't')->selectRaw('count(*) as total')->first()->total;
        goto xUV4A;
        j2fYc:
        mReZN:
        goto Lz4WS;
        Z77m5:
        sLs_I:
        goto ZEn0d;
        ZEn0d:
        goto mReZN;
        goto SXmdN;
        pWDl2:
        $lzChf = $lzChf->where('status', '=', StatusEnum::ihbzS);
        goto j2fYc;
        pPBlV:
        $lzChf = Cloud::query()->where('user_id', $EiW4T);
        goto W85rT;
        W85rT:
        if (!$Qd37g) {
            goto NIPxr;
        }
        goto kZtp_;
        xUV4A:
        $TXgv0 = $lzChf->with('media')->orderBy('created_at', 'desc')->limit($cOlDT)->offset(($ILoS5 - 1) * $cOlDT)->get()->filter(function (Cloud $lK1w0) {
            return $lK1w0->getMedia() != null;
        })->map(function (Cloud $lK1w0) {
            goto aag8X;
            bjWOi:
            $M7zOf = $p0I5F->getView();
            goto BWPeP;
            BWPeP:
            return array_merge($M7zOf, ['type' => $lK1w0->getAttribute('type'), 'status' => $lK1w0->getAttribute('status')]);
            goto pnkBe;
            aag8X:
            $p0I5F = $lK1w0->getMedia();
            goto bjWOi;
            pnkBe:
        })->values();
        goto vuCuN;
        Lz4WS:
        $lzChf = $this->mQDpBl7qTkZ($E4azD, $lGtxR, $lzChf);
        goto VcbZV;
        kZtp_:
        if (!in_array('approved', $E4azD['types'] ?? [])) {
            goto sLs_I;
        }
        goto Qe75x;
        SXmdN:
        NIPxr:
        goto pWDl2;
        vuCuN:
        return ['page' => $ILoS5, 'total' => $JETM_, 'item_per_page' => $cOlDT, 'data' => $TXgv0];
        goto Qx7AL;
        bpupi:
        $E4azD['types'] = array_filter($E4azD['types'], function ($Nkkok) {
            return $Nkkok !== 'approved';
        });
        goto Z77m5;
        Qx7AL:
    }
    private function mQDpBl7qTkZ(array $E4azD, array $CkmOW, Builder $jeWVI) : Builder
    {
        goto JORyW;
        V0S2d:
        F4CNV:
        goto Vl9gm;
        Vl9gm:
        return $jeWVI;
        goto v3TYT;
        JORyW:
        foreach ($this->wldcU as $XopUK => $rH_UR) {
            goto ccobc;
            GydOK:
            $yPeZi->mdds6J6B8b2($jeWVI, $CkmOW[$XopUK], false);
            goto j9fdv;
            j9fdv:
            xS8OA:
            goto PpoPv;
            JGt7h:
            $yPeZi->mdds6J6B8b2($jeWVI, $E4azD[$XopUK], true);
            goto AnCVg;
            PpoPv:
            goto gpTrK;
            goto y67_l;
            VhCoB:
            $yPeZi = new $rH_UR();
            goto JGt7h;
            eOsci:
            if (!isset($CkmOW[$XopUK])) {
                goto xS8OA;
            }
            goto PrGZQ;
            PrGZQ:
            $yPeZi = new $rH_UR();
            goto GydOK;
            AnCVg:
            gpTrK:
            goto sqOSv;
            y67_l:
            rKEB2:
            goto VhCoB;
            sqOSv:
            icWgy:
            goto jc9J2;
            ccobc:
            if (isset($E4azD[$XopUK]) && !isset($CkmOW[$XopUK])) {
                goto rKEB2;
            }
            goto eOsci;
            jc9J2:
        }
        goto V0S2d;
        v3TYT:
    }
    public function saveItems(array $oGWmx) : void
    {
        foreach ($oGWmx as $hFrf7) {
            goto Wwv_2;
            bQXxF:
            if ($lK1w0) {
                goto V3Dhh;
            }
            goto fqIUW;
            rJPVX:
            Cloud::mpetjj3h1GV($gGdNk, StatusEnum::LNqVs);
            goto mCYj2;
            mCYj2:
            V3Dhh:
            goto JrpDQ;
            Wwv_2:
            $lK1w0 = Cloud::find($hFrf7);
            goto bQXxF;
            fqIUW:
            $gGdNk = Media::find($hFrf7);
            goto rJPVX;
            JrpDQ:
            jlHev:
            goto lIq4t;
            lIq4t:
        }
        C4vrE:
    }
    public function delete(string $JTwN4) : void
    {
        $lK1w0 = Cloud::findOrFail($JTwN4);
        $lK1w0->delete();
    }
}
