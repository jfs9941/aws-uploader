<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Ue5sQd192Jr9b;
use Jfs\Gallery\Service\Search\BIsPBMapjBOdd;
use Jfs\Gallery\Service\Search\YfirkFAsa7exj;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class M4njLDTMOF7To implements GalleryCloudInterface
{
    private $Pcgh6 = ['types' => YfirkFAsa7exj::class, 'category' => Ue5sQd192Jr9b::class];
    public function search(int $CYLV9, $NjEGO) : array
    {
        goto hMGaR;
        TGXd6:
        goto Ruaxr;
        goto Y6N35;
        VY8AB:
        $bxnYM = $bxnYM->where('status', '=', StatusEnum::DYk9Y);
        goto VXgvK;
        uNuYM:
        $bxnYM = Cloud::query()->where('user_id', $CYLV9);
        goto lmr2w;
        VXgvK:
        $U2a7I['types'] = array_filter($U2a7I['types'], function ($my0ZJ) {
            return $my0ZJ !== 'approved';
        });
        goto hwCgk;
        zofEB:
        if (!in_array('approved', $U2a7I['types'] ?? [])) {
            goto nIxBV;
        }
        goto VY8AB;
        LrsNX:
        $bxnYM = $this->mYBgsWzRyl3($U2a7I, $lDyT_, $bxnYM);
        goto MvhAO;
        lnoZF:
        Ruaxr:
        goto LrsNX;
        Y6N35:
        kAMSL:
        goto aWx71;
        hMGaR:
        list($U2a7I, $lDyT_, $nGqWt, $d8lTR, $C8Mca) = $NjEGO;
        goto uNuYM;
        vHF72:
        $y0m_Q = $bxnYM->with('media')->orderBy('created_at', 'desc')->limit($d8lTR)->offset(($nGqWt - 1) * $d8lTR)->get()->filter(function (Cloud $O5YQF) {
            return $O5YQF->getMedia() != null;
        })->map(function (Cloud $O5YQF) {
            goto CihHC;
            CihHC:
            $Nb_Od = $O5YQF->getMedia();
            goto a53_9;
            a53_9:
            $rjTdY = $Nb_Od->getView();
            goto V8A3m;
            V8A3m:
            return array_merge($rjTdY, ['type' => $O5YQF->getAttribute('type'), 'status' => $O5YQF->getAttribute('status')]);
            goto rKRYf;
            rKRYf:
        })->values();
        goto w5x4p;
        aWx71:
        $bxnYM = $bxnYM->where('status', '=', StatusEnum::DYk9Y);
        goto lnoZF;
        MvhAO:
        $fuWUm = DB::query()->fromSub($bxnYM, 't')->selectRaw('count(*) as total')->first()->total;
        goto vHF72;
        lmr2w:
        if (!$C8Mca) {
            goto kAMSL;
        }
        goto zofEB;
        hwCgk:
        nIxBV:
        goto TGXd6;
        w5x4p:
        return ['page' => $nGqWt, 'total' => $fuWUm, 'item_per_page' => $d8lTR, 'data' => $y0m_Q];
        goto yH18x;
        yH18x:
    }
    private function mYBgsWzRyl3(array $U2a7I, array $AoVjl, Builder $eyDUn) : Builder
    {
        goto U5i13;
        U5i13:
        foreach ($this->Pcgh6 as $wfn1Y => $rTfVL) {
            goto ca3YA;
            xerWn:
            wLKTR:
            goto QPplH;
            Rmp5U:
            LVIAi:
            goto BGwTj;
            ca3YA:
            if (isset($U2a7I[$wfn1Y]) && !isset($AoVjl[$wfn1Y])) {
                goto UOH7X;
            }
            goto D1kj1;
            wH_Qd:
            $vW2sH = new $rTfVL();
            goto PRv5s;
            PRv5s:
            $vW2sH->mgFtO7lTSCM($eyDUn, $AoVjl[$wfn1Y], false);
            goto xerWn;
            QPplH:
            goto Vuuos;
            goto o7VaA;
            o7VaA:
            UOH7X:
            goto w2uuU;
            w2uuU:
            $vW2sH = new $rTfVL();
            goto ynJ4l;
            tA_8D:
            Vuuos:
            goto Rmp5U;
            D1kj1:
            if (!isset($AoVjl[$wfn1Y])) {
                goto wLKTR;
            }
            goto wH_Qd;
            ynJ4l:
            $vW2sH->mgFtO7lTSCM($eyDUn, $U2a7I[$wfn1Y]);
            goto tA_8D;
            BGwTj:
        }
        goto UBUDh;
        UBUDh:
        uZDPy:
        goto AvpKb;
        AvpKb:
        return $eyDUn;
        goto ncWYD;
        ncWYD:
    }
    public function saveItems(array $dkub5) : void
    {
        foreach ($dkub5 as $FJFJj) {
            goto jAB1f;
            rRikO:
            Cloud::m9hMLtkXyEB($pCAnX, StatusEnum::vr9rg);
            goto ZGsj5;
            ZGsj5:
            kZYJn:
            goto dG9q4;
            jAB1f:
            $O5YQF = Cloud::find($FJFJj);
            goto uTLMl;
            dG9q4:
            IKnuW:
            goto BkXKi;
            OUauc:
            $pCAnX = Media::find($FJFJj);
            goto rRikO;
            uTLMl:
            if ($O5YQF) {
                goto kZYJn;
            }
            goto OUauc;
            BkXKi:
        }
        L3ahM:
    }
    public function delete(string $arqvy) : void
    {
        $O5YQF = Cloud::findOrFail($arqvy);
        $O5YQF->delete();
    }
}
