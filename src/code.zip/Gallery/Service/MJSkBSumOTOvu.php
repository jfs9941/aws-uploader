<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Gallery\Service\Search\Ww3sOGTTZ067P;
use Jfs\Gallery\Service\Search\URI41WL8s209Q;
use Jfs\Gallery\Service\Search\Jn3r7vF7zNmhw;
use Illuminate\Database\Eloquent\Builder;
final class MJSkBSumOTOvu implements GalleryCloudInterface
{
    private $xhAFe = ['types' => Jn3r7vF7zNmhw::class, 'category' => Ww3sOGTTZ067P::class];
    public function search(int $Iwgmc, $OOp2N) : array
    {
        goto QlyJM;
        NQUbH:
        $P1q_e = Cloud::query()->where('user_id', $Iwgmc);
        goto CH96t;
        w6BmT:
        X1suY:
        goto JHrpY;
        IWF6O:
        if (!in_array('approved', $tZkuU['types'] ?? [])) {
            goto QgasO;
        }
        goto aTmW8;
        mnNwz:
        $mSAcF = DB::query()->fromSub($P1q_e, 't')->selectRaw('count(*) as total')->first()->total;
        goto fzq_5;
        CH96t:
        if (!$Jj1cN) {
            goto v2SWO;
        }
        goto IWF6O;
        Grk0k:
        goto X1suY;
        goto POjEd;
        JHrpY:
        $P1q_e = $this->mUUmlfmRR8A($tZkuU, $P1q_e);
        goto mnNwz;
        aTmW8:
        $P1q_e = $P1q_e->where('status', '=', StatusEnum::maR7d);
        goto VCpBs;
        QLbOE:
        QgasO:
        goto Grk0k;
        fzq_5:
        $rvOSs = $P1q_e->with('media')->orderBy('created_at', 'desc')->limit($w1UAq)->offset(($R3k_S - 1) * $w1UAq)->get()->filter(function (Cloud $kGB1W) {
            return $kGB1W->getMedia() != null;
        })->map(function (Cloud $kGB1W) {
            goto uW8hl;
            wdB_8:
            $IjqxX = $UWZG3->getView();
            goto bbOib;
            bbOib:
            return array_merge($IjqxX, ['type' => $kGB1W->getAttribute('type'), 'status' => $kGB1W->getAttribute('status')]);
            goto pHVIy;
            uW8hl:
            $UWZG3 = $kGB1W->getMedia();
            goto wdB_8;
            pHVIy:
        })->values();
        goto htI5J;
        POjEd:
        v2SWO:
        goto J6Kq3;
        htI5J:
        return ['page' => $R3k_S, 'total' => $mSAcF, 'item_per_page' => $w1UAq, 'data' => $rvOSs];
        goto ZOU_C;
        QlyJM:
        list($tZkuU, $R3k_S, $w1UAq, $Jj1cN) = $OOp2N;
        goto NQUbH;
        VCpBs:
        $tZkuU['types'] = array_filter($tZkuU['types'], function ($AjUqt) {
            return $AjUqt !== 'approved';
        });
        goto QLbOE;
        J6Kq3:
        $P1q_e = $P1q_e->where('status', '=', StatusEnum::maR7d);
        goto w6BmT;
        ZOU_C:
    }
    private function mUUmlfmRR8A(array $tZkuU, Builder $O81mB) : Builder
    {
        goto VxTZI;
        b6H3a:
        LRD3F:
        goto uKcP4;
        VxTZI:
        foreach ($this->xhAFe as $Het1X => $byeum) {
            goto y3yqY;
            LN1hj:
            $gvTsA = new $byeum();
            goto ukkQo;
            eQhWZ:
            tGYp7:
            goto a48bw;
            ukkQo:
            $gvTsA->mvxFHVrMgPO($O81mB, $tZkuU[$Het1X]);
            goto uuqkX;
            y3yqY:
            if (!isset($tZkuU[$Het1X])) {
                goto GDV2f;
            }
            goto LN1hj;
            uuqkX:
            GDV2f:
            goto eQhWZ;
            a48bw:
        }
        goto b6H3a;
        uKcP4:
        return $O81mB;
        goto GrwGn;
        GrwGn:
    }
    public function saveItems(array $GBHMJ) : void
    {
        foreach ($GBHMJ as $QuYzZ) {
            goto kX3bT;
            fi8dG:
            if ($kGB1W) {
                goto duhA_;
            }
            goto UN2YL;
            UN2YL:
            $qW6LM = Media::find($QuYzZ);
            goto yklrF;
            yklrF:
            Cloud::mAFPxbcmKO8($qW6LM, StatusEnum::R0BpR);
            goto GDs54;
            kX3bT:
            $kGB1W = Cloud::find($QuYzZ);
            goto fi8dG;
            GDs54:
            duhA_:
            goto Vz7RW;
            Vz7RW:
            Et_WN:
            goto q4opi;
            q4opi:
        }
        xE9yS:
    }
    public function delete(string $IaHim) : void
    {
        $kGB1W = Cloud::findOrFail($IaHim);
        $kGB1W->delete();
    }
}
