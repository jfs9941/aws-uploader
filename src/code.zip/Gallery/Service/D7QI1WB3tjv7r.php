<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\B1WCetrnUPjvY;
use Jfs\Gallery\Service\Search\Zb2RivTMNxeXN;
use Jfs\Gallery\Service\Search\BkkDHyBQdQ5xM;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class D7QI1WB3tjv7r implements GalleryCloudInterface
{
    private $rxlob = ['types' => BkkDHyBQdQ5xM::class, 'category' => B1WCetrnUPjvY::class];
    public function search(int $V3Z4M, $fl1DY) : array
    {
        goto IV8Eh;
        pmLww:
        pIKrS:
        goto iZtvU;
        iZtvU:
        $VkY3h = $this->m1w6rhlgHdH($jId4d, $IDzhS, $VkY3h);
        goto gSHBw;
        j8W6L:
        e2Tfo:
        goto gasWj;
        JVvsU:
        $jId4d['types'] = array_filter($jId4d['types'], function ($T6w12) {
            return $T6w12 !== 'approved';
        });
        goto j8W6L;
        IV8Eh:
        list($jId4d, $IDzhS, $H8eU8, $iaG33, $rl6cW) = $fl1DY;
        goto hSTBg;
        sOiwf:
        return ['page' => $H8eU8, 'total' => $E17dV, 'item_per_page' => $iaG33, 'data' => $FhmWg];
        goto fobAm;
        wPBi3:
        $FhmWg = $VkY3h->with('media')->orderBy('created_at', 'desc')->limit($iaG33)->offset(($H8eU8 - 1) * $iaG33)->get()->filter(function (Cloud $NwPQk) {
            return $NwPQk->getMedia() != null;
        })->map(function (Cloud $NwPQk) {
            goto xezGe;
            cwGxo:
            $RKt3t = $G2mX1->getView();
            goto fZdA9;
            fZdA9:
            return array_merge($RKt3t, ['type' => $NwPQk->getAttribute('type'), 'status' => $NwPQk->getAttribute('status')]);
            goto wiMTz;
            xezGe:
            $G2mX1 = $NwPQk->getMedia();
            goto cwGxo;
            wiMTz:
        })->values();
        goto sOiwf;
        hSTBg:
        $VkY3h = Cloud::query()->where('user_id', $V3Z4M);
        goto fybqq;
        gSHBw:
        $E17dV = DB::query()->fromSub($VkY3h, 't')->selectRaw('count(*) as total')->first()->total;
        goto wPBi3;
        FevDL:
        $VkY3h = $VkY3h->where('status', '=', StatusEnum::AM3bf);
        goto JVvsU;
        duGzX:
        if (!in_array('approved', $jId4d['types'] ?? [])) {
            goto e2Tfo;
        }
        goto FevDL;
        gasWj:
        goto pIKrS;
        goto UL83J;
        PPSAI:
        $VkY3h = $VkY3h->where('status', '=', StatusEnum::AM3bf);
        goto pmLww;
        fybqq:
        if (!$rl6cW) {
            goto CVdm9;
        }
        goto duGzX;
        UL83J:
        CVdm9:
        goto PPSAI;
        fobAm:
    }
    private function m1w6rhlgHdH(array $jId4d, array $xDlQl, Builder $xGZ7p) : Builder
    {
        goto Ylyqp;
        Ylyqp:
        foreach ($this->rxlob as $TM8xe => $FBI1l) {
            goto J_CFD;
            ncR9j:
            $da0P_ = new $FBI1l();
            goto KUVT2;
            vVzJY:
            EUqiw:
            goto zG6ZV;
            T6InB:
            zOVQB:
            goto TgNCz;
            KUVT2:
            $da0P_->mVPkONnVEF8($xGZ7p, $jId4d[$TM8xe], true);
            goto U2xvC;
            tWUu2:
            $da0P_->mVPkONnVEF8($xGZ7p, $xDlQl[$TM8xe], false);
            goto vVzJY;
            C5rhE:
            F6lgO:
            goto ncR9j;
            J_CFD:
            if (isset($jId4d[$TM8xe]) && !isset($xDlQl[$TM8xe])) {
                goto F6lgO;
            }
            goto yhcMA;
            U2xvC:
            v2CU3:
            goto T6InB;
            yhcMA:
            if (!isset($xDlQl[$TM8xe])) {
                goto EUqiw;
            }
            goto i4syo;
            zG6ZV:
            goto v2CU3;
            goto C5rhE;
            i4syo:
            $da0P_ = new $FBI1l();
            goto tWUu2;
            TgNCz:
        }
        goto WIjqP;
        qEjM3:
        return $xGZ7p;
        goto y4U0U;
        WIjqP:
        RuD18:
        goto qEjM3;
        y4U0U:
    }
    public function saveItems(array $O9DNf) : void
    {
        foreach ($O9DNf as $K9DZL) {
            goto EusRE;
            wVDro:
            if ($NwPQk) {
                goto bm9uK;
            }
            goto vddDv;
            vddDv:
            $OwKVg = Media::find($K9DZL);
            goto IILJU;
            IILJU:
            Cloud::mOcvAld26vf($OwKVg, StatusEnum::hLek1);
            goto y0nRE;
            y0nRE:
            bm9uK:
            goto kDFlP;
            EusRE:
            $NwPQk = Cloud::find($K9DZL);
            goto wVDro;
            kDFlP:
            j1FIU:
            goto r1q10;
            r1q10:
        }
        NIaeU:
    }
    public function delete(string $wAkkA) : void
    {
        $NwPQk = Cloud::findOrFail($wAkkA);
        $NwPQk->delete();
    }
}
