<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\SECbji1Rtx8q7;
use Jfs\Gallery\Service\Search\I7VEXBdZYkDiA;
use Jfs\Gallery\Service\Search\IvFG77u08uARl;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class E94a5bHUILBqo implements GalleryCloudInterface
{
    private $d2sfl = ['types' => IvFG77u08uARl::class, 'category' => SECbji1Rtx8q7::class];
    public function search(int $aFk6e, $WKjnR) : array
    {
        goto neEoG;
        SYeIz:
        if (!in_array('approved', $k3uni['types'] ?? [])) {
            goto hRcFT;
        }
        goto eMYnI;
        ehXmT:
        hRcFT:
        goto VmVW3;
        Z2gyx:
        $NQsDq = $nLI19->with('media')->orderBy('created_at', 'desc')->limit($Mguk6)->offset(($ypJJH - 1) * $Mguk6)->get()->filter(function (Cloud $sn0U6) {
            return $sn0U6->getMedia() != null;
        })->map(function (Cloud $sn0U6) {
            goto XZnqA;
            IC_Je:
            $OYL2A = $zacay->getView();
            goto Kkbdc;
            XZnqA:
            $zacay = $sn0U6->getMedia();
            goto IC_Je;
            Kkbdc:
            return array_merge($OYL2A, ['type' => $sn0U6->getAttribute('type'), 'status' => $sn0U6->getAttribute('status')]);
            goto VJBOt;
            VJBOt:
        })->values();
        goto ran_j;
        ran_j:
        return ['page' => $ypJJH, 'total' => $E3fDY, 'item_per_page' => $Mguk6, 'data' => $NQsDq];
        goto qT1qO;
        lciHN:
        $k3uni['types'] = array_filter($k3uni['types'], function ($hfjFu) {
            return $hfjFu !== 'approved';
        });
        goto ehXmT;
        neEoG:
        list($k3uni, $Swmqb, $ypJJH, $Mguk6, $X2Sb5) = $WKjnR;
        goto tNwTs;
        L_N2t:
        if (!$X2Sb5) {
            goto JCNro;
        }
        goto SYeIz;
        Fy9Fh:
        JCNro:
        goto Nuhhd;
        VmVW3:
        goto tOVOR;
        goto Fy9Fh;
        qGXXe:
        tOVOR:
        goto AzztS;
        mBcEY:
        $E3fDY = DB::query()->fromSub($nLI19, 't')->selectRaw('count(*) as total')->first()->total;
        goto Z2gyx;
        AzztS:
        $nLI19 = $this->m7IMCn6XrLb($k3uni, $Swmqb, $nLI19);
        goto mBcEY;
        eMYnI:
        $nLI19 = $nLI19->where('status', '=', StatusEnum::ZNjvU);
        goto lciHN;
        Nuhhd:
        $nLI19 = $nLI19->where('status', '=', StatusEnum::ZNjvU);
        goto qGXXe;
        tNwTs:
        $nLI19 = Cloud::query()->where('user_id', $aFk6e);
        goto L_N2t;
        qT1qO:
    }
    private function m7IMCn6XrLb(array $k3uni, array $uozte, Builder $hXUx3) : Builder
    {
        goto er0bw;
        o72EL:
        Xwegz:
        goto Y8IwY;
        Y8IwY:
        return $hXUx3;
        goto Gexnm;
        er0bw:
        foreach ($this->d2sfl as $DzM0p => $Nq_2R) {
            goto BpWta;
            BpWta:
            if (isset($k3uni[$DzM0p]) && !isset($uozte[$DzM0p])) {
                goto JejjD;
            }
            goto mtAll;
            D7hkd:
            iBCN8:
            goto sijwa;
            b06Xu:
            $dK5OS = new $Nq_2R();
            goto G7pgh;
            KYZRH:
            $dK5OS = new $Nq_2R();
            goto Hr1Mm;
            G7pgh:
            $dK5OS->mF5p1W7dbc2($hXUx3, $uozte[$DzM0p], false);
            goto pBArw;
            hqlgG:
            JejjD:
            goto KYZRH;
            pBArw:
            Np9UF:
            goto cFcYd;
            Hr1Mm:
            $dK5OS->mF5p1W7dbc2($hXUx3, $k3uni[$DzM0p], true);
            goto D7hkd;
            cFcYd:
            goto iBCN8;
            goto hqlgG;
            sijwa:
            koS1A:
            goto RE3qK;
            mtAll:
            if (!isset($uozte[$DzM0p])) {
                goto Np9UF;
            }
            goto b06Xu;
            RE3qK:
        }
        goto o72EL;
        Gexnm:
    }
    public function saveItems(array $kDUA7) : void
    {
        foreach ($kDUA7 as $Z5ydB) {
            goto nLcT3;
            nLcT3:
            $sn0U6 = Cloud::find($Z5ydB);
            goto UAVHl;
            W3oUu:
            Cloud::mud5dNZaXXy($sLwwk, StatusEnum::jg6TU);
            goto z_VBF;
            z_VBF:
            hpPlc:
            goto OdVne;
            iQT4K:
            $sLwwk = Media::find($Z5ydB);
            goto W3oUu;
            OdVne:
            KreQv:
            goto nsw2I;
            UAVHl:
            if ($sn0U6) {
                goto hpPlc;
            }
            goto iQT4K;
            nsw2I:
        }
        a8ZZl:
    }
    public function delete(string $zV1kl) : void
    {
        $sn0U6 = Cloud::findOrFail($zV1kl);
        $sn0U6->delete();
    }
}
