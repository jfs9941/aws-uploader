<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\WrF4Cfb2NiWXX;
use Jfs\Gallery\Service\Search\UT9e3SybDr4LH;
use Jfs\Gallery\Service\Search\Jv0kIHCxA40hC;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class Rcvt9IX4AhWY7 implements GalleryCloudInterface
{
    private $T8qiW = ['types' => Jv0kIHCxA40hC::class, 'category' => WrF4Cfb2NiWXX::class];
    public function search(int $yJf24, $xwEpc) : array
    {
        goto GCFNh;
        w1nyL:
        $Z1dUZ = Cloud::query()->where('user_id', $yJf24);
        goto a6y3g;
        TeZyt:
        AOOH3:
        goto kHasw;
        sfKcR:
        $p43mM = DB::query()->fromSub($Z1dUZ, 't')->selectRaw('count(*) as total')->first()->total;
        goto qAc6g;
        N2X5j:
        $Z1dUZ = $Z1dUZ->where('status', '=', StatusEnum::ZOY3U);
        goto TeZyt;
        xkk0S:
        $qL2tK['types'] = array_filter($qL2tK['types'], function ($AkBFF) {
            return $AkBFF !== 'approved';
        });
        goto ySDt2;
        FskIU:
        $Z1dUZ = $Z1dUZ->where('status', '=', StatusEnum::ZOY3U);
        goto xkk0S;
        ySDt2:
        ak3Oi:
        goto lFChs;
        Q8OFK:
        return ['page' => $il1fW, 'total' => $p43mM, 'item_per_page' => $wanWy, 'data' => $XDvUb];
        goto RaFMH;
        a6y3g:
        if (!$O5V8v) {
            goto sk0Kg;
        }
        goto ZqNjX;
        kHasw:
        $Z1dUZ = $this->mXeeZPNICDY($qL2tK, $SZor3, $Z1dUZ);
        goto sfKcR;
        GCFNh:
        list($qL2tK, $SZor3, $il1fW, $wanWy, $O5V8v) = $xwEpc;
        goto w1nyL;
        ZqNjX:
        if (!in_array('approved', $qL2tK['types'] ?? [])) {
            goto ak3Oi;
        }
        goto FskIU;
        KONBR:
        sk0Kg:
        goto N2X5j;
        qAc6g:
        $XDvUb = $Z1dUZ->with('media')->orderBy('created_at', 'desc')->limit($wanWy)->offset(($il1fW - 1) * $wanWy)->get()->filter(function (Cloud $nu0xX) {
            return $nu0xX->getMedia() != null;
        })->map(function (Cloud $nu0xX) {
            goto Sj8bp;
            iVSPs:
            return array_merge($cYXE_, ['type' => $nu0xX->getAttribute('type'), 'status' => $nu0xX->getAttribute('status')]);
            goto pnj36;
            f1YmE:
            $cYXE_ = $jBims->getView();
            goto iVSPs;
            Sj8bp:
            $jBims = $nu0xX->getMedia();
            goto f1YmE;
            pnj36:
        })->values();
        goto Q8OFK;
        lFChs:
        goto AOOH3;
        goto KONBR;
        RaFMH:
    }
    private function mXeeZPNICDY(array $qL2tK, array $TQjce, Builder $uj0nf) : Builder
    {
        goto S83l3;
        S83l3:
        foreach ($this->T8qiW as $WUaOA => $MjAtF) {
            goto suIU6;
            s1oej:
            SxcwF:
            goto mtm2N;
            Wh9BH:
            jUSue:
            goto l7tSc;
            suIU6:
            if (isset($qL2tK[$WUaOA]) && !isset($TQjce[$WUaOA])) {
                goto SxcwF;
            }
            goto B90eA;
            oCUxn:
            $wrGKa = new $MjAtF();
            goto a5vvW;
            Ml35f:
            FsO5N:
            goto rfgoe;
            bFMBM:
            dt6yA:
            goto Ml35f;
            mtm2N:
            $wrGKa = new $MjAtF();
            goto TKDv4;
            B90eA:
            if (!isset($TQjce[$WUaOA])) {
                goto jUSue;
            }
            goto oCUxn;
            a5vvW:
            $wrGKa->mycbA1e4uHY($uj0nf, $TQjce[$WUaOA], false);
            goto Wh9BH;
            l7tSc:
            goto dt6yA;
            goto s1oej;
            TKDv4:
            $wrGKa->mycbA1e4uHY($uj0nf, $qL2tK[$WUaOA]);
            goto bFMBM;
            rfgoe:
        }
        goto P1qYr;
        uwISi:
        return $uj0nf;
        goto mpTay;
        P1qYr:
        MGoXj:
        goto uwISi;
        mpTay:
    }
    public function saveItems(array $GfY2U) : void
    {
        foreach ($GfY2U as $RB3Ub) {
            goto xmwH2;
            NHYHR:
            t6KqU:
            goto BKL2f;
            yWWeD:
            if ($nu0xX) {
                goto mMIZZ;
            }
            goto fqtQp;
            xmwH2:
            $nu0xX = Cloud::find($RB3Ub);
            goto yWWeD;
            fqtQp:
            $WFvTF = Media::find($RB3Ub);
            goto BUBww;
            gDbQB:
            mMIZZ:
            goto NHYHR;
            BUBww:
            Cloud::mv7HeS8w5DY($WFvTF, StatusEnum::zB8JK);
            goto gDbQB;
            BKL2f:
        }
        WjrwD:
    }
    public function delete(string $GMwD5) : void
    {
        $nu0xX = Cloud::findOrFail($GMwD5);
        $nu0xX->delete();
    }
}
