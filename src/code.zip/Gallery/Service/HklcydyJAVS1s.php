<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Service;

use backup\Exposed\Am3Ua9F8YERkp;
use backup\Gallery\Model\Y15yR15X8IoGo;
use backup\Gallery\Model\Enum\RCVW1TQsWPapp;
use backup\Gallery\Model\QyxVvo5lhAzix;
use backup\Gallery\Service\Search\OOe79iTzAkcR2;
use backup\Gallery\Service\Search\R7JsGWBIJnSWn;
use backup\Gallery\Service\Search\RcGVr5Ck5J1aH;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class HklcydyJAVS1s implements Am3Ua9F8YERkp
{
    private $ReV4A = ['types' => RcGVr5Ck5J1aH::class, 'category' => OOe79iTzAkcR2::class];
    public function search(int $tVw6M, $Zd0wX) : array
    {
        goto J9gHq;
        iHzNp:
        $ekiyM = $this->m99hIPfpvZ5($nboaA, $JJcCv, $ekiyM);
        goto jp44P;
        Opl5w:
        yqX62:
        goto FLGto;
        FLGto:
        goto mx0pS;
        goto Cmies;
        fFKsV:
        $nboaA['types'] = array_filter($nboaA['types'], function ($xls_0) {
            return $xls_0 !== 'approved';
        });
        goto Opl5w;
        qVUZx:
        mx0pS:
        goto iHzNp;
        np2XB:
        $ekiyM = Y15yR15X8IoGo::query()->where('user_id', $tVw6M);
        goto wgGqR;
        lE69Q:
        $ekiyM = $ekiyM->where('status', '=', RCVW1TQsWPapp::vI1BO);
        goto qVUZx;
        wgGqR:
        if (!$etPR1) {
            goto r4OYl;
        }
        goto NtBdy;
        J9gHq:
        list($nboaA, $JJcCv, $GEC0j, $Z0lp3, $etPR1) = $Zd0wX;
        goto np2XB;
        jp44P:
        $QZJAY = DB::query()->fromSub($ekiyM, 't')->selectRaw('count(*) as total')->first()->total;
        goto cVwGt;
        ti7_c:
        return ['page' => $GEC0j, 'total' => $QZJAY, 'item_per_page' => $Z0lp3, 'data' => $Pay5j];
        goto Ejx53;
        hf2xm:
        $ekiyM = $ekiyM->where('status', '=', RCVW1TQsWPapp::vI1BO);
        goto fFKsV;
        NtBdy:
        if (!in_array('approved', $nboaA['types'] ?? [])) {
            goto yqX62;
        }
        goto hf2xm;
        Cmies:
        r4OYl:
        goto lE69Q;
        cVwGt:
        $Pay5j = $ekiyM->with('media')->orderBy('created_at', 'desc')->limit($Z0lp3)->offset(($GEC0j - 1) * $Z0lp3)->get()->filter(function (Y15yR15X8IoGo $s9mwQ) {
            return $s9mwQ->getMedia() != null;
        })->map(function (Y15yR15X8IoGo $s9mwQ) {
            goto fgTQv;
            fyC_7:
            $wNj_Z = $tFHv6->getView();
            goto lz3CB;
            lz3CB:
            return array_merge($wNj_Z, ['type' => $s9mwQ->getAttribute('type'), 'status' => $s9mwQ->getAttribute('status')]);
            goto r66eP;
            fgTQv:
            $tFHv6 = $s9mwQ->getMedia();
            goto fyC_7;
            r66eP:
        })->values();
        goto ti7_c;
        Ejx53:
    }
    private function m99hIPfpvZ5(array $nboaA, array $NHyPT, Builder $ZBTET) : Builder
    {
        goto Ww6EY;
        Ww6EY:
        foreach ($this->ReV4A as $H_NTC => $vZC3c) {
            goto UW51d;
            RLUIh:
            if (!isset($NHyPT[$H_NTC])) {
                goto Tt25y;
            }
            goto Qn5Sf;
            nUMEB:
            Tt25y:
            goto v5Zct;
            cq2xY:
            mf5ow:
            goto FyP2T;
            auCe2:
            $BF0ou = new $vZC3c();
            goto Xwq8B;
            UW51d:
            if (isset($nboaA[$H_NTC]) && !isset($NHyPT[$H_NTC])) {
                goto Ly5e4;
            }
            goto RLUIh;
            Qn5Sf:
            $BF0ou = new $vZC3c();
            goto pKeEw;
            ppd1h:
            Ly5e4:
            goto auCe2;
            pKeEw:
            $BF0ou->mBjbSluggM1($ZBTET, $NHyPT[$H_NTC], false);
            goto nUMEB;
            v5Zct:
            goto Q4ZMe;
            goto ppd1h;
            lOOpW:
            Q4ZMe:
            goto cq2xY;
            Xwq8B:
            $BF0ou->mBjbSluggM1($ZBTET, $nboaA[$H_NTC]);
            goto lOOpW;
            FyP2T:
        }
        goto SBuF1;
        SBuF1:
        IsF58:
        goto pQ4tP;
        pQ4tP:
        return $ZBTET;
        goto me9Rl;
        me9Rl:
    }
    public function saveItems(array $hhN_Q) : void
    {
        foreach ($hhN_Q as $eVZrJ) {
            goto kFtgr;
            aExfl:
            $hT4WG = QyxVvo5lhAzix::find($eVZrJ);
            goto Dodey;
            uDaSX:
            oppYg:
            goto O2xs6;
            Dodey:
            Y15yR15X8IoGo::m4j2jBBSzIs($hT4WG, RCVW1TQsWPapp::lhJSS);
            goto uDaSX;
            kFtgr:
            $s9mwQ = Y15yR15X8IoGo::find($eVZrJ);
            goto vfdNn;
            vfdNn:
            if ($s9mwQ) {
                goto oppYg;
            }
            goto aExfl;
            O2xs6:
            tKl85:
            goto Ug6H7;
            Ug6H7:
        }
        Z1niT:
    }
    public function delete(string $EQQae) : void
    {
        $s9mwQ = Y15yR15X8IoGo::findOrFail($EQQae);
        $s9mwQ->delete();
    }
}
