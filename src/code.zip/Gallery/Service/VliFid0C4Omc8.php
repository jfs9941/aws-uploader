<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\IkqZFYx3nV3bq;
use Jfs\Gallery\Service\Search\FT3xONdY4ln2V;
use Jfs\Gallery\Service\Search\Lkhs2OU0b1zpi;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class VliFid0C4Omc8 implements GalleryCloudInterface
{
    private $dknTE = ['types' => Lkhs2OU0b1zpi::class, 'category' => IkqZFYx3nV3bq::class];
    public function search(int $NURhE, $BazRF) : array
    {
        goto Uqo_f;
        eJgxD:
        lA0Oo:
        goto qbI5I;
        nVo1l:
        goto TC2B0;
        goto eJgxD;
        CcKj7:
        $SKvTz = $T8w9A->with('media')->orderBy('created_at', 'desc')->limit($UUQuI)->offset(($MTqJq - 1) * $UUQuI)->get()->filter(function (Cloud $ytVx9) {
            return $ytVx9->getMedia() != null;
        })->map(function (Cloud $ytVx9) {
            goto iR0Eu;
            MDZUX:
            $u0joM = $Zt12Z->getView();
            goto XFHyY;
            iR0Eu:
            $Zt12Z = $ytVx9->getMedia();
            goto MDZUX;
            XFHyY:
            return array_merge($u0joM, ['type' => $ytVx9->getAttribute('type'), 'status' => $ytVx9->getAttribute('status')]);
            goto lDLIa;
            lDLIa:
        })->values();
        goto vlC6Z;
        SVlCw:
        Ht3rt:
        goto nVo1l;
        hQS3W:
        $Jn05i['types'] = array_filter($Jn05i['types'], function ($gbQ9f) {
            return $gbQ9f !== 'approved';
        });
        goto SVlCw;
        m5RzO:
        if (!in_array('approved', $Jn05i['types'] ?? [])) {
            goto Ht3rt;
        }
        goto ka1tJ;
        dQf2K:
        $h3_Yu = DB::query()->fromSub($T8w9A, 't')->selectRaw('count(*) as total')->first()->total;
        goto CcKj7;
        FfaMJ:
        $T8w9A = Cloud::query()->where('user_id', $NURhE);
        goto u1Uqi;
        vlC6Z:
        return ['page' => $MTqJq, 'total' => $h3_Yu, 'item_per_page' => $UUQuI, 'data' => $SKvTz];
        goto WBrZw;
        PnoSa:
        $T8w9A = $this->mOPIAN6hmn2($Jn05i, $aTr_c, $T8w9A);
        goto dQf2K;
        WIna3:
        TC2B0:
        goto PnoSa;
        ka1tJ:
        $T8w9A = $T8w9A->where('status', '=', StatusEnum::bs_B3);
        goto hQS3W;
        qbI5I:
        $T8w9A = $T8w9A->where('status', '=', StatusEnum::bs_B3);
        goto WIna3;
        u1Uqi:
        if (!$WYAgB) {
            goto lA0Oo;
        }
        goto m5RzO;
        Uqo_f:
        list($Jn05i, $aTr_c, $MTqJq, $UUQuI, $WYAgB) = $BazRF;
        goto FfaMJ;
        WBrZw:
    }
    private function mOPIAN6hmn2(array $Jn05i, array $OuFKB, Builder $BoTPl) : Builder
    {
        goto TlVAB;
        C0Wss:
        zoa3T:
        goto dOvR2;
        TlVAB:
        foreach ($this->dknTE as $mIhnW => $v7CzG) {
            goto HBLPR;
            tN1wr:
            wAAHH:
            goto heMIC;
            HBLPR:
            if (isset($Jn05i[$mIhnW]) && !isset($OuFKB[$mIhnW])) {
                goto XeRGL;
            }
            goto z1pR1;
            t9yx5:
            $OIBeE = new $v7CzG();
            goto iXhkv;
            iXhkv:
            $OIBeE->m2xXyEImnIi($BoTPl, $Jn05i[$mIhnW], true);
            goto SwFot;
            z1pR1:
            if (!isset($OuFKB[$mIhnW])) {
                goto wAAHH;
            }
            goto ipDKJ;
            qTStL:
            S8kpJ:
            goto U0C0m;
            ipDKJ:
            $OIBeE = new $v7CzG();
            goto QLwed;
            nUiJ3:
            XeRGL:
            goto t9yx5;
            QLwed:
            $OIBeE->m2xXyEImnIi($BoTPl, $OuFKB[$mIhnW], false);
            goto tN1wr;
            heMIC:
            goto w5Vo0;
            goto nUiJ3;
            SwFot:
            w5Vo0:
            goto qTStL;
            U0C0m:
        }
        goto C0Wss;
        dOvR2:
        return $BoTPl;
        goto wrhuR;
        wrhuR:
    }
    public function saveItems(array $Tmmek) : void
    {
        foreach ($Tmmek as $cNpq7) {
            goto Jxg1E;
            AYqmU:
            WTF3e:
            goto DEYja;
            FPWoe:
            Cloud::muXJqr3ygIP($vvube, StatusEnum::Twmtw);
            goto AYqmU;
            BT9id:
            if ($ytVx9) {
                goto WTF3e;
            }
            goto npykN;
            Jxg1E:
            $ytVx9 = Cloud::find($cNpq7);
            goto BT9id;
            DEYja:
            aASqd:
            goto ewnoc;
            npykN:
            $vvube = Media::find($cNpq7);
            goto FPWoe;
            ewnoc:
        }
        ve0Fy:
    }
    public function delete(string $EmnXX) : void
    {
        $ytVx9 = Cloud::findOrFail($EmnXX);
        $ytVx9->delete();
    }
}
