<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\NIvYDIodTjO0O;
use Jfs\Gallery\Service\Search\DoQSKTJEY2pjy;
use Jfs\Gallery\Service\Search\ZTITG4LclaIsH;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class I7SvOr1BMBC5q implements GalleryCloudInterface
{
    private $X78_i = ['types' => ZTITG4LclaIsH::class, 'category' => NIvYDIodTjO0O::class];
    public function search(int $gjHtm, $FAyzV) : array
    {
        goto VIPew;
        ahCEO:
        goto BF5oU;
        goto a0dvQ;
        bRcau:
        BF5oU:
        goto yrV0T;
        a0dvQ:
        fVtaa:
        goto wU_nY;
        d_RQ_:
        return ['page' => $W_Teo, 'total' => $GetkM, 'item_per_page' => $tHxWp, 'data' => $KJZOG];
        goto ynS2l;
        LKvqL:
        $KJZOG = $sscx9->with('media')->orderBy('created_at', 'desc')->limit($tHxWp)->offset(($W_Teo - 1) * $tHxWp)->get()->filter(function (Cloud $CJHPg) {
            return $CJHPg->getMedia() != null;
        })->map(function (Cloud $CJHPg) {
            goto sb76J;
            SXVwe:
            $VwddT = $PK0_J->getView();
            goto y2qE0;
            y2qE0:
            return array_merge($VwddT, ['type' => $CJHPg->getAttribute('type'), 'status' => $CJHPg->getAttribute('status')]);
            goto OzMaU;
            sb76J:
            $PK0_J = $CJHPg->getMedia();
            goto SXVwe;
            OzMaU:
        })->values();
        goto d_RQ_;
        wRBTY:
        $BzV4b['types'] = array_filter($BzV4b['types'], function ($AAavr) {
            return $AAavr !== 'approved';
        });
        goto QyE2g;
        yrV0T:
        $sscx9 = $this->m2gijFG9zx1($BzV4b, $V4z6Z, $sscx9);
        goto AH3Hn;
        U5caR:
        $sscx9 = $sscx9->where('status', '=', StatusEnum::wLFmJ);
        goto wRBTY;
        wU_nY:
        $sscx9 = $sscx9->where('status', '=', StatusEnum::wLFmJ);
        goto bRcau;
        giWX2:
        if (!in_array('approved', $BzV4b['types'] ?? [])) {
            goto vgnIh;
        }
        goto U5caR;
        Kapin:
        $sscx9 = Cloud::query()->where('user_id', $gjHtm);
        goto xOSUW;
        xOSUW:
        if (!$PffzZ) {
            goto fVtaa;
        }
        goto giWX2;
        QyE2g:
        vgnIh:
        goto ahCEO;
        VIPew:
        list($BzV4b, $V4z6Z, $W_Teo, $tHxWp, $PffzZ) = $FAyzV;
        goto Kapin;
        AH3Hn:
        $GetkM = DB::query()->fromSub($sscx9, 't')->selectRaw('count(*) as total')->first()->total;
        goto LKvqL;
        ynS2l:
    }
    private function m2gijFG9zx1(array $BzV4b, array $eg5Ax, Builder $kclx2) : Builder
    {
        goto Gmhr4;
        toKqT:
        xwUcd:
        goto L_0Z7;
        L_0Z7:
        return $kclx2;
        goto U6GjY;
        Gmhr4:
        foreach ($this->X78_i as $kdS3D => $o6MZm) {
            goto cNe_5;
            vB4l4:
            if (!isset($eg5Ax[$kdS3D])) {
                goto mGlsH;
            }
            goto TBD6Y;
            ICCRE:
            TPVuv:
            goto FjxeY;
            cNe_5:
            if (isset($BzV4b[$kdS3D]) && !isset($eg5Ax[$kdS3D])) {
                goto TzljQ;
            }
            goto vB4l4;
            NduG6:
            $I08Ph->mRTrEmrRYkC($kclx2, $eg5Ax[$kdS3D], false);
            goto x0skS;
            p0P_K:
            goto w7rcw;
            goto SHI2h;
            SHI2h:
            TzljQ:
            goto XF0uA;
            GLTB5:
            w7rcw:
            goto ICCRE;
            Xx5w9:
            $I08Ph->mRTrEmrRYkC($kclx2, $BzV4b[$kdS3D], true);
            goto GLTB5;
            x0skS:
            mGlsH:
            goto p0P_K;
            XF0uA:
            $I08Ph = new $o6MZm();
            goto Xx5w9;
            TBD6Y:
            $I08Ph = new $o6MZm();
            goto NduG6;
            FjxeY:
        }
        goto toKqT;
        U6GjY:
    }
    public function saveItems(array $AHKtq) : void
    {
        foreach ($AHKtq as $Ga9Xm) {
            goto i3_jv;
            Noa9g:
            Cloud::mCQRrIZ2P6h($pRvih, StatusEnum::Ci8MB);
            goto J3uDy;
            OJC1V:
            $pRvih = Media::find($Ga9Xm);
            goto Noa9g;
            i3_jv:
            $CJHPg = Cloud::find($Ga9Xm);
            goto qIUMf;
            J3uDy:
            yfJWR:
            goto GdJRi;
            GdJRi:
            QxHKq:
            goto Uhn0l;
            qIUMf:
            if ($CJHPg) {
                goto yfJWR;
            }
            goto OJC1V;
            Uhn0l:
        }
        zCb7m:
    }
    public function delete(string $ShXx2) : void
    {
        $CJHPg = Cloud::findOrFail($ShXx2);
        $CJHPg->delete();
    }
}
