<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Tymv54su6j6GP;
use Jfs\Gallery\Service\Search\GJ442z8TMlzkg;
use Jfs\Gallery\Service\Search\N0UHMO15T9Rh2;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class ZZCtF2oiXL4tR implements GalleryCloudInterface
{
    private $BbmDW = ['types' => N0UHMO15T9Rh2::class, 'category' => Tymv54su6j6GP::class];
    public function search(int $nBxcI, $ZOrR8) : array
    {
        goto bxHuB;
        Ub1vx:
        if (!in_array('approved', $dpbut['types'] ?? [])) {
            goto qw5pR;
        }
        goto Wl8Pu;
        M4Jze:
        $dpbut['types'] = array_filter($dpbut['types'], function ($CzxBB) {
            return $CzxBB !== 'approved';
        });
        goto EJLe6;
        Ne8Bw:
        $ntIcz = Cloud::query()->where('user_id', $nBxcI);
        goto bxbOR;
        a11es:
        oqJjy:
        goto lVVE6;
        lVVE6:
        $ntIcz = $ntIcz->where('status', '=', StatusEnum::vVha4);
        goto e5EUF;
        EJLe6:
        qw5pR:
        goto UXGxK;
        e5EUF:
        mH2I5:
        goto RR3G7;
        qRHl7:
        $LDmT4 = $ntIcz->with('media')->orderBy('created_at', 'desc')->limit($AI873)->offset(($K8c3f - 1) * $AI873)->get()->filter(function (Cloud $E3iDv) {
            return $E3iDv->getMedia() != null;
        })->map(function (Cloud $E3iDv) {
            goto lPI56;
            lPI56:
            $IH9NP = $E3iDv->getMedia();
            goto mB7tI;
            mB7tI:
            $n65l6 = $IH9NP->getView();
            goto iqmRE;
            iqmRE:
            return array_merge($n65l6, ['type' => $E3iDv->getAttribute('type'), 'status' => $E3iDv->getAttribute('status')]);
            goto hO_mk;
            hO_mk:
        })->values();
        goto DzvRf;
        KhZe_:
        $Pmpb0 = DB::query()->fromSub($ntIcz, 't')->selectRaw('count(*) as total')->first()->total;
        goto qRHl7;
        Wl8Pu:
        $ntIcz = $ntIcz->where('status', '=', StatusEnum::vVha4);
        goto M4Jze;
        bxHuB:
        list($dpbut, $uB1Q8, $K8c3f, $AI873, $Cz9kl) = $ZOrR8;
        goto Ne8Bw;
        UXGxK:
        goto mH2I5;
        goto a11es;
        RR3G7:
        $ntIcz = $this->mxfZk1PZf2r($dpbut, $uB1Q8, $ntIcz);
        goto KhZe_;
        bxbOR:
        if (!$Cz9kl) {
            goto oqJjy;
        }
        goto Ub1vx;
        DzvRf:
        return ['page' => $K8c3f, 'total' => $Pmpb0, 'item_per_page' => $AI873, 'data' => $LDmT4];
        goto abdSA;
        abdSA:
    }
    private function mxfZk1PZf2r(array $dpbut, array $jIgKs, Builder $DmFxf) : Builder
    {
        goto G28tp;
        Zzwje:
        return $DmFxf;
        goto vhIvJ;
        G28tp:
        foreach ($this->BbmDW as $m4hVl => $bupep) {
            goto gjoYX;
            AD0rQ:
            qJ15c:
            goto wpfzt;
            lVI2o:
            w3AX9:
            goto AD0rQ;
            b_Clf:
            $mpo5C = new $bupep();
            goto U13li;
            gCcsi:
            $mpo5C = new $bupep();
            goto VBMiL;
            gjoYX:
            if (isset($dpbut[$m4hVl]) && !isset($jIgKs[$m4hVl])) {
                goto l2t6n;
            }
            goto TrDYX;
            VBMiL:
            $mpo5C->m0I9i9iKVnz($DmFxf, $jIgKs[$m4hVl], false);
            goto eYQ25;
            TrDYX:
            if (!isset($jIgKs[$m4hVl])) {
                goto isbBQ;
            }
            goto gCcsi;
            U13li:
            $mpo5C->m0I9i9iKVnz($DmFxf, $dpbut[$m4hVl]);
            goto lVI2o;
            eYQ25:
            isbBQ:
            goto J3C3B;
            aN1so:
            l2t6n:
            goto b_Clf;
            J3C3B:
            goto w3AX9;
            goto aN1so;
            wpfzt:
        }
        goto VeaAl;
        VeaAl:
        gB7T1:
        goto Zzwje;
        vhIvJ:
    }
    public function saveItems(array $KvmA7) : void
    {
        foreach ($KvmA7 as $RCdwx) {
            goto F5a6r;
            k_abB:
            qZ_mo:
            goto l37Rz;
            F5a6r:
            $E3iDv = Cloud::find($RCdwx);
            goto NKoM5;
            IJAhW:
            Cloud::mTTcEFVFHoJ($x95Gi, StatusEnum::bbJJ_);
            goto i497N;
            NKoM5:
            if ($E3iDv) {
                goto PO6qf;
            }
            goto mIXHg;
            mIXHg:
            $x95Gi = Media::find($RCdwx);
            goto IJAhW;
            i497N:
            PO6qf:
            goto k_abB;
            l37Rz:
        }
        vcJY1:
    }
    public function delete(string $LpGEK) : void
    {
        $E3iDv = Cloud::findOrFail($LpGEK);
        $E3iDv->delete();
    }
}
