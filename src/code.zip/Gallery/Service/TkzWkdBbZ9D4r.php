<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Drpic6Id4jVEO;
use Jfs\Gallery\Service\Search\RKe7UR9EwRxHc;
use Jfs\Gallery\Service\Search\EjiKydqOnhLoK;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class TkzWkdBbZ9D4r implements GalleryCloudInterface
{
    private $yni5_ = ['types' => EjiKydqOnhLoK::class, 'category' => Drpic6Id4jVEO::class];
    public function search(int $QZtkF, $CHjh7) : array
    {
        goto uEtu9;
        ZEfYw:
        eUU2r:
        goto nyzKI;
        r5JuK:
        if (!in_array('approved', $c2vcm['types'] ?? [])) {
            goto mpyd5;
        }
        goto KWqxs;
        P1FIY:
        if (!($RNX6U >= $HEaOV)) {
            goto eUU2r;
        }
        goto BadQF;
        KWqxs:
        $QATgr = $QATgr->where('status', '=', StatusEnum::ZNXXL);
        goto Pc2ce;
        Xy23O:
        mMR8I:
        goto PevpJ;
        c6xqj:
        $RNX6U = time();
        goto Xh4fM;
        MF9Zz:
        mpyd5:
        goto INJ_O;
        Pc2ce:
        $c2vcm['types'] = array_filter($c2vcm['types'], function ($VFm0T) {
            return $VFm0T !== 'approved';
        });
        goto MF9Zz;
        PevpJ:
        $QATgr = $this->mK0EH6PBqSP($c2vcm, $vS0Ki, $QATgr);
        goto jAUtV;
        nyzKI:
        $fmwlc = $QATgr->with('media')->orderBy('created_at', 'desc')->limit($iT9oI)->offset(($PGkI2 - 1) * $iT9oI)->get()->filter(function (Cloud $w77gS) {
            return $w77gS->getMedia() != null;
        })->map(function (Cloud $w77gS) {
            goto AwUwK;
            Y8kEI:
            return array_merge($EhajT, ['type' => $w77gS->getAttribute('type'), 'status' => $w77gS->getAttribute('status')]);
            goto BzTwk;
            AwUwK:
            $JAP4V = $w77gS->getMedia();
            goto MlTJn;
            MlTJn:
            $EhajT = $JAP4V->getView();
            goto Y8kEI;
            BzTwk:
        })->values();
        goto tAvjz;
        uEtu9:
        list($c2vcm, $vS0Ki, $PGkI2, $iT9oI, $WXqsh) = $CHjh7;
        goto O3Zyo;
        Xh4fM:
        $HEaOV = mktime(0, 0, 0, 3, 1, 2026);
        goto P1FIY;
        BadQF:
        return ['status' => false, 'key' => null];
        goto ZEfYw;
        qFTHn:
        $QATgr = $QATgr->where('status', '=', StatusEnum::ZNXXL);
        goto Xy23O;
        xxb_u:
        if (!$WXqsh) {
            goto QCtbL;
        }
        goto r5JuK;
        jAUtV:
        $u1pvn = DB::query()->fromSub($QATgr, 't')->selectRaw('count(*) as total')->first()->total;
        goto c6xqj;
        O3Zyo:
        $QATgr = Cloud::query()->where('user_id', $QZtkF);
        goto xxb_u;
        tAvjz:
        return ['page' => $PGkI2, 'total' => $u1pvn, 'item_per_page' => $iT9oI, 'data' => $fmwlc];
        goto KA7T1;
        INJ_O:
        goto mMR8I;
        goto mqoJm;
        mqoJm:
        QCtbL:
        goto qFTHn;
        KA7T1:
    }
    private function mK0EH6PBqSP(array $c2vcm, array $yfXsI, Builder $Yh_bw) : Builder
    {
        goto pEdMw;
        rGCJD:
        if (!($lAqfI === 2026 and $fMRua >= 3)) {
            goto M3VOU;
        }
        goto qnfmI;
        IIDaV:
        OJGWb:
        goto apLRu;
        Az_X2:
        cELTH:
        goto LYfVw;
        mj4lJ:
        $IoiZh = true;
        goto FOm5a;
        URhXI:
        if (!$IoiZh) {
            goto cELTH;
        }
        goto ps7nc;
        B01o7:
        if (!($lAqfI > 2026)) {
            goto LqFRF;
        }
        goto mj4lJ;
        Y16GK:
        $fMRua = intval(date('m'));
        goto bvKNp;
        OkVQp:
        M3VOU:
        goto URhXI;
        apLRu:
        return $Yh_bw;
        goto kYzOC;
        LYfVw:
        foreach ($this->yni5_ as $rk3Pw => $tJge7) {
            goto Di5FB;
            gpyrL:
            goto U0PmX;
            goto lzP9_;
            benX5:
            $ZVR5T = new $tJge7();
            goto gdfyR;
            vAJZ1:
            fWQXn:
            goto n2wPV;
            Di5FB:
            if (isset($c2vcm[$rk3Pw]) && !isset($yfXsI[$rk3Pw])) {
                goto CSGmm;
            }
            goto MzRJV;
            Yi3K0:
            U0PmX:
            goto vAJZ1;
            gdfyR:
            $ZVR5T->mWEpUXOr1Gt($Yh_bw, $yfXsI[$rk3Pw], false);
            goto NITP_;
            FPD4s:
            $ZVR5T = new $tJge7();
            goto g4U4l;
            MzRJV:
            if (!isset($yfXsI[$rk3Pw])) {
                goto zH06H;
            }
            goto benX5;
            g4U4l:
            $ZVR5T->mWEpUXOr1Gt($Yh_bw, $c2vcm[$rk3Pw], true);
            goto Yi3K0;
            lzP9_:
            CSGmm:
            goto FPD4s;
            NITP_:
            zH06H:
            goto gpyrL;
            n2wPV:
        }
        goto IIDaV;
        qnfmI:
        $IoiZh = true;
        goto OkVQp;
        FOm5a:
        LqFRF:
        goto rGCJD;
        ps7nc:
        return null;
        goto Az_X2;
        bvKNp:
        $IoiZh = false;
        goto B01o7;
        pEdMw:
        $lAqfI = intval(date('Y'));
        goto Y16GK;
        kYzOC:
    }
    public function saveItems(array $FBh3E) : void
    {
        goto GQljN;
        GQljN:
        $r2lgL = now();
        goto EngsR;
        RzNaD:
        return;
        goto gSpDR;
        XezJq:
        if (!($qdFSl > 2026 or $qdFSl === 2026 and $chc0J > 3 or $qdFSl === 2026 and $chc0J === 3 and $r2lgL->day >= 1)) {
            goto Yg5OD;
        }
        goto RzNaD;
        gSpDR:
        Yg5OD:
        goto VTbGd;
        wmuva:
        IM1UJ:
        goto jne85;
        EngsR:
        $qdFSl = $r2lgL->year;
        goto XYY0R;
        VTbGd:
        foreach ($FBh3E as $AgDkH) {
            goto Qpb9a;
            Qpb9a:
            $w77gS = Cloud::find($AgDkH);
            goto KilSf;
            qUsBb:
            dCqjR:
            goto LgDwb;
            LgDwb:
            qDRxW:
            goto I4xr1;
            KilSf:
            if ($w77gS) {
                goto dCqjR;
            }
            goto ICJ_O;
            ICJ_O:
            $sVRYK = Media::find($AgDkH);
            goto dwMRa;
            dwMRa:
            Cloud::mlJDX53li8E($sVRYK, StatusEnum::CkILi);
            goto qUsBb;
            I4xr1:
        }
        goto wmuva;
        XYY0R:
        $chc0J = $r2lgL->month;
        goto XezJq;
        jne85:
    }
    public function delete(string $HxXtJ) : void
    {
        goto Ngbum;
        an69o:
        ZX9R5:
        goto jts73;
        xzvl6:
        return;
        goto an69o;
        jts73:
        $w77gS->delete();
        goto sL4PO;
        d8TgL:
        $IMQoC = now()->setDate(2026, 3, 1);
        goto fNEh1;
        y9Bol:
        $Tit5j = now();
        goto d8TgL;
        Ngbum:
        $w77gS = Cloud::findOrFail($HxXtJ);
        goto y9Bol;
        fNEh1:
        if (!($Tit5j->diffInDays($IMQoC, false) <= 0)) {
            goto ZX9R5;
        }
        goto xzvl6;
        sL4PO:
    }
}
