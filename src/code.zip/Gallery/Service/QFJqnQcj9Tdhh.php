<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\IJWaKE1RTZvz2;
use Jfs\Gallery\Service\Search\ABSmOmN8jVjWw;
use Jfs\Gallery\Service\Search\Fy5zthDkhR2Sr;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class QFJqnQcj9Tdhh implements GalleryCloudInterface
{
    private $gQRqS = ['types' => Fy5zthDkhR2Sr::class, 'category' => IJWaKE1RTZvz2::class];
    public function search(int $mN8kw, $YhoOw) : array
    {
        goto U8Oc4;
        zqa2k:
        nSm8C:
        goto l2Cz_;
        sfzJS:
        return ['page' => $b29rC, 'total' => $lKLJ9, 'item_per_page' => $XJxa7, 'data' => $COI2e];
        goto lJxHC;
        pODdV:
        $lKLJ9 = DB::query()->fromSub($sDU0B, 't')->selectRaw('count(*) as total')->first()->total;
        goto JHym0;
        iqmfN:
        $sDU0B = $sDU0B->where('status', '=', StatusEnum::PfxeM);
        goto ukQgT;
        Exkyc:
        ZZIuK:
        goto foFSA;
        ukQgT:
        $dd0hs['types'] = array_filter($dd0hs['types'], function ($OuM3O) {
            return $OuM3O !== 'approved';
        });
        goto Exkyc;
        UVBrV:
        $sDU0B = $sDU0B->where('status', '=', StatusEnum::PfxeM);
        goto zqa2k;
        JHym0:
        $COI2e = $sDU0B->with('media')->orderBy('created_at', 'desc')->limit($XJxa7)->offset(($b29rC - 1) * $XJxa7)->get()->filter(function (Cloud $DH7kR) {
            return $DH7kR->getMedia() != null;
        })->map(function (Cloud $DH7kR) {
            goto Z857X;
            pcGio:
            $Ww7Yi = $zr5kh->getView();
            goto P93LR;
            Z857X:
            $zr5kh = $DH7kR->getMedia();
            goto pcGio;
            P93LR:
            return array_merge($Ww7Yi, ['type' => $DH7kR->getAttribute('type'), 'status' => $DH7kR->getAttribute('status')]);
            goto uHvTC;
            uHvTC:
        })->values();
        goto sfzJS;
        Nln2R:
        if (!$u4Xgs) {
            goto CsDoS;
        }
        goto pnYDu;
        YNOTT:
        $sDU0B = Cloud::query()->where('user_id', $mN8kw);
        goto Nln2R;
        qTlYp:
        CsDoS:
        goto UVBrV;
        l2Cz_:
        $sDU0B = $this->mNS1SFnvRrZ($dd0hs, $xd7mR, $sDU0B);
        goto pODdV;
        pnYDu:
        if (!in_array('approved', $dd0hs['types'] ?? [])) {
            goto ZZIuK;
        }
        goto iqmfN;
        U8Oc4:
        list($dd0hs, $xd7mR, $b29rC, $XJxa7, $u4Xgs) = $YhoOw;
        goto YNOTT;
        foFSA:
        goto nSm8C;
        goto qTlYp;
        lJxHC:
    }
    private function mNS1SFnvRrZ(array $dd0hs, array $aGdM3, Builder $b3eGW) : Builder
    {
        goto SnC1r;
        SnC1r:
        foreach ($this->gQRqS as $wOeCL => $lCAxf) {
            goto a4_Za;
            v407h:
            $RwnxB->mfEhyMpa5RD($b3eGW, $dd0hs[$wOeCL]);
            goto ucqHn;
            chMSY:
            $RwnxB = new $lCAxf();
            goto ARR5c;
            ucqHn:
            a_x8G:
            goto j0Vqt;
            Y_CYt:
            ZJGEp:
            goto Ro6Rm;
            p2wnF:
            EpyQA:
            goto sdAEa;
            sdAEa:
            goto a_x8G;
            goto Y_CYt;
            WyIUg:
            if (!isset($aGdM3[$wOeCL])) {
                goto EpyQA;
            }
            goto chMSY;
            a4_Za:
            if (isset($dd0hs[$wOeCL]) && !isset($aGdM3[$wOeCL])) {
                goto ZJGEp;
            }
            goto WyIUg;
            j0Vqt:
            XZqnd:
            goto iThXj;
            ARR5c:
            $RwnxB->mfEhyMpa5RD($b3eGW, $aGdM3[$wOeCL], false);
            goto p2wnF;
            Ro6Rm:
            $RwnxB = new $lCAxf();
            goto v407h;
            iThXj:
        }
        goto JT2Fs;
        JT2Fs:
        bE7a2:
        goto T15lO;
        T15lO:
        return $b3eGW;
        goto nd1gx;
        nd1gx:
    }
    public function saveItems(array $BuswP) : void
    {
        foreach ($BuswP as $gNVOT) {
            goto nbpaZ;
            gt0cP:
            Cloud::m1tvVfvVjBB($FnmXY, StatusEnum::Ke2CU);
            goto Dn69f;
            IMuCz:
            $FnmXY = Media::find($gNVOT);
            goto gt0cP;
            lc9_H:
            if ($DH7kR) {
                goto AtWkj;
            }
            goto IMuCz;
            Dn69f:
            AtWkj:
            goto xomEX;
            nbpaZ:
            $DH7kR = Cloud::find($gNVOT);
            goto lc9_H;
            xomEX:
            f2AFk:
            goto r33_3;
            r33_3:
        }
        eMua9:
    }
    public function delete(string $S580N) : void
    {
        $DH7kR = Cloud::findOrFail($S580N);
        $DH7kR->delete();
    }
}
