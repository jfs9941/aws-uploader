<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Gallery\Service\Search\Z2XOEH6o8GLPS;
use Jfs\Gallery\Service\Search\IzAnV0kIIRlzN;
use Jfs\Gallery\Service\Search\ZNfqdDMft94dJ;
use Illuminate\Database\Eloquent\Builder;
final class UEJL05KV8YOjr implements GalleryCloudInterface
{
    private $sRLl6 = ['types' => ZNfqdDMft94dJ::class, 'category' => Z2XOEH6o8GLPS::class];
    public function search(int $W4GNe, $UXe4j) : array
    {
        goto lIdDa;
        peEhD:
        return ['page' => $SHDO3, 'total' => $Ywt1h, 'item_per_page' => $IQjkQ, 'data' => $paaTe];
        goto Z5fdh;
        IihtM:
        $paaTe = $TFa0I->with('media')->orderBy('created_at', 'desc')->limit($IQjkQ)->offset(($SHDO3 - 1) * $IQjkQ)->get()->filter(function (Cloud $OL7wC) {
            return $OL7wC->getMedia() != null;
        })->map(function (Cloud $OL7wC) {
            goto PCT5c;
            awAhq:
            $Q2Ihy = $ahBEB->getView();
            goto SVH3z;
            PCT5c:
            $ahBEB = $OL7wC->getMedia();
            goto awAhq;
            SVH3z:
            return array_merge($Q2Ihy, ['type' => $OL7wC->getAttribute('type'), 'status' => $OL7wC->getAttribute('status')]);
            goto rDJ3D;
            rDJ3D:
        })->values();
        goto peEhD;
        rnbIK:
        XTWaB:
        goto kVH5C;
        pnLPM:
        XzG9Y:
        goto KXP6t;
        H36TJ:
        $TFa0I = $TFa0I->where('status', '=', StatusEnum::f1bgw);
        goto Y32F5;
        QFYbA:
        if (!in_array('approved', $km6Gs['types'] ?? [])) {
            goto Rrrk3;
        }
        goto H36TJ;
        kVH5C:
        $TFa0I = $TFa0I->where('status', '=', StatusEnum::f1bgw);
        goto pnLPM;
        HGQQB:
        $TFa0I = Cloud::query()->where('user_id', $W4GNe);
        goto vWk1g;
        lIdDa:
        list($km6Gs, $G8MyN, $SHDO3, $IQjkQ, $kASFK) = $UXe4j;
        goto HGQQB;
        h7ZmQ:
        $Ywt1h = DB::query()->fromSub($TFa0I, 't')->selectRaw('count(*) as total')->first()->total;
        goto IihtM;
        Y32F5:
        $km6Gs['types'] = array_filter($km6Gs['types'], function ($poUpf) {
            return $poUpf !== 'approved';
        });
        goto fni0F;
        fni0F:
        Rrrk3:
        goto gDhQ8;
        vWk1g:
        if (!$kASFK) {
            goto XTWaB;
        }
        goto QFYbA;
        KXP6t:
        $TFa0I = $this->mHD0dAP1zvV($km6Gs, $G8MyN, $TFa0I);
        goto h7ZmQ;
        gDhQ8:
        goto XzG9Y;
        goto rnbIK;
        Z5fdh:
    }
    private function mHD0dAP1zvV(array $km6Gs, array $fPYxh, Builder $uXKnP) : Builder
    {
        goto mlerY;
        mlerY:
        foreach ($this->sRLl6 as $wK8hB => $tuar_) {
            goto MuX9L;
            JDw1I:
            if (!isset($fPYxh[$wK8hB])) {
                goto cd0U_;
            }
            goto qU8KN;
            moIuN:
            TyQN9:
            goto Cu3SY;
            cfC0t:
            goto wS0aZ;
            goto moIuN;
            Cu3SY:
            $ZLfN6 = new $tuar_();
            goto vYE0S;
            d0VSK:
            wS0aZ:
            goto wGit9;
            MuX9L:
            if (isset($km6Gs[$wK8hB]) && !isset($fPYxh[$wK8hB])) {
                goto TyQN9;
            }
            goto JDw1I;
            pVOof:
            cd0U_:
            goto cfC0t;
            vYkbC:
            $ZLfN6->mJIhndXL12f($uXKnP, $fPYxh[$wK8hB], false);
            goto pVOof;
            vYE0S:
            $ZLfN6->mJIhndXL12f($uXKnP, $km6Gs[$wK8hB]);
            goto d0VSK;
            qU8KN:
            $ZLfN6 = new $tuar_();
            goto vYkbC;
            wGit9:
            ERjvC:
            goto fNk52;
            fNk52:
        }
        goto yzbqB;
        yzbqB:
        hqvjL:
        goto DTmiD;
        DTmiD:
        return $uXKnP;
        goto Tw0tD;
        Tw0tD:
    }
    public function saveItems(array $UkJJQ) : void
    {
        foreach ($UkJJQ as $tscCi) {
            goto Z8iGg;
            Z8iGg:
            $OL7wC = Cloud::find($tscCi);
            goto z2U_J;
            mjIts:
            Fr_CS:
            goto GfqK5;
            uRW4l:
            $wF34p = Media::find($tscCi);
            goto fCoY1;
            fCoY1:
            Cloud::mEgQTKJs9AQ($wF34p, StatusEnum::bjYZV);
            goto EtdO7;
            z2U_J:
            if ($OL7wC) {
                goto jvann;
            }
            goto uRW4l;
            EtdO7:
            jvann:
            goto mjIts;
            GfqK5:
        }
        Vz8rW:
    }
    public function delete(string $cQqZd) : void
    {
        $OL7wC = Cloud::findOrFail($cQqZd);
        $OL7wC->delete();
    }
}
