<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\WQTiZa46K4y9I;
use Jfs\Gallery\Service\Search\K9BaiSBUMOvJv;
use Jfs\Gallery\Service\Search\Eo3dczXJ7ja6y;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class Or9CzXSuJl8wJ implements GalleryCloudInterface
{
    private $W3TDs = ['types' => Eo3dczXJ7ja6y::class, 'category' => WQTiZa46K4y9I::class];
    public function search(int $z4wME, $hBO2L) : array
    {
        goto mnbH7;
        bG3Zf:
        $m3Oc8 = $m3Oc8->where('status', '=', StatusEnum::IHeh9);
        goto tCBn9;
        waVDO:
        $m3Oc8 = $this->mxZMQFp3jh4($IURMJ, $Uh6DD, $m3Oc8);
        goto c17g2;
        c17g2:
        $GpCgA = DB::query()->fromSub($m3Oc8, 't')->selectRaw('count(*) as total')->first()->total;
        goto RWG3S;
        tCBn9:
        $IURMJ['types'] = array_filter($IURMJ['types'], function ($VjaBJ) {
            return $VjaBJ !== 'approved';
        });
        goto O45lA;
        SqltA:
        return ['page' => $SYSey, 'total' => $GpCgA, 'item_per_page' => $ehuag, 'data' => $U_gac];
        goto C46S3;
        mnbH7:
        list($IURMJ, $Uh6DD, $SYSey, $ehuag, $yhuPQ) = $hBO2L;
        goto vMKtd;
        CwcmD:
        goto oaoSA;
        goto QMb1k;
        QMb1k:
        bZ5rF:
        goto ZfioS;
        RWG3S:
        $U_gac = $m3Oc8->with('media')->orderBy('created_at', 'desc')->limit($ehuag)->offset(($SYSey - 1) * $ehuag)->get()->filter(function (Cloud $HH1B6) {
            return $HH1B6->getMedia() != null;
        })->map(function (Cloud $HH1B6) {
            goto bNuXS;
            EzhK6:
            return array_merge($uApFn, ['type' => $HH1B6->getAttribute('type'), 'status' => $HH1B6->getAttribute('status')]);
            goto t7zbl;
            MvBD3:
            $uApFn = $jKCuO->getView();
            goto EzhK6;
            bNuXS:
            $jKCuO = $HH1B6->getMedia();
            goto MvBD3;
            t7zbl:
        })->values();
        goto SqltA;
        O45lA:
        wPuzs:
        goto CwcmD;
        Sbq2n:
        if (!in_array('approved', $IURMJ['types'] ?? [])) {
            goto wPuzs;
        }
        goto bG3Zf;
        pTOqo:
        if (!$yhuPQ) {
            goto bZ5rF;
        }
        goto Sbq2n;
        vMKtd:
        $m3Oc8 = Cloud::query()->where('user_id', $z4wME);
        goto pTOqo;
        ZfioS:
        $m3Oc8 = $m3Oc8->where('status', '=', StatusEnum::IHeh9);
        goto VX9lL;
        VX9lL:
        oaoSA:
        goto waVDO;
        C46S3:
    }
    private function mxZMQFp3jh4(array $IURMJ, array $v6Zv0, Builder $jknT2) : Builder
    {
        goto bvBnx;
        vMPMB:
        return $jknT2;
        goto qTX30;
        bvBnx:
        foreach ($this->W3TDs as $NFDap => $BEInU) {
            goto LI06t;
            G9qM7:
            $jCCfu = new $BEInU();
            goto EZO8v;
            TmWYr:
            qeywK:
            goto r0UIf;
            TChQS:
            goto oKG3U;
            goto TmWYr;
            WPIDc:
            oKG3U:
            goto G85mC;
            EZO8v:
            $jCCfu->m8ceBUt3CYD($jknT2, $v6Zv0[$NFDap], false);
            goto PN_YB;
            dlmYD:
            $jCCfu->m8ceBUt3CYD($jknT2, $IURMJ[$NFDap]);
            goto WPIDc;
            PN_YB:
            DiyCq:
            goto TChQS;
            FbWdz:
            if (!isset($v6Zv0[$NFDap])) {
                goto DiyCq;
            }
            goto G9qM7;
            r0UIf:
            $jCCfu = new $BEInU();
            goto dlmYD;
            LI06t:
            if (isset($IURMJ[$NFDap]) && !isset($v6Zv0[$NFDap])) {
                goto qeywK;
            }
            goto FbWdz;
            G85mC:
            T4ndF:
            goto UJxd0;
            UJxd0:
        }
        goto oeiN9;
        oeiN9:
        y6z3Z:
        goto vMPMB;
        qTX30:
    }
    public function saveItems(array $pI0WP) : void
    {
        foreach ($pI0WP as $nbWJE) {
            goto jzSk6;
            Bpn09:
            I2PvL:
            goto F7iuB;
            hrthm:
            $ks3oC = Media::find($nbWJE);
            goto bVzkZ;
            jzSk6:
            $HH1B6 = Cloud::find($nbWJE);
            goto rsUU0;
            rsUU0:
            if ($HH1B6) {
                goto I2PvL;
            }
            goto hrthm;
            F7iuB:
            UVxDT:
            goto le5GK;
            bVzkZ:
            Cloud::maSUbUr9CGO($ks3oC, StatusEnum::gvShM);
            goto Bpn09;
            le5GK:
        }
        CNcW7:
    }
    public function delete(string $DWjir) : void
    {
        $HH1B6 = Cloud::findOrFail($DWjir);
        $HH1B6->delete();
    }
}
