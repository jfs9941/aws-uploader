<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\EfMYRSXCMTbEZ;
use Jfs\Gallery\Service\Search\Yr6SLx1QUngeE;
use Jfs\Gallery\Service\Search\UpkFhW0pe6brH;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class JlFZ7iGHeBLrc implements GalleryCloudInterface
{
    private $wjdPt = ['types' => UpkFhW0pe6brH::class, 'category' => EfMYRSXCMTbEZ::class];
    public function search(int $zJG5Z, $W8VFT) : array
    {
        goto VD8sP;
        tBmbo:
        $sx0QZ = $PMBr6->with('media')->orderBy('created_at', 'desc')->limit($RCD2m)->offset(($p_S_z - 1) * $RCD2m)->get()->filter(function (Cloud $C0I5K) {
            return $C0I5K->getMedia() != null;
        })->map(function (Cloud $C0I5K) {
            goto NRJwb;
            mhyZ3:
            $nv2Qs = $pDny3->getView();
            goto DzbRP;
            DzbRP:
            return array_merge($nv2Qs, ['type' => $C0I5K->getAttribute('type'), 'status' => $C0I5K->getAttribute('status')]);
            goto ASVDn;
            NRJwb:
            $pDny3 = $C0I5K->getMedia();
            goto mhyZ3;
            ASVDn:
        })->values();
        goto OiP3s;
        VD8sP:
        list($jSFb5, $geuOh, $p_S_z, $RCD2m, $KOYWG) = $W8VFT;
        goto uEt1X;
        uEt1X:
        $PMBr6 = Cloud::query()->where('user_id', $zJG5Z);
        goto ZVv1n;
        Yi7xv:
        $QWjxg = DB::query()->fromSub($PMBr6, 't')->selectRaw('count(*) as total')->first()->total;
        goto tBmbo;
        di1Lv:
        Pfzqr:
        goto sDPbt;
        RdQ_T:
        $jSFb5['types'] = array_filter($jSFb5['types'], function ($qD8wd) {
            return $qD8wd !== 'approved';
        });
        goto XCgQH;
        HL3tF:
        $PMBr6 = $PMBr6->where('status', '=', StatusEnum::mULpP);
        goto RdQ_T;
        aR46S:
        $PMBr6 = $this->mHgjXm7aYfG($jSFb5, $geuOh, $PMBr6);
        goto Yi7xv;
        XPs8h:
        FX2lU:
        goto aR46S;
        sDPbt:
        $PMBr6 = $PMBr6->where('status', '=', StatusEnum::mULpP);
        goto XPs8h;
        ZVv1n:
        if (!$KOYWG) {
            goto Pfzqr;
        }
        goto lbC9D;
        lbC9D:
        if (!in_array('approved', $jSFb5['types'] ?? [])) {
            goto EcWBq;
        }
        goto HL3tF;
        XCgQH:
        EcWBq:
        goto dqUaE;
        OiP3s:
        return ['page' => $p_S_z, 'total' => $QWjxg, 'item_per_page' => $RCD2m, 'data' => $sx0QZ];
        goto h1tp3;
        dqUaE:
        goto FX2lU;
        goto di1Lv;
        h1tp3:
    }
    private function mHgjXm7aYfG(array $jSFb5, array $J3TIN, Builder $LRBQB) : Builder
    {
        goto cqLm7;
        tIw49:
        return $LRBQB;
        goto sXtKg;
        n0uk0:
        U2YG8:
        goto tIw49;
        cqLm7:
        foreach ($this->wjdPt as $uzG79 => $Ou99_) {
            goto IfLEc;
            wpFql:
            HTP6U:
            goto FNl0o;
            KF05g:
            $ypmXW = new $Ou99_();
            goto NvoyU;
            NvoyU:
            $ypmXW->mRdnFSEH1J0($LRBQB, $J3TIN[$uzG79], false);
            goto LzW4v;
            G2HfR:
            fSlcl:
            goto q7xkL;
            IfLEc:
            if (isset($jSFb5[$uzG79]) && !isset($J3TIN[$uzG79])) {
                goto fSlcl;
            }
            goto e0xyf;
            LzW4v:
            vLo7l:
            goto ZGK_u;
            e0xyf:
            if (!isset($J3TIN[$uzG79])) {
                goto vLo7l;
            }
            goto KF05g;
            DdU0V:
            $ypmXW->mRdnFSEH1J0($LRBQB, $jSFb5[$uzG79]);
            goto gDyCD;
            ZGK_u:
            goto IsMUQ;
            goto G2HfR;
            gDyCD:
            IsMUQ:
            goto wpFql;
            q7xkL:
            $ypmXW = new $Ou99_();
            goto DdU0V;
            FNl0o:
        }
        goto n0uk0;
        sXtKg:
    }
    public function saveItems(array $KcmLQ) : void
    {
        foreach ($KcmLQ as $spSJx) {
            goto pEwLF;
            uRLwM:
            if ($C0I5K) {
                goto EqsXu;
            }
            goto piHeq;
            lczPi:
            Cloud::mcYgkPzCWFw($VSIgF, StatusEnum::j65Fg);
            goto MzlpQ;
            pEwLF:
            $C0I5K = Cloud::find($spSJx);
            goto uRLwM;
            MzlpQ:
            EqsXu:
            goto V4Zol;
            piHeq:
            $VSIgF = Media::find($spSJx);
            goto lczPi;
            V4Zol:
            SRFTe:
            goto x9BuA;
            x9BuA:
        }
        iVpL8:
    }
    public function delete(string $GhyxD) : void
    {
        $C0I5K = Cloud::findOrFail($GhyxD);
        $C0I5K->delete();
    }
}
