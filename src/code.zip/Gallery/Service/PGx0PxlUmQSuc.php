<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\AquEvtCyrVDsB;
use Jfs\Gallery\Service\Search\U0EK8U2OUwM4T;
use Jfs\Gallery\Service\Search\FI9Bt583XnkLm;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class PGx0PxlUmQSuc implements GalleryCloudInterface
{
    private $FdxKd = ['types' => FI9Bt583XnkLm::class, 'category' => AquEvtCyrVDsB::class];
    public function search(int $Vz1ad, $J5Q0n) : array
    {
        goto u2qrW;
        Dx9nh:
        if (!in_array('approved', $TkUR9['types'] ?? [])) {
            goto lxjKk;
        }
        goto GTy06;
        IXJzs:
        $TkUR9['types'] = array_filter($TkUR9['types'], function ($dZxXC) {
            return $dZxXC !== 'approved';
        });
        goto dcu0M;
        RPiCz:
        $bR5ad = $this->m6YNbe2KcSW($TkUR9, $BR63x, $bR5ad);
        goto hCAoo;
        oHxJr:
        $bR5ad = Cloud::query()->where('user_id', $Vz1ad);
        goto B3L61;
        hCAoo:
        $J7rT9 = DB::query()->fromSub($bR5ad, 't')->selectRaw('count(*) as total')->first()->total;
        goto wUhqw;
        EbSNV:
        return ['page' => $UiPJC, 'total' => $J7rT9, 'item_per_page' => $yTyvF, 'data' => $aCVXA];
        goto YlOcH;
        wUhqw:
        $aCVXA = $bR5ad->with('media')->orderBy('created_at', 'desc')->limit($yTyvF)->offset(($UiPJC - 1) * $yTyvF)->get()->filter(function (Cloud $g0W1R) {
            return $g0W1R->getMedia() != null;
        })->map(function (Cloud $g0W1R) {
            goto pTTLw;
            zRDRS:
            return array_merge($HjRng, ['type' => $g0W1R->getAttribute('type'), 'status' => $g0W1R->getAttribute('status')]);
            goto tRhxP;
            rVwVq:
            $HjRng = $lOhz0->getView();
            goto zRDRS;
            pTTLw:
            $lOhz0 = $g0W1R->getMedia();
            goto rVwVq;
            tRhxP:
        })->values();
        goto EbSNV;
        OEjUb:
        k7eBm:
        goto RPiCz;
        Tgy1G:
        goto k7eBm;
        goto f73Ct;
        u2qrW:
        list($TkUR9, $BR63x, $UiPJC, $yTyvF, $XuVuj) = $J5Q0n;
        goto oHxJr;
        dcu0M:
        lxjKk:
        goto Tgy1G;
        f73Ct:
        c_ajf:
        goto jjCHq;
        GTy06:
        $bR5ad = $bR5ad->where('status', '=', StatusEnum::hVd6T);
        goto IXJzs;
        B3L61:
        if (!$XuVuj) {
            goto c_ajf;
        }
        goto Dx9nh;
        jjCHq:
        $bR5ad = $bR5ad->where('status', '=', StatusEnum::hVd6T);
        goto OEjUb;
        YlOcH:
    }
    private function m6YNbe2KcSW(array $TkUR9, array $Cxu1S, Builder $lqRvU) : Builder
    {
        goto q0zFC;
        U4Xd4:
        return $lqRvU;
        goto KUvfD;
        kxNzy:
        rtXz8:
        goto U4Xd4;
        q0zFC:
        foreach ($this->FdxKd as $B2O0Z => $jSeja) {
            goto NadzH;
            tFGJt:
            $Ny35c->mAKe1GASNgN($lqRvU, $TkUR9[$B2O0Z]);
            goto zB3g5;
            zB3g5:
            HJ8KI:
            goto Dc5y8;
            bSqZz:
            $Ny35c->mAKe1GASNgN($lqRvU, $Cxu1S[$B2O0Z], false);
            goto bdbyT;
            Dc5y8:
            Oq0zU:
            goto Do1Jj;
            bOC3Z:
            goto HJ8KI;
            goto WT5jz;
            bdbyT:
            BjF_i:
            goto bOC3Z;
            WT5jz:
            SoOzo:
            goto sG3Vk;
            xmCp5:
            $Ny35c = new $jSeja();
            goto bSqZz;
            TVSi_:
            if (!isset($Cxu1S[$B2O0Z])) {
                goto BjF_i;
            }
            goto xmCp5;
            sG3Vk:
            $Ny35c = new $jSeja();
            goto tFGJt;
            NadzH:
            if (isset($TkUR9[$B2O0Z]) && !isset($Cxu1S[$B2O0Z])) {
                goto SoOzo;
            }
            goto TVSi_;
            Do1Jj:
        }
        goto kxNzy;
        KUvfD:
    }
    public function saveItems(array $UrI3s) : void
    {
        foreach ($UrI3s as $ZPsYd) {
            goto IUoY1;
            C5_dc:
            if ($g0W1R) {
                goto iHHX8;
            }
            goto Jrko3;
            UYyRE:
            bTCsf:
            goto VEjV0;
            lbkm3:
            Cloud::mlSaVKasf6N($uC0lG, StatusEnum::pbYRO);
            goto nMs0t;
            nMs0t:
            iHHX8:
            goto UYyRE;
            IUoY1:
            $g0W1R = Cloud::find($ZPsYd);
            goto C5_dc;
            Jrko3:
            $uC0lG = Media::find($ZPsYd);
            goto lbkm3;
            VEjV0:
        }
        PwZqi:
    }
    public function delete(string $qMhfW) : void
    {
        $g0W1R = Cloud::findOrFail($qMhfW);
        $g0W1R->delete();
    }
}
