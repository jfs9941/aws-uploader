<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Service\Search\Tp6tWcRRLRlQL;
use Jfs\Gallery\Service\Search\YDoxP2uDkUDkB;
use Jfs\Gallery\Service\Search\Q9W2344gtYANN;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
final class MOdNdLRLdg1gi implements GalleryCloudInterface
{
    private $dy4pl = ['types' => Q9W2344gtYANN::class, 'category' => Tp6tWcRRLRlQL::class];
    public function search(int $aG8Gq, $u84Mk) : array
    {
        goto HDNiK;
        Cd3sA:
        $mhKwM = $mhKwM->where('status', '=', StatusEnum::sYto1);
        goto hSsgf;
        ixLxb:
        $z1Ewt = DB::query()->fromSub($mhKwM, 't')->selectRaw('count(*) as total')->first()->total;
        goto SiBsz;
        fbSEW:
        if (!$J8qI8) {
            goto qRYDo;
        }
        goto BCdPU;
        wJLKk:
        $ZPd4o['types'] = array_filter($ZPd4o['types'], function ($pPQJ0) {
            return $pPQJ0 !== 'approved';
        });
        goto TreOK;
        q32j3:
        $mhKwM = Cloud::query()->where('user_id', $aG8Gq);
        goto fbSEW;
        TreOK:
        k1GP7:
        goto lfaXn;
        hSsgf:
        eOEvc:
        goto S5heK;
        am9lm:
        qRYDo:
        goto Cd3sA;
        M8WGO:
        return ['page' => $woIAb, 'total' => $z1Ewt, 'item_per_page' => $pN_vF, 'data' => $fC1nN];
        goto bNpRY;
        S5heK:
        $mhKwM = $this->mo9IcCc7mzE($ZPd4o, $bfKa0, $mhKwM);
        goto ixLxb;
        SiBsz:
        $fC1nN = $mhKwM->with('media')->orderBy('created_at', 'desc')->limit($pN_vF)->offset(($woIAb - 1) * $pN_vF)->get()->filter(function (Cloud $RDasi) {
            return $RDasi->getMedia() != null;
        })->map(function (Cloud $RDasi) {
            goto PIetB;
            B13PH:
            return array_merge($ZUnAd, ['type' => $RDasi->getAttribute('type'), 'status' => $RDasi->getAttribute('status')]);
            goto OyH2N;
            PIetB:
            $g1333 = $RDasi->getMedia();
            goto FJJfo;
            FJJfo:
            $ZUnAd = $g1333->getView();
            goto B13PH;
            OyH2N:
        })->values();
        goto M8WGO;
        HDNiK:
        list($ZPd4o, $bfKa0, $woIAb, $pN_vF, $J8qI8) = $u84Mk;
        goto q32j3;
        mUHp7:
        $mhKwM = $mhKwM->where('status', '=', StatusEnum::sYto1);
        goto wJLKk;
        BCdPU:
        if (!in_array('approved', $ZPd4o['types'] ?? [])) {
            goto k1GP7;
        }
        goto mUHp7;
        lfaXn:
        goto eOEvc;
        goto am9lm;
        bNpRY:
    }
    private function mo9IcCc7mzE(array $ZPd4o, array $nDm8s, Builder $YLIIQ) : Builder
    {
        goto Cbc0R;
        BoIYM:
        nAjYd:
        goto GHtpa;
        GHtpa:
        return $YLIIQ;
        goto pO2Lt;
        Cbc0R:
        foreach ($this->dy4pl as $BXZ6y => $qyWRw) {
            goto RnQ12;
            LaeyC:
            TBtJ0:
            goto fUgCB;
            SyTnf:
            $JczTi = new $qyWRw();
            goto cVHGV;
            DSSrG:
            $JczTi->mMgITLYL4m6($YLIIQ, $nDm8s[$BXZ6y], false);
            goto Ej0AC;
            jC_Yz:
            goto TBtJ0;
            goto fO21U;
            dwVLE:
            if (!isset($nDm8s[$BXZ6y])) {
                goto x4H1v;
            }
            goto CX42r;
            RnQ12:
            if (isset($ZPd4o[$BXZ6y]) && !isset($nDm8s[$BXZ6y])) {
                goto wMFlZ;
            }
            goto dwVLE;
            Ej0AC:
            x4H1v:
            goto jC_Yz;
            fUgCB:
            OMUwZ:
            goto pK1JL;
            CX42r:
            $JczTi = new $qyWRw();
            goto DSSrG;
            fO21U:
            wMFlZ:
            goto SyTnf;
            cVHGV:
            $JczTi->mMgITLYL4m6($YLIIQ, $ZPd4o[$BXZ6y]);
            goto LaeyC;
            pK1JL:
        }
        goto BoIYM;
        pO2Lt:
    }
    public function saveItems(array $Gt72s) : void
    {
        foreach ($Gt72s as $rQ18B) {
            goto tPIKi;
            ekGZy:
            eT3Ih:
            goto B0WIi;
            vT6Tj:
            Cloud::mhmihv57TRw($v17Df, StatusEnum::np3o3);
            goto ekGZy;
            m9tWQ:
            $v17Df = Media::find($rQ18B);
            goto vT6Tj;
            tPIKi:
            $RDasi = Cloud::find($rQ18B);
            goto uiA1G;
            uiA1G:
            if ($RDasi) {
                goto eT3Ih;
            }
            goto m9tWQ;
            B0WIi:
            nfW27:
            goto CKZuj;
            CKZuj:
        }
        q2RpE:
    }
    public function delete(string $mfjeD) : void
    {
        $RDasi = Cloud::findOrFail($mfjeD);
        $RDasi->delete();
    }
}
