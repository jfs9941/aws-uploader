<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\SKKED1C9QLrr4;
use Jfs\Gallery\Service\Search\B1WYSVwQbhFq4;
use Jfs\Gallery\Service\Search\MyVOVzLeB1K52;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class OYQwG3YORcksS implements GalleryCloudInterface
{
    private $FR9m3 = ['types' => MyVOVzLeB1K52::class, 'category' => SKKED1C9QLrr4::class];
    public function search(int $veFJs, $FD03m) : array
    {
        goto DwdWx;
        DwdWx:
        list($g01jt, $Vjbeo, $zQfDw, $D7SeS, $OM8hC) = $FD03m;
        goto JyQQ2;
        Kmqy4:
        $meAZB = $meAZB->where('status', '=', StatusEnum::k16KO);
        goto SsUul;
        Vk_EP:
        XVGoh:
        goto whBCl;
        geV4q:
        $meAZB = $meAZB->where('status', '=', StatusEnum::k16KO);
        goto yXQaa;
        whBCl:
        goto KR5Ep;
        goto wnd0m;
        SsUul:
        $g01jt['types'] = array_filter($g01jt['types'], function ($NfkgP) {
            return $NfkgP !== 'approved';
        });
        goto Vk_EP;
        zf0PI:
        $DUsxo = $meAZB->with('media')->orderBy('created_at', 'desc')->limit($D7SeS)->offset(($zQfDw - 1) * $D7SeS)->get()->filter(function (Cloud $EQirB) {
            return $EQirB->getMedia() != null;
        })->map(function (Cloud $EQirB) {
            goto QUSu3;
            PaP8Y:
            $jMZeL = $mCZRt->getView();
            goto ac03u;
            ac03u:
            return array_merge($jMZeL, ['type' => $EQirB->getAttribute('type'), 'status' => $EQirB->getAttribute('status')]);
            goto jEVIT;
            QUSu3:
            $mCZRt = $EQirB->getMedia();
            goto PaP8Y;
            jEVIT:
        })->values();
        goto fZOwQ;
        yXQaa:
        KR5Ep:
        goto UcVBn;
        fZOwQ:
        return ['page' => $zQfDw, 'total' => $Blw2j, 'item_per_page' => $D7SeS, 'data' => $DUsxo];
        goto H62Vb;
        UcVBn:
        $meAZB = $this->mWjR6bf4nVP($g01jt, $Vjbeo, $meAZB);
        goto IPwoD;
        h6Hpa:
        if (!$OM8hC) {
            goto zWGhW;
        }
        goto buIkx;
        JyQQ2:
        $meAZB = Cloud::query()->where('user_id', $veFJs);
        goto h6Hpa;
        IPwoD:
        $Blw2j = DB::query()->fromSub($meAZB, 't')->selectRaw('count(*) as total')->first()->total;
        goto zf0PI;
        buIkx:
        if (!in_array('approved', $g01jt['types'] ?? [])) {
            goto XVGoh;
        }
        goto Kmqy4;
        wnd0m:
        zWGhW:
        goto geV4q;
        H62Vb:
    }
    private function mWjR6bf4nVP(array $g01jt, array $fioRs, Builder $ZdnGh) : Builder
    {
        goto rTwlv;
        kZyHq:
        return $ZdnGh;
        goto u1HXO;
        UuCUa:
        NsusG:
        goto kZyHq;
        rTwlv:
        foreach ($this->FR9m3 as $Zh9Od => $cyQvz) {
            goto WBTK_;
            NF_gD:
            ttbH2:
            goto SKT7O;
            C3L10:
            $rWFyW->mBV6RLZw0Oj($ZdnGh, $g01jt[$Zh9Od], true);
            goto NF_gD;
            bSklH:
            LqNvz:
            goto Wvg8A;
            Wvg8A:
            $rWFyW = new $cyQvz();
            goto C3L10;
            C_W_I:
            iL4Jw:
            goto MHtsv;
            SKT7O:
            GTwgc:
            goto Q7o1r;
            MHtsv:
            goto ttbH2;
            goto bSklH;
            Rqb55:
            $rWFyW->mBV6RLZw0Oj($ZdnGh, $fioRs[$Zh9Od], false);
            goto C_W_I;
            imqnR:
            $rWFyW = new $cyQvz();
            goto Rqb55;
            sdHLe:
            if (!isset($fioRs[$Zh9Od])) {
                goto iL4Jw;
            }
            goto imqnR;
            WBTK_:
            if (isset($g01jt[$Zh9Od]) && !isset($fioRs[$Zh9Od])) {
                goto LqNvz;
            }
            goto sdHLe;
            Q7o1r:
        }
        goto UuCUa;
        u1HXO:
    }
    public function saveItems(array $eivI8) : void
    {
        foreach ($eivI8 as $D55CH) {
            goto a3cW3;
            ajtPF:
            LtjAQ:
            goto H3AX1;
            hXNeb:
            Qd60n:
            goto ajtPF;
            a3cW3:
            $EQirB = Cloud::find($D55CH);
            goto WC2C_;
            XsAjR:
            $UTk4B = Media::find($D55CH);
            goto M0ncN;
            WC2C_:
            if ($EQirB) {
                goto Qd60n;
            }
            goto XsAjR;
            M0ncN:
            Cloud::mI8Tq0L0Zu3($UTk4B, StatusEnum::tEm4c);
            goto hXNeb;
            H3AX1:
        }
        DolYy:
    }
    public function delete(string $iG1wy) : void
    {
        $EQirB = Cloud::findOrFail($iG1wy);
        $EQirB->delete();
    }
}
