<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Gallery\Service\Search\MSoABmRwCVCfr;
use Jfs\Gallery\Service\Search\OzMM4FQspdFDS;
use Jfs\Gallery\Service\Search\GbFpezpTmLLx1;
use Illuminate\Database\Eloquent\Builder;
final class VBaUDvlE7QYCo implements GalleryCloudInterface
{
    private $ulpI_ = ['types' => GbFpezpTmLLx1::class, 'category' => MSoABmRwCVCfr::class];
    public function search(int $swalJ, $GOisQ) : array
    {
        goto sO_cL;
        A319k:
        goto VoHV2;
        goto HnSt6;
        usFQS:
        VoHV2:
        goto m0r2u;
        V8a4w:
        return ['page' => $e3hQJ, 'total' => $ksBRL, 'item_per_page' => $q7tyw, 'data' => $hrLIq];
        goto vFcY6;
        sO_cL:
        list($tB8oC, $OR7AR, $e3hQJ, $q7tyw, $l8L9_) = $GOisQ;
        goto vDjAQ;
        GswWF:
        if (!$l8L9_) {
            goto McnMr;
        }
        goto cVcv0;
        gIJMW:
        $ksBRL = DB::query()->fromSub($SXrag, 't')->selectRaw('count(*) as total')->first()->total;
        goto NBOB0;
        m0r2u:
        $SXrag = $this->mcpddEo5m3Q($tB8oC, $OR7AR, $SXrag);
        goto gIJMW;
        HnSt6:
        McnMr:
        goto TtwkC;
        cVcv0:
        if (!in_array('approved', $tB8oC['types'] ?? [])) {
            goto jckqC;
        }
        goto A4W3Z;
        A4W3Z:
        $SXrag = $SXrag->where('status', '=', StatusEnum::BV09n);
        goto hl_0H;
        hl_0H:
        $tB8oC['types'] = array_filter($tB8oC['types'], function ($XtJKV) {
            return $XtJKV !== 'approved';
        });
        goto SdOUZ;
        NBOB0:
        $hrLIq = $SXrag->with('media')->orderBy('created_at', 'desc')->limit($q7tyw)->offset(($e3hQJ - 1) * $q7tyw)->get()->filter(function (Cloud $frm9u) {
            return $frm9u->getMedia() != null;
        })->map(function (Cloud $frm9u) {
            goto nZ1wa;
            ipZ4j:
            $faVyj = $BOX5t->getView();
            goto ewym0;
            ewym0:
            return array_merge($faVyj, ['type' => $frm9u->getAttribute('type'), 'status' => $frm9u->getAttribute('status')]);
            goto cB2_W;
            nZ1wa:
            $BOX5t = $frm9u->getMedia();
            goto ipZ4j;
            cB2_W:
        })->values();
        goto V8a4w;
        TtwkC:
        $SXrag = $SXrag->where('status', '=', StatusEnum::BV09n);
        goto usFQS;
        vDjAQ:
        $SXrag = Cloud::query()->where('user_id', $swalJ);
        goto GswWF;
        SdOUZ:
        jckqC:
        goto A319k;
        vFcY6:
    }
    private function mcpddEo5m3Q(array $tB8oC, array $z5irm, Builder $DGS9z) : Builder
    {
        goto syLXY;
        syLXY:
        foreach ($this->ulpI_ as $Bg1lx => $p_M2T) {
            goto grDjd;
            t_oH1:
            $b3960->mbbjz07Cd8J($DGS9z, $z5irm[$Bg1lx], false);
            goto wR_U2;
            zforF:
            $b3960->mbbjz07Cd8J($DGS9z, $tB8oC[$Bg1lx]);
            goto qDycp;
            XNyxO:
            goto NNUiY;
            goto p2X6y;
            FKjXH:
            tDwc9:
            goto HQuMf;
            p2X6y:
            s3IGr:
            goto Dc5uf;
            vIYao:
            if (!isset($z5irm[$Bg1lx])) {
                goto GbEcM;
            }
            goto vO89x;
            wR_U2:
            GbEcM:
            goto XNyxO;
            qDycp:
            NNUiY:
            goto FKjXH;
            grDjd:
            if (isset($tB8oC[$Bg1lx]) && !isset($z5irm[$Bg1lx])) {
                goto s3IGr;
            }
            goto vIYao;
            Dc5uf:
            $b3960 = new $p_M2T();
            goto zforF;
            vO89x:
            $b3960 = new $p_M2T();
            goto t_oH1;
            HQuMf:
        }
        goto S_3sX;
        S_3sX:
        Ooqz6:
        goto Q5Qh0;
        Q5Qh0:
        return $DGS9z;
        goto CjVX8;
        CjVX8:
    }
    public function saveItems(array $H3IvO) : void
    {
        foreach ($H3IvO as $xdi9a) {
            goto Txqgg;
            u0oAU:
            $js0c_ = Media::find($xdi9a);
            goto ZSnWF;
            MaApz:
            NNKaj:
            goto X6h53;
            yTbnp:
            if ($frm9u) {
                goto NNKaj;
            }
            goto u0oAU;
            Txqgg:
            $frm9u = Cloud::find($xdi9a);
            goto yTbnp;
            ZSnWF:
            Cloud::mD5M3nBzpGG($js0c_, StatusEnum::LuNDK);
            goto MaApz;
            X6h53:
            i6k8c:
            goto Ad8Fg;
            Ad8Fg:
        }
        P_r2E:
    }
    public function delete(string $R7IrL) : void
    {
        $frm9u = Cloud::findOrFail($R7IrL);
        $frm9u->delete();
    }
}
