<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\GvLXvaOTfenRc;
use Jfs\Gallery\Service\Search\UjCdlzMnPdCKC;
use Jfs\Gallery\Service\Search\OaaIy59IME9Kv;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class B38tXjPCvNZ7f implements GalleryCloudInterface
{
    private $EU09g = ['types' => OaaIy59IME9Kv::class, 'category' => GvLXvaOTfenRc::class];
    public function search(int $hxvZ_, $rAcJI) : array
    {
        goto ujrts;
        BH8pS:
        egYFn:
        goto z2G2t;
        z2G2t:
        goto VbyIz;
        goto G1iD7;
        G1iD7:
        D3uFF:
        goto ERGtn;
        YlE0l:
        $YRL6p = $YRL6p->where('status', '=', StatusEnum::vq4Bw);
        goto C9uUf;
        aY_ZZ:
        return ['page' => $IYU0f, 'total' => $PiLfS, 'item_per_page' => $Gq7Gu, 'data' => $CT4ZU];
        goto sCX89;
        bOBt1:
        $YRL6p = Cloud::query()->where('user_id', $hxvZ_);
        goto Lb9DZ;
        qp7xN:
        $CT4ZU = $YRL6p->with('media')->orderBy('created_at', 'desc')->limit($Gq7Gu)->offset(($IYU0f - 1) * $Gq7Gu)->get()->filter(function (Cloud $BjbbD) {
            return $BjbbD->getMedia() != null;
        })->map(function (Cloud $BjbbD) {
            goto lbDw0;
            LNxrF:
            return array_merge($dBRu8, ['type' => $BjbbD->getAttribute('type'), 'status' => $BjbbD->getAttribute('status')]);
            goto roi9x;
            lbDw0:
            $HO_3Y = $BjbbD->getMedia();
            goto LxkZM;
            LxkZM:
            $dBRu8 = $HO_3Y->getView();
            goto LNxrF;
            roi9x:
        })->values();
        goto aY_ZZ;
        ujrts:
        list($svswz, $TpD1t, $IYU0f, $Gq7Gu, $QO0rM) = $rAcJI;
        goto bOBt1;
        q9SEx:
        $PiLfS = DB::query()->fromSub($YRL6p, 't')->selectRaw('count(*) as total')->first()->total;
        goto qp7xN;
        ERGtn:
        $YRL6p = $YRL6p->where('status', '=', StatusEnum::vq4Bw);
        goto tZHsa;
        C9uUf:
        $svswz['types'] = array_filter($svswz['types'], function ($zvCZQ) {
            return $zvCZQ !== 'approved';
        });
        goto BH8pS;
        tZHsa:
        VbyIz:
        goto qeoTS;
        Lb9DZ:
        if (!$QO0rM) {
            goto D3uFF;
        }
        goto ZrCfn;
        qeoTS:
        $YRL6p = $this->mWr97TZpNXJ($svswz, $TpD1t, $YRL6p);
        goto q9SEx;
        ZrCfn:
        if (!in_array('approved', $svswz['types'] ?? [])) {
            goto egYFn;
        }
        goto YlE0l;
        sCX89:
    }
    private function mWr97TZpNXJ(array $svswz, array $eEuba, Builder $tdgEg) : Builder
    {
        goto mydC6;
        ZhZ8o:
        return $tdgEg;
        goto mWm9L;
        V1dk9:
        KBNYO:
        goto ZhZ8o;
        mydC6:
        foreach ($this->EU09g as $L6NfV => $XDOws) {
            goto pn2EZ;
            gencY:
            cyqEr:
            goto F906n;
            wHyh4:
            $X1AqQ = new $XDOws();
            goto B82Vs;
            pn2EZ:
            if (isset($svswz[$L6NfV]) && !isset($eEuba[$L6NfV])) {
                goto e_YxT;
            }
            goto avvPN;
            Z5pUV:
            $X1AqQ->my0Gmz1GDju($tdgEg, $svswz[$L6NfV], true);
            goto bz73z;
            bz73z:
            VAEWU:
            goto gencY;
            B82Vs:
            $X1AqQ->my0Gmz1GDju($tdgEg, $eEuba[$L6NfV], false);
            goto kJ2yQ;
            avvPN:
            if (!isset($eEuba[$L6NfV])) {
                goto LtNxg;
            }
            goto wHyh4;
            eYMYY:
            goto VAEWU;
            goto an0ns;
            an0ns:
            e_YxT:
            goto OMQMi;
            OMQMi:
            $X1AqQ = new $XDOws();
            goto Z5pUV;
            kJ2yQ:
            LtNxg:
            goto eYMYY;
            F906n:
        }
        goto V1dk9;
        mWm9L:
    }
    public function saveItems(array $F_fR9) : void
    {
        foreach ($F_fR9 as $DejZC) {
            goto ZHrdH;
            o498A:
            lLUBA:
            goto dTns4;
            nPv0Y:
            if ($BjbbD) {
                goto lLUBA;
            }
            goto OEKXB;
            OEKXB:
            $uQMyN = Media::find($DejZC);
            goto GqNLL;
            dTns4:
            i1e7z:
            goto LcRpL;
            ZHrdH:
            $BjbbD = Cloud::find($DejZC);
            goto nPv0Y;
            GqNLL:
            Cloud::mTAjBySGIzh($uQMyN, StatusEnum::HtBKb);
            goto o498A;
            LcRpL:
        }
        s818a:
    }
    public function delete(string $uuHkQ) : void
    {
        $BjbbD = Cloud::findOrFail($uuHkQ);
        $BjbbD->delete();
    }
}
