<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\OMnp0t4NNpovR;
use Jfs\Gallery\Service\Search\LNw87H7GLupMB;
use Jfs\Gallery\Service\Search\U80hycPd8vamj;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class DvLoYXfg5k6ye implements GalleryCloudInterface
{
    private $AHemg = ['types' => U80hycPd8vamj::class, 'category' => OMnp0t4NNpovR::class];
    public function search(int $cqKaJ, $XMocv) : array
    {
        goto BdqG0;
        RG4i2:
        if (!$HWJWa) {
            goto iFHTV;
        }
        goto hO_lj;
        x7zWh:
        goto ZwzZ7;
        goto bFWN8;
        O27UZ:
        $PpXte = $this->mIwVWhQ8oAU($xA6Qz, $lNNX6, $PpXte);
        goto cuOu7;
        bFWN8:
        iFHTV:
        goto X1zba;
        hrBn8:
        ZwzZ7:
        goto O27UZ;
        cuOu7:
        $F4RNe = DB::query()->fromSub($PpXte, 't')->selectRaw('count(*) as total')->first()->total;
        goto lAPhM;
        BdqG0:
        list($xA6Qz, $lNNX6, $UgzrY, $DCqK1, $HWJWa) = $XMocv;
        goto qo6jA;
        MKR1d:
        $xA6Qz['types'] = array_filter($xA6Qz['types'], function ($EqWY3) {
            return $EqWY3 !== 'approved';
        });
        goto JTyA3;
        JTyA3:
        msOvN:
        goto x7zWh;
        lAPhM:
        $RXeDC = $PpXte->with('media')->orderBy('created_at', 'desc')->limit($DCqK1)->offset(($UgzrY - 1) * $DCqK1)->get()->filter(function (Cloud $kDzew) {
            return $kDzew->getMedia() != null;
        })->map(function (Cloud $kDzew) {
            goto hqX4d;
            hqX4d:
            $D_Z4Z = $kDzew->getMedia();
            goto Ny_8L;
            kX1rW:
            return array_merge($vVh3J, ['type' => $kDzew->getAttribute('type'), 'status' => $kDzew->getAttribute('status')]);
            goto vHWx7;
            Ny_8L:
            $vVh3J = $D_Z4Z->getView();
            goto kX1rW;
            vHWx7:
        })->values();
        goto NBE_x;
        qo6jA:
        $PpXte = Cloud::query()->where('user_id', $cqKaJ);
        goto RG4i2;
        X1zba:
        $PpXte = $PpXte->where('status', '=', StatusEnum::u6RAd);
        goto hrBn8;
        hO_lj:
        if (!in_array('approved', $xA6Qz['types'] ?? [])) {
            goto msOvN;
        }
        goto uCzf4;
        NBE_x:
        return ['page' => $UgzrY, 'total' => $F4RNe, 'item_per_page' => $DCqK1, 'data' => $RXeDC];
        goto GdByP;
        uCzf4:
        $PpXte = $PpXte->where('status', '=', StatusEnum::u6RAd);
        goto MKR1d;
        GdByP:
    }
    private function mIwVWhQ8oAU(array $xA6Qz, array $fhNyv, Builder $W04kQ) : Builder
    {
        goto yS8jX;
        DLXVo:
        return $W04kQ;
        goto U2NLN;
        WmhPF:
        oTqxl:
        goto DLXVo;
        yS8jX:
        foreach ($this->AHemg as $Y1vzU => $bgty5) {
            goto FaZZM;
            yfoAP:
            $a3D87 = new $bgty5();
            goto Me2sT;
            Me2sT:
            $a3D87->mi5VybsYpOe($W04kQ, $xA6Qz[$Y1vzU]);
            goto ASYvf;
            GYLel:
            if (!isset($fhNyv[$Y1vzU])) {
                goto zpg2U;
            }
            goto b8Caa;
            ASYvf:
            lKrsK:
            goto GBUx_;
            ZQd5J:
            $a3D87->mi5VybsYpOe($W04kQ, $fhNyv[$Y1vzU], false);
            goto j6ZbJ;
            j6ZbJ:
            zpg2U:
            goto Sf9oL;
            iYv84:
            YtWN6:
            goto yfoAP;
            b8Caa:
            $a3D87 = new $bgty5();
            goto ZQd5J;
            Sf9oL:
            goto lKrsK;
            goto iYv84;
            FaZZM:
            if (isset($xA6Qz[$Y1vzU]) && !isset($fhNyv[$Y1vzU])) {
                goto YtWN6;
            }
            goto GYLel;
            GBUx_:
            FjTET:
            goto BFM80;
            BFM80:
        }
        goto WmhPF;
        U2NLN:
    }
    public function saveItems(array $x2kJc) : void
    {
        foreach ($x2kJc as $qFMlx) {
            goto jnHSV;
            n1R1C:
            ll4xc:
            goto sI4vA;
            lgGkC:
            $DwGmR = Media::find($qFMlx);
            goto EzlGj;
            EzlGj:
            Cloud::mpnWubZmaKP($DwGmR, StatusEnum::hkg8T);
            goto TeAmA;
            jnHSV:
            $kDzew = Cloud::find($qFMlx);
            goto jjxqt;
            TeAmA:
            c7xlS:
            goto n1R1C;
            jjxqt:
            if ($kDzew) {
                goto c7xlS;
            }
            goto lgGkC;
            sI4vA:
        }
        b3VFA:
    }
    public function delete(string $eeXS6) : void
    {
        $kDzew = Cloud::findOrFail($eeXS6);
        $kDzew->delete();
    }
}
