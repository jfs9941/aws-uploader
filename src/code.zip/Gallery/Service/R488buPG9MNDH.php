<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Gallery\Service\Search\A1UJerd6tbvh8;
use Jfs\Gallery\Service\Search\X08LN7tFFGHa4;
use Jfs\Gallery\Service\Search\AgNmSlPqCKY5q;
use Illuminate\Database\Eloquent\Builder;
final class R488buPG9MNDH implements GalleryCloudInterface
{
    private $B5LCl = ['types' => AgNmSlPqCKY5q::class, 'category' => A1UJerd6tbvh8::class];
    public function search(int $NnyAX, $d_xlI) : array
    {
        goto DB81G;
        EwBiW:
        $Or112 = $C8vDQ->with('media')->orderBy('created_at', 'desc')->limit($daLCg)->offset(($JidUB - 1) * $daLCg)->get()->filter(function (Cloud $b99gU) {
            return $b99gU->getMedia() != null;
        })->map(function (Cloud $b99gU) {
            goto ePMEQ;
            hCfEq:
            $RrBvn = $xUtpC->getView();
            goto rizDO;
            ePMEQ:
            $xUtpC = $b99gU->getMedia();
            goto hCfEq;
            rizDO:
            return array_merge($RrBvn, ['type' => $b99gU->getAttribute('type'), 'status' => $b99gU->getAttribute('status')]);
            goto K_Zat;
            K_Zat:
        })->values();
        goto Tnn65;
        DB81G:
        list($hKs9V, $f0Chp, $JidUB, $daLCg, $lr6iU) = $d_xlI;
        goto n5WWZ;
        gRige:
        goto l1dOE;
        goto jKtrW;
        mDilX:
        $J6WWp = DB::query()->fromSub($C8vDQ, 't')->selectRaw('count(*) as total')->first()->total;
        goto EwBiW;
        x0jGj:
        l1dOE:
        goto D0dkt;
        D0dkt:
        $C8vDQ = $this->mhzKmTQcVui($hKs9V, $f0Chp, $C8vDQ);
        goto mDilX;
        AgtU5:
        if (!$lr6iU) {
            goto lZUIc;
        }
        goto RaZVL;
        RaZVL:
        if (!in_array('approved', $hKs9V['types'] ?? [])) {
            goto zPdGi;
        }
        goto zHkU0;
        zHkU0:
        $C8vDQ = $C8vDQ->where('status', '=', StatusEnum::TXvFN);
        goto bLRUT;
        n5WWZ:
        $C8vDQ = Cloud::query()->where('user_id', $NnyAX);
        goto AgtU5;
        bLRUT:
        $hKs9V['types'] = array_filter($hKs9V['types'], function ($ViPGP) {
            return $ViPGP !== 'approved';
        });
        goto d7310;
        d7310:
        zPdGi:
        goto gRige;
        Tnn65:
        return ['page' => $JidUB, 'total' => $J6WWp, 'item_per_page' => $daLCg, 'data' => $Or112];
        goto Wyv7B;
        A60y5:
        $C8vDQ = $C8vDQ->where('status', '=', StatusEnum::TXvFN);
        goto x0jGj;
        jKtrW:
        lZUIc:
        goto A60y5;
        Wyv7B:
    }
    private function mhzKmTQcVui(array $hKs9V, array $GV23z, Builder $PaniD) : Builder
    {
        goto R7pqi;
        oPHxk:
        return $PaniD;
        goto UFPDb;
        R7pqi:
        foreach ($this->B5LCl as $tIg7L => $IRhMF) {
            goto sv4IW;
            XxgF8:
            $R3Ktv->mpCWvk5cF1i($PaniD, $GV23z[$tIg7L], false);
            goto HSDk6;
            N1W2s:
            $R3Ktv = new $IRhMF();
            goto XxgF8;
            ewCdZ:
            y1W0e:
            goto lGu4D;
            HSDk6:
            nIA24:
            goto gcyg4;
            sv4IW:
            if (isset($hKs9V[$tIg7L]) && !isset($GV23z[$tIg7L])) {
                goto y1W0e;
            }
            goto I9eTY;
            gcyg4:
            goto ongQ5;
            goto ewCdZ;
            SDuM8:
            ongQ5:
            goto rxuNo;
            Q3sea:
            $R3Ktv->mpCWvk5cF1i($PaniD, $hKs9V[$tIg7L]);
            goto SDuM8;
            I9eTY:
            if (!isset($GV23z[$tIg7L])) {
                goto nIA24;
            }
            goto N1W2s;
            rxuNo:
            wXrh2:
            goto xjCuT;
            lGu4D:
            $R3Ktv = new $IRhMF();
            goto Q3sea;
            xjCuT:
        }
        goto EQpWd;
        EQpWd:
        KZjWE:
        goto oPHxk;
        UFPDb:
    }
    public function saveItems(array $jRWDP) : void
    {
        foreach ($jRWDP as $I2SbP) {
            goto DwL4y;
            tyPtn:
            $kvzTH = Media::find($I2SbP);
            goto aEf0h;
            aEf0h:
            Cloud::mcnTWy94ltd($kvzTH, StatusEnum::IcBeZ);
            goto WFGyC;
            WFGyC:
            uKKfd:
            goto vLMpy;
            T3XLj:
            if ($b99gU) {
                goto uKKfd;
            }
            goto tyPtn;
            vLMpy:
            ECoh8:
            goto lNZAv;
            DwL4y:
            $b99gU = Cloud::find($I2SbP);
            goto T3XLj;
            lNZAv:
        }
        TJBaC:
    }
    public function delete(string $FILUb) : void
    {
        $b99gU = Cloud::findOrFail($FILUb);
        $b99gU->delete();
    }
}
