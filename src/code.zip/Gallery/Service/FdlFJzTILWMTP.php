<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\VbZ1kzTgNjr5r;
use Jfs\Gallery\Service\Search\N64YJC4X4qDV3;
use Jfs\Gallery\Service\Search\FaHV8czkudZWz;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class FdlFJzTILWMTP implements GalleryCloudInterface
{
    private $OsdRH = ['types' => FaHV8czkudZWz::class, 'category' => VbZ1kzTgNjr5r::class];
    public function search(int $FiELQ, $bXsnG) : array
    {
        goto Ixd_a;
        JbC2F:
        $QzdJG['types'] = array_filter($QzdJG['types'], function ($j0csg) {
            return $j0csg !== 'approved';
        });
        goto EpATN;
        cswqO:
        $PSeZX = $PSeZX->where('status', '=', StatusEnum::VSEus);
        goto eMJ5e;
        OZ8sb:
        $PSeZX = $this->mSY0vamfwaH($QzdJG, $XVMEe, $PSeZX);
        goto dlSjK;
        EpATN:
        aJtWn:
        goto tuf33;
        P3qGa:
        $PSeZX = Cloud::query()->where('user_id', $FiELQ);
        goto ExryV;
        eMJ5e:
        VrtYu:
        goto OZ8sb;
        IXVSy:
        $PSeZX = $PSeZX->where('status', '=', StatusEnum::VSEus);
        goto JbC2F;
        eApP3:
        if (!in_array('approved', $QzdJG['types'] ?? [])) {
            goto aJtWn;
        }
        goto IXVSy;
        vB3le:
        return ['page' => $GL0ct, 'total' => $OjiNQ, 'item_per_page' => $efQ8c, 'data' => $hd6J3];
        goto iCppV;
        scMgO:
        o03zZ:
        goto cswqO;
        f7F2_:
        $hd6J3 = $PSeZX->with('media')->orderBy('created_at', 'desc')->limit($efQ8c)->offset(($GL0ct - 1) * $efQ8c)->get()->filter(function (Cloud $ZGYBE) {
            return $ZGYBE->getMedia() != null;
        })->map(function (Cloud $ZGYBE) {
            goto oHVQd;
            Y5zUp:
            return array_merge($ld1HK, ['type' => $ZGYBE->getAttribute('type'), 'status' => $ZGYBE->getAttribute('status')]);
            goto ZcYF6;
            oHVQd:
            $I80en = $ZGYBE->getMedia();
            goto Lk6ZU;
            Lk6ZU:
            $ld1HK = $I80en->getView();
            goto Y5zUp;
            ZcYF6:
        })->values();
        goto vB3le;
        dlSjK:
        $OjiNQ = DB::query()->fromSub($PSeZX, 't')->selectRaw('count(*) as total')->first()->total;
        goto f7F2_;
        Ixd_a:
        list($QzdJG, $XVMEe, $GL0ct, $efQ8c, $Fi_dw) = $bXsnG;
        goto P3qGa;
        ExryV:
        if (!$Fi_dw) {
            goto o03zZ;
        }
        goto eApP3;
        tuf33:
        goto VrtYu;
        goto scMgO;
        iCppV:
    }
    private function mSY0vamfwaH(array $QzdJG, array $qE8ji, Builder $QqKs2) : Builder
    {
        goto Fud5y;
        Fud5y:
        foreach ($this->OsdRH as $A7XVE => $qT1k9) {
            goto UfGcz;
            jvHaO:
            JD0Bh:
            goto hY7XK;
            L9F6o:
            $oOjil = new $qT1k9();
            goto U4VG4;
            U4VG4:
            $oOjil->mI8xJ0f7ytO($QqKs2, $qE8ji[$A7XVE], false);
            goto Ahcph;
            hDHmn:
            goto o4g26;
            goto YPR2W;
            YPR2W:
            igw5S:
            goto n7WFl;
            n7WFl:
            $oOjil = new $qT1k9();
            goto z1AuP;
            z1AuP:
            $oOjil->mI8xJ0f7ytO($QqKs2, $QzdJG[$A7XVE]);
            goto L0W6V;
            L0W6V:
            o4g26:
            goto jvHaO;
            mL1cw:
            if (!isset($qE8ji[$A7XVE])) {
                goto T2Rdn;
            }
            goto L9F6o;
            UfGcz:
            if (isset($QzdJG[$A7XVE]) && !isset($qE8ji[$A7XVE])) {
                goto igw5S;
            }
            goto mL1cw;
            Ahcph:
            T2Rdn:
            goto hDHmn;
            hY7XK:
        }
        goto v3ZVf;
        v3ZVf:
        cCTsC:
        goto pQdL8;
        pQdL8:
        return $QqKs2;
        goto anJ9S;
        anJ9S:
    }
    public function saveItems(array $jlij9) : void
    {
        foreach ($jlij9 as $bwI0g) {
            goto GoSC6;
            LUJ77:
            s1C6v:
            goto WzJnW;
            GoSC6:
            $ZGYBE = Cloud::find($bwI0g);
            goto q27Cu;
            zf1kQ:
            $kPdH9 = Media::find($bwI0g);
            goto cBfqt;
            WzJnW:
            jQfqK:
            goto FqCN7;
            cBfqt:
            Cloud::m4f8TxJYcu6($kPdH9, StatusEnum::BYUH7);
            goto LUJ77;
            q27Cu:
            if ($ZGYBE) {
                goto s1C6v;
            }
            goto zf1kQ;
            FqCN7:
        }
        GfFSE:
    }
    public function delete(string $tu00C) : void
    {
        $ZGYBE = Cloud::findOrFail($tu00C);
        $ZGYBE->delete();
    }
}
