<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\ExdNeeQTY88W9;
use Jfs\Gallery\Service\Search\WMuZEU3jPyMCd;
use Jfs\Gallery\Service\Search\UUyrUNf3wErVT;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class KNzRObv7c39L1 implements GalleryCloudInterface
{
    private $qSUqq = ['types' => UUyrUNf3wErVT::class, 'category' => ExdNeeQTY88W9::class];
    public function search(int $E3Fxu, $sJwNs) : array
    {
        goto QaCLx;
        QE7Sz:
        return ['page' => $olMoI, 'total' => $uDDWG, 'item_per_page' => $BiL0y, 'data' => $IcWNr];
        goto cY2eI;
        HC6ag:
        $CdzbV = $CdzbV->where('status', '=', StatusEnum::YZ67o);
        goto bV1x1;
        CEjuI:
        $CdzbV = $CdzbV->where('status', '=', StatusEnum::YZ67o);
        goto DQCO0;
        DQCO0:
        $i7CGL['types'] = array_filter($i7CGL['types'], function ($R5Gqo) {
            return $R5Gqo !== 'approved';
        });
        goto U_oyb;
        U_oyb:
        pr_qy:
        goto DuEDj;
        QaCLx:
        list($i7CGL, $YBEAK, $olMoI, $BiL0y, $afp48) = $sJwNs;
        goto cZY2s;
        XM_Cb:
        if (!$afp48) {
            goto B8MgZ;
        }
        goto I54Mt;
        bV1x1:
        WEvD4:
        goto HEnQF;
        DuEDj:
        goto WEvD4;
        goto ahRsL;
        ahRsL:
        B8MgZ:
        goto HC6ag;
        cZY2s:
        $CdzbV = Cloud::query()->where('user_id', $E3Fxu);
        goto XM_Cb;
        Abl8_:
        $uDDWG = DB::query()->fromSub($CdzbV, 't')->selectRaw('count(*) as total')->first()->total;
        goto JXtJS;
        JXtJS:
        $IcWNr = $CdzbV->with('media')->orderBy('created_at', 'desc')->limit($BiL0y)->offset(($olMoI - 1) * $BiL0y)->get()->filter(function (Cloud $UoeXG) {
            return $UoeXG->getMedia() != null;
        })->map(function (Cloud $UoeXG) {
            goto uyDTu;
            V8INx:
            $KqiYb = $aB0a5->getView();
            goto tK8D2;
            tK8D2:
            return array_merge($KqiYb, ['type' => $UoeXG->getAttribute('type'), 'status' => $UoeXG->getAttribute('status')]);
            goto y0KXl;
            uyDTu:
            $aB0a5 = $UoeXG->getMedia();
            goto V8INx;
            y0KXl:
        })->values();
        goto QE7Sz;
        HEnQF:
        $CdzbV = $this->mAF8HDVodk9($i7CGL, $YBEAK, $CdzbV);
        goto Abl8_;
        I54Mt:
        if (!in_array('approved', $i7CGL['types'] ?? [])) {
            goto pr_qy;
        }
        goto CEjuI;
        cY2eI:
    }
    private function mAF8HDVodk9(array $i7CGL, array $Euyni, Builder $rRtwf) : Builder
    {
        goto BWbL0;
        BWbL0:
        foreach ($this->qSUqq as $AOROk => $s9VKm) {
            goto ms73X;
            ZvmPG:
            sQHDh:
            goto JFp6n;
            zGrN4:
            Y3rn6:
            goto RYWmq;
            RYWmq:
            goto LIz_C;
            goto ZvmPG;
            JFp6n:
            $oEOW2 = new $s9VKm();
            goto W6Z0q;
            SATOT:
            $oEOW2->mE2Vq87744N($rRtwf, $Euyni[$AOROk], false);
            goto zGrN4;
            W6Z0q:
            $oEOW2->mE2Vq87744N($rRtwf, $i7CGL[$AOROk]);
            goto R4GUv;
            vgzGl:
            B0Gx3:
            goto ns0Tw;
            rZpbQ:
            $oEOW2 = new $s9VKm();
            goto SATOT;
            ms73X:
            if (isset($i7CGL[$AOROk]) && !isset($Euyni[$AOROk])) {
                goto sQHDh;
            }
            goto iFPbj;
            iFPbj:
            if (!isset($Euyni[$AOROk])) {
                goto Y3rn6;
            }
            goto rZpbQ;
            R4GUv:
            LIz_C:
            goto vgzGl;
            ns0Tw:
        }
        goto p319u;
        p319u:
        m61rN:
        goto SkuNs;
        SkuNs:
        return $rRtwf;
        goto gp78W;
        gp78W:
    }
    public function saveItems(array $a0Qxo) : void
    {
        foreach ($a0Qxo as $k2MU3) {
            goto Ma_MZ;
            Ma_MZ:
            $UoeXG = Cloud::find($k2MU3);
            goto GcqiT;
            fTdHC:
            tKzCp:
            goto asBz3;
            GcqiT:
            if ($UoeXG) {
                goto tKzCp;
            }
            goto EmQpD;
            EmQpD:
            $dYGNV = Media::find($k2MU3);
            goto pfUl2;
            asBz3:
            RnPU9:
            goto EUVWt;
            pfUl2:
            Cloud::mNq90qD9gnr($dYGNV, StatusEnum::M28FR);
            goto fTdHC;
            EUVWt:
        }
        hIKGm:
    }
    public function delete(string $N2oAf) : void
    {
        $UoeXG = Cloud::findOrFail($N2oAf);
        $UoeXG->delete();
    }
}
