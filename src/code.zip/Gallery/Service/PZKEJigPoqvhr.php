<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\GRgyonpU6pkyo;
use Jfs\Gallery\Service\Search\OMKcqo45IDWKI;
use Jfs\Gallery\Service\Search\Vnpt4Jn2ad5a1;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class PZKEJigPoqvhr implements GalleryCloudInterface
{
    private $sIywY = ['types' => Vnpt4Jn2ad5a1::class, 'category' => GRgyonpU6pkyo::class];
    public function search(int $TbUNq, $jXO2x) : array
    {
        goto g_KQA;
        hRH2k:
        $TqE5I = DB::query()->fromSub($rstYt, 't')->selectRaw('count(*) as total')->first()->total;
        goto jio66;
        wAN5y:
        $rstYt = $this->mwv6DD2JkMN($jIVzU, $lP51B, $rstYt);
        goto hRH2k;
        nB66F:
        $rstYt = $rstYt->where('status', '=', StatusEnum::rdt2D);
        goto wp60Q;
        g_KQA:
        list($jIVzU, $lP51B, $ymZUZ, $g5Mpj, $a8a6j) = $jXO2x;
        goto t2cDz;
        v_Xp3:
        goto Rj0iG;
        goto wypcp;
        TR1zr:
        if (!in_array('approved', $jIVzU['types'] ?? [])) {
            goto nujAr;
        }
        goto H1MQP;
        wp60Q:
        Rj0iG:
        goto wAN5y;
        t2cDz:
        $rstYt = Cloud::query()->where('user_id', $TbUNq);
        goto ox782;
        ox782:
        if (!$a8a6j) {
            goto jY7uK;
        }
        goto TR1zr;
        wypcp:
        jY7uK:
        goto nB66F;
        H1MQP:
        $rstYt = $rstYt->where('status', '=', StatusEnum::rdt2D);
        goto b_8BJ;
        b_8BJ:
        $jIVzU['types'] = array_filter($jIVzU['types'], function ($lWEG4) {
            return $lWEG4 !== 'approved';
        });
        goto heMnj;
        heMnj:
        nujAr:
        goto v_Xp3;
        jio66:
        $h1oLe = $rstYt->with('media')->orderBy('created_at', 'desc')->limit($g5Mpj)->offset(($ymZUZ - 1) * $g5Mpj)->get()->filter(function (Cloud $Zx1Cw) {
            return $Zx1Cw->getMedia() != null;
        })->map(function (Cloud $Zx1Cw) {
            goto uB4bG;
            uB4bG:
            $uTqKK = $Zx1Cw->getMedia();
            goto WdEjz;
            mcSfr:
            return array_merge($Wg92u, ['type' => $Zx1Cw->getAttribute('type'), 'status' => $Zx1Cw->getAttribute('status')]);
            goto rBelY;
            WdEjz:
            $Wg92u = $uTqKK->getView();
            goto mcSfr;
            rBelY:
        })->values();
        goto blswb;
        blswb:
        return ['page' => $ymZUZ, 'total' => $TqE5I, 'item_per_page' => $g5Mpj, 'data' => $h1oLe];
        goto liTCm;
        liTCm:
    }
    private function mwv6DD2JkMN(array $jIVzU, array $EkDzf, Builder $DTD0q) : Builder
    {
        goto OHTWU;
        Pc5xV:
        return $DTD0q;
        goto KLhsS;
        UnbVu:
        EQL6f:
        goto Pc5xV;
        OHTWU:
        foreach ($this->sIywY as $wwCxW => $RAqi7) {
            goto LWemG;
            wYh9i:
            G7LP4:
            goto NfTm2;
            VMPyn:
            $OmiQo = new $RAqi7();
            goto keSTp;
            keSTp:
            $OmiQo->m1O95GkRtTP($DTD0q, $EkDzf[$wwCxW], false);
            goto q_4ug;
            wVzzL:
            if (!isset($EkDzf[$wwCxW])) {
                goto V3xUr;
            }
            goto VMPyn;
            rSQek:
            $OmiQo = new $RAqi7();
            goto TvwKL;
            xOrAK:
            UxK7T:
            goto rSQek;
            q_4ug:
            V3xUr:
            goto bIfuQ;
            TvwKL:
            $OmiQo->m1O95GkRtTP($DTD0q, $jIVzU[$wwCxW]);
            goto CJGw1;
            bIfuQ:
            goto pU6A6;
            goto xOrAK;
            LWemG:
            if (isset($jIVzU[$wwCxW]) && !isset($EkDzf[$wwCxW])) {
                goto UxK7T;
            }
            goto wVzzL;
            CJGw1:
            pU6A6:
            goto wYh9i;
            NfTm2:
        }
        goto UnbVu;
        KLhsS:
    }
    public function saveItems(array $ynycl) : void
    {
        foreach ($ynycl as $YfsmL) {
            goto feeQg;
            uEFVU:
            Cloud::mvlLA67dojz($PC1_p, StatusEnum::S7NUt);
            goto ZNhUZ;
            ZNhUZ:
            bAvz5:
            goto Z4eIH;
            ZUjaV:
            $PC1_p = Media::find($YfsmL);
            goto uEFVU;
            LvSma:
            if ($Zx1Cw) {
                goto bAvz5;
            }
            goto ZUjaV;
            feeQg:
            $Zx1Cw = Cloud::find($YfsmL);
            goto LvSma;
            Z4eIH:
            XkWbN:
            goto t_v4N;
            t_v4N:
        }
        EGG0S:
    }
    public function delete(string $B_L9m) : void
    {
        $Zx1Cw = Cloud::findOrFail($B_L9m);
        $Zx1Cw->delete();
    }
}
