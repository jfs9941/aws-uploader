<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\D0POpDmw1880G;
use Jfs\Gallery\Service\Search\QX45eBU594VwZ;
use Jfs\Gallery\Service\Search\BT7vr2KkCSjJ8;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class GctV2200KmYdA implements GalleryCloudInterface
{
    private $DCsZl = ['types' => BT7vr2KkCSjJ8::class, 'category' => D0POpDmw1880G::class];
    public function search(int $R57fB, $Sc_2l) : array
    {
        goto u7hM_;
        nZ3rQ:
        return ['page' => $CjzWk, 'total' => $MGJ0M, 'item_per_page' => $r_tIG, 'data' => $szBd8];
        goto SU4kU;
        N5tUA:
        $L9RrJ = Cloud::query()->where('user_id', $R57fB);
        goto u3Ool;
        KI3Xa:
        X8Ob6:
        goto UMs6F;
        u7hM_:
        list($a_8CQ, $AC5Fd, $CjzWk, $r_tIG, $PTLcS) = $Sc_2l;
        goto N5tUA;
        RMzBN:
        if (!in_array('approved', $a_8CQ['types'] ?? [])) {
            goto StIwk;
        }
        goto H4Df6;
        EHRpQ:
        $szBd8 = $L9RrJ->with('media')->orderBy('created_at', 'desc')->limit($r_tIG)->offset(($CjzWk - 1) * $r_tIG)->get()->filter(function (Cloud $bEOPg) {
            return $bEOPg->getMedia() != null;
        })->map(function (Cloud $bEOPg) {
            goto NpNwI;
            zFouo:
            return array_merge($hdfBo, ['type' => $bEOPg->getAttribute('type'), 'status' => $bEOPg->getAttribute('status')]);
            goto nGvZu;
            NpNwI:
            $SmLAm = $bEOPg->getMedia();
            goto XFg3G;
            XFg3G:
            $hdfBo = $SmLAm->getView();
            goto zFouo;
            nGvZu:
        })->values();
        goto nZ3rQ;
        NRT0o:
        hlA0Q:
        goto ugg9_;
        AKk9I:
        $MGJ0M = DB::query()->fromSub($L9RrJ, 't')->selectRaw('count(*) as total')->first()->total;
        goto EHRpQ;
        qlDur:
        $a_8CQ['types'] = array_filter($a_8CQ['types'], function ($AKu3b) {
            return $AKu3b !== 'approved';
        });
        goto aotoL;
        UMs6F:
        $L9RrJ = $this->mJbn2FEs1PL($a_8CQ, $AC5Fd, $L9RrJ);
        goto AKk9I;
        u3Ool:
        if (!$PTLcS) {
            goto hlA0Q;
        }
        goto RMzBN;
        OikW8:
        goto X8Ob6;
        goto NRT0o;
        H4Df6:
        $L9RrJ = $L9RrJ->where('status', '=', StatusEnum::v4GXn);
        goto qlDur;
        ugg9_:
        $L9RrJ = $L9RrJ->where('status', '=', StatusEnum::v4GXn);
        goto KI3Xa;
        aotoL:
        StIwk:
        goto OikW8;
        SU4kU:
    }
    private function mJbn2FEs1PL(array $a_8CQ, array $sh8ip, Builder $ONlVY) : Builder
    {
        goto lZaWT;
        lZaWT:
        foreach ($this->DCsZl as $zavj2 => $k2ASY) {
            goto QWesd;
            HdcUU:
            if (!isset($sh8ip[$zavj2])) {
                goto hf6Qj;
            }
            goto kN2Oa;
            qypGC:
            $B5rJe->mQZXyrFVvse($ONlVY, $a_8CQ[$zavj2]);
            goto slqKY;
            G3mwo:
            L5itP:
            goto baTnV;
            QWesd:
            if (isset($a_8CQ[$zavj2]) && !isset($sh8ip[$zavj2])) {
                goto cIR3t;
            }
            goto HdcUU;
            slqKY:
            S7UAo:
            goto G3mwo;
            FcYr5:
            goto S7UAo;
            goto He2hL;
            WxzoP:
            hf6Qj:
            goto FcYr5;
            SRDSN:
            $B5rJe = new $k2ASY();
            goto qypGC;
            l6git:
            $B5rJe->mQZXyrFVvse($ONlVY, $sh8ip[$zavj2], false);
            goto WxzoP;
            He2hL:
            cIR3t:
            goto SRDSN;
            kN2Oa:
            $B5rJe = new $k2ASY();
            goto l6git;
            baTnV:
        }
        goto p7btv;
        Yewu4:
        return $ONlVY;
        goto edAW9;
        p7btv:
        xgKaG:
        goto Yewu4;
        edAW9:
    }
    public function saveItems(array $HQNSs) : void
    {
        foreach ($HQNSs as $s2INV) {
            goto BsyCD;
            u3jlv:
            iNhNK:
            goto LJGQn;
            a0gcb:
            $ZygbT = Media::find($s2INV);
            goto SP4xk;
            BsyCD:
            $bEOPg = Cloud::find($s2INV);
            goto bcORO;
            bcORO:
            if ($bEOPg) {
                goto lx0kt;
            }
            goto a0gcb;
            SP4xk:
            Cloud::m4MinpuRu1G($ZygbT, StatusEnum::jj10U);
            goto FMseZ;
            FMseZ:
            lx0kt:
            goto u3jlv;
            LJGQn:
        }
        Is03t:
    }
    public function delete(string $aK0gt) : void
    {
        $bEOPg = Cloud::findOrFail($aK0gt);
        $bEOPg->delete();
    }
}
