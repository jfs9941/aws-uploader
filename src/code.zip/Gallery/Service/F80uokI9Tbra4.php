<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Gallery\Service\Search\OSQSoaTGUdaw7;
use Jfs\Gallery\Service\Search\YL1ekuEHjKHB6;
use Jfs\Gallery\Service\Search\Uk1SDXqdh2Dop;
use Illuminate\Database\Eloquent\Builder;
final class F80uokI9Tbra4 implements GalleryCloudInterface
{
    private $BZYMb = ['types' => Uk1SDXqdh2Dop::class, 'category' => OSQSoaTGUdaw7::class];
    public function search(int $UVY53, $yDUSV) : array
    {
        goto zE2hm;
        n2mFm:
        $RZJah = $RZJah->where('status', '=', StatusEnum::Hc2dI);
        goto MALlZ;
        PnXDO:
        $RZJah = $RZJah->where('status', '=', StatusEnum::Hc2dI);
        goto c3cpz;
        MALlZ:
        $Bmh71['types'] = array_filter($Bmh71['types'], function ($hb3oT) {
            return $hb3oT !== 'approved';
        });
        goto enjPl;
        vLOO8:
        goto ws1C0;
        goto fpq8_;
        c3cpz:
        ws1C0:
        goto dH_iW;
        ykBvd:
        $RZJah = Cloud::query()->where('user_id', $UVY53);
        goto v7oo3;
        zE2hm:
        list($Bmh71, $MPxWU, $RThse, $M5_rQ, $jpNL_) = $yDUSV;
        goto ykBvd;
        fpq8_:
        FWQ8v:
        goto PnXDO;
        dH_iW:
        $RZJah = $this->mTCMmg9wsAK($Bmh71, $MPxWU, $RZJah);
        goto Zitsl;
        gog0S:
        if (!in_array('approved', $Bmh71['types'] ?? [])) {
            goto Doerh;
        }
        goto n2mFm;
        enjPl:
        Doerh:
        goto vLOO8;
        Zitsl:
        $ONQZa = DB::query()->fromSub($RZJah, 't')->selectRaw('count(*) as total')->first()->total;
        goto L5Nwy;
        B4D1W:
        return ['page' => $RThse, 'total' => $ONQZa, 'item_per_page' => $M5_rQ, 'data' => $QuGN9];
        goto Y_PSJ;
        v7oo3:
        if (!$jpNL_) {
            goto FWQ8v;
        }
        goto gog0S;
        L5Nwy:
        $QuGN9 = $RZJah->with('media')->orderBy('created_at', 'desc')->limit($M5_rQ)->offset(($RThse - 1) * $M5_rQ)->get()->filter(function (Cloud $OPu3r) {
            return $OPu3r->getMedia() != null;
        })->map(function (Cloud $OPu3r) {
            goto haNmA;
            P7NvV:
            $jdl8g = $HpL55->getView();
            goto YQLHg;
            haNmA:
            $HpL55 = $OPu3r->getMedia();
            goto P7NvV;
            YQLHg:
            return array_merge($jdl8g, ['type' => $OPu3r->getAttribute('type'), 'status' => $OPu3r->getAttribute('status')]);
            goto qq5Q9;
            qq5Q9:
        })->values();
        goto B4D1W;
        Y_PSJ:
    }
    private function mTCMmg9wsAK(array $Bmh71, array $H_AlO, Builder $RSfya) : Builder
    {
        goto I84yI;
        rPGIH:
        return $RSfya;
        goto QM4rq;
        llyTa:
        sJRCc:
        goto rPGIH;
        I84yI:
        foreach ($this->BZYMb as $gKkrF => $sl9X1) {
            goto yjF1C;
            uyKQi:
            $DSU4y = new $sl9X1();
            goto gLqtP;
            jEmn5:
            goto dVmIK;
            goto Qeg_i;
            gLqtP:
            $DSU4y->muv3MyLhlJm($RSfya, $Bmh71[$gKkrF]);
            goto gtggX;
            krOwT:
            Ctdni:
            goto WaJwC;
            veu0k:
            EJ00q:
            goto jEmn5;
            c1P0i:
            if (!isset($H_AlO[$gKkrF])) {
                goto EJ00q;
            }
            goto LLNlY;
            LLNlY:
            $DSU4y = new $sl9X1();
            goto vVt8i;
            Qeg_i:
            fNdRt:
            goto uyKQi;
            gtggX:
            dVmIK:
            goto krOwT;
            yjF1C:
            if (isset($Bmh71[$gKkrF]) && !isset($H_AlO[$gKkrF])) {
                goto fNdRt;
            }
            goto c1P0i;
            vVt8i:
            $DSU4y->muv3MyLhlJm($RSfya, $H_AlO[$gKkrF], false);
            goto veu0k;
            WaJwC:
        }
        goto llyTa;
        QM4rq:
    }
    public function saveItems(array $ovfhc) : void
    {
        foreach ($ovfhc as $nKKn0) {
            goto DfbLp;
            ZOBph:
            cPiyb:
            goto XXqvC;
            DfbLp:
            $OPu3r = Cloud::find($nKKn0);
            goto cwSlk;
            eohyU:
            $TUPIK = Media::find($nKKn0);
            goto j3u0G;
            cwSlk:
            if ($OPu3r) {
                goto ffXr5;
            }
            goto eohyU;
            c59N2:
            ffXr5:
            goto ZOBph;
            j3u0G:
            Cloud::mhWnBVgNzKq($TUPIK, StatusEnum::emNHo);
            goto c59N2;
            XXqvC:
        }
        A5_rt:
    }
    public function delete(string $PV4mw) : void
    {
        $OPu3r = Cloud::findOrFail($PV4mw);
        $OPu3r->delete();
    }
}
