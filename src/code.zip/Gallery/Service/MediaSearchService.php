<?php

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\PathResolverInterface;
use Jfs\Gallery\Service\Search\CategoryFilter;
use Jfs\Gallery\Service\Search\FilterInterface;
use Jfs\Gallery\Service\Search\MediaTypeFilter;
use Illuminate\Database\Eloquent\Builder;


final class MediaSearchService implements GalleryCloudInterface
{
    private $filterMap = [
        'types' => MediaTypeFilter::class,
        'category' => CategoryFilter::class,
    ];


    public function search(int $userId, $searchMetadata): array
    {
        list($extra, $page, $perPage, $showAll) = $searchMetadata;
        $query = Cloud::query()
            ->where('user_id', $userId);
        if (!$showAll) {
            $query = $query->where('status', '=', StatusEnum::APPROVED);
        } else {
            if (in_array('approved', $extra['types'] ?? [])) {
                $query = $query->where('status', '=', StatusEnum::APPROVED);
                $extra['types'] = array_filter($extra['types'], function($type) {
                    return $type !== 'approved';
                });
            }
        }

        $query = $this->searchBuilders($extra, $query);

        $total = DB::query()->fromSub($query, 't')
            ->selectRaw('count(*) as total')
            ->first()->total;

        $result = $query->with('media')->orderBy('created_at', 'desc')->limit($perPage)->offset(($page - 1) * $perPage)->get()
            ->filter(function(Cloud $cloud) {
                return $cloud->media != null;
            })
            ->map(function (Cloud $cloud) {
                /** @var Media $media */
                $media = $cloud->media;
                $view = $media->getView();

                return array_merge($view, [
                    'type' => $cloud->getAttribute('type'),
                    'status' => $cloud->getAttribute('status'),
                ]);
            })->values();
        return [
            'page' => $page,
            'total' => $total,
            'item_per_page' => $perPage,
            'data' => $result
        ];
    }

    private function searchBuilders(array $extra, Builder $builder): Builder
    {
        foreach ($this->filterMap as $param => $filterClass) {
            if (isset($extra[$param])) {
                /** @var FilterInterface $filter */
                $filter = new $filterClass(); // Or resolve from container: resolve($filterClass)
                $filter->apply($builder, $extra[$param]);
            }
        }

        return $builder;
    }

    public function saveItems(array $items): void
    {
        foreach ($items as $file) {
            $cloud = Cloud::find($file);
            if (!$cloud) {
                $attachment = Media::find($file);
                Cloud::createFromMedia($attachment, StatusEnum::PENDING);
            }
        }
    }

    public function delete(string $id): void
    {
        $cloud = Cloud::findOrFail($id);
        $cloud->delete();
    }
}
