<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Service\Search\JE3D9AowhwEaq;
use Jfs\Gallery\Service\Search\AcpyJoTxMAGcI;
use Jfs\Gallery\Service\Search\Tob2eSkuGGQz1;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
final class HUoKoAXzk5zWW implements GalleryCloudInterface
{
    private $hUKh7 = ['types' => Tob2eSkuGGQz1::class, 'category' => JE3D9AowhwEaq::class];
    public function search(int $DLEqG, $esYR1) : array
    {
        goto zwKqu;
        FpVBn:
        $pkaxq = Cloud::query()->where('user_id', $DLEqG);
        goto WFCoG;
        YlY0R:
        SaKdX:
        goto X7jIR;
        lVsUB:
        W9_Xm:
        goto qKg3K;
        I1OHA:
        $l7Cgf = DB::query()->fromSub($pkaxq, 't')->selectRaw('count(*) as total')->first()->total;
        goto QJ4mT;
        IOIUw:
        $DLnNy['types'] = array_filter($DLnNy['types'], function ($mVJZH) {
            return $mVJZH !== 'approved';
        });
        goto YlY0R;
        QJ4mT:
        $G4taM = $pkaxq->with('media')->orderBy('created_at', 'desc')->limit($E48S7)->offset(($cIfRM - 1) * $E48S7)->get()->filter(function (Cloud $irUDM) {
            return $irUDM->getMedia() != null;
        })->map(function (Cloud $irUDM) {
            goto ZYbIu;
            h1EXB:
            return array_merge($TdECi, ['type' => $irUDM->getAttribute('type'), 'status' => $irUDM->getAttribute('status')]);
            goto fUupM;
            X4aFw:
            $TdECi = $csSew->getView();
            goto h1EXB;
            ZYbIu:
            $csSew = $irUDM->getMedia();
            goto X4aFw;
            fUupM:
        })->values();
        goto fauTF;
        zwKqu:
        list($DLnNy, $NLi1w, $cIfRM, $E48S7, $L6YB7) = $esYR1;
        goto FpVBn;
        X7jIR:
        goto U0u_Q;
        goto lVsUB;
        WFCoG:
        if (!$L6YB7) {
            goto W9_Xm;
        }
        goto JGzBJ;
        qKg3K:
        $pkaxq = $pkaxq->where('status', '=', StatusEnum::zdeVn);
        goto kUV7M;
        YwTOI:
        $pkaxq = $this->mF6oGOLBWsT($DLnNy, $NLi1w, $pkaxq);
        goto I1OHA;
        kUV7M:
        U0u_Q:
        goto YwTOI;
        fauTF:
        return ['page' => $cIfRM, 'total' => $l7Cgf, 'item_per_page' => $E48S7, 'data' => $G4taM];
        goto ya6Fu;
        cyOII:
        $pkaxq = $pkaxq->where('status', '=', StatusEnum::zdeVn);
        goto IOIUw;
        JGzBJ:
        if (!in_array('approved', $DLnNy['types'] ?? [])) {
            goto SaKdX;
        }
        goto cyOII;
        ya6Fu:
    }
    private function mF6oGOLBWsT(array $DLnNy, array $jVM57, Builder $Eo278) : Builder
    {
        goto QCzzn;
        EQJLj:
        return $Eo278;
        goto KVE_F;
        fM_w0:
        b4UL_:
        goto EQJLj;
        QCzzn:
        foreach ($this->hUKh7 as $c_djD => $Fp2Kv) {
            goto iFnwy;
            cjrWc:
            $rUzrV->mCs88Lgj6p3($Eo278, $jVM57[$c_djD], false);
            goto Jyyam;
            iFnwy:
            if (isset($DLnNy[$c_djD]) && !isset($jVM57[$c_djD])) {
                goto qJRl6;
            }
            goto eJGJe;
            zvUVm:
            goto IHT5P;
            goto YBgfU;
            FPwWz:
            $rUzrV->mCs88Lgj6p3($Eo278, $DLnNy[$c_djD]);
            goto bHLqy;
            bHLqy:
            IHT5P:
            goto ju_q0;
            goEGE:
            $rUzrV = new $Fp2Kv();
            goto cjrWc;
            ju_q0:
            fpiQu:
            goto jAOVO;
            eJGJe:
            if (!isset($jVM57[$c_djD])) {
                goto Vba37;
            }
            goto goEGE;
            EtvVo:
            $rUzrV = new $Fp2Kv();
            goto FPwWz;
            Jyyam:
            Vba37:
            goto zvUVm;
            YBgfU:
            qJRl6:
            goto EtvVo;
            jAOVO:
        }
        goto fM_w0;
        KVE_F:
    }
    public function saveItems(array $iG2dc) : void
    {
        foreach ($iG2dc as $PQjbH) {
            goto SIAG_;
            hhXEm:
            $ij6wF = Media::find($PQjbH);
            goto Ibx3Q;
            CMxeT:
            CHXDL:
            goto BvpyR;
            BvpyR:
            lT2Ax:
            goto HYjs0;
            DOs4v:
            if ($irUDM) {
                goto CHXDL;
            }
            goto hhXEm;
            Ibx3Q:
            Cloud::meOChrrO2tx($ij6wF, StatusEnum::R5xNX);
            goto CMxeT;
            SIAG_:
            $irUDM = Cloud::find($PQjbH);
            goto DOs4v;
            HYjs0:
        }
        FL2v2:
    }
    public function delete(string $ld8Ad) : void
    {
        $irUDM = Cloud::findOrFail($ld8Ad);
        $irUDM->delete();
    }
}
