<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\D82QX6UHjIKzU;
use Jfs\Gallery\Service\Search\Tb6XnnkLG7dBG;
use Jfs\Gallery\Service\Search\NAWBYIb80ejhb;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class FlJAt0fGhvGBs implements GalleryCloudInterface
{
    private $gaNM_ = ['types' => NAWBYIb80ejhb::class, 'category' => D82QX6UHjIKzU::class];
    public function search(int $mGabZ, $nS208) : array
    {
        goto Z588H;
        zVJnx:
        RzPjT:
        goto SSgVC;
        VfsTt:
        goto RzPjT;
        goto re5KN;
        LORLJ:
        if (!$KxhQu) {
            goto DdibE;
        }
        goto HAVTt;
        clSHh:
        $ROoCy = $ROoCy->where('status', '=', StatusEnum::cuyHb);
        goto zVJnx;
        OLMzm:
        $ROoCy = Cloud::query()->where('user_id', $mGabZ);
        goto LORLJ;
        NPnUC:
        $MjYm9 = DB::query()->fromSub($ROoCy, 't')->selectRaw('count(*) as total')->first()->total;
        goto puAXy;
        cTFC5:
        F1Xpu:
        goto VfsTt;
        puAXy:
        $KZQPV = $ROoCy->with('media')->orderBy('created_at', 'desc')->limit($OukeE)->offset(($YwUhx - 1) * $OukeE)->get()->filter(function (Cloud $G5mvt) {
            return $G5mvt->getMedia() != null;
        })->map(function (Cloud $G5mvt) {
            goto lDeFJ;
            wIUXV:
            return array_merge($JsoDj, ['type' => $G5mvt->getAttribute('type'), 'status' => $G5mvt->getAttribute('status')]);
            goto N305n;
            lxb5U:
            $JsoDj = $XCcud->getView();
            goto wIUXV;
            lDeFJ:
            $XCcud = $G5mvt->getMedia();
            goto lxb5U;
            N305n:
        })->values();
        goto GYGS5;
        Z588H:
        list($nMK1O, $kxfnW, $YwUhx, $OukeE, $KxhQu) = $nS208;
        goto OLMzm;
        re5KN:
        DdibE:
        goto clSHh;
        HAVTt:
        if (!in_array('approved', $nMK1O['types'] ?? [])) {
            goto F1Xpu;
        }
        goto RibWB;
        SSgVC:
        $ROoCy = $this->mmg5gBY5byP($nMK1O, $kxfnW, $ROoCy);
        goto NPnUC;
        Tb7o2:
        $nMK1O['types'] = array_filter($nMK1O['types'], function ($czlXb) {
            return $czlXb !== 'approved';
        });
        goto cTFC5;
        RibWB:
        $ROoCy = $ROoCy->where('status', '=', StatusEnum::cuyHb);
        goto Tb7o2;
        GYGS5:
        return ['page' => $YwUhx, 'total' => $MjYm9, 'item_per_page' => $OukeE, 'data' => $KZQPV];
        goto V3QGO;
        V3QGO:
    }
    private function mmg5gBY5byP(array $nMK1O, array $RFBOp, Builder $Vcwqy) : Builder
    {
        goto vmim8;
        uquxT:
        return $Vcwqy;
        goto Er3J_;
        vmim8:
        foreach ($this->gaNM_ as $Joaj9 => $UVYL4) {
            goto TLSBl;
            y8Ns7:
            if (!isset($RFBOp[$Joaj9])) {
                goto HehmU;
            }
            goto tOHrG;
            G13Ac:
            goto S_qJC;
            goto zoa9Y;
            K0erF:
            $S2wj1->mFqhJmqKFVV($Vcwqy, $nMK1O[$Joaj9], true);
            goto aOn1N;
            tOHrG:
            $S2wj1 = new $UVYL4();
            goto g0ZgD;
            u0Ew1:
            gRMZC:
            goto mPEcj;
            g0ZgD:
            $S2wj1->mFqhJmqKFVV($Vcwqy, $RFBOp[$Joaj9], false);
            goto oBYra;
            t8wP4:
            $S2wj1 = new $UVYL4();
            goto K0erF;
            aOn1N:
            S_qJC:
            goto u0Ew1;
            zoa9Y:
            avWva:
            goto t8wP4;
            TLSBl:
            if (isset($nMK1O[$Joaj9]) && !isset($RFBOp[$Joaj9])) {
                goto avWva;
            }
            goto y8Ns7;
            oBYra:
            HehmU:
            goto G13Ac;
            mPEcj:
        }
        goto Dgx_1;
        Dgx_1:
        oypQZ:
        goto uquxT;
        Er3J_:
    }
    public function saveItems(array $QxRZn) : void
    {
        foreach ($QxRZn as $mz56v) {
            goto lI70a;
            eadvF:
            Cloud::m7b2b5lZv6Q($wEV0l, StatusEnum::O8kxk);
            goto eHXcY;
            eHXcY:
            NP4Av:
            goto JCD8x;
            u9XZv:
            if ($G5mvt) {
                goto NP4Av;
            }
            goto DGFE7;
            DGFE7:
            $wEV0l = Media::find($mz56v);
            goto eadvF;
            JCD8x:
            kl83y:
            goto taQmU;
            lI70a:
            $G5mvt = Cloud::find($mz56v);
            goto u9XZv;
            taQmU:
        }
        sTxBV:
    }
    public function delete(string $q8q1b) : void
    {
        $G5mvt = Cloud::findOrFail($q8q1b);
        $G5mvt->delete();
    }
}
