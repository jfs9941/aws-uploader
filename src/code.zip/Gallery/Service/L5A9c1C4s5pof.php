<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\LmRGiyUYHPggD;
use Jfs\Gallery\Model\Enum\GNpRKk9LZahTX;
use Jfs\Gallery\Model\Zcsux86vedhuJ;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Gallery\Service\Search\Ml4NQlMQxMrJS;
use Jfs\Gallery\Service\Search\I2CdekWrLhBZD;
use Jfs\Gallery\Service\Search\EcZWhJKnvFV0v;
use Illuminate\Database\Eloquent\Builder;
final class L5A9c1C4s5pof implements GalleryCloudInterface
{
    private $ASjDy = ['types' => EcZWhJKnvFV0v::class, 'category' => Ml4NQlMQxMrJS::class];
    public function search(int $jVUTM, $rFAhO) : array
    {
        goto bBcvx;
        VQpz0:
        if (!$EBF3F) {
            goto k69sW;
        }
        goto pbhDm;
        bBcvx:
        list($HTtys, $mOZ6S, $OntHZ, $EBF3F) = $rFAhO;
        goto cvW3k;
        RRLz0:
        goto KHcTj;
        goto rABuE;
        cvW3k:
        $FEOX0 = LmRGiyUYHPggD::query()->where('user_id', $jVUTM);
        goto VQpz0;
        uSL2y:
        $FEOX0 = $FEOX0->where('status', '=', GNpRKk9LZahTX::cZBFX);
        goto dxQOU;
        ZBIWY:
        $OhmzR = DB::query()->fromSub($FEOX0, 't')->selectRaw('count(*) as total')->first()->total;
        goto FwAne;
        dxQOU:
        KHcTj:
        goto cK6hr;
        FwAne:
        $bZOiO = $FEOX0->with('media')->orderBy('created_at', 'desc')->limit($OntHZ)->offset(($mOZ6S - 1) * $OntHZ)->get()->filter(function (LmRGiyUYHPggD $g5N3U) {
            return $g5N3U->CANAC != null;
        })->map(function (LmRGiyUYHPggD $g5N3U) {
            goto YVApn;
            YVApn:
            $p2x5d = $g5N3U->CANAC;
            goto cu9VO;
            LhrVF:
            return array_merge($NyT6D, ['type' => $g5N3U->getAttribute('type'), 'status' => $g5N3U->getAttribute('status')]);
            goto IN1yG;
            cu9VO:
            $NyT6D = $p2x5d->getView();
            goto LhrVF;
            IN1yG:
        })->values();
        goto L6Swr;
        pbhDm:
        if (!in_array('approved', $HTtys['types'] ?? [])) {
            goto fU2dq;
        }
        goto BXmsC;
        hVd2h:
        $HTtys['types'] = array_filter($HTtys['types'], function ($JO1HJ) {
            return $JO1HJ !== 'approved';
        });
        goto R293I;
        cK6hr:
        $FEOX0 = $this->mlktVlUWY6g($HTtys, $FEOX0);
        goto ZBIWY;
        L6Swr:
        return ['page' => $mOZ6S, 'total' => $OhmzR, 'item_per_page' => $OntHZ, 'data' => $bZOiO];
        goto mTyxz;
        BXmsC:
        $FEOX0 = $FEOX0->where('status', '=', GNpRKk9LZahTX::cZBFX);
        goto hVd2h;
        rABuE:
        k69sW:
        goto uSL2y;
        R293I:
        fU2dq:
        goto RRLz0;
        mTyxz:
    }
    private function mlktVlUWY6g(array $HTtys, Builder $kZRaS) : Builder
    {
        goto M4THD;
        WgoxA:
        return $kZRaS;
        goto ExpbZ;
        yMYui:
        e7Xp6:
        goto WgoxA;
        M4THD:
        foreach ($this->ASjDy as $ldXHt => $T3ApO) {
            goto VObff;
            Pkds8:
            $ZUtPv = new $T3ApO();
            goto kpxym;
            kpxym:
            $ZUtPv->mwjFqbEzoUX($kZRaS, $HTtys[$ldXHt]);
            goto EGnZB;
            EGnZB:
            oDDyU:
            goto D1VDj;
            D1VDj:
            VgEc8:
            goto VzUgR;
            VObff:
            if (!isset($HTtys[$ldXHt])) {
                goto oDDyU;
            }
            goto Pkds8;
            VzUgR:
        }
        goto yMYui;
        ExpbZ:
    }
    public function saveItems(array $qOlKJ) : void
    {
        foreach ($qOlKJ as $TFA4Z) {
            goto Cr6ta;
            Cr6ta:
            $g5N3U = LmRGiyUYHPggD::find($TFA4Z);
            goto Hau1O;
            AKoG5:
            LmRGiyUYHPggD::mbX6JECC7bs($q8Cz4, GNpRKk9LZahTX::NqbhY);
            goto PobCS;
            awuQj:
            knyP9:
            goto fFN5u;
            Hau1O:
            if ($g5N3U) {
                goto vkPnr;
            }
            goto aKKnm;
            aKKnm:
            $q8Cz4 = Zcsux86vedhuJ::find($TFA4Z);
            goto AKoG5;
            PobCS:
            vkPnr:
            goto awuQj;
            fFN5u:
        }
        GrqUo:
    }
    public function delete(string $ElvKF) : void
    {
        $g5N3U = LmRGiyUYHPggD::findOrFail($ElvKF);
        $g5N3U->delete();
    }
}
