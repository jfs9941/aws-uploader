<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\UujWTK10RdRUx;
use Jfs\Gallery\Service\Search\R4hgN1ScCYWoI;
use Jfs\Gallery\Service\Search\YwVtfmlvVg9tW;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class QwdElzovmeJgR implements GalleryCloudInterface
{
    private $i6Kht = ['types' => YwVtfmlvVg9tW::class, 'category' => UujWTK10RdRUx::class];
    public function search(int $WBtzJ, $Kmxio) : array
    {
        goto gGjEI;
        Gq88_:
        t5LA2:
        goto AMNbw;
        JlZPs:
        $GDE2J = $GDE2J->where('status', '=', StatusEnum::GebaN);
        goto ICvIA;
        TzMbe:
        if (!in_array('approved', $HLNso['types'] ?? [])) {
            goto t5LA2;
        }
        goto YM0qH;
        YM0qH:
        $GDE2J = $GDE2J->where('status', '=', StatusEnum::GebaN);
        goto qcthe;
        A45rA:
        if (!$LK97H) {
            goto Ftefq;
        }
        goto TzMbe;
        w2BPs:
        $GDE2J = Cloud::query()->where('user_id', $WBtzJ);
        goto A45rA;
        AMNbw:
        goto J5zMN;
        goto rIeue;
        Ie04n:
        return ['page' => $CJueO, 'total' => $q8UUB, 'item_per_page' => $mkydX, 'data' => $bzyUS];
        goto RRZsY;
        ICvIA:
        J5zMN:
        goto b7ysn;
        exmnp:
        $bzyUS = $GDE2J->with('media')->orderBy('created_at', 'desc')->limit($mkydX)->offset(($CJueO - 1) * $mkydX)->get()->filter(function (Cloud $zQ7Gb) {
            return $zQ7Gb->getMedia() != null;
        })->map(function (Cloud $zQ7Gb) {
            goto FZsNV;
            W_4Hl:
            return array_merge($zFO_M, ['type' => $zQ7Gb->getAttribute('type'), 'status' => $zQ7Gb->getAttribute('status')]);
            goto b77J8;
            YElRS:
            $zFO_M = $WtNuf->getView();
            goto W_4Hl;
            FZsNV:
            $WtNuf = $zQ7Gb->getMedia();
            goto YElRS;
            b77J8:
        })->values();
        goto Ie04n;
        b7ysn:
        $GDE2J = $this->mrD8iOGuA10($HLNso, $NX9qR, $GDE2J);
        goto ebk50;
        rIeue:
        Ftefq:
        goto JlZPs;
        ebk50:
        $q8UUB = DB::query()->fromSub($GDE2J, 't')->selectRaw('count(*) as total')->first()->total;
        goto exmnp;
        qcthe:
        $HLNso['types'] = array_filter($HLNso['types'], function ($nOhUl) {
            return $nOhUl !== 'approved';
        });
        goto Gq88_;
        gGjEI:
        list($HLNso, $NX9qR, $CJueO, $mkydX, $LK97H) = $Kmxio;
        goto w2BPs;
        RRZsY:
    }
    private function mrD8iOGuA10(array $HLNso, array $N1USh, Builder $hY2O_) : Builder
    {
        goto IkrGa;
        IkrGa:
        foreach ($this->i6Kht as $fJ5XG => $jRJKL) {
            goto O0lzF;
            SJHTn:
            ochGy:
            goto J03Bk;
            Kv7Yi:
            wiFun:
            goto rwKMN;
            UqsRn:
            JnG4_:
            goto eiYo_;
            O0lzF:
            if (isset($HLNso[$fJ5XG]) && !isset($N1USh[$fJ5XG])) {
                goto ochGy;
            }
            goto is9Hy;
            is9Hy:
            if (!isset($N1USh[$fJ5XG])) {
                goto JnG4_;
            }
            goto NvG_E;
            G8LWX:
            $lpgm8->mYE8mYEP5g7($hY2O_, $N1USh[$fJ5XG], false);
            goto UqsRn;
            rwKMN:
            mkznI:
            goto XiEsm;
            J03Bk:
            $lpgm8 = new $jRJKL();
            goto HkkF0;
            HkkF0:
            $lpgm8->mYE8mYEP5g7($hY2O_, $HLNso[$fJ5XG], true);
            goto Kv7Yi;
            NvG_E:
            $lpgm8 = new $jRJKL();
            goto G8LWX;
            eiYo_:
            goto wiFun;
            goto SJHTn;
            XiEsm:
        }
        goto maFeg;
        maFeg:
        EZHME:
        goto zPq4Z;
        zPq4Z:
        return $hY2O_;
        goto lHGyu;
        lHGyu:
    }
    public function saveItems(array $Z48PP) : void
    {
        foreach ($Z48PP as $VslFR) {
            goto Xw_o3;
            uS2au:
            if ($zQ7Gb) {
                goto z51b5;
            }
            goto Rrlvq;
            Cng9R:
            PCFJF:
            goto YOwiQ;
            Xw_o3:
            $zQ7Gb = Cloud::find($VslFR);
            goto uS2au;
            o0hiL:
            z51b5:
            goto Cng9R;
            Rrlvq:
            $s86ub = Media::find($VslFR);
            goto qsjyt;
            qsjyt:
            Cloud::m8WgnmlHPKo($s86ub, StatusEnum::doinC);
            goto o0hiL;
            YOwiQ:
        }
        yhh79:
    }
    public function delete(string $hOWbX) : void
    {
        $zQ7Gb = Cloud::findOrFail($hOWbX);
        $zQ7Gb->delete();
    }
}
