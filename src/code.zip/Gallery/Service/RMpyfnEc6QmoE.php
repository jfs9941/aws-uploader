<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\Ya04lXtQOyBdj;
use Jfs\Gallery\Service\Search\HpA17PWfMPObT;
use Jfs\Gallery\Service\Search\Q9yvpZrisuBqc;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class RMpyfnEc6QmoE implements GalleryCloudInterface
{
    private $WlUtG = ['types' => Q9yvpZrisuBqc::class, 'category' => Ya04lXtQOyBdj::class];
    public function search(int $J7E9r, $qORAP) : array
    {
        goto INaLd;
        JjrXR:
        hM1S0:
        goto cnIVj;
        Ppnjm:
        $yEc9h['types'] = array_filter($yEc9h['types'], function ($rr5Ms) {
            return $rr5Ms !== 'approved';
        });
        goto JjrXR;
        nAerM:
        $pVb4c = $vX3b_->with('media')->orderBy('created_at', 'desc')->limit($c1mEk)->offset(($CqyG8 - 1) * $c1mEk)->get()->filter(function (Cloud $Q8K7a) {
            return $Q8K7a->getMedia() != null;
        })->map(function (Cloud $Q8K7a) {
            goto maH4N;
            WGfdn:
            return array_merge($iLsZb, ['type' => $Q8K7a->getAttribute('type'), 'status' => $Q8K7a->getAttribute('status')]);
            goto Hnysf;
            Ie_lx:
            $iLsZb = $LiWvx->getView();
            goto WGfdn;
            maH4N:
            $LiWvx = $Q8K7a->getMedia();
            goto Ie_lx;
            Hnysf:
        })->values();
        goto caFnX;
        MOSGr:
        WPh97:
        goto UklTX;
        caFnX:
        return ['page' => $CqyG8, 'total' => $JjMfO, 'item_per_page' => $c1mEk, 'data' => $pVb4c];
        goto foaIK;
        cnIVj:
        goto xrYbO;
        goto MOSGr;
        INaLd:
        list($yEc9h, $nS7U3, $CqyG8, $c1mEk, $dhgR7) = $qORAP;
        goto th_af;
        iv0LR:
        $vX3b_ = $this->mEIGD84LcTK($yEc9h, $nS7U3, $vX3b_);
        goto L11_h;
        UklTX:
        $vX3b_ = $vX3b_->where('status', '=', StatusEnum::KKfuY);
        goto X_4i4;
        L11_h:
        $JjMfO = DB::query()->fromSub($vX3b_, 't')->selectRaw('count(*) as total')->first()->total;
        goto nAerM;
        Z8RvA:
        if (!$dhgR7) {
            goto WPh97;
        }
        goto Lln3c;
        X_4i4:
        xrYbO:
        goto iv0LR;
        th_af:
        $vX3b_ = Cloud::query()->where('user_id', $J7E9r);
        goto Z8RvA;
        Lln3c:
        if (!in_array('approved', $yEc9h['types'] ?? [])) {
            goto hM1S0;
        }
        goto yQIft;
        yQIft:
        $vX3b_ = $vX3b_->where('status', '=', StatusEnum::KKfuY);
        goto Ppnjm;
        foaIK:
    }
    private function mEIGD84LcTK(array $yEc9h, array $rGl97, Builder $GkjMb) : Builder
    {
        goto ZyjPl;
        aeNp3:
        return $GkjMb;
        goto SmMYB;
        vyqDj:
        WAIO7:
        goto aeNp3;
        ZyjPl:
        foreach ($this->WlUtG as $ZkMxM => $fSw7G) {
            goto Aj3FC;
            DFkNn:
            $pyQIr = new $fSw7G();
            goto z9TEa;
            WkZnV:
            goto UYVab;
            goto sBdrr;
            Aj3FC:
            if (isset($yEc9h[$ZkMxM]) && !isset($rGl97[$ZkMxM])) {
                goto FZElK;
            }
            goto K6uvU;
            K6uvU:
            if (!isset($rGl97[$ZkMxM])) {
                goto dCpma;
            }
            goto DFkNn;
            r3avS:
            UYVab:
            goto Q9o9z;
            Q9o9z:
            uzyY0:
            goto R08L2;
            sBdrr:
            FZElK:
            goto PwcEX;
            PwcEX:
            $pyQIr = new $fSw7G();
            goto utBvp;
            rhbXF:
            dCpma:
            goto WkZnV;
            z9TEa:
            $pyQIr->m00oogy0owc($GkjMb, $rGl97[$ZkMxM], false);
            goto rhbXF;
            utBvp:
            $pyQIr->m00oogy0owc($GkjMb, $yEc9h[$ZkMxM], true);
            goto r3avS;
            R08L2:
        }
        goto vyqDj;
        SmMYB:
    }
    public function saveItems(array $VJ_aJ) : void
    {
        foreach ($VJ_aJ as $eQ4Ln) {
            goto zrOVW;
            QqIDK:
            $k3Lov = Media::find($eQ4Ln);
            goto i56kA;
            i1V9H:
            if ($Q8K7a) {
                goto Gr3Tg;
            }
            goto QqIDK;
            Aetma:
            Gr3Tg:
            goto BQHIu;
            i56kA:
            Cloud::mNCF8Xhym4w($k3Lov, StatusEnum::fRsgg);
            goto Aetma;
            BQHIu:
            hnbnu:
            goto p3mlQ;
            zrOVW:
            $Q8K7a = Cloud::find($eQ4Ln);
            goto i1V9H;
            p3mlQ:
        }
        lAMJq:
    }
    public function delete(string $g5e_r) : void
    {
        $Q8K7a = Cloud::findOrFail($g5e_r);
        $Q8K7a->delete();
    }
}
