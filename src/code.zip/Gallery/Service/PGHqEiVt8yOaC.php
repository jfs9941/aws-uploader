<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Gallery\Service\Search\Wivz49gnWFj1W;
use Jfs\Gallery\Service\Search\R3QFmJg6F6ARf;
use Jfs\Gallery\Service\Search\Y3m3hZl4G0uZi;
use Illuminate\Database\Eloquent\Builder;
final class PGHqEiVt8yOaC implements GalleryCloudInterface
{
    private $LzWgI = ['types' => Y3m3hZl4G0uZi::class, 'category' => Wivz49gnWFj1W::class];
    public function search(int $PFtUr, $NWImw) : array
    {
        goto rWD5T;
        uNuMQ:
        $Uyqh2 = $Uyqh2->where('status', '=', StatusEnum::Rvner);
        goto ay7KI;
        rWD5T:
        list($MFIF7, $rELz5, $dQYUf, $N8z7f) = $NWImw;
        goto eR5pU;
        eR5pU:
        $Uyqh2 = Cloud::query()->where('user_id', $PFtUr);
        goto be56v;
        p6ILb:
        $Uyqh2 = $Uyqh2->where('status', '=', StatusEnum::Rvner);
        goto gZzxg;
        bWWPv:
        $fQeoC = DB::query()->fromSub($Uyqh2, 't')->selectRaw('count(*) as total')->first()->total;
        goto L14fX;
        MhA2R:
        $Uyqh2 = $this->mRoAUFrAU0D($MFIF7, $Uyqh2);
        goto bWWPv;
        M7w0J:
        if (!in_array('approved', $MFIF7['types'] ?? [])) {
            goto TNylI;
        }
        goto p6ILb;
        TjLGO:
        Rqwco:
        goto uNuMQ;
        b32z5:
        TNylI:
        goto WOJtA;
        be56v:
        if (!$N8z7f) {
            goto Rqwco;
        }
        goto M7w0J;
        ay7KI:
        ojsLy:
        goto MhA2R;
        bHEAF:
        return ['page' => $rELz5, 'total' => $fQeoC, 'item_per_page' => $dQYUf, 'data' => $BVjJ8];
        goto sVytR;
        gZzxg:
        $MFIF7['types'] = array_filter($MFIF7['types'], function ($W1eEp) {
            return $W1eEp !== 'approved';
        });
        goto b32z5;
        WOJtA:
        goto ojsLy;
        goto TjLGO;
        L14fX:
        $BVjJ8 = $Uyqh2->with('media')->orderBy('created_at', 'desc')->limit($dQYUf)->offset(($rELz5 - 1) * $dQYUf)->get()->filter(function (Cloud $tAUSd) {
            return $tAUSd->getMedia() != null;
        })->map(function (Cloud $tAUSd) {
            goto saCFr;
            nfixD:
            $pQ0Yz = $wpJD9->getView();
            goto N5yGX;
            saCFr:
            $wpJD9 = $tAUSd->getMedia();
            goto nfixD;
            N5yGX:
            return array_merge($pQ0Yz, ['type' => $tAUSd->getAttribute('type'), 'status' => $tAUSd->getAttribute('status')]);
            goto TGN6Q;
            TGN6Q:
        })->values();
        goto bHEAF;
        sVytR:
    }
    private function mRoAUFrAU0D(array $MFIF7, Builder $PuAgf) : Builder
    {
        goto lGQVA;
        lGQVA:
        foreach ($this->LzWgI as $M_WPB => $SmDcL) {
            goto DKIbP;
            l54AW:
            AAdgO:
            goto wBbOG;
            DKIbP:
            if (!isset($MFIF7[$M_WPB])) {
                goto zZPDc;
            }
            goto I3P5O;
            vzkCS:
            zZPDc:
            goto l54AW;
            I3P5O:
            $k2eLu = new $SmDcL();
            goto bQgUM;
            bQgUM:
            $k2eLu->mcTvhVRb3hm($PuAgf, $MFIF7[$M_WPB]);
            goto vzkCS;
            wBbOG:
        }
        goto xwZu1;
        yfqGW:
        return $PuAgf;
        goto cxMs_;
        xwZu1:
        Su6jR:
        goto yfqGW;
        cxMs_:
    }
    public function saveItems(array $pnBnL) : void
    {
        foreach ($pnBnL as $ezBDN) {
            goto rD7QD;
            cl2yW:
            $pwWUc = Media::find($ezBDN);
            goto MIwGJ;
            XAInh:
            if ($tAUSd) {
                goto inbEp;
            }
            goto cl2yW;
            Eupyi:
            fdvZ4:
            goto dz14W;
            MIwGJ:
            Cloud::monsP5YDoJt($pwWUc, StatusEnum::l50Bu);
            goto WFTgx;
            WFTgx:
            inbEp:
            goto Eupyi;
            rD7QD:
            $tAUSd = Cloud::find($ezBDN);
            goto XAInh;
            dz14W:
        }
        ZFNzi:
    }
    public function delete(string $eXur0) : void
    {
        $tAUSd = Cloud::findOrFail($eXur0);
        $tAUSd->delete();
    }
}
