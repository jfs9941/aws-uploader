<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\RhEboCp7PSE6E;
use Jfs\Gallery\Service\Search\EWz4UlANqCQvW;
use Jfs\Gallery\Service\Search\PZWacCTDYt7yI;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class GOwwZ3Q3r8QRr implements GalleryCloudInterface
{
    private $FIte7 = ['types' => PZWacCTDYt7yI::class, 'category' => RhEboCp7PSE6E::class];
    public function search(int $hM9Ud, $bNndm) : array
    {
        goto Owfk2;
        Ewalq:
        $T6xcV = DB::query()->fromSub($CLdse, 't')->selectRaw('count(*) as total')->first()->total;
        goto KsPQK;
        gcNt7:
        $CLdse = $this->myD8NxIXGJW($CChZQ, $CfB9W, $CLdse);
        goto Ewalq;
        T6Sbt:
        $CLdse = Cloud::query()->where('user_id', $hM9Ud);
        goto F10ma;
        F10ma:
        if (!$ovMwH) {
            goto eTZ9d;
        }
        goto lhTuY;
        UUjTt:
        $CChZQ['types'] = array_filter($CChZQ['types'], function ($W6ajt) {
            return $W6ajt !== 'approved';
        });
        goto doLvg;
        Bbvqm:
        return ['page' => $vhaI8, 'total' => $T6xcV, 'item_per_page' => $VFfqb, 'data' => $uyT2h];
        goto oSnEN;
        KsPQK:
        $uyT2h = $CLdse->with('media')->orderBy('created_at', 'desc')->limit($VFfqb)->offset(($vhaI8 - 1) * $VFfqb)->get()->filter(function (Cloud $PS9pL) {
            return $PS9pL->getMedia() != null;
        })->map(function (Cloud $PS9pL) {
            goto XyTeW;
            XyTeW:
            $F251H = $PS9pL->getMedia();
            goto MIpFL;
            PHPux:
            return array_merge($IgxEE, ['type' => $PS9pL->getAttribute('type'), 'status' => $PS9pL->getAttribute('status')]);
            goto NpM_T;
            MIpFL:
            $IgxEE = $F251H->getView();
            goto PHPux;
            NpM_T:
        })->values();
        goto Bbvqm;
        doLvg:
        DV7iR:
        goto iY8z2;
        wTzAA:
        $CLdse = $CLdse->where('status', '=', StatusEnum::uXeis);
        goto QIxET;
        mD1RZ:
        $CLdse = $CLdse->where('status', '=', StatusEnum::uXeis);
        goto UUjTt;
        lhTuY:
        if (!in_array('approved', $CChZQ['types'] ?? [])) {
            goto DV7iR;
        }
        goto mD1RZ;
        QIxET:
        VYKl8:
        goto gcNt7;
        iY8z2:
        goto VYKl8;
        goto a0rUP;
        Owfk2:
        list($CChZQ, $CfB9W, $vhaI8, $VFfqb, $ovMwH) = $bNndm;
        goto T6Sbt;
        a0rUP:
        eTZ9d:
        goto wTzAA;
        oSnEN:
    }
    private function myD8NxIXGJW(array $CChZQ, array $KH3xy, Builder $gWJqy) : Builder
    {
        goto WMHUT;
        jgLgP:
        return $gWJqy;
        goto xrrCL;
        wX9tc:
        BqPXO:
        goto jgLgP;
        WMHUT:
        foreach ($this->FIte7 as $Lew_W => $X3Wgi) {
            goto Jwuu2;
            tyeug:
            goto NP2G0;
            goto DzvJW;
            XFzJn:
            $u5kUz->mD0LEl18Mxz($gWJqy, $KH3xy[$Lew_W], false);
            goto NDt0c;
            eCpNw:
            $u5kUz = new $X3Wgi();
            goto XFzJn;
            Jwuu2:
            if (isset($CChZQ[$Lew_W]) && !isset($KH3xy[$Lew_W])) {
                goto AVL9w;
            }
            goto SKjJu;
            esUDf:
            h1Eza:
            goto hkUq4;
            DQCzf:
            $u5kUz->mD0LEl18Mxz($gWJqy, $CChZQ[$Lew_W], true);
            goto LaTN4;
            NDt0c:
            W59rX:
            goto tyeug;
            SKjJu:
            if (!isset($KH3xy[$Lew_W])) {
                goto W59rX;
            }
            goto eCpNw;
            DzvJW:
            AVL9w:
            goto ART0A;
            ART0A:
            $u5kUz = new $X3Wgi();
            goto DQCzf;
            LaTN4:
            NP2G0:
            goto esUDf;
            hkUq4:
        }
        goto wX9tc;
        xrrCL:
    }
    public function saveItems(array $QdlKD) : void
    {
        foreach ($QdlKD as $pemjO) {
            goto mkfhV;
            mkfhV:
            $PS9pL = Cloud::find($pemjO);
            goto lEf5R;
            nRwcE:
            Cloud::mSGcSxTcZ9I($xLiVA, StatusEnum::hwL4C);
            goto PAJe_;
            PAJe_:
            uhyZq:
            goto gZ97I;
            KZMPH:
            $xLiVA = Media::find($pemjO);
            goto nRwcE;
            gZ97I:
            uT5zD:
            goto JY5A2;
            lEf5R:
            if ($PS9pL) {
                goto uhyZq;
            }
            goto KZMPH;
            JY5A2:
        }
        Tz5sd:
    }
    public function delete(string $poSkG) : void
    {
        $PS9pL = Cloud::findOrFail($poSkG);
        $PS9pL->delete();
    }
}
