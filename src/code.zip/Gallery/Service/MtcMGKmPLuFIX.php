<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use src\Gallery\Model\Enum\K58fmXwYJHkrL;
use src\Gallery\Model\PYgdINKBVRjJT;
use src\Gallery\Model\QDkSZEWiaABWN;
use src\Gallery\Service\Search\Hw9Pra3lWfHW0;
use src\Gallery\Service\Search\RIz3xZFjFmOcn;
use src\Gallery\Service\Search\TjfQAwaWAJ4N9;
use src\Uploader\Contracts\MGwfEiRGIYlUs;
final class MtcMGKmPLuFIX implements GalleryCloudInterface
{
    private $Tiu63 = ['types' => Hw9Pra3lWfHW0::class, 'category' => RIz3xZFjFmOcn::class];
    public function search(int $Vy40_, $DMoQ3) : array
    {
        goto TxtYa;
        nWCkF:
        vX262:
        goto n8C77;
        kKWSm:
        VrvuU:
        goto RDhU0;
        Aqx2u:
        return ['page' => $VePzv, 'total' => $mcWik, 'item_per_page' => $cVK_y, 'data' => $aJeqW];
        goto lu9G2;
        TxtYa:
        list($dS2bP, $VePzv, $cVK_y, $obEDj) = $DMoQ3;
        goto uRLVj;
        n8C77:
        goto rWoiM;
        goto kKWSm;
        XHXuC:
        $mcWik = DB::query()->fromSub($V9Qgg, 't')->selectRaw('count(*) as total')->first()->total;
        goto YeLno;
        uRLVj:
        $V9Qgg = PYgdINKBVRjJT::query()->where('user_id', $Vy40_);
        goto T00vY;
        BY32y:
        rWoiM:
        goto mXv8E;
        T00vY:
        if (!$obEDj) {
            goto VrvuU;
        }
        goto UFKDB;
        ndeMO:
        $dS2bP['types'] = array_filter($dS2bP['types'], function ($DORmj) {
            return $DORmj !== 'approved';
        });
        goto nWCkF;
        UFKDB:
        if (!in_array('approved', $dS2bP['types'] ?? [])) {
            goto vX262;
        }
        goto whiQB;
        RDhU0:
        $V9Qgg = $V9Qgg->where('status', '=', K58fmXwYJHkrL::uZJ6l);
        goto BY32y;
        YeLno:
        $aJeqW = $V9Qgg->with('media')->orderBy('created_at', 'desc')->limit($cVK_y)->offset(($VePzv - 1) * $cVK_y)->get()->filter(function (PYgdINKBVRjJT $l9ed4) {
            return $l9ed4->KbfaX != null;
        })->map(function (PYgdINKBVRjJT $l9ed4) {
            goto eHH7j;
            hJXWx:
            return array_merge($S62kT, ['type' => $l9ed4->getAttribute('type'), 'status' => $l9ed4->getAttribute('status')]);
            goto qyJd3;
            HRZ7_:
            $S62kT = $ymghJ->getView();
            goto hJXWx;
            eHH7j:
            $ymghJ = $l9ed4->KbfaX;
            goto HRZ7_;
            qyJd3:
        })->values();
        goto Aqx2u;
        mXv8E:
        $V9Qgg = $this->mji9FhL2Rfo($dS2bP, $V9Qgg);
        goto XHXuC;
        whiQB:
        $V9Qgg = $V9Qgg->where('status', '=', K58fmXwYJHkrL::uZJ6l);
        goto ndeMO;
        lu9G2:
    }
    private function mji9FhL2Rfo(array $dS2bP, Builder $w31bN) : Builder
    {
        goto lqaib;
        lqaib:
        foreach ($this->Tiu63 as $yE4vt => $e15FG) {
            goto TDo_H;
            d_Cc7:
            XCnX1:
            goto H6c4T;
            D7wAN:
            pT31u:
            goto d_Cc7;
            TDo_H:
            if (!isset($dS2bP[$yE4vt])) {
                goto pT31u;
            }
            goto ZoWsC;
            ZoWsC:
            $h36rl = new $e15FG();
            goto nDHMp;
            nDHMp:
            $h36rl->mCaa0P7P2Ba($w31bN, $dS2bP[$yE4vt]);
            goto D7wAN;
            H6c4T:
        }
        goto h164s;
        h164s:
        J4vEh:
        goto GMZIJ;
        GMZIJ:
        return $w31bN;
        goto G_swA;
        G_swA:
    }
    public function saveItems(array $Hbr8K) : void
    {
        foreach ($Hbr8K as $d1aiC) {
            goto MKDC7;
            aWV2v:
            s1UD4:
            goto Lqn_n;
            v6wZU:
            PYgdINKBVRjJT::m9KJntBGD2I($BUvH7, K58fmXwYJHkrL::IlDDl);
            goto Fafvi;
            Fafvi:
            LndpB:
            goto aWV2v;
            MKDC7:
            $l9ed4 = PYgdINKBVRjJT::find($d1aiC);
            goto uQyNi;
            uQyNi:
            if ($l9ed4) {
                goto LndpB;
            }
            goto SeQ_O;
            SeQ_O:
            $BUvH7 = QDkSZEWiaABWN::find($d1aiC);
            goto v6wZU;
            Lqn_n:
        }
        oHaej:
    }
    public function delete(string $BFPg9) : void
    {
        $l9ed4 = PYgdINKBVRjJT::findOrFail($BFPg9);
        $l9ed4->delete();
    }
}
