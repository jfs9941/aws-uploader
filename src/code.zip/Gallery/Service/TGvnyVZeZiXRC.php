<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Gallery\Service\Search\UyiNihR1tMGud;
use Jfs\Gallery\Service\Search\Id1zmbqroCpYB;
use Jfs\Gallery\Service\Search\PgziA1DkeVgwz;
use Illuminate\Database\Eloquent\Builder;
final class TGvnyVZeZiXRC implements GalleryCloudInterface
{
    private $XXEvX = ['types' => PgziA1DkeVgwz::class, 'category' => UyiNihR1tMGud::class];
    public function search(int $r35ul, $TAW9m) : array
    {
        goto zmLPY;
        txjMt:
        $xXcZT = Cloud::query()->where('user_id', $r35ul);
        goto J5ucS;
        WXyHL:
        $BqCn5['types'] = array_filter($BqCn5['types'], function ($r4_LH) {
            return $r4_LH !== 'approved';
        });
        goto uiWLu;
        zmLPY:
        list($BqCn5, $dh3B1, $vzu1g, $Dk6MA, $h8s3X) = $TAW9m;
        goto txjMt;
        Uq8rb:
        goto zS9Fj;
        goto tmkXX;
        uoupS:
        return ['page' => $vzu1g, 'total' => $s7Lz4, 'item_per_page' => $Dk6MA, 'data' => $gy2ea];
        goto nwnIS;
        jstlA:
        $xXcZT = $xXcZT->where('status', '=', StatusEnum::Vn9e9);
        goto Kqu25;
        je086:
        if (!in_array('approved', $BqCn5['types'] ?? [])) {
            goto SHZH3;
        }
        goto SGLGc;
        SGLGc:
        $xXcZT = $xXcZT->where('status', '=', StatusEnum::Vn9e9);
        goto WXyHL;
        fKMVx:
        $s7Lz4 = DB::query()->fromSub($xXcZT, 't')->selectRaw('count(*) as total')->first()->total;
        goto g9oXs;
        g9oXs:
        $gy2ea = $xXcZT->with('media')->orderBy('created_at', 'desc')->limit($Dk6MA)->offset(($vzu1g - 1) * $Dk6MA)->get()->filter(function (Cloud $Hxnc0) {
            return $Hxnc0->getMedia() != null;
        })->map(function (Cloud $Hxnc0) {
            goto X8qnC;
            X8qnC:
            $qRTR9 = $Hxnc0->getMedia();
            goto fY6QY;
            UdgMZ:
            return array_merge($UY4mB, ['type' => $Hxnc0->getAttribute('type'), 'status' => $Hxnc0->getAttribute('status')]);
            goto WuIH7;
            fY6QY:
            $UY4mB = $qRTR9->getView();
            goto UdgMZ;
            WuIH7:
        })->values();
        goto uoupS;
        uiWLu:
        SHZH3:
        goto Uq8rb;
        Kqu25:
        zS9Fj:
        goto BynL3;
        BynL3:
        $xXcZT = $this->mdL17NGxHLx($BqCn5, $dh3B1, $xXcZT);
        goto fKMVx;
        tmkXX:
        jStJx:
        goto jstlA;
        J5ucS:
        if (!$h8s3X) {
            goto jStJx;
        }
        goto je086;
        nwnIS:
    }
    private function mdL17NGxHLx(array $BqCn5, array $JHKjl, Builder $xAWQW) : Builder
    {
        goto MnXru;
        JABkc:
        ewbvW:
        goto RD90X;
        RD90X:
        return $xAWQW;
        goto dRa0N;
        MnXru:
        foreach ($this->XXEvX as $NlWD6 => $XtU2k) {
            goto GW_Rh;
            Fe6NJ:
            Q_Za_:
            goto z38EL;
            UDWke:
            gieXD:
            goto Fe6NJ;
            D3nK7:
            $iML_9 = new $XtU2k();
            goto vV4JF;
            dRbcq:
            $iML_9->mZbAw7ISZ0W($xAWQW, $JHKjl[$NlWD6], false);
            goto vQVA4;
            GW_Rh:
            if (isset($BqCn5[$NlWD6]) && !isset($JHKjl[$NlWD6])) {
                goto I0aHn;
            }
            goto I9Cuw;
            vV4JF:
            $iML_9->mZbAw7ISZ0W($xAWQW, $BqCn5[$NlWD6]);
            goto UDWke;
            OiNPR:
            $iML_9 = new $XtU2k();
            goto dRbcq;
            I9Cuw:
            if (!isset($JHKjl[$NlWD6])) {
                goto umljG;
            }
            goto OiNPR;
            vQVA4:
            umljG:
            goto lN_no;
            lN_no:
            goto gieXD;
            goto jo1RS;
            jo1RS:
            I0aHn:
            goto D3nK7;
            z38EL:
        }
        goto JABkc;
        dRa0N:
    }
    public function saveItems(array $BLg6G) : void
    {
        foreach ($BLg6G as $a3XOL) {
            goto ahh0z;
            ahh0z:
            $Hxnc0 = Cloud::find($a3XOL);
            goto GEb_Y;
            yHiAa:
            $U9mNN = Media::find($a3XOL);
            goto qLUxg;
            xCN53:
            YQJ1T:
            goto MfS1A;
            Z16lw:
            macO4:
            goto xCN53;
            qLUxg:
            Cloud::m0aKDlthFPg($U9mNN, StatusEnum::OOLxl);
            goto Z16lw;
            GEb_Y:
            if ($Hxnc0) {
                goto macO4;
            }
            goto yHiAa;
            MfS1A:
        }
        HkZge:
    }
    public function delete(string $y06DH) : void
    {
        $Hxnc0 = Cloud::findOrFail($y06DH);
        $Hxnc0->delete();
    }
}
