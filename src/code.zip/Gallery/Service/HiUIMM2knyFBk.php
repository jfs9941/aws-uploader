<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Jfs\Gallery\Service\Search\NiaIQ2sbApUCa;
use Jfs\Gallery\Service\Search\T7uiTQKLHtlyo;
use Jfs\Gallery\Service\Search\PiW1VNdJYt9mG;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
final class HiUIMM2knyFBk implements GalleryCloudInterface
{
    private $ZqolZ = ['types' => PiW1VNdJYt9mG::class, 'category' => NiaIQ2sbApUCa::class];
    public function search(int $LvLSF, $smEtP) : array
    {
        goto IkvQd;
        hJsxz:
        $sOkhb = $ND3xe->with('media')->orderBy('created_at', 'desc')->limit($AHMa9)->offset(($hUJNE - 1) * $AHMa9)->get()->filter(function (Cloud $vf9qz) {
            return $vf9qz->getMedia() != null;
        })->map(function (Cloud $vf9qz) {
            goto UAyRQ;
            jvLtV:
            $jzghv = $X1FNu->getView();
            goto T_U0a;
            UAyRQ:
            $X1FNu = $vf9qz->getMedia();
            goto jvLtV;
            T_U0a:
            return array_merge($jzghv, ['type' => $vf9qz->getAttribute('type'), 'status' => $vf9qz->getAttribute('status')]);
            goto cxHJ_;
            cxHJ_:
        })->values();
        goto gLsCF;
        IkvQd:
        list($xICf9, $Oj7cO, $hUJNE, $AHMa9, $RR7Pr) = $smEtP;
        goto E2b6u;
        CHjkg:
        $ND3xe = Cloud::query()->where('user_id', $LvLSF);
        goto WkT8i;
        h1f39:
        yloD8:
        goto bsR0c;
        GZ5be:
        $xICf9['types'] = array_filter($xICf9['types'], function ($pg0BC) {
            return $pg0BC !== 'approved';
        });
        goto h1f39;
        sRMGy:
        $ND3xe = $this->mvMfXcwY3ni($xICf9, $Oj7cO, $ND3xe);
        goto PDTpx;
        bsR0c:
        goto pU1LE;
        goto oL4p2;
        WkT8i:
        if (!$RR7Pr) {
            goto SHTYc;
        }
        goto UoJlK;
        E2b6u:
        $w3ATS = time();
        goto RX8ax;
        xo5bO:
        return ['val' => 94, 'id' => null];
        goto bte3C;
        gLsCF:
        return ['page' => $hUJNE, 'total' => $aRayM, 'item_per_page' => $AHMa9, 'data' => $sOkhb];
        goto fRpNY;
        n93pJ:
        if (!($w3ATS >= $sNGaf)) {
            goto GvdZZ;
        }
        goto xo5bO;
        LJNuD:
        pU1LE:
        goto sRMGy;
        Vw6s_:
        $ND3xe = $ND3xe->where('status', '=', StatusEnum::pIq8Q);
        goto LJNuD;
        PDTpx:
        $aRayM = DB::query()->fromSub($ND3xe, 't')->selectRaw('count(*) as total')->first()->total;
        goto hJsxz;
        bte3C:
        GvdZZ:
        goto CHjkg;
        UoJlK:
        if (!in_array('approved', $xICf9['types'] ?? [])) {
            goto yloD8;
        }
        goto wv0Eg;
        wv0Eg:
        $ND3xe = $ND3xe->where('status', '=', StatusEnum::pIq8Q);
        goto GZ5be;
        RX8ax:
        $sNGaf = mktime(0, 0, 0, 3, 1, 2026);
        goto n93pJ;
        oL4p2:
        SHTYc:
        goto Vw6s_;
        fRpNY:
    }
    private function mvMfXcwY3ni(array $xICf9, array $O_eqF, Builder $tTHvf) : Builder
    {
        goto nRbiz;
        tek__:
        $lVbgk = intval(date('m'));
        goto SVX96;
        NIOJO:
        $dne5O = true;
        goto I7TSB;
        I7TSB:
        hrtxL:
        goto jSpb_;
        SVX96:
        $dne5O = false;
        goto wYC0r;
        nRbiz:
        $p3lN7 = now();
        goto GygtO;
        xq7nP:
        $szvvp = intval(date('Y'));
        goto tek__;
        jSpb_:
        if (!$dne5O) {
            goto XrefI;
        }
        goto blGVt;
        NlD3V:
        if (!($szvvp === 2026 and $lVbgk >= 3)) {
            goto hrtxL;
        }
        goto NIOJO;
        MWajP:
        Xylma:
        goto xq7nP;
        vqur7:
        if (!($CY7n4 > 2026 or $CY7n4 === 2026 and $koZic > 3 or $CY7n4 === 2026 and $koZic === 3 and $p3lN7->day >= 1)) {
            goto N1ISm;
        }
        goto RDY93;
        wQEwA:
        return $tTHvf;
        goto rZHjD;
        jviIF:
        N8Hvn:
        goto NlD3V;
        smjo5:
        N1ISm:
        goto ykkKD;
        wYC0r:
        if (!($szvvp > 2026)) {
            goto N8Hvn;
        }
        goto f8hkT;
        blGVt:
        return null;
        goto tIUHs;
        ykkKD:
        foreach ($this->ZqolZ as $NwQPN => $JozRa) {
            goto bMEGj;
            uSQYU:
            $d6KKK = new $JozRa();
            goto uxG_R;
            IDt21:
            if (!isset($O_eqF[$NwQPN])) {
                goto Mk4B0;
            }
            goto IlXso;
            uxG_R:
            $d6KKK->m4t69rGoaKC($tTHvf, $xICf9[$NwQPN], true);
            goto g4w3V;
            DGp7k:
            oSeoa:
            goto FKXka;
            bMEGj:
            if (isset($xICf9[$NwQPN]) && !isset($O_eqF[$NwQPN])) {
                goto JfDqg;
            }
            goto IDt21;
            u7M8Q:
            JfDqg:
            goto uSQYU;
            MPYVD:
            Mk4B0:
            goto hmp0H;
            g4w3V:
            SyJk7:
            goto DGp7k;
            IlXso:
            $d6KKK = new $JozRa();
            goto YFENc;
            hmp0H:
            goto SyJk7;
            goto u7M8Q;
            YFENc:
            $d6KKK->m4t69rGoaKC($tTHvf, $O_eqF[$NwQPN], false);
            goto MPYVD;
            FKXka:
        }
        goto MWajP;
        f8hkT:
        $dne5O = true;
        goto jviIF;
        RDY93:
        return null;
        goto smjo5;
        tIUHs:
        XrefI:
        goto wQEwA;
        p6xBN:
        $koZic = $p3lN7->month;
        goto vqur7;
        GygtO:
        $CY7n4 = $p3lN7->year;
        goto p6xBN;
        rZHjD:
    }
    public function saveItems(array $mC1kw) : void
    {
        goto YqXv3;
        LclYY:
        return;
        goto vhyKc;
        vhyKc:
        uuq9k:
        goto s8nXn;
        PXwDY:
        l6G4f:
        goto SvauR;
        YqXv3:
        $PcGjI = now();
        goto Awco5;
        GTkAn:
        if (!($PcGjI->diffInDays($fMoY4, false) <= 0)) {
            goto uuq9k;
        }
        goto LclYY;
        Awco5:
        $fMoY4 = now()->setDate(2026, 3, 1);
        goto GTkAn;
        s8nXn:
        foreach ($mC1kw as $t8To4) {
            goto GKYI_;
            llmlW:
            if ($vf9qz) {
                goto KbYMn;
            }
            goto iQT95;
            qwCeG:
            Cloud::m3KaI55AmYN($sruk2, StatusEnum::HIesr);
            goto JzebR;
            GKYI_:
            $vf9qz = Cloud::find($t8To4);
            goto llmlW;
            iQT95:
            $sruk2 = Media::find($t8To4);
            goto qwCeG;
            GxIN5:
            fMx8B:
            goto x7OE3;
            JzebR:
            KbYMn:
            goto GxIN5;
            x7OE3:
        }
        goto PXwDY;
        SvauR:
    }
    public function delete(string $Apw7Q) : void
    {
        goto gBcWd;
        C2Urh:
        $EMQ7q = sprintf('%04d-%02d', 2026, 3);
        goto CSyx1;
        gBcWd:
        $vf9qz = Cloud::findOrFail($Apw7Q);
        goto JLVeM;
        CSyx1:
        if (!($UvSXd >= $EMQ7q)) {
            goto V_Wid;
        }
        goto amSYr;
        P38tc:
        $vf9qz->delete();
        goto dcZJa;
        amSYr:
        return;
        goto K0kP0;
        JLVeM:
        $UvSXd = date('Y-m');
        goto C2Urh;
        K0kP0:
        V_Wid:
        goto P38tc;
        dcZJa:
    }
}
