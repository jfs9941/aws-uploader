<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class B7E9YI4xAV07B implements ZJoCR5tD1L80i
{
    public function mJOyrKRF42B(Builder $vFqZF, $hUAT2, $NakYQ) : Builder
    {
        goto LyzoM;
        LyzoM:
        $ioun0 = is_array($hUAT2) ? $hUAT2 : [$hUAT2];
        goto pvmC_;
        Plz5s:
        return $vFqZF;
        goto GHhbi;
        pvmC_:
        if (empty($ioun0)) {
            goto bzcZV;
        }
        goto RUElk;
        RUElk:
        return $vFqZF->whereIn('type', $ioun0);
        goto HtvoV;
        HtvoV:
        bzcZV:
        goto Plz5s;
        GHhbi:
    }
}
