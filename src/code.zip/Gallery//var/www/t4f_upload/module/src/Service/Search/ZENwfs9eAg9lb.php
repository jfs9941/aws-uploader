<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class ZENwfs9eAg9lb implements ZJoCR5tD1L80i
{
    protected const V_9S2 = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mJOyrKRF42B(Builder $vFqZF, $hUAT2, $NakYQ = true) : Builder
    {
        goto zxMP1;
        YvHW8:
        return $vFqZF->where($BQy8q, '=', $NakYQ);
        goto qLf8_;
        qLf8_:
        CwhwH:
        goto RIE_n;
        zxMP1:
        $HA_sc = Str::lower($hUAT2);
        goto vE8wf;
        RIE_n:
        return $vFqZF;
        goto t84ab;
        Qxc7g:
        $BQy8q = self::V_9S2[$HA_sc];
        goto YvHW8;
        vE8wf:
        if (!isset(self::V_9S2[$HA_sc])) {
            goto CwhwH;
        }
        goto Qxc7g;
        t84ab:
    }
}
