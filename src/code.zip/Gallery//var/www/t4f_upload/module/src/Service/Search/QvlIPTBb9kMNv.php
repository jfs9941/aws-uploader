<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class QvlIPTBb9kMNv implements W7UE9VEvPLsnq
{
    protected const vvmig = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mCmknAxLLai(Builder $yJoye, $g9iDI, $jmuFA = true) : Builder
    {
        goto d0c1W;
        vzhK8:
        $Y2sCk = self::vvmig[$GeYat];
        goto WKMtr;
        R_gCI:
        return $yJoye;
        goto B8XSr;
        WKMtr:
        return $yJoye->where($Y2sCk, '=', $jmuFA);
        goto qLQ7c;
        n16UY:
        if (!isset(self::vvmig[$GeYat])) {
            goto kUJLC;
        }
        goto vzhK8;
        qLQ7c:
        kUJLC:
        goto R_gCI;
        d0c1W:
        $GeYat = Str::lower($g9iDI);
        goto n16UY;
        B8XSr:
    }
}
