<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Service\Search\ZENwfs9eAg9lb;
use Jfs\Gallery\Service\Search\ZJoCR5tD1L80i;
use Jfs\Gallery\Service\Search\B7E9YI4xAV07B;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
final class PBI0DsEzGhtPt implements GalleryCloudInterface
{
    private $qCQMj = ['types' => B7E9YI4xAV07B::class, 'category' => ZENwfs9eAg9lb::class];
    public function search(int $hVGUs, $vGJng) : array
    {
        goto lYF6Q;
        OgJTo:
        goto a6mwO;
        goto jqZln;
        jqZln:
        tpNKa:
        goto eLlXt;
        lYF6Q:
        list($vuSlA, $RrDlb, $s6UWv, $Awg2g, $fkD1v) = $vGJng;
        goto lOqOn;
        ucVx6:
        $aBj0j = DB::query()->fromSub($eCeuv, 't')->selectRaw('count(*) as total')->first()->total;
        goto gKvkv;
        pgys7:
        $eCeuv = $this->mleS6HnJDel($vuSlA, $RrDlb, $eCeuv);
        goto ucVx6;
        gKvkv:
        $x53s1 = $eCeuv->with('media')->orderBy('created_at', 'desc')->limit($Awg2g)->offset(($s6UWv - 1) * $Awg2g)->get()->filter(function (Cloud $jGIip) {
            return $jGIip->getMedia() != null;
        })->map(function (Cloud $jGIip) {
            goto MVhI8;
            Z_M0o:
            $vKG6G = $esNyq->getView();
            goto BTjaJ;
            MVhI8:
            $esNyq = $jGIip->getMedia();
            goto Z_M0o;
            BTjaJ:
            return array_merge($vKG6G, ['type' => $jGIip->getAttribute('type'), 'status' => $jGIip->getAttribute('status')]);
            goto X0VWz;
            X0VWz:
        })->values();
        goto nvvvh;
        BGBpd:
        if (!$fkD1v) {
            goto tpNKa;
        }
        goto VHrWB;
        C0AKC:
        $vuSlA['types'] = array_filter($vuSlA['types'], function ($UkPBU) {
            return $UkPBU !== 'approved';
        });
        goto e_kyH;
        eFtYp:
        a6mwO:
        goto pgys7;
        e_kyH:
        vDRSA:
        goto OgJTo;
        VHrWB:
        if (!in_array('approved', $vuSlA['types'] ?? [])) {
            goto vDRSA;
        }
        goto K0g1D;
        eLlXt:
        $eCeuv = $eCeuv->where('status', '=', StatusEnum::CaVNd);
        goto eFtYp;
        lOqOn:
        $eCeuv = Cloud::query()->where('user_id', $hVGUs);
        goto BGBpd;
        K0g1D:
        $eCeuv = $eCeuv->where('status', '=', StatusEnum::CaVNd);
        goto C0AKC;
        nvvvh:
        return ['page' => $s6UWv, 'total' => $aBj0j, 'item_per_page' => $Awg2g, 'data' => $x53s1];
        goto RNU07;
        RNU07:
    }
    private function mleS6HnJDel(array $vuSlA, array $K33R2, Builder $vFqZF) : Builder
    {
        goto vLH6Y;
        wxlG2:
        TX6zl:
        goto WrOfi;
        vLH6Y:
        foreach ($this->qCQMj as $kbNkf => $BPI0m) {
            goto jk0Uc;
            Rz5gj:
            PgzMd:
            goto j5EaB;
            JUKik:
            $IY1BQ = new $BPI0m();
            goto Rf6g7;
            Rf6g7:
            $IY1BQ->mJOyrKRF42B($vFqZF, $vuSlA[$kbNkf]);
            goto Dgd1Z;
            nsG4O:
            $IY1BQ = new $BPI0m();
            goto pXYAf;
            pXYAf:
            $IY1BQ->mJOyrKRF42B($vFqZF, $K33R2[$kbNkf], false);
            goto exLQ7;
            H1Doj:
            if (!isset($K33R2[$kbNkf])) {
                goto jeXpG;
            }
            goto nsG4O;
            YDONf:
            goto xoF4G;
            goto kBQXx;
            Dgd1Z:
            xoF4G:
            goto Rz5gj;
            exLQ7:
            jeXpG:
            goto YDONf;
            kBQXx:
            kasFO:
            goto JUKik;
            jk0Uc:
            if (isset($vuSlA[$kbNkf]) && !isset($K33R2[$kbNkf])) {
                goto kasFO;
            }
            goto H1Doj;
            j5EaB:
        }
        goto wxlG2;
        WrOfi:
        return $vFqZF;
        goto JBJuF;
        JBJuF:
    }
    public function saveItems(array $DbgJ5) : void
    {
        foreach ($DbgJ5 as $PW_5C) {
            goto Q7ULF;
            Q7ULF:
            $jGIip = Cloud::find($PW_5C);
            goto bu7NN;
            TXW7w:
            iuAyw:
            goto pJAQN;
            bu7NN:
            if ($jGIip) {
                goto oNtQn;
            }
            goto xeS40;
            xeS40:
            $onOto = Media::find($PW_5C);
            goto u1k2L;
            JlyDU:
            oNtQn:
            goto TXW7w;
            u1k2L:
            Cloud::mT2RgYSfz9e($onOto, StatusEnum::JH6uu);
            goto JlyDU;
            pJAQN:
        }
        fxXL6:
    }
    public function delete(string $G2Ngo) : void
    {
        $jGIip = Cloud::findOrFail($G2Ngo);
        $jGIip->delete();
    }
}
