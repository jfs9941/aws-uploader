<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
class CAfXNlqbym5FQ implements J84rE2iEDQv5F
{
    public function mTnfrRwy2aj(Builder $FvF30, $gEnrX, $Ulo6X) : Builder
    {
        goto B4APh;
        OaHv_:
        if (empty($cDPaF)) {
            goto X2vbF;
        }
        goto LpHkb;
        B4APh:
        $cDPaF = is_array($gEnrX) ? $gEnrX : [$gEnrX];
        goto OaHv_;
        LpHkb:
        return $FvF30->whereIn('type', $cDPaF);
        goto x3uO2;
        x3uO2:
        X2vbF:
        goto fpQqr;
        fpQqr:
        return $FvF30;
        goto sGqRq;
        sGqRq:
    }
}
