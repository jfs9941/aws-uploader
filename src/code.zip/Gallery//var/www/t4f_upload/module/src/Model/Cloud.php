<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mJV910UPxiT(Media $MoQri, $DsbB2 = StatusEnum::lNdhS) : void
    {
        goto wVbtk;
        cT2DJ:
        $UA66g = new Cloud();
        goto JChUa;
        JlOzO:
        return;
        goto RVAlN;
        JChUa:
        $UA66g->fill(['id' => $MoQri->getAttribute('id'), 'user_id' => $MoQri->getAttribute('user_id') ?? auth()->user()->id, 'status' => $DsbB2, 'type' => $MoQri->getType(), 'is_post' => $MoQri->getAttribute('post_id') ? 1 : 0, 'is_message' => $MoQri->getAttribute('message_id') ? 1 : 0, 'is_shop' => $MoQri->getAttribute('shop_item_id') ? 1 : 0]);
        goto FYaZv;
        wVbtk:
        if (!Cloud::find($MoQri->id)) {
            goto EMEjV;
        }
        goto JlOzO;
        RVAlN:
        EMEjV:
        goto cT2DJ;
        FYaZv:
        $UA66g->save();
        goto m9isO;
        m9isO:
    }
}
