<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mT2RgYSfz9e(Media $esNyq, $jwWFs = StatusEnum::CaVNd) : void
    {
        goto zoGKK;
        e_i23:
        return;
        goto CA26r;
        SabG2:
        $jGIip = new Cloud();
        goto LivHi;
        R7OxL:
        $jGIip->save();
        goto sZht_;
        CA26r:
        OF7L6:
        goto SabG2;
        LivHi:
        $jGIip->fill(['id' => $esNyq->getAttribute('id'), 'user_id' => $esNyq->getAttribute('user_id') ?? auth()->user()->id, 'status' => $jwWFs, 'type' => $esNyq->getType(), 'is_post' => $esNyq->getAttribute('post_id') ? 1 : 0, 'is_message' => $esNyq->getAttribute('message_id') ? 1 : 0, 'is_shop' => $esNyq->getAttribute('shop_item_id') ? 1 : 0]);
        goto R7OxL;
        zoGKK:
        if (!Cloud::find($esNyq->id)) {
            goto OF7L6;
        }
        goto e_i23;
        sZht_:
    }
}
