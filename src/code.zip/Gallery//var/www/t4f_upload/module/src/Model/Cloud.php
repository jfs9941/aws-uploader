<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use src\Gallery\Model\Enum\StatusEnum;
use src\Gallery\Model\Media;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function muSY8CPT1fh(Media $pm1yU, $I89eq = StatusEnum::XwG85) : void
    {
        goto YUNC6;
        pA0z1:
        QovkS:
        goto vdz8S;
        TjCCT:
        $a4_pD->save();
        goto xIZn7;
        YUNC6:
        if (!\src\Gallery\Model\Cloud::find($pm1yU->id)) {
            goto QovkS;
        }
        goto opTnX;
        vdz8S:
        $a4_pD = new \src\Gallery\Model\Cloud();
        goto ITQHi;
        ITQHi:
        $a4_pD->fill(['id' => $pm1yU->getAttribute('id'), 'user_id' => $pm1yU->getAttribute('user_id') ?? auth()->user()->id, 'status' => $I89eq, 'type' => $pm1yU->getType(), 'is_post' => $pm1yU->getAttribute('post_id') ? 1 : 0, 'is_message' => $pm1yU->getAttribute('message_id') ? 1 : 0, 'is_shop' => $pm1yU->getAttribute('shop_item_id') ? 1 : 0]);
        goto TjCCT;
        opTnX:
        return;
        goto pA0z1;
        xIZn7:
    }
}
