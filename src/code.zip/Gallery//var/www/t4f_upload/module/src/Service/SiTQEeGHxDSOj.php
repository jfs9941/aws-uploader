<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Service\Search\LIRhWZzRlqWph;
use Jfs\Gallery\Service\Search\J84rE2iEDQv5F;
use Jfs\Gallery\Service\Search\CAfXNlqbym5FQ;
use Jfs\Gallery\Model\Cloud;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
final class SiTQEeGHxDSOj implements GalleryCloudInterface
{
    private $jq69N = ['types' => CAfXNlqbym5FQ::class, 'category' => LIRhWZzRlqWph::class];
    public function search(int $HGoYr, $MOFyR) : array
    {
        goto HJpTs;
        WXqHh:
        $x2YXa = $x2YXa->where('status', '=', StatusEnum::lNdhS);
        goto PX6eN;
        WZUrU:
        return ['page' => $I1Was, 'total' => $NW0gg, 'item_per_page' => $sz1BP, 'data' => $cUHx5];
        goto E1Ene;
        DXs5g:
        EdTAk:
        goto X_WPf;
        VQC5h:
        $x2YXa = $this->m3nyhaEkx7J($ksBJB, $ilLMV, $x2YXa);
        goto psh3l;
        jxC0y:
        id4bV:
        goto WXqHh;
        seCO_:
        $x2YXa = $x2YXa->where('status', '=', StatusEnum::lNdhS);
        goto gOaGP;
        gOaGP:
        $ksBJB['types'] = array_filter($ksBJB['types'], function ($o4QWB) {
            return $o4QWB !== 'approved';
        });
        goto DXs5g;
        PX6eN:
        bn1vm:
        goto VQC5h;
        psh3l:
        $NW0gg = DB::query()->fromSub($x2YXa, 't')->selectRaw('count(*) as total')->first()->total;
        goto HmgFU;
        HJpTs:
        list($ksBJB, $ilLMV, $I1Was, $sz1BP, $Y6nUw) = $MOFyR;
        goto DdyI_;
        DdyI_:
        $x2YXa = Cloud::query()->where('user_id', $HGoYr);
        goto ehxeE;
        ehxeE:
        if (!$Y6nUw) {
            goto id4bV;
        }
        goto JDwTu;
        HmgFU:
        $cUHx5 = $x2YXa->with('media')->orderBy('created_at', 'desc')->limit($sz1BP)->offset(($I1Was - 1) * $sz1BP)->get()->filter(function (Cloud $UA66g) {
            return $UA66g->getMedia() != null;
        })->map(function (Cloud $UA66g) {
            goto WYkJ1;
            uJZeY:
            $hKeR1 = $MoQri->getView();
            goto BgPP3;
            BgPP3:
            return array_merge($hKeR1, ['type' => $UA66g->getAttribute('type'), 'status' => $UA66g->getAttribute('status')]);
            goto Xm901;
            WYkJ1:
            $MoQri = $UA66g->getMedia();
            goto uJZeY;
            Xm901:
        })->values();
        goto WZUrU;
        X_WPf:
        goto bn1vm;
        goto jxC0y;
        JDwTu:
        if (!in_array('approved', $ksBJB['types'] ?? [])) {
            goto EdTAk;
        }
        goto seCO_;
        E1Ene:
    }
    private function m3nyhaEkx7J(array $ksBJB, array $ScNX0, Builder $FvF30) : Builder
    {
        goto tEHBn;
        tEHBn:
        foreach ($this->jq69N as $nEQHY => $vFuUn) {
            goto C0uNi;
            qRF7o:
            $JQPVn = new $vFuUn();
            goto hUeDA;
            aEubN:
            uSPEC:
            goto k1wXS;
            Y3zdB:
            $JQPVn = new $vFuUn();
            goto BFDU7;
            LHHb0:
            if (!isset($ScNX0[$nEQHY])) {
                goto uSPEC;
            }
            goto qRF7o;
            iKRCA:
            KGwFW:
            goto XiiVa;
            k1wXS:
            goto Grq4r;
            goto s8JsO;
            BFDU7:
            $JQPVn->mTnfrRwy2aj($FvF30, $ksBJB[$nEQHY]);
            goto DV85q;
            C0uNi:
            if (isset($ksBJB[$nEQHY]) && !isset($ScNX0[$nEQHY])) {
                goto yukyO;
            }
            goto LHHb0;
            s8JsO:
            yukyO:
            goto Y3zdB;
            hUeDA:
            $JQPVn->mTnfrRwy2aj($FvF30, $ScNX0[$nEQHY], false);
            goto aEubN;
            DV85q:
            Grq4r:
            goto iKRCA;
            XiiVa:
        }
        goto KThCc;
        KThCc:
        fdGbd:
        goto o2u3q;
        o2u3q:
        return $FvF30;
        goto QcrVQ;
        QcrVQ:
    }
    public function saveItems(array $tobhI) : void
    {
        foreach ($tobhI as $m42Ed) {
            goto zSkRN;
            yBRoz:
            V7kM0:
            goto RSi26;
            jt3Au:
            $FfPRr = Media::find($m42Ed);
            goto px6eG;
            zSkRN:
            $UA66g = Cloud::find($m42Ed);
            goto g7nRZ;
            RSi26:
            lwhIB:
            goto D4N4S;
            px6eG:
            Cloud::mJV910UPxiT($FfPRr, StatusEnum::yHlKi);
            goto yBRoz;
            g7nRZ:
            if ($UA66g) {
                goto V7kM0;
            }
            goto jt3Au;
            D4N4S:
        }
        zdiMK:
    }
    public function delete(string $C3gWL) : void
    {
        $UA66g = Cloud::findOrFail($C3gWL);
        $UA66g->delete();
    }
}
