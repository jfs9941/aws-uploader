<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Jfs\Exposed\GalleryCloudInterface;
use Jfs\Gallery\Service\Search\QvlIPTBb9kMNv;
use Jfs\Gallery\Service\Search\W7UE9VEvPLsnq;
use Jfs\Gallery\Service\Search\Oumt6yyc621bT;
use src\Gallery\Model\Cloud;
use src\Gallery\Model\Enum\StatusEnum;
use src\Gallery\Model\Media;
final class GITMWtpihwT3w implements GalleryCloudInterface
{
    private $lBjrv = ['types' => Oumt6yyc621bT::class, 'category' => QvlIPTBb9kMNv::class];
    public function search(int $dTwzD, $oRscx) : array
    {
        goto eTNGh;
        sZORJ:
        $SuYdh = DB::query()->fromSub($jZ1Bg, 't')->selectRaw('count(*) as total')->first()->total;
        goto Wxv0Z;
        aQGzB:
        if (!in_array('approved', $mnbRO['types'] ?? [])) {
            goto vRt0y;
        }
        goto T8yZt;
        GKULO:
        L0mlL:
        goto eRRFW;
        eTNGh:
        list($mnbRO, $krvRX, $pKg_y, $VYX6t, $OyWwZ) = $oRscx;
        goto h2si7;
        DfGqG:
        vRt0y:
        goto A9t_M;
        T8yZt:
        $jZ1Bg = $jZ1Bg->where('status', '=', StatusEnum::XwG85);
        goto JEQ63;
        Wxv0Z:
        $d8Dwe = $jZ1Bg->with('media')->orderBy('created_at', 'desc')->limit($VYX6t)->offset(($pKg_y - 1) * $VYX6t)->get()->filter(function (Cloud $a4_pD) {
            return $a4_pD->getMedia() != null;
        })->map(function (Cloud $a4_pD) {
            goto Uawm1;
            bmftV:
            $LEGKz = $pm1yU->getView();
            goto V0KdF;
            V0KdF:
            return array_merge($LEGKz, ['type' => $a4_pD->getAttribute('type'), 'status' => $a4_pD->getAttribute('status')]);
            goto Ej1tn;
            Uawm1:
            $pm1yU = $a4_pD->getMedia();
            goto bmftV;
            Ej1tn:
        })->values();
        goto A0x77;
        Eh8W_:
        if (!$OyWwZ) {
            goto L0mlL;
        }
        goto aQGzB;
        JEQ63:
        $mnbRO['types'] = array_filter($mnbRO['types'], function ($aYH5z) {
            return $aYH5z !== 'approved';
        });
        goto DfGqG;
        vOZtT:
        $jZ1Bg = $this->m4OgDRmfG2w($mnbRO, $krvRX, $jZ1Bg);
        goto sZORJ;
        A9t_M:
        goto rBT9c;
        goto GKULO;
        h2si7:
        $jZ1Bg = Cloud::query()->where('user_id', $dTwzD);
        goto Eh8W_;
        I3ra3:
        rBT9c:
        goto vOZtT;
        A0x77:
        return ['page' => $pKg_y, 'total' => $SuYdh, 'item_per_page' => $VYX6t, 'data' => $d8Dwe];
        goto XIKB8;
        eRRFW:
        $jZ1Bg = $jZ1Bg->where('status', '=', StatusEnum::XwG85);
        goto I3ra3;
        XIKB8:
    }
    private function m4OgDRmfG2w(array $mnbRO, array $qnXsU, Builder $yJoye) : Builder
    {
        goto WwQFZ;
        RqzkE:
        return $yJoye;
        goto CpBHL;
        WwQFZ:
        foreach ($this->lBjrv as $evISZ => $J0icT) {
            goto IEODk;
            vr3Qu:
            EAMxY:
            goto fUkVk;
            oe_uD:
            $VeiKR = new $J0icT();
            goto Jp3lv;
            oWXuh:
            Xm1M6:
            goto XpHXE;
            pZnJz:
            if (!isset($qnXsU[$evISZ])) {
                goto Xm1M6;
            }
            goto SnOo6;
            IEODk:
            if (isset($mnbRO[$evISZ]) && !isset($qnXsU[$evISZ])) {
                goto eFhLT;
            }
            goto pZnJz;
            XpHXE:
            goto EAMxY;
            goto N2oPp;
            SnOo6:
            $VeiKR = new $J0icT();
            goto YDZn0;
            fUkVk:
            a09NU:
            goto Jp0iy;
            N2oPp:
            eFhLT:
            goto oe_uD;
            Jp3lv:
            $VeiKR->mCmknAxLLai($yJoye, $mnbRO[$evISZ]);
            goto vr3Qu;
            YDZn0:
            $VeiKR->mCmknAxLLai($yJoye, $qnXsU[$evISZ], false);
            goto oWXuh;
            Jp0iy:
        }
        goto Q5EC9;
        Q5EC9:
        esxiv:
        goto RqzkE;
        CpBHL:
    }
    public function saveItems(array $atbGi) : void
    {
        foreach ($atbGi as $uY0L7) {
            goto N9_IW;
            ylPC3:
            if ($a4_pD) {
                goto RFuUq;
            }
            goto iDnTq;
            N9_IW:
            $a4_pD = Cloud::find($uY0L7);
            goto ylPC3;
            xfZe5:
            RFuUq:
            goto NEWBR;
            g_WoQ:
            Cloud::muSY8CPT1fh($ippyD, StatusEnum::Mo9i1);
            goto xfZe5;
            NEWBR:
            fxAIn:
            goto SLPT3;
            iDnTq:
            $ippyD = Media::find($uY0L7);
            goto g_WoQ;
            SLPT3:
        }
        xZRt2:
    }
    public function delete(string $W0vWP) : void
    {
        $a4_pD = Cloud::findOrFail($W0vWP);
        $a4_pD->delete();
    }
}
