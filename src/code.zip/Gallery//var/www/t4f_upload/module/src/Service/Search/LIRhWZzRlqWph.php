<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Service\Search;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;
class LIRhWZzRlqWph implements J84rE2iEDQv5F
{
    protected const LassZ = ['post' => 'is_post', 'message' => 'is_message', 'shop' => 'is_shop'];
    public function mTnfrRwy2aj(Builder $FvF30, $gEnrX, $Ulo6X = true) : Builder
    {
        goto YE1FA;
        twAxJ:
        N8h2L:
        goto DpEjE;
        DpEjE:
        return $FvF30;
        goto uhTUc;
        YE1FA:
        $dbDkU = Str::lower($gEnrX);
        goto pRCYr;
        of6Ya:
        return $FvF30->where($VrrFv, '=', $Ulo6X);
        goto twAxJ;
        dRhFr:
        $VrrFv = self::LassZ[$dbDkU];
        goto of6Ya;
        pRCYr:
        if (!isset(self::LassZ[$dbDkU])) {
            goto N8h2L;
        }
        goto dRhFr;
        uhTUc:
    }
}
