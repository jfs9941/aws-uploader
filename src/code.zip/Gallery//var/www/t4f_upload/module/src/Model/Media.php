<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:36:02              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Uploader\Core\REvUXqyajwths;
use Jfs\Uploader\Core\Yi7VDaCr23YjR;
use Jfs\Uploader\Core\RTkNv5GS7FY9w;
use Jfs\Uploader\Core\Traits\PwaCHnhQOie1m;
use Jfs\Uploader\Core\Zr0izVmbs7QaE;
use Jfs\Uploader\Enum\YZ2lA0H3k4o6O;
use Jfs\Gallery\Model\Enum\MediaTypeEnum;
class Media extends REvUXqyajwths
{
    use PwaCHnhQOie1m;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mGiwIjqbwDI() : string
    {
        goto n1h74;
        WLAmp:
        goto pndbx;
        goto yRY37;
        EaXh4:
        hexpd:
        goto zMo9K;
        oTy0B:
        if ($this->getAttribute('message_id')) {
            goto Zv71Q;
        }
        goto Jmy15;
        bgE7a:
        goto pndbx;
        goto jhA8S;
        Jmy15:
        if ($this->getAttribute('shop_item_id')) {
            goto sMilL;
        }
        goto IBUcG;
        zMo9K:
        return 'post';
        goto WLAmp;
        te5Za:
        return 'shop_item';
        goto jbn3N;
        KJnkx:
        return 'message';
        goto bgE7a;
        jhA8S:
        sMilL:
        goto te5Za;
        dW56L:
        return 'uncategorized';
        goto VBamF;
        yRY37:
        Zv71Q:
        goto KJnkx;
        jbn3N:
        pndbx:
        goto dW56L;
        IBUcG:
        goto pndbx;
        goto EaXh4;
        n1h74:
        if ($this->getAttribute('post_id')) {
            goto hexpd;
        }
        goto oTy0B;
        VBamF:
    }
    public function getView() : array
    {
        goto NQFK7;
        HQ2pz:
        hapPa:
        goto xEFS0;
        NQFK7:
        switch ($this->getType()) {
            case 'image':
                return Yi7VDaCr23YjR::m9Rhv5w4sFW($this)->getView();
            case 'video':
                return Zr0izVmbs7QaE::miY3fHXiCQq($this)->getView();
            default:
                return RTkNv5GS7FY9w::m4vqZwtjNfc($this)->getView();
        }
        goto LkN1e;
        LkN1e:
        ia1PP:
        goto HQ2pz;
        xEFS0:
    }
    public function getType() : string
    {
        goto PYHKy;
        Qi2zH:
        Mj2bH:
        goto Ze58n;
        PYHKy:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::L3JoW;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::VO55f;
            default:
                return MediaTypeEnum::pyJC1;
        }
        goto yIvzD;
        yIvzD:
        x229H:
        goto Qi2zH;
        Ze58n:
    }
    public static function createFromScratch(string $tgQj8, string $gETyy) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $tgQj8, 'type' => $gETyy, 'status' => YZ2lA0H3k4o6O::LOCAL]);
    }
}
