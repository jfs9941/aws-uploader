<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:06:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Uploader\Core\TWXq4PCBxnKLl;
use Jfs\Uploader\Core\Il0T1UmENcpfh;
use Jfs\Uploader\Core\FKnhGBzmViN0k;
use Jfs\Uploader\Core\Traits\YzdWeu2LiemYK;
use Jfs\Uploader\Core\S1qX7zy4Guf94;
use Jfs\Uploader\Enum\ARsVGbfyHQlSz;
use src\Gallery\Model\Enum\MediaTypeEnum;
class Media extends TWXq4PCBxnKLl
{
    use YzdWeu2LiemYK;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mlSaDuR57Fh() : string
    {
        goto dsrmP;
        fccCJ:
        goto KvY_I;
        goto Lrb1X;
        ejlzF:
        return 'message';
        goto plhtv;
        hazK0:
        if ($this->getAttribute('shop_item_id')) {
            goto EW0qI;
        }
        goto wuDO7;
        UWrUi:
        return 'post';
        goto fccCJ;
        dsrmP:
        if ($this->getAttribute('post_id')) {
            goto qduXq;
        }
        goto E5LFA;
        kcp6n:
        EW0qI:
        goto Z65NO;
        WFbiB:
        KvY_I:
        goto swFYt;
        E5LFA:
        if ($this->getAttribute('message_id')) {
            goto JRa82;
        }
        goto hazK0;
        wuDO7:
        goto KvY_I;
        goto bhT3R;
        Z65NO:
        return 'shop_item';
        goto WFbiB;
        swFYt:
        return 'uncategorized';
        goto mMCgA;
        bhT3R:
        qduXq:
        goto UWrUi;
        Lrb1X:
        JRa82:
        goto ejlzF;
        plhtv:
        goto KvY_I;
        goto kcp6n;
        mMCgA:
    }
    public function getView() : array
    {
        goto eiiRm;
        bRoKI:
        RI6PK:
        goto bZZrH;
        eiiRm:
        switch ($this->getType()) {
            case 'image':
                return Il0T1UmENcpfh::mXcR490FEJb($this)->getView();
            case 'video':
                return S1qX7zy4Guf94::mVrTuyKgSgq($this)->getView();
            default:
                return FKnhGBzmViN0k::mj4mPciZrS9($this)->getView();
        }
        goto bRoKI;
        bZZrH:
        nJMMO:
        goto QJGYI;
        QJGYI:
    }
    public function getType() : string
    {
        goto KKio6;
        KKio6:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::jkXMn;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::ypKsF;
            default:
                return MediaTypeEnum::a4ghg;
        }
        goto ZdF9L;
        ZdF9L:
        vo3kc:
        goto fYvRz;
        fYvRz:
        DISHH:
        goto kCCx2;
        kCCx2:
    }
    public static function createFromScratch(string $mRgNN, string $PavIR) : \src\Gallery\Model\Media
    {
        return \src\Gallery\Model\Media::fill(['id' => $mRgNN, 'type' => $PavIR, 'status' => ARsVGbfyHQlSz::LOCAL]);
    }
}
