<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:35:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Uploader\Core\VWfw9VfxzTDgS;
use Jfs\Uploader\Core\ZrqFFxIRVAAEU;
use Jfs\Uploader\Core\J45Rghcw16D6k;
use Jfs\Uploader\Core\Traits\EBDQZNARW5Gbb;
use Jfs\Uploader\Core\UZrSkD9d5TXs1;
use Jfs\Uploader\Enum\BHGv9oAB1EERw;
use Jfs\Gallery\Model\Enum\MediaTypeEnum;
class Media extends VWfw9VfxzTDgS
{
    use EBDQZNARW5Gbb;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mg7oTpv03A5() : string
    {
        goto A1REx;
        uip2J:
        hOfhg:
        goto gkkMu;
        v7XTd:
        xa3kl:
        goto yVEsm;
        yVEsm:
        return 'shop_item';
        goto WtYxb;
        A1REx:
        if ($this->getAttribute('post_id')) {
            goto hOfhg;
        }
        goto fw3Ky;
        nS04d:
        ZZy7j:
        goto FizbY;
        fw3Ky:
        if ($this->getAttribute('message_id')) {
            goto ZZy7j;
        }
        goto P1FcH;
        KVU0a:
        goto SUsW9;
        goto nS04d;
        FizbY:
        return 'message';
        goto ighZs;
        gkkMu:
        return 'post';
        goto KVU0a;
        WtYxb:
        SUsW9:
        goto aG_P4;
        P1FcH:
        if ($this->getAttribute('shop_item_id')) {
            goto xa3kl;
        }
        goto ywf01;
        ighZs:
        goto SUsW9;
        goto v7XTd;
        aG_P4:
        return 'uncategorized';
        goto r2qy9;
        ywf01:
        goto SUsW9;
        goto uip2J;
        r2qy9:
    }
    public function getView() : array
    {
        goto TuASx;
        TuASx:
        switch ($this->getType()) {
            case 'image':
                return ZrqFFxIRVAAEU::mmskxNngb8G($this)->getView();
            case 'video':
                return UZrSkD9d5TXs1::mcnCcUM8md7($this)->getView();
            default:
                return J45Rghcw16D6k::mxay1Yy042P($this)->getView();
        }
        goto IOg0o;
        lCYlt:
        JuOef:
        goto klAS1;
        IOg0o:
        b_oUf:
        goto lCYlt;
        klAS1:
    }
    public function getType() : string
    {
        goto STpbz;
        KXkin:
        VTcRy:
        goto zJFGe;
        zJFGe:
        M_Aum:
        goto vrZvh;
        STpbz:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::DNvpn;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::umyVI;
            default:
                return MediaTypeEnum::HV7o7;
        }
        goto KXkin;
        vrZvh:
    }
    public static function createFromScratch(string $NPlHa, string $VPgya) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $NPlHa, 'type' => $VPgya, 'status' => BHGv9oAB1EERw::LOCAL]);
    }
}
