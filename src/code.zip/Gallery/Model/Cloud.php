<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mCQRrIZ2P6h(Media $PK0_J, $eLGJ0 = StatusEnum::wLFmJ) : void
    {
        goto VmI1r;
        VmI1r:
        if (!Cloud::find($PK0_J->id)) {
            goto AC5Ym;
        }
        goto TYw7A;
        HmCSf:
        $CJHPg = new Cloud();
        goto OPmu6;
        TYw7A:
        return;
        goto NTEu9;
        OPmu6:
        $CJHPg->fill(['id' => $PK0_J->getAttribute('id'), 'user_id' => $PK0_J->getAttribute('user_id') ?? auth()->user()->id, 'status' => $eLGJ0, 'type' => $PK0_J->getType(), 'is_post' => $PK0_J->getAttribute('post_id') ? 1 : 0, 'is_message' => $PK0_J->getAttribute('message_id') ? 1 : 0, 'is_shop' => $PK0_J->getAttribute('shop_item_id') ? 1 : 0]);
        goto ykyZ6;
        NTEu9:
        AC5Ym:
        goto HmCSf;
        ykyZ6:
        $CJHPg->save();
        goto qovof;
        qovof:
    }
}
