<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m7b2b5lZv6Q(Media $XCcud, $kwGu2 = StatusEnum::cuyHb) : void
    {
        goto XX3_E;
        ovwRh:
        $G5mvt->save();
        goto SOjcv;
        XX3_E:
        if (!Cloud::find($XCcud->id)) {
            goto aDoy6;
        }
        goto qBIf8;
        ZmJ4H:
        aDoy6:
        goto LkYRy;
        LkYRy:
        $G5mvt = new Cloud();
        goto PdmfJ;
        qBIf8:
        return;
        goto ZmJ4H;
        PdmfJ:
        $G5mvt->fill(['id' => $XCcud->getAttribute('id'), 'user_id' => $XCcud->getAttribute('user_id') ?? auth()->user()->id, 'status' => $kwGu2, 'type' => $XCcud->getType(), 'is_post' => $XCcud->getAttribute('post_id') ? 1 : 0, 'is_message' => $XCcud->getAttribute('message_id') ? 1 : 0, 'is_shop' => $XCcud->getAttribute('shop_item_id') ? 1 : 0]);
        goto ovwRh;
        SOjcv:
    }
}
