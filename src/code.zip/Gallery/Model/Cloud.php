<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mpnWubZmaKP(Media $D_Z4Z, $iemTA = StatusEnum::u6RAd) : void
    {
        goto ysZ5o;
        ysZ5o:
        if (!Cloud::find($D_Z4Z->id)) {
            goto twSyS;
        }
        goto QNX1k;
        BJV30:
        twSyS:
        goto wxD82;
        QNX1k:
        return;
        goto BJV30;
        chFP4:
        $kDzew->fill(['id' => $D_Z4Z->getAttribute('id'), 'user_id' => $D_Z4Z->getAttribute('user_id') ?? auth()->user()->id, 'status' => $iemTA, 'type' => $D_Z4Z->getType(), 'is_post' => $D_Z4Z->getAttribute('post_id') ? 1 : 0, 'is_message' => $D_Z4Z->getAttribute('message_id') ? 1 : 0, 'is_shop' => $D_Z4Z->getAttribute('shop_item_id') ? 1 : 0]);
        goto b_5Q0;
        b_5Q0:
        $kDzew->save();
        goto ghF2N;
        wxD82:
        $kDzew = new Cloud();
        goto chFP4;
        ghF2N:
    }
}
