<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m9Vez0sT79n(Media $tzY18, $C1S9A = StatusEnum::GPHhd) : void
    {
        goto uUVxD;
        LvU5S:
        $kjrz1->fill(['id' => $tzY18->getAttribute('id'), 'user_id' => $tzY18->getAttribute('user_id') ?? auth()->user()->id, 'status' => $C1S9A, 'type' => $tzY18->getType(), 'is_post' => $tzY18->getAttribute('post_id') ? 1 : 0, 'is_message' => $tzY18->getAttribute('message_id') ? 1 : 0, 'is_shop' => $tzY18->getAttribute('shop_item_id') ? 1 : 0]);
        goto myX6b;
        dUK_e:
        Nr2Zz:
        goto Kk59u;
        Kk59u:
        $kjrz1 = new Cloud();
        goto LvU5S;
        uUVxD:
        if (!Cloud::find($tzY18->id)) {
            goto Nr2Zz;
        }
        goto RETyF;
        RETyF:
        return;
        goto dUK_e;
        myX6b:
        $kjrz1->save();
        goto I041x;
        I041x:
    }
}
