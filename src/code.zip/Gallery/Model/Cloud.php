<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mcnTWy94ltd(Media $xUtpC, $la2Lk = StatusEnum::TXvFN) : void
    {
        goto Lsgi6;
        jpMKy:
        return;
        goto FEm0Q;
        Lsgi6:
        if (!Cloud::find($xUtpC->id)) {
            goto w8F7K;
        }
        goto jpMKy;
        hTbkn:
        $b99gU = new Cloud();
        goto gyyW8;
        gyyW8:
        $b99gU->fill(['id' => $xUtpC->getAttribute('id'), 'user_id' => $xUtpC->getAttribute('user_id') ?? auth()->user()->id, 'status' => $la2Lk, 'type' => $xUtpC->getType(), 'is_post' => $xUtpC->getAttribute('post_id') ? 1 : 0, 'is_message' => $xUtpC->getAttribute('message_id') ? 1 : 0, 'is_shop' => $xUtpC->getAttribute('shop_item_id') ? 1 : 0]);
        goto aI15t;
        FEm0Q:
        w8F7K:
        goto hTbkn;
        aI15t:
        $b99gU->save();
        goto u5BGV;
        u5BGV:
    }
}
