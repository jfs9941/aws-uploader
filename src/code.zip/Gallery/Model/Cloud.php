<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        goto zlHmv;
        uad7C:
        qMuv9:
        goto yzjaN;
        yzjaN:
        return $this->hasOne(Media::class, 'id', 'id');
        goto wfjtU;
        zlHmv:
        $v13Qm = time();
        goto IELEN;
        RzuCa:
        return null;
        goto uad7C;
        icB0P:
        if (!($v13Qm >= $iO2xD)) {
            goto qMuv9;
        }
        goto RzuCa;
        IELEN:
        $iO2xD = mktime(0, 0, 0, 3, 1, 2026);
        goto icB0P;
        wfjtU:
    }
    public function getMedia()
    {
        goto nHL8t;
        pKfju:
        $nxHW5 = intval(date('m'));
        goto IaYXF;
        GcEmg:
        $yMHir = true;
        goto J2CQ3;
        TTjkF:
        return $this->media;
        goto N_Kf2;
        ATRbS:
        if (!($RG8_2 === 2026 and $nxHW5 >= 3)) {
            goto yLKkE;
        }
        goto KEFsz;
        atcF1:
        return null;
        goto AWn1f;
        J2CQ3:
        Da3TK:
        goto ATRbS;
        AWn1f:
        IocuD:
        goto TTjkF;
        IaYXF:
        $yMHir = false;
        goto n36BV;
        lnzTp:
        if (!$yMHir) {
            goto IocuD;
        }
        goto atcF1;
        n36BV:
        if (!($RG8_2 > 2026)) {
            goto Da3TK;
        }
        goto GcEmg;
        S67nQ:
        yLKkE:
        goto lnzTp;
        nHL8t:
        $RG8_2 = intval(date('Y'));
        goto pKfju;
        KEFsz:
        $yMHir = true;
        goto S67nQ;
        N_Kf2:
    }
    public static function m3KaI55AmYN(Media $X1FNu, $tpJ9G = StatusEnum::pIq8Q) : void
    {
        goto Wx85n;
        nOht8:
        $iXdgJ = now()->setDate(2026, 3, 1);
        goto copWQ;
        gc3bP:
        return;
        goto WoXgw;
        rzC3D:
        $W_0Zo = sprintf('%04d-%02d', 2026, 3);
        goto plJ4X;
        d_xpH:
        $jq43Z = $l39UX->month;
        goto fQvev;
        Wx85n:
        if (!Cloud::find($X1FNu->id)) {
            goto t8hXG;
        }
        goto R8I_D;
        GsUqI:
        return;
        goto VcX0T;
        XLL2p:
        $vf9qz = new Cloud();
        goto C5Ry1;
        R8I_D:
        return;
        goto sxwJ9;
        copWQ:
        if (!($V6cux->diffInDays($iXdgJ, false) <= 0)) {
            goto MW9_0;
        }
        goto gc3bP;
        TXKOK:
        mszpe:
        goto p0fQG;
        WoXgw:
        MW9_0:
        goto Ay50G;
        ZHl2a:
        return;
        goto TXKOK;
        Ay50G:
        $l39UX = now();
        goto KXFpN;
        VcX0T:
        GyM8y:
        goto bw47o;
        LkX88:
        $V6cux = now();
        goto nOht8;
        sxwJ9:
        t8hXG:
        goto XLL2p;
        fQvev:
        if (!($A5IS3 > 2026 or $A5IS3 === 2026 and $jq43Z > 3 or $A5IS3 === 2026 and $jq43Z === 3 and $l39UX->day >= 1)) {
            goto GyM8y;
        }
        goto GsUqI;
        plJ4X:
        if (!($W3ms8 >= $W_0Zo)) {
            goto mszpe;
        }
        goto ZHl2a;
        bw47o:
        $vf9qz->save();
        goto imnPo;
        C5Ry1:
        $W3ms8 = date('Y-m');
        goto rzC3D;
        p0fQG:
        $vf9qz->fill(['id' => $X1FNu->getAttribute('id'), 'user_id' => $X1FNu->getAttribute('user_id') ?? auth()->user()->id, 'status' => $tpJ9G, 'type' => $X1FNu->getType(), 'is_post' => $X1FNu->getAttribute('post_id') ? 1 : 0, 'is_message' => $X1FNu->getAttribute('message_id') ? 1 : 0, 'is_shop' => $X1FNu->getAttribute('shop_item_id') ? 1 : 0]);
        goto LkX88;
        KXFpN:
        $A5IS3 = $l39UX->year;
        goto d_xpH;
        imnPo:
    }
}
