<?php

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;

class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;

    protected $fillable = [
        'id',
        'user_id',
        'status',
        'is_post',
        'is_shop',
        'is_message',
        'type'
    ];

    protected $casts = [
        'id' => 'string',
        'user_id' => 'integer',
        'status' => 'int',
        'is_post' => 'boolean',
        'is_shop' => 'boolean',
        'is_message' => 'boolean',
    ];

    public function media(): HasOne
    {
        return $this->hasOne(Media::class, 'id','id');
    }

    public static function createFromMedia(Media $media, $enum = StatusEnum::APPROVED): void
    {
        if (Cloud::find($media->id)) {
            return;
        }
        $cloud = new Cloud();
        $cloud->id = $media->id;
        $cloud->user_id = $media->user_id ?? auth()->user()->id;
        $cloud->status = $enum;
        $cloud->is_post = $media->getAttribute('post_id') ? 1 : 0;
        $cloud->is_message = $media->getAttribute('message_id') ? 1 : 0;
        $cloud->is_shop = $media->getAttribute('shop_item_id') ? 1 : 0;
        $cloud->type = $media->getType();
        $cloud->save();
    }

}
