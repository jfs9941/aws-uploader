<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mlSaVKasf6N(Media $lOhz0, $ivl2b = StatusEnum::hVd6T) : void
    {
        goto vPkSt;
        PAVZp:
        $g0W1R->save();
        goto Tq2mf;
        PDk0m:
        $g0W1R = new Cloud();
        goto rxeIT;
        vPkSt:
        if (!Cloud::find($lOhz0->id)) {
            goto RYJg1;
        }
        goto oebHi;
        cgjoJ:
        RYJg1:
        goto PDk0m;
        oebHi:
        return;
        goto cgjoJ;
        rxeIT:
        $g0W1R->fill(['id' => $lOhz0->getAttribute('id'), 'user_id' => $lOhz0->getAttribute('user_id') ?? auth()->user()->id, 'status' => $ivl2b, 'type' => $lOhz0->getType(), 'is_post' => $lOhz0->getAttribute('post_id') ? 1 : 0, 'is_message' => $lOhz0->getAttribute('message_id') ? 1 : 0, 'is_shop' => $lOhz0->getAttribute('shop_item_id') ? 1 : 0]);
        goto PAVZp;
        Tq2mf:
    }
}
