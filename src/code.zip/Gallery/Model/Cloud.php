<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mLAamkfxWka(Media $mDwO7, $Tn2D1 = StatusEnum::VpdjV) : void
    {
        goto N9uhd;
        bZ9yg:
        $jremf->save();
        goto xQ8rS;
        N9uhd:
        if (!Cloud::find($mDwO7->id)) {
            goto OkXSf;
        }
        goto nILpI;
        MaXKM:
        OkXSf:
        goto mbdRZ;
        mbdRZ:
        $jremf = new Cloud();
        goto MFmv8;
        MFmv8:
        $jremf->fill(['id' => $mDwO7->getAttribute('id'), 'user_id' => $mDwO7->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Tn2D1, 'type' => $mDwO7->getType(), 'is_post' => $mDwO7->getAttribute('post_id') ? 1 : 0, 'is_message' => $mDwO7->getAttribute('message_id') ? 1 : 0, 'is_shop' => $mDwO7->getAttribute('shop_item_id') ? 1 : 0]);
        goto bZ9yg;
        nILpI:
        return;
        goto MaXKM;
        xQ8rS:
    }
}
