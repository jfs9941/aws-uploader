<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function maSUbUr9CGO(Media $jKCuO, $Hi8OH = StatusEnum::IHeh9) : void
    {
        goto w8EOK;
        YN8uZ:
        $HH1B6 = new Cloud();
        goto a42r2;
        w8EOK:
        if (!Cloud::find($jKCuO->id)) {
            goto LEaQO;
        }
        goto pZtA8;
        u1Hj9:
        LEaQO:
        goto YN8uZ;
        qwvI5:
        $HH1B6->save();
        goto ZYw4j;
        a42r2:
        $HH1B6->fill(['id' => $jKCuO->getAttribute('id'), 'user_id' => $jKCuO->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Hi8OH, 'type' => $jKCuO->getType(), 'is_post' => $jKCuO->getAttribute('post_id') ? 1 : 0, 'is_message' => $jKCuO->getAttribute('message_id') ? 1 : 0, 'is_shop' => $jKCuO->getAttribute('shop_item_id') ? 1 : 0]);
        goto qwvI5;
        pZtA8:
        return;
        goto u1Hj9;
        ZYw4j:
    }
}
