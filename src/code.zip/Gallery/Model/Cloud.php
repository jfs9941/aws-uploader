<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mA57fqzccfA(Media $wiCE2, $hz9nL = StatusEnum::JHunj) : void
    {
        goto rH_kt;
        L0wmH:
        $wnxPt = new Cloud();
        goto wzTe1;
        Q05d_:
        $wnxPt->save();
        goto AHqrA;
        CQELm:
        BRLQx:
        goto L0wmH;
        rH_kt:
        if (!Cloud::find($wiCE2->id)) {
            goto BRLQx;
        }
        goto vVeEi;
        vVeEi:
        return;
        goto CQELm;
        wzTe1:
        $wnxPt->fill(['id' => $wiCE2->getAttribute('id'), 'user_id' => $wiCE2->getAttribute('user_id') ?? auth()->user()->id, 'status' => $hz9nL, 'type' => $wiCE2->getType(), 'is_post' => $wiCE2->getAttribute('post_id') ? 1 : 0, 'is_message' => $wiCE2->getAttribute('message_id') ? 1 : 0, 'is_shop' => $wiCE2->getAttribute('shop_item_id') ? 1 : 0]);
        goto Q05d_;
        AHqrA:
    }
}
