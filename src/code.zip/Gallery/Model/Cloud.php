<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mhmihv57TRw(Media $g1333, $xNhT1 = StatusEnum::sYto1) : void
    {
        goto p3u1P;
        mAtuq:
        va3d1:
        goto inZn5;
        inZn5:
        $RDasi = new Cloud();
        goto HUUNU;
        grJin:
        $RDasi->save();
        goto s4sQJ;
        CWd4r:
        return;
        goto mAtuq;
        p3u1P:
        if (!Cloud::find($g1333->id)) {
            goto va3d1;
        }
        goto CWd4r;
        HUUNU:
        $RDasi->fill(['id' => $g1333->getAttribute('id'), 'user_id' => $g1333->getAttribute('user_id') ?? auth()->user()->id, 'status' => $xNhT1, 'type' => $g1333->getType(), 'is_post' => $g1333->getAttribute('post_id') ? 1 : 0, 'is_message' => $g1333->getAttribute('message_id') ? 1 : 0, 'is_shop' => $g1333->getAttribute('shop_item_id') ? 1 : 0]);
        goto grJin;
        s4sQJ:
    }
}
