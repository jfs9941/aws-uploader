<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m1tvVfvVjBB(Media $zr5kh, $DCXq1 = StatusEnum::PfxeM) : void
    {
        goto GJv21;
        OG15D:
        $DH7kR->save();
        goto wnglt;
        L6khd:
        $DH7kR = new Cloud();
        goto UWRbe;
        GJv21:
        if (!Cloud::find($zr5kh->id)) {
            goto k8_IP;
        }
        goto qlL3O;
        UWRbe:
        $DH7kR->fill(['id' => $zr5kh->getAttribute('id'), 'user_id' => $zr5kh->getAttribute('user_id') ?? auth()->user()->id, 'status' => $DCXq1, 'type' => $zr5kh->getType(), 'is_post' => $zr5kh->getAttribute('post_id') ? 1 : 0, 'is_message' => $zr5kh->getAttribute('message_id') ? 1 : 0, 'is_shop' => $zr5kh->getAttribute('shop_item_id') ? 1 : 0]);
        goto OG15D;
        HHAWZ:
        k8_IP:
        goto L6khd;
        qlL3O:
        return;
        goto HHAWZ;
        wnglt:
    }
}
