<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mjDBU0YLrFQ(Media $Y6vHu, $EnbWU = StatusEnum::icH3y) : void
    {
        goto bd03C;
        AdjAi:
        $KBT5q->save();
        goto a9PcQ;
        BJB9y:
        O8mlE:
        goto EMJPK;
        EMJPK:
        $KBT5q = new Cloud();
        goto DlZl3;
        DlZl3:
        $KBT5q->fill(['id' => $Y6vHu->getAttribute('id'), 'user_id' => $Y6vHu->getAttribute('user_id') ?? auth()->user()->id, 'status' => $EnbWU, 'type' => $Y6vHu->getType(), 'is_post' => $Y6vHu->getAttribute('post_id') ? 1 : 0, 'is_message' => $Y6vHu->getAttribute('message_id') ? 1 : 0, 'is_shop' => $Y6vHu->getAttribute('shop_item_id') ? 1 : 0]);
        goto AdjAi;
        bd03C:
        if (!Cloud::find($Y6vHu->id)) {
            goto O8mlE;
        }
        goto S13Ea;
        S13Ea:
        return;
        goto BJB9y;
        a9PcQ:
    }
}
