<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mv7HeS8w5DY(Media $jBims, $zaI0Q = StatusEnum::ZOY3U) : void
    {
        goto CwM_x;
        n80dz:
        $nu0xX->save();
        goto YpPre;
        MEY35:
        $nu0xX = new Cloud();
        goto Y6v6B;
        VgbJh:
        kPkdw:
        goto MEY35;
        Y6v6B:
        $nu0xX->fill(['id' => $jBims->getAttribute('id'), 'user_id' => $jBims->getAttribute('user_id') ?? auth()->user()->id, 'status' => $zaI0Q, 'type' => $jBims->getType(), 'is_post' => $jBims->getAttribute('post_id') ? 1 : 0, 'is_message' => $jBims->getAttribute('message_id') ? 1 : 0, 'is_shop' => $jBims->getAttribute('shop_item_id') ? 1 : 0]);
        goto n80dz;
        CwM_x:
        if (!Cloud::find($jBims->id)) {
            goto kPkdw;
        }
        goto IhICv;
        IhICv:
        return;
        goto VgbJh;
        YpPre:
    }
}
