<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mSGcSxTcZ9I(Media $F251H, $YEtX5 = StatusEnum::uXeis) : void
    {
        goto cZqG0;
        IUNna:
        $PS9pL->fill(['id' => $F251H->getAttribute('id'), 'user_id' => $F251H->getAttribute('user_id') ?? auth()->user()->id, 'status' => $YEtX5, 'type' => $F251H->getType(), 'is_post' => $F251H->getAttribute('post_id') ? 1 : 0, 'is_message' => $F251H->getAttribute('message_id') ? 1 : 0, 'is_shop' => $F251H->getAttribute('shop_item_id') ? 1 : 0]);
        goto AsDAa;
        cZqG0:
        if (!Cloud::find($F251H->id)) {
            goto fGKX0;
        }
        goto lMmOA;
        lMmOA:
        return;
        goto a4Ujx;
        ouW5E:
        $PS9pL = new Cloud();
        goto IUNna;
        a4Ujx:
        fGKX0:
        goto ouW5E;
        AsDAa:
        $PS9pL->save();
        goto VJu6A;
        VJu6A:
    }
}
