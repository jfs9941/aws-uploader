<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mNCF8Xhym4w(Media $LiWvx, $feb3v = StatusEnum::KKfuY) : void
    {
        goto ZPIuZ;
        C6Yrb:
        $Q8K7a = new Cloud();
        goto unbi4;
        unbi4:
        $Q8K7a->fill(['id' => $LiWvx->getAttribute('id'), 'user_id' => $LiWvx->getAttribute('user_id') ?? auth()->user()->id, 'status' => $feb3v, 'type' => $LiWvx->getType(), 'is_post' => $LiWvx->getAttribute('post_id') ? 1 : 0, 'is_message' => $LiWvx->getAttribute('message_id') ? 1 : 0, 'is_shop' => $LiWvx->getAttribute('shop_item_id') ? 1 : 0]);
        goto SAFm1;
        SAFm1:
        $Q8K7a->save();
        goto Ew3R0;
        RIwcv:
        KSSJc:
        goto C6Yrb;
        f6Zon:
        return;
        goto RIwcv;
        ZPIuZ:
        if (!Cloud::find($LiWvx->id)) {
            goto KSSJc;
        }
        goto f6Zon;
        Ew3R0:
    }
}
