<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mTAjBySGIzh(Media $HO_3Y, $SU0DO = StatusEnum::vq4Bw) : void
    {
        goto H5mGa;
        H5mGa:
        if (!Cloud::find($HO_3Y->id)) {
            goto W2HAc;
        }
        goto OG01Q;
        OG01Q:
        return;
        goto zfFor;
        zfFor:
        W2HAc:
        goto OWzkg;
        ogpc5:
        $BjbbD->fill(['id' => $HO_3Y->getAttribute('id'), 'user_id' => $HO_3Y->getAttribute('user_id') ?? auth()->user()->id, 'status' => $SU0DO, 'type' => $HO_3Y->getType(), 'is_post' => $HO_3Y->getAttribute('post_id') ? 1 : 0, 'is_message' => $HO_3Y->getAttribute('message_id') ? 1 : 0, 'is_shop' => $HO_3Y->getAttribute('shop_item_id') ? 1 : 0]);
        goto ZWkF4;
        ZWkF4:
        $BjbbD->save();
        goto EOh_o;
        OWzkg:
        $BjbbD = new Cloud();
        goto ogpc5;
        EOh_o:
    }
}
