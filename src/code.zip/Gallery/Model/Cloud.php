<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mhWnBVgNzKq(Media $HpL55, $jsuoG = StatusEnum::Hc2dI) : void
    {
        goto kFRud;
        kFRud:
        if (!Cloud::find($HpL55->id)) {
            goto AQZFJ;
        }
        goto l8Mfr;
        alMOm:
        AQZFJ:
        goto vOxe_;
        l8Mfr:
        return;
        goto alMOm;
        ojG2s:
        $OPu3r->fill(['id' => $HpL55->getAttribute('id'), 'user_id' => $HpL55->getAttribute('user_id') ?? auth()->user()->id, 'status' => $jsuoG, 'type' => $HpL55->getType(), 'is_post' => $HpL55->getAttribute('post_id') ? 1 : 0, 'is_message' => $HpL55->getAttribute('message_id') ? 1 : 0, 'is_shop' => $HpL55->getAttribute('shop_item_id') ? 1 : 0]);
        goto E6CVT;
        E6CVT:
        $OPu3r->save();
        goto Hehjg;
        vOxe_:
        $OPu3r = new Cloud();
        goto ojG2s;
        Hehjg:
    }
}
