<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m0su91aQW5m(Media $P82oP, $jUelB = StatusEnum::P_f3U) : void
    {
        goto X9hFc;
        cfa3W:
        $ncGa7 = new Cloud();
        goto b4kO6;
        sIW4s:
        uK2nX:
        goto cfa3W;
        b4kO6:
        $ncGa7->fill(['id' => $P82oP->getAttribute('id'), 'user_id' => $P82oP->getAttribute('user_id') ?? auth()->user()->id, 'status' => $jUelB, 'type' => $P82oP->getType(), 'is_post' => $P82oP->getAttribute('post_id') ? 1 : 0, 'is_message' => $P82oP->getAttribute('message_id') ? 1 : 0, 'is_shop' => $P82oP->getAttribute('shop_item_id') ? 1 : 0]);
        goto vWl8T;
        vWl8T:
        $ncGa7->save();
        goto hn9MG;
        X9hFc:
        if (!Cloud::find($P82oP->id)) {
            goto uK2nX;
        }
        goto q0u5z;
        q0u5z:
        return;
        goto sIW4s;
        hn9MG:
    }
}
