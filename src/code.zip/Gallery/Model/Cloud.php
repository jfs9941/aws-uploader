<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function muXJqr3ygIP(Media $Zt12Z, $W09tp = StatusEnum::bs_B3) : void
    {
        goto KTm0B;
        VFU3v:
        return;
        goto Z3a_N;
        Z3a_N:
        LlPPg:
        goto x9AuC;
        nifd2:
        $ytVx9->fill(['id' => $Zt12Z->getAttribute('id'), 'user_id' => $Zt12Z->getAttribute('user_id') ?? auth()->user()->id, 'status' => $W09tp, 'type' => $Zt12Z->getType(), 'is_post' => $Zt12Z->getAttribute('post_id') ? 1 : 0, 'is_message' => $Zt12Z->getAttribute('message_id') ? 1 : 0, 'is_shop' => $Zt12Z->getAttribute('shop_item_id') ? 1 : 0]);
        goto j4W1C;
        j4W1C:
        $ytVx9->save();
        goto YeqNa;
        KTm0B:
        if (!Cloud::find($Zt12Z->id)) {
            goto LlPPg;
        }
        goto VFU3v;
        x9AuC:
        $ytVx9 = new Cloud();
        goto nifd2;
        YeqNa:
    }
}
