<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m9hMLtkXyEB(Media $Nb_Od, $Om7s6 = StatusEnum::DYk9Y) : void
    {
        goto SMTYS;
        SMTYS:
        if (!Cloud::find($Nb_Od->id)) {
            goto oQm0g;
        }
        goto s1qIA;
        Zcz0h:
        $O5YQF->save();
        goto LEayU;
        NIexb:
        $O5YQF = new Cloud();
        goto gkrRL;
        s1qIA:
        return;
        goto HQ07s;
        gkrRL:
        $O5YQF->fill(['id' => $Nb_Od->getAttribute('id'), 'user_id' => $Nb_Od->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Om7s6, 'type' => $Nb_Od->getType(), 'is_post' => $Nb_Od->getAttribute('post_id') ? 1 : 0, 'is_message' => $Nb_Od->getAttribute('message_id') ? 1 : 0, 'is_shop' => $Nb_Od->getAttribute('shop_item_id') ? 1 : 0]);
        goto Zcz0h;
        HQ07s:
        oQm0g:
        goto NIexb;
        LEayU:
    }
}
