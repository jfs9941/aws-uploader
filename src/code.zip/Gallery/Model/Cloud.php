<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mWSX4o3yTkk(Media $DzZNO, $CihEh = StatusEnum::f2t50) : void
    {
        goto OFRa_;
        CX1Ky:
        $kMK51->fill(['id' => $DzZNO->getAttribute('id'), 'user_id' => $DzZNO->getAttribute('user_id') ?? auth()->user()->id, 'status' => $CihEh, 'type' => $DzZNO->getType(), 'is_post' => $DzZNO->getAttribute('post_id') ? 1 : 0, 'is_message' => $DzZNO->getAttribute('message_id') ? 1 : 0, 'is_shop' => $DzZNO->getAttribute('shop_item_id') ? 1 : 0]);
        goto fIAqZ;
        OFRa_:
        if (!Cloud::find($DzZNO->id)) {
            goto frR1U;
        }
        goto UQOiw;
        UQOiw:
        return;
        goto jB9pT;
        jB9pT:
        frR1U:
        goto sLDtq;
        sLDtq:
        $kMK51 = new Cloud();
        goto CX1Ky;
        fIAqZ:
        $kMK51->save();
        goto X5JqB;
        X5JqB:
    }
}
