<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m4f8TxJYcu6(Media $I80en, $FAU_L = StatusEnum::VSEus) : void
    {
        goto wcrKt;
        RZQ2j:
        $ZGYBE->fill(['id' => $I80en->getAttribute('id'), 'user_id' => $I80en->getAttribute('user_id') ?? auth()->user()->id, 'status' => $FAU_L, 'type' => $I80en->getType(), 'is_post' => $I80en->getAttribute('post_id') ? 1 : 0, 'is_message' => $I80en->getAttribute('message_id') ? 1 : 0, 'is_shop' => $I80en->getAttribute('shop_item_id') ? 1 : 0]);
        goto I3TDt;
        I3TDt:
        $ZGYBE->save();
        goto vUFCK;
        S3ahc:
        return;
        goto LcMBt;
        LcMBt:
        szWAi:
        goto nHz5x;
        nHz5x:
        $ZGYBE = new Cloud();
        goto RZQ2j;
        wcrKt:
        if (!Cloud::find($I80en->id)) {
            goto szWAi;
        }
        goto S3ahc;
        vUFCK:
    }
}
