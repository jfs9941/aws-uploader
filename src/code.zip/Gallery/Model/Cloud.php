<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mpetjj3h1GV(Media $p0I5F, $bUe6G = StatusEnum::ihbzS) : void
    {
        goto fP8Ud;
        uKwVB:
        $lK1w0->fill(['id' => $p0I5F->getAttribute('id'), 'user_id' => $p0I5F->getAttribute('user_id') ?? auth()->user()->id, 'status' => $bUe6G, 'type' => $p0I5F->getType(), 'is_post' => $p0I5F->getAttribute('post_id') ? 1 : 0, 'is_message' => $p0I5F->getAttribute('message_id') ? 1 : 0, 'is_shop' => $p0I5F->getAttribute('shop_item_id') ? 1 : 0]);
        goto Ezmw4;
        MVwRs:
        anQ4L:
        goto G0rMZ;
        OnlKD:
        return;
        goto MVwRs;
        G0rMZ:
        $lK1w0 = new Cloud();
        goto uKwVB;
        fP8Ud:
        if (!Cloud::find($p0I5F->id)) {
            goto anQ4L;
        }
        goto OnlKD;
        Ezmw4:
        $lK1w0->save();
        goto Qi652;
        Qi652:
    }
}
