<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mhEdtGbCRFm(Media $m5Vy1, $sAkBH = StatusEnum::FtKxT) : void
    {
        goto Wm8ZO;
        Uz6MF:
        DNwCS:
        goto VlSnN;
        PDLy2:
        return;
        goto Uz6MF;
        CqawD:
        $C4gcS->save();
        goto suURP;
        VlSnN:
        $C4gcS = new Cloud();
        goto SoOGG;
        SoOGG:
        $C4gcS->fill(['id' => $m5Vy1->getAttribute('id'), 'user_id' => $m5Vy1->getAttribute('user_id') ?? auth()->user()->id, 'status' => $sAkBH, 'type' => $m5Vy1->getType(), 'is_post' => $m5Vy1->getAttribute('post_id') ? 1 : 0, 'is_message' => $m5Vy1->getAttribute('message_id') ? 1 : 0, 'is_shop' => $m5Vy1->getAttribute('shop_item_id') ? 1 : 0]);
        goto CqawD;
        Wm8ZO:
        if (!Cloud::find($m5Vy1->id)) {
            goto DNwCS;
        }
        goto PDLy2;
        suURP:
    }
}
