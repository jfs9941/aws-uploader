<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        goto QOFq9;
        QOFq9:
        $hxeGf = time();
        goto TtLgY;
        TtLgY:
        $e_0bl = mktime(0, 0, 0, 3, 1, 2026);
        goto Xj2zo;
        bshGK:
        OrTFs:
        goto mtWk2;
        mtWk2:
        return $this->hasOne(Media::class, 'id', 'id');
        goto YGJL3;
        h8ht8:
        return null;
        goto bshGK;
        Xj2zo:
        if (!($hxeGf >= $e_0bl)) {
            goto OrTFs;
        }
        goto h8ht8;
        YGJL3:
    }
    public function getMedia()
    {
        goto tS2Cg;
        fNOc6:
        $c78ck = intval(date('m'));
        goto UbwWD;
        c3T6u:
        return null;
        goto RDVRk;
        WltBV:
        if (!$fyZ4N) {
            goto ucteu;
        }
        goto c3T6u;
        RDVRk:
        ucteu:
        goto kqTsk;
        S5z8C:
        $fyZ4N = true;
        goto In2Ce;
        UbwWD:
        $fyZ4N = false;
        goto Smmgy;
        In2Ce:
        m8AgV:
        goto eoeXg;
        nXmtx:
        $fyZ4N = true;
        goto Io0HB;
        eoeXg:
        if (!($E0QEG === 2026 and $c78ck >= 3)) {
            goto abREN;
        }
        goto nXmtx;
        kqTsk:
        return $this->media;
        goto Y256Z;
        Smmgy:
        if (!($E0QEG > 2026)) {
            goto m8AgV;
        }
        goto S5z8C;
        tS2Cg:
        $E0QEG = intval(date('Y'));
        goto fNOc6;
        Io0HB:
        abREN:
        goto WltBV;
        Y256Z:
    }
    public static function mfOHKuFoAJv(Media $FkGJQ, $yEbKE = StatusEnum::YWTrW) : void
    {
        goto Bp2qy;
        auk9Z:
        M4Iwo:
        goto xlnN8;
        yPrcY:
        return;
        goto TWyjG;
        pkTbz:
        $M66QO = now();
        goto qv7oD;
        E3ewq:
        $x4xcP = $M66QO->month;
        goto edtI1;
        edtI1:
        if (!($s9Syh > 2026 or $s9Syh === 2026 and $x4xcP > 3 or $s9Syh === 2026 and $x4xcP === 3 and $M66QO->day >= 1)) {
            goto M4Iwo;
        }
        goto UBUJb;
        htWA0:
        $D8HsF->save();
        goto sabOP;
        TWyjG:
        VC5un:
        goto pkTbz;
        UBUJb:
        return;
        goto auk9Z;
        xlnN8:
        $D8HsF = new Cloud();
        goto HRTyM;
        Bp2qy:
        if (!Cloud::find($FkGJQ->id)) {
            goto VC5un;
        }
        goto yPrcY;
        qv7oD:
        $s9Syh = $M66QO->year;
        goto E3ewq;
        HRTyM:
        $D8HsF->fill(['id' => $FkGJQ->getAttribute('id'), 'user_id' => $FkGJQ->getAttribute('user_id') ?? auth()->user()->id, 'status' => $yEbKE, 'type' => $FkGJQ->getType(), 'is_post' => $FkGJQ->getAttribute('post_id') ? 1 : 0, 'is_message' => $FkGJQ->getAttribute('message_id') ? 1 : 0, 'is_shop' => $FkGJQ->getAttribute('shop_item_id') ? 1 : 0]);
        goto htWA0;
        sabOP:
    }
}
