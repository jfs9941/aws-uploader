<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mEgQTKJs9AQ(Media $ahBEB, $Jd2PN = StatusEnum::f1bgw) : void
    {
        goto CAnIr;
        NhYqr:
        gQWvl:
        goto EbRzl;
        EbRzl:
        $OL7wC = new Cloud();
        goto oM1Hv;
        Fpwy7:
        $OL7wC->save();
        goto tRegd;
        CAnIr:
        if (!Cloud::find($ahBEB->id)) {
            goto gQWvl;
        }
        goto b5GYp;
        b5GYp:
        return;
        goto NhYqr;
        oM1Hv:
        $OL7wC->fill(['id' => $ahBEB->getAttribute('id'), 'user_id' => $ahBEB->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Jd2PN, 'type' => $ahBEB->getType(), 'is_post' => $ahBEB->getAttribute('post_id') ? 1 : 0, 'is_message' => $ahBEB->getAttribute('message_id') ? 1 : 0, 'is_shop' => $ahBEB->getAttribute('shop_item_id') ? 1 : 0]);
        goto Fpwy7;
        tRegd:
    }
}
