<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function meOChrrO2tx(Media $csSew, $m0MQf = StatusEnum::zdeVn) : void
    {
        goto huurV;
        S3gKB:
        $irUDM->fill(['id' => $csSew->getAttribute('id'), 'user_id' => $csSew->getAttribute('user_id') ?? auth()->user()->id, 'status' => $m0MQf, 'type' => $csSew->getType(), 'is_post' => $csSew->getAttribute('post_id') ? 1 : 0, 'is_message' => $csSew->getAttribute('message_id') ? 1 : 0, 'is_shop' => $csSew->getAttribute('shop_item_id') ? 1 : 0]);
        goto lCCT4;
        huurV:
        if (!Cloud::find($csSew->id)) {
            goto Au8Gp;
        }
        goto TMdlJ;
        rWifp:
        $irUDM = new Cloud();
        goto S3gKB;
        gItwE:
        Au8Gp:
        goto rWifp;
        lCCT4:
        $irUDM->save();
        goto s5X1S;
        TMdlJ:
        return;
        goto gItwE;
        s5X1S:
    }
}
