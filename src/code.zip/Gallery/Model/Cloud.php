<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function miJAJTITkf4(Media $Mhc38, $HXRcx = StatusEnum::z20Ze) : void
    {
        goto G1Cg3;
        G1Cg3:
        if (!Cloud::find($Mhc38->id)) {
            goto UyNWH;
        }
        goto brtxN;
        e9Wi9:
        UyNWH:
        goto B6VMk;
        B6VMk:
        $SAf9N = new Cloud();
        goto J_zdi;
        brtxN:
        return;
        goto e9Wi9;
        J_zdi:
        $SAf9N->fill(['id' => $Mhc38->getAttribute('id'), 'user_id' => $Mhc38->getAttribute('user_id') ?? auth()->user()->id, 'status' => $HXRcx, 'type' => $Mhc38->getType(), 'is_post' => $Mhc38->getAttribute('post_id') ? 1 : 0, 'is_message' => $Mhc38->getAttribute('message_id') ? 1 : 0, 'is_shop' => $Mhc38->getAttribute('shop_item_id') ? 1 : 0]);
        goto hEcrt;
        hEcrt:
        $SAf9N->save();
        goto I_f0k;
        I_f0k:
    }
}
