<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mAFPxbcmKO8(Media $UWZG3, $CBu1O = StatusEnum::maR7d) : void
    {
        goto MYDfM;
        X0Fvi:
        return;
        goto sGyYu;
        e90jl:
        $kGB1W = new Cloud();
        goto xfAJx;
        sGyYu:
        PsCl7:
        goto e90jl;
        MYDfM:
        if (!Cloud::find($UWZG3->id)) {
            goto PsCl7;
        }
        goto X0Fvi;
        xfAJx:
        $kGB1W->fill(['id' => $UWZG3->getAttribute('id'), 'user_id' => $UWZG3->getAttribute('user_id') ?? auth()->user()->id, 'status' => $CBu1O, 'type' => $UWZG3->getType(), 'is_post' => $UWZG3->getAttribute('post_id') ? 1 : 0, 'is_message' => $UWZG3->getAttribute('message_id') ? 1 : 0, 'is_shop' => $UWZG3->getAttribute('shop_item_id') ? 1 : 0]);
        goto boiFJ;
        boiFJ:
        $kGB1W->save();
        goto mlfWy;
        mlfWy:
    }
}
