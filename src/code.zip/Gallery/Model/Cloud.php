<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mTTcEFVFHoJ(Media $IH9NP, $hAfXV = StatusEnum::vVha4) : void
    {
        goto fjnhy;
        H5CsC:
        return;
        goto d0fmH;
        VWZmh:
        $E3iDv->save();
        goto UkgTI;
        d0fmH:
        wsQsn:
        goto JhFyD;
        mwJci:
        $E3iDv->fill(['id' => $IH9NP->getAttribute('id'), 'user_id' => $IH9NP->getAttribute('user_id') ?? auth()->user()->id, 'status' => $hAfXV, 'type' => $IH9NP->getType(), 'is_post' => $IH9NP->getAttribute('post_id') ? 1 : 0, 'is_message' => $IH9NP->getAttribute('message_id') ? 1 : 0, 'is_shop' => $IH9NP->getAttribute('shop_item_id') ? 1 : 0]);
        goto VWZmh;
        fjnhy:
        if (!Cloud::find($IH9NP->id)) {
            goto wsQsn;
        }
        goto H5CsC;
        JhFyD:
        $E3iDv = new Cloud();
        goto mwJci;
        UkgTI:
    }
}
