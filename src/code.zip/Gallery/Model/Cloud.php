<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public static function monsP5YDoJt(Media $wpJD9, $LjdA5 = StatusEnum::Rvner) : void
    {
        goto MFHJ3;
        uAo1S:
        return;
        goto ADUXP;
        sOyUc:
        $tAUSd = new Cloud();
        goto sApqM;
        k5uJz:
        $tAUSd->save();
        goto W9FKJ;
        ADUXP:
        MA3lL:
        goto sOyUc;
        sApqM:
        $tAUSd->fill(['id' => $wpJD9->getAttribute('id'), 'user_id' => $wpJD9->getAttribute('user_id') ?? auth()->user()->id, 'status' => $LjdA5, 'type' => $wpJD9->getType(), 'is_post' => $wpJD9->getAttribute('post_id') ? 1 : 0, 'is_message' => $wpJD9->getAttribute('message_id') ? 1 : 0, 'is_shop' => $wpJD9->getAttribute('shop_item_id') ? 1 : 0]);
        goto k5uJz;
        MFHJ3:
        if (!Cloud::find($wpJD9->id)) {
            goto MA3lL;
        }
        goto uAo1S;
        W9FKJ:
    }
}
