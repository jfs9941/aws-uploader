<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\StatusEnum;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m0aKDlthFPg(Media $qRTR9, $S3XWd = StatusEnum::Vn9e9) : void
    {
        goto PyQWb;
        ExZgY:
        $Hxnc0->fill(['id' => $qRTR9->getAttribute('id'), 'user_id' => $qRTR9->getAttribute('user_id') ?? auth()->user()->id, 'status' => $S3XWd, 'type' => $qRTR9->getType(), 'is_post' => $qRTR9->getAttribute('post_id') ? 1 : 0, 'is_message' => $qRTR9->getAttribute('message_id') ? 1 : 0, 'is_shop' => $qRTR9->getAttribute('shop_item_id') ? 1 : 0]);
        goto dU2KY;
        j1RYk:
        $Hxnc0 = new Cloud();
        goto ExZgY;
        svVBC:
        Jk2v2:
        goto j1RYk;
        dU2KY:
        $Hxnc0->save();
        goto YFxHb;
        j_gHP:
        return;
        goto svVBC;
        PyQWb:
        if (!Cloud::find($qRTR9->id)) {
            goto Jk2v2;
        }
        goto j_gHP;
        YFxHb:
    }
}
