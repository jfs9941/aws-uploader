<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mOcvAld26vf(Media $G2mX1, $YMdXw = StatusEnum::AM3bf) : void
    {
        goto nLxfP;
        nLxfP:
        if (!Cloud::find($G2mX1->id)) {
            goto MhA2z;
        }
        goto rwNcl;
        BUWdi:
        MhA2z:
        goto ydNeA;
        IJvlr:
        $NwPQk->fill(['id' => $G2mX1->getAttribute('id'), 'user_id' => $G2mX1->getAttribute('user_id') ?? auth()->user()->id, 'status' => $YMdXw, 'type' => $G2mX1->getType(), 'is_post' => $G2mX1->getAttribute('post_id') ? 1 : 0, 'is_message' => $G2mX1->getAttribute('message_id') ? 1 : 0, 'is_shop' => $G2mX1->getAttribute('shop_item_id') ? 1 : 0]);
        goto nqza4;
        nqza4:
        $NwPQk->save();
        goto uj5G5;
        ydNeA:
        $NwPQk = new Cloud();
        goto IJvlr;
        rwNcl:
        return;
        goto BUWdi;
        uj5G5:
    }
}
