<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Media::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function mud5dNZaXXy(Media $zacay, $Zptw7 = StatusEnum::ZNjvU) : void
    {
        goto f9Lp7;
        Udxto:
        QZnwQ:
        goto nJqon;
        jAl61:
        return;
        goto Udxto;
        nJqon:
        $sn0U6 = new Cloud();
        goto ZDxoF;
        f9Lp7:
        if (!Cloud::find($zacay->id)) {
            goto QZnwQ;
        }
        goto jAl61;
        VKgt0:
        $sn0U6->save();
        goto XMLxb;
        ZDxoF:
        $sn0U6->fill(['id' => $zacay->getAttribute('id'), 'user_id' => $zacay->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Zptw7, 'type' => $zacay->getType(), 'is_post' => $zacay->getAttribute('post_id') ? 1 : 0, 'is_message' => $zacay->getAttribute('message_id') ? 1 : 0, 'is_shop' => $zacay->getAttribute('shop_item_id') ? 1 : 0]);
        goto VKgt0;
        XMLxb:
    }
}
