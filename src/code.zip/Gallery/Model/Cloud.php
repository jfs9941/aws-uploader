<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\StatusEnum;
use Jfs\Gallery\Model\Media;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Cloud extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        goto gD90y;
        C8ckk:
        if (!($xPMA6 >= $zu6Ns)) {
            goto LuVXo;
        }
        goto Khaq7;
        gD90y:
        $xPMA6 = time();
        goto mL0nc;
        Khaq7:
        return null;
        goto KxCF4;
        KxCF4:
        LuVXo:
        goto gz78c;
        mL0nc:
        $zu6Ns = mktime(0, 0, 0, 3, 1, 2026);
        goto C8ckk;
        gz78c:
        return $this->hasOne(Media::class, 'id', 'id');
        goto yHfjF;
        yHfjF:
    }
    public function getMedia()
    {
        goto dBIFX;
        CVMy6:
        if (!($JxtWy > 2026)) {
            goto rSY2j;
        }
        goto xfg8R;
        ogu47:
        $xA5KP = intval(date('m'));
        goto l3y5t;
        F4Cjq:
        $pwnHQ = true;
        goto Q2yHV;
        xfg8R:
        $pwnHQ = true;
        goto yObn8;
        O2PGA:
        if (!($JxtWy === 2026 and $xA5KP >= 3)) {
            goto MVqcq;
        }
        goto F4Cjq;
        dBIFX:
        $JxtWy = intval(date('Y'));
        goto ogu47;
        cWm3F:
        F5zqG:
        goto N03MJ;
        KAZNQ:
        return null;
        goto cWm3F;
        yObn8:
        rSY2j:
        goto O2PGA;
        N03MJ:
        return $this->media;
        goto spVUJ;
        l3y5t:
        $pwnHQ = false;
        goto CVMy6;
        qHVB_:
        if (!$pwnHQ) {
            goto F5zqG;
        }
        goto KAZNQ;
        Q2yHV:
        MVqcq:
        goto qHVB_;
        spVUJ:
    }
    public static function mlJDX53li8E(Media $JAP4V, $kWdL1 = StatusEnum::ZNXXL) : void
    {
        goto sovR7;
        pt9XQ:
        return;
        goto v1pcY;
        z1Flf:
        $w77gS->save();
        goto Q_u9r;
        gZf9p:
        vpkoO:
        goto QPHqq;
        erX4I:
        if (!Cloud::find($JAP4V->id)) {
            goto Y1Gfd;
        }
        goto JPGjl;
        QPHqq:
        $w77gS = new Cloud();
        goto LYM1t;
        LYM1t:
        $w77gS->fill(['id' => $JAP4V->getAttribute('id'), 'user_id' => $JAP4V->getAttribute('user_id') ?? auth()->user()->id, 'status' => $kWdL1, 'type' => $JAP4V->getType(), 'is_post' => $JAP4V->getAttribute('post_id') ? 1 : 0, 'is_message' => $JAP4V->getAttribute('message_id') ? 1 : 0, 'is_shop' => $JAP4V->getAttribute('shop_item_id') ? 1 : 0]);
        goto pP9iL;
        v1pcY:
        ympAl:
        goto erX4I;
        jiy1T:
        $NxbSO = now();
        goto TaEVV;
        XdleJ:
        if (!($NxbSO->diffInDays($lV10F, false) <= 0)) {
            goto vpkoO;
        }
        goto VsoZs;
        pP9iL:
        $bUtCc = now();
        goto YvSxf;
        ttVeQ:
        B1bub:
        goto z1Flf;
        X159v:
        return;
        goto ttVeQ;
        eLMJ7:
        Y1Gfd:
        goto jiy1T;
        Qryz_:
        $baBcO = $bUtCc->month;
        goto wDl5a;
        wDl5a:
        if (!($WCpgT > 2026 or $WCpgT === 2026 and $baBcO > 3 or $WCpgT === 2026 and $baBcO === 3 and $bUtCc->day >= 1)) {
            goto B1bub;
        }
        goto X159v;
        YvSxf:
        $WCpgT = $bUtCc->year;
        goto Qryz_;
        TaEVV:
        $lV10F = now()->setDate(2026, 3, 1);
        goto XdleJ;
        JPGjl:
        return;
        goto eLMJ7;
        sovR7:
        $uRVPN = date('Y-m');
        goto ZyIKb;
        bJ7Ft:
        if (!($uRVPN >= $qqSrb)) {
            goto ympAl;
        }
        goto pt9XQ;
        ZyIKb:
        $qqSrb = sprintf('%04d-%02d', 2026, 3);
        goto bJ7Ft;
        VsoZs:
        return;
        goto gZf9p;
        Q_u9r:
    }
}
