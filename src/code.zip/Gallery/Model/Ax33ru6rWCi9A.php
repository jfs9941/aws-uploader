<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Gallery\Model; use Illuminate\Database\Eloquent\Model; use Illuminate\Database\Eloquent\Relations\HasOne; use Jfs\Gallery\Model\Enum\G0BxouddcwdN9; class Ax33ru6rWCi9A extends Model { protected $table = 'cloud'; protected $keyType = 'string'; public $incrementing = false; protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type']; protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean']; public function media() : HasOne { return $this->hasOne(PrnhOTG505Txz::class, 'id', 'id'); } public static function mJdtyijogdQ(PrnhOTG505Txz $zSEOq, $CDrl1 = G0BxouddcwdN9::db88F) : void { goto MsJLd; QGtRk: $F87jo = new Ax33ru6rWCi9A(); goto ZJ3Qb; di72u: $F87jo->save(); goto nnVWT; zYvXI: return; goto Sz9w1; Sz9w1: Vhghf: goto QGtRk; MsJLd: if (!Ax33ru6rWCi9A::find($zSEOq->id)) { goto Vhghf; } goto zYvXI; ZJ3Qb: $F87jo->fill(['id' => $zSEOq->getAttribute('id'), 'user_id' => $zSEOq->getAttribute('user_id') ?? auth()->user()->id, 'status' => $CDrl1, 'type' => $zSEOq->getType(), 'is_post' => $zSEOq->getAttribute('post_id') ? 1 : 0, 'is_message' => $zSEOq->getAttribute('message_id') ? 1 : 0, 'is_shop' => $zSEOq->getAttribute('shop_item_id') ? 1 : 0]); goto di72u; nnVWT: } }
