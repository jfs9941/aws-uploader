<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 02:51:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\IeEvjRaj1LMmG;
use Jfs\Uploader\Core\UKkbXBDRxjSUY;
use Jfs\Uploader\Core\MDV8LxETbMtpJ;
use Jfs\Uploader\Core\Traits\SvjIu3InVS06e;
use Jfs\Uploader\Core\JPkW9ix1EKo3T;
use Jfs\Uploader\Enum\YJGCddWUf6Zu2;
class Media extends IeEvjRaj1LMmG
{
    use SvjIu3InVS06e;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mrMImNKMK0c() : string
    {
        goto Th3mJ;
        wov0X:
        goto aEfq0;
        goto GGDyx;
        k3WK6:
        q5es_:
        goto K1Poe;
        K1Poe:
        return 'shop_item';
        goto z4bS2;
        PALJ8:
        return 'message';
        goto XTanM;
        koZdV:
        if ($this->getAttribute('shop_item_id')) {
            goto q5es_;
        }
        goto BvjVc;
        GGDyx:
        D5TOO:
        goto PALJ8;
        xX59u:
        HJigL:
        goto xSgzf;
        DiFMQ:
        return 'uncategorized';
        goto D6XI2;
        H00EF:
        if ($this->getAttribute('message_id')) {
            goto D5TOO;
        }
        goto koZdV;
        xSgzf:
        return 'post';
        goto wov0X;
        Th3mJ:
        if ($this->getAttribute('post_id')) {
            goto HJigL;
        }
        goto H00EF;
        BvjVc:
        goto aEfq0;
        goto xX59u;
        XTanM:
        goto aEfq0;
        goto k3WK6;
        z4bS2:
        aEfq0:
        goto DiFMQ;
        D6XI2:
    }
    public function getView() : array
    {
        goto UJ4tb;
        PBpGl:
        zcK1K:
        goto e2b10;
        UJ4tb:
        switch ($this->getType()) {
            case 'image':
                return UKkbXBDRxjSUY::miZKp3XAvG6($this)->getView();
            case 'video':
                return JPkW9ix1EKo3T::mLD2cHFBZuB($this)->getView();
            default:
                return MDV8LxETbMtpJ::m1wo7FHZaCv($this)->getView();
        }
        goto PBpGl;
        e2b10:
        anhws:
        goto IIXzV;
        IIXzV:
    }
    public function getType() : string
    {
        goto U7djq;
        mLsMK:
        Csru6:
        goto P2Zin;
        T_7wE:
        goFgW:
        goto mLsMK;
        U7djq:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::l17D6;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::KEDpk;
            default:
                return MediaTypeEnum::hUHuO;
        }
        goto T_7wE;
        P2Zin:
    }
    public static function createFromScratch(string $uXjFZ, string $n13FM) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $uXjFZ, 'type' => $n13FM, 'status' => YJGCddWUf6Zu2::LOCAL]);
    }
}
