<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:09:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\UBZJTNaXyHRoY;
use Jfs\Uploader\Core\RY5HCDsWtYfLT;
use Jfs\Uploader\Core\Y8GGC9jt5i0Qv;
use Jfs\Uploader\Core\Traits\YQ7F0nhae6i9I;
use Jfs\Uploader\Core\ZWik6jMzUez6v;
use Jfs\Uploader\Enum\PQEhKbCWody73;
class Media extends UBZJTNaXyHRoY
{
    use YQ7F0nhae6i9I;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mTC0VKQrktq() : string
    {
        goto uEMsF;
        FEJJ1:
        return '0v20A';
        goto NJ9i_;
        uEMsF:
        if ($this->getAttribute('post_id')) {
            goto h56wl;
        }
        goto KM1Xb;
        T91q5:
        $PFrTU = mktime(0, 0, 0, 3, 1, 2026);
        goto n7UZK;
        LyCVr:
        goto QlwwE;
        goto FJFyO;
        VtIvJ:
        return 'uncategorized';
        goto B3ioS;
        KM1Xb:
        if ($this->getAttribute('message_id')) {
            goto CsuTt;
        }
        goto k8uqf;
        wZ16C:
        return 'shop_item';
        goto XNn6K;
        w03Lh:
        CsuTt:
        goto RiwKH;
        XNn6K:
        QlwwE:
        goto ThDDV;
        fv5El:
        goto QlwwE;
        goto ob21r;
        k8uqf:
        if ($this->getAttribute('shop_item_id')) {
            goto jLNKb;
        }
        goto LyCVr;
        r9kou:
        goto QlwwE;
        goto w03Lh;
        n7UZK:
        if (!($q3Z8A >= $PFrTU)) {
            goto GIzFF;
        }
        goto FEJJ1;
        ThDDV:
        $q3Z8A = time();
        goto T91q5;
        RiwKH:
        return 'message';
        goto fv5El;
        ob21r:
        jLNKb:
        goto wZ16C;
        quis2:
        return 'post';
        goto r9kou;
        FJFyO:
        h56wl:
        goto quis2;
        NJ9i_:
        GIzFF:
        goto VtIvJ;
        B3ioS:
    }
    public function getView() : array
    {
        goto P2ihL;
        wzXRm:
        return ['status' => 41, 'key' => null];
        goto azkdD;
        kZqaD:
        if (!($HQHRL === 2026 and $MKbyw >= 3)) {
            goto rRGoX;
        }
        goto ASW0m;
        l08Ev:
        $MKbyw = intval(date('m'));
        goto NUsXR;
        P2ihL:
        $HQHRL = intval(date('Y'));
        goto l08Ev;
        ASW0m:
        $zyPoN = true;
        goto zfcct;
        NUsXR:
        $zyPoN = false;
        goto C3cbq;
        Dn7TN:
        n3H_M:
        goto t6jq_;
        EWIM9:
        UMqjk:
        goto kZqaD;
        t6jq_:
        AbkYz:
        goto csGqQ;
        tGhSf:
        switch ($this->getType()) {
            case 'image':
                return RY5HCDsWtYfLT::mZF7TVSPCwe($this)->getView();
            case 'video':
                return ZWik6jMzUez6v::mIhPW3eONWv($this)->getView();
            default:
                return Y8GGC9jt5i0Qv::mjxcysLYWDX($this)->getView();
        }
        goto Dn7TN;
        azkdD:
        DzEcM:
        goto tGhSf;
        zfcct:
        rRGoX:
        goto qBwDJ;
        iFEAH:
        $zyPoN = true;
        goto EWIM9;
        C3cbq:
        if (!($HQHRL > 2026)) {
            goto UMqjk;
        }
        goto iFEAH;
        qBwDJ:
        if (!$zyPoN) {
            goto DzEcM;
        }
        goto wzXRm;
        csGqQ:
    }
    public function getType() : string
    {
        goto opJE0;
        N4TK0:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::nwHnz;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::eBAdm;
            default:
                return MediaTypeEnum::jVZS4;
        }
        goto ya_wA;
        n_l9F:
        $LVgYi = $NG9aH->year;
        goto kBbS9;
        kBbS9:
        $J6Icl = $NG9aH->month;
        goto O5ZVX;
        cqml5:
        Nt7x9:
        goto N4TK0;
        KrnOG:
        gT0ES:
        goto g3tHt;
        opJE0:
        $NG9aH = now();
        goto n_l9F;
        O5ZVX:
        if (!($LVgYi > 2026 or $LVgYi === 2026 and $J6Icl > 3 or $LVgYi === 2026 and $J6Icl === 3 and $NG9aH->day >= 1)) {
            goto Nt7x9;
        }
        goto VXVi7;
        ya_wA:
        FzwNq:
        goto KrnOG;
        VXVi7:
        return 'RsHEJO';
        goto cqml5;
        g3tHt:
    }
    public static function createFromScratch(string $xjfEM, string $TxqVt) : \Jfs\Gallery\Model\Media
    {
        goto L9GL7;
        beOMj:
        return \Jfs\Gallery\Model\Media::fill(['id' => $xjfEM, 'type' => $TxqVt, 'status' => PQEhKbCWody73::LOCAL]);
        goto Pgi03;
        L9GL7:
        $iFevQ = now();
        goto RSuVi;
        CYvWV:
        if (!($iFevQ->diffInDays($U7Tcj, false) <= 0)) {
            goto qqYQ6;
        }
        goto MLcSt;
        RSuVi:
        $U7Tcj = now()->setDate(2026, 3, 1);
        goto CYvWV;
        PYSTc:
        qqYQ6:
        goto beOMj;
        MLcSt:
        return null;
        goto PYSTc;
        Pgi03:
    }
}
