<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:57:26              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\D3Q3lppZQonk9;
use Jfs\Uploader\Core\OjvWwjWRqBzIO;
use Jfs\Uploader\Core\EqLr3PLlMLHwV;
use Jfs\Uploader\Core\Traits\NYTKsbVPARY8x;
use Jfs\Uploader\Core\HVuLZHLrSam0d;
use Jfs\Uploader\Enum\NFXMub09wSQVu;
class Media extends D3Q3lppZQonk9
{
    use NYTKsbVPARY8x;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mVji1WChmSL() : string
    {
        goto Y3wUc;
        afbYy:
        goto q_13U;
        goto a6hkb;
        RwY5k:
        return 'shop_item';
        goto vXelq;
        Dz33O:
        if ($this->getAttribute('message_id')) {
            goto j7S80;
        }
        goto uiH7a;
        rXNdM:
        goto q_13U;
        goto uNW9n;
        uNW9n:
        j7S80:
        goto b4y7w;
        Y3wUc:
        if ($this->getAttribute('post_id')) {
            goto aNw2k;
        }
        goto Dz33O;
        a6hkb:
        Tu2Dp:
        goto RwY5k;
        Y7n3o:
        goto q_13U;
        goto koat6;
        koat6:
        aNw2k:
        goto YiM5J;
        PIDAb:
        return 'uncategorized';
        goto LP5Nj;
        b4y7w:
        return 'message';
        goto afbYy;
        uiH7a:
        if ($this->getAttribute('shop_item_id')) {
            goto Tu2Dp;
        }
        goto Y7n3o;
        YiM5J:
        return 'post';
        goto rXNdM;
        vXelq:
        q_13U:
        goto PIDAb;
        LP5Nj:
    }
    public function getView() : array
    {
        goto QDasq;
        JJsOa:
        HIKNf:
        goto mnOpd;
        HUgi6:
        bkqrE:
        goto JJsOa;
        QDasq:
        switch ($this->getType()) {
            case 'image':
                return OjvWwjWRqBzIO::m7FwvxMaWNh($this)->getView();
            case 'video':
                return HVuLZHLrSam0d::mZ5lW3h9Joj($this)->getView();
            default:
                return EqLr3PLlMLHwV::myKiZABVUDf($this)->getView();
        }
        goto HUgi6;
        mnOpd:
    }
    public function getType() : string
    {
        goto V3Lvn;
        xItFL:
        zfprB:
        goto Gf75r;
        V3Lvn:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::TGUH9;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::Cu_Gi;
            default:
                return MediaTypeEnum::nNVVm;
        }
        goto ZuDiF;
        ZuDiF:
        OjzFN:
        goto xItFL;
        Gf75r:
    }
    public static function createFromScratch(string $sAFP4, string $geXNd) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $sAFP4, 'type' => $geXNd, 'status' => NFXMub09wSQVu::LOCAL]);
    }
}
