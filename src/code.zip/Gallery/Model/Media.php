<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:41:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\Zl4rdW32ufaUx;
use Jfs\Uploader\Core\XMeo8SOmME8kj;
use Jfs\Uploader\Core\NfPkVduXHwQBz;
use Jfs\Uploader\Core\Traits\EpBhYo5NrILTt;
use Jfs\Uploader\Core\U9HMl0N8dP0ZH;
use Jfs\Uploader\Enum\J0IuL8wroLOWt;
class Media extends Zl4rdW32ufaUx
{
    use EpBhYo5NrILTt;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m62GlW5x06Y() : string
    {
        goto eHza1;
        AaL2_:
        NQDgd:
        goto wJH0h;
        AjDuf:
        eUQdk:
        goto psNfW;
        NmHuQ:
        LMWiH:
        goto VU6c1;
        Nn8tp:
        goto NQDgd;
        goto AjDuf;
        XdAP0:
        return 'shop_item';
        goto AaL2_;
        jcQt_:
        if ($this->getAttribute('shop_item_id')) {
            goto PqOJs;
        }
        goto Nn8tp;
        ItOA5:
        PqOJs:
        goto XdAP0;
        nKNSJ:
        goto NQDgd;
        goto NmHuQ;
        q4Y4Y:
        if ($this->getAttribute('message_id')) {
            goto LMWiH;
        }
        goto jcQt_;
        VU6c1:
        return 'message';
        goto bJ9go;
        bJ9go:
        goto NQDgd;
        goto ItOA5;
        psNfW:
        return 'post';
        goto nKNSJ;
        wJH0h:
        return 'uncategorized';
        goto GwDpE;
        eHza1:
        if ($this->getAttribute('post_id')) {
            goto eUQdk;
        }
        goto q4Y4Y;
        GwDpE:
    }
    public function getView() : array
    {
        goto oiJzk;
        dmrDt:
        Z1is1:
        goto T_VcN;
        WdBXK:
        tVANL:
        goto dmrDt;
        oiJzk:
        switch ($this->getType()) {
            case 'image':
                return XMeo8SOmME8kj::m5NjCLAZvYq($this)->getView();
            case 'video':
                return U9HMl0N8dP0ZH::mxCkMxMEFEn($this)->getView();
            default:
                return NfPkVduXHwQBz::mg5qg8lzFlZ($this)->getView();
        }
        goto WdBXK;
        T_VcN:
    }
    public function getType() : string
    {
        goto f6cNr;
        kWgfj:
        PXL6e:
        goto iQmEp;
        f6cNr:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Rpcz2;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::iDfSl;
            default:
                return MediaTypeEnum::qnvOW;
        }
        goto kWgfj;
        iQmEp:
        GUXQR:
        goto h17h7;
        h17h7:
    }
    public static function createFromScratch(string $FIM0D, string $EE6bd) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $FIM0D, 'type' => $EE6bd, 'status' => J0IuL8wroLOWt::LOCAL]);
    }
}
