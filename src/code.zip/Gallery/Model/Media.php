<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-08 06:13:14              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\THrRXrYMGJt0m;
use Jfs\Uploader\Core\Q48IcpSr3UpAT;
use Jfs\Uploader\Core\D7CMsi4o836Y7;
use Jfs\Uploader\Core\Traits\OyShdbtmiDhqy;
use Jfs\Uploader\Core\M7oTJdNm24KG4;
use Jfs\Uploader\Enum\Tfi7lQDVWUJD9;
class Media extends THrRXrYMGJt0m
{
    use OyShdbtmiDhqy;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mkrWj25vS9M() : string
    {
        goto PMdew;
        W7zu4:
        vpA6_:
        goto nDNjs;
        nDNjs:
        return 'post';
        goto ldNvz;
        GM6li:
        return 'message';
        goto dDrZm;
        vWfyy:
        XGpI8:
        goto u2AmX;
        ldNvz:
        goto XGpI8;
        goto TalDK;
        dDrZm:
        goto XGpI8;
        goto dGlOs;
        I_ZLR:
        if ($this->getAttribute('shop_item_id')) {
            goto L19q_;
        }
        goto CKIlh;
        CKIlh:
        goto XGpI8;
        goto W7zu4;
        dGlOs:
        L19q_:
        goto ybIsl;
        PMdew:
        if ($this->getAttribute('post_id')) {
            goto vpA6_;
        }
        goto PvkSa;
        u2AmX:
        return 'uncategorized';
        goto mND5_;
        TalDK:
        u6cjM:
        goto GM6li;
        PvkSa:
        if ($this->getAttribute('message_id')) {
            goto u6cjM;
        }
        goto I_ZLR;
        ybIsl:
        return 'shop_item';
        goto vWfyy;
        mND5_:
    }
    public function getView() : array
    {
        goto LgbEM;
        LgbEM:
        switch ($this->getType()) {
            case 'image':
                return Q48IcpSr3UpAT::mfFzuceDwxY($this)->getView();
            case 'video':
                return M7oTJdNm24KG4::mUrJus5XMWE($this)->getView();
            default:
                return D7CMsi4o836Y7::mMS9LC6v8bH($this)->getView();
        }
        goto Hn6fI;
        N1iNK:
        p8B2y:
        goto dG8NM;
        Hn6fI:
        jdoiF:
        goto N1iNK;
        dG8NM:
    }
    public function getType() : string
    {
        goto lIEka;
        lIEka:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::a7D__;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::LzTd4;
            default:
                return MediaTypeEnum::AFqwz;
        }
        goto sCjqp;
        sCjqp:
        c0Ped:
        goto nxuf3;
        nxuf3:
        xz4VC:
        goto cSTTE;
        cSTTE:
    }
    public static function createFromScratch(string $seLPv, string $y_fdt) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $seLPv, 'type' => $y_fdt, 'status' => Tfi7lQDVWUJD9::LOCAL]);
    }
}
