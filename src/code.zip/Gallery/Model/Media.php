<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:14:20              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\VMj30iBgKeeJB;
use Jfs\Uploader\Core\QFoN7Ibbm93if;
use Jfs\Uploader\Core\GPZ0EQoHpj04q;
use Jfs\Uploader\Core\Traits\U1oUBtFUca4cm;
use Jfs\Uploader\Core\WrCq6RmnGcVh7;
use Jfs\Uploader\Enum\VNuaYSNcfVlT5;
class Media extends VMj30iBgKeeJB
{
    use U1oUBtFUca4cm;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mCdnDJFmVqx() : string
    {
        goto mP6pX;
        JJWg0:
        ohMO8:
        goto AqJr_;
        UVXU0:
        if ($this->getAttribute('shop_item_id')) {
            goto pjO8N;
        }
        goto JY2uV;
        lnWWQ:
        rsgIG:
        goto ZhGkP;
        AqJr_:
        return 'message';
        goto CQRAB;
        ZhGkP:
        return 'post';
        goto Ecbcb;
        JY2uV:
        goto ZYTjw;
        goto lnWWQ;
        CQRAB:
        goto ZYTjw;
        goto c2pnJ;
        mP6pX:
        if ($this->getAttribute('post_id')) {
            goto rsgIG;
        }
        goto OZq3y;
        wsQaF:
        return 'uncategorized';
        goto MKZEq;
        OZq3y:
        if ($this->getAttribute('message_id')) {
            goto ohMO8;
        }
        goto UVXU0;
        Ecbcb:
        goto ZYTjw;
        goto JJWg0;
        QcvbT:
        return 'shop_item';
        goto r9HSd;
        c2pnJ:
        pjO8N:
        goto QcvbT;
        r9HSd:
        ZYTjw:
        goto wsQaF;
        MKZEq:
    }
    public function getView() : array
    {
        goto fmQEH;
        fmQEH:
        switch ($this->getType()) {
            case 'image':
                return QFoN7Ibbm93if::mdge2uImzRv($this)->getView();
            case 'video':
                return WrCq6RmnGcVh7::mG7JHVfK7iz($this)->getView();
            default:
                return GPZ0EQoHpj04q::mU6lTk6bgNz($this)->getView();
        }
        goto flXa5;
        flXa5:
        mFuKM:
        goto E1WBt;
        E1WBt:
        g6lOE:
        goto BLplc;
        BLplc:
    }
    public function getType() : string
    {
        goto X7QRi;
        YjkSC:
        OvEW_:
        goto T7ss2;
        X7QRi:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::NfItF;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::L1q96;
            default:
                return MediaTypeEnum::kZoda;
        }
        goto lxb6u;
        lxb6u:
        k6BOX:
        goto YjkSC;
        T7ss2:
    }
    public static function createFromScratch(string $xRxub, string $Lmvwp) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $xRxub, 'type' => $Lmvwp, 'status' => VNuaYSNcfVlT5::LOCAL]);
    }
}
