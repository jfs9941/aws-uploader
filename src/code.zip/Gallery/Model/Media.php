<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\OXsaQ69LP2fiA;
use Jfs\Uploader\Core\IZ5shp3JHuftD;
use Jfs\Uploader\Core\UpreKuqs00udz;
use Jfs\Uploader\Core\Traits\VexK8QON1Q211;
use Jfs\Uploader\Core\VHp3UACVYl357;
use Jfs\Uploader\Enum\GoWVLKcTGnffy;
class Media extends OXsaQ69LP2fiA
{
    use VexK8QON1Q211;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function muwyo3YwTws() : string
    {
        goto VyRNt;
        yhzPQ:
        return 'message';
        goto LJyEM;
        iJXhS:
        LGVGM:
        goto W2iyK;
        JN48g:
        goto gycHv;
        goto O_dO3;
        ojh33:
        gycHv:
        goto fvUT0;
        O_dO3:
        VSEL9:
        goto HH1U0;
        HH1U0:
        return 'post';
        goto rBN_b;
        W2iyK:
        return 'shop_item';
        goto ojh33;
        fvUT0:
        return 'uncategorized';
        goto VrXHu;
        LJyEM:
        goto gycHv;
        goto iJXhS;
        UqgAh:
        if ($this->getAttribute('shop_item_id')) {
            goto LGVGM;
        }
        goto JN48g;
        VyRNt:
        if ($this->getAttribute('post_id')) {
            goto VSEL9;
        }
        goto iWhbI;
        rBN_b:
        goto gycHv;
        goto vmE59;
        iWhbI:
        if ($this->getAttribute('message_id')) {
            goto Q2Z84;
        }
        goto UqgAh;
        vmE59:
        Q2Z84:
        goto yhzPQ;
        VrXHu:
    }
    public function getView() : array
    {
        goto i3gvP;
        i3gvP:
        switch ($this->getType()) {
            case 'image':
                return IZ5shp3JHuftD::mcsCcsKbYAl($this)->getView();
            case 'video':
                return VHp3UACVYl357::mYtxpnyXtwE($this)->getView();
            default:
                return UpreKuqs00udz::m4F86YxIzdt($this)->getView();
        }
        goto uKntM;
        Zkrc3:
        Fv3n1:
        goto DlPl3;
        uKntM:
        Pn3ja:
        goto Zkrc3;
        DlPl3:
    }
    public function getType() : string
    {
        goto OxXFg;
        OxXFg:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::zoC0V;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::c0BsO;
            default:
                return MediaTypeEnum::FT0oH;
        }
        goto WsK8d;
        WsK8d:
        hTphs:
        goto No2yR;
        No2yR:
        pHF8X:
        goto L3_Bd;
        L3_Bd:
    }
    public static function createFromScratch(string $ixMzz, string $ydbmO) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $ixMzz, 'type' => $ydbmO, 'status' => GoWVLKcTGnffy::LOCAL]);
    }
}
