<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 09:00:38              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\ALaATNTmuoFHt;
use Jfs\Uploader\Core\X9YHjKrAdcfhe;
use Jfs\Uploader\Core\ZwUpr8c0hc8qN;
use Jfs\Uploader\Core\Traits\LoACaEWnJQjFu;
use Jfs\Uploader\Core\Jf5KRr8uE3t34;
use Jfs\Uploader\Enum\EzGWviwQDmAwI;
class Media extends ALaATNTmuoFHt
{
    use LoACaEWnJQjFu;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mmKJGsFHyvC() : string
    {
        goto y6SrV;
        uZBfH:
        if ($this->getAttribute('shop_item_id')) {
            goto UvqCm;
        }
        goto IvU02;
        xV8Tn:
        UvqCm:
        goto ZarIy;
        ftF8I:
        Jf0Rp:
        goto hu38g;
        hu38g:
        return 'post';
        goto NcBvb;
        y6SrV:
        if ($this->getAttribute('post_id')) {
            goto Jf0Rp;
        }
        goto kNmOO;
        ZarIy:
        return 'shop_item';
        goto pz3bc;
        IvU02:
        goto zOU2a;
        goto ftF8I;
        pz3bc:
        zOU2a:
        goto h_tPy;
        h_tPy:
        return 'uncategorized';
        goto t8O0W;
        NcBvb:
        goto zOU2a;
        goto ZoAoh;
        pjhIT:
        return 'message';
        goto x6rSn;
        ZoAoh:
        bh7Wi:
        goto pjhIT;
        x6rSn:
        goto zOU2a;
        goto xV8Tn;
        kNmOO:
        if ($this->getAttribute('message_id')) {
            goto bh7Wi;
        }
        goto uZBfH;
        t8O0W:
    }
    public function getView() : array
    {
        goto I34V9;
        I34V9:
        switch ($this->getType()) {
            case 'image':
                return X9YHjKrAdcfhe::mD9rfz3vdzZ($this)->getView();
            case 'video':
                return Jf5KRr8uE3t34::mmsjrmald2i($this)->getView();
            default:
                return ZwUpr8c0hc8qN::mCJsnDwRyRT($this)->getView();
        }
        goto OJ0rX;
        OJ0rX:
        IBOx7:
        goto T4t7U;
        T4t7U:
        V1lIJ:
        goto gpg09;
        gpg09:
    }
    public function getType() : string
    {
        goto dR1Dk;
        dR1Dk:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::xHeUx;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::vJZRD;
            default:
                return MediaTypeEnum::a9Rab;
        }
        goto NtN3_;
        NtN3_:
        eSl3e:
        goto X8V3I;
        X8V3I:
        k9Av9:
        goto HLDYu;
        HLDYu:
    }
    public static function createFromScratch(string $kftn8, string $ln7Ij) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $kftn8, 'type' => $ln7Ij, 'status' => EzGWviwQDmAwI::LOCAL]);
    }
}
