<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:34:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\TC3rpsU2GuKAE;
use Jfs\Uploader\Core\LfWCTOqty2Slr;
use Jfs\Uploader\Core\YPgQPiPQjMu1g;
use Jfs\Uploader\Core\IyqtwINobs6go;
use Jfs\Uploader\Core\Traits\Tfhsv7YHW7wn7;
use Jfs\Uploader\Core\SmhkgG6le5p0r;
use Jfs\Uploader\Enum\NYPGraEb3Ennl;
class Media extends LfWCTOqty2Slr
{
    use Tfhsv7YHW7wn7;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mVtf8jFhEs2() : string
    {
        goto GBBKg;
        iJq8F:
        goto QuCFX;
        goto yZzVj;
        GHzCr:
        gB2pB:
        goto V8duK;
        ZSsdg:
        QuCFX:
        goto HrSAC;
        n7CMK:
        goto QuCFX;
        goto SJ4j8;
        eM7cO:
        return 'message';
        goto seD9v;
        Rmci8:
        if ($this->getAttribute('shop_item_id')) {
            goto gB2pB;
        }
        goto iJq8F;
        HrSAC:
        return 'uncategorized';
        goto z2W0h;
        seD9v:
        goto QuCFX;
        goto GHzCr;
        yZzVj:
        O5XNF:
        goto fogGP;
        SJ4j8:
        cCvn_:
        goto eM7cO;
        fogGP:
        return 'post';
        goto n7CMK;
        GBBKg:
        if ($this->getAttribute('post_id')) {
            goto O5XNF;
        }
        goto jk2mF;
        jk2mF:
        if ($this->getAttribute('message_id')) {
            goto cCvn_;
        }
        goto Rmci8;
        V8duK:
        return 'shop_item';
        goto ZSsdg;
        z2W0h:
    }
    public function getView() : array
    {
        goto xeKZr;
        XRiL1:
        gUFaz:
        goto NMR6J;
        NMR6J:
        VE7O7:
        goto kSl0_;
        xeKZr:
        switch ($this->getType()) {
            case 'image':
                return YPgQPiPQjMu1g::mVqWOcOPhht($this)->getView();
            case 'video':
                return SmhkgG6le5p0r::mRyurtz0u9m($this)->getView();
            default:
                return IyqtwINobs6go::mvQeH9gl4Cm($this)->getView();
        }
        goto XRiL1;
        kSl0_:
    }
    public function getType() : string
    {
        goto fA1Q9;
        DXEVR:
        l8dE5:
        goto OA7wD;
        OA7wD:
        kKPai:
        goto ZiVSm;
        fA1Q9:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::jAEbo;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::uKd8N;
            default:
                return MediaTypeEnum::DTjdg;
        }
        goto DXEVR;
        ZiVSm:
    }
    public static function createFromScratch(string $VjmOq, string $H2Bah) : Media
    {
        return Media::fill(['id' => $VjmOq, 'type' => $H2Bah, 'status' => NYPGraEb3Ennl::LOCAL]);
    }
}
