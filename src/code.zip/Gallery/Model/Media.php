<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:20:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\OWEQTdXGAAFta;
use Jfs\Uploader\Core\UG34Yjmf7IsbQ;
use Jfs\Uploader\Core\OrjVhA5InRPZV;
use Jfs\Uploader\Core\Traits\IBoPBAZwQwRqv;
use Jfs\Uploader\Core\N1wF7eNF4lYgo;
use Jfs\Uploader\Enum\PdN71mQX1JeZG;
class Media extends OWEQTdXGAAFta
{
    use IBoPBAZwQwRqv;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mceJD67CntH() : string
    {
        goto DPGfE;
        OTuXM:
        cgz66:
        goto PAyG_;
        InNvL:
        goto cgz66;
        goto bx8Xc;
        PAyG_:
        return 'uncategorized';
        goto n_JaA;
        DPGfE:
        if ($this->getAttribute('post_id')) {
            goto Dvh7a;
        }
        goto jxlYO;
        VmkBE:
        He0Mj:
        goto alGVb;
        LAGuc:
        goto cgz66;
        goto VmkBE;
        bx8Xc:
        x1k5k:
        goto NXKG4;
        jxlYO:
        if ($this->getAttribute('message_id')) {
            goto He0Mj;
        }
        goto i4dbi;
        NXKG4:
        return 'shop_item';
        goto OTuXM;
        e8sTb:
        return 'post';
        goto LAGuc;
        alGVb:
        return 'message';
        goto InNvL;
        i4dbi:
        if ($this->getAttribute('shop_item_id')) {
            goto x1k5k;
        }
        goto vcjeQ;
        qC7eF:
        Dvh7a:
        goto e8sTb;
        vcjeQ:
        goto cgz66;
        goto qC7eF;
        n_JaA:
    }
    public function getView() : array
    {
        goto biKCe;
        biKCe:
        switch ($this->getType()) {
            case 'image':
                return UG34Yjmf7IsbQ::mm5YMwHGTZ1($this)->getView();
            case 'video':
                return N1wF7eNF4lYgo::md7edg6ZDxx($this)->getView();
            default:
                return OrjVhA5InRPZV::m7IPkw58tbj($this)->getView();
        }
        goto ipywa;
        ipywa:
        ZKhyL:
        goto R7Tyo;
        R7Tyo:
        TCK7P:
        goto Hmysc;
        Hmysc:
    }
    public function getType() : string
    {
        goto sCrpu;
        VOOXk:
        SAz8l:
        goto S8Thf;
        S8Thf:
        LD6uB:
        goto aQPK7;
        sCrpu:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::IwM1V;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::M5MoG;
            default:
                return MediaTypeEnum::UJJH0;
        }
        goto VOOXk;
        aQPK7:
    }
    public static function createFromScratch(string $eVMet, string $cJEs5) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $eVMet, 'type' => $cJEs5, 'status' => PdN71mQX1JeZG::LOCAL]);
    }
}
