<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-24 10:03:59              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\QhwgYzl056fwk;
use Jfs\Uploader\Core\UKWxL8i4Jx2NZ;
use Jfs\Uploader\Core\LGMw063tEE9ZC;
use Jfs\Uploader\Core\NGxsa4jamJSuW;
use Jfs\Uploader\Core\Traits\LQpqxojWwaLgF;
use Jfs\Uploader\Core\GXtnGiMmIPEIc;
use Jfs\Uploader\Enum\WG4kCv0INtCV4;
class Media extends UKWxL8i4Jx2NZ
{
    use LQpqxojWwaLgF;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mAduHSrfaGq() : string
    {
        goto bDf8s;
        l_Jg1:
        d_fKu:
        goto Z3yDs;
        TMk43:
        return 'uncategorized';
        goto m5xZZ;
        E0ncH:
        goto f4XvD;
        goto fLFHJ;
        yxfAg:
        return 'shop_item';
        goto SCjTf;
        xa4KZ:
        return 'message';
        goto GEDe4;
        d549q:
        goto f4XvD;
        goto l_Jg1;
        bDf8s:
        if ($this->getAttribute('post_id')) {
            goto d_fKu;
        }
        goto LkFuW;
        lpy25:
        T_20t:
        goto yxfAg;
        gJSLk:
        if ($this->getAttribute('shop_item_id')) {
            goto T_20t;
        }
        goto d549q;
        Z3yDs:
        return 'post';
        goto E0ncH;
        GEDe4:
        goto f4XvD;
        goto lpy25;
        fLFHJ:
        RMtJr:
        goto xa4KZ;
        SCjTf:
        f4XvD:
        goto TMk43;
        LkFuW:
        if ($this->getAttribute('message_id')) {
            goto RMtJr;
        }
        goto gJSLk;
        m5xZZ:
    }
    public function getView() : array
    {
        goto I8jhy;
        Arjfj:
        m8L0e:
        goto vOx8O;
        I8jhy:
        switch ($this->getType()) {
            case 'image':
                return LGMw063tEE9ZC::miCwnVnuzHF($this)->getView();
            case 'video':
                return GXtnGiMmIPEIc::mQW5oMLynde($this)->getView();
            default:
                return NGxsa4jamJSuW::mH3ykqW4cvO($this)->getView();
        }
        goto Arjfj;
        vOx8O:
        Br65R:
        goto CA7C4;
        CA7C4:
    }
    public function getType() : string
    {
        goto g_Q0H;
        Dy7lZ:
        qIy4d:
        goto qzlXP;
        eHat9:
        ePWh8:
        goto Dy7lZ;
        g_Q0H:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::apx3i;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::do3zk;
            default:
                return MediaTypeEnum::m6t9s;
        }
        goto eHat9;
        qzlXP:
    }
    public static function createFromScratch(string $ksTON, string $GXi3I) : Media
    {
        return Media::fill(['id' => $ksTON, 'type' => $GXi3I, 'status' => WG4kCv0INtCV4::LOCAL]);
    }
}
