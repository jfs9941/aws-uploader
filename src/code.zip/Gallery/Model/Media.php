<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 15:34:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\UXdXfw71iQGkx;
use Jfs\Uploader\Core\Vt3ybt0yfaPAa;
use Jfs\Uploader\Core\QWYHsUCm1wCVE;
use Jfs\Uploader\Core\Traits\L5mR6rHm99iIZ;
use Jfs\Uploader\Core\D6fOq8lm3n7T2;
use Jfs\Uploader\Enum\TpPQGsuK0gyw2;
class Media extends UXdXfw71iQGkx
{
    use L5mR6rHm99iIZ;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function msNi41rlKyX() : string
    {
        goto kwqiw;
        pT53L:
        if ($this->getAttribute('shop_item_id')) {
            goto rfQBM;
        }
        goto uXrNI;
        jEhhj:
        return 'shop_item';
        goto QrV8Q;
        QYgeU:
        goto DK1aS;
        goto lsCVB;
        lsCVB:
        XiqoM:
        goto G3A8z;
        H7kpG:
        if ($this->getAttribute('message_id')) {
            goto XiqoM;
        }
        goto pT53L;
        npQcv:
        return 'uncategorized';
        goto EIf0n;
        BdpiQ:
        Zk7vv:
        goto QxBiq;
        QrV8Q:
        DK1aS:
        goto npQcv;
        uXrNI:
        goto DK1aS;
        goto BdpiQ;
        QxBiq:
        return 'post';
        goto QYgeU;
        kwqiw:
        if ($this->getAttribute('post_id')) {
            goto Zk7vv;
        }
        goto H7kpG;
        SJCh6:
        rfQBM:
        goto jEhhj;
        G3A8z:
        return 'message';
        goto rHTOj;
        rHTOj:
        goto DK1aS;
        goto SJCh6;
        EIf0n:
    }
    public function getView() : array
    {
        goto eA3Cr;
        eA3Cr:
        switch ($this->getType()) {
            case 'image':
                return Vt3ybt0yfaPAa::m9PoKybUPwn($this)->getView();
            case 'video':
                return D6fOq8lm3n7T2::mn6id2HHGBf($this)->getView();
            default:
                return QWYHsUCm1wCVE::mi0oPfAJa4u($this)->getView();
        }
        goto DNJr7;
        DNJr7:
        KMbIU:
        goto XPg5O;
        XPg5O:
        lXN9g:
        goto iUaGn;
        iUaGn:
    }
    public function getType() : string
    {
        goto dKH90;
        bEJvK:
        TiFnv:
        goto ezAD1;
        ezAD1:
        XxYeX:
        goto C3WOC;
        dKH90:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Z9l6S;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::uTsTl;
            default:
                return MediaTypeEnum::Oqthd;
        }
        goto bEJvK;
        C3WOC:
    }
    public static function createFromScratch(string $r7rVx, string $NTkTt) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $r7rVx, 'type' => $NTkTt, 'status' => TpPQGsuK0gyw2::LOCAL]);
    }
}
