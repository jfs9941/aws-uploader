<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:26:49              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\MpZUpGr3YFIhj;
use Jfs\Uploader\Core\Dup6KVtAFNCUq;
use Jfs\Uploader\Core\McTg5Yp6FKC6z;
use Jfs\Uploader\Core\XWqfTCKHy5X8X;
use Jfs\Uploader\Core\Traits\RN8oxnSswJ42z;
use Jfs\Uploader\Core\CSQMvXC33KbbS;
use Jfs\Uploader\Enum\GrPXtp41lLmde;
class Media extends Dup6KVtAFNCUq
{
    use RN8oxnSswJ42z;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mKcvSXplPAL() : string
    {
        goto dAsbr;
        a56Do:
        if ($this->getAttribute('shop_item_id')) {
            goto edMYr;
        }
        goto V1Pn5;
        CuPDS:
        Um62t:
        goto BAuCO;
        dAsbr:
        if ($this->getAttribute('post_id')) {
            goto uMnIH;
        }
        goto ERYdi;
        IJ414:
        return 'post';
        goto hkyNi;
        VE0vk:
        edMYr:
        goto IcHM9;
        BAuCO:
        return 'message';
        goto Fdu_n;
        IcHM9:
        return 'shop_item';
        goto DswT0;
        DswT0:
        HOuuX:
        goto xCWYi;
        hkyNi:
        goto HOuuX;
        goto CuPDS;
        a0_s0:
        uMnIH:
        goto IJ414;
        V1Pn5:
        goto HOuuX;
        goto a0_s0;
        Fdu_n:
        goto HOuuX;
        goto VE0vk;
        ERYdi:
        if ($this->getAttribute('message_id')) {
            goto Um62t;
        }
        goto a56Do;
        xCWYi:
        return 'uncategorized';
        goto H0ClL;
        H0ClL:
    }
    public function getView() : array
    {
        goto ATUTy;
        ATUTy:
        switch ($this->getType()) {
            case 'image':
                return McTg5Yp6FKC6z::m4cyxOitf5I($this)->getView();
            case 'video':
                return CSQMvXC33KbbS::miWN6rba4HM($this)->getView();
            default:
                return XWqfTCKHy5X8X::m6LSnq6paa7($this)->getView();
        }
        goto Mwlim;
        Mwlim:
        SLsjw:
        goto FTzZr;
        FTzZr:
        bjdkI:
        goto r_cYj;
        r_cYj:
    }
    public function getType() : string
    {
        goto UsHcN;
        n6dgk:
        FOqV3:
        goto ybsEg;
        ybsEg:
        SRahs:
        goto ZPoQs;
        UsHcN:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::ws97f;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::I9bfM;
            default:
                return MediaTypeEnum::qCygz;
        }
        goto n6dgk;
        ZPoQs:
    }
    public static function createFromScratch(string $FeNc2, string $lfMjH) : Media
    {
        return Media::fill(['id' => $FeNc2, 'type' => $lfMjH, 'status' => GrPXtp41lLmde::LOCAL]);
    }
}
