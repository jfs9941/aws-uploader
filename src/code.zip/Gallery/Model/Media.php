<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:56:16              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\KFe2ZCctciwsA;
use Jfs\Uploader\Core\XK5kReLMTU1ob;
use Jfs\Uploader\Core\WLv4xzk21eiAP;
use Jfs\Uploader\Core\Traits\Rr9MHzXLd8EvR;
use Jfs\Uploader\Core\BG2FRpwGrKqJx;
use Jfs\Uploader\Enum\DccywYjigTakI;
class Media extends KFe2ZCctciwsA
{
    use Rr9MHzXLd8EvR;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mhkOKcaGKHd() : string
    {
        goto CO3FF;
        YQUpB:
        return 'message';
        goto Xl36x;
        O5JZr:
        goto bFWwj;
        goto IXOsR;
        iEiWN:
        if ($this->getAttribute('shop_item_id')) {
            goto nC8Td;
        }
        goto O5JZr;
        IXOsR:
        u2g7k:
        goto bbHB7;
        JWZF0:
        goto bFWwj;
        goto ADLwx;
        bbHB7:
        return 'post';
        goto JWZF0;
        Xl36x:
        goto bFWwj;
        goto u7Pk8;
        wlpGT:
        return 'shop_item';
        goto t_wZI;
        t_wZI:
        bFWwj:
        goto ldOHQ;
        ADLwx:
        oDcEM:
        goto YQUpB;
        rq1iR:
        if ($this->getAttribute('message_id')) {
            goto oDcEM;
        }
        goto iEiWN;
        ldOHQ:
        return 'uncategorized';
        goto vGX6C;
        u7Pk8:
        nC8Td:
        goto wlpGT;
        CO3FF:
        if ($this->getAttribute('post_id')) {
            goto u2g7k;
        }
        goto rq1iR;
        vGX6C:
    }
    public function getView() : array
    {
        goto rXXPW;
        rXXPW:
        switch ($this->getType()) {
            case 'image':
                return XK5kReLMTU1ob::m8dA7C2luFM($this)->getView();
            case 'video':
                return BG2FRpwGrKqJx::mTuCzzVbYKr($this)->getView();
            default:
                return WLv4xzk21eiAP::mm7gGMh6HSD($this)->getView();
        }
        goto H0ZRF;
        H0ZRF:
        it81T:
        goto cPJJ0;
        cPJJ0:
        frV7P:
        goto NlXBa;
        NlXBa:
    }
    public function getType() : string
    {
        goto NlQEu;
        gbGRY:
        bVYje:
        goto q1DRj;
        NlQEu:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::v4rDR;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::F9sHl;
            default:
                return MediaTypeEnum::ez1GX;
        }
        goto sMQyp;
        sMQyp:
        MEiOg:
        goto gbGRY;
        q1DRj:
    }
    public static function createFromScratch(string $VfJ3M, string $xY26M) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $VfJ3M, 'type' => $xY26M, 'status' => DccywYjigTakI::LOCAL]);
    }
}
