<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 04:09:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\Lx6EggVsR2j6q;
use Jfs\Uploader\Core\JOauoJMkgHWbh;
use Jfs\Uploader\Core\JmnRmflAnvBc1;
use Jfs\Uploader\Core\Traits\IdjMnkSrUQeOj;
use Jfs\Uploader\Core\O1jfuwJR340k5;
use Jfs\Uploader\Enum\Y9OZ7qWyGdhw2;
class Media extends Lx6EggVsR2j6q
{
    use IdjMnkSrUQeOj;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mhKysFIlVIg() : string
    {
        goto wvoaB;
        NjJvy:
        if ($this->getAttribute('shop_item_id')) {
            goto Fb_7Z;
        }
        goto rLxDP;
        IaKix:
        dt2rZ:
        goto ke83j;
        ke83j:
        return 'message';
        goto eRzsG;
        XlsfI:
        goto y3STi;
        goto IaKix;
        rLxDP:
        goto y3STi;
        goto wNSZN;
        pDTbR:
        return 'shop_item';
        goto OGCIS;
        ef44E:
        Fb_7Z:
        goto pDTbR;
        R2YVk:
        return 'post';
        goto XlsfI;
        wvoaB:
        if ($this->getAttribute('post_id')) {
            goto TJQul;
        }
        goto w_cYM;
        OGCIS:
        y3STi:
        goto TsDVG;
        wNSZN:
        TJQul:
        goto R2YVk;
        eRzsG:
        goto y3STi;
        goto ef44E;
        TsDVG:
        return 'uncategorized';
        goto vSFYm;
        w_cYM:
        if ($this->getAttribute('message_id')) {
            goto dt2rZ;
        }
        goto NjJvy;
        vSFYm:
    }
    public function getView() : array
    {
        goto Tzkm7;
        Tzkm7:
        switch ($this->getType()) {
            case 'image':
                return JOauoJMkgHWbh::mfj1CtQBPLH($this)->getView();
            case 'video':
                return O1jfuwJR340k5::mrrWmneCyG1($this)->getView();
            default:
                return JmnRmflAnvBc1::mdQyy3wSeZR($this)->getView();
        }
        goto yt66c;
        yt66c:
        B2wTt:
        goto JJ739;
        JJ739:
        V2jOb:
        goto qhClP;
        qhClP:
    }
    public function getType() : string
    {
        goto UPg7X;
        UPg7X:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::lR1x5;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::Ua9Xi;
            default:
                return MediaTypeEnum::Sa0P1;
        }
        goto XKbUq;
        X0Ts5:
        pVfVd:
        goto UDqxc;
        XKbUq:
        R2bdm:
        goto X0Ts5;
        UDqxc:
    }
    public static function createFromScratch(string $f_0vQ, string $Xu3VW) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $f_0vQ, 'type' => $Xu3VW, 'status' => Y9OZ7qWyGdhw2::LOCAL]);
    }
}
