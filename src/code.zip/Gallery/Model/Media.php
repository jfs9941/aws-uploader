<?php

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\PathResolverInterface;
use Jfs\Uploader\Core\BaseFileModel;
use Jfs\Uploader\Core\Image;
use Jfs\Uploader\Core\Pdf;
use Jfs\Uploader\Core\Traits\FileCreationTrait;
use Jfs\Uploader\Core\Video;
use Jfs\Uploader\Enum\FileDriver;

/**
 * @property FileDriver $driver
 * @property string $filename
 * @property string $category
 * @property string $type
 * @property MediaTypeEnum $file_type
 * @property ?string $thumbnail
 * @property ?string $thumbnail_id
 * @property boolean $approved
 */
class Media extends BaseFileModel
{
    use FileCreationTrait;

    protected $table = 'attachments';

    protected $casts = [
        'driver' => 'int',
        'id' => 'string',
        'approved' => 'boolean',
    ];

    protected $appends = ['file_type'];


    public function getCategory(): string
    {
        if ($this->getAttribute('post_id')) {
            return 'post';
        } elseif ($this->getAttribute('message_id')) {
            return 'message';
        } elseif ($this->getAttribute('shop_item_id')) {
            return 'shop_item';
        }

        return 'uncategorized';
    }

    public function getView(): array
    {
        switch ($this->getType()) {
            case 'image':
                return Image::asImage($this)->getView();
            case 'video':
                return Video::asVideo($this)->getView();
            default:
                return Pdf::asPdf($this)->getView();
        }
    }

    public function getType(): string
    {
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::VIDEO;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::IMAGE;
            default:
                return MediaTypeEnum::DOCUMENT;
        }
    }

    public static function createFromScratch(string $name, string $extension): Media
    {
        return Media::fill([
            'id' => $name,
            'type' => $extension,
            'status' => FileDriver::LOCAL,
        ]);
    }
}
