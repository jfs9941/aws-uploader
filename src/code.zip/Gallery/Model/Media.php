<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:43:58              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\AtQh9cRLX7xL8;
use Jfs\Uploader\Core\KCmQR4pvm0dT3;
use Jfs\Uploader\Core\SK0zQTH7YFzcx;
use Jfs\Uploader\Core\Traits\ICoBvKGsB4Udb;
use Jfs\Uploader\Core\UYo98bF5lKEmO;
use Jfs\Uploader\Enum\X4ZiOQdPeeHKI;
class Media extends AtQh9cRLX7xL8
{
    use ICoBvKGsB4Udb;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m7JgA67jwuR() : string
    {
        goto mAvhA;
        Jwfbh:
        bjed8:
        goto WWBov;
        PJA0y:
        if ($this->getAttribute('message_id')) {
            goto bjed8;
        }
        goto RKDt5;
        nqiCw:
        goto Yod9u;
        goto EWkPr;
        WWBov:
        return 'message';
        goto tTbSS;
        tTbSS:
        goto Yod9u;
        goto mjnbz;
        KAbr9:
        Yod9u:
        goto oyTu5;
        EWkPr:
        Nd8NW:
        goto bhm3a;
        bhm3a:
        return 'post';
        goto FXjJF;
        FXjJF:
        goto Yod9u;
        goto Jwfbh;
        mjnbz:
        itSzo:
        goto vVMGP;
        oyTu5:
        return 'uncategorized';
        goto CUKHu;
        RKDt5:
        if ($this->getAttribute('shop_item_id')) {
            goto itSzo;
        }
        goto nqiCw;
        mAvhA:
        if ($this->getAttribute('post_id')) {
            goto Nd8NW;
        }
        goto PJA0y;
        vVMGP:
        return 'shop_item';
        goto KAbr9;
        CUKHu:
    }
    public function getView() : array
    {
        goto aIO99;
        YMCfS:
        DiXao:
        goto JF1Xv;
        HITTA:
        EFZBV:
        goto YMCfS;
        aIO99:
        switch ($this->getType()) {
            case 'image':
                return KCmQR4pvm0dT3::medyb5BdGg1($this)->getView();
            case 'video':
                return UYo98bF5lKEmO::mHAl6xGHJWX($this)->getView();
            default:
                return SK0zQTH7YFzcx::mvWLcaos1oR($this)->getView();
        }
        goto HITTA;
        JF1Xv:
    }
    public function getType() : string
    {
        goto HevWB;
        HevWB:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::endMo;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::coi2Y;
            default:
                return MediaTypeEnum::oQdaQ;
        }
        goto JBt5t;
        JBt5t:
        TFWTQ:
        goto kCsdP;
        kCsdP:
        KpFb1:
        goto srg0t;
        srg0t:
    }
    public static function createFromScratch(string $e1Rlj, string $fsv41) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $e1Rlj, 'type' => $fsv41, 'status' => X4ZiOQdPeeHKI::LOCAL]);
    }
}
