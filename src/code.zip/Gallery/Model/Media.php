<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:29:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\UKSr4EAd7qrlK;
use Jfs\Uploader\Core\HJJu0xs0QACaQ;
use Jfs\Uploader\Core\NBWuSM65HseqY;
use Jfs\Uploader\Core\NvNhGXZYZ9DLW;
use Jfs\Uploader\Core\Traits\FdeEVbF7HDTyC;
use Jfs\Uploader\Core\S25BfMDKrX8cB;
use Jfs\Uploader\Enum\VCKF0xK25vLxq;
class Media extends HJJu0xs0QACaQ
{
    use FdeEVbF7HDTyC;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mnRajQiYdGO() : string
    {
        goto XVDsN;
        VxmTu:
        return 'uncategorized';
        goto D0IT9;
        B6FTG:
        return 'shop_item';
        goto u9su9;
        FhRH1:
        if ($this->getAttribute('message_id')) {
            goto bn1fY;
        }
        goto H6Swj;
        K6Yzp:
        Bg9w_:
        goto Z_EEM;
        H6Swj:
        if ($this->getAttribute('shop_item_id')) {
            goto bti3X;
        }
        goto Y31b1;
        tq_Z5:
        goto Vwry1;
        goto Kq0XP;
        u9su9:
        Vwry1:
        goto VxmTu;
        rAOk_:
        bti3X:
        goto B6FTG;
        XVDsN:
        if ($this->getAttribute('post_id')) {
            goto Bg9w_;
        }
        goto FhRH1;
        Kq0XP:
        bn1fY:
        goto hETdV;
        Y31b1:
        goto Vwry1;
        goto K6Yzp;
        PkSgl:
        goto Vwry1;
        goto rAOk_;
        Z_EEM:
        return 'post';
        goto tq_Z5;
        hETdV:
        return 'message';
        goto PkSgl;
        D0IT9:
    }
    public function getView() : array
    {
        goto oqsKk;
        buy7F:
        vY0rB:
        goto smtDF;
        smtDF:
        kWx_d:
        goto ZV_j4;
        oqsKk:
        switch ($this->getType()) {
            case 'image':
                return NBWuSM65HseqY::mWHW8Fl7CnX($this)->getView();
            case 'video':
                return S25BfMDKrX8cB::mhgdbkItnfv($this)->getView();
            default:
                return NvNhGXZYZ9DLW::mnJ8VHbQddv($this)->getView();
        }
        goto buy7F;
        ZV_j4:
    }
    public function getType() : string
    {
        goto R_BrK;
        BlEMt:
        Acjw6:
        goto gBww0;
        gBww0:
        iMJUV:
        goto v_ijp;
        R_BrK:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::MB4A3;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::eCDeH;
            default:
                return MediaTypeEnum::dsNiv;
        }
        goto BlEMt;
        v_ijp:
    }
    public static function createFromScratch(string $yU2y0, string $Vb_Cv) : Media
    {
        return Media::fill(['id' => $yU2y0, 'type' => $Vb_Cv, 'status' => VCKF0xK25vLxq::LOCAL]);
    }
}
