<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\Z3KXO9qO3sUsa;
use Jfs\Uploader\Core\VPGaYsuFJzbQ0;
use Jfs\Uploader\Core\McjNajNYCqDZl;
use Jfs\Uploader\Core\Traits\Vf8zHiJ8Htyjk;
use Jfs\Uploader\Core\SNpic2wzC1yT8;
use Jfs\Uploader\Enum\ISqBWmYzjt1eQ;
class Media extends Z3KXO9qO3sUsa
{
    use Vf8zHiJ8Htyjk;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mebw7oB0Ljz() : string
    {
        goto Sotw6;
        tvAsi:
        goto FgNhx;
        goto vnhbU;
        GAGO0:
        if ($this->getAttribute('message_id')) {
            goto RaPVF;
        }
        goto Kedb4;
        SWOp5:
        return 'uncategorized';
        goto QYJSZ;
        Sotw6:
        if ($this->getAttribute('post_id')) {
            goto y99K8;
        }
        goto GAGO0;
        SG7ww:
        FgNhx:
        goto SWOp5;
        Xqaz8:
        RaPVF:
        goto qZYCY;
        zOYju:
        yOue3:
        goto Z1f52;
        vnhbU:
        y99K8:
        goto vErk5;
        HZgUS:
        goto FgNhx;
        goto Xqaz8;
        qZYCY:
        return 'message';
        goto UNXbT;
        vErk5:
        return 'post';
        goto HZgUS;
        UNXbT:
        goto FgNhx;
        goto zOYju;
        Z1f52:
        return 'shop_item';
        goto SG7ww;
        Kedb4:
        if ($this->getAttribute('shop_item_id')) {
            goto yOue3;
        }
        goto tvAsi;
        QYJSZ:
    }
    public function getView() : array
    {
        goto HXtfe;
        HXtfe:
        switch ($this->getType()) {
            case 'image':
                return VPGaYsuFJzbQ0::m68LNHyPt4c($this)->getView();
            case 'video':
                return SNpic2wzC1yT8::mqlrnEuOYnP($this)->getView();
            default:
                return McjNajNYCqDZl::m5KKffAjngV($this)->getView();
        }
        goto KiCbK;
        KiCbK:
        fo8jC:
        goto Zr4ZQ;
        Zr4ZQ:
        ReshR:
        goto kNMOW;
        kNMOW:
    }
    public function getType() : string
    {
        goto E0wSi;
        E0wSi:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Rw7aj;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::QRQo1;
            default:
                return MediaTypeEnum::z5Lut;
        }
        goto IKCYT;
        R1m6H:
        l5RVF:
        goto Cxnbd;
        IKCYT:
        XOYYN:
        goto R1m6H;
        Cxnbd:
    }
    public static function createFromScratch(string $CGBR8, string $QPWym) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $CGBR8, 'type' => $QPWym, 'status' => ISqBWmYzjt1eQ::LOCAL]);
    }
}
