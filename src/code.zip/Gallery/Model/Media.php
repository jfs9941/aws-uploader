<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-07 12:08:41              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\Fd8NTWwq2cQOc;
use Jfs\Uploader\Core\XqAJHKYeaW2YU;
use Jfs\Uploader\Core\AvQy1eDjm0AkP;
use Jfs\Uploader\Core\Traits\Kbu3Shr02PNph;
use Jfs\Uploader\Core\JbxOPjx4A3DUY;
use Jfs\Uploader\Enum\Tq4KHV0o6oTIo;
class Media extends Fd8NTWwq2cQOc
{
    use Kbu3Shr02PNph;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mhajeXS6ibV() : string
    {
        goto Lwvin;
        WpAGU:
        goto Twn4v;
        goto AQddr;
        KJJb6:
        return 'shop_item';
        goto vDZF6;
        JaOsf:
        if ($this->getAttribute('message_id')) {
            goto uGtvG;
        }
        goto OMftv;
        AQddr:
        Mk9BA:
        goto ms8xd;
        vDZF6:
        Twn4v:
        goto P3x7A;
        gISQ6:
        lz2Xl:
        goto KJJb6;
        x7Tgz:
        uGtvG:
        goto s5sJW;
        OMftv:
        if ($this->getAttribute('shop_item_id')) {
            goto lz2Xl;
        }
        goto WpAGU;
        C8rAT:
        goto Twn4v;
        goto x7Tgz;
        Lwvin:
        if ($this->getAttribute('post_id')) {
            goto Mk9BA;
        }
        goto JaOsf;
        ms8xd:
        return 'post';
        goto C8rAT;
        n0BdV:
        goto Twn4v;
        goto gISQ6;
        P3x7A:
        return 'uncategorized';
        goto DiNYV;
        s5sJW:
        return 'message';
        goto n0BdV;
        DiNYV:
    }
    public function getView() : array
    {
        goto CbtPq;
        jVxH0:
        DYwj4:
        goto eWOh7;
        tSqg5:
        I3EEy:
        goto jVxH0;
        CbtPq:
        switch ($this->getType()) {
            case 'image':
                return XqAJHKYeaW2YU::mVexDRZured($this)->getView();
            case 'video':
                return JbxOPjx4A3DUY::mprcHbvAwf7($this)->getView();
            default:
                return AvQy1eDjm0AkP::mNjCFnOHEn6($this)->getView();
        }
        goto tSqg5;
        eWOh7:
    }
    public function getType() : string
    {
        goto R311F;
        s_hHe:
        fMQuM:
        goto wC2IQ;
        R311F:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Rv3ym;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::l0OTR;
            default:
                return MediaTypeEnum::SSPTb;
        }
        goto d_7cr;
        d_7cr:
        HQdaf:
        goto s_hHe;
        wC2IQ:
    }
    public static function createFromScratch(string $LtmUC, string $QVNFV) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $LtmUC, 'type' => $QVNFV, 'status' => Tq4KHV0o6oTIo::LOCAL]);
    }
}
