<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 09:53:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\NRDoWGrbd9WhU;
use Jfs\Uploader\Core\S7LEoIprYtLQw;
use Jfs\Uploader\Core\QJ9aA37t27inE;
use Jfs\Uploader\Core\Traits\QuukgXnznCEU4;
use Jfs\Uploader\Core\RhSx2q5xIlh0Y;
use Jfs\Uploader\Enum\Opdj0uZXaMJfa;
class Media extends NRDoWGrbd9WhU
{
    use QuukgXnznCEU4;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mFxqkzBL96V() : string
    {
        goto apl9x;
        L_Ez4:
        if ($this->getAttribute('message_id')) {
            goto qpqEf;
        }
        goto IPUkg;
        xaSp5:
        goto QgIwZ;
        goto exQKc;
        sRdIU:
        return 'post';
        goto cUQYb;
        jy29_:
        qpqEf:
        goto bX_qg;
        cUQYb:
        goto QgIwZ;
        goto jy29_;
        fudoK:
        goto QgIwZ;
        goto wWpG8;
        wWpG8:
        uSdps:
        goto rtwie;
        Ovgyd:
        QgIwZ:
        goto cSDZy;
        rtwie:
        return 'shop_item';
        goto Ovgyd;
        exQKc:
        aNrkc:
        goto sRdIU;
        apl9x:
        if ($this->getAttribute('post_id')) {
            goto aNrkc;
        }
        goto L_Ez4;
        bX_qg:
        return 'message';
        goto fudoK;
        cSDZy:
        return 'uncategorized';
        goto gK_cH;
        IPUkg:
        if ($this->getAttribute('shop_item_id')) {
            goto uSdps;
        }
        goto xaSp5;
        gK_cH:
    }
    public function getView() : array
    {
        goto w6fTi;
        kN_m2:
        DqwAN:
        goto nUPFf;
        w6fTi:
        switch ($this->getType()) {
            case 'image':
                return S7LEoIprYtLQw::mKzMM5HkJZD($this)->getView();
            case 'video':
                return RhSx2q5xIlh0Y::mua16OeAdrP($this)->getView();
            default:
                return QJ9aA37t27inE::mnch22Y6EjB($this)->getView();
        }
        goto kN_m2;
        nUPFf:
        MN6hp:
        goto CUvQo;
        CUvQo:
    }
    public function getType() : string
    {
        goto Q0Qan;
        Q0Qan:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Bmd9L;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::pITZU;
            default:
                return MediaTypeEnum::D0K3C;
        }
        goto D3WMo;
        QJXAy:
        njrQv:
        goto aQ3z1;
        D3WMo:
        WRJf3:
        goto QJXAy;
        aQ3z1:
    }
    public static function createFromScratch(string $ExhEa, string $zuSYz) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $ExhEa, 'type' => $zuSYz, 'status' => Opdj0uZXaMJfa::LOCAL]);
    }
}
