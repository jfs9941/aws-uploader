<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:43:19              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Uploader\Core\Yn8aWzKzROkno;
use Jfs\Uploader\Core\DsyQbNiy8VgJG;
use Jfs\Uploader\Core\DPPVKylVXE4k4;
use Jfs\Uploader\Core\Traits\NS3Z1m1xuUfrl;
use Jfs\Uploader\Core\ZSB2cdrwtZpmk;
use Jfs\Uploader\Enum\GTmWxMidiCuj0;
use Jfs\Gallery\Model\Enum\MediaTypeEnum;
class Media extends Yn8aWzKzROkno
{
    use NS3Z1m1xuUfrl;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mGBdLi2dQ8r() : string
    {
        goto LNrax;
        K0cD5:
        return 'message';
        goto nzGQ3;
        ou4Qp:
        AZEan:
        goto mDAE7;
        ze6mz:
        goto ZLAqo;
        goto DkwBH;
        hEDcR:
        w9HfS:
        goto K0cD5;
        JD5UZ:
        return 'uncategorized';
        goto eWszA;
        mDAE7:
        return 'shop_item';
        goto gRJYH;
        mAb0P:
        if ($this->getAttribute('shop_item_id')) {
            goto AZEan;
        }
        goto ze6mz;
        nzGQ3:
        goto ZLAqo;
        goto ou4Qp;
        gRJYH:
        ZLAqo:
        goto JD5UZ;
        LNrax:
        if ($this->getAttribute('post_id')) {
            goto VPkJ5;
        }
        goto SHGTa;
        DkwBH:
        VPkJ5:
        goto UOMtG;
        ftkkf:
        goto ZLAqo;
        goto hEDcR;
        UOMtG:
        return 'post';
        goto ftkkf;
        SHGTa:
        if ($this->getAttribute('message_id')) {
            goto w9HfS;
        }
        goto mAb0P;
        eWszA:
    }
    public function getView() : array
    {
        goto C_0Qx;
        O_YQs:
        BmfzC:
        goto v0VZd;
        v0VZd:
        xBA2R:
        goto RMmA0;
        C_0Qx:
        switch ($this->getType()) {
            case 'image':
                return DsyQbNiy8VgJG::mItue757lf8($this)->getView();
            case 'video':
                return ZSB2cdrwtZpmk::mjl467SqCuG($this)->getView();
            default:
                return DPPVKylVXE4k4::mQaSGimSztk($this)->getView();
        }
        goto O_YQs;
        RMmA0:
    }
    public function getType() : string
    {
        goto iVlUw;
        iVlUw:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::SHQYQ;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::HqCGS;
            default:
                return MediaTypeEnum::JBQNR;
        }
        goto Slxve;
        Slxve:
        l6DwH:
        goto DA8a_;
        DA8a_:
        H1S3a:
        goto XTcOM;
        XTcOM:
    }
    public static function createFromScratch(string $EtuF1, string $dwytV) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $EtuF1, 'type' => $dwytV, 'status' => GTmWxMidiCuj0::LOCAL]);
    }
}
