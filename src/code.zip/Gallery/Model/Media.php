<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:15:44              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\NCmZ7rMVMWyvC;
use Jfs\Uploader\Core\A9olNyGXhDJnA;
use Jfs\Uploader\Core\PvOVRr4EuSa8e;
use Jfs\Uploader\Core\Traits\Av20P07H9bvdh;
use Jfs\Uploader\Core\WI5WSPGRr1b2t;
use Jfs\Uploader\Enum\Pj539Ru5gyMbt;
class Media extends NCmZ7rMVMWyvC
{
    use Av20P07H9bvdh;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mjh7gUPVVnP() : string
    {
        goto Rfg09;
        QC5Qq:
        return 'uncategorized';
        goto b6kmX;
        UYB8d:
        bdYeK:
        goto QC5Qq;
        Ks7DR:
        return 'post';
        goto FDPLc;
        FDPLc:
        goto bdYeK;
        goto j2Asy;
        Yb2_3:
        if ($this->getAttribute('message_id')) {
            goto XSgA3;
        }
        goto UyyR9;
        WnLpX:
        goto bdYeK;
        goto yXbmt;
        vJmLr:
        return 'message';
        goto wklNa;
        Rfg09:
        if ($this->getAttribute('post_id')) {
            goto aQIhx;
        }
        goto Yb2_3;
        uWYzT:
        return 'shop_item';
        goto UYB8d;
        RetZz:
        n0rBl:
        goto uWYzT;
        yXbmt:
        aQIhx:
        goto Ks7DR;
        wklNa:
        goto bdYeK;
        goto RetZz;
        j2Asy:
        XSgA3:
        goto vJmLr;
        UyyR9:
        if ($this->getAttribute('shop_item_id')) {
            goto n0rBl;
        }
        goto WnLpX;
        b6kmX:
    }
    public function getView() : array
    {
        goto RyoTi;
        aUOmo:
        hW0kZ:
        goto hXzMF;
        hXzMF:
        KYahS:
        goto OoKDB;
        RyoTi:
        switch ($this->getType()) {
            case 'image':
                return A9olNyGXhDJnA::mgsK0EwCCwS($this)->getView();
            case 'video':
                return WI5WSPGRr1b2t::mQQw5D1SVlK($this)->getView();
            default:
                return PvOVRr4EuSa8e::mvzwsEX7FcR($this)->getView();
        }
        goto aUOmo;
        OoKDB:
    }
    public function getType() : string
    {
        goto WbBml;
        uu10N:
        Ktm8b:
        goto vFOVn;
        vFOVn:
        Kf_L4:
        goto UBTId;
        WbBml:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::HFNKc;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::sjJe6;
            default:
                return MediaTypeEnum::FMu1y;
        }
        goto uu10N;
        UBTId:
    }
    public static function createFromScratch(string $gQlRM, string $UEzod) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $gQlRM, 'type' => $UEzod, 'status' => Pj539Ru5gyMbt::LOCAL]);
    }
}
