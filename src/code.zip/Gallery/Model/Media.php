<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 02:40:42              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\Rqw1PJIt1YU1r;
use Jfs\Uploader\Core\WUuz09CA4woAL;
use Jfs\Uploader\Core\QzHAZxZkrX5gT;
use Jfs\Uploader\Core\Traits\EhgHLZ3CNJJzA;
use Jfs\Uploader\Core\NYx4mhlHSMgHF;
use Jfs\Uploader\Enum\YOaiWCgFM7tRK;
class Media extends Rqw1PJIt1YU1r
{
    use EhgHLZ3CNJJzA;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mSmhtXAFlgq() : string
    {
        goto cVkgP;
        KDWeg:
        XMGu6:
        goto sUAsv;
        Tma5t:
        goto lICZ0;
        goto wZxwq;
        cVkgP:
        if ($this->getAttribute('post_id')) {
            goto O2oZB;
        }
        goto YcH03;
        wZxwq:
        O2oZB:
        goto CkXt3;
        rBN71:
        return 'uncategorized';
        goto dotNm;
        CkXt3:
        return 'post';
        goto IpIvB;
        rPU23:
        XTEbi:
        goto htljy;
        LYDfC:
        goto lICZ0;
        goto rPU23;
        IpIvB:
        goto lICZ0;
        goto KDWeg;
        TRI9f:
        if ($this->getAttribute('shop_item_id')) {
            goto XTEbi;
        }
        goto Tma5t;
        htljy:
        return 'shop_item';
        goto OQJyr;
        YcH03:
        if ($this->getAttribute('message_id')) {
            goto XMGu6;
        }
        goto TRI9f;
        OQJyr:
        lICZ0:
        goto rBN71;
        sUAsv:
        return 'message';
        goto LYDfC;
        dotNm:
    }
    public function getView() : array
    {
        goto CGqC8;
        Vjl2_:
        maJok:
        goto llvaG;
        CGqC8:
        switch ($this->getType()) {
            case 'image':
                return WUuz09CA4woAL::mxZAEugLYBL($this)->getView();
            case 'video':
                return NYx4mhlHSMgHF::mMoUlTr9I2a($this)->getView();
            default:
                return QzHAZxZkrX5gT::mlVRDe31z4r($this)->getView();
        }
        goto iwyXy;
        iwyXy:
        ECzXA:
        goto Vjl2_;
        llvaG:
    }
    public function getType() : string
    {
        goto f4i_9;
        f4i_9:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::rOCTh;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::Ap17i;
            default:
                return MediaTypeEnum::NqhsB;
        }
        goto HemON;
        HemON:
        aT3Fe:
        goto R_d_g;
        R_d_g:
        hbLhu:
        goto j0icj;
        j0icj:
    }
    public static function createFromScratch(string $Xvgj6, string $xKIEz) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $Xvgj6, 'type' => $xKIEz, 'status' => YOaiWCgFM7tRK::LOCAL]);
    }
}
