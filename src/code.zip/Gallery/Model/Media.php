<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\EpIpyfdFnoTz6;
use Jfs\Uploader\Core\C6ftQJKUZRJIp;
use Jfs\Uploader\Core\UF7LVTTMiEHny;
use Jfs\Uploader\Core\Traits\CD8fs6jM2d7v1;
use Jfs\Uploader\Core\RhdJGUi8FOLBJ;
use Jfs\Uploader\Enum\CUySMhqlL7P49;
class Media extends EpIpyfdFnoTz6
{
    use CD8fs6jM2d7v1;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mPUq0sR22tx() : string
    {
        goto tbPNO;
        iCPNe:
        b70Gk:
        goto ADGc7;
        PwJhO:
        goto ShJd4;
        goto iCPNe;
        dD1dq:
        goto ShJd4;
        goto faoLT;
        uxiBH:
        if ($this->getAttribute('shop_item_id')) {
            goto rSwFv;
        }
        goto dD1dq;
        sExUP:
        goto ShJd4;
        goto VklMr;
        OUc5W:
        return 'shop_item';
        goto SGFO2;
        faoLT:
        IezGq:
        goto PGcus;
        ADGc7:
        return 'message';
        goto sExUP;
        tP0Ez:
        if ($this->getAttribute('message_id')) {
            goto b70Gk;
        }
        goto uxiBH;
        PGcus:
        return 'post';
        goto PwJhO;
        tbPNO:
        if ($this->getAttribute('post_id')) {
            goto IezGq;
        }
        goto tP0Ez;
        SGFO2:
        ShJd4:
        goto DupB2;
        VklMr:
        rSwFv:
        goto OUc5W;
        DupB2:
        return 'uncategorized';
        goto EQxuY;
        EQxuY:
    }
    public function getView() : array
    {
        goto Nhc9L;
        l7E6w:
        R4O1G:
        goto kMexR;
        kMexR:
        ibR8u:
        goto vWTZl;
        Nhc9L:
        switch ($this->getType()) {
            case 'image':
                return C6ftQJKUZRJIp::mQO65yCGuDw($this)->getView();
            case 'video':
                return RhdJGUi8FOLBJ::mRdKdX78JVs($this)->getView();
            default:
                return UF7LVTTMiEHny::mkfp0EymnNm($this)->getView();
        }
        goto l7E6w;
        vWTZl:
    }
    public function getType() : string
    {
        goto IjT50;
        YBxMI:
        eHK4_:
        goto JHRPf;
        KaHIb:
        hzJ4T:
        goto YBxMI;
        IjT50:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::VmYKH;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::IQ4BE;
            default:
                return MediaTypeEnum::Bkpa3;
        }
        goto KaHIb;
        JHRPf:
    }
    public static function createFromScratch(string $chz0R, string $T_yZW) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $chz0R, 'type' => $T_yZW, 'status' => CUySMhqlL7P49::LOCAL]);
    }
}
