<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:53:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\OavRsjNQCayKr;
use Jfs\Uploader\Core\MpPzMcfcRTISZ;
use Jfs\Uploader\Core\En8A7e3KRqXQ0;
use Jfs\Uploader\Core\Traits\G7E8tu8BtZX7c;
use Jfs\Uploader\Core\IfBHv1AJhiIDu;
use Jfs\Uploader\Enum\ZuZC67ch9j73R;
class Media extends OavRsjNQCayKr
{
    use G7E8tu8BtZX7c;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mgf9XDCjM4g() : string
    {
        goto kAbRE;
        yRPmj:
        return 'post';
        goto uSmUP;
        zjy1b:
        sH8jW:
        goto czgOL;
        IiDzV:
        goto sH8jW;
        goto o8jZf;
        kAbRE:
        if ($this->getAttribute('post_id')) {
            goto prvuX;
        }
        goto Ni1St;
        uSmUP:
        goto sH8jW;
        goto MSqzD;
        Ni1St:
        if ($this->getAttribute('message_id')) {
            goto Jh0o6;
        }
        goto B4Qn0;
        o8jZf:
        prvuX:
        goto yRPmj;
        fE6Lz:
        return 'shop_item';
        goto zjy1b;
        B4Qn0:
        if ($this->getAttribute('shop_item_id')) {
            goto h_Le8;
        }
        goto IiDzV;
        czgOL:
        return 'uncategorized';
        goto CnVRq;
        TWlGV:
        goto sH8jW;
        goto CucFq;
        MSqzD:
        Jh0o6:
        goto jXk4i;
        jXk4i:
        return 'message';
        goto TWlGV;
        CucFq:
        h_Le8:
        goto fE6Lz;
        CnVRq:
    }
    public function getView() : array
    {
        goto HqF1S;
        zQ_lu:
        EoFBm:
        goto OZIL3;
        tXHTc:
        rTlHx:
        goto zQ_lu;
        HqF1S:
        switch ($this->getType()) {
            case 'image':
                return MpPzMcfcRTISZ::msJ0kSV5JW8($this)->getView();
            case 'video':
                return IfBHv1AJhiIDu::mGQz4LugI5K($this)->getView();
            default:
                return En8A7e3KRqXQ0::mianY5Xsm9l($this)->getView();
        }
        goto tXHTc;
        OZIL3:
    }
    public function getType() : string
    {
        goto bvS3L;
        EX1gB:
        wUrOd:
        goto v3CqV;
        bvS3L:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::pX3J0;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::ZWJPU;
            default:
                return MediaTypeEnum::NnZxi;
        }
        goto kAfZT;
        kAfZT:
        x5Xvv:
        goto EX1gB;
        v3CqV:
    }
    public static function createFromScratch(string $bl6S5, string $TlRjW) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $bl6S5, 'type' => $TlRjW, 'status' => ZuZC67ch9j73R::LOCAL]);
    }
}
