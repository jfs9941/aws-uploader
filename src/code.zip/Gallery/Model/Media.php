<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:28:04              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\GpdHFYchpZHPa;
use Jfs\Uploader\Core\KfEJaEGpFJ0tm;
use Jfs\Uploader\Core\XHvEDPKBjvWLs;
use Jfs\Uploader\Core\Traits\WajBwoXLSKmXZ;
use Jfs\Uploader\Core\BtruCfJoaSWZ6;
use Jfs\Uploader\Enum\McZXbZmlQ53or;
class Media extends GpdHFYchpZHPa
{
    use WajBwoXLSKmXZ;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mqmPh5ZQOnl() : string
    {
        goto yiOvu;
        Q7lA_:
        return 'uncategorized';
        goto LFs55;
        TniH_:
        htoKA:
        goto kLPc8;
        YkU51:
        c82JH:
        goto fjdlT;
        TfeMF:
        Bz2MF:
        goto Q7lA_;
        P2K6x:
        goto Bz2MF;
        goto YkU51;
        n_yN6:
        goto Bz2MF;
        goto nVepe;
        nVepe:
        JN0PQ:
        goto T_YtI;
        fjdlT:
        return 'post';
        goto qzht3;
        yiOvu:
        if ($this->getAttribute('post_id')) {
            goto c82JH;
        }
        goto ywzRz;
        T_YtI:
        return 'shop_item';
        goto TfeMF;
        fIW51:
        if ($this->getAttribute('shop_item_id')) {
            goto JN0PQ;
        }
        goto P2K6x;
        ywzRz:
        if ($this->getAttribute('message_id')) {
            goto htoKA;
        }
        goto fIW51;
        kLPc8:
        return 'message';
        goto n_yN6;
        qzht3:
        goto Bz2MF;
        goto TniH_;
        LFs55:
    }
    public function getView() : array
    {
        goto M8A1J;
        vJJdY:
        KLtjo:
        goto EfVzS;
        EfVzS:
        jX3EP:
        goto lx3z2;
        M8A1J:
        switch ($this->getType()) {
            case 'image':
                return KfEJaEGpFJ0tm::m5QQLRAV8sj($this)->getView();
            case 'video':
                return BtruCfJoaSWZ6::m9PqKZwfJZn($this)->getView();
            default:
                return XHvEDPKBjvWLs::m6OhB7ZjjS8($this)->getView();
        }
        goto vJJdY;
        lx3z2:
    }
    public function getType() : string
    {
        goto usKJ_;
        jKFSz:
        nZu_Q:
        goto jRVhQ;
        jRVhQ:
        YIr3F:
        goto EKh0u;
        usKJ_:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::PPa6k;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::gtxWI;
            default:
                return MediaTypeEnum::jpfZC;
        }
        goto jKFSz;
        EKh0u:
    }
    public static function createFromScratch(string $F4nAe, string $WawPM) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $F4nAe, 'type' => $WawPM, 'status' => McZXbZmlQ53or::LOCAL]);
    }
}
