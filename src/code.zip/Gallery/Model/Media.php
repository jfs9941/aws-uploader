<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 11:52:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\MEyH4ejCzSk64;
use Jfs\Uploader\Core\Z7LUL65CwqbbF;
use Jfs\Uploader\Core\B1V448YMelQAT;
use Jfs\Uploader\Core\Traits\XU255kYjU0NUS;
use Jfs\Uploader\Core\MbOYV1VlUGCys;
use Jfs\Uploader\Enum\A3VATad7gvqZU;
class Media extends MEyH4ejCzSk64
{
    use XU255kYjU0NUS;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mSH51bpX1iZ() : string
    {
        goto D9DbI;
        rmafr:
        goto sPV3f;
        goto nNid5;
        lHhqZ:
        return 'message';
        goto s4Nka;
        rDNoG:
        return 'shop_item';
        goto Arf_4;
        zZ06T:
        goto sPV3f;
        goto rV8t8;
        rV8t8:
        hopfc:
        goto lHhqZ;
        uC3iN:
        if ($this->getAttribute('message_id')) {
            goto hopfc;
        }
        goto UMIX8;
        nNid5:
        drDsr:
        goto bqyr7;
        D9DbI:
        if ($this->getAttribute('post_id')) {
            goto drDsr;
        }
        goto uC3iN;
        axAox:
        i2T2v:
        goto rDNoG;
        UMIX8:
        if ($this->getAttribute('shop_item_id')) {
            goto i2T2v;
        }
        goto rmafr;
        bqyr7:
        return 'post';
        goto zZ06T;
        s4Nka:
        goto sPV3f;
        goto axAox;
        Arf_4:
        sPV3f:
        goto IbYiT;
        IbYiT:
        return 'uncategorized';
        goto Y4QiY;
        Y4QiY:
    }
    public function getView() : array
    {
        goto U9FmI;
        ONYcq:
        m2lBu:
        goto WQp0u;
        U9FmI:
        switch ($this->getType()) {
            case 'image':
                return Z7LUL65CwqbbF::m1TDGa0a0oK($this)->getView();
            case 'video':
                return MbOYV1VlUGCys::mll4R4Tup3I($this)->getView();
            default:
                return B1V448YMelQAT::mayfBcrM7kL($this)->getView();
        }
        goto o9jLS;
        o9jLS:
        XDLll:
        goto ONYcq;
        WQp0u:
    }
    public function getType() : string
    {
        goto N8Ww5;
        I741E:
        YgtYr:
        goto Veqyp;
        Veqyp:
        RwGpD:
        goto IP_At;
        N8Ww5:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::WuMuQ;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::vhB_5;
            default:
                return MediaTypeEnum::ttpPg;
        }
        goto I741E;
        IP_At:
    }
    public static function createFromScratch(string $pODrs, string $iJrca) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $pODrs, 'type' => $iJrca, 'status' => A3VATad7gvqZU::LOCAL]);
    }
}
