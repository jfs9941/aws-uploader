<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 15:53:13              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\ZOxMhYUF0fAsi;
use Jfs\Uploader\Core\DYGJpbj9Ye8wY;
use Jfs\Uploader\Core\HSe6BNUpJTSwE;
use Jfs\Uploader\Core\E2ynNzu6kpbgj;
use Jfs\Uploader\Core\Traits\OoN59oKA3bVp5;
use Jfs\Uploader\Core\QdnSnf08v9RV7;
use Jfs\Uploader\Enum\KPpxBU3Qc8yRk;
class Media extends DYGJpbj9Ye8wY
{
    use OoN59oKA3bVp5;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mPfiXqwMkgV() : string
    {
        goto Iagi_;
        xw3t9:
        goto V0r9L;
        goto awCPE;
        Jdxei:
        return 'uncategorized';
        goto t2r7k;
        VIIq8:
        if ($this->getAttribute('shop_item_id')) {
            goto FqBV4;
        }
        goto b8HG4;
        j177k:
        return 'post';
        goto Hr1Yb;
        bawzn:
        dHgfH:
        goto j177k;
        Hr1Yb:
        goto V0r9L;
        goto xUFbO;
        V050X:
        if ($this->getAttribute('message_id')) {
            goto gvyoF;
        }
        goto VIIq8;
        NQd10:
        return 'shop_item';
        goto caEZE;
        awCPE:
        FqBV4:
        goto NQd10;
        gLmzW:
        return 'message';
        goto xw3t9;
        caEZE:
        V0r9L:
        goto Jdxei;
        b8HG4:
        goto V0r9L;
        goto bawzn;
        Iagi_:
        if ($this->getAttribute('post_id')) {
            goto dHgfH;
        }
        goto V050X;
        xUFbO:
        gvyoF:
        goto gLmzW;
        t2r7k:
    }
    public function getView() : array
    {
        goto dZEWS;
        EVs4n:
        q9cn8:
        goto jZHf1;
        bo_mN:
        ETzfg:
        goto EVs4n;
        dZEWS:
        switch ($this->getType()) {
            case 'image':
                return HSe6BNUpJTSwE::mFQn0UlhghW($this)->getView();
            case 'video':
                return QdnSnf08v9RV7::m18qmlHeEfl($this)->getView();
            default:
                return E2ynNzu6kpbgj::mgsEG9NjLde($this)->getView();
        }
        goto bo_mN;
        jZHf1:
    }
    public function getType() : string
    {
        goto xv6YO;
        xv6YO:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::xA7uw;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::IBelX;
            default:
                return MediaTypeEnum::KaPJn;
        }
        goto CkAEy;
        CkAEy:
        laNqJ:
        goto IoY5T;
        IoY5T:
        MSM62:
        goto CtYA4;
        CtYA4:
    }
    public static function createFromScratch(string $IW90g, string $ffCXh) : Media
    {
        return Media::fill(['id' => $IW90g, 'type' => $ffCXh, 'status' => KPpxBU3Qc8yRk::LOCAL]);
    }
}
