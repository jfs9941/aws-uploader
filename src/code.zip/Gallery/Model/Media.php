<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:42:09              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\E97atJzeJ1gs5;
use Jfs\Uploader\Core\QfVdOZWAlX8Sl;
use Jfs\Uploader\Core\OcbNsXl9lpteB;
use Jfs\Uploader\Core\RkSRDDbIFKZE9;
use Jfs\Uploader\Core\Traits\NYNDlFOE1EB92;
use Jfs\Uploader\Core\B6s4AA1exjQ2T;
use Jfs\Uploader\Enum\R278OrMF6HCNB;
class Media extends QfVdOZWAlX8Sl
{
    use NYNDlFOE1EB92;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mDaWdBdlNb3() : string
    {
        goto E0ZKO;
        CvHi5:
        return 'message';
        goto cGyxH;
        V1YB4:
        if ($this->getAttribute('message_id')) {
            goto eeg3e;
        }
        goto XR9zH;
        B9l3Q:
        return 'uncategorized';
        goto jjps2;
        XAsGJ:
        XcKcY:
        goto ZMwci;
        ZMwci:
        return 'post';
        goto cAkFT;
        mF_2P:
        IUksd:
        goto B9l3Q;
        nA02D:
        goto IUksd;
        goto XAsGJ;
        cAkFT:
        goto IUksd;
        goto BifwX;
        BifwX:
        eeg3e:
        goto CvHi5;
        XR9zH:
        if ($this->getAttribute('shop_item_id')) {
            goto X7cpB;
        }
        goto nA02D;
        E0ZKO:
        if ($this->getAttribute('post_id')) {
            goto XcKcY;
        }
        goto V1YB4;
        cGyxH:
        goto IUksd;
        goto jdjrd;
        jdjrd:
        X7cpB:
        goto aREpT;
        aREpT:
        return 'shop_item';
        goto mF_2P;
        jjps2:
    }
    public function getView() : array
    {
        goto RLWSc;
        RLWSc:
        switch ($this->getType()) {
            case 'image':
                return OcbNsXl9lpteB::mpi4nItrxbO($this)->getView();
            case 'video':
                return B6s4AA1exjQ2T::mGVlE6RHdPz($this)->getView();
            default:
                return RkSRDDbIFKZE9::mqsl8SHPpfR($this)->getView();
        }
        goto dnLW7;
        dnLW7:
        zTfDI:
        goto cJDLv;
        cJDLv:
        fLg3i:
        goto ewCLi;
        ewCLi:
    }
    public function getType() : string
    {
        goto JOlIa;
        XVB4X:
        gn3DG:
        goto oeyw_;
        oeyw_:
        dWL46:
        goto hYgxf;
        JOlIa:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::ysFKp;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::ijhYW;
            default:
                return MediaTypeEnum::ClXBl;
        }
        goto XVB4X;
        hYgxf:
    }
    public static function createFromScratch(string $YoQzC, string $HuqsN) : Media
    {
        return Media::fill(['id' => $YoQzC, 'type' => $HuqsN, 'status' => R278OrMF6HCNB::LOCAL]);
    }
}
