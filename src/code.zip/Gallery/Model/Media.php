<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 03:50:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\F43pNWIrUhz3z;
use Jfs\Uploader\Core\IQJN6V0t7DC7c;
use Jfs\Uploader\Core\IFOKBvW1HTPmz;
use Jfs\Uploader\Core\Traits\K8rP6m5O2PpBO;
use Jfs\Uploader\Core\J7sRaWo8um3yO;
use Jfs\Uploader\Enum\KkaUVP3OQvOtp;
class Media extends F43pNWIrUhz3z
{
    use K8rP6m5O2PpBO;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function muqSPBNagqy() : string
    {
        goto FBj8K;
        akw_p:
        return 'shop_item';
        goto hFga6;
        T1muh:
        goto HO27o;
        goto IzA9N;
        f5fmU:
        goto HO27o;
        goto Wv660;
        vVN90:
        return 'message';
        goto f5fmU;
        IzA9N:
        XiC91:
        goto vVN90;
        Wv660:
        XhDdz:
        goto akw_p;
        hFga6:
        HO27o:
        goto KkfC4;
        igg28:
        return 'post';
        goto T1muh;
        OyROb:
        if ($this->getAttribute('message_id')) {
            goto XiC91;
        }
        goto edK_2;
        edK_2:
        if ($this->getAttribute('shop_item_id')) {
            goto XhDdz;
        }
        goto Pl1ky;
        Pl1ky:
        goto HO27o;
        goto sSSRc;
        sSSRc:
        AH_rz:
        goto igg28;
        FBj8K:
        if ($this->getAttribute('post_id')) {
            goto AH_rz;
        }
        goto OyROb;
        KkfC4:
        return 'uncategorized';
        goto bhvM1;
        bhvM1:
    }
    public function getView() : array
    {
        goto CQlej;
        HWnYI:
        gccEM:
        goto Ma2IW;
        tHOZ3:
        mPDPf:
        goto HWnYI;
        CQlej:
        switch ($this->getType()) {
            case 'image':
                return IQJN6V0t7DC7c::mnXEB1vIaPR($this)->getView();
            case 'video':
                return J7sRaWo8um3yO::mVtkoYTT0QM($this)->getView();
            default:
                return IFOKBvW1HTPmz::mgjpdNh3R0A($this)->getView();
        }
        goto tHOZ3;
        Ma2IW:
    }
    public function getType() : string
    {
        goto Xf3Qb;
        Xf3Qb:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::gxEpn;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::vUq2n;
            default:
                return MediaTypeEnum::JOvPi;
        }
        goto wIsQA;
        Ph1KE:
        Z7QIU:
        goto uGZWn;
        wIsQA:
        Ir73a:
        goto Ph1KE;
        uGZWn:
    }
    public static function createFromScratch(string $lrkH0, string $aCi5W) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $lrkH0, 'type' => $aCi5W, 'status' => KkaUVP3OQvOtp::LOCAL]);
    }
}
