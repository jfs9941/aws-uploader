<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 01:45:28              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Uploader\Core\O4HsadxAyKjYq;
use Jfs\Uploader\Core\Sf7MFJ2wUSx2k;
use Jfs\Uploader\Core\EW5dO98pv4IzW;
use Jfs\Uploader\Core\Traits\VxlX0xA9Oyzyn;
use Jfs\Uploader\Core\RVcEF1JsGQd8M;
use Jfs\Uploader\Enum\ZBLpZ2qUZ4P6C;
use Jfs\Gallery\Model\Enum\MediaTypeEnum;
class Media extends O4HsadxAyKjYq
{
    use VxlX0xA9Oyzyn;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mtx1jcTQGa0() : string
    {
        goto c6312;
        SGZOZ:
        if ($this->getAttribute('shop_item_id')) {
            goto Zo079;
        }
        goto aMION;
        MHPFi:
        return 'uncategorized';
        goto P4Lov;
        PNvVG:
        goto PkvgX;
        goto dy6F1;
        bnK2A:
        Zo079:
        goto qgmvC;
        c6312:
        if ($this->getAttribute('post_id')) {
            goto PCRzM;
        }
        goto kQ8Mw;
        Q3P7E:
        PCRzM:
        goto VWEOp;
        VWEOp:
        return 'post';
        goto PNvVG;
        qgmvC:
        return 'shop_item';
        goto NCAEK;
        dy6F1:
        DceJz:
        goto ECcbw;
        aMION:
        goto PkvgX;
        goto Q3P7E;
        ECcbw:
        return 'message';
        goto uY3fa;
        NCAEK:
        PkvgX:
        goto MHPFi;
        kQ8Mw:
        if ($this->getAttribute('message_id')) {
            goto DceJz;
        }
        goto SGZOZ;
        uY3fa:
        goto PkvgX;
        goto bnK2A;
        P4Lov:
    }
    public function getView() : array
    {
        goto iHVHP;
        eu0k8:
        QMBg3:
        goto x4OyI;
        dq9u3:
        mrZc5:
        goto eu0k8;
        iHVHP:
        switch ($this->getType()) {
            case 'image':
                return Sf7MFJ2wUSx2k::mtnSOrZmhmT($this)->getView();
            case 'video':
                return RVcEF1JsGQd8M::mkZPLnccwfi($this)->getView();
            default:
                return EW5dO98pv4IzW::mmCgbYaS4M0($this)->getView();
        }
        goto dq9u3;
        x4OyI:
    }
    public function getType() : string
    {
        goto JwDzm;
        YUpTx:
        uuCi5:
        goto o8FM9;
        JwDzm:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::JziBW;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::n6Cqr;
            default:
                return MediaTypeEnum::oP9vJ;
        }
        goto KSUkA;
        KSUkA:
        xFZqd:
        goto YUpTx;
        o8FM9:
    }
    public static function createFromScratch(string $KKu2U, string $FonuJ) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $KKu2U, 'type' => $FonuJ, 'status' => ZBLpZ2qUZ4P6C::LOCAL]);
    }
}
