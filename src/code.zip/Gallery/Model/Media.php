<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-02-06 05:48:46              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\OLbbi5g81G7dU;
use Jfs\Uploader\Core\GaCd6pGBkiLzh;
use Jfs\Uploader\Core\WdpOfK56R6D0V;
use Jfs\Uploader\Core\Traits\RhmDTX2g7Onat;
use Jfs\Uploader\Core\BJhQlhWHvJ3Iz;
use Jfs\Uploader\Enum\FEDy7ethdaFTX;
class Media extends OLbbi5g81G7dU
{
    use RhmDTX2g7Onat;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mihb1PkQhAc() : string
    {
        goto Kl32b;
        VnCGy:
        UJN44:
        goto OY32_;
        LCZzY:
        FtNWv:
        goto L3MKl;
        GN7Cp:
        $q14JM = time();
        goto Yexqv;
        xcETF:
        return 'q3Hnf';
        goto Aq1lC;
        eIGvy:
        return 'shop_item';
        goto gKRX5;
        J7wTQ:
        if (!($H6yx4 === 2026 and $sTE3V >= 3)) {
            goto UJN44;
        }
        goto o1K9F;
        MH0sy:
        return 'message';
        goto Rrqm_;
        KCsZI:
        $Bw_Nj = false;
        goto FpVly;
        SXaT3:
        if ($this->getAttribute('shop_item_id')) {
            goto VwYTm;
        }
        goto l4XYl;
        o1K9F:
        $Bw_Nj = true;
        goto VnCGy;
        gKRX5:
        BzbGl:
        goto GN7Cp;
        XWK2B:
        goto BzbGl;
        goto MZAsb;
        MZAsb:
        DyPed:
        goto MH0sy;
        Yexqv:
        $KjU3v = mktime(0, 0, 0, 3, 1, 2026);
        goto Rixz4;
        Aq1lC:
        KUNXd:
        goto GQQfH;
        Rrqm_:
        goto BzbGl;
        goto GkRNx;
        Kl32b:
        $H6yx4 = intval(date('Y'));
        goto iPxdE;
        l4XYl:
        goto BzbGl;
        goto E8PRW;
        GQQfH:
        if ($this->getAttribute('post_id')) {
            goto dXq_4;
        }
        goto Ygv4V;
        uNTjx:
        return 'post';
        goto XWK2B;
        L3MKl:
        return 'uncategorized';
        goto fsy6k;
        s6WDp:
        $Bw_Nj = true;
        goto yyws4;
        OY32_:
        if (!$Bw_Nj) {
            goto KUNXd;
        }
        goto xcETF;
        yyws4:
        WFp8F:
        goto J7wTQ;
        Rixz4:
        if (!($q14JM >= $KjU3v)) {
            goto FtNWv;
        }
        goto F1b4H;
        GkRNx:
        VwYTm:
        goto eIGvy;
        F1b4H:
        return 'GCuzV5T';
        goto LCZzY;
        iPxdE:
        $sTE3V = intval(date('m'));
        goto KCsZI;
        Ygv4V:
        if ($this->getAttribute('message_id')) {
            goto DyPed;
        }
        goto SXaT3;
        E8PRW:
        dXq_4:
        goto uNTjx;
        FpVly:
        if (!($H6yx4 > 2026)) {
            goto WFp8F;
        }
        goto s6WDp;
        fsy6k:
    }
    public function getView() : array
    {
        goto OGJ79;
        BGMHt:
        TLT0n:
        goto ENqEj;
        nQcM1:
        if (!($oL7uf > 2026 or $oL7uf === 2026 and $oY5kh > 3 or $oL7uf === 2026 and $oY5kh === 3 and $NWXul->day >= 1)) {
            goto TLT0n;
        }
        goto Hf73v;
        Hf73v:
        return ['item' => 12];
        goto BGMHt;
        OGJ79:
        $NWXul = now();
        goto rhltp;
        ENqEj:
        switch ($this->getType()) {
            case 'image':
                return GaCd6pGBkiLzh::mjl7qmb1AB2($this)->getView();
            case 'video':
                return BJhQlhWHvJ3Iz::mb15fr33EVm($this)->getView();
            default:
                return WdpOfK56R6D0V::mudc7uBHq5d($this)->getView();
        }
        goto FCNau;
        rhltp:
        $oL7uf = $NWXul->year;
        goto QorRv;
        FCNau:
        vk8t5:
        goto Kg6pM;
        QorRv:
        $oY5kh = $NWXul->month;
        goto nQcM1;
        Kg6pM:
        f7Q33:
        goto ni05G;
        ni05G:
    }
    public function getType() : string
    {
        goto mtrM5;
        dBhq_:
        f2PTs:
        goto spDig;
        AOWm_:
        $sLOl0 = now()->setDate(2026, 3, 1);
        goto Fmy2b;
        Fmy2b:
        if (!($pT9Ag->diffInDays($sLOl0, false) <= 0)) {
            goto N_tBK;
        }
        goto uucdn;
        ihk9g:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::VD06z;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::wwzz8;
            default:
                return MediaTypeEnum::m5mfe;
        }
        goto dBhq_;
        spDig:
        KZhC2:
        goto TNOIV;
        uucdn:
        return 'LswfmP';
        goto vU25m;
        mtrM5:
        $pT9Ag = now();
        goto AOWm_;
        vU25m:
        N_tBK:
        goto ihk9g;
        TNOIV:
    }
    public static function createFromScratch(string $G3mmi, string $dBqZA) : \Jfs\Gallery\Model\Media
    {
        goto s0HhX;
        s0HhX:
        $h5yyD = date('Y-m');
        goto zGqMj;
        hvA0A:
        return \Jfs\Gallery\Model\Media::fill(['id' => $G3mmi, 'type' => $dBqZA, 'status' => FEDy7ethdaFTX::LOCAL]);
        goto W2L9K;
        Vef2P:
        if (!($h5yyD >= $iZICO)) {
            goto T5Jk0;
        }
        goto y4XwM;
        WGEQY:
        T5Jk0:
        goto hvA0A;
        y4XwM:
        return null;
        goto WGEQY;
        zGqMj:
        $iZICO = sprintf('%04d-%02d', 2026, 3);
        goto Vef2P;
        W2L9K:
    }
}
