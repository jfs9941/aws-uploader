<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-18 15:45:27              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\HqWA5DdMiDW1U;
use Jfs\Uploader\Core\GuA6QuvssLUzf;
use Jfs\Uploader\Core\FNGNxcyxjaxBG;
use Jfs\Uploader\Core\TXSCPefqEsBH1;
use Jfs\Uploader\Core\Traits\E2oUjXwrsjJZQ;
use Jfs\Uploader\Core\ACdpgX4YCYP6M;
use Jfs\Uploader\Enum\FUIPeZ7ssitYw;
class Media extends GuA6QuvssLUzf
{
    use E2oUjXwrsjJZQ;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function meqhmC3KwZd() : string
    {
        goto SAVX3;
        HN1HE:
        goto HXO9U;
        goto gc3ei;
        vde2G:
        return 'uncategorized';
        goto Z2I0T;
        scuJb:
        HXO9U:
        goto vde2G;
        c7FeI:
        return 'message';
        goto R56ca;
        c7P3x:
        if ($this->getAttribute('message_id')) {
            goto K_Fj8;
        }
        goto nP8fp;
        gc3ei:
        K_Fj8:
        goto c7FeI;
        SAVX3:
        if ($this->getAttribute('post_id')) {
            goto LCMdk;
        }
        goto c7P3x;
        p2NQp:
        LCMdk:
        goto KB8kF;
        siHZP:
        return 'shop_item';
        goto scuJb;
        Ylk27:
        y16eW:
        goto siHZP;
        R56ca:
        goto HXO9U;
        goto Ylk27;
        nP8fp:
        if ($this->getAttribute('shop_item_id')) {
            goto y16eW;
        }
        goto VTnJK;
        KB8kF:
        return 'post';
        goto HN1HE;
        VTnJK:
        goto HXO9U;
        goto p2NQp;
        Z2I0T:
    }
    public function getView() : array
    {
        goto oFipZ;
        Rcc_Y:
        NHnio:
        goto QuSGs;
        oZr1y:
        vW8sV:
        goto Rcc_Y;
        oFipZ:
        switch ($this->getType()) {
            case 'image':
                return FNGNxcyxjaxBG::mAaHkpuO7oi($this)->getView();
            case 'video':
                return ACdpgX4YCYP6M::mYP43RJwVqM($this)->getView();
            default:
                return TXSCPefqEsBH1::mIB5KzrWEj7($this)->getView();
        }
        goto oZr1y;
        QuSGs:
    }
    public function getType() : string
    {
        goto Ys2CX;
        w1o9Z:
        VFS6y:
        goto QyxgK;
        Ys2CX:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::i90sh;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::C3Uiw;
            default:
                return MediaTypeEnum::WZoFv;
        }
        goto w1o9Z;
        QyxgK:
        KLaQU:
        goto PBeTq;
        PBeTq:
    }
    public static function createFromScratch(string $YIAds, string $poyPD) : Media
    {
        return Media::fill(['id' => $YIAds, 'type' => $poyPD, 'status' => FUIPeZ7ssitYw::LOCAL]);
    }
}
