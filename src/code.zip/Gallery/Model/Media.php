<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-05 01:28:17              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\GSmU4C9IL4AGB;
use Jfs\Uploader\Core\KyoDVfv3eGItF;
use Jfs\Uploader\Core\C1MO7dubi2ia5;
use Jfs\Uploader\Core\Traits\BgSSf3nNzBi4E;
use Jfs\Uploader\Core\AelPShnd8pMtD;
use Jfs\Uploader\Enum\Ef6Dy6MoUDei9;
class Media extends GSmU4C9IL4AGB
{
    use BgSSf3nNzBi4E;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m1Sin2BFirv() : string
    {
        goto AXe_n;
        uCFXQ:
        z04vg:
        goto wKkma;
        HYr_8:
        return 'post';
        goto lWIyn;
        u1Ew5:
        sipSk:
        goto HYr_8;
        kNuG8:
        BzHdX:
        goto IMHkG;
        Xbafe:
        return 'message';
        goto UQv3M;
        AXe_n:
        if ($this->getAttribute('post_id')) {
            goto sipSk;
        }
        goto Fpgrr;
        lWIyn:
        goto BzHdX;
        goto XbSJy;
        xbAxh:
        goto BzHdX;
        goto u1Ew5;
        XbSJy:
        csq2D:
        goto Xbafe;
        IMHkG:
        return 'uncategorized';
        goto cCqOE;
        Fpgrr:
        if ($this->getAttribute('message_id')) {
            goto csq2D;
        }
        goto YuRtc;
        wKkma:
        return 'shop_item';
        goto kNuG8;
        UQv3M:
        goto BzHdX;
        goto uCFXQ;
        YuRtc:
        if ($this->getAttribute('shop_item_id')) {
            goto z04vg;
        }
        goto xbAxh;
        cCqOE:
    }
    public function getView() : array
    {
        goto YKYwW;
        MHQaj:
        UAQ1J:
        goto aJUgj;
        aJUgj:
        xu2ra:
        goto CObzb;
        YKYwW:
        switch ($this->getType()) {
            case 'image':
                return KyoDVfv3eGItF::m3SPwGDKDky($this)->getView();
            case 'video':
                return AelPShnd8pMtD::m0gOIny6R4n($this)->getView();
            default:
                return C1MO7dubi2ia5::mgdpp7AIRiA($this)->getView();
        }
        goto MHQaj;
        CObzb:
    }
    public function getType() : string
    {
        goto OYyRu;
        OPLdw:
        eE90X:
        goto K4jRB;
        OYyRu:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::pJVzd;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::bLneX;
            default:
                return MediaTypeEnum::dr0Lo;
        }
        goto OPLdw;
        K4jRB:
        uKMzI:
        goto MGE4l;
        MGE4l:
    }
    public static function createFromScratch(string $Y1bE6, string $h4Sqa) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $Y1bE6, 'type' => $h4Sqa, 'status' => Ef6Dy6MoUDei9::LOCAL]);
    }
}
