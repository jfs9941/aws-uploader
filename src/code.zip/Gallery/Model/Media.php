<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:18:10              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\BEzZsfn3kKkr3;
use Jfs\Uploader\Core\CZj9PTf9Cv9Eq;
use Jfs\Uploader\Core\XbYF8aa0XyGnI;
use Jfs\Uploader\Core\WabYRJvOEOksh;
use Jfs\Uploader\Core\Traits\RYD8pJSplDz0G;
use Jfs\Uploader\Core\CUaMUcjkFHEwK;
use Jfs\Uploader\Enum\N0ISad2bKF2Yp;
class Media extends CZj9PTf9Cv9Eq
{
    use RYD8pJSplDz0G;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mBV3h3X3GOJ() : string
    {
        goto alxLV;
        gAApO:
        return 'shop_item';
        goto wHJcg;
        i4HE0:
        goto Ix4or;
        goto MHuht;
        pYojE:
        if ($this->getAttribute('message_id')) {
            goto Vjkr3;
        }
        goto m7AQq;
        FWN2m:
        goto Ix4or;
        goto ZOtqJ;
        wHJcg:
        Ix4or:
        goto MzWY9;
        m7AQq:
        if ($this->getAttribute('shop_item_id')) {
            goto FCVXD;
        }
        goto i4HE0;
        MHuht:
        kAM6B:
        goto sqkZk;
        ZOtqJ:
        FCVXD:
        goto gAApO;
        sqkZk:
        return 'post';
        goto xqHos;
        xqHos:
        goto Ix4or;
        goto hVWHp;
        hVWHp:
        Vjkr3:
        goto M3sgI;
        M3sgI:
        return 'message';
        goto FWN2m;
        alxLV:
        if ($this->getAttribute('post_id')) {
            goto kAM6B;
        }
        goto pYojE;
        MzWY9:
        return 'uncategorized';
        goto xt5m0;
        xt5m0:
    }
    public function getView() : array
    {
        goto BnXMd;
        KXW_8:
        Xs56L:
        goto x128j;
        BnXMd:
        switch ($this->getType()) {
            case 'image':
                return XbYF8aa0XyGnI::mExCgmTcBRJ($this)->getView();
            case 'video':
                return CUaMUcjkFHEwK::mpg6LaJ3BRK($this)->getView();
            default:
                return WabYRJvOEOksh::mIKQ6h4By9B($this)->getView();
        }
        goto KXW_8;
        x128j:
        Et3W9:
        goto PWR_8;
        PWR_8:
    }
    public function getType() : string
    {
        goto awAua;
        fgcJA:
        v9mec:
        goto dNZ_Y;
        dNZ_Y:
        aqGjg:
        goto L1WxO;
        awAua:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::NP09c;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::RUQR5;
            default:
                return MediaTypeEnum::dC45v;
        }
        goto fgcJA;
        L1WxO:
    }
    public static function createFromScratch(string $Vuk0i, string $RKAxu) : Media
    {
        return Media::fill(['id' => $Vuk0i, 'type' => $RKAxu, 'status' => N0ISad2bKF2Yp::LOCAL]);
    }
}
