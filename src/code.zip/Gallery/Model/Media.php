<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 16:43:08              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\ZZfsW9KHWsMrx;
use Jfs\Uploader\Core\FmmY71eXk0D8U;
use Jfs\Uploader\Core\DrXBch7yBj5qf;
use Jfs\Uploader\Core\Traits\LIcGrY9QpTYiX;
use Jfs\Uploader\Core\IvT3V5jT5KEaA;
use Jfs\Uploader\Enum\Rf7fPQasmK9R3;
class Media extends ZZfsW9KHWsMrx
{
    use LIcGrY9QpTYiX;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m63mOd6ICij() : string
    {
        goto XH96H;
        XH96H:
        if ($this->getAttribute('post_id')) {
            goto YoQj6;
        }
        goto ppPrW;
        fOuBc:
        jqPdG:
        goto hRjxK;
        rOOHG:
        goto h166g;
        goto fOuBc;
        hRjxK:
        return 'message';
        goto miiJL;
        aYJR6:
        return 'shop_item';
        goto O4aaF;
        nv1X_:
        u1heT:
        goto aYJR6;
        miiJL:
        goto h166g;
        goto nv1X_;
        ppPrW:
        if ($this->getAttribute('message_id')) {
            goto jqPdG;
        }
        goto GcoDi;
        KxMfz:
        goto h166g;
        goto QlU4d;
        Kmqoq:
        return 'uncategorized';
        goto nkykh;
        hrIV3:
        return 'post';
        goto rOOHG;
        O4aaF:
        h166g:
        goto Kmqoq;
        QlU4d:
        YoQj6:
        goto hrIV3;
        GcoDi:
        if ($this->getAttribute('shop_item_id')) {
            goto u1heT;
        }
        goto KxMfz;
        nkykh:
    }
    public function getView() : array
    {
        goto gaqvR;
        n864r:
        dX0Nc:
        goto iktze;
        iktze:
        fnyR3:
        goto bFRNQ;
        gaqvR:
        switch ($this->getType()) {
            case 'image':
                return FmmY71eXk0D8U::mR67ojPvI8S($this)->getView();
            case 'video':
                return IvT3V5jT5KEaA::mONJQtUC1V5($this)->getView();
            default:
                return DrXBch7yBj5qf::mz6MeDmAsBZ($this)->getView();
        }
        goto n864r;
        bFRNQ:
    }
    public function getType() : string
    {
        goto FozHJ;
        DOTIS:
        P5dQ2:
        goto vgNG2;
        kco5H:
        jfv25:
        goto DOTIS;
        FozHJ:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::f5GSA;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::jmmLJ;
            default:
                return MediaTypeEnum::uRkNt;
        }
        goto kco5H;
        vgNG2:
    }
    public static function createFromScratch(string $BeTZm, string $vQR_D) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $BeTZm, 'type' => $vQR_D, 'status' => Rf7fPQasmK9R3::LOCAL]);
    }
}
