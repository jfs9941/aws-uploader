<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 14:56:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\Yuf8dMzRcjZ21;
use Jfs\Uploader\Core\DMUaxGX7XHAI0;
use Jfs\Uploader\Core\JyZaxpharsbun;
use Jfs\Uploader\Core\SzJ0JuIDdEumD;
use Jfs\Uploader\Core\Traits\DE88el5C1yZlG;
use Jfs\Uploader\Core\Kt6NO3eUvdER6;
use Jfs\Uploader\Enum\Rc6MZhMMdyG6A;
class Media extends DMUaxGX7XHAI0
{
    use DE88el5C1yZlG;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mQMhJSGpCg5() : string
    {
        goto jP3ti;
        rsvgL:
        if ($this->getAttribute('message_id')) {
            goto uafwQ;
        }
        goto Se6LR;
        B9S_C:
        goto LZKXX;
        goto bIFf7;
        FaZcW:
        return 'post';
        goto OAXpY;
        xcr1W:
        return 'uncategorized';
        goto J6dmp;
        jP3ti:
        if ($this->getAttribute('post_id')) {
            goto F1nDp;
        }
        goto rsvgL;
        bIFf7:
        Tmw9Q:
        goto i1H05;
        q6DVJ:
        uafwQ:
        goto DVjRn;
        FwL2l:
        LZKXX:
        goto xcr1W;
        dVUSF:
        goto LZKXX;
        goto kmxOZ;
        OAXpY:
        goto LZKXX;
        goto q6DVJ;
        i1H05:
        return 'shop_item';
        goto FwL2l;
        kmxOZ:
        F1nDp:
        goto FaZcW;
        DVjRn:
        return 'message';
        goto B9S_C;
        Se6LR:
        if ($this->getAttribute('shop_item_id')) {
            goto Tmw9Q;
        }
        goto dVUSF;
        J6dmp:
    }
    public function getView() : array
    {
        goto InJke;
        pnSbG:
        PF323:
        goto oZ2yu;
        oZ2yu:
        RE3G7:
        goto HiWlV;
        InJke:
        switch ($this->getType()) {
            case 'image':
                return JyZaxpharsbun::mCzpCom7Ehj($this)->getView();
            case 'video':
                return Kt6NO3eUvdER6::my6JDcooTU0($this)->getView();
            default:
                return SzJ0JuIDdEumD::mKOaENxjk3C($this)->getView();
        }
        goto pnSbG;
        HiWlV:
    }
    public function getType() : string
    {
        goto D5WdF;
        HOjUX:
        V8O2l:
        goto nLaFb;
        mE7hc:
        EPusr:
        goto HOjUX;
        D5WdF:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::E01DK;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::FkrlF;
            default:
                return MediaTypeEnum::lX4mn;
        }
        goto mE7hc;
        nLaFb:
    }
    public static function createFromScratch(string $XKudI, string $KvyPo) : Media
    {
        return Media::fill(['id' => $XKudI, 'type' => $KvyPo, 'status' => Rc6MZhMMdyG6A::LOCAL]);
    }
}
