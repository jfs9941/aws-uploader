<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-01 03:57:55              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\HtHJXf7xellNX;
use Jfs\Uploader\Core\KZbAaRxCqNUr3;
use Jfs\Uploader\Core\NYMdb5NeWwwAT;
use Jfs\Uploader\Core\Traits\CAyWR6lPHLTW2;
use Jfs\Uploader\Core\ISYJHQo8eqdfc;
use Jfs\Uploader\Enum\L2PWLPeQEFi6U;
class Media extends HtHJXf7xellNX
{
    use CAyWR6lPHLTW2;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m0TGgkzb9xJ() : string
    {
        goto pSucy;
        l1Y2E:
        goto L_CuV;
        goto CD2wk;
        L_G5X:
        aHbdh:
        goto EBJ6J;
        KIi1z:
        return 'post';
        goto wAzbz;
        wAzbz:
        goto L_CuV;
        goto L_G5X;
        JMv0Q:
        return 'shop_item';
        goto lqkkq;
        STkcq:
        UY1YM:
        goto KIi1z;
        EBJ6J:
        return 'message';
        goto l1Y2E;
        W1b9m:
        goto L_CuV;
        goto STkcq;
        CD2wk:
        TyItz:
        goto JMv0Q;
        pSucy:
        if ($this->getAttribute('post_id')) {
            goto UY1YM;
        }
        goto uLhxj;
        SpO9L:
        if ($this->getAttribute('shop_item_id')) {
            goto TyItz;
        }
        goto W1b9m;
        lqkkq:
        L_CuV:
        goto yxTEA;
        yxTEA:
        return 'uncategorized';
        goto PqEUV;
        uLhxj:
        if ($this->getAttribute('message_id')) {
            goto aHbdh;
        }
        goto SpO9L;
        PqEUV:
    }
    public function getView() : array
    {
        goto OZQla;
        AdyiP:
        iH5SW:
        goto rnOp3;
        OZQla:
        switch ($this->getType()) {
            case 'image':
                return KZbAaRxCqNUr3::muMVvYVlXv7($this)->getView();
            case 'video':
                return ISYJHQo8eqdfc::mrZnKkTiou8($this)->getView();
            default:
                return NYMdb5NeWwwAT::mcZcdS6qP1V($this)->getView();
        }
        goto dLzPQ;
        dLzPQ:
        jmEB1:
        goto AdyiP;
        rnOp3:
    }
    public function getType() : string
    {
        goto WQLk_;
        WQLk_:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::UmRDF;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::LxQd_;
            default:
                return MediaTypeEnum::lSA07;
        }
        goto kMr4r;
        kMr4r:
        AmwrC:
        goto U_ag9;
        U_ag9:
        KUZ2m:
        goto gEig0;
        gEig0:
    }
    public static function createFromScratch(string $tbOMu, string $g88NJ) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $tbOMu, 'type' => $g88NJ, 'status' => L2PWLPeQEFi6U::LOCAL]);
    }
}
