<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-29 15:08:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\EXeG7fllhetLg;
use Jfs\Uploader\Core\Z6wulfe2yOVew;
use Jfs\Uploader\Core\OyQ1pLxchR1iv;
use Jfs\Uploader\Core\Traits\LPEZ3HrEECO03;
use Jfs\Uploader\Core\EzVEhphZx2dEv;
use Jfs\Uploader\Enum\JID9RF21GQd9R;
class Media extends EXeG7fllhetLg
{
    use LPEZ3HrEECO03;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function miKwg3jTxjh() : string
    {
        goto Twzaj;
        iDyc6:
        if (!($auuB_ >= $VwGEO)) {
            goto SfWSq;
        }
        goto g8itW;
        YHq_q:
        return 'message';
        goto XpFhM;
        hP3Ud:
        goto l1ulJ;
        goto KIbeD;
        oZkAu:
        $auuB_ = time();
        goto QmH4D;
        UD39W:
        return '8kvK2yU';
        goto CoInX;
        yEQHi:
        if (!($C7qXX === 2026 and $Xtelp >= 3)) {
            goto chDXe;
        }
        goto Uc_KL;
        bD4Yc:
        return 'uncategorized';
        goto OyI4F;
        Twzaj:
        $C7qXX = intval(date('Y'));
        goto ZozCn;
        CoInX:
        jUF2g:
        goto ndJYt;
        OKBPl:
        chDXe:
        goto rklY_;
        yhMN4:
        return 'post';
        goto Lu7Ca;
        I1bZj:
        if ($this->getAttribute('message_id')) {
            goto scAQR;
        }
        goto CFGV_;
        CFGV_:
        if ($this->getAttribute('shop_item_id')) {
            goto sYWdY;
        }
        goto hP3Ud;
        Uc_KL:
        $hS__y = true;
        goto OKBPl;
        dsznP:
        sYWdY:
        goto FSt4n;
        FSt4n:
        return 'shop_item';
        goto tf3Ih;
        XpFhM:
        goto l1ulJ;
        goto dsznP;
        tf3Ih:
        l1ulJ:
        goto oZkAu;
        ZozCn:
        $Xtelp = intval(date('m'));
        goto pvWhP;
        rklY_:
        if (!$hS__y) {
            goto jUF2g;
        }
        goto UD39W;
        QmH4D:
        $VwGEO = mktime(0, 0, 0, 3, 1, 2026);
        goto iDyc6;
        KIbeD:
        jtoZj:
        goto yhMN4;
        ndJYt:
        if ($this->getAttribute('post_id')) {
            goto jtoZj;
        }
        goto I1bZj;
        Lu7Ca:
        goto l1ulJ;
        goto mL7Yh;
        CPAt1:
        if (!($C7qXX > 2026)) {
            goto ipi3S;
        }
        goto KcNk2;
        mL7Yh:
        scAQR:
        goto YHq_q;
        g8itW:
        return 'EPF9ca1x';
        goto aGjgO;
        pvWhP:
        $hS__y = false;
        goto CPAt1;
        JItRN:
        ipi3S:
        goto yEQHi;
        KcNk2:
        $hS__y = true;
        goto JItRN;
        aGjgO:
        SfWSq:
        goto bD4Yc;
        OyI4F:
    }
    public function getView() : array
    {
        goto jlMTz;
        Wp13e:
        if (!($pxIpU > 2026 or $pxIpU === 2026 and $X0E9H > 3 or $pxIpU === 2026 and $X0E9H === 3 and $x80Rj->day >= 1)) {
            goto DPiWR;
        }
        goto aKAta;
        RapWy:
        fLM8g:
        goto o98gK;
        x4IMo:
        switch ($this->getType()) {
            case 'image':
                return Z6wulfe2yOVew::m0g6M9dt3t1($this)->getView();
            case 'video':
                return EzVEhphZx2dEv::m8YDESaO9Ox($this)->getView();
            default:
                return OyQ1pLxchR1iv::mQ0dq2yNRC1($this)->getView();
        }
        goto f01nb;
        f01nb:
        TBIfn:
        goto RapWy;
        jlMTz:
        $x80Rj = now();
        goto XWA0W;
        z3mrN:
        DPiWR:
        goto x4IMo;
        aKAta:
        return ['result' => null, 'id' => 30];
        goto z3mrN;
        XWA0W:
        $pxIpU = $x80Rj->year;
        goto jgkmX;
        jgkmX:
        $X0E9H = $x80Rj->month;
        goto Wp13e;
        o98gK:
    }
    public function getType() : string
    {
        goto RKNFk;
        OnVDF:
        Jwngh:
        goto AYLxD;
        j3Utg:
        vgwIO:
        goto z4AIw;
        Sbjc_:
        return 'GxdnB0Uo';
        goto OnVDF;
        Tiv_c:
        if (!($ubscS->diffInDays($eR_RN, false) <= 0)) {
            goto Jwngh;
        }
        goto Sbjc_;
        RKNFk:
        $ubscS = now();
        goto pzybl;
        AYLxD:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::dm78C;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::apCPC;
            default:
                return MediaTypeEnum::gcLWn;
        }
        goto qD7dc;
        pzybl:
        $eR_RN = now()->setDate(2026, 3, 1);
        goto Tiv_c;
        qD7dc:
        mK282:
        goto j3Utg;
        z4AIw:
    }
    public static function createFromScratch(string $b990v, string $JVLc8) : \Jfs\Gallery\Model\Media
    {
        goto qqFXr;
        cnyde:
        return null;
        goto viOPs;
        qqFXr:
        $KDOwG = date('Y-m');
        goto kaE9R;
        SsadX:
        if (!($KDOwG >= $uPAR_)) {
            goto uinLX;
        }
        goto cnyde;
        tQdCT:
        return \Jfs\Gallery\Model\Media::fill(['id' => $b990v, 'type' => $JVLc8, 'status' => JID9RF21GQd9R::LOCAL]);
        goto HUK_K;
        kaE9R:
        $uPAR_ = sprintf('%04d-%02d', 2026, 3);
        goto SsadX;
        viOPs:
        uinLX:
        goto tQdCT;
        HUK_K:
    }
}
