<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2026-01-04 16:20:01              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\GGOMDClEFMcsH;
use Jfs\Uploader\Core\D6FgZi8OHmjic;
use Jfs\Uploader\Core\JmK3jjuoaQvAV;
use Jfs\Uploader\Core\Traits\Lch9OtTvfn4IQ;
use Jfs\Uploader\Core\HS7SZ3rYPI80t;
use Jfs\Uploader\Enum\NZ0k4EM0XOGE7;
class Media extends GGOMDClEFMcsH
{
    use Lch9OtTvfn4IQ;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mQfTUt6rlxc() : string
    {
        goto E1cTs;
        G0thD:
        return 'shop_item';
        goto cNvAw;
        cNvAw:
        QyNGB:
        goto dQ5cH;
        yQ0cr:
        if ($this->getAttribute('shop_item_id')) {
            goto OzyG5;
        }
        goto NKzFd;
        N82Da:
        return 'post';
        goto Hw8Gk;
        v_3Ve:
        if ($this->getAttribute('message_id')) {
            goto JN2CH;
        }
        goto yQ0cr;
        WPd00:
        goto QyNGB;
        goto Av1jI;
        NKzFd:
        goto QyNGB;
        goto TpRTd;
        dQ5cH:
        return 'uncategorized';
        goto m7Bpx;
        ZPjIz:
        return 'message';
        goto WPd00;
        TpRTd:
        wCsdq:
        goto N82Da;
        CTVH5:
        JN2CH:
        goto ZPjIz;
        Hw8Gk:
        goto QyNGB;
        goto CTVH5;
        E1cTs:
        if ($this->getAttribute('post_id')) {
            goto wCsdq;
        }
        goto v_3Ve;
        Av1jI:
        OzyG5:
        goto G0thD;
        m7Bpx:
    }
    public function getView() : array
    {
        goto UC0nP;
        bu829:
        ld7Za:
        goto E0HEw;
        UC0nP:
        switch ($this->getType()) {
            case 'image':
                return D6FgZi8OHmjic::mJOovyh4SEi($this)->getView();
            case 'video':
                return HS7SZ3rYPI80t::mW3R7ViluAh($this)->getView();
            default:
                return JmK3jjuoaQvAV::myotmt8557e($this)->getView();
        }
        goto bu829;
        E0HEw:
        OGIZj:
        goto XYWbS;
        XYWbS:
    }
    public function getType() : string
    {
        goto V0InK;
        V0InK:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::h9ILD;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::NJJt2;
            default:
                return MediaTypeEnum::Eo1aU;
        }
        goto RhIbz;
        RhIbz:
        eAvT4:
        goto DyTUs;
        DyTUs:
        zMFBl:
        goto zb7xy;
        zb7xy:
    }
    public static function createFromScratch(string $eNeio, string $QGmwG) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $eNeio, 'type' => $QGmwG, 'status' => NZ0k4EM0XOGE7::LOCAL]);
    }
}
