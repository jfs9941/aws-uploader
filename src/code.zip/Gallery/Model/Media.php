<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-25 15:04:24              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Contracts\ECHrJsgxCR7OQ;
use Jfs\Uploader\Core\ZujQPL2bQTbeI;
use Jfs\Uploader\Core\Kx3NMUJqFpl5Q;
use Jfs\Uploader\Core\YuLJNLBqHeeZR;
use Jfs\Uploader\Core\Traits\SMO7C4a5P3uK2;
use Jfs\Uploader\Core\G4MP13yRAmltw;
use Jfs\Uploader\Enum\FW54oEnFetVYj;
class Media extends ZujQPL2bQTbeI
{
    use SMO7C4a5P3uK2;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function msrpG9cBSxf() : string
    {
        goto uunJx;
        Sj2pB:
        SpA3D:
        goto joxkL;
        tMBcu:
        goto HoNAv;
        goto pboUx;
        sj6ml:
        nq9mJ:
        goto Ti5Jn;
        BwvUL:
        return 'uncategorized';
        goto GjCk6;
        lmHb0:
        goto HoNAv;
        goto sj6ml;
        hTEn0:
        if ($this->getAttribute('shop_item_id')) {
            goto SpA3D;
        }
        goto lmHb0;
        AUCMD:
        return 'message';
        goto lAVkm;
        uFCeq:
        if ($this->getAttribute('message_id')) {
            goto b9QNh;
        }
        goto hTEn0;
        uunJx:
        if ($this->getAttribute('post_id')) {
            goto nq9mJ;
        }
        goto uFCeq;
        Ti5Jn:
        return 'post';
        goto tMBcu;
        zCLR9:
        HoNAv:
        goto BwvUL;
        joxkL:
        return 'shop_item';
        goto zCLR9;
        lAVkm:
        goto HoNAv;
        goto Sj2pB;
        pboUx:
        b9QNh:
        goto AUCMD;
        GjCk6:
    }
    public function getView() : array
    {
        goto QJSOp;
        kjlSG:
        N_S7i:
        goto Kk8Ch;
        QJSOp:
        switch ($this->getType()) {
            case 'image':
                return Kx3NMUJqFpl5Q::mYJzrtoXl6R($this)->getView();
            case 'video':
                return G4MP13yRAmltw::mLedFBDOv04($this)->getView();
            default:
                return YuLJNLBqHeeZR::mLHyNmOdf7w($this)->getView();
        }
        goto kjlSG;
        Kk8Ch:
        VNu1V:
        goto Sl4TW;
        Sl4TW:
    }
    public function getType() : string
    {
        goto Zrlmw;
        Zrlmw:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::wvBcp;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::yrWML;
            default:
                return MediaTypeEnum::uOqA0;
        }
        goto FynT6;
        neQOE:
        zczFr:
        goto V6oKq;
        FynT6:
        RMpEf:
        goto neQOE;
        V6oKq:
    }
    public static function createFromScratch(string $o6Bjc, string $sJ7MD) : Media
    {
        return Media::fill(['id' => $o6Bjc, 'type' => $sJ7MD, 'status' => FW54oEnFetVYj::LOCAL]);
    }
}
