<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-29 10:09:50              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\UfttW7MErNAIK;
use Jfs\Uploader\Core\U0IzvN2kaLZHI;
use Jfs\Uploader\Core\CuvWXGDQ9mxt7;
use Jfs\Uploader\Core\Traits\SyABBXn5GOmzX;
use Jfs\Uploader\Core\CpeNYzI7e1ALA;
use Jfs\Uploader\Enum\LrHrisEWQ9E5o;
class Media extends UfttW7MErNAIK
{
    use SyABBXn5GOmzX;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mqzNHtxzGi8() : string
    {
        goto V1W5Z;
        q_Jwc:
        goto DS5F2;
        goto Cq6P9;
        FvTlp:
        JMrpP:
        goto LoOP7;
        tth2g:
        if ($this->getAttribute('shop_item_id')) {
            goto JMrpP;
        }
        goto q_Jwc;
        Cq6P9:
        beVTj:
        goto RjR43;
        AfjcJ:
        if ($this->getAttribute('message_id')) {
            goto niZQi;
        }
        goto tth2g;
        wlQCB:
        niZQi:
        goto pBan2;
        kAFh1:
        return 'uncategorized';
        goto ZD4K5;
        V1W5Z:
        if ($this->getAttribute('post_id')) {
            goto beVTj;
        }
        goto AfjcJ;
        Lej9g:
        DS5F2:
        goto kAFh1;
        RjR43:
        return 'post';
        goto heF21;
        KnMFx:
        goto DS5F2;
        goto FvTlp;
        pBan2:
        return 'message';
        goto KnMFx;
        LoOP7:
        return 'shop_item';
        goto Lej9g;
        heF21:
        goto DS5F2;
        goto wlQCB;
        ZD4K5:
    }
    public function getView() : array
    {
        goto nRVz6;
        nRVz6:
        switch ($this->getType()) {
            case 'image':
                return U0IzvN2kaLZHI::m73RU6tUJOs($this)->getView();
            case 'video':
                return CpeNYzI7e1ALA::mFWpAxV5AAs($this)->getView();
            default:
                return CuvWXGDQ9mxt7::muKXA0L3dlh($this)->getView();
        }
        goto wZmh4;
        NUZOO:
        LFN98:
        goto nd2XN;
        wZmh4:
        WKa6i:
        goto NUZOO;
        nd2XN:
    }
    public function getType() : string
    {
        goto JhwOV;
        JhwOV:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::Z4nX1;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::IdHV8;
            default:
                return MediaTypeEnum::NJ46x;
        }
        goto fKY52;
        fKY52:
        EkJMD:
        goto HfZRf;
        HfZRf:
        a0qYB:
        goto HPjDI;
        HPjDI:
    }
    public static function createFromScratch(string $g6MG9, string $Cm600) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $g6MG9, 'type' => $Cm600, 'status' => LrHrisEWQ9E5o::LOCAL]);
    }
}
