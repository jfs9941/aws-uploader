<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 08:59:15              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\MediaTypeEnum;
use Jfs\Uploader\Core\MIyg7KY6jn9L1;
use Jfs\Uploader\Core\JMa7GBaLcnq3D;
use Jfs\Uploader\Core\XpjbCMtbhbQNm;
use Jfs\Uploader\Core\Traits\Ek8Ahis6odNzI;
use Jfs\Uploader\Core\VPegVN4NByLqJ;
use Jfs\Uploader\Enum\I5kpK7wkbRQvu;
class Media extends MIyg7KY6jn9L1
{
    use Ek8Ahis6odNzI;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mKHNRIN5Fll() : string
    {
        goto eP0cx;
        CGk3U:
        zy75X:
        goto SIt3c;
        wPQnn:
        VyeSE:
        goto LlNtN;
        SIt3c:
        return 'uncategorized';
        goto nJzcQ;
        qKWXy:
        aYCXA:
        goto KuP9o;
        AAdOk:
        return 'post';
        goto uUZOM;
        KuP9o:
        return 'shop_item';
        goto CGk3U;
        eP0cx:
        if ($this->getAttribute('post_id')) {
            goto DWJ2s;
        }
        goto S02j0;
        SwRhC:
        DWJ2s:
        goto AAdOk;
        b1IpS:
        goto zy75X;
        goto SwRhC;
        Y2wn5:
        goto zy75X;
        goto qKWXy;
        S02j0:
        if ($this->getAttribute('message_id')) {
            goto VyeSE;
        }
        goto rl2wF;
        LlNtN:
        return 'message';
        goto Y2wn5;
        rl2wF:
        if ($this->getAttribute('shop_item_id')) {
            goto aYCXA;
        }
        goto b1IpS;
        uUZOM:
        goto zy75X;
        goto wPQnn;
        nJzcQ:
    }
    public function getView() : array
    {
        goto MaIkd;
        MaIkd:
        switch ($this->getType()) {
            case 'image':
                return JMa7GBaLcnq3D::mX44CNdBU9d($this)->getView();
            case 'video':
                return VPegVN4NByLqJ::mBXl913uoSe($this)->getView();
            default:
                return XpjbCMtbhbQNm::mNrRjIAanK0($this)->getView();
        }
        goto q86xJ;
        q86xJ:
        Xnhhk:
        goto pa3ao;
        pa3ao:
        i_4d8:
        goto ZvCTg;
        ZvCTg:
    }
    public function getType() : string
    {
        goto bmapR;
        H3dLl:
        ZpeJX:
        goto I3pr7;
        bmapR:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return MediaTypeEnum::ZbIhi;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return MediaTypeEnum::IzPpd;
            default:
                return MediaTypeEnum::zbbp5;
        }
        goto BXHI5;
        BXHI5:
        FLcfY:
        goto H3dLl;
        I3pr7:
    }
    public static function createFromScratch(string $YJReg, string $bE8Rq) : \Jfs\Gallery\Model\Media
    {
        return \Jfs\Gallery\Model\Media::fill(['id' => $YJReg, 'type' => $bE8Rq, 'status' => I5kpK7wkbRQvu::LOCAL]);
    }
}
