<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Model;

use src\Gallery\Model\Enum\Xnz6lOV7VbgSI;
use src\Uploader\Contracts\MGwfEiRGIYlUs;
use src\Uploader\Core\GoopVn9iYwlO0;
use src\Uploader\Core\ID6EZw1DKfqu4;
use src\Uploader\Core\Traits\GGdwEU4dd3qMI;
use src\Uploader\Core\TvpGfrAj9WMXE;
use src\Uploader\Core\YdClVYDRbSDMR;
use src\Uploader\Enum\FileDriver;
class QDkSZEWiaABWN extends TvpGfrAj9WMXE
{
    use GGdwEU4dd3qMI;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function m9pAB57LEKq() : string
    {
        goto or0dK;
        W8jCb:
        return 'post';
        goto Dp_7x;
        m17zL:
        if ($this->getAttribute('message_id')) {
            goto ZQ57z;
        }
        goto Eaio2;
        LKUkn:
        return 'message';
        goto fdwKn;
        Zi2EV:
        return 'shop_item';
        goto jCLLH;
        Dp_7x:
        goto C9458;
        goto YJ1Fp;
        dXtSD:
        goto C9458;
        goto iJE7Q;
        YJ1Fp:
        ZQ57z:
        goto LKUkn;
        jCLLH:
        C9458:
        goto rV9LW;
        SckvQ:
        BF0FJ:
        goto Zi2EV;
        or0dK:
        if ($this->getAttribute('post_id')) {
            goto hsJwD;
        }
        goto m17zL;
        Eaio2:
        if ($this->getAttribute('shop_item_id')) {
            goto BF0FJ;
        }
        goto dXtSD;
        fdwKn:
        goto C9458;
        goto SckvQ;
        rV9LW:
        return 'uncategorized';
        goto Bu28t;
        iJE7Q:
        hsJwD:
        goto W8jCb;
        Bu28t:
    }
    public function getView() : array
    {
        goto otBYr;
        TXVRe:
        R14UL:
        goto gxjsS;
        otBYr:
        switch ($this->getType()) {
            case 'image':
                return ID6EZw1DKfqu4::mSbsYBP2c9C($this)->getView();
            case 'video':
                return YdClVYDRbSDMR::m9suzflhhQ7($this)->getView();
            default:
                return GoopVn9iYwlO0::mkMxaw28x1V($this)->getView();
        }
        goto TXVRe;
        gxjsS:
        VBCOq:
        goto CToRz;
        CToRz:
    }
    public function getType() : string
    {
        goto hWyzb;
        hWyzb:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return Xnz6lOV7VbgSI::c4oY3;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return Xnz6lOV7VbgSI::zyURJ;
            default:
                return Xnz6lOV7VbgSI::UWWs5;
        }
        goto rKNMk;
        gM4Ro:
        qqlLi:
        goto jjtHM;
        rKNMk:
        CcbXv:
        goto gM4Ro;
        jjtHM:
    }
    public static function createFromScratch(string $rHgUV, string $cvjX2) : QDkSZEWiaABWN
    {
        return QDkSZEWiaABWN::fill(['id' => $rHgUV, 'type' => $cvjX2, 'status' => FileDriver::LOCAL]);
    }
}
