<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Jfs\Gallery\Model\Enum\GNpRKk9LZahTX;
class LmRGiyUYHPggD extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(Zcsux86vedhuJ::class, 'id', 'id');
    }
    public static function mbX6JECC7bs(Zcsux86vedhuJ $p2x5d, $HSXbC = GNpRKk9LZahTX::cZBFX) : void
    {
        goto yeRAb;
        yeRAb:
        if (!LmRGiyUYHPggD::find($p2x5d->id)) {
            goto juFIn;
        }
        goto j03U_;
        WV3T8:
        $g5N3U->save();
        goto Jmsaq;
        j03U_:
        return;
        goto naQXM;
        drYfX:
        $g5N3U->fill(['id' => $p2x5d->getAttribute('id'), 'user_id' => $p2x5d->getAttribute('user_id') ?? auth()->user()->id, 'status' => $HSXbC, 'type' => $p2x5d->getType(), 'is_post' => $p2x5d->getAttribute('post_id') ? 1 : 0, 'is_message' => $p2x5d->getAttribute('message_id') ? 1 : 0, 'is_shop' => $p2x5d->getAttribute('shop_item_id') ? 1 : 0]);
        goto WV3T8;
        naQXM:
        juFIn:
        goto mtFfy;
        mtFfy:
        $g5N3U = new LmRGiyUYHPggD();
        goto drYfX;
        Jmsaq:
    }
}
