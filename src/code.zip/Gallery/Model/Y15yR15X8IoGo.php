<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Model;

use backup\Gallery\Model\Enum\RCVW1TQsWPapp;
use backup\Gallery\Model\QyxVvo5lhAzix;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
class Y15yR15X8IoGo extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(QyxVvo5lhAzix::class, 'id', 'id');
    }
    public function getMedia()
    {
        return $this->media;
    }
    public static function m4j2jBBSzIs(QyxVvo5lhAzix $tFHv6, $Zw7ek = RCVW1TQsWPapp::vI1BO) : void
    {
        goto xuk0t;
        UVk8j:
        DtRdM:
        goto n9q91;
        SGqbz:
        $s9mwQ->fill(['id' => $tFHv6->getAttribute('id'), 'user_id' => $tFHv6->getAttribute('user_id') ?? auth()->user()->id, 'status' => $Zw7ek, 'type' => $tFHv6->getType(), 'is_post' => $tFHv6->getAttribute('post_id') ? 1 : 0, 'is_message' => $tFHv6->getAttribute('message_id') ? 1 : 0, 'is_shop' => $tFHv6->getAttribute('shop_item_id') ? 1 : 0]);
        goto h1g1j;
        h1g1j:
        $s9mwQ->save();
        goto oqRKE;
        piqZM:
        return;
        goto UVk8j;
        n9q91:
        $s9mwQ = new Y15yR15X8IoGo();
        goto SGqbz;
        xuk0t:
        if (!Y15yR15X8IoGo::find($tFHv6->id)) {
            goto DtRdM;
        }
        goto piqZM;
        oqRKE:
    }
}
