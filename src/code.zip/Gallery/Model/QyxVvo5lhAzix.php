<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Model;

use backup\Gallery\Model\Enum\QsEwWxf0Uttny;
use backup\Uploader\Core\PJqa0Yy2jwBHe;
use backup\Uploader\Core\CrEYqpC23XUGo;
use backup\Uploader\Core\OzgWWRogA2eJF;
use backup\Uploader\Core\Traits\A6wERosUOJgWZ;
use backup\Uploader\Core\AvisbyD0IE5xq;
use backup\Uploader\Enum\XmcIS8CQn72i3;
class QyxVvo5lhAzix extends PJqa0Yy2jwBHe
{
    use A6wERosUOJgWZ;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mGJlKRn27Kw() : string
    {
        goto gH365;
        kiw4q:
        return 'post';
        goto XM14A;
        KyBHj:
        goto ZGTGw;
        goto RFs0l;
        i1PBz:
        HkulG:
        goto tP8VU;
        czJNs:
        if ($this->getAttribute('shop_item_id')) {
            goto HkulG;
        }
        goto KyBHj;
        gH365:
        if ($this->getAttribute('post_id')) {
            goto N05H_;
        }
        goto h1kDh;
        QvP5X:
        return 'uncategorized';
        goto OIeHz;
        XM14A:
        goto ZGTGw;
        goto gpOdw;
        glrIS:
        goto ZGTGw;
        goto i1PBz;
        pNyWJ:
        ZGTGw:
        goto QvP5X;
        RFs0l:
        N05H_:
        goto kiw4q;
        tP8VU:
        return 'shop_item';
        goto pNyWJ;
        YQRmQ:
        return 'message';
        goto glrIS;
        h1kDh:
        if ($this->getAttribute('message_id')) {
            goto DKOn8;
        }
        goto czJNs;
        gpOdw:
        DKOn8:
        goto YQRmQ;
        OIeHz:
    }
    public function getView() : array
    {
        goto Xc3DS;
        Xc3DS:
        switch ($this->getType()) {
            case 'image':
                return CrEYqpC23XUGo::mFbCs9BPJ4Y($this)->getView();
            case 'video':
                return AvisbyD0IE5xq::mfV15QbPTt4($this)->getView();
            default:
                return OzgWWRogA2eJF::mqoxxfip02F($this)->getView();
        }
        goto YnWaN;
        iFqI8:
        ovDs4:
        goto SxXtb;
        YnWaN:
        MifIT:
        goto iFqI8;
        SxXtb:
    }
    public function getType() : string
    {
        goto vSxCi;
        f5mS2:
        lTF3f:
        goto jJQXS;
        d2CM1:
        cPZDI:
        goto f5mS2;
        vSxCi:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return QsEwWxf0Uttny::gTRA9;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return QsEwWxf0Uttny::FThv5;
            default:
                return QsEwWxf0Uttny::OFB1g;
        }
        goto d2CM1;
        jJQXS:
    }
    public static function createFromScratch(string $IMDKn, string $ISfDH) : \Jfs\Gallery\Model\QyxVvo5lhAzix
    {
        return \Jfs\Gallery\Model\QyxVvo5lhAzix::fill(['id' => $IMDKn, 'type' => $ISfDH, 'status' => XmcIS8CQn72i3::LOCAL]);
    }
}
