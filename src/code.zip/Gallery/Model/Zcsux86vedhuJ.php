<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Model;

use Jfs\Gallery\Model\Enum\WNw9m1E4GzcGo;
use Jfs\Uploader\Contracts\LlbXoUBShkgwJ;
use Jfs\Uploader\Core\MXbLxov2QPqm4;
use Jfs\Uploader\Core\WKX0l52zWptlF;
use Jfs\Uploader\Core\JUuiYtFOGewFF;
use Jfs\Uploader\Core\Traits\CHvTVfEcdTEOe;
use Jfs\Uploader\Core\UMeQT1ArE1U05;
use Jfs\Uploader\Enum\I2Tze5VZcqaXS;
class Zcsux86vedhuJ extends MXbLxov2QPqm4
{
    use CHvTVfEcdTEOe;
    protected $table = 'attachments';
    protected $casts = ['driver' => 'int', 'id' => 'string', 'approved' => 'boolean'];
    protected $appends = ['file_type'];
    public function mdQRjyErdQ7() : string
    {
        goto dJ0t9;
        umYPI:
        if ($this->getAttribute('message_id')) {
            goto OaVxW;
        }
        goto mnMlP;
        p114u:
        goto qqez2;
        goto v5iDO;
        dJ0t9:
        if ($this->getAttribute('post_id')) {
            goto xK_TE;
        }
        goto umYPI;
        G1mQr:
        xK_TE:
        goto lTZ8j;
        b_Gql:
        qqez2:
        goto chvqX;
        chvqX:
        return 'uncategorized';
        goto MWboZ;
        mnMlP:
        if ($this->getAttribute('shop_item_id')) {
            goto COXwe;
        }
        goto mdDqq;
        UD1Ai:
        goto qqez2;
        goto qEXXX;
        y7mEq:
        return 'message';
        goto UD1Ai;
        qEXXX:
        COXwe:
        goto ufF1X;
        mdDqq:
        goto qqez2;
        goto G1mQr;
        ufF1X:
        return 'shop_item';
        goto b_Gql;
        v5iDO:
        OaVxW:
        goto y7mEq;
        lTZ8j:
        return 'post';
        goto p114u;
        MWboZ:
    }
    public function getView() : array
    {
        goto R_Tg5;
        CvlgD:
        gY2lX:
        goto vXHXh;
        DYJTw:
        sxHPK:
        goto CvlgD;
        R_Tg5:
        switch ($this->getType()) {
            case 'image':
                return WKX0l52zWptlF::mpheudTHtML($this)->getView();
            case 'video':
                return UMeQT1ArE1U05::mUJPTOTgdD6($this)->getView();
            default:
                return JUuiYtFOGewFF::meW9yO1uQcc($this)->getView();
        }
        goto DYJTw;
        vXHXh:
    }
    public function getType() : string
    {
        goto DJL6k;
        k5SXI:
        DpP1o:
        goto K32DQ;
        n_xLs:
        Xerwp:
        goto k5SXI;
        DJL6k:
        switch ($this->getAttribute('type')) {
            case 'mp4':
            case 'mov':
                return WNw9m1E4GzcGo::gJGUE;
            case 'jpg':
            case 'jpeg':
            case 'png':
            case 'gif':
            case 'webm':
            case 'heic':
                return WNw9m1E4GzcGo::GoReM;
            default:
                return WNw9m1E4GzcGo::VZ0Ct;
        }
        goto n_xLs;
        K32DQ:
    }
    public static function createFromScratch(string $DQgCT, string $rG_ni) : Zcsux86vedhuJ
    {
        return Zcsux86vedhuJ::fill(['id' => $DQgCT, 'type' => $rG_ni, 'status' => I2Tze5VZcqaXS::LOCAL]);
    }
}
