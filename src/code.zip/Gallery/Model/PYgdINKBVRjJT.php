<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:12:39              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace src\Gallery\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use src\Gallery\Model\Enum\K58fmXwYJHkrL;
use src\Gallery\Model\QDkSZEWiaABWN;
class PYgdINKBVRjJT extends Model
{
    protected $table = 'cloud';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $fillable = ['id', 'user_id', 'status', 'is_post', 'is_shop', 'is_message', 'type'];
    protected $casts = ['id' => 'string', 'user_id' => 'integer', 'status' => 'int', 'is_post' => 'boolean', 'is_shop' => 'boolean', 'is_message' => 'boolean'];
    public function media() : HasOne
    {
        return $this->hasOne(QDkSZEWiaABWN::class, 'id', 'id');
    }
    public static function m9KJntBGD2I(QDkSZEWiaABWN $ymghJ, $BkDh_ = K58fmXwYJHkrL::uZJ6l) : void
    {
        goto e3jtt;
        e3jtt:
        if (!PYgdINKBVRjJT::find($ymghJ->id)) {
            goto ty6CK;
        }
        goto Q2o07;
        FFetz:
        $l9ed4->fill(['id' => $ymghJ->getAttribute('id'), 'user_id' => $ymghJ->getAttribute('user_id') ?? auth()->user()->id, 'status' => $BkDh_, 'type' => $ymghJ->getType(), 'is_post' => $ymghJ->getAttribute('post_id') ? 1 : 0, 'is_message' => $ymghJ->getAttribute('message_id') ? 1 : 0, 'is_shop' => $ymghJ->getAttribute('shop_item_id') ? 1 : 0]);
        goto BOsOr;
        Q2o07:
        return;
        goto oBFmj;
        enO7I:
        $l9ed4 = new PYgdINKBVRjJT();
        goto FFetz;
        BOsOr:
        $l9ed4->save();
        goto z0UwS;
        oBFmj:
        ty6CK:
        goto enO7I;
        z0UwS:
    }
}
