<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:22:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace backup\Gallery\Model\Enum;

class QsEwWxf0Uttny
{
    const gTRA9 = 'video';
    const FThv5 = 'image';
    const OFB1g = 'document';
}
