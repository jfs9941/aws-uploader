<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 10:18:12              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/
 namespace Jfs\Gallery\Model\Enum; class NxCWzIC0023xT { const VZNWB = 'video'; const AgPsR = 'image'; const vNush = 'document'; }
