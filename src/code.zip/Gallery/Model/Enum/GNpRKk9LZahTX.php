<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-16 14:17:43              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at 
*/

namespace Jfs\Gallery\Model\Enum;

class GNpRKk9LZahTX
{
    const cZBFX = 1;
    const NqbhY = 0;
}
