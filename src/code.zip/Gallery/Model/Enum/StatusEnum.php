<?php

namespace Jfs\Gallery\Model\Enum;

class StatusEnum
{
    const APPROVED = 1;
    const PENDING = 0;
}
