<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-31 07:45:23              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model\Enum;

class MediaTypeEnum
{
    const VmYKH = 'video';
    const IQ4BE = 'image';
    const Bkpa3 = 'document';
}
