<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-26 13:26:52              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model\Enum;

class MediaTypeEnum
{
    const zoC0V = 'video';
    const c0BsO = 'image';
    const FT0oH = 'document';
}
