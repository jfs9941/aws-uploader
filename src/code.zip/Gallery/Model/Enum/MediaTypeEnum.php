<?php
/*   __________________________________________________
    |  Obfuscated by YAK Pro - Php Obfuscator  2.0.17  |
    |              on 2025-12-30 04:04:05              |
    |    GitHub: https://github.com/pk-fr/yakpro-po    |
    |__________________________________________________|
*/
/*
Contact me at jfs
*/

namespace Jfs\Gallery\Model\Enum;

class MediaTypeEnum
{
    const Rw7aj = 'video';
    const QRQo1 = 'image';
    const z5Lut = 'document';
}
