<?php

namespace Jfs\Gallery\Model\Enum;

class MediaTypeEnum
{
    const VIDEO = 'video';
    const IMAGE = 'image';
    const DOCUMENT = 'document';
}
